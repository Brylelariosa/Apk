// Port of ViewModels/Map/IEventViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.tools.*

interface IEventViewModel : INotifyPropertyChanged { // cs:22-36
    fun equals(other: IEventViewModel?): Boolean // IEquatable<IEventViewModel>.Equals
    val eventVisualUpdated: Event<EventArgs>
    val cycleEvent: Event<EventCycleDirection>
    val cycleEventCommand: ICommand
    val element: ModelArrayElement?
    val eventType: String
    val eventIndex: String
    val topOffset: Int
    val leftOffset: Int
    var x: Int
    var y: Int
    val eventRender: IPixelViewModel?
    fun render(model: IDataModel, layout: LayoutModel)
    fun delete(): Boolean
    /*@END IEventViewModel*/
}

enum class EventCycleDirection(val value: Int) { // cs:38-38
    PreviousCategory(0),
    PreviousEvent(1),
    NextEvent(2),
    NextCategory(3),
    None(4);
    companion object {
        fun fromValue(value: Int): EventCycleDirection = entries.first { it.value == value }
    }
    /*@END EventCycleDirection*/
}

open class FlyEventViewModel : ViewModelCore, IEventViewModel { // cs:40-172
    private lateinit var flySpot: ModelArrayElement
    private var connectionEntry: ModelArrayElement? = null
    override val eventType: String
        get() { /*@DONE FlyEventViewModel.EventType.get cs:44-44*/
            return "Fly"
        }
    override val eventIndex: String
        get() { /*@DONE FlyEventViewModel.EventIndex.get cs:46-46*/
            return "1/1"
        }
    override val topOffset: Int
        get() { /*@DONE FlyEventViewModel.TopOffset.get cs:48-48*/
            return 0
        }
    override val leftOffset: Int
        get() { /*@DONE FlyEventViewModel.LeftOffset.get cs:49-49*/
            return 0
        }
    override val element: ModelArrayElement?
        get() { /*@DONE FlyEventViewModel.Element.get cs:51-51*/
            return flySpot
        }
    override var x: Int
        get() { /*@DONE FlyEventViewModel.X.get cs:56-56*/
            return if (!valid) -1 else flySpot.getValue("x")
        }
        set(value) { /*@DONE FlyEventViewModel.X.set cs:57-64*/
            if (!valid) return
            flySpot.setValue("x", value)
            notifyPropertyChanged("x")
            if (!ignoreUpdateXY) _xy = null
            notifyPropertyChanged("xy")
            eventVisualUpdated(this, EventArgs.empty)
        }
    override var y: Int
        get() { /*@DONE FlyEventViewModel.Y.get cs:68-68*/
            return if (!valid) -1 else flySpot.getValue("y")
        }
        set(value) { /*@DONE FlyEventViewModel.Y.set cs:69-76*/
            if (!valid) return
            flySpot.setValue("y", value)
            notifyPropertyChanged("y")
            if (!ignoreUpdateXY) _xy = null
            notifyPropertyChanged("xy")
            eventVisualUpdated(this, EventArgs.empty)
        }
    private var ignoreUpdateXY: Boolean = false
    private var _xy: String? = null
    var xy: String
        get() { /*@DONE FlyEventViewModel.XY.get cs:82-86*/
            if (!valid) return "(-1, -1)"
            var current = _xy
            if (current == null) {
                current = "(" + x + ", " + y + ")"
                _xy = current
            }
            return current
        }
        set(value) { /*@DONE FlyEventViewModel.XY.set cs:87-96*/
            if (!valid) return
            _xy = value
            val parts = value.split(',', ' ', '(', ')').filter { part -> part.isNotEmpty() }
            if (parts.size != 2) return
            ignoreUpdateXY = true
            val parsedX = Ref(0)
            val parsedY = Ref(0)
            if (parts[0].tryParseInt(parsedX)) x = parsedX.value
            if (parts[1].tryParseInt(parsedY)) y = parsedY.value
            ignoreUpdateXY = false
        }
    override var eventRender: IPixelViewModel? = null
    var valid: Boolean = false
        private set
    private lateinit var _cycleEventCommand: StubCommand
    override val cycleEventCommand: ICommand
        get() { /*@DONE FlyEventViewModel.CycleEventCommand.get cs:107-109*/
            if (!::_cycleEventCommand.isInitialized) _cycleEventCommand = stubCommandOf<EventCycleDirection>({ direction -> if (direction != null) cycleEvent(this, direction) })
            return _cycleEventCommand
        }
    override val eventVisualUpdated = Event<EventArgs>()
    override val cycleEvent = Event<EventCycleDirection>()
    constructor(flySpot: ModelArrayElement, bank: Int, map: Int, expectedFlight: Int) { /*@DONE FlyEventViewModel.<init>/1 cs:125-149*/
        this.flySpot = flySpot
        val model = flySpot.model!!
        val tokenFactory: () -> ModelDelta = { flySpot.token }
        // get the region from the map
        val banks = model.getTableModel(HardcodeTablesModel.mapBankTable, tokenFactory) ?: return // not valid map table
        val maps = banks[bank].getSubTable("maps") ?: return // not valid bank
        val table = maps[map].getSubTable("map") ?: return // not valid map
        var region = table[0].getValue(Format.regionSection)
        if (model.isFRLG()) region -= 88
        if (region < 0) return // not valid region section

        valid = true // connection entries are optional

        val flyIndexTable = model.getTableModel(HardcodeTablesModel.flyConnections, tokenFactory) ?: return
        if (region >= flyIndexTable.size) return
        val entry = flyIndexTable[region]
        val savedFlight = Ref(0)
        if (entry.tryGetValue("flight", savedFlight) && savedFlight.value == expectedFlight) {
            connectionEntry = entry
        }
    }
    override fun delete(): Boolean { /*@DONE FlyEventViewModel.Delete/1 cs:152-162*/
        if (!valid) return false
        val entry = connectionEntry ?: return false // cannot delete 'special' fly events (such as the player's house)
        // set the connection table's index to 0
        entry.setValue("flight", 0)
        flySpot.setValue("bank", 0)
        flySpot.setValue("map", 0)
        flySpot.setValue("x", 0)
        flySpot.setValue("y", 0)
        return true
    }
    override fun equals(other: IEventViewModel?): Boolean { /*@DONE FlyEventViewModel.Equals/1 cs:164-167*/
        if (other !is FlyEventViewModel) return false
        return x == other.x && y == other.y && flySpot.start == other.flySpot.start
    }
    override fun render(model: IDataModel, layout: LayoutModel) { /*@DONE FlyEventViewModel.Render/1 cs:169-171*/
        eventRender = BaseEventViewModel.buildEventRender(UncompressedPaletteColor.pack(31, 31, 0))
    }
    companion object {
        fun create(model: IDataModel, bank: Int, map: Int, tokenFactory: () -> ModelDelta): Iterable<FlyEventViewModel> { /*@DONE FlyEventViewModel.Create/1 cs:114-123*/
            val result = ArrayList<FlyEventViewModel>()
            val flyTable = model.getTableModel(HardcodeTablesModel.flySpawns, tokenFactory) ?: return result
            for (i in 0 until flyTable.size) {
                val flight = flyTable[i]
                if (flight.getValue("bank") != bank) continue
                if (flight.getValue("map") != map) continue
                result.add(FlyEventViewModel(flight, bank, map, i + 1))
            }
            return result
        }
        /*@END FlyEventViewModel.Companion*/
    }
    /*@END FlyEventViewModel*/
}

abstract class BaseEventViewModel : ViewModelCore, IEventViewModel { // cs:174-418
    override val eventVisualUpdated = Event<EventArgs>()
    override val cycleEvent = Event<EventCycleDirection>()
    private lateinit var _cycleEventCommand: StubCommand
    override val cycleEventCommand: ICommand
        get() { /*@DONE BaseEventViewModel.CycleEventCommand.get cs:179-181*/
            if (!::_cycleEventCommand.isInitialized) _cycleEventCommand = stubCommandOf<EventCycleDirection>({ direction -> if (direction != null) cycleEvent(this, direction) })
            return _cycleEventCommand
        }
    protected lateinit var _element: ModelArrayElement
    private var parentLengthField: String = ""
    override val element: ModelArrayElement?
        get() { /*@DONE BaseEventViewModel.Element.get cs:186-186*/
            return _element
        }
    val token: ModelDelta
        get() { /*@DONE BaseEventViewModel.Token.get cs:187-187*/
            return _element.token
        }
    override val eventType: String
        get() { /*@DONE BaseEventViewModel.EventType.get cs:189-189*/
            // (explicit names: the class names are obfuscated in release builds)
            return when (this) {
                is ObjectEventViewModel -> "Object Event"
                is WarpEventViewModel -> "Warp Event"
                is ScriptEventViewModel -> "Script Event"
                is SignpostEventViewModel -> "Signpost Event"
                else -> "Event"
            }
        }
    override val eventIndex: String
        get() { /*@DONE BaseEventViewModel.EventIndex.get cs:190-190*/
            return "" + (_element.arrayIndex + 1) + " / " + _element.table.elementCount
        }
    override val topOffset: Int
        get() { /*@DONE BaseEventViewModel.TopOffset.get cs:191-191*/
            return 0
        }
    override val leftOffset: Int
        get() { /*@DONE BaseEventViewModel.LeftOffset.get cs:192-192*/
            return 0
        }
    override var x: Int
        get() { /*@DONE BaseEventViewModel.X.get cs:197-197*/
            return _element.getValue("x")
        }
        set(value) { /*@DONE BaseEventViewModel.X.set cs:198-204*/
            _element.setValue("x", value)
            notifyPropertyChanged("x")
            if (!ignoreUpdateXY) _xy = null
            notifyPropertyChanged("xy")
            raiseEventVisualUpdated()
        }
    override var y: Int
        get() { /*@DONE BaseEventViewModel.Y.get cs:208-208*/
            return _element.getValue("y")
        }
        set(value) { /*@DONE BaseEventViewModel.Y.set cs:209-215*/
            _element.setValue("y", value)
            notifyPropertyChanged("y")
            if (!ignoreUpdateXY) _xy = null
            notifyPropertyChanged("xy")
            raiseEventVisualUpdated()
        }
    private var ignoreUpdateXY: Boolean = false
    private var _xy: String? = null
    var xy: String
        get() { /*@DONE BaseEventViewModel.XY.get cs:221-224*/
            var current = _xy
            if (current == null) {
                current = "(" + x + ", " + y + ")"
                _xy = current
            }
            return current
        }
        set(value) { /*@DONE BaseEventViewModel.XY.set cs:225-233*/
            _xy = value
            val parts = value.split(',', ' ', '(', ')').filter { part -> part.isNotEmpty() }
            if (parts.size != 2) return
            ignoreUpdateXY = true
            val parsedX = Ref(0)
            val parsedY = Ref(0)
            if (parts[0].tryParseInt(parsedX)) x = parsedX.value
            if (parts[1].tryParseInt(parsedY)) y = parsedY.value
            ignoreUpdateXY = false
        }
    var elevation: Int
        get() { /*@DONE BaseEventViewModel.Elevation.get cs:241-241*/
            return _element.getValue("elevation")
        }
        set(value) { /*@DONE BaseEventViewModel.Elevation.set cs:242-242*/
            _element.setValue("elevation", value)
        }
    override var eventRender: IPixelViewModel? = null
        protected set
    protected constructor(element: ModelArrayElement, parentLengthField: String) { /*@DONE BaseEventViewModel.<init>/1 cs:249-249*/
        this._element = element
        this.parentLengthField = parentLengthField
    }
    private var _hasScriptAddressError: Boolean = false
    var hasScriptAddressError: Boolean
        get() { /*@DONE BaseEventViewModel.HasScriptAddressError.get cs:254-254*/
            return _hasScriptAddressError
        }
        private set(value) { /*@DONE BaseEventViewModel.HasScriptAddressError.set cs:254-254*/
            set(_hasScriptAddressError, value, "hasScriptAddressError", { _hasScriptAddressError = it })
        }
    private var _scriptAddressError: String = ""
    var scriptAddressError: String
        get() { /*@DONE BaseEventViewModel.ScriptAddressError.get cs:257-257*/
            return _scriptAddressError
        }
        private set(value) { /*@DONE BaseEventViewModel.ScriptAddressError.set cs:257-257*/
            set(_scriptAddressError, value, "scriptAddressError", { _scriptAddressError = it })
        }
    protected fun updateScriptError(address: Int) { /*@DONE BaseEventViewModel.UpdateScriptError/1 cs:259-281*/
        if (address == Pointer.null_) {
            scriptAddressError = "Event has no script."
            hasScriptAddressError = true
            return
        }

        val eventModel = _element.model!!
        if (address < 0 || address >= eventModel.count) {
            scriptAddressError = "Address is not valid."
            hasScriptAddressError = true
            return
        }

        val run = eventModel.getNextRun(address)
        if (run == null || run.start != address || (run !is XSERun && run !is NoInfoRun)) {
            scriptAddressError = if (isValidScriptFreespace(address)) "Freespace found at that address." else "No script found at that address."
            hasScriptAddressError = true
            return
        }

        hasScriptAddressError = false
        scriptAddressError = ""
    }
    protected fun isValidScriptFreespace(address: Int): Boolean { /*@DONE BaseEventViewModel.IsValidScriptFreespace/1 cs:283-294*/
        val minLength = 10
        if (address == Pointer.null_) return true
        val eventModel = _element.model!!
        if (address < 0 || address >= eventModel.count - minLength) return false
        for (i in 0 until minLength) {
            if (eventModel[address + i] != 0xFF) return false
        }
        val run = eventModel.getNextRun(address)
        val nextRun = eventModel.getNextRun(address + 1)
        if (run == null || address != run.start) return false
        return run is NoInfoRun && (nextRun == null || nextRun.start > address + minLength)
    }
    override fun delete(): Boolean { /*@DONE BaseEventViewModel.Delete/1 cs:298-298*/
        return deleteElement(parentLengthField)
    }
    override fun equals(other: IEventViewModel?): Boolean { /*@DONE BaseEventViewModel.Equals/1 cs:300-303*/
        if (other !is BaseEventViewModel) return false
        return other._element.start == _element.start
    }
    abstract override fun render(model: IDataModel, layout: LayoutModel)
    protected fun raiseEventVisualUpdated() { /*@DONE BaseEventViewModel.RaiseEventVisualUpdated/1 cs:307-307*/
        eventVisualUpdated(this, EventArgs.empty)
    }
    protected fun deleteElement(parentCountField: String): Boolean { /*@DONE BaseEventViewModel.DeleteElement/1 cs:309-343*/
        val table = _element.table
        val model = _element.model!!
        val token = _element.token
        val offset = table.convertByteOffsetToArrayOffset(_element.start)
        val editCount = table.elementCount - offset.elementIndex - 1
        for (i in 0 until editCount) {
            var segmentOffset = 0
            for (j in 0 until table.elementContent.size) {
                val source = _element.start + (i + 1) * _element.length + segmentOffset
                val destination = source - _element.length
                val length = table.elementContent[j].length
                if (table.elementContent[j].type == ElementContentType.Pointer) {
                    model.updateArrayPointer(token, table.elementContent[j], table.elementContent, offset.elementIndex, destination, model.readPointer(source))
                } else {
                    model.writeMultiByteValue(destination, length, token, model.readMultiByteValue(source, length))
                }
                segmentOffset += length
            }
        }
        if (table.elementCount > 1) {
            val shorterTable = table.append(token, -1)
            model.observeRunWritten(token, shorterTable)
        } else {
            val sources = table.pointerSources
            if (sources != null) {
                for (source in sources.toList()) {
                    model.updateArrayPointer(token, null, null, 0, source, Pointer.null_)
                    val parentTable = model.getNextRun(source) as? ITableRun
                    if (parentTable != null) {
                        val parent = ModelArrayElement(model, parentTable.start, 0, { token }, parentTable)
                        parent.setValue(parentCountField, 0)
                    }
                }
            }
            model.clearFormatAndData(token, table.start, table.length)
        }
        return true
    }
    protected fun getText(pointer: Int): String? { /*@DONE BaseEventViewModel.GetText/1 cs:345-366*/
        if (pointer == Pointer.null_) return null
        val eventModel = _element.model!!
        val address = eventModel.readPointer(pointer)
        if (address < 0 || address >= eventModel.count) return null
        var run: IFormattedRun? = eventModel.getNextRun(address)
        if (run == null || run.start != address) {
            if (run != null && run.start < address) return null
            val length = PCSString.readString(eventModel, address, true)
            if ((run != null && run.start < address + length) || length < 1) return null
            // we can add a PCSRun here
            run = PCSRun(eventModel, address, length, SortedSpanStatic.one(pointer))
            val pointerRun = eventModel.getNextRun(pointer)
            if (pointerRun == null || pointerRun.start >= pointer + 4) eventModel.observeRunWritten(_element.token, PointerRun(pointer))
            eventModel.observeRunWritten(_element.token, run)
        }
        var pcs = run as? PCSRun
        if (pcs == null) {
            val length = PCSString.readString(eventModel, address, true)
            eventModel.clearFormat(_element.token, address, length)
            pcs = PCSRun(eventModel, address, length, run!!.pointerSources)
        }
        if (pcs.length < 1) return ""
        return pcs.serializeRun()
    }
    protected fun setText(pointer: Int, text: String, propertyName: String? = null): Int { /*@DONE BaseEventViewModel.SetText/1 cs:368-377*/
        if (pointer == Pointer.null_) return Pointer.null_
        val eventModel = _element.model!!
        val address = eventModel.readPointer(pointer)
        if (address < 0 || address >= eventModel.count) return -1
        val pcs = eventModel.getNextRun(address) as? PCSRun ?: return -1
        val newRun = pcs.deserializeRun(text, _element.token, Ref<List<Int>?>(null), Ref<List<Int>?>(null))
        eventModel.observeRunWritten(_element.token, newRun)
        if (propertyName != null) notifyPropertyChanged(propertyName)
        return if (newRun.start != pcs.start) newRun.start else -1
    }
    protected fun getAddressText(address: Int, field: Ref<String?>): String { /*@DONE BaseEventViewModel.GetAddressText/1 cs:379-385*/
        var current = field.value
        if (current == null) {
            current = "<" + address.toAddress() + ">"
            if (address == Pointer.null_) current = "<null>"
            field.value = current
        }
        return current
    }
    protected fun setAddressText(value: String, field: Ref<String?>, fieldName: String, writeFormat: Boolean) { /*@DONE BaseEventViewModel.SetAddressText/1 cs:387-391*/
        field.value = value
        val trimmed = value.trim { c -> "<nul> ".indexOf(c) >= 0 }
        val result = Ref(0)
        _element.setAddress(fieldName, if (trimmed.tryParseHex(result)) result.value else Pointer.null_, writeFormat)
    }
    companion object {
        private val focalPoints: Array<Point> = /*@INITDONE BaseEventViewModel.focalPoints cs:393-393*/ arrayOf(Point(0, 7), Point(7, 0), Point(15, 8), Point(8, 15)) /*@ENDINIT*/
        fun buildEventRender(color: Short, indentSides: Boolean = false): IPixelViewModel { /*@DONE BaseEventViewModel.BuildEventRender/1 cs:394-406*/
            val pixels = ShortArray(256)

            for (x in 1 until 15) {
                var y = 1
                while (y < 15) {
                    if (((x + y) and 1) != 0) {
                        y++
                        continue
                    }
                    val cy = y
                    if (indentSides && focalPoints.any { p -> Math.abs(p.x - x) + Math.abs(p.y - cy) < 4 }) {
                        y++
                        continue
                    }
                    pixels[y * 16 + x] = color
                    y++
                    y++
                }
            }
            return ReadonlyPixelViewModel(SpriteFormat(4, 2, 2, null), pixels, 0.toShort())
        }
        fun buildInvisibleEventRender(colors: IPixelViewModel): IPixelViewModel { /*@DONE BaseEventViewModel.BuildInvisibleEventRender/1 cs:408-417*/
            val pixels = ShortArray(colors.pixelData.size)
            for (x in 0 until colors.pixelWidth) {
                for (y in 0 until colors.pixelHeight) {
                    if (((x + y) and 1) != 0) pixels[y * colors.pixelWidth + x] = colors.transparent
                    else pixels[y * colors.pixelWidth + x] = colors.pixelData[y * colors.pixelWidth + x]
                }
            }
            return ReadonlyPixelViewModel(SpriteFormat(4, colors.pixelWidth / 8, colors.pixelHeight / 8, null), pixels, colors.transparent)
        }
        /*@END BaseEventViewModel.Companion*/
    }
    /*@END BaseEventViewModel*/
}

open class EventTextViewModel : ViewModelCore() { // cs:420-425
    private var _pointerAddress: Int = 0
    var pointerAddress: Int
        get() { /*@DONE EventTextViewModel.PointerAddress.get cs:422-422*/
            return _pointerAddress
        }
        set(value) { /*@DONE EventTextViewModel.PointerAddress.set cs:422-422*/
            set(_pointerAddress, value, "pointerAddress", { _pointerAddress = it }) { old -> notifyPropertyChanged("pointerAddressText") }
        }
    val pointerAddressText: String
        get() { /*@DONE EventTextViewModel.PointerAddressText.get cs:423-423*/
            return pointerAddress.toAddress()
        }
    var text: TextEditorViewModel = /*@INITDONE EventTextViewModel.Text cs:424-424*/ TextEditorViewModel() /*@ENDINIT*/
        private set
    /*@END EventTextViewModel*/
}

open class ObjectEventViewModel : BaseEventViewModel { // cs:427-1630
    private lateinit var parent: BlockMapViewModel
    private lateinit var parser: ScriptParser
    private lateinit var eventTemplate: EventTemplate
    private lateinit var berries: BerryInfo
    private lateinit var gotoAddress: (Int) -> Unit
    val dataMoved = Event<DataMovedEventArgs>()
    val start: Int
        get() { /*@DONE ObjectEventViewModel.Start.get cs:436-436*/
            return _element.start
        }
    var objectID: Int
        get() { /*@DONE ObjectEventViewModel.ObjectID.get cs:439-439*/
            return _element.getValue("id")
        }
        set(value) { /*@DONE ObjectEventViewModel.ObjectID.set cs:440-443*/
            _element.setValue("id", value)
            notifyPropertyChanged("objectID")
        }
    var graphics: Int
        get() { /*@DONE ObjectEventViewModel.Graphics.get cs:447-447*/
            return _element.getValue("graphics")
        }
        set(value) { /*@DONE ObjectEventViewModel.Graphics.set cs:448-453*/
            _element.setValue("graphics", value)
            raiseEventVisualUpdated()
            notifyPropertyChanged("graphics")
            notifyPropertiesChanged("hasGraphicsInTransitionScript", "canAddDynamicGraphicsToTransitionScript")
        }
    private var _graphicsText: String? = null
    var graphicsText: String
        get() { /*@DONE ObjectEventViewModel.GraphicsText.get cs:458-462*/
            var current = _graphicsText
            if (current != null) return current
            current = graphics.toString()
            _graphicsText = current
            return current
        }
        set(value) { /*@DONE ObjectEventViewModel.GraphicsText.set cs:463-469*/
            _graphicsText = value
            val result = Ref(0)
            if (!value.tryParseInt(result)) return
            graphics = result.value
            notifyPropertiesChanged("canAddDynamicGraphicsToTransitionScript", "hasGraphicsInTransitionScript")
            if (hasGraphicsInTransitionScript) loadDynamicOverworldGraphicsCategories()
        }
    private var _showGraphicsAsText: Boolean = false
    var showGraphicsAsText: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowGraphicsAsText.get cs:474-474*/
            return _showGraphicsAsText
        }
        set(value) { /*@DONE ObjectEventViewModel.ShowGraphicsAsText.set cs:475-483*/
            set(_showGraphicsAsText, value, "showGraphicsAsText", { _showGraphicsAsText = it }) { old ->
                _graphicsText = null
                notifyPropertiesChanged("graphicsText", "canAddDynamicGraphicsToTransitionScript", "hasGraphicsInTransitionScript")
                if (value) {
                    loadDynamicOverworldGraphicsCategories()
                }
            }
        }
    val canAddDynamicGraphicsToTransitionScript: Boolean
        get() { /*@DONE ObjectEventViewModel.CanAddDynamicGraphicsToTransitionScript.get cs:488-488*/
            return !hasGraphicsInTransitionScript && showGraphicsAsText && graphics >= 240
        }
    fun addDynamicGraphicsToTransitionScript() { /*@DONE ObjectEventViewModel.AddDynamicGraphicsToTransitionScript/1 cs:490-510*/
        if (hasGraphicsInTransitionScript) return
        val scripts = MapScriptCollection(parent.viewPort, eventTemplate)
        scripts.load(parent.getMapModel())
        var transitionScriptFound = false
        for (script in scripts.scripts) {
            if (script.scriptOptions[script.scriptTypeIndex].option != "Transition") continue
            transitionScriptFound = true
            val tool = parent.viewPort.tools?.codeTool ?: break

            parent.viewPort.gotoScript(script.scriptAddress)
            val body = tool.contents[0]
            body.content = "setvar gfx" + (graphics - 240) + " 18" + "\n" + body.content
            break
        }
        if (!transitionScriptFound) {
            scripts.addScript()
            scripts.scripts.last().scriptTypeIndex = 2 // Transition
            addDynamicGraphicsToTransitionScript()
        }
    }
    fun pullValueFromTransitionScript(): Int { /*@DONE ObjectEventViewModel.PullValueFromTransitionScript/1 cs:512-528*/
        val scripts = MapScriptCollection(parent.viewPort, eventTemplate)
        scripts.load(parent.getMapModel())
        val model = _element.model!!
        for (script in scripts.scripts) {
            if (script.scriptOptions[script.scriptTypeIndex].option != "Transition") continue

            val spots = Flags.getAllScriptSpots(model, parser, listOf(script.scriptAddress), 0x16)
                .filter { spot -> model.readMultiByteValue(spot.address + 1, 2) == 0x4010 + graphics - 240 } // setvar gfxN

            val spot = spots.firstOrNull() ?: continue
            val dynamicValue = model.readMultiByteValue(spot.address + 3, 2)
            return dynamicValue
        }
        return -1
    }
    val hasGraphicsInTransitionScript: Boolean
        get() { /*@DONE ObjectEventViewModel.HasGraphicsInTransitionScript.get cs:531-544*/
            if (!showGraphicsAsText) return false // short circuit: if we're not doing dynamic graphics, don't show anything
            // check that we have a transition script that sets graphics
            val scripts = MapScriptCollection(parent.viewPort, eventTemplate)
            scripts.load(parent.getMapModel())
            val model = _element.model!!
            for (script in scripts.scripts) {
                if (script.scriptOptions[script.scriptTypeIndex].option != "Transition") continue
                val spots = Flags.getAllScriptSpots(model, parser, listOf(script.scriptAddress), 0x16)
                    .filter { spot -> model.readMultiByteValue(spot.address + 1, 2) == 0x4010 + graphics - 240 } // setvar gfxN

                if (spots.size > 0) return true
            }
            return false
        }
    fun updateDynamicOverworldGraphicsInScript() { /*@DONE ObjectEventViewModel.UpdateDynamicOverworldGraphicsInScript/1 cs:546-567*/
        if (dynamicOverworldGraphicsSelectedIndex == -1) return
        val scripts = MapScriptCollection(parent.viewPort, eventTemplate)
        scripts.load(parent.getMapModel())
        val model = _element.model!!
        for (script in scripts.scripts) {
            if (script.scriptOptions[script.scriptTypeIndex].option != "Transition") continue

            val spots = Flags.getAllScriptSpots(model, parser, listOf(script.scriptAddress), 0x16)
                .filter { spot -> model.readMultiByteValue(spot.address + 1, 2) == 0x4010 + graphics - 240 } // setvar gfxN

            val spot = spots.firstOrNull() ?: continue
            val categoryIndex = dynamicOverworldGraphicsCategories.selectedIndex
            if (categoryIndex < 0 || categoryIndex >= dynamicOverworldGraphicsCategories.filteredOptions.size) return
            var dynamicOffset = 0
            val categoryText = dynamicOverworldGraphicsCategories.filteredOptions[categoryIndex].text
            if (categoryText == "Pokemon Icons") dynamicOffset = 10000
            if (categoryText == "Expanded Overworld Sprites") dynamicOffset = 20000
            val existingValue = model.readMultiByteValue(spot.address + 3, 2)
            if (existingValue == dynamicOverworldGraphicsSelectedIndex + dynamicOffset) continue
            model.writeMultiByteValue(spot.address + 3, 2, token, dynamicOverworldGraphicsSelectedIndex + dynamicOffset)
            raiseEventVisualUpdated()
        }
    }
    private var previousCategoryListener: IDisposable? = null
    private fun loadDynamicOverworldGraphicsCategories() { /*@DONE ObjectEventViewModel.LoadDynamicOverworldGraphicsCategories/1 cs:569-595*/
        val model = _element.model!!
        val categories = ArrayList<String>()
        if (model.getTable("graphics.overworld.sprites") != null) categories.add("Overworld Sprites")
        if (model.getTable("graphics.overworld.pokemon") != null) categories.add("Pokemon Icons")
        if (model.getTable("graphics.overworld.sprites20k") != null) categories.add("Expanded Overworld Sprites")
        if (categories.size == 0) return
        val scripts = MapScriptCollection(parent.viewPort, eventTemplate)
        scripts.load(parent.getMapModel())
        var selectedIndex = 0
        for (script in scripts.scripts) {
            if (script.scriptOptions[script.scriptTypeIndex].option != "Transition") continue
            val spots = Flags.getAllScriptSpots(model, parser, listOf(script.scriptAddress), 0x16)
                .filter { spot -> model.readMultiByteValue(spot.address + 1, 2) == 0x4010 + graphics - 240 } // setvar gfxN
            val spot = spots.firstOrNull() ?: continue
            val desiredTable = model.readMultiByteValue(spot.address + 3, 2) / 10000
            if (desiredTable == 0) selectedIndex = categories.indexOf("Overworld Sprites")
            if (desiredTable == 1) selectedIndex = categories.indexOf("Pokemon Icons")
            if (desiredTable == 2) selectedIndex = categories.indexOf("Expanded Overworld Sprites")
            if (selectedIndex == -1) selectedIndex = 0
        }

        previousCategoryListener?.dispose()
        dynamicOverworldGraphicsCategories.update(categories.mapIndexed { i, option -> ComboOption(option, i) }, selectedIndex)
        loadDynamicOverworldGraphicsOptions()
        previousCategoryListener = dynamicOverworldGraphicsCategories.bind("selectedIndex") { _, _ -> loadDynamicOverworldGraphicsOptions() }
    }
    private fun loadDynamicOverworldGraphicsOptions() { /*@DONE ObjectEventViewModel.LoadDynamicOverworldGraphicsOptions/1 cs:598-631*/
        val model = _element.model!!
        val categoryIndex = dynamicOverworldGraphicsCategories.selectedIndex
        val filtered = dynamicOverworldGraphicsCategories.filteredOptions
        if (categoryIndex < 0 || categoryIndex >= filtered.size) return
        val categoryText = filtered[categoryIndex].text
        if (categoryText == "Overworld Sprites") {
            dynamicOverworldOptions.clear()
            for (option in options) dynamicOverworldOptions.add(VisualComboOption.createFromSprite(option.text, option.pixelData, option.pixelWidth, option.index, 2.0, true))
            dynamicOverworldGraphicsSelectedIndex = pullValueFromTransitionScript()
        } else if (categoryText == "Pokemon Icons") {
            var index = -1
            dynamicOverworldOptions.clear()
            val pokemonTable = model.getTable("graphics.overworld.pokemon") ?: return
            for (mon in ModelTable(model, pokemonTable)) {
                index += 1
                val run = model.getNextRun(mon.getAddress("sprite")) as? ISpriteRun ?: continue
                val full = ReadonlyPixelViewModel.create(model, run) ?: continue
                val sprite = ReadonlyPixelViewModel.crop(full, 0, 0, full.pixelWidth, full.pixelWidth)
                dynamicOverworldOptions.add(VisualComboOption.createFromSprite(index.toString(), sprite.pixelData, sprite.pixelWidth, index, 2.0, true))
            }
            dynamicOverworldGraphicsSelectedIndex = pullValueFromTransitionScript() - 10000
        } else if (categoryText == "Expanded Overworld Sprites") {
            var index = -1
            dynamicOverworldOptions.clear()
            val expandedTable = model.getTable("graphics.overworld.sprites20k") ?: return
            for (item in ModelTable(model, expandedTable)) {
                index += 1
                val sprites = item.getSubTable("sprites") ?: continue
                val run = model.getNextRun(sprites[0].getAddress("sprite")) as? ISpriteRun ?: continue
                val sprite = ReadonlyPixelViewModel.create(model, run) ?: continue
                dynamicOverworldOptions.add(VisualComboOption.createFromSprite(index.toString(), sprite.pixelData, sprite.pixelWidth, index, 2.0, true))
            }
            dynamicOverworldGraphicsSelectedIndex = pullValueFromTransitionScript() - 20000
        }
    }
    var dynamicOverworldGraphicsCategories: FilteringComboOptions = /*@INITDONE ObjectEventViewModel.DynamicOverworldGraphicsCategories cs:632-632*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    private var dynamicGraphicsIndex: Int = 0
    var dynamicOverworldGraphicsSelectedIndex: Int
        get() { /*@DONE ObjectEventViewModel.DynamicOverworldGraphicsSelectedIndex.get cs:634-634*/
            return dynamicGraphicsIndex
        }
        set(value) { /*@DONE ObjectEventViewModel.DynamicOverworldGraphicsSelectedIndex.set cs:634-634*/
            set(dynamicGraphicsIndex, value, "dynamicOverworldGraphicsSelectedIndex", { dynamicGraphicsIndex = it }) { old -> updateDynamicOverworldGraphicsInScript() }
        }
    var dynamicOverworldOptions: ObservableCollection<VisualComboOption> = /*@INITDONE ObjectEventViewModel.DynamicOverworldOptions cs:635-635*/ ObservableCollection() /*@ENDINIT*/
        private set
    val hasKind: Boolean
        get() { /*@DONE ObjectEventViewModel.HasKind.get cs:645-645*/
            return _element.hasField("kind")
        }
    var kind: Boolean
        get() { /*@DONE ObjectEventViewModel.Kind.get cs:647-647*/
            val kindValue = Ref(0)
            return if (_element.tryGetValue("kind", kindValue)) kindValue.value != 0 else false
        }
        set(value) { /*@DONE ObjectEventViewModel.Kind.set cs:648-650*/
            if (_element.hasField("kind")) _element.setValue("kind", if (value) 0xFF else 0)
        }
    var moveType: Int
        get() { /*@DONE ObjectEventViewModel.MoveType.get cs:654-654*/
            return _element.getValue("moveType")
        }
        set(value) { /*@DONE ObjectEventViewModel.MoveType.set cs:655-660*/
            _element.setValue("moveType", value)
            val allFacing = facingOptions.allOptions
            if (allFacing != null) facingOptions.update(allFacing, moveType)
            raiseEventVisualUpdated()
            notifyPropertyChanged("moveType")
        }
    var rangeX: Int
        get() { /*@DONE ObjectEventViewModel.RangeX.get cs:666-666*/
            return _element.getValue("range") and 0xF
        }
        set(value) { /*@DONE ObjectEventViewModel.RangeX.set cs:667-672*/
            _element.setValue("range", (rangeY shl 4) or value)
            _rangeXY = null
            notifyPropertyChanged("rangeXY")
            raiseEventVisualUpdated()
        }
    var rangeY: Int
        get() { /*@DONE ObjectEventViewModel.RangeY.get cs:676-676*/
            return _element.getValue("range") shr 4
        }
        set(value) { /*@DONE ObjectEventViewModel.RangeY.set cs:677-682*/
            _element.setValue("range", (value shl 4) or rangeX)
            _rangeXY = null
            notifyPropertyChanged("rangeXY")
            raiseEventVisualUpdated()
        }
    private var _rangeXY: String? = null
    var rangeXY: String
        get() { /*@DONE ObjectEventViewModel.RangeXY.get cs:687-690*/
            var current = _rangeXY
            if (current == null) {
                current = "(" + rangeX + ", " + rangeY + ")"
                _rangeXY = current
            }
            return current
        }
        set(value) { /*@DONE ObjectEventViewModel.RangeXY.set cs:691-700*/
            _rangeXY = value
            val parts = value.split(',', ' ', '(', ')').filter { part -> part.isNotEmpty() }
            if (parts.size != 2) return
            val parsedX = Ref(0)
            val parsedY = Ref(0)
            if (parts[0].tryParseInt(parsedX) && parts[1].tryParseInt(parsedY)) _element.setValue("range", (parsedY.value shl 4) or parsedX.value)
            notifyPropertyChanged("rangeX")
            notifyPropertyChanged("rangeY")
            notifyPropertyChanged("rangeXY")
            raiseEventVisualUpdated()
        }
    var trainerType: Int
        get() { /*@DONE ObjectEventViewModel.TrainerType.get cs:706-706*/
            return _element.getValue("trainerType")
        }
        set(value) { /*@DONE ObjectEventViewModel.TrainerType.set cs:707-711*/
            _element.setValue("trainerType", value)
            notifyPropertiesChanged("showBerryContent", "showTrainerContent", "showRematchTrainerContent", "showNoContent")
            notifyPropertyChanged("trainerType")
        }
    var trainerRangeOrBerryID: Int
        get() { /*@DONE ObjectEventViewModel.TrainerRangeOrBerryID.get cs:715-715*/
            return _element.getValue("trainerRangeOrBerryID")
        }
        set(value) { /*@DONE ObjectEventViewModel.TrainerRangeOrBerryID.set cs:716-721*/
            _element.setValue("trainerRangeOrBerryID", value)
            raiseEventVisualUpdated()
            notifyPropertiesChanged("showBerryContent", "berryText")
            notifyPropertyChanged("trainerRangeOrBerryID")
        }
    var scriptAddress: Int
        get() { /*@DONE ObjectEventViewModel.ScriptAddress.get cs:725-725*/
            return _element.getAddress("script")
        }
        set(value) { /*@DONE ObjectEventViewModel.ScriptAddress.set cs:726-752*/
            _element.setAddress("script", value, false)
            updateScriptError(_element.getAddress("script"))
            notifyPropertyChanged("scriptAddress")
            resetScriptDependentCaches()
            _scriptAddressText = null
            martContentText = null
            notifyPropertiesChanged(
                "scriptAddressText",
                "showItemContents", "itemContents",
                "showNpcText", "npcTextEditor",
                "showTrainerContent", "trainerClass", "trainerSprite", "trainerName", "trainerBeforeTextEditor", "trainerAfterTextEditor", "trainerWinTextEditor", "trainerTeam",
                "showRematchTrainerContent",
                "showMartContents", "martHelloEditor", "martContent", "martGoodbyeEditor",
                "showTutorContent", "tutorInfoText", "tutorWhichPokemonText", "tutorFailedText", "tutorSucessText", "tutorNumber",
                "showTradeContent", "tradeFailedEditor", "tradeIndex", "tradeInitialEditor", "tradeSuccessEditor", "tradeThanksEditor", "tradeWrongSpeciesEditor",
                "showLegendaryContent", "level", "legendaryFlagText", "hasCryText", "cryEditor", "sampleLegendClearScript",
                "showBerryContent", "berryText", "canCreateScript")
        }
    fun gotoScript() { /*@DONE ObjectEventViewModel.GotoScript/1 cs:755-758*/
        setDestinationFormat()
        gotoAddress(scriptAddress)
    }
    val canGotoScript: Boolean
        get() { /*@DONE ObjectEventViewModel.CanGotoScript.get cs:759-759*/
            return 0 <= scriptAddress && scriptAddress < _element.model!!.count
        }
    val canCreateScript: Boolean
        get() { /*@DONE ObjectEventViewModel.CanCreateScript.get cs:761-761*/
            return isValidScriptFreespace(scriptAddress) || scriptAddress == Pointer.null_
        }
    fun createScript() { /*@DONE ObjectEventViewModel.CreateScript/1 cs:762-770*/
        val eventModel = _element.model!!
        val start: Int
        if (scriptAddress != Pointer.null_ && isValidScriptFreespace(scriptAddress)) start = scriptAddress
        else start = eventModel.findFreeSpace(eventModel.freeSpaceStart, 0x10)
        token.changeData(eventModel, start, byteArrayOf(0x6A, 0x5A, 0x6C, 0x02).asByteList()) // lock, faceplayer, release, end
        scriptAddress = start
        setDestinationFormat()
        gotoAddress(start)
    }
    private var _scriptAddressText: String? = null
    var scriptAddressText: String
        get() { /*@DONE ObjectEventViewModel.ScriptAddressText.get cs:774-778*/
            val cached = _scriptAddressText
            if (cached != null) return cached
            val value = _element.getAddress("script")
            val cache = Ref<String?>(_scriptAddressText)
            val text = getAddressText(value, cache)
            _scriptAddressText = cache.value
            return text
        }
        set(value) { /*@DONE ObjectEventViewModel.ScriptAddressText.set cs:779-805*/
            val cache = Ref<String?>(_scriptAddressText)
            setAddressText(value, cache, "script", false)
            _scriptAddressText = cache.value
            notifyPropertyChanged("scriptAddressText")
            resetScriptDependentCaches()
            martContentText = null

            notifyPropertiesChanged(
                "scriptAddress",
                "showItemContents", "itemContents",
                "showNpcText", "npcTextEditor",
                "showTrainerContent", "trainerClass", "trainerSprite", "trainerName", "trainerBeforeTextEditor", "trainerAfterTextEditor", "trainerWinTextEditor", "trainerTeam",
                "showRematchTrainerContent",
                "showMartContents", "martHelloEditor", "martContent", "martGoodbyeEditor",
                "showTutorContent", "tutorInfoText", "tutorWhichPokemonText", "tutorFailedText", "tutorSucessText", "tutorNumber",
                "showTradeContent", "tradeFailedEditor", "tradeIndex", "tradeInitialEditor", "tradeSuccessEditor", "tradeThanksEditor", "tradeWrongSpeciesEditor",
                "showLegendaryContent", "level", "legendaryFlagText", "hasCryText", "cryEditor", "sampleLegendClearScript",
                "showBerryContent", "berryText", "canCreateScript")
            updateScriptError(scriptAddress)
        }
    var flag: Int
        get() { /*@DONE ObjectEventViewModel.Flag.get cs:811-811*/
            return _element.getValue("flag")
        }
        set(value) { /*@DONE ObjectEventViewModel.Flag.set cs:812-817*/
            _element.setValue("flag", value)
            notifyPropertyChanged("flag")
            _flagText = null
            notifyPropertiesChanged("flagText", "sampleLegendClearScript")
        }
    private var _flagText: String? = null
    var flagText: String
        get() { /*@DONE ObjectEventViewModel.FlagText.get cs:822-825*/
            var current = _flagText
            if (current == null) {
                current = _element.getValue("flag").toHex(4)
                _flagText = current
            }
            return current
        }
        set(value) { /*@DONE ObjectEventViewModel.FlagText.set cs:826-831*/
            _flagText = value
            val result = Ref(0)
            _element.setValue("flag", if (value.tryParseHex(result)) result.value else 0)
            notifyPropertyChanged("flagText")
            notifyPropertiesChanged("flag", "sampleLegendClearScript", "canGenerateNewFlag")
        }
    val canGenerateNewFlag: Boolean
        get() { /*@DONE ObjectEventViewModel.CanGenerateNewFlag.get cs:834-834*/
            return flag == 0
        }
    fun generateNewFlag() { /*@DONE ObjectEventViewModel.GenerateNewFlag/1 cs:836-839*/
        flag = eventTemplate.findNextUnusedFlag()
        notifyPropertiesChanged("flagText", "canGenerateNewFlag")
    }
    var padding: Int
        get() { /*@DONE ObjectEventViewModel.Padding.get cs:844-844*/
            val paddingValue = Ref(0)
            return if (_element.tryGetValue("padding", paddingValue)) paddingValue.value else 0
        }
        set(value) { /*@DONE ObjectEventViewModel.Padding.set cs:845-848*/
            _element.setValue("padding", value)
            notifyPropertyChanged("padding")
        }
    lateinit var defaultOW: IPixelViewModel
        private set
    var options: ObservableCollection<VisualComboOption> = /*@INITDONE ObjectEventViewModel.Options cs:852-852*/ ObservableCollection() /*@ENDINIT*/
        private set
    var facingOptions: FilteringComboOptions = /*@INITDONE ObjectEventViewModel.FacingOptions cs:853-853*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    var classOptions: ObservableCollection<String> = /*@INITDONE ObjectEventViewModel.ClassOptions cs:854-854*/ ObservableCollection() /*@ENDINIT*/
        private set
    var itemOptions: FilteringComboOptions = /*@INITDONE ObjectEventViewModel.ItemOptions cs:855-855*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    val showItemContents: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowItemContents.get cs:863-863*/
            return EventTemplate.getItemAddress(_element.model!!, this) != Pointer.null_
        }
    var itemContents: Int
        get() { /*@DONE ObjectEventViewModel.ItemContents.get cs:866-870*/
            val itemAddress = EventTemplate.getItemAddress(_element.model!!, this)
            if (itemAddress == Pointer.null_) return -1
            return _element.model!!.readMultiByteValue(itemAddress, 2)
        }
        set(value) { /*@DONE ObjectEventViewModel.ItemContents.set cs:871-877*/
            val itemAddress = EventTemplate.getItemAddress(_element.model!!, this)
            if (itemAddress == Pointer.null_) return
            _element.model!!.writeMultiByteValue(itemAddress, 2, _element.token, value)
            val allItems = itemOptions.allOptions
            if (allItems != null) itemOptions.update(allItems, value)
            notifyPropertyChanged("itemContents")
        }
    val showNpcText: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowNpcText.get cs:882-882*/
            return EventTemplate.getNPCTextPointer(_element.model!!, this) != Pointer.null_
        }
    private var _npcTextEditor: TextEditorViewModel? = null
    val npcTextEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.NpcTextEditor.get cs:885-885*/
            return createTextEditor({ _npcTextEditor }, { _npcTextEditor = it }, { EventTemplate.getNPCTextPointer(_element.model!!, this) }, "npcTextEditor")
        }
    var trainerOptions: FilteringComboOptions = /*@INITDONE ObjectEventViewModel.TrainerOptions cs:891-891*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    val showTrainerContent: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowTrainerContent.get cs:893-893*/
            return EventTemplate.getTrainerContent(_element.model!!, this) != null && trainerType != 0
        }
    var trainerContent: TextEditorViewModel = /*@INITDONE ObjectEventViewModel.TrainerContent cs:895-895*/ TextEditorViewModel() /*@ENDINIT*/
        private set
    var trainerClass: Int
        get() { /*@DONE ObjectEventViewModel.TrainerClass.get cs:898-902*/
            val content = EventTemplate.getTrainerContent(_element.model!!, this) ?: return -1
            return _element.model!![content.trainerClassAddress]
        }
        set(value) { /*@DONE ObjectEventViewModel.TrainerClass.set cs:903-911*/
            val content = EventTemplate.getTrainerContent(_element.model!!, this) ?: return
            _element.token.changeData(_element.model!!, content.trainerClassAddress, value and 0xFF)

            val allTrainers = trainerOptions.allOptions
            if (allTrainers != null) {
                val updated = ArrayList<ComboOption>(allTrainers)
                if (content.trainerIndex >= 0 && content.trainerIndex < updated.size) {
                    updated[content.trainerIndex] = createOption(content.trainerIndex, value, trainerName ?: "")
                    trainerOptions.update(updated, content.trainerIndex)
                }
            }
        }
    private var _trainerSprite: IPixelViewModel? = null
    val trainerSprite: IPixelViewModel?
        get() { /*@DONE ObjectEventViewModel.TrainerSprite.get cs:916-924*/
            val cached = _trainerSprite
            if (cached != null) return cached
            val eventModel = _element.model!!
            val content = EventTemplate.getTrainerContent(eventModel, this) ?: return null
            val spriteIndex = eventModel[content.trainerClassAddress + 2]
            val spriteTable = eventModel.getTableModel(HardcodeTablesModel.trainerSpritesName) ?: return null
            val spriteAddress = spriteTable[spriteIndex].getAddress("sprite")
            val spriteRun = eventModel.getNextRun(spriteAddress) as? ISpriteRun
            val sprite = ReadonlyPixelViewModel.create(eventModel, spriteRun, true, .5)
            _trainerSprite = sprite
            return sprite
        }
    private var _trainerName: String? = null
    var trainerName: String?
        get() { /*@DONE ObjectEventViewModel.TrainerName.get cs:929-935*/
            val cached = _trainerName
            if (cached != null) return cached
            val eventModel = _element.model!!
            val content = EventTemplate.getTrainerContent(eventModel, this) ?: return null
            val text = eventModel.textConverter.convert(eventModel, content.trainerNameAddress, 12) ?: ""
            val trimmed = text.trim('"')
            _trainerName = trimmed
            return trimmed
        }
        set(value) { /*@DONE ObjectEventViewModel.TrainerName.set cs:936-951*/
            val newName = value ?: ""
            _trainerName = newName
            val eventModel = _element.model!!
            val content = EventTemplate.getTrainerContent(eventModel, this) ?: return
            val bytes = ArrayList<Int>(eventModel.textConverter.convert(newName, Ref(false)))
            while (bytes.size > 12) {
                bytes.removeAt(bytes.size - 1)
                bytes[bytes.size - 1] = 0xFF
            }
            while (bytes.size < 12) bytes.add(0)
            _element.token.changeData(eventModel, content.trainerNameAddress, ByteArray(bytes.size) { i -> bytes[i].toByte() }.asByteList())
            notifyPropertyChanged("trainerName")
            val allTrainers = trainerOptions.allOptions
            if (allTrainers != null) {
                val updated = ArrayList<ComboOption>(allTrainers)
                if (content.trainerIndex >= 0 && content.trainerIndex < updated.size) {
                    updated[content.trainerIndex] = createOption(content.trainerIndex, eventModel[content.trainerClassAddress], newName)
                    trainerOptions.update(updated, content.trainerIndex)
                }
            }
        }
    fun refreshTrainerOptions() { /*@DONE ObjectEventViewModel.RefreshTrainerOptions/1 cs:954-965*/
        val eventModel = _element.model!!
        val trainerTable = eventModel.getTableModel(HardcodeTablesModel.trainerTableName)
        val trainers = eventModel.getOptions(HardcodeTablesModel.trainerTableName)
        if (trainerTable == null) return

        val content = EventTemplate.getTrainerContent(eventModel, this)
        val trainerChoices = ArrayList<ComboOption>()
        for (i in 0 until trainers.size) {
            trainerChoices.add(createOption(i, trainerTable[i].getValue(1), trainers[i]))
        }
        trainerOptions.update(trainerChoices, content?.trainerIndex ?: 0)
    }
    private var trainerBeforeText: TextEditorViewModel? = null
    private var trainerWinText: TextEditorViewModel? = null
    private var trainerAfterText: TextEditorViewModel? = null
    val trainerBeforeTextEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TrainerBeforeTextEditor.get cs:968-968*/
            return createTextEditor({ trainerBeforeText }, { trainerBeforeText = it }, { EventTemplate.getTrainerContent(_element.model!!, this)?.beforeTextPointer }, "trainerBeforeTextEditor")
        }
    val trainerWinTextEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TrainerWinTextEditor.get cs:969-969*/
            return createTextEditor({ trainerWinText }, { trainerWinText = it }, { EventTemplate.getTrainerContent(_element.model!!, this)?.winTextPointer }, "trainerWinTextEditor")
        }
    val trainerAfterTextEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TrainerAfterTextEditor.get cs:970-970*/
            return createTextEditor({ trainerAfterText }, { trainerAfterText = it }, { EventTemplate.getTrainerContent(_element.model!!, this)?.afterTextPointer }, "trainerAfterTextEditor")
        }
    private var teamText: String? = null
    var trainerTeam: String?
        get() { /*@DONE ObjectEventViewModel.TrainerTeam.get cs:974-984*/
            val cached = teamText
            if (cached != null) return cached
            val eventModel = _element.model!!
            val content = EventTemplate.getTrainerContent(eventModel, this) ?: return null
            val address = eventModel.readPointer(content.teamPointer)
            if (address < 0 || address >= eventModel.count) return null
            val run = eventModel.getNextRun(address) as? TrainerPokemonTeamRun ?: return null
            if (run.start != address) return null
            if (teamVisualizations.size == 0) updateTeamVisualizations(run)
            val serialized = run.serializeRun()
            teamText = serialized
            return serialized
        }
        set(value) { /*@DONE ObjectEventViewModel.TrainerTeam.set cs:985-998*/
            teamText = value
            val eventModel = _element.model!!
            val content = EventTemplate.getTrainerContent(eventModel, this) ?: return
            val address = eventModel.readPointer(content.teamPointer)
            if (address < 0 || address >= eventModel.count) return
            val run = eventModel.getNextRun(address) as? TrainerPokemonTeamRun ?: return
            if (run.start != address) return
            val newRun = run.deserializeRun(value ?: "", _element.token, false, false, Ref<List<Int>?>(null))
            eventModel.observeRunWritten(_element.token, newRun)
            if (newRun.start != run.start) dataMoved(this, DataMovedEventArgs("Trainer Team", newRun.start))
            updateTeamVisualizations(newRun)
            notifyPropertyChanged("trainerTeam")
        }
    var teamVisualizations: ObservableCollection<IPixelViewModel> = /*@INITDONE ObjectEventViewModel.TeamVisualizations cs:1001-1001*/ ObservableCollection() /*@ENDINIT*/
        private set
    private fun updateTeamVisualizations(team: TrainerPokemonTeamRun) { /*@DONE ObjectEventViewModel.UpdateTeamVisualizations/1 cs:1003-1008*/
        teamVisualizations.clear()
        for (vis in team.visualizations) {
            teamVisualizations.add(vis)
        }
    }
    private lateinit var _openTrainerData: StubCommand
    val openTrainerData: ICommand
        get() { /*@DONE ObjectEventViewModel.OpenTrainerData.get cs:1011-1015*/
            if (!::_openTrainerData.isInitialized) {
                _openTrainerData = stubCommand({
                    val content = EventTemplate.getTrainerContent(_element.model!!, this)
                    if (content != null) gotoAddress(content.trainerClassAddress - 1)
                })
            }
            return _openTrainerData
        }
    private fun createOption(index: Int, trainerClass: Int, name: String): ComboOption { /*@DONE ObjectEventViewModel.CreateOption/2 cs:1019-1019*/
        return createOption(classOptions, index, trainerClass, name)
    }
    fun getTrainerAutocomplete(line: String, lineIndex: Int, characterIndex: Int): List<AutocompleteItem>? { /*@DONE ObjectEventViewModel.GetTrainerAutocomplete/1 cs:1021-1029*/
        val eventModel = _element.model!!
        val content = EventTemplate.getTrainerContent(eventModel, this) ?: return null
        val address = eventModel.readPointer(content.teamPointer)
        if (address < 0 || address >= eventModel.count) return null
        val run = eventModel.getNextRun(address) as? TrainerPokemonTeamRun ?: return null
        if (run.start != address) return null
        return run.getAutoCompleteOptions(line, lineIndex, characterIndex)
    }
    val showRematchTrainerContent: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowRematchTrainerContent.get cs:1036-1054*/
            if (trainerType == 0) return false
            val eventModel = _element.model!!
            val trainers = eventModel.getTableModel(HardcodeTablesModel.trainerTableName) ?: return false
            val content = EventTemplate.getRematchTrainerContent(eventModel, parser, this) ?: return false
            val table = eventModel.getTableModel(HardcodeTablesModel.rematchTable) ?: eventModel.getTableModel(HardcodeTablesModel.rematchTableRSE) ?: return false
            var rematchIndex = -1
            for (i in 0 until table.size) {
                if (table[i].getValue(0) == content.trainerID) {
                    rematchIndex = i
                    break
                }
            }
            if (rematchIndex == -1) return false
            trainerTeams.clear()
            for (i in 0 until table[rematchIndex].table.elementContent.size) {
                val seg = table[rematchIndex].table.elementContent[i] as? ArrayRunEnumSegment ?: continue
                if (seg.enumName != HardcodeTablesModel.trainerTableName) continue
                val trainerID = table[rematchIndex].getValue(i)
                if (!trainerID.inRange(1, trainers.size)) continue
                trainerTeams.add(TrainerTeamViewModel(eventModel, trainerID, { _element.token }))
            }
            return true
        }
    var trainerTeams: ObservableCollection<TrainerTeamViewModel> = /*@INITDONE ObjectEventViewModel.TrainerTeams cs:1057-1057*/ ObservableCollection() /*@ENDINIT*/
        private set
    fun gotoRematches() { /*@DONE ObjectEventViewModel.GotoRematches/1 cs:1059-1068*/
        val eventModel = _element.model!!
        if (eventModel.getTableModel(HardcodeTablesModel.trainerTableName) == null) return
        val content = EventTemplate.getRematchTrainerContent(eventModel, parser, this) ?: return
        val table = eventModel.getTableModel(HardcodeTablesModel.rematchTable) ?: eventModel.getTableModel(HardcodeTablesModel.rematchTableRSE) ?: return
        var rematchIndex = -1
        for (i in 0 until table.size) {
            if (table[i].getValue(0) == content.trainerID) {
                rematchIndex = i
                break
            }
        }
        if (rematchIndex == -1) return
        gotoAddress(table[rematchIndex].start)
    }
    fun replaceRematchScript() { /*@DONE ObjectEventViewModel.ReplaceRematchScript/1 cs:1070-1100*/
        // TODO replace script with simple trainer script (keep before/during/after battle text if we can)
        val eventModel = _element.model!!
        val content = EventTemplate.getRematchTrainerContent(eventModel, parser, this) ?: return
        var before = "<auto>"
        var win = "<auto>"
        var after = "<auto>"
        if (content.beforeTextPointer != Pointer.null_) before = "<" + content.beforeTextPointer.toHex(6) + ">"
        if (content.winTextPointer != Pointer.null_) win = "<" + content.winTextPointer.toHex(6) + ">"
        if (content.afterTextPointer != Pointer.null_) after = "<" + content.afterTextPointer.toHex(6) + ">"

        /*
           trainerbattle 00 [trainerID] 0 <before> <during>
           loadpointer 0 <after>
           callstd 6
           end
        */
        val nl = "\n"
        val script = StringBuilder()
        script.append("trainerbattle 0 " + content.trainerID + " 0 " + before + " " + win + nl)
        if (before == "<auto>") script.append("{" + nl + "Let's fight!" + nl + "}" + nl)
        if (win == "<auto>") script.append("{" + nl + "You win!" + nl + "}" + nl)
        script.append("loadpointer 0 " + after + nl)
        if (after == "<auto>") script.append("{" + nl + "Later!" + nl + "}" + nl)
        script.append("callstd 6" + nl)
        script.append("end" + nl)
        val scriptText = Ref(script.toString())
        val compiled = parser.compileWithoutErrors(token, eventModel, scriptAddress, scriptText)
        if (compiled != null) token.changeData(eventModel, scriptAddress, compiled.asByteList())
        parser.formatScript<XSERun>(token, eventModel, scriptAddress)

        notifyPropertiesChanged("showRematchTrainerContent",
            "showTrainerContent", "trainerClass", "trainerSprite", "trainerName", "trainerBeforeTextEditor", "trainerAfterTextEditor", "trainerWinTextEditor", "trainerTeam")
    }
    private lateinit var _martContent: Lazy<MartEventContent?>
    val showMartContents: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowMartContents.get cs:1108-1108*/
            return _martContent.value != null
        }
    private var martContentText: String? = null
    var martContent: String?
        get() { /*@DONE ObjectEventViewModel.MartContent.get cs:1113-1120*/
            val cached = martContentText
            if (cached != null) return cached
            val content = _martContent.value ?: return null
            val eventModel = _element.model!!
            val martStart = eventModel.readPointer(content.martPointer)
            val stream = eventModel.getNextRun(martStart) as? IStreamRun ?: return null
            val serialized = stream.serializeRun() ?: return null
            val lines = serialized.splitLines().map { line -> line.trim('"') }
            val joined = lines.joinToString("\n")
            martContentText = joined
            return joined
        }
        set(value) { /*@DONE ObjectEventViewModel.MartContent.set cs:1121-1129*/
            martContentText = value
            val content = _martContent.value ?: return
            val eventModel = _element.model!!
            val martStart = eventModel.readPointer(content.martPointer)
            val stream = eventModel.getNextRun(martStart) as? IStreamRun ?: return
            val newStream = stream.deserializeRun(value ?: "", token, Ref<List<Int>?>(null), Ref<List<Int>?>(null))
            eventModel.observeRunWritten(token, newStream)
            if (newStream.start != stream.start) dataMoved(this, DataMovedEventArgs("Mart", newStream.start))
        }
    private var _martHelloEditor: TextEditorViewModel? = null
    private var _martGoodbyeEditor: TextEditorViewModel? = null
    val martHelloEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.MartHelloEditor.get cs:1133-1133*/
            return createTextEditor({ _martHelloEditor }, { _martHelloEditor = it }, { _martContent.value?.helloPointer }, "martHelloEditor")
        }
    val martGoodbyeEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.MartGoodbyeEditor.get cs:1134-1134*/
            return createTextEditor({ _martGoodbyeEditor }, { _martGoodbyeEditor = it }, { _martContent.value?.goodbyePointer }, "martGoodbyeEditor")
        }
    fun getMartAutocomplete(line: String, lineIndex: Int, characterIndex: Int): List<AutocompleteItem>? { /*@DONE ObjectEventViewModel.GetMartAutocomplete/1 cs:1136-1141*/
        val content = _martContent.value ?: return null
        val eventModel = _element.model!!
        val martStart = eventModel.readPointer(content.martPointer)
        val stream = eventModel.getNextRun(martStart) as? IStreamRun ?: return null
        return stream.getAutoCompleteOptions(line, lineIndex, characterIndex)
    }
    private lateinit var tutorContent: Lazy<TutorEventContent?>
    val showTutorContent: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowTutorContent.get cs:1150-1157*/
            val content = tutorContent.value
            if (content != null && tutorOptions.allOptions == null) {
                val tutorChoices = ComboOption.convert(_element.model!!.getOptions(HardcodeTablesModel.moveTutors))
                if (tutorChoices != null) {
                    tutorOptions.update(tutorChoices, tutorNumber)
                    tutorOptions.bind("selectedIndex") { _, _ -> tutorNumber = tutorOptions.selectedIndex }
                }
            }
            return tutorContent.value != null
        }
    private var tutorInfoEditor: TextEditorViewModel? = null
    private var tutorWhichPokemonEditor: TextEditorViewModel? = null
    private var tutorFailedEditor: TextEditorViewModel? = null
    private var tutorSuccessEditor: TextEditorViewModel? = null
    val tutorInfoText: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TutorInfoText.get cs:1161-1161*/
            return createTextEditor({ tutorInfoEditor }, { tutorInfoEditor = it }, { tutorContent.value?.infoPointer }, "tutorInfoText")
        }
    val tutorWhichPokemonText: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TutorWhichPokemonText.get cs:1162-1162*/
            return createTextEditor({ tutorWhichPokemonEditor }, { tutorWhichPokemonEditor = it }, { tutorContent.value?.whichPokemonPointer }, "tutorWhichPokemonText")
        }
    val tutorFailedText: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TutorFailedText.get cs:1163-1163*/
            return createTextEditor({ tutorFailedEditor }, { tutorFailedEditor = it }, { tutorContent.value?.failedPointer }, "tutorFailedText")
        }
    val tutorSucessText: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TutorSucessText.get cs:1164-1164*/
            return createTextEditor({ tutorSuccessEditor }, { tutorSuccessEditor = it }, { tutorContent.value?.successPointer }, "tutorSucessText")
        }
    var tutorNumber: Int
        get() { /*@DONE ObjectEventViewModel.TutorNumber.get cs:1167-1170*/
            val content = tutorContent.value ?: return -1
            return _element.model!!.readMultiByteValue(content.tutorAddress, 2)
        }
        set(value) { /*@DONE ObjectEventViewModel.TutorNumber.set cs:1171-1174*/
            val content = tutorContent.value ?: return
            _element.model!!.writeMultiByteValue(content.tutorAddress, 2, token, value)
        }
    var tutorOptions: FilteringComboOptions = /*@INITDONE ObjectEventViewModel.TutorOptions cs:1177-1177*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    fun gotoTutors() { /*@DONE ObjectEventViewModel.GotoTutors/1 cs:1179-1179*/
        gotoAddress(_element.model!!.getTableModel(HardcodeTablesModel.moveTutors)!![tutorNumber].start)
    }
    private lateinit var tradeContent: Lazy<TradeEventContent?>
    var tradeOptions: FilteringComboOptions = /*@INITDONE ObjectEventViewModel.TradeOptions cs:1187-1187*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    val showTradeContent: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowTradeContent.get cs:1190-1206*/
            val content = tradeContent.value
            if (content != null && tradeOptions.allOptions == null) {
                val eventModel = _element.model!!
                val pokenames = eventModel.getOptions(HardcodeTablesModel.pokemonNameTable)
                val tradeNames = ArrayList<String>()
                val trades = eventModel.getTableModel(HardcodeTablesModel.tradeTable)
                if (trades != null) {
                    for (trade in trades) {
                        val receive = Ref(0)
                        val give = Ref(0)
                        if (!trade.tryGetValue("receive", receive) || !trade.tryGetValue("give", give)) {
                            tradeNames.add(tradeNames.size.toString())
                        } else {
                            val giveName = if (give.value >= 0 && give.value < pokenames.size) pokenames[give.value] else give.value.toString()
                            val receiveName = if (receive.value >= 0 && receive.value < pokenames.size) pokenames[receive.value] else receive.value.toString()
                            tradeNames.add(giveName + " -> " + receiveName)
                        }
                    }
                }
                val tradeChoices = ComboOption.convert(tradeNames)
                if (tradeChoices != null) {
                    tradeOptions.update(tradeChoices, tradeIndex)
                    tradeOptions.bind("selectedIndex") { _, _ -> tradeIndex = tradeOptions.selectedIndex }
                }
            }
            return tradeContent.value != null
        }
    private var tradeInitialText: TextEditorViewModel? = null
    private var tradeThanksText: TextEditorViewModel? = null
    private var tradeSuccessText: TextEditorViewModel? = null
    private var tradeFailedText: TextEditorViewModel? = null
    private var tradeWrongSpeciesText: TextEditorViewModel? = null
    val tradeInitialEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TradeInitialEditor.get cs:1210-1210*/
            return createTextEditor({ tradeInitialText }, { tradeInitialText = it }, { tradeContent.value?.infoPointer }, "tradeInitialEditor")
        }
    val tradeThanksEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TradeThanksEditor.get cs:1211-1211*/
            return createTextEditor({ tradeThanksText }, { tradeThanksText = it }, { tradeContent.value?.thanksPointer }, "tradeThanksEditor")
        }
    val tradeSuccessEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TradeSuccessEditor.get cs:1212-1212*/
            return createTextEditor({ tradeSuccessText }, { tradeSuccessText = it }, { tradeContent.value?.successPointer }, "tradeSuccessEditor")
        }
    val tradeFailedEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TradeFailedEditor.get cs:1213-1213*/
            return createTextEditor({ tradeFailedText }, { tradeFailedText = it }, { tradeContent.value?.failedPointer }, "tradeFailedEditor")
        }
    val tradeWrongSpeciesEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.TradeWrongSpeciesEditor.get cs:1214-1214*/
            return createTextEditor({ tradeWrongSpeciesText }, { tradeWrongSpeciesText = it }, { tradeContent.value?.wrongSpeciesPointer }, "tradeWrongSpeciesEditor")
        }
    var tradeIndex: Int
        get() { /*@DONE ObjectEventViewModel.TradeIndex.get cs:1217-1220*/
            val content = tradeContent.value ?: return -1
            return _element.model!!.readMultiByteValue(content.tradeAddress, 2)
        }
        set(value) { /*@DONE ObjectEventViewModel.TradeIndex.set cs:1221-1224*/
            val content = tradeContent.value ?: return
            _element.model!!.writeMultiByteValue(content.tradeAddress, 2, token, value)
        }
    fun gotoTrades() { /*@DONE ObjectEventViewModel.GotoTrades/1 cs:1227-1227*/
        gotoAddress(_element.model!!.getTableModel(HardcodeTablesModel.tradeTable)!![tradeIndex].start)
    }
    private lateinit var legendaryContent: Lazy<LegendaryEventContent?>
    val showLegendaryContent: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowLegendaryContent.get cs:1236-1253*/
            val content = legendaryContent.value
            val eventModel = _element.model!!
            if (content != null && pokemonOptions.allOptions == null) {
                val pokemonChoices = ComboOption.convert(eventModel.getOptions(HardcodeTablesModel.pokemonNameTable))
                if (pokemonChoices != null) {
                    pokemonOptions.update(pokemonChoices, eventModel.readMultiByteValue(content.setWildBattle + 1, 2))
                    pokemonOptions.bind("selectedIndex") { _, _ ->
                        eventModel.writeMultiByteValue(content.cry + 1, 2, _element.token, pokemonOptions.selectedIndex)
                        eventModel.writeMultiByteValue(content.setWildBattle + 1, 2, _element.token, pokemonOptions.selectedIndex)
                        for (buffer in content.bufferPokemon ?: emptyList()) eventModel.writeMultiByteValue(buffer + 2, 2, _element.token, pokemonOptions.selectedIndex)
                    }
                }
            }
            if (content != null && holdItemOptions.allOptions == null) {
                val itemChoices = ComboOption.convert(eventModel.getOptions(HardcodeTablesModel.itemsTableName))
                if (itemChoices != null) {
                    holdItemOptions.update(itemChoices, eventModel.readMultiByteValue(content.setWildBattle + 4, 2))
                    holdItemOptions.bind("selectedIndex") { _, _ -> eventModel.writeMultiByteValue(content.setWildBattle + 4, 2, _element.token, holdItemOptions.selectedIndex) }
                }
            }
            return content != null
        }
    var pokemonOptions: FilteringComboOptions = /*@INITDONE ObjectEventViewModel.PokemonOptions cs:1256-1256*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    fun gotoPokemon() { /*@DONE ObjectEventViewModel.GotoPokemon/1 cs:1257-1257*/
        gotoAddress(_element.model!!.getTableModel(HardcodeTablesModel.pokemonNameTable)!![pokemonOptions.selectedIndex].start)
    }
    var level: Int
        get() { /*@DONE ObjectEventViewModel.Level.get cs:1259-1259*/
            val content = legendaryContent.value ?: return -1
            return _element.model!![content.setWildBattle + 3]
        }
        set(value) { /*@DONE ObjectEventViewModel.Level.set cs:1260-1263*/
            val content = legendaryContent.value ?: return
            _element.token.changeData(_element.model!!, content.setWildBattle + 3, value and 0xFF)
        }
    var holdItemOptions: FilteringComboOptions = /*@INITDONE ObjectEventViewModel.HoldItemOptions cs:1265-1265*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    fun gotoHoldItem() { /*@DONE ObjectEventViewModel.GotoHoldItem/1 cs:1266-1266*/
        gotoAddress(_element.model!!.getTableModel(HardcodeTablesModel.itemsTableName)!![holdItemOptions.selectedIndex].start)
    }
    private var _legendaryFlagText: String? = null
    var legendaryFlagText: String?
        get() { /*@DONE ObjectEventViewModel.LegendaryFlagText.get cs:1269-1273*/
            val content = legendaryContent.value ?: return null
            if (_legendaryFlagText == null) {
                val flags = content.setFlag
                if (flags == null || flags.isEmpty()) return null
                _legendaryFlagText = _element.model!!.readMultiByteValue(flags[0] + 1, 2).toHex(4)
            }
            return _legendaryFlagText
        }
        set(value) { /*@DONE ObjectEventViewModel.LegendaryFlagText.set cs:1274-1282*/
            val content = legendaryContent.value ?: return
            _legendaryFlagText = value
            val parsedFlag = Ref(0)
            val flagValue = if ((value ?: "").tryParseHex(parsedFlag)) parsedFlag.value else 0
            for (flag in content.setFlag ?: emptyList()) {
                _element.model!!.writeMultiByteValue(flag + 1, 2, _element.token, flagValue)
            }
            notifyPropertyChanged("legendaryFlagText")
            notifyPropertyChanged("sampleLegendClearScript")
        }
    val hasCryText: Boolean
        get() { /*@DONE ObjectEventViewModel.HasCryText.get cs:1284-1284*/
            return (legendaryContent.value?.cryTextPointer ?: Pointer.null_) != Pointer.null_
        }
    private var cryText: TextEditorViewModel? = null
    val cryEditor: TextEditorViewModel?
        get() { /*@DONE ObjectEventViewModel.CryEditor.get cs:1287-1287*/
            return createTextEditor({ cryText }, { cryText = it }, { legendaryContent.value?.cryTextPointer }, "cryEditor")
        }
    private var _sampleLegendClearScript: TextEditorViewModel? = null
    val sampleLegendClearScript: TextEditorViewModel
        get() { /*@DONE ObjectEventViewModel.SampleLegendClearScript.get cs:1291-1308*/
            val script = "  # somewhere in your script\n" +
                "  if.flag.clear.call 0x" + (legendaryFlagText ?: "") + " <show>\n" +
                "\n" +
                "  # add this at the bottom\n" +
                "show:\n" +
                "  clearflag 0x" + flagText + "\n" +
                "  return"
            var editor = _sampleLegendClearScript
            if (editor == null) {
                editor = TextEditorViewModel()
                editor.lineCommentHeader = "#"
                editor.keywords.add("if.flag.clear.call")
                editor.keywords.add("end")
                editor.keywords.add("clearflag")
                editor.keywords.add("return")
                _sampleLegendClearScript = editor
            }
            editor.content = script
            return editor
        }
    val showBerryContent: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowBerryContent.get cs:1315-1315*/
            return trainerType == 0 && trainerRangeOrBerryID != 0
        }
    val berryText: String
        get() { /*@DONE ObjectEventViewModel.BerryText.get cs:1318-1325*/
            val spot = berries.berryMap[trainerRangeOrBerryID]
            if (spot != null) {
                if (spot.berryID >= 0 && spot.berryID < berries.berryOptions.size) {
                    return berries.berryOptions[spot.berryID]
                }
            }
            return "Unknown"
        }
    fun gotoBerryCode() { /*@DONE ObjectEventViewModel.GotoBerryCode/1 cs:1328-1332*/
        val spot = berries.berryMap[trainerRangeOrBerryID]
        if (spot != null) {
            gotoAddress(spot.address)
        }
    }
    val showNoContent: Boolean
        get() { /*@DONE ObjectEventViewModel.ShowNoContent.get cs:1338-1348*/
            return scriptAddress > 0 && !(
                showItemContents ||
                showNpcText ||
                showTrainerContent ||
                showRematchTrainerContent ||
                showMartContents ||
                showTutorContent ||
                showTradeContent ||
                showLegendaryContent ||
                showBerryContent
            )
        }
    var basicText: ObservableCollection<EventTextViewModel> = /*@INITDONE ObjectEventViewModel.BasicText cs:1350-1350*/ ObservableCollection() /*@ENDINIT*/
        private set
    var basicItemAddresses: ObservableCollection<Int> = /*@INITDONE ObjectEventViewModel.BasicItemAddresses cs:1351-1351*/ ObservableCollection() /*@ENDINIT*/
        private set
    var basicFlagAddresses: ObservableCollection<Int> = /*@INITDONE ObjectEventViewModel.BasicFlagAddresses cs:1352-1352*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _basicFlag: Int = /*@INITAUTO ObjectEventViewModel.basicFlag cs:1353-1353*/ -1 /*@ENDINIT*/
    var basicItem: FilteringComboOptions = /*@INITDONE ObjectEventViewModel.BasicItem cs:1354-1354*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    val hasBasicItem: Boolean
        get() { /*@DONE ObjectEventViewModel.HasBasicItem.get cs:1355-1355*/
            return (basicItem.allOptions?.size ?: 0) > 0
        }
    var basicFlag: Int
        get() { /*@DONE ObjectEventViewModel.BasicFlag.get cs:1356-1356*/
            return _basicFlag
        }
        set(value) { /*@DONE ObjectEventViewModel.BasicFlag.set cs:1356-1356*/
            set(_basicFlag, value, "basicFlag", { _basicFlag = it }) { old -> notifyPropertyChanged("hasBasicFlag") }
        }
    val hasBasicFlag: Boolean
        get() { /*@DONE ObjectEventViewModel.HasBasicFlag.get cs:1357-1357*/
            return _basicFlag != -1
        }
    private var _basicFlagText: String = /*@INITAUTO ObjectEventViewModel.basicFlagText cs:1358-1358*/ "" /*@ENDINIT*/
    var basicFlagText: String
        get() { /*@DONE ObjectEventViewModel.BasicFlagText.get cs:1360-1360*/
            return _basicFlagText
        }
        set(value) { /*@DONE ObjectEventViewModel.BasicFlagText.set cs:1361-1366*/
            set(_basicFlagText, value, "basicFlagText", { _basicFlagText = it }) { old ->
                val result = Ref(0)
                if (_basicFlagText.tryParseHex(result)) {
                    for (address in basicFlagAddresses) _element.model!!.writeMultiByteValue(address, 2, token, result.value)
                    _basicFlag = result.value
                    notifyPropertyChanged("basicFlag")
                }
            }
        }
    private fun fillBasicContent() { /*@DONE ObjectEventViewModel.FillBasicContent/1 cs:1369-1429*/
        val eventModel = _element.model!!
        // text
        basicText.clear()
        for (spot in Flags.getAllScriptSpots(eventModel, parser, listOf(scriptAddress), 0x0F)) {
            val textViewModel = EventTextViewModel()
            textViewModel.pointerAddress = spot.address + 2
            textViewModel.text.content = getText(spot.address + 2) ?: ""
            textViewModel.text.bind("content") { editor, _ ->
                val newStart = setText(spot.address + 2, editor.content, "Unknown", "basicText")
                if (newStart != -1) textViewModel.pointerAddress = newStart
            }
            basicText.add(textViewModel)
        }

        // items
        basicItemAddresses.clear()
        val filter = ArrayList<Int>()
        for (line in parser.dependsOn(HardcodeTablesModel.itemsTableName)) {
            if (line is MacroScriptLine) {
                val firstArg = line.args.firstOrNull()
                if (firstArg is SilentMatchArg) filter.add(firstArg.expectedValue)
            }
            if (line is ScriptLine) filter.add(line.lineCode[0])
        }
        val itemSpots = ArrayList<Int>()
        var item = -1
        for (spot in Flags.getAllScriptSpots(eventModel, parser, listOf(scriptAddress), true, *filter.toIntArray())) {
            val offset = spot.address + spot.line.args.until { arg -> arg.enumTableName == HardcodeTablesModel.itemsTableName }.sumOf { arg -> arg.length(eventModel, -1) } + spot.line.lineCode.count
            val chosenItem = eventModel.readMultiByteValue(offset, 2)
            if (item == -1 || item == chosenItem) {
                item = chosenItem
                itemSpots.add(offset)
            } else {
                itemSpots.clear()
                break
            }
        }
        if (itemSpots.size > 0) {
            basicItem.update(ComboOption.convert(eventModel.getOptions(HardcodeTablesModel.itemsTableName)) ?: emptyList(), item)
            for (address in itemSpots.distinct()) basicItemAddresses.add(address)
            basicItem.bind("selectedIndex") { sender, _ ->
                for (address in basicItemAddresses) eventModel.writeMultiByteValue(address, 2, token, sender.selectedIndex)
            }
        }

        // flags
        basicFlagAddresses.clear()
        val flagSpots = ArrayList<Int>()
        var flag = -1
        for (spot in Flags.getAllScriptSpots(eventModel, parser, listOf(scriptAddress), false, 0x29, 0x2A, 0x2B)) { // setflag, clearflag, checkflag
            val offset = spot.address + 1
            val chosenFlag = eventModel.readMultiByteValue(offset, 2)
            if (flag == -1 || flag == chosenFlag) {
                flag = chosenFlag
                flagSpots.add(offset)
            } else {
                flagSpots.clear()
                break
            }
        }
        if (flagSpots.size > 0) {
            basicFlag = flag
            for (address in flagSpots.distinct()) basicFlagAddresses.add(address)
            _basicFlagText = flag.toHex(4)
        }
    }
    private fun getText(cache: Ref<String?>, pointer: Int?): String? { /*@DONE ObjectEventViewModel.GetText/1 cs:1433-1437*/
        val current = cache.value
        if (current != null) return current
        if (pointer == null) return null
        val text = super.getText(pointer)
        cache.value = text
        return text
    }
    private fun setText(cache: Ref<String>, pointer: Int?, value: String, type: String, propertyName: String? = null) { /*@DONE ObjectEventViewModel.SetText/1 cs:1439-1444*/
        cache.value = value
        if (pointer == null) return
        val newStart = super.setText(pointer, value, propertyName)
        if (newStart != -1) dataMoved(this, DataMovedEventArgs(type, newStart))
    }
    private fun getText(pointer: Int?): String? { /*@DONE ObjectEventViewModel.GetText/2 cs:1446-1449*/
        if (pointer == null) return null
        return super.getText(pointer)
    }
    private fun setText(pointer: Int?, value: String, type: String, propertyName: String? = null): Int { /*@DONE ObjectEventViewModel.SetText/2 cs:1451-1456*/
        if (pointer == null) return -1
        val newStart = super.setText(pointer, value, propertyName)
        if (newStart != -1) dataMoved(this, DataMovedEventArgs(type, newStart))
        return newStart
    }
    constructor(parent: BlockMapViewModel, gotoAddress: (Int) -> Unit, objectEvent: ModelArrayElement, eventTemplate: EventTemplate, sprites: List<IPixelViewModel>, defaultSprite: IPixelViewModel, berries: BerryInfo) : super(objectEvent, "objectCount") { /*@DONE ObjectEventViewModel.<init>/1 cs:1460-1499*/
        this.parent = parent
        this.parser = parent.viewPort.tools!!.codeTool!!.scriptParser
        this.gotoAddress = gotoAddress
        this.eventTemplate = eventTemplate
        this.berries = berries
        for (i in 0 until sprites.size) options.add(VisualComboOption.createFromSprite(i.toString(), sprites[i].pixelData, sprites[i].pixelWidth, i, 2.0, true))
        defaultOW = defaultSprite
        showGraphicsAsText = graphics >= options.size
        val objectModel = objectEvent.model!!
        val facingList = Ref<ValidationList?>(null)
        objectModel.tryGetList("FacingOptions", facingList)
        facingOptions.update(ComboOption.convert(facingList.value ?: emptyList()) ?: emptyList(), moveType)
        facingOptions.bind("selectedIndex") { _, _ -> moveType = facingOptions.modelValue }
        for (className in objectModel.getOptions(HardcodeTablesModel.trainerClassNamesTable)) classOptions.add(className)
        itemOptions.update(ComboOption.convert(objectModel.getOptions(HardcodeTablesModel.itemsTableName)) ?: emptyList(), itemContents)
        itemOptions.bind("selectedIndex") { _, _ -> itemContents = itemOptions.modelValue }

        refreshTrainerOptions()
        trainerOptions.bind("selectedIndex") { _, _ ->
            this.eventTemplate.useTrainerFlag(trainerOptions.selectedIndex)
            val currentTrainerContent = EventTemplate.getTrainerContent(_element.model!!, this)
            if (currentTrainerContent != null) {
                _element.model!!.writeMultiByteValue(currentTrainerContent.trainerIndexAddress, 2, { _element.token }, trainerOptions.selectedIndex)
            }
            teamVisualizations.clear()
            _trainerSprite = null
            _trainerName = null
            teamText = null
            trainerBeforeText = null
            trainerWinText = null
            trainerAfterText = null
            notifyPropertiesChanged("trainerSprite", "trainerName", "trainerBeforeTextEditor", "trainerWinTextEditor", "trainerAfterTextEditor", "trainerTeam", "trainerClass")
        }

        createContentLazies()
        if (showNoContent) fillBasicContent()

        updateScriptError(scriptAddress)

        trainerContent.preFormatter = TrainerTextFormatter(objectModel)
        trainerContent.content = trainerTeam ?: ""
        trainerContent.bind("content") { sender, _ -> trainerTeam = sender.content }
    }
    override val topOffset: Int
        get() { /*@DONE ObjectEventViewModel.TopOffset.get cs:1501-1501*/
            return 16 - (eventRender?.pixelHeight ?: 0)
        }
    override val leftOffset: Int
        get() { /*@DONE ObjectEventViewModel.LeftOffset.get cs:1502-1502*/
            return (16 - (eventRender?.pixelWidth ?: 0)) / 2
        }
    override fun render(model: IDataModel, layout: LayoutModel) { /*@DONE ObjectEventViewModel.Render/1 cs:1504-1516*/
        val ows = model.getTable(HardcodeTablesModel.overworldSprites)
        val owTable = if (ows == null) null else ModelTable(model, ows.start)
        val facing = when (moveType) {
            7 -> 1
            9 -> 2
            10 -> 3
            76 -> 76 // invisible
            else -> 0
        }
        eventRender = render(model, owTable, defaultOW, graphics, facing) { pullValueFromTransitionScript() }
        notifyPropertyChanged("eventRender")
    }
    fun clearUnused() { /*@DONE ObjectEventViewModel.ClearUnused/1 cs:1581-1584*/
        _element.setValue(2, 0)
        _element.setValue(12, 0)
    }
    fun shouldHighlight(x: Int, y: Int): Boolean { /*@DONE ObjectEventViewModel.ShouldHighlight/1 cs:1592-1604*/
        fun sgn(v: Int): Int = if (v > 0) 1 else if (v < 0) -1 else 0
        fun absolute(v: Int): Int = if (v < 0) -v else v
        val vector = facingVectors[moveType]
        if (trainerType != 0 && vector != null) {
            val xx = this.x
            val yy = this.y
            val range = trainerRangeOrBerryID
            if (sgn(y - yy) == vector.y && sgn(x - xx) == vector.x && absolute(y - yy) <= range && absolute(x - xx) <= range) {
                return true
            }
        } else {
            if (!moveType.isAny(2, 3, 4, 5, 6)) return false
            if (absolute(x - this.x) <= rangeX && absolute(y - this.y) <= rangeY) return true
        }
        return false
    }
    private fun setDestinationFormat() { /*@DONE ObjectEventViewModel.SetDestinationFormat/1 cs:1606-1611*/
        val eventModel = _element.model!!
        val existingRun = eventModel.getNextRun(scriptAddress)
        if (existingRun != null && existingRun.start == scriptAddress && existingRun is NoInfoRun) {
            eventModel.observeRunWritten(token, XSERun(scriptAddress))
        }
    }
    private fun createTextEditor(getField: () -> TextEditorViewModel?, setField: (TextEditorViewModel?) -> Unit, source: () -> Int?, propertyName: String? = null): TextEditorViewModel? { /*@DONE ObjectEventViewModel.CreateTextEditor/1 cs:1613-1623*/
        val existing = getField()
        if (existing != null) return existing
        val text = getText(source()) ?: return null
        val newEditor = TextEditorViewModel(false)
        newEditor.content = text
        newEditor.bind("content") { editor, _ ->
            setText(source(), editor.content, "Text", propertyName)
            updateTextErrorContent(editor)
        }
        val updated = updateTextErrorContent(newEditor)
        setField(updated)
        return updated
    }
    private fun updateTextErrorContent(editor: TextEditorViewModel): TextEditorViewModel { /*@DONE ObjectEventViewModel.UpdateTextErrorContent/1 cs:1625-1629*/
        editor.errorLocations.clear()
        editor.errorLocations.addRange(_element.model!!.textConverter.getOverflow(editor.content, CodeBody.maxEventTextWidth))
        return editor
    }
    companion object {
        fun createOption(classOptions: List<String>, index: Int, trainerClass: Int, name: String): ComboOption { /*@DONE ObjectEventViewModel.CreateOption/1 cs:1017-1017*/
            val className = if (classOptions.isEmpty()) "" else classOptions[trainerClass.limitToRange(0, classOptions.size - 1)]
            return ComboOption("" + index + " - " + className + " " + name, index)
        }
        fun render(model: IDataModel, owTable: ModelTable?, defaultOW: IPixelViewModel, index: Int, facing: Int, dynamicSprites: () -> Int): IPixelViewModel { /*@DONE ObjectEventViewModel.Render/2 cs:1519-1579*/
            var spriteIndex = index
            var facingIndex = facing
            // special case: gfx variables
            if (spriteIndex >= 240 && spriteIndex <= 255) {
                val fromScript = dynamicSprites()
                if (fromScript > -1) spriteIndex = fromScript
            }

            // special case: expanded OWs for pokemon / sprites20k (HMA expansion utility integration)
            val dataTable: ModelTable?
            if (spriteIndex.inRange(10000, 20000)) {
                dataTable = model.getTableModel("graphics.overworld.pokemon")
                spriteIndex -= 10000
            } else if (spriteIndex.inRange(20000, 30000)) {
                dataTable = model.getTableModel("graphics.overworld.sprites20k")
                spriteIndex -= 20000
            } else {
                if (owTable == null || spriteIndex >= owTable.size) return defaultOW
                dataTable = owTable[spriteIndex].getSubTable("data")
                spriteIndex = 0
            }

            if (dataTable == null) return defaultOW
            if (spriteIndex >= dataTable.size) return defaultOW
            val data = dataTable[spriteIndex]
            val sprites = data.getSubTable("sprites")

            var graphicsAddress: Int
            var invisible = false
            var flip = false
            if (sprites == null) {
                // overworld.pokemon
                graphicsAddress = data.getAddress("sprite")
                if (graphicsAddress == Pointer.null_) return defaultOW
            } else {
                // overworld.sprites or overworld.sprites20k
                invisible = facingIndex == 76
                flip = facingIndex == 3
                if (facingIndex == 3) facingIndex = 2
                if (facingIndex >= sprites.size) facingIndex = 0
                graphicsAddress = sprites.run.start
            }

            val pointerAddress = data.start
            var graphicsRun = model.getNextRun(graphicsAddress) as? ISpriteRun
            val paletteRun = graphicsRun.findRelatedPalettes(model, pointerAddress).firstOrNull()
            if (facingIndex != -1 && sprites != null) {
                val sprite = sprites[facingIndex]
                graphicsAddress = sprite.getAddress("sprite")
                graphicsRun = model.getNextRun(graphicsAddress) as? ISpriteRun
            }
            if (graphicsRun == null) return defaultOW
            if (paletteRun == null) return defaultOW
            var ow: IPixelViewModel = ReadonlyPixelViewModel.create(model, graphicsRun, paletteRun, true) ?: return defaultOW
            if (sprites == null) ow = ReadonlyPixelViewModel.crop(ow, 0, 0, ow.pixelWidth, ow.pixelHeight / 2)
            if (invisible) ow = buildInvisibleEventRender(ow)
            if (flip) ow = ow.reflectX()
            return ow
        }
        private val facingVectors: MutableMap<Int, Point> = /*@INITDONE ObjectEventViewModel.facingVectors cs:1586-1591*/ mutableMapOf(7 to Point(0, -1), 8 to Point(0, 1), 9 to Point(-1, 0), 10 to Point(1, 0)) /*@ENDINIT*/
        /*@END ObjectEventViewModel.Companion*/
    }
    /*@ADD ObjectEventViewModel#ievent_c.txt*/
    private fun createContentLazies() {
        tutorContent = lazy { EventTemplate.getTutorContent(_element.model!!, parser, this) }
        _martContent = lazy { EventTemplate.getMartContent(_element.model!!, parser, this) }
        tradeContent = lazy { EventTemplate.getTradeContent(_element.model!!, parser, scriptAddress) }
        legendaryContent = lazy { EventTemplate.getLegendaryEventContent(_element.model!!, parser, this) }
    }

    private fun resetScriptDependentCaches() {
        _trainerSprite = null
        _npcTextEditor = null
        trainerAfterText = null
        trainerBeforeText = null
        trainerWinText = null
        _martHelloEditor = null
        _martGoodbyeEditor = null
        tutorFailedEditor = null
        tutorInfoEditor = null
        tutorSuccessEditor = null
        tutorWhichPokemonEditor = null
        tradeFailedText = null
        tradeInitialText = null
        tradeSuccessText = null
        tradeThanksText = null
        cryText = null
        _sampleLegendClearScript = null
        createContentLazies()
    }
    /*@ENDADD ObjectEventViewModel#ievent_c.txt*/
    /*@END ObjectEventViewModel*/
}

open class WarpEventViewModel : BaseEventViewModel { // cs:1632-1717
    private lateinit var gotoMap: (Int, Int) -> Unit
    constructor(warpEvent: ModelArrayElement, gotoMap: (Int, Int) -> Unit) : super(warpEvent, "warpCount") { /*@DONE WarpEventViewModel.<init>/1 cs:1635-1635*/
        this.gotoMap = gotoMap
    }
    var warpID: Int
        get() { /*@DONE WarpEventViewModel.WarpID.get cs:1638-1638*/
            return _element.getValue("warpID") + 1
        }
        set(value) { /*@DONE WarpEventViewModel.WarpID.set cs:1639-1639*/
            _element.setValue("warpID", value - 1)
        }
    var bank: Int
        get() { /*@DONE WarpEventViewModel.Bank.get cs:1645-1645*/
            return _element.getValue("bank")
        }
        set(value) { /*@DONE WarpEventViewModel.Bank.set cs:1646-1651*/
            _element.setValue("bank", value)
            notifyPropertyChanged("bank")
            if (!ignoreUpdateBankMap) _bankMap = null
            notifyPropertiesChanged("bankMap", "targetMapName", "canGotoBankMap")
        }
    var map: Int
        get() { /*@DONE WarpEventViewModel.Map.get cs:1655-1655*/
            return _element.getValue("map")
        }
        set(value) { /*@DONE WarpEventViewModel.Map.set cs:1656-1661*/
            _element.setValue("map", value)
            notifyPropertyChanged("map")
            if (!ignoreUpdateBankMap) _bankMap = null
            notifyPropertiesChanged("bankMap", "targetMapName", "canGotoBankMap")
        }
    private var ignoreUpdateBankMap: Boolean = false
    private var _bankMap: String? = null
    var bankMap: String
        get() { /*@DONE WarpEventViewModel.BankMap.get cs:1667-1670*/
            var current = _bankMap
            if (current == null) {
                current = "(" + bank + ", " + map + ")"
                _bankMap = current
            }
            return current
        }
        set(value) { /*@DONE WarpEventViewModel.BankMap.set cs:1671-1680*/
            _bankMap = value
            val parts = value.split(',', ' ', '(', ')').filter { part -> part.isNotEmpty() }
            if (parts.size != 2) return
            ignoreUpdateBankMap = true
            val parsedBank = Ref(0)
            val parsedMap = Ref(0)
            if (parts[0].tryParseInt(parsedBank)) bank = parsedBank.value
            if (parts[1].tryParseInt(parsedMap)) map = parsedMap.value
            ignoreUpdateBankMap = false
            notifyPropertyChanged("canGotoBankMap")
        }
    val targetMapName: String
        get() { /*@DONE WarpEventViewModel.TargetMapName.get cs:1683-1683*/
            return BlockMapViewModel.mapIDToText(_element.model!!, bank, map)
        }
    val warpModel: WarpEventModel
        get() { /*@DONE WarpEventViewModel.WarpModel.get cs:1685-1685*/
            return WarpEventModel(_element)
        }
    val canGotoBankMap: Boolean
        get() { /*@DONE WarpEventViewModel.CanGotoBankMap.get cs:1687-1687*/
            val maps = AllMapsModel.create(_element.model!!)
            if (bank < 0 || map < 0 || maps.count <= bank) return false
            val bankModel = maps[bank] ?: return false
            return bankModel.count > map
        }
    fun gotoBankMap() { /*@DONE WarpEventViewModel.GotoBankMap/1 cs:1688-1688*/
        gotoMap(bank, map)
    }
    override fun render(model: IDataModel, layout: LayoutModel) { /*@DONE WarpEventViewModel.Render/1 cs:1692-1698*/
        if (warpIsOnWarpableBlock(model, layout)) {
            eventRender = buildEventRender(UncompressedPaletteColor.pack(0, 0, 31))
        } else {
            eventRender = buildEventRender(UncompressedPaletteColor.pack(0, 0, 31), true)
        }
    }
    fun warpIsOnWarpableBlock(model: IDataModel, layout: LayoutModel): Boolean { /*@DONE WarpEventViewModel.WarpIsOnWarpableBlock/1 cs:1700-1716*/
        val behaviors = Ref<ValidationList?>(null)
        if (!model.tryGetList("MapAttributeBehaviors", behaviors)) return false
        val list = behaviors.value ?: return false

        val primaryBlockCount = if (model.isFRLG()) 640 else 512
        if (x < 0 || y < 0 || x >= layout.width || y >= layout.height) return true // failure to read layout, this warp rendering doesn't matter.
        val cell = layout.blockMap[x, y] ?: return true // failure to read layout, this warp rendering doesn't matter.
        var tile = cell.tile
        var blockset = layout.primaryBlockset
        if (tile >= primaryBlockCount) {
            tile -= primaryBlockCount
            blockset = layout.secondaryBlockset
        }

        val attribute = blockset?.attribute(tile) ?: return true
        val behavior = attribute.behavior
        if (list.size <= behavior) return false
        val behaviorName = list[behavior]
        return listOf("Warp", "Door", "Stairs", "Ladder", "Escalator").any { keyword -> behaviorName.contains(keyword) }
    }
    /*@END WarpEventViewModel*/
}

open class ScriptEventViewModel : BaseEventViewModel { // cs:1719-1810
    private lateinit var gotoAddress: (Int) -> Unit
    private lateinit var eventTemplate: EventTemplate
    constructor(gotoAddress: (Int) -> Unit, scriptEvent: ModelArrayElement, eventTemplate: EventTemplate) : super(scriptEvent, "scriptCount") { /*@DONE ScriptEventViewModel.<init>/1 cs:1723-1727*/
        this.gotoAddress = gotoAddress
        this.eventTemplate = eventTemplate
        updateScriptError(scriptAddress)
    }
    var trigger: Int
        get() { /*@DONE ScriptEventViewModel.Trigger.get cs:1730-1730*/
            return _element.getValue("trigger")
        }
        set(value) { /*@DONE ScriptEventViewModel.Trigger.set cs:1731-1731*/
            _element.setValue("trigger", value)
        }
    private var _triggerHex: String? = null
    var triggerHex: String
        get() { /*@DONE ScriptEventViewModel.TriggerHex.get cs:1736-1739*/
            val cached = _triggerHex
            if (cached != null) return cached
            val text = trigger.toHex(4)
            _triggerHex = text
            return text
        }
        set(value) { /*@DONE ScriptEventViewModel.TriggerHex.set cs:1740-1745*/
            _triggerHex = value
            val result = Ref(0)
            if (!value.tryParseHex(result)) return
            trigger = result.value
            notifyPropertyChanged("canGenerateNewTrigger")
        }
    val canGenerateNewTrigger: Boolean
        get() { /*@DONE ScriptEventViewModel.CanGenerateNewTrigger.get cs:1748-1748*/
            return trigger == 0
        }
    fun generateNewTrigger() { /*@DONE ScriptEventViewModel.GenerateNewTrigger/1 cs:1749-1753*/
        trigger = eventTemplate.findNextUnusedVariable()
        _triggerHex = null
        notifyPropertiesChanged("triggerHex", "canGenerateNewTrigger")
    }
    var index: Int
        get() { /*@DONE ScriptEventViewModel.Index.get cs:1756-1756*/
            return _element.getValue("index")
        }
        set(value) { /*@DONE ScriptEventViewModel.Index.set cs:1757-1757*/
            _element.setValue("index", value)
        }
    var scriptAddress: Int
        get() { /*@DONE ScriptEventViewModel.ScriptAddress.get cs:1761-1761*/
            return _element.getAddress("script")
        }
        set(value) { /*@DONE ScriptEventViewModel.ScriptAddress.set cs:1762-1766*/
            _element.setAddress("script", value, false)
            updateScriptError(_element.getAddress("script"))
            notifyPropertiesChanged("scriptAddressText", "canCreateScript")
        }
    fun gotoScript() { /*@DONE ScriptEventViewModel.GotoScript/1 cs:1769-1772*/
        setDestinationFormat()
        gotoAddress(scriptAddress)
    }
    val canCreateScript: Boolean
        get() { /*@DONE ScriptEventViewModel.CanCreateScript.get cs:1774-1774*/
            return isValidScriptFreespace(scriptAddress) || scriptAddress == Pointer.null_
        }
    fun createScript() { /*@DONE ScriptEventViewModel.CreateScript/1 cs:1775-1783*/
        val eventModel = _element.model!!
        val start: Int
        if (scriptAddress != Pointer.null_ && isValidScriptFreespace(scriptAddress)) start = scriptAddress
        else start = eventModel.findFreeSpace(eventModel.freeSpaceStart, 0x10)
        token.changeData(eventModel, start, 2)
        scriptAddress = start
        setDestinationFormat()
        gotoAddress(start)
    }
    private var _scriptAddressText: String? = null
    var scriptAddressText: String
        get() { /*@DONE ScriptEventViewModel.ScriptAddressText.get cs:1787-1791*/
            val cached = _scriptAddressText
            if (cached != null) return cached
            val value = _element.getAddress("script")
            val cache = Ref<String?>(_scriptAddressText)
            val text = getAddressText(value, cache)
            _scriptAddressText = cache.value
            return text
        }
        set(value) { /*@DONE ScriptEventViewModel.ScriptAddressText.set cs:1792-1797*/
            val cache = Ref<String?>(_scriptAddressText)
            setAddressText(value, cache, "script", false)
            _scriptAddressText = cache.value
            notifyPropertyChanged("scriptAddressText")
            notifyPropertiesChanged("scriptAddress", "canCreateScript")
            updateScriptError(scriptAddress)
        }
    override fun render(model: IDataModel, layout: LayoutModel) { /*@DONE ScriptEventViewModel.Render/1 cs:1800-1802*/
        eventRender = buildEventRender(UncompressedPaletteColor.pack(0, 31, 0))
    }
    private fun setDestinationFormat() { /*@DONE ScriptEventViewModel.SetDestinationFormat/1 cs:1804-1809*/
        val eventModel = _element.model!!
        val existingRun = eventModel.getNextRun(scriptAddress)
        if (existingRun != null && existingRun.start == scriptAddress && existingRun is NoInfoRun) {
            eventModel.observeRunWritten(token, XSERun(scriptAddress))
        }
    }
    /*@END ScriptEventViewModel*/
}

open class SignpostEventViewModel : BaseEventViewModel { // cs:1812-2035
    private lateinit var gotoAddress: (Int) -> Unit
    val dataMoved = Event<DataMovedEventArgs>()
    constructor(signpostEvent: ModelArrayElement, gotoAddress: (Int) -> Unit) : super(signpostEvent, "signpostCount") { /*@DONE SignpostEventViewModel.<init>/1 cs:1823-1834*/
        val signModel = signpostEvent.model!!
        val names = Ref<ValidationList?>(null)
        if (signModel.tryGetList("MapSignpostKindOptions", names)) {
            for (kindName in names.value ?: emptyList<String>()) kindOptions.add(kindName)
        }

        for (item in signModel.getOptions(HardcodeTablesModel.itemsTableName)) {
            itemOptions.add(item)
        }

        setDestinationFormat()

        this.gotoAddress = gotoAddress
        if (showPointer) updateScriptError(pointer)
    }
    fun setDestinationFormat() { /*@DONE SignpostEventViewModel.SetDestinationFormat/1 cs:1836-1843*/
        if (!showPointer) return
        val eventModel = _element.model!!
        val destinationRun = XSERun(pointer, SortedSpan.none<Int>())
        val existingRun = eventModel.getNextRun(destinationRun.start) ?: return
        if (existingRun.start < destinationRun.start) return // don't erase existing runs for this
        if (existingRun.start == destinationRun.start && existingRun !is NoInfoRun) return
        eventModel.observeRunWritten(ModelDelta(), destinationRun) // don't track this change
    }
    fun clearDestinationFormat() { /*@DONE SignpostEventViewModel.ClearDestinationFormat/1 cs:1845-1851*/
        if (!showPointer) return
        val destination = pointer
        val eventModel = _element.model!!
        val run = eventModel.getNextRun(destination) ?: return
        val sources = run.pointerSources
        if (run.start != destination || (sources != null && sources.size > 0)) return
        eventModel.clearFormat(_element.token, destination, 1)
    }
    var kindOptions: ObservableCollection<String> = /*@INITDONE SignpostEventViewModel.KindOptions cs:1853-1853*/ ObservableCollection() /*@ENDINIT*/
        private set
    var kind: Int
        get() { /*@DONE SignpostEventViewModel.Kind.get cs:1856-1856*/
            val kindValue = Ref(0)
            return if (_element.tryGetValue("kind", kindValue)) kindValue.value else -1
        }
        set(value) { /*@DONE SignpostEventViewModel.Kind.set cs:1857-1873*/
            clearDestinationFormat()
            val old = _element.getValue("kind")
            _element.setValue("kind", value)
            val wasPointer = old < 5
            val isPointer = value < 5
            notifyPropertiesChanged("showArg", "showPointer", "showHiddenItemProperties")
            if (showHiddenItemProperties) notifyPropertyChanged("itemID")
            setDestinationFormat()
            if (wasPointer == isPointer) return
            _element.setValue("arg", 0)
            _argText = null
            _pointerText = null
            notifyPropertiesChanged(
                "argText", "pointerText", "showSignpostText", "itemID",
                "hiddenItemID", "quantity", "canGotoScript", "canGenerateNewHiddenItemID")
        }
    val showArg: Boolean
        get() { /*@DONE SignpostEventViewModel.ShowArg.get cs:1876-1876*/
            return kind == 8
        }
    private var _argText: String? = null
    var argText: String
        get() { /*@DONE SignpostEventViewModel.ArgText.get cs:1880-1884*/
            val cached = _argText
            if (cached != null) return cached
            val text = _element.getValue("arg").toHex(8)
            _argText = text
            return text
        }
        set(value) { /*@DONE SignpostEventViewModel.ArgText.set cs:1885-1888*/
            _argText = value
            val result = Ref(0)
            if (value.tryParseHex(result)) _element.setValue("arg", result.value)
        }
    val canCreateScript: Boolean
        get() { /*@DONE SignpostEventViewModel.CanCreateScript.get cs:1893-1893*/
            return showPointer && isValidScriptFreespace(pointer)
        }
    fun createScript() { /*@DONE SignpostEventViewModel.CreateScript/1 cs:1894-1903*/
        val eventModel = _element.model!!
        val start: Int
        if (pointer != Pointer.null_ && isValidScriptFreespace(pointer)) start = pointer
        else start = eventModel.findFreeSpace(eventModel.freeSpaceStart, 0x10)
        // 0F 00 <start+9> 09 03 02 FF
        val textStart = start + 9
        token.changeData(eventModel, start, byteArrayOf(0x0F, 0, textStart.toByte(), (textStart shr 8).toByte(), (textStart shr 16).toByte(), ((textStart shr 24) + 8).toByte(), 9, 3, 2, 0xFF.toByte()).asByteList())
        pointer = start
        gotoAddress(start)
    }
    val showPointer: Boolean
        get() { /*@DONE SignpostEventViewModel.ShowPointer.get cs:1905-1905*/
            return kind < 5
        }
    var pointer: Int
        get() { /*@DONE SignpostEventViewModel.Pointer.get cs:1908-1908*/
            return _element.getAddress("arg")
        }
        set(value) { /*@DONE SignpostEventViewModel.Pointer.set cs:1909-1917*/
            clearDestinationFormat()
            _element.setAddress("arg", value, false)
            val run = _element.model!!.getNextRun(pointer)
            if (run != null && run.start == pointer && run is NoInfoRun && !isValidScriptFreespace(pointer)) setDestinationFormat()
            updateScriptError(_element.getAddress("arg"))
            _pointerText = null
            _argText = null
            notifyPropertiesChanged("pointerText", "argText", "canGotoScript", "canCreateScript")
        }
    private var _pointerText: String? = null
    var pointerText: String
        get() { /*@DONE SignpostEventViewModel.PointerText.get cs:1922-1926*/
            val cached = _pointerText
            if (cached != null) return cached
            val value = _element.getAddress("arg")
            val cache = Ref<String?>(_pointerText)
            val text = getAddressText(value, cache)
            _pointerText = cache.value
            return text
        }
        set(value) { /*@DONE SignpostEventViewModel.PointerText.set cs:1927-1934*/
            clearDestinationFormat()
            val cache = Ref<String?>(_pointerText)
            setAddressText(value, cache, "arg", false)
            _pointerText = cache.value
            val run = _element.model!!.getNextRun(pointer)
            if (run != null && run.start == pointer && run is NoInfoRun && !isValidScriptFreespace(pointer)) setDestinationFormat()
            notifyPropertiesChanged("pointerText", "pointer", "argText", "canGotoScript", "canCreateScript")
            updateScriptError(pointer)
        }
    val canGotoScript: Boolean
        get() { /*@DONE SignpostEventViewModel.CanGotoScript.get cs:1937-1937*/
            return 0 <= pointer && pointer < _element.model!!.count
        }
    fun gotoScript() { /*@DONE SignpostEventViewModel.GotoScript/1 cs:1938-1942*/
        val run = _element.model!!.getNextRun(pointer)
        if (run != null && run.start == pointer && run is NoInfoRun) setDestinationFormat()
        gotoAddress(pointer)
    }
    val showHiddenItemProperties: Boolean
        get() { /*@DONE SignpostEventViewModel.ShowHiddenItemProperties.get cs:1948-1948*/
            return kind >= 5 && kind <= 7
        }
    var itemOptions: ObservableCollection<String> = /*@INITDONE SignpostEventViewModel.ItemOptions cs:1953-1953*/ ObservableCollection() /*@ENDINIT*/
        private set
    var itemID: Int
        get() { /*@DONE SignpostEventViewModel.ItemID.get cs:1956-1956*/
            return _element.model!!.readMultiByteValue(_element.start + 8, 2)
        }
        set(value) { /*@DONE SignpostEventViewModel.ItemID.set cs:1957-1960*/
            _element.model!!.writeMultiByteValue(_element.start + 8, 2, _element.token, value)
            notifyPropertyChanged("itemID")
        }
    var hiddenItemID: Int
        get() { /*@DONE SignpostEventViewModel.HiddenItemID.get cs:1964-1964*/
            return _element.model!![_element.start + 10]
        }
        set(value) { /*@DONE SignpostEventViewModel.HiddenItemID.set cs:1965-1968*/
            _element.token.changeData(_element.model!!, _element.start + 10, value and 0xFF)
            notifyPropertyChanged("canGenerateNewHiddenItemID")
        }
    var quantity: Int
        get() { /*@DONE SignpostEventViewModel.Quantity.get cs:1972-1972*/
            return _element.model!![_element.start + 11] and 0x7F
        }
        set(value) { /*@DONE SignpostEventViewModel.Quantity.set cs:1973-1979*/
            var newValue = value.limitToRange(0, 0x7F)
            val previous = _element.model!![_element.start + 11]
            newValue = newValue or (previous and 0x80)
            token.changeData(_element.model!!, _element.start + 11, newValue)
            notifyPropertyChanged("quantity")
        }
    var isUnderFoot: Boolean
        get() { /*@DONE SignpostEventViewModel.IsUnderFoot.get cs:1983-1983*/
            return _element.model!![_element.start + 11] >= 0x80
        }
        set(value) { /*@DONE SignpostEventViewModel.IsUnderFoot.set cs:1984-1990*/
            var newValue = if (value) 0x80 else 0
            val previous = _element.model!![_element.start + 11]
            newValue = newValue or (previous and 0x7F)
            token.changeData(_element.model!!, _element.start + 11, newValue)
            notifyPropertyChanged("isUnderFoot")
        }
    val canGenerateNewHiddenItemID: Boolean
        get() { /*@DONE SignpostEventViewModel.CanGenerateNewHiddenItemID.get cs:1993-1993*/
            return showHiddenItemProperties && hiddenItemID == 0
        }
    fun generateNewHiddenItemID() { /*@DONE SignpostEventViewModel.GenerateNewHiddenItemID/1 cs:1995-2012*/
        val eventModel = _element.model!!
        val usedIDs = HashSet<Int>()
        for (bank in AllMapsModel.create(eventModel)) {
            for (mapModel in bank) {
                for (signpost in mapModel.events.signposts) {
                    if (!signpost.isHiddenItem) continue
                    val signElement = signpost.element ?: continue
                    usedIDs.add(eventModel[signElement.start + 10])
                }
            }
        }

        var match = 0
        for (i in 1 until 256) {
            if (usedIDs.contains(i)) continue
            match = i
            break
        }

        hiddenItemID = match
        notifyPropertyChanged("hiddenItemID")
    }
    override fun render(model: IDataModel, layout: LayoutModel) { /*@DONE SignpostEventViewModel.Render/1 cs:2016-2018*/
        eventRender = buildEventRender(UncompressedPaletteColor.pack(31, 0, 0))
    }
    val showSignpostText: Boolean
        get() { /*@DONE SignpostEventViewModel.ShowSignpostText.get cs:2020-2020*/
            return EventTemplate.getSignpostTextPointer(_element.model!!, this) != Pointer.null_
        }
    private var _signpostText: String? = null
    var signpostText: String
        get() { /*@DONE SignpostEventViewModel.SignpostText.get cs:2024-2028*/
            val cached = _signpostText
            if (cached != null) return cached
            val text = getText(EventTemplate.getSignpostTextPointer(_element.model!!, this))
            _signpostText = text
            return text ?: ""
        }
        set(value) { /*@DONE SignpostEventViewModel.SignpostText.set cs:2029-2033*/
            _signpostText = value
            val newAddress = setText(EventTemplate.getSignpostTextPointer(_element.model!!, this), value)
            if (newAddress >= 0) dataMoved(this, DataMovedEventArgs("Text", newAddress))
        }
    /*@END SignpostEventViewModel*/
}

open class TrainerTeamViewModel : ViewModelCore { // cs:2037-2113
    private lateinit var model: IDataModel
    private var trainerID: Int = 0
    private lateinit var tokenGenerator: () -> ModelDelta
    val dataMoved = Event<DataMovedEventArgs>()
    constructor(model: IDataModel, trainerID: Int, tokenGenerator: () -> ModelDelta) { /*@DONE TrainerTeamViewModel.<init>/1 cs:2044-2050*/
        this.model = model
        this.trainerID = trainerID
        this.tokenGenerator = tokenGenerator
        trainerContent.preFormatter = TrainerTextFormatter(model)
        trainerContent.content = trainerTeam
        trainerContent.bind("content") { sender, _ -> trainerTeam = sender.content }
    }
    val trainerIDText: String
        get() { /*@DONE TrainerTeamViewModel.TrainerIDText.get cs:2053-2058*/
            val trainerNames = model.getOptions(HardcodeTablesModel.trainerTableName)
            if (trainerID < 0 || trainerID >= trainerNames.size) return ""
            var name = trainerNames[trainerID]
            val splitter = name.indexOf("~")
            if (splitter != -1) name = name.substring(splitter)
            return name
        }
    private var teamText: String? = null
    var trainerTeam: String
        get() { /*@DONE TrainerTeamViewModel.TrainerTeam.get cs:2063-2072*/
            val cached = teamText
            if (cached != null) return cached
            val table = model.getTableModel(HardcodeTablesModel.trainerTableName)
            if (table == null || !trainerID.inRange(0, table.size)) return ""
            val teamAddress = table[trainerID].getAddress("pokemon")
            val team = model.getNextRun(teamAddress) as? TrainerPokemonTeamRun ?: return ""

            if (teamVisualizations.size == 0) updateTeamVisualizations(team)
            val serialized = team.serializeRun()
            teamText = serialized
            return serialized ?: ""
        }
        set(value) { /*@DONE TrainerTeamViewModel.TrainerTeam.set cs:2074-2086*/
            teamText = value
            val table = model.getTableModel(HardcodeTablesModel.trainerTableName)
            if (table == null || !trainerID.inRange(0, table.size)) return
            val teamAddress = table[trainerID].getAddress("pokemon")
            val team = model.getNextRun(teamAddress) as? TrainerPokemonTeamRun ?: return

            val newRun = team.deserializeRun(value, tokenGenerator(), false, false, Ref<List<Int>?>(null))
            model.observeRunWritten(tokenGenerator(), newRun)
            if (newRun.start != team.start) dataMoved(this, DataMovedEventArgs("Trainer Team", newRun.start))
            updateTeamVisualizations(newRun)
            notifyPropertyChanged("trainerTeam")
        }
    var trainerContent: TextEditorViewModel = /*@INITDONE TrainerTeamViewModel.TrainerContent cs:2089-2089*/ TextEditorViewModel() /*@ENDINIT*/
        private set
    var teamVisualizations: ObservableCollection<IPixelViewModel> = /*@INITDONE TrainerTeamViewModel.TeamVisualizations cs:2091-2091*/ ObservableCollection() /*@ENDINIT*/
        private set
    private fun updateTeamVisualizations(team: TrainerPokemonTeamRun) { /*@DONE TrainerTeamViewModel.UpdateTeamVisualizations/1 cs:2093-2098*/
        teamVisualizations.clear()
        for (vis in team.visualizations) {
            teamVisualizations.add(vis)
        }
    }
    fun getTrainerAutocomplete(line: String, lineIndex: Int, characterIndex: Int): List<AutocompleteItem>? { /*@DONE TrainerTeamViewModel.GetTrainerAutocomplete/1 cs:2100-2106*/
        val table = model.getTableModel(HardcodeTablesModel.trainerTableName)
        if (table == null || !trainerID.inRange(0, table.size)) return null
        val teamAddress = table[trainerID].getAddress("pokemon")
        val team = model.getNextRun(teamAddress) as? TrainerPokemonTeamRun ?: return null
        return team.getAutoCompleteOptions(line, lineIndex, characterIndex)
    }
    fun refresh() { /*@DONE TrainerTeamViewModel.Refresh/1 cs:2108-2112*/
        teamText = null
        teamVisualizations.clear()
        notifyPropertyChanged("trainerTeam")
    }
    /*@END TrainerTeamViewModel*/
}
