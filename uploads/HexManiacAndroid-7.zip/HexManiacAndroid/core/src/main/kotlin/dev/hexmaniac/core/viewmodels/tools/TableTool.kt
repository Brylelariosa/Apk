// Port of ViewModels/Tools/TableTool.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.viewmodels.gotoStringComparer
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.map.*

open class TableTool : ViewModelCore, IToolViewModel { // cs:14-683
    private lateinit var model: IDataModel
    private lateinit var selection: Selection
    private lateinit var history: ChangeHistory<ModelDelta>
    private lateinit var viewPort: ViewPort
    private lateinit var toolTray: IToolTrayViewModel
    private lateinit var dispatcher: IWorkDispatcher
    private lateinit var loadMapUsageTimer: IDelayWorkTimer
    private lateinit var dataChangedTimer: IDelayWorkTimer
    override val name: String
        get() { /*@DONE TableTool.Name.get cs:23-23*/
            return "Table"
        }
    val tableSections: List<String>
        get() { /*@DONE TableTool.TableSections.get cs:26-34*/
            val sections = unmatchedArrays.map { array ->
                val parts = model.getAnchorFromAddress(-1, array.start).split('.')
                if (parts.size > 2) parts.take(2).joinToString(".") else parts[0]
            }.distinct().toMutableList()
            sections.sortWith(gotoStringComparer)
            return sections
        }
    private var _selectedTableSection: Int = 0
    var selectedTableSection: Int
        get() { /*@DONE TableTool.SelectedTableSection.get cs:39-39*/
            return _selectedTableSection
        }
        set(value) { /*@DONE TableTool.SelectedTableSection.set cs:40-43*/
            if (dataForCurrentRunChangeUpdate) return // recursion guard: ignore this update if we're about to change it manually
            set(_selectedTableSection, value, "selectedTableSection", { _selectedTableSection = it }, { old -> updateTableList(old) })
        }
    val tableList: List<String>
        get() { /*@DONE TableTool.TableList.get cs:47-57*/
            val sections = tableSections
            if (_selectedTableSection == -1 || _selectedTableSection >= sections.size) return ArrayList()
            val selectedSection = sections[_selectedTableSection]
            val list = unmatchedArrays
                .map { array -> model.getAnchorFromAddress(-1, array.start) }
                .filter { name -> name.startsWith(selectedSection + ".") }
                .map { name -> name.substring(selectedSection.length + 1) }
                .toMutableList()
            list.sortWith(gotoStringComparer)
            return list
        }
    private var _selectedTableIndex: Int = 0
    var selectedTableIndex: Int
        get() { /*@DONE TableTool.SelectedTableIndex.get cs:62-62*/
            return _selectedTableIndex
        }
        set(value) { /*@DONE TableTool.SelectedTableIndex.set cs:63-67*/
            if (!tryUpdate(_selectedTableIndex, value, "selectedTableIndex") { _selectedTableIndex = it }) return
            if (_selectedTableIndex == -1 || dataForCurrentRunChangeUpdate) return
            updateAddressFromSectionAndSelection()
        }
    private fun updateTableList(oldValue: Int = 0) { /*@DONE TableTool.UpdateTableList/1 cs:69-72*/
        notifyPropertyChanged("tableList")
        updateAddressFromSectionAndSelection()
    }
    private fun updateAddressFromSectionAndSelection(oldValue: Int = 0) { /*@DONE TableTool.UpdateAddressFromSectionAndSelection/1 cs:73-82*/
        if (_selectedTableSection == -1 || _selectedTableIndex == -1) return
        var arrayName = tableSections[_selectedTableSection]
        val currentTableList = tableList
        if (_selectedTableIndex >= currentTableList.size) tryUpdate(_selectedTableIndex, 0, "selectedTableIndex") { _selectedTableIndex = it }
        arrayName += "." + currentTableList[_selectedTableIndex]
        val start = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, arrayName)
        selection.gotoAddress(start)
        address = start
    }
    private val unmatchedArrays: List<ITableRun>
        get() { /*@DONE TableTool.UnmatchedArrays.get cs:85-94*/
            val list = ArrayList<ITableRun>()
            for (anchor in model.anchors) {
                val table = model.getTable(anchor)
                if (table == null) continue // skip anything that's not a table
                if (table is ArrayRun && !table.lengthFromAnchor.isNullOrEmpty()) continue // skip 'matched-length' arrays
                list.add(table)
            }
            return list
        }
    private var _currentElementName: String = ""
    var currentElementName: String
        get() { /*@DONE TableTool.CurrentElementName.get cs:99-99*/
            return _currentElementName
        }
        private set(value) { /*@DONE TableTool.CurrentElementName.set cs:100-100*/
            tryUpdate(_currentElementName, value, "currentElementName") { _currentElementName = it }
        }
    lateinit var currentElementSelector: FilteringComboOptions
        private set
    private lateinit var _previous: StubCommand
    private lateinit var _next: StubCommand
    private lateinit var _append: StubCommand
    private lateinit var _incrementAdd: StubCommand
    private lateinit var _decrementAdd: StubCommand
    val previous: ICommand
        get() { /*@DONE TableTool.Previous.get cs:107-107*/
            return _previous
        }
    val next: ICommand
        get() { /*@DONE TableTool.Next.get cs:108-108*/
            return _next
        }
    val append: ICommand
        get() { /*@DONE TableTool.Append.get cs:109-109*/
            return _append
        }
    val incrementAdd: ICommand
        get() { /*@DONE TableTool.IncrementAdd.get cs:110-110*/
            if (!::_incrementAdd.isInitialized) _incrementAdd = stubCommand({ incrementAddExecute() }, { incrementAddCanExecute() })
            return _incrementAdd
        }
    val decrementAdd: ICommand
        get() { /*@DONE TableTool.DecrementAdd.get cs:111-111*/
            if (!::_decrementAdd.isInitialized) _decrementAdd = stubCommand({ decrementAddExecute() }, { decrementAddCanExecute() })
            return _decrementAdd
        }
    private fun commandCanExecuteChanged() { /*@DONE TableTool.CommandCanExecuteChanged/1 cs:112-118*/
        if (::_previous.isInitialized) _previous.raiseCanExecuteChanged()
        if (::_next.isInitialized) _next.raiseCanExecuteChanged()
        if (::_append.isInitialized) _append.raiseCanExecuteChanged()
        if (::_incrementAdd.isInitialized) _incrementAdd.raiseCanExecuteChanged()
        if (::_decrementAdd.isInitialized) _decrementAdd.raiseCanExecuteChanged()
    }
    private fun incrementAddExecute() { /*@DONE TableTool.IncrementAddExecute/1 cs:119-119*/
        addCount += 1
        commandCanExecuteChanged()
    }
    private fun decrementAddExecute() { /*@DONE TableTool.DecrementAddExecute/1 cs:120-120*/
        addCount -= 1
        commandCanExecuteChanged()
    }
    private fun incrementAddCanExecute(): Boolean { /*@DONE TableTool.IncrementAddCanExecute/1 cs:121-121*/
        return _append.canExecute(null) && _addCount < 500
    }
    private fun decrementAddCanExecute(): Boolean { /*@DONE TableTool.DecrementAddCanExecute/1 cs:122-122*/
        return _append.canExecute(null) && _addCount > 1
    }
    private var _addCount: Int = /*@INITAUTO TableTool.addCount cs:124-124*/ 1 /*@ENDINIT*/
    var addCount: Int
        get() { /*@DONE TableTool.AddCount.get cs:126-126*/
            return _addCount
        }
        set(value) { /*@DONE TableTool.AddCount.set cs:127-130*/
            val limited = Math.min(Math.max(1, value), 500)
            set(_addCount, limited, "addCount", { _addCount = it }, { _ -> commandCanExecuteChanged() })
        }
    private var _useMultiFieldFeature: Boolean = /*@INITAUTO TableTool.useMultiFieldFeature cs:133-133*/ false /*@ENDINIT*/
    var useMultiFieldFeature: Boolean
        get() { /*@DONE TableTool.UseMultiFieldFeature.get cs:135-135*/
            return _useMultiFieldFeature
        }
        set(value) { /*@DONE TableTool.UseMultiFieldFeature.set cs:136-139*/
            set(_useMultiFieldFeature, value, "useMultiFieldFeature", { _useMultiFieldFeature = it }, { _ ->
                for (group in groups) group.useMultiFieldFeature = _useMultiFieldFeature
                dataForCurrentRunChanged()
            })
        }
    var usageChildren: ObservableCollection<IArrayElementViewModel> = ObservableCollection()
        private set
    var groups: ObservableCollection<TableGroupViewModel> = ObservableCollection()
        private set
    private var _address: Int = /*@INITDONE TableTool.address cs:146-146*/ Pointer.null_ /*@ENDINIT*/
    var address: Int
        get() { /*@DONE TableTool.Address.get cs:148-148*/
            return _address
        }
        set(value) { /*@DONE TableTool.Address.set cs:149-162*/
            if (tryUpdate(_address, value, "address") { _address = it }) {
                val run = model.getNextRun(value) ?: NoInfoRun.nullRun
                if (run.start > value || run !is ITableRun) {
                    enabled = false
                    commandCanExecuteChanged()
                    return
                }

                commandCanExecuteChanged()
                enabled = true
                toolTray.schedule(this::dataForCurrentRunChanged)
            }
        }
    private var _enabled: Boolean = false
    var enabled: Boolean
        get() { /*@DONE TableTool.Enabled.get cs:167-167*/
            return _enabled
        }
        private set(value) { /*@DONE TableTool.Enabled.set cs:168-168*/
            tryUpdate(_enabled, value, "enabled") { _enabled = it }
        }
    private var _usageOptionsOpen: Boolean = false
    var usageOptionsOpen: Boolean
        get() { /*@DONE TableTool.UsageOptionsOpen.get cs:172-172*/
            return _usageOptionsOpen
        }
        set(value) { /*@DONE TableTool.UsageOptionsOpen.set cs:172-172*/
            set(_usageOptionsOpen, value, "usageOptionsOpen", { _usageOptionsOpen = it })
        }
    private var _fieldFilter: String = /*@INITAUTO TableTool.fieldFilter cs:174-174*/ "" /*@ENDINIT*/
    var fieldFilter: String
        get() { /*@DONE TableTool.FieldFilter.get cs:176-176*/
            return _fieldFilter
        }
        set(value) { /*@DONE TableTool.FieldFilter.set cs:177-177*/
            set(_fieldFilter, value, "fieldFilter", { _fieldFilter = it }, { _ -> applyFieldFilter() })
        }
    val modelDataChanged = Event<IFormattedRun>()
    val onError = Event<String>()
    val onMessage = Event<String>()
    val requestMenuClose = Event<EventArgs>()
    val modelDataMoved = Event<TableToolModelDataMovedTuple>()
    var verticalOffset: Double = 0.0
    private var ignoreFurtherCommands: Boolean = /*@INITAUTO TableTool.ignoreFurtherCommands cs:191-191*/ false /*@ENDINIT*/
    constructor(model: IDataModel, selection: Selection, history: ChangeHistory<ModelDelta>, viewPort: ViewPort, toolTray: IToolTrayViewModel, dispatcher: IWorkDispatcher) { /*@DONE TableTool.<init>/1 cs:192-293*/
        this.model = model
        this.selection = selection
        this.history = history
        this.viewPort = viewPort
        this.toolTray = toolTray
        this.dispatcher = dispatcher
        loadMapUsageTimer = dispatcher.createDelayTimer()
        dataChangedTimer = ImmediateWorkTimer() // dispatcher.createDelayTimer()
        currentElementSelector = FilteringComboOptions()
        currentElementSelector.bind("modelValue") { _, _ -> updateViewPortSelectionFromTableComboBoxIndex() }

        val previousCommand = StubCommand()
        previousCommand.canExecute = { _ ->
            val array = model.getNextRun(_address) as? ITableRun
            array != null && array.start < _address
        }
        previousCommand.execute = previousExecute@{ _ ->
            if (ignoreFurtherCommands) return@previousExecute
            val guard = scope(ignoreFurtherCommands, true, { ignoreFurtherCommands = it }, { ignoreFurtherCommands = it })
            dispatcher.waitForRenderingAsync().continueWith { _ ->
                try {
                    var start = selection.scroll.viewPointToDataIndex(selection.selectionStart)
                    var end = selection.scroll.viewPointToDataIndex(selection.selectionEnd)
                    val array = model.getNextRun(_address) as ITableRun
                    if (array.start <= start && start < array.start + array.length && array.start <= end && end < array.start + array.length) {
                        start -= array.elementLength
                        end -= array.elementLength
                    } else {
                        start = _address - array.elementLength
                        end = _address - 1
                    }
                    selection.selectionStart = selection.scroll.dataIndexToViewPoint(start)
                    selection.selectionEnd = selection.scroll.dataIndexToViewPoint(end)
                } finally {
                    guard.dispose()
                }
            }
        }
        _previous = previousCommand

        val nextCommand = StubCommand()
        nextCommand.canExecute = { _ ->
            val array = model.getNextRun(_address) as? ITableRun
            array != null && array.start + array.length > _address + array.elementLength
        }
        nextCommand.execute = nextExecute@{ _ ->
            if (ignoreFurtherCommands) return@nextExecute
            val guard = scope(ignoreFurtherCommands, true, { ignoreFurtherCommands = it }, { ignoreFurtherCommands = it })
            dispatcher.waitForRenderingAsync().continueWith { _ ->
                try {
                    var start = selection.scroll.viewPointToDataIndex(selection.selectionStart)
                    var end = selection.scroll.viewPointToDataIndex(selection.selectionEnd)
                    val array = model.getNextRun(_address) as ITableRun
                    if (array.start <= start && start < array.start + array.length && array.start <= end && end < array.start + array.length) {
                        start += array.elementLength
                        end += array.elementLength
                    } else {
                        start = _address + array.elementLength
                        end = _address + array.elementLength * 2 - 1
                    }
                    selection.selectionStart = selection.scroll.dataIndexToViewPoint(start)
                    selection.selectionEnd = selection.scroll.dataIndexToViewPoint(end)
                } finally {
                    guard.dispose()
                }
            }
        }
        _next = nextCommand

        val appendCommand = StubCommand()
        appendCommand.canExecute = appendCanExecute@{ _ ->
            val array = model.getNextRun(_address) as? ITableRun
            if (array == null || !array.canAppend) return@appendCanExecute false
            if (array is TableStreamRun && array.allowsZeroElements && _address == array.start + array.elementLength * array.elementCount) return@appendCanExecute true
            _address == array.start + array.elementLength * (array.elementCount - 1)
        }
        appendCommand.execute = { _ ->
            ModelCacheScope.createScope(model).using {
                val originalArray = model.getNextRun(_address) as ITableRun
                val initialViewOffset = viewPort.dataOffset
                val arrayRef = Ref<ITableRun?>(originalArray)
                val error = model.completeArrayExtension(viewPort.currentChange, _addCount, arrayRef)
                val array = arrayRef.value
                if (array != null) {
                    if (array.start != originalArray.start) {
                        modelDataMoved(this, TableToolModelDataMovedTuple(originalArray.start, array.start))
                        viewPort.goto?.execute(array.start + (initialViewOffset - originalArray.start))
                        selection.selectionStart = viewPort.convertAddressToViewPoint(array.start + array.length - array.elementLength)
                    }
                    if (error.hasError && !error.isWarning) {
                        onError(this, error.errorMessage ?: "")
                    } else {
                        if (error.isWarning) onMessage(this, error.errorMessage ?: "")
                        modelDataChanged(this, array)
                        selection.selectionStart = selection.scroll.dataIndexToViewPoint(array.start + array.length - array.elementLength)
                        selection.selectionEnd = selection.scroll.dataIndexToViewPoint(selection.scroll.viewPointToDataIndex(selection.selectionStart) + array.elementLength - 1)
                    }
                } else {
                    _append.raiseCanExecuteChanged()
                }
                viewPort.refresh()
                requestMenuClose(this, EventArgs.empty)
                val currentModel = model
                if (currentModel is PokemonModel) currentModel.resolveConflicts()
            }
            addCount = 1
        }
        _append = appendCommand

        currentElementName = "The Table tool only works if your cursor is on table data."
    }
    val children: MutableList<IArrayElementViewModel>
        get() { /*@DONE TableTool.Children.get cs:295-295*/
            return groups.flatMap { group -> group.members.toList() }.toMutableList()
        }
    private fun addGroup() { /*@DONE TableTool.AddGroup/1 cs:297-302*/
        groups.add(newTableGroup())
    }
    private var childIndexGroup: Int = /*@INITAUTO TableTool.childIndexGroup cs:304-304*/ 0 /*@ENDINIT*/
    private fun addChild(child: IArrayElementViewModel?) { /*@DONE TableTool.AddChild/1 cs:305-309*/
        if (child == null) return
        while (groups.size <= childIndexGroup) addGroup()
        groups[childIndexGroup].add(child)
    }
    private fun moveToNextGroup() { /*@DONE TableTool.MoveToNextGroup/1 cs:311-315*/
        groups[childIndexGroup].close()
        childIndexGroup += 1
        if (groups.size > childIndexGroup) groups[childIndexGroup].open()
    }
    val hasUsageOptions: Boolean
        get() { /*@DONE TableTool.HasUsageOptions.get cs:318-324*/
            for (child in usageChildren) {
                if (child !is MapOptionsArrayElementViewModel) return true
                return child.mapPreviews.size > 0
            }
            return false
        }
    private var usageChildInsertionIndex: Int = /*@INITAUTO TableTool.usageChildInsertionIndex cs:327-327*/ 0 /*@ENDINIT*/
    private fun addUsageChild(child: IArrayElementViewModel) { /*@DONE TableTool.AddUsageChild/1 cs:328-336*/
        if (usageChildInsertionIndex == usageChildren.size) {
            usageChildren.add(child)
        } else if (!usageChildren[usageChildInsertionIndex].tryCopy(child)) {
            usageChildren[usageChildInsertionIndex] = child
        }
        usageChildInsertionIndex++
        notifyPropertyChanged("hasUsageOptions")
    }
    private var dataForCurrentRunChangeUpdate: Boolean = false
    override fun dataForCurrentRunChanged() { /*@DONE TableTool.DataForCurrentRunChanged/1 cs:339-349*/
        // ignore callbacks while any held comboboxes are open
        for (group in groups) {
            for (member in group.members) {
                if (member is ComboBoxArrayElementViewModel && member.filteringComboOptions.dropDownIsOpen) return
            }
        }

        // must be longer than initial key-hold delay or app will studder
        dataChangedTimer.delayCall(TimeSpan.fromSeconds(.6), this::dataForCurrentRunChangedCore)
    }
    private fun dataForCurrentRunChangedCore() { /*@DONE TableTool.DataForCurrentRunChangedCore/1 cs:351-501*/
        for (group in groups) {
            for (member in group.members) clearHandlers(member)
        }
        for (child in usageChildren) clearHandlers(child)
        for (group in groups) group.open()
        childIndexGroup = 0
        usageChildInsertionIndex = 0

        val array = model.getNextRun(address) as? ITableRun
        if (array == null || array.start > address) {
            currentElementName = "The Table tool only works if your cursor is on table data."
            groups.clear()
            usageChildren.clear()
            scope(dataForCurrentRunChangeUpdate, true, { dataForCurrentRunChangeUpdate = it }, { dataForCurrentRunChangeUpdate = it }).using {
                notifyPropertyChanged("tableSections")
            }
            return
        }

        dataForCurrentRunChangeUpdate = true
        var basename = model.getAnchorFromAddress(-1, array.start)
        val anchorParts = basename.split('.')
        notifyPropertyChanged("tableSections")
        if (anchorParts.size == 1) {
            tryUpdate(_selectedTableSection, tableSections.indexOf(anchorParts[0]), "selectedTableSection") { _selectedTableSection = it }
            notifyPropertyChanged("tableList")
        } else if (anchorParts.size == 2) {
            tryUpdate(_selectedTableSection, tableSections.indexOf(anchorParts[0]), "selectedTableSection") { _selectedTableSection = it }
            notifyPropertyChanged("tableList")
            tryUpdate(_selectedTableIndex, tableList.indexOf(anchorParts[1]), "selectedTableIndex") { _selectedTableIndex = it }
        } else {
            tryUpdate(_selectedTableSection, tableSections.indexOf(anchorParts[0] + "." + anchorParts[1]), "selectedTableSection") { _selectedTableSection = it }
            notifyPropertyChanged("tableList")
            tryUpdate(_selectedTableIndex, tableList.indexOf(anchorParts.drop(2).joinToString(".")), "selectedTableIndex") { _selectedTableIndex = it }
        }

        dataForCurrentRunChangeUpdate = false
        if (basename.isEmpty()) basename = array.start.toHex(6)
        var index = (address - array.start) / array.elementLength

        if (0 <= index && index < array.elementCount) {
            currentElementName = basename + "/" + index
            updateCurrentElementSelector(array, index)

            var streamGroup: TableGroupViewModel? = null
            var elementOffset = array.start + array.elementLength * index
            if (array !is ArrayRun) {
                if (groups.size == 2) {
                    streamGroup = groups[1]
                    streamGroup.open()
                } else {
                    streamGroup = newTableGroup()
                    streamGroup.open()
                }

                val header = SplitterArrayElementViewModel(viewPort, basename, elementOffset)
                addChild(header)
                groups[childIndexGroup].addChildrenFromTable(viewPort, selection, array, index, header, streamGroup)
                moveToNextGroup()
                groups[0].groupName = basename
            } else {
                index -= array.parentOffset.beginningMargin
                val originalTableName = basename
                val lengthFromAnchor = array.lengthFromAnchor
                if (!lengthFromAnchor.isNullOrEmpty() && (model.getMatchedWords(lengthFromAnchor)?.size ?: 0) == 0) basename = lengthFromAnchor // basename is now a 'parent table' name, if there is one

                var tableGroups: List<TableGroup> = listOf(TableGroup(TableGroupViewModel.defaultName, listOf(originalTableName)))
                if (!viewPort.spartanMode) tableGroups = model.getTableGroups(basename) ?: tableGroups
                if (tableGroups.size == 1) {
                    if (groups.size == 2) {
                        streamGroup = groups[1]
                        streamGroup.groupName = TableGroupViewModel.defaultName
                        streamGroup.open()
                    } else {
                        streamGroup = newTableGroup()
                        streamGroup.open()
                    }
                }
                for (tableGroup in tableGroups) {
                    while (groups.size <= childIndexGroup) addGroup()
                    val helperGroup = streamGroup ?: groups[childIndexGroup]
                    for (table in tableGroup.tables) {
                        var tableName = table
                        var partition = 0
                        val parts = table.split(ArrayRunSplitterSegment.separator)
                        if (parts.size == 2) {
                            tableName = parts[0]
                            val parsed = Ref(0)
                            partition = if (tryParseInt(parts[1], parsed)) parsed.value else 0
                        }

                        val currentArrayStart = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, tableName)
                        val currentArray = model.getNextRun(currentArrayStart) as? ArrayRun
                        if (currentArray == null) continue
                        val currentIndex = index + currentArray.parentOffset.beginningMargin
                        if (currentIndex >= 0 && currentIndex < currentArray.elementCount) {
                            elementOffset = currentArray.start + currentArray.elementLength * currentIndex
                            val header = SplitterArrayElementViewModel(viewPort, tableName, elementOffset)
                            addChild(header)
                            groups[childIndexGroup].addChildrenFromTable(viewPort, selection, currentArray, currentIndex, header, helperGroup, partition)
                        }
                    }
                    while (groups.size <= childIndexGroup) addGroup()
                    groups[childIndexGroup].groupName = tableGroup.groupName
                    moveToNextGroup()
                }
            }

            if (groups.size == 1) {
                groups.add(streamGroup!!)
                streamGroup.close()
                childIndexGroup++
            } else if (streamGroup != null) {
                while (groups.size <= childIndexGroup) addGroup()
                groups[childIndexGroup] = streamGroup
                streamGroup.close()
                childIndexGroup++
            }
            addChildrenFromStreams(array, basename, index)
        }

        while (groups.size > childIndexGroup) groups.removeAt(groups.size - 1)
        while (usageChildren.size > usageChildInsertionIndex) usageChildren.removeAt(usageChildren.size - 1)
        for (group in groups) {
            for (member in group.members) addHandlers(member)
        }
        for (child in usageChildren) addHandlers(child)
        addDummyGroup()

        val allChildren = children
        val paletteIndex = (allChildren.filterIsInstance<SpriteElementViewModel>().map { spriteElement ->
            if (spriteElement.currentPalette > spriteElement.maxPalette) 0 else spriteElement.currentPalette
        } + listOf(0)).maxOrNull() ?: 0
        for (child in allChildren) {
            // update sprites now that all the associated palettes have been loaded.
            if (child is SpriteElementViewModel) {
                // using var scope = sevm.SilencePropertyNotifications();
                child.currentPalette = paletteIndex
                child.updateTiles()
            }
            // update 'visible' for children based on their parents.
            if (child is SplitterArrayElementViewModel) child.updateCollapsed(_fieldFilter)
        }

        // Debug.Assert(!group.isOpen) for every group
        notifyPropertyChanged("children")
    }
    private fun addHandlers(member: IArrayElementViewModel) { /*@DONE TableTool.AddHandlers/1 cs:503-506*/
        member.dataChanged += forwardModelChangedHandler
        member.dataSelected += handleDataSelectedHandler
    }
    private fun clearHandlers(member: IArrayElementViewModel) { /*@DONE TableTool.ClearHandlers/1 cs:508-511*/
        member.dataChanged -= forwardModelChangedHandler
        member.dataSelected -= handleDataSelectedHandler
    }
    private fun updateCurrentElementSelector(array: ITableRun, index: Int) { /*@DONE TableTool.UpdateCurrentElementSelector/1 cs:513-515*/
        setupFromModel(array.start + array.elementLength * index)
    }
    private var selfChange: Boolean = /*@INITAUTO TableTool.selfChange cs:517-517*/ false /*@ENDINIT*/
    private fun setupFromModel(address: Int) { /*@DONE TableTool.SetupFromModel/1 cs:518-537*/
        val tableRun = model.getNextRun(address) as? ITableRun
        if (tableRun == null) return
        val offset = tableRun.convertByteOffsetToArrayOffset(address)
        val allOptions: MutableList<String> = tableRun.elementNames?.toMutableList() ?: (0 until tableRun.elementCount).map { i -> i.toString() }.toMutableList()
        while (allOptions.size < tableRun.elementCount) {
            allOptions.add(allOptions.size.toString())
        }
        val selectedIndex = offset.elementIndex
        val options = ArrayList<ComboOption>()
        for (i in 0 until allOptions.size) {
            // var image = ToolTipContentVisitor.GetEnumImage(model, i, tableRun as ArrayRun)
            // if (image != null) options.Add(VisualComboOption.CreateFromSprite(allOptions[i], image.PixelData, image.PixelWidth, i, 1, true))
            // else
            options.add(ComboOption(allOptions[i], i))
        }
        scope(selfChange, true, { selfChange = it }, { selfChange = it }).using {
            currentElementSelector.update(options, selectedIndex)
        }
    }
    private fun addDummyGroup() { /*@DONE TableTool.AddDummyGroup/1 cs:543-546*/
        if (groups.size > 1) return
        addGroup()
    }
    private fun updateViewPortSelectionFromTableComboBoxIndex(sender: Any? = null, e: EventArgs? = null) { /*@DONE TableTool.UpdateViewPortSelectionFromTableComboBoxIndex/1 cs:548-555*/
        if (selfChange) return
        if (currentElementSelector.dropDownIsOpen) return
        val array = model.getNextRun(address) as ITableRun
        val targetAddress = array.start + array.elementLength * currentElementSelector.selectedIndex
        selection.selectionStart = selection.scroll.dataIndexToViewPoint(targetAddress)
        selection.selectionEnd = selection.scroll.dataIndexToViewPoint(targetAddress + array.elementLength - 1)
    }
    private fun addChildrenFromStreams(array: ITableRun, basename: String, index: Int) { /*@DONE TableTool.AddChildrenFromStreams/1 cs:557-643*/
        val plmResults = ArrayList<ViewPortOpenSearchResultsTabShowSelectionTuple>()
        val eggResults = ArrayList<ViewPortOpenSearchResultsTabShowSelectionTuple>()
        val trainerResults = ArrayList<Int>()
        val streamResults = ArrayList<ViewPortOpenSearchResultsTabShowSelectionTuple>()
        for (child in model.streams) {
            if (!child.dependsOn(basename)) continue
            if (child is PLMRun) for (r in child.search(index)) plmResults.add(ViewPortOpenSearchResultsTabShowSelectionTuple(r.item1, r.item2))
            if (child is EggMoveRun) for (r in child.search(basename, index)) eggResults.add(ViewPortOpenSearchResultsTabShowSelectionTuple(r.item1, r.item2))
            if (child is TrainerPokemonTeamRun) trainerResults.addAll(child.search(basename, index))
            if (child is TableStreamRun) for (r in child.search(basename, index)) streamResults.add(ViewPortOpenSearchResultsTabShowSelectionTuple(r.item1, r.item2))
        }
        val parentOffset = if (array is ArrayRun) array.parentOffset.beginningMargin else 0
        val names = array.elementNames
        val elementName = if (names != null && names.size > index + parentOffset && index + parentOffset >= 0) names[index + parentOffset] else "Element " + index

        if (trainerResults.size > 0) {
            val selections = trainerResults.map { result -> ViewPortOpenSearchResultsTabShowSelectionTuple(result, result + 1) }
            val trainerTable = model.getTable(HardcodeTablesModel.trainerTableName)
            val trainerAddresses: List<ViewPortOpenSearchResultsTabGotoSelectionTuple>? = if (trainerTable != null) selections.map { s ->
                val parentPointer = model.getNextRun(s.start)?.pointerSources?.firstOrNull()
                if (parentPointer != null) {
                    val trainerIndex = trainerTable.convertByteOffsetToArrayOffset(parentPointer).elementIndex
                    ViewPortOpenSearchResultsTabGotoSelectionTuple(trainerTable.start + trainerTable.elementLength * trainerIndex, trainerTable.start + trainerTable.elementLength * (trainerIndex + 1) - 1)
                } else {
                    ViewPortOpenSearchResultsTabGotoSelectionTuple(s.start, s.end)
                }
            } else null
            addUsageChild(ButtonArrayElementViewModel("trainer teams", {
                usageOptionsOpen = false
                viewPort.openSearchResultsTab(elementName + " within " + HardcodeTablesModel.trainerTableName, selections, trainerAddresses)
            }))
        }

        if (plmResults.size > 0) {
            addUsageChild(ButtonArrayElementViewModel("level-up moves", {
                usageOptionsOpen = false
                viewPort.openSearchResultsTab(elementName + " within " + HardcodeTablesModel.levelMovesTableName, plmResults)
            }))
        }

        if (eggResults.size > 0) {
            addUsageChild(ButtonArrayElementViewModel("egg moves", {
                usageOptionsOpen = false
                viewPort.openSearchResultsTab(elementName + " within " + HardcodeTablesModel.eggMovesTableName, eggResults)
            }))
        }

        for (table in model.arrays) {
            if (!table.dependsOn(basename)) continue
            val results = ArrayList<ViewPortOpenSearchResultsTabShowSelectionTuple>(table.search(model, basename, index).map { r -> ViewPortOpenSearchResultsTabShowSelectionTuple(r.item1, r.item2) })
            if (results.size == 0) continue
            val name = model.getAnchorFromAddress(-1, table.start)
            addUsageChild(ButtonArrayElementViewModel(name, name, {
                usageOptionsOpen = false
                viewPort.openSearchResultsTab(elementName + " within " + name, results)
            }))
        }

        if (streamResults.size > 0) {
            addUsageChild(ButtonArrayElementViewModel("other streams", {
                usageOptionsOpen = false
                viewPort.openSearchResultsTab(elementName + " within streams", streamResults)
            }))
        }

        // only check XSE scripts for now
        if (viewPort.tools!!.codeTool!!.scriptParser.dependsOn(basename).any()) {
            addUsageChild(ButtonArrayElementViewModel("scripts", {
                val results = ArrayList<ViewPortOpenSearchResultsTabShowSelectionTuple>(findXseScriptUses(basename, index).map { r -> ViewPortOpenSearchResultsTabShowSelectionTuple(r.item1, r.item2) })
                if (results.size == 0) {
                    onMessage(this, "No matches were found.")
                } else {
                    usageOptionsOpen = false
                    viewPort.tools!!.selectedTool = viewPort.tools!!.codeTool
                    viewPort.tools!!.codeTool!!.mode = CodeMode.Script
                    viewPort.openSearchResultsTab(elementName + " within scripts", results)
                    viewPort.tools!!.selectedTool = viewPort.tools!!.codeTool
                    viewPort.tools!!.codeTool!!.mode = CodeMode.Script
                }
            }))
        }

        // maps
        val mapEditor = viewPort.mapEditor
        if (mapEditor != null && mapEditor.isValidState && !viewPort.spartanMode) {
            val mapOptions = MapOptionsArrayElementViewModel(dispatcher, loadMapUsageTimer, mapEditor, basename, index)
            mapOptions.mapPreviews.collectionChanged += { _, _ -> notifyPropertyChanged("hasUsageOptions") }
            addUsageChild(mapOptions) // always add, but invisible when empty
        }
    }
    fun findXseScriptUses(basename: String, index: Int): Iterable<TableToolFindXseScriptUsesTuple> { /*@DONE TableTool.FindXseScriptUses/1 cs:645-665*/
        val parser = viewPort.tools!!.codeTool!!.scriptParser
        val lines = parser.dependsOn(basename).toList()
        val filter = ArrayList<Int>()
        for (line in lines) {
            if (line is MacroScriptLine && line.args[0] is SilentMatchArg) filter.add((line.args[0] as SilentMatchArg).expectedValue)
            if (line is ScriptLine) filter.add(line.lineCode[0])
        }
        val results = ArrayList<TableToolFindXseScriptUsesTuple>()
        for (spot in Flags.getAllScriptSpots(model, parser, Flags.getAllTopLevelScripts(model), *filter.toIntArray())) {
            var check = spot.address + spot.line.lineCode.count
            for (arg in spot.line.args) {
                val length = arg.length(model, check)
                if (arg.enumTableName == basename) {
                    if (model.readMultiByteValue(check, length) == index) {
                        results.add(TableToolFindXseScriptUsesTuple(spot.address, check + length - 1))
                    }
                }
                check += length
            }
        }
        return results
    }
    private fun applyFieldFilter() { /*@DONE TableTool.ApplyFieldFilter/1 cs:667-672*/
        for (child in children) {
            // update 'visible' for children based on their parents.
            if (child is SplitterArrayElementViewModel) child.updateCollapsed(_fieldFilter)
        }
    }
    private fun forwardModelChanged(sender: Any?, e: EventArgs) { /*@DONE TableTool.ForwardModelChanged/1 cs:674-674*/
        modelDataChanged(this, model.getNextRun(address) ?: NoInfoRun.nullRun)
    }
    private fun forwardModelDataMoved(sender: Any?, e: IStreamArrayElementViewModelDataMovedTuple) { /*@DONE TableTool.ForwardModelDataMoved/1 cs:675-675*/
        modelDataMoved(this, TableToolModelDataMovedTuple(e.originalStart, e.newStart))
    }
    private fun handleDataSelected(sender: Any?, e: EventArgs) { /*@DONE TableTool.HandleDataSelected/1 cs:677-682*/
        if (sender !is IArrayElementViewModel) return
        if (sender is FieldArrayElementViewModel) viewPort.goto?.execute(sender.start)
        if (sender is ComboBoxArrayElementViewModel) viewPort.goto?.execute(sender.start)
        if (sender is TupleArrayElementViewModel) viewPort.goto?.execute(sender.children[0].start)
    }
    /*@ADD TableTool#tabletool.txt*/
    private val forwardModelChangedHandler: (Any?, EventArgs) -> Unit = { s, e -> forwardModelChanged(s, e) }
    private val handleDataSelectedHandler: (Any?, EventArgs) -> Unit = { s, e -> handleDataSelected(s, e) }
    private val forwardModelDataMovedHandler: (Any?, IStreamArrayElementViewModelDataMovedTuple) -> Unit = { s, e -> forwardModelDataMoved(s, e) }
    private fun newTableGroup(): TableGroupViewModel {
        val group = TableGroupViewModel(viewPort)
        group.forwardModelChanged = { element -> element.dataChanged += forwardModelChangedHandler }
        group.forwardModelDataMoved = { element -> element.dataMoved += forwardModelDataMovedHandler }
        return group
    }
    /*@ENDADD TableTool#tabletool.txt*/
    /*@END TableTool*/
}

data class TableToolModelDataMovedTuple(val originalLocation: Int, val newLocation: Int)

data class TableToolFindXseScriptUsesTuple(val item1: Int, val item2: Int)
