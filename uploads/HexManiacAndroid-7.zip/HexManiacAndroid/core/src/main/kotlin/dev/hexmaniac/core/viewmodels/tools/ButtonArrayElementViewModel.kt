// Port of ViewModels/Tools/ButtonArrayElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.map.*

open class ButtonArrayElementViewModel : ViewModelCore, IArrayElementViewModel { // cs:13-56
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE ButtonArrayElementViewModel.Theme.get cs:14-14*/
            return _theme
        }
        set(value) { /*@DONE ButtonArrayElementViewModel.Theme.set cs:14-14*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE ButtonArrayElementViewModel.IsInError.get cs:15-15*/
            return false
        }
    override val errorText: String?
        get() { /*@DONE ButtonArrayElementViewModel.ErrorText.get cs:16-16*/
            return ""
        }
    override val zIndex: Int
        get() { /*@DONE ButtonArrayElementViewModel.ZIndex.get cs:17-17*/
            return 0
        }
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    var text: String? = null
        private set
    var toolTipText: String = ""
        private set
    lateinit var command: ICommand
        private set
    private var _visible: Boolean = /*@INITAUTO ButtonArrayElementViewModel.visible cs:26-26*/ true /*@ENDINIT*/
    override var visible: Boolean
        get() { /*@DONE ButtonArrayElementViewModel.Visible.get cs:27-27*/
            return _visible
        }
        set(value) { /*@DONE ButtonArrayElementViewModel.Visible.set cs:27-27*/
            set(_visible, value, "visible", { _visible = it })
        }
    constructor(text: String, action: () -> Unit) { /*@DONE ButtonArrayElementViewModel.<init>/1 cs:29-36*/
        this.text = text
        toolTipText = text
        val buttonCommand = StubCommand()
        buttonCommand.canExecute = { _ -> true }
        buttonCommand.execute = { _ -> action() }
        command = buttonCommand
    }
    constructor(text: String, toolTip: String, action: () -> Unit) { /*@DONE ButtonArrayElementViewModel.<init>/2 cs:38-45*/
        this.text = text
        toolTipText = toolTip
        val buttonCommand = StubCommand()
        buttonCommand.canExecute = { _ -> true }
        buttonCommand.execute = { _ -> action() }
        command = buttonCommand
    }
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE ButtonArrayElementViewModel.TryCopy/1 cs:47-55*/
        val button = other as? ButtonArrayElementViewModel ?: return false
        if (text != button.text) return false
        if (toolTipText != button.toolTipText) return false
        command = button.command
        visible = other.visible
        notifyPropertyChanged("command")
        return true
    }
    /*@END ButtonArrayElementViewModel*/
}

open class MapOptionsArrayElementViewModel : ViewModelCore, IArrayElementViewModel { // cs:58-193
    private lateinit var dispatcher: IWorkDispatcher
    private lateinit var mapEditor: MapEditorViewModel
    private var tableName: String = ""
    private var index: Int = 0
    private var _visible: Boolean = false
    override var visible: Boolean
        get() { /*@DONE MapOptionsArrayElementViewModel.Visible.get cs:64-64*/
            return _visible
        }
        set(value) { /*@DONE MapOptionsArrayElementViewModel.Visible.set cs:64-64*/
            set(_visible, value, "visible", { _visible = it })
        }
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE MapOptionsArrayElementViewModel.Theme.get cs:66-66*/
            return _theme
        }
        set(value) { /*@DONE MapOptionsArrayElementViewModel.Theme.set cs:66-66*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE MapOptionsArrayElementViewModel.IsInError.get cs:67-67*/
            return false
        }
    override val errorText: String?
        get() { /*@DONE MapOptionsArrayElementViewModel.ErrorText.get cs:69-69*/
            return ""
        }
    private var _zIndex: Int = 0
    override var zIndex: Int
        get() { /*@DONE MapOptionsArrayElementViewModel.ZIndex.get cs:72-72*/
            return _zIndex
        }
        set(value) { /*@DONE MapOptionsArrayElementViewModel.ZIndex.set cs:72-72*/
            set(_zIndex, value, "zIndex", { _zIndex = it })
        }
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    private var cancel: Boolean = false
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE MapOptionsArrayElementViewModel.TryCopy/1 cs:80-83*/
        cancel = true
        return false
    }
    private var _showPreviews: Boolean = false
    var showPreviews: Boolean
        get() { /*@DONE MapOptionsArrayElementViewModel.ShowPreviews.get cs:87-87*/
            return _showPreviews
        }
        set(value) { /*@DONE MapOptionsArrayElementViewModel.ShowPreviews.set cs:88-88*/
            set(_showPreviews, value, "showPreviews", { _showPreviews = it })
        }
    var mapPreviews: ObservableCollection<GotoMapButton> = /*@INITDONE MapOptionsArrayElementViewModel.MapPreviews cs:91-91*/ ObservableCollection() /*@ENDINIT*/
        private set
    constructor(dispatcher: IWorkDispatcher, timer: IDelayWorkTimer, mapEditor: MapEditorViewModel, tableName: String, index: Int) { /*@DONE MapOptionsArrayElementViewModel.<init>/1 cs:93-97*/
        this.dispatcher = dispatcher
        this.mapEditor = mapEditor
        this.tableName = tableName
        this.index = index
        timer.delayCall(TimeSpan.fromSeconds(.5), this::load)
    }
    private fun load() { /*@DONE MapOptionsArrayElementViewModel.Load/1 cs:99-109*/
        fun addButton(button: GotoMapButton) {
            visible = true
            dispatcher.blockOnUIWork { mapPreviews.add(button) }
        }
        if (tableName == HardcodeTablesModel.overworldSprites) {
            for (button in findOverworldUses()) addButton(button)
        } else {
            for (button in findObjectUses()) addButton(button)
        }
    }
    private fun findOverworldUses(): Sequence<GotoMapButton> { /*@DONE MapOptionsArrayElementViewModel.FindOverworldUses/1 cs:111-129*/
        return sequence {
            // look for any map with an event using this sprite
            val allMaps = AllMapsModel.create(mapEditor.viewPort.model!!)
            for (bankIndex in 0 until allMaps.count) {
                val bank = allMaps[bankIndex] ?: continue
                for (mapIndex in 0 until bank.count) {
                    val map = bank[mapIndex]
                    if (map == null) continue
                    val events = map.events
                    for (ev in events.objects ?: ArrayList<ObjectEventModel>()) {
                        if (cancel) return@sequence
                        if (ev.graphics != index) continue
                        val button = GotoMapButton(mapEditor, this@MapOptionsArrayElementViewModel, bankIndex, mapIndex, ev)
                        if (button.image == null) continue
                        yield(button)
                    }
                }
            }
        }
    }
    private fun findObjectUses(): Sequence<GotoMapButton> { /*@DONE MapOptionsArrayElementViewModel.FindObjectUses/1 cs:131-192*/
        return sequence {
            val model = mapEditor.viewPort.model!!
            val parser = mapEditor.viewPort.tools!!.codeTool!!.scriptParser
            val lines = parser.dependsOn(tableName).toList()
            val filter = ArrayList<Int>()
            for (line in lines) {
                if (line is MacroScriptLine && line.args[0] is SilentMatchArg) filter.add((line.args[0] as SilentMatchArg).expectedValue)
                if (line is ScriptLine) filter.add(line.lineCode[0])
            }

            val allMaps = AllMapsModel.create(model)
            val isItemTable = tableName == HardcodeTablesModel.itemsTableName
            val isMapNameTable = tableName == HardcodeTablesModel.mapNameTable
            for (bankIndex in 0 until allMaps.count) {
                val bank = allMaps[bankIndex] ?: continue
                for (mapIndex in 0 until bank.count) {
                    val map = bank[mapIndex]
                    if (map == null) continue
                    val events = map.events
                    val scriptEvents = ArrayList<IScriptEventModel>()
                    scriptEvents.addAll(events.objects ?: ArrayList<ObjectEventModel>())
                    scriptEvents.addAll(events.scripts)
                    for (ev in scriptEvents) {
                        if (ev is SignpostEventModel && !ev.hasScript) continue
                        if (cancel) return@sequence
                        val spots = Flags.getAllScriptSpots(model, parser, listOf(ev.scriptAddress), *filter.toIntArray())

                        // if any of these spots match, then this object's script refers to this enum
                        for (spot in spots) {
                            var check = spot.address + spot.line.lineCode.count
                            var match = false
                            for (arg in spot.line.args) {
                                if (cancel) return@sequence
                                val length = arg.length(model, check)
                                if (arg.enumTableName == tableName) {
                                    if (model.readMultiByteValue(check, length) == index) {
                                        val button = GotoMapButton(mapEditor, this@MapOptionsArrayElementViewModel, bankIndex, mapIndex, ev)
                                        if (button.image == null) continue
                                        yield(button)
                                        match = true
                                        break
                                    }
                                }
                                check += length
                            }
                            if (match) break
                        }
                    }
                    if (isItemTable) {
                        for (ev in events.signposts) {
                            if (cancel) return@sequence
                            if (ev.isHiddenItem && ev.itemValue == index) {
                                val button = GotoMapButton(mapEditor, this@MapOptionsArrayElementViewModel, bankIndex, mapIndex, ev)
                                if (button.image == null) continue
                                yield(button)
                            }
                        }
                    } else if (isMapNameTable) {
                        if (map.nameIndex != index) continue
                        val button = GotoMapButton(mapEditor, this@MapOptionsArrayElementViewModel, bankIndex, mapIndex, null)
                        if (button.image == null) continue
                        yield(button)
                    }
                }
            }
        }
    }
    /*@END MapOptionsArrayElementViewModel*/
}

open class GotoMapButton : ViewModelCore { // cs:195-220
    private lateinit var mapEditor: MapEditorViewModel
    private lateinit var owner: MapOptionsArrayElementViewModel
    private var bank: Int = 0
    private var map: Int = 0
    private var eventModel: IEventModel? = null
    var image: IPixelViewModel? = null
    constructor(mapEditor: MapEditorViewModel, owner: MapOptionsArrayElementViewModel, bank: Int, map: Int, eventViewModel: IEventModel?) { /*@DONE GotoMapButton.<init>/1 cs:201-210*/
        this.mapEditor = mapEditor
        this.owner = owner
        this.bank = bank
        this.map = map
        this.eventModel = eventViewModel
        if (eventViewModel == null) {
            image = mapEditor.getMapPreview(bank, map, 7)
        } else {
            image = mapEditor.getMapPreview(bank, map, eventViewModel.x, eventViewModel.y)
        }
    }
    fun goto() { /*@DONE GotoMapButton.Goto/1 cs:211-219*/
        owner.showPreviews = false
        mapEditor.viewPort.tools!!.tableTool!!.usageOptionsOpen = false
        val blockmap = BlockMapViewModel(mapEditor.fileSystem, mapEditor.tutorials, mapEditor.viewPort, mapEditor.format!!, mapEditor.templates, bank, map)
        blockmap.allOverworldSprites = mapEditor.primaryMap.allOverworldSprites
        blockmap.includeBorders = false
        val targetEvent = eventModel
        val x = if (targetEvent != null) targetEvent.x else blockmap.pixelWidth / 32
        val y = if (targetEvent != null) targetEvent.y else blockmap.pixelHeight / 32
        mapEditor.navigateTo(bank, map, x, y)
        if (targetEvent != null) mapEditor.selectedEvent = mapEditor.primaryMap.eventGroup?.all?.firstOrNull { ev -> ev.element?.start == targetEvent.element?.start }
        mapEditor.viewPort.raiseRequestTabChange(mapEditor)
    }
    /*@END GotoMapButton*/
}
