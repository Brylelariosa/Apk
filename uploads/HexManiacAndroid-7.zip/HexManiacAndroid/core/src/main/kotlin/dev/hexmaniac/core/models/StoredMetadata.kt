// Port of Models/StoredMetadata.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

open class StoredMetadataFields { // cs:9-14
    var freeSpaceSearch: Int = /*@INITAUTO StoredMetadataFields.FreeSpaceSearch cs:10-10*/ -1 /*@ENDINIT*/
    var freeSpaceBuffer: Int = /*@INITAUTO StoredMetadataFields.FreeSpaceBuffer cs:11-11*/ -1 /*@ENDINIT*/
    var nextExportID: Int = /*@INITAUTO StoredMetadataFields.NextExportID cs:12-12*/ 0 /*@ENDINIT*/
    var showRawIVByteForTrainer: Boolean = /*@INITAUTO StoredMetadataFields.ShowRawIVByteForTrainer cs:13-13*/ false /*@ENDINIT*/
    /*@END StoredMetadataFields*/
}

open class StoredMetadata { // cs:16-427
    var namedAnchors: List<StoredAnchor> = ArrayList()
        private set
    var unmappedPointers: List<StoredUnmappedPointer> = ArrayList()
        private set
    var matchedWords: List<StoredMatchedWord> = ArrayList()
        private set
    var offsetPointers: List<StoredOffsetPointer> = ArrayList()
        private set
    var lists: List<StoredList> = ArrayList()
        private set
    var unmappedConstants: List<StoredUnmappedConstant> = ArrayList()
        private set
    var gotoShortcuts: List<StoredGotoShortcut> = ArrayList()
        private set
    var tableGroups: List<TableGroup> = ArrayList()
        private set
    var version: String? = null
        private set
    var nextExportID: Int = 0
        private set
    var freeSpaceSearch: Int = /*@INITAUTO StoredMetadata.FreeSpaceSearch cs:27-27*/ -1 /*@ENDINIT*/
        private set
    var freeSpaceBuffer: Int = /*@INITAUTO StoredMetadata.FreeSpaceBuffer cs:28-28*/ -1 /*@ENDINIT*/
        private set
    var showRawIVByteForTrainer: Boolean = /*@INITAUTO StoredMetadata.ShowRawIVByteForTrainer cs:29-29*/ false /*@ENDINIT*/
        private set
    val isEmpty: Boolean
        get() { /*@DONE StoredMetadata.IsEmpty.get cs:31-31*/
            return namedAnchors.size == 0 && unmappedPointers.size == 0 && lists.size == 0 && tableGroups.size == 0
        }
    constructor(anchors: List<StoredAnchor>?, unmappedPointers: List<StoredUnmappedPointer>?, matchedWords: List<StoredMatchedWord>?, offsetPointers: List<StoredOffsetPointer>?, lists: List<StoredList>?, unmappedConstants: List<StoredUnmappedConstant>?, generalInfo: IMetadataInfo?, freeSpaceSearch: Int, freeSpaceBuffer: Int, nextExportID: Int) : this(anchors, unmappedPointers, matchedWords, offsetPointers, lists, unmappedConstants, null, null, generalInfo, StoredMetadataFields().also { it.freeSpaceSearch = freeSpaceSearch; it.freeSpaceBuffer = freeSpaceBuffer; it.nextExportID = nextExportID }) { /*@DONE StoredMetadata.<init>/1 cs:34-49*/
        // all work happens in the delegated constructor
    }
    constructor(anchors: List<StoredAnchor>?, unmappedPointers: List<StoredUnmappedPointer>?, matchedWords: List<StoredMatchedWord>?, offsetPointers: List<StoredOffsetPointer>?, lists: List<StoredList>?, unmappedConstants: List<StoredUnmappedConstant>?, gotoShortcuts: List<StoredGotoShortcut>?, generalInfo: IMetadataInfo?, fields: StoredMetadataFields?) : this(anchors, unmappedPointers, matchedWords, offsetPointers, lists, unmappedConstants, gotoShortcuts, null, generalInfo, fields) { /*@DONE StoredMetadata.<init>/2 cs:51-61*/
        // all work happens in the delegated constructor
    }
    constructor(anchors: List<StoredAnchor>? = null, unmappedPointers: List<StoredUnmappedPointer>? = null, matchedWords: List<StoredMatchedWord>? = null, offsetPointers: List<StoredOffsetPointer>? = null, lists: List<StoredList>? = null, unmappedConstants: List<StoredUnmappedConstant>? = null, gotoShortcuts: List<StoredGotoShortcut>? = null, tableGroups: List<TableGroup>? = null, generalInfo: IMetadataInfo? = null, fields: StoredMetadataFields? = null) { /*@DONE StoredMetadata.<init>/3 cs:63-89*/
        this.namedAnchors = anchors ?: ArrayList()
        this.unmappedPointers = unmappedPointers ?: ArrayList()
        this.matchedWords = matchedWords ?: ArrayList()
        this.offsetPointers = offsetPointers ?: ArrayList()
        this.lists = lists ?: ArrayList()
        this.unmappedConstants = unmappedConstants ?: ArrayList()
        this.gotoShortcuts = gotoShortcuts ?: ArrayList()
        this.tableGroups = tableGroups ?: ArrayList()
        version = generalInfo?.versionNumber
        val fields2 = fields ?: StoredMetadataFields()
        freeSpaceSearch = fields2.freeSpaceSearch
        freeSpaceBuffer = fields2.freeSpaceBuffer
        nextExportID = fields2.nextExportID
        showRawIVByteForTrainer = fields2.showRawIVByteForTrainer
    }
    constructor(lines: Array<String>) { /*@DONE StoredMetadata.<init>/4 cs:91-226*/
        val anchors = ArrayList<StoredAnchor>()
        val pointers = ArrayList<StoredUnmappedPointer>()
        val matchedWords = ArrayList<StoredMatchedWord>()
        val offsetPointers = ArrayList<StoredOffsetPointer>()
        val lists = ArrayList<StoredList>()
        val unmappedConstants = ArrayList<StoredUnmappedConstant>()
        val gotoShortcuts = ArrayList<StoredGotoShortcut>()
        val tableGroups = ArrayList<TableGroup>()

        for (line in lines) {
            var cleanLine = line.split('#').first().trim()
            if (cleanLine == "") continue
            if (cleanLine.startsWith("[")) {
                closeCurrentItem(anchors, pointers, matchedWords, offsetPointers, lists, unmappedConstants, gotoShortcuts, tableGroups)
                currentItem = cleanLine
                continue
            }

            if (cleanLine.startsWith("]")) {
                continueCurrentItemIndex = false
                continue
            }

            if (continueCurrentItemIndex) {
                if (cleanLine.endsWith(",")) cleanLine = cleanLine.substring(0, cleanLine.length - 1)
                currentItemChildren!!.add(cleanLine.replace("'''", ""))
                continue
            }

            if (cleanLine.startsWith("Address = 0x")) {
                val start = cleanLine.indexOf("x") + 1
                currentItemAddress = parseHexInt(cleanLine.substring(start))
            }

            if (cleanLine.startsWith("Offset = 0x")) {
                val start = cleanLine.indexOf("x") + 1
                currentItemOffset = parseHexInt(cleanLine.substring(start))
            } else if (cleanLine.startsWith("Offset = ")) {
                val start = cleanLine.indexOf(" = ") + 3
                currentItemOffset = parseInt(cleanLine.substring(start))
            } else if (cleanLine.startsWith("MultOffset = ")) {
                val start = cleanLine.indexOf(" = ") + 3
                currentItemMultOffset = parseInt(cleanLine.substring(start))
            }

            if (cleanLine.startsWith("Length = ")) {
                val start = cleanLine.indexOf(" = ") + 3
                currentItemLength = parseInt(cleanLine.substring(start))
            }

            if (cleanLine.startsWith("Name = '''")) {
                currentItemName = cleanLine.split("'''")[1]
            }

            if (cleanLine.startsWith("Value = 0x")) {
                val start = cleanLine.indexOf("x") + 1
                currentItemValue = parseHexInt(cleanLine.substring(start))
            } else if (cleanLine.startsWith("Value = ")) {
                val start = cleanLine.indexOf(" = ") + 3
                currentItemValue = parseInt(cleanLine.substring(start))
            }

            if (cleanLine.startsWith("Format = '''")) {
                currentItemFormat = cleanLine.split("'''")[1]
            }

            if (cleanLine.startsWith("DefaultHash = '''")) {
                currentItemHash = cleanLine.split("'''")[1]
            }

            if (cleanLine.startsWith("Note = '''")) {
                currentItemNote = cleanLine.split("'''")[1]
            } else if (cleanLine.startsWith("Image = '''")) {
                currentItemImage = cleanLine.split("'''")[1]
            } else if (cleanLine.startsWith("Destination =")) {
                currentItemDestination = cleanLine.split("=")[1].trim('\'', ' ')
            }

            if (cleanLine.startsWith("ApplicationVersion = '''")) {
                version = cleanLine.split("'''")[1]
            }

            if (cleanLine.startsWith("NextExportID = '''")) {
                val neid = Ref(0)
                if (tryParseInt(cleanLine.split("'''")[1], neid)) nextExportID = neid.value
            }

            if (cleanLine.startsWith("FreeSpaceSearch = '''")) {
                val fss = Ref(0)
                if (tryParseHexInt(cleanLine.split("'''")[1], fss)) freeSpaceSearch = fss.value
            }

            if (cleanLine.startsWith("FreeSpaceBuffer = '''")) {
                val fsb = Ref(0)
                if (tryParseHexInt(cleanLine.split("'''")[1], fsb)) freeSpaceBuffer = fsb.value
            }

            if (cleanLine.startsWith("ShowRawIVByteForTrainer =")) {
                val showRawIV = cleanLine.split("=")[1].trim().lowercase()
                if (showRawIV == "true") showRawIVByteForTrainer = true
                else if (showRawIV == "false") showRawIVByteForTrainer = false
            }

            val itemIndexRef = Ref(0)
            if (cleanLine.contains('=') && cleanLine.split('=')[0].trim().tryParseInt(itemIndexRef)) {
                val currentItemIndex = itemIndexRef.value
                if (currentItemChildren == null) currentItemChildren = ArrayList()
                val children = currentItemChildren!!
                while (children.size < currentItemIndex) children.add(null)
                if (!cleanLine.split("'''")[0].contains("[")) {
                    // this is the only element, easy peasy
                    val elementStart = cleanLine.indexOf("'''") + 3
                    val elementLength = cleanLine.substring(elementStart).indexOf("'''")
                    if (elementStart > 3 && elementLength > 0) children.add(cleanLine.substring(elementStart, elementStart + elementLength))
                } else if (cleanLine.endsWith("]")) {
                    // this is a one line list
                    var lineList = cleanLine.substring(cleanLine.indexOf("[") + 1)
                    lineList = lineList.substring(0, lineList.lastIndexOf("]"))
                    for (element in lineList.split(',')) children.add(element.replace("'''", ""))
                } else if (cleanLine.endsWith("[")) {
                    // this is a multiline list
                    continueCurrentItemIndex = true
                }
            }

            val endOfLine = line.split("'''").last()
            if (endOfLine.contains("#") && currentItemChildren != null) {
                if (currentItemChildrenComments == null) currentItemChildrenComments = LinkedHashMap()
                currentItemChildrenComments!![currentItemChildren!!.size - 1] = endOfLine.split("#")[1].trim()
            }
        }

        closeCurrentItem(anchors, pointers, matchedWords, offsetPointers, lists, unmappedConstants, gotoShortcuts, tableGroups)

        this.namedAnchors = anchors
        this.unmappedPointers = pointers
        this.matchedWords = matchedWords
        this.offsetPointers = offsetPointers
        this.unmappedConstants = unmappedConstants
        this.lists = lists
        this.gotoShortcuts = gotoShortcuts
        this.tableGroups = tableGroups
    }
    fun serialize(): Array<String> { /*@DONE StoredMetadata.Serialize/1 cs:254-346*/
        val lines = ArrayList<String>()
        lines.add("[General]")
        if (version != null) lines.add("ApplicationVersion = '''$version'''")
        lines.add("FreeSpaceSearch = '''${freeSpaceSearch.toHex(6)}'''")
        lines.add("FreeSpaceBuffer = '''${freeSpaceBuffer.toHex(3)}'''")
        lines.add("NextExportID = '''$nextExportID'''")
        lines.add("ShowRawIVByteForTrainer = ${if (showRawIVByteForTrainer) "True" else "False"}")
        lines.add("")
        lines.add("#################################")

        for (anchor in namedAnchors) {
            lines.add("[[NamedAnchors]]")
            lines.add("Name = '''${anchor.name}'''")
            lines.add("Address = 0x${anchor.address.toHex(6)}")
            lines.add("Format = '''${anchor.format ?: ""}'''")
            lines.add("DefaultHash = '''${anchor.hash ?: ""}'''")
            lines.add("")
        }

        lines.add("#################################")

        for (pointer in unmappedPointers) {
            lines.add("[[UnmappedPointers]]")
            lines.add("Name = '''${pointer.name}'''")
            lines.add("Address = 0x${pointer.address.toHex(6)}")
            lines.add("")
        }

        lines.add("#################################")

        for (word in matchedWords) {
            lines.add("[[MatchedWords]]")
            lines.add("Name = '''${word.name}'''")
            lines.add("Address = 0x${word.address.toHex(6)}")
            lines.add("Length = ${word.length}")
            if (word.addOffset != 0) lines.add("Offset = ${word.addOffset}")
            if (word.multOffset != 1) lines.add("MultOffset = ${word.multOffset}")
            if (word.note != null) lines.add("Note = '''${word.note}'''")
            lines.add("")
        }

        lines.add("#################################")

        for (offsetPointer in offsetPointers) {
            lines.add("[[OffsetPointer]]")
            lines.add("Address = 0x${offsetPointer.address.toHex(6)}")
            lines.add("Offset = 0x${offsetPointer.offset.toHex(6)}")
            lines.add("")
        }

        lines.add("#################################")

        for (list in lists) {
            list.appendContents(lines)
        }

        lines.add("#################################")

        for (constant in unmappedConstants) {
            lines.add("[[UnmappedConstant]]")
            lines.add("Name = '''${constant.name}'''")
            lines.add("Value = 0x${constant.value.toHex(8)}")
            lines.add("")
        }

        lines.add("#################################")

        for (shortcut in gotoShortcuts) {
            lines.add("[[GotoShortcut]]")
            lines.add("Name = '''${shortcut.display}'''")
            lines.add("Image = '''${shortcut.image ?: ""}'''")
            lines.add("Destination = '''${shortcut.anchor}'''")
            lines.add("")
        }

        lines.add("#################################")

        for (group in tableGroups) {
            lines.add("[[TableGroup]]")
            lines.add("Name = '''${group.groupName}'''")
            lines.add("DefaultHash = '''${group.hash}'''")
            lines.add("0 = [")
            for (table in group.tables) {
                lines.add("   '''$table''',")
            }
            lines.add("]")
            lines.add("")
        }

        return lines.toTypedArray()
    }
    private var currentItem: String? = null
    private var currentItemName: String? = null
    private var currentItemFormat: String? = null
    private var currentItemImage: String? = null
    private var currentItemDestination: String? = null
    private var currentItemHash: String? = null
    private var currentItemChildren: MutableList<String?>? = null
    private var currentItemChildrenComments: MutableMap<Int, String>? = null
    private var continueCurrentItemIndex: Boolean = false
    private var currentItemLength: Int = /*@INITAUTO StoredMetadata.currentItemLength cs:352-352*/ -1 /*@ENDINIT*/
    private var currentItemAddress: Int = /*@INITAUTO StoredMetadata.currentItemAddress cs:353-353*/ -1 /*@ENDINIT*/
    private var currentItemValue: Int = /*@INITAUTO StoredMetadata.currentItemValue cs:354-354*/ -1 /*@ENDINIT*/
    private var currentItemOffset: Int = /*@INITDONE StoredMetadata.currentItemOffset cs:355-355*/ Int.MIN_VALUE /*@ENDINIT*/
    private var currentItemMultOffset: Int = /*@INITAUTO StoredMetadata.currentItemMultOffset cs:356-356*/ 1 /*@ENDINIT*/
    private var currentItemNote: String? = /*@INITAUTO StoredMetadata.currentItemNote cs:357-357*/ null /*@ENDINIT*/
    private fun closeCurrentItem(anchors: MutableList<StoredAnchor>, pointers: MutableList<StoredUnmappedPointer>, matchedWords: MutableList<StoredMatchedWord>, offsetPointers: MutableList<StoredOffsetPointer>, lists: MutableList<StoredList>, unmappedConstants: MutableList<StoredUnmappedConstant>, gotoShortcuts: MutableList<StoredGotoShortcut>, tableGroups: MutableList<TableGroup>) { /*@DONE StoredMetadata.CloseCurrentItem/1 cs:359-426*/
        if (currentItem == "[[UnmappedPointers]]") {
            if (currentItemName == null) throw ArgumentNullException("The Metadata file has an UnmappedPointer that didn't specify a name!")
            if (currentItemAddress == -1) throw ArgumentOutOfRangeException("The Metadata file has an UnmappedPointer that didn't specify an Address!")
            pointers.add(StoredUnmappedPointer(currentItemAddress, currentItemName!!))
        }

        if (currentItem == "[[NamedAnchors]]") {
            if (currentItemName == null) throw ArgumentNullException("The Metadata file has a NamedAnchor that didn't specify a name!")
            if (currentItemAddress == -1) throw ArgumentOutOfRangeException("The Metadata file has a NamedAnchor that didn't specify an Address!")
            anchors.add(StoredAnchor(currentItemAddress, currentItemName!!, currentItemFormat, currentItemHash))
        }

        if (currentItem == "[[MatchedWords]]") {
            if (currentItemName == null) throw ArgumentNullException("The Metadata file has a MatchedWords that didn't specify a Name!")
            if (currentItemAddress == -1) throw ArgumentOutOfRangeException("The Metadata file has a MatchedWord that didn't specify an Address!")
            if (currentItemLength == -1) currentItemLength = 4
            if (currentItemOffset == Int.MIN_VALUE) currentItemOffset = 0
            matchedWords.add(StoredMatchedWord(currentItemAddress, currentItemName!!, currentItemLength, currentItemOffset, currentItemMultOffset, currentItemNote))
        }

        if (currentItem == "[[OffsetPointer]]") {
            if (currentItemAddress == -1) throw ArgumentOutOfRangeException("The Metadata file has an OffsetPointer that didn't specify an Address!")
            if (currentItemOffset == Int.MIN_VALUE) throw ArgumentOutOfRangeException("The Metadata file has an OffsetPointer that didn't specify an Offset!")
            offsetPointers.add(StoredOffsetPointer(currentItemAddress, currentItemOffset))
        }

        if (currentItem == "[[List]]") {
            if (currentItemName == null) throw ArgumentNullException("The Metadata file has a list that didn't specify a name!")
            if (currentItemChildren == null) throw ArgumentNullException("List $currentItemName didn't specify any children!")
            lists.add(StoredList(currentItemName!!, currentItemChildren!!, currentItemChildrenComments, currentItemHash))
        }

        if (currentItem == "[[UnmappedConstant]]") {
            if (currentItemName == null) throw ArgumentNullException("The Metadata file has an unmapped constant that didn't specify a name!")
            if (currentItemValue == -1) throw ArgumentNullException("Unmapped Constant $currentItemName didn't specify a value!")
            unmappedConstants.add(StoredUnmappedConstant(currentItemName!!, currentItemValue))
        }

        if (currentItem == "[[GotoShortcut]]") {
            if (currentItemName == null) throw ArgumentNullException("The Metadata file has a Goto Shortcut that didn't specify a Name!")
            if (currentItemImage == null) throw ArgumentNullException("Goto Shortcut $currentItemName didn't specify an Image!")
            if (currentItemDestination == null) throw ArgumentNullException("Goto Shortcut $currentItemName didn't specify a Destination!")
            gotoShortcuts.add(StoredGotoShortcut(currentItemName!!, currentItemImage!!, currentItemDestination!!))
        }

        if (currentItem == "[[TableGroup]]") {
            if (currentItemName == null) throw ArgumentNullException("The Metadata file has a TableGroup that didn't specify a name!")
            if (currentItemChildren == null) throw ArgumentNullException("TableGroup $currentItemName didn't specify any children!")
            tableGroups.add(TableGroup(currentItemName!!, currentItemChildren!! as List<String>, currentItemHash))
        }

        currentItem = null
        currentItemName = null
        currentItemFormat = null
        currentItemAddress = -1
        currentItemValue = -1
        currentItemOffset = Int.MIN_VALUE
        currentItemMultOffset = 1
        currentItemLength = -1
        continueCurrentItemIndex = false
        currentItemChildren = null
        currentItemChildrenComments = null
        currentItemNote = null
        currentItemImage = null
        currentItemDestination = null
        currentItemHash = null
    }
    companion object {
        fun needVersionUpdate(previousVersion: String?, currentVersion: String?): Boolean { /*@DONE StoredMetadata.NeedVersionUpdate/1 cs:232-252*/
            if (previousVersion == null && currentVersion != null) return true

            var previous = previousVersion!!
            var current = currentVersion!!
            if (previous.startsWith("v")) previous = previous.substring(1)
            while (current.contains("v")) current = current.substring(1)

            while (previous.count { c -> c == '.' } < current.count { c -> c == '.' }) previous += ".0"
            while (current.count { c -> c == '.' } < previous.count { c -> c == '.' }) current += ".0"

            val previousParts = previous.split('.')
            val currentParts = current.split('.')

            for (i in previousParts.indices) {
                val previousValue = Ref(0)
                val currentValue = Ref(0)
                if (!tryParseInt(previousParts[i], previousValue)) return false
                if (!tryParseInt(currentParts[i], currentValue)) return false
                if (previousValue.value < currentValue.value) return true
                if (previousValue.value > currentValue.value) return false
            }

            return false
        }
        /*@END StoredMetadata.Companion*/
    }
    /*@END StoredMetadata*/
}

open class StoredUnmappedPointer { // cs:429-437
    var address: Int = 0
        private set
    var name: String = ""
        private set
    constructor(address: Int, name: String) { /*@DONE StoredUnmappedPointer.<init>/1 cs:433-436*/
        this.address = address
        this.name = name
    }
    /*@END StoredUnmappedPointer*/
}

open class StoredUnmappedConstant { // cs:439-444
    var name: String = ""
        private set
    var value: Int = 0
        private set
    constructor(name: String, value: Int) { /*@DONE StoredUnmappedConstant.<init>/1 cs:443-443*/
        this.name = name
        this.value = value
    }
    /*@END StoredUnmappedConstant*/
}

data class StoredAnchor(val address: Int, val name: String, val format: String?, val hash: String? = null) { // cs:446-446
    /*@END StoredAnchor*/
}

open class StoredMatchedWord { // cs:448-459
    var address: Int = 0
        private set
    var name: String = ""
        private set
    var length: Int = 0
        private set
    var addOffset: Int = 0
        private set
    var multOffset: Int = 0
        private set
    var note: String? = null
        private set
    constructor(address: Int, name: String, length: Int, offset: Int, multOffset: Int, note: String?) { /*@DONE StoredMatchedWord.<init>/1 cs:455-458*/
        Debug.assert(multOffset > 0, "MultOffset must be positive.")
        this.address = address
        this.name = name
        this.length = length
        this.addOffset = offset
        this.multOffset = multOffset
        this.note = note
    }
    /*@END StoredMatchedWord*/
}

open class StoredOffsetPointer { // cs:461-465
    var address: Int = 0
        private set
    var offset: Int = 0
        private set
    constructor(address: Int, offset: Int) { /*@DONE StoredOffsetPointer.<init>/1 cs:464-464*/
        this.address = address
        this.offset = offset
    }
    /*@END StoredOffsetPointer*/
}

open class StoredList : ReadOnlyListMixin<String> { // cs:470-531
    var name: String = ""
        private set
    var contents: List<String?> = ArrayList()
        private set
    var hash: String? = null
        private set
    val hashMatches: Boolean
        get() { /*@DONE StoredList.HashMatches.get cs:474-474*/
            return hash == generateHash(contents)
        }
    var comments: Map<Int, String>? = null
        private set
    constructor(name: String, contents: List<String?>, comments: Map<Int, String>?, hash: String? = null) { /*@DONE StoredList.<init>/1 cs:477-481*/
        this.name = name
        this.hash = hash ?: generateHash(contents)
        this.contents = contents
        this.comments = comments
    }
    fun appendContents(builder: MutableList<String>) { /*@DONE StoredList.AppendContents/1 cs:483-508*/
        builder.add("[[List]]")
        builder.add("Name = '''$name'''")
        if (hash != null) builder.add("DefaultHash = '''$hash'''")
        val allComments = comments
        for (i in 0 until contents.size) {
            val prevNull = i == 0 || contents[i - 1] == null
            val nextNull = i == contents.size - 1 || contents[i + 1] == null

            if (contents[i] != null) {
                var comment = ""
                if (allComments != null) {
                    val c = allComments[i]
                    comment = if (c != null) "# $c" else ""
                }
                if (prevNull && nextNull) {
                    builder.add("$i = '''${contents[i]}'''$comment")
                } else if (prevNull && !nextNull) {
                    builder.add("$i = [")
                    builder.add("   '''${contents[i]}''',$comment")
                } else if (!prevNull && !nextNull) {
                    builder.add("   '''${contents[i]}''',$comment")
                } else {
                    builder.add("   '''${contents[i]}''',$comment")
                    builder.add("]")
                }
            }
        }
        builder.add("")
    }
    override val size: Int
        get() { /*@DONE StoredList.Count.get cs:512-512*/
            return contents.size
        }
    override operator fun get(index: Int): String { /*@DONE StoredList.this/1.get cs:514-514*/
        return contents[index] ?: index.toString()
    }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    companion object {
        fun generateHash(items: Iterable<String?>, seed: UInt = 0xCafeBabeu): String { /*@DONE StoredList.GenerateHash/1 cs:520-530*/
            var hash = seed
            val sha = java.security.MessageDigest.getInstance("SHA-256")
            for (item in items) {
                hash = (hash shl 3) or (hash shr 29)
                if (item == null) continue
                val encoded = sha.digest(item.toByteArray(Charsets.UTF_8))
                hash = hash xor ((encoded[0].toUInt() and 0xFFu) or ((encoded[1].toUInt() and 0xFFu) shl 8) or
                    ((encoded[2].toUInt() and 0xFFu) shl 16) or ((encoded[3].toUInt() and 0xFFu) shl 24))
            }
            return hash.toString(16).uppercase().padStart(8, '0')
        }
        /*@END StoredList.Companion*/
    }
    /*@END StoredList*/
}

open class StoredGotoShortcut { // cs:533-538
    var display: String = ""
        private set
    var image: String? = null
        private set
    var anchor: String = ""
        private set
    constructor(name: String, image: String, destination: String) { /*@DONE StoredGotoShortcut.<init>/1 cs:537-537*/
        display = name
        this.image = image
        anchor = destination
    }
    /*@END StoredGotoShortcut*/
}

open class ValidationList : ArrayList<String> { // cs:540-549
    var storedHash: String = ""
        private set
    var comments: Map<Int, String>? = null
        private set
    constructor(hash: String) { /*@DONE ValidationList.<init>/1 cs:543-543*/
        storedHash = hash
    }
    constructor(hash: String, content: Iterable<String>, comments: Map<Int, String>?) : super(content.toList()) { /*@DONE ValidationList.<init>/2 cs:544-547*/
        storedHash = hash
        this.comments = comments
    }
    val storedHashMatches: Boolean
        get() { /*@DONE ValidationList.StoredHashMatches.get cs:548-548*/
            return storedHash == StoredList.generateHash(this)
        }
    /*@END ValidationList*/
}
