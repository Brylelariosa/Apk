// Port of ViewModels/QuickEditItems/LevelUpMoveSorter.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class LevelUpMoveSorter : IQuickEditItem { // cs:7-42
    override val name: String?
        get() { /*@DONE LevelUpMoveSorter.Name.get cs:8-8*/
            return "Level Up Move Sort"
        }
    override val description: String?
        get() { /*@DONE LevelUpMoveSorter.Description.get cs:10-11*/
            return "Sorts all level-up moves of all Pokemon in ascending order." + NEW_LINE + "By Petuuuhhh (thanks to Haven for walking me through it!)"
        }
    override val wikiLink: String?
        get() { /*@DONE LevelUpMoveSorter.WikiLink.get cs:13-13*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Sorting-Level-Up-Moves-Explained"
        }
    override val canRunChanged = Event<EventArgs>()
    override fun canRun(viewPort: IViewPort): Boolean { /*@DONE LevelUpMoveSorter.CanRun/1 cs:17-20*/
        if (viewPort !is IEditableViewPort) return false
        return viewPort.model?.getTable(HardcodeTablesModel.levelMovesTableName) != null
    }
    override fun run(viewPort: IViewPort): Task<ErrorInfo>? { /*@DONE LevelUpMoveSorter.Run/1 cs:22-39*/
        return asyncTask<ErrorInfo> {
            val viewModel = viewPort as IEditableViewPort
            val model = viewModel.model ?: return@asyncTask ErrorInfo.noError
            val levelUpMoveTable = model.getTable(HardcodeTablesModel.levelMovesTableName) ?: return@asyncTask ErrorInfo.noError
            for (i in 0 until levelUpMoveTable.elementCount) {
                val destination = levelUpMoveTable.readPointer(model, i)
                val moveset = model.getNextRun(destination) as? ITableRun
                if (moveset == null) continue
                val sortedMoves = moveset.sort(model, moveset.elementContent.size - 1)
                viewModel.changeHistory.currentChange.changeData(model, moveset.start, sortedMoves.asByteList())
                viewModel.updateProgress(i.toDouble() / levelUpMoveTable.elementCount).await()
            }

            viewModel.clearProgress()
            viewModel.changeHistory.changeCompleted()
            viewModel.refresh()
            ErrorInfo.noError
        }
    }
    override fun tabChanged() { /*@DONE LevelUpMoveSorter.TabChanged/1 cs:41-41*/
        canRunChanged(this, EventArgs.empty)
    }
    /*@END LevelUpMoveSorter*/
}
