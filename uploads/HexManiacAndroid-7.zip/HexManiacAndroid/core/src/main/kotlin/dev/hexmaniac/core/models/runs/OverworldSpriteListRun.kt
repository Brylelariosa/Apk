// Port of Models/Runs/OverworldSpriteListRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class OverworldSpriteListRun : BaseRun, ITableRun, ISpriteRun { // cs:9-314
    private lateinit var model: IDataModel
    private var parent: List<ArrayRunElementSegment>? = null
    final override var length: Int = 0
        private set
    override val decompressedLength: Int
        get() { /*@DONE OverworldSpriteListRun.DecompressedLength.get cs:17-17*/
            return length
        }
    final override var elementCount: Int = 0
        private set
    var paletteHint: String? = null
        private set
    override val formatString: String
        get() { /*@DONE OverworldSpriteListRun.FormatString.get cs:24-27*/
            if (paletteHint.isNullOrEmpty()) return sharedFormatString
            return AsciiRun.streamDelimeter.toString() + "osl|" + paletteHint + AsciiRun.streamDelimeter
        }
    override val elementLength: Int
        get() { /*@DONE OverworldSpriteListRun.ElementLength.get cs:30-30*/
            return 8
        }
    final override var elementNames: List<String>? = null
        private set
    final override var elementContent: List<ArrayRunElementSegment> = ArrayList()
        private set
    final override var spriteFormat: SpriteFormat = SpriteFormat()
        private set
    override val pages: Int
        get() { /*@DONE OverworldSpriteListRun.Pages.get cs:38-38*/
            return elementCount
        }
    var runIndex: Int = 0
        private set
    override val supportsImport: Boolean
        get() { /*@DONE OverworldSpriteListRun.SupportsImport.get cs:42-42*/
            return true
        }
    override val supportsEdit: Boolean
        get() { /*@DONE OverworldSpriteListRun.SupportsEdit.get cs:43-43*/
            return true
        }
    override val canAppend: Boolean
        get() { /*@DONE OverworldSpriteListRun.CanAppend.get cs:45-45*/
            return true
        }
    constructor(model: IDataModel, parent: List<ArrayRunElementSegment>, paletteHint: String, runIndex: Int, start: Int, sources: SortedSpan<Int>? = null) : this(model, parent, paletteHint, runIndex, start, -1, sources) { /*@DONE OverworldSpriteListRun.<init>/1 cs:47-47*/ }
    private constructor(model: IDataModel, parent: List<ArrayRunElementSegment>?, paletteHint: String?, runIndex: Int, start: Int, elementCount: Int = -1, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE OverworldSpriteListRun.<init>/2 cs:49-150*/
        this.model = model
        this.parent = parent
        this.paletteHint = paletteHint
        this.runIndex = runIndex

        val nextStartBuilder = ArrayList<Int>()
        val parentLength = parent?.sumOf { seg -> seg.length } ?: 0
        if (parent != null && sources != null && sources.size > 0) {
            var nextSource = sources[0] + parentLength
            while (true) {
                if (nextSource < 0 || nextSource + 4 > model.count) break
                val nextDest = model.readPointer(nextSource)
                if (nextDest < 0 || nextDest >= model.count) break
                nextStartBuilder.add(nextDest)
                nextSource += parentLength
            }
        }
        val nextStart = nextStartBuilder.toIntArray()

        val segments = ArrayList<ArrayRunElementSegment>()
        segments.add(ArrayRunPointerSegment(model.formatRunFactory, "sprite", "`ucs4x1x2`"))
        segments.add(ArrayRunElementSegment("length", ElementContentType.Integer, 2))
        segments.add(ArrayRunElementSegment("unused", ElementContentType.Integer, 2))
        this.elementContent = segments
        this.elementCount = 1
        this.elementNames = listOf("")
        this.length = elementLength
        this.spriteFormat = SpriteFormat(4, 1, 1, "")

        if (sources == null || sources.size == 0) return

        // initialize format from parent info
        val parentSegments: List<ArrayRunElementSegment> = parent ?: ArrayList<ArrayRunElementSegment>()
        val listOffset = getOffset<ArrayRunPointerSegment>(parentSegments) { pSeg -> pSeg.innerFormat.startsWith("`osl") }
        var widthOffset = getOffset2(parentSegments) { seg -> seg.name == "width" }
        var heightOffset = getOffset2(parentSegments) { seg -> seg.name == "height" }
        var keyOffset = getOffset2(parentSegments) { seg -> seg.name == "paletteid" }
        if (widthOffset == parentLength) widthOffset = -1
        if (heightOffset == parentLength) heightOffset = -1
        if (keyOffset == parentLength) keyOffset = -1

        val elementStart = sources[0] - listOffset
        var width = if (widthOffset >= 0) maxOf(1, model.readMultiByteValue(elementStart + widthOffset, 2)) else 0
        var height = if (heightOffset >= 0) maxOf(1, model.readMultiByteValue(elementStart + heightOffset, 2)) else 0
        // if there was no height/width found, assume that it's square and based on the first element length
        val pixelCount = model.readMultiByteValue(start + 4, 4) * 2 // number of pixels is twice the number of bytes for all OW sprites
        var adjustDimensions = true
        if (width == 0) { width = Math.sqrt(pixelCount.toDouble()).toInt(); adjustDimensions = true }
        if (height == 0) { height = width; adjustDimensions = true }
        var tileWidth = maxOf(1.0, Math.ceil(width / 8.0)).toInt()
        var tileHeight = maxOf(1.0, Math.ceil(height / 8.0)).toInt()
        if (tileWidth > 30 || tileHeight > 20) return // sanity size check
        while (adjustDimensions && pixelCount > 0) {
            adjustDimensions = false
            while (tileWidth * tileHeight * 64 > pixelCount) {
                adjustDimensions = true
                tileHeight -= 1
            }
            if (tileHeight == 0) break
            while (tileWidth * tileHeight * 64 < pixelCount) {
                if (tileWidth > 500) break
                adjustDimensions = true
                tileWidth += 1
            }
        }

        val key = model.readMultiByteValue(elementStart + keyOffset, 2)
        var hint = HardcodeTablesModel.overworldPalettes + ":id=" + key.toHex(4)
        if (!paletteHint.isNullOrEmpty()) hint = paletteHint + "=" + runIndex.toHex(4)
        if (paletteHint != null && paletteHint.contains("=")) hint = paletteHint + key.toHex(4)

        var format = "`ucs4x" + tileWidth + "x" + tileHeight + "|" + hint + "`"
        if (keyOffset == -1 && paletteHint.isNullOrEmpty()) {
            format = "`ucs4x" + tileWidth + "x" + tileHeight + "`"
            hint = ""
        }
        segments[0] = ArrayRunPointerSegment(model.formatRunFactory, "sprite", format)

        // calculate the element count
        val byteLength = tileWidth * tileHeight * tileSize
        val nextAnchorStart = model.getNextAnchor(start + 1).start
        this.elementCount = 0
        this.length = 0
        if (elementCount == -1) {
            while (this.start + this.length < nextAnchorStart) {
                val destination = model.readPointer(start + this.length)
                if (destination < 0 || destination >= model.count) break
                if (model.readMultiByteValue(start + this.length + 4, 2) != byteLength) break
                if (this.length > 0 && nextStart.contains(start + this.length)) break // metric: if there's a pointer in the parent table that points here, then it's the next list, not this list.
                this.elementCount += 1
                this.length += elementLength
                if (this.elementCount == maxOverworldSprites) break // overworld sprite lists can only have so many elements
            }
        } else {
            this.elementCount = elementCount
            this.length = this.elementCount * elementLength
        }

        this.elementCount = maxOf(this.elementCount, 1)
        this.length = maxOf(elementLength, this.length)
        this.spriteFormat = SpriteFormat(4, tileWidth, tileHeight, hint)
        this.elementNames = this.elementCount.range().map { _ -> "" }
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE OverworldSpriteListRun.CreateDataFormat/1 cs:152-152*/
        return this.createSegmentDataFormat(data, index)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE OverworldSpriteListRun.Clone/1 cs:154-154*/
        return OverworldSpriteListRun(model, parent, paletteHint, runIndex, start, elementCount, newPointerSources)
    }
    override fun append(token: ModelDelta, length: Int): ITableRun { /*@DONE OverworldSpriteListRun.Append/1 cs:156-172*/
        val naturalLength = this.length
        val newRun = model.relocateForExpansion(token, this, naturalLength + length * elementLength)

        // add new element data
        for (i in 0 until elementLength * length) {
            var prevIndex = newRun.start + naturalLength + i - newRun.elementLength * length
            while (prevIndex < newRun.start) prevIndex += newRun.elementLength
            val prevData = if (prevIndex >= newRun.start) model[prevIndex] else 0
            token.changeData(model, newRun.start + naturalLength + i, prevData)
        }

        // remove excess element data
        for (i in naturalLength + length * elementLength until naturalLength) token.changeData(model, newRun.start + i, 0xFF)

        return OverworldSpriteListRun(model, parent, paletteHint, runIndex, newRun.start, -1, pointerSources)
    }
    override fun duplicate(start: Int, pointerSources: SortedSpan<Int>?, segments: List<ArrayRunElementSegment>): ITableRun { /*@DONE OverworldSpriteListRun.Duplicate/1 cs:174-174*/
        throw NotImplementedException()
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE OverworldSpriteListRun.AppendTo/1 cs:176-176*/
        ITableRunExtensions.appendTo(this, model, builder, start, length, depth)
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE OverworldSpriteListRun.Clear/1 cs:178-180*/
        for (i in 0 until length) changeToken.changeData(model, start + i, 0)
    }
    fun updateFromParent(token: ModelDelta, segmentIndex: Int, pointerSource: Int, spritesMoved: Ref<Boolean>): OverworldSpriteListRun { /*@DONE OverworldSpriteListRun.UpdateFromParent/1 cs:182-215*/
        spritesMoved.value = false
        val tableSource = model.getNextRun(pointerSource) as? ITableRun ?: return this
        val segName = tableSource.elementContent[segmentIndex].name
        if (!segName.isAny("width", "height", "paletteid")) return this

        // if parent width changed, add/subtract space to the right edge of the sprite. Min width is one tile.
        // if the parent height changed, add/subtract space to the bottom of the sprite. Min height is one tile.
        if (segName == "width" || segName == "height") {
            val parentSegments: List<ArrayRunElementSegment> = parent ?: ArrayList<ArrayRunElementSegment>()
            val listOffset = getOffset<ArrayRunPointerSegment>(parentSegments) { pSeg -> pSeg.innerFormat == sharedFormatString }
            val elementStart = pointerSources!![0] - listOffset
            val widthOffset = getOffset2(parentSegments) { seg -> seg.name == "width" }
            val heightOffset = getOffset2(parentSegments) { seg -> seg.name == "height" }
            val width = maxOf(1, model.readMultiByteValue(elementStart + widthOffset, 2))
            val height = maxOf(1, model.readMultiByteValue(elementStart + heightOffset, 2))
            val newTileWidth = maxOf(1.0, Math.ceil(width / 8.0)).toInt()
            val newTileHeight = maxOf(1.0, Math.ceil(height / 8.0)).toInt()
            val movedRuns = ArrayList<ISpriteRun>()
            for (i in 0 until elementCount) {
                val spriteStart = model.readPointer(start + elementLength * i)
                var sprite = model.getNextRun(spriteStart) as? ISpriteRun
                if (sprite != null && !movedRuns.contains(sprite)) {
                    sprite = resize(model, token, sprite, newTileWidth, newTileHeight)
                    if (sprite != null) movedRuns.add(sprite)
                }
                val spriteLengthStart = start + elementLength * i + 4
                model.writeMultiByteValue(spriteLengthStart, 4, token, newTileWidth * newTileHeight * tileSize)
                if (sprite != null) spritesMoved.value = spritesMoved.value || (spriteStart != sprite.start)
            }
        }

        // if the parent paletteid changed, we just need to update the format, no data change is required.
        return OverworldSpriteListRun(model, parent, paletteHint, runIndex, start, -1, pointerSources)
    }
    override fun getData(): ByteArray { /*@DONE OverworldSpriteListRun.GetData/1 cs:257-266*/
        val pageSize = spriteFormat.tileWidth * spriteFormat.tileHeight * 32
        val result = ByteArray(pageSize * pages)
        for (i in 0 until pages) {
            val spriteStart = model.readPointer(start + elementLength * i)
            val spriteRun = model.getNextRun(spriteStart)
            val page = if (spriteRun is ISpriteRun) spriteRun.getData() else ByteArray(pageSize)
            System.arraycopy(page, 0, result, pageSize * i, pageSize)
        }
        return result
    }
    override fun getPixels(model: IDataModel, page: Int, arrayIndex: Int): Array<IntArray>? { /*@DONE OverworldSpriteListRun.GetPixels/1 cs:269-277*/
        val width = spriteFormat.tileWidth * 8
        val height = spriteFormat.tileHeight * 8
        val spriteStart = model.readPointer(start + elementLength * page)
        val spriteRun = model.getNextRun(spriteStart)
        if (spriteRun !is ISpriteRun) return Array(width) { IntArray(height) }
        val spritePixels = spriteRun.getPixels(model, 0, -1) ?: return Array(width) { IntArray(height) }
        if (spritePixels.getLength(0) < width || spritePixels.getLength(1) < height) return Array(width) { IntArray(height) }
        return spritePixels
    }
    private fun getPixels1(model: IDataModel, page: Int): Array<IntArray> { /*@DONE OverworldSpriteListRun.GetPixels1/1 cs:280-300*/
        val width = spriteFormat.tileWidth * 8 / elementCount
        val height = spriteFormat.tileHeight * 8

        val overallPixels = Array(width * elementCount) { IntArray(height) }

        for (i in 0 until elementCount) {
            val spriteStart = model.readPointer(start + elementLength * i)
            val spriteRun = model.getNextRun(spriteStart)
            if (spriteRun !is ISpriteRun) continue
            val spritePixels = spriteRun.getPixels(model, 0, -1) ?: continue
            if (spritePixels.getLength(0) < width || spritePixels.getLength(1) < height) continue
            val offset = width * i
            for (x in 0 until width) {
                for (y in 0 until height) {
                    overallPixels[offset + x][y] = spritePixels[x][y]
                }
            }
        }

        return overallPixels
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>): ISpriteRun { /*@DONE OverworldSpriteListRun.SetPixels/1 cs:302-308*/
        val spriteStart = model.readPointer(start + elementLength * page)
        val spriteRun = model.getNextRun(spriteStart)
        if (spriteRun !is ISpriteRun) return this

        spriteRun.setPixels(model, token, 0, pixels)
        return this // moving a page will never move the list
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, tiles: List<Array<IntArray>>): ISpriteRun { /*@DONE OverworldSpriteListRun.SetPixels/2 cs:311-311*/
        throw NotImplementedException()
    }
    override fun duplicate(newFormat: SpriteFormat): ISpriteRun { /*@DONE OverworldSpriteListRun.Duplicate/2 cs:313-313*/
        return OverworldSpriteListRun(model, parent, paletteHint, runIndex, start, -1, pointerSources)
    }
    companion object {
        private const val maxOverworldSprites: Int = 27
        val sharedFormatString: String = /*@INITDONE OverworldSpriteListRun.SharedFormatString cs:13-13*/ AsciiRun.streamDelimeter.toString() + "osl" + AsciiRun.streamDelimeter /*@ENDINIT*/
        private inline fun <reified T : ArrayRunElementSegment> getOffset(segments: List<ArrayRunElementSegment>, crossinline segmentIdentifier: (T) -> Boolean): Int { /*@DONE OverworldSpriteListRun.GetOffset/1 cs:217-218*/
            return segments.until { seg -> seg is T && segmentIdentifier(seg) }.sumOf { seg -> seg.length }
        }
        private fun getOffset2(segments: List<ArrayRunElementSegment>, segmentIdentifier: (ArrayRunElementSegment) -> Boolean): Int { /*@DONE OverworldSpriteListRun.GetOffset/2 cs:220-221*/
            return segments.until(segmentIdentifier).sumOf { seg -> seg.length }
        } // FIXME-SKEL renamed overload
        private const val tileSize: Int = 32
        private fun resize(model: IDataModel, token: ModelDelta, spriteRun: ISpriteRun?, tileWidth: Int, tileHeight: Int): ISpriteRun? { /*@DONE OverworldSpriteListRun.Resize/1 cs:224-255*/
            if (spriteRun == null) return null
            val run = model.relocateForExpansion(token, spriteRun, tileWidth * tileHeight * tileSize)
            val format = run.spriteFormat

            // extract existing tile data
            val existingTiles = Array(format.tileWidth) { Array(format.tileHeight) { ByteArray(tileSize) } }
            for (x in 0 until format.tileWidth) {
                for (y in 0 until format.tileHeight) {
                    val tileIndex = y * format.tileWidth + x
                    System.arraycopy(model.rawData, run.start + tileIndex * tileSize, existingTiles[x][y], 0, tileSize)
                }
            }

            // rewrite it with the new dimensions
            for (x in 0 until tileWidth) {
                for (y in 0 until tileHeight) {
                    val tileIndex = y * tileWidth + x
                    val tileStart = run.start + tileIndex * tileSize
                    for (i in 0 until tileSize) {
                        if (x < format.tileWidth && y < format.tileHeight) {
                            token.changeData(model, tileStart + i, existingTiles[x][y][i].toInt() and 0xFF)
                        } else {
                            token.changeData(model, tileStart + i, 0)
                        }
                    }
                }
            }

            return run
        }
        /*@END OverworldSpriteListRun.Companion*/
    }
    /*@END OverworldSpriteListRun*/
}
