// Port of Models/ModelDelta.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*

open class ModelDelta : IChangeToken { // cs:13-252
    private val oldData: MutableMap<Int, Int> = /*@INITAUTO ModelDelta.oldData cs:14-14*/ LinkedHashMap() /*@ENDINIT*/
    private val addedRuns: MutableMap<Int, IFormattedRun> = /*@INITAUTO ModelDelta.addedRuns cs:16-16*/ LinkedHashMap() /*@ENDINIT*/
    private val removedRuns: MutableMap<Int, IFormattedRun> = /*@INITAUTO ModelDelta.removedRuns cs:17-17*/ LinkedHashMap() /*@ENDINIT*/
    private val addedNames: MutableMap<Int, String> = /*@INITAUTO ModelDelta.addedNames cs:19-20*/ LinkedHashMap() /*@ENDINIT*/
    private val removedNames: MutableMap<Int, String> = /*@INITAUTO ModelDelta.removedNames cs:19-21*/ LinkedHashMap() /*@ENDINIT*/
    private val addedUnmappedPointers: MutableMap<Int, String> = /*@INITAUTO ModelDelta.addedUnmappedPointers cs:19-22*/ LinkedHashMap() /*@ENDINIT*/
    private val removedUnmappedPointers: MutableMap<Int, String> = /*@INITAUTO ModelDelta.removedUnmappedPointers cs:19-23*/ LinkedHashMap() /*@ENDINIT*/
    private val addedMatchedWords: MutableMap<Int, String> = /*@INITAUTO ModelDelta.addedMatchedWords cs:19-24*/ LinkedHashMap() /*@ENDINIT*/
    private val removedMatchedWords: MutableMap<Int, String> = /*@INITAUTO ModelDelta.removedMatchedWords cs:19-25*/ LinkedHashMap() /*@ENDINIT*/
    private val addedOffsetPointers: MutableMap<Int, Int> = /*@INITAUTO ModelDelta.addedOffsetPointers cs:27-28*/ LinkedHashMap() /*@ENDINIT*/
    private val removedOffsetPointers: MutableMap<Int, Int> = /*@INITAUTO ModelDelta.removedOffsetPointers cs:27-29*/ LinkedHashMap() /*@ENDINIT*/
    private val addedUnmappedConstants: MutableMap<String, Int> = /*@INITAUTO ModelDelta.addedUnmappedConstants cs:31-32*/ LinkedHashMap() /*@ENDINIT*/
    private val removedUnmappedConstants: MutableMap<String, Int> = /*@INITAUTO ModelDelta.removedUnmappedConstants cs:31-33*/ LinkedHashMap() /*@ENDINIT*/
    private val addedLists: MutableMap<String, ValidationList> = /*@INITAUTO ModelDelta.addedLists cs:35-36*/ LinkedHashMap() /*@ENDINIT*/
    private val removedLists: MutableMap<String, ValidationList> = /*@INITAUTO ModelDelta.removedLists cs:35-37*/ LinkedHashMap() /*@ENDINIT*/
    private var oldDataLength: Int = /*@INITAUTO ModelDelta.oldDataLength cs:39-39*/ -1 /*@ENDINIT*/
    private var newDataLength: Int = /*@INITAUTO ModelDelta.newDataLength cs:39-39*/ -1 /*@ENDINIT*/
    var doNotClearConstants: Boolean = false
    override val onNewChange = Event<EventArgs>()
    protected fun notifyOnNewChange() { /*@DONE ModelDelta.NotifyOnNewChange/1 cs:44-44*/
        onNewChange(this, EventArgs.empty)
    }
    override var hasDataChange: Boolean = false
        protected set
    override val hasAnyChange: Boolean
        get() { /*@DONE ModelDelta.HasAnyChange.get cs:46-59*/
            return hasDataChange ||
                addedRuns.isNotEmpty() ||
                removedRuns.isNotEmpty() ||
                addedNames.isNotEmpty() ||
                removedNames.isNotEmpty() ||
                addedMatchedWords.isNotEmpty() ||
                removedMatchedWords.isNotEmpty() ||
                addedUnmappedPointers.isNotEmpty() ||
                removedUnmappedPointers.isNotEmpty() ||
                addedUnmappedConstants.isNotEmpty() ||
                removedLists.isNotEmpty() ||
                addedLists.isNotEmpty() ||
                removedUnmappedConstants.isNotEmpty()
        }
    val earliestChange: Int
        get() { /*@DONE ModelDelta.EarliestChange.get cs:62-80*/
            if (oldData.size > 0) return oldData.keys.min()

            if (addedNames.size > 0) return addedNames.keys.min()

            var filteredRuns = addedRuns.values.filter { added -> added !is NoInfoRun }
            if (filteredRuns.isNotEmpty()) return filteredRuns.minOf { added -> added.start }

            if (addedUnmappedPointers.size > 0) return addedUnmappedPointers.keys.min()

            if (removedNames.size > 0) return removedNames.keys.min()

            filteredRuns = removedRuns.values.filter { removed -> removed !is NoInfoRun }
            if (filteredRuns.isNotEmpty()) return filteredRuns.minOf { removed -> removed.start }

            if (removedUnmappedPointers.size > 0) return removedUnmappedPointers.keys.min()

            return -1
        }
    open fun changeData(model: IDataModel, index: Int, data: Int): Boolean { /*@DONE ModelDelta.ChangeData/1 cs:83-100*/
        if (model.count > index && model[index] == data) return false
        if (!oldData.containsKey(index)) {
            if (model.count <= index) {
                model.expandData(this, index)
            }
            oldData[index] = model[index]
        }

        val valueChanged = model[index] != data
        model[index] = data
        if (!hasDataChange) {
            hasDataChange = true
            onNewChange(this, EventArgs.empty)
        }

        return valueChanged
    }
    fun changeData(model: IDataModel, index: Int, array: ByteList): Boolean { /*@DONE ModelDelta.ChangeData/2 cs:102-106*/
        var anyChanges = false
        for (i in 0 until array.count) anyChanges = changeData(model, index + i, array[i]) or anyChanges
        return anyChanges
    }
    fun setDataLength(model: IDataModel, length: Int): Boolean { /*@DONE ModelDelta.SetDataLength/1 cs:108-118*/
        if (oldDataLength == -1) oldDataLength = model.rawData.size
        newDataLength = length
        if (!hasAnyChange) {
            hasDataChange = hasDataChange or (oldDataLength != newDataLength)
            if (hasDataChange) {
                onNewChange(this, EventArgs.empty)
            }
        }
        return true
    }
    fun changeList(name: String, oldValues: ValidationList?, newValues: ValidationList) { /*@DONE ModelDelta.ChangeList/1 cs:120-125*/
        captureNonDataChange().using {
            if (oldValues != null && !removedLists.containsKey(name)) removedLists[name] = oldValues
            addedLists[name] = newValues
        }
    }
    fun addRun(run: IFormattedRun) { /*@DONE ModelDelta.AddRun/1 cs:127-130*/
        captureNonDataChange().using { addedRuns[run.start] = run }
    }
    fun removeRun(run: IFormattedRun) { /*@DONE ModelDelta.RemoveRun/1 cs:132-139*/
        captureNonDataChange().using {
            if (addedRuns.containsKey(run.start)) {
                addedRuns.remove(run.start)
            } else if (!removedRuns.containsKey(run.start)) {
                removedRuns[run.start] = run
            }
        }
    }
    fun addName(index: Int, name: String) { /*@DONE ModelDelta.AddName/1 cs:141-144*/
        captureNonDataChange().using { addedNames[index] = name }
    }
    fun removeName(index: Int, name: String) { /*@DONE ModelDelta.RemoveName/1 cs:146-153*/
        captureNonDataChange().using {
            if (addedNames.containsKey(index)) {
                addedNames.remove(index)
            } else if (!removedNames.containsKey(index)) {
                removedNames[index] = name
            }
        }
    }
    fun addUnmappedPointer(index: Int, name: String) { /*@DONE ModelDelta.AddUnmappedPointer/1 cs:155-158*/
        captureNonDataChange().using { addedUnmappedPointers[index] = name }
    }
    fun removeUnmappedPointer(index: Int, name: String) { /*@DONE ModelDelta.RemoveUnmappedPointer/1 cs:160-167*/
        captureNonDataChange().using {
            if (addedUnmappedPointers.containsKey(index)) {
                addedUnmappedPointers.remove(index)
            } else if (!removedUnmappedPointers.containsKey(index)) {
                removedUnmappedPointers[index] = name
            }
        }
    }
    fun revert(model: IDataModel): ModelDelta { /*@DONE ModelDelta.Revert/1 cs:169-207*/
        val reverse = ModelDelta()
        reverse.hasDataChange = hasDataChange

        for ((index, data) in oldData) {
            reverse.oldData[index] = if (model.count > index) model[index] else 0xFF
            if (model.count > index) model[index] = data
        }

        for ((k, v) in addedRuns) reverse.removedRuns[k] = v
        for ((k, v) in removedRuns) reverse.addedRuns[k] = v
        for ((k, v) in addedNames) reverse.removedNames[k] = v
        for ((k, v) in removedNames) reverse.addedNames[k] = v
        for ((k, v) in addedLists) reverse.removedLists[k] = v
        for ((k, v) in removedLists) reverse.addedLists[k] = v
        for ((k, v) in addedMatchedWords) reverse.removedMatchedWords[k] = v
        for ((k, v) in removedMatchedWords) reverse.addedMatchedWords[k] = v
        for ((k, v) in addedOffsetPointers) reverse.removedOffsetPointers[k] = v
        for ((k, v) in removedOffsetPointers) reverse.addedOffsetPointers[k] = v
        for ((k, v) in addedUnmappedPointers) reverse.removedUnmappedPointers[k] = v
        for ((k, v) in removedUnmappedPointers) reverse.addedUnmappedPointers[k] = v
        for ((k, v) in addedUnmappedConstants) reverse.removedUnmappedConstants[k] = v
        for ((k, v) in removedUnmappedConstants) reverse.addedUnmappedConstants[k] = v

        if (oldDataLength != -1 || newDataLength != -1) {
            model.expandData(reverse, oldDataLength - 1)
            model.contractData(reverse, oldDataLength - 1)
        }

        model.massUpdateFromDelta(addedRuns, removedRuns,
            addedNames, removedNames,
            addedUnmappedPointers, removedUnmappedPointers,
            addedMatchedWords, removedMatchedWords,
            addedOffsetPointers, removedOffsetPointers,
            addedUnmappedConstants, removedUnmappedConstants,
            addedLists, removedLists)

        return reverse
    }
    fun addMatchedWord(model: IDataModel, memoryLocation: Int, parentName: String, byteCount: Int) { /*@DONE ModelDelta.AddMatchedWord/1 cs:209-215*/
        val parentAddress = model.getAddressFromAnchor(this, -1, parentName)
        val parent = model.getNextRun(parentAddress) as? ArrayRun
        if (parent != null && this !is NoDataChangeDeltaModel) model.writeMultiByteValue(memoryLocation, byteCount, this, parent.elementCount)
        captureNonDataChange().using { addedMatchedWords[memoryLocation] = parentName }
    }
    fun removeMatchedWord(memoryLocation: Int, parentName: String) { /*@DONE ModelDelta.RemoveMatchedWord/1 cs:217-221*/
        captureNonDataChange().using {
            if (addedMatchedWords.containsKey(memoryLocation)) addedMatchedWords.remove(memoryLocation)
            else removedMatchedWords[memoryLocation] = parentName
        }
    }
    fun addOffsetPointer(start: Int, offset: Int) { /*@DONE ModelDelta.AddOffsetPointer/1 cs:223-226*/
        captureNonDataChange().using { addedOffsetPointers[start] = offset }
    }
    fun removeOffsetPointer(start: Int, offset: Int) { /*@DONE ModelDelta.RemoveOffsetPointer/1 cs:228-232*/
        captureNonDataChange().using {
            if (addedOffsetPointers.containsKey(start)) addedMatchedWords.remove(start)
            else removedOffsetPointers[start] = offset
        }
    }
    fun addUnmappedConstant(name: String, value: Int) { /*@DONE ModelDelta.AddUnmappedConstant/1 cs:234-237*/
        captureNonDataChange().using { addedUnmappedConstants[name] = value }
    }
    fun removeUnmappedConstant(name: String, value: Int) { /*@DONE ModelDelta.RemoveUnmappedConstant/1 cs:239-243*/
        captureNonDataChange().using {
            if (addedUnmappedConstants.containsKey(name)) addedUnmappedConstants.remove(name)
            else removedUnmappedConstants[name] = value
        }
    }
    private fun captureNonDataChange(): IDisposable { /*@DONE ModelDelta.CaptureNonDataChange/1 cs:245-251*/
        if (hasAnyChange) return StubDisposable()
        return StubDisposable {
            if (!hasAnyChange) return@StubDisposable
            onNewChange(this, EventArgs.empty)
        }
    }
    /*@END ModelDelta*/
}

open class NoDataChangeDeltaModel : ModelDelta() { // cs:254-258
    override fun changeData(model: IDataModel, index: Int, data: Int): Boolean { /*@DONE NoDataChangeDeltaModel.ChangeData/1 cs:255-257*/
        throw InvalidOperationException("This operation is not allowed to change model data!")
    }
    /*@END NoDataChangeDeltaModel*/
}

open class TransientModelDelta : NoDataChangeDeltaModel() { // cs:264-264
    /*@END TransientModelDelta*/
}

open class NoTrackChange : ModelDelta() { // cs:266-279
    override fun changeData(model: IDataModel, index: Int, data: Int): Boolean { /*@DONE NoTrackChange.ChangeData/1 cs:267-278*/
        if (model.count > index && model[index] == data) return false
        if (model.count <= index) model.expandData(this, index)
        val valueChanged = model[index] != data
        model[index] = data
        if (!hasDataChange) {
            hasDataChange = true
            notifyOnNewChange()
        }

        return valueChanged
    }
    /*@END NoTrackChange*/
}
