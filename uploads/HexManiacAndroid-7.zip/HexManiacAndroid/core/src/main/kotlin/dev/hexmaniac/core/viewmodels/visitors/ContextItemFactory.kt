// Port of ViewModels/Visitors/ContextItemFactory.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.visitors

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.system.ICommandExtensions.canAlwaysExecute

interface IContextItem { // cs:14-19
    val text: String?
    val command: ICommand
    val parameter: Any?
    val shortcutText: String
    /*@END IContextItem*/
}

open class ContextItem : IContextItem { // cs:21-31
    final override var text: String? = null
        private set
    final override lateinit var command: ICommand
        private set
    final override var parameter: Any? = null
        private set
    override var shortcutText: String = ""
    constructor(text: String, action: ((Any?) -> Unit)?, parameter: Any? = null) { /*@DONE ContextItem.<init>/1 cs:26-30*/
        this.text = text
        val stub = StubCommand()
        if (action == null) {
            stub.canExecute = { _ -> false }
        } else {
            stub.canExecute = { p -> canAlwaysExecute(p) }
        }
        stub.execute = action
        this.command = stub
        this.parameter = parameter
    }
    /*@END ContextItem*/
}

open class DisabledContextItem : IContextItem { // cs:33-43
    final override var text: String? = null
        private set
    final override lateinit var command: ICommand
        private set
    final override var parameter: Any? = null
        private set
    override var shortcutText: String = ""
    constructor(text: String, parameter: Any? = null) { /*@DONE DisabledContextItem.<init>/1 cs:38-42*/
        this.text = text
        val stub = StubCommand()
        stub.canExecute = { _ -> false }
        stub.execute = { _ -> }
        this.command = stub
        this.parameter = parameter
    }
    /*@END DisabledContextItem*/
}

open class CompositeContextItem : ArrayList<IContextItem>, IContextItem { // cs:48-59
    override val text: String?
        get() { /*@DONE CompositeContextItem.Text.get cs:49-49*/
            throw NotImplementedException()
        }
    override val command: ICommand
        get() { /*@DONE CompositeContextItem.Command.get cs:50-50*/
            throw NotImplementedException()
        }
    override val parameter: Any
        get() { /*@DONE CompositeContextItem.Parameter.get cs:51-51*/
            throw NotImplementedException()
        }
    override val shortcutText: String
        get() { /*@DONE CompositeContextItem.ShortcutText.get cs:52-52*/
            throw NotImplementedException()
        }
    constructor(command: (Any?) -> Unit, vararg text: String) { /*@DONE CompositeContextItem.<init>/1 cs:54-58*/
        for (item in text) {
            add(ContextItem(item, command, item))
        }
    }
    /*@END CompositeContextItem*/
}

open class ContextItemGroup : ArrayList<IContextItem>, IContextItem { // cs:64-71
    final override var text: String? = null
        private set
    override val command: ICommand
        get() { /*@DONE ContextItemGroup.Command.get cs:66-66*/
            throw NotImplementedException()
        }
    override val parameter: Any
        get() { /*@DONE ContextItemGroup.Parameter.get cs:67-67*/
            throw NotImplementedException()
        }
    override val shortcutText: String
        get() { /*@DONE ContextItemGroup.ShortcutText.get cs:68-68*/
            throw NotImplementedException()
        }
    constructor(label: String) { /*@DONE ContextItemGroup.<init>/1 cs:70-70*/
        this.text = label
    }
    /*@END ContextItemGroup*/
}

open class ContextItemFactory : IDataFormatVisitor { // cs:73-310
    lateinit var viewPort: ViewPort
        private set
    var results: MutableList<IContextItem> = /*@INITAUTO ContextItemFactory.Results cs:75-75*/ ArrayList() /*@ENDINIT*/
        private set
    constructor(parent: ViewPort) { /*@DONE ContextItemFactory.<init>/1 cs:77-77*/
        this.viewPort = parent
    }
    override fun visit(dataFormat: Undefined, data: Int) { /*@DONE ContextItemFactory.Visit/1 cs:79-79*/
        visit(None.instance, data)
    }
    override fun visit(dataFormat: None, data: Int) { /*@DONE ContextItemFactory.Visit/2 cs:81-111*/
        val displayAs = ContextItemGroup("Display As...")
        displayAs.add(ContextItem("Text", viewPort.shortcuts.displayAsText::execute).also { it.shortcutText = "Ctrl+D, T" })
        displayAs.add(ContextItem("Sprite", viewPort.shortcuts.displayAsSprite::execute).also { it.shortcutText = "Ctrl+D, S" })
        displayAs.add(ContextItem("Color Palette", viewPort.shortcuts.displayAsColorPalette::execute).also { it.shortcutText = "Ctrl+D, C" })
        displayAs.add(ContextItem("Event Script", viewPort.shortcuts.displayAsEventScript::execute).also { it.shortcutText = "Ctrl+D, E" })
        results.add(displayAs)

        if (data == 0xFF && viewPort.selectionEnd == viewPort.selectionStart && viewPort[viewPort.selectionStart].format is None) {
            val createNew = ContextItemGroup("Create New...")
            createNew.add(ContextItem("Event Script", { _ ->
                val newScriptStart = viewPort.convertViewPointToAddress(viewPort.selectionStart)
                // write the 'end' command
                viewPort.currentChange.changeData(viewPort.model, newScriptStart, 2)
                viewPort.model.observeAnchorWritten(viewPort.currentChange, "scripts.new.xse_" + newScriptStart.toHex(6), XSERun(newScriptStart))
                val name = viewPort.model.getAnchorFromAddress(-1, newScriptStart)
                viewPort.refresh()
                viewPort.updateToolsFromSelection(newScriptStart)
                viewPort.anchorTextSelectionStart = 1
                viewPort.anchorTextSelectionLength = name.length
            }))
            // new ContextItem("Compressed Sprite", arg => { /* TODO what dimensions? */ }),
            // new ContextItem("Compressed Palette", arg => { /* TODO how many pages? */ }),
            results.add(createNew)
        }

        var start = viewPort.convertViewPointToAddress(viewPort.selectionStart)
        var end = viewPort.convertViewPointToAddress(viewPort.selectionEnd)
        if (start > end) {
            val swap = start
            start = end
            end = swap
        }
        if ((viewPort.model.getNextRun(start) ?: NoInfoRun.nullRun).start < end) {
            results.addAll(getFormattedChildren())
        }
    }
    override fun visit(dataFormat: UnderEdit, data: Int) { /*@DONE ContextItemFactory.Visit/3 cs:113-113*/
        // nothing to add while a cell is being edited
    }
    override fun visit(pointer: Pointer, data: Int) { /*@DONE ContextItemFactory.Visit/4 cs:115-147*/
        val point = viewPort.selectionStart

        val group = ContextItemGroup("Pointer Operations")

        group.add(ContextItem("Follow Pointer", { _ -> viewPort.followLink(point.x, point.y) }).also { it.shortcutText = "Ctrl+Click" })

        val pointerAddress = viewPort.convertViewPointToAddress(point)
        val pointerDestination = viewPort.model.readPointer(pointerAddress)
        if (pointerDestination == Pointer.null_) {
            group.add(ContextItem("Create New Data", { _ ->
                viewPort.repointToNewCopy(pointerAddress)
                viewPort.refresh()
            }))
        } else {
            val destination = viewPort.model.getNextRun(pointerDestination) ?: NoInfoRun.nullRun
            val destinationSources = destination.pointerSources
            if (destination !is NoInfoRun && destinationSources != null && destinationSources.size > 1) {
                group.add(ContextItem("Repoint to New Copy", { _ ->
                    viewPort.repointToNewCopy(pointerAddress)
                    viewPort.refresh()
                }))
            }
            group.add(ContextItem("Open in New Tab", { _ -> viewPort.openInNewTab(pointerDestination) }))
        }

        results.add(group)

        val arrayRun = viewPort.model.getNextRun(pointerAddress)
        if (arrayRun is ITableRun && arrayRun.start <= pointerAddress) {
            results.addAll(getTableChildren())
        } else {
            results.addAll(getFormattedChildren())
        }
    }
    override fun visit(anchor: Anchor, data: Int) { /*@DONE ContextItemFactory.Visit/5 cs:149-173*/
        val selectionStartAddress = viewPort.convertViewPointToAddress(viewPort.selectionStart)
        val anchorName: String? = anchor.name
        var name: String = if (anchorName.isNullOrEmpty()) "Anchor " + selectionStartAddress.toHex(6) else anchorName
        name = name.replace("_", "__")

        val group = ContextItemGroup(name)

        val tableRun = viewPort.model.getNextRun(selectionStartAddress)
        if (tableRun is ITableRun && tableRun.start == selectionStartAddress) {
            if (tableRun.start != viewPort.dataOffset || tableRun.elementLength != viewPort.preferredWidth) {
                val gotoCommand = viewPort.goto!!
                group.add(ContextItem("Align Here", gotoCommand::execute, tableRun.start))
            } else {
                group.add(DisabledContextItem("Align Here"))
            }
        }

        group.addAll(getAnchorSourceItems(selectionStartAddress))

        results.add(group)

        anchor.originalFormat!!.visit(this, data)

        if (anchor.originalFormat is None && !results.any { option -> option is ContextItem && option.text == "Clear Format" }) {
            results.addAll(getFormattedChildren())
        }
    }
    fun getAnchorSourceItems(address: Int): Iterable<ContextItem> { /*@DONE ContextItemFactory.GetAnchorSourceItems/1 cs:175-197*/
        val items = ArrayList<ContextItem>()
        val run = viewPort.model.getNextRun(address) ?: NoInfoRun.nullRun
        var sources = run.pointerSources
        if (run is ArrayRun && run.supportsInnerPointers && address != run.start) {
            val index = (address - run.start) / run.elementLength
            sources = run.pointerSourcesForInnerElements!![index]
        }
        if (sources == null || sources.size == 0) {
            items.add(ContextItem("(Nothing points to this.)", null))
            return items
        }

        if (sources.size > 1) {
            items.add(ContextItem("Show All Sources in new tab", { _ ->
                viewPort.findAllSources(address)
            }))
        }

        val gotoCommand = viewPort.goto!!
        val destinations = sources.map { source -> source.toAddress() }
        for (destination in destinations) {
            items.add(ContextItem(destination, gotoCommand::execute, destination))
        }
        return items
    }
    override fun visit(sprite: SpriteDecorator, data: Int) { /*@DONE ContextItemFactory.Visit/6 cs:199-199*/
        sprite.originalFormat!!.visit(this, data)
    }
    override fun visit(decorator: StreamEndDecorator, data: Int) { /*@DONE ContextItemFactory.Visit/7 cs:201-201*/
        decorator.originalFormat!!.visit(this, data)
    }
    override fun visit(pcs: PCS, data: Int) { /*@DONE ContextItemFactory.Visit/8 cs:203-213*/
        visitPcsLike()
    }
    override fun visit(pcs: EscapedPCS, data: Int) { /*@DONE ContextItemFactory.Visit/9 cs:215-215*/
        visitPcsLike()
    }
    override fun visit(pcs: ErrorPCS, data: Int) { /*@DONE ContextItemFactory.Visit/10 cs:217-217*/
        visitPcsLike()
    }
    override fun visit(ascii: Ascii, data: Int) { /*@DONE ContextItemFactory.Visit/11 cs:219-219*/
        results.addAll(getFormattedChildren())
    }
    override fun visit(braille: Braille, data: Int) { /*@DONE ContextItemFactory.Visit/12 cs:221-221*/
        results.addAll(getFormattedChildren())
    }
    override fun visit(integer: Integer, data: Int) { /*@DONE ContextItemFactory.Visit/13 cs:223-229*/
        val tableTool = viewPort.tools?.tableTool
        if (tableTool != null && viewPort.model.getNextRun(tableTool.address) is ITableRun) {
            results.addAll(getTableChildren())
        } else {
            results.addAll(getFormattedChildren())
        }
    }
    override fun visit(integer: IntegerEnum, data: Int) { /*@DONE ContextItemFactory.Visit/14 cs:231-231*/
        results.addAll(getTableChildren())
    }
    override fun visit(integerHex: IntegerHex, data: Int) { /*@DONE ContextItemFactory.Visit/15 cs:233-233*/
        results.addAll(getTableChildren())
    }
    override fun visit(section: EggSection, data: Int) { /*@DONE ContextItemFactory.Visit/16 cs:235-235*/
        visitTextLike()
    }
    override fun visit(item: EggItem, data: Int) { /*@DONE ContextItemFactory.Visit/17 cs:237-241*/
        visitTextLike()
    }
    override fun visit(item: PlmItem, data: Int) { /*@DONE ContextItemFactory.Visit/18 cs:243-247*/
        visitTextLike()
    }
    override fun visit(array: BitArray, data: Int) { /*@DONE ContextItemFactory.Visit/19 cs:249-249*/
        results.addAll(getTableChildren())
    }
    override fun visit(word: MatchedWord, data: Int) { /*@DONE ContextItemFactory.Visit/20 cs:251-251*/
        results.addAll(getFormattedChildren())
    }
    override fun visit(endStream: EndStream, data: Int) { /*@DONE ContextItemFactory.Visit/21 cs:253-253*/
        results.addAll(getFormattedChildren())
    }
    override fun visit(color: UncompressedPaletteColor, data: Int) { /*@DONE ContextItemFactory.Visit/22 cs:255-261*/
        val selectionStart = viewPort.convertViewPointToAddress(viewPort.selectionStart)
        val palRun = viewPort.model.getNextRun(selectionStart)
        if (palRun is IPaletteRun) {
            addPalPaletteExportOption(palRun)
        }
        results.addAll(getFormattedChildren())
    }
    private fun addPalPaletteExportOption(palRun: IPaletteRun) { /*@DONE ContextItemFactory.AddPalPaletteExportOption/1 cs:263-278*/
        results.add(ContextItem("Copy Palette as .pal", { arg ->
            val fileSystem = arg as IFileSystem
            val colors = ArrayList<Short>()
            for (i in 0 until palRun.pages) {
                val page = palRun.getPalette(viewPort.model, i)
                if (page != null) colors.addAll(page)
            }
            val copyText = StringBuilder()
            copyText.append("JASC-PAL").append(NEW_LINE)
            copyText.append("0100").append(NEW_LINE)
            copyText.append(colors.size.toString()).append(NEW_LINE)
            for (color in colors) {
                val rgb = UncompressedPaletteColor.toRGB(color)
                copyText.append("" + (rgb.r shl 3) + " " + (rgb.g shl 3) + " " + (rgb.b shl 3)).append(NEW_LINE)
            }
            fileSystem.copyText = copyText.toString()
        }))
    }
    override fun visit(tuple: Tuple, data: Int) { /*@DONE ContextItemFactory.Visit/23 cs:280-280*/
        results.addAll(getFormattedChildren())
    }
    private fun getTableChildren(): Iterable<IContextItem> { /*@DONE ContextItemFactory.GetTableChildren/1 cs:282-289*/
        val items = ArrayList<IContextItem>()
        val tableTool = viewPort.tools?.tableTool
        if (tableTool != null && tableTool.append.canExecute(null)) {
            items.add(ContextItem("Extend Table", tableTool.append::execute))
        }

        items.add(ContextItem("Open in Table Tool", { _ -> viewPort.tools?.selectedIndex = 1 }))
        items.addAll(getFormattedChildren())
        return items
    }
    private fun getFormattedChildren(): Iterable<IContextItem> { /*@DONE ContextItemFactory.GetFormattedChildren/1 cs:291-293*/
        val items = ArrayList<IContextItem>()
        items.add(ContextItem("Clear Format", { _ -> viewPort.clearAnchor() }))
        return items
    }
    override fun visit(lz: LzMagicIdentifier, data: Int) { /*@DONE ContextItemFactory.Visit/24 cs:295-295*/
        visitLzFormat()
    }
    override fun visit(lz: LzGroupHeader, data: Int) { /*@DONE ContextItemFactory.Visit/25 cs:297-297*/
        visitLzFormat()
    }
    override fun visit(lz: LzCompressed, data: Int) { /*@DONE ContextItemFactory.Visit/26 cs:299-299*/
        visitLzFormat()
    }
    override fun visit(lz: LzUncompressed, data: Int) { /*@DONE ContextItemFactory.Visit/27 cs:301-301*/
        visitLzFormat()
    }
    private fun visitLzFormat() { /*@DONE ContextItemFactory.VisitLzFormat/1 cs:303-309*/
        val selectionStart = viewPort.convertViewPointToAddress(viewPort.selectionStart)
        val palRun = viewPort.model.getNextRun(selectionStart)
        if (palRun is IPaletteRun) {
            addPalPaletteExportOption(palRun)
        }
        results.addAll(getFormattedChildren())
    }
    /*@ADD ContextItemFactory#vis_3.txt*/
    private fun visitPcsLike() {
        val point = viewPort.selectionStart
        results.add(ContextItem("Open In Text Tool", { _ -> viewPort.followLink(point.x, point.y) }).also { it.shortcutText = "Ctrl+Click" })

        val address = viewPort.convertViewPointToAddress(point)
        val arrayRun = viewPort.model.getNextRun(address)
        if (arrayRun is ITableRun && arrayRun.start <= address) {
            results.addAll(getTableChildren())
        } else {
            results.addAll(getFormattedChildren())
        }
    }
    private fun visitTextLike() {
        val point = viewPort.selectionStart
        results.add(ContextItem("Open In Text Tool", { _ -> viewPort.followLink(point.x, point.y) }).also { it.shortcutText = "Ctrl+Click" })
        results.addAll(getFormattedChildren())
    }
    /*@ENDADD ContextItemFactory#vis_3.txt*/
    /*@END ContextItemFactory*/
}
