// Port of Models/Point.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

class Point { // cs:4-20
    var x: Int = 0
        private set
    var y: Int = 0
        private set
    constructor(x: Int, y: Int) { /*@DONE Point.<init>/1 cs:8-8*/
        this.x = x
        this.y = y
    }
    fun deconstruct(x: Ref<Int>, y: Ref<Int>) { /*@DONE Point.Deconstruct/1 cs:9-9*/
        x.value = this.x
        y.value = this.y
    }
    fun equals(that: Point): Boolean { /*@DONE Point.Equals/1 cs:10-10*/
        return this.x == that.x && this.y == that.y
    }
    override fun equals(obj: Any?): Boolean { /*@DONE Point.Equals/2 cs:11-11*/
        return obj is Point && equals(obj)
    }
    override fun hashCode(): Int { /*@DONE Point.GetHashCode/1 cs:12-12*/
        return x * 101 + y * 37
    }
    operator fun times(num: Int): Point { /*@DONE Point.op_Multiply/1 cs:13-13*/
        return Point(x * num, y * num)
    }
    operator fun plus(b: Point): Point { /*@DONE Point.op_Addition/1 cs:14-14*/
        return Point(x + b.x, y + b.y)
    }
    operator fun unaryMinus(): Point { /*@DONE Point.op_Subtraction/1 cs:15-15*/
        return Point(-x, -y)
    }
    operator fun minus(b: Point): Point { /*@DONE Point.op_Subtraction/2 cs:16-16*/
        return Point(x - b.x, y - b.y)
    }
    override fun toString(): String { /*@DONE Point.ToString/1 cs:19-19*/
        return "($x, $y)"
    }
    constructor()
    companion object {
        var zero: Point = /*@INITDONE Point.Zero cs:5-5*/ Point(0, 0) /*@ENDINIT*/
            private set
        /*@END Point.Companion*/
    }
    /*@END Point*/
}
