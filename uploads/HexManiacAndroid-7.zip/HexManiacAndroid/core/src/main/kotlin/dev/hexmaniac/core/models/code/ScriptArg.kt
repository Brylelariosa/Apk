// Port of Models/Code/ScriptArg.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.code

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*

interface IScriptArg { // cs:11-18
    val type: ArgType
    val pointerType: ExpectedPointerType
    val name: String
    val enumTableName: String?
    fun length(model: IDataModel?, start: Int): Int
    /*@END IScriptArg*/
}

open class ScriptArg : IScriptArg { // cs:20-255
    private var length: Int = 0
    final override var type: ArgType = ArgType.Byte
        private set
    final override var pointerType: ExpectedPointerType = ExpectedPointerType.Unknown
        private set
    final override var name: String = ""
        private set
    final override var enumTableName: String? = null
        private set
    var enumOffset: Int = 0
        private set
    override fun length(model: IDataModel?, start: Int): Int { /*@DONE ScriptArg.Length/1 cs:29-29*/
        return length
    }
    constructor(token: String) { /*@DONE ScriptArg.<init>/1 cs:31-43*/
        val built = construct(token)
        this.type = built.type
        this.pointerType = built.pointerType
        this.name = built.name
        this.enumTableName = built.enumTableName
        this.length = built.length
        val enumTable = this.enumTableName ?: return
        if (enumTable.contains("+")) {
            val parts = enumTable.split("+", limit = 2)
            this.enumTableName = parts[0]
            val result = Ref(0)
            if (parts[1].tryParseInt(result)) enumOffset = result.value
        } else if (enumTable.contains("-")) {
            val parts = enumTable.split("-", limit = 2)
            this.enumTableName = parts[0]
            val result = Ref(0)
            if (parts[1].tryParseInt(result)) enumOffset = -result.value
        }
    }
    fun fitsInRange(model: IDataModel, address: Int): Boolean { /*@DONE ScriptArg.FitsInRange/1 cs:117-120*/
        val enumTable = this.enumTableName
        if (enumTable.isNullOrEmpty() || enumTable.startsWith("|")) return true
        return model.readMultiByteValue(address, length) < model.getOptions(enumTable).size
    }
    private fun convert(model: IDataModel, value: Int, bytes: Int): String { /*@DONE ScriptArg.Convert/1 cs:122-138*/
        var value = value
        val enumTable = this.enumTableName
        var preferHex = enumTable?.endsWith("|h") ?: false
        val preferSign = enumTable?.endsWith("|z") ?: false
        val enumName = enumTable?.split('|')?.get(0)
        val table: List<String>? = if (enumName.isNullOrEmpty()) null else model.getOptions(enumName)
        if (table == null || value - enumOffset < 0 || table.size <= value - enumOffset || table.getOrNull(value).isNullOrEmpty()) {
            if (value != Int.MIN_VALUE) preferHex = preferHex || Math.abs(value).inRange(0x4000, 20000) || Math.abs(value) > 20100
            if (preferHex || value == Int.MIN_VALUE) {
                return "0x" + java.lang.Integer.toHexString(value - enumOffset).uppercase().padStart(length * 2, '0')
            } else {
                if (bytes == 1 && preferSign) value = value.toByte().toInt()
                if (bytes == 2 && preferSign) value = value.toShort().toInt()
                return (value - enumOffset).toString()
            }
        }
        return table[value - enumOffset]
    }
    private fun convert(model: IDataModel, value: String, result: Ref<Int>): String? { /*@DONE ScriptArg.Convert/2 cs:140-160*/
        result.value = 0
        var parseType = "as a number"
        val enumTable = this.enumTableName
        if (!enumTable.isNullOrEmpty()) {
            if (!enumTable.startsWith("|")) parseType = "from " + enumTable
            if (ArrayRunEnumSegment.tryParse(enumTable, model, value, result)) {
                result.value += enumOffset
                return null
            }
        }
        if (
            value.startsWith("0x") && value.substring(2).tryParseHex(result) ||
            value.startsWith("0X") && value.substring(2).tryParseHex(result) ||
            value.startsWith("$") && value.substring(1).tryParseHex(result) ||
            tryParseInt(value, result)
        ) {
            result.value += enumOffset
            return null
        }
        return "Could not parse '" + value + "' " + parseType + "."
    }
    fun build(allFillerIsZero: Boolean, data: IDataModel, start: Int, builder: StringBuilder, streamContent: MutableList<String>, labels: DecompileLabelLibrary, streamTypes: MutableList<ExpectedPointerType>): Boolean { /*@DONE ScriptArg.Build/1 cs:165-166*/
        return build(allFillerIsZero, data, start, builder, streamContent, 0, 0, labels, streamTypes)
    }
    fun build(allFillerIsZero: Boolean, data: IDataModel, start: Int, builder: StringBuilder, streamContent: MutableList<String>, shift: Int, carry: Int, labels: DecompileLabelLibrary, streamTypes: MutableList<ExpectedPointerType>): Boolean { /*@DONE ScriptArg.Build/2 cs:168-189*/
        if (allFillerIsZero && name == "filler") return true
        if (type == ArgType.Byte) builder.append(convert(data, (data[start] shl shift) + carry, 1))
        if (type == ArgType.Short) builder.append(convert(data, (data.readMultiByteValue(start, 2) shl shift) + carry, 2))
        if (type == ArgType.Word) builder.append(convert(data, data.readMultiByteValue(start, 4), 4)) // shift/carry not supported for 4-byte reads
        if (type == ArgType.Pointer) {
            var address = data.readMultiByteValue(start, 4)
            if (address < 0x8000000) {
                builder.append("<" + labels.addressToLabel(address + Pointer.null_, type == ArgType.Pointer && pointerType == ExpectedPointerType.Script) + ">")
            } else {
                address -= 0x8000000
                builder.append("<" + labels.addressToLabel(address, type == ArgType.Pointer && pointerType == ExpectedPointerType.Script) + ">")
                if (pointerType != ExpectedPointerType.Unknown) {
                    val stream = data.getNextRun(address)
                    if (stream is IStreamRun && stream.start == address) {
                        streamContent.add(stream.serializeRun() ?: "")
                        streamTypes.add(pointerType)
                    }
                }
            }
        }
        return false
    }
    fun build(model: IDataModel, address: Int, token: String, results: MutableList<Int>, labels: LabelLibrary): String? { /*@DONE ScriptArg.Build/3 cs:191-192*/
        return build(model, address, token, 0, results, labels)
    }
    fun build(model: IDataModel, address: Int, token: String, shift: Int, results: MutableList<Int>, labels: LabelLibrary): String? { /*@DONE ScriptArg.Build/4 cs:197-254*/
        var token = token
        var value: Int
        val parsed = Ref(0)
        if (type == ArgType.Byte) {
            val error = convert(model, token, parsed)
            if (error != null) return error
            value = parsed.value
            results.add((value shr shift) and 0xFF)
        } else if (type == ArgType.Short) {
            val error = convert(model, token, parsed)
            if (error != null) return error
            value = parsed.value
            results.add((value shr shift) and 0xFF)
            results.add((value shr (shift + 8)) and 0xFF)
        } else if (type == ArgType.Word) {
            val error = convert(model, token, parsed)
            if (error != null) return error
            value = parsed.value
            results.add(value and 0xFF)
            results.add((value shr 0x8) and 0xFF)
            results.add((value shr 0x10) and 0xFF)
            results.add((value shr 0x18) and 0xFF)
        } else if (type == ArgType.Pointer) {
            if (token.startsWith("<")) {
                if (!token.endsWith(">") || token.length < 2) return "Unmatched <>"
                token = token.substring(1, token.length - 1)
            }
            if (token.startsWith("0x")) {
                token = token.substring(2)
            }
            if (token == "auto") {
                if (pointerType == ExpectedPointerType.Script || pointerType == ExpectedPointerType.Unknown) {
                    return "<auto> only supported for text/data."
                }
                value = Pointer.null_ + DeferredStreamToken.autoSentinel
            } else if (labels.tryResolveLabel(token, parsed)) {
                // resolved to an address
                value = parsed.value
            } else if (token == "null") {
                value = Pointer.null_
            } else if (token.tryParseHex(parsed)) {
                // pointer *is* an address: nothing else to do
                value = parsed.value
                if (value > -Pointer.null_) value += Pointer.null_
                if (labels.requireCompleteAddresses && (token.length < 6 || token.length > 7)) {
                    return "Script addresses must be 6 or 7 characters long."
                }
            } else if (pointerType != ExpectedPointerType.Script) {
                return "'" + token + "' is not a valid pointer."
            } else {
                labels.addUnresolvedLabel(token, address)
                value = Pointer.null_
            }
            if (value < 0x02000000) value -= Pointer.null_
            results.add(value and 0xFF)
            results.add((value shr 0x8) and 0xFF)
            results.add((value shr 0x10) and 0xFF)
            results.add((value shr 0x18) and 0xFF)
        } else {
            throw NotImplementedError()
        }
        return null
    }
    companion object {
        fun construct(token: String): ScriptArgConstructTuple { /*@DONE ScriptArg.Construct/1 cs:45-111*/
            if (token.contains("<>")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.Unknown, token.substringBefore("<>"), null, 4)
            } else if (token.contains("<\"\">")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.Text, token.substringBefore("<\"\">"), null, 4)
            } else if (token.contains("<`mart`>")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.Mart, token.substringBefore("<`mart`>"), null, 4)
            } else if (token.contains("<`decor`>")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.Decor, token.substringBefore("<`decor`>"), null, 4)
            } else if (token.contains("<`move`>")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.Movement, token.substringBefore("<`move`>"), null, 4)
            } else if (token.contains("<`oam`>")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.SpriteTemplate, token.substringBefore("<`oam`>"), null, 4)
            } else if (token.contains("<`xse`>")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.Script, token.substringBefore("<`xse`>"), null, 4)
            } else if (token.contains("<`bse`>")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.Script, token.substringBefore("<`bse`>"), null, 4)
            } else if (token.contains("<`ase`>")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.Script, token.substringBefore("<`ase`>"), null, 4)
            } else if (token.contains("<`tse`>")) {
                return ScriptArgConstructTuple(ArgType.Pointer, ExpectedPointerType.Script, token.substringBefore("<`tse`>"), null, 4)
            } else if (token.contains("::")) {
                return ScriptArgConstructTuple(ArgType.Word, ExpectedPointerType.Unknown, token.substringBefore("::"), token.substringAfterLast("::"), 4)
            } else if (token.contains(':')) {
                return ScriptArgConstructTuple(ArgType.Short, ExpectedPointerType.Unknown, token.substringBefore(':'), token.substringAfterLast(':'), 2)
            } else if (token.contains('.')) {
                return ScriptArgConstructTuple(ArgType.Byte, ExpectedPointerType.Unknown, token.substringBefore('.'), token.substringAfter('.'), 1)
            } else {
                // didn't find a token :(
                // I guess it's a byte?
                return ScriptArgConstructTuple(ArgType.Byte, ExpectedPointerType.Unknown, token, null, 1)
            }
        }
        fun isValidToken(token: String): Boolean { /*@DONE ScriptArg.IsValidToken/1 cs:113-115*/
            return "<> <`xse`> <`bse`> <`ase`> <`tse`> <\"\"> <`mart`> <`decor`> <`move`> <`oam`> : .".split(' ').any { token.contains(it) }
        }
        /*@END ScriptArg.Companion*/
    }
    /*@END ScriptArg*/
}

open class SilentMatchArg : IScriptArg { // cs:257-268
    override val type: ArgType
        get() { /*@DONE SilentMatchArg.Type.get cs:258-258*/
            return ArgType.Byte
        }
    override val pointerType: ExpectedPointerType
        get() { /*@DONE SilentMatchArg.PointerType.get cs:259-259*/
            return ExpectedPointerType.Unknown
        }
    override val name: String
        get() { /*@DONE SilentMatchArg.Name.get cs:260-260*/
            return ""
        }
    override val enumTableName: String?
        get() { /*@DONE SilentMatchArg.EnumTableName.get cs:261-261*/
            return null
        }
    val enumOffset: Int
        get() { /*@DONE SilentMatchArg.EnumOffset.get cs:262-262*/
            return 0
        }
    override fun length(model: IDataModel?, start: Int): Int { /*@DONE SilentMatchArg.Length/1 cs:264-264*/
        return 1
    }
    var expectedValue: Int = 0
        private set
    constructor(value: Int) { /*@DONE SilentMatchArg.<init>/1 cs:267-267*/
        expectedValue = value
    }
    /*@END SilentMatchArg*/
}

open class ArrayArg : IScriptArg { // cs:270-320
    final override var type: ArgType = ArgType.Byte
        private set
    final override var name: String = ""
        private set
    final override var enumTableName: String? = null
        private set
    var tokenLength: Int = 0
        private set
    override val pointerType: ExpectedPointerType
        get() { /*@DONE ArrayArg.PointerType.get cs:275-275*/
            return ExpectedPointerType.Unknown
        }
    override fun length(model: IDataModel?, start: Int): Int { /*@DONE ArrayArg.Length/1 cs:277-279*/
        return model!![start] * tokenLength + 1
    }
    constructor(token: String) { /*@DONE ArrayArg.<init>/1 cs:281-283*/
        val built = ScriptArg.construct(token)
        this.type = built.type
        this.name = built.name
        this.enumTableName = built.enumTableName
        this.tokenLength = built.length
    }
    fun convertMany(model: IDataModel, start: Int): String { /*@DONE ArrayArg.ConvertMany/1 cs:285-303*/
        val result = StringBuilder()
        val count = model[start]
        var start = start + 1
        for (i in 0 until count) {
            val value = model.readMultiByteValue(start, tokenLength)
            start += tokenLength
            var tokenText = "0x" + java.lang.Integer.toHexString(value).uppercase().padStart(tokenLength * 2, '0')
            val enumTable = this.enumTableName
            if (!enumTable.isNullOrEmpty()) {
                val table = model.getOptions(enumTable)
                if (value >= 0 && table.size > value) {
                    val named: String? = table[value]
                    tokenText = named ?: ""
                }
            }
            result.append(tokenText)
            if (i < count - 1) result.append(' ')
        }
        return result.toString()
    }
    fun convertMany(model: IDataModel, info: Iterable<String>): Iterable<Int> { /*@DONE ArrayArg.ConvertMany/2 cs:305-319*/
        val results = ArrayList<Int>()
        val enumTable = this.enumTableName
        for (token in info) {
            val result = Ref(0)
            if (enumTable.isNullOrEmpty()) {
                if (token.startsWith("0x") && token.substring(2).tryParseHex(result)) results.add(result.value)
                else if (token.startsWith("0X") && token.substring(2).tryParseHex(result)) results.add(result.value)
                else if (token.startsWith("$") && token.substring(1).tryParseHex(result)) results.add(result.value)
                else if (tryParseInt(token, result)) results.add(result.value)
                else results.add(0)
            } else if (ArrayRunEnumSegment.tryParse(enumTable, model, token, result)) {
                results.add(result.value)
            } else {
                results.add(0)
            }
        }
        return results
    }
    /*@END ArrayArg*/
}

enum class ArgType(val value: Int) { // cs:322-327
    Byte(0),
    Short(1),
    Word(2),
    Pointer(3);
    companion object {
        fun fromValue(value: Int): ArgType = entries.first { it.value == value }
    }
    /*@END ArgType*/
}

data class ScriptArgConstructTuple(val type: ArgType, val pointerType: ExpectedPointerType, val name: String, val enumTableName: String?, val length: Int)
