// Port of Models/Runs/Sprites/MetatileRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class MetatileRun : BaseRun { // cs:7-125
    private lateinit var model: IDataModel
    val supportsImport: Boolean
        get() { /*@DONE MetatileRun.SupportsImport.get cs:12-12*/
            return false
        }
    val supportsEdit: Boolean
        get() { /*@DONE MetatileRun.SupportsEdit.get cs:13-13*/
            return false
        }
    var spriteFormat: SpriteFormat = SpriteFormat()
        private set
    val pages: Int
        get() { /*@DONE MetatileRun.Pages.get cs:15-15*/
            return 1
        }
    override val length: Int = 0
    override val formatString: String
        get() { /*@DONE MetatileRun.FormatString.get cs:17-17*/
            return sharedFormatString
        }
    constructor(model: IDataModel, start: Int, sources: SortedSpan<Int>?) : super(start, sources) { /*@DONE MetatileRun.<init>/1 cs:19-37*/
        this.model = model

        // 2 bytes for each tile/palette combo.
        // 10 bits for the tile, for up to 1024 possible tiles
        // 2  bits for x/y flip, for up to 4 orientations
        // 4  bits for the color, for up to 16 possible palettes
        // Do this 8 times, once for each tile in the block (4 lower, 4 upper). A total of 16 bytes per tile.

        val width = 40
        var height = 0
        if (sources != null && sources.size > 0) {
            val source = sources[0]
            if (source >= 8 && source + 12 <= model.count) {
                // note: the original declares a local `Length` here that shadows the property, so the run's own Length stays 0.
                val blockEnd = model.readPointer(source + 8)
                val blockLength = blockEnd - start
                val blocks = blockLength / 16
                height = (blocks + width - 1) / width
            }
        }
        spriteFormat = SpriteFormat(8, width * 2, height * 2, null)
    }
    fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE MetatileRun.AppendTo/1 cs:39-41*/
        // TODO support copy
    }
    fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE MetatileRun.Clear/1 cs:43-46*/
        // TODO make this better
        model.clearFormatAndData(changeToken, start, length)
    }
    fun getData(): ByteArray { /*@DONE MetatileRun.GetData/1 cs:48-87*/
        val tilesetAddress = model.readPointer(pointerSources!![0] - 8)
        val tileset = model.getNextRun(tilesetAddress) as ITilesetRun
        val tilesetData = tileset.getData()
        val blockData = ByteArray(length)
        System.arraycopy(model.rawData, start, blockData, 0, length)
        val result = ByteArray(8 * 8 * spriteFormat.tileWidth * spriteFormat.tileHeight)
        val lineWidth = spriteFormat.tileWidth * 64
        val cellWidth = 64
        for (y in 0 until spriteFormat.tileHeight / 2) {
            for (x in 0 until spriteFormat.tileWidth / 2) {
                val block = y * spriteFormat.tileWidth / 2 + x
                val blockStart = block * 16
                val resultOffset = y * lineWidth * 2 + x * cellWidth * 2

                // lower layer: the tile data is copied straight in (the original copies in the wrong direction, which leaves the lower layer blank)
                var tileBytes = getTile(tilesetData, blockData, blockStart + 0)
                System.arraycopy(tileBytes, 0, result, resultOffset, tileBytes.size)
                tileBytes = getTile(tilesetData, blockData, blockStart + 1)
                System.arraycopy(tileBytes, 0, result, resultOffset + cellWidth, tileBytes.size)
                tileBytes = getTile(tilesetData, blockData, blockStart + 2)
                System.arraycopy(tileBytes, 0, result, resultOffset + lineWidth, tileBytes.size)
                tileBytes = getTile(tilesetData, blockData, blockStart + 3)
                System.arraycopy(tileBytes, 0, result, resultOffset + lineWidth + cellWidth, tileBytes.size)

                // upper layer: transparent pixels (palette index 0) are skipped
                tileBytes = getTile(tilesetData, blockData, blockStart + 4)
                writeTile(result, resultOffset, tileBytes)
                tileBytes = getTile(tilesetData, blockData, blockStart + 5)
                writeTile(result, resultOffset + cellWidth, tileBytes)
                tileBytes = getTile(tilesetData, blockData, blockStart + 6)
                writeTile(result, resultOffset + lineWidth, tileBytes)
                tileBytes = getTile(tilesetData, blockData, blockStart + 7)
                writeTile(result, resultOffset + lineWidth + cellWidth, tileBytes)
            }
        }

        return result
    }
    private fun getTile(tileset: ByteArray, mapData: ByteArray, index: Int): ByteArray { /*@DONE MetatileRun.GetTile/1 cs:89-104*/
        val tileData = LzTilemapRun.readTileData(mapData, index, 32)
        val result = ByteArray(64)

        val pal = tileData.paletteIndex shl 4
        val tileStart = tileData.tileIndex * 32
        val pixels = SpriteRun.getPixels(tileset.asByteList(), tileStart, 1, 1, 4)
        for (yy in 0 until 8) {
            for (xx in 0 until 8) {
                val inX = if (tileData.hFlip) 7 - xx else xx
                val inY = if (tileData.vFlip) 7 - yy else yy
                result[yy * 8 + xx] = (pixels[inX][inY] + pal).toByte()
            }
        }
        return result
    }
    private fun writeTile(result: ByteArray, resultOffset: Int, tileData: ByteArray) { /*@DONE MetatileRun.WriteTile/1 cs:106-111*/
        for (i in 0 until tileData.size) {
            if ((tileData[i].toInt() and 0xFF) % 0x10 == 0) continue
            result[resultOffset + i] = tileData[i]
        }
    }
    fun getPixels(model: IDataModel, page: Int, tableIndex: Int): Array<IntArray> { /*@DONE MetatileRun.GetPixels/1 cs:113-116*/
        // return everything as if a single layer, combining multiple tiles together, mixing palettes as needed
        throw NotImplementedError()
    }
    fun setPixels(model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>): ISpriteRun { /*@DONE MetatileRun.SetPixels/1 cs:118-120*/
        throw NotImplementedError()
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE MetatileRun.CreateDataFormat/1 cs:122-122*/
        return LzUncompressed(index)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE MetatileRun.Clone/1 cs:124-124*/
        return MetatileRun(model, start, newPointerSources)
    }
    companion object {
        val sharedFormatString: String = /*@INITAUTO MetatileRun.SharedFormatString cs:8-8*/ "`ucb`" /*@ENDINIT*/
        /*@END MetatileRun.Companion*/
    }
    /*@END MetatileRun*/
}
