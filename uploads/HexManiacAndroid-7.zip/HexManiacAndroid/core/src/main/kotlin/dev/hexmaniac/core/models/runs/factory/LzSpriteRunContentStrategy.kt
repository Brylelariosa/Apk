// Port of Models/Runs/Factory/LzSpriteRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class LzSpriteRunContentStrategy : RunStrategy { // cs:11-54
    private var spriteFormat: SpriteFormat = SpriteFormat()
    constructor(spriteFormat: SpriteFormat) { /*@DONE LzSpriteRunContentStrategy.<init>/1 cs:13-13*/
        this.spriteFormat = spriteFormat
    }
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE LzSpriteRunContentStrategy.LengthForNewRun/1 cs:15-18*/
        val data = LZRun.compress(ByteArray(spriteFormat.expectedByteLength).asByteList(), 0, spriteFormat.expectedByteLength)
        return data.count
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE LzSpriteRunContentStrategy.TryAddFormatAtDestination/1 cs:19-26*/
        val lzRun = LzSpriteRun(spriteFormat, owner, destination, SortedSpan(source))
        if (lzRun.length <= 5 || owner.readMultiByteValue(destination + 1, 3) % 32 != 0) return false

        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, lzRun)

        return true
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE LzSpriteRunContentStrategy.Matches/1 cs:27-27*/
        return run is LzSpriteRun && run.formatString == format
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE LzSpriteRunContentStrategy.WriteNewRun/1 cs:28-32*/
        val data = LZRun.compress(ByteArray(spriteFormat.expectedByteLength).asByteList(), 0, spriteFormat.expectedByteLength)
        for (i in 0 until data.count) token.changeData(owner, destination + i, data[i])
        return LzSpriteRun(spriteFormat, owner, destination)
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE LzSpriteRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:33-45*/
        var localSpriteFormat = spriteFormat
        if (sourceSegments != null && parentIndex >= 0) localSpriteFormat = SpriteFormat(spriteFormat.bitsPerPixel, spriteFormat.tileWidth, spriteFormat.tileHeight, spriteFormat.paletteHint, true)
        val runAttempt = LzSpriteRun(localSpriteFormat, model, run.value.start, run.value.pointerSources)
        if (runAttempt.length > 0) {
            val merged = runAttempt.mergeAnchor(run.value.pointerSources)
            run.value = merged
            if (merged is LzSpriteRun && merged.spriteFormat == runAttempt.spriteFormat && merged.length == runAttempt.length) {
                // no need to clear this one, the format matches
            } else {
                model.clearFormat(token, merged.start, merged.length)
            }
        }
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE LzSpriteRunContentStrategy.TryParseData/1 cs:46-53*/
        val error = SpriteRunContentStrategy.isValid(spriteFormat)
        if (error.hasError) return error
        val lzRun = LzSpriteRun(spriteFormat, model, dataIndex, run.value?.pointerSources)
        run.value = lzRun
        if (lzRun.length == LZRun.decompressedTooLong) return ErrorInfo("Decompressed more bytes than expected. Add a ! to override this.")
        if (lzRun.length < 6) return ErrorInfo("Compressed data needs to be at least " + spriteFormat.expectedByteLength + " when decompressed, but was too short.")
        return ErrorInfo.noError
    }
    /*@END LzSpriteRunContentStrategy*/
}
