// Port of ViewModels/Map/BlockEditor.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.tools.*

abstract class TileAttribute { // cs:259-274
    var behavior: Int = 0
    var layer: Int = 0
    var errorInfo: String? = null
        protected set
    abstract fun serialize(): ByteArray
    companion object {
        fun create(data: ByteArray): TileAttribute { /*@DONE TileAttribute.Create/1 cs:264-267*/
            if (data.size == 2) return AttributeRSE(data)
            return AttributeFRLG(data)
        }
        fun create(fullData: ByteArray, start: Int, length: Int): TileAttribute { /*@DONE TileAttribute.Create/2 cs:268-273*/
            val data = ByteArray(length)
            System.arraycopy(fullData, start, data, 0, length)
            if (length == 2) return AttributeRSE(data)
            return AttributeFRLG(data)
        }
        /*@END TileAttribute.Companion*/
    }
    /*@END TileAttribute*/
}

open class AttributeFRLG : TileAttribute { // cs:286-306
    var terrain: Int = 0
    var encounter: Int = 0
    constructor(data: ByteArray) { /*@DONE AttributeFRLG.<init>/1 cs:289-297*/
        behavior = data[0].toInt() and 0xFF
        terrain = (data[1].toInt() and 0xFF) shr 1
        encounter = data[3].toInt() and 3
        layer = (data[3].toInt() and 0xFF) shr 5
        if ((data.asByteList().readMultiByteValue(0, 4) and 0x9CFFF900.toInt()) != 0) {
            errorInfo = "Warning: Expected attribute mask 9CFFF900 to be zero."
        }
    }
    override fun serialize(): ByteArray { /*@DONE AttributeFRLG.Serialize/1 cs:298-305*/
        val result = ByteArray(4)
        result[0] = behavior.toByte()
        result[1] = (terrain shl 1).toByte()
        result[2] = 0
        result[3] = ((layer shl 5) or encounter).toByte()
        return result
    }
    /*@END AttributeFRLG*/
}

open class AttributeRSE : TileAttribute { // cs:312-326
    constructor(data: ByteArray) { /*@DONE AttributeRSE.<init>/1 cs:313-319*/
        behavior = data[0].toInt() and 0xFF
        layer = (data[1].toInt() and 0xFF) shr 4
        if ((data[1].toInt() and 0xF) != 0) {
            errorInfo = "Warning: Expected attribute mask 0F00 to be zero."
        }
    }
    override fun serialize(): ByteArray { /*@DONE AttributeRSE.Serialize/1 cs:320-325*/
        val result = ByteArray(2)
        result[0] = behavior.toByte()
        result[1] = (layer shl 4).toByte()
        return result
    }
    /*@END AttributeRSE*/
}

open class BlockEditor : ViewModelCore { // cs:328-762
    private lateinit var history: ChangeHistory<ModelDelta>
    private lateinit var tutorials: MapTutorialsViewModel
    private lateinit var model: IDataModel
    private var _palettes: Array<ShortArray> = emptyArray()
    private var tiles: Array<Array<IntArray>?> = emptyArray()
    private var blocks: Array<ByteArray> = emptyArray()
    private var blockAttributes: Array<ByteArray> = emptyArray()
    private var indexForTileImage: MutableMap<IPixelViewModel, Int> = LinkedHashMap()
    private var images: Array<CanvasPixelViewModel?> = arrayOfNulls(8)
    private var hoverTile: Int = 0
    private var _layerMode: Int = 0
    var layerMode: Int
        get() { /*@DONE BlockEditor.LayerMode.get cs:343-343*/
            return _layerMode
        }
        set(value) { /*@DONE BlockEditor.LayerMode.set cs:344-344*/
            set(_layerMode, value, "layerMode", { _layerMode = it }) { arg -> enterTile(images[hoverTile]) }
        }
    private var _blockIndex: Int = /*@INITAUTO BlockEditor.blockIndex cs:347-347*/ 0 /*@ENDINIT*/
    var blockIndex: Int
        get() { /*@DONE BlockEditor.BlockIndex.get cs:349-349*/
            return _blockIndex
        }
        set(value) { /*@DONE BlockEditor.BlockIndex.set cs:350-350*/
            set(_blockIndex, value.limitToRange(0, blocks.size - 1), "blockIndex", { _blockIndex = it }) { old -> updateBlockUI(old) }
        }
    val movementPermissions: ObservableCollection<String>
        get() { /*@DONE BlockEditor.MovementPermissions.get cs:410-410*/
            return _movementPermissions
        }
    val autoscrollTiles = Event<EventArgs>()
    val blocksChanged = Event<Array<ByteArray>>()
    val blockAttributesChanged = Event<Array<ByteArray>>()
    val sendMessage = Event<String>()
    private var _tileRender: IPixelViewModel? = null
    val tileRender: IPixelViewModel?
        get() { /*@DONE BlockEditor.TileRender.get cs:418-418*/
            return _tileRender
        }
    private var _drawTileRender: IPixelViewModel? = null
    val drawTileRender: IPixelViewModel?
        get() { /*@DONE BlockEditor.DrawTileRender.get cs:421-421*/
            return _drawTileRender
        }
    val drawTileIndex: Int
        get() { /*@DONE BlockEditor.DrawTileIndex.get cs:422-422*/
            return drawTile
        }
    constructor(history: ChangeHistory<ModelDelta>, listSource: IDataModel, tutorials: MapTutorialsViewModel, palettes: Array<ShortArray>, tiles: Array<Array<IntArray>?>, blocks: Array<ByteArray>, blockAttributes: Array<ByteArray>) { /*@DONE BlockEditor.<init>/2 cs:424-441*/
        this.history = history
        this.tutorials = tutorials
        this.model = listSource
        this._palettes = palettes
        this.tiles = tiles
        this.blocks = blocks
        this.blockAttributes = blockAttributes
        _hasTerrainAndEncounter = blockAttributes[0].size > 2
        images = arrayOfNulls(8)
        indexForTileImage = LinkedHashMap()
        val behaviors = Ref<ValidationList?>(null)
        if (listSource.tryGetList("MapAttributeBehaviors", behaviors)) {
            behaviorOptions.update(behaviors.value!!.mapIndexed { i, name -> ComboOption(name, i) }, _behavior)
        }
        behaviorOptions.bind("selectedIndex") { obj, e -> behavior = behaviorOptions.selectedIndex }
        val layerList = Ref<ValidationList?>(null)
        if (listSource.tryGetList("MapLayerOptions", layerList)) {
            for (item in layerList.value!!) layerOptions.add(item)
        }
        val terrainList = Ref<ValidationList?>(null)
        if (listSource.tryGetList("MapTerrainOptions", terrainList)) {
            for (item in terrainList.value!!) terrainOptions.add(item)
        }
        val encounterList = Ref<ValidationList?>(null)
        if (listSource.tryGetList("MapEncounterOptions", encounterList)) {
            for (item in encounterList.value!!) encounterOptions.add(item)
        }
        for (i in 0 until palettes.size) this.palettes.add(ReadonlyPaletteCollection(palettes[i].asList(), i))
    }
    val leftTopBack: IPixelViewModel?
        get() { /*@DONE BlockEditor.LeftTopBack.get cs:443-443*/
            return images[0]
        }
    val rightTopBack: IPixelViewModel?
        get() { /*@DONE BlockEditor.RightTopBack.get cs:444-444*/
            return images[1]
        }
    val leftBottomBack: IPixelViewModel?
        get() { /*@DONE BlockEditor.LeftBottomBack.get cs:445-445*/
            return images[2]
        }
    val rightBottomBack: IPixelViewModel?
        get() { /*@DONE BlockEditor.RightBottomBack.get cs:446-446*/
            return images[3]
        }
    val leftTopFront: IPixelViewModel?
        get() { /*@DONE BlockEditor.LeftTopFront.get cs:447-447*/
            return images[4]
        }
    val rightTopFront: IPixelViewModel?
        get() { /*@DONE BlockEditor.RightTopFront.get cs:448-448*/
            return images[5]
        }
    val leftBottomFront: IPixelViewModel?
        get() { /*@DONE BlockEditor.LeftBottomFront.get cs:449-449*/
            return images[6]
        }
    val rightBottomFront: IPixelViewModel?
        get() { /*@DONE BlockEditor.RightBottomFront.get cs:450-450*/
            return images[7]
        }
    private var _flipVLeft: Int = 0
    private var _flipVTop: Int = 0
    private var _flipHLeft: Int = 0
    private var _flipHTop: Int = 0
    var flipVLeft: Int
        get() { /*@DONE BlockEditor.FlipVLeft.get cs:457-457*/
            return _flipVLeft
        }
        private set(value) { /*@DONE BlockEditor.FlipVLeft.set cs:457-457*/
            tryUpdate(_flipVLeft, value, "flipVLeft") { _flipVLeft = it }
        }
    var flipVTop: Int
        get() { /*@DONE BlockEditor.FlipVTop.get cs:458-458*/
            return _flipVTop
        }
        private set(value) { /*@DONE BlockEditor.FlipVTop.set cs:458-458*/
            tryUpdate(_flipVTop, value, "flipVTop") { _flipVTop = it }
        }
    var flipHLeft: Int
        get() { /*@DONE BlockEditor.FlipHLeft.get cs:459-459*/
            return _flipHLeft
        }
        private set(value) { /*@DONE BlockEditor.FlipHLeft.set cs:459-459*/
            tryUpdate(_flipHLeft, value, "flipHLeft") { _flipHLeft = it }
        }
    var flipHTop: Int
        get() { /*@DONE BlockEditor.FlipHTop.get cs:460-460*/
            return _flipHTop
        }
        private set(value) { /*@DONE BlockEditor.FlipHTop.set cs:460-460*/
            tryUpdate(_flipHTop, value, "flipHTop") { _flipHTop = it }
        }
    private var _flipVVisible: Boolean = false
    private var _flipHVisible: Boolean = false
    var flipVVisible: Boolean
        get() { /*@DONE BlockEditor.FlipVVisible.get cs:463-463*/
            return _flipVVisible
        }
        set(value) { /*@DONE BlockEditor.FlipVVisible.set cs:463-463*/
            tryUpdate(_flipVVisible, value, "flipVVisible") { _flipVVisible = it }
        }
    var flipHVisible: Boolean
        get() { /*@DONE BlockEditor.FlipHVisible.get cs:464-464*/
            return _flipHVisible
        }
        set(value) { /*@DONE BlockEditor.FlipHVisible.set cs:464-464*/
            tryUpdate(_flipHVisible, value, "flipHVisible") { _flipHVisible = it }
        }
    fun flipH() { /*@DONE BlockEditor.FlipH/1 cs:466-474*/
        val tileData = LzTilemapRun.readTileData(blocks[_blockIndex], hoverTile, 2)
        LzTilemapRun.writeTileData(blocks[_blockIndex], hoverTile, tileData.paletteIndex, !tileData.hFlip, tileData.vFlip, tileData.tileIndex)
        val newImage = BlocksetModel.read(blocks[_blockIndex], hoverTile, tiles, paletteLists())
        images[hoverTile]?.fill(newImage.pixelData)
        blocksChanged(this, blocks)
        tutorials.complete(Tutorial.FlipButton_FlipBlock)
    }
    fun flipV() { /*@DONE BlockEditor.FlipV/1 cs:476-484*/
        val tileData = LzTilemapRun.readTileData(blocks[_blockIndex], hoverTile, 2)
        LzTilemapRun.writeTileData(blocks[_blockIndex], hoverTile, tileData.paletteIndex, tileData.hFlip, !tileData.vFlip, tileData.tileIndex)
        val newImage = BlocksetModel.read(blocks[_blockIndex], hoverTile, tiles, paletteLists())
        images[hoverTile]?.fill(newImage.pixelData)
        blocksChanged(this, blocks)
        tutorials.complete(Tutorial.FlipButton_FlipBlock)
    }
    private var copyTiles: Array<IntArray> = /*@INITDONE BlockEditor.copyTiles cs:490-490*/ Array(2) { IntArray(2) } /*@ENDINIT*/
    private var copyPalettes: Array<IntArray> = /*@INITDONE BlockEditor.copyPalettes cs:491-491*/ Array(2) { IntArray(2) } /*@ENDINIT*/
    private var copyFlipVs: Array<BooleanArray> = /*@INITDONE BlockEditor.copyFlipVs cs:492-492*/ Array(2) { BooleanArray(2) } /*@ENDINIT*/
    private var copyFlipHs: Array<BooleanArray> = /*@INITDONE BlockEditor.copyFlipHs cs:493-493*/ Array(2) { BooleanArray(2) } /*@ENDINIT*/
    fun copyBackground() { /*@DONE BlockEditor.CopyBackground/1 cs:495-501*/
        copyFrom(0)
        sendMessage(this, "Copied Block Background")
    }
    fun copyForeground() { /*@DONE BlockEditor.CopyForeground/1 cs:503-509*/
        copyFrom(4)
        sendMessage(this, "Copied Block Foreground")
    }
    fun pasteBackground() { /*@DONE BlockEditor.PasteBackground/1 cs:511-523*/
        pasteTo(0)
        for (i in 0 until 4) {
            val newImage = BlocksetModel.read(blocks[_blockIndex], i, tiles, paletteLists())
            images[i]?.fill(newImage.pixelData)
        }
        blocksChanged(this, blocks)
        tutorials.complete(Tutorial.ClickBlock_DrawTile)
        sendMessage(this, "Pasted Block Background")
    }
    fun pasteForeground() { /*@DONE BlockEditor.PasteForeground/1 cs:525-537*/
        pasteTo(4)
        for (i in 4 until 8) {
            val newImage = BlocksetModel.read(blocks[_blockIndex], i, tiles, paletteLists())
            images[i]?.fill(newImage.pixelData)
        }
        blocksChanged(this, blocks)
        tutorials.complete(Tutorial.ClickBlock_DrawTile)
        sendMessage(this, "Pasted Block Foreground")
    }
    fun loadClipboard(other: BlockEditor) { /*@DONE BlockEditor.LoadClipboard/1 cs:539-544*/
        copyPalettes = other.copyPalettes
        copyFlipHs = other.copyFlipHs
        copyFlipVs = other.copyFlipVs
        copyTiles = other.copyTiles
    }
    fun enterTile(tile: IPixelViewModel?) { /*@DONE BlockEditor.EnterTile/1 cs:548-555*/
        flipVVisible = true
        flipHVisible = true
        if (tile == null) return
        val index = indexForTileImage[tile]
        if (index == null) return
        val set = if (_layerMode == 0) twoSets[index] else if (_layerMode == 1) bottomLayerTogether[index] else topLayerTogether[index]
        flipVLeft = set.first.first
        flipVTop = set.first.second
        flipHLeft = set.second.first
        flipHTop = set.second.second
        hoverTile = index
    }
    fun drawOnTile(tile: IPixelViewModel?) { /*@DONE BlockEditor.DrawOnTile/1 cs:557-565*/
        if (!_showTiles || tile == null) return
        val index = indexForTileImage[tile]
        if (index == null) return
        LzTilemapRun.writeTileData(blocks[_blockIndex], index, drawPalette, drawFlipH, drawFlipV, drawTile)
        val newImage = BlocksetModel.read(blocks[_blockIndex], index, tiles, paletteLists())
        // (the original refreshes images[hoverTile]; that is the same tile whenever the pointer hovers before drawing, and index is right when it doesn't, e.g. touch input)
        images[index]?.fill(newImage.pixelData)
        blocksChanged(this, blocks)
        tutorials.complete(Tutorial.ClickBlock_DrawTile)
    }
    fun getSelectionFromTile(tileImage: IPixelViewModel?) { /*@DONE BlockEditor.GetSelectionFromTile/1 cs:567-580*/
        if (tileImage == null) return
        showTiles = true
        val index = indexForTileImage[tileImage]
        if (index == null) return
        val tileData = LzTilemapRun.readTileData(blocks[_blockIndex], index, 2)
        drawTile = tileData.tileIndex
        drawFlipV = tileData.vFlip
        drawFlipH = tileData.hFlip
        paletteSelection = tileData.paletteIndex
        notifyPropertiesChanged("tileSelectionX", "tileSelectionY")
        autoscrollTiles(this, EventArgs.empty)
        animateTileSelection()
        history.changeCompleted()
        updateDrawTileRender()
    }
    fun exitTiles() { /*@DONE BlockEditor.ExitTiles/1 cs:582-585*/
        flipVVisible = false
        flipHVisible = false
    }
    private var _behavior: Int = 0
    private var _layer: Int = 0
    private var _terrain: Int = 0
    private var _encounter: Int = 0
    var behavior: Int
        get() { /*@DONE BlockEditor.Behavior.get cs:590-590*/
            return _behavior
        }
        set(value) { /*@DONE BlockEditor.Behavior.set cs:590-590*/
            set(_behavior, value, "behavior", { _behavior = it }) { arg -> saveAttributes(arg) }
        }
    var layer: Int
        get() { /*@DONE BlockEditor.Layer.get cs:591-591*/
            return _layer
        }
        set(value) { /*@DONE BlockEditor.Layer.set cs:591-591*/
            set(_layer, value, "layer", { _layer = it }) { arg -> saveAttributes(arg) }
        }
    var terrain: Int
        get() { /*@DONE BlockEditor.Terrain.get cs:592-592*/
            return _terrain
        }
        set(value) { /*@DONE BlockEditor.Terrain.set cs:592-592*/
            set(_terrain, value, "terrain", { _terrain = it }) { arg -> saveAttributes(arg) }
        }
    var encounter: Int
        get() { /*@DONE BlockEditor.Encounter.get cs:593-593*/
            return _encounter
        }
        set(value) { /*@DONE BlockEditor.Encounter.set cs:593-593*/
            set(_encounter, value, "encounter", { _encounter = it }) { arg -> saveAttributes(arg) }
        }
    private var _errorText: String? = null
    val hasError: Boolean
        get() { /*@DONE BlockEditor.HasError.get cs:596-596*/
            return _errorText != null
        }
    val errorText: String?
        get() { /*@DONE BlockEditor.ErrorText.get cs:597-597*/
            return _errorText
        }
    var behaviorOptions: FilteringComboOptions = /*@INITDONE BlockEditor.BehaviorOptions cs:599-599*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    var layerOptions: ObservableCollection<String> = /*@INITDONE BlockEditor.LayerOptions cs:600-600*/ ObservableCollection() /*@ENDINIT*/
        private set
    var terrainOptions: ObservableCollection<String> = /*@INITDONE BlockEditor.TerrainOptions cs:601-601*/ ObservableCollection() /*@ENDINIT*/
        private set
    var encounterOptions: ObservableCollection<String> = /*@INITDONE BlockEditor.EncounterOptions cs:602-602*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _hasTerrainAndEncounter: Boolean = false
    var hasTerrainAndEncounter: Boolean
        get() { /*@DONE BlockEditor.HasTerrainAndEncounter.get cs:605-605*/
            return _hasTerrainAndEncounter
        }
        set(value) { /*@DONE BlockEditor.HasTerrainAndEncounter.set cs:605-605*/
            tryUpdate(_hasTerrainAndEncounter, value, "hasTerrainAndEncounter") { _hasTerrainAndEncounter = it }
        }
    private fun updateAttributeUI() { /*@DONE BlockEditor.UpdateAttributeUI/1 cs:607-618*/
        val attributes = TileAttribute.create(blockAttributes[_blockIndex])
        _behavior = attributes.behavior
        _layer = attributes.layer
        if (attributes is AttributeFRLG) {
            _terrain = attributes.terrain
            _encounter = attributes.encounter
        }
        _errorText = attributes.errorInfo
        notifyPropertiesChanged("behavior", "layer", "terrain", "encounter", "hasError", "errorText")
        behaviorOptions.update(behaviorOptions.allOptions ?: ArrayList<ComboOption>(), _behavior)
    }
    private fun saveAttributes(arg: Int = 0) { /*@DONE BlockEditor.SaveAttributes/1 cs:620-630*/
        val attributes = TileAttribute.create(blockAttributes[_blockIndex])
        attributes.behavior = _behavior
        attributes.layer = _layer
        if (attributes is AttributeFRLG) {
            attributes.terrain = _terrain
            attributes.encounter = _encounter
        }
        blockAttributes[_blockIndex] = attributes.serialize()
        blockAttributesChanged(this, blockAttributes)
    }
    private fun updateBlockUI(old: Int) { /*@DONE BlockEditor.UpdateBlockUI/1 cs:634-637*/
        for (i in 0 until 8) images[i] = null
        updateBlockUI()
    }
    private fun updateBlockUI() { /*@DONE BlockEditor.UpdateBlockUI/2 cs:639-655*/
        if (_blockIndex == -1) return

        for (i in 0 until 8) {
            if (images[i] == null) {
                val image = BlocksetModel.read(blocks[_blockIndex], i, tiles, paletteLists())
                val canvas = CanvasPixelViewModel(image.pixelWidth, image.pixelHeight, image.pixelData)
                canvas.spriteScale = 3.0
                images[i] = canvas
                indexForTileImage[canvas] = i
                notifyPropertyChanged(imageNames[i])
            }
        }

        indexForTileImage.clear()
        for (i in 0 until 8) indexForTileImage[images[i]!!] = i

        updateAttributeUI()
    }
    private var _showTiles: Boolean = false
    var showTiles: Boolean
        get() { /*@DONE BlockEditor.ShowTiles.get cs:663-663*/
            return _showTiles
        }
        set(value) { /*@DONE BlockEditor.ShowTiles.set cs:664-666*/
            set(_showTiles, value, "showTiles", { _showTiles = it }) { arg ->
                if (_showTiles && _tileRender == null) updateTileRender(drawPalette)
            }
        }
    fun toggleShowTiles() { /*@DONE BlockEditor.ToggleShowTiles/1 cs:669-672*/
        showTiles = !showTiles
        tutorials.complete(Tutorial.BlockButton_EditBlocks)
    }
    fun hideTiles() { /*@DONE BlockEditor.HideTiles/1 cs:674-674*/
        showTiles = false
    }
    private var _tileSelectionToggle: Boolean = false
    var tileSelectionToggle: Boolean
        get() { /*@DONE BlockEditor.TileSelectionToggle.get cs:679-679*/
            return _tileSelectionToggle
        }
        set(value) { /*@DONE BlockEditor.TileSelectionToggle.set cs:679-679*/
            tryUpdate(_tileSelectionToggle, value, "tileSelectionToggle") { _tileSelectionToggle = it }
        }
    private fun animateTileSelection() { /*@DONE BlockEditor.AnimateTileSelection/1 cs:680-680*/
        tileSelectionToggle = !tileSelectionToggle
    }
    private var drawTile: Int = 0
    private var drawPalette: Int = 0
    private var drawFlipV: Boolean = false
    private var drawFlipH: Boolean = false
    var tileSelectionX: Int
        get() { /*@DONE BlockEditor.TileSelectionX.get cs:685-685*/
            return (drawTile % tilesPerRow) * pixelPerTile
        }
        set(value) { /*@DONE BlockEditor.TileSelectionX.set cs:686-697*/
            var x = drawTile % tilesPerRow
            val y = drawTile / tilesPerRow
            if (x != value / pixelPerTile) {
                x = value / pixelPerTile
                drawTile = y * tilesPerRow + x
                if (drawTile >= tiles.size) drawTile = tiles.size - 1
                notifyPropertyChanged("tileSelectionX")
                drawFlipH = false
                drawFlipV = false
                tutorials.complete(Tutorial.ClickTile_SelectTile)
                updateDrawTileRender()
            }
        }
    var tileSelectionY: Int
        get() { /*@DONE BlockEditor.TileSelectionY.get cs:700-700*/
            return (drawTile / tilesPerRow) * pixelPerTile
        }
        set(value) { /*@DONE BlockEditor.TileSelectionY.set cs:701-716*/
            val x = drawTile % tilesPerRow
            var y = drawTile / tilesPerRow
            if (y != value / pixelPerTile) {
                y = value / pixelPerTile
                drawTile = y * tilesPerRow + x
                if (drawTile >= tiles.size) {
                    drawTile = tiles.size - 1
                    notifyPropertiesChanged("tileSelectionX")
                }
                notifyPropertyChanged("tileSelectionY")
                drawFlipH = false
                drawFlipV = false
                history.changeCompleted()
                tutorials.complete(Tutorial.ClickTile_SelectTile)
                updateDrawTileRender()
            }
        }
    var paletteSelection: Int
        get() { /*@DONE BlockEditor.PaletteSelection.get cs:719-719*/
            return drawPalette
        }
        set(value) { /*@DONE BlockEditor.PaletteSelection.set cs:720-720*/
            set(drawPalette, value, "paletteSelection", { drawPalette = it }) { arg -> updateTileRender(drawPalette) }
        }
    var palettes: ObservableCollection<ReadonlyPaletteCollection> = /*@INITDONE BlockEditor.Palettes cs:723-723*/ ObservableCollection() /*@ENDINIT*/
        private set
    private fun updateTileRender(paletteIndex: Int) { /*@DONE BlockEditor.UpdateTileRender/1 cs:725-741*/
        val tileLines = (tiles.size + tilesPerRow - 1) / tilesPerRow
        val pixelData = ShortArray(8 * 8 * tilesPerRow * tileLines)
        for (i in pixelData.indices) pixelData[i] = Short.MIN_VALUE
        val render = CanvasPixelViewModel(8 * 16, 8 * 16 * 4, pixelData)
        render.spriteScale = 3.0
        render.transparent = Short.MIN_VALUE
        val palette = SpriteTool.createPaletteWithUniqueTransparentColor(_palettes[paletteIndex].asList())
        for (y in 0 until 64) {
            for (x in 0 until 16) {
                val tileIndex = y * 16 + x
                if (tileIndex >= tiles.size) break
                val tile = ReadonlyPixelViewModel(8, 8, SpriteTool.render(tiles[tileIndex], palette, 0, 0), palette[0])
                if (tile.pixelData.size == 0) break
                render.draw(tile, x * 8, y * 8)
            }
        }
        _tileRender = render
        notifyPropertyChanged("tileRender")
        updateDrawTileRender()
    }
    private fun updateDrawTileRender() { /*@DONE BlockEditor.UpdateDrawTileRender/1 cs:743-747*/
        val palette = SpriteTool.createPaletteWithUniqueTransparentColor(_palettes[drawPalette].asList())
        val render = CanvasPixelViewModel(8, 8, SpriteTool.render(tiles[drawTile], palette, 0, 0))
        render.transparent = palette[0]
        render.spriteScale = 4.0
        _drawTileRender = render
        notifyPropertiesChanged("drawTileRender", "drawTileIndex")
    }
    fun refreshPaletteCache(palette: Array<ShortArray>) { /*@DONE BlockEditor.RefreshPaletteCache/1 cs:753-753*/
        this._palettes = palette
    }
    fun refreshTileCache(tiles: Array<Array<IntArray>?>) { /*@DONE BlockEditor.RefreshTileCache/1 cs:754-754*/
        this.tiles = tiles
    }
    fun refreshBlockCache(blocks: Array<ByteArray>) { /*@DONE BlockEditor.RefreshBlockCache/1 cs:755-758*/
        this.blocks = blocks
        blockIndex = _blockIndex
    }
    fun refreshBlockAttributeCache(blockAttributes: Array<ByteArray>) { /*@DONE BlockEditor.RefreshBlockAttributeCache/1 cs:759-759*/
        this.blockAttributes = blockAttributes
    }
    companion object {
        private var bottomLayerTogether: MutableList<Pair<Pair<Int, Int>, Pair<Int, Int>>> = ArrayList()
        private var topLayerTogether: MutableList<Pair<Pair<Int, Int>, Pair<Int, Int>>> = ArrayList()
        private var twoSets: MutableList<Pair<Pair<Int, Int>, Pair<Int, Int>>> = ArrayList()
        private val _movementPermissions: ObservableCollection<String> = /*@INITDONE BlockEditor.movementPermissions cs:354-354*/ ObservableCollection() /*@ENDINIT*/
        init { /*@DONE BlockEditor.<cctor>/1 cs:355-408*/
            val p0 = 0
            val p1 = 24
            val p2 = 48
            val p3 = 72
            val p4 = 96
            val shortD = 8
            bottomLayerTogether = arrayListOf(
                Pair(Pair(p1 - shortD, p1), Pair(p1, p1 - shortD)),
                Pair(Pair(p3, p1), Pair(p2, p1 - shortD)),
                Pair(Pair(p1 - shortD, p2), Pair(p1, p3)),
                Pair(Pair(p3, p2), Pair(p2, p3)),
                Pair(Pair(p1, p0), Pair(p0, p1)),
                Pair(Pair(p3 - shortD, p0), Pair(p3, p1)),
                Pair(Pair(p1, p3), Pair(p0, p3 - shortD)),
                Pair(Pair(p3 - shortD, p3), Pair(p3, p3 - shortD)),
            )
            topLayerTogether = arrayListOf(
                Pair(Pair(p1, p0), Pair(p0, p1)),
                Pair(Pair(p3 - shortD, p0), Pair(p3, p1)),
                Pair(Pair(p1, p3), Pair(p0, p3 - shortD)),
                Pair(Pair(p3 - shortD, p3), Pair(p3, p3 - shortD)),
                Pair(Pair(p1 - shortD, p1), Pair(p1, p1 - shortD)),
                Pair(Pair(p3, p1), Pair(p2, p1 - shortD)),
                Pair(Pair(p1 - shortD, p2), Pair(p1, p3)),
                Pair(Pair(p3, p2), Pair(p2, p3)),
            )
            twoSets = arrayListOf(
                Pair(Pair(p2 - shortD, p2), Pair(p2, p2 - shortD)),
                Pair(Pair(p4, p2), Pair(p3, p2 - shortD)),
                Pair(Pair(p2 - shortD, p3), Pair(p2, p4)),
                Pair(Pair(p4, p3), Pair(p3, p4)),
                Pair(Pair(p0 - shortD, p0), Pair(p0, p0 - shortD)),
                Pair(Pair(p2, p0), Pair(p1, p0 - shortD)),
                Pair(Pair(p0 - shortD, p1), Pair(p0, p2)),
                Pair(Pair(p2, p1), Pair(p1, p2)),
            )

            // movement permissions
            _movementPermissions.add("00 - Cross Layers")
            _movementPermissions.add("01 - Wall")
            _movementPermissions.add("02")
            _movementPermissions.add("03")
            for (i in 1 until 14) {
                val start = i * 4
                _movementPermissions.add("${(start + 0).toHex(2)} - Elevation $i Pass")
                _movementPermissions.add("${(start + 1).toHex(2)} - Elevation $i Wall")
                _movementPermissions.add("${(start + 2).toHex(2)} - Elevation $i Unused")
                _movementPermissions.add("${(start + 3).toHex(2)} - Elevation $i Unused")
            }
            _movementPermissions.add("38 - No Use")
            _movementPermissions.add("39 - No Use")
            _movementPermissions.add("3A - No Use")
            _movementPermissions.add("3B - No Use")
            _movementPermissions.add("3C - Above/Below")
            _movementPermissions.add("3D - No Use")
            _movementPermissions.add("3E - No Use")
            _movementPermissions.add("3F - No Use")
        }
        private val imageNames: Array<String> = /*@INITDONE BlockEditor.imageNames cs:452-452*/ "leftTopBack,rightTopBack,leftBottomBack,rightBottomBack,leftTopFront,rightTopFront,leftBottomFront,rightBottomFront".split(",") /*@ENDINIT*/
        private const val tilesPerRow: Int = 16
        private const val pixelPerTile: Int = 24
        /*@END BlockEditor.Companion*/
    }
    /*@ADD BlockEditor#blockeditor.txt*/
    private fun paletteLists(): Array<List<Short>> = Array(_palettes.size) { _palettes[it].asList() }
    private fun copyFrom(first: Int) {
        for (i in 0 until 4) {
            val x = i % 2
            val y = i / 2
            val t = LzTilemapRun.readTileData(blocks[_blockIndex], first + i, 2)
            copyPalettes[x][y] = t.paletteIndex
            copyFlipHs[x][y] = t.hFlip
            copyFlipVs[x][y] = t.vFlip
            copyTiles[x][y] = t.tileIndex
        }
    }
    private fun pasteTo(first: Int) {
        for (i in 0 until 4) {
            val x = i % 2
            val y = i / 2
            LzTilemapRun.writeTileData(blocks[_blockIndex], first + i, copyPalettes[x][y], copyFlipHs[x][y], copyFlipVs[x][y], copyTiles[x][y])
        }
    }
    /*@ENDADD BlockEditor#blockeditor.txt*/
    /*@END BlockEditor*/
}
