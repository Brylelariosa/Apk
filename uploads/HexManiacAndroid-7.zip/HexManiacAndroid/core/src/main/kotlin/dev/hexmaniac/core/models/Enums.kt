// Port of Models/Enums.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

enum class Direction(val value: Int) { // cs:2-2
    Left(0),
    Right(1),
    Up(2),
    Down(3),
    PageUp(4),
    PageDown(5),
    Home(6),
    End(7);
    companion object {
        fun fromValue(value: Int): Direction = entries.first { it.value == value }
    }
    /*@END Direction*/
}

enum class PatchType(val value: Int) { // cs:3-3
    Ips(0),
    Ups(1);
    companion object {
        fun fromValue(value: Int): PatchType = entries.first { it.value == value }
    }
    /*@END PatchType*/
}
