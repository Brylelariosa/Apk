package dev.hexmaniac.core.system

import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Where the bundled reference data lives (the original keeps it in a "resources" folder next to the exe, and reads it with
 * File.ReadAllLines("resources/x.txt"), File.Exists, Directory.GetFiles("resources", "default.*.toml")).
 * Ported code calls [Resources] with the SAME relative path text the C# used ("resources/x.txt" or just "x.txt").
 */
interface ResourceProvider {
    /** [path] is normalized: forward slashes, no leading "resources/". Returns null when there is no such file. */
    fun open(path: String): InputStream?

    /** Names (not paths) of the entries that sit directly in [directory] ("" is the root); directories end without a slash. */
    fun listNames(directory: String): List<String>
}

/** Reads `hma/<path>` from the class path; the folder listing comes from `hma/index.txt` (one relative path per line). */
class ClasspathResourceProvider(private val root: String = "hma") : ResourceProvider {
    private val index: List<String> by lazy {
        val stream = ClasspathResourceProvider::class.java.getResourceAsStream("/$root/index.txt")
        if (stream == null) emptyList() else stream.use { s ->
            String(s.readBytes(), Charsets.UTF_8).split('\n').map { it.trim().replace('\\', '/') }.filter { it.isNotEmpty() }
        }
    }

    override fun open(path: String): InputStream? = ClasspathResourceProvider::class.java.getResourceAsStream("/$root/$path")

    override fun listNames(directory: String): List<String> {
        val prefix = if (directory.isEmpty()) "" else "$directory/"
        val result = LinkedHashSet<String>()
        for (entry in index) {
            if (!entry.startsWith(prefix)) continue
            val rest = entry.substring(prefix.length)
            if (rest.isEmpty()) continue
            val slash = rest.indexOf('/')
            result.add(if (slash < 0) rest else rest.substring(0, slash))
        }
        return result.toList()
    }
}

object Resources {
    @JvmField
    var provider: ResourceProvider = ClasspathResourceProvider()

    /** "resources/default.toml", ".\resources\default.toml" and "default.toml" all name the same entry. */
    fun normalize(path: String): String {
        var p = path.replace('\\', '/')
        while (p.startsWith("./")) p = p.substring(2)
        if (p.startsWith("resources/", ignoreCase = true)) p = p.substring("resources/".length)
        else if (p.equals("resources", ignoreCase = true)) p = ""
        return p.trim('/')
    }

    fun exists(path: String): Boolean {
        val p = normalize(path)
        val stream = provider.open(p) ?: return false
        stream.close()
        return true
    }

    fun readAllBytes(path: String): ByteArray {
        val p = normalize(path)
        val stream = provider.open(p) ?: throw FileNotFoundException(path)
        stream.use { s ->
            val buffer = ByteArrayOutputStream()
            val chunk = ByteArray(65536)
            while (true) {
                val n = s.read(chunk)
                if (n < 0) break
                buffer.write(chunk, 0, n)
            }
            return buffer.toByteArray()
        }
    }

    /** UTF-8 text without a byte order mark (like File.ReadAllText). */
    fun readAllText(path: String): String {
        val bytes = readAllBytes(path)
        var start = 0
        if (bytes.size >= 3 && bytes[0] == 0xEF.toByte() && bytes[1] == 0xBB.toByte() && bytes[2] == 0xBF.toByte()) start = 3
        return String(bytes, start, bytes.size - start, Charsets.UTF_8)
    }

    /** Like File.ReadAllLines: lines split at \r\n, \n or \r; no trailing empty line for a final line break. */
    fun readAllLines(path: String): List<String> = splitLines(readAllText(path))

    fun splitLines(text: String): List<String> {
        val lines = ArrayList<String>()
        var start = 0
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (c == '\n' || c == '\r') {
                lines.add(text.substring(start, i))
                if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                start = i + 1
            }
            i++
        }
        if (start < text.length) lines.add(text.substring(start))
        return lines
    }

    /** Directory.GetFiles(directory, pattern): returns "resources/..."-style relative paths of files (not directories), '*' and '?' wildcards. */
    fun getFiles(directory: String, pattern: String = "*"): List<String> {
        val dir = normalize(directory)
        val regex = wildcardToRegex(pattern)
        val result = ArrayList<String>()
        for (name in provider.listNames(dir)) {
            val full = if (dir.isEmpty()) name else "$dir/$name"
            if (!isFile(full)) continue
            if (regex.matches(name)) result.add("resources/$full")
        }
        return result
    }

    fun getDirectories(directory: String): List<String> {
        val dir = normalize(directory)
        val result = ArrayList<String>()
        for (name in provider.listNames(dir)) {
            val full = if (dir.isEmpty()) name else "$dir/$name"
            if (!isFile(full)) result.add("resources/$full")
        }
        return result
    }

    fun isFile(normalizedPath: String): Boolean {
        val stream = provider.open(normalizedPath) ?: return false
        stream.close()
        return true
    }

    private fun wildcardToRegex(pattern: String): Regex {
        val sb = StringBuilder()
        for (ch in pattern) {
            when (ch) {
                '*' -> sb.append(".*")
                '?' -> sb.append('.')
                else -> sb.append(Regex.escape(ch.toString()))
            }
        }
        return Regex(sb.toString(), RegexOption.IGNORE_CASE)
    }
}
