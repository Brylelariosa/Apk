// Port of ViewModels/Tools/BatchObservableCollection.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*

open class BatchObservableCollection<T> : AbstractMutableList<T>(), INotifyCollectionChanged { // cs:8-103
    private val content: MutableList<T> = /*@INITDONE BatchObservableCollection.content cs:9-9*/ ArrayList() /*@ENDINIT*/
    private var batchCount: Int = /*@INITAUTO BatchObservableCollection.batchCount cs:10-10*/ 0 /*@ENDINIT*/
    fun createBatch(): IDisposable { /*@DONE BatchObservableCollection.CreateBatch/1 cs:12-18*/
        batchCount += 1
        return StubDisposable {
            batchCount -= 1
            if (batchCount == 0) raiseReset()
        }
    }
    fun createSilentBatch(): IDisposable { /*@DONE BatchObservableCollection.CreateSilentBatch/1 cs:24-27*/
        batchCount += 1
        return StubDisposable { batchCount -= 1 }
    }
    private fun raiseMemberChanged(index: Int, newValue: T, oldValue: T) { /*@DONE BatchObservableCollection.RaiseMemberChanged/1 cs:29-30*/
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Replace, newItems = listOf(newValue), oldItems = listOf(oldValue), newStartingIndex = index, oldStartingIndex = index))
    }
    private fun raiseMemberInsert(index: Int, item: T) { /*@DONE BatchObservableCollection.RaiseMemberInsert/1 cs:32-32*/
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, newItems = listOf(item), newStartingIndex = index))
    }
    private fun raiseMemberAdd(item: T) { /*@DONE BatchObservableCollection.RaiseMemberAdd/1 cs:34-34*/
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, newItems = listOf(item)))
    }
    private fun raiseMemberRemove(item: T) { /*@DONE BatchObservableCollection.RaiseMemberRemove/1 cs:36-36*/
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, oldItems = listOf(item)))
    }
    private fun raiseMemberRemove(index: Int, item: T) { /*@DONE BatchObservableCollection.RaiseMemberRemove/2 cs:38-38*/
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, oldItems = listOf(item), oldStartingIndex = index))
    }
    private fun raiseReset() { /*@DONE BatchObservableCollection.RaiseReset/1 cs:40-40*/
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset))
    }
    override fun get(index: Int): T { /*@DONE BatchObservableCollection.this/1.get cs:45-45*/
        return content[index]
    }
    override fun set(index: Int, element: T): T { /*@DONE BatchObservableCollection.this/1.set cs:46-52*/
        val old = content[index]
        content[index] = element
        if (batchCount == 0) {
            raiseMemberChanged(index, element, old)
        }
        return old
    }
    override val size: Int
        get() { /*@DONE BatchObservableCollection.Count.get cs:55-55*/ return content.size }
    override fun add(element: T): Boolean { /*@DONE BatchObservableCollection.Add/1 cs:59-62*/
        content.add(element)
        if (batchCount == 0) raiseMemberAdd(element)
        return true
    }
    override fun clear() { /*@DONE BatchObservableCollection.Clear/1 cs:64-67*/
        content.clear()
        if (batchCount == 0) raiseReset()
    }
    override fun add(index: Int, element: T) { /*@DONE BatchObservableCollection.Insert/1 cs:77-80*/
        content.add(index, element)
        if (batchCount == 0) raiseMemberInsert(index, element)
    }
    override fun remove(element: T): Boolean { /*@DONE BatchObservableCollection.Remove/1 cs:82-86*/
        val result = content.remove(element)
        if (batchCount == 0 && result) raiseMemberRemove(element)
        return result
    }
    override fun removeAt(index: Int): T { /*@DONE BatchObservableCollection.RemoveAt/1 cs:88-92*/
        val item = content[index]
        content.removeAt(index)
        if (batchCount == 0) raiseMemberRemove(index, item)
        return item
    }
    override val collectionChanged = Event<NotifyCollectionChangedEventArgs>()
    /*@END BatchObservableCollection*/
}
