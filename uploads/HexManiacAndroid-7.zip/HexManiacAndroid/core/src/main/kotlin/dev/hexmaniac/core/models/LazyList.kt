// Port of Models/LazyList.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

open class LazyList<T> : ReadOnlyListMixin<T> { // cs:6-29
    private var lazyData: Iterable<T>? = null
    private var concreteData: List<T>? = null
    constructor(data: Iterable<T>) { /*@DONE LazyList.<init>/1 cs:10-10*/
        lazyData = data
    }
    private fun init(): List<T> { /*@DONE LazyList.Init/1 cs:12-20*/
        val existing = concreteData
        if (existing != null) return existing
        synchronized(this) {
            val lazy = lazyData
            if (lazy == null) return concreteData!!
            concreteData = lazy.toList()
            lazyData = null
        }
        return concreteData!!
    }
    override val size: Int
        get() { /*@DONE LazyList.Count.get cs:22-22*/
            return init().size
        }
    override operator fun get(index: Int): T { /*@DONE LazyList.this/1.get cs:24-24*/
        return init()[index]
    }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@END LazyList*/
}
