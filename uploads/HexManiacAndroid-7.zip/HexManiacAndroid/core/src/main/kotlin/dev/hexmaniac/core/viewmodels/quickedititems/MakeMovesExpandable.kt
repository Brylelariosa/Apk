// Port of ViewModels/QuickEditItems/MakeMovesExpandable.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flySpawns
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tradeTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapBankTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTableRSE
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.wildTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.specialsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDataTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapLayoutTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.berryTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flyConnections
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.dexInfoTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.naturesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldSprites
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonStatsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.eggMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldPalettes
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.frontSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.contestTypesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokePalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typeChartTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.shinyPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerSpritesName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemImagesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.levelMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemEffectsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.regionalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.nationalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.multichoiceTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDescriptionsName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backupFontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultSpriteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerClassNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.conversionDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultTilemapNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultPaletteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityDescriptionsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPaletteIndexTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticleSpriteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticlePaletteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveInfoListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTargetListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionMethodListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsShapeListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsCategoryListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsPermissionListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emerald
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.hmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTutors
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tutorCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.cfruIgnoreTables
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decodeConstantsFromReference
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.getIsCFRU

open class MakeMovesExpandable : IQuickEditItem { // cs:12-302
    override val name: String?
        get() { /*@DONE MakeMovesExpandable.Name.get cs:14-14*/
            return "Make Moves Expandable"
        }
    override val description: String?
        get() { /*@DONE MakeMovesExpandable.Description.get cs:18-19*/
            return "Running this utility will remove the move limiters " +
                "and allow for unlimited moves and effects."
        }
    override val wikiLink: String?
        get() { /*@DONE MakeMovesExpandable.WikiLink.get cs:21-21*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Move-Expansion-Explained"
        }
    override val canRunChanged = Event<EventArgs>()
    override fun canRun(viewPort: IViewPort): Boolean { /*@DONE MakeMovesExpandable.CanRun/1 cs:25-49*/
        // this ViewPort must be editable
        if (viewPort !is IEditableViewPort) return false

        // the new levelup thumb code must exist
        if (!Resources.exists(expandLevelUpMovesCode)) return false

        val model = viewPort.model ?: return false

        // we need tables for level-up moves, move names, move stats, and move effects
        for (table in arrayOf(HardcodeTablesModel.levelMovesTableName, HardcodeTablesModel.moveDataTable, HardcodeTablesModel.moveNamesTable, HardcodeTablesModel.moveEffectsTable)) {
            if (model.getTable(table) == null) return false
        }

        // the expansion must not have been run yet
        // easy way to check: if the move stats table has 2 bytes for the effect field, it's been tampered with
        val moveStatsTable = model.getTable(HardcodeTablesModel.moveDataTable) ?: return false
        if (moveStatsTable.elementContent[0].length != 1) return false

        // moves must be 2 bytes each
        val levelMovesTable = model.getTable(HardcodeTablesModel.levelMovesTableName) ?: return false
        val destination = levelMovesTable.readPointer(model, 0)
        val pokemonMoves = model.getNextRun(destination) as? ITableRun
        if (pokemonMoves == null || pokemonMoves.elementLength != 2) return false

        return true
    }
    override fun run(viewPortInterface: IViewPort): Task<ErrorInfo>? { /*@DONE MakeMovesExpandable.Run/1 cs:51-80*/
        return asyncTask<ErrorInfo> {
            val viewPort = viewPortInterface as IEditableViewPort
            val model = viewPort.model ?: return@asyncTask ErrorInfo.noError
            val token = viewPort.changeHistory.currentChange
            val parser = viewPort.tools?.codeTool?.parser ?: return@asyncTask ErrorInfo("The code tool is not available.")

            var error: ErrorInfo
            error = expandMoveEffects(parser, viewPort, token, .5).await()
            if (error.hasError) return@asyncTask error

            // update limiters for move names
            error = replaceAll(parser, model, token,
                arrayOf("mov r0, #177", "lsl r0, r0, #1", "cmp r1, r0"),
                arrayOf("mov r0, #177", "lsl r0, r0, #9", "cmp r1, r0"))
            if (error.hasError) return@asyncTask error
            viewPort.updateProgress(.6).await()

            // update levelup moves (update limit from 20 to 25)
            val storeFreeSpaceBuffer = model.freeSpaceBuffer
            model.freeSpaceBuffer = 0
            try {
                expandLevelUpMoveData(model, token)
            } finally {
                model.freeSpaceBuffer = storeFreeSpaceBuffer
            }
            viewPort.updateProgress(.7).await()
            expandLevelUpMoveCode(viewPort, token, .7, 1.0).await()

            viewPort.refresh()
            canRunChanged(this, EventArgs.empty)
            ErrorInfo.noError
        }
    }
    override fun tabChanged() { /*@DONE MakeMovesExpandable.TabChanged/1 cs:301-301*/
        canRunChanged(this, EventArgs.empty)
    }
    companion object {
        private const val expandLevelUpMovesCode: String = "resources/expand_levelup_moves_code.hma"
        fun expandMoveEffects(parser: ThumbParser, viewPort: IEditableViewPort, token: ModelDelta, targetLoadingPercent: Double): Task<ErrorInfo> { /*@DONE MakeMovesExpandable.ExpandMoveEffects/1 cs:82-117*/
            return asyncTask<ErrorInfo> {
                // make move effects 2 bytes instead of 1 byte
                val model = viewPort.model ?: return@asyncTask ErrorInfo.noError
                val table = model.getTable(HardcodeTablesModel.moveDataTable) ?: return@asyncTask ErrorInfo("Couldn't find table " + HardcodeTablesModel.moveDataTable + ".")
                val fieldNames = table.elementContent.map { seg -> seg.name }.toTypedArray()
                suspend fun shiftField(i: Int): ErrorInfo {
                    val result = refactorMoveByteFieldInTable(parser, model, token, HardcodeTablesModel.moveDataTable, fieldNames[i], i + 1)
                    viewPort.updateProgress((9 - i) / 9.0 * targetLoadingPercent).await()
                    return result
                }

                // effect. power. type. accuracy. pp. effectAccuracy. target. priority. info. unused. unused:
                var error: ErrorInfo
                error = shiftField(8)
                if (error.hasError) return@asyncTask error
                error = shiftField(7)
                if (error.hasError) return@asyncTask error
                error = shiftField(6)
                if (error.hasError) return@asyncTask error
                error = shiftField(5)
                if (error.hasError) return@asyncTask error
                error = shiftField(4)
                if (error.hasError) return@asyncTask error
                error = shiftField(3)
                if (error.hasError) return@asyncTask error
                error = shiftField(2)
                if (error.hasError) return@asyncTask error
                error = shiftField(1)
                if (error.hasError) return@asyncTask error
                error = refactorByteToHalfWordInTable(parser, model, token, HardcodeTablesModel.moveDataTable, fieldNames[0])
                if (error.hasError) return@asyncTask error
                viewPort.updateProgress(targetLoadingPercent).await()

                // update offset pointers (because the PP field moved)
                val sources = table.pointerSources
                val pointerRuns = ArrayList<OffsetPointerRun>()
                if (sources != null) {
                    for (address in sources) {
                        val run = model.getNextRun(address)
                        if (run is OffsetPointerRun) pointerRuns.add(run)
                    }
                }
                for (pointerRun in pointerRuns) {
                    model.clearFormat(token, pointerRun.start, 4)
                    model.writePointer(token, pointerRun.start, table.start + 5)
                    model.observeRunWritten(token, OffsetPointerRun(pointerRun.start, 5))
                }

                ErrorInfo.noError
            }
        }
        fun refactorMoveByteFieldInTable(parser: ThumbParser, model: IDataModel, token: ModelDelta, tableName: String, fieldName: String, newOffset: Int): ErrorInfo { /*@DONE MakeMovesExpandable.RefactorMoveByteFieldInTable/1 cs:119-168*/
            // setup
            val table = model.getTable(tableName) as? ArrayRun
            if (table == null) return ErrorInfo("Couldn't find table " + tableName + ".")
            val segToMove = table.elementContent.firstOrNull { seg -> seg.name == fieldName }
            if (segToMove == null) return ErrorInfo("Couldn't find field " + fieldName + " in " + tableName + ".")
            if (segToMove.length != 1) return ErrorInfo(fieldName + " must be a 1-byte field to refactor.")
            if (newOffset >= table.elementLength) return ErrorInfo("Trying to move " + fieldName + " to offset " + newOffset + ", but the table is only " + table.elementLength + " bytes wide.")
            val oldFieldIndex = table.elementContent.indexOf(segToMove)
            var newFieldIndex = 0
            var remainingOffset = newOffset
            while (remainingOffset > 0) {
                remainingOffset -= table.elementContent[newFieldIndex].length
                newFieldIndex += 1
            }
            val segToReplace = table.elementContent[newFieldIndex]
            if (segToReplace.length != 1) return ErrorInfo(segToReplace.name + " must be a 1-byte field to be replaced.")
            val oldOffset = table.elementContent.until { seg -> seg === segToMove }.sumOf { seg -> seg.length }

            // update table format
            var format = table.formatString
            format = format.replaceOne(segToMove.serializeFormat, "#invalidtabletoken#")
            format = format.replaceOne(segToReplace.serializeFormat, segToMove.serializeFormat)
            format = format.replaceOne("#invalidtabletoken#", segToReplace.serializeFormat)
            val newTable = Ref<ITableRun?>(null)
            val error = ArrayRun.tryParse(model, format, table.start, table.pointerSources, newTable)
            if (error.hasError) return ErrorInfo("Failed to create a table from new format " + format + ": " + error.errorMessage + ".")

            // update code
            val ldrbWriter = TupleSegment("", 5)
            for (address in table.findAllByteReads(parser, oldFieldIndex)) {
                val instructionOpCode = model[address + 1] shr 3
                if (instructionOpCode == 15) {
                    // ldrb rd, [rn, #]: 01111 # rn rd
                    ldrbWriter.write(model, token, address, 6, newOffset)
                } else if (instructionOpCode == 4) {
                    // mov  rd, #: 00100 rd #
                    model[address] = newOffset and 0xFF
                }
            }

            // update table contents
            for (i in 0 until table.elementCount) {
                val value = model[table.start + table.elementLength * i + oldOffset]
                token.changeData(model, table.start + table.elementLength * i + oldOffset, 0)
                token.changeData(model, table.start + table.elementLength * i + newOffset, value)
            }

            val newRun = newTable.value
            if (newRun != null) model.observeRunWritten(token, newRun)
            return ErrorInfo.noError
        }
        fun refactorByteToHalfWordInTable(parser: ThumbParser, model: IDataModel, token: ModelDelta, tableName: String, fieldName: String): ErrorInfo { /*@DONE MakeMovesExpandable.RefactorByteToHalfWordInTable/1 cs:170-211*/
            // setup
            val table = model.getTable(tableName) as? ArrayRun
            if (table == null) return ErrorInfo("Couldn't find table " + tableName + ".")
            val segToGrow = table.elementContent.firstOrNull { seg -> seg.name == fieldName }
            if (segToGrow == null) return ErrorInfo("Couldn't find field " + fieldName + " in " + tableName + ".")
            if (segToGrow.length != 1) return ErrorInfo(fieldName + " must be a 1-byte field to refactor.")
            val fieldIndex = table.elementContent.indexOf(segToGrow)
            if (fieldIndex + 1 == table.elementContent.size) return ErrorInfo(fieldName + " is the last field in the table.")
            val segToReplace = table.elementContent[fieldIndex + 1]
            if (segToReplace.length != 1) return ErrorInfo(segToReplace.name + " must be a 1-byte field to be replaced.")
            val fieldOffset = table.elementContent.until { seg -> seg === segToGrow }.sumOf { seg -> seg.length }
            if (fieldOffset % 2 != 0) return ErrorInfo(fieldName + " must be on an even byte address to extend to a halfword.")

            // update table format
            var format = table.formatString
            val newSegFormat = segToGrow.serializeFormat.replaceOne(".", ":")
            format = format.replaceOne(segToGrow.serializeFormat, newSegFormat)
            format = format.replaceOne(segToReplace.serializeFormat, "")
            val newTable = Ref<ITableRun?>(null)
            val error = ArrayRun.tryParse(model, format, table.start, table.pointerSources, newTable)
            if (error.hasError) return ErrorInfo("Failed to create a table from new format " + format + ": " + error.errorMessage + ".")

            // update code
            val writer = TupleSegment("", 5)
            val allChanges = ArrayList<String>()
            for (address in table.findAllByteReads(parser, fieldIndex)) {
                allChanges.add(address.toAddress())
                // ldrb rd, [rn, #]: 01111 # rn rd
                // ldrh rd, [rn, #]: 10001 # rn rd, but # is /2
                writer.write(model, token, address, 6, fieldOffset / 2) // divide offset by 2
                writer.write(model, token, address, 11, 17)             // ldrb -> ldrh (0b10001)
            }

            // update table contents
            for (i in 0 until table.elementCount) {
                token.changeData(model, table.start + table.elementLength * i + fieldOffset + 1, 0) // make sure that any old data gets cleared
            }

            val newRun = newTable.value
            if (newRun != null) model.observeRunWritten(token, newRun)
            return ErrorInfo.noError
        }
        fun replaceAll(parser: ThumbParser, model: IDataModel, token: ModelDelta, inputCode: Array<String>, outputCode: Array<String>): ErrorInfo { /*@DONE MakeMovesExpandable.ReplaceAll/1 cs:213-222*/
            val search = parser.compile(model, 0, Ref<List<IFormattedRun>?>(null), *inputCode)
            val replace = parser.compile(model, 0, Ref<List<IFormattedRun>?>(null), *outputCode)
            if (search.count != replace.count) return ErrorInfo("Input length (" + search.count + ") doesn't match output length (" + replace.count + ").")
            val results = model.find(*IntArray(search.count) { i -> search[i] })
            for (result in results) {
                for (i in 0 until replace.count) token.changeData(model, result + i, replace[i])
            }
            return ErrorInfo.noError
        }
        fun expandLevelUpMoveData(model: IDataModel, token: ModelDelta) { /*@DONE MakeMovesExpandable.ExpandLevelUpMoveData/1 cs:224-262*/
            // Note that ALL the data changes before ANY new metadata gets written.
            // This means that edited data blocks will get seen as NoInfoRuns during the write.
            val levelMovesTable = model.getTable(HardcodeTablesModel.levelMovesTableName) ?: return
            for (i in 0 until levelMovesTable.elementCount) {
                val pokemonMovesStart = model.readPointer(levelMovesTable.start + levelMovesTable.elementLength * i)
                val pokemonMovesTable = model.getNextRun(pokemonMovesStart) as? TableStreamRun
                if (pokemonMovesTable == null) continue

                // calculate the new 4-byte format from the old 2-byte format
                val newData = ByteArray(pokemonMovesTable.elementCount * 4)
                for (j in 0 until pokemonMovesTable.elementCount) {
                    val split = PLMRun.splitToken(model.readMultiByteValue(pokemonMovesTable.start + pokemonMovesTable.elementLength * j, 2))
                    val level = split.level
                    val move = split.move
                    newData[j * 4 + 0] = move.toByte()
                    newData[j * 4 + 1] = (move shr 8).toByte()
                    newData[j * 4 + 2] = level.toByte()
                    newData[j * 4 + 3] = (level shr 8).toByte()
                }

                // write the new 4-byte format into the rom
                val newMovesLocation = model.relocateForExpansion(token, pokemonMovesTable, newData.size + 7)
                var newStart = newMovesLocation.start
                while (newStart % 4 != 0) newStart += 1
                model.writePointer(token, levelMovesTable.start + levelMovesTable.elementLength * i, newStart)
                model.clearFormatAndData(token, newStart, newMovesLocation.length * 2)
                for (j in 0 until newData.size) token.changeData(model, newStart + j, newData[j].toInt() and 0xFF)
                for (j in 0 until 4) token.changeData(model, newStart + newData.size + j, 0xFF)

                // update FreeSpaceStart to just after the current run ends.
                val afterThisRun = newStart + newData.size + 4
                model.freeSpaceStart = maxOf(model.freeSpaceStart, afterThisRun)
            }

            // write metadata
            val newTableRun = Ref<ITableRun?>(null)
            val errorInfo = ArrayRun.tryParse(model, "[movesFromLevel<[move:" + HardcodeTablesModel.moveNamesTable + " level:]!FFFFFFFF>]" + HardcodeTablesModel.pokemonNameTable, levelMovesTable.start, levelMovesTable.pointerSources, newTableRun)
            if (errorInfo.hasError) {
                throw NotImplementedException("There was an unexpected error creating the new table: " + errorInfo.errorMessage)
            }
            val writtenRun = newTableRun.value
            if (writtenRun != null) model.observeAnchorWritten(token, HardcodeTablesModel.levelMovesTableName, writtenRun)
        }
        fun expandLevelUpMoveCode(viewPort: IEditableViewPort, token: ModelDelta, loadingStart: Double, loadingEnd: Double): Task<Unit> { /*@DONE MakeMovesExpandable.ExpandLevelUpMoveCode/1 cs:264-267*/
            val script = Resources.readAllText(expandLevelUpMovesCode)
            return viewPort.edit(script, loadingStart, loadingEnd)
        }
        private const val originalElementLength: Int = 13
        private const val newElementLength: Int = 17
        fun expandMoveNameData(model: IDataModel, token: ModelDelta) { /*@DONE MakeMovesExpandable.ExpandMoveNameData/1 cs:270-281*/
            var table = model.getTable(HardcodeTablesModel.moveNamesTable) ?: return
            table = model.relocateForExpansion(token, table, table.elementCount * newElementLength)
            for (i in table.elementCount - 1 downTo 0) {
                val text = table.readText(model, i)
                val writeBytes: MutableList<Int> = model.textConverter.convert(text, Ref(false)) ?: ArrayList<Int>()
                while (writeBytes.size < newElementLength) writeBytes.add(0x00)
                token.changeData(model, table.start + i * newElementLength, writeBytes.toByteArrayU().asByteList())
            }
            val newTable = Ref<ITableRun?>(null)
            ArrayRun.tryParse(model, "[name\"\"" + newElementLength + "]" + table.elementCount, table.start, table.pointerSources, newTable)
            val newRun = newTable.value
            if (newRun != null) model.observeRunWritten(token, newRun)
        }
        fun expandMoveNameCode(model: IDataModel, parser: ThumbParser, token: ModelDelta) { /*@DONE MakeMovesExpandable.ExpandMoveNameCode/1 cs:283-299*/
            val table = model.getTable(HardcodeTablesModel.moveNamesTable) as ArrayRun
            val sources = table.pointerSources ?: return
            for (source in sources) {
                var funcLoc = source - 2
                while (funcLoc >= 0 && model[funcLoc] != 0xB5) funcLoc -= 2
                if (funcLoc < 0) continue
                funcLoc += 2
                while (funcLoc < source) {
                    if (model[funcLoc] != originalElementLength) {
                        funcLoc += 2
                        continue
                    }
                    val loadArrayLine = parser.parse(model, funcLoc, 2).trim().splitLines().last().trim()
                    // change commands like mov r0, #13 or add r1, #13
                    // given the proximity to the name table pointer, the constant is probably used by that table
                    if (loadArrayLine.endsWith(", #" + originalElementLength)) {
                        token.changeData(model, funcLoc, newElementLength)
                    }
                    funcLoc += 2
                }
            }
        }
        /*@END MakeMovesExpandable.Companion*/
    }
    /*@END MakeMovesExpandable*/
}
