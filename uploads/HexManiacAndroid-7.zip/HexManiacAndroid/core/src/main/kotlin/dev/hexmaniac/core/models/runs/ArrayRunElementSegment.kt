// Port of Models/Runs/ArrayRunElementSegment.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.models.runs.factory.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.models.code.*

enum class ElementContentType(val value: Int) { // cs:15-22
    Unknown(0),
    PCS(1),
    Integer(2),
    Pointer(3),
    BitArray(4),
    Splitter(5);
    companion object {
        fun fromValue(value: Int): ElementContentType = entries.first { it.value == value }
    }
    /*@END ElementContentType*/
}

interface IHasOptions { // cs:24-26
    fun getOptions(model: IDataModel): List<String>?
    /*@END IHasOptions*/
}

open class ArrayRunElementSegment { // cs:28-165
    protected var textConverter: ITextConverter? = null
        private set
    var name: String = ""
        private set
    var type: ElementContentType = ElementContentType.Unknown
        private set
    var length: Int = 0
        private set
    open val serializeFormat: String
        get() { /*@DONE ArrayRunElementSegment.SerializeFormat.get cs:35-43*/
            if (type == ElementContentType.PCS) return "$name\"\"$length"
            if (type == ElementContentType.Pointer) return "$name<>"
            if (type == ElementContentType.Integer && length == 1) return "$name."
            if (type == ElementContentType.Integer && length == 2) return "$name:"
            if (type == ElementContentType.Integer && length == 3) return "$name:."
            if (type == ElementContentType.Integer && length == 4) return "$name::"
            throw NotImplementedException()
        }
    constructor(name: String, type: ElementContentType, length: Int, converter: ITextConverter? = null) { /*@DONE ArrayRunElementSegment.<init>/1 cs:46-46*/
        this.name = name
        this.type = type
        this.length = length
        this.textConverter = converter
    }
    private var recursionStopper: Boolean = false
    open fun toText(rawData: IDataModel, offset: Int, depth: Int = 0): String? { /*@DONE ArrayRunElementSegment.ToText/1 cs:49-82*/
        when (type) {
            ElementContentType.PCS -> {
                return rawData.textConverter.convert(rawData, offset, length)
            }
            ElementContentType.Integer -> {
                return toInteger(rawData, offset, length).toString()
            }
            ElementContentType.Pointer -> {
                val address = rawData.readPointer(offset)
                var anchor = rawData.getAnchorFromAddress(-1, address)
                if (anchor.isNullOrEmpty()) anchor = address.toHex(6)
                val run = rawData.getNextRun(address) as? IAppendToBuilderRun
                if (depth < 1 || recursionStopper || run == null) return "${PointerRun.pointerStart}${anchor}${PointerRun.pointerEnd}"

                val builder = StringBuilder("@{ ")
                recursionStopper = true
                if (run is ArrayRun && run.supportsInnerPointers && run.elementContent.size == 1 && run.elementContent[0].type == ElementContentType.PCS) {
                    // special case: if the pointer in this array is to a specific element of a text array, only copy that one element rather than the whole array.
                    run.appendTo(rawData, builder, address, run.elementLength, 0)
                } else {
                    run.appendTo(rawData, builder, run.start, run.length, depth - 1)
                }
                recursionStopper = false
                if (run is TableStreamRun && run.allowsZeroElements) {
                    if (builder.length >= 2 && builder.substring(builder.length - 2, builder.length) != "[]") {
                        builder.append(" []") // Include the end token, allowing streams to be made shorter.
                    }
                }
                builder.append(" @} ")

                return builder.toString()
            }
            else -> throw NotImplementedException()
        }
    }
    open fun write(parentSegments: List<ArrayRunElementSegment>?, model: IDataModel, token: ModelDelta, start: Int, data: Ref<String>): Boolean { /*@DONE ArrayRunElementSegment.Write/1 cs:94-154*/
        if (data.value.startsWith("(") && data.value.endsWith(")")) data.value = data.value.substring(1, data.value.length - 1)
        var remainder = ""
        if (type != ElementContentType.PCS) {
            val tokens = TableStreamRun.tokenize(data.value)
            remainder = tokens.drop(1).joinToString(", ")
            data.value = if (tokens.size > 0) tokens[0] else ""
        }

        when (type) {
            ElementContentType.PCS -> {
                val bytes = textConverter!!.convert(data.value, Ref(false))!!
                while (bytes.size > length) bytes.removeAt(bytes.size - 1)
                if (!bytes.contains(0xFF)) bytes[bytes.size - 1] = 0xFF
                while (bytes.size < length) bytes.add(0)
                data.value = remainder
                return token.changeData(model, start, bytes.toByteArrayU().asByteList())
            }
            ElementContentType.Integer -> {
                val intValue = Ref(0)
                if (data.value.startsWith("0x")) {
                    if (!tryParseHexInt(data.value.substring(2), intValue)) intValue.value = 0
                } else {
                    if (!tryParseInt(data.value, intValue)) intValue.value = 0
                }
                data.value = remainder
                return model.writeMultiByteValue(start, length, token, intValue.value)
            }
            ElementContentType.Pointer -> {
                data.value = data.value.trim()
                if (data.value.startsWith("<")) data.value = data.value.substring(1)
                if (data.value.endsWith(">")) data.value = data.value.substring(0, data.value.length - 1)
                val addressRef = Ref(0)
                var address: Int
                if (!tryParseHexInt(data.value, addressRef)) {
                    address = model.getAddressFromAnchor(token, -1, data.value)
                } else {
                    address = addressRef.value
                }
                data.value = remainder

                val pointerSegment = this as? ArrayRunPointerSegment
                if (pointerSegment == null || pointerSegment.destinationDataMatchesPointerFormat(model, token, start, address, null, -1)) {
                    val currentDestination = model.readPointer(start)
                    if (currentDestination != address) {
                        model.updateArrayPointer(token, this, parentSegments, 0, start, address)
                    }
                    return currentDestination != address
                } else {
                    val oldDestination = model.readPointer(start)
                    var oldRun = model.getNextRun(oldDestination)!!
                    if (oldRun.start == oldDestination) {
                        oldRun = oldRun.removeSource(start)
                        if ((oldRun.pointerSources?.size ?: 0) == 0 && model.getAnchorFromAddress(-1, oldRun.start) == "") model.clearFormat(token, oldDestination, 1)
                    }
                    val changed = model.writePointer(token, start, address)
                    val existingRun = model.getNextRun(address)!!
                    if (existingRun.start < address) {
                        // can't actually add a NoInfoRun here
                    } else {
                        model.observeRunWritten(token, NoInfoRun(address, SortedSpan(start)))
                    }
                    return changed
                }
            }
            else -> throw NotImplementedException()
        }
    }
    companion object {
        fun toInteger(data: ByteList, offset: Int, length: Int): Int { /*@DONE ArrayRunElementSegment.ToInteger/1 cs:156-164*/
            var result = 0
            var shift = 0
            for (i in 0 until length) {
                result += data[offset + i] shl shift
                shift += 8
            }
            return result
        }
        /*@END ArrayRunElementSegment.Companion*/
    }
    /*@END ArrayRunElementSegment*/
}

open class ArrayRunSignedSegment : ArrayRunElementSegment { // cs:167-180
    override val serializeFormat: String
        get() { /*@DONE ArrayRunSignedSegment.SerializeFormat.get cs:168-168*/
            return super.serializeFormat + ArrayRun.signedFormatString
        }
    constructor(name: String, length: Int) : super(name, ElementContentType.Integer, length) { /*@DONE ArrayRunSignedSegment.<init>/1 cs:169-169*/
        // the base constructor does all the work
    }
    override fun toText(rawData: IDataModel, offset: Int, depth: Int): String? { /*@DONE ArrayRunSignedSegment.ToText/1 cs:170-172*/
        return readValue(rawData, offset).toString()
    }
    fun readValue(model: IDataModel, offset: Int): Int { /*@DONE ArrayRunSignedSegment.ReadValue/1 cs:174-179*/
        val value = model.readMultiByteValue(offset, length)
        if (length == 1) return value.toByte().toInt()
        if (length == 2) return value.toShort().toInt()
        return value
    }
    /*@END ArrayRunSignedSegment*/
}

open class ArrayRunEnumSegment : ArrayRunElementSegment, IHasOptions { // cs:182-369
    var enumName: String = ""
        private set
    var valueOffset: Int = 0
        private set
    override val serializeFormat: String
        get() { /*@DONE ArrayRunEnumSegment.SerializeFormat.get cs:188-193*/
            var result = super.serializeFormat + enumName
            if (valueOffset > 0) result += "+" + valueOffset
            if (valueOffset < 0) result += valueOffset
            return result
        }
    constructor(name: String, length: Int, enumName: String) : super(name, ElementContentType.Integer, length) { /*@DONE ArrayRunEnumSegment.<init>/1 cs:196-203*/
        this.enumName = enumName
        val parts = this.enumName.split("+")
        val parsedOffset = Ref(0)
        if (parts.size == 2 && tryParseInt(parts[1], parsedOffset)) {
            this.enumName = parts[0]
            this.valueOffset = parsedOffset.value
        }
    }
    override fun toText(model: IDataModel, address: Int, depth: Int): String? { /*@DONE ArrayRunEnumSegment.ToText/1 cs:205-228*/
        ModelCacheScope.createScope(model).using {
            val options = getOptions(model).toList()

            val resultAsInteger = toInteger(model, address, length) - valueOffset
            if (resultAsInteger >= options.size || resultAsInteger < 0) return resultAsInteger.toString()
            var value = options[resultAsInteger] ?: resultAsInteger.toString()

            // use ~2 postfix for a value if an earlier entry in the array has the same string
            var elementsUpToHereWithThisName = 1
            for (i in resultAsInteger - 1 downTo 0) {
                val previousValue = options[i]
                if (previousValue == value) elementsUpToHereWithThisName++
            }
            if (value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length - 1)
            if (elementsUpToHereWithThisName > 1) value += "~" + elementsUpToHereWithThisName

            // add quotes around it if it contains a space
            if (value.contains(' ')) value = "\"$value\""

            return value
        }
    }
    fun getComboOptions(model: IDataModel): Iterable<ComboOption> { /*@DONE ArrayRunEnumSegment.GetComboOptions/1 cs:231-254*/
        val defaultOptions = getOptions(model)
            .mapIndexed { i, option -> ComboOption(option, i) }
            .filter { combo -> combo.text != null }
            .toMutableList()
        val tableRun = model.getNextRun(model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, enumName)) as? ITableRun ?: return defaultOptions
        val pointerSegment = tableRun.elementContent[0] as? ArrayRunPointerSegment ?: return defaultOptions
        if (!LzSpriteRun.tryParseSpriteFormat(pointerSegment.innerFormat, Ref(SpriteFormat())) && !SpriteRun.tryParseSpriteFormat(pointerSegment.innerFormat, Ref(SpriteFormat()))) return defaultOptions

        val imageOptions = ArrayList<ComboOption>()
        for (i in 0 until tableRun.elementCount) {
            val destination = model.readPointer(tableRun.start + tableRun.elementLength * i)
            val run = model.getNextRun(destination) as? ISpriteRun ?: return defaultOptions
            val sprite = run.getPixels(model, 0, i)
            val paletteAddress = SpriteTool.findMatchingPalette(model, run, 0)
            val paletteRun = model.getNextRun(paletteAddress) as? IPaletteRun
            val palette: List<Short> = paletteRun?.getPalette(model, paletteRun.paletteFormat.initialBlankPages) ?: TileViewModel.createDefaultPalette(16).toList()
            val image = SpriteTool.render(sprite, palette, paletteRun?.paletteFormat?.initialBlankPages ?: 0, 0)
            val option = VisualComboOption.createFromSprite(defaultOptions[i].text!!, image, sprite!!.size, i, 1.0, true)
            imageOptions.add(option)
        }

        return imageOptions
    }
    override fun write(parentSegments: List<ArrayRunElementSegment>?, model: IDataModel, token: ModelDelta, start: Int, data: Ref<String>): Boolean { /*@DONE ArrayRunEnumSegment.Write/1 cs:256-276*/
        if (data.value.startsWith("(") && data.value.endsWith(")")) data.value = data.value.substring(1, data.value.length - 1)
        val tokens = TableStreamRun.tokenize(data.value)
        if (tokens.size == 0) return false
        var remainder = ""
        if ((parentSegments?.size ?: 0) > 1) {
            data.value = tokens[0]
            remainder = tokens.drop(1).joinToString(", ")
        }
        val result: Boolean

        val value = Ref(0)
        if (!tryParse(model, data.value, value)) {
            result = super.write(parentSegments, model, token, start, data)
        } else {
            data.value = value.value.toString()
            result = super.write(parentSegments, model, token, start, data)
        }

        data.value = remainder
        return result
    }
    fun tryParse(model: IDataModel, text: String, value: Ref<Int>): Boolean { /*@DONE ArrayRunEnumSegment.TryParse/1 cs:278-282*/
        val result = tryParse(enumName, model, text, value)
        value.value += valueOffset
        return result
    }
    override fun getOptions(model: IDataModel): List<String> { /*@DONE ArrayRunEnumSegment.GetOptions/1 cs:334-334*/
        return getOptions(model, enumName)
    }
    fun getBestOptions(model: IDataModel, match: String): Iterable<String> { /*@DONE ArrayRunEnumSegment.GetBestOptions/1 cs:336-336*/
        return getBestOptions(getOptions(model, enumName), match)
    }
    companion object {
        fun tryParse(enumName: String, model: IDataModel, text: String, value: Ref<Int>): Boolean { /*@DONE ArrayRunEnumSegment.TryParse/2 cs:284-287*/
            val options = model.getOptions(enumName)
            return tryMatch(text, options, value)
        }
        fun tryMatch(text: String, list: List<String>, value: Ref<Int>): Boolean { /*@DONE ArrayRunEnumSegment.TryMatch/1 cs:289-332*/
            var text = text.trim()
            if (tryParseInt(text, value)) return true
            value.value = 0
            if (text.startsWith("\"")) text = text.substring(1)
            if (text.endsWith("\"")) text = text.substring(0, text.length - 1)
            if (text.length == 0) return false
            val partialMatches = ArrayList<Int>()
            val matches = ArrayList<String>()

            // if the ~ character is used, expect that it's saying which match we want
            val desiredMatchRef = Ref(1)
            val splitIndex = text.indexOf('~')
            if (splitIndex != -1 && !tryParseInt(text.substring(splitIndex + 1), desiredMatchRef)) return false
            if (splitIndex == -1) desiredMatchRef.value = 1
            val desiredMatch = desiredMatchRef.value
            if (splitIndex != -1) text = text.substring(0, splitIndex)

            // ok, so everything lines up... check the array to see if any values match the string entered
            text = text.lowercase()
            val options = list
            for (i in 0 until options.size) {
                var option = (options[i] ?: i.toString()).lowercase().split("~")[0]
                if (option.startsWith("\"")) option = option.substring(1)
                if (option.endsWith("\"")) option = option.substring(0, option.length - 1)
                if (option == text) matches.add(option)
                if (matches.size == desiredMatch) { value.value = i; return true }
                if (option.matchesPartial(text, text.length > 3)) {
                    partialMatches.add(i)
                    if (partialMatches.size == desiredMatch && matches.size == 0) value.value = i
                }
            }
            if (matches.size == 0 && partialMatches.size >= desiredMatch) {
                // no full matches, use the partial match
                // match priority, lowest to highest: prefer partial matches with
                //   lower IDs
                //   lower skip count
                //   earlier starts
                partialMatches.sortWith { a, b -> options[a].skipCount(text) - options[b].skipCount(text) }
                partialMatches.sortWith { a, b -> options[a].indexOf(text[0], 0, true) - options[b].indexOf(text[0], 0, true) }
                value.value = partialMatches[(desiredMatch - 1).limitToRange(0, partialMatches.size - 1)]
                return true
            }

            // we went through the whole array and didn't find it :(
            return false
        }
        fun getOptions(model: IDataModel, enumName: String): List<String> { /*@DONE ArrayRunEnumSegment.GetOptions/2 cs:338-351*/
            val result = Ref(0)
            if (enumName.tryParseInt(result)) return getNumericOptions(result.value)
            var options: List<String> = model.getOptions(enumName)

            // we _need_ options for the table tool
            // if we have none, just create "0", "1", ..., "n-1" based on the length of the EnumName table.
            if (!options.any()) {
                val tableRun = model.getNextRun(model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, enumName)) as? ITableRun
                if (tableRun != null) {
                    options = getNumericOptions(tableRun.elementCount)
                }
            }

            return options
        }
        fun getBestOptions(options: Iterable<String>, text: String, onlyCheckLettersAndDigits: Boolean = false): Iterable<String> { /*@DONE ArrayRunEnumSegment.GetBestOptions/2 cs:356-360*/
            var ops = options.filter { option -> option?.matchesPartial(text, onlyCheckLettersAndDigits) ?: false }.asIterable()
            ops = ScriptParser.sortOptions(ops, text) { op -> op }
            return ops
        }
        private val numericOptions: MutableList<String> = /*@INITDONE ArrayRunEnumSegment.numericOptions cs:362-362*/ ArrayList() /*@ENDINIT*/
        fun getNumericOptions(count: Int): List<String> { /*@DONE ArrayRunEnumSegment.GetNumericOptions/1 cs:363-368*/
            while (numericOptions.size < count) numericOptions.add(numericOptions.size.toString())
            val options = ArrayList<String>(count)
            for (i in 0 until count) options.add(numericOptions[i])
            return options
        }
        /*@END ArrayRunEnumSegment.Companion*/
    }
    /*@END ArrayRunEnumSegment*/
}

open class ArrayRunRecordSegment : ArrayRunElementSegment { // cs:372-445
    var matchField: String = ""
        private set
    var enumForValue: Map<Int, String> = LinkedHashMap()
        private set
    override val serializeFormat: String
        get() { /*@DONE ArrayRunRecordSegment.SerializeFormat.get cs:377-380*/
            val records = enumForValue.entries.sortedBy { pair -> pair.key }.joinToString("|") { pair -> "${pair.key}=${pair.value}" }
            return "${super.serializeFormat}|s=$matchField($records)"
        }
    constructor(name: String, length: Int, recordSwitch: String) : super(name, ElementContentType.Integer, length) { /*@DONE ArrayRunRecordSegment.<init>/1 cs:383-399*/
        Debug.assert(recordSwitch.startsWith("|s="))
        Debug.assert(recordSwitch.contains("(") && recordSwitch.contains(")"))
        var switchText = recordSwitch.substring(3)
        matchField = switchText.split("(")[0]
        if (matchField.isNullOrEmpty()) throw ArrayRunParseException("Record format is s={name}({number}={enum}|...).")
        switchText = switchText.substring(matchField.length + 1).replace(")", "")

        val enumForValue = LinkedHashMap<Int, String>()
        for (pair in switchText.split("|")) {
            val keyAndValue = pair.split("=")
            if (keyAndValue.size != 2) continue
            val key = Ref(0)
            if (!tryParseInt(keyAndValue[0], key)) continue
            enumForValue[key.value] = keyAndValue[1]
        }
        this.enumForValue = enumForValue
    }
    fun createConcrete(model: IDataModel, offset: Int): ArrayRunElementSegment { /*@DONE ArrayRunRecordSegment.CreateConcrete/1 cs:401-404*/
        val table = model.getNextRun(offset) as ITableRun
        return createConcrete(model, table, offset)
    }
    fun createConcrete(model: IDataModel, table: ITableRun, offset: Int): ArrayRunElementSegment { /*@DONE ArrayRunRecordSegment.CreateConcrete/2 cs:406-421*/
        val defaultConcrete = ArrayRunElementSegment(name, ElementContentType.Integer, length, this.textConverter)
        var matchFieldOffset = 0
        var matchFieldIndex = 0
        for (i in 0 until table.elementContent.size) {
            if (table.elementContent[i].name == matchField) break
            matchFieldOffset += table.elementContent[i].length
            matchFieldIndex += 1
        }
        if (matchFieldOffset == table.elementLength) return defaultConcrete
        val offsets = table.convertByteOffsetToArrayOffset(offset)!!
        val fieldStart = table.start + offsets.elementIndex * table.elementLength + matchFieldOffset
        if (!(fieldStart >= 0 && fieldStart < model.count)) return defaultConcrete
        val matchFieldValue = model.readMultiByteValue(fieldStart, table.elementContent[matchFieldIndex].length)
        return createConcrete(model.formatRunFactory, model.textConverter, matchFieldValue)
    }
    fun createConcrete(formatRunFactory: IFormatRunFactory, textConverter: ITextConverter, matchFieldValue: Int): ArrayRunElementSegment { /*@DONE ArrayRunRecordSegment.CreateConcrete/3 cs:423-434*/
        val defaultConcrete = ArrayRunElementSegment(name, ElementContentType.Integer, length, this.textConverter)
        var enumName = enumForValue[matchFieldValue] ?: return defaultConcrete

        if (enumName.startsWith("<") && enumName.endsWith(">")) {
            enumName = enumName.substring(1, enumName.length - 1)
            if (enumName.length > 0) return ArrayRunPointerSegment(formatRunFactory, name, enumName)
            return ArrayRunElementSegment(name, ElementContentType.Pointer, 4, textConverter)
        }

        return ArrayRunEnumSegment(name, length, enumName)
    }
    fun toText(model: IDataModel, table: ITableRun, offset: Int, depth: Int = 0): String? { /*@DONE ArrayRunRecordSegment.ToText/1 cs:436-438*/
        return createConcrete(model, table, offset).toText(model, offset, depth)
    }
    override fun toText(rawData: IDataModel, offset: Int, depth: Int): String? { /*@DONE ArrayRunRecordSegment.ToText/2 cs:440-442*/
        return createConcrete(rawData, offset).toText(rawData, offset, depth)
    }
    fun dependsOn(anchorName: String): Boolean { /*@DONE ArrayRunRecordSegment.DependsOn/1 cs:444-444*/
        return enumForValue.values.contains(anchorName)
    }
    /*@END ArrayRunRecordSegment*/
}

open class ArrayRunHexSegment : ArrayRunElementSegment { // cs:447-474
    override val serializeFormat: String
        get() { /*@DONE ArrayRunHexSegment.SerializeFormat.get cs:448-448*/
            return super.serializeFormat + ArrayRun.hexFormatString
        }
    constructor(name: String, length: Int) : super(name, ElementContentType.Integer, length) { /*@DONE ArrayRunHexSegment.<init>/1 cs:450-451*/
        // the base constructor does all the work
    }
    override fun toText(rawData: IDataModel, offset: Int, depth: Int): String? { /*@DONE ArrayRunHexSegment.ToText/1 cs:453-457*/
        val hexLength = length * 2
        val hex = rawData.readMultiByteValue(offset, length).toHex(hexLength)
        return hex
    }
    override fun write(parentSegments: List<ArrayRunElementSegment>?, model: IDataModel, token: ModelDelta, start: Int, data: Ref<String>): Boolean { /*@DONE ArrayRunHexSegment.Write/1 cs:459-473*/
        if (data.value.startsWith("(") && data.value.endsWith(")")) data.value = data.value.substring(1, data.value.length - 1)
        var remainder = ""
        if (type != ElementContentType.PCS) {
            val tokens = TableStreamRun.tokenize(data.value)
            remainder = tokens.drop(1).joinToString(", ")
            data.value = if (tokens.size > 0) tokens[0] else ""
        }

        data.value = data.value.trim()
        if (data.value.startsWith("0x")) data.value = data.value.substring(2)
        val intValue = Ref(0)
        if (!tryParseHexInt(data.value, intValue)) intValue.value = 0
        data.value = remainder
        return model.writeMultiByteValue(start, length, token, intValue.value)
    }
    /*@END ArrayRunHexSegment*/
}

open class ArrayRunTupleSegment : ArrayRunHexSegment { // cs:476-603
    override val serializeFormat: String
        get() { /*@DONE ArrayRunTupleSegment.SerializeFormat.get cs:478-482*/
            var format = super.serializeFormat
            format = format.substring(0, format.length - ArrayRun.hexFormatString.length)
            return format + "|t" + elements.joinToString("") { e -> e.format ?: "" }
        }
    var elements: List<TupleSegment> = ArrayList()
        private set
    val visibleElementCount: Int
        get() { /*@DONE ArrayRunTupleSegment.VisibleElementCount.get cs:485-485*/
            return elements.size - elements.count { e -> e.name.isNullOrEmpty() }
        }
    constructor(name: String, contract: String, length: Int) : super(name, length) { /*@DONE ArrayRunTupleSegment.<init>/1 cs:486-498*/
        val content = ArrayList<TupleSegment>()
        for (part in contract.split('|').filter { it.isNotEmpty() }) {
            val elementName = part.split('.', ':')[0]
            val elementEnumName = part.split('.', ':').filter { it.isNotEmpty() }.drop(1).joinToString(".")
            val elementFormat = part.substring(elementName.length, part.length - elementEnumName.length)
            val elementSize = elementFormat.fold(0) { acc, c -> acc + (if (c == '.') 1 else if (c == ':') 2 else 0) }
            if (elementSize == 0) throw ArrayRunParseException("$elementName: tuple element needs to have a length.")
            content.add(TupleSegment(elementName, elementSize, elementEnumName))
        }
        elements = content
        if (content.sumOf { seg -> seg.bitWidth } > length * 8) throw ArrayRunParseException("$name: tuple too long to fit in field!")
    }
    override fun toText(rawData: IDataModel, offset: Int, depth: Int): String? { /*@DONE ArrayRunTupleSegment.ToText/1 cs:500-520*/
        var result = "("
        var bitOffset = 0
        for (segment in elements) {
            if (segment.name.isNullOrEmpty()) {
                // don't append unnamed segments
            } else if (!segment.sourceName.isNullOrEmpty()) {
                val options = rawData.getOptions(segment.sourceName)
                val value = segment.read(rawData, offset, bitOffset)
                val text = if (options.size > value) options[value] else value.toString()
                result += if (text.contains(" ") && !text.contains("\"")) "\"" + text + "\"" else text
                result += " "
            } else if (segment.bitWidth == 1) {
                result += if (segment.read(rawData, offset, bitOffset) == 1) "true " else "false "
            } else {
                result += segment.read(rawData, offset, bitOffset).toString() + " "
            }
            bitOffset += segment.bitWidth
        }
        return result.trim() + ")"
    }
    override fun write(parentSegments: List<ArrayRunElementSegment>?, model: IDataModel, token: ModelDelta, start: Int, data: Ref<String>): Boolean { /*@DONE ArrayRunTupleSegment.Write/1 cs:522-556*/
        val parts = data.value.split("(", ")", " ").filter { it.isNotEmpty() }.toMutableList()
        TableStreamRun.recombine(parts, "\"", "\"")
        data.value = ""
        if (parts.size != visibleElementCount) return false
        var bitOffset = 0
        var partIndex = 0
        var anyChanges = false
        for (i in 0 until elements.size) {
            if (elements[i].name.isNullOrEmpty()) {
                // Unnamed segments. I should increment, and  bitOffset should increase, but the value should change to zero.
                anyChanges = elements[i].write(model, token, start, bitOffset, 0) or anyChanges
                partIndex -= 1
            } else if (!elements[i].sourceName.isNullOrEmpty()) {
                val value = Ref(0)
                if (ArrayRunEnumSegment.tryParse(elements[i].sourceName, model, parts[partIndex], value))
                    anyChanges = elements[i].write(model, token, start, bitOffset, value.value) or anyChanges
            } else if (elements[i].bitWidth == 1) {
                val boolText = parts[partIndex].trim().lowercase()
                if (boolText == "true" || boolText == "false")
                    anyChanges = elements[i].write(model, token, start, bitOffset, if (boolText == "true") 1 else 0) or anyChanges
            } else {
                val value = Ref(0)
                if (tryParseInt(parts[partIndex], value))
                    anyChanges = elements[i].write(model, token, start, bitOffset, value.value) or anyChanges
            }

            partIndex += 1
            bitOffset += elements[i].bitWidth
        }

        val remainingBits = length * 8 - bitOffset
        if (remainingBits > 0) {
            anyChanges = TupleSegment("", remainingBits).write(model, token, start, bitOffset, 0) or anyChanges
        }

        return anyChanges
    }
    fun getAutocomplete(model: IDataModel, text: String): List<AutocompleteItem>? { /*@DONE ArrayRunTupleSegment.GetAutocomplete/1 cs:558-579*/
        var tupleTokens = text.split(" ").toMutableList()
        TableStreamRun.recombine(tupleTokens, "\"", "\"")
        if (tupleTokens[0].startsWith("(")) tupleTokens[0] = tupleTokens[0].substring(1)
        val visibleTupleElements = elements.filter { element -> !element.name.isNullOrEmpty() }
        var optionToken = tupleTokens.last()
        tupleTokens = tupleTokens.take(tupleTokens.size - 1).toMutableList()
        if (visibleTupleElements.size > tupleTokens.size) {
            val tupleToken = visibleTupleElements[tupleTokens.size]
            if (optionToken.startsWith("\"")) optionToken = optionToken.substring(1)
            if (optionToken.endsWith("\"")) optionToken = optionToken.substring(0, optionToken.length - 1)
            if (!tupleToken.sourceName.isNullOrEmpty()) {
                val optionText = ArrayRunEnumSegment.getBestOptions(ArrayRunEnumSegment.getOptions(model, tupleToken.sourceName), optionToken)
                return createTupleEnumAutocompleteOptions(tupleTokens, optionText)
            } else if (tupleToken.bitWidth == 1) {
                val optionText = arrayOf("false", "true").filter { option -> option.matchesPartial(optionToken) }
                return createTupleEnumAutocompleteOptions(tupleTokens, optionText)
            }
        }

        return null
    }
    fun dependsOn(anchorName: String): Boolean { /*@DONE ArrayRunTupleSegment.DependsOn/1 cs:581-581*/
        return elements.any { element -> element.sourceName == anchorName }
    }
    fun constructAutocompleteLine(previousTokens: List<String>, option: String): String { /*@DONE ArrayRunTupleSegment.ConstructAutocompleteLine/1 cs:583-591*/
        var newLine = "("
        newLine += previousTokens.joinToString(" ")
        if (previousTokens.size > 0) newLine += " "
        newLine += option
        if (previousTokens.size + 1 < visibleElementCount) newLine += " "
        if (previousTokens.size + 1 == visibleElementCount) newLine += ")"
        return newLine
    }
    private fun createTupleEnumAutocompleteOptions(previousTokens: List<String>, newToken: Iterable<String>): List<AutocompleteItem> { /*@DONE ArrayRunTupleSegment.CreateTupleEnumAutocompleteOptions/1 cs:593-602*/
        val results = ArrayList<AutocompleteItem>()

        for (option in newToken) {
            val newLine = constructAutocompleteLine(previousTokens, option)
            results.add(AutocompleteItem(option, newLine))
        }

        return results
    }
    /*@END ArrayRunTupleSegment*/
}

open class TupleSegment { // cs:605-638
    var name: String = ""
        private set
    var sourceName: String = ""
        private set
    val format: String?
        get() { /*@DONE TupleSegment.Format.get cs:609-616*/
            val format = StringBuilder("|")
            format.append(name)
            var remainingWidth = bitWidth
            while (remainingWidth >= 2) {
                format.append(":")
                remainingWidth -= 2
            }
            if (bitWidth % 2 == 1) format.append('.')
            if (!sourceName.isNullOrEmpty()) format.append(sourceName)
            return format.toString()
        }
    var bitWidth: Int = 0
        private set
    constructor(name: String, width: Int, sourceName: String? = null) { /*@DONE TupleSegment.<init>/1 cs:619-619*/
        this.name = name
        this.bitWidth = width
        this.sourceName = sourceName ?: ""
    }
    fun read(model: IDataModel, start: Int, bitOffset: Int): Int { /*@DONE TupleSegment.Read/1 cs:620-627*/
        var firstByte = start
        var firstBit = bitOffset
        var requiredByteLength = (firstBit + bitWidth + 7) / 8
        while (requiredByteLength > 4) {
            firstByte += 4
            firstBit -= 32
            requiredByteLength -= 4
        }
        var bitArray = model.readMultiByteValue(firstByte, requiredByteLength)
        bitArray = bitArray shr firstBit
        bitArray = bitArray and ((1 shl bitWidth) - 1)
        return bitArray
    }
    fun write(model: IDataModel?, token: ModelDelta, start: Int, bitOffset: Int, value: Int): Boolean { /*@DONE TupleSegment.Write/1 cs:628-637*/
        var firstByte = start
        var firstBit = bitOffset
        var requiredByteLength = (firstBit + bitWidth + 7) / 8
        while (requiredByteLength > 4) {
            firstByte += 4
            firstBit -= 32
            requiredByteLength -= 4
        }
        var bitArray = model!!.readMultiByteValue(firstByte, requiredByteLength)
        val mask = (1 shl bitWidth) - 1
        val masked = value and mask
        bitArray = bitArray and (mask shl firstBit).inv()
        bitArray = bitArray or (masked shl firstBit)
        return model.writeMultiByteValue(firstByte, requiredByteLength, token, bitArray)
    }
    /*@END TupleSegment*/
}

open class ArrayRunColorSegment : ArrayRunElementSegment { // cs:640-650
    override val serializeFormat: String
        get() { /*@DONE ArrayRunColorSegment.SerializeFormat.get cs:641-641*/
            return super.serializeFormat + ArrayRun.colorFormatString
        }
    constructor(name: String) : super(name, ElementContentType.Integer, 2) { /*@DONE ArrayRunColorSegment.<init>/1 cs:643-643*/
        // the base constructor does all the work
    }
    override fun toText(rawData: IDataModel, offset: Int, depth: Int): String? { /*@DONE ArrayRunColorSegment.ToText/1 cs:645-649*/
        val color = rawData.readMultiByteValue(offset, length).toShort()
        val colorText = UncompressedPaletteColor.convert(color)
        return colorText
    }
    /*@END ArrayRunColorSegment*/
}

open class ArrayRunBitArraySegment : ArrayRunElementSegment, IHasOptions { // cs:652-707
    var sourceArrayName: String = ""
        private set
    override val serializeFormat: String
        get() { /*@DONE ArrayRunBitArraySegment.SerializeFormat.get cs:655-655*/
            return "$name${BitArray.sharedFormatString}$sourceArrayName"
        }
    constructor(name: String, length: Int, bitSourceName: String) : super(name, ElementContentType.BitArray, length) { /*@DONE ArrayRunBitArraySegment.<init>/1 cs:657-659*/
        sourceArrayName = bitSourceName
    }
    override fun toText(rawData: IDataModel, offset: Int, depth: Int): String? { /*@DONE ArrayRunBitArraySegment.ToText/1 cs:661-690*/
        val result = StringBuilder("-")
        val options = rawData.getBitOptions(sourceArrayName)

        // handle edge cases: no options, or no options for some set bits
        var highestByteSet = length - 1
        while (rawData[offset + highestByteSet] == 0 && highestByteSet > 0) {
            highestByteSet -= 1
        }
        val highestBitSet = (Math.log(rawData[offset + highestByteSet].toDouble()) / Math.log(2.0)).toInt()
        val unknownBitsAreSet = options == null || (highestByteSet * 8) + highestBitSet >= options.size

        for (i in 0 until length) {
            val bits = rawData[offset + i]
            if (unknownBitsAreSet) {
                result.append(bits.toHex(2))
            } else {
                val optionOffset = i shl 3
                for (j in 0 until 8) {
                    if ((bits and (1 shl j)) == 0) continue
                    result.append(" ")
                    result.append(options!![optionOffset + j] ?: "")
                }
            }
        }

        result.append(" ")
        if (options != null) result.append("/")
        return result.toString()
    }
    override fun write(parentSegments: List<ArrayRunElementSegment>?, model: IDataModel, token: ModelDelta, start: Int, data: Ref<String>): Boolean { /*@DONE ArrayRunBitArraySegment.Write/1 cs:692-701*/
        var anyChanges = false
        var i = 0
        while (i < length && i * 2 + 1 < data.value.length) {
            val value = Ref(0)
            if (!tryParseHexInt(data.value.substring(i * 2, i * 2 + 2), value)) value.value = 0
            anyChanges = token.changeData(model, start + i, value.value) or anyChanges
            i++
        }

        data.value = ""
        return anyChanges
    }
    override fun getOptions(model: IDataModel): List<String>? { /*@DONE ArrayRunBitArraySegment.GetOptions/1 cs:703-706*/
        val cache = ModelCacheScope.getCache(model)
        return cache.getBitOptions(sourceArrayName)
    }
    /*@END ArrayRunBitArraySegment*/
}

open class ArrayRunPointerSegment : ArrayRunElementSegment { // cs:713-768
    lateinit var factory: IFormatRunFactory
        private set
    var innerFormat: String = ""
        private set
    val isInnerFormatValid: Boolean
        get() { /*@DONE ArrayRunPointerSegment.IsInnerFormatValid.get cs:717-717*/
            return factory.getStrategy(innerFormat) != null
        }
    override val serializeFormat: String
        get() { /*@DONE ArrayRunPointerSegment.SerializeFormat.get cs:719-719*/
            return "$name<$innerFormat>"
        }
    constructor(factory: IFormatRunFactory, name: String, innerFormat: String) : super(name, ElementContentType.Pointer, 4) { /*@DONE ArrayRunPointerSegment.<init>/1 cs:721-724*/
        this.factory = factory
        this.innerFormat = innerFormat
    }
    fun destinationDataMatchesPointerFormat(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE ArrayRunPointerSegment.DestinationDataMatchesPointerFormat/1 cs:726-752*/
        if (destination == Pointer.null_) return true
        val run = owner.getNextRun(destination)!!
        var possibleFalseRun = false
        if (run.start < destination && run !is ITableRun) {
            if (run is PCSRun || run is PointerRun) possibleFalseRun = true // this could have been added automatically and is blocking the correct interpretation of the data
            else return false
        }
        if ((run.start < destination && possibleFalseRun) || run.start > destination || (run.start == destination && (run is NoInfoRun || run is PointerRun))) {
            // hard case: no format found, so check the data
            if (destination < 0 || destination >= owner.count) return false
            return factory.getStrategy(innerFormat)?.tryAddFormatAtDestination(owner, token, source, destination, name, sourceSegments, parentIndex) ?: false
        } else {
            // easy case: already have a format, just see if it matches
            val strategy = factory.getStrategy(innerFormat)
            if (strategy == null) return false
            if (strategy.matches(run)) return true

            // special test: the format of the data is wrong?
            if (run is ITableRun) {
                // just see if we _could_ add it
                val runRef = Ref<IFormattedRun?>(run)
                return !strategy.tryParseData(owner, "", destination, runRef)!!.hasError
            } else {
                return strategy.tryAddFormatAtDestination(owner, token, source, destination, name, sourceSegments, parentIndex)
            }
        }
    }
    fun writeNewFormat(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, sourceSegments: List<ArrayRunElementSegment>) { /*@DONE ArrayRunPointerSegment.WriteNewFormat/1 cs:754-758*/
        owner.writePointer(token, source, destination)
        val newRun = factory.getStrategy(innerFormat)!!.writeNewRun(owner, token, source, destination, name, sourceSegments)
        owner.observeRunWritten(token, newRun.mergeAnchor(SortedSpan(source)))
    }
    private var childIsTable: Boolean? = null
    private var childSegmentCache: MutableList<ArrayRunElementSegment> = ArrayList()
    private lateinit var childEndCache: IStreamEndStrategy
    fun tryParseTableStream(model: IDataModel, start: Int, sources: SortedSpan<Int>, segments: List<ArrayRunElementSegment>, validate: Boolean, tableStream: Ref<TableStreamRun?>): Boolean { /*@DONE ArrayRunPointerSegment.TryParseTableStream/1 cs:763-767*/
        if (childIsTable == null) {
            val segmentsOut = Ref<MutableList<ArrayRunElementSegment>?>(null)
            val endOut = Ref<IStreamEndStrategy?>(null)
            childIsTable = TableStreamRun.tryParseSegmentsAndEndStrategy(model, name, innerFormat, segments, segmentsOut, endOut)
            childSegmentCache = segmentsOut.value ?: ArrayList()
            endOut.value?.let { childEndCache = it }
        }
        if (childIsTable == false) { tableStream.value = null; return false }
        return TableStreamRun.tryBuildTableStream(model, start, sources, name, innerFormat, childSegmentCache, childEndCache, validate, tableStream)
    }
    /*@END ArrayRunPointerSegment*/
}

open class ArrayRunCalculatedSegment : ArrayRunElementSegment { // cs:777-913
    var model: IDataModel? = null
        private set
    var operands: List<String> = ArrayList()
        private set
    var operator: String = ""
        private set
    val hasOperator: Boolean
        get() { /*@DONE ArrayRunCalculatedSegment.HasOperator.get cs:781-781*/
            return !this.operator.isNullOrEmpty()
        }
    var enum: String? = null
        private set
    override val serializeFormat: String
        get() { /*@DONE ArrayRunCalculatedSegment.SerializeFormat.get cs:784-784*/
            return name + "|=" + operands.joinToString(this.operator) + enumPostfix
        }
    private val enumPostfix: String
        get() { /*@DONE ArrayRunCalculatedSegment.EnumPostfix.get cs:785-785*/
            return if (this.enum != null) "|" + this.enum else ""
        }
    constructor(model: IDataModel, name: String, contract: String) : super(name, ElementContentType.Integer, 0) { /*@DONE ArrayRunCalculatedSegment.<init>/1 cs:787-814*/
        this.model = model
        var contractText = contract
        if (contractText.contains("|")) {
            val parts = contractText.split("|")
            contractText = parts[0]
            this.enum = parts[1]
        }

        if (contractText.contains("*")) {
            this.operands = contractText.split('*')
            this.operator = "*"
        } else if (contractText.contains("+")) {
            this.operands = contractText.split('+')
            this.operator = "+"
        } else if (contractText.contains("\u00f7")) {
            this.operands = contractText.split('\u00f7')
            this.operator = "\u00f7"
        } else if (contractText.contains("%")) {
            this.operands = contractText.split('%')
            this.operator = "%"
        } else {
            this.operands = listOf(contractText)
            this.operator = ""
        }
    }
    fun calculatedValue(index: Int): Double { /*@DONE ArrayRunCalculatedSegment.CalculatedValue/1 cs:816-829*/
        if (operands[0].isNullOrEmpty()) return 0.0
        val table = model!!.getNextRun(index) as ITableRun
        val offset = table.convertByteOffsetToArrayOffset(index)!!

        val values = operands.map { operand -> parseValue(model!!, table, offset.elementIndex, operand) }
        when (this.operator) {
            "+" -> return values.reduce { a, b -> a + b }
            "*" -> return values.reduce { a, b -> a * b }
            "\u00f7" -> return values.reduce { a, b -> if (b == 0.0) 0.0 else a / b }
            "%" -> return (values[0].toInt() % values[1].toInt()).toDouble()
            else -> return values.first()
        }
    }
    companion object {
        fun calculateSource(model: IDataModel, table: ITableRun?, elementIndex: Int, content: String): Int { /*@DONE ArrayRunCalculatedSegment.CalculateSource/1 cs:831-869*/
            if (content.isNullOrEmpty()) return Pointer.null_
            if (tryParseInt(content, Ref(0))) return Pointer.null_

            val tableSegment = table?.elementContent?.firstOrNull { seg -> seg.name == content }
            if (tableSegment != null) {
                return table.start + table.elementLength * elementIndex +
                    table.elementContent.until { seg -> seg === tableSegment }.sumOf { seg -> seg.length }
            }

            if (content.matchesPartial("(/=)/")) {
                val parts = content.split('(', '/', '=', ')')
                if (parts.size != 6) return Pointer.null_
                if (!parts[0].isNullOrEmpty() || !parts[4].isNullOrEmpty()) return Pointer.null_
                val matchTableName = parts[1]
                val matchTableField = parts[2]
                val matchLocalField = parts[3]
                val localFieldValue = parseValue(model, table, elementIndex, matchLocalField)
                val valueField = parts[5]
                val matchTable = model.getTable(matchTableName)
                if (matchTable == null) return Pointer.null_
                for (i in 0 until matchTable.elementCount) {
                    if (matchTable.readValue(model, i, matchTableField).toDouble() != localFieldValue) continue
                    return calculateSource(model, matchTable, i, valueField)
                }
                return calculateSource(model, matchTable, matchTable.elementCount, valueField)
            }
            if (content.matchesPartial("//")) {
                val parts = content.split("/")
                if (parts.size != 3) return Pointer.null_
                val destination = table!!.readPointer(model, elementIndex, parts[0])
                val childTable = model.getNextRun(destination) as? ITableRun
                if (childTable == null) return Pointer.null_
                val childTableIndex = parseValue(model, childTable, elementIndex, parts[1]).toInt()
                return calculateSource(model, childTable, childTableIndex, parts[2])
            }

            return Pointer.null_
        }
        fun parseValue(model: IDataModel, table: ITableRun?, elementIndex: Int, content: String): Double { /*@DONE ArrayRunCalculatedSegment.ParseValue/1 cs:871-912*/
            if (content.isNullOrEmpty()) return 0.0
            val simpleValue = Ref(0.0)
            if (tryParseDouble(content, simpleValue)) return simpleValue.value
            if (content == "last") return (table!!.elementCount - 1).toDouble()

            if (table != null && table.elementContent.any { seg -> seg.name == content }) {
                return table.readValue(model, elementIndex, content).toDouble()
            }

            if (content.matchesPartial("(/=)/")) {
                val parts = content.split('(', '/', '=', ')')
                val message = "Expected $content to fit the form (table/field=local)/field. But it didn't."
                if (parts.size != 6) throw NotImplementedException(message)
                if (!parts[0].isNullOrEmpty() || !parts[4].isNullOrEmpty()) throw NotImplementedException(message)
                val matchTableName = parts[1]
                val matchTableField = parts[2]
                val matchLocalField = parts[3]
                val localFieldValue = parseValue(model, table, elementIndex, matchLocalField)
                val valueField = parts[5]
                val matchTable = model.getTable(matchTableName)
                if (matchTable == null) return 0.0
                for (i in 0 until matchTable.elementCount) {
                    if (matchTable.readValue(model, i, matchTableField).toDouble() != localFieldValue) continue
                    return parseValue(model, matchTable, i, valueField)
                }
                return parseValue(model, matchTable, matchTable.elementCount - 1, valueField)
            }
            if (content.matchesPartial("//")) {
                val parts = content.split("/")
                val message = "Expected $content to fit the form field/index/field. But it didn't."
                if (parts.size != 3) throw NotImplementedException(message)
                val destination = table!!.readPointer(model, elementIndex, parts[0])
                if (destination == Pointer.null_) return 0.0
                val childTable = model.getNextRun(destination) as? ITableRun
                if (childTable == null) throw NotImplementedException(message)
                val childTableIndex = parseValue(model, childTable, elementIndex, parts[1]).toInt()
                return parseValue(model, childTable, childTableIndex, parts[2])
            }

            // failed to find a match for the content
            return 0.0
        }
        /*@END ArrayRunCalculatedSegment.Companion*/
    }
    /*@END ArrayRunCalculatedSegment*/
}

open class ArrayRunPythonButtonSegment : ArrayRunElementSegment { // cs:915-923
    var model: IDataModel? = null
        private set
    var functionName: String = ""
        private set
    override val serializeFormat: String
        get() { /*@DONE ArrayRunPythonButtonSegment.SerializeFormat.get cs:918-918*/
            return name + "|python=" + functionName
        }
    constructor(model: IDataModel, name: String, contract: String) : super(name, ElementContentType.Integer, 0) { /*@DONE ArrayRunPythonButtonSegment.<init>/1 cs:919-922*/
        this.model = model
        this.functionName = contract
    }
    /*@END ArrayRunPythonButtonSegment*/
}

open class ArrayRunOffsetRenderSegment : ArrayRunElementSegment { // cs:925-970
    var background: String = ""
        private set
    var backgroundX: Int = 0
        private set
    var backgroundY: Int = 0
        private set
    var backgroundWidth: Int = 0
        private set
    var backgroundHeight: Int = 0
        private set
    var foreground: String = ""
        private set
    var x: Int = 0
        private set
    var y: Int = 0
        private set
    var targetFieldX: String = ""
        private set
    var targetFieldY: String = ""
        private set
    override val serializeFormat: String
        get() { /*@DONE ArrayRunOffsetRenderSegment.SerializeFormat.get cs:938-938*/
            return "$name|render=$background|$backgroundX|$backgroundY|$backgroundWidth|$backgroundHeight|$foreground|$x|$y|$targetFieldX|$targetFieldY"
        }
    constructor(name: String, contract: String) : super(name, ElementContentType.Integer, 0) { /*@DONE ArrayRunOffsetRenderSegment.<init>/1 cs:940-953*/
        val parts = contract.split("|")
        background = get(parts, 0)
        backgroundX = getInt(parts, 1)
        backgroundY = getInt(parts, 2)
        backgroundWidth = getInt(parts, 3)
        backgroundHeight = getInt(parts, 4)

        foreground = get(parts, 5)
        x = getInt(parts, 6)
        y = getInt(parts, 7)
        targetFieldX = get(parts, 8)
        targetFieldY = get(parts, 9)
    }
    private var previousRun: ISpriteRun? = null
    private var previousRender: IPixelViewModel? = null
    fun renderBackground(model: IDataModel): IPixelViewModel? { /*@DONE ArrayRunOffsetRenderSegment.RenderBackground/1 cs:958-965*/
        val spriteRun = model.getNextRun(model.getAddressFromAnchor(ModelDelta(), -1, background)) as? ISpriteRun ?: return null
        if (spriteRun === previousRun) return previousRender
        var pixels: IPixelViewModel = SpriteDecorator.buildSprite(model, spriteRun)!!
        pixels = ReadonlyPixelViewModel.crop(pixels, backgroundX, backgroundY, backgroundWidth, backgroundHeight) // (gba screen width, height of pokemon battle background)
        previousRun = spriteRun
        previousRender = pixels
        return pixels
    }
    companion object {
        private fun get(array: Array<String>, index: Int): String { /*@DONE ArrayRunOffsetRenderSegment.Get/1 cs:967-967*/
            return if (array.size > index) array[index] else ""
        }
        private fun getInt(array: Array<String>, index: Int): Int { /*@DONE ArrayRunOffsetRenderSegment.GetInt/1 cs:969-969*/
            if (array.size > index) {
                val result = Ref(0)
                if (tryParseInt(array[index], result)) return result.value
            }
            return 0
        }
        /*@END ArrayRunOffsetRenderSegment.Companion*/
    }
    /*@END ArrayRunOffsetRenderSegment*/
}

open class ArrayRunSplitterSegment : ArrayRunElementSegment { // cs:972-976
    constructor() : super("", ElementContentType.Integer, 0) { /*@DONE ArrayRunSplitterSegment.<init>/1 cs:974-974*/
        // the base constructor does all the work
    }
    override val serializeFormat: String
        get() { /*@DONE ArrayRunSplitterSegment.SerializeFormat.get cs:975-975*/
            return separator
        }
    companion object {
        const val separator: String = "|"
        /*@END ArrayRunSplitterSegment.Companion*/
    }
    /*@END ArrayRunSplitterSegment*/
}
