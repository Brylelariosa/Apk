// Port of Models/Runs/TableStreamRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class TableStreamRun : BaseRun, IStreamRun, ITableRun, IUpdateFromParentRun { // cs:11-547
    private lateinit var model: IDataModel
    private lateinit var endStream: IStreamEndStrategy
    override val canAppend: Boolean
        get() { /*@DONE TableStreamRun.CanAppend.get cs:15-15*/
            return !(endStream is FixedLengthStreamStrategy || endStream is DynamicStreamStrategy)
        }
    val allowsZeroElements: Boolean
        get() { /*@DONE TableStreamRun.AllowsZeroElements.get cs:17-17*/
            return endStream is EndCodeStreamStrategy
        }
    override val repointContentShortName: String
        get() { /*@DONE TableStreamRun.RepointContentShortName.get cs:19-19*/
            return "Table"
        }
    constructor(model: IDataModel, start: Int, sources: SortedSpan<Int>?, formatString: String, parsedSegments: List<ArrayRunElementSegment>?, endStream: IStreamEndStrategy) : this(model, start, sources, formatString, parsedSegments, endStream, -1) { /*@DONE TableStreamRun.<init>/1 cs:113-120*/ }
    constructor(model: IDataModel, start: Int, sources: SortedSpan<Int>?, formatString: String, parsedSegments: List<ArrayRunElementSegment>?, endStream: IStreamEndStrategy, elementCountOverride: Int) : super(start, sources) { /*@DONE TableStreamRun.<init>/2 cs:122-139*/
        val segments = parsedSegments ?: ArrayRun.parseSegments(formatString.substring(1, formatString.length - 1), model)
        this.model = model
        this.elementContent = segments
        this.endStream = endStream
        this.elementLength = segments.sumOf { segment -> segment.length }
        this.elementCount = if (elementCountOverride >= 0) elementCountOverride else endStream.getCount(this, start, this.elementLength, sources)
        this.length = this.elementLength * this.elementCount + endStream.extraLength
        this.formatString = formatString
    }
    private var cachedCurrentString: String = ""
    private var currentCachedStartIndex: Int = /*@INITAUTO TableStreamRun.currentCachedStartIndex cs:146-146*/ -1 /*@ENDINIT*/
    private var currentCachedIndex: Int = /*@INITAUTO TableStreamRun.currentCachedIndex cs:146-146*/ -1 /*@ENDINIT*/
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE TableStreamRun.CreateDataFormat/1 cs:147-169*/
        val naturalLength = elementCount * elementLength
        val naturalStop = start + naturalLength
        if (index >= naturalStop) return EndStream(naturalStop, index - naturalStop, length - naturalLength)

        val offsets = this.convertByteOffsetToArrayOffset(index)
        val currentSegment = elementContent[offsets.segmentIndex]
        if (currentSegment.type == ElementContentType.PCS) {
            if (currentCachedStartIndex != offsets.segmentStart || currentCachedIndex > offsets.segmentOffset) {
                currentCachedStartIndex = offsets.segmentStart
                currentCachedIndex = offsets.segmentOffset
                cachedCurrentString = data.textConverter.convert(data, offsets.segmentStart, currentSegment.length) ?: ""
            }

            val pcsFormat = PCSRun.createPCSFormat(data, offsets.segmentStart, index, cachedCurrentString)
            if (offsets.segmentIndex == 0) return StreamEndDecorator(pcsFormat)
            return pcsFormat
        }

        val format = this.createSegmentDataFormat(data, index)
        if (offsets.segmentIndex == 0) return StreamEndDecorator(format)
        return format
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE TableStreamRun.Clone/1 cs:171-172*/
        return TableStreamRun(model, start, newPointerSources, formatString, elementContent, endStream, elementCount)
    }
    override fun serializeRun(): String? { /*@DONE TableStreamRun.SerializeRun/1 cs:178-191*/
        val es = endStream
        if (es is FixedLengthStreamStrategy && es.count == 1) return serializeSingleElementStream()
        val builder = StringBuilder()
        appendTo(model, builder, start, elementLength * elementCount, 0)
        val lines = builder.toString().split(NEW_LINE)

        // AppendTo is used in copy/paste scenarios, and includes the required '+' to work in that case.
        // strip the '+', as it's not needed for stream serialization, which uses newlines instead.
        return lines.map { line ->
            if (line.length == 0) line
            else if (line[0] != ArrayRun.extendArray) line
            else line.substring(1)
        }.joinToString(NEW_LINE)
    }
    override fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, movedChildren: Ref<List<Int>?>): IStreamRun { /*@DONE TableStreamRun.DeserializeRun/1 cs:193-197*/
        val children = Ref<MutableList<Int>?>(null)
        val result = deserializeRun2(content, token, changedOffsets, children)
        movedChildren.value = children.value
        return result
    }
    fun deserializeRunFromZero(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, movedChildren: Ref<MutableList<Int>?>): TableStreamRun { /*@DONE TableStreamRun.DeserializeRunFromZero/1 cs:199-201*/
        return deserializeRun(content, token, 0, changedOffsets, movedChildren)
    }
    fun deserializeRun2(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, movedChildren: Ref<MutableList<Int>?>): TableStreamRun { /*@DONE TableStreamRun.DeserializeRun/2 cs:203-205*/
        return deserializeRun(content, token, elementCount, changedOffsets, movedChildren)
    } // FIXME-SKEL renamed overload
    private fun deserializeRun(content: String, token: ModelDelta, lengthOverride: Int, changedOffsets: Ref<List<Int>?>, movedChildren: Ref<MutableList<Int>?>): TableStreamRun { /*@DONE TableStreamRun.DeserializeRun/3 cs:207-246*/
        val es0 = endStream
        if (es0 is FixedLengthStreamStrategy && es0.count == 1) return deserializeSingleElementStream(content, token, changedOffsets, movedChildren)
        var self = this
        if (lengthOverride != elementCount) self = TableStreamRun(model, start, pointerSources, formatString, elementContent, endStream, lengthOverride)
        val changedAddresses = ArrayList<Int>()
        var lines: List<String> = content.split('\n', '\r').filter { line -> line.length > 0 }.filter { line -> !line.trim().startsWith("#") }
        if (lines.size == 0 && !allowsZeroElements) lines = content.split(NEW_LINE).toList()
        var newRun = self
        val appendCount = maxOf(lines.size, 1) - lengthOverride
        if (lines.size != lengthOverride) newRun = self.append(token, appendCount) as TableStreamRun
        var rowStart = newRun.start
        for (i in 0 until newRun.elementCount) {
            val line = if (lines.size > i) lines[i] else ""
            val tokens = tokenize(line)
            var segmentOffset = 0
            val elementContent = this.elementContent.filter { c -> c.length != 0 }
            for (j in 0 until elementContent.size) {
                val data = Ref(if (j < tokens.size) tokens[j] else "")
                if (j == elementContent.size - 1 && tokens.size > elementContent.size) data.value += " " + " ".join(tokens.drop(j + 1))
                if (elementContent[j].write(elementContent, model, token, rowStart + segmentOffset, data)) {
                    // don't allow deserialization to write a value that looks like an end code
                    val storedValue = model.readMultiByteValue(rowStart, elementContent[j].length)
                    val endCode = endStream
                    if (endCode is EndCodeStreamStrategy &&
                        j == 0 &&
                        elementContent[j].length == endCode.extraLength &&
                        storedValue == endCode.endCode.readMultiByteValue(0, endCode.extraLength)
                    ) {
                        model.writeMultiByteValue(rowStart + segmentOffset, elementContent[j].length, token, storedValue + 1)
                    }
                    changedAddresses.add(rowStart + segmentOffset)
                }
                if (data.value.length > 0) tokens.add(j + 1, data.value)
                segmentOffset += elementContent[j].length
            }
            rowStart += elementLength
        }
        val endCode1 = endStream
        if (endCode1 is EndCodeStreamStrategy && token !is NoDataChangeDeltaModel) token.changeData(model, rowStart, endCode1.endCode)
        changedOffsets.value = changedAddresses
        movedChildren.value = ArrayList<Int>()
        return newRun
    }
    fun createDefault(): ByteList { /*@DONE TableStreamRun.CreateDefault/1 cs:248-251*/
        val endcode = endStream
        if (endcode is EndCodeStreamStrategy) return endcode.endCode
        return ByteArray(0).asByteList()
    }
    private fun serializeSingleElementStream(): String { /*@DONE TableStreamRun.SerializeSingleElementStream/1 cs:253-283*/
        val result = StringBuilder()
        var offset = start
        val longestLabel = elementContent.maxOf { seg -> seg.name.length }
        for (i in 0 until elementContent.size) {
            val segment = elementContent[i]
            val rawValue = model.readMultiByteValue(offset, segment.length)
            var value = rawValue.toString()
            if (segment is ArrayRunEnumSegment) {
                val options = segment.getOptions(model)
                if (rawValue >= 0 && options.size > rawValue) value = options[rawValue]
            } else if (segment is ArrayRunTupleSegment) {
                value = segment.toText(model, offset) ?: ""
            } else if (segment is ArrayRunHexSegment) {
                value = "0x" + rawValue.toHex(segment.length * 2)
            } else if (segment.type == ElementContentType.Pointer) {
                val pointerValue = rawValue - BaseModel.pointerOffset
                value = "<" + pointerValue.toHex(6) + ">"
                if (pointerValue == Pointer.null_) value = "<null>"
            } else if (segment.type == ElementContentType.PCS) {
                value = model.textConverter.convert(model, offset, segment.length) ?: ""
            } else if (segment.length == 0) {
                continue
            }
            result.append(segment.name.padEnd(longestLabel) + " : " + value)
            if (i < elementContent.size - 1) result.append(NEW_LINE)
            offset += segment.length
        }
        return result.toString()
    }
    private fun deserializeSingleElementStream(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, movedChildren: Ref<MutableList<Int>?>): TableStreamRun { /*@DONE TableStreamRun.DeserializeSingleElementStream/1 cs:285-342*/
        val moved = ArrayList<Int>()
        movedChildren.value = moved
        val fields = content.splitLines()
        var segmentOffset = 0
        var fieldIndex = 0
        val changeAddresses = ArrayList<Int>()
        val changedSegments = LinkedHashSet<Int>()
        val unwritten = elementContent.size.range().toMutableList()
        for (j in 0 until elementContent.size) {
            while (fieldIndex < fields.size && fields[fieldIndex].isBlank()) fieldIndex += 1
            if (fieldIndex >= fields.size) break
            val data = Ref(if (j < fields.size) fields[fieldIndex].split(':', limit = 2).last().trim() else "")
            if (elementContent[j].write(this.elementContent, model, token, start + segmentOffset, data)) {
                changeAddresses.add(start + segmentOffset)
                changedSegments.add(j)
            }
            segmentOffset += elementContent[j].length
            fieldIndex += 1
            unwritten.remove(j)
        }
        segmentOffset = 0
        for (j in 0 until elementContent.size) {
            // write default value
            val seg = elementContent[j]
            if (unwritten.contains(j)) {
                if (seg.type == ElementContentType.Pointer) model.writeMultiByteValue(start + segmentOffset, 4, token, 0)
                if (seg.type == ElementContentType.Integer) model.writeMultiByteValue(start + segmentOffset, seg.length, token, 0)
                changeAddresses.add(start + segmentOffset)
                changedSegments.add(j)
            }
            segmentOffset += seg.length
        }

        // check for any pointers that care about values being changed
        segmentOffset = 0
        for (j in 0 until elementContent.size) {
            val seg = elementContent[j]
            if (seg is ArrayRunPointerSegment && !unwritten.contains(j)) {
                val subStart = model.readPointer(start + segmentOffset)
                val subRun = model.getNextRun(subStart)
                if (subRun is IUpdateFromParentRun) {
                    var newChild: IUpdateFromParentRun? = subRun
                    for (i in changedSegments) {
                        newChild = newChild?.updateFromParent(token, i, start + segmentOffset)
                    }
                    if (newChild !== subRun && newChild != null) {
                        model.observeRunWritten(token, newChild)
                        moved.add(newChild.start)
                    }
                }
            }
            segmentOffset += seg.length
        }

        changedOffsets.value = changeAddresses
        return this
    }
    override fun dependsOn(anchorName: String): Boolean { /*@DONE TableStreamRun.DependsOn/1 cs:373-375*/
        return (this as ITableRun).dependsOn(anchorName)
    }
    override fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem>? { /*@DONE TableStreamRun.GetAutoCompleteOptions/1 cs:377-416*/
        val es = endStream
        if (es is FixedLengthStreamStrategy && es.count == 1) {
            return getAutoCompleteOptionsForSingleElementStream(line, caretCharacterIndex)
        }

        val results = ArrayList<AutocompleteItem>()
        if (line.trim().length == 0) return results
        val lineStart = line.substring(0, caretCharacterIndex)
        val lineEnd = line.substring(caretCharacterIndex)
        val tokens = tokenize(lineStart)
        val content = elementContent.filter { seg -> seg !is ArrayRunCommentSegment }
        if (content.size < tokens.size) return results
        val targetSegment = content[maxOf(0, tokens.size - 1)]
        var currentToken = if (tokens.size == 0) "" else tokens[tokens.size - 1]
        if (targetSegment is ArrayRunEnumSegment) {
            if (currentToken.startsWith("\"")) currentToken = currentToken.substring(1)
            if (currentToken.endsWith("\"")) currentToken = currentToken.substring(0, currentToken.length - 1)
            val optionText = targetSegment.getBestOptions(model, currentToken)
            results.addAll(createEnumAutocompleteOptions(tokens, optionText, lineEnd))
        } else if (targetSegment is ArrayRunTupleSegment) {
            val tupleTokens = currentToken.split(" ").toMutableList()
            if (tupleTokens[0].startsWith("(")) tupleTokens[0] = tupleTokens[0].substring(1)
            recombine(tupleTokens, "\"", "\"")
            val visibleTupleElements = targetSegment.elements.filter { element -> !element.name.isNullOrEmpty() }
            var optionToken = tupleTokens.last()
            if (visibleTupleElements.size >= tupleTokens.size) {
                val tupleToken = visibleTupleElements[tupleTokens.size - 1]
                if (optionToken.startsWith("\"")) optionToken = optionToken.substring(1)
                if (optionToken.endsWith("\"")) optionToken = optionToken.substring(0, optionToken.length - 1)
                val partialToken = optionToken
                if (!tupleToken.sourceName.isNullOrEmpty()) {
                    val optionText = ArrayRunEnumSegment.getBestOptions(ArrayRunEnumSegment.getOptions(model, tupleToken.sourceName), partialToken)
                    results.addAll(createTupleEnumAutocompleteOptions(tokens, targetSegment, tupleTokens, optionText, lineEnd))
                } else if (tupleToken.bitWidth == 1) {
                    val options = listOf("false", "true").filter { option -> option.matchesPartial(partialToken) }
                    results.addAll(createTupleEnumAutocompleteOptions(tokens, targetSegment, tupleTokens, options, lineEnd))
                }
            }
        }
        return results
    }
    private fun getAutoCompleteOptionsForSingleElementStream(line: String, caretIndex: Int): List<AutocompleteItem>? { /*@DONE TableStreamRun.GetAutoCompleteOptionsForSingleElementStream/1 cs:418-453*/
        val results = ArrayList<AutocompleteItem>()

        val lineStart = line.substring(0, caretIndex)
        val lineEnd = line.substring(caretIndex)
        if (lineStart.count { c -> c == ':' } != 1) return results
        val fieldName = lineStart.split(':')[0].trim()
        val currentContent = lineStart.split(':')[1].trim()
        val field = elementContent.firstOrNull { segment -> segment.name == fieldName } ?: return null
        if (field is ArrayRunEnumSegment) {
            val optionText = field.getOptions(model).filter { option -> option.matchesPartial(currentContent) }
            results.addAll(createSingleElementEnumAutocompleteOptions(lineEnd, fieldName, optionText))
        } else if (field is ArrayRunTupleSegment) {
            var tupleTokens = currentContent.split(" ").toMutableList()
            recombine(tupleTokens, "\"", "\"")
            if (tupleTokens[0].startsWith("(")) tupleTokens[0] = tupleTokens[0].substring(1)
            val visibleTupleElements = field.elements.filter { element -> !element.name.isNullOrEmpty() }
            if (visibleTupleElements.size >= tupleTokens.size) {
                val tupleToken = visibleTupleElements[tupleTokens.size - 1]
                var optionToken = tupleTokens.last()
                if (optionToken.startsWith("\"")) optionToken = optionToken.substring(1)
                if (optionToken.endsWith("\"")) optionToken = optionToken.substring(0, optionToken.length - 1)
                val partialToken = optionToken
                tupleTokens = tupleTokens.take(tupleTokens.size - 1).toMutableList()
                if (!tupleToken.sourceName.isNullOrEmpty()) {
                    val optionText = ArrayRunEnumSegment.getOptions(model, tupleToken.sourceName).filter { option -> option.matchesPartial(partialToken) }
                    results.addAll(createTupleEnumSingleElementAutocompleteOptions(fieldName, field, tupleTokens, optionText, lineEnd))
                } else if (tupleToken.bitWidth == 1) {
                    val optionText = listOf("false", "true").filter { option -> option.matchesPartial(partialToken) }
                    results.addAll(createTupleEnumSingleElementAutocompleteOptions(fieldName, field, tupleTokens, optionText, lineEnd))
                }
            }
        }

        return results
    }
    private fun createEnumAutocompleteOptions(tokens: List<String>, optionText: Iterable<String>, lineEnd: String): Iterable<AutocompleteItem> { /*@DONE TableStreamRun.CreateEnumAutocompleteOptions/1 cs:455-464*/
        val result = ArrayList<AutocompleteItem>()
        for (option in optionText) {
            var newLine = ", ".join(tokens.take((tokens.size - 1).coerceAtLeast(0)))
            if (newLine.length > 0) newLine += ", "
            newLine += option
            newLine += lineEnd
            if (tokenize(newLine).size < elementContent.count { seg -> seg !is ArrayRunCommentSegment }) newLine += ", "
            result.add(AutocompleteItem(option, newLine))
        }
        return result
    }
    private fun createTupleEnumAutocompleteOptions(tokens: List<String>, tupleGroup: ArrayRunTupleSegment, tupleTokens: MutableList<String>, optionText: Iterable<String>, lineEnd: String): Iterable<AutocompleteItem> { /*@DONE TableStreamRun.CreateTupleEnumAutocompleteOptions/1 cs:466-477*/
        val result = ArrayList<AutocompleteItem>()
        for (option in optionText) {
            var newLine = ", ".join(tokens.take((tokens.size - 1).coerceAtLeast(0)))
            val previousTokens = tupleTokens.take((tupleTokens.size - 1).coerceAtLeast(0))
            newLine += tupleGroup.constructAutocompleteLine(previousTokens, option)
            var thisLineEnd = lineEnd.trim()
            if (thisLineEnd.startsWith(")")) thisLineEnd = thisLineEnd.substring(1)
            newLine += thisLineEnd
            if (tokenize(newLine).size < elementContent.size) newLine += ", "
            result.add(AutocompleteItem(option, newLine))
        }
        return result
    }
    override val visualizations: List<IPixelViewModel>
        get() { /*@DONE TableStreamRun.Visualizations.get cs:495-495*/
            return ArrayList<IPixelViewModel>()
        }
    final override var preFormatter: ITextPreProcessor? = null
        private set
    final override var elementCount: Int = 0
        private set
    final override var elementLength: Int = 0
        private set
    override val elementNames: List<String>? = /*@INITAUTO TableStreamRun.ElementNames cs:506-506*/ ArrayList() /*@ENDINIT*/
    final override var elementContent: List<ArrayRunElementSegment> = ArrayList()
        private set
    final override var length: Int = 0
        private set
    final override var formatString: String = ""
        private set
    override fun append(token: ModelDelta, length: Int): ITableRun { /*@DONE TableStreamRun.Append/1 cs:514-516*/
        return endStream.append(this, token, length)
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE TableStreamRun.AppendTo/1 cs:518-521*/
        ITableRunExtensions.appendTo(this, model, builder, start, length, depth)
        if (start + length >= this.start + this.length && endStream is EndCodeStreamStrategy) builder.append(NEW_LINE + "[]")
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE TableStreamRun.Clear/1 cs:523-525*/
        ITableRunExtensions.clear(this, model, changeToken, start, length)
    }
    fun search(baseName: String, index: Int): Iterable<TableStreamRunSearchTuple> { /*@DONE TableStreamRun.Search/1 cs:527-529*/
        return (this as ITableRun).search(model, baseName, index).map { t -> TableStreamRunSearchTuple(t.item1, t.item2) }
    }
    override fun duplicate(start: Int, pointerSources: SortedSpan<Int>?, segments: List<ArrayRunElementSegment>): ITableRun { /*@DONE TableStreamRun.Duplicate/1 cs:531-538*/
        val closeSegments = formatString.lastIndexOf(']')
        val endToken = formatString.substring(closeSegments + 1)

        var format = segments.map { segment -> segment.serializeFormat }.reduce { a, b -> a + " " + b }
        format = "[" + format + "]" + endToken
        return TableStreamRun(model, start, pointerSources, format, segments, endStream)
    }
    // skipped method UpdateFromParent: explicit implementation merged with the public member
    override fun updateFromParent(token: ModelDelta, parentSegmentChange: Int, pointerSource: Int): TableStreamRun? { /*@DONE TableStreamRun.UpdateFromParent/2 cs:543-546*/
        val strategy = endStream as? LengthFromParentStreamStrategy ?: return this
        return strategy.updateFromParentStream(this, token, parentSegmentChange)
    }
    companion object {
        fun tryParseTableStream(model: IDataModel, start: Int, sources: SortedSpan<Int>?, fieldName: String, content: String, sourceSegments: List<ArrayRunElementSegment>?, tableStream: Ref<TableStreamRun?>): Boolean { /*@DONE TableStreamRun.TryParseTableStream/1 cs:22-24*/
            return tryParseTableStream(model, start, sources, fieldName, content, sourceSegments, true, tableStream)
        }
        fun tryParseTableStream(model: IDataModel, start: Int, sources: SortedSpan<Int>?, fieldName: String, content: String, sourceSegments: List<ArrayRunElementSegment>?, validate: Boolean, tableStream: Ref<TableStreamRun?>): Boolean { /*@DONE TableStreamRun.TryParseTableStream/2 cs:25-29*/
            tableStream.value = null
            val segments = Ref<MutableList<ArrayRunElementSegment>?>(null)
            val endStream = Ref<IStreamEndStrategy?>(null)
            if (!tryParseSegmentsAndEndStrategy(model, fieldName, content, sourceSegments, segments, endStream)) return false
            return tryBuildTableStream(model, start, sources, fieldName, content, segments.value!!, endStream.value!!, validate, tableStream)
        }
        fun tryParseSegmentsAndEndStrategy(model: IDataModel, fieldName: String, content: String, sourceSegments: List<ArrayRunElementSegment>?, segments: Ref<MutableList<ArrayRunElementSegment>?>, endStream: Ref<IStreamEndStrategy?>): Boolean { /*@DONE TableStreamRun.TryParseSegmentsAndEndStrategy/1 cs:31-49*/
            segments.value = null
            endStream.value = null

            if (content.length < 4 || content[0] != '[') return false
            val close = content.lastIndexOf(']')
            if (close == -1) return false
            try {
                val segmentContent = content.substring(1, close)
                val parsed = ArrayRun.parseSegments(segmentContent, model)
                segments.value = parsed
                endStream.value = parseEndStream(model, fieldName, content.substring(close + 1), parsed, sourceSegments)
                if (endStream.value == null) return false
                if (parsed.size == 0) return false
            } catch (e: ArrayRunParseException) {
                return false
            }

            return true
        }
        fun tryBuildTableStream(model: IDataModel, start: Int, sources: SortedSpan<Int>?, fieldName: String, content: String, preParsedSegments: List<ArrayRunElementSegment>, endStream: IStreamEndStrategy, validate: Boolean, tableStream: Ref<TableStreamRun?>): Boolean { /*@DONE TableStreamRun.TryBuildTableStream/1 cs:51-66*/
            val built = TableStreamRun(model, start, sources, content, preParsedSegments, endStream)
            tableStream.value = built

            if (start < 0) return false // not a valid data location, so the data can't possibly be valid

            if (model.getUnmappedSourcesToAnchor(fieldName).size > 0) {
                // we're pasting this format and something else is expecting it. Don't expect the content to match yet.
                return built.elementCount > 0 || built.endStream is EndCodeStreamStrategy
            }

            if (!validate) return true

            // if the first 90% matches, we don't need to check the last 10%
            val mostElementsCount = Math.ceil(built.elementCount * .85).toInt()
            return dataMatches(model, built, mostElementsCount)
        }
        fun dataMatches(model: IDataModel, tableStream: TableStreamRun, elementsCount: Int): Boolean { /*@DONE TableStreamRun.DataMatches/1 cs:68-80*/
            for (i in 0 until elementsCount) {
                var subStart = tableStream.start + tableStream.elementLength * i
                for (j in 0 until tableStream.elementContent.size) {
                    // at this point I already know the length of the table
                    // I don't need to do a deep-match, I just need to figure out if the pointers/text/enums are in the right spots.
                    // the data that this points to doesn't have to be valid in order for this to be valid.
                    if (!ArrayRun.dataMatchesSegmentFormat(model, subStart, tableStream.elementContent[j], 0, tableStream.elementContent, i, deepCheck = false)) return false
                    subStart += tableStream.elementContent[j].length
                }
            }
            return tableStream.elementCount > 0 || tableStream.allowsZeroElements
        }
        fun tryWriteNewEndToken(token: ModelDelta, tableStream: Ref<TableStreamRun>): Boolean { /*@DONE TableStreamRun.TryWriteNewEndToken/1 cs:82-87*/
            val current = tableStream.value
            val strategy = current.endStream as? EndCodeStreamStrategy ?: return false
            for (i in 0 until strategy.endCode.count) token.changeData(current.model, current.start + i, strategy.endCode[i])
            tableStream.value = current.clone(current.pointerSources) as TableStreamRun
            return true
        }
        fun parseEndStream(model: IDataModel, fieldName: String, endToken: String, childSegments: List<ArrayRunElementSegment>, parentSegments: List<ArrayRunElementSegment>?): IStreamEndStrategy? { /*@DONE TableStreamRun.ParseEndStream/1 cs:95-111*/
            val number = Ref(0)
            if (tryParseInt(endToken, number)) {
                return FixedLengthStreamStrategy(number.value)
            }
            if (endToken.startsWith("!") && endToken.length % 2 == 1 && endToken.substring(1).all { c -> ViewPort.allHexCharacters.contains(c) }) {
                if (endToken.length == 1) return null // end token must be at least 1 byte long
                return EndCodeStreamStrategy(model, endToken.substring(1).uppercase())
            }
            if (endToken == "?") {
                return DynamicStreamStrategy(model, childSegments)
            }
            val tokens = endToken.split("/")
            if (tokens.size == 2) {
                return LengthFromParentStreamStrategy(model, tokens, fieldName, parentSegments)
            }
            return null
        }
        fun tokenize(line: String): MutableList<String> { /*@DONE TableStreamRun.Tokenize/1 cs:344-362*/
            // split at each space
            val tokens = line.split(" ").filter { s -> s.length > 0 }.toMutableList()

            // remove trailing ',' from tokens
            for (i in 0 until tokens.size) {
                if (!tokens[i].endsWith(",")) continue
                tokens[i] = tokens[i].substring(0, tokens[i].length - 1)
            }

            recombine(tokens, "\"", "\"")
            recombine(tokens, "(", ")")

            // remove comments
            val comment = ViewPort.commentStart.toString()
            return tokens.filter { token -> !token.startsWith(comment) }.toMutableList()
        }
        fun recombine(tokens: MutableList<String>, startToken: String, endToken: String) { /*@DONE TableStreamRun.Recombine/1 cs:364-371*/
            var i = 0
            while (i < tokens.size - 1) {
                if (tokens[i].startsWith(startToken) == tokens[i].endsWith(endToken)) {
                    i++
                    continue
                }
                tokens[i] = tokens[i] + " " + tokens[i + 1]
                tokens.removeAt(i + 1)
            }
        }
        private fun createSingleElementEnumAutocompleteOptions(lineEnd: String, fieldName: String, optionText: Iterable<String>): Iterable<AutocompleteItem> { /*@DONE TableStreamRun.CreateSingleElementEnumAutocompleteOptions/1 cs:479-484*/
            val result = ArrayList<AutocompleteItem>()
            for (option in optionText) {
                val newLine = fieldName + ": " + option + lineEnd
                result.add(AutocompleteItem(option, newLine))
            }
            return result
        }
        private fun createTupleEnumSingleElementAutocompleteOptions(fieldName: String, tupleSegment: ArrayRunTupleSegment, previousTupleElements: MutableList<String>, optionText: Iterable<String>, lineEnd: String): Iterable<AutocompleteItem> { /*@DONE TableStreamRun.CreateTupleEnumSingleElementAutocompleteOptions/1 cs:486-493*/
            val result = ArrayList<AutocompleteItem>()
            for (option in optionText) {
                var newLine = fieldName + ": "
                newLine += tupleSegment.constructAutocompleteLine(previousTupleElements, option)
                newLine += lineEnd
                result.add(AutocompleteItem(option, newLine))
            }
            return result
        }
        /*@END TableStreamRun.Companion*/
    }
    /*@END TableStreamRun*/
}

interface IStreamEndStrategy { // cs:549-556
    val extraLength: Int
    fun getCount(table: TableStreamRun, start: Int, elementLength: Int, pointerSources: List<Int>?): Int
    fun append(run: TableStreamRun, token: ModelDelta, length: Int): TableStreamRun
    /*@END IStreamEndStrategy*/
}

open class FixedLengthStreamStrategy : IStreamEndStrategy { // cs:558-567
    var count: Int = 0
        private set
    override val extraLength: Int
        get() { /*@DONE FixedLengthStreamStrategy.ExtraLength.get cs:560-560*/
            return 0
        }
    constructor(count: Int) { /*@DONE FixedLengthStreamStrategy.<init>/1 cs:562-562*/
        this.count = count
    }
    override fun getCount(table: TableStreamRun, start: Int, elementLength: Int, pointerSources: List<Int>?): Int { /*@DONE FixedLengthStreamStrategy.GetCount/1 cs:564-564*/
        return count
    }
    override fun append(run: TableStreamRun, token: ModelDelta, length: Int): TableStreamRun { /*@DONE FixedLengthStreamStrategy.Append/1 cs:566-566*/
        return run
    }
    /*@END FixedLengthStreamStrategy*/
}

open class DynamicStreamStrategy : IStreamEndStrategy { // cs:569-620
    private lateinit var model: IDataModel
    private var segments: List<ArrayRunElementSegment>? = null
    constructor(model: IDataModel, segments: List<ArrayRunElementSegment>?) { /*@DONE DynamicStreamStrategy.<init>/1 cs:572-572*/
        this.model = model
        this.segments = segments
    }
    override val extraLength: Int
        get() { /*@DONE DynamicStreamStrategy.ExtraLength.get cs:574-574*/
            return 0
        }
    override fun append(run: TableStreamRun, token: ModelDelta, length: Int): TableStreamRun { /*@DONE DynamicStreamStrategy.Append/1 cs:576-592*/
        val naturalLength = run.length
        val newRun = model.relocateForExpansion(token, run, naturalLength + length * run.elementLength)

        // add new element data
        for (i in 0 until run.elementLength * length) {
            var prevIndex = newRun.start + naturalLength + i - newRun.elementLength * length
            while (prevIndex < newRun.start) prevIndex += newRun.elementLength
            val prevData = if (prevIndex >= newRun.start) model[prevIndex] else 0
            token.changeData(model, newRun.start + naturalLength + i, prevData)
        }

        // remove excess element data
        for (i in naturalLength + length * run.elementLength until naturalLength) token.changeData(model, newRun.start + i, 0xFF)

        return TableStreamRun(model, newRun.start, run.pointerSources, run.formatString, run.elementContent, this, run.elementCount + length)
    }
    override fun getCount(run: TableStreamRun, start: Int, elementLength: Int, pointerSources: List<Int>?): Int { /*@DONE DynamicStreamStrategy.GetCount/1 cs:594-619*/
        val segments = this.segments ?: run.elementContent
        var forceEnd = Int.MAX_VALUE
        var current = start
        var i = 0
        while (true) {
            // verify that there's enough room for another element
            val existingRun = model.getNextRun(current)!!
            if (existingRun.start >= current && existingRun.start < current + elementLength) {
                if (existingRun.pointerSources != null && existingRun !is NoInfoRun && existingRun !is PointerRun) return i // break if it's not a no-info run and has pointers
                if (!model.getAnchorFromAddress(-1, existingRun.start).isNullOrEmpty()) return i // break if it's an anchor
            }

            // if this is just a table of pointers, track the next pointer destination after the table
            if (run.elementContent.size == 1 && run.elementContent[0].type == ElementContentType.Pointer) {
                val destination = model.readPointer(current)
                if (destination >= current) forceEnd = minOf(destination, forceEnd)
            }

            // verify that the data matches the expected format
            if (!segments.dataFormatMatches(model, current, i, deepCheck = false)) return i

            // if we read a pointer while getting the count, verify that we haven't passed it
            if (current >= forceEnd) return i
            current += elementLength
            i++
        }
    }
    /*@END DynamicStreamStrategy*/
}

open class EndCodeStreamStrategy : IStreamEndStrategy { // cs:622-676
    private lateinit var model: IDataModel
    var endCode: ByteList = ByteArray(0).asByteList()
        private set
    override val extraLength: Int
        get() { /*@DONE EndCodeStreamStrategy.ExtraLength.get cs:626-626*/
            return endCode.count
        }
    constructor(model: IDataModel, endToken: String) { /*@DONE EndCodeStreamStrategy.<init>/1 cs:628-637*/
        this.model = model
        val hex = ViewPort.allHexCharacters
        val codes = ArrayList<Int>()
        var remaining = endToken
        while (remaining.length > 0) {
            codes.add((hex.indexOf(remaining[0]) * 16 + hex.indexOf(remaining[1])) and 0xFF)
            remaining = remaining.substring(2)
        }
        this.endCode = codes.toByteArrayU().asByteList()
    }
    override fun getCount(table: TableStreamRun, start: Int, elementLength: Int, pointerSources: List<Int>?): Int { /*@DONE EndCodeStreamStrategy.GetCount/1 cs:639-652*/
        var current = start
        if (current < 0) return 0
        var length = 0
        while (true) {
            var match = true
            var j = 0
            while (j < endCode.count && match) {
                if (model.count <= current + j) return 0
                if (model[current + j] != endCode[j]) match = false
                j++
            }
            if (match) return length
            length++
            current += elementLength
        }
    }
    override fun append(run: TableStreamRun, token: ModelDelta, length: Int): TableStreamRun { /*@DONE EndCodeStreamStrategy.Append/1 cs:654-675*/
        val naturalLength = run.length - endCode.count
        val newRun = model.relocateForExpansion(token, run, naturalLength + length * run.elementLength + endCode.count)

        // add new entries
        if (naturalLength == 0) {
            for (i in 0 until run.elementLength * length) token.changeData(model, newRun.start + naturalLength + i, 0)
        } else {
            for (i in 0 until run.elementLength * length) token.changeData(model, newRun.start + naturalLength + i, model[newRun.start + naturalLength + i - run.elementLength])
        }

        // clear excess old entries
        for (i in naturalLength + length * run.elementLength until naturalLength) if (model[newRun.start + i] != 0xFF) token.changeData(model, newRun.start + i, 0xFF)

        // clear the old end code
        if (length < 0) {
            for (i in 0 until endCode.count) token.changeData(model, newRun.start + naturalLength + i, 0xFF)
        }

        // add the new end code
        for (i in 0 until endCode.count) token.changeData(model, newRun.start + naturalLength + length * run.elementLength + i, endCode[i])

        return TableStreamRun(model, newRun.start, run.pointerSources, run.formatString, run.elementContent, this, run.elementCount + length)
    }
    /*@END EndCodeStreamStrategy*/
}

open class LengthFromParentStreamStrategy : IStreamEndStrategy { // cs:678-836
    private lateinit var model: IDataModel
    private var parentName: String = ""
    private var parentFieldForLength: String = ""
    private var parentFieldForThis: String = ""
    private var sourceSegments: List<ArrayRunElementSegment>? = null
    override val extraLength: Int
        get() { /*@DONE LengthFromParentStreamStrategy.ExtraLength.get cs:683-683*/
            return 0
        }
    constructor(model: IDataModel, tokens: Array<String>, tableFieldName: String, sourceSegments: List<ArrayRunElementSegment>?) { /*@DONE LengthFromParentStreamStrategy.<init>/1 cs:685-691*/
        this.model = model
        parentName = tokens[0]
        parentFieldForLength = tokens[1]
        parentFieldForThis = tableFieldName
        this.sourceSegments = sourceSegments
    }
    override fun getCount(table: TableStreamRun, start: Int, elementLength: Int, pointerSources: List<Int>?): Int { /*@DONE LengthFromParentStreamStrategy.GetCount/1 cs:693-712*/
        val defaultValue = 1
        val parentIndex = if (pointerSources != null) getParentIndex(pointerSources) else -1
        val run = if (parentIndex >= 0) model.getNextRun(parentIndex) as? ITableRun else null
        val segments = run?.elementContent ?: sourceSegments
        val countSegmentIndex = getSegmentIndex(segments, parentFieldForLength)
        if (countSegmentIndex == -1 || segments == null) return defaultValue
        val countSegmentOffset = segments.take(countSegmentIndex).sumOf { segment -> segment.length }
        val pointerSegmentIndex = getSegmentIndex(segments, parentFieldForThis)
        val pointerSegmentOffset = segments.take(pointerSegmentIndex.coerceAtLeast(0)).sumOf { segment -> segment.length }

        for (source in (pointerSources ?: emptyList<Int>()).sorted()) {
            if (source < parentIndex) continue
            val modelValue = model.readMultiByteValue(source - pointerSegmentOffset + countSegmentOffset, segments[countSegmentIndex].length)
            return maxOf(modelValue, defaultValue)
        }

        return defaultValue
    }
    override fun append(run: TableStreamRun, token: ModelDelta, length: Int): TableStreamRun { /*@DONE LengthFromParentStreamStrategy.Append/1 cs:714-748*/
        val runSources: List<Int> = run.pointerSources ?: SortedSpan.none<Int>()
        val parentIndex = getParentIndex(runSources)
        val parent = if (parentIndex >= 0) model.getNextRun(parentIndex) as? ITableRun else null
        val segmentIndex = getSegmentIndex(parent?.elementContent, parentFieldForLength)

        updateParents(token, parent, segmentIndex, run.elementCount + length, runSources)

        val naturalLength = run.length
        val newRun = model.relocateForExpansion(token, run, naturalLength + length * run.elementLength)
        for (i in 0 until run.elementLength * length) {
            var prevIndex = newRun.start + naturalLength + i - newRun.elementLength * length
            while (prevIndex < newRun.start) prevIndex += newRun.elementLength
            val prevData = if (prevIndex >= newRun.start) model[prevIndex] else 0
            token.changeData(model, newRun.start + naturalLength + i, prevData)
        }

        for (i in 0 until -length) {
            var segmentOffset = 0
            for (j in 0 until run.elementContent.size) {
                val segment = run.elementContent[j]
                val source = run.start + run.length - (1 + i) * run.elementLength + segmentOffset
                if (segment.type == ElementContentType.Pointer) {
                    model.clearPointer(token, source, model.readPointer(source))
                }
                if (segment.type == ElementContentType.PCS) {
                    token.changeData(model, source, ByteArray(segment.length) { 0xFF.toByte() }.asByteList())
                } else {
                    model.writeMultiByteValue(source, segment.length, token, -1)
                }
                segmentOffset += segment.length
            }
        }

        return TableStreamRun(model, newRun.start, run.pointerSources, run.formatString, run.elementContent, this, (newRun.elementCount + length).limitToRange(1, Int.MAX_VALUE))
    }
    fun updateFromParentStream(run: TableStreamRun, token: ModelDelta, parentSegmentIndex: Int): TableStreamRun? { /*@DONE LengthFromParentStreamStrategy.UpdateFromParentStream/1 cs:750-788*/
        val runSources: List<Int> = run.pointerSources ?: SortedSpan.none<Int>()
        val parentAddress = getParentIndex(runSources)
        val parent = model.getNextRun(parentAddress) as? ITableRun ?: return run
        val segmentIndex = getSegmentIndex(parent.elementContent, parentFieldForLength)
        if (segmentIndex == -1 || segmentIndex != parentSegmentIndex) return run
        val segmentOffset = parent.elementContent.take(segmentIndex).sumOf { segment -> segment.length }
        val offsets = parent.convertByteOffsetToArrayOffset(parentAddress)

        var newElementCount = model.readMultiByteValue(parent.start + offsets.elementIndex * parent.elementLength + segmentOffset, parent.elementContent[segmentIndex].length)
        newElementCount = newElementCount.limitToRange(0, 1000)

        var newRun: TableStreamRun? = run
        if (newElementCount == 0) {
            model.clearFormatAndData(token, run.start, run.length)
            model.updateArrayPointer(token, parent.elementContent[offsets.segmentIndex], parent.elementContent, offsets.elementIndex, parentAddress, Pointer.null_)
            newRun = null
        } else if (newElementCount != run.elementCount) {
            val endOfCurrentRun = run.start + run.length
            val nextRunMinimumStart = run.start + run.elementLength * newElementCount
            if (
                TableStreamRun.dataMatches(model, run, newElementCount) &&
                model.getNextRun(nextRunMinimumStart)!!.start >= nextRunMinimumStart &&
                run.elementCount <= 1
            ) {
                // no need to repoint: the next data matches
                // this is important for when we're pasting pointers to existing formats before pasting those formats' lengths.
                // example: paste ^newanchor <pointer> count, where pointer points to existing data. We don't want writing the 'count' to cause a repoint
                model.clearFormat(token, endOfCurrentRun, nextRunMinimumStart - endOfCurrentRun)
                updateParents(token, parent, segmentIndex, newElementCount, runSources)
                newRun = TableStreamRun(model, run.start, run.pointerSources, run.formatString, run.elementContent, this)
            } else {
                val appended = run.append(token, newElementCount - run.elementCount) as TableStreamRun
                updateParents(token, parent, segmentIndex, newElementCount, appended.pointerSources ?: SortedSpan.none<Int>())
                newRun = appended
            }
        }

        return newRun
    }
    private fun getParentIndex(pointerSources: List<Int>): Int { /*@DONE LengthFromParentStreamStrategy.GetParentIndex/1 cs:790-808*/
        if (parentName == "") {
            val matches = pointerSources.filter { source -> sourceIsFromParentTable(source) }
            if (matches.size == 0) return -1
            // we know where we expect the beginning of the element to be if this is a valid pointer in a recognized table
            for (match in matches) {
                val run = model.getNextRun(match)
                if (run is ITableRun) {
                    val segments = run.elementContent
                    val pointerSegmentIndex = getSegmentIndex(segments, parentFieldForThis)
                    val pointerSegmentOffset = segments.take(pointerSegmentIndex.coerceAtLeast(0)).sumOf { segment -> segment.length }
                    val offset = run.convertByteOffsetToArrayOffset(match - pointerSegmentOffset)
                    if (offset.segmentIndex == 0 && offset.segmentOffset == 0) return match
                }
            }
            return matches[0]
        } else {
            return model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, parentName)
        }
    }
    private fun getSegmentIndex(sourceSegments: List<ArrayRunElementSegment>?, segmentName: String): Int { /*@DONE LengthFromParentStreamStrategy.GetSegmentIndex/1 cs:810-816*/
        if (sourceSegments == null) return -1
        for (i in 0 until sourceSegments.size) {
            if (sourceSegments[i].name == segmentName) return i
        }
        return -1
    }
    private fun sourceIsFromParentTable(source: Int): Boolean { /*@DONE LengthFromParentStreamStrategy.SourceIsFromParentTable/1 cs:818-821*/
        val run = model.getNextRun(source)
        if (run !is ITableRun) return false
        return run.elementContent.any { segment -> segment.name == parentFieldForLength }
    }
    private fun updateParents(token: ModelDelta, parent: ITableRun?, segmentIndex: Int, newValue: Int, pointerSources: List<Int>) { /*@DONE LengthFromParentStreamStrategy.UpdateParents/1 cs:823-835*/
        if (parent == null || segmentIndex == -1) return
        val segmentOffset = parent.elementContent.take(segmentIndex).sumOf { segment -> segment.length }
        val segmentLength = parent.elementContent[segmentIndex].length
        for (source in pointerSources) {
            val offsets = parent.convertByteOffsetToArrayOffset(source)
            if (offsets.elementIndex < 0 || offsets.elementIndex > parent.elementCount) continue
            val lengthAddress = parent.start + offsets.elementIndex * parent.elementLength + segmentOffset
            if (model.readMultiByteValue(lengthAddress, segmentLength) != newValue) {
                model.writeMultiByteValue(lengthAddress, segmentLength, token, newValue)
            }
        }
    }
    /*@END LengthFromParentStreamStrategy*/
}

data class TableStreamRunSearchTuple(val item1: Int, val item2: Int)
