// Port of ViewModels/Tools/ToolTray.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.system.ICommandExtensions.canAlwaysExecute
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class EmptyTool : IToolViewModel { // cs:12-17
    override val name: String
        get() { /*@DONE EmptyTool.Name.get cs:14-14*/
            return "None"
        }
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    override fun dataForCurrentRunChanged() { /*@DONE EmptyTool.DataForCurrentRunChanged/1 cs:16-16*/
        // the empty tool has no data
    }
    companion object {
        var instance: EmptyTool = /*@INITDONE EmptyTool.Instance cs:13-13*/ EmptyTool() /*@ENDINIT*/
            private set
        /*@END EmptyTool.Companion*/
    }
    /*@END EmptyTool*/
}

open class EmptyToolTray : IToolTrayViewModel { // cs:19-60
    override operator fun get(index: Int): IToolViewModel { /*@DONE EmptyToolTray.this/1.get cs:20-20*/
        return EmptyTool.instance
    }
    override var selectedIndex: Int
        get() { /*@DONE EmptyToolTray.SelectedIndex.get cs:22-22*/
            return -1
        }
        set(value) { /*@DONE EmptyToolTray.SelectedIndex.set cs:22-22*/
            // there is nothing to select
        }
    override var selectedTool: IToolViewModel?
        get() { /*@DONE EmptyToolTray.SelectedTool.get cs:23-23*/
            return EmptyTool.instance
        }
        set(value) { /*@DONE EmptyToolTray.SelectedTool.set cs:23-23*/
            throw NotImplementedError()
        }
    override val hideCommand: ICommand
        get() { /*@DONE EmptyToolTray.HideCommand.get cs:25-25*/
            return StubCommand()
        }
    override val stringToolCommand: ICommand
        get() { /*@DONE EmptyToolTray.StringToolCommand.get cs:27-27*/
            return StubCommand()
        }
    override val tableToolCommand: ICommand
        get() { /*@DONE EmptyToolTray.TableToolCommand.get cs:29-29*/
            return StubCommand()
        }
    override val codeToolCommand: ICommand
        get() { /*@DONE EmptyToolTray.CodeToolCommand.get cs:31-31*/
            return StubCommand()
        }
    override val spriteToolCommand: ICommand
        get() { /*@DONE EmptyToolTray.SpriteToolCommand.get cs:33-33*/
            return StubCommand()
        }
    override val stringTool: PCSTool?
        get() { /*@DONE EmptyToolTray.StringTool.get cs:35-35*/
            return null
        }
    override val tableTool: TableTool?
        get() { /*@DONE EmptyToolTray.TableTool.get cs:37-37*/
            return null
        }
    override val codeTool: CodeTool?
        get() { /*@DONE EmptyToolTray.CodeTool.get cs:39-39*/
            return null
        }
    override val spriteTool: SpriteTool?
        get() { /*@DONE EmptyToolTray.SpriteTool.get cs:41-41*/
            return null
        }
    override val logTool: LogTool?
        get() { /*@DONE EmptyToolTray.LogTool.get cs:43-43*/
            return null
        }
    override val deferUpdates: IDisposable
        get() { /*@DONE EmptyToolTray.DeferUpdates.get cs:45-45*/
            return StubDisposable()
        }
    override val size: Int
        get() { /*@DONE EmptyToolTray.Count.get cs:47-47*/
            return 0
        }
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    override fun refreshContent() { /*@DONE EmptyToolTray.RefreshContent/1 cs:55-55*/
        // there is no content to refresh
    }
    override fun schedule(action: () -> Unit) { /*@DONE EmptyToolTray.Schedule/1 cs:57-57*/
        action()
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@END EmptyToolTray*/
}

open class ToolTray : ViewModelCore, IToolTrayViewModel { // cs:62-199
    private var tools: MutableList<IToolViewModel> = ArrayList()
    private lateinit var _hideCommand: StubCommand
    private lateinit var _stringToolCommand: StubCommand
    private lateinit var _tableToolCommand: StubCommand
    private lateinit var _codeToolCommand: StubCommand
    private lateinit var _spriteToolCommand: StubCommand
    private lateinit var _logToolCommand: StubCommand
    private val deferredWork: MutableSet<() -> Unit> = /*@INITAUTO ToolTray.deferredWork cs:66-66*/ LinkedHashSet() /*@ENDINIT*/
    private lateinit var model: IDataModel
    private lateinit var selection: Selection
    private var _selectedIndex: Int = 0
    override var selectedIndex: Int
        get() { /*@DONE ToolTray.SelectedIndex.get cs:71-71*/
            return _selectedIndex
        }
        set(value) { /*@DONE ToolTray.SelectedIndex.set cs:72-84*/
            if (tryUpdate(_selectedIndex, value, "selectedIndex") { _selectedIndex = it }) {
                _hideCommand.canExecuteChanged(_hideCommand, EventArgs.empty)
                requestMenuClose(this, EventArgs.empty)
                ModelCacheScope.createScope(model).using {
                    if (selectedTool === tableTool) tableTool.dataForCurrentRunChanged()
                    if (selectedTool === spriteTool) spriteTool.dataForCurrentRunChanged()
                    if (selectedTool === stringTool) stringTool.dataForCurrentRunChanged()
                    if (selectedTool === logTool) logTool.dataForCurrentRunChanged()
                    codeTool.isSelected = selectedTool === codeTool
                }
            }
        }
    override var selectedTool: IToolViewModel?
        get() { /*@DONE ToolTray.SelectedTool.get cs:88-88*/
            return if (_selectedIndex == -1) null else tools[_selectedIndex]
        }
        set(value) { /*@DONE ToolTray.SelectedTool.set cs:89-89*/
            selectedIndex = if (value == null) -1 else tools.indexOf(value)
        }
    override val size: Int
        get() { /*@DONE ToolTray.Count.get cs:92-92*/
            return tools.size
        }
    override operator fun get(index: Int): IToolViewModel { /*@DONE ToolTray.this/1.get cs:93-93*/
        return tools[index]
    }
    override val hideCommand: ICommand
        get() { /*@DONE ToolTray.HideCommand.get cs:95-95*/
            return _hideCommand
        }
    override val stringToolCommand: ICommand
        get() { /*@DONE ToolTray.StringToolCommand.get cs:96-96*/
            return _stringToolCommand
        }
    override val tableToolCommand: ICommand
        get() { /*@DONE ToolTray.TableToolCommand.get cs:97-97*/
            return _tableToolCommand
        }
    override val codeToolCommand: ICommand
        get() { /*@DONE ToolTray.CodeToolCommand.get cs:98-98*/
            return _codeToolCommand
        }
    override val spriteToolCommand: ICommand
        get() { /*@DONE ToolTray.SpriteToolCommand.get cs:99-99*/
            return _spriteToolCommand
        }
    val logToolCommand: ICommand
        get() { /*@DONE ToolTray.LogToolCommand.get cs:100-100*/
            return _logToolCommand
        }
    override val stringTool: PCSTool
        get() { /*@DONE ToolTray.StringTool.get cs:102-102*/
            return tools[1] as PCSTool
        }
    override val tableTool: TableTool
        get() { /*@DONE ToolTray.TableTool.get cs:104-104*/
            return tools[0] as TableTool
        }
    override val codeTool: CodeTool
        get() { /*@DONE ToolTray.CodeTool.get cs:106-106*/
            return tools[3] as CodeTool
        }
    override val spriteTool: SpriteTool
        get() { /*@DONE ToolTray.SpriteTool.get cs:108-108*/
            return tools[2] as SpriteTool
        }
    override val logTool: LogTool
        get() { /*@DONE ToolTray.LogTool.get cs:110-110*/
            return tools[4] as LogTool
        }
    private var runningDeferredWork: Boolean = false
    private var currentDeferralToken: StubDisposable? = null
    override val deferUpdates: IDisposable
        get() { /*@DONE ToolTray.DeferUpdates.get cs:115-131*/
            // Debug.Assert(currentDeferralToken == null)
            val token = StubDisposable()
            token.dispose = {
                val workingCopy = deferredWork.toList()
                runningDeferredWork = true
                currentDeferralToken = null
                StubDisposable { runningDeferredWork = false }.using {
                    for (action in workingCopy) {
                        action()
                        deferredWork.remove(action)
                    }
                }
            }
            currentDeferralToken = token
            return token
        }
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    val requestMenuClose = Event<EventArgs>()
    constructor(singletons: Singletons, model: IDataModel, selection: Selection, history: ChangeHistory<ModelDelta>, viewPort: ViewPort) { /*@DONE ToolTray.<init>/1 cs:138-176*/
        this.model = model
        this.selection = selection
        tools = arrayListOf<IToolViewModel>(
            TableTool(model, selection, history, viewPort, this, singletons.workDispatcher!!),
            PCSTool(viewPort, history, this),
            SpriteTool(viewPort, history),
            CodeTool(singletons, viewPort, selection, history, viewPort),
            LogTool())

        fun commandFor(i: Int): StubCommand {
            val command = StubCommand()
            command.canExecute = { p -> canAlwaysExecute(p) }
            command.execute = { _ ->
                ModelCacheScope.createScope(model).using {
                    selectedIndex = if (_selectedIndex == i) -1 else i
                    tools[i].dataForCurrentRunChanged()
                }
            }
            return command
        }

        _tableToolCommand = commandFor(0)
        _stringToolCommand = commandFor(1)
        _spriteToolCommand = commandFor(2)
        _codeToolCommand = commandFor(3)
        _logToolCommand = commandFor(4)

        val hide = StubCommand()
        hide.canExecute = { _ -> selectedIndex != -1 }
        hide.execute = { _ -> selectedIndex = -1 }
        _hideCommand = hide

        selectedIndex = 0 // table tool is open by default

        stringTool.onError += { _, e -> onError(this, e) }
        tableTool.onError += { _, e -> onError(this, e) }
        tableTool.onMessage += { _, e -> onMessage(this, e) }
        tableTool.requestMenuClose += { _, e -> requestMenuClose(this, e) }
    }
    override fun schedule(action: () -> Unit) { /*@DONE ToolTray.Schedule/1 cs:178-185*/
        if (currentDeferralToken != null) {
            // Debug.Assert(!runningDeferredWork, "Scheduling deferred work while deferred work is running is not safe!")
            deferredWork.add(action)
        } else {
            action()
        }
    }
    override fun refreshContent() { /*@DONE ToolTray.RefreshContent/1 cs:187-194*/
        selection.scroll.dataLength = model.count
        stringTool.dataForCurrentRunChanged()
        tableTool.dataForCurrentRunChanged()
        spriteTool.dataForCurrentRunChanged()
        codeTool.dataForCurrentRunChanged()
        logTool.dataForCurrentRunChanged()
    }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@END ToolTray*/
}
