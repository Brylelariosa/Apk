// Port of ViewModels/QuickEditItems/UpdateDexConversionTable.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class UpdateDexConversionTable : IQuickEditItem { // cs:7-71
    override val name: String?
        get() { /*@DONE UpdateDexConversionTable.Name.get cs:8-8*/
            return "Update Dex Conversion Table"
        }
    override val description: String?
        get() { /*@DONE UpdateDexConversionTable.Description.get cs:10-12*/
            return "The games contain a table that converts regional dex entries to national dex entries." + NEW_LINE +
                EditorViewModel.applicationName + " can update this automatically." + NEW_LINE +
                "If you're using FireRed or LeafGreen, this probably doesn't matter for you."
        }
    override val wikiLink: String?
        get() { /*@DONE UpdateDexConversionTable.WikiLink.get cs:14-14*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Pokedex-Conversion-Explained"
        }
    override val canRunChanged = Event<EventArgs>()
    override fun canRun(viewPortInterface: IViewPort): Boolean { /*@DONE UpdateDexConversionTable.CanRun/1 cs:18-40*/
        val noChange = NoDataChangeDeltaModel()
        val viewPort = viewPortInterface as? ViewPort
        if (viewPort == null) return false
        val model = viewPort.model
        fun get(name: String): ArrayRun? = model.getNextRun(model.getAddressFromAnchor(noChange, -1, name)) as? ArrayRun
        val regional = get(HardcodeTablesModel.regionalDexTableName)
        val national = get(HardcodeTablesModel.nationalDexTableName)
        val convert = get(HardcodeTablesModel.conversionDexTableName)
        if (regional == null || national == null || convert == null) return false
        if (regional.elementContent.size != 1 || national.elementContent.size != 1 || convert.elementContent.size != 1) return false
        if (regional.elementCount != national.elementCount || regional.elementCount != convert.elementCount) return false
        if (regional.elementLength != 2 || national.elementLength != 2 || convert.elementLength != 2) return false

        for (i in 0 until regional.elementCount) {
            val regionalIndex = model.readMultiByteValue(regional.start + i * 2, 2)
            val nationalIndex = model.readMultiByteValue(national.start + i * 2, 2)
            val conversionAddress = convert.start + (regionalIndex - 1) * 2
            if (regionalIndex < 1 || conversionAddress + 2 > model.count) continue
            val conversionIndex = model.readMultiByteValue(conversionAddress, 2)
            if (nationalIndex != conversionIndex) return true
        }

        return false
    }
    override fun run(viewPortInterface: IViewPort): Task<ErrorInfo>? { /*@DONE UpdateDexConversionTable.Run/1 cs:42-51*/
        val viewPort = viewPortInterface as ViewPort
        val model = viewPort.model
        val token = viewPort.currentChange

        UpdateDexConversionTable.run(model, token)

        return Task.fromResult(ErrorInfo.noError)
    }
    override fun tabChanged() { /*@DONE UpdateDexConversionTable.TabChanged/1 cs:70-70*/
        canRunChanged(this, EventArgs.empty)
    }
    companion object {
        fun run(model: IDataModel, token: ModelDelta) { /*@DONE UpdateDexConversionTable.Run/2 cs:53-68*/
            fun get(name: String): ArrayRun? = model.getNextRun(model.getAddressFromAnchor(token, -1, name)) as? ArrayRun
            val regional = get(HardcodeTablesModel.regionalDexTableName)
            val national = get(HardcodeTablesModel.nationalDexTableName)
            val convert = get(HardcodeTablesModel.conversionDexTableName)
            if (convert == null || regional == null || national == null) return

            for (i in 0 until regional.elementCount) {
                val regionalIndex = model.readMultiByteValue(regional.start + i * 2, 2)
                val nationalIndex = model.readMultiByteValue(national.start + i * 2, 2)
                val conversionAddress = convert.start + (regionalIndex - 1) * 2
                if (regionalIndex < 1 || conversionAddress + 2 > model.count) continue
                val conversionIndex = model.readMultiByteValue(conversionAddress, 2)
                if (nationalIndex != conversionIndex) {
                    model.writeMultiByteValue(conversionAddress, 2, token, nationalIndex)
                }
            }
        }
        /*@END UpdateDexConversionTable.Companion*/
    }
    /*@END UpdateDexConversionTable*/
}
