// Port of ViewModels/QuickEditItems/ReorderDex.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class ReorderDex : IQuickEditItem { // cs:7-43
    private var displayName: String = ""
    private var dexTableName: String = ""
    override val name: String?
        get() { /*@DONE ReorderDex.Name.get cs:10-10*/
            return "Reorder " + displayName + " Dex"
        }
    override val description: String?
        get() { /*@DONE ReorderDex.Description.get cs:12-12*/
            return "Open a special UI for interactively reordering the " + displayName + " pokedex."
        }
    override val wikiLink: String?
        get() { /*@DONE ReorderDex.WikiLink.get cs:14-14*/
            return ""
        }
    override val canRunChanged = Event<EventArgs>()
    constructor(displayName: String, dexTableName: String) { /*@DONE ReorderDex.<init>/1 cs:18-18*/
        this.displayName = displayName
        this.dexTableName = dexTableName
    }
    override fun canRun(viewPortInterface: IViewPort): Boolean { /*@DONE ReorderDex.CanRun/1 cs:20-29*/
        val viewPort = viewPortInterface as? ViewPort ?: return false
        val model = viewPort.model
        val dexOrder = getTable(model, dexTableName)
        val dexInfo = getTable(model, HardcodeTablesModel.dexInfoTableName)
        val pokenames = getTable(model, HardcodeTablesModel.pokemonNameTable)
        val frontSprites = getTable(model, HardcodeTablesModel.frontSpritesTable)
        val pokepalettes = getTable(model, HardcodeTablesModel.pokePalettesTable)
        return dexOrder != null && pokenames != null && dexInfo != null && frontSprites != null && pokepalettes != null
    }
    override fun run(viewPortInterface: IViewPort): Task<ErrorInfo>? { /*@DONE ReorderDex.Run/1 cs:31-35*/
        val viewPort = viewPortInterface as ViewPort
        viewPort.openDexReorderTab(dexTableName)
        return Task.fromResult(ErrorInfo.noError)
    }
    override fun tabChanged() { /*@DONE ReorderDex.TabChanged/1 cs:37-37*/
        canRunChanged(this, EventArgs.empty)
    }
    companion object {
        fun getTable(model: IDataModel, name: String): ITableRun? { /*@DONE ReorderDex.GetTable/1 cs:39-42*/
            val address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, name)
            return model.getNextRun(address) as? ITableRun
        }
        /*@END ReorderDex.Companion*/
    }
    /*@END ReorderDex*/
}
