// Port of Models/Runs/Factory/BlockmapRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class BlockmapRunContentStrategy : RunStrategy() { // cs:19-63
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE BlockmapRunContentStrategy.LengthForNewRun/1 cs:20-24*/
        val width = model.readMultiByteValue(pointerAddress - 12, 4)
        val height = model.readMultiByteValue(pointerAddress - 8, 4)
        return width * height * 2
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE BlockmapRunContentStrategy.Matches/1 cs:26-26*/
        return run is BlockmapRun
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE BlockmapRunContentStrategy.TryAddFormatAtDestination/1 cs:28-34*/
        if (token is NoDataChangeDeltaModel) return true
        val newRun = BlockmapRun(owner, destination, SortedSpanStatic.one(source))
        owner.clearFormat(token, newRun.start, newRun.length)
        owner.observeRunWritten(token, newRun)
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE BlockmapRunContentStrategy.TryParseData/1 cs:36-39*/
        run.value = BlockmapRun(model, dataIndex, run.value?.pointerSources)
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE BlockmapRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:45-56*/
        val sanitySize = 100000
        val runAttempt = BlockmapRun(model, run.value.start, run.value.pointerSources)
        val currentSources = run.value.pointerSources
        if (currentSources != null) {
            for (i in 0 until currentSources.size) {
                val source = currentSources[i]
                if (runAttempt.start <= source && source < runAttempt.start + runAttempt.length) {
                    // one of the expected pointer sources is contained within the new run.
                    return
                }
            }
        }
        if (runAttempt.length > 0 && runAttempt.blockWidth <= sanitySize && runAttempt.blockHeight <= sanitySize) {
            val merged = runAttempt.mergeAnchor(run.value.pointerSources)
            run.value = merged
            model.clearFormat(token, merged.start, merged.length)
        }
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE BlockmapRunContentStrategy.WriteNewRun/1 cs:58-62*/
        val runAttempt = BlockmapRun(owner, destination, SortedSpanStatic.one(source))
        for (i in 0 until runAttempt.length) token.changeData(owner, destination + i, 0)
        return runAttempt
    }
    /*@END BlockmapRunContentStrategy*/
}
