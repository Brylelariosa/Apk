// Port of ViewModels/QuickEditItems/ApplyCFRUPatch.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.map.*

open class ApplyCFRUPatch : IQuickEditItem { // cs:9-61
    lateinit var editor: EditorViewModel
    override val name: String?
        get() { /*@DONE ApplyCFRUPatch.Name.get cs:14-14*/
            return "Apply HUBOL DPE CFRU"
        }
    override val description: String?
        get() { /*@DONE ApplyCFRUPatch.Description.get cs:16-26*/
            return arrayOf(
                "Haven's Unofficial Build Of Leon's DPE/CFRU Rombase.",
                "",
                "Running this will apply Leon's base, Dynamic Pokemon Expansion, and the Complete FireRed Upgrade to the current file.",
                "",
                "WARNING! This will save your file and make this ROM no longer vanilla!",
                "",
                "Credits to Leon for putting together the rombase with additional recommended features over the DPE/CFRU.",
                "",
                "Credits to Skeli / Ghoulslash for DPE / CFRU.",
                "",
                "Please read the Wiki for information about how to use the included features."
            ).joinToString(NEW_LINE)
        }
    override val wikiLink: String?
        get() { /*@DONE ApplyCFRUPatch.WikiLink.get cs:28-28*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Haven's-Unofficial-Build-Of-Leon's-Dynamic-Pokemon-Expansion---Complete-FireRed-Upgrade-Rombase"
        }
    override val canRunChanged = Event<EventArgs>()
    override fun canRun(viewPort: IViewPort): Boolean { /*@DONE ApplyCFRUPatch.CanRun/1 cs:32-32*/
        return viewPort is ViewPort && Patcher.calcCRC32(viewPort.model.rawData) == 0xDD88761C.toInt()
    }
    override fun run(viewPort1: IViewPort): Task<ErrorInfo>? { /*@DONE ApplyCFRUPatch.Run/1 cs:34-58*/
        return asyncTask<ErrorInfo> {
            val viewPort = viewPort1 as? ViewPort
            if (viewPort == null) return@asyncTask ErrorInfo("Selected tab is expected to be a FireRed data tab.")
            val model = viewPort.model
            // The Android build does not bundle the 17 MB patch (it would roughly double the size of the APK), so when it is
            // not part of the resources the user is asked for the file (it ships in the "resources" folder of HexManiacAdvance).
            val patch: ByteArray
            if (Resources.exists(patchFileName)) {
                patch = Resources.readAllBytes(patchFileName)
            } else {
                val answer = editor.fileSystem.showCustomMessageBox(
                    "The patch file hubol_dpe_cfru.ups is not bundled with this app (it is 17 MB).\n" +
                        "It is part of the HexManiacAdvance download, in the 'resources' folder. Pick it now?", true)
                if (answer != true) return@asyncTask ErrorInfo("The patch was not applied.")
                val picked = editor.fileSystem.openFile("UPS patch", "ups")
                if (picked == null) return@asyncTask ErrorInfo("No patch file was chosen.")
                patch = picked.contents
            }
            Patcher.applyUPSPatch(model, patch, { viewPort.currentChange }, true, Ref(Patcher.UpsPatchDirection.Fail))

            val fullFileName = viewPort.fullFileName

            // close tab (and related tabs), delete the toml, and re-open
            viewPort.save?.execute(editor.fileSystem)
            viewPort.close.execute()
            for (tab in editor.toList()) {
                if (tab is IViewPort && tab.model === model) { tab.save?.execute(); tab.close.execute() }
                if (tab is MapEditorViewModel && tab.viewPort.model === model) { tab.save?.execute(); tab.close.execute() }
                if (tab is DexReorderTab && tab.model === model) { tab.close.execute() }
                // need to close diff tabs / search result tabs?
            }

            val toml = Path.changeExtension(fullFileName, "toml")
            if (toml != null) java.io.File(toml).delete()
            editor.open.execute(editor.fileSystem.loadFile(fullFileName))

            ErrorInfo.noError
        }
    }
    override fun tabChanged() { /*@DONE ApplyCFRUPatch.TabChanged/1 cs:60-60*/
        canRunChanged(this, EventArgs.empty)
    }
    companion object {
        private const val patchFileName: String = "resources/hubol_dpe_cfru.ups"
        /*@END ApplyCFRUPatch.Companion*/
    }
    /*@END ApplyCFRUPatch*/
}
