// Port of ViewModels/Tools/StreamElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.map.*

abstract class StreamElementViewModel : ViewModelCore, IStreamArrayElementViewModel { // cs:12-252
    lateinit var viewPort: ViewPort
        private set
    lateinit var model: IDataModel
        private set
    var start: Int = 0
        protected set
    var runFormat: String = ""
        protected set
    private var _visible: Boolean = /*@INITAUTO StreamElementViewModel.visible cs:19-19*/ true /*@ENDINIT*/
    override var visible: Boolean
        get() { /*@DONE StreamElementViewModel.Visible.get cs:20-20*/
            return _visible
        }
        set(value) { /*@DONE StreamElementViewModel.Visible.set cs:20-20*/
            set(_visible, value, "visible", { _visible = it })
        }
    lateinit var undo: ICommand
        private set
    lateinit var redo: ICommand
        private set
    override val showContent: Boolean
        get() { /*@DONE StreamElementViewModel.ShowContent.get cs:27-27*/
            return usageCount != 0
        }
    override var parent: SplitterArrayElementViewModel? = null
    private var _usageCount: Int = 0
    override var usageCount: Int
        get() { /*@DONE StreamElementViewModel.UsageCount.get cs:33-33*/
            return _usageCount
        }
        set(value) { /*@DONE StreamElementViewModel.UsageCount.set cs:34-43*/
            if (!tryUpdate(_usageCount, value, "usageCount") { _usageCount = it }) return
            notifyPropertyChanged("showContent")
            notifyPropertyChanged("canRepoint")
            notifyPropertyChanged("canRepointAll")
            notifyPropertyChanged("hasMultipleUses")
            notifyPropertyChanged("canCreateNew")
            _repoint.raiseCanExecuteChanged()
            _createNew.raiseCanExecuteChanged()
        }
    val hasMultipleUses: Boolean
        get() { /*@DONE StreamElementViewModel.HasMultipleUses.get cs:46-46*/
            return usageCount > 1
        }
    override val canRepoint: Boolean
        get() { /*@DONE StreamElementViewModel.CanRepoint.get cs:48-48*/
            return !canCreateNew && (usageCount > 1 || dataIsValidButNoRun || dataIsNotValid)
        }
    override val canRepointAll: Boolean
        get() { /*@DONE StreamElementViewModel.CanRepointAll.get cs:50-50*/
            return usageCount > 2
        }
    val dataIsValidButNoRun: Boolean
        get() { /*@DONE StreamElementViewModel.DataIsValidButNoRun.get cs:53-61*/
            val destination = model.readPointer(start)
            if (destination < 0 || destination >= model.count) return false
            var run: IFormattedRun = model.getNextRun(destination) ?: NoInfoRun.nullRun
            if (run.start == destination) return false
            val runRef = Ref<IFormattedRun?>(NoInfoRun(destination, SortedSpan(start)))
            val error = model.formatRunFactory.getStrategy(runFormat)?.tryParseData(model, "", destination, runRef) ?: return false
            return !error.hasError
        }
    val dataIsNotValid: Boolean
        get() { /*@DONE StreamElementViewModel.DataIsNotValid.get cs:65-74*/
            val destination = model.readPointer(start)
            if (destination < 0 || destination >= model.count) return true
            val run: IFormattedRun = model.getNextRun(destination) ?: NoInfoRun.nullRun
            if (run.start != destination) return true
            val result = ModelCacheScope.createScope(model).using {
                val runRef = Ref<IFormattedRun?>(run)
                val error = model.formatRunFactory.getStrategy(runFormat)?.tryParseData(model, "", destination, runRef)
                error?.hasError ?: true
            }
            return result
        }
    fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem> { /*@DONE StreamElementViewModel.GetAutoCompleteOptions/1 cs:77-86*/
        val destination = model.readPointer(start)
        val streamRun = model.getNextRun(destination) as? IStreamRun
        if (streamRun != null) {
            val options = streamRun.getAutoCompleteOptions(line, caretLineIndex, caretCharacterIndex)
            if (options != null && options.size > 0) zIndex = 1
            return options ?: ArrayList<AutocompleteItem>()
        } else {
            return ArrayList<AutocompleteItem>()
        }
    }
    fun clearAutocomplete() { /*@DONE StreamElementViewModel.ClearAutocomplete/1 cs:88-88*/
        zIndex = 0
    }
    private val _repoint: StubCommand = /*@INITAUTO StreamElementViewModel.repoint cs:90-90*/ StubCommand() /*@ENDINIT*/
    override val repoint: ICommand
        get() { /*@DONE StreamElementViewModel.Repoint.get cs:91-91*/
            return _repoint
        }
    private val _repointAll: StubCommand = /*@INITAUTO StreamElementViewModel.repointAll cs:93-93*/ StubCommand() /*@ENDINIT*/
    override val repointAll: ICommand
        get() { /*@DONE StreamElementViewModel.RepointAll.get cs:94-94*/
            return _repointAll
        }
    override val canCreateNew: Boolean
        get() { /*@DONE StreamElementViewModel.CanCreateNew.get cs:96-96*/
            return usageCount == 0
        }
    private val _createNew: StubCommand = /*@INITAUTO StreamElementViewModel.createNew cs:98-98*/ StubCommand() /*@ENDINIT*/
    override val createNew: ICommand
        get() { /*@DONE StreamElementViewModel.CreateNew.get cs:99-99*/
            return _createNew
        }
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE StreamElementViewModel.Theme.get cs:101-101*/
            return _theme
        }
        set(value) { /*@DONE StreamElementViewModel.Theme.set cs:101-101*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE StreamElementViewModel.IsInError.get cs:102-102*/
            return !errorText.isNullOrEmpty()
        }
    private var _errorText: String = ""
    override var errorText: String?
        get() { /*@DONE StreamElementViewModel.ErrorText.get cs:106-106*/
            return _errorText
        }
        set(value) { /*@DONE StreamElementViewModel.ErrorText.set cs:107-107*/
            if (tryUpdate(_errorText, value ?: "", "errorText") { _errorText = it }) notifyPropertyChanged("isInError")
        }
    var parentName: String = ""
        private set
    private var _zIndex: Int = 0
    final override var zIndex: Int
        get() { /*@DONE StreamElementViewModel.ZIndex.get cs:113-113*/
            return _zIndex
        }
        private set(value) { /*@DONE StreamElementViewModel.ZIndex.set cs:113-113*/
            set(_zIndex, value, "zIndex", { _zIndex = it })
        }
    private var _dataMoved: EventHandlerOf<Pair<Int, Int>>? = null
    override val dataMoved = Event<IStreamArrayElementViewModelDataMovedTuple>()
    protected fun raiseDataMoved(originalStart: Int, newStart: Int) { /*@DONE StreamElementViewModel.RaiseDataMoved/1 cs:117-117*/
        dataMoved(this, IStreamArrayElementViewModelDataMovedTuple(originalStart, newStart))
    }
    private var _dataChanged: EventHandler? = null
    override val dataChanged = Event<EventArgs>()
    protected fun raiseDataChanged() { /*@DONE StreamElementViewModel.RaiseDataChanged/1 cs:121-121*/
        dataChanged(this, EventArgs.empty)
    }
    private var _dataSelected: EventHandler? = null
    override val dataSelected = Event<EventArgs>()
    protected fun raiseDataSelected() { /*@DONE StreamElementViewModel.RaiseDataSelected/1 cs:125-125*/
        dataSelected(this, EventArgs.empty)
    }
    protected constructor(viewPort: ViewPort, parentName: String, runFormat: String, start: Int) { /*@DONE StreamElementViewModel.<init>/1 cs:129-157*/
        this.viewPort = viewPort
        this.model = viewPort.model
        this.start = start
        this.runFormat = runFormat
        this.parentName = parentName
        undo = viewPort.undo
        redo = viewPort.redo

        _repoint.canExecute = { _ -> canRepoint }
        _repoint.execute = this::executeRepoint
        _repointAll.canExecute = { _ -> canRepointAll }
        _repointAll.execute = this::executeRepointAll

        _createNew.canExecute = { _ -> canCreateNew }
        _createNew.execute = this::executeCreateNew

        // by the time we get this far, we're nearly guaranteed that this will be a IStreamRun.
        // if it's not an IStreamRun, it's because the pointer in the array doesn't actually point to a valid stream.
        // (It might point to an IPagedRun or some other stream-like element.)
        // at which point, we don't want to display any content.
        val destination = this.model.readPointer(this.start)
        if (destination == Pointer.null_) {
            usageCount = 0
        } else {
            val run = this.model.getNextRun(destination)
            usageCount = if (run is IStreamRun || run is ITableRun) (run.pointerSources?.size ?: 0) else 0
        }
    }
    private var overrideCopyAttempt: Boolean = false
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE StreamElementViewModel.TryCopy/1 cs:163-184*/
        val that = other as? StreamElementViewModel ?: return false
        if (overrideCopyAttempt) return true
        if (!tryCopy(that)) return false

        usageCount = that.usageCount
        errorText = that.errorText
        dataMoved.copyFrom(that.dataMoved)
        dataChanged.copyFrom(that.dataChanged)
        dataSelected.copyFrom(that.dataSelected)
        start = that.start
        runFormat = that.runFormat
        visible = that.visible
        parentName = that.parentName
        notifyPropertyChanged("canRepoint")
        notifyPropertyChanged("canRepointAll")
        _repoint.raiseCanExecuteChanged()
        notifyPropertyChanged("dataIsValidButNoRun")
        notifyPropertyChanged("parentName")

        return true
    }
    protected fun preventSelfCopy(): IDisposable { /*@DONE StreamElementViewModel.PreventSelfCopy/1 cs:186-189*/
        overrideCopyAttempt = true
        return StubDisposable { overrideCopyAttempt = false }
    }
    protected abstract fun tryCopy(other: StreamElementViewModel): Boolean
    private fun executeRepoint(arg: Any?) { /*@DONE StreamElementViewModel.ExecuteRepoint/1 cs:195-198*/
        viewPort.repointToNewCopy(start)
        refreshCount()
    }
    private fun executeRepointAll(arg: Any?) { /*@DONE StreamElementViewModel.ExecuteRepointAll/1 cs:200-207*/
        val destination = model.readPointer(start)
        val sources = (model.getNextRun(destination)?.pointerSources ?: ArrayList<Int>()).drop(1)
        repointAllAsync(sources).continueWith { _ ->
            viewPort.clearProgress()
            refreshCount()
        }
    }
    private fun repointAllAsync(sources: List<Int>): Task<ErrorInfo> { /*@DONE StreamElementViewModel.RepointAllAsync/1 cs:209-221*/
        return asyncTask {
            val buffer = viewPort.model.freeSpaceBuffer
            viewPort.model.freeSpaceBuffer = 0
            val groupSize = Math.max(1, sources.size / 100)
            for (i in 0 until sources.size) {
                viewPort.repointToNewCopy(sources[i])
                if (i % groupSize == 0) {
                    viewPort.updateProgress((i + 1) / sources.size.toDouble()).await()
                }
            }
            viewPort.model.freeSpaceBuffer = buffer
            ErrorInfo.noError
        }
    }
    private fun executeCreateNew(arg: Any?) { /*@DONE StreamElementViewModel.ExecuteCreateNew/1 cs:223-226*/
        viewPort.repointToNewCopy(start)
        refreshCount()
    }
    private fun refreshCount() { /*@DONE StreamElementViewModel.RefreshCount/1 cs:228-251*/
        viewPort.refresh()
        usageCount = 1
        dataChanged(this, EventArgs.empty)

        // Random code that shouldn't live here, but this is the trigger that people expect.
        // In response to the "Repoint" button in the table tool, we need to update the layout table.
        // Do a bunch of checks to make sure that this is the case we're interested in.
        if (this.parentName != "layout") return
        val mapRun = model.getNextRun(start) as? TableStreamRun
        if (mapRun == null || mapRun.elementCount != 1) return
        val mapSources = mapRun.pointerSources
        if (mapSources == null || mapSources.size != 1) return
        val bankRun = model.getNextRun(mapSources[0]) as? TableStreamRun
        if (bankRun == null) return
        val bankSources = bankRun.pointerSources
        if (bankSources == null || bankSources.size != 1) return
        val mapTable = model.getNextRun(bankSources[0]) as? ITableRun
        if (mapTable == null || mapTable !== model.getNextAnchor(HardcodeTablesModel.mapBankTable)) return

        // look up the bank/map and update the layoutID
        val bankNumber = mapTable.convertByteOffsetToArrayOffset(bankSources[0]).elementIndex
        val mapNumber = bankRun.convertByteOffsetToArrayOffset(mapSources[0]).elementIndex
        val repointInfo = BlockMapViewModel.updateLayoutID(model, bankNumber, mapNumber) { viewPort.currentChange }
        if (repointInfo != null) {
            viewPort.raiseMessage(repointInfo.type + " moved to " + repointInfo.address.toHex(6))
        }
    }
    /*@END StreamElementViewModel*/
}
