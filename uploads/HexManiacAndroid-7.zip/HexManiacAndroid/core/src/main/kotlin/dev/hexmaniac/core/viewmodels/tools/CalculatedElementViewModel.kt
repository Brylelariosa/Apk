// Port of ViewModels/Tools/CalculatedElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class CalculatedElementViewModel : ViewModelCore, IArrayElementViewModel { // cs:9-67
    private lateinit var model: IDataModel
    private lateinit var segment: ArrayRunCalculatedSegment
    private var dataStart: Int = 0
    val name: String
        get() { /*@DONE CalculatedElementViewModel.Name.get cs:14-14*/
            return segment.name
        }
    val calculatedValue: String
        get() { /*@DONE CalculatedElementViewModel.CalculatedValue.get cs:16-32*/
            val table = segment.model!!.getNextRun(dataStart) as? ITableRun
            if (table == null) return ""
            val offset = table.convertByteOffsetToArrayOffset(dataStart)
            val value = segment.calculatedValue(table.start + table.elementLength * offset.elementIndex)

            val isWhole = value == value.toInt().toDouble()
            var text = if (isWhole) value.toInt().toString() else value.toString()
            val enumName = segment.enum
            if (isWhole && enumName != null) {
                val options = model.getOptions(enumName)
                if (value >= 0.0 && value < options.size) text = options[value.toInt()]
            } else if (!isWhole) {
                // rounding
                text = String.format(java.util.Locale.ROOT, "%.2f", value)
            }

            return text
        }
    var operands: ObservableCollection<CalculatedElementViewModelOperand> = ObservableCollection()
        private set
    val operator: String
        get() { /*@DONE CalculatedElementViewModel.Operator.get cs:35-35*/
            return segment.operator
        }
    val hasOperator: Boolean
        get() { /*@DONE CalculatedElementViewModel.HasOperator.get cs:36-36*/
            return segment.hasOperator
        }
    constructor(viewPort: IViewPort, segment: ArrayRunCalculatedSegment, start: Int) { /*@DONE CalculatedElementViewModel.<init>/1 cs:38-43*/
        this.segment = segment
        dataStart = start
        this.model = viewPort.model!!
        operands = ObservableCollection()
        for (operand in segment.operands) operands.add(CalculatedElementViewModelOperand(operand, viewPort, start))
    }
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE CalculatedElementViewModel.Theme.get cs:47-47*/
            return _theme
        }
        set(value) { /*@DONE CalculatedElementViewModel.Theme.set cs:47-47*/
            set(_theme, value, "theme", { _theme = it })
        }
    private var _visible: Boolean = false
    override var visible: Boolean
        get() { /*@DONE CalculatedElementViewModel.Visible.get cs:49-49*/
            return _visible
        }
        set(value) { /*@DONE CalculatedElementViewModel.Visible.set cs:49-49*/
            set(_visible, value, "visible", { _visible = it })
        }
    override val isInError: Boolean
        get() { /*@DONE CalculatedElementViewModel.IsInError.get cs:50-50*/
            return false
        }
    override val errorText: String?
        get() { /*@DONE CalculatedElementViewModel.ErrorText.get cs:51-51*/
            return ""
        }
    override val zIndex: Int
        get() { /*@DONE CalculatedElementViewModel.ZIndex.get cs:52-52*/
            return 0
        }
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE CalculatedElementViewModel.TryCopy/1 cs:56-64*/
        val that = other as? CalculatedElementViewModel ?: return false
        segment = that.segment
        dataStart = that.dataStart
        this.model = that.model
        operands.clear()
        for (operand in that.operands) operands.add(operand)
        notifyPropertiesChanged("name", "calculatedValue", "operator", "hasOperator")
        return true
    }
    /*@END CalculatedElementViewModel*/
}

open class CalculatedElementViewModelOperand : ViewModelCore { // cs:69-86
    var text: String? = null
        private set
    lateinit var jumpTo: ICommand
        private set
    constructor(text: String, viewPort: IViewPort, sourceAddress: Int) { /*@DONE CalculatedElementViewModelOperand.<init>/1 cs:73-85*/
        this.text = text
        jumpTo = StubCommand()

        val table = viewPort.model!!.getNextRun(sourceAddress) as? ITableRun
        if (table != null && table.start <= sourceAddress) {
            val offset = table.convertByteOffsetToArrayOffset(sourceAddress)
            val destination = ArrayRunCalculatedSegment.calculateSource(viewPort.model!!, table, offset.elementIndex, text)
            if (destination != Pointer.null_) {
                val jump = StubCommand()
                jump.execute = { _ -> viewPort.goto?.execute(destination) }
                jump.canExecute = { _ -> true }
                jumpTo = jump
            }
        }
    }
    /*@END CalculatedElementViewModelOperand*/
}
