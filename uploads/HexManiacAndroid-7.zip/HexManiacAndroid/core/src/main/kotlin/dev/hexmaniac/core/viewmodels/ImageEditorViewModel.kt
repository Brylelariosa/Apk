// Port of ViewModels/ImageEditorViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.tools.*

open class ImageEditorViewModelCreationException : Exception { // cs:20-22
    constructor(message: String) : super(message) { /*@DONE ImageEditorViewModelCreationException.<init>/1 cs:21-21*/
        // the message is passed to the base class
    }
    /*@END ImageEditorViewModelCreationException*/
}

open class ImageEditorViewModel : ViewModelCore, ITabContent, IPixelViewModel, IRaiseMessageTab { // cs:24-1551
    private lateinit var history: ChangeHistory<ModelDelta>
    private lateinit var model: IDataModel
    private var pixels: Array<IntArray> = emptyArray()
    private var withinInteraction: Boolean = false
    private var withinDropperInteraction: Boolean = false
    private var withinPanInteraction: Boolean = false
    private var interactionStart: Point = Point()
    private var selectedPixels: Array<BooleanArray> = emptyArray()
    private var _close: StubCommand? = null
    private var undoWrapper: StubCommand? = null
    private var redoWrapper: StubCommand? = null
    private var pasteCommand: StubCommand? = null
    private var copyCommand: StubCommand? = null
    private var selectAllCommand: StubCommand? = null
    override val name: String
        get() { /*@DONE ImageEditorViewModel.Name.get cs:40-40*/
            return "Image Editor"
        }
    var fullFileName: String = ""
        private set
    override var spartanMode: Boolean = false
    override val isMetadataOnlyChange: Boolean
        get() { /*@DONE ImageEditorViewModel.IsMetadataOnlyChange.get cs:43-43*/
            return false
        }
    final override var save: ICommand? = null
        private set
    override val saveAs: ICommand
        get() { /*@DONE ImageEditorViewModel.SaveAs.get cs:45-45*/
            return disabledViewPortCommand
        }
    override val exportBackup: ICommand
        get() { /*@DONE ImageEditorViewModel.ExportBackup.get cs:46-46*/
            return disabledViewPortCommand
        }
    override val undo: ICommand
        get() { /*@DONE ImageEditorViewModel.Undo.get cs:47-47*/
            return undoWrapper ?: stubCommand({ executeUndo() }, { history.undo.canExecute(null) }).also { undoWrapper = it }
        }
    override val redo: ICommand
        get() { /*@DONE ImageEditorViewModel.Redo.get cs:48-48*/
            return redoWrapper ?: stubCommand({ executeRedo() }, { history.redo.canExecute(null) }).also { redoWrapper = it }
        }
    override val copy: ICommand?
        get() { /*@DONE ImageEditorViewModel.Copy.get cs:49-49*/
            return copyCommand ?: argCommand({ arg ->
                val fs = arg as? IFileSystem
                if (fs != null) executeCopy(fs)
            }, { arg ->
                val tool = toolStrategy
                tool is SelectionTool && tool.hasSelection
            }).also { copyCommand = it }
        }
    val paste: ICommand
        get() { /*@DONE ImageEditorViewModel.Paste.get cs:50-50*/
            return pasteCommand ?: argCommand({ arg ->
                val fs = arg as? IFileSystem
                if (fs != null) executePaste(fs)
            }, { arg ->
                val fs = arg as? IFileSystem
                fs != null && fs.copyImage.width != 0
            }).also { pasteCommand = it }
        }
    override val selectAll: ICommand
        get() { /*@DONE ImageEditorViewModel.SelectAll.get cs:51-51*/
            return selectAllCommand ?: stubCommand({ executeSelectAll() }, { true }).also { selectAllCommand = it }
        }
    override val deepCopy: ICommand
        get() { /*@DONE ImageEditorViewModel.DeepCopy.get cs:52-52*/
            return disabledViewPortCommand
        }
    override val diff: ICommand
        get() { /*@DONE ImageEditorViewModel.Diff.get cs:53-53*/
            return disabledViewPortCommand
        }
    override val diffLeft: ICommand
        get() { /*@DONE ImageEditorViewModel.DiffLeft.get cs:54-54*/
            return disabledViewPortCommand
        }
    override val diffRight: ICommand
        get() { /*@DONE ImageEditorViewModel.DiffRight.get cs:55-55*/
            return disabledViewPortCommand
        }
    override val clear: ICommand?
        get() { /*@DONE ImageEditorViewModel.Clear.get cs:56-56*/
            return null
        }
    override val goto: ICommand?
        get() { /*@DONE ImageEditorViewModel.Goto.get cs:57-57*/
            return null
        }
    override val resetAlignment: ICommand
        get() { /*@DONE ImageEditorViewModel.ResetAlignment.get cs:58-58*/
            return disabledViewPortCommand
        }
    override val back: ICommand
        get() { /*@DONE ImageEditorViewModel.Back.get cs:59-59*/
            return disabledViewPortCommand
        }
    override val forward: ICommand
        get() { /*@DONE ImageEditorViewModel.Forward.get cs:60-60*/
            return disabledViewPortCommand
        }
    override val close: ICommand
        get() { /*@DONE ImageEditorViewModel.Close.get cs:61-61*/
            return _close ?: stubCommand({ closed(this, EventArgs.empty) }).also { _close = it }
        }
    override val canDuplicate: Boolean
        get() { /*@DONE ImageEditorViewModel.CanDuplicate.get cs:62-62*/
            return false
        }
    override fun duplicate() { /*@DONE ImageEditorViewModel.Duplicate/1 cs:63-63*/
        // images cannot be duplicated
    }
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val clearMessage = Event<EventArgs>()
    override val closed = Event<EventArgs>()
    override val requestTabChange = Event<TabChangeRequestedEventArgs>()
    override val requestDelayedWork = Event<() -> Unit>()
    override val requestMenuClose = Event<EventArgs>()
    override val requestDiff = Event<Direction>()
    override val requestCanCreatePatch = Event<CanPatchEventArgs>()
    override val requestCreatePatch = Event<CanPatchEventArgs>()
    override val requestCanDiff = Event<CanDiffEventArgs>()
    override val requestRefreshGotoShortcuts = Event<EventArgs>()
    override val canIpsPatchRight: Boolean
        get() { /*@DONE ImageEditorViewModel.CanIpsPatchRight.get cs:77-77*/
            return false
        }
    override val canUpsPatchRight: Boolean
        get() { /*@DONE ImageEditorViewModel.CanUpsPatchRight.get cs:78-78*/
            return false
        }
    override fun ipsPatchRight() { /*@DONE ImageEditorViewModel.IpsPatchRight/1 cs:79-79*/
        // not supported for images
    }
    override fun upsPatchRight() { /*@DONE ImageEditorViewModel.UpsPatchRight/1 cs:80-80*/
        // not supported for images
    }
    override fun raiseMessage(message: String) { /*@DONE ImageEditorViewModel.RaiseMessage/1 cs:82-82*/
        onMessage(this, message)
    }
    fun raiseError(message: String) { /*@DONE ImageEditorViewModel.RaiseError/1 cs:84-84*/
        onError(this, message)
    }
    private fun executeUndo() { /*@DONE ImageEditorViewModel.ExecuteUndo/1 cs:86-98*/
        val selectionStart = palette.selectionStart
        val selectionEnd = palette.selectionEnd

        history.undo.execute()
        undoWrapper?.raiseCanExecuteChanged()
        redoWrapper?.raiseCanExecuteChanged()
        refresh()
        if (hasMultipleEditOptions) editOptions[selectedEditOption].refresh()

        palette.selectionStart = selectionStart
        palette.selectionEnd = selectionEnd
    }
    private fun executeRedo() { /*@DONE ImageEditorViewModel.ExecuteRedo/1 cs:100-106*/
        history.redo.execute()
        undoWrapper?.raiseCanExecuteChanged()
        redoWrapper?.raiseCanExecuteChanged()
        refresh()
        if (hasMultipleEditOptions) editOptions[selectedEditOption].refresh()
    }
    private fun executeCopy(fs: IFileSystem) { /*@DONE ImageEditorViewModel.ExecuteCopy/1 cs:108-111*/
        val tool = toolStrategy as? SelectionTool ?: return
        tool.copy(fs)
    }
    private fun executePaste(fs: IFileSystem) { /*@DONE ImageEditorViewModel.ExecutePaste/1 cs:113-171*/
        val sprite = fs.copyImage
        if (sprite.width == 0) return
        val height = sprite.image.size / sprite.width
        if (height > pixelHeight || sprite.width > pixelWidth) {
            raiseMessage("Image is too large to paste!")
            return
        }

        selectedTool = ImageEditorTools.Select
        val tool = toolStrategy as SelectionTool
        tool.clearSelection()
        val hoverPoint = toSpriteSpace(interactionStart)
        var x = hoverPoint.x - sprite.width / 2
        var y = hoverPoint.y - height / 2
        x = x.limitToRange(0, pixelWidth - sprite.width)
        y = y.limitToRange(0, pixelHeight - height)
        toolDown(fromSpriteSpace(Point(x, y)))
        hover(fromSpriteSpace(Point(x + sprite.width - 1, y + height - 1)))
        toolUp(fromSpriteSpace(Point(x + sprite.width - 1, y + height - 1)))

        var fullPalette: List<Short>
        if (palettePointer == Pointer.null_) {
            fullPalette = TileViewModel.createDefaultPalette(palette.elements.size).asList()
        } else {
            val paletteRun = model.getNextRun(model.readPointer(palettePointer)) as IPaletteRun
            fullPalette = paletteRun.allColors(model) ?: ArrayList()
        }

        // choose a palette that best matches the available colors
        if (palette.elements.size < fullPalette.size) {
            val paletteMatch = IntArray(fullPalette.size / palette.elements.size)
            for (xx in 0 until sprite.width) {
                for (yy in 0 until height) {
                    val targetColor = sprite.image[yy * sprite.width + xx]
                    for (i in 0 until fullPalette.size) {
                        if (fullPalette[i] != targetColor) continue
                        val pal = i / palette.elements.size
                        if (pal < paletteMatch.size) paletteMatch[pal]++
                    }
                }
            }
            val max = paletteMatch.max()
            val palChoice = paletteMatch.indices.first { i -> paletteMatch[i] == max }
            fullPalette = fullPalette.drop(palChoice * palette.elements.size).take(palette.elements.size)
        }

        val newUnderPixels = Array(sprite.width) { IntArray(height) }
        for (xx in 0 until sprite.width) {
            for (yy in 0 until height) {
                val targetColor = sprite.image[yy * sprite.width + xx]
                var paletteIndex = fullPalette.indexOf(targetColor)
                if (paletteIndex < 0) paletteIndex = 0
                paletteIndex %= palette.elements.size
                newUnderPixels[xx][yy] = paletteIndex
            }
        }

        tool.setUnderPixels(newUnderPixels)
        tool.swapUnderPixelsWithCurrentPixels()

        updateSpriteModel()
        notifyPropertyChanged("pixelData")
    }
    private fun executeSelectAll() { /*@DONE ImageEditorViewModel.ExecuteSelectAll/1 cs:173-178*/
        selectedTool = ImageEditorTools.Select
        toolDown(fromSpriteSpace(Point()))
        hover(fromSpriteSpace(Point(pixelWidth - 1, pixelHeight - 1)))
        toolUp(fromSpriteSpace(Point(pixelWidth - 1, pixelHeight - 1)))
    }
    private var _spritePage: Int = 0
    private var _palettePage: Int = 0
    var spritePage: Int
        get() { /*@DONE ImageEditorViewModel.SpritePage.get cs:184-184*/
            return _spritePage
        }
        set(value) { /*@DONE ImageEditorViewModel.SpritePage.set cs:184-184*/
            set(_spritePage, value, "spritePage", { _spritePage = it }) { refresh() }
        }
    var palettePage: Int
        get() { /*@DONE ImageEditorViewModel.PalettePage.get cs:185-185*/
            return _palettePage
        }
        set(value) { /*@DONE ImageEditorViewModel.PalettePage.set cs:185-185*/
            set(_palettePage, value, "palettePage", { _palettePage = it }) { refresh() }
        }
    val spritePages: Int
        get() { /*@DONE ImageEditorViewModel.SpritePages.get cs:186-186*/
            return spritePageOptions.size
        }
    val palettePages: Int
        get() { /*@DONE ImageEditorViewModel.PalettePages.get cs:187-187*/
            return palettePageOptions.size
        }
    val hasMultipleSpritePages: Boolean
        get() { /*@DONE ImageEditorViewModel.HasMultipleSpritePages.get cs:188-188*/
            return spritePages > 1
        }
    val hasMultiplePalettePages: Boolean
        get() { /*@DONE ImageEditorViewModel.HasMultiplePalettePages.get cs:189-189*/
            return palettePages > 1
        }
    var spritePageOptions: ObservableCollection<SelectionViewModel> = /*@INITAUTO ImageEditorViewModel.SpritePageOptions cs:190-190*/ ObservableCollection() /*@ENDINIT*/
        private set
    var palettePageOptions: ObservableCollection<SelectionViewModel> = /*@INITAUTO ImageEditorViewModel.PalettePageOptions cs:191-191*/ ObservableCollection() /*@ENDINIT*/
        private set
    private fun setupPageOptions() { /*@DONE ImageEditorViewModel.SetupPageOptions/1 cs:192-217*/
        val spritePageCount = (model.getNextRun(model.readPointer(spritePointer)) as? ISpriteRun)?.pages ?: 1
        spritePageOptions.clear()
        for (i in 0 until spritePageCount) {
            val option = SelectionViewModel()
            option.selected = i == _spritePage
            option.name = i.toString()
            option.index = i
            option.bind("selected") { sender, _ -> if (sender.selected) spritePage = sender.index }
            spritePageOptions.add(option)
        }
        notifyPropertyChanged("spritePages")
        notifyPropertyChanged("hasMultipleSpritePages")

        val palInfo = readPalette()
        val palPages = palInfo.pages
        val initialBlankPalettePages = palInfo.initialBlankPages
        palettePageOptions.clear()
        for (i in 0 until palPages) {
            val option = SelectionViewModel()
            option.selected = i == _palettePage
            option.name = i.toString()
            option.index = i
            option.bind("selected") { sender, _ -> if (sender.selected) palettePage = sender.index }
            palettePageOptions.add(option)
        }
        if (initialBlankPalettePages != 0) {
            val option = SelectionViewModel()
            option.selected = -initialBlankPalettePages == _palettePage
            option.name = "default" + "\n" + "Colors from this page are not recommended, but may be needed for transparency."
            option.index = -initialBlankPalettePages
            option.bind("selected") { sender, _ -> if (sender.selected) palettePage = sender.index }
            palettePageOptions.add(0, option)
        }
        notifyPropertyChanged("palettePages")
        notifyPropertyChanged("hasMultiplePalettePages")
    }
    val hasMultipleEditOptions: Boolean
        get() { /*@DONE ImageEditorViewModel.HasMultipleEditOptions.get cs:225-225*/
            return editOptions.size > 1
        }
    var editOptions: ObservableCollection<EditOption> = /*@INITAUTO ImageEditorViewModel.EditOptions cs:227-227*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _selectedEditOption: Int = 0
    var selectedEditOption: Int
        get() { /*@DONE ImageEditorViewModel.SelectedEditOption.get cs:230-230*/
            return _selectedEditOption
        }
        set(value) { /*@DONE ImageEditorViewModel.SelectedEditOption.set cs:230-230*/
            set(_selectedEditOption, value, "selectedEditOption", { _selectedEditOption = it }) { old -> selectedEditOptionChanged(old) }
        }
    private fun selectedEditOptionChanged(oldValue: Int) { /*@DONE ImageEditorViewModel.SelectedEditOptionChanged/1 cs:232-245*/
        if (selectedEditOption == -1) set(_selectedEditOption, oldValue, "selectedEditOption", { _selectedEditOption = it })
        val option = editOptions[selectedEditOption.limitToRange(0, editOptions.size - 1)]
        spritePointer = option.spritePointer
        palettePointer = option.palettePointer
        pixelWidth = option.pixelWidth
        pixelHeight = option.pixelHeight
        notifyPropertyChanged("spritePointer")
        notifyPropertyChanged("palettePointer")
        notifyPropertyChanged("pixelWidth")
        notifyPropertyChanged("pixelHeight")
        refresh()
        setupPageOptions()
    }
    private fun initializeEditOptions() { /*@DONE ImageEditorViewModel.InitializeEditOptions/1 cs:247-277*/
        editOptions.clear()
        val currentTable = model.getNextRun(spritePointer) as? ArrayRun
        if (currentTable == null) {
            editOptions.add(EditOption(model, spritePointer, palettePointer))
            notifyPropertyChanged("hasMultipleEditOptions")
            selectedEditOption = 0
            return
        }

        val offset = currentTable.convertByteOffsetToArrayOffset(spritePointer)
        for (table in model.getRelatedArrays(currentTable)) {
            for (i in 0 until table.elementContent.size) {
                val segmentStart = table.elementContent.take(i).sumOf { seg -> seg.length }
                val pSegment = table.elementContent[i] as? ArrayRunPointerSegment ?: continue
                val relatedSpritePointer = table.start + table.elementLength * offset.elementIndex + segmentStart
                val spriteAddress = model.readPointer(relatedSpritePointer)
                val spriteRun = model.getNextRun(spriteAddress) as? ISpriteRun
                if (spriteRun == null || spriteRun.start != spriteAddress || spriteRun.formatString != pSegment.innerFormat) continue
                for (relatedPalette in spriteRun.findRelatedPalettes(model, relatedSpritePointer, includeAllTableIndex = true)) {
                    editOptions.add(EditOption(model, relatedSpritePointer, relatedPalette.pointerSources!![0]))
                }
                if (spriteRun.spriteFormat.bitsPerPixel < 4) {
                    editOptions.add(EditOption(model, relatedSpritePointer, Pointer.null_))
                }
            }
        }

        notifyPropertyChanged("hasMultipleEditOptions")
        selectedEditOption = 0
    }
    private var flipVerticalCommand: StubCommand? = null
    private var flipHorizontalCommand: StubCommand? = null
    val flipVertical: ICommand
        get() { /*@DONE ImageEditorViewModel.FlipVertical.get cs:285-285*/
            return flipVerticalCommand ?: stubCommand({ executeFlipVertical() }, { canExecuteOrientSelectedPixels() }).also { flipVerticalCommand = it }
        }
    val flipHorizontal: ICommand
        get() { /*@DONE ImageEditorViewModel.FlipHorizontal.get cs:286-286*/
            return flipHorizontalCommand ?: stubCommand({ executeFlipHorizontal() }, { canExecuteOrientSelectedPixels() }).also { flipHorizontalCommand = it }
        }
    private fun canExecuteOrientSelectedPixels(): Boolean { /*@DONE ImageEditorViewModel.CanExecuteOrientSelectedPixels/1 cs:288-291*/
        val tool = toolStrategy as? SelectionTool ?: return false
        return tool.hasSelection
    }
    private fun executeFlipVertical() { /*@DONE ImageEditorViewModel.ExecuteFlipVertical/1 cs:293-298*/
        val tool = toolStrategy as? SelectionTool ?: return
        tool.flipVertical()
        updateSpriteModel()
        render()
    }
    private fun executeFlipHorizontal() { /*@DONE ImageEditorViewModel.ExecuteFlipHorizontal/1 cs:300-305*/
        val tool = toolStrategy as? SelectionTool ?: return
        tool.flipHorizontal()
        updateSpriteModel()
        render()
    }
    val canEditTilePalettes: Boolean
        get() { /*@DONE ImageEditorViewModel.CanEditTilePalettes.get cs:312-321*/
            val spriteAddress = model.readPointer(spritePointer)
            if (!hasMultiplePalettePages) return false
            val tilemap = model.getNextRun(spriteAddress) as? ITilemapRun ?: return false
            if (tilemap.start != spriteAddress) return false
            val tileset = model.getNextRun(tilemap.findMatchingTileset(model)) as? ITilesetRun ?: return false
            return tileset.tilesetFormat.bitsPerPixel == 4 && tilemap.bytesPerTile == 2
        }
    val tileWidth: Int
        get() { /*@DONE ImageEditorViewModel.TileWidth.get cs:324-324*/
            return pixelWidth / 8
        }
    val tileHeight: Int
        get() { /*@DONE ImageEditorViewModel.TileHeight.get cs:325-325*/
            return pixelHeight / 8
        }
    val fontSize: Double
        get() { /*@DONE ImageEditorViewModel.FontSize.get cs:326-326*/
            return spriteScale * 8
        }
    var tilePalettes: ObservableCollection<Int> = /*@INITAUTO ImageEditorViewModel.TilePalettes cs:328-328*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var _tilePaletteMode: TilePaletteMode = TilePaletteMode.Draw
    var tilePaletteMode: TilePaletteMode
        get() { /*@DONE ImageEditorViewModel.TilePaletteMode.get cs:331-331*/
            return _tilePaletteMode
        }
        set(value) { /*@DONE ImageEditorViewModel.TilePaletteMode.set cs:331-331*/
            tryUpdate(_tilePaletteMode, value, "tilePaletteMode") { _tilePaletteMode = it }
        }
    private var tilePaletteRefreshing: Boolean = false
    private fun refreshTilePalettes() { /*@DONE ImageEditorViewModel.RefreshTilePalettes/1 cs:334-347*/
        val spriteAddress = model.readPointer(spritePointer)
        val tilemapRun = model.getNextRun(spriteAddress) as? ITilemapRun ?: return
        val guard = scope(tilePaletteRefreshing, true, { tilePaletteRefreshing = it }, { tilePaletteRefreshing = it })
        try {
            tilePalettes.clear()
            val runData = tilemapRun.getTilemapData()
            val pal = readPalette()
            for (i in 0 until runData.size / tilemapRun.bytesPerTile) {
                var paletteIndex = LzTilemapRun.readTileData(runData, i, tilemapRun.bytesPerTile).paletteIndex
                if (tilemapRun.bytesPerTile == 1) paletteIndex = pal.initialBlankPages
                tilePalettes.add(paletteIndex)
            }
        } finally {
            guard.dispose()
        }
    }
    private fun pushTilePalettesToModel(sender: Any?, e: EventArgs) { /*@DONE ImageEditorViewModel.PushTilePalettesToModel/1 cs:349-359*/
        val spriteAddress = model.readPointer(spritePointer)
        val tilemapRun = model.getNextRun(spriteAddress) as? ITilemapRun
        if (tilemapRun == null || tilePaletteRefreshing) return
        val runData = tilemapRun.getTilemapData()
        for (i in 0 until runData.size / tilemapRun.bytesPerTile) {
            val tile = LzTilemapRun.readTileData(runData, i, tilemapRun.bytesPerTile)
            val paletteIndex = tilePalettes[i]
            LzTilemapRun.writeTileData(runData, i, paletteIndex, tile.hFlip, tile.vFlip, tile.tileIndex)
        }
        tilemapRun.replaceData(runData, history.currentChange)
    }
    private lateinit var toolStrategy: IImageToolStrategy
    private lateinit var eyeDropperStrategy: EyeDropperTool
    private lateinit var panStrategy: PanTool
    private var _selectedTool: ImageEditorTools = ImageEditorTools.Pan
    var selectedTool: ImageEditorTools
        get() { /*@DONE ImageEditorViewModel.SelectedTool.get cs:368-368*/
            return _selectedTool
        }
        set(value) { /*@DONE ImageEditorViewModel.SelectedTool.set cs:369-380*/
            if (tryUpdate(_selectedTool, value, "selectedTool") { _selectedTool = it }) {
                toolStrategy = when (_selectedTool) {
                    ImageEditorTools.Draw -> DrawTool(this)
                    ImageEditorTools.Select -> SelectionTool(this)
                    ImageEditorTools.Pan -> panStrategy
                    ImageEditorTools.Fill -> FillTool(this)
                    ImageEditorTools.EyeDropper -> eyeDropperStrategy
                    ImageEditorTools.TilePalette -> TilePaletteTool(this)
                }
                raiseRefreshSelection()
            }
        }
    private var _selectTool: StubCommand? = null
    private var _selectColor: StubCommand? = null
    private var _zoomInCommand: StubCommand? = null
    private var _zoomOutCommand: StubCommand? = null
    private var _deleteCommand: StubCommand? = null
    private var _selectTilePaletteMode: StubCommand? = null
    val selectTool: ICommand
        get() { /*@DONE ImageEditorViewModel.SelectTool.get cs:383-389*/
            return _selectTool ?: argCommand({ param ->
                val arg = toolFromArg(param)
                if (arg != null) {
                    var allowed = true
                    if (arg == ImageEditorTools.TilePalette) {
                        val spriteAddress = model.readPointer(spritePointer)
                        if (model.getNextRun(spriteAddress) !is ITilemapRun) allowed = false
                    }
                    if (allowed) selectedTool = arg
                }
            }).also { _selectTool = it }
        }
    val selectColor: ICommand
        get() { /*@DONE ImageEditorViewModel.SelectColor.get cs:390-390*/
            return _selectColor ?: argCommand({ param ->
                val index = intFromArg(param)
                if (index != null) palette.selectionStart = index
            }).also { _selectColor = it }
        }
    val selectTilePaletteMode: ICommand
        get() { /*@DONE ImageEditorViewModel.SelectTilePaletteMode.get cs:391-391*/
            return _selectTilePaletteMode ?: argCommand({ param ->
                val mode = tilePaletteModeFromArg(param)
                if (mode != null) tilePaletteMode = mode
            }).also { _selectTilePaletteMode = it }
        }
    val zoomInCommand: ICommand
        get() { /*@DONE ImageEditorViewModel.ZoomInCommand.get cs:392-392*/
            return _zoomInCommand ?: stubCommand({ zoomIn(0, 0) }).also { _zoomInCommand = it }
        }
    val zoomOutCommand: ICommand
        get() { /*@DONE ImageEditorViewModel.ZoomOutCommand.get cs:393-393*/
            return _zoomOutCommand ?: stubCommand({ zoomOut(0, 0) }).also { _zoomOutCommand = it }
        }
    val deleteCommand: ICommand
        get() { /*@DONE ImageEditorViewModel.DeleteCommand.get cs:394-394*/
            return _deleteCommand ?: stubCommand({ deleteSelection() }, {
                val selector = toolStrategy
                selector is SelectionTool && selector.hasSelection
            }).also { _deleteCommand = it }
        }
    lateinit var blockPreview: BlockPreview
        private set
    val refreshSelection = Event<EventArgs>()
    private fun raiseRefreshSelection(vararg toSelect: Point) { /*@DONE ImageEditorViewModel.RaiseRefreshSelection/1 cs:401-408*/
        selectionSize = Point.zero
        selectedPixels = Array(pixelWidth) { BooleanArray(pixelHeight) }
        for (s in toSelect) {
            if (withinImage(s)) selectedPixels[s.x][s.y] = true
        }
        refreshSelection(this, EventArgs.empty)
    }
    private var _xOffset: Int = 0
    private var _yOffset: Int = 0
    private var width: Int = 0
    private var height: Int = 0
    var xOffset: Int
        get() { /*@DONE ImageEditorViewModel.XOffset.get cs:411-411*/
            return _xOffset
        }
        private set(value) { /*@DONE ImageEditorViewModel.XOffset.set cs:411-411*/
            tryUpdate(_xOffset, value, "xOffset") { _xOffset = it }
        }
    var yOffset: Int
        get() { /*@DONE ImageEditorViewModel.YOffset.get cs:412-412*/
            return _yOffset
        }
        private set(value) { /*@DONE ImageEditorViewModel.YOffset.set cs:412-412*/
            tryUpdate(_yOffset, value, "yOffset") { _yOffset = it }
        }
    override val transparent: Short
        get() { /*@DONE ImageEditorViewModel.Transparent.get cs:413-413*/
            return (-1).toShort()
        }
    override var pixelWidth: Int
        get() { /*@DONE ImageEditorViewModel.PixelWidth.get cs:414-414*/
            return width
        }
        set(value) { /*@DONE ImageEditorViewModel.PixelWidth.set cs:414-414*/
            set(width, value, "pixelWidth", { width = it }) { raiseRefreshSelection() }
        }
    override var pixelHeight: Int
        get() { /*@DONE ImageEditorViewModel.PixelHeight.get cs:415-415*/
            return height
        }
        set(value) { /*@DONE ImageEditorViewModel.PixelHeight.set cs:415-415*/
            set(height, value, "pixelHeight", { height = it }) { raiseRefreshSelection() }
        }
    override var pixelData: ShortArray = ShortArray(0)
    private var _spriteScale: Double = /*@INITAUTO ImageEditorViewModel.spriteScale cs:419-419*/ 4.0 /*@ENDINIT*/
    override var spriteScale: Double
        get() { /*@DONE ImageEditorViewModel.SpriteScale.get cs:420-420*/
            return _spriteScale
        }
        set(value) { /*@DONE ImageEditorViewModel.SpriteScale.set cs:420-420*/
            set(_spriteScale, value, "spriteScale", { _spriteScale = it }) { notifyPropertyChanged("fontSize") }
        }
    private var _quickInfo: String = /*@INITAUTO ImageEditorViewModel.quickInfo cs:422-422*/ "" /*@ENDINIT*/
    var quickInfo: String
        get() { /*@DONE ImageEditorViewModel.QuickInfo.get cs:423-423*/
            return _quickInfo
        }
        set(value) { /*@DONE ImageEditorViewModel.QuickInfo.set cs:423-423*/
            tryUpdate(_quickInfo, value, "quickInfo") { _quickInfo = it }
        }
    var selectionSize: Point = Point()
        private set
    lateinit var palette: PaletteCollection
        private set
    var spritePointer: Int = 0
        private set
    var palettePointer: Int = 0
        private set
    private var _setCursorSize: StubCommand? = null
    val setCursorSize: ICommand
        get() { /*@DONE ImageEditorViewModel.SetCursorSize.get cs:432-432*/
            return _setCursorSize ?: argCommand({ param ->
                val size = intFromArg(param)
                if (size != null) cursorSize = size
            }).also { _setCursorSize = it }
        }
    private var _cursorSize: Int = /*@INITAUTO ImageEditorViewModel.cursorSize cs:433-433*/ 1 /*@ENDINIT*/
    var cursorSize: Int
        get() { /*@DONE ImageEditorViewModel.CursorSize.get cs:434-434*/
            return _cursorSize
        }
        set(value) { /*@DONE ImageEditorViewModel.CursorSize.set cs:434-434*/
            set(_cursorSize, value, "cursorSize", { _cursorSize = it }) { blockPreview.clear() }
        }
    var canEditTilesetWidth: Boolean = false
        private set
    var minimumTilesetWidth: Int = 0
        private set
    var maximumTilesetWidth: Int = 0
        private set
    private var _currentTilesetWidth: Int = 0
    var currentTilesetWidth: Int
        get() { /*@DONE ImageEditorViewModel.CurrentTilesetWidth.get cs:444-444*/
            return _currentTilesetWidth
        }
        set(value) { /*@DONE ImageEditorViewModel.CurrentTilesetWidth.set cs:445-445*/
            set(_currentTilesetWidth, value, "currentTilesetWidth", { _currentTilesetWidth = it }) { refresh() }
        }
    private fun setupTilesetWidthControl() { /*@DONE ImageEditorViewModel.SetupTilesetWidthControl/1 cs:448-462*/
        val tileset = model.getNextRun(model.readPointer(spritePointer)) as? LzTilesetRun
        if (tileset == null) {
            canEditTilesetWidth = false
            return
        }

        canEditTilesetWidth = true
        val defaultTileWidth = tileset.width
        if (defaultTileWidth > 1) {
            minimumTilesetWidth = 2
            maximumTilesetWidth = defaultTileWidth * tileset.height / 2
            if (currentTilesetWidth == 0) set(_currentTilesetWidth, defaultTileWidth, "currentTilesetWidth", { _currentTilesetWidth = it })
        }
    }
    constructor(history: ChangeHistory<ModelDelta>, model: IDataModel, address: Int, save: ICommand? = null, toolPaletteAddress: Int = -1) { /*@DONE ImageEditorViewModel.<init>/1 cs:466-508*/
        this.history = history
        this.model = model
        fullFileName = ViewPort.buildElementName(model, address)
        if (fullFileName.isBlank()) {
            fullFileName = model.getAnchorFromAddress(-1, address)
        }
        if (fullFileName.isBlank()) {
            fullFileName = "Image " + address.toAddress()
        }
        this.save = save
        val pan = PanTool(this)
        this.panStrategy = pan
        this.toolStrategy = pan
        this.eyeDropperStrategy = EyeDropperTool(this)
        val inputRun = model.getNextRun(address)
        var foundSprite = inputRun as? ISpriteRun
        var palRun = inputRun as? IPaletteRun
        if (foundSprite == null && palRun == null) throw ImageEditorViewModelCreationException("Input ${address.toHex(6)} was not a sprite or palette.")
        if (foundSprite == null) foundSprite = palRun!!.findDependentSprites(model).firstOrNull()
        if (foundSprite == null) throw ImageEditorViewModelCreationException("Could not find sprite for palette ${palRun!!.start.toHex(6)}")
        val spriteRun: ISpriteRun = foundSprite
        if ((spriteRun.pointerSources?.size ?: 0) == 0) throw ImageEditorViewModelCreationException("Could not find pointer to sprite at ${spriteRun.start.toHex(6)}")
        if (palRun == null && spriteRun.spriteFormat.bitsPerPixel > 2) palRun = spriteRun.findRelatedPalettes(model).firstOrNull()
        if (palRun == null && spriteRun.spriteFormat.bitsPerPixel > 2) palRun = model.getNextRun(toolPaletteAddress) as? IPaletteRun
        if (palRun != null && (palRun.pointerSources?.size ?: 0) == 0) throw ImageEditorViewModelCreationException("Could not find pointer to palette at ${palRun.start.toHex(6)}")

        spritePointer = spriteRun.pointerSources!![0]
        palettePointer = palRun?.pointerSources?.get(0) ?: Pointer.null_
        palette = PaletteCollection(this, model, history)
        palette.spriteBitsPerPixel = spriteRun.spriteFormat.bitsPerPixel
        palette.sourcePalettePointer = palettePointer
        palette.bind("hoverIndex") { sender, e -> updateSelectionFromPaletteHover(sender, e) }
        initializeEditOptions()
        refresh()
        selectedPixels = Array(pixelWidth) { BooleanArray(pixelHeight) }
        blockPreview = BlockPreview()
        setupPageOptions()
        palette.selectionSet += { _, _ -> blockPreview.clear() }
        palette.paletteRepointed += { _, newAddress -> raiseMessage("Palette moved to ${newAddress.toHex(6)}. Pointers were updated.") }
        refreshTilePalettes()
        tilePalettes.collectionChanged += { s, e -> pushTilePalettesToModel(s, e) }
        history.undo.canExecuteChanged += { _, e -> undoWrapper?.canExecuteChanged?.invoke(undoWrapper, e) }
        history.redo.canExecuteChanged += { _, e -> redoWrapper?.canExecuteChanged?.invoke(undoWrapper, e) }
    }
    fun readPalette(): ImageEditorViewModelReadPaletteTuple { /*@DONE ImageEditorViewModel.ReadPalette/2 cs:523-526*/
        val sprite = model.getNextRun(model.readPointer(spritePointer)) as? ISpriteRun
        val bits = sprite?.spriteFormat?.bitsPerPixel ?: 4
        return readPalette(model, palettePointer, bits)
    }
    fun readRawPixel(x: Int, y: Int): Int { /*@DONE ImageEditorViewModel.ReadRawPixel/1 cs:528-528*/
        return pixels[x][y]
    }
    fun zoomIn(x: Int, y: Int) { /*@DONE ImageEditorViewModel.ZoomIn/1 cs:531-531*/
        zoomIn(Point(x, y))
    }
    fun zoomOut(x: Int, y: Int) { /*@DONE ImageEditorViewModel.ZoomOut/1 cs:532-532*/
        zoomOut(Point(x, y))
    }
    fun toolDown(x: Int, y: Int) { /*@DONE ImageEditorViewModel.ToolDown/1 cs:533-533*/
        toolDown(Point(x, y))
    }
    fun hover(x: Int, y: Int) { /*@DONE ImageEditorViewModel.Hover/1 cs:534-534*/
        hover(Point(x, y))
    }
    fun toolUp(x: Int, y: Int) { /*@DONE ImageEditorViewModel.ToolUp/1 cs:535-535*/
        toolUp(Point(x, y))
    }
    fun eyeDropperDown(x: Int, y: Int) { /*@DONE ImageEditorViewModel.EyeDropperDown/1 cs:536-536*/
        eyeDropperDown(Point(x, y))
    }
    fun eyeDropperUp(x: Int, y: Int) { /*@DONE ImageEditorViewModel.EyeDropperUp/1 cs:537-537*/
        eyeDropperUp(Point(x, y))
    }
    fun panDown(x: Int, y: Int) { /*@DONE ImageEditorViewModel.PanDown/1 cs:538-538*/
        panDown(Point(x, y))
    }
    fun panUp(x: Int, y: Int) { /*@DONE ImageEditorViewModel.PanUp/1 cs:539-539*/
        panUp(Point(x, y))
    }
    fun showSelectionRect(x: Int, y: Int): Boolean { /*@DONE ImageEditorViewModel.ShowSelectionRect/1 cs:540-540*/
        return showSelectionRect(Point(x, y))
    }
    fun zoomIn(point: Point) { /*@DONE ImageEditorViewModel.ZoomIn/2 cs:542-559*/
        if (spriteScale > maxZoom - 1) return
        val x = point.x
        val y = point.y
        _xOffset -= x
        _yOffset -= y
        val xPartial = _xOffset / spriteScale
        val yPartial = _yOffset / spriteScale
        spriteScale += 1
        val xRange = (pixelWidth * spriteScale / 2).toInt()
        val yRange = (pixelHeight * spriteScale / 2).toInt()
        _xOffset = (xPartial * spriteScale).toInt() + x
        _yOffset = (yPartial * spriteScale).toInt() + y
        _xOffset = _xOffset.limitToRange(-xRange, xRange)
        _yOffset = _yOffset.limitToRange(-yRange, yRange)
        notifyPropertyChanged("xOffset")
        notifyPropertyChanged("yOffset")
    }
    fun zoomOut(point: Point) { /*@DONE ImageEditorViewModel.ZoomOut/2 cs:561-573*/
        if (spriteScale < 2) return
        val x = point.x
        val y = point.y
        _xOffset -= x
        _yOffset -= y
        val xPartial = _xOffset / spriteScale
        val yPartial = _yOffset / spriteScale
        spriteScale -= 1
        val xRange = (pixelWidth * spriteScale / 2).toInt()
        val yRange = (pixelHeight * spriteScale / 2).toInt()
        xOffset = ((xPartial * spriteScale).toInt() + x).limitToRange(-xRange, xRange)
        yOffset = ((yPartial * spriteScale).toInt() + y).limitToRange(-yRange, yRange)
    }
    fun deleteSelection() { /*@DONE ImageEditorViewModel.DeleteSelection/1 cs:575-583*/
        val selector = toolStrategy as? SelectionTool ?: return
        if (!selector.hasSelection) return
        selector.swapUnderPixelsWithCurrentPixels()
        selector.clearSelection()
        SelectionTool.raiseRefreshSelection(this, Point(), 0, 0)
        updateSpriteModel()
        notifyPropertyChanged("pixelData")
    }
    fun toolDown(point: Point, altBehavior: Boolean = false) { /*@DONE ImageEditorViewModel.ToolDown/2 cs:585-590*/
        history.changeCompleted()
        withinInteraction = true
        interactionStart = point
        toolStrategy.toolDown(point, altBehavior)
    }
    fun hover(point: Point) { /*@DONE ImageEditorViewModel.Hover/2 cs:592-613*/
        if (!withinInteraction) {
            interactionStart = point
            toolStrategy.toolHover(point)
        } else if (withinDropperInteraction) {
            eyeDropperStrategy.toolDrag(point)
        } else if (withinPanInteraction) {
            panStrategy.toolDrag(point)
        } else {
            toolStrategy.toolDrag(point)
        }

        quickInfo = ""
        val spritePoint = toSpriteSpace(point)
        if (!spritePoint.x.inRange(0, pixelWidth)) return
        if (!spritePoint.y.inRange(0, pixelHeight)) return
        var text = spritePoint.toString()
        if (selectionSize.x > 1 || selectionSize.y > 1) {
            text = "[$selectionSize]"
        }
        quickInfo = text
    }
    fun toolUp(point: Point) { /*@DONE ImageEditorViewModel.ToolUp/2 cs:615-621*/
        toolStrategy.toolUp(point)
        withinInteraction = false
        history.changeCompleted()
        undoWrapper?.raiseCanExecuteChanged()
        if (hasMultipleEditOptions) editOptions[selectedEditOption].refresh()
    }
    fun eyeDropperDown(point: Point) { /*@DONE ImageEditorViewModel.EyeDropperDown/2 cs:623-627*/
        withinDropperInteraction = true
        withinInteraction = true
        interactionStart = point
        eyeDropperStrategy.toolDown(point, false)
    }
    fun eyeDropperUp(point: Point) { /*@DONE ImageEditorViewModel.EyeDropperUp/2 cs:629-632*/
        eyeDropperStrategy.toolUp(point)
        withinDropperInteraction = false
        withinInteraction = false
    }
    fun panDown(point: Point) { /*@DONE ImageEditorViewModel.PanDown/2 cs:634-638*/
        withinPanInteraction = true
        withinInteraction = true
        interactionStart = point
        panStrategy.toolDown(point, false)
    }
    fun panUp(point: Point) { /*@DONE ImageEditorViewModel.PanUp/2 cs:640-643*/
        panStrategy.toolUp(point)
        withinPanInteraction = false
        withinInteraction = false
    }
    fun showSelectionRect(spriteSpace: Point): Boolean { /*@DONE ImageEditorViewModel.ShowSelectionRect/2 cs:645-649*/
        if (spriteSpace.x < 0 || spriteSpace.x >= pixelWidth || spriteSpace.y < 0 || spriteSpace.y >= pixelHeight) return false
        if (spriteSpace.x >= selectedPixels.size) return false
        if (spriteSpace.y >= selectedPixels[spriteSpace.x].size) return false
        return selectedPixels[spriteSpace.x][spriteSpace.y]
    }
    override fun refresh() { /*@DONE ImageEditorViewModel.Refresh/1 cs:651-670*/
        val spriteAddress = model.readPointer(spritePointer)
        val spriteRun = model.getNextRun(spriteAddress) as? ISpriteRun
        if (spriteRun == null) {
            // user did something weird like deleting the data or clearing the format in the main tab: the sprite run is no longer valid
            close.execute()
            return
        }
        if (spritePage >= spriteRun.pages) spritePage = spriteRun.pages - 1
        setupTilesetWidthControl()

        // tilemap may have been repointed: recalculate
        if (spriteRun is ITilemapRun) spriteRun.findMatchingTileset(model)

        pixels = (if (spriteRun is LzTilesetRun) spriteRun.getPixelsForWidth(model, spritePage, currentTilesetWidth) else spriteRun.getPixels(model, spritePage, -1)) ?: Array(0) { IntArray(0) }
        render()
        refreshPaletteColors(spriteRun.spriteFormat)
        setupPageOptions()
        refreshTilePalettes()
    }
    override fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean { /*@DONE ImageEditorViewModel.TryImport/1 cs:672-678*/
        if (!file.name.lowercase().endsWith(".png")) return false
        val image = fileSystem.loadImage(file.name)
        fileSystem.copyImage = IFileSystemCopyImageTuple(image.image ?: ShortArray(0), image.width)
        executePaste(fileSystem)
        return true
    }
    fun pixelIndex(x: Int, y: Int): Int { /*@DONE ImageEditorViewModel.PixelIndex/1 cs:680-680*/
        return pixelIndex(Point(x, y))
    }
    fun pixelIndex(spriteSpace: Point): Int { /*@DONE ImageEditorViewModel.PixelIndex/2 cs:681-681*/
        return spriteSpace.y * pixelWidth + spriteSpace.x
    }
    private fun toSpriteSpace(point: Point): Point { /*@DONE ImageEditorViewModel.ToSpriteSpace/1 cs:683-689*/
        val x = Math.floor((point.x - _xOffset) / spriteScale).toInt() + pixelWidth / 2
        val y = Math.floor((point.y - _yOffset) / spriteScale).toInt() + pixelHeight / 2
        return Point(x, y)
    }
    fun fromSpriteSpace(spriteSpace: Point): Point { /*@DONE ImageEditorViewModel.FromSpriteSpace/1 cs:691-697*/
        val x = (spriteSpace.x - pixelWidth / 2) * spriteScale.toInt() + _xOffset
        val y = (spriteSpace.y - pixelHeight / 2) * spriteScale.toInt() + _yOffset
        return Point(x, y)
    }
    private fun refreshPaletteColors(spriteFormat: SpriteFormat) { /*@DONE ImageEditorViewModel.RefreshPaletteColors/1 cs:699-726*/
        val palRun = readPalette()
        palette.sourcePalettePointer = palettePointer
        palette.page = _palettePage
        var colors: List<Short> = palRun.colors
        if (spriteFormat.bitsPerPixel == 4 || (colors.size > 16 && colors.size < 256)) colors = colors.drop(Math.max(0, _palettePage) * 16).take(16)
        palette.setContents(colors)
        palette.hasMultiplePages = palRun.pages > 1
        for (element in palette.elements) {
            element.propertyChanged += { sender, args ->
                val sc = sender as SelectableColor
                when (args.propertyName) {
                    "selected" -> {
                        if (sc.selected && selectedTool != ImageEditorTools.Fill) {
                            selectedTool = ImageEditorTools.Draw
                        }
                        blockPreview.clear()
                        if (cursorSize == 0) cursorSize = 1
                    }
                    "color" -> {
                        palette.page = _palettePage
                        palette.pushColorsToModel() // this causes a Render
                    }
                }
            }
        }
    }
    private fun withinImage(p: Point): Boolean { /*@DONE ImageEditorViewModel.WithinImage/1 cs:728-728*/
        return p.x >= 0 && p.x < pixelWidth && p.y >= 0 && p.y < pixelHeight
    }
    private fun render() { /*@DONE ImageEditorViewModel.Render/1 cs:730-746*/
        val spriteAddress = model.readPointer(spritePointer)
        val spriteRun = model.getNextRun(spriteAddress) as ISpriteRun
        val readPixels = (if (spriteRun is LzTilesetRun) spriteRun.getPixelsForWidth(model, spritePage, currentTilesetWidth) else spriteRun.getPixels(model, spritePage, -1)) ?: return

        val palRun = readPalette()

        pixelWidth = readPixels.size
        pixelHeight = if (readPixels.isEmpty()) 0 else readPixels[0].size
        if (_palettePage >= palRun.pages) palettePage = palRun.pages - 1
        var renderPage = _palettePage
        if (spriteRun.spriteFormat.bitsPerPixel == 8 || spriteRun is ITilemapRun) renderPage = 0
        pixelData = SpriteTool.render(pixels, palRun.colors, palRun.initialBlankPages, renderPage)
        notifyPropertyChanged("pixelData")

        if (hasMultipleEditOptions) editOptions[selectedEditOption].refresh()
    }
    private fun updateSpriteModel() { /*@DONE ImageEditorViewModel.UpdateSpriteModel/1 cs:748-757*/
        val spriteAddress = model.readPointer(spritePointer)
        val spriteRun = model.getNextRun(spriteAddress) as ISpriteRun

        // tilemap may have been repointed: recalculate
        if (spriteRun is ITilemapRun) spriteRun.findMatchingTileset(model)

        val newRun = spriteRun.setPixels(model, history.currentChange, spritePage, pixels)
        if (newRun.start != spriteRun.start) raiseMessage("Sprite was moved to " + newRun.start.toAddress() + ".")
    }
    private fun colorIndex(paletteIndex: Int, page: Int = Int.MIN_VALUE, palette: PaletteCache? = null): Int { /*@DONE ImageEditorViewModel.ColorIndex/1 cs:764-773*/
        val cache = palette ?: PaletteCache(this)
        val spriteAddress = model.readPointer(spritePointer)
        val spriteRun = model.getNextRun(spriteAddress) as ISpriteRun
        if (spriteRun is ITilesetRun) return paletteIndex
        val currentPage = if (page == Int.MIN_VALUE) palettePage else page
        val blankPages = cache.initialBlankPages
        val pageOffset = (blankPages + currentPage) shl 4
        return paletteIndex + pageOffset
    }
    private fun paletteIndex(colorIndex: Int, page: Int = Int.MIN_VALUE, palette: PaletteCache? = null): Int { /*@DONE ImageEditorViewModel.PaletteIndex/1 cs:779-788*/
        val cache = palette ?: PaletteCache(this)
        val spriteAddress = model.readPointer(spritePointer)
        val spriteRun = model.getNextRun(spriteAddress) as ISpriteRun
        if (spriteRun is ITilesetRun) return colorIndex
        val currentPage = if (page == Int.MIN_VALUE) palettePage else page
        val blankPages = cache.initialBlankPages
        val pageOffset = (blankPages + currentPage) shl 4
        return colorIndex - pageOffset
    }
    private fun updateSelectionFromPaletteHover(sender: PaletteCollection, e: PropertyChangedEventArgs) { /*@DONE ImageEditorViewModel.UpdateSelectionFromPaletteHover/1 cs:790-804*/
        if (spartanMode) return
        var paletteStart = readPalette().initialBlankPages * 16
        paletteStart += palettePage * 16
        val matches = ArrayList<Point>()
        if (this.palette.hoverIndex >= 0) {
            for (x in 0 until pixelWidth) {
                for (y in 0 until pixelHeight) {
                    if (pixels[x][y] != this.palette.hoverIndex + paletteStart) continue
                    matches.add(Point(x, y))
                }
            }
        }
        raiseRefreshSelection(*matches.toTypedArray())
    }
    private fun spriteOnlyExpects16Colors(): Boolean { /*@DONE ImageEditorViewModel.SpriteOnlyExpects16Colors/1 cs:806-814*/
        val spriteAddress = model.readPointer(spritePointer)
        val run = model.getNextRun(spriteAddress)
        if (run !is ISpriteRun) return false
        if (run is ITilesetRun && run.tilesetFormat.bitsPerPixel == 4) return true
        if (run is ITilemapRun) return false
        if (run.spriteFormat.bitsPerPixel < 8 && run.pages == 1) return true
        return false
    }
    private interface IImageToolStrategy { // cs:818-823
        fun toolDown(screenPosition: Point, altBehavior: Boolean)
        fun toolHover(screenPosition: Point)
        fun toolDrag(screenPosition: Point)
        fun toolUp(screenPosition: Point)
        /*@END ImageEditorViewModel.IImageToolStrategy*/
    }
    private open class DrawTool : IImageToolStrategy { // cs:825-932
        private lateinit var parent: ImageEditorViewModel
        private var drawPoint: Point = Point()
        private var drawWidth: Int = 0
        private var drawHeight: Int = 0
        constructor(parent: ImageEditorViewModel) { /*@DONE ImageEditorViewModel.DrawTool.<init>/1 cs:831-831*/
            this.parent = parent
        }
        override fun toolDown(point: Point, altBehavior: Boolean) { /*@DONE ImageEditorViewModel.DrawTool.ToolDown/1 cs:833-835*/
            toolDrag(point)
        }
        override fun toolDrag(point: Point) { /*@DONE ImageEditorViewModel.DrawTool.ToolDrag/1 cs:837-893*/
            val element = parent.palette.elements.firstOrNull { sc -> sc.selected } ?: parent.palette.elements[0]
            val spritePoint = parent.toSpriteSpace(point)

            var validHoverLocation = parent.withinImage(spritePoint)
            val spriteOnlyExpects16Colors = parent.spriteOnlyExpects16Colors()
            if (validHoverLocation) {
                val initialBlankPages = parent.readPalette().initialBlankPages
                if (parent.canEditTilePalettes) {
                    val hoverTilesPalette = parent.tilePalettes[spritePoint.y / 8 * parent.tileWidth + spritePoint.x / 8]
                    validHoverLocation = initialBlankPages + parent.palettePage == hoverTilesPalette
                    validHoverLocation = validHoverLocation && parent.palettePage >= 0
                }
            }

            if (validHoverLocation) {
                val eyeTile = parent.eyeDropperStrategy.tile
                val tile: Array<IntArray>
                if (eyeTile == null || !parent.blockPreview.enabled) {
                    drawWidth = Math.max(parent.cursorSize, 1)
                    drawHeight = drawWidth
                    val newTile = Array(drawWidth) { IntArray(drawHeight) }
                    var colorIndex = parent.colorIndex(element.index)
                    if (spriteOnlyExpects16Colors) colorIndex = element.index
                    for (x in 0 until drawWidth) for (y in 0 until drawHeight) newTile[x][y] = colorIndex
                    tile = newTile
                } else {
                    tile = eyeTile
                    drawWidth = eyeTile.size
                    drawHeight = if (eyeTile.isEmpty()) 0 else eyeTile[0].size
                }

                if (drawWidth < 1 || drawHeight < 1) {
                    raiseRefreshSelection()
                    return
                }

                drawPoint = Point(spritePoint.x - spritePoint.x % drawWidth, spritePoint.y - spritePoint.y % drawHeight)

                // allow editing the selected palette to match the tile if a tile is selected
                var pageChange = Math.floor((parent.paletteIndex(tile[0][0]).toFloat() / parent.palette.elements.size).toDouble()).toInt()
                if (!spriteOnlyExpects16Colors && drawWidth == 8 && drawHeight == 8 && pageChange != 0) {
                    parent.palettePage += pageChange
                    pageChange = 0
                }

                // only draw if the paletteIndex is reasonable
                if (pageChange == 0 || spriteOnlyExpects16Colors) {
                    for (x in 0 until drawWidth) {
                        for (y in 0 until drawHeight) {
                            val xx = drawPoint.x + x
                            val yy = drawPoint.y + y
                            var paletteIndex = parent.paletteIndex(tile[x][y])
                            if (spriteOnlyExpects16Colors) paletteIndex = tile[x][y]
                            if (xx >= parent.pixelWidth || yy >= parent.pixelHeight) continue
                            paletteIndex %= parent.palette.elements.size
                            parent.pixelData[parent.pixelIndex(xx, yy)] = parent.palette.elements[paletteIndex].color
                            parent.pixels[xx][yy] = tile[x][y]
                        }
                    }
                    parent.raiseChanged("pixelData")
                }
            }

            raiseRefreshSelection()
        }
        override fun toolHover(point: Point) { /*@DONE ImageEditorViewModel.DrawTool.ToolHover/1 cs:895-921*/
            val spritePoint = parent.toSpriteSpace(point)
            var validHoverLocation = parent.withinImage(spritePoint)
            if (validHoverLocation) {
                val palRun = if (parent.canEditTilePalettes) parent.model.getNextRun(parent.model.readPointer(parent.palettePointer)) as? IPaletteRun else null
                if (palRun != null) {
                    val hoverTilesPalette = parent.tilePalettes[spritePoint.y / 8 * parent.tileWidth + spritePoint.x / 8]
                    validHoverLocation = parent.cursorSize == 8 || palRun.paletteFormat.initialBlankPages + parent.palettePage == hoverTilesPalette
                }
            }

            if (validHoverLocation) {
                val eyeTile = parent.eyeDropperStrategy.tile
                if (eyeTile == null || !parent.blockPreview.enabled) {
                    drawWidth = Math.max(parent.cursorSize, 1)
                    drawHeight = drawWidth
                } else {
                    drawWidth = eyeTile.size
                    drawHeight = if (eyeTile.isEmpty()) 0 else eyeTile[0].size
                }

                if (drawWidth < 1 || drawHeight < 1) {
                    drawPoint = Point()
                    drawWidth = 0
                    drawHeight = 0
                } else {
                    drawPoint = Point(spritePoint.x - spritePoint.x % drawWidth, spritePoint.y - spritePoint.y % drawHeight)
                }
            } else {
                drawPoint = Point()
                drawWidth = 0
                drawHeight = 0
            }

            raiseRefreshSelection()
        }
        override fun toolUp(screenPosition: Point) { /*@DONE ImageEditorViewModel.DrawTool.ToolUp/1 cs:923-925*/
            parent.updateSpriteModel()
        }
        private fun raiseRefreshSelection() { /*@DONE ImageEditorViewModel.DrawTool.RaiseRefreshSelection/1 cs:927-931*/
            val selectionPoints = Array(drawWidth * drawHeight) { i -> drawPoint + Point(i % drawWidth, i / drawWidth) }
            parent.raiseRefreshSelection(*selectionPoints)
        }
        /*@END ImageEditorViewModel.DrawTool*/
    }
    private open class SelectionTool : IImageToolStrategy { // cs:934-1217
        private lateinit var parent: ImageEditorViewModel
        private var selectionStart: Point = Point()
        private var selectionWidth: Int = 0
        private var selectionHeight: Int = 0
        private var underMask: Array<BooleanArray>? = null
        private var underPixels: Array<IntArray>? = null
        val hasSelection: Boolean
            get() { /*@DONE ImageEditorViewModel.SelectionTool.HasSelection.get cs:942-942*/
                return underPixels != null
            }
        constructor(parent: ImageEditorViewModel) { /*@DONE ImageEditorViewModel.SelectionTool.<init>/1 cs:944-944*/
            this.parent = parent
        }
        override fun toolDown(point: Point, altBehavior: Boolean) { /*@DONE ImageEditorViewModel.SelectionTool.ToolDown/1 cs:946-969*/
            var hoverPoint = parent.toSpriteSpace(point)
            if (hoverPoint.x < 0) hoverPoint = Point(0, hoverPoint.y)
            if (hoverPoint.y < 0) hoverPoint = Point(hoverPoint.x, 0)
            if (hoverPoint.x >= parent.pixelWidth) hoverPoint = Point(parent.pixelWidth - 1, hoverPoint.y)
            if (hoverPoint.y >= parent.pixelHeight) hoverPoint = Point(hoverPoint.x, parent.pixelHeight - 1)
            if (selectionStart.x > hoverPoint.x ||
                selectionStart.y > hoverPoint.y ||
                selectionStart.x + selectionWidth <= hoverPoint.x ||
                selectionStart.y + selectionHeight <= hoverPoint.y
            ) {
                underPixels = null // old selection lost
                selectionStart = hoverPoint
                selectionWidth = 0
                selectionHeight = 0
            } else if (altBehavior) {
                // copy the parent pixels to the under-pixels
                val under = underPixels
                if (under != null) {
                    for (x in 0 until selectionWidth) {
                        for (y in 0 until selectionHeight) {
                            val xx = selectionStart.x + x
                            val yy = selectionStart.y + y
                            under[x][y] = parent.pixels[xx][yy]
                        }
                    }
                }
            }
        }
        override fun toolDrag(point: Point) { /*@DONE ImageEditorViewModel.SelectionTool.ToolDrag/1 cs:971-1011*/
            if (underPixels != null) {
                val previousPoint = parent.toSpriteSpace(parent.interactionStart)
                val currentPoint = parent.toSpriteSpace(point)
                if (previousPoint == currentPoint) return
                val palRun = parent.readPalette()
                val maxReasonablePage = palRun.pages + palRun.initialBlankPages
                var delta = currentPoint - previousPoint
                var minX = -selectionStart.x
                var minY = -selectionStart.y
                var maxX = parent.pixelWidth - selectionWidth - selectionStart.x
                var maxY = parent.pixelHeight - selectionHeight - selectionStart.y
                if (minX > maxX) { val t = minX; minX = maxX; maxX = t }
                if (minY > maxY) { val t = minY; minY = maxY; maxY = t }
                delta = Point(delta.x.limitToRange(minX, maxX), delta.y.limitToRange(minY, maxY))

                if (parent.canEditTilePalettes) {
                    var x = 0
                    while (x < selectionWidth) {
                        val tileX = (selectionStart.x + delta.x + x) / 8
                        var y = 0
                        while (y < selectionHeight) {
                            val tileY = (selectionStart.y + delta.y + y) / 8
                            val currentPalette = parent.tilePalettes[tileY * parent.tileWidth + tileX]
                            if (currentPalette >= maxReasonablePage) return
                            y += 8
                        }
                        x += 8
                    }
                }

                swapUnderPixelsWithCurrentPixels()
                selectionStart = selectionStart + delta
                swapUnderPixelsWithCurrentPixels()
                parent.raiseChanged("pixelData")

                parent.interactionStart = point
            } else {
                val spritePoint = parent.toSpriteSpace(point)
                if (parent.withinImage(spritePoint)) {
                    selectionWidth = spritePoint.x - selectionStart.x
                    selectionHeight = spritePoint.y - selectionStart.y
                }
            }

            raiseRefreshSelection()
        }
        override fun toolHover(screenPosition: Point) { /*@DONE ImageEditorViewModel.SelectionTool.ToolHover/1 cs:1013-1013*/
            // nothing to do while hovering with the selection tool
        }
        override fun toolUp(point: Point) { /*@DONE ImageEditorViewModel.SelectionTool.ToolUp/1 cs:1015-1039*/
            val cache = PaletteCache(parent)
            if (underPixels != null) {
                parent.updateSpriteModel()
            } else {
                val rect = buildRect(selectionStart, selectionWidth, selectionHeight, 1)
                selectionStart = rect.point
                selectionWidth = rect.width
                selectionHeight = rect.height
                if (selectionWidth > 1 || selectionHeight > 1) {
                    val under = Array(selectionWidth) { IntArray(selectionHeight) }
                    val mask = Array(selectionWidth) { BooleanArray(selectionHeight) }
                    // copy the mask
                    for (x in 0 until selectionWidth) {
                        for (y in 0 until selectionHeight) {
                            val xx = selectionStart.x + x
                            val yy = selectionStart.y + y
                            mask[x][y] = parent.pixels[xx][yy] != cache.initialBlankPages * 16
                        }
                    }
                    underPixels = under
                    underMask = mask
                } else {
                    selectionWidth = 0
                    selectionHeight = 0
                }
                parent.flipHorizontalCommand?.raiseCanExecuteChanged()
                parent.flipVerticalCommand?.raiseCanExecuteChanged()
            }

            SelectionTool.raiseRefreshSelection(parent, selectionStart, selectionWidth, selectionHeight)
        }
        fun clearSelection() { /*@DONE ImageEditorViewModel.SelectionTool.ClearSelection/1 cs:1069-1073*/
            underPixels = null
            underMask = null
            selectionWidth = 0
            selectionHeight = 0
        }
        fun copy(fs: IFileSystem) { /*@DONE ImageEditorViewModel.SelectionTool.Copy/1 cs:1075-1089*/
            if (underPixels == null) return
            val result = ShortArray(selectionWidth * selectionHeight)
            for (x in 0 until selectionWidth) {
                for (y in 0 until selectionHeight) {
                    val index = parent.pixelIndex(selectionStart + Point(x, y))
                    result[y * selectionWidth + x] = parent.pixelData[index]
                }
            }
            try {
                fs.copyImage = IFileSystemCopyImageTuple(result, selectionWidth)
            } catch (e: Exception) {
                parent.raiseError("Failed to copy image.")
            }
        }
        private fun raiseRefreshSelection() { /*@DONE ImageEditorViewModel.SelectionTool.RaiseRefreshSelection/2 cs:1091-1099*/
            var start = selectionStart
            var width = selectionWidth
            var height = selectionHeight

            if (parent.withinInteraction && underPixels == null) {
                val rect = buildRect(selectionStart, selectionWidth, selectionHeight, 1)
                start = rect.point
                width = rect.width
                height = rect.height
            }

            SelectionTool.raiseRefreshSelection(parent, start, width, height)
        }
        fun swapUnderPixelsWithCurrentPixels() { /*@DONE ImageEditorViewModel.SelectionTool.SwapUnderPixelsWithCurrentPixels/1 cs:1101-1137*/
            val under = underPixels ?: return
            val mask = underMask ?: return
            val cache = PaletteCache(parent)
            val fullPalette = cache.colors
            val pageOffset = cache.initialBlankPages
            val spriteOnlyExpects16Colors = parent.spriteOnlyExpects16Colors()

            for (x in 0 until selectionWidth) {
                for (y in 0 until selectionHeight) {
                    if (!mask[x][y]) continue
                    val xx = selectionStart.x + x
                    val yy = selectionStart.y + y

                    var page = 0
                    if (parent.canEditTilePalettes) {
                        val pX = xx / 8
                        val pY = yy / 8
                        page = parent.tilePalettes[pY * parent.tileWidth + pX] - pageOffset
                    }

                    var newUnder = parent.paletteIndex(parent.pixels[xx][yy], page, cache)
                    var newOver = parent.colorIndex(under[x][y], page, cache)
                    var index = Math.max(0, newOver - pageOffset * 16)
                    if (spriteOnlyExpects16Colors) {
                        // tilesets don't have palette information
                        newUnder = parent.pixels[xx][yy]
                        newOver = under[x][y]
                        index = newOver
                    }

                    under[x][y] = newUnder
                    parent.pixels[xx][yy] = newOver

                    if (index < fullPalette.size) {
                        var color = fullPalette[index]
                        if (spriteOnlyExpects16Colors && (parent.palettePage * 16 + index).inRange(0, fullPalette.size)) color = fullPalette[index + parent.palettePage * 16]
                        parent.pixelData[parent.pixelIndex(xx, yy)] = color
                    }
                }
            }
        }
        fun flipVertical() { /*@DONE ImageEditorViewModel.SelectionTool.FlipVertical/1 cs:1139-1162*/
            val cache = cachePixels()
            val paletteRun = readPalette()
            val pageOffset = paletteRun?.paletteFormat?.initialBlankPages ?: 0
            var inputPage = 0
            var outputPage = 0

            for (x in 0 until selectionWidth) {
                for (y in 0 until selectionHeight) {
                    if (parent.canEditTilePalettes) {
                        var pX = (selectionStart.x + x) / 8
                        var pY = (selectionStart.y + selectionHeight - y - 1) / 8
                        inputPage = parent.tilePalettes[pY * parent.tileWidth + pX] - pageOffset
                        pX = (selectionStart.x + x) / 8
                        pY = (selectionStart.y + y) / 8
                        outputPage = parent.tilePalettes[pY * parent.tileWidth + pX] - pageOffset
                    }

                    val index = parent.paletteIndex(cache[x][selectionHeight - y - 1], inputPage)
                    parent.pixels[selectionStart.x + x][selectionStart.y + y] = parent.colorIndex(index, outputPage)
                    val under = underPixels
                    val mask = underMask
                    if (under != null && mask != null && y <= selectionHeight / 2 - 1) {
                        val tp = under[x][y]
                        under[x][y] = under[x][selectionHeight - y - 1]
                        under[x][selectionHeight - y - 1] = tp
                        val tm = mask[x][y]
                        mask[x][y] = mask[x][selectionHeight - y - 1]
                        mask[x][selectionHeight - y - 1] = tm
                    }
                }
            }
        }
        fun flipHorizontal() { /*@DONE ImageEditorViewModel.SelectionTool.FlipHorizontal/1 cs:1164-1187*/
            val cache = cachePixels()
            val paletteRun = readPalette()
            val pageOffset = paletteRun?.paletteFormat?.initialBlankPages ?: 0
            var inputPage = 0
            var outputPage = 0

            for (x in 0 until selectionWidth) {
                for (y in 0 until selectionHeight) {
                    if (parent.canEditTilePalettes) {
                        var pX = (selectionStart.x + selectionWidth - x - 1) / 8
                        var pY = (selectionStart.y + y) / 8
                        inputPage = parent.tilePalettes[pY * parent.tileWidth + pX] - pageOffset
                        pX = (selectionStart.x + x) / 8
                        pY = (selectionStart.y + y) / 8
                        outputPage = parent.tilePalettes[pY * parent.tileWidth + pX] - pageOffset
                    }

                    val index = parent.paletteIndex(cache[selectionWidth - x - 1][y], inputPage)
                    parent.pixels[selectionStart.x + x][selectionStart.y + y] = parent.colorIndex(index, outputPage)
                    val under = underPixels
                    val mask = underMask
                    if (under != null && mask != null && x <= selectionWidth / 2 - 1) {
                        val tp = under[x][y]
                        under[x][y] = under[selectionWidth - x - 1][y]
                        under[selectionWidth - x - 1][y] = tp
                        val tm = mask[x][y]
                        mask[x][y] = mask[selectionWidth - x - 1][y]
                        mask[selectionWidth - x - 1][y] = tm
                    }
                }
            }
        }
        private fun readPalette(): IPaletteRun? { /*@DONE ImageEditorViewModel.SelectionTool.ReadPalette/1 cs:1189-1193*/
            if (parent.palettePointer == Pointer.null_) return null
            val destination = parent.model.readPointer(parent.palettePointer)
            return parent.model.getNextRun(destination) as? IPaletteRun
        }
        fun setUnderPixels(values: Array<IntArray>) { /*@DONE ImageEditorViewModel.SelectionTool.SetUnderPixels/1 cs:1195-1206*/
            if (underPixels == null) return
            underPixels = values
            val cache = PaletteCache(parent)
            val mask = underMask ?: Array(values.size) { i -> BooleanArray(values[i].size) }
            underMask = mask
            for (x in values.indices) {
                for (y in values[x].indices) {
                    if (x < mask.size && y < mask[x].size) mask[x][y] = values[x][y] != cache.initialBlankPages * 16
                }
            }
        }
        private fun cachePixels(): Array<IntArray> { /*@DONE ImageEditorViewModel.SelectionTool.CachePixels/1 cs:1208-1216*/
            val cache = Array(Math.max(selectionWidth, 0)) { IntArray(Math.max(selectionHeight, 0)) }
            for (x in cache.indices) {
                for (y in cache[x].indices) {
                    cache[x][y] = parent.pixels[selectionStart.x + x][selectionStart.y + y]
                }
            }
            return cache
        }
        companion object {
            fun buildRect(start: Point, dragX: Int, dragY: Int, gridSize: Int): ImageEditorViewModelSelectionToolBuildRectTuple { /*@DONE ImageEditorViewModel.SelectionTool.BuildRect/1 cs:1041-1060*/
                var s = start
                var dx = dragX
                var dy = dragY
                val grid = Math.max(gridSize, 1)
                if (dx < 0) {
                    s = s + Point(dx, 0)
                    dx = -dx
                }
                if (dy < 0) {
                    s = s + Point(0, dy)
                    dy = -dy
                }
                dx += 1
                dy += 1

                dx += s.x % grid
                dy += s.y % grid
                s = s - Point(s.x % grid, s.y % grid)
                if (dx % grid != 0) dx += grid - dx % grid
                if (dy % grid != 0) dy += grid - dy % grid

                return ImageEditorViewModelSelectionToolBuildRectTuple(s, dx, dy)
            }
            fun raiseRefreshSelection(parent: ImageEditorViewModel, start: Point, width: Int, height: Int) { /*@DONE ImageEditorViewModel.SelectionTool.RaiseRefreshSelection/1 cs:1062-1067*/
                val count = if (width > 0 && height > 0) width * height else 0
                val selectionPoints = Array(count) { i -> start + Point(i % width, i / width) }
                parent.raiseRefreshSelection(*selectionPoints)
                parent.selectionSize = Point(width, height)
            }
            /*@END ImageEditorViewModel.SelectionTool.Companion*/
        }
        /*@END ImageEditorViewModel.SelectionTool*/
    }
    private open class PanTool : IImageToolStrategy { // cs:1219-1240
        private lateinit var parent: ImageEditorViewModel
        constructor(parent: ImageEditorViewModel) { /*@DONE ImageEditorViewModel.PanTool.<init>/1 cs:1221-1221*/
            this.parent = parent
        }
        override fun toolDown(screenPosition: Point, altBehavior: Boolean) { /*@DONE ImageEditorViewModel.PanTool.ToolDown/1 cs:1223-1223*/
            // panning starts on the first drag
        }
        override fun toolDrag(point: Point) { /*@DONE ImageEditorViewModel.PanTool.ToolDrag/1 cs:1225-1233*/
            val xRange = (parent.pixelWidth * parent.spriteScale / 2).toInt()
            val yRange = (parent.pixelHeight * parent.spriteScale / 2).toInt()
            val originalX = parent._xOffset
            val originalY = parent._yOffset
            parent.xOffset = (parent.xOffset + point.x - parent.interactionStart.x).limitToRange(-xRange, xRange)
            parent.yOffset = (parent.yOffset + point.y - parent.interactionStart.y).limitToRange(-yRange, yRange)
            parent.interactionStart = Point(parent.interactionStart.x + parent.xOffset - originalX, parent.interactionStart.y + parent.yOffset - originalY)
        }
        override fun toolHover(screenPosition: Point) { /*@DONE ImageEditorViewModel.PanTool.ToolHover/1 cs:1235-1235*/
            // nothing to do while hovering with the pan tool
        }
        override fun toolUp(screenPosition: Point) { /*@DONE ImageEditorViewModel.PanTool.ToolUp/1 cs:1237-1237*/
            // nothing to do when releasing the pan tool
        }
        fun showSelectionRect(subPixelPosition: Point): Boolean { /*@DONE ImageEditorViewModel.PanTool.ShowSelectionRect/1 cs:1239-1239*/
            return false
        }
        /*@END ImageEditorViewModel.PanTool*/
    }
    private open class FillTool : IImageToolStrategy { // cs:1242-1334
        private lateinit var parent: ImageEditorViewModel
        constructor(parent: ImageEditorViewModel) { /*@DONE ImageEditorViewModel.FillTool.<init>/1 cs:1245-1245*/
            this.parent = parent
        }
        override fun toolDown(screenPosition: Point, altBehavior: Boolean) { /*@DONE ImageEditorViewModel.FillTool.ToolDown/1 cs:1247-1247*/
            // filling happens on release
        }
        override fun toolDrag(point: Point) { /*@DONE ImageEditorViewModel.FillTool.ToolDrag/1 cs:1249-1256*/
            val spritePoint = parent.toSpriteSpace(point)
            if (parent.withinImage(spritePoint)) {
                parent.raiseRefreshSelection(spritePoint)
            } else {
                parent.raiseRefreshSelection()
            }
        }
        override fun toolHover(point: Point) { /*@DONE ImageEditorViewModel.FillTool.ToolHover/1 cs:1258-1265*/
            val spritePoint = parent.toSpriteSpace(point)
            if (parent.withinImage(spritePoint)) {
                parent.raiseRefreshSelection(spritePoint)
            } else {
                parent.raiseRefreshSelection()
            }
        }
        override fun toolUp(point: Point) { /*@DONE ImageEditorViewModel.FillTool.ToolUp/1 cs:1267-1269*/
            fillSpace(parent.interactionStart, point)
        }
        private fun fillSpace(a: Point, b: Point) { /*@DONE ImageEditorViewModel.FillTool.FillSpace/1 cs:1271-1320*/
            val start = parent.toSpriteSpace(a)
            val end = parent.toSpriteSpace(b)
            if (!parent.withinImage(start) || !parent.withinImage(end)) return
            val paletteInfo = parent.readPalette()
            val originalColorIndex = parent.pixels[start.x][start.y]
            if (parent.canEditTilePalettes) {
                // don't allow fill if the current tile doesn't have the same palette as the current selected palette
                if (originalColorIndex / 16 != paletteInfo.initialBlankPages + parent.palettePage) return
            }
            val selectionStart = parent.palette.selectionStart
            val selectionEnd = parent.palette.selectionEnd
            val direction = kotlin.math.sign((selectionEnd - selectionStart).toDouble()).toInt()
            val targetColors = ArrayList<Int>()
            targetColors.add(selectionStart)
            var i = selectionStart + direction
            while (i != selectionEnd) {
                targetColors.add(i)
                i += direction
            }
            if (selectionEnd != selectionStart) targetColors.add(selectionEnd)
            val targetColorsWithinPalettePage = ArrayList<Int>()
            for (tc in targetColors) targetColorsWithinPalettePage.add(parent.colorIndex(tc))

            val toProcess = kotlin.collections.ArrayDeque<Point>()
            toProcess.addLast(start)
            val processed = HashSet<Point>()
            val spriteOnly16Colors = parent.spriteOnlyExpects16Colors()
            while (toProcess.isNotEmpty()) {
                val current = toProcess.removeFirst()
                if (processed.contains(current)) continue
                processed.add(current)
                if (parent.pixels[current.x][current.y] != originalColorIndex) continue

                val targetColorIndex = pickColorIndex(start, end, current, targetColors)
                var targetColorWithinPalettePageIndex = pickColorIndex(start, end, current, targetColorsWithinPalettePage)
                if (spriteOnly16Colors) targetColorWithinPalettePageIndex = targetColorIndex

                parent.pixels[current.x][current.y] = targetColorWithinPalettePageIndex
                parent.pixelData[parent.pixelIndex(current)] = parent.palette.elements[targetColorIndex].color
                val neighbors = arrayOf(
                    Point(current.x - 1, current.y),
                    Point(current.x + 1, current.y),
                    Point(current.x, current.y - 1),
                    Point(current.x, current.y + 1)
                )
                for (next in neighbors) {
                    if (parent.withinImage(next) && !processed.contains(next)) toProcess.addLast(next)
                }
            }

            parent.updateSpriteModel()
            parent.raiseChanged("pixelData")
        }
        private fun pickColorIndex(a: Point, b: Point, current: Point, options: MutableList<Int>): Int { /*@DONE ImageEditorViewModel.FillTool.PickColorIndex/1 cs:1322-1333*/
            if (a == b) return options[0]

            // a is the center
            // b-a is the radius
            var dx = b.x - a.x
            var dy = b.y - a.y
            val gradientRadius = Math.sqrt((dx * dx + dy * dy).toDouble())
            dx = current.x - a.x
            dy = current.y - a.y
            val pointRadius = Math.sqrt((dx * dx + dy * dy).toDouble())
            val index = Math.rint(pointRadius / gradientRadius * options.size)
            return options[Math.min(index, (options.size - 1).toDouble()).toInt()]
        }
        /*@END ImageEditorViewModel.FillTool*/
    }
    private open class EyeDropperTool : IImageToolStrategy { // cs:1336-1441
        private lateinit var parent: ImageEditorViewModel
        private var selectionStart: Point = Point()
        private var selectionWidth: Int = 0
        private var selectionHeight: Int = 0
        private var underPixels: Array<IntArray>? = null
        val tile: Array<IntArray>?
            get() { /*@DONE ImageEditorViewModel.EyeDropperTool.Tile.get cs:1343-1343*/
                return underPixels
            }
        constructor(parent: ImageEditorViewModel) { /*@DONE ImageEditorViewModel.EyeDropperTool.<init>/1 cs:1345-1345*/
            this.parent = parent
        }
        override fun toolDown(point: Point, altBehavior: Boolean) { /*@DONE ImageEditorViewModel.EyeDropperTool.ToolDown/1 cs:1347-1351*/
            underPixels = null // old selection lost
            selectionStart = parent.toSpriteSpace(point)
            selectionWidth = 0
            selectionHeight = 0
        }
        override fun toolDrag(point: Point) { /*@DONE ImageEditorViewModel.EyeDropperTool.ToolDrag/1 cs:1353-1363*/
            val spritePoint = parent.toSpriteSpace(point)
            if (parent.withinImage(spritePoint) && !parent.canEditTilePalettes) {
                selectionWidth = spritePoint.x - selectionStart.x
                selectionHeight = spritePoint.y - selectionStart.y

                val rect = SelectionTool.buildRect(selectionStart, selectionWidth, selectionHeight, parent.cursorSize)

                SelectionTool.raiseRefreshSelection(parent, rect.point, rect.width, rect.height)
            }
        }
        override fun toolHover(point: Point) { /*@DONE ImageEditorViewModel.EyeDropperTool.ToolHover/1 cs:1365-1368*/
            selectionStart = parent.toSpriteSpace(point)
            raiseRefreshSelection()
        }
        override fun toolUp(point: Point) { /*@DONE ImageEditorViewModel.EyeDropperTool.ToolUp/1 cs:1370-1424*/
            val rect = SelectionTool.buildRect(selectionStart, selectionWidth, selectionHeight, parent.cursorSize)
            val cursorSize = Math.max(parent.cursorSize, 1)

            if (parent.selectedTool == ImageEditorTools.TilePalette) {
                val spritePoint = parent.toSpriteSpace(point)
                val lineNumber = spritePoint.y / 8
                val lineTileWidth = parent.pixelWidth / 8
                val rowNumber = spritePoint.x / 8
                val tileIndex = lineNumber * lineTileWidth + rowNumber
                var desiredPalettePage = parent.tilePalettes[tileIndex]
                val paletteAddress = parent.model.readPointer(parent.palettePointer)
                val tilePalRun = parent.model.getNextRun(paletteAddress) as? IPaletteRun
                if (tilePalRun != null) desiredPalettePage -= tilePalRun.paletteFormat.initialBlankPages
                parent.palettePage = desiredPalettePage
                return
            }

            var initWidth = selectionWidth
            var initHeight = selectionHeight
            selectionStart = rect.point
            selectionWidth = rect.width
            selectionHeight = rect.height
            if (selectionStart.x < 0 || selectionStart.y < 0) return
            if (selectionStart.x + selectionWidth > parent.pixelWidth || selectionStart.y + selectionHeight > parent.pixelHeight) return

            if (initWidth == 0 && initHeight == 0 && parent.selectedTool != ImageEditorTools.Fill) {
                var xx = selectionStart.x
                var yy = selectionStart.y
                xx -= xx % cursorSize
                yy -= yy % cursorSize
                selectionStart = Point(xx, yy)
                selectionWidth = cursorSize
                selectionHeight = cursorSize
                initWidth = cursorSize - 1
                initHeight = cursorSize - 1
            }

            if (initWidth == 0 && initHeight == 0) {
                val spritePoint = parent.toSpriteSpace(point)
                if (!parent.withinImage(spritePoint)) return
                var index = parent.pixels[spritePoint.x][spritePoint.y]
                val palette = parent.readPalette()
                if (parent.palette.canEditColors || palette.pages > 1) {
                    if (palette.colors.size < 256 && !parent.spriteOnlyExpects16Colors()) {
                        index -= palette.initialBlankPages shl 4
                        while (index < 0) index += 16
                        if (parent.spritePages == 1) parent.palettePage = index / 16
                        index %= 16
                    }
                }

                parent.palette.selectionStart = index
                underPixels = null
            } else {
                val under = Array(selectionWidth) { IntArray(selectionHeight) }
                for (x in 0 until selectionWidth) {
                    for (y in 0 until selectionHeight) {
                        under[x][y] = parent.pixels[selectionStart.x + x][selectionStart.y + y]
                    }
                }
                underPixels = under

                parent.blockPreview.set(parent.pixelData, parent.pixelWidth, selectionStart, selectionWidth, selectionHeight)
            }
        }
        private fun makeSquare(width: Ref<Int>, height: Ref<Int>) { /*@DONE ImageEditorViewModel.EyeDropperTool.MakeSquare/1 cs:1426-1431*/
            width.value = Math.min(width.value, height.value)
            val log = if (width.value >= 1) 31 - width.value.countLeadingZeroBits() else 0
            width.value = 1 shl log
            height.value = width.value
        }
        private fun raiseRefreshSelection() { /*@DONE ImageEditorViewModel.EyeDropperTool.RaiseRefreshSelection/1 cs:1433-1440*/
            val size = parent.cursorSize
            if (size < 1) {
                parent.raiseRefreshSelection()
                return
            }
            val xx = selectionStart.x
            val yy = selectionStart.y
            val drawPoint = Point(xx - xx % size, yy - yy % size)
            val selectionPoints = Array(size * size) { i -> drawPoint + Point(i % size, i / size) }
            parent.raiseRefreshSelection(*selectionPoints)
        }
        /*@END ImageEditorViewModel.EyeDropperTool*/
    }
    private open class TilePaletteTool : IImageToolStrategy { // cs:1443-1541
        private lateinit var parent: ImageEditorViewModel
        constructor(parent: ImageEditorViewModel) { /*@DONE ImageEditorViewModel.TilePaletteTool.<init>/1 cs:1446-1446*/
            this.parent = parent
        }
        override fun toolDown(screenPosition: Point, altBehavior: Boolean) { /*@DONE ImageEditorViewModel.TilePaletteTool.ToolDown/1 cs:1448-1452*/
            if (parent.tilePaletteMode == TilePaletteMode.Fill) paint(screenPosition)
            else if (parent.tilePaletteMode == TilePaletteMode.EyeDropper) parent.eyeDropperStrategy.toolDown(screenPosition, altBehavior)
            else toolDrag(screenPosition)
        }
        override fun toolDrag(screenPosition: Point) { /*@DONE ImageEditorViewModel.TilePaletteTool.ToolDrag/1 cs:1454-1478*/
            if (parent.tilePaletteMode == TilePaletteMode.EyeDropper) {
                parent.eyeDropperStrategy.toolDrag(screenPosition)
                return
            }

            val point = parent.toSpriteSpace(screenPosition)
            val rowNumber = point.y / 8
            val colNumber = point.x / 8

            if (parent.withinImage(point)) {
                val lineTileWidth = parent.pixelWidth / 8
                val tileIndex = rowNumber * lineTileWidth + colNumber
                val paletteAddress = parent.model.readPointer(parent.palettePointer)
                var currentSelectedPage = parent.palettePage
                val paletteRun = parent.model.getNextRun(paletteAddress) as? IPaletteRun
                if (paletteRun != null) currentSelectedPage += paletteRun.paletteFormat.initialBlankPages
                val spriteAddress = parent.model.readPointer(parent.spritePointer)
                if (parent.tilePalettes[tileIndex] != currentSelectedPage && parent.model.getNextRun(spriteAddress) is ITilemapRun) {
                    parent.tilePalettes[tileIndex] = currentSelectedPage
                    refresh()
                }
            }

            raiseRefreshSelection(rowNumber, colNumber)
        }
        override fun toolHover(screenPosition: Point) { /*@DONE ImageEditorViewModel.TilePaletteTool.ToolHover/1 cs:1480-1485*/
            val point = parent.toSpriteSpace(screenPosition)
            val rowNumber = point.y / 8
            val colNumber = point.x / 8
            raiseRefreshSelection(rowNumber, colNumber)
        }
        override fun toolUp(screenPosition: Point) { /*@DONE ImageEditorViewModel.TilePaletteTool.ToolUp/1 cs:1487-1489*/
            if (parent.tilePaletteMode == TilePaletteMode.EyeDropper) parent.eyeDropperStrategy.toolUp(screenPosition)
        }
        private fun paint(screenPosition: Point) { /*@DONE ImageEditorViewModel.TilePaletteTool.Paint/1 cs:1491-1523*/
            val point = parent.toSpriteSpace(screenPosition)
            val rowNumber = point.y / 8
            val colNumber = point.x / 8
            if (!parent.withinImage(point)) return
            val lineTileWidth = parent.pixelWidth / 8
            val lineTileHeight = parent.pixelHeight / 8
            val originalTileIndex = rowNumber * lineTileWidth + colNumber
            val paletteAddress = parent.model.readPointer(parent.palettePointer)
            var currentSelectedPage = parent.palettePage
            val paletteRun = parent.model.getNextRun(paletteAddress) as? IPaletteRun
            if (paletteRun != null) currentSelectedPage += paletteRun.paletteFormat.initialBlankPages

            val originalPalette = parent.tilePalettes[originalTileIndex]
            if (originalPalette == currentSelectedPage) return // painting a tile with its existing palette is a no-op
            val queue = kotlin.collections.ArrayDeque<Point>()
            queue.addLast(Point(colNumber, rowNumber))
            while (queue.isNotEmpty()) {
                val p = queue.removeFirst()
                if (p.x < 0 || p.x >= lineTileWidth || p.y < 0 || p.y >= lineTileHeight) continue
                val index = p.y * lineTileWidth + p.x
                if (parent.tilePalettes[index] != originalPalette) continue

                queue.addLast(p + Point(1, 0))
                queue.addLast(p + Point(-1, 0))
                queue.addLast(p + Point(0, -1))
                queue.addLast(p + Point(0, 1))

                parent.tilePalettes[index] = currentSelectedPage
            }

            refresh()
        }
        private fun refresh() { /*@DONE ImageEditorViewModel.TilePaletteTool.Refresh/1 cs:1525-1533*/
            // tilemap may have been repointed: recalculate
            val spriteAddress = parent.model.readPointer(parent.spritePointer)
            val tilemapRun = parent.model.getNextRun(spriteAddress) as ITilemapRun
            tilemapRun.findMatchingTileset(parent.model)

            parent.pixels = tilemapRun.getPixels(parent.model, parent.spritePage, -1) ?: Array(0) { IntArray(0) }
            parent.render()
        }
        private fun raiseRefreshSelection(rowNumber: Int, colNumber: Int) { /*@DONE ImageEditorViewModel.TilePaletteTool.RaiseRefreshSelection/1 cs:1535-1540*/
            val drawPoint = Point(colNumber * 8, rowNumber * 8)
            val selectionPoints = Array(8 * 8) { i -> drawPoint + Point(i % 8, i / 8) }
            parent.raiseRefreshSelection(*selectionPoints)
        }
        /*@END ImageEditorViewModel.TilePaletteTool*/
    }
    open class PaletteCache { // cs:1543-1548
        var colors: List<Short> = ArrayList()
            private set
        var pages: Int = 0
            private set
        var initialBlankPages: Int = 0
            private set
        constructor(parent: ImageEditorViewModel) { /*@DONE ImageEditorViewModel.PaletteCache.<init>/1 cs:1547-1547*/
            val tuple = parent.readPalette()
            colors = tuple.colors
            pages = tuple.pages
            initialBlankPages = tuple.initialBlankPages
        }
        /*@END ImageEditorViewModel.PaletteCache*/
    }
    companion object {
        const val maxZoom: Int = 24
        fun readPalette(model: IDataModel, palettePointer: Int, spriteBits: Int): ImageEditorViewModelReadPaletteTuple { /*@DONE ImageEditorViewModel.ReadPalette/1 cs:510-521*/
            if (palettePointer == Pointer.null_) {
                return ImageEditorViewModelReadPaletteTuple(TileViewModel.createDefaultPalette(1 shl spriteBits).asList(), 1, 0)
            }

            val paletteAddress = model.readPointer(palettePointer)
            val palette = model.getNextRun(paletteAddress) as? IPaletteRun
            if (palette == null) {
                return ImageEditorViewModelReadPaletteTuple(TileViewModel.createDefaultPalette(1 shl spriteBits).asList(), 1, 0)
            }
            return ImageEditorViewModelReadPaletteTuple(palette.allColors(model) ?: ArrayList(), palette.pages, palette.paletteFormat.initialBlankPages)
        }
        /*@END ImageEditorViewModel.Companion*/
    }
    /*@ADD ImageEditorViewModel#imageeditor.txt*/
    /** A command whose delegates receive the command parameter (C# StubCommand with Execute/CanExecute lambdas). */
    private fun argCommand(execute: (Any?) -> Unit, canExecute: ((Any?) -> Boolean)? = null): StubCommand {
        val command = StubCommand()
        command.execute = execute
        command.canExecute = canExecute ?: { _ -> true }
        return command
    }

    private fun toolFromArg(arg: Any?): ImageEditorTools? {
        return when (arg) {
            is ImageEditorTools -> arg
            is Int -> ImageEditorTools.entries.firstOrNull { it.value == arg }
            is String -> ImageEditorTools.entries.firstOrNull { it.name.equals(arg.trim(), ignoreCase = true) }
                ?: arg.trim().toIntOrNull()?.let { n -> ImageEditorTools.entries.firstOrNull { it.value == n } }
            else -> null
        }
    }

    private fun tilePaletteModeFromArg(arg: Any?): TilePaletteMode? {
        return when (arg) {
            is TilePaletteMode -> arg
            is Int -> TilePaletteMode.entries.firstOrNull { it.value == arg }
            is String -> TilePaletteMode.entries.firstOrNull { it.name.equals(arg.trim(), ignoreCase = true) }
                ?: arg.trim().toIntOrNull()?.let { n -> TilePaletteMode.entries.firstOrNull { it.value == n } }
            else -> null
        }
    }

    private fun intFromArg(arg: Any?): Int? {
        return when (arg) {
            is Int -> arg
            is Number -> arg.toInt()
            is String -> arg.trim().toIntOrNull()
            else -> null
        }
    }

    /** Lets the nested tool strategies raise PropertyChanged on the (protected) view-model core. */
    fun raiseChanged(propertyName: String) {
        notifyPropertyChanged(propertyName)
    }
    /*@ENDADD ImageEditorViewModel#imageeditor.txt*/
    /*@END ImageEditorViewModel*/
}

enum class ImageEditorTools(val value: Int) { // cs:1553-1560
    Pan(0),
    Select(1),
    Draw(2),
    Fill(3),
    EyeDropper(4),
    TilePalette(5);
    companion object {
        fun fromValue(value: Int): ImageEditorTools = entries.first { it.value == value }
    }
    /*@END ImageEditorTools*/
}

enum class TilePaletteMode(val value: Int) { // cs:1562-1566
    Draw(0),
    Fill(1),
    EyeDropper(2);
    companion object {
        fun fromValue(value: Int): TilePaletteMode = entries.first { it.value == value }
    }
    /*@END TilePaletteMode*/
}

open class BlockPreview : ViewModelCore(), IPixelViewModel { // cs:1568-1603
    override val transparent: Short
        get() { /*@DONE BlockPreview.Transparent.get cs:1569-1569*/
            return (-1).toShort()
        }
    private var width: Int = 0
    private var height: Int = 0
    override var pixelWidth: Int
        get() { /*@DONE BlockPreview.PixelWidth.get cs:1572-1572*/
            return width
        }
        set(value) { /*@DONE BlockPreview.PixelWidth.set cs:1572-1572*/
            tryUpdate(width, value, "pixelWidth") { width = it }
        }
    override var pixelHeight: Int
        get() { /*@DONE BlockPreview.PixelHeight.get cs:1573-1573*/
            return height
        }
        set(value) { /*@DONE BlockPreview.PixelHeight.set cs:1573-1573*/
            tryUpdate(height, value, "pixelHeight") { height = it }
        }
    override var pixelData: ShortArray = ShortArray(0)
    private var scale: Double = 0.0
    override var spriteScale: Double
        get() { /*@DONE BlockPreview.SpriteScale.get cs:1578-1578*/
            return scale
        }
        set(value) { /*@DONE BlockPreview.SpriteScale.set cs:1578-1578*/
            tryUpdate(scale, value, "spriteScale") { scale = it }
        }
    private var _enabled: Boolean = false
    var enabled: Boolean
        get() { /*@DONE BlockPreview.Enabled.get cs:1581-1581*/
            return _enabled
        }
        private set(value) { /*@DONE BlockPreview.Enabled.set cs:1581-1581*/
            tryUpdate(_enabled, value, "enabled") { _enabled = it }
        }
    fun set(full: ShortArray, fullWidth: Int, start: Point, width: Int, height: Int) { /*@DONE BlockPreview.Set/1 cs:1583-1598*/
        enabled = true
        pixelWidth = width
        pixelHeight = height

        val data = ShortArray(Math.max(width, 0) * Math.max(height, 0))
        for (y in 0 until height) {
            for (x in 0 until width) {
                data[y * width + x] = full[fullWidth * (start.y + y) + start.x + x]
            }
        }
        pixelData = data
        notifyPropertyChanged("pixelData")

        spriteScale = Math.max(1, Math.min(64 / Math.max(width, 1), 64 / Math.max(height, 1))).toDouble()
    }
    fun clear() { /*@DONE BlockPreview.Clear/1 cs:1600-1602*/
        enabled = false
    }
    /*@END BlockPreview*/
}

open class EditOption : ViewModelCore, IPixelViewModel { // cs:1605-1643
    private lateinit var model: IDataModel
    override val transparent: Short
        get() { /*@DONE EditOption.Transparent.get cs:1608-1608*/
            return (-1).toShort()
        }
    final override var pixelWidth: Int = 0
        private set
    final override var pixelHeight: Int = 0
        private set
    var spritePointer: Int = 0
        private set
    var palettePointer: Int = 0
        private set
    override var pixelData: ShortArray = ShortArray(0)
    override val spriteScale: Double
        get() { /*@DONE EditOption.SpriteScale.get cs:1615-1615*/
            return if (pixelWidth > 240 || pixelHeight > 160) 0.5 else 1.0
        }
    constructor(model: IDataModel, spritePointer: Int, palettePointer: Int) { /*@DONE EditOption.<init>/1 cs:1617-1630*/
        this.model = model
        this.spritePointer = spritePointer
        this.palettePointer = palettePointer
        val spriteAddress = model.readPointer(spritePointer)
        val sprite = model.getNextRun(spriteAddress) as? ISpriteRun

        if (sprite != null) {
            pixelWidth = sprite.spriteFormat.tileWidth * 8
            pixelHeight = sprite.spriteFormat.tileHeight * 8
        } else {
            pixelData = ShortArray(0)
        }

        refresh()
    }
    fun refresh() { /*@DONE EditOption.Refresh/1 cs:1632-1642*/
        val spriteAddress = model.readPointer(spritePointer)
        val sprite = model.getNextRun(spriteAddress) as? ISpriteRun ?: return

        val palInfo = ImageEditorViewModel.readPalette(model, palettePointer, sprite.spriteFormat.bitsPerPixel)

        val pixels = sprite.getPixels(model, 0, -1)
        pixelData = SpriteTool.render(pixels, palInfo.colors, palInfo.initialBlankPages, 0)
        notifyPropertyChanged("pixelData")
    }
    /*@END EditOption*/
}

data class ImageEditorViewModelReadPaletteTuple(val colors: List<Short>, val pages: Int, val initialBlankPages: Int)

data class ImageEditorViewModelSelectionToolBuildRectTuple(val point: Point, val width: Int, val height: Int)
