// Port of ViewModels/SearchResultsViewPort.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*

open class SelectionRange { // cs:16-16
    open var start: Int = 0
    open var end: Int = 0
    /*@END SelectionRange*/
}

open class SelectionRangeGroup : SelectionRange(), Iterable<SelectionRange> { // cs:17-26
    private val children: MutableList<SelectionRange> = /*@INITDONE SelectionRangeGroup.children cs:18-18*/ ArrayList() /*@ENDINIT*/
    override var start: Int
        get() { /*@DONE SelectionRangeGroup.Start.get cs:19-19*/
            throw NotImplementedError()
        }
        set(value) { /*@DONE SelectionRangeGroup.Start.set cs:19-19*/
            super.start = value
        }
    override var end: Int
        get() { /*@DONE SelectionRangeGroup.End.get cs:20-20*/
            throw NotImplementedError()
        }
        set(value) { /*@DONE SelectionRangeGroup.End.set cs:20-20*/
            super.end = value
        }
    fun add(range: SelectionRange?) { /*@DONE SelectionRangeGroup.Add/1 cs:21-21*/
        children.add(range!!)
    }
    operator fun get(i: Int): SelectionRange { /*@DONE SelectionRangeGroup.this/1.get cs:22-22*/
        return children[i]
    }
    override fun iterator(): Iterator<SelectionRange> { /*@DONE SelectionRangeGroup.GetEnumerator/1 cs:24-24*/
        return children.iterator()
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@END SelectionRangeGroup*/
}

open class SearchResultsViewPort : ViewModelCore, IViewPort { // cs:28-360
    private lateinit var _scroll: StubCommand
    private lateinit var _close: StubCommand
    private val children: MutableList<IChildViewPort> = /*@INITAUTO SearchResultsViewPort.children cs:30-30*/ ArrayList() /*@ENDINIT*/
    private val firstChildToUseParent: MutableMap<IViewPort, Int> = /*@INITAUTO SearchResultsViewPort.firstChildToUseParent cs:31-31*/ LinkedHashMap() /*@ENDINIT*/
    private val childrenSelection: MutableList<SelectionRange> = /*@INITAUTO SearchResultsViewPort.childrenSelection cs:32-32*/ ArrayList() /*@ENDINIT*/
    private var _width: Int = 0
    private var _height: Int = 0
    private var _scrollValue: Int = 0
    private var maxScrollValue: Int = 0
    val childViewCount: Int
        get() { /*@DONE SearchResultsViewPort.ChildViewCount.get cs:35-35*/
            return children.size
        }
    val resultCount: Int
        get() { /*@DONE SearchResultsViewPort.ResultCount.get cs:36-36*/
            return children.sumOf { child -> if (child is CompositeChildViewPort) child.size else 1 }
        }
    override operator fun get(x: Int, y: Int): HexElement { /*@DONE SearchResultsViewPort.this/1.get cs:41-49*/
        val (childIndex, line) = getChildLine(y)
        if (line < 0 && x == 3 && childIndex < children.size && firstChildToUseParent[children[childIndex].parent!!] == childIndex) {
            return HexElement(0, false, UnderEdit(null, "Results from " + children[childIndex].fileName, _width))
        }
        if (line < 0 || childIndex >= children.size) return HexElement.undefined

        return children[childIndex][x, line]
    }
    override var width: Int
        get() { /*@DONE SearchResultsViewPort.Width.get cs:53-53*/
            return _width
        }
        set(value) { /*@DONE SearchResultsViewPort.Width.set cs:54-56*/
            if (tryUpdate(_width, value, "width") { _width = it }) notifyCollectionChanged()
        }
    override var height: Int
        get() { /*@DONE SearchResultsViewPort.Height.get cs:59-59*/
            return _height
        }
        set(value) { /*@DONE SearchResultsViewPort.Height.set cs:60-62*/
            if (tryUpdate(_height, value, "height") { _height = it }) notifyCollectionChanged()
        }
    override val minimumScroll: Int
        get() { /*@DONE SearchResultsViewPort.MinimumScroll.get cs:64-64*/
            return 0
        }
    override val previewScrollChanged = Event<EventArgs>()
    override var scrollValue: Int
        get() { /*@DONE SearchResultsViewPort.ScrollValue.get cs:67-67*/
            return _scrollValue
        }
        set(value) { /*@DONE SearchResultsViewPort.ScrollValue.set cs:68-72*/
            previewScrollChanged(this, EventArgs.empty)
            val limited = value.limitToRange(0, maximumScroll)
            if (tryUpdate(_scrollValue, limited, "scrollValue") { _scrollValue = it }) notifyCollectionChanged()
        }
    override var maximumScroll: Int
        get() { /*@DONE SearchResultsViewPort.MaximumScroll.get cs:74-74*/
            return maxScrollValue
        }
        set(value) { /*@DONE SearchResultsViewPort.MaximumScroll.set cs:74-74*/
            tryUpdate(maxScrollValue, value, "maximumScroll") { maxScrollValue = it }
        }
    override val headers: ObservableCollection<RowHeader>? = /*@INITAUTO SearchResultsViewPort.Headers cs:75-75*/ ObservableCollection() /*@ENDINIT*/
    override val scroll: ICommand
        get() { /*@DONE SearchResultsViewPort.Scroll.get cs:76-76*/
            return _scroll
        }
    override val dataOffset: Int
        get() { /*@DONE SearchResultsViewPort.DataOffset.get cs:78-82*/
            val (childIndex, line) = getChildLine(0)
            val child = children[childIndex]
            return child.width * line + child.dataOffset
        }
    override var toolPanelWidth: Double = /*@INITAUTO SearchResultsViewPort.ToolPanelWidth cs:84-84*/ 500.0 /*@ENDINIT*/
    final override var name: String = ""
        private set
    final override var fullFileName: String = ""
        private set
    override val fileName: String
        get() { /*@DONE SearchResultsViewPort.FileName.get cs:87-87*/
            return ""
        }
    override var spartanMode: Boolean = false
    override val isMetadataOnlyChange: Boolean
        get() { /*@DONE SearchResultsViewPort.IsMetadataOnlyChange.get cs:89-89*/
            return false
        }
    override var findBytes: ByteArray? = null
    override val save: ICommand? = /*@INITAUTO SearchResultsViewPort.Save cs:91-91*/ StubCommand() /*@ENDINIT*/
    override val saveAs: ICommand = /*@INITAUTO SearchResultsViewPort.SaveAs cs:92-92*/ StubCommand() /*@ENDINIT*/
    override val exportBackup: ICommand
        get() { /*@DONE SearchResultsViewPort.ExportBackup.get cs:93-93*/
            return disabledViewPortCommand
        }
    override val undo: ICommand = /*@INITAUTO SearchResultsViewPort.Undo cs:94-94*/ StubCommand() /*@ENDINIT*/
    override val redo: ICommand = /*@INITAUTO SearchResultsViewPort.Redo cs:95-95*/ StubCommand() /*@ENDINIT*/
    override val copy: ICommand? = /*@INITAUTO SearchResultsViewPort.Copy cs:96-96*/ StubCommand() /*@ENDINIT*/
    override val deepCopy: ICommand = /*@INITAUTO SearchResultsViewPort.DeepCopy cs:97-97*/ StubCommand() /*@ENDINIT*/
    override val diff: ICommand
        get() { /*@DONE SearchResultsViewPort.Diff.get cs:98-98*/
            return disabledViewPortCommand
        }
    override val diffLeft: ICommand
        get() { /*@DONE SearchResultsViewPort.DiffLeft.get cs:99-99*/
            return disabledViewPortCommand
        }
    override val diffRight: ICommand
        get() { /*@DONE SearchResultsViewPort.DiffRight.get cs:100-100*/
            return disabledViewPortCommand
        }
    override val clear: ICommand? = /*@INITAUTO SearchResultsViewPort.Clear cs:101-101*/ StubCommand() /*@ENDINIT*/
    override val selectAll: ICommand = /*@INITAUTO SearchResultsViewPort.SelectAll cs:102-102*/ StubCommand() /*@ENDINIT*/
    override val goto: ICommand?
        get() { /*@DONE SearchResultsViewPort.Goto.get cs:103-103*/
            return null
        }
    override val resetAlignment: ICommand = /*@INITAUTO SearchResultsViewPort.ResetAlignment cs:104-104*/ StubCommand() /*@ENDINIT*/
    override val back: ICommand = /*@INITAUTO SearchResultsViewPort.Back cs:105-105*/ StubCommand() /*@ENDINIT*/
    override val forward: ICommand = /*@INITAUTO SearchResultsViewPort.Forward cs:106-106*/ StubCommand() /*@ENDINIT*/
    override val close: ICommand
        get() { /*@DONE SearchResultsViewPort.Close.get cs:107-107*/
            return _close
        }
    override val canDuplicate: Boolean
        get() { /*@DONE SearchResultsViewPort.CanDuplicate.get cs:108-108*/
            return false
        }
    override var base10Length: Boolean = false
    override fun duplicate() { /*@DONE SearchResultsViewPort.Duplicate/1 cs:110-110*/
        // search results cannot be duplicated
    }
    override val updateInProgress: Boolean
        get() { /*@DONE SearchResultsViewPort.UpdateInProgress.get cs:112-112*/
            return false
        }
    override val progress: Double
        get() { /*@DONE SearchResultsViewPort.Progress.get cs:113-113*/
            return 0.0
        }
    override val model: IDataModel?
        get() { /*@DONE SearchResultsViewPort.Model.get cs:115-115*/
            return null
        }
    override fun modelFor(p: Point): IDataModel? { /*@DONE SearchResultsViewPort.ModelFor/1 cs:116-121*/
        val (childIndex, line) = getChildLine(p.y)
        if (line == -1 || childIndex >= children.size) return null

        return children[childIndex].modelFor(Point(p.x, line))
    }
    override val hasTools: Boolean
        get() { /*@DONE SearchResultsViewPort.HasTools.get cs:123-123*/
            return false
        }
    override var autoAdjustDataWidth: Boolean = false
    override var stretchData: Boolean = false
    override var allowMultipleElementsPerLine: Boolean = false
    override lateinit var changeHistory: ChangeHistory<ModelDelta>
    override val tools: IToolTrayViewModel? = /*@INITAUTO SearchResultsViewPort.Tools cs:129-129*/ SearchResultsTools() /*@ENDINIT*/
    override var selectedAddress: String
        get() { /*@DONE SearchResultsViewPort.SelectedAddress.get cs:131-131*/
            return ""
        }
        set(value) { /*@DONE SearchResultsViewPort.SelectedAddress.set cs:131-131*/
            // the selection of a result list cannot be edited
        }
    override val selectedBytes: String?
        get() { /*@DONE SearchResultsViewPort.SelectedBytes.get cs:132-132*/
            return ""
        }
    override var anchorText: String = ""
    override val anchorTextVisible: Boolean
        get() { /*@DONE SearchResultsViewPort.AnchorTextVisible.get cs:136-136*/
            return false
        }
    override val columnHeaders: ObservableCollection<ColumnHeaderRow> = ObservableCollection()
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val clearMessage = Event<EventArgs>()
    override val closed = Event<EventArgs>()
    override val collectionChanged = Event<NotifyCollectionChangedEventArgs>()
    override val requestTabChange = Event<TabChangeRequestedEventArgs>()
    override val requestCloseOtherViewports = Event<IDataModel>()
    override val requestDelayedWork = Event<() -> Unit>()
    override val requestMenuClose = Event<EventArgs>()
    override val requestDiff = Event<Direction>()
    override val requestCanCreatePatch = Event<CanPatchEventArgs>()
    override val requestCreatePatch = Event<CanPatchEventArgs>()
    override val requestCanDiff = Event<CanDiffEventArgs>()
    override val requestRefreshGotoShortcuts = Event<EventArgs>()
    override val canIpsPatchRight: Boolean
        get() { /*@DONE SearchResultsViewPort.CanIpsPatchRight.get cs:157-157*/
            return false
        }
    override val canUpsPatchRight: Boolean
        get() { /*@DONE SearchResultsViewPort.CanUpsPatchRight.get cs:158-158*/
            return false
        }
    override fun ipsPatchRight() { /*@DONE SearchResultsViewPort.IpsPatchRight/1 cs:159-159*/
        // not supported by search results
    }
    override fun upsPatchRight() { /*@DONE SearchResultsViewPort.UpsPatchRight/1 cs:160-160*/
        // not supported by search results
    }
    constructor(searchTerm: String) { /*@DONE SearchResultsViewPort.<init>/1 cs:164-184*/
        fullFileName = "Results for " + searchTerm
        name = if (searchTerm.length > 24) searchTerm.substring(0, 23) + "\u2026" else searchTerm

        _width = 4
        _height = 4

        val scrollCommand = StubCommand()
        scrollCommand.canExecute = { arg -> (arg as Direction) != Direction.Left && (arg as Direction) != Direction.Right }
        scrollCommand.execute = { arg ->
            val direction = arg as Direction
            if (direction == Direction.Up) scrollValue -= 1
            if (direction == Direction.Down) scrollValue += 1
        }
        _scroll = scrollCommand

        val closeCommand = StubCommand()
        closeCommand.canExecute = { _ -> true }
        closeCommand.execute = { _ -> closed(this, EventArgs.empty) }
        _close = closeCommand
    }
    fun add(child: IChildViewPort?, start: Int, end: Int) { /*@DONE SearchResultsViewPort.Add/1 cs:186-217*/
        val range = SelectionRange()
        range.start = start
        range.end = end
        if (children.size > 0) {
            val previousHeight = children.last().height
            val combo = Ref<CompositeChildViewPort?>(null)
            if (CompositeChildViewPort.tryCombine(children.last(), child!!, combo)) {
                val combined = combo.value!!
                children[children.size - 1] = combined
                val existing = childrenSelection[children.size - 1]
                if (existing is SelectionRangeGroup) {
                    existing.add(range)
                } else {
                    val group = SelectionRangeGroup()
                    group.add(existing)
                    group.add(range)
                    childrenSelection[children.size - 1] = group
                }
                maxScrollValue += combined.height - previousHeight
                combined.refreshHeaders()
                notifyCollectionChanged()
                return
            }
        }

        val newChild = child!!
        newChild.refreshHeaders()
        children.add(newChild)
        childrenSelection.add(range)
        maxScrollValue += newChild.height
        _width = Math.max(_width, newChild.width)
        if (children.size > 1) maxScrollValue++
        if (!firstChildToUseParent.containsKey(newChild.parent!!)) {
            firstChildToUseParent[newChild.parent!!] = children.size - 1
        }
        notifyCollectionChanged()
    }
    override fun createChildView(startAddress: Int, endAddress: Int): IChildViewPort { /*@DONE SearchResultsViewPort.CreateChildView/1 cs:219-219*/
        throw NotImplementedError()
    }
    override fun find(search: String, matchExactCase: Boolean): List<IViewPortFindTuple> { /*@DONE SearchResultsViewPort.Find/1 cs:222-222*/
        return ArrayList()
    }
    override val canFindFreeSpace: Boolean
        get() { /*@DONE SearchResultsViewPort.CanFindFreeSpace.get cs:224-224*/
            return false
        }
    override fun findFreeSpace(fs: IFileSystem) { /*@DONE SearchResultsViewPort.FindFreeSpace/1 cs:225-225*/
        // not supported by search results
    }
    override var useCustomHeaders: Boolean
        get() { /*@DONE SearchResultsViewPort.UseCustomHeaders.get cs:228-228*/
            return children.firstOrNull()?.useCustomHeaders ?: false
        }
        set(value) { /*@DONE SearchResultsViewPort.UseCustomHeaders.set cs:229-232*/
            for (child in children) child.useCustomHeaders = value
            updateHeaders()
        }
    override fun isSelected(point: Point): Boolean { /*@DONE SearchResultsViewPort.IsSelected/1 cs:235-242*/
        val x = point.x
        val y = point.y
        if (y < 0 || y > _height || x < 0 || x > _width) return false
        val (childIndex, line) = getChildLine(y)
        if (line == -1 || childIndex >= children.size) return false

        return children[childIndex].isSelected(Point(x, line))
    }
    override fun isTable(point: Point): Boolean { /*@DONE SearchResultsViewPort.IsTable/1 cs:244-244*/
        return false
    }
    override fun followLink(x: Int, y: Int) { /*@DONE SearchResultsViewPort.FollowLink/1 cs:246-285*/
        if (y < 0 || y > _height || x < 0 || x > _width) return
        val childLineInfo = getChildLine(y)
        val childIndex = childLineInfo.first
        var line = childLineInfo.second
        if (line == -1 || childIndex >= children.size) return

        var child = children[childIndex]
        val parent = child.parent!!
        requestTabChange(this, TabChangeRequestedEventArgs(parent))
        val (compositeChildIndex, compositeLine) = getChildLineFromComposite(child, line)
        if (compositeChildIndex >= 0) child = (child as CompositeChildViewPort)[compositeChildIndex]
        if (compositeLine >= 0) line = compositeLine

        var range = childrenSelection[childIndex]
        if (compositeChildIndex == -1 && range is SelectionRangeGroup) return
        if (range is SelectionRangeGroup) range = range[compositeChildIndex]

        if (child.model!!.getNextRun(child.dataOffset) is ITableRun) {
            if (child is ChildViewPort) {
                parent.goto?.execute(range.start)
                parent.scrollValue -= y
            } else {
                parent.goto?.execute(child.dataOffset)
                parent.scrollValue += line - y
            }

            // heuristic: if the parent height matches the search results height, then the parent
            // probably doesn't have labels yet but is about to get them. We don't know how big the
            // labels will be, but they will probably push all the data down quite a bit.
            // compensate by scrolling slightly
            if (parent.height == height) parent.scrollValue += 3
        } else {
            val dataOffset = Math.max(0, child.dataOffset)
            parent.goto?.execute(dataOffset.toHex(6))
            parent.scrollValue += line - y
        }

        if (parent is ViewPort) {
            selectRange(parent, range)
        }
    }
    override fun expandSelection(x: Int, y: Int) { /*@DONE SearchResultsViewPort.ExpandSelection/1 cs:292-292*/
        followLink(x, y)
    }
    override fun considerReload(fileSystem: IFileSystem) { /*@DONE SearchResultsViewPort.ConsiderReload/1 cs:294-294*/
        // search results never reload
    }
    override fun findAllSources(x: Int, y: Int) { /*@DONE SearchResultsViewPort.FindAllSources/1 cs:296-302*/
        if (y < 0 || y > _height || x < 0 || x > _width) return
        val (childIndex, line) = getChildLine(y)
        if (line == -1 || childIndex >= children.size) return

        children[childIndex].findAllSources(x, y)
    }
    override fun getContextMenuItems(selectionPoint: Point, fileSystem: IFileSystem?): List<IContextItem> { /*@DONE SearchResultsViewPort.GetContextMenuItems/1 cs:304-309*/
        val item = ContextItem("Open in Main Tab", { _ ->
            followLink(selectionPoint.x, selectionPoint.y)
            requestMenuClose(this, EventArgs.empty)
        })
        item.shortcutText = "Ctrl+Click"
        return arrayListOf<IContextItem>(item)
    }
    override fun refresh() { /*@DONE SearchResultsViewPort.Refresh/1 cs:311-311*/
        for (child in children) child.refresh()
    }
    override fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean { /*@DONE SearchResultsViewPort.TryImport/1 cs:313-313*/
        return false
    }
    private fun notifyCollectionChanged() { /*@DONE SearchResultsViewPort.NotifyCollectionChanged/1 cs:315-319*/
        if (children.size == 0) return
        updateHeaders()
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset))
    }
    private fun updateHeaders() { /*@DONE SearchResultsViewPort.UpdateHeaders/1 cs:321-331*/
        headers!!.clear()
        for (i in 0 until _height) {
            val (childIndex, line) = getChildLine(i)
            if (line == -1 || childIndex >= children.size) { // blank line between results / after results
                headers!!.add(RowHeader.fromString(""))
            } else {
                headers!!.add(children[childIndex].headers!![line])
            }
        }
    }
    private fun getChildLine(y: Int): Pair<Int, Int> { /*@DONE SearchResultsViewPort.GetChildLine/1 cs:338-345*/
        var line = y + _scrollValue - 1 // 0 is the first line in the data. Include one empty line at the top for the file name
        var childIndex = 0
        while (childIndex < children.size && children[childIndex].height <= line) {
            line -= children[childIndex].height + 1
            childIndex++
        }
        return Pair(childIndex, line)
    }
    private fun getChildLineFromComposite(viewPort: IChildViewPort, line: Int): Pair<Int, Int> { /*@DONE SearchResultsViewPort.GetChildLineFromComposite/1 cs:347-359*/
        if (viewPort !is CompositeChildViewPort) return Pair(-1, -1)

        // each child has the same data offset and same height
        // but they have different selections
        // return the last element that has something selected on the chosen line.
        for (i in viewPort.size - 1 downTo 0) {
            val child = viewPort[i] as ChildViewPort
            if (child.selectionStart.y <= line) return Pair(i, child.selectionStart.y)
        }

        return Pair(-1, -1)
    }
    companion object {
        fun selectRange(viewPort: ViewPort, range: SelectionRange) { /*@DONE SearchResultsViewPort.SelectRange/1 cs:287-290*/
            viewPort.selectionStart = viewPort.convertAddressToViewPoint(range.start)
            viewPort.selectionEnd = viewPort.convertAddressToViewPoint(range.end)
        }
        /*@END SearchResultsViewPort.Companion*/
    }
    /*@END SearchResultsViewPort*/
}

open class SearchResultsTools : IToolTrayViewModel { // cs:362-392
    override val hideCommand: ICommand = /*@INITAUTO SearchResultsTools.HideCommand cs:363-363*/ StubCommand() /*@ENDINIT*/
    override val stringToolCommand: ICommand = /*@INITAUTO SearchResultsTools.StringToolCommand cs:364-364*/ StubCommand() /*@ENDINIT*/
    override val tableToolCommand: ICommand = /*@INITAUTO SearchResultsTools.TableToolCommand cs:365-365*/ StubCommand() /*@ENDINIT*/
    override val spriteToolCommand: ICommand = /*@INITAUTO SearchResultsTools.SpriteToolCommand cs:366-366*/ StubCommand() /*@ENDINIT*/
    override val codeToolCommand: ICommand = /*@INITAUTO SearchResultsTools.CodeToolCommand cs:367-367*/ StubCommand() /*@ENDINIT*/
    override val stringTool: PCSTool?
        get() { /*@DONE SearchResultsTools.StringTool.get cs:369-369*/
            return null
        }
    override val tableTool: TableTool?
        get() { /*@DONE SearchResultsTools.TableTool.get cs:370-370*/
            return null
        }
    override val spriteTool: SpriteTool?
        get() { /*@DONE SearchResultsTools.SpriteTool.get cs:371-371*/
            return null
        }
    override val codeTool: CodeTool?
        get() { /*@DONE SearchResultsTools.CodeTool.get cs:372-372*/
            return null
        }
    override val logTool: LogTool?
        get() { /*@DONE SearchResultsTools.LogTool.get cs:373-373*/
            return null
        }
    override val deferUpdates: IDisposable
        get() { /*@DONE SearchResultsTools.DeferUpdates.get cs:375-375*/
            return StubDisposable()
        }
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    override fun schedule(action: () -> Unit) { /*@DONE SearchResultsTools.Schedule/1 cs:383-383*/
        action()
    }
    override fun refreshContent() { /*@DONE SearchResultsTools.RefreshContent/1 cs:384-384*/
        // search results have no tools to refresh
    }
    override operator fun get(index: Int): IToolViewModel { /*@DONE SearchResultsTools.this/1.get cs:386-386*/
        throw IndexOutOfBoundsException()
    }
    override var selectedIndex: Int
        get() { /*@DONE SearchResultsTools.SelectedIndex.get cs:387-387*/
            return -1
        }
        set(value) { /*@DONE SearchResultsTools.SelectedIndex.set cs:387-387*/
            // there are no tools
        }
    override var selectedTool: IToolViewModel?
        get() { /*@DONE SearchResultsTools.SelectedTool.get cs:388-388*/
            return null
        }
        set(value) { /*@DONE SearchResultsTools.SelectedTool.set cs:388-388*/
            // there are no tools
        }
    override val size: Int
        get() { /*@DONE SearchResultsTools.Count.get cs:389-389*/
            return 0
        }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@END SearchResultsTools*/
}

/*@ADD file:viewmodels/SearchResultsViewPort.kt#viewports_a.txt*/
/** Stands in for the C# `ICommand X => null;` members of view ports that have no such command (the UI sees a disabled command). */
internal val disabledViewPortCommand: ICommand = StubCommand()
/*@ENDADD file:viewmodels/SearchResultsViewPort.kt#viewports_a.txt*/
