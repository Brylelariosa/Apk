// Port of ViewModels/Images/ReadonlyPixelViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.images

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class ReadonlyPixelViewModel : ViewModelCore, IPixelViewModel { // cs:8-59
    final override var transparent: Short = 0.toShort()
        private set
    final override var pixelWidth: Int = 0
        private set
    final override var pixelHeight: Int = 0
        private set
    final override var pixelData: ShortArray = ShortArray(0)
        private set
    override var spriteScale: Double = /*@INITAUTO ReadonlyPixelViewModel.SpriteScale cs:13-13*/ 1.0 /*@ENDINIT*/
    constructor(sf: SpriteFormat, data: ShortArray, transparent: Short = -1) { /*@DONE ReadonlyPixelViewModel.<init>/1 cs:15-18*/
        this.pixelWidth = sf.tileWidth * 8
        this.pixelHeight = sf.tileHeight * 8
        this.pixelData = data
        this.transparent = transparent
    }
    constructor(width: Int, height: Int, data: ShortArray? = null, transparent: Short = -1) { /*@DONE ReadonlyPixelViewModel.<init>/2 cs:20-24*/
        this.pixelWidth = width
        this.pixelHeight = height
        this.pixelData = data ?: ShortArray(width * height)
        this.transparent = transparent
    }
    companion object {
        fun create(model: IDataModel, sprite: ISpriteRun?, useTransparency: Boolean = false, scale: Double = 1.0): ReadonlyPixelViewModel? { /*@DONE ReadonlyPixelViewModel.Create/1 cs:26-28*/
            return SpriteDecorator.buildSprite(model, sprite, useTransparency, scale)
        }
        fun create(model: IDataModel, sprite: ISpriteRun?, tableElementAddress: Int, useTransparency: Boolean = false, scale: Double = 1.0): ReadonlyPixelViewModel? { /*@DONE ReadonlyPixelViewModel.Create/2 cs:30-32*/
            return SpriteDecorator.buildSprite(model, sprite, tableElementAddress, useTransparency, scale)
        }
        fun create(model: IDataModel, sprite: ISpriteRun?, palette: IPaletteRun?, useTransparency: Boolean = false): IPixelViewModel? { /*@DONE ReadonlyPixelViewModel.Create/3 cs:34-36*/
            if (sprite == null) return null
            return SpriteDecorator.buildSprite(model, sprite, palette, useTransparency)
        }
        fun crop(pixels: IPixelViewModel, x: Int, y: Int, width: Int, height: Int): ReadonlyPixelViewModel { /*@DONE ReadonlyPixelViewModel.Crop/1 cs:38-40*/
            return TilemapTableRun.crop(pixels, x, y, Math.max(0, pixels.pixelWidth - width - x), Math.max(0, pixels.pixelHeight - height - y))
        }
        fun render(background: IPixelViewModel, foreground: IPixelViewModel, x: Int, y: Int): IPixelViewModel { /*@DONE ReadonlyPixelViewModel.Render/1 cs:42-58*/
            val data = ShortArray(background.pixelData.size)
            System.arraycopy(background.pixelData, 0, data, 0, background.pixelData.size)

            for (yy in 0 until foreground.pixelHeight) {
                for (xx in 0 until foreground.pixelWidth) {
                    val pixel = foreground.pixelData[foreground.pixelWidth * yy + xx]
                    if (pixel == foreground.transparent) continue
                    if (x + xx >= background.pixelWidth || y + yy >= background.pixelHeight) continue
                    if (x + xx < 0 || y + yy < 0) continue
                    val offset = background.pixelWidth * (y + yy) + x + xx
                    data[offset] = pixel
                }
            }

            return ReadonlyPixelViewModel(background.pixelWidth, background.pixelHeight, data, background.transparent)
        }
        /*@END ReadonlyPixelViewModel.Companion*/
    }
    /*@END ReadonlyPixelViewModel*/
}
