// Port of Models/Singletons.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flySpawns
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tradeTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapBankTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTableRSE
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.wildTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.specialsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDataTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapLayoutTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.berryTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flyConnections
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.dexInfoTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.naturesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldSprites
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonStatsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.eggMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldPalettes
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.frontSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.contestTypesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokePalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typeChartTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.shinyPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerSpritesName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemImagesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.levelMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemEffectsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.regionalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.nationalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.multichoiceTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDescriptionsName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backupFontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultSpriteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerClassNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.conversionDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultTilemapNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultPaletteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityDescriptionsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPaletteIndexTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticleSpriteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticlePaletteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveInfoListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTargetListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionMethodListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsShapeListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsCategoryListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsPermissionListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emerald
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.hmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTutors
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tutorCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.cfruIgnoreTables
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decodeConstantsFromReference
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.getIsCFRU

open class Singletons { // cs:21-601
    lateinit var metadataInfo: IMetadataInfo
        private set
    var gameReferenceTables: Map<String, GameReferenceTables> = LinkedHashMap()
        private set
    var gameReferenceConstants: Map<String, GameReferenceConstants>? = null
        private set
    var thumbConditionalCodes: List<ConditionCode> = ArrayList()
        private set
    var thumbInstructionTemplates: List<IInstruction> = ArrayList()
        private set
    var scriptLines: List<IScriptLine> = ArrayList()
        private set
    var battleScriptLines: List<IScriptLine> = ArrayList()
        private set
    var animationScriptLines: List<IScriptLine> = ArrayList()
        private set
    var battleAIScriptLines: List<IScriptLine> = ArrayList()
        private set
    var docReference: Map<String, List<DocLabel>> = LinkedHashMap()
        private set
    var workDispatcher: IWorkDispatcher? = null
        private set
    var pythonUtility: String = ""
        private set
    var copyLimit: Int = 0
        private set
    constructor(dispatcher: IWorkDispatcher? = null, copyLimit: Int = 40000) { /*@DONE Singletons.<init>/1 cs:49-62*/
        metadataInfo = MetadataInfo()
        gameReferenceTables = createGameReferenceTables()
        gameReferenceConstants = createGameReferenceConstants()
        val thumbReference = loadThumbReference()
        thumbConditionalCodes = thumbReference.first
        thumbInstructionTemplates = thumbReference.second
        scriptLines = loadScriptReference<XSEScriptLine>(scriptReferenceFileName)
        battleScriptLines = loadScriptReference<BSEScriptLine>(battleScriptReferenceFileName)
        animationScriptLines = loadScriptReference<ASEScriptLine>(animationScriptReferenceFileName)
        battleAIScriptLines = loadScriptReference<TSEScriptLine>(battleAIScriptReferenceFileName)
        docReference = loadDocReference(docReferenceFileName)
        workDispatcher = dispatcher ?: InstantDispatch.instance
        pythonUtility = if (Resources.exists(pythonUtilityFileName)) Resources.readAllText(pythonUtilityFileName) else ""
        this.copyLimit = copyLimit
    }
    constructor(metadataInfo: IMetadataInfo, gameReferenceTables: Map<String, GameReferenceTables>, copyLimit: Int = 40000) : this(metadataInfo, gameReferenceTables, null, copyLimit) { /*@DONE Singletons.<init>/2 cs:64-64*/
        // all work happens in the delegated constructor
    }
    constructor(metadataInfo: IMetadataInfo, gameReferenceTables: Map<String, GameReferenceTables>, gameRefereneceConstants: Map<String, GameReferenceConstants>?, copyLimit: Int = 40000) { /*@DONE Singletons.<init>/3 cs:66-80*/
        this.metadataInfo = metadataInfo
        this.gameReferenceTables = gameReferenceTables
        this.gameReferenceConstants = gameRefereneceConstants ?: LinkedHashMap()
        thumbConditionalCodes = ArrayList()
        thumbInstructionTemplates = ArrayList()
        scriptLines = ArrayList()
        battleScriptLines = ArrayList()
        animationScriptLines = ArrayList()
        battleAIScriptLines = ArrayList()
        docReference = LinkedHashMap()
        workDispatcher = InstantDispatch.instance
        this.copyLimit = copyLimit
        pythonUtility = ""
    }
    private inline fun <reified TLine : ScriptLine> loadScriptReference(file: String): List<IScriptLine> { /*@DONE Singletons.LoadScriptReference/1 cs:82-110*/
        if (!Resources.exists(file)) return ArrayList<ScriptLine>()
        var factory: (String) -> IScriptLine = { line -> XSEScriptLine(line) }
        if (TLine::class == BSEScriptLine::class) factory = { line -> BSEScriptLine(line) }
        if (TLine::class == ASEScriptLine::class) factory = { line -> ASEScriptLine(line) }
        if (TLine::class == TSEScriptLine::class) factory = { line -> TSEScriptLine(line) }

        val lines = Resources.readAllLines(file)
        val scriptLines = ArrayList<IScriptLine>()
        var active: IScriptLine? = null
        for (line in lines) {
            if (line.isEmpty()) continue
            if (!line.startsWith(" ") && active != null) active = null
            if (line.startsWith("#")) continue
            if (line.trim().startsWith("#")) {
                active?.addDocumentation(line.trim())
            } else {
                if (MacroScriptLine.isMacroLine(line)) {
                    val macro = MacroScriptLine(line)
                    if (macro.isValid) active = macro
                } else {
                    active = factory(line)
                }
                if (active != null) scriptLines.add(active)
            }
        }

        return scriptLines
    }
    private fun loadDocReference(file: String): Map<String, List<DocLabel>> { /*@DONE Singletons.LoadDocReference/1 cs:112-138*/
        val dict = LinkedHashMap<String, List<DocLabel>>()
        if (!Resources.exists(file)) return dict
        val lines = Resources.readAllLines(file)
        val lists = ArrayList<MutableList<DocLabel>>()
        for (line in lines) {
            val trim = line.trim()
            if (trim.isBlank()) continue
            if (trim.startsWith("[")) {
                lists.clear()
                val content = trim.split('[', ']').filter { part -> part.isNotEmpty() }[0]
                val keys = content.split("_")
                for (key in keys) {
                    var list = dict[key] as MutableList<DocLabel>?
                    if (list == null) {
                        list = ArrayList()
                        dict[key] = list
                    }
                    lists.add(list)
                }
            } else if (trim.startsWith("#")) {
                continue
            } else {
                val content = trim.split(' ').filter { part -> part.isNotEmpty() }
                if (content.size != 2) continue
                val label = DocLabel(content[0], content[1])
                lists.forEach { list -> list.add(label) }
            }
        }
        return dict
    }
    private fun createGameReferenceTables(): Map<String, GameReferenceTables> { /*@DONE Singletons.CreateGameReferenceTables/1 cs:141-152*/
        val tableEn = createGameReferenceTablesEnglish()
        val tableIt = createGameReferenceTablesItalian()
        val readonlyTables = LinkedHashMap<String, GameReferenceTables>()
        for (pair in tableEn) {
            readonlyTables[pair.key] = pair.value
        }
        for (pair in tableIt) {
            readonlyTables[pair.key] = pair.value
        }
        return readonlyTables
    }
    private fun createGameReferenceTablesEnglish(): Map<String, GameReferenceTables> { /*@DONE Singletons.CreateGameReferenceTablesEnglish/1 cs:155-189*/
        if (!Resources.exists(tableReferenceFileName)) return LinkedHashMap()
        val lines = Resources.readAllLines(tableReferenceFileName)
        val tables = LinkedHashMap<String, MutableList<ReferenceTable>>()
        for (i in 0 until referenceOrder.size - 2) tables[referenceOrder[i + 1]] = ArrayList()
        for (line in lines) {
            val row = line.trim()
            if (row.startsWith("//")) continue
            val segments = row.split("//")[0].split(",")
            if (segments.size != referenceOrder.size) continue
            var name = segments[0].trim()
            var offset = 0
            if (name.contains("+")) {
                val parts = name.split("+")
                name = parts[0]
                val parsed = Ref(0)
                tryParseHexInt(parts[1], parsed)
                offset = parsed.value
            } else if (name.contains("-")) {
                val parts = name.split("-")
                name = parts[0]
                val parsed = Ref(0)
                tryParseHexInt(parts[1], parsed)
                offset = -parsed.value
            }
            val format = segments.last().trim()
            for (i in 0 until referenceOrder.size - 2) {
                val addressHex = segments[i + 1].trim()
                if (addressHex == "") continue
                val address = Ref(0)
                if (!tryParseHexInt(addressHex, address)) continue
                tables[referenceOrder[i + 1]]!!.add(ReferenceTable(name, offset, address.value, format))
            }
        }

        val readonlyTables = LinkedHashMap<String, GameReferenceTables>()
        for (pair in tables) readonlyTables[pair.key] = GameReferenceTables(pair.value)
        return readonlyTables
    }
    private fun createGameReferenceTablesItalian(): Map<String, GameReferenceTables> { /*@DONE Singletons.CreateGameReferenceTablesItalian/1 cs:191-227*/
        if (!Resources.exists(tableReferenceFileNameItalian)) {
            return LinkedHashMap()
        }
        val lines = Resources.readAllLines(tableReferenceFileNameItalian)
        val tables = LinkedHashMap<String, MutableList<ReferenceTable>>()
        for (i in 0 until referenceOrderItalian.size - 2) tables[referenceOrderItalian[i + 1]] = ArrayList()
        for (line in lines) {
            val row = line.trim()
            if (row.startsWith("//")) continue
            val segments = row.split("//")[0].split(",")
            if (segments.size != referenceOrderItalian.size) continue
            var name = segments[0].trim()
            var offset = 0
            if (name.contains("+")) {
                val parts = name.split("+")
                name = parts[0]
                val parsed = Ref(0)
                tryParseHexInt(parts[1], parsed)
                offset = parsed.value
            } else if (name.contains("-")) {
                val parts = name.split("-")
                name = parts[0]
                val parsed = Ref(0)
                tryParseHexInt(parts[1], parsed)
                offset = -parsed.value
            }
            val format = segments.last().trim()
            for (i in 0 until referenceOrderItalian.size - 2) {
                val addressHex = segments[i + 1].trim()
                if (addressHex == "") continue
                val address = Ref(0)
                if (!tryParseHexInt(addressHex, address)) continue
                tables[referenceOrderItalian[i + 1]]!!.add(ReferenceTable(name, offset, address.value, format))
            }
        }

        val readonlyTables = LinkedHashMap<String, GameReferenceTables>()
        for (pair in tables) readonlyTables[pair.key] = GameReferenceTables(pair.value)
        return readonlyTables
    }
    private fun createGameReferenceConstants(): Map<String, GameReferenceConstants> { /*@DONE Singletons.CreateGameReferenceConstants/1 cs:230-241*/
        val constantsEn = createGameReferenceConstantsEnglish()
        val constantsIt = createGameReferenceConstantsItalian()
        val readonlyConstants = LinkedHashMap<String, GameReferenceConstants>()
        for (pair in constantsEn) {
            readonlyConstants[pair.key] = pair.value
        }
        for (pair in constantsIt) {
            readonlyConstants[pair.key] = pair.value
        }
        return readonlyConstants
    }
    private fun createGameReferenceConstantsEnglish(): Map<String, GameReferenceConstants> { /*@DONE Singletons.CreateGameReferenceConstantsEnglish/1 cs:243-263*/
        if (!Resources.exists(constantReferenceFileName)) return LinkedHashMap()
        val lines = Resources.readAllLines(constantReferenceFileName)
        val constants = LinkedHashMap<String, MutableList<ReferenceConstant>>()
        for (line in lines) {
            if (line.isBlank()) continue
            val cleanLine = line.trim()
            if (cleanLine.length < 6) continue
            if (!Character.isLetter(cleanLine[0])) continue
            val gameCode = cleanLine.substring(0, 5).uppercase()
            var collection = constants[gameCode]
            if (collection == null) {
                collection = ArrayList()
                constants[gameCode] = collection
            }
            collection.add(ReferenceConstant(cleanLine.substring(5)))
        }

        val readonlyConstants = LinkedHashMap<String, GameReferenceConstants>()
        for (pair in constants) readonlyConstants[pair.key] = GameReferenceConstants(pair.value)
        return readonlyConstants
    }
    private fun createGameReferenceConstantsItalian(): Map<String, GameReferenceConstants> { /*@DONE Singletons.CreateGameReferenceConstantsItalian/1 cs:265-285*/
        if (!Resources.exists(constantReferenceFileNameItalian)) return LinkedHashMap()
        val lines = Resources.readAllLines(constantReferenceFileNameItalian)
        val constants = LinkedHashMap<String, MutableList<ReferenceConstant>>()
        for (line in lines) {
            if (line.isBlank()) continue
            val cleanLine = line.trim()
            if (cleanLine.length < 6) continue
            if (!Character.isLetter(cleanLine[0])) continue
            val gameCode = cleanLine.substring(0, 5).uppercase()
            var collection = constants[gameCode]
            if (collection == null) {
                collection = ArrayList()
                constants[gameCode] = collection
            }
            collection.add(ReferenceConstant(cleanLine.substring(5)))
        }

        val readonlyConstants = LinkedHashMap<String, GameReferenceConstants>()
        for (pair in constants) readonlyConstants[pair.key] = GameReferenceConstants(pair.value)
        return readonlyConstants
    }
    private fun loadThumbReference(): Pair<List<ConditionCode>, List<IInstruction>> { /*@DONE Singletons.LoadThumbReference/1 cs:287-297*/
        val conditionalCodes = ArrayList<ConditionCode>()
        val instructionTemplates = ArrayList<IInstruction>()
        if (!Resources.exists(thumbReferenceFileName)) return Pair(ArrayList<ConditionCode>(), ArrayList<IInstruction>())
        val engineLines = Resources.readAllLines(thumbReferenceFileName)
        for (line in engineLines) {
            val condition = Ref<ConditionCode?>(null)
            val instruction = Ref<Instruction?>(null)
            if (ConditionCode.tryLoadConditionCode(line, condition)) conditionalCodes.add(condition.value!!)
            else if (Instruction.tryLoadInstruction(line, instruction)) instructionTemplates.add(instruction.value!!)
        }
        return Pair(conditionalCodes, instructionTemplates)
    }
    fun exportReadableScriptReference(editor: EditorViewModel) { /*@DONE Singletons.ExportReadableScriptReference/1 cs:299-308*/
        val specials = LinkedHashMap<String, StoredList>()
        for (code in arrayOf("axve", "axpe", "bpre", "bpge", "bpee")) {
            specials[code] = BaseModel.getDefaultMetadatas(code).flatMap { md -> md.lists }.single { list -> list.name == "specials" }
        }

        exportReadableScriptReference(editor, scriptLines, specials, scriptReferenceDocumetationFileName)
    }
    private fun exportReadableScriptReference(editor: EditorViewModel, lines: List<IScriptLine>, specials: MutableMap<String, StoredList>, filename: String) { /*@DONE Singletons.ExportReadableScriptReference/2 cs:314-497*/
        // setup: make sure all the scripts have been fully determined
        for (tab in editor) {
            if (tab !is IEditableViewPort) continue
            val top = Flags.getAllTopLevelScripts(tab.model!!)
            for (script in top) tab.tools!!.codeTool!!.scriptParser.formatScript<XSERun>(ModelDelta(), tab.model!!, script)
        }

        val rnd = java.util.Random(0x5eed)
        val text = StringBuilder()
        val nl = NEW_LINE
        text.append("\nThis is a list of all the commands currently available within HexManiacAdvance when writing scripts.\nFor example scripts and tutorials, see the [HexManiacAdvance Wiki](https://github.com/haven1433/HexManiacAdvance/wiki).\n").append(NEW_LINE)
        text.appendLine("# Commands")
        var lastCommand: String? = null

        for (line in lines.sortedBy { line -> line.lineCommand }) {
            if (lastCommand != null && lastCommand != line.lineCommand) {
                text.appendLine("</details>")
                text.appendLine()
            }
            if (lastCommand != line.lineCommand) {
                text.appendLine("## ${line.lineCommand}")
                text.appendLine()
                text.appendLine("<details>")
                text.appendLine("<summary> ${line.lineCommand}</summary>")
                text.appendLine()
            }
            lastCommand = line.lineCommand
            text.appendLine()

            text.append(line.lineCommand)
            if (line.lineCode.count > 1) text.append(" " + line.lineCode[1])
            for (arg in line.args) {
                if (arg is SilentMatchArg || arg.name == "filler") continue
                if (arg is ArrayArg) {
                    text.append(" `[${arg.name}]`")
                } else {
                    text.append(" `${arg.name}`")
                }
            }
            text.appendLine()
            val matches = ScriptLine.getMatchingGames(line)
            if (matches.size < 5) text.appendLine("$nl  Only available in " + " ".join(matches))
            for (arg in line.args) {
                if (arg is SilentMatchArg || arg.name == "filler") continue
                val enumName = arg.enumTableName
                if (!enumName.isNullOrEmpty() && !enumName.startsWith("|")) {
                    text.appendLine("$nl*  `${arg.name}` is from $enumName")
                } else if (arg.type != ArgType.Pointer) {
                    if (enumName.isNullOrEmpty()) {
                        text.appendLine("$nl*  `${arg.name}` is a number.")
                    } else {
                        text.appendLine("$nl*  `${arg.name}` is a number (hex).")
                    }
                } else if (arg.type == ArgType.Pointer) {
                    if (arg.pointerType == ExpectedPointerType.Script) {
                        text.appendLine("$nl*  `${arg.name}` points to a script or section")
                    } else if (arg.pointerType == ExpectedPointerType.Mart) {
                        text.appendLine("$nl*  `${arg.name}` points to pokemart data or auto")
                    } else if (arg.pointerType == ExpectedPointerType.Movement) {
                        text.appendLine("$nl*  `${arg.name}` points to movement data or auto")
                    } else if (arg.pointerType == ExpectedPointerType.SpriteTemplate) {
                        text.appendLine("$nl*  `${arg.name}` points to sprite-template data or auto")
                    } else if (arg.pointerType == ExpectedPointerType.Decor) {
                        text.appendLine("$nl*  `${arg.name}` points to decor data or auto")
                    } else if (arg.pointerType == ExpectedPointerType.Text) {
                        text.appendLine("$nl*  `${arg.name}` points to text or auto")
                    } else if (arg.pointerType == ExpectedPointerType.Unknown) {
                        text.appendLine("$nl*  `${arg.name}` is a pointer.")
                    }
                }
            }
            text.appendLine("")
            text.appendLine("Example:")
            text.appendLine("```")

            var exampleFound = false
            if (line is ScriptLine && line.args.size > 0) {
                val examples = getExamplesForBasicCommandReference(editor, line.lineCode)
                if (examples.size > 0) {
                    text.append(rnd.from(examples))
                    exampleFound = true
                }
            } else if (line is MacroScriptLine) {
                val examples = getExamplesForMacroCommandReference(editor, line)
                if (examples.size > 0) {
                    text.append(rnd.from(examples))
                    exampleFound = true
                }
            }
            if (!exampleFound) {
                text.append(line.lineCommand)
                if (line.lineCode.count > 1) text.append(" " + line.lineCode[1])
                for (arg in line.args) {
                    if (arg is SilentMatchArg || arg.name == "filler") continue
                    val enumName = arg.enumTableName
                    if (!enumName.isNullOrEmpty() && !enumName.startsWith("|")) {
                        val model = (editor.first() as IViewPort).model!!
                        var options = model.getOptions(enumName) ?: emptyList()
                        val count = Ref(0)
                        if (options.size == 0 && tryParseInt(enumName, count)) options = count.value.range { i -> i.toString() }.toList()
                        text.append(" " + rnd.from(options))
                    } else if (arg.type != ArgType.Pointer) {
                        if (enumName.isNullOrEmpty()) {
                            text.append(" ${rnd.nextInt(5)}")
                        } else {
                            text.append(" 0x${rnd.nextInt(16).toHex(2)}")
                        }
                    } else if (arg.type == ArgType.Pointer) {
                        if (arg.pointerType == ExpectedPointerType.Script) {
                            text.append(" <section1>")
                        } else if (arg.pointerType == ExpectedPointerType.Unknown) {
                            text.appendLine(" <F00000>")
                        } else {
                            text.append(" <auto>")
                        }
                    }
                }
            }

            text.appendLine()
            text.appendLine("```")
            val documentation = line.documentation
            if (documentation != null && documentation.size > 0) {
                text.appendLine("Notes:")
                text.appendLine("```")
                for (doc in documentation) {
                    text.appendLine("  $doc")
                }
                text.appendLine("```")
            }
        }
        text.appendLine("</details>")
        text.appendLine()

        text.appendLine("# Specials")
        text.append("\nThis is a list of all the specials available within HexManiacAdvance when writing scripts.\n\nUse `special name` when doing an action with no result.\n\nUse `special2 variable name` when doing an action that has a result.\n* The result will be returned to the variable.\n").append(NEW_LINE)

        val variableForSpecial = getVariableForSpecialReference(editor)
        val varNamesRef = Ref<ValidationList?>(null)
        (editor.first() as IViewPort).model!!.tryGetList("scriptvariablealiases", varNamesRef)
        val varNames = varNamesRef.value
        val names = specials.values.flatMap { list -> list.contents }.distinct().sortedBy { name -> name }.toList()
        for (name in names) {
            if (name.isNullOrEmpty()) continue
            if (name.length < 2) continue
            val supportedGames = specials.keys.filter { key -> specials[key]!!.contents.contains(name) }.toList()
            text.appendLine("## $name")
            text.appendLine()
            text.appendLine("<details>")
            text.appendLine("<summary> $name </summary>")
            text.appendLine()
            if (supportedGames.size == specials.size) {
                text.appendLine("*(Supports all games.)*")
            } else {
                text.appendLine("*(Supports ${", ".join(supportedGames)})*")
            }
            text.appendLine()
            var usage = "special $name"
            val variableID = variableForSpecial[name]
            if (variableID != null) {
                val resultVar = (varNames!![variableID] as String?) ?: "0x${variableID.toHex(4)}"
                usage = "special2 $resultVar $name"
            }
            text.appendLine("Example Usage:")
            text.appendLine("```")
            text.appendLine(usage)
            text.appendLine("```")
            for (game in supportedGames) {
                val comment = specials[game]!!.comments?.get(specials[game]!!.indexOf(name))
                if (comment != null) {
                    text.appendLine(comment)
                    text.appendLine()
                    break
                }
            }
            text.appendLine("</details>")
            text.appendLine()
        }

        java.io.File(filename).writeText(text.toString())
    }
    companion object {
        private const val tableReferenceFileName: String = "resources/tableReference.txt"
        private const val tableReferenceFileNameItalian: String = "resources/tableReference.it.txt"
        private const val constantReferenceFileName: String = "resources/constantReference.txt"
        private const val constantReferenceFileNameItalian: String = "resources/constantReference.it.txt"
        private const val thumbReferenceFileName: String = "resources/armReference.txt"
        private const val scriptReferenceFileName: String = "resources/scriptReference.txt"
        private const val battleScriptReferenceFileName: String = "resources/battleScriptReference.txt"
        private const val animationScriptReferenceFileName: String = "resources/animationScriptReference.txt"
        private const val battleAIScriptReferenceFileName: String = "resources/battleAIScriptReference.txt"
        private const val scriptReferenceDocumetationFileName: String = "resources/scriptReference.md"
        private const val docReferenceFileName: String = "resources/docReference.txt"
        private const val pythonUtilityFileName: String = "resources/hma.py"
        var referenceOrder: List<String> = /*@INITDONE Singletons.ReferenceOrder cs:140-140*/ listOf("name", ruby, sapphire, ruby1_1, sapphire1_1, fireRed, leafGreen, fireRed1_1, leafGreen1_1, emerald, "format") /*@ENDINIT*/
            private set
        var referenceOrderItalian: List<String> = /*@INITDONE Singletons.ReferenceOrderItalian cs:154-154*/ listOf("name", fireRedIt, "format") /*@ENDINIT*/
            private set
        fun getExamplesForMacroCommandReference(editor: EditorViewModel, line: MacroScriptLine): List<String> { /*@DONE Singletons.GetExamplesForMacroCommandReference/1 cs:499-536*/
            val collection = ArrayList<String>()
            for (tab in editor) {
                if (tab !is IEditableViewPort) continue
                val model = tab.model!!
                val hash = model.getShortGameCode()
                val top = Flags.getAllTopLevelScripts(model)
                val start = (line.args[0] as SilentMatchArg).expectedValue
                val header = "# From " + model.getGameCode() + ", "
                val spots = Flags.getAllScriptSpots(model, tab.tools!!.codeTool!!.scriptParser, top, start)
                for (spot in spots.filter { spot -> line.matches(hash, model, spot.address) }) {
                    // skip spots that resolve to a different macro
                    if (spot.line != line) continue

                    // skip spots where the variables are 'weird'
                    var argStart = spot.address + spot.line.lineCode.count
                    var reasonableArgs = true
                    for (arg in spot.line.args) {
                        if (arg is ScriptArg && !arg.fitsInRange(model, argStart)) {
                            reasonableArgs = false
                            break
                        }
                        argStart += arg.length(model, argStart)
                    }
                    if (!reasonableArgs) continue

                    val library = DecompileLabelLibrary(model, spot.address - 0x1000, 0x2000)
                    val streams = ArrayList<ExpectedPointerType>()
                    var text = spot.line.decompile(model, spot.address, library, streams)
                    val sectionCount = Ref(0)
                    val labels = library.finalizeLabels(sectionCount)
                    text = library.finalizeLine(labels, text)
                    collection.add(header + spot.address.toAddress() + NEW_LINE + text)
                    if (collection.size >= maxExamples) return collection
                }
            }
            return collection
        }
        fun getExamplesForBasicCommandReference(editor: EditorViewModel, command: ByteList): List<String> { /*@DONE Singletons.GetExamplesForBasicCommandReference/1 cs:538-545*/
            val collection = ArrayList<String>()
            for (tab in editor) {
                if (tab !is IEditableViewPort) continue
                collectBasicCommandExamples(tab.model!!, tab.tools!!.codeTool!!.scriptParser, collection, command, "# From " + tab.model!!.getGameCode() + ", ")
            }
            return collection
        }
        private const val maxExamples: Int = 20
        fun collectBasicCommandExamples(model: IDataModel, parser: ScriptParser, collection: MutableList<String>, command: ByteList, prefix: String) { /*@DONE Singletons.CollectBasicCommandExamples/1 cs:548-577*/
            if (collection.size >= maxExamples) return
            for (spot in Flags.getAllScriptSpots(model, parser, Flags.getAllTopLevelScripts(model), false, command[0])!!) {
                if (collection.size >= maxExamples) break

                val commandMatches = command.count.range().all { i -> model[spot.address + i] == command[i] }
                if (!commandMatches) continue

                // skip spots where the variables are 'weird'
                var argStart = spot.address + spot.line.lineCode.count
                var reasonableArgs = true
                for (arg in spot.line.args) {
                    if (arg is ScriptArg && !arg.fitsInRange(model, argStart)) {
                        reasonableArgs = false
                        break
                    }
                    argStart += arg.length(model, argStart)
                }
                if (!reasonableArgs) continue

                val library = DecompileLabelLibrary(model, spot.address - 0x1000, 0x2000)
                val streams = ArrayList<ExpectedPointerType>()
                var text = spot.line.decompile(model, spot.address, library, streams)
                val sectionCount = Ref(0)
                val labels = library.finalizeLabels(sectionCount)
                text = library.finalizeLine(labels, text)
                collection.add(prefix + spot.address.toAddress() + ":" + NEW_LINE + text)
            }
        }
        fun getVariableForSpecialReference(editor: EditorViewModel): Map<String, Int> { /*@DONE Singletons.GetVariableForSpecialReference/1 cs:579-586*/
            val collection = LinkedHashMap<String, Int>()
            for (tab in editor) {
                if (tab !is IEditableViewPort) continue
                collectSpecialReference(tab.model!!, tab.tools!!.codeTool!!.scriptParser, collection)
            }
            return collection
        }
        fun collectSpecialReference(model: IDataModel, parser: ScriptParser, collection: MutableMap<String, Int>) { /*@DONE Singletons.CollectSpecialReference/1 cs:588-600*/
            val listRef = Ref<ValidationList?>(null)
            if (!model.tryGetList("specials", listRef)) return
            val list = listRef.value!!
            for (spot in Flags.getAllScriptSpots(model, parser, Flags.getAllTopLevelScripts(model), 0x26)) {
                val variable = model.readMultiByteValue(spot.address + 1, 2)
                if (variable < 0x100) continue
                val specialID = model.readMultiByteValue(spot.address + 3, 2)
                if (specialID.inRange(0, list.size) && (list[specialID] as String?) != null) {
                    val name = list[specialID]
                    if (collection.containsKey(name)) continue
                    collection[name] = variable
                }
            }
        }
        /*@END Singletons.Companion*/
    }
    /*@END Singletons*/
}

fun Map<String, GameReferenceTables>.guessSources(code: String, address: Int): Array<String> { /*@DONE GameReferenceTableDictionaryExtensions.GuessSources/1 cs:604-619*/
    val result = Array(this.size) { "" }
    val tables = this[code] ?: return result
    val index = tables.getIndexOfNearestAddress(address)
    val name = tables[index].name
    val diff = address - tables[index].address

    val keys = this.keys.toTypedArray()
    for (i in 0 until this.size) {
        val currentTable = this[keys[i]]!!.firstOrNull { table -> table.name == name }
        if (currentTable == null) continue
        result[i] = (currentTable.address + diff).toAddress()
    }

    return result
}

object GameReferenceTableDictionaryExtensions { // cs:603-620
    /*@END GameReferenceTableDictionaryExtensions*/
}

open class GameReferenceTables : ReadOnlyListMixin<ReferenceTable> { // cs:622-649
    private var core: List<ReferenceTable> = ArrayList()
    operator fun get(name: String): ReferenceTable? { /*@DONE GameReferenceTables.this/1.get cs:624-624*/
        return core.firstOrNull { table -> table.name == name }
    }
    override operator fun get(index: Int): ReferenceTable { /*@DONE GameReferenceTables.this/2.get cs:625-625*/
        return core[index]
    }
    override val size: Int
        get() { /*@DONE GameReferenceTables.Count.get cs:626-626*/
            return core.size
        }
    constructor(list: List<ReferenceTable>) { /*@DONE GameReferenceTables.<init>/1 cs:628-628*/
        core = list
    }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    fun getIndexOfNearestAddress(address: Int): Int { /*@DONE GameReferenceTables.GetIndexOfNearestAddress/1 cs:637-648*/
        var distance = Int.MAX_VALUE
        var index = -1
        for (i in 0 until size) {
            val currentDistance = Math.abs(this[i].address - address)
            if (currentDistance == 0) continue
            if (currentDistance > distance) continue
            distance = currentDistance
            index = i
        }
        return index
    }
    /*@END GameReferenceTables*/
}

open class ReferenceTable { // cs:651-658
    var name: String = ""
        private set
    var offset: Int = 0
        private set
    var address: Int = 0
        private set
    var format: String? = null
        private set
    constructor(name: String, offset: Int, address: Int, format: String) { /*@DONE ReferenceTable.<init>/1 cs:656-656*/
        this.name = name
        this.offset = offset
        this.address = address
        this.format = format
    }
    override fun toString(): String { /*@DONE ReferenceTable.ToString/1 cs:657-657*/
        return "${address.toHex(6)} -> $name, $offset, $format"
    }
    /*@END ReferenceTable*/
}

open class GameReferenceConstants : ReadOnlyListMixin<ReferenceConstant> { // cs:660-670
    private var core: List<ReferenceConstant> = ArrayList()
    operator fun get(name: String): ReferenceConstant? { /*@DONE GameReferenceConstants.this/1.get cs:662-662*/
        return core.firstOrNull { table -> table.name == name }
    }
    override operator fun get(index: Int): ReferenceConstant { /*@DONE GameReferenceConstants.this/2.get cs:663-663*/
        return core[index]
    }
    override val size: Int
        get() { /*@DONE GameReferenceConstants.Count.get cs:664-664*/
            return core.size
        }
    constructor(list: List<ReferenceConstant>) { /*@DONE GameReferenceConstants.<init>/1 cs:666-666*/
        core = list
    }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@END GameReferenceConstants*/
}

open class ReferenceConstant { // cs:672-723
    var addresses: List<Int> = ArrayList()
        private set
    var name: String = ""
        private set
    var length: Int = 0
        private set
    var addOffset: Int = 0
        private set
    var multOffset: Int = /*@INITAUTO ReferenceConstant.MultOffset cs:677-677*/ 1 /*@ENDINIT*/
        private set
    var note: String? = null
        private set
    constructor(line: String) { /*@DONE ReferenceConstant.<init>/1 cs:681-716*/
        var parts = line.substring(1).split(' ').filter { part -> part.isNotEmpty() }

        // Length
        if (line[0] == '.') length = 1
        else if (line[0] == ':') length = 2
        else throw NotImplementedException()
        if (line[1] == ':') {
            length = 4
            parts = line.substring(2).split(' ').filter { part -> part.isNotEmpty() }
        }

        // Name/Offset
        if (parts[0].contains("-")) {
            val offsetSplit = parts[0].split('-')
            name = offsetSplit[0]
            addOffset = -parseInt(offsetSplit[1])
        } else if (parts[0].contains("+")) {
            val offsetSplit = parts[0].split('+')
            name = offsetSplit[0]
            addOffset = parseInt(offsetSplit[1])
        } else if (parts[0].contains("*")) {
            val offsetSplit = parts[0].split('*')
            name = offsetSplit[0]
            multOffset = parseInt(offsetSplit[1])
        } else {
            name = parts[0]
        }

        // Addresses
        addresses = parts[1].split(',').map { adr -> parseHexInt(adr) }.toList()

        // Note
        val commentParts = line.split("#", limit = 2)
        if (commentParts.size > 1) note = commentParts[1].trim()
    }
    fun toStoredMatchedWords(): Iterable<StoredMatchedWord> { /*@DONE ReferenceConstant.ToStoredMatchedWords/1 cs:718-722*/
        return addresses.map { address -> StoredMatchedWord(address, name, length, addOffset, multOffset, note) }
    }
    /*@END ReferenceConstant*/
}

interface IMetadataInfo { // cs:725-728
    val versionNumber: String?
    val isPublicRelease: Boolean
    /*@END IMetadataInfo*/
}

open class MetadataInfo : IMetadataInfo { // cs:730-745
    final override var versionNumber: String? = null
        private set
    override val isPublicRelease: Boolean
        get() { /*@DONE MetadataInfo.IsPublicRelease.get cs:733-737*/
            return true // FilePrivatePart == 0 for this build
        }
    constructor() { /*@DONE MetadataInfo.<init>/1 cs:739-744*/
        versionNumber = "0.6.1"
    }
    /*@END MetadataInfo*/
}

data class DocLabel(val label: String, val url: String) { // cs:747-747
    /*@END DocLabel*/
}
