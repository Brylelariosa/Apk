// Port of Models/Runs/Sprites/TilesetRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class TilesetRun : BaseRun, ITilesetRun { // cs:7-115
    private lateinit var model: IDataModel
    final override var tilesetFormat: TilesetFormat = TilesetFormat()
        private set
    override val spriteFormat: SpriteFormat
        get() { /*@DONE TilesetRun.SpriteFormat.get cs:13-18*/
            val tiles = Math.sqrt(tilesetFormat.tiles.toDouble())
            val width = Math.ceil(tiles).toInt()
            val height = Math.ceil(tilesetFormat.tiles.toDouble() / width).toInt()
            return SpriteFormat(tilesetFormat.bitsPerPixel, width, height, tilesetFormat.paletteHint)
        }
    override val pages: Int
        get() { /*@DONE TilesetRun.Pages.get cs:21-21*/
            return 1
        }
    override val supportsImport: Boolean
        get() { /*@DONE TilesetRun.SupportsImport.get cs:23-23*/
            return false
        }
    override val supportsEdit: Boolean
        get() { /*@DONE TilesetRun.SupportsEdit.get cs:24-24*/
            return true
        }
    override val length: Int
        get() { /*@DONE TilesetRun.Length.get cs:26-26*/
            return tilesetFormat.tiles * tilesetFormat.bitsPerPixel * 8
        }
    override val decompressedLength: Int
        get() { /*@DONE TilesetRun.DecompressedLength.get cs:27-27*/
            return length
        }
    override val formatString: String
        get() { /*@DONE TilesetRun.FormatString.get cs:30-36*/
            var format = "`uct" + tilesetFormat.bitsPerPixel + "x" + tilesetFormat.tiles
            if (tilesetFormat.maxTiles != -1) format += "x" + tilesetFormat.maxTiles
            val hint = tilesetFormat.paletteHint
            format += (if (hint.isNullOrEmpty()) "" else "|" + hint)
            return format + "`"
        }
    constructor(tilesetFormat: TilesetFormat, model: IDataModel, start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE TilesetRun.<init>/1 cs:39-48*/
        var format = tilesetFormat
        if (format.tiles == -1) {
            var nextRun = model.getNextAnchor(start + 1)
            if (nextRun.start <= start) nextRun = model.getNextAnchor(nextRun.start + nextRun.length)
            val tiles = (nextRun.start - start) / (8 * format.bitsPerPixel)
            format = TilesetFormat(format.bitsPerPixel, tiles, -1, format.paletteHint)
        }
        this.tilesetFormat = format
        this.model = model
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE TilesetRun.AppendTo/1 cs:70-76*/
        var currentStart = start
        var remaining = length
        while (remaining > 0) {
            builder.append(model[currentStart].toHexString() + " ")
            currentStart += 1
            remaining -= 1
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE TilesetRun.Clear/1 cs:78-82*/
        for (i in 0 until length) {
            changeToken.changeData(model, start + i, 0x00)
        }
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE TilesetRun.CreateDataFormat/1 cs:84-84*/
        return LzUncompressed(index)
    }
    override fun duplicate(newFormat: SpriteFormat): ISpriteRun { /*@DONE TilesetRun.Duplicate/1 cs:86-86*/
        return SpriteRun(model, start, newFormat, pointerSources)
    }
    override fun getData(): ByteArray { /*@DONE TilesetRun.GetData/1 cs:88-93*/
        val width = spriteFormat.tileWidth
        val height = spriteFormat.tileHeight
        val data = ByteArray(width * height * spriteFormat.bitsPerPixel * 8)
        System.arraycopy(model.rawData, start, data, 0, length)
        return data
    }
    override fun getPixels(model: IDataModel, page: Int, tableIndex: Int): Array<IntArray>? { /*@DONE TilesetRun.GetPixels/1 cs:95-101*/
        val width = spriteFormat.tileWidth
        val height = spriteFormat.tileHeight
        val data = ByteArray(length)
        System.arraycopy(model.rawData, start, data, 0, length)
        val pixels = SpriteRun.getPixels(data.asByteList(), 0, width, height, tilesetFormat.bitsPerPixel)
        return pixels
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>): ISpriteRun { /*@DONE TilesetRun.SetPixels/1 cs:103-108*/
        val data = ByteArray(length)
        SpriteRun.setPixels(data, 0, pixels, tilesetFormat.bitsPerPixel)
        for (i in 0 until length) token.changeData(model, start + i, data[i].toInt() and 0xFF)
        return this
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, tiles: List<Array<IntArray>>): ISpriteRun { /*@DONE TilesetRun.SetPixels/2 cs:110-112*/
        return LzTilesetRun.setPixels(this, model, token, tiles) { newStart, sources -> TilesetRun(tilesetFormat, model, newStart, sources) }
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE TilesetRun.Clone/1 cs:114-114*/
        return TilesetRun(tilesetFormat, model, start, newPointerSources)
    }
    companion object {
        fun tryParseTilesetFormat(format: String, tilesetFormat: Ref<TilesetFormat>): Boolean { /*@DONE TilesetRun.TryParseTilesetFormat/1 cs:50-68*/
            tilesetFormat.value = TilesetFormat()
            if (!format.startsWith("`uct") || !format.endsWith("`")) return false
            val content = format.substring(4, format.length - 1)
            val hintsplit = content.split("|")
            if (hintsplit.size > 2) return false
            val main = hintsplit[0]
            var hint = ""
            if (hintsplit.size == 2) hint = hintsplit[1]
            val split = main.split("x")
            if (split.size < 2 || split.size > 3) return false
            val bitsRef = Ref(0)
            val tilesRef = Ref(0)
            if (!tryParseInt(split[0], bitsRef) || !tryParseInt(split[1], tilesRef)) return false
            val bits = bitsRef.value
            val tiles = tilesRef.value
            if (!(bits == 1 || bits == 2 || bits == 4 || bits == 8)) return false
            if (tiles < 0 || tiles > 2048) return false
            var maxTiles = -1
            if (split.size == 3) {
                val maxTilesRef = Ref(0)
                if (!tryParseInt(split[2], maxTilesRef)) return false
                maxTiles = maxTilesRef.value
            }
            tilesetFormat.value = TilesetFormat(bits, tiles, maxTiles, hint)
            return true
        }
        /*@END TilesetRun.Companion*/
    }
    /*@END TilesetRun*/
}
