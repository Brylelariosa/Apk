// Port of ViewModels/QuickEditItems/MakeTmsExpandable.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flySpawns
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tradeTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapBankTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTableRSE
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.wildTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.specialsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDataTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapLayoutTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.berryTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flyConnections
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.dexInfoTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.naturesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldSprites
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonStatsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.eggMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldPalettes
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.frontSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.contestTypesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokePalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typeChartTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.shinyPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerSpritesName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemImagesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.levelMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemEffectsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.regionalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.nationalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.multichoiceTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDescriptionsName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backupFontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultSpriteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerClassNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.conversionDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultTilemapNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultPaletteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityDescriptionsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPaletteIndexTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticleSpriteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticlePaletteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveInfoListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTargetListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionMethodListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsShapeListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsCategoryListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsPermissionListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emerald
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.hmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTutors
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tutorCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.cfruIgnoreTables
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decodeConstantsFromReference
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.getIsCFRU

open class MakeTmsExpandable : IQuickEditItem { // cs:20-611
    private val setText: MutableMap<String, Int> = /*@INITDONE MakeTmsExpandable.SetText cs:26-28*/ linkedMapOf<String, Int>(HardcodeTablesModel.fireRed to 0x008D84) /*@ENDINIT*/
    private val readPokeData: MutableMap<String, Int> = /*@INITDONE MakeTmsExpandable.ReadPokeData cs:31-37*/ 
        linkedMapOf<String, Int>(
            HardcodeTablesModel.fireRed to 0x03FBE8,
            HardcodeTablesModel.leafGreen to 0x03FBE8,
            HardcodeTablesModel.ruby to 0x03CB60,
            HardcodeTablesModel.sapphire to 0x03CB60,
            HardcodeTablesModel.emerald to 0x06A518) /*@ENDINIT*/
    private val magicBufferStrings: MutableMap<String, IntArray> = /*@INITDONE MakeTmsExpandable.MagicBufferStrings cs:40-42*/ linkedMapOf<String, IntArray>(HardcodeTablesModel.fireRed to intArrayOf(0x4166FF, 0x463178, 0x416226, 0x46317C, 0x416703)) /*@ENDINIT*/
    private val canPokemonLearnTmOrHmMove: MutableMap<String, Int> = /*@INITDONE MakeTmsExpandable.CanPokemonLearnTmOrHmMove cs:45-51*/ 
        linkedMapOf<String, Int>(
            HardcodeTablesModel.fireRed to 0x043C2C,
            HardcodeTablesModel.leafGreen to 0x043C2C,
            HardcodeTablesModel.ruby to 0x040374,
            HardcodeTablesModel.sapphire to 0x040374,
            HardcodeTablesModel.emerald to 0x06E00C) /*@ENDINIT*/
    private val isMoveHmMove2: MutableMap<String, Int> = /*@INITDONE MakeTmsExpandable.IsMoveHmMove2 cs:54-57*/ 
        linkedMapOf<String, Int>(
            HardcodeTablesModel.fireRed to 0x0441B8,
            HardcodeTablesModel.emerald to 0x06E804) /*@ENDINIT*/
    private val special0x196: MutableMap<String, Int> = /*@INITDONE MakeTmsExpandable.Special0x196 cs:60-63*/ 
        linkedMapOf<String, Int>(
            HardcodeTablesModel.fireRed to 0x0CC8CC,
            HardcodeTablesModel.emerald to 0x1398C0) /*@ENDINIT*/
    private val getBattleMoveFromItemNumber: MutableMap<String, Int> = /*@INITDONE MakeTmsExpandable.GetBattleMoveFromItemNumber cs:66-69*/ 
        linkedMapOf<String, Int>(
            HardcodeTablesModel.fireRed to 0x125A78,
            HardcodeTablesModel.emerald to 0x1B6CFC) /*@ENDINIT*/
    private val isMoveHmMove1: MutableMap<String, Int> = /*@INITDONE MakeTmsExpandable.IsMoveHmMove1 cs:72-75*/ 
        linkedMapOf<String, Int>(
            HardcodeTablesModel.fireRed to 0x125A90,
            HardcodeTablesModel.emerald to 0x1B6D14) /*@ENDINIT*/
    private val bufferTmHmNameForMenu: MutableMap<String, Int> = /*@INITDONE MakeTmsExpandable.BufferTmHmNameForMenu cs:78-81*/ linkedMapOf<String, Int>(HardcodeTablesModel.fireRed to 0x131D48) /*@ENDINIT*/
    private var convertItemPointerToTmHmBattleMoveId: MutableMap<String, Int> = LinkedHashMap()
    private var isItemTmHm: MutableMap<String, Int> = LinkedHashMap()
    private var parseNumber: MutableMap<String, Int> = LinkedHashMap()
    private var readBitArray: MutableMap<String, Int> = LinkedHashMap()
    private var isItemTmHm2: MutableMap<String, Int> = LinkedHashMap()
    override val name: String?
        get() { /*@DONE MakeTmsExpandable.Name.get cs:88-88*/
            return "Make TMs Expandable"
        }
    override val description: String?
        get() { /*@DONE MakeTmsExpandable.Description.get cs:90-94*/
            return "The initial games are limited to have no more than 64 TMs+HMs." +
                NEW_LINE + "This change will allow you to freely add new TMs, up to 256." +
                NEW_LINE + "It will also split TMs and HMs into separate lists, making them easier to manage." +
                NEW_LINE + "After this change, TM moves are based on the name given to the TM/HM instead of the item index." +
                NEW_LINE + "For example, an item named 'TM30' will use the 30th move in the 'data.pokemon.moves.tms' table."
        }
    override val wikiLink: String?
        get() { /*@DONE MakeTmsExpandable.WikiLink.get cs:96-96*/
            // the original throws NotImplementedException here; there is no wiki page for this item, so report 'no link'.
            return null
        }
    override val canRunChanged = Event<EventArgs>()
    constructor() { /*@DONE MakeTmsExpandable.<init>/1 cs:100-121*/
        convertItemPointerToTmHmBattleMoveId = LinkedHashMap()
        isItemTmHm = LinkedHashMap()
        parseNumber = LinkedHashMap()
        readBitArray = LinkedHashMap()
        isItemTmHm2 = LinkedHashMap()

        // ReadBitArray fits after IsMoveHmMove2
        for (pair in isMoveHmMove2) readBitArray[pair.key] = pair.value + 0x24

        // ParseNumber goes after Special196
        for (pair in special0x196) parseNumber[pair.key] = pair.value + 0x30

        // IsItemTmHm goes after IsMoveHmMove1
        for (pair in isMoveHmMove1) isItemTmHm[pair.key] = pair.value + 0x8

        // ConvertItemPointerToTmHmBattleMoveId goes after BufferTmHmNameForMenu
        for (pair in bufferTmHmNameForMenu) convertItemPointerToTmHmBattleMoveId[pair.key] = pair.value + 0x6C

        // IsItemTmHm2 goes after ConvertItemPointerToTmHmBattleMoveId
        for (pair in convertItemPointerToTmHmBattleMoveId) isItemTmHm2[pair.key] = pair.value + 0x24
    }
    override fun canRun(viewPortInterface: IViewPort): Boolean { /*@DONE MakeTmsExpandable.CanRun/1 cs:123-139*/
        // require that I have a tab with real data, not a search tab or a diff tab or something
        if (viewPortInterface !is ViewPort) return false
        val viewPort: ViewPort = viewPortInterface
        val model = viewPort.model

        // require that this data has a tmmoves / hmmoves / tmcompatibility table, since we're messing with those
        val tmmoves = model.getAddressFromAnchor(viewPort.currentChange, -1, HardcodeTablesModel.tmMoves)
        val hmmoves = model.getAddressFromAnchor(viewPort.currentChange, -1, HardcodeTablesModel.hmMoves)
        val tmcompatibility = model.getAddressFromAnchor(viewPort.currentChange, -1, HardcodeTablesModel.tmCompatibility)
        if (tmmoves == Pointer.null_ || hmmoves == Pointer.null_ || tmcompatibility == Pointer.null_) return false
        // also require that their length is 58/8, since that being false means something else has already messed with them.
        if ((model.getNextRun(tmmoves) as? ArrayRun)?.elementCount != 58) return false
        if ((model.getNextRun(hmmoves) as? ArrayRun)?.elementCount != 8) return false

        // TODO detect if any of the functions to change have been modified
        return true
    }
    override fun run(viewPortInterface: IViewPort): Task<ErrorInfo>? { /*@DONE MakeTmsExpandable.Run/1 cs:141-162*/
        val viewPort = viewPortInterface as ViewPort
        val model = viewPort.model
        val gameCode = model.getGameCode()

        // every game-specific address table must know this game, otherwise the change could only be applied halfway
        val gameTables = listOf<Map<String, *>>(canPokemonLearnTmOrHmMove, readPokeData, isMoveHmMove2, readBitArray, special0x196, parseNumber,
            getBattleMoveFromItemNumber, setText, isMoveHmMove1, isItemTmHm, bufferTmHmNameForMenu, magicBufferStrings,
            convertItemPointerToTmHmBattleMoveId, isItemTmHm2)
        if (!gameTables.all { table -> table.containsKey(gameCode) }) {
            return Task.fromResult(ErrorInfo("Making TMs expandable is not supported for the game code " + gameCode + "."))
        }

        splitTmsHms(viewPort)
        insertCanPokemonLearnTmOrHmMove(viewPort, gameCode)
        insertIsMoveHmMove2(viewPort, gameCode)
        insertReadBitArray(viewPort, gameCode)
        insertSpecial196(viewPort, gameCode)
        insertParseNumber(viewPort, gameCode)
        insertGetBattleMoveFromItemNumber(viewPort, gameCode)
        insertIsMoveHmMove1(viewPort, gameCode)
        insertIsItemTmHm(viewPort, gameCode)
        insertBufferTmHmNameForMenu(viewPort, gameCode)
        insertConvertItemPointerToTmHmBattleMoveId(viewPort, gameCode)
        insertIsItemTmHm2(viewPort, gameCode)
        patchItemRemovalFunctions(viewPort, gameCode)

        canRunChanged(this, EventArgs.empty)
        return Task.fromResult(ErrorInfo.noError)
    }
    private fun splitTmsHms(viewPort: ViewPort) { /*@DONE MakeTmsExpandable.SplitTmsHms/1 cs:167-212*/
        val model = viewPort.model
        val token = viewPort.currentChange
        val compatibilityAddress = model.getAddressFromAnchor(token, -1, HardcodeTablesModel.tmCompatibility)
        val tmMovesAddress = model.getAddressFromAnchor(token, -1, HardcodeTablesModel.tmMoves)
        val table = model.getNextRun(compatibilityAddress) as ArrayRun

        // clear the existing format
        model.clearFormat(token, table.start, table.length)

        // extract all the HM compatibilies to a separate list
        val newTableData = ByteArray(table.elementCount)
        for (i in 0 until table.elementCount) {
            val index = table.start + 6 + i * table.elementLength
            val hmBits = model.readMultiByteValue(index, 2) shr 2
            newTableData[i] = hmBits.toByte()
            val lowValue = model[index] and 3 // only keep the bottom 2 bits: TM49 and TM50
            token.changeData(model, index, lowValue)
            token.changeData(model, index + 1, 0)
        }

        // condense all the TM compatibilities by 1 byte
        for (i in 1 until table.elementCount) {
            val a = table.start + i * (table.elementLength - 1)
            val b = table.start + i * table.elementLength
            for (j in 0 until table.elementLength - 1) {
                token.changeData(model, a + j, model[b + j])
            }
        }

        // place all the HM compatibilities after the TM compatibilities
        val hmStart = table.start + table.length - table.elementCount
        for (i in 0 until table.elementCount) {
            token.changeData(model, hmStart + i, newTableData[i].toInt() and 0xFF)
        }

        // clear HMs from the TmMove table
        val tmMovesTable = (model.getNextRun(tmMovesAddress) as ArrayRun).append(token, -8)
        model.observeAnchorWritten(token, HardcodeTablesModel.tmMoves, tmMovesTable)
        for (i in 0 until 8) model.writeMultiByteValue(tmMovesTable.start + tmMovesTable.length + i * 2, 2, token, 0)

        // add new tmcompatibility and hmcompatibility formats
        viewPort.edit("@" + compatibilityAddress.toHex(6) + " ^" + HardcodeTablesModel.tmCompatibility + "[pokemon|b[]" + HardcodeTablesModel.tmMoves + "]" + HardcodeTablesModel.pokemonNameTable + " ")
        viewPort.edit("@" + hmStart.toHex(6) + " ^" + hmCompatibility + "[pokemon|b[]" + HardcodeTablesModel.hmMoves + "]" + HardcodeTablesModel.pokemonNameTable + " ")
    }
    private fun compile(viewPort: ViewPort, start: Int, code: Array<String>): ByteList { /*@DONE MakeTmsExpandable.Compile/1 cs:214-216*/
        val parser = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")
        return parser.compile(viewPort.currentChange, viewPort.model, start, *code)
    }
    private fun insertCanPokemonLearnTmOrHmMove(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertCanPokemonLearnTmOrHmMove/1 cs:219-274*/
        val model = viewPort.model
        val start = lookup(canPokemonLearnTmOrHmMove, game)
        val length = 0x58
        model.clearFormat(viewPort.currentChange, start, length)
        val code = codeLines("""
        CanPokemonLearnTmOrHmMove:
            push lr, {r4-r5}
            mov  r4, r1
            mov  r1, #65
            mov  r2, #0
            bl   <${lookup(readPokeData, game).toHex(6)}>
            add  r4, #250
            add  r4, #39
            mov  r2, #210
            add  r2, #202
            cmp  r0, r2
            beq  <Fail>
            mov  r5, r0
            mov  r0, r4
            bl   <${lookup(isItemTmHm, game).toHex(6)}>
            cmp  r1, #0
            beq  <Fail>
            mov  r4, r1
            add  r0, #2
            bl   <${lookup(parseNumber, game).toHex(6)}>
            sub  r0, #1
            mov  r1, r5
            cmp  r4, #1
            beq  <CheckTmCompatibility>
        CheckHmCompatibility:
            ldr  r2, [pc, <HmCompatibilityTable>]
            ldr  r3, [pc, <HmMoveCount>]
            b    <UseTables>
        CheckTmCompatibility:
            ldr  r2, [pc, <TmCompatibilityTable>]
            ldr  r3, [pc, <TmMoveCount>]
        UseTables:
            bl   <${lookup(readBitArray, game).toHex(6)}>
            b    <End>
        Fail:
            mov   r0, #0
        End:
            pop   pc, {r4-r5}
        HmCompatibilityTable:
            .word <hmcompatibility>
        HmMoveCount:
            .word 00
        TmCompatibilityTable:
            .word <${HardcodeTablesModel.tmCompatibility}>
        TmMoveCount:
            .word 00
        """)
        val bytes = compile(viewPort, start, code)
        viewPort.edit("@" + (start + bytes.count - 4 * 4).toHex(6) + " <> ::" + HardcodeTablesModel.hmMoves + " <> ::" + HardcodeTablesModel.tmMoves + " ")
    }
    private fun insertIsMoveHmMove2(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertIsMoveHmMove2/1 cs:277-308*/
        val start = lookup(isMoveHmMove2, game)
        val length = 0x3C
        val model = viewPort.model
        model.clearFormat(viewPort.currentChange, start, length)
        val code = codeLines("""
        IsMoveHmMove2:
            ldr   r1, [pc, <table>]
            ldr   r3, [pc, <numberOfMoves>]
            lsl   r3, r3, #1
            add   r3, r3, r1
        Loop:
            cmp   r1, r3
            beq   <Fail>
            ldrh  r2, [r1, #0]
            add   r1, #2
            cmp   r0, r2
            bne   <Loop>
            mov   r0, #1
            b     <End>
        Fail:
            mov   r0, #0
        End:
            bx    r14
        table:
            .word <${HardcodeTablesModel.hmMoves}>
        numberOfMoves:
            .word 00
        """)
        val bytes = compile(viewPort, start, code)
        viewPort.edit("@" + (start + bytes.count - 4 * 2).toHex(6) + " <> ::" + HardcodeTablesModel.hmMoves + " ")
    }
    private fun insertReadBitArray(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertReadBitArray/1 cs:311-330*/
        val start = lookup(readBitArray, game)
        val model = viewPort.model
        val code = codeLines("""
        ReadBitArray:
            add   r3, #7
            lsr   r3, r3, #3
            mul   r1, r3
            lsr   r3, r0, #3
            add   r1, r1, r3
            ldrb  r1, [r1, r2]
            mov   r2, #7
            and   r2, r0
            mov   r0, #1
            lsl   r0, r2
            and   r0, r1
            bx    r14
        """)
        compile(viewPort, start, code)
    }
    private fun insertSpecial196(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertSpecial196/1 cs:333-368*/
        val start = lookup(special0x196, game)
        val length = 0x4C
        val model = viewPort.model
        model.clearFormat(viewPort.currentChange, start, length)
        val code = codeLines("""
        Special196:
            push  lr, {}
            ldr   r0, [pc, <itemIDLocation>]
            ldrh  r0, [r0, #0]
            bl    <${lookup(getBattleMoveFromItemNumber, game).toHex(6)}>
            cmp   r0, #0
            beq   <Fail>
            mov   r1, #13
            mul   r1, r0
            ldr   r0, [pc, <movenamesTable>]
            add   r1, r1, r0
            ldr   r0, [pc, <bufferLocation>]
            bl    <${lookup(setText, game).toHex(6)}>
            mov   r0, #1
            b     <End>
        Fail:
            mov   r0, #0
        End:
            pop   pc, {}
        movenamesTable:
            .word <${HardcodeTablesModel.moveNamesTable}>
        itemIDLocation:
            .word 020370C0
        bufferLocation:
            .word 02021CD0
        """)
        val bytes = compile(viewPort, start, code)
        for (i in bytes.count until length) viewPort.currentChange.changeData(model, start + i, 0x00)
        viewPort.edit("@" + (start + bytes.count - 4 * 3).toHex(6) + " <> ")
    }
    private fun insertParseNumber(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertParseNumber/1 cs:371-393*/
        val start = lookup(parseNumber, game)
        val model = viewPort.model
        val code = codeLines("""
        ParseNumber:
            mov  r2, #0
            mov  r3, #10
        Loop:
            ldrb r1, [r0, #0]
            cmp  r1, #255
            beq  <Done>
            sub  r1, #161
            mul  r2, r3
            add  r2, r2, r1
            add  r0, #1
            b    <Loop>
        Done:
            mov  r0, r2
            bx   r14
        """)
        val bytes = compile(viewPort, start, code)
        for (i in 0 until bytes.count) viewPort.currentChange.changeData(model, start + i, bytes[i])
    }
    private fun insertGetBattleMoveFromItemNumber(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertGetBattleMoveFromItemNumber/1 cs:396-416*/
        val start = lookup(getBattleMoveFromItemNumber, game)
        val length = 0x18
        val model = viewPort.model
        model.clearFormat(viewPort.currentChange, start, length)
        val code = codeLines("""
        GetBattleMoveFromItemNumber:
            push  lr, {}
            bl    <${lookup(isItemTmHm, game).toHex(6)}>
            cmp   r1, #0
            beq   <Fail>
            bl    <${lookup(convertItemPointerToTmHmBattleMoveId, game).toHex(6)}>
            b     <End>
        Fail:
            mov   r0, #0
        End:
            pop   pc, {}
        """)
        val bytes = compile(viewPort, start, code)
        for (i in bytes.count until length) viewPort.currentChange.changeData(model, start + i, 0x00)
    }
    private fun insertIsMoveHmMove1(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertIsMoveHmMove1/1 cs:419-433*/
        val model = viewPort.model
        val start = lookup(isMoveHmMove1, game)
        val length = 0x30
        model.clearFormat(viewPort.currentChange, start, length)
        val code = codeLines("""
        IsMoveHmMove1:
            ldr  r1, [pc, <mainroutine>]
            bx   r1
        mainroutine:
            .word <${(lookup(isMoveHmMove2, game) + 1).toHex(6)}>
        """)
        val bytes = compile(viewPort, start, code)
        for (i in bytes.count until length) viewPort.currentChange.changeData(model, start + i, 0x00)
    }
    private fun insertIsItemTmHm(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertIsItemTmHm/1 cs:436-471*/
        val start = lookup(isItemTmHm, game)
        val model = viewPort.model
        // input:  r0 = itemID
        // result: r0 = pointer to the item
        //         r1 = {0,1,2} for {none, isTm, isHm}
        val code = codeLines("""
        IsItemTmHm:
            mov  r1, #44
            mul  r0, r1
            ldr  r1, [pc, <ItemsTable>]
            add  r0, r0, r1
            ldrb r2, [r0, #1]
            cmp  r2, #199
            bne  <Fail>
            ldrb r2, [r0, #0]
            cmp  r2, #206
            beq  <IsTm>
            cmp  r2, #194
            bne  <Fail>
        IsHm:
            mov  r1, #2
            b    <End>
        IsTm:
            mov  r1, #1
            b    <End>
        Fail:
            mov  r1, #0
        End:
            bx   r14
        ItemsTable:
            .word <${HardcodeTablesModel.itemsTableName}>
        """)
        val bytes = compile(viewPort, start, code)
        viewPort.edit("@" + (start + bytes.count - 4 * 1).toHex(6) + " <> ")
    }
    private fun insertBufferTmHmNameForMenu(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertBufferTmHmNameForMenu/1 cs:474-533*/
        val model = viewPort.model
        val start = lookup(bufferTmHmNameForMenu, game)
        val length = 0xD0
        val magic = magicBufferStrings[game] ?: throw IllegalStateException("The game code " + game + " is not supported by this change.")
        val setTextAddress = lookup(setText, game).toHex(6)
        model.clearFormat(viewPort.currentChange, start, length)
        val code = codeLines("""
        BufferTmHmNameForMenu(address, itemID):
            push lr, {r4-r5}
            mov  r4, r1
            ldr  r5, [pc, <ItemsTable>]
            ldr  r1, [pc, <MagicString0>]
            bl   <${setTextAddress}>
            mov  r2, #44
            mul  r2, r4
            add  r5, r5, r2
            ldrb r2, [r5, #0]
            cmp  r2, #206
            beq  <CaseTm>
            ldr  r1, [pc, <MagicString1>]
            bl   <${setTextAddress}>
        CaseTm:
            ldr  r1, [pc, <MagicString2>]
            bl   <${setTextAddress}>
            add  r1, r5, #2
            bl   <${setTextAddress}>
            ldr  r1, [pc, <MagicString3>]
            bl   <${setTextAddress}>
            ldr  r1, [pc, <MagicString4>]
            bl   <${setTextAddress}>
            mov  r5, r0
            mov  r0, r4
            bl   <${lookup(getBattleMoveFromItemNumber, game).toHex(6)}>
            mov  r1, #13
            mul  r0, r1
            ldr  r1, [pc, <MovesTable>]
            add  r1, r1, r0
            mov  r0, r5
            bl   <${setTextAddress}>
            pop  pc, {r4-r5}
            nop
        ItemsTable:
            .word <${HardcodeTablesModel.itemsTableName}>
        MagicString0:
            .word <${magic[0].toHex(6)}>
        MagicString1:
            .word <${magic[1].toHex(6)}>
        MagicString2:
            .word <${magic[2].toHex(6)}>
        MagicString3:
            .word <${magic[3].toHex(6)}>
        MagicString4:
            .word <${magic[4].toHex(6)}>
        MovesTable:
            .word <${HardcodeTablesModel.moveNamesTable}>
        """)
        val bytes = compile(viewPort, start, code)
        for (i in bytes.count until length) viewPort.currentChange.changeData(model, start + i, 0x00)
        viewPort.edit("@" + (start + bytes.count - 4 * 7).toHex(6) + " <> ")
        viewPort.edit("@" + (start + bytes.count - 4 * 1).toHex(6) + " <> ")
    }
    private fun insertConvertItemPointerToTmHmBattleMoveId(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertConvertItemPointerToTmHmBattleMoveId/1 cs:536-564*/
        val model = viewPort.model
        val start = lookup(convertItemPointerToTmHmBattleMoveId, game)
        val code = codeLines("""
        ConvertItemPointerToTmHmBattleMoveId:
            push  lr, {r4}
            cmp   r1, #1
            beq   <LoadTmTable>
        LoadHmTable:
            ldr   r4, [pc, <HmMovesTable>]
            b     <DoParse>
        LoadTmTable:
            ldr   r4, [pc, <TmMovesTable>]
        DoParse:
            add   r0, #2
            bl    <${lookup(parseNumber, game).toHex(6)}>
            sub   r0, #1
            lsl   r0, r0, #1
            ldrh  r0, [r4, r0]
            pop   pc, {r4}
            nop
        TmMovesTable:
            .word <${HardcodeTablesModel.tmMoves}>
        HmMovesTable:
            .word <${HardcodeTablesModel.hmMoves}>
        """)
        val bytes = compile(viewPort, start, code)
        viewPort.edit("@" + (start + bytes.count - 4 * 2).toHex(6) + " <> <> ")
    }
    private fun insertIsItemTmHm2(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.InsertIsItemTmHm2/1 cs:567-579*/
        // does the same thing as IsItemTmHm, but leaves r0 alone.
        // r1 is {0,1,2} for {none,tm,hm} and r0 is the itemID.
        val model = viewPort.model
        val start = lookup(isItemTmHm2, game)
        val code = codeLines("""
        IsItemTmHm2:
            push  lr, {r0}
            bl    <${lookup(isItemTmHm, game).toHex(6)}>
            pop   pc, {r0}
        """)
        val bytes = compile(viewPort, start, code)
    }
    private fun patchItemRemovalFunctions(viewPort: ViewPort, game: String) { /*@DONE MakeTmsExpandable.PatchItemRemovalFunctions/1 cs:581-608*/
        val model = viewPort.model
        val deleteLocation = 0x09A1D8 // ReduceItemCount[game]
        var start = 0x124F6A // ItemRemoval1[game];
        var length = 9 * 2
        var code = codeLines("""
            ldrh  r0, [r7, #0]
            bl    <${lookup(isItemTmHm, game).toHex(6)}>
            cmp   r1, #2
            beq   <${(start + length).toHex(6)}>
            ldrh  r0, [r7, #0]
            mov   r1, #1
            bl    <${deleteLocation.toHex(6)}>
        """)
        compile(viewPort, start, code)

        start = 0x125C74 // ItemRemoval2[game];
        length = 8 * 2
        code = codeLines("""
            mov   r0, r4
            bl    <${lookup(isItemTmHm2, game).toHex(6)}>
            cmp   r1, #2
            beq   <${(start + length).toHex(6)}>
            mov   r1, #1
            bl    <${deleteLocation.toHex(6)}>
        """)
        compile(viewPort, start, code)
    }
    override fun tabChanged() { /*@DONE MakeTmsExpandable.TabChanged/1 cs:610-610*/
        canRunChanged(this, EventArgs.empty)
    }
    companion object {
        const val hmCompatibility: String = "hmcompatibility"
        /*@END MakeTmsExpandable.Companion*/
    }
    /*@ADD MakeTmsExpandable#quickedit_f.txt*/
    private fun codeLines(code: String): Array<String> = code.split(NEW_LINE).filter { it.isNotBlank() }.toTypedArray()
    private fun lookup(table: Map<String, Int>, game: String): Int = table[game] ?: throw IllegalStateException("The game code " + game + " is not supported by this change.")
    /*@ENDADD MakeTmsExpandable#quickedit_f.txt*/
    /*@END MakeTmsExpandable*/
}
