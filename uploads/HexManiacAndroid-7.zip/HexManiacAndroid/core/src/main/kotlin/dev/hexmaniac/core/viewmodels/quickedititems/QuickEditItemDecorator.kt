// Port of Core/Autos/QuickEditItemDecorator.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*

open class QuickEditItemDecorator : IQuickEditItem { // cs:4-83
    protected var innerQuickEditItem: IQuickEditItem? = null
    override fun canRun(viewPort: IViewPort): Boolean { /*@DONE QuickEditItemDecorator.CanRun/1 cs:7-14*/
        val inner = innerQuickEditItem
        if (inner != null) return inner.canRun(viewPort)
        return false
    }
    override fun run(viewPort: IViewPort): Task<ErrorInfo>? { /*@DONE QuickEditItemDecorator.Run/1 cs:16-23*/
        val inner = innerQuickEditItem
        if (inner != null) return inner.run(viewPort)
        return null
    }
    override fun tabChanged() { /*@DONE QuickEditItemDecorator.TabChanged/1 cs:25-31*/
        innerQuickEditItem?.tabChanged()
    }
    override val name: String?
        get() { /*@DONE QuickEditItemDecorator.Name.get cs:35-42*/
            return innerQuickEditItem?.name
        }
    override val description: String?
        get() { /*@DONE QuickEditItemDecorator.Description.get cs:46-53*/
            return innerQuickEditItem?.description
        }
    override val wikiLink: String?
        get() { /*@DONE QuickEditItemDecorator.WikiLink.get cs:57-64*/
            return innerQuickEditItem?.wikiLink
        }
    override val canRunChanged = Event<EventArgs>()
    /*@END QuickEditItemDecorator*/
}
