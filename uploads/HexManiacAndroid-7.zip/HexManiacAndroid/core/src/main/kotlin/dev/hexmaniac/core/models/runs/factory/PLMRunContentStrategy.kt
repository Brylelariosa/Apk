// Port of Models/Runs/Factory/PLMRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class PLMRunContentStrategy : RunStrategy() { // cs:9-37
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE PLMRunContentStrategy.LengthForNewRun/1 cs:10-10*/
        return 2
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE PLMRunContentStrategy.TryAddFormatAtDestination/1 cs:11-19*/
        val plmRun = PLMRun(owner, destination)
        val length = plmRun.length
        if (length < 2) return false

        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, plmRun)

        return true
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE PLMRunContentStrategy.Matches/1 cs:20-20*/
        return run is PLMRun
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE PLMRunContentStrategy.WriteNewRun/1 cs:21-24*/
        // PLM ends with FFFF, and this is already freespace, so just add the format.
        return PLMRun(owner, destination)
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE PLMRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:25-31*/
        val runAttempt = PLMRun(model, run.value.start)
        if (runAttempt.length > 0) {
            val merged = runAttempt.mergeAnchor(run.value.pointerSources)
            run.value = merged
            model.clearFormat(token, merged.start, merged.length)
        }
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE PLMRunContentStrategy.TryParseData/1 cs:32-36*/
        val plmRun = PLMRun(model, dataIndex)
        run.value = plmRun
        if (plmRun.length == 0) return ErrorInfo("Format specified was for pokemon level-up move data, but could not parse that location as level-up move data.")
        return ErrorInfo.noError
    }
    /*@END PLMRunContentStrategy*/
}
