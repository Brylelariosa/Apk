// Port of ViewModels/Tools/TupleArrayElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.runs.*

open class TupleArrayElementViewModel : ViewModelCore, IArrayElementViewModel { // cs:7-56
    private var _visible: Boolean = false
    override var visible: Boolean
        get() { /*@DONE TupleArrayElementViewModel.Visible.get cs:9-9*/
            return _visible
        }
        set(value) { /*@DONE TupleArrayElementViewModel.Visible.set cs:9-9*/
            set(_visible, value, "visible", { _visible = it })
        }
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE TupleArrayElementViewModel.Theme.get cs:10-10*/
            return _theme
        }
        set(value) { /*@DONE TupleArrayElementViewModel.Theme.set cs:10-10*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE TupleArrayElementViewModel.IsInError.get cs:11-11*/
            return false
        }
    override val errorText: String?
        get() { /*@DONE TupleArrayElementViewModel.ErrorText.get cs:12-12*/
            return ""
        }
    override val zIndex: Int
        get() { /*@DONE TupleArrayElementViewModel.ZIndex.get cs:13-13*/
            return 0
        }
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    private fun raiseDataChanged() { /*@DONE TupleArrayElementViewModel.RaiseDataChanged/1 cs:16-16*/
        dataChanged(this, EventArgs.empty)
    }
    private fun raiseDataSelected() { /*@DONE TupleArrayElementViewModel.RaiseDataSelected/1 cs:17-17*/
        dataSelected(this, EventArgs.empty)
    }
    var name: String = ""
        private set
    var children: ObservableCollection<ITupleElementViewModel> = ObservableCollection()
        private set
    constructor(viewPort: ViewPort, tupleItem: ArrayRunTupleSegment, start: Int) { /*@DONE TupleArrayElementViewModel.<init>/1 cs:22-43*/
        children = ObservableCollection()
        name = tupleItem.name
        var bitOffset = 0
        for (i in 0 until tupleItem.elements.size) {
            var child: ITupleElementViewModel? = null
            val element = tupleItem.elements[i]
            if (element.name.isEmpty()) {
                // don't make a viewmodel for unnamed tuple item elements
            } else if (element.bitWidth == 1) {
                child = CheckBoxTupleElementViewModel(viewPort, start, bitOffset, element, this::raiseDataChanged)
            } else if (element.sourceName.isNotEmpty()) {
                child = EnumTupleElementViewModel(viewPort, start, bitOffset, element, this::raiseDataChanged, this::raiseDataSelected)
            } else {
                child = NumericTupleElementViewModel(viewPort, start, bitOffset, element, this::raiseDataChanged, this::raiseDataSelected)
            }
            if (child != null) {
                children.add(child)
                addSilentChild(child)
            }
            bitOffset += element.bitWidth
        }
    }
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE TupleArrayElementViewModel.TryCopy/1 cs:45-55*/
        val that = other as? TupleArrayElementViewModel ?: return false
        if (that.children.size != children.size) return false
        if (name != that.name) return false
        for (i in 0 until children.size) {
            if (!children[i].tryCopy(that.children[i])) return false
        }

        visible = that.visible
        return true
    }
    /*@END TupleArrayElementViewModel*/
}

interface ITupleElementViewModel : ICanSilencePropertyNotifications { // cs:58-64
    val name: String
    val bitOffset: Int
    val bitLength: Int
    val start: Int
    fun tryCopy(other: ITupleElementViewModel): Boolean
    /*@END ITupleElementViewModel*/
}

open class NumericTupleElementViewModel : ViewModelCore, ITupleElementViewModel { // cs:66-104
    private lateinit var seg: TupleSegment
    private lateinit var viewPort: ViewPort
    override val name: String
        get() { /*@DONE NumericTupleElementViewModel.Name.get cs:69-69*/
            return seg.name
        }
    final override var bitOffset: Int = 0
        private set
    override val bitLength: Int
        get() { /*@DONE NumericTupleElementViewModel.BitLength.get cs:71-71*/
            return seg.bitWidth
        }
    final override var start: Int = 0
        private set
    private lateinit var raiseDataChanged: () -> Unit
        private set
    private var raiseDataSelected: (() -> Unit)? = null
        private set
    var content: Int
        get() { /*@DONE NumericTupleElementViewModel.Content.get cs:77-77*/
            return seg.read(viewPort.model, start, bitOffset)
        }
        set(value) { /*@DONE NumericTupleElementViewModel.Content.set cs:78-82*/
            seg.write(viewPort.model, viewPort.currentChange, start, bitOffset, value)
            notifyPropertyChanged("content")
            raiseDataChanged()
        }
    constructor(viewPort: ViewPort, start: Int, bitOffset: Int, segment: TupleSegment, raiseDataChanged: () -> Unit, raiseDataSelected: () -> Unit) { /*@DONE NumericTupleElementViewModel.<init>/1 cs:85-89*/
        this.viewPort = viewPort
        this.seg = segment
        this.start = start
        this.bitOffset = bitOffset
        this.raiseDataChanged = raiseDataChanged
        this.raiseDataSelected = raiseDataSelected
    }
    override fun tryCopy(other: ITupleElementViewModel): Boolean { /*@DONE NumericTupleElementViewModel.TryCopy/1 cs:91-101*/
        val that = other as? NumericTupleElementViewModel ?: return false
        if (name != that.name) return false
        if (bitOffset != that.bitOffset) return false
        if (bitLength != that.bitLength) return false

        start = that.start
        notifyPropertyChanged("start")
        notifyPropertyChanged("content")
        return true
    }
    fun focus() { /*@DONE NumericTupleElementViewModel.Focus/1 cs:103-103*/
        raiseDataSelected?.invoke()
    }
    /*@END NumericTupleElementViewModel*/
}

open class CheckBoxTupleElementViewModel : ViewModelCore, ITupleElementViewModel { // cs:106-142
    private lateinit var seg: TupleSegment
    private lateinit var viewPort: ViewPort
    private lateinit var raiseDataChanged: () -> Unit
        private set
    override val name: String
        get() { /*@DONE CheckBoxTupleElementViewModel.Name.get cs:110-110*/
            return seg.name
        }
    final override var bitOffset: Int = 0
        private set
    override val bitLength: Int
        get() { /*@DONE CheckBoxTupleElementViewModel.BitLength.get cs:112-112*/
            return 1
        }
    final override var start: Int = 0
        private set
    var isChecked: Boolean
        get() { /*@DONE CheckBoxTupleElementViewModel.IsChecked.get cs:116-116*/
            return seg.read(viewPort.model, start, bitOffset) == 1
        }
        set(value) { /*@DONE CheckBoxTupleElementViewModel.IsChecked.set cs:117-122*/
            val bit = if (value) 1 else 0
            seg.write(viewPort.model, viewPort.currentChange, start, bitOffset, bit)
            notifyPropertyChanged("isChecked")
            raiseDataChanged()
        }
    constructor(viewPort: ViewPort, start: Int, bitOffset: Int, segment: TupleSegment, raiseDataChanged: () -> Unit) { /*@DONE CheckBoxTupleElementViewModel.<init>/1 cs:125-130*/
        this.viewPort = viewPort
        this.seg = segment
        this.start = start
        this.bitOffset = bitOffset
        this.raiseDataChanged = raiseDataChanged
    }
    override fun tryCopy(other: ITupleElementViewModel): Boolean { /*@DONE CheckBoxTupleElementViewModel.TryCopy/1 cs:132-141*/
        val that = other as? CheckBoxTupleElementViewModel ?: return false
        if (name != that.name) return false
        if (bitOffset != that.bitOffset) return false

        start = that.start
        notifyPropertyChanged("start")
        notifyPropertyChanged("isChecked")
        return true
    }
    /*@END CheckBoxTupleElementViewModel*/
}

open class EnumTupleElementViewModel : ViewModelCore, ITupleElementViewModel { // cs:144-189
    private lateinit var seg: TupleSegment
    private lateinit var viewPort: ViewPort
    override val name: String
        get() { /*@DONE EnumTupleElementViewModel.Name.get cs:147-147*/
            return seg.name
        }
    final override var bitOffset: Int = 0
        private set
    override val bitLength: Int
        get() { /*@DONE EnumTupleElementViewModel.BitLength.get cs:149-149*/
            return seg.bitWidth
        }
    final override var start: Int = 0
        private set
    val enumName: String
        get() { /*@DONE EnumTupleElementViewModel.EnumName.get cs:151-151*/
            return seg.sourceName
        }
    private lateinit var raiseDataChanged: () -> Unit
        private set
    private var raiseDataSelected: (() -> Unit)? = null
        private set
    var filteringComboOptions: FilteringComboOptions = /*@INITDONE EnumTupleElementViewModel.FilteringComboOptions cs:155-155*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    constructor(viewPort: ViewPort, start: Int, bitOffset: Int, segment: TupleSegment, raiseDataChanged: () -> Unit, raiseDataSelected: () -> Unit) { /*@DONE EnumTupleElementViewModel.<init>/1 cs:157-169*/
        this.viewPort = viewPort
        this.start = start
        this.bitOffset = bitOffset
        this.seg = segment
        addSilentChild(filteringComboOptions)
        this.raiseDataChanged = raiseDataChanged
        this.raiseDataSelected = raiseDataSelected

        filteringComboOptions.update(ComboOption.convert(ArrayRunEnumSegment.getOptions(viewPort.model, enumName) ?: ArrayList<String>()) ?: ArrayList<ComboOption>(), seg.read(viewPort.model, this.start, this.bitOffset))
        filteringComboOptions.bind("modelValue") { _, _ ->
            if (!copying) {
                seg.write(viewPort.model, viewPort.currentChange, this.start, this.bitOffset, filteringComboOptions.modelValue)
                this.raiseDataChanged()
            }
        }
    }
    private var copying: Boolean = false
    override fun tryCopy(other: ITupleElementViewModel): Boolean { /*@DONE EnumTupleElementViewModel.TryCopy/1 cs:172-186*/
        val that = other as? EnumTupleElementViewModel ?: return false
        if (enumName != that.enumName) return false
        if (name != that.name) return false
        if (bitOffset != that.bitOffset) return false
        if (bitLength != that.bitLength) return false

        start = that.start
        scope(copying, true, { copying = it }, { copying = it }).using {
            filteringComboOptions.update(that.filteringComboOptions.allOptions ?: ArrayList<ComboOption>(), that.filteringComboOptions.selectedIndex)
        }
        notifyPropertyChanged("start")

        return true
    }
    fun focus() { /*@DONE EnumTupleElementViewModel.Focus/1 cs:188-188*/
        raiseDataSelected?.invoke()
    }
    /*@END EnumTupleElementViewModel*/
}
