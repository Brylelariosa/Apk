// Port of Models/Runs/PLMRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class PLMRun : BaseRun, IStreamRun, IAppendToBuilderRun { // cs:14-162
    private lateinit var model: IDataModel
    final override var length: Int = 0
        private set
    override val formatString: String
        get() { /*@DONE PLMRun.FormatString.get cs:19-19*/
            return sharedFormatString
        }
    constructor(dataModel: IDataModel, start: Int, pointerSources: SortedSpan<Int>? = null) : super(start, pointerSources) { /*@DONE PLMRun.<init>/1 cs:21-36*/
        model = dataModel
        val moveNames = dataModel.getOptions(HardcodeTablesModel.moveNamesTable)
        length = 1
        var i = start
        while (i < model.count) {
            val value = model.readMultiByteValue(i, 2)
            if (value == 0xFFFF) {
                length = i - start + 2
                break
            }
            // validate value
            val (level, move) = splitToken(value)
            if (level > 101 || level < 1) break
            if (move > moveNames.size) break
            i += 2
        }
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE PLMRun.CreateDataFormat/1 cs:46-56*/
        val moveNames = model.getOptions(HardcodeTablesModel.moveNamesTable)
        var position = index - start
        val groupStart = if (position % 2 == 1) position - 1 else position
        position -= groupStart
        val value = data.readMultiByteValue(start + groupStart, 2)
        val (level, move) = splitToken(value)
        val moveName = if (moveNames.size > move) moveNames[move] else move.toString()
        return PlmItem(groupStart + start, position, level, move, moveName)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE PLMRun.Clone/1 cs:58-58*/
        return PLMRun(model, start, newPointerSources)
    }
    fun tryGetMoveNumber(moveName: String, move: Ref<Int>): Boolean { /*@DONE PLMRun.TryGetMoveNumber/1 cs:60-74*/
        val name = moveName.trim('"').lowercase()
        val moveNames = model.getOptions(HardcodeTablesModel.moveNamesTable)
        val names = moveNames.map { n -> n.trim('"').lowercase() }

        // perfect match?
        move.value = names.indexOf(name)
        if (move.value != -1) return true

        // partial match?
        move.value = names.indexOfPartial(name)
        if (move.value != -1) return true

        // last try: numeric match
        if (tryParseInt(name, move)) return true
        move.value = 0
        return false
    }
    fun getAutoCompleteOptions(header: String): Iterable<String> { /*@DONE PLMRun.GetAutoCompleteOptions/1 cs:76-79*/
        val moveNames = model.getOptions(HardcodeTablesModel.moveNamesTable)
        return moveNames.map { name -> header + " " + name + (if (name.endsWith("\"")) "" else " ") } // autocomplete needs to complete after selection, so add a space if there's no quotes
    }
    override fun serializeRun(): String? { /*@DONE PLMRun.SerializeRun/1 cs:81-92*/
        val moveNames = model.getOptions(HardcodeTablesModel.moveNamesTable)
        val builder = StringBuilder()
        var i = 0
        while (i < length - 2) {
            val address = start + i
            val (level, move) = splitToken(model.readMultiByteValue(address, 2))
            val moveName = if (moveNames.size > move) moveNames[move] else move.toString()
            builder.append(level.toString() + " " + moveName)
            if (i < length - 4) builder.append(NEW_LINE)
            i += 2
        }
        return builder.toString()
    }
    override fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, changedRuns: Ref<List<Int>?>): IStreamRun { /*@DONE PLMRun.DeserializeRun/1 cs:94-126*/
        changedRuns.value = ArrayList<Int>()
        val data = ArrayList<Int>()
        val changedAddresses = LinkedHashSet<Int>()
        var moveNames = model.getOptions(HardcodeTablesModel.moveNamesTable)
        moveNames = moveNames.map { name -> name.trim('"').lowercase() }

        val lines = content.lowercase().split(NEW_LINE).filter { line -> line.length > 0 }
        for (line in lines) {
            val parts = line.split(' ', limit = 2)
            val level = Ref(0)
            if (!tryParseInt(parts[0], level)) continue
            var moveName = if (parts.size == 1) "0" else parts[1]
            moveName = moveName.trim().trim('"')

            val index = moveNames.indexOf(moveName)
            if (index != -1) { data.add(combineToken(level.value, index)); continue }

            // look for a partial move match
            for (i in 0 until moveNames.size) {
                if (moveNames[i].matchesPartial(moveName)) { data.add(combineToken(level.value, i)); break }
            }
        }

        val run = model.relocateForExpansion(token, this, data.size * 2 + 2)
        for (i in 0 until data.size) {
            if (model.writeMultiByteValue(run.start + i * 2, 2, token, data[i])) changedAddresses.add(run.start + i * 2)
        }
        model.writeMultiByteValue(run.start + data.size * 2, 2, token, EggMoveRun.endStream) // write the new end token (not tracked)
        for (i in data.size * 2 + 2 until length) token.changeData(model, run.start + i, 0xFF) // fill any remaining old space with FF (not tracked)

        changedOffsets.value = ArrayList<Int>(changedAddresses)
        return PLMRun(model, run.start)
    }
    override fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem> { /*@DONE PLMRun.GetAutoCompleteOptions/2 cs:128-131*/
        val result = ArrayList<AutocompleteItem>()
        return result
    }
    override val visualizations: List<IPixelViewModel>
        get() { /*@DONE PLMRun.Visualizations.get cs:133-133*/
            return ArrayList<IPixelViewModel>()
        }
    final override var preFormatter: ITextPreProcessor? = null
        private set
    override fun dependsOn(anchorName: String): Boolean { /*@DONE PLMRun.DependsOn/1 cs:135-135*/
        return anchorName == HardcodeTablesModel.moveNamesTable
    }
    fun search(index: Int): Iterable<PLMRunSearchTuple> { /*@DONE PLMRun.Search/1 cs:137-144*/
        val result = ArrayList<PLMRunSearchTuple>()
        var i = 0
        while (i < length - 2) {
            val fullValue = model.readMultiByteValue(start + i, 2)
            if (splitToken(fullValue).move == index) {
                result.add(PLMRunSearchTuple(start + i, start + i + 1))
            }
            i += 2
        }
        return result
    }
    override fun appendTo(model: IDataModel, text: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE PLMRun.AppendTo/1 cs:146-155*/
        val moveNames = model.getOptions(HardcodeTablesModel.moveNamesTable)
        var i = 0
        while (i < length && i < this.length) {
            if (i > 0) text.append(" ")
            if (i + start - this.start == this.length - 2) { text.append("[]"); i += 2; continue }
            val (level, move) = splitToken(model.readMultiByteValue(start + i, 2))
            val moveName = if (moveNames.size > move) moveNames[move] else move.toString()
            text.append(level.toString() + " " + moveName + ",")
            i += 2
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE PLMRun.Clear/1 cs:157-161*/
        for (i in 0 until length) {
            changeToken.changeData(model, start + i, 0x00)
        }
    }
    companion object {
        const val maxLearningLevel: Int = 100
        val sharedFormatString: String = /*@INITDONE PLMRun.SharedFormatString cs:16-16*/ AsciiRun.streamDelimeter.toString() + "plm" + AsciiRun.streamDelimeter /*@ENDINIT*/
        fun splitToken(value: Int): PLMRunSplitTokenTuple { /*@DONE PLMRun.SplitToken/1 cs:38-42*/
            val level = (value and 0xFE00) shr 9
            val move = (value and 0x1FF)
            return PLMRunSplitTokenTuple(level, move)
        }
        fun combineToken(level: Int, move: Int): Int { /*@DONE PLMRun.CombineToken/1 cs:44-44*/
            return (level shl 9) or move
        }
        /*@END PLMRun.Companion*/
    }
    /*@END PLMRun*/
}

data class PLMRunSearchTuple(val item1: Int, val item2: Int)

data class PLMRunSplitTokenTuple(val level: Int, val move: Int)
