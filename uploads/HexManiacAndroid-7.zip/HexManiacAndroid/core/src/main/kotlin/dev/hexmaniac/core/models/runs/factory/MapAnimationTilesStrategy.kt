// Port of Models/Runs/Factory/MapAnimationTilesStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class MapAnimationTilesStrategy : RunStrategy() { // cs:10-51
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE MapAnimationTilesStrategy.LengthForNewRun/1 cs:13-15*/
        return 4
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE MapAnimationTilesStrategy.Matches/1 cs:17-23*/
        if (run !is TableStreamRun) return false
        if (!run.allowsZeroElements) return false
        if (run.elementContent.size != 1) return false
        val pointerSegment = run.elementContent[0] as? ArrayRunPointerSegment ?: return false
        return (pointerSegment.innerFormat.startsWith("`uct4x") && pointerSegment.innerFormat.endsWith("`"))
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE MapAnimationTilesStrategy.TryAddFormatAtDestination/1 cs:25-31*/
        val runRef = Ref<IFormattedRun?>(NoInfoRun(destination, SortedSpanStatic.one(source)))
        val result = tryParseData(owner, "", 0, runRef)
        if (result != null && result.hasError) return false
        owner.observeRunWritten(token, runRef.value!!)
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE MapAnimationTilesStrategy.TryParseData/1 cs:33-41*/
        val current = run.value
        val sources = current?.pointerSources
        if (current == null || sources == null || sources.size == 0) return ErrorInfo("Map animation tiles need a pointer source.")
        val source = sources[0]
        val destination = current.start
        // if (model.GetNextRun(source) is not ITableRun parentRun) return new ErrorInfo("No parent!");
        // if (!parentRun.ElementContent.Any(seg => seg.Name == MapAnimationTilesRun.ParentTileCountField)) return new ErrorInfo("No tile field!");
        // if (!parentRun.ElementContent.Any(seg => seg.Name == MapAnimationTilesRun.ParentFrameCountField)) return new ErrorInfo("No frame field!");
        run.value = MapAnimationTilesRun(model, destination, SortedSpanStatic.one(source))
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE MapAnimationTilesStrategy.UpdateNewRunFromPointerFormat/1 cs:43-46*/
        val current = Ref<IFormattedRun?>(run.value)
        tryParseData(model, name, 0, current)
        val updated = current.value ?: run.value
        run.value = updated
        model.clearFormat(token, updated.start, updated.length)
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE MapAnimationTilesStrategy.WriteNewRun/1 cs:48-50*/
        return MapAnimationTilesRun(owner, destination, SortedSpanStatic.one(source))
    }
    /*@END MapAnimationTilesStrategy*/
}
