// Port of ViewModels/Tools/IndexComboBoxViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class IndexComboBoxViewModel : ViewModelCore { // cs:8-81
    private var allOptions: MutableList<String>? = /*@INITAUTO IndexComboBoxViewModel.allOptions cs:9-9*/ ArrayList() /*@ENDINIT*/
    private var _selectedIndex: Int = 0
    private var selectedVisibleIndex: Int = 0
    private var _text: String = ""
    var options: List<String> = ArrayList()
        private set
    var text: String?
        get() { /*@DONE IndexComboBoxViewModel.Text.get cs:15-15*/
            return _text
        }
        set(value) { /*@DONE IndexComboBoxViewModel.Text.set cs:16-19*/
            if (resetting) return
            set(_text, value ?: "", "text", { _text = it }, { old -> textChanged(old) })
        }
    var selectedIndex: Int
        get() { /*@DONE IndexComboBoxViewModel.SelectedIndex.get cs:23-23*/
            return selectedVisibleIndex
        }
        set(value) { /*@DONE IndexComboBoxViewModel.SelectedIndex.set cs:24-31*/
            if (value == -1) return
            if (selectedVisibleIndex != value && !resetting) {
                _selectedIndex = allOptions!!.indexOf(options[value])
                resetFilter()
                updateSelection(this, EventArgs.empty)
            }
        }
    val updateSelection = Event<EventArgs>()
    var model: IDataModel? = null
        private set
    constructor(model: IDataModel) { /*@DONE IndexComboBoxViewModel.<init>/1 cs:37-37*/
        this.model = model
    }
    fun setupFromModel(address: Int) { /*@DONE IndexComboBoxViewModel.SetupFromModel/1 cs:39-49*/
        val tableRun = model!!.getNextRun(address) as? ITableRun
        if (tableRun == null) return
        val offset = tableRun.convertByteOffsetToArrayOffset(address)
        val names: MutableList<String> = tableRun.elementNames?.toMutableList() ?: (0 until tableRun.elementCount).map { i -> i.toString() }.toMutableList()
        while (names.size < tableRun.elementCount) {
            names.add(names.size.toString())
        }
        allOptions = names
        _selectedIndex = offset.elementIndex
        resetFilter()
    }
    fun completeFilterInteraction() { /*@DONE IndexComboBoxViewModel.CompleteFilterInteraction/1 cs:51-60*/
        if (options.size == 0) {
            _selectedIndex = 0
        } else {
            _selectedIndex = allOptions!!.indexOf(options[0])
        }

        resetFilter()
        updateSelection(this, EventArgs.empty)
    }
    private fun textChanged(old: String) { /*@DONE IndexComboBoxViewModel.TextChanged/1 cs:62-66*/
        val everything = allOptions!!
        options = everything.filter { option -> option.matchesPartial(_text) }.toList()
        selectedVisibleIndex = options.indexOf(everything[_selectedIndex])
        notifyProperties("options", "selectedIndex")
    }
    private var resetting: Boolean = false
    private fun resetFilter() { /*@DONE IndexComboBoxViewModel.ResetFilter/1 cs:69-76*/
        resetting = true
        val everything = allOptions!!
        options = everything
        selectedVisibleIndex = _selectedIndex
        _text = everything[_selectedIndex]
        notifyProperties("options", "selectedIndex", "text")
        resetting = false
    }
    private fun notifyProperties(vararg props: String) { /*@DONE IndexComboBoxViewModel.NotifyProperties/1 cs:78-80*/
        for (prop in props) notifyPropertyChanged(prop)
    }
    /*@END IndexComboBoxViewModel*/
}
