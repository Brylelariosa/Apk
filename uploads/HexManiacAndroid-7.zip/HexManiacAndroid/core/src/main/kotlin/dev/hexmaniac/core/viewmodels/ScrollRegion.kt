// Port of ViewModels/ScrollRegion.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.tools.*

typealias TryGetUsefulHeader = (Int, Ref<String?>) -> Boolean // cs:10-10

open class ScrollRegion : ViewModelCore { // cs:12-276
    private lateinit var _scroll: StubCommand
    private lateinit var tryGetUsefulHeader: TryGetUsefulHeader
    private var raiseErrorTab: IRaiseErrorTab? = null
    private var _dataIndex: Int = 0
    private var _width: Int = 0
    private var _height: Int = 0
    private var _scrollValue: Int = 0
    private var _maximumScroll: Int = 0
    private var _dataLength: Int = 0
    private var tableStart: Int = 0
    private var tableLength: Int = 0
    private var allowTableMode: Boolean = false
    var allowSingleTableMode: Boolean
        get() { /*@DONE ScrollRegion.AllowSingleTableMode.get cs:29-29*/
            return allowTableMode
        }
        set(value) { /*@DONE ScrollRegion.AllowSingleTableMode.set cs:29-29*/
            set(allowTableMode, value, "allowSingleTableMode", { allowTableMode = it }) { clearTableMode() }
        }
    var scheduler: IToolTrayViewModel? = null
    val scroll: ICommand
        get() { /*@DONE ScrollRegion.Scroll.get cs:33-33*/
            return _scroll
        }
    var dataIndex: Int
        get() { /*@DONE ScrollRegion.DataIndex.get cs:36-36*/
            return _dataIndex
        }
        private set(value) { /*@DONE ScrollRegion.DataIndex.set cs:37-43*/
            val dif = value - _dataIndex
            if (tryUpdate(_dataIndex, value, "dataIndex") { _dataIndex = it }) {
                scrollChanged(this, dif)
                updateScrollRange()
            }
        }
    var width: Int
        get() { /*@DONE ScrollRegion.Width.get cs:47-47*/
            return _width
        }
        set(value) { /*@DONE ScrollRegion.Width.set cs:48-56*/
            // do the update manually so that we don't notify value change until after calling UpdateScrollRange
            val value = value.limitToRange(4, Int.MAX_VALUE)
            if (value == _width) return
            val oldWidth = _width
            _width = value
            updateScrollRange()
            notifyPropertyChanged(oldWidth, "width")
        }
    var height: Int
        get() { /*@DONE ScrollRegion.Height.get cs:60-60*/
            return _height
        }
        set(value) { /*@DONE ScrollRegion.Height.set cs:61-69*/
            // do the update manually so that we don't notify value change until after calling UpdateScrollRange
            val value = value.limitToRange(1, Int.MAX_VALUE)
            if (value == _height) return
            val oldHeight = _height
            _height = value
            updateScrollRange()
            notifyPropertyChanged(oldHeight, "height")
        }
    var scrollValue: Int
        get() { /*@DONE ScrollRegion.ScrollValue.get cs:73-73*/
            return _scrollValue
        }
        set(value) { /*@DONE ScrollRegion.ScrollValue.set cs:74-81*/
            val value = value.limitToRange(minimumScroll, maximumScroll)
            val dif = value - _scrollValue
            if (dif == 0) return

            dataIndex += dif * _width
            notifyPropertyChanged(value - dif, "scrollValue")
        }
    val isSingleTableMode: Boolean
        get() { /*@DONE ScrollRegion.IsSingleTableMode.get cs:84-84*/
            return tableLength != 0
        }
    val minimumScroll: Int
        get() { /*@DONE ScrollRegion.MinimumScroll.get cs:87-91*/
            if (tableLength == 0) return 0
            val effectiveDataStart = calculateEffectiveDataLength(tableStart)
            return effectiveDataStart / _width
        }
    var maximumScroll: Int
        get() { /*@DONE ScrollRegion.MaximumScroll.get cs:95-100*/
            if (tableLength == 0) return _maximumScroll
            val effectiveDataLength = calculateEffectiveDataLength(tableStart + tableLength)
            val lineCount = Math.ceil(effectiveDataLength.toDouble() / _width).toInt()
            return Math.max(lineCount - 1, 0)
        }
        private set(value) { /*@DONE ScrollRegion.MaximumScroll.set cs:101-101*/
            tryUpdate(_maximumScroll, value, "maximumScroll") { _maximumScroll = it }
        }
    private var _useCustomHeaders: Boolean = false
    var useCustomHeaders: Boolean
        get() { /*@DONE ScrollRegion.UseCustomHeaders.get cs:106-106*/
            return _useCustomHeaders
        }
        set(value) { /*@DONE ScrollRegion.UseCustomHeaders.set cs:107-109*/
            if (tryUpdate(_useCustomHeaders, value, "useCustomHeaders") { _useCustomHeaders = it }) updateHeaders()
        }
    val dataStart: Int
        get() { /*@DONE ScrollRegion.DataStart.get cs:112-112*/
            return if (tableLength == 0) 0 else tableStart
        }
    var dataLength: Int
        get() { /*@DONE ScrollRegion.DataLength.get cs:115-118*/
            if (tableLength == 0) return _dataLength
            return tableStart + tableLength
        }
        set(value) { /*@DONE ScrollRegion.DataLength.set cs:119-126*/
            if (tryUpdate(_dataLength, value, "dataLength") { _dataLength = it }) {
                updateScrollRange()
                if (_dataLength > 0x2000000) {
                    raiseErrorTab?.raiseError("gba games cannot be longer than 0x2000000 bytes.")
                }
            }
        }
    var headers: ObservableCollection<RowHeader> = /*@INITAUTO ScrollRegion.Headers cs:129-129*/ ObservableCollection() /*@ENDINIT*/
        private set
    val scrollChanged = Event<Int>()
    val headersChanged = Event<EventArgs>()
    constructor(headerStratey: TryGetUsefulHeader? = null, raiseErrorTab: IRaiseErrorTab? = null) { /*@DONE ScrollRegion.<init>/1 cs:136-146*/
        tryGetUsefulHeader = headerStratey ?: { address, header -> defaultHeaderStrategy(address, header) }
        _width = 4
        _height = 4
        this.raiseErrorTab = raiseErrorTab
        _scroll = StubCommand().also {
            it.canExecute = { _ -> _dataLength > 0 }
            it.execute = { args -> scrollExecuted(args as Direction) }
        }
        updateHeaders()
    }
    fun viewPointToDataIndex(p: Point): Int { /*@DONE ScrollRegion.ViewPointToDataIndex/1 cs:148-148*/
        return p.y * _width + p.x + _dataIndex
    }
    fun dataIndexToViewPoint(index: Int): Point { /*@DONE ScrollRegion.DataIndexToViewPoint/1 cs:150-157*/
        val index = index - _dataIndex
        return if (index >= 0) {
            Point(index % _width, index / _width)
        } else {
            Point(_width - ((-index) % _width), index / _width - 1)
        }
    }
    fun scrollToPoint(point: Ref<Point>): Boolean { /*@DONE ScrollRegion.ScrollToPoint/1 cs:164-181*/
        var p = point.value
        while (p.x < 0) p += Point(_width, -1)
        while (p.x >= _width) p -= Point(_width, -1)
        point.value = p

        if (p.y < 0) {
            scrollValue += p.y
            point.value = Point(p.x, 0)
            return true
        }

        if (p.y >= _height) {
            scrollValue += p.y + 1 - _height
            point.value = Point(p.x, _height - 1)
            return true
        }

        return false
    }
    fun setTableMode(start: Int, length: Int) { /*@DONE ScrollRegion.SetTableMode/1 cs:183-192*/
        if (tableStart == start && tableLength == length) return
        if (!allowTableMode && length != 0) return
        tableStart = start
        tableLength = length
        notifyPropertyChanged("minimumScroll")
        notifyPropertyChanged("maximumScroll")
        notifyPropertyChanged("dataLength")
        updateHeaders()
    }
    fun clearTableMode() { /*@DONE ScrollRegion.ClearTableMode/1 cs:194-194*/
        setTableMode(0, 0)
    }
    private fun scrollExecuted(direction: Direction) { /*@DONE ScrollRegion.ScrollExecuted/1 cs:196-204*/
        val dif = directionToDif[direction]!!
        if (dif.y != 0) {
            scrollValue += dif.y
        } else {
            dataIndex = (_dataIndex + dif.x).limitToRange(1 - _width, _dataLength - 1)
            clearTableMode()
        }
    }
    private fun updateScrollRange() { /*@DONE ScrollRegion.UpdateScrollRange/1 cs:206-229*/
        if (_width < 1 || _height < 1 || _dataLength < 1) return
        val effectiveDataLength = calculateEffectiveDataLength()
        val lineCount = Math.ceil(effectiveDataLength.toDouble() / _width).toInt()
        if (tableLength != 0) notifyPropertyChanged("minimumScroll")
        maximumScroll = Math.max(lineCount - 1, 0)
        if (minimumScroll > maximumScroll) throw InvalidOperationException("MinimumScroll($minimumScroll) is bigger than MaximumScroll($maximumScroll): TableStart=$tableStart, TableLength=$tableLength, Width=$_width")
        var newCurrentScroll = Math.ceil(_dataIndex.toDouble() / _width).toInt()

        // screen size changes while scrolled above the data can make the data scroll completely out of view
        if (newCurrentScroll < 0) {
            dataIndex += width * -newCurrentScroll
            newCurrentScroll = 0
        }

        // don't notify: the caller will notify if desired.
        _scrollValue = newCurrentScroll

        val tray = scheduler
        if (tray != null) {
            tray.schedule { updateHeaders() }
        } else {
            updateHeaders()
        }
    }
    private var headerNeedsUpdate: Boolean = false
    private var deferHeader: Boolean = false
    fun deferHeader() { /*@DONE ScrollRegion.DeferHeader/1 cs:232-232*/
        deferHeader = true
    }
    fun updateDeferedHeader() { /*@DONE ScrollRegion.UpdateDeferedHeader/1 cs:233-236*/
        deferHeader = false
        if (headerNeedsUpdate) updateHeaders()
    }
    fun updateHeaders() { /*@DONE ScrollRegion.UpdateHeaders/1 cs:238-260*/
        headerNeedsUpdate = deferHeader
        if (deferHeader) return
        while (headers.size > height) headers.removeAt(headers.size - 1)
        for (i in 0 until height) {
            val address = _dataIndex + i * width

            var hexAddress: String
            val useful = Ref<String?>(null)
            if (!_useCustomHeaders || !tryGetUsefulHeader(address, useful)) {
                hexAddress = if (address < 0) "" else address.toHex(6)
            } else {
                hexAddress = useful.value ?: ""
            }

            if (address >= dataLength) hexAddress = ""

            if (headers.size > i) {
                headers[i] = RowHeader.fromString(hexAddress)
            } else {
                headers.add(RowHeader.fromString(hexAddress))
            }
        }

        headersChanged(this, EventArgs.empty)
    }
    private fun calculateEffectiveDataLength(virtualDataLength: Int = -1): Int { /*@DONE ScrollRegion.CalculateEffectiveDataLength/1 cs:267-275*/
        var virtualDataLength = virtualDataLength
        if (virtualDataLength == -1) virtualDataLength = _dataLength
        var effectiveDataLength = virtualDataLength

        val columnOffset = dataIndex % _width
        if (columnOffset != 0) effectiveDataLength += _width - columnOffset

        return effectiveDataLength
    }
    companion object {
        val directionToDif: Map<Direction, Point> = /*@INITDONE ScrollRegion.DirectionToDif cs:13-18*/ 
            linkedMapOf(
                Direction.Up to Point(0, -1),
                Direction.Down to Point(0, 1),
                Direction.Left to Point(-1, 0),
                Direction.Right to Point(1, 0),
            ) /*@ENDINIT*/
        fun defaultHeaderStrategy(address: Int, header: Ref<String?>): Boolean { /*@DONE ScrollRegion.DefaultHeaderStrategy/1 cs:134-134*/
            header.value = null
            return false
        }
        /*@END ScrollRegion.Companion*/
    }
    /*@END ScrollRegion*/
}

open class RowHeader : ViewModelCore() { // cs:278-288
    private var _isSelected: Boolean = false
    var isSelected: Boolean
        get() { /*@DONE RowHeader.IsSelected.get cs:280-280*/
            return _isSelected
        }
        set(value) { /*@DONE RowHeader.IsSelected.set cs:280-280*/
            set(_isSelected, value, "isSelected", { _isSelected = it })
        }
    private var _content: String = ""
    var content: String
        get() { /*@DONE RowHeader.Content.get cs:283-283*/
            return _content
        }
        set(value) { /*@DONE RowHeader.Content.set cs:283-283*/
            set(_content, value, "content", { _content = it })
        }
    // C# RowHeader : IEquatable<RowHeader> (equal when the content is equal)
    override fun equals(other: Any?): Boolean = other is RowHeader && other._content == _content
    override fun hashCode(): Int = _content.hashCode()
    override fun toString(): String = _content
    // conversion from String: use the companion function below
    companion object {
        fun fromString(value: String): RowHeader { /*@DONE RowHeader.op_Implicit/1 cs:285-285*/
            val header = RowHeader()
            header.content = value
            return header
        }
        /*@END RowHeader.Companion*/
    }
    fun equals(other: RowHeader?): Boolean { /*@DONE RowHeader.Equals/1 cs:287-287*/
        return other?._content == _content
    }
    /*@END RowHeader*/
}
