// Port of Models/Runs/Factory/LzTilemapRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class LzTilemapRunContentStrategy : RunStrategy { // cs:5-56
    var tilemapFormat: TilemapFormat = TilemapFormat()
        private set
    constructor(format: TilemapFormat) { /*@DONE LzTilemapRunContentStrategy.<init>/1 cs:7-7*/
        tilemapFormat = format
    }
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE LzTilemapRunContentStrategy.LengthForNewRun/1 cs:9-12*/
        val defaultData = ByteArray(tilemapFormat.bitsPerPixel * 8)
        return LZRun.compress(defaultData.asByteList(), 0, defaultData.size).count
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE LzTilemapRunContentStrategy.Matches/1 cs:14-14*/
        return run is LzTilemapRun && run.format.bitsPerPixel == tilemapFormat.bitsPerPixel
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE LzTilemapRunContentStrategy.TryAddFormatAtDestination/1 cs:16-22*/
        val lzRun = LZRun(owner, destination)
        if (lzRun.decompressedLength != tilemapFormat.expectedUncompressedLength) return false
        val newRun = LzTilemapRun(tilemapFormat, owner, destination)
        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, newRun)
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE LzTilemapRunContentStrategy.TryParseData/1 cs:24-39*/
        val error = SpriteRunContentStrategy.isValid(tilemapFormat)
        if (error.hasError) return error
        val lzRun = LZRun(model, dataIndex)
        val rowRemainder = if (tilemapFormat.tileWidth == 0) 0 else lzRun.decompressedLength % tilemapFormat.tileWidth
        if (rowRemainder != 0) {
            return ErrorInfo(lzRun.decompressedLength.toString() + " cannot be divided into " + tilemapFormat.tileWidth + " columns.")
        }
        if (lzRun.length < 6) {
            return ErrorInfo("Unable to decompress run at " + dataIndex.toHex(6) + ".")
        }

        val newRun = LzTilemapRun(tilemapFormat, model, dataIndex)
        run.value = newRun
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE LzTilemapRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:41-48*/
        val lzRun = LZRun(model, run.value.start)
        if (lzRun.length < 0) return
        if (lzRun.decompressedLength != tilemapFormat.expectedUncompressedLength) return
        val newRun = LzTilemapRun(tilemapFormat, model, run.value.start, run.value.pointerSources)
        model.clearFormat(token, newRun.start, newRun.length)
        run.value = newRun
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE LzTilemapRunContentStrategy.WriteNewRun/1 cs:50-55*/
        val defaultData = ByteArray(tilemapFormat.expectedUncompressedLength)
        val data = LZRun.compress(defaultData.asByteList(), 0, defaultData.size)
        for (i in 0 until data.count) token.changeData(owner, destination + i, data[i])
        return LzTilemapRun(tilemapFormat, owner, destination)
    }
    /*@END LzTilemapRunContentStrategy*/
}
