// Port of Models/Runs/MapAnimationTilesRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class MapAnimationTilesRun : BaseRun, ITableRun, IUpdateFromParentRun { // cs:9-76
    private lateinit var model: IDataModel
    override val canAppend: Boolean
        get() { /*@DONE MapAnimationTilesRun.CanAppend.get cs:15-15*/
            return true
        }
    override val length: Int
        get() { /*@DONE MapAnimationTilesRun.Length.get cs:16-16*/
            return elementCount * elementLength
        }
    override val formatString: String
        get() { /*@DONE MapAnimationTilesRun.FormatString.get cs:17-17*/
            return sharedFormatString
        }
    final override var elementCount: Int = 0
        private set
    override val elementLength: Int
        get() { /*@DONE MapAnimationTilesRun.ElementLength.get cs:19-19*/
            return 4
        }
    override val elementNames: List<String>? = /*@INITAUTO MapAnimationTilesRun.ElementNames cs:20-20*/ ArrayList() /*@ENDINIT*/
    final override var elementContent: List<ArrayRunElementSegment> = ArrayList()
        private set
    override val repointContentShortName: String
        get() { /*@DONE MapAnimationTilesRun.RepointContentShortName.get cs:22-22*/
            return "Tiles"
        }
    constructor(model: IDataModel, start: Int, sources: SortedSpan<Int>?) : super(start, sources) { /*@DONE MapAnimationTilesRun.<init>/1 cs:24-30*/
        this.model = model
        val primarySource = sources?.firstOrNull()
        if (primarySource == null) {
            elementCount = 0
            elementContent = listOf(ArrayRunPointerSegment(model.formatRunFactory, "frame", "`uct4x1`"))
        } else {
            elementCount = model.readMultiByteValue(primarySource + 4, 2)
            val tileCount = model[primarySource + 7]
            elementContent = listOf(ArrayRunPointerSegment(model.formatRunFactory, "frame", "`uct4x" + tileCount + "`"))
        }
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE MapAnimationTilesRun.CreateDataFormat/1 cs:32-32*/
        return this.createSegmentDataFormat(data, index)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE MapAnimationTilesRun.Clone/1 cs:34-34*/
        return MapAnimationTilesRun(model, start, newPointerSources)
    }
    override fun duplicate(start: Int, pointerSources: SortedSpan<Int>?, segments: List<ArrayRunElementSegment>): ITableRun { /*@DONE MapAnimationTilesRun.Duplicate/1 cs:36-38*/
        return MapAnimationTilesRun(model, start, pointerSources)
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE MapAnimationTilesRun.AppendTo/1 cs:40-40*/
        ITableRunExtensions.appendTo(this, model, builder, start, length, depth)
    }
    override fun append(token: ModelDelta, length: Int): ITableRun { /*@DONE MapAnimationTilesRun.Append/1 cs:42-46*/
        val parent = pointerSources!![0]
        model.writeMultiByteValue(parent + 4, 2, token, elementCount + length)
        return updateFromParent(token, 1, parent)
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE MapAnimationTilesRun.Clear/1 cs:48-50*/
        throw NotImplementedException()
    }
    // skipped method UpdateFromParent: explicit implementation merged with the public member
    override fun updateFromParent(token: ModelDelta, segmentIndex: Int, pointerSource: Int): MapAnimationTilesRun { /*@DONE MapAnimationTilesRun.UpdateFromParent/2 cs:53-75*/
        if (segmentIndex == 1) {
            val newTableCount = model.readMultiByteValue(pointerSource + 4, 2)
            val self = model.relocateForExpansion(token, this, newTableCount * 4)
            for (i in elementCount until newTableCount) {
                model.writePointer(token, self.start + 4 * i, Pointer.null_)
            }
            return MapAnimationTilesRun(model, self.start, self.pointerSources)
        } else if (segmentIndex == 3) {
            val newTileCount = model[pointerSource + 7]
            val tilesetFormat = TilesetFormat(4, newTileCount, -1, null)
            for (i in 0 until elementCount) {
                val destination = model.readPointer(start + elementLength * i)
                if (destination == Pointer.null_) continue
                val child = model.getNextRun(destination) as ISpriteRun
                val newChild = model.relocateForExpansion(token, child, newTileCount * 32)
                model.observeRunWritten(token, TilesetRun(tilesetFormat, model, newChild.start, newChild.pointerSources))
            }
            return this
        } else {
            return this
        }
    }
    companion object {
        const val parentTileCountField: String = "tiles"
        const val parentFrameCountField: String = "frames"
        val sharedFormatString: String = /*@INITDONE MapAnimationTilesRun.SharedFormatString cs:12-12*/ AsciiRun.streamDelimeter.toString() + "mat" + AsciiRun.streamDelimeter /*@ENDINIT*/
        /*@END MapAnimationTilesRun.Companion*/
    }
    /*@END MapAnimationTilesRun*/
}
