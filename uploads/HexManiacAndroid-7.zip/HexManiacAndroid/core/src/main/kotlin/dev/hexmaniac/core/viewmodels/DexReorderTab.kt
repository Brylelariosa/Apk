// Port of ViewModels/DexReorderTab.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.viewmodels.tools.*

open class DexReorderTab : ViewModelCore, ITabContent { // cs:14-310
    private lateinit var fs: IFileSystem
    private lateinit var history: ChangeHistory<ModelDelta>
    private lateinit var _model: IDataModel
    private var dexOrder: String = ""
    private var dexInfo: String = ""
    private var isNational: Boolean = false
    private lateinit var _undo: StubCommand
    private lateinit var _redo: StubCommand
    var elements: ObservableCollection<SortablePokemon> = /*@INITAUTO DexReorderTab.Elements cs:22-22*/ ObservableCollection() /*@ENDINIT*/
        private set
    override val name: String
        get() { /*@DONE DexReorderTab.Name.get cs:24-24*/
            return "Adjust Dex Order"
        }
    var fullFileName: String = ""
        private set
    override var spartanMode: Boolean = false
    val model: IDataModel?
        get() { /*@DONE DexReorderTab.Model.get cs:30-30*/
            return _model
        }
    private var _filter: String = /*@INITAUTO DexReorderTab.filter cs:32-32*/ "" /*@ENDINIT*/
    var filter: String
        get() { /*@DONE DexReorderTab.Filter.get cs:34-34*/
            return _filter
        }
        set(value) { /*@DONE DexReorderTab.Filter.set cs:35-38*/
            if (!tryUpdate(_filter, value, "filter") { _filter = it }) return
            for (mon in elements) mon.matchToFilter(_filter)
        }
    override val isMetadataOnlyChange: Boolean
        get() { /*@DONE DexReorderTab.IsMetadataOnlyChange.get cs:41-41*/
            return false
        }
    final override var save: ICommand? = null
        private set
    override lateinit var saveAs: ICommand
    override val exportBackup: ICommand = /*@INITAUTO DexReorderTab.ExportBackup cs:44-44*/ StubCommand() /*@ENDINIT*/
    override val undo: ICommand
        get() { /*@DONE DexReorderTab.Undo.get cs:45-45*/
            return _undo
        }
    override val redo: ICommand
        get() { /*@DONE DexReorderTab.Redo.get cs:46-46*/
            return _redo
        }
    override val copy: ICommand? = /*@INITAUTO DexReorderTab.Copy cs:47-47*/ StubCommand() /*@ENDINIT*/
    override val deepCopy: ICommand = /*@INITAUTO DexReorderTab.DeepCopy cs:48-48*/ StubCommand() /*@ENDINIT*/
    override val diff: ICommand
        get() { /*@DONE DexReorderTab.Diff.get cs:49-49*/
            return disabledCommand
        }
    override val diffLeft: ICommand
        get() { /*@DONE DexReorderTab.DiffLeft.get cs:50-50*/
            return disabledCommand
        }
    override val diffRight: ICommand
        get() { /*@DONE DexReorderTab.DiffRight.get cs:51-51*/
            return disabledCommand
        }
    override val clear: ICommand? = /*@INITAUTO DexReorderTab.Clear cs:52-52*/ StubCommand() /*@ENDINIT*/
    override val selectAll: ICommand = /*@INITAUTO DexReorderTab.SelectAll cs:53-53*/ StubCommand() /*@ENDINIT*/
    override val goto: ICommand? = /*@INITAUTO DexReorderTab.Goto cs:54-54*/ StubCommand() /*@ENDINIT*/
    override val resetAlignment: ICommand = /*@INITAUTO DexReorderTab.ResetAlignment cs:55-55*/ StubCommand() /*@ENDINIT*/
    override val back: ICommand = /*@INITAUTO DexReorderTab.Back cs:56-56*/ StubCommand() /*@ENDINIT*/
    override val forward: ICommand = /*@INITAUTO DexReorderTab.Forward cs:57-57*/ StubCommand() /*@ENDINIT*/
    override lateinit var close: ICommand
    override val canDuplicate: Boolean
        get() { /*@DONE DexReorderTab.CanDuplicate.get cs:59-59*/
            return false
        }
    override fun duplicate() { /*@DONE DexReorderTab.Duplicate/1 cs:60-60*/
        // a dex reorder tab cannot be duplicated
    }
    override val onError = Event<String>()
    override val closed = Event<EventArgs>()
    override val onMessage = Event<String>()
    override val clearMessage = Event<EventArgs>()
    override val requestTabChange = Event<TabChangeRequestedEventArgs>()
    override val requestDelayedWork = Event<() -> Unit>()
    override val requestMenuClose = Event<EventArgs>()
    override val requestDiff = Event<Direction>()
    override val requestCanDiff = Event<CanDiffEventArgs>()
    override val requestCanCreatePatch = Event<CanPatchEventArgs>()
    override val requestCreatePatch = Event<CanPatchEventArgs>()
    override val requestRefreshGotoShortcuts = Event<EventArgs>()
    override val canIpsPatchRight: Boolean
        get() { /*@DONE DexReorderTab.CanIpsPatchRight.get cs:75-75*/
            return false
        }
    override val canUpsPatchRight: Boolean
        get() { /*@DONE DexReorderTab.CanUpsPatchRight.get cs:76-76*/
            return false
        }
    override fun ipsPatchRight() { /*@DONE DexReorderTab.IpsPatchRight/1 cs:77-77*/
        // not supported by this tab
    }
    override fun upsPatchRight() { /*@DONE DexReorderTab.UpsPatchRight/1 cs:78-78*/
        // not supported by this tab
    }
    private var _spriteScale: Double = /*@INITAUTO DexReorderTab.spriteScale cs:80-80*/ 1.0 /*@ENDINIT*/
    var spriteScale: Double
        get() { /*@DONE DexReorderTab.SpriteScale.get cs:82-82*/
            return _spriteScale
        }
        set(value) { /*@DONE DexReorderTab.SpriteScale.set cs:83-85*/
            set(_spriteScale, value.limitToRange(.25, 4.0), "spriteScale", { _spriteScale = it }, { _ ->
                for (pokemon in elements) pokemon.spriteScale = spriteScale
            })
        }
    private var _selectionStart: Int = 0
    var selectionStart: Int
        get() { /*@DONE DexReorderTab.SelectionStart.get cs:90-90*/
            return _selectionStart
        }
        set(value) { /*@DONE DexReorderTab.SelectionStart.set cs:91-97*/
            val first = Math.min(_selectionStart, _selectionEnd)
            val last = Math.max(_selectionStart, _selectionEnd)
            if (first <= value && value <= last) return
            if (!tryUpdate(_selectionStart, value, "selectionStart") { _selectionStart = it }) return
            selectionEnd = _selectionStart
        }
    private var _selectionEnd: Int = 0
    var selectionEnd: Int
        get() { /*@DONE DexReorderTab.SelectionEnd.get cs:102-102*/
            return _selectionEnd
        }
        set(value) { /*@DONE DexReorderTab.SelectionEnd.set cs:103-106*/
            tryUpdate(_selectionEnd, value, "selectionEnd") { _selectionEnd = it }
            updateSelection()
        }
    constructor(fileSystem: IFileSystem, viewPort: ViewPort, dexOrder: String, dexInfo: String, isNational: Boolean) { /*@DONE DexReorderTab.<init>/1 cs:109-140*/
        this.fullFileName = viewPort.name
        this.fs = fileSystem
        this.history = viewPort.changeHistory
        this._model = viewPort.model
        this.dexOrder = dexOrder
        this.dexInfo = dexInfo
        this.isNational = isNational
        this.save = viewPort.save
        this.saveAs = viewPort.saveAs

        val undoCommand = StubCommand()
        undoCommand.canExecute = { arg -> history.undo.canExecute(arg) }
        undoCommand.execute = { arg ->
            history.undo.execute(arg)
            refresh()
        }
        _undo = undoCommand
        history.undo.canExecuteChanged += undoWatcher

        val redoCommand = StubCommand()
        redoCommand.canExecute = { arg -> history.redo.canExecute(arg) }
        redoCommand.execute = { arg ->
            history.redo.execute(arg)
            refresh()
        }
        _redo = redoCommand
        history.redo.canExecuteChanged += redoWatcher

        val closeCommand = StubCommand()
        closeCommand.canExecute = { _ -> true }
        closeCommand.execute = { _ ->
            closed(this, EventArgs.empty)
            history.undo.canExecuteChanged -= undoWatcher
            history.redo.canExecuteChanged -= redoWatcher
        }
        close = closeCommand
    }
    override fun refresh() { /*@DONE DexReorderTab.Refresh/1 cs:142-194*/
        history.changeCompleted()
        elements.clear()

        val dexOrderRun = _model.getNextRun(_model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, this.dexOrder)) as ITableRun
        val dexInfoRun = _model.getNextRun(_model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, this.dexInfo)) as ITableRun

        val elementCount = dexOrderRun.elementCount
        val dexOrderTable = ModelTable(_model, dexOrderRun.start)
        val indexName = dexOrderRun.elementContent[0].name

        val sorted = arrayOfNulls<SortablePokemon>(dexInfoRun.elementCount - 1)
        val usedIndices = HashMap<Int, Int>()
        val warnings = ArrayList<String>()
        for (i in 0 until elementCount) {
            val dexIndex = dexOrderTable[i].getValue(indexName)
            if (dexIndex >= dexInfoRun.elementCount) {
                if (dexIndex > elementCount) {
                    warnings.add("Dex Reorder Warning: pokemon " + i + " is set to pokedex slot " + (dexIndex - 1) + " which is more than the number of pokemon!")
                }
                if (!usedIndices.containsKey(dexIndex)) {
                    usedIndices[dexIndex] = 0
                }
                usedIndices[dexIndex] = usedIndices[dexIndex]!! + 1
                continue
            }
            if (dexIndex == 0 || dexIndex > sorted.size) continue // out of range: we don't reall care about this value.
            val existing = sorted[dexIndex - 1]
            if (existing != null) {
                // multiple pokemon set to the same slot. Example: Rattata and Alolan Rattata
                existing.addSource(i + 1)
            } else {
                val created = SortablePokemon(_model, i + 1)
                created.spriteScale = spriteScale
                sorted[dexIndex - 1] = created
            }
        }
        for (i in dexInfoRun.elementCount until elementCount) {
            if (!usedIndices.containsKey(i)) {
                // TODO I still care about this, but I probably want to put it in a warnings tab, not here.
                // It might cause problems for the hacker, but not for the program.
                // Debug.Fail($"Dex Reorder Warning: pokedex slot {i} is not used!");
            } else if (usedIndices[i]!! > 1) {
                warnings.add("Dex Reorder Warning: pokedex slot " + i + " is used more than once!")
            }
        }
        for (i in 0 until sorted.size) {
            var pokemon = sorted[i]
            if (pokemon == null) {
                // unused pokedex slot
                pokemon = SortablePokemon(_model, 0)
                pokemon.spriteScale = spriteScale
                sorted[i] = pokemon
            }
            elements.add(pokemon)
            pokemon.matchToFilter(_filter)
        }
        if (warnings.size > 0) {
            val header = "Warning: Pokedex data in unexpected form!" + NEW_LINE + NEW_LINE
            fs.showCustomMessageBox(header + warnings.joinToString(NEW_LINE), showYesNoCancel = false)
        }
    }
    override fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean { /*@DONE DexReorderTab.TryImport/1 cs:196-196*/
        return false
    }
    private fun updateSelection() { /*@DONE DexReorderTab.UpdateSelection/1 cs:198-202*/
        val first = Math.min(_selectionStart, _selectionEnd)
        val last = Math.max(_selectionStart, _selectionEnd)
        for (i in 0 until elements.size) elements[i].selected = first <= i && i <= last
    }
    fun completeCurrentInteraction() { /*@DONE DexReorderTab.CompleteCurrentInteraction/1 cs:204-211*/
        try {
            updateDexFromSortOrder()
        } catch (e: Exception) {
            onError(this, e.message ?: "")
        }
        history.changeCompleted()
    }
    fun handleMove(originalIndex: Int, newIndex: Int): MutableList<DexReorderTabHandleMoveTuple> { /*@DONE DexReorderTab.HandleMove/1 cs:213-242*/
        val otherMovedElements = ArrayList<DexReorderTabHandleMoveTuple>()
        if (originalIndex == newIndex) return otherMovedElements

        var target = newIndex
        val first = Math.min(_selectionStart, _selectionEnd)
        val last = Math.max(_selectionStart, _selectionEnd)
        target = Math.max(target, originalIndex - first)
        target = Math.min(target, elements.size - 1 - last + originalIndex)
        val targetElements = (first..last).toMutableList()

        if (originalIndex < target) targetElements.reverse()
        for (index in targetElements) {
            val element = elements[index]
            elements.removeAt(index)
            elements.add(target - originalIndex + index, element)
        }

        var i = first
        while (i < target - (originalIndex - first)) {
            otherMovedElements.add(DexReorderTabHandleMoveTuple(i, last - first + 1))
            i++
        }
        i = last
        while (i > target + (last - originalIndex)) {
            otherMovedElements.add(DexReorderTabHandleMoveTuple(i, first - last - 1))
            i--
        }

        _selectionStart += target - originalIndex
        selectionEnd += target - originalIndex
        return otherMovedElements
    }
    private fun updateDexFromSortOrder() { /*@DONE DexReorderTab.UpdateDexFromSortOrder/1 cs:244-295*/
        val token = history.currentChange
        // Elements is in the new desired pokedex order
        // update dexOrder / dexInfo to match

        val dexOrderRun = _model.getNextRun(_model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, this.dexOrder)) as ITableRun
        val dexInfoRun = _model.getNextRun(_model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, this.dexInfo)) as ITableRun

        // maps from canonical order to previous desired dex order
        val oldOrder = ArrayList<Int>()
        var i = dexOrderRun.start
        while (i < dexOrderRun.start + dexOrderRun.length) {
            oldOrder.add(_model.readMultiByteValue(i, dexOrderRun.elementContent[0].length))
            i += dexOrderRun.elementLength
        }

        // maps from canonical order to new desired dex order
        val newOrder = invert(elements, oldOrder)

        val oldDexInfo = ByteArray(dexInfoRun.length)
        System.arraycopy(_model.rawData, dexInfoRun.start, oldDexInfo, 0, dexInfoRun.length)

        // clear dexInfo format
        if (isNational) _model.clearFormat(TransientModelDelta(), dexInfoRun.start, dexInfoRun.length)

        // move each dex info / dex order
        for (index in 1 until dexInfoRun.elementCount) {
            if (isNational) {
                // we only have to update the dex info if this tab is editing the nationaldex.
                val originalIndex = index
                val previousIndices = (0 until oldOrder.size).filter { j -> oldOrder[j] == index }
                val newIndices = previousIndices.map { j -> newOrder[j] }.distinct()
                // var newIndex = newOrder[oldOrder.IndexOf(i)];
                for (newIndex in newIndices) {
                    if (newIndex != originalIndex) {
                        // update data
                        for (j in 0 until dexInfoRun.elementLength) {
                            token.changeData(_model, dexInfoRun.start + dexInfoRun.elementLength * newIndex + j, oldDexInfo[dexInfoRun.elementLength * originalIndex + j].toInt() and 0xFF)
                        }
                    }
                }
            }
        }

        for (index in 0 until newOrder.size) {
            val start = dexOrderRun.start + dexOrderRun.elementLength * index
            _model.writeMultiByteValue(start, dexOrderRun.elementContent[0].length, token, newOrder[index])
        }

        // restore dexInfo format
        if (isNational) _model.observeAnchorWritten(TransientModelDelta(), HardcodeTablesModel.dexInfoTableName, dexInfoRun)

        UpdateDexConversionTable.run(_model, token)
    }
    private fun invert(list: List<SortablePokemon>, filler: MutableList<Int>): MutableList<Int> { /*@DONE DexReorderTab.Invert/1 cs:297-306*/
        val result = IntArray(filler.size)
        for (i in 0 until filler.size) result[i] = filler[i]
        for (i in 0 until list.size) {
            if (list[i].canonicalIndex == 0) continue // skip this one
            result[list[i].canonicalIndex - 1] = i + 1
            for (index in list[i].extraIndices) result[index - 1] = i + 1
        }
        return result.toMutableList()
    }
    private fun undoCanExecuteWatcher(sender: Any?, e: EventArgs) { /*@DONE DexReorderTab.UndoCanExecuteWatcher/1 cs:308-308*/
        _undo.canExecuteChanged(_undo, EventArgs.empty)
    }
    private fun redoCanExecuteWatcher(sender: Any?, e: EventArgs) { /*@DONE DexReorderTab.RedoCanExecuteWatcher/1 cs:309-309*/
        _redo.canExecuteChanged(_redo, EventArgs.empty)
    }
    /*@ADD DexReorderTab#goto_dex.txt*/
    private val undoWatcher: (Any?, EventArgs) -> Unit = { sender, e -> undoCanExecuteWatcher(sender, e) }
    private val redoWatcher: (Any?, EventArgs) -> Unit = { sender, e -> redoCanExecuteWatcher(sender, e) }
    private val disabledCommand: ICommand = StubCommand().also {
        it.canExecute = { _ -> false }
        it.execute = { _ -> }
    }
    /*@ENDADD DexReorderTab#goto_dex.txt*/
    /*@END DexReorderTab*/
}

open class SortablePokemon : ViewModelCore, IPixelViewModel { // cs:312-384
    private var filterTerms: MutableList<String> = ArrayList()
    private var _extraIndices: MutableList<Int> = ArrayList()
    var canonicalIndex: Int = 0
        private set
    val extraIndices: List<Int>
        get() { /*@DONE SortablePokemon.ExtraIndices.get cs:317-317*/
            return _extraIndices
        }
    override val transparent: Short
        get() { /*@DONE SortablePokemon.Transparent.get cs:318-318*/
            return (-1).toShort()
        }
    final override var pixelWidth: Int = 0
        private set
    final override var pixelHeight: Int = 0
        private set
    final override var pixelData: ShortArray = ShortArray(0)
        private set
    private var _spriteScale: Double = 0.0
    override var spriteScale: Double
        get() { /*@DONE SortablePokemon.SpriteScale.get cs:323-323*/
            return _spriteScale
        }
        set(value) { /*@DONE SortablePokemon.SpriteScale.set cs:323-323*/
            set(_spriteScale, value, "spriteScale", { _spriteScale = it })
        }
    var name: String = ""
        private set
    private var _isFilteredOut: Boolean = false
    var isFilteredOut: Boolean
        get() { /*@DONE SortablePokemon.IsFilteredOut.get cs:328-328*/
            return _isFilteredOut
        }
        set(value) { /*@DONE SortablePokemon.IsFilteredOut.set cs:328-328*/
            tryUpdate(_isFilteredOut, value, "isFilteredOut") { _isFilteredOut = it }
        }
    private var _selected: Boolean = false
    var selected: Boolean
        get() { /*@DONE SortablePokemon.Selected.get cs:331-331*/
            return _selected
        }
        set(value) { /*@DONE SortablePokemon.Selected.set cs:331-331*/
            tryUpdate(_selected, value, "selected") { _selected = it }
        }
    constructor(model: IDataModel, index: Int) { /*@DONE SortablePokemon.<init>/1 cs:333-349*/
        val sprites = ModelTable(model, model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.frontSpritesTable))
        val palettes = ModelTable(model, model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.pokePalettesTable))
        val sprite = sprites[index].getSprite(sprites[index].getFieldName(0))
        var palette: List<Short>? = palettes[index].getPalette(palettes[index].getFieldName(0))
        if (palette == null) palette = TileViewModel.createDefaultPalette(16).toList()
        _extraIndices = ArrayList()

        canonicalIndex = index
        pixelWidth = sprite?.size ?: 64
        pixelHeight = if (sprite != null) (sprite.firstOrNull()?.size ?: 0) else 64
        pixelData = if (sprite != null) SpriteTool.render(sprite, palette, 0, 0) else ShortArray(64 * 64)
        spriteScale = 1.0

        filterTerms = generateFilterTerms(model, index)
        name = filterTerms.firstOrNull() ?: ""
    }
    fun addSource(canonicalIndex: Int) { /*@DONE SortablePokemon.AddSource/1 cs:351-353*/
        _extraIndices.add(canonicalIndex)
    }
    fun matchToFilter(filter: String) { /*@DONE SortablePokemon.MatchToFilter/1 cs:355-364*/
        isFilteredOut = false
        if (filter == "") return

        for (term in filterTerms) {
            if (term.matchesPartial(filter)) return
        }

        isFilteredOut = true
    }
    companion object {
        private fun generateFilterTerms(model: IDataModel, pokemonIndex: Int): MutableList<String> { /*@DONE SortablePokemon.GenerateFilterTerms/1 cs:366-383*/
            val terms = ArrayList<String>()

            // pokemon name
            val names = ModelTable(model, model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.pokemonNameTable))
            val name = names[pokemonIndex].getStringValue(names[pokemonIndex].getFieldName(0))
            terms.add(name)

            // pokemon types
            val statsTable = ReorderDex.getTable(model, HardcodeTablesModel.pokemonStatsTable)
            if (statsTable != null) {
                val stats = ModelTable(model, statsTable.start)
                terms.add(stats[pokemonIndex].getEnumValue("type1"))
                terms.add(stats[pokemonIndex].getEnumValue("type2"))
            }

            return terms
        }
        /*@END SortablePokemon.Companion*/
    }
    /*@END SortablePokemon*/
}

data class DexReorderTabHandleMoveTuple(val index: Int, val direction: Int)
