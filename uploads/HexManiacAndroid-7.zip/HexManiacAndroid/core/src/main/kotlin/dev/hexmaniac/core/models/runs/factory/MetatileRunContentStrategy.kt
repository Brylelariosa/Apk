// Port of Models/Runs/Factory/MetatileRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class MetatileRunContentStrategy : RunStrategy() { // cs:6-30
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE MetatileRunContentStrategy.LengthForNewRun/1 cs:7-9*/
        throw NotImplementedError()
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE MetatileRunContentStrategy.Matches/1 cs:11-13*/
        throw NotImplementedError()
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE MetatileRunContentStrategy.TryAddFormatAtDestination/1 cs:15-17*/
        throw NotImplementedError()
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE MetatileRunContentStrategy.TryParseData/1 cs:19-21*/
        throw NotImplementedError()
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE MetatileRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:23-25*/
        throw NotImplementedError()
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE MetatileRunContentStrategy.WriteNewRun/1 cs:27-29*/
        return MetatileRun(owner, destination, SortedSpanStatic.one(source))
    }
    /*@END MetatileRunContentStrategy*/
}
