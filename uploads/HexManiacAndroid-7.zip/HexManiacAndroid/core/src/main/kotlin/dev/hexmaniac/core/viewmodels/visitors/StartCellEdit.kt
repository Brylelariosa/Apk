// Port of ViewModels/Visitors/StartCellEdit.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.visitors

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.extendArray
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayStart
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayEnd
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.singleByteIntegerFormat
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.doubleByteIntegerFormat
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayAnchorSeparator
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.signedFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.hexFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.recordFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.tupleFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.colorFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.calculatedFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.pythonButtonFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.renderFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.commentFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.splitterFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.tryParse
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.trySearch
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseTilemapTable
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.findAllLoads
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.findAllCommands
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseSegments
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseSegments2
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.dataMatchesSegmentFormat
import dev.hexmaniac.core.models.runs.AsciiRun.Companion.streamDelimeter
import dev.hexmaniac.core.models.runs.AsciiRun.Companion.sharedFormatString
import dev.hexmaniac.core.models.runs.BaseRun.Companion.anchorStart
import dev.hexmaniac.core.models.runs.PCSRun.Companion.stringDelimeter
import dev.hexmaniac.core.models.runs.PCSRun.Companion.sharedFormatString
import dev.hexmaniac.core.models.runs.PCSRun.Companion.createPCSFormat
import dev.hexmaniac.core.models.runs.PointerRun.Companion.pointerStart
import dev.hexmaniac.core.models.runs.PointerRun.Companion.pointerEnd

open class StartCellEdit : IDataFormatVisitor { // cs:19-270
    lateinit var model: IDataModel
        private set
    var memoryLocation: Int = 0
        private set
    var input: Char = '\u0000'
        private set
    var newFormat: UnderEdit? = null
        private set
    var result: Boolean = false
        private set
    constructor(model: IDataModel, memoryLocation: Int, input: Char) { /*@DONE StartCellEdit.<init>/1 cs:37-37*/
        this.model = model
        this.memoryLocation = memoryLocation
        this.input = input
    }
    override fun visit(dataFormat: Undefined, data: Int) { /*@DONE StartCellEdit.Visit/1 cs:41-41*/
        basicVisit(dataFormat, data)
    }
    override fun visit(dataFormat: None, data: Int) { /*@DONE StartCellEdit.Visit/2 cs:43-43*/
        basicVisit(dataFormat, data)
    }
    private fun basicVisit(dataFormat: IDataFormat, data: Int) { /*@DONE StartCellEdit.BasicVisit/1 cs:45-72*/
        // you can write a pointer into a space with no current format
        if (input == PointerRun.pointerStart) {
            val editText = input.toString()
            val autocompleteOptions = model.getNewPointerAutocompleteOptions(editText, -1)
            newFormat = UnderEdit(dataFormat, editText, 4, autocompleteOptions)
            result = true
            return
        }

        if (input == ':') {
            val editText = input.toString()
            val autocompleteOptions = model.getNewWordAutocompleteOptions("::", -1)
            newFormat = UnderEdit(dataFormat, editText, 4, autocompleteOptions)
            result = true
            return
        }

        if (input == '.') {
            val editText = input.toString()
            val autocompleteOptions = model.getNewWordAutocompleteOptions(".", -1)
            newFormat = UnderEdit(dataFormat, editText, 4, autocompleteOptions)
            result = true
            return
        }

        result = ViewPort.allHexCharacters.contains(input)
    }
    override fun visit(underEdit: UnderEdit, data: Int) { /*@DONE StartCellEdit.Visit/3 cs:76-103*/
        // handle special cases of "anywhere" formats first
        if (underEdit.currentText.startsWith(ViewPort.gotoMarker.toString())) {
            result = input.isLetterOrDigit() || input.isWhitespace()
            result = result || ("" + ArrayRun.arrayAnchorSeparator + ViewPort.commandMarker + "()~=._+-'\"").contains(input)
            if (underEdit.currentText.count { c -> c == '(' } > underEdit.currentText.count { c -> c == ')' } && input == ' ') result = true // allow spaces if we have unmatched ()
            if (underEdit.currentText.length == 1) result = result || input == '{' || input == '}'
            return
        } else if (underEdit.currentText.startsWith(BaseRun.anchorStart.toString())) {
            result =
                input.isLetterOrDigit() ||
                input.isWhitespace() ||
                specialAnchorAllowedCharacters.contains(input)
            return
        } else if (underEdit.currentText.startsWith(ViewPort.directiveMarker.toString())
        && underEdit.currentText.count { c -> c == ViewPort.directiveMarker } == 1) {
            result = true
            return
        } else if (underEdit.currentText.startsWith(ViewPort.commentStart.toString())) {
            result = true
            return
        }

        // use the ContinueCellEdit class to continue the edit
        val editor = ContinueCellEdit(model, input, underEdit)
        (underEdit.originalFormat ?: Undefined.instance).visit(editor, data)
        result = editor.result
    }
    override fun visit(pointer: Pointer, data: Int) { /*@DONE StartCellEdit.Visit/4 cs:105-115*/
        if (input == ':') { basicVisit(pointer, data); return }
        if (input != PointerRun.pointerStart && !input.isLetterOrDigit()) return

        var editText = input.toString()
        // if the user tries to edit the pointer but forgets the opening bracket, add it for them.
        if (input != PointerRun.pointerStart) editText = PointerRun.pointerStart.toString() + editText
        val autocompleteOptions = model.getNewPointerAutocompleteOptions(editText, -1)
        newFormat = UnderEdit(pointer, editText, 4, autocompleteOptions)
        result = true
    }
    override fun visit(anchor: Anchor, data: Int) { /*@DONE StartCellEdit.Visit/5 cs:117-121*/
        val innerFormat = anchor.originalFormat!!
        innerFormat.visit(this, data)
        val currentNewFormat = newFormat
        if (currentNewFormat != null && currentNewFormat.originalFormat === innerFormat) newFormat = UnderEdit(anchor, currentNewFormat.currentText, currentNewFormat.editWidth, currentNewFormat.autocompleteOptions)
    }
    override fun visit(sprite: SpriteDecorator, data: Int) { /*@DONE StartCellEdit.Visit/6 cs:123-123*/
        sprite.originalFormat!!.visit(this, data)
    }
    override fun visit(decorator: StreamEndDecorator, data: Int) { /*@DONE StartCellEdit.Visit/7 cs:125-131*/
        if (input == '[') {
            result = true
        } else {
            decorator.originalFormat!!.visit(this, data)
        }
    }
    override fun visit(pcs: PCS, data: Int) { /*@DONE StartCellEdit.Visit/8 cs:133-145*/
        // don't let it start with a space unless it's in quotes (for copy/paste)
        val run = model.getNextRun(memoryLocation)
        if (run is ITableRun) {
            val offsets = run.convertByteOffsetToArrayOffset(memoryLocation)
            if (offsets.segmentStart == memoryLocation && input == ' ') return
        }
        if (run is PCSRun && run.start == memoryLocation && input == ' ') return

        result = input == PCSRun.stringDelimeter ||
            PCSString.pcs.any { str -> str != null && str.startsWith(input.toString()) } ||
            model.textConverter.anyMacroStartsWith(input.toString())
    }
    override fun visit(pcs: EscapedPCS, data: Int) { /*@DONE StartCellEdit.Visit/9 cs:147-149*/
        result = ViewPort.allHexCharacters.contains(input)
    }
    override fun visit(pcs: ErrorPCS, data: Int) { /*@DONE StartCellEdit.Visit/10 cs:151-151*/
        visit(PCS(memoryLocation, 0, "", ""), data)
    }
    override fun visit(ascii: Ascii, data: Int) { /*@DONE StartCellEdit.Visit/11 cs:153-156*/
        if (input == ' ' && ascii.position == 0) result = false
        else result = true
    }
    override fun visit(braille: Braille, data: Int) { /*@DONE StartCellEdit.Visit/12 cs:158-158*/
        result = true
    }
    override fun visit(intFormat: Integer, data: Int) { /*@DONE StartCellEdit.Visit/13 cs:160-180*/
        val nextRun = model.getNextRun(memoryLocation)
        if (input == '+' && nextRun is LzSpriteRun && nextRun.start == memoryLocation - 1 && nextRun.pages == 1) {
            result = true
            return
        }
        if (nextRun is WordRun && nextRun.start == memoryLocation) {
            if (nextRun.length == 1 && input == '.') {
                result = true
                return
            } else if (nextRun.length == 2 && input == ':') {
                result = true
                return
            }
        }

        if (!intFormat.canStartWithCharacter(input)) return

        newFormat = UnderEdit(intFormat, input.toString(), intFormat.length, null)
        result = true
    }
    override fun visit(integer: IntegerEnum, data: Int) { /*@DONE StartCellEdit.Visit/14 cs:182-191*/
        if (!integer.canStartWithCharacter(input)) return

        val autocompleteVisitor = AutocompleteCell(model, input.toString(), memoryLocation)
        integer.visit(autocompleteVisitor, data)
        val autocomplete = autocompleteVisitor.result

        newFormat = UnderEdit(integer, input.toString(), integer.length, autocomplete)
        result = true
    }
    override fun visit(integerHex: IntegerHex, data: Int) { /*@DONE StartCellEdit.Visit/15 cs:193-198*/
        if (!integerHex.canStartWithCharacter(input)) return

        newFormat = UnderEdit(integerHex, input.toString(), integerHex.length, null)
        result = true
    }
    override fun visit(section: EggSection, data: Int) { /*@DONE StartCellEdit.Visit/16 cs:200-200*/
        visitEgg(section)
    }
    override fun visit(item: EggItem, data: Int) { /*@DONE StartCellEdit.Visit/17 cs:202-202*/
        visitEgg(item)
    }
    fun visitEgg(eggFormat: IDataFormat) { /*@DONE StartCellEdit.VisitEgg/1 cs:204-212*/
        if (!input.isLetterOrDigit() && !("" + PCSRun.stringDelimeter + "[").contains(input)) return

        val stream = model.getNextRun(memoryLocation) as EggMoveRun
        val allOptions = stream.getAutoCompleteOptions()
        val autocomplete = AutoCompleteSelectionItem.generate(allOptions.filter { option -> option.matchesPartial(input.toString()) }, -1)
        newFormat = UnderEdit(eggFormat, input.toString(), 2, autocomplete)
        result = true
    }
    override fun visit(item: PlmItem, data: Int) { /*@DONE StartCellEdit.Visit/18 cs:214-220*/
        result = input.isDigit() || input == '['
        if (result) {
            val autocomplete = AutoCompleteSelectionItem.generate(emptyList<String>(), -1)
            newFormat = UnderEdit(item, input.toString(), 2, autocomplete)
        }
    }
    override fun visit(array: BitArray, data: Int) { /*@DONE StartCellEdit.Visit/19 cs:222-232*/
        result = input.isLetterOrDigit() || input == '"' || input == '-' || input == '/'

        if (result) {
            val autocompleteVisitor = AutocompleteCell(model, input.toString(), memoryLocation)
            array.visit(autocompleteVisitor, data)
            val autocomplete = autocompleteVisitor.result

            newFormat = UnderEdit(array, input.toString(), array.length, autocomplete)
        }
    }
    override fun visit(word: MatchedWord, data: Int) { /*@DONE StartCellEdit.Visit/20 cs:234-234*/
        basicVisit(word, data)
    }
    override fun visit(endStream: EndStream, data: Int) { /*@DONE StartCellEdit.Visit/21 cs:236-236*/
        result = input == ArrayRun.extendArray || input == '['
    }
    override fun visit(lz: LzMagicIdentifier, data: Int) { /*@DONE StartCellEdit.Visit/22 cs:238-238*/
        result = input.lowercaseChar() == 'l'
    }
    override fun visit(lz: LzGroupHeader, data: Int) { /*@DONE StartCellEdit.Visit/23 cs:240-240*/
        result = ViewPort.allHexCharacters.contains(input)
    }
    override fun visit(lz: LzCompressed, data: Int) { /*@DONE StartCellEdit.Visit/24 cs:242-242*/
        result = input.isDigit()
    }
    override fun visit(lz: LzUncompressed, data: Int) { /*@DONE StartCellEdit.Visit/25 cs:244-251*/
        val spriteRun = model.getNextRun(memoryLocation)
        if (input == '+' && spriteRun is SpriteRun && spriteRun.start == memoryLocation) {
            result = true
            return
        }

        result = ViewPort.allHexCharacters.contains(input)
    }
    override fun visit(color: UncompressedPaletteColor, data: Int) { /*@DONE StartCellEdit.Visit/26 cs:253-256*/
        result = ViewPort.allHexCharacters.contains(input)
        if (result) newFormat = UnderEdit(color, input.toString(), 2)
    }
    override fun visit(tuple: Tuple, data: Int) { /*@DONE StartCellEdit.Visit/27 cs:258-269*/
        if (" +,".contains(input)) {
            result = false
            return
        }

        result = true
        val autocompleteVisitor = AutocompleteCell(model, input.toString(), memoryLocation)
        tuple.visit(autocompleteVisitor, data)
        val autocomplete = autocompleteVisitor.result
        newFormat = UnderEdit(tuple, input.toString(), tuple.length, autocomplete)
    }
    companion object {
        private val specialAnchorAllowedCharacters: CharArray = /*@INITDONE StartCellEdit.SpecialAnchorAllowedCharacters cs:20-28*/ charArrayOf(BaseRun.anchorStart, ArrayRun.arrayStart, ArrayRun.arrayEnd, '(', ')', PCSRun.stringDelimeter, AsciiRun.streamDelimeter, PointerRun.pointerStart, PointerRun.pointerEnd, '|', '!', '?', '-', '_', '=', '+', '*', '\u00f7', ArrayRun.arrayAnchorSeparator, ArrayRun.singleByteIntegerFormat, ArrayRun.doubleByteIntegerFormat) /*@ENDINIT*/
        /*@END StartCellEdit.Companion*/
    }
    /*@END StartCellEdit*/
}
