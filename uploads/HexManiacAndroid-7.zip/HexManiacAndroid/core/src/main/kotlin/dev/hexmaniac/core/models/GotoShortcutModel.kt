// Port of Models/GotoShortcutModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

open class GotoShortcutModel { // cs:2-12
    var imageAnchor: String = ""
        private set
    var gotoAnchor: String = ""
        private set
    var displayText: String = ""
        private set
    constructor(imageAnchor: String, gotoAnchor: String, displayText: String) { /*@DONE GotoShortcutModel.<init>/1 cs:7-11*/
        this.imageAnchor = imageAnchor
        this.gotoAnchor = gotoAnchor
        this.displayText = displayText
    }
    /*@END GotoShortcutModel*/
}
