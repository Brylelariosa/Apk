// Port of ViewModels/EditorViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.quickedititems.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.system.ICommandExtensions.canAlwaysExecute

open class EditorViewModel : ViewModelCore, Iterable<ITabContent>, INotifyCollectionChanged { // cs:27-1552
    private lateinit var _fileSystem: IFileSystem
    private lateinit var workDispatcher: IWorkDispatcher
    private var allowLoadingMetadata: Boolean = false
    private var tabs: MutableList<ITabContent> = ArrayList()
    private val commandsToRefreshOnTabChange: MutableList<StubCommand> = /*@INITAUTO EditorViewModel.commandsToRefreshOnTabChange cs:35-35*/ ArrayList() /*@ENDINIT*/
    private val newCommand: StubCommand = /*@INITAUTO EditorViewModel.newCommand cs:36-37*/ StubCommand() /*@ENDINIT*/
    private var _open: StubCommand = /*@INITAUTO EditorViewModel.open cs:36-38*/ StubCommand() /*@ENDINIT*/
    private var _duplicateCurrentTab: StubCommand = /*@INITAUTO EditorViewModel.duplicateCurrentTab cs:36-39*/ StubCommand() /*@ENDINIT*/
    private var _save: StubCommand = /*@INITAUTO EditorViewModel.save cs:36-40*/ StubCommand() /*@ENDINIT*/
    private var _saveAs: StubCommand = /*@INITAUTO EditorViewModel.saveAs cs:36-41*/ StubCommand() /*@ENDINIT*/
    private var _exportBackup: StubCommand = /*@INITAUTO EditorViewModel.exportBackup cs:36-42*/ StubCommand() /*@ENDINIT*/
    private var _saveAll: StubCommand = /*@INITAUTO EditorViewModel.saveAll cs:36-43*/ StubCommand() /*@ENDINIT*/
    private var _runFile: StubCommand = /*@INITAUTO EditorViewModel.runFile cs:36-44*/ StubCommand() /*@ENDINIT*/
    private var _close: StubCommand = /*@INITAUTO EditorViewModel.close cs:36-45*/ StubCommand() /*@ENDINIT*/
    private var _closeAll: StubCommand = /*@INITAUTO EditorViewModel.closeAll cs:36-46*/ StubCommand() /*@ENDINIT*/
    private var _undo: StubCommand = /*@INITAUTO EditorViewModel.undo cs:36-48*/ StubCommand() /*@ENDINIT*/
    private var _redo: StubCommand = /*@INITAUTO EditorViewModel.redo cs:36-49*/ StubCommand() /*@ENDINIT*/
    private var _cut: StubCommand = /*@INITAUTO EditorViewModel.cut cs:36-50*/ StubCommand() /*@ENDINIT*/
    private var _copy: StubCommand = /*@INITAUTO EditorViewModel.copy cs:36-51*/ StubCommand() /*@ENDINIT*/
    private var _deepCopy: StubCommand = /*@INITAUTO EditorViewModel.deepCopy cs:36-52*/ StubCommand() /*@ENDINIT*/
    private var _paste: StubCommand = /*@INITAUTO EditorViewModel.paste cs:36-53*/ StubCommand() /*@ENDINIT*/
    private var _delete: StubCommand = /*@INITAUTO EditorViewModel.delete cs:36-54*/ StubCommand() /*@ENDINIT*/
    private var _selectAll: StubCommand = /*@INITAUTO EditorViewModel.selectAll cs:36-55*/ StubCommand() /*@ENDINIT*/
    private var _back: StubCommand = /*@INITAUTO EditorViewModel.back cs:36-57*/ StubCommand() /*@ENDINIT*/
    private var _forward: StubCommand = /*@INITAUTO EditorViewModel.forward cs:36-58*/ StubCommand() /*@ENDINIT*/
    private var _find: StubCommand = /*@INITAUTO EditorViewModel.find cs:36-59*/ StubCommand() /*@ENDINIT*/
    private var _findPrevious: StubCommand = /*@INITAUTO EditorViewModel.findPrevious cs:36-60*/ StubCommand() /*@ENDINIT*/
    private var _findNext: StubCommand = /*@INITAUTO EditorViewModel.findNext cs:36-61*/ StubCommand() /*@ENDINIT*/
    private var _showFind: StubCommand = /*@INITAUTO EditorViewModel.showFind cs:36-62*/ StubCommand() /*@ENDINIT*/
    private var _showHexConverter: StubCommand = /*@INITAUTO EditorViewModel.showHexConverter cs:36-63*/ StubCommand() /*@ENDINIT*/
    private var _hideSearchControls: StubCommand = /*@INITAUTO EditorViewModel.hideSearchControls cs:36-64*/ StubCommand() /*@ENDINIT*/
    private var _diffSinceLastSave: StubCommand = /*@INITAUTO EditorViewModel.diffSinceLastSave cs:36-65*/ StubCommand() /*@ENDINIT*/
    private var _resetZoom: StubCommand = /*@INITAUTO EditorViewModel.resetZoom cs:36-66*/ StubCommand() /*@ENDINIT*/
    private var _resetAlignment: StubCommand = /*@INITAUTO EditorViewModel.resetAlignment cs:36-67*/ StubCommand() /*@ENDINIT*/
    private var _resetTheme: StubCommand = /*@INITAUTO EditorViewModel.resetTheme cs:36-68*/ StubCommand() /*@ENDINIT*/
    private var _clearError: StubCommand = /*@INITAUTO EditorViewModel.clearError cs:36-69*/ StubCommand() /*@ENDINIT*/
    private var _clearMessage: StubCommand = /*@INITAUTO EditorViewModel.clearMessage cs:36-70*/ StubCommand() /*@ENDINIT*/
    private var _displayAsText: StubCommand = /*@INITAUTO EditorViewModel.displayAsText cs:36-71*/ StubCommand() /*@ENDINIT*/
    private var _displayAsEventScript: StubCommand = /*@INITAUTO EditorViewModel.displayAsEventScript cs:36-72*/ StubCommand() /*@ENDINIT*/
    private var _displayAsSprite: StubCommand = /*@INITAUTO EditorViewModel.displayAsSprite cs:36-73*/ StubCommand() /*@ENDINIT*/
    private var _displayAsColorPalette: StubCommand = /*@INITAUTO EditorViewModel.displayAsColorPalette cs:36-74*/ StubCommand() /*@ENDINIT*/
    private var _toggleMatrix: StubCommand = /*@INITAUTO EditorViewModel.toggleMatrix cs:36-75*/ StubCommand() /*@ENDINIT*/
    private var _toggleScrollAnimation: StubCommand = /*@INITAUTO EditorViewModel.toggleScrollAnimation cs:36-76*/ StubCommand() /*@ENDINIT*/
    private var _toggleTableHeaders: StubCommand = /*@INITAUTO EditorViewModel.toggleTableHeaders cs:36-77*/ StubCommand() /*@ENDINIT*/
    private var forwardExecuteChangeNotifications: MutableMap<(ITabContent) -> ICommand?, EventHandler> = LinkedHashMap()
    private var recentFindResults: List<Triple<IViewPort, Int, Int>> = emptyList()
    private var currentFindResultIndex: Int = 0
    private var showDevMenu: Boolean = false
    var showDeveloperMenu: Boolean
        get() { /*@DONE EditorViewModel.ShowDeveloperMenu.get cs:84-84*/
            return showDevMenu
        }
        set(value) { /*@DONE EditorViewModel.ShowDeveloperMenu.set cs:84-84*/
            set(showDevMenu, value, "showDeveloperMenu", { showDevMenu = it })
        }
    val recentFileMenuEnabled: Boolean
        get() { /*@DONE EditorViewModel.RecentFileMenuEnabled.get cs:86-86*/
            return recentFileViewModels.isNotEmpty()
        }
    val new: ICommand
        get() { /*@DONE EditorViewModel.New.get cs:88-88*/
            return newCommand
        }
    val open: ICommand
        get() { /*@DONE EditorViewModel.Open.get cs:89-89*/
            return _open
        }
    val duplicateCurrentTab: ICommand
        get() { /*@DONE EditorViewModel.DuplicateCurrentTab.get cs:90-90*/
            return _duplicateCurrentTab
        }
    val isMetadataOnlyChange: Boolean
        get() { /*@DONE EditorViewModel.IsMetadataOnlyChange.get cs:91-91*/
            return selectedTab?.isMetadataOnlyChange ?: false
        }
    val save: ICommand
        get() { /*@DONE EditorViewModel.Save.get cs:92-92*/
            return _save
        }
    val saveAs: ICommand
        get() { /*@DONE EditorViewModel.SaveAs.get cs:93-93*/
            return _saveAs
        }
    val saveAll: ICommand
        get() { /*@DONE EditorViewModel.SaveAll.get cs:94-94*/
            return _saveAll
        }
    val exportBackup: ICommand
        get() { /*@DONE EditorViewModel.ExportBackup.get cs:95-95*/
            return _exportBackup
        }
    val runFile: ICommand
        get() { /*@DONE EditorViewModel.RunFile.get cs:96-96*/
            return _runFile
        }
    val close: ICommand
        get() { /*@DONE EditorViewModel.Close.get cs:97-97*/
            return _close
        }
    val closeAll: ICommand
        get() { /*@DONE EditorViewModel.CloseAll.get cs:98-98*/
            return _closeAll
        }
    val undo: ICommand
        get() { /*@DONE EditorViewModel.Undo.get cs:99-99*/
            return _undo
        }
    val redo: ICommand
        get() { /*@DONE EditorViewModel.Redo.get cs:100-100*/
            return _redo
        }
    val cut: ICommand
        get() { /*@DONE EditorViewModel.Cut.get cs:101-101*/
            return _cut
        }
    val copy: ICommand
        get() { /*@DONE EditorViewModel.Copy.get cs:102-102*/
            return _copy
        }
    val deepCopy: ICommand
        get() { /*@DONE EditorViewModel.DeepCopy.get cs:103-103*/
            return _deepCopy
        }
    val paste: ICommand
        get() { /*@DONE EditorViewModel.Paste.get cs:104-104*/
            return _paste
        }
    val delete: ICommand
        get() { /*@DONE EditorViewModel.Delete.get cs:105-105*/
            return _delete
        }
    val selectAll: ICommand
        get() { /*@DONE EditorViewModel.SelectAll.get cs:106-106*/
            return _selectAll
        }
    val diffSinceLastSave: ICommand
        get() { /*@DONE EditorViewModel.DiffSinceLastSave.get cs:107-107*/
            return _diffSinceLastSave
        }
    val back: ICommand
        get() { /*@DONE EditorViewModel.Back.get cs:108-108*/
            return _back
        }
    val forward: ICommand
        get() { /*@DONE EditorViewModel.Forward.get cs:109-109*/
            return _forward
        }
    val find: ICommand
        get() { /*@DONE EditorViewModel.Find.get cs:110-110*/
            return _find
        }
    val findPrevious: ICommand
        get() { /*@DONE EditorViewModel.FindPrevious.get cs:111-111*/
            return _findPrevious
        }
    val findNext: ICommand
        get() { /*@DONE EditorViewModel.FindNext.get cs:112-112*/
            return _findNext
        }
    val showFind: ICommand
        get() { /*@DONE EditorViewModel.ShowFind.get cs:113-113*/
            return _showFind
        }
    val showHexConverter: ICommand
        get() { /*@DONE EditorViewModel.ShowHexConverter.get cs:114-114*/
            return _showHexConverter
        }
    val hideSearchControls: ICommand
        get() { /*@DONE EditorViewModel.HideSearchControls.get cs:115-115*/
            return _hideSearchControls
        }
    val resetZoom: ICommand
        get() { /*@DONE EditorViewModel.ResetZoom.get cs:116-116*/
            return _resetZoom
        }
    val resetAlignment: ICommand
        get() { /*@DONE EditorViewModel.ResetAlignment.get cs:117-117*/
            return _resetAlignment
        }
    val resetTheme: ICommand
        get() { /*@DONE EditorViewModel.ResetTheme.get cs:118-118*/
            return _resetTheme
        }
    val clearError: ICommand
        get() { /*@DONE EditorViewModel.ClearError.get cs:119-119*/
            return _clearError
        }
    val clearMessage: ICommand
        get() { /*@DONE EditorViewModel.ClearMessage.get cs:120-120*/
            return _clearMessage
        }
    val displayAsText: ICommand
        get() { /*@DONE EditorViewModel.DisplayAsText.get cs:121-121*/
            return _displayAsText
        }
    val displayAsEventScript: ICommand
        get() { /*@DONE EditorViewModel.DisplayAsEventScript.get cs:122-122*/
            return _displayAsEventScript
        }
    val displayAsSprite: ICommand
        get() { /*@DONE EditorViewModel.DisplayAsSprite.get cs:123-123*/
            return _displayAsSprite
        }
    val displayAsColorPalette: ICommand
        get() { /*@DONE EditorViewModel.DisplayAsColorPalette.get cs:124-124*/
            return _displayAsColorPalette
        }
    val toggleMatrix: ICommand
        get() { /*@DONE EditorViewModel.ToggleMatrix.get cs:125-125*/
            return _toggleMatrix
        }
    val toggleScrollAnimation: ICommand
        get() { /*@DONE EditorViewModel.ToggleScrollAnimation.get cs:126-126*/
            return _toggleScrollAnimation
        }
    val toggleTableHeaders: ICommand
        get() { /*@DONE EditorViewModel.ToggleTableHeaders.get cs:127-127*/
            return _toggleTableHeaders
        }
    private var _copyAlignedAddress: StubCommand? = null
    private var _copyAnchorReference: StubCommand? = null
    val copyAlignedAddress: ICommand
        get() { /*@DONE EditorViewModel.CopyAlignedAddress.get cs:130-130*/
            return _copyAlignedAddress ?: stubCommandOf<IFileSystem>({ fs -> executeCopyAlignedAddress(fs!!) }).also { _copyAlignedAddress = it }
        }
    val copyAnchorReference: ICommand
        get() { /*@DONE EditorViewModel.CopyAnchorReference.get cs:131-131*/
            return _copyAnchorReference ?: stubCommandOf<IFileSystem>({ fs -> executeCopyAnchorReference(fs!!) }).also { _copyAnchorReference = it }
        }
    var mapTutorials: MapTutorialsViewModel = /*@INITDONE EditorViewModel.MapTutorials cs:133-133*/ MapTutorialsViewModel() /*@ENDINIT*/
        private set
    private var _gotoViewModel: GotoControlViewModel = /*@INITAUTO EditorViewModel.gotoViewModel cs:135-135*/ GotoControlViewModel(null, null, null, false) /*@ENDINIT*/
    var gotoViewModel: GotoControlViewModel
        get() { /*@DONE EditorViewModel.GotoViewModel.get cs:137-137*/
            return _gotoViewModel
        }
        private set(value) { /*@DONE EditorViewModel.GotoViewModel.set cs:138-142*/
            val old = _gotoViewModel
            _gotoViewModel = value
            notifyPropertyChanged(old, "gotoViewModel")
        }
    private var _overlayText: String = ""
    var overlayText: String
        get() { /*@DONE EditorViewModel.OverlayText.get cs:149-149*/
            return _overlayText
        }
        set(value) { /*@DONE EditorViewModel.OverlayText.set cs:150-150*/
            set(_overlayText, value, "overlayText", { _overlayText = it })
        }
    private var _showOverlayText: Boolean = false
    var showOverlayText: Boolean
        get() { /*@DONE EditorViewModel.ShowOverlayText.get cs:155-155*/
            return _showOverlayText
        }
        set(value) { /*@DONE EditorViewModel.ShowOverlayText.set cs:156-156*/
            set(_showOverlayText, value, "showOverlayText", { _showOverlayText = it })
        }
    private var _findControlVisible: Boolean = false
    var findControlVisible: Boolean
        get() { /*@DONE EditorViewModel.FindControlVisible.get cs:163-163*/
            return _findControlVisible
        }
        private set(value) { /*@DONE EditorViewModel.FindControlVisible.set cs:164-175*/
            if (value) {
                clearError.execute()
                clearMessage.execute()
                _gotoViewModel.controlVisible = false
                hexConverterVisible = false
            }

            tryUpdate(_findControlVisible, value, "findControlVisible", { _findControlVisible = it })
            if (value) moveFocusToFind(this, EventArgs.empty)
            findTextChanged()
        }
    private var _hexConverterVisible: Boolean = false
    var hexConverterVisible: Boolean
        get() { /*@DONE EditorViewModel.HexConverterVisible.get cs:180-180*/
            return _hexConverterVisible
        }
        private set(value) { /*@DONE EditorViewModel.HexConverterVisible.set cs:181-190*/
            if (value) {
                clearError.execute()
                clearMessage.execute()
                _gotoViewModel.controlVisible = false
                findControlVisible = false
            }
            tryUpdate(_hexConverterVisible, value, "hexConverterVisible", { _hexConverterVisible = it })
            if (value) moveFocusToHexConverter(this, EventArgs.empty)
        }
    private var _hexText: String = ""
    var hexText: String
        get() { /*@DONE EditorViewModel.HexText.get cs:195-195*/
            return _hexText
        }
        set(value) { /*@DONE EditorViewModel.HexText.set cs:196-200*/
            if (!tryUpdate(_hexText, value, "hexText", { _hexText = it })) return
            val result = doMath(_hexText) { text ->
                val number = Ref(0)
                if (text.tryParseHex(number)) number.value else null
            }
            set(_decText, result.toString(), "decText", { _decText = it })
        }
    private var _decText: String = ""
    var decText: String
        get() { /*@DONE EditorViewModel.DecText.get cs:205-205*/
            return _decText
        }
        set(value) { /*@DONE EditorViewModel.DecText.set cs:206-210*/
            if (!tryUpdate(_decText, value, "decText", { _decText = it })) return
            val result = doMath(_decText) { text ->
                val number = Ref(0)
                if (tryParseInt(text, number)) number.value else null
            }
            set(_hexText, result.toUInt().toString(16).uppercase(), "hexText", { _hexText = it })
        }
    private fun doMath(text: String, parse: (String) -> Int?): Int { /*@DONE EditorViewModel.DoMath/1 cs:213-229*/
        val operators = ArrayList<Int>()
        for (i in 0 until text.length) {
            if (text[i] == '+' || text[i] == '-') operators.add(i)
        }
        operators.add(text.length)
        var left: Int? = parse(text.substring(0, operators[0]))
        if (left == null) return 0
        for (i in 1 until operators.size) {
            val op = text[operators[i - 1]]
            val right = parse(text.substring(operators[i - 1] + 1, operators[i]))
            if (right == null) return 0
            left = when (op) {
                '-' -> left!! - right
                else -> left!! + right
            }
        }
        return left!!
    }
    fun runQuickEdit(edit: IQuickEditItem) { /*@DONE EditorViewModel.RunQuickEdit/1 cs:231-238*/
        var tab: ITabContent = tabs[selectedIndex]
        if (tab is MapEditorViewModel) {
            val map = tab
            tabChangeRequested(map, TabChangeRequestedEventArgs(map.viewPort))
            tab = map.viewPort
        }
        val viewPort = tab as IViewPort
        _gotoViewModel.controlVisible = false
        val errorTask = edit.run(viewPort)
        errorTask?.continueWith { completed -> continueQuickEdit(completed) }
    }
    private fun continueQuickEdit(completedTask: Task<ErrorInfo>) { /*@DONE EditorViewModel.ContinueQuickEdit/1 cs:239-249*/
        val viewPort = tabs[selectedIndex] as? IViewPort
        if (viewPort is IEditableViewPort) viewPort.clearProgress()
        val error = completedTask.result
        if (!error.hasError) return
        if (error.isWarning) {
            informationMessage = error.errorMessage ?: ""
        } else {
            errorMessage = error.errorMessage
        }
    }
    private var _searchBytes: ByteArray? = /*@INITAUTO EditorViewModel.searchBytes cs:251-251*/ null /*@ENDINIT*/
    var searchBytes: ByteArray?
        get() { /*@DONE EditorViewModel.SearchBytes.get cs:253-253*/
            return _searchBytes
        }
        set(value) { /*@DONE EditorViewModel.SearchBytes.set cs:254-257*/
            _searchBytes = value
            notifyPropertyChanged("searchBytes")
        }
    private var _findText: String = /*@INITAUTO EditorViewModel.findText cs:260-260*/ "" /*@ENDINIT*/
    var findText: String
        get() { /*@DONE EditorViewModel.FindText.get cs:262-262*/
            return _findText
        }
        set(value) { /*@DONE EditorViewModel.FindText.set cs:263-263*/
            set(_findText, value, "findText", { _findText = it }) { old -> findTextChanged(old) }
        }
    private fun findTextChanged(oldValue: String? = null) { /*@DONE EditorViewModel.FindTextChanged/1 cs:265-272*/
        val parsed = Ref<ByteArray?>(null)
        if (findControlVisible && tryParseBytes(_findText, parsed)) {
            searchBytes = parsed.value
        } else {
            searchBytes = null
        }
        val tab = selectedTab
        if (tab is IViewPort) tab.findBytes = searchBytes
    }
    private var _matchExactCase: Boolean = false
    var matchExactCase: Boolean
        get() { /*@DONE EditorViewModel.MatchExactCase.get cs:275-275*/
            return _matchExactCase
        }
        set(value) { /*@DONE EditorViewModel.MatchExactCase.set cs:275-275*/
            set(_matchExactCase, value, "matchExactCase", { _matchExactCase = it })
        }
    private var _searchAllFiles: Boolean = /*@INITAUTO EditorViewModel.searchAllFiles cs:277-277*/ true /*@ENDINIT*/
    var searchAllFiles: Boolean
        get() { /*@DONE EditorViewModel.SearchAllFiles.get cs:278-278*/
            return _searchAllFiles
        }
        set(value) { /*@DONE EditorViewModel.SearchAllFiles.set cs:278-278*/
            set(_searchAllFiles, value, "searchAllFiles", { _searchAllFiles = it })
        }
    private var _logAppStartupProgress: Boolean = false
    var logAppStartupProgress: Boolean
        get() { /*@DONE EditorViewModel.LogAppStartupProgress.get cs:282-282*/
            return _logAppStartupProgress
        }
        set(value) { /*@DONE EditorViewModel.LogAppStartupProgress.set cs:283-283*/
            set(_logAppStartupProgress, value, "logAppStartupProgress", { _logAppStartupProgress = it })
        }
    private var _zoomLevel: Int = /*@INITAUTO EditorViewModel.zoomLevel cs:286-286*/ 16 /*@ENDINIT*/
    var zoomLevel: Int
        get() { /*@DONE EditorViewModel.ZoomLevel.get cs:288-288*/
            return _zoomLevel
        }
        set(value) { /*@DONE EditorViewModel.ZoomLevel.set cs:289-289*/
            tryUpdate(_zoomLevel, value, "zoomLevel", { _zoomLevel = it })
        }
    private var _insertAutoActive: Boolean = /*@INITAUTO EditorViewModel.insertAutoActive cs:292-292*/ true /*@ENDINIT*/
    var insertAutoActive: Boolean
        get() { /*@DONE EditorViewModel.InsertAutoActive.get cs:294-294*/
            return _insertAutoActive
        }
        set(value) { /*@DONE EditorViewModel.InsertAutoActive.set cs:295-299*/
            set(_insertAutoActive, value, "insertAutoActive", { _insertAutoActive = it }) { old ->
                for (tab in tabs) {
                    if (tab is ViewPort) tab.tools?.codeTool?.insertAutoActive = _insertAutoActive
                }
            }
        }
    private var _showError: Boolean = false
    var showError: Boolean
        get() { /*@DONE EditorViewModel.ShowError.get cs:304-304*/
            return _showError
        }
        private set(value) { /*@DONE EditorViewModel.ShowError.set cs:305-313*/
            if (value) {
                _gotoViewModel.controlVisible = false
                findControlVisible = false
                hexConverterVisible = false
                showMessage = false
            }
            if (tryUpdate(_showError, value, "showError", { _showError = it })) _clearError.canExecuteChanged(_clearError, EventArgs.empty)
        }
    private var _errorMessage: String? = ""
    var errorMessage: String?
        get() { /*@DONE EditorViewModel.ErrorMessage.get cs:318-318*/
            return _errorMessage
        }
        set(value) { /*@DONE EditorViewModel.ErrorMessage.set cs:319-322*/
            tryUpdate(_errorMessage, value, "errorMessage", { _errorMessage = it })
            showError = !errorMessage.isNullOrEmpty()
        }
    private var _showMessage: Boolean = false
    var showMessage: Boolean
        get() { /*@DONE EditorViewModel.ShowMessage.get cs:327-327*/
            return _showMessage
        }
        private set(value) { /*@DONE EditorViewModel.ShowMessage.set cs:328-338*/
            if (value) {
                _gotoViewModel.controlVisible = false
                findControlVisible = false
                hexConverterVisible = false
                showError = false
            } else {
                infoMessage = ""
            }
            if (tryUpdate(_showMessage, value, "showMessage", { _showMessage = it })) _clearMessage.canExecuteChanged(_clearMessage, EventArgs.empty)
        }
    private var _useTableEntryHeaders: Boolean = /*@INITAUTO EditorViewModel.useTableEntryHeaders cs:341-341*/ true /*@ENDINIT*/
    var useTableEntryHeaders: Boolean
        get() { /*@DONE EditorViewModel.UseTableEntryHeaders.get cs:343-343*/
            return _useTableEntryHeaders
        }
        set(value) { /*@DONE EditorViewModel.UseTableEntryHeaders.set cs:344-349*/
            if (!tryUpdate(_useTableEntryHeaders, value, "useTableEntryHeaders", { _useTableEntryHeaders = it })) return
            for (tab in tabs) {
                if (tab is ViewPort) tab.useCustomHeaders = _useTableEntryHeaders
            }
        }
    private var _allowSingleTableMode: Boolean = /*@INITAUTO EditorViewModel.allowSingleTableMode cs:352-352*/ true /*@ENDINIT*/
    var allowSingleTableMode: Boolean
        get() { /*@DONE EditorViewModel.AllowSingleTableMode.get cs:354-354*/
            return _allowSingleTableMode
        }
        set(value) { /*@DONE EditorViewModel.AllowSingleTableMode.set cs:355-361*/
            set(_allowSingleTableMode, value, "allowSingleTableMode", { _allowSingleTableMode = it }) { arg ->
                for (tab in tabs) {
                    if (tab is IEditableViewPort) tab.allowSingleTableMode = _allowSingleTableMode
                }
            }
        }
    private var _spartanMode: Boolean = /*@INITAUTO EditorViewModel.spartanMode cs:364-364*/ false /*@ENDINIT*/
    var spartanMode: Boolean
        get() { /*@DONE EditorViewModel.SpartanMode.get cs:366-366*/
            return _spartanMode
        }
        set(value) { /*@DONE EditorViewModel.SpartanMode.set cs:367-374*/
            set(_spartanMode, value, "spartanMode", { _spartanMode = it }) { arg ->
                for (tab in tabs) {
                    tab.spartanMode = _spartanMode
                    tab.refresh()
                }
            }
        }
    private var _focusOnGotoShortcuts: Boolean = /*@INITAUTO EditorViewModel.focusOnGotoShortcuts cs:377-377*/ true /*@ENDINIT*/
    var focusOnGotoShortcuts: Boolean
        get() { /*@DONE EditorViewModel.FocusOnGotoShortcuts.get cs:379-379*/
            return _focusOnGotoShortcuts
        }
        set(value) { /*@DONE EditorViewModel.FocusOnGotoShortcuts.set cs:380-380*/
            set(_focusOnGotoShortcuts, value, "focusOnGotoShortcuts", { _focusOnGotoShortcuts = it })
        }
    var isNewVersionAvailable: Boolean = false
    var lastUpdateCheck: java.time.LocalDateTime = java.time.LocalDateTime.of(1, 1, 1, 0, 0)
    private var _showMatrix: Boolean = /*@INITAUTO EditorViewModel.showMatrix cs:386-386*/ true /*@ENDINIT*/
    var showMatrix: Boolean
        get() { /*@DONE EditorViewModel.ShowMatrix.get cs:387-387*/
            return _showMatrix
        }
        set(value) { /*@DONE EditorViewModel.ShowMatrix.set cs:387-387*/
            set(_showMatrix, value, "showMatrix", { _showMatrix = it })
        }
    private var _animateScroll: Boolean = /*@INITAUTO EditorViewModel.animateScroll cs:389-389*/ true /*@ENDINIT*/
    var animateScroll: Boolean
        get() { /*@DONE EditorViewModel.AnimateScroll.get cs:390-390*/
            return _animateScroll
        }
        set(value) { /*@DONE EditorViewModel.AnimateScroll.set cs:390-390*/
            set(_animateScroll, value, "animateScroll", { _animateScroll = it })
        }
    private var _autoAdjustDataWidth: Boolean = /*@INITAUTO EditorViewModel.autoAdjustDataWidth cs:392-392*/ true /*@ENDINIT*/
    var autoAdjustDataWidth: Boolean
        get() { /*@DONE EditorViewModel.AutoAdjustDataWidth.get cs:393-393*/
            return _autoAdjustDataWidth
        }
        set(value) { /*@DONE EditorViewModel.AutoAdjustDataWidth.set cs:393-393*/
            set(_autoAdjustDataWidth, value, "autoAdjustDataWidth", { _autoAdjustDataWidth = it })
        }
    private var _stretchData: Boolean = /*@INITAUTO EditorViewModel.stretchData cs:395-395*/ true /*@ENDINIT*/
    var stretchData: Boolean
        get() { /*@DONE EditorViewModel.StretchData.get cs:396-396*/
            return _stretchData
        }
        set(value) { /*@DONE EditorViewModel.StretchData.set cs:396-396*/
            set(_stretchData, value, "stretchData", { _stretchData = it })
        }
    private var _allowMultipleElementsPerLine: Boolean = /*@INITAUTO EditorViewModel.allowMultipleElementsPerLine cs:398-398*/ false /*@ENDINIT*/
    var allowMultipleElementsPerLine: Boolean
        get() { /*@DONE EditorViewModel.AllowMultipleElementsPerLine.get cs:399-399*/
            return _allowMultipleElementsPerLine
        }
        set(value) { /*@DONE EditorViewModel.AllowMultipleElementsPerLine.set cs:399-399*/
            set(_allowMultipleElementsPerLine, value, "allowMultipleElementsPerLine", { _allowMultipleElementsPerLine = it })
        }
    private var _tutorialsAcknowledged: Boolean = false
    private var _newVersionAcknowledged: Boolean = false
    var tutorialsAcknowledged: Boolean
        get() { /*@DONE EditorViewModel.TutorialsAcknowledged.get cs:402-402*/
            return _tutorialsAcknowledged
        }
        set(value) { /*@DONE EditorViewModel.TutorialsAcknowledged.set cs:402-402*/
            set(_tutorialsAcknowledged, value, "tutorialsAcknowledged", { _tutorialsAcknowledged = it })
        }
    var newVersionAcknowledged: Boolean
        get() { /*@DONE EditorViewModel.NewVersionAcknowledged.get cs:403-403*/
            return _newVersionAcknowledged
        }
        set(value) { /*@DONE EditorViewModel.NewVersionAcknowledged.set cs:403-403*/
            set(_newVersionAcknowledged, value, "newVersionAcknowledged", { _newVersionAcknowledged = it })
        }
    private var _base10Length: Boolean = false
    var base10Length: Boolean
        get() { /*@DONE EditorViewModel.Base10Length.get cs:406-406*/
            return _base10Length
        }
        set(value) { /*@DONE EditorViewModel.Base10Length.set cs:406-406*/
            set(_base10Length, value, "base10Length", { _base10Length = it })
        }
    private var _launchScriptsLocation: StubCommand? = null
    val launchScriptsLocation: ICommand
        get() { /*@DONE EditorViewModel.LaunchScriptsLocation.get cs:409-409*/
            return _launchScriptsLocation ?: stubCommand({ _fileSystem.launchProcess("resources/scripts") }).also { _launchScriptsLocation = it }
        }
    lateinit var theme: Theme
        private set
    val fileSystem: IFileSystem
        get() { /*@DONE EditorViewModel.FileSystem.get cs:413-413*/
            return _fileSystem
        }
    private var infoMessage: String = ""
    var informationMessage: String
        get() { /*@DONE EditorViewModel.InformationMessage.get cs:417-417*/
            return infoMessage
        }
        private set(value) { /*@DONE EditorViewModel.InformationMessage.set cs:418-420*/
            if (tryUpdate(infoMessage, value, "informationMessage", { infoMessage = it })) showMessage = !informationMessage.isNullOrEmpty()
        }
    private var maxDiffSegCount: Int = /*@INITAUTO EditorViewModel.maxDiffSegCount cs:423-423*/ 1000 /*@ENDINIT*/
    var maximumDiffSegments: Int
        get() { /*@DONE EditorViewModel.MaximumDiffSegments.get cs:424-424*/
            return maxDiffSegCount
        }
        set(value) { /*@DONE EditorViewModel.MaximumDiffSegments.set cs:424-424*/
            set(maxDiffSegCount, value.limitToRange(1, 10000), "maximumDiffSegments", { maxDiffSegCount = it })
        }
    var hideDiffPointerChanges: Boolean = false
    private var maxSearchResults: Int = /*@INITAUTO EditorViewModel.maxSearchResults cs:427-427*/ 400 /*@ENDINIT*/
    var maximumSearchResults: Int
        get() { /*@DONE EditorViewModel.MaximumSearchResults.get cs:428-428*/
            return maxSearchResults
        }
        set(value) { /*@DONE EditorViewModel.MaximumSearchResults.set cs:428-428*/
            set(maxSearchResults, value.limitToRange(1, 10000), "maximumSearchResults", { maxSearchResults = it })
        }
    val tools: IToolTrayViewModel?
        get() { /*@DONE EditorViewModel.Tools.get cs:430-430*/
            return (selectedTab as? IViewPort)?.tools
        }
    var quickEditsPokedex: List<IQuickEditItem> = ArrayList()
        private set
    var quickEditsExpansion: List<IQuickEditItem> = ArrayList()
        private set
    var quickEditsMisc: List<IQuickEditItem> = ArrayList()
        private set
    private var _showAutomationPanel: Boolean = false
    var showAutomationPanel: Boolean
        get() { /*@DONE EditorViewModel.ShowAutomationPanel.get cs:439-439*/
            return _showAutomationPanel
        }
        set(value) { /*@DONE EditorViewModel.ShowAutomationPanel.set cs:439-439*/
            set(_showAutomationPanel, value, "showAutomationPanel", { _showAutomationPanel = it })
        }
    private var _toggleShowAutomationPanelCommand: StubCommand? = null
    val toggleShowAutomationPanelCommand: ICommand
        get() { /*@DONE EditorViewModel.ToggleShowAutomationPanelCommand.get cs:441-441*/
            return _toggleShowAutomationPanelCommand ?: stubCommand({ showAutomationPanel = !showAutomationPanel }).also { _toggleShowAutomationPanelCommand = it }
        }
    lateinit var pythonTool: PythonTool
        private set
    lateinit var singletons: Singletons
        private set
    val requestDelayedWork = Event<() -> Unit>()
    val moveFocusToFind = Event<EventArgs>()
    val moveFocusToHexConverter = Event<EventArgs>()
    val moveFocusToPrimaryContent = Event<EventArgs>()
    override val collectionChanged = Event<NotifyCollectionChangedEventArgs>()
    operator fun get(index: Int): ITabContent { /*@DONE EditorViewModel.this/1.get cs:457-457*/
        return tabs[index]
    }
    val count: Int
        get() { /*@DONE EditorViewModel.Count.get cs:459-459*/
            return tabs.size
        }
    private var _selectedIndex: Int = 0
    var selectedIndex: Int
        get() { /*@DONE EditorViewModel.SelectedIndex.get cs:464-464*/
            return _selectedIndex
        }
        set(value) { /*@DONE EditorViewModel.SelectedIndex.set cs:465-485*/
            val guard = workWithoutListeningToCommandsFromCurrentTab()
            try {
                if (tryUpdate(_selectedIndex, value, "selectedIndex", { _selectedIndex = it })) {
                    _findPrevious.raiseCanExecuteChanged()
                    _findNext.raiseCanExecuteChanged()
                    _runFile.raiseCanExecuteChanged()
                    _duplicateCurrentTab.raiseCanExecuteChanged()
                    if (_selectedIndex >= 0 && _selectedIndex < tabs.size) tabs[_selectedIndex].refresh()
                    updateGotoViewModel()
                    for (edit in quickEditsPokedex + quickEditsExpansion + quickEditsMisc) edit.tabChanged()
                    notifyPropertyChanged("selectedTab")
                    notifyPropertyChanged("showWidthOptions")
                    notifyPropertyChanged("isMetadataOnlyChange")
                    notifyPropertyChanged("canCalculateHashes")
                    _diffLeft?.raiseCanExecuteChanged()
                    _diffRight?.raiseCanExecuteChanged()
                    val vp = selectedTab
                    if (vp is IViewPort) vp.findBytes = searchBytes
                    moveFocusToPrimaryContent(this, EventArgs.empty)
                }
            } finally {
                guard.dispose()
            }
        }
    val showWidthOptions: Boolean
        get() { /*@DONE EditorViewModel.ShowWidthOptions.get cs:488-488*/
            return selectedTab is IEditableViewPort
        }
    val selectedTab: ITabContent?
        get() { /*@DONE EditorViewModel.SelectedTab.get cs:489-489*/
            return if (selectedIndex < 0) null else tabs[selectedIndex]
        }
    var recentFiles: ObservableCollection<String> = ObservableCollection()
        private set
    var recentFileViewModels: ObservableCollection<RecentFileViewModel> = /*@INITAUTO EditorViewModel.RecentFileViewModels cs:492-492*/ ObservableCollection() /*@ENDINIT*/
        private set
    constructor(fileSystem: IFileSystem, workDispatcher: IWorkDispatcher? = null, allowLoadingMetadata: Boolean = true, utilities: List<IQuickEditItem>? = null) { /*@DONE EditorViewModel.<init>/1 cs:496-612*/
        _fileSystem = fileSystem

        val metadata = fileSystem.metadataFor(applicationName) ?: emptyArray()
        val copyLimitLine = metadata.firstOrNull { line -> line.startsWith("CopyLimit = ") }
        val copyLimitRef = Ref(0)
        val copyLimit = if (copyLimitLine == null || !tryParseInt(copyLimitLine.split('=').last().trim(), copyLimitRef)) 40000 else copyLimitRef.value
        singletons = Singletons(workDispatcher, copyLimit)

        this.workDispatcher = workDispatcher ?: InstantDispatch.instance
        this.allowLoadingMetadata = allowLoadingMetadata
        quickEditsPokedex = utilities ?: listOf<IQuickEditItem>(
            UpdateDexConversionTable(),
            ReorderDex("National", HardcodeTablesModel.nationalDexTableName),
            ReorderDex("Regional", HardcodeTablesModel.regionalDexTableName),
            LevelUpMoveSorter()
        ).map { edit -> EditItemWrapper(edit) }
        val expansionUtils = ArrayList<IQuickEditItem>()
        expansionUtils.add(ExpandRom(fileSystem))
        expansionUtils.add(MakeTutorsExpandable())
        expansionUtils.add(MakeMovesExpandable())
        expansionUtils.add(AddTilesetAnimation(fileSystem))
        // MakeTmsExpandable / MakeItemsExpandable: expanding TMs requires further research.
        if (!singletons.metadataInfo.isPublicRelease) {
            // beta features
            // expansionUtils.add(MakePokemonExpandable())
        }
        quickEditsExpansion = expansionUtils.map { edit -> EditItemWrapper(edit) }
        quickEditsMisc = listOf<IQuickEditItem>(
            RomOverview(),
            DecapNames(),
            ApplyCFRUPatch().also { it.editor = this }
        )

        tabs = ArrayList()
        _selectedIndex = -1

        implementCommands()

        _copy = createWrapperForSelected({ tab -> tab.copy }, true)
        _deepCopy = createWrapperForSelected({ tab -> tab.deepCopy }, true)
        _diffSinceLastSave = createWrapperForSelected({ tab -> tab.diff })
        _delete = createWrapperForSelected({ tab -> tab.clear }, true)
        _selectAll = createWrapperForSelected({ tab -> tab.selectAll }, true)
        _save = createWrapperForSelected({ tab -> tab.save })
        _saveAs = createWrapperForSelected({ tab -> tab.saveAs })
        _exportBackup = createWrapperForSelected({ tab -> tab.exportBackup })
        _close = createWrapperForSelected({ tab -> tab.close })
        _undo = createWrapperForSelected({ tab -> tab.undo }, true)
        _redo = createWrapperForSelected({ tab -> tab.redo }, true)
        _back = createWrapperForSelected({ tab -> tab.back }, true)
        _forward = createWrapperForSelected({ tab -> tab.forward }, true)
        _resetAlignment = createWrapperForSelected({ tab -> tab.resetAlignment }, true)
        _displayAsText = createWrapperForSelected({ tab -> (tab as? ViewPort)?.shortcuts?.displayAsText }, true)
        _displayAsEventScript = createWrapperForSelected({ tab -> (tab as? ViewPort)?.shortcuts?.displayAsEventScript }, true)
        _displayAsSprite = createWrapperForSelected({ tab -> (tab as? ViewPort)?.shortcuts?.displayAsSprite }, true)
        _displayAsColorPalette = createWrapperForSelected({ tab -> (tab as? ViewPort)?.shortcuts?.displayAsColorPalette }, true)

        _saveAll = createWrapperForAll({ tab -> tab.save })
        _closeAll = createWrapperForAll({ tab -> tab.close })

        val dispatcher = this.workDispatcher
        val forwards = LinkedHashMap<(ITabContent) -> ICommand?, EventHandler>()
        forwards[{ tab -> tab.copy }] = { sender, e -> _copy.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.deepCopy }] = { sender, e -> _deepCopy.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.diff }] = { sender, e -> _diffSinceLastSave.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.clear }] = { sender, e -> _delete.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.selectAll }] = { sender, e -> _selectAll.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.save }] = { sender, e -> _save.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.saveAs }] = { sender, e -> _saveAs.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.exportBackup }] = { sender, e -> _exportBackup.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.close }] = { sender, e -> _close.canExecuteChanged(this, e) }
        // refreshing undo from the background thread isn't allowed
        forwards[{ tab -> tab.undo }] = { sender, e -> dispatcher.dispatchWork { _undo.canExecuteChanged(this, e) } }
        forwards[{ tab -> tab.redo }] = { sender, e -> _redo.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.back }] = { sender, e -> _back.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.forward }] = { sender, e -> _forward.canExecuteChanged(this, e) }
        forwards[{ tab -> tab.resetAlignment }] = { sender, e -> _resetAlignment.canExecuteChanged(this, e) }
        forwards[{ tab -> (tab as? ViewPort)?.shortcuts?.displayAsText }] = { sender, e -> _displayAsText.raiseCanExecuteChanged() }
        forwards[{ tab -> (tab as? ViewPort)?.shortcuts?.displayAsEventScript }] = { sender, e -> _displayAsEventScript.raiseCanExecuteChanged() }
        forwards[{ tab -> (tab as? ViewPort)?.shortcuts?.displayAsSprite }] = { sender, e -> _displayAsSprite.raiseCanExecuteChanged() }
        forwards[{ tab -> (tab as? ViewPort)?.shortcuts?.displayAsColorPalette }] = { sender, e -> _displayAsColorPalette.raiseCanExecuteChanged() }
        forwardExecuteChangeNotifications = forwards

        theme = Theme(metadata)
        logAppStartupProgress = metadata.contains("LogAppStartupProgress = True")
        useTableEntryHeaders = !metadata.contains("UseTableEntryHeaders = False")
        allowSingleTableMode = !metadata.contains("AllowSingleTableMode = False")
        spartanMode = metadata.contains("SpartanMode = True")
        insertAutoActive = !metadata.contains("InsertAutoActive = False")
        showMatrix = !metadata.contains("ShowMatrixGrid = False")
        focusOnGotoShortcuts = !metadata.contains("FocusOnGotoShortcuts = False")
        animateScroll = !metadata.contains("AnimateScroll = False")
        autoAdjustDataWidth = !metadata.contains("AutoAdjustDataWidth = False")
        stretchData = !metadata.contains("StretchData = False")
        isNewVersionAvailable = metadata.contains("IsNewVersionAvailable = True")
        allowMultipleElementsPerLine = metadata.contains("AllowMultipleElementsPerLine = True")
        tutorialsAcknowledged = metadata.contains("AcknowledgeTutorials = True")
        base10Length = metadata.contains("Base10Length = True")
        val lastUpdateCheckLine = metadata.firstOrNull { line -> line.startsWith("LastUpdateCheck = ") }
        if (lastUpdateCheckLine != null) {
            val parsedCheck = parseDateTime(lastUpdateCheckLine.split('=').last().trim())
            if (parsedCheck != null) lastUpdateCheck = parsedCheck
        }
        val zoomLine = metadata.firstOrNull { line -> line.startsWith("ZoomLevel =") }
        val zoomRef = Ref(0)
        if (zoomLine != null && tryParseInt(zoomLine.split('=').last().trim(), zoomRef)) zoomLevel = zoomRef.value
        val maxDiffLine = metadata.firstOrNull { line -> line.startsWith("MaximumDiffSegments = ") }
        val maxDiffRef = Ref(0)
        if (maxDiffLine != null && tryParseInt(maxDiffLine.split('=').last().trim(), maxDiffRef)) maximumDiffSegments = maxDiffRef.value
        val maxSearchResultsLine = metadata.firstOrNull { line -> line.startsWith("MaximumSearchResults = ") }
        val maxSearchRef = Ref(0)
        if (maxSearchResultsLine != null && tryParseInt(maxSearchResultsLine.split('=').last().trim(), maxSearchRef)) maximumSearchResults = maxSearchRef.value

        val recentFilesLine = metadata.firstOrNull { line -> line.startsWith("RecentFiles = [") }
        if (recentFilesLine != null) {
            recentFiles = parseRecentFiles(recentFilesLine)
        } else {
            recentFiles = ObservableCollection()
        }
        populateRecentFilesViewModel()
        pythonTool = PythonTool(this)
        mapTutorials.load(metadata)
    }
    fun writeAppLevelMetadata() { /*@DONE EditorViewModel.WriteAppLevelMetadata/1 cs:619-647*/
        val metadata = ArrayList<String>()
        metadata.add("[GeneralSettings]")
        metadata.add("LogAppStartupProgress = ${boolText(logAppStartupProgress)}")
        metadata.add("UseTableEntryHeaders = ${boolText(useTableEntryHeaders)}")
        metadata.add("AllowSingleTableMode = ${boolText(allowSingleTableMode)}")
        metadata.add("InsertAutoActive = ${boolText(insertAutoActive)}")
        metadata.add("ShowMatrixGrid = ${boolText(showMatrix)}")
        metadata.add("FocusOnGotoShortcuts = ${boolText(focusOnGotoShortcuts)}")
        metadata.add("ZoomLevel = $zoomLevel")
        metadata.add("MaximumDiffSegments = $maximumDiffSegments")
        metadata.add("MaximumSearchResults = $maximumSearchResults")
        metadata.add("CopyLimit = ${singletons.copyLimit}")
        metadata.add("AnimateScroll = ${boolText(animateScroll)}")
        metadata.add("AutoAdjustDataWidth = ${boolText(autoAdjustDataWidth)}")
        metadata.add("StretchData = ${boolText(stretchData)}")
        metadata.add("AllowMultipleElementsPerLine = ${boolText(allowMultipleElementsPerLine)}")
        metadata.add("IsNewVersionAvailable = ${boolText(isNewVersionAvailable)}")
        metadata.add("LastUpdateCheck = ${formatDateTime(lastUpdateCheck)}")
        metadata.add("AcknowledgeTutorials = ${boolText(tutorialsAcknowledged)}")
        metadata.add("Base10Length = ${boolText(base10Length)}")
        metadata.add("SpartanMode = ${boolText(spartanMode)}")
        metadata.add(mapTutorials.serialize())
        metadata.add(serializeRecentFiles())
        metadata.add("")
        metadata.addAll(theme.serialize())
        _fileSystem.saveMetadata(applicationName, metadata.toTypedArray())
    }
    private fun implementCommands() { /*@DONE EditorViewModel.ImplementCommands/1 cs:649-753*/
        newCommand.canExecute = { arg -> canAlwaysExecute(arg) }
        newCommand.execute = { arg ->
            val model = PokemonModel(ByteArray(0), singletons = singletons)
            add(ViewPort("", model, workDispatcher, singletons, mapTutorials, fileSystem, pythonTool))
        }

        _open.canExecute = { arg -> canAlwaysExecute(arg) }
        _open.execute = { arg -> executeOpen(arg) }

        _duplicateCurrentTab.canExecute = { arg -> selectedTab?.canDuplicate ?: false }
        _duplicateCurrentTab.execute = { arg ->
            selectedTab?.duplicate()
            _gotoViewModel.controlVisible = true
        }

        _runFile.canExecute = { arg ->
            var tab = selectedTab
            if (tab is MapEditorViewModel) tab = tab.viewPort
            tab is IEditableViewPort && !tab.changeHistory.hasDataChange
        }
        _runFile.execute = { arg ->
            var tab = selectedTab
            if (tab is MapEditorViewModel) tab = tab.viewPort
            (arg as IFileSystem).launchProcess((tab as IEditableViewPort).fullFileName)
        }

        implementFindCommands()

        _showHexConverter.canExecute = { arg -> canAlwaysExecute(arg) }
        _showHexConverter.execute = { arg -> hexConverterVisible = arg as Boolean }

        _hideSearchControls.canExecute = { arg -> canAlwaysExecute(arg) }
        _hideSearchControls.execute = { arg ->
            _gotoViewModel.controlVisible = false
            findControlVisible = false
            hexConverterVisible = false
            showError = false
            showMessage = false
        }

        _clearError.canExecute = { arg -> showError }
        _clearError.execute = { arg ->
            errorMessage = ""
        }

        _clearMessage.canExecute = { arg -> showMessage }
        _clearMessage.execute = { arg -> informationMessage = "" }

        _toggleMatrix.canExecute = { arg -> canAlwaysExecute(arg) }
        _toggleMatrix.execute = { arg -> showMatrix = !showMatrix }

        _toggleScrollAnimation.canExecute = { arg -> canAlwaysExecute(arg) }
        _toggleScrollAnimation.execute = { arg -> animateScroll = !animateScroll }

        _resetZoom.canExecute = { arg -> canAlwaysExecute(arg) }
        _resetZoom.execute = { arg ->
            zoomLevel = 16
            for (tab in this) {
                if (tab is MapEditorViewModel) tab.resetZoom()
                if (tab is ViewPort) tab.tools?.codeTool?.fontSize = 12
            }
        }

        _resetTheme.canExecute = { arg -> canAlwaysExecute(arg) }
        _resetTheme.execute = { arg -> theme.reset() }

        _toggleTableHeaders.canExecute = { arg -> canAlwaysExecute(arg) }
        _toggleTableHeaders.execute = { arg -> useTableEntryHeaders = !useTableEntryHeaders }

        _cut.canExecute = { arg -> selectedTab?.copy?.canExecute(arg) ?: false }
        _cut.execute = { arg ->
            val tab = selectedTab
            if (tab != null && tab.copy != null && tab.clear != null) {
                if (tab is ViewPort) {
                    tab.cut(_fileSystem)
                } else {
                    tab.copy!!.execute(_fileSystem)
                    tab.clear!!.execute()
                }
            }
        }

        _paste.canExecute = { arg ->
            val tab = selectedTab
            tab is ViewPort || (tab is ImageEditorViewModel && tab.paste.canExecute(fileSystem))
        }
        _paste.execute = { arg -> executePaste() }
    }
    fun copyMessage() { /*@DONE EditorViewModel.CopyMessage/1 cs:755-755*/
        _fileSystem.copyText = informationMessage
    }
    fun copyError() { /*@DONE EditorViewModel.CopyError/1 cs:757-757*/
        _fileSystem.copyText = errorMessage
    }
    private fun executeOpen(arg: Any?) { /*@DONE EditorViewModel.ExecuteOpen/1 cs:759-800*/
        try {
            val file: LoadedFile? = (arg as? LoadedFile) ?: _fileSystem.openFile("GameBoy Advanced", "gba")
            if (file == null) return

            val current = selectedTab
            if (current is IEditableViewPort) {
                val workload = current.model?.initializationWorkload
                if (workload != null && !workload.isCompleted) {
                    // the C# code awaits the initialization workload before importing; continue once it is done.
                    workload.onCompleted { continueOpen(file) }
                    return
                }
            }
            continueOpen(file)
        } catch (ex: java.io.IOException) {
            errorMessage = ex.message
        }
    }
    private fun implementFindCommands() { /*@DONE EditorViewModel.ImplementFindCommands/1 cs:802-836*/
        _find.canExecute = { arg -> canAlwaysExecute(arg) }
        _find.execute = { arg -> findExecuted(arg as String?) }

        _findPrevious.canExecute = { arg -> recentFindResults.any { pair -> pair.first === selectedTab } }
        _findPrevious.execute = { arg ->
            var attemptCount = 0
            while (attemptCount < recentFindResults.size) {
                attemptCount++
                currentFindResultIndex--
                if (currentFindResultIndex < 0) currentFindResultIndex += recentFindResults.size
                val (tab, start, end) = recentFindResults[currentFindResultIndex]
                if (tab !== selectedTab) continue
                jumpTo(tab, start, end)
                break
            }
        }

        _findNext.canExecute = { arg -> recentFindResults.any { pair -> pair.first === selectedTab } }
        _findNext.execute = { arg ->
            var attemptCount = 0
            while (attemptCount < recentFindResults.size) {
                attemptCount++
                currentFindResultIndex++
                if (currentFindResultIndex >= recentFindResults.size) currentFindResultIndex -= recentFindResults.size
                val (tab, start, end) = recentFindResults[currentFindResultIndex]
                if (tab !== selectedTab) continue
                jumpTo(tab, start, end)
                break
            }
        }

        _showFind.canExecute = { arg -> canAlwaysExecute(arg) }
        _showFind.execute = { arg -> findControlVisible = (arg ?: !findControlVisible) as Boolean }
    }
    fun add(content: ITabContent) { /*@DONE EditorViewModel.Add/1 cs:845-884*/
        content.spartanMode = _spartanMode
        tabs.add(content)
        selectedIndex = tabs.size - 1
        addContentListeners(content)
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, listOf<Any?>(content)))
        if (content is IViewPort) {
            val viewModel = content
            val viewModelData = viewModel.model
            if (viewModelData != null) {
                viewModelData.initializationWorkload.continueWith { task ->
                    singletons.workDispatcher?.dispatchWork {
                        for (edit in quickEditsPokedex + quickEditsExpansion + quickEditsMisc) edit.tabChanged()
                        _gotoViewModel.refreshOptions()
                        val collection = createGotoShortcuts(_gotoViewModel)
                        if (collection != null) _gotoViewModel.shortcuts = ObservableCollection(collection)
                    }
                }
            }
            viewModel.useCustomHeaders = useTableEntryHeaders
            viewModel.base10Length = base10Length
            if (viewModel is IEditableViewPort) viewModel.allowSingleTableMode = allowSingleTableMode
            viewModel.autoAdjustDataWidth = autoAdjustDataWidth
            viewModel.allowMultipleElementsPerLine = allowMultipleElementsPerLine
            viewModel.stretchData = stretchData
            if (content is ViewPort) {
                val viewPort = content
                val codeTool = viewPort.tools?.codeTool
                codeTool?.insertAutoActive = insertAutoActive
                codeTool?.bind("insertAutoActive") { tool, e -> insertAutoActive = tool.insertAutoActive }
                var anyTabsHaveMatchingViewModel = false
                for (tab in tabs) {
                    if (tab is MapEditorViewModel) anyTabsHaveMatchingViewModel = anyTabsHaveMatchingViewModel or (tab.viewPort === viewPort)
                    if (tab !is ViewPort) continue
                    if (tab === viewPort) continue
                    anyTabsHaveMatchingViewModel = anyTabsHaveMatchingViewModel or (tab.model === viewPort.model)
                }
                if (!anyTabsHaveMatchingViewModel && viewPort.fileName.lowercase().endsWith(".gba")) {
                    errorMessage = ""
                    informationMessage = ""
                    _gotoViewModel.controlVisible = true
                }
            }
        }
        refreshTabHeaderContextMenus()
    }
    private fun closeOtherViewports(sender: Any?, e: IDataModel) { /*@DONE EditorViewModel.CloseOtherViewports/1 cs:886-898*/
        if (sender !is IViewPort) return
        val viewPort = sender
        var anyTabsClosed = false
        var i = 0
        while (i < count) {
            val target = tabs[i] as? IViewPort
            if (target == null) { i++; continue }
            if (target === viewPort) { i++; continue }
            if (target.model !== viewPort.model) { i++; continue }
            removeTab(target, EventArgs.empty)
            i -= 1
            anyTabsClosed = true
            i++
        }
        if (anyTabsClosed) informationMessage = "Other tabs for that in-memory file were automatically closed."
    }
    val canCalculateHashes: Boolean
        get() { /*@DONE EditorViewModel.CanCalculateHashes.get cs:902-902*/
            return selectedTab is IEditableViewPort
        }
    fun calculateHashes() { /*@DONE EditorViewModel.CalculateHashes/1 cs:903-909*/
        val viewPort = selectedTab as? IEditableViewPort ?: return
        val sha = getSHA1(viewPort)
        val crc = getCRC32(viewPort)
        val nl = NEW_LINE
        _fileSystem.showCustomMessageBox("SHA1:" + nl + sha + nl + nl + "CRC32:" + nl + crc, false)
    }
    fun swapTabs(a: Int, b: Int) { /*@DONE EditorViewModel.SwapTabs/1 cs:924-939*/
        val temp = tabs[a]
        tabs[a] = tabs[b]
        tabs[b] = temp

        // if one of the items to swap is selected, swap the selection too
        if (_selectedIndex == a) {
            _selectedIndex = b
        } else if (_selectedIndex == b) {
            _selectedIndex = a
        }

        val args = NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Move, listOf<Any?>(tabs[a]), listOf<Any?>(tabs[a]), a, b)
        collectionChanged(this, args)
        refreshTabHeaderContextMenus()
    }
    private fun refreshTabHeaderContextMenus() { /*@DONE EditorViewModel.RefreshTabHeaderContextMenus/1 cs:941-947*/
        _diffLeft?.raiseCanExecuteChanged()
        _diffRight?.raiseCanExecuteChanged()
        for (tab in tabs) {
            if (tab is ViewPort) tab.refreshTabCommands()
        }
    }
    override fun iterator(): Iterator<ITabContent> { /*@DONE EditorViewModel.GetEnumerator/1 cs:949-949*/
        return tabs.iterator()
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    private var _diffLeft: StubCommand? = null
    private var _diffRight: StubCommand? = null
    val diffLeft: ICommand
        get() { /*@DONE EditorViewModel.DiffLeft.get cs:956-956*/
            return _diffLeft ?: stubCommandOf<ITabContent>({ tab -> executeDiffLeft(tab) }, { tab -> canExecuteDiffLeft(tab) }).also { _diffLeft = it }
        }
    val diffRight: ICommand
        get() { /*@DONE EditorViewModel.DiffRight.get cs:957-957*/
            return _diffRight ?: stubCommandOf<ITabContent>({ tab -> executeDiffRight(tab) }, { tab -> canExecuteDiffRight(tab) }).also { _diffRight = it }
        }
    private fun canDiffRequested(sender: Any?, e: CanDiffEventArgs) { /*@DONE EditorViewModel.CanDiffRequested/1 cs:959-963*/
        val tab = sender as ITabContent
        if (e.direction == Direction.Left) e.result = canExecuteDiffLeft(tab)
        if (e.direction == Direction.Right) e.result = canExecuteDiffRight(tab)
    }
    private fun diffRequested(sender: Any?, direction: Direction) { /*@DONE EditorViewModel.DiffRequested/1 cs:965-969*/
        val tab = sender as ITabContent
        if (direction == Direction.Left) executeDiffLeft(tab)
        if (direction == Direction.Right) executeDiffRight(tab)
    }
    private fun canCreatePatch(sender: Any?, e: CanPatchEventArgs) { /*@DONE EditorViewModel.CanCreatePatch/1 cs:971-988*/
        val tab = sender as ITabContent
        val index = tabs.indexOf(tab)
        val otherIndex = when (e.direction) {
            Direction.Left -> index - 1
            Direction.Right -> index + 1
            else -> throw NotImplementedError()
        }

        if (otherIndex < 0 || otherIndex >= tabs.size) return
        val viewPort1 = tabs[index] as? ViewPort ?: return
        val viewPort2 = tabs[otherIndex] as? ViewPort ?: return
        val bigFile = viewPort1.model!!.count > 0x1000000 || viewPort2.model!!.count > 0x1000000
        if (e.patchType == PatchType.Ips && bigFile) return
        if (!viewPort1.changeHistory.isSaved || !viewPort2.changeHistory.isSaved) return

        e.result = true
    }
    private fun createPatch(sender: Any?, e: CanPatchEventArgs) { /*@DONE EditorViewModel.CreatePatch/1 cs:990-1028*/
        val tab = sender as ITabContent
        val index = tabs.indexOf(tab)
        val otherIndex = when (e.direction) {
            Direction.Left -> index - 1
            Direction.Right -> index + 1
            else -> throw NotImplementedError()
        }

        if (otherIndex < 0 || otherIndex >= tabs.size) return
        val viewPort1 = tabs[index] as? ViewPort ?: return
        val viewPort2 = tabs[otherIndex] as? ViewPort ?: return
        val bigFile = viewPort1.model!!.count > 0x1000000 || viewPort2.model!!.count > 0x1000000
        if (e.patchType == PatchType.Ips && bigFile) return
        if (!viewPort1.changeHistory.isSaved || !viewPort2.changeHistory.isSaved) return

        val extension: String
        val patchData: ByteArray
        if (e.patchType == PatchType.Ips) {
            patchData = Patcher.buildIpsPatch(viewPort1.model!!.rawData, viewPort2.model!!.rawData)
            extension = "ips"
        } else if (e.patchType == PatchType.Ups) {
            patchData = Patcher.buildUpsPatch(viewPort1.model!!.rawData, viewPort2.model!!.rawData)
            extension = "ups"
        } else {
            throw NotImplementedError()
        }

        val path = Path.getDirectoryName(viewPort1.fullFileName) ?: ""
        var defaultName: String? = path + "/" + viewPort1.name + "_to_" + viewPort2.name + "." + extension
        if (!_fileSystem.exists(defaultName!!)) {
            _fileSystem.save(LoadedFile(defaultName, patchData))
        } else {
            defaultName = _fileSystem.requestNewName(defaultName, "Patch", extension)
            if (defaultName == null) return
            _fileSystem.save(LoadedFile(defaultName, patchData))
        }
        informationMessage = "Created " + defaultName
    }
    private fun executeDiffLeft(tab: ITabContent?) { /*@DONE EditorViewModel.ExecuteDiffLeft/1 cs:1030-1036*/
        val current = tab ?: selectedTab
        val index = tabs.indexOf(current)
        val leftIndex = index - 1
        if (leftIndex < 0) return
        diffTabs(leftIndex, index)
    }
    private fun canExecuteDiffLeft(tab: ITabContent?): Boolean { /*@DONE EditorViewModel.CanExecuteDiffLeft/1 cs:1037-1042*/
        val current = tab ?: selectedTab
        val index = tabs.indexOf(current)
        val leftIndex = index - 1
        return leftIndex >= 0 && tabs[leftIndex] is ViewPort && tabs[index] is ViewPort
    }
    private fun executeDiffRight(tab: ITabContent?) { /*@DONE EditorViewModel.ExecuteDiffRight/1 cs:1044-1050*/
        val current = tab ?: selectedTab
        val index = tabs.indexOf(current)
        val rightIndex = index + 1
        if (rightIndex >= tabs.size) return
        diffTabs(index, rightIndex)
    }
    private fun canExecuteDiffRight(tab: ITabContent?): Boolean { /*@DONE EditorViewModel.CanExecuteDiffRight/1 cs:1051-1056*/
        val current = tab ?: selectedTab
        val index = tabs.indexOf(current)
        val rightIndex = index + 1
        return index >= 0 && rightIndex < tabs.size && tabs[index] is ViewPort && tabs[rightIndex] is ViewPort
    }
    private fun diffTabs(left: Int, right: Int) { /*@DONE EditorViewModel.DiffTabs/1 cs:1058-1071*/
        val leftViewPort = tabs[left] as? ViewPort
        if (leftViewPort == null) {
            errorMessage = "You can only diff data tabs!"
            return
        }
        val rightViewPort = tabs[right] as? ViewPort
        if (rightViewPort == null) {
            errorMessage = "You can only diff data tabs!"
            return
        }

        leftViewPort.maxDiffSegmentCount = maxDiffSegCount
        leftViewPort.hideDiffPointerChanges = hideDiffPointerChanges
        leftViewPort.diff.execute(rightViewPort)
    }
    private fun createWrapperForSelected(commandGetter: (ITabContent) -> ICommand?, preventIfScreenBlocked: Boolean = false): StubCommand { /*@DONE EditorViewModel.CreateWrapperForSelected/1 cs:1087-1119*/
        val command = StubCommand()
        command.canExecute = { arg ->
            if (selectedIndex < 0) {
                false
            } else {
                val innerCommand = commandGetter(tabs[selectedIndex])
                if (innerCommand == null) false else innerCommand.canExecute(_fileSystem)
            }
        }
        fun executeWrapped(arg: Any?) {
            if (preventIfScreenBlocked && _gotoViewModel.controlVisible) return // don't execute this command while the screen is blocked by the goto panel
            val tab = tabs[selectedIndex]
            val innerCommand = commandGetter(tab)
            if (innerCommand == null) return

            // special case: for save/save as, remove the file listener
            // otherwise the filesystem will notify us of our own change
            if ((innerCommand === tab.save || innerCommand === tab.saveAs) && tab is IViewPort && !tab.fileName.isNullOrEmpty()) {
                val viewPort = tab
                _fileSystem.removeListenerForFile(viewPort.fileName, viewPort::considerReload)
                val guard = StubDisposable { _fileSystem.addListenerToFile(viewPort.fileName, viewPort::considerReload) }
                try {
                    innerCommand.execute(_fileSystem)
                    updateRecentFiles(viewPort.fileName)
                } finally {
                    guard.dispose()
                }
            } else {
                if (tab is ViewPort) tab.maxDiffSegmentCount = this.maxDiffSegCount
                innerCommand.execute(_fileSystem)
            }
        }
        command.execute = { arg -> executeWrapped(arg) }

        commandsToRefreshOnTabChange.add(command)

        return command
    }
    private fun createWrapperForAll(commandGetter: (ITabContent) -> ICommand?): StubCommand { /*@DONE EditorViewModel.CreateWrapperForAll/1 cs:1121-1132*/
        val command = StubCommand()
        command.canExecute = { arg -> tabs.any { tab -> commandGetter(tab)?.canExecute(_fileSystem) ?: false } }
        command.execute = { arg ->
            // some commands may modify the tabs. Make a copy of the list before running a foreach.
            tabs.toList().forEach { tab ->
                val inner = commandGetter(tab)
                if (inner != null && inner.canExecute(_fileSystem)) {
                    inner.execute(_fileSystem)
                }
            }
        }

        return command
    }
    private fun findExecuted(search: String?) { /*@DONE EditorViewModel.FindExecuted/1 cs:1134-1191*/
        val query = search ?: _findText
        val results = ArrayList<Triple<IViewPort, Int, Int>>()

        val searchedModels = ArrayList<IDataModel?>()
        for (tab in tabs) {
            val searchThisTab = _searchAllFiles || tab === selectedTab
            if (searchThisTab && tab is IViewPort && searchedModels.all { model -> model !== tab.model }) {
                if (tab !== selectedTab && tabs.any { other -> other is IViewPort && other === selectedTab && other.model === tab.model }) {
                    // don't include results from this tab
                    // a different tab has the same model and is selected
                    // we'll get results from that tab instead.
                } else {
                    tab.model?.initializationWorkload?.waitSync()
                    results.addAll(tab.find(query, _matchExactCase).map { offset -> Triple<IViewPort, Int, Int>(tab, offset.start, offset.end) })
                    searchedModels.add(tab.model)
                }
            }
        }

        findControlVisible = false

        if (results.size == 0) {
            if (query.length < 4) {
                errorMessage = "Query '" + query + "' is too short. Narrow your search."
            } else {
                errorMessage = "Could not find " + query + "."
            }
            return
        }

        recentFindResults = results.toList()
        _findPrevious.canExecuteChanged(_findPrevious, EventArgs.empty)
        _findNext.canExecuteChanged(_findNext, EventArgs.empty)

        if (results.size == 1) {
            val (tab, start, end) = results[0]
            selectedIndex = tabs.indexOf(tab)
            tab.goto?.execute(start.toHex(2))
            if (tab is ViewPort) SearchResultsViewPort.selectRange(tab, SelectionRange().also { it.start = start; it.end = end })
            return
        }

        if (results.size > maximumSearchResults) {
            errorMessage = "Found " + results.size + " results: please refine your search."
            return
        }

        val newTab = SearchResultsViewPort(query)
        for ((tab, start, end) in results) {
            newTab.add(tab.createChildView(start, end), start, end)
        }

        add(newTab)
        informationMessage = "Found " + results.size + " matches for '" + query + "'."
    }
    private fun removeTab(sender: Any?, e: EventArgs) { /*@DONE EditorViewModel.RemoveTab/1 cs:1193-1225*/
        val tab = sender as ITabContent
        if (!tabs.contains(tab)) return
        val index = tabs.indexOf(tab)

        // if the tab to remove is the selected tab, select the next tab (or the previous if there is no next)
        if (index == selectedIndex) {
            val guard = workWithoutListeningToCommandsFromCurrentTab()
            try {
                tabs.remove(tab)
                removeContentListeners(tab)
                if (_selectedIndex == tabs.size) selectedIndex = tabs.size - 1
                try {
                    collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, null, listOf<Any?>(tab), -1, index))
                } catch (ex: IndexOutOfBoundsException) {
                    // in some cases, the collection may have already noticed the change due to UI updates.
                    // in this situation, the index may be out of range, and we may catch an exception.
                    // If that happens, just do a hard reset on the collection as a backup.
                    collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset))
                }
            } finally {
                guard.dispose()
            }
            updateGotoViewModel()
            return
        }

        // if the removed tab was left of the selected tab, we need to adjust the selected index based on the removal
        if (index < selectedIndex) _selectedIndex--

        removeContentListeners(tab)
        tabs.remove(tab)
        collectionChanged(this, NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, null, listOf<Any?>(tab), -1, index))
        _diffLeft?.raiseCanExecuteChanged()
        _diffRight?.raiseCanExecuteChanged()
    }
    private fun addContentListeners(content: ITabContent) { /*@DONE EditorViewModel.AddContentListeners/1 cs:1227-1248*/
        content.closed += tabClosedHandler
        content.onError += tabErrorHandler
        content.onMessage += tabMessageHandler
        content.clearMessage += tabClearMessageHandler
        content.requestTabChange += tabChangeRequestedHandler
        content.requestDelayedWork += tabDelayedWorkHandler
        content.requestCanDiff += tabCanDiffHandler
        content.requestDiff += tabDiffHandler
        content.requestCanCreatePatch += tabCanCreatePatchHandler
        content.requestCreatePatch += tabCreatePatchHandler
        content.propertyChanged += tabPropertyChangedHandler
        content.requestRefreshGotoShortcuts += tabRefreshGotoShortcutsHandler
        val saveCommand = content.save
        if (saveCommand != null) saveCommand.canExecuteChanged += tabSaveCanExecuteChangedHandler

        if (content is IViewPort) {
            content.requestCloseOtherViewports += tabCloseOtherViewportsHandler
            if (!content.fileName.isNullOrEmpty()) {
                _fileSystem.addListenerToFile(content.fileName, content::considerReload)
            }
        }
    }
    private fun removeContentListeners(content: ITabContent) { /*@DONE EditorViewModel.RemoveContentListeners/1 cs:1250-1271*/
        content.closed -= tabClosedHandler
        content.onError -= tabErrorHandler
        content.onMessage -= tabMessageHandler
        content.clearMessage -= tabClearMessageHandler
        content.requestTabChange -= tabChangeRequestedHandler
        content.requestDelayedWork -= tabDelayedWorkHandler
        content.requestCanDiff -= tabCanDiffHandler
        content.requestDiff -= tabDiffHandler
        content.requestCanCreatePatch -= tabCanCreatePatchHandler
        content.requestCreatePatch -= tabCreatePatchHandler
        content.propertyChanged -= tabPropertyChangedHandler
        content.requestRefreshGotoShortcuts -= tabRefreshGotoShortcutsHandler
        val saveCommand = content.save
        if (saveCommand != null) saveCommand.canExecuteChanged -= tabSaveCanExecuteChangedHandler

        if (content is IViewPort) {
            content.requestCloseOtherViewports -= tabCloseOtherViewportsHandler
            if (!content.fileName.isNullOrEmpty()) {
                _fileSystem.removeListenerForFile(content.fileName, content::considerReload)
            }
        }
    }
    private fun refreshGotoShortcuts(sender: Any?, e: EventArgs) { /*@DONE EditorViewModel.RefreshGotoShortcuts/1 cs:1273-1277*/
        if (selectedTab !== sender) return
        val collection = createGotoShortcuts(_gotoViewModel)
        if (collection != null) _gotoViewModel.shortcuts = ObservableCollection(collection)
    }
    private fun updateGotoViewModel() { /*@DONE EditorViewModel.UpdateGotoViewModel/1 cs:1279-1297*/
        _gotoViewModel.propertyChanged -= gotoPropertyChangedHandler
        val docs = ArrayList<DocLabel>()
        val currentTab = selectedTab
        if (currentTab is IEditableViewPort) {
            val currentModel = currentTab.model
            if (currentModel != null && currentModel.count >= 0x100) {
                val gameCode = currentModel.getGameCode()
                val fixedDocs = if (gameCode.length >= 4) singletons.docReference[gameCode.substring(0, 4)] else null
                if (fixedDocs != null) docs.addAll(fixedDocs)
            }
        }

        val previousText = _gotoViewModel.text
        val newGoto = GotoControlViewModel(selectedTab, workDispatcher, docs, showDevMenu)
        newGoto.showAll = !focusOnGotoShortcuts
        newGoto.text = previousText
        gotoViewModel = newGoto
        val collection = createGotoShortcuts(_gotoViewModel)
        if (collection != null) _gotoViewModel.shortcuts = ObservableCollection(collection)
        _gotoViewModel.propertyChanged += gotoPropertyChangedHandler
        val vp1 = selectedTab
        val baseModel = (vp1 as? IEditableViewPort)?.model as? BaseModel
        if (vp1 is IEditableViewPort && baseModel != null) {
            val vm = _gotoViewModel
            vp1.initializationWorkload.continueWith { task ->
                if (vm === _gotoViewModel) vm.updateDocs(baseModel.generateDocumentationLabels(singletons.scriptLines))
            }
        }
        notifyPropertyChanged("tools")
    }
    private fun createGotoShortcuts(gotoViewModel: GotoControlViewModel): List<GotoShortcutViewModel>? { /*@DONE EditorViewModel.CreateGotoShortcuts/1 cs:1299-1345*/
        var tab: ITabContent? = selectedTab
        if (tab is MapEditorViewModel) tab = tab.viewPort
        if (tab !is IEditableViewPort) {
            gotoViewModel.loading = false
            return null
        }
        val viewPort = tab
        val model = viewPort.model
        if (model == null) {
            gotoViewModel.loading = false
            return null
        }
        model.initializationWorkload.continueWith { task -> singletons.workDispatcher?.dispatchWork { gotoViewModel.loading = false } }
        val results = ArrayList<GotoShortcutViewModel>()
        for (i in 0 until model.gotoShortcuts.size) {
            val destinationAddress = model.getAddressFromAnchor(ModelDelta(), -1, model.gotoShortcuts[i].gotoAnchor)
            if (destinationAddress == Pointer.null_) {
                val destination = model.gotoShortcuts[i].gotoAnchor
                var matchingMaps: List<MapInfo> = model.getMatchingMaps(destination)
                if (matchingMaps.size > 1) {
                    matchingMaps = matchingMaps.filter { info -> info.name.contains(destination) }
                }
                if (matchingMaps.size != 1) continue
            }

            var sprite: IPixelViewModel?
            val spriteAddress = model.getAddressFromAnchor(ModelDelta(), -1, model.gotoShortcuts[i].imageAnchor)
            val run = model.getNextRun(spriteAddress) as? BaseRun
            if (model.gotoShortcuts[i].imageAnchor.endsWith("/")) {
                val length = model.gotoShortcuts[i].imageAnchor.length
                val source = model.getAddressFromAnchor(ModelDelta(), -1, model.gotoShortcuts[i].imageAnchor.substring(0, length - 1))
                sprite = if (run != null) ToolTipContentVisitor.buildContentForRun(model, source, spriteAddress, run) as? IPixelViewModel else null
            } else {
                if (run is ISpriteRun) {
                    sprite = SpriteDecorator.buildSprite(model, run, useTransparency = true)
                } else {
                    val format = run?.createDataFormat(model, run.start, true, 16)
                    sprite = if (format is SpriteDecorator) format.pixels else null
                }
            }
            val anchor = model.gotoShortcuts[i].gotoAnchor
            val text = model.gotoShortcuts[i].displayText
            results.add(GotoShortcutViewModel(gotoViewModel, viewPort, sprite, anchor, text))
        }
        return results
    }
    private fun forwardDelayedWork(sender: Any?, e: () -> Unit) { /*@DONE EditorViewModel.ForwardDelayedWork/1 cs:1347-1347*/
        requestDelayedWork(this, e)
    }
    private fun tabPropertyChanged(sender: Any?, e: PropertyChangedEventArgs) { /*@DONE EditorViewModel.TabPropertyChanged/1 cs:1349-1397*/
        if (e.propertyName == "isMetadataOnlyChange") {
            notifyPropertyChanged("isMetadataOnlyChange")
        }

        if (e.propertyName == "fileName" && sender is IViewPort) {
            val args = e as? ExtendedPropertyChangedEventArgs<*>
            val oldName = args?.oldValue as? String

            if (!oldName.isNullOrEmpty()) _fileSystem.removeListenerForFile(oldName, sender::considerReload)
            if (!sender.fileName.isNullOrEmpty()) _fileSystem.addListenerToFile(sender.fileName, sender::considerReload)
        }

        if (e.propertyName == "name") {
            // the file's display name changes whenever it's edited or saved (trailing *)
            workDispatcher.dispatchWork { _runFile.raiseCanExecuteChanged() }
        }

        // when one tab's height updates, update other tabs by the same amount.
        // this isn't perfect, since tabs shouldn't nessisarily change height at the same pixel.
        // but it'll keep the tabs that are out of view from getting totally out of sync.
        if (sender is IViewPort) {
            val viewPort2 = sender
            if (e.propertyName == "autoAdjustDataWidth") autoAdjustDataWidth = viewPort2.autoAdjustDataWidth
            if (e.propertyName == "stretchData") stretchData = viewPort2.stretchData
            if (e.propertyName == "allowMultipleElementsPerLine") allowMultipleElementsPerLine = viewPort2.allowMultipleElementsPerLine
            if (e.propertyName == "base10Length") base10Length = viewPort2.base10Length
            for (tab in this) {
                if (tab === viewPort2) continue
                if (tab !is IViewPort) continue
                val viewPort3 = tab
                val syncedProperties = arrayOf("height", "autoAdjustDataWidth", "stretchData", "allowMultipleElementsPerLine", "base10Length")
                if (!syncedProperties.contains(e.propertyName)) continue // filter to only the properties wo care about so we don't Remove/Add Content Listeners unless we need to.
                removeContentListeners(tab)
                if (e.propertyName == "height") {
                    val args = e as? ExtendedPropertyChangedEventArgs<*>
                    val oldHeight = (args?.oldValue as? Int) ?: viewPort2.height
                    viewPort3.height += viewPort2.height - oldHeight
                } else if (e.propertyName == "autoAdjustDataWidth") {
                    viewPort3.autoAdjustDataWidth = autoAdjustDataWidth
                } else if (e.propertyName == "stretchData") {
                    viewPort3.stretchData = stretchData
                } else if (e.propertyName == "allowMultipleElementsPerLine") {
                    viewPort3.allowMultipleElementsPerLine = allowMultipleElementsPerLine
                } else if (e.propertyName == "base10Length") {
                    viewPort3.base10Length = base10Length
                }
                addContentListeners(tab)
            }
        }
    }
    private fun gotoPropertyChanged(sender: Any?, e: PropertyChangedEventArgs) { /*@DONE EditorViewModel.GotoPropertyChanged/1 cs:1399-1411*/
        if (e.propertyName == "controlVisible") {
            if (_gotoViewModel.controlVisible) {
                clearError.execute()
                clearMessage.execute()
                findControlVisible = false
                hexConverterVisible = false
            } else {
                moveFocusToPrimaryContent(this, EventArgs.empty)
            }
        }
        if (e.propertyName == "showAll") focusOnGotoShortcuts = !_gotoViewModel.showAll
    }
    private fun acceptError(sender: Any?, message: String) { /*@DONE EditorViewModel.AcceptError/1 cs:1413-1416*/
        if (sender is MapEditorViewModel) sender.viewPort.tools?.logTool?.logMessages?.add("Error: " + message)
        errorMessage = message
    }
    private fun acceptMessage(sender: Any?, message: String) { /*@DONE EditorViewModel.AcceptMessage/1 cs:1418-1421*/
        if (sender is MapEditorViewModel) sender.viewPort.tools?.logTool?.logMessages?.add("Message: " + message)
        informationMessage = message
    }
    private fun acceptMessageClear(sender: Any?, e: EventArgs) { /*@DONE EditorViewModel.AcceptMessageClear/1 cs:1423-1423*/
        hideSearchControls.execute()
    }
    private fun parseRecentFiles(recentFilesLine: String): ObservableCollection<String> { /*@DONE EditorViewModel.ParseRecentFiles/1 cs:1425-1437*/
        val list = ObservableCollection<String>()
        var content = recentFilesLine.split('[')[1]
        content = content.split(']')[0]

        for (segment in content.split(',')) {
            val element = segment.trim(' ', '"', '\'')
            if (!_fileSystem.exists(element)) continue
            list.add(element)
        }

        return list
    }
    private fun serializeRecentFiles(): String { /*@DONE EditorViewModel.SerializeRecentFiles/1 cs:1439-1442*/
        val content = recentFiles.joinToString(", ") { file -> "\"" + file + "\"" }
        return "RecentFiles = [" + content + "]"
    }
    private fun updateRecentFiles(filename: String) { /*@DONE EditorViewModel.UpdateRecentFiles/1 cs:1444-1452*/
        val index = recentFiles.indexOf(filename)
        if (index == 0) return
        if (index != -1) recentFiles.removeAt(index)
        recentFiles.add(0, filename)
        while (recentFiles.size > 5) recentFiles.removeAt(recentFiles.size - 1)

        populateRecentFilesViewModel()
    }
    private fun populateRecentFilesViewModel() { /*@DONE EditorViewModel.PopulateRecentFilesViewModel/1 cs:1454-1467*/
        recentFileViewModels.clear()
        for (file in recentFiles) {
            val closureFile = file
            val openRecent = StubCommand()
            openRecent.canExecute = { arg -> true }
            openRecent.execute = { arg ->
                val loadedFile = _fileSystem.loadFile(closureFile)
                this.open.execute(loadedFile)
            }
            recentFileViewModels.add(RecentFileViewModel(file, openRecent))
            notifyPropertyChanged("recentFileMenuEnabled")
        }
    }
    private fun tabChangeRequested(sender: Any?, args: TabChangeRequestedEventArgs) { /*@DONE EditorViewModel.TabChangeRequested/1 cs:1469-1480*/
        val newTab = args.newTab
        val isNewTabWithSameModel = !tabs.contains(newTab) && sender is ViewPort && newTab is ViewPort && sender.model === newTab.model
        if (sender !== selectedTab && !isNewTabWithSameModel) return
        args.requestAccepted = true
        // if (args.NewTab is ViewPort vp) vp.DistractionFreeMode = sender is MapEditorViewModel;
        val index = tabs.indexOf(newTab)
        if (index == -1) {
            add(newTab)
        } else {
            selectedIndex = index
        }
    }
    private fun adjustNotificationsFromCurrentTab(adjust: (ICommand, EventHandler) -> Unit) { /*@DONE EditorViewModel.AdjustNotificationsFromCurrentTab/1 cs:1482-1491*/
        if (_selectedIndex < 0 || _selectedIndex >= tabs.size) return
        val tab = tabs[_selectedIndex]
        for ((getCommand, notify) in forwardExecuteChangeNotifications) {
            val command = getCommand(tab)
            if (command != null) adjust(command, notify)
        }
    }
    private var withinNotListeningScope: Boolean = /*@INITAUTO EditorViewModel.withinNotListeningScope cs:1493-1493*/ false /*@ENDINIT*/
    private fun workWithoutListeningToCommandsFromCurrentTab(): IDisposable { /*@DONE EditorViewModel.WorkWithoutListeningToCommandsFromCurrentTab/1 cs:1494-1507*/
        if (withinNotListeningScope) return StubDisposable { }
        val add: (ICommand, EventHandler) -> Unit = { command, notify -> command.canExecuteChanged += notify }
        val remove: (ICommand, EventHandler) -> Unit = { command, notify -> command.canExecuteChanged -= notify }
        withinNotListeningScope = true
        adjustNotificationsFromCurrentTab(remove)
        return StubDisposable {
            commandsToRefreshOnTabChange.forEach { command -> command.canExecuteChanged(command, EventArgs.empty) }
            adjustNotificationsFromCurrentTab(add)
            withinNotListeningScope = false
        }
    }
    private fun raiseSaveAllCanExecuteChanged(sender: Any?, e: EventArgs) { /*@DONE EditorViewModel.RaiseSaveAllCanExecuteChanged/1 cs:1509-1509*/
        workDispatcher.blockOnUIWork { _saveAll.canExecuteChanged(this, e) }
    }
    private fun executeCopyAlignedAddress(fileSystem: IFileSystem) { /*@DONE EditorViewModel.ExecuteCopyAlignedAddress/1 cs:1511-1526*/
        val currentTab = selectedTab as? ViewPort
        if (currentTab == null) {
            errorMessage = "Selected tab must be a ViewPort."
            return
        }

        val addresses = ArrayList<String>()

        for (tab in tabs) {
            if (tab !is ViewPort) continue
            addresses.add(tab.convertViewPointToAddress(currentTab.selectionStart).toHex(6))
        }

        fileSystem.copyText = addresses.joinToString(", ")
        informationMessage = "Copied " + addresses.size + " addresses."
    }
    private fun executeCopyAnchorReference(fileSystem: IFileSystem) { /*@DONE EditorViewModel.ExecuteCopyAnchorReference/1 cs:1528-1551*/
        val viewport = selectedTab as? ViewPort
        if (viewport == null) {
            errorMessage = "Selected tab must be a ViewPort."
            return
        }

        val address = viewport.convertViewPointToAddress(viewport.selectionStart)
        val vpModel = viewport.model!!
        val run = vpModel.getNextRun(address)
        val anchor = vpModel.getAnchorFromAddress(-1, address)
        if (anchor.isNullOrEmpty() || (run?.pointerSources?.size ?: 0) == 0) {
            errorMessage = "Must select a named anchor with at least one pointer."
            return
        }

        val gameCode = vpModel.getGameCode()
        val addresses = singletons.gameReferenceTables.guessSources(gameCode, run!!.pointerSources!![0]).joinToString(", ")

        val content = StringBuilder()
        content.append("```").append("\n")
        content.append(anchor + ", " + addresses + ", " + run!!.formatString + " // " + gameCode).append("\n")
        content.append("```").append("\n")
        fileSystem.copyText = content.toString()
        informationMessage = "Copied " + anchor + " reference."
    }
    companion object {
        const val applicationName: String = "HexManiacAdvance"
        fun wrap(quickEdit: IQuickEditItem): ICommand { /*@DONE EditorViewModel.Wrap/1 cs:614-617*/
            val command = StubCommand()
            command.canExecute = { arg -> quickEdit.canRun(arg as IViewPort) }
            command.execute = { arg -> quickEdit.run(arg as IViewPort) }
            return command
        }
        private fun jumpTo(tab: IViewPort, start: Int, end: Int) { /*@DONE EditorViewModel.JumpTo/1 cs:838-843*/
            tab.goto?.execute(start.toHex(2))
            if (tab is ViewPort) {
                tab.selectionEnd = tab.convertAddressToViewPoint(end)
            }
        }
        fun getSHA1(viewPort: IEditableViewPort): String { /*@DONE EditorViewModel.GetSHA1/1 cs:911-915*/
            val sha = java.security.MessageDigest.getInstance("SHA-1")
            val hash = sha.digest(viewPort.model!!.rawData)
            val digits = "0123456789ABCDEF"
            val builder = StringBuilder()
            for (b in hash) {
                val v = b.toInt() and 0xFF
                builder.append(digits[v shr 4]).append(digits[v and 15])
            }
            return builder.toString()
        }
        fun getCRC32(viewPort: IEditableViewPort): String { /*@DONE EditorViewModel.GetCRC32/1 cs:917-920*/
            val crc = java.util.zip.CRC32()
            crc.update(viewPort.model!!.rawData)
            return crc.value.toString(16).uppercase().padStart(8, '0')
        }
        fun tryParseBytes(text: String, results: Ref<ByteArray?>): Boolean { /*@DONE EditorViewModel.TryParseBytes/1 cs:1075-1085*/
            results.value = null
            fun hexValue(c: Char): Int = when (c) {
                in '0'..'9' -> c - '0'
                in 'a'..'f' -> c - 'a' + 10
                in 'A'..'F' -> c - 'A' + 10
                else -> -1
            }
            val parsed = ArrayList<Byte>()
            for (token in text.split(' ').filter { it.isNotEmpty() }) {
                if (token.length != 2) return false
                val high = hexValue(token[0])
                val low = hexValue(token[1])
                if (high < 0 || low < 0) return false
                parsed.add(((high shl 4) or low).toByte())
            }
            results.value = parsed.toByteArray()
            return true
        }
        /*@END EditorViewModel.Companion*/
    }
    /*@ADD EditorViewModel#editor_a.txt*/
    private fun boolText(value: Boolean): String = if (value) "True" else "False"

    private fun parseDateTime(text: String): java.time.LocalDateTime? {
        val patterns = listOf("M/d/yyyy h:mm:ss a", "M/d/yyyy H:mm:ss", "M/d/yyyy h:mm a", "M/d/yyyy", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss", "yyyy-MM-dd")
        for (pattern in patterns) {
            try {
                val formatter = java.time.format.DateTimeFormatter.ofPattern(pattern, java.util.Locale.US)
                return if (pattern.contains("H") || pattern.contains("h")) {
                    java.time.LocalDateTime.parse(text, formatter)
                } else {
                    java.time.LocalDate.parse(text, formatter).atStartOfDay()
                }
            } catch (ex: Exception) {
                // try the next pattern
            }
        }
        return null
    }

    private fun formatDateTime(value: java.time.LocalDateTime): String =
        value.format(java.time.format.DateTimeFormatter.ofPattern("M/d/yyyy h:mm:ss a", java.util.Locale.US))

    private fun executePaste() {
        if (_gotoViewModel.controlVisible) return
        val tab = selectedTab
        if (tab is ImageEditorViewModel) {
            tab.paste.execute(fileSystem)
            return
        }

        var copyText = fileSystem.copyText ?: ""
        // if the paste is long, add whitespace to complete any pasted elements
        if (copyText.contains("\n") || copyText.contains(BaseRun.anchorStart)) {
            copyText += " "
            copyText = copyText.replace("\r\n", "\n") // normalize newline inputs
        }
        if (copyText.count { it == '"' } % 2 == 0 && copyText.length > 2 && !copyText.endsWith(' ')) {
            // In the case of 'paste' inputs with no open quotes, add a space
            // at the end to make it more likely to complete the last element.
            copyText += ' '
        }

        if (tab is ViewPort) tab.edit(copyText)
    }
    /*@ENDADD EditorViewModel#editor_a.txt*/
    /*@ADD EditorViewModel#editor_b.txt*/
    private val tabClosedHandler: (Any?, EventArgs) -> Unit = { s, e -> removeTab(s, e) }
    private val tabErrorHandler: (Any?, String) -> Unit = { s, m -> acceptError(s, m) }
    private val tabMessageHandler: (Any?, String) -> Unit = { s, m -> acceptMessage(s, m) }
    private val tabClearMessageHandler: (Any?, EventArgs) -> Unit = { s, e -> acceptMessageClear(s, e) }
    private val tabChangeRequestedHandler: (Any?, TabChangeRequestedEventArgs) -> Unit = { s, a -> tabChangeRequested(s, a) }
    private val tabDelayedWorkHandler: (Any?, () -> Unit) -> Unit = { s, w -> forwardDelayedWork(s, w) }
    private val tabCanDiffHandler: (Any?, CanDiffEventArgs) -> Unit = { s, a -> canDiffRequested(s, a) }
    private val tabDiffHandler: (Any?, Direction) -> Unit = { s, d -> diffRequested(s, d) }
    private val tabCanCreatePatchHandler: (Any?, CanPatchEventArgs) -> Unit = { s, a -> canCreatePatch(s, a) }
    private val tabCreatePatchHandler: (Any?, CanPatchEventArgs) -> Unit = { s, a -> createPatch(s, a) }
    private val tabPropertyChangedHandler: (Any?, PropertyChangedEventArgs) -> Unit = { s, a -> tabPropertyChanged(s, a) }
    private val tabRefreshGotoShortcutsHandler: (Any?, EventArgs) -> Unit = { s, e -> refreshGotoShortcuts(s, e) }
    private val tabSaveCanExecuteChangedHandler: (Any?, EventArgs) -> Unit = { s, e -> raiseSaveAllCanExecuteChanged(s, e) }
    private val tabCloseOtherViewportsHandler: (Any?, IDataModel) -> Unit = { s, m -> closeOtherViewports(s, m) }
    private val gotoPropertyChangedHandler: (Any?, PropertyChangedEventArgs) -> Unit = { s, a -> gotoPropertyChanged(s, a) }

    /** Second half of ExecuteOpen (the part after the C# `await`). */
    private fun continueOpen(file: LoadedFile) {
        try {
            val sel = selectedTab
            if (sel is IEditableViewPort) {
                val importSuccessful = sel.tryImport(file, _fileSystem)
                if (importSuccessful) return
            }
            updateRecentFiles(file.name)
            var metadataText: Array<String> = emptyArray()
            if (allowLoadingMetadata) {
                metadataText = _fileSystem.metadataFor(file.name) ?: emptyArray()
            }
            val metadata: StoredMetadata = try {
                StoredMetadata(metadataText)
            } catch (nullEx: ArgumentNullException) {
                errorMessage = nullEx.message
                return
            } catch (rangeEx: ArgumentOutOfRangeException) {
                errorMessage = rangeEx.message
                return
            }
            val model: IDataModel = if (file.name.lowercase().endsWith(".gba")) {
                HardcodeTablesModel(singletons, file.contents, metadata)
            } else {
                PokemonModel(file.contents, metadata, singletons)
            }
            val viewPort = ViewPort(file.name, model, workDispatcher, singletons, mapTutorials, fileSystem, pythonTool)
            if (metadata.isEmpty || StoredMetadata.needVersionUpdate(metadata.version, singletons.metadataInfo.versionNumber)) {
                viewPort.model?.initializationWorkload?.continueWith { task ->
                    val refTable = singletons.gameReferenceTables[model.getGameCode()]
                    _fileSystem.saveMetadata(file.name, viewPort.model?.exportMetadata(refTable, singletons.metadataInfo)?.serialize())
                    if (model is HardcodeTablesModel) viewPort.tools?.logTool?.logMessages?.addAll(model.loadingMessages)
                }
            }
            add(viewPort)
        } catch (ex: java.io.IOException) {
            errorMessage = ex.message
        }
    }
    /*@ENDADD EditorViewModel#editor_b.txt*/
    /*@END EditorViewModel*/
}

open class EditItemWrapper : QuickEditItemDecorator { // cs:1557-1564
    constructor(core: IQuickEditItem) { /*@DONE EditItemWrapper.<init>/1 cs:1558-1558*/
        innerQuickEditItem = core
    }
    override fun run(viewPort: IViewPort): Task<ErrorInfo>? { /*@DONE EditItemWrapper.Run/1 cs:1559-1563*/
        val result = super.run(viewPort)
        (viewPort.model as? PokemonModel)?.resolveConflicts()
        return result
    }
    /*@END EditItemWrapper*/
}

open class RecentFileViewModel : ViewModelCore { // cs:1566-1576
    var shortName: String = ""
        private set
    var longName: String = ""
        private set
    lateinit var open: ICommand
        private set
    constructor(filename: String, open: ICommand) { /*@DONE RecentFileViewModel.<init>/1 cs:1571-1575*/
        longName = filename
        shortName = Path.getFileNameWithoutExtension(filename) ?: ""
        this.open = open
    }
    /*@END RecentFileViewModel*/
}
