// Port of Models/Runs/TrainerPokemonTeamRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class TrainerPokemonTeamRun : BaseRun, IStreamRun, ITableRun, IUpdateFromParentRun { // cs:12-601
    private lateinit var model: IDataModel
    private var primarySource: Int = 0
    var structType: Int = 0
        private set
    override val canAppend: Boolean
        get() { /*@DONE TrainerPokemonTeamRun.CanAppend.get cs:34-34*/
            return elementCount < 6
        }
    override val repointContentShortName: String
        get() { /*@DONE TrainerPokemonTeamRun.RepointContentShortName.get cs:36-36*/
            return "Team"
        }
    private var showFullIVByteRange: Boolean = /*@INITAUTO TrainerPokemonTeamRun.showFullIVByteRange cs:38-38*/ false /*@ENDINIT*/
    private var minimumLevels: Any? = null
    constructor(model: IDataModel, start: Int, showFullIVByteRange: Boolean, sources: SortedSpan<Int>?) : super(start, sources) { /*@DONE TrainerPokemonTeamRun.<init>/1 cs:43-64*/
        this.model = model
        this.showFullIVByteRange = showFullIVByteRange

        // trainer format (abbreviated):
        //     0           1       2         3        4-15     16     18      20     22       24          28       32         36          40 total
        // [structType. class. introMusic. sprite. name\"\"12 item1: item2: item3: item4: doubleBattle:: ai:: pokemonCount:: pokemon<>]
        structType = 0
        elementCount = 1
        if (sources != null) {
            for (source in sources) {
                if (model.getNextRun(source) !is ITableRun) continue
                structType = model[source - trainerFormat_PointerOffset]
                elementCount = model.readMultiByteValue(source - trainerFormat_PointerOffset + trainerFormat_PokemonCountOffset, 4)
                primarySource = source
                break
            }
        }

        elementCount = minOf(elementCount, 1000)
        val segments = initialize()
        elementContent = segments
        elementLength = elementContent.sumOf { segment -> segment.length }
    }
    private constructor(model: IDataModel, start: Int, showFullIVByteRange: Boolean, sources: SortedSpan<Int>?, primarySource: Int) : super(start, sources) { /*@DONE TrainerPokemonTeamRun.<init>/2 cs:66-75*/
        this.model = model
        this.showFullIVByteRange = showFullIVByteRange
        this.primarySource = primarySource
        val parentStart = primarySource - trainerFormat_PointerOffset
        if (parentStart >= 0 && parentStart + trainerFormat_PokemonCountOffset + 4 <= model.count) {
            structType = model[parentStart]
            elementCount = minOf(model.readMultiByteValue(parentStart + trainerFormat_PokemonCountOffset, 4), 1000)
        } else {
            structType = 0
            elementCount = 1
        }
        val segments = initialize()
        elementContent = segments
        elementLength = elementContent.sumOf { segment -> segment.length }
    }
    private fun initialize(): List<ArrayRunElementSegment> { /*@DONE TrainerPokemonTeamRun.Initialize/1 cs:77-98*/
        val segments = ArrayList<ArrayRunElementSegment>()
        segments.add(ArrayRunElementSegment("ivSpread", ElementContentType.Integer, 2))
        segments.add(ArrayRunCalculatedSegment(model, "scaledIV", "ivSpread*.12156"))
        segments.add(ArrayRunElementSegment("level", ElementContentType.Integer, 2))
        segments.add(ArrayRunEnumSegment("mon", 2, HardcodeTablesModel.pokemonNameTable))
        if ((structType and include_ITEM) != 0) {
            segments.add(ArrayRunEnumSegment("item", 2, HardcodeTablesModel.itemsTableName))
        }
        if ((structType and include_MOVES) != 0) {
            segments.add(ArrayRunEnumSegment("move1", 2, HardcodeTablesModel.moveNamesTable))
            segments.add(ArrayRunEnumSegment("move2", 2, HardcodeTablesModel.moveNamesTable))
            segments.add(ArrayRunEnumSegment("move3", 2, HardcodeTablesModel.moveNamesTable))
            segments.add(ArrayRunEnumSegment("move4", 2, HardcodeTablesModel.moveNamesTable))
        }
        if ((structType and include_ITEM) == 0) {
            segments.add(ArrayRunElementSegment("padding", ElementContentType.Integer, 2))
        }

        return segments
    }
    fun search(parentArrayName: String, id: Int): Iterable<Int> { /*@DONE TrainerPokemonTeamRun.Search/1 cs:102-122*/
        val result = ArrayList<Int>()
        for (i in 0 until elementCount) {
            val elementStart = start + i * elementLength
            if (parentArrayName == HardcodeTablesModel.moveNamesTable && (structType and include_MOVES) != 0) {
                for (j in 0 until 4) {
                    var index = elementStart + pokemonFormat_MoveStart + j * 2
                    if ((structType and include_ITEM) != 0) index += 2
                    val moveID = model.readMultiByteValue(index, 2)
                    if (moveID == id) result.add(index)
                }
            } else if (parentArrayName == HardcodeTablesModel.pokemonNameTable) {
                val index = elementStart + pokemonFormat_PokemonStart
                val pokemonID = model.readMultiByteValue(index, 2)
                if (pokemonID == id) result.add(index)
            } else if (parentArrayName == HardcodeTablesModel.itemsTableName && (structType and include_ITEM) != 0) {
                val index = elementStart + pokemonFormat_ItemStart
                val itemID = model.readMultiByteValue(index, 2)
                if (itemID == id) result.add(index)
            }
        }
        return result
    }
    override val length: Int
        get() { /*@DONE TrainerPokemonTeamRun.Length.get cs:126-126*/
            return elementLength * elementCount
        }
    override val formatString: String
        get() { /*@DONE TrainerPokemonTeamRun.FormatString.get cs:128-128*/
            return sharedFormatString
        }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE TrainerPokemonTeamRun.CreateDataFormat/1 cs:130-130*/
        return this.createSegmentDataFormat(data, index)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE TrainerPokemonTeamRun.Clone/1 cs:132-132*/
        return TrainerPokemonTeamRun(model, start, showFullIVByteRange, newPointerSources, primarySource)
    }
    final override var elementCount: Int = 0
        private set
    final override var elementLength: Int = 0
        private set
    override val elementNames: List<String>? = /*@INITAUTO TrainerPokemonTeamRun.ElementNames cs:142-142*/ ArrayList() /*@ENDINIT*/
    final override var elementContent: List<ArrayRunElementSegment> = ArrayList()
        private set
    override fun append(token: ModelDelta, length: Int): ITableRun { /*@DONE TrainerPokemonTeamRun.Append/1 cs:146-174*/
        val totalLength = elementLength * (elementCount + length)
        var workingRun = this
        if (totalLength > workingRun.length) workingRun = model.relocateForExpansion(token, workingRun, totalLength)

        // delete old elements
        var removeIndex = -1
        while (removeIndex >= length) {
            val removeStart = workingRun.start + this.length + removeIndex * elementLength
            for (j in 0 until elementLength) token.changeData(model, removeStart + j, 0xFF)
            removeIndex--
        }

        // add new elements
        for (i in 0 until length) {
            val newStart = workingRun.start + this.length + i * elementLength
            for (j in 0 until elementLength) {
                if (elementCount > 0) {
                    val previousMemberValue = model[newStart + j - elementLength]
                    token.changeData(model, newStart + j, previousMemberValue)
                } else {
                    token.changeData(model, newStart + j, 0x00)
                }
            }
        }

        // update parent
        val parent = workingRun.pointerSources!![0] - trainerFormat_PointerOffset
        model.writeMultiByteValue(parent + trainerFormat_PokemonCountOffset, 4, token, elementCount + length)
        return TrainerPokemonTeamRun(model, workingRun.start, showFullIVByteRange, workingRun.pointerSources)
    }
    override fun duplicate(start: Int, pointerSources: SortedSpan<Int>?, segments: List<ArrayRunElementSegment>): ITableRun { /*@DONE TrainerPokemonTeamRun.Duplicate/1 cs:176-176*/
        return TrainerPokemonTeamRun(model, start, showFullIVByteRange, pointerSources)
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE TrainerPokemonTeamRun.AppendTo/1 cs:178-178*/
        ITableRunExtensions.appendTo(this, model, builder, start, length, depth)
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE TrainerPokemonTeamRun.Clear/1 cs:180-182*/
        ITableRunExtensions.clear(this, model, changeToken, start, length)
    }
    override fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, changedRuns: Ref<List<Int>?>): IStreamRun { /*@DONE TrainerPokemonTeamRun.DeserializeRun/1 cs:196-199*/
        changedRuns.value = ArrayList<Int>()
        return deserializeRun(content, token, false, false, changedOffsets)
    }
    fun deserializeRun(content: String, token: ModelDelta, setDefaultMoves: Boolean, setDefaultItems: Boolean, changedOffsets: Ref<List<Int>?>): TrainerPokemonTeamRun { /*@DONE TrainerPokemonTeamRun.DeserializeRun/2 cs:200-224*/
        val changedAddresses = LinkedHashSet<Int>()
        val lines = content.split(NEW_LINE).map { line -> line.trim() }.toTypedArray()

        // step 1: parse it into some data containers
        val data = TeamData(model, lines, showFullIVByteRange)
        if (setDefaultMoves) data.setDefaultMoves(this)
        if (setDefaultItems) data.setDefaultItems()

        // step 2: figure out what I need based on the data
        val newElementLength = if (data.movesIncluded) 16 else 8
        val totalLength = newElementLength * data.pokemon.size
        var workingRun = this
        if (totalLength > workingRun.length) workingRun = model.relocateForExpansion(token, workingRun, totalLength)

        // step 3: write the run data
        writeData(token, workingRun.start, data)

        // step 4: write the parent data
        val newStructType = (if (data.itemsIncluded) include_ITEM else 0) xor (if (data.movesIncluded) include_MOVES else 0)
        updateParents(token, newStructType, data.pokemon.size, workingRun.pointerSources ?: SortedSpan.none<Int>())

        changedOffsets.value = ArrayList<Int>(changedAddresses)
        return TrainerPokemonTeamRun(model, workingRun.start, showFullIVByteRange, workingRun.pointerSources)
    }
    private fun writeData(token: ModelDelta, runStart: Int, data: TeamData) { /*@DONE TrainerPokemonTeamRun.WriteData/1 cs:226-255*/
        val newElementLength = if (data.movesIncluded) 16 else 8
        for (i in 0 until data.pokemon.size) {
            var elementStart = runStart + newElementLength * i
            model.writeMultiByteValue(elementStart + 0, 2, token, data.iVs[i])
            model.writeMultiByteValue(elementStart + 2, 2, token, data.levels[i])
            model.writeMultiByteValue(elementStart + 4, 2, token, data.pokemon[i])
            elementStart += 6
            if (data.itemsIncluded) {
                model.writeMultiByteValue(elementStart, 2, token, data.items[i])
                elementStart += 2
            }
            if (data.movesIncluded) {
                for (j in 0 until 4) {
                    model.writeMultiByteValue(elementStart + j * 2, 2, token, data.moves[i * 4 + j])
                }
                elementStart += 8
            }

            // if there's no item, add 2 more bytes to get to the next multiple of 4.
            if (!data.itemsIncluded) {
                model.writeMultiByteValue(elementStart, 2, token, 0)
            }
        }

        // free space from the original run that's not needed by the new run
        for (i in newElementLength * data.pokemon.size until length) {
            token.changeData(model, runStart + i, 0xFF) // intentionally don't notify, these elements don't exist anymore.
        }
    }
    private fun updateParents(token: ModelDelta, structType: Int, pokemonCount: Int, pointerSources: List<Int>) { /*@DONE TrainerPokemonTeamRun.UpdateParents/1 cs:257-264*/
        for (source in pointerSources) {
            if (model.getNextRun(source) !is ITableRun) continue
            val parent = source - trainerFormat_PointerOffset
            if (model[parent + trainerFormat_StructTypeOffset] != structType) token.changeData(model, parent + trainerFormat_StructTypeOffset, structType and 0xFF)
            if (model[parent + trainerFormat_PokemonCountOffset] != pokemonCount) model.writeMultiByteValue(parent + trainerFormat_PokemonCountOffset, 4, token, pokemonCount)
        }
    }
    override fun serializeRun(): String? { /*@DONE TrainerPokemonTeamRun.SerializeRun/1 cs:266-302*/
        val cache = ModelCacheScope.getCache(model)
        val buffer = StringBuilder()
        for (i in 0 until elementCount) {
            var elementStart = start + elementLength * i
            var ivSpread = model.readMultiByteValue(elementStart + 0, 2)
            if (!showFullIVByteRange) ivSpread = Math.rint(ivSpread * iv_Cap / 255.0).toInt()
            val level = model.readMultiByteValue(elementStart + 2, 2)
            val pokeID = model.readMultiByteValue(elementStart + 4, 2)
            val pokemonNames = cache.getOptions(HardcodeTablesModel.pokemonNameTable)
            val pokemon = if (pokemonNames.size > pokeID) pokemonNames[pokeID] else pokeID.toString()
            elementStart += 6

            var item = ""
            if ((structType and include_ITEM) != 0) {
                val itemID = model.readMultiByteValue(elementStart, 2)
                val itemNames = cache.getOptions(HardcodeTablesModel.itemsTableName)
                item = if (itemNames.size > itemID) itemNames[itemID] else itemID.toString()
                item = "@" + item
                elementStart += 2
            }

            buffer.append(level.toString() + " " + pokemon + " (IVs=" + ivSpread + ")" + item + NEW_LINE)
            if ((structType and include_MOVES) != 0) {
                val moveNames = cache.getOptions(HardcodeTablesModel.moveNamesTable)
                for (j in 0 until 4) {
                    val moveID = model.readMultiByteValue(elementStart + j * 2, 2)
                    val move = if (moveNames.size > moveID) moveNames[moveID] else moveID.toString()
                    buffer.append("- " + move + NEW_LINE)
                }
            } else {
                buffer.append(NEW_LINE)
            }
            if (i + 1 < elementCount) buffer.append(NEW_LINE)
        }
        return buffer.toString()
    }
    override fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem> { /*@DONE TrainerPokemonTeamRun.GetAutoCompleteOptions/1 cs:304-309*/
        val result = ArrayList<AutocompleteItem>()
        if (line.trim().startsWith("-")) result.addAll(getAutocompleteMoveOptions(line, caretCharacterIndex))
        else result.addAll(getAutocompletePokemonOptions(line, caretCharacterIndex))
        return result
    }
    private fun getAutocompletePokemonOptions(line: String, caretIndex: Int): Iterable<AutocompleteItem> { /*@DONE TrainerPokemonTeamRun.GetAutocompletePokemonOptions/1 cs:311-352*/
        val result = ArrayList<AutocompleteItem>()
        val end = line.substring(caretIndex).trim()
        var startText = line.substring(0, caretIndex).trim()
        val spaceIndex = startText.indexOf(" ")
        val parenIndex = startText.indexOf("(")
        val endParenIndex = startText.indexOf(")")
        val atIndex = startText.indexOf("@")

        // level
        if (spaceIndex == -1) return result

        // pokemon
        if (parenIndex == -1 && atIndex == -1) {
            val level = startText.substring(0, spaceIndex)
            val pokemon = startText.substring(spaceIndex + 1)
            var ops: Iterable<String> = ArrayRunEnumSegment.getOptions(model, HardcodeTablesModel.pokemonNameTable)
                .filter { option -> option.matchesPartial(pokemon, onlyCheckLettersAndDigits = true) }
                .filter { option -> option.contains("-") || !pokemon.contains("-") }
                .filter { option -> option.contains("'") || !pokemon.contains("'") }
                .filter { option -> option.contains(".") || !pokemon.contains(".") }
            ops = ScriptParser.sortOptions(ops, pokemon) { op -> op }
            return ops.map { option -> AutocompleteItem(option, level + " " + option + " " + end) }
        }

        // IVs
        if (parenIndex >= 0 && endParenIndex == -1) return result

        // Item
        if (atIndex == -1) return result
        val item = startText.substring(atIndex + 1)
        startText = startText.substring(0, atIndex)
        val itemPrefix = startText.trim()
        val options = ArrayRunEnumSegment.getOptions(model, HardcodeTablesModel.itemsTableName).toList()
        var itemOps: Iterable<String> = options
            .filter { option -> option.matchesPartial(item, onlyCheckLettersAndDigits = true) }
            .filter { option -> option.contains("-") || !item.contains("-") }
            .filter { option -> option.contains("'") || !item.contains("'") }
        itemOps = ScriptParser.sortOptions(itemOps, item) { op -> op }
        return itemOps.map { option -> AutocompleteItem(option, itemPrefix + " @" + option) }
    }
    private fun getAutocompleteMoveOptions(line: String, caretIndex: Int): Iterable<AutocompleteItem> { /*@DONE TrainerPokemonTeamRun.GetAutocompleteMoveOptions/1 cs:354-361*/
        val namePart = line.split('-', limit = 2)[1].trim()
        if (namePart == "") return emptyList<AutocompleteItem>()
        return ArrayRunEnumSegment.getOptions(model, HardcodeTablesModel.moveNamesTable)
            .filter { option -> option.matchesPartial(namePart, onlyCheckLettersAndDigits = true) }
            .filter { option -> option.contains("-") || !namePart.contains("-") }
            .map { option -> AutocompleteItem(option, "- " + option) }
    }
    override val visualizations: List<IPixelViewModel>
        get() { /*@DONE TrainerPokemonTeamRun.Visualizations.get cs:364-378*/
            val list = ArrayList<IPixelViewModel>()
            val monOffset = elementContent.take(3).sumOf { seg -> seg.length }
            val monSeg = elementContent[3]
            val sprites = model.getTable(HardcodeTablesModel.frontSpritesTable) ?: return list
            for (i in 0 until elementCount) {
                val index = model.readMultiByteValue(start + elementLength * i + monOffset, monSeg.length)
                val spriteAddress = model.readPointer(sprites.start + sprites.elementLength * index)
                val sprite = model.getNextRun(spriteAddress) as? ISpriteRun ?: return ArrayList<IPixelViewModel>()
                val pixels = SpriteDecorator.buildSprite(model, sprite, useTransparency = true) ?: return ArrayList<IPixelViewModel>()
                list.add(pixels)
            }
            return list
        }
    override val preFormatter: ITextPreProcessor
        get() { /*@DONE TrainerPokemonTeamRun.PreFormatter.get cs:381-381*/
            return TrainerTextFormatter(model)
        }
    override fun dependsOn(anchorName: String): Boolean { /*@DONE TrainerPokemonTeamRun.DependsOn/1 cs:383-386*/
        return anchorName == HardcodeTablesModel.itemsTableName ||
            anchorName == HardcodeTablesModel.moveNamesTable ||
            anchorName == HardcodeTablesModel.pokemonNameTable
    }
    private open class TeamData { // cs:388-523
        private val _levels: MutableList<Int> = /*@INITAUTO TrainerPokemonTeamRun.TeamData.levels cs:389-389*/ ArrayList() /*@ENDINIT*/
        private val pokemons: MutableList<Int> = /*@INITAUTO TrainerPokemonTeamRun.TeamData.pokemons cs:390-390*/ ArrayList() /*@ENDINIT*/
        private val ivs: MutableList<Int> = /*@INITAUTO TrainerPokemonTeamRun.TeamData.ivs cs:391-391*/ ArrayList() /*@ENDINIT*/
        private val _items: MutableList<Int> = /*@INITAUTO TrainerPokemonTeamRun.TeamData.items cs:392-392*/ ArrayList() /*@ENDINIT*/
        private val _moves: MutableList<Int> = /*@INITAUTO TrainerPokemonTeamRun.TeamData.moves cs:393-393*/ ArrayList() /*@ENDINIT*/
        private lateinit var model: IDataModel
        private var showFullIVByteRange: Boolean = /*@INITAUTO TrainerPokemonTeamRun.TeamData.showFullIVByteRange cs:395-395*/ false /*@ENDINIT*/
        var itemsIncluded: Boolean = false
            private set
        var movesIncluded: Boolean = false
            private set
        val levels: List<Int>
            get() { /*@DONE TrainerPokemonTeamRun.TeamData.Levels.get cs:400-400*/
                return _levels
            }
        val pokemon: List<Int>
            get() { /*@DONE TrainerPokemonTeamRun.TeamData.Pokemon.get cs:401-401*/
                return pokemons
            }
        val iVs: List<Int>
            get() { /*@DONE TrainerPokemonTeamRun.TeamData.IVs.get cs:402-402*/
                return ivs
            }
        val items: List<Int>
            get() { /*@DONE TrainerPokemonTeamRun.TeamData.Items.get cs:403-403*/
                return _items
            }
        val moves: List<Int>
            get() { /*@DONE TrainerPokemonTeamRun.TeamData.Moves.get cs:404-404*/
                return _moves
            }
        constructor(model: IDataModel, lines: Array<String>, showFullIVByteRange: Boolean) { /*@DONE TrainerPokemonTeamRun.TeamData.<init>/1 cs:406-454*/
            this.model = model
            this.showFullIVByteRange = showFullIVByteRange
            var currentPokemonMoveCount = 0
            val moveNames = model.getOptions(HardcodeTablesModel.moveNamesTable)
            val itemNames = model.getOptions(HardcodeTablesModel.itemsTableName)
            val pokemonNames = model.getOptions(HardcodeTablesModel.pokemonNameTable)

            for (line in lines) {
                if (line.trim() == "") continue
                if (line.trim().startsWith("-")) {
                    if (pokemons.size == 0) continue
                    if (currentPokemonMoveCount > 3) continue
                    movesIncluded = true
                    val move = line.trim().substring(1).trim(' ', '"')
                    var moveIndex = moveNames.indexOfPartial(move)
                    if (moveIndex < 0) moveIndex = 0
                    _moves[(pokemons.size - 1) * 4 + currentPokemonMoveCount] = moveIndex
                    currentPokemonMoveCount++
                } else {
                    if (pokemons.size == 6) continue

                    val levelTokenized = line.split(' ', limit = 2)
                    if (levelTokenized.size != 2) continue
                    val levelValue = Ref(0)
                    if (!tryParseInt(levelTokenized[0], levelValue)) continue
                    _levels.add(levelValue.value)

                    val itemTokenized = levelTokenized[1].split('@', limit = 2).toTypedArray()
                    addItem(itemNames, _items, itemTokenized)

                    val ivTokenized = itemTokenized[0].split('(', limit = 2).toTypedArray()
                    addIV(ivs, ivTokenized)

                    val pokemon = ivTokenized[0].trim()
                    var pokemonIndex = pokemonNames.indexOfPartial(pokemon)
                    if (pokemonIndex < 0) pokemonIndex = 0
                    pokemons.add(pokemonIndex)
                    _moves.addAll(listOf(0, 0, 0, 0))
                    currentPokemonMoveCount = 0
                }
            }

            if (pokemons.size == 0) {
                pokemons.add(0)
                ivs.add(0)
                _levels.add(0)
                _moves.addAll(listOf(0, 0, 0, 0))
            }
        }
        constructor(model: IDataModel, start: Int, structType: Int, count: Int) { /*@DONE TrainerPokemonTeamRun.TeamData.<init>/2 cs:456-477*/
            this.model = model
            itemsIncluded = (include_ITEM and structType) != 0
            movesIncluded = (include_MOVES and structType) != 0
            var elementStart = start
            for (i in 0 until count) {
                ivs.add(model.readMultiByteValue(elementStart + 0, 2))
                _levels.add(model.readMultiByteValue(elementStart + 2, 2))
                pokemons.add(model.readMultiByteValue(elementStart + 4, 2))
                elementStart += 6
                if (itemsIncluded) {
                    _items.add(model.readMultiByteValue(elementStart, 2))
                    elementStart += 2
                }
                if (movesIncluded) {
                    for (j in 0 until 4) _moves.add(model.readMultiByteValue(elementStart + j * 2, 2))
                    elementStart += 8
                } else {
                    _moves.addAll(listOf(0, 0, 0, 0))
                }
                if (!itemsIncluded) elementStart += 2
            }
        }
        fun setDefaultMoves(parent: TrainerPokemonTeamRun) { /*@DONE TrainerPokemonTeamRun.TeamData.SetDefaultMoves/1 cs:479-485*/
            movesIncluded = true
            _moves.clear()
            for (i in 0 until pokemons.size) {
                _moves.addAll(parent.getDefaultMoves(pokemons[i], _levels[i]))
            }
        }
        fun removeMoves() { /*@DONE TrainerPokemonTeamRun.TeamData.RemoveMoves/1 cs:487-487*/
            movesIncluded = false
        }
        fun setDefaultItems() { /*@DONE TrainerPokemonTeamRun.TeamData.SetDefaultItems/1 cs:489-494*/
            itemsIncluded = true
            _items.clear()
            val pokemonTable = model.getTable(HardcodeTablesModel.pokemonStatsTable)
            _items.addAll(pokemons.map { p -> pokemonTable?.readValue(model, p, "item1") ?: 0 })
        }
        fun removeItems() { /*@DONE TrainerPokemonTeamRun.TeamData.RemoveItems/1 cs:496-496*/
            itemsIncluded = false
        }
        private fun addIV(ivs: MutableList<Int>, ivTokenized: Array<String>) { /*@DONE TrainerPokemonTeamRun.TeamData.AddIV/1 cs:498-511*/
            if (ivTokenized.size == 2) {
                ivTokenized[1] = ivTokenized[1].replace(")", "").trim()
                ivTokenized[1] = ivTokenized[1].split('=').last()
                val parsedIV = Ref(0)
                if (tryParseInt(ivTokenized[1], parsedIV)) {
                    var fixedIV = parsedIV.value
                    if (!showFullIVByteRange) fixedIV = Math.rint(fixedIV * 255.0 / iv_Cap).toInt()
                    ivs.add(fixedIV)
                } else {
                    ivs.add(0)
                }
            } else {
                ivs.add(0)
            }
        }
        private fun addItem(itemNames: List<String>, items: MutableList<Int>, itemTokenized: Array<String>) { /*@DONE TrainerPokemonTeamRun.TeamData.AddItem/1 cs:513-522*/
            if (itemTokenized.size == 2) {
                itemsIncluded = true
                var itemIndex = itemNames.indexOfPartial(itemTokenized[1])
                if (itemIndex < 0) itemIndex = 0
                items.add(itemIndex)
            } else {
                items.add(0)
            }
        }
        /*@END TrainerPokemonTeamRun.TeamData*/
    }
    // skipped method UpdateFromParent: explicit implementation merged with the public member
    override fun updateFromParent(token: ModelDelta, parentSegmentChange: Int, pointerSource: Int): TrainerPokemonTeamRun? { /*@DONE TrainerPokemonTeamRun.UpdateFromParent/2 cs:528-568*/
        // we only care if the change was to the parent's structType or pokemonCount.
        val sourceTable = model.getNextRun(pointerSource) as? ITableRun ?: return this
        if (sourceTable.elementContent.size <= parentSegmentChange) return this
        if (parentSegmentChange != 0 && sourceTable.elementContent[parentSegmentChange].name != "pokemonCount") return this

        val newStructType = model[pointerSource - trainerFormat_PointerOffset]
        var newElementCount = model.readMultiByteValue(pointerSource - trainerFormat_PointerOffset + trainerFormat_PokemonCountOffset, 4)
        newElementCount = newElementCount.limitToRange(0, 100)

        var newRun = this
        if (newElementCount == 0) {
            val offsets = sourceTable.convertByteOffsetToArrayOffset(pointerSource)
            model.clearFormatAndData(token, newRun.start, newRun.length)
            model.updateArrayPointer(token, sourceTable.elementContent[offsets.segmentIndex], sourceTable.elementContent, offsets.elementIndex, pointerSource, Pointer.null_)
            return null
        }
        if (newElementCount != elementCount) newRun = newRun.append(token, newElementCount - elementCount) as TrainerPokemonTeamRun
        if (newStructType != structType) {
            val data = TeamData(model, newRun.start, structType, newElementCount)
            if ((newStructType and include_MOVES) != 0 && !data.movesIncluded) {
                data.setDefaultMoves(this)
                newRun = model.relocateForExpansion(token, newRun, newRun.length * 2)
            } else if ((newStructType and include_MOVES) == 0 && data.movesIncluded) {
                data.removeMoves()
            }
            if ((newStructType and include_ITEM) != 0 && !data.itemsIncluded) {
                data.setDefaultItems()
            } else if ((newStructType and include_ITEM) == 0 && data.itemsIncluded) {
                data.removeItems()
            }
            writeData(token, newRun.start, data)
        }
        if (newElementCount != elementCount || newStructType != structType) {
            updateParents(token, newStructType, newElementCount, newRun.pointerSources ?: SortedSpan.none<Int>())
        }

        return TrainerPokemonTeamRun(model, newRun.start, showFullIVByteRange, pointerSources, pointerSource)
    }
    private fun getDefaultMoves(pokemon: Int, currentLevel: Int): List<Int> { /*@DONE TrainerPokemonTeamRun.GetDefaultMoves/1 cs:573-600*/
        val results = ArrayList<Int>()
        val levelMovesAddress = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.levelMovesTableName)
        val lvlMoves = model.getNextRun(levelMovesAddress) as? ArrayRun
        if (lvlMoves != null) {
            val movesStart = model.readPointer(lvlMoves.start + lvlMoves.elementLength * pokemon)
            val run = model.getNextRun(movesStart)
            if (run is ITableRun) {
                for (i in 0 until run.elementCount) {
                    var level = 0
                    var move = 0
                    if (run.elementContent.size == 1) {
                        val pair = model.readMultiByteValue(run.start + i * run.elementLength, run.elementLength)
                        val split = PLMRun.splitToken(pair)
                        level = split.level
                        move = split.move
                    } else if (run.elementContent.size == 2) {
                        move = model.readMultiByteValue(run.start + i * run.elementLength, run.elementContent[0].length)
                        level = model.readMultiByteValue(run.start + i * run.elementLength + run.elementContent[0].length, run.elementContent[1].length)
                    } else {
                        level = Int.MAX_VALUE
                    }

                    if (currentLevel >= level) results.add(move)
                    else break
                }
            }
        }
        while (results.size > 4) results.removeAt(0) // restrict to the last 4 moves
        while (results.size < 4) results.add(0)      // pad with extra '0' moves if needed
        return results
    }
    companion object {
        const val iv_Cap: Int = 31
        const val trainerFormat_StructTypeOffset: Int = 0
        const val trainerFormat_PokemonCountOffset: Int = 32
        const val trainerFormat_PointerOffset: Int = 36
        const val trainerFormat_Width: Int = 40
        const val include_MOVES: Int = 1
        const val include_ITEM: Int = 2
        const val pokemonFormat_FixedIVStart: Int = 0
        const val pokemonFormat_LevelStart: Int = 2
        const val pokemonFormat_PokemonStart: Int = 4
        const val pokemonFormat_ItemStart: Int = 6
        const val pokemonFormat_MoveStart: Int = 6
        val sharedFormatString: String = /*@INITDONE TrainerPokemonTeamRun.SharedFormatString cs:27-27*/ AsciiRun.streamDelimeter.toString() + "tpt" + AsciiRun.streamDelimeter /*@ENDINIT*/
        /*@END TrainerPokemonTeamRun.Companion*/
    }
    /*@END TrainerPokemonTeamRun*/
}

data class TrainerTextFormatter(val model: IDataModel?) : ITextPreProcessor { // cs:603-667
    override fun format(content: String): Array<TextFormatting> { /*@DONE TrainerTextFormatter.Format/1 cs:604-604*/
        return emptyArray<TextFormatting>()
    }
    override fun findErrors(content: String): Iterable<TextSegment> { /*@DONE TrainerTextFormatter.FindErrors/1 cs:606-619*/
        val errors = ArrayList<TextSegment>()
        var species = 0
        val lines = content.splitLines()
        for (i in 0 until lines.size) {
            if (lines[i].isBlank()) continue
            if (lines[i].trim().startsWith("-")) {
                checkMoveError(species, i, lines[i], errors)
            } else {
                species = checkPokemonError(i, lines[i], errors)
            }
        }
        return errors
    }
    private fun checkPokemonError(lineNumber: Int, line: String, errors: MutableList<TextSegment>): Int { /*@DONE TrainerTextFormatter.CheckPokemonError/1 cs:621-644*/
        val tokens = line.split(' ').filter { s -> s.length > 0 }.toMutableList()
        tokens.combineTokens("\"", "\"")
        if (tokens.size < 2) return 0
        val levelValue = Ref(0)
        if (!tryParseInt(tokens[0], levelValue)) return 0
        val level = levelValue.value
        val cache = ModelCacheScope.getCache(model!!)
        val pokemonNames = cache.getOptions(HardcodeTablesModel.pokemonNameTable)
        val pokemonValue = Ref(0)
        if (!pokemonNames.tryMatch(tokens[1], pokemonValue)) return 0
        val pokemon = pokemonValue.value

        // error: pokemon is too low of a level
        val minimumLevels = cache.getPokemonMinimumLevels()
        val minLevel = minimumLevels[pokemon]
        if (minLevel != null && minLevel > level) {
            errors.add(TextSegment(lineNumber, line.indexOf(tokens[1]), tokens[1].length, SegmentType.Warning))
        } else {
            val baby = cache.getPokemonDevolutions()[pokemon]
            if (baby != null) {
                // check that the lower evolution is also allowed. Important for stage 3 pokmeon that evolve via stone
                val babyLevel = minimumLevels[baby]
                if (babyLevel != null && babyLevel > level) {
                    errors.add(TextSegment(lineNumber, line.indexOf(tokens[1]), tokens[1].length, SegmentType.Warning))
                }
            }
        }

        return pokemon
    }
    private fun checkMoveError(species: Int, lineNumber: Int, line: String, errors: MutableList<TextSegment>) { /*@DONE TrainerTextFormatter.CheckMoveError/1 cs:646-666*/
        val cache = ModelCacheScope.getCache(model!!)
        val moveNames = cache.getOptions(HardcodeTablesModel.moveNamesTable)
        val moveValue = Ref(0)
        if (!moveNames.tryMatch(line, moveValue)) return
        val move = moveValue.value

        val allMoves = LinkedHashSet<Int>()
        var currentSpecies = species
        for (i in 0 until 5) {
            cache.getLevelupMoves()[currentSpecies]?.let { moves -> allMoves.addAll(moves) }
            cache.getTutorMoves()[currentSpecies]?.let { moves -> allMoves.addAll(moves) }
            cache.getPokemonEggMoves()[currentSpecies]?.let { moves -> allMoves.addAll(moves) }
            cache.getTmMoves()[currentSpecies]?.let { moves -> allMoves.addAll(moves) }
            val baby = cache.getPokemonDevolutions()[currentSpecies] ?: break
            currentSpecies = baby
        }

        // error: pokemon cannot learn move
        if (!allMoves.contains(move) && line.length > 2) {
            errors.add(TextSegment(lineNumber, 2, line.length - 2, SegmentType.Warning))
        }
    }
    /*@END TrainerTextFormatter*/
}
