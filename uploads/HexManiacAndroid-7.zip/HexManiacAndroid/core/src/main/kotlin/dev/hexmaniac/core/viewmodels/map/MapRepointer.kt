// Port of ViewModels/Map/MapRepointer.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*

data class ChangeMapEventArgs(val bank: Int, val map: Int) { // cs:14-14
    /*@END ChangeMapEventArgs*/
}

data class DataMovedEventArgs(val type: String, val address: Int) { // cs:15-15
    /*@END DataMovedEventArgs*/
}

open class MapRepointer : ViewModelCore { // cs:17-990
    private lateinit var format: Format
    private lateinit var fileSystem: IFileSystem
    private lateinit var viewPort: IEditableViewPort
    private lateinit var model: IDataModel
    private lateinit var history: ChangeHistory<ModelDelta>
    private var mapID: Int = 0
    private var refreshHeader: (() -> Unit)? = null
    private var _repointLayout: StubCommand? = null
    private var _repointBorderBlock: StubCommand? = null
    private var _repointBlockMap: StubCommand? = null
    private var _repointPrimaryBlockset: StubCommand? = null
    private var _repointSecondaryBlockset: StubCommand? = null
    private var _repointPrimaryTileset: StubCommand? = null
    private var _repointSecondaryTileset: StubCommand? = null
    private var _expandPrimaryTileset: StubCommand? = null
    private var _expandSecondaryTileset: StubCommand? = null
    private var _repointPrimaryBlocks: StubCommand? = null
    private var _repointSecondaryBlocks: StubCommand? = null
    private var _expandPrimaryBlocks: StubCommand? = null
    private var _expandSecondaryBlocks: StubCommand? = null
    private var _repointPrimaryPalette: StubCommand? = null
    private var _repointSecondaryPalette: StubCommand? = null
    private var _expandPrimaryPalette: StubCommand? = null
    private var _expandSecondaryPalette: StubCommand? = null
    private var _createPrimaryTilesetAnimations: StubCommand? = null
    private var _createSecondaryTilesetAnimations: StubCommand? = null
    private var _duplicateMap: StubCommand? = null
    val repointLayout: ICommand
        get() { /*@DONE MapRepointer.RepointLayout.get cs:56-56*/
            return _repointLayout ?: stubCommand({ executeRepointLayout() }, { canRepointLayout() }).also { _repointLayout = it }
        }
    val repointBorderBlock: ICommand
        get() { /*@DONE MapRepointer.RepointBorderBlock.get cs:57-57*/
            return _repointBorderBlock ?: stubCommand({ executeRepointBorderBlock() }, { canRepointBorderBlock() }).also { _repointBorderBlock = it }
        }
    val repointBlockMap: ICommand
        get() { /*@DONE MapRepointer.RepointBlockMap.get cs:58-58*/
            return _repointBlockMap ?: stubCommand({ executeRepointBlockMap() }, { canRepointBlockMap() }).also { _repointBlockMap = it }
        }
    val repointPrimaryBlockset: ICommand
        get() { /*@DONE MapRepointer.RepointPrimaryBlockset.get cs:59-59*/
            return _repointPrimaryBlockset ?: stubCommand({ executeRepointPrimaryBlockset() }, { canRepointPrimaryBlockset() }).also { _repointPrimaryBlockset = it }
        }
    val repointSecondaryBlockset: ICommand
        get() { /*@DONE MapRepointer.RepointSecondaryBlockset.get cs:60-60*/
            return _repointSecondaryBlockset ?: stubCommand({ executeRepointSecondaryBlockset() }, { canRepointSecondaryBlockset() }).also { _repointSecondaryBlockset = it }
        }
    val repointPrimaryTileset: ICommand
        get() { /*@DONE MapRepointer.RepointPrimaryTileset.get cs:61-61*/
            return _repointPrimaryTileset ?: stubCommand({ executeRepointPrimaryTileset() }, { canRepointPrimaryTileset() }).also { _repointPrimaryTileset = it }
        }
    val repointSecondaryTileset: ICommand
        get() { /*@DONE MapRepointer.RepointSecondaryTileset.get cs:62-62*/
            return _repointSecondaryTileset ?: stubCommand({ executeRepointSecondaryTileset() }, { canRepointSecondaryTileset() }).also { _repointSecondaryTileset = it }
        }
    val expandPrimaryTileset: ICommand
        get() { /*@DONE MapRepointer.ExpandPrimaryTileset.get cs:63-63*/
            return _expandPrimaryTileset ?: stubCommand({ executeExpandPrimaryTileset() }, { canExpandPrimaryTileset() }).also { _expandPrimaryTileset = it }
        }
    val expandSecondaryTileset: ICommand
        get() { /*@DONE MapRepointer.ExpandSecondaryTileset.get cs:64-64*/
            return _expandSecondaryTileset ?: stubCommand({ executeExpandSecondaryTileset() }, { canExpandSecondaryTileset() }).also { _expandSecondaryTileset = it }
        }
    val repointPrimaryBlocks: ICommand
        get() { /*@DONE MapRepointer.RepointPrimaryBlocks.get cs:65-65*/
            return _repointPrimaryBlocks ?: stubCommand({ executeRepointPrimaryBlocks() }, { canRepointPrimaryBlocks() }).also { _repointPrimaryBlocks = it }
        }
    val repointSecondaryBlocks: ICommand
        get() { /*@DONE MapRepointer.RepointSecondaryBlocks.get cs:66-66*/
            return _repointSecondaryBlocks ?: stubCommand({ executeRepointSecondaryBlocks() }, { canRepointSecondaryBlocks() }).also { _repointSecondaryBlocks = it }
        }
    val expandPrimaryBlocks: ICommand
        get() { /*@DONE MapRepointer.ExpandPrimaryBlocks.get cs:67-67*/
            return _expandPrimaryBlocks ?: stubCommand({ executeExpandPrimaryBlocks() }, { canExpandPrimaryBlocks() }).also { _expandPrimaryBlocks = it }
        }
    val expandSecondaryBlocks: ICommand
        get() { /*@DONE MapRepointer.ExpandSecondaryBlocks.get cs:68-68*/
            return _expandSecondaryBlocks ?: stubCommand({ executeExpandSecondaryBlocks() }, { canExpandSecondaryBlocks() }).also { _expandSecondaryBlocks = it }
        }
    val repointPrimaryPalette: ICommand
        get() { /*@DONE MapRepointer.RepointPrimaryPalette.get cs:69-69*/
            return _repointPrimaryPalette ?: stubCommand({ executeRepointPrimaryPalette() }, { canRepointPrimaryPalette() }).also { _repointPrimaryPalette = it }
        }
    val repointSecondaryPalette: ICommand
        get() { /*@DONE MapRepointer.RepointSecondaryPalette.get cs:70-70*/
            return _repointSecondaryPalette ?: stubCommand({ executeRepointSecondaryPalette() }, { canRepointSecondaryPalette() }).also { _repointSecondaryPalette = it }
        }
    val expandPrimaryPalette: ICommand
        get() { /*@DONE MapRepointer.ExpandPrimaryPalette.get cs:71-71*/
            return _expandPrimaryPalette ?: stubCommand({ executeExpandPrimaryPalette() }, { canExpandPrimaryPalette() }).also { _expandPrimaryPalette = it }
        }
    val expandSecondaryPalette: ICommand
        get() { /*@DONE MapRepointer.ExpandSecondaryPalette.get cs:72-72*/
            return _expandSecondaryPalette ?: stubCommand({ executeExpandSecondaryPalette() }, { canExpandSecondaryPalette() }).also { _expandSecondaryPalette = it }
        }
    val createPrimaryTilesetAnimations: ICommand
        get() { /*@DONE MapRepointer.CreatePrimaryTilesetAnimations.get cs:73-73*/
            return _createPrimaryTilesetAnimations ?: stubCommand({ executeCreatePrimaryTilesetAnimations() }, { canCreatePrimaryTilesetAnimations() }).also { _createPrimaryTilesetAnimations = it }
        }
    val createSecondaryTilesetAnimations: ICommand
        get() { /*@DONE MapRepointer.CreateSecondaryTilesetAnimations.get cs:74-74*/
            return _createSecondaryTilesetAnimations ?: stubCommand({ executeCreateSecondaryTilesetAnimations() }, { canCreateSecondaryTilesetAnimations() }).also { _createSecondaryTilesetAnimations = it }
        }
    val duplicateMap: ICommand
        get() { /*@DONE MapRepointer.DuplicateMap.get cs:75-75*/
            return _duplicateMap ?: stubCommand({ executeDuplicateMap() }, { canDuplicateMap() }).also { _duplicateMap = it }
        }
    val dataMoved = Event<DataMovedEventArgs?>()
    val changeMap = Event<ChangeMapEventArgs>()
    constructor(format: Format, fileSystem: IFileSystem, viewPort: IEditableViewPort, history: ChangeHistory<ModelDelta>, mapID: Int, refreshHeader: () -> Unit) { /*@DONE MapRepointer.<init>/1 cs:82-90*/
        this.format = format
        this.fileSystem = fileSystem
        this.viewPort = viewPort
        this.model = viewPort.model!!
        this.history = history
        this.mapID = mapID
        this.refreshHeader = refreshHeader
    }
    fun refresh() { /*@DONE MapRepointer.Refresh/1 cs:92-117*/
        for (command in listOf(
            _repointLayout,
            _repointBorderBlock,
            _repointBlockMap,
            _repointPrimaryBlockset,
            _repointSecondaryBlockset,
            _repointPrimaryTileset,
            _repointSecondaryTileset,
            _expandPrimaryTileset,
            _expandSecondaryTileset,
            _repointPrimaryBlocks,
            _repointSecondaryBlocks,
            _expandPrimaryBlocks,
            _expandSecondaryBlocks,
            _repointPrimaryPalette,
            _repointSecondaryPalette,
            _expandPrimaryPalette,
            _expandSecondaryPalette,
            _createPrimaryTilesetAnimations,
            _createSecondaryTilesetAnimations,
            _duplicateMap
        )) {
            command?.raiseCanExecuteChanged()
        }
    }
    val repointLayoutText: String
        get() { /*@DONE MapRepointer.RepointLayoutText.get cs:122-130*/
            val map = getMapModel() ?: return ""
            val layoutStart = map.getAddress(Format.layout)
            if (layoutStart < 0 || layoutStart >= model.count) return ""
            val layoutRun = model.getNextRun(layoutStart)
            val sources = layoutRun?.pointerSources ?: return ""
            return "This layout is used by ${sources.size - 1} maps."
        }
    private fun canRepointLayout(): Boolean { /*@DONE MapRepointer.CanRepointLayout/1 cs:134-145*/
        val map = getMapModel() ?: return false

        val layoutTable = model.getTable(HardcodeTablesModel.mapLayoutTable)
        if (layoutTable == null) return false // repointing a layout without a layout table isn't safe

        val layoutStart = map.getAddress(Format.layout)
        if (layoutStart < 0 || layoutStart >= model.count) return false
        val layoutRun = model.getNextRun(layoutStart)
        val sources = layoutRun?.pointerSources
        return sources != null && sources.size > 2
    }
    private fun executeRepointLayout() { /*@DONE MapRepointer.ExecuteRepointLayout/1 cs:147-161*/
        val map = getMapModel() ?: return
        val layoutStart = map.getAddress(Format.layout)
        val layoutRun = model.getNextRun(layoutStart) ?: return
        val newDataStart = duplicateData(layoutRun.start, layoutRun.length)
        map.setAddress(Format.layout, newDataStart)
        dataMoved(this, DataMovedEventArgs("Layout", newDataStart))
        _repointLayout?.raiseCanExecuteChanged()
        _repointBorderBlock?.raiseCanExecuteChanged()
        _repointBlockMap?.raiseCanExecuteChanged()
        _repointPrimaryBlockset?.raiseCanExecuteChanged()
        _repointSecondaryBlockset?.raiseCanExecuteChanged()
        refreshHeader?.invoke()
        // TODO we just made a new layout, we need to add it to the layout table
    }
    val repointBorderText: String
        get() { /*@DONE MapRepointer.RepointBorderText.get cs:164-167*/
            val count = countLayoutMemberSources(Format.borderBlock)
            return "This border is used by $count layout${if (count != 1) "s" else ""}."
        }
    private fun canRepointBorderBlock(): Boolean { /*@DONE MapRepointer.CanRepointBorderBlock/1 cs:170-170*/
        return countLayoutMemberSources(Format.borderBlock) > 1
    }
    private fun executeRepointBorderBlock() { /*@DONE MapRepointer.ExecuteRepointBorderBlock/1 cs:172-179*/
        val layout = getLayout() ?: return
        val count = borderBlockCount(layout)
        executeRepointLayoutMember(Format.borderBlock, count * 2, _repointBorderBlock)
    }
    fun importBorderBlock() { /*@DONE MapRepointer.ImportBorderBlock/1 cs:181-189*/
        val layout = getLayout() ?: return
        val count = borderBlockCount(layout)

        if (importBytes(layout.getAddress(Format.borderBlock), count * 2, -1)) dataMoved(this, null)
    }
    fun exportBorderBlock() { /*@DONE MapRepointer.ExportBorderBlock/1 cs:191-199*/
        val layout = getLayout() ?: return
        val count = borderBlockCount(layout)

        exportBytes(layout.getAddress(Format.borderBlock), count * 2)
    }
    val repointBlockMapText: String
        get() { /*@DONE MapRepointer.RepointBlockMapText.get cs:201-201*/
            return "This Blockmap is used by ${countLayoutMemberSources(Format.blockMap)} layouts."
        }
    private fun canRepointBlockMap(): Boolean { /*@DONE MapRepointer.CanRepointBlockMap/1 cs:203-203*/
        return countLayoutMemberSources(Format.blockMap) > 1
    }
    private fun executeRepointBlockMap() { /*@DONE MapRepointer.ExecuteRepointBlockMap/1 cs:205-209*/
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        executeRepointLayoutMember(Format.blockMap, width * height * 2, _repointBlockMap)
    }
    fun importBlockMap() { /*@DONE MapRepointer.ImportBlockMap/1 cs:211-218*/
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val size = width * height * 2
        val address = layout.getAddress(Format.blockMap)

        if (importBytes(address, size, -1)) dataMoved(this, null)
    }
    fun exportBlockMap() { /*@DONE MapRepointer.ExportBlockMap/1 cs:220-227*/
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val size = width * height * 2
        val address = layout.getAddress(Format.blockMap)

        exportBytes(address, size)
    }
    val repointPrimaryBlocksetText: String
        get() { /*@DONE MapRepointer.RepointPrimaryBlocksetText.get cs:229-229*/
            return "This primary blockset is used by ${countLayoutMemberSources(Format.primaryBlockset)} layouts."
        }
    private fun canRepointPrimaryBlockset(): Boolean { /*@DONE MapRepointer.CanRepointPrimaryBlockset/1 cs:231-231*/
        return countLayoutMemberSources(Format.primaryBlockset) > 1
    }
    private fun executeRepointPrimaryBlockset() { /*@DONE MapRepointer.ExecuteRepointPrimaryBlockset/1 cs:233-239*/
        executeRepointLayoutMember(Format.primaryBlockset, 6 * 4,
            _repointPrimaryBlockset, _repointPrimaryBlocks,
            _repointPrimaryTileset, _repointPrimaryPalette,
            _expandPrimaryBlocks, _expandPrimaryTileset,
            _expandPrimaryPalette, _createPrimaryTilesetAnimations)
    }
    val repointSecondaryBlocksetText: String
        get() { /*@DONE MapRepointer.RepointSecondaryBlocksetText.get cs:241-241*/
            return "This secondary blockset is used by ${countLayoutMemberSources(Format.secondaryBlockset)} layouts."
        }
    private fun canRepointSecondaryBlockset(): Boolean { /*@DONE MapRepointer.CanRepointSecondaryBlockset/1 cs:243-243*/
        return countLayoutMemberSources(Format.secondaryBlockset) > 1
    }
    private fun executeRepointSecondaryBlockset() { /*@DONE MapRepointer.ExecuteRepointSecondaryBlockset/1 cs:245-251*/
        executeRepointLayoutMember(Format.secondaryBlockset, 6 * 4,
            _repointSecondaryBlockset, _repointSecondaryBlocks,
            _repointSecondaryTileset, _repointSecondaryPalette,
            _expandSecondaryBlocks, _expandSecondaryTileset,
            _expandSecondaryPalette, _createSecondaryTilesetAnimations)
    }
    val duplicateMapText: String
        get() { /*@DONE MapRepointer.DuplicateMapText.get cs:253-253*/
            return "Create a new map with no connections or events, but the same layout."
        }
    private fun canDuplicateMap(): Boolean { /*@DONE MapRepointer.CanDuplicateMap/1 cs:255-257*/
        return true
    }
    private fun executeDuplicateMap() { /*@DONE MapRepointer.ExecuteDuplicateMap/1 cs:259-276*/
        val option = getMapBankForNewMap(
            "Maps are organized into banks. The game doesn't care, so you can use the banks however you like."
            + "\n" +
            "Duplicate map into which bank?"
        )
        if (option == -1) return
        val table = addNewMapToBank(option)
        if (table == null) {
            viewPort.raiseError(mapBankFullError)
            return
        }
        val newMap = createNewMap(history.currentChange)
        model.updateArrayPointer(history.currentChange, null, null, -1, table.start + table.length - 4, newMap.element!!.start)
        changeMap(this, ChangeMapEventArgs(option, table.elementCount - 1))
        _repointLayout?.raiseCanExecuteChanged()
        refreshHeader?.invoke()
    }
    private fun countLayoutMemberSources(member: String): Int { /*@DONE MapRepointer.CountLayoutMemberSources/1 cs:278-284*/
        val layout = getLayout() ?: return 0
        val start = layout.getAddress(member)
        val run = model.getNextRun(start)
        return run?.pointerSources?.size ?: 0
    }
    private fun executeRepointLayoutMember(member: String, length: Int, vararg commands: StubCommand?) { /*@DONE MapRepointer.ExecuteRepointLayoutMember/1 cs:286-293*/
        val layout = getLayout() ?: return
        val start = duplicateData(layout.getAddress(member), length)
        layout.setAddress(member, start)
        refreshHeader?.invoke()
        dataMoved(this, DataMovedEventArgs(member[0].uppercaseChar() + member.substring(1), start))
        for (command in commands) command?.raiseCanExecuteChanged()
    }
    val repointPrimaryBlocksText: String
        get() { /*@DONE MapRepointer.RepointPrimaryBlocksText.get cs:301-301*/
            return "These primary blocks are used by ${countBlocksetMemberSources(Format.primaryBlockset, Format.blocks)} blocksets."
        }
    private fun canRepointPrimaryBlocks(): Boolean { /*@DONE MapRepointer.CanRepointPrimaryBlocks/1 cs:303-303*/
        return countBlocksetMemberSources(Format.primaryBlockset, Format.blocks) > 1
    }
    private fun executeRepointPrimaryBlocks() { /*@DONE MapRepointer.ExecuteRepointPrimaryBlocks/1 cs:305-311*/
        val layout = getLayout()
        val attributeSize = if (model.isFRLG()) 4 else 2
        val (blockCount, _) = estimateBlockCount(layout, true)
        repointBlocksetMember(Format.primaryBlockset, Format.blocks, blockCount * 16)
        repointBlocksetMember(Format.primaryBlockset, Format.blockAttributes, blockCount * attributeSize, _repointPrimaryBlocks)
    }
    val repointSecondaryBlocksText: String
        get() { /*@DONE MapRepointer.RepointSecondaryBlocksText.get cs:313-313*/
            return "These secondary blocks are used by ${countBlocksetMemberSources(Format.secondaryBlockset, Format.blocks)} blocksets."
        }
    private fun canRepointSecondaryBlocks(): Boolean { /*@DONE MapRepointer.CanRepointSecondaryBlocks/1 cs:315-315*/
        return countBlocksetMemberSources(Format.secondaryBlockset, Format.blocks) > 1
    }
    private fun executeRepointSecondaryBlocks() { /*@DONE MapRepointer.ExecuteRepointSecondaryBlocks/1 cs:317-323*/
        val layout = getLayout()
        val attributeSize = if (model.isFRLG()) 4 else 2
        val (blockCount, _) = estimateBlockCount(layout, false)
        repointBlocksetMember(Format.secondaryBlockset, Format.blocks, blockCount * 16)
        repointBlocksetMember(Format.secondaryBlockset, Format.blockAttributes, blockCount * attributeSize, _repointSecondaryBlocks)
    }
    val expandPrimaryBlocksText: String
        get() { /*@DONE MapRepointer.ExpandPrimaryBlocksText.get cs:326-329*/
            val (currentCount, maxCount) = estimateBlockCount(getLayout(), true)
            return "This primary blockset contains $currentCount of $maxCount blocks."
        }
    private fun canExpandPrimaryBlocks(): Boolean { /*@DONE MapRepointer.CanExpandPrimaryBlocks/1 cs:332-336*/
        val layout = getLayout()
        val (blockCount, maxBlockCount) = estimateBlockCount(layout, true)
        return blockCount < maxBlockCount
    }
    private fun executeExpandPrimaryBlocks() { /*@DONE MapRepointer.ExecuteExpandPrimaryBlocks/1 cs:338-341*/
        expandBlocks(true)
        _expandPrimaryBlocks?.raiseCanExecuteChanged()
    }
    val expandSecondaryBlocksText: String
        get() { /*@DONE MapRepointer.ExpandSecondaryBlocksText.get cs:344-347*/
            val (currentCount, maxCount) = estimateBlockCount(getLayout(), false)
            return "This secondary blockset contains $currentCount of $maxCount blocks."
        }
    private fun canExpandSecondaryBlocks(): Boolean { /*@DONE MapRepointer.CanExpandSecondaryBlocks/1 cs:350-354*/
        val layout = getLayout()
        val (blockCount, maxBlockCount) = estimateBlockCount(layout, false)
        return blockCount < maxBlockCount
    }
    private fun executeExpandSecondaryBlocks() { /*@DONE MapRepointer.ExecuteExpandSecondaryBlocks/1 cs:356-359*/
        expandBlocks(false)
        _expandSecondaryBlocks?.raiseCanExecuteChanged()
    }
    private fun expandBlocks(primary: Boolean) { /*@DONE MapRepointer.ExpandBlocks/1 cs:361-384*/
        // expand blocks and attributes
        // neither have any formatting, so here's the plan:
        val token = history.currentChange
        val layout = getLayout() ?: return
        val (blockCount, maxBlockCount) = estimateBlockCount(layout, primary)
        val attributeSize = if (model.isFRLG()) 4 else 2
        val blocksetName = if (primary) Format.primaryBlockset else Format.secondaryBlockset
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return

        // (1) copy/repoint/paste the blocks
        var blockStart = blockset.getAddress(Format.blocks)
        val blockData = cut(blockStart, blockCount * 16)
        blockStart = model.relocateForExpansion(token, model.getNextRun(blockStart)!!, maxBlockCount * 16).start
        paste(blockStart, blockData, maxBlockCount * 16)

        // (2) copy/repoint/paste the attributes
        var attributeStart = blockset.getAddress(Format.blockAttributes)
        val attributeData = cut(attributeStart, blockCount * attributeSize)
        attributeStart = model.relocateForExpansion(token, model.getNextRun(attributeStart)!!, maxBlockCount * attributeSize).start
        paste(attributeStart, attributeData, maxBlockCount * attributeSize)

        dataMoved(this, DataMovedEventArgs("Block", blockStart))
        history.changeCompleted()
    }
    fun estimateBlockCount(layout: ModelArrayElement?, primary: Boolean): MapRepointerEstimateBlockCountTuple { /*@DONE MapRepointer.EstimateBlockCount/1 cs:386-399*/
        val blocksetName = if (primary) Format.primaryBlockset else Format.secondaryBlockset
        if (layout == null) return MapRepointerEstimateBlockCountTuple(0, 0)
        val blocksetTable = layout.getSubTable(blocksetName) ?: return MapRepointerEstimateBlockCountTuple(0, 0)
        val blockset = blocksetTable[0]
        val blockCount = Ref(if (model.isFRLG()) 640 else 512)
        if (!primary) blockCount.value = 1024 - blockCount.value
        val maxBlockCount = blockCount.value
        val blockStart = blockset.getAddress(Format.blocks)
        val attributeStart = blockset.getAddress(Format.blockAttributes)
        BlocksetModel.estimateBlockCount(model, blockCount, blockStart, attributeStart)
        return MapRepointerEstimateBlockCountTuple(blockCount.value, maxBlockCount)
    }
    fun exportPrimaryBlocks() { /*@DONE MapRepointer.ExportPrimaryBlocks/1 cs:401-401*/
        exportBlocks(true)
    }
    fun importPrimaryBlocks() { /*@DONE MapRepointer.ImportPrimaryBlocks/1 cs:403-403*/
        importBlocks(true)
    }
    fun exportSecondaryBlocks() { /*@DONE MapRepointer.ExportSecondaryBlocks/1 cs:405-405*/
        exportBlocks(false)
    }
    fun importSecondaryBlocks() { /*@DONE MapRepointer.ImportSecondaryBlocks/1 cs:407-407*/
        importBlocks(false)
    }
    private fun exportBlocks(primary: Boolean) { /*@DONE MapRepointer.ExportBlocks/1 cs:409-421*/
        val layout = getLayout() ?: return
        val (blockCount, maxBlockCount) = estimateBlockCount(layout, primary)
        val blocksetName = if (primary) Format.primaryBlockset else Format.secondaryBlockset
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return
        val blockStart = blockset.getAddress(Format.blocks)
        val attributeStart = blockset.getAddress(Format.blockAttributes)
        val attributeSize = if (model.isFRLG()) 2 else 1

        val exportData = ByteArray((16 + attributeSize) * blockCount)
        System.arraycopy(model.rawData, blockStart, exportData, 0, blockCount * 16)
        System.arraycopy(model.rawData, attributeStart, exportData, blockCount * 16, blockCount * attributeSize)
        exportBytes(exportData)
    }
    private fun importBlocks(primary: Boolean) { /*@DONE MapRepointer.ImportBlocks/1 cs:423-451*/
        val layout = getLayout() ?: return
        val (blockCount, maxBlockCount) = estimateBlockCount(layout, primary)
        val blocksetName = if (primary) Format.primaryBlockset else Format.secondaryBlockset
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return
        var blockStart = blockset.getAddress(Format.blocks)
        val attributeStart = blockset.getAddress(Format.blockAttributes)
        val attributeSize = if (model.isFRLG()) 2 else 1

        val file = fileSystem.openFile("Byte File", "bin") ?: return
        val bytes = file.contents
        val unitLength = 16 + attributeSize
        if (bytes.size % unitLength != 0) {
            viewPort.raiseError("Import data should be a multiple of $unitLength bytes, but was ${bytes.size} bytes.")
            return
        }
        val unitCount = bytes.size / unitLength
        val blockData = ByteArray(unitCount * 16)
        val attributeData = ByteArray(attributeSize * unitCount)
        System.arraycopy(bytes, 0, blockData, 0, blockData.size)
        System.arraycopy(bytes, blockData.size, attributeData, 0, attributeData.size)

        if (importBytes(blockStart, blockCount * 16, maxBlockCount * 16, blockData)) {
            if (importBytes(attributeStart, blockCount * attributeSize, maxBlockCount * attributeSize, attributeData)) {
                blockStart = layout.getSubTable(blocksetName)!![0].getAddress(Format.blocks)
                dataMoved(this, DataMovedEventArgs("Blockset", blockStart))
            }
        }
    }
    val repointPrimaryTilesetText: String
        get() { /*@DONE MapRepointer.RepointPrimaryTilesetText.get cs:458-461*/
            val count = countBlocksetMemberSources(Format.primaryBlockset, Format.tileset)
            return "These primary tiles are used by $count blocksets."
        }
    private fun canRepointPrimaryTileset(): Boolean { /*@DONE MapRepointer.CanRepointPrimaryTileset/1 cs:464-464*/
        return countBlocksetMemberSources(Format.primaryBlockset, Format.tileset) > 1
    }
    private fun executeRepointPrimaryTileset() { /*@DONE MapRepointer.ExecuteRepointPrimaryTileset/1 cs:466-466*/
        repointTileset(Format.primaryBlockset, _repointPrimaryTileset)
    }
    val repointSecondaryTilesetText: String
        get() { /*@DONE MapRepointer.RepointSecondaryTilesetText.get cs:469-472*/
            val count = countBlocksetMemberSources(Format.secondaryBlockset, Format.tileset)
            return "These secondary tiles are used by $count blocksets."
        }
    private fun canRepointSecondaryTileset(): Boolean { /*@DONE MapRepointer.CanRepointSecondaryTileset/1 cs:475-475*/
        return countBlocksetMemberSources(Format.secondaryBlockset, Format.tileset) > 1
    }
    private fun executeRepointSecondaryTileset() { /*@DONE MapRepointer.ExecuteRepointSecondaryTileset/1 cs:477-477*/
        repointTileset(Format.secondaryBlockset, _repointSecondaryTileset)
    }
    private fun repointTileset(blocksetName: String, command: StubCommand?) { /*@DONE MapRepointer.RepointTileset/1 cs:479-494*/
        var maxTileCount = if (model.isFRLG()) 640 else 512
        if (blocksetName == Format.secondaryBlockset) maxTileCount = 1024 - maxTileCount
        val layout = getLayout() ?: return
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return
        val isCompressed = blockset.getValue("isCompressed") != 0
        if (isCompressed) {
            val address = blockset.getAddress(Format.tileset)
            val run = LZRun(model, address)
            repointBlocksetMember(blocksetName, Format.tileset, run.length, command)
        } else {
            val address = blockset.getAddress(Format.tileset)
            val tileCount = Ref(maxTileCount)
            BlocksetModel.estimateTileCount(model, tileCount, address)
            repointBlocksetMember(blocksetName, Format.tileset, tileCount.value * 32, command)
        }
    }
    val expandPrimaryTilesetText: String
        get() { /*@DONE MapRepointer.ExpandPrimaryTilesetText.get cs:497-507*/
            val layout = getLayout()
            var currentCount = 0
            var maxCount = 0
            if (layout != null) {
                val primaryBlocksetTable = layout.getSubTable(Format.primaryBlockset)
                if (primaryBlocksetTable != null) {
                    val counts = estimateTileCount(primaryBlocksetTable[0])
                    currentCount = counts.first
                    maxCount = counts.second
                }
            }
            return "This primary tileset contains $currentCount of $maxCount tiles."
        }
    private fun canExpandPrimaryTileset(): Boolean { /*@DONE MapRepointer.CanExpandPrimaryTileset/1 cs:510-510*/
        return canExpandTileset(Format.primaryBlockset)
    }
    private fun executeExpandPrimaryTileset() { /*@DONE MapRepointer.ExecuteExpandPrimaryTileset/1 cs:512-515*/
        expandTileset(Format.primaryBlockset)
        _expandPrimaryTileset?.raiseCanExecuteChanged()
    }
    val expandSecondaryTilesetText: String
        get() { /*@DONE MapRepointer.ExpandSecondaryTilesetText.get cs:518-522*/
            val layout = getLayout()
            val (currentCount, maxCount) = if (layout == null) Pair(0, 0) else estimateTileCount(layout.getSubTable(Format.secondaryBlockset)?.get(0))
            return "This secondary tileset contains $currentCount of $maxCount tiles."
        }
    private fun canExpandSecondaryTileset(): Boolean { /*@DONE MapRepointer.CanExpandSecondaryTileset/1 cs:525-525*/
        return canExpandTileset(Format.secondaryBlockset)
    }
    private fun executeExpandSecondaryTileset() { /*@DONE MapRepointer.ExecuteExpandSecondaryTileset/1 cs:527-530*/
        expandTileset(Format.secondaryBlockset)
        _expandSecondaryTileset?.raiseCanExecuteChanged()
    }
    private fun canExpandTileset(blocksetName: String): Boolean { /*@DONE MapRepointer.CanExpandTileset/1 cs:532-540*/
        val layout = getLayout() ?: return false
        val blocksetTable = layout.getSubTable(blocksetName) ?: return false
        val blockset = blocksetTable[0]
        val (currentTiles, maxTiles) = estimateTileCount(blockset)
        return currentTiles < maxTiles
    }
    private fun expandTileset(blocksetName: String) { /*@DONE MapRepointer.ExpandTileset/1 cs:542-568*/
        val layout = getLayout() ?: return
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return
        val (currentTiles, maxTiles) = estimateTileCount(blockset)
        var start = blockset.getAddress(Format.tileset)
        if (blockset.getValue("isCompressed") != 0) {
            val run = LZRun(model, start)
            val compressedData = ByteArray(run.length)
            System.arraycopy(model.rawData, start, compressedData, 0, run.length)
            val decompressedData = LZRun.decompress(compressedData.asByteList(), 0)
            if (decompressedData == null) {
                viewPort.raiseError("The existing tileset could not be decompressed.")
                return
            }
            val newData = ByteArray(maxTiles * 0x20)
            System.arraycopy(decompressedData, 0, newData, 0, minOf(decompressedData.size, newData.size))
            val newCompressedData = byteListToArray(LZRun.compress(newData.asByteList()))
            val newRun = model.relocateForExpansion(history.currentChange, model.getNextRun(start)!!, run.length, newCompressedData.size)
            paste(newRun.start, newCompressedData, newCompressedData.size)
            start = newRun.start
            model.observeRunWritten(history.currentChange, newRun.duplicate(newRun.start, newRun.pointerSources)) // run length changed
        } else {
            val data = cut(start, currentTiles * 0x20)
            val newRun = model.relocateForExpansion(history.currentChange, model.getNextRun(start)!!, maxTiles * 0x20)
            paste(newRun.start, data, maxTiles * 0x20)
            start = newRun.start
        }

        dataMoved(this, DataMovedEventArgs("Tileset", start))
        history.changeCompleted()
    }
    private fun estimateTileCount(blockset: ModelArrayElement?): Pair<Int, Int> { /*@DONE MapRepointer.EstimateTileCount/1 cs:570-583*/
        if (blockset == null) return Pair(0, 0)
        var maxTiles = if (model.isFRLG()) 640 else 512
        if (blockset.getValue("isSecondary") != 0) maxTiles = 1024 - maxTiles
        var currentTiles = maxTiles
        val tilesetAddress = blockset.getAddress(Format.tileset)
        if (blockset.getValue("isCompressed") == 0) {
            val tileCount = Ref(currentTiles)
            BlocksetModel.estimateTileCount(model, tileCount, tilesetAddress)
            currentTiles = tileCount.value
        } else {
            val run = LZRun(model, tilesetAddress)
            currentTiles = run.decompressedLength / 0x20
        }
        return Pair(currentTiles, maxTiles)
    }
    fun exportPrimaryTileset() { /*@DONE MapRepointer.ExportPrimaryTileset/1 cs:585-585*/
        exportTileset(true)
    }
    fun importPrimaryTileset() { /*@DONE MapRepointer.ImportPrimaryTileset/1 cs:587-587*/
        importTileset(true)
    }
    fun exportSecondaryTileset() { /*@DONE MapRepointer.ExportSecondaryTileset/1 cs:589-589*/
        exportTileset(false)
    }
    fun importSecondaryTileset() { /*@DONE MapRepointer.ImportSecondaryTileset/1 cs:591-591*/
        importTileset(false)
    }
    private fun exportTileset(primary: Boolean) { /*@DONE MapRepointer.ExportTileset/1 cs:593-606*/
        val blocksetName = if (primary) Format.primaryBlockset else Format.secondaryBlockset
        val layout = getLayout() ?: return
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return
        val (currentTiles, maxTiles) = estimateTileCount(blockset)
        val start = blockset.getAddress(Format.tileset)
        val isCompressed = blockset.getValue("isCompressed") != 0
        if (isCompressed) {
            val run = LZRun(model, start)
            exportBytes(start, run.length)
        } else {
            exportBytes(start, currentTiles * 0x20)
        }
    }
    private fun importTileset(primary: Boolean) { /*@DONE MapRepointer.ImportTileset/1 cs:608-638*/
        val blocksetName = if (primary) Format.primaryBlockset else Format.secondaryBlockset
        val layout = getLayout() ?: return
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return
        val (currentTiles, maxTiles) = estimateTileCount(blockset)
        val start = blockset.getAddress(Format.tileset)
        val isCompressed = blockset.getValue("isCompressed") != 0
        if (isCompressed) {
            val file = fileSystem.openFile("Byte File", "bin") ?: return
            val existingRun = model.getNextRun(start)!!
            val newRun = model.relocateForExpansion(history.currentChange, model.getNextRun(start)!!, file.contents.size)
            history.currentChange.changeData(model, newRun.start, file.contents.asByteList())
            if (newRun is LzTilesetRun) {
                val tsRun = LzTilesetRun(newRun.tilesetFormat, model, newRun.start, newRun.pointerSources)
                model.observeRunWritten(history.currentChange, tsRun)
            }
            if (newRun.start != start) {
                dataMoved(this, DataMovedEventArgs("Tileset", newRun.start))
            } else {
                dataMoved(this, null)
            }
            for (i in file.contents.size until existingRun.length) {
                history.currentChange.changeData(model, newRun.start + i, 0xFF)
            }
        } else {
            if (importBytes(start, currentTiles * 0x20, maxTiles * 0x20)) {
                dataMoved(this, null)
            }
        }
    }
    val repointPrimaryPalettesText: String
        get() { /*@DONE MapRepointer.RepointPrimaryPalettesText.get cs:644-644*/
            return "These primary palettes are used by ${countBlocksetMemberSources(Format.primaryBlockset, Format.palette)} blocksets."
        }
    private fun canRepointPrimaryPalette(): Boolean { /*@DONE MapRepointer.CanRepointPrimaryPalette/1 cs:646-646*/
        return countBlocksetMemberSources(Format.primaryBlockset, Format.palette) > 1
    }
    private fun executeRepointPrimaryPalette() { /*@DONE MapRepointer.ExecuteRepointPrimaryPalette/1 cs:648-650*/
        repointBlocksetMember(Format.primaryBlockset, Format.palette, 0x200, _repointPrimaryPalette)
    }
    val repointSecondaryPalettesText: String
        get() { /*@DONE MapRepointer.RepointSecondaryPalettesText.get cs:652-652*/
            return "These secondary palettes are used by ${countBlocksetMemberSources(Format.secondaryBlockset, Format.palette)} blocksets."
        }
    private fun canRepointSecondaryPalette(): Boolean { /*@DONE MapRepointer.CanRepointSecondaryPalette/1 cs:654-654*/
        return countBlocksetMemberSources(Format.secondaryBlockset, Format.palette) > 1
    }
    private fun executeRepointSecondaryPalette() { /*@DONE MapRepointer.ExecuteRepointSecondaryPalette/1 cs:656-658*/
        repointBlocksetMember(Format.secondaryBlockset, Format.palette, 0x200, _repointSecondaryPalette)
    }
    val expandPrimaryPaletteText: String
        get() { /*@DONE MapRepointer.ExpandPrimaryPaletteText.get cs:660-660*/
            return ""
        }
    private fun canExpandPrimaryPalette(): Boolean { /*@DONE MapRepointer.CanExpandPrimaryPalette/1 cs:662-662*/
        return false
    }
    private fun executeExpandPrimaryPalette() { /*@DONE MapRepointer.ExecuteExpandPrimaryPalette/1 cs:664-664*/
        // the original throws NotImplementedException; the command is never enabled (CanExpandPrimaryPalette is false)
        viewPort.raiseError("Expanding the primary palettes is not supported.")
    }
    val expandSecondaryPaletteText: String
        get() { /*@DONE MapRepointer.ExpandSecondaryPaletteText.get cs:666-666*/
            return ""
        }
    private fun canExpandSecondaryPalette(): Boolean { /*@DONE MapRepointer.CanExpandSecondaryPalette/1 cs:668-668*/
        return false
    }
    private fun executeExpandSecondaryPalette() { /*@DONE MapRepointer.ExecuteExpandSecondaryPalette/1 cs:670-670*/
        // the original throws NotImplementedException; the command is never enabled (CanExpandSecondaryPalette is false)
        viewPort.raiseError("Expanding the secondary palettes is not supported.")
    }
    fun exportPrimaryPalette() { /*@DONE MapRepointer.ExportPrimaryPalette/1 cs:672-672*/
        exportPalette(true)
    }
    fun importPrimaryPalette() { /*@DONE MapRepointer.ImportPrimaryPalette/1 cs:674-674*/
        importPalette(true)
    }
    fun exportSecondaryPalette() { /*@DONE MapRepointer.ExportSecondaryPalette/1 cs:676-676*/
        exportPalette(false)
    }
    fun importSecondaryPalette() { /*@DONE MapRepointer.ImportSecondaryPalette/1 cs:678-678*/
        importPalette(false)
    }
    private fun exportPalette(primary: Boolean) { /*@DONE MapRepointer.ExportPalette/1 cs:680-688*/
        val blocksetName = if (primary) Format.primaryBlockset else Format.secondaryBlockset
        val layout = getLayout() ?: return
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return
        val start = blockset.getAddress(Format.palette)
        val folder = fileSystem.openFolder()
        if (folder == null) return
        for (i in 0 until 16) exportPal(folder, i, start + i * 32)
    }
    private fun exportPal(folder: String, nameIndex: Int, start: Int) { /*@DONE MapRepointer.ExportPal/1 cs:690-705*/
        val content = StringBuilder()
        content.append("JASC-PAL\r\n")
        content.append("0100\r\n")
        content.append("16\r\n")
        for (i in 0 until 16) {
            val color = model.readMultiByteValue(start + i * 2, 2)
            val rgb = UncompressedPaletteColor.toRGB(color.toShort())
            val r = rgb.r * 255 / 31
            val g = rgb.g * 255 / 31
            val b = rgb.b * 255 / 31
            content.append("$r $g $b\r\n")
        }
        fileSystem.save(LoadedFile(folder + "/" + nameIndex.toHex(2) + ".pal", content.toString().toByteArray(Charsets.US_ASCII)))
        viewPort.raiseMessage("Exported palettes to $folder")
    }
    private fun importPalette(primary: Boolean) { /*@DONE MapRepointer.ImportPalette/1 cs:707-716*/
        val blocksetName = if (primary) Format.primaryBlockset else Format.secondaryBlockset
        val layout = getLayout() ?: return
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return
        val start = blockset.getAddress(Format.palette)
        val folder = fileSystem.openFolder()
        if (folder == null) return
        for (i in 0 until 16) importPal(folder, i, start + i * 32)
        dataMoved(this, null)
    }
    private fun importPal(folder: String, nameIndex: Int, start: Int) { /*@DONE MapRepointer.ImportPal/1 cs:718-734*/
        val file = fileSystem.loadFile(folder + "/" + nameIndex.toHex(2) + ".pal") ?: return
        val lines = String(file.contents, Charsets.US_ASCII).splitLines()
        var colorStart = start
        for (line in lines) {
            val parts = line.split(' ')
            if (parts.size != 3) continue
            val rRef = Ref(0)
            val gRef = Ref(0)
            val bRef = Ref(0)
            if (!parts[0].tryParseInt(rRef)) continue
            if (!parts[1].tryParseInt(gRef)) continue
            if (!parts[2].tryParseInt(bRef)) continue
            val r = rRef.value / 8
            val g = gRef.value / 8
            val b = bRef.value / 8
            model.writeMultiByteValue(colorStart, 2, history.currentChange, UncompressedPaletteColor.pack(r, g, b).toInt())
            colorStart += 2
        }
    }
    private fun countBlocksetMemberSources(blocksetName: String, member: String): Int { /*@DONE MapRepointer.CountBlocksetMemberSources/1 cs:738-746*/
        val layout = getLayout() ?: return 0
        val blockset = layout.getSubTable(blocksetName) ?: return 0
        val start = blockset[0].getAddress(member)
        val run = model.getNextRun(start)
        return run?.pointerSources?.size ?: 0
    }
    private fun repointBlocksetMember(blocksetName: String, member: String, length: Int, vararg commands: StubCommand?) { /*@DONE MapRepointer.RepointBlocksetMember/1 cs:748-755*/
        val layout = getLayout() ?: return
        val blockset = layout.getSubTable(blocksetName)?.get(0) ?: return
        val start = duplicateData(blockset.getAddress(member), length)
        blockset.setAddress(member, start)
        dataMoved(this, DataMovedEventArgs(member[0].uppercaseChar() + member.substring(1), start))
        for (command in commands) command?.raiseCanExecuteChanged()
    }
    private fun cut(start: Int, length: Int): ByteArray { /*@DONE MapRepointer.Cut/1 cs:757-757*/
        return model.cut(history.currentChange, start, length)
    }
    private fun paste(start: Int, data: ByteArray, length: Int) { /*@DONE MapRepointer.Paste/1 cs:759-759*/
        model.paste(history.currentChange, start, data, length)
    }
    val createPrimaryTilesetAnimationsText: String
        get() { /*@DONE MapRepointer.CreatePrimaryTilesetAnimationsText.get cs:765-765*/
            return ""
        }
    private fun canCreatePrimaryTilesetAnimations(): Boolean { /*@DONE MapRepointer.CanCreatePrimaryTilesetAnimations/1 cs:767-770*/
        // we should be able to run the utility to create a tileset animation unless we already have
        return false
    }
    private fun executeCreatePrimaryTilesetAnimations() { /*@DONE MapRepointer.ExecuteCreatePrimaryTilesetAnimations/1 cs:772-775*/
        // TODO grab the code from the utility and use that here (the original throws NotImplementedException)
        viewPort.raiseError("Creating tileset animations from here is not supported yet.")
    }
    val createSecondaryTilesetAnimationsText: String
        get() { /*@DONE MapRepointer.CreateSecondaryTilesetAnimationsText.get cs:777-777*/
            return ""
        }
    private fun canCreateSecondaryTilesetAnimations(): Boolean { /*@DONE MapRepointer.CanCreateSecondaryTilesetAnimations/1 cs:779-782*/
        // we should be able to run the utility to create a tileset animation unless we already have
        return false
    }
    private fun executeCreateSecondaryTilesetAnimations() { /*@DONE MapRepointer.ExecuteCreateSecondaryTilesetAnimations/1 cs:784-786*/
        // grab the code from the utility and use that here
    }
    fun getMapBankForNewMap(prompt: String): Int { /*@DONE MapRepointer.GetMapBankForNewMap/1 cs:792-806*/
        val tokenFactory: () -> ModelDelta = { history.currentChange }
        val mapBanks = ModelTable(model, model.getTable(HardcodeTablesModel.mapBankTable)!!.start, tokenFactory)
        val options = ArrayList<String>()
        for (i in 0 until mapBanks.size) options.add(i.toString())
        options.add("Create New Bank")
        val enumViewModel = EnumViewModel(*options.toTypedArray())
        enumViewModel.choice = format.recentBank.limitToRange(0, options.size)
        val visualOption = VisualOption()
        visualOption.index = 1
        visualOption.option = "OK"
        visualOption.shortDescription = "Insert New Map"
        val option = fileSystem.showOptions(
            "Pick a bank",
            prompt,
            listOf(listOf<Any>(enumViewModel)),
            visualOption)
        if (option == -1) return option
        format.recentBank = enumViewModel.choice
        return enumViewModel.choice
    }
    fun addNewMapToBank(bankIndex: Int): ITableRun? { /*@DONE MapRepointer.AddNewMapToBank/1 cs:812-832*/
        val tokenFactory: () -> ModelDelta = { history.currentChange }
        val token = history.currentChange
        var mapBanks = ModelTable(model, model.getTable(HardcodeTablesModel.mapBankTable)!!.start, tokenFactory)
        var mapTable: ITableRun
        if (mapBanks.size == bankIndex) {
            var newTable = model.relocateForExpansion(token, mapBanks.run, mapBanks.run.length + mapBanks.run.elementLength)
            newTable = newTable.append(token, 1)
            model.observeRunWritten(token, newTable)
            mapBanks = ModelTable(model, newTable.start, tokenFactory, newTable)
            val tableStart = model.findFreeSpace(model.freeSpaceStart, 8)
            mapTable = TableStreamRun(model, tableStart, SortedSpanStatic.one(mapBanks[bankIndex].start), "[map<${format.mapFormat}1>]", null, DynamicStreamStrategy(model, null), 0)
            model.updateArrayPointer(token, null, null, -1, mapBanks[bankIndex].start, tableStart)
        } else {
            mapTable = mapBanks[bankIndex].getSubTable("maps")!!.run
        }
        if (mapTable.elementCount >= maxMapsPerBank) return null // don't add another map
        mapTable = mapTable.append(token, 1)
        model.observeRunWritten(token, mapTable)
        return mapTable
    }
    fun createNewMap(token: ModelDelta): MapModel { /*@DONE MapRepointer.CreateNewMap/1 cs:839-855*/
        val currentMap = getMapModel()!!
        val mapStart = model.findFreeSpace(model.freeSpaceStart, 28)
        // music: layoutID: regionSectionID. cave. weather. mapType. allowBiking. flags. floorNum. battleType.
        for (i in 16 until 28) token.changeData(model, mapStart + i, model[currentMap.start + i])

        writePointerAndSource(token, mapStart + 0, model.readPointer(currentMap.start))
        writePointerAndSource(token, mapStart + 4, createNewEvents(token))
        writePointerAndSource(token, mapStart + 8, createNewMapScripts(token))
        writePointerAndSource(token, mapStart + 12, createNewConnections(token))

        val table = TableStreamRun(model, mapStart, SortedSpan.none<Int>(), format.mapFormat, null, FixedLengthStreamStrategy(1))
        model.observeRunWritten(token, table)

        dataMoved(this, DataMovedEventArgs("Map", mapStart))
        return MapModel(ModelArrayElement(model, mapStart, 0, { token }, table))
    }
    fun createNewLayout(token: ModelDelta): LayoutModel { /*@DONE MapRepointer.CreateNewLayout/1 cs:861-879*/
        val layoutStart = model.findFreeSpace(model.freeSpaceStart, 28)
        val myLayout = getLayout()!!

        model.writeValue(token, layoutStart + 0, myLayout.getValue("width"))
        model.writeValue(token, layoutStart + 4, myLayout.getValue("height"))
        writePointerAndSource(token, layoutStart + 8, myLayout.getAddress(Format.borderBlock))
        writePointerAndSource(token, layoutStart + 12, myLayout.getAddress(Format.blockMap))
        writePointerAndSource(token, layoutStart + 16, myLayout.getAddress(Format.primaryBlockset))
        writePointerAndSource(token, layoutStart + 20, myLayout.getAddress(Format.secondaryBlockset))
        if (myLayout.hasField(Format.borderWidth)) {
            model.writeValue(token, layoutStart + 24, myLayout.getValue(Format.borderWidth))
            model.writeValue(token, layoutStart + 25, myLayout.getValue(Format.borderHeight))
            model.writeMultiByteValue(layoutStart + 26, 2, token, 0)
        }
        val table = Ref<ITableRun?>(null)
        if (ArrayRun.tryParse(model, format.layoutFormat, layoutStart, SortedSpan.none<Int>(), table) != ErrorInfo.noError) {
            throw IllegalStateException("The new layout could not be parsed.")
        }
        model.observeRunWritten(token, table.value!!)
        return LayoutModel(ModelArrayElement(model, table.value!!.start, 0, { token }, table.value))
    }
    fun createNewBlockMap(token: ModelDelta, width: Int, height: Int): Int { /*@DONE MapRepointer.CreateNewBlockMap/1 cs:881-888*/
        val blockmapLength = width * height * 2
        val blockmapStart = model.findFreeSpace(model.freeSpaceStart, blockmapLength)
        token.changeData(model, blockmapStart, ByteArray(blockmapLength).asByteList())
        val run = BlockmapRun(model, blockmapStart, SortedSpan.none<Int>(), width, height)
        model.observeRunWritten(token, run)
        return blockmapStart
    }
    fun createNewBorderBlock(token: ModelDelta): Int { /*@DONE MapRepointer.CreateNewBorderBlock/1 cs:890-900*/
        val layout = getLayout()!!
        val count = borderBlockCount(layout)
        val myStart = layout.getAddress(Format.borderBlock)
        val start = model.findFreeSpace(model.freeSpaceStart, count * 2)
        for (i in 0 until count) model.writeMultiByteValue(start + i * 2, 2, token, model.readMultiByteValue(myStart + i * 2, 2))
        return start
    }
    fun createNewEvents(token: ModelDelta): Int { /*@DONE MapRepointer.CreateNewEvents/1 cs:902-907*/
        // objectCount. warpCount. scriptCount. signpostCount. objects<> warps<> scripts<> signposts<>
        val eventStart = model.findFreeSpace(model.freeSpaceStart, 20)
        token.changeData(model, eventStart, ByteArray(20).asByteList())
        return eventStart
    }
    fun createNewMapScripts(token: ModelDelta): Int { /*@DONE MapRepointer.CreateNewMapScripts/1 cs:909-914*/
        // mapscripts<[type. pointer<>]!00>
        val eventStart = model.findFreeSpace(model.freeSpaceStart, 4)
        token.changeData(model, eventStart, byteArrayOf(0, -1, -1, -1).asByteList())
        return eventStart
    }
    fun createNewConnections(token: ModelDelta): Int { /*@DONE MapRepointer.CreateNewConnections/1 cs:916-923*/
        // count:: connections<>
        val connectionStart = model.findFreeSpace(model.freeSpaceStart, 8)
        token.changeData(model, connectionStart, ByteArray(8).asByteList())
        val run = TableStreamRun(model, connectionStart, SortedSpan.none<Int>(), "[${ConnectionInfo.connectionTableContent}]", null, FixedLengthStreamStrategy(1))
        model.observeRunWritten(token, run)
        return connectionStart
    }
    private fun getMapModel(): ModelArrayElement? { /*@DONE MapRepointer.GetMapModel/1 cs:925-927*/
        return BlockMapViewModel.getMapModel(model, mapID / 1000, mapID % 1000) { history.currentChange }
    }
    private fun getLayout(map: ModelArrayElement? = null): ModelArrayElement? { /*@DONE MapRepointer.GetLayout/1 cs:929-935*/
        val map = map ?: getMapModel() ?: return null
        val layout = map.getSubTable(Format.layout) ?: return null
        return layout[0]
    }
    private fun duplicateData(start: Int, length: Int): Int { /*@DONE MapRepointer.DuplicateData/1 cs:937-939*/
        return duplicateData(model, history, start, length)
    }
    private fun writePointerAndSource(token: ModelDelta, source: Int, destination: Int) { /*@DONE MapRepointer.WritePointerAndSource/1 cs:948-951*/
        model.writePointer(token, source, destination)
        model.observeRunWritten(token, NoInfoRun.fromPointer(model, source))
    }
    private fun importBytes(address: Int, currentSize: Int, maxSize: Int, bytes: ByteArray? = null): Boolean { /*@DONE MapRepointer.ImportBytes/1 cs:953-975*/
        var bytes = bytes
        if (bytes == null) {
            val file = fileSystem.openFile("Byte File", "bin") ?: return false
            bytes = file.contents
        }
        var minSize = 0
        var maxSize = maxSize
        if (maxSize < 0) {
            minSize = currentSize
            maxSize = currentSize
        }

        if (bytes.size > maxSize) {
            viewPort.raiseError("Expected a file with no more than $maxSize bytes, but got ${bytes.size} instead.")
            return false
        }
        if (bytes.size < minSize) {
            viewPort.raiseError("Expected a file with no less than $minSize bytes, but got ${bytes.size} instead.")
            return false
        }
        val token = viewPort.changeHistory.currentChange
        val newRun = model.relocateForExpansion(token, model.getNextRun(address)!!, currentSize, bytes.size)
        token.changeData(model, newRun.start, bytes.asByteList())
        for (i in bytes.size until currentSize) token.changeData(model, newRun.start + i, 0xFF)
        return true
    }
    private fun exportBytes(address: Int, size: Int): Boolean { /*@DONE MapRepointer.ExportBytes/1 cs:977-981*/
        val content = ByteArray(size)
        System.arraycopy(model.rawData, address, content, 0, size)
        return exportBytes(content)
    }
    private fun exportBytes(content: ByteArray): Boolean { /*@DONE MapRepointer.ExportBytes/2 cs:983-987*/
        val newName = fileSystem.requestNewName("", "Byte File", "bin") ?: return false
        return fileSystem.save(LoadedFile(newName, content))
    }
    companion object {
        const val maxMapsPerBank: Int = 127
        const val mapBankFullError: String = "Banks cannot have more than 127 maps."
        const val mapLayoutMissing: String = "Cannot create a new map when data.maps.layouts is missing."
        fun duplicateData(model: IDataModel, history: ChangeHistory<ModelDelta>, start: Int, length: Int): Int { /*@DONE MapRepointer.DuplicateData/2 cs:941-946*/
            val newStart = model.findFreeSpace(model.freeSpaceStart, length)
            val token = history.currentChange
            for (i in 0 until length) token.changeData(model, newStart + i, model[start + i])
            return newStart
        }
        /*@END MapRepointer.Companion*/
    }
    /*@ADD MapRepointer#maprepointer.txt*/
    private fun borderBlockCount(layout: ModelArrayElement): Int {
        var count = 4
        if (layout.hasField(Format.borderWidth) && layout.hasField(Format.borderHeight)) {
            count = maxOf(4, layout.getValue(Format.borderWidth) * layout.getValue(Format.borderHeight))
        }
        return count
    }
    private fun byteListToArray(list: ByteList): ByteArray {
        val result = ByteArray(list.count)
        for (i in 0 until list.count) result[i] = list[i].toByte()
        return result
    }
    /*@ENDADD MapRepointer#maprepointer.txt*/
    /*@END MapRepointer*/
}

data class MapRepointerEstimateBlockCountTuple(val currentCount: Int, val maxCount: Int)
