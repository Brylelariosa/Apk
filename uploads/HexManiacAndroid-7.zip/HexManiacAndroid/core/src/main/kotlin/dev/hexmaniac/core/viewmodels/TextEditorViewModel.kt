// Port of ViewModels/TextEditorViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

enum class TextFormatting(val value: Int) { // cs:8-8
    None(0),
    Keyword(1),
    Constant(2),
    Numeric(3),
    Comment(4),
    Text(5);
    companion object {
        fun fromValue(value: Int): TextFormatting = entries.first { it.value == value }
    }
    /*@END TextFormatting*/
}

interface ITextPreProcessor { // cs:9-12
    fun format(content: String): Array<TextFormatting>
    fun findErrors(content: String): Iterable<TextSegment>
    /*@END ITextPreProcessor*/
}

open class TextEditorViewModel : ViewModelCore { // cs:14-195
    var keywords: ObservableCollection<String> = /*@INITDONE TextEditorViewModel.Keywords cs:15-15*/ ObservableCollection() /*@ENDINIT*/
        private set
    var constants: ObservableCollection<String> = /*@INITDONE TextEditorViewModel.Constants cs:16-16*/ ObservableCollection() /*@ENDINIT*/
        private set
    var errorLocations: ObservableCollection<TextSegment> = /*@INITDONE TextEditorViewModel.ErrorLocations cs:17-17*/ ObservableCollection() /*@ENDINIT*/
        private set
    private var commentHeader: String = /*@INITAUTO TextEditorViewModel.commentHeader cs:19-19*/ "" /*@ENDINIT*/
    private var multiLineCommentStart: String = /*@INITAUTO TextEditorViewModel.multiLineCommentStart cs:19-19*/ "" /*@ENDINIT*/
    private var multiLineCommentEnd: String = /*@INITAUTO TextEditorViewModel.multiLineCommentEnd cs:19-19*/ "" /*@ENDINIT*/
    var lineCommentHeader: String
        get() { /*@DONE TextEditorViewModel.LineCommentHeader.get cs:20-20*/
            return commentHeader
        }
        set(value) { /*@DONE TextEditorViewModel.LineCommentHeader.set cs:20-20*/
            set(commentHeader, value, "lineCommentHeader", { commentHeader = it })
        }
    var multiLineCommentHeader: String
        get() { /*@DONE TextEditorViewModel.MultiLineCommentHeader.get cs:21-21*/
            return multiLineCommentStart
        }
        set(value) { /*@DONE TextEditorViewModel.MultiLineCommentHeader.set cs:21-21*/
            set(multiLineCommentStart, value, "multiLineCommentHeader", { multiLineCommentStart = it })
        }
    var multiLineCommentFooter: String
        get() { /*@DONE TextEditorViewModel.MultiLineCommentFooter.get cs:22-22*/
            return multiLineCommentEnd
        }
        set(value) { /*@DONE TextEditorViewModel.MultiLineCommentFooter.set cs:22-22*/
            set(multiLineCommentEnd, value, "multiLineCommentFooter", { multiLineCommentEnd = it })
        }
    var syntaxHighlighting: Boolean = false
        private set
    var preFormatter: ITextPreProcessor? = null
    val requestCaretMove = Event<EventArgs>()
    val requestKeyboardFocus = Event<EventArgs>()
    constructor() { /*@DONE TextEditorViewModel.<init>/1 cs:31-35*/
        keywords.collectionChanged += { _, _ -> updateLayers() }
        constants.collectionChanged += { _, _ -> updateLayers() }
        syntaxHighlighting = true
    }
    constructor(syntaxHighlighting: Boolean) { /*@DONE TextEditorViewModel.<init>/2 cs:37-41*/
        keywords.collectionChanged += { _, _ -> updateLayers() }
        constants.collectionChanged += { _, _ -> updateLayers() }
        this.syntaxHighlighting = syntaxHighlighting
    }
    private var contentChanging: Boolean = false
    private var _content: String = /*@INITAUTO TextEditorViewModel.content cs:44-44*/ "" /*@ENDINIT*/
    var content: String
        get() { /*@DONE TextEditorViewModel.Content.get cs:46-46*/
            return _content
        }
        set(value) { /*@DONE TextEditorViewModel.Content.set cs:47-56*/
            if (_content == value) return
            val oldContent = _content
            _content = value
            updateLayers()
            scope(contentChanging, true, { contentChanging = it }, { back -> contentChanging = back }).using {
                notifyPropertyChanged(oldContent, "content")
            }
        }
    private var _caretIndex: Int = 0
    var caretIndex: Int
        get() { /*@DONE TextEditorViewModel.CaretIndex.get cs:61-61*/
            return _caretIndex
        }
        set(value) { /*@DONE TextEditorViewModel.CaretIndex.set cs:62-65*/
            if (contentChanging) return
            set(_caretIndex, value, "caretIndex", { _caretIndex = it }, { _ -> requestCaretMove(this, EventArgs.empty) })
        }
    var accentContent: String = /*@INITAUTO TextEditorViewModel.AccentContent cs:68-68*/ "" /*@ENDINIT*/
        private set
    var plainContent: String = /*@INITAUTO TextEditorViewModel.PlainContent cs:69-69*/ "" /*@ENDINIT*/
        private set
    var constantContent: String = /*@INITAUTO TextEditorViewModel.ConstantContent cs:70-70*/ "" /*@ENDINIT*/
        private set
    var numericContent: String = /*@INITAUTO TextEditorViewModel.NumericContent cs:71-71*/ "" /*@ENDINIT*/
        private set
    var commentContent: String = /*@INITAUTO TextEditorViewModel.CommentContent cs:72-72*/ "" /*@ENDINIT*/
        private set
    var textContent: String = /*@INITAUTO TextEditorViewModel.TextContent cs:73-73*/ "" /*@ENDINIT*/
        private set
    fun pushCaretUpdate(index: Int) { /*@DONE TextEditorViewModel.PushCaretUpdate/1 cs:75-78*/
        caretIndex = index
        requestCaretMove(this, EventArgs.empty)
    }
    fun focusKeyboard() { /*@DONE TextEditorViewModel.FocusKeyboard/1 cs:80-80*/
        requestKeyboardFocus(this, EventArgs.empty)
    }
    private fun updateLayers() { /*@DONE TextEditorViewModel.UpdateLayers/1 cs:82-194*/
        errorLocations.clear()
        if (_content.length == 0) {
            if (plainContent.length != 0) {
                plainContent = ""
                accentContent = ""
                constantContent = ""
                numericContent = ""
                commentContent = ""
                textContent = ""
                notifyPropertiesChanged(
                    "plainContent", "accentContent",
                    "constantContent", "numericContent",
                    "commentContent", "textContent")
            }
            return
        }
        val basic = MutableString(content)
        val accent = MutableString(basic.length)
        val constants = MutableString(basic.length)
        val numeric = MutableString(basic.length)
        val comments = MutableString(basic.length)
        val text = MutableString(basic.length)
        accent.copyWhitespace(basic)
        constants.copyWhitespace(basic)
        numeric.copyWhitespace(basic)
        comments.copyWhitespace(basic)
        text.copyWhitespace(basic)

        val formatter = preFormatter
        if (formatter != null) {
            val pre = formatter.format(content)
            for (i in 0 until pre.size) {
                if (pre[i] == TextFormatting.None) continue
                if (pre[i] == TextFormatting.Keyword) accent.replace(i, basic, i, 1)
                if (pre[i] == TextFormatting.Constant) constants.replace(i, basic, i, 1)
                if (pre[i] == TextFormatting.Numeric) numeric.replace(i, basic, i, 1)
                if (pre[i] == TextFormatting.Comment) comments.replace(i, basic, i, 1)
                if (pre[i] == TextFormatting.Text) text.replace(i, basic, i, 1)
                basic.clear(i, 1)
            }
            for (error in formatter.findErrors(content)) errorLocations.add(error)
        }

        // comments
        while (lineCommentHeader.isNotEmpty()) {
            val index = basic.indexOf(lineCommentHeader)
            if (index == -1) break
            val endIndex = basic.indexOfCharacter(index, '\n', '\r')
            if (index == -1) break
            comments.replace(index, basic, index, endIndex - index)
            basic.clear(index, endIndex - index)
        }
        while (multiLineCommentStart.isNotEmpty() && multiLineCommentEnd.isNotEmpty()) {
            val index = basic.indexOf(multiLineCommentStart)
            if (index == -1) break
            var endIndex = basic.indexOf(multiLineCommentEnd, index + multiLineCommentStart.length)
            if (endIndex == -1) endIndex = basic.length
            else endIndex += multiLineCommentEnd.length
            comments.replace(index, basic, index, endIndex - index)
            basic.clear(index, endIndex - index)
        }

        val check = basic.getPossibleKeywordStartPoints().toList()
        for (i in 0 until check.size) {
            var match = false

            // keywords
            for (j in 0 until keywords.size) {
                if (check[i].length != keywords[j].length) continue
                if (basic.match(keywords[j], check[i].start)) {
                    accent.replace(check[i].start, keywords[j])
                    basic.clear(check[i].start, keywords[j].length)
                    match = true
                    break
                }
            }
            if (match) continue

            // constants
            for (j in 0 until this.constants.size) {
                if (check[i].length != this.constants[j].length) continue
                if (basic.match(this.constants[j], check[i].start)) {
                    constants.replace(check[i].start, this.constants[j])
                    basic.clear(check[i].start, this.constants[j].length)
                    break
                }
            }
        }

        // numeric
        if (syntaxHighlighting) {
            var start = 0
            while (true) {
                val found = basic.indexOfNumber(start)
                val index = found.item1
                val length = found.item2
                if (index == -1) break
                start = index
                numeric.replace(index, basic, index, length)
                basic.clear(index, length)
            }
        }

        plainContent = basic.toString()
        accentContent = accent.toString()
        constantContent = constants.toString()
        numericContent = numeric.toString()
        commentContent = comments.toString()
        textContent = text.toString()

        notifyPropertiesChanged(
            "plainContent",
            "accentContent",
            "constantContent",
            "numericContent",
            "commentContent",
            "textContent")
    }
    /*@END TextEditorViewModel*/
}

enum class SegmentType(val value: Int) { // cs:197-197
    None(0),
    Warning(1),
    Error(2);
    companion object {
        fun fromValue(value: Int): SegmentType = entries.first { it.value == value }
    }
    /*@END SegmentType*/
}

data class TextSegment(val line: Int, val start: Int, val length: Int, val type: SegmentType) : INotifyPropertyChanged { // cs:198-200
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    /*@END TextSegment*/
}

open class MutableString { // cs:202-321
    private var content: CharArray = CharArray(0)
    val length: Int
        get() { /*@DONE MutableString.Length.get cs:205-205*/
            return content.size
        }
    constructor(initialContent: String) { /*@DONE MutableString.<init>/1 cs:207-207*/
        content = initialContent.toCharArray()
    }
    constructor(length: Int) { /*@DONE MutableString.<init>/2 cs:208-208*/
        content = CharArray(length)
    }
    override fun toString(): String { /*@DONE MutableString.ToString/1 cs:210-210*/
        return String(content)
    }
    fun indexOfKeyword(keyword: String, start: Int): Int { /*@DONE MutableString.IndexOfKeyword/1 cs:212-222*/
        if (keyword.length == 0) return -1
        for (i in start until content.size - keyword.length + 1) {
            if (i > 0 && content[i - 1].isLetterOrDigit()) continue // not valid keyword start
            if (i < content.size - keyword.length && content[i + keyword.length].isLetterOrDigit()) continue // not valid keyword end
            var matchLength = 0
            var j = 0
            while (j < keyword.length && keyword[j] == content[i + j]) {
                matchLength = j + 1
                j++
            }
            if (matchLength == keyword.length) return i
        }
        return -1
    }
    fun getPossibleKeywordStartPoints(): Iterable<MutableStringGetPossibleKeywordStartPointsTuple> { /*@DONE MutableString.GetPossibleKeywordStartPoints/1 cs:224-245*/
        val result = ArrayList<MutableStringGetPossibleKeywordStartPointsTuple>()
        var i = 0
        while (i < content.size - 1) {
            if (i > 0 && content[i - 1].isLetterOrDigit()) { i++; continue } // not valid keyword start
            if (content[i] == '"') {
                // look for matching
                var closeIndex = i
                for (j in i + 1 until content.size) {
                    if (content[j] != '"') continue
                    closeIndex = j
                    break
                }
                if (closeIndex == i) break
                result.add(MutableStringGetPossibleKeywordStartPointsTuple(i, closeIndex - i + 1))
                i = closeIndex + 1
            }
            if (i < content.size && !content[i].isLetterOrDigit()) { i++; continue } // some constants _do_ start with numbers, like 2to5Hits
            var length = 1
            while (i + length < content.size && (content[i + length].isLetterOrDigit() || ".'-~_\\".contains(content[i + length]))) length++
            result.add(MutableStringGetPossibleKeywordStartPointsTuple(i, length))
            i += length
            i++
        }
        return result
    }
    fun match(keyword: String, start: Int): Boolean { /*@DONE MutableString.Match/1 cs:247-253*/
        if (start < 0 || start + keyword.length > content.size) return false
        for (i in 0 until keyword.length) {
            if (content[start + i] != keyword[i]) return false
        }
        return true
    }
    fun indexOf(text: String, start: Int = 0): Int { /*@DONE MutableString.IndexOf/1 cs:255-263*/
        if (text.length == 0) return -1
        for (i in start until content.size - text.length + 1) {
            var matchLength = 0
            var j = 0
            while (j < text.length && content[i + j] == text[j]) {
                matchLength = j + 1
                j++
            }
            if (matchLength == text.length) return i
        }
        return -1
    }
    fun indexOfCharacter(start: Int, vararg options: Char): Int { /*@DONE MutableString.IndexOfCharacter/1 cs:265-270*/
        for (i in start until content.size) {
            if (options.contains(content[i])) return i
        }
        return content.size
    }
    fun indexOfNumber(start: Int): MutableStringIndexOfNumberTuple { /*@DONE MutableString.IndexOfNumber/1 cs:273-297*/
        for (i in start until content.size) {
            if (i > 0 && content[i - 1].isLetterOrDigit()) continue
            if (i > 0 && content[i - 1] == '_') continue // non-letter characters that are not considered token splitters
            if (!content[i].isDigit() && !hexLetters.contains(content[i])) continue
            var length = 1
            while (true) {
                if (i + length >= content.size) break
                if (length == 1 && content[i + length] == 'x') {
                    length++
                    continue
                }
                if (hexLetters.contains(content[i + length])) {
                    length++
                    continue
                }
                if (!content[i + length].isDigit()) break
                length++
            }
            if (length < 0) continue
            if (i + length < content.size && content[i + length].isLetter()) continue
            return MutableStringIndexOfNumberTuple(i, length)
        }
        return MutableStringIndexOfNumberTuple(-1, -1)
    }
    fun replace(index: Int, keyword: String) { /*@DONE MutableString.Replace/1 cs:299-301*/
        for (i in 0 until keyword.length) content[index + i] = keyword[i]
    }
    fun replace(index: Int, source: MutableString, start: Int, length: Int) { /*@DONE MutableString.Replace/2 cs:303-305*/
        for (i in 0 until length) content[index + i] = source.content[start + i]
    }
    fun clear(index: Int, length: Int) { /*@DONE MutableString.Clear/1 cs:307-312*/
        for (i in 0 until length) {
            val c = content[index + i]
            if (c == '\n' || c == '\r' || c == '\t') continue
            content[index + i] = ' '
        }
    }
    fun copyWhitespace(other: MutableString) { /*@DONE MutableString.CopyWhitespace/1 cs:314-320*/
        for (i in 0 until content.size) {
            val c = other.content[i]
            if (c == '\n' || c == '\r' || c == '\t') {
                content[i] = c
            }
        }
    }
    companion object {
        private val hexLetters: CharArray = /*@INITDONE MutableString.hexLetters cs:272-272*/ "ABCDEF".toCharArray() /*@ENDINIT*/
        /*@END MutableString.Companion*/
    }
    /*@END MutableString*/
}

data class MutableStringGetPossibleKeywordStartPointsTuple(val start: Int, val length: Int)

data class MutableStringIndexOfNumberTuple(val item1: Int, val item2: Int)
