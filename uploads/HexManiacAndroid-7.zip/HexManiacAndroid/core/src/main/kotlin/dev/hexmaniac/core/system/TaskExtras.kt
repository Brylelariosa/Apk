package dev.hexmaniac.core.system

import dev.hexmaniac.core.models.InlineDispatch
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

/** `await dispatcher.SomethingReturningInlineDispatch()`: resumes through the dispatcher (C# awaiter pattern). */
suspend fun InlineDispatch.await() {
    suspendCoroutine<Unit> { cont -> onCompleted { cont.resume(Unit) } }
}
