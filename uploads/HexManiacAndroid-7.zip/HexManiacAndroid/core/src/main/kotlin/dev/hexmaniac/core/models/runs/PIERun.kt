// Port of Models/Runs/PIERun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.factory.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class PIERun : BaseRun, IStreamRun, IAppendToBuilderRun { // cs:16-559
    private lateinit var model: IDataModel
    private var hasArgByte: Boolean = false
    private var _hasLowHappinessByte: Boolean = false
    private var _hasMidHappinessByte: Boolean = false
    private var _hasHighHappinessByte: Boolean = false
    var healInfatuation: Boolean
        get() { /*@DONE PIERun.HealInfatuation.get cs:27-27*/
            return getBit(start, 7)
        }
        set(value) { /*@DONE PIERun.HealInfatuation.set cs:28-28*/
            setBit(start, 7, value)
        }
    var applyToFirstPokemonOnly: Boolean
        get() { /*@DONE PIERun.ApplyToFirstPokemonOnly.get cs:32-32*/
            return getBit(start, 6)
        }
        set(value) { /*@DONE PIERun.ApplyToFirstPokemonOnly.set cs:33-33*/
            setBit(start, 6, value)
        }
    var direHit: Byte
        get() { /*@DONE PIERun.DireHit.get cs:37-41*/
            val high = getBit(start, 5)
            val low = getBit(start, 4)
            return ((if (high) 2 else 0) + (if (low) 1 else 0)).toByte()
        }
        set(value) { /*@DONE PIERun.DireHit.set cs:42-47*/
            val high = value > 1
            val low = value % 2 == 1
            setBit(start, 5, high)
            setBit(start, 4, low)
        }
    var attackStatIncrease: Int
        get() { /*@DONE PIERun.AttackStatIncrease.get cs:51-51*/
            return getLow(start)
        }
        set(value) { /*@DONE PIERun.AttackStatIncrease.set cs:52-52*/
            setLow(start, value)
        }
    var speedStatIncrease: Int
        get() { /*@DONE PIERun.SpeedStatIncrease.get cs:57-57*/
            return getLow(start + 1)
        }
        set(value) { /*@DONE PIERun.SpeedStatIncrease.set cs:58-58*/
            setLow(start + 1, value)
        }
    var defenseStatIncrease: Int
        get() { /*@DONE PIERun.DefenseStatIncrease.get cs:62-62*/
            return getHigh(start + 1)
        }
        set(value) { /*@DONE PIERun.DefenseStatIncrease.set cs:63-63*/
            setHigh(start + 1, value)
        }
    var specialAttackStatIncrease: Int
        get() { /*@DONE PIERun.SpecialAttackStatIncrease.get cs:68-68*/
            return getLow(start + 2)
        }
        set(value) { /*@DONE PIERun.SpecialAttackStatIncrease.set cs:69-69*/
            setLow(start + 2, value)
        }
    var accuracyStatIncrease: Int
        get() { /*@DONE PIERun.AccuracyStatIncrease.get cs:73-73*/
            return getHigh(start + 2)
        }
        set(value) { /*@DONE PIERun.AccuracyStatIncrease.set cs:74-74*/
            setHigh(start + 2, value)
        }
    var guardSpec: Boolean
        get() { /*@DONE PIERun.GuardSpec.get cs:79-79*/
            return getBit(start + 3, 7)
        }
        set(value) { /*@DONE PIERun.GuardSpec.set cs:80-80*/
            setBit(start + 3, 7, value)
        }
    var levelUp: Boolean
        get() { /*@DONE PIERun.LevelUp.get cs:83-83*/
            return getBit(start + 3, 6)
        }
        set(value) { /*@DONE PIERun.LevelUp.set cs:84-84*/
            setBit(start + 3, 6, value)
        }
    var clearSleep: Boolean
        get() { /*@DONE PIERun.ClearSleep.get cs:87-87*/
            return getBit(start + 3, 5)
        }
        set(value) { /*@DONE PIERun.ClearSleep.set cs:88-88*/
            setBit(start + 3, 5, value)
        }
    var clearPoison: Boolean
        get() { /*@DONE PIERun.ClearPoison.get cs:91-91*/
            return getBit(start + 3, 4)
        }
        set(value) { /*@DONE PIERun.ClearPoison.set cs:92-92*/
            setBit(start + 3, 4, value)
        }
    var clearBurn: Boolean
        get() { /*@DONE PIERun.ClearBurn.get cs:95-95*/
            return getBit(start + 3, 3)
        }
        set(value) { /*@DONE PIERun.ClearBurn.set cs:96-96*/
            setBit(start + 3, 3, value)
        }
    var clearIce: Boolean
        get() { /*@DONE PIERun.ClearIce.get cs:99-99*/
            return getBit(start + 3, 2)
        }
        set(value) { /*@DONE PIERun.ClearIce.set cs:100-100*/
            setBit(start + 3, 2, value)
        }
    var clearParalyze: Boolean
        get() { /*@DONE PIERun.ClearParalyze.get cs:103-103*/
            return getBit(start + 3, 1)
        }
        set(value) { /*@DONE PIERun.ClearParalyze.set cs:104-104*/
            setBit(start + 3, 1, value)
        }
    var clearConfusion: Boolean
        get() { /*@DONE PIERun.ClearConfusion.get cs:107-107*/
            return getBit(start + 3, 0)
        }
        set(value) { /*@DONE PIERun.ClearConfusion.set cs:108-108*/
            setBit(start + 3, 0, value)
        }
    var increaseHpEv: Boolean
        get() { /*@DONE PIERun.IncreaseHpEv.get cs:113-113*/
            return getBit(start + 4, 0)
        }
        set(value) { /*@DONE PIERun.IncreaseHpEv.set cs:114-114*/
            setBit(start + 4, 0, value)
        }
    var increaseAttackEv: Boolean
        get() { /*@DONE PIERun.IncreaseAttackEv.get cs:117-117*/
            return getBit(start + 4, 1)
        }
        set(value) { /*@DONE PIERun.IncreaseAttackEv.set cs:118-118*/
            setBit(start + 4, 1, value)
        }
    var healHealth: Boolean
        get() { /*@DONE PIERun.HealHealth.get cs:121-121*/
            return getBit(start + 4, 2)
        }
        set(value) { /*@DONE PIERun.HealHealth.set cs:122-122*/
            setBit(start + 4, 2, value)
        }
    var healPowerPoints: Boolean
        get() { /*@DONE PIERun.HealPowerPoints.get cs:125-125*/
            return getBit(start + 4, 3)
        }
        set(value) { /*@DONE PIERun.HealPowerPoints.set cs:126-126*/
            setBit(start + 4, 3, value)
        }
    var requireAttackSelection: Boolean
        get() { /*@DONE PIERun.RequireAttackSelection.get cs:129-129*/
            return getBit(start + 4, 4)
        }
        set(value) { /*@DONE PIERun.RequireAttackSelection.set cs:130-130*/
            setBit(start + 4, 4, value)
        }
    var increaseMaxPowerPoints: Boolean
        get() { /*@DONE PIERun.IncreaseMaxPowerPoints.get cs:133-133*/
            return getBit(start + 4, 5)
        }
        set(value) { /*@DONE PIERun.IncreaseMaxPowerPoints.set cs:134-134*/
            setBit(start + 4, 5, value)
        }
    var reviveAndHeal: Boolean
        get() { /*@DONE PIERun.ReviveAndHeal.get cs:137-137*/
            return getBit(start + 4, 6)
        }
        set(value) { /*@DONE PIERun.ReviveAndHeal.set cs:138-138*/
            setBit(start + 4, 6, value)
        }
    var evolutionStone: Boolean
        get() { /*@DONE PIERun.EvolutionStone.get cs:141-141*/
            return getBit(start + 4, 7)
        }
        set(value) { /*@DONE PIERun.EvolutionStone.set cs:142-142*/
            setBit(start + 4, 7, value)
        }
    var changeHappinessWhenGreaterThan200: Boolean
        get() { /*@DONE PIERun.ChangeHappinessWhenGreaterThan200.get cs:147-147*/
            return getBit(start + 5, 7)
        }
        set(value) { /*@DONE PIERun.ChangeHappinessWhenGreaterThan200.set cs:148-148*/
            setBit(start + 5, 7, value)
        }
    var changeHappinessWhenBetween100And199: Boolean
        get() { /*@DONE PIERun.ChangeHappinessWhenBetween100And199.get cs:151-151*/
            return getBit(start + 5, 6)
        }
        set(value) { /*@DONE PIERun.ChangeHappinessWhenBetween100And199.set cs:152-152*/
            setBit(start + 5, 6, value)
        }
    var changeHappinessWhenLessThan100: Boolean
        get() { /*@DONE PIERun.ChangeHappinessWhenLessThan100.get cs:155-155*/
            return getBit(start + 5, 5)
        }
        set(value) { /*@DONE PIERun.ChangeHappinessWhenLessThan100.set cs:156-156*/
            setBit(start + 5, 5, value)
        }
    var increasePowerPointsToMax: Boolean
        get() { /*@DONE PIERun.IncreasePowerPointsToMax.get cs:159-159*/
            return getBit(start + 5, 4)
        }
        set(value) { /*@DONE PIERun.IncreasePowerPointsToMax.set cs:160-160*/
            setBit(start + 5, 4, value)
        }
    var increaseSpecialAttackEv: Boolean
        get() { /*@DONE PIERun.IncreaseSpecialAttackEv.get cs:163-163*/
            return getBit(start + 5, 3)
        }
        set(value) { /*@DONE PIERun.IncreaseSpecialAttackEv.set cs:164-164*/
            setBit(start + 5, 3, value)
        }
    var increaseSpecialDefenseEv: Boolean
        get() { /*@DONE PIERun.IncreaseSpecialDefenseEv.get cs:167-167*/
            return getBit(start + 5, 2)
        }
        set(value) { /*@DONE PIERun.IncreaseSpecialDefenseEv.set cs:168-168*/
            setBit(start + 5, 2, value)
        }
    var increaseSpeedEv: Boolean
        get() { /*@DONE PIERun.IncreaseSpeedEv.get cs:171-171*/
            return getBit(start + 5, 1)
        }
        set(value) { /*@DONE PIERun.IncreaseSpeedEv.set cs:172-172*/
            setBit(start + 5, 1, value)
        }
    var increaseDefenseEv: Boolean
        get() { /*@DONE PIERun.IncreaseDefenseEv.get cs:175-175*/
            return getBit(start + 5, 0)
        }
        set(value) { /*@DONE PIERun.IncreaseDefenseEv.set cs:176-176*/
            setBit(start + 5, 0, value)
        }
    val hasArg: Boolean
        get() { /*@DONE PIERun.HasArg.get cs:180-180*/
            return hasArgByte
        }
    var arg: Short
        get() { /*@DONE PIERun.Arg.get cs:186-190*/
            var value = model[start + 6].toByte().toShort()
            if (value < -3) value = (value + 0x100).toShort()
            return value
        }
        set(value) { /*@DONE PIERun.Arg.set cs:191-191*/
            editScope!!.changeToken!!.changeData(model, start + 6, value.toInt() and 0xFF)
        }
    val hasLowHappinessByte: Boolean
        get() { /*@DONE PIERun.HasLowHappinessByte.get cs:195-195*/
            return _hasLowHappinessByte
        }
    var lowHappinessChange: Byte
        get() { /*@DONE PIERun.LowHappinessChange.get cs:197-197*/
            return model[start + 6 + (if (hasArg) 1 else 0)].toByte()
        }
        set(value) { /*@DONE PIERun.LowHappinessChange.set cs:198-198*/
            editScope!!.changeToken!!.changeData(model, start + 6 + (if (hasArg) 1 else 0), value.toInt() and 0xFF)
        }
    val hasMidHappinessByte: Boolean
        get() { /*@DONE PIERun.HasMidHappinessByte.get cs:201-201*/
            return _hasMidHappinessByte
        }
    var midHappinessChange: Byte
        get() { /*@DONE PIERun.MidHappinessChange.get cs:203-203*/
            return model[start + 6 + (if (hasArg) 1 else 0) + (if (hasLowHappinessByte) 1 else 0)].toByte()
        }
        set(value) { /*@DONE PIERun.MidHappinessChange.set cs:204-204*/
            editScope!!.changeToken!!.changeData(model, start + 6 + (if (hasArg) 1 else 0) + (if (hasLowHappinessByte) 1 else 0), value.toInt() and 0xFF)
        }
    val hasHighHappinessByte: Boolean
        get() { /*@DONE PIERun.HasHighHappinessByte.get cs:207-207*/
            return _hasHighHappinessByte
        }
    var highHappinessChange: Byte
        get() { /*@DONE PIERun.HighHappinessChange.get cs:209-209*/
            return model[start + 6 + (if (hasArg) 1 else 0) + (if (hasLowHappinessByte) 1 else 0) + (if (hasMidHappinessByte) 1 else 0)].toByte()
        }
        set(value) { /*@DONE PIERun.HighHappinessChange.set cs:210-210*/
            editScope!!.changeToken!!.changeData(model, start + 6 + (if (hasArg) 1 else 0) + (if (hasLowHappinessByte) 1 else 0) + (if (hasMidHappinessByte) 1 else 0), value.toInt() and 0xFF)
        }
    override val length: Int
        get() { /*@DONE PIERun.Length.get cs:217-217*/
            return 6 + (if (hasArgByte) 1 else 0) + (if (_hasLowHappinessByte) 1 else 0) + (if (_hasMidHappinessByte) 1 else 0) + (if (_hasHighHappinessByte) 1 else 0)
        }
    override val formatString: String
        get() { /*@DONE PIERun.FormatString.get cs:219-219*/
            return sharedFormatString
        }
    constructor(model: IDataModel, start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE PIERun.<init>/1 cs:221-224*/
        this.model = model
        refreshFlags()
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE PIERun.CreateDataFormat/1 cs:226-226*/
        return IntegerHex(index, 0, data[index], 1)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE PIERun.Clone/1 cs:228-228*/
        return PIERun(model, start, newPointerSources)
    }
    private fun refreshFlags() { /*@DONE PIERun.RefreshFlags/1 cs:230-243*/
        _hasLowHappinessByte = changeHappinessWhenLessThan100
        _hasMidHappinessByte = changeHappinessWhenBetween100And199
        _hasHighHappinessByte = changeHappinessWhenGreaterThan200
        hasArgByte =
            increaseSpecialDefenseEv ||
            increaseDefenseEv ||
            increaseAttackEv ||
            increaseSpecialAttackEv ||
            increaseSpeedEv ||
            increaseHpEv ||
            healHealth ||
            healPowerPoints
    }
    override fun serializeRun(): String? { /*@DONE PIERun.SerializeRun/1 cs:249-308*/
        val result = StringBuilder()
        addLine(result, "ApplyToFirstPokemonOnly = " + boolText(applyToFirstPokemonOnly))
        addLine(result, "RequireAttackSelection = " + boolText(requireAttackSelection))
        addLine(result, "DireHit = " + direHit)
        val general = LinkedHashMap<String, Boolean>()
        general["GuardSpec"] = guardSpec
        general["LevelUp"] = levelUp
        general["HealHealth"] = healHealth
        general["HealPowerPoints"] = healPowerPoints
        general["ReviveAndHeal"] = reviveAndHeal
        general["EvolutionStone"] = evolutionStone
        renderFlagList(result, "General", general)
        val clearStat = LinkedHashMap<String, Boolean>()
        clearStat["Infatuation"] = healInfatuation
        clearStat["Sleep"] = clearSleep
        clearStat["Poison"] = clearPoison
        clearStat["Burn"] = clearBurn
        clearStat["Ice"] = clearIce
        clearStat["Paralyze"] = clearParalyze
        clearStat["Confusion"] = clearConfusion
        renderFlagList(result, "ClearStat", clearStat)
        val increaseStat = LinkedHashMap<String, Boolean>()
        increaseStat["HpEv"] = increaseHpEv
        increaseStat["AttackEv"] = increaseAttackEv
        increaseStat["DefenseEv"] = increaseDefenseEv
        increaseStat["SpecialAttackEv"] = increaseSpecialAttackEv
        increaseStat["SpecialDefenseEv"] = increaseSpecialDefenseEv
        increaseStat["SpeedEv"] = increaseSpeedEv
        increaseStat["MaxPowerPoints"] = increaseMaxPowerPoints
        increaseStat["PowerPointsToMax"] = increasePowerPointsToMax
        renderFlagList(result, "IncreaseStat", increaseStat)
        val changeHappiness = LinkedHashMap<String, Boolean>()
        changeHappiness["Low"] = changeHappinessWhenLessThan100
        changeHappiness["Mid"] = changeHappinessWhenBetween100And199
        changeHappiness["High"] = changeHappinessWhenGreaterThan200
        renderFlagList(result, "ChangeHappiness", changeHappiness)
        addLine(result)
        addLine(result, "AttackStatIncrease = " + attackStatIncrease)
        addLine(result, "SpecialAttackStatIncrease = " + specialAttackStatIncrease)
        addLine(result, "DefenseStatIncrease = " + defenseStatIncrease)
        addLine(result, "SpeedStatIncrease = " + speedStatIncrease)
        addLine(result, "AccuracyStatIncrease = " + accuracyStatIncrease)

        if (hasArg) {
            addLine(result)
            val arg = this.arg
            var argText = arg.toString()
            if (arg.toInt() == healthRestore_FromLevelUp.toInt()) argText = "LevelUpHealth"
            if (arg.toInt() == healthRestore_Half.toInt()) argText = "Half"
            if (arg.toInt() == healthRestore_Max.toInt()) argText = "Max"
            addLine(result, "Arg = " + argText)
        }
        if (hasLowHappinessByte || hasMidHappinessByte || hasHighHappinessByte) addLine(result)
        if (hasLowHappinessByte) addLine(result, "LowHappinessChange = " + lowHappinessChange)
        if (hasMidHappinessByte) addLine(result, "MidHappinessChange = " + midHappinessChange)
        if (hasHighHappinessByte) addLine(result, "HighHappinessChange = " + highHappinessChange)

        return result.toString()
    }
    private fun renderFlagList(builder: StringBuilder, setName: String, flags: MutableMap<String, Boolean>) { /*@DONE PIERun.RenderFlagList/1 cs:310-316*/
        builder.append(setName + " = { ")
        var content = flags.keys.filter { key -> flags[key] == true }.joinToString(", ")
        if (!content.isBlank()) content += " "
        builder.append(content)
        builder.append("}").append(NEW_LINE)
    }
    private fun readFlagList(list: String, options: MutableMap<String, (Boolean) -> Unit>) { /*@DONE PIERun.ReadFlagList/1 cs:318-327*/
        val tokens = list.split('{', '}', ' ', ',').filter { token -> token.isNotEmpty() }
        for (key in options.keys) {
            if (tokens.contains(key.lowercase())) {
                options[key]!!.invoke(true)
            } else {
                options[key]!!.invoke(false)
            }
        }
    }
    private var changedAddresses: MutableSet<Int>? = null
    override fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, changedRuns: Ref<List<Int>?>): IStreamRun { /*@DONE PIERun.DeserializeRun/1 cs:330-407*/
        changedRuns.value = ArrayList<Int>()
        changedAddresses = LinkedHashSet<Int>()
        val pairs = content.split(NEW_LINE)
            .filter { line -> line.count { c -> c == '=' } == 1 }
            .map { line -> line.split('=') }
            .map { pair -> Pair(pair[0].trim().lowercase(), pair[1].trim().lowercase()) }
        val scope = createEditScope(token)
        try {
            // check the bytes that everyone has
            for (pair in pairs) {
                val key = pair.first
                val value = pair.second
                val parseBool: Boolean? = if (value == "true") true else if (value == "false") false else null
                val parseInt: Byte? = value.toByteOrNull()
                if (key == "applytofirstpokemononly" && parseBool != null) applyToFirstPokemonOnly = parseBool
                if (key == "requireattackselection" && parseBool != null) requireAttackSelection = parseBool
                if (key == "direhit" && parseInt != null) direHit = parseInt
                if (key == "attackstatincrease" && parseInt != null) attackStatIncrease = parseInt.toInt()
                if (key == "specialattackstatincrease" && parseInt != null) specialAttackStatIncrease = parseInt.toInt()
                if (key == "defensestatincrease" && parseInt != null) defenseStatIncrease = parseInt.toInt()
                if (key == "speedstatincrease" && parseInt != null) speedStatIncrease = parseInt.toInt()
                if (key == "accuracystatincrease" && parseInt != null) accuracyStatIncrease = parseInt.toInt()

                if (key == "general") {
                    val flags = LinkedHashMap<String, (Boolean) -> Unit>()
                    flags["GuardSpec"] = { v -> guardSpec = v }
                    flags["LevelUp"] = { v -> levelUp = v }
                    flags["HealHealth"] = { v -> healHealth = v }
                    flags["HealPowerPoints"] = { v -> healPowerPoints = v }
                    flags["ReviveAndHeal"] = { v -> reviveAndHeal = v }
                    flags["EvolutionStone"] = { v -> evolutionStone = v }
                    readFlagList(value, flags)
                }

                if (key == "clearstat") {
                    val flags = LinkedHashMap<String, (Boolean) -> Unit>()
                    flags["Infatuation"] = { v -> healInfatuation = v }
                    flags["Sleep"] = { v -> clearSleep = v }
                    flags["Poison"] = { v -> clearPoison = v }
                    flags["Burn"] = { v -> clearBurn = v }
                    flags["Ice"] = { v -> clearIce = v }
                    flags["Paralyze"] = { v -> clearParalyze = v }
                    flags["Confusion"] = { v -> clearConfusion = v }
                    readFlagList(value, flags)
                }

                if (key == "increasestat") {
                    val flags = LinkedHashMap<String, (Boolean) -> Unit>()
                    flags["HpEv"] = { v -> increaseHpEv = v }
                    flags["AttackEv"] = { v -> increaseAttackEv = v }
                    flags["DefenseEv"] = { v -> increaseDefenseEv = v }
                    flags["SpecialAttackEv"] = { v -> increaseSpecialAttackEv = v }
                    flags["SpecialDefenseEv"] = { v -> increaseSpecialDefenseEv = v }
                    flags["SpeedEv"] = { v -> increaseSpeedEv = v }
                    flags["MaxPowerPoints"] = { v -> increaseMaxPowerPoints = v }
                    flags["PowerPointsToMax"] = { v -> increasePowerPointsToMax = v }
                    readFlagList(value, flags)
                }

                if (key == "changehappiness") {
                    val flags = LinkedHashMap<String, (Boolean) -> Unit>()
                    flags["Low"] = { v -> changeHappinessWhenLessThan100 = v }
                    flags["Mid"] = { v -> changeHappinessWhenBetween100And199 = v }
                    flags["High"] = { v -> changeHappinessWhenGreaterThan200 = v }
                    readFlagList(value, flags)
                }
            }

            repoint(this)

            // check the bytes that we may have, now that we've possibly been repointed.
            for (pair in pairs) {
                val key = pair.first
                val value = pair.second
                val parseInt: Byte? = value.toByteOrNull()
                val editResult = editScope!!.result
                if (key == "arg" && editResult.hasArg) {
                    if (value == "leveluphealth") editResult.arg = healthRestore_FromLevelUp.toShort()
                    else if (value == "half") editResult.arg = healthRestore_Half.toShort()
                    else if (value == "max") editResult.arg = healthRestore_Max.toShort()
                    else {
                        val parseShort = value.toShortOrNull()
                        if (parseShort != null) editResult.arg = parseShort
                    }
                }

                if (key == "lowhappinesschange" && editResult.hasLowHappinessByte && parseInt != null) editResult.lowHappinessChange = parseInt
                if (key == "midhappinesschange" && editResult.hasMidHappinessByte && parseInt != null) editResult.midHappinessChange = parseInt
                if (key == "highhappinesschange" && editResult.hasHighHappinessByte && parseInt != null) editResult.highHappinessChange = parseInt
            }

            changedOffsets.value = ArrayList<Int>(changedAddresses!!)
            changedAddresses = null
            val result = editScope!!.result
            editScope = null
            return result
        } finally {
            scope.dispose()
        }
    }
    override fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem> { /*@DONE PIERun.GetAutoCompleteOptions/1 cs:409-433*/
        val result = ArrayList<AutocompleteItem>()
        val parts = line.split("=")
        if (parts.size != 2) return result
        val header = parts[0].trim().lowercase()
        val partial = parts[1].replace('{', ' ').replace('}', ' ').trim()
        val caretInValue = caretCharacterIndex - (parts[0].length + 1)
        var beforeText = ""
        var afterText = ""
        if (caretInValue >= 0) {
            val safeCaret = minOf(caretInValue, parts[1].length)
            beforeText = parts[1].substring(0, safeCaret)
            afterText = parts[1].substring(safeCaret)
        }

        tryAdd(result, header, "ApplyToFirstPokemonOnly", partial, "false", "true")
        tryAdd(result, header, "Arg", partial, "LevelUpHealth", "Half", "Max")
        tryAddMulti(result, header, "General", beforeText, afterText,
            "GuardSpec", "LevelUp", "HealHealth", "HealPowerPoints", "ReviveAndHeal", "EvolutionStone")
        tryAddMulti(result, header, "ClearStat", beforeText, afterText,
            "Infatuation", "Sleep", "Poison", "Burn", "Ice", "Paralyze", "Confusion")
        tryAddMulti(result, header, "IncreaseStat", beforeText, afterText,
            "HpEv", "AttackEv", "DefenseEv", "SpecialAttackEv", "SpecialDefenseEv", "SpeedEv", "MaxPowerPoints", "PowerPointsToMax")
        tryAddMulti(result, header, "ChangeHappiness", beforeText, afterText,
            "Low", "Mid", "High")
        return result
    }
    private fun tryAdd(result: MutableList<AutocompleteItem>, header: String, propertyName: String, partial: String, vararg options: String): Boolean { /*@DONE PIERun.TryAdd/1 cs:435-441*/
        if (header != propertyName.lowercase()) return false
        result.addAll(options
            .filter { option -> option.matchesPartial(partial) }
            .map { option -> AutocompleteItem(option, propertyName + " = " + option) })
        return true
    }
    private fun tryAddMulti(result: MutableList<AutocompleteItem>, header: String, propertyName: String, beforeText: String, afterText: String, vararg options: String): Boolean { /*@DONE PIERun.TryAddMulti/1 cs:443-463*/
        if (beforeText.length == 0 && afterText.length == 0) return false
        if (header != propertyName.lowercase()) return false
        var before = beforeText.replace('{', ' ').replace('}', ' ').replace(", ", " ")
        var after = afterText.replace('{', ' ').replace('}', ' ').replace(",", " ")
        val afterTokens = after.split(' ').filter { s -> s.isNotEmpty() }
        after = afterTokens.joinToString(", ")
        if (after.length > 0) after = ", " + after
        val editToken = before.split(' ').last()
        var beforeTokens = before.split(' ').filter { s -> s.isNotEmpty() }
        if (editToken.length > 0) beforeTokens = beforeTokens.take((beforeTokens.size - 1).coerceAtLeast(0))
        before = beforeTokens.joinToString(", ")
        if (before.length > 0) before = " " + before + ","

        result.addAll(options
            .filter { option -> option.matchesPartial(editToken) }
            .filter { option -> !beforeTokens.contains(option) }
            .filter { option -> !afterTokens.contains(option) }
            .map { option -> AutocompleteItem(option, propertyName + " = {" + before + " " + option + after + " }") })
        return true
    }
    override val visualizations: List<IPixelViewModel>
        get() { /*@DONE PIERun.Visualizations.get cs:465-465*/
            return ArrayList<IPixelViewModel>()
        }
    final override var preFormatter: ITextPreProcessor? = null
        private set
    override fun dependsOn(anchorName: String): Boolean { /*@DONE PIERun.DependsOn/1 cs:467-467*/
        return false
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE PIERun.AppendTo/1 cs:469-476*/
        for (i in 0 until length) {
            val index = i + start
            if (index < this.start) continue
            if (index >= this.start + this.length) break
            builder.append(model[index].toHex(2) + " ")
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE PIERun.Clear/1 cs:478-485*/
        for (i in 0 until length) {
            val index = i + start
            if (index < this.start) continue
            if (index >= this.start + this.length) break
            changeToken.changeData(model, index, 0xFF)
        }
    }
    private open class EditScope : IDisposable { // cs:491-499
        var changeToken: ModelDelta? = null
            private set
        lateinit var result: PIERun
        constructor(token: ModelDelta, initialResult: PIERun) { /*@DONE PIERun.EditScope.<init>/1 cs:494-494*/
            this.changeToken = token
            this.result = initialResult
        }
        override fun dispose() { /*@DONE PIERun.EditScope.Dispose/1 cs:495-498*/
            changeToken = null
            result.editScope = null
        }
        /*@END PIERun.EditScope*/
    }
    private var editScope: EditScope? = null
    fun createEditScope(token: ModelDelta): IDisposable { /*@DONE PIERun.CreateEditScope/1 cs:502-505*/
        val newScope = EditScope(token, this)
        editScope = newScope
        return newScope
    }
    fun refresh(token: ModelDelta): PIERun { /*@DONE PIERun.Refresh/1 cs:507-511*/
        val scope = createEditScope(token)
        try {
            acceptChange()
            return editScope!!.result
        } finally {
            scope.dispose()
        }
    }
    private fun getBit(address: Int, bit: Int): Boolean { /*@DONE PIERun.GetBit/1 cs:513-513*/
        return (model[address] and (1 shl bit)) != 0
    }
    private fun setBit(address: Int, bit: Int, value: Boolean) { /*@DONE PIERun.SetBit/1 cs:514-519*/
        val otherBits = model[address] and (1 shl bit).inv()
        val thisBit = if (value) (1 shl bit) else 0
        if (editScope!!.changeToken!!.changeData(model, address, (otherBits or thisBit) and 0xFF)) changedAddresses?.add(address)
        acceptChange()
    }
    private fun acceptChange() { /*@DONE PIERun.AcceptChange/1 cs:521-531*/
        val newRun = PIERun(model, start, pointerSources)
        if (
            newRun._hasLowHappinessByte != _hasLowHappinessByte ||
            newRun._hasMidHappinessByte != _hasMidHappinessByte ||
            newRun._hasHighHappinessByte != _hasHighHappinessByte ||
            newRun.hasArgByte != hasArgByte
        ) {
            repoint(newRun)
        }
    }
    private fun getHigh(address: Int): Int { /*@DONE PIERun.GetHigh/1 cs:533-533*/
        return (model[address] and 0xF0) shr 4
    }
    private fun setHigh(address: Int, value: Int) { /*@DONE PIERun.SetHigh/1 cs:534-538*/
        val low = model[address] and 0xF
        val high = value.limitToRange(0, 15) shl 4
        editScope!!.changeToken!!.changeData(model, address, (high or low) and 0xFF)
    }
    private fun getLow(address: Int): Int { /*@DONE PIERun.GetLow/1 cs:540-540*/
        return model[address] and 0xF
    }
    private fun setLow(address: Int, value: Int) { /*@DONE PIERun.SetLow/1 cs:541-545*/
        val high = model[address] and 0xF0
        val low = value.limitToRange(0, 15)
        editScope!!.changeToken!!.changeData(model, address, (high or low) and 0xFF)
    }
    private fun repoint(newFlags: PIERun) { /*@DONE PIERun.Repoint/1 cs:547-556*/
        val scope = editScope!!
        for (i in 0 until length - newFlags.length) {
            scope.changeToken!!.changeData(model, start + newFlags.length + i, 0xFF)
        }
        val newRun = model.relocateForExpansion(scope.changeToken!!, this, newFlags.length)
        for (i in 0 until newFlags.length - length) {
            scope.changeToken!!.changeData(model, newRun.start + length + i, 0x00)
        }
        val repointed = PIERun(model, newRun.start, newRun.pointerSources)
        repointed.editScope = scope
        scope.result = repointed
    }
    companion object {
        const val sharedFormatString: String = "`pie`"
        const val healthRestore_Max: Byte = -1
        const val healthRestore_Half: Byte = -2
        const val healthRestore_FromLevelUp: Byte = -3
        /*@END PIERun.Companion*/
    }
    /*@ADD PIERun#runs_9.txt*/
    private fun boolText(value: Boolean): String = if (value) "True" else "False"
    private fun addLine(builder: StringBuilder, text: String = "") { builder.append(text).append(NEW_LINE) }
    /*@ENDADD PIERun#runs_9.txt*/
    /*@END PIERun*/
}

open class PIERunContentStrategy : RunStrategy() { // cs:561-584
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE PIERunContentStrategy.LengthForNewRun/1 cs:562-562*/
        return 6
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE PIERunContentStrategy.Matches/1 cs:564-564*/
        return run is PIERun
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE PIERunContentStrategy.TryAddFormatAtDestination/1 cs:566-569*/
        owner.observeRunWritten(token, PIERun(owner, destination, SortedSpan(source)))
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE PIERunContentStrategy.TryParseData/1 cs:571-574*/
        run.value = PIERun(model, dataIndex)
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE PIERunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:576-578*/
        run.value = PIERun(model, run.value.start, run.value.pointerSources)
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE PIERunContentStrategy.WriteNewRun/1 cs:580-583*/
        for (i in 0 until 6) token.changeData(owner, destination + i, 0)
        return PIERun(owner, destination, SortedSpan(source))
    }
    /*@END PIERunContentStrategy*/
}
