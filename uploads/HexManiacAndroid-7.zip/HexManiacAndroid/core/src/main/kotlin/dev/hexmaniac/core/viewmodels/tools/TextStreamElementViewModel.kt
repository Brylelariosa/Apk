// Port of ViewModels/Tools/TextStreamElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.images.*

open class TextStreamElementViewModel : StreamElementViewModel { // cs:6-92
    private var _content: String = ""
    var content: String
        get() { /*@DONE TextStreamElementViewModel.Content.get cs:9-9*/
            return _content
        }
        set(value) { /*@DONE TextStreamElementViewModel.Content.set cs:10-26*/
            if (tryUpdate(_content, value, "content") { _content = it }) {
                ModelCacheScope.createScope(model).using {
                    val destination = model.readPointer(start)
                    val rawRun = model.getNextRun(destination)
                    if (rawRun is IStreamRun) {
                        val changedOffsets = Ref<List<Int>?>(null)
                        val changedRuns = Ref<List<Int>?>(null)
                        val newRun = rawRun.deserializeRun(_content, viewPort.currentChange, changedOffsets, changedRuns)
                        handleNewDataStream(rawRun, newRun, changedOffsets.value ?: ArrayList<Int>(), changedRuns.value)
                    } else if (rawRun is ITableRun) {
                        val proxy = TableStreamRun(model, rawRun.start, rawRun.pointerSources, rawRun.formatString,
                            rawRun.elementContent, FixedLengthStreamStrategy(rawRun.elementCount))
                        val changedOffsets = Ref<List<Int>?>(null)
                        val changedRuns = Ref<List<Int>?>(null)
                        val newRun = proxy.deserializeRun(_content, viewPort.currentChange, changedOffsets, changedRuns)
                        handleNewDataStream(proxy, newRun, changedOffsets.value ?: ArrayList<Int>(), changedRuns.value)
                    }
                }
            }
        }
    val elementContent: TextEditorViewModel = /*@INITDONE TextStreamElementViewModel.ElementContent cs:29-29*/ TextEditorViewModel() /*@ENDINIT*/
    protected fun handleNewDataStream(oldRun: IStreamRun, newRun: IStreamRun, changedOffsets: List<Int>, changedRuns: List<Int>?) { /*@DONE TextStreamElementViewModel.HandleNewDataStream/1 cs:31-54*/
        model.observeRunWritten(viewPort.currentChange, newRun)
        if (oldRun.start != newRun.start) {
            raiseDataMoved(oldRun.start, newRun.start)
        }

        val table = model.getNextRun(newRun.start) as? ITableRun
        if (table != null) {
            for (change in changedOffsets) {
                val offsets = table.convertByteOffsetToArrayOffset(change)
                val info = table.notifyChildren(model, viewPort.currentChange, offsets.elementIndex, offsets.segmentIndex)
                viewPort.handleErrorInfo(info)
            }
        }

        preventSelfCopy().using {
            raiseDataChanged()
        }

        if (changedRuns != null && changedRuns.size > 0) {
            raiseDataMoved(-1, changedRuns[0])
        }

        notifyPropertyChanged("visualizations")
    }
    val visualizations: List<IPixelViewModel>
        get() { /*@DONE TextStreamElementViewModel.Visualizations.get cs:57-63*/
            val destination = model.readPointer(start)
            val run = model.getNextRun(destination)
            if (run is IStreamRun) {
                return run.visualizations
            }
            return ArrayList<IPixelViewModel>()
        }
    constructor(viewPort: ViewPort, parentName: String, start: Int, format: String?) : super(viewPort, parentName, format ?: PCSRun.sharedFormatString, start) { /*@DONE TextStreamElementViewModel.<init>/1 cs:66-81*/
        val destination = viewPort.model.readPointer(start)
        val firstRun = viewPort.model.getNextRun(destination)
        if (firstRun is IStreamRun) {
            _content = firstRun.serializeRun() ?: ""
            elementContent.preFormatter = firstRun.preFormatter
        } else if (firstRun is ITableRun) {
            val proxy = TableStreamRun(model, firstRun.start, firstRun.pointerSources, firstRun.formatString,
                firstRun.elementContent, FixedLengthStreamStrategy(firstRun.elementCount))
            _content = proxy.serializeRun() ?: ""
        } else {
            _content = ""
        }

        elementContent.content = _content
        elementContent.bind("content") { _, _ -> content = elementContent.content }
    }
    protected override fun tryCopy(other: StreamElementViewModel): Boolean { /*@DONE TextStreamElementViewModel.TryCopy/1 cs:83-91*/
        if (javaClass != other.javaClass) return false
        val stream = other as? TextStreamElementViewModel ?: return false
        start = other.start
        tryUpdate(_content, stream._content, "content") { _content = it }
        elementContent.content = content
        notifyPropertyChanged("visualizations")
        return true
    }
    /*@END TextStreamElementViewModel*/
}
