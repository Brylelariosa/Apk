// Port of ViewModels/Tools/ComboBoxArrayElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class ComboOption : INotifyPropertyChanged { // cs:16-34
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    open val displayAsText: Boolean
        get() { /*@DONE ComboOption.DisplayAsText.get cs:18-18*/
            return true
        }
    var text: String = ""
        private set
    var index: Int = 0
        private set
    constructor(text: String, index: Int) { /*@DONE ComboOption.<init>/1 cs:23-23*/
        this.text = text
        this.index = index
    }
    override fun toString(): String { /*@DONE ComboOption.ToString/1 cs:25-25*/
        return text
    }
    companion object {
        fun convert(options: Iterable<String>): Iterable<ComboOption>? { /*@DONE ComboOption.Convert/1 cs:27-33*/
            val result = ArrayList<ComboOption>()
            var count = 0
            for (option in options) {
                result.add(ComboOption(option, count))
                count++
            }
            return result
        }
        /*@END ComboOption.Companion*/
    }
    /*@END ComboOption*/
}

open class VisualComboOption : ComboOption, IPixelViewModel { // cs:36-53
    override val transparent: Short
        get() { /*@DONE VisualComboOption.Transparent.get cs:37-37*/
            return (-1).toShort()
        }
    override var pixelWidth: Int = 0
    override var pixelHeight: Int = 0
    override var pixelData: ShortArray = ShortArray(0)
    override var spriteScale: Double = /*@INITAUTO VisualComboOption.SpriteScale cs:41-41*/ 1.0 /*@ENDINIT*/
    override val displayAsText: Boolean
        get() { /*@DONE VisualComboOption.DisplayAsText.get cs:42-42*/
            return false
        }
    var displayIndex: Boolean = false
        private set
    private constructor(text: String, index: Int) : super(text, index) { /*@DONE VisualComboOption.<init>/1 cs:45-45*/
        pixelData = ShortArray(0)
    }
    companion object {
        fun createFromSprite(text: String, pixelData: ShortArray, width: Int, index: Int, scale: Double = 1.0, displayIndex: Boolean = false): VisualComboOption { /*@DONE VisualComboOption.CreateFromSprite/1 cs:46-52*/
            val option = VisualComboOption(text, index)
            option.pixelData = pixelData
            option.pixelWidth = width
            option.pixelHeight = pixelData.size / width
            option.displayIndex = displayIndex
            option.spriteScale = scale
            return option
        }
        /*@END VisualComboOption.Companion*/
    }
    /*@END VisualComboOption*/
}

open class ComboBoxArrayElementViewModel : ViewModelCore, IMultiEnabledArrayElementViewModel { // cs:55-200
    private var _name: String = ""
    private var enumName: String = ""
    private var _start: Int = 0
    private var _length: Int = 0
    private var _dataChanged: EventHandler? = null
    private var _dataSelected: EventHandler? = null
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    lateinit var viewPort: ViewPort
        private set
    var tableName: String = ""
        private set
    override var name: String
        get() { /*@DONE ComboBoxArrayElementViewModel.Name.get cs:66-66*/
            return _name
        }
        set(value) { /*@DONE ComboBoxArrayElementViewModel.Name.set cs:66-66*/
            tryUpdate(_name, value, "name") { _name = it }
        }
    var start: Int
        get() { /*@DONE ComboBoxArrayElementViewModel.Start.get cs:68-68*/
            return _start
        }
        set(value) { /*@DONE ComboBoxArrayElementViewModel.Start.set cs:68-70*/
            if (!tryUpdate(_start, value, "start") { _start = it }) return
        }
    var length: Int
        get() { /*@DONE ComboBoxArrayElementViewModel.Length.get cs:72-72*/
            return _length
        }
        set(value) { /*@DONE ComboBoxArrayElementViewModel.Length.set cs:72-72*/
            tryUpdate(_length, value, "length") { _length = it }
        }
    lateinit var gotoSource: ICommand
        private set
    val type: ElementContentViewModelType
        get() { /*@DONE ComboBoxArrayElementViewModel.Type.get cs:75-75*/
            return ElementContentViewModelType.ComboBox
        }
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE ComboBoxArrayElementViewModel.Theme.get cs:77-77*/
            return _theme
        }
        set(value) { /*@DONE ComboBoxArrayElementViewModel.Theme.set cs:77-77*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE ComboBoxArrayElementViewModel.IsInError.get cs:78-78*/
            return _errorText != ""
        }
    private var _errorText: String = ""
    override var errorText: String?
        get() { /*@DONE ComboBoxArrayElementViewModel.ErrorText.get cs:82-82*/
            return _errorText
        }
        set(value) { /*@DONE ComboBoxArrayElementViewModel.ErrorText.set cs:83-85*/
            if (tryUpdate(_errorText, value ?: "", "errorText") { _errorText = it }) notifyPropertyChanged("isInError")
        }
    override val zIndex: Int
        get() { /*@DONE ComboBoxArrayElementViewModel.ZIndex.get cs:88-88*/
            return 0
        }
    private var _visible: Boolean = /*@INITAUTO ComboBoxArrayElementViewModel.visible cs:90-90*/ true /*@ENDINIT*/
    override var visible: Boolean
        get() { /*@DONE ComboBoxArrayElementViewModel.Visible.get cs:91-91*/
            return _visible
        }
        set(value) { /*@DONE ComboBoxArrayElementViewModel.Visible.set cs:91-91*/
            set(_visible, value, "visible", { _visible = it })
        }
    var filteringComboOptions: FilteringComboOptions = /*@INITDONE ComboBoxArrayElementViewModel.FilteringComboOptions cs:93-93*/ FilteringComboOptions() /*@ENDINIT*/
        private set
    constructor(viewPort: ViewPort, selection: Selection, name: String, start: Int, length: Int) { /*@DONE ComboBoxArrayElementViewModel.<init>/1 cs:95-151*/
        var fullOptions: MutableList<ComboOption> = ArrayList()
        addSilentChild(filteringComboOptions)
        var selectedIndex = 0
        this.viewPort = viewPort
        _name = name
        _start = start
        _length = length
        val run = viewPort.model.getNextRun(start) as ITableRun
        tableName = viewPort.model.getAnchorFromAddress(-1, run.start)
        val offsets = run.convertByteOffsetToArrayOffset(start)
        var rawSegment = run.elementContent[offsets.segmentIndex]
        if (rawSegment is ArrayRunRecordSegment) rawSegment = rawSegment.createConcrete(viewPort.model, start)
        val segment = rawSegment as ArrayRunEnumSegment
        enumName = segment.enumName
        val optionSource: Lazy<Int> = lazy { calculateOptionSource(enumName) }
        fullOptions = ArrayList(segment.getComboOptions(viewPort.model).toList())
        val modelValue = viewPort.model.readMultiByteValue(start, length) - segment.valueOffset
        if (fullOptions.all { option -> option.index != modelValue }) {
            val newOption = ComboOption(modelValue.toString(), modelValue - segment.valueOffset)
            val insertIndex = fullOptions.count { option -> option.index < newOption.index }
            fullOptions.add(insertIndex, newOption)
            selectedIndex = insertIndex
        } else {
            selectedIndex = fullOptions.indexOfFirst { option -> option.index == modelValue }
        }

        filteringComboOptions.update(fullOptions, selectedIndex)
        val gotoCommand = StubCommand()
        gotoCommand.canExecute = { _ -> optionSource.value != Pointer.null_ }
        gotoCommand.execute = { _ ->
            val currentValue = viewPort.model.readMultiByteValue(this.start, this.length) - segment.valueOffset
            val optionSourceTable = viewPort.model.getNextRun(optionSource.value) as? ITableRun
            val indexSource = if (optionSourceTable != null && currentValue < optionSourceTable.elementCount)
                optionSourceTable.start + optionSourceTable.elementLength * currentValue
            else
                optionSource.value
            selection.gotoAddress(indexSource)
        }
        gotoSource = gotoCommand

        filteringComboOptions.bind("modelValue") { _, _ ->
            if (!copying) {
                val currentRun = viewPort.model.getNextRun(this.start) as ITableRun
                val currentOffsets = currentRun.convertByteOffsetToArrayOffset(this.start)
                var currentRaw = currentRun.elementContent[currentOffsets.segmentIndex]
                if (currentRaw is ArrayRunRecordSegment) currentRaw = currentRaw.createConcrete(viewPort.model, this.start)
                val currentSegment = currentRaw as ArrayRunEnumSegment

                viewPort.model.writeMultiByteValue(this.start, this.length, viewPort.changeHistory.currentChange, filteringComboOptions.modelValue + currentSegment.valueOffset)
                val info = currentRun.notifyChildren(viewPort.model, viewPort.changeHistory.currentChange, currentOffsets.elementIndex, currentOffsets.segmentIndex)
                if (info.hasError && info.isWarning) viewPort.raiseMessage(info.errorMessage ?: "")
                else if (info.hasError) viewPort.raiseError(info.errorMessage ?: "")
                dataChanged(this, EventArgs.empty)
            }
        }
    }
    private var copying: Boolean = /*@INITAUTO ComboBoxArrayElementViewModel.copying cs:153-153*/ false /*@ENDINIT*/
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE ComboBoxArrayElementViewModel.TryCopy/1 cs:154-178*/
        val comboBox = other as? ComboBoxArrayElementViewModel ?: return false
        if (comboBox.filteringComboOptions.allOptions?.firstOrNull()?.displayAsText != filteringComboOptions.allOptions?.firstOrNull()?.displayAsText) {
            return false
        }
        name = comboBox.name
        tableName = comboBox.tableName
        length = comboBox.length
        start = comboBox.start
        visible = comboBox.visible
        scope(copying, true, { copying = it }, { copying = it }).using {
            filteringComboOptions.update(comboBox.filteringComboOptions.allOptions ?: ArrayList<ComboOption>(), comboBox.filteringComboOptions.selectedIndex)
        }

        errorText = comboBox.errorText
        if (enumName != comboBox.enumName) {
            enumName = comboBox.enumName
            gotoSource = comboBox.gotoSource
            notifyPropertyChanged("gotoSource")
        }
        dataChanged.copyFrom(comboBox.dataChanged)
        dataSelected.copyFrom(comboBox.dataSelected)

        return true
    }
    fun focus() { /*@DONE ComboBoxArrayElementViewModel.Focus/1 cs:180-180*/
        dataSelected(this, EventArgs.empty)
    }
    private fun calculateOptionSource(name: String): Int { /*@DONE ComboBoxArrayElementViewModel.CalculateOptionSource/1 cs:182-194*/
        val model = viewPort.model
        val initialGuess = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, name)
        if (initialGuess != Pointer.null_) return initialGuess
        // maybe it's a list?
        val list = Ref<ValidationList?>(null)
        if (!model.tryGetList(name, list)) return Pointer.null_
        // look for tables with length based on that list
        val arrays = model.arrays.filter { array -> array.lengthFromAnchor == name }.toList()
        if (arrays.size != 1) return Pointer.null_

        // there's a single array
        return arrays[0].start
    }
    var filterText: String
        get() { /*@DONE ComboBoxArrayElementViewModel.FilterText.get cs:197-197*/
            return filteringComboOptions.displayText
        }
        set(value) { /*@DONE ComboBoxArrayElementViewModel.FilterText.set cs:197-197*/
            filteringComboOptions.displayText = value
        }
    val options: MutableList<ComboOption>
        get() { /*@DONE ComboBoxArrayElementViewModel.Options.get cs:198-198*/
            return filteringComboOptions.filteredOptions
        }
    var selectedIndex: Int
        get() { /*@DONE ComboBoxArrayElementViewModel.SelectedIndex.get cs:199-199*/
            return filteringComboOptions.selectedIndex
        }
        set(value) { /*@DONE ComboBoxArrayElementViewModel.SelectedIndex.set cs:199-199*/
            filteringComboOptions.selectedIndex = value
        }
    /*@END ComboBoxArrayElementViewModel*/
}
