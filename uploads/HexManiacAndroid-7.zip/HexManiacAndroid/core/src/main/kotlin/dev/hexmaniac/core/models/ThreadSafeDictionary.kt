// Port of Models/ThreadSafeDictionary.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

open class ThreadSafeDictionary<TKey, TValue> { // cs:7-96
    private var keyCache: MutableList<TKey>? = null
    private val inner: MutableMap<TKey, TValue> = /*@INITDONE ThreadSafeDictionary.inner cs:9-9*/ LinkedHashMap() /*@ENDINIT*/
    operator fun get(key: TKey): TValue { /*@DONE ThreadSafeDictionary.this/1.get cs:12-12*/
        synchronized(inner) {
            if (!inner.containsKey(key)) throw NoSuchElementException("The given key was not present in the dictionary.")
            return inner[key] as TValue
        }
    }
    operator fun set(key: TKey, value: TValue) { /*@DONE ThreadSafeDictionary.this/1.set cs:13-18*/
        synchronized(inner) {
            keyCache = null
            inner[key] = value
        }
    }
    val keys: MutableCollection<TKey>
        get() { /*@DONE ThreadSafeDictionary.Keys.get cs:22-27*/
            synchronized(inner) {
                if (keyCache == null) keyCache = ArrayList(inner.keys)
                return keyCache!!
            }
        }
    val values: MutableCollection<TValue>
        get() { /*@DONE ThreadSafeDictionary.Values.get cs:31-31*/
            synchronized(inner) { return ArrayList(inner.values) }
        }
    val count: Int
        get() { /*@DONE ThreadSafeDictionary.Count.get cs:35-35*/
            synchronized(inner) { return inner.size }
        }
    val isReadOnly: Boolean
        get() { /*@DONE ThreadSafeDictionary.IsReadOnly.get cs:38-38*/
            return false
        }
    fun add(key: TKey, value: TValue) { /*@DONE ThreadSafeDictionary.Add/1 cs:40-45*/
        synchronized(inner) {
            keyCache = null
            if (inner.containsKey(key)) throw ArgumentException("An item with the same key has already been added.")
            inner[key] = value
        }
    }
    fun add(item: Map.Entry<TKey, TValue>) { /*@DONE ThreadSafeDictionary.Add/2 cs:47-52*/
        synchronized(inner) {
            keyCache = null
            if (inner.containsKey(item.key)) throw ArgumentException("An item with the same key has already been added.")
            inner[item.key] = item.value
        }
    }
    fun clear() { /*@DONE ThreadSafeDictionary.Clear/1 cs:54-59*/
        synchronized(inner) {
            keyCache = null
            inner.clear()
        }
    }
    fun contains(item: Map.Entry<TKey, TValue>): Boolean { /*@DONE ThreadSafeDictionary.Contains/1 cs:61-63*/
        synchronized(inner) { return inner.containsKey(item.key) && inner[item.key] == item.value }
    }
    fun containsKey(key: TKey): Boolean { /*@DONE ThreadSafeDictionary.ContainsKey/1 cs:65-67*/
        synchronized(inner) { return inner.containsKey(key) }
    }
    fun copyTo(array: Array<Map.Entry<TKey, TValue>>, arrayIndex: Int) { /*@DONE ThreadSafeDictionary.CopyTo/1 cs:69-71*/
        synchronized(inner) {
            var i = arrayIndex
            for (entry in inner.entries) array[i++] = entry
        }
    }
    fun getEnumerator(): Iterator<Map.Entry<TKey, TValue>> { /*@DONE ThreadSafeDictionary.GetEnumerator/1 cs:73-75*/
        synchronized(inner) { return inner.entries.iterator() }
    }
    fun remove(key: TKey): Boolean { /*@DONE ThreadSafeDictionary.Remove/1 cs:77-82*/
        synchronized(inner) {
            keyCache = null
            if (!inner.containsKey(key)) return false
            inner.remove(key)
            return true
        }
    }
    fun remove(item: Map.Entry<TKey, TValue>): Boolean { /*@DONE ThreadSafeDictionary.Remove/2 cs:84-89*/
        synchronized(inner) {
            keyCache = null
            if (!inner.containsKey(item.key) || inner[item.key] != item.value) return false
            inner.remove(item.key)
            return true
        }
    }
    fun tryGetValue(key: TKey, value: Ref<TValue>): Boolean { /*@DONE ThreadSafeDictionary.TryGetValue/1 cs:91-93*/
        synchronized(inner) {
            if (!inner.containsKey(key)) return false
            value.value = inner[key] as TValue
            return true
        }
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@ADD ThreadSafeDictionary#util_1.txt*/
    operator fun iterator(): Iterator<Map.Entry<TKey, TValue>> = getEnumerator()
    /*@ENDADD ThreadSafeDictionary#util_1.txt*/
    /*@END ThreadSafeDictionary*/
}
