// Port of ViewModels/QuickEditItems/AddTilesetAnimation.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class AddTilesetAnimation : IQuickEditItem { // cs:9-219
    private lateinit var fileSystem: IFileSystem
    override val name: String?
        get() { /*@DONE AddTilesetAnimation.Name.get cs:12-12*/
            return "Add Tileset Animation"
        }
    override val description: String?
        get() { /*@DONE AddTilesetAnimation.Description.get cs:14-16*/
            return "Add a new table and code for adding animations to a map tileset." + NEW_LINE +
                "Look for your new table with the name `graphics.maps.tilesets.animations. <something>.table`." + NEW_LINE +
                "Look for your new animation routine with the name `graphics.maps.tilesets.animations. <something>.init`."
        }
    override val wikiLink: String?
        get() { /*@DONE AddTilesetAnimation.WikiLink.get cs:18-18*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Tileset-Animations-Explained"
        }
    override val canRunChanged = Event<EventArgs>()
    constructor(fileSystem: IFileSystem) { /*@DONE AddTilesetAnimation.<init>/1 cs:22-22*/
        this.fileSystem = fileSystem
    }
    override fun canRun(viewPort: IViewPort): Boolean { /*@DONE AddTilesetAnimation.CanRun/1 cs:24-26*/
        return viewPort is IEditableViewPort && viewPort.model?.getGameCode() == "BPRE0"
    }
    override fun run(viewPort: IViewPort): Task<ErrorInfo>? { /*@DONE AddTilesetAnimation.Run/1 cs:28-56*/
        val model = viewPort.model ?: return Task.fromResult(ErrorInfo.noError)
        val token = viewPort.changeHistory.currentChange
        val requestedName: String? = fileSystem.requestText("New Animation Anchor Name", "Choose a short name for the new animation (no spaces or special characters)")
        if (requestedName == null) return Task.fromResult(ErrorInfo.noError)
        val name = sanitizeName(viewPort, requestedName)
        val newTableName = Ref("graphics.maps.tilesets.animations." + name + ".table")
        val tableAddress = model.findFreeSpace(model.freeSpaceStart, 16) + 4
        PokemonModel.uniquifyName(model, tableAddress, newTableName)

        // insert data/metadata for new table
        model.writePointer(token, tableAddress - 4, Pointer.null_) // null pointer for the first animation
        model.writePointer(token, tableAddress, tableAddress - 4) // pointer to the child
        model.writeMultiByteValue(tableAddress + 4, 2, token, 1)  // 1 frame
        model.writeMultiByteValue(tableAddress + 6, 1, token, 4)  // timer is 1<<4 -> 16
        model.writeMultiByteValue(tableAddress + 7, 1, token, 1)  // 1 tile
        model.writeMultiByteValue(tableAddress + 8, 4, token, 0)  // tile offset
        model.writeMultiByteValue(tableAddress + 12, 4, token, -1 - 0x01010101) // FEFEFEFE as the end token

        // `mat`=[frame<`uct4xn`>]/frames
        val tableRun = Ref<ITableRun?>(null)
        val error = ArrayRun.tryParse(model, "[animations<`mat`> frames: timer. tiles. tileOffset::]!FEFEFEFE", tableAddress, SortedSpan.none<Int>(), tableRun)
        val parsedRun = tableRun.value
        if (parsedRun != null) model.observeAnchorWritten(token, newTableName.value, parsedRun)

        val callbackAddress = insertCallback(viewPort, "graphics.maps.tilesets.animations." + name + ".callback", tableAddress)
        val initAddress = insertInit(viewPort, "graphics.maps.tilesets.animations." + name + ".init", tableAddress, callbackAddress)

        viewPort.goto?.execute(tableAddress)
        return Task.fromResult(ErrorInfo.noError)
    }
    private fun sanitizeName(viewPort: IViewPort, name: String): String { /*@DONE AddTilesetAnimation.SanitizeName/1 cs:61-67*/
        val characters = ArrayList<Char>(name.filter { ch -> ch.isLetterOrDigit() }.toList())
        if (characters.size == 0) characters.addAll("temp".toList())
        val candidate = Ref(String(characters.toCharArray()).lowercase())
        val model = viewPort.model
        if (model != null) PokemonModel.uniquifyName(model, model.freeSpaceStart, candidate)
        return candidate.value
    }
    private fun insertCallback(viewPort: IViewPort, callbackName: String, tableAddress: Int): Int { /*@DONE AddTilesetAnimation.InsertCallback/1 cs:69-148*/
        val model = viewPort.model ?: throw IllegalStateException("No data is loaded.")
        val gamecode = model.getGameCode()
        val mod = when (gamecode) {
            "BPRE0" -> 0x1E4684
            else -> throw NotImplementedException()
        }
        val appendTilesetAnimToBuffer = when (gamecode) {
            "BPRE0" -> 0x06FF04
            else -> throw NotImplementedException()
        }

        val token = viewPort.changeHistory.currentChange
        val compiler = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")
        val start = model.findFreeSpace(model.freeSpaceStart, 0x80)

        val code = """
        push {r4-r7, lr}

        ldr   r4, =<${tableAddress.toHex(6)}>  @ r4 is the item
        sub   r4, #12
        ldr   r5, =0xFEFEFEFE           @ r5 is the end token
        mov   r6, r0                    @ r6 is the timer
                                        @ r7 is reserved for long branch-link
        loop:
          add  r4, #12

          @ if end of table, break
          ldr  r0, [r4, #0] @ check end of table
          cmp  r0, r5
          beq  <end>

          @ verify that timer is a multiple of the proper power of 2 (item.timer)
          mov  r0, #1
          ldrb r1, [r4, #6] @ item.timer
          lsl  r0, r1
          sub  r0, #1
          and  r0, r6
          cmp  r0, #0
          bne  <loop>

          @ arg0 = the current animation frame graphics
          mov  r0, r6
          lsr  r0, r1
          ldrh r1, [r4, #4] @ item.frames
          ldr  r7, =<${mod.toHex(6)}>
          bl   <long_branch>                   @ r0 %= r1
          lsl  r0, #2
          ldr  r2, [r4, #0] @ item.frame
          ldr  r0, [r2, r0]

          @ arg1 = the address to apply the tiles, in RAM
          ldr  r1, [r4, #8] @ item.tileOffset
          lsl  r1, #5
          ldr  r2, =0x6000000
          add  r1, r2

          @ arg2 = the number of bytes to copy from ROM to RAM
          ldrb r2, [r4, #7] @ item.tiles
          lsl  r2, #5

          @ AppendTilesetAnimToBuffer(arg0, arg1, arg2)
          ldr  r7, =<${appendTilesetAnimToBuffer.toHex(6)}>
          bl   <long_branch>
          b    <loop>

        end:
        pop  {r4-r7, pc}
        long_branch:
          add r7, #1
          bx r7
        """

        compiler.compile(token, model, start, *code.splitLines())

        val uniqueName = Ref(callbackName)
        PokemonModel.uniquifyName(model, start, uniqueName)
        model.observeAnchorWritten(token, uniqueName.value, NoInfoRun(start + 1))

        return start
    }
    private fun insertInit(viewPort: IViewPort, initName: String, tableAddress: Int, callbackAddress: Int): Int { /*@DONE AddTilesetAnimation.InsertInit/1 cs:150-216*/
        // TODO verify that these are the same in every game
        val sPrimaryTilesetAnimCounter = 0x03000FAE
        val sPrimaryTilesetAnimCounterMax = 0x03000FB0
        val sPrimaryTilesetAnimCallback = 0x03000FB8

        // animations<[frame<`uct4`>]/frames> frames: timer. tiles. tileOffset::

        val model = viewPort.model ?: throw IllegalStateException("No data is loaded.")
        val token = viewPort.changeHistory.currentChange
        val compiler = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")
        val start = model.findFreeSpace(model.freeSpaceStart, 0x80)
        val code = """
        push {lr}

        @ sPrimaryTilesetAnimCounter = 0
        ldr   r0, =0x${sPrimaryTilesetAnimCounter.toHex(8)}
        mov   r1, #0
        strh  r1, [r0, #0]

        @ sPrimaryTilesetAnimCounterMax = 1 << table.Max(.timer)
        ldr   r2, =0x08${tableAddress.toHex(6)}
        sub   r2, #12
        ldr   r3, =0xFEFEFEFE
        loop1:
          add  r2, #12
          ldr  r0, [r2, #0]
          cmp  r0, r3
          beq  <done_loop1>
          ldrb r0, [r2, #6]
          cmp  r0, r1
          blt  <loop1>
          mov  r1, r0
        done_loop1:
        mov   r0, #1
        lsl   r0, r1
        mov   r1, r0

        @ sPrimaryTilesetAnimCounterMax *= table.Each(.frames)
        ldr   r2, =0x08${tableAddress.toHex(6)}
        sub   r2, #12
        loop2:
          add  r2, #12
          ldr  r0, [r2, #0]
          cmp  r0, r3
          beq  <done_loop2>
          ldrh r0, [r2, #4]
          mul  r1, r0
          b <loop2>
        done_loop2:
        ldr   r0, =0x${sPrimaryTilesetAnimCounterMax.toHex(8)}
        strh  r1, [r0, #0]

        @ sPrimaryTilesetAnimCallback = TilesetAnim_Custom
        ldr   r0, =0x${sPrimaryTilesetAnimCallback.toHex(8)}
        ldr   r1, =<${(callbackAddress + 1).toHex(6)}>
        str   r1, [r0, #0]

        pop   {pc}
        """ // 45

        compiler.compile(token, model, start, *code.splitLines())
        val uniqueName = Ref(initName)
        PokemonModel.uniquifyName(model, start, uniqueName)
        model.observeAnchorWritten(token, uniqueName.value, NoInfoRun(start + 1))

        return start
    }
    override fun tabChanged() { /*@DONE AddTilesetAnimation.TabChanged/1 cs:218-218*/
        canRunChanged(this, EventArgs.empty)
    }
    /*@END AddTilesetAnimation*/
}
