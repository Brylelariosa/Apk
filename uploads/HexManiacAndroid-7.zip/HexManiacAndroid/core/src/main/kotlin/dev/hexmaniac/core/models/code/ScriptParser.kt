// Port of Models/Code/ScriptParser.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.code

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.factory.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*

data class ScriptErrorInfo(val message: String, val segment: TextSegment) { // cs:19-19
    /*@END ScriptErrorInfo*/
}

open class ScriptParser { // cs:21-967
    private var engine: List<IScriptLine> = ArrayList()
    private var endToken: Int = 0
    private var gameHash: Int = 0
    var requireCompleteAddresses: Boolean = /*@INITAUTO ScriptParser.RequireCompleteAddresses cs:27-27*/ true /*@ENDINIT*/
    val compileError = Event<ScriptErrorInfo>()
    constructor(gameHash: Int, engine: List<IScriptLine>, endToken: Int) { /*@DONE ScriptParser.<init>/1 cs:31-34*/
        this.engine = engine
        this.endToken = endToken
        this.gameHash = gameHash
    }
    fun refreshGameHash(model: IDataModel) { /*@DONE ScriptParser.RefreshGameHash/1 cs:36-36*/
        gameHash = model.getShortGameCode()
    }
    fun getScriptSegmentLength(model: IDataModel, address: Int): Int { /*@DONE ScriptParser.GetScriptSegmentLength/1 cs:38-38*/
        return engine.getScriptSegmentLength(gameHash, model, address, LinkedHashMap())
    }
    fun parse(data: IDataModel, start: Int, length: Int, existingSectionCount: Ref<Int>, updateBody: CodeBody? = null): String { /*@DONE ScriptParser.Parse/1 cs:40-44*/
        val builder = StringBuilder()
        for (line in decompile(data, start, length, updateBody, existingSectionCount)) builder.appendLine(line)
        return builder.toString()
    }
    fun collectScripts(model: IDataModel, address: Int): MutableList<Int> { /*@DONE ScriptParser.CollectScripts/1 cs:46-163*/
        // do some basic validation to make sure this is actually a reasonable thing to decode
        var address = address
        val currentRun = model.getNextRun(address) ?: NoInfoRun.nullRun
        val scripts = ArrayList<Int>()
        if (address < 0 || address >= model.count) return scripts
        if (currentRun.start < address) return scripts
        if (currentRun.start == address && currentRun !is IScriptStartRun && currentRun !is NoInfoRun) return scripts

        scripts.add(address)
        val lengths = ArrayList<Int>()

        var i = -1
        while (true) {
            i++
            if (i >= scripts.size) break
            while (i < scripts.size && (0 until i).any { j -> scripts[j] <= scripts[i] && scripts[i] < scripts[j] + lengths.getOrElse(j) { 0 } }) scripts.removeAt(i)
            if (i == scripts.size) break
            address = scripts[i]
            var length = 0
            val destinations = LinkedHashMap<Int, Int>()
            var lastCommand = -1
            var repeateLength = 0
            while (true) {
                val line = engine.getMatchingLine(gameHash, model, address + length) ?: break
                // normally we would just use this,
                // but we want to track all the pointers that go to scripts separately.
                // so just use this to get the child-sizes, so we can adjust the length after
                line.compiledByteLength(model, address + length, destinations)
                length += line.lineCode.count
                for (arg in line.args) {
                    if (arg.type == ArgType.Pointer) {
                        val destination = model.readPointer(address + length)
                        if (destination >= 0 && destination < model.count &&
                            arg.pointerType == ExpectedPointerType.Script &&
                            !scripts.contains(destination) &&
                            (0 until i).all { j -> destination < scripts[j] || scripts[j] + lengths.getOrElse(j) { 0 } <= destination }
                        ) {
                            scripts.add(destination)
                        }
                    }
                    length += arg.length(model, address + length)
                }
                if (line.isEndingCommand) break

                if (line.lineCode[0] != lastCommand) {
                    lastCommand = line.lineCode[0]
                    repeateLength = 1
                } else {
                    repeateLength += 1
                }
                if (line.args.size > 0) repeateLength = 0
                if (repeateLength > maxRepeates) break // same command lots of times in a row is fishy
            }

            // append child scripts that come directly after this script
            while (true) {
                // child script starts directly after this script and has only one source
                var childLength = destinations[address + length]
                if (childLength != null && childLength > 0) {
                    val anchor = model.getNextAnchor(address + length)
                    if (anchor.start == address + length && (anchor.pointerSources?.size ?: 0) == 1) {
                        length += childLength
                        continue
                    }
                }
                // child script has a 1-byte margin (probably an end after a goto) and has only one source
                childLength = destinations[address + length + 1]
                if (childLength != null) {
                    // there was a skip... should we ignore it?
                    // If something points to that position, we can't keep going.
                    var anchor = model.getNextAnchor(address + length)
                    if (anchor.start == address + length && (anchor.pointerSources?.size ?: 0) > 0) break

                    anchor = model.getNextAnchor(address + length + 1)
                    if (anchor.start == address + length + 1 && (anchor.pointerSources?.size ?: 0) == 1) {
                        length += childLength + 1
                        continue
                    }
                }
                // child script has a 2-byte margin (probably aligned mart data) and has only one source
                childLength = destinations[address + length + 2]
                if (childLength != null) {
                    // there was a skip... should we ignore it?
                    // If something points to that position, we can't keep going.
                    var anchor = model.getNextAnchor(address + length)
                    if (anchor.start == address + length && (anchor.pointerSources?.size ?: 0) > 0) break

                    anchor = model.getNextAnchor(address + length + 2)
                    if (anchor.start == address + length + 2 && (anchor.pointerSources?.size ?: 0) == 1 && anchor !is IScriptStartRun) {
                        length += childLength + 2
                        continue
                    }
                }
                // child script has a 3-byte margin (probably aligned mart data) and has only one source
                childLength = destinations[address + length + 3]
                if (childLength != null) {
                    // there was a skip... should we ignore it?
                    // If something points to that position, we can't keep going.
                    var anchor = model.getNextAnchor(address + length)
                    if (anchor.start == address + length && (anchor.pointerSources?.size ?: 0) > 0) break

                    anchor = model.getNextAnchor(address + length + 3)
                    if (anchor.start == address + length + 3 && (anchor.pointerSources?.size ?: 0) == 1 && anchor !is IScriptStartRun) {
                        length += childLength + 3
                        continue
                    }
                }
                break
            }

            lengths.add(length)
            for (j in lengths.size - 1 downTo 0) {
                if (scripts[j] <= address || scripts[j] >= address + length) continue
                lengths.removeAt(j)
                scripts.removeAt(j)
                i--
            }

            // look for other scripts from destinations that we should care about but don't yet
            for (d in ArrayList(destinations.keys)) {
                if (scripts.contains(d)) continue // destination is already in queue
                val scriptStart = model.getNextRun(d)
                if (scriptStart !is IScriptStartRun || scriptStart.start != d) continue // destination isn't formatted as a script
                if ((0 until lengths.size).any { j -> scripts[j] <= d && d < scripts[j] + lengths[j] }) continue // destination is included within exsting script
                scripts.add(d)
            }
        }

        return scripts
    }
    fun findLength(model: IDataModel, address: Int, destinations: MutableMap<Int, Int>? = null): Int { /*@DONE ScriptParser.FindLength/1 cs:165-213*/
        val destinations = destinations ?: model.currentCacheScope.scriptDestinations(address)
        var length = 0
        var consecutiveNops = 0
        var lastCommand = -1
        var repeateLength = 1
        while (true) {
            val line = engine.getMatchingLine(gameHash, model, address + length) ?: break
            consecutiveNops = if (line.lineCommand.startsWith("nop")) consecutiveNops + 1 else 0
            if (consecutiveNops > 16) return 0
            length += line.compiledByteLength(model, address + length, destinations)
            if (line.isEndingCommand) break

            if (line.lineCode[0] != lastCommand) {
                lastCommand = line.lineCode[0]
                repeateLength = 1
            } else {
                repeateLength += 1
            }
            if (line.args.size > 0) repeateLength = 0
            if (repeateLength > ScriptParser.maxRepeates) break // same command lots of times in a row is fishy
        }

        // concatenate destinations directly after the current script
        // (only if the destination is only used once)
        val initialAnchor = model.getNextAnchor(address + length)
        var consolidateAgain = true
        while (consolidateAgain) {
            consolidateAgain = false
            for (i in 0 until 4) {
                // we want to know if there's more script content detected closely after this script, with a possible gap of a few bytes
                // go ahead and concatenate that content onto this script segment if nothing is using the space between.
                var argLength = destinations[address + length + i]
                if (argLength != null && argLength > 0) {
                    if (i == 1 && initialAnchor.start == address + length && (initialAnchor.pointerSources?.size ?: 0) > 0) break
                    val spacedAnchor = model.getNextAnchor(address + length + i)
                    if (spacedAnchor.start == address + length + i && (spacedAnchor.pointerSources?.size ?: 0) == 1) {
                        // if the argLength is 1, we may've skipped finding the length to prevent recursion.
                        // Now that we know more lengths, go ahead and try to calculate it.
                        if (argLength == 1 && spacedAnchor is IScriptStartRun) {
                            destinations.remove(address + length + i)
                            argLength = model.getScriptLength(spacedAnchor, destinations)
                            destinations[address + length + i] = argLength
                        }

                        length += argLength + i
                        consolidateAgain = true
                        break
                    }
                }
            }
        }

        return length
    }
    fun getMacro(model: IDataModel, address: Int): MacroScriptLine? { /*@DONE ScriptParser.GetMacro/1 cs:215-215*/
        return engine.getMatchingMacro(gameHash, model, address)
    }
    fun getLine(model: IDataModel, address: Int): ScriptLine? { /*@DONE ScriptParser.GetLine/1 cs:216-216*/
        return engine.getMatchingLine(gameHash, model, address)
    }
    private var tableDependencyCache: MutableMap<String, MutableList<IScriptLine>> = /*@INITDONE ScriptParser.tableDependencyCache cs:219-219*/ LinkedHashMap() /*@ENDINIT*/
    fun dependsOn(basename: String): Iterable<IScriptLine> { /*@DONE ScriptParser.DependsOn/1 cs:221-233*/
        synchronized(tableDependencyCache) {
            val cached = tableDependencyCache[basename]
            if (cached != null) return cached
        }
        val matches = ArrayList<IScriptLine>()
        for (line in engine) {
            for (arg in line.args) {
                if (arg.enumTableName == basename) {
                    matches.add(line)
                    break
                }
            }
        }
        synchronized(tableDependencyCache) {
            tableDependencyCache[basename] = matches
        }
        return matches
    }
    private var constantCache: MutableSet<String>? = null
    private var keywordCache: MutableSet<String>? = null
    fun addKeywords(model: IDataModel, body: CodeBody) { /*@DONE ScriptParser.AddKeywords/1 cs:236-263*/
        val editor = body.editor
        editor.lineCommentHeader = "#"
        editor.multiLineCommentHeader = "/*"
        editor.multiLineCommentFooter = "*/"
        var constants = constantCache
        var keywords = keywordCache
        if (constants == null || keywords == null) {
            constants = LinkedHashSet()
            keywords = LinkedHashSet()
            constantCache = constants
            keywordCache = keywords
            for (line in engine) {
                if (!line.matchesGame(gameHash)) continue
                keywords.add(line.lineCommand)
                for (arg in line.args) {
                    val enumName = arg.enumTableName
                    if (enumName.isNullOrEmpty()) continue
                    for (option0 in model.getOptions(enumName)) {
                        val option: String? = option0 // option lists may contain null entries (unnamed values)
                        if (option == null) continue
                        if ("<>!=?".any { c -> option.contains(c) }) continue
                        constants.add(option)
                    }
                }
            }
        }

        editor.constants.clear()
        editor.constants.addRange(constants)
        editor.keywords.clear()
        editor.keywords.addRange(keywords)
        editor.keywords.add("auto") // for the auto-pointer feature
    }
    fun clearConstantCache() { /*@DONE ScriptParser.ClearConstantCache/1 cs:265-267*/
        constantCache = null
    }
    inline fun <reified SERun : IScriptStartRun> formatScript(token: ModelDelta, model: IDataModel, address: Int, minLength: Int = 0): MutableMap<Int, Int>? { /*@DONE ScriptParser.FormatScript/1 cs:271-352*/
        return formatScriptImpl(SERun::class.java, token, model, address, minLength)
    }
    private fun writeTextStream(model: IDataModel, token: ModelDelta, destination: Int, source: Int) { /*@DONE ScriptParser.WriteTextStream/1 cs:354-372*/
        if (destination < 0 || destination > model.count) return
        val destinationLength = PCSString.readString(model, destination, true)
        if (destinationLength > 0) {
            // if there's an anchor that starts exactly here, we don't want to clear it: just update it
            // if the run starts somewhere else, we better to a clear to prevent conflicting formats
            val existingTextRun = model.getNextRun(destination) ?: NoInfoRun.nullRun
            if (existingTextRun.start != destination) {
                model.clearFormat(token, destination, destinationLength)
                model.observeRunWritten(token, PCSRun(model, destination, destinationLength, SortedSpanStatic.one(source)))
            } else if (existingTextRun is PCSRun && destinationLength == existingTextRun.length) {
                // length and format is correct, nothing to do
            } else {
                model.clearAnchor(token, destination + existingTextRun.length, destinationLength - existingTextRun.length) // assuming that the old run ends before the new run, clear the difference
                model.observeRunWritten(token, PCSRun(model, destination, destinationLength, SortedSpanStatic.one(source)))
                model.clearAnchor(token, destination + destinationLength, existingTextRun.length - destinationLength) // assuming that the new run ends before the old run, clear the difference
            }
        }
    }
    private fun writeMovementStream(model: IDataModel, token: ModelDelta, start: Int, source: Int) { /*@DONE ScriptParser.WriteMovementStream/1 cs:374-377*/
        val format = "[move.movementtypes]!FE"
        writeStream(model, token, start, source, format)
    }
    fun writeMartStream(model: IDataModel, token: ModelDelta, start: Int, source: Int) { /*@DONE ScriptParser.WriteMartStream/1 cs:379-382*/
        val format = "[item:" + HardcodeTablesModel.itemsTableName + "]!0000"
        writeStream(model, token, start, source, format)
    }
    fun writeDecorStream(model: IDataModel, token: ModelDelta, start: Int, source: Int) { /*@DONE ScriptParser.WriteDecorStream/1 cs:384-387*/
        val format = "[item:" + HardcodeTablesModel.decorationsTableName + "]!0000"
        writeStream(model, token, start, source, format)
    }
    private fun writeSpriteTemplateStream(model: IDataModel, token: ModelDelta, start: Int, source: Int) { /*@DONE ScriptParser.WriteSpriteTemplateStream/1 cs:389-392*/
        val format = "[tileTag: paletteTag: oam<> anims<> images<> affineAnims<> callback<>]1"
        writeStream(model, token, start, source, format)
    }
    private fun writeStream(model: IDataModel, token: ModelDelta, start: Int, source: Int, format: String) { /*@DONE ScriptParser.WriteStream/1 cs:394-415*/
        val sources: SortedSpan<Int> = if (source >= 0) SortedSpanStatic.one(source) else SortedSpan.none<Int>()
        val tsRunRef = Ref<TableStreamRun?>(null)
        TableStreamRun.tryParseTableStream(model, start, sources, "", format, null, tsRunRef)
        var tsRun = tsRunRef.value
        if (tsRun != null) {
            val endTokenLength = tsRun.length - tsRun.elementLength * tsRun.elementCount
            val existingRun = model.getNextRun(tsRun.start)
            if (endTokenLength > 0 && model.isFreespace(start, endTokenLength) && token !is NoDataChangeDeltaModel) {
                // freespace: write the end token
                model.clearFormat(token, tsRun.start, endTokenLength)
                tsRun = tsRun.deserializeRunFromZero("", token, Ref<List<Int>?>(null), Ref<MutableList<Int>?>(null))
                model.observeRunWritten(token, tsRun)
            } else if (existingRun is ITableRun && existingRun.start == tsRun.start && tsRun.dataFormatMatches(existingRun)) {
                // no need to update the format, the format already matches what we want
            } else {
                model.clearFormat(token, tsRun.start, tsRun.length)
                if (tsRun.elementCount == 0) {
                    // write the end token
                    tsRun.deserializeRun("", token, Ref<List<Int>?>(null), Ref<List<Int>?>(null))
                }
                model.observeRunWritten(token, tsRun)
            }
        }
    }
    private data class StreamInfo(val pointerType: ExpectedPointerType, val source: Int, val destination: Int) { // cs:417-417
        /*@END ScriptParser.StreamInfo*/
    }
    fun compileWithoutErrors(token: ModelDelta, model: IDataModel, scriptStart: Int, script: Ref<String>): ByteArray? { /*@DONE ScriptParser.CompileWithoutErrors/1 cs:494-502*/
        val errors = ArrayList<ScriptErrorInfo>()
        val handler: (Any?, ScriptErrorInfo) -> Unit = { _, info -> errors.add(info) }
        compileError += handler
        val content = compile(token, model, scriptStart, script, Ref<List<ScriptParserCompileMovedDataTuple>?>(null), Ref(0))
        compileError -= handler
        return content
    }
    fun compile(token: ModelDelta, model: IDataModel, start: Int, script: Ref<String>, movedData: Ref<List<ScriptParserCompileMovedDataTuple>?>, ignoreCharacterCount: Ref<Int>): ByteArray? { /*@DONE ScriptParser.Compile/1 cs:504-507*/
        val ignoreCaret = Ref(0)
        return compile(token, model, start, script, ignoreCaret, null, movedData, ignoreCharacterCount)
    }
    fun compile(token: ModelDelta, model: IDataModel, start: Int, script: Ref<String>, caret: Ref<Int>, updateBody: CodeBody?, movedData: Ref<List<ScriptParserCompileMovedDataTuple>?>, ignoreCharacterCount: Ref<Int>): ByteArray? { /*@DONE ScriptParser.Compile/2 cs:516-684*/
        ignoreCharacterCount.value = 0
        val moved = ArrayList<ScriptParserCompileMovedDataTuple>()
        movedData.value = moved
        val deferredContent = ArrayList<DeferredStreamToken>()
        val adjustCaret = insertMissingClosers(script, caret.value)
        caret.value += adjustCaret
        val streamTypes = ArrayList<ExpectedPointerType>()
        val lines: Array<String> = script.value.split("\r\n", "\r", "\n").map { it.substringBefore('#') }.toTypedArray()
        val result = ArrayList<Int>()
        val streamInfo = ArrayList<StreamInfo>()

        val labels = extractLocalLabels(model, start, lines)

        var lastCommandIsEndCommand = false

        var i = -1
        while (true) {
            i++
            if (i >= lines.size) break
            if (lines[i].isBlank()) continue
            var line = lines[i].trim()
            if (line.endsWith(":")) continue // label, not code. Don't parse.
            if (line == "{") {
                val streamStart = i + 1
                var indentCount = 1
                i += 1
                while (indentCount > 0 && lines.size > i) {
                    line = lines[i].trim()
                    if (line == "{") indentCount += 1
                    if (line == "}") indentCount -= 1
                    i += 1
                }
                i -= 1
                val streamEnd = i
                val streamLines = lines.drop(streamStart).take(Math.max(0, streamEnd - streamStart))
                val stream = streamLines.joinToString("\n")

                // Let the stream run handle updating itself based on the stream content.
                if (streamInfo.size > 0) {
                    val info = streamInfo[0]
                    streamTypes.add(info.pointerType)
                    if (info.destination == DeferredStreamToken.autoSentinel + Pointer.null_) {
                        val deferred = deferredContent[deferredContent.size - streamInfo.size]
                        deferred.updateContent(model, info.pointerType, stream)
                    } else {
                        val streamRun = model.getNextRun(info.destination)
                        if (streamRun is IStreamRun && streamRun.start == info.destination) {
                            val newStreamRun = streamRun.deserializeRun(stream, token, Ref<List<Int>?>(null), Ref<List<Int>?>(null)) // we don't notify parents/children based on script-stream changes: we know they never have parents/children.
                            // alter script content and compiled byte location based on stream move
                            if (newStreamRun.start != info.destination) {
                                script.value = script.value.replace(info.destination.toAddress(), newStreamRun.start.toAddress())
                                result[info.source - start + 0] = (newStreamRun.start shr 0) and 0xFF
                                result[info.source - start + 1] = (newStreamRun.start shr 8) and 0xFF
                                result[info.source - start + 2] = (newStreamRun.start shr 16) and 0xFF
                                result[info.source - start + 3] = ((newStreamRun.start shr 24) + 0x08) and 0xFF
                                moved.add(ScriptParserCompileMovedDataTuple(info.destination, newStreamRun.start))
                            }
                            if (newStreamRun !== streamRun) model.observeRunWritten(token, newStreamRun)
                        }
                    }
                    streamInfo.removeAt(0)
                }
                continue
            }
            streamInfo.clear()

            val command = firstMatch(line)
            if (command != null) {
                val currentSize = result.size

                if (line.contains("<??????>")) {
                    var newAddress = -1
                    if (command.args.any { arg -> arg.pointerType == ExpectedPointerType.Movement }) {
                        if (model.freeSpaceStart == start) model.freeSpaceStart += model.freeSpaceBuffer
                        newAddress = model.findFreeSpace(0, 0x10)
                        token.changeData(model, newAddress, 0xFE)
                        writeMovementStream(model, token, newAddress, -1)
                    } else if (command.args.any { arg -> arg.pointerType == ExpectedPointerType.Text }) {
                        newAddress = model.findFreeSpace(0, 0x10)
                        if (newAddress == -1) {
                            val endLength = model.count
                            model.expandData(token, endLength + 0x10)
                            newAddress = endLength + 0x10
                        }
                        token.changeData(model, newAddress, 0xFF)
                        model.observeRunWritten(token, PCSRun(model, newAddress, 1))
                    } else if (command.args.any { arg -> arg.pointerType == ExpectedPointerType.Mart }) {
                        newAddress = model.findFreeSpace(0, 0x10)
                        token.changeData(model, newAddress, 0x00)
                        token.changeData(model, newAddress + 1, 0x00)
                        writeMartStream(model, token, newAddress, -1)
                    } else if (command.args.any { arg -> arg.pointerType == ExpectedPointerType.Decor }) {
                        newAddress = model.findFreeSpace(0, 0x10)
                        token.changeData(model, newAddress, 0x00)
                        token.changeData(model, newAddress + 1, 0x00)
                        writeDecorStream(model, token, newAddress, -1)
                    } else if (command.args.any { arg -> arg.pointerType == ExpectedPointerType.SpriteTemplate }) {
                        newAddress = model.findFreeSpace(0, 0x18)
                        for (j in 0 until 0x18) token.changeData(model, newAddress + j, 0x00)
                        writeSpriteTemplateStream(model, token, newAddress, -1)
                    } else if (command.args.any { arg -> arg.pointerType == ExpectedPointerType.Script }) {
                        newAddress = model.findFreeSpace(0, 0x10)
                        token.changeData(model, newAddress, endToken)
                        // TODO write a new script template... an anchor with a format based on the current script
                    }
                    if (newAddress != -1) {
                        val originalLine = line
                        line = line.replaceOne("<??????>", "<" + newAddress.toHex(6) + ">")
                        if (command.args.any { arg -> arg.pointerType == ExpectedPointerType.Script }) {
                            script.value = script.value.replaceOne("<??????>", "<" + newAddress.toHex(6) + ">")
                        } else if (script.value.indexOf(originalLine) != script.value.indexOf(originalLine + "\n" + "{" + "\n")) {
                            script.value = script.value.replaceOne(originalLine, line + "\n" + "{" + "\n" + "}")
                            ignoreCharacterCount.value += "\n".length * 2 + 2
                        } else {
                            script.value = script.value.replaceOne("<??????>", "<" + newAddress.toHex(6) + ">")
                        }
                    }
                }

                val codeRef = Ref<ByteArray?>(null)
                val error = command.compile(model, start + currentSize, line, labels, codeRef)
                if (error == null) {
                    val code = codeRef.value!!
                    for (b in code) result.add(b.toInt() and 0xFF)
                } else {
                    val segment = TextSegment(i, 0, lines[i].length, SegmentType.Error)
                    compileError(this, ScriptErrorInfo(i.toString() + ": " + error, segment))
                    return null
                }
                var pointerOffset = command.lineCode.count
                for (arg in command.args) {
                    if (arg.type == ArgType.Pointer && arg.pointerType != ExpectedPointerType.Unknown) {
                        val at = currentSize + pointerOffset
                        val destination = (result[at] or (result[at + 1] shl 8) or (result[at + 2] shl 16) or (result[at + 3] shl 24)) + Pointer.null_
                        if (destination == DeferredStreamToken.autoSentinel + Pointer.null_) {
                            streamInfo.add(StreamInfo(arg.pointerType, start + currentSize + pointerOffset, destination))
                            val format: String
                            val defaultContent: ByteArray
                            val alignment: Int
                            when (arg.pointerType) {
                                ExpectedPointerType.Text -> {
                                    format = "\"\""
                                    defaultContent = byteArrayOf(0xFF.toByte())
                                    alignment = 1
                                }
                                ExpectedPointerType.Mart -> {
                                    format = "[item:" + HardcodeTablesModel.itemsTableName + "]!0000"
                                    defaultContent = byteArrayOf(0, 0)
                                    alignment = 4
                                }
                                ExpectedPointerType.Decor -> {
                                    format = "[item:" + HardcodeTablesModel.decorationsTableName + "]!0000"
                                    defaultContent = byteArrayOf(0, 0)
                                    alignment = 1
                                }
                                ExpectedPointerType.Movement -> {
                                    format = "[move.movementtypes]!FE"
                                    defaultContent = byteArrayOf(0xFE.toByte())
                                    alignment = 1
                                }
                                else -> {
                                    format = "^"
                                    defaultContent = ByteArray(0)
                                    alignment = 1
                                }
                            }
                            deferredContent.add(DeferredStreamToken(currentSize + pointerOffset, format, defaultContent, alignment))
                        } else if (destination >= 0 && arg.pointerType != ExpectedPointerType.Script) {
                            streamInfo.add(StreamInfo(arg.pointerType, start + currentSize + pointerOffset, destination))
                            if (arg.pointerType == ExpectedPointerType.Text) {
                                writeTextStream(model, token, destination, start + currentSize + pointerOffset)
                            } else if (arg.pointerType == ExpectedPointerType.Movement) {
                                writeMovementStream(model, token, destination, start + currentSize + pointerOffset)
                            }
                        }
                    }
                    pointerOffset += arg.length(model, currentSize + pointerOffset)
                }

                lastCommandIsEndCommand = command.isEndingCommand
            } else {
                compileError(this, ScriptErrorInfo(i.toString() + ": " + line + " is not a valid command", TextSegment(i, 0, lines[i].length, SegmentType.Error)))
                return null
            }
        }

        if (!lastCommandIsEndCommand) result.add(endToken and 0xFF)

        // any labels that were used but not included, stick them on the end of the script
        labels.resolveUnresolvedLabels(start, result, endToken)

        // done with script lines, now write deferred data
        for (deferred in deferredContent) {
            deferred.writeData(result, start)
        }

        if (updateBody != null) updateBody.streamTypes = streamTypes
        return result.toByteArrayU()
    }
    fun firstMatch(line: String): IScriptLine? { /*@DONE ScriptParser.FirstMatch/1 cs:686-692*/
        for (command in engine) {
            if (!command.matchesGame(gameHash)) continue
            if (command.canCompile(line)) return command
        }
        return null
    }
    private fun extractLocalLabels(model: IDataModel, start: Int, lines: Array<String>): LabelLibrary { /*@DONE ScriptParser.ExtractLocalLabels/1 cs:694-711*/
        val labels = LinkedHashMap<String, Int>()
        var length = 0
        for (fullLine in lines) {
            val line = fullLine.trim()
            if (line.endsWith(":")) {
                labels[line.substring(0, line.length - 1)] = start + length
                continue
            }
            for (command in engine) {
                if (!command.matchesGame(gameHash)) continue
                if (!command.canCompile(line)) continue
                length += command.compiledByteLength(model, line)
                break
            }
        }
        val library = LabelLibrary(model, labels)
        library.requireCompleteAddresses = requireCompleteAddresses
        return library
    }
    fun readOptions(model: IDataModel, tableName: String?, token: String): MutableList<String>? { /*@DONE ScriptParser.ReadOptions/1 cs:722-744*/
        if (!tableName.isNullOrEmpty()) {
            val listRef = Ref<ValidationList?>(null)
            val isList = model.tryGetList(tableName, listRef)
            val list = listRef.value
            val allOptions = model.getOptions(tableName)
            val found = ArrayList<String>()
            for (i in allOptions.indices) {
                val optionI: String? = allOptions[i] // option lists may contain null entries (unnamed values)
                if (optionI == null || optionI.isEmpty()) continue
                if (token.length == 0 || optionI.matchesPartial(token)) {
                    val listComments = list?.comments
                    val commentText = if (isList && listComments != null) listComments[i] else null
                    val comment = if (commentText == null) "" else " # " + commentText
                    found.add(optionI + comment)
                }
            }
            val options = sortOptions(found, token) { option -> option }.toMutableList()

            if (options.size > 10) {
                while (options.size > 9) options.removeAt(options.size - 1)
                options.add("...")
            }
            return options
        }
        return null
    }
    fun partialMatches(token: String): MutableList<IScriptLine> { /*@DONE ScriptParser.PartialMatches/1 cs:746-749*/
        return engine.filter { line -> line.lineCommand.matchesPartial(token) }.toMutableList()
    }
    fun getContentHelp(model: IDataModel, body: CodeBody?, context: HelpContext?): String? { /*@DONE ScriptParser.GetContentHelp/1 cs:751-763*/
        if (context == null || body == null) return null
        val bodyStreamTypes = body.streamTypes ?: return null
        if (!context.contentBoundaryIndex.inRange(0, bodyStreamTypes.size)) return null
        val expectedType = bodyStreamTypes[context.contentBoundaryIndex]
        if (expectedType == ExpectedPointerType.Mart) {
            val options = readOptions(model, HardcodeTablesModel.itemsTableName, context.line)
            return (options ?: ArrayList()).joinToString("\n")
        } else if (expectedType == ExpectedPointerType.Movement) {
            val options = readOptions(model, "movementtypes", context.line)
            return (options ?: ArrayList()).joinToString("\n")
        }
        return null
    }
    fun getHelp(model: IDataModel, context: HelpContext?): String? { /*@DONE ScriptParser.GetHelp/1 cs:765-765*/
        if (context == null) return null
        return getHelp(model, null, context)
    }
    fun getHelp(model: IDataModel, body: CodeBody?, context: HelpContext): String? { /*@DONE ScriptParser.GetHelp/2 cs:766-859*/
        val currentLine = context.line
        if (currentLine.isBlank()) return null
        if (context.index == currentLine.length && !currentLine.endsWith(" ")) return null
        if (context.contentBoundaryCount > 0 && body != null) return getContentHelp(model, body, context)
        var tokens = ScriptLine.tokenize(currentLine.trim())
        var candidates: List<IScriptLine> = partialMatches(tokens[0]).filter { line -> line.matchesGame(gameHash) }
        // match linecode (if there is one)
        val num = Ref(0)
        if (tokens.size > 1 && candidates.any { candidate -> candidate.lineCode.count > 1 } && tokens[1].tryParseInt(num)) {
            candidates = candidates.filter { line -> line.lineCode.count < 2 || line.lineCode[1] == num.value }
        }

        val isAfterToken = context.index > 0 && context.index < context.line.length &&
            (context.line.length == context.index || context.line[context.index] == ' ') &&
            (context.line[context.index - 1].isLetterOrDigit() || context.line[context.index - 1].isAny('_', '~', '\'', '"', '-', '.'))
        if (isAfterToken) {
            tokens = ScriptLine.tokenize(currentLine.substring(0, context.index).trim())
            // try to auto-complete whatever token is left of the cursor

            // need autocomplete for command?
            if (tokens.size == 1) {
                val firstToken = tokens[0]
                candidates = candidates.filter { line -> line.lineCommand.matchesPartial(firstToken) }
                if (!context.isSelection) {
                    for (line in candidates) {
                        if (line.lineCommand == firstToken && line.countShowArgs() == 0) return null // perfect match with no args
                    }
                }
                candidates = sortOptions(candidates, firstToken) { c -> c.lineCommand }.toList()
                return candidates.take(10).joinToString("\n") { line -> line.usage }
            }

            // filter down to just perfect matches. There could be several (trainerbattle)
            val commandToken = tokens[0]
            candidates = candidates.filter { line -> line.lineCommand.equals(commandToken, ignoreCase = true) }
            var checkToken = 1
            while (candidates.size > 1 && checkToken < tokens.size) {
                val codeValue = Ref(0)
                if (!tokens[checkToken].tryParseHex(codeValue)) break
                val currentCheck = checkToken
                val currentValue = codeValue.value
                candidates = candidates.filter { line -> line.lineCode.count <= currentCheck || line.lineCode[currentCheck] == currentValue }
                checkToken++
            }
            val syntax = candidates.firstOrNull()
            if (syntax != null) {
                var args: List<IScriptArg> = syntax.args.filter { arg -> arg is ScriptArg }
                if (syntax is MacroScriptLine) args = syntax.shortFormArgs?.toList() ?: args
                var skipCount = syntax.lineCode.count
                if (skipCount == 0) skipCount = 1 // macros
                if (args.size + skipCount >= tokens.size && tokens.size >= skipCount + 1) {
                    val arg = args[tokens.size - 1 - skipCount]
                    val token = tokens[tokens.size - 1]
                    val options = readOptions(model, arg.enumTableName, token)
                    if (options != null) {
                        if (args.size == tokens.size - skipCount && options.any { option -> option == token }) return null // perfect match on last token
                        return options.joinToString("\n")
                    }
                }
            }
        }

        if (candidates.size > 15) return null
        if (candidates.size == 0) return null

        var partialDocumentation = ""
        if (candidates.size == 1 && !(candidates[0].documentation ?: emptyList()).all { it.isBlank() }) {
            if (candidates[0].countShowArgs() <= tokens.size - 1) return null
            partialDocumentation = candidates[0].usage + "\n" + (candidates[0].documentation ?: emptyList()).joinToString("\n")
        }

        if (context.index > 0 && context.index < context.line.length && context.line[context.index - 1] == ' ' && tokens.size > 0) {
            // I'm directly after a space, I'm at the start of a new token, there is no existing documentation
            var skipCount = candidates[0].lineCode.count
            if (skipCount == 0) skipCount = 1
            var args: List<IScriptArg> = candidates[0].args.filter { arg -> arg is ScriptArg }
            val first = candidates[0]
            if (first is MacroScriptLine) args = first.shortFormArgs?.toList() ?: args
            if ((tokens.size - skipCount).inRange(0, args.size)) {
                val arg = args[tokens.size - skipCount]
                val options = readOptions(model, arg.enumTableName, "")
                if (options != null) {
                    if (partialDocumentation.length > 0) partialDocumentation += "\n"
                    partialDocumentation += options.joinToString("\n")
                }
            }
        }

        if (partialDocumentation.length > 0) return partialDocumentation

        val perfectMatch = candidates.firstOrNull { candidate -> (currentLine + " ").startsWith(candidate.lineCommand + " ") }
        if (perfectMatch != null) {
            if (perfectMatch.countShowArgs() == tokens.size - 1) return null
            return perfectMatch.usage + "\n" + (perfectMatch.documentation ?: emptyList()).joinToString("\n")
        }
        val bestMatch = candidates.firstOrNull { candidate -> tokens[0].contains(candidate.lineCommand) }
        if (bestMatch != null) {
            if (bestMatch.countShowArgs() + bestMatch.lineCode.count == tokens.size) return null
            return bestMatch.usage + "\n" + (bestMatch.documentation ?: emptyList()).joinToString("\n")
        }
        return candidates.joinToString("\n") { line -> line.usage }
    }
    private fun decompile(data: IDataModel, index: Int, length: Int, updateBody: CodeBody?, existingSectionCount: Ref<Int>): Array<String> { /*@DONE ScriptParser.Decompile/1 cs:889-966*/
        var index = index
        var length = length
        val results = ArrayList<String>()
        var nextAnchor = data.getNextAnchor(index)
        val destinations = LinkedHashMap<Int, Int>()

        val linesWithLabelsToUpdate = LinkedHashSet<Int>()
        val labels = DecompileLabelLibrary(data, index, length)
        val streamTypes = ArrayList<ExpectedPointerType>()

        while (length > 0) {
            if (index == nextAnchor.start) {
                if (nextAnchor is IScriptStartRun) {
                    if (results.size > 0) results.add("")
                    results.add(labels.addressToLabel(nextAnchor.start, true) + ": # " + nextAnchor.start.toHex(6))
                    linesWithLabelsToUpdate.add(results.size - 1)
                } else if (nextAnchor is IStreamRun) {
                    if (destinations.containsKey(index)) {
                        index += nextAnchor.length
                        length -= nextAnchor.length
                    }
                }
                nextAnchor = data.getNextAnchor(nextAnchor.start + Math.max(1, nextAnchor.length))
                continue
            } else if (index > nextAnchor.start) {
                nextAnchor = data.getNextAnchor(nextAnchor.start + Math.max(1, nextAnchor.length))
                continue
            }

            val currentIndex = index
            val line = engine.firstOrNull { option -> option.matches(gameHash, data, currentIndex) }
            if (line == null) {
                results.add(".raw " + data[index].toHexByte())
                index += 1
                length -= 1
            } else {
                results.add("  " + line.decompile(data, index, labels, streamTypes))
                if (line.args.any { arg -> arg.type == ArgType.Pointer && arg.pointerType == ExpectedPointerType.Script }) {
                    linesWithLabelsToUpdate.add(results.size - 1)
                }
                val compiledByteLength = line.compiledByteLength(data, index, destinations)
                index += compiledByteLength
                length -= compiledByteLength

                // if we point to shortly after, keep going
                if (destinations.containsKey(index) && nextAnchor is IScriptStartRun && nextAnchor.start == index) continue
                if (destinations.containsKey(index + 1) && nextAnchor is IScriptStartRun && nextAnchor.start == index + 1) continue
                if (destinations.containsKey(index) && nextAnchor is IStreamRun && nextAnchor.start == index) continue
                if (destinations.containsKey(index + 1) && nextAnchor is IStreamRun && nextAnchor.start == index + 1) continue
                if (destinations.containsKey(index + 2) && nextAnchor is IStreamRun && nextAnchor.start == index + 2) continue
                if (destinations.containsKey(index + 3) && nextAnchor is IStreamRun && nextAnchor.start == index + 3) continue

                // if we're at an end command, don't keep going
                if (line.isEndingCommand) break
            }
        }

        // post processing: if a line has a stream pointer to within the script,
        // change that pointer to be an -auto- pointer
        for (label in labels.autoLabels.toList()) {
            val labelText = "<" + label.toHex(6) + ">"
            val autoIndex = results.indices.firstOrNull { i -> results[i].contains(labelText) } ?: 0
            val autoRun = data.getNextRun(label)
            val runIsStream = autoRun is IStreamRun

            if (runIsStream) {
                if (autoIndex < results.size) results[autoIndex] = results[autoIndex].replace(labelText, "<auto>")
            } else {
                continue
            }
        }

        // post processing: change the section labels to be in address order
        val sections = labels.finalizeLabels(existingSectionCount)
        for (i in linesWithLabelsToUpdate) {
            results[i] = labels.finalizeLine(sections, results[i])
        }

        if (updateBody != null) updateBody.streamTypes = streamTypes
        return results.toTypedArray()
    }
    companion object {
        const val maxRepeates: Int = 20
        fun insertMissingClosers(script: Ref<String>, caret: Int): Int { /*@DONE ScriptParser.InsertMissingClosers/1 cs:419-492*/
            // The C# code assumes Windows line endings ("\r\n"); this version uses whatever line ending the script uses ("\n" by default).
            val nl = if (script.value.contains("\r\n")) "\r\n" else "\n"
            fun insertNewline(text: ArrayList<Char>, at: Int) { for (k in nl.indices) text.add(at + k, nl[k]) }
            fun newlineAt(text: ArrayList<Char>, at: Int): Boolean {
                if (at < 0 || at + nl.length > text.size) return false
                for (k in nl.indices) if (text[at + k] != nl[k]) return false
                return true
            }
            var caret = caret
            var caretMove = 0
            var isStartOfLine = true
            val text = ArrayList<Char>(script.value.length + 16)
            for (c in script.value) text.add(c)
            var i = -1
            while (true) {
                i++
                if (i >= text.size) break
                if (text[i] == '\n' || text[i] == '\r') isStartOfLine = true
                else if (text[i] != ' ' && text[i] != '{') isStartOfLine = false
                if (text[i] != '{') continue

                if (!isStartOfLine) {
                    insertNewline(text, i)
                    if (i <= caret) { caret += nl.length }
                    i += nl.length
                }

                isStartOfLine = true
                var close = -1
                var j = i + 1
                while (j < text.size && text[j] != '{') {
                    if (text[j] == '\n' || text[j] == '\r') isStartOfLine = true
                    else if (text[j] != ' ' && text[j] != '}') isStartOfLine = false
                    if (text[j] != '}') {
                        j++
                        continue
                    }
                    if (!isStartOfLine) {
                        insertNewline(text, j)
                        if (j < caret) { caret += nl.length; caretMove += nl.length }
                        j += nl.length
                    }
                    close = j
                    break
                }
                if (close == -1) {
                    if (i == caret || (i == caret - 1 && caret == text.size)) {
                        insertNewline(text, i + 1)
                    }
                    val closeAt = i + 1 + nl.length
                    while (text.size < closeAt) text.add(' ')
                    text.add(closeAt, '}')
                    close = closeAt
                    if (i == caret) caretMove -= nl.length + 1
                    // check for excess blank lines after the lines we just inserted
                    if (close < text.size - 2 * nl.length && newlineAt(text, close + 1) && newlineAt(text, close + 1 + nl.length)) {
                        for (k in nl.indices) text.removeAt(close + 1)
                    }
                }
                if (i + 1 < text.size && text[i + 1] != nl[0]) {
                    insertNewline(text, i + 1)
                    if (i < caret) { caret += nl.length; caretMove += nl.length }
                    close += nl.length
                }
                if (close + 1 < text.size && text[close + 1] != nl[0]) {
                    insertNewline(text, close + 1)
                    if (close < caret) { caret += nl.length }
                    isStartOfLine = true
                    close += nl.length
                }

                // special case: no blank line between open and close
                if (close == i + 1 + nl.length) {
                    while (text.size < i) text.add(' ')
                    insertNewline(text, i + 1)
                    if (i < caret) { caret += nl.length; caretMove -= nl.length }
                    close += nl.length
                }

                i = close
            }

            script.value = String(text.toCharArray())
            return caretMove
        }
        fun <T> sortOptions(options: Iterable<T>, token: String, compare: (T) -> String): Iterable<T> { /*@DONE ScriptParser.SortOptions/1 cs:713-720*/
            var options = options
            if (token.length > 0) {
                options = options.sortedBy { a -> compare(a).length }
                options = options.sortedBy { a -> compare(a).skipCount(token) }
                options = options.sortedBy { a -> compare(a).indexOf(token[0], ignoreCase = true) }
            }
            return options
        }
        fun getArgLength(model: IDataModel, arg: IScriptArg, start: Int, destinationLengths: MutableMap<Int, Int>): Int { /*@DONE ScriptParser.GetArgLength/1 cs:861-887*/
            if (arg.type == ArgType.Pointer && arg.pointerType != ExpectedPointerType.Unknown) {
                val destination = model.readPointer(start)
                if (destination >= 0 && destination < model.count) {
                    val run = model.getNextRun(destination) ?: NoInfoRun.nullRun
                    val scriptStart = run as? IScriptStartRun
                    if (scriptStart != null && scriptStart.start == destination && scriptStart.start > start) {
                        return model.getScriptLength(scriptStart, destinationLengths)
                    } else if (run.start == destination) {
                        // we only want to add this run's length as part of the script if:
                        // (1) the run has no name
                        // (2) the run has only one source (the script)
                        val sources = run.pointerSources
                        if (run is NoInfoRun || sources == null) return -1
                        if (scriptStart != null && scriptStart.start < start) return 1 // this script has a length, but don't calculate it (prevent recursion loop)
                        if (scriptStart != null) return -1 // this script has a length, but don't track it (prevent recursion loop)
                        if (sources.size == 1 && model.getAnchorFromAddress(-1, destination).isEmpty()) {
                            return run.length
                        }
                    } else if (arg.pointerType == ExpectedPointerType.Text) {
                        // we didn't find a matching run, but this data claims to be simple text
                        val textLength = PCSString.readString(model, destination, true)
                        return textLength
                    }
                }
            }
            return -1
        }
        /*@END ScriptParser.Companion*/
    }
    /*@ADD ScriptParser#models_3h.txt*/
    fun formatScriptImpl(runType: Class<*>, token: ModelDelta, model: IDataModel, address: Int, minLength: Int = 0): MutableMap<Int, Int>? {
        var address = address
        var minLength = minLength
        if (!address.inRange(0, model.count)) return null
        var constructor: (Int, SortedSpan<Int>?) -> IScriptStartRun = { a, s -> XSERun(a, s) }
        if (runType == BSERun::class.java) constructor = { a, s -> BSERun(a, s) }
        if (runType == ASERun::class.java) constructor = { a, s -> ASERun(a, s) }
        if (runType == TSERun::class.java) constructor = { a, s -> TSERun(a, s) }

        val processed = LinkedHashMap<Int, Int>()
        val toProcess = ArrayList<Int>()
        toProcess.add(address)
        while (toProcess.size > 0) {
            address = toProcess[toProcess.size - 1]
            toProcess.removeAt(toProcess.size - 1)
            val existingRun = model.getNextRun(address) ?: NoInfoRun.nullRun
            // We need to check for an anchor here _before_ checking if this is a duplicate address and therefore skippable.
            // Because self-referential scripts won't have their anchor picked up on the initial run.
            if (!runType.isInstance(existingRun) && existingRun.start == address) {
                val anchorName = model.getAnchorFromAddress(-1, address)
                model.observeAnchorWritten(token, anchorName, constructor(address, existingRun.pointerSources))
            }
            if (processed.containsKey(address)) continue
            var length = 0
            var desiredLength = minLength
            minLength = 0
            while (true) {
                val line = engine.getMatchingLine(gameHash, model, address + length) ?: break
                // there may've previously been a pointer here: the code has changed!
                val pRun = model.getNextRun(address + length)
                if (pRun is PointerRun && pRun.start == address + length) model.clearFormat(token, address + length, line.lineCode.count)
                length += line.lineCode.count
                for (arg in line.args) {
                    if (arg.type != ArgType.Pointer) {
                        // there may've previously been a pointer here: the code has changed!
                        // when clearing args, we actually _do_ want to clear any anchors that point to them.
                        val start = address + length
                        val argLength = arg.length(model, start)
                        val tableRun = model.getNextRun(start)
                        if (tableRun is ITableRun && tableRun.start == start && tableRun.length == argLength) {
                            // no need to clear
                        } else {
                            model.clearFormat(token, start, argLength)
                        }
                    } else {
                        val destination = model.readPointer(address + length)
                        if (destination.inRange(0, model.count) && !destination.inRange(address + length, address + length + 4)) {
                            val destinationRun = model.getNextRun(destination) ?: NoInfoRun.nullRun
                            if (destinationRun.start < destination) {
                                // we're trying to point into already formatted data
                                // don't add the pointer source or destination
                            } else {
                                val pointerSource = model.getNextRun(address + length)
                                if (pointerSource is PointerRun && pointerSource.start == address + length) {
                                    // no need to clear/update
                                } else {
                                    model.clearFormat(token, address + length, 4)
                                    model.observeRunWritten(token, PointerRun(address + length))
                                }
                                if (arg.pointerType == ExpectedPointerType.Script) {
                                    toProcess.add(destination)
                                    if (destination.inRange(address, address + desiredLength)) desiredLength = destination - address
                                }
                                if (arg.pointerType == ExpectedPointerType.Text) {
                                    writeTextStream(model, token, destination, address + length)
                                } else if (arg.pointerType == ExpectedPointerType.Movement) {
                                    writeMovementStream(model, token, destination, address + length)
                                } else if (arg.pointerType == ExpectedPointerType.Mart) {
                                    writeMartStream(model, token, destination, address + length)
                                } else if (arg.pointerType == ExpectedPointerType.Decor) {
                                    writeDecorStream(model, token, destination, address + length)
                                } else if (arg.pointerType == ExpectedPointerType.SpriteTemplate) {
                                    writeSpriteTemplateStream(model, token, destination, address + length)
                                }
                            }
                        }
                    }
                    length += arg.length(model, address + length)
                }
                if (line.isEndingCommand && length >= desiredLength) break
            }
            processed[address] = length
        }

        return processed
    }
    /*@ENDADD ScriptParser#models_3h.txt*/
    /*@END ScriptParser*/
}

enum class ExpectedPointerType(val value: Int) { // cs:969-977
    Unknown(0),
    Script(1),
    Text(2),
    Movement(3),
    Mart(4),
    Decor(5),
    SpriteTemplate(6);
    companion object {
        fun fromValue(value: Int): ExpectedPointerType = entries.first { it.value == value }
    }
    /*@END ExpectedPointerType*/
}

fun List<IScriptLine>.getMatchingMacro(gameHash: Int, data: ByteList, start: Int): MacroScriptLine? { /*@DONE ScriptExtensions.GetMatchingMacro/1 cs:980-982*/
    return this.firstOrNull { option -> option is MacroScriptLine && option.matches(gameHash, data, start) } as MacroScriptLine?
}
fun List<IScriptLine>.getMatchingLine(gameHash: Int, data: ByteList, start: Int): ScriptLine? { /*@DONE ScriptExtensions.GetMatchingLine/1 cs:987-989*/
    return this.firstOrNull { option -> option is ScriptLine && option.matches(gameHash, data, start) } as ScriptLine?
}
fun List<IScriptLine>.getScriptSegmentLength(gameHash: Int, model: IDataModel, address: Int, destinationLengths: MutableMap<Int, Int>): Int { /*@DONE ScriptExtensions.GetScriptSegmentLength/1 cs:991-1035*/
    var length = 0
    var lastCommand = -1
    var repeateLength = 1
    while (true) {
        val line = this.getMatchingLine(gameHash, model, address + length) ?: break
        length += line.compiledByteLength(model, address + length, destinationLengths)
        if (line.isEndingCommand) break

        if (line.lineCode[0] != lastCommand) {
            lastCommand = line.lineCode[0]
            repeateLength = 1
        } else {
            repeateLength += 1
        }
        if (line.args.size > 0) repeateLength = 0
        if (repeateLength > ScriptParser.maxRepeates) break // same command lots of times in a row is fishy
    }

    // concatenate destinations directly after the current script
    // (only if the destination is only used once)
    val initialAnchor = model.getNextAnchor(address + length)
    var consolidateAgain = true
    while (consolidateAgain) {
        consolidateAgain = false
        for (i in 0 until 4) {
            // we want to know if there's more script content detected closely after this script, with a possible gap of a few bytes
            // go ahead and concatenate that content onto this script segment if nothing is using the space between.
            var argLength = destinationLengths[address + length + i]
            if (argLength != null && argLength > 0) {
                if (i == 1 && initialAnchor.start == address + length && (initialAnchor.pointerSources?.size ?: 0) > 0) break
                val spacedAnchor = model.getNextAnchor(address + length + i)
                if (spacedAnchor.start == address + length + i && (spacedAnchor.pointerSources?.size ?: 0) == 1) {
                    // if the argLength is 1, we may've resisted finding the length to prevent recursion.
                    // Now that we know more lengths, go ahead and try to calculate it.
                    if (argLength == 1 && spacedAnchor is IScriptStartRun) {
                        destinationLengths.remove(address + length + i)
                        argLength = model.getScriptLength(spacedAnchor, destinationLengths)
                        destinationLengths[address + length + i] = argLength
                    }

                    length += argLength + i
                    consolidateAgain = true
                    break
                }
            }
        }
    }

    return length
}

object ScriptExtensions { // cs:979-1036
    /*@END ScriptExtensions*/
}

open class DeferredStreamToken { // cs:1038-1139
    private var pointerOffset: Int = 0
    private var format: String = ""
    private var content: ByteArray = ByteArray(0)
    private var alignment: Int = 0
    val contentLength: Int
        get() { /*@DONE DeferredStreamToken.ContentLength.get cs:1046-1046*/
            return content.size
        }
    constructor(pointerOffset: Int, format: String, defaultContent: ByteArray, alignment: Int) { /*@DONE DeferredStreamToken.<init>/1 cs:1048-1053*/
        this.pointerOffset = pointerOffset
        this.format = format
        this.content = defaultContent
        this.alignment = alignment
    }
    fun updateContent(model: IDataModel, type: ExpectedPointerType, text: String) { /*@DONE DeferredStreamToken.UpdateContent/1 cs:1056-1112*/
        if (type == ExpectedPointerType.Text) {
            content = (model.textConverter.convert(text, Ref(false)) ?: ArrayList<Int>()).toByteArrayU()
        } else if (type == ExpectedPointerType.Mart) {
            //   [item:{HardcodeTablesModel.ItemsTableName}]!0000
            val data = ArrayList<Int>()
            for (line in text.splitLines()) {
                if (line.isBlank()) continue
                val value = Ref(0)
                if (!ArrayRunEnumSegment.tryParse(HardcodeTablesModel.itemsTableName, model, line, value)) continue
                data.addShort(value.value)
            }
            data.addShort(0)
            content = data.toByteArrayU()
        } else if (type == ExpectedPointerType.Mart) {
            //   [item:{HardcodeTablesModel.DecorationsTableName}]!0000
            val data = ArrayList<Int>()
            for (line in text.splitLines()) {
                if (line.isBlank()) continue
                val value = Ref(0)
                if (!ArrayRunEnumSegment.tryParse(HardcodeTablesModel.decorationsTableName, model, line, value)) continue
                data.addShort(value.value)
            }
            data.addShort(0)
            content = data.toByteArrayU()
        } else if (type == ExpectedPointerType.Movement) {
            //   "[move.movementtypes]!FE",
            val data = ArrayList<Int>()
            for (line in text.splitLines()) {
                if (line.isBlank()) continue
                val value = Ref(0)
                if (!ArrayRunEnumSegment.tryParse("movementtypes", model, line, value)) continue
                data.add(value.value and 0xFF)
            }
            data.add(0xFE)
            content = data.toByteArrayU()
        } else if (type == ExpectedPointerType.SpriteTemplate) {
            val spriteFormat = "tileTag: paletteTag: oam<> anims<> images<> affineAnims<> callback<>".split(' ')
            val data = IntArray(24)
            for (line in text.splitLines()) {
                val parts = line.split(':')
                if (parts.size == 1) continue
                val index = spriteFormat.indexOfFirst { f -> parts[0].startsWith(f) }
                if (index == -1) continue
                val offset = when (index) {
                    0 -> 0
                    1 -> 2
                    else -> (index - 1) * 4
                }
                val field = readSpriteTemplateField(spriteFormat[index], parts[1])
                var value = field.first
                val fieldLength = field.second

                for (i in 0 until fieldLength) {
                    data[offset + i] = value and 0xFF
                    value = value shr 8
                }
            }
        } else {
            throw NotImplementedError()
        }
    }
    private fun readSpriteTemplateField(format: String, content: String): Pair<Int, Int> { /*@DONE DeferredStreamToken.ReadSpriteTemplateField/1 cs:1114-1119*/
        val content = content.trim()
        val result = Ref(0)
        if (format.endsWith(":") && content.tryParseInt(result)) return Pair(result.value, 2)
        if (format.endsWith("<>") && content.trim('<', '>').tryParseHex(result)) return Pair(result.value, 4)
        return Pair(0, 0)
    }
    fun writeData(model: IDataModel, token: ModelDelta, scriptStart: Int, contentOffset: Int) { /*@DONE DeferredStreamToken.WriteData/1 cs:1121-1128*/
        model.clearFormat(token, scriptStart + pointerOffset, 4)
        model.writePointer(token, scriptStart + pointerOffset, scriptStart + contentOffset)
        model.observeRunWritten(token, PointerRun(scriptStart + pointerOffset))
        token.changeData(model, scriptStart + contentOffset, content.asByteList())
        val strategy = FormatRunFactory(false).getStrategy(format)
        strategy?.tryAddFormatAtDestination(model, token, scriptStart + pointerOffset, scriptStart + contentOffset, "", null, 0)
    }
    fun writeData(data: MutableList<Int>, scriptStart: Int) { /*@DONE DeferredStreamToken.WriteData/2 cs:1130-1138*/
        while ((scriptStart + data.size) % alignment != 0) data.add(0)
        val address = scriptStart + data.size - Pointer.null_
        data[pointerOffset + 0] = (address shr 0) and 0xFF
        data[pointerOffset + 1] = (address shr 8) and 0xFF
        data[pointerOffset + 2] = (address shr 16) and 0xFF
        data[pointerOffset + 3] = (address shr 24) and 0xFF
        for (b in content) data.add(b.toInt() and 0xFF)
    }
    companion object {
        const val autoSentinel: Int = -0xAAAA
        /*@END DeferredStreamToken.Companion*/
    }
    /*@END DeferredStreamToken*/
}

data class ScriptParserCompileMovedDataTuple(val originalLocation: Int, val newLocation: Int)
