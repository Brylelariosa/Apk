// Port of ViewModels/Tools/SpriteElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.images.*

open class SpriteIndicatorElementViewModel : ViewModelCore, IArrayElementViewModel { // cs:13-37
    var image: IPixelViewModel? = null
        private set
    private var _visible: Boolean = false
    override var visible: Boolean
        get() { /*@DONE SpriteIndicatorElementViewModel.Visible.get cs:17-17*/
            return _visible
        }
        set(value) { /*@DONE SpriteIndicatorElementViewModel.Visible.set cs:17-17*/
            set(_visible, value, "visible", { _visible = it })
        }
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE SpriteIndicatorElementViewModel.Theme.get cs:19-19*/
            return _theme
        }
        set(value) { /*@DONE SpriteIndicatorElementViewModel.Theme.set cs:19-19*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE SpriteIndicatorElementViewModel.IsInError.get cs:20-20*/
            return false
        }
    override val errorText: String?
        get() { /*@DONE SpriteIndicatorElementViewModel.ErrorText.get cs:22-22*/
            return ""
        }
    override val zIndex: Int
        get() { /*@DONE SpriteIndicatorElementViewModel.ZIndex.get cs:24-24*/
            return 1
        }
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    constructor(image: IPixelViewModel) { /*@DONE SpriteIndicatorElementViewModel.<init>/1 cs:29-29*/
        this.image = image
    }
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE SpriteIndicatorElementViewModel.TryCopy/1 cs:31-36*/
        val indicator = other as? SpriteIndicatorElementViewModel ?: return false
        image = indicator.image
        notifyPropertyChanged("image")
        return true
    }
    /*@END SpriteIndicatorElementViewModel*/
}

open class SpriteElementViewModel : PagedElementViewModel, IPixelViewModel { // cs:39-363
    private var format: SpriteFormat = SpriteFormat()
    override var pixelData: ShortArray = ShortArray(0)
    override val transparent: Short
        get() { /*@DONE SpriteElementViewModel.Transparent.get cs:43-43*/
            return (-1).toShort()
        }
    override val pixelWidth: Int
        get() { /*@DONE SpriteElementViewModel.PixelWidth.get cs:44-44*/
            return format.tileWidth * 8
        }
    override val pixelHeight: Int
        get() { /*@DONE SpriteElementViewModel.PixelHeight.get cs:45-45*/
            return format.tileHeight * 8
        }
    override var spriteScale: Double = 0.0
    val hasMultiplePalettes: Boolean
        get() { /*@DONE SpriteElementViewModel.HasMultiplePalettes.get cs:48-48*/
            return maxPalette > 0
        }
    private var _currentPalette: Int = 0
    var currentPalette: Int
        get() { /*@DONE SpriteElementViewModel.CurrentPalette.get cs:51-51*/
            return _currentPalette
        }
        set(value) { /*@DONE SpriteElementViewModel.CurrentPalette.set cs:52-60*/
            set(_currentPalette, value, "currentPalette", { _currentPalette = it }) { _ ->
                updateTiles(currentPage)
                for (child in viewPort.tools!!.tableTool!!.children) {
                    if (child is SpriteElementViewModel && child !== this && child.maxPalette == maxPalette) child.currentPalette = currentPalette
                }
                updatePaletteSelection()
            }
        }
    var maxPalette: Int = 0
        private set
    fun getRun(start: Int = Int.MIN_VALUE): ISpriteRun? { /*@DONE SpriteElementViewModel.GetRun/1 cs:64-75*/
        val address = if (start == Int.MIN_VALUE) this.start else start
        val destination = viewPort.model.readPointer(address)
        if (destination < 0 || destination >= viewPort.model.count) return null
        var run = viewPort.model.getNextRun(destination) as? ISpriteRun
        if (run == null) {
            val tempRun = Ref<IFormattedRun?>(NoInfoRun(destination, SortedSpan(this.start)))
            model.formatRunFactory.getStrategy(runFormat)?.tryParseData(model, "", destination, tempRun)
            run = tempRun.value as? ISpriteRun
        }
        return run
    }
    private var _openEditor: StubCommand? = null
    val openEditor: ICommand
        get() { /*@DONE SpriteElementViewModel.OpenEditor.get cs:80-80*/
            return _openEditor ?: stubCommand({ executeOpenEditor() }, { canExecuteImageEditor() }).also { _openEditor = it }
        }
    private fun canExecuteImageEditor(): Boolean { /*@DONE SpriteElementViewModel.CanExecuteImageEditor/1 cs:82-85*/
        val run = getRun()
        return run?.supportsEdit ?: false
    }
    private fun executeOpenEditor() { /*@DONE SpriteElementViewModel.ExecuteOpenEditor/1 cs:87-91*/
        if (dataIsNotValid && canRepoint) repoint.execute(null)
        val destination = viewPort.model.readPointer(start)
        viewPort.openImageEditorTab(destination, currentPage, currentPalette)
    }
    private var importImage: StubCommand? = null
    private var exportImage: StubCommand? = null
    private var exportImages: StubCommand? = null
    private var exportAllImages: StubCommand? = null
    val canExportMany: Boolean
        get() { /*@DONE SpriteElementViewModel.CanExportMany.get cs:99-99*/
            return pages > 1 && exportPair.canExecute(null)
        }
    val canExportAll: Boolean
        get() { /*@DONE SpriteElementViewModel.CanExportAll.get cs:100-100*/
            return canExecuteExportAllImages(null)
        }
    val canExportManyOrAll: Boolean
        get() { /*@DONE SpriteElementViewModel.CanExportManyOrAll.get cs:101-101*/
            return canExportMany || canExportAll
        }
    val importPair: ICommand
        get() { /*@DONE SpriteElementViewModel.ImportPair.get cs:102-102*/
            return importImage ?: stubCommandOf<IFileSystem>({ fs -> if (fs != null) executeImportImage(fs) }, { arg -> canExecuteImportImage(arg) }).also { importImage = it }
        }
    val exportPair: ICommand
        get() { /*@DONE SpriteElementViewModel.ExportPair.get cs:103-103*/
            return exportImage ?: stubCommandOf<IFileSystem>({ fs -> if (fs != null) executeExportImage(fs) }, { arg -> canExecuteExportImage(arg) }).also { exportImage = it }
        }
    val exportMany: ICommand
        get() { /*@DONE SpriteElementViewModel.ExportMany.get cs:104-104*/
            return exportImages ?: stubCommandOf<IFileSystem>({ fs -> if (fs != null) executeExportImages(fs) }, { arg -> canExecuteExportImages(arg) }).also { exportImages = it }
        }
    val exportAll: ICommand
        get() { /*@DONE SpriteElementViewModel.ExportAll.get cs:105-105*/
            return exportAllImages ?: stubCommandOf<IFileSystem>({ fs -> if (fs != null) executeExportAllImages(fs) }, { arg -> canExecuteExportAllImages(arg) }).also { exportAllImages = it }
        }
    private fun canExecuteImportImage(arg: Any?): Boolean { /*@DONE SpriteElementViewModel.CanExecuteImportImage/1 cs:107-113*/
        val destination = viewPort.model.readPointer(start)
        val spriteRun = viewPort.model.getNextRun(destination) as? ISpriteRun
        if (spriteRun == null || spriteRun.start != destination) return false
        if (spriteRun.spriteFormat.bitsPerPixel < 4) return spriteRun.supportsImport
        if (maxPalette < 0) return false
        return spriteRun.supportsImport
    }
    private fun canExecuteExportImage(arg: Any?): Boolean { /*@DONE SpriteElementViewModel.CanExecuteExportImage/1 cs:114-120*/
        val destination = viewPort.model.readPointer(start)
        val spriteRun = viewPort.model.getNextRun(destination) as? ISpriteRun
        if (spriteRun == null || spriteRun.start != destination) return false
        if (spriteRun.spriteFormat.bitsPerPixel < 4) return true
        if (maxPalette < 0) return false
        return true
    }
    private fun canExecuteExportImages(arg: Any?): Boolean { /*@DONE SpriteElementViewModel.CanExecuteExportImages/1 cs:121-121*/
        return canExportMany
    }
    private fun canExecuteExportAllImages(arg: Any?): Boolean { /*@DONE SpriteElementViewModel.CanExecuteExportAllImages/1 cs:122-124*/
        val table = model.getNextRun(start) as? ITableRun
        return table != null && table.elementCount > 1
    }
    private fun executeImportImage(fs: IFileSystem) { /*@DONE SpriteElementViewModel.ExecuteImportImage/1 cs:126-126*/
        executeSpriteToolCommand(fs, viewPort.tools!!.spriteTool!!.importPair)
    }
    private fun executeExportImage(fs: IFileSystem) { /*@DONE SpriteElementViewModel.ExecuteExportImage/1 cs:127-127*/
        executeSpriteToolCommand(fs, viewPort.tools!!.spriteTool!!.exportPair)
    }
    private fun executeExportImages(fs: IFileSystem) { /*@DONE SpriteElementViewModel.ExecuteExportImages/1 cs:128-128*/
        executeSpriteToolCommand(fs, viewPort.tools!!.spriteTool!!.exportMany)
    }
    private fun executeExportAllImages(fs: IFileSystem) { /*@DONE SpriteElementViewModel.ExecuteExportAllImages/1 cs:130-170*/
        val folder: String? = fs.openFolder()
        if (folder.isNullOrEmpty()) return
        val run = model.getNextRun(start) as? ITableRun ?: return
        val tableName = model.getAnchorFromAddress(-1, run.start)
        val offset = run.convertByteOffsetToArrayOffset(start)
        for (i in 0 until run.elementCount) {
            val itemStart = run.start + run.elementLength * i + run.elementContent.take(offset.segmentIndex).sumOf { seg -> seg.length }
            val elementNames = run.elementNames
            var shortname = if (elementNames != null && elementNames.size > i) elementNames[i] else "Sprite " + i
            val sRun = getRun(itemStart)
            if (sRun != null) {
                val palettes = sRun.findRelatedPalettes(model, itemStart, sRun.spriteFormat.paletteHint ?: format.paletteHint).toList()
                var palette = palettes.firstOrNull()
                if (palettes.size > 1 && palettes.size > currentPalette) palette = palettes[currentPalette]
                for (c in Path.getInvalidFileNameChars()) shortname = shortname.replace(c, '_')
                val name = folder + "/" + tableName + "_" + i + "_" + shortname + ".png"
                if (!fs.exists(name)) {
                    if (sRun is ITilemapRun) sRun.findMatchingTileset(model)
                    val imagePixels = sRun.getPixels(model, if (sRun.pages > currentPage) currentPage else 0, -1)
                    val colors = palette?.allColors(model) ?: TileViewModel.createDefaultPalette(Math.pow(2.0, sRun.spriteFormat.bitsPerPixel.toDouble()).toInt()).toList()
                    if (imagePixels == null || imagePixels.size == 0) {
                        viewPort.raiseError("Could not export image " + i + " (" + shortname + ")." + NEW_LINE + "The sprite couldn't be recognized.")
                    } else if (colors.size > 256) {
                        val pixels = SpriteTool.render(imagePixels, colors, palette?.paletteFormat?.initialBlankPages ?: 0, 0)
                        fs.saveImage(pixels, imagePixels.size, name)
                    } else {
                        val initialBlankPages = palette?.paletteFormat?.initialBlankPages ?: 0
                        if (initialBlankPages > 0) {
                            for (x in 0 until imagePixels.size) {
                                for (y in 0 until imagePixels[x].size) {
                                    imagePixels[x][y] = Math.max(0, imagePixels[x][y] - (initialBlankPages shl 4))
                                }
                            }
                        }
                        fs.saveImage(imagePixels, colors, name)
                    }
                } else {
                    viewPort.raiseError("Could not export image " + i + " (" + shortname + ")." + NEW_LINE + "Another image with that named exists.")
                }
            }
        }
    }
    private fun executeSpriteToolCommand(fs: IFileSystem, command: ICommand) { /*@DONE SpriteElementViewModel.ExecuteSpriteToolCommand/1 cs:172-185*/
        val spriteTool = viewPort.tools!!.spriteTool!!
        val sRun = getRun()
        if (sRun != null) {
            val palettes = sRun.findRelatedPalettes(model, start, format.paletteHint).toList()
            var palette = palettes.firstOrNull()
            if (palettes.size > 1 && palettes.size > currentPalette) palette = palettes[currentPalette]
            spriteTool.spriteAddress = sRun.start
            spriteTool.spritePage = currentPage
            if (palette != null) spriteTool.paletteAddress = palette.start
            spriteTool.palettePage = currentPalette
            if (palettes.size > currentPalette && palettes[currentPalette].pages == sRun.pages) spriteTool.palettePage = currentPage
            command.execute(fs)
        }
    }
    override val showPageControls: Boolean
        get() { /*@DONE SpriteElementViewModel.ShowPageControls.get cs:189-189*/
            return super.showPageControls || canExecuteImageEditor()
        }
    constructor(viewPort: ViewPort, parentName: String, runFormat: String, format: SpriteFormat, itemAddress: Int) : super(viewPort, parentName, runFormat, itemAddress) { /*@DONE SpriteElementViewModel.<init>/1 cs:191-200*/
        this.format = format
        this.runFormat = runFormat
        val run = getRun()
        pages = run?.pages ?: pages
        updateAvailablePalettes(start)
        this.bind("visible") { _, _ ->
            if (visible && needsUpdate) updateTiles(start, currentPage, false)
        }
    }
    private fun updateAvailablePalettes(start: Int) { /*@DONE SpriteElementViewModel.UpdateAvailablePalettes/1 cs:202-218*/
        val run = getRun(start)
        var index = 0
        for (palette in run.findRelatedPalettes(viewPort.model, start)) {
            val name = ViewPort.buildElementName(viewPort.model, palette.start)
            val ps = SelectionViewModel()
            ps.name = name
            ps.selected = index == _currentPalette
            ps.index = index
            ps.bind("selected") { o, _ -> if (o.selected) currentPalette = o.index }
            if (index < paletteSelection.size) {
                paletteSelection[index] = ps
            } else {
                paletteSelection.add(ps)
            }
            index += 1
        }
        while (paletteSelection.size > index) paletteSelection.removeAt(paletteSelection.size - 1)
        maxPalette = paletteSelection.size - 1
    }
    var paletteSelection: ObservableCollection<SelectionViewModel> = /*@INITAUTO SpriteElementViewModel.PaletteSelection cs:220-220*/ ObservableCollection() /*@ENDINIT*/
        private set
    private fun updatePaletteSelection() { /*@DONE SpriteElementViewModel.UpdatePaletteSelection/1 cs:221-223*/
        for (i in 0..maxPalette) paletteSelection[i].selected = i == _currentPalette
    }
    protected override fun tryCopy(other: PagedElementViewModel): Boolean { /*@DONE SpriteElementViewModel.TryCopy/1 cs:230-243*/
        val that = other as? SpriteElementViewModel ?: return false
        format = that.format
        runFormat = that.runFormat
        updateAvailablePalettes(that.start)
        start = other.start
        pages = that.pages
        notifyPropertiesChanged("canExportMany", "canExportAll", "canExportManyOrAll", "hasMultiplePalettes")
        importImage?.raiseCanExecuteChanged()
        exportImage?.raiseCanExecuteChanged()
        exportImages?.raiseCanExecuteChanged()
        errorText = ""
        return true
    }
    protected override fun pageChanged() { /*@DONE SpriteElementViewModel.PageChanged/1 cs:245-245*/
        updateTiles(currentPage)
    }
    private var needsUpdate: Boolean = /*@INITAUTO SpriteElementViewModel.needsUpdate cs:247-247*/ false /*@ENDINIT*/
    fun updateTiles(pageOption: Int? = null) { /*@DONE SpriteElementViewModel.UpdateTiles/1 cs:248-259*/
        // TODO support multiple layers
        val page = pageOption ?: currentPage

        val tilemapRun = getRun() as? LzTilemapRun
        tilemapRun?.findMatchingTileset(model)

        if (visible) {
            updateTiles(start, page, false)
        } else {
            needsUpdate = true
        }
    }
    protected override fun canExecuteAddPage(): Boolean { /*@DONE SpriteElementViewModel.CanExecuteAddPage/1 cs:261-266*/
        val run = getRun()
        return run is LzSpriteRun && currentPage == run.pages - 1 && run.findRelatedPalettes(model).all { pal -> pal.pages == run.pages && pal is LzPaletteRun }
    }
    protected override fun canExecuteDeletePage(): Boolean { /*@DONE SpriteElementViewModel.CanExecuteDeletePage/1 cs:268-272*/
        val run = getRun()
        return run is LzSpriteRun && pages > 1 && run.findRelatedPalettes(model).all { pal -> pal.pages == run.pages && pal is LzPaletteRun }
    }
    private var lastPixels: Array<IntArray>? = null
    private var lastColors: List<Short> = ArrayList()
    private fun updateTiles(start: Int, page: Int, exitPaletteSearchEarly: Boolean) { /*@DONE SpriteElementViewModel.UpdateTiles/2 cs:276-305*/
        needsUpdate = false
        val run = getRun() ?: return

        var tableIndex = -1
        val tableRun = model.getNextRun(this.start) as? ITableRun
        if (tableRun != null) {
            tableIndex = tableRun.convertByteOffsetToArrayOffset(this.start).elementIndex
        }

        val pixels = run.getPixels(viewPort.model, page, tableIndex)
        val paletteFormat = Ref<PaletteFormat>(PaletteFormat())
        val palette = getDesiredPalette(start, page, exitPaletteSearchEarly, paletteFormat)
        if (pixels === lastPixels && palette === lastColors) return
        lastPixels = pixels
        lastColors = palette
        if (run !is LzTilemapRun) paletteFormat.value = PaletteFormat()

        pixelData = SpriteTool.render(pixels, palette, paletteFormat.value.initialBlankPages, currentPage)

        notifyPropertyChanged("pixelWidth")
        notifyPropertyChanged("pixelHeight")
        notifyPropertyChanged("pixelData")
        if (SpriteTool.maxSpriteWidth < pixelWidth) {
            spriteScale = .5
        } else if (SpriteTool.maxSpriteWidth > pixelWidth * 2) {
            spriteScale = 2.0
        } else {
            spriteScale = 1.0
        }
        notifyPropertyChanged("spriteScale")
    }
    private fun getDesiredPalette(start: Int, page: Int, exitEarly: Boolean, paletteFormat: Ref<PaletteFormat>): List<Short> { /*@DONE SpriteElementViewModel.GetDesiredPalette/1 cs:310-325*/
        paletteFormat.value = PaletteFormat()

        val sRun = getRun()
        if (sRun != null) {
            val palettes = sRun.findRelatedPalettes(model, this.start, format.paletteHint).toList()
            var palette = palettes.firstOrNull()
            if (palettes.size > 1 && palettes.size > currentPalette) palette = palettes[currentPalette]
            if (palette != null) {
                paletteFormat.value = palette.paletteFormat
                val all = palette.allColors(model)
                if (all != null) return all
            }
            if (sRun.spriteFormat.bitsPerPixel == 2) return TileViewModel.createDefaultPalette(4).toList()
            if (sRun.spriteFormat.bitsPerPixel == 1) return TileViewModel.createDefaultPalette(2).toList()
        }
        return TileViewModel.createDefaultPalette(0x10).toList()
    }
    private fun tryGetPaletteFromComboBoxInMatchingTable(start: Int, comboBox: ComboBoxArrayElementViewModel, page: Int, colors: Ref<List<Short>?>): Boolean { /*@DONE SpriteElementViewModel.TryGetPaletteFromComboBoxInMatchingTable/1 cs:333-362*/
        colors.value = null

        // figure out the current index into the table
        val myRun = model.getNextRun(start) as ITableRun
        val arrayIndex = (start - myRun.start) / myRun.elementLength

        // figure out the name of the palette table
        val indexRun = model.getNextRun(comboBox.start) as ITableRun
        val offsets = indexRun.convertByteOffsetToArrayOffset(comboBox.start)
        if (offsets.segmentOffset != 0) return false // for now, require that
        val segment = indexRun.elementContent[offsets.segmentIndex] as? ArrayRunEnumSegment ?: return false
        val paletteTable = segment.enumName

        // figure out which element into the palette run from the value in the index run
        val paletteIndex = model.readMultiByteValue(indexRun.start + indexRun.elementLength * arrayIndex, segment.length)

        // find the pointer to our palette
        val array = model.getNextRun(model.getAddressFromAnchor(viewPort.currentChange, -1, paletteTable)) as? ArrayRun ?: return false
        if (array.elementContent[0].type != ElementContentType.Pointer) return false
        val pointer = array.start + array.elementLength * paletteIndex

        // go get the palette that we want
        val paletteAddress = model.readPointer(pointer)
        val palRun = model.getNextRun(paletteAddress) as? IPaletteRun ?: return false

        // return the values from the palette
        colors.value = palRun.getPalette(model, page)
        return true
    }
    /*@END SpriteElementViewModel*/
}

open class TileViewModel : ViewModelCore { // cs:365-396
    var dataStore: ByteArray = ByteArray(0)
        private set
    var start: Int = 0
        private set
    var palette: List<Short> = ArrayList()
        private set
    constructor(data: ByteArray, start: Int, byteLength: Int, palette: List<Short>?) { /*@DONE TileViewModel.<init>/1 cs:374-383*/
        dataStore = data
        this.start = start
        if (palette != null) {
            this.palette = palette
            return
        }

        val desiredCount = Math.pow(2.0, (byteLength / 8).toDouble()).toInt()
        this.palette = createDefaultPalette(desiredCount).toList()
    }
    companion object {
        fun createDefaultPalette(desiredCount: Int): ShortArray { /*@DONE TileViewModel.CreateDefaultPalette/1 cs:387-395*/
            val palette = ShortArray(desiredCount)
            for (i in 0 until desiredCount) {
                val shade = 0b11111 * i / (desiredCount - 1)
                val color = (shade shl 10) or (shade shl 5) or shade
                palette[i] = color.toShort()
            }
            return palette
        }
        /*@END TileViewModel.Companion*/
    }
    /*@END TileViewModel*/
}
