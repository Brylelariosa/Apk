// Port of ViewModels/Map/MapTutorialsViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*

enum class Tutorial(val value: Int) { // cs:7-51
    MiddleClick_PanMap(0),
    ArrowKeys_PanMap(1),
    Wheel_ZoomMap(2),
    LeftClickBlock_SelectBlock(3),
    LeftClickMap_DrawBlock(4),
    ToolbarUndo_Undo(5),
    DoubleClick_PaintBlock(6),
    ControlClick_FillRect(7),
    EscapeKey_UnselectBlock(8),
    DragMap_SwapBlock(9),
    DragBlocks_SelectBlocks(10),
    BlockButton_EditBlocks(11),
    ClickTile_SelectTile(12),
    ClickBlock_DrawTile(13),
    FlipButton_FlipBlock(14),
    RightClickMap_SelectBlock(15),
    RightDragMap_SelectBlocks(16),
    LeftClick_SelectEvent(17),
    DoubleClick_FollowWarp(18),
    BackButton_GoBack(19),
    DragEvent_MoveEvent(20),
    ClickMap_UnselectEvent(21),
    DoubleClickEvent_SeeScript(22),
    EventButtons_CycleEvent(23),
    DragConnectionButtons_ResizeMap(24),
    RightClick_CreateConnection(25),
    DragButtons_AdjustConnection(26),
    ToolbarButton_EditBorderBlock(27),
    ToolbarButton_GotoWildData(28),
    ToolbarButton_EditMapHeader(29),
    ToolbarTemplate_CreateObject(30),
    ToolbarTemplate_CreateEvent(31),
    RightClick_WarpNewMap(32),
    ToolbarTemplate_ConfigureObject(33),
    SpaceBar_ShowBeneath(34),
    Ctrl_HideEvents(35);
    companion object {
        fun fromValue(value: Int): Tutorial = entries.first { it.value == value }
    }
    /*@END Tutorial*/
}

open class MapTutorialsViewModel : ViewModelCore { // cs:53-197
    var tutorials: ObservableCollection<MapTutorialViewModel> = /*@INITDONE MapTutorialsViewModel.Tutorials cs:59-59*/ ObservableCollection() /*@ENDINIT*/
        private set
    val completionPercent: String
        get() { /*@DONE MapTutorialsViewModel.CompletionPercent.get cs:62-65*/
            val completed = tutorials.count { tut -> !tut.incomplete }.toDouble()
            return String.format(java.util.Locale.US, "%.2f%%", completed / tutorials.size * 100.0)
        }
    val seeMore: Boolean
        get() { /*@DONE MapTutorialsViewModel.SeeMore.get cs:68-68*/
            return tutorials.count { tut -> tut.incomplete } > visibleCount
        }
    val completedTutorial = Event<EventArgs>()
    constructor() { /*@DONE MapTutorialsViewModel.<init>/1 cs:72-146*/
        // general navigation
        tutorials.add(MapTutorialViewModel(middleClick, "Move Map", "Middle-Click and drag to move the maps around on the screen."))
        tutorials.add(MapTutorialViewModel("ArrowKeys", "Move Map", "Use the arrow keys to move the maps around on the screen."))
        tutorials.add(MapTutorialViewModel(middleClick, "Zoom Map", "Use the scroll wheel to zoom in and out of the map. Zooming in will hide the border blocks."))

        // select block / draw / paint
        tutorials.add(MapTutorialViewModel(leftClick, "Select Block", "Click a block in the Blocks panel to select it."))
        tutorials.add(MapTutorialViewModel(leftClick, "Draw Block", "Click/Drag over the map to draw with the selected block."))
        tutorials.add(MapTutorialViewModel("UndoArrow", "Undo", "Use the Undo button in the toolbar to undo any mistakes."))
        tutorials.add(MapTutorialViewModel("FillBucket", "Paint Blocks", "Double-Click over the map to paint an area with the selected block."))
        tutorials.add(MapTutorialViewModel("CtrlKey", "Fill Rectangle", "Hold Control, then left-click and drag over an area to create a rectangle of blocks."))
        tutorials.add(MapTutorialViewModel("EscapeKey", "Unselect Block", "Press the escape key to unselect a block."))
        tutorials.add(MapTutorialViewModel(leftClick, "Move Block", "Click/Drag over the map with no selected block to move the blocks on the map."))
        tutorials.add(MapTutorialViewModel(leftClick, "Select Blocks", "Left-Click and drag on the Blocks panel to select multiple blocks. When multiple blocks are selected, you can draw, but not double-click fill."))

        // editing blocks
        tutorials.add(MapTutorialViewModel("RightAngleArrow", "Edit Block", "Blocks are made of Tiles in a 2x2 grid, with foreground and background layers. Select a block, then click 'Edit Block' in the Blocks panel to show the Tiles panel."))
        tutorials.add(MapTutorialViewModel(leftClick, "Select Tile", "Click a tile in the Tiles panel to select it."))
        tutorials.add(MapTutorialViewModel(leftClick, "Draw Tile", "Click on a block's foreground or background tile at the top of the Blocks panel to replace it with your selected tile/palette."))
        tutorials.add(MapTutorialViewModel("ArrowsLeftRight", "Flip Tile", "Click the arrows next to the selected block's foreground/background tile to flip that tile vertically or horizontally."))

        // right-click map
        tutorials.add(MapTutorialViewModel(rightClick, "Select Block", "Right-Click the map to select that block."))
        tutorials.add(MapTutorialViewModel(rightClick, "Select Blocks", "Right-Click and drag on the map to select multiple blocks. When multiple blocks are selected, you can draw, but not paint."))

        // editing events
        tutorials.add(MapTutorialViewModel(leftClick, "Select Event", "Click an event (character, blue warp, green script, or red signpost) in the map to select it. Selecting an event will unselect any active blocks."))
        tutorials.add(MapTutorialViewModel("LeftMouseDoubleClick", "Follow Warp", "Double-Click on a warp event to go to the map it references."))
        tutorials.add(MapTutorialViewModel("LeftArrow", "Go Back", "Use the back arrow in the toolbar to return to the previous map or data."))
        tutorials.add(MapTutorialViewModel("FourDirectionArrows", "Move Event", "Drag an event to move it on the map."))
        tutorials.add(MapTutorialViewModel(leftClick, "Unselect Event", "Click on any part of the map to unselect the event."))
        tutorials.add(MapTutorialViewModel("LeftMouseDoubleClick", "See Script", "Double-Click on an object, script tile, or signpost to jump to its script in the other tab."))
        tutorials.add(MapTutorialViewModel("ArrowsLeftRight", "Cycle Events", "With an event selected, use the Group buttons at the top of the Events panel to change between the 5 groups of events:\nObjects, Warps, Scripts, Sigpost, and Fly."))

        // connections
        tutorials.add(MapTutorialViewModel("ArrowsLeftRight", "Resize Map", "Use the arrows on the four edges of the map to resize the map."))
        tutorials.add(MapTutorialViewModel(rightClick, "New Connection", "Right-click an edge arrow to connect a new or existing map."))
        tutorials.add(MapTutorialViewModel("ArrowsLeftRight", "Edit Connection", "Use the arrows on the corners of the map to adjust the offset between the two maps."))

        // other toolbar options
        tutorials.add(MapTutorialViewModel("RightAngleArrow", "Edit Border Block", "Each map has a 'border block' that shows for anything onscreen that's out of bounds of the map. Click the button in the toolbar to edit it."))
        tutorials.add(MapTutorialViewModel("OutAngleArrow", "Goto Wild Data", "Click this button in the toolbar to create or edit the wild pokemon that appear in the grass, when surfing, when breaking trees/rocks, or when fishing."))
        tutorials.add(MapTutorialViewModel("LeftAngleArrow", "Edit Map Header", "Each map has additional information, such as its music and weather. Click the button in the toolbar to edit it."))
        tutorials.add(MapTutorialViewModel("Selection", "Create Object", "Drag the character sprite from the top toolbar to create object events."))
        tutorials.add(MapTutorialViewModel("Selection", "Create Event", "Drag the Blue/Green/Red squares from the top toolbar to create warp events, script events, and signpost events."))
        tutorials.add(MapTutorialViewModel(rightClick, "Warp New Map", "Right-Click a warp to create a new map to warp to."))
        tutorials.add(MapTutorialViewModel("Settings", "Configure Object", "Click the gear icon next to the character sprite to choose what type of object you want to add."))

        // additions
        tutorials.add(MapTutorialViewModel("Remove", "Show Beneath", "Hold Spacebar to see the map from the Dive/Emerge connection. Double-click to switch to that map."))
        tutorials.add(MapTutorialViewModel("CtrlKey", "Hide Events", "Hold Control to hide events. You can right-click to select a block under an event."))

        reset()
        for (i in 0 until tutorials.size) {
            tutorials[i].requestClose += { sender, e -> completeNoCheck(Tutorial.fromValue(tutorials.indexOfFirst { it === sender })) }
            tutorials[i].index = i + 1
        }
    }
    fun reset() { /*@DONE MapTutorialsViewModel.Reset/1 cs:148-153*/
        for (i in 0 until tutorials.size) {
            tutorials[i].incomplete = true
            tutorials[i].targetPosition = i.toDouble()
        }
    }
    fun load(metadata: Array<String>) { /*@DONE MapTutorialsViewModel.Load/1 cs:155-163*/
        val line = metadata.firstOrNull { str -> str.startsWith("MapTutorials = '''") }
        if (line == null) return
        val content = line.split("'''")[1]
        for (i in 0 until tutorials.size) {
            if (i >= content.length || content[i] != '1') continue
            complete(Tutorial.fromValue(i))
        }
    }
    fun serialize(): String { /*@DONE MapTutorialsViewModel.Serialize/1 cs:165-169*/
        val tuts = CharArray(tutorials.size)
        for (i in 0 until tutorials.size) tuts[i] = if (tutorials[i].incomplete) '0' else '1'
        return "MapTutorials = '''" + String(tuts) + "'''"
    }
    fun dismissAll() { /*@DONE MapTutorialsViewModel.DismissAll/1 cs:171-178*/
        for (i in 0 until tutorials.size) {
            if (!tutorials[i].incomplete) continue
            tutorials[i].incomplete = false
            tutorials[i].triggerAnimation()
        }
        notifyPropertyChanged("completionPercent")
    }
    fun complete(id: Tutorial) { /*@DONE MapTutorialsViewModel.Complete/1 cs:180-185*/
        val index = id.value
        if (!tutorials[index].incomplete) return
        completeNoCheck(id)
        completedTutorial(tutorials[index], EventArgs.empty)
    }
    private fun completeNoCheck(id: Tutorial) { /*@DONE MapTutorialsViewModel.CompleteNoCheck/1 cs:187-196*/
        val index = id.value
        if (!tutorials[index].incomplete) return
        tutorials[index].incomplete = false
        for (i in index + 1 until tutorials.size) {
            tutorials[i].targetPosition = tutorials[i].targetPosition - 1
            if (tutorials[i].incomplete && tutorials[i].targetPosition < visibleCount) tutorials[i].triggerAnimation()
        }
        notifyPropertiesChanged("completionPercent", "seeMore")
    }
    companion object {
        const val visibleCount: Int = 5
        const val leftClick: String = "LeftMouseButton"
        const val middleClick: String = "MiddleMouseButton"
        const val rightClick: String = "RightMouseButton"
        /*@END MapTutorialsViewModel.Companion*/
    }
    /*@END MapTutorialsViewModel*/
}

data class MapTutorialViewModel(val icon: String, val title: String, val content: String) : INotifyPropertyChanged { // cs:199-215
    val animateMovement = Event<EventArgs>()
    val requestClose = Event<EventArgs>()
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    private var _incomplete: Boolean = false
    private var target: Double = 0.0
    var incomplete: Boolean
        get() { /*@DONE MapTutorialViewModel.Incomplete.get cs:206-206*/
            return _incomplete
        }
        set(value) { /*@DONE MapTutorialViewModel.Incomplete.set cs:206-206*/
            if (_incomplete == value) return
            val old = _incomplete
            _incomplete = value
            propertyChanged(this, ExtendedPropertyChangedEventArgs(old, "incomplete"))
        }
    var targetPosition: Double
        get() { /*@DONE MapTutorialViewModel.TargetPosition.get cs:207-207*/
            return target
        }
        set(value) { /*@DONE MapTutorialViewModel.TargetPosition.set cs:207-207*/
            if (target == value) return
            val old = target
            target = value
            propertyChanged(this, ExtendedPropertyChangedEventArgs(old, "targetPosition"))
            notifyTopEdge()
        }
    val topEdge: Double
        get() { /*@DONE MapTutorialViewModel.TopEdge.get cs:208-208*/
            return targetPosition * 90
        }
    var index: Int = 0
    val indexText: String
        get() { /*@DONE MapTutorialViewModel.IndexText.get cs:210-210*/
            return "" + index + " of 36"
        }
    fun triggerAnimation() { /*@DONE MapTutorialViewModel.TriggerAnimation/1 cs:212-212*/
        animateMovement(this, EventArgs.empty)
    }
    fun close() { /*@DONE MapTutorialViewModel.Close/1 cs:214-214*/
        requestClose(this, EventArgs.empty)
    }
    /*@ADD MapTutorialViewModel#maptutorials.txt*/
    private fun notifyTopEdge() {
        // TopEdge is derived from TargetPosition: let bindings know it moved too.
        propertyChanged(this, PropertyChangedEventArgs("topEdge"))
    }
    /*@ENDADD MapTutorialViewModel#maptutorials.txt*/
    /*@END MapTutorialViewModel*/
}
