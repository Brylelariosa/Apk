// Port of ViewModels/Tools/PythonButtonElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class PythonButtonElementViewModel : ViewModelCore, IArrayElementViewModel { // cs:6-65
    private lateinit var viewPort: ViewPort
    private lateinit var segment: ArrayRunPythonButtonSegment
    private var elementAddress: Int = 0
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE PythonButtonElementViewModel.Theme.get cs:12-12*/
            return _theme
        }
        set(value) { /*@DONE PythonButtonElementViewModel.Theme.set cs:12-12*/
            set(_theme, value, "theme", { _theme = it })
        }
    private var _visible: Boolean = false
    override var visible: Boolean
        get() { /*@DONE PythonButtonElementViewModel.Visible.get cs:15-15*/
            return _visible
        }
        set(value) { /*@DONE PythonButtonElementViewModel.Visible.set cs:15-15*/
            set(_visible, value, "visible", { _visible = it })
        }
    private var _name: String = ""
    var name: String
        get() { /*@DONE PythonButtonElementViewModel.Name.get cs:18-18*/
            return _name
        }
        set(value) { /*@DONE PythonButtonElementViewModel.Name.set cs:18-18*/
            set(_name, value, "name", { _name = it })
        }
    private var _tooltip: String? = null
    val tooltip: String
        get() { /*@DONE PythonButtonElementViewModel.Tooltip.get cs:22-28*/
            if (_tooltip != null) return _tooltip ?: ""
            if (viewPort.pythonTool!!.hasFunction(segment.functionName)) {
                _tooltip = viewPort.pythonTool!!.getComment(segment.functionName)
            }
            return _tooltip ?: ""
        }
    override val isInError: Boolean
        get() { /*@DONE PythonButtonElementViewModel.IsInError.get cs:31-31*/
            return false
        }
    override val errorText: String?
        get() { /*@DONE PythonButtonElementViewModel.ErrorText.get cs:32-32*/
            return ""
        }
    override val zIndex: Int
        get() { /*@DONE PythonButtonElementViewModel.ZIndex.get cs:33-33*/
            return 0
        }
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    constructor(viewPort: ViewPort, segment: ArrayRunPythonButtonSegment, elementAddress: Int) { /*@DONE PythonButtonElementViewModel.<init>/1 cs:37-42*/
        this.viewPort = viewPort
        this.segment = segment
        this.elementAddress = elementAddress
        _name = segment.name
    }
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE PythonButtonElementViewModel.TryCopy/1 cs:44-51*/
        if (other is PythonButtonElementViewModel && other.segment.name == name) {
            name = other.segment.name
            elementAddress = other.elementAddress
            return true
        }
        return false
    }
    fun canExecute(): Boolean { /*@DONE PythonButtonElementViewModel.CanExecute/1 cs:53-53*/
        return viewPort.pythonTool!!.hasFunction(segment.functionName)
    }
    fun execute() { /*@DONE PythonButtonElementViewModel.Execute/1 cs:55-64*/
        val tableRun = viewPort.model.getNextRun(elementAddress) as? ITableRun
        if (tableRun == null) return
        val elementIndex = tableRun.convertByteOffsetToArrayOffset(elementAddress).elementIndex
        viewPort.pythonTool!!.addVariable("element", ModelTable(viewPort.model, tableRun) { viewPort.currentChange }[elementIndex])
        val error = viewPort.pythonTool!!.runPythonScript(segment.functionName + "(element)")
        if (error.hasError && !error.isWarning) {
            viewPort.raiseError(error.errorMessage ?: "")
        }
        viewPort.refresh()
    }
    /*@END PythonButtonElementViewModel*/
}
