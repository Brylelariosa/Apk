// Port of ViewModels/Visitors/DataClear.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.visitors

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class DataClear : IDataFormatVisitor { // cs:13-84
    private lateinit var buffer: IDataModel
    private lateinit var currentChange: ModelDelta
    private var index: Int = 0
    constructor(data: IDataModel, delta: ModelDelta, index: Int) { /*@DONE DataClear.<init>/1 cs:18-22*/
        buffer = data
        currentChange = delta
        this.index = index
    }
    override fun visit(dataFormat: Undefined, data: Int) { /*@DONE DataClear.Visit/1 cs:24-24*/
        // undefined cells have nothing to clear
    }
    override fun visit(dataFormat: None, data: Int) { /*@DONE DataClear.Visit/2 cs:26-26*/
        currentChange.changeData(buffer, index, 0xFF)
    }
    override fun visit(dataFormat: UnderEdit, data: Int) { /*@DONE DataClear.Visit/3 cs:28-28*/
        throw NotImplementedException()
    }
    override fun visit(pointer: Pointer, data: Int) { /*@DONE DataClear.Visit/4 cs:30-33*/
        val start = index - pointer.position
        buffer.writeValue(currentChange, start, 0)
    }
    override fun visit(anchor: Anchor, data: Int) { /*@DONE DataClear.Visit/5 cs:35-35*/
        anchor.originalFormat!!.visit(this, data)
    }
    override fun visit(sprite: SpriteDecorator, data: Int) { /*@DONE DataClear.Visit/6 cs:37-37*/
        sprite.originalFormat!!.visit(this, data)
    }
    override fun visit(decorator: StreamEndDecorator, data: Int) { /*@DONE DataClear.Visit/7 cs:39-39*/
        decorator.originalFormat!!.visit(this, data)
    }
    override fun visit(pcs: PCS, data: Int) { /*@DONE DataClear.Visit/8 cs:41-41*/
        currentChange.changeData(buffer, index, 0xFF)
    }
    override fun visit(pcs: EscapedPCS, data: Int) { /*@DONE DataClear.Visit/9 cs:43-43*/
        currentChange.changeData(buffer, index, 0xFF)
    }
    override fun visit(pcs: ErrorPCS, data: Int) { /*@DONE DataClear.Visit/10 cs:45-45*/
        currentChange.changeData(buffer, index, 0xFF)
    }
    override fun visit(ascii: Ascii, data: Int) { /*@DONE DataClear.Visit/11 cs:47-47*/
        currentChange.changeData(buffer, index, 0xFF)
    }
    override fun visit(braille: Braille, data: Int) { /*@DONE DataClear.Visit/12 cs:49-49*/
        currentChange.changeData(buffer, index, 0xFF)
    }
    override fun visit(integer: Integer, data: Int) { /*@DONE DataClear.Visit/13 cs:51-51*/
        buffer.writeMultiByteValue(index, integer.length, currentChange, 0)
    }
    override fun visit(integerEnum: IntegerEnum, data: Int) { /*@DONE DataClear.Visit/14 cs:53-53*/
        buffer.writeMultiByteValue(index, integerEnum.length, currentChange, 0)
    }
    override fun visit(integerHex: IntegerHex, data: Int) { /*@DONE DataClear.Visit/15 cs:55-55*/
        buffer.writeMultiByteValue(index, integerHex.length, currentChange, 0)
    }
    override fun visit(section: EggSection, data: Int) { /*@DONE DataClear.Visit/16 cs:57-57*/
        buffer.writeMultiByteValue(index, 2, currentChange, EggMoveRun.magicNumber)
    }
    override fun visit(item: EggItem, data: Int) { /*@DONE DataClear.Visit/17 cs:59-59*/
        buffer.writeMultiByteValue(index, 2, currentChange, 0x0000)
    }
    override fun visit(item: PlmItem, data: Int) { /*@DONE DataClear.Visit/18 cs:61-61*/
        buffer.writeMultiByteValue(index, 2, currentChange, 0x0200)
    }
    override fun visit(array: BitArray, data: Int) { /*@DONE DataClear.Visit/19 cs:63-63*/
        buffer.writeMultiByteValue(index, array.length, currentChange, 0x00)
    }
    override fun visit(word: MatchedWord, data: Int) { /*@DONE DataClear.Visit/20 cs:65-65*/
        visit(None.instance, data)
    }
    override fun visit(endStream: EndStream, data: Int) { /*@DONE DataClear.Visit/21 cs:67-71*/
        for (i in 0 until endStream.length) {
            currentChange.changeData(buffer, endStream.source + i, 0xFF)
        }
    }
    override fun visit(lz: LzMagicIdentifier, data: Int) { /*@DONE DataClear.Visit/22 cs:73-73*/
        visit(None.instance, data)
    }
    override fun visit(lz: LzGroupHeader, data: Int) { /*@DONE DataClear.Visit/23 cs:75-75*/
        visit(None.instance, data)
    }
    override fun visit(lz: LzCompressed, data: Int) { /*@DONE DataClear.Visit/24 cs:77-77*/
        buffer.writeMultiByteValue(index, 2, currentChange, 0xFFFF)
    }
    override fun visit(lz: LzUncompressed, data: Int) { /*@DONE DataClear.Visit/25 cs:79-79*/
        visit(None.instance, data)
    }
    override fun visit(color: UncompressedPaletteColor, data: Int) { /*@DONE DataClear.Visit/26 cs:81-81*/
        buffer.writeMultiByteValue(index, 2, currentChange, 0xFFFF)
    }
    override fun visit(tuple: Tuple, data: Int) { /*@DONE DataClear.Visit/27 cs:83-83*/
        buffer.writeMultiByteValue(index, tuple.length, currentChange, -1)
    }
    /*@END DataClear*/
}
