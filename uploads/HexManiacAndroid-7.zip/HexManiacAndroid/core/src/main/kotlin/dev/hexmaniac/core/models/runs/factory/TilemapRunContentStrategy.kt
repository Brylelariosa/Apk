// Port of Models/Runs/Factory/TilemapRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class TilemapRunContentStrategy : RunStrategy { // cs:5-49
    private var _format: TilemapFormat = TilemapFormat()
    constructor(format: TilemapFormat) { /*@DONE TilemapRunContentStrategy.<init>/1 cs:8-10*/
        this._format = format
    }
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE TilemapRunContentStrategy.LengthForNewRun/1 cs:12-14*/
        return _format.tileHeight * _format.tileWidth * 2
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE TilemapRunContentStrategy.Matches/1 cs:16-22*/
        if (run !is TilemapRun) return false
        if (run.format.tileWidth != _format.tileWidth) return false
        if (run.format.tileHeight != _format.tileHeight) return false
        if (run.format.bitsPerPixel != _format.bitsPerPixel) return false
        return run.format.expectedUncompressedLength == _format.expectedUncompressedLength
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE TilemapRunContentStrategy.TryAddFormatAtDestination/1 cs:24-28*/
        val newRun = TilemapRun(owner, destination, _format)
        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, newRun)
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE TilemapRunContentStrategy.TryParseData/1 cs:30-36*/
        val error = SpriteRunContentStrategy.isValid(_format)
        if (error.hasError) return error
        val newRun = TilemapRun(model, dataIndex, _format)
        run.value = newRun
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE TilemapRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:38-42*/
        val newRun = TilemapRun(model, run.value.start, _format, run.value.pointerSources)
        model.clearFormat(token, newRun.start, newRun.length)
        run.value = newRun
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE TilemapRunContentStrategy.WriteNewRun/1 cs:44-48*/
        val defaultData = ByteArray(_format.tileWidth * _format.tileHeight * 2)
        for (i in 0 until defaultData.size) token.changeData(owner, destination + i, defaultData[i].toInt() and 0xFF)
        return TilemapRun(owner, destination, _format)
    }
    /*@END TilemapRunContentStrategy*/
}
