// Port of Models/Runs/Sprites/LzSpriteRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class LzSpriteRun : PagedLZRun, ISpriteRun { // cs:6-122
    final override var spriteFormat: SpriteFormat = SpriteFormat()
        private set
    final override var formatString: String = ""
        private set
    override val pages: Int
        get() { /*@DONE LzSpriteRun.Pages.get cs:12-15*/
            val length = model!!.readMultiByteValue(start + 1, 3)
            return length / spriteFormat.expectedByteLength
        }
    override val supportsImport: Boolean
        get() { /*@DONE LzSpriteRun.SupportsImport.get cs:18-18*/
            return true
        }
    override val supportsEdit: Boolean
        get() { /*@DONE LzSpriteRun.SupportsEdit.get cs:19-19*/
            return true
        }
    protected override val uncompressedPageLength: Int
        get() { /*@DONE LzSpriteRun.UncompressedPageLength.get cs:21-21*/
            return spriteFormat.expectedByteLength
        }
    constructor(spriteFormat: SpriteFormat, data: IDataModel, start: Int, sources: SortedSpan<Int>? = null) : super(data, start, spriteFormat.allowLengthErrors, sources) { /*@DONE LzSpriteRun.<init>/1 cs:23-30*/
        this.spriteFormat = spriteFormat
        if (spriteFormat.expectedByteLength > decompressedLength) invalidateLength()
        var hintContent = ""
        if (!spriteFormat.paletteHint.isNullOrEmpty()) hintContent += "|" + spriteFormat.paletteHint
        formatString = "`lzs" + spriteFormat.bitsPerPixel + "x" + spriteFormat.tileWidth + "x" + spriteFormat.tileHeight + hintContent + "`"
    }
    private var lastFormatRequested: Int = /*@INITDONE LzSpriteRun.lastFormatRequested cs:57-57*/ Int.MAX_VALUE /*@ENDINIT*/
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE LzSpriteRun.CreateDataFormat/1 cs:58-70*/
        val basicFormat = super.createDataFormat(data, index)
        if (!createForLeftEdge || data.spartanMode) return basicFormat
        if (lastFormatRequested < index) {
            lastFormatRequested = index
            return basicFormat
        }

        val sprite = data.currentCacheScope.getImage(this)
        val availableRows = (length - (index - start)) / expectedDisplayWidth
        lastFormatRequested = index
        return SpriteDecorator(basicFormat, sprite, expectedDisplayWidth, availableRows)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE LzSpriteRun.Clone/1 cs:72-72*/
        return LzSpriteRun(spriteFormat, model!!, start, newPointerSources)
    }
    override fun duplicate(format: SpriteFormat): ISpriteRun { /*@DONE LzSpriteRun.Duplicate/1 cs:74-74*/
        return LzSpriteRun(format, model!!, start, pointerSources)
    }
    override fun getData(): ByteArray { /*@DONE LzSpriteRun.GetData/1 cs:76-76*/
        return decompress(model!!, start, spriteFormat.allowLengthErrors) ?: ByteArray(0)
    }
    override fun getPixels(model: IDataModel, page: Int, tableIndex: Int): Array<IntArray>? { /*@DONE LzSpriteRun.GetPixels/1 cs:78-82*/
        val data = decompress(model, start, allowLengthErrors) ?: return null
        return SpriteRun.getPixels(data.asByteList(), spriteFormat.expectedByteLength * page, spriteFormat.tileWidth, spriteFormat.tileHeight, spriteFormat.bitsPerPixel)
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>): ISpriteRun { /*@DONE LzSpriteRun.SetPixels/1 cs:84-104*/
        val data = decompress(model, start, true) ?: return this
        val pageIndex = if (pages > 0) page % pages else 0

        val pageLength = spriteFormat.tileWidth * spriteFormat.tileHeight * 8 * spriteFormat.bitsPerPixel
        if (spriteFormat.bitsPerPixel == 4 && pixels[0][0] >= 0x10) {
            // this is a sprite, not a tileset/tilemap
            // erase the palette page data before inserting the colors
            val width = pixels.getLength(0)
            val height = pixels.getLength(1)
            for (x in 0 until width) for (y in 0 until height) pixels[x][y] = pixels[x][y] and 0xF
        }
        SpriteRun.setPixels(data, pageIndex * pageLength, pixels, spriteFormat.bitsPerPixel)

        val newModelData = compress(data.asByteList(), 0, data.size)
        var newRun: ISpriteRun = model.relocateForExpansion(token, this, newModelData.count)
        for (i in 0 until newModelData.count) token.changeData(model, newRun.start + i, newModelData[i])
        for (i in newModelData.count until length) token.changeData(model, newRun.start + i, 0xFF)
        newRun = LzSpriteRun(spriteFormat, model, newRun.start, newRun.pointerSources)
        model.observeRunWritten(token, newRun)
        return newRun
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, tiles: List<Array<IntArray>>): ISpriteRun { /*@DONE LzSpriteRun.SetPixels/2 cs:106-106*/
        return LzTilesetRun.setPixels(this, model, token, tiles) { newStart, sources -> LzSpriteRun(spriteFormat, model, newStart, sources) }
    }
    fun increaseHeight(tiles: Int, token: ModelDelta): LzSpriteRun { /*@DONE LzSpriteRun.IncreaseHeight/1 cs:108-121*/
        val m = model!!
        val data = decompress(m, start)!!
        val longerData = data + ByteArray(spriteFormat.expectedByteLength / spriteFormat.tileHeight * tiles)
        val newModelData = compress(longerData.asByteList(), 0, longerData.size)

        var newRun = m.relocateForExpansion(token, this, newModelData.count)
        for (i in 0 until newModelData.count) token.changeData(m, newRun.start + i, newModelData[i])
        for (i in newModelData.count until length) token.changeData(m, newRun.start + i, 0xFF)

        val newFormat = SpriteFormat(spriteFormat.bitsPerPixel, spriteFormat.tileWidth, spriteFormat.tileHeight + tiles, spriteFormat.paletteHint, spriteFormat.allowLengthErrors)
        newRun = LzSpriteRun(newFormat, m, newRun.start, newRun.pointerSources)
        m.observeRunWritten(token, newRun)
        return newRun
    }
    companion object {
        fun tryParseSpriteFormat(pointerFormat: String, spriteFormat: Ref<SpriteFormat>): Boolean { /*@DONE LzSpriteRun.TryParseSpriteFormat/1 cs:32-36*/
            spriteFormat.value = SpriteFormat()
            if (!pointerFormat.startsWith("`lzs") || !pointerFormat.endsWith("`")) return false
            return tryParseDimensions(pointerFormat, spriteFormat)
        }
        fun tryParseDimensions(format: String, spriteFormat: Ref<SpriteFormat>): Boolean { /*@DONE LzSpriteRun.TryParseDimensions/1 cs:38-55*/
            spriteFormat.value = SpriteFormat()
            val formatContent = format.substring(4, format.length - 1) // snip leading "`xxx" and trailing "`"
            val hintSplit = formatContent.split('|')
            val dimensionsAsText = hintSplit[0].split('x').toMutableList()
            if (dimensionsAsText.size != 3) return false
            val allowLengthErrors = dimensionsAsText[2].endsWith("!")
            if (allowLengthErrors) dimensionsAsText[2] = dimensionsAsText[2].substring(0, dimensionsAsText[2].length - 1)
            val bitsPerPixelRef = Ref(0)
            if (!tryParseInt(dimensionsAsText[0], bitsPerPixelRef)) return false
            val bitsPerPixel = bitsPerPixelRef.value
            if (!(bitsPerPixel == 1 || bitsPerPixel == 2 || bitsPerPixel == 4 || bitsPerPixel == 8)) return false
            val widthRef = Ref(0)
            if (!tryParseInt(dimensionsAsText[1], widthRef)) return false
            val width = widthRef.value
            val heightRef = Ref(0)
            if (!tryParseInt(dimensionsAsText[2], heightRef)) return false
            val height = heightRef.value
            if (width < 1 || height < 1) return false
            if (width > 100 || height > 1024) return false
            val hint = if (hintSplit.size == 2) hintSplit[1] else null
            spriteFormat.value = SpriteFormat(bitsPerPixel, width, height, hint, allowLengthErrors)
            return true
        }
        /*@END LzSpriteRun.Companion*/
    }
    /*@END LzSpriteRun*/
}
