// Port of ViewModels/ViewPort.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.system.ICommandExtensions.canAlwaysExecute
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.extendArray
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayStart
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayEnd
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.singleByteIntegerFormat
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.doubleByteIntegerFormat
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayAnchorSeparator
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.signedFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.hexFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.recordFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.tupleFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.colorFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.calculatedFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.pythonButtonFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.renderFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.commentFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.splitterFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.tryParse
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.trySearch
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseTilemapTable
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.findAllLoads
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.findAllCommands
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseSegments
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseSegments2
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.dataMatchesSegmentFormat
import dev.hexmaniac.core.models.runs.BaseRun.Companion.anchorStart
import dev.hexmaniac.core.models.runs.PCSRun.Companion.stringDelimeter
import dev.hexmaniac.core.models.runs.PCSRun.Companion.sharedFormatString
import dev.hexmaniac.core.models.runs.PCSRun.Companion.createPCSFormat
import dev.hexmaniac.core.models.runs.PointerRun.Companion.pointerStart
import dev.hexmaniac.core.models.runs.PointerRun.Companion.pointerEnd

open class ViewPort : ViewModelCore, IEditableViewPort { // cs:32-3469
    private val undoWrapper: StubCommand = /*@INITAUTO ViewPort.undoWrapper cs:40-41*/ StubCommand() /*@ENDINIT*/
    private val redoWrapper: StubCommand = /*@INITAUTO ViewPort.redoWrapper cs:40-42*/ StubCommand() /*@ENDINIT*/
    private val _clear: StubCommand = /*@INITAUTO ViewPort.clear cs:40-43*/ StubCommand() /*@ENDINIT*/
    private val _selectAll: StubCommand = /*@INITAUTO ViewPort.selectAll cs:40-44*/ StubCommand() /*@ENDINIT*/
    private val _copy: StubCommand = /*@INITAUTO ViewPort.copy cs:40-45*/ StubCommand() /*@ENDINIT*/
    private val _copyAddress: StubCommand = /*@INITAUTO ViewPort.copyAddress cs:40-46*/ StubCommand() /*@ENDINIT*/
    private val _copyBytes: StubCommand = /*@INITAUTO ViewPort.copyBytes cs:40-47*/ StubCommand() /*@ENDINIT*/
    private val _deepCopy: StubCommand = /*@INITAUTO ViewPort.deepCopy cs:40-48*/ StubCommand() /*@ENDINIT*/
    private val _isText: StubCommand = /*@INITAUTO ViewPort.isText cs:40-49*/ StubCommand() /*@ENDINIT*/
    private val threadlock: Any = /*@INITDONE ViewPort.threadlock cs:51-51*/ Any() /*@ENDINIT*/
    private var fs: IFileSystem? = null
    private var mapper: MapEditorViewModel? = null
    val hasValidMapper: Boolean
        get() { /*@DONE ViewPort.HasValidMapper.get cs:55-55*/
            return mapper?.isValidState ?: false
        }
    override val mapEditor: MapEditorViewModel?
        get() { /*@DONE ViewPort.MapEditor.get cs:56-56*/
            return if (hasValidMapper) mapper else null
        }
    lateinit var singletons: Singletons
        private set
    var pythonTool: PythonTool? = null
        private set
    override var initializationWorkload: Task<Unit> = Task.completedTask
    private var _distractionFreeMode: Boolean = false
    var distractionFreeMode: Boolean
        get() { /*@DONE ViewPort.DistractionFreeMode.get cs:65-65*/
            return _distractionFreeMode
        }
        set(value) { /*@DONE ViewPort.DistractionFreeMode.set cs:65-65*/
            set(_distractionFreeMode, value, "distractionFreeMode", { _distractionFreeMode = it })
        }
    private var currentView: Array<Array<HexElement?>> = emptyArray()
    private var exitEditEarly: Boolean = false
    private var withinComment: Boolean = false
    private var skipToNextGameCode: Boolean = false
    override val name: String
        get() { /*@DONE ViewPort.Name.get cs:71-76*/
            var name = Path.getFileNameWithoutExtension(fileName) ?: ""
            if (name.isEmpty()) name = "Untitled"
            if (history.hasDataChange) name += "*"
            return name
        }
    override var toolPanelWidth: Double = /*@INITAUTO ViewPort.ToolPanelWidth cs:79-79*/ 500.0 /*@ENDINIT*/
    private var _fileName: String = ""
    override var fileName: String
        get() { /*@DONE ViewPort.FileName.get cs:83-83*/
            return _fileName
        }
        set(value) { /*@DONE ViewPort.FileName.set cs:84-89*/
            if (tryUpdate(_fileName, value, "fileName") { _fileName = it } && _fileName.isNotEmpty()) {
                fullFileName = Path.getFullPath(_fileName)
                notifyPropertyChanged("name")
            }
        }
    private var _fullFileName: String = ""
    override var fullFileName: String
        get() { /*@DONE ViewPort.FullFileName.get cs:93-93*/
            return _fullFileName
        }
        set(value) { /*@DONE ViewPort.FullFileName.set cs:93-93*/
            tryUpdate(_fullFileName, value, "fullFileName") { _fullFileName = it }
        }
    private var _spartanMode: Boolean = false
    override var spartanMode: Boolean
        get() { /*@DONE ViewPort.SpartanMode.get cs:97-97*/
            return _spartanMode
        }
        set(value) { /*@DONE ViewPort.SpartanMode.set cs:98-102*/
            set(_spartanMode, value, "spartanMode", { _spartanMode = it }) {
                model.spartanMode = _spartanMode
            }
        }
    private lateinit var _scroll: ScrollRegion
    protected val scrollRegion: ScrollRegion
        get() { /*@DONE ViewPort.ScrollRegion.get cs:108-108*/
            return _scroll
        }
    override val previewScrollChanged = Event<EventArgs>()
    val dataStart: Int
        get() { /*@DONE ViewPort.DataStart.get cs:112-112*/
            return _scroll.dataStart
        }
    val dataLength: Int
        get() { /*@DONE ViewPort.DataLength.get cs:114-114*/
            return _scroll.dataLength - _scroll.dataStart
        }
    override var width: Int
        get() { /*@DONE ViewPort.Width.get cs:117-117*/
            return _scroll.width
        }
        set(value) { /*@DONE ViewPort.Width.set cs:118-120*/
            ModelCacheScope.createScope(model).using { selection.changeWidth(value) }
        }
    override var height: Int
        get() { /*@DONE ViewPort.Height.get cs:124-124*/
            return _scroll.height
        }
        set(value) { /*@DONE ViewPort.Height.set cs:125-125*/
            _scroll.height = value
        }
    override val minimumScroll: Int
        get() { /*@DONE ViewPort.MinimumScroll.get cs:128-128*/
            return _scroll.minimumScroll
        }
    override var scrollValue: Int
        get() { /*@DONE ViewPort.ScrollValue.get cs:131-131*/
            return _scroll.scrollValue
        }
        set(value) { /*@DONE ViewPort.ScrollValue.set cs:132-135*/
            previewScrollChanged(this, EventArgs.empty)
            ModelCacheScope.createScope(model).using { _scroll.scrollValue = value }
        }
    override val maximumScroll: Int
        get() { /*@DONE ViewPort.MaximumScroll.get cs:138-138*/
            return _scroll.maximumScroll
        }
    override val headers: ObservableCollection<RowHeader>?
        get() { /*@DONE ViewPort.Headers.get cs:140-140*/
            return _scroll.headers
        }
    override val columnHeaders: ObservableCollection<ColumnHeaderRow> = ObservableCollection()
    override val dataOffset: Int
        get() { /*@DONE ViewPort.DataOffset.get cs:142-142*/
            return _scroll.dataIndex
        }
    override val scroll: ICommand
        get() { /*@DONE ViewPort.Scroll.get cs:143-143*/
            return _scroll.scroll
        }
    override var useCustomHeaders: Boolean
        get() { /*@DONE ViewPort.UseCustomHeaders.get cs:146-146*/
            return _scroll.useCustomHeaders
        }
        set(value) { /*@DONE ViewPort.UseCustomHeaders.set cs:147-147*/
            ModelCacheScope.createScope(model).using { _scroll.useCustomHeaders = value }
        }
    override var allowSingleTableMode: Boolean
        get() { /*@DONE ViewPort.AllowSingleTableMode.get cs:151-151*/
            return _scroll.allowSingleTableMode
        }
        set(value) { /*@DONE ViewPort.AllowSingleTableMode.set cs:152-152*/
            _scroll.allowSingleTableMode = value
        }
    private fun scrollPropertyChanged(sender: Any?, e: PropertyChangedEventArgs) { /*@DONE ViewPort.ScrollPropertyChanged/1 cs:155-179*/
        if (e.propertyName == "dataIndex") {
            clearActiveEditBeforeSelectionChanges(selection, selection.selectionStart)
            refreshBackingData()
            if (e is ExtendedPropertyChangedEventArgs<*>) {
                val previous = e.oldValue as? Int
                if (previous != null && Math.abs(_scroll.dataIndex - previous) % width != 0) updateColumnHeaders()
            }
        } else if (e.propertyName != "dataLength") {
            notifyPropertyChanged(e)
        }

        if (e.propertyName == "width" || e.propertyName == "height" || e.propertyName == "allowSingleTableMode") {
            dispatcher.blockOnUIWork { refreshBackingData() }
        }

        if (e.propertyName == "width") {
            updateColumnHeaders()
            notifyPropertyChanged("scrollValue") // changing the Scroll's Width can mess with the ScrollValue: go ahead and notify
        }
        if (e.propertyName == "minimumScroll") notifyPropertyChanged("minimumScroll")
        if (e.propertyName == "maximumScroll") notifyPropertyChanged("maximumScroll")
        if (e.propertyName == "allowSingleTableMode") notifyPropertyChanged("allowSingleTableMode")
        if (e.propertyName == "dataLength") dispatcher.blockOnUIWork { refreshBackingData() }
    }
    private lateinit var selection: Selection
    private var _stretchData: Boolean = false
    override var stretchData: Boolean
        get() { /*@DONE ViewPort.StretchData.get cs:188-188*/
            return _stretchData
        }
        set(value) { /*@DONE ViewPort.StretchData.set cs:188-188*/
            set(_stretchData, value, "stretchData", { _stretchData = it })
        }
    override var autoAdjustDataWidth: Boolean
        get() { /*@DONE ViewPort.AutoAdjustDataWidth.get cs:189-189*/
            return selection.autoAdjustDataWidth
        }
        set(value) { /*@DONE ViewPort.AutoAdjustDataWidth.set cs:189-189*/
            selection.autoAdjustDataWidth = value
        }
    override var allowMultipleElementsPerLine: Boolean
        get() { /*@DONE ViewPort.AllowMultipleElementsPerLine.get cs:190-190*/
            return selection.allowMultipleElementsPerLine
        }
        set(value) { /*@DONE ViewPort.AllowMultipleElementsPerLine.set cs:190-190*/
            selection.allowMultipleElementsPerLine = value
        }
    override var selectionStart: Point
        get() { /*@DONE ViewPort.SelectionStart.get cs:193-193*/
            return selection.selectionStart
        }
        set(value) { /*@DONE ViewPort.SelectionStart.set cs:194-194*/
            selection.selectionStart = value
        }
    override var selectionEnd: Point
        get() { /*@DONE ViewPort.SelectionEnd.get cs:198-198*/
            return selection.selectionEnd
        }
        set(value) { /*@DONE ViewPort.SelectionEnd.set cs:199-199*/
            selection.selectionEnd = value
        }
    var preferredWidth: Int
        get() { /*@DONE ViewPort.PreferredWidth.get cs:203-203*/
            return selection.preferredWidth
        }
        set(value) { /*@DONE ViewPort.PreferredWidth.set cs:204-204*/
            selection.preferredWidth = value
        }
    private val _moveSelectionStart: StubCommand = /*@INITAUTO ViewPort.moveSelectionStart cs:206-206*/ StubCommand() /*@ENDINIT*/
    private val _moveSelectionEnd: StubCommand = /*@INITAUTO ViewPort.moveSelectionEnd cs:206-207*/ StubCommand() /*@ENDINIT*/
    val moveSelectionStart: ICommand
        get() { /*@DONE ViewPort.MoveSelectionStart.get cs:208-208*/
            return _moveSelectionStart
        }
    val moveSelectionEnd: ICommand
        get() { /*@DONE ViewPort.MoveSelectionEnd.get cs:209-209*/
            return _moveSelectionEnd
        }
    override val goto: ICommand?
        get() { /*@DONE ViewPort.Goto.get cs:210-210*/
            if (!::gotoCommand.isInitialized) {
                gotoCommand = stubCommandOf<Any>({ arg -> executeGoto(arg) }, { arg -> selection.goto?.canExecute(arg) ?: true })
            }
            return gotoCommand
        }
    override val back: ICommand
        get() { /*@DONE ViewPort.Back.get cs:211-211*/
            return selection.back
        }
    override val forward: ICommand
        get() { /*@DONE ViewPort.Forward.get cs:212-212*/
            return selection.forward
        }
    override val resetAlignment: ICommand
        get() { /*@DONE ViewPort.ResetAlignment.get cs:213-213*/
            return selection.resetAlignment
        }
    override val selectAll: ICommand
        get() { /*@DONE ViewPort.SelectAll.get cs:214-214*/
            return _selectAll
        }
    private lateinit var gotoCommand: StubCommand
    private fun executeGoto(arg: Any?) { /*@DONE ViewPort.ExecuteGoto/1 cs:217-328*/
        initializationWorkload.continueWith { _ ->
            // This needs to be synchronous to make it deterministic,
            // but needs to happen on the UI thread since it can update bound properties.
            dispatcher.blockOnUIWork {
                if (arg is String) {
                    var str: String = arg
                    _tools?.logTool?.logMessages?.add("Attempting to Goto Token: " + str)
                    val possibleMatches = model.getExtendedAutocompleteOptions(str) ?: emptyList()
                    if (possibleMatches.size == 1) {
                        str = possibleMatches[0]
                    } else if (possibleMatches.size > 1 && possibleMatches.all { match -> (model.getMatchedWords(match) ?: emptyList()).isNotEmpty() }) {
                        str = possibleMatches[0]
                    }

                    if (model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, str) == Pointer.null_) {
                        val words = (model.getMatchedWords(str) ?: emptyList()).toList()
                        if (words.size == 1) {
                            selection.goto?.execute(words[0])
                            val tabArgs = TabChangeRequestedEventArgs(this)
                            requestTabChange(mapper, tabArgs)
                            return@blockOnUIWork
                        } else if (words.size > 1) {
                            openSearchResultsTab(str, words.map { word -> ViewPortOpenSearchResultsTabShowSelectionTuple(word, word) })
                            return@blockOnUIWork
                        }
                    }

                    // goto prioritizes the map editor
                    // but only if the search is specific enough to match only one map name
                    // (multiple maps can have the same map name)
                    val maps = model.getMatchingMaps(str)
                    var gotoMap: MapInfo? = null
                    if (str.contains("-") && str.startsWith("maps.") && mapper != null) {
                        val searchText = str
                        val bestMaps = maps.filter { info -> info.name.contains(searchText) }
                        if (bestMaps.size == 1) gotoMap = bestMaps[0]
                    }
                    fun extractShortName(map: MapInfo): String {
                        val parts = map.name.split(".").toMutableList()
                        parts.removeAt(parts.size - 1)
                        return parts.drop(2).joinToString(".")
                    }
                    if (maps.size >= 1 && maps.all { m -> maps[0].name.contains(extractShortName(m)) } && mapper != null && !str.tryParseHex(Ref(0))) {
                        gotoMap = maps[0]
                    } else if (str.contains("(") && str.contains(")")) {
                        for (map in maps) {
                            if (map.name.skipCount(str) != 0) continue
                            gotoMap = map
                            break
                        }
                    }
                    if (gotoMap != null) {
                        val mapEditorTab = mapper!!
                        val previousMap = mapEditorTab.primaryMap
                        mapEditorTab.primaryMap = BlockMapViewModel(mapEditorTab.fileSystem, mapEditorTab.tutorials, this, mapEditorTab.format!!, mapEditorTab.templates, maps[0].group, maps[0].map)
                        val tabArgs = TabChangeRequestedEventArgs(mapEditorTab)
                        requestTabChange(this, tabArgs)
                        if (tabArgs.requestAccepted) {
                            // We actually changed tabs. Tell the map editor that it may want to change back to this tab on a 'back'
                            mapEditorTab.switchToViewPortOnNextBackNavigation()
                        } else {
                            // mapper tab was already requested
                            // add the previous map as the back point for the mapper
                            mapEditorTab.addBackNavigation(previousMap.mapID)
                        }
                        return@blockOnUIWork
                    }

                    // documentation check
                    val prefixes = arrayOf("scripting.overworld.reference.commands", "scripting.overworld.reference.specials")
                    if (str.contains("/")) {
                        val tokens = str.split("/")
                        if (tokens.size == 2 && tokens[0].length > 0 && tokens[1].length > 0) {
                            val group = tokens[0].lowercase()
                            val token = tokens[1].lowercase()
                            val matches = docs.filter { doc -> doc.label.lowercase().endsWith(token) && doc.label.contains(group) }
                            if (matches.size == 1) {
                                var bestTableMatch = Int.MAX_VALUE
                                for (text in possibleMatches) bestTableMatch = Math.min(bestTableMatch, text.skipCount(str))
                                if (bestTableMatch > matches[0].label.skipCount(str)) {
                                    openLink(matches[0].url)
                                    return@blockOnUIWork
                                }
                            }
                        }
                    } else {
                        val searchText = str
                        var matches = docs.filter { doc -> doc.label.equals(searchText, ignoreCase = true) }
                        for (prefix in prefixes) {
                            if (matches.size != 1) matches = docs.filter { doc -> doc.label.equals("documentation.$prefix.$searchText", ignoreCase = true) }
                        }
                        if (matches.size == 1) {
                            var bestTableMatch = Int.MAX_VALUE
                            for (text in possibleMatches) bestTableMatch = Math.min(bestTableMatch, text.skipCount(str))
                            if (bestTableMatch > matches[0].label.skipCount(str)) {
                                openLink(matches[0].url)
                                return@blockOnUIWork
                            }
                        }
                    }
                }

                if (arg is Int) {
                    _tools?.logTool?.logMessages?.add("Attempting to Goto Address: " + arg.toString())
                }

                if (arg is String) selection.goto?.execute(SelectionGotoArgs(arg, this))
                else selection.goto?.execute(arg)

                val tabArgs = TabChangeRequestedEventArgs(this)
                requestTabChange(mapper, tabArgs)
                if (!tabArgs.requestAccepted) mapper?.raiseRequestTabChange(tabArgs) // if this tab has been closed, ask the mapper to raise it
                if (tabArgs.requestAccepted) {
                    val mapEditorTab = mapper
                    if (mapEditorTab != null) selection.setJumpBackTab(mapEditorTab)
                    focusToolPanel(this, EventArgs.empty)
                }
            }
        }
    }
    fun setJumpBackTab(tab: ITabContent) { /*@DONE ViewPort.SetJumpBackTab/1 cs:330-330*/
        selection.setJumpBackTab(tab)
    }
    fun setJumpForwardTab(tab: ITabContent) { /*@DONE ViewPort.SetJumpForwardTab/1 cs:332-334*/
        selection.setJumpForwardTab(tab)
    }
    private fun clearActiveEditBeforeSelectionChanges(sender: Any?, location: Point) { /*@DONE ViewPort.ClearActiveEditBeforeSelectionChanges/1 cs:336-359*/
        if (location.x >= 0 && location.x < _scroll.width && location.y >= 0 && location.y < _scroll.height) {
            val element = this[location.x, location.y]
            val underEdit = element.format as? UnderEdit
            if (underEdit != null) {
                ModelCacheScope.createScope(model).using {
                    if (underEdit.currentText == "") {
                        val index = _scroll.viewPointToDataIndex(location)
                        val operation = DataClear(model, history.currentChange, index)
                        underEdit.originalFormat?.visit(operation, model[index])
                        clearEdits(location)
                    } else {
                        var endEdit = " "
                        if (underEdit.currentText.count { c -> c == stringDelimeter } % 2 == 1) endEdit = stringDelimeter.toString()
                        var originalFormat: IDataFormat? = underEdit.originalFormat
                        while (originalFormat is IDataFormatDecorator) originalFormat = originalFormat.originalFormat
                        if (underEdit.currentText.startsWith(EggMoveRun.groupStart) && (originalFormat is EggSection || originalFormat is EggItem)) endEdit = EggMoveRun.groupEnd
                        currentView[location.x][location.y] = HexElement(element.value, element.edited, underEdit.edit(endEdit))
                        if (!tryCompleteEdit(location)) clearEdits(location)
                    }
                }
            }
        }
    }
    private fun selectionPropertyChanged(sender: Any?, e: PropertyChangedEventArgs) { /*@DONE ViewPort.SelectionPropertyChanged/1 cs:361-373*/
        if (e.propertyName == "selectionEnd") {
            history.changeCompleted()
            updateColumnHeaderSelection()
        }
        notifyPropertyChanged(e.propertyName ?: "")
        val dataIndex = _scroll.viewPointToDataIndex(selectionStart)
        ModelCacheScope.createScope(model).using {
            updateToolsFromSelection(dataIndex)
            updateSelectedAddress()
            updateSelectedBytes()
        }
    }
    private fun updateToolsFromSelection() { /*@DONE ViewPort.UpdateToolsFromSelection/1 cs:375-375*/
        updateToolsFromSelection(convertViewPointToAddress(selectionStart))
    }
    fun updateToolsFromSelection(dataIndex: Int) { /*@DONE ViewPort.UpdateToolsFromSelection/2 cs:376-443*/
        var dataIndex = dataIndex
        var run = nextRun(dataIndex)
        if (run.start > dataIndex) {
            anchorTextVisible = false
            return
        }

        if (run is PointerRun && model.getAnchorFromAddress(-1, run.start).isEmpty()) {
            val destination = model.readPointer(run.start)
            run = nextRun(destination)
            dataIndex = destination
        }

        // if the user explicitly closed the tools, don't auto-open them.
        val tools = _tools
        if (tools != null && tools.selectedIndex != -1) {
            // if the 'Raw' tool is selected, don't auto-update tool selection.
            if (!(tools.selectedTool == tools.codeTool && tools.codeTool.mode == CodeMode.Raw)) {
                val currentRun = run
                val currentIndex = dataIndex
                ModelCacheScope.createScope(model).using {
                    // update the tool from pointers too
                    if (currentRun is ITableRun) {
                        val offsets = currentRun.convertByteOffsetToArrayOffset(currentIndex)
                        tools.stringTool.address = offsets.segmentStart - offsets.elementIndex * currentRun.elementLength
                        tools.tableTool.address = currentRun.start + currentRun.elementLength * offsets.elementIndex
                        if (!(currentRun is IStreamRun || currentRun.elementContent[offsets.segmentIndex].type == ElementContentType.PCS) || tools.selectedTool != tools.stringTool) {
                            tools.selectedIndex = tools.indexOf(tools.tableTool)
                        }
                    }
                    if (currentRun is ISpriteRun) {
                        val tool = tools.spriteTool
                        if (tool.spriteAddress != currentRun.start) {
                            tool.spriteAddress = currentRun.start
                        } else {
                            tool.updateSpriteProperties()
                            tool.paletteAddress = SpriteTool.findMatchingPalette(model, currentRun, tool.paletteAddress)
                        }

                        if (tools.selectedIndex == tools.indexOf(tools.tableTool) && currentRun is ITableRun) {
                            // don't switch to the sprite tool if the selected tool is valid
                        } else {
                            tools.selectedIndex = tools.indexOf(tools.spriteTool)
                        }
                    } else if (currentRun is IPaletteRun) {
                        tools.spriteTool.paletteAddress = currentRun.start
                        tools.selectedIndex = tools.indexOf(tools.spriteTool)
                    } else if (currentRun is IStreamRun) {
                        tools.stringTool.address = currentRun.start
                        if (tools.selectedIndex == tools.indexOf(tools.tableTool) && currentRun is ITableRun) {
                            // don't switch to the text tool if the selected tool is valid
                        } else {
                            tools.selectedIndex = tools.indexOf(tools.stringTool)
                        }
                    } else if (currentRun is IScriptStartRun) {
                        tools.selectedIndex = tools.indexOf(tools.codeTool)
                        if (currentRun is XSERun) tools.codeTool.mode = CodeMode.Script
                        if (currentRun is BSERun) tools.codeTool.mode = CodeMode.BattleScript
                        if (currentRun is ASERun) tools.codeTool.mode = CodeMode.AnimationScript
                        if (currentRun is TSERun) tools.codeTool.mode = CodeMode.TrainerAiScript
                    } else {
                        // not a special run, so don't update tools
                    }
                }
            }
        }

        updateAnchorText(dataIndex)

        requestMenuClose(this, EventArgs.empty)
    }
    private fun updateAnchorText(dataIndex: Int) { /*@DONE ViewPort.UpdateAnchorText/1 cs:445-460*/
        val run = nextRun(dataIndex)

        val anchor = this[selectionStart].format
        if (anchor is Anchor) {
            // there is an anchor exactly here: show that format
            tryUpdate(_anchorText, anchorStart + anchor.name + anchor.format, "anchorText") { _anchorText = it }
            anchorTextVisible = true
        } else if (run.start <= dataIndex && run.pointerSources != null) {
            // there is an anchor attached to this run: show that format
            val name = model.getAnchorFromAddress(-1, run.start)
            tryUpdate(_anchorText, anchorStart + name + run.formatString, "anchorText") { _anchorText = it }
            anchorTextVisible = true
        } else {
            anchorTextVisible = false
        }
    }
    private var _selectedAddress: String = ""
    private var _selectedLength: String = ""
    private var _selectedElementName: String = ""
    override var selectedAddress: String
        get() { /*@DONE ViewPort.SelectedAddress.get cs:466-466*/
            return _selectedAddress
        }
        set(value) { /*@DONE ViewPort.SelectedAddress.set cs:467-467*/
            set(_selectedAddress, value, "selectedAddress", { _selectedAddress = it }) { old -> selectedAddressChanged(old) }
        }
    var selectedLength: String
        get() { /*@DONE ViewPort.SelectedLength.get cs:470-470*/
            return _selectedLength
        }
        set(value) { /*@DONE ViewPort.SelectedLength.set cs:471-471*/
            set(_selectedLength, value, "selectedLength", { _selectedLength = it }) { old -> selectedLengthChanged(old) }
        }
    private var _base10SelectionLength: Boolean = false
    var base10SelectionLength: Boolean
        get() { /*@DONE ViewPort.Base10SelectionLength.get cs:476-476*/
            return _base10SelectionLength
        }
        set(value) { /*@DONE ViewPort.Base10SelectionLength.set cs:477-480*/
            set(_base10SelectionLength, value, "base10SelectionLength", { _base10SelectionLength = it }) {
                updateSelectedAddress()
                notifyPropertyChanged("base10Length")
            }
        }
    override var base10Length: Boolean
        get() { /*@DONE ViewPort.Base10Length.get cs:483-483*/
            return _base10SelectionLength
        }
        set(value) { /*@DONE ViewPort.Base10Length.set cs:484-484*/
            base10SelectionLength = value
        }
    val selectedElementName: String
        get() { /*@DONE ViewPort.SelectedElementName.get cs:487-487*/
            return _selectedElementName
        }
    private fun updateSelectedAddress() { /*@DONE ViewPort.UpdateSelectedAddress/1 cs:489-501*/
        val dataIndex1 = _scroll.viewPointToDataIndex(selectionStart)
        val dataIndex2 = _scroll.viewPointToDataIndex(selectionEnd)
        val left = Math.min(dataIndex1, dataIndex2)
        tryUpdate(_selectedAddress, left.toAddress(), "selectedAddress") { _selectedAddress = it }

        val elementName = buildElementName(model, left)
        tryUpdate(_selectedElementName, elementName, "selectedElementName") { _selectedElementName = it }

        val length = Math.abs(dataIndex1 - dataIndex2) + 1
        val lengthText = if (_base10SelectionLength) length.toString() else length.toHex(1)
        tryUpdate(_selectedLength, lengthText, "selectedLength") { _selectedLength = it }
    }
    private fun selectedAddressChanged(old: String) { /*@DONE ViewPort.SelectedAddressChanged/1 cs:503-506*/
        val address = Ref(0)
        if (!_selectedAddress.tryParseHex(address)) return
        selectionStart = convertAddressToViewPoint(address.value)
    }
    private fun selectedLengthChanged(old: String) { /*@DONE ViewPort.SelectedLengthChanged/1 cs:508-518*/
        val length = Ref(0)
        if (_base10SelectionLength) {
            if (!tryParseInt(_selectedLength, length)) return
        } else {
            if (!_selectedLength.tryParseHex(length)) return
        }
        val left = Math.min(convertViewPointToAddress(selectionStart), convertViewPointToAddress(selectionEnd))
        selectionStart = convertAddressToViewPoint(left)
        selectionEnd = convertAddressToViewPoint(left + length.value - 1)
    }
    private var _selectedBytes: String? = null
    override var selectedBytes: String?
        get() { /*@DONE ViewPort.SelectedBytes.get cs:555-561*/
            val existing = _selectedBytes
            if (existing != null) return existing

            val bytes = getSelectedByteContents(0x10)
            _selectedBytes = "Selected Bytes: " + bytes
            return _selectedBytes
        }
        set(value) { /*@DONE ViewPort.SelectedBytes.set cs:562-562*/
            tryUpdate(_selectedBytes, value, "selectedBytes") { _selectedBytes = it }
        }
    private fun updateSelectedBytes() { /*@DONE ViewPort.UpdateSelectedBytes/1 cs:566-566*/
        selectedBytes = null
    }
    private fun getSelectedByteContents(maxByteCount: Int = Int.MAX_VALUE): String { /*@DONE ViewPort.GetSelectedByteContents/1 cs:568-583*/
        val dataIndex1 = _scroll.viewPointToDataIndex(selectionStart)
        val dataIndex2 = _scroll.viewPointToDataIndex(selectionEnd)
        var left = Math.min(dataIndex1, dataIndex2)
        var length = Math.abs(dataIndex1 - dataIndex2) + 1
        if (left < 0) {
            length += left
            left = 0
        }
        if (left + length > model.count) length = model.count - left
        val result = StringBuilder()
        var i = 0
        while (i < length && i < maxByteCount) {
            val token = model[left + i].toHexByte()
            result.append(token)
            result.append(" ")
            i++
        }
        if (maxByteCount < length) result.append("...")
        return result.toString()
    }
    private fun selectAllExecuted() { /*@DONE ViewPort.SelectAllExecuted/1 cs:585-594*/
        if (_scroll.isSingleTableMode) {
            selectionStart = _scroll.dataIndexToViewPoint(_scroll.dataStart)
            selectionEnd = _scroll.dataIndexToViewPoint(_scroll.dataStart + _scroll.dataLength)
        } else {
            goto?.execute(0)
            selectionStart = Point(0, 0)
            selectionEnd = _scroll.dataIndexToViewPoint(model.count - 1)
        }
    }
    private lateinit var history: ChangeHistory<ModelDelta>
    override val changeHistory: ChangeHistory<ModelDelta>
        get() { /*@DONE ViewPort.ChangeHistory.get cs:602-602*/
            return history
        }
    val currentChange: ModelDelta
        get() { /*@DONE ViewPort.CurrentChange.get cs:604-604*/
            return history.currentChange
        }
    override val undo: ICommand
        get() { /*@DONE ViewPort.Undo.get cs:606-606*/
            return undoWrapper
        }
    override val redo: ICommand
        get() { /*@DONE ViewPort.Redo.get cs:608-608*/
            return redoWrapper
        }
    private fun revertChanges(changes: ModelDelta): ModelDelta { /*@DONE ViewPort.RevertChanges/1 cs:610-615*/
        val reverse = changes.revert(model)
        refreshBackingData()
        _scroll.updateHeaders()
        return reverse
    }
    private fun historyPropertyChanged(sender: Any?, e: PropertyChangedEventArgs) { /*@DONE ViewPort.HistoryPropertyChanged/1 cs:617-629*/
        if (e.propertyName == "isSaved") {
            _save.raiseCanExecuteChanged()
            _exportBackup.raiseCanExecuteChanged()
            if (history.isSaved) {
                model.resetChanges()
                refreshBackingData()
            }
            notifyPropertyChanged("isMetadataOnlyChange")
        }

        if (e.propertyName == "hasDataChange") {
            notifyPropertyChanged("isMetadataOnlyChange")
            notifyPropertyChanged("name")
        }
    }
    private val _save: StubCommand = /*@INITAUTO ViewPort.save cs:635-636*/ StubCommand() /*@ENDINIT*/
    private val _saveAs: StubCommand = /*@INITAUTO ViewPort.saveAs cs:635-637*/ StubCommand() /*@ENDINIT*/
    private val _exportBackup: StubCommand = /*@INITAUTO ViewPort.exportBackup cs:635-638*/ StubCommand() /*@ENDINIT*/
    private val _close: StubCommand = /*@INITAUTO ViewPort.close cs:635-639*/ StubCommand() /*@ENDINIT*/
    override val isMetadataOnlyChange: Boolean
        get() { /*@DONE ViewPort.IsMetadataOnlyChange.get cs:641-641*/
            return !history.isSaved && !changeHistory.hasDataChange
        }
    override val save: ICommand?
        get() { /*@DONE ViewPort.Save.get cs:642-642*/
            return _save
        }
    override val saveAs: ICommand
        get() { /*@DONE ViewPort.SaveAs.get cs:644-644*/
            return _saveAs
        }
    override val exportBackup: ICommand
        get() { /*@DONE ViewPort.ExportBackup.get cs:646-646*/
            return _exportBackup
        }
    override val close: ICommand
        get() { /*@DONE ViewPort.Close.get cs:648-648*/
            return _close
        }
    override val closed = Event<EventArgs>()
    private val refTable: GameReferenceTables?
        get() { /*@DONE ViewPort.RefTable.get cs:652-652*/
            return singletons.gameReferenceTables[model.getGameCode()]
        }
    private fun saveExecuted(fileSystem: IFileSystem?) { /*@DONE ViewPort.SaveExecuted/1 cs:654-668*/
        if (history.isSaved) return

        if (fileName.isEmpty()) {
            saveAsExecuted(fileSystem)
            return
        }

        val metadata = model.exportMetadata(refTable, singletons.metadataInfo)
        if (fileSystem!!.save(LoadedFile(fileName, model.rawData))) {
            fileSystem!!.saveMetadata(fileName, metadata?.serialize())
            history.tagAsSaved()
            model.resetChanges()
        }
    }
    private fun saveAsExecuted(fileSystem: IFileSystem?) { /*@DONE ViewPort.SaveAsExecuted/1 cs:670-682*/
        val newName = fileSystem!!.requestNewName(fileName, "Game Boy Advance", "gba")
        if (newName == null) return

        val metadata = model.exportMetadata(refTable, singletons.metadataInfo)
        if (fileSystem!!.save(LoadedFile(newName, model.rawData))) {
            fileName = newName // don't bother notifying, because tagging the history will cause a notify;
            fileSystem!!.saveMetadata(fileName, metadata?.serialize())
            history.tagAsSaved()
            model.resetChanges()
            requestCloseOtherViewports(this, model)
        }
    }
    private fun exportBackupExecuted(fileSystem: IFileSystem?) { /*@DONE ViewPort.ExportBackupExecuted/1 cs:684-703*/
        var changeDescription = fileSystem!!.requestText("Export Summary", "What was your most recent change?")
        if (changeDescription == null) return
        changeDescription = String(changeDescription.map { letter -> if (Character.isLetterOrDigit(letter)) letter else '_' }.toCharArray())

        val exportID = model.nextExportID
        model.nextExportID += 1
        val metadata = model.exportMetadata(refTable, singletons.metadataInfo)
        var baseName = Path.getFileNameWithoutExtension(fullFileName) ?: ""
        baseName = baseName.split("_backup")[0]
        val extension = Path.getExtension(fullFileName) ?: ""
        var directory = Path.getDirectoryName(fullFileName) ?: ""
        if (directory.isNotEmpty()) directory = directory + Path.directorySeparatorChar

        val exportName = "${directory}backups${Path.directorySeparatorChar}${baseName}_backup${exportID}__${changeDescription}${extension}"
        if (fileSystem!!.save(LoadedFile(exportName, model.rawData))) {
            fileSystem!!.saveMetadata(exportName, metadata?.serialize())
            fileSystem!!.saveMetadata(fileName, metadata?.serialize())
        }
    }
    private fun closeExecuted(fileSystem: IFileSystem?) { /*@DONE ViewPort.CloseExecuted/1 cs:705-718*/
        if (!history.isSaved && model.referenceCount == 1) {
            val metadata = model.exportMetadata(refTable, singletons.metadataInfo)
            val result = fileSystem!!.trySavePrompt(LoadedFile(fileName, model.rawData))
            if (result == null) return
            if (result == true) {
                fileSystem!!.saveMetadata(fileName, metadata?.serialize())
                history.tagAsSaved()
            }
        }
        model.referenceCount -= 1

        closed(this, EventArgs.empty)
    }
    private lateinit var dispatcher: IWorkDispatcher
    private var _progress: Double = 0.0
    override var progress: Double
        get() { /*@DONE ViewPort.Progress.get cs:727-727*/
            return _progress
        }
        set(value) { /*@DONE ViewPort.Progress.set cs:727-727*/
            set(_progress, value, "progress", { _progress = it })
        }
    private var holdWorkHistory: IDisposable? = null
    private var _updateInProgress: Boolean = false
    override var updateInProgress: Boolean
        get() { /*@DONE ViewPort.UpdateInProgress.get cs:731-731*/
            return _updateInProgress
        }
        set(value) { /*@DONE ViewPort.UpdateInProgress.set cs:731-731*/
            set(_updateInProgress, value, "updateInProgress", { _updateInProgress = it })
        }
    private var initialWorkLoad: Int = 0
    private var postEditWork: Int = 0
    private val currentProgressScopes: MutableList<IDisposable> = /*@INITAUTO ViewPort.CurrentProgressScopes cs:734-734*/ ArrayList() /*@ENDINIT*/
    override fun updateProgress(value: Double): InlineDispatch { /*@DONE ViewPort.UpdateProgress/1 cs:736-740*/
        updateInProgress = true
        progress = value
        return InlineDispatch(dispatcher)
    }
    override fun clearProgress() { /*@DONE ViewPort.ClearProgress/1 cs:742-742*/
        updateInProgress = false
    }
    override val requestCanDiff = Event<CanDiffEventArgs>()
    override val requestDiff = Event<Direction>()
    var maxDiffSegmentCount: Int = 0
    var hideDiffPointerChanges: Boolean = false
    private lateinit var _diff: StubCommand
    private var _diffLeft: StubCommand? = null
    private var _diffRight: StubCommand? = null
    override val diff: ICommand
        get() { /*@DONE ViewPort.Diff.get cs:755-755*/
            if (!::_diff.isInitialized) _diff = stubCommandOf<Any>({ arg -> executeDiff(arg) })
            return _diff
        }
    override val diffLeft: ICommand
        get() { /*@DONE ViewPort.DiffLeft.get cs:756-756*/
            var command = _diffLeft
            if (command == null) {
                command = stubCommand({ executeDiffLeft() }, { canExecuteDiffLeft() })
                _diffLeft = command
            }
            return command
        }
    override val diffRight: ICommand
        get() { /*@DONE ViewPort.DiffRight.get cs:757-757*/
            var command = _diffRight
            if (command == null) {
                command = stubCommand({ executeDiffRight() }, { canExecuteDiffRight() })
                _diffRight = command
            }
            return command
        }
    private fun executeDiff(data: Any?) { /*@DONE ViewPort.ExecuteDiff/1 cs:758-822*/
        val otherTab = data as? ViewPort
        val maxSegments = maxDiffSegmentCount
        if (otherTab == null) {
            val resultsTab = SearchResultsViewPort("Changes")
            var firstResultStart = 0
            var firstResultLength = 0
            var i = 0
            while (i < model.count) {
                if (model.hasChanged(i)) {
                    var length = 1
                    var j = i + 1
                    while (j < model.count) {
                        if (model.hasChanged(j)) length++
                        else break
                        j++
                    }
                    resultsTab.add(createChildView(i, i + length - 1), i, i + length - 1)
                    if (resultsTab.resultCount >= maxSegments) break
                    if (firstResultLength == 0) {
                        firstResultStart = i
                        firstResultLength = length
                    }
                    i += length
                }
                i++
            }

            val changeCount = resultsTab.resultCount
            var changeCountText = changeCount.toString()
            if (changeCount >= maxSegments) changeCountText += "+"
            raiseMessage("$changeCountText changes found.")
            if (changeCount == 1) {
                goto?.execute(firstResultStart)
                selectionEnd = convertAddressToViewPoint(firstResultStart + firstResultLength - 1)
            } else if (changeCount > 1) {
                requestTabChange(this, TabChangeRequestedEventArgs(resultsTab))
            }
        } else {
            val otherViewPort: IEditableViewPort = otherTab
            val modelA = model
            val modelB = otherViewPort.model!!
            if (modelA.count != modelB.count) {
                raiseError("Cannot diff files of different length.")
                return
            }
            val resultsTabA = ArrayList<IChildViewPort>()
            val resultsTabB = ArrayList<IChildViewPort>()
            var i = 0
            while (i < modelA.count && i < modelB.count) {
                if (modelA[i] != modelB[i]) {
                    var lastDiff = i
                    var j = i + 1
                    while (j < model.count && j < modelB.count) {
                        if (modelA[j] != modelB[j]) lastDiff = j
                        if (lastDiff == j - 4) break
                        j++
                    }
                    if (!(hideDiffPointerChanges && isDiffPointerChange(i, lastDiff, modelB))) {
                        resultsTabA.add(createChildView(i, lastDiff))
                        resultsTabB.add(otherViewPort.createChildView(i, lastDiff))
                        i = lastDiff + 1
                        if (resultsTabA.size >= maxSegments) break
                    }
                }
                i++
            }
            val diffTab = DiffViewPort(resultsTabA, resultsTabB)
            diffTab.height = height
            val changeCount = resultsTabA.size
            var changeCountText = changeCount.toString()
            if (changeCount >= maxSegments) changeCountText += "+"
            raiseMessage("$changeCountText changes found.")
            if (changeCount > 0) {
                val tabArgs = TabChangeRequestedEventArgs(diffTab)
                requestTabChange(this, tabArgs)
                if (!tabArgs.requestAccepted) otherTab.raiseRequestTabChange(tabArgs)
            }
        }
    }
    private fun isDiffPointerChange(start: Int, end: Int, other: IDataModel): Boolean { /*@DONE ViewPort.IsDiffPointerChange/1 cs:824-831*/
        var start = start
        var end = end
        while (start % 4 != 0) start--
        while (end % 4 != 3) end++
        if (end - start != 3) return false
        val run1 = model.getNextRun(start)
        if (run1 is PointerRun && run1.start == start) return true
        val run2 = other.getNextRun(start)
        if (run2 is PointerRun && run2.start == start) return true
        return false
    }
    private fun executeDiffLeft() { /*@DONE ViewPort.ExecuteDiffLeft/1 cs:833-833*/
        requestDiff(this, Direction.Left)
    }
    private fun canExecuteDiffLeft(): Boolean { /*@DONE ViewPort.CanExecuteDiffLeft/1 cs:834-838*/
        val args = CanDiffEventArgs(Direction.Left)
        requestCanDiff(this, args)
        return args.result
    }
    private fun executeDiffRight() { /*@DONE ViewPort.ExecuteDiffRight/1 cs:840-840*/
        requestDiff(this, Direction.Right)
    }
    private fun canExecuteDiffRight(): Boolean { /*@DONE ViewPort.CanExecuteDiffRight/1 cs:841-845*/
        val args = CanDiffEventArgs(Direction.Right)
        requestCanDiff(this, args)
        return args.result
    }
    fun refreshTabCommands() { /*@DONE ViewPort.RefreshTabCommands/1 cs:847-851*/
        _diffLeft?.raiseCanExecuteChanged()
        _diffRight?.raiseCanExecuteChanged()
        notifyPropertiesChanged("canIpsPatchRight", "canUpsPatchRight")
    }
    fun launchFileLocation(fileSystem: IFileSystem) { /*@DONE ViewPort.LaunchFileLocation/1 cs:857-857*/
        fileSystem.launchProcess("explorer.exe", "/select,\"$fullFileName\"")
    }
    override val canDuplicate: Boolean
        get() { /*@DONE ViewPort.CanDuplicate.get cs:863-863*/
            return true
        }
    // skipped method CreateDuplicate: explicit implementation merged with the public member
    override fun createDuplicate(): ViewPort { /*@DONE ViewPort.CreateDuplicate/2 cs:865-869*/
        val child = ViewPort(fileName, model, dispatcher, singletons, mapper?.tutorials, mapper?.fileSystem, pythonTool, history, mapper?.templates)
        child.selection.gotoAddress(_scroll.dataIndex)
        return child
    }
    override fun duplicate() { /*@DONE ViewPort.Duplicate/1 cs:870-870*/
        openInNewTab(_scroll.dataIndex)
    }
    override val requestCanCreatePatch = Event<CanPatchEventArgs>()
    override val requestCreatePatch = Event<CanPatchEventArgs>()
    override val canIpsPatchRight: Boolean
        get() { /*@DONE ViewPort.CanIpsPatchRight.get cs:880-884*/
            val args = CanPatchEventArgs(Direction.Right, PatchType.Ips)
            requestCanCreatePatch(this, args)
            return args.result
        }
    override val canUpsPatchRight: Boolean
        get() { /*@DONE ViewPort.CanUpsPatchRight.get cs:887-891*/
            val args = CanPatchEventArgs(Direction.Right, PatchType.Ups)
            requestCanCreatePatch(this, args)
            return args.result
        }
    override fun ipsPatchRight() { /*@DONE ViewPort.IpsPatchRight/1 cs:894-894*/
        requestCreatePatch(this, CanPatchEventArgs(Direction.Right, PatchType.Ips))
    }
    override fun upsPatchRight() { /*@DONE ViewPort.UpsPatchRight/1 cs:896-896*/
        requestCreatePatch(this, CanPatchEventArgs(Direction.Right, PatchType.Ups))
    }
    var freeSpaceStart: Int
        get() { /*@DONE ViewPort.FreeSpaceStart.get cs:901-901*/
            return model.freeSpaceStart
        }
        set(value) { /*@DONE ViewPort.FreeSpaceStart.set cs:901-906*/
            if (model.freeSpaceStart != value) {
                model.freeSpaceStart = value
                notifyPropertyChanged("freeSpaceStart")
            }
        }
    private lateinit var _gotoFreeSpaceStart: StubCommand
    val gotoFreeSpaceStart: ICommand
        get() { /*@DONE ViewPort.GotoFreeSpaceStart.get cs:909-909*/
            if (!::_gotoFreeSpaceStart.isInitialized) _gotoFreeSpaceStart = stubCommand({ goto?.execute(model.freeSpaceStart) })
            return _gotoFreeSpaceStart
        }
    override val canFindFreeSpace: Boolean
        get() { /*@DONE ViewPort.CanFindFreeSpace.get cs:910-910*/
            return true
        }
    override fun findFreeSpace(fileSystem: IFileSystem) { /*@DONE ViewPort.FindFreeSpace/1 cs:911-926*/
        val sizeText = fileSystem.requestText("Free Space Finder", "How many bytes of freespace do you want to find?")
        if (sizeText == null) return
        val sizeRef = Ref(0)
        if (!tryParseInt(sizeText, sizeRef)) {
            raiseError("Could not parse $sizeText as a number")
            return
        }
        val size = sizeRef.value
        if (size < 1) {
            raiseError("Try a number bigger than zero.")
            return
        }

        val start = model.findFreeSpace(freeSpaceStart, size)
        goto?.execute(start)
        selectionEnd = convertAddressToViewPoint(start + size - 1)
    }
    private var docs: List<DocLabel> = ArrayList()
    private var _tools: ToolTray? = null
    override val hasTools: Boolean
        get() { /*@DONE ViewPort.HasTools.get cs:930-930*/
            return _tools != null
        }
    override val tools: IToolTrayViewModel?
        get() { /*@DONE ViewPort.Tools.get cs:931-931*/
            return _tools
        }
    private var _anchorTextVisible: Boolean = false
    override var anchorTextVisible: Boolean
        get() { /*@DONE ViewPort.AnchorTextVisible.get cs:935-935*/
            return _anchorTextVisible
        }
        set(value) { /*@DONE ViewPort.AnchorTextVisible.set cs:936-936*/
            set(_anchorTextVisible, value, "anchorTextVisible", { _anchorTextVisible = it })
        }
    private var _anchorText: String = ""
    override var anchorText: String
        get() { /*@DONE ViewPort.AnchorText.get cs:941-941*/
            return _anchorText
        }
        set(value) { /*@DONE ViewPort.AnchorText.set cs:942-990*/
            var value = value
            if (!value.startsWith(anchorStart.toString())) value = anchorStart + value
            if (tryUpdate(_anchorText, value, "anchorText") { _anchorText = it }) {
                var index = _scroll.viewPointToDataIndex(selectionStart)
                var run = nextRun(index)
                val hasAnchor = ((run.pointerSources?.size ?: 0) > 0) || model.getAnchorFromAddress(-1, run.start).isNotEmpty()
                if (run is PointerRun && !hasAnchor) {
                    index = model.readPointer(run.start)
                    run = nextRun(index)
                }
                _tools?.logTool?.logMessages?.add("Attempting to Update Anchor at address ${run.start.toAddress()}: $_anchorText")
                if (run.start <= index) {
                    val token = NoDataChangeDeltaModel()

                    // During edits, typing `^` is allowed, and is used as a way to remove an anchor.
                    // When doing AnchorText edits, clearing the name/format when there are no pointers is an error.
                    var errorInfo = ErrorInfo.noError
                    if (_anchorText == anchorStart.toString() && (run.pointerSources?.size ?: 0) == 0) {
                        errorInfo = ErrorInfo("An anchor with nothing pointing to it must have a name.")
                    }

                    if (errorInfo === ErrorInfo.noError) {
                        errorInfo = PokemonModel.applyAnchor(model, token, run.start, _anchorText)
                    }

                    if (errorInfo === ErrorInfo.noError) {
                        raiseError("")
                        val newRun = nextRun(index)
                        if (_anchorText == anchorStart.toString()) model.clearFormat(token, run.start, 1)
                        if (newRun is ArrayRun) {
                            // if the format changed (ignoring length), run a goto to update the display width
                            val oldArray = run as? ArrayRun
                            if (oldArray == null || !newRun.hasSameSegments(oldArray)) {
                                selection.propertyChanged -= selectionPropertyChangedHandler // to keep from double-updating the AnchorText
                                goto?.execute(index)
                                selection.propertyChanged += selectionPropertyChangedHandler
                                notifyPropertyChanged("preferredWidth") // editing the anchor can edit the preferred width, and we weren't listening
                            }
                            updateColumnHeaders()
                        }
                        _tools?.refreshContent()
                        refreshBackingData()
                    } else {
                        raiseError(errorInfo.errorMessage ?: "")
                    }
                    if (token.hasAnyChange) history.insertCustomChange(token)
                }
            }
        }
    private var _anchorTextSelectionStart: Int = 0
    var anchorTextSelectionStart: Int
        get() { /*@DONE ViewPort.AnchorTextSelectionStart.get cs:994-994*/
            return _anchorTextSelectionStart
        }
        set(value) { /*@DONE ViewPort.AnchorTextSelectionStart.set cs:994-994*/
            set(_anchorTextSelectionStart, value, "anchorTextSelectionStart", { _anchorTextSelectionStart = it })
        }
    private var _anchorTextSelectionLength: Int = 0
    var anchorTextSelectionLength: Int
        get() { /*@DONE ViewPort.AnchorTextSelectionLength.get cs:997-997*/
            return _anchorTextSelectionLength
        }
        set(value) { /*@DONE ViewPort.AnchorTextSelectionLength.set cs:997-997*/
            set(_anchorTextSelectionLength, value, "anchorTextSelectionLength", { _anchorTextSelectionLength = it })
        }
    private var _isFocused: Boolean = false
    override var isFocused: Boolean
        get() { /*@DONE ViewPort.IsFocused.get cs:1000-1000*/
            return _isFocused
        }
        set(value) { /*@DONE ViewPort.IsFocused.set cs:1000-1000*/
            set(_isFocused, value, "isFocused", { _isFocused = it })
        }
    private var ownsHistory: Boolean = false
    override val copy: ICommand?
        get() { /*@DONE ViewPort.Copy.get cs:1004-1004*/
            return _copy
        }
    val copyAddress: ICommand
        get() { /*@DONE ViewPort.CopyAddress.get cs:1005-1005*/
            return _copyAddress
        }
    val copyBytes: ICommand
        get() { /*@DONE ViewPort.CopyBytes.get cs:1006-1006*/
            return _copyBytes
        }
    override val deepCopy: ICommand
        get() { /*@DONE ViewPort.DeepCopy.get cs:1007-1007*/
            return _deepCopy
        }
    override val clear: ICommand?
        get() { /*@DONE ViewPort.Clear.get cs:1008-1008*/
            return _clear
        }
    val isText: ICommand
        get() { /*@DONE ViewPort.IsText.get cs:1009-1009*/
            return _isText
        }
    operator fun get(p: Point): HexElement { /*@DONE ViewPort.this/1.get cs:1011-1011*/
        return this[p.x, p.y]
    }
    override operator fun get(x: Int, y: Int): HexElement { /*@DONE ViewPort.this/2.get cs:1014-1029*/
        val view = currentView
        if (x < 0 || x >= width || x >= view.size) return HexElement.undefined
        if (y < 0 || y >= height || y >= view[x].size) return HexElement.undefined
        val existing = view[x][y]
        if (existing != null) return existing

        if (x == 0 && y == 0) {
            refreshBackingDataFull()
            return currentView[x][y] ?: HexElement.undefined
        }

        ModelCacheScope.createScope(model).using {
            refreshBackingData(Point(x, y))
        }

        return currentView[x][y] ?: HexElement.undefined
    }
    operator fun get(name: String): ModelTable { /*@DONE ViewPort.this/3.get cs:1032-1032*/
        return model.getTableModel(name) { currentChange }!!
    }
    private lateinit var _model: IDataModel
    override val model: IDataModel
        get() = _model
    override fun modelFor(p: Point): IDataModel? { /*@DONE ViewPort.ModelFor/1 cs:1035-1035*/
        return model
    }
    val maps: AllMapsModel
        get() { /*@DONE ViewPort.Maps.get cs:1036-1036*/
            return AllMapsModel.create(model) { currentChange }
        }
    val formattedDataIsSelected: Boolean
        get() { /*@DONE ViewPort.FormattedDataIsSelected.get cs:1039-1044*/
            var left = _scroll.viewPointToDataIndex(selectionStart)
            var right = _scroll.viewPointToDataIndex(selectionEnd)
            if (left > right) {
                val swap = left
                left = right
                right = swap
            }
            val next = nextRun(left)
            return next.start <= right
        }
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val clearMessage = Event<EventArgs>()
    override val collectionChanged = Event<NotifyCollectionChangedEventArgs>()
    override val requestCloseOtherViewports = Event<IDataModel>()
    override val requestTabChange = Event<TabChangeRequestedEventArgs>()
    override val requestDelayedWork = Event<() -> Unit>()
    override val requestMenuClose = Event<EventArgs>()
    val focusToolPanel = Event<EventArgs>()
    override val requestRefreshGotoShortcuts = Event<EventArgs>()
    lateinit var shortcuts: Shortcuts
        private set
    constructor() : this(LoadedFile("", ByteArray(0))) { /*@DONE ViewPort.<init>/1 cs:1064-1064*/ }
    constructor(fileName: String, model: IDataModel, dispatcher: IWorkDispatcher?, singletons: Singletons? = null, tutorials: MapTutorialsViewModel? = null, fs: IFileSystem? = null, pythonTool: PythonTool? = null, changeHistory: ChangeHistory<ModelDelta>? = null, eventTemplate: EventTemplate? = null) { /*@DONE ViewPort.<init>/2 cs:1066-1143*/
        this.singletons = singletons ?: Singletons()
        this.fs = fs
        this.docs = ArrayList()
        val gameCode = model.getGameCode()
        if (model.count >= 0x100 && gameCode.length >= 4) {
            val gameDocs = this.singletons.docReference[gameCode.substring(4)]
            if (gameDocs != null) this.docs = gameDocs
        }
        this.pythonTool = pythonTool
        ownsHistory = changeHistory == null
        model.referenceCount += 1

        history = changeHistory ?: ChangeHistory<ModelDelta>({ changes -> revertChanges(changes) })
        history.propertyChanged += historyPropertyChangedHandler
        this.dispatcher = dispatcher ?: InstantDispatch.instance

        _model = model
        this.fileName = fileName

        _scroll = ScrollRegion({ address, header -> model.tryGetUsefulHeader(address, header) })
        _scroll.dataLength = model.count
        _scroll.propertyChanged += scrollPropertyChangedHandler

        selection = Selection(_scroll, model, history, { p -> getSelectionSpan(p) })
        selection.propertyChanged += selectionPropertyChangedHandler
        selection.previewSelectionStartChanged += clearActiveEditHandler
        selection.onError += { _, e -> raiseError(e) }
        selection.requestTabChanged += { _, e ->
            val request = TabChangeRequestedEventArgs(e.tab!!)
            requestTabChange(this, request)
            if (request.requestAccepted && request.newTab === mapper) {
                if (e.isBackArrow) {
                    mapper?.addForwardNavigation(-1)
                } else {
                    mapper?.addBackNavigation(-1)
                }
            }
        }

        if (this !is ChildViewPort) { // child viewports don't need tools
            val toolTray = ToolTray(this.singletons, model, selection, history, this)
            _tools = toolTray
            toolTray.logTool.logMessages.add("Start of session $name - ${java.util.Date()}")
            toolTray.onError += { _, e -> raiseError(e) }
            toolTray.onMessage += { _, e -> raiseMessage(e) }
            toolTray.requestMenuClose += { _, e -> requestMenuClose(this, e) }
            toolTray.stringTool.modelDataChanged += { sender, run -> modelChangedByTool(sender, run) }
            toolTray.stringTool.modelDataMoved += { sender, moved -> modelDataMovedByTool(sender, moved.originalLocation, moved.newLocation) }
            toolTray.tableTool.modelDataChanged += { sender, run -> modelChangedByTool(sender, run) }
            toolTray.tableTool.modelDataMoved += { sender, moved -> modelDataMovedByTool(sender, moved.originalLocation, moved.newLocation) }
            toolTray.codeTool.modelDataChanged += { sender, e -> modelChangedByCodeTool(sender, e) }
            toolTray.codeTool.modelDataMoved += { sender, moved -> modelDataMovedByTool(sender, moved.originalLocation, moved.newLocation) }
            model.logMessage += { _, e -> toolTray.logTool.logMessages.add(e) }
            _scroll.scheduler = toolTray
        }

        implementCommands()
        refreshBackingData()
        shortcuts = Shortcuts(this)

        initializationWorkload = model.initializationWorkload.continueWith { _ ->
            val firstViewPort = changeHistory == null
            var template = eventTemplate
            if (firstViewPort) {
                if (template == null) template = EventTemplate(singletons?.workDispatcher ?: InstantDispatch.instance, this.model, _tools!!.codeTool.scriptParser, BlockMapViewModel.renderOWs(this.model) ?: emptyList())
                cascadeScripts()
                validateMatchedWords()
            }
            this.dispatcher.dispatchWork { refreshBackingData() } // this work must be done on the UI thread
            if (fs != null) {
                val created = Ref<MapEditorViewModel?>(null)
                if (MapEditorViewModel.tryCreateMapEditor(fs, this, singletons, tutorials, template, created)) {
                    mapper = created.value
                    _tools!!.codeTool.investigator = mapper!!.templates
                } else {
                    mapper = null
                }
            }
            val baseModel = model as? BaseModel
            if (baseModel != null) {
                this.docs = this.docs + baseModel.generateDocumentationLabels(this.singletons.scriptLines)
            }
        }
    }
    constructor(file: LoadedFile) : this(file.name, BasicModel(file.contents), InstantDispatch.instance) { /*@DONE ViewPort.<init>/3 cs:1145-1145*/ }
    private var ignoreFurtherCommands: Boolean = /*@INITAUTO ViewPort.ignoreFurtherCommands cs:1147-1147*/ false /*@ENDINIT*/
    private fun implementCommands() { /*@DONE ViewPort.ImplementCommands/1 cs:1148-1265*/
        undoWrapper.canExecute = { a -> history.undo.canExecute(a) }
        undoWrapper.execute = { arg ->
            history.undo.execute(arg)
            if (!ownsHistory) refreshBackingData()
            _tools?.refreshContent()
        }
        history.undo.canExecuteChanged += { _, e -> undoWrapper.canExecuteChanged(undoWrapper, e) }

        redoWrapper.canExecute = { a -> history.redo.canExecute(a) }
        redoWrapper.execute = { arg ->
            history.redo.execute(arg)
            if (!ownsHistory) refreshBackingData()
            _tools?.refreshContent()
        }
        history.redo.canExecuteChanged += { _, e -> redoWrapper.canExecuteChanged(redoWrapper, e) }

        _clear.canExecute = { _ -> true }
        _clear.execute = { _ ->
            val selStart = _scroll.viewPointToDataIndex(selection.selectionStart)
            val selEnd = _scroll.viewPointToDataIndex(selection.selectionEnd)
            val left = minOf(selStart, selEnd)
            val right = maxOf(selStart, selEnd)
            val length = right - left + 1
            val startRun = nextRun(left)
            val endRun = nextRun(right)
            if (ThumbParser.isThumbSelection(model, left, length) && length >= 0xC && ThumbParser.tryWriteUniversalBranchLink(model, history.currentChange, left, length)) {
                // we cleared and we wrote the UBL, nothing else to do
            } else if (startRun === endRun && startRun.start <= left && (startRun.start < left || startRun.start + startRun.length - 1 > right) && startRun is ITableRun) {
                val arrayRun: ITableRun = startRun
                for (i in 0 until arrayRun.elementCount) {
                    var start = arrayRun.start + arrayRun.elementLength * i
                    if (start + arrayRun.elementLength <= left) continue
                    if (start > right) break
                    for (j in 0 until arrayRun.elementContent.size) {
                        start = arrayRun.start + arrayRun.elementLength * i + arrayRun.elementContent.take(j).sumOf { seg -> seg.length }
                        if (start + arrayRun.elementContent[j].length <= left) continue
                        if (start > right) break
                        for (k in 0 until arrayRun.elementContent[j].length) {
                            if (arrayRun.elementContent[j].type == ElementContentType.Pointer) {
                                history.currentChange.changeData(model, start + k, 0x00)
                            } else {
                                history.currentChange.changeData(model, start + k, 0xFF)
                            }
                        }
                    }
                }
            } else if (startRun === endRun && (startRun.start < left || startRun.start + startRun.length > right + 1)) {
                // clearing _within_ a single run
                model.clearData(history.currentChange, left, right - left + 1)
            } else if (left >= model.count) {
                // don't do any clearing, we are past the last byte
            } else {
                model.clearFormatAndData(history.currentChange, left, right - left + 1)
            }
            _tools?.stringTool?.dataForCurrentRunChanged()
            refreshBackingData()
            _scroll.updateHeaders()
        }

        _copy.canExecute = { _ -> true }
        _copy.execute = { arg ->
            val filesystem = arg as IFileSystem
            copyExecute(filesystem, allowModelChanges = false)
        }

        _copyAddress.canExecute = { _ -> true }
        _copyAddress.execute = { arg ->
            val fileSystem = arg as IFileSystem
            copyAddressExecute(fileSystem)
        }

        _copyBytes.canExecute = { _ -> true }
        _copyBytes.execute = { arg ->
            val fileSystem = arg as IFileSystem
            copyBytesExecute(fileSystem)
        }

        _deepCopy.canExecute = { _ -> true }
        _deepCopy.execute = { arg ->
            val fileSystem = arg as IFileSystem
            deepCopyExecute(fileSystem)
        }

        _moveSelectionStart.canExecute = { a -> selection.moveSelectionStart.canExecute(a) }
        _moveSelectionStart.execute = { arg ->
            asyncTask {
                if (!ignoreFurtherCommands) {
                    val guard = scope(ignoreFurtherCommands, true, { ignoreFurtherCommands = it }) { value -> ignoreFurtherCommands = value }
                    guard.using {
                        dispatcher.waitForRenderingAsync().await()
                        val direction = arg as Direction
                        moveSelectionStartExecuted(arg, direction)
                    }
                }
            }
        }
        selection.moveSelectionStart.canExecuteChanged += { _, e -> _moveSelectionStart.canExecuteChanged(this, e) }
        _moveSelectionEnd.canExecute = { a -> selection.moveSelectionEnd.canExecute(a) }
        _moveSelectionEnd.execute = { arg ->
            ModelCacheScope.createScope(model).using {
                selection.moveSelectionEnd.execute(arg)
            }
        }
        selection.moveSelectionEnd.canExecuteChanged += { _, e -> _moveSelectionEnd.canExecuteChanged(this, e) }

        _isText.canExecute = { _ -> true }
        _isText.execute = { arg -> isTextExecuted(arg) }

        _save.canExecute = { _ -> !history.isSaved }
        _save.execute = { arg -> saveExecuted(arg as IFileSystem?) }

        _saveAs.canExecute = { _ -> true }
        _saveAs.execute = { arg -> saveAsExecuted(arg as IFileSystem?) }

        _exportBackup.canExecute = { _ -> !history.hasDataChange }
        _exportBackup.execute = { arg -> exportBackupExecuted(arg as IFileSystem?) }

        _close.canExecute = { _ -> true }
        _close.execute = { arg -> closeExecuted(arg as IFileSystem?) }

        _selectAll.canExecute = { _ -> true }
        _selectAll.execute = { _ -> selectAllExecuted() }
    }
    private fun cascadeScripts() { /*@DONE ViewPort.CascadeScripts/1 cs:1271-1284*/
        val noChange = NoDataChangeDeltaModel()
        noChange.doNotClearConstants = true
        ModelCacheScope.createScope(model).using {
            for (run in runs(model).filterIsInstance<IScriptStartRun>().toList()) {
                if (run is XSERun) {
                    _tools!!.codeTool.scriptParser.formatScript<XSERun>(noChange, model, run.start)
                } else if (run is BSERun) {
                    _tools!!.codeTool.battleScriptParser.formatScript<BSERun>(noChange, model, run.start)
                } else if (run is ASERun) {
                    _tools!!.codeTool.animationScriptParser.formatScript<ASERun>(noChange, model, run.start)
                }
            }
        }
    }
    private fun copyAddressExecute(fileSystem: IFileSystem) { /*@DONE ViewPort.CopyAddressExecute/1 cs:1292-1297*/
        val copyText = _scroll.viewPointToDataIndex(selection.selectionStart).toHex(6)
        fileSystem.copyText = copyText
        requestMenuClose(this, EventArgs.empty)
        raiseMessage("'$copyText' copied to clipboard.")
    }
    private fun copyBytesExecute(fileSystem: IFileSystem) { /*@DONE ViewPort.CopyBytesExecute/1 cs:1299-1304*/
        val copyText = getSelectedByteContents()
        fileSystem.copyText = copyText
        requestMenuClose(this, EventArgs.empty)
        raiseMessage("'$copyText' copied to clipboard.")
    }
    private fun copyExecute(filesystem: IFileSystem, allowModelChanges: Boolean) { /*@DONE ViewPort.CopyExecute/1 cs:1306-1337*/
        val selStart = _scroll.viewPointToDataIndex(selection.selectionStart)
        val selEnd = _scroll.viewPointToDataIndex(selection.selectionEnd)
        val left = minOf(selStart, selEnd)
        val length = Math.abs(selEnd - selStart) + 1
        if (length > singletons.copyLimit) {
            raiseError("Cannot copy more than ${singletons.copyLimit} bytes at once!")
        } else {
            var usedHistory = false
            if (left + length > model.count) {
                raiseError("Cannot copy beyond the end of the data.")
            } else if (left < 0) {
                raiseError("Cannot copy before the start of the data.")
            } else {
                if (ThumbParser.isThumbSelection(model, left, length) && allowModelChanges) {
                    val text = _tools!!.codeTool.parser.parse(model, left, length)
                    val nl = "\n"
                    val nameRef = Ref("thumb.misc.${left.toHex(6)}")
                    PokemonModel.uniquifyName(model, left, nameRef)
                    filesystem.copyText = "^thumb.misc.${left.toHex(6)} .thumb$nl$text$nl.end"
                    model.observeAnchorWritten(history.currentChange, nameRef.value, NoInfoRun(left))
                } else if (allowModelChanges) {
                    filesystem.copyText = model.copy({ usedHistory = true; history.currentChange }, left, length, false)
                } else {
                    filesystem.copyText = model.copy({ NoDataChangeDeltaModel() }, left, length, false)
                }
                refreshBackingData()
                if (usedHistory) updateToolsFromSelection(left)
            }
        }
        requestMenuClose(this, EventArgs.empty)
    }
    private fun deepCopyExecute(fileSystem: IFileSystem) { /*@DONE ViewPort.DeepCopyExecute/1 cs:1339-1353*/
        val selStart = _scroll.viewPointToDataIndex(selection.selectionStart)
        val selEnd = _scroll.viewPointToDataIndex(selection.selectionEnd)
        val left = minOf(selStart, selEnd)
        val length = Math.abs(selEnd - selStart) + 1
        if (length > singletons.copyLimit) {
            raiseError("Cannot copy more than ${singletons.copyLimit} bytes at once!")
        } else {
            var usedHistory = false
            fileSystem.copyText = model.copy({ usedHistory = true; history.currentChange }, left, length, true)
            refreshBackingData()
            if (usedHistory) updateToolsFromSelection(left)
        }
        requestMenuClose(this, EventArgs.empty)
    }
    private fun moveSelectionStartExecuted(arg: Any?, direction: Direction) { /*@DONE ViewPort.MoveSelectionStartExecuted/1 cs:1357-1381*/
        val format = this[selectionStart.x, selectionStart.y].format
        val underEdit = format as? UnderEdit
        val autoOptions = underEdit?.autocompleteOptions
        if (underEdit != null && autoOptions != null && autoOptions.size > 0) {
            var index = -1
            for (i in 0 until autoOptions.size) if (autoOptions[i].isSelected) index = i
            var options: Iterable<AutoCompleteSelectionItem>? = null
            if (direction == Direction.Up) {
                index -= 1
                if (index < -1) index = autoOptions.size - 1
                options = AutoCompleteSelectionItem.generate(autoOptions.map { option -> option.completionText }, index)
            } else if (direction == Direction.Down) {
                index += 1
                if (index == autoOptions.size) index = -1
                options = AutoCompleteSelectionItem.generate(autoOptions.map { option -> option.completionText }, index)
            }
            if (options != null) {
                val edit = UnderEdit(underEdit.originalFormat, underEdit.currentText, underEdit.editWidth, options.toList())
                currentView[selectionStart.x][selectionStart.y] = HexElement(this[selectionStart.x, selectionStart.y], edit)
                notifyCollectionChanged(resetArgs)
                return
            }
        }
        previewScrollChanged(this, EventArgs.empty)
        selection.moveSelectionStart.execute(arg)
    }
    fun convertAddressToViewPoint(address: Int): Point { /*@DONE ViewPort.ConvertAddressToViewPoint/1 cs:1383-1383*/
        return _scroll.dataIndexToViewPoint(address)
    }
    fun convertViewPointToAddress(p: Point): Int { /*@DONE ViewPort.ConvertViewPointToAddress/1 cs:1384-1384*/
        return _scroll.viewPointToDataIndex(p)
    }
    fun getContextMenuItems(selectionPoint: Point): List<IContextItem> = getContextMenuItems(selectionPoint, null) // C# default argument
    override fun getContextMenuItems(selectionPoint: Point, fileSystem: IFileSystem?): List<IContextItem> { /*@DONE ViewPort.GetContextMenuItems/1 cs:1386-1404*/
        // don't show the context menu if the clicked box isn't actually selected.
        // Example: selection is outside the range of selectable data (maybe past the end of the data).
        if (!isSelected(selectionPoint)) return ArrayList()
        val factory = ContextItemFactory(this)
        val cell = this[selectionStart.x, selectionStart.y]
        (cell.format ?: None.instance).visit(factory, cell.value)
        val results: MutableList<IContextItem> = ArrayList(factory.results)
        if (selectionStart != selectionEnd) {
            results.add(ContextItem("Copy", { arg -> _copy.execute(arg) }).also { it.shortcutText = "Ctrl+C" })
            results.add(ContextItem("Deep Copy", { arg -> _deepCopy.execute(arg) }).also { it.shortcutText = "Ctrl+Shift+C" })
        }
        results.add(ContextItem("Paste", { arg -> edit((arg as IFileSystem).copyText ?: "") }).also { it.shortcutText = "Ctrl+V" })
        val clipboardText = fileSystem?.copyText
        if (fileSystem != null && clipboardText != null && clipboardText.all { c -> allHexCharacters.contains(c) || c.isWhitespace() }) {
            results.add(ContextItem("Paste Raw Bytes", { arg -> pasteRawBytes((arg as IFileSystem).copyText ?: "") }))
        }
        results.add(ContextItem("Copy Address", { arg -> copyAddressExecute(arg as IFileSystem) }))
        return results
    }
    private fun pasteRawBytes(text: String) { /*@DONE ViewPort.PasteRawBytes/1 cs:1406-1430*/
        var text = text.replace(" ", "").replace("\n", "").replace("\r", "").uppercase()
        val index = minOf(convertViewPointToAddress(selectionStart), convertViewPointToAddress(selectionEnd))
        model.expandData(currentChange, index + text.length / 2)
        _scroll.dataLength = model.count
        for (i in 0 until text.length / 2) {
            val high = allHexCharacters.indexOf(text[i * 2])
            val low = allHexCharacters.indexOf(text[i * 2 + 1])
            val value = ((high shl 4) + low) and 0xFF
            val run = nextRun(index + i)
            if (run.start <= index + i) {
                // remove pointers, since randomly changing pointer bytes can lead to metadata issues
                if (run is ITableRun) {
                    val contentIndex = run.convertByteOffsetToArrayOffset(index + i).segmentIndex
                    if (run.elementContent[contentIndex].type == ElementContentType.Pointer) {
                        model.clearFormat(currentChange, index + i, 1)
                    }
                }
                if (run is PointerRun) model.clearFormat(currentChange, index + i, 1)
            }
            currentChange.changeData(model, index + i, value)
        }
        selectionStart = convertAddressToViewPoint(index + text.length / 2)
        refreshBackingDataFull()
    }
    override fun isSelected(point: Point): Boolean { /*@DONE ViewPort.IsSelected/1 cs:1432-1432*/
        return selection.isSelected(point)
    }
    override fun isTable(point: Point): Boolean { /*@DONE ViewPort.IsTable/1 cs:1434-1438*/
        val search = _scroll.viewPointToDataIndex(point)
        val run = nextRun(search)
        return run.start <= search && run is ITableRun
    }
    override fun refresh() { /*@DONE ViewPort.Refresh/1 cs:1440-1453*/
        _scroll.dataLength = model.count
        model.clearCacheScope()
        val selStart = convertViewPointToAddress(selectionStart)
        if (selStart > model.count + 1) selectionStart = convertAddressToViewPoint(model.count + 1)
        _scroll.updateHeaders()
        val tableRun = nextRun(selStart)
        if (tableRun is ITableRun && tableRun.start <= selStart) _scroll.setTableMode(tableRun.start, tableRun.length)
        refreshBackingData()
        _tools?.tableTool?.dataForCurrentRunChanged()
        _tools?.spriteTool?.dataForCurrentRunChanged()
        _tools?.codeTool?.clearConstantCache()
        _tools?.codeTool?.dataForCurrentRunChanged()
        updateAnchorText(convertViewPointToAddress(selectionStart))
    }
    fun cut(filesystem: IFileSystem) { /*@DONE ViewPort.Cut/1 cs:1455-1458*/
        copyExecute(filesystem, allowModelChanges = true)
        _clear.execute()
    }
    private var pathContext: String? = null
    override fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean { /*@DONE ViewPort.TryImport/1 cs:1461-1515*/
        if (file.name.lowercase().endsWith(".hma")) {
            val edit = String(file.contents, Charsets.UTF_8)
            pathContext = Path.getDirectoryName(Path.getFullPath(file.name))
            edit(edit)
            return true
        } else if (file.name.lowercase().endsWith(".ips")) {
            history.changeCompleted()
            history.clearHistory(needsSave = true)
            val destination = Patcher.applyIPSPatch(model, file.contents, NoTrackChange())
            if (destination >= 0) reloadMetadata(model.rawData, model.exportMetadata(refTable, singletons.metadataInfo)?.serialize())
            goto?.execute(destination)
            return true
        } else if (file.name.lowercase().endsWith(".ups")) {
            history.changeCompleted()
            val direction = Ref(Patcher.UpsPatchDirection.Fail)
            var destination = Patcher.applyUPSPatch(model, file.contents, { NoTrackChange() }, false, direction)
            _scroll.dataLength = model.count
            when (destination) {
                -1 -> raiseError("UPS Header didn't match!")
                -2 -> {
                    val choice = fileSystem.showOptions(
                        "UPS Patch Error", "The UPS source-file check failed: it isn't meant to be run on this file.", null,
                        VisualOption().also {
                            it.option = "Apply It Anyway"
                            it.index = 0
                            it.shortDescription = "This is UNsafe"
                            it.description = "Applying a UPS when the checksum doesn't match can break your file.\nBut if you're sure that the patch doesn't interfere with any changes to your rom, you may choose to run it anyway."
                        },
                        VisualOption().also {
                            it.option = "Cancel"
                            it.index = 1
                            it.shortDescription = "This is SAFE"
                            it.description = "The UPS will instead be opened as a hex file in a separate tab."
                        }
                    )
                    if (choice == 0) {
                        destination = Patcher.applyUPSPatch(model, file.contents, { NoTrackChange() }, true, direction)
                        _scroll.dataLength = model.count
                    } else {
                        return false
                    }
                    if (destination == -3) raiseError("Patch file is corrupt! (CRC doesn't match!)")
                }
                -3 -> raiseError("Patch file is corrupt! (CRC doesn't match!)")
                -4 -> raiseError("Source file size doesn't match!")
                -5 -> raiseError("Result file CRC doesn't match! Patch was still applied.")
                -6 -> raiseError("UPS chunks are corrupted! Patch was still applied.")
                -7 -> raiseError("Tried to write past the end of the result file! Patch was still applied.")
            }

            history.clearHistory(needsSave = true)
            if (destination >= 0) {
                reloadMetadata(model.rawData, model.exportMetadata(refTable, singletons.metadataInfo)?.serialize())
                goto?.execute(destination)
                if (direction.value == Patcher.UpsPatchDirection.SourceToDestination) {
                    raiseMessage("Applied UPS: source->destination patch.")
                } else if (direction.value == Patcher.UpsPatchDirection.DestinationToSource) {
                    raiseMessage("Reverted UPS: destination->source patch.")
                }
            }

            return true
        }

        return false
    }
    override fun raiseError(text: String) { /*@DONE ViewPort.RaiseError/1 cs:1517-1520*/
        _tools?.logTool?.logMessages?.add("Error: $text")
        onError(this, text)
    }
    private var deferredMessage: String = ""
    override fun raiseMessage(text: String) { /*@DONE ViewPort.RaiseMessage/1 cs:1523-1527*/
        deferredMessage = text
        _tools?.logTool?.logMessages?.add("Message: $deferredMessage")
        val trayForSchedule = _tools
        if (trayForSchedule != null) trayForSchedule.schedule { raiseMessage() } else raiseMessage()
    }
    private fun raiseMessage() { /*@DONE ViewPort.RaiseMessage/2 cs:1528-1528*/
        onMessage(this, deferredMessage)
    }
    override fun raiseRequestTabChange(tab: ITabContent) { /*@DONE ViewPort.RaiseRequestTabChange/1 cs:1530-1530*/
        requestTabChange(this, TabChangeRequestedEventArgs(tab))
    }
    fun raiseRequestTabChange(args: TabChangeRequestedEventArgs) { /*@DONE ViewPort.RaiseRequestTabChange/2 cs:1531-1531*/
        requestTabChange(this, args)
    }
    fun clearAnchor() { /*@DONE ViewPort.ClearAnchor/1 cs:1533-1543*/
        var startDataIndex = _scroll.viewPointToDataIndex(selectionStart)
        var endDataIndex = _scroll.viewPointToDataIndex(selectionEnd)
        if (startDataIndex > endDataIndex) {
            val swap = startDataIndex
            startDataIndex = endDataIndex
            endDataIndex = swap
        }

        // do the clear with a custom token that can't change data.
        // This anchor-clear is a formatting-only change.
        _scroll.clearTableMode()
        model.clearAnchor(history.insertCustomChange(NoDataChangeDeltaModel()), startDataIndex, endDataIndex - startDataIndex + 1)
        refresh()
    }
    private var inPythonScript: Boolean = /*@INITAUTO ViewPort.inPythonScript cs:1545-1545*/ false /*@ENDINIT*/
    override fun edit(input: String) { /*@DONE ViewPort.Edit/1 cs:1551-1566*/
        if (updateInProgress && !inPythonScript) return
        synchronized(threadlock) {
            updateInProgress = true
            if (inPythonScript) {
                // no chunking / history changes: just do it all here
                editHelper(input, input.length)
                return
            }
            val deferScope = _tools?.deferUpdates
            if (deferScope != null) currentProgressScopes.add(0, deferScope)
            initialWorkLoad = input.length
            postEditWork = 0
            holdWorkHistory = history.continueCurrentTransaction()
            editCore(input)
        }
    }
    override fun edit(input: String, startPercent: Double, endPercent: Double): Task<Unit> { /*@DONE ViewPort.Edit/2 cs:1573-1579*/
        return asyncTask {
            val deferScope = _tools?.deferUpdates
            if (deferScope != null) currentProgressScopes.add(0, deferScope)
            initialWorkLoad = (input.length / (endPercent - startPercent)).toInt()
            postEditWork = ((1 - endPercent) * initialWorkLoad).toInt()
            initialWorkLoad -= postEditWork
            editCoreAsync(input).await()
        }
    }
    private fun editCore(input: String) { /*@DONE ViewPort.EditCore/1 cs:1582-1604*/
        // allow chunking at newline boundaries only
        val chunkSize = maxOf(defaultChunkSize, initialWorkLoad / 100)
        var maxSize = input.length

        if (input.length > chunkSize) {
            val nextNewline = input.substring(chunkSize).indexOf('\n')
            if (nextNewline != -1) maxSize = chunkSize + nextNewline + 1
        }

        exitEditEarly = false
        val i = editHelper(input, maxSize)

        if (exitEditEarly) {
            clearEditWork()
            refresh()
        } else if (input.length > i) {
            progress = (initialWorkLoad - input.length).toDouble() / (initialWorkLoad + postEditWork)
            dispatcher.dispatchWork { editCore(input.substring(i)) }
        } else {
            clearEditWork()
        }
    }
    private fun editCoreAsync(input: String): Task<Unit> { /*@DONE ViewPort.EditCoreAsync/1 cs:1606-1634*/
        return asyncTask {
            val chunkSize = maxOf(defaultChunkSize, initialWorkLoad / 100)
            var maxSize = input.length

            if (input.length > chunkSize) {
                val nextNewline = input.substring(chunkSize).indexOf('\n')
                if (nextNewline != -1) maxSize = chunkSize + nextNewline + 1
            }

            exitEditEarly = false
            var i = 0
            synchronized(threadlock) {
                i = editHelper(input, maxSize)
            }

            if (exitEditEarly) {
                synchronized(threadlock) {
                    clearEditWork()
                    refresh()
                }
            } else if (input.length > i) {
                updateProgress((initialWorkLoad - input.length).toDouble() / (initialWorkLoad + postEditWork)).await()
                editCoreAsync(input.substring(i)).await()
            } else {
                synchronized(threadlock) {
                    clearEditWork()
                }
            }
        }
    }
    private fun editHelper(input: String, maxSize: Int): Int { /*@DONE ViewPort.EditHelper/1 cs:1636-1678*/
        var i = 0
        try {
            i = 0
            while (i < input.length && i < maxSize && !exitEditEarly) {
                val precededByWhitespace = i == 0 || input[i - 1] == ' ' || input[i - 1] == '\n'
                if (input[i] == '@' && input.substring(i).startsWith("@!game")) skipToNextGameCode = false
                if (skipToNextGameCode) {
                    // skip this input
                } else if (input[i] == '.' && input.length > i + 6 && input.substring(i + 1, i + 6).lowercase() == "thumb" && precededByWhitespace) {
                    var lines = input.substring(i).split('\n', '\r')
                    var endLine = (0 until lines.size).firstOrNull { j -> (lines[j] + " ").lowercase().startsWith(".end ") } ?: 0
                    if (endLine == 0) endLine = lines.size - 1
                    lines = lines.take(endLine + 1)
                    val thumbLength = (lines.size - 1) + lines.sumOf { line -> line.length }
                    i += thumbLength - 1
                    insertThumbCode(lines.toTypedArray())
                } else if (input[i] == '.' && input.length > i + 7 && input.substring(i + 1, i + 7).lowercase() == "python" && precededByWhitespace) {
                    var lines = input.substring(i).split('\n', '\r')
                    var endLine = (0 until lines.size).firstOrNull { j -> (lines[j] + " ").lowercase().startsWith(".end ") } ?: 0
                    if (endLine == 0) endLine = lines.size - 1
                    lines = lines.take(endLine + 1)
                    val pythonLength = (lines.size - 1) + lines.sumOf { line -> line.length }
                    i += pythonLength - 1
                    // note that we're ignoring any non-error result here
                    val pythonContent = lines.drop(1).take(maxOf(0, lines.size - 2)).joinToString("\n")
                    val pythonGuard = scope(inPythonScript, true, { inPythonScript = it }) { value -> inPythonScript = value }
                    pythonGuard.using {
                        val result = pythonTool!!.runPythonScript(pythonContent)
                        if (result.hasError && !result.isWarning) {
                            raiseError(result.errorMessage ?: "")
                            exitEditEarly = true
                        }
                    }
                } else {
                    edit(input[i])
                }
                i++
            }
        } catch (e: Throwable) {
            clearEditWork()
            throw e
        }

        return i
    }
    fun insertThumbCode(lines: Array<String>) { /*@DONE ViewPort.InsertThumbCode/1 cs:1680-1685*/
        val start = convertViewPointToAddress(selectionStart)
        val result = _tools!!.codeTool.parser.compile(currentChange, model, start, *lines)
        selectionStart = convertAddressToViewPoint(start + result.count)
        refreshBackingData()
    }
    private fun clearEditWork() { /*@DONE ViewPort.ClearEditWork/1 cs:1687-1695*/
        currentProgressScopes.forEach { scope -> scope.dispose() }
        currentProgressScopes.clear()
        updateInProgress = false
        skipToNextGameCode = false
        pathContext = null
        holdWorkHistory?.dispose()
        holdWorkHistory = null
    }
    override fun edit(key: ConsoleKey) { /*@DONE ViewPort.Edit/3 cs:1697-1743*/
        synchronized(threadlock) {
            ModelCacheScope.createScope(model).using {
                val point = getEditPoint()
                val offset = _scroll.viewPointToDataIndex(point)
                val run = nextRun(offset)
                val element = this[point.x, point.y]
                var underEdit = element.format as? UnderEdit
                if (key == ConsoleKey.Enter && underEdit != null) {
                    val editOptions = underEdit.autocompleteOptions
                    if (editOptions != null && editOptions.any { option -> option.isSelected }) {
                        val selectedIndex = AutoCompleteSelectionItem.selectedIndex(editOptions)
                        underEdit = UnderEdit(underEdit.originalFormat, editOptions[selectedIndex].completionText, underEdit.editWidth)
                        currentView[point.x][point.y] = HexElement(element.value, element.edited, underEdit)
                        requestMenuClose(this, EventArgs.empty)
                        tryCompleteEdit(point)
                    } else {
                        edit("\n")
                    }
                    return
                }
                if (key == ConsoleKey.Enter && run is ITableRun) {
                    val offsets = run.convertByteOffsetToArrayOffset(offset)
                    silentScroll(offsets.segmentStart + run.elementLength)
                }
                if (key == ConsoleKey.Tab && run is ITableRun) {
                    val offsets = run.convertByteOffsetToArrayOffset(offset)
                    silentScroll(offsets.segmentStart + run.elementContent[offsets.segmentIndex].length)
                }
                if (key == ConsoleKey.Escape) {
                    clearEdits(selectionStart)
                    clearMessage(this, EventArgs.empty)
                    requestMenuClose(this, EventArgs.empty)
                }

                if (key != ConsoleKey.Backspace) return

                // special case: when an entire run is selected, tread backspace like delete
                //   (special case doesn't apply to short runs like IScriptStartRun, NoInfoRun, or PointerRun)
                if (run.length > 4 && _scroll.viewPointToDataIndex(selectionStart) == run.start && _scroll.viewPointToDataIndex(selectionEnd) == run.start + run.length - 1) {
                    _clear.execute()
                    return
                }

                acceptBackspace(underEdit, element.value, point)
            }
        }
    }
    fun autocomplete(input: String) { /*@DONE ViewPort.Autocomplete/1 cs:1745-1765*/
        val point = selectionStart
        val element = this[point.x, point.y]
        var underEdit = (element.format as? UnderEdit) ?: return
        var tryComplete = true
        val options = underEdit.autocompleteOptions
        if (options != null) {
            val index = options.map { option -> option.completionText }.indexOf(input)
            underEdit = UnderEdit(underEdit.originalFormat, options[index].completionText, underEdit.editWidth)
            tryComplete = options[index].isFormatComplete
        } else {
            underEdit = UnderEdit(underEdit.originalFormat, input, underEdit.editWidth)
        }
        currentView[point.x][point.y] = HexElement(element.value, element.edited, underEdit)
        if (tryComplete) {
            tryCompleteEdit(point)
        } else {
            notifyCollectionChanged(resetArgs) // refresh the view
        }
    }
    fun repointToNewCopy(pointer: Int) { /*@DONE ViewPort.RepointToNewCopy/1 cs:1767-1833*/
        // if the pointer points to nothing
        val destinationAddress = model.readPointer(pointer)
        if (destinationAddress == Pointer.null_) {
            createNewData(pointer)
            return
        }

        // if the pointer is expected to point to a type of data, but doesn't
        val destination = nextRun(destinationAddress)
        val parentRun = nextRun(pointer)
        if (parentRun is ITableRun) {
            val offset = parentRun.convertByteOffsetToArrayOffset(pointer)
            val pSegment = parentRun.elementContent[offset.segmentIndex]
            if (pSegment is ArrayRunPointerSegment) {
                val runRef = Ref<IFormattedRun?>(destination)
                val strategy = model.formatRunFactory.getStrategy(pSegment.innerFormat, true)
                val error = strategy?.tryParseData(model, "", destinationAddress, runRef)
                if (error == null || error.hasError) {
                    createNewData(pointer)
                    return
                }
            }
        }

        // if the pointer points to the right type of data, but with no run
        if (destination.start != destinationAddress) {
            repointWithoutRun(pointer, destinationAddress)
            return
        }

        if (destination is ArrayRun) {
            raiseError("Cannot automatically duplicate a table. This operation is unsafe.")
            return
        }

        var newDestination: Int
        if (destination is LZRun && destination.hasLengthErrors) {
            // we can repoint this
            val uncompressed = LZRun.decompress(model, destination.start, true)!!
            val newCompressed = LZRun.compress(uncompressed.asByteList())
            newDestination = model.findFreeSpace(destination.start, newCompressed.count)
            if (newDestination == -1) {
                newDestination = model.count
                model.expandData(history.currentChange, model.count + newCompressed.count)
            }

            history.currentChange.changeData(model, newDestination, newCompressed)
        } else if ((destination.pointerSources?.size ?: 0) < 2) {
            raiseError("This is the only pointer, no need to make a new copy.")
            return
        } else {
            newDestination = model.findFreeSpace(destination.start, destination.length)
            if (newDestination == -1) {
                newDestination = model.count
                model.expandData(history.currentChange, model.count + destination.length)
            }

            for (i in 0 until destination.length) {
                history.currentChange.changeData(model, newDestination + i, model[destination.start + i])
            }
        }

        model.clearPointer(currentChange, pointer, destination.start)
        model.writePointer(currentChange, pointer, newDestination) // point to the new destination
        val destination2 = nextRun(destination.start)
        model.observeRunWritten(currentChange, destination2.duplicate(newDestination, SortedSpan(pointer))) // create a new run at the new destination
        raiseMessage("New copy added at " + newDestination.toHex(6) + ".")
    }
    fun openInNewTab(destination: Int) { /*@DONE ViewPort.OpenInNewTab/1 cs:1835-1839*/
        val child = ViewPort(fileName, model, dispatcher, singletons, mapper?.tutorials, mapper?.fileSystem, pythonTool, history, mapper?.templates)
        child.selection.gotoAddress(destination)
        requestTabChange(this, TabChangeRequestedEventArgs(child))
    }
    private fun createNewData(pointer: Int): Boolean { /*@DONE ViewPort.CreateNewData/1 cs:1841-1867*/
        val errorText = "Can only create new data for a pointer with a format within a table."
        val tableRun = nextRun(pointer) as? ITableRun
        if (tableRun == null) {
            raiseError(errorText)
            return false
        }
        val offsets = tableRun.convertByteOffsetToArrayOffset(pointer)
        val pointerSegment = tableRun.elementContent[offsets.segmentIndex] as? ArrayRunPointerSegment
        if (pointerSegment == null || !pointerSegment.isInnerFormatValid) {
            raiseError(errorText)
            return false
        }

        val length = model.formatRunFactory.getStrategy(pointerSegment.innerFormat)!!.lengthForNewRun(model, pointer)

        var insert = model.findFreeSpace(0, length)
        if (insert < 0) {
            insert = model.count
            model.expandData(currentChange, model.count + length)
            _scroll.dataLength = model.count
        }
        pointerSegment.writeNewFormat(model, currentChange, pointer, insert, tableRun.elementContent)
        val newTable = nextRun(insert)
        if (newTable is ITableRun) newTable.append(currentChange, 0) // append 0 to force-update the parent count field

        raiseMessage("New data added at ${insert.toHex(6)}")
        refreshBackingData()
        return true
    }
    private fun repointWithoutRun(source: Int, destination: Int) { /*@DONE ViewPort.RepointWithoutRun/1 cs:1875-1916*/
        if (!destination.inRange(0, model.count)) {
            raiseError("Could not find suitable freespace to use for the repoint.")
            return
        }
        val table = nextRun(source) as? ITableRun
        if (table == null) {
            raiseError("Could not parse a data format for that pointer.")
            return
        }
        val offset = table.convertByteOffsetToArrayOffset(source)
        val segment = table.elementContent[offset.segmentIndex] as? ArrayRunPointerSegment
        if (segment == null) {
            raiseError("Could not parse a data format for that pointer.")
            return
        }
        val strategy = model.formatRunFactory.getStrategy(segment.innerFormat)
        if (strategy == null) {
            raiseError("Could not parse a data format for that pointer.")
            return
        }
        val runRef = Ref<IFormattedRun?>(NoInfoRun(destination, SortedSpan(source)))
        if (strategy.tryParseData(model, "", destination, runRef)!!.hasError) {
            raiseError("Could not parse a data format for that pointer.")
            return
        }
        val run = runRef.value!!

        var newDestination = model.findFreeSpace(destination, run.length)
        if (newDestination == -1) {
            newDestination = model.count
            model.expandData(history.currentChange, model.count + run.length)
        }

        for (i in 0 until run.length) {
            history.currentChange.changeData(model, newDestination + i, model[destination + i])
        }

        model.writePointer(currentChange, source, newDestination) // point to the new destination
        val newRun = run.duplicate(newDestination, SortedSpan(source))
        model.observeRunWritten(currentChange, newRun) // create a new run at the new destination
        raiseMessage("Run moved to ${newDestination.toHex(6)}. This pointer was updated, original data was not modified.")
        refresh()
    }
    private fun acceptBackspace(underEdit: UnderEdit?, cellValue: Int, point: Point) { /*@DONE ViewPort.AcceptBackspace/1 cs:1918-2045*/
        var point = point
        // backspace in progress with characters left: just clear a character
        if (underEdit != null && underEdit.currentText.length > 0) {
            val newText = underEdit.currentText.substring(0, underEdit.currentText.length - 1)
            var options: Iterable<AutoCompleteSelectionItem>? = underEdit.autocompleteOptions
            val currentOptions = underEdit.autocompleteOptions
            if (currentOptions != null) {
                val selectedIndex = AutoCompleteSelectionItem.selectedIndex(currentOptions)
                options = getAutocompleteOptions(underEdit.originalFormat, cellValue, newText, selectedIndex)
            }
            val newFormat = UnderEdit(underEdit.originalFormat, newText, underEdit.editWidth, options)
            currentView[point.x][point.y] = HexElement(this[point.x, point.y], newFormat)
            notifyCollectionChanged(resetArgs)
            return
        }

        var index = _scroll.viewPointToDataIndex(point)

        // backspace on an empty element: clear the data from those cells
        if (underEdit != null) {
            val operation = DataClear(model, history.currentChange, index)
            val currentValue = if (index < model.count) model[index] else 0
            underEdit.originalFormat?.visit(operation, currentValue)
            refreshBackingData()
            selectionStart = _scroll.dataIndexToViewPoint(index - 1)
            point = getEditPoint()
            index = _scroll.viewPointToDataIndex(point)
        }

        val run = nextRun(index)
        val cell = this[point.x, point.y]
        var unwrapped = cell.format
        while (unwrapped is IDataFormatDecorator) unwrapped = unwrapped.originalFormat
        val format = unwrapped
        val cellToText = ConvertCellToText(model, index)
        format?.visit(cellToText, cell.value)
        if (format is IDataFormatInstance) {
            selectionStart = _scroll.dataIndexToViewPoint(format.source)
            val editText = cellToText.result.substring(0, cellToText.result.length - 1)
            currentView[selectionStart.x][selectionStart.y] = HexElement(cell.value, cell.edited, cell.format!!.edit(editText))
            notifyCollectionChanged(resetArgs)
            return
        }

        if (run.start > index) {
            // no run: doing a raw edit.
            selectionStart = _scroll.dataIndexToViewPoint(index)
            val element = this[selectionStart.x, selectionStart.y]
            val text = element.value.toHex(2)
            currentView[selectionStart.x][selectionStart.y] = HexElement(element, element.format!!.edit(text.substring(0, text.length - 1)))
            notifyCollectionChanged(resetArgs)
            return
        }

        if (run is PCSRun || run is AsciiRun) {
            for (i in index until run.start + run.length) history.currentChange.changeData(model, i, 0xFF)
            val length = PCSString.readString(model, run.start, true)
            if (run is PCSRun) model.observeRunWritten(history.currentChange, PCSRun(model, run.start, length, run.pointerSources))
            refreshBackingData()
            selectionStart = _scroll.dataIndexToViewPoint(index - 1)
            return
        }

        val tablePoint = point
        fun tableBackspace(length: Int) {
            prepareForMultiSpaceEdit(tablePoint, length)
            cell.format!!.visit(cellToText, cell.value)
            var text = cellToText.result
            if (format is BitArray) {
                for (i in 1 until length) {
                    val extraData = model[_scroll.viewPointToDataIndex(tablePoint) + i]
                    cell.format!!.visit(cellToText, extraData)
                    text += cellToText.result
                }
            }
            text = text.substring(0, text.length - 1)
            currentView[tablePoint.x][tablePoint.y] = HexElement(cell, UnderEdit(cell.format, text, length))
        }

        if (run is ITableRun) {
            val array: ITableRun = run
            val offsets = array.convertByteOffsetToArrayOffset(index)
            val segmentType = array.elementContent[offsets.segmentIndex].type
            if (segmentType == ElementContentType.PCS) {
                for (i in index + 1 until offsets.segmentStart + array.elementContent[offsets.segmentIndex].length) history.currentChange.changeData(model, i, 0x00)
                history.currentChange.changeData(model, index, 0xFF)
                refreshBackingData()
                _scroll.updateHeaders()
                selectionStart = _scroll.dataIndexToViewPoint(index - 1)
            } else if (segmentType == ElementContentType.Pointer) {
                tableBackspace(4)
            } else if (segmentType == ElementContentType.Integer) {
                tableBackspace((format as Integer).length)
            } else if (segmentType == ElementContentType.BitArray) {
                tableBackspace((format as BitArray).length)
            } else {
                throw NotImplementedException()
            }
            notifyCollectionChanged(resetArgs)
            return
        }

        if (run is EggMoveRun || run is PLMRun) {
            prepareForMultiSpaceEdit(point, 2)
            cell.format!!.visit(cellToText, cell.value)
            var text = cellToText.result
            text = text.substring(0, text.length - 1)
            currentView[point.x][point.y] = HexElement(cell, UnderEdit(cell.format, text, 2))
            notifyCollectionChanged(resetArgs)
            return
        }

        if (run.start <= index && run.start + run.length > index) {
            // I want to do a backspace at the end of this run
            selectionStart = _scroll.dataIndexToViewPoint(run.start)
            val element = this[selectionStart.x, selectionStart.y]
            element.format!!.visit(cellToText, element.value)
            val text = cellToText.result

            var editLength = 1
            if (element.format is Pointer) editLength = 4

            for (i in 0 until run.length) {
                val p = _scroll.dataIndexToViewPoint(run.start + i)
                val editString = if (i == 0) text.substring(0, text.length - 1) else ""
                if (i > 0) editLength = 1
                val newFormat = UnderEdit(this[p.x, p.y].format, editString, editLength)
                currentView[p.x][p.y] = HexElement(this[p.x, p.y], newFormat)
            }
        }

        notifyCollectionChanged(resetArgs)
    }
    private var _findBytes: ByteArray? = null
    override var findBytes: ByteArray?
        get() { /*@DONE ViewPort.FindBytes.get cs:2051-2051*/
            return _findBytes
        }
        set(value) { /*@DONE ViewPort.FindBytes.set cs:2052-2056*/
            _findBytes = value
            notifyPropertyChanged("findBytes")
            refreshBackingDataFull()
        }
    override fun find(rawSearch: String, matchExactCase: Boolean): List<IViewPortFindTuple> { /*@DONE ViewPort.Find/1 cs:2059-2114*/
        val results = ArrayList<IViewPortFindTuple>()
        var cleanedSearchString = rawSearch
        if (!matchExactCase) cleanedSearchString = rawSearch.uppercase().trim()
        val searchBytes: MutableList<ISearchByte> = ArrayList()

        // it might be a string with no quotes, we should check for matches for that.
        if (cleanedSearchString.length > 3 && !cleanedSearchString.contains(stringDelimeter) && !cleanedSearchString.all { c -> allHexCharacters.contains(c) }) {
            for (found in findUnquotedText(cleanedSearchString, searchBytes, matchExactCase)) results.add(IViewPortFindTuple(found.first, found.second))
        }

        // it might be a matched-word
        val matchedWords = model.getMatchedWords(rawSearch)
        if (matchedWords != null && matchedWords.size > 0) {
            for (word in matchedWords) results.add(IViewPortFindTuple(word, word))
        }

        // it might be a pointer without angle braces
        if (cleanedSearchString.length == 6 && cleanedSearchString.all { c -> allHexCharacters.contains(c) }) {
            val parsed = parse(cleanedSearchString)
            for (j in parsed.indices.reversed()) searchBytes.add(SearchByte(parsed[j].toInt() and 0xFF))
            searchBytes.add(SearchByte(0x08))
            for (result in model.search(searchBytes)) results.add(IViewPortFindTuple(result, result + 3))
        }

        // it might be a word
        if (cleanedSearchString.length == 8 && cleanedSearchString.all { c -> allHexCharacters.contains(c) }) {
            val parsed = parse(cleanedSearchString)
            for (j in parsed.indices.reversed()) searchBytes.add(SearchByte(parsed[j].toInt() and 0xFF))
            for (result in model.search(searchBytes)) results.add(IViewPortFindTuple(result, result + 3))
        }

        // it might be a bl command
        if (cleanedSearchString.startsWith("BL ") && cleanedSearchString.contains("<") && cleanedSearchString.endsWith(">")) {
            for (found in findBranchLink(cleanedSearchString)) results.add(IViewPortFindTuple(found.first, found.second))
        }

        // attempt to parse the search string fully
        if (tryParseSearchString(searchBytes, cleanedSearchString, results.size == 0)) {
            // find matches
            val searchLength = searchBytes.size // C# reads Count lazily while the iterator is paused; Kotlin search() is eager and clears the list at the end
            val textResults = model.search(searchBytes).map { result -> Pair(result, result + searchLength - 1) }.toList()
            for (found in textResults) results.add(IViewPortFindTuple(found.first, found.second))
            // find data matches for the results that are in tables
            for (result in textResults) {
                val parentArray = nextRun(result.first)
                if (parentArray is ArrayRun && parentArray.lengthFromAnchor == "") {
                    for (found in findMatchingDataResultsFromArrayElement(parentArray, result.first)) results.add(IViewPortFindTuple(found.first, found.second))
                }
            }
        }

        // reorder the list to start at the current cursor position
        results.sortWith(compareBy<IViewPortFindTuple> { it.start })
        val offset = _scroll.viewPointToDataIndex(selectionStart)
        val left = results.filter { result -> result.start < offset }
        val right = results.filter { result -> result.start >= offset }
        val reordered = ArrayList<IViewPortFindTuple>(right)
        reordered.addAll(left)
        notifyNumberOfResults(rawSearch, reordered.size)
        return reordered
    }
    private fun findBranchLink(command: String): Iterable<Pair<Int, Int>> { /*@DONE ViewPort.FindBranchLink/1 cs:2116-2154*/
        val results = ArrayList<Pair<Int, Int>>()
        val addressStart = command.indexOf(" <") + 2
        val addressEnd = command.lastIndexOf(">")
        if (addressEnd < addressStart) return results
        val addressText = command.substring(addressStart, addressEnd)
        val addressRef = Ref(0)
        var address: Int
        if (tryParseHexInt(addressText, addressRef)) {
            address = addressRef.value
        } else {
            address = model.getAddressFromAnchor(currentChange, -1, addressText)
            if (address < 0 || address >= model.count) return results
        }

        // I want to know, for any given point in the raw data, if it's possible a branch-link command pointing to `address`
        // branch link commands are always 4 bytes and have the following format:
        // 11111 #11 11110 #11, where #=pc+#*2+4
        // note that this command is 4 bytes long, stored byte reversed. So in the data, it's:
        // 8 bits: bits 11-18 of a 22 bit signed offset
        // 8 bits:
        //         the low 3 bits are bits 19-21 of a 22 bit signed offset
        //         the high 5 bits are always 11110
        // 8 bits: bits 0-7 of a 22 bit signed offset
        // 8 bits:
        //         the low 3 bits are bits 8-10 of a 22 bit signed offset
        //         the high 5 bits are always 11111
        // the command is always 2-byte aligned
        //
        // bit order is really weird (11-18, 19-21, 0-7, 8-10) because BL is made of **2** instructions,
        // and each instruction is stored little-endian

        // start as early as possible in the file: maximum offset, or offset for source=0
        val raw = model.rawData
        var offset = minOf(0b0111111111111111111111, (address - 4) / 2)
        while (true) { // traveling down the offsets means traveling up the source options
            val source = address - 4 - offset * 2
            if (source + 4 > raw.size) break
            if (source >= 0) {
                val b0 = raw[source + 0].toInt() and 0xFF
                val b1 = raw[source + 1].toInt() and 0xFF
                val b2 = raw[source + 2].toInt() and 0xFF
                val b3 = raw[source + 3].toInt() and 0xFF
                // check source+2 first because it's the simplest, and thus fastest
                if (b2 == (offset and 0xFF) &&
                    b0 == ((offset shr 11) and 0xFF) &&
                    b3 == (0b11111000 or (0b111 and (offset shr 8))) &&
                    b1 == (0b11110000 or (0b111 and (offset shr 19)))) {
                    results.add(Pair(source, source + 3))
                }
            }
            offset--
        }
        return results
    }
    private fun findUnquotedText(cleanedSearchString: String, searchBytes: MutableList<ISearchByte>, matchExactCase: Boolean): Iterable<Pair<Int, Int>> { /*@DONE ViewPort.FindUnquotedText/1 cs:2156-2178*/
        val results = ArrayList<Pair<Int, Int>>()
        val containsBadCharacters = Ref(false)
        val pcsBytes = model.textConverter.convert(cleanedSearchString, containsBadCharacters)!!
        pcsBytes.removeAt(pcsBytes.size - 1) // remove the 0xFF that was added, since we're searching for a string segment instead of a whole string.

        // only search for the string if every character in the search string is allowed
        if (containsBadCharacters.value) return results

        for (b in pcsBytes) searchBytes.add(PCSSearchByte.create(b, matchExactCase))
        val textResults = model.search(searchBytes).toList()
        model.considerResultsAsTextRuns({ NoTrackChange() }, textResults) // don't add auto-recognized text to undo/redo
        for (result in textResults) {
            // also look for elements that use that text as a name or value
            // (if matching exact case, we only want to find text: skip this step)
            val parentArray = nextRun(result)
            if (!matchExactCase && parentArray is ArrayRun && parentArray.lengthFromAnchor == "") {
                for (dataResult in findMatchingDataResultsFromArrayElement(parentArray, result)) results.add(dataResult)
            }

            results.add(Pair(result, result + pcsBytes.size - 1))
        }

        // it could also be a list token. Look for matches among list enums.
        for (dataResult in model.findListUsages(cleanedSearchString)) results.add(Pair(dataResult.start, dataResult.end))
        return results
    }
    private fun findMatchingDataResultsFromArrayElement(parentArray: ArrayRun, parentIndex: Int): Iterable<Pair<Int, Int>> { /*@DONE ViewPort.FindMatchingDataResultsFromArrayElement/1 cs:2185-2194*/
        val offsets = parentArray.convertByteOffsetToArrayOffset(parentIndex)
        val parentArrayName = model.getAnchorFromAddress(-1, parentArray.start)
        if (offsets.segmentIndex == 0 && parentArray.elementContent[offsets.segmentIndex].type == ElementContentType.PCS) {
            val arrayUses = findTableUsages(offsets, parentArrayName)
            val streamUses = findStreamUsages(offsets, parentArrayName)
            return arrayUses + streamUses
        }
        return emptyList()
    }
    private fun findTableUsages(offsets: ArrayOffset, parentArrayName: String): Iterable<Pair<Int, Int>> { /*@DONE ViewPort.FindTableUsages/1 cs:2196-2220*/
        val results = ArrayList<Pair<Int, Int>>()
        for (child in model.all<ITableRun>() ?: emptyList()) {
            // option 1: another table has a row named after this element
            if (child is ArrayRun && child.lengthFromAnchor == parentArrayName) {
                val address = child.start + child.elementLength * offsets.elementIndex
                results.add(Pair(address, address + child.elementLength - 1))
            }

            // option 2: another table has an enum named after this element
            var segmentOffset = 0
            for (segment in child.elementContent) {
                if (segment !is ArrayRunEnumSegment || segment.enumName != parentArrayName) {
                    segmentOffset += segment.length
                    continue
                }
                for (i in 0 until child.elementCount) {
                    val address = child.start + child.elementLength * i + segmentOffset
                    val enumValue = model.readMultiByteValue(address, segment.length)
                    if (enumValue != offsets.elementIndex) continue
                    results.add(Pair(address, address + segment.length - 1))
                }
                segmentOffset += segment.length
            }
        }
        return results
    }
    private fun findStreamUsages(offsets: ArrayOffset, parentArrayName: String): Iterable<Pair<Int, Int>> { /*@DONE ViewPort.FindStreamUsages/1 cs:2222-2243*/
        val results = ArrayList<Pair<Int, Int>>()
        for (child in model.streams) {
            // option 1: the value is used by egg moves
            if (child is EggMoveRun) {
                for (result in child.search(parentArrayName, offsets.elementIndex)) results.add(Pair(result.item1, result.item2))
            }
            // option 2: the value is used by learnable moves
            if (child is PLMRun && parentArrayName == HardcodeTablesModel.moveNamesTable) {
                for (result in child.search(offsets.elementIndex)) results.add(Pair(result.item1, result.item2))
            }
            // option 3: the value is a move used by trainer teams
            if (child is TrainerPokemonTeamRun) {
                for (result in child.search(parentArrayName, offsets.elementIndex)) {
                    results.add(Pair(result, result + 1))
                }
            }
            // option 3: the value is in an enum used by a custom table stream
            if (child is TableStreamRun) {
                for (result in child.search(parentArrayName, offsets.elementIndex)) results.add(Pair(result.item1, result.item2))
            }
        }
        return results
    }
    private fun notifyNumberOfResults(rawSearch: String, results: Int) { /*@DONE ViewPort.NotifyNumberOfResults/1 cs:2245-2251*/
        if (results == 1) {
            raiseMessage("Found only 1 match for '$rawSearch'.")
        } else if (results > 1) {
            raiseMessage("Found $results matches for '$rawSearch'.")
        }
    }
    private fun parse(content: String): ByteArray { /*@DONE ViewPort.Parse/1 cs:2253-2261*/
        val result = ByteArray(content.length / 2)
        for (i in 0 until result.size) {
            val thisByte = content.substring(i * 2, i * 2 + 2)
            result[i] = (result[i] + (allHexCharacters.indexOf(thisByte[0]) * 0x10)).toByte()
            result[i] = (result[i] + allHexCharacters.indexOf(thisByte[1])).toByte()
        }
        return result
    }
    private fun tryParseSearchString(searchBytes: MutableList<ISearchByte>, cleanedSearchString: String, errorOnParseError: Boolean): Boolean { /*@DONE ViewPort.TryParseSearchString/1 cs:2263-2296*/
        val position = Ref(0)
        while (position.value < cleanedSearchString.length) {
            val i = position.value
            if (cleanedSearchString[i] == ' ') {
                position.value = i + 1
                continue
            }

            if (cleanedSearchString[i] == pointerStart) {
                if (!tryParsePointerSearchSegment(searchBytes, cleanedSearchString, position)) return false
                continue
            }

            if (cleanedSearchString[i] == stringDelimeter) {
                if (tryParseStringSearchSegment(searchBytes, cleanedSearchString, position)) continue
            }

            if (cleanedSearchString.length >= i + 2 && cleanedSearchString.substring(i, i + 2) == "XX") {
                searchBytes.add(SearchByte.wild)
                position.value = i + 2
                continue
            }

            if (cleanedSearchString.length >= i + 2 && cleanedSearchString.substring(i, i + 2).all { c -> allHexCharacters.contains(c) }) {
                for (b in parse(cleanedSearchString.substring(i, i + 2))) searchBytes.add(SearchByte(b.toInt() and 0xFF))
                position.value = i + 2
                continue
            }

            if (errorOnParseError) raiseError("Could not parse search term ${cleanedSearchString.substring(i)}")
            return false
        }

        return true
    }
    private fun tryParsePointerSearchSegment(searchBytes: MutableList<ISearchByte>, cleanedSearchString: String, i: Ref<Int>): Boolean { /*@DONE ViewPort.TryParsePointerSearchSegment/1 cs:2298-2316*/
        val endIndex = cleanedSearchString.indexOf(pointerEnd, i.value)
        if (endIndex == -1) { onError(this, "Search mismatch: no closing >"); return false }
        val pointerContents = cleanedSearchString.substring(i.value + 1, endIndex)
        val address = model.getAddressFromAnchor(history.currentChange, -1, pointerContents)
        if (address != Pointer.null_) {
            searchBytes.add(SearchByte((address shr 0) and 0xFF))
            searchBytes.add(SearchByte((address shr 8) and 0xFF))
            searchBytes.add(SearchByte((address shr 16) and 0xFF))
            searchBytes.add(SearchByte(0x08))
        } else if (pointerContents.all { c -> allHexCharacters.contains(c) } && pointerContents.length <= 6) {
            val parsed = parse(pointerContents)
            for (j in parsed.indices.reversed()) searchBytes.add(SearchByte(parsed[j].toInt() and 0xFF))
            searchBytes.add(SearchByte(0x08))
        } else {
            onError(this, "Could not parse pointer <$pointerContents>")
            return false
        }
        i.value = endIndex + 1
        return true
    }
    private fun tryParseStringSearchSegment(searchBytes: MutableList<ISearchByte>, cleanedSearchString: String, i: Ref<Int>): Boolean { /*@DONE ViewPort.TryParseStringSearchSegment/1 cs:2318-2330*/
        var endIndex = cleanedSearchString.indexOf(stringDelimeter, i.value + 1)
        while (endIndex > i.value && cleanedSearchString[endIndex - 1] == '\\') endIndex = cleanedSearchString.indexOf(stringDelimeter, endIndex + 1)
        if (endIndex > i.value) {
            val pcsBytes = model.textConverter.convert(cleanedSearchString.substring(i.value, endIndex + 1), Ref(false))!!
            i.value = endIndex + 1
            if (i.value == cleanedSearchString.length) pcsBytes.removeAt(pcsBytes.size - 1)
            for (b in pcsBytes) searchBytes.add(PCSSearchByte(b))
            return true
        } else {
            return false
        }
    }
    override fun createChildView(startAddress: Int, endAddress: Int): IChildViewPort { /*@DONE ViewPort.CreateChildView/1 cs:2334-2361*/
        val child = ChildViewPort(this, dispatcher, singletons)
        child.allowMultipleElementsPerLine = true
        child.preferredWidth = 16
        child.width = minOf(24, width)

        val run = nextRun(startAddress)
        if (run is ArrayRun) {
            val offsets = run.convertByteOffsetToArrayOffset(startAddress)
            val lineStart = run.start + run.elementLength * offsets.elementIndex
            child.goto?.execute(lineStart)
            child.selectionStart = child.convertAddressToViewPoint(startAddress)
            val endPoint = child.convertAddressToViewPoint(endAddress)
            if (endPoint.y - child.selectionStart.y > 3) child.height = endPoint.y - child.selectionStart.y + 1
            child.selectionEnd = endPoint
        } else if (run is ITableRun) {
            child.goto?.execute(run.start)
            child.width = if (run.length <= 32) run.length else run.elementLength
            val endPoint = child.convertAddressToViewPoint(endAddress)
            child.height = endPoint.y + 1
            child.selectionStart = child.convertAddressToViewPoint(startAddress)
            child.selectionEnd = endPoint
        } else {
            child.goto?.execute(startAddress.toHex(2))
            val endPoint = child.convertAddressToViewPoint(endAddress)
            if (endPoint.y > 3) child.height = endPoint.y + 1
            child.selectionEnd = endPoint
        }

        return child
    }
    override fun followLink(x: Int, y: Int) { /*@DONE ViewPort.FollowLink/1 cs:2363-2415*/
        var unwrapped = this[x, y].format
        while (unwrapped is IDataFormatDecorator) unwrapped = unwrapped.originalFormat
        val format = unwrapped

        ModelCacheScope.createScope(model).using {
            // follow pointer
            if (format is Pointer) {
                if (format.destination != Pointer.null_) {
                    _tools?.logTool?.logMessages?.add("Follow Link ${format.destinationAsText}")
                    selection.gotoAddress(format.destination)
                } else if (format.destinationName.isNullOrEmpty()) {
                    onError(this, "null pointers point to nothing, so going to their source isn't possible.")
                } else {
                    onError(this, "Pointer destination ${format.destinationName} not found.")
                }
                return
            }

            // follow word value source
            if (format is MatchedWord) {
                val address = model.getAddressFromAnchor(history.currentChange, -1, format.name.substring(2))
                if (address == Pointer.null_) {
                    onError(this, "No table with name '${format.name.substring(2)}' was found.")
                } else {
                    selection.gotoAddress(address)
                }
                return
            }

            // open tool
            val tray = _tools!!
            val byteOffset = _scroll.viewPointToDataIndex(Point(x, y))
            val currentRun = nextRun(byteOffset)
            if (currentRun is ISpriteRun) {
                tray.spriteTool.spriteAddress = currentRun.start
                tray.selectedIndex = tray.indexOf(tray.spriteTool)
            } else if (currentRun is IPaletteRun) {
                tray.spriteTool.paletteAddress = currentRun.start
                tray.selectedIndex = tray.indexOf(tray.spriteTool)
            } else if (currentRun is IStreamRun) {
                tray.stringTool.address = currentRun.start
                tray.selectedIndex = tray.indexOf(tray.stringTool)
            } else if (currentRun is ITableRun) {
                val offsets = currentRun.convertByteOffsetToArrayOffset(byteOffset)
                if (format is PCS) {
                    tray.stringTool.address = offsets.segmentStart - offsets.elementIndex * currentRun.elementLength
                    tray.selectedIndex = tray.indexOf(tray.stringTool)
                } else {
                    tray.tableTool.address = currentRun.start + offsets.elementIndex * currentRun.elementLength
                    tray.selectedIndex = tray.indexOf(tray.tableTool)
                }
            }
        }
    }
    override fun expandSelection(x: Int, y: Int) { /*@DONE ViewPort.ExpandSelection/1 cs:2417-2456*/
        val index = _scroll.viewPointToDataIndex(selectionStart)
        val run = nextRun(index)
        if (run.start > index || run is NoInfoRun) {
            val length = ThumbParser.getSelectionLength(model, index)
            if (length == -1) return
            selectionEnd = _scroll.dataIndexToViewPoint(index + length - 1)
            _tools!!.selectedTool = _tools!!.codeTool
            _tools!!.codeTool.mode = CodeMode.Thumb
        } else if (run is ITableRun) {
            val offsets = run.convertByteOffsetToArrayOffset(index)
            if (run.elementContent[offsets.segmentIndex].type == ElementContentType.Pointer) {
                followLink(x, y)
            } else {
                selectionStart = _scroll.dataIndexToViewPoint(offsets.segmentStart)
                selectionEnd = _scroll.dataIndexToViewPoint(offsets.segmentStart + run.elementContent[offsets.segmentIndex].length - 1)
            }
        } else if (run is PointerRun) {
            followLink(x, y)
        } else if (run is IScriptStartRun) {
            val tray = _tools!!
            var length = tray.codeTool.scriptParser.getScriptSegmentLength(model, run.start)
            if (run is BSERun) length = tray.codeTool.battleScriptParser.getScriptSegmentLength(model, run.start)
            if (run is ASERun) length = tray.codeTool.animationScriptParser.getScriptSegmentLength(model, run.start)
            if (run is TSERun) length = tray.codeTool.battleAIScriptParser.getScriptSegmentLength(model, run.start)
            selectionStart = _scroll.dataIndexToViewPoint(run.start)
            selectionEnd = _scroll.dataIndexToViewPoint(run.start + length - 1)
            tray.codeTool.mode = CodeMode.Script
            if (run is BSERun) tray.codeTool.mode = CodeMode.BattleScript
            if (run is ASERun) tray.codeTool.mode = CodeMode.AnimationScript
            if (run is TSERun) tray.codeTool.mode = CodeMode.TrainerAiScript
            tray.selectedIndex = tray.indexOf(tray.codeTool)
        } else {
            selectionStart = _scroll.dataIndexToViewPoint(run.start)
            selectionEnd = _scroll.dataIndexToViewPoint(run.start + run.length - 1)
        }
        if (selectionStart == selectionEnd && _scroll.viewPointToDataIndex(selectionStart) >= run.start && _scroll.viewPointToDataIndex(selectionEnd) < run.start + run.length) {
            selectionStart = _scroll.dataIndexToViewPoint(run.start)
            selectionEnd = _scroll.dataIndexToViewPoint(run.start + run.length - 1)
        }
    }
    override fun considerReload(fileSystem: IFileSystem) { /*@DONE ViewPort.ConsiderReload/1 cs:2458-2484*/
        if (!history.isSaved) return // don't overwrite local changes

        fun action() {
            try {
                val file = fileSystem.loadFile(fileName)
                if (file != null) { // if the file wasn't found... carry on
                    val metadata = fileSystem.metadataFor(fileName)
                    reloadMetadata(file.contents, metadata)
                }
            } catch (e: IOException) {
                // something happened when we tried to load the file
                // try again soon.
                requestDelayedWork(this) { considerReload(fileSystem) }
            } catch (e: InvalidOperationException) {
                // failed to compare runs
                // try again soon.
                requestDelayedWork(this) { considerReload(fileSystem) }
            }
        }

        val fileDispatcher = fileSystem as? IWorkDispatcher
        if (fileDispatcher != null) {
            fileDispatcher.blockOnUIWork { action() }
        } else {
            action()
        }
    }
    fun reloadMetadata(data: ByteArray, metadata: Array<String>?) { /*@DONE ViewPort.ReloadMetadata/1 cs:2486-2498*/
        model.load(data, if (metadata != null) StoredMetadata(metadata) else null)
        _scroll.dataLength = model.count
        refreshBackingData()
        model.initializationWorkload.continueWith { _ ->
            cascadeScripts()
            dispatcher.dispatchWork { refreshBackingData() }
            Unit
        }

        // if the new file is shorter, selection might need to be updated
        // this forces it to be re-evaluated.
        val currentSelectionStart = selectionStart
        selectionStart = currentSelectionStart
    }
    override fun findAllSources(x: Int, y: Int) { /*@DONE ViewPort.FindAllSources/1 cs:2500-2504*/
        val anchor = this[x, y].format as? Anchor
        if (anchor == null) return
        findAllSources(convertViewPointToAddress(Point(x, y)))
    }
    fun findAllSources(address: Int) { /*@DONE ViewPort.FindAllSources/2 cs:2506-2517*/
        val name = model.getAnchorFromAddress(-1, address)
        val run = nextRun(address)
        var title = if (name.isEmpty()) address.toAddress() else name
        title = "Sources of $title"
        val newTab = SearchResultsViewPort(title)

        val sources = run.pointerSources
        if (sources != null) {
            for (source in sources) newTab.add(createChildView(source, source), source, source)
        }

        requestTabChange(this, TabChangeRequestedEventArgs(newTab))
        requestMenuClose(this, EventArgs.empty)
    }
    fun openSearchResultsTab(title: String, showSelection: List<ViewPortOpenSearchResultsTabShowSelectionTuple>, gotoSelection: List<ViewPortOpenSearchResultsTabGotoSelectionTuple>? = null) { /*@DONE ViewPort.OpenSearchResultsTab/1 cs:2519-2542*/
        val gotoList: List<ViewPortOpenSearchResultsTabGotoSelectionTuple> = gotoSelection ?: showSelection.map { s -> ViewPortOpenSearchResultsTabGotoSelectionTuple(s.start, s.end) }
        if (showSelection.size == 1) {
            val only = showSelection[0]
            selection.gotoAddress(only.start)
            selectionStart = _scroll.dataIndexToViewPoint(only.start)
            selectionEnd = _scroll.dataIndexToViewPoint(only.end)
            return
        }

        val newTab = SearchResultsViewPort(title)
        for (i in 0 until showSelection.size) {
            val show = showSelection[i]
            val go = gotoList[i]
            newTab.add(createChildView(show.start, show.end), go.start, go.end)
        }
        val args = TabChangeRequestedEventArgs(newTab)
        requestTabChange(this, args)
        val editor = mapEditor
        if (!args.requestAccepted && editor?.isValidState == true) {
            // maybe I'm not the current tab
            // try again from my map editor
            requestTabChange(editor, args)
        }
    }
    fun openDexReorderTab(dexTableName: String) { /*@DONE ViewPort.OpenDexReorderTab/1 cs:2544-2549*/
        val newTab = DexReorderTab(fs!!, this, dexTableName, HardcodeTablesModel.dexInfoTableName, dexTableName == HardcodeTablesModel.nationalDexTableName)
        val args = TabChangeRequestedEventArgs(newTab)
        requestTabChange(this, args)
        if (!args.requestAccepted) mapper?.raiseRequestTabChange(args)
    }
    override fun openImageEditorTab(address: Int, spritePage: Int, palettePage: Int, preferredTileWidth: Int) { /*@DONE ViewPort.OpenImageEditorTab/1 cs:2551-2569*/
        try {
            val newTab = ImageEditorViewModel(history, model, address, save, _tools!!.spriteTool.paletteAddress)
            newTab.spritePage = spritePage
            newTab.palettePage = palettePage
            val args = TabChangeRequestedEventArgs(newTab)
            requestTabChange(this, args)
            val editor = mapEditor
            if (!args.requestAccepted && editor?.isValidState == true) {
                // trying to open from the image editor?
                editor.raiseRequestTabChange(args)
            }
            if (preferredTileWidth != -1 && newTab.canEditTilesetWidth) {
                newTab.currentTilesetWidth = preferredTileWidth.limitToRange(newTab.minimumTilesetWidth, newTab.maximumTilesetWidth)
            }
        } catch (e: ImageEditorViewModelCreationException) {
            raiseError(e.message ?: "")
        }
    }
    private var recentDuplicates: MutableList<ViewPort> = /*@INITDONE ViewPort.RecentDuplicates cs:2571-2571*/ ArrayList<ViewPort>() /*@ENDINIT*/
    override fun gotoScript(address: Int) { /*@DONE ViewPort.GotoScript/1 cs:2572-2607*/
        _tools?.logTool?.logMessages?.add("Goto Script: " + address.toAddress())
        if (recentDuplicates.size == 0) recentDuplicates.add(this)

        var start: Int
        for (tab in recentDuplicates) {
            // if we're already looking at a script, open this in a new tab instead
            start = tab.convertViewPointToAddress(tab.selectionStart)
            if (start == address) {
                // just switch to this tab
                val args = TabChangeRequestedEventArgs(tab)
                requestTabChange(mapper, args)
                if (!args.requestAccepted) mapper?.raiseRequestTabChange(args) // if this tab has been closed, ask the mapper to raise it
                if (args.requestAccepted) {
                    tab.selection.setJumpBackTab(mapper)
                    focusToolPanel(this, EventArgs.empty)
                }
                return
            }
        }

        // no open tab has this script loaded
        // check if we need to make a new tab
        start = convertViewPointToAddress(selectionStart)
        val xse = nextRun(start)
        if (_tools?.selectedTool is CodeTool && xse is XSERun && xse.start == start) {
            val newTab = createDuplicate()
            newTab.recentDuplicates = recentDuplicates
            recentDuplicates.add(newTab)
            newTab.goto?.execute(address)
            mapper?.raiseRequestTabChange(TabChangeRequestedEventArgs(newTab))
        } else {
            // doesn't look like we're going to a script
            // just do a normal goto
            goto?.execute(address)
        }
    }
    private fun validateMatchedWords() { /*@DONE ViewPort.ValidateMatchedWords/1 cs:2609-2623*/
        // TODO if this is too slow, add a method to the model to get the set of only MatchedWordRuns.
        var run = model.getNextRun(0)
        while (run != null && run !== NoInfoRun.nullRun) {
            if (run is WordRun) {
                val address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, run.sourceArrayName)
                val array = if (address == Pointer.null_) null else nextRun(address) as? ArrayRun
                if (array != null) {
                    val actualValue = model.readValue(run.start)
                    if (array.elementCount != actualValue) {
                        raiseMessage("MatchedWord at ${run.start.toHex(6)} was expected to have value ${array.elementCount}, but was $actualValue.")
                        goto?.execute(run.start.toHex(6))
                        break
                    }
                }
            }
            run = model.getNextRun(run.start + maxOf(1, run.length))
        }
    }
    fun insertPalette16() { /*@DONE ViewPort.InsertPalette16/1 cs:2625-2644*/
        val selectionPoint = _scroll.viewPointToDataIndex(selectionStart)
        val run1 = nextRun(selectionPoint)
        val run2 = nextRun(selectionPoint + 1)
        if (run1.start + 32 != run2.start || run1 !is NoInfoRun) {
            raiseError("Palettes insertion requires a no-format anchor with exactly 32 bytes of space.")
            return
        }
        for (i in 0 until 16) {
            if (model.readMultiByteValue(run1.start + i * 2, 2) >= 0x8000) {
                raiseError("Palette colors only use 15 bits, but the high bit it set at ${(run1.start + i * 2 + 1).toHex(6)}.")
                return
            }
        }
        var currentName = model.getAnchorFromAddress(-1, run1.start)
        if (currentName.isEmpty()) currentName = "${HardcodeTablesModel.defaultPaletteNamespace}.${run1.start.toHex(6)}"
        model.observeAnchorWritten(currentChange, currentName, PaletteRun(run1.start, PaletteFormat(4, 1)))
        refresh()
        updateToolsFromSelection(run1.start)
    }
    fun cascadeScript(address: Int) { /*@DONE ViewPort.CascadeScript/1 cs:2646-2667*/
        width = maxOf(width, 16) // hack to make the width right on initial load
        height = maxOf(height, 16) // hack to make the height right on initial load
        val addressText = address.toHex(6)
        goto?.execute(addressText)
        val tray = _tools!!
        val length = tray.codeTool.scriptParser.getScriptSegmentLength(model, address)

        // clear format in a way that won't remove inner-anchors, since some scripts point into other scripts
        var run = nextRun(address)
        while (run.start < address + length) {
            model.clearFormat(currentChange, address, 1)
            run = nextRun(run.start + run.length)
        }

        ModelCacheScope.createScope(model).using {
            tray.codeTool.scriptParser.formatScript<XSERun>(currentChange, model, address)
        }

        selectionStart = _scroll.dataIndexToViewPoint(address)
        selectionEnd = _scroll.dataIndexToViewPoint(address + length - 1)
        tray.codeTool.mode = CodeMode.Script
        tray.selectedIndex = tray.indexOf(tray.codeTool)
    }
    private fun edit(input: Char) { /*@DONE ViewPort.Edit/4 cs:2669-2706*/
        var input = input
        val point = getEditPoint()
        val element = this[point.x, point.y]

        if (input == '\r' || input == '\n') {
            input = ' ' // handle multiline pasting by just treating the newlines as standard whitespace.
            withinComment = false
            if (element.format is PCS || element.format is ErrorPCS) return // exit early: newlines within strings are ignored, because they're escaped.
        }

        if (element.format is UnderEdit && input == ',') input = ' '

        if (!shouldAcceptInput(point, element, input)) {
            clearEdits(point)
            return
        }

        selectionStart = point

        if (element === this[point.x, point.y]) {
            val elementFormat = element.format
            val newFormat: UnderEdit
            if (elementFormat is UnderEdit && elementFormat.autocompleteOptions != null) {
                val newText = elementFormat.currentText + input
                val autoCompleteOptions = getAutocompleteOptions(elementFormat.originalFormat, element.value, newText)
                newFormat = UnderEdit(elementFormat.originalFormat, newText, elementFormat.editWidth, autoCompleteOptions)
            } else {
                newFormat = elementFormat!!.edit(input.toString())
            }
            currentView[point.x][point.y] = HexElement(element, newFormat)
        } else {
            // ShouldAcceptInput already did the work: nothing to change
        }

        if (!tryCompleteEdit(point)) {
            // only need to notify collection changes if we didn't complete an edit
            notifyCollectionChanged(resetArgs)
        }
    }
    private fun getAutocompleteOptions(originalFormat: IDataFormat?, value: Int, newText: String, selectedIndex: Int = -1): Iterable<AutoCompleteSelectionItem>? { /*@DONE ViewPort.GetAutocompleteOptions/1 cs:2708-2714*/
        return ModelCacheScope.createScope(model).using {
            val visitor = AutocompleteCell(model, newText, selectedIndex)
            (originalFormat ?: Undefined.instance).visit(visitor, value)
            visitor.result
        }
    }
    private fun clearEdits(point: Point) { /*@DONE ViewPort.ClearEdits/1 cs:2716-2719*/
        if (this[point.x, point.y].format is UnderEdit) refreshBackingData()
        withinComment = false
    }
    private fun getEditPoint(): Point { /*@DONE ViewPort.GetEditPoint/1 cs:2721-2730*/
        val selStart = _scroll.viewPointToDataIndex(selectionStart)
        val selEnd = _scroll.viewPointToDataIndex(selectionEnd)
        val leftEdge = minOf(selStart, selEnd)

        val point = Ref(_scroll.dataIndexToViewPoint(leftEdge))
        _scroll.scrollToPoint(point)

        return point.value
    }
    private fun isTextExecuted(notUsed: Any?) { /*@DONE ViewPort.IsTextExecuted/1 cs:2732-2750*/
        dispatcher.blockOnUIWork {
            val selStart = _scroll.viewPointToDataIndex(selection.selectionStart)
            val selEnd = _scroll.viewPointToDataIndex(selection.selectionEnd)
            val left = minOf(selStart, selEnd)
            val length = Math.abs(selEnd - selStart) + 1
            val startPlaces = model.findPossibleTextStartingPlaces(left, length)

            // do the actual search now that we know places to start
            val foundCount = model.considerResultsAsTextRuns({ history.insertCustomChange(NoDataChangeDeltaModel()) }, startPlaces)
            if (foundCount == 0) {
                raiseError("Failed to automatically find text at that location.")
            } else {
                refreshBackingData()
            }

            requestMenuClose(this, EventArgs.empty)
        }
    }
    private fun shouldAcceptInput(point: Point, element: HexElement, input: Char): Boolean { /*@DONE ViewPort.ShouldAcceptInput/1 cs:2752-2790*/
        val memoryLocation = _scroll.viewPointToDataIndex(point)

        // special cases: if there's no edit unde way, there's a few formats that can be added anywhere. Handle those first.
        if (element.format !is UnderEdit) {
            if (input == extendArray) {
                val index = _scroll.viewPointToDataIndex(point)
                if (model.isAtEndOfArray(index, Ref<ITableRun?>(null))) return true
            }

            if (input == anchorStart || input == gotoMarker) {
                // anchor edits are actually 0 length
                // but lets give them 4 spaces to work with
                prepareForMultiSpaceEdit(point, 4)
                val autoCompleteOptions: List<AutoCompleteSelectionItem>? = if (input == gotoMarker) ArrayList() else null
                val underEdit = UnderEdit(element.format, input.toString(), 4, autoCompleteOptions)
                currentView[point.x][point.y] = HexElement(element, underEdit)
                return true
            }

            if (input == commentStart) {
                val underEdit = UnderEdit(element.format, input.toString())
                currentView[point.x][point.y] = HexElement(element, underEdit)
                withinComment = true
                return true
            }
        }

        // normal case: the logic for how to handle this edit depends on what format is in this cell.
        val startCellEdit = StartCellEdit(model, memoryLocation, input)
        element.format!!.visit(startCellEdit, element.value)
        val startFormat = startCellEdit.newFormat
        if (startFormat != null) {
            // if the edit provided a new format, go ahead and build a new element based on that format.
            // if no new format was provided, then the default logic in the method above will make a new UnderEdit cell if the Result is true.
            currentView[point.x][point.y] = HexElement(element, startFormat)
            if (startFormat.editWidth > 1) prepareForMultiSpaceEdit(point, startFormat.editWidth)
        }
        return startCellEdit.result
    }
    private fun getSelectionSpan(p: Point): GetSelectionSpanGetSelectionSpanTuple { /*@DONE ViewPort.GetSelectionSpan/1 cs:2792-2819*/
        val index = _scroll.viewPointToDataIndex(p)
        val run = nextRun(index)
        if (run.start > index) return GetSelectionSpanGetSelectionSpanTuple(p, p)

        fun pair(start: Int, end: Int): GetSelectionSpanGetSelectionSpanTuple = GetSelectionSpanGetSelectionSpanTuple(_scroll.dataIndexToViewPoint(start), _scroll.dataIndexToViewPoint(end))

        var unwrapped: IDataFormat? = run.createDataFormat(model, index)
        while (unwrapped is IDataFormatDecorator) unwrapped = unwrapped.originalFormat
        val format = unwrapped
        if (format is IDataFormatInstance) {
            return pair(format.source, format.source + format.length - 1)
        }

        if (run !is ITableRun) return GetSelectionSpanGetSelectionSpanTuple(p, p)
        val array: ITableRun = run

        val naturalEnd = array.start + array.elementCount * array.elementLength
        if (naturalEnd <= index) {
            return pair(naturalEnd, array.start + array.length - 1)
        }

        val offset = array.convertByteOffsetToArrayOffset(index)
        val type = array.elementContent[offset.segmentIndex].type
        if (type == ElementContentType.Pointer || type == ElementContentType.Integer || type == ElementContentType.BitArray) {
            return pair(offset.segmentStart, offset.segmentStart + array.elementContent[offset.segmentIndex].length - 1)
        }

        return GetSelectionSpanGetSelectionSpanTuple(p, p)
    }
    private fun prepareForMultiSpaceEdit(point: Point, length: Int) { /*@DONE ViewPort.PrepareForMultiSpaceEdit/1 cs:2821-2834*/
        var point = point
        val index = _scroll.viewPointToDataIndex(point)
        val endIndex = index + length - 1
        for (i in 1 until length) {
            point = _scroll.dataIndexToViewPoint(index + i)
            if (point.y >= height) return
            val element = this[point.x, point.y]
            val newFormat = element.format!!.edit("")
            currentView[point.x][point.y] = HexElement(element, newFormat)
        }
        selection.propertyChanged -= selectionPropertyChangedHandler // don't notify on multi-space edit: it breaks up the undo history
        selectionEnd = _scroll.dataIndexToViewPoint(endIndex)
        selection.propertyChanged += selectionPropertyChangedHandler
    }
    private fun tryCompleteEdit(point: Point): Boolean { /*@DONE ViewPort.TryCompleteEdit/1 cs:2836-2900*/
        // wrap this whole method in an anti-recursion clause
        selection.previewSelectionStartChanged -= clearActiveEditHandler
        val antiRecursion = StubDisposable { selection.previewSelectionStartChanged += clearActiveEditHandler }
        return antiRecursion.using {
            val element = this[point.x, point.y]
            val underEdit = element.format as? UnderEdit
            if (underEdit == null) return false // no edit to complete

            val generalResult = Ref(false)
            if (tryGeneralCompleteEdit(underEdit.currentText, point, generalResult)) {
                return generalResult.value
            }

            // normal case: whether or not to accept the edit depends on the existing cell format
            val dataIndex = _scroll.viewPointToDataIndex(point)
            val completeEditOperation = CompleteCellEdit(model, _scroll, dataIndex, underEdit.currentText) { history.currentChange }
            ModelCacheScope.createScope(model).using {
                (underEdit.originalFormat ?: Undefined.instance).visit(completeEditOperation, element.value)

                if (completeEditOperation.result) {
                    // if the data we just changed was in a table, notify children of that table about the change
                    val previousRun = nextRun(dataIndex)
                    if (previousRun is ITableRun) {
                        val offsets = previousRun.convertByteOffsetToArrayOffset(dataIndex)
                        val errorInfo = previousRun.notifyChildren(model, history.currentChange, offsets.elementIndex, offsets.segmentIndex)
                        handleErrorInfo(errorInfo)
                    }

                    // update the cell / selection
                    val newCell = completeEditOperation.newCell
                    if (newCell != null) {
                        currentView[point.x][point.y] = newCell
                    }
                    if (completeEditOperation.dataMoved || completeEditOperation.newDataIndex > _scroll.dataLength) {
                        _scroll.dataLength = model.count
                        _scroll.clearTableMode()
                    }

                    // update tools from the new moved selection
                    var run = nextRun(completeEditOperation.newDataIndex)
                    if (run.start > completeEditOperation.newDataIndex) run = NoInfoRun(model.count)
                    if (completeEditOperation.dataMoved) updateToolsFromSelection(run.start)
                    val tray = _tools!!
                    if (run is ITableRun || previousRun is ITableRun) {
                        tray.schedule { tray.tableTool.dataForCurrentRunChanged() }
                    }
                    if (run is ITableRun || run is IStreamRun || previousRun is ITableRun || previousRun is IStreamRun) tray.schedule { tray.stringTool.dataForCurrentRunChanged() }
                    if (run is ISpriteRun || run is IPaletteRun || previousRun is ISpriteRun || previousRun is IPaletteRun) {
                        tray.schedule { tray.spriteTool.dataForCurrentRunChanged() }
                        tray.schedule { tray.tableTool.dataForCurrentRunChanged() }
                    }
                    val messageText = completeEditOperation.messageText
                    if (messageText != null) raiseMessage(messageText)
                    val errorText = completeEditOperation.errorText
                    if (errorText != null) raiseError(errorText)

                    // refresh the screen
                    refreshBackingData(point)
                    if (!silentScroll(completeEditOperation.newDataIndex) && completeEditOperation.newCell == null) {
                        refreshBackingData()
                    }

                    tray.schedule { updateToolsFromSelection() }
                }
            }

            completeEditOperation.result
        }
    }
    private fun tryGeneralCompleteEdit(currentText: String, point: Point, result: Ref<Boolean>): Boolean { /*@DONE ViewPort.TryGeneralCompleteEdit/1 cs:2907-3035*/
        result.value = false

        // goto marker
        if (currentText.startsWith(gotoMarker.toString())) {
            if (currentText.length == 2 && currentText[1] == '{') {
                val currentAddress = _scroll.viewPointToDataIndex(point)
                var destination = model.readPointer(currentAddress)
                if (destination == Pointer.null_) {
                    if (createNewData(currentAddress)) {
                        destination = model.readPointer(currentAddress)
                    } else {
                        raiseError("Could not jump using pointer at ${currentAddress.toHex(6)}")
                    }
                }
                clearEdits(point)
                if (destination >= 0 && destination < model.count) {
                    history.continueCurrentTransaction().using {
                        goto?.execute(destination)
                        selection.setJumpBackPoint(currentAddress + 4)
                    }
                } else if (destination != Pointer.null_) {
                    raiseError("Could not jump using pointer at ${currentAddress.toHex(6)}")
                }
                requestMenuClose(this, EventArgs.empty)
                result.value = true
            } else if (currentText.length == 2 && currentText[1] == '}') {
                clearEdits(point)
                history.continueCurrentTransaction().using { selection.back?.execute() }
                requestMenuClose(this, EventArgs.empty)
                result.value = true
            }
            if (currentText[currentText.length - 1].isWhitespace() && currentText[1] == commandMarker && currentText.count { c -> c == '(' } > currentText.count { c -> c == ')' }) {
                // allow commands to contain spaces
            } else if (currentText[currentText.length - 1].isWhitespace()) {
                val destination = currentText.substring(1).trim()
                clearEdits(point)
                if (currentText.contains("=")) {
                    updateConstant(destination)
                } else {
                    val parts = destination.split(commandMarker)
                    if (parts[0].isNotBlank()) goto?.execute(parts[0])
                    for (i in 1 until parts.size) executeMetacommand(parts[i])
                    updateSelectedBytes()
                }
                requestMenuClose(this, EventArgs.empty)
                result.value = true
            }

            return true
        }

        // comment
        if (currentText.startsWith(commentStart.toString())) {
            if (currentText.length > 1 && currentText.endsWith(commentStart.toString())) withinComment = false
            result.value = (currentText.endsWith(" ") || currentText.endsWith("#")) && !withinComment
            if (result.value) clearEdits(point)
            return true
        }

        // anchor start
        if (currentText.startsWith(anchorStart.toString())) {
            tryUpdate(_anchorText, currentText, "anchorText") { _anchorText = it }
            val endingCharacter = currentText[currentText.length - 1]
            // anchor format will only end once the user
            // -> types a whitespace character,
            // -> types a closing quote for the text format ""
            // -> types a closing ` for a `` format
            if (!endingCharacter.isWhitespace() && !currentText.endsWith(AsciiRun.streamDelimeter.toString()) && !currentText.endsWith(PCSRun.stringDelimeter.toString())) {
                anchorTextVisible = true
                return true
            }

            // special case: `asc` has a length token outside the ``, so the anchor isn't completed if it ends with `asc`
            if (currentText.endsWith("`asc`")) {
                anchorTextVisible = true
                return true
            }

            // only end the anchor edit if the [] brace count matches
            if (currentText.count { c -> c == '[' } - currentText.count { c -> c == ']' } != 0) {
                anchorTextVisible = true
                return true
            }

            // only end the anchor if the "" and `` quote count are even
            if (currentText.count { c -> c == AsciiRun.streamDelimeter } % 2 != 0 || currentText.count { c -> c == stringDelimeter } % 2 != 0) {
                anchorTextVisible = true
                return true
            }

            if (!completeAnchorEdit(point)) exitEditEarly = true
            result.value = true
            return true
        }

        // directive marker
        val element = this[point.x, point.y]
        val underEdit = element.format as? UnderEdit
        if (currentText.startsWith(directiveMarker.toString()) && currentText.count { c -> c == directiveMarker } == 1) {
            if (underEdit?.originalFormat is PCS || underEdit?.originalFormat is Ascii) {
                // if we're in a text cell, don't allow directives.
            } else {
                result.value = completeDirectiveEdit(point, currentText)
                return true
            }
        }

        // table extension
        val dataIndex = _scroll.viewPointToDataIndex(point)
        val arrayRun = Ref<ITableRun?>(null)
        if (currentText == extendArray.toString() && model.isAtEndOfArray(dataIndex, arrayRun)) {
            val originalArray = arrayRun.value
            val errorInfo = model.completeArrayExtension(history.currentChange, 1, arrayRun)
            if (!errorInfo.hasError || errorInfo.isWarning) {
                val extended = arrayRun.value
                if (extended != null && originalArray != null && extended.start != originalArray.start) {
                    // refresh first to clear any active edit cells
                    refreshBackingData(point)
                    scrollFromTableMove(dataIndex, originalArray, extended)
                }
                refreshBackingData()
                selectionEnd = getSelectionSpan(selectionStart).end
            }
            handleErrorInfo(errorInfo)
            result.value = true
            return true
        }

        return false
    }
    private fun updateConstant(expression: String) { /*@DONE ViewPort.UpdateConstant/1 cs:3037-3063*/
        val parts = expression.split('=')
        if (parts.size != 2) {
            raiseError("Could not parse constant assignment expression.")
            return
        }
        val parsedValue = Ref(0)
        if (!tryParseInt(parts[1], parsedValue)) {
            if (!parts[1].startsWith("0x") || !tryParseHexInt(parts[1].substring(2), parsedValue)) {
                raiseError("Could not parse constant assignment expression.")
                return
            }
        }
        val value = parsedValue.value

        val locations = model.getMatchedWords(parts[0])
        if (locations == null || locations.size == 0) {
            model.setUnmappedConstant(currentChange, parts[0], value)
        }

        for (address in locations ?: emptyList()) {
            val currentRun = nextRun(address) as? WordRun
            if (currentRun == null) continue
            val writeValue = value + currentRun.valueOffset
            if (writeValue < 0 || writeValue > 255) {
                raiseError("${currentRun.start.toHex(6)}: value out of range!")
            }
            model.writeMultiByteValue(address, currentRun.length, currentChange, writeValue)
        }
    }
    private fun executeMetacommand(command: String) { /*@DONE ViewPort.ExecuteMetacommand/1 cs:3078-3198*/
        var command = command.lowercase()
        var index = _scroll.viewPointToDataIndex(selectionStart)
        val paramsStart = command.indexOf("(")
        val paramsEnd = command.indexOf(")")
        val lengthRef = Ref(0)
        if (command.startsWith("lz(") && paramsEnd > 3 && tryParseInt(command.substring(3, paramsEnd), lengthRef)) {
            val length = lengthRef.value
            // only do the write if the current data isn't compressed data of the right length
            val existingCompressedData = LZRun.decompress(model, index)
            val newCompressed = LZRun.compress(ByteArray(length).asByteList(), 0, length)

            if (existingCompressedData != null && existingCompressedData.size == length) {
                // do nothing, it's already the right data type
            } else if ((0 until newCompressed.count).all { i -> model[index + i] == 0xFF }) {
                // data is all FF, go ahead and write
                for (i in 0 until newCompressed.count) currentChange.changeData(model, index + i, newCompressed[i])
            } else {
                // data is not freespace and is not the correct data: error
                raiseError("Writing $length compressed bytes would overwrite existing data.")
                exitEditEarly = true
            }
        } else if (command.startsWith("00(") && paramsEnd > 3 && tryParseInt(command.substring(3, paramsEnd), lengthRef)) {
            val length = lengthRef.value
            val currentRun = nextRun(index)
            val tableRun = currentRun as? ITableRun
            if (tableRun != null && currentRun.start == index && length % tableRun.elementLength == 0 && length <= tableRun.length) {
                // we're trying to clear out table data.
                // assume that the user wanted us to clear it.
                // do NOT do the clear if the current clear is bigger than the current table: that could wipe existing data.
                clearPointersFromTable(tableRun, index, length)
                for (i in 0 until length) currentChange.changeData(model, index + i, 0)
            } else if (tableRun == null && currentRun.start == index && currentRun.length == length) {
                // we're trying to clear out a non-table
                // the length matches exactly, so we shouldn't error. But also, don't actually clear.
            } else if ((0 until length).all { i -> model[index + i] == 0xFF }) {
                for (i in 0 until length) currentChange.changeData(model, index + i, 0)
            } else {
                raiseError("Writing $length 00 bytes would overwrite existing data.")
                exitEditEarly = true
            }
        } else if (command.startsWith("ff(") && paramsEnd > 3 && command.substring(3, paramsEnd).tryParseInt(lengthRef)) {
            val length = lengthRef.value
            val currentRun = nextRun(index)
            if (currentRun.start < index || (currentRun.start == index && currentRun !is NoInfoRun) || (currentRun.start > index && currentRun.start < index + length)) {
                raiseError("Writing $length FF bytes would overwrite formatted data.")
                exitEditEarly = true
            } else {
                for (i in 0 until length) currentChange.changeData(model, index + i, 0xFF)
            }
        } else if (command.startsWith("game(") && paramsEnd > 5) {
            val content = command.substring(5, paramsEnd).lowercase()
            val gameCode = model.getGameCode().lowercase()
            if (content == "all") {
                // all good
            } else if (!content.contains(gameCode)) {
                skipToNextGameCode = true
            }
        } else if (command.startsWith("put(") && paramsEnd > 4) {
            val content = command.substring(4, paramsEnd)
            if (content.length % 2 != 0 || !content.all { c -> allHexCharacters.contains(c) }) {
                raiseError("'put' expects hex bytes as an argument. ")
                exitEditEarly = true
                return
            }
            for (i in 0 until content.length / 2) {
                val data = content.substring(i * 2, i * 2 + 2).toInt(16)
                currentChange.changeData(model, index + i, data)
            }
        } else if (command.startsWith("importimage(") && paramsEnd > 12) {
            val content = command.substring(12, paramsEnd)
            var run = nextRun(index)
            if (run is ITableRun) {
                val offset = run.convertByteOffsetToArrayOffset(index)
                index = model.readPointer(offset.segmentStart)
                run = nextRun(index)
            } else if (run is PointerRun) {
                index = model.readPointer(run.start)
                run = nextRun(index)
            }
            val args = content.trim().split(' ')
            if (args.size != 2) {
                raiseError("importimage: expected 2 arguments, but got ${args.size}.")
                exitEditEarly = true
            } else {
                val importType = ImportType.entries.firstOrNull { t -> t.name.equals(args[1], ignoreCase = true) }
                if (importType == null) {
                    raiseError("Expected Cautious, Greedy, or Smart, but got ${args[1]}.")
                    exitEditEarly = true
                } else {
                    // editor[0].Edit('@!importimage(relative/path.png Greedy)')
                    val error = _tools!!.spriteTool.tryImport(mapper!!.fileSystem!!, pathContext ?: Path.getDirectoryName(fullFileName) ?: "", run.start, args[0], importType)
                    if (!error.hasError) {
                        // all good
                    } else if (error.isWarning) {
                        raiseMessage(error.errorMessage ?: "")
                    } else {
                        raiseError(error.errorMessage ?: "")
                        exitEditEarly = true
                    }
                }
            }
        } else if (command.startsWith("exportimage(") && paramsEnd > 12) {
            val content = command.substring(12, paramsEnd)
            var run = nextRun(index)
            if (run is ITableRun) {
                val offset = run.convertByteOffsetToArrayOffset(index)
                index = model.readPointer(offset.segmentStart)
                run = nextRun(index)
            } else if (run is PointerRun) {
                index = model.readPointer(run.start)
                run = nextRun(index)
            }
            val error = _tools!!.spriteTool.export(mapper!!.fileSystem!!, pathContext ?: Path.getDirectoryName(fullFileName) ?: "", run.start, content)
            if (!error.hasError) {
                // all good
            } else if (error.isWarning) {
                raiseMessage(error.errorMessage ?: "")
            } else {
                raiseError(error.errorMessage ?: "")
                exitEditEarly = true
            }
        } else {
            raiseError("Could not parse metacommand $command.")
            exitEditEarly = true
        }
    }
    fun abortScript() { /*@DONE ViewPort.AbortScript/1 cs:3200-3200*/
        exitEditEarly = exitEditEarly or updateInProgress
    }
    private fun clearPointersFromTable(tableRun: ITableRun, index: Int, length: Int) { /*@DONE ViewPort.ClearPointersFromTable/1 cs:3202-3211*/
        for (segment in tableRun.elementContent) {
            if (segment.type != ElementContentType.Pointer) continue
            val offset = tableRun.elementContent.takeWhile { seg -> seg !== segment }.sumOf { seg -> seg.length }
            var i = offset
            while (i < length) {
                val destination = model.readPointer(tableRun.start + i)
                model.clearPointer(currentChange, tableRun.start + i, destination)
                i += tableRun.elementLength
            }
        }
    }
    private fun completeAnchorEdit(point: Point): Boolean { /*@DONE ViewPort.CompleteAnchorEdit/1 cs:3214-3256*/
        val underEdit = this[point.x, point.y].format as UnderEdit
        val index = _scroll.viewPointToDataIndex(point)
        var errorInfo: ErrorInfo = ErrorInfo.noError

        // if it's an unnamed text/stream anchor, we have special logic for that
        ModelCacheScope.createScope(model).using {
            if (underEdit.currentText.trim() == anchorStart.toString() + PCSRun.sharedFormatString) {
                val count = model.considerResultsAsTextRuns({ history.currentChange }, listOf(index))
                if (count == 0) {
                    errorInfo = ErrorInfo("An anchor with nothing pointing to it must have a name.")
                } else {
                    errorInfo = ErrorInfo.noError
                }
            } else if (underEdit.currentText == anchorStart.toString() + PLMRun.sharedFormatString) {
                if (!PokemonModel.considerAsPlmStream(model, index, history.currentChange)) {
                    errorInfo = ErrorInfo("An anchor with nothing pointing to it must have a name.")
                } else {
                    errorInfo = ErrorInfo.noError
                    _tools!!.stringTool.refreshContentAtAddress()
                }
            } else if (underEdit.currentText == anchorStart.toString() + XSERun.sharedFormatString) {
                // TODO
                cascadeScript(index)
                errorInfo = ErrorInfo.noError
            } else {
                errorInfo = PokemonModel.applyAnchor(model, history.currentChange, index, underEdit.currentText)
                _tools!!.stringTool.refreshContentAtAddress()
            }
        }

        clearEdits(point)
        updateToolsFromSelection(index)

        if (errorInfo === ErrorInfo.noError) {
            val array = nextRun(index)
            if (array is ArrayRun && array.start == index) goto?.execute(index.toHex(2))
            return true
        }

        handleErrorInfo(errorInfo)

        return errorInfo.isWarning
    }
    private fun completeDirectiveEdit(point: Point, currentText: String): Boolean { /*@DONE ViewPort.CompleteDirectiveEdit/1 cs:3258-3280*/
        var currentText = currentText.lowercase()

        if (!currentText.endsWith(" ")) return false

        if (currentText.startsWith(".align ") && currentText.length > 8) {
            val parsedValue = Ref(0)
            val value = if (tryParseInt(currentText.substring(7), parsedValue)) parsedValue.value else 4
            clearEdits(point)
            val index = _scroll.viewPointToDataIndex(point)
            if (value == 2) selectionStart = _scroll.dataIndexToViewPoint(index + point.x % 2)
            if (value == 4 && point.x % 4 != 0) selectionStart = _scroll.dataIndexToViewPoint(index + 4 - (point.x % 4))
        } else if (currentText.startsWith(".text")) {
            clearEdits(point)
        } else if (currentText.startsWith(".thumb")) {
            clearEdits(point)
        } else if (currentText.startsWith(".python")) {
            clearEdits(point)
        } else {
            raiseError("'${currentText.substring(1).trim()}' is not a valid directive.")
        }

        return false
    }
    private fun scrollFromTableMove(initialSelection: Int, oldRun: ITableRun, newRun: ITableRun) { /*@DONE ViewPort.ScrollFromTableMove/1 cs:3282-3290*/
        _scroll.dataLength = model.count // possible length change
        val tableOffset = _scroll.dataIndex - oldRun.start
        val relativeSelection = initialSelection - oldRun.start
        selection.propertyChanged -= selectionPropertyChangedHandler
        selection.gotoAddress(newRun.start + tableOffset)
        selection.selectionStart = _scroll.dataIndexToViewPoint(newRun.start + relativeSelection)
        selection.propertyChanged += selectionPropertyChangedHandler
    }
    private fun silentScroll(memoryLocation: Int): Boolean { /*@DONE ViewPort.SilentScroll/1 cs:3292-3303*/
        val nextPoint = Ref(_scroll.dataIndexToViewPoint(memoryLocation))
        var didScroll = true
        if (!_scroll.scrollToPoint(nextPoint)) {
            // only need to notify collection change if we didn't auto-scroll after changing cells
            notifyCollectionChanged(resetArgs)
            didScroll = false
        }

        updateSelectionWithoutNotify(nextPoint.value)
        return didScroll
    }
    fun handleErrorInfo(info: ErrorInfo) { /*@DONE ViewPort.HandleErrorInfo/1 cs:3305-3309*/
        if (!info.hasError) return
        if (info.isWarning) raiseMessage(info.errorMessage ?: "")
        else raiseError(info.errorMessage ?: "")
    }
    private fun updateSelectionWithoutNotify(nextPoint: Point) { /*@DONE ViewPort.UpdateSelectionWithoutNotify/1 cs:3317-3325*/
        selection.propertyChanged -= selectionPropertyChangedHandler

        selectionStart = nextPoint
        notifyPropertyChanged("selectionStart")
        notifyPropertyChanged("selectionEnd")

        selection.propertyChanged += selectionPropertyChangedHandler
    }
    private fun modelChangedByTool(sender: Any?, run: IFormattedRun) { /*@DONE ViewPort.ModelChangedByTool/1 cs:3327-3336*/
        if (run.start < _scroll.viewPointToDataIndex(Point(width - 1, height - 1)) || run.start + run.length > _scroll.dataIndex) {
            // there's some visible data that changed
            refreshBackingData()
            _scroll.updateHeaders()
        }

        val tray = _tools!!
        if (run is ITableRun && sender !== tray.stringTool && nextRun(tray.stringTool.address).start == run.start) tray.stringTool.dataForCurrentRunChanged()
        if (run is ITableRun && nextRun(tray.tableTool.address).start == run.start) tray.tableTool.dataForCurrentRunChanged()
    }
    private fun modelDataMovedByTool(sender: Any?, originalLocation: Int, newLocation: Int) { /*@DONE ViewPort.ModelDataMovedByTool/1 cs:3338-3348*/
        _scroll.dataLength = model.count
        val start = convertViewPointToAddress(selectionStart)
        val end = convertViewPointToAddress(selectionEnd)
        if (start - 1 <= originalLocation && originalLocation < end + 1) {
            // data was moved from in-selection: follow it
            val offset = originalLocation - _scroll.dataIndex
            selection.gotoAddress(newLocation - offset)
        }
        raiseMessage("Data was automatically moved to ${newLocation.toHex(6)}. Pointers were updated.")
    }
    private fun modelChangedByCodeTool(sender: Any?, e: ErrorInfo) { /*@DONE ViewPort.ModelChangedByCodeTool/1 cs:3350-3353*/
        refreshBackingData()
        handleErrorInfo(e)
    }
    private fun refreshBackingData(p: Point) { /*@DONE ViewPort.RefreshBackingData/1 cs:3355-3366*/
        synchronized(threadlock) {
            val index = _scroll.viewPointToDataIndex(p)
            val edited = model.hasChanged(index)
            if (index < 0 || index >= model.count) { currentView[p.x][p.y] = HexElement.undefined; return }
            val run = nextRun(index)
            if (index < run.start) { currentView[p.x][p.y] = HexElement(model[index], edited, None.instance); return }
            var format = run.createDataFormat(model, index)
            format = model.wrapFormat(run, format, index)
            currentView[p.x][p.y] = HexElement(model[index], edited, format)
        }
    }
    private fun refreshBackingData() { /*@DONE ViewPort.RefreshBackingData/2 cs:3368-3376*/
        synchronized(threadlock) {
            currentView = Array(width) { arrayOfNulls<HexElement>(height) }

            requestMenuClose(this, EventArgs.empty)
            notifyCollectionChanged(resetArgs)
            notifyPropertyChanged("freeSpaceStart")
        }
    }
    private fun refreshBackingDataFull() { /*@DONE ViewPort.RefreshBackingDataFull/1 cs:3378-3430*/
        synchronized(threadlock) {
            currentView = Array(width) { arrayOfNulls<HexElement>(height) }
            ModelCacheScope.createScope(model).using {
                var run: IFormattedRun? = null
                for (y in 0 until height) {
                    for (x in 0 until width) {
                        val index = _scroll.viewPointToDataIndex(Point(x, y))
                        val edited = model.hasChanged(index)
                        val cached = run
                        val activeRun: IFormattedRun
                        if (cached == null || index >= cached.start + cached.length) {
                            activeRun = model.getNextRun(index) ?: NoInfoRun(model.count)
                            run = activeRun
                        } else {
                            activeRun = cached
                        }
                        if (index < _scroll.dataStart || index >= _scroll.dataLength) {
                            currentView[x][y] = HexElement.undefined
                        } else if (index >= activeRun.start) {
                            var format = if (activeRun is BaseRun) activeRun.createDataFormat(model, index, x == 0, width) else activeRun.createDataFormat(model, index)
                            format = model.wrapFormat(activeRun, format, index)
                            currentView[x][y] = HexElement(model[index], edited, format)
                        } else if (index >= 0 && index < model.count) {
                            currentView[x][y] = HexElement(model[index], edited, None.instance)
                        } else {
                            currentView[x][y] = HexElement(0, false, Undefined.instance)
                        }
                    }
                }
            }
            val fb = _findBytes
            if (fb != null) {
                val fullLength = width * height
                var i = 0
                while (i < fullLength) {
                    var possibleMatch = fb.size > 0
                    for (j in 0 until fb.size) {
                        if (!(dataOffset + i + j).inRange(0, model.count) || model[dataOffset + i + j] != (fb[j].toInt() and 0xFF)) {
                            possibleMatch = false
                            break
                        }
                    }
                    if (!possibleMatch) {
                        i++
                        continue
                    }
                    for (j in 0 until fb.size) {
                        val x = (i + j) % width
                        val y = (i + j) / width
                        if (y < height) {
                            val cell = currentView[x][y]!!
                            val cellFormat = cell.format
                            if (cellFormat is None) {
                                currentView[x][y] = HexElement(cell.value, cell.edited, None.resultInstance)
                            } else if (cellFormat is Anchor && cellFormat.originalFormat is None) {
                                val newWrapper = Anchor(None.resultInstance, cellFormat.name, cellFormat.format, cellFormat.sources)
                                currentView[x][y] = HexElement(cell.value, cell.edited, newWrapper)
                            }
                        }
                    }
                    i += fb.size - 1
                    i++
                }
            }
        }
    }
    private fun updateColumnHeaders() { /*@DONE ViewPort.UpdateColumnHeaders/1 cs:3432-3446*/
        val index = _scroll.viewPointToDataIndex(Point(0, 0))
        var run = nextRun(index) as? ArrayRun
        if (run != null && run.start > index) run = null // only use the run if it starts _before_ the screen
        val headers = run?.getColumnHeaders(width, index) ?: ColumnHeaderRow.getDefaultColumnHeaders(width, index)

        for (i in 0 until headers.size) {
            if (i < columnHeaders.size) columnHeaders[i] = headers[i]
            else columnHeaders.add(headers[i])
        }

        while (columnHeaders.size > headers.size) columnHeaders.removeAt(columnHeaders.size - 1)

        updateColumnHeaderSelection()
    }
    private fun updateColumnHeaderSelection() { /*@DONE ViewPort.UpdateColumnHeaderSelection/1 cs:3448-3464*/
        if (columnHeaders.size == 1 && selectionStart.y == selectionEnd.y) {
            var left = selectionStart.x
            var right = selectionEnd.x
            if (left > right) {
                val swap = left
                left = right
                right = swap
            }
            var offset = 0
            for (i in 0 until columnHeaders[0].columnHeaders.size) {
                columnHeaders[0].columnHeaders[i].isSelected = left <= offset && offset <= right
                offset += columnHeaders[0].columnHeaders[i].byteWidth
            }
        } else {
            for (i in 0 until columnHeaders.size) {
                for (j in 0 until columnHeaders[i].columnHeaders.size) {
                    columnHeaders[i].columnHeaders[j].isSelected = false
                }
            }
        }
    }
    private fun openLink(link: String) { /*@DONE ViewPort.OpenLink/1 cs:3466-3466*/
        NativeProcess.start(link)
    }
    private fun notifyCollectionChanged(args: NotifyCollectionChangedEventArgs) { /*@DONE ViewPort.NotifyCollectionChanged/1 cs:3468-3468*/
        collectionChanged(this, args)
    }
    companion object {
        const val allHexCharacters: String = "0123456789ABCDEFabcdef"
        const val gotoMarker: Char = '@'
        const val directiveMarker: Char = '.'
        const val commandMarker: Char = '!'
        const val commentStart: Char = '#'
        private val resetArgs: NotifyCollectionChangedEventArgs = /*@INITDONE ViewPort.ResetArgs cs:39-39*/ NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset) /*@ENDINIT*/
        fun buildElementName(model: IDataModel, address: Int): String { /*@DONE ViewPort.BuildElementName/1 cs:522-551*/
            val run = model.getNextRun(address) ?: NoInfoRun.nullRun
            if (run is ITableRun && run.start <= address) {
                val index = run.convertByteOffsetToArrayOffset(address).elementIndex
                val basename = model.getAnchorFromAddress(-1, run.start)
                val runNames = run.elementNames
                if (runNames != null && runNames.size > index) {
                    return "$basename/${runNames[index]}"
                } else {
                    return "$basename/$index"
                }
            } else {
                val sources = run.pointerSources
                if (sources != null && sources.size > 0 && model.getAnchorFromAddress(-1, run.start).isEmpty()) {
                    val sourceRun = model.getNextRun(sources[0])
                    if (sourceRun is ITableRun) {
                        // we are an anchor that's pointed to from an array
                        val offset = sourceRun.convertByteOffsetToArrayOffset(sources[0])
                        val index = offset.elementIndex
                        if (index >= 0) {
                            val segment = sourceRun.elementContent[offset.segmentIndex]
                            val basename = model.getAnchorFromAddress(-1, sourceRun.start)
                            val sourceNames = sourceRun.elementNames
                            if (sourceNames != null && sourceNames.size > index) {
                                return "$basename/${sourceNames[index]}/${segment.name}"
                            } else {
                                return "$basename/$index/${segment.name}"
                            }
                        }
                    }
                }
            }

            return ""
        }
        private fun runs(model: IDataModel): Iterable<IFormattedRun> { /*@DONE ViewPort.Runs/1 cs:1286-1290*/
            val result = ArrayList<IFormattedRun>()
            var run = model.getNextRun(0) ?: NoInfoRun.nullRun
            while (run.start < model.count) {
                result.add(run)
                run = model.getNextRun(run.start + maxOf(1, run.length)) ?: NoInfoRun.nullRun
            }
            return result
        }
        private const val defaultChunkSize: Int = 200
        /*@END ViewPort.Companion*/
    }
    /*@ADD ViewPort#view_3.txt*/
    private val scrollPropertyChangedHandler: (Any?, PropertyChangedEventArgs) -> Unit = { s, e -> scrollPropertyChanged(s, e) }
    private val selectionPropertyChangedHandler: (Any?, PropertyChangedEventArgs) -> Unit = { s, e -> selectionPropertyChanged(s, e) }
    private val historyPropertyChangedHandler: (Any?, PropertyChangedEventArgs) -> Unit = { s, e -> historyPropertyChanged(s, e) }
    private fun nextRun(index: Int): IFormattedRun = model.getNextRun(index) ?: NoInfoRun.nullRun
    /*@ENDADD ViewPort#view_3.txt*/
    /*@ADD ViewPort#view_5.txt*/
    private val clearActiveEditHandler: (Any?, Point) -> Unit = { s, p -> clearActiveEditBeforeSelectionChanges(s, p) }
    /*@ENDADD ViewPort#view_5.txt*/
    /*@END ViewPort*/
}

data class ViewPortOpenSearchResultsTabShowSelectionTuple(val start: Int, val end: Int)

data class ViewPortOpenSearchResultsTabGotoSelectionTuple(val start: Int, val end: Int)
