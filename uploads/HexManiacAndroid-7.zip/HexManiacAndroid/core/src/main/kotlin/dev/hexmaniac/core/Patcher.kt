// Port of Models/Code/Patcher.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.models.*

object Patcher { // cs:7-255
    fun buildIpsPatch(source: ByteArray, destination: ByteArray): ByteArray { /*@DONE Patcher.BuildIpsPatch/1 cs:10-33*/
        val patch = ArrayList<Int>()
        var source = source
        if (source.size < destination.size) {
            source = source + ByteArray(destination.size - source.size)
        }

        // header
        for (c in "PATCH") patch.add(c.code)

        // body
        var i = -1
        while (true) {
            i++
            if (i >= destination.size) break
            if (source[i] == destination[i]) continue
            var j = i + 1
            while (j < destination.size && source[j] != destination[j] && j - i < 0xFFFF) j++
            for (b in buildChunk(destination, i, j - i)) patch.add(b.toInt() and 0xFF)
            if (j < destination.size && source[j] != destination[j]) j -= 1 // need to re-check this byte, we exited due to the length limit
            i = j
        }

        // footer
        for (c in "EOF") patch.add(c.code)

        return patch.toByteArrayU()
    }
    fun buildChunk(data: ByteArray, start: Int, length: Int): ByteArray { /*@DONE Patcher.BuildChunk/1 cs:35-55*/
        val chunk = ArrayList<Int>()
        val compressed = length > 4 && (0 until length).all { i -> data[start + i] == data[start] }

        // offset
        chunk.add((start shr 16) and 0xFF)
        chunk.add((start shr 8) and 0xFF)
        chunk.add(start and 0xFF)

        // compressed content
        if (compressed) {
            chunk.addAll(listOf(0, 0, (length shr 8) and 0xFF, length and 0xFF, data[start].toInt() and 0xFF))
            return chunk.toByteArrayU()
        }

        // normal content
        chunk.addAll(listOf((length shr 8) and 0xFF, length and 0xFF))
        for (i in 0 until length) chunk.add(data[start + i].toInt() and 0xFF)

        return chunk.toByteArrayU()
    }
    fun applyIPSPatch(model: IDataModel, patch: ByteArray, token: ModelDelta): Int { /*@DONE Patcher.ApplyIPSPatch/1 cs:58-96*/
        // 5 byte header (PATCH) and 3 byte footer (EOF)
        // hunk type 1: offset (3 bytes), length (2 bytes), payload (length bytes). Write the payload at offset.
        // RLE hunk:    offset (3 bytes), 00 00, length (2 bytes), target (1 byte). Write the target, length times, at offset

        var start = 5
        var firstOffset = -1

        while (patch.size - start >= 6) {
            var offset = (patch.getU(start) shl 16) + (patch.getU(start + 1) shl 8) + patch.getU(start + 2)
            if (firstOffset < 0) firstOffset = offset
            start += 3
            var length = (patch.getU(start) shl 8) + patch.getU(start + 1)
            start += 2
            if (length > 0) {
                // normal
                model.expandData(token, offset + length - 1)
                while (length > 0) {
                    token.changeData(model, offset, patch.getU(start))
                    offset += 1
                    start += 1
                    length -= 1
                }
            } else {
                length = (patch.getU(start) shl 8) + patch.getU(start + 1)
                start += 2
                model.expandData(token, offset + length - 1)
                // rle
                while (length > 0) {
                    token.changeData(model, offset, patch.getU(start))
                    offset += 1
                    length -= 1
                }
                start += 1
            }
        }

        return firstOffset
    }
    enum class UpsPatchDirection(val value: Int) { // cs:102-102
        Fail(0),
        SourceToDestination(1),
        DestinationToSource(2);
        companion object {
            fun fromValue(value: Int): UpsPatchDirection = entries.first { it.value == value }
        }
        /*@END Patcher.UpsPatchDirection*/
    }
    fun buildUpsPatch(source: ByteArray, destination: ByteArray): ByteArray { /*@DONE Patcher.BuildUpsPatch/1 cs:104-139*/
        val patch = ArrayList<Int>()

        // header
        for (c in "UPS1") patch.add(c.code)
        patch.addAll(writeVariableWidthInteger(source.size))
        patch.addAll(writeVariableWidthInteger(destination.size))

        // body
        var offset = 0
        var writing = false
        for (i in 0 until destination.size) {
            val sourceVal = if (source.size > i) (source[i].toInt() and 0xFF) else 0
            val destinationVal = destination[i].toInt() and 0xFF
            if (sourceVal == destinationVal) {
                if (writing) {
                    writing = false
                    offset = i + 1
                    patch.add(0)
                }
                continue
            }
            if (!writing) {
                patch.addAll(writeVariableWidthInteger(i - offset))
                writing = true
            }
            patch.add(sourceVal xor destinationVal)
        }
        if (writing) patch.add(0)

        // footer
        for (crc in listOf(calcCRC32(source), calcCRC32(destination))) {
            for (k in 0 until 4) patch.add((crc shr (8 * k)) and 0xFF)
        }
        val patchCrc = calcCRC32(patch.toByteArrayU())
        for (k in 0 until 4) patch.add((patchCrc shr (8 * k)) and 0xFF)

        return patch.toByteArrayU()
    }
    fun applyUPSPatch(model: IDataModel, patch: ByteArray, tokenFactory: () -> ModelDelta, ignoreChecksums: Boolean, direction: Ref<UpsPatchDirection>): Int { /*@DONE Patcher.ApplyUPSPatch/1 cs:149-205*/
        // 4 byte header: "UPS1"
        // variable width source-size
        // variable width destination-size
        // 12 byte footer: 3 CRC32 checksums. Source file, destination file, patch file (CRC of everything except the last 4 bytes)
        direction.value = UpsPatchDirection.Fail

        // check header
        val headerMatches = patch.size >= 4 && String(CharArray(4) { k -> (patch[k].toInt() and 0xFF).toChar() }) == "UPS1"
        if (!headerMatches) return -1

        // check source CRC
        val currentCRC = calcCRC32(model.rawData)
        val patchSourceFileCRC = patch.asByteList().readMultiByteValue(patch.size - 12, 4)
        val patchDestinationFileCRC = patch.asByteList().readMultiByteValue(patch.size - 8, 4)
        if (currentCRC == patchSourceFileCRC) direction.value = UpsPatchDirection.SourceToDestination
        if (currentCRC == patchDestinationFileCRC) direction.value = UpsPatchDirection.DestinationToSource
        if (direction.value == UpsPatchDirection.Fail && !ignoreChecksums) return -2
        if (direction.value == UpsPatchDirection.Fail) direction.value = UpsPatchDirection.SourceToDestination

        // check patch CRC
        val patchWithoutCRC = ByteArray(patch.size - 4)
        System.arraycopy(patch, 0, patchWithoutCRC, 0, patchWithoutCRC.size)
        val patchCRC = calcCRC32(patchWithoutCRC)
        if (patchCRC != patch.asByteList().readMultiByteValue(patch.size - 4, 4)) return -3

        // resize (bigger)
        val readIndex = Ref(4)
        var firstEdit = Int.MAX_VALUE
        var sourceSize = readVariableWidthInteger(patch, readIndex)
        var destinationSize = readVariableWidthInteger(patch, readIndex)
        val writeLength = destinationSize
        if (direction.value == UpsPatchDirection.DestinationToSource) {
            val swap = sourceSize
            sourceSize = destinationSize
            destinationSize = swap
        }
        if (sourceSize != model.count && !ignoreChecksums) return -4
        val token = tokenFactory()
        model.expandData(token, destinationSize - 1)
        token.changeData(model, sourceSize, ByteArray(Math.max(0, destinationSize - sourceSize)).asByteList())
        token.changeData(model, destinationSize, ByteArray(Math.max(0, sourceSize - destinationSize)).asByteList())

        // run algorithm
        firstEdit = runUPSPatchAlgorithm(model, patch, token, writeLength, destinationSize, readIndex)
        if (firstEdit < 0) return firstEdit

        // resize (smaller)
        model.contractData(token, destinationSize - 1)

        // check result CRC
        if (!ignoreChecksums) {
            val finalCRC = calcCRC32(model.rawData)
            if (direction.value == UpsPatchDirection.SourceToDestination && finalCRC != patchDestinationFileCRC) return -5
            if (direction.value == UpsPatchDirection.DestinationToSource && finalCRC != patchSourceFileCRC) return -5
        }

        // check that the chunk ended cleanly
        if (direction.value == UpsPatchDirection.SourceToDestination && readIndex.value != patch.size - 12) return -6

        return firstEdit
    }
    fun calcCRC32(array: ByteArray): Int { /*@DONE Patcher.CalcCRC32/1 cs:207-207*/
        val crc = java.util.zip.CRC32()
        crc.update(array, 0, array.size)
        return crc.value.toInt()
    }
    fun readVariableWidthInteger(data: ByteArray, index: Ref<Int>): Int { /*@DONE Patcher.ReadVariableWidthInteger/1 cs:209-220*/
        var result = 0
        var shift = 0
        while (true) {
            result += (data.getU(index.value) and 0x7F) shl shift
            if (shift != 0) result += 1 shl shift
            shift += 7
            index.value += 1
            if ((data.getU(index.value - 1) and 0x80) != 0) {
                return result
            }
        }
    }
    fun writeVariableWidthInteger(value: Int): Iterable<Int> { /*@DONE Patcher.WriteVariableWidthInteger/1 cs:222-230*/
        val bytes = ArrayList<Int>()
        var current = value
        do {
            var payload = current and 0x7F
            current = current shr 7
            if (current == 0) payload = payload or 0x80
            current -= 1
            bytes.add(payload)
        } while (current >= 0)
        return bytes
    }
    private fun runUPSPatchAlgorithm(model: IDataModel, patch: ByteArray, token: ModelDelta, writeLength: Int, destinationSize: Int, readIndex: Ref<Int>): Int { /*@DONE Patcher.RunUPSPatchAlgorithm/1 cs:232-252*/
        var writeIndex = 0
        var firstEdit = Int.MAX_VALUE
        while (readIndex.value < patch.size - 12 && writeIndex < destinationSize) {
            val skipSize = readVariableWidthInteger(patch, readIndex)
            writeIndex += skipSize
            if (writeIndex > writeLength) return -7
            if (firstEdit == Int.MAX_VALUE) firstEdit = skipSize

            while (patch.getU(readIndex.value) != 0 && writeIndex < destinationSize) {
                token.changeData(model, writeIndex, patch.getU(readIndex.value) xor model[writeIndex])
                readIndex.value += 1
                writeIndex += 1
                if (writeIndex > writeLength) return -7
            }
            readIndex.value += 1
            writeIndex += 1
        }

        return firstEdit
    }
    /*@END Patcher*/
}
