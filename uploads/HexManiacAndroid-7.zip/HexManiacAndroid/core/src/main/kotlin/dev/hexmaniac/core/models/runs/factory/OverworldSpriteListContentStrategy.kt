// Port of Models/Runs/Factory/OverworldSpriteListContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class OverworldSpriteListContentStrategy : RunStrategy { // cs:5-85
    private var parentTemplate: List<ArrayRunElementSegment> = ArrayList()
    private var parentTemplate2: List<ArrayRunElementSegment> = ArrayList()
    var hint: String = ""
        private set
    constructor(factory: IFormatRunFactory, format: String) { /*@DONE OverworldSpriteListContentStrategy.<init>/1 cs:11-40*/
        parentTemplate = listOf<ArrayRunElementSegment>(
            ArrayRunElementSegment("", ElementContentType.Integer, 2),
            ArrayRunElementSegment("paletteid", ElementContentType.Integer, 2),
            ArrayRunElementSegment("", ElementContentType.Integer, 2),
            ArrayRunElementSegment("length", ElementContentType.Integer, 2),
            ArrayRunElementSegment("width", ElementContentType.Integer, 2),
            ArrayRunElementSegment("height", ElementContentType.Integer, 2),
            ArrayRunElementSegment("", ElementContentType.Integer, 4),
            ArrayRunElementSegment("", ElementContentType.Pointer, 4),
            ArrayRunElementSegment("", ElementContentType.Pointer, 4),
            ArrayRunElementSegment("", ElementContentType.Pointer, 4),
            ArrayRunPointerSegment(factory, "sprites", OverworldSpriteListRun.sharedFormatString),
            ArrayRunElementSegment("", ElementContentType.Pointer, 4)
        )

        parentTemplate2 = listOf<ArrayRunElementSegment>(
            ArrayRunElementSegment("", ElementContentType.Integer, 2),
            ArrayRunElementSegment("paletteid", ElementContentType.Integer, 2),
            ArrayRunElementSegment("", ElementContentType.Pointer, 4),
            ArrayRunElementSegment("", ElementContentType.Pointer, 4),
            ArrayRunPointerSegment(factory, "sprites", OverworldSpriteListRun.sharedFormatString),
            ArrayRunElementSegment("", ElementContentType.Pointer, 4),
            ArrayRunElementSegment("", ElementContentType.Pointer, 4)
        )

        if (format.contains("|")) {
            hint = format.split("|")[1].split("`")[0]
        }
    }
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE OverworldSpriteListContentStrategy.LengthForNewRun/1 cs:42-47*/
        val destination = model.readPointer(pointerAddress)
        if (destination == Pointer.null_) return 8
        if (destination < 0 || destination >= model.count) return -1
        return OverworldSpriteListRun(model, parentTemplate, hint, 0, destination, SortedSpan(pointerAddress)).length
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE OverworldSpriteListContentStrategy.Matches/1 cs:49-49*/
        return run is OverworldSpriteListRun
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE OverworldSpriteListContentStrategy.TryAddFormatAtDestination/1 cs:51-55*/
        if (sourceSegments == null) return false
        val attempt = OverworldSpriteListRun(owner, sourceSegments, hint, 0, destination, SortedSpan(source))
        return attempt.length > 0
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE OverworldSpriteListContentStrategy.TryParseData/1 cs:57-69*/
        val currentSources = run.value?.pointerSources
        var newRun = OverworldSpriteListRun(model, parentTemplate, hint, 0, dataIndex, currentSources)
        if (newRun.length > 0) {
            run.value = newRun
            return ErrorInfo.noError
        }
        newRun = OverworldSpriteListRun(model, parentTemplate2, hint, 0, dataIndex, currentSources)
        if (newRun.length > 0) {
            run.value = newRun
            return ErrorInfo.noError
        }
        return ErrorInfo("Could not find overworld sprite at " + dataIndex)
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE OverworldSpriteListContentStrategy.UpdateNewRunFromPointerFormat/1 cs:71-77*/
        if (sourceSegments == null) {
            run.value = NoInfoRun(run.value.start, run.value.pointerSources)
            return
        }
        val newRun = OverworldSpriteListRun(model, sourceSegments, hint, parentIndex, run.value.start, run.value.pointerSources)
        run.value = newRun

        // backup: we may get asked to make a pointer format even when it's not an overworld sprite list.
        // if that happens, fall back to a NoInfoRun.
        if (newRun.length == 0) run.value = NoInfoRun(newRun.start, newRun.pointerSources)
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE OverworldSpriteListContentStrategy.WriteNewRun/1 cs:79-84*/
        val run = OverworldSpriteListRun(owner, sourceSegments, hint, 0, destination, SortedSpan(source))
        owner.writePointer(token, destination, Pointer.null_)
        owner.writeMultiByteValue(destination + 4, 4, token, 0x100)
        return run
    }
    /*@END OverworldSpriteListContentStrategy*/
}
