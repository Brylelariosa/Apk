// Port of Models/Runs/Sprites/SpriteRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class SpriteRun : BaseRun, ISpriteRun { // cs:9-243
    private var bitsPerPixel: Int = 0
    private var tileWidth: Int = 0
    private var tileHeight: Int = 0
    var model: IDataModel? = null
        private set
    final override var spriteFormat: SpriteFormat = SpriteFormat()
        private set
    override val pages: Int
        get() { /*@DONE SpriteRun.Pages.get cs:14-14*/
            return 1
        }
    final override var length: Int = 0
        private set
    final override var formatString: String = ""
        private set
    override val supportsImport: Boolean
        get() { /*@DONE SpriteRun.SupportsImport.get cs:19-19*/
            return true
        }
    override val supportsEdit: Boolean
        get() { /*@DONE SpriteRun.SupportsEdit.get cs:20-20*/
            return true
        }
    override val decompressedLength: Int
        get() { /*@DONE SpriteRun.DecompressedLength.get cs:22-22*/
            return length // no compression
        }
    constructor(model: IDataModel, start: Int, format: SpriteFormat, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE SpriteRun.<init>/1 cs:24-34*/
        this.model = model
        spriteFormat = format
        bitsPerPixel = format.bitsPerPixel
        tileWidth = format.tileWidth
        tileHeight = format.tileHeight
        length = tileWidth * tileHeight * bitsPerPixel * 8
        var text = "`ucs" + bitsPerPixel + "x" + tileWidth + "x" + tileHeight
        if (!format.paletteHint.isNullOrEmpty()) text += "|" + format.paletteHint
        text += "`"
        formatString = text
    }
    private var lastFormatRequested: Int = /*@INITDONE SpriteRun.lastFormatRequested cs:43-43*/ Int.MAX_VALUE /*@ENDINIT*/
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE SpriteRun.CreateDataFormat/1 cs:44-56*/
        val basicFormat = LzUncompressed(index)
        if (!createForLeftEdge || data.spartanMode) return basicFormat
        if (lastFormatRequested < index) {
            lastFormatRequested = index
            return basicFormat
        }

        val sprite = data.currentCacheScope.getImage(this)
        val availableRows = (length - (index - start)) / expectedDisplayWidth
        lastFormatRequested = index
        return SpriteDecorator(basicFormat, sprite, expectedDisplayWidth, availableRows)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE SpriteRun.Clone/1 cs:58-58*/
        return SpriteRun(model!!, start, spriteFormat, newPointerSources)
    }
    // skipped method Duplicate: explicit implementation merged with the public member
    override fun duplicate(format: SpriteFormat): SpriteRun { /*@DONE SpriteRun.Duplicate/2 cs:61-61*/
        return SpriteRun(model!!, start, format, pointerSources)
    }
    override fun getData(): ByteArray { /*@DONE SpriteRun.GetData/1 cs:63-67*/
        val data = ByteArray(spriteFormat.expectedByteLength)
        System.arraycopy(model!!.rawData, start, data, 0, data.size)
        return data
    }
    override fun getPixels(model: IDataModel, page: Int, tableIndex: Int): Array<IntArray>? { /*@DONE SpriteRun.GetPixels/1 cs:69-72*/
        val pageSize = 8 * bitsPerPixel * tileWidth * tileHeight
        return getPixels(model, start + page * pageSize, tileWidth, tileHeight, bitsPerPixel)
    }
    fun increaseHeight(units: Int, token: ModelDelta): SpriteRun { /*@DONE SpriteRun.IncreaseHeight/1 cs:199-210*/
        if (units < 1) return this
        val data = getData()
        val format = spriteFormat
        val newData = ByteArray(data.size + units * format.bitsPerPixel * 8 * format.tileWidth)
        System.arraycopy(data, 0, newData, 0, data.size)
        var newRun = model!!.relocateForExpansion(token, this, newData.size)
        token.changeData(model!!, newRun.start, newData.asByteList())
        newRun = newRun.duplicate(SpriteFormat(format.bitsPerPixel, format.tileWidth, format.tileHeight + units, format.paletteHint, format.allowLengthErrors))
        model!!.observeRunWritten(token, newRun)
        return newRun
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>): ISpriteRun { /*@DONE SpriteRun.SetPixels/2 cs:212-217*/
        val data = ByteArray(pixels.size * pixels[0].size * spriteFormat.bitsPerPixel / 8)
        setPixels(data, 0, pixels, spriteFormat.bitsPerPixel)
        for (i in 0 until data.size) token.changeData(model, start + i, data[i].toInt() and 0xFF)
        return this
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, tiles: List<Array<IntArray>>): ISpriteRun { /*@DONE SpriteRun.SetPixels/3 cs:219-221*/
        return LzTilesetRun.setPixels(this, model, token, tiles) { newStart, sources -> SpriteRun(model, newStart, spriteFormat, sources) }
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE SpriteRun.AppendTo/1 cs:223-236*/
        var currentStart = start
        var remaining = length
        while (remaining > 0) {
            if (currentStart == this.start + this.length - 1) {
                builder.append(model[currentStart].toHexString())
            } else if (this.start <= currentStart && currentStart < this.start + this.length) {
                builder.append(model[currentStart].toHexString() + " ")
            } else {
                break
            }
            // Moving to the next byte
            currentStart += 1
            remaining -= 1
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE SpriteRun.Clear/1 cs:238-242*/
        for (i in 0 until length) {
            changeToken.changeData(model, start + i, 0x00)
        }
    }
    companion object {
        fun tryParseSpriteFormat(pointerFormat: String, spriteFormat: Ref<SpriteFormat>): Boolean { /*@DONE SpriteRun.TryParseSpriteFormat/1 cs:36-40*/
            spriteFormat.value = SpriteFormat()
            if (!pointerFormat.startsWith("`ucs") || !pointerFormat.endsWith("`")) return false
            return LzSpriteRun.tryParseDimensions(pointerFormat, spriteFormat)
        }
        fun getPixels(data: ByteList, start: Int, tileWidth: Int, tileHeight: Int, bitsPerPixel: Int): Array<IntArray> { /*@DONE SpriteRun.GetPixels/2 cs:77-129*/
            val result = Array(8 * tileWidth) { IntArray(8 * tileHeight) }
            for (y in 0 until tileHeight) {
                val yOffset = y * 8
                for (x in 0 until tileWidth) {
                    val tileStart = ((y * tileWidth) + x) * 8 * bitsPerPixel + start
                    val xOffset = x * 8
                    if (bitsPerPixel == 4) {
                        for (i in 0 until 32) {
                            val xx = i % 4 // ranges from 0 to 3
                            val yy = i / 4 // ranges from 0 to 7
                            val raw = if (tileStart + i < data.count) data[tileStart + i] else 0
                            result[xOffset + xx * 2 + 0][yOffset + yy] = (raw and 0xF)
                            result[xOffset + xx * 2 + 1][yOffset + yy] = raw shr 4
                        }
                    } else if (bitsPerPixel == 8) {
                        for (i in 0 until 64) {
                            val xx = i % 8
                            val yy = i / 8
                            val raw = if (tileStart + i < data.count) data[tileStart + i] else 0
                            result[xOffset + xx][yOffset + yy] = raw
                        }
                    } else if (bitsPerPixel == 2) {
                        for (i in 0 until 16) {
                            var xx = i % 2 // ranges from 0 to 1
                            val yy = i / 2 // ranges from 0 to 7
                            xx = 1 - xx // swap the left half with the right half
                            val raw = if (tileStart + i < data.count) data[tileStart + i] else 0
                            result[xOffset + xx * 4 + 0][yOffset + yy] = ((raw shr 6) and 3)
                            result[xOffset + xx * 4 + 1][yOffset + yy] = ((raw shr 4) and 3)
                            result[xOffset + xx * 4 + 2][yOffset + yy] = ((raw shr 2) and 3)
                            result[xOffset + xx * 4 + 3][yOffset + yy] = ((raw shr 0) and 3)
                        }
                    } else if (bitsPerPixel == 1) {
                        for (i in 0 until 8) {
                            val raw = if (tileStart + i < data.count) data[tileStart + i] else 0
                            result[xOffset + 0][yOffset + i] = ((raw shr 0) and 1)
                            result[xOffset + 1][yOffset + i] = ((raw shr 1) and 1)
                            result[xOffset + 2][yOffset + i] = ((raw shr 2) and 1)
                            result[xOffset + 3][yOffset + i] = ((raw shr 3) and 1)
                            result[xOffset + 4][yOffset + i] = ((raw shr 4) and 1)
                            result[xOffset + 5][yOffset + i] = ((raw shr 5) and 1)
                            result[xOffset + 6][yOffset + i] = ((raw shr 6) and 1)
                            result[xOffset + 7][yOffset + i] = ((raw shr 7) and 1)
                        }
                    } else {
                        // unsure what to do here...
                    }
                }
            }
            return result
        }
        fun setPixels(data: ByteArray, start: Int, pixels: Array<IntArray>, bitsPerPixel: Int) { /*@DONE SpriteRun.SetPixels/1 cs:131-197*/
            val width = pixels.getLength(0)
            val height = pixels.getLength(1)
            val tileWidth = width / 8
            val tileHeight = height / 8
            var position = start
            if (bitsPerPixel == 4) {
                for (y in 0 until tileHeight) {
                    val yOffset = y * 8
                    for (x in 0 until tileWidth) {
                        val xOffset = x * 8
                        for (i in 0 until 32) {
                            if (position >= data.size) break // don't write the blank 'bonus' tiles for tilesets
                            val xx = i % 4
                            val yy = i / 4
                            val low = pixels[xOffset + xx * 2 + 0][yOffset + yy] and 0xF
                            val high = pixels[xOffset + xx * 2 + 1][yOffset + yy] and 0xF
                            data[position] = ((high shl 4) or low).toByte()
                            position += 1
                        }
                    }
                }
            } else if (bitsPerPixel == 8) {
                for (y in 0 until tileHeight) {
                    val yOffset = y * 8
                    for (x in 0 until tileWidth) {
                        val xOffset = x * 8
                        for (i in 0 until 64) {
                            if (position >= data.size) break // don't write the blank 'bonus' tiles for tilesets
                            val xx = i % 8
                            val yy = i / 8
                            data[position] = pixels[xOffset + xx][yOffset + yy].toByte()
                            position += 1
                        }
                    }
                }
            } else if (bitsPerPixel == 2) {
                for (y in 0 until tileHeight) {
                    val yOffset = y * 8
                    for (x in 0 until tileWidth) {
                        val xOffset = x * 8
                        for (i in 0 until 16) {
                            if (position >= data.size) break // don't write the blank 'bonus' tiles for tilesets
                            var xx = i % 2
                            val yy = i / 2
                            xx = 1 - xx
                            val a = pixels[xOffset + xx * 4 + 0][yOffset + yy]
                            val b = pixels[xOffset + xx * 4 + 1][yOffset + yy]
                            val c = pixels[xOffset + xx * 4 + 2][yOffset + yy]
                            val d = pixels[xOffset + xx * 4 + 3][yOffset + yy]
                            data[position] = ((a shl 6) or (b shl 4) or (c shl 2) or d).toByte()
                            position += 1
                        }
                    }
                }
            } else if (bitsPerPixel == 1) {
                for (y in 0 until tileHeight) {
                    val yOffset = y * 8
                    for (x in 0 until tileWidth) {
                        val xOffset = x * 8
                        for (i in 0 until 8) {
                            if (position >= data.size) break // don't write the blank 'bonus' tiles for tilesets
                            var newValue = 0
                            for (j in 0 until 8) newValue = newValue or ((pixels[xOffset + j][yOffset + i] shl j) and 0xFF)
                            data[position] = newValue.toByte()
                            position += 1
                        }
                    }
                }
            } else {
                throw NotImplementedError()
            }
        }
        /*@END SpriteRun.Companion*/
    }
    /*@END SpriteRun*/
}
