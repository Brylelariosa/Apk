// Port of ViewModels/QuickEditItems/DecapNames.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.map.*

open class DecapNames : IQuickEditItem { // cs:12-198
    override val name: String?
        get() { /*@DONE DecapNames.Name.get cs:13-13*/
            return "Decapitalize Names"
        }
    override val description: String?
        get() { /*@DONE DecapNames.Description.get cs:15-15*/
            return "Decapitalize names of Pokemon, Species, Moves, Abilities, Items, Trainers, Types, and Natures"
        }
    override val wikiLink: String?
        get() { /*@DONE DecapNames.WikiLink.get cs:17-17*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Decapitalization-Explained"
        }
    override val canRunChanged = Event<EventArgs>()
    override fun canRun(viewPort: IViewPort): Boolean { /*@DONE DecapNames.CanRun/1 cs:21-21*/
        return viewPort is ViewPort
    }
    override fun run(viewPortInterface: IViewPort): Task<ErrorInfo>? { /*@DONE DecapNames.Run/1 cs:23-152*/
        return asyncTask<ErrorInfo> {
            if (viewPortInterface !is ViewPort) return@asyncTask ErrorInfo.noError
            val viewPort: ViewPort = viewPortInterface
            val model = viewPort.model

            viewPort.updateProgress(0.0).await()

            // text lists
            for (tableName in arrayOf(
                HardcodeTablesModel.abilityNamesTable,
                HardcodeTablesModel.contestTypesTable,
                HardcodeTablesModel.decorationsTableName,
                HardcodeTablesModel.dexInfoTableName,
                HardcodeTablesModel.itemsTableName,
                HardcodeTablesModel.moveNamesTable,
                HardcodeTablesModel.pokemonNameTable,
                HardcodeTablesModel.trainerClassNamesTable,
                HardcodeTablesModel.trainerTableName,
                HardcodeTablesModel.typesTableName,
                "data.items.berry.stats",
                "data.pokemon.contest.stats",
                "data.pokemon.trades"
            )) {
                val tableAddress = model.getAddressFromAnchor(viewPort.currentChange, -1, tableName)
                if (tableAddress == Pointer.null_) continue
                val tableRun = model.getNextRun(tableAddress)
                val table = tableRun as? ITableRun
                if (tableRun == null || tableRun.start != tableAddress || table == null) continue
                var offset = 0
                for (i in 0 until table.elementContent.size) {
                    if (table.elementContent[i].type == ElementContentType.PCS) {
                        for (j in 0 until table.elementCount) {
                            decapitalize(model, viewPort.currentChange, table.start + table.elementLength * j + offset)
                        }
                    }
                    offset += table.elementContent[i].length
                }
            }

            viewPort.updateProgress(0.1).await()

            // pointer-to-text lists
            for (tableName in arrayOf(
                HardcodeTablesModel.mapNameTable,
                HardcodeTablesModel.naturesTableName,
                HardcodeTablesModel.abilityDescriptionsTable,
                "data.battle.text",
                "data.maps.dungeons.stats",
                "data.menus.text.options", // TODO the values (FireRed=3CC330): Slow/Mid/Fast, On/Off, Shift/Set, Mono/Stereo, Help/LR/L=A
                "data.menus.text.pc",
                "data.menus.text.pcoptions",
                "data.menus.text.pokemon",
                "data.pokedex.habitat.names",
                "data.pokemon.moves.details.fallback.names",
                "data.text.menu.pause",
                "data.text.menu.pokemon.options",
                "scripts.newgame.names.female",
                "scripts.newgame.names.male",
                "scripts.newgame.names.rival",
                "data.maps.dungeons.stats",
                "scripts.text.names",
                "scripts.text.interviews",
                "scripts.text.destinations"
            )) {
                val tableAddress = model.getAddressFromAnchor(viewPort.currentChange, -1, tableName)
                if (tableAddress == Pointer.null_) continue
                val tableRun = model.getNextRun(tableAddress)
                val table = tableRun as? ITableRun
                if (tableRun == null || tableRun.start != tableAddress || table == null) continue
                for (i in 0 until table.elementCount) {
                    for (segment in table.elementContent.filterIsInstance<ArrayRunPointerSegment>()) {
                        if (segment.innerFormat != "\"\"") continue
                        val offset = table.elementContent.until { seg -> seg === segment }.sumOf { seg -> seg.length }
                        val destination = model.readPointer(table.start + table.elementLength * i + offset)
                        decapitalize(model, viewPort.currentChange, destination)
                    }
                }
            }

            // multichoice [options< [text<""> unused::]/count > count::]
            val parent = model.getTable(HardcodeTablesModel.multichoiceTableName)
            if (parent != null) {
                for (i in 0 until parent.elementCount) {
                    var destination = model.readPointer(parent.start + parent.elementLength * i)
                    val child = model.getNextRun(destination) as? ITableRun
                    if (child != null) {
                        for (j in 0 until child.elementCount) {
                            destination = model.readPointer(child.start + child.elementLength * j)
                            decapitalize(model, viewPort.currentChange, destination)
                        }
                    }
                }
            }

            // single strings
            for (anchor in model.anchors.toList()) {
                val run = model.getNextRun(model.getAddressFromAnchor(viewPort.currentChange, -1, anchor))
                if (run is PCSRun) decapitalize(model, viewPort.currentChange, run.start)
            }

            // "S" / "IES" additions for FR/LG
            val address = when (model.getGameCode()) {
                "BPRE0", "BPGE0" -> 0x06BDE8
                "BPRE1", "BPGE1" -> 0x06BDFC
                else -> -1
            }
            if (address >= 0) {
                val destination = model.readPointer(address)
                decapitalize(model, viewPort.currentChange, destination, startLowercase = true)
                decapitalize(model, viewPort.currentChange, destination + 2, startLowercase = true)
            }

            viewPort.updateProgress(0.2).await()

            // scripts
            val scriptAddresses = Flags.getAllTopLevelScripts(model)
            val parser = viewPort.tools?.codeTool?.scriptParser
            if (parser != null) {
                val spots = Flags.getAllScriptSpots(model, parser, scriptAddresses, false, 0x0F, 0x67) // loadpointer, preparemsg
                for (spot in spots) {
                    val offset = when (spot.line.lineCode[0]) { 0x0F -> 2; 0x67 -> 1; else -> throw NotImplementedException() }
                    val textStart = model.readPointer(spot.address + offset)
                    decapitalize(model, viewPort.currentChange, textStart)
                }
            }

            viewPort.updateProgress(0.3).await()

            // POKEMON (with the accented e)
            val searchText = (model.textConverter.convert("POK\u00c9MON".replace('\u00c9', '\u00e9'), Ref(false)) ?: ArrayList<Int>()).take(7)
            val findResults = model.find(*searchText.toIntArray()).toList()
            val replacement = (model.textConverter.convert("Pok\u00e9mon", Ref(false)) ?: ArrayList<Int>()).take(7).toIntArray().map { it and 0xFF }
            val replacementBytes = replacement.toByteArrayU().asByteList()
            for (i in 0 until findResults.size) {
                viewPort.updateProgress(i.toDouble() / findResults.size).await()
                viewPort.currentChange.changeData(model, findResults[i], replacementBytes)
            }

            viewPort.refresh()
            ErrorInfo.noError
        }
    }
    override fun tabChanged() { /*@DONE DecapNames.TabChanged/1 cs:154-154*/
        canRunChanged(this, EventArgs.empty)
    }
    private fun decapitalize(model: IDataModel, token: ModelDelta, address: Int, startLowercase: Boolean = false) { /*@DONE DecapNames.Decapitalize/1 cs:156-184*/
        if (address < 0 || address >= model.count) return
        val textLength = PCSString.readString(model, address, true)
        if (textLength < 3 && !startLowercase) return
        val upperA = 0xBB
        val lowerA = 0xD5
        val run = PCSRun(model, address, textLength)
        val pcs0 = run.createDataFormat(model, address) as? PCS
        var previousIsCap = false
        var previousIsSpecial = false
        if (pcs0 != null) {
            previousIsCap = isCap(pcs0.thisCharacter)
            previousIsSpecial = isSpecial(model, pcs0)
        }
        var start = 1
        if (startLowercase) {
            previousIsCap = false
            previousIsSpecial = true
            start = 0
        }
        for (i in start until textLength) {
            var format = run.createDataFormat(model, address + i)
            if (format is Anchor) format = format.originalFormat ?: format
            val pcs = format as? PCS
            if (pcs == null) {
                previousIsCap = false
                continue
            }
            val capital = isCap(pcs.thisCharacter)
            val special = isSpecial(model, pcs)
            if ((previousIsCap || previousIsSpecial) && capital) {
                token.changeData(model, address + i, (model[address + i] - upperA + lowerA) and 0xFF)
            }
            previousIsCap = capital
            previousIsSpecial = special
        }
    }
    private fun isCap(c: String): Boolean { /*@DONE DecapNames.IsCap/1 cs:186-190*/
        val text = if (c.startsWith("\"")) c.substring(1) else c
        if (text.length != 1) return false
        return 'A' <= text[0] && text[0] <= 'Z'
    }
    private fun isSpecial(model: IDataModel, pcs: PCS): Boolean { /*@DONE DecapNames.IsSpecial/1 cs:192-197*/
        val address = pcs.source + pcs.position
        if (model[address] == 0x1B) return true // e-acute
        if (model[address] == 0xB4) return true // apostrophe
        return false
    }
    /*@END DecapNames*/
}
