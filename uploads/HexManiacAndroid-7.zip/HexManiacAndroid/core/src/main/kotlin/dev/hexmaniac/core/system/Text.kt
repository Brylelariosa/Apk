package dev.hexmaniac.core.system

// Formatting / parsing helpers that stand in for ToString("X2"), int.TryParse(..., NumberStyles.HexNumber) and friends.

private const val HEX_DIGITS = "0123456789ABCDEF"

/** C# `value.ToString("X" + width)` -- upper case hex, left padded with zeros to at least [width] digits. */
fun Int.toHex(width: Int = 1): String {
    val sb = StringBuilder(8)
    var v = this
    for (i in 7 downTo 0) {
        sb.append(HEX_DIGITS[(v ushr (i * 4)) and 0xF])
    }
    // strip leading zeros down to the requested width (negative numbers keep all 8 digits, like C#)
    var start = 0
    while (start < 8 - width.coerceAtMost(8) && sb[start] == '0') start++
    return sb.substring(start)
}

/** C# `value.ToString("X" + width)` for a long. */
fun Long.toHex(width: Int = 1): String {
    val s = java.lang.Long.toHexString(this).uppercase()
    return if (s.length >= width) s else "0".repeat(width - s.length) + s
}

/** `byte.ToString("X2")` for a byte value stored as Int 0..255 (see ToHexString in SystemExtensions). */
fun Int.toHexByte(): String = "" + HEX_DIGITS[(this ushr 4) and 0xF] + HEX_DIGITS[this and 0xF]

/**
 * C# `int.TryParse(text, NumberStyles.HexNumber, ..., out result)`: hex digits only (no 0x prefix), surrounding
 * whitespace allowed, values up to FFFFFFFF wrap to negative ints like in C#.
 */
fun tryParseHexInt(text: String?, result: Ref<Int>): Boolean {
    if (text == null) return false
    val t = text.trim()
    if (t.isEmpty() || t.length > 8) return false
    var v = 0L
    for (c in t) {
        val d = Character.digit(c, 16)
        if (d < 0) return false
        v = v * 16 + d
    }
    result.value = v.toInt()
    return true
}

/** C# `int.TryParse(text, out result)`: optional sign, decimal digits, surrounding whitespace allowed. */
fun tryParseInt(text: String?, result: Ref<Int>): Boolean {
    if (text == null) return false
    val v = text.trim().let { if (it.startsWith("+")) it.substring(1) else it }.toIntOrNull() ?: return false
    result.value = v
    return true
}

/** C# `double.TryParse(text, out result)` with the invariant culture. */
fun tryParseDouble(text: String?, result: Ref<Double>): Boolean {
    if (text == null) return false
    val v = text.trim().toDoubleOrNull() ?: return false
    result.value = v
    return true
}

/** C# `int.Parse(text, NumberStyles.HexNumber)`: hex digits only; values above 0x7FFFFFFF wrap like 32-bit two's complement. Throws FormatException. */
fun parseHexInt(text: String): Int = java.lang.Long.parseLong(text.trim(), 16).toInt()

/** C# `int.Parse(text)`. Throws FormatException. */
fun parseInt(text: String): Int = text.trim().let { if (it.startsWith("+")) it.substring(1) else it }.toInt()
