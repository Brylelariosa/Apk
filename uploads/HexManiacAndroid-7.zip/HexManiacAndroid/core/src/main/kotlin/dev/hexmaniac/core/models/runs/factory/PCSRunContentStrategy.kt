// Port of Models/Runs/Factory/PCSRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class PCSRunContentStrategy : RunStrategy() { // cs:9-54
    override fun lengthForNewRun(model: IDataModel, pointerAdress: Int): Int { /*@DONE PCSRunContentStrategy.LengthForNewRun/1 cs:10-10*/
        return 1
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE PCSRunContentStrategy.TryAddFormatAtDestination/1 cs:11-29*/
        val length = PCSString.readString(owner, destination, true)

        if (length < 1) return false

        // our token will be a no-change token if we're in the middle of exploring the data.
        // If so, don't actually add the run. It's enough to know that we _can_ add the run.
        if (token !is NoDataChangeDeltaModel) {
            val existingRun = owner.getNextRun(destination) ?: NoInfoRun.nullRun

            // don't add a format if it would conflict with an existing format
            if (existingRun.start < destination) return false
            if (existingRun.start > destination && existingRun.start < destination + length) return false
            owner.observeRunWritten(token, PCSRun(owner, destination, length))
        }

        // even if we didn't add the format, we're _capable_ of adding it... so return true
        return true
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE PCSRunContentStrategy.Matches/1 cs:30-30*/
        return run is PCSRun
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE PCSRunContentStrategy.WriteNewRun/1 cs:31-34*/
        // found freespace, so this should already be an FF. Just add the format.
        return PCSRun(owner, destination, 1)
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE PCSRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:35-42*/
        val length = PCSString.readString(model, run.value.start, true)
        if (length > 0) {
            val newRun = PCSRun(model, run.value.start, length, run.value.pointerSources)
            if (newRun != run.value) model.clearFormat(token, newRun.start, newRun.length)
            run.value = newRun
        }
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE PCSRunContentStrategy.TryParseData/1 cs:43-53*/
        val length = PCSString.readString(model, dataIndex, true)
        if (length < 0) {
            return ErrorInfo("Format was specified as a string, but no string was recognized.")
        } else if (PokemonModel.spanContainsAnchor(model, dataIndex, length)) {
            return ErrorInfo("Format was specified as a string, but a string would overlap the next anchor.")
        }
        run.value = PCSRun(model, dataIndex, length)

        return ErrorInfo.noError
    }
    /*@END PCSRunContentStrategy*/
}
