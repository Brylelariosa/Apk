// Port of ViewModels/QuickEditItems/IQuickEditItem.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*

interface IQuickEditItem { // cs:6-15
    val name: String?
    val description: String?
    val wikiLink: String?
    val canRunChanged: Event<EventArgs>
    fun canRun(viewPort: IViewPort): Boolean
    fun run(viewPort: IViewPort): Task<ErrorInfo>?
    fun tabChanged()
    /*@END IQuickEditItem*/
}
