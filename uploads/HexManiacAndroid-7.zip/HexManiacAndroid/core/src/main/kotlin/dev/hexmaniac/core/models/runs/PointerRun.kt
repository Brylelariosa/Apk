// Port of Models/Runs/PointerRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class PointerRun : BaseRun { // cs:4-24
    override val length: Int
        get() { /*@DONE PointerRun.Length.get cs:8-8*/
            return 4
        }
    override val formatString: String
        get() { /*@DONE PointerRun.FormatString.get cs:9-9*/
            return ""
        }
    constructor(start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE PointerRun.<init>/1 cs:11-11*/
        // the base constructor does all the work
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE PointerRun.CreateDataFormat/1 cs:13-20*/
        val destinationAddress = data.readPointer(start)
        val anchor = data.getAnchorFromAddress(start, destinationAddress)
        val run = data.getNextRun(destinationAddress)
        val hasError = data.pointerHasError(destinationAddress, run)
        val pointer = Pointer(start, index - start, destinationAddress, 0, anchor, hasError)
        return pointer
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE PointerRun.Clone/1 cs:21-23*/
        return PointerRun(start, newPointerSources)
    }
    companion object {
        const val pointerStart: Char = '<'
        const val pointerEnd: Char = '>'
        /*@END PointerRun.Companion*/
    }
    /*@END PointerRun*/
}

open class OffsetPointerRun : PointerRun { // cs:26-36
    var offset: Int = 0
        private set
    constructor(start: Int, offset: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE OffsetPointerRun.<init>/1 cs:28-28*/
        this.offset = offset
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE OffsetPointerRun.CreateDataFormat/1 cs:29-34*/
        val destinationAddress = data.readPointer(start)
        val anchor = data.getAnchorFromAddress(start, destinationAddress)
        val pointer = Pointer(start, index - start, destinationAddress, offset, anchor, destinationAddress < 0)
        return pointer
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE OffsetPointerRun.Clone/1 cs:35-35*/
        return OffsetPointerRun(start, offset, newPointerSources)
    }
    /*@END OffsetPointerRun*/
}
