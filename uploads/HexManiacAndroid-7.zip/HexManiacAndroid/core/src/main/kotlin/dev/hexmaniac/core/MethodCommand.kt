// Port of MethodCommand.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core

import dev.hexmaniac.core.system.*

open class MethodCommand : ICommand { // cs:15-115
    private var _context: Any? = null
    var context: Any?
        get() { /*@DONE MethodCommand.Context.get cs:18-18*/
            return _context
        }
        set(value) { /*@DONE MethodCommand.Context.set cs:19-24*/
            val oldContext = _context
            _context = value
            setupFromContext(oldContext, _context)
            raiseCanExecuteChanged(this, EventArgs.empty)
        }
    var executeName: String = ""
        private set
    var canExecuteName: String = ""
        private set
    var canExecuteChangedName: String = ""
        private set
    constructor(context: Any, executeMethodName: String, canExecuteMethodName: String? = null, canExecuteChangedEventName: String? = null) { /*@DONE MethodCommand.<init>/1 cs:33-38*/
        executeName = executeMethodName
        canExecuteName = canExecuteMethodName ?: "Can$executeName"
        canExecuteChangedName = canExecuteChangedEventName ?: "Can${executeName}Changed"
        this.context = context
    }
    private fun setupFromContext(oldContext: Any?, newContext: Any?) { /*@DONE MethodCommand.SetupFromContext/1 cs:40-56*/
        // The C# version binds the CanExecuteChanged event of the context by reflection (WPF binding helper); only the
        // INotifyPropertyChanged part is ported.
        if (oldContext != null) {
            if (oldContext is INotifyPropertyChanged) oldContext.propertyChanged -= contextChangedHandler
        }
        if (newContext != null) {
            if (newContext is INotifyPropertyChanged) newContext.propertyChanged += contextChangedHandler
        }
    }
    private fun onContextPropertyChanged(sender: Any, e: PropertyChangedEventArgs) { /*@DONE MethodCommand.OnContextPropertyChanged/1 cs:58-61*/
        if (e.propertyName != canExecuteName) return
        raiseCanExecuteChanged(this, e)
    }
    private fun raiseCanExecuteChanged(sender: Any, e: EventArgs) { /*@DONE MethodCommand.RaiseCanExecuteChanged/1 cs:63-63*/
        canExecuteChanged(this, e)
    }
    override val canExecuteChanged = Event<EventArgs>()
    override fun canExecute(parameter: Any?): Boolean { /*@DONE MethodCommand.CanExecute/1 cs:69-91*/
        // reflection based in C#; the Android UI does not use MethodCommand
        return _context != null
    }
    override fun execute(parameter: Any?) { /*@DONE MethodCommand.Execute/1 cs:93-114*/
        // reflection based in C#; inert here (see canExecute)
    }
    /*@ADD MethodCommand#util_1.txt*/
    private val contextChangedHandler: (Any?, PropertyChangedEventArgs) -> Unit = { s, e -> onContextPropertyChanged(s ?: this, e) }
    /*@ENDADD MethodCommand#util_1.txt*/
    /*@END MethodCommand*/
}
