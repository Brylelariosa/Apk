// Port of Models/Runs/Factory/TrainerPokemonTeamRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class TrainerPokemonTeamRunContentStrategy : RunStrategy { // cs:11-59
    private var showFullIVByteRange: Boolean = /*@INITAUTO TrainerPokemonTeamRunContentStrategy.showFullIVByteRange cs:12-12*/ false /*@ENDINIT*/
    constructor(showFullIVByteRange: Boolean) { /*@DONE TrainerPokemonTeamRunContentStrategy.<init>/1 cs:13-13*/
        this.showFullIVByteRange = showFullIVByteRange
    }
    override fun lengthForNewRun(model: IDataModel, pointerAdress: Int): Int { /*@DONE TrainerPokemonTeamRunContentStrategy.LengthForNewRun/1 cs:14-14*/
        return TrainerPokemonTeamRun(model, -1, showFullIVByteRange, SortedSpan(pointerAdress)).length
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE TrainerPokemonTeamRunContentStrategy.TryAddFormatAtDestination/1 cs:15-33*/
        val teamRun = TrainerPokemonTeamRun(owner, destination, showFullIVByteRange, SortedSpan(source))
        val length = teamRun.length
        if (length < 2) return false

        if (token !is NoDataChangeDeltaModel) {
            val existingRun = owner.getNextRun(teamRun.start) ?: NoInfoRun.nullRun
            if (existingRun.start >= teamRun.start + teamRun.length || existingRun is NoInfoRun || existingRun is PointerRun) {
                // safe to overwrite
                owner.clearFormat(token, teamRun.start, teamRun.length)
                owner.observeRunWritten(token, teamRun)
            } else {
                // don't overwrite this run
                return false
            }
        }

        return true
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE TrainerPokemonTeamRunContentStrategy.Matches/1 cs:34-34*/
        return run is TrainerPokemonTeamRun
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE TrainerPokemonTeamRunContentStrategy.WriteNewRun/1 cs:35-37*/
        return TrainerPokemonTeamRun(owner, destination, showFullIVByteRange, SortedSpan(source)).deserializeRun("0 ???", token, Ref<List<Int>?>(null), Ref<List<Int>?>(null)) // new run, so we don't care about the changes
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE TrainerPokemonTeamRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:38-47*/
        val runAttempt = TrainerPokemonTeamRun(model, run.value.start, showFullIVByteRange, run.value.pointerSources)
        if (runAttempt.length < 1) return

        // trainer teams should never be able to contain their own pointer sources
        val attemptSources = runAttempt.pointerSources
        if (attemptSources != null) {
            for (i in 0 until attemptSources.size) {
                if (attemptSources[i].inRange(runAttempt.start, runAttempt.start + runAttempt.length)) return
            }
        }

        model.clearFormat(token, run.value.start, runAttempt.length)
        run.value = runAttempt
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE TrainerPokemonTeamRunContentStrategy.TryParseData/1 cs:48-58*/
        var pointerSources: SortedSpan<Int> = run.value?.pointerSources ?: model.getUnmappedSourcesToAnchor(name)
        if (pointerSources.size == 0) {
            pointerSources = model.getUnmappedSourcesToAnchor(name)
        }
        if (pointerSources.size == 0) {
            return ErrorInfo("Cannot create trainer team without a pointer from trainer data.")
        }
        run.value = TrainerPokemonTeamRun(model, dataIndex, showFullIVByteRange, pointerSources)
        return ErrorInfo.noError
    }
    /*@END TrainerPokemonTeamRunContentStrategy*/
}
