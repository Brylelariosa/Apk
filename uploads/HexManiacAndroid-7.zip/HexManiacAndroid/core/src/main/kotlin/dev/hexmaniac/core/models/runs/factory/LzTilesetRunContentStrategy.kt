// Port of Models/Runs/Factory/LzTilesetRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class LzTilesetRunContentStrategy : RunStrategy { // cs:5-52
    var tilesetFormat: TilesetFormat = TilesetFormat()
        private set
    constructor(format: TilesetFormat) { /*@DONE LzTilesetRunContentStrategy.<init>/1 cs:7-7*/
        tilesetFormat = format
    }
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE LzTilesetRunContentStrategy.LengthForNewRun/1 cs:9-12*/
        val defaultData = ByteArray(tilesetFormat.bitsPerPixel * 8)
        return LZRun.compress(defaultData.asByteList(), 0, defaultData.size).count
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE LzTilesetRunContentStrategy.Matches/1 cs:14-14*/
        return run is LzTilesetRun && run.tilesetFormat.bitsPerPixel == tilesetFormat.bitsPerPixel
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE LzTilesetRunContentStrategy.TryAddFormatAtDestination/1 cs:16-23*/
        val lzRun = LZRun(owner, destination)
        if (lzRun.length < 0) return false
        if (lzRun.decompressedLength % 0x20 != 0) return false
        val newRun = LzTilesetRun(tilesetFormat, owner, destination)
        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, newRun)
        return true
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE LzTilesetRunContentStrategy.TryParseData/1 cs:25-35*/
        val error = SpriteRunContentStrategy.isValid(tilesetFormat)
        if (error.hasError) return error
        val lzRun = LzTilesetRun(tilesetFormat, model, dataIndex)
        if (lzRun.length == LZRun.decompressedTooLong) return ErrorInfo("Decompressed more bytes than expected. Add a ! to override this.")
        if (lzRun.length < 0) return ErrorInfo("Format was specified as a compressed tileset, but no compressed data was recognized.")
        if (lzRun.decompressedLength % 0x20 != 0) return ErrorInfo("Format was specified as a compressed tileset, but the compressed data was not the proper length to be a tileset.")
        val newRun = LzTilesetRun(tilesetFormat, model, dataIndex)
        run.value = newRun
        return ErrorInfo.noError
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE LzTilesetRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:37-44*/
        val lzRun = LZRun(model, run.value.start)
        if (lzRun.length < 0) return
        if (lzRun.decompressedLength % 0x20 != 0) return
        val newRun = LzTilesetRun(tilesetFormat, model, run.value.start, run.value.pointerSources)
        model.clearFormat(token, newRun.start, newRun.length)
        run.value = newRun
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE LzTilesetRunContentStrategy.WriteNewRun/1 cs:46-51*/
        val defaultData = ByteArray(tilesetFormat.bitsPerPixel * 8)
        val data = LZRun.compress(defaultData.asByteList(), 0, defaultData.size)
        for (i in 0 until data.count) token.changeData(owner, destination + i, data[i])
        return LzTilesetRun(tilesetFormat, owner, destination)
    }
    /*@END LzTilesetRunContentStrategy*/
}
