// Port of Models/Runs/TilemapTableRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.tools.*

open class TilemapTableRun : BaseRun, ITableRun { // cs:12-121
    private lateinit var model: IDataModel
    lateinit var segment: ArrayRunElementSegment
        private set
    var tilemapAnchor: String = ""
        private set
    lateinit var margins: TilemapMargins
        private set
    final override var elementCount: Int = 0
        private set
    final override var elementLength: Int = 0
        private set
    override val elementNames: List<String>? = /*@INITDONE TilemapTableRun.ElementNames cs:24-24*/ ArrayList<String>() /*@ENDINIT*/
    final override var elementContent: List<ArrayRunElementSegment> = ArrayList()
        private set
    override val canAppend: Boolean
        get() { /*@DONE TilemapTableRun.CanAppend.get cs:28-28*/
            return false
        }
    final override var length: Int = 0
        private set
    final override var formatString: String = ""
        private set
    constructor(model: IDataModel, anchorName: String, segment: ArrayRunElementSegment, margins: TilemapMargins, start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE TilemapTableRun.<init>/1 cs:34-52*/
        this.model = model
        tilemapAnchor = anchorName
        this.segment = segment
        this.margins = margins

        val tilemapAddress = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, anchorName)
        val tilemap = model.getNextRun(tilemapAddress) as? ITilemapRun
        if (tilemap != null) {
            val height = tilemap.spriteFormat.tileHeight + margins.top + margins.bottom
            val width = tilemap.spriteFormat.tileWidth + margins.left + margins.right
            elementCount = height * margins.lengthMultiplier
            elementLength = width * segment.length
            elementContent = (0 until width).map { segment }
        }

        length = elementCount * elementLength
        formatString = "[" + segment.serializeFormat + "]" + anchorName + this.margins.toString()
    }
    override fun append(token: ModelDelta, length: Int): ITableRun { /*@DONE TilemapTableRun.Append/1 cs:54-54*/
        throw NotImplementedException()
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE TilemapTableRun.AppendTo/1 cs:56-58*/
        ITableRunExtensions.appendTo(this, model, builder, start, length, depth)
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE TilemapTableRun.Clear/1 cs:60-62*/
        ITableRunExtensions.clear(this, model, changeToken, start, length)
    }
    private var lastFormatCreated: Int = /*@INITDONE TilemapTableRun.lastFormatCreated cs:64-64*/ Int.MAX_VALUE /*@ENDINIT*/
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE TilemapTableRun.CreateDataFormat/1 cs:65-84*/
        val inner = this.createSegmentDataFormat(data, index)
        if (index > lastFormatCreated) {
            lastFormatCreated = index
            return inner
        }

        if ((index - start) % elementLength != 0) return inner
        val address = data.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, tilemapAnchor)
        val run = data.getNextRun(address) as? ITilemapRun ?: return inner
        var pixels: IPixelViewModel = data.currentCacheScope.getImage(run) ?: return inner

        val missingTopRows = (index - start) / elementLength
        pixels = crop(pixels, -margins.left * 8, -margins.top * 8, -margins.right * 8, -margins.bottom * 8)
        pixels = duplicateDown(pixels, margins.lengthMultiplier)
        pixels = crop(pixels, 0, missingTopRows * 8, 0, 0)
        lastFormatCreated = index
        return SpriteDecorator(inner, pixels, pixels.pixelWidth / 8, pixels.pixelHeight / 8)
    }
    override fun duplicate(start: Int, pointerSources: SortedSpan<Int>?, segments: List<ArrayRunElementSegment>): ITableRun { /*@DONE TilemapTableRun.Duplicate/1 cs:114-116*/
        return TilemapTableRun(model, tilemapAnchor, segment, margins, start, pointerSources)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE TilemapTableRun.Clone/1 cs:118-120*/
        return TilemapTableRun(model, tilemapAnchor, segment, margins, start, newPointerSources)
    }
    companion object {
        fun crop(pixels: IPixelViewModel, left: Int, top: Int, right: Int, bottom: Int): ReadonlyPixelViewModel { /*@DONE TilemapTableRun.Crop/1 cs:86-98*/
            val width = pixels.pixelWidth - left - right
            val height = pixels.pixelHeight - top - bottom
            val pixelData = ShortArray(width * height)
            for (y in 0 until height) {
                val originalDataStart = pixels.pixelWidth * (y + top) + left
                if (originalDataStart < 0) continue
                val croppedDataStart = width * y
                val copyLength = minOf(width, pixels.pixelData.size - originalDataStart, pixelData.size - croppedDataStart)
                if (copyLength <= 0) continue
                System.arraycopy(pixels.pixelData, originalDataStart, pixelData, croppedDataStart, copyLength)
            }
            return ReadonlyPixelViewModel(SpriteFormat(4, width / 8, height / 8, ""), pixelData, pixels.transparent)
        }
        fun duplicateDown(pixels: IPixelViewModel, count: Int): IPixelViewModel { /*@DONE TilemapTableRun.DuplicateDown/1 cs:100-112*/
            if (count == 1) return pixels
            val pixelData = ShortArray(pixels.pixelWidth * pixels.pixelHeight * count)
            for (y in 0 until pixels.pixelHeight) {
                val originalDataStart = pixels.pixelWidth * y
                for (i in 0 until count) {
                    val newDataStart = pixels.pixelWidth * y + pixels.pixelData.size * i
                    System.arraycopy(pixels.pixelData, originalDataStart, pixelData, newDataStart, pixels.pixelWidth)
                }
            }
            return ReadonlyPixelViewModel(SpriteFormat(4, pixels.pixelWidth / 8, pixels.pixelHeight / 8 * count, ""), pixelData)
        }
        /*@END TilemapTableRun.Companion*/
    }
    /*@END TilemapTableRun*/
}

open class TilemapMargins { // cs:123-164
    var lengthMultiplier: Int = 0
        private set
    var left: Int = 0
        private set
    var top: Int = 0
        private set
    var right: Int = 0
        private set
    var bottom: Int = 0
        private set
    constructor(multiplier: Int, uniform: Int) { /*@DONE TilemapMargins.<init>/1 cs:131-131*/
        lengthMultiplier = multiplier
        left = uniform
        top = uniform
        right = uniform
        bottom = uniform
    }
    constructor(multiplier: Int, left: Int, top: Int, right: Int, bottom: Int) { /*@DONE TilemapMargins.<init>/2 cs:132-132*/
        lengthMultiplier = multiplier
        this.left = left
        this.top = top
        this.right = right
        this.bottom = bottom
    }
    override fun toString(): String { /*@DONE TilemapMargins.ToString/1 cs:156-163*/
        var result = ""
        if (lengthMultiplier != 1) result += "*" + lengthMultiplier
        if (left == 0 && top == 0 && right == 0 && bottom == 0) return result
        for (side in intArrayOf(left, top, right, bottom)) {
            result += if (side < 0) side.toString() else "+" + side
        }
        return result
    }
    companion object {
        val default: TilemapMargins = /*@INITAUTO TilemapMargins.Default cs:124-124*/ TilemapMargins(1, 0) /*@ENDINIT*/
        fun extractMargins(token: Ref<String>): TilemapMargins { /*@DONE TilemapMargins.ExtractMargins/1 cs:134-154*/
            if (token.value.isBlank()) return default
            var name = token.value
            val initialName = name
            var separators: IntArray = (0 until initialName.length).filter { i -> initialName[i].isAny('*', '+', '-') }.plus(initialName.length).toIntArray()
            if (separators.size == 1) return default
            var multiplier = 1
            if (name[separators[0]] == '*') {
                val tokenLength = separators[1] - separators[0]
                val multiplierText = name.substring(separators[0] + 1, separators[0] + tokenLength)
                val parsedMultiplier = Ref(0)
                multiplier = if (tryParseInt(multiplierText, parsedMultiplier)) parsedMultiplier.value else 1
                name = name.substring(0, separators[0]) + name.substring(separators[1])
                token.value = name
                separators = separators.drop(1).map { i -> i - tokenLength }.toIntArray()
            }
            if (separators.size != 5) return TilemapMargins(multiplier, 0)
            if (separators.take(4).any { i -> name[i] == '*' }) return TilemapMargins(multiplier, 0)
            val finalName = name
            val textMargins = (0 until 4).map { i -> finalName.substring(separators[i], separators[i + 1]) }
            val margins = textMargins.map { str ->
                val value = Ref(0)
                if (tryParseInt(str, value)) value.value else 0
            }
            token.value = name.substring(0, separators[0])
            return TilemapMargins(multiplier, margins[0], margins[1], margins[2], margins[3])
        }
        /*@END TilemapMargins.Companion*/
    }
    /*@END TilemapMargins*/
}
