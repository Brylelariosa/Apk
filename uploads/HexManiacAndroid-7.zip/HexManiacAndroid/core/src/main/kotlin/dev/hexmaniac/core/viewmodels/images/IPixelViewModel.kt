// Port of ViewModels/Images/IPixelViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.images

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*

interface IPixelViewModel : INotifyPropertyChanged { // cs:5-11
    val transparent: Short
    val pixelWidth: Int
    val pixelHeight: Int
    val pixelData: ShortArray
    val spriteScale: Double
    /*@END IPixelViewModel*/
}

fun IPixelViewModel.autoCrop(): IPixelViewModel { /*@DONE IPixelViewModelExtensions.AutoCrop/1 cs:15-31*/
    val image = this
    var top = 0
    var bottom = image.pixelHeight
    while (top < image.pixelHeight && image.pixelWidth.range().all { i -> image.pixelData[top * image.pixelWidth + i] == image.transparent }) top++
    while (bottom > top && image.pixelWidth.range().all { i -> image.pixelData[bottom * image.pixelWidth - i - 1] == image.transparent }) bottom--
    var height = bottom - top
    while (height % 8 != 0) {
        height++
        top = (top - 1).limitToRange(0, image.pixelHeight)
    }
    val data = ShortArray(image.pixelWidth * height)
    for (y in 0 until height) {
        for (x in 0 until image.pixelWidth) {
            data[y * image.pixelWidth + x] = image.pixelData[(top + y) * image.pixelWidth + x]
        }
    }
    return ReadonlyPixelViewModel(image.pixelWidth, height, data, image.transparent)
}
fun IPixelViewModel.reflectX(): IPixelViewModel { /*@DONE IPixelViewModelExtensions.ReflectX/1 cs:33-42*/
    val image = this
    val data = ShortArray(image.pixelWidth * image.pixelHeight)
    for (y in 0 until image.pixelHeight) {
        for (x in 0 until image.pixelWidth) {
            val xx = image.pixelWidth - x - 1
            data[y * image.pixelWidth + x] = image.pixelData[y * image.pixelWidth + xx]
        }
    }
    return ReadonlyPixelViewModel(image.pixelWidth, image.pixelHeight, data, image.transparent)
}

object IPixelViewModelExtensions { // cs:13-43
    /*@END IPixelViewModelExtensions*/
}
