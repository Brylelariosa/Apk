// Port of Models/Runs/IFormattedRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

interface IFormattedRun : ISearchTreePayload { // cs:11-20
    override val start: Int
    val length: Int
    val pointerSources: SortedSpan<Int>?
    val formatString: String
    fun createDataFormat(data: IDataModel, index: Int): IDataFormat
    fun mergeAnchor(sources: SortedSpan<Int>?): IFormattedRun
    fun removeSource(source: Int): IFormattedRun
    fun duplicate(start: Int, pointerSources: SortedSpan<Int>?): IFormattedRun
    /*@END IFormattedRun*/
}

fun IFormattedRun.containsOnlyPointerToSelf(): Boolean { /*@DONE IFormattedRunExtensions.ContainsOnlyPointerToSelf/1 cs:23-28*/
    val sources = pointerSources ?: return false
    if (sources.size != 1) return false
    val source = sources[0]
    return source >= start && source < start + length
}

object IFormattedRunExtensions { // cs:22-29
    /*@END IFormattedRunExtensions*/
}

interface IAppendToBuilderRun : IFormattedRun { // cs:31-34
    fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int)
    fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int)
    /*@END IAppendToBuilderRun*/
}

open class AutocompleteItem { // cs:36-41
    var text: String? = null
        private set
    var lineText: String = ""
        private set
    var characterOffset: Int = 0
    constructor(text: String, lineText: String) { /*@DONE AutocompleteItem.<init>/1 cs:40-40*/
        this.text = text
        this.lineText = lineText
    }
    /*@END AutocompleteItem*/
}

interface IStreamRun : IFormattedRun { // cs:48-72
    fun serializeRun(): String?
    fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, movedChildren: Ref<List<Int>?>): IStreamRun
    fun dependsOn(anchorName: String): Boolean
    fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem>?
    val visualizations: List<IPixelViewModel>
    val preFormatter: ITextPreProcessor?
    /*@END IStreamRun*/
}

open class FormattedRunComparer : Comparator<IFormattedRun> { // cs:74-77
    override fun compare(a: IFormattedRun, b: IFormattedRun): Int { /*@DONE FormattedRunComparer.Compare/1 cs:76-76*/
        return a.start.compareTo(b.start)
    }
    companion object {
        var instance: FormattedRunComparer = /*@INITAUTO FormattedRunComparer.Instance cs:75-75*/ FormattedRunComparer() /*@ENDINIT*/
            private set
        /*@END FormattedRunComparer.Companion*/
    }
    /*@END FormattedRunComparer*/
}

open class CompareFormattedRun : IFormattedRun { // cs:82-95
    final override var start: Int = 0
        private set
    override val length: Int
        get() { /*@DONE CompareFormattedRun.Length.get cs:84-84*/
            return 0
        }
    override val formatString: String
        get() { /*@DONE CompareFormattedRun.FormatString.get cs:85-85*/
            throw NotImplementedException()
        }
    constructor(start: Int) { /*@DONE CompareFormattedRun.<init>/1 cs:87-87*/
        this.start = start
    }
    override val pointerSources: SortedSpan<Int>?
        get() { /*@DONE CompareFormattedRun.PointerSources.get cs:89-89*/
            throw NotImplementedException()
        }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE CompareFormattedRun.CreateDataFormat/1 cs:90-90*/
        throw NotImplementedException()
    }
    override fun mergeAnchor(other: SortedSpan<Int>?): IFormattedRun { /*@DONE CompareFormattedRun.MergeAnchor/1 cs:91-91*/
        throw NotImplementedException()
    }
    override fun removeSource(source: Int): IFormattedRun { /*@DONE CompareFormattedRun.RemoveSource/1 cs:92-92*/
        throw NotImplementedException()
    }
    override fun duplicate(start: Int, pointerSources: SortedSpan<Int>?): IFormattedRun { /*@DONE CompareFormattedRun.Duplicate/1 cs:94-94*/
        throw NotImplementedException()
    }
    /*@END CompareFormattedRun*/
}

abstract class BaseRun : IFormattedRun { // cs:97-142
    override var start: Int = 0
    abstract override val length: Int
    abstract override val formatString: String
    override var pointerSources: SortedSpan<Int>? = null
    protected constructor(start: Int, sources: SortedSpan<Int>? = null) { /*@DONE BaseRun.<init>/1 cs:105-108*/
        this.start = start
        this.pointerSources = sources
    }
    protected var createForLeftEdge: Boolean = false
        private set
    protected var expectedDisplayWidth: Int = 0
        private set
    fun createDataFormat(data: IDataModel, index: Int, leftEdgeHint: Boolean, displayWidth: Int): IDataFormat { /*@DONE BaseRun.CreateDataFormat/1 cs:112-116*/
        createForLeftEdge = leftEdgeHint
        expectedDisplayWidth = displayWidth
        return createDataFormat(data, index)
    }
    abstract override fun createDataFormat(data: IDataModel, index: Int): IDataFormat
    override fun mergeAnchor(sources: SortedSpan<Int>?): IFormattedRun { /*@DONE BaseRun.MergeAnchor/1 cs:119-127*/
        if (sources == null) return this

        val current = pointerSources
        if (current == null) return clone(sources)

        if (current.containsAll(sources)) return this

        return clone(current.add(sources))
    }
    override fun removeSource(source: Int): IFormattedRun { /*@DONE BaseRun.RemoveSource/1 cs:129-131*/
        return clone(pointerSources?.remove1(source) ?: SortedSpan.none<Int>())
    }
    override fun duplicate(start: Int, pointerSources: SortedSpan<Int>?): IFormattedRun { /*@DONE BaseRun.Duplicate/1 cs:133-139*/
        val myStart = this.start
        this.start = start
        val copy = clone(pointerSources)
        this.start = myStart
        return copy
    }
    protected abstract fun clone(newPointerSources: SortedSpan<Int>?): BaseRun
    companion object {
        const val anchorStart: Char = '^'
        /*@END BaseRun.Companion*/
    }
    /*@END BaseRun*/
}

open class NoInfoRun : BaseRun { // cs:144-160
    override val length: Int
        get() { /*@DONE NoInfoRun.Length.get cs:149-149*/
            return 1
        }
    override val formatString: String
        get() { /*@DONE NoInfoRun.FormatString.get cs:150-150*/
            return ""
        }
    constructor(start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE NoInfoRun.<init>/1 cs:152-152*/
        // the base constructor does all the work
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE NoInfoRun.CreateDataFormat/1 cs:154-154*/
        return None.instance
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE NoInfoRun.Clone/1 cs:155-157*/
        return NoInfoRun(start, newPointerSources)
    }
    companion object {
        var nullRun: NoInfoRun = /*@INITDONE NoInfoRun.NullRun cs:145-145*/ NoInfoRun(Int.MAX_VALUE)  // effectively a null object /*@ENDINIT*/
            private set
        fun fromPointer(model: IDataModel, source: Int): NoInfoRun { /*@DONE NoInfoRun.FromPointer/1 cs:147-147*/
            return NoInfoRun(model.readPointer(source), SortedSpanStatic.one(source))
        }
        fun proxy(run: IFormattedRun): NoInfoRun { /*@DONE NoInfoRun.Proxy/1 cs:159-159*/
            return NoInfoRun(run.start, run.pointerSources)
        }
        /*@END NoInfoRun.Companion*/
    }
    /*@END NoInfoRun*/
}

open class FakeRun : BaseRun { // cs:165-172
    private var _length: Int = 0
    override val length: Int
        get() { /*@DONE FakeRun.Length.get cs:167-167*/
            return _length
        }
    override val formatString: String
        get() { /*@DONE FakeRun.FormatString.get cs:168-168*/
            throw NotImplementedException()
        }
    constructor(start: Int, length: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE FakeRun.<init>/1 cs:169-169*/
        this._length = length
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE FakeRun.CreateDataFormat/1 cs:170-170*/
        throw NotImplementedException()
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE FakeRun.Clone/1 cs:171-171*/
        return FakeRun(start, _length, newPointerSources)
    }
    /*@END FakeRun*/
}

object SortedSpanStatic { // cs:174-176
    fun <T : Comparable<T>> one(element: T): SortedSpan<T> { /*@DONE SortedSpanStatic.One/1 cs:175-175*/
        return SortedSpan(element)
    }
    /*@END SortedSpanStatic*/
}

open class SortedSpan<T : Comparable<T>> : ReadOnlyListMixin<T> { // cs:177-279
    private var elements: Array<T>
    final override var size: Int = 0
        private set
    override operator fun get(index: Int): T { /*@DONE SortedSpan.this/1.get cs:180-180*/
        return elements[index]
    }
    constructor(single: T) { /*@DONE SortedSpan.<init>/1 cs:183-183*/
        elements = newArray(1)
        elements[0] = single
        size = 1
    }
    constructor(source: List<T>) { /*@DONE SortedSpan.<init>/2 cs:185-191*/
        val set = java.util.TreeSet<T>(source)
        size = set.size
        elements = newArray(set.size)
        var i = 0
        for (t in set) elements[i++] = t
    }
    constructor(elements: Array<T>, length: Int) { /*@DONE SortedSpan.<init>/3 cs:197-197*/
        this.elements = elements
        size = length
    }
    fun add1(value: T): SortedSpan<T> { /*@DONE SortedSpan.Add1/1 cs:199-212*/
        val newElements = newArray(size + 1)
        var newElementCount = 0
        var oldElementIndex = 0
        var compare = 0
        while (oldElementIndex < size) {
            compare = elements[oldElementIndex].compareTo(value)
            if (compare < 0) {
                newElements[newElementCount] = elements[oldElementIndex]
                newElementCount++
                oldElementIndex++
            } else {
                break
            }
        }
        if (oldElementIndex < size && compare == 0) oldElementIndex++
        newElements[newElementCount++] = value
        System.arraycopy(elements, oldElementIndex, newElements, newElementCount, size - oldElementIndex)
        newElementCount += size - oldElementIndex
        return SortedSpan(newElements, newElementCount)
    }
    fun remove1(value: T): SortedSpan<T> { /*@DONE SortedSpan.Remove1/1 cs:214-224*/
        val newElements = newArray(size)
        var i = 0
        var compare = 0
        while (i < size) {
            compare = elements[i].compareTo(value)
            if (compare == 0) break
            newElements[i] = elements[i]
            i++
        }
        if (size - 1 - i > 0) {
            System.arraycopy(elements, i + 1, newElements, i, size - 1 - i)
            i = size - 1
        }
        return SortedSpan(newElements, i)
    }
    fun add(other: SortedSpan<T>?): SortedSpan<T> { /*@DONE SortedSpan.Add/1 cs:226-243*/
        if (other == null || other.size == 0) return this
        if (size == 0) return other
        val newElements = newArray(size + other.size)
        var a = 0
        var b = 0
        var d = 0
        var compare = 0
        while (a < size && b < other.size) {
            compare = elements[a].compareTo(other.elements[b])
            if (compare < 0) {
                newElements[d++] = elements[a++]
            } else {
                newElements[d++] = other.elements[b++]
                if (compare == 0) a++
            }
        }
        if (a < size) {
            System.arraycopy(elements, a, newElements, d, size - a)
            d += size - a
        }
        if (b < other.size) {
            System.arraycopy(other.elements, b, newElements, d, other.size - b)
            d += other.size - b
        }
        return SortedSpan(newElements, d)
    }
    fun remove(other: SortedSpan<T>): SortedSpan<T> { /*@DONE SortedSpan.Remove/1 cs:245-260*/
        val newElements = newArray(size)
        var a = 0
        var b = 0
        var d = 0
        var compare = 0
        while (a < size && b < other.size) {
            compare = elements[a].compareTo(other.elements[b])
            if (compare > 0) {
                b++
            } else if (compare < 0) {
                newElements[d++] = elements[a++]
            } else {
                a++
                b++
            }
        }
        System.arraycopy(elements, a, newElements, d, size - a)
        return SortedSpan(newElements, d)
    }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    fun containsAll(sources: SortedSpan<T>): Boolean { /*@DONE SortedSpan.ContainsAll/1 cs:265-278*/
        if (sources.size == 0) return true
        if (size == 0) return false

        // take advantage of the sorted order: make sure all 'sources' are in this collection
        var i = 0
        var j = 0
        while (i < size && j < sources.size) {
            val compare = elements[i].compareTo(sources[j])
            if (compare > 0) return false
            if (compare < 0) i++
            if (compare == 0) {
                i++
                j++
            }
        }
        return j == sources.size
    }
    companion object {
        fun <T : Comparable<T>> none(): SortedSpan<T> { /*@DONE SortedSpan.None.get cs:181-181*/
            return SortedSpan(newArrayOf<T>(0), 0)
        } // static member of a generic class: function instead of property
        /*@END SortedSpan.Companion*/
    }
    /*@ADD SortedSpan#runs_1.txt*/
    @Suppress("UNCHECKED_CAST")
    private fun newArray(n: Int): Array<T> = arrayOfNulls<Comparable<*>>(n) as Array<T>
    /*@ENDADD SortedSpan#runs_1.txt*/
    /*@END SortedSpan*/
}

/*@ADD file:models/runs/IFormattedRun.kt#runs_1.txt*/
@Suppress("UNCHECKED_CAST")
internal fun <T : Comparable<T>> newArrayOf(n: Int): Array<T> = arrayOfNulls<Comparable<*>>(n) as Array<T>
/*@ENDADD file:models/runs/IFormattedRun.kt#runs_1.txt*/
