// Port of ViewModels/AutoCompleteSelectionItem.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.runs.*

open class AutoCompleteSelectionItem : INotifyPropertyChanged { // cs:7-47
    var displayText: String = ""
        private set
    var completionText: String = ""
        private set
    var isSelected: Boolean = false
        private set
    var isFormatComplete: Boolean = /*@INITAUTO AutoCompleteSelectionItem.IsFormatComplete cs:11-11*/ true /*@ENDINIT*/
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    constructor(text: String, selection: Boolean) { /*@DONE AutoCompleteSelectionItem.<init>/1 cs:15-15*/
        completionText = text
        displayText = text
        isSelected = selection
    }
    constructor(display: String, completion: String, selection: Boolean) { /*@DONE AutoCompleteSelectionItem.<init>/2 cs:16-16*/
        displayText = display
        completionText = completion
        isSelected = selection
    }
    fun equals(other: AutoCompleteSelectionItem?): Boolean { /*@DONE AutoCompleteSelectionItem.Equals/1 cs:43-46*/
        if (other == null) return false
        return isSelected == other.isSelected && completionText == other.completionText
    }
    companion object {
        fun selectedIndex(options: Iterable<AutoCompleteSelectionItem>): Int { /*@DONE AutoCompleteSelectionItem.SelectedIndex/1 cs:18-25*/
            var index = 0
            for (option in options) {
                if (option.isSelected) return index
                index += 1
            }
            return -1
        }
        fun generate(options: Iterable<String>?, selectionIndex: Int): Iterable<AutoCompleteSelectionItem> { /*@DONE AutoCompleteSelectionItem.Generate/1 cs:27-33*/
            val result = ArrayList<AutoCompleteSelectionItem>()
            var i = 0
            for (option in options ?: emptyList()) {
                result.add(AutoCompleteSelectionItem(option, i == selectionIndex))
                i++
            }
            return result
        }
        fun generate2(options: Iterable<AutocompleteItem>, selectionIndex: Int): Iterable<AutoCompleteSelectionItem> { /*@DONE AutoCompleteSelectionItem.Generate/2 cs:35-41*/
            val result = ArrayList<AutoCompleteSelectionItem>()
            var i = 0
            for (option in options) {
                result.add(AutoCompleteSelectionItem(option.text ?: "", option.lineText, i == selectionIndex))
                i++
            }
            return result
        } // FIXME-SKEL renamed overload
        /*@END AutoCompleteSelectionItem.Companion*/
    }
    /*@END AutoCompleteSelectionItem*/
}
