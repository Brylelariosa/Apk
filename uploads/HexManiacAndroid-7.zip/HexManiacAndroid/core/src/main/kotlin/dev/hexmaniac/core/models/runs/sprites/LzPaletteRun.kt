// Port of Models/Runs/Sprites/LzPaletteRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.tools.*

open class LzPaletteRun : PagedLZRun, IPaletteRun { // cs:7-93
    final override var paletteFormat: PaletteFormat = PaletteFormat()
        private set
    final override var formatString: String = ""
        private set
    override val pages: Int
        get() { /*@DONE LzPaletteRun.Pages.get cs:13-18*/
            if (start + 4 > model!!.count) return 1
            val length = model!!.readMultiByteValue(start + 1, 3)
            val paletteLength = Math.pow(2.0, paletteFormat.bits.toDouble()).toInt() * 2
            return length / paletteLength
        }
    protected override val uncompressedPageLength: Int
        get() { /*@DONE LzPaletteRun.UncompressedPageLength.get cs:21-21*/
            return paletteFormat.expectedByteLengthPerPage
        }
    constructor(paletteFormat: PaletteFormat, data: IDataModel, start: Int, sources: SortedSpan<Int>? = null) : super(data, start, paletteFormat.allowLengthErrors, sources) { /*@DONE LzPaletteRun.<init>/1 cs:23-33*/
        this.paletteFormat = paletteFormat
        if (Math.pow(2.0, paletteFormat.bits.toDouble()).toInt() * 2 > decompressedLength) invalidateLength()
        var text = "`lzp" + paletteFormat.bits + "`"
        if (paletteFormat.initialBlankPages != 0) {
            text = "`lzp" + paletteFormat.bits + ":"
            for (i in 0 until paletteFormat.pages) text += ViewPort.allHexCharacters[paletteFormat.initialBlankPages + i]
            text += "`"
        }
        formatString = text
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE LzPaletteRun.Clone/1 cs:65-65*/
        return LzPaletteRun(paletteFormat, model!!, start, newPointerSources)
    }
    override fun duplicate(newFormat: PaletteFormat): IPaletteRun { /*@DONE LzPaletteRun.Duplicate/1 cs:67-67*/
        return LzPaletteRun(newFormat, model!!, start, pointerSources)
    }
    override fun getPalette(model: IDataModel, page: Int): List<Short>? { /*@DONE LzPaletteRun.GetPalette/1 cs:69-76*/
        val data = decompress(model, start, allowLengthErrors)
        val colorCount = Math.pow(2.0, paletteFormat.bits.toDouble()).toInt()
        val pageLength = colorCount * 2
        val pageIndex = if (pages > 0) page % pages else 0
        if (data == null) return TileViewModel.createDefaultPalette(pageLength).toList()
        return PaletteRun.getPalette(data.asByteList(), pageIndex * pageLength, colorCount)
    }
    override fun setPalette(model: IDataModel, token: ModelDelta, page: Int, colors: List<Short>): IPaletteRun { /*@DONE LzPaletteRun.SetPalette/1 cs:78-92*/
        val data = decompress(model, start, true) ?: return this
        val colorCount = Math.pow(2.0, paletteFormat.bits.toDouble()).toInt()
        val pageLength = colorCount * 2
        val pageIndex = if (pages > 0) page % pages else 0
        PaletteRun.setPalette(data, pageIndex * pageLength, colors)

        val newModelData = compress(data.asByteList(), 0, data.size)
        var newRun: IPaletteRun = model.relocateForExpansion(token, this, newModelData.count)
        for (i in 0 until newModelData.count) token.changeData(model, newRun.start + i, newModelData[i])
        for (i in newModelData.count until length) token.changeData(model, newRun.start + i, 0xFF)
        newRun = LzPaletteRun(paletteFormat, model, newRun.start, newRun.pointerSources)
        model.observeRunWritten(token, newRun)
        return newRun
    }
    companion object {
        fun tryParsePaletteFormat(pointerFormat: String, paletteFormat: Ref<PaletteFormat>): Boolean { /*@DONE LzPaletteRun.TryParsePaletteFormat/1 cs:35-39*/
            paletteFormat.value = PaletteFormat()
            if (!pointerFormat.startsWith("`lzp") || !pointerFormat.endsWith("`")) return false
            return tryParseDimensions(pointerFormat, paletteFormat)
        }
        fun tryParseDimensions(format: String, paletteFormat: Ref<PaletteFormat>): Boolean { /*@DONE LzPaletteRun.TryParseDimensions/1 cs:42-63*/
            paletteFormat.value = PaletteFormat()
            val formatContent = format.substring(4, format.length - 1)
            val pageSplit = formatContent.split(':').toMutableList()
            val allowLengthErrors = pageSplit[0].endsWith("!")
            if (allowLengthErrors) pageSplit[0] = pageSplit[0].substring(0, pageSplit[0].length - 1)
            val bitsRef = Ref(0)
            if (!tryParseInt(pageSplit[0], bitsRef)) return false
            val bits = bitsRef.value
            if (!(bits == 1 || bits == 2 || bits == 4 || bits == 8)) return false
            var pages = 1
            var pageStart = 0
            if (pageSplit.size == 2) {
                val lastPageID = pageSplit[1].uppercase().lastOrNull() ?: '\u0000'
                val lastPageIndex = ViewPort.allHexCharacters.indexOf(lastPageID)
                if (lastPageIndex > 0) pages = lastPageIndex + 1
                val firstPageID = pageSplit[1].uppercase().firstOrNull() ?: '\u0000'
                val firstPageIndex = ViewPort.allHexCharacters.indexOf(firstPageID)
                if (firstPageIndex > 0) pageStart = firstPageIndex
                pages -= firstPageIndex
            }

            paletteFormat.value = PaletteFormat(bits, pages, pageStart, allowLengthErrors)
            return true
        }
        /*@END LzPaletteRun.Companion*/
    }
    /*@END LzPaletteRun*/
}
