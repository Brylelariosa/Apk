// Port of Models/HardcodeTablesModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.runs.*

open class HardcodeTablesModel : PokemonModel { // cs:16-566
    private var gameCode: String = ""
    override val earliestAllowedAnchor: Int
        get() { /*@DONE HardcodeTablesModel.EarliestAllowedAnchor.get cs:114-114*/
            return 0x200
        }
    var loadingMessages: MutableList<String> = /*@INITDONE HardcodeTablesModel.LoadingMessages cs:116-116*/ ArrayList() /*@ENDINIT*/
        private set
    constructor(singletons: Singletons?, data: ByteArray, metadata: StoredMetadata? = null, devMode: Boolean = false) : super(data, metadata, singletons, devMode) { /*@DONE HardcodeTablesModel.<init>/1 cs:118-167*/
        gameCode = this.getGameCode()
        if (metadata != null && !metadata.isEmpty) {
            initializationWorkload = (singletons?.workDispatcher ?: InstantDispatch.instance).runBackgroundWork { initialize(metadata) }
            return
        }

        initializationWorkload = (singletons?.workDispatcher ?: InstantDispatch.instance).runBackgroundWork {
            run {
                val noChangeDelta = NoDataChangeDeltaModel()
                var currentMetadata = metadata
                val referenceConstants = singletons?.gameReferenceConstants?.get(gameCode)
                if (referenceConstants != null && singletons != null) {
                    currentMetadata = decodeConstantsFromReference(this, singletons.metadataInfo, currentMetadata, referenceConstants)
                }
                initialize(currentMetadata)
                isCFRU = getIsCFRU(this)

                // in vanilla emerald, this pointer isn't four-byte aligned
                // it's at the very front of the ROM, so if there's no metadata we can be pretty sure that the pointer is still there
                if (gameCode == emerald && data.size > earliestAllowedAnchor && (data[0x1C3].toInt() and 0xFF) == 0x08) observeRunWritten(noChangeDelta, PointerRun(0x1C0))

                val gamesToDecode = arrayOf(
                    ruby,
                    sapphire,
                    emerald,
                    fireRed,
                    leafGreen,
                    ruby1_1,
                    sapphire1_1,
                    fireRed1_1,
                    leafGreen1_1,
                    fireRedFr,
                    fireRedIt,
                    emeraldFr,
                    emeraldIt,
                    "ABCD0" // for tests
                )

                for (defaultMetadata in BaseModel.getDefaultMetadatas(gameCode.padEnd(4).substring(0, 4).lowercase(), gameCode.lowercase())) {
                    this.loadMetadata(defaultMetadata)
                }
                if (gamesToDecode.contains(gameCode)) {
                    val referenceTables = singletons?.gameReferenceTables?.get(gameCode)
                    if (referenceTables != null) {
                        decodeTablesFromReference(referenceTables)
                    }
                }

                resolveConflicts()
            }
        }
    }
    private fun checkForEmptyAnchors(destination: Int, anchor: String) { /*@DONE HardcodeTablesModel.CheckForEmptyAnchors/1 cs:170-173*/
        // debug-only assertion in the original: a table anchor found by reference should have pointers.
        getNextRun(destination)
    }
    private fun decodeTablesFromReference(tables: GameReferenceTables) { /*@DONE HardcodeTablesModel.DecodeTablesFromReference/1 cs:175-295*/
        // add evolution types
        val evolutionRef = Ref<ValidationList?>(null)
        if (isCFRU && tryGetList(evolutionMethodListName, evolutionRef)) {
            val newList = ArrayList<String?>(evolutionRef.value!!)
            newList.add("Rain Or Fog")
            newList.add("Move Type")      // 17 type
            newList.add("Type in Party")  // 18 type
            newList.add("Map")
            newList.add("Male")
            newList.add("Female")
            newList.add("Level Night")
            newList.add("Level Day")
            newList.add("Hold Item Night") // 24 hold item
            newList.add("Hold Item Day")   // 25 hold item
            newList.add("Move Name")       // 26 move name
            newList.add("Mon in Party")    // 27 species
            newList.add("Level Time Range")
            newList.add("Flag Set")
            newList.add("3 Critical Hits In One Battle")
            newList.add("Nature High")
            newList.add("Nature Low")
            newList.add("Damage Location")
            newList.add("Item Location")
            while (newList.size <= 252) newList.add(null) // skip to gigantamax = 253 mega = 254
            newList.add("Gigantamax")
            newList.add("Mega")
            setList(NoDataChangeDeltaModel(), evolutionMethodListName, newList as List<String>, null, StoredList.generateHash(newList))
        }

        // add move effects
        val moveEffectRef = Ref<ValidationList?>(null)
        if (isCFRU && tryGetList(moveEffectListName, moveEffectRef)) {
            val newList = ArrayList<String?>(moveEffectRef.value!!)
            newList[12] = "RaiseSpeed1Primary"
            newList[14] = "RaiseSpDefese1Primary"
            newList[15] = "RaiseAccuracy1Primary"
            newList[21] = "LowerSpAtk1Primary"
            newList[22] = "LowerSpDef1Primary"
            newList[25] = "RemoveStatChanges"
            newList[55] = "RaiseAccuracy2Primary"
            newList[56] = "RaiseEvasion2Primary"
            newList[61] = "LowerSpAttack2Primary"
            newList[63] = "LowerAccuracy2Primary"
            newList[64] = "LowerEvasion2Primary"
            newList[74] = "LowerEvasion1HitChance"
            newList[77] = "Unused4D"
            newList[78] = "Unused4E"
            newList[96] = "RaiseSpeed1HitChance"
            newList[110] = "RaiseSpAtk1HitChance"
            newList[121] = "Unused79"
            newList[123] = "Unused7B"
            newList[125] = "BurnUp"
            newList[135] = "RaiseDefense2HitChance"
            newList[150] = "Unused96"
            newList[169] = "UnusedA9"
            newList[174] = "BoostNextElectricMoveAndRaiseSpDef"
            newList[185] = "UnusedB9"
            newList[196] = "UnusedC4"
            newList[198] = "RaiseAttack1SpAtk1"
            newList[199] = "RaiseAttack1Accuracy1"
            newList[200] = "UnusedC8"
            newList[202] = "UnusedCA"
            newList[203] = "UnusedCB"
            newList[207] = "RaiseAllStatsPrimary"
            newList[213] = "Stat Swap or Split"
            newList.addAll(listOf<String?>(null, null, null, null, "Me First", "Eat Berry", "Natural Gift", "Smack Down", "Remove Target Stat Changes", "SleepHitChance", null, null,
                "Set Terrain", "Pledge", "Field Effects", "Fling", "Feint", "Attack Blockers", "Type Changes", "Heal Target", "Topsy Turvy Electrify", "Fairy Lock Happy Hour",
                "Instruct After You Quash", "Sucker Punch", "Ignore Redirection", "Team Effects", "Camouflage", "Flame Burst", "Last Resort Sky Drop", "Damage Set Terrain", "Teatime",
                "RaiseTarget'sAttackSpAtk2"))
            for (k in 0 until 7) newList.add(null) // 246 to 252 are unused.
            newList.addAll(listOf<String?>("Max Move", "Synchronoise"))
            setList(NoDataChangeDeltaModel(), moveEffectListName, newList as List<String>, null, StoredList.generateHash(newList))
        }

        // add item hold effects
        val holdEffectsRef = Ref<ValidationList?>(null)
        if (isCFRU && tryGetList("holdeffects", holdEffectsRef)) {
            val newList = ArrayList<String?>(holdEffectsRef.value!!)
            newList.addAll(listOf<String?>(
                "UnusedA", "RockyHelmet", "UnusedB", "AssaultVest",
                "Eviolite", "Plate", "MegaStone", "LifeOrb",
                "ToxicOrb", "FlameOrb", "BlackSludge", "SmoothRock",
                "DampRock", "HeatRock", "IcyRock", "LightClay",
                "WideLens", "SafetyGoggles", "WeaknessPolicy", "Drive",
                "Memory", "AdamantOrb", "LustrousOrb", "GriseousOrb",
                "DestinyKnot", "ExpertBelt", "PrimalOrb", "Gem",
                "WeaknessBerry", "CustapBerry", "LaggingTail", "IronBall",
                "BindingBand", "UnusedC", "ProtectivePads", "AbsorbBulb",
                "AirBalloon", "Bigroot", "CellBattery", "EjectButton",
                "FloatStone", "GripClaw", "LuminousMoss", "UnusedD",
                "Metronome", "MuscleBand", "RedCard", "RingTarget",
                "ShedShell", "Snowball", "StickyBarb", "TerrainExtender",
                "WiseGlasses", "Seeds", "JabocaRowapBerry", "KeeBerry",
                "MarangaBerry", "ZoomLens", "AdrenalineOrb", "PowerHerb",
                "MicleBerry", "EnigmaBerry", "TypeBoosters", "ZCrystal",
                "AbilityCapsule", "EjectPack", "RoomService", "BlunderPolicy",
                "HeavyDutyBoots", "UtilityUmbrella", "ThroatSpray"
            ))
            setList(NoDataChangeDeltaModel(), "holdeffects", newList as List<String>, null, StoredList.generateHash(newList))
        }

        // Update the type chart effectivenesses list
        val multipliersRef = Ref<ValidationList?>(null)
        if (isCFRU && tryGetList("effectiveness", multipliersRef)) {
            val newMultipliers = arrayOfNulls<String>(21) // 0 to 20
            newMultipliers[0] = "1x"
            newMultipliers[1] = "0x"
            newMultipliers[5] = "0.5x"
            newMultipliers[20] = "2x"
            val multiplierList = newMultipliers.toList()
            setList(NoDataChangeDeltaModel(), "effectiveness", multiplierList as List<String>, null, StoredList.generateHash(multiplierList))
        }

        for (table in tables) {
            // some tables have been removed from CFRU
            if (isCFRU && cfruIgnoreTables.contains(table.name)) continue

            ModelCacheScope.createScope(this).using {
                val format = table.format ?: ""
                addTable(table.address, table.offset, table.name, format)
            }
        }

        if (isCFRU) setupCFRUSpecificTablesAndConstants()
    }
    fun setupCFRUSpecificTablesAndConstants() { /*@DONE HardcodeTablesModel.SetupCFRUSpecificTablesAndConstants/1 cs:304-387*/
        showRawIVByteForTrainer = true

        // class-based pokeballs
        val balls = ArrayList<String?>(listOf(
            "Master Ball", "Ultra Ball", "Great Ball", "Poke Ball",
            "Safari Ball", "Net Ball", "Dive Ball", "Nest Ball",
            "Repeat Ball", "Timer Ball", "Luxury Ball", "Premier Ball",
            "Dusk Ball", "Heal Ball", "Quick Ball", "Cherish Ball",
            "Park Ball", "Fast Ball", "Level Ball", "Lure Ball",
            "Heavy Ball", "Love Ball", "Friend Ball", "Moon Ball",
            "Sport Ball", "Beast Ball", "Dream Ball"
        ))
        while (balls.size < 0xFE) balls.add(null)
        balls.add("Class Based")
        balls.add("Random")
        setList(NoDataChangeDeltaModel(), "trainerballs", balls as List<String>, null, StoredList.generateHash(balls))
        addTable(0x1456790, 0, "data.trainers.classes.balls", "[ball.trainerballs]data.trainers.classes.names")

        // randomizer restrictions
        addTable(0x1453828, 0, "data.randomizer.species.banlist", "[species:" + pokemonNameTable + "]!FEFE")
        addTable(0x1454730, 0, "data.randomizer.ability.banlist", "[ability." + abilityNamesTable + "]!FF")

        // physical/special/split list
        val pss = listOf("Physical", "Special", "Status")
        setList(NoDataChangeDeltaModel(), "movecategory", pss, null, StoredList.generateHash(pss))

        // trainers-with-EVs table
        val trainerabilities = listOf("Hidden", "Ability1", "Ability2", "RandomNormal", "RandomAny")
        setList(NoDataChangeDeltaModel(), "trainerabilities", trainerabilities, null, StoredList.generateHash(trainerabilities))
        addTable(0x1456798, 0, "data.trainers.evs", "[nature.data.pokemon.natures.names ivs. hpEv. atkEv. defEv. spdEv. spAtkEv. spDefEv. ball.data.trainers.classes.names ability.trainerabilities]121")

        // trainer class-based encounter music
        addTable(0x144C110, 0, "data.trainers.classes.music", "[song:songnames]data.trainers.classes.names")

        // trainer sprite-based mugshots
        addTable(0x144FC94, 0, "data.trainers.sprites.mugshots", "[sprite<`lzs4x8x8|data.trainers.sprites.mugshots`> pal<`lzp4`> size: x:|z y:|z unused:]graphics.trainers.sprites.front-0-1")

        // kanto dex
        // first hword is actually the length of the table - 1
        // every hword after that is what pokemon appears in that slot of the dex (slot 1, slot 2, etc)
        addTable(0x160A52C, 0, "data.pokedex.kanto", "[mon:data.pokemon.names]152")

        // PSS icons/palette
        if (0x143B0EC < count - 4) {
            val spriteStart = readPointer(0x143B0EC)
            addTableDirect(spriteStart, "graphics.pokemon.moves.category.icons", "`ucs4x3x18|graphics.pokemon.moves.category.palette`")
            addTableDirect(spriteStart + 0x6C0, "graphics.pokemon.moves.category.palette", "`ucp4`")
        }

        // z-effects
        val newList = ArrayList<String>()
        newList.add("None")
        newList.add("Reset Stats")
        newList.add("All Stats Up 1")
        newList.add("Boost Crits")
        newList.add("Follow Me")
        newList.add("Curse")
        newList.add("Recover Hp")
        newList.add("Restore Replacement Hp")
        newList.add("Atk Up 1")
        newList.add("Def Up 1")
        newList.add("Spd Up 1")
        newList.add("Spatk Up 1")
        newList.add("Spdef Up 1")
        newList.add("Acc Up 1")
        newList.add("Evsn Up 1")
        newList.add("Atk Up 2")
        newList.add("Def Up 2")
        newList.add("Spd Up 2")
        newList.add("Spatk Up 2")
        newList.add("Spdef Up 2")
        newList.add("Acc Up 2")
        newList.add("Evsn Up 2")
        newList.add("Atk Up 3")
        newList.add("Def Up 3")
        newList.add("Spd Up 3")
        newList.add("Spatk Up 3")
        newList.add("Spdef Up 3")
        newList.add("Acc Up 3")
        newList.add("Evsn Up 3")
        setList(NoDataChangeDeltaModel(), "zeffects", newList, null, StoredList.generateHash(newList))
    }
    private fun addTable(source: Int, offset: Int, name: String, format: String) { /*@DONE HardcodeTablesModel.AddTable/1 cs:416-465*/
        val noChangeDelta = NoDataChangeDeltaModel()
        val sourceRef = Ref(source)
        val format = adjustFormatForCFRU(name, format, sourceRef)
        val source = sourceRef.value
        if (source < 0 || source > rawData.size) return
        val destination = readPointer(source) - offset
        if (destination < 0 || destination > rawData.size) return

        val interruptingSourceRun = getNextRun(source)
        if (interruptingSourceRun.start < source && interruptingSourceRun.start + interruptingSourceRun.length > source) {
            if (interruptingSourceRun is ITableRun) {
                val tableOffset = interruptingSourceRun.convertByteOffsetToArrayOffset(source)
                if (tableOffset.segmentOffset != 0) {
                    loadingMessages.add("Failed to add table " + name + ": it conflicted with an existing table found at " + interruptingSourceRun.start.toAddress() + ".")
                    return
                }
                if (interruptingSourceRun.elementContent[tableOffset.segmentIndex].type != ElementContentType.Pointer) {
                    loadingMessages.add("Failed to add table " + name + " at " + destination.toAddress() + ": data in the table didn't match pointers in the file.")
                    return
                }
            } else {
                // the source isn't actually a pointer, we shouldn't write anything
                return
            }
        }

        val interruptingRun = getNextRun(destination)
        if (interruptingRun.start < destination && interruptingRun is ArrayRun) {
            var array: ArrayRun = interruptingRun
            val elementCount = (destination - array.start) / array.elementLength
            val desiredChange = elementCount - array.elementCount
            while (!array.lengthFromAnchor.isNullOrEmpty()) {
                val nextArray = getNextRun(getAddressFromAnchor(noChangeDelta, -1, array.lengthFromAnchor ?: "")) as? ArrayRun
                if (nextArray != null) {
                    array = nextArray
                } else {
                    break
                }
            }
            if (array.elementCount + desiredChange <= 0) {
                // erase the entire run
                loadingMessages.add("When trying to add table " + name + ", had to clear existing format from " + array.start.toAddress() + " to " + (array.start + array.length).toAddress() + " because a formatting conflict was found.")
                clearFormat(noChangeDelta, array.start, array.length)
            } else {
                val arrayName = getAnchorFromAddress(-1, array.start)
                array = array.append(noChangeDelta, desiredChange) // if append is negative, the name might get erased. Store it.
                observeAnchorWritten(noChangeDelta, arrayName, array)
            }
        }

        addTableDirect(destination, name, format, offset == 0)
        if (offset != 0) observeRunWritten(noChangeDelta, OffsetPointerRun(source, offset))
    }
    private fun addTableDirect(destination: Int, name: String, format: String, validatePointerFound: Boolean = false) { /*@DONE HardcodeTablesModel.AddTableDirect/1 cs:470-480*/
        val noChangeDelta = NoDataChangeDeltaModel()
        var validate = validatePointerFound
        ModelCacheScope.createScope(this).using {
            val errorInfo = applyAnchor(this, noChangeDelta, destination, "^" + name + format, true)
            validate = validate && !errorInfo.hasError
        }

        if (validate) {
            checkForEmptyAnchors(destination, name)
        }
    }
    private var isCFRU: Boolean = false
    private fun adjustFormatForCFRU(name: String, format: String, source: Ref<Int>): String { /*@DONE HardcodeTablesModel.AdjustFormatForCFRU/1 cs:494-565*/
        if (!isCFRU) return format
        var format = format

        // type names
        if (name == typesTableName) format = format.split("]")[0] + "]24"

        // type icons
        if (name == "graphics.pokemon.type.icons") format = format.replace("ucs4x16x16", "ucs4x16x18")

        // remove the extra +28 from pokemon-related tables
        if (format.endsWith(pokemonNameTable + "+28")) format = format.substring(0, format.length - 3)

        // remove the extra +1 from pokemon-related tables
        if (format.endsWith(pokemonNameTable + "+1")) format = format.substring(0, format.length - 2)

        // hidden abilities stored in pokemon stats
        if (name == pokemonStatsTable) format = format.replace("padding:", "hiddenAbility." + abilityNamesTable + " padding.")

        // items: no constant
        if (name == itemsTableName) format = format.replace("data.items.count", "")

        // moves
        if (name == moveNamesTable) format += "896"
        if (name == moveDataTable) format = format.replace("unused. unused:", "zMovePower. category.movecategory zMoveEffect.zeffects")

        // level-up moves uses Jambo format
        if (name == levelMovesTableName) return "[movesFromLevel<[move:" + moveNamesTable + " level.]!0000FF>]" + pokemonNameTable

        // tms / tutors
        if (name == moveTutors) format = format.replace("]15", "]128")
        if (name == tmMoves) format = format.replace("]58", "]128")

        // graphics.pokemon.type.map[width. height. xy:|t|:|x:|.|y::]data.pokemon.type.names+1+2
        if (name == "graphics.pokemon.type.map") format = format.replace("data.pokemon.type.names+1+5", "data.pokemon.type.names+1+2")

        // overworld sprites
        if (name == overworldSprites) format = format.replace("graphics.overworld.tablelength", "240")

        // 16 evolutions per pokemon
        if (name == evolutionTableName) {
            val vars = listOf(
                "6=" + itemsTableName,
                "7=" + itemsTableName,
                "17=" + typesTableName,
                "18=" + typesTableName,
                "24=" + itemsTableName,
                "25=" + itemsTableName,
                "26=" + moveNamesTable,
                "27=" + pokemonNameTable,
                "254=" + itemsTableName
            ).joinToString("|")
            val methods = "0123456789ABCDEF".map { i -> "method" + i + ":evolutionmethods arg" + i + ":|s=method" + i + "(" + vars + ") species" + i + ":" + pokemonNameTable + " value" + i + ":" }.joinToString(" ")
            return "[" + methods + "]" + pokemonNameTable
        }

        // roaming locations
        if (name == "data.maps.roaming.sets") source.value = 0x14889B0

        if (name == itemEffectsTableName) format = format.replace("-199", "") // item effects are as long as the items

        // type chart
        if (name == "data.pokemon.type.chart") {
            source.value = 0x145BB74
            format = "Norm Fight Fly Poison Grd Rock Bug Ghost Steel arg9 Fire Water Grass Elec Psych Ice Drag Dark arg18 arg19 arg20 arg21 arg22 Fairy"
            format = format.split(' ').map { type -> type + ".effectiveness" }.joinToString(" ")
            format = "[" + format + "]data.pokemon.type.names"
        }

        return format
    }
    companion object {
        const val flySpawns: String = "data.maps.fly.spawn"
        const val tradeTable: String = "data.pokemon.trades"
        const val mapNameTable: String = "data.maps.names"
        const val mapBankTable: String = "data.maps.banks"
        const val rematchTable: String = "data.trainers.vsseeker"
        const val rematchTableRSE: String = "data.trainers.rematches"
        const val wildTableName: String = "data.pokemon.wild"
        const val specialsTable: String = "scripts.commands.events.specials"
        const val moveDataTable: String = "data.pokemon.moves.stats.battle"
        const val itemsTableName: String = "data.items.stats"
        const val mapLayoutTable: String = "data.maps.layouts"
        const val berryTableName: String = "data.items.berry.stats"
        const val typesTableName: String = "data.pokemon.type.names"
        const val moveNamesTable: String = "data.pokemon.moves.names"
        const val flyConnections: String = "data.maps.fly.connections"
        const val pokeIconsTable: String = "graphics.pokemon.icons.sprites"
        const val fontWidthTable: String = "graphics.text.font.black.width"
        const val dexInfoTableName: String = "data.pokedex.stats"
        const val pokemonNameTable: String = "data.pokemon.names"
        const val trainerTableName: String = "data.trainers.stats"
        const val moveEffectsTable: String = "scripts.moves.effects"
        const val naturesTableName: String = "data.pokemon.natures.names"
        const val overworldSprites: String = "graphics.overworld.sprites"
        const val ballSpritesTable: String = "graphics.items.ball.sprites"
        const val backSpritesTable: String = "graphics.pokemon.sprites.back"
        const val pokemonStatsTable: String = "data.pokemon.stats"
        const val abilityNamesTable: String = "data.abilities.names"
        const val eggMovesTableName: String = "data.pokemon.moves.egg"
        const val overworldPalettes: String = "graphics.overworld.palettes"
        const val ballPalettesTable: String = "graphics.items.ball.palettes"
        const val frontSpritesTable: String = "graphics.pokemon.sprites.front"
        const val contestTypesTable: String = "data.pokemon.type.contest.names"
        const val pokePalettesTable: String = "graphics.pokemon.palettes.normal"
        const val evolutionTableName: String = "data.pokemon.evolutions"
        const val typeChartTableName: String = "data.pokemon.type.chart"
        const val shinyPalettesTable: String = "graphics.pokemon.palettes.shiny"
        const val trainerSpritesName: String = "graphics.trainers.sprites.front"
        const val itemImagesTableName: String = "graphics.items.sprites"
        const val levelMovesTableName: String = "data.pokemon.moves.levelup"
        const val itemEffectsTableName: String = "data.items.effects"
        const val regionalDexTableName: String = "data.pokedex.regional"
        const val nationalDexTableName: String = "data.pokedex.national"
        const val decorationsTableName: String = "data.decorations.stats"
        const val multichoiceTableName: String = "scripts.text.multichoice"
        const val moveDescriptionsName: String = "data.pokemon.moves.descriptions"
        const val backupFontWidthTable: String = "graphics.text.font.default.width"
        const val pokeIconPalettesTable: String = "graphics.pokemon.icons.palettes"
        const val defaultSpriteNamespace: String = "graphics.new.sprite"
        const val trainerClassNamesTable: String = "data.trainers.classes.names"
        const val conversionDexTableName: String = "data.pokedex.hoennToNational"
        const val defaultTilemapNamespace: String = "graphics.new.tilemap"
        const val defaultPaletteNamespace: String = "graphics.new.palette"
        const val abilityDescriptionsTable: String = "data.abilities.descriptions"
        const val pokeIconPaletteIndexTable: String = "graphics.pokemon.icons.index"
        const val battleParticleSpriteTable: String = "graphics.moves.particles.sprites"
        const val battleParticlePaletteTable: String = "graphics.moves.particles.palettes"
        const val moveInfoListName: String = "moveinfo"
        const val moveEffectListName: String = "moveeffectoptions"
        const val moveTargetListName: String = "movetarget"
        const val evolutionMethodListName: String = "evolutionmethods"
        const val decorationsShapeListName: String = "decorshape"
        const val decorationsCategoryListName: String = "decorcategory"
        const val decorationsPermissionListName: String = "decorpermissions"
        const val ruby: String = "AXVE0"
        const val sapphire: String = "AXPE0"
        const val emerald: String = "BPEE0"
        const val fireRed: String = "BPRE0"
        const val leafGreen: String = "BPGE0"
        const val ruby1_1: String = "AXVE1"
        const val sapphire1_1: String = "AXPE1"
        const val fireRed1_1: String = "BPRE1"
        const val leafGreen1_1: String = "BPGE1"
        const val fireRedFr: String = "BPRF0"
        const val fireRedIt: String = "BPRI0"
        const val emeraldFr: String = "BPEF0"
        const val emeraldIt: String = "BPEI0"
        const val tmMoves: String = "data.pokemon.moves.tms"
        const val hmMoves: String = "data.pokemon.moves.hms"
        const val tmCompatibility: String = "data.pokemon.moves.tmcompatibility"
        const val moveTutors: String = "data.pokemon.moves.tutors"
        const val tutorCompatibility: String = "data.pokemon.moves.tutorcompatibility"
        val cfruIgnoreTables: List<String> = /*@INITDONE HardcodeTablesModel.CfruIgnoreTables cs:297-302*/ 
            listOf(
                "graphics.pokemon.sprites.coordinates.front",
                "data.pokedex.hoennToNational",        // causes problems with pokename count
                "graphics.pokemon.sprites.anchor",     // causes problems with pokename count
                "data.pokedex.search.alpha"            // causes problems with shiny palettes
            ) /*@ENDINIT*/
        fun decodeConstantsFromReference(model: ByteList, info: IMetadataInfo, metadata: StoredMetadata?, constants: GameReferenceConstants): StoredMetadata? { /*@DONE HardcodeTablesModel.DecodeConstantsFromReference/1 cs:389-410*/
            if (metadata == null) return metadata
            val words = ArrayList<StoredMatchedWord>(metadata.matchedWords)
            val constantSet = LinkedHashMap<String, MutableList<StoredMatchedWord>>()
            for (constant in constants.flatMap { c -> c.toStoredMatchedWords() }) {
                if (!constantSet.containsKey(constant.name)) constantSet[constant.name] = ArrayList<StoredMatchedWord>()
                constantSet[constant.name]!!.add(constant)
            }
            for (constant in constantSet.values) {
                if (constant.any { c -> c.address + c.length > model.count }) continue
                val virtualValues = constant.map { c -> (model.readMultiByteValue(c.address, c.length) - c.addOffset) / c.multOffset }
                val match = virtualValues.all { vv -> vv == virtualValues[0] }
                if (match) words.addAll(constant)
            }
            val fields = StoredMetadataFields()
            fields.freeSpaceSearch = metadata.freeSpaceSearch
            fields.freeSpaceBuffer = metadata.freeSpaceBuffer
            fields.nextExportID = metadata.nextExportID
            fields.showRawIVByteForTrainer = metadata.showRawIVByteForTrainer
            return StoredMetadata(metadata.namedAnchors, metadata.unmappedPointers, words, metadata.offsetPointers, metadata.lists, metadata.unmappedConstants, metadata.gotoShortcuts, info, fields)
        }
        private const val cfru_Check_Address: Int = 0x00051A
        private const val cfru_Check_Value: Int = 0x46C0
        private const val cfru_ValueRepeateCount: Int = 5
        fun getIsCFRU(model: IDataModel): Boolean { /*@DONE HardcodeTablesModel.GetIsCFRU/1 cs:484-492*/
            val gameCode = model.getGameCode()
            if (gameCode != fireRed) return false
            if (model.rawData.size < cfru_Check_Address + 3) return false
            for (i in 0 until cfru_ValueRepeateCount) {
                if (model.readMultiByteValue(cfru_Check_Address + i * 2, 2) != cfru_Check_Value) return false
            }
            return true
        }
        /*@END HardcodeTablesModel.Companion*/
    }
    /*@END HardcodeTablesModel*/
}
