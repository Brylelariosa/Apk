// Port of ViewModels/Map/BlockMapViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.map.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*
import dev.hexmaniac.core.viewmodels.tools.*

data class ImageLocation(val x: Double, val y: Double) { // cs:18-18
    /*@END ImageLocation*/
}

open class BlockMapViewModel : ViewModelCore, IPixelViewModel { // cs:20-2813
    private lateinit var format: Format
    private lateinit var fileSystem: IFileSystem
    private lateinit var tutorials: MapTutorialsViewModel
    private lateinit var _viewPort: IEditableViewPort
    private lateinit var model: IDataModel
    private lateinit var eventTemplate: EventTemplate
    private lateinit var tokenFactory: () -> ModelDelta
    private var group: Int = 0
    private var map: Int = 0
    private var primaryTiles: Int = 0
        private set
    private var primaryBlocks: Int = 0
        private set
    private val totalBlocks: Int
        get() { /*@DONE BlockMapViewModel.TotalBlocks.get cs:32-32*/
            return 1024
        }
    private var primaryPalettes: Int = 0
        private set
    private var _zIndex: Int = 0
    var zIndex: Int
        get() { /*@DONE BlockMapViewModel.ZIndex.get cs:36-36*/
            return _zIndex
        }
        set(value) { /*@DONE BlockMapViewModel.ZIndex.set cs:36-36*/
            set(_zIndex, value, "zIndex", { _zIndex = it })
        }
    val requestClearMapCaches = Event<EventArgs>()
    val viewPort: IEditableViewPort
        get() { /*@DONE BlockMapViewModel.ViewPort.get cs:40-40*/
            return _viewPort
        }
    private var _selectedEvent: IEventViewModel? = null
    var selectedEvent: IEventViewModel?
        get() { /*@DONE BlockMapViewModel.SelectedEvent.get cs:46-46*/
            return _selectedEvent
        }
        set(value) { /*@DONE BlockMapViewModel.SelectedEvent.set cs:47-52*/
            val oldValue = _selectedEvent
            _selectedEvent = value
            notifyPropertyChanged("selectedEvent")
            handleSelectedEventChanged(oldValue)
        }
    var eventSelectors: ObservableCollection<EventSelector> = /*@INITDONE BlockMapViewModel.EventSelectors cs:55-55*/ ObservableCollection() /*@ENDINIT*/
        private set
    private fun handleSelectedEventChanged(old: IEventViewModel?) { /*@DONE BlockMapViewModel.HandleSelectedEventChanged/1 cs:57-83*/
        val current = _selectedEvent
        if (old === current) return
        if (old != null) {
            old.eventVisualUpdated -= refreshFromEventChangeHandler
            old.cycleEvent -= cycleActiveEventHandler
        }
        if (current != null) {
            current.eventVisualUpdated += refreshFromEventChangeHandler
            current.cycleEvent += cycleActiveEventHandler
        }
        redrawEvents()

        eventSelectors.clear()
        if (current != null) {
            val parts = current.eventIndex.split("/")
            val index = (parts[0].trim().toIntOrNull() ?: 1) - 1
            val count = if (parts.size > 1) (parts[1].trim().toIntOrNull() ?: 0) else 0
            for (i in 0 until count) {
                val selector = EventSelector()
                selector.isSelected = i == index
                selector.index = i
                selector.bind("isSelected") { sender, _ ->
                    val selected = _selectedEvent
                    if (selected != null) {
                        val events = getEvents().filter { ev -> ev.javaClass == selected.javaClass }
                        if (sender.index >= 0 && sender.index < events.size) selectedEvent = events[sender.index]
                    }
                }
                eventSelectors.add(selector)
            }
        }
    }
    private fun refreshFromEventChange(sender: Any?, e: EventArgs) { /*@DONE BlockMapViewModel.RefreshFromEventChange/1 cs:85-85*/
        redrawEvents()
    }
    private fun cycleActiveEvent(sender: Any?, direction: EventCycleDirection) { /*@DONE BlockMapViewModel.CycleActiveEvent/1 cs:87-143*/
        // organize events into categories
        val events = getEvents()
        val categories = ArrayList<MutableList<IEventViewModel>>()
        for (i in 0 until 5) categories.add(ArrayList())
        var selectionIndex = -1
        var selectedCategory = -1
        for (i in events.indices) {
            val currentCategory =
                if (events[i] is ObjectEventViewModel) 0
                else if (events[i] is WarpEventViewModel) 1
                else if (events[i] is ScriptEventViewModel) 2
                else if (events[i] is SignpostEventViewModel) 3
                else if (events[i] is FlyEventViewModel) 4
                else -1
            if (currentCategory < 0) continue
            categories[currentCategory].add(events[i])

            if (events[i] == _selectedEvent) {
                selectionIndex = categories[currentCategory].size - 1
                selectedCategory = currentCategory
            }
        }

        // remove unused categories
        var c = 0
        while (c < categories.size) {
            if (categories[c].size != 0) { c++; continue }
            categories.removeAt(c)
            if (selectedCategory > c) selectedCategory--
        }

        // cycle
        if (direction == EventCycleDirection.PreviousCategory) {
            selectedCategory += categories.size - 1
            selectionIndex = 0
        } else if (direction == EventCycleDirection.NextCategory) {
            selectedCategory += 1
            selectionIndex = 0
        } else if (direction == EventCycleDirection.PreviousEvent) {
            if (selectedCategory >= 0 && selectedCategory < categories.size) selectionIndex += categories[selectedCategory].size - 1
        } else if (direction == EventCycleDirection.NextEvent) {
            selectionIndex += 1
        } else if (direction == EventCycleDirection.None) {
            // we just wanted to regenerate the event object
        }
        if (selectedCategory < 0 || categories.isEmpty()) {
            selectedEvent = null
            return
        }
        selectedCategory %= categories.size
        selectionIndex %= categories[selectedCategory].size
        if (selectionIndex < 0) selectionIndex = 0

        // update selection
        selectedEvent = categories[selectedCategory][selectionIndex]
        tutorials.complete(Tutorial.EventButtons_CycleEvent)
    }
    val mapID: Int
        get() { /*@DONE BlockMapViewModel.MapID.get cs:150-150*/
            return group * 1000 + map
        }
    private var _header: MapHeaderViewModel? = null
    val header: MapHeaderViewModel
        get() { /*@DONE BlockMapViewModel.Header.get cs:154-161*/
            if (_header == null) {
                val created = MapHeaderViewModel(getMapModel(), format, tokenFactory)
                _header = created
                created.bind("primaryIndex") { _, _ -> clearCaches() }
                created.bind("secondaryIndex") { _, _ -> clearCaches() }
            }
            return _header!!
        }
    val isValidMap: Boolean
        get() { /*@DONE BlockMapViewModel.IsValidMap.get cs:164-164*/
            return getMapModel() != null
        }
    private var _transparent: Short = 0.toShort()
    override var transparent: Short
        get() { /*@DONE BlockMapViewModel.Transparent.get cs:169-169*/
            return _transparent
        }
        set(value) { /*@DONE BlockMapViewModel.Transparent.set cs:169-169*/
            set(_transparent, value, "transparent", { _transparent = it })
        }
    private var _pixelWidth: Int = 0
    private var _pixelHeight: Int = 0
    override var pixelWidth: Int
        get() { /*@DONE BlockMapViewModel.PixelWidth.get cs:172-172*/
            return _pixelWidth
        }
        set(value) { /*@DONE BlockMapViewModel.PixelWidth.set cs:172-172*/
            set(_pixelWidth, value, "pixelWidth", { _pixelWidth = it })
        }
    override var pixelHeight: Int
        get() { /*@DONE BlockMapViewModel.PixelHeight.get cs:173-173*/
            return _pixelHeight
        }
        set(value) { /*@DONE BlockMapViewModel.PixelHeight.set cs:173-173*/
            set(_pixelHeight, value, "pixelHeight", { _pixelHeight = it })
        }
    private val pixelWriteLock: Any = /*@INITDONE BlockMapViewModel.pixelWriteLock cs:175-175*/ Any() /*@ENDINIT*/
    private var _pixelData: ShortArray? = null
    override val pixelData: ShortArray
        get() { /*@DONE BlockMapViewModel.PixelData.get cs:178-183*/
            synchronized(pixelWriteLock) {
                if (_pixelData == null) fillMapPixelData()
                return _pixelData ?: ShortArray(0)
            }
        }
    private var _spriteScale: Double = /*@INITAUTO BlockMapViewModel.spriteScale cs:186-186*/ 1.0 /*@ENDINIT*/
    override var spriteScale: Double
        get() { /*@DONE BlockMapViewModel.SpriteScale.get cs:188-188*/
            return _spriteScale
        }
        set(value) { /*@DONE BlockMapViewModel.SpriteScale.set cs:189-189*/
            set(_spriteScale, value, "spriteScale", { _spriteScale = it }) { old -> updateEdgesFromScale(old, old * _pixelWidth / 2, old * _pixelHeight / 2) }
        }
    private fun updateEdgesFromScale(old: Double, centerX: Double, centerY: Double) { /*@DONE BlockMapViewModel.UpdateEdgesFromScale/1 cs:192-195*/
        leftEdge += (centerX * (1 - spriteScale / old)).toInt()
        topEdge += (centerY * (1 - spriteScale / old)).toInt()
    }
    private var _isSelected: Boolean = false
    var isSelected: Boolean
        get() { /*@DONE BlockMapViewModel.IsSelected.get cs:203-203*/
            return _isSelected
        }
        set(value) { /*@DONE BlockMapViewModel.IsSelected.set cs:204-204*/
            set(_isSelected, value, "isSelected", { _isSelected = it }) { _ -> clearPixelCache() }
        }
    private var _topEdge: Int = 0
    private var _leftEdge: Int = 0
    var topEdge: Int
        get() { /*@DONE BlockMapViewModel.TopEdge.get cs:212-212*/
            return _topEdge
        }
        set(value) { /*@DONE BlockMapViewModel.TopEdge.set cs:212-212*/
            set(_topEdge, value, "topEdge", { _topEdge = it })
        }
    var leftEdge: Int
        get() { /*@DONE BlockMapViewModel.LeftEdge.get cs:213-213*/
            return _leftEdge
        }
        set(value) { /*@DONE BlockMapViewModel.LeftEdge.set cs:213-213*/
            set(_leftEdge, value, "leftEdge", { _leftEdge = it })
        }
    val bottomEdge: Int
        get() { /*@DONE BlockMapViewModel.BottomEdge.get cs:215-215*/
            return _topEdge + (pixelHeight * spriteScale).toInt()
        }
    val rightEdge: Int
        get() { /*@DONE BlockMapViewModel.RightEdge.get cs:216-216*/
            return _leftEdge + (pixelWidth * spriteScale).toInt()
        }
    private var _hoverPoint: ImageLocation = /*@INITDONE BlockMapViewModel.hoverPoint cs:218-218*/ ImageLocation(0.0, 0.0) /*@ENDINIT*/
    var hoverPoint: ImageLocation
        get() { /*@DONE BlockMapViewModel.HoverPoint.get cs:220-220*/
            return _hoverPoint
        }
        set(value) { /*@DONE BlockMapViewModel.HoverPoint.set cs:221-224*/
            _hoverPoint = value
            notifyPropertyChanged("hoverPoint")
        }
    val widthRatio: Double
        get() { /*@DONE BlockMapViewModel.WidthRatio.get cs:227-227*/
            return 80.0 / pixelWidth / Math.min(1.0, spriteScale)
        }
    val heightRatio: Double
        get() { /*@DONE BlockMapViewModel.HeightRatio.get cs:228-228*/
            return 80.0 / pixelHeight / Math.min(1.0, spriteScale)
        }
    private var _showBeneath: Boolean = false
    var showBeneath: Boolean
        get() { /*@DONE BlockMapViewModel.ShowBeneath.get cs:231-231*/
            return _showBeneath
        }
        set(value) { /*@DONE BlockMapViewModel.ShowBeneath.set cs:231-234*/
            set(_showBeneath, value, "showBeneath", { _showBeneath = it }) { _ ->
                notifyPropertiesChanged("widthRatio", "heightRatio")
                tutorials.complete(Tutorial.SpaceBar_ShowBeneath)
            }
        }
    private var _showEvents: MapDisplayOptions = MapDisplayOptions.AllEvents
    var showEvents: MapDisplayOptions
        get() { /*@DONE BlockMapViewModel.ShowEvents.get cs:238-238*/
            return _showEvents
        }
        set(value) { /*@DONE BlockMapViewModel.ShowEvents.set cs:238-238*/
            set(_showEvents, value, "showEvents", { _showEvents = it }) { _ -> clearPixelCache() }
        }
    private var _blockPixels: IPixelViewModel? = null
    val blockPixels: IPixelViewModel
        get() { /*@DONE BlockMapViewModel.BlockPixels.get cs:246-249*/
            if (_blockPixels == null) fillBlockPixelData()
            return _blockPixels ?: ReadonlyPixelViewModel(1, 1, ShortArray(1), 0.toShort())
        }
    private var _collisionHighlight: Int = /*@INITAUTO BlockMapViewModel.collisionHighlight cs:256-256*/ -1 /*@ENDINIT*/
    var collisionHighlight: Int
        get() { /*@DONE BlockMapViewModel.CollisionHighlight.get cs:258-258*/
            return _collisionHighlight
        }
        set(value) { /*@DONE BlockMapViewModel.CollisionHighlight.set cs:259-261*/
            set(_collisionHighlight, value, "collisionHighlight", { _collisionHighlight = it }) { _ -> clearPixelCache() }
        }
    private var palettes: Array<ShortArray>? = null
    private var tiles: Array<Array<IntArray>?>? = null
    private var blocks: Array<ByteArray>? = null
    private var blockAttributes: Array<ByteArray>? = null
    private val _blockRenders: MutableList<IPixelViewModel> = /*@INITDONE BlockMapViewModel.blockRenders cs:272-272*/ ArrayList() /*@ENDINIT*/
    private var eventRenders: List<IEventViewModel>? = null
    val blockRenders: List<IPixelViewModel>
        get() { /*@DONE BlockMapViewModel.BlockRenders.get cs:275-280*/
            synchronized(_blockRenders) {
                if (_blockRenders.size == 0) refreshBlockRenderCache()
            }
            return _blockRenders
        }
    private fun clearPixelCache() { /*@DONE BlockMapViewModel.ClearPixelCache/1 cs:283-288*/
        synchronized(pixelWriteLock) {
            _pixelData = null
            notifyPropertyChanged("pixelData")
        }
    }
    private var _includeBorders: Boolean = /*@INITAUTO BlockMapViewModel.includeBorders cs:294-294*/ true /*@ENDINIT*/
    var includeBorders: Boolean
        get() { /*@DONE BlockMapViewModel.IncludeBorders.get cs:296-296*/
            return _includeBorders
        }
        set(value) { /*@DONE BlockMapViewModel.IncludeBorders.set cs:297-297*/
            set(_includeBorders, value, "includeBorders", { _includeBorders = it }) { old -> includeBordersChanged(old) }
        }
    private fun includeBordersChanged(oldValue: Boolean) { /*@DONE BlockMapViewModel.IncludeBordersChanged/1 cs:299-305*/
        val width = pixelWidth
        val height = pixelHeight
        refreshMapSize()
        leftEdge -= (pixelWidth - width) / 2
        topEdge -= (pixelHeight - height) / 2
    }
    private var _borderBlock: IPixelViewModel? = null
    var borderBlock: IPixelViewModel
        get() { /*@DONE BlockMapViewModel.BorderBlock.get cs:309-312*/
            if (_borderBlock == null) refreshBorderRender()
            return _borderBlock ?: refreshBorderRender()
        }
        set(value) { /*@DONE BlockMapViewModel.BorderBlock.set cs:313-316*/
            _borderBlock = value
            notifyPropertyChanged("borderBlock")
        }
    val fullName: String?
        get() { /*@DONE BlockMapViewModel.FullName.get cs:323-323*/
            return mapIDToText(model, mapID)
        }
    val name: String
        get() { /*@DONE BlockMapViewModel.Name.get cs:324-324*/
            return "(" + group + "-" + map + ")"
        }
    private var _availableNames: ObservableCollection<String>? = null
    val availableNames: ObservableCollection<String>
        get() { /*@DONE BlockMapViewModel.AvailableNames.get cs:328-335*/
            val existing = _availableNames
            if (existing != null) return existing
            val result = ObservableCollection<String>()
            _availableNames = result
            for (name in model.getOptions(HardcodeTablesModel.mapNameTable)) {
                result.add(sanitizeName(name.trim('"')))
            }
            return result
        }
    private var _sortedAvailableNames: ObservableCollection<String>? = null
    val sortedAvailableNames: ObservableCollection<String>
        get() { /*@DONE BlockMapViewModel.SortedAvailableNames.get cs:339-343*/
            val existing = _sortedAvailableNames
            if (existing != null) return existing
            val result = ObservableCollection(availableNames.sortedWith(String.CASE_INSENSITIVE_ORDER))
            _sortedAvailableNames = result
            return result
        }
    var selectedNameIndex: Int
        get() { /*@DONE BlockMapViewModel.SelectedNameIndex.get cs:347-358*/
            val offset = if (model.isFRLG()) 0x58 else 0
            val banks = model.getTableModel(HardcodeTablesModel.mapBankTable) ?: return -1
            if (group < 0 || group >= banks.size) return -1
            val maps = banks[group].getSubTable("maps") ?: return -1
            if (map < 0 || map >= maps.size) return -1
            val subTable = maps[map].getSubTable("map") ?: return -1
            val self = subTable[0]
            if (!self.hasField("regionSectionID")) return -1
            return self.getValue("regionSectionID") - offset
        }
        set(value) { /*@DONE BlockMapViewModel.SelectedNameIndex.set cs:359-371*/
            val offset = if (model.isFRLG()) 0x58 else 0
            val banks = model.getTableModel(HardcodeTablesModel.mapBankTable, tokenFactory) ?: return
            if (group < 0 || group >= banks.size) return
            val maps = banks[group].getSubTable("maps") ?: return
            if (map < 0 || map >= maps.size) return
            val subTable = maps[map].getSubTable("map") ?: return
            val self = subTable[0]
            if (!self.hasField("regionSectionID")) return
            self.setValue("regionSectionID", value + offset)
            notifyPropertyChanged("fullName")
        }
    var gotoNameIndex: Int
        get() { /*@DONE BlockMapViewModel.GotoNameIndex.get cs:375-375*/
            val selected = selectedNameIndex
            if (selected < 0 || selected >= availableNames.size) return -1
            return sortedAvailableNames.indexOf(availableNames[selected])
        }
        set(value) { /*@DONE BlockMapViewModel.GotoNameIndex.set cs:376-388*/
            if (value < 0 || value >= sortedAvailableNames.size) return
            var name = sortedAvailableNames[value]
            // find the first map with that name
            val tableIndex = availableNames.indexOf(name)
            var mapWithName: MapModel? = null
            for (bank in AllMapsModel.create(model)) {
                for (candidate in bank) {
                    if (candidate.nameIndex == tableIndex) { mapWithName = candidate; break }
                }
                if (mapWithName != null) break
            }
            if (mapWithName == null) {
                viewPort.raiseError("Could not find a map named " + name)
            } else {
                name = mapIDToText(model, mapWithName.group, mapWithName.map)
                viewPort.goto?.execute("maps.bank" + mapWithName.group + "." + name)
            }
        }
    val blockMapIsShared: Boolean
        get() { /*@DONE BlockMapViewModel.BlockMapIsShared.get cs:399-399*/
            return (findLayoutUses()?.size ?: 0) > 1
        }
    val blockMapShareCount: Int
        get() { /*@DONE BlockMapViewModel.BlockMapShareCount.get cs:401-401*/
            return findLayoutUses()?.size ?: 0
        }
    val blockMapUses: ObservableCollection<JumpMapInfo>
        get() { /*@DONE BlockMapViewModel.BlockMapUses.get cs:403-403*/
            return findLayoutUses() ?: ObservableCollection()
        }
    private var layoutUseCache: ObservableCollection<JumpMapInfo>? = null
    private fun findLayoutUses(): ObservableCollection<JumpMapInfo>? { /*@DONE BlockMapViewModel.FindLayoutUses/1 cs:406-424*/
        val cached = layoutUseCache
        if (cached != null) return cached
        val mapElement = getMapModel()
        val layout = getLayout(mapElement) ?: return null
        val modelRun = model.getNextRun(layout.start) ?: return null
        if (modelRun.start != layout.start) return null
        val uses = ObservableCollection<JumpMapInfo>()
        val names = model.getOptions(HardcodeTablesModel.mapNameTable)

        for (candidate in getAllMaps()) {
            val candidateElement = candidate.element ?: continue
            if (modelRun.pointerSources?.contains(candidateElement.start) != true) continue
            val nameIndex = candidate.nameIndex
            val name = if (nameIndex >= 0 && nameIndex < names.size) names[nameIndex] else "unknown"
            uses.add(JumpMapInfo(candidate.group, candidate.map, name) { args -> requestChangeMap(this, args) })
        }

        layoutUseCache = uses
        return uses
    }
    val neighborsChanged = Event<EventArgs>()
    val autoscrollTiles = Event<EventArgs>()
    val hideSidePanels = Event<EventArgs>()
    val requestChangeMap = Event<ChangeMapEventArgs>()
    private var _blockEditor: BlockEditor? = null
    val blockEditor: BlockEditor?
        get() { /*@DONE BlockMapViewModel.BlockEditor.get cs:435-454*/
            val existing = _blockEditor
            if (existing != null) return existing
            val layout = getLayout() ?: return null
            val blockModel1 = BlocksetModel(model, layout.getAddress("blockdata1"))
            val blockModel2 = BlocksetModel(model, layout.getAddress("blockdata2"))
            if (palettes == null) refreshPaletteCache(layout, blockModel1, blockModel2)
            if (tiles == null) refreshTileCache(layout, blockModel1, blockModel2)
            if (blocks == null) refreshBlockCache(layout, blockModel1, blockModel2)
            if (blockAttributes == null) refreshBlockAttributeCache(layout, blockModel1, blockModel2)
            val editor = BlockEditor(viewPort.changeHistory, model, tutorials, palettes!!, tiles!!, blocks!!, blockAttributes!!)
            _blockEditor = editor
            editor.blocksChanged += blocksChangedHandler
            editor.blockAttributesChanged += blockAttributesChangedHandler
            editor.autoscrollTiles += autoscrollTilesHandler
            editor.sendMessage += { _, e -> viewPort.raiseMessage(e) }
            editor.bind("showTiles") { changed, _ -> borderEditor.showBorderPanel = borderEditor.showBorderPanel && !changed.showTiles }
            editor.bind("blockIndex") { _, _ ->
                lastDrawX = -1
                lastDrawY = -1
                clearPixelCache()
            }
            return editor
        }
    private var _borderEditor: BorderEditor? = null
    val borderEditor: BorderEditor
        get() { /*@DONE BlockMapViewModel.BorderEditor.get cs:459-470*/
            val existing = _borderEditor
            if (existing != null) return existing
            val editor = BorderEditor(this, tutorials)
            _borderEditor = editor
            editor.borderChanged += borderChangedHandler
            editor.bind("showBorderPanel") { changed, _ ->
                val blockEd = blockEditor
                if (blockEd != null) {
                    blockEd.showTiles = blockEd.showTiles && !changed.showBorderPanel
                    hideSidePanels(this, EventArgs.empty)
                }
            }
            return editor
        }
    private lateinit var _mapRepointer: MapRepointer
    val mapRepointer: MapRepointer
        get() { /*@DONE BlockMapViewModel.MapRepointer.get cs:474-474*/
            return _mapRepointer
        }
    private lateinit var _mapScriptCollection: MapScriptCollection
    val mapScriptCollection: MapScriptCollection
        get() { /*@DONE BlockMapViewModel.MapScriptCollection.get cs:478-484*/
            if (_mapScriptCollection.unloaded) {
                val mapElement = getMapModel()
                _mapScriptCollection.load(mapElement)
            }
            return _mapScriptCollection
        }
    private var _wildPokemon: WildPokemonViewModel? = null
    val wildPokemon: WildPokemonViewModel
        get() { /*@DONE BlockMapViewModel.WildPokemon.get cs:489-492*/
            if (_wildPokemon == null) _wildPokemon = WildPokemonViewModel(viewPort, tutorials, group, map)
            return _wildPokemon!!
        }
    private var _surfConnection: SurfConnectionViewModel? = null
    val surfConnection: SurfConnectionViewModel
        get() { /*@DONE BlockMapViewModel.SurfConnection.get cs:497-510*/
            val existing = _surfConnection
            if (existing != null) return existing
            val created = SurfConnectionViewModel(viewPort, group, map)
            _surfConnection = created
            created.requestChangeMap += { _, e -> requestChangeMap(this, e) }
            created.connectNewMap += { _, e -> connectNewMap(e) }
            created.connectExistingMap += { _, e -> connectExistingMap(e) }
            created.requestRemoveConnection += { _, _ ->
                val connections = AllMapsModel.create(model, tokenFactory)[group]?.get(map)?.connections ?: ArrayList<ConnectionModel>()
                val toRemove = ArrayList<Int>()
                for (i in connections.indices) {
                    if (connections[i].direction.isAny(MapDirection.Dive, MapDirection.Emerge)) toRemove.add(i)
                }
                removeConnections(toRemove)
            }
            return created
        }
    constructor(fileSystem: IFileSystem, tutorials: MapTutorialsViewModel, viewPort: IEditableViewPort, format: Format, eventTemplate: EventTemplate, group: Int, map: Int) { /*@DONE BlockMapViewModel.<init>/1 cs:513-545*/
        this.format = format
        this.fileSystem = fileSystem
        this.tutorials = tutorials
        this._viewPort = viewPort
        this.model = viewPort.model!!
        this.eventTemplate = eventTemplate
        this.tokenFactory = { viewPort.changeHistory.currentChange }
        this.group = group
        this.map = map
        transparent = (-1).toShort()
        val mapModel = getMapModel()
        refreshMapSize()
        primaryTiles = if (this.model.isFRLG()) 640 else 512
        primaryBlocks = primaryTiles
        primaryPalettes = if (this.model.isFRLG()) 7 else 6

        leftEdge = -pixelWidth / 2
        topEdge = -pixelHeight / 2

        _mapScriptCollection = MapScriptCollection(viewPort, eventTemplate)
        _mapScriptCollection.newMapScriptsCreated += { _, e -> getMapModel()?.setAddress("mapscripts", e.address) }

        _mapRepointer = MapRepointer(format, fileSystem, viewPort, viewPort.changeHistory, mapID) {
            header.refresh()
            layoutUseCache = null // invalidate the cache during a refresh
            notifyPropertiesChanged("blockMapShareCount", "blockMapUses", "blockMapIsShared")
        }
        _mapRepointer.changeMap += { _, e -> requestChangeMap(this, e) }
        _mapRepointer.dataMoved += { _, e ->
            clearCaches()
            if (e != null) {
                informRepoint(e)
                if (e.type == "Layout") updateLayoutID()
            }
        }
    }
    private var _berryInfo: BerryInfo? = null
    var berryInfo: BerryInfo
        get() { /*@DONE BlockMapViewModel.BerryInfo.get cs:549-552*/
            val existing = _berryInfo
            if (existing != null) return existing
            val created = setupBerryInfo()
            _berryInfo = created
            return created
        }
        set(value) { /*@DONE BlockMapViewModel.BerryInfo.set cs:553-556*/
            _berryInfo = value
            notifyPropertyChanged("berryInfo")
        }
    private fun setupBerryInfo(): BerryInfo { /*@DONE BlockMapViewModel.SetupBerryInfo/1 cs:559-566*/
        val collection = ObservableCollection<String>()
        var options: List<String> = model.getOptions(HardcodeTablesModel.berryTableName)
        if (options.isEmpty()) options = (0 until 100).map { i -> i.toString() }
        for (option in options) collection.add(option)
        val spots = Flags.getBerrySpots(model, viewPort.tools!!.codeTool!!.scriptParser)
        return BerryInfo(spots, collection)
    }
    fun informRepoint(e: DataMovedEventArgs) { /*@DONE BlockMapViewModel.InformRepoint/1 cs:568-570*/
        viewPort.raiseMessage(e.type + " data was moved to " + e.address.toHex(6) + ".")
    }
    fun informCreate(e: DataMovedEventArgs) { /*@DONE BlockMapViewModel.InformCreate/1 cs:572-574*/
        viewPort.raiseMessage(e.type + " data was created at " + e.address.toHex(6) + ".")
    }
    fun getNeighbors(direction: MapDirection): List<BlockMapViewModel> { /*@DONE BlockMapViewModel.GetNeighbors/1 cs:576-588*/
        val list = ArrayList<BlockMapViewModel>()
        val border = getBorderThickness() ?: return list
        val connections = getConnections() ?: return list
        for (connection in connections) {
            if (connection.direction != direction) continue
            val vm = getNeighbor(connection, border)
            list.add(vm)
        }
        return list
    }
    fun updateFrom(other: BlockMapViewModel?): Boolean { /*@DONE BlockMapViewModel.UpdateFrom/1 cs:590-603*/
        if (other == null) return false
        if (other === this) return true
        if (other.mapID == mapID) {
            includeBorders = other.includeBorders
            spriteScale = other.spriteScale
            leftEdge = other.leftEdge
            topEdge = other.topEdge
            zIndex = other.zIndex
            isSelected = other.isSelected
            return true
        }
        return false
    }
    fun gotoData() { /*@DONE BlockMapViewModel.GotoData/1 cs:605-608*/
        val mapElement = getMapModel() ?: return
        viewPort.goto?.execute(mapElement.start)
    }
    fun clearCaches() { /*@DONE BlockMapViewModel.ClearCaches/1 cs:610-639*/
        palettes = null
        tiles = null
        blocks = null
        synchronized(_blockRenders) {
            _blockRenders.clear()
        }
        _blockPixels = null
        eventRenders = null
        _borderBlock = null
        _berryInfo = null
        wildPokemon.clearCache()
        dynamicOverworldSprites = null
        refreshMapSize(false)
        refreshBlockAttributeCache()
        val oldBorderEditor = _borderEditor
        if (oldBorderEditor != null) {
            val oldShowBorder = oldBorderEditor.showBorderPanel
            oldBorderEditor.borderChanged -= borderChangedHandler
            _borderEditor = null
            borderEditor.showBorderPanel = oldShowBorder
            oldBorderEditor.showBorderPanel = false
            notifyPropertyChanged("borderEditor")
        }
        header.updateFromModel()
        clearPixelCache()
        if (!mapScriptCollection.unloaded) mapScriptCollection.load(getMapModel())
        notifyPropertiesChanged("blockRenders", "blockPixels", "berryInfo")
        if (_selectedEvent != null) cycleActiveEvent(null, EventCycleDirection.None)
    }
    fun redrawEvents() { /*@DONE BlockMapViewModel.RedrawEvents/1 cs:641-645*/
        eventRenders = null
        notifyPropertyChanged("canCreateFlyEvent")
        clearPixelCache()
    }
    fun scale(x: Double, y: Double, enlarge: Boolean) { /*@DONE BlockMapViewModel.Scale/1 cs:647-661*/
        lastDrawX = -1
        lastDrawY = -1
        val old = _spriteScale

        if (enlarge && _spriteScale < 10) {
            if (_spriteScale < 1) _spriteScale *= 2
            else _spriteScale += 1
        } else if (!enlarge && _spriteScale > .1) {
            if (_spriteScale > 1) _spriteScale -= 1
            else _spriteScale /= 2
        }

        if (old != _spriteScale) updateEdgesFromScale(old, x - _leftEdge, y - _topEdge)
        notifyPropertyChanged("spriteScale")
    }
    fun createMapForWarp(warp: WarpEventViewModel): BlockMapViewModel? { /*@DONE BlockMapViewModel.CreateMapForWarp/1 cs:665-800*/
        // what bank should the new map go in?
        val option = mapRepointer.getMapBankForNewMap(
            "Maps are organized into banks. The game doesn't care, so you can use the banks however you like." +
            "\n" +
            "Which map bank do you want to use for the new map?")
        if (option == -1) return null
        val token = tokenFactory()
        val thisMap = MapModel(getMapModel())

        // give me this block
        val thisBlocks = thisMap.blocks
        val blockIndex = safeCell(thisBlocks, warp.x, warp.y)?.tile ?: 0

        // give me all maps that use this blockset
        val thisLayout = thisMap.layout ?: return null
        var borderBlockAddress = thisLayout.borderBlockAddress
        var primaryBlocksetAddress = thisLayout.primaryBlockset?.start ?: Pointer.null_
        var secondaryBlocksetAddress = thisLayout.secondaryBlockset?.start ?: Pointer.null_

        val maps = ArrayList<MapModel>()
        for (candidate in getAllMaps()) {
            val candidateLayout = candidate.layout
            if (candidateLayout?.primaryBlockset?.start != primaryBlocksetAddress && blockIndex < primaryBlocks) continue
            if (candidateLayout?.secondaryBlockset?.start != secondaryBlocksetAddress && blockIndex >= primaryBlocks) continue
            maps.add(candidate)
        }

        // give me all warps in those maps (except for this warp itself)
        // give me all warps that are on this tile
        val warps = ArrayList<WarpEventModel>()
        for (candidate in maps) {
            val candidateBlocks = candidate.blocks
            for (w in candidate.events.warps) {
                if (w.element!!.start == warp.element!!.start) continue
                if (safeCell(candidateBlocks, w.x, w.y)?.tile != blockIndex) continue
                warps.add(w)
            }
        }

        // give me maps that those warp to
        // give me all the primary/secondary blocksets for those maps
        // give me all the borders for those maps
        val prototypes = LinkedHashMap<LayoutPrototype, MutableList<WarpEventModel>>()
        for (w in warps) {
            val m = w.targetMap ?: continue
            val targetLayout = m.layout ?: continue
            val primary = targetLayout.primaryBlockset
            val secondary = targetLayout.secondaryBlockset
            val border = targetLayout.borderBlockAddress
            if (primary == null || secondary == null || border == Pointer.null_) continue
            val prototype = LayoutPrototype(primary.start, secondary.start, border)
            if (!prototypes.containsKey(prototype)) prototypes[prototype] = ArrayList()
            prototypes[prototype]!!.add(w)
        }

        val orderedPrototypes = ArrayList<LayoutPrototype>(prototypes.keys)
        var initialBlockmap = Array(9) { IntArray(9) }
        var warpIsBottomSquare = true

        if (orderedPrototypes.size > 1) {
            val initialBlockmaps = ArrayList<Array<IntArray>>()
            val warpIsBottomSquareForIndex = ArrayList<Boolean>()

            // for each prototype, create an image that represents what that map prototype would look like
            val images = ArrayList<VisualOption>()
            for (prototype in orderedPrototypes) {
                val targets = prototypes[prototype]!!
                val rendered = renderPrototype(targets)
                initialBlockmaps.add(rendered.second)
                warpIsBottomSquareForIndex.add(rendered.third)
                val targetMapName = mapIDToText(model, targets[0].bank, targets[0].map)
                val nameParts = targetMapName.splitLast('.')
                val targetLocation = nameParts[0]
                val targetName = nameParts[1]
                val visOption = VisualOption()
                visOption.index = orderedPrototypes.indexOf(prototype)
                visOption.option = "Like " + targetLocation
                visOption.shortDescription = targetName
                visOption.visual = rendered.first
                images.add(visOption)
            }

            // create one additional 'blank' prototype
            initialBlockmaps.add(Array(9) { IntArray(9) })
            val blank = LayoutPrototype(primaryBlocksetAddress, secondaryBlocksetAddress, borderBlockAddress)
            orderedPrototypes.add(blank)
            val blankRender = CanvasPixelViewModel(9 * 16, 9 * 16)
            blankRender.spriteScale = images[0].visual?.spriteScale ?: 1.0
            val blankVisOption = VisualOption()
            blankVisOption.index = orderedPrototypes.size - 1
            blankVisOption.option = "Blank"
            blankVisOption.shortDescription = "Use Current Blocksets"
            blankVisOption.visual = blankRender
            warpIsBottomSquareForIndex.add(true)
            images.add(blankVisOption)

            val choice = fileSystem.showOptions("Create New Map", "Start from which template?", null, *images.toTypedArray())
            if (choice < 0 || choice >= orderedPrototypes.size) return null
            val chosenPrototype = orderedPrototypes[choice]
            // use the most frequent primary/secondary blockset and border blocks
            primaryBlocksetAddress = chosenPrototype.primaryBlockset
            secondaryBlocksetAddress = chosenPrototype.secondaryBlockset
            borderBlockAddress = chosenPrototype.borderBlock
            initialBlockmap = initialBlockmaps[choice]
            warpIsBottomSquare = warpIsBottomSquareForIndex[choice]
        } else if (orderedPrototypes.size == 1) {
            // no dialog, just go with this one
            val chosenPrototype = orderedPrototypes[0]
            primaryBlocksetAddress = chosenPrototype.primaryBlockset
            secondaryBlocksetAddress = chosenPrototype.secondaryBlockset
            borderBlockAddress = chosenPrototype.borderBlock
            val rendered = renderPrototype(prototypes.values.first())
            initialBlockmap = rendered.second
            warpIsBottomSquare = rendered.third
        }

        // create a new 9x9 map
        val newMap = createNewMap(token, option, 9, 9)
        if (newMap == null) {
            if (model.getTable(HardcodeTablesModel.mapLayoutTable) == null) {
                viewPort.raiseError(MapRepointer.mapLayoutMissing)
            } else {
                viewPort.raiseError(MapRepointer.mapBankFullError)
            }
            return null
        }
        val newLayout = newMap.getLayout() ?: return null
        newLayout.setAddress(Format.borderBlock, borderBlockAddress)
        newLayout.setAddress(Format.primaryBlockset, primaryBlocksetAddress)
        newLayout.setAddress(Format.secondaryBlockset, secondaryBlocksetAddress)
        val start = newLayout.getAddress(Format.blockMap)
        for (x in 0 until 9) {
            for (y in 0 until 9) {
                model.writeMultiByteValue(start + (y * 9 + x) * 2, 2, token, initialBlockmap[x][y])
            }
        }

        // place reverse warp at bottom heading back
        warp.bank = newMap.group
        warp.map = newMap.map
        warp.warpID = 1
        val returnWarp = newMap.createWarpEvent(group, map)
        if (returnWarp != null) {
            returnWarp.warpID = warp.element!!.arrayIndex + 1
            returnWarp.x = 4
            returnWarp.y = 8
            if (!warpIsBottomSquare) {
                returnWarp.x = 4
                returnWarp.y = 7
            }
        }

        // repoint border block
        newMap.mapRepointer.repointBorderBlock.execute()

        return newMap
    }
    fun updateClone(neighbor: BlockMapViewModel?, parentEvent: ObjectEventViewModel?, deleted: Boolean = false) { /*@DONE BlockMapViewModel.UpdateClone/1 cs:802-834*/
        if (!model.isFRLG() || neighbor == null || parentEvent == null) return
        val parentNumber = parentEvent.element!!.arrayIndex + 1
        var obj: ObjectEventViewModel? = eventGroup?.objects?.firstOrNull { candidate ->
            candidate.kind && candidate.elevation == parentNumber && candidate.trainerType == neighbor.map && candidate.trainerRangeOrBerryID == neighbor.group
        }
        val thisXY = convertCoordinates(0.0, 0.0)
        val thatXY = neighbor.convertCoordinates(0.0, 0.0)
        val xDif = thisXY.first - thatXY.first
        val yDif = thisXY.second - thatXY.second
        val desiredX = parentEvent.x + xDif
        val desiredY = parentEvent.y + yDif
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        var needClone = desiredX >= -8 && desiredY >= -8 && desiredX < width + 8 && desiredY < height + 8
        if (deleted) needClone = false
        if (obj == null && needClone) {
            val created = createObjectEvent(parentEvent.graphics, Pointer.null_) ?: return
            created.kind = true
            created.elevation = parentNumber
            created.trainerType = neighbor.map
            created.trainerRangeOrBerryID = neighbor.group
            created.flag = parentEvent.flag
            viewPort.raiseMessage("Clone added to map (" + this.group + "-" + this.map + ") for object " + parentNumber + ".")
            obj = created
        } else if (!needClone) {
            if (obj != null) {
                obj.delete()
                clearCaches()
                viewPort.raiseMessage("Clone removed from map (" + this.group + "-" + this.map + ") for object " + parentNumber + ".")
            }
            return
        }

        val target = obj ?: return
        target.x = desiredX
        target.y = desiredY
        clearCaches()
    }
    private fun renderPrototype(warps: MutableList<WarpEventModel>): Triple<IPixelViewModel, Array<IntArray>, Boolean> { /*@DONE BlockMapViewModel.RenderPrototype/1 cs:838-915*/
        // TODO I don't just want to return an image, I want to return the tiles/collisions to use as well
        val layouts = warps.mapNotNull { warp -> warp.targetMap?.layout }
        fun blockAt(layout: LayoutModel, x: Int, y: Int): Int = safeCell(layout.blockMap, x, y)?.block ?: 0

        // find the edge tiles
        val topTile = mostCommonOrZero(layouts.flatMap { layout -> (0 until layout.width - 2).map { x -> blockAt(layout, x + 1, 0) } })
        val bottomTile = mostCommonOrZero(layouts.flatMap { layout -> (0 until layout.width - 2).map { x -> blockAt(layout, x + 1, layout.height - 1) } })
        val leftTile = mostCommonOrZero(layouts.flatMap { layout -> (0 until layout.height - 2).map { y -> blockAt(layout, 0, y + 1) } })
        val rightTile = mostCommonOrZero(layouts.flatMap { layout -> (0 until layout.height - 2).map { y -> blockAt(layout, layout.width - 1, y + 1) } })
        val topLeftTile = mostCommonOrZero(layouts.map { layout -> blockAt(layout, 0, 0) })
        val topRightTile = mostCommonOrZero(layouts.map { layout -> blockAt(layout, layout.width - 1, 0) })
        val bottomLeftTile = mostCommonOrZero(layouts.map { layout -> blockAt(layout, 0, layout.height - 1) })
        val bottomRightTile = mostCommonOrZero(layouts.map { layout -> blockAt(layout, layout.width - 1, layout.height - 1) })

        // find the floor tile
        val centerTiles = ArrayList<Int>()
        for (layout in layouts) {
            for (x in 1 until layout.width - 1) {
                for (y in 1 until layout.height - 1) {
                    centerTiles.add(blockAt(layout, x, y))
                }
            }
        }
        val floorTile = mostCommonOrZero(centerTiles)

        // build the map image data
        val blockMap = Array(9) { IntArray(9) }
        for (i in 1 until 8) {
            blockMap[0][i] = leftTile
            blockMap[8][i] = rightTile
            blockMap[i][0] = topTile
            blockMap[i][8] = bottomTile
            for (j in 1 until 8) blockMap[i][j] = floorTile
        }
        blockMap[0][0] = topLeftTile
        blockMap[8][0] = topRightTile
        blockMap[0][8] = bottomLeftTile
        blockMap[8][8] = bottomRightTile

        // find the door tile
        var warpIsAgainstWall = true
        if (warps.size > 0) {
            val map0 = warps[0].targetMap
            if (map0 != null) {
                val mapWarps = map0.events.warps
                val map0Blocks = map0.blocks
                if (mapWarps.size > warps[0].warpID && warps[0].warpID >= 0) {
                    val matchingWarp0 = mapWarps[warps[0].warpID]
                    warpIsAgainstWall = matchingWarp0.y == (map0.layout?.height ?: 0) - 1
                    val mx = matchingWarp0.x
                    val my = matchingWarp0.y
                    if (warpIsAgainstWall) {
                        blockMap[3][7] = safeCell(map0Blocks, mx - 1, my - 1)?.block ?: 0
                        blockMap[4][7] = safeCell(map0Blocks, mx, my - 1)?.block ?: 0
                        blockMap[5][7] = safeCell(map0Blocks, mx + 1, my - 1)?.block ?: 0

                        blockMap[3][8] = safeCell(map0Blocks, mx - 1, my)?.block ?: 0
                        blockMap[4][8] = safeCell(map0Blocks, mx, my)?.block ?: 0
                        blockMap[5][8] = safeCell(map0Blocks, mx + 1, my)?.block ?: 0
                    } else {
                        blockMap[3][7] = safeCell(map0Blocks, mx - 1, my)?.block ?: 0
                        blockMap[4][7] = safeCell(map0Blocks, mx, my)?.block ?: 0
                        blockMap[5][7] = safeCell(map0Blocks, mx + 1, my)?.block ?: 0

                        blockMap[3][8] = safeCell(map0Blocks, mx - 1, my + 1)?.block ?: 0
                        blockMap[4][8] = safeCell(map0Blocks, mx, my + 1)?.block ?: 0
                        blockMap[5][8] = safeCell(map0Blocks, mx + 1, my + 1)?.block ?: 0
                    }
                }
            }
        }

        // draw the map
        val viewModel = BlockMapViewModel(fileSystem, tutorials, _viewPort, format, eventTemplate, warps[0].bank, warps[0].map)
        viewModel.berryInfo = berryInfo
        val canvas = CanvasPixelViewModel(9 * 16, 9 * 16)
        val viewModelRenders = viewModel.blockRenders
        for (y in 0 until 9) {
            for (x in 0 until 9) {
                val blockIndex = blockMap[x][y] and 0x3FF
                val blockRender = if (blockIndex < viewModelRenders.size) viewModelRenders[blockIndex] else null
                canvas.draw(blockRender, x * 16, y * 16)
            }
        }

        canvas.spriteScale = .5
        return Triple(canvas, blockMap, warpIsAgainstWall)
    }
    private fun convertCoordinates(x: Double, y: Double): Pair<Int, Int> { /*@DONE BlockMapViewModel.ConvertCoordinates/1 cs:919-928*/
        var px = (x - leftEdge) / spriteScale
        var py = (y - topEdge) / spriteScale
        px /= 16
        py /= 16

        val layout = getLayout()
        val border = getBorderThickness(layout)
        return Pair(Math.floor(px).toInt() - border.west, Math.floor(py).toInt() - border.north)
    }
    fun getBlock(x: Double, y: Double): BlockMapViewModelGetBlockTuple { /*@DONE BlockMapViewModel.GetBlock/1 cs:933-948*/
        lastDrawX = -1
        lastDrawY = -1
        var px = (x - leftEdge) / spriteScale
        var py = (y - topEdge) / spriteScale
        px /= 16
        py /= 16

        val layout = getLayout() ?: return BlockMapViewModelGetBlockTuple(-1, -1)
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val border = getBorderThickness(layout)
        val xx = px.toInt() - border.west
        val yy = py.toInt() - border.north
        if (xx < 0 || yy < 0 || xx >= width || yy >= height) return BlockMapViewModelGetBlockTuple(-1, -1)
        val start = layout.getAddress("blockmap")

        val modelAddress = start + (yy * width + xx) * 2
        val data = model.readMultiByteValue(modelAddress, 2)
        return BlockMapViewModelGetBlockTuple(data and 0x3FF, data shr 10)
    }
    private var lastDrawVal: Int = 0
    private var lastDrawX: Int = 0
    private var lastDrawY: Int = 0
    fun drawBlock(token: ModelDelta, blockIndex: Int, collisionIndex: Int, x: Double, y: Double) { /*@DONE BlockMapViewModel.DrawBlock/1 cs:956-960*/
        waveFunctionActive?.cancel()
        val converted = convertCoordinates(x, y)
        drawBlock(token, blockIndex, collisionIndex, converted.first, converted.second)
    }
    fun drawBlock(token: ModelDelta, blockIndex: Int, collisionIndex: Int, xx: Int, yy: Int) { /*@DONE BlockMapViewModel.DrawBlock/2 cs:962-991*/
        waveFunctionActive?.cancel()
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        if (width <= 0 || height <= 0) return
        val border = getBorderThickness(layout)

        val ax = xx.limitToRange(0, width - 1)
        val ay = yy.limitToRange(0, height - 1)
        if (lastDrawX == ax && lastDrawY == ay) return
        val start = layout.getAddress("blockmap")

        val modelAddress = start + (ay * width + ax) * 2
        val data = model.readMultiByteValue(modelAddress, 2)
        var high = data shr 10
        var low = data and 0x3FF
        if (blockIndex >= 0 && blockIndex < _blockRenders.size) low = blockIndex
        if (collisionIndex >= 0 && collisionIndex < 0x3F) high = collisionIndex
        lastDrawVal = model.readMultiByteValue(modelAddress, 2)
        lastDrawX = ax
        lastDrawY = ay
        model.writeMultiByteValue(modelAddress, 2, token, (high shl 10) or low)

        val currentPixels = pixelData
        val canvas = CanvasPixelViewModel(pixelWidth, pixelHeight, currentPixels)
        val updateBlock = blockIndex >= 0 && blockIndex < _blockRenders.size
        val updateHighlight = collisionIndex == _collisionHighlight && _collisionHighlight != -1
        val px = (ax + border.west) * 16
        val py = (ay + border.north) * 16
        if (updateBlock) canvas.draw(_blockRenders[blockIndex], px, py)
        if (updateHighlight && px < pixelWidth && py < pixelHeight) highlightCollision(currentPixels, px, py)
        if (updateBlock || updateHighlight) notifyPropertyChanged("pixelData")
        tutorials.complete(Tutorial.LeftClickMap_DrawBlock)
    }
    fun draw9Grid(token: ModelDelta, grid: Array<IntArray>, x: Double, y: Double) { /*@DONE BlockMapViewModel.Draw9Grid/1 cs:993-1001*/
        waveFunctionActive?.cancel()
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        if (width < 2 || height < 2) return
        val converted = convertCoordinates(x, y)
        val xx = converted.first.limitToRange(0, width - 2)
        val yy = converted.second.limitToRange(0, height - 2)
        draw9Grid(token, grid, xx, yy)
    }
    fun discoverCornersFor9Grid(grid: Array<IntArray>) { /*@DONE BlockMapViewModel.DiscoverCornersFor9Grid/1 cs:1003-1060*/
        innerCornersFor9Grid = null
        val layout = LayoutModel(getLayout())

        // numpad layout for easy reference
        val np7 = grid[0][0] and 0x3FF
        val np8 = grid[1][0] and 0x3FF
        val np9 = grid[2][0] and 0x3FF
        val np4 = grid[0][1] and 0x3FF
        val np5 = grid[1][1] and 0x3FF
        val np6 = grid[2][1] and 0x3FF
        val np1 = grid[0][2] and 0x3FF
        val np2 = grid[1][2] and 0x3FF
        val np3 = grid[2][2] and 0x3FF

        // histograms for inside corners, where the ! is a 'hole':
        // 7  .  9
        // .  !  .
        // 1  .  3
        val corner7 = AutoDictionary<Int, Int>({ _ -> 0 })
        val corner9 = AutoDictionary<Int, Int>({ _ -> 0 })
        val corner1 = AutoDictionary<Int, Int>({ _ -> 0 })
        val corner3 = AutoDictionary<Int, Int>({ _ -> 0 })

        // use maps in the game to figure out the corners
        val ownPrimary = layout.primaryBlockset?.start
        val ownSecondary = layout.secondaryBlockset?.start
        for (otherMap in getAllMaps()) {
            val otherLayout = otherMap.layout ?: continue
            if (otherLayout.primaryBlockset?.start != ownPrimary && otherLayout.secondaryBlockset?.start != ownSecondary) continue

            val blockMap = otherLayout.blockMap
            fun tileAt(bx: Int, by: Int): Int = blockMap[bx, by]?.tile ?: -1
            for (y in 0 until blockMap.height) {
                val topEdge = y == 0
                val bottomEdge = y == blockMap.height - 1
                for (x in 0 until blockMap.width) {
                    val leftEdge = x == 0
                    val rightEdge = x == blockMap.width - 1
                    val block = blockMap[x, y]?.block ?: continue // store tile and collision, but only check that tiles match
                    if (!rightEdge && !bottomEdge && tileAt(x + 1, y).isAny(np3, np2) && tileAt(x, y + 1).isAny(np3, np6)) {
                        corner7[block] = corner7[block] + 1
                    }
                    if (!leftEdge && !bottomEdge && tileAt(x - 1, y).isAny(np1, np2) && tileAt(x, y + 1).isAny(np1, np4)) {
                        corner9[block] = corner9[block] + 1
                    }
                    if (!rightEdge && !topEdge && tileAt(x + 1, y).isAny(np8, np9) && tileAt(x, y - 1).isAny(np6, np9)) {
                        corner1[block] = corner1[block] + 1
                    }
                    if (!leftEdge && !topEdge && tileAt(x - 1, y).isAny(np7, np8) && tileAt(x, y - 1).isAny(np4, np7)) {
                        corner3[block] = corner3[block] + 1
                    }
                }
            }
        }

        val corners = Array(2) { IntArray(2) }
        val defaultBlock = grid[1][1] and 0x3FF
        var key = if (corner7.isEmpty()) 0 else corner7.mostCommonKey()
        corners[0][0] = if (key != 0) key else defaultBlock
        key = if (corner9.isEmpty()) 0 else corner9.mostCommonKey()
        corners[1][0] = if (key != 0) key else defaultBlock
        key = if (corner1.isEmpty()) 0 else corner1.mostCommonKey()
        corners[0][1] = if (key != 0) key else defaultBlock
        key = if (corner3.isEmpty()) 0 else corner3.mostCommonKey()
        corners[1][1] = if (key != 0) key else defaultBlock
        innerCornersFor9Grid = corners
    }
    fun prepareFor9GridDraw(grid: Array<IntArray>) { /*@DONE BlockMapViewModel.PrepareFor9GridDraw/1 cs:1062-1083*/
        // when we do a 9-grid draw,
        // we want to track which draws are part of the current interaction only
        val layout = LayoutModel(getLayout())
        current9gridInteractionMap = Array(Math.max(layout.width, 0)) { BooleanArray(Math.max(layout.height, 0)) }
    }
    private var current9gridInteractionMap: Array<BooleanArray> = emptyArray()
    private var innerCornersFor9Grid: Array<IntArray>? = null
    fun draw9Grid(token: ModelDelta, grid: Array<IntArray>, x: Int, y: Int) { /*@DONE BlockMapViewModel.Draw9Grid/2 cs:1145-1172*/
        waveFunctionActive?.cancel()
        val corners = innerCornersFor9Grid ?: arrayOf(intArrayOf(grid[1][1], grid[1][1]), intArrayOf(grid[1][1], grid[1][1])) // copy so that there's no reference changing during the method
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        if (current9gridInteractionMap.size != width || (width > 0 && current9gridInteractionMap[0].size != height)) prepareFor9GridDraw(grid)
        if (x < 0 || y < 0 || x + 1 >= width || y + 1 >= height) return

        current9gridInteractionMap[x][y] = true
        current9gridInteractionMap[x + 1][y] = true
        current9gridInteractionMap[x][y + 1] = true
        current9gridInteractionMap[x + 1][y + 1] = true

        val start = layout.getAddress("blockmap")

        // need to draw these 4 blocks as well as the 12 neighboring blocks (up/down/left/right/diagonal) if they're set to true
        synchronized(pixelWriteLock) {
            for (dy in -1 until 3) {
                for (dx in -1 until 3) {
                    val xx = x + dx
                    val yy = y + dy
                    if (!xx.inRange(0, width - 1) || !yy.inRange(0, height - 1)) continue
                    if (!current9gridInteractionMap[xx][yy]) continue
                    val chosenBlock = get9GridBlock(current9gridInteractionMap, Point(xx, yy), grid, corners)
                    model.writeMultiByteValue(start + (yy * width + xx) * 2, 2, token, chosenBlock)
                }
            }
        }

        clearPixelCache()
    }
    fun drawBlocks(token: ModelDelta, tiles: Array<IntArray>, source: Point, destination: Point) { /*@DONE BlockMapViewModel.DrawBlocks/1 cs:1174-1197*/
        waveFunctionActive?.cancel()
        if (tiles.isEmpty() || tiles[0].isEmpty()) return
        var dest = destination
        while (Math.abs(dest.x - source.x) % tiles.size != 0) dest = dest - Point(1, 0)
        while (Math.abs(dest.y - source.y) % tiles[0].size != 0) dest = dest - Point(0, 1)

        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val start = layout.getAddress("blockmap")
        var changeCount = 0
        synchronized(pixelWriteLock) {
            for (x in 0 until tiles.size) {
                for (y in 0 until tiles[0].size) {
                    if (dest.x + x < 0 || dest.y + y < 0 || dest.x + x >= width || dest.y + y >= height) continue
                    val address = start + ((dest.y + y) * width + dest.x + x) * 2
                    if (model.readMultiByteValue(address, 2) != tiles[x][y]) {
                        model.writeMultiByteValue(address, 2, token, tiles[x][y])
                        changeCount++
                    }
                }
            }
        }

        if (changeCount > 0) clearPixelCache()
    }
    fun repeatBlock(futureToken: () -> ModelDelta, blockOptions: List<Int>, collision: Int, x: Int, y: Int, w: Int, h: Int, refreshScreen: Boolean) { /*@DONE BlockMapViewModel.RepeatBlock/1 cs:1199-1225*/
        waveFunctionActive?.cancel()
        if (blockOptions.isEmpty()) return
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val start = layout.getAddress("blockmap")
        var changeCount = 0
        val rnd = java.util.Random()
        synchronized(pixelWriteLock) {
            for (xx in 0 until w) {
                for (yy in 0 until h) {
                    if (x + xx < 0 || y + yy < 0 || x + xx >= width || y + yy >= height) continue
                    val address = start + ((yy + y) * width + xx + x) * 2
                    var blockValue = model.readMultiByteValue(address, 2)
                    lastDrawVal = blockValue
                    var block = blockOptions[0]
                    if (blockOptions.size > 1) block = rnd.from(blockOptions)
                    if (block >= 0) blockValue = (blockValue and 0xFC00) + block
                    if (collision >= 0) blockValue = (blockValue and 0x3FF) + (collision shl 10)
                    if (blockValue != lastDrawVal) {
                        model.writeMultiByteValue(address, 2, futureToken(), blockValue)
                        changeCount++
                    }
                }
            }
        }
        if (changeCount > 0 && refreshScreen) clearPixelCache()
    }
    fun repeatBlocks(futureToken: () -> ModelDelta, blockValues: Array<IntArray>?, x: Int, y: Int, w: Int, h: Int, refreshScreen: Boolean) { /*@DONE BlockMapViewModel.RepeatBlocks/1 cs:1227-1251*/
        waveFunctionActive?.cancel()
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val start = layout.getAddress("blockmap")
        var changeCount = 0
        val values = if (blockValues == null || blockValues.isEmpty() || blockValues[0].isEmpty()) null else blockValues
        synchronized(pixelWriteLock) {
            for (xx in 0 until w) {
                for (yy in 0 until h) {
                    if (x + xx < 0 || y + yy < 0 || x + xx >= width || y + yy >= height) continue
                    val address = start + ((yy + y) * width + xx + x) * 2
                    var block = if (values == null) -1 else values[xx % values.size][yy % values[0].size]
                    if (block == -1 && _collisionHighlight >= 0) {
                        val existingBlock = (model.readMultiByteValue(address, 2) and 0x3F)
                        block = (existingBlock or (_collisionHighlight shl 10))
                    }
                    if (block != -1 && model.readMultiByteValue(address, 2) != block) {
                        model.writeMultiByteValue(address, 2, futureToken(), block)
                        changeCount++
                    }
                }
            }
        }
        if (changeCount > 0 && refreshScreen) clearPixelCache()
    }
    fun readRectangle(x: Int, y: Int, w: Int, h: Int): Array<IntArray> { /*@DONE BlockMapViewModel.ReadRectangle/1 cs:1253-1266*/
        val results = Array(Math.max(w, 0)) { IntArray(Math.max(h, 0)) }
        val layout = getLayout() ?: return results
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val start = layout.getAddress("blockmap")
        for (xx in 0 until w) {
            for (yy in 0 until h) {
                if (x + xx < 0 || y + yy < 0 || x + xx >= width || y + yy >= height) continue
                val address = start + ((yy + y) * width + xx + x) * 2
                results[xx][yy] = model.readMultiByteValue(address, 2)
            }
        }
        return results
    }
    fun paintBlock(token: ModelDelta, blockIndex: Int, collisionIndex: Int, x: Double, y: Double) { /*@DONE BlockMapViewModel.PaintBlock/1 cs:1268-1290*/
        waveFunctionActive?.cancel()
        if (blockIndex == -1) return
        var px = (x - leftEdge) / spriteScale
        var py = (y - topEdge) / spriteScale
        px /= 16
        py /= 16
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val border = getBorderThickness(layout)
        val xx = px.toInt() - border.west
        val yy = py.toInt() - border.north
        if (xx < 0 || yy < 0 || xx >= width || yy >= height) return
        val start = layout.getAddress("blockmap")

        val size = Point(width, height)
        var collision = collisionIndex
        if (collision < 0) collision = lastDrawVal shr 10
        val before = lastDrawVal
        val after = (collision shl 10) or blockIndex
        synchronized(pixelWriteLock) {
            paintBlock(token, Point(xx - 1, yy), size, start, before, after)
            paintBlock(token, Point(xx + 1, yy), size, start, before, after)
            paintBlock(token, Point(xx, yy - 1), size, start, before, after)
            paintBlock(token, Point(xx, yy + 1), size, start, before, after)
        }
        clearPixelCache()
    }
    private fun paintBlock(token: ModelDelta, p: Point, size: Point, start: Int, before: Int, after: Int) { /*@DONE BlockMapViewModel.PaintBlock/2 cs:1292-1303*/
        waveFunctionActive?.cancel()
        if (before == after) return
        // iterative flood fill (the original recursed, which risks a stack overflow on large maps)
        val pending = kotlin.collections.ArrayDeque<Point>()
        pending.addLast(p)
        while (pending.isNotEmpty()) {
            val current = pending.removeLast()
            if (current.x < 0 || current.y < 0 || current.x >= size.x || current.y >= size.y) continue
            val address = start + (current.y * size.x + current.x) * 2
            if (model.readMultiByteValue(address, 2) != before) continue
            model.writeMultiByteValue(address, 2, token, after)
            pending.addLast(current + Point(-1, 0))
            pending.addLast(current + Point(1, 0))
            pending.addLast(current + Point(0, -1))
            pending.addLast(current + Point(0, 1))
        }
    }
    fun paintBlockBag(token: ModelDelta, blockIndexes: MutableList<Int>, collisionIndex: Int, x: Double, y: Double) { /*@DONE BlockMapViewModel.PaintBlockBag/1 cs:1305-1337*/
        waveFunctionActive?.cancel()
        if (blockIndexes.size < 1) return
        var px = (x - leftEdge) / spriteScale
        var py = (y - topEdge) / spriteScale
        px /= 16
        py /= 16
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val border = getBorderThickness(layout)
        val xx = px.toInt() - border.west
        val yy = py.toInt() - border.north
        if (xx < 0 || yy < 0 || xx >= width || yy >= height) return
        val start = layout.getAddress("blockmap")

        val complete = HashSet<Point>()
        complete.add(Point(xx, yy))
        val check = ArrayList<Point>()
        check.add(Point(xx - 1, yy))
        check.add(Point(xx + 1, yy))
        check.add(Point(xx, yy - 1))
        check.add(Point(xx, yy + 1))
        val targets = blockIndexes.map { bi -> (collisionIndex shl 10) or bi }
        val rnd = java.util.Random()
        synchronized(pixelWriteLock) {
            while (check.size > 0) {
                val p = check.removeAt(check.size - 1)
                if (p.x < 0 || p.y < 0 || p.x >= width || p.y >= height) continue
                if (complete.contains(p)) continue
                complete.add(p)

                val address = start + (p.y * width + p.x) * 2
                if (model.readMultiByteValue(address, 2) != lastDrawVal) continue
                model.writeMultiByteValue(address, 2, token, rnd.from(targets))

                check.add(Point(p.x - 1, p.y))
                check.add(Point(p.x + 1, p.y))
                check.add(Point(p.x, p.y - 1))
                check.add(Point(p.x, p.y + 1))
            }
        }
        clearPixelCache()
    }
    private fun getAllMatchingConnectedBlocks(x: Int, y: Int): Iterable<Point> { /*@DONE BlockMapViewModel.GetAllMatchingConnectedBlocks/1 cs:1339-1364*/
        val results = ArrayList<Point>()
        val layout = getLayout() ?: return results
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        if (x < 0 || y < 0 || x >= width || y >= height) return results
        val start = layout.getAddress("blockmap")
        val added = HashSet<Point>()
        val toAdd = kotlin.collections.ArrayDeque<Point>()
        toAdd.addLast(Point(x, y))
        fun read(p: Point): Int = model.readMultiByteValue(start + (p.y * width + p.x) * 2, 2)
        val matchBlock = read(Point(x, y))

        while (toAdd.isNotEmpty()) {
            val current = toAdd.removeFirst()
            if (added.contains(current)) continue
            if (current.x < 0 || current.x >= width) continue
            if (current.y < 0 || current.y >= height) continue
            if (read(current) != matchBlock) continue
            results.add(current)
            added.add(current)
            toAdd.addLast(current + Point(-1, 0))
            toAdd.addLast(current + Point(1, 0))
            toAdd.addLast(current + Point(0, -1))
            toAdd.addLast(current + Point(0, 1))
        }
        return results
    }
    fun paintWaveFunction(token: ModelDelta, x: Double, y: Double, wave: (Int, Int) -> WaveCell, cancelToken: CancellationToken) { /*@DONE BlockMapViewModel.PaintWaveFunction/1 cs:1367-1450*/
        // The original is an async void that yields to the UI every 50 iterations; this port runs to completion synchronously.
        waveFunctionActive?.cancel()
        val linked = CancellationTokenSource()
        waveFunctionActive = linked
        cancelToken.register { linked.cancel() }
        val linkedToken = linked.token
        var px = (x - leftEdge) / spriteScale
        var py = (y - topEdge) / spriteScale
        px /= 16
        py /= 16
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val border = getBorderThickness(layout)
        val xx = px.toInt() - border.west
        val yy = py.toInt() - border.north
        if (xx < 0 || yy < 0 || xx >= width || yy >= height) return
        val start = layout.getAddress("blockmap")

        val right = Point(1, 0)
        val down = Point(0, 1)
        val rnd = java.util.Random()
        val toDraw = HashMap<Point, WaveCell>()
        val allCells = getAllMatchingConnectedBlocks(xx, yy).toList()
        fun fill(p: Point, value: Int) { model.writeMultiByteValue(start + (p.y * width + p.x) * 2, 2, token, value) }

        synchronized(pixelWriteLock) {
            // set all effected spaces to 0 so they won't count toward eachother's wave-function
            for (cell in allCells) fill(cell, 0)

            // initial wave function collapse values
            for (cell in allCells) toDraw[cell] = wave(cell.x, cell.y)
        }

        // reduction loop: find the most restricted cell, collapse it, then propogate its new restrictions
        val stack = ArrayList<CollapseAttempt>()
        var delayCount = 0
        var attemptLimit = 10
        if (toDraw.size < 300) attemptLimit *= 2
        while (toDraw.size > 0) {
            val cellsWithRestrictions = toDraw.values.filter { cell -> cell.hasRestrictions }
            val smallest = cellsWithRestrictions.minOfOrNull { v -> v.probabilities?.size ?: 0 } ?: 0 // what is the smallest number of options

            if (smallest > 0 && (stack.size == 0 || stack.sumOf { item -> item.attemptCount } < attemptLimit) && !linkedToken.isCancellationRequested) {
                // good case: we have a cell to callapse
                val restrictedCells = cellsWithRestrictions.filter { cell -> (cell.probabilities?.size ?: 0) == smallest } // get the cells with that least number of options
                val cell = rnd.from(restrictedCells)
                val point = toDraw.keys.first { key -> toDraw[key] === cell }

                val attempt = cell.collapse(rnd)
                val uncollapsedNeighbors = getUncollapsedNeighbors(point, toDraw)
                stack.add(CollapseAttempt(WaveSpot(point, cell), attempt and 0x3FF, uncollapsedNeighbors))
                synchronized(pixelWriteLock) { fill(point, attempt) }

                toDraw.remove(point)
                val neighbors = listOf(point - right, point + right, point - down, point + down, point - right - down, point + right - down, point - right + down, point + right + down)
                for (neighbor in neighbors) {
                    if (!toDraw.containsKey(neighbor)) continue
                    toDraw[neighbor] = wave(neighbor.x, neighbor.y) // re-evaluate from scratch now that a new neighbor has been found
                }
            } else {
                // bad case:
                //  (1) last collapse caused a contradiction - need to backtrack
                //      or
                //  (2) we've been backtracking too much along this line, we need to back out and try something else.
                if (stack.size == 0) {
                    viewPort.raiseError("Wave Function Collapse failed: no valid options remain.")
                    break
                }
                val lastAttempt = stack.removeAt(stack.size - 1)
                // restore the last attempt's cell and neighbors
                toDraw[lastAttempt.spotToCollapse.collapsedPoint] = lastAttempt.spotToCollapse.cellBeforeCollapse
                for (neighbor in lastAttempt.neighborsBeforeCollapse) {
                    toDraw[neighbor.collapsedPoint] = neighbor.cellBeforeCollapse
                }
                synchronized(pixelWriteLock) { fill(lastAttempt.spotToCollapse.collapsedPoint, 0) } // reset to uncollapsed
                // remove the chosen collapse from options
                val probabilities = lastAttempt.spotToCollapse.cellBeforeCollapse.probabilities
                val badOption = probabilities?.firstOrNull { prob -> prob.block == lastAttempt.chosenCollapse }
                if (probabilities != null && badOption != null) probabilities.remove(badOption)
                if (stack.size > 0) stack[stack.size - 1].attemptCount += 1
            }
            delayCount += 1
            if (delayCount == 50) {
                delayCount = 0
                clearPixelCache()
            }
        }

        clearPixelCache()
    }
    private data class WaveSpot(val collapsedPoint: Point, val cellBeforeCollapse: WaveCell) { // cs:1462-1462
        /*@END BlockMapViewModel.WaveSpot*/
    }
    private data class CollapseAttempt(val spotToCollapse: WaveSpot, val chosenCollapse: Int, val neighborsBeforeCollapse: MutableList<WaveSpot>) { // cs:1463-1465
        var attemptCount: Int = 0
        /*@END BlockMapViewModel.CollapseAttempt*/
    }
    fun updateEventLocation(ev: IEventViewModel?, x: Double, y: Double) { /*@DONE BlockMapViewModel.UpdateEventLocation/1 cs:1471-1486*/
        lastDrawX = -1
        lastDrawY = -1
        val layout = getLayout()
        val border = getBorderThickness(layout)
        if (ev == null || layout == null) return
        val px = (x - leftEdge) / spriteScale
        val py = (y - topEdge) / spriteScale
        val xx = (px / 16).toInt() - border.west
        val yy = (py / 16).toInt() - border.north
        if (ev.x == xx && ev.y == yy) return
        if (xx < 0 || yy < 0) return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        if (xx >= width || yy >= height) return
        ev.x = xx
        ev.y = yy
        selectedEvent = ev
        clearPixelCache()
    }
    fun eventsUnderCursor(x: Double, y: Double, autoSelect: Boolean = true): List<IEventViewModel> { /*@DONE BlockMapViewModel.EventsUnderCursor/1 cs:1488-1503*/
        val matches = ArrayList<IEventViewModel>()
        if (_showEvents == MapDisplayOptions.NoEvents) return matches
        val layout = getLayout()
        val border = getBorderThickness(layout)
        val tileX = ((x - leftEdge) / spriteScale / 16).toInt() - border.west
        val tileY = ((y - topEdge) / spriteScale / 16).toInt() - border.north
        for (e in getEvents()) {
            if (e.x == tileX && e.y == tileY) matches.add(e)
        }
        val last = matches.lastOrNull()
        if (autoSelect && _selectedEvent !== last) {
            selectedEvent = last
            clearPixelCache()
        }
        return matches
    }
    fun autoCrop(warpID: Int): IPixelViewModel? { /*@DONE BlockMapViewModel.AutoCrop/1 cs:1506-1515*/
        val sprites = allOverworldSprites
        if (defaultOverworldSprite == null) defaultOverworldSprite = getDefaultOW(model)
        val mapElement = getMapModel() ?: return null
        val eventsTable = mapElement.getSubTable("events") ?: return null
        val events = EventGroupModel(this, { address -> gotoAddress(address) }, { b, m -> gotoBankMap(b, m) }, eventsTable[0], eventTemplate, sprites, defaultOverworldSprite!!, berryInfo, group, this.map)
        val eventWarps = events.warps
        if (eventWarps.size <= warpID || warpID < 0) return null
        val warp = eventWarps[warpID]
        return autoCrop(warp.x, warp.y)
    }
    fun autoCrop(centerX: Int, centerY: Int): IPixelViewModel? { /*@DONE BlockMapViewModel.AutoCrop/2 cs:1517-1532*/
        val mapElement = getMapModel() ?: return null
        val layout = getLayout(mapElement) ?: return null
        val width = layout.getValue("width")
        val height = layout.getValue("height")

        var startX = centerX - sizeX / 2
        var startY = centerY - sizeY / 2
        while (startX < 0) startX += 1
        while (startY < 0) startY += 1
        while (startX + sizeX > width && startX > 0) startX--
        while (startY + sizeY > height && startY > 0) startY--

        return ReadonlyPixelViewModel.crop(this, startX * 16, startY * 16, sizeX * 16, sizeY * 16)
    }
    fun deselectEvent() { /*@DONE BlockMapViewModel.DeselectEvent/1 cs:1534-1538*/
        if (_selectedEvent == null) return
        selectedEvent = null
        clearPixelCache()
    }
    fun getMapSliders(): Iterable<MapSlider> { /*@DONE BlockMapViewModel.GetMapSliders/1 cs:1544-1593*/
        val result = ArrayList<MapSlider>()
        val connections = getConnections() ?: return result
        val border = getBorderThickness()
        val tileSize = (16 * spriteScale).toInt()
        var id = 0

        // get sliders for up/down/left/right connections
        for (connection in connections) {
            val notify: () -> Unit = { neighborsChanged(this, EventArgs.empty) }
            val neighbor = getNeighbor(connection, border)
            val sourceMapInfo = ConnectionSliderInitSourceMapInfoTuple(group, this.map)

            if (connection.direction == MapDirection.Up) {
                result.add(ConnectionSlider(connection, sourceMapInfo, notify, id, MapSliderIcons.LeftRight, tutorials, right = neighbor.leftEdge, bottom = neighbor.bottomEdge - tileSize))
                result.add(ConnectionSlider(connection, sourceMapInfo, notify, id + 1, MapSliderIcons.LeftRight, tutorials, left = neighbor.rightEdge, bottom = neighbor.bottomEdge - tileSize))
            }

            if (connection.direction == MapDirection.Down) {
                result.add(ConnectionSlider(connection, sourceMapInfo, notify, id, MapSliderIcons.LeftRight, tutorials, right = neighbor.leftEdge, top = neighbor.topEdge + tileSize))
                result.add(ConnectionSlider(connection, sourceMapInfo, notify, id + 1, MapSliderIcons.LeftRight, tutorials, left = neighbor.rightEdge, top = neighbor.topEdge + tileSize))
            }

            if (connection.direction == MapDirection.Left) {
                result.add(ConnectionSlider(connection, sourceMapInfo, notify, id, MapSliderIcons.UpDown, tutorials, right = neighbor.rightEdge - tileSize, bottom = neighbor.topEdge))
                result.add(ConnectionSlider(connection, sourceMapInfo, notify, id + 1, MapSliderIcons.UpDown, tutorials, right = neighbor.rightEdge - tileSize, top = neighbor.bottomEdge))
            }

            if (connection.direction == MapDirection.Right) {
                result.add(ConnectionSlider(connection, sourceMapInfo, notify, id, MapSliderIcons.UpDown, tutorials, left = neighbor.leftEdge + tileSize, bottom = neighbor.topEdge))
                result.add(ConnectionSlider(connection, sourceMapInfo, notify, id + 1, MapSliderIcons.UpDown, tutorials, left = neighbor.leftEdge + tileSize, top = neighbor.bottomEdge))
            }

            id += 2
        }

        // get sliders for size expansion
        val centerX = (leftEdge + rightEdge - MapSlider.sliderSize) / 2
        val centerY = (topEdge + bottomEdge - MapSlider.sliderSize) / 2
        val resize: (MapDirection, Int) -> Unit = { direction, amount -> resizeMapData(direction, amount) }
        result.add(ExpansionSlider(resize, id + 0, MapSliderIcons.ExtendUp, getConnectionCommands(connections, MapDirection.Up), left = centerX, bottom = topEdge))
        result.add(ExpansionSlider(resize, id + 1, MapSliderIcons.ExtendDown, getConnectionCommands(connections, MapDirection.Down), left = centerX, top = bottomEdge))
        result.add(ExpansionSlider(resize, id + 2, MapSliderIcons.ExtendLeft, getConnectionCommands(connections, MapDirection.Left), right = leftEdge, top = centerY))
        result.add(ExpansionSlider(resize, id + 3, MapSliderIcons.ExtendRight, getConnectionCommands(connections, MapDirection.Right), left = rightEdge, top = centerY))
        return result
    }
    private fun getConnectionCommands(connections: List<ConnectionModel>, direction: MapDirection): Iterable<IMenuCommand> { /*@DONE BlockMapViewModel.GetConnectionCommands/1 cs:1595-1626*/
        val result = ArrayList<IMenuCommand>()
        val toRemove = ArrayList<Int>()

        val info = canConnect(direction)
        if (info != null) {
            // every size/offset case of the original offers the same two commands; the numbers are already inside info
            val createNew = MenuCommand<ConnectionInfo>("Create New Map", { i -> connectNewMap(i) })
            createNew.parameter = info
            result.add(createNew)
            val connectExisting = MenuCommand<ConnectionInfo>("Connect Existing Map", { i -> connectExistingMap(i) })
            connectExisting.parameter = info
            result.add(connectExisting)
        }

        for (i in connections.indices) {
            if (connections[i].direction != direction) continue
            toRemove.add(i)
        }
        if (toRemove.size > 0) {
            // we can remove these connections
            val remove = MenuCommand<List<Int>>("Remove Connections", { list -> removeConnections(list) })
            remove.parameter = toRemove
            result.add(remove)
        }
        return result
    }
    private fun getAllMaps(): Iterable<MapModel> { /*@DONE BlockMapViewModel.GetAllMaps/1 cs:1632-1647*/
        val result = ArrayList<MapModel>()
        val banks = model.getTableModel(HardcodeTablesModel.mapBankTable) ?: return result
        for (i in 0 until banks.size) {
            val bank = banks[i]
            val maps = bank.getSubTable("maps") ?: continue
            for (j in 0 until maps.size) {
                val mapList = maps[j]
                val mapTable = mapList.getSubTable("map") ?: continue
                val mapElement = mapTable[0]
                result.add(MapModel(mapElement, i, j))
            }
        }
        return result
    }
    private var waveFunctionActive: CancellationTokenSource? = null
    private fun resizeMapData(direction: MapDirection, amount: Int) { /*@DONE BlockMapViewModel.ResizeMapData/1 cs:1650-1693*/
        waveFunctionActive?.cancel()
        if (amount == 0) return
        val mapElement = getMapModel() ?: return
        val layout = getLayout(mapElement) ?: return
        val run = model.getNextRun(layout.getAddress("blockmap")) as? BlockmapRun ?: return
        val borderWidth = if (layout.hasField("borderwidth")) layout.getValue("borderwidth") else 2
        val borderHeight = if (layout.hasField("borderheight")) layout.getValue("borderheight") else 2
        val newRun = run.tryChangeSize(tokenFactory, direction, amount, borderWidth, borderHeight)
        if (newRun != null) {
            val tileSize = (16 * spriteScale).toInt()
            if (direction == MapDirection.Left) leftEdge -= amount * tileSize
            if (direction == MapDirection.Up) topEdge -= amount * tileSize
            val connectionList = getConnections(mapElement, group, this.map)
            if (connectionList != null) {
                for (connection in connectionList) {
                    if (direction == MapDirection.Left) {
                        if (connection.direction == MapDirection.Down || connection.direction == MapDirection.Up) {
                            connection.offset += amount
                            val inverse = connection.getInverse()
                            if (inverse != null) inverse.offset -= amount
                        }
                    } else if (direction == MapDirection.Up) {
                        if (connection.direction == MapDirection.Left || connection.direction == MapDirection.Right) {
                            connection.offset += amount
                            val inverse = connection.getInverse()
                            if (inverse != null) inverse.offset -= amount
                        }
                    }
                }
            }
            for (e in getEvents()) {
                if (direction == MapDirection.Left) {
                    e.x += amount
                } else if (direction == MapDirection.Up) {
                    e.y += amount
                }
            }
            refreshMapSize()
            neighborsChanged(this, EventArgs.empty)
            if (newRun.start != run.start) informRepoint(DataMovedEventArgs("Map", newRun.start))
            tutorials.complete(Tutorial.DragConnectionButtons_ResizeMap)
        }
    }
    fun connectNewMap(info: ConnectionInfo) { /*@DONE BlockMapViewModel.ConnectNewMap/1 cs:1695-1755*/
        viewPort.changeHistory.changeCompleted()
        val scope = viewPort.changeHistory.continueCurrentTransaction()
        try {
            val token = tokenFactory()
            tutorials.complete(Tutorial.RightClick_CreateConnection)
            val option = mapRepointer.getMapBankForNewMap(
                "Maps are organized into banks. The game doesn't care, so you can use the banks however you like." + "\n" +
                "Which map bank do you want to use for the new map?")
            if (option == -1) return

            val mapElement = getMapModel()

            var width = info.size
            var height = info.size

            val layoutModel = LayoutModel(getLayout() ?: return)
            if (info.direction.isAny(MapDirection.Up, MapDirection.Down)) {
                height = Math.min(layoutModel.height, height)
            } else if (info.direction.isAny(MapDirection.Right, MapDirection.Left)) {
                width = Math.min(layoutModel.width, width)
            }
            val isZConnection = info.direction.isAny(MapDirection.Dive, MapDirection.Emerge)
            if (isZConnection) height = info.offset
            val otherMap = createNewMap(token, option, width, height)
            if (otherMap == null) {
                if (model.getTable(HardcodeTablesModel.mapLayoutTable) == null) {
                    viewPort.raiseError(MapRepointer.mapLayoutMissing)
                } else {
                    viewPort.raiseError(MapRepointer.mapBankFullError)
                }
                return
            }

            var connections = getOrCreateConnections(mapElement, token) ?: return
            val connectionsAndCount = mapElement!!.getSubTable("connections")!![0]

            val originalConnectionStart = connections.start
            connections = model.relocateForExpansion(token, connections, connections.length + connections.elementLength)
            if (connections.start != originalConnectionStart) informRepoint(DataMovedEventArgs("Connections", connections.start))
            connectionsAndCount.setValue("count", connections.elementCount + 1)
            val table = ModelTable(model, connections.start, tokenFactory, connections)
            var newConnection = ConnectionModel(table[connections.elementCount], group, this.map)
            newConnection.offset = if (isZConnection) 0 else info.offset
            newConnection.direction = info.direction
            newConnection.unused = 0

            newConnection.mapGroup = otherMap.group
            newConnection.mapNum = otherMap.map
            val inverseInfo = ConnectionInfo(info.size, if (isZConnection) 0 else -info.offset, info.oppositeDirection)
            newConnection = otherMap.addConnection(inverseInfo) ?: return
            newConnection.offset = if (isZConnection) 0 else inverseInfo.offset
            newConnection.mapGroup = mapID / 1000
            newConnection.mapNum = mapID % 1000
            newConnection.unused = 0

            refreshMapSize()
            neighborsChanged(this, EventArgs.empty)
        } finally {
            scope.dispose()
        }
        viewPort.changeHistory.changeCompleted()
    }
    private fun createNewMap(token: ModelDelta, bank: Int, width: Int, height: Int): BlockMapViewModel? { /*@DONE BlockMapViewModel.CreateNewMap/1 cs:1757-1779*/
        if (model.getTable(HardcodeTablesModel.mapLayoutTable) == null) return null
        val mapTable = mapRepointer.addNewMapToBank(bank) ?: return null // failed to create map in given bank
        val newMap = mapRepointer.createNewMap(token)
        val layout = mapRepointer.createNewLayout(token)

        // update width / height
        model.writeValue(token, layout.element!!.start + 0, width)
        model.writeValue(token, layout.element!!.start + 4, height)

        layout.element!!.setAddress(Format.blockMap, mapRepointer.createNewBlockMap(token, width, height))

        newMap.element!!.setAddress(Format.layout, layout.element!!.start)
        model.updateArrayPointer(token, null, null, -1, mapTable.start + mapTable.length - 4, newMap.element!!.start)

        val otherMap = BlockMapViewModel(fileSystem, tutorials, viewPort, format, eventTemplate, bank, mapTable.elementCount - 1)
        otherMap.allOverworldSprites = allOverworldSprites
        otherMap.berryInfo = berryInfo
        otherMap.updateLayoutID()
        return otherMap
    }
    private fun connectExistingMap(info: ConnectionInfo) { /*@DONE BlockMapViewModel.ConnectExistingMap/1 cs:1781-1844*/
        // find available maps
        val options = LinkedHashMap<Int, ConnectionInfo>()
        val table = model.getTable(HardcodeTablesModel.mapBankTable) ?: return
        val mapBanks = ModelTable(model, table.start, tokenFactory)
        for (g in 0 until mapBanks.size) {
            val bank = mapBanks[g]
            val maps = bank.getSubTable("maps") ?: continue
            for (m in 0 until maps.size) {
                val mapVM = BlockMapViewModel(fileSystem, tutorials, viewPort, format, eventTemplate, g, m)
                mapVM.allOverworldSprites = allOverworldSprites
                mapVM.berryInfo = berryInfo
                val newInfo = mapVM.canConnect(info.oppositeDirection)
                if (newInfo != null) options[mapVM.mapID] = newInfo
            }
        }

        // select which map to add
        val keys = options.keys.toList()
        if (keys.isEmpty()) return
        val enumViewModel = EnumViewModel(*keys.map { key -> mapIDToText(model, key) }.toTypedArray())

        tutorials.complete(Tutorial.RightClick_CreateConnection)
        val okOption = VisualOption()
        okOption.index = 1
        okOption.option = "OK"
        okOption.shortDescription = "Connect Existing Map"
        val option = fileSystem.showOptions("Pick a map", "Which map do you want to connect to?", listOf(listOf<Any>(enumViewModel)), okOption)
        if (option == -1) return
        if (enumViewModel.choice < 0 || enumViewModel.choice >= keys.size) return
        val choice = keys[enumViewModel.choice]

        val otherMap = BlockMapViewModel(fileSystem, tutorials, viewPort, format, eventTemplate, choice / 1000, choice % 1000)
        otherMap.allOverworldSprites = allOverworldSprites
        otherMap.berryInfo = berryInfo
        val otherSize = otherMap.getBlockSize()
        var connectInfo = info
        if (info.direction.isAny(MapDirection.Left, MapDirection.Right)) {
            connectInfo = info.copy(offset = info.offset - (otherSize.second - info.size) / 2)
        } else if (info.direction.isAny(MapDirection.Up, MapDirection.Down)) {
            connectInfo = info.copy(offset = info.offset - (otherSize.first - info.size) / 2)
        } else if (info.direction.isAny(MapDirection.Dive, MapDirection.Emerge)) {
            connectInfo = info.copy(offset = 0)
        }

        var newConnection = addConnection(connectInfo) ?: return
        newConnection.offset = connectInfo.offset
        newConnection.direction = connectInfo.direction
        newConnection.mapGroup = choice / 1000
        newConnection.mapNum = choice % 1000

        val inverseInfo = options[choice]!!.copy(offset = -connectInfo.offset)
        newConnection = otherMap.addConnection(inverseInfo) ?: return
        newConnection.offset = inverseInfo.offset
        newConnection.mapGroup = mapID / 1000
        newConnection.mapNum = mapID % 1000

        refreshMapSize()
        neighborsChanged(this, EventArgs.empty)
        viewPort.changeHistory.changeCompleted()
    }
    private fun removeConnections(toRemove: List<Int>) { /*@DONE BlockMapViewModel.RemoveConnections/1 cs:1846-1875*/
        val token = tokenFactory()
        val mapElement = getMapModel() ?: return
        val connections = getConnections(mapElement, group, this.map) ?: return
        val border = getBorderThickness()
        for (i in toRemove.indices) {
            val connectedMap = getNeighbor(connections[toRemove[i] - i], border)
            connectedMap.removeMatchedConnection(token, this.group, this.map, connections[toRemove[i] - i].direction.reverse())

            for (j in toRemove[i] - i + 1 until connections.size - i) {
                connections[j - 1].direction = connections[j].direction
                connections[j - 1].offset = connections[j].offset
                connections[j - 1].mapGroup = connections[j].mapGroup
                connections[j - 1].mapNum = connections[j].mapNum
            }
            val connectionsTable = connections[0].table
            if (connectionsTable.elementCount == 1) {
                erase(connectionsTable, token)
            } else {
                val shorterTable = connectionsTable.append(token, -1)
                model.observeRunWritten(token, shorterTable)
            }
        }
        val connectionsAndCount = mapElement.getSubTable("connections")!![0]
        connectionsAndCount.setValue("count", connections.size - toRemove.size)

        refreshMapSize()
        neighborsChanged(this, EventArgs.empty)
        viewPort.changeHistory.changeCompleted()
    }
    private fun removeMatchedConnection(token: ModelDelta, mapGroup: Int, mapNum: Int, direction: MapDirection) { /*@DONE BlockMapViewModel.RemoveMatchedConnection/1 cs:1880-1910*/
        // don't remove self-referential connections
        if (mapGroup == group && mapNum == this.map) return

        val mapElement = getMapModel()
        val connections = getConnections(mapElement, group, this.map) ?: return
        for (i in 0 until connections.size) {
            if (connections[i].direction != direction || connections[i].mapGroup != mapGroup || connections[i].mapNum != mapNum) continue

            for (j in i + 1 until connections.size) {
                connections[j - 1].direction = connections[j].direction
                connections[j - 1].offset = connections[j].offset
                connections[j - 1].mapGroup = connections[j].mapGroup
                connections[j - 1].mapNum = connections[j].mapNum
            }

            // doesn't depend on i, but only do these if a match was found
            val connectionsTable = connections[0].table
            if (connectionsTable.elementCount == 1) {
                erase(connectionsTable, token)
            } else {
                val shorterTable = connectionsTable.append(token, -1)
                model.observeRunWritten(token, shorterTable)
            }
            val connectionsAndCount = mapElement!!.getSubTable("connections")!![0]
            connectionsAndCount.setValue("count", connections.size - 1)
            refreshMapSize()
            neighborsChanged(this, EventArgs.empty)
            break
        }
    }
    private fun addConnection(info: ConnectionInfo): ConnectionModel? { /*@DONE BlockMapViewModel.AddConnection/1 cs:1912-1928*/
        val token = tokenFactory()
        val mapElement = getMapModel()

        var connections = getOrCreateConnections(mapElement, token) ?: return null

        val count = connections.elementCount
        connections = connections.append(token, 1)
        model.observeRunWritten(token, connections)

        val table = ModelTable(model, connections.start, tokenFactory, connections)
        val newConnection = ConnectionModel(table[count], group, this.map)
        token.changeData(model, table[count].start, ByteArray(12).asByteList())
        newConnection.direction = info.direction
        return newConnection
    }
    private fun getOrCreateConnections(map: ModelArrayElement?, token: ModelDelta): ITableRun? { /*@DONE BlockMapViewModel.GetOrCreateConnections/1 cs:1930-1958*/
        if (map == null) return null
        var connectionsAndCountTable = map.getSubTable("connections")
        var needsNewTable = connectionsAndCountTable == null
        if (!needsNewTable) {
            val existingRun = model.getNextRun(connectionsAndCountTable!!.run.start)
            needsNewTable = existingRun == null || existingRun.start != connectionsAndCountTable.run.start
        }
        if (needsNewTable) {
            val newConnectionsAndCountTable = mapRepointer.createNewConnections(token)
            model.updateArrayPointer(token, null, null, -1, map.start + 12, newConnectionsAndCountTable)
            connectionsAndCountTable = map.getSubTable("connections")
        }
        val countTable: ModelTable = connectionsAndCountTable ?: return null
        val connectionsAndCount = countTable[0]

        val connections: ITableRun

        if (connectionsAndCount.getValue("count") == 0) {
            val newConnectionTableStart = model.findFreeSpace(model.freeSpaceStart, 12)
            val childContent = ConnectionInfo.singleConnectionContent
            val lengthToken = ConnectionInfo.singleConnectionLength
            val childSegments = ArrayRun.parseSegments(childContent, model)
            val parentStrategy = TableStreamRun.parseEndStream(model, "connections", lengthToken, childSegments, countTable.run.elementContent) ?: return null
            connections = TableStreamRun(model, newConnectionTableStart, SortedSpanStatic.one(connectionsAndCount.start + 4), "[" + childContent + "]" + lengthToken, childSegments, parentStrategy, 0)
            connectionsAndCount.setAddress("connections", newConnectionTableStart)
            informCreate(DataMovedEventArgs("Connection", newConnectionTableStart))
        } else {
            val connectionsTable = connectionsAndCount.getSubTable("connections") ?: return null
            connections = connectionsTable.run
        }

        return connections
    }
    private fun createEventTable(map: ModelArrayElement): ModelTable { /*@DONE BlockMapViewModel.CreateEventTable/1 cs:1960-1966*/
        // create some blank event data: 0 events for each of the four categories
        val token = tokenFactory()
        val eventAddress = mapRepointer.createNewEvents(token)
        model.updateArrayPointer(token, map.table.elementContent[1], map.table.elementContent, 0, map.start + 4, eventAddress)
        return map.getSubTable("events")!!
    }
    val canEditTilesetChanged = Event<EventArgs>()
    fun canEditTileset(type: String): Boolean { /*@DONE BlockMapViewModel.CanEditTileset/1 cs:1969-1979*/
        val mapElement = getMapModel() ?: return false
        val mapModel = MapModel(mapElement, group, this.map)
        var spriteAddress = mapModel.layout?.primaryBlockset?.tilesetAddress ?: -1
        var paletteAddress = mapModel.layout?.primaryBlockset?.paletteAddress ?: -1
        if (type == "Secondary") {
            spriteAddress = mapModel.layout?.secondaryBlockset?.tilesetAddress ?: -1
            paletteAddress = mapModel.layout?.secondaryBlockset?.paletteAddress ?: -1
        }
        val sRun = model.getNextRun(spriteAddress) as? ISpriteRun
        val pRun = model.getNextRun(paletteAddress) as? IPaletteRun
        return sRun != null && sRun.start == spriteAddress && pRun != null && pRun.start == paletteAddress
    }
    fun editTileset(type: String) { /*@DONE BlockMapViewModel.EditTileset/1 cs:1980-1997*/
        val mapElement = getMapModel() ?: return
        val mapModel = MapModel(mapElement, group, this.map)
        val layoutModel = mapModel.layout ?: return
        val spriteTool = viewPort.tools?.spriteTool ?: return
        val blockset = (if (type == "Primary") layoutModel.primaryBlockset else layoutModel.secondaryBlockset) ?: return
        spriteTool.spriteAddress = blockset.tilesetAddress
        spriteTool.paletteAddress = blockset.paletteAddress

        val newTab = ImageEditorViewModel(viewPort.changeHistory, model, spriteTool.spriteAddress, viewPort.save, spriteTool.paletteAddress)
        val args = TabChangeRequestedEventArgs(newTab)
        viewPort.mapEditor!!.raiseRequestTabChange(args)

        if (newTab.canEditTilesetWidth) {
            val minWidth = newTab.minimumTilesetWidth
            val maxWidth = newTab.maximumTilesetWidth
            newTab.currentTilesetWidth = if (maxWidth < minWidth) minWidth else 16.limitToRange(minWidth, maxWidth)
        }
    }
    fun createObjectEvent(graphics: Int, scriptAddress: Int): ObjectEventViewModel? { /*@DONE BlockMapViewModel.CreateObjectEvent/1 cs:1999-2028*/
        val mapElement = getMapModel() ?: return null
        var eventsTable = mapElement.getSubTable("events")
        if (eventsTable == null) eventsTable = createEventTable(mapElement)
        val events = eventsTable[0]
        val element = addEvent(events, tokenFactory, "objectCount", "objects")
        var targetID = 1
        val takenIDs = HashSet<Int>()
        val existingObjects = Ref<ModelTable?>(null)
        if (events.tryGetSubTable("objects", existingObjects)) {
            for (ev in existingObjects.value!!) {
                val idValue = Ref(0)
                takenIDs.add(if (ev.tryGetValue("id", idValue)) idValue.value else 0)
            }
        }
        while (targetID < element.table.elementCount && takenIDs.contains(targetID)) targetID++
        val sprites = allOverworldSprites
        if (defaultOverworldSprite == null) defaultOverworldSprite = getDefaultOW(model)
        val newEvent = ObjectEventViewModel(this, { a -> gotoAddress(a) }, element, eventTemplate, sprites, defaultOverworldSprite!!, berryInfo)
        newEvent.x = 0
        newEvent.y = 0
        newEvent.elevation = 0
        newEvent.objectID = targetID
        newEvent.scriptAddress = scriptAddress
        newEvent.graphics = graphics
        newEvent.rangeX = 0
        newEvent.rangeY = 0
        newEvent.flag = 0
        newEvent.moveType = 0
        newEvent.trainerType = 0
        newEvent.trainerRangeOrBerryID = 0
        newEvent.clearUnused()
        selectedEvent = newEvent
        return newEvent
    }
    fun createWarpEvent(bank: Int, map: Int): WarpEventViewModel? { /*@DONE BlockMapViewModel.CreateWarpEvent/1 cs:2030-2038*/
        val mapModel = getMapModel() ?: return null
        val events = mapModel.getSubTable("events")?.get(0) ?: return null
        val element = addEvent(events, tokenFactory, "warpCount", "warps")
        val newEvent = WarpEventViewModel(element, { b, m -> gotoBankMap(b, m) })
        newEvent.x = 0
        newEvent.y = 0
        newEvent.elevation = 0
        newEvent.bank = bank
        newEvent.map = map
        newEvent.warpID = element.arrayIndex + 1
        selectedEvent = newEvent
        return newEvent
    }
    fun createScriptEvent(): ScriptEventViewModel? { /*@DONE BlockMapViewModel.CreateScriptEvent/1 cs:2040-2048*/
        val mapModel = getMapModel() ?: return null
        val events = mapModel.getSubTable("events")?.get(0) ?: return null
        val element = addEvent(events, tokenFactory, "scriptCount", "scripts")
        val newEvent = ScriptEventViewModel({ a -> gotoAddress(a) }, element, eventTemplate)
        newEvent.x = 0
        newEvent.y = 0
        newEvent.elevation = 0
        newEvent.index = 0
        newEvent.trigger = 0
        newEvent.scriptAddress = Pointer.null_
        selectedEvent = newEvent
        return newEvent
    }
    fun createSignpostEvent(): SignpostEventViewModel? { /*@DONE BlockMapViewModel.CreateSignpostEvent/1 cs:2050-2058*/
        val mapModel = getMapModel() ?: return null
        val events = mapModel.getSubTable("events")?.get(0) ?: return null
        val element = addEvent(events, tokenFactory, "signpostCount", "signposts")
        val newEvent = SignpostEventViewModel(element, { a -> gotoAddress(a) })
        newEvent.x = 0
        newEvent.y = 0
        newEvent.elevation = 0
        newEvent.kind = 0
        newEvent.pointer = Pointer.null_
        selectedEvent = newEvent
        return newEvent
    }
    val canCreateFlyEvent: Boolean
        get() { /*@DONE BlockMapViewModel.CanCreateFlyEvent.get cs:2061-2069*/
            val mapElement = getMapModel() ?: return false
            var region = mapElement.getValue(Format.regionSection)
            if (model.isFRLG()) region -= 88
            val connections = model.getTableModel(HardcodeTablesModel.flyConnections) ?: return false
            if (region < 0 || region >= connections.size) return false
            return connections[region].getValue("flight") == 0
        }
    fun createFlyEvent(): FlyEventViewModel? { /*@DONE BlockMapViewModel.CreateFlyEvent/1 cs:2072-2110*/
        val mapElement = getMapModel() ?: return null
        var region = mapElement.getValue(Format.regionSection)
        if (model.isFRLG()) region -= 88
        val connections = model.getTableModel(HardcodeTablesModel.flyConnections, tokenFactory) ?: return null
        if (region < 0 || region >= connections.size) return null
        val flight = connections[region].getValue("flight")
        if (flight != 0) return null
        var spawns = model.getTableModel(HardcodeTablesModel.flySpawns, tokenFactory) ?: return null

        // hunt for an available spawn location
        var emptySpawn = -1
        for (i in 0 until spawns.size) {
            if (spawns[i].getValue("x") == 0 && spawns[i].getValue("y") == 0 && spawns[i].getValue("bank") == 0 && spawns[i].getValue("map") == 0) {
                emptySpawn = i
                break
            }
        }

        // if there were no empty entries in the table, add a new one
        if (emptySpawn == -1) {
            var newSpawns = model.relocateForExpansion(tokenFactory(), spawns.run, spawns.run.length + spawns.run.elementLength)
            newSpawns = newSpawns.append(tokenFactory(), 1)
            model.observeRunWritten(tokenFactory(), newSpawns)
            if (newSpawns.start != spawns.run.start) informRepoint(DataMovedEventArgs("Fly Spawns", newSpawns.start))
            spawns = ModelTable(model, newSpawns, tokenFactory)
            emptySpawn = spawns.size - 1
        }

        // update the connections and spawn table
        connections[region].setValue("flight", emptySpawn + 1)
        connections[region].setValue("bank", group)
        connections[region].setValue("map", this.map)
        spawns[emptySpawn].setValue("bank", group)
        spawns[emptySpawn].setValue("map", this.map)

        notifyPropertyChanged("canCreateFlyEvent")
        return FlyEventViewModel(spawns[emptySpawn], group, this.map, emptySpawn + 1)
    }
    fun addEvent(events: ModelArrayElement, tokenFactory: () -> ModelDelta, countName: String, fieldName: String): ModelArrayElement { /*@DONE BlockMapViewModel.AddEvent/1 cs:2113-2135*/
        val eventModel = events.model!!
        val count = events.getValue(countName)
        var elementTable: ITableRun? = events.getSubTable(fieldName)?.run
        if (count == 0 || elementTable == null) {
            val segment = events.table.elementContent.single { seg -> seg.name == fieldName } as ArrayRunPointerSegment
            val divider = segment.innerFormat.lastIndexOf("/")
            val newTableStart = eventModel.findFreeSpace(eventModel.freeSpaceStart, 24)
            var childContent = segment.innerFormat.substring(0, divider)
            childContent = childContent.substring(1, childContent.length - 1)
            val lengthToken = segment.innerFormat.substring(divider)
            val childSegments = ArrayRun.parseSegments(childContent, eventModel)
            val parentStrategy = TableStreamRun.parseEndStream(eventModel, fieldName, lengthToken, childSegments, events.table.elementContent)!!
            var sourceOffset = 0
            for (seg in events.table.elementContent) {
                if (seg.name == fieldName) break
                sourceOffset += seg.length
            }
            elementTable = TableStreamRun(eventModel, newTableStart, SortedSpanStatic.one(sourceOffset + events.table.start), segment.innerFormat, childSegments, parentStrategy, 0)
            events.setAddress(fieldName, newTableStart)
        }
        val token = tokenFactory()
        val newRun = elementTable!!.append(token, 1)
        val nextRun = eventModel.getNextRun(newRun.start + 1)
        if (nextRun == null || nextRun.start != newRun.start) eventModel.clearFormat(token, newRun.start + 1, newRun.length - 1)
        eventModel.observeRunWritten(token, newRun)
        if (newRun.start != elementTable.start) informRepoint(DataMovedEventArgs(fieldName, newRun.start))
        return ModelArrayElement(eventModel, newRun.start, newRun.elementCount - 1, tokenFactory, newRun)
    }
    private fun erase(table: ITableRun, token: ModelDelta) { /*@DONE BlockMapViewModel.Erase/1 cs:2137-2143*/
        val sources = table.pointerSources
        if (sources != null) {
            for (source in sources.toList()) {
                model.clearPointer(token, source, table.start)
                model.writePointer(token, source, Pointer.null_)
            }
        }
        model.clearData(token, table.start, table.length)
    }
    private fun updateLayoutID() { /*@DONE BlockMapViewModel.UpdateLayoutID/1 cs:2145-2150*/
        val message = updateLayoutID(model, group, map, tokenFactory)
        if (message != null) {
            informRepoint(message)
        }
    }
    private fun getBlockSize(layout: ModelArrayElement? = null): Pair<Int, Int> { /*@DONE BlockMapViewModel.GetBlockSize/1 cs:2181-2185*/
        val border = getBorderThickness(layout)
        return Pair(_pixelWidth / 16 - border.west - border.east, _pixelHeight / 16 - border.north - border.south)
    }
    private fun getNeighbor(connection: ConnectionModel, border: Border): BlockMapViewModel { /*@DONE BlockMapViewModel.GetNeighbor/1 cs:2187-2206*/
        val vm = BlockMapViewModel(fileSystem, tutorials, viewPort, format, eventTemplate, connection.mapGroup, connection.mapNum)
        vm.includeBorders = includeBorders
        vm.spriteScale = spriteScale
        vm.allOverworldSprites = allOverworldSprites
        vm.berryInfo = berryInfo
        vm.collisionHighlight = collisionHighlight
        vm.showEvents = showEvents
        val neighborBorder = vm.getBorderThickness()
        val n = neighborBorder.north
        val w = neighborBorder.west
        vm.topEdge = topEdge + (connection.offset + border.north - n) * (16 * spriteScale).toInt()
        vm.leftEdge = leftEdge + (connection.offset + border.west - w) * (16 * spriteScale).toInt()
        if (connection.direction == MapDirection.Left) vm.leftEdge = leftEdge - (vm.pixelWidth * spriteScale).toInt()
        if (connection.direction == MapDirection.Right) vm.leftEdge = leftEdge + (pixelWidth * spriteScale).toInt()
        if (connection.direction == MapDirection.Up) vm.topEdge = topEdge - (vm.pixelHeight * spriteScale).toInt()
        if (connection.direction == MapDirection.Down) vm.topEdge = topEdge + (pixelHeight * spriteScale).toInt()
        vm.zIndex = zIndex
        if (connection.direction.isAny(MapDirection.Dive, MapDirection.Emerge)) vm.zIndex = zIndex - 1
        return vm
    }
    private fun refreshPaletteCache(layout: ModelArrayElement? = null, blockModel1: BlocksetModel? = null, blockModel2: BlocksetModel? = null) { /*@DONE BlockMapViewModel.RefreshPaletteCache/1 cs:2208-2217*/
        val layoutElement = if (blockModel1 == null || blockModel2 == null) (layout ?: getLayout() ?: return) else layout
        val b1 = blockModel1 ?: BlocksetModel(model, layoutElement!!.getAddress(Format.primaryBlockset))
        val b2 = blockModel2 ?: BlocksetModel(model, layoutElement!!.getAddress(Format.secondaryBlockset))

        palettes = BlockmapRun.readPalettes(b1, b2, primaryPalettes)
        val newPalettes = palettes
        if (newPalettes != null) _blockEditor?.refreshPaletteCache(newPalettes)
    }
    private fun refreshTileCache(layout: ModelArrayElement? = null, blockModel1: BlocksetModel? = null, blockModel2: BlocksetModel? = null) { /*@DONE BlockMapViewModel.RefreshTileCache/1 cs:2219-2228*/
        val layoutElement = if (blockModel1 == null || blockModel2 == null) (layout ?: getLayout() ?: return) else layout
        val b1 = blockModel1 ?: BlocksetModel(model, layoutElement!!.getAddress("blockdata1"))
        val b2 = blockModel2 ?: BlocksetModel(model, layoutElement!!.getAddress("blockdata2"))

        tiles = BlockmapRun.readTiles(b1, b2, primaryTiles)
        val newTiles = tiles
        if (newTiles != null) _blockEditor?.refreshTileCache(newTiles)
    }
    private fun refreshBlockCache(layout: ModelArrayElement? = null, blockModel1: BlocksetModel? = null, blockModel2: BlocksetModel? = null) { /*@DONE BlockMapViewModel.RefreshBlockCache/1 cs:2230-2245*/
        val layoutElement = layout ?: getLayout() ?: return
        val b1 = blockModel1 ?: BlocksetModel(model, layoutElement.getAddress(Format.primaryBlockset))
        val b2 = blockModel2 ?: BlocksetModel(model, layoutElement.getAddress(Format.secondaryBlockset))
        if (!b1.start.inRange(0, model.count) || !b2.start.inRange(0, model.count)) return

        val width = layoutElement.getValue("width")
        val height = layoutElement.getValue("height")
        val start = layoutElement.getAddress(Format.blockMap)
        val maxUsedPrimary = BlockmapRun.getMaxUsedBlock(model, start, width, height, primaryBlocks)
        val maxUsedSecondary = BlockmapRun.getMaxUsedBlock(model, start, width, height, 1024) - primaryBlocks

        blocks = BlockmapRun.readBlocks(maxUsedPrimary, maxUsedSecondary, b1, b2)
        val newBlocks = blocks
        if (newBlocks != null) _blockEditor?.refreshBlockCache(newBlocks)
    }
    private fun refreshBlockAttributeCache(layout: ModelArrayElement? = null, blockModel1: BlocksetModel? = null, blockModel2: BlocksetModel? = null) { /*@DONE BlockMapViewModel.RefreshBlockAttributeCache/1 cs:2247-2263*/
        val layoutElement = layout ?: getLayout() ?: return
        val b1 = blockModel1 ?: BlocksetModel(model, layoutElement.getAddress("blockdata1"))
        val b2 = blockModel2 ?: BlocksetModel(model, layoutElement.getAddress("blockdata2"))
        if (!b1.start.inRange(0, model.count) || !b2.start.inRange(0, model.count)) return

        val width = layoutElement.getValue("width")
        val height = layoutElement.getValue("height")
        val start = layoutElement.getAddress(Format.blockMap)
        val maxUsedPrimary = BlockmapRun.getMaxUsedBlock(model, start, width, height, primaryBlocks)
        val maxUsedSecondary = BlockmapRun.getMaxUsedBlock(model, start, width, height, 1024) - primaryBlocks

        blockAttributes = BlockmapRun.readBlockAttributes(maxUsedPrimary, maxUsedSecondary, b1, b2)
        val newAttributes = blockAttributes
        if (newAttributes != null) _blockEditor?.refreshBlockAttributeCache(newAttributes)
    }
    private fun refreshBlockRenderCache(layout: ModelArrayElement? = null, blockModel1: BlocksetModel? = null, blockModel2: BlocksetModel? = null) { /*@DONE BlockMapViewModel.RefreshBlockRenderCache/1 cs:2265-2284*/
        val layoutElement = layout ?: getLayout() ?: return
        val b1 = blockModel1 ?: BlocksetModel(model, layoutElement.getAddress(Format.primaryBlockset))
        val b2 = blockModel2 ?: BlocksetModel(model, layoutElement.getAddress(Format.secondaryBlockset))
        if (!b1.start.inRange(0, model.count) || !b2.start.inRange(0, model.count)) return

        synchronized(_blockRenders) {
            if (blocks == null) refreshBlockCache(layoutElement, b1, b2)
            if (blockAttributes == null) refreshBlockAttributeCache(layoutElement, b1, b2)
            if (tiles == null) refreshTileCache(layoutElement, b1, b2)
            if (palettes == null) refreshPaletteCache(layoutElement, b1, b2)
            _blockRenders.clear()
            val cachedBlocks = blocks
            val cachedAttributes = blockAttributes
            val cachedTiles = tiles
            val cachedPalettes = palettes
            if (cachedBlocks != null && cachedAttributes != null && cachedTiles != null && cachedPalettes != null) {
                _blockRenders.addAll(BlockmapRun.calculateBlockRenders(cachedBlocks, cachedAttributes, cachedTiles, cachedPalettes.map { p -> p.asList() }.toTypedArray()))
            }
        }
    }
    private fun refreshMapSize(clearPixels: Boolean = true) { /*@DONE BlockMapViewModel.RefreshMapSize/1 cs:2286-2293*/
        val layout = getLayout() ?: return
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val border = getBorderThickness(layout)
        _pixelWidth = (width + border.west + border.east) * 16
        _pixelHeight = (height + border.north + border.south) * 16
        if (clearPixels) clearPixelCache()
    }
    private fun refreshMapEvents(layout: ModelArrayElement) { /*@DONE BlockMapViewModel.RefreshMapEvents/1 cs:2295-2305*/
        if (eventRenders != null) return
        val layoutModel = LayoutModel(layout)
        val list = ArrayList<IEventViewModel>()
        val events = getEvents()
        for (obj in events) {
            obj.render(model, layoutModel)
            list.add(obj)
        }
        eventRenders = list
    }
    private fun fillMapPixelData() { /*@DONE BlockMapViewModel.FillMapPixelData/1 cs:2307-2386*/
        val layout = getLayout() ?: return
        synchronized(_blockRenders) {
            if (_blockRenders.size == 0) refreshBlockRenderCache(layout)
        }
        // race condition: borderblock might be erased while we're drawing
        val borderBlockCopy: IPixelViewModel = _borderBlock ?: refreshBorderRender()
        val width = layout.getValue("width")
        val height = layout.getValue("height")
        val border = getBorderThickness(layout)
        val start = layout.getAddress("blockmap")
        val blockHighlight = _blockEditor?.blockIndex ?: -1
        val selectedEvent = this._selectedEvent // threading protection

        val canvas = CanvasPixelViewModel(_pixelWidth, _pixelHeight)
        val borderWidth = borderBlockCopy.pixelWidth / 16
        val borderHeight = borderBlockCopy.pixelHeight / 16
        for (y in 0 until height + border.north + border.south) {
            for (x in 0 until width + border.west + border.east) {
                if ((y < border.north || x < border.west || y >= border.north + height || x >= border.west + width) && borderWidth > 0 && borderHeight > 0) {
                    val xEdge = x - border.west - width
                    val yEdge = y - border.north - height
                    val rightEdge = xEdge >= 0
                    val bottomEdge = yEdge >= 0
                    // top/left
                    if (!rightEdge && !bottomEdge && x % borderWidth == 0 && y % borderHeight == 0) canvas.draw(borderBlockCopy, x * 16, y * 16)
                    // right edge
                    if (rightEdge && !bottomEdge && xEdge % borderWidth == 0 && y % borderHeight == 0) canvas.draw(borderBlockCopy, x * 16, y * 16)
                    // bottom edge
                    if (!rightEdge && bottomEdge && x % borderWidth == 0 && yEdge % borderHeight == 0) canvas.draw(borderBlockCopy, x * 16, y * 16)
                    // bottom right corner
                    if (rightEdge && bottomEdge && xEdge % borderWidth == 0 && yEdge % borderHeight == 0) canvas.draw(borderBlockCopy, x * 16, y * 16)
                    continue
                }
                val dataStart = start + ((y - border.north) * width + x - border.west) * 2
                val rawData = if (dataStart.inRange(0, model.count - 2)) model.readMultiByteValue(dataStart, 2) else 0
                val collision = rawData shr 10
                val data = rawData and 0x3FF
                synchronized(_blockRenders) {
                    if (_blockRenders.size > data) canvas.draw(_blockRenders[data], x * 16, y * 16)
                }
                if (_showEvents != MapDisplayOptions.NoEvents) {
                    if (collision == _collisionHighlight) highlightCollision(canvas.pixelData, x * 16, y * 16)
                    if (_collisionHighlight == -1 && selectedEvent is ObjectEventViewModel && selectedEvent.shouldHighlight(x - border.west, y - border.north)) {
                        highlightCollision(canvas.pixelData, x * 16, y * 16)
                    }
                    if (_collisionHighlight != -1 && blockHighlight != -1 && collision != _collisionHighlight && data == blockHighlight) {
                        // this matches the chosen block, but not the chosen collision
                        highlightBlock(canvas.pixelData, x * 16, y * 16)
                    }
                }
            }
        }

        // draw the box for the selected event
        val gray = UncompressedPaletteColor.pack(6, 6, 6)
        if (selectedEvent != null && selectedEvent.x >= 0 && selectedEvent.x < width && selectedEvent.y >= 0 && selectedEvent.y < height) {
            canvas.drawBox((selectedEvent.x + border.west) * 16, (selectedEvent.y + border.north) * 16, 16, gray)
        }

        // now draw the events on top
        if (_showEvents != MapDisplayOptions.NoEvents) {
            if (eventRenders == null) refreshMapEvents(layout)
            val renders = eventRenders
            if (renders != null) {
                for (obj in renders) {
                    val eventImage = obj.eventRender
                    if (eventImage != null) {
                        if (obj is ObjectEventViewModel || _showEvents == MapDisplayOptions.AllEvents) {
                            val ex = (obj.x + border.west) * 16 + obj.leftOffset
                            val ey = (obj.y + border.north) * 16 + obj.topOffset
                            canvas.draw(eventImage, ex, ey)
                        }
                    }
                }
            }
        }

        // finally, draw a one-pixel border around the entire map (but not the border blocks)
        if (_isSelected) {
            val borderW = border.west + border.east
            val borderH = border.north + border.south
            canvas.darkenRect(border.west * 16, border.north * 16, _pixelWidth - borderW * 16, _pixelHeight - borderH * 16, 12)
        }

        _pixelData = canvas.pixelData
    }
    private fun highlightCollision(pixelData: ShortArray, x: Int, y: Int) { /*@DONE BlockMapViewModel.HighlightCollision/1 cs:2388-2390*/
        CanvasPixelViewModel(pixelWidth, pixelHeight, pixelData).darkenRect(x, y, 16, 16, 8)
    }
    private fun highlightBlock(pixelData: ShortArray, x: Int, y: Int) { /*@DONE BlockMapViewModel.HighlightBlock/1 cs:2392-2403*/
        val width = pixelWidth
        fun transform(xx: Int, yy: Int) {
            val p = (y + yy) * width + x + xx
            pixelData[p] = CanvasPixelViewModel.shiftTowards(pixelData[p], CanvasPixelViewModelShiftTowardsTargetColorTuple(31, 31, 0), 8) // yellow
        }
        for (i in 0 until 15) {
            transform(i, 0)
            transform(15 - i, 15)
            transform(0, 15 - i)
            transform(15, i)
        }
    }
    private fun fillBlockPixelData() { /*@DONE BlockMapViewModel.FillBlockPixelData/1 cs:2406-2423*/
        val layout = getLayout()
        synchronized(_blockRenders) {
            if (_blockRenders.size == 0) refreshBlockRenderCache(layout)
        }

        val blockHeight = Math.ceil(_blockRenders.size.toDouble() / blocksPerRow).toInt()
        val canvas = CanvasPixelViewModel(blocksPerRow * 16, blockHeight * 16)
        canvas.spriteScale = 2.0

        for (y in 0 until blockHeight) {
            for (x in 0 until blocksPerRow) {
                if (_blockRenders.size <= y * blocksPerRow + x) break
                canvas.draw(_blockRenders[y * blocksPerRow + x], x * 16, y * 16)
            }
        }

        _blockPixels = canvas
    }
    private fun refreshBorderRender(layout: ModelArrayElement? = null): IPixelViewModel { /*@DONE BlockMapViewModel.RefreshBorderRender/1 cs:2425-2449*/
        val layoutElement = layout ?: getLayout()
        synchronized(_blockRenders) {
            if (_blockRenders.size == 0) refreshBlockRenderCache(layoutElement)
        }
        val width = if (layoutElement != null && layoutElement.hasField("borderwidth")) layoutElement.getValue("borderwidth") else 2
        val height = if (layoutElement != null && layoutElement.hasField("borderheight")) layoutElement.getValue("borderheight") else 2
        if (layoutElement == null) return CanvasPixelViewModel(width * 16, height * 16)

        val start = layoutElement.getAddress("borderblock")
        val canvas = CanvasPixelViewModel(width * 16, height * 16)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val address = start + (y * width + x)
                if (address + 2 >= model.count || address < 0) continue
                val data = model.readMultiByteValue(start + (y * width + x) * 2, 2) and 0x3FF
                synchronized(_blockRenders) {
                    if (!data.inRange(0, _blockRenders.size)) return@synchronized // can't draw this block. Transient race condition?
                    canvas.draw(_blockRenders[data], x * 16, y * 16)
                }
            }
        }

        borderBlock = canvas
        return canvas
    }
    fun getMapModel(): ModelArrayElement? { /*@DONE BlockMapViewModel.GetMapModel/1 cs:2451-2451*/
        return getMapModel(model, group, map, tokenFactory)
    }
    fun getLayout(map: ModelArrayElement? = null): ModelArrayElement? { /*@DONE BlockMapViewModel.GetLayout/1 cs:2465-2471*/
        val mapElement = map ?: getMapModel() ?: return null
        val layoutTable = mapElement.getSubTable("layout") ?: return null
        return layoutTable[0]
    }
    private fun getConnections(): List<ConnectionModel>? { /*@DONE BlockMapViewModel.GetConnections/1 cs:2473-2476*/
        val mapElement = getMapModel(model, group, this.map, tokenFactory)
        return getConnections(mapElement, group, this.map)
    }
    private var defaultOverworldSprite: IPixelViewModel? = null
    private var _allOverworldSprites: List<IPixelViewModel>? = null
    var allOverworldSprites: List<IPixelViewModel>
        get() { /*@DONE BlockMapViewModel.AllOverworldSprites.get cs:2494-2497*/
            var sprites = _allOverworldSprites
            if (sprites == null) {
                sprites = renderOWs(model)
                _allOverworldSprites = sprites
            }
            return sprites
        }
        set(value) { /*@DONE BlockMapViewModel.AllOverworldSprites.set cs:2498-2498*/
            _allOverworldSprites = value
        }
    val eventGroup: EventGroupModel?
        get() { /*@DONE BlockMapViewModel.EventGroup.get cs:2523-2535*/
            val sprites = allOverworldSprites
            if (defaultOverworldSprite == null) defaultOverworldSprite = getDefaultOW(model)
            val mapElement = getMapModel() ?: return null
            val eventsTable = mapElement.getSubTable("events") ?: return null
            val eventElements = eventsTable[0]
            val events = EventGroupModel(this, { a -> gotoAddress(a) }, { b, m -> gotoBankMap(b, m) }, eventElements, eventTemplate, sprites, defaultOverworldSprite!!, berryInfo, group, this.map)
            events.dataMoved += eventDataMovedHandler
            return events
        }
    private fun getEvents(): List<IEventViewModel> { /*@DONE BlockMapViewModel.GetEvents/1 cs:2538-2548*/
        val results = ArrayList<IEventViewModel>()
        val events = eventGroup ?: return results
        results.addAll(events.objects)
        results.addAll(events.warps)
        results.addAll(events.scripts)
        results.addAll(events.signposts)
        results.addAll(events.flyEvents)
        return results
    }
    fun getBorderThickness(layout: ModelArrayElement? = null): Border { /*@DONE BlockMapViewModel.GetBorderThickness/1 cs:2550-2565*/
        if (!_includeBorders) return Border(0, 0, 0, 0)
        val connections = getConnections() ?: return Border(0, 0, 0, 0)
        val layoutElement = layout ?: getLayout() ?: return Border(0, 0, 0, 0)
        val width = if (layoutElement.hasField("borderwidth")) layoutElement.getValue("borderwidth") else 2
        val height = if (layoutElement.hasField("borderheight")) layoutElement.getValue("borderheight") else 2
        var east = width
        var west = width
        var north = height
        var south = height
        val directions = connections.map { c -> c.direction }
        if (directions.contains(MapDirection.Down)) south = 0
        if (directions.contains(MapDirection.Up)) north = 0
        if (directions.contains(MapDirection.Left)) west = 0
        if (directions.contains(MapDirection.Right)) east = 0
        return Border(north, east, south, west)
    }
    private fun canConnect(direction: MapDirection): ConnectionInfo? { /*@DONE BlockMapViewModel.CanConnect/1 cs:2567-2647*/
        val connections: List<ConnectionModel> = getConnections() ?: ArrayList()
        val width = _pixelWidth / 16
        val height = _pixelHeight / 16
        val dimensionLength = when (direction) {
            MapDirection.Up -> width
            MapDirection.Down -> width
            MapDirection.Left -> height
            MapDirection.Right -> height
            MapDirection.Dive -> 0
            MapDirection.Emerge -> 0
            else -> throw NotImplementedError()
        }
        val availableSpace: MutableList<Int> = ArrayList()
        for (i in 0 until dimensionLength) availableSpace.add(i)

        // can't add a connection where there already is one
        for (connection in connections) {
            if (connection.direction != direction) continue
            if (direction == MapDirection.Up || direction == MapDirection.Down) {
                val other = BlockMapViewModel(fileSystem, tutorials, viewPort, format, eventTemplate, connection.mapGroup, connection.mapNum)
                other.allOverworldSprites = allOverworldSprites
                other.berryInfo = berryInfo
                val removeWidth = other._pixelWidth / 16
                val removeOffset = connection.offset
                for (j in 0 until removeWidth) availableSpace.remove(j + removeOffset)
            } else if (direction == MapDirection.Left || direction == MapDirection.Right) {
                val other = BlockMapViewModel(fileSystem, tutorials, viewPort, format, eventTemplate, connection.mapGroup, connection.mapNum)
                other.allOverworldSprites = allOverworldSprites
                other.berryInfo = berryInfo
                val removeHeight = other._pixelHeight / 16
                val removeOffset = connection.offset
                for (j in 0 until removeHeight) availableSpace.remove(j + removeOffset)
            } else if (direction.isAny(MapDirection.Dive, MapDirection.Emerge)) {
                // can't dive or emerge to a map that already has a dive/emerge
                val otherMapModel = AllMapsModel.create(model, tokenFactory)[connection.mapGroup]?.get(connection.mapNum)
                val otherConnections = otherMapModel?.connections
                if (otherConnections != null && otherConnections.any { c -> c.direction.isAny(MapDirection.Emerge, MapDirection.Dive) }) return null
            }
        }

        if (direction.isAny(MapDirection.Dive, MapDirection.Emerge)) {
            val ownLayout = AllMapsModel.create(model, tokenFactory)[group]?.get(map)?.layout ?: return null
            return ConnectionInfo(ownLayout.width, ownLayout.height, direction)
        }

        // find the longest stretch of available space
        var longestSpanLength = 0
        var longestSpanStart = -1
        var spanLength = 0
        var spanStart = -1
        for (j in availableSpace.indices) {
            if (spanStart == -1) {
                spanStart = j
                spanLength = 1
            } else if (availableSpace[j - 1] + 1 == availableSpace[j]) {
                spanLength++
            } else {
                if (spanLength > longestSpanLength) {
                    longestSpanStart = spanStart
                    longestSpanLength = spanLength
                }
                spanStart = j
                spanLength = 1
            }
        }

        if (spanLength > longestSpanLength) {
            longestSpanStart = spanStart
            longestSpanLength = spanLength
        }

        // if a long space is availabe, we can connect to it
        // otherwise, we could technically connect to an edge
        if (longestSpanLength > 3) {
            // we can make a map here of width/height longestSpanLength
            // and the offset is availableSpace[longestSpanStart]
            return ConnectionInfo(longestSpanLength, availableSpace[longestSpanStart], direction)
        } else if (availableSpace.contains(0)) {
            // we can make a map here of width/height 4
            // and the offset is -3
            return ConnectionInfo(4, -3, direction)
        } else if (availableSpace.contains(dimensionLength - 1)) {
            // we can make a map here of width/height 4
            // and the offset is dimensionLength-1
            return ConnectionInfo(4, dimensionLength - 1, direction)
        }

        return null
    }
    private fun writePointerAndSource(token: ModelDelta, source: Int, destination: Int) { /*@DONE BlockMapViewModel.WritePointerAndSource/1 cs:2649-2652*/
        model.writePointer(token, source, destination)
        model.observeRunWritten(token, NoInfoRun.fromPointer(model, source))
    }
    private fun gotoAddress(address: Int) { /*@DONE BlockMapViewModel.GotoAddress/1 cs:2654-2654*/
        gotoAddress(viewPort, address)
    }
    private fun gotoBankMap(bank: Int, map: Int) { /*@DONE BlockMapViewModel.GotoBankMap/1 cs:2655-2655*/
        viewPort.mapEditor!!.navigateTo(bank, map, Int.MIN_VALUE, Int.MIN_VALUE)
    }
    private fun handleBlocksChanged(sender: Any?, blocks: Array<ByteArray>) { /*@DONE BlockMapViewModel.HandleBlocksChanged/1 cs:2672-2688*/
        val layout = getLayout() ?: return
        val layoutModel = LayoutModel(layout)

        val blockmapRun = model.getNextRun(layoutModel.blockMap.start) as? BlockmapRun
        if (blockmapRun != null) {
            val blockModel1 = layoutModel.primaryBlockset!!.fullBlocksetModel
            val blockModel2 = layoutModel.secondaryBlockset!!.fullBlocksetModel
            var primaryMax = BlockmapRun.getMaxUsedBlock(model, blockmapRun.start, blockmapRun.blockWidth, blockmapRun.blockHeight, blockmapRun.primaryBlocks)
            var secondaryMax = BlockmapRun.getMaxUsedBlock(model, blockmapRun.start, blockmapRun.blockWidth, blockmapRun.blockHeight, 1024) - blockmapRun.primaryBlocks
            primaryMax = Math.max(primaryMax, mapRepointer.estimateBlockCount(layout, true).currentCount)
            secondaryMax = Math.max(secondaryMax, mapRepointer.estimateBlockCount(layout, false).currentCount)
            BlockmapRun.writeBlocks(tokenFactory, primaryMax, secondaryMax, blockModel1, blockModel2, blocks)
        }

        viewPort.changeHistory.changeCompleted()
        requestClearMapCaches(this, EventArgs.empty)
    }
    private fun handleBorderChanged(sender: Any?, e: EventArgs) { /*@DONE BlockMapViewModel.HandleBorderChanged/1 cs:2690-2692*/
        requestClearMapCaches(this, EventArgs.empty)
    }
    private fun handleBlockAttributesChanged(sender: Any?, attributes: Array<ByteArray>) { /*@DONE BlockMapViewModel.HandleBlockAttributesChanged/1 cs:2694-2710*/
        val layout = getLayout() ?: return
        val layoutModel = LayoutModel(layout)

        val blockmapRun = model.getNextRun(layoutModel.blockMap.start) as? BlockmapRun
        if (blockmapRun != null) {
            val blockModel1 = layoutModel.primaryBlockset!!.fullBlocksetModel
            val blockModel2 = layoutModel.secondaryBlockset!!.fullBlocksetModel
            var primaryMax = BlockmapRun.getMaxUsedBlock(model, blockmapRun.start, blockmapRun.blockWidth, blockmapRun.blockHeight, blockmapRun.primaryBlocks)
            var secondaryMax = BlockmapRun.getMaxUsedBlock(model, blockmapRun.start, blockmapRun.blockWidth, blockmapRun.blockHeight, 1024) - blockmapRun.primaryBlocks
            primaryMax = Math.max(primaryMax, mapRepointer.estimateBlockCount(layout, true).currentCount)
            secondaryMax = Math.max(secondaryMax, mapRepointer.estimateBlockCount(layout, false).currentCount)
            BlockmapRun.writeBlockAttributes(tokenFactory, primaryMax, secondaryMax, blockModel1, blockModel2, attributes)
        }

        viewPort.changeHistory.changeCompleted()
        requestClearMapCaches(this, EventArgs.empty)
    }
    private fun handleAutoscrollTiles(sender: Any?, e: EventArgs) { /*@DONE BlockMapViewModel.HandleAutoscrollTiles/1 cs:2712-2712*/
        autoscrollTiles(this, EventArgs.empty)
    }
    private fun handleEventDataMoved(sender: Any?, e: DataMovedEventArgs?) { /*@DONE BlockMapViewModel.HandleEventDataMoved/1 cs:2714-2714*/
        if (e != null) informRepoint(e)
    }
    private var dynamicOverworldSprites: Array<MutableList<Int>?>? = null
    private fun loadDynamicOverworldSprites() { /*@DONE BlockMapViewModel.LoadDynamicOverworldSprites/1 cs:2747-2772*/
        if (dynamicOverworldSprites != null) return
        val sprites = arrayOfNulls<MutableList<Int>>(0x10)
        dynamicOverworldSprites = sprites
        val collection = MapScriptCollection(viewPort, eventTemplate)
        collection.load(getMapModel())
        val checkAddresses = HashSet<Int>()
        for (script in collection.scripts) {
            if (script.hasSubScripts) {
                for (sub in script.subScripts) {
                    checkAddresses.add(sub.scriptAddress)
                }
            } else {
                checkAddresses.add(script.scriptAddress)
            }
        }
        // look for all the map scripts
        // look for places where we load dynamic sprites
        val parser = viewPort.tools?.codeTool?.scriptParser ?: return
        val setvarSpots = Flags.getAllScriptSpots(model, parser, checkAddresses, 0x16)
        for (spot in setvarSpots) {
            val graphicsSlot = model.readMultiByteValue(spot.address + 1, 2) - 0x4010 // 0x4010=gfx0
            if (!graphicsSlot.inRange(0, sprites.size)) continue
            var slotList = sprites[graphicsSlot]
            if (slotList == null) {
                slotList = ArrayList()
                sprites[graphicsSlot] = slotList
            }
            slotList.add(model.readMultiByteValue(spot.address + 3, 2))
        }
        // the first one will be shown directly, the rest are available through the tooltip?
    }
    companion object {
        private val mapSizeLimit: Int
            get() { /*@DONE BlockMapViewModel.MapSizeLimit.get cs:147-147*/
                return 0x2800 // (x+15)*(y+14) must be less that 0x2800 (5*2048). This can lead to limits like 113x66 or 497x6
            }
        fun isMapWithinSizeLimit(width: Int, height: Int): Boolean { /*@DONE BlockMapViewModel.IsMapWithinSizeLimit/1 cs:148-148*/
            return (width + 15) * (height + 14) <= mapSizeLimit
        }
        fun sanitizeName(name: String): String { /*@DONE BlockMapViewModel.SanitizeName/1 cs:391-393*/
            return name.replace("\\CC0000", " ")
        }
        fun get9GridBlock(map: Array<BooleanArray>, p: Point, grid9: Array<IntArray>, corners: Array<IntArray>): Int { /*@DONE BlockMapViewModel.Get9GridBlock/1 cs:1085-1140*/
            var neighborhood = 0
            val mapWidth = map.size
            val mapHeight = if (map.isEmpty()) 0 else map[0].size
            for (y in -1 until 2) {
                for (x in -1 until 2) {
                    if (!(p.x + x).inRange(0, mapWidth) || !(p.y + y).inRange(0, mapHeight)) continue
                    val bit = 8 - ((y + 1) * 3 + x + 1)
                    neighborhood = neighborhood or ((if (map[p.x + x][p.y + y]) 1 else 0) shl bit)
                }
            }

            return when (neighborhood) {
                // normal corners - 4 varients of each (2 corners don't matter)
                0b110_110_000, 0b110_110_100, 0b111_110_100, 0b111_110_000 -> grid9[2][2] // bottom-right
                0b011_011_000, 0b011_011_001, 0b111_011_001, 0b111_011_000 -> grid9[0][2] // bottom-left
                0b000_110_110, 0b100_110_110, 0b100_110_111, 0b000_110_111 -> grid9[2][0] // top-right
                0b000_011_011, 0b001_011_011, 0b000_011_111, 0b001_011_111 -> grid9[0][0] // top-left

                // edges - 4 variants of each (2 corners don't matter)
                0b111_111_000, 0b111_111_100, 0b111_111_001, 0b111_111_101 -> grid9[1][2] // bottom
                0b000_111_111, 0b100_111_111, 0b001_111_111, 0b101_111_111 -> grid9[1][0] // top
                0b011_011_011, 0b111_011_011, 0b011_011_111, 0b111_011_111 -> grid9[0][1] // left
                0b110_110_110, 0b111_110_110, 0b110_110_111, 0b111_110_111 -> grid9[2][1] // right

                // inside corners
                0b111_111_110 -> corners[0][0]
                0b111_111_011 -> corners[1][0]
                0b110_111_111 -> corners[0][1]
                0b011_111_111 -> corners[1][1]

                else -> grid9[1][1]
            }
        }
        private fun getUncollapsedNeighbors(point: Point, toDraw: MutableMap<Point, WaveCell>): MutableList<WaveSpot> { /*@DONE BlockMapViewModel.GetUncollapsedNeighbors/1 cs:1452-1460*/
            val results = ArrayList<WaveSpot>()
            val right = Point(1, 0)
            val down = Point(0, 1)
            for (direction in listOf(-right - down, -right, -right + down, down, -down, right + down, right, right - down)) {
                val cell = toDraw[point + direction] ?: continue
                results.add(WaveSpot(point + direction, cell))
            }
            return results
        }
        private const val sizeX: Int = 7
        private const val sizeY: Int = 7
        fun updateLayoutID(model: IDataModel, groupID: Int, mapID: Int, tokenFactory: () -> ModelDelta): DataMovedEventArgs? { /*@DONE BlockMapViewModel.UpdateLayoutID/2 cs:2152-2175*/
            // step 1: test if we need to update the layout id
            var layoutTable = model.getTable(HardcodeTablesModel.mapLayoutTable) ?: return null
            val mapElement = getMapModel(model, groupID, mapID, tokenFactory) ?: return null
            val layoutID = mapElement.getValue("layoutID") - 1
            val addressFromMap = mapElement.getAddress("layout")
            val tableAddress = layoutTable.start + layoutTable.elementLength * layoutID
            val addressFromTable = if (tableAddress < 0) Pointer.null_ else model.readPointer(tableAddress)
            if (addressFromMap == addressFromTable) return null

            val matches = ArrayList<Int>()
            for (i in 0 until layoutTable.elementCount) {
                if (model.readPointer(layoutTable.start + layoutTable.elementLength * i) == addressFromMap) matches.add(i)
            }
            val token = tokenFactory()
            var result: DataMovedEventArgs? = null
            if (matches.size == 0) {
                val originalLayoutTableStart = layoutTable.start
                layoutTable = model.relocateForExpansion(token, layoutTable, layoutTable.length + 4)
                layoutTable = layoutTable.append(token, 1)
                model.observeRunWritten(token, layoutTable)
                model.updateArrayPointer(token, layoutTable.elementContent[0], layoutTable.elementContent, -1, layoutTable.start + layoutTable.elementLength * (layoutTable.elementCount - 1), addressFromMap)
                if (originalLayoutTableStart != layoutTable.start) result = DataMovedEventArgs("Layout Table", layoutTable.start)
                matches.add(layoutTable.elementCount - 1)
            }
            mapElement.setValue("layoutID", matches[0] + 1)
            return result
        }
        const val blocksPerRow: Int = 8
        fun getMapModel(model: IDataModel, group: Int, map: Int, tokenFactory: () -> ModelDelta): ModelArrayElement? { /*@DONE BlockMapViewModel.GetMapModel/2 cs:2452-2463*/
            val table = model.getTable(HardcodeTablesModel.mapBankTable) ?: return null
            val mapBanks = ModelTable(model, table.start, tokenFactory)
            if (mapBanks.size <= group) return null
            val bank = mapBanks[group].getSubTable("maps") ?: return null
            if (bank.size <= map) return null
            val mapTable = bank[map].getSubTable("map") ?: return null
            return mapTable[0]
        }
        fun getConnections(map: ModelArrayElement?, bankNum: Int, mapNum: Int): List<ConnectionModel>? { /*@DONE BlockMapViewModel.GetConnections/2 cs:2477-2489*/
            if (map == null) return null
            val connectionsAndCountTable = map.getSubTable("connections")
            val list = ArrayList<ConnectionModel>()
            if (connectionsAndCountTable == null) return list
            val connectionsAndCount = connectionsAndCountTable[0]
            val count = connectionsAndCount.getValue("count")
            if (count == 0) return list
            val connections = connectionsAndCount.getSubTable("connections") ?: return ArrayList()
            for (i in 0 until count) list.add(ConnectionModel(connections[i], bankNum, mapNum))
            return list
        }
        fun getDefaultOW(model: IDataModel): IPixelViewModel { /*@DONE BlockMapViewModel.GetDefaultOW/1 cs:2500-2510*/
            val defaultSpriteAddress = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.pokeIconsTable + "/0/icon/")
            val defaultSpriteRun = model.getNextRun(defaultSpriteAddress) as? ISpriteRun
            var defaultImage: IPixelViewModel = (if (defaultSpriteRun == null) ReadonlyPixelViewModel(16, 16) else model.currentCacheScope.getImage(defaultSpriteRun)) ?: ReadonlyPixelViewModel(16, 16)
            if (defaultImage.pixelHeight > 24) {
                val canvas = CanvasPixelViewModel(defaultImage.pixelWidth, 24)
                canvas.transparent = defaultImage.pixelData[0]
                canvas.draw(defaultImage, 0, 24 - Math.min(32, defaultImage.pixelHeight))
                defaultImage = canvas
            }
            return defaultImage
        }
        fun renderOWs(model: IDataModel): MutableList<IPixelViewModel> { /*@DONE BlockMapViewModel.RenderOWs/1 cs:2511-2520*/
            val list = ArrayList<IPixelViewModel>()
            val run = model.getTable(HardcodeTablesModel.overworldSprites)
            val ows = if (run == null) null else ModelTable(model, run.start, null, run)
            val defaultImage = getDefaultOW(model)
            val count = ows?.size ?: 1
            for (i in 0 until count) {
                list.add(ObjectEventViewModel.render(model, ows, defaultImage, i, -1, { -1 }))
            }
            return list
        }
        fun gotoAddress(viewPort: IEditableViewPort, address: Int) { /*@DONE BlockMapViewModel.GotoAddress/2 cs:2660-2670*/
            val tool = viewPort.tools?.codeTool
            val nextRun = viewPort.model?.getNextRun(address)
            if (tool != null) {
                if (nextRun == null || nextRun.start > address) {
                    viewPort.tools?.selectedTool = tool
                    tool.mode = CodeMode.Script
                } else if (nextRun.start == address && nextRun is XSERun) {
                    tool.scriptParser.formatScript<XSERun>(NoDataChangeDeltaModel(), viewPort.model!!, address)
                }
            }
            viewPort.gotoScript(address)
        }
        fun mapIDToText(model: IDataModel, id: Int): String { /*@DONE BlockMapViewModel.MapIDToText/1 cs:2716-2720*/
            val group = id / 1000
            val map = id % 1000
            return mapIDToText(model, group, map)
        }
        fun mapIDToText(model: IDataModel, group: Int, map: Int): String { /*@DONE BlockMapViewModel.MapIDToText/2 cs:2722-2740*/
            val offset = if (model.isFRLG()) 0x58 else 0

            val bankTable = model.getTable(HardcodeTablesModel.mapBankTable) ?: return "${group}-${map}"
            val mapBanks = ModelTable(model, bankTable.start)
            if (group < 0 || group >= mapBanks.size) return "${group}-${map}"
            val bank = mapBanks[group].getSubTable("maps")
            if (bank == null) return "${group}-${map}"
            if (bank.size <= map) return "${group}-${map}"
            val mapTable = bank[map].getSubTable("map")
            if (mapTable == null) return "${group}-${map}"
            if (!mapTable[0].hasField("regionSectionID")) return "${group}-${map}"
            val key = mapTable[0].getValue("regionSectionID") - offset

            val names = model.getTableModel(HardcodeTablesModel.mapNameTable)
            var name = if (names == null || key < 0 || key >= names.size) "" else names[key].getStringValue("name")
            name = sanitizeName(name)
            if (name.length == 0) name = "(unnamed)"

            return "${name}.${group}-${map}"
        }
        /*@END BlockMapViewModel.Companion*/
    }
    /*@ADD BlockMapViewModel#blockmap.txt*/
    private val refreshFromEventChangeHandler: (Any?, EventArgs) -> Unit = { s, e -> refreshFromEventChange(s, e) }
    private val cycleActiveEventHandler: (Any?, EventCycleDirection) -> Unit = { s, d -> cycleActiveEvent(s, d) }
    private val blocksChangedHandler: (Any?, Array<ByteArray>) -> Unit = { s, b -> handleBlocksChanged(s, b) }
    private val blockAttributesChangedHandler: (Any?, Array<ByteArray>) -> Unit = { s, b -> handleBlockAttributesChanged(s, b) }
    private val autoscrollTilesHandler: (Any?, EventArgs) -> Unit = { s, e -> handleAutoscrollTiles(s, e) }
    private val borderChangedHandler: (Any?, EventArgs) -> Unit = { s, e -> handleBorderChanged(s, e) }
    private val eventDataMovedHandler: (Any?, DataMovedEventArgs?) -> Unit = { s, e -> handleEventDataMoved(s, e) }
    private fun mostCommonOrZero(values: List<Int>): Int = if (values.isEmpty()) 0 else values.toHistogram().mostCommonKey()
    private fun safeCell(cells: BlockCells?, x: Int, y: Int): BlockCell? {
        if (cells == null || x < 0 || y < 0 || x >= cells.width || y >= cells.height) return null
        return cells[x, y]
    }
    /*@ENDADD BlockMapViewModel#blockmap.txt*/
    /*@END BlockMapViewModel*/
}

open class EventSelector : ViewModelCore() { // cs:2815-2823
    private var _isSelected: Boolean = false
    var isSelected: Boolean
        get() { /*@DONE EventSelector.IsSelected.get cs:2817-2817*/
            return _isSelected
        }
        set(value) { /*@DONE EventSelector.IsSelected.set cs:2817-2817*/
            tryUpdate(_isSelected, value, "isSelected") { _isSelected = it }
        }
    private var _index: Int = 0
    var index: Int
        get() { /*@DONE EventSelector.Index.get cs:2820-2820*/
            return _index
        }
        set(value) { /*@DONE EventSelector.Index.set cs:2820-2820*/
            tryUpdate(_index, value, "index") { _index = it }
        }
    fun select() { /*@DONE EventSelector.Select/1 cs:2822-2822*/
        isSelected = true
    }
    /*@END EventSelector*/
}

data class Border(val north: Int, val east: Int, val south: Int, val west: Int) { // cs:2825-2825
    /*@END Border*/
}

data class ConnectionInfo(val size: Int, val offset: Int, val direction: MapDirection) { // cs:2827-2833
    val oppositeDirection: MapDirection
        get() { /*@DONE ConnectionInfo.OppositeDirection.get cs:2832-2832*/
            return direction.reverse()
        }
    companion object {
        const val singleConnectionContent: String = "direction:: offset:: mapGroup. mapNum. unused:"
        const val singleConnectionLength: String = "/count"
        val singleConnectionFormat: String = /*@INITDONE ConnectionInfo.SingleConnectionFormat cs:2830-2830*/ "[" + singleConnectionContent + "]" + singleConnectionLength /*@ENDINIT*/
        val connectionTableContent: String = /*@INITDONE ConnectionInfo.ConnectionTableContent cs:2831-2831*/ "count:: connections<" + singleConnectionFormat + ">" /*@ENDINIT*/
        /*@END ConnectionInfo.Companion*/
    }
    /*@END ConnectionInfo*/
}

data class BerryInfo(val berryMap: MutableMap<Int, BerrySpot>, val berryOptions: ObservableCollection<String>) { // cs:2835-2835
    /*@END BerryInfo*/
}

open class ConnectionModel { // cs:2837-2882
    private lateinit var connection: ModelArrayElement
    private var sourceGroup: Int = 0
    private var sourceMap: Int = 0
    val model: IDataModel?
        get() { /*@DONE ConnectionModel.Model.get cs:2840-2840*/
            return connection.model
        }
    val tokens: () -> ModelDelta
        get() { /*@DONE ConnectionModel.Tokens.get cs:2841-2841*/
            return { connection.token }
        }
    constructor(connection: ModelArrayElement, sourceGroup: Int, sourceMap: Int) { /*@DONE ConnectionModel.<init>/1 cs:2842-2842*/
        this.connection = connection
        this.sourceGroup = sourceGroup
        this.sourceMap = sourceMap
    }
    var direction: MapDirection
        get() { /*@DONE ConnectionModel.Direction.get cs:2845-2845*/
            val rawDirection = connection.getValue("direction")
            return MapDirection.entries.firstOrNull { d -> d.value == rawDirection } ?: MapDirection.None
        }
        set(value) { /*@DONE ConnectionModel.Direction.set cs:2846-2846*/
            connection.setValue("direction", value.value)
        }
    val table: ITableRun
        get() { /*@DONE ConnectionModel.Table.get cs:2849-2849*/
            return connection.table
        }
    var offset: Int
        get() { /*@DONE ConnectionModel.Offset.get cs:2852-2852*/
            return connection.getValue("offset")
        }
        set(value) { /*@DONE ConnectionModel.Offset.set cs:2853-2853*/
            connection.setValue("offset", value)
        }
    var mapGroup: Int
        get() { /*@DONE ConnectionModel.MapGroup.get cs:2857-2857*/
            return connection.getValue("mapGroup")
        }
        set(value) { /*@DONE ConnectionModel.MapGroup.set cs:2858-2858*/
            connection.setValue("mapGroup", value)
        }
    var mapNum: Int
        get() { /*@DONE ConnectionModel.MapNum.get cs:2862-2862*/
            return connection.getValue("mapNum")
        }
        set(value) { /*@DONE ConnectionModel.MapNum.set cs:2863-2863*/
            connection.setValue("mapNum", value)
        }
    var unused: Int
        get() { /*@DONE ConnectionModel.Unused.get cs:2867-2867*/
            return connection.getValue("unused")
        }
        set(value) { /*@DONE ConnectionModel.Unused.set cs:2868-2868*/
            connection.setValue("unused", value)
        }
    fun getInverse(): ConnectionModel? { /*@DONE ConnectionModel.GetInverse/1 cs:2871-2877*/
        val reversed = direction.reverse()
        val neighborMap = BlockMapViewModel.getMapModel(model!!, mapGroup, mapNum, tokens)
        val neighbors = BlockMapViewModel.getConnections(neighborMap, mapGroup, mapNum) ?: return null
        return neighbors.firstOrNull { c -> c.mapGroup == sourceGroup && c.mapNum == sourceMap && c.direction == reversed }
    }
    fun clear(model: IDataModel, token: ModelDelta) { /*@DONE ConnectionModel.Clear/1 cs:2879-2881*/
        token.changeData(model, connection.start, ByteArray(connection.length) { 0xFF.toByte() }.asByteList())
    }
    /*@END ConnectionModel*/
}

open class EventGroupModel { // cs:2884-2954
    private var events: ModelArrayElement? = null
    val dataMoved = Event<DataMovedEventArgs>()
    constructor(parent: BlockMapViewModel, gotoAddress: (Int) -> Unit, gotoBankMap: (Int, Int) -> Unit, events: ModelArrayElement, eventTemplate: EventTemplate, ows: List<IPixelViewModel>, defaultOW: IPixelViewModel, berries: BerryInfo, bank: Int, map: Int) { /*@DONE EventGroupModel.<init>/1 cs:2889-2937*/
        this.events = events

        val objectCount = events.getValue("objectCount")
        val objectElements = events.getSubTable("objects")
        val objectList = ArrayList<ObjectEventViewModel>()
        if (objectElements != null) {
            for (i in 0 until objectCount) {
                val newEvent = ObjectEventViewModel(parent, gotoAddress, objectElements[i], eventTemplate, ows, defaultOW, berries)
                newEvent.dataMoved += { _, e -> dataMoved(this, e) }
                objectList.add(newEvent)
            }
        }
        this.objects = objectList

        val warpCount = events.getValue("warpCount")
        val warpElements = events.getSubTable("warps")
        val warpList = ArrayList<WarpEventViewModel>()
        if (warpElements != null) {
            for (i in 0 until warpCount) warpList.add(WarpEventViewModel(warpElements[i], gotoBankMap))
        }
        this.warps = warpList

        val scriptCount = events.getValue("scriptCount")
        val scriptElements = events.getSubTable("scripts")
        val scriptList = ArrayList<ScriptEventViewModel>()
        if (scriptElements != null) {
            for (i in 0 until scriptCount) scriptList.add(ScriptEventViewModel(gotoAddress, scriptElements[i], eventTemplate))
        }
        this.scripts = scriptList

        val signpostCount = events.getValue("signpostCount")
        val signpostElements = events.getSubTable("signposts")
        val signpostList = ArrayList<SignpostEventViewModel>()
        if (signpostElements != null) {
            for (i in 0 until signpostCount) {
                val newEvent = SignpostEventViewModel(signpostElements[i], gotoAddress)
                newEvent.dataMoved += { _, e -> dataMoved(this, e) }
                signpostList.add(newEvent)
            }
        }
        this.signposts = signpostList

        val flyList = ArrayList<FlyEventViewModel>()
        for (flyEvent in FlyEventViewModel.create(events.model!!, bank, map, { events.token })) {
            if (flyEvent.valid) flyList.add(flyEvent)
        }
        this.flyEvents = flyList
    }
    var objects: List<ObjectEventViewModel> = ArrayList()
        private set
    var warps: List<WarpEventViewModel> = ArrayList()
        private set
    var scripts: List<ScriptEventViewModel> = ArrayList()
        private set
    var signposts: List<SignpostEventViewModel> = ArrayList()
        private set
    var flyEvents: List<FlyEventViewModel> = ArrayList()
        private set
    val all: Iterable<IEventViewModel>
        get() { /*@DONE EventGroupModel.All.get cs:2945-2945*/
            val list = ArrayList<IEventViewModel>()
            list.addAll(objects)
            list.addAll(warps)
            list.addAll(scripts)
            list.addAll(signposts)
            list.addAll(flyEvents)
            return list
        }
    /*@END EventGroupModel*/
}

enum class MapDirection(val value: Int) { // cs:2956-2964
    None(0),
    Down(1),
    Up(2),
    Left(3),
    Right(4),
    Dive(5),
    Emerge(6);
    companion object {
        fun fromValue(value: Int): MapDirection = entries.first { it.value == value }
    }
    /*@END MapDirection*/
}

fun MapDirection.reverse(): MapDirection { /*@DONE MapDirectionExtensions.Reverse/1 cs:2967-2975*/
    return when (this) {
        MapDirection.Up -> MapDirection.Down
        MapDirection.Down -> MapDirection.Up
        MapDirection.Left -> MapDirection.Right
        MapDirection.Right -> MapDirection.Left
        MapDirection.Dive -> MapDirection.Emerge
        MapDirection.Emerge -> MapDirection.Dive
        else -> throw NotImplementedError()
    }
}

object MapDirectionExtensions { // cs:2966-2976
    /*@END MapDirectionExtensions*/
}

enum class ZoomDirection(val value: Int) { // cs:2978-2982
    None(0),
    Shrink(1),
    Enlarge(2);
    companion object {
        fun fromValue(value: Int): ZoomDirection = entries.first { it.value == value }
    }
    /*@END ZoomDirection*/
}

data class BlockMapViewModelGetBlockTuple(val blockIndex: Int, val collisionIndex: Int)
