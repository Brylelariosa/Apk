// Port of Models/Runs/AsciiRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class AsciiRun : BaseRun, IStreamRun { // cs:9-51
    private lateinit var model: IDataModel
    final override var length: Int = 0
        private set
    override val formatString: String
        get() { /*@DONE AsciiRun.FormatString.get cs:17-17*/
            return "`asc`" + length
        }
    override val visualizations: List<IPixelViewModel>
        get() { /*@DONE AsciiRun.Visualizations.get cs:19-19*/
            throw NotImplementedException()
        }
    final override var preFormatter: ITextPreProcessor? = null
        private set
    constructor(model: IDataModel, start: Int, length: Int, pointerSources: SortedSpan<Int>? = null) : super(start, pointerSources) { /*@DONE AsciiRun.<init>/1 cs:22-22*/
        this.model = model
        this.length = length.limitToRange(1, 1000)
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE AsciiRun.CreateDataFormat/1 cs:24-26*/
        return Ascii(start, index - start, data[index].toChar().toString())
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE AsciiRun.Clone/1 cs:28-28*/
        return AsciiRun(model, start, length, newPointerSources)
    }
    override fun serializeRun(): String? { /*@DONE AsciiRun.SerializeRun/1 cs:30-36*/
        val builder = StringBuilder()
        for (i in 0 until length) {
            builder.append(model[start + i].toChar())
        }
        return builder.toString()
    }
    override fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, changedRuns: Ref<List<Int>?>): IStreamRun { /*@DONE AsciiRun.DeserializeRun/1 cs:38-46*/
        for (i in 0 until length) {
            if (i < content.length) token.changeData(model, start + i, content[i].code and 0xFF)
            else token.changeData(model, start + i, 0)
        }
        changedOffsets.value = ArrayList<Int>()
        changedRuns.value = ArrayList<Int>()
        return this
    }
    override fun dependsOn(anchorName: String): Boolean { /*@DONE AsciiRun.DependsOn/1 cs:48-48*/
        return false
    }
    override fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem>? { /*@DONE AsciiRun.GetAutoCompleteOptions/1 cs:50-50*/
        return null
    }
    companion object {
        const val streamDelimeter: Char = '`'
        val sharedFormatString: String = /*@INITDONE AsciiRun.SharedFormatString cs:11-11*/ streamDelimeter.toString() + "asc" + streamDelimeter /*@ENDINIT*/
        /*@END AsciiRun.Companion*/
    }
    /*@END AsciiRun*/
}
