// Port of Models/Runs/Sprites/PaletteRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class PaletteRun : BaseRun, IPaletteRun { // cs:8-127
    private var bits: Int = 0
    final override var paletteFormat: PaletteFormat = PaletteFormat()
        private set
    final override var pages: Int = 0
        private set
    final override var length: Int = 0
        private set
    final override var formatString: String = ""
        private set
    constructor(start: Int, format: PaletteFormat, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE PaletteRun.<init>/1 cs:17-28*/
        paletteFormat = format
        bits = format.bits
        pages = format.pages
        if (bits == 8) length = 512
        if (bits == 4) length = pages * 32
        var pagesPart = ""
        if (pages > 1 || format.initialBlankPages > 0) {
            pagesPart = ":" + getPalettePages(format)
        }
        formatString = "`ucp" + bits + pagesPart + "`"
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE PaletteRun.CreateDataFormat/1 cs:41-48*/
        val runPosition = index - start
        val colorPosition = runPosition % 2
        val colorStart = start + runPosition - colorPosition
        var color = data.readMultiByteValue(colorStart, 2).toShort()
        color = flipColorChannels(color)
        return UncompressedPaletteColor(colorStart, colorPosition, color)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE PaletteRun.Clone/1 cs:50-50*/
        return PaletteRun(start, paletteFormat, newPointerSources)
    }
    override fun duplicate(newFormat: PaletteFormat): IPaletteRun { /*@DONE PaletteRun.Duplicate/1 cs:52-52*/
        return PaletteRun(start, newFormat, pointerSources)
    }
    override fun getPalette(model: IDataModel, page: Int): List<Short>? { /*@DONE PaletteRun.GetPalette/1 cs:54-59*/
        val pageIndex = if (pages > 0) page % pages else 0
        val paletteColorCount = Math.pow(2.0, bits.toDouble()).toInt()
        val pageLength = paletteFormat.expectedByteLengthPerPage
        return getPalette(model, start + pageIndex * pageLength, paletteColorCount)
    }
    override fun setPalette(model: IDataModel, token: ModelDelta, page: Int, colors: List<Short>): IPaletteRun { /*@DONE PaletteRun.SetPalette/1 cs:61-70*/
        val pageIndex = if (pages > 0) page % pages else 0
        val pageLength = paletteFormat.expectedByteLengthPerPage
        val pageStart = start + pageIndex * pageLength

        val data = ByteArray(pageLength)
        setPalette(data, 0, colors)
        for (i in 0 until data.size) token.changeData(model, pageStart + i, data[i].toInt() and 0xFF)
        return this
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE PaletteRun.AppendTo/1 cs:107-120*/
        var currentStart = start
        var remaining = length
        if (currentStart < this.start) {
            remaining -= this.start - currentStart
            currentStart = this.start
        }
        if (remaining > this.length) remaining = this.length

        while (remaining > 0) {
            val format = createDataFormat(model, currentStart) as UncompressedPaletteColor
            builder.append(format.toString() + " ")
            currentStart += 2 - format.position
            remaining -= 2 - format.position
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE PaletteRun.Clear/1 cs:122-126*/
        for (i in 0 until length) {
            changeToken.changeData(model, start + i, 0x00)
        }
    }
    companion object {
        fun getPalettePages(format: PaletteFormat): String { /*@DONE PaletteRun.GetPalettePages/1 cs:30-33*/
            val pageIDs = (format.initialBlankPages until format.initialBlankPages + format.pages).map { i -> ViewPort.allHexCharacters[i] }
            return String(pageIDs.toCharArray())
        }
        fun tryParsePaletteFormat(pointerFormat: String, paletteFormat: Ref<PaletteFormat>): Boolean { /*@DONE PaletteRun.TryParsePaletteFormat/1 cs:35-39*/
            paletteFormat.value = PaletteFormat()
            if (!pointerFormat.startsWith("`ucp") || !pointerFormat.endsWith("`")) return false
            return LzPaletteRun.tryParseDimensions(pointerFormat, paletteFormat)
        }
        fun getPalette(data: ByteList, start: Int, count: Int): List<Short>? { /*@DONE PaletteRun.GetPalette/2 cs:76-83*/
            val results = ArrayList<Short>()
            for (i in 0 until count) {
                val color = data.readMultiByteValue(start + i * 2, 2).toShort()
                results.add(flipColorChannels(color))
            }
            return results
        }
        fun setPalette(data: ByteArray, start: Int, colors: List<Short>) { /*@DONE PaletteRun.SetPalette/2 cs:89-95*/
            for (i in 0 until colors.size) {
                val color = flipColorChannels(colors[i]).toInt()
                data[start + i * 2 + 0] = (color shr 0).toByte()
                data[start + i * 2 + 1] = (color shr 8).toByte()
            }
        }
        fun flipColorChannels(color: Short): Short { /*@DONE PaletteRun.FlipColorChannels/1 cs:100-105*/
            val r = ((color.toInt() shr 10) and 0x1F)
            val g = ((color.toInt() shr 5) and 0x1F)
            val b = ((color.toInt() shr 0) and 0x1F)
            return ((b shl 10) or (g shl 5) or (r shl 0)).toShort()
        }
        /*@END PaletteRun.Companion*/
    }
    /*@END PaletteRun*/
}
