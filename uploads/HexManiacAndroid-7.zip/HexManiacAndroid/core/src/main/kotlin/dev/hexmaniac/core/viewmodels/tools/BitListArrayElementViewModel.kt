// Port of ViewModels/Tools/BitListArrayElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class BitElement : ViewModelCore() { // cs:13-22
    private var _bitLabel: String = ""
    var bitLabel: String
        get() { /*@DONE BitElement.BitLabel.get cs:15-15*/
            return _bitLabel
        }
        set(value) { /*@DONE BitElement.BitLabel.set cs:15-15*/
            set(_bitLabel, value, "bitLabel", { _bitLabel = it })
        }
    private var _isChecked: Boolean = false
    private var _visible: Boolean = /*@INITAUTO BitElement.visible cs:17-17*/ true /*@ENDINIT*/
    var isChecked: Boolean
        get() { /*@DONE BitElement.IsChecked.get cs:18-18*/
            return _isChecked
        }
        set(value) { /*@DONE BitElement.IsChecked.set cs:18-18*/
            set(_isChecked, value, "isChecked", { _isChecked = it })
        }
    var visible: Boolean
        get() { /*@DONE BitElement.Visible.get cs:19-19*/
            return _visible
        }
        set(value) { /*@DONE BitElement.Visible.set cs:19-19*/
            set(_visible, value, "visible", { _visible = it })
        }
    fun equals(other: BitElement): Boolean { /*@DONE BitElement.Equals/1 cs:21-21*/
        return _bitLabel == other._bitLabel && _isChecked == other._isChecked
    }
    /*@END BitElement*/
}

open class BitListArrayElementViewModel : ViewModelCore, ReadOnlyListMixin<BitElement>, IArrayElementViewModel { // cs:24-254
    private lateinit var history: ChangeHistory<ModelDelta>
    private lateinit var model: IDataModel
    private val children: MutableList<BitElement> = /*@INITAUTO BitListArrayElementViewModel.children cs:27-27*/ ArrayList() /*@ENDINIT*/
    private lateinit var segment: ArrayRunElementSegment
    private var rotatedBitArray: ArrayRun? = null
    private lateinit var viewPort: ViewPort
    private var start: Int = 0
    var name: String = ""
        private set
    private var _theme: String = ""
    override var theme: String
        get() { /*@DONE BitListArrayElementViewModel.Theme.get cs:35-35*/
            return _theme
        }
        set(value) { /*@DONE BitListArrayElementViewModel.Theme.set cs:35-35*/
            set(_theme, value, "theme", { _theme = it })
        }
    override val isInError: Boolean
        get() { /*@DONE BitListArrayElementViewModel.IsInError.get cs:36-36*/
            return !errorText.isNullOrEmpty()
        }
    override var errorText: String? = null
    override val zIndex: Int
        get() { /*@DONE BitListArrayElementViewModel.ZIndex.get cs:38-38*/
            return 0
        }
    lateinit var linkCommand: ICommand
        private set
    val canMassCopy: Boolean
        get() { /*@DONE BitListArrayElementViewModel.CanMassCopy.get cs:44-44*/
            return rotatedBitArray != null
        }
    fun massCopy(fileSystem: IFileSystem) { /*@DONE BitListArrayElementViewModel.MassCopy/1 cs:45-49*/
        val content = StringBuilder()
        for (child in children) content.append(if (child.isChecked) "1" else "0")
        fileSystem.copyText = content.toString()
    }
    val canMassPaste: Boolean
        get() { /*@DONE BitListArrayElementViewModel.CanMassPaste.get cs:51-51*/
            return rotatedBitArray != null
        }
    fun massPaste(fileSystem: IFileSystem) { /*@DONE BitListArrayElementViewModel.MassPaste/1 cs:52-61*/
        val content = fileSystem.copyText ?: ""
        if (!content.all { c -> "01".contains(c) }) {
            viewPort.raiseError("Expected only 0s and 1s")
        } else if (content.length != children.size) {
            viewPort.raiseError("Expected exactly " + children.size + " flags, but there were " + content.length + " flags.")
        } else {
            for (i in 0 until children.size) children[i].isChecked = content[i] == '1'
        }
    }
    private var _visible: Boolean = /*@INITAUTO BitListArrayElementViewModel.visible cs:65-65*/ true /*@ENDINIT*/
    override var visible: Boolean
        get() { /*@DONE BitListArrayElementViewModel.Visible.get cs:66-66*/
            return _visible
        }
        set(value) { /*@DONE BitListArrayElementViewModel.Visible.set cs:66-66*/
            set(_visible, value, "visible", { _visible = it })
        }
    private var _dataChanged: EventHandler? = null
    private lateinit var _dataSelected: EventHandler
    override val dataChanged = Event<EventArgs>()
    override val dataSelected = Event<EventArgs>()
    private lateinit var _selectAll: StubCommand
    private lateinit var _unselectAll: StubCommand
    val selectAll: ICommand
        get() { /*@DONE BitListArrayElementViewModel.SelectAll.get cs:74-74*/
            if (!::_selectAll.isInitialized) _selectAll = stubCommand({ setAll(true) })
            return _selectAll
        }
    val unselectAll: ICommand
        get() { /*@DONE BitListArrayElementViewModel.UnselectAll.get cs:75-75*/
            if (!::_unselectAll.isInitialized) _unselectAll = stubCommand({ setAll(false) })
            return _unselectAll
        }
    private fun setAll(value: Boolean) { /*@DONE BitListArrayElementViewModel.SetAll/1 cs:76-81*/
        deferChanges = true
        for (element in children) element.isChecked = value
        deferChanges = false
        updateModelFromView()
    }
    constructor(viewPort: ViewPort, name: String, start: Int) { /*@DONE BitListArrayElementViewModel.<init>/1 cs:83-113*/
        this.viewPort = viewPort
        this.history = viewPort.changeHistory
        this.model = viewPort.model
        this.name = name
        this.start = start

        val array = model.getNextRun(start) as ITableRun
        val offset = array.convertByteOffsetToArrayOffset(start)
        segment = array.elementContent[offset.segmentIndex]
        val currentSegment = segment
        if (currentSegment is ArrayRunBitArraySegment) {
            val optionSource = fillBodyFromBitArraySegment(currentSegment)

            val link = StubCommand()
            link.canExecute = { _ -> optionSource != Pointer.null_ }
            link.execute = { _ -> viewPort.goto?.execute(optionSource) }
            linkCommand = link
        } else if (currentSegment is ArrayRunEnumSegment) {
            val rotated = fillBodyRotated()
            rotatedBitArray = rotated

            val link = StubCommand()
            link.canExecute = { _ -> true }
            link.execute = { _ -> viewPort.goto?.execute(rotated.start) }
            linkCommand = link
        } else {
            throw NotImplementedError()
        }

        for (child in children) addSilentChild(child)
        updateViewFromModel()
    }
    private fun fillBodyFromBitArraySegment(bitSegment: ArrayRunBitArraySegment): Int { /*@DONE BitListArrayElementViewModel.FillBodyFromBitArraySegment/1 cs:115-135*/
        // get all the bits of this segment and turn them into BitElements
        val optionSource = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, bitSegment.sourceArrayName)
        val bits = model.readMultiByteValue(start, bitSegment.length)
        val names: MutableList<String> = bitSegment.getOptions(model)?.toMutableList() ?: ArrayList<String>()

        if (names.size == 0) {
            errorText = "Trying to use " + bitSegment.sourceArrayName + " for a bit-source, but it doesn't exist or has no length."
            names.add("UNKNOWN")
        } else {
            errorText = ""
        }

        for (i in 0 until names.size) {
            val element = BitElement()
            element.bitLabel = names[i]
            children.add(element)
            element.propertyChanged += childChangedHandler
        }

        return optionSource
    }
    private fun fillBodyRotated(): ArrayRun { /*@DONE BitListArrayElementViewModel.FillBodyRotated/1 cs:137-160*/
        // get 1 bit of each segment and turn them into BitElements
        val array = model.getNextRun(start) as ITableRun
        val anchor = model.getAnchorFromAddress(-1, array.start)
        var rotated: ArrayRun? = null

        for (option in model.arrays) {
            val optionSegment = option.elementContent[0] // TODO should I be using enumSegment?
            if (optionSegment is ArrayRunBitArraySegment && optionSegment.sourceArrayName == anchor && option.elementContent.size == 1) {
                rotated = option
                for (i in 0 until option.elementCount) {
                    val optionNames = option.elementNames
                    val label = if (optionNames != null && optionNames.size > i) optionNames[i] else i.toString()
                    val element = BitElement()
                    element.bitLabel = label
                    children.add(element)
                    element.propertyChanged += childChangedHandler
                }
                break
            }
            if (rotated != null) break
        }
        if (rotated == null) throw NotImplementedError("Trying to Rotate " + anchor + ":" + name + " at " + start.toHex(6) + ", but couldn't find a matching array.")

        return rotated
    }
    override val size: Int
        get() { /*@DONE BitListArrayElementViewModel.Count.get cs:164-164*/
            return children.size
        }
    override operator fun get(index: Int): BitElement { /*@DONE BitListArrayElementViewModel.this/1.get cs:165-165*/
        return children[index]
    }
    // skipped method GetEnumerator: provided by ReadOnlyListMixin
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    fun updateModelFromView() { /*@DONE BitListArrayElementViewModel.UpdateModelFromView/1 cs:171-195*/
        val rotated = rotatedBitArray
        if (rotated == null) {
            for (i in 0 until segment.length) {
                var result = 0
                var j = 0
                while (j < 8 && children.size > i * 8 + j) {
                    result += if (children[i * 8 + j].isChecked) (1 shl j) else 0
                    j++
                }
                if (model[start + i] != result) history.currentChange.changeData(model, start + i, result)
            }
        } else {
            val array = model.getNextRun(start) as ArrayRun
            val offset = array.convertByteOffsetToArrayOffset(start)
            val bitIndex = offset.elementIndex
            val byteShift = bitIndex / 8
            val bitShift = bitIndex % 8
            for (i in 0 until rotated.elementCount) {
                val elementStart = rotated.start + rotated.elementLength * i + byteShift
                var bits = model[elementStart]
                if (children[i].isChecked) {
                    bits = bits or (1 shl bitShift)
                } else {
                    bits = bits and (1 shl bitShift).inv()
                }
                bits = bits and 0xFF
                if (bits != model[elementStart]) history.currentChange.changeData(model, elementStart, bits)
            }
        }
        dataChanged(this, EventArgs.empty)
    }
    fun updateViewFromModel() { /*@DONE BitListArrayElementViewModel.UpdateViewFromModel/1 cs:197-221*/
        val rotated = rotatedBitArray
        if (rotated == null) {
            for (i in 0 until segment.length) {
                val bits = model[start + i]
                for (j in 0 until 8) {
                    if (children.size <= i * 8 + j) break
                    children[i * 8 + j].propertyChanged -= childChangedHandler
                    children[i * 8 + j].isChecked = ((bits shr j) and 1) != 0
                    children[i * 8 + j].propertyChanged += childChangedHandler
                }
            }
        } else {
            val array = model.getNextRun(start) as ArrayRun
            val offset = array.convertByteOffsetToArrayOffset(start)
            val bitIndex = offset.elementIndex
            val byteShift = bitIndex / 8
            val bitShift = bitIndex % 8
            for (i in 0 until rotated.elementCount) {
                val elementStart = rotated.start + rotated.elementLength * i + byteShift
                val bits = model[elementStart]
                children[i].propertyChanged -= childChangedHandler
                children[i].isChecked = ((bits shr bitShift) and 1) != 0
                children[i].propertyChanged += childChangedHandler
            }
        }
    }
    override fun tryCopy(other: IArrayElementViewModel): Boolean { /*@DONE BitListArrayElementViewModel.TryCopy/1 cs:223-246*/
        val bitList = other as? BitListArrayElementViewModel ?: return false
        if (name != bitList.name) return false
        if (segment !== bitList.segment) return false
        if (rotatedBitArray !== bitList.rotatedBitArray) return false
        if (children.map { child -> child.bitLabel } != bitList.children.map { child -> child.bitLabel }) return false

        start = bitList.start
        visible = other.visible
        if (errorText != other.errorText) {
            errorText = other.errorText
            notifyPropertyChanged("errorText")
            notifyPropertyChanged("isInError")
        }
        for (i in 0 until children.size) {
            children[i].propertyChanged -= childChangedHandler
            children[i].isChecked = bitList.children[i].isChecked
            children[i].propertyChanged += childChangedHandler
        }
        dataChanged.copyFrom(bitList.dataChanged)
        dataSelected.copyFrom(bitList.dataSelected)

        return true
    }
    private var deferChanges: Boolean = false
    private fun childChanged(sender: Any?, e: PropertyChangedEventArgs) { /*@DONE BitListArrayElementViewModel.ChildChanged/1 cs:249-253*/
        if (deferChanges) return
        if (e.propertyName == "visible") return
        updateModelFromView()
    }
    /*@ADD BitListArrayElementViewModel#bitlist.txt*/
    private val childChangedHandler: (Any?, PropertyChangedEventArgs) -> Unit = { s, e -> childChanged(s, e) }
    /*@ENDADD BitListArrayElementViewModel#bitlist.txt*/
    /*@END BitListArrayElementViewModel*/
}
