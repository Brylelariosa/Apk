// Port of Core/SystemExtensions.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*

fun Int.toHexString(): String { /*@DONE SystemExtensions.ToHexString/1 cs:20-20*/
    return SystemExtensions.byteToString[this]
}
fun StubCommand?.raiseCanExecuteChanged() { /*@DONE SystemExtensions.RaiseCanExecuteChanged/1 cs:22-22*/
    if (this != null) canExecuteChanged(this, EventArgs.empty)
}
fun EventHandler?.raise(source: Any?) { /*@DONE SystemExtensions.Raise/1 cs:24-24*/
    this?.invoke(source, EventArgs.empty)
}
fun <T> EventHandlerOf<T>?.raise(source: Any?, args: T) { /*@DONE SystemExtensions.Raise/2 cs:25-25*/
    this?.invoke(source, args)
}
fun <T : Comparable<T>> T.limitToRange(lower: T, upper: T): T { /*@DONE SystemExtensions.LimitToRange/1 cs:27-32*/
    if (upper.compareTo(lower) < 0) throw ArgumentException("upper value $upper is less than lower value $lower")
    if (this.compareTo(lower) < 0) return lower
    if (upper.compareTo(this) < 0) return upper
    return this
}
fun <T : Comparable<T>> T.inRange(min: T, max: T): Boolean { /*@DONE SystemExtensions.InRange/1 cs:37-39*/
    return min.compareTo(this) <= 0 && this.compareTo(max) < 0
}
fun String.tryParseInt(result: Ref<Int>): Boolean { /*@DONE SystemExtensions.TryParseInt/1 cs:41-50*/
    var str = this
    val negate = str.startsWith("-")
    if (negate) str = str.substring(1)
    if (str.startsWith("0x") && tryParseHexInt(str.substring(2), result)) return true
    if (tryParseInt(str, result)) {
        if (negate) result.value = -result.value
        return true
    }
    return false
}
fun String.tryParseInt2(result: Ref<Int>): Boolean { /*@DONE SystemExtensions.TryParseInt/2 cs:51-55*/
    if (this.startsWith("0x") && tryParseHexInt(this.substring(2), result)) return true
    if (tryParseInt(this, result)) return true
    return false
} // FIXME-SKEL renamed overload
fun Int.range(): Iterable<Int> { /*@DONE SystemExtensions.Range/1 cs:58-58*/
    return 0 until this
}
fun <T> Int.range(selector: (Int) -> T): Iterable<T> { /*@DONE SystemExtensions.Range/2 cs:60-60*/
    val count = this
    return Iterable { (0 until count).asSequence().map(selector).iterator() }
}
fun <T> Iterable<T>.toHistogram(): MutableMap<T, Int> { /*@DONE SystemExtensions.ToHistogram/1 cs:65-72*/
    val result = LinkedHashMap<T, Int>()
    for (element in this) {
        if (!result.containsKey(element)) result[element] = 0
        result[element] = result[element]!! + 1
    }
    return result
}
fun <T> MutableMap<T, Int>.mostCommonKey(): T { /*@DONE SystemExtensions.MostCommonKey/1 cs:74-89*/
    var first = true
    var best: T? = null
    var bestCount = 0
    for (pair in this) {
        if (first) {
            best = pair.key
            bestCount = pair.value
            first = false
        } else if (pair.value > bestCount) {
            best = pair.key
            bestCount = pair.value
        }
    }
    return best as T
}
fun <T> Iterable<T>.until(func: (T) -> Boolean): Iterable<T> { /*@DONE SystemExtensions.Until/1 cs:95-100*/
    val list = this
    return Iterable {
        sequence<T> {
            for (element in list) {
                if (func(element)) break
                yield(element)
            }
        }.iterator()
    }
}
fun Iterable<String>.trimAll(): Iterable<String> { /*@DONE SystemExtensions.TrimAll/1 cs:102-107*/
    val list = this
    return Iterable {
        sequence<String> {
            for (item in list) {
                val text = (item as String?)?.trim()
                if (!text.isNullOrEmpty()) yield(text)
            }
        }.iterator()
    }
}
inline fun <reified T : Any> Iterable<Any?>.firstOfTypeOrDefault(): T? { /*@DONE SystemExtensions.FirstOfTypeOrDefault/1 cs:109-114*/
    for (item in this) {
        if (item is T) return item
    }
    return null
}
inline fun <reified T : Any> Iterable<Any?>.firstOfType(): T { /*@DONE SystemExtensions.FirstOfType/1 cs:116-119*/
    return firstOfTypeOrDefault<T>() ?: throw InvalidOperationException("Enumerable did not contain any ${T::class.java.simpleName} elements.")
}
fun <T> List<T>.matchPairIndex(start: T, end: T): Int { /*@DONE SystemExtensions.MatchPairIndex/1 cs:121-139*/
    var started = false
    var depth = 0
    var index = -1
    for (c in this) {
        index += 1
        if (c != start && c != end) continue
        if (c == start) {
            started = true
            depth += 1
            continue
        } else {
            if (!started) continue
            depth -= 1
            if (depth == 0) return index
        }
    }
    return -1
}
fun <T> Iterable<T>?.isNullOrEmpty(): Boolean { /*@DONE SystemExtensions.IsNullOrEmpty/1 cs:141-144*/
    if (this == null) return true
    return !this.iterator().hasNext()
}
fun <T> MutableList<T>.sort(compare: (T, T) -> Int) { /*@DONE SystemExtensions.Sort/1 cs:146-148*/
    this.sortWith(Comparator { a, b -> compare(a, b) })
}
fun <T> MutableSet<T>.addRange(items: Iterable<T>) { /*@DONE SystemExtensions.AddRange/1 cs:150-152*/
    for (item in items) this.add(item)
}
fun <T> ObservableCollection<T>.addRange(items: Iterable<T>) { /*@DONE SystemExtensions.AddRange/2 cs:154-156*/
    for (item in items) this.add(item)
}
fun <T> List<T>.allOf(predicate: (T) -> Boolean): Boolean { /*@DONE SystemExtensions.All/1 cs:158-164*/
    var match = true
    var i = 0
    while (match && i < this.size) {
        match = predicate(this[i])
        i++
    }
    return match
}
fun <T> Iterable<T>.countOf(c: T): Int { /*@DONE SystemExtensions.Count/1 cs:166-166*/
    var count = 0
    for (ch in this) {
        if (c == ch) count++
    }
    return count
}
fun <T> List<T>.countOf(c: T): Int { /*@DONE SystemExtensions.Count/2 cs:167-173*/
    var count = 0
    for (ch in this) {
        if (c == ch) count++
    }
    return count
}
fun <T> List<T>.indexOf(element: T): Int { /*@DONE SystemExtensions.IndexOf/1 cs:175-180*/
    for (i in 0 until this.size) {
        if (this[i] == element) return i
    }
    return -1
}
fun <T> Array<T>.indexOf(element: T): Int { /*@DONE SystemExtensions.IndexOf/2 cs:182-187*/
    for (i in 0 until this.size) {
        if (this[i] == element) return i
    }
    return -1
}
fun <T> List<T>.writeInto(array: Array<T>, index: Int) { /*@DONE SystemExtensions.WriteInto/1 cs:189-191*/
    for (i in 0 until this.size) array[index + i] = this[i]
}
fun MutableList<Int>.addShort(value: Int) { /*@DONE SystemExtensions.AddShort/1 cs:193-196*/
    this.add(value and 0xFF)
    this.add((value shr 8) and 0xFF)
}
fun String.join(elements: Iterable<String>): String { /*@DONE SystemExtensions.Join/1 cs:198-198*/
    return elements.joinToString(this)
}
fun String.split(token: String): Array<String> { /*@DONE SystemExtensions.Split/1 cs:200-200*/
    if (token.isEmpty()) return arrayOf(this)
    val result = ArrayList<String>()
    var start = 0
    while (true) {
        val i = this.indexOf(token, start)
        if (i < 0) break
        result.add(this.substring(start, i))
        start = i + token.length
    }
    result.add(this.substring(start))
    return result.toTypedArray()
}
fun String.splitLines(): Array<String> { /*@DONE SystemExtensions.SplitLines/1 cs:202-202*/
    return this.replace("\r\n", "\n").split("\n")
}
fun String.splitLast(c: Char): Array<String> { /*@DONE SystemExtensions.SplitLast/1 cs:204-213*/
    val result = arrayOf(this, "")
    for (i in this.length - 1 downTo 0) {
        if (this[i] != c) continue
        result[0] = this.substring(0, i)
        result[1] = this.substring(i + 1)
        break
    }
    return result
}
fun MutableList<String>.combineTokens(startToken: String, endToken: String) { /*@DONE SystemExtensions.CombineTokens/1 cs:215-215*/
    TableStreamRun.recombine(this, startToken, endToken)
}
fun List<String>.combineLines(): String { /*@DONE SystemExtensions.CombineLines/1 cs:217-217*/
    if (this.isEmpty()) throw InvalidOperationException("Sequence contains no elements")
    return this.joinToString(NEW_LINE)
}
fun String.replaceOne(search: String, replacement: String): String { /*@DONE SystemExtensions.ReplaceOne/1 cs:219-223*/
    val index = this.indexOf(search)
    if (index == -1) return this
    return this.substring(0, index) + replacement + this.substring(index + search.length)
}
fun StringBuilder?.trimEnd(): StringBuilder { /*@DONE SystemExtensions.TrimEnd/1 cs:225-238*/
    if (this == null || this.length == 0) return this ?: StringBuilder()

    var i = this.length - 1

    while (i >= 0) {
        if (!Character.isWhitespace(this[i])) break
        i--
    }

    if (i < this.length - 1) this.setLength(i + 1)

    return this
}
fun <T> T.isAny(vararg options: T): Boolean { /*@DONE SystemExtensions.IsAny/1 cs:240-243*/
    Debug.assert(this is Enum<*> || this is Comparable<*> || this is Number || this is Boolean || this is Char || this is String || this == null)
    return options.contains(this)
}
fun <T> T.fluent(action: (T) -> Unit): T { /*@DONE SystemExtensions.Fluent/1 cs:247-250*/
    action(this)
    return this
}
fun String.matchLength(partial: String, onlyCheckLettersAndDigits: Boolean = false): Int { /*@DONE SystemExtensions.MatchLength/1 cs:257-276*/
    var j = 0
    for (i in 0 until partial.length) {
        if (onlyCheckLettersAndDigits && !Character.isLetterOrDigit(partial[i])) continue
        var testPartial = Character.toUpperCase(partial[i])
        if (partial[i] == '\u00e9') testPartial = 'E'
        if (partial[i] == '\u00e1') testPartial = 'A'
        while (j < this.length) {
            var testFull = Character.toUpperCase(this[j])
            if (this[j] == '\u00e9') testFull = 'E'
            if (this[j] == '\u00e1') testFull = 'A'
            j++
            if (testFull == testPartial) break
            if (j == this.length) return i
        }
        if (j == this.length) return i + 1
    }

    return partial.length
}
fun String?.matchesPartial(partial: String?, onlyCheckLettersAndDigits: Boolean = false): Boolean { /*@DONE SystemExtensions.MatchesPartial/1 cs:278-281*/
    if (this == null || partial == null) return false
    return this.matchLength(partial, onlyCheckLettersAndDigits) == partial.length
}
fun String.skipCount(partial: String): Int { /*@DONE SystemExtensions.SkipCount/1 cs:286-316*/
    val full = this
    if (partial.length < 2) return 0
    var bestSkipCount = full.length

    fun compare(letter: Char): Char {
        var c = Character.toUpperCase(letter)
        if (letter == '\u00e9') c = 'E'
        if (letter == '\u00e1') c = 'A'
        return c
    }

    val startPartial = compare(partial[0])
    for (startPoint in 0..(full.length - partial.length)) {
        if (compare(full[startPoint]) != startPartial) continue
        var skipCount = 0
        var k = 1
        var currentPartial = compare(partial[1])
        for (j in (startPoint + 1) until full.length) {
            if (compare(full[j]) == currentPartial) {
                k += 1
                if (k == partial.length) break
                currentPartial = compare(partial[k])
            } else {
                skipCount += 1
            }
        }
        if (k < partial.length) continue
        bestSkipCount = Math.min(bestSkipCount, skipCount)
        if (bestSkipCount == 0) return 0
    }
    return bestSkipCount
}
fun List<String>.indexOfPartial(input: String): Int { /*@DONE SystemExtensions.IndexOfPartial/1 cs:318-327*/
    val names = this
    // perfect match first
    val matchIndex = names.indexOf(input)
    if (matchIndex != -1) return matchIndex

    var partialList = names.size.range().filter { i -> names[i].matchesPartial(input) }.toList()
    partialList = ScriptParser.sortOptions(partialList, input) { i -> names[i] }.toList()
    if (partialList.size == 0) return -1
    return partialList[0]
}
fun <T> Iterable<T>.except(vararg remove: T): Iterable<T> { /*@DONE SystemExtensions.Except/1 cs:343-343*/
    val removeSet = remove.toSet()
    val seen = HashSet<T>()
    val result = ArrayList<T>()
    for (item in this) {
        if (removeSet.contains(item)) continue
        if (seen.add(item)) result.add(item)
    }
    return result
}
fun String.matchesPartialWithReordering(partial: String): Boolean { /*@DONE SystemExtensions.MatchesPartialWithReordering/1 cs:345-362*/
    if (partial.length == 0) return true
    if (partial.contains('.')) return this.matchesPartial(partial)
    val parts = this.split('.').toMutableList()
    var remaining = partial
    while (remaining.length > 0) {
        if (parts.size == 0) return false
        var bestMatchIndex = 0
        var bestMatchValue = parts[0].matchLength(remaining)
        for (i in 1 until parts.size) {
            val matchValue = parts[i].matchLength(remaining)
            if (matchValue <= bestMatchValue) continue
            bestMatchIndex = i
            bestMatchValue = matchValue
        }
        if (bestMatchValue == 0) return false
        parts.removeAt(bestMatchIndex)
        remaining = remaining.substring(bestMatchValue)
    }
    return true
}
fun String.matchesPartialWithReordering1(partial: String): Boolean { /*@DONE SystemExtensions.MatchesPartialWithReordering1/1 cs:364-372*/
    if (partial.length == 0) return true
    val parts = this.split('.').filter { part -> part.any { c -> partial.contains(c) } } // only bother checking the parts where at least some letter matches
    for (possibleOrder in SystemExtensions.enumerateOrders(parts)) {
        if (!possibleOrder.matchesPartial(partial, true)) continue
        return true
    }
    return false
}
fun String.bitLetters(): UInt { /*@DONE SystemExtensions.BitLetters/1 cs:375-382*/
    var result = 0u
    for (letter in this) {
        if (letter >= 'a' && letter <= 'z') result = result or (1u shl (letter - 'a'))
        if (letter >= 'A' && letter <= 'Z') result = result or (1u shl (letter - 'A'))
    }
    return result
}
fun Int.toAddress(): String { /*@DONE SystemExtensions.ToAddress/1 cs:384-384*/
    return this.toHex(6) // for debugging
}
fun String.findMatches(options: List<String>): MutableList<Int> { /*@DONE SystemExtensions.FindMatches/1 cs:386-399*/
    val input = this
    val result = ArrayList<Int>()
    val seekBits = input.bitLetters()
    for (i in 0 until options.size) {
        val includedBits = options[i].bitLetters()
        if ((seekBits and includedBits.inv()) != 0u) continue
        if (!input.contains(".")) {
            if (options[i].matchesPartialWithReordering(input)) result.add(i)
        } else {
            if (options[i].matchesPartial(input)) result.add(i)
        }
    }
    return result
}
fun String.parseHexBytes(): ByteArray { /*@DONE SystemExtensions.ToByteArray/1 cs:401-403*/
    return this.split(' ').filter { t -> t.isNotEmpty() }.map { t -> parseHexInt(t).toByte() }.toByteArray()
}
fun <T> java.util.Random.from(list: List<T>): T { /*@DONE SystemExtensions.From/1 cs:405-408*/
    val index = this.nextInt(list.size)
    return list[index]
}
fun <T> MutableList<T>.ensure(predicate: (T) -> Boolean, element: T): T { /*@DONE SystemExtensions.Ensure/1 cs:410-415*/
    val existing = this.firstOrNull(predicate)
    if (existing != null) return existing
    this.add(element)
    return element
}
fun <K, V> MutableMap<K, V>.ensure(key: K, valueFactory: () -> V): V { /*@DONE SystemExtensions.Ensure/2 cs:417-422*/
    if (this.containsKey(key)) return this[key] as V
    val value = valueFactory()
    this[key] = value
    return value
}

object SystemExtensions { // cs:15-423
    val byteToString: List<String> = /*@INITDONE SystemExtensions.byteToString cs:19-19*/ (0 until 0x100).map { i -> i.toHex(2) } /*@ENDINIT*/
    fun enumerateOrders(parts: List<String>): Iterable<String> { /*@DONE SystemExtensions.EnumerateOrders/1 cs:329-341*/
        return Iterable {
            sequence<String> {
                if (parts.size == 1) {
                    yield(parts[0])
                    return@sequence
                }

                for (token in parts) {
                    val otherTokens = parts.except(token).toList()
                    for (result in enumerateOrders(otherTokens)) {
                        yield(token + '.' + result)
                    }
                }
            }.iterator()
        }
    }
    /*@END SystemExtensions*/
}

object NativeProcess { // cs:425-437
    fun start(url: String) { /*@DONE NativeProcess.Start/1 cs:430-432*/
        launcher?.invoke(url, null)
    }
    fun start(url: String, arguments: String) { /*@DONE NativeProcess.Start/2 cs:434-436*/
        launcher?.invoke(url, arguments)
    }
    /*@ADD NativeProcess#util_5.txt*/
    /** Hook the Android app installs to open a URL / launch something (C# `Process.Start(new ProcessStartInfo(url) { UseShellExecute = true })`). */
    var launcher: ((String, String?) -> Unit)? = null
    /*@ENDADD NativeProcess#util_5.txt*/
    /*@END NativeProcess*/
}

fun <TKey, TValue> MutableMap<TKey, TValue>.debug(watch: TKey): DebugDictionary<TKey, TValue> { /*@DONE DebugDictionaryExtensions.Debug/1 cs:451-451*/
    return DebugDictionary(this, watch)
}

object DebugDictionaryExtensions { // cs:450-452
    /*@END DebugDictionaryExtensions*/
}

open class DebugDictionary<TKey, TValue> : DictionaryDecorator<TKey, TValue> { // cs:454-465
    private var watchKey: TKey = portInit()
    constructor(core: MutableMap<TKey, TValue>, watch: TKey) { /*@DONE DebugDictionary.<init>/1 cs:456-456*/
        innerDictionary = core
        watchKey = watch
    }
    override fun remove(item: Map.Entry<TKey, TValue>): Boolean { /*@DONE DebugDictionary.Remove/1 cs:457-460*/
        return super.remove(item)
    }
    override fun remove(key: TKey): Boolean { /*@DONE DebugDictionary.Remove/2 cs:461-464*/
        return super.remove(key)
    }
    /*@END DebugDictionary*/
}

open class DictionaryDecorator<TKey, TValue> { // cs:471-588
    protected var innerDictionary: MutableMap<TKey, TValue>? = null
    open fun containsKey(key: TKey): Boolean { /*@DONE DictionaryDecorator.ContainsKey/1 cs:473-478*/
        val inner = innerDictionary
        if (inner != null) {
            return inner.containsKey(key)
        }
        return false
    }
    open fun add(key: TKey, value: TValue) { /*@DONE DictionaryDecorator.Add/1 cs:480-484*/
        val inner = innerDictionary
        if (inner != null) {
            if (inner.containsKey(key)) throw ArgumentException("An item with the same key has already been added.")
            inner[key] = value
        }
    }
    open fun remove(key: TKey): Boolean { /*@DONE DictionaryDecorator.Remove/1 cs:486-491*/
        val inner = innerDictionary
        if (inner != null) {
            val had = inner.containsKey(key)
            inner.remove(key)
            return had
        }
        return false
    }
    open fun tryGetValue(key: TKey, value: Ref<TValue>): Boolean { /*@DONE DictionaryDecorator.TryGetValue/1 cs:493-499*/
        value.value = null as TValue
        val inner = innerDictionary
        if (inner != null) {
            if (inner.containsKey(key)) {
                value.value = inner[key] as TValue
                return true
            }
            return false
        }
        return false
    }
    open operator fun get(key: TKey): TValue { /*@DONE DictionaryDecorator.this/1.get cs:502-507*/
        val inner = innerDictionary
        if (inner != null) {
            if (!inner.containsKey(key)) throw KeyNotFoundException()
            return inner[key] as TValue
        }
        return null as TValue
    }
    open operator fun set(key: TKey, value: TValue) { /*@DONE DictionaryDecorator.this/1.set cs:508-512*/
        val inner = innerDictionary
        if (inner != null) {
            inner[key] = value
        }
    }
    open val keys: MutableCollection<TKey>?
        get() { /*@DONE DictionaryDecorator.Keys.get cs:515-520*/
            val inner = innerDictionary
            if (inner != null) {
                return inner.keys
            }
            return null
        }
    open val values: MutableCollection<TValue>?
        get() { /*@DONE DictionaryDecorator.Values.get cs:523-528*/
            val inner = innerDictionary
            if (inner != null) {
                return inner.values
            }
            return null
        }
    open fun add(item: Map.Entry<TKey, TValue>) { /*@DONE DictionaryDecorator.Add/2 cs:530-534*/
        val inner = innerDictionary
        if (inner != null) {
            if (inner.containsKey(item.key)) throw ArgumentException("An item with the same key has already been added.")
            inner[item.key] = item.value
        }
    }
    open fun clear() { /*@DONE DictionaryDecorator.Clear/1 cs:536-540*/
        val inner = innerDictionary
        if (inner != null) {
            inner.clear()
        }
    }
    open fun contains(item: Map.Entry<TKey, TValue>): Boolean { /*@DONE DictionaryDecorator.Contains/1 cs:542-547*/
        val inner = innerDictionary
        if (inner != null) {
            return inner.containsKey(item.key) && inner[item.key] == item.value
        }
        return false
    }
    open fun copyTo(array: Array<Map.Entry<TKey, TValue>>, arrayIndex: Int) { /*@DONE DictionaryDecorator.CopyTo/1 cs:549-553*/
        val inner = innerDictionary
        if (inner != null) {
            var i = arrayIndex
            for (entry in inner.entries) array[i++] = entry
        }
    }
    open fun remove(item: Map.Entry<TKey, TValue>): Boolean { /*@DONE DictionaryDecorator.Remove/2 cs:555-560*/
        val inner = innerDictionary
        if (inner != null) {
            if (inner.containsKey(item.key) && inner[item.key] == item.value) {
                inner.remove(item.key)
                return true
            }
            return false
        }
        return false
    }
    open val count: Int
        get() { /*@DONE DictionaryDecorator.Count.get cs:563-568*/
            val inner = innerDictionary
            if (inner != null) {
                return inner.size
            }
            return 0
        }
    open val isReadOnly: Boolean
        get() { /*@DONE DictionaryDecorator.IsReadOnly.get cs:571-576*/
            return false
        }
    open fun getEnumerator(): Iterator<Map.Entry<TKey, TValue>>? { /*@DONE DictionaryDecorator.GetEnumerator/1 cs:578-583*/
        val inner = innerDictionary
        if (inner != null) {
            return inner.entries.iterator()
        }
        return null
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    /*@END DictionaryDecorator*/
}
