// Port of Models/PokemonModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.code.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.factory.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.visitors.*
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.extendArray
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayStart
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayEnd
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.singleByteIntegerFormat
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.doubleByteIntegerFormat
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayAnchorSeparator
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.signedFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.hexFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.recordFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.tupleFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.colorFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.calculatedFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.pythonButtonFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.renderFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.commentFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.splitterFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.tryParse
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.trySearch
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseTilemapTable
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.findAllLoads
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.findAllCommands
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseSegments
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseSegments2
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.dataMatchesSegmentFormat
import dev.hexmaniac.core.models.runs.AsciiRun.Companion.streamDelimeter
import dev.hexmaniac.core.models.runs.AsciiRun.Companion.sharedFormatString
import dev.hexmaniac.core.models.runs.BaseRun.Companion.anchorStart
import dev.hexmaniac.core.models.runs.PCSRun.Companion.stringDelimeter
import dev.hexmaniac.core.models.runs.PCSRun.Companion.sharedFormatString
import dev.hexmaniac.core.models.runs.PCSRun.Companion.createPCSFormat

private typealias RunPath = Int

open class PokemonModel : BaseModel { // cs:25-2829
    private val runs: MutableList<IFormattedRun> = /*@INITAUTO PokemonModel.runs cs:31-31*/ ArrayList() /*@ENDINIT*/
    private fun setIndex(index: RunPath, run: IFormattedRun) { /*@DONE PokemonModel.SetIndex/1 cs:33-33*/
        runs[index] = run
    }
    private fun insertIndex(index: RunPath, existingRun: IFormattedRun) { /*@DONE PokemonModel.InsertIndex/1 cs:35-39*/
        synchronized(threadlock) {
            runs.add(index, existingRun)
        }
    }
    private fun removeIndex(index: RunPath) { /*@DONE PokemonModel.RemoveIndex/1 cs:41-41*/
        runs.removeAt(index)
    }
    private fun binarySearch(start: Int): RunPath { /*@DONE PokemonModel.BinarySearch/1 cs:49-52*/
        return runs.binarySearch(CompareFormattedRun(start), FormattedRunComparer.instance)
    }
    private fun binarySearchNext(start: Int): RunPath { /*@DONE PokemonModel.BinarySearchNext/1 cs:54-58*/
        var index = runs.binarySearch(CompareFormattedRun(start), FormattedRunComparer.instance)
        if (index < 0) index = index.inv()
        return index
    }
    private fun runsStartingFrom(dataIndex: Int): Iterable<IFormattedRun> { /*@DONE PokemonModel.RunsStartingFrom/1 cs:60-65*/
        val index = binarySearchNext(dataIndex)
        val result = ArrayList<IFormattedRun>()
        for (i in index until runs.size) result.add(runs[i])
        return result
    }
    private val addressForAnchor: ThreadSafeDictionary<String, Int> = /*@INITDONE PokemonModel.addressForAnchor cs:92-92*/ ThreadSafeDictionary<String, Int>() /*@ENDINIT*/
    private val anchorForAddress: MutableMap<Int, String> = /*@INITDONE PokemonModel.anchorForAddress cs:93-93*/ LinkedHashMap<Int, String>() /*@ENDINIT*/
    private val unmappedNameToSources: MutableMap<String, SortedSpan<Int>> = /*@INITDONE PokemonModel.unmappedNameToSources cs:97-97*/ LinkedHashMap<String, SortedSpan<Int>>() /*@ENDINIT*/
    private val sourceToUnmappedName: MutableMap<Int, String> = /*@INITDONE PokemonModel.sourceToUnmappedName cs:98-98*/ LinkedHashMap<Int, String>() /*@ENDINIT*/
    private val unmappedConstants: MutableMap<String, Int> = /*@INITDONE PokemonModel.unmappedConstants cs:100-100*/ LinkedHashMap<String, Int>() /*@ENDINIT*/
    private val matchedWords: MutableMap<String, MutableSet<Int>> = /*@INITDONE PokemonModel.matchedWords cs:104-104*/ LinkedHashMap<String, MutableSet<Int>>() /*@ENDINIT*/
    private val pointerOffsets: MutableMap<Int, Int> = /*@INITDONE PokemonModel.pointerOffsets cs:107-107*/ LinkedHashMap<Int, Int>() /*@ENDINIT*/
    private val lists: ThreadSafeDictionary<String, ValidationList> = /*@INITDONE PokemonModel.lists cs:109-109*/ ThreadSafeDictionary<String, ValidationList>() /*@ENDINIT*/
    private var singletons: Singletons? = null
    private var devMode: Boolean = false
    var showRawIVByteForTrainer: Boolean = false
        protected set
    private var sourcesForDestinations: MutableMap<Int, SortedSpan<Int>>? = null
    private fun buildDestinationToSourceCache(data: ByteArray) { /*@DONE PokemonModel.BuildDestinationToSourceCache/1 cs:123-136*/
        val found = LinkedHashMap<Int, MutableList<Int>>()
        for (i in 3 until data.size) {
            val b = data[i].toInt() and 0xFF
            if (b != 0x08 && b != 0x09) continue
            val source = i - 3
            val destination = readPointer(source)
            if (destination < 0 || destination >= data.size) continue
            var list = found[destination]
            if (list == null) {
                list = ArrayList()
                found[destination] = list
            }
            list.add(source)
        }

        val result = LinkedHashMap<Int, SortedSpan<Int>>()
        for ((key, value) in found) result[key] = SortedSpan(value)
        this.sourcesForDestinations = result
    }
    override operator fun get(index: Int): Int { /*@DONE PokemonModel.this/1.get cs:139-139*/
        return super.get(index)
    }
    override operator fun set(index: Int, value: Int) { /*@DONE PokemonModel.this/1.set cs:140-143*/
        super.set(index, value)
        clearPointerCache()
    }
    private fun clearPointerCache() { /*@DONE PokemonModel.ClearPointerCache/1 cs:146-146*/
        sourcesForDestinations = null
    }
    open val earliestAllowedAnchor: Int
        get() { /*@DONE PokemonModel.EarliestAllowedAnchor.get cs:150-150*/
            return 0
        }
    override val listNames: List<String>
        get() { /*@DONE PokemonModel.ListNames.get cs:152-152*/
            return ArrayList(lists.keys)
        }
    override val arrays: List<ArrayRun>
        get() { /*@DONE PokemonModel.Arrays.get cs:154-164*/
            synchronized(threadlock) {
                val results = ArrayList<ArrayRun>()
                for (address in ArrayList(anchorForAddress.keys)) {
                    val index = binarySearch(address)
                    if (index < 0) continue
                    val run = runs[index]
                    if (run is ArrayRun) results.add(run)
                }
                return results
            }
        }
    override fun <T : IFormattedRun> allOfType(type: Class<T>): Iterable<T>? { /*@DONE PokemonModel.All/1 cs:166-170*/
        val result = ArrayList<T>()
        synchronized(threadlock) {
            for (i in 0 until runs.size) {
                val run = runs[i]
                if (type.isInstance(run)) result.add(type.cast(run))
            }
        }
        return result
    }
    override val streams: List<IStreamRun>
        get() { /*@DONE PokemonModel.Streams.get cs:171-171*/
            synchronized(threadlock) {
                val result = ArrayList<IStreamRun>()
                for (run in runs) if (run is IStreamRun) result.add(run)
                return result
            }
        }
    override val anchors: List<String>
        get() { /*@DONE PokemonModel.Anchors.get cs:172-172*/
            return ArrayList(addressForAnchor.keys)
        }
    constructor(data: ByteArray, metadata: StoredMetadata? = null, singletons: Singletons? = null, devMode: Boolean = false) : super(data) { /*@DONE PokemonModel.<init>/1 cs:176-187*/
        this.singletons = singletons
        this.devMode = devMode
        showRawIVByteForTrainer = metadata?.showRawIVByteForTrainer ?: false
        this.formatRunFactory = FormatRunFactory(showRawIVByteForTrainer)
        buildDestinationToSourceCache(data)

        // if we have a subclass, expect the subclass to do this when it's ready.
        if (javaClass == PokemonModel::class.java) {
            initializationWorkload = (singletons?.workDispatcher ?: InstantDispatch.instance).runBackgroundWork { initialize(metadata) }
        }
    }
    protected fun initialize(metadata: StoredMetadata?) { /*@DONE PokemonModel.Initialize/1 cs:189-280*/
        val pointersForDestination = LinkedHashMap<Int, SortedSpan<Int>>()
        val destinationForSource = java.util.TreeMap<Int, Int>()
        searchForPointers(pointersForDestination, destinationForSource)
        writePointerRuns(pointersForDestination, destinationForSource)
        writeSpriteRuns(pointersForDestination)
        writeStringRuns(pointersForDestination)
        freeSpaceStart = earliestAllowedAnchor

        if (metadata == null) return
        val noChange = NoDataChangeDeltaModel()

        // metadata is more important than anything already found
        for (list in metadata.lists) {
            lists[list.name] = ValidationList(list.hash ?: "", list, list.comments)
        }
        val anchorHashes = LinkedHashMap<String, String>()

        // load MatchedWords before loading NamedAnchors, since some tables may have length based on constants (like type names)
        for (word in metadata.matchedWords) {
            if (word.address + word.length >= count) continue
            var wordSet = matchedWords[word.name]
            if (wordSet == null) {
                wordSet = LinkedHashSet()
                matchedWords[word.name] = wordSet
            }
            wordSet.add(word.address)
            synchronized(threadlock) {
                val index = binarySearch(word.address)
                val newRun: WordRun
                if (index > 0) {
                    newRun = WordRun(word.address, word.name, word.length, word.addOffset, word.multOffset, word.note, runs[index].pointerSources)
                } else {
                    newRun = WordRun(word.address, word.name, word.length, word.addOffset, word.multOffset, word.note)
                }
                clearFormat(noChange, word.address, word.length)
                observeRunWritten(noChange, newRun)
                CompleteCellEdit.updateAllWords(this, newRun, noChange, this.readMultiByteValue(word.address, word.length), true)
            }
        }

        for (anchor in metadata.namedAnchors) {
            // since we're loading metadata, we're pretty sure that the anchors in the metadata are right.
            // therefore, allow those anchors to overwrite anything we found during the initial quick-search phase.
            val scope = ModelCacheScope.createScope(this)
            try {
                applyAnchor(this, noChange, anchor.address, BaseRun.anchorStart + anchor.name + (anchor.format ?: ""), true)
                anchorHashes[anchor.name] = anchor.hash ?: ""
            } finally {
                scope.dispose()
            }
        }
        for (unmappedPointer in metadata.unmappedPointers) {
            sourceToUnmappedName[unmappedPointer.address] = unmappedPointer.name
            if (!unmappedNameToSources.containsKey(unmappedPointer.name)) unmappedNameToSources[unmappedPointer.name] = SortedSpan.none<Int>()
            unmappedNameToSources[unmappedPointer.name] = unmappedNameToSources[unmappedPointer.name]!!.add1(unmappedPointer.address)
            if (getNextRun(unmappedPointer.address).start >= unmappedPointer.address + 4 && readPointer(unmappedPointer.address) == Pointer.null_) {
                observeRunWritten(noChange, PointerRun(unmappedPointer.address))
            }
        }
        removeMatchedWordsThatDoNotMatch(noChange)
        for (offsetPointer in metadata.offsetPointers) {
            if (offsetPointer.address + 4 >= count) continue
            val newRun = OffsetPointerRun(offsetPointer.address, offsetPointer.offset)
            clearFormat(noChange, newRun.start, newRun.length)
            pointerOffsets[offsetPointer.address] = offsetPointer.offset
            observeRunWritten(noChange, newRun)
        }
        for (unmappedConstant in metadata.unmappedConstants) {
            unmappedConstants[unmappedConstant.name] = unmappedConstant.value
        }

        this.loadMetadataProperties(metadata)

        fillGotoModels(metadata)

        tableGroups.addAll(metadata.tableGroups)

        if (!metadata.isEmpty && StoredMetadata.needVersionUpdate(metadata.version, singletons?.metadataInfo?.versionNumber ?: "0")) {
            val gameCode = this.getGameCode()
            val tables = singletons?.gameReferenceTables?.get(gameCode)
            if (tables != null) {
                val metadatas = getDefaultMetadatas(gameCode.substring(0, 4), gameCode)
                synchronized(threadlock) {
                    updateRuns(tables, metadatas, anchorHashes)
                }
            }
        } else {
            // didn't run an update. Now that all the constants are setup correctly, do a quick second pass through the anchors to look for any that failed the first time.
            // for example, if the types were loaded before the number of types was known, then the type chart probably failed to load.
            for (anchor in metadata.namedAnchors) {
                if (addressForAnchor.containsKey(anchor.name)) continue
                applyAnchor(this, noChange, anchor.address, BaseRun.anchorStart + anchor.name + (anchor.format ?: ""), true)
            }
        }

        if (javaClass == PokemonModel::class.java) resolveConflicts()
    }
    private fun removeMatchedWordsThatDoNotMatch(token: ModelDelta) { /*@DONE PokemonModel.RemoveMatchedWordsThatDoNotMatch/1 cs:282-307*/
        for (key in ArrayList(matchedWords.keys)) {
            var allMatch = true
            val addresses = ArrayList(matchedWords[key]!!)
            for (address in addresses) {
                val run = getNextRun(address) as? WordRun
                if (run == null) {
                    allMatch = false
                    break
                }
                if (address == addresses[0]) continue
                val firstRun = getNextRun(addresses[0]) as WordRun
                val virtualTargetValue = firstRun.read(this)
                val virtualActualValue = run.read(this)
                if (virtualActualValue != virtualTargetValue) {
                    allMatch = false
                    break
                }
            }
            if (!allMatch) {
                // the constant will be removed because not all the uses match.
                for (address in addresses) {
                    clearFormat(token, address, 1)
                }
            }
        }
    }
    private fun clearNoEditTableGroups() { /*@DONE PokemonModel.ClearNoEditTableGroups/1 cs:312-315*/
        val groupsToRemove = ArrayList<TableGroup>(tableGroups.filter { group -> group.hashMatches })
        groupsToRemove.forEach { group -> tableGroups.remove(group) }
    }
    private fun updateRuns(referenceTables: GameReferenceTables, metadatas: Iterable<StoredMetadata>, anchorHashes: Map<String, String>) { /*@DONE PokemonModel.UpdateRuns/1 cs:317-457*/
        val noChange = NoDataChangeDeltaModel()

        clearNoEditTableGroups()

        val s = this.singletons ?: return
        val referenceConstants = s.gameReferenceConstants?.get(this.getGameCode())
        if (referenceConstants != null) {
            val constantsMetadata = HardcodeTablesModel.decodeConstantsFromReference(this, s.metadataInfo, StoredMetadata(arrayOf<String>()), referenceConstants)
            if (constantsMetadata != null) this.loadMetadata(constantsMetadata)
        }

        // if there's any differences between the previous metadata and the new metadata, go ahead and use the new metadata.
        // this allows for default metadata updates when member names change, but may overwrite manual changes made by the user.
        // We're not currently worried about that, since we don't expect that to be a common use case.
        for (metadata in metadatas) {
            this.loadMetadata(metadata)
        }

        val changedLocations = LinkedHashSet<Int>()

        val isCFRU = HardcodeTablesModel.getIsCFRU(this)
        for (reference in referenceTables) {
            if (reference.address + 4 > count) continue
            if (isCFRU && HardcodeTablesModel.cfruIgnoreTables.contains(reference.name)) continue
            val referenceFormat = reference.format ?: ""
            val destination = super.readPointer(reference.address) - reference.offset
            if (!anchorForAddress.containsKey(destination) && !addressForAnchor.containsKey(reference.name)) {
                applyAnchor(this, noChange, destination, "^" + reference.name + referenceFormat, true)
                changedLocations.add(destination)
                continue
            }

            val anchor = anchorForAddress[destination] ?: continue
            val existingRun = getNextRun(destination)
            if (anchor == reference.name && existingRun.start == destination && existingRun.formatString == referenceFormat) continue

            // If the stored hash doesn't match the loaded format, then the user edited this table's format.
            // Don't overwrite the user edits.
            val formatHash = StoredList.generateHash(listOf(existingRun.formatString))
            val formatWithoutLengthHash = StoredList.generateHash(listOf(withoutLength(existingRun.formatString)))
            val previousReferenceHash = anchorHashes[anchor] ?: ""
            if (previousReferenceHash.isNotEmpty() && previousReferenceHash != formatHash && previousReferenceHash != formatWithoutLengthHash) continue

            val replacementRunRef = Ref<IFormattedRun?>(null)
            if (tryParseFormat(this, reference.name, referenceFormat, destination, replacementRunRef).hasError) continue
            val replacementRun = replacementRunRef.value ?: continue
            if (doNotChangeFormatOnUpdate(existingRun.formatString)) continue
            // update this anchor
            anchorForAddress[destination] = reference.name
            addressForAnchor.remove(anchor)
            addressForAnchor[reference.name] = destination

            // update the run, if the new one can drop-in replace the old one. Used for updating field names or general format
            val newLengthReasonable = existingRun.length <= replacementRun.length || allowShorterLength(reference.name)
            val sameStartAddress = existingRun.start == replacementRun.start
            if (sameStartAddress && newLengthReasonable && existingRun.formatString != replacementRun.formatString) {
                observeAnchorWritten(noChange, reference.name, replacementRun)
                changedLocations.add(destination)
            }

            // update runs that care about this name
            var i = -1
            while (true) {
                i++
                if (i >= runs.size) break
                // update matched-length lengths
                val arrayCandidate = runs[i]
                if (arrayCandidate is ArrayRun) {
                    val array: ArrayRun = arrayCandidate
                    val parentName = array.lengthFromAnchor
                    val childTableName: String? = anchorForAddress[array.start]
                    if (parentName == anchor) {
                        val lengthModifier = array.formatString.split(parentName).last()
                        val newLengthToken = reference.name + array.lengthFromAnchor.substring(parentName.length)
                        val arrayClose = array.formatString.lastIndexOf(']')
                        val newFormat = array.formatString.substring(0, arrayClose + 1)
                        val newRunRef = Ref<ITableRun?>(null)
                        ArrayRun.tryParse(this, newFormat + newLengthToken + lengthModifier, array.start, array.pointerSources, newRunRef)
                        val newRun = newRunRef.value
                        if (newRun != null) {
                            clearFormat(noChange, newRun.start, newRun.length)
                            if (childTableName == null) {
                                observeRunWritten(noChange, newRun)
                            } else {
                                observeAnchorWritten(noChange, childTableName, newRun)
                            }
                            i = binarySearch(newRun.start)
                            if (i < 0) i = i.inv()
                            if (i >= runs.size) break
                        }
                    }
                    if (parentName == reference.name) {
                        // there's a table that depends on the new name, which wasn't available yet.
                        // re-evaluate that table to get the right length.
                        val newRunRef = Ref<ITableRun?>(null)
                        ArrayRun.tryParse(this, array.formatString, array.start, array.pointerSources, newRunRef)
                        val newRun = newRunRef.value
                        if (newRun != null) {
                            clearFormat(noChange, newRun.start, newRun.length)
                            if (childTableName == null) {
                                observeRunWritten(noChange, newRun)
                            } else {
                                observeAnchorWritten(noChange, childTableName, newRun)
                            }
                            i = binarySearch(newRun.start)
                            if (i < 0) i = i.inv()
                            if (i >= runs.size) break
                        }
                    }
                }

                if (changedLocations.contains(runs[i].start)) continue // we've already updated this run, no need to check it again

                // update enum names / bitarray names
                val tableCandidate = runs[i]
                if (tableCandidate is ITableRun) {
                    var table: ITableRun = tableCandidate
                    for (j in 0 until table.elementContent.size) {
                        val segment = table.elementContent[j]
                        if (segment is ArrayRunEnumSegment && segment.enumName == anchor) {
                            val segments = table.elementContent.toMutableList()
                            segments[j] = ArrayRunEnumSegment(segment.name, segment.length, reference.name)
                            table = table.duplicate(table.start, table.pointerSources, segments)
                            runs[i] = table
                        } else if (segment is ArrayRunBitArraySegment && segment.sourceArrayName == anchor) {
                            val segments = table.elementContent.toMutableList()
                            segments[j] = ArrayRunBitArraySegment(segment.name, segment.length, reference.name)
                            table = table.duplicate(table.start, table.pointerSources, segments)
                            runs[i] = table
                        }
                    }
                }

                // update tileset hints
                val tilemapCandidate = runs[i]
                if (tilemapCandidate is ITilemapRun) {
                    val format = tilemapCandidate.format
                    if (format.matchingTileset != anchor) continue
                    val tilemap = tilemapCandidate.duplicate(TilemapFormat(format.bitsPerPixel, format.tileWidth, format.tileHeight, reference.name, format.tilesetTableMember, format.allowLengthErrors))
                    runs[i] = tilemap
                }

                // update palette hints
                val spriteCandidate = runs[i]
                if (spriteCandidate is ISpriteRun) {
                    if (spriteCandidate is LzTilemapRun) continue
                    val format = spriteCandidate.spriteFormat
                    if (format.paletteHint != anchor) continue
                    val sprite = spriteCandidate.duplicate(SpriteFormat(format.bitsPerPixel, format.tileWidth, format.tileHeight, reference.name, format.allowLengthErrors))
                    runs[i] = sprite
                }

                // update dependent streams
                val streamCandidate = runs[i]
                if (streamCandidate is IStreamRun && streamCandidate.dependsOn(reference.name)) {
                    // clear/observe is heavy-handed, but it clears any stray pointers
                    val newRun = streamCandidate.duplicate(streamCandidate.start, streamCandidate.pointerSources)
                    val anchorName = anchorForAddress[streamCandidate.start]
                    if (anchorName != null) {
                        clearFormat(noChange, newRun.start, newRun.length)
                        observeAnchorWritten(noChange, anchorName, newRun)
                    } else {
                        clearFormat(noChange, newRun.start, newRun.length)
                        observeRunWritten(noChange, newRun)
                    }
                }
            }
        }
    }
    private fun searchForPointers(pointersForDestination: MutableMap<Int, SortedSpan<Int>>, destinationForSource: java.util.TreeMap<Int, Int>) { /*@DONE PokemonModel.SearchForPointers/1 cs:469-497*/
        val data = rawData
        // pointers must be 4-byte aligned
        for (i in 0 until data.size - 3 step 4) {

            // pointers must end in 08 or 09
            val last = data[i + 3].toInt() and 0xFF
            if (last != 0x08 && last != 0x09) continue

            // pointers must point to locations that are 4-byte aligned
            if ((data[i].toInt() and 0xFF) % 4 != 0) continue
            val source = i
            val destination = readPointer(i)

            // pointers must point into the data
            if (destination >= data.size) continue

            // pointers must not point at the header
            if (destination < earliestAllowedAnchor) continue

            // pointers must point at something useful, not just a bunch of FF
            var pointsToManyFF = true
            var j = 0
            while (j < 4 && pointsToManyFF && destination + j < data.size) {
                pointsToManyFF = (data[destination + j].toInt() and 0xFF) == 0xFF
                j++
            }
            if (pointsToManyFF) continue

            // we found a pointer!
            val existing = pointersForDestination[destination] ?: SortedSpan.none<Int>()
            pointersForDestination[destination] = existing.add1(source)
            destinationForSource[source] = destination
        }
    }
    private fun writePointerRuns(pointersForDestination: MutableMap<Int, SortedSpan<Int>>, destinationForSource: java.util.TreeMap<Int, Int>) { /*@DONE PokemonModel.WritePointerRuns/1 cs:499-531*/
        val destinations = ArrayList<Int>(pointersForDestination.keys)
        destinations.sort()
        val sources = ArrayList<Int>(destinationForSource.keys)
        var di = 0
        var si = 0

        synchronized(threadlock) {
            while (di < destinations.size && si < sources.size) {
                val d = destinations[di]
                val s = sources[si]
                if (d < s) {
                    runs.add(NoInfoRun(d, pointersForDestination[d]))
                    di++
                } else if (s < d) {
                    runs.add(PointerRun(s))
                    si++
                } else {
                    runs.add(PointerRun(s, pointersForDestination[d]))
                    di++
                    si++
                }
            }

            while (di < destinations.size) {
                val d = destinations[di]
                runs.add(NoInfoRun(d, pointersForDestination[d]))
                di++
            }

            while (si < sources.size) {
                runs.add(PointerRun(sources[si]))
                si++
            }
        }
    }
    private fun writeSpriteRuns(pointersForDestination: MutableMap<Int, SortedSpan<Int>>) { /*@DONE PokemonModel.WriteSpriteRuns/1 cs:533-553*/
        val noDataChange = NoDataChangeDeltaModel()
        val destinations = ArrayList<Int>(pointersForDestination.keys)
        destinations.sort()
        for (destination in destinations) {
            synchronized(threadlock) {
                val existingRun = getNextRun(destination)
                if (existingRun !is NoInfoRun) return@synchronized
                val protoRun = LZRun(this, destination)
                if (protoRun.length < 5) return@synchronized
                if (protoRun.decompressedLength < 32 || protoRun.decompressedLength % 32 != 0) return@synchronized
                if (getNextRun(destination + 1).start < destination + protoRun.length) return@synchronized
                if (protoRun.decompressedLength == 32) {
                    observeRunWritten(noDataChange, LzPaletteRun(PaletteFormat(4, 1), this, destination, pointersForDestination[destination]))
                } else {
                    val tiles = protoRun.decompressedLength / 32
                    val sqrt = Math.sqrt(tiles.toDouble()).toInt()
                    val spriteFormat = SpriteFormat(4, sqrt, sqrt, null)
                    observeRunWritten(noDataChange, LzSpriteRun(spriteFormat, this, destination, pointersForDestination[destination]))
                }
            }
        }
    }
    private fun writeStringRuns(pointersForDestination: MutableMap<Int, SortedSpan<Int>>) { /*@DONE PokemonModel.WriteStringRuns/1 cs:555-566*/
        val noDataChange = NoDataChangeDeltaModel()
        val keys = ArrayList<Int>(pointersForDestination.keys)
        keys.sort()
        val data = rawData.asByteList()
        for (destination in keys) {
            val length = PCSString.readString(data, destination, false)
            if (length < 2) continue
            synchronized(threadlock) {
                if (getNextRun(destination + 1).start < destination + length) return@synchronized
                observeRunWritten(noDataChange, PCSRun(this, destination, length, pointersForDestination[destination]))
            }
        }
    }
    fun resolveConflicts() { /*@DONE PokemonModel.ResolveConflicts/1 cs:569-705*/
        // The original only performs consistency assertions here (Debug.Assert / Debug.Fail), which have no effect on the model.
    }
    private fun doNotChangeFormatOnUpdate(format: String): Boolean { /*@DONE PokemonModel.DoNotChangeFormatOnUpdate/1 cs:707-715*/
        // move utility changes the format of moves.stats: effects is now 2 bytes and other formats have moved.
        if (format.contains("[effect:") && format.contains(" pp. ")) return true

        // move utility changes the format of moves.levelup: pointer is now to a series of 4-byte tokens
        if (format.contains(" level:]!FFFFFFFF>]")) return true

        return false
    }
    private fun allowShorterLength(name: String): Boolean { /*@DONE PokemonModel.AllowShorterLength/1 cs:717-722*/
        if (this.isEmerald()) {
            return name == HardcodeTablesModel.overworldSprites
        }
        return false
    }
    private fun fillGotoModels(metadata: StoredMetadata) { /*@DONE PokemonModel.FillGotoModels/1 cs:724-730*/
        @Suppress("UNCHECKED_CAST")
        val shortcuts = gotoShortcuts as MutableList<GotoShortcutModel>
        for (shortcut in metadata.gotoShortcuts) {
            if (shortcuts.any { s -> s.displayText == shortcut.display }) continue // don't double-add the same shortcut
            shortcuts.add(GotoShortcutModel(shortcut.image ?: "", shortcut.anchor, shortcut.display))
        }
    }
    override fun getMatchedWords(name: String): List<Int>? { /*@DONE PokemonModel.GetMatchedWords/1 cs:819-822*/
        val list = matchedWords[name]
        if (list != null) return ArrayList(list)
        return ArrayList()
    }
    override fun getUnmappedSourcesToAnchor(anchor: String): SortedSpan<Int> { /*@DONE PokemonModel.GetUnmappedSourcesToAnchor/1 cs:824-827*/
        val list = unmappedNameToSources[anchor] ?: return SortedSpan.none<Int>()
        return list
    }
    override fun setUnmappedConstant(changeToken: ModelDelta, name: String, value: Int) { /*@DONE PokemonModel.SetUnmappedConstant/1 cs:829-832*/
        unmappedConstants[name.lowercase()] = value
        changeToken.addUnmappedConstant(name.lowercase(), value)
    }
    override fun tryGetUnmappedConstant(name: String, value: Ref<Int>): Boolean { /*@DONE PokemonModel.TryGetUnmappedConstant/1 cs:834-834*/
        val found = unmappedConstants[name.lowercase()]
        if (found == null) {
            value.value = 0
            return false
        }
        value.value = found
        return true
    }
    override fun getAddressFromAnchor(changeToken: ModelDelta?, requestSource: Int, anchor: String): Int { /*@DONE PokemonModel.GetAddressFromAnchor/1 cs:836-873*/
        var nameparts = anchor.split("/")
        val anchorName = nameparts.first()

        val addressRef = Ref(0)
        if (addressForAnchor.tryGetValueCaseInsensitive(anchorName, addressRef)) {
            nameparts = nameparts.drop(1).toTypedArray()
            var address = addressRef.value
            if (nameparts.size > 0) address = getAddressFromAnchor(address, nameparts)
            return address
        }

        // check if it's a named constant with a valid index specifier
        if (anchorName.contains("~")) {
            val constantParts = anchorName.split("~")
            val constantIndexRef = Ref(0)
            if (constantParts.size == 2 && tryParseInt(constantParts[1], constantIndexRef)) {
                val constantAddresses = matchedWords[constantParts[0]]
                val constantIndex = constantIndexRef.value
                if (constantAddresses != null && constantAddresses.size >= constantIndex && constantIndex > 0) {
                    val sortedConstantAddresses = constantAddresses.sorted()
                    return sortedConstantAddresses[constantIndex - 1]
                }
            }
        }

        if (requestSource < 0) return Pointer.null_
        if (anchorName.lowercase() == "null") return Pointer.null_

        // the named anchor does not exist! Add it to the list of desired anchors
        if (!unmappedNameToSources.containsKey(anchorName)) {
            unmappedNameToSources[anchorName] = SortedSpan.none<Int>()
        }
        unmappedNameToSources[anchorName] = unmappedNameToSources[anchorName]!!.add1(requestSource)
        sourceToUnmappedName[requestSource] = anchorName
        changeToken?.addUnmappedPointer(requestSource, anchorName)

        return Pointer.null_
    }
    private fun getAddressFromAnchor(startingAddress: Int, nameparts: Array<String>): Int { /*@DONE PokemonModel.GetAddressFromAnchor/2 cs:875-909*/
        val run = getNextRun(startingAddress)

        // support empty string as element 0
        if (nameparts[0] == "") return run.start

        // only support indexing into an anchor if the anchor points to an array
        if (run !is ITableRun) return Pointer.null_
        val array: ITableRun = run

        if (nameparts.size < 1) return Pointer.null_

        // support things like .../4
        val indexRef = Ref(0)
        if (!tryParseInt(nameparts[0], indexRef)) {
            // support things like .../BULBASAUR
            val elementNames = array.elementNames ?: return Pointer.null_
            if (!ArrayRunEnumSegment.tryMatch(nameparts[0], elementNames, indexRef)) return Pointer.null_
        }
        val index = indexRef.value

        val elementStart = array.start + array.elementLength * index
        if (nameparts.size == 1) return elementStart

        // support things like .../4/name
        var segmentOffset = 0
        for (segment in array.elementContent) {
            if (segment.name.lowercase() == nameparts[1].lowercase()) {
                val segmentStart = elementStart + segmentOffset
                if (nameparts.size > 2 && segment.type == ElementContentType.Pointer) {
                    return getAddressFromAnchor(readPointer(segmentStart), nameparts.drop(2).toTypedArray())
                }
                return segmentStart
            }
            segmentOffset += segment.length
        }

        return Pointer.null_
    }
    override fun getAnchorFromAddress(requestSource: Int, address: Int): String { /*@DONE PokemonModel.GetAnchorFromAddress/1 cs:915-935*/
        // option 1: a known name exists for this address
        val known = anchorForAddress[address]
        if (known != null) return known

        // option 2: a known name exists for this source, but the name doesn't actually exist in the file
        val unmapped = sourceToUnmappedName[requestSource]
        if (unmapped != null) return unmapped

        // option 3: pointing to nothing
        if (address == -0x08000000) return "null"

        // option 4: pointing within an array that supports inner element anchors
        val containingRun = getNextRun(address)
        if (containingRun.start < address && containingRun is ArrayRun) {
            val arrayName = getAnchorFromAddress(-1, containingRun.start)
            val arrayIndex = (address - containingRun.start) / containingRun.elementLength
            val indexMod = (address - containingRun.start) % containingRun.elementLength
            if (indexMod == 0) return "" + arrayName + ArrayRun.arrayAnchorSeparator + arrayIndex
        }

        return ""
    }
    private val threadlock: Any = /*@INITDONE PokemonModel.threadlock cs:937-937*/ Any() /*@ENDINIT*/
    fun threadlockRuns(action: () -> Unit) { /*@DONE PokemonModel.ThreadlockRuns/1 cs:942-944*/
        synchronized(threadlock) { action() }
    }
    override fun getNextRun(dataIndex: Int): IFormattedRun { /*@DONE PokemonModel.GetNextRun/1 cs:946-953*/
        if (dataIndex == Pointer.null_) return NoInfoRun.nullRun
        synchronized(threadlock) {
            val index = getIndexForNextRun(dataIndex)
            if (index >= runs.size) return NoInfoRun.nullRun
            return runs[index]
        }
    }
    private fun getNextRunUnthreaded(dataIndex: Int): IFormattedRun { /*@DONE PokemonModel.GetNextRunUnthreaded/1 cs:958-963*/
        if (dataIndex == Pointer.null_) return NoInfoRun.nullRun
        val index = getIndexForNextRun(dataIndex)
        if (index >= runs.size) return NoInfoRun.nullRun
        return runs[index]
    }
    private fun getIndexForNextRun(address: Int): Int { /*@DONE PokemonModel.GetIndexForNextRun/1 cs:965-974*/
        var index = binarySearch(address)
        if (index >= 0) return index
        index = index.inv()
        if (index > 0) {
            val previous = runs[index - 1]
            if (previous.start + previous.length > address) index -= 1
        }
        return index
    }
    override fun getNextAnchor(dataIndex: Int): IFormattedRun { /*@DONE PokemonModel.GetNextAnchor/1 cs:976-985*/
        synchronized(threadlock) {
            var index = binarySearchNext(dataIndex)
            while (index < runs.size) {
                val run = runs[index]
                index++
                if (run.start < dataIndex) continue
                if (run.pointerSources == null) continue
                return run
            }
        }
        return NoInfoRun.nullRun
    }
    override fun tryGetUsefulHeader(address: Int, header: Ref<String?>): Boolean { /*@DONE PokemonModel.TryGetUsefulHeader/1 cs:987-1017*/
        header.value = null
        // only produce headers for arrays with length based on other arrays that start with a text member.
        val run = getNextRun(address)
        if (run.start > address) return false
        var targetAddress = address
        synchronized(threadlock) {
            val array: ArrayRun
            if (run !is ArrayRun) {
                val runSources = run.pointerSources
                if (runSources != null && runSources.size > 0 && run.start == targetAddress) {
                    val parentRun = getNextRun(runSources[0])
                    if (parentRun is ArrayRun) {
                        array = parentRun
                        val arrayIndex = parentRun.convertByteOffsetToArrayOffset(runSources[0]).elementIndex
                        targetAddress = parentRun.start + arrayIndex * parentRun.elementLength
                    } else {
                        return false
                    }
                } else {
                    return false
                }
            } else {
                array = run
            }

            if ((targetAddress - array.start) % array.elementLength != 0) return false

            val index = (targetAddress - array.start) / array.elementLength
            val names = array.elementNames ?: return false
            if (names.size <= index) return false
            header.value = names[index]

            return true
        }
    }
    override fun isAtEndOfArray(dataIndex: Int, arrayRun: Ref<ITableRun?>): Boolean { /*@DONE PokemonModel.IsAtEndOfArray/1 cs:1019-1039*/
        synchronized(threadlock) {
            var index = binarySearch(dataIndex)
            if (index >= 0 && runs[index].length == 0) {
                arrayRun.value = runs[index] as? ITableRun
                return arrayRun.value != null
            }

            if (index < 0) index = index.inv()
            index -= 1

            if (index < 0) {
                arrayRun.value = null
                return false
            }

            val table = runs[index] as? ITableRun
            arrayRun.value = table
            if (table is TableStreamRun && table.elementCount * table.elementLength != table.length) return false
            return table != null && table.start + table.length == dataIndex
        }
    }
    override fun observeRunWritten(changeToken: ModelDelta, run: IFormattedRun) { /*@DONE PokemonModel.ObserveRunWritten/1 cs:1041-1143*/
        synchronized(threadlock) {
            var r: IFormattedRun = run
            if (r is ArrayRun) {
                // update any words who's name matches this array's name
                val anchorName = anchorForAddress[r.start]
                if (anchorName != null) {
                    val words = matchedWords[anchorName]
                    if (words != null && changeToken !is NoDataChangeDeltaModel) {
                        val elementCount = r.elementCount
                        for (address in ArrayList(words)) writeValue(changeToken, address, elementCount)
                    }
                }
            }

            var index = binarySearch(r.start)
            var existingRun: IFormattedRun? = null
            if (index < 0) {
                index = index.inv()

                // check for conflict with previous run / next run
                if (index > 0 && r.start < runs[index - 1].start + runs[index - 1].length) {
                    // Trying to add a run which overlaps the previous run: ignore it.
                } else if (index < runs.size && runs[index].start < r.start + r.length) {
                    // Trying to add a run which overlaps the next run: ignore it.
                } else {
                    runs.add(index, r)
                    changeToken.addRun(r)
                }
            } else {
                // replace / merge with existing
                // if the only thing changed was the anchor, then don't change the format, just merge the anchor
                val existing = runs[index]
                existingRun = existing
                changeToken.removeRun(existing)
                if (existing is PointerRun) {
                    var needClearPointerRun = r !is NoInfoRun && r !is PointerRun
                    val newOffset = (r as? OffsetPointerRun)?.offset ?: 0
                    val oldOffset = (existing as? OffsetPointerRun)?.offset ?: 0
                    if (newOffset != oldOffset) needClearPointerRun = true
                    if (needClearPointerRun) {
                        val destination = readPointer(existing.start)
                        clearPointer(changeToken, existing.start, destination)
                        index = binarySearch(r.start) // have to recalculate index, because ClearPointer can removed runs.
                    }
                }
                r = r.mergeAnchor(existing.pointerSources)
                if (r is NoInfoRun) r = existing.mergeAnchor(r.pointerSources) // when writing an anchor with no format, keep the existing format.
                val existingTable = existing as? ITableRun
                val newTable = r as? ITableRun
                if (existingTable != null && newTable != null) {
                    if (existingTable.elementLength != newTable.elementLength) {
                        // we need to clear all the pointers, the element length changed
                        modifyAnchorsFromPointerArray(changeToken, existingTable, null, existingTable.elementCount) { seg, segs, parentIndex, token, start -> clearPointerFormat(seg, segs, parentIndex, token, start) }
                    } else {
                        modifyAnchorsFromPointerArray(changeToken, newTable, existingTable, existingTable.elementCount) { seg, segs, parentIndex, token, start -> clearPointerFormat(seg, segs, parentIndex, token, start) }
                    }
                    index = binarySearch(r.start) // have to recalculate index, because ClearPointerFormat can removed runs.
                }
                setIndex(index, r)
                changeToken.addRun(r)
            }

            val written: IFormattedRun = r
            if (written is WordRun && written.start + written.length <= count) {
                var wordSet = matchedWords[written.sourceArrayName]
                if (wordSet == null) {
                    wordSet = LinkedHashSet()
                    matchedWords[written.sourceArrayName] = wordSet
                }
                wordSet.add(written.start)
                changeToken.addMatchedWord(this, written.start, written.sourceArrayName, written.length)
                CompleteCellEdit.updateAllWords(this, written, changeToken, this.readMultiByteValue(written.start, written.length), true)
            } else if (written is OffsetPointerRun) {
                pointerOffsets[written.start] = written.offset
                changeToken.addOffsetPointer(written.start, written.offset)
            }

            if (written is PointerRun) addPointerToAnchor(null, null, 0, changeToken, written.start)
            if (written is ITableRun) modifyAnchorsFromPointerArray(changeToken, written, existingRun as? ITableRun, written.elementCount) { seg, segs, parentIndex, token, start -> addPointerToAnchor(seg, segs, parentIndex, token, start) }
            if (written is ArrayRun) updateDependantArrayLengths(changeToken, written)

            val writtenSources = written.pointerSources
            if (written is NoInfoRun && writtenSources != null && writtenSources.size == 0 && !anchorForAddress.containsKey(written.start)) {
                // this run has no useful information. Remove it.
                changeToken.removeRun(runs[index])
                removeIndex(index)
            }
            if (written is PointerRun && writtenSources != null && writtenSources.size == 0 && !anchorForAddress.containsKey(written.start)) {
                // this run contains useful information, but no useful anchors. Remove the pointer sources.
                r = written.duplicate(written.start, null)
                changeToken.addRun(r)
                setIndex(index, r)
            }

            // we shortened a table that had inner anchors. Those inner anchors should not be cleared.
            val shortened = existingRun
            if (shortened is ArrayRun && shortened.supportsInnerPointers && shortened.length > r.length) {
                val innerSources = shortened.pointerSourcesForInnerElements
                if (innerSources != null) {
                    for (i in 0 until shortened.elementCount) {
                        if (shortened.elementLength * i < r.length) continue
                        val sources = innerSources[i]
                        for (source in sources) {
                            if (getNextRun(source).start >= source + 4) {
                                // there was a pointer here, it's probably valid so we should re-add it
                                val pRun = PointerRun(source)
                                runs.add(binarySearch(source).inv(), pRun)
                                changeToken.addRun(pRun)
                            }
                        }
                        observeRunWritten(changeToken, NoInfoRun(shortened.start + shortened.elementLength * i, sources))
                    }
                }
            }
        }
    }
    override fun readPointer(index: Int): Int { /*@DONE PokemonModel.ReadPointer/1 cs:1145-1149*/
        var destination = super.readPointer(index)
        val offset = pointerOffsets[index]
        if (offset != null) destination -= offset
        return destination
    }
    override fun writePointer(changeToken: ModelDelta, address: Int, pointerDestination: Int): Boolean { /*@DONE PokemonModel.WritePointer/1 cs:1151-1154*/
        var destination = pointerDestination
        val offset = pointerOffsets[address]
        if (offset != null) destination += offset
        return super.writePointer(changeToken, address, destination)
    }
    private fun modifyAnchorsFromPointerArray(changeToken: ModelDelta, arrayRun: ITableRun, previousTable: ITableRun?, elementCount: Int, changeAnchors: (ArrayRunElementSegment, List<ArrayRunElementSegment>, Int, ModelDelta, Int) -> Unit) { /*@DONE PokemonModel.ModifyAnchorsFromPointerArray/1 cs:1161-1196*/
        var segmentOffset = arrayRun.start
        val formatMatches = previousTable != null && arrayRun.dataFormatMatches(previousTable)
        var parentOffset = 0
        if (arrayRun is ArrayRun) parentOffset = Math.max(arrayRun.parentOffset.endMargin, 0)
        val shorterTable = Math.min(arrayRun.elementCount, previousTable?.elementCount ?: arrayRun.elementCount)
        // i loops over the different segments in the array
        for (i in 0 until arrayRun.elementContent.size) {
            var segment = arrayRun.elementContent[i]

            // record segments _might_ be pointers... sometimes. Need to check every element
            if (segment is ArrayRunRecordSegment) {
                val recordSeg: ArrayRunRecordSegment = segment
                for (j in 0 until elementCount) {
                    val start = segmentOffset + arrayRun.elementLength * j
                    segment = recordSeg.createConcrete(this, arrayRun, start)
                    if (segment.type == ElementContentType.Pointer) {
                        if (formatMatches && shorterTable - parentOffset > j) continue // we can skip this one
                        changeAnchors(segment, arrayRun.elementContent, j, changeToken, start)
                    }
                }
                segmentOffset += segment.length
                continue
            }
            if (arrayRun.elementContent[i].type != ElementContentType.Pointer) {
                segmentOffset += segment.length
                continue
            }
            // for a pointer segment, j loops over all the elements in the array
            var reverse = false
            if (segment is ArrayRunPointerSegment && segment.innerFormat.endsWith("?")) reverse = true
            val range: IntProgression = if (reverse) (elementCount - 1 downTo 0) else (0 until elementCount)
            for (j in range) {
                if (formatMatches && shorterTable - parentOffset > j) continue // we can skip this one
                val start = segmentOffset + arrayRun.elementLength * j
                changeAnchors(segment, arrayRun.elementContent, j, changeToken, start)
            }
            segmentOffset += segment.length
        }
    }
    private fun updateAnchorsFromArrayMove(changeToken: ModelDelta, original: ITableRun, moved: ITableRun) { /*@DONE PokemonModel.UpdateAnchorsFromArrayMove/1 cs:1204-1245*/
        var originalOffset = original.start
        var segmentOffset = moved.start
        if (original.elementContent.size != moved.elementContent.size) return // if the number of elements changed during the move, nop out
        // i loops over the different segments in the array
        for (i in 0 until moved.elementContent.size) {
            var seg = moved.elementContent[i]
            if (seg is ArrayRunRecordSegment) seg = seg.createConcrete(this, moved, segmentOffset)
            if (seg.type != ElementContentType.Pointer) {
                originalOffset += original.elementContent[i].length
                segmentOffset += moved.elementContent[i].length
                continue
            }
            // for a pointer segment, j loops over all the elements in the array
            for (j in 0 until moved.elementCount) {
                val originalStart = originalOffset + original.elementLength * j
                val movedStart = segmentOffset + moved.elementLength * j
                val destination = readPointer(movedStart)
                if (destination < 0 || destination >= rawData.size) continue
                var destinationRun: IFormattedRun = getNextRun(destination)
                if (destination == moved.start) destinationRun = moved
                changeToken.removeRun(destinationRun)

                val current = destinationRun
                val currentSources = current.pointerSources
                if (current is ISupportInnerPointersRun && current.supportsInnerPointers) {
                    // special case: use the override methods to handle inner-pointers
                    val destinationTable = current.removeInnerSource(originalStart)
                    destinationRun = destinationTable.addSourcePointingWithinRun(movedStart)
                } else if (currentSources != null && currentSources.contains(originalStart)) { // only add it if it previously pointed to the start of the run
                    destinationRun = current.removeSource(originalStart)
                    destinationRun = destinationRun.mergeAnchor(SortedSpan(movedStart))
                }

                changeToken.addRun(destinationRun)
                val runIndex = binarySearch(destinationRun.start)
                if (runIndex >= 0) {
                    setIndex(runIndex, destinationRun)
                }
            }
            originalOffset += original.elementContent[i].length
            segmentOffset += moved.elementContent[i].length
        }
    }
    private fun updateDependantArrayLengths(changeToken: ModelDelta, arrayRun: ArrayRun) { /*@DONE PokemonModel.UpdateDependantArrayLengths/1 cs:1252-1316*/
        val anchor = anchorForAddress[arrayRun.start] ?: return
        val dependentArrays = ArrayList<ArrayRun>(this.getDependantArrays(anchor).toList())
        for (table in dependentArrays) {
            var newTable: ArrayRun = table

            // runs may have changed since getting the dependent arrays
            // try to update newTable to be the most recent version from the model
            val latest = getNextRun(newTable.start) as? ArrayRun
            if (latest != null && latest.start == table.start) newTable = latest // else: update failed

            // option 1: this table's length is based on the given table
            if (anchor == table.lengthFromAnchor) {
                val targetCount = arrayRun.elementCount + table.parentOffset.beginningMargin + table.parentOffset.endMargin
                if (newTable.elementCount == targetCount) continue
                // only relocate if we're not in a loading situation
                if (changeToken !is NoDataChangeDeltaModel) {
                    newTable = relocateForExpansion(changeToken, table, targetCount * table.elementLength)
                }
                val originalLength = newTable.length

                // clear any possible metadata in the way of appending (only matters if we didn't relocate
                // note that we need to do this _before_ Append is called
                val lengthChange = (targetCount - table.elementCount) * newTable.elementLength
                if (lengthChange > 0) clearFormat(changeToken, newTable.start + originalLength, lengthChange)

                val tableAnchor = getAnchorFromAddress(-1, newTable.start)
                newTable = newTable.append(changeToken, targetCount - table.elementCount)

                // clear any possible remaining metadata after contracting
                // note that we need to do this _after_ Append is called
                if (newTable.length < originalLength) clearFormat(changeToken, newTable.start, originalLength)

                if (tableAnchor.isEmpty()) {
                    observeRunWritten(changeToken, newTable)
                } else {
                    observeAnchorWritten(changeToken, tableAnchor, newTable)
                }

                // if this run has pointers, those may have been cleared by some earlier update
                this.insertPointersToRun(changeToken, newTable)
            }
            // option 2: this table includes a bit-array based on the given table
            val requiredByteLength = Math.ceil(arrayRun.elementCount / 8.0).toInt()
            for (segmentIndex in 0 until newTable.elementContent.size) {
                val bitSegment = newTable.elementContent[segmentIndex] as? ArrayRunBitArraySegment ?: continue
                if (bitSegment.sourceArrayName != anchor) continue
                if (bitSegment.length == requiredByteLength) continue

                // if the changeToken is a NoChange, we're still in the middle of loading
                // in that case, don't try to relocate/shift anything, just grow the proper segment based on the length of the newly loaded table
                val newElementWidth = newTable.elementLength - bitSegment.length + requiredByteLength
                if (changeToken !is NoDataChangeDeltaModel) {
                    newTable = relocateForExpansion(changeToken, table, newTable.elementCount * newElementWidth)
                    // within the new table, shift all the data to fit the new data width
                    shiftTableBytesForGrowingSegment(changeToken, newTable, requiredByteLength, segmentIndex)
                } else {
                    // we didn't relocate/shift, but we still need to clear the area before growing the table
                    clearFormat(changeToken, newTable.start + newTable.length, newTable.elementCount * (newElementWidth - newTable.elementLength))
                }
                newTable = newTable.growBitArraySegment(segmentIndex, requiredByteLength - bitSegment.length)
                observeRunWritten(changeToken, newTable)
            }
        }
    }
    private fun shiftTableBytesForGrowingSegment(changeToken: ModelDelta, table: ArrayRun, newLength: Int, segmentIndex: Int) { /*@DONE PokemonModel.ShiftTableBytesForGrowingSegment/1 cs:1322-1345*/
        val segment = table.elementContent[segmentIndex]
        // since we're moving data in-place, start at the end and work our way to the front to avoid overwriting anything we haven't read yet.
        val oldElementWidth = table.elementLength
        val newElementWidth = table.elementLength - segment.length + newLength
        for (elementIndex in table.elementCount - 1 downTo 0) {
            var sourceIndex = table.start + oldElementWidth * (elementIndex + 1) - 1
            var destinationIndex = table.start + newElementWidth * (elementIndex + 1) - 1
            for (movingSegment in table.elementContent.reversed()) {
                // if we're at the segment that's expanding, expand it by filling with 0's
                if (movingSegment === segment) {
                    for (k in 0 until (newLength - segment.length)) {
                        changeToken.changeData(this, destinationIndex, 0)
                        destinationIndex--
                    }
                }
                // move the source data to the destination point
                for (k in 0 until movingSegment.length) {
                    changeToken.changeData(this, destinationIndex, rawData[sourceIndex].toInt() and 0xFF)
                    sourceIndex--
                    destinationIndex--
                }
            }
        }
    }
    private fun addPointerToAnchor(segment: ArrayRunElementSegment?, segments: List<ArrayRunElementSegment>?, parentIndex: Int, changeToken: ModelDelta, start: Int) { /*@DONE PokemonModel.AddPointerToAnchor/1 cs:1353-1355*/
        addPointerToAnchor(segment, segments, parentIndex, changeToken, start, true)
    }
    private fun addPointerToAnchor(segment: ArrayRunElementSegment?, segments: List<ArrayRunElementSegment>?, parentIndex: Int, changeToken: ModelDelta, start: Int, includeFormatting: Boolean) { /*@DONE PokemonModel.AddPointerToAnchor/2 cs:1357-1439*/
        var seg = segment
        if (seg is ArrayRunRecordSegment) seg = seg.createConcrete(this, start)
        val destination = readPointer(start)
        if (destination < 0 || destination >= count) return
        var index = binarySearch(destination)
        val candidate = if (index < 0 && index.inv() > 0) runs[index.inv() - 1] else null
        if (candidate is ArrayRun &&
            candidate.supportsInnerPointers &&
            candidate.start + candidate.length > destination &&
            (destination - candidate.start) % candidate.elementLength == 0) {
            // the pointer points into an array that supports inner anchors
            index = index.inv() - 1
            changeToken.removeRun(candidate)
            setIndex(index, candidate.addSourcePointingWithinRun(start))
            changeToken.addRun(runs[index])
        } else if (index < 0) {
            // the pointer points to a location between existing runs
            var sources = SortedSpan(start)
            sources = sources.add(searchForPointersInTables(changeToken, destination))
            val newRunRef = Ref<IFormattedRun?>(NoInfoRun(destination, sources))
            if (includeFormatting) {
                updateNewRunFromPointerFormat(newRunRef, seg as? ArrayRunPointerSegment, segments, parentIndex, changeToken)
            }
            var newRun = newRunRef.value
            if (newRun != null) {
                if (newRun.start < start && newRun.start + newRun.length > start) {
                    // the new run conflicts with the pointer that points to it
                    // don't add the new run
                    newRun = NoInfoRun(newRun.start, newRun.pointerSources)
                } else if (newRun.length <= 0) {
                    // run has no length, something went wrong creating the new run.
                    newRun = NoInfoRun(newRun.start, newRun.pointerSources)
                }
                val existingRun = getNextRun(newRun.start)
                if (existingRun.start == newRun.start) {
                    newRun = newRun.mergeAnchor(existingRun.pointerSources)
                }
                if (existingRun.start < newRun.start && !includeFormatting) {
                    // prefer to keep the existing run, not add the new run
                } else {
                    clearFormat(changeToken, newRun.start, newRun.length) // adding a new destination, so clear anything in the way.
                    observeRunWritten(changeToken, newRun)
                }
            }
        } else if (runs[index].start <= start && start < runs[index].start + runs[index].length) {
            // self-referential pointer: don't write a new run, just add the pointer
            var existingRun = runs[index]
            changeToken.removeRun(existingRun)
            existingRun = existingRun.mergeAnchor(SortedSpan(start))
            setIndex(index, existingRun)
            changeToken.addRun(existingRun)
        } else {
            // the pointer points to a known normal anchor
            val previousRun = runs[index]
            val merged = previousRun.mergeAnchor(SortedSpan(start))
            val existingAnchor = anchorForAddress[merged.start]
            val existingRunRef = Ref<IFormattedRun?>(merged)
            if (includeFormatting) {
                updateNewRunFromPointerFormat(existingRunRef, seg as? ArrayRunPointerSegment, segments, parentIndex, changeToken)
            }
            val existingRun = existingRunRef.value
            if (existingRun != null) {
                if (seg == null) {
                    // it's just a naked pointer, so we have no knowledge about the thing it points to.
                    index = binarySearch(destination) // runs could've been removed during UpdateNewRunFromPointerFormat: search for the index again.
                    if (index < 0) {
                        insertIndex(index.inv(), existingRun)
                    } else {
                        setIndex(index, existingRun)
                    }
                    changeToken.removeRun(previousRun)
                    changeToken.addRun(existingRun)
                } else {
                    if (previousRun.formatString != existingRun.formatString) {
                        // it could point to something interesting. Do a full observe. Start by clearing out any existing formats in that area.
                        clearFormat(changeToken, existingRun.start, existingRun.length)
                    }
                    if (existingAnchor != null) {
                        observeAnchorWritten(changeToken, existingAnchor, existingRun)
                    } else {
                        observeRunWritten(changeToken, existingRun)
                    }
                }
            }
        }
    }
    private fun updateNewRunFromPointerFormat(run: Ref<IFormattedRun?>, segment: ArrayRunPointerSegment?, segments: List<ArrayRunElementSegment>?, parentIndex: Int, token: ModelDelta) { /*@DONE PokemonModel.UpdateNewRunFromPointerFormat/1 cs:1445-1485*/
        val currentRun = run.value ?: return
        val nextRun = getNextRun(currentRun.start)
        if (nextRun === currentRun && nextRun is ITableRun) {
            // the parent table points into a table. The existing table format wins: just keep it the same.
            return
        }
        if (nextRun.start <= currentRun.start && nextRun is ITableRun && currentRun.javaClass != nextRun.javaClass) {
            // we're trying to point into a table. The table format wins: don't add any anchor.
            // this pointer is a 'bad' pointer: its pointing somewhere we KNOW doesn't contain the right data.
            run.value = null
            return
        }
        val nextSources = nextRun.pointerSources
        if (nextRun.start < currentRun.start && nextSources != null && nextSources.any { source -> getNextRun(source) is ITableRun }) {
            // we're trying to point into something that is owned by a table. The table format wins: don't add any anchor.
            // this pointer is a 'bad' pointer: its pointing somewhere we KNOW doesn't contain the right data.
            run.value = null
            return
        }

        if (segment == null) {
            // we don't know anything about the format, but we know a pointer starts here.
            // clear any existing formats that conflict with this pointer.
            if (currentRun.start != nextRun.start) clearFormat(token, currentRun.start, currentRun.length)
            return
        }

        val strategy = formatRunFactory.getStrategy(segment.innerFormat)
        if (strategy is TableStreamRunContentStrategy) {
            val tableStreamRef = Ref<TableStreamRun?>(null)
            if (segment.tryParseTableStream(this, currentRun.start, currentRun.pointerSources ?: SortedSpan.none<Int>(), segments ?: emptyList(), false, tableStreamRef)) {
                val newRun = tableStreamRef.value
                if (newRun != null) {
                    var existingRun = getNextRun(newRun.start)
                    while (existingRun.start < newRun.start + newRun.length) {
                        if (existingRun.start > newRun.start && existingRun is ITableRun) {
                            // we still care about the pointer, we just don't want to add the format
                            return
                        }
                        existingRun = getNextRun(existingRun.start + existingRun.length)
                    }
                }
            }
            val inner = Ref<IFormattedRun>(currentRun)
            strategy.updateNewRunFromPointerFormat(this, token, segment, segments ?: emptyList(), parentIndex, inner)
            run.value = inner.value
        } else if (strategy != null) {
            val inner = Ref<IFormattedRun>(currentRun)
            strategy.updateNewRunFromPointerFormat(this, token, segment.name, segments, parentIndex, inner)
            run.value = inner.value
        }
    }
    override fun observeAnchorWritten(changeToken: ModelDelta, anchorName: String, run: IFormattedRun) { /*@DONE PokemonModel.ObserveAnchorWritten/1 cs:1487-1551*/
        synchronized(threadlock) {
            var r: IFormattedRun = run
            val location = r.start
            val index = binarySearch(location)

            val existingRun: IFormattedRun? = if (index >= 0 && index < runs.size) runs[index] else null

            if (existingRun == null || existingRun.start != r.start) {
                // no format starts exactly at this anchor, so clear any format that goes over this anchor.
                clearFormat(changeToken, location, r.length)
            } else if (r !is NoInfoRun) {
                // a format starts exactly at this anchor.
                if (existingRun.length < r.length) {
                    // the new format may extend further. Clear excess space to make room for the longer format.
                    clearFormatAndAnchors(changeToken, existingRun.start + existingRun.length, r.length - existingRun.length)
                } else if (existingRun.length > r.length) {
                    // clear pointers from the end of the run?
                }
            }

            val oldAnchorName = anchorForAddress[location]
            if (oldAnchorName != null) {
                anchorForAddress.remove(location)
                addressForAnchor.remove(oldAnchorName)
                changeToken.removeName(location, oldAnchorName)
            }

            if (addressForAnchor.containsKey(anchorName)) {
                removeAnchorByName(changeToken, anchorName)
            }

            // if this anchor was given a name, add it
            if (anchorName != "") {
                anchorForAddress[location] = anchorName
                addressForAnchor.add(anchorName, location)
                changeToken.addName(location, anchorName)
            }

            var seekPointers = existingRun?.pointerSources == null || existingRun.start != location
            val runSources = r.pointerSources
            val noKnownPointers = runSources == null || runSources.size == 0
            seekPointers = seekPointers && noKnownPointers
            var sources = getSourcesPointingToNewAnchor(changeToken, anchorName, r, seekPointers).add(runSources)
            // remove any sources that were added _within_ the existing run
            var i = 0
            while (i < sources.size) {
                if (sources[i] <= r.start || sources[i] >= r.start + r.length) {
                    i++
                    continue
                }
                clearFormat(changeToken, sources[i], 4)
                sources = sources.remove1(sources[i])
            }

            // if we're adding an array, a few extra updates
            val newRun: IFormattedRun
            if (r is ArrayRun) {
                // update inner pointers and dependent arrays
                var array: ArrayRun = r
                if (array.supportsInnerPointers) array = array.addSourcesPointingWithinArray(changeToken)
                r = array
                newRun = r.mergeAnchor(sources)
            } else {
                newRun = r.duplicate(r.start, sources)
            }

            observeRunWritten(changeToken, newRun)

            clearCacheScope()
        }
    }
    override fun massUpdateFromDelta(runsToRemove: Map<Int, IFormattedRun>, runsToAdd: Map<Int, IFormattedRun>, namesToRemove: Map<Int, String>, namesToAdd: Map<Int, String>, unmappedPointersToRemove: Map<Int, String>, unmappedPointersToAdd: Map<Int, String>, matchedWordsToRemove: Map<Int, String>, matchedWordsToAdd: Map<Int, String>, offsetPointersToRemove: Map<Int, Int>, offsetPointersToAdd: Map<Int, Int>, unmappedConstantsToRemove: Map<String, Int>, unmappedConstantsToAdd: Map<String, Int>, listsToRemove: Map<String, ValidationList>, listsToAdd: Map<String, ValidationList>) { /*@DONE PokemonModel.MassUpdateFromDelta/1 cs:1553-1647*/
        for ((key, _) in listsToRemove) lists.remove(key)
        for ((key, value) in listsToAdd) {
            val newList = ValidationList(value.storedHash)
            newList.addAll(value)
            lists[key] = newList
        }

        for ((address, name) in namesToRemove) {
            addressForAnchor.remove(name)
            anchorForAddress.remove(address)
        }

        for ((address, name) in namesToAdd) {
            addressForAnchor[name] = address
            anchorForAddress[address] = name
        }

        for ((address, name) in unmappedPointersToRemove) {
            val current = unmappedNameToSources[name]
            if (current != null) {
                val updated = current.remove1(address)
                if (updated.size == 0) unmappedNameToSources.remove(name) else unmappedNameToSources[name] = updated
            }
            sourceToUnmappedName.remove(address)
        }

        for ((address, name) in unmappedPointersToAdd) {
            val current = unmappedNameToSources[name] ?: SortedSpan.none<Int>()
            unmappedNameToSources[name] = current.add1(address)
            sourceToUnmappedName[address] = name
        }

        for ((address, name) in matchedWordsToRemove) {
            val set = matchedWords[name]
            if (set != null) {
                set.remove(address)
                if (set.size == 0) matchedWords.remove(name)
            }
        }

        for ((address, name) in matchedWordsToAdd) {
            var set = matchedWords[name]
            if (set == null) {
                set = LinkedHashSet()
                matchedWords[name] = set
            }
            set.add(address)
        }

        for ((key, _) in offsetPointersToRemove) pointerOffsets.remove(key)

        for ((key, value) in offsetPointersToAdd) pointerOffsets[key] = value

        for ((key, _) in unmappedConstantsToRemove) unmappedConstants.remove(key)

        for ((key, value) in unmappedConstantsToAdd) unmappedConstants[key] = value

        synchronized(threadlock) {
            for ((key, _) in runsToRemove) {
                val index = binarySearch(key)
                if (index >= 0) runs.removeAt(index)
            }

            for ((key, value) in runsToAdd) {
                var index = binarySearch(key)
                if (index >= 0) {
                    setIndex(index, value)
                } else {
                    index = index.inv()
                    if (index < runs.size) {
                        insertIndex(index, value)
                    } else {
                        runs.add(value)
                    }
                }
            }
        }
    }
    override fun getScriptLength(run: IScriptStartRun, destinationLengths: MutableMap<Int, Int>): Int { /*@DONE PokemonModel.GetScriptLength/1 cs:1649-1657*/
        val gameHash = this.getShortGameCode()
        var lines: List<IScriptLine>? = null
        val s = singletons
        if (s != null) {
            if (run is XSERun) lines = s.scriptLines
            if (run is BSERun) lines = s.battleScriptLines
            if (run is ASERun) lines = s.animationScriptLines
            if (run is TSERun) lines = s.battleAIScriptLines
        }
        if (lines == null) return 1
        return Math.max(1, lines.getScriptSegmentLength(gameHash, this, run.start, destinationLengths))
    }
    override fun <T : IFormattedRun> relocateForExpansion(changeToken: ModelDelta, run: T, minimumLength: Int): T { /*@DONE PokemonModel.RelocateForExpansion/1 cs:1659-1676*/
        var currentLength = run.length
        if (run is IScriptStartRun) {
            currentLength = getScriptLength(run, LinkedHashMap<Int, Int>())
        }
        if (minimumLength <= currentLength) return run
        if (canSafelyUse(run.start + currentLength, run.start + minimumLength)) return run

        val freeSpace = findFreeSpace(0x100, minimumLength)
        synchronized(threadlock) {
            if (freeSpace >= 0) {
                return moveRun(changeToken, run, currentLength, freeSpace)
            } else {
                expandData(changeToken, rawData.size + minimumLength)
                return moveRun(changeToken, run, currentLength, rawData.size - minimumLength - 1)
            }
        }
    }
    override fun <T : IFormattedRun> relocateForExpansion(token: ModelDelta, run: T, currentLength: Int, desiredLength: Int): T { /*@DONE PokemonModel.RelocateForExpansion/2 cs:1678-1692*/
        var length = currentLength
        if (length < 1) length = 1
        if (desiredLength <= length) return run
        if (canSafelyUse(run.start + length, run.start + desiredLength)) return run

        val freeSpace = findFreeSpace(0x100, desiredLength)
        synchronized(threadlock) {
            if (freeSpace >= 0) {
                return moveRun(token, run, length, freeSpace)
            } else {
                expandData(token, rawData.size + desiredLength)
                return moveRun(token, run, length, rawData.size - desiredLength - 1)
            }
        }
    }
    override fun findFreeSpace(start: Int, minimumLength: Int): Int { /*@DONE PokemonModel.FindFreeSpace/1 cs:1694-1734*/
        var from = start
        if (freeSpaceStart != 0) from = freeSpaceStart
        if (from < earliestAllowedAnchor) from = earliestAllowedAnchor
        val wantedLength = minimumLength + 0x40 // make sure there's plenty of room after, so that we're not in the middle of some other data set
        var alignment = Math.max(4, freeSpaceBuffer)
        while (alignment % 4 != 0) alignment++
        synchronized(threadlock) {
            while (from < rawData.size - wantedLength) {
                // catch the currentRun up to where we are
                val currentRun = getNextRun(from)
                if (currentRun.start <= from + wantedLength) {
                    from = currentRun.start + currentRun.length + freeSpaceBuffer
                    val modulo = from % alignment
                    if (modulo != 0) from += alignment - modulo
                    continue
                }

                // if the space we want already has some data in it that we don't have a run for, skip it
                var lastConflictingData = -1
                var i = from + wantedLength - 1
                while (i >= from) {
                    if ((rawData[i].toInt() and 0xFF) != 0xFF) {
                        lastConflictingData = i
                        break
                    }
                    i--
                }
                if (lastConflictingData != -1) {
                    from = lastConflictingData + Math.max(4, freeSpaceBuffer)
                    val modulo = from % alignment
                    if (modulo != 0) from += alignment - modulo
                    continue
                }

                // found a good spot!
                // move the run
                freeSpaceStart = from
                return from
            }
        }

        return -1
    }
    override fun clearAnchor(changeToken: ModelDelta, start: Int, length: Int) { /*@DONE PokemonModel.ClearAnchor/1 cs:1736-1740*/
        synchronized(threadlock) {
            clearFormat(changeToken, start, length, false, false)
        }
    }
    override fun clearFormat(changeToken: ModelDelta, originalStart: Int, length: Int) { /*@DONE PokemonModel.ClearFormat/1 cs:1742-1747*/
        synchronized(threadlock) {
            val run = getNextRun(originalStart)
            clearFormat(changeToken, originalStart, length, run.start == originalStart, false)
        }
    }
    private fun clearFormatAndAnchors(changeToken: ModelDelta, originalStart: Int, length: Int) { /*@DONE PokemonModel.ClearFormatAndAnchors/1 cs:1749-1753*/
        synchronized(threadlock) {
            clearFormat(changeToken, originalStart, length, false, false)
        }
    }
    override fun clearData(changeToken: ModelDelta, start: Int, length: Int) { /*@DONE PokemonModel.ClearData/1 cs:1755-1765*/
        synchronized(threadlock) {
            val run = getNextRun(start)
            if (run.start <= start && run is IAppendToBuilderRun) {
                run.clear(this, changeToken, start, length)
            } else {
                super.clearData(changeToken, start, length)
            }
        }
    }
    override fun clearFormatAndData(changeToken: ModelDelta, originalStart: Int, length: Int) { /*@DONE PokemonModel.ClearFormatAndData/1 cs:1767-1771*/
        synchronized(threadlock) {
            clearFormat(changeToken, originalStart, length, false, true)
        }
    }
    override fun setList(changeToken: ModelDelta, name: String, list: Iterable<String>?, comments: Map<Int, String>?, hash: String) { /*@DONE PokemonModel.SetList/1 cs:1773-1780*/
        val oldContent: ValidationList? = if (lists.containsKey(name)) lists[name] else null
        if (list == null && lists.containsKey(name)) {
            lists.remove(name)
        } else {
            lists[name] = ValidationList(hash, list ?: emptyList(), comments)
        }
        changeToken.changeList(name, oldContent, ValidationList(hash, list ?: emptyList(), LinkedHashMap<Int, String>()))
    }
    override fun tryGetList(name: String, list: Ref<ValidationList?>): Boolean { /*@DONE PokemonModel.TryGetList/1 cs:1782-1784*/
        return lists.tryGetValueCaseInsensitive(name, list)
    }
    override fun considerResultsAsTextRuns(futureChange: () -> ModelDelta, searchResults: List<Int>): Int { /*@DONE PokemonModel.ConsiderResultsAsTextRuns/1 cs:1787-1800*/
        var resultsRecognizedAsTextRuns = 0
        synchronized(threadlock) {
            for (result in searchResults) {
                val run = considerAsTextStream(result, futureChange)
                if (run != null) {
                    clearFormat(futureChange(), run.start, run.length)
                    observeAnchorWritten(futureChange(), "", run)
                    resultsRecognizedAsTextRuns++
                }
            }
        }
        return resultsRecognizedAsTextRuns
    }
    fun considerAsTextStream(address: Int, futureCurrentChange: () -> ModelDelta): PCSRun? { /*@DONE PokemonModel.ConsiderAsTextStream/1 cs:1816-1833*/
        synchronized(threadlock) {
            val model = this
            var nextRun = model.getNextRun(address)
            if (nextRun.start < address) return null
            if (nextRun.start == address && nextRun !is NoInfoRun) return null
            val length = PCSString.readString(model, address, true)
            if (length < 1) return null
            while ((nextRun.start < address + length && nextRun.start != address && nextRun is NoInfoRun) || nextRun is PCSRun) {
                nextRun = getNextRun(nextRun.start + nextRun.length)
            }
            if (address + length > nextRun.start && nextRun.start != address) return null
            clearPointerCache()
            val pointers = searchForPointersToAnchor(futureCurrentChange(), true, address) // this is slow and change the metadata. Only do it if we're sure we want the new PCSRun
            if (pointers.size == 0) return null
            return PCSRun(model, address, length, pointers)
        }
    }
    override fun clearPointer(currentChange: ModelDelta, source: Int, destination: Int) { /*@DONE PokemonModel.ClearPointer/1 cs:1838-1878*/
        synchronized(threadlock) {
            var index = binarySearch(destination)
            if (index < 0) {
                index = index.inv() - 1
                // nothing to remove at the destination, unless this is an inner-anchor for a table that supports pointers
                if (index <= 0) return
                val candidate = runs[index]
                if (candidate !is ArrayRun || !candidate.supportsInnerPointers) return
                val newArray = candidate.removeInnerSource(source)
                currentChange.removeRun(candidate)
                currentChange.addRun(newArray)
                setIndex(index, newArray)
                return
            }

            currentChange.removeRun(runs[index])

            val newRun = runs[index].removeSource(source)
            val newSourceCount = newRun.pointerSources?.size ?: 0
            if (newRun is NoInfoRun && newSourceCount == 0) {
                // run carries no info, just remove it
                removeIndex(index)
            } else if (newRun is PointerRun && newSourceCount == 0) {
                // run carries no pointer info: remove the anchor
                setIndex(index, PointerRun(newRun.start))
                if (newRun is OffsetPointerRun) setIndex(index, OffsetPointerRun(newRun.start, newRun.offset))
                currentChange.addRun(runs[index])
            } else if (newRun is TrainerPokemonTeamRun && newSourceCount == 0) {
                // trainer pokemon teams get their length from their parent.
                // if there is no parent, then there's no concept of length.
                // just remove it
                removeIndex(index)
            } else if (newRun is IScriptStartRun && newSourceCount == 0 && !anchorForAddress.containsKey(newRun.start)) {
                // script start run, but with nothing points to it and it's unnamed.
                // just remove it
                removeIndex(index)
            } else {
                setIndex(index, newRun)
                currentChange.addRun(newRun)
            }
        }
    }
    private fun clearFormat(changeToken: ModelDelta, start: Int, length: Int, keepInitialAnchorPointers: Boolean, alsoClearData: Boolean) { /*@DONE PokemonModel.ClearFormat/2 cs:1880-1935*/
        var from = start
        var remaining = length
        var keepInitial = keepInitialAnchorPointers
        while (remaining > 0) {
            val run = getNextRun(from)

            if (alsoClearData && from < run.start) {
                var i = 0
                while (i < remaining && i < run.start - from) {
                    if (from + i < count) {
                        changeToken.changeData(this, from + i, 0xFF)
                    }
                    i++
                }
            }

            if (run.start >= from + remaining) return
            if (run is PointerRun) clearPointerFormat(null, null, 0, changeToken, run.start)
            if (run is ITableRun) modifyAnchorsFromPointerArray(changeToken, run, null, run.elementCount) { seg, segs, parentIndex, token, begin -> clearPointerFormat(seg, segs, parentIndex, token, begin) }
            if (run is WordRun) {
                changeToken.removeMatchedWord(run.start, run.sourceArrayName)
                matchedWords[run.sourceArrayName]?.remove(run.start)
            } else if (run is OffsetPointerRun) {
                changeToken.removeOffsetPointer(run.start, run.offset)
                pointerOffsets.remove(run.start)
            }

            if (getNextRun(run.start).start == run.start) {
                val runSources = run.pointerSources
                if (!alsoClearData && run.start < from && runSources != null && runSources.size > 0) {
                    // we want to keep the pointers
                    val simpleRun = NoInfoRun(run.start, runSources)
                    var index = binarySearch(run.start)
                    changeToken.removeRun(run)
                    setIndex(index, simpleRun)
                    changeToken.addRun(simpleRun)
                    // but we don't want to keep the inner-pointers
                    if (run is ArrayRun && run.supportsInnerPointers) {
                        val inner = run.pointerSourcesForInnerElements
                        if (inner != null) {
                            for (i in 1 until inner.size) {
                                for (source in inner[i]) {
                                    index = binarySearch(source)
                                    if (index >= 0 && runs[index] is PointerRun) {
                                        changeToken.removeRun(runs[index])
                                        removeIndex(index)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    clearAnchorFormat(changeToken, keepInitial, run)
                }
            }

            if (alsoClearData) {
                for (i in 0 until run.length) changeToken.changeData(this, run.start + i, 0xFF)
            }

            val previousFrom = from
            remaining -= run.length + run.start - from
            from = run.start + run.length
            keepInitial = false
            if (from <= previousFrom) return // a zero-length run cannot make progress
        }
    }
    private fun clearAnchorFormat(changeToken: ModelDelta, keepPointers: Boolean, run: IFormattedRun) { /*@DONE PokemonModel.ClearAnchorFormat/1 cs:1937-2027*/
        var runIndex: Int

        // case 1: anchor is named
        // delete the anchor.
        val name = anchorForAddress[run.start]
        if (name != null) {
            val runSources = run.pointerSources ?: SortedSpan.none<Int>()
            if (changeToken !is NoDataChangeDeltaModel) {
                // Clear pointers to it, but keep the names. They're pointers, just not to here anymore.
                for (source in runSources) {
                    writeValue(changeToken, source, 0)
                    changeToken.addUnmappedPointer(source, name)
                    sourceToUnmappedName[source] = name
                }
                unmappedNameToSources[name] = runSources
                if (run is ArrayRun && run.supportsInnerPointers) {
                    val inner = run.pointerSourcesForInnerElements
                    if (inner != null) {
                        for (i in 0 until inner.size) {
                            for (source in inner[i]) {
                                writeValue(changeToken, source, i)
                                changeToken.addUnmappedPointer(source, name)
                                sourceToUnmappedName[source] = name
                            }
                            unmappedNameToSources[name] = unmappedNameToSources[name]!!.add(inner[i])
                        }
                    }
                }
            } else if (!keepPointers) {
                // Clear pointer formats to it. They're not actually pointers.
                for (source in runSources) {
                    if (source > run.start && source < run.start + run.length) continue
                    clearPointerFormat(changeToken, source)
                }
                if (run is ArrayRun && run.supportsInnerPointers) {
                    val inner = run.pointerSourcesForInnerElements
                    if (inner != null) {
                        for (sources in inner) {
                            for (source in sources) {
                                if (source > run.start && source < run.start + run.length) continue
                                clearPointerFormat(changeToken, source)
                            }
                        }
                    }
                }
            }
            changeToken.removeName(run.start, name)
            addressForAnchor.remove(name)
            anchorForAddress.remove(run.start)
            runIndex = binarySearch(run.start)
            changeToken.removeRun(run)
            if (runIndex >= 0) runs.removeAt(runIndex)
            if (keepPointers && run is ArrayRun && run.supportsInnerPointers) addAnchorsForRemovedArray(run, changeToken)
            return
        }

        // case 2: unnamed anchor is not really an anchor, so don't keep the pointers
        // this anchor shouldn't exist. The things that point to it aren't real pointers.
        if (!keepPointers) {
            // by removing the unnamed anchor here, we're claiming that these were never really pointers to begin with.
            // as such, we should not change their data, just remove their pointer format
            for (source in run.pointerSources ?: SortedSpan.none<Int>()) {
                val sourceRunIndex = binarySearch(source)
                if (sourceRunIndex >= 0 && runs[sourceRunIndex] is PointerRun) {
                    val pointerRun = runs[sourceRunIndex]
                    changeToken.removeRun(pointerRun)
                    val pointerRunSources = pointerRun.pointerSources
                    if (pointerRunSources == null) {
                        runs.removeAt(sourceRunIndex)
                    } else {
                        // remove the pointer, but keep any anchors to that location.
                        val newRun = NoInfoRun(pointerRun.start, pointerRunSources)
                        changeToken.addRun(newRun)
                        runs[sourceRunIndex] = newRun
                    }
                } else {
                    // this source is in a table: the source is in error, but we have to leave it anyway.
                }
            }
            runIndex = binarySearch(run.start)
            changeToken.removeRun(run)
            if (runIndex >= 0) runs.removeAt(runIndex) // if the run was a pointer, it may've already been removed in the previous step
            return
        }

        // case 3: unnamed anchor is a constant and we've been asked not to touch constants
        if (run is WordRun && changeToken.doNotClearConstants) return

        // case 4: unnamed anchor and we want to keep the pointers
        // delete the content, but leave the anchor and pointers to it: we don't want to lose track of the pointers that point here.
        runIndex = binarySearch(run.start)
        changeToken.removeRun(run)
        if (runIndex >= 0) {
            val keptSources = run.pointerSources
            if (keptSources != null) {
                runs[runIndex] = NoInfoRun(run.start, keptSources)
                changeToken.addRun(runs[runIndex])
            } else {
                runs.removeAt(runIndex)
            }
        }
    }
    private fun addAnchorsForRemovedArray(table: ArrayRun, token: ModelDelta) { /*@DONE PokemonModel.AddAnchorsForRemovedArray/1 cs:2029-2036*/
        val inner = table.pointerSourcesForInnerElements ?: return
        for (i in 1 until table.elementCount) {
            if (i >= inner.size) break
            val sources = inner[i]
            if (sources.size == 0) continue
            val destination = table.start + table.elementLength * i
            observeRunWritten(token, NoInfoRun(destination, sources))
        }
    }
    private fun clearPointerFormat(changeToken: ModelDelta?, source: Int) { /*@DONE PokemonModel.ClearPointerFormat/1 cs:2038-2041*/
        if (changeToken == null) return
        val run = getNextRun(source)
        if (run is PointerRun && run.start == source) clearFormat(changeToken, source, 4)
    }
    private fun clearPointerFormat(segment: ArrayRunElementSegment?, segments: List<ArrayRunElementSegment>?, parentIndex: Int, changeToken: ModelDelta, start: Int) { /*@DONE PokemonModel.ClearPointerFormat/2 cs:2043-2065*/
        if (start < 0 || start > count - 3) return // no need to clear the format, this location isn't valid
        // remove the reference from the anchor we're pointing to as well
        val destination = readPointer(start)
        if (destination >= 0 && destination < count) {
            val index = binarySearch(destination)
            if (index >= 0) {
                clearPointerFromAnchor(changeToken, start, index)
            } else if (index != -1) { // if index is -1, we are before the first run, so we're not within an array run
                val candidate = runs[index.inv() - 1]
                if (candidate is ArrayRun) {
                    clearPointerWithinArray(changeToken, start, candidate, index.inv() - 1)
                }
                // else: pointers in tables are allowed to point at junk
            }
        } else {
            val name = sourceToUnmappedName[start]
            if (name != null) {
                changeToken.removeUnmappedPointer(start, name)
                sourceToUnmappedName.remove(start)
                val current = unmappedNameToSources[name]
                if (current != null) {
                    if (current.size == 1) {
                        unmappedNameToSources.remove(name)
                    } else {
                        unmappedNameToSources[name] = current.remove1(start)
                    }
                }
            }
        }
    }
    private fun clearPointerFromAnchor(changeToken: ModelDelta, start: Int, index: RunPath) { /*@DONE PokemonModel.ClearPointerFromAnchor/1 cs:2067-2090*/
        val anchorRun = runs[index]
        val newAnchorRun = anchorRun.removeSource(start)
        val newSourceCount = newAnchorRun.pointerSources?.size ?: 0

        // the only run that is allowed to exist with nothing pointing to it and no name is a pointer run.
        // if it's any other kind of run with no name and no pointers to it, remove it.
        if (newSourceCount == 0 && !anchorForAddress.containsKey(newAnchorRun.start) && newAnchorRun !is PointerRun && changeToken !is TransientModelDelta) {
            if (anchorRun.start <= start && anchorRun.start + anchorRun.length > start) {
                // calling ClearFormat would try to clear the element we're already removing
                // no need to do that: This element should get removed higher up the callstack.
                changeToken.removeRun(anchorRun)
            } else {
                clearFormat(changeToken, anchorRun.start, anchorRun.length, false, false)
            }
        } else if (newSourceCount == 0 && !anchorForAddress.containsKey(newAnchorRun.start) && newAnchorRun is PointerRun) {
            // if it IS a pointer run, we still need to remove the anchor by setting the pointerSources to null.
            changeToken.removeRun(anchorRun)
            setIndex(index, PointerRun(newAnchorRun.start))
        } else {
            changeToken.removeRun(anchorRun)
            setIndex(index, newAnchorRun)
            changeToken.addRun(newAnchorRun)
        }
    }
    private fun clearPointerWithinArray(changeToken: ModelDelta, start: Int, array: ArrayRun, index: RunPath) { /*@DONE PokemonModel.ClearPointerWithinArray/1 cs:2092-2097*/
        changeToken.removeRun(array)
        val newArray = array.removeSource(start)
        setIndex(index, newArray)
        changeToken.addRun(newArray)
    }
    override fun updateArrayPointer(changeToken: ModelDelta, segment: ArrayRunElementSegment?, segments: List<ArrayRunElementSegment>?, parentIndex: Int, source: Int, destination: Int, writeDestinationFormat: Boolean) { /*@DONE PokemonModel.UpdateArrayPointer/1 cs:2099-2105*/
        synchronized(threadlock) {
            clearPointerFormat(segment, null, 0, changeToken, source)
            if (readPointer(source) != destination) writePointer(changeToken, source, destination)
            addPointerToAnchor(segment, segments, parentIndex, changeToken, source, writeDestinationFormat)
        }
    }
    override fun copy(changeToken: () -> ModelDelta, start: Int, length: Int, deep: Boolean): String { /*@DONE PokemonModel.Copy/1 cs:2107-2192*/
        val text = StringBuilder()
        var from = start
        var remaining = length

        synchronized(threadlock) {
            while (remaining > 0) {
                val run = getNextRun(from)
                if (run.start > from) {
                    val len = Math.min(remaining, run.start - from)
                    val bytes = ArrayList<String>()
                    for (i in from until from + len) bytes.add((rawData[i].toInt() and 0xFF).toHexString())
                    text.append(bytes.joinToString(" ") + " ")
                    remaining -= len
                    from += len
                    continue
                }
                if (run.start == from && run.length <= remaining) {
                    if (run is LZRun) {
                        // the user is copying an lzrun. Make sure to include a metacommand to insert a new lzrun during the paste.
                        text.append("@!lz(" + run.decompressedLength + ") ")
                    } else if (run is ITableRun) {
                        // the user is copying a table run. Make sure to include a metacommand to insert 00 of the appropriate length during the paste.
                        // this makes sure that we have enough freespace and makes deep copy for pointers work correctly.
                        text.append("@!00(" + run.length + ") ")
                        if (run is TableStreamRun) {
                            var defaultStream = StringBuilder()
                            val defaultBytes = run.createDefault()
                    for (bi in 0 until defaultBytes.count) defaultStream.append(defaultBytes[bi].toHexString())
                            var defaultText = defaultStream.toString()
                            if (defaultText.length > 0) {
                                defaultText = "0".repeat(2 * run.elementLength) + defaultText
                                text.append("@!put(" + defaultText + ") ")
                            }
                        }
                    }
                    var anchor = anchorForAddress[from]
                    if (anchor == null) {
                        if ((run.pointerSources?.size ?: 0) > 0) {
                            anchor = generateDefaultAnchorName(run)
                            val token = changeToken()
                            observeAnchorWritten(token, anchor, run)
                            text.append("^" + anchor + run.formatString + " ")
                        }
                    } else {
                        text.append("^" + anchor + run.formatString + " ")
                    }
                }
                if (run is PointerRun) {
                    val destination = readPointer(run.start)
                    var anchorName = getAnchorFromAddress(run.start, destination)
                    if (anchorName.isEmpty()) anchorName = destination.toHex(6)
                    var offset = ""
                    if (run is OffsetPointerRun) {
                        if (run.offset > 0) offset = "+" + run.offset.toHex(6)
                        if (run.offset < 0) offset = "-" + (-run.offset).toHex(6)
                    }
                    val child = getNextRun(destination)
                    if (deep && child is IAppendToBuilderRun) {
                        text.append("@{ ")
                        child.appendTo(this, text, destination, child.length, if (deep) 10 else 0)
                        text.append("@} ")
                    } else {
                        text.append("<" + anchorName + offset + "> ")
                    }
                    from += 4
                    remaining -= 4
                } else if (run is NoInfoRun || run is IScriptStartRun) {
                    text.append((rawData[run.start].toInt() and 0xFF).toHexString() + " ")
                    from += 1
                    remaining -= 1
                } else if (run is IAppendToBuilderRun) {
                    run.appendTo(this, text, from, remaining, if (deep) 10 else 0)
                    text.append(" ")
                    remaining -= run.start + run.length - from
                    from = run.start + run.length
                } else if (run is AsciiRun) {
                    val textLength = Math.min(run.length, remaining)
                    for (i in 0 until textLength) {
                        text.append((rawData[from + i].toInt() and 0xFF).toChar())
                    }
                    from += textLength
                    remaining -= textLength
                    text.append(" ")
                } else {
                    throw NotImplementedError()
                }
            }
        }

        if (text.length > 0) text.setLength(text.length - 1) // remove the trailing space
        return text.toString()
    }
    private fun generateDefaultAnchorName(run: IFormattedRun): String { /*@DONE PokemonModel.GenerateDefaultAnchorName/1 cs:2194-2207*/
        val gameCodeText = readGameCode(this)
        val textSample = getSampleText(run)
        val initialAddress = run.start.toHex(6)

        val defaultName = "misc.temp." + gameCodeText + "_" + initialAddress + textSample
        if (!addressForAnchor.containsKey(defaultName)) return defaultName

        var counter = 0
        while (true) {
            counter++
            if (!addressForAnchor.containsKey(defaultName + "_" + counter)) return defaultName + "_" + counter
        }
    }
    private fun getSampleText(run: IFormattedRun): String { /*@DONE PokemonModel.GetSampleText/1 cs:2222-2229*/
        if (run !is PCSRun) return ""
        var text = textConverter.convert(this, run.start, run.length) ?: ""
        var words = text.split(" ")
        if (words.size > 3) words = words.take(3).toTypedArray()
        text = words.joinToString("")
        return "." + text.filter { c -> c.isLetterOrDigit() }
    }
    override fun load(newData: ByteArray, metadata: StoredMetadata?) { /*@DONE PokemonModel.Load/1 cs:2231-2249*/
        super.load(newData, metadata)
        synchronized(threadlock) {
            unmappedNameToSources.clear()
            sourceToUnmappedName.clear()
            addressForAnchor.clear()
            anchorForAddress.clear()
            runs.clear()
            lists.clear()
            pointerOffsets.clear()
            unmappedConstants.clear()
            tableGroups.clear()
            matchedWords.clear()
        }
        initializationWorkload = (singletons?.workDispatcher ?: InstantDispatch.instance).runBackgroundWork {
            buildDestinationToSourceCache(newData)
            initialize(metadata)
        }
    }
    override fun getAutoCompleteAnchorNameOptions(partial: String, maxResults: Int): Iterable<String>? { /*@DONE PokemonModel.GetAutoCompleteAnchorNameOptions/1 cs:2251-2286*/
        val results = ArrayList<String>()
        synchronized(threadlock) {
            val lowered = partial.lowercase()
            val mappedNames = ArrayList<String>(addressForAnchor.keys)

            var resultsCount = 0

            if (!lowered.contains(ArrayRun.arrayAnchorSeparator)) {
                for (index in lowered.findMatches(mappedNames)) {
                    results.add(mappedNames[index])
                    resultsCount += 1
                    if (resultsCount == maxResults) break
                }
                return results
            }

            val nameParts = lowered.split(ArrayRun.arrayAnchorSeparator.toString())
            val seekBits = nameParts[0].bitLetters()

            for (name in mappedNames) {
                val address = addressForAnchor[name]
                val run = getNextRun(address)
                if (run is ArrayRun) {
                    val sanitizedName = name.replace("\u00e9", "e")
                    val includedBits = sanitizedName.bitLetters()
                    if ((seekBits and includedBits.inv()) != 0u) continue
                    if (!sanitizedName.matchesPartialWithReordering(nameParts[0])) continue
                    for (option in getAutoCompleteOptions(name + ArrayRun.arrayAnchorSeparator, run, nameParts.drop(1).toTypedArray())) {
                        results.add(option)
                        resultsCount += 1
                        if (resultsCount >= maxResults) return results
                    }
                }
            }
        }
        return results
    }
    override fun getAutoCompleteByteNameOptions(text: String): Iterable<String>? { /*@DONE PokemonModel.GetAutoCompleteByteNameOptions/1 cs:2288-2298*/
        val results = ArrayList<String>()
        val seekBits = text.bitLetters()
        val matchedWordsCopy = ArrayList<String>(matchedWords.keys)
        for (key in matchedWordsCopy) {
            val includedBits = key.bitLetters()
            if ((seekBits and includedBits.inv()) != 0u) continue
            if (key.matchesPartialWithReordering(text)) {
                results.add(key)
            }
        }
        return results
    }
    private fun getAutoCompleteOptions(prefix: String, run: ITableRun, parts: Array<String>): Iterable<String> { /*@DONE PokemonModel.GetAutoCompleteOptions/1 cs:2311-2350*/
        val results = ArrayList<String>()
        val childNames = run.elementNames
        for (i in 0 until run.elementCount) {
            val options = ArrayList<String>()
            options.add(i.toString())
            if (childNames != null && childNames.size > i && childNames[i].isNotEmpty()) options.add(childNames[i])
            for (option in options) {
                if (!option.matchesPartial(parts[0])) continue
                if (parts.size == 1) {
                    results.add(prefix + option)
                    continue
                }
                // looking for a field name
                var segmentOffset = 0
                for (segment in run.elementContent) {
                    if (!segment.name.matchesPartial(parts[1])) {
                        segmentOffset += segment.length
                        continue
                    }
                    if (parts.size == 2) {
                        results.add(prefix + option + ArrayRun.arrayAnchorSeparator + segment.name)
                    } else {
                        val childRunStart = readPointer(run.start + run.elementLength * i + segmentOffset)
                        if (segment.type != ElementContentType.Pointer) {
                            segmentOffset += segment.length
                            continue // oops, can't follow into a non-pointer segment
                        }
                        val childRun = getNextRun(childRunStart)
                        if (parts[2] == "") {
                            results.add(prefix + option + ArrayRun.arrayAnchorSeparator + segment.name + ArrayRun.arrayAnchorSeparator)
                        } else if (childRun is ITableRun) {
                            results.addAll(getAutoCompleteOptions(prefix + option + ArrayRun.arrayAnchorSeparator + segment.name + ArrayRun.arrayAnchorSeparator, childRun, parts.drop(2).toTypedArray()))
                        }
                    }
                    segmentOffset += segment.length
                }
            }
        }
        return results
    }
    override fun exportMetadata(references: GameReferenceTables?, metadataInfo: IMetadataInfo): StoredMetadata? { /*@DONE PokemonModel.ExportMetadata/1 cs:2352-2414*/
        val anchors = ArrayList<StoredAnchor>()
        synchronized(threadlock) {
            for (kvp in ArrayList(anchorForAddress.entries)) {
                val address = kvp.key
                val name = kvp.value
                if (name.startsWith("misc.temp.")) continue // don't persist miscilaneous temp anchors
                val index = binarySearch(address)
                if (index < 0) continue
                val format = runs[index].formatString

                // We want to know the hash from the reference table,
                // because we only want to update the table if the hash matches the format
                val refTable = if (references == null) null else references[name]
                val hash = if (refTable != null) StoredList.generateHash(listOf(refTable.format)) else StoredList.generateHash(listOf(format))
                anchors.add(StoredAnchor(address, name, format, hash))
            }
        }

        val unmappedPointers = ArrayList<StoredUnmappedPointer>()
        for ((address, name) in sourceToUnmappedName) {
            unmappedPointers.add(StoredUnmappedPointer(address, name))
        }

        val exportedWords = ArrayList<StoredMatchedWord>()
        for ((name, addresses) in matchedWords) {
            for (address in addresses) {
                val run = getNextRun(address) as? WordRun
                exportedWords.add(StoredMatchedWord(address, name, run?.length ?: 4, run?.valueOffset ?: 0, run?.multOffset ?: 1, run?.note))
            }
        }

        val offsetPointers = ArrayList<StoredOffsetPointer>()
        for ((address, offset) in pointerOffsets) offsetPointers.add(StoredOffsetPointer(address, offset))

        val exportedLists = ArrayList<StoredList>()
        for (kvp in lists) {
            val name = kvp.key
            val value = kvp.value
            val members = ArrayList<String?>()
            for (i in 0 until value.size) {
                val memberText = value[i]
                members.add(if (i.toString() == memberText) null else memberText)
            }
            exportedLists.add(StoredList(name, members, value.comments, value.storedHash))
        }

        val exportedConstants = ArrayList<StoredUnmappedConstant>()
        for ((name, value) in unmappedConstants) {
            exportedConstants.add(StoredUnmappedConstant(name, value))
        }

        val exportedShortcuts = ArrayList<StoredGotoShortcut>()
        for (shortcut in this.gotoShortcuts) {
            exportedShortcuts.add(StoredGotoShortcut(shortcut.displayText, shortcut.imageAnchor, shortcut.gotoAnchor))
        }

        val fields = StoredMetadataFields()
        fields.freeSpaceSearch = freeSpaceStart
        fields.freeSpaceBuffer = freeSpaceBuffer
        fields.nextExportID = nextExportID
        fields.showRawIVByteForTrainer = showRawIVByteForTrainer
        return StoredMetadata(anchors, unmappedPointers, exportedWords, offsetPointers, exportedLists, exportedConstants, exportedShortcuts, ArrayList(tableGroups), metadataInfo, fields)
    }
    override fun searchForPointersToAnchor(changeToken: ModelDelta, ignoreNoInfoPointers: Boolean, vararg addresses: Int): SortedSpan<Int> { /*@DONE PokemonModel.SearchForPointersToAnchor/1 cs:2419-2462*/
        synchronized(threadlock) {
            if (sourcesForDestinations != null) return spanFromCache(changeToken, *addresses)
        }

        var results = SortedSpan.none<Int>()
        val runsToAdd = ArrayList<PointerRun>()

        synchronized(threadlock) { // we need to know that `runs` won't be modified during TryMakePointerAtAddress
            val data = rawData
            var i = 3
            while (i < data.size) {
                val last = data[i].toInt() and 0xFF
                if (last != 0x08 && last != 0x09) {
                    i++
                    continue
                }
                val destination = readPointer(i - 3)
                if (!addresses.contains(destination)) {
                    i++
                    continue
                }
                val newRunRef = Ref<PointerRun?>(null)
                if (tryMakePointerAtAddress(changeToken, i - 3, ignoreNoInfoPointers, newRunRef)) {
                    results = results.add1(i - 3)
                    val newRun = newRunRef.value
                    if (newRun != null) runsToAdd.add(newRun)
                }
                i++
            }
        }

        synchronized(threadlock) {
            for (newRun in runsToAdd) {
                if (ignoreNoInfoPointers) {
                    clearFormat(changeToken, newRun.start, newRun.length)
                    observeRunWritten(changeToken, newRun)
                } else {
                    val found = binarySearch(newRun.start)
                    if (found >= 0) {
                        changeToken.removeRun(runs[found])
                        runs[found] = newRun
                    } else {
                        runs.add(found.inv(), newRun)
                    }
                    changeToken.addRun(newRun)
                }
            }
        }
        return results
    }
    private fun searchForPointersInTables(changeToken: ModelDelta, address: Int): SortedSpan<Int> { /*@DONE PokemonModel.SearchForPointersInTables/1 cs:2464-2482*/
        if (sourcesForDestinations != null || changeToken is TransientModelDelta) return SortedSpan.none<Int>() // no need to search through tables if we're in a transient or doing initial load
        val results = ArrayList<Int>()
        synchronized(threadlock) {
            val tables = this.all<ITableRun>() ?: emptyList()
            for (run in tables) {
                var offset = 0
                for (seg in run.elementContent) {
                    if (seg.type == ElementContentType.Pointer) {
                        for (i in 0 until run.elementCount) {
                            val source = run.start + i * run.elementLength + offset
                            if (readPointer(source) == address) results.add(source)
                        }
                    }
                    offset += seg.length
                }
            }
        }
        return SortedSpan(results)
    }
    private fun spanFromCache(token: ModelDelta, vararg destinations: Int): SortedSpan<Int> { /*@DONE PokemonModel.SpanFromCache/1 cs:2484-2510*/
        var results = SortedSpan.none<Int>()
        val cache = sourcesForDestinations
        for (destination in destinations) {
            val sources = cache?.get(destination)
            if (sources != null) results = results.add(sources)
        }

        // remove sources that are already in use in other ways
        var i = 0
        while (i < results.size) {
            val newRunRef = Ref<PointerRun?>(null)
            if (!tryMakePointerAtAddress(token, results[i], false, newRunRef)) {
                results = results.remove1(results[i])
                continue
            }
            val newRun = newRunRef.value
            if (newRun != null) {
                // NOTE don't ObserveRunWritten here! That will automatically add not only the Pointer, but also an anchor.
                // Example: Unbound-bt-d1.3.1, it causes a conflict where an anchor is added into the type names while we're adding the pointers.
                var index = binarySearch(newRun.start)
                if (index >= 0) {
                    token.removeRun(runs[index])
                    runs[index] = newRun
                } else {
                    index = index.inv()
                    insertIndex(index, newRun)
                }
                token.addRun(newRun)
            }
            i++
        }

        return results
    }
    private fun tryMakePointerAtAddress(changeToken: ModelDelta, address: Int, ignoreNoInfoPointers: Boolean, runToAdd: Ref<PointerRun?>): Boolean { /*@DONE PokemonModel.TryMakePointerAtAddress/1 cs:2522-2568*/
        // I have to lock this whole block, because I need to know that 'index' remains consistent until I can call runs.Insert
        runToAdd.value = null

        var index = binarySearch(address)
        if (index >= 0) {
            val existing = runs[index]
            if (existing is PointerRun) return true
            if (existing is ArrayRun && existing.elementContent[0].type == ElementContentType.Pointer) return true
            if (existing is NoInfoRun) {
                runToAdd.value = PointerRun(address, existing.pointerSources)
                return true
            }
            return false
        }
        index = index.inv()
        if (ignoreNoInfoPointers) {
            while (index < runs.size && runs[index] is PointerRun && getNextRunUnthreaded(readPointer(runs[index].start)) is NoInfoRun) {
                // this pointer might be a false pointer, we can ignore it for now
                index += 1
            }
        }
        if (index < runs.size && runs[index].start <= address + 3) return false // can't add a pointer run if an existing run starts during the new one

        index -= 1 // looking at the previous run, not the next run
        if (ignoreNoInfoPointers) {
            while (index >= 0 && runs[index] is PointerRun && getNextRunUnthreaded(readPointer(runs[index].start)) is NoInfoRun) {
                // this pointer might be a false pointer, we can ignore it for now
                index -= 1
            }
        }

        // can't add a pointer run if the new one starts during an existing run
        if (index >= 0 && runs[index].start + runs[index].length > address) {
            // ah, but if that run is an array and there's already a pointer here...
            val candidate = runs[index]
            if (candidate is ArrayRun) {
                val offsets = candidate.convertByteOffsetToArrayOffset(address)
                if (offsets.segmentOffset == 0 && candidate.elementContent[offsets.segmentIndex].type == ElementContentType.Pointer) {
                    return true
                }
            }
            return false
        }

        runToAdd.value = PointerRun(address)

        return true
    }
    private fun removeAnchorByName(changeToken: ModelDelta, anchorName: String) { /*@DONE PokemonModel.RemoveAnchorByName/1 cs:2634-2652*/
        val anchorAddress = addressForAnchor[anchorName]
        val index = binarySearch(anchorAddress)
        if (index < 0) {
            // there is a name, but no run at that address: just forget the name
            addressForAnchor.remove(anchorName)
            anchorForAddress.remove(anchorAddress)
            changeToken.removeName(anchorAddress, anchorName)
            return
        }
        val oldAnchor = runs[index]
        changeToken.removeRun(oldAnchor)
        runs.removeAt(index)
        val oldAnchorName = anchorForAddress[oldAnchor.start] ?: anchorName

        val oldSources = oldAnchor.pointerSources ?: SortedSpan.none<Int>()
        for (source in oldSources) {
            writeValue(changeToken, source, 0)
            sourceToUnmappedName[source] = oldAnchorName
            changeToken.addUnmappedPointer(source, oldAnchorName)
        }

        unmappedNameToSources[oldAnchorName] = oldSources
        val nameToRemove = anchorForAddress[oldAnchor.start] ?: anchorName
        addressForAnchor.remove(nameToRemove)
        anchorForAddress.remove(oldAnchor.start)
        changeToken.removeName(oldAnchor.start, nameToRemove)
    }
    private fun getSourcesPointingToNewAnchor(changeToken: ModelDelta, anchorName: String, run: IFormattedRun, seekPointers: Boolean): SortedSpan<Int> { /*@DONE PokemonModel.GetSourcesPointingToNewAnchor/1 cs:2660-2703*/
        val locationRef = Ref(0)
        if (!addressForAnchor.tryGetValue(anchorName, locationRef)) return SortedSpan.none<Int>() // new anchor is unnamed, so nothing points to it yet
        val location = locationRef.value

        val sources = unmappedNameToSources[anchorName]
        if (sources == null) {
            // no pointer was waiting for this anchor to be created
            // but the user thinks there's something pointing here
            if (seekPointers) return searchForPointersToAnchor(changeToken, false, location)
            return SortedSpan.none<Int>()
        }

        var sourcesDirectlyToThis: SortedSpan<Int> = sources
        for (source in sources) {
            changeToken.removeUnmappedPointer(source, anchorName)
            sourceToUnmappedName.remove(source)
            var offset = 0
            if (run is ArrayRun && run.supportsInnerPointers) {
                offset = (readValue(source) * run.elementLength).limitToRange(0, run.length)
                if (offset != 0) sourcesDirectlyToThis = sourcesDirectlyToThis.remove1(source)
            }

            if (changeToken is NoDataChangeDeltaModel) {
                // if we're doing an initial load of the model, we may load a pointer and want to update unmapped pointers to point to that location.
                // this _is_ a data edit, and we're ok with that in this case.
                // example: if the original pointer for the game name was cleared and we re-add it, we want to re-add any pointers to it.
                // note that this change isn't undo-able and isn't tracked for save purposes.
                // this is an edge case, so it's probably ok.
                writePointer(ModelDelta(), source, location + offset)
            } else {
                writePointer(changeToken, source, location + offset)
            }
        }
        unmappedNameToSources.remove(anchorName)

        return sourcesDirectlyToThis
    }
    private fun <T : IFormattedRun> moveRun(changeToken: ModelDelta, run: T, length: Int, newStart: Int): T { /*@DONE PokemonModel.MoveRun/1 cs:2705-2773*/
        var current: T = run
        var logName = current.start.toAddress()
        val existingAnchorName = anchorForAddress[current.start]
        if (existingAnchorName != null) logName = existingAnchorName
        raiseLogMessage("Moving " + current.javaClass.simpleName + " " + logName + " to " + newStart.toAddress())
        // repoint
        val originalSources = current.pointerSources?.toList() ?: emptyList<Int>()
        for (source in originalSources) {
            // special update for pointers to this run that live within this run
            if (current.start < source && source < current.start + current.length) {
                current = current.removeSource(source) as T
                current = current.duplicate(current.start, (current.pointerSources ?: SortedSpan.none<Int>()).add1(source + newStart - current.start)) as T
            }
            writePointer(changeToken, source, newStart)
        }
        val movingRun: IFormattedRun = current
        if (movingRun is ArrayRun && movingRun.supportsInnerPointers) {
            val inner = movingRun.pointerSourcesForInnerElements
            if (inner != null) {
                for (i in 1 until movingRun.elementCount) {
                    for (source in inner[i]) {
                        writePointer(changeToken, source, newStart + i * movingRun.elementLength)
                    }
                }
            }
        }

        // clear pointers / move inner anchors from moved scripts
        if (movingRun is IScriptStartRun) {
            while (true) {
                val nextRun = getNextRun(movingRun.start + 1)
                if (nextRun.start >= movingRun.start + length) break
                if (nextRun is IScriptStartRun) {
                    moveRun(changeToken, nextRun, 1, newStart + nextRun.start - movingRun.start)
                } else {
                    // clear format of any constants/pointers/streams that is considered part of the script
                    clearFormatAndAnchors(changeToken, nextRun.start, nextRun.length)
                }
            }
        }

        // move data
        for (i in 0 until length) {
            changeToken.changeData(this, newStart + i, rawData[current.start + i].toInt() and 0xFF)
            changeToken.changeData(this, current.start + i, 0xFF)
        }

        // move run
        val newRun = current.duplicate(newStart, current.pointerSources) as T
        val newTable = newRun as? ITableRun
        if (newTable != null) {
            updateAnchorsFromArrayMove(changeToken, current as ITableRun, newTable)
        }

        val index = binarySearch(current.start)
        if (index >= 0) {
            changeToken.removeRun(runs[index])
            removeIndex(index)
        }
        val newIndex = binarySearch(newStart)
        insertIndex(newIndex.inv(), newRun)
        changeToken.addRun(newRun)

        // move anchor
        val name = anchorForAddress[current.start]
        if (name != null) {
            addressForAnchor[name] = newRun.start
            anchorForAddress.remove(current.start)
            anchorForAddress[newRun.start] = name
            changeToken.removeName(current.start, name)
            changeToken.addName(newRun.start, name)
        }

        return newRun
    }
    private fun canSafelyUse(rangeStart: Int, rangeEnd: Int): Boolean { /*@DONE PokemonModel.CanSafelyUse/1 cs:2775-2791*/
        // only safe to use if there is no run in that range
        var nextRun = getNextRun(rangeStart)

        // ignore a runs of length zero that begin at the requested rangeStart
        // because space after a run of length zero is obviously safe to use when extending that run.
        // in this case, we actually care about accidentally butting up against the _next_ run.
        if (nextRun.start == rangeStart && nextRun.length == 0) nextRun = getNextRun(rangeStart + 1)

        if (nextRun.start < rangeEnd) return false
        if (rangeEnd >= rawData.size) return false

        // make sure the data is clear
        for (i in rangeStart until rangeEnd) {
            val b = rawData[i].toInt() and 0xFF
            if (b != 0xFF && b != 0x00) return false
        }

        return true
    }
    private val tableGroups: MutableList<TableGroup> = /*@INITDONE PokemonModel.TableGroups cs:2793-2793*/ ArrayList() /*@ENDINIT*/
    override fun appendTableGroup(token: ModelDelta, groupName: String, tableNames: List<String>, hash: String?) { /*@DONE PokemonModel.AppendTableGroup/1 cs:2794-2797*/
        if (tableGroups.any { group -> tableNames.any { table -> group.tables.contains(table) } }) return // don't add it if it contains the same table as one already added
        tableGroups.add(TableGroup(groupName, tableNames, hash))
    }
    override fun getTableGroups(tableName: String): List<TableGroup>? { /*@DONE PokemonModel.GetTableGroups/1 cs:2798-2828*/
        val addressRef = Ref(0)
        val address: Int
        if (!addressForAnchor.tryGetValue(tableName, addressRef)) {
            if (lists.containsKey(tableName)) {
                val firstTable = this.arrays.firstOrNull { array -> array.lengthFromAnchor == tableName } ?: return null
                address = firstTable.start
            } else {
                return null
            }
        } else {
            address = addressRef.value
        }
        val run = getNextRun(address)
        if (run !is ArrayRun || run.start != address) return null
        val related = this.getRelatedArrays(run).distinct().toList()
        val others = ArrayList<String>()
        val groups = ArrayList<TableGroup>()
        for (arrayRun in related) {
            val arrayName = anchorForAddress[arrayRun.start] ?: continue
            val matchingGroups = tableGroups.filter { group -> group.tables.any { table -> table.split(ArrayRunSplitterSegment.separator.toString())[0] == arrayName } }
            for (matchingGroup in matchingGroups) {
                if (groups.contains(matchingGroup)) continue
                groups.add(matchingGroup)
            }
            if (matchingGroups.size == 0) {
                others.add(arrayName)
            }
        }
        if (others.size > 0) {
            others.sort()
            groups.add(TableGroup("Other", others))
        }
        return groups
    }
    companion object {
        private fun withoutLength(format: String): String { /*@DONE PokemonModel.WithoutLength/1 cs:459-463*/
            val index = format.lastIndexOf("]")
            if (index == -1) return format
            return format.substring(0, index + 1)
        }
        fun applyAnchor(model: IDataModel, changeToken: ModelDelta, dataIndex: Int, text: String): ErrorInfo { /*@DONE PokemonModel.ApplyAnchor/1 cs:734-738*/
            val errorInfo = applyAnchor(model, changeToken, dataIndex, text, false)
            (model as? PokemonModel)?.resolveConflicts()
            return errorInfo
        }
        fun applyAnchor(model: IDataModel, changeToken: ModelDelta, dataIndex: Int, text: String, allowAnchorOverwrite: Boolean): ErrorInfo { /*@DONE PokemonModel.ApplyAnchor/2 cs:740-757*/
            val split = splitNameAndFormat(text)
            val originalName = split.first
            val format = split.second

            val runRef = Ref<IFormattedRun?>(null)
            var errorInfo = tryParseFormat(model, originalName, format, dataIndex, runRef)
            if (errorInfo.hasError) return errorInfo
            val runToWrite = runRef.value ?: return errorInfo

            errorInfo = validateAnchorNameAndFormat(model, runToWrite, originalName, format, dataIndex, allowAnchorOverwrite)
            if (!errorInfo.hasError) {
                val nameRef = Ref(originalName)
                errorInfo = uniquifyName(model, dataIndex, nameRef)
                if (runToWrite.containsOnlyPointerToSelf()) {
                    errorInfo = ErrorInfo(nameRef.value + " could not be added at " + dataIndex.toHex(6) + " because no pointers were found.", true)
                } else {
                    model.observeAnchorWritten(changeToken, nameRef.value, runToWrite)
                }
            }

            return errorInfo
        }
        fun uniquifyName(model: IDataModel, desiredAddressForName: Int, name: Ref<String>): ErrorInfo { /*@DONE PokemonModel.UniquifyName/1 cs:759-791*/
            val address = model.getAddressFromAnchor(null, -1, name.value)
            if (address == Pointer.null_ || address == desiredAddressForName) return ErrorInfo.noError

            val info = ErrorInfo("Chosen name was in use. The new anchor has been renamed to avoid collisions.", true)

            // so once we've verified that the new name doesn't match the name from the current address,
            // we'll need to check again for the newly created name.
            // so do some recursion in each of these return cases.

            // Append _copy to the end to avoid the collision.
            if (!name.value.contains("_copy")) {
                name.value = name.value + "_copy1"
                uniquifyName(model, desiredAddressForName, name)
                return info
            }
            // It already had _copy on the end... fine, append a number or increment it.
            val currentName = name.value
            if (currentName[currentName.length - 1].isDigit()) {
                var number = ""
                var i = currentName.length - 1
                while (i >= 0 && currentName[i].isDigit()) {
                    number = currentName[i].toString() + number
                    i--
                }
                val digit = number.toIntOrNull() ?: 0
                var renamed = currentName.replace(number, digit.toString())
                val firstAt = renamed.indexOf(digit.toString())
                if (firstAt >= 0) renamed = renamed.substring(0, firstAt)
                renamed += (digit + 1).toString()
                name.value = renamed
                uniquifyName(model, desiredAddressForName, name)
                return info
            }
            // It wasn't a number? Eh, just throw _copy1 on the end again, it'll be fine.
            name.value = name.value + "_copy1"
            uniquifyName(model, desiredAddressForName, name)
            return info
        }
        fun spanContainsAnchor(model: IDataModel, start: Int, length: Int): Boolean { /*@DONE PokemonModel.SpanContainsAnchor/1 cs:793-817*/
            var from = start
            var remaining = length
            var run: IFormattedRun = model.getNextRun(from + 1) ?: NoInfoRun.nullRun

            // if we're starting in the middle of a run, get the next one
            if (run.start <= from) {
                remaining -= run.length + run.start - from
                from = run.start + run.length
                run = model.getNextRun(from) ?: NoInfoRun.nullRun
            }

            // move start forward to the start of the run
            remaining -= run.start - from
            from = run.start

            // check all the runs in the range for pointer sources / destination names
            while (remaining > 0) {
                if (run === NoInfoRun.nullRun) return false // there are no more runs
                if ((run.pointerSources?.size ?: 0) > 0) return true
                if (model.getAnchorFromAddress(-1, run.start).isNotEmpty()) return true
                run = model.getNextRun(run.start + run.length) ?: NoInfoRun.nullRun
                remaining -= run.start - from
                from = run.start
            }

            return false
        }
        fun considerAsPlmStream(model: IDataModel, address: Int, currentChange: ModelDelta): Boolean { /*@DONE PokemonModel.ConsiderAsPlmStream/1 cs:1803-1814*/
            val nextRun = model.getNextRun(address) ?: NoInfoRun.nullRun
            if (nextRun.start < address) return false
            if (nextRun.start == address && nextRun !is NoInfoRun) return false
            val run = PLMRun(model, address)
            if (run.length < 2) return false
            if (address + run.length > nextRun.start && nextRun.start != address) return false
            val pointers = model.searchForPointersToAnchor(currentChange, false, address) // this is slow and change the metadata. Only do it if we're sure we want the new PLMRun
            if (pointers.size == 0) return false
            model.observeAnchorWritten(currentChange, "", run.mergeAnchor(pointers))
            return true
        }
        fun readGameCode(model: IDataModel): String { /*@DONE PokemonModel.ReadGameCode/1 cs:2212-2217*/
            val address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, "data.header.gamecode")
            if (address == Pointer.null_) return ""
            val gameCode = model.getNextRun(address) as? AsciiRun
            if (gameCode == null || gameCode.start != address) return ""
            val sb = StringBuilder()
            for (i in 0 until gameCode.length) sb.append((model[gameCode.start + i] and 0xFF).toChar())
            return sb.toString()
        }
        private fun splitNameAndFormat(text: String): Pair<String, String> { /*@DONE PokemonModel.SplitNameAndFormat/1 cs:2570-2591*/
            var name = text.substring(1).trim() // lop off leading ^
            var format = ""
            var split = -1

            if (name.contains("" + BaseRun.anchorStart + ArrayRun.arrayStart)) {
                split = name.indexOf(BaseRun.anchorStart)
            } else if (name.contains(ArrayRun.arrayStart)) {
                split = name.indexOf(ArrayRun.arrayStart)
            } else if (name.contains(PCSRun.stringDelimeter)) {
                split = name.indexOf(PCSRun.stringDelimeter)
            } else if (name.contains(AsciiRun.streamDelimeter)) {
                split = name.indexOf(AsciiRun.streamDelimeter)
            }

            if (split != -1) {
                format = name.substring(split)
                name = name.substring(0, split)
            }

            return Pair(name, format)
        }
        private fun tryParseFormat(model: IDataModel, name: String, format: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo { /*@DONE PokemonModel.TryParseFormat/1 cs:2593-2609*/
            val initialRun: IFormattedRun = NoInfoRun(dataIndex)
            run.value = initialRun
            val existingRun = model.getNextRun(dataIndex) ?: NoInfoRun.nullRun
            if (existingRun.start == initialRun.start) run.value = initialRun.mergeAnchor(existingRun.pointerSources)
            if (dataIndex >= model.count || dataIndex < 0) return ErrorInfo(name + " cannot start at 0x" + dataIndex.toHex(6) + ", which is outside the file size (" + model.count.toHex(6) + ").")

            // special case: empty format, stick with the no-info run
            if (format == "") return ErrorInfo.noError

            val strategy = model.formatRunFactory.getStrategy(format) ?: return ErrorInfo("Format " + format + " was not understood.")
            val holder = Ref<IFormattedRun?>(run.value ?: initialRun)
            val result: ErrorInfo
            if (model is PokemonModel) {
                result = synchronized(model.threadlock) { strategy.tryParseData(model, name, dataIndex, holder) } ?: ErrorInfo.noError
            } else {
                result = strategy.tryParseData(model, name, dataIndex, holder) ?: ErrorInfo.noError
            }
            run.value = holder.value
            return result
        }
        private fun validateAnchorNameAndFormat(model: IDataModel, runToWrite: IFormattedRun, name: String, format: String, dataIndex: Int, allowAnchorOverwrite: Boolean = false): ErrorInfo { /*@DONE PokemonModel.ValidateAnchorNameAndFormat/1 cs:2611-2632*/
            val existingRun = model.getNextRun(dataIndex) ?: NoInfoRun.nullRun
            val nextAnchor = model.getNextAnchor(dataIndex + 1)

            if (name.lowercase() == "null") {
                return ErrorInfo("'null' is a reserved word and cannot be used as an anchor name.")
            } else if (name == "" && existingRun.start != dataIndex) {
                // if there isn't already a run here, then clearly there's nothing pointing here
                return ErrorInfo("An anchor with nothing pointing to it must have a name.")
            } else if (name == "" && (existingRun.pointerSources?.size ?: 0) == 0 && format != "") {
                // the next run DOES start here, but nothing points to it
                return ErrorInfo("An anchor with nothing pointing to it must have a name.")
            } else if (!allowAnchorOverwrite && nextAnchor.start < runToWrite.start + runToWrite.length) {
                return ErrorInfo("An existing anchor starts at " + nextAnchor.start.toAddress() + ", before the new one ends.")
            } else if (!name.all { c -> c.isLetterOrDigit() || "._".contains(c) }) {
                return ErrorInfo("Anchor names must contain only letters, numbers, dots, and underscores.")
            } else if (runToWrite.start + runToWrite.length > model.count) {
                return ErrorInfo("Anchor format must not go past the end of the file.")
            } else {
                return ErrorInfo.noError
            }
        }
        /*@END PokemonModel.Companion*/
    }
    /*@END PokemonModel*/
}

data class TableGroup(val groupName: String, val tables: List<String>) { // cs:2831-2846
    private var _hash: String? = null
    val hash: String
        get() { /*@DONE TableGroup.Hash.get cs:2834-2837*/
            if (_hash == null) _hash = StoredList.generateHash(tables)
            return _hash!!
        }
    val hashMatches: Boolean
        get() { /*@DONE TableGroup.HashMatches.get cs:2840-2840*/
            return StoredList.generateHash(tables) == hash
        }
    constructor(groupName: String, tables: List<String>, hash: String?) : this(groupName, tables) { /*@DONE TableGroup.<init>/1 cs:2842-2845*/
        _hash = hash ?: StoredList.generateHash(tables)
    }
    /*@END TableGroup*/
}

fun <T> ThreadSafeDictionary<String, T>.tryGetValueCaseInsensitive(key: String, value: Ref<in T>): Boolean { /*@DONE StringDictionaryExtensions.TryGetValueCaseInsensitive/1 cs:2849-2861*/
    if (this.containsKey(key)) {
        value.value = this[key]
        return true
    }
    val allKeys = ArrayList<String>(this.keys) // keys is a thread-safe copy
    for (option in allKeys) {
        if (key.equals(option, ignoreCase = true)) {
            value.value = this[option]
            return true
        }
    }

    return false
}

object StringDictionaryExtensions { // cs:2848-2862
    /*@END StringDictionaryExtensions*/
}

open class DebugList : ArrayList<IFormattedRun>() { // cs:2864-2899
    var insertCount: Int = 0
        private set
    var removeCount: Int = 0
        private set
    var removedRunTypes: MutableMap<Class<*>, Int> = /*@INITDONE DebugList.RemovedRunTypes cs:2868-2868*/ LinkedHashMap<Class<*>, Int>() /*@ENDINIT*/
        private set
    var replaceCount: Int = 0
        private set
    // skipped method Add: explicit implementation of an interface that is not mapped (ICollection<IFormattedRun>)
    // skipped method Insert: explicit implementation of an interface that is not mapped (IList<IFormattedRun>)
    // skipped method RemoveAt: explicit implementation of an interface that is not mapped (IList<IFormattedRun>)
    // skipped indexer this: explicit implementation of an interface that is not mapped (IList<IFormattedRun>)
    companion object {
        private val targetAddresses: IntArray = /*@INITDONE DebugList.TargetAddresses cs:2865-2865*/ IntArray(0) /*@ENDINIT*/
        /*@END DebugList.Companion*/
    }
    /*@END DebugList*/
}
