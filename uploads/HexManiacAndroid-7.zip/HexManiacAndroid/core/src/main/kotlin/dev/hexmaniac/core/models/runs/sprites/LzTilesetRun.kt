// Port of Models/Runs/Sprites/LzTilesetRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

interface ITilesetRun : ISpriteRun { // cs:7-9
    val tilesetFormat: TilesetFormat
    /*@END ITilesetRun*/
}

fun ISpriteRun.getFillerTiles(): Iterable<Int> { /*@DONE ITilesetRunExtensions.GetFillerTiles/1 cs:12-19*/
    val data = this.getData()
    val bytesPerTile = spriteFormat.bitsPerPixel * 8
    val tileCount = data.size / bytesPerTile
    val result = ArrayList<Int>()
    for (i in 0 until tileCount) {
        if (ITilesetRunExtensions.isFiller(data, i * bytesPerTile, bytesPerTile)) result.add(i)
    }
    return result
}

object ITilesetRunExtensions { // cs:11-24
    fun isFiller(data: ByteArray, start: Int, length: Int): Boolean { /*@DONE ITilesetRunExtensions.IsFiller/1 cs:21-23*/
        return length.range().all { i -> data[start + i].toInt() == 0 }
    }
    /*@END ITilesetRunExtensions*/
}

open class LzTilesetRun : LZRun, ITilesetRun { // cs:26-164
    override val spriteFormat: SpriteFormat
        get() { /*@DONE LzTilesetRun.SpriteFormat.get cs:27-27*/
            return SpriteFormat(tilesetFormat.bitsPerPixel, width, height, tilesetFormat.paletteHint)
        }
    final override var tilesetFormat: TilesetFormat = TilesetFormat()
        private set
    override val pages: Int
        get() { /*@DONE LzTilesetRun.Pages.get cs:29-29*/
            return 1
        }
    var width: Int = 0
        private set
    var height: Int = 0
        private set
    override val supportsImport: Boolean
        get() { /*@DONE LzTilesetRun.SupportsImport.get cs:32-32*/
            return false
        }
    override val supportsEdit: Boolean
        get() { /*@DONE LzTilesetRun.SupportsEdit.get cs:33-33*/
            return true
        }
    override val formatString: String
        get() { /*@DONE LzTilesetRun.FormatString.get cs:36-42*/
            var format = "`lzt" + tilesetFormat.bitsPerPixel
            if (tilesetFormat.maxTiles != -1) format += "x" + tilesetFormat.maxTiles
            val hint = tilesetFormat.paletteHint
            if (!hint.isNullOrEmpty()) format += "|" + hint
            return format + "`"
        }
    constructor(format: TilesetFormat, data: IDataModel, start: Int, sources: SortedSpan<Int>? = null) : super(data, start, format.allowLengthErrors, sources) { /*@DONE LzTilesetRun.<init>/1 cs:45-54*/
        this.tilesetFormat = format
        val tileSize = format.bitsPerPixel * 8
        val uncompressedSize = data.readMultiByteValue(start + 1, 3)
        val tileCount = uncompressedSize / tileSize
        val roughSize = Math.sqrt(tileCount.toDouble())
        width = Math.ceil(roughSize).toInt()
        height = roughSize.toInt()
        if (width * height < tileCount) height += 1
    }
    override fun getData(): ByteArray { /*@DONE LzTilesetRun.GetData/1 cs:88-88*/
        return decompress(model!!, start, allowLengthErrors) ?: ByteArray(0)
    }
    // skipped method GetPixels: explicit implementation merged with the public member
    fun getPixels(model: IDataModel, page: Int): Array<IntArray>? { /*@DONE LzTilesetRun.GetPixels/2 cs:92-96*/
        val data = decompress(model, start) ?: return null
        return SpriteRun.getPixels(data.asByteList(), 0, width, height, tilesetFormat.bitsPerPixel)
    }
    // C# ISpriteRun.GetPixels(model, page, tableIndex) explicit implementation: delegates to the 2-argument version
    override fun getPixels(model: IDataModel, page: Int, tableIndex: Int): Array<IntArray>? = getPixels(model, page)
    // C# public GetPixels(model, page, preferredTileWidth) (same JVM signature as the interface method, so renamed)
    fun getPixelsForWidth(model: IDataModel, page: Int, preferredTileWidth: Int): Array<IntArray>? { /*@DONE LzTilesetRun.GetPixels/3 cs:98-105*/
        val data = decompress(model, start, true)
        val tileSize = tilesetFormat.bitsPerPixel * 8
        var tileCount = 0
        if (data != null) tileCount = data.size / tileSize
        val preferredTileHeight = Math.ceil(tileCount.toDouble() / preferredTileWidth).toInt()
        return SpriteRun.getPixels((data ?: ByteArray(0)).asByteList(), 0, preferredTileWidth, preferredTileHeight, tilesetFormat.bitsPerPixel)
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>): ISpriteRun { /*@DONE LzTilesetRun.SetPixels/1 cs:107-121*/
        // TODO handle the fact that pixels[,] may contain a different number of tiles compared to the existing tileset
        val data = decompress(model, start) ?: return this
        for (x in 0 until pixels.getLength(0)) for (y in 0 until pixels.getLength(1)) {
            pixels[x][y] = pixels[x][y] % Math.pow(2.0, tilesetFormat.bitsPerPixel.toDouble()).toInt()
        }
        SpriteRun.setPixels(data, 0, pixels, tilesetFormat.bitsPerPixel)
        val newModelData = compress(data.asByteList(), 0, data.size)
        var newRun = model.relocateForExpansion(token, this, newModelData.count)
        for (i in 0 until newModelData.count) token.changeData(model, newRun.start + i, newModelData[i])
        for (i in newModelData.count until length) token.changeData(model, newRun.start + i, 0xFF)
        newRun = LzTilesetRun(tilesetFormat, model, newRun.start, newRun.pointerSources)
        model.observeRunWritten(token, newRun)
        return newRun
    }
    private var lastFormatRequested: Int = /*@INITDONE LzTilesetRun.lastFormatRequested cs:123-123*/ Int.MAX_VALUE /*@ENDINIT*/
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE LzTilesetRun.CreateDataFormat/1 cs:124-136*/
        val basicFormat = super.createDataFormat(data, index)
        if (!createForLeftEdge || data.spartanMode) return basicFormat
        if (lastFormatRequested < index) {
            lastFormatRequested = index
            return basicFormat
        }

        val sprite = data.currentCacheScope.getImage(this)
        val availableRows = (length - (index - start)) / expectedDisplayWidth
        lastFormatRequested = index
        return SpriteDecorator(basicFormat, sprite, expectedDisplayWidth, availableRows)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE LzTilesetRun.Clone/1 cs:138-138*/
        return LzTilesetRun(tilesetFormat, model!!, start, newPointerSources)
    }
    override fun duplicate(format: SpriteFormat): ISpriteRun { /*@DONE LzTilesetRun.Duplicate/1 cs:140-140*/
        return LzTilesetRun(TilesetFormat(format.bitsPerPixel, tilesetFormat.tiles, tilesetFormat.maxTiles, format.paletteHint), model!!, start, pointerSources)
    }
    // skipped method SetPixels: explicit implementation merged with the public member
    override fun setPixels(model: IDataModel, token: ModelDelta, tiles: List<Array<IntArray>>): LzTilesetRun { /*@DONE LzTilesetRun.SetPixels/3 cs:143-145*/
        return LzTilesetRun.setPixels(this, model, token, tiles) { newStart, sources -> LzTilesetRun(tilesetFormat, model, newStart, sources) }
    }
    companion object {
        fun tryParseTilesetFormat(format: String, tilesetFormat: Ref<TilesetFormat>): Boolean { /*@DONE LzTilesetRun.TryParseTilesetFormat/1 cs:56-86*/
            tilesetFormat.value = TilesetFormat()
            if (!(format.startsWith("`lzt") && format.endsWith("`"))) return false
            var text = format.substring(4, format.length - 1)
            var allowLengthErrors = false
            if (text.endsWith("!")) {
                text = text.substring(0, text.length - 1)
                allowLengthErrors = true
            }

            // parse the paletteHint
            var hint: String? = null
            val pipeIndex = text.indexOf('|')
            if (pipeIndex != -1) {
                hint = text.substring(pipeIndex + 1)
                text = text.substring(0, pipeIndex)
            }

            var maxTiles = -1
            if (text.contains("x")) {
                val parts = text.split("x")
                text = parts[0]
                if (parts.size > 2) return false
                val maxTilesRef = Ref(0)
                if (!tryParseInt(parts[1], maxTilesRef)) return false
                maxTiles = maxTilesRef.value
            }

            val bitsRef = Ref(0)
            if (!tryParseInt(text, bitsRef)) return false
            val bits = bitsRef.value
            if (!(bits == 1 || bits == 2 || bits == 4 || bits == 8)) return false
            tilesetFormat.value = TilesetFormat(bits, -1, maxTiles, hint, allowLengthErrors)
            return true
        }
        fun <T : ISpriteRun> setPixels(run: T, model: IDataModel, token: ModelDelta, tiles: List<Array<IntArray>>, construct: (Int, SortedSpan<Int>) -> T): T { /*@DONE LzTilesetRun.SetPixels/4 cs:147-163*/
            val bpp = run.spriteFormat.bitsPerPixel
            val tileSize = 8 * bpp
            val data = ByteArray(tiles.size * tileSize)

            for (i in 0 until tiles.size) {
                SpriteRun.setPixels(data, i * tileSize, tiles[i], bpp)
            }

            val newModelData: ByteList = if (run is LZRun) LZRun.compress(data.asByteList(), 0, data.size) else data.asByteList()
            var newRun = model.relocateForExpansion(token, run, newModelData.count)
            for (i in 0 until newModelData.count) token.changeData(model, newRun.start + i, newModelData[i])
            for (i in newModelData.count until run.length) token.changeData(model, newRun.start + i, 0xFF)
            newRun = construct(newRun.start, newRun.pointerSources ?: SortedSpan.none<Int>())
            model.observeRunWritten(token, newRun)
            return newRun
        }
        /*@END LzTilesetRun.Companion*/
    }
    /*@END LzTilesetRun*/
}
