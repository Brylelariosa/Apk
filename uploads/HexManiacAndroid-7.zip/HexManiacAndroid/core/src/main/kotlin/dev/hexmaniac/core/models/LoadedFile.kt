// Port of Models/LoadedFile.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

open class LoadedFile { // cs:2-11
    var name: String = ""
        private set
    var contents: ByteArray = ByteArray(0)
        private set
    constructor(name: String, contents: ByteArray) { /*@DONE LoadedFile.<init>/1 cs:7-10*/
        this.name = name
        this.contents = contents
    }
    /*@END LoadedFile*/
}
