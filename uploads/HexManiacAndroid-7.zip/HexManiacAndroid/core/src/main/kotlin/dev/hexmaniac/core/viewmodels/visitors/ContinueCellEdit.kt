// Port of ViewModels/Visitors/ContinueCellEdit.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.visitors

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.extendArray
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayStart
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayEnd
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.singleByteIntegerFormat
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.doubleByteIntegerFormat
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.arrayAnchorSeparator
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.signedFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.hexFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.recordFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.tupleFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.colorFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.calculatedFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.pythonButtonFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.renderFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.commentFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.splitterFormatString
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.tryParse
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.trySearch
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseTilemapTable
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.findAllLoads
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.findAllCommands
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseSegments
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.parseSegments2
import dev.hexmaniac.core.models.runs.ArrayRun.Companion.dataMatchesSegmentFormat
import dev.hexmaniac.core.models.runs.PCSRun.Companion.stringDelimeter
import dev.hexmaniac.core.models.runs.PCSRun.Companion.sharedFormatString
import dev.hexmaniac.core.models.runs.PCSRun.Companion.createPCSFormat
import dev.hexmaniac.core.models.runs.PointerRun.Companion.pointerStart
import dev.hexmaniac.core.models.runs.PointerRun.Companion.pointerEnd

open class ContinueCellEdit : IDataFormatVisitor { // cs:15-165
    private lateinit var model: IDataModel
    private var input: Char = '\u0000'
        private set
    private lateinit var underEdit: UnderEdit
        private set
    var result: Boolean = false
        private set
    constructor(model: IDataModel, input: Char, underEdit: UnderEdit) { /*@DONE ContinueCellEdit.<init>/1 cs:23-23*/
        this.model = model
        this.input = input
        this.underEdit = underEdit
    }
    override fun visit(dataFormat: Undefined, data: Int) { /*@DONE ContinueCellEdit.Visit/1 cs:25-25*/
        visit(None.instance, data)
    }
    override fun visit(dataFormat: None, data: Int) { /*@DONE ContinueCellEdit.Visit/2 cs:27-50*/
        if (underEdit.currentText.length > 0) {
            if (underEdit.currentText[0] == PointerRun.pointerStart) {
                result = input.isLetterOrDigit() || "/> .+-_".contains(input)
                return
            }

            if (underEdit.currentText[0] == ':') {
                if (underEdit.currentText.length == 1) {
                    result = input.isLetterOrDigit() || input == ' ' || input == '.' || input == ':'
                } else {
                    result = input.isLetterOrDigit() || input == ' ' || input == '.'
                }
                return
            }

            if (underEdit.currentText[0] == '.') {
                result = input.isLetterOrDigit() || " .+-=".contains(input)
                return
            }
        }

        result = ViewPort.allHexCharacters.contains(input)
    }
    override fun visit(dataFormat: UnderEdit, data: Int) { /*@DONE ContinueCellEdit.Visit/3 cs:54-54*/
        throw NotImplementedException()
    }
    override fun visit(pointer: Pointer, data: Int) { /*@DONE ContinueCellEdit.Visit/4 cs:57-57*/
        visit(None.instance, data)
    }
    override fun visit(anchor: Anchor, data: Int) { /*@DONE ContinueCellEdit.Visit/5 cs:59-59*/
        anchor.originalFormat!!.visit(this, data)
    }
    override fun visit(sprite: SpriteDecorator, data: Int) { /*@DONE ContinueCellEdit.Visit/6 cs:61-61*/
        sprite.originalFormat!!.visit(this, data)
    }
    override fun visit(decorator: StreamEndDecorator, data: Int) { /*@DONE ContinueCellEdit.Visit/7 cs:63-69*/
        if (underEdit.currentText == "[" && input == ']') {
            result = true
        } else {
            decorator.originalFormat!!.visit(this, data)
        }
    }
    override fun visit(pcs: PCS, data: Int) { /*@DONE ContinueCellEdit.Visit/8 cs:71-80*/
        if (input == PCSRun.stringDelimeter) { result = true; return }
        var strippedText = underEdit.currentText

        // if this is the start of a text segment, crop off the leading " before trying to convert to a byte
        if (pcs.position == 0 && strippedText.length > 0 && strippedText[0] == PCSRun.stringDelimeter) strippedText = strippedText.substring(1)

        val fullText = strippedText + input
        result = fullText.startsWith("\\!") || PCSString.pcs.any { str -> str != null && str.startsWith(fullText) } ||
            model.textConverter.anyMacroStartsWith(fullText)
    }
    override fun visit(pcs: EscapedPCS, data: Int) { /*@DONE ContinueCellEdit.Visit/9 cs:82-84*/
        result = ViewPort.allHexCharacters.contains(input)
    }
    override fun visit(pcs: ErrorPCS, data: Int) { /*@DONE ContinueCellEdit.Visit/10 cs:86-88*/
        throw NotImplementedException()
    }
    override fun visit(ascii: Ascii, data: Int) { /*@DONE ContinueCellEdit.Visit/11 cs:91-91*/
        result = true
    }
    override fun visit(braille: Braille, data: Int) { /*@DONE ContinueCellEdit.Visit/12 cs:93-93*/
        throw NotImplementedException()
    }
    override fun visit(integer: Integer, data: Int) { /*@DONE ContinueCellEdit.Visit/13 cs:95-100*/
        result = integer.canStartWithCharacter(input) || input.isWhitespace() || input == ')'
        if (underEdit.currentText.startsWith(".") || underEdit.currentText.startsWith(":")) {
            result = result || input.isLetterOrDigit() || input == '+' || input == '-' || input == '.'
        }
    }
    override fun visit(integer: IntegerEnum, data: Int) { /*@DONE ContinueCellEdit.Visit/14 cs:102-106*/
        result = integer.canStartWithCharacter(input) ||
            ".'~|,_&%()".contains(input) ||
            input.isWhitespace()
    }
    override fun visit(integerHex: IntegerHex, data: Int) { /*@DONE ContinueCellEdit.Visit/15 cs:108-108*/
        visit(integerHex as Integer, data)
    }
    override fun visit(section: EggSection, data: Int) { /*@DONE ContinueCellEdit.Visit/16 cs:110-110*/
        visitEgg()
    }
    override fun visit(item: EggItem, data: Int) { /*@DONE ContinueCellEdit.Visit/17 cs:111-111*/
        visitEgg()
    }
    fun visitEgg() { /*@DONE ContinueCellEdit.VisitEgg/1 cs:112-120*/
        var specialCharacters = ". '-\\" // mr. mime, farfetch'd, double-edge, nidoran
        if (underEdit.currentText.startsWith(EggMoveRun.groupStart)) specialCharacters += ']'
        if (underEdit.currentText.startsWith(PCSRun.stringDelimeter.toString())) specialCharacters += PCSRun.stringDelimeter
        result =
            input.isLetterOrDigit() ||
            specialCharacters.contains(input) ||
            input.isWhitespace()
    }
    override fun visit(item: PlmItem, data: Int) { /*@DONE ContinueCellEdit.Visit/18 cs:122-140*/
        val specialCharacters = " -" // double-edge, Vine Whip

        if (underEdit.currentText == "[") {
            result = input == ']'
        } else if (!underEdit.currentText.contains(" ")) {
            // before the space, only numbers are allowed
            result = input.isDigit() || input == ' '
        } else if (underEdit.currentText.endsWith(" ") && !underEdit.currentText.contains(PCSRun.stringDelimeter)) {
            // directly after the space, can be a quote, a letter, or a digit.
            result = input == PCSRun.stringDelimeter || input.isLetterOrDigit()
        } else if (underEdit.currentText.contains(PCSRun.stringDelimeter)) {
            // if there is a quote, accept lots
            result = input == PCSRun.stringDelimeter || input.isLetterOrDigit() || specialCharacters.contains(input)
        } else {
            // if there is no quote, accept lots, but not a quote
            result = input == PCSRun.stringDelimeter || input.isLetterOrDigit() || specialCharacters.contains(input)
        }
    }
    override fun visit(array: BitArray, data: Int) { /*@DONE ContinueCellEdit.Visit/19 cs:142-144*/
        result = input.isLetterOrDigit() || "?-\" .'~|,_&%)".contains(input)
    }
    override fun visit(word: MatchedWord, data: Int) { /*@DONE ContinueCellEdit.Visit/20 cs:146-146*/
        visit(None.instance, data)
    }
    override fun visit(endStream: EndStream, data: Int) { /*@DONE ContinueCellEdit.Visit/21 cs:148-150*/
        result = "[]+".contains(input)
    }
    override fun visit(lz: LzMagicIdentifier, data: Int) { /*@DONE ContinueCellEdit.Visit/22 cs:152-152*/
        result = input.lowercaseChar() == 'z'
    }
    override fun visit(lz: LzGroupHeader, data: Int) { /*@DONE ContinueCellEdit.Visit/23 cs:154-154*/
        result = ViewPort.allHexCharacters.contains(input) || input.isWhitespace()
    }
    override fun visit(lz: LzCompressed, data: Int) { /*@DONE ContinueCellEdit.Visit/24 cs:156-156*/
        result = input.isDigit() || input == ':' || input.isWhitespace()
    }
    override fun visit(lz: LzUncompressed, data: Int) { /*@DONE ContinueCellEdit.Visit/25 cs:158-158*/
        result = ViewPort.allHexCharacters.contains(input) || input.isWhitespace()
    }
    override fun visit(color: UncompressedPaletteColor, data: Int) { /*@DONE ContinueCellEdit.Visit/26 cs:160-162*/
        result = ViewPort.allHexCharacters.contains(input) || input == ':' || input == ' '
    }
    override fun visit(tuple: Tuple, data: Int) { /*@DONE ContinueCellEdit.Visit/27 cs:164-164*/
        result = true
    }
    /*@END ContinueCellEdit*/
}
