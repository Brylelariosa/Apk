// Port of ViewModels/Map/SurfConnectionViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.map.*

open class SurfConnectionViewModel : ViewModelCore { // cs:6-88
    private lateinit var viewPort: IEditableViewPort
    private var group: Int = 0
    private var map: Int = 0
    private var _canWarp: Boolean = false
    var canWarp: Boolean
        get() { /*@DONE SurfConnectionViewModel.CanWarp.get cs:12-12*/
            return _canWarp
        }
        set(value) { /*@DONE SurfConnectionViewModel.CanWarp.set cs:13-13*/
            set(_canWarp, value, "canWarp", { _canWarp = it }) { old -> notifyPropertiesChanged("canCreate", "canRemoveConnection") }
        }
    private var _canEmerge: Boolean = false
    var canEmerge: Boolean
        get() { /*@DONE SurfConnectionViewModel.CanEmerge.get cs:17-17*/
            return _canEmerge
        }
        set(value) { /*@DONE SurfConnectionViewModel.CanEmerge.set cs:17-17*/
            tryUpdate(_canEmerge, value, "canEmerge") { _canEmerge = it }
        }
    val canCreate: Boolean
        get() { /*@DONE SurfConnectionViewModel.CanCreate.get cs:19-19*/
            return !canWarp
        }
    val requestChangeMap = Event<ChangeMapEventArgs>()
    val connectNewMap = Event<ConnectionInfo>()
    val connectExistingMap = Event<ConnectionInfo>()
    val requestRemoveConnection = Event<EventArgs>()
    constructor(viewPort: IEditableViewPort, group: Int, map: Int) { /*@DONE SurfConnectionViewModel.<init>/1 cs:26-38*/
        this.viewPort = viewPort
        this.group = group
        this.map = map
        val allmaps = AllMapsModel.create(viewPort.model!!) { viewPort.changeHistory.currentChange }
        val connections = allmaps[group]?.get(map)?.connections
        val connection = connections?.firstOrNull { c -> c.direction.isAny(MapDirection.Dive, MapDirection.Emerge) }
        if (connection == null) {
            _canWarp = false
        } else {
            _canWarp = true
            _canEmerge = connection.direction == MapDirection.Emerge
        }
    }
    fun followConnection() { /*@DONE SurfConnectionViewModel.FollowConnection/1 cs:40-46*/
        val allmaps = AllMapsModel.create(viewPort.model!!) { viewPort.changeHistory.currentChange }
        val connections = allmaps[group]?.get(map)?.connections
        val connection = connections?.firstOrNull { c -> c.direction.isAny(MapDirection.Dive, MapDirection.Emerge) }
        if (connection == null) return
        requestChangeMap(this, ChangeMapEventArgs(connection.mapGroup, connection.mapNum))
    }
    fun diveExisting() { /*@DONE SurfConnectionViewModel.DiveExisting/1 cs:50-54*/
        val info = make(MapDirection.Dive)
        connectExistingMap(this, info)
        canWarp = true
    }
    fun emergeExisting() { /*@DONE SurfConnectionViewModel.EmergeExisting/1 cs:56-60*/
        val info = make(MapDirection.Emerge)
        connectExistingMap(this, info)
        canWarp = true
    }
    fun diveNew() { /*@DONE SurfConnectionViewModel.DiveNew/1 cs:62-66*/
        val info = make(MapDirection.Dive)
        connectNewMap(this, info)
        canWarp = true
    }
    fun emergeNew() { /*@DONE SurfConnectionViewModel.EmergeNew/1 cs:68-72*/
        val info = make(MapDirection.Emerge)
        connectNewMap(this, info)
        canWarp = true
    }
    private fun make(direction: MapDirection): ConnectionInfo { /*@DONE SurfConnectionViewModel.Make/1 cs:74-79*/
        val allmaps = AllMapsModel.create(viewPort.model!!) { viewPort.changeHistory.currentChange }
        val layout = allmaps[group]!![map]!!.layout!!
        val width = layout.width
        val height = layout.height
        return ConnectionInfo(width, height, direction)
    }
    val canRemoveConnection: Boolean
        get() { /*@DONE SurfConnectionViewModel.CanRemoveConnection.get cs:83-83*/
            return canWarp
        }
    fun removeConnection() { /*@DONE SurfConnectionViewModel.RemoveConnection/1 cs:84-87*/
        requestRemoveConnection(this, EventArgs.empty)
        canWarp = false
    }
    /*@END SurfConnectionViewModel*/
}
