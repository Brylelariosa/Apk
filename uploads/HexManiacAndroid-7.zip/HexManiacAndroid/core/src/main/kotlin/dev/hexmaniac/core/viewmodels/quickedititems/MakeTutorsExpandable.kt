// Port of ViewModels/QuickEditItems/MakeTutorsExpandable.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.quickedititems

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flySpawns
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tradeTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapBankTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.rematchTableRSE
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.wildTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.specialsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDataTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.mapLayoutTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.berryTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.flyConnections
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.dexInfoTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonNameTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.naturesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldSprites
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokemonStatsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.eggMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.overworldPalettes
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ballPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.frontSpritesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.contestTypesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokePalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.typeChartTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.shinyPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerSpritesName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemImagesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.levelMovesTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.itemEffectsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.regionalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.nationalDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.multichoiceTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveDescriptionsName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.backupFontWidthTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPalettesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultSpriteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.trainerClassNamesTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.conversionDexTableName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultTilemapNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.defaultPaletteNamespace
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.abilityDescriptionsTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.pokeIconPaletteIndexTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticleSpriteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.battleParticlePaletteTable
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveInfoListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveEffectListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTargetListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.evolutionMethodListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsShapeListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsCategoryListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decorationsPermissionListName
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emerald
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.ruby1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.sapphire1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRed1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.leafGreen1_1
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.fireRedIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldFr
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.emeraldIt
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.hmMoves
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tmCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.moveTutors
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.tutorCompatibility
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.cfruIgnoreTables
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.decodeConstantsFromReference
import dev.hexmaniac.core.models.HardcodeTablesModel.Companion.getIsCFRU

open class MakeTutorsExpandable : IQuickEditItem { // cs:10-165
    override val name: String?
        get() { /*@DONE MakeTutorsExpandable.Name.get cs:11-11*/
            return "Make Tutors Expandable"
        }
    override val description: String?
        get() { /*@DONE MakeTutorsExpandable.Description.get cs:13-14*/
            return "The initial games limited to have exactly 18 (FireRed) or no more than 32 (Emerald) tutors." +
                NEW_LINE + "This change will allow you to freely add new tutors, up to 256."
        }
    override val wikiLink: String?
        get() { /*@DONE MakeTutorsExpandable.WikiLink.get cs:16-16*/
            return "https://github.com/haven1433/HexManiacAdvance/wiki/Tutor-Expansion-Explained"
        }
    override val canRunChanged = Event<EventArgs>()
    override fun canRun(viewPortInterface: IViewPort): Boolean { /*@DONE MakeTutorsExpandable.CanRun/1 cs:20-48*/
        // require that I have a tab with real data, not a search tab or a diff tab or something
        if (viewPortInterface !is ViewPort) return false
        val viewPort: ViewPort = viewPortInterface

        // require that we fan find the specials table and that it's long enough
        val token = NoDataChangeDeltaModel()
        val specialsAddress = viewPort.model.getAddressFromAnchor(token, -1, HardcodeTablesModel.specialsTable)
        if (specialsAddress < 0 || specialsAddress > viewPort.model.count) return false
        val specials = viewPort.model.getNextRun(specialsAddress) as? ITableRun
        if (specials == null) return false
        if (specials.elementCount < 397) return false

        // require that this data actually supports this change
        val model = viewPort.model
        val gameCode = model.getGameCode()
        val offsets = getOffsets(gameCode)
        val getTutorMove = offsets.getTutorMove
        val canPokemonLearnTutorMove = offsets.canPokemonLearnTutorMove
        if (getTutorMove < 0 || canPokemonLearnTutorMove < 0) return false

        // require that this data has a tutormoves and tutorcompatibility table, since we're messing with those
        val tutormoves = model.getAddressFromAnchor(token, -1, HardcodeTablesModel.moveTutors)
        val tutorcompatibility = model.getAddressFromAnchor(token, -1, HardcodeTablesModel.tutorCompatibility)
        if (tutormoves == Pointer.null_ || tutorcompatibility == Pointer.null_) {
            return false
        }

        // if the patch has already been applied, you can't apply it again
        if (viewPort.model.getNextRun(canPokemonLearnTutorMove + 0x20) is WordRun) return false
        return true
    }
    override fun run(viewPortInterface: IViewPort): Task<ErrorInfo>? { /*@DONE MakeTutorsExpandable.Run/1 cs:50-71*/
        val viewPort = viewPortInterface as ViewPort
        val model = viewPort.model
        val token = NoDataChangeDeltaModel()
        val gameCode = model.getGameCode()

        val offsets = getOffsets(gameCode)
        val specialsAddress = model.getAddressFromAnchor(token, -1, HardcodeTablesModel.specialsTable)
        var tutorSpecial = model.readPointer(specialsAddress + 397 * 4) // Emerald tutors is actually special 477, but we don't need to edit it so it doesn't matter.
        tutorSpecial -= 1 // the pointer is to thumb code, so it's off by one.

        insertRoutine_GetTutorMove(viewPort, offsets.getTutorMove, offsets.getTutorMove_Length)
        insertRoutine_CanPokemonLearnTutorMove(viewPort, offsets.canPokemonLearnTutorMove, offsets.canPokemonLearnTutorMove_Length)
        updateRoutine_TutorSpecial(viewPort, tutorSpecial, gameCode)

        canRunChanged(this, EventArgs.empty)

        return Task.fromResult(ErrorInfo.noError)
    }
    override fun tabChanged() { /*@DONE MakeTutorsExpandable.TabChanged/1 cs:73-73*/
        canRunChanged(this, EventArgs.empty)
    }
    private fun compile(viewPort: ViewPort, start: Int, code: Array<String>): ByteList { /*@DONE MakeTutorsExpandable.Compile/1 cs:91-93*/
        val parser = viewPort.tools?.codeTool?.parser ?: throw IllegalStateException("The code tool is not available.")
        return parser.compile(viewPort.currentChange, viewPort.model, start, *code)
    }
    private fun insertRoutine_GetTutorMove(viewPort: ViewPort, address: Int, originalLength: Int) { /*@DONE MakeTutorsExpandable.InsertRoutine_GetTutorMove/1 cs:95-114*/
        val token = viewPort.currentChange
        val model = viewPort.model
        model.clearFormat(token, address, originalLength)

        val code = """
                    GetTutorMove: @ (index) -> moveID
                       lsl   r0, r0, #1
                       ldr   r1, [pc, <move_tutor_list>]
                       ldrh  r0, [r0, r1]
                       bx    lr
                    move_tutor_list:
                       .word <${HardcodeTablesModel.moveTutors}>
                 """.split(NEW_LINE)

        val bytes = compile(viewPort, address, code)
        for (i in bytes.count until originalLength) token.changeData(model, address + i, 0x00)

        viewPort.edit("@" + (address + bytes.count - 4).toHex(6) + " <" + HardcodeTablesModel.moveTutors + ">")
    }
    private fun insertRoutine_CanPokemonLearnTutorMove(viewPort: ViewPort, address: Int, originalLength: Int) { /*@DONE MakeTutorsExpandable.InsertRoutine_CanPokemonLearnTutorMove/1 cs:116-147*/
        val token = viewPort.currentChange
        val model = viewPort.model
        model.clearFormat(token, address, originalLength)

        val code = """
                    CanPokemonLearnTutorMove: @ (pokemon, tutor_move) -> bool
                       ldr     r2, [pc, <move_tutor_count>]
                       add     r2, #7
                       lsr     r2, r2, #3
                       mul     r0, r2
                       lsr     r2, r1, #3
                       add     r0, r0, r2
                       mov     r2, #7
                       and     r1, r2
                       ldr     r2, [pc, <move_tutor_compatibility>]
                       ldrb    r0, [r2, r0]
                       lsr     r0, r1
                       mov     r2, #1
                       and     r0, r2
                       bx      lr
                    move_tutor_compatibility:
                       .word <${HardcodeTablesModel.tutorCompatibility}>
                    move_tutor_count:
                       .word 0 @ ::${HardcodeTablesModel.moveTutors}
                 """.split(NEW_LINE)

        val bytes = compile(viewPort, address, code)
        for (i in bytes.count until originalLength) token.changeData(model, address + i, 0x00)

        viewPort.edit("@" + (address + bytes.count - 8).toHex(6) + " <" + HardcodeTablesModel.tutorCompatibility + "> ::" + HardcodeTablesModel.moveTutors + " ")
    }
    private fun updateRoutine_TutorSpecial(viewPort: ViewPort, tutorSpecial: Int, gameCode: String) { /*@DONE MakeTutorsExpandable.UpdateRoutine_TutorSpecial/1 cs:149-164*/
        if (gameCode == HardcodeTablesModel.emerald) return // Emerald's tutor special doesn't have a limiter, so it doesn't need to be updated.

        // change the code from 'branch-hi' to 'nop' so that the standard codepath is taken for tutorID>14
        var instructionIndex = 5
        val instructionWidth = 2
        var branchOffset = tutorSpecial + instructionIndex * instructionWidth
        viewPort.model.writeMultiByteValue(branchOffset, 2, viewPort.currentChange, 0x0000)

        // a separate routine several layers down also needs to be updated
        // change the code from 'branch-hi' to 'nop' so that the standard codepath is taken for tutorID>14
        instructionIndex = 20
        branchOffset = if (gameCode == HardcodeTablesModel.fireRed) 0x11F430 else 0x11F408 // FireRed / LeafGreen
        branchOffset += instructionIndex * instructionWidth
        viewPort.model.writeMultiByteValue(branchOffset, 2, viewPort.currentChange, 0x0000)
    }
    companion object {
        fun getOffsets(gameCode: String): MakeTutorsExpandableGetOffsetsTuple { /*@DONE MakeTutorsExpandable.GetOffsets/1 cs:75-89*/
            if (gameCode == HardcodeTablesModel.fireRed) {
                return MakeTutorsExpandableGetOffsetsTuple(0x120BA8, 0x120BE8, 0x40, 0x54)
            } else if (gameCode == HardcodeTablesModel.fireRed1_1) {
                return MakeTutorsExpandableGetOffsetsTuple(0x120C20, 0x120C60, 0x40, 0x54)
            } else if (gameCode == HardcodeTablesModel.leafGreen) {
                return MakeTutorsExpandableGetOffsetsTuple(0x120B80, 0x120BC0, 0x40, 0x54)
            } else if (gameCode == HardcodeTablesModel.leafGreen1_1) {
                return MakeTutorsExpandableGetOffsetsTuple(0x120BF8, 0x120C38, 0x40, 0x54)
            } else if (gameCode == HardcodeTablesModel.emerald) {
                return MakeTutorsExpandableGetOffsetsTuple(0x1B2360, 0x1B2370, 0x10, 0x2C)
            } else {
                return MakeTutorsExpandableGetOffsetsTuple(-1, -1, 0, 0)
            }
        }
        /*@END MakeTutorsExpandable.Companion*/
    }
    /*@END MakeTutorsExpandable*/
}

data class MakeTutorsExpandableGetOffsetsTuple(val getTutorMove: Int, val canPokemonLearnTutorMove: Int, val getTutorMove_Length: Int, val canPokemonLearnTutorMove_Length: Int)
