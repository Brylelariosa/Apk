// Port of Models/Runs/Sprites/LZRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class LZRun : BaseRun, IStreamRun, IAppendToBuilderRun { // cs:11-436
    var model: IDataModel? = null
        private set
    private var _length: Int = 0
    override val length: Int
        get() { /*@DONE LZRun.Length.get cs:19-19*/
            return _length
        }
    protected fun invalidateLength() { /*@DONE LZRun.InvalidateLength/1 cs:20-20*/
        _length = -1
    }
    var decompressedLength: Int = 0
        private set
    override val formatString: String
        get() { /*@DONE LZRun.FormatString.get cs:24-24*/
            return "`lz`"
        }
    var allowLengthErrors: Boolean = false
        private set
    var hasLengthErrors: Boolean = false
        private set
    constructor(data: IDataModel, start: Int, allowLengthErrors: Boolean = false, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE LZRun.<init>/1 cs:30-36*/
        this.model = data
        this.allowLengthErrors = allowLengthErrors
        val lengthErrors = Ref(false)
        _length = isCompressedLzData(data, start, allowLengthErrors, lengthErrors)
        hasLengthErrors = lengthErrors.value
        if (start.inRange(0, data.count - 4)) decompressedLength = data.readMultiByteValue(start + 1, 3)
    }
    private var previousScope: IDisposable? = null
    private var cache: Array<IDataFormat?> = arrayOfNulls<IDataFormat>(0)
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE LZRun.CreateDataFormat/1 cs:163-167*/
        val scope = ModelCacheScope.getCache(data)
        if (previousScope !== scope) updateCache(scope, data)
        return cache[index - start]!!
    }
    fun fixupEnd(model: IDataModel, token: ModelDelta, fixupStart: Int): LZRun? { /*@DONE LZRun.FixupEnd/1 cs:173-181*/
        val newData = recommendedFixup(fixupStart) ?: return null
        val newRun = model.relocateForExpansion(token, this, newData.count)
        val newStart = newRun.start
        for (i in 0 until newData.count) token.changeData(model, newStart + i, newData[i])
        for (i in newData.count until length) token.changeData(model, newStart + i, 0xFF)
        return duplicate(newStart, newRun.pointerSources) as LZRun
    }
    override fun serializeRun(): String? { /*@DONE LZRun.SerializeRun/1 cs:185-197*/
        val uncompressed = decompress(model!!, start, allowLengthErrors)
        val builder = StringBuilder()
        for (i in 0 until (uncompressed?.size ?: 0)) {
            if (i % 16 != 0) {
                builder.append(" ")
            } else if (i != 0) {
                builder.append(NEW_LINE)
            }
            builder.append((uncompressed!![i].toInt() and 0xFF).toHexString())
        }
        return builder.toString()
    }
    override fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, changedRuns: Ref<List<Int>?>): IStreamRun { /*@DONE LZRun.DeserializeRun/1 cs:199-214*/
        changedRuns.value = ArrayList<Int>()
        val uncompressed = ArrayList<Int>()
        for (textByte in content.split(Regex("\\s+")).filter { s -> s.isNotEmpty() }) {
            val value = Ref(0)
            if (tryParseHexByte(textByte, value)) uncompressed.add(value.value)
        }
        val data = uncompressed.toByteArrayU().asByteList()
        val compressed = compress(data, 0, data.count)
        var run: IStreamRun = this
        if (compressed.count > length) {
            run = model!!.relocateForExpansion(token, this, compressed.count)
        }
        for (i in 0 until compressed.count) token.changeData(model!!, run.start + i, compressed[i])
        for (i in compressed.count until length) token.changeData(model!!, run.start + i, 0xFF)
        changedOffsets.value = ArrayList<Int>() // don't track changes for compression streams
        return duplicate(run.start, pointerSources) as LZRun
    }
    override fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem> { /*@DONE LZRun.GetAutoCompleteOptions/1 cs:216-219*/
        val result = ArrayList<AutocompleteItem>()
        return result
    }
    override val visualizations: List<IPixelViewModel>
        get() { /*@DONE LZRun.Visualizations.get cs:221-221*/
            return ArrayList<IPixelViewModel>()
        }
    final override var preFormatter: ITextPreProcessor? = null
        private set
    override fun dependsOn(anchorName: String): Boolean { /*@DONE LZRun.DependsOn/1 cs:223-223*/
        return false
    }
    private fun recommendedFixup(fixupStart: Int): ByteList? { /*@DONE LZRun.RecommendedFixup/1 cs:236-288*/
        val m = model!!
        val newCompressedData = ArrayList<Int>()
        newCompressedData.add(m[start + 0])
        newCompressedData.add(m[start + 1])
        newCompressedData.add(m[start + 2])
        newCompressedData.add(m[start + 3])
        val uncompressedLength = newCompressedData[1] or (newCompressedData[2] shl 8) or (newCompressedData[3] shl 16)
        var currentLength = 0     // tracks the uncompressed length of newCompressedData so far
        val readIndex = Ref(start + 4) // tracks the current location we're reading from Model
        var header = 0

        while (currentLength < uncompressedLength) {
            if (newCompressedData.size < fixupStart) {
                header = m[readIndex.value]
                readIndex.value += 1
            } else {
                val remainingLength = uncompressedLength - currentLength
                var desiredCompressedTokens = Math.ceil(remainingLength / 18.0).toInt()
                if (remainingLength < 3) desiredCompressedTokens = 0
                if (desiredCompressedTokens > 8) desiredCompressedTokens = 8
                header = (0xFF shl (8 - desiredCompressedTokens)) and 0xFF
                if (readIndex.value == start + 4) header = header and 0x7F // if this is the first header, the highest bit must be 0.
            }
            newCompressedData.add(header)
            for (i in 0 until 8) {
                if (currentLength >= uncompressedLength) break
                val headerRef = Ref(header)
                val nextIsCompressed = isNextTokenCompressed(headerRef)
                header = headerRef.value
                if (nextIsCompressed) {
                    if (newCompressedData.size < fixupStart) {
                        val token = readCompressedToken(m, readIndex)
                        val runLength = token.runLength
                        val runOffset = token.runOffset
                        newCompressedData.addAll(LzCompressedToken(runLength and 0xFF, runOffset.toShort()).render())
                        currentLength += runLength
                    } else {
                        // get to the end as fast as possible (prefer 18) but no faster than able (make sure we can fulfill our requirements)
                        val minLeftover = minimumLengthNeededToFullfillHeader(header)
                        var desiredLength = uncompressedLength - currentLength - minLeftover
                        if (desiredLength > 18) desiredLength = 18
                        if (desiredLength < 3) return null // no fixup can match the current header
                        newCompressedData.addAll(LzCompressedToken(desiredLength and 0xFF, 1.toShort()).render())
                        currentLength += desiredLength
                        readIndex.value += 2
                    }
                } else {
                    if (newCompressedData.size < fixupStart) {
                        newCompressedData.add(m[readIndex.value])
                    } else {
                        // we can render anything, we're at the 'end'
                        newCompressedData.add(0)
                    }
                    readIndex.value += 1
                    currentLength += 1
                }
            }
        }

        if (header == 0 && currentLength == uncompressedLength) return newCompressedData.toByteArrayU().asByteList()
        return null // no data space left, but high-bits are left. No fixup can fix this.
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE LZRun.Clone/1 cs:290-290*/
        return LZRun(model!!, start, allowLengthErrors, newPointerSources)
    }
    private fun updateCache(scope: IDisposable, data: ByteList) { /*@DONE LZRun.UpdateCache/1 cs:336-371*/
        previousScope = scope
        cache = arrayOfNulls<IDataFormat>(length)
        val startRef = Ref(start)
        var cacheIndex = 4

        val decompressedLength = readHeader(data, startRef)
        cache[0] = LzMagicIdentifier(start)
        cache[1] = Integer(start + 1, 0, decompressedLength, 3)
        cache[2] = Integer(start + 1, 1, decompressedLength, 3)
        cache[3] = Integer(start + 1, 2, decompressedLength, 3)

        while (cacheIndex < cache.size) {
            cache[cacheIndex] = LzGroupHeader(startRef.value)
            val bitfield = Ref(data[startRef.value])
            cacheIndex++
            startRef.value++
            var i = 0
            while (i < 8 && cacheIndex < cache.size) {
                if (isNextTokenCompressed(bitfield)) {
                    if (cacheIndex + 2 > cache.size) {
                        cache[cacheIndex] = LzUncompressed(startRef.value)
                        cacheIndex++
                    } else {
                        val token = readCompressedToken(data, startRef)
                        cache[cacheIndex + 0] = LzCompressed(startRef.value - 2, 0, token.runLength, token.runOffset)
                        cache[cacheIndex + 1] = LzCompressed(startRef.value - 2, 1, token.runLength, token.runOffset)
                        cacheIndex += 2
                    }
                } else {
                    cache[cacheIndex] = LzUncompressed(startRef.value)
                    cacheIndex++
                    startRef.value++
                }
                i++
            }
        }
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE LZRun.AppendTo/1 cs:373-405*/
        var currentStart = start
        var remaining = length
        while (remaining > 0) {
            if (currentStart >= this.start + this.length) break
            var format: IDataFormat? = createDataFormat(model, currentStart)
            while (format is IDataFormatDecorator) format = format.originalFormat
            if (format is LzMagicIdentifier) {
                builder.append("lz ")
                currentStart += 1
                remaining -= 1
            } else if (format is Integer) {
                val uncompressedLength = model.readMultiByteValue(format.source, 3)
                builder.append(uncompressedLength.toString() + " ")
                currentStart += 3 - format.position
                remaining -= 3 - format.position
            } else if (format is LzGroupHeader) {
                builder.append(model[currentStart].toHexString() + " ")
                currentStart += 1
                remaining -= 1
            } else if (format is LzUncompressed) {
                builder.append(model[currentStart].toHexString() + " ")
                currentStart += 1
                remaining -= 1
            } else if (format is LzCompressed) {
                val tempStart = Ref(currentStart - format.position)
                val token = readCompressedToken(model, tempStart)
                builder.append(token.runLength.toString() + ":" + token.runOffset + " ")
                remaining -= tempStart.value - currentStart
                currentStart = tempStart.value
            } else {
                throw NotImplementedError()
            }
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE LZRun.Clear/1 cs:407-410*/
        for (i in 0 until length) changeToken.changeData(model, start + i, 0)
        fixupEnd(model, changeToken, start + length)
    }
    private interface ILzDataToken { // cs:412-415
        fun compressionBit(offset: Int): Int
        fun render(): Iterable<Int>
        /*@END LZRun.ILzDataToken*/
    }
    private open class LzUncompressedToken : ILzDataToken { // cs:417-422
        var value: Int = 0
            private set
        constructor(value: Int) { /*@DONE LZRun.LzUncompressedToken.<init>/1 cs:419-419*/
            this.value = value
        }
        override fun compressionBit(offset: Int): Int { /*@DONE LZRun.LzUncompressedToken.CompressionBit/1 cs:420-420*/
            return 0
        }
        override fun render(): Iterable<Int> { /*@DONE LZRun.LzUncompressedToken.Render/1 cs:421-421*/
            return listOf(value)
        }
        /*@END LZRun.LzUncompressedToken*/
    }
    private open class LzCompressedToken : ILzDataToken { // cs:424-435
        var length: Int = 0
            private set
        var offset: Short = 0.toShort()
            private set
        constructor(length: Int, offset: Short) { /*@DONE LZRun.LzCompressedToken.<init>/1 cs:427-427*/
            this.length = length
            this.offset = offset
        }
        override fun compressionBit(offset: Int): Int { /*@DONE LZRun.LzCompressedToken.CompressionBit/1 cs:428-428*/
            return (1 shl (7 - offset)) and 0xFF
        }
        override fun render(): Iterable<Int> { /*@DONE LZRun.LzCompressedToken.Render/1 cs:429-434*/
            val renderOffset = (this.offset - 1).limitToRange(0, 0xFFF)
            val renderLength = (this.length - 3).limitToRange(0, 0xF)
            return listOf(((renderLength shl 4) or (renderOffset shr 8)) and 0xFF, renderOffset and 0xFF)
        }
        /*@END LZRun.LzCompressedToken*/
    }
    companion object {
        val generalDecompressionError: Int = /*@INITAUTO LZRun.GeneralDecompressionError cs:12-13*/ -1 /*@ENDINIT*/
        val decompressedTooLong: Int = /*@INITAUTO LZRun.DecompressedTooLong cs:12-14*/ -2 /*@ENDINIT*/
        fun isCompressedLzData(data: ByteList, start: Int, allowLengthErrors: Boolean = false): Int { /*@DONE LZRun.IsCompressedLzData/1 cs:39-39*/
            return isCompressedLzData(data, start, allowLengthErrors, Ref(false))
        }
        fun isCompressedLzData(data: ByteList, start: Int, allowLengthErrors: Boolean, hasLengthErrors: Ref<Boolean>): Int { /*@DONE LZRun.IsCompressedLzData/2 cs:46-75*/
            hasLengthErrors.value = false
            val initialStart = start
            val startRef = Ref(start)
            val length = readHeader(data, startRef)
            if (length < 1) return generalDecompressionError
            var index = 0 // the index into the uncompressed data
            while (index < length && startRef.value < data.count) {
                val bitField = Ref(data[startRef.value])
                startRef.value++
                for (i in 0 until 8) {
                    if (index > length) break
                    if (index == length) return if (bitField.value == 0) startRef.value - initialStart else generalDecompressionError
                    val compressed = isNextTokenCompressed(bitField)
                    if (!compressed) {
                        index += 1
                        startRef.value += 1
                    } else {
                        val token = readCompressedToken(data, startRef)
                        if (index - token.runOffset < 0 || token.runLength < 0) return generalDecompressionError
                        index += token.runLength
                    }
                }
            }

            hasLengthErrors.value = index != length || startRef.value > data.count
            if (allowLengthErrors) return startRef.value - initialStart
            if (!hasLengthErrors.value) return startRef.value - initialStart
            if (index > length) return decompressedTooLong
            return generalDecompressionError
        }
        fun tryDecompress(data: ByteList, start: Int, allowLengthErrors: Boolean, result: Ref<ByteArray?>): Boolean { /*@DONE LZRun.TryDecompress/1 cs:77-77*/
            result.value = decompress(data, start, allowLengthErrors)
            return result.value != null
        }
        fun decompress(data: ByteList, start: Int, allowLengthErrors: Boolean = false): ByteArray? { /*@DONE LZRun.Decompress/1 cs:79-111*/
            val startRef = Ref(start)
            val length = readHeader(data, startRef)
            if (length < 1) return null
            var index = 0
            val result = ByteArray(length)
            while (index < length) {
                if (startRef.value >= data.count) return null
                val bitField = Ref(data[startRef.value])
                startRef.value++
                for (i in 0 until 8) {
                    if (index > length) break
                    if (index == length) return if (bitField.value == 0) result else null
                    if (startRef.value >= data.count) return null
                    val compressed = isNextTokenCompressed(bitField)
                    if (!compressed) {
                        result[index] = data[startRef.value].toByte()
                        index += 1
                        startRef.value += 1
                    } else {
                        if (startRef.value + 2 > data.count) return null
                        val token = readCompressedToken(data, startRef)
                        val runLength = token.runLength
                        val runOffset = token.runOffset
                        if (index - runOffset < 0) return null
                        for (j in 0 until runLength) {
                            if (index + j < result.size) result[index + j] = result[index + j - runOffset]
                        }
                        index += runLength
                    }
                }
                if (bitField.value != 0) return null
            }

            if (allowLengthErrors) return result
            return if (index == length) result else null
        }
        fun readCompressedToken(data: ByteList, start: Ref<Int>): LZRunReadCompressedTokenTuple { /*@DONE LZRun.ReadCompressedToken/1 cs:113-121*/
            if (data.count < start.value + 2) return LZRunReadCompressedTokenTuple(-1, -1)
            val byte1 = data[start.value + 0]
            val byte2 = data[start.value + 1]
            start.value += 2
            val runLength = (byte1 shr 4) + 3
            val runOffset = (((byte1 and 0xF) shl 8) or byte2) + 1
            return LZRunReadCompressedTokenTuple(runLength, runOffset)
        }
        fun compress(data: ByteList): ByteList { /*@DONE LZRun.Compress/1 cs:123-123*/
            return compress(data, 0, data.count)
        }
        fun compress(data: ByteList, start: Int, length: Int): ByteList { /*@DONE LZRun.Compress/2 cs:125-157*/
            // step 1: tokenize
            val tokens = ArrayList<ILzDataToken>()
            var index = start
            while (index < start + length) {
                val match = findLongestMatch(data, index, start, start + length)
                val runLength = match.first
                val runOffset = match.second
                if (runLength < 3) {
                    tokens.add(LzUncompressedToken(data[index]))
                    index += 1
                } else {
                    tokens.add(LzCompressedToken(runLength and 0xFF, runOffset.toShort()))
                    index += runLength
                }
            }

            // step 2: render the tokens into a stream
            val result = ArrayList<Int>()
            result.add(0x10) // magic number
            result.add(length and 0xFF)
            result.add((length shr 8) and 0xFF)
            result.add((length shr 16) and 0xFF)
            for (i in 0 until tokens.size) {
                if (i % 8 == 0) {
                    var bitfield = 0
                    var j = 0
                    while (j < 8 && i + j < tokens.size) {
                        bitfield = bitfield or tokens[i + j].compressionBit(j)
                        j++
                    }
                    result.add(bitfield)
                }
                result.addAll(tokens[i].render())
            }

            return result.toByteArrayU().asByteList()
        }
        fun compressedToken(runLength: Int, runOffset: Short): ByteList { /*@DONE LZRun.CompressedToken/1 cs:159-159*/
            return LzCompressedToken(runLength, runOffset).render().toList().toByteArrayU().asByteList()
        }
        private fun readHeader(data: ByteList, start: Ref<Int>): Int { /*@DONE LZRun.ReadHeader/1 cs:292-300*/
            val originalStart = start.value
            start.value += 4
            if (data.count <= start.value || originalStart < 0) return -1
            if (originalStart < 0 || start.value > data.count) return -1
            if (data[originalStart] != 0x10) return -1
            val length = data.readMultiByteValue(originalStart + 1, 3)
            return length
        }
        private fun findLongestMatch(data: ByteList, start: Int, earliest: Int, end: Int): Pair<Int, Int> { /*@DONE LZRun.FindLongestMatch/1 cs:302-315*/
            // do not allow compression tokens to start on an odd byte
            // see https://www.akkit.org/info/gbatek.htm : SWI 11h (GBA/NDS7/NDS9) - LZ77UnCompWram
            if (start % 2 == 1) return Pair(2, -1)

            var bestLength = 2
            var bestOffset = -1
            var runOffset = 2
            while (runOffset <= 0x1000 && start - runOffset >= earliest) {
                var runLength = 0
                while (start + runLength < end && runLength < 18 && data[start - runOffset + runLength] == data[start + runLength]) runLength++
                if (runLength > bestLength) {
                    bestLength = runLength
                    bestOffset = runOffset
                }
                runOffset += 2
            }
            return Pair(bestLength, bestOffset)
        }
        private fun isNextTokenCompressed(bitField: Ref<Int>): Boolean { /*@DONE LZRun.IsNextTokenCompressed/1 cs:317-321*/
            val compressed = (bitField.value and 0x80) != 0
            bitField.value = (bitField.value shl 1) and 0xFF
            return compressed
        }
        private fun minimumLengthNeededToFullfillHeader(bitField: Int): Int { /*@DONE LZRun.MinimumLengthNeededToFullfillHeader/1 cs:324-334*/
            var field = bitField
            if (field == 0) return 0
            // at least one bit is high
            var minimum = 0
            while (field != 0) {
                if ((field and 0x80) != 0) minimum += 3
                else minimum += 1
                field = (field shl 1) and 0xFF
            }
            return minimum
        }
        /*@END LZRun.Companion*/
    }
    /*@ADD LZRun#runs_10.txt*/
    private fun tryParseHexByte(text: String, result: Ref<Int>): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || trimmed.length > 8) return false
        for (c in trimmed) {
            if (!((c in '0'..'9') || (c in 'a'..'f') || (c in 'A'..'F'))) return false
        }
        val parsed = trimmed.toLong(16)
        if (parsed > 0xFF) return false
        result.value = parsed.toInt()
        return true
    }
    /*@ENDADD LZRun#runs_10.txt*/
    /*@END LZRun*/
}

abstract class PagedLZRun : LZRun { // cs:438-474
    abstract val pages: Int
    protected abstract val uncompressedPageLength: Int
    protected constructor(data: IDataModel, start: Int, allowLengthErrors: Boolean = false, sources: SortedSpan<Int>? = null) : super(data, start, allowLengthErrors, sources) { /*@DONE PagedLZRun.<init>/1 cs:442-442*/ }
    fun appendPage(token: ModelDelta): PagedLZRun { /*@DONE PagedLZRun.AppendPage/1 cs:444-458*/
        val m = model!!
        val data = decompress(m, start)!!
        val lastPage = pages - 1
        val pageLength = uncompressedPageLength
        val newData = ByteArray(data.size + pageLength)
        System.arraycopy(data, 0, newData, 0, data.size)
        System.arraycopy(data, lastPage * pageLength, newData, data.size, pageLength)
        val newModelData = compress(newData.asByteList(), 0, newData.size)

        var newRun = m.relocateForExpansion(token, this, newModelData.count)
        for (i in 0 until newModelData.count) token.changeData(m, newRun.start + i, newModelData[i])
        newRun = newRun.duplicate(newRun.start, newRun.pointerSources) as PagedLZRun
        m.observeRunWritten(token, newRun)
        return newRun
    }
    fun deletePage(page: Int, token: ModelDelta): PagedLZRun { /*@DONE PagedLZRun.DeletePage/1 cs:460-473*/
        val m = model!!
        val data = decompress(m, start)!!
        val pageLength = uncompressedPageLength
        val newData = ByteArray(data.size - pageLength)
        System.arraycopy(data, 0, newData, 0, page * pageLength)
        System.arraycopy(data, (page + 1) * pageLength, newData, page * pageLength, (pages - page - 1) * pageLength)
        val newModelData = compress(newData.asByteList(), 0, newData.size)

        for (i in 0 until newModelData.count) token.changeData(m, start + i, newModelData[i])
        for (i in newModelData.count until length) token.changeData(m, start + i, 0xFF)
        val newRun = duplicate(start, pointerSources) as PagedLZRun
        m.observeRunWritten(token, newRun)
        return newRun
    }
    /*@END PagedLZRun*/
}

data class LZRunReadCompressedTokenTuple(val runLength: Int, val runOffset: Int)
