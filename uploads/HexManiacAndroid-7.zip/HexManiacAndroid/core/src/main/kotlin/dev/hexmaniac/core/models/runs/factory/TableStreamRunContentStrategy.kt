// Port of Models/Runs/Factory/TableStreamRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class TableStreamRunContentStrategy : RunStrategy() { // cs:12-77
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE TableStreamRunContentStrategy.LengthForNewRun/1 cs:13-18*/
        val tableRun = getTable(model, pointerAddress)!!
        val pointerSegment = getSegment(tableRun, pointerAddress)
        val newStream = Ref<TableStreamRun?>(null)
        TableStreamRun.tryParseTableStream(model, -1, SortedSpan(pointerAddress), pointerSegment.name, pointerSegment.innerFormat, tableRun.elementContent, newStream)
        return newStream.value?.length ?: 0
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE TableStreamRunContentStrategy.TryAddFormatAtDestination/1 cs:19-33*/
        val tsRunRef = Ref<TableStreamRun?>(null)
        if (TableStreamRun.tryParseTableStream(owner, destination, SortedSpan(source), name, format!!, sourceSegments, tsRunRef)) {
            val tsRun = tsRunRef.value!!
            if (token !is NoDataChangeDeltaModel) {
                // we know that the data format matches, but there may already be a run there that starts sooner
                val existingTable = owner.getNextRun(tsRun.start) as? ITableRun
                if (existingTable != null && existingTable.start < tsRun.start) {
                    // there is already a format that starts sooner: do nothing, but return true because the format matches
                } else {
                    owner.clearFormat(token, tsRun.start + 1, tsRun.length - 1)
                    owner.observeRunWritten(token, tsRun)
                }
            }
            return true
        }
        return false
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE TableStreamRunContentStrategy.Matches/1 cs:34-37*/
        if (run == null || run.formatString != format) return false
        return run is ITableRun
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE TableStreamRunContentStrategy.WriteNewRun/1 cs:38-43*/
        // don't bother checking the TryParse result: we very much expect that the data originally in the run won't fit the parse.
        val parsed = Ref<TableStreamRun?>(null)
        TableStreamRun.tryParseTableStream(owner, destination, SortedSpan(source), name, format!!, sourceSegments, parsed)
        val tableStream = Ref<TableStreamRun>(parsed.value!!)
        if (TableStreamRun.tryWriteNewEndToken(token, tableStream)) return tableStream.value
        val lines = ArrayList<String>()
        for (i in 0 until tableStream.value.elementCount) lines.add(" ")
        return tableStream.value.deserializeRun(lines.joinToString(NEW_LINE), token, Ref<List<Int>?>(null), Ref<List<Int>?>(null))
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE TableStreamRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:45-48*/
        val runAttempt = Ref<TableStreamRun?>(null)
        if (!TableStreamRun.tryParseTableStream(model, run.value.start, run.value.pointerSources, name, format!!, sourceSegments, runAttempt)) return
        updateNewRunFromPointerFormat(model, token, run, runAttempt.value!!)
    }
    fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, segment: ArrayRunPointerSegment, sourceSegments: List<ArrayRunElementSegment>, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE TableStreamRunContentStrategy.UpdateNewRunFromPointerFormat/2 cs:50-53*/
        val runAttempt = Ref<TableStreamRun?>(null)
        val sources: SortedSpan<Int> = run.value.pointerSources ?: SortedSpan<Int>(ArrayList<Int>())
        if (!segment.tryParseTableStream(model, run.value.start, sources, sourceSegments, true, runAttempt)) return
        updateNewRunFromPointerFormat(model, token, run, runAttempt.value!!)
    }
    private fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, run: Ref<IFormattedRun>, runAttempt: TableStreamRun) { /*@DONE TableStreamRunContentStrategy.UpdateNewRunFromPointerFormat/3 cs:55-62*/
        val table = run.value as? ITableRun
        if (table != null && runAttempt.formatString == table.formatString && runAttempt.length == table.length) {
            // we don't need to do a clear: the new format matches the existing format
        } else {
            model.clearFormat(token, run.value.start, runAttempt.length)
        }
        run.value = runAttempt
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE TableStreamRunContentStrategy.TryParseData/1 cs:64-76*/
        var pointerSources = model.getUnmappedSourcesToAnchor(name)
        val readable = ArrayList<Int>()
        for (i in 0 until pointerSources.size) {
            val source = pointerSources[i]
            if (model.readValue(source) == 0) readable.add(source)
        }
        pointerSources = SortedSpan<Int>(readable)
        val currentRun = run.value
        if (currentRun != null && currentRun.pointerSources != null) pointerSources = pointerSources.add(currentRun.pointerSources)
        val arrayRun = Ref<ITableRun?>(null)
        val errorInfo = ArrayRun.tryParse(model, name, format!!, dataIndex, pointerSources, arrayRun)
        if (errorInfo === ErrorInfo.noError) {
            run.value = arrayRun.value
        } else if (format != "") {
            return ErrorInfo("Format " + format + " was not understood: " + errorInfo.errorMessage)
        }

        return ErrorInfo.noError
    }
    /*@END TableStreamRunContentStrategy*/
}
