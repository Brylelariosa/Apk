package dev.hexmaniac.core.system

/**
 * Placeholders of the generated Kotlin skeleton: a member that has not been ported yet returns a harmless default
 * (lenient mode, used by the app) or throws (strict mode, used by the tests so that unported code is noticed).
 */
object PortStub {
    @JvmField
    var strict: Boolean = false
}

fun port() {
    if (PortStub.strict) throw NotImplementedError("PORT")
}

fun <T> port(default: T): T {
    if (PortStub.strict) throw NotImplementedError("PORT")
    return default
}

/** Placeholder for a member whose result type has no harmless default. */
fun portFail(): Nothing = throw NotImplementedError("PORT")
