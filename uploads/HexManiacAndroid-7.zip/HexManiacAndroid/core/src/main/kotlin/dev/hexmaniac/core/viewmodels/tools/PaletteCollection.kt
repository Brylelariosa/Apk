// Port of ViewModels/Tools/PaletteCollection.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class ReadonlyPaletteCollection : ViewModelCore { // cs:14-25
    val colorWidth: Int
        get() { /*@DONE ReadonlyPaletteCollection.ColorWidth.get cs:15-15*/
            return Math.ceil(Math.sqrt(colors.size.toDouble())).toInt()
        }
    val colorHeight: Int
        get() { /*@DONE ReadonlyPaletteCollection.ColorHeight.get cs:16-16*/
            return Math.sqrt(colors.size.toDouble()).toInt()
        }
    var index: Int = 0
        private set
    var displayIndex: Boolean = false
        private set
    var colors: ObservableCollection<Short> = /*@INITAUTO ReadonlyPaletteCollection.Colors cs:19-19*/ ObservableCollection() /*@ENDINIT*/
        private set
    constructor(colors: Iterable<Short>, index: Int = -1) { /*@DONE ReadonlyPaletteCollection.<init>/1 cs:20-24*/
        for (color in colors) this.colors.add(color)
        this.index = index
        this.displayIndex = index >= 0
    }
    /*@END ReadonlyPaletteCollection*/
}

open class PaletteCollection : ViewModelCore { // cs:27-543
    private var tab: IRaiseMessageTab? = null
    private var model: IDataModel? = null
    private var history: ChangeHistory<ModelDelta>? = null
    private var _sourcePalettePointer: Int = 0
    var sourcePalettePointer: Int
        get() { /*@DONE PaletteCollection.SourcePalettePointer.get cs:33-33*/
            return _sourcePalettePointer
        }
        set(value) { /*@DONE PaletteCollection.SourcePalettePointer.set cs:33-33*/
            tryUpdate(_sourcePalettePointer, value, "sourcePalettePointer", { _sourcePalettePointer = it })
        }
    var elements: ObservableCollection<SelectableColor> = /*@INITDONE PaletteCollection.Elements cs:34-34*/ ObservableCollection() /*@ENDINIT*/
        private set
    val colorWidth: Int
        get() { /*@DONE PaletteCollection.ColorWidth.get cs:36-36*/
            val height = colorHeight
            return if (height == 0) 0 else elements.size / height
        }
    val colorHeight: Int
        get() { /*@DONE PaletteCollection.ColorHeight.get cs:37-37*/
            return Math.ceil(Math.sqrt(elements.size.toDouble())).toInt()
        }
    val canEditColors: Boolean
        get() { /*@DONE PaletteCollection.CanEditColors.get cs:38-38*/
            val currentModel = model
            return _sourcePalettePointer >= 0 && _page >= 0 && (currentModel == null || _sourcePalettePointer <= currentModel.count - 4)
        }
    var spriteBitsPerPixel: Int = 0
    val selectionSet = Event<EventArgs>()
    private var _selectionStart: Int = 0
    var selectionStart: Int
        get() { /*@DONE PaletteCollection.SelectionStart.get cs:46-46*/
            return _selectionStart
        }
        set(value) { /*@DONE PaletteCollection.SelectionStart.set cs:47-55*/
            if ((value >= 0 && elements.size > value && elements[value].selected) || !tryUpdate(_selectionStart, value, "selectionStart", { _selectionStart = it })) {
                selectionSet(this, EventArgs.empty)
                return
            }

            selectionEnd = _selectionStart
            history?.changeCompleted()
        }
    private var _selectionEnd: Int = 0
    var selectionEnd: Int
        get() { /*@DONE PaletteCollection.SelectionEnd.get cs:60-60*/
            return _selectionEnd
        }
        set(value) { /*@DONE PaletteCollection.SelectionEnd.set cs:61-69*/
            tryUpdate(_selectionEnd, value, "selectionEnd", { _selectionEnd = it })
            val first = Math.min(_selectionStart, _selectionEnd)
            val last = Math.max(_selectionStart, _selectionEnd)
            for (i in 0 until elements.size) elements[i].selected = first <= i && i <= last
            _createGradient?.raiseCanExecuteChanged()
            _singleReduce?.raiseCanExecuteChanged()
            selectionSet(this, EventArgs.empty)
        }
    private var _page: Int = 0
    var page: Int
        get() { /*@DONE PaletteCollection.Page.get cs:73-73*/
            return _page
        }
        set(value) { /*@DONE PaletteCollection.Page.set cs:73-73*/
            tryUpdate(_page, value, "page", { _page = it })
        }
    private var _hoverIndex: Int = 0
    var hoverIndex: Int
        get() { /*@DONE PaletteCollection.HoverIndex.get cs:76-76*/
            return _hoverIndex
        }
        set(value) { /*@DONE PaletteCollection.HoverIndex.set cs:76-76*/
            set(_hoverIndex, value, "hoverIndex", { _hoverIndex = it }) { old -> hoverChanged(old) }
        }
    private fun hoverChanged(obj: Int) { /*@DONE PaletteCollection.HoverChanged/1 cs:78-81*/
        _copy?.raiseCanExecuteChanged()
        _paste?.raiseCanExecuteChanged()
    }
    private var _hasMultiplePages: Boolean = false
    var hasMultiplePages: Boolean
        get() { /*@DONE PaletteCollection.HasMultiplePages.get cs:84-84*/
            return _hasMultiplePages
        }
        set(value) { /*@DONE PaletteCollection.HasMultiplePages.set cs:84-84*/
            tryUpdate(_hasMultiplePages, value, "hasMultiplePages", { _hasMultiplePages = it })
        }
    private var _copy: StubCommand? = null
    val copy: ICommand
        get() { /*@DONE PaletteCollection.Copy.get cs:87-87*/
            return _copy ?: stubCommandOf<IFileSystem>({ fs -> if (fs != null) executeCopy(fs) }, { fs -> fs != null && canExecuteCopy(fs) }).also { _copy = it }
        }
    private var _paste: StubCommand? = null
    val paste: ICommand
        get() { /*@DONE PaletteCollection.Paste.get cs:90-90*/
            return _paste ?: stubCommandOf<IFileSystem>({ fs -> if (fs != null) executePaste(fs) }, { fs -> fs != null && canExecutePaste(fs) }).also { _paste = it }
        }
    private var _createGradient: StubCommand? = null
    val createGradient: ICommand
        get() { /*@DONE PaletteCollection.CreateGradient.get cs:93-93*/
            return _createGradient ?: stubCommand({ executeCreateGradient() }, { canExecuteCreateGradient() }).also { _createGradient = it }
        }
    private var _singleReduce: StubCommand? = null
    val singleReduce: ICommand
        get() { /*@DONE PaletteCollection.SingleReduce.get cs:96-96*/
            return _singleReduce ?: stubCommand({ executeSingleReduce() }, { canExecuteSingleReduce() }).also { _singleReduce = it }
        }
    private var _deleteColor: StubCommand? = null
    val deleteColor: ICommand
        get() { /*@DONE PaletteCollection.DeleteColor.get cs:99-99*/
            return _deleteColor ?: stubCommand({ executeDelete() }).also { _deleteColor = it }
        }
    val requestPageSet = Event<Int>()
    val paletteRepointed = Event<Int>()
    val colorsChanged = Event<EventArgs>()
    constructor(tab: IRaiseMessageTab, model: IDataModel, history: ChangeHistory<ModelDelta>) { /*@DONE PaletteCollection.<init>/1 cs:112-116*/
        this.tab = tab
        this.model = model
        this.history = history
    }
    constructor() { /*@DONE PaletteCollection.<init>/2 cs:122-122*/
        // parameterless: used by the UI when there is no model behind the palette
    }
    fun handleMove(originalIndex: Int, newIndex: Int): MutableList<PaletteCollectionHandleMoveTuple> { /*@DONE PaletteCollection.HandleMove/1 cs:124-151*/
        val otherMovedElements = ArrayList<PaletteCollectionHandleMoveTuple>()
        if (originalIndex == newIndex) return otherMovedElements

        val first = Math.min(_selectionStart, _selectionEnd)
        val last = Math.max(_selectionStart, _selectionEnd)
        var target = Math.max(newIndex, originalIndex - first)
        target = Math.min(target, elements.size - 1 - last + originalIndex)
        val targetElements = (first..last).toMutableList()

        if (originalIndex < target) targetElements.reverse()
        for (index in targetElements) {
            val element = elements[index]
            elements.removeAt(index)
            elements.add(target - originalIndex + index, element)
        }

        for (i in first until target - (originalIndex - first)) {
            otherMovedElements.add(PaletteCollectionHandleMoveTuple(i, last - first + 1))
        }
        var j = last
        while (j > target + (last - originalIndex)) {
            otherMovedElements.add(PaletteCollectionHandleMoveTuple(j, first - last - 1))
            j--
        }

        _selectionStart += target - originalIndex
        selectionEnd = selectionEnd + (target - originalIndex)
        return otherMovedElements
    }
    fun toggleSelection(index: Int) { /*@DONE PaletteCollection.ToggleSelection/1 cs:153-173*/
        elements[index].selected = !elements[index].selected
        _createGradient?.raiseCanExecuteChanged()
        _singleReduce?.raiseCanExecuteChanged()

        // if all the selected elements are contiguous, clean up the selection start/end
        val first = elements.firstOrNull { e -> e.selected }
        val last = elements.lastOrNull { e -> e.selected }
        if (first != null && last != null && last !== first) {
            var allSelected = true
            var i = first.index + 1
            while (i < last.index && allSelected) {
                allSelected = elements[i].selected
                i++
            }
            if (allSelected) {
                _selectionStart = first.index
                _selectionEnd = last.index
                notifyPropertyChanged("selectionStart")
                notifyPropertyChanged("selectionEnd")
            }
        }

        selectionSet(this, EventArgs.empty)
    }
    fun completeCurrentInteraction() { /*@DONE PaletteCollection.CompleteCurrentInteraction/1 cs:175-178*/
        reorderPalette()
        history?.changeCompleted()
    }
    fun setContents(colors: List<Short>) { /*@DONE PaletteCollection.SetContents/1 cs:180-197*/
        val left = Math.min(selectionStart, selectionEnd)
        val right = Math.max(selectionStart, selectionEnd)
        val toAdd = (0 until colors.size).map { i ->
            val item = SelectableColor()
            item.color = colors[i]
            item.index = i
            item.selected = left <= i && i <= right
            item
        }

        clearSilentChildren()
        for (child in toAdd) addSilentChild(child)

        for (i in 0 until toAdd.size) {
            if (elements.size > i) {
                elements[i] = toAdd[i]
            } else {
                elements.add(toAdd[i])
            }
        }
        while (elements.size > toAdd.size) elements.removeAt(elements.size - 1)
        notifyPropertyChanged("colorWidth")
        notifyPropertyChanged("colorHeight")
    }
    fun pushColorsToModel() { /*@DONE PaletteCollection.PushColorsToModel/1 cs:199-225*/
        val model = this.model
        if (model == null || !canEditColors) return
        val sourcePalette = model.readPointer(_sourcePalettePointer)
        var source = model.getNextRun(sourcePalette) as? IPaletteRun ?: return
        if (_page < 0) {
            tab?.raiseMessage("Cannot edit colors for a default palette page!")
            return
        }

        val colors = elements.map { e -> e.color }
        source = repointIfBadData(source, _sourcePalettePointer)

        // update model
        var newPalette = source
        newPalette = newPalette.setPalette(model, history!!.currentChange, _page, colors)
        if (source.start != newPalette.start) {
            tab?.raiseMessage("Palette was moved to " + newPalette.start.toHex(6) + ". Pointers were updated.")
            paletteRepointed(this, newPalette.start)
        }

        // update UI
        val selectionRangeStart = _selectionStart
        val selectionRangeEnd = _selectionEnd
        val selections = elements.map { e -> e.selected }
        refresh()
        selectionStart = selectionRangeStart
        selectionEnd = selectionRangeEnd
        for (i in 0 until elements.size) {
            if (i < selections.size) elements[i].selected = selections[i]
        }
    }
    fun singleSelect() { /*@DONE PaletteCollection.SingleSelect/1 cs:230-240*/
        if (selectionEnd != selectionStart) {
            selectionEnd = selectionStart
            return
        }

        for (i in 0 until elements.size) elements[i].selected = selectionStart == i
        _createGradient?.raiseCanExecuteChanged()
        _singleReduce?.raiseCanExecuteChanged()
        selectionSet(this, EventArgs.empty)
    }
    private fun reorderPalette() { /*@DONE PaletteCollection.ReorderPalette/1 cs:242-335*/
        val model = this.model
        if (model == null || !canEditColors) return
        if (_sourcePalettePointer < 0 || _sourcePalettePointer > model.count - 4) return
        val sourcePalette = model.readPointer(_sourcePalettePointer)
        val source = model.getNextRun(sourcePalette) as? IPaletteRun ?: return
        val hist = this.history ?: return

        val oldToNew = IntArray(elements.size) { i -> elements.indexOf(elements.single { element -> element.index == i }) }
        val newElements = (0 until elements.size).map { i ->
            val item = SelectableColor()
            item.index = i
            item.color = elements[elements[i].index].color
            item.selected = elements[i].selected
            item
        }

        // early exit if there's no actual changes
        if ((0 until elements.size).all { i -> elements[i].index == newElements[i].index }) return

        val palettesToUpdate = ArrayList<IPaletteRun>()
        palettesToUpdate.add(source)
        val sprites = source.findDependentSprites(model).distinct()

        for (sprite in sprites) {
            var newSprite = sprite

            if (sprite is LzTilesetRun) {
                // find all tilemaps that use this tileset and update them
                val tilemaps = sprite.findDependentTilemaps(model)
                for (tilemap in tilemaps) {
                    val pixels = tilemap.getPixels(model, 0, -1) ?: continue
                    for (y in 0 until pixels.getLength(1)) {
                        for (x in 0 until pixels.getLength(0)) {
                            var tilesetPalettePage = source.paletteFormat.initialBlankPages
                            if (_hasMultiplePages) tilesetPalettePage = pixels[x][y] shr 4
                            // note that if a tilemap has a tile with a palette of 'zero', this page calculation comes out as negative, and no swapping will be done.
                            // in the game, this only happens for tiles filled with the fully transparent color, so leaving them alone is actually the right thing to do.
                            if (tilesetPalettePage - source.paletteFormat.initialBlankPages != _page) continue
                            var oldPaletteColorIndex = pixels[x][y] - (tilesetPalettePage shl 4)
                            var tilesetPageOffset = 0
                            while (oldPaletteColorIndex < 0) { oldPaletteColorIndex += 16; tilesetPageOffset += 16 }
                            while (oldPaletteColorIndex >= oldToNew.size) { oldPaletteColorIndex -= 16; tilesetPageOffset -= 16 }
                            val newPaletteColorIndex = oldToNew[oldPaletteColorIndex]
                            pixels[x][y] = newPaletteColorIndex + (tilesetPalettePage shl 4) - tilesetPageOffset
                        }
                    }
                    val newTileMap = tilemap.setPixels(model, hist.currentChange, 0, pixels)
                    if (newTileMap.start != tilemap.start) {
                        tab?.raiseMessage("Tilemap was moved to " + newTileMap.start.toHex(6) + ". Pointers were updated.")
                        if (dataIsSelected(tilemap.start)) tab?.goto?.execute(newTileMap.start)
                    }
                }
                // find the new tileset sprite, since it could've moved
                newSprite = model.getNextRun(model.readPointer(sprite.pointerSources!![0])) as? ISpriteRun ?: sprite
            } else {
                // get/set the sprite data for each relavent page
                var spritePage = 0
                while (spritePage < newSprite.pages) {
                    if (_hasMultiplePages) spritePage += _page
                    val pixels = newSprite.getPixels(model, spritePage % newSprite.pages, -1)
                    if (pixels != null) {
                        for (y in 0 until pixels.getLength(1)) {
                            for (x in 0 until pixels.getLength(0)) {
                                val pixelPage = pixels[x][y] / oldToNew.size
                                pixels[x][y] -= pixelPage * oldToNew.size
                                pixels[x][y] = oldToNew[pixels[x][y]] + pixelPage * oldToNew.size
                            }
                        }
                        newSprite = newSprite.setPixels(model, hist.currentChange, spritePage % newSprite.pages, pixels)
                    }
                    if (_hasMultiplePages) break
                    spritePage++
                }

                if (newSprite.start != sprite.start) {
                    tab?.raiseMessage("Sprite was moved to " + newSprite.start.toHex(6) + ". Pointers were updated.")
                    if (dataIsSelected(sprite.start)) tab?.goto?.execute(newSprite.start)
                }
            }

            palettesToUpdate.addAll(newSprite.findRelatedPalettes(model, includeAllTableIndex = true))
        }

        for (palette in palettesToUpdate.distinct()) {
            var newPalette = palette
            val colors = newPalette.getPalette(model, _page) ?: continue
            val newColors = (0 until elements.size).map { i -> colors[elements[i].index] }
            val newPaletteSources = newPalette.pointerSources
            if (newPaletteSources != null && newPaletteSources.size > 0) {
                // handle possible bad format repoints
                newPalette = repointIfBadData(newPalette, newPaletteSources[0])
            }
            newPalette = newPalette.setPalette(model, hist.currentChange, _page, newColors)
            if (palette.start != newPalette.start) tab?.raiseMessage("Palette was moved to " + newPalette.start.toHex(6) + ". Pointers were updated.")
        }

        for (i in 0 until elements.size) {
            elements[i].selected = newElements[i].selected
            elements[i].index = newElements[i].index
            // the elements order changed, so the element should already have the right color.
        }
        refresh()
    }
    private fun dataIsSelected(runStart: Int): Boolean { /*@DONE PaletteCollection.DataIsSelected/1 cs:337-341*/
        val viewPort = tab as? ViewPort ?: return false
        val selectedAddress = viewPort.convertViewPointToAddress(viewPort.selectionStart)
        return model?.getNextRun(selectedAddress)?.start == runStart
    }
    private fun refresh() { /*@DONE PaletteCollection.Refresh/1 cs:343-349*/
        val tab = this.tab ?: return
        val currentPage = _page
        tab.refresh()
        if (_hasMultiplePages) requestPageSet(this, currentPage)
        colorsChanged(this, EventArgs.empty)
    }
    private fun <T> repointIfBadData(run: T, pointerSource: Int): T { /*@DONE PaletteCollection.RepointIfBadData/1 cs:351-371*/
        if (run !is LZRun) return run
        if (!run.hasLengthErrors) return run
        val lz: LZRun = run
        val model = this.model!!
        val hist = this.history!!

        val token = hist.currentChange
        val uncompressed = LZRun.decompress(model, lz.start, true)!!
        val newCompressed = LZRun.compress(uncompressed.asByteList())
        var newDestination = model.findFreeSpace(lz.start, newCompressed.count)
        if (newDestination == -1) {
            newDestination = model.count
            model.expandData(token, model.count + newCompressed.count)
        }

        hist.currentChange.changeData(model, newDestination, newCompressed)

        val newRun = lz.duplicate(newDestination, SortedSpan<Int>(pointerSource))
        model.clearPointer(token, pointerSource, lz.start)
        model.writePointer(token, pointerSource, newDestination) // point to the new destination
        model.observeRunWritten(token, newRun)
        return newRun as T
    }
    private fun executeCopy(fileSystem: IFileSystem) { /*@DONE PaletteCollection.ExecuteCopy/1 cs:375-381*/
        val copied = ArrayList<String>()
        for (element in elements) {
            if (element.selected) copied.add(UncompressedPaletteColor.convert(element.color) ?: "")
        }
        fileSystem.copyText = copied.joinToString(" ")
    }
    private fun canExecuteCopy(fileSystem: IFileSystem): Boolean { /*@DONE PaletteCollection.CanExecuteCopy/1 cs:383-383*/
        return 0 <= _selectionStart && _selectionStart < elements.size
    }
    private fun executePaste(fileSystem: IFileSystem) { /*@DONE PaletteCollection.ExecutePaste/1 cs:420-437*/
        val model = this.model
        if (model != null) {
            val sourcePalette = model.readPointer(_sourcePalettePointer)
            if (model.getNextRun(sourcePalette) !is IPaletteRun) return
        }

        // paste data into elements
        val clipboard = fileSystem.copyText ?: return
        val colors = parseColor(clipboard) ?: return
        var start = Math.min(_selectionStart, _selectionEnd)
        for (i in 0 until colors.size) {
            elements[start].color = colors[i]
            if (start < elements.size - 1) start += 1
        }

        pushColorsToModel()
        selectionStart = start
    }
    private fun canExecutePaste(fileSystem: IFileSystem): Boolean { /*@DONE PaletteCollection.CanExecutePaste/1 cs:439-439*/
        val clipboard = fileSystem.copyText ?: return false
        return canExecuteCopy(fileSystem) && parseColor(clipboard) != null
    }
    private fun executeCreateGradient() { /*@DONE PaletteCollection.ExecuteCreateGradient/1 cs:441-467*/
        val left = (0 until elements.size).first { i -> elements[i].selected }
        val right = (0 until elements.size).last { i -> elements[i].selected }

        val leftRGB = UncompressedPaletteColor.toRGB(elements[left].color)
        val leftLAB = Theme.toOklab(((leftRGB.r * 33) shr 2) and 0xFF, ((leftRGB.g * 33) shr 2) and 0xFF, ((leftRGB.b * 33) shr 2) and 0xFF)

        val rightRGB = UncompressedPaletteColor.toRGB(elements[right].color)
        val rightLAB = Theme.toOklab(((rightRGB.r * 33) shr 2) and 0xFF, ((rightRGB.g * 33) shr 2) and 0xFF, ((rightRGB.b * 33) shr 2) and 0xFF)

        val deltaLight = rightLAB.lightness - leftLAB.lightness
        val deltaA = rightLAB.a - leftLAB.a
        val deltaB = rightLAB.b - leftLAB.b

        val distance = right - left
        for (i in 1 until distance) {
            if (!elements[left + i].selected) continue
            val part = i.toDouble() / distance
            val light = leftLAB.lightness + deltaLight * part
            val a_ = leftLAB.a + deltaA * part
            val b_ = leftLAB.b + deltaB * part
            val rgb = Theme.fromOklab(light, a_, b_)
            elements[left + i].color = UncompressedPaletteColor.pack(rgb.red shr 3, rgb.green shr 3, rgb.blue shr 3)
        }

        pushColorsToModel()
    }
    private fun canExecuteCreateGradient(): Boolean { /*@DONE PaletteCollection.CanExecuteCreateGradient/1 cs:469-469*/
        return elements.count { element -> element.selected } > 2
    }
    private fun executeSingleReduce() { /*@DONE PaletteCollection.ExecuteSingleReduce/1 cs:471-531*/
        val model = this.model ?: return
        val hist = this.history ?: return
        val sourcePalette = model.readPointer(_sourcePalettePointer)
        val paletteRun = model.getNextRun(sourcePalette) as? IPaletteRun ?: return
        val pageOffset = (paletteRun.paletteFormat.initialBlankPages + page) shl 4

        val masses = ArrayList<ColorMass>()
        for (i in 0 until elements.size) {
            if (!elements[i].selected) continue
            var count = 0
            for (dependent in paletteRun.findDependentSprites(model)) {
                var items: List<ISpriteRun> = listOf(dependent)
                if (dependent is LzTilesetRun) items = dependent.findDependentTilemaps(model)
                for (sprite in items) {
                    for (j in 0 until sprite.pages) {
                        val spritePixels = sprite.getPixels(model, j, -1) ?: continue
                        for (column in spritePixels) {
                            for (pixelIndex in column) {
                                if (pixelIndex == pageOffset + i) count += 1
                            }
                        }
                    }
                }
            }
            masses.add(ColorMass(elements[i].color, count))
        }

        val bestPair = WeightedPalette.cheapestMerge(masses, Ref(0.0))
        val keepIndex = bestPair.a
        val mergeIndex = bestPair.b
        val selectedElements = elements.filter { e -> e.selected }
        val elementKeepIndex = selectedElements[keepIndex].index
        val elementMergeIndex = selectedElements[mergeIndex].index

        for (dependent in paletteRun.findDependentSprites(model)) {
            var items: List<ISpriteRun> = listOf(dependent)
            if (dependent is LzTilesetRun) items = dependent.findDependentTilemaps(model)
            for (sprite in items) {
                var newSprite = sprite
                var j = 0
                while (j < newSprite.pages) {
                    val pixels = newSprite.getPixels(model, j, -1)
                    if (pixels != null) {
                        for (x in 0 until pixels.getLength(0)) {
                            for (y in 0 until pixels.getLength(1)) {
                                if (pixels[x][y] == elementMergeIndex + pageOffset) pixels[x][y] = elementKeepIndex + pageOffset
                            }
                        }
                        newSprite = newSprite.setPixels(model, hist.currentChange, j, pixels)
                    }
                    j++
                }
                if (newSprite.start != sprite.start) {
                    tab?.raiseMessage("Sprite was moved to " + newSprite.start.toHex(6) + ". Pointers were updated.")
                    val currentViewPort = tab as? IViewPort
                    if (currentViewPort != null) {
                        currentViewPort.goto?.execute(newSprite.start)
                    }
                }
            }
        }

        elements[elementKeepIndex].color = (masses[keepIndex] + masses[mergeIndex]).resultColor
        elements[elementMergeIndex].color = 0.toShort()
        pushColorsToModel()
    }
    private fun canExecuteSingleReduce(): Boolean { /*@DONE PaletteCollection.CanExecuteSingleReduce/1 cs:533-533*/
        return model != null && elements.count { element -> element.selected } > 1
    }
    private fun executeDelete() { /*@DONE PaletteCollection.ExecuteDelete/1 cs:535-540*/
        for (i in 0 until elements.size) {
            if (elements[i].selected) elements[i].color = 0.toShort()
        }
        pushColorsToModel()
    }
    companion object {
        fun parseColor(stream: String): List<Short>? { /*@DONE PaletteCollection.ParseColor/1 cs:385-418*/
            val results = ArrayList<Short>()
            val parts = stream.split(' ').filter { part -> part.isNotEmpty() }
            if (parts.size == 64 && (0 until 16).all { k -> parts[k * 4 + 3] == "00" } && (0 until 64).all { k -> parts[k].length == 2 }) {
                // .pal paste
                for (i in 0 until 16) {
                    val blue = Ref(0)
                    val green = Ref(0)
                    val red = Ref(0)
                    if (!tryParseHexInt(parts[i * 4 + 0], blue) || blue.value > 255) return null
                    if (!tryParseHexInt(parts[i * 4 + 1], green) || green.value > 255) return null
                    if (!tryParseHexInt(parts[i * 4 + 2], red) || red.value > 255) return null
                    results.add(UncompressedPaletteColor.pack(red.value shr 3, green.value shr 3, blue.value shr 3))
                }
                return results
            }

            var i = 0
            while (i < parts.size) {
                if (parts[i].contains(":")) {
                    val channels = parts[i].split(':')
                    if (channels.size != 3) return null
                    val red = Ref(0)
                    val green = Ref(0)
                    val blue = Ref(0)
                    if (!tryParseInt(channels[0], red) || !tryParseInt(channels[1], green) || !tryParseInt(channels[2], blue)) return null
                    results.add(UncompressedPaletteColor.pack(red.value, green.value, blue.value))
                } else if (parts[i].length == 4) {
                    val color = Ref(0)
                    if (!tryParseHexInt(parts[i], color)) return null
                    results.add(color.value.toShort())
                } else if (parts[i].length == 2 && i + 1 < parts.size && parts[i + 1].length == 2) {
                    val low = Ref(0)
                    val high = Ref(0)
                    if (!tryParseHexInt(parts[i + 0], low) || low.value > 255) return null
                    if (!tryParseHexInt(parts[i + 1], high) || high.value > 255) return null
                    i += 1
                    results.add(((high.value shl 8) or low.value).toShort())
                } else {
                    return null
                }
                i++
            }
            return results
        }
        /*@END PaletteCollection.Companion*/
    }
    /*@END PaletteCollection*/
}

open class SelectableColor : ViewModelCore() { // cs:546-555
    private var _selected: Boolean = false
    var selected: Boolean
        get() { /*@DONE SelectableColor.Selected.get cs:548-548*/
            return _selected
        }
        set(value) { /*@DONE SelectableColor.Selected.set cs:548-548*/
            tryUpdate(_selected, value, "selected", { _selected = it })
        }
    private var _color: Short = 0.toShort()
    var color: Short
        get() { /*@DONE SelectableColor.Color.get cs:551-551*/
            return _color
        }
        set(value) { /*@DONE SelectableColor.Color.set cs:551-551*/
            tryUpdate(_color, value, "color", { _color = it })
        }
    private var _index: Int = 0
    var index: Int
        get() { /*@DONE SelectableColor.Index.get cs:554-554*/
            return _index
        }
        set(value) { /*@DONE SelectableColor.Index.set cs:554-554*/
            tryUpdate(_index, value, "index", { _index = it })
        }
    /*@END SelectableColor*/
}

data class PaletteCollectionHandleMoveTuple(val index: Int, val direction: Int)
