// Port of Models/Runs/Sprites/Sprites.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

class SpriteFormat { // cs:7-30
    var bitsPerPixel: Int = 0
        private set
    var tileWidth: Int = 0
        private set
    var tileHeight: Int = 0
        private set
    var expectedByteLength: Int = 0
        private set
    var paletteHint: String? = null
        private set
    var allowLengthErrors: Boolean = false
        private set
    constructor(bitsPerPixel: Int, width: Int, height: Int, paletteHint: String?, allowLengthErrors: Boolean = false) { /*@DONE SpriteFormat.<init>/1 cs:14-19*/
        this.bitsPerPixel = bitsPerPixel
        this.tileWidth = width
        this.tileHeight = height
        this.paletteHint = paletteHint ?: ""
        this.expectedByteLength = 8 * bitsPerPixel * tileWidth * tileHeight
        this.allowLengthErrors = allowLengthErrors
    }
    override fun equals(obj: Any?): Boolean { /*@DONE SpriteFormat.Equals/1 cs:20-29*/
        if (obj !is SpriteFormat) return false
        return bitsPerPixel == obj.bitsPerPixel &&
            tileWidth == obj.tileWidth &&
            tileHeight == obj.tileHeight &&
            expectedByteLength == obj.expectedByteLength &&
            paletteHint == obj.paletteHint &&
            allowLengthErrors == obj.allowLengthErrors
    }
    constructor()
    /*@ADD SpriteFormat#runs_10.txt*/
    override fun hashCode(): Int {
        var h = 17
        h = h * 31 + bitsPerPixel
        h = h * 31 + tileWidth
        h = h * 31 + tileHeight
        h = h * 31 + expectedByteLength
        h = h * 31 + (paletteHint?.hashCode() ?: 0)
        h = h * 31 + (if (allowLengthErrors) 1 else 0)
        return h
    }
    /*@ENDADD SpriteFormat#runs_10.txt*/
    /*@END SpriteFormat*/
}

class PaletteFormat { // cs:32-40
    var bits: Int = 0
        private set
    var initialBlankPages: Int = 0
        private set
    var pages: Int = 0
        private set
    var allowLengthErrors: Boolean = false
        private set
    val expectedByteLengthPerPage: Int
        get() { /*@DONE PaletteFormat.ExpectedByteLengthPerPage.get cs:37-37*/
            return Math.pow(2.0, (bits + 1).toDouble()).toInt()
        }
    constructor(bits: Int, pages: Int, initialBlankPages: Int = 0, allowLengthErrors: Boolean = false) { /*@DONE PaletteFormat.<init>/1 cs:39-39*/
        this.bits = bits
        this.pages = pages
        this.initialBlankPages = initialBlankPages
        this.allowLengthErrors = allowLengthErrors
    }
    constructor()
    override fun equals(other: Any?): Boolean = other is PaletteFormat && bits == other.bits && initialBlankPages == other.initialBlankPages && pages == other.pages && allowLengthErrors == other.allowLengthErrors
    override fun hashCode(): Int { var h = 17; h = h * 31 + (bits as Any?).hashCode(); h = h * 31 + (initialBlankPages as Any?).hashCode(); h = h * 31 + (pages as Any?).hashCode(); h = h * 31 + (allowLengthErrors as Any?).hashCode(); return h }
    /*@END PaletteFormat*/
}

class TilesetFormat { // cs:42-50
    var bitsPerPixel: Int = 0
        private set
    var tiles: Int = 0
        private set
    var maxTiles: Int = 0
        private set
    var paletteHint: String? = null
        private set
    var allowLengthErrors: Boolean = false
        private set
    constructor(bitsPerPixel: Int, paletteHint: String?, allowLengthErrors: Boolean = false) { /*@DONE TilesetFormat.<init>/1 cs:48-48*/
        this.bitsPerPixel = bitsPerPixel
        this.tiles = -1
        this.maxTiles = -1
        this.paletteHint = paletteHint
        this.allowLengthErrors = allowLengthErrors
    }
    constructor(bitsPerPixel: Int, tiles: Int, maxTiles: Int, paletteHint: String?, allowLengthErrors: Boolean = false) : this(bitsPerPixel, paletteHint, allowLengthErrors) { /*@DONE TilesetFormat.<init>/2 cs:49-49*/
        this.tiles = tiles
        this.maxTiles = maxTiles
    }
    constructor()
    override fun equals(other: Any?): Boolean = other is TilesetFormat && bitsPerPixel == other.bitsPerPixel && tiles == other.tiles && maxTiles == other.maxTiles && paletteHint == other.paletteHint && allowLengthErrors == other.allowLengthErrors
    override fun hashCode(): Int { var h = 17; h = h * 31 + (bitsPerPixel as Any?).hashCode(); h = h * 31 + (tiles as Any?).hashCode(); h = h * 31 + (maxTiles as Any?).hashCode(); h = h * 31 + (paletteHint as Any?).hashCode(); h = h * 31 + (allowLengthErrors as Any?).hashCode(); return h }
    /*@END TilesetFormat*/
}

class TilemapFormat { // cs:52-68
    var bitsPerPixel: Int = 0
        private set
    var tileWidth: Int = 0
        private set
    var tileHeight: Int = 0
        private set
    val expectedUncompressedLength: Int
        get() { /*@DONE TilemapFormat.ExpectedUncompressedLength.get cs:56-56*/
            return tileWidth * tileHeight * 2 // TODO handle BitsPerPixel
        }
    var matchingTileset: String = ""
        private set
    var tilesetTableMember: String? = null
        private set
    var allowLengthErrors: Boolean = false
        private set
    constructor(bits: Int, width: Int, height: Int, tileset: String?, tilesetTableMember: String? = null, allowLengthErrors: Boolean = false) { /*@DONE TilemapFormat.<init>/1 cs:60-67*/
        bitsPerPixel = bits
        tileWidth = width
        tileHeight = height
        matchingTileset = tileset ?: ""
        this.tilesetTableMember = tilesetTableMember
        this.allowLengthErrors = allowLengthErrors
    }
    constructor()
    override fun equals(other: Any?): Boolean = other is TilemapFormat && bitsPerPixel == other.bitsPerPixel && tileWidth == other.tileWidth && tileHeight == other.tileHeight && matchingTileset == other.matchingTileset && tilesetTableMember == other.tilesetTableMember && allowLengthErrors == other.allowLengthErrors
    override fun hashCode(): Int { var h = 17; h = h * 31 + (bitsPerPixel as Any?).hashCode(); h = h * 31 + (tileWidth as Any?).hashCode(); h = h * 31 + (tileHeight as Any?).hashCode(); h = h * 31 + (matchingTileset as Any?).hashCode(); h = h * 31 + (tilesetTableMember as Any?).hashCode(); h = h * 31 + (allowLengthErrors as Any?).hashCode(); return h }
    /*@END TilemapFormat*/
}

interface IPagedRun : IAppendToBuilderRun { // cs:70-72
    val pages: Int
    /*@END IPagedRun*/
}

interface ISpriteRun : IPagedRun { // cs:74-84
    val supportsImport: Boolean
    val supportsEdit: Boolean
    val spriteFormat: SpriteFormat
    val decompressedLength: Int
    fun getPixels(model: IDataModel, page: Int, tableIndex: Int): Array<IntArray>?
    fun setPixels(model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>): ISpriteRun
    fun setPixels(model: IDataModel, token: ModelDelta, tiles: List<Array<IntArray>>): ISpriteRun
    fun duplicate(newFormat: SpriteFormat): ISpriteRun
    fun getData(): ByteArray
    /*@END ISpriteRun*/
}

interface IPaletteRun : IPagedRun { // cs:86-91
    val paletteFormat: PaletteFormat
    fun getPalette(model: IDataModel, page: Int): List<Short>?
    fun setPalette(model: IDataModel, token: ModelDelta, page: Int, colors: List<Short>): IPaletteRun
    fun duplicate(newFormat: PaletteFormat): IPaletteRun
    /*@END IPaletteRun*/
}

fun IPaletteRun.allColors(model: IDataModel): List<Short>? { /*@DONE IPaletteRunExtensions.AllColors/1 cs:94-101*/
    if (paletteFormat.bits == 8) return getPalette(model, 0)
    val collection = ArrayList<Short>()

    for (i in 0 until pages) {
        val pagePalette = getPalette(model, i)
        if (pagePalette != null) collection.addAll(pagePalette)
    }

    return collection
}
fun ISpriteRun?.findRelatedPalettes(model: IDataModel, primarySource: Int = -1, hint: String? = null, includeAllTableIndex: Boolean = false): List<IPaletteRun> { /*@DONE IPaletteRunExtensions.FindRelatedPalettes/1 cs:111-207*/
    val spriteRun = this
    // find all palettes that could be applied to this sprite run
    val noChange = NoDataChangeDeltaModel()
    val results = ArrayList<IPaletteRun>()
    if (spriteRun != null && spriteRun.spriteFormat.bitsPerPixel < 4) return results // 1- and 2-bit sprites don't have palettes
    var hintText: String? = hint ?: spriteRun?.spriteFormat?.paletteHint
    var primary = primarySource
    if (primary == -1) {
        val spriteSources = spriteRun?.pointerSources
        val pointerCount = spriteSources?.size ?: 0
        for (i in 0 until pointerCount) {
            if (model.getNextRun(spriteSources!![i]) !is ArrayRun) continue
            primary = spriteSources[i]
            break
        }
    }
    val spriteTable = model.getNextRun(primary) as? ITableRun
    var offset = spriteTable?.convertByteOffsetToArrayOffset(primary) ?: ArrayOffset(-1, -1, -1, -1)
    if (primary < 0) offset = ArrayOffset(-1, -1, -1, -1)

    // if the current hint is a palette table and a matched value (like id=1104) and the spriteTable is a single-element table,
    // we need to check for a field with a name that matches the hint field and possibly update
    if (hintText != null && hintText.contains(":") && hintText.contains("=") && spriteTable != null && spriteTable.elementCount == 1) {
        val hintFieldPart = hintText.split(":")[1].split("=")[0]
        val hintField = spriteTable.elementContent.map { seg -> seg.name }.firstOrNull { seg -> seg.contains(hintFieldPart) }
        if (hintField != null) {
            val table = ModelTable(model, spriteTable)
            val hintValue = table[0].getValue(hintField)
            hintText = hintText.split("=")[0] + "=" + hintValue.toHex(4)
        }
    }

    if (!hintText.isNullOrEmpty()) {
        val address = model.getAddressFromAnchor(noChange, -1, hintText)
        val run = model.getNextRun(address)
        if (run is IPaletteRun && run.start == address) {
            // option 1: hint is to a palette
            results.add(run)
            return results
        } else if (run is ArrayRun && run.elementContent.size == 1 && run.elementContent[0] is ArrayRunEnumSegment) {
            val enumArray = run
            val enumSegment = run.elementContent[0] as ArrayRunEnumSegment
            // option 2: hint is to index into paletteTable, and I'm in a table
            val paletteTable = model.getNextRun(model.getAddressFromAnchor(noChange, -1, enumSegment.enumName)) as? ITableRun
            if (offset.elementIndex != -1 && paletteTable != null) {
                val paletteIndex = model.readMultiByteValue(enumArray.start + enumArray.elementLength * offset.elementIndex, enumArray.elementLength)
                val destination = model.readPointer(paletteTable.start + paletteTable.elementLength * paletteIndex)
                val tempRun = model.getNextRun(destination)
                if (tempRun is IPaletteRun && tempRun.start == destination) {
                    results.add(tempRun)
                }
            }
        } else if (hintText.contains(":")) {
            // option 3: hint is a table name, followed by a identifier=value pair
            val tableKeyPair = hintText.split(':')
            val identifierValuePair: List<String> = if (tableKeyPair.size == 2) tableKeyPair[1].split("=").toList() else emptyList()
            if (identifierValuePair.size == 2) {
                val paletteTable = model.getNextRun(model.getAddressFromAnchor(noChange, -1, tableKeyPair[0])) as? ITableRun
                val segment = paletteTable?.elementContent?.firstOrNull { seg -> seg.name == identifierValuePair[0] }
                var pSegment = paletteTable?.elementContent?.firstOrNull { seg -> seg is ArrayRunPointerSegment && PaletteRun.tryParsePaletteFormat(seg.innerFormat, Ref(PaletteFormat())) }
                if (pSegment == null) pSegment = paletteTable?.elementContent?.firstOrNull { seg -> seg is ArrayRunPointerSegment && LzPaletteRun.tryParsePaletteFormat(seg.innerFormat, Ref(PaletteFormat())) }
                val rawValue = identifierValuePair[1]
                val keyValueRef = Ref(0)
                if (segment is ArrayRunEnumSegment) {
                    keyValueRef.value = segment.getOptions(model).toList().indexOf(rawValue)
                } else if (segment is ArrayRunHexSegment) {
                    tryParseHexInt(rawValue, keyValueRef)
                } else {
                    tryParseInt(rawValue, keyValueRef)
                }
                val keyValue = keyValueRef.value
                if (segment != null && paletteTable != null) {
                    val segmentOffset = paletteTable.elementContent.until { seg -> seg === segment }.sumOf { seg -> seg.length }
                    val pSegmentOffset = paletteTable.elementContent.until { seg -> seg === pSegment }.sumOf { seg -> seg.length }
                    val tableIndex = paletteTable.elementCount.range().firstOrNull { i -> model.readMultiByteValue(paletteTable.start + i * paletteTable.elementLength + segmentOffset, segment.length) == keyValue } ?: 0
                    val paletteStart = model.readPointer(paletteTable.start + tableIndex * paletteTable.elementLength + pSegmentOffset)
                    val pRun = model.getNextRun(paletteStart)
                    if (pRun is IPaletteRun && pRun.start == paletteStart) results.add(pRun)
                }
            }
        }

        // option 4: I'm in a table, and my hint is a table name
        if (offset.elementIndex == -1) return results
        if (run !is ArrayRun) return results
        results.addAll(model.getPointedChildren<IPaletteRun>(run, offset.elementIndex))
    } else if (spriteTable != null) {
        // option 5: this sprite is in an array, so get all palettes in all related arrays
        if (spriteTable is ArrayRun) {
            for (relatedTable in IPaletteRunExtensions.getLengthSortedRelatedArrays(model, spriteTable)) {
                if (relatedTable === spriteTable) continue // skip self, I'll handle my own relation later
                results.addAll(model.getPointedChildren<IPaletteRun>(relatedTable, offset.elementIndex))
            }
        }
        // this sprite may appear in the table multiple times, with different palettes. Example: potions
        if (includeAllTableIndex) {
            val segStart = offset.segmentStart - offset.elementIndex * spriteTable.elementLength - spriteTable.start
            val spriteStart = spriteRun?.start ?: Int.MIN_VALUE
            for (i in 0 until spriteTable.elementCount) {
                if (model.readPointer(spriteTable.start + spriteTable.elementLength * i + segStart) != spriteStart) continue
                results.addAll(model.getPointedChildren<IPaletteRun>(spriteTable, i))
            }
        } else {
            results.addAll(model.getPointedChildren<IPaletteRun>(spriteTable, offset.elementIndex))
        }
    }
    return results
}
fun IPaletteRun.findDependentSprites(model: IDataModel): List<ISpriteRun> { /*@DONE IPaletteRunExtensions.FindDependentSprites/1 cs:212-310*/
    val results = ArrayList<ISpriteRun>()
    val run = this

    val tableSources = ArrayList<Int>()
    val runSources = run.pointerSources ?: SortedSpan.none<Int>()
    for (i in 0 until runSources.size) {
        if (model.getNextRun(runSources[i]) !is ITableRun) continue
        tableSources.add(runSources[i])
    }

    // part of a table
    if (tableSources.size > 0) {
        for (primarySource in tableSources) {
            val tableRun = model.getNextRun(primarySource) as ITableRun
            val primaryName = model.getAnchorFromAddress(-1, tableRun.start)
            val offset = tableRun.convertByteOffsetToArrayOffset(primarySource)

            // find all sprites within tables of the same length that reference this table or reference nothing at all
            if (tableRun is ArrayRun) {
                for (table in IPaletteRunExtensions.getLengthSortedRelatedArrays(model, tableRun)) {
                    for (segmentIndex in 0 until table.elementContent.size) {
                        val pointerSegment = table.elementContent[segmentIndex] as? ArrayRunPointerSegment ?: continue
                        val spriteRun = model.getNextRun(table.readPointer(model, offset.elementIndex, segmentIndex)) as? ISpriteRun ?: continue
                        if (spriteRun is LzTilemapRun) continue // don't count tilemaps
                        if (spriteRun.spriteFormat.bitsPerPixel != run.paletteFormat.bits) continue // only worry about sprites that could use this palette
                        val paletteHint = spriteRun.spriteFormat.paletteHint
                        if (!paletteHint.isNullOrEmpty() && paletteHint != primaryName && !pointerSegment.innerFormat.endsWith("|" + primaryName + "`")) continue
                        results.add(spriteRun)
                    }
                }
            }

            // if tableRun is used as an enum in indexTable, we care about payload tables with the same length as the index table that have sprites that use the index table as a paletteHint.
            // in that case, we want every sprite from the payload where the index matches the current tableRun index
            if (primaryName.isNotEmpty()) {
                for (indexTable in model.getEnumArrays(primaryName)) {
                    if (indexTable.elementContent.size != 1) continue
                    val indexTableName = model.getAnchorFromAddress(-1, indexTable.start)
                    for (payloadTable in model.getRelatedArrays(indexTable)) {
                        for (segment in payloadTable.elementContent) {
                            val pSegment = segment as? ArrayRunPointerSegment ?: continue
                            var format = SpriteFormat()
                            val sf1 = Ref(SpriteFormat())
                            if (SpriteRun.tryParseSpriteFormat(pSegment.innerFormat, sf1)) format = sf1.value
                            val sf2 = Ref(SpriteFormat())
                            if (LzSpriteRun.tryParseSpriteFormat(pSegment.innerFormat, sf2)) format = sf2.value
                            if (format.bitsPerPixel == 0) continue
                            if (format.paletteHint != indexTableName) continue
                            val elementPartOffset = payloadTable.elementContent.until { content -> content === segment }.sumOf { content -> content.length }
                            val checkLength = minOf(payloadTable.elementCount, indexTable.elementCount)
                            for (i in 0 until checkLength) {
                                val index = model.readMultiByteValue(indexTable.start + indexTable.elementLength * i, indexTable.elementLength)
                                if (offset.elementIndex != index) continue
                                val elementOffset = payloadTable.elementLength * i
                                val destination = model.readPointer(payloadTable.start + elementOffset + elementPartOffset)
                                val spriteRun = model.getNextRun(destination) as? ISpriteRun ?: continue
                                if (spriteRun is LzTilemapRun) continue // don't count tilemaps
                                results.add(spriteRun)
                            }
                        }
                    }
                }

                // look for sprites that specify that they use this palette from this table, found via a key (example: overworld sprites)
                // this is time consuming, so only do it if we haven't found any sprites yet
                if (results.size == 0) {
                    for (sprite in model.all<SpriteRun>() ?: emptyList<SpriteRun>()) {
                        val hint = sprite.spriteFormat.paletteHint
                        if (hint.isNullOrEmpty()) continue
                        val tableKeyPair = hint.split(':')
                        if (tableKeyPair[0] != primaryName) continue
                        val identifierValuePair: List<String> = if (tableKeyPair.size == 2) tableKeyPair[1].split("=").toList() else emptyList()
                        if (identifierValuePair.size != 2) continue
                        val keyName = identifierValuePair[0]
                        val keyValue = identifierValuePair[1]
                        val keyOffset = tableRun.elementContent.until { seg -> seg.name == keyName }.sumOf { seg -> seg.length }
                        if (keyOffset == tableRun.elementLength) continue
                        val keySegment = tableRun.elementContent.first { seg -> seg.name == keyName }
                        val actualValue = model.readMultiByteValue(tableRun.start + tableRun.elementLength * offset.elementIndex + keyOffset, keySegment.length)
                        val expectedValue = Ref(0)
                        if (!tryParseHexInt(keyValue, expectedValue)) continue
                        if (actualValue != expectedValue.value) continue
                        results.add(sprite)
                    }
                }
            }
        }
    }

    // loose
    val name = model.getAnchorFromAddress(-1, run.start)
    if (name.isEmpty()) return results
    for (anchor in model.anchors) {
        val address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, anchor)
        val anchorRun = model.getNextRun(address)
        val spriteRun = anchorRun as? ISpriteRun ?: continue
        if (spriteRun is ITilemapRun) continue // don't count tilemaps
        if (spriteRun.spriteFormat.paletteHint != name) continue
        results.add(spriteRun)
    }

    return results
}
fun ISpriteRun.findDependentTilemaps(model: IDataModel): List<ITilemapRun> { /*@DONE IPaletteRunExtensions.FindDependentTilemaps/1 cs:312-345*/
    val results = ArrayList<ITilemapRun>()
    val tileset = this

    // if the tileset is part of a table, find other tilemaps at the same index in the table
    val tilesetSources = tileset.pointerSources ?: SortedSpan.none<Int>()
    val tableRun = if (tilesetSources.size > 0) model.getNextRun(tilesetSources[0]) as? ArrayRun else null
    if (tableRun != null) {
        val table = tableRun
        val offset = table.convertByteOffsetToArrayOffset(tilesetSources[0])
        for (relatedTable in model.getRelatedArrays(table)) {
            for (spriteRun in model.getPointedChildren<ISpriteRun>(relatedTable, offset.elementIndex)) {
                val tableName = model.getAnchorFromAddress(-1, table.start)

                // we only care about tilemaps that specifically want _this_ tileset
                val tilemap = spriteRun as? ITilemapRun ?: continue
                if (tilemap.format.matchingTileset != tableName) continue
                if (!tilemap.format.tilesetTableMember.isNullOrEmpty() && tilemap.format.tilesetTableMember != table.elementContent[offset.segmentIndex].name) continue

                results.add(tilemap)
            }
        }
    }

    // if the tileset has a name, find tilemaps that depend on that name
    val tilesetName = model.getAnchorFromAddress(-1, tileset.start)
    if (!tilesetName.isBlank()) {
        for (anchor in model.anchors) {
            val address = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, anchor)
            val anchorRun = model.getNextRun(address)
            val tilemap = anchorRun as? ITilemapRun ?: continue
            if (tilemap.format.matchingTileset != tilesetName) continue
            results.add(tilemap)
        }
    }

    return results
}

object IPaletteRunExtensions { // cs:93-359
    fun getLengthSortedRelatedArrays(model: IDataModel, arrayRun: ArrayRun): MutableList<ArrayRun> { /*@DONE IPaletteRunExtensions.GetLengthSortedRelatedArrays/1 cs:351-358*/
        val relatedArrays = model.getRelatedArrays(arrayRun).toMutableList()

        // sort by name length
        relatedArrays.sortWith { a, b -> model.getAnchorFromAddress(-1, b.start).length - model.getAnchorFromAddress(-1, a.start).length }

        return relatedArrays
    }
    /*@END IPaletteRunExtensions*/
}
