package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import kotlin.reflect.KProperty

// Port of ViewModels/ViewModelCore.cs. See PORTING.md "Properties and change notification" for how C# property
// setters (TryUpdate / Set / [CallerMemberName]) translate.

/** `ExtendedPropertyChangedEventArgs<T>`: a PropertyChanged notification that also carries the old value. */
class ExtendedPropertyChangedEventArgs<T>(val oldValue: T, propertyName: String?) : PropertyChangedEventArgs(propertyName)

/** Extensions of PropertyChangedEventHandler (C# static class PropertyChangedEventHandlerExtensions). */
object PropertyChangedEventHandlerExtensions {
    /** `viewModel.Bind(propertyName, handler)`: calls [handler] whenever that property changes. Dispose to unbind. */
    fun <T : INotifyPropertyChanged> bind(viewModel: T, propertyName: String, handler: (T, PropertyChangedEventArgs) -> Unit): IDisposable {
        val watcher: (Any?, PropertyChangedEventArgs) -> Unit = { sender, e ->
            if (propertyName == e.propertyName) {
                @Suppress("UNCHECKED_CAST")
                handler(sender as T, e)
            }
        }
        viewModel.propertyChanged += watcher
        return StubDisposable { viewModel.propertyChanged -= watcher }
    }
}

/** `viewModel.Bind(propertyName, handler)` extension. */
fun <T : INotifyPropertyChanged> T.bind(propertyName: String, handler: (T, PropertyChangedEventArgs) -> Unit): IDisposable =
    PropertyChangedEventHandlerExtensions.bind(this, propertyName, handler)

/**
 * Represents a superset of property notifiers with functionality to temporarily turn notifications off.
 * This makes them less noisy in situations where a massive number of notifications are happening.
 */
interface ICanSilencePropertyNotifications : INotifyPropertyChanged {
    fun silencePropertyNotifications(): IDisposable
}

/**
 * Utility base-class that adds the PropertyChanged event and adds protected methods to simplify calling it.
 * It also adds protected methods to simplify the creation of commands.
 */
open class ViewModelCore : ICanSilencePropertyNotifications {
    override val propertyChanged: Event<PropertyChangedEventArgs> = Event()

    private var deferCount = 0
    private var deferredPropertyNotifications: MutableSet<String>? = null

    private val silenceScopes = ArrayDeque<MutableList<IDisposable>>()
    private val silentChildren = ArrayList<ICanSilencePropertyNotifications>()

    protected fun addSilentChild(child: ICanSilencePropertyNotifications) {
        silentChildren.add(child)
        if (silenceScopes.isNotEmpty()) {
            silenceScopes.last().add(child.silencePropertyNotifications())
        }
    }

    protected fun removeSilentChild(child: ICanSilencePropertyNotifications) {
        silentChildren.remove(child)
    }

    protected fun clearSilentChildren() {
        silentChildren.clear()
    }

    override fun silencePropertyNotifications(): IDisposable {
        deferCount += 1
        silenceScopes.addLast(silentChildren.map { it.silencePropertyNotifications() }.toMutableList())
        if (deferredPropertyNotifications == null) deferredPropertyNotifications = LinkedHashSet()
        return StubDisposable {
            deferCount -= 1
            silenceScopes.removeLast().forEach { it.dispose() }
            if (deferCount != 0) {
                deferredPropertyNotifications!!.clear()
            } else {
                deferredPropertyNotifications = null
            }
        }
    }

    fun deferPropertyNotifications(): IDisposable {
        deferCount += 1
        if (deferredPropertyNotifications == null) deferredPropertyNotifications = LinkedHashSet()
        return StubDisposable {
            deferCount -= 1
            if (deferCount == 0) {
                val properties = deferredPropertyNotifications!!.toTypedArray()
                deferredPropertyNotifications = null
                notifyPropertiesChanged(*properties)
            }
        }
    }

    protected fun notifyPropertyChanged(propertyName: String) {
        val deferred = deferredPropertyNotifications
        if (deferred != null) {
            deferred.add(propertyName)
        } else {
            propertyChanged(this, PropertyChangedEventArgs(propertyName))
        }
    }

    /** The oldValue will not be stored / notified if we're deferring property notifications */
    protected fun <T> notifyPropertyChanged(oldValue: T, propertyName: String) {
        val deferred = deferredPropertyNotifications
        if (deferred != null) {
            deferred.add(propertyName)
        } else {
            propertyChanged(this, ExtendedPropertyChangedEventArgs(oldValue, propertyName))
        }
    }

    protected fun notifyPropertiesChanged(vararg propertyNames: String) {
        for (name in propertyNames) notifyPropertyChanged(name)
    }

    protected fun notifyPropertyChanged(args: PropertyChangedEventArgs) {
        propertyChanged(this, args)
    }

    /**
     * Utility function to make writing property updates easier. C#: `set => TryUpdate(ref field, value)`.
     * Kotlin:
     * ```
     * private var foo = 0
     * var foo: Int
     *    get() = foo
     *    set(value) { tryUpdate(foo, value, "foo") { foo = it } }
     * ```
     * If [current] equals [value] nothing happens and false is returned; otherwise [assign] stores the value,
     * PropertyChanged is raised for [propertyName] and true is returned.
     */
    protected fun <T> tryUpdate(current: T, value: T, propertyName: String, assign: (T) -> Unit): Boolean {
        if (current == value) return false
        assign(value)
        notifyPropertyChanged(current, propertyName)
        return true
    }

    /** C# `Set(ref field, value, changeHandler)`: like tryUpdate, then calls [changeHandler] with the old value. */
    protected fun <T> set(current: T, value: T, propertyName: String, assign: (T) -> Unit, changeHandler: ((T) -> Unit)? = null) {
        if (tryUpdate(current, value, propertyName, assign)) changeHandler?.invoke(current)
    }

    /** C# `TryUpdateSequence`: like tryUpdate, but compares two sequences element by element. */
    protected fun <T> tryUpdateSequence(current: List<T>?, value: List<T>?, propertyName: String, assign: (List<T>?) -> Unit): Boolean {
        if (current == null && value == null) return false
        if (current != null && value != null && current == value) return false
        assign(value)
        notifyPropertyChanged(current, propertyName)
        return true
    }

    /**
     * C# `StubCommand(ref field, Action execute, Func<bool> canExecute = null)`. The C# code caches the command in a
     * field; in Kotlin use `val foo: ICommand by lazy { stubCommand({ ... }, { ... }) }`.
     */
    protected fun stubCommand(execute: () -> Unit, canExecute: (() -> Boolean)? = null): StubCommand = StubCommand().also {
        it.execute = { _ -> execute() }
        it.canExecute = { _ -> canExecute?.invoke() ?: true }
    }

    /** C# `StubCommand<T>(ref field, Action<T> execute, Func<T, bool> canExecute = null)`; a null/mismatched argument becomes null. */
    protected fun <T> stubCommandOf(execute: (T?) -> Unit, canExecute: ((T?) -> Boolean)? = null): StubCommand = StubCommand().also {
        @Suppress("UNCHECKED_CAST")
        it.execute = { arg -> execute(arg as? T) }
        @Suppress("UNCHECKED_CAST")
        it.canExecute = { arg -> canExecute?.invoke(arg as? T) ?: true }
    }

    /** C# `Scope(ref field, value, lambda)`: sets the value now and restores the original via [lambda] on dispose. */
    protected fun <T> scope(current: T, value: T, assign: (T) -> Unit, lambda: (T) -> Unit): IDisposable {
        val original = current
        val disposable = StubDisposable { lambda(original) }
        assign(value)
        return disposable
    }

    // --- property delegates: `var foo: Int by notifying(0)` is the whole of C# `set => TryUpdate(ref foo, value)` ---

    /** Property delegate that stores a value and raises PropertyChanged (with the old value) when it changes. */
    protected fun <T> notifying(initial: T, changeHandler: ((T) -> Unit)? = null): NotifyingProperty<T> = NotifyingProperty(initial, changeHandler)

    class NotifyingProperty<T>(private var value: T, private val changeHandler: ((T) -> Unit)?) {
        operator fun getValue(thisRef: ViewModelCore, property: KProperty<*>): T = value

        operator fun setValue(thisRef: ViewModelCore, property: KProperty<*>, newValue: T) {
            val old = value
            if (old == newValue) return
            value = newValue
            thisRef.notifyPropertyChanged(old, property.name)
            changeHandler?.invoke(old)
        }
    }
}
