// Port of ViewModels/Map/MapScriptCollection.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

data class NewMapScriptsCreatedEventArgs(val address: Int) { // cs:10-10
    /*@END NewMapScriptsCreatedEventArgs*/
}

open class MapScriptCollection : ViewModelCore { // cs:12-112
    private lateinit var viewPort: IEditableViewPort
    private lateinit var eventTemplate: EventTemplate
    private var owner: ModelArrayElement? = null
    private var _address: Int = 0
    val address: Int
        get() { /*@DONE MapScriptCollection.Address.get cs:18-18*/
            return _address
        }
    val unloaded: Boolean
        get() { /*@DONE MapScriptCollection.Unloaded.get cs:19-19*/
            return _address == 0
        }
    var scripts: ObservableCollection<MapScriptViewModel> = /*@INITDONE MapScriptCollection.Scripts cs:20-20*/ ObservableCollection() /*@ENDINIT*/
        private set
    val collectionExists: Boolean
        get() { /*@DONE MapScriptCollection.CollectionExists.get cs:21-21*/
            return _address > 0
        }
    var allowAddMoreScripts: Boolean = /*@INITAUTO MapScriptCollection.AllowAddMoreScripts cs:22-22*/ true /*@ENDINIT*/
        private set
    val newMapScriptsCreated = Event<NewMapScriptsCreatedEventArgs>()
    constructor(viewPort: IEditableViewPort, eventTemplate: EventTemplate) { /*@DONE MapScriptCollection.<init>/1 cs:26-26*/
        this.viewPort = viewPort
        this.eventTemplate = eventTemplate
    }
    fun load(owner: ModelArrayElement?) { /*@DONE MapScriptCollection.Load/1 cs:29-50*/
        for (script in scripts) script.deleteMe -= deleteHandler
        scripts.clear()
        this.owner = owner
        if (owner == null) return
        _address = owner.getAddress("mapscripts")
        if (_address == Pointer.null_) return
        val model = viewPort.model!!
        var scriptStart = _address
        allowAddMoreScripts = true
        while (model[scriptStart] != 0) {
            if (scripts.size == 10) {
                scripts.add(MapScriptViewModel(viewPort, eventTemplate, Pointer.null_)) // 'UI is full' sentinel
                allowAddMoreScripts = false
                break
            }
            scripts.add(MapScriptViewModel(viewPort, eventTemplate, scriptStart))
            addDeleteHandler(scripts.size - 1)
            scriptStart += 5
        }
        notifyPropertiesChanged("collectionExists", "unloaded", "address", "allowAddMoreScripts")
    }
    val canCreateCollection: Boolean
        get() { /*@DONE MapScriptCollection.CanCreateCollection.get cs:52-52*/
            return _address < 0
        }
    fun createCollection() { /*@DONE MapScriptCollection.CreateCollection/1 cs:53-62*/
        val model = viewPort.model!!
        val token = viewPort.changeHistory.currentChange
        val start = model.findFreeSpace(model.freeSpaceStart, 1)
        token.changeData(model, start, 0x00)
        _address = start
        owner!!.setAddress("mapscripts", _address)
        scripts.clear()
        notifyPropertiesChanged("unloaded", "collectionExists", "address")
    }
    fun getScriptsOf(): List<Int> { /*@DONE MapScriptCollection.GetScripts/1 cs:64-68*/
        val results = ArrayList<Int>()
        for (child in scripts) results.addAll(child.getScripts())
        return results
    }
    fun addScript() { /*@DONE MapScriptCollection.AddScript/1 cs:70-88*/
        val token = viewPort.changeHistory.currentChange
        val model = viewPort.model!!
        var run = model.getNextRun(_address) as? ITableRun
        if (run == null) return
        val originalRun = run
        run = model.relocateForExpansion(token, run, run.length + 5)
        if (originalRun.start != run.start) viewPort.raiseMessage("Repointed data from " + originalRun.start.toAddress() + " to " + run.start.toAddress() + ".")
        run = run.append(token, 1)
        _address = run.start
        val newScript = model.findFreeSpace(model.freeSpaceStart, 1)
        token.changeData(model, newScript, 0x02) // `end`
        token.changeData(model, run.start + run.length - 6, 1) // script-type 1
        model.updateArrayPointer(token, null, null, 0, run.start + run.length - 5, newScript)
        model.observeRunWritten(token, run)
        model.observeRunWritten(token, XSERun(newScript))
        viewPort.changeHistory.changeCompleted()
        load(owner) // do a full reload, in case we need to truncate scripts
    }
    private fun addDeleteHandler(index: Int) { /*@DONE MapScriptCollection.AddDeleteHandler/1 cs:90-92*/
        scripts[index].deleteMe += deleteHandler
    }
    private fun handleDelete(sender: Any, e: MapScriptDeleteEventArgs) { /*@DONE MapScriptCollection.HandleDelete/1 cs:94-111*/
        val model = viewPort.model!!
        val token = viewPort.changeHistory.currentChange
        val script = sender as MapScriptViewModel
        val index = scripts.indexOf(script)
        var tableRun = model.getNextRun(_address) as? ITableRun
        if (tableRun == null) return
        val table = ModelTable(model, tableRun, { token }) // type. pointer<>
        for (i in index until table.size - 1) {
            table[i].setValue(0, table[i + 1].getValue(0))
            table[i].setAddress("pointer", table[i + 1].getAddress("pointer"))
        }
        tableRun = tableRun.append(token, -1)
        model.observeRunWritten(token, tableRun)
        e.success = true
        viewPort.changeHistory.changeCompleted()
        load(owner) // do a reload, in case we were truncating scripts.
    }
    /*@ADD MapScriptCollection#mapscripts.txt*/
    private val deleteHandler: (Any?, MapScriptDeleteEventArgs) -> Unit = { s, e -> handleDelete(s!!, e) }
    /*@ENDADD MapScriptCollection#mapscripts.txt*/
    /*@END MapScriptCollection*/
}

open class MapScriptDeleteEventArgs : EventArgs() { // cs:114-116
    var success: Boolean = false
    /*@END MapScriptDeleteEventArgs*/
}

open class MapScriptViewModel : ViewModelCore { // cs:118-335
    private lateinit var viewPort: IEditableViewPort
    private lateinit var eventTemplate: EventTemplate
    private var start: Int = 0
    private var scriptType: Int = 0
    private var _address: Int = 0
    private var displayAddress: String = ""
    val deleteMe = Event<MapScriptDeleteEventArgs>()
    val hasSubScripts: Boolean
        get() { /*@DONE MapScriptViewModel.HasSubScripts.get cs:127-127*/
            return scriptType == 2 || scriptType == 4
        }
    var moreScriptsTruncated: Boolean = /*@INITAUTO MapScriptViewModel.MoreScriptsTruncated cs:128-128*/ false /*@ENDINIT*/
        private set
    val showMapScript: Boolean
        get() { /*@DONE MapScriptViewModel.ShowMapScript.get cs:129-129*/
            return !moreScriptsTruncated
        }
    var scriptOptions: ObservableCollection<VisualOption> = /*@INITDONE MapScriptViewModel.ScriptOptions cs:131-131*/ ObservableCollection() /*@ENDINIT*/
        private set
    var subScripts: ObservableCollection<MapSubScriptViewModel> = /*@INITDONE MapScriptViewModel.SubScripts cs:132-132*/ ObservableCollection() /*@ENDINIT*/
        private set
    constructor(viewPort: IEditableViewPort, eventTemplate: EventTemplate, start: Int) { /*@DONE MapScriptViewModel.<init>/1 cs:134-182*/
        this.viewPort = viewPort
        this.eventTemplate = eventTemplate
        val model = viewPort.model!!
        this.start = start
        if (start == Pointer.null_) {
            moreScriptsTruncated = true
            return
        }
        this.scriptType = model[start]
        this._address = model.readPointer(start + 1)
        this.displayAddress = "<" + _address.toHex(6) + ">"
        load()
        scriptOptions.add(VisualOption().apply {
            option = "Load"
            shortDescription = "Before layout is drawn"
            description = "Almost exclusively used to set metatiles on the map before it's first drawn"
        })
        scriptOptions.add(VisualOption().apply {
            option = "Per-Frame (Table)"
            shortDescription = "Run every frame"
            description = "Only the first script whose condition is satisfied is run. Used to trigger events."
        })
        scriptOptions.add(VisualOption().apply {
            option = "Transition"
            shortDescription = "Run when switching maps"
            description = "Used to set map-specific flags/vars, update object positions/movement types, set weather, etc"
        })
        scriptOptions.add(VisualOption().apply {
            option = "Warp into Map (Table)"
            shortDescription = "Run after objects are loaded"
            description = "Only the first script whose condition is satisfied is run. Used to update facing / visibility or to add objects to the scene."
        })
        scriptOptions.add(VisualOption().apply {
            option = "Resume"
            shortDescription = "Run after loading the map, or exiting the bag, or finishing a battle, etc"
            description = "Used to hide defeated static pokemon, or maintain some map state"
        })
        scriptOptions.add(VisualOption().apply {
            option = "Dive Warp"
            shortDescription = "Run after the player dives or emerges"
            description = "Only used to determine whether the player should emerge in the sealed chamber."
        })
        scriptOptions.add(VisualOption().apply {
            option = "Return to Field"
            shortDescription = "Run after exiting bag or finishing battle, but not when entering a map"
            description = "Used rarely, when something must only happen on reload."
        })
    }
    private fun load() { /*@DONE MapScriptViewModel.Load/1 cs:186-210*/
        val model = viewPort.model!!
        subScripts.clear()
        val token = NoDataChangeDeltaModel()
        if (scriptType != 2 && scriptType != 4) {
            // we're pointing at an XSERun
            val nextRun = model.getNextRun(_address)
            if (nextRun == null || nextRun.start >= _address) {
                model.observeRunWritten(token, XSERun(_address))
            }
        } else {
            var destination = _address
            while (true) {
                val currentValue = model.readMultiByteValue(destination, 2)
                if (currentValue == 0 || currentValue == 0xFFFF) break
                val child = MapSubScriptViewModel(viewPort, eventTemplate, destination)
                child.deleteMe += handleDeleteHandler
                subScripts.add(child)
                destination += 8
            }
            val runRef = Ref<ITableRun?>(null)
            if (!ArrayRun.tryParse(model, "[variable:|h value: pointer<`xse`>]!0000", _address, SortedSpanStatic.one(start + 1), runRef).hasError) {
                val run = runRef.value!!
                model.clearFormat(token, run.start, run.length)
                model.observeRunWritten(token, run)
            }
        }
    }
    var scriptTypeIndex: Int
        get() { /*@DONE MapScriptViewModel.ScriptTypeIndex.get cs:213-213*/
            return scriptType - 1
        }
        set(value) { /*@DONE MapScriptViewModel.ScriptTypeIndex.set cs:214-250*/
            set(scriptType, value + 1, "scriptTypeIndex", { scriptType = it }) { arg ->
                notifyPropertyChanged("hasSubScripts")
                val model = viewPort.model!!
                val token = viewPort.changeHistory.currentChange
                if ((arg == 2 || arg == 4) && (scriptType != 2 && scriptType != 4)) {
                    // if the old type is 2 or 4 and the new type is not, delete the content and replace it with a new 1-byte script `end` (02)
                    val destination: Int
                    if (subScripts.size == 0) {
                        destination = model.findFreeSpace(model.freeSpaceStart, 2)
                        token.changeData(model, destination, 0x02)
                        model.observeRunWritten(token, XSERun(destination))
                    } else {
                        destination = model.readPointer(subScripts[0].start + 4)
                    }
                    model.updateArrayPointer(token, null, null, -1, this.start + 1, destination)
                    _address = destination
                    this.displayAddress = "<" + _address.toHex(6) + ">"
                    notifyPropertyChanged("address")
                    load()
                } else if ((scriptType == 2 || scriptType == 4) && (arg != 2 && arg != 4)) {
                    // if the new type is 2 or 4 and the old type is not, move the current script to be the first SubScript of the new table
                    val destination = model.findFreeSpace(model.freeSpaceStart, 10)
                    model.writeMultiByteValue(destination + 0, 2, token, 0x4000) // temp0
                    model.writeMultiByteValue(destination + 2, 2, token, 0)      // check = 0
                    // by default, the script will now always run, until you make it stop!
                    model.writePointer(token, destination + 4, _address)
                    model.writeMultiByteValue(destination + 8, 2, token, 0)
                    model.updateArrayPointer(token, null, null, -1, this.start + 1, destination)
                    _address = destination
                    this.displayAddress = "<" + _address.toHex(6) + ">"
                    notifyPropertyChanged("address")
                    load()
                }
                viewPort.changeHistory.currentChange.changeData(viewPort.model!!, start, scriptType)
                notifyPropertyChanged("hasSubScripts")
                viewPort.changeHistory.changeCompleted()
            }
        }
    var address: String
        get() { /*@DONE MapScriptViewModel.Address.get cs:254-254*/
            return displayAddress
        }
        set(value) { /*@DONE MapScriptViewModel.Address.set cs:255-262*/
            set(displayAddress, value, "address", { displayAddress = it }) { arg ->
                val text = displayAddress.trim('<', '>')
                val result = Ref(0)
                if (text.tryParseHex(result)) {
                    _address = result.value
                    viewPort.model!!.updateArrayPointer(viewPort.changeHistory.currentChange, null, null, 0, start + 1, _address)
                    load()
                }
            }
        }
    val scriptAddress: Int
        get() { /*@DONE MapScriptViewModel.ScriptAddress.get cs:265-265*/
            return _address
        }
    fun getScripts(): Collection<Int> { /*@DONE MapScriptViewModel.GetScripts/1 cs:267-276*/
        val results = ArrayList<Int>()
        for (script in subScripts) {
            results.add(viewPort.model!!.readPointer(script.start + 4))
        }
        if (scriptType != 2 && scriptType != 4) {
            results.add(_address)
        }
        return results
    }
    fun addSubScript() { /*@DONE MapScriptViewModel.AddSubScript/1 cs:278-303*/
        val model = viewPort.model!!
        val token = viewPort.changeHistory.currentChange

        val run = model.getNextRun(_address)
        if (run !is ITableRun) return
        var tableRun: ITableRun = run
        val originalRun = tableRun
        tableRun = tableRun.append(token, 1)
        model.observeRunWritten(token, tableRun)
        if (originalRun.start != tableRun.start) viewPort.raiseMessage("Repointed data from " + originalRun.start.toAddress() + " to " + tableRun.start.toAddress() + ".")

        // add new element data
        val newScriptStart = model.findFreeSpace(model.freeSpaceStart, 1)
        token.changeData(model, newScriptStart, 0x02)
        model.updateArrayPointer(token, null, null, -1, tableRun.start + (tableRun.elementCount - 1) * tableRun.elementLength + 4, newScriptStart)
        model.observeRunWritten(token, XSERun(newScriptStart))

        _address = tableRun.start
        displayAddress = "<" + _address.toHex(6) + ">"
        notifyPropertyChanged("address")
        // (the original only reloads when the table moved, and otherwise calls Enumerable.Append, which adds nothing; always reload so the new entry shows up)
        load()
    }
    fun delete() { /*@DONE MapScriptViewModel.Delete/1 cs:305-310*/
        val args = MapScriptDeleteEventArgs()
        deleteMe(this, args)
        if (!args.success) return
        // NOTE maybe we should clear all the data in this script right here
    }
    fun goto() { /*@DONE MapScriptViewModel.Goto/1 cs:312-312*/
        BlockMapViewModel.gotoAddress(viewPort, _address)
    }
    private fun handleDelete(sender: Any, e: MapScriptDeleteEventArgs) { /*@DONE MapScriptViewModel.HandleDelete/1 cs:314-334*/
        val model = viewPort.model!!
        val token = viewPort.changeHistory.currentChange
        val script = sender as MapSubScriptViewModel
        val index = subScripts.indexOf(script)
        if (index == -1) return

        var tableRun = model.getNextRun(_address) as? ITableRun
        if (tableRun == null) return
        val table = ModelTable(model, tableRun, { token }) // type. pointer<>
        for (i in index until subScripts.size - 1) {
            table[i].setValue(0, table[i + 1].getValue(0))
            table[i].setValue(1, table[i + 1].getValue(1))
            table[i].setAddress("pointer", table[i + 1].getAddress("pointer"))
        }
        tableRun = tableRun.append(token, -1)
        model.observeRunWritten(token, tableRun)
        subScripts[index].deleteMe -= handleDeleteHandler
        subScripts.removeAt(index)
        e.success = true
    }
    /*@ADD MapScriptViewModel#mapscripts.txt*/
    private val handleDeleteHandler: (Any?, MapScriptDeleteEventArgs) -> Unit = { s, e -> handleDelete(s!!, e) }
    /*@ENDADD MapScriptViewModel#mapscripts.txt*/
    /*@END MapScriptViewModel*/
}

open class MapSubScriptViewModel : ViewModelCore { // cs:340-404
    private lateinit var viewPort: IEditableViewPort
    private lateinit var eventTemplate: EventTemplate
    private var _start: Int = 0
    private var _variable: Int = 0
    private var val_: Int = 0
    private var _address: Int = 0
    private var variableText: String = ""
    private var valueText: String = ""
    private var addressText: String = ""
    val start: Int
        get() { /*@DONE MapSubScriptViewModel.Start.get cs:346-346*/
            return _start
        }
    val deleteMe = Event<MapScriptDeleteEventArgs>()
    constructor(viewPort: IEditableViewPort, eventTemplate: EventTemplate, start: Int) { /*@DONE MapSubScriptViewModel.<init>/1 cs:350-359*/
        this.viewPort = viewPort
        this.eventTemplate = eventTemplate
        this._start = start
        val model = viewPort.model!!
        this._variable = model.readMultiByteValue(start, 2)
        this.val_ = model.readMultiByteValue(start + 2, 2)
        this._address = model.readPointer(start + 4)

        variableText = _variable.toHex(4)
        valueText = val_.toString()
        addressText = "<" + _address.toHex(6) + ">"
    }
    var variable: String
        get() { /*@DONE MapSubScriptViewModel.Variable.get cs:362-362*/
            return variableText
        }
        set(value) { /*@DONE MapSubScriptViewModel.Variable.set cs:362-367*/
            set(variableText, value, "variable", { variableText = it }) { arg ->
                val result = Ref(0)
                if (variableText.tryParseHex(result)) {
                    _variable = result.value
                    viewPort.model!!.writeMultiByteValue(_start, 2, viewPort.changeHistory.currentChange, _variable)
                    notifyPropertyChanged("canGenerateNewVar")
                }
            }
        }
    var value: String
        get() { /*@DONE MapSubScriptViewModel.Value.get cs:371-371*/
            return valueText
        }
        set(value) { /*@DONE MapSubScriptViewModel.Value.set cs:371-375*/
            set(valueText, value, "value", { valueText = it }) { arg ->
                val result = Ref(0)
                if (valueText.tryParseInt(result)) {
                    val_ = result.value
                    viewPort.model!!.writeMultiByteValue(_start + 2, 2, viewPort.changeHistory.currentChange, val_)
                }
            }
        }
    var address: String
        get() { /*@DONE MapSubScriptViewModel.Address.get cs:379-379*/
            return addressText
        }
        set(value) { /*@DONE MapSubScriptViewModel.Address.set cs:379-385*/
            set(addressText, value, "address", { addressText = it }) { arg ->
                val text = addressText.trim('<', '>', ' ')
                val result = Ref(0)
                if (text.tryParseHex(result)) {
                    // do the same work that we do in the code tool, removing scripts that aren't needed
                    _address = result.value
                    viewPort.model!!.updateArrayPointer(viewPort.changeHistory.currentChange, null, null, -1, _start + 4, _address)
                }
            }
        }
    val scriptAddress: Int
        get() { /*@DONE MapSubScriptViewModel.ScriptAddress.get cs:388-388*/
            return _address
        }
    val canGenerateNewVar: Boolean
        get() { /*@DONE MapSubScriptViewModel.CanGenerateNewVar.get cs:390-390*/
            return _variable == 0
        }
    fun generateNewVar() { /*@DONE MapSubScriptViewModel.GenerateNewVar/1 cs:391-394*/
        _variable = eventTemplate.findNextUnusedVariable()
        variable = _variable.toHex(4)
    }
    fun delete() { /*@DONE MapSubScriptViewModel.Delete/1 cs:396-401*/
        val args = MapScriptDeleteEventArgs()
        deleteMe(this, args)
        if (!args.success) return
        // leaving an orphan behind on purpose
    }
    fun goto() { /*@DONE MapSubScriptViewModel.Goto/1 cs:403-403*/
        BlockMapViewModel.gotoAddress(viewPort, _address)
    }
    /*@END MapSubScriptViewModel*/
}
