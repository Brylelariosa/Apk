// Port of Models/Runs/Factory/PaletteRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class PaletteRunContentStrategy : RunStrategy { // cs:12-49
    private var paletteFormat: PaletteFormat = PaletteFormat()
    constructor(paletteFormat: PaletteFormat) { /*@DONE PaletteRunContentStrategy.<init>/1 cs:14-14*/
        this.paletteFormat = paletteFormat
    }
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE PaletteRunContentStrategy.LengthForNewRun/1 cs:16-16*/
        return paletteFormat.expectedByteLengthPerPage
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE PaletteRunContentStrategy.TryAddFormatAtDestination/1 cs:17-22*/
        val palRun = PaletteRun(destination, paletteFormat, SortedSpan(source))
        // TODO deal with the run being too long?
        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, palRun)
        return true
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE PaletteRunContentStrategy.Matches/1 cs:23-23*/
        return run is PaletteRun && run.formatString == format
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE PaletteRunContentStrategy.WriteNewRun/1 cs:24-28*/
        val length = paletteFormat.expectedByteLengthPerPage
        for (i in 0 until length) token.changeData(owner, destination + i, 0)
        return PaletteRun(destination, paletteFormat)
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE PaletteRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:29-35*/
        val runAttempt = PaletteRun(run.value.start, paletteFormat, run.value.pointerSources)
        var containsSource = false
        val currentSources = run.value.pointerSources
        if (currentSources != null) {
            for (i in 0 until currentSources.size) {
                val source = currentSources[i]
                if (runAttempt.start <= source && source < runAttempt.start + runAttempt.length) containsSource = true
            }
        }
        if (runAttempt.length > 0 && !containsSource) {
            val merged = runAttempt.mergeAnchor(run.value.pointerSources)
            run.value = merged
            model.clearFormat(token, merged.start, merged.length)
        }
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE PaletteRunContentStrategy.TryParseData/1 cs:36-41*/
        val error = isValid(paletteFormat.bits)
        if (error.hasError) return error
        run.value = PaletteRun(dataIndex, paletteFormat, run.value?.pointerSources)
        return ErrorInfo.noError
    }
    companion object {
        fun isValid(bitness: Int): ErrorInfo { /*@DONE PaletteRunContentStrategy.IsValid/1 cs:43-48*/
            if (bitness != 4 && bitness != 8) {
                return ErrorInfo("Palette bpp must be 4 or 8.")
            }
            return ErrorInfo.noError
        }
        /*@END PaletteRunContentStrategy.Companion*/
    }
    /*@END PaletteRunContentStrategy*/
}
