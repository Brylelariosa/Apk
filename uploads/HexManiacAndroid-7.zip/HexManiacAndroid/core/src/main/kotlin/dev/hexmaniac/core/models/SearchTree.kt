// Port of Models/SearchTree.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

interface ISearchTreePayload { // cs:8-10
    val start: Int
    /*@END ISearchTreePayload*/
}

enum class TreeColor(val value: Int) { // cs:12-12
    Red(0),
    Black(1);
    companion object {
        fun fromValue(value: Int): TreeColor = entries.first { it.value == value }
    }
    /*@END TreeColor*/
}

enum class AddType(val value: Int) { // cs:13-13
    Left(0),
    Right(1),
    Balanced(2),
    Insert(3),
    ReplaceExisting(4);
    companion object {
        fun fromValue(value: Int): AddType = entries.first { it.value == value }
    }
    /*@END AddType*/
}

enum class RemoveType(val value: Int) { // cs:14-14
    NoRemoval(0),
    Balanced(1),
    DecreaseBlackCount(2);
    companion object {
        fun fromValue(value: Int): RemoveType = entries.first { it.value == value }
    }
    /*@END RemoveType*/
}

open class SearchTree<T> : Iterable<T> where T : Any, T : ISearchTreePayload { // cs:26-158
    private var root: TreeNode<T>? = null
    var count: Int = 0
        private set
    fun add(element: T) { /*@DONE SearchTree.Add/1 cs:32-34*/
        val r = Ref(root)
        if (TreeNodeStatic.add(r, element)) count++
        root = r.value
    }
    fun remove(start: Int) { /*@DONE SearchTree.Remove/1 cs:36-38*/
        val r = Ref(root)
        if (TreeNodeStatic.remove(r, start)) count--
        root = r.value
    }
    fun clear() { /*@DONE SearchTree.Clear/1 cs:40-43*/
        root = null
        count = 0
    }
    operator fun get(index: Int): SearchPath<T> { /*@DONE SearchTree.this/1.get cs:46-62*/
        val directions = ArrayList<Int>()
        var node = root
        while (node != null) {
            if (index < node.payload.start) {
                directions.add(left)
                node = node.left
            } else if (node.payload.start < index) {
                directions.add(right)
                node = node.right
            } else {
                return SearchPath(this, directions, node.payload)
            }
        }

        // not found
        return SearchPath(this, directions)
    }
    operator fun get(path: SearchPath<T>): T { /*@DONE SearchTree.this/2.get cs:65-65*/
        return path.element!!
    }
    private fun getNodesOnPath(path: Iterable<Int>): MutableList<TreeNode<T>?> { /*@DONE SearchTree.GetNodesOnPath/1 cs:67-78*/
        val results = ArrayList<TreeNode<T>?>()
        var node = root
        results.add(node)
        for (direction in path) {
            node = if (direction == left) node!!.left else node!!.right
            if (node == null) break
            results.add(node)
        }
        return results
    }
    fun startingFrom(index: Int): Iterable<T> { /*@DONE SearchTree.StartingFrom/1 cs:80-82*/
        return root!!.enumerateFrom(index)
    }
    override fun iterator(): Iterator<T> { /*@DONE SearchTree.GetEnumerator/1 cs:84-86*/
        return sequence<T> { for (node in root!!) yield(node.payload) }.iterator()
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    open class SearchPath<T> where T : Any, T : ISearchTreePayload { // cs:90-157
        private var tree: SearchTree<T>? = null
        private var directions: MutableList<Int> = ArrayList()
        val previousElement: T
            get() { /*@DONE SearchTree.SearchPath.PreviousElement.get cs:94-94*/
                return getPrevious()!!.payload
            }
        var element: T? = null
            private set
        val nextElement: T
            get() { /*@DONE SearchTree.SearchPath.NextElement.get cs:96-96*/
                return getNext()!!.payload
            }
        val hasElement: Boolean
            get() { /*@DONE SearchTree.SearchPath.HasElement.get cs:97-97*/
                return element != null
            }
        constructor(tree: SearchTree<T>, directions: MutableList<Int>, element: T? = null) { /*@DONE SearchTree.SearchPath.<init>/1 cs:99-103*/
            this.tree = tree
            this.element = element
            this.directions = directions
        }
        operator fun compareTo(index: Int): Int { /*@DONE SearchTree.SearchPath.op_GreaterThanOrEqual/1 cs:107-110*/
            // C#: `path >= 0` is true when the path points at an element; Kotlin: compareTo(0) >= 0 <=> hasElement
            if (index == 0) return if (hasElement) 0 else -1
            throw NotImplementedException()
        }
        private fun getPrevious(): TreeNode<T>? { /*@DONE SearchTree.SearchPath.GetPrevious/1 cs:124-139*/
            val path = tree!!.getNodesOnPath(directions)
            if (!hasElement && directions.last() == right) return path.last()

            var checkNodeIndex = path.size - 1

            var previous = path[checkNodeIndex]!!.left
            if (previous == null) {
                while (checkNodeIndex > 0 && path[checkNodeIndex - 1]!!.left === path[checkNodeIndex]) checkNodeIndex--
                if (checkNodeIndex == 0) return null
                previous = path[checkNodeIndex - 1]!!.left
            }

            while (previous!!.right != null) previous = previous.right
            return previous
        }
        private fun getNext(): TreeNode<T>? { /*@DONE SearchTree.SearchPath.GetNext/1 cs:141-156*/
            val path = tree!!.getNodesOnPath(directions)
            if (!hasElement && directions.last() == left) return path.last()

            var checkNodeIndex = path.size - 1

            var next = path[checkNodeIndex]!!.right
            if (next == null) {
                while (checkNodeIndex > 0 && path[checkNodeIndex - 1]!!.right === path[checkNodeIndex]) checkNodeIndex--
                if (checkNodeIndex == 0) return null
                next = path[checkNodeIndex - 1]!!.right
            }

            while (next!!.left != null) next = next.left
            return next
        }
        /*@END SearchTree.SearchPath*/
    }
    companion object {
        const val left: Int = 0
        const val right: Int = 1
        /*@END SearchTree.Companion*/
    }
    /*@END SearchTree*/
}

fun <T : ISearchTreePayload> TreeNode<T>?.isBlack(): Boolean { /*@DONE TreeNodeStatic.IsBlack/1 cs:182-182*/
    return (this?.color ?: TreeColor.Black) == TreeColor.Black
}
fun <T : ISearchTreePayload> TreeNode<T>?.blackWithBlackChildren(): Boolean { /*@DONE TreeNodeStatic.BlackWithBlackChildren/1 cs:183-186*/
    if (this == null || this.color == TreeColor.Red) return false
    return this.left.isBlack() && this.right.isBlack()
}

object TreeNodeStatic { // cs:160-187
    fun <T : ISearchTreePayload> from(element: T): TreeNode<T> { /*@DONE TreeNodeStatic.From/1 cs:161-161*/
        return TreeNode(element)
    }
    fun <T : ISearchTreePayload> add(node: Ref<TreeNode<T>?>, element: T): Boolean { /*@DONE TreeNodeStatic.Add/1 cs:163-163*/
        return TreeNode.add(node, element) != AddType.ReplaceExisting
    }
    fun <T : ISearchTreePayload> remove(node: Ref<TreeNode<T>?>, key: Int): Boolean { /*@DONE TreeNodeStatic.Remove/1 cs:165-165*/
        return TreeNode.remove(node, key) != RemoveType.NoRemoval
    }
    fun <T : ISearchTreePayload> rotateRight(node: Ref<TreeNode<T>?>) { /*@DONE TreeNodeStatic.RotateRight/1 cs:166-171*/
        val old = node.value!!
        val newRoot = old.left!!
        old.left = newRoot.right
        newRoot.right = old
        node.value = newRoot
    }
    fun <T : ISearchTreePayload> rotateLeft(node: Ref<TreeNode<T>?>) { /*@DONE TreeNodeStatic.RotateLeft/1 cs:172-177*/
        val old = node.value!!
        val newRoot = old.right!!
        old.right = newRoot.left
        newRoot.left = old
        node.value = newRoot
    }
    fun <T : ISearchTreePayload> rotate(node: Ref<TreeNode<T>?>, direction: Int) { /*@DONE TreeNodeStatic.Rotate/1 cs:178-181*/
        if (direction == TreeNode._left) rotateLeft(node)
        else rotateRight(node)
    }
    /*@END TreeNodeStatic*/
}

open class TreeNode<T : ISearchTreePayload> : Iterable<TreeNode<T>> { // cs:189-398
    var payload: T = portInit()
        private set
    var color: TreeColor = TreeColor.Red
        private set
    val blackCount: Int
        get() { /*@DONE TreeNode.BlackCount.get cs:194-194*/
            return (if (left == null) 0 else left!!.blackCount) + (if (color == TreeColor.Black) 1 else 0)
        }
    private var children: Array<TreeNode<T>?> = /*@INITDONE TreeNode.children cs:195-195*/ arrayOfNulls<TreeNode<T>>(2) /*@ENDINIT*/
    var left: TreeNode<T>?
        get() { /*@DONE TreeNode.Left.get cs:196-196*/
            return children[0]
        }
        set(value) { /*@DONE TreeNode.Left.set cs:196-196*/
            children[0] = value
        }
    var right: TreeNode<T>?
        get() { /*@DONE TreeNode.Right.get cs:197-197*/
            return children[1]
        }
        set(value) { /*@DONE TreeNode.Right.set cs:197-197*/
            children[1] = value
        }
    constructor(value: T) { /*@DONE TreeNode.<init>/1 cs:198-198*/
        payload = value
    }
    override fun toString(): String { /*@DONE TreeNode.ToString/1 cs:200-204*/
        val result = payload.toString()
        if (color == TreeColor.Red) return "($result)"
        return result
    }
    fun verify() { /*@DONE TreeNode.Verify/1 cs:210-210*/
        verifyHelper()
    }
    private fun verifyHelper(): Int { /*@DONE TreeNode.VerifyHelper/1 cs:212-221*/
        // verify that from this node, the black length is the same in both directions
        // verify that if this node is red, it has no red children.
        val leftCount = if (children[_left] == null) 0 else left!!.verifyHelper()
        val rightCount = if (right == null) 0 else right!!.verifyHelper()
        Debug.assert(leftCount == rightCount, "RedBlack Node must have matching black count on left and right branches: $leftCount and $rightCount")
        if (color == TreeColor.Black) return leftCount + 1
        Debug.assert(left.isBlack() && right.isBlack(), "Red nodes must not have red children!")
        return leftCount
    }
    fun blackWithRedChild(direction: Int): Boolean { /*@DONE TreeNode.BlackWithRedChild/1 cs:223-223*/
        return this.isBlack() && !children[direction].isBlack()
    }
    fun enumerateFrom(start: Int): Iterable<T> { /*@DONE TreeNode.EnumerateFrom/1 cs:225-233*/
        return sequence<T> {
            val l = left
            if (start > payload.start && l != null) {
                for (node in l.enumerateFrom(start)) yield(node)
            }
            if (start == payload.start) yield(payload)
            val r = right
            if (r != null) {
                for (node in r.enumerateFrom(start)) yield(node)
            }
        }.asIterable()
    }
    fun recolor() { /*@DONE TreeNode.Recolor/1 cs:361-361*/
        color = if (color == TreeColor.Red) TreeColor.Black else TreeColor.Red
    }
    override fun iterator(): Iterator<TreeNode<T>> { /*@DONE TreeNode.GetEnumerator/1 cs:363-375*/
        return sequence<TreeNode<T>> {
            val l = left
            if (l != null) {
                for (node in l) {
                    yield(node)
                }
            }
            yield(this@TreeNode)
            val r = right
            if (r != null) {
                for (node in r) {
                    yield(node)
                }
            }
        }.iterator()
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    private fun recolorIfSelfAndSiblingAreRed(sibling: TreeNode<T>?, parent: TreeNode<T>): Boolean { /*@DONE TreeNode.RecolorIfSelfAndSiblingAreRed/1 cs:379-388*/
        if (!this.isBlack() && !sibling.isBlack()) {
            // parent is guaranteed to be black by rule (2)
            parent.recolor()
            recolor()
            sibling!!.recolor()
            return true
        }
        return false
    }
    private fun rotateIfSelfRedWithBlackSibling(sibling: TreeNode<T>?, parent: Ref<TreeNode<T>?>, rotateDirection: Int) { /*@DONE TreeNode.RotateIfSelfRedWithBlackSibling/1 cs:390-397*/
        if (parent.value == null) return // root is always black
        if (!sibling.isBlack()) return
        if (this.isBlack()) return
        TreeNodeStatic.rotate(parent, rotateDirection)
        parent.value!!.children[rotateDirection]!!.recolor()
        parent.value!!.recolor()
    }
    companion object {
        const val _left: Int = 0
        const val _right: Int = 1
        fun <T : ISearchTreePayload> add(node: Ref<TreeNode<T>?>, element: T): AddType { /*@DONE TreeNode.Add/1 cs:239-242*/
            val insert = TreeNodeStatic.from(element)
            return add(node, insert)
        }
        fun <T : ISearchTreePayload> add(node: Ref<TreeNode<T>?>, insert: TreeNode<T>, balance: Boolean = true): AddType { /*@DONE TreeNode.Add/2 cs:244-261*/
            val start = insert.payload.start
            val current = node.value
            if (current == null || current.payload.start == start) {
                if (balance) insert.color = current?.color ?: TreeColor.Red
                var addType = if (balance) AddType.Insert else AddType.Balanced
                if (current != null) addType = AddType.ReplaceExisting
                insert.left = current?.left
                insert.right = current?.right
                node.value = insert
                return addType
            } else if (start < current.payload.start) {
                return addChild(node, insert, _left, balance)
            } else if (current.payload.start < start) {
                return addChild(node, insert, _right, balance)
            } else {
                throw NotImplementedException()
            }
        }
        private fun <T : ISearchTreePayload> addChild(parent: Ref<TreeNode<T>?>, insert: TreeNode<T>, direction: Int, balance: Boolean): AddType { /*@DONE TreeNode.AddChild/1 cs:263-278*/
            val other = 1 - direction
            val p = parent.value!!
            val addMethod = withSlot(p.children, direction) { slot -> add(slot, insert, balance) }
            if (addMethod == AddType.ReplaceExisting) return addMethod
            if (addMethod == AddType.Insert) return AddType.fromValue(direction)
            var node = p.children[direction]
            val sibling = p.children[other]
            if (addMethod != AddType.Balanced) {
                if (node!!.recolorIfSelfAndSiblingAreRed(sibling, p)) return AddType.Insert
                if (addMethod == AddType.fromValue(other) && !node.isBlack() && sibling.isBlack()) {
                    withSlot(p.children, direction) { slot -> TreeNodeStatic.rotate(slot, direction) }
                    node = p.children[direction]
                }
                node!!.rotateIfSelfRedWithBlackSibling(sibling, parent, other)
            }
            return AddType.Balanced
        }
        fun <T : ISearchTreePayload> remove(node: Ref<TreeNode<T>?>, key: Int): RemoveType { /*@DONE TreeNode.Remove/1 cs:280-304*/
            val current = node.value ?: return RemoveType.NoRemoval

            if (key == current.payload.start) {
                if (current.right != null) {
                    val nextNode = current.right!!.first()
                    val tmp = current.payload
                    current.payload = nextNode.payload
                    nextNode.payload = tmp
                    return removeChild(node, key, _right)
                } else if (current.left != null) {
                    val prevNode = current.left!! // if I have only one child, by the red-black rules it must be a Red leaf
                    val tmp = current.payload
                    current.payload = prevNode.payload
                    prevNode.payload = tmp
                    return removeChild(node, key, _left)
                } else {
                    val color = current.color
                    node.value = null
                    return if (color == TreeColor.Red) RemoveType.Balanced else RemoveType.DecreaseBlackCount
                }
            }

            if (current.payload.start < key) {
                return removeChild(node, key, _right)
            } else {
                return removeChild(node, key, _left)
            }
        }
        private fun <T : ISearchTreePayload> removeChild(node: Ref<TreeNode<T>?>, key: Int, direction: Int): RemoveType { /*@DONE TreeNode.RemoveChild/1 cs:306-342*/
            val other = 1 - direction
            val n = node.value!!
            val result = withSlot(n.children, direction) { slot -> remove(slot, key) }
            if (result == RemoveType.NoRemoval) return result
            if (n.color == TreeColor.Black && !n.children[other].isBlack() && result == RemoveType.DecreaseBlackCount) {
                TreeNodeStatic.rotate(node, direction)
                node.value!!.recolor()
                node.value!!.children[direction]!!.recolor()
                val rotated = node.value!!
                withSlot(rotated.children, direction) { slot -> increaseBlackCount(slot, direction) }
                return RemoveType.Balanced
            }
            if (n.color == TreeColor.Black && result == RemoveType.DecreaseBlackCount && n.children[other].blackWithBlackChildren()) {
                n.children[other]!!.recolor()
                return RemoveType.DecreaseBlackCount
            } else if (n.color == TreeColor.Red && result == RemoveType.DecreaseBlackCount && n.children[other].isBlack() && n.children[direction].isBlack()) {
                increaseBlackCount(node, direction)
                return RemoveType.Balanced
            }

            if (n.color == TreeColor.Black && result == RemoveType.DecreaseBlackCount && n.children[other]!!.blackWithRedChild(other)) {
                TreeNodeStatic.rotate(node, direction)
                node.value!!.children[other]!!.recolor()
                return RemoveType.Balanced
            }
            if (n.color == TreeColor.Black && result == RemoveType.DecreaseBlackCount && n.children[other]!!.blackWithRedChild(direction)) {
                // this case just rotates to become the previous case
                withSlot(n.children, other) { slot -> TreeNodeStatic.rotate(slot, other) }
                n.children[other]!!.children[other]!!.recolor()
                n.children[other]!!.recolor()

                TreeNodeStatic.rotate(node, direction)
                node.value!!.children[other]!!.recolor()
                return RemoveType.Balanced
            }

            return RemoveType.Balanced
        }
        private fun <T : ISearchTreePayload> increaseBlackCount(node: Ref<TreeNode<T>?>, direction: Int) { /*@DONE TreeNode.IncreaseBlackCount/1 cs:344-359*/
            val n = node.value!!
            if (n.color == TreeColor.Red && n.children[1 - direction]!!.blackWithRedChild(direction)) {
                withSlot(n.children, 1 - direction) { slot -> TreeNodeStatic.rotate(slot, 1 - direction) }
                n.children[1 - direction]!!.recolor()
                n.children[1 - direction]!!.children[1 - direction]!!.recolor()
            }
            if (n.color == TreeColor.Red && n.left.isBlack() && n.right.isBlack()) {
                n.recolor()
                n.children[1 - direction]!!.recolor()
            }
            if (n.children[1 - direction]!!.children.any { child -> !child.isBlack() }) {
                TreeNodeStatic.rotate(node, direction)
                node.value!!.children[direction]!!.recolor()
                node.value!!.recolor()
            }
        }
        /*@END TreeNode.Companion*/
    }
    /*@END TreeNode*/
}

/*@ADD file:models/SearchTree.kt#util_2.txt*/
/** C# `ref node.children[i]`: run [block] on a boxed copy of the slot and write the result back (no aliasing happens inside the callee). */
private inline fun <T : ISearchTreePayload, R> withSlot(array: Array<TreeNode<T>?>, index: Int, block: (Ref<TreeNode<T>?>) -> R): R {
    val box = Ref(array[index])
    val result = block(box)
    array[index] = box.value
    return result
}
/*@ENDADD file:models/SearchTree.kt#util_2.txt*/
