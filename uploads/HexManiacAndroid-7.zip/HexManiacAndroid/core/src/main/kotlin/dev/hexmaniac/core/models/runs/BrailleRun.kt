// Port of Models/Runs/BrailleRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.images.*

open class BrailleRun : BaseRun, IStreamRun, IAppendToBuilderRun { // cs:9-122
    private lateinit var model: IDataModel
    constructor(model: IDataModel, start: Int, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE BrailleRun.<init>/1 cs:48-52*/
        this.model = model
        while (model.count > start + length && length < 100 && model[start + length] != 0xFF) length++
        length++
    }
    final override var length: Int = 0
        private set
    override val formatString: String
        get() { /*@DONE BrailleRun.FormatString.get cs:56-56*/
            return sharedFormatString
        }
    override val visualizations: List<IPixelViewModel>
        get() { /*@DONE BrailleRun.Visualizations.get cs:58-58*/
            return ArrayList<IPixelViewModel>()
        }
    final override var preFormatter: ITextPreProcessor? = null
        private set
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE BrailleRun.AppendTo/1 cs:61-65*/
        for (i in 0 until length - 1) {
            if (model[start] != 0xFF) {
                val c = encoding[model[start + i]]
                if (c != null) builder.append(c)
            }
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE BrailleRun.Clear/1 cs:67-69*/
        for (i in 0 until length) changeToken.changeData(model, start + i, 0xFF)
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE BrailleRun.CreateDataFormat/1 cs:71-73*/
        return Braille(start, index - start, if (data[index] == 0xFF) '"' else (encoding[data[index]] ?: ' '))
    }
    override fun dependsOn(anchorName: String): Boolean { /*@DONE BrailleRun.DependsOn/1 cs:75-75*/
        return false
    }
    override fun deserializeRun(content: String, token: ModelDelta, changedOffsets: Ref<List<Int>?>, changedRuns: Ref<List<Int>?>): IStreamRun { /*@DONE BrailleRun.DeserializeRun/1 cs:82-111*/
        val changes = ArrayList<Int>()
        val upper = content.uppercase()

        val bytes = ArrayList<Int>()
        for (c in upper) bytes.add(deserializeCharacter(c))
        bytes.add(0xFF)

        val run = model.relocateForExpansion(token, this, bytes.size)
        if (run.start != start) {
            changes.addAll((length - 1).range().map { i -> start + i })
            token.changeData(model, run.start, bytes.toByteArrayU().asByteList())
            changes.addAll((length - 1).range().map { i -> run.start + i })
        } else {
            for (i in 0 until bytes.size) {
                if (bytes[i] != model[start + i]) {
                    changes.add(start + i)
                    token.changeData(model, start + i, bytes[i])
                }
            }
            for (i in bytes.size until length - 1) {
                changes.add(start + i)
                token.changeData(model, start + i, 0xFF)
            }
        }

        changedOffsets.value = changes
        changedRuns.value = ArrayList<Int>()
        return BrailleRun(model, run.start, pointerSources)
    }
    override fun getAutoCompleteOptions(line: String, caretLineIndex: Int, caretCharacterIndex: Int): List<AutocompleteItem>? { /*@DONE BrailleRun.GetAutoCompleteOptions/1 cs:113-113*/
        return null
    }
    override fun serializeRun(): String? { /*@DONE BrailleRun.SerializeRun/1 cs:115-119*/
        val builder = StringBuilder()
        appendTo(model, builder, start, length - 1, 0)
        return builder.toString()
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE BrailleRun.Clone/1 cs:121-121*/
        return BrailleRun(model, start, newPointerSources)
    }
    companion object {
        val encoding: Map<Int, Char> = /*@INITDONE BrailleRun.Encoding cs:10-42*/ 
            linkedMapOf(
                0x01 to 'A',
                0x05 to 'B',
                0x03 to 'C',
                0x0B to 'D',
                0x09 to 'E',
                0x07 to 'F',
                0x0F to 'G',
                0x0D to 'H',
                0x06 to 'I',
                0x0E to 'J',
                0x11 to 'K',
                0x15 to 'L',
                0x13 to 'M',
                0x1B to 'N',
                0x19 to 'O',
                0x17 to 'P',
                0x1F to 'Q',
                0x1D to 'R',
                0x16 to 'S',
                0x1E to 'T',
                0x31 to 'U',
                0x35 to 'V',
                0x2E to 'W',
                0x33 to 'X',
                0x3B to 'Y',
                0x39 to 'Z',
                0x00 to ' ',
                0x04 to ',',
                0x2C to '.',
                0xFF to '$'
            ) /*@ENDINIT*/
        val sharedFormatString: String = /*@INITDONE BrailleRun.SharedFormatString cs:44-44*/ AsciiRun.streamDelimeter.toString() + "brl" + AsciiRun.streamDelimeter /*@ENDINIT*/
        fun deserializeCharacter(content: Char): Int { /*@DONE BrailleRun.DeserializeCharacter/1 cs:77-80*/
            val match = encoding.entries.firstOrNull { entry -> entry.value == content }?.key ?: 0
            return match
        }
        /*@END BrailleRun.Companion*/
    }
    /*@END BrailleRun*/
}
