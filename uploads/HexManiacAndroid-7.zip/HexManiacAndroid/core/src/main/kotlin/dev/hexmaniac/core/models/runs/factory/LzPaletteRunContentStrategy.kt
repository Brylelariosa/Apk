// Port of Models/Runs/Factory/LzPaletteRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*

open class LzPaletteRunContentStrategy : RunStrategy { // cs:12-52
    private var paletteFormat: PaletteFormat = PaletteFormat()
    constructor(paletteFormat: PaletteFormat) { /*@DONE LzPaletteRunContentStrategy.<init>/1 cs:14-14*/
        this.paletteFormat = paletteFormat
    }
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE LzPaletteRunContentStrategy.LengthForNewRun/1 cs:16-19*/
        val data = LZRun.compress(ByteArray(paletteFormat.expectedByteLengthPerPage).asByteList(), 0, paletteFormat.expectedByteLengthPerPage)
        return data.count
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE LzPaletteRunContentStrategy.TryAddFormatAtDestination/1 cs:20-28*/
        val lzRun = LzPaletteRun(paletteFormat, owner, destination, SortedSpan(source))
        val numColors = Math.pow(2.0, paletteFormat.bits.toDouble()).toInt()
        if (lzRun.length <= 5 || lzRun.decompressedLength % (numColors * 2) != 0) return false

        if (token !is NoDataChangeDeltaModel) owner.observeRunWritten(token, lzRun)

        return true
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE LzPaletteRunContentStrategy.Matches/1 cs:29-29*/
        return run is LzPaletteRun && run.paletteFormat.pages == paletteFormat.pages && run.paletteFormat.bits == paletteFormat.bits
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE LzPaletteRunContentStrategy.WriteNewRun/1 cs:30-34*/
        val data = LZRun.compress(ByteArray(paletteFormat.expectedByteLengthPerPage).asByteList(), 0, paletteFormat.expectedByteLengthPerPage)
        for (i in 0 until data.count) token.changeData(owner, destination + i, data[i])
        return LzPaletteRun(paletteFormat, owner, destination)
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE LzPaletteRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:35-43*/
        var localFormat = paletteFormat
        if (sourceSegments != null && parentIndex >= 0) localFormat = PaletteFormat(paletteFormat.bits, paletteFormat.pages, paletteFormat.initialBlankPages, true)
        val runAttempt = LzPaletteRun(localFormat, model, run.value.start, run.value.pointerSources)
        if (runAttempt.length > 0) {
            val merged = runAttempt.mergeAnchor(run.value.pointerSources)
            run.value = merged
            model.clearFormat(token, merged.start, merged.length)
        }
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE LzPaletteRunContentStrategy.TryParseData/1 cs:44-51*/
        val error = PaletteRunContentStrategy.isValid(paletteFormat.bits)
        if (error.hasError) return error
        val lzRun = LzPaletteRun(paletteFormat, model, dataIndex, run.value?.pointerSources)
        run.value = lzRun
        if (lzRun.length == LZRun.decompressedTooLong) return ErrorInfo("Decompressed more bytes than expected. Add a ! to override this.")
        if (lzRun.length < 6) return ErrorInfo("Compressed data needs to be at least " + Math.pow(2.0, (paletteFormat.bits + 1).toDouble()).toInt() + " bytes when decompressed, but was too short.")
        return ErrorInfo.noError
    }
    /*@END LzPaletteRunContentStrategy*/
}
