// Port of ViewModels/Map/WildPokemonViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class WildPokemonViewModel : ViewModelCore { // cs:11-209
    private lateinit var viewPort: IEditableViewPort
    private lateinit var model: IDataModel
    private lateinit var tokenFactory: () -> ModelDelta
    private lateinit var tutorials: MapTutorialsViewModel
    private var bank: Int = 0
    private var map: Int = 0
    constructor(viewPort: IEditableViewPort, tutorials: MapTutorialsViewModel, group: Int, map: Int) { /*@DONE WildPokemonViewModel.<init>/1 cs:18-22*/
        this.viewPort = viewPort
        this.tokenFactory = { viewPort.changeHistory.currentChange }
        this.model = viewPort.model!!
        this.tutorials = tutorials
        this.bank = group
        this.map = map
    }
    private var wildDataIndex: Int = /*@INITDONE WildPokemonViewModel.wildDataIndex cs:26-26*/ Int.MIN_VALUE /*@ENDINIT*/
    val hasWildData: Boolean
        get() { /*@DONE WildPokemonViewModel.HasWildData.get cs:28-31*/
            if (wildDataIndex == Int.MIN_VALUE) wildDataIndex = findWildData()
            return wildDataIndex != -1
        }
    private fun findWildData(): Int { /*@DONE WildPokemonViewModel.FindWildData/1 cs:33-43*/
        val wildData = model.getTableModel(HardcodeTablesModel.wildTableName, null)
        if (wildData == null) return -1
        for (i in 0 until wildData.size) {
            val bank = wildData[i].getValue("bank")
            val map = wildData[i].getValue("map")
            if (this.bank != bank || this.map != map) continue
            return i
        }
        return -1
    }
    private var _showWildData: Boolean = false
    var showWildData: Boolean
        get() { /*@DONE WildPokemonViewModel.ShowWildData.get cs:49-49*/
            return _showWildData
        }
        set(value) { /*@DONE WildPokemonViewModel.ShowWildData.set cs:50-77*/
            tryUpdate(_showWildData, value, "showWildData") { _showWildData = it }
            if (!_showWildData || hasWildData) return
            val token = tokenFactory()

            // extend wild table
            var wildTable = model.getTable(HardcodeTablesModel.wildTableName)
            if (wildTable == null) return
            val originalStart = wildTable.start
            wildTable = model.relocateForExpansion(token, wildTable, wildTable.length + wildTable.elementLength)
            wildTable = wildTable.append(token, 1)
            model.observeRunWritten(token, wildTable)

            // create new entry
            val element = ModelArrayElement(model, wildTable.start, wildTable.elementCount - 1, tokenFactory, wildTable)
            element.setValue("bank", bank)
            element.setValue("map", map)
            element.setAddress("grass", Pointer.null_)
            element.setAddress("surf", Pointer.null_)
            element.setAddress("tree", Pointer.null_)
            element.setAddress("fish", Pointer.null_)
            wildDataIndex = wildTable.elementCount - 1

            // bookkeeping
            if (wildTable.start != originalStart) informRepoint(DataMovedEventArgs("Wild", wildTable.start))
            notifyPropertyChanged("hasWildData")
            viewPort.changeHistory.changeCompleted()
        }
    private var wildText: String? = null
    val wildSummary: String
        get() { /*@DONE WildPokemonViewModel.WildSummary.get cs:82-96*/
            val cached = wildText
            if (cached != null) return cached
            val wild = model.getTableModel(HardcodeTablesModel.wildTableName)
            // grass<[rate:: list<>]1> surf<[rate:: list<>]1> tree<[rate:: list<>]1> fish<[rate:: list<>]1>
            val text = StringBuilder()
            if (wildDataIndex < 0 || wild == null) return text.toString()
            if (buildWildTooltip(text, wild[wildDataIndex], "grass")) text.append(NEW_LINE)
            if (buildWildTooltip(text, wild[wildDataIndex], "surf")) text.append(NEW_LINE)
            if (buildWildTooltip(text, wild[wildDataIndex], "tree")) text.append(NEW_LINE)
            buildWildTooltip(text, wild[wildDataIndex], "fish")
            var summary = text.toString()
            summary = summary.trimEnd()
            if (summary.isBlank()) summary = "No Wild Pokemon (yet!)"
            wildText = summary
            return summary
        }
    private var _gotoWildData: StubCommand? = null
    val gotoWildData: ICommand
        get() { /*@DONE WildPokemonViewModel.GotoWildData.get cs:132-139*/
            return _gotoWildData ?: stubCommand({
                val wildTable = model.getTable(HardcodeTablesModel.wildTableName)
                if (!hasWildData) {
                    // (the original has an empty branch here; reading hasWildData finds the wild data index)
                }
                if (wildTable != null) viewPort.goto?.execute(wildTable.start + wildTable.elementLength * wildDataIndex)
                tutorials.complete(Tutorial.ToolbarButton_GotoWildData)
            }, { model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, HardcodeTablesModel.wildTableName) != Pointer.null_ }).also { _gotoWildData = it }
        }
    private var _gotoGrass: StubCommand? = null
    private var _gotoTree: StubCommand? = null
    private var _gotoFishing: StubCommand? = null
    private var _gotoSurf: StubCommand? = null
    val grassExists: Boolean
        get() { /*@DONE WildPokemonViewModel.GrassExists.get cs:147-147*/
            return exists("grass")
        }
    val gotoGrass: ICommand
        get() { /*@DONE WildPokemonViewModel.GotoGrass.get cs:148-148*/
            return _gotoGrass ?: stubCommand({ gotoData("grass", 20, 2, 3, if (model.isFRLG()) 19 else 288, 12) }).also { _gotoGrass = it } // rattata, zigzagoon
        }
    val surfExists: Boolean
        get() { /*@DONE WildPokemonViewModel.SurfExists.get cs:150-150*/
            return exists("surf")
        }
    val gotoSurf: ICommand
        get() { /*@DONE WildPokemonViewModel.GotoSurf.get cs:151-151*/
            return _gotoSurf ?: stubCommand({ gotoData("surf", 4, 5, 35, 72, 5) }).also { _gotoSurf = it } // tentacool
        }
    val treeExists: Boolean
        get() { /*@DONE WildPokemonViewModel.TreeExists.get cs:153-153*/
            return exists("tree")
        }
    val gotoTree: ICommand
        get() { /*@DONE WildPokemonViewModel.GotoTree.get cs:154-154*/
            return _gotoTree ?: stubCommand({ gotoData("tree", 20, 10, 15, 74, 5) }).also { _gotoTree = it } // geodude
        }
    val fishingExists: Boolean
        get() { /*@DONE WildPokemonViewModel.FishingExists.get cs:156-156*/
            return exists("fish")
        }
    val gotoFishing: ICommand
        get() { /*@DONE WildPokemonViewModel.GotoFishing.get cs:157-157*/
            return _gotoFishing ?: stubCommand({ gotoData("fish", 30, 5, 10, 129, 10) }).also { _gotoFishing = it } // magikarp
        }
    private fun exists(subtable: String): Boolean { /*@DONE WildPokemonViewModel.Exists/1 cs:161-166*/
        if (wildDataIndex == Int.MIN_VALUE) wildDataIndex = findWildData()
        if (wildDataIndex == -1) return false
        val wild = model.getTableModel(HardcodeTablesModel.wildTableName)!![wildDataIndex]
        return wild.getAddress(subtable) != Pointer.null_
    }
    private fun gotoData(subtable: String, rate: Int, minLevel: Int, maxLevel: Int, species: Int, count: Int) { /*@DONE WildPokemonViewModel.GotoData/1 cs:168-198*/
        if (wildDataIndex == Int.MIN_VALUE) wildDataIndex = findWildData()
        if (wildDataIndex == -1) return
        val wild = model.getTableModel(HardcodeTablesModel.wildTableName, tokenFactory)!![wildDataIndex]
        val address = wild.getAddress(subtable)
        tutorials.complete(Tutorial.ToolbarButton_GotoWildData)

        showWildData = false

        if (address != Pointer.null_) {
            viewPort.goto?.execute(address)
            return
        }

        val subtableStart = model.findFreeSpace(model.freeSpaceStart, 8 + 4 * count)
        val dataStart = subtableStart + 8
        val token = tokenFactory()

        model.writeMultiByteValue(subtableStart + 0, 4, token, rate)
        model.writePointer(token, subtableStart + 4, dataStart)
        for (i in 0 until count) {
            token.changeData(model, dataStart + i * 4 + 0, minLevel)
            token.changeData(model, dataStart + i * 4 + 1, maxLevel)
            model.writeMultiByteValue(dataStart + i * 4 + 2, 2, token, species)
        }
        wild.setAddress(subtable, subtableStart)
        viewPort.goto?.execute(subtableStart)
        viewPort.raiseMessage("New " + subtable + " data was added at " + subtableStart.toHex(6) + ".")
        wildText = null
        notifyPropertyChanged("wildSummary")
    }
    fun clearCache() { /*@DONE WildPokemonViewModel.ClearCache/1 cs:200-204*/
        wildDataIndex = Int.MIN_VALUE
        wildText = null
        notifyPropertiesChanged("hasWildData", "wildSummary")
    }
    private fun informRepoint(e: DataMovedEventArgs) { /*@DONE WildPokemonViewModel.InformRepoint/1 cs:206-208*/
        viewPort.raiseMessage(e.type + " data was moved to " + e.address.toHex(6) + ".")
    }
    companion object {
        private fun buildWildTooltip(text: StringBuilder, wild: ModelArrayElement, type: String): Boolean { /*@DONE WildPokemonViewModel.BuildWildTooltip/1 cs:98-121*/
            // list<[low. high. species:]n>
            val terrain = wild.getSubTable(type)
            if (terrain == null) return false
            val list = terrain[0].getSubTable("list")
            if (list == null) return false
            text.append(type)
            text.append(":").append(NEW_LINE)

            if (type == "fish") {
                text.append("old rod: ")
                appendHistogram(text, list.take(2), "species")
                text.append(NEW_LINE)
                text.append("good rod: ")
                appendHistogram(text, list.drop(2).take(3), "species")
                text.append(NEW_LINE)
                text.append("super rod: ")
                appendHistogram(text, list.drop(5), "species")
            } else {
                appendHistogram(text, list, "species")
            }
            text.append(NEW_LINE)
            return true
        }
        private fun appendHistogram(text: StringBuilder, elements: Iterable<ModelArrayElement>, fieldName: String) { /*@DONE WildPokemonViewModel.AppendHistogram/1 cs:123-129*/
            val histogram = elements.map { element -> element.getEnumValue(fieldName) }.toHistogram()
            val parts = histogram.keys.map { key -> if (histogram[key] == 1) key else key + " x" + histogram[key] }
            text.append(parts.joinToString(", "))
        }
        /*@END WildPokemonViewModel.Companion*/
    }
    /*@END WildPokemonViewModel*/
}
