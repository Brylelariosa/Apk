package dev.hexmaniac.core.system

import kotlin.coroutines.Continuation
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.startCoroutine
import kotlin.coroutines.suspendCoroutine

// System.Threading.Tasks.Task / async / await on top of the Kotlin standard library only (no kotlinx.coroutines).
//
//   C#                                      Kotlin
//   Task                                    Task<Unit>
//   Task<T>                                 Task<T>
//   async Task<T> Foo() { ... await x; }    fun foo(): Task<T> = asyncTask { ...; x.await() ... }
//   await task                              task.await()      (only inside asyncTask { } or another suspend function)
//   Task.CompletedTask                      Task.completedTask
//   Task.FromResult(v)                      Task.fromResult(v)
//   Task.Run(() => ...)                     Task.run { ... }
//   task.Wait() / task.Result               task.waitSync() / task.result
//
// Continuations of a task that finishes on another thread are posted to [SynchronizationContext.main] when one is
// installed (the Android UI thread), so code after an `await` keeps running on the UI thread like in WPF.

/** Posts work to the "UI thread". Install one from the Android app; unit tests leave it unset and run inline. */
object SynchronizationContext {
    @JvmField
    var post: ((() -> Unit) -> Unit)? = null

    @JvmField
    var isMainThread: () -> Boolean = { true }

    internal fun runOnMain(action: () -> Unit) {
        val p = post
        if (p == null || isMainThread()) action() else p(action)
    }
}

class Task<T> {
    private val lock = Object()
    private var done = false
    private var value: T? = null
    private var error: Throwable? = null
    private var continuations: MutableList<() -> Unit>? = null

    val isCompleted: Boolean get() = synchronized(lock) { done }
    val isFaulted: Boolean get() = synchronized(lock) { done && error != null }
    val exception: Throwable? get() = synchronized(lock) { error }

    /** Blocks until the task is done, then returns the value (or throws the task's exception). */
    val result: T
        @Suppress("UNCHECKED_CAST")
        get() {
            waitSync()
            synchronized(lock) {
                error?.let { throw it }
                return value as T
            }
        }

    /** C# `task.Wait()`: blocks the calling thread until the task completes. Rethrows the task's exception. */
    fun waitSync() {
        synchronized(lock) {
            while (!done) lock.wait()
            error?.let { throw it }
        }
    }

    fun trySetResult(result: T): Boolean = finish(result, null)
    fun trySetException(e: Throwable): Boolean = finish(null, e)
    fun setResult(result: T) {
        if (!trySetResult(result)) throw IllegalStateException("The task was already completed.")
    }

    private fun finish(v: T?, e: Throwable?): Boolean {
        val toRun: List<() -> Unit>?
        synchronized(lock) {
            if (done) return false
            done = true
            value = v
            error = e
            toRun = continuations
            continuations = null
            lock.notifyAll()
        }
        toRun?.let { list -> for (c in list) SynchronizationContext.runOnMain(c) }
        return true
    }

    /** Runs [action] after the task completes (immediately when it already has). */
    fun onCompleted(action: () -> Unit) {
        synchronized(lock) {
            if (!done) {
                val list = continuations ?: ArrayList<() -> Unit>().also { continuations = it }
                list.add(action)
                return
            }
        }
        action()
    }

    /** C# `task.ContinueWith(t => ...)`. */
    fun <R> continueWith(selector: (Task<T>) -> R): Task<R> {
        val next = Task<R>()
        onCompleted {
            try {
                next.trySetResult(selector(this))
            } catch (e: Throwable) {
                next.trySetException(e)
            }
        }
        return next
    }

    @Suppress("UNCHECKED_CAST")
    internal fun valueOrThrow(): T {
        synchronized(lock) {
            error?.let { throw it }
            return value as T
        }
    }

    companion object {
        /** `Task.CompletedTask` (a non-generic C# Task is a Task<Unit>). */
        val completedTask: Task<Unit> = Task<Unit>().also { it.trySetResult(Unit) }

        fun <T> fromResult(result: T): Task<T> = Task<T>().also { it.trySetResult(result) }

        /** `Task.Run`: runs [block] on a background thread. */
        fun <T> run(block: () -> T): Task<T> {
            val task = Task<T>()
            val thread = Thread {
                try {
                    task.trySetResult(block())
                } catch (e: Throwable) {
                    task.trySetException(e)
                }
            }
            thread.isDaemon = true
            thread.start()
            return task
        }

        /** `Task.Delay(ms)` */
        fun delay(milliseconds: Int): Task<Unit> {
            val task = Task<Unit>()
            val thread = Thread {
                try {
                    Thread.sleep(milliseconds.toLong())
                } catch (_: InterruptedException) {
                }
                task.trySetResult(Unit)
            }
            thread.isDaemon = true
            thread.start()
            return task
        }

        /**
         * `Task.Delay(ms, token)`: completes after [milliseconds] (never when negative) or when the token is cancelled.
         * (C# would mark the task cancelled; here the task completes so that continuations run.)
         */
        fun delay(milliseconds: Int, token: CancellationToken): Task<Unit> {
            val task = Task<Unit>()
            token.register { task.trySetResult(Unit) }
            if (milliseconds >= 0) {
                val thread = Thread {
                    try {
                        Thread.sleep(milliseconds.toLong())
                    } catch (_: InterruptedException) {
                    }
                    task.trySetResult(Unit)
                }
                thread.isDaemon = true
                thread.start()
            }
            return task
        }

        /** `Task.WhenAll(...)` */
        fun whenAll(tasks: List<Task<*>>): Task<Unit> {
            val all = Task<Unit>()
            if (tasks.isEmpty()) {
                all.trySetResult(Unit)
                return all
            }
            var remaining = tasks.size
            val lock = Object()
            for (t in tasks) {
                t.onCompleted {
                    val finished = synchronized(lock) { --remaining == 0 }
                    if (finished) {
                        val failure = tasks.firstOrNull { it.isFaulted }
                        if (failure != null) all.trySetException(failure.exception!!) else all.trySetResult(Unit)
                    }
                }
            }
            return all
        }
    }
}

/** `await task` */
suspend fun <T> Task<T>.await(): T = suspendCoroutine { cont ->
    onCompleted {
        try {
            cont.resume(valueOrThrow())
        } catch (e: Throwable) {
            cont.resumeWithException(e)
        }
    }
}

/**
 * An `async` method body. Like C#, the body runs synchronously on the caller's thread until its first `await`
 * on a task that is not complete yet; the returned Task finishes with the body's value or exception.
 */
fun <T> asyncTask(block: suspend () -> T): Task<T> {
    val task = Task<T>()
    block.startCoroutine(object : Continuation<T> {
        override val context = EmptyCoroutineContext
        override fun resumeWith(result: Result<T>) {
            result.fold({ task.trySetResult(it) }, { task.trySetException(it) })
        }
    })
    return task
}
