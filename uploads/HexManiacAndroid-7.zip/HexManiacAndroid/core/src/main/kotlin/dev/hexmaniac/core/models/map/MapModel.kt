// Port of Models/Map/MapModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.map

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.map.*
import dev.hexmaniac.core.models.runs.sprites.*

data class AllMapsModel(val table: ModelTable?) : Iterable<MapBankModel> { // cs:12-31
    override fun iterator(): Iterator<MapBankModel> { /*@DONE AllMapsModel.GetEnumerator/1 cs:15-15*/
        return enumerate().iterator()
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    operator fun get(index: Int): MapBankModel? { /*@DONE AllMapsModel.this/1.get cs:20-24*/
        val bank = table!![index].getSubTable("maps") ?: return null
        return MapBankModel(bank, index)
    }
    val count: Int
        get() { /*@DONE AllMapsModel.Count.get cs:26-26*/
            return table?.size ?: 0
        }
    private fun enumerate(): Iterable<MapBankModel> { /*@DONE AllMapsModel.Enumerate/1 cs:28-30*/
        return Iterable {
            iterator {
                for (i in 0 until count) {
                    val bank = this@AllMapsModel[i]
                    if (bank != null) yield(bank)
                }
            }
        }
    }
    companion object {
        fun create(model: IDataModel, tokenFactory: (() -> ModelDelta)? = null): AllMapsModel { /*@DONE AllMapsModel.Create/1 cs:13-13*/
            return AllMapsModel(model.getTableModel("data.maps.banks", tokenFactory))
        }
        /*@END AllMapsModel.Companion*/
    }
    /*@END AllMapsModel*/
}

data class MapBankModel(val table: ModelTable?, val group: Int) : Iterable<MapModel> { // cs:33-49
    override fun iterator(): Iterator<MapModel> { /*@DONE MapBankModel.GetEnumerator/1 cs:34-34*/
        return enumerate().iterator()
    }
    // skipped method GetEnumerator: non-generic IEnumerable.GetEnumerator
    operator fun get(index: Int): MapModel? { /*@DONE MapBankModel.this/1.get cs:38-42*/
        val child = table!![index].getSubTable("map") ?: return null
        return MapModel(child[0], group, index)
    }
    val count: Int
        get() { /*@DONE MapBankModel.Count.get cs:44-44*/
            return table?.size ?: 0
        }
    private fun enumerate(): Iterable<MapModel> { /*@DONE MapBankModel.Enumerate/1 cs:46-48*/
        return Iterable {
            iterator {
                for (i in 0 until count) {
                    val map = this@MapBankModel[i]
                    if (map != null) yield(map)
                }
            }
        }
    }
    /*@END MapBankModel*/
}

data class MapModel(val element: ModelArrayElement?, val group: Int = -1, val map: Int = -1) { // cs:51-93
    val layout: LayoutModel?
        get() { /*@DONE MapModel.Layout.get cs:52-52*/
            val subTable = Ref<ModelTable?>(null)
            return if (element!!.tryGetSubTable(Format.layout, subTable)) LayoutModel(subTable.value!![0]) else LayoutModel(null)
        }
    val events: EventGroupModel
        get() { /*@DONE MapModel.Events.get cs:54-54*/
            val subTable = Ref<ModelTable?>(null)
            return if (element!!.tryGetSubTable(Format.events, subTable)) EventGroupModel(subTable.value!![0]) else EventGroupModel(null)
        }
    var nameIndex: Int
        get() { /*@DONE MapModel.NameIndex.get cs:57-62*/
            val element = element!!
            val code = element.model!!.getShortGameCode()
            val offset = if (code.isAny(0x45525042, 0x45475042, 0x49525042)) 88 else 0 // BPRE, BPGE, BPRI
            val value = Ref(0)
            if (!element.tryGetValue("regionSectionID", value)) return -1
            return value.value - offset
        }
        set(value) { /*@DONE MapModel.NameIndex.set cs:63-68*/
            val element = element!!
            if (!element.hasField("regionSectionID")) return
            val code = element.model!!.getShortGameCode()
            val offset = if (code.isAny(0x45525042, 0x45475042, 0x49525042)) 88 else 0 // BPRE, BPGE, BPRI
            element.setValue("regionSectionID", value + offset)
        }
    val connections: MutableList<ConnectionModel>?
        get() { /*@DONE MapModel.Connections.get cs:72-77*/
            if (group < 0 || map < 0) throw IllegalStateException("bank/map location unknown.")
            val outerTable = Ref<ModelTable?>(null)
            if (!element!!.tryGetSubTable(Format.connections, outerTable)) return null
            val innerTable = Ref<ModelTable?>(null)
            if (!outerTable.value!![0].tryGetSubTable(Format.connections, innerTable)) return null
            val connectionList = ArrayList<ConnectionModel>()
            for (e in innerTable.value!!) connectionList.add(ConnectionModel(e, group, map))
            return connectionList
        }
    val blocks: BlockCells?
        get() { /*@DONE MapModel.Blocks.get cs:81-85*/
            val layout = layout
            if (layout == null) return null
            return layout.blockMap
        }
    val mapScripts: ModelTable?
        get() { /*@DONE MapModel.MapScripts.get cs:89-89*/
            return element!!.getSubTable("mapscripts")
        }
    override fun toString(): String { /*@DONE MapModel.ToString/1 cs:92-92*/
        return "(" + group + ", " + map + ")"
    }
    /*@END MapModel*/
}

data class LayoutPrototype(val primaryBlockset: Int, val secondaryBlockset: Int, val borderBlock: Int) { // cs:95-95
    /*@END LayoutPrototype*/
}

data class BlockCells(val model: IDataModel?, val start: Int, val width: Int, val height: Int) { // cs:97-106
    val run: BlockmapRun?
        get() { /*@DONE BlockCells.Run.get cs:98-98*/
            return model?.getNextRun(start) as? BlockmapRun
        }
    operator fun get(x: Int, y: Int): BlockCell? { /*@DONE BlockCells.this/1.get cs:100-104*/
        if (start < 0) return null
        val data = model!!.readMultiByteValue(start + (y * width + x) * 2, 2)
        return BlockCell(data and 0x3FF, data shr 10)
    }
    /*@END BlockCells*/
}

data class BlockCell(val tile: Int, val collision: Int) { // cs:108-110
    val block: Int
        get() { /*@DONE BlockCell.Block.get cs:109-109*/
            return (collision shl 10) or tile
        }
    /*@END BlockCell*/
}

data class LayoutModel(val element: ModelArrayElement?) { // cs:112-124
    val width: Int
        get() { /*@DONE LayoutModel.Width.get cs:113-113*/
            return element?.getValue("width") ?: -1
        }
    val height: Int
        get() { /*@DONE LayoutModel.Height.get cs:114-114*/
            return element?.getValue("height") ?: -1
        }
    val primaryBlockset: MiniBlocksetModel?
        get() { /*@DONE LayoutModel.PrimaryBlockset.get cs:115-115*/
            val subTable = Ref<ModelTable?>(null)
            return if (element?.tryGetSubTable(Format.primaryBlockset, subTable) ?: false) MiniBlocksetModel(subTable.value!![0]) else null
        }
    val secondaryBlockset: MiniBlocksetModel?
        get() { /*@DONE LayoutModel.SecondaryBlockset.get cs:116-116*/
            val subTable = Ref<ModelTable?>(null)
            return if (element?.tryGetSubTable(Format.secondaryBlockset, subTable) ?: false) MiniBlocksetModel(subTable.value!![0]) else null
        }
    val borderBlockAddress: Int
        get() { /*@DONE LayoutModel.BorderBlockAddress.get cs:117-117*/
            return element?.getAddress(Format.borderBlock) ?: Pointer.null_
        }
    val blockMap: BlockCells
        get() { /*@DONE LayoutModel.BlockMap.get cs:119-122*/
            val start = element?.getAddress(Format.blockMap) ?: Pointer.null_
            return BlockCells(element?.model, start, width, height)
        }
    /*@END LayoutModel*/
}

data class MiniBlocksetModel(val element: ModelArrayElement?) { // cs:126-139
    val start: Int
        get() { /*@DONE MiniBlocksetModel.Start.get cs:127-127*/
            return element?.start ?: Pointer.null_
        }
    val blocksAddress: Int
        get() { /*@DONE MiniBlocksetModel.BlocksAddress.get cs:128-128*/
            return element?.getAddress(Format.blocks) ?: Pointer.null_
        }
    val tilesetAddress: Int
        get() { /*@DONE MiniBlocksetModel.TilesetAddress.get cs:129-129*/
            return element?.getAddress(Format.tileset) ?: Pointer.null_
        }
    val paletteAddress: Int
        get() { /*@DONE MiniBlocksetModel.PaletteAddress.get cs:130-130*/
            return element?.getAddress(Format.palette) ?: Pointer.null_
        }
    val attributeAddress: Int
        get() { /*@DONE MiniBlocksetModel.AttributeAddress.get cs:131-131*/
            return element?.getAddress(Format.blockAttributes) ?: Pointer.null_
        }
    val fullBlocksetModel: BlocksetModel
        get() { /*@DONE MiniBlocksetModel.FullBlocksetModel.get cs:132-132*/
            val element = element!!
            return BlocksetModel(element.model!!, element.start)
        }
    fun attribute(index: Int): TileAttribute? { /*@DONE MiniBlocksetModel.Attribute/1 cs:133-138*/
        val start = attributeAddress
        if (start == Pointer.null_) return null
        val model = element!!.model!!
        val length = if (model.isFRLG()) 4 else 2
        return TileAttribute.create(model.rawData, start + length * index, length)
    }
    /*@END MiniBlocksetModel*/
}

data class EventGroupModel(val element: ModelArrayElement?) { // cs:141-170
    val objects: MutableList<ObjectEventModel>?
        get() { /*@DONE EventGroupModel.Objects.get cs:143-147*/
            val element = element
            if (element == null) return ArrayList<ObjectEventModel>()
            val objects = Ref<ModelTable?>(null)
            if (!element.tryGetSubTable(Format.objects, objects)) return ArrayList<ObjectEventModel>()
            val result = ArrayList<ObjectEventModel>()
            for (obj in objects.value!!) result.add(ObjectEventModel(obj))
            return result
        }
    val scripts: MutableList<ScriptEventModel>
        get() { /*@DONE EventGroupModel.Scripts.get cs:150-154*/
            val element = element
            if (element == null) return ArrayList<ScriptEventModel>()
            val scripts = Ref<ModelTable?>(null)
            if (!element.tryGetSubTable(Format.scripts, scripts)) return ArrayList<ScriptEventModel>()
            val result = ArrayList<ScriptEventModel>()
            for (obj in scripts.value!!) result.add(ScriptEventModel(obj))
            return result
        }
    val warps: MutableList<WarpEventModel>
        get() { /*@DONE EventGroupModel.Warps.get cs:157-161*/
            val element = element
            if (element == null) return ArrayList<WarpEventModel>()
            val warps = Ref<ModelTable?>(null)
            if (!element.tryGetSubTable(Format.warps, warps)) return ArrayList<WarpEventModel>()
            val result = ArrayList<WarpEventModel>()
            for (obj in warps.value!!) result.add(WarpEventModel(obj))
            return result
        }
    val signposts: MutableList<SignpostEventModel>
        get() { /*@DONE EventGroupModel.Signposts.get cs:164-168*/
            val element = element
            if (element == null) return ArrayList<SignpostEventModel>()
            val signposts = Ref<ModelTable?>(null)
            if (!element.tryGetSubTable(Format.signposts, signposts)) return ArrayList<SignpostEventModel>()
            val result = ArrayList<SignpostEventModel>()
            for (sp in signposts.value!!) result.add(SignpostEventModel(sp))
            return result
        }
    /*@END EventGroupModel*/
}

interface IEventModel { // cs:172-177
    val element: ModelArrayElement?
    val x: Int
    val y: Int
    val elevation: Int
    /*@END IEventModel*/
}

open class BaseEventModel(override val element: ModelArrayElement?) : IEventModel { // cs:179-183
    override val x: Int
        get() { /*@DONE BaseEventModel.X.get cs:180-180*/
            val result = Ref(0)
            return if (element!!.tryGetValue("x", result)) result.value else 0
        }
    override val y: Int
        get() { /*@DONE BaseEventModel.Y.get cs:181-181*/
            val result = Ref(0)
            return if (element!!.tryGetValue("y", result)) result.value else 0
        }
    override val elevation: Int
        get() { /*@DONE BaseEventModel.Elevation.get cs:182-182*/
            val result = Ref(0)
            return if (element!!.tryGetValue("elevation", result)) result.value else 0
        }
    /*@END BaseEventModel*/
}

interface IScriptEventModel : IEventModel { // cs:185-187
    val scriptAddress: Int
    /*@END IScriptEventModel*/
}

class ObjectEventModel(element: ModelArrayElement?) : BaseEventModel(element), IScriptEventModel { // cs:189-193
    val graphics: Int
        get() { /*@DONE ObjectEventModel.Graphics.get cs:190-190*/
            val result = Ref(0)
            return if (element!!.tryGetValue("graphics", result)) result.value else -1
        }
    override val scriptAddress: Int
        get() { /*@DONE ObjectEventModel.ScriptAddress.get cs:191-191*/
            return element!!.getAddress("script")
        }
    val flag: Int
        get() { /*@DONE ObjectEventModel.Flag.get cs:192-192*/
            return element!!.getAddress("flag")
        }
    /*@END ObjectEventModel*/
}

class ScriptEventModel(element: ModelArrayElement?) : BaseEventModel(element), IScriptEventModel { // cs:195-197
    override val scriptAddress: Int
        get() { /*@DONE ScriptEventModel.ScriptAddress.get cs:196-196*/
            return element!!.getAddress("script")
        }
    /*@END ScriptEventModel*/
}

class WarpEventModel(element: ModelArrayElement?) : BaseEventModel(element) { // cs:199-223
    val targetMap: MapModel?
        get() { /*@DONE WarpEventModel.TargetMap.get cs:201-206*/
            val element = element!!
            val banks = AllMapsModel.create(element.model!!, { element.token })
            val bankModel = banks[bank]
            if (bankModel == null) return null
            return bankModel[map]
        }
    val warpID: Int
        get() { /*@DONE WarpEventModel.WarpID.get cs:208-208*/
            return element!!.getValue("warpID")
        }
    val bank: Int
        get() { /*@DONE WarpEventModel.Bank.get cs:209-209*/
            return element!!.getValue("bank")
        }
    val map: Int
        get() { /*@DONE WarpEventModel.Map.get cs:210-210*/
            return element!!.getValue("map")
        }
    val targetWarp: WarpEventModel?
        get() { /*@DONE WarpEventModel.TargetWarp.get cs:213-221*/
            val allmaps = AllMapsModel.create(element!!.model!!)
            val bankModel = allmaps[bank]
            if (bankModel == null) return null
            val mapModel = bankModel[map]
            if (mapModel == null) return null
            if (mapModel.events.warps.size <= warpID) return null
            return mapModel.events.warps[warpID]
        }
    /*@END WarpEventModel*/
}

class SignpostEventModel(element: ModelArrayElement?) : BaseEventModel(element), IScriptEventModel { // cs:225-234
    val kind: Int
        get() { /*@DONE SignpostEventModel.Kind.get cs:226-226*/
            return element!!.getValue("kind")
        }
    val arg: Int
        get() { /*@DONE SignpostEventModel.Arg.get cs:227-227*/
            return element!!.getValue("arg")
        }
    val hasScript: Boolean
        get() { /*@DONE SignpostEventModel.HasScript.get cs:228-228*/
            return kind < 5
        }
    val isHiddenItem: Boolean
        get() { /*@DONE SignpostEventModel.IsHiddenItem.get cs:229-229*/
            return kind.isAny(5, 6, 7)
        }
    val itemValue: Int
        get() { /*@DONE SignpostEventModel.ItemValue.get cs:230-230*/
            val element = element!!
            return element.model!!.readMultiByteValue(element.start + 8, 2)
        }
    val hiddenItemFlag: Int
        get() { /*@DONE SignpostEventModel.HiddenItemFlag.get cs:231-231*/
            val element = element!!
            return element.model!![element.start + 10]
        }
    val hiddenItemCount: Int
        get() { /*@DONE SignpostEventModel.HiddenItemCount.get cs:232-232*/
            val element = element!!
            return element.model!![element.start + 11]
        }
    override val scriptAddress: Int
        get() { /*@DONE SignpostEventModel.ScriptAddress.get cs:233-233*/
            val element = element!!
            return element.model!!.readPointer(element.start + 8)
        }
    /*@END SignpostEventModel*/
}

open class Format { // cs:236-306
    private lateinit var model: IDataModel
    private lateinit var cache: BlocksetCache
    val blocksetCache: BlocksetCache
        get() { /*@DONE Format.BlocksetCache.get cs:265-265*/
            return cache
        }
    var blockDataFormat: String = ""
        private set
    var layoutFormat: String = ""
        private set
    var objectsFormat: String = ""
        private set
    var warpsFormat: String = ""
        private set
    var scriptsFormat: String = ""
        private set
    var signpostsFormat: String = ""
        private set
    var eventsFormat: String = ""
        private set
    var connectionsFormat: String = ""
        private set
    var headerFormat: String = ""
        private set
    var mapFormat: String = ""
        private set
    constructor(model: IDataModel) { /*@DONE Format.<init>/1 cs:278-298*/
        this.model = model
        cache = BlocksetCache(ObservableCollection(), ObservableCollection())
        cache.calculateBlocksetOptions(model)
        val isRSE = !model.isFRLG()
        blockDataFormat = "[isCompressed. isSecondary. padding: ${tileset}<> ${palette}<`ucp4:0123456789ABCDEF`> ${blocks}<> ${tileAnimationRoutine}<> ${blockAttributes}<>]1"
        if (isRSE) blockDataFormat = "[isCompressed. isSecondary. padding: ${tileset}<> ${palette}<`ucp4:0123456789ABCDEF`> ${blocks}<> ${blockAttributes}<> ${tileAnimationRoutine}<>]1"
        layoutFormat = "[width:: height:: ${borderBlock}<> ${blockMap}<`blm`> ${primaryBlockset}<${blockDataFormat}> ${secondaryBlockset}<${blockDataFormat}> ${borderWidth}. ${borderHeight}. unused:]1"
        if (isRSE) layoutFormat = "[width:: height:: ${borderBlock}<> ${blockMap}<`blm`> ${primaryBlockset}<${blockDataFormat}> ${secondaryBlockset}<${blockDataFormat}>]1"
        var regionSectionIDFormat = "data.maps.names+88"
        if (isRSE) regionSectionIDFormat = "data.maps.names"
        val field3 = if (!isRSE) "kind:" else "unused:1"
        objectsFormat = "[id. graphics.${HardcodeTablesModel.overworldSprites} ${field3} x:|z y:|z elevation.11 moveType. range:|t|x::|y:: trainerType: trainerRangeOrBerryID: script<`xse`> flag:|h padding:]/${objectCount}"
        warpsFormat = "[x:|z y:|z elevation.11 warpID. map. bank.]/${warpCount}"
        scriptsFormat = "[x:|z y:|z elevation:11 trigger:|h index:: script<`xse`>]/${scriptCount}"
        signpostsFormat = "[x:|z y:|z elevation.11 kind. unused:1 arg::|h]/${signpostCount}"
        eventsFormat = "[${objectCount}. ${warpCount}. ${scriptCount}. ${signpostCount}. ${objects}<${objectsFormat}> ${warps}<${warpsFormat}> ${scripts}<${scriptsFormat}> ${signposts}<${signpostsFormat}>]1"
        connectionsFormat = "[count:: connections<[direction:: offset:: mapGroup. mapNum. unused:]/count>]1"
        headerFormat = "music:songnames layoutID:data.maps.layouts+1 regionSectionID.${regionSectionIDFormat} cave. weather. mapType. allowBiking. flags.|t|allowEscaping.|allowRunning.|showMapName::: floorNum. battleType."
        mapFormat = "[${layout}<${layoutFormat}> events<${eventsFormat}> mapscripts<[type. pointer<>]!00> ${connections}<${connectionsFormat}> ${headerFormat}]"
    }
    fun refresh() { /*@DONE Format.Refresh/1 cs:300-303*/
        cache = BlocksetCache(ObservableCollection(), ObservableCollection())
        cache.calculateBlocksetOptions(model)
    }
    var recentBank: Int = 0
    companion object {
        val regionSection: String
            get() { /*@DONE Format.RegionSection.get cs:237-237*/
                return "regionSectionID"
            }
        val events: String
            get() { /*@DONE Format.Events.get cs:238-238*/
                return "events"
            }
        val layout: String
            get() { /*@DONE Format.Layout.get cs:239-239*/
                return "layout"
            }
        val warps: String
            get() { /*@DONE Format.Warps.get cs:240-240*/
                return "warps"
            }
        val objects: String
            get() { /*@DONE Format.Objects.get cs:241-241*/
                return "objects"
            }
        val connections: String
            get() { /*@DONE Format.Connections.get cs:242-242*/
                return "connections"
            }
        val scripts: String
            get() { /*@DONE Format.Scripts.get cs:243-243*/
                return "scripts"
            }
        val signposts: String
            get() { /*@DONE Format.Signposts.get cs:244-244*/
                return "signposts"
            }
        val objectCount: String
            get() { /*@DONE Format.ObjectCount.get cs:245-245*/
                return "objectCount"
            }
        val warpCount: String
            get() { /*@DONE Format.WarpCount.get cs:246-246*/
                return "warpCount"
            }
        val scriptCount: String
            get() { /*@DONE Format.ScriptCount.get cs:247-247*/
                return "scriptCount"
            }
        val signpostCount: String
            get() { /*@DONE Format.SignpostCount.get cs:248-248*/
                return "signpostCount"
            }
        val borderBlock: String
            get() { /*@DONE Format.BorderBlock.get cs:249-249*/
                return "borderblock"
            }
        val blockMap: String
            get() { /*@DONE Format.BlockMap.get cs:250-250*/
                return "blockmap"
            }
        val primaryBlockset: String
            get() { /*@DONE Format.PrimaryBlockset.get cs:251-251*/
                return "blockdata1"
            }
        val secondaryBlockset: String
            get() { /*@DONE Format.SecondaryBlockset.get cs:252-252*/
                return "blockdata2"
            }
        val tileset: String
            get() { /*@DONE Format.Tileset.get cs:253-253*/
                return "tileset"
            }
        val blockAttributes: String
            get() { /*@DONE Format.BlockAttributes.get cs:254-254*/
                return "attributes"
            }
        val blocks: String
            get() { /*@DONE Format.Blocks.get cs:255-255*/
                return "blockset"
            }
        val tileAnimationRoutine: String
            get() { /*@DONE Format.TileAnimationRoutine.get cs:256-256*/
                return "animation"
            }
        val palette: String
            get() { /*@DONE Format.Palette.get cs:257-257*/
                return "pal"
            }
        val borderWidth: String
            get() { /*@DONE Format.BorderWidth.get cs:258-258*/
                return "borderwidth"
            }
        val borderHeight: String
            get() { /*@DONE Format.BorderHeight.get cs:259-259*/
                return "borderheight"
            }
        val isSecondary: String
            get() { /*@DONE Format.IsSecondary.get cs:260-260*/
                return "isSecondary"
            }
        /*@END Format.Companion*/
    }
    /*@END Format*/
}
