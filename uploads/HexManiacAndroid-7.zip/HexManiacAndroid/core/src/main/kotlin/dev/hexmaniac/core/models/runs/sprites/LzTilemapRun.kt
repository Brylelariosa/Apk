// Port of Models/Runs/Sprites/LzTilemapRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.sprites

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.dataformats.*

interface ITilemapRun : ISpriteRun { // cs:8-15
    val format: TilemapFormat
    val bytesPerTile: Int
    fun getTilemapData(): ByteArray
    fun findMatchingTileset(model: IDataModel): Int
    fun duplicate(format: TilemapFormat): ITilemapRun
    fun replaceData(newRawData: ByteArray, token: ModelDelta): ITilemapRun
    /*@END ITilemapRun*/
}

open class LzTilemapRun : LZRun, ITilemapRun { // cs:17-503
    override val spriteFormat: SpriteFormat
        get() { /*@DONE LzTilemapRun.SpriteFormat.get cs:19-29*/
            val m = model!!
            var hint: String? = null
            val address = m.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, format.matchingTileset)
            if (address >= 0 && address < m.count) {
                var tileset = m.getNextRun(address) as? ISpriteRun
                if (tileset == null) tileset = m.getNextRun(arrayTilesetAddress) as? ISpriteRun
                if (tileset != null && tileset !is LzTilemapRun) hint = tileset.spriteFormat.paletteHint
            }

            return SpriteFormat(format.bitsPerPixel, format.tileWidth, format.tileHeight, hint)
        }
    override val pages: Int
        get() { /*@DONE LzTilemapRun.Pages.get cs:31-31*/
            return 1
        }
    final override var format: TilemapFormat = TilemapFormat()
        private set
    override val supportsImport: Boolean
        get() { /*@DONE LzTilemapRun.SupportsImport.get cs:38-46*/
            val m = model!!
            val tilesetAddress = m.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, format.matchingTileset)
            var tileset = m.getNextRun(tilesetAddress) as? ISpriteRun
            if (tileset == null) {
                if (arrayTilesetAddress == 0) findMatchingTileset(m)
                tileset = m.getNextRun(arrayTilesetAddress) as? ISpriteRun
            }
            return tileset != null
        }
    override val supportsEdit: Boolean
        get() { /*@DONE LzTilemapRun.SupportsEdit.get cs:48-48*/
            return supportsImport
        }
    override var bytesPerTile: Int = 0
    override val formatString: String
        get() { /*@DONE LzTilemapRun.FormatString.get cs:51-54*/
            return "`lzm${format.bitsPerPixel}x${format.tileWidth}x${format.tileHeight}|${format.matchingTileset}" +
                (if (format.tilesetTableMember != null) "|" + format.tilesetTableMember else "") +
                "`"
        }
    constructor(format: TilemapFormat, data: IDataModel, start: Int, sources: SortedSpan<Int>? = null) : super(data, start, false, sources) { /*@DONE LzTilemapRun.<init>/1 cs:56-60*/
        this.format = format
        bytesPerTile = 2
        if (format.tileWidth * format.tileHeight * bytesPerTile > decompressedLength) bytesPerTile = 1
    }
    override fun getTilemapData(): ByteArray { /*@DONE LzTilemapRun.GetTilemapData/1 cs:103-103*/
        return decompress(model!!, start, allowLengthErrors) ?: ByteArray(0)
    }
    override fun getData(): ByteArray { /*@DONE LzTilemapRun.GetData/1 cs:105-115*/
        val m = model!!
        val tilesetAddress = m.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, format.matchingTileset)
        var tileset = m.getNextRun(tilesetAddress) as? ISpriteRun
        if (tileset == null) tileset = m.getNextRun(arrayTilesetAddress) as? ISpriteRun

        if (tileset == null) return ByteArray(format.tileWidth * 8 * format.tileHeight * format.bitsPerPixel)

        val tiles = tileset.getData()

        return LzTilemapRun.getData(getTilemapData(), tiles, format, bytesPerTile)
    }
    override fun getPixels(model: IDataModel, page: Int, tableIndex: Int): Array<IntArray>? { /*@DONE LzTilemapRun.GetPixels/1 cs:117-137*/
        val mapData = decompress(model, start, allowLengthErrors) ?: return null
        val firstAddress = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, format.matchingTileset)
        var tileset = model.getNextRun(firstAddress) as? ISpriteRun
        if (tileset == null) {
            if (tableIndex != -1) {
                val ignore = Ref(0)
                val tilesetAddress = LzTilemapRun.findMatchingTileset(this, this.model!!, tableIndex, ignore)
                tileset = model.getNextRun(tilesetAddress) as? ISpriteRun
            } else {
                tileset = model.getNextRun(arrayTilesetAddress) as? ISpriteRun
            }
        }

        if (tileset == null || tileset is ITilemapRun) return Array(format.tileWidth * 8) { IntArray(format.tileHeight * 8) } // relax the conditions slightly: if the run we found is an LZSpriteRun, that's close enough, we can use it as a tileset.

        val tiles = tileset.getData()
        return LzTilemapRun.getPixels(mapData, tiles, format, bytesPerTile)
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>): ISpriteRun { /*@DONE LzTilemapRun.SetPixels/1 cs:190-192*/
        return withTilesetAddress { address -> LzTilemapRun.setPixels(this, model, token, page, pixels, address) { data, delta -> replaceData(data, delta) } }
    }
    override fun setPixels(model: IDataModel, token: ModelDelta, tiles: List<Array<IntArray>>): ISpriteRun { /*@DONE LzTilemapRun.SetPixels/2 cs:195-195*/
        throw NotImplementedError()
    }
    override fun replaceData(newRawData: ByteArray, token: ModelDelta): ITilemapRun { /*@DONE LzTilemapRun.ReplaceData/1 cs:254-262*/
        val m = model!!
        val newModelData = compress(newRawData.asByteList(), 0, newRawData.size)
        var newRun = m.relocateForExpansion(token, this, newModelData.count)
        for (i in 0 until newModelData.count) token.changeData(m, newRun.start + i, newModelData[i])
        for (i in newModelData.count until length) token.changeData(m, newRun.start + i, 0xFF)
        newRun = LzTilemapRun(format, m, newRun.start, newRun.pointerSources)
        m.observeRunWritten(token, newRun)
        return newRun
    }
    private var arrayTilesetAddress: Int = 0
    override fun findMatchingTileset(model: IDataModel): Int { /*@DONE LzTilemapRun.FindMatchingTileset/1 cs:433-433*/
        return withTilesetAddress { address -> LzTilemapRun.findMatchingTileset(this, model, -1, address) }
    }
    private var lastFormatRequested: Int = /*@INITDONE LzTilemapRun.lastFormatRequested cs:482-482*/ Int.MAX_VALUE /*@ENDINIT*/
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE LzTilemapRun.CreateDataFormat/1 cs:483-495*/
        val basicFormat = super.createDataFormat(data, index)
        if (!createForLeftEdge || data.spartanMode) return basicFormat
        if (lastFormatRequested < index) {
            lastFormatRequested = index
            return basicFormat
        }

        val sprite = data.currentCacheScope.getImage(this)
        val availableRows = (length - (index - start)) / expectedDisplayWidth
        lastFormatRequested = index
        return SpriteDecorator(basicFormat, sprite, expectedDisplayWidth, availableRows)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE LzTilemapRun.Clone/1 cs:497-497*/
        return LzTilemapRun(format, model!!, start, newPointerSources)
    }
    override fun duplicate(format: SpriteFormat): ISpriteRun { /*@DONE LzTilemapRun.Duplicate/1 cs:499-499*/
        return LzSpriteRun(format, model!!, start, pointerSources)
    }
    // skipped method Duplicate: explicit implementation merged with the public member
    override fun duplicate(format: TilemapFormat): LzTilemapRun { /*@DONE LzTilemapRun.Duplicate/3 cs:502-502*/
        return LzTilemapRun(format, model!!, start, pointerSources)
    }
    companion object {
        fun tryParseTilemapFormat(format: String, tilemapFormat: Ref<TilemapFormat>): Boolean { /*@DONE LzTilemapRun.TryParseTilemapFormat/1 cs:62-72*/
            tilemapFormat.value = TilemapFormat()
            if (!(format.startsWith("`lzm") && format.endsWith("`"))) return false
            var text = format.substring(4, format.length - 1)
            var allowLengthErrors = false
            if (text.endsWith("!")) {
                text = text.substring(0, text.length - 1)
                allowLengthErrors = true
            }
            return tryParseGeneralTilemapFormat(text, allowLengthErrors, tilemapFormat)
        }
        fun tryParseGeneralTilemapFormat(format: String, allowLengthErrors: Boolean, tilemapFormat: Ref<TilemapFormat>): Boolean { /*@DONE LzTilemapRun.TryParseGeneralTilemapFormat/1 cs:74-101*/
            tilemapFormat.value = TilemapFormat()

            // parse the tilesetHint
            var text = format
            var hint: String? = null
            var tableMember: String? = null
            var pipeIndex = text.indexOf('|')
            if (pipeIndex != -1) {
                var hintText = text.substring(pipeIndex + 1)
                text = text.substring(0, pipeIndex)
                pipeIndex = hintText.indexOf('|')
                if (pipeIndex != -1) {
                    tableMember = hintText.substring(pipeIndex + 1)
                    hintText = hintText.substring(0, pipeIndex)
                }
                hint = hintText
            }

            val parts = text.split("x")
            if (parts.size != 3) return false
            val bitsRef = Ref(0)
            if (!tryParseInt(parts[0], bitsRef)) return false
            val bits = bitsRef.value
            if (!(bits == 1 || bits == 2 || bits == 4 || bits == 8)) return false
            val widthRef = Ref(0)
            if (!tryParseInt(parts[1], widthRef)) return false
            val width = widthRef.value
            val heightRef = Ref(0)
            if (!tryParseInt(parts[2], heightRef)) return false
            val height = heightRef.value
            if (width < 0 || height < 0) return false
            if (width > 100 || height > 100) return false

            tilemapFormat.value = TilemapFormat(bits, width, height, hint, tableMember, allowLengthErrors)
            return true
        }
        fun readTileData(mapData: ByteArray, tile: Int, bytesPerTile: Int): LzTilemapRunReadTileDataTuple { /*@DONE LzTilemapRun.ReadTileData/1 cs:141-149*/
            if (bytesPerTile == 1) return LzTilemapRunReadTileDataTuple(0, false, false, mapData[tile].toInt() and 0xFF)
            val map = readLittleEndian(mapData, tile * 2, 2)
            val tileIndex = map and 0x3FF
            val hFlip = ((map shr 10) and 0x1) == 1
            val vFlip = ((map shr 11) and 0x1) == 1
            val paletteIndex = (map shr 12) and 0xF
            return LzTilemapRunReadTileDataTuple(paletteIndex, hFlip, vFlip, tileIndex)
        }
        fun writeTileData(tileData: ByteArray, index: Int, paletteIndex: Int, hFlip: Boolean, vFlip: Boolean, tileIndex: Int) { /*@DONE LzTilemapRun.WriteTileData/1 cs:151-159*/
            var packedData = 0
            packedData = packedData or tileIndex
            if (hFlip) packedData = packedData or (1 shl 10)
            if (vFlip) packedData = packedData or (1 shl 11)
            packedData = packedData or (paletteIndex shl 12)
            tileData[index * 2 + 0] = packedData.toByte()
            tileData[index * 2 + 1] = (packedData shr 8).toByte()
        }
        fun getPixels(mapData: ByteArray, tiles: ByteArray, format: TilemapFormat, bytesPerTile: Int): Array<IntArray> { /*@DONE LzTilemapRun.GetPixels/2 cs:161-184*/
            val tileSize = format.bitsPerPixel * 8
            val result = Array(format.tileWidth * 8) { IntArray(format.tileHeight * 8) }
            val tileBytes = tiles.asByteList()
            for (y in 0 until format.tileHeight) {
                val yStart = y * 8
                for (x in 0 until format.tileWidth) {
                    val tileData = readTileData(mapData, format.tileWidth * y + x, bytesPerTile)
                    val hFlip = tileData.hFlip
                    val vFlip = tileData.vFlip

                    val pal = tileData.paletteIndex shl 4
                    val tileStart = tileData.tileIndex * tileSize
                    val pixels = SpriteRun.getPixels(tileBytes, tileStart, 1, 1, format.bitsPerPixel) // TODO cache this during this method so we don't load the same tile more than once
                    val xStart = x * 8
                    for (yy in 0 until 8) {
                        for (xx in 0 until 8) {
                            val inX = if (hFlip) 7 - xx else xx
                            val inY = if (vFlip) 7 - yy else yy
                            result[xStart + xx][yStart + yy] = pixels[inX][inY] + pal
                        }
                    }
                }
            }

            return result
        }
        fun getData(mapData: ByteArray, tiles: ByteArray, format: TilemapFormat, bytesPerTile: Int): ByteArray { /*@DONE LzTilemapRun.GetData/2 cs:186-188*/
            throw NotImplementedError()
        }
        fun setPixels(run: ITilemapRun, model: IDataModel, token: ModelDelta, page: Int, pixels: Array<IntArray>, arrayTilesetAddress: Ref<Int>, replaceData: (ByteArray, ModelDelta) -> ITilemapRun): ITilemapRun { /*@DONE LzTilemapRun.SetPixels/3 cs:197-251*/
            val tileData = tilize(pixels, run.format.bitsPerPixel)
            var tiles = getUniqueTiles(tileData, run.bytesPerTile == 2)
            val tilesetAddress = model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, run.format.matchingTileset)
            var tileset = model.getNextRun(tilesetAddress) as? ISpriteRun
            if (tileset == null) {
                findMatchingTileset(run, model, -1, arrayTilesetAddress)
                tileset = model.getNextRun(arrayTilesetAddress.value) as? ISpriteRun
            }
            if (tileset == null) return run // the original would crash with a NullReferenceException here

            val tilesToKeep = HashSet<Int>()
            for (i in 0 until (tileset.decompressedLength / tileset.spriteFormat.bitsPerPixel / 8)) tilesToKeep.add(i)
            val originalUsedTiles = getUsedTiles(run).toHashSet()
            for (tile in originalUsedTiles) tilesToKeep.remove(tile)
            for (tile in tileset.getFillerTiles()) tilesToKeep.remove(tile)
            for (tilemap in tileset.findDependentTilemaps(model).filter { it !== run }) {
                tilesToKeep.addAll(getUsedTiles(tilemap))
            }
            tilesToKeep.add(0) // always keep the 'transparency' tile
            val oldTileDataRaw = tileset.getData()
            val previousTiles = tilize(oldTileDataRaw, run.format.bitsPerPixel)

            // if the new tiledata matches the previous tiledata
            val tileWidth = tileData.size
            val tileHeight = if (tileData.isEmpty()) 0 else tileData[0].size
            if (tileWidth == 0) return run // the original would divide by zero here
            val originalTilemap = getUsedTiles(run).toList()
            for (i in 0 until originalTilemap.size) {
                val y = i / tileWidth
                val x = i % tileWidth
                if (y >= tileHeight) break
                if (previousTiles.size <= originalTilemap[i]) break
                if (tilesMatch(previousTiles[originalTilemap[i]], tileData[x][y].pixels, false) == TileMatchType.Normal) tilesToKeep.add(originalTilemap[i])
            }

            tiles = mergeTilesets(previousTiles, tilesToKeep, tiles, run.bytesPerTile == 2)
            tileset.setPixels(model, token, tiles)
            val mapData = run.getTilemapData()

            for (y in 0 until tileHeight) {
                for (x in 0 until tileWidth) {
                    val i = y * tileWidth + x
                    val tile = tileData[x][y].pixels
                    val paletteIndex = tileData[x][y].palette
                    val match = findMatch(tile, tiles, run.bytesPerTile == 2)
                    var tileIndex = match.index
                    if (tileIndex == -1) tileIndex = 0
                    if (run.bytesPerTile == 2) {
                        val mapping = packMapping(paletteIndex, match.matchType, tileIndex)
                        mapData[i * 2 + 0] = mapping.toByte()
                        mapData[i * 2 + 1] = (mapping shr 8).toByte()
                    } else {
                        mapData[i] = tileIndex.toByte()
                    }
                }
            }

            return replaceData(mapData, token)
        }
        fun getUsedTiles(tilemap: ITilemapRun): Iterable<Int> { /*@DONE LzTilemapRun.GetUsedTiles/1 cs:264-273*/
            val result = ArrayList<Int>()
            val mapData = tilemap.getTilemapData()
            for (y in 0 until tilemap.format.tileHeight) {
                for (x in 0 until tilemap.format.tileWidth) {
                    val map = readLittleEndian(mapData, (tilemap.format.tileWidth * y + x) * tilemap.bytesPerTile, tilemap.bytesPerTile)
                    val tile = map and 0x3FF
                    result.add(tile)
                }
            }
            return result
        }
        fun packMapping(paletteIndex: Int, matchType: TileMatchType, tileIndex: Int): Int { /*@DONE LzTilemapRun.PackMapping/1 cs:275-279*/
            val hFlip = if (matchType == TileMatchType.HFlip || matchType == TileMatchType.BFlip) 1 else 0
            val vFlip = if (matchType == TileMatchType.VFlip || matchType == TileMatchType.BFlip) 1 else 0
            return (paletteIndex shl 12) or (vFlip shl 11) or (hFlip shl 10) or tileIndex
        }
        fun mergeTilesets(previous: List<Array<IntArray>>, tilesToKeep: MutableSet<Int>, newTiles: List<Array<IntArray>>, allowFlips: Boolean): List<Array<IntArray>> { /*@DONE LzTilemapRun.MergeTilesets/1 cs:281-334*/
            // if any of the newTiles match existing tiles, keep those existing tiles in the same spot.
            for (i in 0 until newTiles.size) {
                val match = findMatch(newTiles[i], previous, allowFlips)
                if (match.index != -1) tilesToKeep.add(match.index)
            }

            var newListIndex = 0
            val mergedList = ArrayList<Array<IntArray>>()

            // merge the used-previous tiles in with the new tiles, until we've used up all the old tiles or all the new tiles
            for (i in 0 until previous.size) {
                if (tilesToKeep.contains(i)) {
                    mergedList.add(previous[i])
                } else {
                    while (newListIndex < newTiles.size) {
                        // if this new tile has already been added to the merged list, skip it
                        if (findMatch(newTiles[newListIndex], mergedList, allowFlips).index != -1) {
                            newListIndex += 1
                            continue
                        }
                        // if this new tile will later be added at a different index, skip it
                        if (findMatch(newTiles[newListIndex], previous, allowFlips).index != -1) {
                            newListIndex += 1
                            continue
                        }
                        break
                    }
                    if (newListIndex == newTiles.size) break
                    mergedList.add(newTiles[newListIndex])
                    newListIndex += 1
                }
            }

            // if we have any previous tiles left over, add them in (or skip them if they're unused)
            for (i in mergedList.size until previous.size) {
                if (tilesToKeep.contains(i)) {
                    mergedList.add(previous[i])
                } else {
                    // we don't need this tile at all
                    // we want to truncate
                    // but we have to stick _something_ in, for alignment
                    mergedList.add(previous[0])
                }
            }

            // if we have any new tiles left over, add them in at the end (expanded the number of tiles)
            while (newListIndex < newTiles.size) {
                if (findMatch(newTiles[newListIndex], mergedList, allowFlips).index == -1) mergedList.add(newTiles[newListIndex])
                newListIndex += 1
            }

            return mergedList
        }
        fun tilize(rawData: ByteArray, bitsPerPixel: Int): List<Array<IntArray>> { /*@DONE LzTilemapRun.Tilize/1 cs:336-343*/
            val results = ArrayList<Array<IntArray>>()
            val tileSize = 8 * bitsPerPixel
            val data = rawData.asByteList()
            var i = 0
            while (i < rawData.size) {
                results.add(SpriteRun.getPixels(data, i, 1, 1, bitsPerPixel))
                i += tileSize
            }
            return results
        }
        fun tilize(pixels: Array<IntArray>, bitsPerPixel: Int): Array<Array<LzTilemapRunTilizeTuple>> { /*@DONE LzTilemapRun.Tilize/2 cs:345-368*/
            val width = pixels.size
            val tileWidth = width / 8
            val height = if (pixels.isEmpty()) 0 else pixels[0].size
            val tileHeight = height / 8
            val mod = if (bitsPerPixel == 4) 16 else 256
            return Array(tileWidth) { x ->
                Array(tileHeight) { y ->
                    val xStart = x * 8
                    val yStart = y * 8
                    val palette = pixels[xStart][yStart] / mod
                    val tile = Array(8) { IntArray(8) }
                    for (yy in 0 until 8) {
                        for (xx in 0 until 8) {
                            tile[xx][yy] = pixels[xStart + xx][yStart + yy] % mod
                        }
                    }
                    LzTilemapRunTilizeTuple(tile, palette)
                }
            }
        }
        fun getUniqueTiles(tiles: Array<Array<LzTilemapRunTilizeTuple>>, allowFlips: Boolean): List<Array<IntArray>> { /*@DONE LzTilemapRun.GetUniqueTiles/1 cs:370-387*/
            val tileLimit = if (allowFlips) 0x400 else 0x100 // only so many unique tiles are allowed
            val tileWidth = tiles.size
            val tileHeight = if (tiles.isEmpty()) 0 else tiles[0].size
            val result = ArrayList<Array<IntArray>>()
            result.add(Array(8) { IntArray(8) }) // first tile is always the 'empty' tile. Important for transparency/layering stuff.
            for (y in 0 until tileHeight) {
                for (x in 0 until tileWidth) {
                    if (result.size == tileLimit) break
                    val pixels = tiles[x][y].pixels
                    if (result.any { tile -> tilesMatch(tile, pixels, allowFlips) != TileMatchType.None }) continue
                    result.add(pixels)
                }
            }

            return result
        }
        fun tilesMatch(a: Array<IntArray>, b: Array<IntArray>, flipPossible: Boolean): TileMatchType { /*@DONE LzTilemapRun.TilesMatch/1 cs:389-415*/
            var normalPossible = true
            var hFlipPossible = flipPossible
            var vFlipPossible = flipPossible
            var bFlipPossible = flipPossible

            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    normalPossible = normalPossible && a[x][y] == b[x][y]
                    hFlipPossible = hFlipPossible && a[x][y] == b[7 - x][y]
                    vFlipPossible = vFlipPossible && a[x][y] == b[x][7 - y]
                    bFlipPossible = bFlipPossible && a[x][y] == b[7 - x][7 - y]
                }
                if (!normalPossible && !hFlipPossible && !vFlipPossible && !bFlipPossible) return TileMatchType.None
            }

            if (normalPossible) return TileMatchType.Normal
            if (hFlipPossible) return TileMatchType.HFlip
            if (vFlipPossible) return TileMatchType.VFlip
            if (bFlipPossible) return TileMatchType.BFlip
            return TileMatchType.None
        }
        fun findMatch(tile: Array<IntArray>, collection: List<Array<IntArray>>, allowFlips: Boolean): LzTilemapRunFindMatchTuple { /*@DONE LzTilemapRun.FindMatch/1 cs:421-430*/
            var bestIndex = -1
            var bestMatch = TileMatchType.None
            for (i in 0 until collection.size) {
                val match = tilesMatch(tile, collection[i], allowFlips)
                if (match == TileMatchType.None) continue
                if (match == TileMatchType.Normal) return LzTilemapRunFindMatchTuple(i, match)
                if (bestIndex == -1) {
                    bestIndex = i
                    bestMatch = match
                }
            }
            return LzTilemapRunFindMatchTuple(bestIndex, bestMatch)
        }
        fun findMatchingTileset(run: ITilemapRun, model: IDataModel, arrayIndex: Int, arrayTilesetAddress: Ref<Int>): Int { /*@DONE LzTilemapRun.FindMatchingTileset/2 cs:434-480*/
            val hint: String? = run.format.matchingTileset
            val hintRun: IFormattedRun?
            val sources = run.pointerSources
            if (hint != null) {
                hintRun = model.getNextRun(model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, hint))
            } else {
                hintRun = if (sources != null && sources.size > 0) model.getNextRun(sources[0]) else null
            }

            // easy case: the hint is the address of a tileset
            if (hintRun is LzTilesetRun) {
                arrayTilesetAddress.value = hintRun.start
                return arrayTilesetAddress.value
            }

            // harder case: the hint is a table
            if (hintRun == null) return Pointer.null_
            if (hintRun !is ITableRun) return hintRun.start
            if (sources == null || sources.size == 0) return Pointer.null_
            var tilemapPointer = sources[0]
            var tilemapTable = model.getNextRun(tilemapPointer) as? ITableRun
            var sourceIndex = 1
            while (sourceIndex < sources.size && tilemapTable == null) {
                tilemapPointer = sources[sourceIndex]
                tilemapTable = model.getNextRun(tilemapPointer) as? ITableRun
                sourceIndex += 1
            }
            if (tilemapTable == null) return hintRun.start
            var tilemapIndex = (tilemapPointer - tilemapTable.start) / tilemapTable.elementLength
            if (arrayIndex != -1) tilemapIndex = arrayIndex

            // get which element of the table has the tileset
            var segmentOffset = 0
            for (i in 0 until hintRun.elementContent.size) {
                val segment = hintRun.elementContent[i]
                if (segment is ArrayRunPointerSegment) {
                    if (run.format.tilesetTableMember == null || segment.name == run.format.tilesetTableMember) {
                        if (LzTilesetRun.tryParseTilesetFormat(segment.innerFormat, Ref(TilesetFormat()))) {
                            val source = hintRun.start + hintRun.elementLength * tilemapIndex + segmentOffset
                            val tilesetRun = model.getNextRun(model.readPointer(source))
                            if (tilesetRun is LzTilesetRun) {
                                arrayTilesetAddress.value = tilesetRun.start
                                return arrayTilesetAddress.value
                            }
                        }
                    }
                }
                segmentOffset += hintRun.elementContent[i].length
            }

            return hintRun.start
        }
        /*@ADD LzTilemapRun.Companion#runs_12.txt*/
        private fun readLittleEndian(data: ByteArray, index: Int, length: Int): Int {
            var result = 0
            var remaining = length
            while (remaining > 0) {
                result = result shl 8
                result += data[index + remaining - 1].toInt() and 0xFF
                remaining -= 1
            }
            return result
        }
        /*@ENDADD LzTilemapRun.Companion#runs_12.txt*/
        /*@END LzTilemapRun.Companion*/
    }
    /*@ADD LzTilemapRun#runs_12.txt*/
    // C# passes the private field arrayTilesetAddress by ref; emulate with a copy-in/write-back Ref.
    private fun <T> withTilesetAddress(action: (Ref<Int>) -> T): T {
        val address = Ref(arrayTilesetAddress)
        try {
            return action(address)
        } finally {
            arrayTilesetAddress = address.value
        }
    }
    /*@ENDADD LzTilemapRun#runs_12.txt*/
    /*@END LzTilemapRun*/
}

enum class TileMatchType(val value: Int) { // cs:505-505
    None(0),
    Normal(1),
    HFlip(2),
    VFlip(3),
    BFlip(4);
    companion object {
        fun fromValue(value: Int): TileMatchType = entries.first { it.value == value }
    }
    /*@END TileMatchType*/
}

data class LzTilemapRunReadTileDataTuple(val paletteIndex: Int, val hFlip: Boolean, val vFlip: Boolean, val tileIndex: Int)

data class LzTilemapRunTilizeTuple(val pixels: Array<IntArray>, val palette: Int)

data class LzTilemapRunGetUniqueTilesTilesTuple(val pixels: Array<IntArray>, val palette: Int)

data class LzTilemapRunFindMatchTuple(val index: Int, val matchType: TileMatchType)
