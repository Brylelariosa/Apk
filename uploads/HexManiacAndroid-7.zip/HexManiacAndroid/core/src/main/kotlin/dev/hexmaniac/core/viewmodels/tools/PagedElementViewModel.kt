// Port of ViewModels/Tools/PagedElementViewModel.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels.tools

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.models.runs.sprites.*

abstract class PagedElementViewModel : StreamElementViewModel, IPagedViewModel { // cs:6-114
    override val showPageControls: Boolean
        get() { /*@DONE PagedElementViewModel.ShowPageControls.get cs:8-8*/
            return pages > 1 || canExecuteAddPage()
        }
    private var _currentPage: Int = 0
    override var currentPage: Int
        get() { /*@DONE PagedElementViewModel.CurrentPage.get cs:12-12*/
            return _currentPage
        }
        set(value) { /*@DONE PagedElementViewModel.CurrentPage.set cs:13-20*/
            val newPage = if (pages == 0) value else value % pages
            if (!tryUpdate(_currentPage, newPage, "currentPage") { _currentPage = it }) return
            notifyPropertyChanged("canMovePrevious")
            notifyPropertyChanged("canMoveNext")
            updateOtherPagedViewModels()
            _addPage?.raiseCanExecuteChanged()
            pageChanged()
        }
    override var pages: Int = 0
        protected set
    override val canMovePrevious: Boolean
        get() { /*@DONE PagedElementViewModel.CanMovePrevious.get cs:27-27*/
            return _currentPage > 0
        }
    override val canMoveNext: Boolean
        get() { /*@DONE PagedElementViewModel.CanMoveNext.get cs:28-28*/
            return _currentPage < pages - 1
        }
    override fun movePrevious() { /*@DONE PagedElementViewModel.MovePrevious/1 cs:29-29*/
        currentPage -= 1
    }
    override fun moveNext() { /*@DONE PagedElementViewModel.MoveNext/1 cs:30-30*/
        currentPage += 1
    }
    private var _addPage: StubCommand? = null
    private var _deletePage: StubCommand? = null
    override val addPage: ICommand
        get() { /*@DONE PagedElementViewModel.AddPage.get cs:33-33*/
            return _addPage ?: stubCommand({ executeAddPage() }, { canExecuteAddPage() }).also { _addPage = it }
        }
    override val deletePage: ICommand
        get() { /*@DONE PagedElementViewModel.DeletePage.get cs:34-34*/
            return _deletePage ?: stubCommand({ executeDeletePage() }, { canExecuteDeletePage() }).also { _deletePage = it }
        }
    protected abstract fun canExecuteAddPage(): Boolean
    protected abstract fun canExecuteDeletePage(): Boolean
    protected open fun executeAddPage() { /*@DONE PagedElementViewModel.ExecuteAddPage/1 cs:39-57*/
        val destination = viewPort.model.readPointer(start)
        val run = viewPort.model.getNextRun(destination) as? PagedLZRun ?: return
        val newRun = run.appendPage(viewPort.currentChange)
        if (newRun.start != run.start) {
            viewPort.raiseMessage("Data moved from " + run.start.toHex(6) + " to " + newRun.start.toHex(6) + ". Pointers were updated.")
        }
        pages = newRun.pages
        _currentPage = newRun.pages - 1

        for (child in viewPort.tools!!.tableTool!!.children) {
            if (child !is PagedElementViewModel) continue
            if (child.pages == pages - 1) child.executeAddPage()
        }
        _deletePage?.raiseCanExecuteChanged()
        notifyPropertyChanged("canMovePrevious")

        pageChanged()
    }
    protected open fun executeDeletePage() { /*@DONE PagedElementViewModel.ExecuteDeletePage/1 cs:59-74*/
        val destination = viewPort.model.readPointer(start)
        val run = viewPort.model.getNextRun(destination) as? PagedLZRun ?: return
        val newRun = run.deletePage(currentPage, viewPort.currentChange)
        pages = newRun.pages
        if (currentPage >= pages) _currentPage = pages - 1

        for (child in viewPort.tools!!.tableTool!!.children) {
            if (child !is PagedElementViewModel) continue
            if (child.pages == pages + 1) child.executeDeletePage()
        }
        _deletePage?.raiseCanExecuteChanged()
        notifyPropertyChanged("canMoveNext")

        pageChanged()
    }
    protected constructor(viewPort: ViewPort, parentName: String, runFormat: String, start: Int) : super(viewPort, parentName, runFormat, start) { /*@DONE PagedElementViewModel.<init>/1 cs:78-84*/
        pages = 1

        // update usage count, assuming that our run is paged.
        val pagedRun = model.getNextRun(model.readPointer(start)) as? IPagedRun
        usageCount = pagedRun?.pointerSources?.size ?: 0
    }
    fun updateOtherPagedViewModels() { /*@DONE PagedElementViewModel.UpdateOtherPagedViewModels/1 cs:86-91*/
        for (child in viewPort.tools!!.tableTool!!.children) {
            if (child !is IPagedViewModel) continue
            child.currentPage = if (child.pages > currentPage) currentPage else 0
        }
    }
    protected override fun tryCopy(other: StreamElementViewModel): Boolean { /*@DONE PagedElementViewModel.TryCopy/1 cs:93-109*/
        val that = other as? PagedElementViewModel ?: return false
        if (!tryCopy(that)) return false

        _currentPage = that._currentPage
        pages = that.pages
        notifyPropertyChanged("pages")
        start = that.start // required in order to update the ShowPageControls value
        notifyPropertyChanged("showPageControls")
        _addPage?.raiseCanExecuteChanged()
        _deletePage?.raiseCanExecuteChanged()
        notifyPropertyChanged("currentPage")
        notifyPropertyChanged("canMovePrevious")
        notifyPropertyChanged("canMoveNext")

        return true
    }
    protected abstract fun tryCopy(other: PagedElementViewModel): Boolean
    protected abstract fun pageChanged()
    /*@END PagedElementViewModel*/
}
