// Port of ViewModels/Theme.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*

open class Theme : ViewModelCore { // cs:7-245
    private var _primaryColor: String = ""
    private var _backgroundColor: String = ""
    private var _hueOffset: Double = 0.0
    private var _accentSaturation: Double = 0.0
    private var _accentValue: Double = 0.0
    private var _highlightBrightness: Double = 0.0
    var primaryColor: String
        get() { /*@DONE Theme.PrimaryColor.get cs:11-11*/
            return _primaryColor
        }
        set(value) { /*@DONE Theme.PrimaryColor.set cs:11-11*/
            if (tryUpdate(_primaryColor, value, "primaryColor") { _primaryColor = it }) updateTheme()
        }
    var backgroundColor: String
        get() { /*@DONE Theme.BackgroundColor.get cs:12-12*/
            return _backgroundColor
        }
        set(value) { /*@DONE Theme.BackgroundColor.set cs:12-12*/
            if (tryUpdate(_backgroundColor, value, "backgroundColor") { _backgroundColor = it }) updateTheme()
        }
    var hueOffset: Double
        get() { /*@DONE Theme.HueOffset.get cs:13-13*/
            return _hueOffset
        }
        set(value) { /*@DONE Theme.HueOffset.set cs:13-13*/
            if (tryUpdate(_hueOffset, value, "hueOffset") { _hueOffset = it }) updateTheme()
        }
    var accentSaturation: Double
        get() { /*@DONE Theme.AccentSaturation.get cs:14-14*/
            return _accentSaturation
        }
        set(value) { /*@DONE Theme.AccentSaturation.set cs:14-14*/
            if (tryUpdate(_accentSaturation, value, "accentSaturation") { _accentSaturation = it }) updateTheme()
        }
    var accentValue: Double
        get() { /*@DONE Theme.AccentValue.get cs:15-15*/
            return _accentValue
        }
        set(value) { /*@DONE Theme.AccentValue.set cs:15-15*/
            if (tryUpdate(_accentValue, value, "accentValue") { _accentValue = it }) updateTheme()
        }
    var highlightBrightness: Double
        get() { /*@DONE Theme.HighlightBrightness.get cs:16-16*/
            return _highlightBrightness
        }
        set(value) { /*@DONE Theme.HighlightBrightness.set cs:16-16*/
            if (tryUpdate(_highlightBrightness, value, "highlightBrightness") { _highlightBrightness = it }) updateTheme()
        }
    constructor(file: Array<String>) { /*@DONE Theme.<init>/1 cs:18-35*/
        reset()
        var acceptingEntries = false
        for (entry in file) {
            val line = entry.lowercase()
            if (line.contains("[")) acceptingEntries = false
            if (line.contains("[theme]")) acceptingEntries = true
            if (!acceptingEntries) continue

            if (line.startsWith("primarycolor")) _primaryColor = line.split('"').filter { piece -> piece.isNotEmpty() }.last()
            if (line.startsWith("backgroundcolor")) _backgroundColor = line.split('"').filter { piece -> piece.isNotEmpty() }.last()
            if (line.startsWith("hueoffset")) _hueOffset = line.substring(line.indexOf('=') + 1).trim().toDoubleOrNull() ?: 0.0
            if (line.startsWith("accentsaturation")) _accentSaturation = line.substring(line.indexOf('=') + 1).trim().toDoubleOrNull() ?: 0.0
            if (line.startsWith("accentvalue")) _accentValue = line.substring(line.indexOf('=') + 1).trim().toDoubleOrNull() ?: 0.0
            if (line.startsWith("highlightbrightness")) _highlightBrightness = line.substring(line.indexOf('=') + 1).trim().toDoubleOrNull() ?: 0.0
        }
        updateTheme()
    }
    fun serialize(): Array<String> { /*@DONE Theme.Serialize/1 cs:37-47*/
        return arrayOf(
            "[Theme]",
            "PrimaryColor = \"" + primaryColor + "\"",
            "BackgroundColor = \"" + backgroundColor + "\"",
            "HueOffset= " + themeDoubleText(hueOffset),
            "AccentSaturation = " + themeDoubleText(accentSaturation),
            "AccentValue = " + themeDoubleText(accentValue),
            "HighlightBrightness = " + themeDoubleText(highlightBrightness)
        )
    }
    fun reset() { /*@DONE Theme.Reset/1 cs:49-57*/
        tryUpdate(_primaryColor, "#DDDDDD", "primaryColor") { _primaryColor = it }
        tryUpdate(_backgroundColor, "#222222", "backgroundColor") { _backgroundColor = it }
        tryUpdate(_hueOffset, 0.1, "hueOffset") { _hueOffset = it }
        tryUpdate(_accentSaturation, 0.7, "accentSaturation") { _accentSaturation = it }
        tryUpdate(_accentValue, 0.7, "accentValue") { _accentValue = it }
        tryUpdate(_highlightBrightness, 0.6, "highlightBrightness") { _highlightBrightness = it }
        updateTheme()
    }
    private fun updateTheme() { /*@DONE Theme.UpdateTheme/1 cs:85-125*/
        val uiPrimaryRef = Ref(ThemeTryConvertColorColorTuple(0, 0, 0))
        if (!tryConvertColor(_primaryColor, uiPrimaryRef)) return
        val uiBackgroundRef = Ref(ThemeTryConvertColorColorTuple(0, 0, 0))
        if (!tryConvertColor(_backgroundColor, uiBackgroundRef)) return
        val uiPrimary = uiPrimaryRef.value
        val uiBackground = uiBackgroundRef.value
        val hsbPrimary = toHSB(uiPrimary.r, uiPrimary.g, uiPrimary.b)
        val hsbBackground = toHSB(uiBackground.r, uiBackground.g, uiBackground.b)

        val darkHue = hsbBackground.hue
        var darkSat = hsbBackground.sat
        var darkBright: Double

        val brightnessTravel = .6 + .3 * _highlightBrightness
        darkSat *= .8
        darkBright = 1 - brightnessTravel
        if (hsbPrimary.bright < hsbBackground.bright) darkBright = brightnessTravel
        backlight = themeHsbToHex(darkHue, darkSat, darkBright)

        val lightBright = (hsbBackground.bright + hsbPrimary.bright) / 2
        secondary = themeHsbToHex(hsbPrimary.hue, 0.0, lightBright)

        val accentColors = ArrayList<DoubleArray>()
        val saturation = _accentSaturation * .8 + .2
        val accentBrightness = _accentValue * .6 + .4
        var prototypeHue = (_hueOffset - .5) / 12
        for (i in 0 until 8) {
            accentColors.add(doubleArrayOf(prototypeHue, saturation, accentBrightness))
            prototypeHue += 1 / 8.0
        }

        error = themeHsbToHex(accentColors[0][0], accentColors[0][1], accentColors[0][2])
        text1 = themeHsbToHex(accentColors[1][0], accentColors[1][1], accentColors[1][2])
        data1 = themeHsbToHex(accentColors[2][0], accentColors[2][1], accentColors[2][2])
        stream2 = themeHsbToHex(accentColors[3][0], accentColors[3][1], accentColors[3][2])
        data2 = themeHsbToHex(accentColors[4][0], accentColors[4][1], accentColors[4][2])
        accent = themeHsbToHex(accentColors[5][0], accentColors[5][1], accentColors[5][2])
        text2 = themeHsbToHex(accentColors[6][0], accentColors[6][1], accentColors[6][2])
        stream1 = themeHsbToHex(accentColors[7][0], accentColors[7][1], accentColors[7][2])
        editBackground = splice(ThemeSpliceColor1Tuple(darkHue, darkSat, darkBright), ThemeSpliceColor2Tuple(accentColors[2][0], accentColors[2][1], accentColors[2][2]), .1)

        notifyPropertyChanged("primary")
        notifyPropertyChanged("background")
    }
    private var _secondary: String = ""
    private var _backlight: String = ""
    var secondary: String
        get() { /*@DONE Theme.Secondary.get cs:128-128*/
            return _secondary
        }
        set(value) { /*@DONE Theme.Secondary.set cs:128-128*/
            tryUpdate(_secondary, value, "secondary") { _secondary = it }
        }
    var backlight: String
        get() { /*@DONE Theme.Backlight.get cs:129-129*/
            return _backlight
        }
        set(value) { /*@DONE Theme.Backlight.set cs:129-129*/
            tryUpdate(_backlight, value, "backlight") { _backlight = it }
        }
    private var _error: String = ""
    private var _text1: String = ""
    private var _text2: String = ""
    private var _data1: String = ""
    private var _data2: String = ""
    private var _accent: String = ""
    private var _stream1: String = ""
    private var _stream2: String = ""
    private var _editBackground: String = ""
    var error: String
        get() { /*@DONE Theme.Error.get cs:132-132*/
            return _error
        }
        set(value) { /*@DONE Theme.Error.set cs:132-132*/
            tryUpdate(_error, value, "error") { _error = it }
        }
    var text1: String
        get() { /*@DONE Theme.Text1.get cs:133-133*/
            return _text1
        }
        set(value) { /*@DONE Theme.Text1.set cs:133-133*/
            tryUpdate(_text1, value, "text1") { _text1 = it }
        }
    var text2: String
        get() { /*@DONE Theme.Text2.get cs:134-134*/
            return _text2
        }
        set(value) { /*@DONE Theme.Text2.set cs:134-134*/
            tryUpdate(_text2, value, "text2") { _text2 = it }
        }
    var data1: String
        get() { /*@DONE Theme.Data1.get cs:135-135*/
            return _data1
        }
        set(value) { /*@DONE Theme.Data1.set cs:135-135*/
            tryUpdate(_data1, value, "data1") { _data1 = it }
        }
    var data2: String
        get() { /*@DONE Theme.Data2.get cs:136-136*/
            return _data2
        }
        set(value) { /*@DONE Theme.Data2.set cs:136-136*/
            tryUpdate(_data2, value, "data2") { _data2 = it }
        }
    var accent: String
        get() { /*@DONE Theme.Accent.get cs:137-137*/
            return _accent
        }
        set(value) { /*@DONE Theme.Accent.set cs:137-137*/
            tryUpdate(_accent, value, "accent") { _accent = it }
        }
    var stream1: String
        get() { /*@DONE Theme.Stream1.get cs:138-138*/
            return _stream1
        }
        set(value) { /*@DONE Theme.Stream1.set cs:138-138*/
            tryUpdate(_stream1, value, "stream1") { _stream1 = it }
        }
    var stream2: String
        get() { /*@DONE Theme.Stream2.get cs:139-139*/
            return _stream2
        }
        set(value) { /*@DONE Theme.Stream2.set cs:139-139*/
            tryUpdate(_stream2, value, "stream2") { _stream2 = it }
        }
    var editBackground: String
        get() { /*@DONE Theme.EditBackground.get cs:140-140*/
            return _editBackground
        }
        set(value) { /*@DONE Theme.EditBackground.set cs:140-140*/
            tryUpdate(_editBackground, value, "editBackground") { _editBackground = it }
        }
    val primary: String
        get() { /*@DONE Theme.Primary.get cs:142-142*/
            return primaryColor
        }
    val background: String
        get() { /*@DONE Theme.Background.get cs:143-143*/
            return backgroundColor
        }
    companion object {
        fun tryConvertColor(text: String, color: Ref<ThemeTryConvertColorColorTuple>): Boolean { /*@DONE Theme.TryConvertColor/1 cs:59-83*/
            val hex = "0123456789ABCDEF"
            var content = text.uppercase()
            if (content.startsWith("#")) content = content.substring(1)
            try {
                if (content.length == 3) content =
                    content.substring(0, 1) + content.substring(0, 1) +
                    content.substring(0, 2) + content.substring(0, 2) +
                    content.substring(0, 3) + content.substring(0, 3)
                if (content.length == 8) content = content.substring(2)
                if (content.length == 6) {
                    val r = (hex.indexOf(content[0]) * 16 + hex.indexOf(content[1])) and 0xFF
                    val g = (hex.indexOf(content[2]) * 16 + hex.indexOf(content[3])) and 0xFF
                    val b = (hex.indexOf(content[4]) * 16 + hex.indexOf(content[5])) and 0xFF
                    color.value = ThemeTryConvertColorColorTuple(r, g, b)
                    return true
                } else {
                    color.value = ThemeTryConvertColorColorTuple(0, 0, 0)
                    return false
                }
            } catch (e: Exception) {
                color.value = ThemeTryConvertColorColorTuple(0, 0, 0)
                return false
            }
        }
        fun splice(color1: ThemeSpliceColor1Tuple, color2: ThemeSpliceColor2Tuple, ratio: Double): String { /*@DONE Theme.Splice/1 cs:145-151*/
            val initial = 1 - ratio
            val hue = color2.hue
            val sat = color2.sat * initial + color1.sat * ratio
            val bright = color1.bright * initial + color2.bright * ratio
            return themeHsbToHex(hue, sat, bright)
        }
        fun fromHSB(hue: Double, sat: Double, bright: Double): ThemeFromHSBTuple { /*@DONE Theme.FromHSB/1 cs:153-173*/
            val s = sat.limitToRange(0.0, 1.0)
            val br = bright.limitToRange(0.0, 1.0)
            var h = hue
            while (h < 0) h += 1
            while (h >= 1) h -= 1
            val c = br * s
            var hue2 = h * 6
            while (hue2 > 2) hue2 -= 2
            val x = c * (1 - Math.abs(hue2 - 1))
            val m = br - c

            var r = 0.0
            var g = 0.0
            var b = 0.0
            if (h < 1 / 6.0) { r = c; g = x; b = 0.0 }
            else if (h < 2 / 6.0) { r = x; g = c; b = 0.0 }
            else if (h < 3 / 6.0) { r = 0.0; g = c; b = x }
            else if (h < 4 / 6.0) { r = 0.0; g = x; b = c }
            else if (h < 5 / 6.0) { r = x; g = 0.0; b = c }
            else if (h < 6 / 6.0) { r = c; g = 0.0; b = x }

            return ThemeFromHSBTuple(((r + m) * 255).toInt() and 0xFF, ((g + m) * 255).toInt() and 0xFF, ((b + m) * 255).toInt() and 0xFF)
        }
        fun toHSB(red: Int, green: Int, blue: Int): ThemeToHSBTuple { /*@DONE Theme.ToHSB/1 cs:175-195*/
            val r = red / 255.0
            val g = green / 255.0
            val b = blue / 255.0
            val max = Math.max(r, Math.max(g, b))
            val min = Math.min(r, Math.min(g, b))
            val delta = max - min
            val bright = max
            val sat = if (delta == 0.0) 0.0 else delta / max
            var hue = 0.0
            if (delta != 0.0) {
                if (max == r) hue = (g - b) / delta
                if (max == g) hue = (b - r) / delta + 2
                if (max == b) hue = (r - g) / delta + 4
                while (hue > 6) hue -= 6
                while (hue < 0) hue += 6
                hue /= 6
            }
            return ThemeToHSBTuple(hue, sat, bright)
        }
        fun fromOklab(lightness: Double, a: Double, b: Double): ThemeFromOklabTuple { /*@DONE Theme.FromOklab/1 cs:197-220*/
            // From the creator of the color space
            // https://bottosson.github.io/posts/oklab/#converting-from-linear-srgb-to-oklab
            val lPrime = lightness + 0.3963377774 * a + 0.2158037573 * b
            val mPrime = lightness - 0.1055613458 * a - 0.0638541728 * b
            val sPrime = lightness - 0.0894841775 * a - 1.2914855480 * b

            val l = lPrime * lPrime * lPrime
            val m = mPrime * mPrime * mPrime
            val s = sPrime * sPrime * sPrime

            val rLinear = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
            val gLinear = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
            val bLinear = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s

            // Assume the output is sRGB, meaning gamma = 2.4
            // Real original-model GBA screens have higher gamma, but most people making and playing romhacks aren't going to be playing with a GBA-like screen
            val toSRGB = { c: Double -> (if (c <= 0.0031308) 12.92 * c else (1.055 * Math.pow(c, 1.0 / 2.4) - 0.055)).limitToRange(0.0, 1.0) }

            val red = Math.rint(toSRGB(rLinear) * 255.0).toInt() and 0xFF
            val green = Math.rint(toSRGB(gLinear) * 255.0).toInt() and 0xFF
            val blue = Math.rint(toSRGB(bLinear) * 255.0).toInt() and 0xFF
            return ThemeFromOklabTuple(red, green, blue)
        }
        fun toOklab(red: Int, green: Int, blue: Int): ThemeToOklabTuple { /*@DONE Theme.ToOklab/1 cs:222-244*/
            val rr = red / 255.0
            val gg = green / 255.0
            val bb = blue / 255.0

            // Assume the input is sRGB, meaning gamma = 2.4
            // Real original-model GBA screens have higher gamma, but most people making and playing romhacks aren't going to be playing with a GBA-like screen
            val toLinear = { c: Double -> if (c <= 0.04045) c / 12.92 else Math.pow((c + 0.055) / 1.055, 2.4) }
            val rLinear = toLinear(rr)
            val gLinear = toLinear(gg)
            val bLinear = toLinear(bb)

            // From the creator of the color space
            // https://bottosson.github.io/posts/oklab/#converting-from-linear-srgb-to-oklab
            val lPrime = Math.cbrt(0.4122214708 * rLinear + 0.5363325363 * gLinear + 0.0514459929 * bLinear)
            val mPrime = Math.cbrt(0.2119034982 * rLinear + 0.6806995451 * gLinear + 0.1073969566 * bLinear)
            val sPrime = Math.cbrt(0.0883024619 * rLinear + 0.2817188376 * gLinear + 0.6299787005 * bLinear)

            val lightness = 0.2104542553 * lPrime + 0.7936177850 * mPrime - 0.0040720468 * sPrime
            val a = 1.9779984951 * lPrime - 2.4285922050 * mPrime + 0.4505937099 * sPrime
            val b = 0.0259040371 * lPrime + 0.7827717662 * mPrime - 0.8086757660 * sPrime
            return ThemeToOklabTuple(lightness, a, b)
        }
        /*@END Theme.Companion*/
    }
    /*@END Theme*/
}

fun ExtensionsToHexStringRgbTuple.toHexString(): String { /*@DONE Extensions.ToHexString/1 cs:533-536*/
    return String.format("#%02X%02X%02X", red, green, blue)
}
fun String.tryParseHex(result: Ref<Int>): Boolean { /*@DONE Extensions.TryParseHex/1 cs:538-542*/
    var hex = this.trim()
    if (hex.startsWith("0x")) hex = hex.substring(2)
    return tryParseHexInt(hex, result)
}
fun ExtensionsToRgbHsbTuple.toRgb(): ExtensionsToRgbTuple { /*@DONE Extensions.ToRgb/1 cs:544-544*/
    val rgb = Theme.fromHSB(hue, sat, bright)
    return ExtensionsToRgbTuple(rgb.red, rgb.green, rgb.blue)
}
fun ExtensionsAdjustHsbTuple.adjust(h: Double, s: Double, b: Double): ExtensionsAdjustTuple { /*@DONE Extensions.Adjust/1 cs:546-551*/
    val newHue = hue + h
    val newSat = (sat + s).limitToRange(0.0, 1.0)
    val newBright = (bright + b).limitToRange(0.0, 1.0)
    return ExtensionsAdjustTuple(newHue, newSat, newBright)
}

object Extensions { // cs:532-552
    /*@END Extensions*/
}

data class ThemeTryConvertColorColorTuple(val r: Int, val g: Int, val b: Int)

data class ThemeSpliceColor1Tuple(val hue: Double, val sat: Double, val bright: Double)

data class ThemeSpliceColor2Tuple(val hue: Double, val sat: Double, val bright: Double)

data class ThemeFromHSBTuple(val red: Int, val green: Int, val blue: Int)

data class ThemeToHSBTuple(val hue: Double, val sat: Double, val bright: Double)

data class ThemeFromOklabTuple(val red: Int, val green: Int, val blue: Int)

data class ThemeToOklabTuple(val lightness: Double, val a: Double, val b: Double)

data class ExtensionsToHexStringRgbTuple(val red: Int, val green: Int, val blue: Int)

data class ExtensionsToRgbTuple(val item1: Int, val item2: Int, val item3: Int)

data class ExtensionsToRgbHsbTuple(val hue: Double, val sat: Double, val bright: Double)

data class ExtensionsAdjustTuple(val hue: Double, val sat: Double, val bright: Double)

data class ExtensionsAdjustHsbTuple(val hue: Double, val sat: Double, val bright: Double)

/*@ADD file:viewmodels/Theme.kt#theme_1.txt*/
internal fun themeHsbToHex(hue: Double, sat: Double, bright: Double): String {
    val rgb = Theme.fromHSB(hue, sat, bright)
    return ExtensionsToHexStringRgbTuple(rgb.red, rgb.green, rgb.blue).toHexString()
}

/** .NET prints a whole-number double without a decimal point, so keep the saved theme text the same. */
internal fun themeDoubleText(value: Double): String {
    val text = value.toString()
    return if (text.endsWith(".0")) text.substring(0, text.length - 2) else text
}
/*@ENDADD file:viewmodels/Theme.kt#theme_1.txt*/
