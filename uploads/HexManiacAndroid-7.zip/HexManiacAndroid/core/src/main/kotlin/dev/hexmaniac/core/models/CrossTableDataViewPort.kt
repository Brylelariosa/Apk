// Port of Models/CrossTableDataViewPort.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.viewmodels.*
import dev.hexmaniac.core.viewmodels.dataformats.*
import dev.hexmaniac.core.viewmodels.tools.*
import dev.hexmaniac.core.viewmodels.visitors.*

data class CrossTableRow(val address: Int, val format: IDataFormat?) { // cs:16-16
    /*@END CrossTableRow*/
}

open class CrossTableDataViewPort : ViewModelCore, IViewPort { // cs:22-294
    private lateinit var parent: ViewPort
    private var rows: MutableList<CrossTableRow> = /*@INITDONE CrossTableDataViewPort.rows cs:24-24*/ ArrayList() /*@ENDINIT*/
    private var _height: Int = 0
    constructor(parent: ViewPort) { /*@DONE CrossTableDataViewPort.<init>/1 cs:27-29*/
        this.parent = parent
    }
    override operator fun get(x: Int, y: Int): HexElement { /*@DONE CrossTableDataViewPort.this/1.get cs:32-37*/
        val yy = y + _scrollValue
        val model = parent.model
        if (model == null || yy >= rows.size) return HexElement(0, false, Undefined.instance)
        val row = rows[yy]
        return HexElement(if (row.address < 0) 0 else model[row.address], false, row.format ?: Undefined.instance)
    }
    operator fun set(x: Int, y: Int, value: HexElement) { /*@DONE CrossTableDataViewPort.this/1.set cs:38-38*/
        // the cross-table view is read-only
    }
    override var toolPanelWidth: Double
        get() { /*@DONE CrossTableDataViewPort.ToolPanelWidth.get cs:43-43*/
            return 0.0
        }
        set(value) { /*@DONE CrossTableDataViewPort.ToolPanelWidth.set cs:43-43*/
            // fixed
        }
    override val fileName: String
        get() { /*@DONE CrossTableDataViewPort.FileName.get cs:45-45*/
            return parent.fileName
        }
    override val fullFileName: String
        get() { /*@DONE CrossTableDataViewPort.FullFileName.get cs:47-47*/
            return parent.fullFileName
        }
    override var width: Int
        get() { /*@DONE CrossTableDataViewPort.Width.get cs:49-49*/
            return 4
        }
        set(value) { /*@DONE CrossTableDataViewPort.Width.set cs:49-49*/
            // fixed
        }
    override var height: Int
        get() { /*@DONE CrossTableDataViewPort.Height.get cs:50-50*/
            return _height
        }
        set(value) { /*@DONE CrossTableDataViewPort.Height.set cs:50-50*/
            set(_height, value, "height", { _height = it })
        }
    override var autoAdjustDataWidth: Boolean
        get() { /*@DONE CrossTableDataViewPort.AutoAdjustDataWidth.get cs:51-51*/
            return false
        }
        set(value) { /*@DONE CrossTableDataViewPort.AutoAdjustDataWidth.set cs:51-51*/
            // fixed
        }
    override var stretchData: Boolean
        get() { /*@DONE CrossTableDataViewPort.StretchData.get cs:52-52*/
            return false
        }
        set(value) { /*@DONE CrossTableDataViewPort.StretchData.set cs:52-52*/
            // fixed
        }
    override var allowMultipleElementsPerLine: Boolean
        get() { /*@DONE CrossTableDataViewPort.AllowMultipleElementsPerLine.get cs:53-53*/
            return false
        }
        set(value) { /*@DONE CrossTableDataViewPort.AllowMultipleElementsPerLine.set cs:53-53*/
            // fixed
        }
    override var base10Length: Boolean
        get() { /*@DONE CrossTableDataViewPort.Base10Length.get cs:54-54*/
            return parent.base10Length
        }
        set(value) { /*@DONE CrossTableDataViewPort.Base10Length.set cs:54-54*/
            // follows the parent
        }
    override var useCustomHeaders: Boolean
        get() { /*@DONE CrossTableDataViewPort.UseCustomHeaders.get cs:55-55*/
            return true
        }
        set(value) { /*@DONE CrossTableDataViewPort.UseCustomHeaders.set cs:55-55*/
            // fixed
        }
    override val minimumScroll: Int
        get() { /*@DONE CrossTableDataViewPort.MinimumScroll.get cs:57-57*/
            return 0
        }
    private var _scrollValue: Int = 0
    override var scrollValue: Int
        get() { /*@DONE CrossTableDataViewPort.ScrollValue.get cs:60-60*/
            return _scrollValue
        }
        set(value) { /*@DONE CrossTableDataViewPort.ScrollValue.set cs:60-60*/
            set(_scrollValue, value, "scrollValue", { _scrollValue = it })
        }
    override val maximumScroll: Int
        get() { /*@DONE CrossTableDataViewPort.MaximumScroll.get cs:62-62*/
            return rows.size - 1
        }
    override var headers: ObservableCollection<RowHeader>? = /*@INITDONE CrossTableDataViewPort.Headers cs:64-64*/ ObservableCollection() /*@ENDINIT*/
    private fun updateRowHeaders() { /*@DONE CrossTableDataViewPort.UpdateRowHeaders/1 cs:65-78*/
        val newHeaders = ObservableCollection<RowHeader>()
        val model = parent.model
        for (i in 0 until height) {
            val y = i + _scrollValue
            val row = if (y >= 0 && y < rows.size) rows[y] else null
            val table = if (model == null || row == null || row.address < 0) null else model.getNextRun(row.address) as? ITableRun
            if (table == null) {
                val empty = RowHeader()
                empty.content = ""
                newHeaders.add(empty)
                continue
            }
            val offset = table.convertByteOffsetToArrayOffset(rows[i].address - table.start)
            val header = RowHeader()
            header.content = table.elementContent[offset.segmentIndex].name
            newHeaders.add(header)
        }
        headers = newHeaders
        notifyPropertyChanged("headers")
    }
    override val columnHeaders: ObservableCollection<ColumnHeaderRow> = /*@INITDONE CrossTableDataViewPort.ColumnHeaders cs:80-80*/ ObservableCollection<ColumnHeaderRow>().also { it.add(ColumnHeaderRow("data", 4)) } /*@ENDINIT*/
    override val dataOffset: Int
        get() { /*@DONE CrossTableDataViewPort.DataOffset.get cs:82-82*/
            return 0
        }
    private var scrollCommand: StubCommand? = null
    override val scroll: ICommand
        get() { /*@DONE CrossTableDataViewPort.Scroll.get cs:85-85*/
            var command = scrollCommand
            if (command == null) {
                command = StubCommand()
                command.canExecute = { parameter -> canScroll(parameter) }
                command.execute = { parameter -> scrollExecute(parameter) }
                scrollCommand = command
            }
            return command
        }
    override val progress: Double
        get() { /*@DONE CrossTableDataViewPort.Progress.get cs:87-87*/
            return 0.0
        }
    override val updateInProgress: Boolean
        get() { /*@DONE CrossTableDataViewPort.UpdateInProgress.get cs:89-89*/
            return false
        }
    override val canFindFreeSpace: Boolean
        get() { /*@DONE CrossTableDataViewPort.CanFindFreeSpace.get cs:91-91*/
            return false
        }
    override var selectedAddress: String
        get() { /*@DONE CrossTableDataViewPort.SelectedAddress.get cs:93-93*/
            return ""
        }
        set(value) { /*@DONE CrossTableDataViewPort.SelectedAddress.set cs:93-93*/
            // fixed
        }
    override val selectedBytes: String?
        get() { /*@DONE CrossTableDataViewPort.SelectedBytes.get cs:95-95*/
            return ""
        }
    override val anchorText: String
        get() { /*@DONE CrossTableDataViewPort.AnchorText.get cs:97-97*/
            return ""
        }
    override val anchorTextVisible: Boolean
        get() { /*@DONE CrossTableDataViewPort.AnchorTextVisible.get cs:99-99*/
            return false
        }
    override var findBytes: ByteArray?
        get() { /*@DONE CrossTableDataViewPort.FindBytes.get cs:101-101*/
            return ByteArray(0)
        }
        set(value) { /*@DONE CrossTableDataViewPort.FindBytes.set cs:101-101*/
            // fixed
        }
    override val model: IDataModel?
        get() { /*@DONE CrossTableDataViewPort.Model.get cs:103-103*/
            return parent.model
        }
    override val hasTools: Boolean
        get() { /*@DONE CrossTableDataViewPort.HasTools.get cs:105-105*/
            return false
        }
    override val changeHistory: ChangeHistory<ModelDelta>
        get() { /*@DONE CrossTableDataViewPort.ChangeHistory.get cs:107-107*/
            return parent.changeHistory
        }
    override val tools: IToolTrayViewModel? = /*@INITAUTO CrossTableDataViewPort.Tools cs:109-109*/ EmptyToolTray() /*@ENDINIT*/
    override val name: String
        get() { /*@DONE CrossTableDataViewPort.Name.get cs:111-111*/
            return parent.name
        }
    override val isMetadataOnlyChange: Boolean
        get() { /*@DONE CrossTableDataViewPort.IsMetadataOnlyChange.get cs:113-113*/
            return parent.isMetadataOnlyChange
        }
    override val save: ICommand?
        get() { /*@DONE CrossTableDataViewPort.Save.get cs:115-115*/
            return parent.save
        }
    override val saveAs: ICommand
        get() { /*@DONE CrossTableDataViewPort.SaveAs.get cs:117-117*/
            return parent.saveAs
        }
    override val exportBackup: ICommand
        get() { /*@DONE CrossTableDataViewPort.ExportBackup.get cs:119-119*/
            return parent.exportBackup
        }
    override val undo: ICommand
        get() { /*@DONE CrossTableDataViewPort.Undo.get cs:121-121*/
            return parent.undo
        }
    override val redo: ICommand
        get() { /*@DONE CrossTableDataViewPort.Redo.get cs:123-123*/
            return parent.redo
        }
    private var _copy: StubCommand? = null
    private var _deepCopy: StubCommand? = null
    private var _clear: StubCommand? = null
    private var _selectAll: StubCommand? = null
    override val copy: ICommand?
        get() { /*@DONE CrossTableDataViewPort.Copy.get cs:126-126*/
            var command = _copy
            if (command == null) {
                command = StubCommand()
                command.canExecute = { parameter -> canCopy(parameter) }
                command.execute = { parameter -> copyExecute(parameter) }
                _copy = command
            }
            return command
        }
    override val deepCopy: ICommand
        get() { /*@DONE CrossTableDataViewPort.DeepCopy.get cs:128-128*/
            var command = _deepCopy
            if (command == null) {
                command = StubCommand()
                command.canExecute = { parameter -> canDeepCopy(parameter) }
                command.execute = { parameter -> deepCopyExecute(parameter) }
                _deepCopy = command
            }
            return command
        }
    override val clear: ICommand?
        get() { /*@DONE CrossTableDataViewPort.Clear.get cs:130-130*/
            var command = _clear
            if (command == null) {
                command = StubCommand()
                command.canExecute = { parameter -> canClear(parameter) }
                command.execute = { parameter -> clearExecute(parameter) }
                _clear = command
            }
            return command
        }
    override val selectAll: ICommand
        get() { /*@DONE CrossTableDataViewPort.SelectAll.get cs:132-132*/
            return StubCommand()
        }
    override val goto: ICommand?
        get() { /*@DONE CrossTableDataViewPort.Goto.get cs:134-134*/
            return StubCommand()
        }
    override val resetAlignment: ICommand
        get() { /*@DONE CrossTableDataViewPort.ResetAlignment.get cs:136-136*/
            return StubCommand()
        }
    override val back: ICommand
        get() { /*@DONE CrossTableDataViewPort.Back.get cs:138-138*/
            return StubCommand()
        }
    override val forward: ICommand
        get() { /*@DONE CrossTableDataViewPort.Forward.get cs:140-140*/
            return StubCommand()
        }
    override val close: ICommand
        get() { /*@DONE CrossTableDataViewPort.Close.get cs:142-142*/
            return StubCommand()
        }
    override val diff: ICommand
        get() { /*@DONE CrossTableDataViewPort.Diff.get cs:144-144*/
            return StubCommand()
        }
    override val diffLeft: ICommand
        get() { /*@DONE CrossTableDataViewPort.DiffLeft.get cs:146-146*/
            return StubCommand()
        }
    override val diffRight: ICommand
        get() { /*@DONE CrossTableDataViewPort.DiffRight.get cs:148-148*/
            return StubCommand()
        }
    override var spartanMode: Boolean
        get() { /*@DONE CrossTableDataViewPort.SpartanMode.get cs:150-150*/
            return false
        }
        set(value) { /*@DONE CrossTableDataViewPort.SpartanMode.set cs:150-150*/
            // fixed
        }
    override val canIpsPatchRight: Boolean
        get() { /*@DONE CrossTableDataViewPort.CanIpsPatchRight.get cs:152-152*/
            return false
        }
    override val canUpsPatchRight: Boolean
        get() { /*@DONE CrossTableDataViewPort.CanUpsPatchRight.get cs:154-154*/
            return false
        }
    override val canDuplicate: Boolean
        get() { /*@DONE CrossTableDataViewPort.CanDuplicate.get cs:156-156*/
            return false
        }
    override val previewScrollChanged = Event<EventArgs>()
    override val requestCloseOtherViewports = Event<IDataModel>()
    override val onError = Event<String>()
    override val onMessage = Event<String>()
    override val clearMessage = Event<EventArgs>()
    override val closed = Event<EventArgs>()
    override val requestTabChange = Event<TabChangeRequestedEventArgs>()
    override val requestDelayedWork = Event<() -> Unit>()
    override val requestMenuClose = Event<EventArgs>()
    override val requestDiff = Event<Direction>()
    override val requestCanDiff = Event<CanDiffEventArgs>()
    override val requestCanCreatePatch = Event<CanPatchEventArgs>()
    override val requestCreatePatch = Event<CanPatchEventArgs>()
    override val requestRefreshGotoShortcuts = Event<EventArgs>()
    override val propertyChanged = Event<PropertyChangedEventArgs>()
    override val collectionChanged = Event<NotifyCollectionChangedEventArgs>()
    override fun considerReload(fileSystem: IFileSystem) { /*@DONE CrossTableDataViewPort.ConsiderReload/1 cs:175-175*/
        parent.considerReload(fileSystem)
    }
    override fun createChildView(startAddress: Int, endAddress: Int): IChildViewPort { /*@DONE CrossTableDataViewPort.CreateChildView/1 cs:177-177*/
        throw NotImplementedError()
    }
    override fun duplicate() { /*@DONE CrossTableDataViewPort.Duplicate/1 cs:179-179*/
        // not supported
    }
    override fun expandSelection(x: Int, y: Int) { /*@DONE CrossTableDataViewPort.ExpandSelection/1 cs:181-181*/
        // not supported
    }
    override fun find(search: String, matchExactCase: Boolean): List<IViewPortFindTuple> { /*@DONE CrossTableDataViewPort.Find/1 cs:183-183*/
        return parent.find(search, matchExactCase)
    }
    override fun findAllSources(x: Int, y: Int) { /*@DONE CrossTableDataViewPort.FindAllSources/1 cs:185-185*/
        parent.findAllSources(x, y)
    }
    override fun findFreeSpace(fileSystem: IFileSystem) { /*@DONE CrossTableDataViewPort.FindFreeSpace/1 cs:187-187*/
        parent.findFreeSpace(fileSystem)
    }
    override fun followLink(x: Int, y: Int) { /*@DONE CrossTableDataViewPort.FollowLink/1 cs:189-189*/
        parent.followLink(x, y)
    }
    override fun ipsPatchRight() { /*@DONE CrossTableDataViewPort.IpsPatchRight/1 cs:191-191*/
        // not supported
    }
    override fun isTable(point: Point): Boolean { /*@DONE CrossTableDataViewPort.IsTable/1 cs:193-193*/
        return true
    }
    override fun modelFor(point: Point): IDataModel? { /*@DONE CrossTableDataViewPort.ModelFor/1 cs:195-195*/
        return parent.model
    }
    override fun tryImport(file: LoadedFile, fileSystem: IFileSystem): Boolean { /*@DONE CrossTableDataViewPort.TryImport/1 cs:197-197*/
        return false
    }
    override fun upsPatchRight() { /*@DONE CrossTableDataViewPort.UpsPatchRight/1 cs:199-199*/
        // not supported
    }
    override fun getContextMenuItems(point: Point, fileSystem: IFileSystem?): List<IContextItem> { /*@DONE CrossTableDataViewPort.GetContextMenuItems/1 cs:203-206*/
        // TODO
        return ArrayList<IContextItem>()
    }
    override fun isSelected(point: Point): Boolean { /*@DONE CrossTableDataViewPort.IsSelected/1 cs:208-210*/
        return false
    }
    private var _visible: Boolean = false
    var visible: Boolean
        get() { /*@DONE CrossTableDataViewPort.Visible.get cs:213-213*/
            return _visible
        }
        set(value) { /*@DONE CrossTableDataViewPort.Visible.set cs:213-213*/
            set(_visible, value, "visible", { _visible = it }, { visibleChanged() })
        }
    private fun visibleChanged() { /*@DONE CrossTableDataViewPort.VisibleChanged/1 cs:214-216*/
        if (_visible && needsRefresh) refresh()
    }
    private var needsRefresh: Boolean = false
    override fun refresh() { /*@DONE CrossTableDataViewPort.Refresh/1 cs:219-249*/
        needsRefresh = true
        if (!_visible) return
        val model = parent.model ?: return
        val selectedAddress = parent.convertViewPointToAddress(parent.selectionStart)
        val arrayRun = model.getNextRun(selectedAddress) as? ArrayRun ?: return

        var basename = model.getAnchorFromAddress(-1, arrayRun.start)
        val baseElementIndex = (selectedAddress - arrayRun.start) / arrayRun.elementLength
        val originalTableName = basename
        val lengthFromAnchor = arrayRun.lengthFromAnchor
        if (!lengthFromAnchor.isNullOrEmpty() && (model.getMatchedWords(lengthFromAnchor)?.size ?: 0) == 0) basename = lengthFromAnchor // basename is now a 'parent table' name, if there is one
        val groups: List<TableGroup> = model.getTableGroups(basename) ?: listOf(TableGroup(TableGroupViewModel.defaultName, listOf(originalTableName)))

        // now we have to get fields from all the tables and use them to fill the rows, including blank rows
        rows.clear()
        for (group in groups) {
            for (table in group.tables) {
                val tableRun = model.getTable(table) ?: continue
                var tableIndex = baseElementIndex
                if (tableRun is ArrayRun) tableIndex -= tableRun.parentOffset.beginningMargin
                val start = tableRun.start + tableIndex * tableRun.elementLength
                rows.add(CrossTableRow(-1, UnderEdit(Undefined.instance, table)))
                for (field in tableRun.elementContent) {
                    val format = tableRun.createDataFormat(model, start)
                    rows.add(CrossTableRow(start, format))
                }
            }
            rows.add(CrossTableRow(-1, UnderEdit(Undefined.instance, ""))) // separator between groups
        }

        needsRefresh = false
    }
    private fun canScroll(parameter: Any?): Boolean { /*@DONE CrossTableDataViewPort.CanScroll/1 cs:251-256*/
        if (parameter !is Direction) return false
        if (!parameter.isAny(Direction.Up, Direction.Down)) return false
        val dy = if (parameter == Direction.Down) 1 else -1
        return (_scrollValue + dy).inRange(minimumScroll, maximumScroll + 1)
    }
    private fun scrollExecute(parameter: Any?) { /*@DONE CrossTableDataViewPort.ScrollExecute/1 cs:258-263*/
        if (parameter !is Direction || !parameter.isAny(Direction.Up, Direction.Down)) return
        val dy = if (parameter == Direction.Down) 1 else -1
        scrollValue += dy
        updateRowHeaders()
    }
    private fun canCopy(parameter: Any?): Boolean { /*@DONE CrossTableDataViewPort.CanCopy/1 cs:265-269*/
        if (parameter !is IFileSystem) return false
        // Copying is not yet supported on Cross Table Viewports.
        return false
    }
    private fun copyExecute(parameter: Any?) { /*@DONE CrossTableDataViewPort.CopyExecute/1 cs:271-273*/
        if (parameter !is IFileSystem) return
    }
    private fun canDeepCopy(parameter: Any?): Boolean { /*@DONE CrossTableDataViewPort.CanDeepCopy/1 cs:275-279*/
        if (parameter !is IFileSystem) return false
        // Copying is not yet supported on Cross Table Viewports.
        return false
    }
    private fun deepCopyExecute(parameter: Any?) { /*@DONE CrossTableDataViewPort.DeepCopyExecute/1 cs:281-283*/
        if (parameter !is IFileSystem) return
    }
    private fun canClear(parameter: Any?): Boolean { /*@DONE CrossTableDataViewPort.CanClear/1 cs:285-289*/
        if (parameter !is IFileSystem) return false
        // Clearing is not yet supported on Cross Table Viewports.
        return false
    }
    private fun clearExecute(parameter: Any?) { /*@DONE CrossTableDataViewPort.ClearExecute/1 cs:291-293*/
        if (parameter !is IFileSystem) return
    }
    /*@END CrossTableDataViewPort*/
}

data class IViewPortFindTuple(val start: Int, val end: Int)
