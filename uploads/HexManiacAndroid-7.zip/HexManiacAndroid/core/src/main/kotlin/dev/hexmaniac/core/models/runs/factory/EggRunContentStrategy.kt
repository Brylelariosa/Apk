// Port of Models/Runs/Factory/EggRunContentStrategy.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs.factory

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*

open class EggRunContentStrategy : RunStrategy() { // cs:9-24
    override fun lengthForNewRun(model: IDataModel, pointerAddress: Int): Int { /*@DONE EggRunContentStrategy.LengthForNewRun/1 cs:10-10*/
        throw NotImplementedError()
    }
    override fun matches(run: IFormattedRun?): Boolean { /*@DONE EggRunContentStrategy.Matches/1 cs:12-12*/
        throw NotImplementedError()
    }
    override fun tryAddFormatAtDestination(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int): Boolean { /*@DONE EggRunContentStrategy.TryAddFormatAtDestination/1 cs:14-14*/
        throw NotImplementedError()
    }
    override fun updateNewRunFromPointerFormat(model: IDataModel, token: ModelDelta, name: String, sourceSegments: List<ArrayRunElementSegment>?, parentIndex: Int, run: Ref<IFormattedRun>) { /*@DONE EggRunContentStrategy.UpdateNewRunFromPointerFormat/1 cs:16-16*/
        throw NotImplementedError()
    }
    override fun writeNewRun(owner: IDataModel, token: ModelDelta, source: Int, destination: Int, name: String, sourceSegments: List<ArrayRunElementSegment>): IFormattedRun { /*@DONE EggRunContentStrategy.WriteNewRun/1 cs:18-18*/
        throw NotImplementedError()
    }
    override fun tryParseData(model: IDataModel, name: String, dataIndex: Int, run: Ref<IFormattedRun?>): ErrorInfo? { /*@DONE EggRunContentStrategy.TryParseData/1 cs:20-23*/
        run.value = EggMoveRun(model, dataIndex)
        return ErrorInfo.noError
    }
    /*@END EggRunContentStrategy*/
}
