// Port of Models/Runs/WordRun.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.models.runs

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class WordRun : BaseRun, IAppendToBuilderRun { // cs:8-65
    var sourceArrayName: String = ""
        private set
    final override var length: Int = 0
        private set
    var valueOffset: Int = 0
        private set
    var multOffset: Int = 0
        private set
    var note: String? = null
        private set
    override val formatString: String
        get() { /*@DONE WordRun.FormatString.get cs:19-23*/
            return when (length) {
                4 -> "::"
                2 -> ":"
                else -> "."
            }
        }
    constructor(start: Int, name: String, length: Int, valueOffset: Int, multOffset: Int, note: String? = null, sources: SortedSpan<Int>? = null) : super(start, sources) { /*@DONE WordRun.<init>/1 cs:25-32*/
        sourceArrayName = name
        this.length = length
        this.valueOffset = valueOffset
        Debug.assert(multOffset > 0, "MultOffset must be positive!")
        this.multOffset = multOffset
        this.note = note
    }
    override fun createDataFormat(data: IDataModel, index: Int): IDataFormat { /*@DONE WordRun.CreateDataFormat/1 cs:34-38*/
        if (isMatchedWord(data)) return MatchedWord(start, index - start, "::" + sourceArrayName)
        if (length != 4 && length != 2) return Integer(start, 0, data[index], 1)
        return Integer(start, index - start, data.readMultiByteValue(start, length), length)
    }
    protected override fun clone(newPointerSources: SortedSpan<Int>?): BaseRun { /*@DONE WordRun.Clone/1 cs:40-40*/
        return WordRun(start, sourceArrayName, length, valueOffset, multOffset, note, newPointerSources)
    }
    override fun appendTo(model: IDataModel, builder: StringBuilder, start: Int, length: Int, depth: Int) { /*@DONE WordRun.AppendTo/1 cs:42-54*/
        if (isMatchedWord(model)) {
            builder.append(formatString + sourceArrayName)
        } else if (this.length == 4 || this.length == 2 || this.length == 1) {
            var offset = ""
            if (multOffset != 1) offset += "*" + multOffset
            if (valueOffset > 0) offset += "+" + valueOffset
            if (valueOffset < 0) offset += "-" + valueOffset
            builder.append("$formatString$sourceArrayName$offset=${model[start]} ")
        } else {
            throw NotImplementedException()
        }
    }
    override fun clear(model: IDataModel, changeToken: ModelDelta, start: Int, length: Int) { /*@DONE WordRun.Clear/1 cs:56-58*/
        for (i in 0 until length) changeToken.changeData(model, start + i, 0x00)
    }
    fun read(model: IDataModel): Int { /*@DONE WordRun.Read/1 cs:60-62*/
        return (model.readMultiByteValue(start, length) - valueOffset) / multOffset
    }
    private fun isMatchedWord(model: IDataModel): Boolean { /*@DONE WordRun.IsMatchedWord/1 cs:64-64*/
        return length == 4 && model.getAddressFromAnchor(NoDataChangeDeltaModel(), -1, sourceArrayName) != Pointer.null_
    }
    /*@END WordRun*/
}
