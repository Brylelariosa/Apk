// Port of ViewModels/ConvertCellToText.cs
@file:Suppress("UNUSED_PARAMETER", "UNUSED_VARIABLE", "unused", "UNCHECKED_CAST", "NAME_SHADOWING", "UNUSED_EXPRESSION", "CanBeParameter", "RedundantVisibilityModifier", "MemberVisibilityCanBePrivate", "ConvertSecondaryConstructorToPrimary")

package dev.hexmaniac.core.viewmodels

import dev.hexmaniac.core.system.*
import dev.hexmaniac.core.*
import dev.hexmaniac.core.models.*
import dev.hexmaniac.core.models.runs.*
import dev.hexmaniac.core.models.runs.sprites.*
import dev.hexmaniac.core.viewmodels.dataformats.*

open class ConvertCellToText : IDataFormatVisitor { // cs:11-87
    private lateinit var buffer: IDataModel
    private var index: Int = 0
    var result: String = ""
        private set
    constructor(buffer: IDataModel, index: Int) { /*@DONE ConvertCellToText.<init>/1 cs:17-20*/
        this.buffer = buffer
        this.index = index
    }
    override fun visit(dataFormat: Undefined, data: Int) { /*@DONE ConvertCellToText.Visit/1 cs:22-22*/
        // undefined cells have no text
    }
    override fun visit(dataFormat: None, data: Int) { /*@DONE ConvertCellToText.Visit/2 cs:24-24*/
        result = data.toHexByte()
    }
    override fun visit(dataFormat: UnderEdit, data: Int) { /*@DONE ConvertCellToText.Visit/3 cs:26-28*/
        throw NotImplementedException()
    }
    override fun visit(pointer: Pointer, data: Int) { /*@DONE ConvertCellToText.Visit/4 cs:30-30*/
        result = pointer.destinationAsText
    }
    override fun visit(anchor: Anchor, data: Int) { /*@DONE ConvertCellToText.Visit/5 cs:32-32*/
        anchor.originalFormat!!.visit(this, data)
    }
    override fun visit(sprite: SpriteDecorator, data: Int) { /*@DONE ConvertCellToText.Visit/6 cs:34-34*/
        sprite.originalFormat!!.visit(this, data)
    }
    override fun visit(decorator: StreamEndDecorator, data: Int) { /*@DONE ConvertCellToText.Visit/7 cs:36-36*/
        decorator.originalFormat!!.visit(this, data)
    }
    override fun visit(pcs: PCS, data: Int) { /*@DONE ConvertCellToText.Visit/8 cs:38-40*/
        result = pcs.thisCharacter
    }
    override fun visit(pcs: EscapedPCS, data: Int) { /*@DONE ConvertCellToText.Visit/9 cs:42-42*/
        visit(None.instance, data)
    }
    override fun visit(pcs: ErrorPCS, data: Int) { /*@DONE ConvertCellToText.Visit/10 cs:44-44*/
        visit(None.instance, data)
    }
    override fun visit(ascii: Ascii, data: Int) { /*@DONE ConvertCellToText.Visit/11 cs:46-46*/
        result = data.toChar().toString()
    }
    override fun visit(braille: Braille, data: Int) { /*@DONE ConvertCellToText.Visit/12 cs:48-52*/
        if (data == 0xFF) {
            result = "\""
        } else if (BrailleRun.encoding.containsKey(data)) {
            result = BrailleRun.encoding[data].toString()
        } else {
            result = " "
        }
    }
    override fun visit(integer: Integer, data: Int) { /*@DONE ConvertCellToText.Visit/13 cs:54-54*/
        result = integer.value.toString()
    }
    override fun visit(integerEnum: IntegerEnum, data: Int) { /*@DONE ConvertCellToText.Visit/14 cs:56-56*/
        result = integerEnum.valueNew
    }
    override fun visit(integerHex: IntegerHex, data: Int) { /*@DONE ConvertCellToText.Visit/15 cs:58-58*/
        result = integerHex.toString()
    }
    override fun visit(section: EggSection, data: Int) { /*@DONE ConvertCellToText.Visit/16 cs:60-60*/
        result = section.sectionName
    }
    override fun visit(item: EggItem, data: Int) { /*@DONE ConvertCellToText.Visit/17 cs:62-62*/
        result = item.itemName
    }
    override fun visit(item: PlmItem, data: Int) { /*@DONE ConvertCellToText.Visit/18 cs:64-64*/
        result = item.toString()
    }
    override fun visit(array: BitArray, data: Int) { /*@DONE ConvertCellToText.Visit/19 cs:66-66*/
        visit(None.instance, data)
    }
    override fun visit(word: MatchedWord, data: Int) { /*@DONE ConvertCellToText.Visit/20 cs:68-68*/
        visit(None.instance, data)
    }
    override fun visit(endStream: EndStream, data: Int) { /*@DONE ConvertCellToText.Visit/21 cs:70-70*/
        result = "" + ArrayRun.arrayStart + ArrayRun.arrayEnd
    }
    override fun visit(lz: LzMagicIdentifier, data: Int) { /*@DONE ConvertCellToText.Visit/22 cs:72-72*/
        result = "lz"
    }
    override fun visit(lz: LzGroupHeader, data: Int) { /*@DONE ConvertCellToText.Visit/23 cs:74-74*/
        visit(None.instance, data)
    }
    override fun visit(lz: LzCompressed, data: Int) { /*@DONE ConvertCellToText.Visit/24 cs:76-80*/
        val start = Ref(index)
        val token = LZRun.readCompressedToken(buffer, start)
        result = "" + token.runLength + ":" + token.runOffset
    }
    override fun visit(lz: LzUncompressed, data: Int) { /*@DONE ConvertCellToText.Visit/25 cs:82-82*/
        visit(None.instance, data)
    }
    override fun visit(color: UncompressedPaletteColor, data: Int) { /*@DONE ConvertCellToText.Visit/26 cs:84-84*/
        result = color.toString()
    }
    override fun visit(tuple: Tuple, data: Int) { /*@DONE ConvertCellToText.Visit/27 cs:86-86*/
        result = tuple.toString()
    }
    /*@END ConvertCellToText*/
}
