package dev.hexmaniac.core.system

// System.Collections.ObjectModel.ObservableCollection<T> and friends.

/**
 * A list that raises [collectionChanged] for every change.
 * `ObservableCollection<T>` => `ObservableCollection<T>`; `AddRange` extension => [addRange].
 */
open class ObservableCollection<T>() : AbstractMutableList<T>(), INotifyCollectionChanged {
    protected val items: ArrayList<T> = ArrayList()

    /** `new ObservableCollection<T>(IEnumerable<T>)`: copies the items without raising change events. */
    constructor(initial: Iterable<T>) : this() {
        for (e in initial) items.add(e)
    }

    override val collectionChanged: Event<NotifyCollectionChangedEventArgs> = Event()

    override val size: Int get() = items.size

    override fun get(index: Int): T = items[index]

    override fun add(index: Int, element: T) {
        items.add(index, element)
        raise(NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, newItems = listOf(element), newStartingIndex = index))
    }

    override fun removeAt(index: Int): T {
        val old = items.removeAt(index)
        raise(NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Remove, oldItems = listOf(old), oldStartingIndex = index))
        return old
    }

    override fun set(index: Int, element: T): T {
        val old = items.set(index, element)
        raise(
            NotifyCollectionChangedEventArgs(
                NotifyCollectionChangedAction.Replace, newItems = listOf(element), oldItems = listOf(old),
                newStartingIndex = index, oldStartingIndex = index,
            ),
        )
        return old
    }

    override fun clear() {
        if (items.isEmpty()) return
        items.clear()
        raise(NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Reset))
    }

    /** ObservableCollection.Move */
    open fun move(oldIndex: Int, newIndex: Int) {
        val item = items.removeAt(oldIndex)
        items.add(newIndex, item)
        raise(
            NotifyCollectionChangedEventArgs(
                NotifyCollectionChangedAction.Move, newItems = listOf(item), oldItems = listOf(item),
                newStartingIndex = newIndex, oldStartingIndex = oldIndex,
            ),
        )
    }

    /** SystemExtensions.AddRange for ObservableCollection. */
    open fun addRange(elements: Iterable<T>) {
        for (e in elements) add(e)
    }

    protected fun raise(args: NotifyCollectionChangedEventArgs) {
        collectionChanged(this, args)
    }
}

/** `ReadOnlyObservableCollection<T>`: a read-only view with change notification passed through. */
class ReadOnlyObservableCollection<T>(private val inner: ObservableCollection<T>) : AbstractList<T>(), INotifyCollectionChanged {
    override val collectionChanged: Event<NotifyCollectionChangedEventArgs> get() = inner.collectionChanged
    override val size: Int get() = inner.size
    override fun get(index: Int): T = inner[index]
}

/** C# `int[,].GetLength(dimension)` for an `Array<IntArray>` used as a row-major 2D array (`a[x][y]`). */
fun Array<IntArray>.getLength(dimension: Int): Int = if (dimension == 0) size else if (size == 0) 0 else this[0].size
