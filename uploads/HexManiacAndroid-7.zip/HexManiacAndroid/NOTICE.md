# Notices

## HexManiacAdvance

This project is an Android port of HexManiacAdvance (https://github.com/haven1433/HexManiacAdvance). The Kotlin engine in
`core/src/main/kotlin` is a translation of the original C# source (models, view models and the logic of the tools), the
unit tests in `core/src/test` are translations of the original xunit tests, and the reference data in
`core/src/main/resources/hma` (character sets, table and metadata definitions, script references, scripts) comes from that
project. The layout and behaviour of the app follow the original WPF application.

HexManiacAdvance is released under the MIT license:

```
MIT License

Copyright (c) 2018 haven1433

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
