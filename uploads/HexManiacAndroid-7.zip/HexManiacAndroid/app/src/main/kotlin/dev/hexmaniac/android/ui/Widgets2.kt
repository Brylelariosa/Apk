package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.viewmodels.tools.PaletteCollection

/** Lays children out left to right and wraps to a new line when the row is full. */
class FlowLayout(context: Context) : ViewGroup(context) {
    var hGap = 0
    var vGap = 0

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val maxWidth = if (MeasureSpec.getMode(widthSpec) == MeasureSpec.UNSPECIFIED) Int.MAX_VALUE else MeasureSpec.getSize(widthSpec)
        var x = 0
        var y = 0
        var lineHeight = 0
        var used = 0
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child.visibility == GONE) continue
            measureChildWithMargins(child, widthSpec, 0, heightSpec, 0)
            val lp = child.layoutParams as MarginLayoutParams
            val w = child.measuredWidth + lp.leftMargin + lp.rightMargin
            val h = child.measuredHeight + lp.topMargin + lp.bottomMargin
            if (x > 0 && x + w > maxWidth) {
                x = 0
                y += lineHeight + vGap
                lineHeight = 0
            }
            x += w + hGap
            lineHeight = maxOf(lineHeight, h)
            used = maxOf(used, x - hGap)
        }
        val width = if (MeasureSpec.getMode(widthSpec) == MeasureSpec.EXACTLY) maxWidth else minOf(used, maxWidth)
        setMeasuredDimension(width, y + lineHeight)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxWidth = r - l
        var x = 0
        var y = 0
        var lineHeight = 0
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (child.visibility == GONE) continue
            val lp = child.layoutParams as MarginLayoutParams
            val w = child.measuredWidth + lp.leftMargin + lp.rightMargin
            val h = child.measuredHeight + lp.topMargin + lp.bottomMargin
            if (x > 0 && x + w > maxWidth) {
                x = 0
                y += lineHeight + vGap
                lineHeight = 0
            }
            child.layout(x + lp.leftMargin, y + lp.topMargin, x + lp.leftMargin + child.measuredWidth, y + lp.topMargin + child.measuredHeight)
            x += w + hGap
            lineHeight = maxOf(lineHeight, h)
        }
    }

    override fun generateLayoutParams(attrs: android.util.AttributeSet?): LayoutParams = MarginLayoutParams(context, attrs)
    override fun generateDefaultLayoutParams(): LayoutParams = MarginLayoutParams(WRAP, WRAP)
    override fun generateLayoutParams(p: LayoutParams?): LayoutParams = MarginLayoutParams(p)
    override fun checkLayoutParams(p: LayoutParams?): Boolean = p is MarginLayoutParams
}

fun gbaToArgb(c: Int): Int = Color.rgb(((c shr 10) and 31) * 255 / 31, ((c shr 5) and 31) * 255 / 31, (c and 31) * 255 / 31)

/** A small filled square showing one 15 bit color. */
class SwatchView(context: Context) : View(context) {
    var color: Int = 0
        set(value) {
            field = value
            invalidate()
        }
    var marked = false
        set(value) {
            field = value
            invalidate()
        }
    private val fill = Paint()
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = Ui.dpf(2f) }

    override fun onDraw(canvas: Canvas) {
        fill.color = gbaToArgb(color)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), fill)
        stroke.color = if (marked) Palette.accent else Palette.secondary
        stroke.strokeWidth = if (marked) Ui.dpf(3f) else Ui.dpf(1f)
        val half = stroke.strokeWidth / 2f
        canvas.drawRect(RectF(half, half, width - half, height - half), stroke)
    }
}

object ColorPicker {
    /** Edits one 5-bit-per-channel color. [onPick] is called with the new value when the user presses OK. */
    fun show(context: Context, initial: Int, onPick: (Int) -> Unit) {
        val channels = intArrayOf((initial shr 10) and 31, (initial shr 5) and 31, initial and 31)
        val root = context.vbox()
        root.setPadding(Ui.dp(12), Ui.dp(12), Ui.dp(12), Ui.dp(8))
        root.addView(Dialogs.title(context, "Color"))
        val swatch = SwatchView(context)
        swatch.color = initial
        root.addView(swatch, LinearLayout.LayoutParams(MATCH, Ui.dp(48)).also { it.topMargin = Ui.dp(8) })
        val hex = context.label("", 13f, Palette.secondary, mono = true)
        fun current() = (channels[0] shl 10) or (channels[1] shl 5) or channels[2]
        fun refresh() {
            swatch.color = current()
            hex.text = "R " + channels[0] + "  G " + channels[1] + "  B " + channels[2] + "   (" + String.format("%04X", current()) + ")"
        }
        val names = arrayOf("Red", "Green", "Blue")
        for (i in 0 until 3) {
            val row = context.hbox()
            row.addView(context.label(names[i], 13f, Palette.primary), LinearLayout.LayoutParams(Ui.dp(54), WRAP))
            val bar = SeekBar(context)
            bar.max = 31
            bar.progress = channels[i]
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    channels[i] = progress
                    refresh()
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
            row.addView(bar, LinearLayout.LayoutParams(0, Ui.dp(40), 1f))
            root.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(6) })
        }
        root.addView(hex, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = Ui.dp(8) })
        refresh()
        val dialog = Dialogs.create(context, root, 340)
        val buttons = context.hbox()
        buttons.addView(context.fill())
        buttons.addView(context.angleButton("Cancel") { dialog.dismiss() })
        buttons.addView(context.angleButton("OK", AngleDrawable.Direction.Out) {
            dialog.dismiss()
            onPick(current())
        }.margin(left = 8))
        root.addView(buttons, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(10) })
        dialog.show()
    }
}

/** A grid of swatches for a [PaletteCollection] with selection, copy/paste and editing buttons. */
class PaletteView(context: Context, private val colors: PaletteCollection, private val binder: Binder) : LinearLayout(context) {
    private val flow = FlowLayout(context).also { it.hGap = Ui.dp(2); it.vGap = Ui.dp(2) }
    private val buttons = FlowLayout(context).also { it.hGap = Ui.dp(4); it.vGap = Ui.dp(4) }
    private var extend = false

    init {
        orientation = VERTICAL
        addView(flow, LayoutParams(MATCH, WRAP))
        buttons.addView(context.angleButton("Edit", AngleDrawable.Direction.Out, size = 12f) {
            val index = Engine.read { colors.selectionStart }
            val color = Engine.read { colors.elements.getOrNull(index)?.color?.toInt() ?: 0 }
            ColorPicker.show(context, color) { picked ->
                Engine.post {
                    val start = minOf(colors.selectionStart, colors.selectionEnd)
                    val end = maxOf(colors.selectionStart, colors.selectionEnd)
                    for (i in start..end) if (i in 0 until colors.elements.size) colors.elements[i].color = picked.toShort()
                    colors.pushColorsToModel()
                }
            }
        }.margin(right = 4), LayoutParams(WRAP, WRAP))
        val rangeButton = context.angleButton("Range", AngleDrawable.Direction.Out, size = 12f) {}
        rangeButton.setOnClickListener {
            extend = !extend
            rangeButton.setTextColor(if (extend) Palette.accent else Palette.primary)
        }
        buttons.addView(rangeButton)
        fun command(text: String, direction: AngleDrawable.Direction, cmd: () -> dev.hexmaniac.core.system.ICommand) {
            val button = context.angleButton(text, direction, size = 12f) { cmd().fire() }
            buttons.addView(button)
            binder.watchCommand(cmd()) { button.alpha = if (cmd().canExecute(null)) 1f else 0.4f }
        }
        command("Copy", AngleDrawable.Direction.Out) { colors.copy }
        command("Paste", AngleDrawable.Direction.Out) { colors.paste }
        command("Gradient", AngleDrawable.Direction.Out) { colors.createGradient }
        command("Reduce", AngleDrawable.Direction.Out) { colors.singleReduce }
        command("Delete", AngleDrawable.Direction.Out) { colors.deleteColor }
        addView(buttons, LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
        binder.watchCollection(colors.elements) { rebuild() }
        binder.watch(colors, "selectionStart", "selectionEnd") { updateSelection() }
    }

    private fun rebuild() {
        flow.removeAllViews()
        val elements = colors.elements
        val perRow = maxOf(1, colors.colorWidth)
        val size = Ui.dp(if (perRow > 16) 18 else 24)
        for (i in 0 until elements.size) {
            val swatch = SwatchView(context)
            swatch.color = elements[i].color.toInt()
            swatch.setOnClickListener {
                Engine.post {
                    if (extend) colors.selectionEnd = i else {
                        colors.selectionStart = i
                        colors.selectionEnd = i
                    }
                }
            }
            swatch.setOnLongClickListener {
                Engine.post {
                    colors.selectionStart = i
                    colors.selectionEnd = i
                }
                ColorPicker.show(context, elements[i].color.toInt()) { picked ->
                    Engine.post {
                        if (i in 0 until colors.elements.size) colors.elements[i].color = picked.toShort()
                        colors.pushColorsToModel()
                    }
                }
                true
            }
            flow.addView(swatch, MarginLayoutParams(size, size))
        }
        updateSelection()
    }

    private fun updateSelection() {
        val low = minOf(colors.selectionStart, colors.selectionEnd)
        val high = maxOf(colors.selectionStart, colors.selectionEnd)
        for (i in 0 until flow.childCount) (flow.getChildAt(i) as? SwatchView)?.marked = i in low..high
    }
}

/** Lets the user press and drag across a view, reporting the position in view coordinates. */
class DragSurface(context: Context) : View(context) {
    var onDown: ((Float, Float) -> Unit)? = null
    var onMove: ((Float, Float) -> Unit)? = null
    var onUp: ((Float, Float) -> Unit)? = null

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                onDown?.invoke(event.x, event.y)
            }
            MotionEvent.ACTION_MOVE -> onMove?.invoke(event.x, event.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onUp?.invoke(event.x, event.y)
        }
        return true
    }
}
