package dev.hexmaniac.android.host

import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import dev.hexmaniac.core.system.SynchronizationContext
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.ReentrantLock

/**
 * The ported HexManiac view-models were written for a single "UI thread" (the WPF dispatcher). On Android that role
 * is played by one dedicated engine thread, so the real UI thread never runs view-model code that may have to wait
 * for the user (file pickers, option dialogs, ...).
 *
 *  - Everything that changes view-model state runs on the engine thread: [post] / [call].
 *  - The Android UI thread only reads view-model state through [read] / [tryRead], which take the engine lock.
 *  - While the engine thread waits for the user ([awaitUi]) it releases the lock, so the UI stays responsive.
 *  - Never call [call] (or anything that waits for the engine thread) while holding the lock on the UI thread.
 */
object Engine {
    private const val TAG = "HexManiac"

    private val thread = HandlerThread("hma-engine")
    private lateinit var handler: Handler
    private val main = Handler(Looper.getMainLooper())
    private var started = false

    /** Guards all view-model state. Held by the engine thread whenever it runs a posted block. */
    val lock = ReentrantLock()

    /** Called (on the UI thread) when engine code throws. */
    @Volatile var onFailure: (Throwable) -> Unit = { }

    @Synchronized
    fun start() {
        if (started) return
        started = true
        thread.start()
        handler = Handler(thread.looper)
        // Task continuations (await) resume on the engine thread, like WPF resumes on the dispatcher thread.
        SynchronizationContext.post = { block -> post(block) }
        SynchronizationContext.isMainThread = { isEngineThread() }
    }

    fun isEngineThread(): Boolean = Thread.currentThread() === thread
    fun isUiThread(): Boolean = Looper.myLooper() === Looper.getMainLooper()

    private fun guarded(block: () -> Unit) {
        lock.lock()
        try {
            block()
        } catch (t: Throwable) {
            Log.e(TAG, "engine block failed", t)
            val handlerCopy = onFailure
            main.post { handlerCopy(t) }
        } finally {
            lock.unlock()
        }
    }

    /** Runs [block] on the engine thread, holding the lock. Returns immediately. */
    fun post(block: () -> Unit) {
        handler.post { guarded(block) }
    }

    /** Like [post], but runs [block] no earlier than [delayMs]. The returned handle cancels it. */
    fun postDelayed(delayMs: Long, block: () -> Unit): Cancel {
        val runnable = Runnable { guarded(block) }
        handler.postDelayed(runnable, delayMs)
        return Cancel { handler.removeCallbacks(runnable) }
    }

    class Cancel(private val action: () -> Unit) {
        fun cancel() = action()
    }

    /** Runs [block] on the engine thread and waits for it. Runs inline when already on the engine thread. */
    fun <T> call(block: () -> T): T {
        if (isEngineThread()) return block()
        var result: Any? = null
        var failure: Throwable? = null
        val done = CountDownLatch(1)
        handler.post {
            lock.lock()
            try {
                result = block()
            } catch (t: Throwable) {
                failure = t
            } finally {
                lock.unlock()
                done.countDown()
            }
        }
        done.await()
        failure?.let { throw it }
        @Suppress("UNCHECKED_CAST")
        return result as T
    }

    /** UI thread: run [block] while holding the engine lock (blocks while the engine thread is busy). */
    fun <T> read(block: () -> T): T {
        lock.lock()
        try {
            return block()
        } finally {
            lock.unlock()
        }
    }

    /** UI thread: like [read], but gives up (returns null) if the engine stays busy longer than [timeoutMs]. */
    fun <T : Any> tryRead(timeoutMs: Long, block: () -> T): T? {
        if (!lock.tryLock(timeoutMs, TimeUnit.MILLISECONDS)) return null
        try {
            return block()
        } finally {
            lock.unlock()
        }
    }

    /** Runs [block] on the Android UI thread. */
    fun ui(block: () -> Unit) {
        if (isUiThread()) block() else main.post(block)
    }

    fun uiDelayed(delayMs: Long, block: () -> Unit): Cancel {
        val runnable = Runnable(block)
        main.postDelayed(runnable, delayMs)
        return Cancel { main.removeCallbacks(runnable) }
    }

    /** Result channel handed to a UI-thread prompt. [resume] may be called once, from any thread. */
    class Resume<T>(private val deliver: (T) -> Unit) {
        private val used = AtomicBoolean(false)
        fun resume(value: T) {
            if (used.compareAndSet(false, true)) deliver(value)
        }
    }

    /**
     * Engine (or background) thread: show something to the user and wait for the answer. [prompt] runs on the UI
     * thread. The engine lock is released while waiting, so the UI can keep reading view-model state.
     * Must not be called on the UI thread.
     */
    fun <T> awaitUi(prompt: (Resume<T>) -> Unit): T {
        check(!isUiThread()) { "awaitUi must not be called from the UI thread" }
        var answer: Any? = null
        val done = CountDownLatch(1)
        val resume = Resume<T> { value ->
            answer = value
            done.countDown()
        }
        main.post {
            try {
                prompt(resume)
            } catch (t: Throwable) {
                Log.e(TAG, "prompt failed", t)
                done.countDown()
            }
        }
        val holds = lock.holdCount
        repeat(holds) { lock.unlock() }
        try {
            done.await()
        } finally {
            repeat(holds) { lock.lock() }
        }
        @Suppress("UNCHECKED_CAST")
        return answer as T
    }
}
