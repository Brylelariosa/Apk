package dev.hexmaniac.android.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.system.ICommand
import dev.hexmaniac.core.viewmodels.EditorViewModel
import dev.hexmaniac.core.viewmodels.quickedititems.IQuickEditItem

/** One entry of the menu. The lambdas are evaluated on the UI thread under the engine lock when the sheet is built. */
sealed class MenuItem {
    class Cmd(val text: String, val command: () -> ICommand?, val parameter: () -> Any? = { null }) : MenuItem()
    class Act(val text: String, val enabled: () -> Boolean = { true }, val onEngine: Boolean = true, val action: () -> Unit) : MenuItem()
    class Toggle(val text: String, val get: () -> Boolean, val set: (Boolean) -> Unit) : MenuItem()
    class Sub(val text: String, val items: () -> List<MenuItem>) : MenuItem()
    class Note(val text: String, val sub: String) : MenuItem()
    object Sep : MenuItem()
}

/** The accordion style menu that replaces the desktop menu bar. */
class MenuSheet(private val context: Context, private val editor: EditorViewModel, private val callbacks: Callbacks) {
    interface Callbacks {
        fun exit()
        fun openLink(link: String)
        fun showThemeEditor()
        fun showAbout()
    }

    private val fs get() = AppState.fileSystem
    private lateinit var dialog: Dialog
    private lateinit var list: LinearLayout
    private val open = HashSet<String>()

    fun show() {
        val root = context.vbox()
        root.setBackgroundColor(Palette.background)
        val header = context.hbox()
        header.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(8), Ui.dp(10))
        header.addView(context.label("HexManiac Advance", 17f, Palette.primary, bold = true), LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(context.iconButton(Icon.Exit, 36, Palette.secondary) { dialog.dismiss() })
        root.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(context.divider(Palette.secondary))
        list = context.vbox()
        root.addView(context.vscroll(list), LinearLayout.LayoutParams(MATCH, 0, 1f))
        dialog = Dialog(context, android.R.style.Theme_DeviceDefault_NoActionBar)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(root)
        dialog.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            val width = minOf(context.resources.displayMetrics.widthPixels, Ui.dp(340))
            w.setLayout(width, WindowManager.LayoutParams.MATCH_PARENT)
            w.setGravity(Gravity.START)
        }
        rebuild()
        dialog.show()
    }

    private fun sections(): List<Pair<String, () -> List<MenuItem>>> {
        val sections = ArrayList<Pair<String, () -> List<MenuItem>>>()
        sections.add(Pair("File") { fileItems() })
        sections.add(Pair("Edit") { editItems() })
        sections.add(Pair("View") { viewItems() })
        if (editor.showDeveloperMenu) sections.add(Pair("Developer") { developerItems() })
        sections.add(Pair("Utilities") { utilityItems() })
        sections.add(Pair("Tools") { toolItems() })
        sections.add(Pair("Help") { helpItems() })
        return sections
    }

    private fun rebuild() {
        val scrollY = (list.parent as? View)?.scrollY ?: 0
        list.removeAllViews()
        Engine.read {
            for ((name, items) in sections()) {
                val head = context.hbox()
                head.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(10), Ui.dp(12))
                head.setBackgroundColor(if (name in open) Palette.backlight else Color.TRANSPARENT)
                head.addView(context.label(name, 15f, if (name in open) Palette.accent else Palette.primary, bold = true), LinearLayout.LayoutParams(0, WRAP, 1f))
                val arrow = IconView(context, Icon.Chevron, Palette.secondary)
                arrow.rotation = if (name in open) 180f else 0f
                head.addView(arrow, LinearLayout.LayoutParams(Ui.dp(14), Ui.dp(14)))
                head.setOnClickListener {
                    if (name in open) open.remove(name) else open.add(name)
                    rebuild()
                }
                list.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
                if (name in open) addItems(list, items(), 0)
                list.addView(context.divider(Palette.backlight))
            }
        }
        (list.parent as? View)?.post { (list.parent as? View)?.scrollTo(0, scrollY) }
    }

    private fun addItems(container: LinearLayout, items: List<MenuItem>, depth: Int) {
        for (item in items) {
            when (item) {
                is MenuItem.Sep -> container.addView(context.divider(Palette.backlight), LinearLayout.LayoutParams(MATCH, 1).also { it.setMargins(Ui.dp(20 + depth * 12), Ui.dp(4), Ui.dp(12), Ui.dp(4)) })
                is MenuItem.Note -> container.addView(row(item.text, item.sub, depth, true, null) {})
                is MenuItem.Cmd -> {
                    val command = item.command()
                    val parameter = item.parameter()
                    val enabled = command != null && command.canExecute(parameter)
                    container.addView(row(item.text, null, depth, enabled, null) {
                        dialog.dismiss()
                        command.fire(parameter)
                    })
                }
                is MenuItem.Act -> {
                    val enabled = item.enabled()
                    container.addView(row(item.text, null, depth, enabled, null) {
                        dialog.dismiss()
                        if (item.onEngine) Engine.post { item.action() } else item.action()
                    })
                }
                is MenuItem.Toggle -> {
                    val on = item.get()
                    container.addView(row(item.text, null, depth, true, on) {
                        Engine.post { item.set(!on) }
                        dialog.window?.decorView?.postDelayed({ rebuild() }, 120)
                    })
                }
                is MenuItem.Sub -> {
                    val key = "sub:" + depth + ":" + item.text
                    val expanded = key in open
                    container.addView(row(item.text + if (expanded) "  \u25BE" else "  \u25B8", null, depth, true, null) {
                        if (expanded) open.remove(key) else open.add(key)
                        rebuild()
                    })
                    if (expanded) addItems(container, item.items(), depth + 1)
                }
            }
        }
    }

    private fun row(text: String, sub: String?, depth: Int, enabled: Boolean, checked: Boolean?, onClick: () -> Unit): View {
        val row = context.hbox()
        row.setPadding(Ui.dp(22 + depth * 14), Ui.dp(10), Ui.dp(12), Ui.dp(10))
        val box = context.vbox()
        box.addView(context.label(text, 14f, if (enabled) Palette.primary else Palette.secondary))
        if (!sub.isNullOrEmpty()) box.addView(context.label(sub, 11f, Palette.secondary).also { it.setPadding(0, Ui.dp(2), 0, 0) })
        row.addView(box, LinearLayout.LayoutParams(0, WRAP, 1f))
        if (checked != null) {
            val mark = context.label(if (checked) "\u2713" else "", 16f, Palette.accent, bold = true)
            row.addView(mark, LinearLayout.LayoutParams(Ui.dp(24), WRAP))
        }
        row.alpha = if (enabled) 1f else 0.55f
        row.isClickable = true
        row.setOnClickListener { if (enabled) onClick() }
        return row
    }

    // ---------------------------------------------------------------- menu contents

    private fun fileItems(): List<MenuItem> = listOf(
        MenuItem.Cmd("New", { editor.new }),
        MenuItem.Cmd("Open", { editor.open }),
        MenuItem.Sub("Open Recent") {
            editor.recentFileViewModels.map { recent -> MenuItem.Cmd(recent.shortName, { recent.open }) }
        },
        MenuItem.Cmd("Duplicate Current Tab", { editor.duplicateCurrentTab }),
        MenuItem.Sep,
        MenuItem.Cmd("Save", { editor.save }),
        MenuItem.Cmd("Save As", { editor.saveAs }),
        MenuItem.Cmd("Save All", { editor.saveAll }),
        MenuItem.Cmd("Export Backup", { editor.exportBackup }),
        MenuItem.Sep,
        MenuItem.Act("Calculate Common Hashes", { editor.canCalculateHashes }) { editor.calculateHashes() },
        MenuItem.Cmd("Run", { editor.runFile }, { fs }),
        MenuItem.Sep,
        MenuItem.Cmd("Close Current Tab", { editor.close }, { fs }),
        MenuItem.Act("Exit", onEngine = false) { callbacks.exit() },
    )

    private fun editItems(): List<MenuItem> = listOf(
        MenuItem.Cmd("Undo", { editor.undo }),
        MenuItem.Cmd("Redo", { editor.redo }),
        MenuItem.Sep,
        MenuItem.Sub("Display As...") {
            listOf(
                MenuItem.Cmd("Text", { editor.displayAsText }),
                MenuItem.Cmd("Event Script", { editor.displayAsEventScript }),
                MenuItem.Cmd("Sprite", { editor.displayAsSprite }),
                MenuItem.Cmd("Color Palette", { editor.displayAsColorPalette }),
            )
        },
        MenuItem.Cmd("Cut", { editor.cut }),
        MenuItem.Cmd("Copy", { editor.copy }),
        MenuItem.Cmd("Deep Copy", { editor.deepCopy }),
        MenuItem.Cmd("Paste / Replace", { editor.paste }),
        MenuItem.Cmd("Delete", { editor.delete }),
        MenuItem.Cmd("Select All", { editor.selectAll }),
        MenuItem.Sep,
        MenuItem.Cmd("Find", { editor.showFind }, { true }),
        MenuItem.Cmd("Find Next", { editor.findNext }, { editor.findText }),
        MenuItem.Cmd("Find Previous", { editor.findPrevious }, { editor.findText }),
        MenuItem.Cmd("Goto", { editor.gotoViewModel.showGoto }, { true }),
        MenuItem.Cmd("Go Back", { editor.back }),
        MenuItem.Cmd("Go Forward", { editor.forward }),
        MenuItem.Cmd("Show Hex Converter", { editor.showHexConverter }, { true }),
    )

    private fun viewItems(): List<MenuItem> = listOf(
        MenuItem.Sub("Diff") {
            listOf(
                MenuItem.Cmd("Diff Since Last Save", { editor.diffSinceLastSave }),
                MenuItem.Cmd("Diff selected tab with left neighbor", { editor.diffLeft }),
                MenuItem.Cmd("Diff selected tab with right neighbor", { editor.diffRight }),
                MenuItem.Sep,
                MenuItem.Toggle("Exclude Pointer-only changes from diffs", { editor.hideDiffPointerChanges }, { editor.hideDiffPointerChanges = it }),
            )
        },
        MenuItem.Sep,
        MenuItem.Toggle("Show Matrix Grid", { editor.showMatrix }, { editor.showMatrix = it }),
        MenuItem.Toggle("Animate when Scrolling", { editor.animateScroll }, { editor.animateScroll = it }),
        MenuItem.Toggle("Use Table Entry Headers", { editor.useTableEntryHeaders }, { editor.useTableEntryHeaders = it }),
        MenuItem.Toggle("Enable Single Table Focus", { editor.allowSingleTableMode }, { editor.allowSingleTableMode = it }),
        MenuItem.Sep,
        MenuItem.Cmd("Reset Zoom", { editor.resetZoom }),
        MenuItem.Cmd("Reset Alignment", { editor.resetAlignment }),
        MenuItem.Act("Customize Theme", onEngine = false) { callbacks.showThemeEditor() },
        MenuItem.Cmd("Clear Error", { editor.clearError }),
    )

    private fun developerItems(): List<MenuItem> = listOf(
        MenuItem.Cmd("Copy Aligned Address", { editor.copyAlignedAddress }, { fs }),
    )

    private fun quickEdits(name: String, edits: () -> List<IQuickEditItem>): MenuItem = MenuItem.Sub(name) {
        val viewPort = editor.selectedTab as? dev.hexmaniac.core.viewmodels.IViewPort
        edits().map { edit ->
            val enabled = viewPort != null && edit.canRun(viewPort)
            MenuItem.Act((edit.name ?: "?"), { enabled }) { editor.runQuickEdit(edit) }
        }
    }

    private fun utilityItems(): List<MenuItem> = listOf(
        quickEdits("Pokedex") { editor.quickEditsPokedex },
        quickEdits("Expand") { editor.quickEditsExpansion },
        quickEdits("Misc") { editor.quickEditsMisc },
    )

    private fun toolItems(): List<MenuItem> {
        val tools = editor.tools
        return listOf(
            MenuItem.Cmd("Hide All Tools", { tools?.hideCommand }),
            MenuItem.Sep,
            MenuItem.Cmd("Toggle Table Tool", { tools?.tableToolCommand }),
            MenuItem.Cmd("Toggle Text Tool", { tools?.stringToolCommand }),
            MenuItem.Cmd("Toggle Image Tool", { tools?.spriteToolCommand }),
            MenuItem.Cmd("Toggle Code Tool", { tools?.codeToolCommand }),
            MenuItem.Cmd("Show Hex Converter", { editor.showHexConverter }, { true }),
            MenuItem.Toggle("Toggle Automation Tool", { editor.showAutomationPanel }, { editor.showAutomationPanel = it }),
            MenuItem.Sep,
            MenuItem.Toggle("Spartan Mode", { editor.spartanMode }, { editor.spartanMode = it }),
        )
    }

    private fun link(text: String, url: String) = MenuItem.Act(text, onEngine = false) { callbacks.openLink(url) }

    private fun helpItems(): List<MenuItem> {
        val wiki = "https://github.com/haven1433/HexManiacAdvance/wiki"
        fun game(name: String, repo: String, symbols: String, battle: String) = MenuItem.Sub(name) {
            listOf(
                link("List of Script Variables", "https://github.com/pret/$repo/blob/master/include/constants/vars.h"),
                link("List of Script Flags", "https://github.com/pret/$repo/blob/master/include/constants/flags.h"),
                link("List of All Symbols", "https://raw.githubusercontent.com/pret/$repo/symbols/$symbols"),
                link("Battle Outcome Constants", "https://github.com/pret/$repo/blob/master/include/constants/battle.h$battle"),
            )
        }
        return listOf(
            MenuItem.Act("Update", { editor.isNewVersionAvailable }, onEngine = false) { callbacks.openLink("https://github.com/haven1433/HexManiacAdvance/releases") },
            link("Wiki", wiki),
            link("Tutorials", "$wiki/Tutorials"),
            link("Event Script Reference", "$wiki/Everything-You-Need-for-Event-Scripting-in-HexManiac-Advance"),
            MenuItem.Sub("Online Reference Content") {
                listOf(
                    game("Ruby", "pokeruby", "pokeruby.sym", "#L67"),
                    game("FireRed", "pokefirered", "pokefirered.sym", "#L75"),
                    game("Emerald", "pokeemerald", "pokeemerald.sym", ""),
                )
            },
            link("Report an Issue", "https://github.com/haven1433/HexManiacAdvance/issues"),
            link("Discord", "https://discord.gg/x9eQuBg"),
            MenuItem.Sub("Assist Development") { listOf(MenuItem.Cmd("Copy Anchor Reference", { editor.copyAnchorReference }, { fs })) },
            MenuItem.Act("About", onEngine = false) { callbacks.showAbout() },
        )
    }
}

/** Edits the six values the desktop theme window exposes. */
object ThemeDialog {
    fun show(context: Context, editor: EditorViewModel, onClosed: () -> Unit) {
        val theme = Engine.read { editor.theme }
        val root = context.vbox()
        root.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(10))
        root.addView(Dialogs.title(context, "Customize Theme"))
        val binder = Binder()

        fun colorRow(label: String, property: String, get: () -> String, set: (String) -> Unit) {
            val row = context.hbox()
            row.addView(context.label(label, 13f, Palette.primary), LinearLayout.LayoutParams(0, WRAP, 1f))
            val edit = context.textBox(size = 13f, mono = true)
            edit.minimumWidth = Ui.dp(110)
            binder.bindText(edit, theme, property, get, set)
            row.addView(edit, LinearLayout.LayoutParams(Ui.dp(120), WRAP))
            val swatch = View(context)
            row.addView(swatch, LinearLayout.LayoutParams(Ui.dp(34), Ui.dp(34)).also { it.leftMargin = Ui.dp(6) })
            binder.watch(theme, property) {
                val parsed = try {
                    Color.parseColor(get())
                } catch (e: IllegalArgumentException) {
                    Palette.secondary
                }
                swatch.setBackgroundColor(parsed)
            }
            root.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(8) })
        }

        fun sliderRow(label: String, property: String, get: () -> Double, set: (Double) -> Unit) {
            val row = context.hbox()
            row.addView(context.label(label, 13f, Palette.primary), LinearLayout.LayoutParams(Ui.dp(130), WRAP))
            val bar = SeekBar(context)
            bar.max = 100
            var silent = false
            binder.watch(theme, property) {
                silent = true
                bar.progress = (get() * 100).toInt()
                silent = false
            }
            bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!silent && fromUser) Engine.post { set(progress / 100.0) }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
            row.addView(bar, LinearLayout.LayoutParams(0, Ui.dp(40), 1f))
            root.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
        }

        Engine.read {
            colorRow("Text Color", "primaryColor", { theme.primaryColor }, { theme.primaryColor = it })
            colorRow("Background Color", "backgroundColor", { theme.backgroundColor }, { theme.backgroundColor = it })
            sliderRow("Highlight Brightness", "highlightBrightness", { theme.highlightBrightness }, { theme.highlightBrightness = it })
            sliderRow("Hue Shift", "hueOffset", { theme.hueOffset }, { theme.hueOffset = it })
            sliderRow("Accent Saturation", "accentSaturation", { theme.accentSaturation }, { theme.accentSaturation = it })
            sliderRow("Accent Brightness", "accentValue", { theme.accentValue }, { theme.accentValue = it })
        }
        val dialog = Dialogs.create(context, root, 420)
        val buttons = context.hbox()
        buttons.addView(context.angleButton("Reset") { Engine.post { theme.reset() } })
        buttons.addView(context.fill())
        buttons.addView(context.angleButton("Close", AngleDrawable.Direction.Out) { dialog.dismiss() })
        root.addView(buttons, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(14) })
        dialog.setOnDismissListener {
            binder.dispose()
            onClosed()
        }
        dialog.show()
    }
}

object AboutDialog {
    fun show(context: Context) {
        val root = context.vbox()
        root.setPadding(Ui.dp(16), Ui.dp(16), Ui.dp(16), Ui.dp(12))
        root.addView(Dialogs.title(context, "HexManiac Advance for Android"))
        val body: TextView = context.label(
            "An Android port of HexManiac Advance, the ROM editor for GBA Pok\u00E9mon games created by haven1433 and contributors.\n\n" +
                "The editing engine is a direct port of the original C# view-models; the screens are rebuilt for touch.\n\n" +
                "Original project: github.com/haven1433/HexManiacAdvance (MIT license).",
            13f, Palette.primary,
        )
        body.setPadding(0, Ui.dp(8), 0, Ui.dp(8))
        root.addView(body)
        val dialog = Dialogs.create(context, root, 400)
        root.addView(context.angleButton("OK", AngleDrawable.Direction.Out) { dialog.dismiss() }, LinearLayout.LayoutParams(WRAP, WRAP).also { it.gravity = Gravity.END; it.topMargin = Ui.dp(8) })
        dialog.show()
    }
}
