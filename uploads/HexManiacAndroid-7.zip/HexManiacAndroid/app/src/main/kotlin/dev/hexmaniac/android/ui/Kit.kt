package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import dev.hexmaniac.core.viewmodels.Theme

/** Pixel helpers. [init] is called once with the application context. */
object Ui {
    var density = 1f
        private set
    var fontScale = 1f
        private set
    val mono: Typeface = Typeface.MONOSPACE

    fun init(context: Context) {
        density = context.resources.displayMetrics.density
        fontScale = context.resources.configuration.fontScale
    }

    fun dp(value: Int): Int = (value * density + 0.5f).toInt()
    fun dpf(value: Float): Float = value * density
}

fun Context.dp(value: Int): Int = Ui.dp(value)

/** The colors of the app, derived from the engine's [Theme] (the DynamicResources of the desktop app). */
object Palette {
    var primary = 0xFFDDDDDD.toInt()
    var secondary = 0xFF888888.toInt()
    var background = 0xFF222222.toInt()
    var backlight = 0xFF3A3A3A.toInt()
    var accent = 0xFF5CB0E0.toInt()
    var error = 0xFFE06060.toInt()
    var text1 = 0xFFE0B060.toInt()
    var text2 = 0xFF70C090.toInt()
    var data1 = 0xFF70B0E0.toInt()
    var data2 = 0xFFB090E0.toInt()
    var stream1 = 0xFFE09090.toInt()
    var stream2 = 0xFF90D0D0.toInt()
    var editBackground = 0xFF3A4A3A.toInt()

    private fun parse(text: String, fallback: Int): Int = try {
        Color.parseColor(if (text.startsWith("#")) text else "#$text")
    } catch (e: IllegalArgumentException) {
        fallback
    }

    /** Call while holding the engine lock. */
    fun apply(theme: Theme) {
        primary = parse(theme.primary, primary)
        secondary = parse(theme.secondary, secondary)
        background = parse(theme.background, background)
        backlight = parse(theme.backlight, backlight)
        accent = parse(theme.accent, accent)
        error = parse(theme.error, error)
        text1 = parse(theme.text1, text1)
        text2 = parse(theme.text2, text2)
        data1 = parse(theme.data1, data1)
        data2 = parse(theme.data2, data2)
        stream1 = parse(theme.stream1, stream1)
        stream2 = parse(theme.stream2, stream2)
        editBackground = parse(theme.editBackground, editBackground)
    }

    fun alpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)
}

/** Parses the subset of path data used by the icons of the desktop app (M L H V C S Q Z, absolute and relative). */
object PathData {
    fun parse(data: String): Path {
        val path = Path()
        val tokens = Regex("[MmLlHhVvCcSsQqZz]|-?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?").findAll(data).map { it.value }.toList()
        var i = 0
        var cx = 0f
        var cy = 0f
        var sx = 0f
        var sy = 0f
        var lastCtrlX = 0f
        var lastCtrlY = 0f
        var command = 'M'
        fun num(): Float = tokens[i++].toFloat()
        while (i < tokens.size) {
            val token = tokens[i]
            if (token[0].isLetter()) {
                command = token[0]
                i++
                if (command == 'Z' || command == 'z') {
                    path.close()
                    cx = sx
                    cy = sy
                    continue
                }
            }
            val relative = command.isLowerCase()
            when (command.uppercaseChar()) {
                'M' -> {
                    val x = num() + if (relative) cx else 0f
                    val y = num() + if (relative) cy else 0f
                    path.moveTo(x, y)
                    cx = x; cy = y; sx = x; sy = y
                    command = if (relative) 'l' else 'L'
                }
                'L' -> {
                    val x = num() + if (relative) cx else 0f
                    val y = num() + if (relative) cy else 0f
                    path.lineTo(x, y)
                    cx = x; cy = y
                }
                'H' -> {
                    val x = num() + if (relative) cx else 0f
                    path.lineTo(x, cy)
                    cx = x
                }
                'V' -> {
                    val y = num() + if (relative) cy else 0f
                    path.lineTo(cx, y)
                    cy = y
                }
                'C' -> {
                    val ox = if (relative) cx else 0f
                    val oy = if (relative) cy else 0f
                    val x1 = num() + ox; val y1 = num() + oy
                    val x2 = num() + ox; val y2 = num() + oy
                    val x = num() + ox; val y = num() + oy
                    path.cubicTo(x1, y1, x2, y2, x, y)
                    lastCtrlX = x2; lastCtrlY = y2
                    cx = x; cy = y
                }
                'S' -> {
                    val ox = if (relative) cx else 0f
                    val oy = if (relative) cy else 0f
                    val x2 = num() + ox; val y2 = num() + oy
                    val x = num() + ox; val y = num() + oy
                    path.cubicTo(2 * cx - lastCtrlX, 2 * cy - lastCtrlY, x2, y2, x, y)
                    lastCtrlX = x2; lastCtrlY = y2
                    cx = x; cy = y
                }
                'Q' -> {
                    val ox = if (relative) cx else 0f
                    val oy = if (relative) cy else 0f
                    val x1 = num() + ox; val y1 = num() + oy
                    val x = num() + ox; val y = num() + oy
                    path.quadTo(x1, y1, x, y)
                    cx = x; cy = y
                }
                else -> i++
            }
        }
        return path
    }
}

/** The icons of the desktop app (Resources/Icons.xaml) that the Android screens use. */
enum class Icon(private val data: String) {
    RightArrow("M5,5 L15,5 L15,0 L25,10 L15,20 L15,15 L5,15 z"),
    LeftArrow("M-5,5 L-15,5 L-15,0 L-25,10 L-15,20 L-15,15 L-5,15 z"),
    UndoArrow("m-7,2 L-3,-5 -2,-2 7,-5 6,2 3,6 4,-1 -1,2 0,5 z"),
    RedoArrow("m7,2 L3,-5 2,-2 -7,-5 -6,2 -3,6 -4,-1 1,2 0,5 z"),
    Home("M0,0 L 0,-3 2,-4 4,-3 4,0 3,0 3,-2 2,-2 2,0 Z"),
    Exit("m0,0 l -1,-1 1,-1 1,1 1,-1 1,1 -1,1 1,1 -1,1 -1,-1 -1,1 -1,-1 1,-1"),
    Chevron("M0,0 L1,0 2,1 3,0 4,0 3,1 2,2 Z"),
    ChevronUp("M0,0 L 1,0 2,-1 3,0 4,0 3,-1 2,-2 Z"),
    Add("M -5,-5 L -5,-10 0,-10 0,-5 5,-5 5,0 0,0 0,5 -5,5 -5,0 -10,0 -10,-5 -5,-5"),
    Remove("M -5,-2.5 L 5,-2.5 5,2.5 -5,2.5 -5,-2.5"),
    Check("M0,0 L5,5 10,-5 4.5,2 Z"),
    Flag("M0,10 L0,0 1,0 1,1 6,3 1,5 1,10 Z"),
    ArrowsLeftRight("M6,6 L7,6 7,5 9,7 7,9 7,8 6,8 6,8 5,8 5,9 3,7 5,5 5,6 z"),
    ArrowsUpDown("M6,6 L6,7 5,7 7,9 9,7 8,7 8,6 8,6 8,5 9,5 7,3 5,5 6,5 z"),
    MultiList("M0,0 l12,0 0,1 -12,0 z M15,0 l12,0 0,1 -12,0 z M0,5 l12,0 0,1 -12,0 z M0,10 l12,0 0,1 -12,0 z M15,5 l12,0 0,1 -12,0 z M15,10 l12,0 0,1 -12,0 z"),
    Tiles("m0,0 L5,0 5,5 0,5 z M7,0 L12,0 12,5 7,5 z M0,7 L5,7 5,12 0,12 z M7,7 L12,7 12,12 7,12 z"),
    List("m0,0 L5,0 5,5 0,5 z M0,7 L5,7 5,12 0,12 z M0,14 L5,14 5,19 0,19 z M7,2 L19,2 19,3 7,3 z M7,9 l12,0 0,1 -12,0 z m0,6 l12,0 0,1 -12,0 z"),
    Play("M0,0 L5,5 0,10 Z"),
    Menu("M0,0 L16,0 16,2 0,2 Z M0,6 L16,6 16,8 0,8 Z M0,12 L16,12 16,14 0,14 Z"),
    Save("M0,0 L11,0 L14,3 L14,14 L0,14 Z M3,1 L3,5 L10,5 L10,1 Z M3,8 L3,13 L11,13 L11,8 Z"),
    Search("M5,0 C2,0 0,2 0,5 C0,8 2,10 5,10 C6.2,10 7.2,9.6 8,9 L12,13 L13,12 L9,8 C9.6,7.2 10,6.2 10,5 C10,2 8,0 5,0 Z M5,1.5 C7,1.5 8.5,3 8.5,5 C8.5,7 7,8.5 5,8.5 C3,8.5 1.5,7 1.5,5 C1.5,3 3,1.5 5,1.5 Z"),
    Multiple("M2,3 L10,3 L10,13 L2,13 Z M3,4 L3,12 L9,12 L9,4 Z M2,10 L0,10 L0,0 L8,0 L8,2 L1,2 L1,9 L2,9 Z"),
    Keyboard("M0,2 L16,2 L16,12 L0,12 Z M1,3 L1,11 L15,11 L15,3 Z M3,4 L5,4 L5,6 L3,6 Z M6,4 L8,4 L8,6 L6,6 Z M9,4 L11,4 L11,6 L9,6 Z M12,4 L14,4 L14,6 L12,6 Z M4,8 L12,8 L12,9.5 L4,9.5 Z"),
    Tools("M0,0 L7,0 L7,3 L16,3 L16,6 L7,6 L7,9 L0,9 Z M0,12 L16,12 L16,15 L0,15 Z");

    private val path: Path by lazy { PathData.parse(data).also { it.fillType = Path.FillType.EVEN_ODD } }
    private val bounds: RectF by lazy { RectF().also { path.computeBounds(it, true) } }

    fun draw(canvas: Canvas, paint: Paint, left: Float, top: Float, right: Float, bottom: Float) {
        val b = bounds
        val w = b.width().coerceAtLeast(0.001f)
        val h = b.height().coerceAtLeast(0.001f)
        val scale = minOf((right - left) / w, (bottom - top) / h)
        canvas.save()
        canvas.translate(left + ((right - left) - w * scale) / 2f, top + ((bottom - top) - h * scale) / 2f)
        canvas.scale(scale, scale)
        canvas.translate(-b.left, -b.top)
        canvas.drawPath(path, paint)
        canvas.restore()
    }
}

class IconView(context: Context, var icon: Icon, var tint: Int = Palette.secondary) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    init {
        isClickable = false
    }

    fun setIconTint(color: Int) {
        tint = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        paint.color = if (isEnabled) tint else Palette.alpha(tint, 90)
        val pad = Ui.dpf(1f)
        icon.draw(canvas, paint, paddingLeft + pad, paddingTop + pad, width - paddingRight - pad, height - paddingBottom - pad)
    }
}

/** The slanted button/field outline of the desktop app (AngleBorder / AngleButton). */
class AngleDrawable(
    var fill: Int,
    var stroke: Int,
    var direction: Direction = Direction.None,
    var activeStroke: Int = Palette.accent,
) : Drawable() {
    enum class Direction { None, Left, Right, In, Out }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = Ui.dpf(1f)
        strokeJoin = Paint.Join.MITER
    }
    private var pressed = false
    private var enabled = true
    private var focused = false
    private val path = Path()

    override fun isStateful(): Boolean = true

    override fun onStateChange(state: IntArray): Boolean {
        var p = false
        var e = false
        var f = false
        for (s in state) {
            if (s == android.R.attr.state_pressed) p = true
            if (s == android.R.attr.state_enabled) e = true
            if (s == android.R.attr.state_focused) f = true
        }
        val changed = p != pressed || e != enabled || f != focused
        pressed = p
        enabled = e
        focused = f
        return changed
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val half = strokePaint.strokeWidth / 2f
        val left = b.left + half
        val right = b.right - half
        val top = b.top + half
        val bottom = b.bottom - half
        val h = bottom - top
        val e = Ui.dpf(if (direction == Direction.None) 2f else 6f).coerceAtMost((right - left) / 3f)
        val notch = e * 5f / 6f
        val leftPoint = direction == Direction.Left || direction == Direction.Out
        val leftNotch = direction == Direction.Right || direction == Direction.In
        val rightPoint = direction == Direction.Right || direction == Direction.Out
        val rightNotch = direction == Direction.Left || direction == Direction.In
        val ltx = left + if (leftPoint) notch else 0f
        val lmx = left + if (leftNotch) notch else 0f
        val rtx = right - if (rightPoint) notch else 0f
        val rmx = right - if (rightNotch) notch else 0f
        path.reset()
        path.moveTo(ltx, top)
        path.lineTo(rtx, top)
        path.lineTo(rmx, top + h / 2f)
        path.lineTo(rtx, bottom)
        path.lineTo(ltx, bottom)
        path.lineTo(lmx, top + h / 2f)
        path.close()
        fillPaint.color = if (enabled) fill else Palette.background
        strokePaint.color = if (pressed || focused) activeStroke else stroke
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, strokePaint)
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
        strokePaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        strokePaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    override fun getPadding(padding: android.graphics.Rect): Boolean {
        val e = Ui.dp(if (direction == Direction.None) 2 else 6)
        padding.set(e, Ui.dp(1), e, Ui.dp(1))
        return true
    }
}

/** A plain rectangle (fill + 1dp border) that dims when disabled; used for text boxes, list rows and panels. */
class BoxDrawable(var fill: Int, var stroke: Int, var activeStroke: Int = Palette.accent, var radius: Float = 0f) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = Ui.dpf(1f)
    }
    private var active = false
    private var enabled = true

    override fun isStateful(): Boolean = true

    override fun onStateChange(state: IntArray): Boolean {
        var a = false
        var e = false
        for (s in state) {
            if (s == android.R.attr.state_pressed || s == android.R.attr.state_focused) a = true
            if (s == android.R.attr.state_enabled) e = true
        }
        val changed = a != active || e != enabled
        active = a
        enabled = e
        return changed
    }

    override fun draw(canvas: Canvas) {
        val half = strokePaint.strokeWidth / 2f
        val rect = RectF(bounds.left + half, bounds.top + half, bounds.right - half, bounds.bottom - half)
        fillPaint.color = if (enabled) fill else Palette.background
        strokePaint.color = if (active) activeStroke else stroke
        if (radius > 0f) {
            canvas.drawRoundRect(rect, radius, radius, fillPaint)
            canvas.drawRoundRect(rect, radius, radius, strokePaint)
        } else {
            canvas.drawRect(rect, fillPaint)
            canvas.drawRect(rect, strokePaint)
        }
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
        strokePaint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        strokePaint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

// ------------------------------------------------------------------------------------------------ view factories

fun Context.label(
    text: CharSequence,
    size: Float = 14f,
    color: Int = Palette.primary,
    bold: Boolean = false,
    italic: Boolean = false,
    mono: Boolean = false,
): TextView = TextView(this).apply {
    this.text = text
    setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
    setTextColor(color)
    val style = when {
        bold && italic -> Typeface.BOLD_ITALIC
        bold -> Typeface.BOLD
        italic -> Typeface.ITALIC
        else -> Typeface.NORMAL
    }
    typeface = Typeface.create(if (mono) Typeface.MONOSPACE else Typeface.DEFAULT, style)
    includeFontPadding = false
}

fun Context.angleButton(
    text: CharSequence,
    direction: AngleDrawable.Direction = AngleDrawable.Direction.None,
    fill: Int = Palette.backlight,
    textColor: Int = Palette.primary,
    size: Float = 14f,
    onClick: () -> Unit,
): TextView = TextView(this).apply {
    this.text = text
    setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
    setTextColor(textColor)
    gravity = Gravity.CENTER
    minHeight = dp(36)
    minWidth = dp(40)
    setPadding(dp(10), dp(4), dp(10), dp(4))
    background = AngleDrawable(fill, Palette.secondary, direction)
    isClickable = true
    setOnClickListener { onClick() }
    isSingleLine = true
}

fun Context.iconButton(icon: Icon, size: Int = 40, tint: Int = Palette.primary, onClick: () -> Unit): IconView =
    IconView(this, icon, tint).apply {
        val pad = dp(10)
        setPadding(pad, pad, pad, pad)
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        background = BoxDrawable(Color.TRANSPARENT, Color.TRANSPARENT)
        isClickable = true
        setOnClickListener { onClick() }
    }

fun Context.textBox(
    text: String = "",
    hint: String = "",
    size: Float = 14f,
    mono: Boolean = false,
    inputType: Int = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS,
): EditText = EditText(this).apply {
    setText(text)
    this.hint = hint
    setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
    setTextColor(Palette.primary)
    setHintTextColor(Palette.secondary)
    highlightColor = Palette.alpha(Palette.accent, 110)
    this.inputType = inputType
    imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_EXTRACT_UI
    isSingleLine = true
    if (mono) typeface = Typeface.MONOSPACE
    minHeight = dp(34)
    setPadding(dp(8), dp(4), dp(8), dp(4))
    background = BoxDrawable(Palette.backlight, Palette.secondary)
    includeFontPadding = false
}

fun Context.hbox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

fun Context.vbox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

fun Context.vscroll(content: View): ScrollView = ScrollView(this).apply {
    isFillViewport = true
    overScrollMode = View.OVER_SCROLL_NEVER
    addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
}

fun Context.hscroll(content: View): HorizontalScrollView = HorizontalScrollView(this).apply {
    isHorizontalScrollBarEnabled = false
    overScrollMode = View.OVER_SCROLL_NEVER
    addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
}

fun Context.divider(color: Int = Palette.backlight, thickness: Int = 1): View = View(this).apply {
    setBackgroundColor(color)
    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, maxOf(1, Ui.dp(thickness)))
}

fun Context.spacer(widthDp: Int, heightDp: Int = 0): View = View(this).apply {
    layoutParams = LinearLayout.LayoutParams(dp(widthDp), dp(heightDp))
}

fun Context.fill(): View = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 0, 1f) }

fun lp(width: Int, height: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(width, height, weight)

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun <T : View> T.margin(left: Int = 0, top: Int = 0, right: Int = 0, bottom: Int = 0): T {
    val p = (layoutParams as? ViewGroup.MarginLayoutParams) ?: LinearLayout.LayoutParams(WRAP, WRAP)
    p.setMargins(Ui.dp(left), Ui.dp(top), Ui.dp(right), Ui.dp(bottom))
    layoutParams = p
    return this
}

fun <T : View> T.sized(width: Int, height: Int, weight: Float = 0f): T {
    layoutParams = LinearLayout.LayoutParams(
        if (width > 0) Ui.dp(width) else width,
        if (height > 0) Ui.dp(height) else height,
        weight,
    )
    return this
}

fun FrameLayout.addFill(view: View) = addView(view, FrameLayout.LayoutParams(MATCH, MATCH))
