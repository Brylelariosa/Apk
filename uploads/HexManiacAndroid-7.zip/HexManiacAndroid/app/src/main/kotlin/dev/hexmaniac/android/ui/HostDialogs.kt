package dev.hexmaniac.android.ui

import android.app.Dialog
import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.android.host.HostUi
import dev.hexmaniac.core.models.ProcessModel
import dev.hexmaniac.core.models.VisualOption
import dev.hexmaniac.core.viewmodels.images.IPixelViewModel
import dev.hexmaniac.core.viewmodels.tools.EnumViewModel
import dev.hexmaniac.core.viewmodels.tools.FlagViewModel

/** The message box and the "pick one of these options" dialog the engine asks its file system for. */
object HostDialogs {
    fun message(context: Context, host: HostUi, message: String, yesNoCancel: Boolean, links: List<ProcessModel>, resume: Engine.Resume<Boolean?>) {
        val root = context.vbox()
        root.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(10))
        val text = context.label(message, 15f, Palette.primary)
        text.setTextIsSelectable(true)
        root.addView(context.vscroll(text), LinearLayout.LayoutParams(MATCH, WRAP, 0f))
        val dialog = Dialogs.create(context, root, 420, false)
        var answered = false
        fun answer(value: Boolean?) {
            if (answered) return
            answered = true
            dialog.dismiss()
            resume.resume(value)
        }
        for (link in links) {
            val view = context.label(link.displayText, 14f, Palette.accent)
            view.paintFlags = view.paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            view.setPadding(0, Ui.dp(8), 0, Ui.dp(4))
            view.setOnClickListener { openLink(host, link) }
            root.addView(view, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        val buttons = context.hbox()
        buttons.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        if (yesNoCancel) {
            buttons.addView(context.angleButton("Cancel") { answer(null) })
            buttons.addView(context.angleButton("No") { answer(false) }.margin(left = 8))
            buttons.addView(context.angleButton("Yes", AngleDrawable.Direction.Out) { answer(true) }.margin(left = 8))
        } else {
            buttons.addView(context.angleButton("OK", AngleDrawable.Direction.Out) { answer(true) })
        }
        root.addView(buttons, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(12) })
        dialog.setOnCancelListener { answer(null) }
        dialog.show()
    }

    private fun openLink(host: HostUi, link: ProcessModel) {
        val content = link.content
        when {
            content.startsWith("http://") || content.startsWith("https://") -> host.openLink(content)
            content.startsWith("~") -> host.writeClipboard(content.substring(1))
            else -> host.writeClipboard(content.trimStart('!', '/'))
        }
    }

    fun options(context: Context, title: String, prompt: String, details: List<List<Any>>?, options: List<VisualOption>, resume: Engine.Resume<Int>) {
        val root = context.vbox()
        root.setPadding(Ui.dp(14), Ui.dp(14), Ui.dp(14), Ui.dp(10))
        root.addView(Dialogs.title(context, title))
        if (prompt.isNotEmpty()) root.addView(context.label(prompt, 14f, Palette.primary).also { it.setPadding(0, Ui.dp(6), 0, Ui.dp(6)) })
        if (details != null) {
            for (row in details) {
                val line = context.hbox()
                line.gravity = Gravity.CENTER_VERTICAL
                for (item in row) {
                    val view: View? = when (item) {
                        is IPixelViewModel -> PixelView(context).also { it.scaleDp = 1f; it.setImage(item) }
                        is FlagViewModel -> CheckRow(context, item.name, item.isSet).also { c -> c.onChange = { checked -> item.isSet = checked } }
                        is EnumViewModel -> Dropdown(context, "").also { d ->
                            d.setItems(item.options.toList(), item.choice)
                            d.onSelect = { index -> item.choice = index }
                        }
                        else -> null
                    }
                    if (view != null) line.addView(view, LinearLayout.LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(8) })
                }
                root.addView(line, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
            }
        }
        val dialog: Dialog = Dialogs.create(context, root, 420, false)
        var answered = false
        fun answer(index: Int) {
            if (answered) return
            answered = true
            dialog.dismiss()
            resume.resume(index)
        }
        val list = context.vbox()
        for ((i, option) in options.withIndex()) {
            val box = context.vbox()
            box.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), Ui.dp(8))
            box.background = AngleDrawable(Palette.backlight, Palette.secondary, AngleDrawable.Direction.Out)
            box.isClickable = true
            box.addView(context.label(option.option, 15f, Palette.primary, bold = true))
            val description = if (option.shortDescription.isNotEmpty()) option.shortDescription else option.description
            if (description.isNotEmpty()) box.addView(context.label(description, 12f, Palette.secondary).also { it.setPadding(0, Ui.dp(2), 0, 0) })
            box.setOnClickListener { answer(i) }
            list.addView(box, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(6) })
        }
        root.addView(context.vscroll(list), LinearLayout.LayoutParams(MATCH, WRAP))
        val cancel = context.angleButton("Cancel") { answer(-1) }
        root.addView(cancel, LinearLayout.LayoutParams(WRAP, WRAP).also { it.gravity = Gravity.END; it.topMargin = Ui.dp(10) })
        dialog.setOnCancelListener { answer(-1) }
        dialog.show()
    }
}
