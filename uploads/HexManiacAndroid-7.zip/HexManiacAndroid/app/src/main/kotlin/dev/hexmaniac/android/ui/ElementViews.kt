package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.viewmodels.images.IPixelViewModel
import dev.hexmaniac.core.viewmodels.tools.BitListArrayElementViewModel
import dev.hexmaniac.core.viewmodels.tools.ButtonArrayElementViewModel
import dev.hexmaniac.core.viewmodels.tools.CalculatedElementViewModel
import dev.hexmaniac.core.viewmodels.tools.CheckBoxTupleElementViewModel
import dev.hexmaniac.core.viewmodels.tools.ColorFieldArrayElementViewModel
import dev.hexmaniac.core.viewmodels.tools.ComboBoxArrayElementViewModel
import dev.hexmaniac.core.viewmodels.tools.ElementContentViewModelType
import dev.hexmaniac.core.viewmodels.tools.EnumTupleElementViewModel
import dev.hexmaniac.core.viewmodels.tools.FieldArrayElementViewModel
import dev.hexmaniac.core.viewmodels.tools.FilteringComboOptions
import dev.hexmaniac.core.viewmodels.tools.IArrayElementViewModel
import dev.hexmaniac.core.viewmodels.tools.MapOptionsArrayElementViewModel
import dev.hexmaniac.core.viewmodels.tools.MultiFieldArrayElementViewModel
import dev.hexmaniac.core.viewmodels.tools.NumericTupleElementViewModel
import dev.hexmaniac.core.viewmodels.tools.OffsetRenderViewModel
import dev.hexmaniac.core.viewmodels.tools.PaletteElementViewModel
import dev.hexmaniac.core.viewmodels.tools.PythonButtonElementViewModel
import dev.hexmaniac.core.viewmodels.tools.SpriteElementViewModel
import dev.hexmaniac.core.viewmodels.tools.SpriteIndicatorElementViewModel
import dev.hexmaniac.core.viewmodels.tools.SplitterArrayElementViewModel
import dev.hexmaniac.core.viewmodels.tools.StreamElementViewModel
import dev.hexmaniac.core.viewmodels.tools.TextStreamElementViewModel
import dev.hexmaniac.core.viewmodels.tools.TrainerPokemonTeamElementViewModel
import dev.hexmaniac.core.viewmodels.tools.TupleArrayElementViewModel

/**
 * Touch versions of the table tool's per-field templates. Everything here is created on the UI thread while the engine
 * lock is held; reads in [Binder.watch] callbacks are safe, writes are posted to the engine thread.
 */
object ElementViews {
    private val Left = AngleDrawable.Direction.Left
    private val Right = AngleDrawable.Direction.Right
    private val Out = AngleDrawable.Direction.Out

    fun create(context: Context, binder: Binder, vm: IArrayElementViewModel): View {
        val view: View = when (vm) {
            is SplitterArrayElementViewModel -> splitter(context, binder, vm)
            is ColorFieldArrayElementViewModel -> colorField(context, binder, vm)
            is FieldArrayElementViewModel -> field(context, binder, vm)
            is ComboBoxArrayElementViewModel -> combo(context, binder, vm)
            is BitListArrayElementViewModel -> bitList(context, binder, vm)
            is TrainerPokemonTeamElementViewModel -> trainerTeam(context, binder, vm)
            is TextStreamElementViewModel -> textStream(context, binder, vm)
            is SpriteElementViewModel -> StreamViews.sprite(context, binder, vm)
            is PaletteElementViewModel -> StreamViews.palette(context, binder, vm)
            is SpriteIndicatorElementViewModel -> spriteIndicator(context, binder, vm)
            is TupleArrayElementViewModel -> tuple(context, binder, vm)
            is CalculatedElementViewModel -> calculated(context, binder, vm)
            is OffsetRenderViewModel -> offsetRender(context, binder, vm)
            is PythonButtonElementViewModel -> pythonButton(context, vm)
            is MultiFieldArrayElementViewModel -> multiField(context, binder, vm)
            is MapOptionsArrayElementViewModel -> mapOptions(context, binder, vm)
            is ButtonArrayElementViewModel -> button(context, binder, vm)
            is StreamElementViewModel -> StreamViews.generic(context, binder, vm)
            else -> context.label("(unsupported field)", 12f, Palette.secondary)
        }
        binder.watch(vm, "visible") { view.visibility = if (vm.visible) View.VISIBLE else View.GONE }
        return view
    }

    // ---------------------------------------------------------------- shared pieces

    internal fun nameLabel(context: Context, text: String, direction: AngleDrawable.Direction): TextView = context.label(text, 13f, Palette.primary).also {
        it.setPadding(Ui.dp(8), Ui.dp(6), Ui.dp(8), Ui.dp(6))
        it.background = AngleDrawable(Palette.background, Palette.secondary, direction)
        it.gravity = Gravity.CENTER_VERTICAL
    }

    /** name on the left, [content] filling the middle, optional [trailing] view on the right */
    internal fun fieldRow(context: Context, name: String, content: View, trailing: View? = null, direction: AngleDrawable.Direction = Left): LinearLayout {
        val row = context.hbox()
        row.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2))
        row.addView(nameLabel(context, name, direction), LinearLayout.LayoutParams(0, WRAP, 0.4f))
        row.addView(content, LinearLayout.LayoutParams(0, WRAP, 0.6f).also { it.leftMargin = Ui.dp(2) })
        if (trailing != null) row.addView(trailing, LinearLayout.LayoutParams(WRAP, WRAP).also { it.leftMargin = Ui.dp(2) })
        return row
    }

    internal fun jumpButton(context: Context, onClick: () -> Unit): View = context.angleButton("\u2192", Right, onClick = onClick).also { it.minimumWidth = Ui.dp(36) }

    private fun errorLine(context: Context, binder: Binder, vm: IArrayElementViewModel, box: LinearLayout) {
        val line = context.label("", 12f, Palette.error)
        line.visibility = View.GONE
        box.addView(line, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(6) })
        binder.watch(vm as dev.hexmaniac.core.system.INotifyPropertyChanged, "isInError", "errorText") {
            val message = vm.errorText
            line.text = message ?: ""
            line.visibility = if (vm.isInError && !message.isNullOrEmpty()) View.VISIBLE else View.GONE
        }
    }

    private fun wrap(context: Context, vararg views: View): LinearLayout {
        val box = context.vbox()
        for (v in views) box.addView(v, LinearLayout.LayoutParams(MATCH, WRAP))
        return box
    }

    // ---------------------------------------------------------------- elements

    private fun splitter(context: Context, binder: Binder, vm: SplitterArrayElementViewModel): View {
        val row = context.hbox()
        row.setPadding(Ui.dp(6), Ui.dp(8), Ui.dp(6), Ui.dp(8))
        row.background = AngleDrawable(Palette.backlight, Palette.secondary, AngleDrawable.Direction.None)
        val arrow = IconView(context, Icon.Chevron, Palette.secondary)
        row.addView(arrow, LinearLayout.LayoutParams(Ui.dp(16), Ui.dp(16)))
        val name = context.label("", 14f, Palette.secondary)
        name.gravity = Gravity.END
        row.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.leftMargin = Ui.dp(8) })
        val link = jumpButton(context) { vm.followLink.fire() }
        row.addView(link, LinearLayout.LayoutParams(WRAP, WRAP).also { it.leftMargin = Ui.dp(6) })
        binder.watch(vm, "sectionName", "showSection") {
            name.text = vm.sectionName
            row.visibility = if (vm.showSection) View.VISIBLE else View.GONE
        }
        binder.watch(vm, "sectionLink", "visible") {
            link.visibility = if (vm.sectionLink != 0) View.VISIBLE else View.GONE
            arrow.rotation = if (vm.visible) 0f else -90f
        }
        row.setOnClickListener { vm.toggleVisibility.fire() }
        row.setOnLongClickListener {
            Dialogs.pick(context, vm.sectionName.ifEmpty { "Section" }, listOf("Expand All", "Collapse All"), -1) { which ->
                if (which == 0) vm.expandAll.fire() else vm.collapseAll.fire()
            }
            true
        }
        return LinearLayout(context).also {
            it.orientation = LinearLayout.VERTICAL
            it.setPadding(0, Ui.dp(10), 0, Ui.dp(2))
            it.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }
    }

    private fun field(context: Context, binder: Binder, vm: FieldArrayElementViewModel): View {
        val edit = context.textBox(size = 13f)
        val numeric = vm.type == ElementContentViewModelType.NumericField
        edit.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE or android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
        binder.bindText(edit, vm, "content", { vm.content }, { vm.content = it })
        edit.setOnEditorActionListener { _, _, _ ->
            Engine.post { if (vm.canAccept()) vm.accept() }
            false
        }
        edit.setOnFocusChangeListener { _, focused -> if (focused) Engine.post { vm.focus() } }
        if (numeric) {
            edit.setOnKeyListener { _, keyCode, event ->
                if (event.action == android.view.KeyEvent.ACTION_DOWN && keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP) {
                    Engine.post { vm.incrementValue() }
                    true
                } else if (event.action == android.view.KeyEvent.ACTION_DOWN && keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                    Engine.post { vm.decrementValue() }
                    true
                } else false
            }
        }
        val isAddress = vm.type == ElementContentViewModelType.Address
        val trailing = if (isAddress) jumpButton(context) { Engine.post { if (vm.canAccept()) vm.accept() } } else null
        val box = context.vbox()
        val nameView = nameLabel(context, vm.name, Left)
        binder.watch(vm, "name") { nameView.text = vm.name }
        val row = context.hbox()
        row.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2))
        row.addView(nameView, LinearLayout.LayoutParams(0, WRAP, 0.4f))
        row.addView(edit, LinearLayout.LayoutParams(0, WRAP, 0.6f).also { it.leftMargin = Ui.dp(2) })
        if (trailing != null) row.addView(trailing, LinearLayout.LayoutParams(Ui.dp(40), WRAP).also { it.leftMargin = Ui.dp(2) })
        box.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        errorLine(context, binder, vm, box)
        binder.watch(vm, "isInError") { edit.background = BoxDrawable(Palette.backlight, if (vm.isInError) Palette.error else Palette.secondary) }
        return box
    }

    private fun colorField(context: Context, binder: Binder, vm: ColorFieldArrayElementViewModel): View {
        val edit = context.textBox(size = 13f)
        binder.bindText(edit, vm, "content", { vm.content }, { vm.content = it })
        val swatch = SwatchView(context)
        binder.watch(vm, "color") { swatch.color = vm.color.toInt() }
        swatch.setOnClickListener {
            val current = Engine.read { vm.color.toInt() }
            ColorPicker.show(context, current) { picked -> Engine.post { vm.color = picked.toShort() } }
        }
        val row = context.hbox()
        row.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2))
        val nameView = nameLabel(context, vm.name, Left)
        binder.watch(vm, "name") { nameView.text = vm.name }
        row.addView(nameView, LinearLayout.LayoutParams(0, WRAP, 0.4f))
        row.addView(swatch, LinearLayout.LayoutParams(Ui.dp(36), Ui.dp(34)).also { it.leftMargin = Ui.dp(2) })
        row.addView(edit, LinearLayout.LayoutParams(0, WRAP, 0.6f).also { it.leftMargin = Ui.dp(2) })
        val box = context.vbox()
        box.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        errorLine(context, binder, vm, box)
        return box
    }

    /** Shows the options of a [FilteringComboOptions] in a dropdown; picking one stores it through the view-model. */
    fun comboDropdown(context: Context, binder: Binder, options: FilteringComboOptions, title: String): Dropdown {
        val dropdown = Dropdown(context, title)
        var itemCount = -1
        binder.watch(options, "allOptions", "filteredOptions", "selectedIndex", "displayText") {
            val all = options.allOptions
            val texts = all?.map { it.text } ?: emptyList()
            if (texts.size != itemCount || options.selectedIndex != dropdown.selectedIndex) {
                itemCount = texts.size
                dropdown.setItems(texts, options.selectedIndex)
            }
            if (options.selectedIndex !in texts.indices) dropdown.text = options.displayText
        }
        dropdown.onSelect = { index -> Engine.post { options.selectedIndex = index } }
        return dropdown
    }

    private fun combo(context: Context, binder: Binder, vm: ComboBoxArrayElementViewModel): View {
        val dropdown = comboDropdown(context, binder, vm.filteringComboOptions, vm.name)
        val jump = jumpButton(context) { vm.gotoSource.fire() }
        val nameView = nameLabel(context, vm.name, Left)
        binder.watch(vm, "name") { nameView.text = vm.name }
        val row = context.hbox()
        row.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2))
        row.addView(nameView, LinearLayout.LayoutParams(0, WRAP, 0.4f))
        row.addView(dropdown, LinearLayout.LayoutParams(0, WRAP, 0.6f).also { it.leftMargin = Ui.dp(2) })
        row.addView(jump, LinearLayout.LayoutParams(Ui.dp(40), WRAP).also { it.leftMargin = Ui.dp(2) })
        val box = context.vbox()
        box.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        errorLine(context, binder, vm, box)
        return box
    }

    private fun bitList(context: Context, binder: Binder, vm: BitListArrayElementViewModel): View {
        val box = context.vbox()
        val header = context.hbox()
        header.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2))
        val name = nameLabel(context, vm.name, Out)
        header.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(jumpButton(context) { vm.linkCommand.fire() }, LinearLayout.LayoutParams(Ui.dp(40), WRAP).also { it.leftMargin = Ui.dp(2) })
        box.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))
        errorLine(context, binder, vm, box)
        val tools = FlowLayout(context)
        tools.hGap = Ui.dp(4)
        tools.vGap = Ui.dp(4)
        tools.addView(context.angleButton("Check All", Out, size = 12f) { vm.selectAll.fire() })
        tools.addView(context.angleButton("Uncheck All", Out, size = 12f) { vm.unselectAll.fire() })
        val copy = context.angleButton("Copy All", Out, size = 12f) { Engine.post { vm.massCopy(AppState.fileSystem) } }
        val paste = context.angleButton("Paste All", Out, size = 12f) { Engine.post { vm.massPaste(AppState.fileSystem) } }
        tools.addView(copy)
        tools.addView(paste)
        box.addView(tools, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(6); it.topMargin = Ui.dp(2) })
        val flow = FlowLayout(context)
        flow.hGap = Ui.dp(4)
        flow.vGap = Ui.dp(2)
        box.addView(flow, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(6); it.topMargin = Ui.dp(4) })
        val rows = ArrayList<Pair<dev.hexmaniac.core.viewmodels.tools.BitElement, CheckRow>>()
        binder.watch(vm, "name") { name.text = vm.name }
        binder.watch(vm) {
            copy.visibility = if (vm.canMassCopy) View.VISIBLE else View.GONE
            paste.visibility = if (vm.canMassPaste) View.VISIBLE else View.GONE
            if (rows.size != vm.size || rows.indices.any { rows[it].first !== vm[it] }) {
                flow.removeAllViews()
                rows.clear()
                val width = Ui.dp(150)
                for (i in 0 until vm.size) {
                    val bit = vm[i]
                    val check = CheckRow(context, bit.bitLabel, bit.isChecked)
                    check.onChange = { checked -> Engine.post { bit.isChecked = checked } }
                    binder.watch(bit, "isChecked", "visible", "bitLabel") {
                        check.setCheckedSilently(bit.isChecked)
                        check.label.text = bit.bitLabel
                        check.visibility = if (bit.visible) View.VISIBLE else View.GONE
                    }
                    flow.addView(check, ViewGroup.MarginLayoutParams(width, WRAP))
                    rows.add(Pair(bit, check))
                }
            }
        }
        return box
    }

    private fun multilineText(context: Context): EditText = context.textBox(mono = true, size = 13f).also {
        it.isSingleLine = false
        it.setHorizontallyScrolling(false)
        it.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        it.gravity = Gravity.TOP or Gravity.START
        it.minLines = 2
        it.imeOptions = android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
    }

    private fun textStream(context: Context, binder: Binder, vm: TextStreamElementViewModel): View {
        val box = StreamViews.header(context, binder, vm)
        val edit = multilineText(context)
        binder.bindText(edit, vm, "content", { vm.content }, { vm.content = it })
        binder.watch(vm, "showContent") { edit.visibility = if (vm.showContent) View.VISIBLE else View.GONE }
        box.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(10); it.topMargin = Ui.dp(2) })
        return box
    }

    private fun trainerTeam(context: Context, binder: Binder, vm: TrainerPokemonTeamElementViewModel): View {
        val box = StreamViews.header(context, binder, vm)
        val editor = vm.elementContent
        val edit = multilineText(context)
        binder.bindText(edit, editor, "content", { editor.content }, { editor.content = it })
        binder.watch(vm, "showContent") { edit.visibility = if (vm.showContent) View.VISIBLE else View.GONE }
        box.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(10); it.topMargin = Ui.dp(2) })
        val previews = context.hbox()
        val scroll = context.hscroll(previews)
        box.addView(scroll, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watch(vm) {
            previews.removeAllViews()
            for (image in vm.visualizations) {
                val pixels = PixelView(context)
                pixels.scaleDp = 1f
                pixels.setImage(image)
                previews.addView(pixels, LinearLayout.LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(4) })
            }
        }
        val buttons = context.hbox()
        buttons.gravity = Gravity.CENTER
        buttons.addView(context.angleButton("Default Moves", Out, size = 12f) { vm.setDefaultMoves.fire() })
        buttons.addView(context.angleButton("Default Items", Out, size = 12f) { vm.setDefaultItems.fire() }.margin(left = 6))
        box.addView(buttons, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
        return box
    }

    private fun spriteIndicator(context: Context, binder: Binder, vm: SpriteIndicatorElementViewModel): View {
        val pixels = PixelView(context)
        pixels.scaleDp = 1f
        binder.watch(vm, "image") { pixels.setImage(vm.image) }
        return pixels
    }

    private fun tuple(context: Context, binder: Binder, vm: TupleArrayElementViewModel): View {
        val box = context.vbox()
        val name = context.label(vm.name, 13f, Palette.secondary)
        name.setPadding(Ui.dp(6), Ui.dp(2), 0, Ui.dp(2))
        box.addView(name)
        val flow = FlowLayout(context)
        flow.hGap = Ui.dp(4)
        flow.vGap = Ui.dp(4)
        box.addView(flow, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watch(vm, "name") { name.text = vm.name }
        binder.watchCollection(vm.children) {
            flow.removeAllViews()
            val width = Ui.dp(190)
            for (child in vm.children) {
                val view: View = when (child) {
                    is NumericTupleElementViewModel -> {
                        val edit = context.textBox(size = 13f, inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED)
                        binder.watch(child, "content") {
                            val text = child.content.toString()
                            if (edit.text.toString() != text) edit.setText(text)
                        }
                        edit.addTextChangedListener(object : android.text.TextWatcher {
                            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                            override fun afterTextChanged(s: android.text.Editable?) {
                                val parsed = s?.toString()?.toIntOrNull() ?: return
                                if (parsed != Engine.read { child.content }) Engine.post { child.content = parsed }
                            }
                        })
                        fieldRow(context, child.name, edit, null, Out)
                    }
                    is CheckBoxTupleElementViewModel -> {
                        val check = CheckRow(context, child.name, child.isChecked)
                        binder.watch(child, "isChecked") { check.setCheckedSilently(child.isChecked) }
                        check.onChange = { checked -> Engine.post { child.isChecked = checked } }
                        check
                    }
                    is EnumTupleElementViewModel -> fieldRow(context, child.name, comboDropdown(context, binder, child.filteringComboOptions, child.name), null, Left)
                    else -> context.label(child.name, 12f, Palette.secondary)
                }
                flow.addView(view, ViewGroup.MarginLayoutParams(width, WRAP))
            }
        }
        return box
    }

    private fun calculated(context: Context, binder: Binder, vm: CalculatedElementViewModel): View {
        val box = context.vbox()
        val head = context.hbox()
        head.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(2))
        val name = context.label(vm.name, 13f, Palette.primary)
        val value = context.label("", 13f, Palette.accent)
        value.gravity = Gravity.END
        head.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(value, LinearLayout.LayoutParams(0, WRAP, 1f))
        box.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        val details = context.vbox()
        details.visibility = View.GONE
        val toggle = context.label("\u25B8 How's it calculated?", 12f, Palette.secondary)
        toggle.setPadding(Ui.dp(18), Ui.dp(2), 0, Ui.dp(4))
        toggle.setOnClickListener {
            details.visibility = if (details.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            toggle.text = if (details.visibility == View.VISIBLE) "\u25BE How's it calculated?" else "\u25B8 How's it calculated?"
        }
        box.addView(toggle)
        box.addView(details, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(18) })
        binder.watch(vm, "calculatedValue") {
            value.text = vm.calculatedValue
        }
        binder.watchCollection(vm.operands) {
            details.removeAllViews()
            if (vm.hasOperator) details.addView(context.label("(Operator " + vm.operator + ")", 12f, Palette.secondary, italic = true))
            for (operand in vm.operands) {
                val row = context.hbox()
                row.addView(context.label(operand.text ?: "", 12f, Palette.primary), LinearLayout.LayoutParams(0, WRAP, 1f))
                row.addView(jumpButton(context) { operand.jumpTo.fire() })
                details.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            }
        }
        return box
    }

    private fun offsetRender(context: Context, binder: Binder, vm: OffsetRenderViewModel): View {
        val pixels = PixelView(context)
        pixels.scaleDp = 1f
        binder.watch(vm, "pixelData", "pixelWidth", "pixelHeight") { pixels.setImage(vm) }
        return pixels
    }

    private fun pythonButton(context: Context, vm: PythonButtonElementViewModel): View {
        return context.angleButton(vm.name, Out) { Engine.post { if (vm.canExecute()) vm.execute() } }.also {
            it.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).also { p -> p.topMargin = Ui.dp(2); p.bottomMargin = Ui.dp(2) }
        }
    }

    private fun multiField(context: Context, binder: Binder, vm: MultiFieldArrayElementViewModel): View {
        val box = context.vbox()
        val edit = multilineText(context)
        binder.bindText(edit, vm, "content", { vm.content }, { vm.content = it })
        box.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(10); it.topMargin = Ui.dp(2) })
        errorLine(context, binder, vm, box)
        return box
    }

    private fun button(context: Context, binder: Binder, vm: ButtonArrayElementViewModel): View {
        val button = context.angleButton(vm.text ?: "", Out) { vm.command.fire() }
        button.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(2); it.bottomMargin = Ui.dp(2) }
        binder.watch(vm, "text") { button.text = vm.text ?: "" }
        binder.watchCommand(vm.command) { button.alpha = if (vm.command.canExecute(null)) 1f else 0.4f }
        return button
    }

    private fun mapOptions(context: Context, binder: Binder, vm: MapOptionsArrayElementViewModel): View {
        val box = context.vbox()
        val toggle = context.angleButton("maps", Out) { Engine.post { vm.showPreviews = !vm.showPreviews } }
        box.addView(toggle, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(2); it.bottomMargin = Ui.dp(2) })
        val list = FlowLayout(context)
        list.hGap = Ui.dp(4)
        list.vGap = Ui.dp(4)
        box.addView(list, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watch(vm, "showPreviews", "mapPreviews") {
            list.visibility = if (vm.showPreviews) View.VISIBLE else View.GONE
            toggle.setTextColor(if (vm.showPreviews) Palette.accent else Palette.primary)
        }
        binder.watchCollection(vm.mapPreviews) {
            list.removeAllViews()
            for (preview in vm.mapPreviews) {
                val pixels = PixelView(context)
                pixels.scaleDp = 1f
                pixels.setImage(preview.image)
                pixels.setOnClickListener { Engine.post { preview.goto() } }
                list.addView(pixels, ViewGroup.MarginLayoutParams(WRAP, WRAP))
            }
        }
        return box
    }
}
