package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.viewmodels.images.IPixelViewModel
import dev.hexmaniac.core.viewmodels.map.BlockEditor
import dev.hexmaniac.core.viewmodels.map.BlockMapViewModel
import dev.hexmaniac.core.viewmodels.map.MapEditorViewModel
import dev.hexmaniac.core.viewmodels.map.MapTutorialsViewModel
import dev.hexmaniac.core.viewmodels.map.WildPokemonViewModel

/** Small building blocks shared by the map editor panels. */
internal object PanelUi {
    fun chip(context: Context, text: String): TextView = context.label(text, 13f, Palette.primary).apply {
        gravity = Gravity.CENTER
        setPadding(Ui.dp(20), Ui.dp(6), Ui.dp(20), Ui.dp(6))
        background = AngleDrawable(Palette.backlight, Palette.secondary, AngleDrawable.Direction.Out)
    }

    /** A centered title with an optional close button at the end (child 1 of the result). */
    fun titleBar(context: Context, title: String, onClose: (() -> Unit)?): FrameLayout {
        val bar = FrameLayout(context)
        bar.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(2))
        bar.addView(chip(context, title), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        val close = context.iconButton(Icon.Exit, 36, Palette.secondary) { onClose?.invoke() }
        if (onClose == null) close.visibility = View.GONE
        bar.addView(close, FrameLayout.LayoutParams(Ui.dp(36), Ui.dp(36), Gravity.END or Gravity.CENTER_VERTICAL))
        return bar
    }
}

/** Rebuilds its content whenever the editor starts showing another map. */
internal class MapBound(
    context: Context,
    private val tab: MapEditorViewModel,
    private val binder: Binder,
    private val build: (BlockMapViewModel, Binder) -> View?,
) : FrameLayout(context) {
    private var shown: BlockMapViewModel? = null
    private var own: Binder? = null
    private var stale = false

    init {
        binder.watch(tab, "primaryMap") { rebuild() }
    }

    /** Hidden panels wait until they are shown again before they follow the editor to another map. */
    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible && stale) readSoon { rebuild() }
    }

    private fun rebuild() {
        val map = tab.primaryMap
        if (map === shown && !stale) return
        if (shown != null && !isShown) {
            stale = true
            return
        }
        stale = false
        shown = map
        own?.dispose()
        removeAllViews()
        val child = binder.child()
        own = child
        val view = build(map, child)
        if (view != null) addView(view, LayoutParams(MATCH, MATCH))
    }
}

/** A pixel image stretched over the whole view (nearest neighbor). */
internal class FitImageView(context: Context) : View(context) {
    private var bitmap: Bitmap? = null
    private val paint = Paint().apply { isFilterBitmap = false }
    private val src = Rect()
    private val dst = Rect()

    /** Engine lock held. */
    fun setImage(vm: IPixelViewModel?) {
        bitmap = pixelsToBitmap(vm)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        src.set(0, 0, b.width, b.height)
        dst.set(paddingLeft, paddingTop, width - paddingRight, height - paddingBottom)
        canvas.drawBitmap(b, src, dst, paint)
    }
}

/**
 * A picture that reacts to touches in image pixels. In tap mode (for pickers inside a scroll view) a tap reports once; in
 * draw mode press/drag/release are reported, and a long press (when [onHold] is set) is reported instead of drawing.
 */
internal class GridImageView(context: Context, private val maxScale: Float, private val drawMode: Boolean) : View(context) {
    private var bitmap: Bitmap? = null
    private var imageWidth = 0
    private var imageHeight = 0
    private var natural = 1f
    private var scalePx = 1f
    private var highlight: RectF? = null
    private val paint = Paint().apply { isFilterBitmap = false }
    private val fill = Paint()
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    var onTap: ((Float, Float) -> Unit)? = null
    var onPress: ((Float, Float) -> Unit)? = null
    var onDrag: ((Float, Float) -> Unit)? = null
    var onRelease: (() -> Unit)? = null
    var onHold: ((Float, Float) -> Unit)? = null

    private var state = 0 // 0 idle, 1 pending, 2 drawing, 3 held
    private var downX = 0f
    private var downY = 0f
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val holdRunnable = Runnable {
        if (state == 1) {
            state = 3
            performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
            onHold?.invoke(toImageX(downX), toImageY(downY))
        }
    }

    /** Engine lock held. */
    fun setImage(vm: IPixelViewModel?) {
        bitmap = pixelsToBitmap(vm)
        val w = vm?.pixelWidth ?: 0
        val h = vm?.pixelHeight ?: 0
        val scale = (vm?.spriteScale ?: 1.0).toFloat().takeIf { it > 0f } ?: 1f
        if (w != imageWidth || h != imageHeight || scale != natural) {
            imageWidth = w
            imageHeight = h
            natural = scale
            requestLayout()
        }
        invalidate()
    }

    fun setHighlight(rect: RectF?) {
        highlight = rect
        invalidate()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val available = MeasureSpec.getSize(widthSpec).let { if (it <= 0) Int.MAX_VALUE else it } - paddingLeft - paddingRight
        scalePx = if (imageWidth > 0) minOf(minOf(natural, maxScale) * Ui.density, available.toFloat() / imageWidth) else 1f
        val w = (imageWidth * scalePx).toInt() + paddingLeft + paddingRight
        val h = (imageHeight * scalePx).toInt() + paddingTop + paddingBottom
        setMeasuredDimension(resolveSize(w, widthSpec), resolveSize(h, heightSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        val left = paddingLeft
        val top = paddingTop
        canvas.drawBitmap(b, Rect(0, 0, b.width, b.height), Rect(left, top, left + (imageWidth * scalePx).toInt(), top + (imageHeight * scalePx).toInt()), paint)
        val h = highlight ?: return
        val r = RectF(left + h.left * scalePx, top + h.top * scalePx, left + h.right * scalePx, top + h.bottom * scalePx)
        fill.color = Palette.alpha(Palette.primary, 120)
        canvas.drawRect(r, fill)
        stroke.color = Palette.accent
        stroke.strokeWidth = Ui.dpf(1.5f)
        canvas.drawRect(r, stroke)
    }

    private fun toImageX(px: Float): Float = (px - paddingLeft) / scalePx
    private fun toImageY(py: Float): Float = (py - paddingTop) / scalePx
    private fun inside(ix: Float, iy: Float): Boolean = ix >= 0f && iy >= 0f && ix < imageWidth && iy < imageHeight

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val ix = toImageX(event.x)
        val iy = toImageY(event.y)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                state = 1
                downX = event.x
                downY = event.y
                if (drawMode) parent?.requestDisallowInterceptTouchEvent(true)
                if (onHold != null) postDelayed(holdRunnable, ViewConfiguration.getLongPressTimeout().toLong())
            }
            MotionEvent.ACTION_MOVE -> {
                if (state == 1) {
                    val dx = event.x - downX
                    val dy = event.y - downY
                    if (dx * dx + dy * dy > slop * slop) {
                        removeCallbacks(holdRunnable)
                        if (drawMode) {
                            state = 2
                            val px = toImageX(downX)
                            val py = toImageY(downY)
                            if (inside(px, py)) onPress?.invoke(px, py)
                            if (inside(ix, iy)) onDrag?.invoke(ix, iy)
                        } else {
                            state = 0
                        }
                    }
                } else if (state == 2 && inside(ix, iy)) {
                    onDrag?.invoke(ix, iy)
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(holdRunnable)
                if (state == 1 && inside(ix, iy)) {
                    if (drawMode) {
                        onPress?.invoke(ix, iy)
                        onRelease?.invoke()
                    } else {
                        onTap?.invoke(ix, iy)
                    }
                } else if (state == 2) {
                    onRelease?.invoke()
                }
                state = 0
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(holdRunnable)
                if (state == 2) onRelease?.invoke()
                state = 0
            }
        }
        return true
    }
}

/** Sixteen colors in a row. */
internal class PaletteStrip(context: Context, private val boxDp: Int) : View(context) {
    private var colors: List<Short> = emptyList()
    private val paint = Paint()

    fun setColors(list: List<Short>) {
        colors = list
        requestLayout()
        invalidate()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(Ui.dp(boxDp) * maxOf(1, colors.size), Ui.dp(boxDp))
    }

    override fun onDraw(canvas: Canvas) {
        val box = Ui.dp(boxDp)
        for (i in colors.indices) {
            paint.color = gbaToArgb(colors[i].toInt() and 0x7FFF)
            canvas.drawRect((i * box).toFloat(), 0f, ((i + 1) * box).toFloat(), box.toFloat(), paint)
        }
    }
}

/** Shows the block picker in a dialog, for panels that sit where the Blocks panel would be. */
internal object BlockPickerDialog {
    /** UI thread. */
    fun show(context: Context, binder: Binder, tab: MapEditorViewModel) {
        readSoon {
            val own = binder.child()
            val scroll = ScrollView(context)
            val picker = BlockPicker(context, tab, scroll, own)
            scroll.addView(picker, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL))
            val root = context.vbox()
            root.addView(Dialogs.title(context, "Pick a Block"))
            val hint = context.label("Tap a block to select it, long-press and drag to select several.", 12f, Palette.secondary)
            hint.setPadding(Ui.dp(14), Ui.dp(2), Ui.dp(14), Ui.dp(6))
            root.addView(hint, lp(MATCH, WRAP))
            root.addView(scroll, lp(MATCH, Ui.dp(340)))
            val row = context.hbox()
            row.setPadding(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(10))
            val dialog = Dialogs.create(context, root, 360, true)
            row.addView(context.angleButton("Done", AngleDrawable.Direction.Out) { dialog.dismiss() })
            root.addView(row, lp(MATCH, WRAP))
            dialog.setOnDismissListener { own.dispose() }
            dialog.show()
        }
    }
}

/** The "Blocks" panel: movement permission, selected block info and the block picker. */
internal class BlocksPanel(context: Context, private val tab: MapEditorViewModel, binder: Binder) : LinearLayout(context) {
    val picker: BlockPicker
    private val scroll = ScrollView(context)

    init {
        orientation = VERTICAL
        picker = BlockPicker(context, tab, scroll, binder)

        val bar = PanelUi.titleBar(context, "Blocks") { Engine.post { tab.cancel() } }
        val close = bar.getChildAt(1)
        binder.watch(tab) { close.visibility = if (tab.blockEditorVisible || tab.drawMultipleTiles) View.VISIBLE else View.INVISIBLE }
        addView(bar, lp(MATCH, WRAP))

        val state = context.vbox()
        state.setPadding(Ui.dp(4), 0, Ui.dp(4), Ui.dp(2))
        val form = MapForm(context, binder, state)
        form.check("Automatic Movement Permission", tab, { tab.autoUpdateCollision }, { tab.autoUpdateCollision = it })
        form.combo(
            "Movement:", tab,
            { tab.primaryMap.blockEditor?.movementPermissions?.toList() ?: tab.collisionOptions.toList() },
            { tab.collisionIndex }, { tab.collisionIndex = it },
        )
        form.dynamicNote(tab, Palette.primary) { if (tab.blockEditorVisible) "Block ID: " + tab.drawBlockIndex else null }
        form.dynamicNote(tab, Palette.secondary) { if (tab.isSingleBlock) "Usage Count: " + tab.blockUsageCount else null }
        form.image(tab, 2f, { tab.multiTileDrawRender }) { tab.blockEditorVisible || tab.drawMultipleTiles || tab.isValid9GridSelection }
        form.action("Edit Block", tab, null, { tab.blockEditorVisible }) { tab.primaryMap.blockEditor?.toggleShowTiles() }
        form.check("Draw 9-Grid", tab, { tab.use9Grid }, { tab.use9Grid = it }, tab) { tab.isValid9GridSelection }
        form.note(
            "(No Block Selected)\nTap a block below to select it, or long-press a map cell in Select mode.\nYou can pick a movement permission without selecting a block.",
            tab,
        ) { !(tab.blockEditorVisible || tab.drawMultipleTiles || tab.isValid9GridSelection) }

        val bag = CheckRow(context, "Mixing bag: taps add/remove blocks", false)
        bag.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4))
        bag.onChange = { picker.bagMode = it }
        state.addView(bag, lp(MATCH, WRAP))
        form.group(tab, { tab.blockBagVisible }) { g ->
            g.image(tab, 2f, { try { tab.blockBag } catch (e: UninitializedPropertyAccessException) { null } })
            g.action("Empty the bag") { tab.clearBlockBag() }
        }
        addView(state, lp(MATCH, WRAP))

        scroll.isFillViewport = false
        scroll.addView(picker, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL))
        addView(scroll, lp(MATCH, 0, 1f))
    }
}

/** The four foreground and four background tiles of the selected block. */
internal class BlockQuadEditor(context: Context, binder: Binder, private val editor: BlockEditor) : LinearLayout(context) {
    private val cells = ArrayList<FitImageView>()
    private var chosen: FitImageView? = null

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        val tile = Ui.dp(32)
        val canvas = FrameLayout(context)
        val slots: List<Triple<() -> IPixelViewModel?, Int, Int>> = listOf(
            Triple({ editor.leftTopFront }, 0, 0), Triple({ editor.rightTopFront }, 1, 0),
            Triple({ editor.leftBottomFront }, 0, 1), Triple({ editor.rightBottomFront }, 1, 1),
            Triple({ editor.leftTopBack }, 2, 2), Triple({ editor.rightTopBack }, 3, 2),
            Triple({ editor.leftBottomBack }, 2, 3), Triple({ editor.rightBottomBack }, 3, 3),
        )
        for ((getter, col, row) in slots) {
            val cell = FitImageView(context)
            cell.background = BoxDrawable(Palette.background, Palette.backlight)
            cell.setPadding(1, 1, 1, 1)
            val params = FrameLayout.LayoutParams(tile, tile)
            params.leftMargin = col * tile
            params.topMargin = row * tile
            canvas.addView(cell, params)
            cells.add(cell)
            val vm = getter()
            if (vm != null) binder.watch(vm) { cell.setImage(getter()) }
            cell.setOnClickListener {
                choose(cell)
                Engine.post {
                    val image = getter()
                    editor.enterTile(image)
                    editor.drawOnTile(image)
                }
            }
            cell.setOnLongClickListener {
                choose(cell)
                Engine.post {
                    val image = getter()
                    editor.enterTile(image)
                    editor.getSelectionFromTile(image)
                }
                true
            }
        }
        // The two empty quadrants carry the copy and paste buttons.
        fun corner(label: String, left: Int, top: Int, copy: () -> Unit, paste: () -> Unit) {
            val box = context.vbox()
            box.gravity = Gravity.CENTER
            box.addView(context.label(label, 11f, Palette.secondary), lp(WRAP, WRAP))
            val row = context.hbox()
            val copyButton = context.angleButton("Copy", AngleDrawable.Direction.Left, size = 11f) { Engine.post { copy() } }
            val pasteButton = context.angleButton("Paste", AngleDrawable.Direction.Right, size = 11f) { Engine.post { paste() } }
            for (b in listOf(copyButton, pasteButton)) {
                b.minimumWidth = 0
                b.minHeight = Ui.dp(30)
                b.setPadding(Ui.dp(5), Ui.dp(2), Ui.dp(5), Ui.dp(2))
            }
            row.addView(copyButton, lp(WRAP, WRAP))
            row.addView(pasteButton, lp(WRAP, WRAP))
            box.addView(row, lp(WRAP, WRAP))
            val params = FrameLayout.LayoutParams(tile * 2, tile * 2)
            params.leftMargin = left * tile
            params.topMargin = top * tile
            canvas.addView(box, params)
        }
        corner("Foreground", 2, 0, { editor.copyForeground() }, { editor.pasteForeground() })
        corner("Background", 0, 2, { editor.copyBackground() }, { editor.pasteBackground() })
        addView(canvas, lp(tile * 4, tile * 4))

        val flips = context.vbox()
        flips.setPadding(Ui.dp(10), 0, 0, 0)
        val flipH = context.angleButton("Flip H", AngleDrawable.Direction.Out, size = 12f) { Engine.post { editor.flipH() } }
        val flipV = context.angleButton("Flip V", AngleDrawable.Direction.Out, size = 12f) { Engine.post { editor.flipV() } }
        flips.addView(flipH, lp(WRAP, WRAP))
        flips.addView(flipV, lp(WRAP, WRAP).also { it.topMargin = Ui.dp(6) })
        val note = context.label("Tap a tile to paint it with the selected tile, long-press to pick its tile and palette.", 11f, Palette.secondary)
        note.setPadding(0, Ui.dp(6), 0, 0)
        flips.addView(note, lp(Ui.dp(120), WRAP))
        addView(flips, lp(WRAP, WRAP))
        binder.watch(editor, "flipHVisible", "flipVVisible") {
            flipH.alpha = if (editor.flipHVisible) 1f else 0.4f
            flipV.alpha = if (editor.flipVVisible) 1f else 0.4f
        }
    }

    private fun choose(cell: FitImageView) {
        chosen?.background = BoxDrawable(Palette.background, Palette.backlight)
        chosen = cell
        cell.background = BoxDrawable(Palette.background, Palette.accent)
    }
}

/** The "Selected Block" panel: attributes, tile editor, tile picker and palette selection. */
internal class TilesPanel(context: Context, private val tab: MapEditorViewModel, private val binder: Binder) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        val bar = PanelUi.titleBar(context, "Selected Block") { Engine.post { tab.primaryMap.blockEditor?.hideTiles() } }
        addView(bar, lp(MATCH, WRAP))
        val content = MapBound(context, tab, binder) { map, b -> buildFor(map, b) }
        addView(context.vscroll(content).also { (it.getChildAt(0) as? FrameLayout)?.minimumHeight = 0 }, lp(MATCH, 0, 1f))
    }

    private fun buildFor(map: BlockMapViewModel, b: Binder): View? {
        val editor = map.blockEditor ?: return null
        val box = context.vbox()
        box.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(14))
        val form = MapForm(context, b, box)

        form.group(tab, { tab.blockEditorVisible }) { g ->
            g.filtering("Behavior:", editor.behaviorOptions)
            g.combo("Layer:", editor, { editor.layerOptions.toList() }, { editor.layer }, { editor.layer = it }, editor.layerOptions)
            g.combo("Terrain:", editor, { editor.terrainOptions.toList() }, { editor.terrain }, { editor.terrain = it }, editor.terrainOptions, null, editor) { editor.hasTerrainAndEncounter }
            g.combo("Encounter:", editor, { editor.encounterOptions.toList() }, { editor.encounter }, { editor.encounter = it }, editor.encounterOptions, null, editor) { editor.hasTerrainAndEncounter }
            g.dynamicNote(editor, Palette.error) { if (editor.hasError) editor.errorText else null }
            val quad = BlockQuadEditor(context, b, editor)
            quad.setPadding(0, Ui.dp(8), 0, Ui.dp(8))
            g.box.addView(quad, lp(MATCH, WRAP))
        }
        form.note("(No block selected. Pick one in the Blocks panel or on the map first.)", tab) { !tab.blockEditorVisible }
        form.action("Pick a Block...") { Unit }.also { button ->
            button.setOnClickListener { BlockPickerDialog.show(context, binder, tab) }
        }

        // tileset editing
        val tilesets = context.hbox()
        tilesets.gravity = Gravity.CENTER
        tilesets.setPadding(0, Ui.dp(8), 0, Ui.dp(4))
        val primary = context.angleButton("Edit Primary", AngleDrawable.Direction.Left, size = 12f) { Engine.post { map.editTileset("Primary") } }
        val secondary = context.angleButton("Edit Secondary", AngleDrawable.Direction.Right, size = 12f) { Engine.post { map.editTileset("Secondary") } }
        tilesets.addView(primary, lp(WRAP, WRAP))
        tilesets.addView(PanelUi.chip(context, "Tiles"), lp(WRAP, WRAP).also { it.leftMargin = Ui.dp(4); it.rightMargin = Ui.dp(4) })
        tilesets.addView(secondary, lp(WRAP, WRAP))
        for ((button, type) in listOf(primary to "Primary", secondary to "Secondary")) {
            val on = map.canEditTileset(type)
            button.isEnabled = on
            button.alpha = if (on) 1f else 0.4f
        }
        box.addView(tilesets, lp(MATCH, WRAP))

        // selected tile and palette
        val selected = context.hbox()
        selected.gravity = Gravity.CENTER_VERTICAL
        selected.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4))
        val drawn = FitImageView(context)
        drawn.background = BoxDrawable(Palette.background, Palette.secondary)
        drawn.setPadding(2, 2, 2, 2)
        val drawnIndex = context.label("", 12f, Palette.primary)
        val column = context.vbox()
        column.gravity = Gravity.CENTER_HORIZONTAL
        column.addView(drawn, lp(Ui.dp(48), Ui.dp(48)))
        column.addView(drawnIndex, lp(WRAP, WRAP))
        selected.addView(context.label("Selected\nTile:", 12f, Palette.secondary), lp(WRAP, WRAP).also { it.rightMargin = Ui.dp(8) })
        selected.addView(column, lp(WRAP, WRAP))
        val paletteBox = context.vbox()
        paletteBox.setPadding(Ui.dp(14), 0, 0, 0)
        val paletteLabel = context.label("", 12f, Palette.secondary)
        val strip = PaletteStrip(context, 10)
        strip.background = BoxDrawable(Color.TRANSPARENT, Palette.secondary)
        strip.setPadding(1, 1, 1, 1)
        strip.setOnClickListener { readSoon { pickPalette(editor) } }
        paletteBox.addView(paletteLabel, lp(WRAP, WRAP))
        paletteBox.addView(strip, lp(WRAP, WRAP).also { it.topMargin = Ui.dp(4) })
        selected.addView(paletteBox, lp(WRAP, WRAP))
        box.addView(selected, lp(MATCH, WRAP))
        b.watch(editor, "drawTileRender", "drawTileIndex", "paletteSelection") {
            drawn.setImage(editor.drawTileRender)
            drawnIndex.text = editor.drawTileIndex.toString()
            paletteLabel.text = "Palette (" + editor.paletteSelection + ") - tap to change"
            val colors = editor.palettes.getOrNull(editor.paletteSelection)?.colors
            strip.setColors(colors?.toList() ?: emptyList())
        }

        // tile picker
        val picker = GridImageView(context, 3f, false)
        picker.setPadding(0, Ui.dp(4), 0, Ui.dp(4))
        picker.onTap = { ix, iy ->
            val x = (ix * 3f).toInt()
            val y = (iy * 3f).toInt()
            Engine.post {
                editor.tileSelectionY = y
                editor.tileSelectionX = x
            }
        }
        box.addView(picker, lp(MATCH, WRAP))
        b.watch(editor, "tileRender", "tileSelectionX", "tileSelectionY") {
            picker.setImage(editor.tileRender)
            val left = editor.tileSelectionX / 3f
            val top = editor.tileSelectionY / 3f
            picker.setHighlight(RectF(left, top, left + 8f, top + 8f))
        }
        return box
    }

    private fun pickPalette(editor: BlockEditor) {
        val root = context.vbox()
        root.addView(Dialogs.title(context, "Palette"))
        val list = context.vbox()
        list.setPadding(Ui.dp(8), Ui.dp(4), Ui.dp(8), Ui.dp(8))
        val dialogRef = arrayOfNulls<android.app.Dialog>(1)
        for (index in 0 until editor.palettes.size) {
            val row = context.hbox()
            row.setPadding(Ui.dp(6), Ui.dp(5), Ui.dp(6), Ui.dp(5))
            row.background = BoxDrawable(if (index == editor.paletteSelection) Palette.backlight else Color.TRANSPARENT, Color.TRANSPARENT)
            val number = context.label(index.toString(), 13f, Palette.primary, mono = true)
            number.gravity = Gravity.END
            row.addView(number, lp(Ui.dp(26), WRAP))
            val strip = PaletteStrip(context, 12)
            strip.setColors(editor.palettes[index].colors.toList())
            row.addView(strip, lp(WRAP, WRAP).also { it.leftMargin = Ui.dp(8) })
            row.setOnClickListener {
                Engine.post { editor.paletteSelection = index }
                dialogRef[0]?.dismiss()
            }
            list.addView(row, lp(MATCH, WRAP))
        }
        root.addView(context.vscroll(list), lp(MATCH, Ui.dp(380)))
        val dialog = Dialogs.create(context, root, 340, true)
        dialogRef[0] = dialog
        dialog.show()
    }
}

/** The border block editor. */
internal class BorderPanel(context: Context, private val tab: MapEditorViewModel, private val binder: Binder) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        val bar = PanelUi.titleBar(context, "Border Block") { Engine.post { tab.primaryMap.borderEditor.toggleBorderEditor() } }
        addView(bar, lp(MATCH, WRAP))
        val content = MapBound(context, tab, binder) { map, b -> buildFor(map, b) }
        addView(context.vscroll(content), lp(MATCH, 0, 1f))
    }

    private fun buildFor(map: BlockMapViewModel, b: Binder): View {
        val editor = map.borderEditor
        val box = context.vbox()
        box.setPadding(Ui.dp(8), Ui.dp(4), Ui.dp(8), Ui.dp(14))
        val form = MapForm(context, b, box)
        form.group(editor, { editor.hasBorderDimensions }) { g ->
            g.number("Width:", editor, { editor.width }, { editor.width = it })
            g.number("Height:", editor, { editor.height }, { editor.height = it })
        }
        form.button("Repoint Border Block") { map.mapRepointer.repointBorderBlock.fire() }
        form.button("Pick a Block...") { BlockPickerDialog.show(context, binder, tab) }
        form.dynamicNote(tab, Palette.secondary) {
            if (tab.drawBlockIndex == -1 && !tab.drawMultipleTiles) "Select a block first: pick one above, or long-press a map cell in Select mode." else "Tap or drag on the border to draw the selected block. Long-press a border block to pick it up."
        }
        val image = GridImageView(context, 4f, true)
        image.setPadding(Ui.dp(4), Ui.dp(8), Ui.dp(4), Ui.dp(8))
        image.onPress = { x, y -> Engine.post { tab.drawBorder(x.toDouble(), y.toDouble()) } }
        image.onDrag = { x, y -> Engine.post { tab.drawBorder(x.toDouble(), y.toDouble()) } }
        image.onRelease = { Engine.post { tab.completeBorderDraw() } }
        image.onHold = { x, y -> Engine.post { tab.readBorderBlock(x.toDouble(), y.toDouble()) } }
        val holder = FrameLayout(context)
        holder.addView(image, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL))
        box.addView(holder, lp(MATCH, WRAP))
        b.watch(editor, "borderRender", "width", "height") { image.setImage(editor.borderRender) }
        return box
    }
}

/** The popup with the four kinds of wild pokemon. */
internal object WildDialog {
    /** Engine lock held; [wild].showWildData is true. */
    fun show(context: Context, wild: WildPokemonViewModel, onDismiss: () -> Unit) {
        val own = Binder()
        val root = context.vbox()
        root.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(12))
        root.addView(Dialogs.title(context, "Wild Pokemon"))
        val info = context.label(
            "Wild pokemon have 3 stats:\n\u2022 Lowest possible level\n\u2022 Highest possible level\n\u2022 Species",
            13f, Palette.primary,
        )
        info.setPadding(Ui.dp(14), Ui.dp(6), Ui.dp(14), Ui.dp(8))
        root.addView(info, lp(MATCH, WRAP))
        val summary = context.label("", 12f, Palette.secondary)
        summary.setPadding(Ui.dp(14), 0, Ui.dp(14), Ui.dp(8))
        root.addView(summary, lp(MATCH, WRAP))
        val dialogRef = arrayOfNulls<android.app.Dialog>(1)
        val form = MapForm(context, own, root)
        fun open(command: () -> dev.hexmaniac.core.system.ICommand?) {
            command().fire()
            dialogRef[0]?.dismiss()
        }
        form.button("", wild, null, null) { }.also { it.visibility = View.GONE }
        val grass = form.button("", wild) { open { wild.gotoGrass } }
        val tree = form.button("", wild) { open { wild.gotoTree } }
        val surf = form.button("", wild) { open { wild.gotoSurf } }
        val fishing = form.button("", wild) { open { wild.gotoFishing } }
        own.watch(wild) {
            grass.text = if (wild.grassExists) "Show Pokemon in Grass" else "Add Pokemon to Grass"
            tree.text = if (wild.treeExists) "Show Pokemon in Rocks" else "Add Pokemon to Rocks"
            surf.text = if (wild.surfExists) "Show Surfing Pokemon" else "Add Surfing Pokemon"
            fishing.text = if (wild.fishingExists) "Show Fishing Pokemon" else "Add Fishing Pokemon"
            summary.text = if (wild.hasWildData) wild.wildSummary else ""
        }
        val dialog = Dialogs.create(context, context.vscroll(root), 360, true)
        dialogRef[0] = dialog
        dialog.setOnDismissListener {
            own.dispose()
            onDismiss()
            Engine.post { wild.showWildData = false }
        }
        dialog.show()
    }
}

/** The tutorial cards of the map editor. */
internal object TutorialsDialog {
    /** Engine lock held. */
    fun show(context: Context, tutorials: MapTutorialsViewModel) {
        val own = Binder()
        val root = context.vbox()
        root.addView(Dialogs.title(context, "Tutorials"))
        val percent = context.label("", 12f, Palette.secondary)
        percent.setPadding(Ui.dp(14), 0, Ui.dp(14), Ui.dp(4))
        root.addView(percent, lp(MATCH, WRAP))
        val touch = context.label(
            "On a touch screen: tap = click, long-press = right-click, one finger drags the map in Pan mode, two fingers move and zoom.",
            12f, Palette.accent,
        )
        touch.setPadding(Ui.dp(14), 0, Ui.dp(14), Ui.dp(6))
        root.addView(touch, lp(MATCH, WRAP))
        val cards = context.vbox()
        cards.setPadding(Ui.dp(8), 0, Ui.dp(8), Ui.dp(8))
        root.addView(context.vscroll(cards), lp(MATCH, Ui.dp(320)))
        val actions = context.hbox()
        actions.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(10), Ui.dp(10))
        actions.addView(context.angleButton("Dismiss All", AngleDrawable.Direction.Left, size = 12f) { Engine.post { tutorials.dismissAll() } }, lp(WRAP, WRAP))
        actions.addView(context.angleButton("Restart All", AngleDrawable.Direction.Right, size = 12f) { Engine.post { tutorials.reset() } }, lp(WRAP, WRAP))
        root.addView(actions, lp(MATCH, WRAP))

        fun rebuild() {
            percent.text = "Completed: " + tutorials.completionPercent
            cards.removeAllViews()
            var shown = 0
            for (tutorial in tutorials.tutorials.toList()) {
                if (!tutorial.incomplete) continue
                if (shown >= MapTutorialsViewModel.visibleCount) break
                shown++
                val card = context.vbox()
                card.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), Ui.dp(8))
                card.background = BoxDrawable(Palette.backlight, Palette.secondary)
                val head = context.hbox()
                head.addView(context.label(tutorial.title, 14f, Palette.primary, bold = true), lp(0, WRAP, 1f))
                head.addView(context.label(tutorial.indexText, 11f, Palette.secondary, italic = true), lp(WRAP, WRAP))
                head.addView(context.iconButton(Icon.Exit, 32, Palette.secondary) { Engine.post { tutorial.close() } }, lp(Ui.dp(32), Ui.dp(32)).also { it.leftMargin = Ui.dp(6) })
                card.addView(head, lp(MATCH, WRAP))
                card.addView(context.label(tutorial.content, 13f, Palette.primary).also { it.setPadding(0, Ui.dp(4), 0, 0) }, lp(MATCH, WRAP))
                cards.addView(card, lp(MATCH, WRAP).also { it.topMargin = Ui.dp(6) })
            }
            if (shown == 0) cards.addView(context.label("All tutorials are complete.", 13f, Palette.secondary).also { it.setPadding(Ui.dp(6), Ui.dp(8), Ui.dp(6), Ui.dp(8)) })
            if (tutorials.seeMore) cards.addView(context.label("See More... (finish these to reveal the next ones)", 12f, Palette.secondary, italic = true).also { it.setPadding(Ui.dp(6), Ui.dp(8), Ui.dp(6), Ui.dp(8)) })
        }
        own.watch(tutorials) { rebuild() }
        own.watchCollection(tutorials.tutorials) { rebuild() }
        for (tutorial in tutorials.tutorials.toList()) own.watch(tutorial, "incomplete") { rebuild() }
        val dialog = Dialogs.create(context, root, 400, true)
        dialog.setOnDismissListener { own.dispose() }
        dialog.show()
    }
}
