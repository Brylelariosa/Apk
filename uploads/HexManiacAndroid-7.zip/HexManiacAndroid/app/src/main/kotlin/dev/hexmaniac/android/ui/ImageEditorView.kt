package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.LinearLayout
import android.widget.SeekBar
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.models.Point
import dev.hexmaniac.core.system.INotifyPropertyChanged
import dev.hexmaniac.core.viewmodels.ImageEditorTools
import dev.hexmaniac.core.viewmodels.ImageEditorViewModel
import dev.hexmaniac.core.viewmodels.TilePaletteMode
import java.util.concurrent.atomic.AtomicBoolean

/** Everything the canvas needs to draw the sprite; built on the engine thread. */
private class ImageFrame(
    val bitmap: Bitmap?,
    val width: Int,
    val height: Int,
    val scale: Double,
    val xOffset: Int,
    val yOffset: Int,
    val selection: BooleanArray,
    val tilePalettes: List<Int>,
    val tileWidth: Int,
    val tileHeight: Int,
    val showTilePalettes: Boolean,
    val info: String,
    val preview: Bitmap?,
)

/** Draws the sprite being edited and turns touches into the tool calls of the view-model. */
private class ImageCanvas(context: Context, private val vm: ImageEditorViewModel) : View(context) {
    private var frame: ImageFrame? = null
    private val dirty = AtomicBoolean(false)
    private val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = Ui.dpf(1.5f) }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val fill = Paint()
    private val binder = Binder()
    private var gesture = 0 // 0 none, 1 tool, 2 pan, 3 eyedropper
    private var downX = 0f
    private var downY = 0f
    private var pinchStart = 0f
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val longPress = ViewConfiguration.getLongPressTimeout().toLong()
    private var moved = false
    private val longPressRunnable = Runnable {
        if (gesture == 1 && !moved) {
            gesture = 3
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val p = point(downX, downY)
            Engine.post {
                vm.toolUp(p)
                vm.eyeDropperDown(p)
            }
        }
    }

    init {
        setWillNotDraw(false)
        binder.onEngineEvent {
            val handler: (Any?, dev.hexmaniac.core.system.PropertyChangedEventArgs) -> Unit = { _, _ -> requestFrame() }
            val refresh: (Any?, dev.hexmaniac.core.system.EventArgs) -> Unit = { _, _ -> requestFrame() }
            vm.propertyChanged += handler
            vm.refreshSelection += refresh
            val undo: () -> Unit = {
                vm.propertyChanged -= handler
                vm.refreshSelection -= refresh
            }
            undo
        }
        requestFrame()
    }

    fun release() = binder.dispose()

    fun requestFrame() {
        if (dirty.compareAndSet(false, true)) Engine.post { build() }
    }

    private fun build() {
        try {
            val w = vm.pixelWidth
            val h = vm.pixelHeight
            val data = vm.pixelData
            var bitmap: Bitmap? = null
            if (w > 0 && h > 0 && data.size >= w * h) {
                val colors = IntArray(w * h)
                val transparent = vm.transparent.toInt()
                for (i in colors.indices) {
                    val c = data[i].toInt()
                    colors[i] = if (c == transparent) 0 else gbaToArgb(c)
                }
                bitmap = Bitmap.createBitmap(colors, w, h, Bitmap.Config.ARGB_8888)
            }
            val selection = BooleanArray((w + 2) * (h + 2))
            if (w > 0 && h > 0) {
                for (y in -1..h) for (x in -1..w) selection[(y + 1) * (w + 2) + (x + 1)] = vm.showSelectionRect(x, y)
            }
            var preview: Bitmap? = null
            val block = vm.blockPreview
            if (block.enabled && block.pixelWidth > 0 && block.pixelHeight > 0 && block.pixelData.size >= block.pixelWidth * block.pixelHeight) {
                val colors = IntArray(block.pixelWidth * block.pixelHeight)
                for (i in colors.indices) colors[i] = gbaToArgb(block.pixelData[i].toInt())
                preview = Bitmap.createBitmap(colors, block.pixelWidth, block.pixelHeight, Bitmap.Config.ARGB_8888)
            }
            val result = ImageFrame(
                bitmap, w, h, vm.spriteScale, vm.xOffset, vm.yOffset, selection,
                vm.tilePalettes.toList(), vm.tileWidth, vm.tileHeight,
                vm.selectedTool == ImageEditorTools.TilePalette, vm.quickInfo, preview,
            )
            Engine.ui {
                frame = result
                invalidate()
            }
        } finally {
            dirty.set(false)
        }
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Palette.background)
        val f = frame ?: return
        val bmp = f.bitmap ?: return
        val scale = (f.scale * Ui.density).toFloat()
        val cx = width / 2f + f.xOffset * Ui.density
        val cy = height / 2f + f.yOffset * Ui.density
        val dest = RectF(cx - f.width * scale / 2f, cy - f.height * scale / 2f, cx + f.width * scale / 2f, cy + f.height * scale / 2f)
        fill.color = Palette.backlight
        canvas.drawRect(dest, fill)
        canvas.drawBitmap(bmp, null, dest, paint)
        // tile grid
        line.color = Palette.alpha(Palette.secondary, 90)
        line.strokeWidth = Ui.dpf(1f)
        var x = 8
        while (x < f.width) {
            canvas.drawLine(dest.left + x * scale, dest.top, dest.left + x * scale, dest.bottom, line)
            x += 8
        }
        var y = 8
        while (y < f.height) {
            canvas.drawLine(dest.left, dest.top + y * scale, dest.right, dest.top + y * scale, line)
            y += 8
        }
        if (scale >= Ui.dpf(10f)) {
            line.color = Palette.alpha(Palette.secondary, 40)
            for (px in 1 until f.width) if (px % 8 != 0) canvas.drawLine(dest.left + px * scale, dest.top, dest.left + px * scale, dest.bottom, line)
            for (py in 1 until f.height) if (py % 8 != 0) canvas.drawLine(dest.left, dest.top + py * scale, dest.right, dest.top + py * scale, line)
        }
        // tile palette overlay
        if (f.showTilePalettes && f.tileWidth > 0 && f.tileHeight > 0) {
            val tw = dest.width() / f.tileWidth
            val th = dest.height() / f.tileHeight
            text.textSize = minOf(tw, th) * 0.5f
            for (i in f.tilePalettes.indices) {
                val tx = i % f.tileWidth
                val ty = i / f.tileWidth
                if (ty >= f.tileHeight) break
                fill.color = Color.HSVToColor(150, floatArrayOf((f.tilePalettes[i] * 360f / 16f) % 360f, 0.7f, 0.9f))
                canvas.drawRect(dest.left + tx * tw, dest.top + ty * th, dest.left + (tx + 1) * tw, dest.top + (ty + 1) * th, fill)
                text.color = Color.BLACK
                canvas.drawText(f.tilePalettes[i].toString(), dest.left + (tx + 0.5f) * tw, dest.top + (ty + 0.5f) * th + text.textSize / 3f, text)
            }
        }
        // selection outline
        line.color = Palette.accent
        line.strokeWidth = Ui.dpf(2f)
        val stride = f.width + 2
        for (py in 0 until f.height) {
            for (px in 0 until f.width) {
                if (!f.selection[(py + 1) * stride + (px + 1)]) continue
                val l = dest.left + px * scale
                val t = dest.top + py * scale
                if (!f.selection[py * stride + (px + 1)]) canvas.drawLine(l, t, l + scale, t, line)
                if (!f.selection[(py + 2) * stride + (px + 1)]) canvas.drawLine(l, t + scale, l + scale, t + scale, line)
                if (!f.selection[(py + 1) * stride + px]) canvas.drawLine(l, t, l, t + scale, line)
                if (!f.selection[(py + 1) * stride + px + 2]) canvas.drawLine(l + scale, t, l + scale, t + scale, line)
            }
        }
        // info and block preview
        val preview = f.preview
        if (preview != null) {
            val target = RectF(Ui.dpf(6f), Ui.dpf(6f), Ui.dpf(6f) + preview.width * Ui.density * 2, Ui.dpf(6f) + preview.height * Ui.density * 2)
            canvas.drawBitmap(preview, null, target, paint)
        }
        if (f.info.isNotEmpty()) {
            text.textAlign = Paint.Align.RIGHT
            text.textSize = Ui.dpf(12f)
            val w = text.measureText(f.info)
            fill.color = Palette.background
            canvas.drawRect(width - w - Ui.dpf(10f), height - Ui.dpf(24f), width.toFloat(), height.toFloat(), fill)
            text.color = Palette.primary
            canvas.drawText(f.info, width - Ui.dpf(5f), height - Ui.dpf(7f), text)
            text.textAlign = Paint.Align.CENTER
        }
    }

    private fun point(x: Float, y: Float) = Point(((x - width / 2f) / Ui.density).toInt(), ((y - height / 2f) / Ui.density).toInt())

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = event.x
                downY = event.y
                moved = false
                gesture = 1
                val p = point(event.x, event.y)
                Engine.post { vm.toolDown(p, false) }
                postDelayed(longPressRunnable, longPress)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                removeCallbacks(longPressRunnable)
                if (gesture == 1) {
                    // the first finger started a tool stroke; cancel it where it is and switch to panning
                    val p = point(event.getX(0), event.getY(0))
                    Engine.post { vm.toolUp(p) }
                }
                gesture = 2
                val mid = point((event.getX(0) + event.getX(1)) / 2f, (event.getY(0) + event.getY(1)) / 2f)
                pinchStart = distance(event)
                Engine.post { vm.panDown(mid) }
            }
            MotionEvent.ACTION_MOVE -> {
                if (Math.abs(event.x - downX) > slop || Math.abs(event.y - downY) > slop) moved = true
                if (gesture == 2 && event.pointerCount >= 2) {
                    val mid = point((event.getX(0) + event.getX(1)) / 2f, (event.getY(0) + event.getY(1)) / 2f)
                    Engine.post { vm.hover(mid) }
                    val d = distance(event)
                    if (pinchStart > 0f) {
                        if (d / pinchStart > 1.35f) {
                            pinchStart = d
                            Engine.post { vm.zoomIn(mid) }
                        } else if (d / pinchStart < 0.74f) {
                            pinchStart = d
                            Engine.post { vm.zoomOut(mid) }
                        }
                    }
                } else if (gesture == 1 || gesture == 3) {
                    val p = point(event.x, event.y)
                    Engine.post { vm.hover(p) }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (gesture == 2) {
                    val mid = point((event.getX(0) + event.getX(1)) / 2f, (event.getY(0) + event.getY(1)) / 2f)
                    Engine.post { vm.panUp(mid) }
                    gesture = 0
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                val p = point(event.x, event.y)
                when (gesture) {
                    1 -> Engine.post { vm.toolUp(p) }
                    3 -> Engine.post { vm.eyeDropperUp(p) }
                    2 -> Engine.post { vm.panUp(p) }
                }
                gesture = 0
            }
        }
        return true
    }

    private fun distance(event: MotionEvent): Float {
        val dx = event.getX(0) - event.getX(1)
        val dy = event.getY(0) - event.getY(1)
        return Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
    }
}

/** The image editor tab: tool row, drawing canvas, page selectors and the palette. */
class ImageEditorView(context: Context, private val vm: ImageEditorViewModel, private val binder: Binder) : LinearLayout(context) {
    private val Out = AngleDrawable.Direction.Out
    private val canvas = ImageCanvas(context, vm)

    init {
        orientation = VERTICAL
        setBackgroundColor(Palette.background)
        addView(context.hscroll(toolRow(context)), LayoutParams(MATCH, WRAP))
        addView(optionRow(context), LayoutParams(MATCH, WRAP))
        addView(canvas, LayoutParams(MATCH, 0, 1f))
        addView(context.vscroll(bottomPanel(context)), LayoutParams(MATCH, WRAP).also { it.height = Ui.dp(150) })
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        canvas.release()
    }

    private fun toolButton(context: Context, text: String, tool: ImageEditorTools, visible: (() -> Boolean)? = null): View {
        val button = context.angleButton(text, Out, size = 12f) { vm.selectTool.fire(tool) }
        button.minimumHeight = Ui.dp(32)
        binder.watch(vm, "selectedTool", "canEditTilePalettes") {
            button.setTextColor(if (vm.selectedTool == tool) Palette.accent else Palette.primary)
            if (visible != null) button.visibility = if (visible()) View.VISIBLE else View.GONE
        }
        return button
    }

    private fun toolRow(context: Context): View {
        val row = context.hbox()
        row.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(2))
        row.addView(toolButton(context, "Pan", ImageEditorTools.Pan))
        row.addView(toolButton(context, "Select", ImageEditorTools.Select))
        row.addView(toolButton(context, "Draw", ImageEditorTools.Draw))
        row.addView(toolButton(context, "Fill", ImageEditorTools.Fill))
        row.addView(toolButton(context, "Pick", ImageEditorTools.EyeDropper))
        row.addView(toolButton(context, "Tile Pal", ImageEditorTools.TilePalette) { vm.canEditTilePalettes })
        row.addView(context.iconButton(Icon.Add, 36) { vm.zoomInCommand.fire() }.margin(left = 8))
        row.addView(context.iconButton(Icon.Remove, 36) { vm.zoomOutCommand.fire() })
        row.addView(context.angleButton("Delete", Out, size = 12f) { vm.deleteCommand.fire() }.margin(left = 4))
        return row
    }

    private fun optionRow(context: Context): View {
        val box = context.vbox()
        // cursor sizes and tile palette modes depend on the tool
        val sizes = context.hbox()
        sizes.setPadding(Ui.dp(6), 0, Ui.dp(6), 0)
        sizes.addView(context.label("Cursor", 12f, Palette.secondary), LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(4) })
        val sizeButtons = ArrayList<android.widget.TextView>()
        for (size in listOf(1, 2, 4, 8)) {
            val b = context.angleButton(size.toString(), size = 12f) { vm.setCursorSize.fire(size) }
            b.minimumHeight = Ui.dp(30)
            sizeButtons.add(b)
            sizes.addView(b, LayoutParams(Ui.dp(40), WRAP).also { it.rightMargin = Ui.dp(2) })
        }
        binder.watch(vm, "cursorSize", "selectedTool") {
            for ((i, b) in sizeButtons.withIndex()) b.setTextColor(if (vm.cursorSize == listOf(1, 2, 4, 8)[i]) Palette.accent else Palette.primary)
            sizes.visibility = if (vm.selectedTool == ImageEditorTools.Draw || vm.selectedTool == ImageEditorTools.EyeDropper) View.VISIBLE else View.GONE
        }
        box.addView(sizes)

        val modes = context.hbox()
        modes.setPadding(Ui.dp(6), 0, Ui.dp(6), 0)
        for ((name, mode) in listOf("Draw" to TilePaletteMode.Draw, "Fill" to TilePaletteMode.Fill, "Pick" to TilePaletteMode.EyeDropper)) {
            val b = context.angleButton(name, size = 12f) { vm.selectTilePaletteMode.fire(mode) }
            b.minimumHeight = Ui.dp(30)
            binder.watch(vm, "tilePaletteMode") { b.setTextColor(if (vm.tilePaletteMode == mode) Palette.accent else Palette.primary) }
            modes.addView(b, LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(4) })
        }
        binder.watch(vm, "selectedTool") { modes.visibility = if (vm.selectedTool == ImageEditorTools.TilePalette) View.VISIBLE else View.GONE }
        box.addView(modes)

        val flips = context.hbox()
        flips.setPadding(Ui.dp(6), 0, Ui.dp(6), 0)
        flips.addView(context.angleButton("Flip Vertical", Out, size = 12f) { vm.flipVertical.fire() }.also { it.minimumHeight = Ui.dp(30) })
        flips.addView(context.angleButton("Flip Horizontal", Out, size = 12f) { vm.flipHorizontal.fire() }.also { it.minimumHeight = Ui.dp(30) }.margin(left = 4))
        binder.watch(vm, "selectedTool") { flips.visibility = if (vm.selectedTool == ImageEditorTools.Select) View.VISIBLE else View.GONE }
        box.addView(flips)

        val edit = context.hbox()
        edit.setPadding(Ui.dp(6), Ui.dp(2), Ui.dp(6), 0)
        val editScroll = context.hscroll(edit)
        binder.watch(vm, "hasMultipleEditOptions", "selectedEditOption") { editScroll.visibility = if (vm.hasMultipleEditOptions) View.VISIBLE else View.GONE }
        binder.watchCollection(vm.editOptions) {
            edit.removeAllViews()
            for ((i, option) in vm.editOptions.withIndex()) {
                val pixels = PixelView(context)
                pixels.scaleDp = 1f
                pixels.setImage(option)
                pixels.setOnClickListener { Engine.post { vm.selectedEditOption = i } }
                binder.watch(vm, "selectedEditOption") { pixels.alpha = if (vm.selectedEditOption == i) 1f else 0.5f }
                edit.addView(pixels, LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(6) })
            }
        }
        box.addView(editScroll)

        val width = context.hbox()
        width.setPadding(Ui.dp(6), 0, Ui.dp(6), 0)
        width.addView(context.label("Tileset width", 12f, Palette.secondary), LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(6) })
        val bar = SeekBar(context)
        val value = context.label("", 12f, Palette.primary)
        var silent = false
        binder.watch(vm, "canEditTilesetWidth", "minimumTilesetWidth", "maximumTilesetWidth", "currentTilesetWidth") {
            width.visibility = if (vm.canEditTilesetWidth) View.VISIBLE else View.GONE
            silent = true
            bar.max = maxOf(0, vm.maximumTilesetWidth - vm.minimumTilesetWidth)
            bar.progress = vm.currentTilesetWidth - vm.minimumTilesetWidth
            value.text = vm.currentTilesetWidth.toString()
            silent = false
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!silent && fromUser) Engine.post { vm.currentTilesetWidth = vm.minimumTilesetWidth + progress }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
        width.addView(bar, LayoutParams(0, Ui.dp(36), 1f))
        width.addView(value)
        box.addView(width)
        return box
    }

    private fun pageRow(context: Context, title: String, options: () -> List<dev.hexmaniac.core.viewmodels.tools.SelectionViewModel>, collection: dev.hexmaniac.core.system.INotifyCollectionChanged, visible: () -> Boolean, owner: INotifyPropertyChanged, property: String, set: (Int) -> Unit): View {
        val row = context.hbox()
        row.setPadding(Ui.dp(6), Ui.dp(2), Ui.dp(6), Ui.dp(2))
        row.addView(context.label(title, 12f, Palette.secondary), LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(6) })
        val buttons = context.hbox()
        row.addView(context.hscroll(buttons), LayoutParams(0, WRAP, 1f))
        binder.watchCollection(collection) {
            buttons.removeAllViews()
            for (option in options()) {
                val b = context.angleButton(option.name, Out, size = 12f) { Engine.post { set(option.index) } }
                b.minimumHeight = Ui.dp(30)
                binder.watch(option, "selected") { b.setTextColor(if (option.selected) Palette.accent else Palette.primary) }
                buttons.addView(b, LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(3) })
            }
        }
        binder.watch(owner, property) { row.visibility = if (visible()) View.VISIBLE else View.GONE }
        return row
    }

    private fun bottomPanel(context: Context): View {
        val box = context.vbox()
        box.addView(pageRow(context, "Sprite Page", { vm.spritePageOptions.toList() }, vm.spritePageOptions, { vm.hasMultipleSpritePages }, vm, "hasMultipleSpritePages") { vm.spritePage = it })
        box.addView(pageRow(context, "Palette Page", { vm.palettePageOptions.toList() }, vm.palettePageOptions, { vm.hasMultiplePalettePages }, vm, "hasMultiplePalettePages") { vm.palettePage = it })
        box.addView(PaletteView(context, vm.palette, binder.child()), LayoutParams(MATCH, WRAP).also { it.setMargins(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4)) })
        return box
    }
}
