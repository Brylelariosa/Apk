package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Rect
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.PopupWindow
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.models.Direction
import dev.hexmaniac.core.models.Point
import dev.hexmaniac.core.system.ConsoleKey
import dev.hexmaniac.core.viewmodels.EditorViewModel
import dev.hexmaniac.core.viewmodels.IEditableViewPort
import dev.hexmaniac.core.viewmodels.IViewPort
import dev.hexmaniac.core.viewmodels.ViewPort
import dev.hexmaniac.core.viewmodels.visitors.IContextItem

/** Hex digits, arrows and the usual editing keys for people who do not want the system keyboard. */
class HexKeypad(context: Context, private val hex: HexView) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        setBackgroundColor(Palette.backlight)
        setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2))
        fun key(text: String, weight: Float = 1f, color: Int = Palette.primary, action: () -> Unit): View {
            val button = context.angleButton(text, AngleDrawable.Direction.None, size = 16f, textColor = color) { action() }
            button.minimumHeight = Ui.dp(40)
            button.minimumWidth = 0
            button.setPadding(0, 0, 0, 0)
            button.layoutParams = LayoutParams(0, Ui.dp(42), weight).also { it.setMargins(Ui.dp(1), Ui.dp(1), Ui.dp(1), Ui.dp(1)) }
            return button
        }
        val rowA = context.hbox()
        val rowB = context.hbox()
        val rowC = context.hbox()
        for (c in "01234567") rowA.addView(key(c.toString()) { hex.sendText(c.toString()) })
        for (c in "89ABCDEF") rowB.addView(key(c.toString()) { hex.sendText(c.toString()) })
        rowC.addView(key("\u2190") { hex.move(Direction.Left, false) })
        rowC.addView(key("\u2191") { hex.move(Direction.Up, false) })
        rowC.addView(key("\u2193") { hex.move(Direction.Down, false) })
        rowC.addView(key("\u2192") { hex.move(Direction.Right, false) })
        rowC.addView(key("Bksp", 1.4f) { hex.sendKey(ConsoleKey.Backspace) })
        rowC.addView(key("Del", 1.2f) { hex.sendKey(ConsoleKey.Delete) })
        rowC.addView(key("Esc", 1.2f) { hex.sendKey(ConsoleKey.Escape) })
        rowC.addView(key("Enter", 1.6f, Palette.accent) { hex.sendKey(ConsoleKey.Enter) })
        rowC.addView(key("ABC", 1.4f, Palette.secondary) {
            hex.requestFocus()
            (context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.showSoftInput(hex, 0)
        })
        addView(rowA, LayoutParams(MATCH, WRAP))
        addView(rowB, LayoutParams(MATCH, WRAP))
        addView(rowC, LayoutParams(MATCH, WRAP))
    }
}

/** One hex tab: the hex grid, a bottom info bar and the tool panels. */
class HexTabView(context: Context, private val vp: IViewPort, private val editor: EditorViewModel, private val binder: Binder) : LinearLayout(context), HexView.Host {
    private val concrete = vp as? ViewPort
    private val editable = vp as? IEditableViewPort
    private val hexView: HexView
    private val popup = PopupWindow(context)
    private val popupList = context.vbox()
    private var keypad: HexKeypad? = null
    private val hexColumn = context.vbox()
    private val body = LinearLayout(context)
    private var panel: ToolPanelView? = null
    private var wide = false

    init {
        orientation = VERTICAL
        setBackgroundColor(Palette.background)
        hexView = HexView(context, vp, { editor.searchBytes }, { editor.showMatrix })
        hexView.host = this
        hexView.fontPx = zoomToPx(editor.zoomLevel)
        binder.watch(editor, "zoomLevel") { hexView.fontPx = zoomToPx(editor.zoomLevel) }
        binder.onEngineEvent {
            val handler: (Any?, dev.hexmaniac.core.system.PropertyChangedEventArgs) -> Unit = { _, e ->
                if (e.propertyName == "searchBytes" || e.propertyName == "showMatrix" || e.propertyName == null) hexView.requestFrame()
            }
            editor.propertyChanged += handler
            val undo: () -> Unit = { editor.propertyChanged -= handler }
            undo
        }

        // anchor text
        val anchorRow = context.hbox()
        anchorRow.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(2))
        val anchorBox = context.textBox(hint = "anchor name and format", mono = true, size = 13f)
        anchorRow.addView(context.label("Anchor", 12f, Palette.secondary), LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(6) })
        anchorRow.addView(anchorBox, LayoutParams(0, WRAP, 1f))
        if (editable != null) {
            binder.bindText(anchorBox, vp as dev.hexmaniac.core.system.INotifyPropertyChanged, "anchorText", { editable.anchorText }, { editable.anchorText = it })
        }
        binder.watch(vp as dev.hexmaniac.core.system.INotifyPropertyChanged, "anchorTextVisible") { anchorRow.visibility = if (vp.anchorTextVisible && editable != null) View.VISIBLE else View.GONE }
        addView(anchorRow, LayoutParams(MATCH, WRAP))

        // hex column: grid, progress, keypad
        hexColumn.addView(hexView, LayoutParams(MATCH, 0, 1f))
        val progress = ProgressStrip(context)
        hexColumn.addView(progress, LayoutParams(MATCH, Ui.dp(3)))
        binder.watch(vp as dev.hexmaniac.core.system.INotifyPropertyChanged, "progress", "updateInProgress") {
            progress.visibility = if (vp.updateInProgress) View.VISIBLE else View.INVISIBLE
            progress.fraction = vp.progress.toFloat()
        }

        body.orientation = HORIZONTAL
        addView(body, LayoutParams(MATCH, 0, 1f))
        val tools = vp.tools
        if (tools != null) {
            panel = ToolPanelView(context, tools, binder.child())
        }
        layoutBody(context.resources.configuration.screenWidthDp >= 640)

        if (tools != null) addView(ToolTabsRow(context, tools, binder.child()), LayoutParams(MATCH, WRAP))
        addView(infoBar(context, binder), LayoutParams(MATCH, WRAP))

        popup.contentView = popupList
        popup.isFocusable = false
        popup.isOutsideTouchable = false
        popup.setBackgroundDrawable(BoxDrawable(Palette.background, Palette.accent))
    }

    private fun zoomToPx(zoom: Int): Float = zoom.coerceIn(6, 60) * 0.8f * Ui.density

    /** Chooses the side-by-side layout on wide screens and the stacked one on phones. */
    fun layoutBody(isWide: Boolean) {
        wide = isWide
        body.removeAllViews()
        (hexColumn.parent as? ViewGroup)?.removeView(hexColumn)
        (panel?.parent as? ViewGroup)?.removeView(panel)
        body.orientation = if (isWide) HORIZONTAL else VERTICAL
        val p = panel
        if (isWide) {
            if (p != null) body.addView(p, LayoutParams(0, MATCH, 0.45f))
            body.addView(hexColumn, LayoutParams(0, MATCH, 0.55f))
        } else {
            body.addView(hexColumn, LayoutParams(MATCH, 0, 1f))
            if (p != null) body.addView(p, LayoutParams(MATCH, 0, 1f))
        }
    }

    private fun infoBar(context: Context, binder: Binder): View {
        val bar = FlowLayout(context)
        bar.hGap = Ui.dp(6)
        bar.vGap = Ui.dp(2)
        bar.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(2))
        bar.setBackgroundColor(Palette.backlight)
        val vm = vp as dev.hexmaniac.core.system.INotifyPropertyChanged

        fun cell(label: String, view: View, widthDp: Int): LinearLayout {
            val row = context.hbox()
            row.addView(context.label(label, 12f, Palette.secondary), LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(3) })
            row.addView(view, LayoutParams(Ui.dp(widthDp), Ui.dp(30)))
            return row
        }

        fun smallBox(): android.widget.EditText = context.textBox(size = 12f, mono = true).also {
            it.minHeight = Ui.dp(28)
            it.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(2))
        }

        if (concrete != null) {
            val free = smallBox()
            binder.watch(vm, "freeSpaceStart") {
                val text = String.format("%X", concrete.freeSpaceStart)
                if (free.text.toString().uppercase() != text && !free.hasFocus()) free.setText(text)
            }
            free.addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: android.text.Editable?) {
                    val parsed = s?.toString()?.trim()?.toIntOrNull(16) ?: return
                    Engine.post { concrete.freeSpaceStart = parsed }
                }
            })
            free.setOnEditorActionListener { _, _, _ ->
                concrete.gotoFreeSpaceStart.fire()
                true
            }
            val freeCell = cell("Free Space:", free, 76)
            val find = context.angleButton("Find", AngleDrawable.Direction.Out, size = 11f) { Engine.post { concrete.findFreeSpace(AppState.fileSystem) } }
            find.minimumHeight = Ui.dp(28)
            freeCell.addView(find, LayoutParams(WRAP, Ui.dp(28)).also { it.leftMargin = Ui.dp(3) })
            binder.watch(vm, "canFindFreeSpace") { freeCell.visibility = if (concrete.canFindFreeSpace) View.VISIBLE else View.GONE }
            bar.addView(freeCell)
        }
        val address = smallBox()
        binder.bindText(address, vm, "selectedAddress", { vp.selectedAddress }, { vp.selectedAddress = it })
        bar.addView(cell("Address:", address, 78))
        if (concrete != null) {
            val length = smallBox()
            binder.bindText(length, vm, "selectedLength", { concrete.selectedLength }, { concrete.selectedLength = it })
            length.setOnLongClickListener {
                Dialogs.pick(context, "Length", listOf(if (Engine.read { concrete.base10SelectionLength }) "Display Length in Hex" else "Display Length in Base 10"), -1) {
                    Engine.post { concrete.base10SelectionLength = !concrete.base10SelectionLength }
                }
                true
            }
            bar.addView(cell("Length:", length, 64))
            val name = context.label("", 12f, Palette.primary)
            binder.watch(vm, "selectedElementName") { name.text = concrete.selectedElementName }
            bar.addView(name)
        }
        val bytes = context.label("", 12f, Palette.secondary, mono = true)
        binder.watch(vm, "selectedBytes") { bytes.text = vp.selectedBytes ?: "" }
        bytes.setOnLongClickListener {
            val text = Engine.read { vp.selectedBytes }
            if (!text.isNullOrEmpty()) AppState.fileSystem.ui?.writeClipboard(text)
            true
        }
        bar.addView(bytes)
        val keys = context.iconButton(Icon.Keyboard, 34, Palette.secondary) { toggleKeypad() }
        keys.setOnLongClickListener {
            hexView.requestFocus()
            (context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)?.showSoftInput(hexView, 0)
            true
        }
        bar.addView(keys)
        return bar
    }

    fun toggleKeypad() {
        val existing = keypad
        if (existing != null) {
            hexColumn.removeView(existing)
            keypad = null
        } else {
            val pad = HexKeypad(context, hexView)
            hexColumn.addView(pad, LayoutParams(MATCH, WRAP))
            keypad = pad
        }
    }

    fun focusHex() {
        hexView.requestFocus()
    }

    // ---------------------------------------------------------------- HexView.Host

    override fun onContextMenu(x: Int, y: Int, screenX: Float, screenY: Float) {
        Engine.post {
            val items: List<IContextItem> = try {
                vp.getContextMenuItems(Point(x, y), AppState.fileSystem)
            } catch (e: Throwable) {
                emptyList()
            }
            val extras = ArrayList<IContextItem>()
            extras.add(dev.hexmaniac.core.viewmodels.visitors.ContextItem("Follow Link", { vp.followLink(x, y) }))
            extras.add(dev.hexmaniac.core.viewmodels.visitors.ContextItem("Expand Selection", { vp.expandSelection(x, y) }))
            extras.add(dev.hexmaniac.core.viewmodels.visitors.ContextItem("Find All Sources", { vp.findAllSources(x, y) }))
            val all = extras + items
            Engine.ui { ContextMenus.show(context, "Actions", all) }
        }
    }

    override fun onAutocomplete(auto: AutoOp?, anchor: Rect) {
        if (auto == null || auto.items.isEmpty()) {
            if (popup.isShowing) popup.dismiss()
            return
        }
        popupList.removeAllViews()
        for ((i, text) in auto.items.withIndex()) {
            val item = context.label(text, 13f, if (i == auto.selected) Palette.accent else Palette.primary, mono = true)
            item.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), Ui.dp(8))
            val completion = auto.completions.getOrNull(i) ?: text
            item.setOnClickListener { Engine.post { concrete?.autocomplete(completion) } }
            popupList.addView(item, LayoutParams(MATCH, WRAP))
        }
        popup.width = Ui.dp(240)
        popup.height = ViewGroup.LayoutParams.WRAP_CONTENT
        val location = IntArray(2)
        hexView.getLocationInWindow(location)
        val x = location[0] + anchor.left
        val y = location[1] + anchor.bottom
        if (!hexView.isShown) return
        if (popup.isShowing) popup.update(x, y, -1, -1) else popup.showAtLocation(hexView, Gravity.TOP or Gravity.START, x, y)
    }

    override fun onZoom(factor: Float) {
        val current = Engine.read { editor.zoomLevel }
        val next = Math.round(current * factor).coerceIn(8, 40)
        if (next != current) Engine.post { editor.zoomLevel = next }
    }

    override fun onEditRequest() {
        // a tap selects; typing starts through the keypad or the system keyboard
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (popup.isShowing) popup.dismiss()
    }
}

/** A thin bar that fills from left to right, used for long running operations. */
class ProgressStrip(context: Context) : View(context) {
    var fraction = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }
    private val paint = android.graphics.Paint()

    override fun onDraw(canvas: android.graphics.Canvas) {
        paint.color = Palette.backlight
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.color = Palette.stream2
        canvas.drawRect(0f, 0f, width * fraction, height.toFloat(), paint)
    }
}
