package dev.hexmaniac.android.host

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.util.Log
import dev.hexmaniac.core.models.IFileSystem
import dev.hexmaniac.core.models.IFileSystemCopyImageTuple
import dev.hexmaniac.core.models.IFileSystemLoadImageTuple
import dev.hexmaniac.core.models.LoadedFile
import dev.hexmaniac.core.models.ProcessModel
import dev.hexmaniac.core.models.VisualOption
import dev.hexmaniac.core.system.Ref
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.zip.CRC32

/**
 * [IFileSystem] on top of Android's storage access framework.
 *
 * The engine identifies files by a single string (it is used for recent files, metadata and tab titles), so every
 * document the user picks is registered under a virtual path: `/saf/<crc of uri>/<display name>`. The registry is
 * persisted, so recent files can be re-opened. A folder the user picks gets `/tree/<crc>/<name>`; files "inside" that
 * path are created in the real folder. Metadata (the `.toml` files of the desktop app) and settings live in the
 * app-private `metadata` directory.
 *
 * All methods run on the engine thread (see [Engine]); they wait for the user with [Engine.awaitUi].
 */
class AndroidFileSystem(private val appContext: Context) : IFileSystem {
    companion object {
        private const val TAG = "HexManiac"
        private const val PREFS = "hma_registry"
        const val SAF_ROOT = "/saf/"
        const val TREE_ROOT = "/tree/"

        fun lastSegment(path: String): String {
            val trimmed = path.trimEnd('/', '\\')
            val index = maxOf(trimmed.lastIndexOf('/'), trimmed.lastIndexOf('\\'))
            return if (index < 0) trimmed else trimmed.substring(index + 1)
        }

        fun parentOf(path: String): String {
            val trimmed = path.trimEnd('/', '\\')
            val index = maxOf(trimmed.lastIndexOf('/'), trimmed.lastIndexOf('\\'))
            return if (index <= 0) "" else trimmed.substring(0, index)
        }

        private fun mimeFor(extension: String?): String = when (extension?.lowercase(Locale.ROOT)) {
            "png" -> "image/png"
            "txt", "toml", "hma", "pal" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    @Volatile var ui: HostUi? = null

    private val prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val resolver get() = appContext.contentResolver
    private val listeners = HashMap<String, MutableList<(IFileSystem) -> Unit>>()
    private val stamps = HashMap<String, Long?>()
    private var clipText: String = ""
    private var clipImage = IFileSystemCopyImageTuple(ShortArray(0), 0)

    // ---------------------------------------------------------------- registry

    private fun crcOf(text: String): String {
        val crc = CRC32()
        crc.update(text.toByteArray(Charsets.UTF_8))
        return String.format(Locale.ROOT, "%08x", crc.value and 0xFFFFFFFFL)
    }

    private fun register(uri: Uri, tree: Boolean): String {
        val name = displayNameOf(uri, tree)
        val path = (if (tree) TREE_ROOT else SAF_ROOT) + crcOf(uri.toString()) + "/" + name
        prefs.edit().putString(path, uri.toString()).apply()
        return path
    }

    private fun registeredUri(path: String): Uri? {
        val text = prefs.getString(path, null) ?: return null
        return Uri.parse(text)
    }

    private fun displayNameOf(uri: Uri, tree: Boolean): String {
        try {
            if (tree) {
                val documentUri = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
                resolver.query(documentUri, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) return cursor.getString(0) ?: "folder"
                }
            } else {
                resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val name = cursor.getString(0)
                        if (!name.isNullOrEmpty()) return name
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "display name query failed", e)
        }
        return uri.lastPathSegment?.let { lastSegment(it) } ?: "file"
    }

    /** Registers a document that arrived from outside the app (for example "Open with" from a file manager). */
    fun registerExternal(uri: Uri): String {
        try {
            resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (e: Exception) {
            try {
                resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (ignored: Exception) {
                // not every provider allows persisted permissions
            }
        }
        return register(uri, false)
    }

    // ---------------------------------------------------------------- targets (where a virtual path really lives)

    private sealed class Target {
        class Document(val uri: Uri) : Target()
        class Plain(val file: File) : Target()
        class InTree(val tree: Uri, val name: String) : Target()
    }

    private fun resolve(path: String): Target? {
        val uri = registeredUri(path)
        if (uri != null) return Target.Document(uri)
        val parentUri = registeredUri(parentOf(path))
        if (parentUri != null && path.startsWith(TREE_ROOT)) return Target.InTree(parentUri, lastSegment(path))
        if (path.startsWith("/") && !path.startsWith(SAF_ROOT) && !path.startsWith(TREE_ROOT)) return Target.Plain(File(path))
        return null
    }

    private fun treeDocument(tree: Uri): Uri =
        DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))

    private fun findChild(tree: Uri, name: String): Uri? {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                if (cursor.getString(1) == name) return DocumentsContract.buildDocumentUriUsingTree(tree, cursor.getString(0))
            }
        }
        return null
    }

    private fun openIn(path: String): InputStream? {
        return try {
            when (val target = resolve(path)) {
                null -> null
                is Target.Document -> resolver.openInputStream(target.uri)
                is Target.Plain -> if (target.file.isFile) target.file.inputStream() else null
                is Target.InTree -> findChild(target.tree, target.name)?.let { resolver.openInputStream(it) }
            }
        } catch (e: Exception) {
            Log.w(TAG, "open failed: $path", e)
            null
        }
    }

    private fun openOut(path: String): OutputStream? {
        return when (val target = resolve(path)) {
            null -> null
            is Target.Document -> try {
                resolver.openOutputStream(target.uri, "wt")
            } catch (e: Exception) {
                resolver.openOutputStream(target.uri, "w")
            }
            is Target.Plain -> {
                target.file.parentFile?.mkdirs()
                target.file.outputStream()
            }
            is Target.InTree -> {
                val existing = findChild(target.tree, target.name)
                val uri = existing
                    ?: DocumentsContract.createDocument(resolver, treeDocument(target.tree), mimeFor(target.name.substringAfterLast('.', "")), target.name)
                    ?: return null
                try {
                    resolver.openOutputStream(uri, "wt")
                } catch (e: Exception) {
                    resolver.openOutputStream(uri, "w")
                }
            }
        }
    }

    private fun lastModifiedOf(path: String): Long? {
        return try {
            when (val target = resolve(path)) {
                null -> null
                is Target.Plain -> if (target.file.exists()) target.file.lastModified() else null
                is Target.Document -> queryLong(target.uri, DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                is Target.InTree -> findChild(target.tree, target.name)?.let { queryLong(it, DocumentsContract.Document.COLUMN_LAST_MODIFIED) }
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun queryLong(uri: Uri, column: String): Long? {
        resolver.query(uri, arrayOf(column), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst() && !cursor.isNull(0)) return cursor.getLong(0)
        }
        return null
    }

    // ---------------------------------------------------------------- pickers

    private fun pick(intent: Intent): Intent? {
        val host = ui ?: return null
        return Engine.awaitUi<Intent?> { resume -> host.launchForResult(intent, resume) }
    }

    private fun takePermission(data: Intent, uri: Uri) {
        val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try {
            resolver.takePersistableUriPermission(uri, if (flags == 0) Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION else flags)
        } catch (e: Exception) {
            // the provider may not support persisted permissions; the document still works for this session
        }
    }

    private fun pickOpen(mime: String): String? {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        val data = pick(intent) ?: return null
        val uri = data.data ?: return null
        takePermission(data, uri)
        return register(uri, false)
    }

    private fun pickCreate(suggestedName: String, mime: String): String? {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, suggestedName)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        val data = pick(intent) ?: return null
        val uri = data.data ?: return null
        takePermission(data, uri)
        return register(uri, false)
    }

    // ---------------------------------------------------------------- clipboard

    override var copyText: String?
        get() {
            val host = ui
            if (host != null) {
                val text = Engine.awaitUi<String?> { resume ->
                    resume.resume(try { host.readClipboard() } catch (e: Exception) { null })
                }
                if (!text.isNullOrEmpty()) return text
            }
            return clipText
        }
        set(value) {
            clipText = value ?: ""
            val host = ui ?: return
            Engine.ui {
                try {
                    host.writeClipboard(clipText)
                } catch (e: Exception) {
                    Log.w(TAG, "clipboard write failed", e)
                }
            }
        }

    override var copyImage: IFileSystemCopyImageTuple
        get() = clipImage
        set(value) {
            clipImage = value
        }

    // ---------------------------------------------------------------- files

    override fun requestNewName(currentName: String, extensionDescription: String?, vararg extensionOptions: String): String? {
        var suggested = lastSegment(currentName)
        val extension = extensionOptions.firstOrNull()
        if (suggested.isEmpty()) suggested = if (extension != null) "untitled.$extension" else "untitled"
        return pickCreate(suggested, mimeFor(suggested.substringAfterLast('.', extension ?: "")))
    }

    override fun openFile(extensionDescription: String?, vararg extensionOptions: String): LoadedFile? {
        val path = pickOpen("*/*") ?: return null
        return loadFile(path)
    }

    override fun openFolder(): String? {
        val host = ui ?: return null
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        val data = Engine.awaitUi<Intent?> { resume -> host.launchForResult(intent, resume) } ?: return null
        val uri = data.data ?: return null
        takePermission(data, uri)
        return register(uri, true)
    }

    override fun exists(file: String): Boolean {
        return try {
            when (val target = resolve(file)) {
                null -> false
                is Target.Plain -> target.file.exists()
                is Target.Document -> {
                    resolver.openFileDescriptor(target.uri, "r")?.use { true } ?: false
                }
                is Target.InTree -> findChild(target.tree, target.name) != null
            }
        } catch (e: Exception) {
            false
        }
    }

    override fun launchProcess(file: String, arguments: String?) {
        val lower = file.lowercase(Locale.ROOT)
        if (arguments == null && (lower.startsWith("http://") || lower.startsWith("https://"))) {
            val host = ui
            if (host != null) Engine.ui { host.openLink(file) }
            return
        }
        val name = if (arguments != null && arguments.startsWith("/select,")) lastSegment(arguments.removePrefix("/select,").trim('"')) else lastSegment(file)
        showCustomMessageBox("Android cannot open \"$name\" in a file browser or another program from here.", false)
    }

    override fun loadFile(fileName: String): LoadedFile? {
        val stream = openIn(fileName) ?: return null
        return try {
            val data = stream.use { it.readBytes() }
            LoadedFile(fileName, data)
        } catch (e: IOException) {
            showCustomMessageBox("Could not read file: " + (e.message ?: ""), false)
            null
        } catch (e: OutOfMemoryError) {
            showCustomMessageBox("The file is too large to open on this device.", false)
            null
        }
    }

    override fun addListenerToFile(fileName: String, listener: (IFileSystem) -> Unit) {
        val list = listeners.getOrPut(fileName) { ArrayList() }
        list.add(listener)
        if (!stamps.containsKey(fileName)) stamps[fileName] = lastModifiedOf(fileName)
    }

    override fun removeListenerForFile(fileName: String, listener: (IFileSystem) -> Unit) {
        val list = listeners[fileName] ?: return
        list.remove(listener)
        if (list.isEmpty()) {
            listeners.remove(fileName)
            stamps.remove(fileName)
        }
    }

    /** Android has no file watcher for documents, so the activity calls this whenever the app comes back to the front. */
    fun pollExternalChanges() {
        for ((name, list) in listeners.entries.toList()) {
            val now = lastModifiedOf(name)
            val before = stamps[name]
            if (now != null && before != null && now != before) {
                stamps[name] = now
                for (listener in list.toList()) listener(this)
            } else if (before == null) {
                stamps[name] = now
            }
        }
    }

    override fun save(file: LoadedFile): Boolean {
        var result = true
        try {
            val stream = openOut(file.name)
            if (stream == null) {
                result = false
            } else {
                stream.use { it.write(file.contents) }
            }
        } catch (e: Exception) {
            Log.w(TAG, "save failed", e)
            result = false
        }
        if (!result) {
            showCustomMessageBox("Could not save. The file might be ReadOnly or in use by another application.", false)
        } else if (listeners.containsKey(file.name)) {
            stamps[file.name] = lastModifiedOf(file.name)
        }
        return result
    }

    // ---------------------------------------------------------------- metadata (app-private; the desktop app writes .toml next to the file)

    private fun metadataFile(fileName: String): File {
        val directory = File(appContext.filesDir, "metadata")
        val safe = StringBuilder()
        for (c in fileName) safe.append(if (c.isLetterOrDigit() || c == '.' || c == '-' || c == '_') c else '_')
        var name = safe.toString()
        if (name.length > 120) name = name.substring(name.length - 120)
        if (name.lowercase(Locale.ROOT).endsWith(".gba")) name = name.substring(0, name.length - 4)
        return File(directory, "$name.toml")
    }

    override fun saveMetadata(originalFileName: String, metadata: Array<String>?): Boolean {
        if (metadata == null) return true // nothing to save
        val target = metadataFile(originalFileName)
        var tryCount = 0
        while (tryCount < 5) {
            try {
                target.parentFile?.mkdirs()
                target.writeText(metadata.joinToString("\n") + "\n", Charsets.UTF_8)
                return true
            } catch (e: Exception) {
                tryCount += 1
                if (tryCount < 5) {
                    Thread.sleep(100)
                } else {
                    showCustomMessageBox("Failed to write metadata for ${lastSegment(originalFileName)}:\n${e.message}.", false)
                    return false
                }
            }
        }
        return true
    }

    override fun metadataFor(fileName: String): Array<String>? {
        val target = metadataFile(fileName)
        if (!target.isFile) return null
        return try {
            target.readText(Charsets.UTF_8).split("\r\n", "\n").toTypedArray().let { lines ->
                if (lines.isNotEmpty() && lines.last().isEmpty()) lines.copyOf(lines.size - 1).requireNoNulls() else lines
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Lets the user bring a `.toml` file made by the desktop app. It is stored as the metadata of [fileName]. */
    fun importMetadata(fileName: String, lines: Array<String>): Boolean = saveMetadata(fileName, lines)

    override fun trySavePrompt(file: LoadedFile): Boolean? {
        var displayName = ""
        if (file.name.isNotEmpty()) displayName = "\n" + lastSegment(file.name)
        val result = showCustomMessageBox("Would you like to save$displayName?")
        if (result != true) return result
        var name: String? = file.name
        if (name.isNullOrEmpty()) name = requestNewName("")
        if (name.isNullOrEmpty()) return null
        return save(LoadedFile(name.trim(), file.contents))
    }

    // ---------------------------------------------------------------- images

    private fun readImageBytes(fileName: String?): Pair<String, ByteArray>? {
        var path = fileName
        if (path == null || resolve(path) == null || !exists(path)) {
            path = pickOpen("image/*") ?: return null
        }
        val stream = openIn(path)
        if (stream == null) {
            showCustomMessageBox("Could not read ${lastSegment(path)}.", false)
            return null
        }
        return try {
            Pair(path, stream.use { it.readBytes() })
        } catch (e: IOException) {
            showCustomMessageBox("Error: ${e.message}.", false)
            null
        }
    }

    override fun loadImage(fileName: String?): IFileSystemLoadImageTuple {
        val (_, bytes) = readImageBytes(fileName) ?: return IFileSystemLoadImageTuple(null, 0)
        val options = BitmapFactory.Options().apply { inPremultiplied = false }
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
        if (bitmap == null) {
            showCustomMessageBox("Could not decode bitmap. The file may not be a valid PNG.", false)
            return IFileSystemLoadImageTuple(null, 0)
        }
        val width = bitmap.width
        val height = bitmap.height
        val argb = IntArray(width * height)
        bitmap.getPixels(argb, 0, width, 0, 0, width, height)
        bitmap.recycle()
        val data = ShortArray(width * height)
        for (i in argb.indices) {
            val color = argb[i]
            val r = (color shr 16) and 0xFF shr 3
            val g = (color shr 8) and 0xFF shr 3
            val b = color and 0xFF shr 3
            data[i] = ((r shl 10) or (g shl 5) or b).toShort()
        }
        return IFileSystemLoadImageTuple(data, width)
    }

    override fun tryLoadIndexedImage(fileName: Ref<String?>, image: Ref<Array<IntArray>?>, palette: Ref<List<Short>?>): Boolean {
        image.value = null
        palette.value = null
        val (path, bytes) = readImageBytes(fileName.value) ?: return false
        fileName.value = path
        return try {
            val loaded = PngIndexed.read(bytes)
            image.value = loaded.pixels
            palette.value = loaded.palette
            true
        } catch (e: PngIndexed.PngFormatException) {
            false
        }
    }

    private fun pngTarget(fileName: String?): String? {
        if (fileName != null && resolve(fileName) != null) return fileName
        return pickCreate(if (fileName != null) lastSegment(fileName) else "image.png", "image/png")
    }

    private fun writeBytes(path: String, data: ByteArray) {
        val stream = openOut(path)
        if (stream == null) {
            showCustomMessageBox("Could not save ${lastSegment(path)}.", false)
            return
        }
        try {
            stream.use { it.write(data) }
        } catch (e: IOException) {
            showCustomMessageBox("Error: ${e.message}.", false)
        }
    }

    override fun saveImage(image: ShortArray, width: Int, fileName: String?) {
        val path = pngTarget(fileName) ?: return
        val height = if (width == 0) 0 else image.size / width
        if (width <= 0 || height <= 0) return
        val argb = IntArray(width * height)
        for (i in argb.indices) {
            val c = image[i].toInt()
            val r = (c shr 10) and 31
            val g = (c shr 5) and 31
            val b = c and 31
            argb[i] = (0xFF shl 24) or (((r shl 3) or (r shr 2)) shl 16) or (((g shl 3) or (g shr 2)) shl 8) or ((b shl 3) or (b shr 2))
        }
        val bitmap = Bitmap.createBitmap(argb, width, height, Bitmap.Config.ARGB_8888)
        val out = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        bitmap.recycle()
        writeBytes(path, out.toByteArray())
    }

    override fun saveImage(image: Array<IntArray>, palette: List<Short>, fileName: String?) {
        val path = pngTarget(fileName) ?: return
        try {
            writeBytes(path, PngIndexed.write(image, palette))
        } catch (e: PngIndexed.PngFormatException) {
            showCustomMessageBox(e.message ?: "Could not save the image.", false)
        }
    }

    // ---------------------------------------------------------------- dialogs

    override fun showOptions(title: String, prompt: String, additionalDetails: List<List<Any>>?, vararg options: VisualOption): Int {
        val host = ui ?: return -1
        val list = options.toList()
        return Engine.awaitUi<Int> { resume -> host.showOptions(title, prompt, additionalDetails, list, resume) }
    }

    override fun requestText(title: String, prompt: String): String? {
        val host = ui ?: return null
        return Engine.awaitUi<String?> { resume -> host.requestText(title, prompt, resume) }
    }

    override fun showCustomMessageBox(message: String, showYesNoCancel: Boolean, vararg links: ProcessModel): Boolean? {
        val host = ui ?: return null
        val list = links.toList()
        return Engine.awaitUi<Boolean?> { resume -> host.showMessage(message, showYesNoCancel, list, resume) }
    }
}
