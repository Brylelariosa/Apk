package dev.hexmaniac.android.host

import java.io.ByteArrayOutputStream
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * Port of HexManiac.WPF IndexedPng / IndexedPngReader / IndexedPngWriter: palette-indexed PNG files whose palette
 * entries are GBA (15 bit) colors. Unlike the original reader this one also understands PNG row filters and files
 * with several IDAT chunks, because most image editors write those.
 */
object PngIndexed {
    class PngFormatException(message: String) : Exception(message)

    class Loaded(val pixels: Array<IntArray>, val palette: List<Short>)

    private val signature = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)

    fun convertToPalette(data: ByteArray, offset: Int, length: Int): List<Short> {
        val palette = ArrayList<Short>()
        var i = offset
        while (i + 2 < offset + length) {
            val r = Math.round((data[i].toInt() and 0xFF) * 31 / 255.0).toInt()
            val g = Math.round((data[i + 1].toInt() and 0xFF) * 31 / 255.0).toInt()
            val b = Math.round((data[i + 2].toInt() and 0xFF) * 31 / 255.0).toInt()
            palette.add(((r shl 10) or (g shl 5) or b).toShort())
            i += 3
        }
        return palette
    }

    fun convertFromPalette(palette: List<Short>): ByteArray {
        val data = ByteArray(3 * palette.size)
        var i = 0
        for (color in palette) {
            val c = color.toInt()
            data[i++] = (((c shr 10) and 31) * 255 / 31).toByte()
            data[i++] = (((c shr 5) and 31) * 255 / 31).toByte()
            data[i++] = ((c and 31) * 255 / 31).toByte()
        }
        return data
    }

    private fun int32(data: ByteArray, at: Int): Int =
        ((data[at].toInt() and 0xFF) shl 24) or ((data[at + 1].toInt() and 0xFF) shl 16) or
            ((data[at + 2].toInt() and 0xFF) shl 8) or (data[at + 3].toInt() and 0xFF)

    fun read(file: ByteArray): Loaded {
        if (file.size < 8 || !file.copyOfRange(0, 8).contentEquals(signature)) throw PngFormatException("Not a PNG file.")
        var position = 8
        var width = 0
        var height = 0
        var bitDepth = 0
        var palette: List<Short>? = null
        val idat = ByteArrayOutputStream()
        var sawIdat = false
        var sawEnd = false
        while (!sawEnd) {
            if (position + 12 > file.size) throw PngFormatException("Unexpected end of file.")
            val size = int32(file, position)
            if (size < 0 || position + 12 + size > file.size) throw PngFormatException("Unexpected end of file.")
            val type = String(file, position + 4, 4, Charsets.US_ASCII)
            val crc = CRC32()
            crc.update(file, position + 4, 4 + size)
            if ((crc.value and 0xFFFFFFFFL).toInt() != int32(file, position + 8 + size)) {
                if (type == "IHDR" || type == "PLTE" || type == "IDAT" || type == "IEND") {
                    throw PngFormatException("$type chunk is corrupted (CRC check failed).")
                }
            }
            val dataStart = position + 8
            when (type) {
                "IHDR" -> {
                    if (size != 13) throw PngFormatException("IHDR chunk has invalid size.")
                    if (width != 0) throw PngFormatException("Multiple IHDR chunks present.")
                    width = int32(file, dataStart)
                    height = int32(file, dataStart + 4)
                    bitDepth = file[dataStart + 8].toInt() and 0xFF
                    val colourType = file[dataStart + 9].toInt() and 0xFF
                    val compression = file[dataStart + 10].toInt() and 0xFF
                    val filterMethod = file[dataStart + 11].toInt() and 0xFF
                    val interlace = file[dataStart + 12].toInt() and 0xFF
                    if (width <= 0) throw PngFormatException("Image has width of 0.")
                    if (height <= 0) throw PngFormatException("Image has height of 0.")
                    if (colourType != 3) throw PngFormatException("Image is not palette indexed.")
                    if (bitDepth != 1 && bitDepth != 2 && bitDepth != 4 && bitDepth != 8) {
                        throw PngFormatException("Bit depth ($bitDepth) is invalid for a palette indexed image.")
                    }
                    if (compression != 0) throw PngFormatException("Compression method ($compression) is invalid.")
                    if (filterMethod != 0) throw PngFormatException("Image has a non-zero filter method ($filterMethod)")
                    if (interlace != 0) throw PngFormatException("Image has a non-zero interlace method ($interlace)")
                }
                "PLTE" -> {
                    if (size % 3 != 0) throw PngFormatException("PLTE chunk size not divisible by 3.")
                    if (palette != null) throw PngFormatException("Multiple PLTE chunks present.")
                    palette = convertToPalette(file, dataStart, size)
                }
                "IDAT" -> {
                    sawIdat = true
                    idat.write(file, dataStart, size)
                }
                "IEND" -> sawEnd = true
                else -> Unit // skip all other chunks
            }
            position += 12 + size
        }
        val colors = palette ?: throw PngFormatException("No PLTE chunk read.")
        if (!sawIdat || width == 0) throw PngFormatException("No IDAT chunk read.")
        return Loaded(unpack(inflate(idat.toByteArray()), width, height, bitDepth), colors)
    }

    private fun inflate(compressed: ByteArray): ByteArray {
        val inflater = Inflater()
        try {
            inflater.setInput(compressed)
            val out = ByteArrayOutputStream(compressed.size * 4)
            val buffer = ByteArray(16384)
            while (!inflater.finished()) {
                val count = inflater.inflate(buffer)
                if (count == 0 && (inflater.needsInput() || inflater.needsDictionary())) break
                out.write(buffer, 0, count)
            }
            return out.toByteArray()
        } catch (e: java.util.zip.DataFormatException) {
            throw PngFormatException("Image data is corrupted.")
        } finally {
            inflater.end()
        }
    }

    private fun unpack(raw: ByteArray, width: Int, height: Int, bitDepth: Int): Array<IntArray> {
        val rowBytes = (width * bitDepth + 7) / 8
        if (raw.size < (rowBytes + 1) * height) throw PngFormatException("Decompressed data size from IDAT does not match width and height from IDHR.")
        // undo the filters row by row; bytes-per-pixel is 1 for everything an indexed image can use
        val rows = Array(height) { ByteArray(rowBytes) }
        for (y in 0 until height) {
            val start = y * (rowBytes + 1)
            val filter = raw[start].toInt() and 0xFF
            val row = rows[y]
            val above = if (y > 0) rows[y - 1] else null
            for (i in 0 until rowBytes) {
                val x = raw[start + 1 + i].toInt() and 0xFF
                val a = if (i > 0) row[i - 1].toInt() and 0xFF else 0
                val b = if (above != null) above[i].toInt() and 0xFF else 0
                val c = if (above != null && i > 0) above[i - 1].toInt() and 0xFF else 0
                val value = when (filter) {
                    0 -> x
                    1 -> x + a
                    2 -> x + b
                    3 -> x + ((a + b) / 2)
                    4 -> x + paeth(a, b, c)
                    else -> throw PngFormatException("Unknown row filter $filter.")
                }
                row[i] = value.toByte()
            }
        }
        val pixels = Array(width) { IntArray(height) }
        val mask = (1 shl bitDepth) - 1
        for (y in 0 until height) {
            val row = rows[y]
            for (x in 0 until width) {
                val bit = x * bitDepth
                val byte = row[bit shr 3].toInt() and 0xFF
                val shift = 8 - bitDepth - (bit and 7)
                pixels[x][y] = (byte shr shift) and mask
            }
        }
        return pixels
    }

    private fun paeth(a: Int, b: Int, c: Int): Int {
        val p = a + b - c
        val pa = Math.abs(p - a)
        val pb = Math.abs(p - b)
        val pc = Math.abs(p - c)
        return if (pa <= pb && pa <= pc) a else if (pb <= pc) b else c
    }

    fun write(pixels: Array<IntArray>, palette: List<Short>): ByteArray {
        if (palette.size > 256) throw PngFormatException("An indexed PNG file cannot have more than 256 colors.")
        val width = pixels.size
        val height = if (width == 0) 0 else pixels[0].size
        for (x in 0 until width) {
            for (y in 0 until height) {
                val pixel = pixels[x][y]
                if (pixel < 0 || pixel >= palette.size) throw PngFormatException("Pixel at $x, $y ($pixel) is out of range.")
            }
        }
        val bitDepth = if (palette.size <= 16) 4 else 8
        val out = ByteArrayOutputStream()
        out.write(signature)
        val header = ByteArray(13)
        putInt(header, 0, width)
        putInt(header, 4, height)
        header[8] = bitDepth.toByte()
        header[9] = 3 // indexed colour
        chunk(out, "IHDR", header)
        chunk(out, "PLTE", convertFromPalette(palette))
        val rowBytes = (width * bitDepth + 7) / 8
        val raw = ByteArray((rowBytes + 1) * height)
        var i = 0
        for (y in 0 until height) {
            raw[i++] = 0
            if (bitDepth == 4) {
                var x = 0
                while (x < width) {
                    val high = pixels[x][y] and 15
                    val low = if (x + 1 < width) pixels[x + 1][y] and 15 else 0
                    raw[i++] = ((high shl 4) or low).toByte()
                    x += 2
                }
            } else {
                for (x in 0 until width) raw[i++] = pixels[x][y].toByte()
            }
        }
        chunk(out, "IDAT", deflate(raw))
        chunk(out, "IEND", ByteArray(0))
        return out.toByteArray()
    }

    private fun deflate(data: ByteArray): ByteArray {
        val deflater = Deflater(Deflater.BEST_COMPRESSION)
        try {
            deflater.setInput(data)
            deflater.finish()
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(16384)
            while (!deflater.finished()) {
                val count = deflater.deflate(buffer)
                out.write(buffer, 0, count)
            }
            return out.toByteArray()
        } finally {
            deflater.end()
        }
    }

    private fun putInt(target: ByteArray, at: Int, value: Int) {
        target[at] = (value shr 24).toByte()
        target[at + 1] = (value shr 16).toByte()
        target[at + 2] = (value shr 8).toByte()
        target[at + 3] = value.toByte()
    }

    private fun chunk(out: ByteArrayOutputStream, type: String, data: ByteArray) {
        val size = ByteArray(4)
        putInt(size, 0, data.size)
        out.write(size)
        val typeBytes = type.toByteArray(Charsets.US_ASCII)
        out.write(typeBytes)
        out.write(data)
        val crc = CRC32()
        crc.update(typeBytes)
        crc.update(data)
        val crcBytes = ByteArray(4)
        putInt(crcBytes, 0, crc.value.toInt())
        out.write(crcBytes)
    }
}
