package dev.hexmaniac.android.host

import android.content.Context
import android.content.Intent
import dev.hexmaniac.core.models.ProcessModel
import dev.hexmaniac.core.models.VisualOption

/**
 * What the engine-side file system needs from the Android UI. Implemented by the main activity.
 * Every method is called on the Android UI thread; answers go back through [Engine.Resume].
 */
interface HostUi {
    val context: Context

    /** Starts an activity (a system picker) and resumes with its result intent, or null when cancelled. */
    fun launchForResult(intent: Intent, resume: Engine.Resume<Intent?>)

    /** Yes/No/Cancel (or OK) message box. Resumes with true (yes/ok), false (no) or null (cancel). */
    fun showMessage(message: String, yesNoCancel: Boolean, links: List<ProcessModel>, resume: Engine.Resume<Boolean?>)

    /** Option dialog (see OptionDialog.xaml). Resumes with the chosen [VisualOption.index] or -1 when cancelled. */
    fun showOptions(title: String, prompt: String, details: List<List<Any>>?, options: List<VisualOption>, resume: Engine.Resume<Int>)

    /** Single line text request (see RequestTextDialog.xaml). Resumes with the text or null when cancelled. */
    fun requestText(title: String, prompt: String, resume: Engine.Resume<String?>)

    fun readClipboard(): String?
    fun writeClipboard(text: String)
    fun openLink(link: String)
}
