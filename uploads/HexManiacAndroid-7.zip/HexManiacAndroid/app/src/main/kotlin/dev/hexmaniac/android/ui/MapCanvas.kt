package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.ScrollView
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.system.INotifyPropertyChanged
import dev.hexmaniac.core.system.NotifyCollectionChangedEventArgs
import dev.hexmaniac.core.system.PropertyChangedEventArgs
import dev.hexmaniac.core.viewmodels.MenuCommandNonGeneric
import dev.hexmaniac.core.viewmodels.images.IPixelViewModel
import dev.hexmaniac.core.viewmodels.map.BlockMapViewModel
import dev.hexmaniac.core.viewmodels.map.EventCreationType
import dev.hexmaniac.core.viewmodels.map.MapEditorViewModel
import dev.hexmaniac.core.viewmodels.map.MapSlider
import dev.hexmaniac.core.viewmodels.map.MapSliderIcons
import dev.hexmaniac.core.viewmodels.map.PrimaryInteractionStart
import dev.hexmaniac.core.viewmodels.map.SelectionInteractionResult
import java.util.concurrent.atomic.AtomicBoolean

/** How a single finger acts on the map. Two fingers always pan and pinch-zoom. */
enum class MapMode { Draw, Rect, Fill, Pan, Select }

/** 15 bit GBA color -> ARGB, precomputed. */
object GbaLut {
    val table: IntArray = IntArray(32768) { gbaToArgb(it) }
}

/** Converts view-model pixels into a bitmap. Call with the engine lock held. */
fun pixelsToBitmap(vm: IPixelViewModel?): Bitmap? {
    if (vm == null) return null
    val w = vm.pixelWidth
    val h = vm.pixelHeight
    val data = vm.pixelData
    if (w <= 0 || h <= 0 || data.size < w * h) return null
    val transparent = vm.transparent.toInt()
    val colors = IntArray(w * h)
    val lut = GbaLut.table
    for (i in colors.indices) {
        val c = data[i].toInt()
        colors[i] = if (c == transparent) 0 else lut[c and 0x7FFF]
    }
    return try {
        Bitmap.createBitmap(colors, w, h, Bitmap.Config.ARGB_8888)
    } catch (e: OutOfMemoryError) {
        null
    }
}

/** Keeps one bitmap per view-model, rebuilt only when the view-model replaces its pixel array. Engine thread only. */
class BitmapCache<K : Any> {
    private class Entry(val data: ShortArray, val width: Int, val height: Int, val bitmap: Bitmap?)

    private val entries = HashMap<K, Entry>()

    fun get(key: K, vm: IPixelViewModel?): Bitmap? {
        if (vm == null) return null
        val data = vm.pixelData
        val existing = entries[key]
        if (existing != null && existing.data === data && existing.width == vm.pixelWidth && existing.height == vm.pixelHeight) return existing.bitmap
        val bitmap = pixelsToBitmap(vm)
        entries[key] = Entry(data, vm.pixelWidth, vm.pixelHeight, bitmap)
        return bitmap
    }

    fun retainOnly(live: Collection<K>) {
        entries.keys.retainAll(live.toSet())
    }
}

private class MapDraw(val bitmap: Bitmap, val left: Int, val top: Int, val scale: Double, val z: Int, val width: Int, val height: Int)

private class SliderDraw(val leftEdge: Boolean, val topEdge: Boolean, val x: Int, val y: Int, val icon: MapSliderIcons, val slider: MapSlider)

private class MapFrame(
    val maps: List<MapDraw>,
    val sliders: List<SliderDraw>,
    val cursor: RectF?,
    val hover: String,
    val zoom: String,
    val showBeneath: Boolean,
)

internal interface MapHost {
    fun showContextItems(title: String, items: List<MenuCommandNonGeneric>)
    fun showSliderMenu(slider: MapSlider)
    fun creationFinished()
}

/** The map itself: draws every visible map and turns touches into the interactions of the view-model. */
class MapCanvas internal constructor(context: Context, private val vm: MapEditorViewModel, private val binder: Binder, private val host: MapHost) : View(context) {
    var mode: MapMode = MapMode.Draw
    private var frame: MapFrame? = null
    private val dirty = AtomicBoolean(false)
    private val cache = BitmapCache<BlockMapViewModel>()
    private val watched = HashMap<INotifyPropertyChanged, (Any?, PropertyChangedEventArgs) -> Unit>()

    private val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val mask = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) }

    // touch state
    private var state = IDLE
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var pinchDistance = 0f
    private var lastTapTime = 0L
    private var lastTapX = 0f
    private var lastTapY = 0f
    private var beneathX = 0f
    private var beneathY = 0f
    private var creating: EventCreationType = EventCreationType.None
    private var session = Session()
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val longPress = ViewConfiguration.getLongPressTimeout().toLong()
    private val longPressRunnable = Runnable { onLongPress() }

    private class Session {
        @Volatile var menuShown = false
    }

    init {
        setWillNotDraw(false)
        frame = compute()
        binder.onEngineEvent {
            val onProperty: (Any?, PropertyChangedEventArgs) -> Unit = { _, _ -> requestFrame() }
            val onMaps: (Any?, NotifyCollectionChangedEventArgs) -> Unit = { _, _ -> requestFrame() }
            vm.propertyChanged += onProperty
            vm.visibleMaps.collectionChanged += onMaps
            vm.mapButtons.collectionChanged += onMaps
            val undo: () -> Unit = {
                vm.propertyChanged -= onProperty
                vm.visibleMaps.collectionChanged -= onMaps
                vm.mapButtons.collectionChanged -= onMaps
                for ((target, handler) in watched) target.propertyChanged -= handler
                watched.clear()
            }
            undo
        }
    }

    /** Arms the "drop a new event on the map" interaction: the next touch places the event. */
    fun beginCreation(type: EventCreationType) {
        creating = type
        Engine.post { vm.startEventCreationInteraction(type) }
        invalidate()
    }

    fun cancelCreation() {
        creating = EventCreationType.None
        Engine.post { vm.cancel() }
        invalidate()
    }

    fun requestFrame() {
        if (dirty.compareAndSet(false, true)) {
            Engine.post {
                try {
                    val result = compute()
                    Engine.ui {
                        frame = result
                        invalidate()
                    }
                } finally {
                    dirty.set(false)
                }
            }
        }
    }

    /** Needs the engine lock. */
    private fun compute(): MapFrame {
        val maps = ArrayList<MapDraw>()
        val visible = ArrayList<BlockMapViewModel>(vm.visibleMaps)
        val buttons = ArrayList<MapSlider>(vm.mapButtons)
        // keep a property listener on every visible map and slider (they appear and disappear while navigating)
        val handler: (Any?, PropertyChangedEventArgs) -> Unit = { _, _ -> requestFrame() }
        val wanted = HashSet<INotifyPropertyChanged>()
        wanted.addAll(visible)
        wanted.addAll(buttons)
        val stale = watched.keys.filter { it !in wanted }
        for (old in stale) {
            watched.remove(old)?.let { old.propertyChanged -= it }
        }
        for (target in wanted) {
            if (!watched.containsKey(target)) {
                target.propertyChanged += handler
                watched[target] = handler
            }
        }
        for (map in visible.sortedBy { it.zIndex }) {
            val bitmap = cache.get(map, map) ?: continue
            maps.add(MapDraw(bitmap, map.leftEdge, map.topEdge, map.spriteScale, map.zIndex, map.pixelWidth, map.pixelHeight))
        }
        cache.retainOnly(visible)
        val sliders = buttons.map { SliderDraw(it.anchorLeftEdge, it.anchorTopEdge, it.anchorPositionX, it.anchorPositionY, it.icon, it) }
        val cursor = if (vm.showHighlightCursor) {
            RectF(
                (vm.highlightCursorX - vm.highlightCursorWidth / 2).toFloat(), (vm.highlightCursorY - vm.highlightCursorHeight / 2).toFloat(),
                (vm.highlightCursorX + vm.highlightCursorWidth / 2).toFloat(), (vm.highlightCursorY + vm.highlightCursorHeight / 2).toFloat(),
            )
        } else null
        return MapFrame(maps, sliders, cursor, vm.hoverPoint, vm.zoomLevel, vm.showBeneath)
    }

    // ---------------------------------------------------------------------------------------------- drawing

    private fun sliderRect(s: SliderDraw, cx: Float, cy: Float): RectF {
        val size = Ui.dpf(28f)
        val left = if (s.leftEdge) cx + s.x * Ui.density else cx - s.x * Ui.density - size
        val top = if (s.topEdge) cy + s.y * Ui.density else cy - s.y * Ui.density - size
        return RectF(left, top, left + size, top + size)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Palette.background)
        val f = frame ?: return
        val d = Ui.density
        val cx = width / 2f
        val cy = height / 2f
        val under = f.maps.filter { it.z < 0 }
        val over = f.maps.filter { it.z >= 0 }
        fun drawMap(m: MapDraw) {
            val dest = RectF(cx + m.left * d, cy + m.top * d, cx + (m.left + m.width * m.scale).toFloat() * d, cy + (m.top + m.height * m.scale).toFloat() * d)
            if (RectF.intersects(dest, RectF(0f, 0f, width.toFloat(), height.toFloat()))) canvas.drawBitmap(m.bitmap, null, dest, paint)
        }
        for (m in under) drawMap(m)
        if (f.showBeneath && over.isNotEmpty()) {
            val layer = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
            for (m in over) drawMap(m)
            val radius = Ui.dpf(80f)
            mask.shader = RadialGradient(beneathX, beneathY, radius, intArrayOf(Color.BLACK, Color.BLACK, 0), floatArrayOf(0f, 0.8f, 1f), Shader.TileMode.CLAMP)
            canvas.drawCircle(beneathX, beneathY, radius, mask)
            canvas.restoreToCount(layer)
        } else {
            for (m in over) drawMap(m)
        }
        val cursor = f.cursor
        if (cursor != null) {
            val r = RectF(cx + cursor.left * d, cy + cursor.top * d, cx + cursor.right * d, cy + cursor.bottom * d)
            stroke.strokeWidth = Ui.dpf(3f)
            stroke.color = Palette.alpha(Palette.background, 200)
            canvas.drawRect(r, stroke)
            stroke.strokeWidth = Ui.dpf(1.5f)
            stroke.color = Palette.primary
            canvas.drawRect(r, stroke)
        }
        for (s in f.sliders) {
            val r = sliderRect(s, cx, cy)
            fill.color = Palette.backlight
            canvas.drawRoundRect(r, Ui.dpf(3f), Ui.dpf(3f), fill)
            stroke.strokeWidth = Ui.dpf(1f)
            stroke.color = Palette.secondary
            canvas.drawRoundRect(r, Ui.dpf(3f), Ui.dpf(3f), stroke)
            text.color = Palette.primary
            text.textSize = Ui.dpf(16f)
            val glyph = when (s.icon) {
                MapSliderIcons.LeftRight -> "\u2194"
                MapSliderIcons.UpDown -> "\u2195"
                MapSliderIcons.ExtendLeft -> "\u2190"
                MapSliderIcons.ExtendRight -> "\u2192"
                MapSliderIcons.ExtendUp -> "\u2191"
                MapSliderIcons.ExtendDown -> "\u2193"
            }
            canvas.drawText(glyph, r.centerX(), r.centerY() + text.textSize / 3f, text)
        }
        // status line (hover position and zoom), bottom right like the desktop app
        val status = (f.hover + "   " + f.zoom).trim()
        if (status.isNotEmpty()) {
            text.textAlign = Paint.Align.RIGHT
            text.textSize = Ui.dpf(12f)
            val w = text.measureText(status) + Ui.dpf(12f)
            fill.color = Palette.alpha(Palette.background, 220)
            canvas.drawRect(width - w, height - Ui.dpf(20f), width.toFloat(), height.toFloat(), fill)
            text.color = Palette.primary
            canvas.drawText(status, width - Ui.dpf(6f), height - Ui.dpf(6f), text)
            text.textAlign = Paint.Align.CENTER
        }
        if (creating != EventCreationType.None) {
            val hint = "Drag on the map to place the new " + creating.name.lowercase() + ", then release"
            text.textSize = Ui.dpf(13f)
            val w = text.measureText(hint) + Ui.dpf(16f)
            fill.color = Palette.alpha(Palette.accent, 200)
            canvas.drawRect(width / 2f - w / 2f, 0f, width / 2f + w / 2f, Ui.dpf(24f), fill)
            text.color = Color.BLACK
            canvas.drawText(hint, width / 2f, Ui.dpf(17f), text)
        }
    }

    // ---------------------------------------------------------------------------------------------- touch

    private fun dx(px: Float): Double = ((px - width / 2f) / Ui.density).toDouble()
    private fun dy(py: Float): Double = ((py - height / 2f) / Ui.density).toDouble()

    private fun onMap(px: Float, py: Float): Boolean {
        val f = frame ?: return false
        val d = Ui.density
        val cx = width / 2f
        val cy = height / 2f
        for (m in f.maps) {
            if (m.z < 0) continue
            val left = cx + m.left * d
            val top = cy + m.top * d
            if (px >= left && px <= left + m.width * m.scale * d && py >= top && py <= top + m.height * m.scale * d) return true
        }
        return false
    }

    private fun sliderAt(px: Float, py: Float): MapSlider? {
        val f = frame ?: return null
        val cx = width / 2f
        val cy = height / 2f
        for (s in f.sliders) if (sliderRect(s, cx, cy).contains(px, py)) return s.slider
        return null
    }

    private var touchedSlider: MapSlider? = null

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = event.x
                downY = event.y
                lastX = event.x
                lastY = event.y
                beneathX = event.x
                beneathY = event.y
                session = Session()
                val x = dx(event.x)
                val y = dy(event.y)
                val armed = creating
                if (armed != EventCreationType.None) {
                    state = CREATE
                    Engine.post { vm.primaryMove(x, y) }
                    return true
                }
                val slider = sliderAt(event.x, event.y)
                if (slider != null) {
                    touchedSlider = slider
                    state = SLIDER
                    removeCallbacks(longPressRunnable)
                    postDelayed(longPressRunnable, longPress)
                    return true
                }
                when (mode) {
                    MapMode.Pan -> {
                        state = PAN
                        Engine.post { vm.dragDown(x, y) }
                    }
                    MapMode.Select -> startSelect(x, y)
                    else -> {
                        if (!onMap(event.x, event.y)) {
                            state = PAN
                            Engine.post {
                                vm.clearSelection()
                                vm.dragDown(x, y)
                            }
                        } else {
                            state = PENDING
                            Engine.post { vm.hover(x, y) }
                            removeCallbacks(longPressRunnable)
                            postDelayed(longPressRunnable, longPress)
                        }
                    }
                }
                return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount == 2) {
                    removeCallbacks(longPressRunnable)
                    finishSingle(lastX, lastY)
                    state = PINCH
                    val mx = (event.getX(0) + event.getX(1)) / 2f
                    val my = (event.getY(0) + event.getY(1)) / 2f
                    pinchDistance = distance(event)
                    lastX = mx
                    lastY = my
                    val x = dx(mx)
                    val y = dy(my)
                    Engine.post { vm.dragDown(x, y) }
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (state == PINCH && event.pointerCount >= 2) {
                    val mx = (event.getX(0) + event.getX(1)) / 2f
                    val my = (event.getY(0) + event.getY(1)) / 2f
                    val x = dx(mx)
                    val y = dy(my)
                    val newDistance = distance(event)
                    if (pinchDistance > 0f) {
                        val ratio = newDistance / pinchDistance
                        if (ratio > 1.35f) {
                            pinchDistance = newDistance
                            Engine.post { vm.zoom(x, y, true) }
                        } else if (ratio < 0.74f) {
                            pinchDistance = newDistance
                            Engine.post { vm.zoom(x, y, false) }
                        }
                    }
                    lastX = mx
                    lastY = my
                    Engine.post { vm.dragMove(x, y, false) }
                    return true
                }
                if (event.pointerCount != 1) return true
                val px = event.x
                val py = event.y
                lastX = px
                lastY = py
                beneathX = px
                beneathY = py
                val x = dx(px)
                val y = dy(py)
                val moved = Math.abs(px - downX) > slop || Math.abs(py - downY) > slop
                when (state) {
                    PENDING -> if (moved) {
                        removeCallbacks(longPressRunnable)
                        if (mode == MapMode.Fill) {
                            // a fill is a tap; dragging pans instead
                            state = PAN
                            val sx = dx(downX)
                            val sy = dy(downY)
                            Engine.post {
                                vm.dragDown(sx, sy)
                                vm.dragMove(x, y, false)
                            }
                        } else {
                            state = PRIMARY
                            val sx = dx(downX)
                            val sy = dy(downY)
                            val start = if (mode == MapMode.Rect) PrimaryInteractionStart.ControlClick else PrimaryInteractionStart.Click
                            Engine.post {
                                vm.primaryDown(sx, sy, start)
                                vm.primaryMove(x, y)
                            }
                        }
                    }
                    PRIMARY, CREATE -> Engine.post { vm.primaryMove(x, y) }
                    PAN -> Engine.post { vm.dragMove(x, y, mode == MapMode.Pan) }
                    SELECT -> {
                        val s = session
                        Engine.post { if (!s.menuShown) vm.selectMove(x, y) }
                    }
                    SLIDER -> if (moved) {
                        removeCallbacks(longPressRunnable)
                        state = SHIFT
                        val sx = dx(downX)
                        val sy = dy(downY)
                        Engine.post {
                            vm.shiftDown(sx, sy)
                            vm.shiftMove(x, y)
                        }
                    }
                    SHIFT -> Engine.post { vm.shiftMove(x, y) }
                }
                if (state == PENDING || state == PRIMARY) invalidate()
                return true
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (state == PINCH && event.pointerCount == 2) {
                    val x = dx(lastX)
                    val y = dy(lastY)
                    Engine.post { vm.dragUp(x, y) }
                    state = IGNORE
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPressRunnable)
                val px = event.x
                val py = event.y
                val x = dx(px)
                val y = dy(py)
                when (state) {
                    PENDING -> tap(px, py)
                    PRIMARY, CREATE -> {
                        Engine.post { vm.primaryUp(x, y) }
                        if (state == CREATE) {
                            creating = EventCreationType.None
                            host.creationFinished()
                        }
                    }
                    PAN -> Engine.post { vm.dragUp(x, y) }
                    SELECT -> {
                        val s = session
                        Engine.post { if (!s.menuShown) vm.selectUp(x, y) }
                    }
                    SHIFT -> Engine.post { vm.shiftUp(x, y) }
                    SLIDER -> {
                        // a plain tap on a slider opens its menu when it has one
                        val slider = touchedSlider
                        if (slider != null && slider.enableContextMenu) host.showSliderMenu(slider)
                    }
                    PINCH -> {
                        Engine.post { vm.dragUp(x, y) }
                    }
                }
                touchedSlider = null
                state = IDLE
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                finishSingle(lastX, lastY)
                touchedSlider = null
                state = IDLE
                invalidate()
                return true
            }
        }
        return true
    }

    private fun distance(e: MotionEvent): Float {
        val dxp = e.getX(0) - e.getX(1)
        val dyp = e.getY(0) - e.getY(1)
        return Math.sqrt((dxp * dxp + dyp * dyp).toDouble()).toFloat()
    }

    /** Ends whatever one-finger interaction is running (a second finger arrived, or the gesture was cancelled). */
    private fun finishSingle(px: Float, py: Float) {
        val x = dx(px)
        val y = dy(py)
        val s = session
        when (state) {
            PRIMARY -> Engine.post { vm.primaryUp(x, y) }
            PAN -> Engine.post { vm.dragUp(x, y) }
            SELECT -> Engine.post { if (!s.menuShown) vm.selectUp(x, y) }
            SHIFT -> Engine.post { vm.shiftUp(x, y) }
            CREATE -> {
                creating = EventCreationType.None
                Engine.post { vm.cancel() }
                host.creationFinished()
            }
        }
    }

    private fun tap(px: Float, py: Float) {
        val x = dx(px)
        val y = dy(py)
        val now = android.os.SystemClock.uptimeMillis()
        val isDouble = now - lastTapTime < 350 && Math.abs(px - lastTapX) < Ui.dpf(24f) && Math.abs(py - lastTapY) < Ui.dpf(24f)
        lastTapTime = if (isDouble) 0L else now
        lastTapX = px
        lastTapY = py
        val start = when {
            mode == MapMode.Fill || isDouble -> PrimaryInteractionStart.DoubleClick
            mode == MapMode.Rect -> PrimaryInteractionStart.ControlClick
            else -> PrimaryInteractionStart.Click
        }
        Engine.post {
            vm.primaryDown(x, y, start)
            vm.primaryUp(x, y)
        }
    }

    private fun startSelect(x: Double, y: Double) {
        state = SELECT
        val s = session
        Engine.post {
            val result = vm.selectDown(x, y)
            if (result == SelectionInteractionResult.ShowMenu) {
                s.menuShown = true
                val items = ArrayList<MenuCommandNonGeneric>(vm.contextItems)
                Engine.ui {
                    state = IGNORE
                    host.showContextItems("Event", items)
                }
            }
        }
    }

    private fun onLongPress() {
        if (state == PENDING) {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            startSelect(dx(downX), dy(downY))
        } else if (state == SLIDER) {
            val slider = touchedSlider
            state = IGNORE
            if (slider != null && slider.enableContextMenu) {
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                host.showSliderMenu(slider)
            }
        }
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(longPressRunnable)
        super.onDetachedFromWindow()
    }

    private companion object {
        const val IDLE = 0
        const val PENDING = 1
        const val PRIMARY = 2
        const val PAN = 3
        const val SELECT = 4
        const val SLIDER = 5
        const val SHIFT = 6
        const val PINCH = 7
        const val CREATE = 8
        const val IGNORE = 9
    }
}

// ---------------------------------------------------------------------------------------------------- block picker

private class BlockFrame(val bitmap: Bitmap?, val width: Int, val height: Int, val scale: Double, val hx: Float, val hy: Float, val hw: Float, val hh: Float, val bag: Set<Int>)

/**
 * The grid of blocks of the current map. Tap selects a block; long-press and drag selects a rectangle of blocks. Inside
 * the mixing bag mode every tap adds or removes the block from the bag.
 */
class BlockPicker(context: Context, private val vm: MapEditorViewModel, private val scroll: ScrollView, binder: Binder) : View(context) {
    var bagMode = false
    private var frame: BlockFrame? = null
    private val dirty = AtomicBoolean(false)
    private var lastMap: BlockMapViewModel? = null
    private var lastData: ShortArray? = null
    private var lastBitmap: Bitmap? = null
    private val paint = Paint().apply { isFilterBitmap = false }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fill = Paint()

    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var multi = false
    private var startBx = 0
    private var startBy = 0
    private var fingerViewportY = 0f
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val longPress = ViewConfiguration.getLongPressTimeout().toLong()
    private val longPressRunnable = Runnable { beginMulti() }
    private val autoScroll = object : Runnable {
        override fun run() {
            if (!multi) return
            val edge = Ui.dp(48)
            val step = Ui.dp(10)
            val delta = when {
                fingerViewportY < edge -> -step
                fingerViewportY > scroll.height - edge -> step
                else -> 0
            }
            if (delta != 0) scroll.scrollBy(0, delta)
            postDelayed(this, 16)
        }
    }

    init {
        setWillNotDraw(false)
        frame = compute()
        binder.onEngineEvent {
            val onProperty: (Any?, PropertyChangedEventArgs) -> Unit = { _, _ -> requestFrame() }
            vm.propertyChanged += onProperty
            val undo: () -> Unit = { vm.propertyChanged -= onProperty }
            undo
        }
    }

    fun requestFrame() {
        if (dirty.compareAndSet(false, true)) {
            Engine.post {
                try {
                    val result = compute()
                    Engine.ui {
                        val resized = frame?.width != result.width || frame?.height != result.height || frame?.scale != result.scale
                        frame = result
                        if (resized) requestLayout()
                        invalidate()
                    }
                } finally {
                    dirty.set(false)
                }
            }
        }
    }

    /** Needs the engine lock. */
    private fun compute(): BlockFrame {
        val blocks = vm.blocks
        val map = vm.primaryMap
        if (blocks != null) {
            val data = blocks.pixelData
            if (lastMap !== map || lastData !== data) {
                lastBitmap = pixelsToBitmap(blocks)
                lastMap = map
                lastData = data
            }
        } else {
            lastBitmap = null
        }
        val bag = HashSet<Int>()
        return BlockFrame(
            lastBitmap, blocks?.pixelWidth ?: 0, blocks?.pixelHeight ?: 0, blocks?.spriteScale ?: 2.0,
            vm.highlightBlockX.toFloat(), vm.highlightBlockY.toFloat(), vm.highlightBlockWidth.toFloat(), vm.highlightBlockHeight.toFloat(), bag,
        )
    }

    private fun cell(): Float = (16 * (frame?.scale ?: 2.0) * Ui.density).toFloat()

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val f = frame
        val scale = (f?.scale ?: 2.0) * Ui.density
        val w = ((f?.width ?: 0) * scale).toInt()
        val h = ((f?.height ?: 0) * scale).toInt()
        setMeasuredDimension(resolveSize(Math.max(w, Ui.dp(64)), widthSpec), Math.max(h, Ui.dp(32)))
    }

    override fun onDraw(canvas: Canvas) {
        val f = frame ?: return
        val bitmap = f.bitmap ?: return
        val scale = (f.scale * Ui.density).toFloat()
        val dest = RectF(0f, 0f, f.width * scale, f.height * scale)
        canvas.drawBitmap(bitmap, null, dest, paint)
        val x = f.hx * Ui.density
        val y = f.hy * Ui.density
        if (f.hw > 0f) {
            stroke.strokeWidth = Ui.dpf(3f)
            stroke.color = Palette.alpha(Palette.background, 220)
            canvas.drawRect(x, y, x + f.hw * Ui.density - Ui.dpf(2f), y + f.hh * Ui.density - Ui.dpf(2f), stroke)
            stroke.strokeWidth = Ui.dpf(1.5f)
            stroke.color = Palette.accent
            canvas.drawRect(x, y, x + f.hw * Ui.density - Ui.dpf(2f), y + f.hh * Ui.density - Ui.dpf(2f), stroke)
        }
        fill.color = 0
    }

    private fun blockX(px: Float): Int = Math.max(0, Math.min(BlockMapViewModel.blocksPerRow - 1, (px / cell()).toInt()))
    private fun blockY(py: Float): Int = Math.max(0, (py / cell()).toInt())

    private fun beginMulti() {
        if (moved || multi) return
        multi = true
        parent?.requestDisallowInterceptTouchEvent(true)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val bx = startBx
        val by = startBy
        Engine.post { vm.selectBlock(bx, by) }
        postDelayed(autoScroll, 16)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                moved = false
                multi = false
                startBx = blockX(event.x)
                startBy = blockY(event.y)
                fingerViewportY = event.y - scroll.scrollY
                postDelayed(longPressRunnable, longPress)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                fingerViewportY = event.y - scroll.scrollY
                if (multi) {
                    val bx = blockX(event.x)
                    val by = blockY(event.y)
                    Engine.post { vm.dragBlock(bx, by) }
                } else if (Math.abs(event.x - downX) > slop || Math.abs(event.y - downY) > slop) {
                    moved = true
                    removeCallbacks(longPressRunnable)
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPressRunnable)
                removeCallbacks(autoScroll)
                val bx = blockX(event.x)
                val by = blockY(event.y)
                if (multi) {
                    multi = false
                    Engine.post { vm.releaseBlock(bx, by) }
                } else if (!moved) {
                    val bag = bagMode
                    Engine.post {
                        if (bag) {
                            vm.toggleBlockInBag(bx, by)
                        } else {
                            vm.selectBlock(bx, by)
                            vm.releaseBlock(bx, by)
                        }
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                removeCallbacks(autoScroll)
                if (multi) {
                    multi = false
                    val bx = blockX(downX)
                    val by = blockY(downY)
                    Engine.post { vm.releaseBlock(bx, by) }
                }
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(longPressRunnable)
        removeCallbacks(autoScroll)
        super.onDetachedFromWindow()
    }
}
