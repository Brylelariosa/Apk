package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.text.InputType
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.models.Direction
import dev.hexmaniac.core.models.Point
import dev.hexmaniac.core.system.ConsoleKey
import dev.hexmaniac.core.viewmodels.ConvertCellToText
import dev.hexmaniac.core.viewmodels.IEditableViewPort
import dev.hexmaniac.core.viewmodels.IViewPort
import dev.hexmaniac.core.viewmodels.ViewPort
import dev.hexmaniac.core.viewmodels.dataformats.Anchor
import dev.hexmaniac.core.viewmodels.dataformats.Ascii
import dev.hexmaniac.core.viewmodels.dataformats.BitArray
import dev.hexmaniac.core.viewmodels.dataformats.Braille
import dev.hexmaniac.core.viewmodels.dataformats.EggItem
import dev.hexmaniac.core.viewmodels.dataformats.EggSection
import dev.hexmaniac.core.viewmodels.dataformats.EndStream
import dev.hexmaniac.core.viewmodels.dataformats.ErrorPCS
import dev.hexmaniac.core.viewmodels.dataformats.EscapedPCS
import dev.hexmaniac.core.viewmodels.dataformats.IDataFormat
import dev.hexmaniac.core.viewmodels.dataformats.IDataFormatDecorator
import dev.hexmaniac.core.viewmodels.dataformats.IDataFormatInstance
import dev.hexmaniac.core.viewmodels.dataformats.Integer
import dev.hexmaniac.core.viewmodels.dataformats.IntegerEnum
import dev.hexmaniac.core.viewmodels.dataformats.IntegerHex
import dev.hexmaniac.core.viewmodels.dataformats.LzCompressed
import dev.hexmaniac.core.viewmodels.dataformats.LzGroupHeader
import dev.hexmaniac.core.viewmodels.dataformats.LzMagicIdentifier
import dev.hexmaniac.core.viewmodels.dataformats.LzUncompressed
import dev.hexmaniac.core.viewmodels.dataformats.MatchedWord
import dev.hexmaniac.core.viewmodels.dataformats.None
import dev.hexmaniac.core.viewmodels.dataformats.PCS
import dev.hexmaniac.core.viewmodels.dataformats.PlmItem
import dev.hexmaniac.core.viewmodels.dataformats.Pointer
import dev.hexmaniac.core.viewmodels.dataformats.SpriteDecorator
import dev.hexmaniac.core.viewmodels.dataformats.UncompressedPaletteColor
import dev.hexmaniac.core.viewmodels.dataformats.UnderEdit
import dev.hexmaniac.core.viewmodels.dataformats.Tuple
import java.util.concurrent.atomic.AtomicBoolean

// ------------------------------------------------------------------------------------------------ the frame

/** One run of text inside a row of cells. [startCell] may be negative (the element started on the previous row). */
class TextOp(val text: String, val startCell: Int, val cells: Int, val row: Int, val color: Int, val small: Boolean, val italic: Boolean)

class LineOp(val row: Int, val fromCell: Float, val toCell: Float, val color: Int)
class SpriteOp(val row: Int, val cellWidth: Int, val cellHeight: Int, val bitmap: Bitmap)
class EditOp(val col: Int, val row: Int, val text: String, val editWidth: Int)
class AutoOp(val col: Int, val row: Int, val items: List<String>, val completions: List<String>, val selected: Int)

/** Everything the UI thread needs to draw the visible cells; built on the engine thread, immutable afterwards. */
class HexFrame(
    val cols: Int,
    val rows: Int,
    val scrollValue: Int,
    val minScroll: Int,
    val maxScroll: Int,
    val seq: Int,
    val texts: List<TextOp>,
    val lines: List<LineOp>,
    val anchors: List<Int>,
    val sprites: List<SpriteOp>,
    /** (cols + 2) x (rows + 2), index (y + 1) * (cols + 2) + (x + 1) */
    val selected: BooleanArray,
    val edited: BooleanArray,
    val edits: List<EditOp>,
    val auto: AutoOp?,
    val rowHeaders: List<String>,
    val rowHeaderSelected: BooleanArray,
    val columnRows: List<List<Pair<String, Int>>>,
    val selStartX: Int,
    val selStartY: Int,
    val showGrid: Boolean,
    val stretch: Boolean,
    val editable: Boolean,
) {
    fun isSelected(x: Int, y: Int): Boolean {
        if (x < -1 || y < -1 || x > cols || y > rows) return false
        return selected[(y + 1) * (cols + 2) + (x + 1)]
    }
}

/** Builds [HexFrame]s. Engine thread only. */
internal class FrameBuilder {
    private val spriteCache = ArrayList<Pair<Any, Bitmap>>()

    private fun spriteBitmap(sprite: SpriteDecorator): Bitmap? {
        val vm = sprite.pixels
        for (entry in spriteCache) if (entry.first === vm) return entry.second
        val w = vm.pixelWidth
        val h = vm.pixelHeight
        val data = vm.pixelData
        if (w <= 0 || h <= 0 || data.size < w * h) return null
        val colors = IntArray(w * h)
        val transparent = vm.transparent.toInt()
        for (i in colors.indices) {
            val c = data[i].toInt()
            colors[i] = if (c == transparent) 0 else Color.rgb(((c shr 10) and 31) * 255 / 31, ((c shr 5) and 31) * 255 / 31, (c and 31) * 255 / 31)
        }
        val bitmap = Bitmap.createBitmap(colors, w, h, Bitmap.Config.ARGB_8888)
        if (spriteCache.size >= 20) spriteCache.removeAt(0)
        spriteCache.add(Pair(vm, bitmap))
        return bitmap
    }

    fun build(vp: IViewPort, seq: Int, searchBytes: ByteArray?, showGrid: Boolean): HexFrame {
        val cols = maxOf(vp.width, 1)
        val rows = maxOf(vp.height, 1)
        val texts = ArrayList<TextOp>()
        val lines = ArrayList<LineOp>()
        val anchors = ArrayList<Int>()
        val sprites = ArrayList<SpriteOp>()
        val edits = ArrayList<EditOp>()
        var auto: AutoOp? = null
        val edited = BooleanArray(cols * rows)
        val editable = vp as? IEditableViewPort
        val lightweightMode = (vp as? ViewPort)?.distractionFreeMode == true
        val model = vp.model
        val noSearch = searchBytes == null || searchBytes.isEmpty()
        val p = Palette

        for (y in 0 until rows) {
            // sprite behind the whole row
            var rowFormat: IDataFormat? = vp[0, y].format
            if (rowFormat is Anchor) rowFormat = rowFormat.originalFormat
            if (rowFormat is SpriteDecorator && rowFormat.cellWidth == vp.width) {
                spriteBitmap(rowFormat)?.let { sprites.add(SpriteOp(y, rowFormat.cellWidth, rowFormat.cellHeight, it)) }
            }
            for (x in 0 until cols) {
                val cell = vp[x, y]
                edited[y * cols + x] = cell.edited
                var format: IDataFormat? = cell.format ?: continue
                var hasAnchor = false
                while (format is IDataFormatDecorator) {
                    if (format is Anchor) hasAnchor = true
                    format = format.originalFormat
                }
                if (hasAnchor) anchors.add(y * 65536 + x)
                val value = cell.value
                val lightweight = lightweightMode && !vp.isSelected(Point(x, y))

                fun instanceStart(f: IDataFormat): Int? {
                    val instance = f as? IDataFormatInstance ?: return x
                    if (instance.position != 0) {
                        if (x > 0) return null
                        return x - instance.position
                    }
                    return x
                }

                fun add(text: String?, f: IDataFormat, cells: Int, color: Int, small: Boolean = false, italic: Boolean = false) {
                    if (text.isNullOrEmpty()) return
                    val start = instanceStart(f) ?: return
                    texts.add(TextOp(text, start, cells, y, color, small, italic))
                }

                when (val f = format) {
                    is UnderEdit -> {
                        edits.add(EditOp(x, y, f.currentText, f.editWidth))
                        val options = f.autocompleteOptions
                        if (options != null && options.isNotEmpty() && auto == null) {
                            auto = AutoOp(x, y, options.map { it.displayText }, options.map { it.completionText }, options.indexOfFirst { it.isSelected })
                        }
                    }
                    is PCS -> add(f.thisCharacter, f, 1, p.text1)
                    is EscapedPCS -> add(String.format("%02X", f.thisValue and 0xFF), f, 1, p.text1)
                    is ErrorPCS -> add(String.format("%02X", value and 0xFF), f, 1, p.error)
                    is Pointer -> {
                        val color = when {
                            f.hasError -> p.error
                            f.offsetValue != 0 -> p.data2
                            else -> p.accent
                        }
                        val text = if (lightweight && !f.hasError && f.offsetValue == 0 && f.destinationName.isEmpty()) "<unknown>" else f.destinationAsText
                        add(text, f, 4, color)
                        val lineColor = if (f.destination < 0) p.error else if (f.offsetValue != 0) p.data2 else p.accent
                        lines.add(LineOp(y, x + if (f.position == 0) 0.25f else 0f, x + 1f - if (f.position == 3) 0.25f else 0f, lineColor))
                    }
                    is PlmItem -> add(f.toString(), f, 2, p.stream2, small = true)
                    is EggItem -> add(f.itemName, f, 2, p.stream2, small = true)
                    is EggSection -> add(f.sectionName, f, 2, p.stream1, small = true)
                    is IntegerEnum -> add(f.displayValue, f, f.length, p.data2, small = true)
                    is IntegerHex -> add(f.toString(), f, f.length, if (f.isUnused) p.secondary else p.data2)
                    is Integer -> add(f.value.toString(), f, f.length, if (f.isUnused) p.secondary else p.data1)
                    is Ascii -> add(f.thisCharacter, f, 1, p.text2)
                    is Braille -> add(f.thisCharacter.toString(), f, 1, p.text2)
                    is None -> {
                        val hex = String.format("%02X", value and 0xFF)
                        if (lightweight && value == 0xFF) {
                            // free space: draw nothing
                        } else if (!lightweight) {
                            when {
                                f.isSearchResult -> add(hex, f, 1, p.primary)
                                value == 0x00 -> add("00", f, 1, p.secondary)
                                value == 0xFF -> add("FF", f, 1, p.secondary, italic = true)
                                noSearch -> add(hex, f, 1, p.primary)
                                else -> add(hex, f, 1, p.secondary)
                            }
                        } else if (value == 0xB5 && x % 2 == 1) {
                            if (x > 0) texts.add(TextOp("thumb", x - 1, 2, y, p.secondary, false, true))
                        } else if (x % 2 == 1 || (x < cols - 1 && vp[x + 1, y].value != 0xB5)) {
                            texts.add(TextOp("..", x, 1, y, p.secondary, false, true))
                        }
                        if (value == 0xB5 && !lightweightMode) lines.add(LineOp(y, x.toFloat(), x + 1f, p.secondary))
                    }
                    is BitArray -> add(f.displayValue, f, f.length, p.data1)
                    is MatchedWord -> add(f.name, f, 4, p.data1, small = true)
                    is EndStream -> {
                        if (model != null) {
                            val converter = ConvertCellToText(model, 0)
                            converter.visit(f, value)
                            add(converter.result, f, f.length, p.stream1)
                        }
                    }
                    is LzMagicIdentifier -> add("lz", f, 1, p.text2)
                    is LzGroupHeader -> add(String.format("%02X", value and 0xFF), f, 1, p.data1)
                    is LzUncompressed -> add(String.format("%02X", value and 0xFF), f, 1, p.data2)
                    is LzCompressed -> add(f.runLength.toString() + ":" + f.runOffset, f, 2, p.stream2)
                    is UncompressedPaletteColor -> {
                        add(f.toString(), f, 2, p.data2, small = true)
                        val c = f.color.toInt()
                        val argb = Color.rgb(((c shr 10) and 31) * 255 / 31, ((c shr 5) and 31) * 255 / 31, (c and 31) * 255 / 31)
                        lines.add(LineOp(y, x + if (f.position == 0) 0.25f else 0f, x + 1f - if (f.position == 1) 0.25f else 0f, argb))
                    }
                    is Tuple -> add(f.toString(), f, f.length, p.data2, small = true)
                    else -> Unit
                }
            }
        }

        val selected = BooleanArray((cols + 2) * (rows + 2))
        for (y in -1..rows) for (x in -1..cols) selected[(y + 1) * (cols + 2) + (x + 1)] = vp.isSelected(Point(x, y))

        val headerList = ArrayList<String>()
        val headerSelected = BooleanArray(rows)
        val headers = vp.headers
        if (headers != null) {
            for (i in 0 until minOf(rows, headers.size)) {
                headerList.add(headers[i].content)
                headerSelected[i] = headers[i].isSelected
            }
        }
        val columnRows = ArrayList<List<Pair<String, Int>>>()
        for (row in vp.columnHeaders) columnRows.add(row.columnHeaders.map { Pair(it.columnTitle, it.byteWidth) })

        return HexFrame(
            cols, rows, vp.scrollValue, vp.minimumScroll, vp.maximumScroll, seq,
            texts, lines, anchors, sprites, selected, edited, edits, auto,
            headerList, headerSelected, columnRows,
            editable?.selectionStart?.x ?: -1, editable?.selectionStart?.y ?: -1,
            showGrid, vp.stretchData, editable != null,
        )
    }
}

// ------------------------------------------------------------------------------------------------ the view

/**
 * Draws a hex editor page and turns touches into view-model calls. The view never reads the view-model on the UI
 * thread: the engine thread posts a [HexFrame] whenever something visible changes.
 */
class HexView(context: Context, private val vp: IViewPort, private val searchBytes: () -> ByteArray?, private val showGrid: () -> Boolean) : View(context) {
    interface Host {
        fun onContextMenu(x: Int, y: Int, screenX: Float, screenY: Float)
        fun onAutocomplete(auto: AutoOp?, anchor: Rect)
        fun onZoom(factor: Float)
        fun onEditRequest()
    }

    var host: Host? = null
    var fontPx: Float = 13f * Ui.density
        set(value) {
            field = value
            applyMetrics()
            requestFrame()
        }

    private val editable = vp as? IEditableViewPort
    private val concrete = vp as? ViewPort
    private val binder = Binder()
    private val builder = FrameBuilder()
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
    private val italicPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.MONOSPACE, Typeface.ITALIC) }
    private val gutterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE; textAlign = Paint.Align.RIGHT }
    private val fill = Paint()
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = Ui.dpf(1f) }
    private val triangle = Path()

    private var cellW = 0f
    private var cellH = 0f
    private var drawCellW = 0f
    private var gutterW = 0f
    private var headerH = 0f
    private var frame: HexFrame? = null

    // engine-thread inputs (written on the UI thread)
    @Volatile private var maxCols = 1
    @Volatile private var wantRows = 1
    @Volatile private var requestedRow = 0
    @Volatile private var requestSeq = 0
    private val dirty = AtomicBoolean(false)
    private var appliedCols = -1

    private var scrollTarget = 0.0
    private var touching = false
    private var flinging = false

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        setWillNotDraw(false)
        applyMetrics()
        binder.onEngineEvent {
            val handler: (Any?, dev.hexmaniac.core.system.PropertyChangedEventArgs) -> Unit = { _, e ->
                when (e.propertyName) {
                    "selectionStart", "selectionEnd", "scrollValue", "updateInProgress", "stretchData", "allowMultipleElementsPerLine",
                    "preferredWidth", "width", "height", "useCustomHeaders", "minimumScroll", "maximumScroll", "autoAdjustDataWidth", null -> requestFrame()
                    else -> Unit
                }
            }
            val collection: (Any?, dev.hexmaniac.core.system.NotifyCollectionChangedEventArgs) -> Unit = { _, _ -> requestFrame() }
            vp.propertyChanged += handler
            vp.collectionChanged += collection
            vp.headers?.collectionChanged?.plusAssign(collection)
            vp.columnHeaders.collectionChanged += collection
            val undo: () -> Unit = {
                vp.propertyChanged -= handler
                vp.collectionChanged -= collection
                vp.headers?.collectionChanged?.minusAssign(collection)
                vp.columnHeaders.collectionChanged -= collection
            }
            undo
        }
        requestFrame()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        binder.dispose()
    }

    // ---------------------------------------------------------------- metrics

    private fun applyMetrics() {
        textPaint.textSize = fontPx
        smallPaint.textSize = fontPx * 0.75f
        italicPaint.textSize = fontPx
        gutterPaint.textSize = fontPx * 0.8f
        val sample = textPaint.measureText("000")
        val fm = textPaint.fontMetrics
        val textHeight = fm.descent - fm.ascent
        cellH = Math.ceil(maxOf(textHeight, sample * 2f / 3f).toDouble()).toFloat()
        cellW = Math.ceil((cellH * 3f / 2f).toDouble()).toFloat()
        gutterW = gutterPaint.measureText("000000") + Ui.dpf(10f)
        layoutRequestFromSize()
    }

    private fun layoutRequestFromSize() {
        if (width == 0 || height == 0 || cellW == 0f) return
        val cols = maxOf(1, ((width - gutterW) / cellW).toInt())
        val visible = Math.ceil(((height - headerH) / cellH).toDouble()).toInt()
        val rows = maxOf(1, visible + 1)
        if (cols != maxCols || rows != wantRows) {
            maxCols = cols
            wantRows = rows
            requestFrame()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutRequestFromSize()
    }

    private fun headerHeightFor(f: HexFrame): Float {
        if (f.columnRows.isEmpty()) return 0f
        var total = 0f
        val fm = gutterPaint.fontMetrics
        val line = fm.descent - fm.ascent
        for (row in f.columnRows) {
            var need = line + Ui.dpf(4f)
            var offsetCells = 0
            for ((name, byteWidth) in row) {
                val width = byteWidth * drawCellW
                val textWidth = gutterPaint.measureText(name)
                if (textWidth > width - Ui.dpf(2f) && width > 0) need = maxOf(need, textWidth * 0.62f + line)
                offsetCells += byteWidth
            }
            total += need
        }
        return total
    }

    // ---------------------------------------------------------------- frames

    fun requestFrame() {
        if (dirty.compareAndSet(false, true)) Engine.post { rebuild() }
    }

    private fun rebuild() {
        try {
            val seq = requestSeq
            val row = requestedRow
            if (maxCols != appliedCols) {
                appliedCols = maxCols
                vp.width = maxCols
            }
            if (vp.height != wantRows) vp.height = wantRows
            if (vp.scrollValue != row) vp.scrollValue = row
            val f = builder.build(vp, seq, searchBytes(), showGrid())
            Engine.ui { applyFrame(f) }
        } finally {
            dirty.set(false)
        }
    }

    private fun applyFrame(f: HexFrame) {
        val extra = width - gutterW - f.cols * cellW
        drawCellW = cellW + if (f.stretch && extra > 0) Math.floor((minOf(extra, f.cols * cellW * 2f) / f.cols).toDouble()).toFloat() else 0f
        frame = f
        val newHeader = headerHeightFor(f)
        if (newHeader != headerH) {
            headerH = newHeader
            layoutRequestFromSize()
        }
        if (f.seq == requestSeq && f.scrollValue != requestedRow && !touching) {
            requestedRow = f.scrollValue
            scrollTarget = f.scrollValue.toDouble()
        }
        host?.onAutocomplete(f.auto, autoAnchor(f))
        invalidate()
    }

    private fun autoAnchor(f: HexFrame): Rect {
        val auto = f.auto ?: return Rect()
        val x = gutterW + auto.col * drawCellW
        val y = headerH + (f.scrollValue - scrollTarget).toFloat() * cellH + auto.row * cellH
        return Rect(x.toInt(), y.toInt(), (x + drawCellW).toInt(), (y + cellH).toInt())
    }

    // ---------------------------------------------------------------- drawing

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Palette.background)
        val f = frame ?: return
        val cw = drawCellW
        val ch = cellH
        val rowShift = ((f.scrollValue - scrollTarget) * ch).toFloat()

        // column headers
        if (headerH > 0f) drawColumnHeaders(canvas, f)

        // content
        canvas.save()
        canvas.clipRect(gutterW, headerH, width.toFloat(), height.toFloat())
        canvas.translate(gutterW, headerH + rowShift)
        canvas.save()
        canvas.clipRect(0f, -ch * 2f, f.cols * cw, f.rows * ch + ch * 2f)

        for (s in f.sprites) {
            val bw = s.bitmap.width.toFloat()
            val bh = s.bitmap.height.toFloat()
            var dest = RectF(0f, s.row * ch, s.cellWidth * cw, s.row * ch + s.cellHeight * ch)
            if (s.cellWidth * 8 != s.bitmap.width || s.cellHeight * 8 != s.bitmap.height) {
                val availableRows = minOf(f.rows - s.row, s.cellHeight)
                val scale = 1f / maxOf(bw / (s.cellWidth * cw), bh / (availableRows * ch))
                val w = bw * scale
                val h = bh * scale
                val availableW = f.cols * cw
                val availableH = availableRows * ch
                dest = RectF((availableW - w) / 2f, s.row * ch + (availableH - h) / 2f, (availableW - w) / 2f + w, s.row * ch + (availableH - h) / 2f + h)
            }
            fill.color = Color.WHITE
            fill.alpha = 100
            canvas.drawBitmap(s.bitmap, null, dest, fill)
            fill.alpha = 255
        }

        if (f.showGrid) {
            stroke.color = Palette.backlight
            for (x in 1..f.cols) canvas.drawLine(cw * x, 0f, cw * x, ch * f.rows, stroke)
            for (y in 1..f.rows) canvas.drawLine(0f, ch * y, cw * f.cols, ch * y, stroke)
        }

        // selection and edited cells
        for (y in 0 until f.rows) {
            for (x in 0 until f.cols) {
                val isSel = f.isSelected(x, y)
                val isEdited = f.edited[y * f.cols + x]
                if (isEdited && !isSel) {
                    fill.color = Palette.editBackground
                    canvas.drawRect(x * cw, y * ch, (x + 1) * cw, (y + 1) * ch, fill)
                }
                if (!isSel) continue
                fill.color = Palette.backlight
                canvas.drawRect(x * cw, y * ch, (x + 1) * cw, (y + 1) * ch, fill)
                if (isEdited) {
                    fill.color = Palette.editBackground
                    canvas.drawRect(x * cw, y * ch, (x + 1) * cw, (y + 1) * ch, fill)
                }
                stroke.color = Palette.accent
                val l = x * cw
                val t = y * ch
                val r = l + cw
                val b = t + ch
                if (!f.isSelected(x, y - 1)) canvas.drawLine(l, t, r, t, stroke)
                if (!f.isSelected(x, y + 1)) canvas.drawLine(l, b, r, b, stroke)
                if (!f.isSelected(x - 1, y)) canvas.drawLine(l, t, l, b, stroke)
                if (!f.isSelected(x + 1, y)) canvas.drawLine(r, t, r, b, stroke)
            }
        }

        // text
        for (op in f.texts) drawText(canvas, op, cw, ch)

        // underlines
        for (line in f.lines) {
            stroke.color = line.color
            val y = (line.row + 1) * ch - Ui.dpf(1f)
            canvas.drawLine(line.fromCell * cw, y, line.toCell * cw, y, stroke)
        }

        // anchors
        stroke.color = Palette.accent
        val ts = fontPx / 16f * Ui.density
        for (code in f.anchors) {
            val x = (code and 0xFFFF) * cw
            val y = (code shr 16) * ch
            triangle.reset()
            triangle.moveTo(x, y + 5f * ts)
            triangle.lineTo(x + 3f * ts, y)
            triangle.lineTo(x + 6f * ts, y + 5f * ts)
            canvas.drawPath(triangle, stroke)
        }

        // text being typed
        for (edit in f.edits) {
            val region = edit.editWidth * cw
            fill.color = Palette.background
            canvas.drawRect(edit.col * cw, edit.row * ch, edit.col * cw + region, (edit.row + 1) * ch, fill)
            textPaint.color = Palette.primary
            val w = textPaint.measureText(edit.text)
            val fm = textPaint.fontMetrics
            val baseline = edit.row * ch + (ch - (fm.descent - fm.ascent)) / 2f - fm.ascent
            canvas.save()
            canvas.clipRect(edit.col * cw, edit.row * ch, edit.col * cw + region, (edit.row + 1) * ch)
            val x = if (w > region) edit.col * cw + region - w else edit.col * cw + (cw - textPaint.measureText("00")) / 2f
            canvas.drawText(edit.text, x, baseline, textPaint)
            canvas.restore()
            stroke.color = Palette.accent
            canvas.drawRect(edit.col * cw, edit.row * ch, edit.col * cw + region, (edit.row + 1) * ch, stroke)
        }
        canvas.restore()
        canvas.restore()

        // row headers
        canvas.save()
        canvas.clipRect(0f, headerH, gutterW, height.toFloat())
        fill.color = Palette.backlight
        canvas.drawRect(0f, headerH, gutterW, height.toFloat(), fill)
        val gfm = gutterPaint.fontMetrics
        for (i in f.rowHeaders.indices) {
            val selected = f.rowHeaderSelected[i]
            gutterPaint.color = if (selected) Palette.primary else Palette.secondary
            val baseline = headerH + rowShift + i * ch + (ch - (gfm.descent - gfm.ascent)) / 2f - gfm.ascent
            canvas.drawText(f.rowHeaders[i], gutterW - Ui.dpf(4f), baseline, gutterPaint)
        }
        canvas.restore()
        fill.color = Palette.background
        canvas.drawRect(gutterW - 1f, headerH, gutterW, height.toFloat(), fill)

        drawScrollbar(canvas, f)
    }

    private fun drawText(canvas: Canvas, op: TextOp, cw: Float, ch: Float) {
        val paint = if (op.italic) italicPaint else if (op.small) smallPaint else textPaint
        paint.color = op.color
        val region = op.cells * cw
        var text = op.text
        var w = paint.measureText(text)
        if (w > region) {
            val ellipsis = "\u2026" + if (text.endsWith(">")) ">" else ""
            var cut = text.length
            while (cut > 0 && paint.measureText(text.substring(0, cut) + ellipsis) > region) cut--
            text = text.substring(0, cut) + ellipsis
            w = paint.measureText(text)
        }
        val fm = paint.fontMetrics
        val x = op.startCell * cw + (region - w) / 2f
        val baseline = op.row * ch + (ch - (fm.descent - fm.ascent)) / 2f - fm.ascent
        canvas.drawText(text, x, baseline, paint)
    }

    private fun drawColumnHeaders(canvas: Canvas, f: HexFrame) {
        canvas.save()
        canvas.clipRect(gutterW, 0f, width.toFloat(), headerH)
        fill.color = Palette.background
        canvas.drawRect(gutterW, 0f, width.toFloat(), headerH, fill)
        val fm = gutterPaint.fontMetrics
        val line = fm.descent - fm.ascent
        var top = 0f
        val rowH = headerH / f.columnRows.size
        gutterPaint.textAlign = Paint.Align.LEFT
        for (row in f.columnRows) {
            var cell = 0
            var alt = false
            for ((name, byteWidth) in row) {
                val left = gutterW + cell * drawCellW
                val widthPx = byteWidth * drawCellW
                fill.color = if (alt) Palette.alpha(Palette.backlight, 200) else Palette.alpha(Palette.backlight, 110)
                canvas.drawRect(left + 1f, top, left + widthPx - 1f, top + rowH, fill)
                gutterPaint.color = Palette.secondary
                if (gutterPaint.measureText(name) <= widthPx - Ui.dpf(2f)) {
                    canvas.drawText(name, left + (widthPx - gutterPaint.measureText(name)) / 2f, top + rowH - Ui.dpf(3f) - fm.descent, gutterPaint)
                } else {
                    canvas.save()
                    canvas.rotate(-45f, left + Ui.dpf(2f), top + rowH - Ui.dpf(2f))
                    canvas.drawText(name, left + Ui.dpf(2f), top + rowH - Ui.dpf(2f), gutterPaint)
                    canvas.restore()
                }
                cell += byteWidth
                alt = !alt
            }
            top += rowH
            if (line < 0f) break
        }
        gutterPaint.textAlign = Paint.Align.RIGHT
        canvas.restore()
    }

    private fun drawScrollbar(canvas: Canvas, f: HexFrame) {
        val span = (f.maxScroll - f.minScroll).toDouble()
        if (span <= 0.0) return
        val fraction = ((scrollTarget - f.minScroll) / span).coerceIn(0.0, 1.0).toFloat()
        val trackTop = headerH + Ui.dpf(4f)
        val trackBottom = height - Ui.dpf(4f)
        val thumbH = Ui.dpf(44f)
        val y = trackTop + (trackBottom - trackTop - thumbH) * fraction
        fill.color = Palette.alpha(Palette.secondary, if (touching || flinging || scrollbarDrag) 220 else 110)
        val right = width - Ui.dpf(2f)
        canvas.drawRoundRect(RectF(right - Ui.dpf(5f), y, right, y + thumbH), Ui.dpf(2f), Ui.dpf(2f), fill)
    }

    // ---------------------------------------------------------------- touch

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val longPress = ViewConfiguration.getLongPressTimeout().toLong()
    private var velocity: VelocityTracker? = null
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var mode = 0 // 0 idle, 1 pending, 2 scrolling, 3 selecting, 4 scrollbar
    private var scrollbarDrag = false
    private var lastTapTime = 0L
    private var lastTapX = 0f
    private var lastTapY = 0f
    private var selectedEnd: Point? = null
    private var movedSinceLongPress = false
    private val longPressRunnable = Runnable { beginSelecting() }
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {
            host?.onZoom(detector.scaleFactor)
        }
    })

    private fun cellAt(px: Float, py: Float): Point? {
        val f = frame ?: return null
        val col = Math.floor(((px - gutterW) / drawCellW).toDouble()).toInt().coerceIn(0, f.cols - 1)
        val row = Math.floor(((py - headerH) / cellH + (scrollTarget - f.scrollValue)).toDouble()).toInt().coerceIn(0, f.rows - 1)
        return Point(col, row)
    }

    private fun beginSelecting() {
        if (mode != 1) return
        val p = cellAt(downX, downY) ?: return
        mode = 3
        movedSinceLongPress = false
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        selectedEnd = p
        val e = concrete ?: return
        if (!e.isSelected(p)) Engine.post { e.selectionStart = p }
    }

    private fun scrollBy(rows: Double) {
        val f = frame ?: return
        val low = f.minScroll.toDouble()
        val high = f.maxScroll.toDouble()
        scrollTarget = (scrollTarget + rows).coerceIn(low, maxOf(low, high))
        val row = Math.floor(scrollTarget).toInt()
        if (row != requestedRow) {
            requestedRow = row
            requestSeq++
            requestFrame()
        }
        invalidate()
    }

    private fun scrollbarTo(py: Float) {
        val f = frame ?: return
        val span = (f.maxScroll - f.minScroll).toDouble()
        if (span <= 0.0) return
        val trackTop = headerH + Ui.dpf(4f)
        val trackBottom = height - Ui.dpf(4f)
        val thumbH = Ui.dpf(44f)
        val fraction = ((py - thumbH / 2f - trackTop) / (trackBottom - trackTop - thumbH)).coerceIn(0f, 1f)
        scrollBy(f.minScroll + span * fraction - scrollTarget)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        if (scaleDetector.isInProgress || event.pointerCount > 1) {
            removeCallbacks(longPressRunnable)
            if (mode == 1 || mode == 3) mode = 0
            return true
        }
        val e = concrete
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                requestFocus()
                touching = true
                flinging = false
                downX = event.x
                downY = event.y
                lastX = event.x
                lastY = event.y
                velocity?.recycle()
                velocity = VelocityTracker.obtain()
                velocity?.addMovement(event)
                if (event.x > width - Ui.dpf(28f) && (frame?.maxScroll ?: 0) > (frame?.minScroll ?: 0)) {
                    mode = 4
                    scrollbarDrag = true
                    scrollbarTo(event.y)
                } else {
                    mode = 1
                    postDelayed(longPressRunnable, longPress)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(event)
                when (mode) {
                    1 -> if (Math.abs(event.x - downX) > slop || Math.abs(event.y - downY) > slop) {
                        removeCallbacks(longPressRunnable)
                        mode = 2
                        lastY = event.y
                    }
                    2 -> {
                        scrollBy(-(event.y - lastY).toDouble() / cellH)
                        lastY = event.y
                    }
                    3 -> {
                        if (Math.abs(event.x - downX) > slop || Math.abs(event.y - downY) > slop) movedSinceLongPress = true
                        val p = cellAt(event.x, event.y)
                        if (p != null && e != null && (selectedEnd == null || !selectedEnd!!.equals(p))) {
                            selectedEnd = p
                            Engine.post { e.selectionEnd = p }
                        }
                        if (event.y < headerH + cellH) scrollBy(-0.25) else if (event.y > height - cellH) scrollBy(0.25)
                    }
                    4 -> scrollbarTo(event.y)
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPressRunnable)
                touching = false
                scrollbarDrag = false
                when (mode) {
                    1 -> handleTap(event.x, event.y)
                    2 -> {
                        velocity?.computeCurrentVelocity(1000)
                        val v = velocity?.yVelocity ?: 0f
                        if (Math.abs(v) > ViewConfiguration.get(context).scaledMinimumFlingVelocity) startFling(-v.toDouble() / cellH)
                    }
                    3 -> if (!movedSinceLongPress) {
                        val p = cellAt(event.x, event.y)
                        if (p != null) host?.onContextMenu(p.x, p.y, event.rawX, event.rawY)
                    }
                }
                mode = 0
                velocity?.recycle()
                velocity = null
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                touching = false
                scrollbarDrag = false
                mode = 0
                invalidate()
            }
        }
        return true
    }

    private fun handleTap(x: Float, y: Float) {
        val p = cellAt(x, y) ?: return
        val now = SystemClock.uptimeMillis()
        val e = concrete
        val doubleTap = now - lastTapTime < ViewConfiguration.getDoubleTapTimeout() && Math.abs(x - lastTapX) < slop * 3 && Math.abs(y - lastTapY) < slop * 3
        lastTapTime = if (doubleTap) 0L else now
        lastTapX = x
        lastTapY = y
        if (doubleTap) {
            Engine.post { vp.expandSelection(p.x, p.y) }
            return
        }
        if (e == null) return
        if (x < gutterW) {
            val width = frame?.cols ?: 1
            Engine.post {
                e.selectionStart = Point(0, p.y)
                e.selectionEnd = Point(width - 1, p.y)
            }
        } else {
            Engine.post { e.selectionStart = p }
        }
        host?.onEditRequest()
    }

    private fun startFling(rowsPerSecond: Double) {
        var speed = rowsPerSecond
        flinging = true
        var last = SystemClock.uptimeMillis()
        val step = object : Runnable {
            override fun run() {
                if (!flinging) return
                val now = SystemClock.uptimeMillis()
                val dt = (now - last) / 1000.0
                last = now
                scrollBy(speed * dt)
                speed *= Math.exp(-dt * 3.2)
                val f = frame
                val atEdge = f != null && (scrollTarget <= f.minScroll || scrollTarget >= f.maxScroll)
                if (Math.abs(speed) < 0.6 || atEdge) {
                    flinging = false
                    invalidate()
                } else {
                    postOnAnimation(this)
                }
            }
        }
        postOnAnimation(step)
    }

    // ---------------------------------------------------------------- keyboard

    fun sendText(text: String) {
        val e = editable ?: return
        Engine.post { e.edit(text) }
    }

    fun sendKey(key: ConsoleKey) {
        val e = editable ?: return
        Engine.post { e.edit(key) }
    }

    fun move(direction: Direction, extend: Boolean) {
        val vpc = vp as? ViewPort ?: return
        Engine.post {
            val command = if (extend) vpc.moveSelectionEnd else vpc.moveSelectionStart
            if (command.canExecute(direction)) command.execute(direction)
        }
    }

    fun scrollCommand(direction: Direction) {
        Engine.post {
            val command = vp.scroll
            if (command.canExecute(direction)) command.execute(direction)
        }
    }

    override fun onCheckIsTextEditor(): Boolean = editable != null

    override fun onCreateInputConnection(outAttrs: EditorInfo): InputConnection? {
        if (editable == null) return null
        outAttrs.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        outAttrs.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN or EditorInfo.IME_ACTION_NONE
        return object : BaseInputConnection(this, false) {
            override fun commitText(text: CharSequence?, newCursorPosition: Int): Boolean {
                if (!text.isNullOrEmpty()) sendText(text.toString())
                return true
            }

            override fun setComposingText(text: CharSequence?, newCursorPosition: Int): Boolean {
                if (!text.isNullOrEmpty()) sendText(text.toString())
                return true
            }

            override fun deleteSurroundingText(beforeLength: Int, afterLength: Int): Boolean {
                if (beforeLength > 0) sendKey(ConsoleKey.Backspace)
                if (afterLength > 0) sendKey(ConsoleKey.Delete)
                return true
            }

            override fun sendKeyEvent(event: KeyEvent): Boolean {
                if (event.action == KeyEvent.ACTION_DOWN) this@HexView.handleKey(event.keyCode, event)
                return true
            }
        }
    }

    private fun handleKey(keyCode: Int, event: KeyEvent): Boolean {
        val shift = event.isShiftPressed
        val ctrl = event.isCtrlPressed
        when (keyCode) {
            KeyEvent.KEYCODE_DEL -> sendKey(ConsoleKey.Backspace)
            KeyEvent.KEYCODE_FORWARD_DEL -> sendKey(ConsoleKey.Delete)
            KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> sendKey(ConsoleKey.Enter)
            KeyEvent.KEYCODE_ESCAPE -> sendKey(ConsoleKey.Escape)
            KeyEvent.KEYCODE_TAB -> sendKey(ConsoleKey.Tab)
            KeyEvent.KEYCODE_DPAD_UP -> if (ctrl) scrollCommand(Direction.Up) else move(Direction.Up, shift)
            KeyEvent.KEYCODE_DPAD_DOWN -> if (ctrl) scrollCommand(Direction.Down) else move(Direction.Down, shift)
            KeyEvent.KEYCODE_DPAD_LEFT -> if (ctrl) scrollCommand(Direction.Left) else move(Direction.Left, shift)
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (ctrl) scrollCommand(Direction.Right) else move(Direction.Right, shift)
            KeyEvent.KEYCODE_PAGE_UP -> move(Direction.PageUp, shift)
            KeyEvent.KEYCODE_PAGE_DOWN -> move(Direction.PageDown, shift)
            KeyEvent.KEYCODE_MOVE_HOME -> move(Direction.Home, shift)
            KeyEvent.KEYCODE_MOVE_END -> move(Direction.End, shift)
            else -> {
                if (ctrl) return false
                val unicode = event.unicodeChar
                if (unicode > 0 && unicode != 10 && unicode != 13) {
                    sendText(String(Character.toChars(unicode)))
                } else {
                    return false
                }
            }
        }
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean = handleKey(keyCode, event) || super.onKeyDown(keyCode, event)

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        val e = editable ?: return
        Engine.post { e.isFocused = gainFocus }
    }
}
