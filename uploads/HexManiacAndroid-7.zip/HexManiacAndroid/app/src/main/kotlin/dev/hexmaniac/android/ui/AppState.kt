package dev.hexmaniac.android.ui

import dev.hexmaniac.android.host.AndroidFileSystem
import dev.hexmaniac.core.viewmodels.EditorViewModel

/** Process wide handles shared by the views. The app is a single activity, so a plain object is enough. */
object AppState {
    lateinit var fileSystem: AndroidFileSystem
    fun hasFileSystem(): Boolean = ::fileSystem.isInitialized
    @Volatile var editor: EditorViewModel? = null
}
