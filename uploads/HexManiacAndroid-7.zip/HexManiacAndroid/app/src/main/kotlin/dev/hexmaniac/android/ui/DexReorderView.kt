package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.viewmodels.DexReorderTab
import dev.hexmaniac.core.viewmodels.SortablePokemon

private class DexTile(val bitmap: Bitmap?, val name: String, val selected: Boolean, val filtered: Boolean)

private class DexFrame(val tiles: List<DexTile>, val scale: Double, val status: String)

/** A scroll view that reports pinch gestures as "make the sprites twice as big / half as big" steps. */
private class PinchScroll(context: Context, private val onStep: (Boolean) -> Unit) : ScrollView(context) {
    private var accumulated = 1f
    private val detector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            accumulated = 1f
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            accumulated *= detector.scaleFactor
            if (accumulated > 1.5f) {
                accumulated = 1f
                onStep(true)
            } else if (accumulated < 0.66f) {
                accumulated = 1f
                onStep(false)
            }
            return true
        }
    })

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }
}

/**
 * The grid of sprites. Tap selects, long-press picks the selection up and dragging moves it (the other sprites make
 * room), exactly like dragging with the mouse in the desktop app.
 */
private class DexGrid(context: Context, private val tab: DexReorderTab, private val scroll: ScrollView, binder: Binder) : View(context) {
    private var frame: DexFrame? = null
    var onFrame: ((DexFrame) -> Unit)? = null
    var rangeMode = false

    private val dirty = java.util.concurrent.atomic.AtomicBoolean(false)
    private val cache = HashMap<SortablePokemon, Bitmap?>()
    private val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false }
    private val fill = Paint()
    private val border = Paint().apply { style = Paint.Style.STROKE; strokeWidth = Ui.dpf(2f) }
    private val thin = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 1f }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)

    private var mode = 0 // 0 idle, 1 dragging the selection
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var lastTile = 0
    private var fingerX = 0f
    private var fingerViewportY = 0f
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val longPress = ViewConfiguration.getLongPressTimeout().toLong()
    private val longPressRunnable = Runnable { beginDrag() }
    private val autoScroll = object : Runnable {
        override fun run() {
            if (mode != 1) return
            val edge = Ui.dp(56)
            val step = Ui.dp(10)
            val delta = when {
                fingerViewportY < edge -> -step
                fingerViewportY > scroll.height - edge -> step
                else -> 0
            }
            if (delta != 0) {
                val before = scroll.scrollY
                scroll.scrollBy(0, delta)
                if (scroll.scrollY != before) dragTo(fingerX, fingerViewportY + scroll.scrollY)
            }
            postDelayed(this, 16)
        }
    }

    init {
        setWillNotDraw(false)
        frame = compute()
        binder.onEngineEvent {
            val onProperty: (Any?, dev.hexmaniac.core.system.PropertyChangedEventArgs) -> Unit = { _, _ -> requestFrame() }
            val onCollection: (Any?, dev.hexmaniac.core.system.NotifyCollectionChangedEventArgs) -> Unit = { _, _ -> requestFrame() }
            tab.propertyChanged += onProperty
            tab.elements.collectionChanged += onCollection
            val undo: () -> Unit = {
                tab.propertyChanged -= onProperty
                tab.elements.collectionChanged -= onCollection
            }
            undo
        }
    }

    fun currentStatus(): String = frame?.status ?: ""

    fun requestFrame() {
        if (dirty.compareAndSet(false, true)) {
            Engine.post {
                try {
                    val result = compute()
                    Engine.ui {
                        val sizeChanged = frame?.tiles?.size != result.tiles.size || frame?.scale != result.scale
                        frame = result
                        if (sizeChanged) requestLayout()
                        invalidate()
                        onFrame?.invoke(result)
                    }
                } finally {
                    dirty.set(false)
                }
            }
        }
    }

    /** Needs the engine lock. */
    private fun compute(): DexFrame {
        val elements = ArrayList<SortablePokemon>(tab.elements)
        val tiles = ArrayList<DexTile>(elements.size)
        val live = HashSet<SortablePokemon>()
        for (element in elements) {
            live.add(element)
            var bitmap = cache[element]
            if (bitmap == null) {
                bitmap = render(element)
                cache[element] = bitmap
            }
            tiles.add(DexTile(bitmap, element.name, element.selected, element.isFilteredOut))
        }
        cache.keys.retainAll(live)
        val first = Math.min(tab.selectionStart, tab.selectionEnd)
        val last = Math.max(tab.selectionStart, tab.selectionEnd)
        val status = when {
            elements.isEmpty() -> ""
            first == last && first in elements.indices -> "#" + (first + 1) + "  " + elements[first].name
            else -> "#" + (first + 1) + " - #" + (last + 1) + "  (" + (last - first + 1) + " selected)"
        }
        return DexFrame(tiles, tab.spriteScale, status)
    }

    private fun render(element: SortablePokemon): Bitmap? {
        val w = element.pixelWidth
        val h = element.pixelHeight
        val data = element.pixelData
        if (w <= 0 || h <= 0 || data.size < w * h) return null
        val transparent = element.transparent.toInt()
        val colors = IntArray(w * h)
        for (i in colors.indices) {
            val c = data[i].toInt()
            colors[i] = if (c == transparent) 0 else gbaToArgb(c)
        }
        return Bitmap.createBitmap(colors, w, h, Bitmap.Config.ARGB_8888)
    }

    // ---------------------------------------------------------------------------------------------- layout and drawing

    private fun cellSize(): Int {
        val scale = frame?.scale ?: 1.0
        return Math.max(Ui.dp(16), (64 * scale * Ui.density).toInt() + Ui.dp(2))
    }

    private fun perRow(): Int = Math.max(1, width / cellSize())

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        var w = MeasureSpec.getSize(widthSpec)
        if (w <= 0) w = Ui.dp(320)
        val cell = cellSize()
        val perRow = Math.max(1, w / cell)
        val count = frame?.tiles?.size ?: 0
        val rows = (count + perRow - 1) / perRow
        setMeasuredDimension(w, rows * cell)
    }

    override fun onDraw(canvas: Canvas) {
        val f = frame ?: return
        val cell = cellSize()
        val perRow = perRow()
        val clip = canvas.clipBounds
        val firstRow = Math.max(0, clip.top / cell)
        val lastRow = Math.min((f.tiles.size - 1) / perRow, clip.bottom / cell)
        val inset = Ui.dp(1)
        val showIndex = cell >= Ui.dp(40)
        val showName = cell >= Ui.dp(60)
        text.textSize = Ui.dpf(9f)
        text.setShadowLayer(2f, 0f, 0f, Palette.background)
        thin.color = Palette.alpha(Palette.secondary, 45)
        for (row in firstRow..lastRow) {
            for (col in 0 until perRow) {
                val i = row * perRow + col
                if (i >= f.tiles.size) break
                val tile = f.tiles[i]
                val x = col * cell
                val y = row * cell
                val dest = Rect(x + inset, y + inset, x + cell - inset, y + cell - inset)
                if (tile.selected) {
                    fill.color = Palette.alpha(Palette.accent, 40)
                    canvas.drawRect(dest, fill)
                }
                canvas.drawRect(dest, thin)
                val alpha = if (tile.filtered) 77 else 255
                paint.alpha = alpha
                val bitmap = tile.bitmap
                if (bitmap != null) canvas.drawBitmap(bitmap, null, dest, paint)
                text.alpha = alpha
                if (showIndex) {
                    text.color = Palette.secondary
                    text.alpha = alpha
                    canvas.drawText((i + 1).toString(), dest.left + Ui.dpf(3f), dest.top + text.textSize + Ui.dpf(1f), text)
                }
                if (showName && tile.name.isNotEmpty()) {
                    text.color = Palette.primary
                    text.alpha = alpha
                    val count = text.breakText(tile.name, true, (dest.width() - Ui.dp(4)).toFloat(), null)
                    canvas.drawText(tile.name, 0, count, dest.left + Ui.dpf(3f), dest.bottom - Ui.dpf(3f), text)
                }
                if (tile.selected) {
                    border.color = Palette.accent
                    canvas.drawRect(
                        dest.left + border.strokeWidth / 2f, dest.top + border.strokeWidth / 2f,
                        dest.right - border.strokeWidth / 2f, dest.bottom - border.strokeWidth / 2f, border,
                    )
                }
            }
        }
    }

    // ---------------------------------------------------------------------------------------------- touch

    private fun tileAt(x: Float, y: Float): Int {
        val count = frame?.tiles?.size ?: 0
        if (count == 0) return 0
        val cell = cellSize()
        val perRow = perRow()
        val col = Math.min(perRow - 1, Math.max(0, (x / cell).toInt()))
        val row = Math.max(0, (y / cell).toInt())
        return Math.min(count - 1, Math.max(0, row * perRow + col))
    }

    private fun beginDrag() {
        if (mode != 0 || moved) return
        mode = 1
        parent?.requestDisallowInterceptTouchEvent(true)
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        val index = lastTile
        Engine.post { tab.selectionStart = index }
        postDelayed(autoScroll, 16)
    }

    private fun dragTo(x: Float, y: Float) {
        val tile = tileAt(x, y)
        if (tile == lastTile) return
        val old = lastTile
        lastTile = tile
        Engine.post { tab.handleMove(old, tile) }
    }

    private fun endDrag() {
        if (mode != 1) return
        mode = 0
        removeCallbacks(autoScroll)
        Engine.post { tab.completeCurrentInteraction() }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                moved = false
                mode = 0
                lastTile = tileAt(event.x, event.y)
                fingerX = event.x
                fingerViewportY = event.y - scroll.scrollY
                postDelayed(longPressRunnable, longPress)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                fingerX = event.x
                fingerViewportY = event.y - scroll.scrollY
                if (mode == 0) {
                    if (Math.abs(event.x - downX) > slop || Math.abs(event.y - downY) > slop) {
                        moved = true
                        removeCallbacks(longPressRunnable)
                    }
                } else {
                    dragTo(event.x, event.y)
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPressRunnable)
                if (mode == 1) {
                    endDrag()
                } else if (!moved) {
                    tap(tileAt(event.x, event.y))
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                endDrag()
            }
        }
        return true
    }

    private fun tap(index: Int) {
        val extend = rangeMode
        Engine.post {
            if (extend) {
                tab.selectionEnd = index
            } else {
                selectSingle(tab, index)
            }
        }
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(longPressRunnable)
        removeCallbacks(autoScroll)
        super.onDetachedFromWindow()
    }

    companion object {
        /** The view-model ignores a new selection start inside the current selection (so a drag can begin there). A tap collapses it. */
        fun selectSingle(tab: DexReorderTab, index: Int) {
            val first = Math.min(tab.selectionStart, tab.selectionEnd)
            val last = Math.max(tab.selectionStart, tab.selectionEnd)
            if (first != last && index in first..last) {
                val outside = if (first > 0) 0 else if (last < tab.elements.size - 1) tab.elements.size - 1 else -1
                if (outside >= 0) tab.selectionStart = outside
            }
            tab.selectionStart = index
        }
    }
}

/** The "Adjust Dex Order" tab: a filter box above a wrapping grid of sprites that can be dragged into a new order. */
class DexReorderView(context: Context, private val tab: DexReorderTab, binder: Binder) : LinearLayout(context) {
    private val grid: DexGrid
    private val status: TextView = context.label("", 13f, Palette.primary)

    init {
        orientation = VERTICAL
        setBackgroundColor(Palette.background)

        val filterRow = context.hbox()
        filterRow.setPadding(Ui.dp(8), Ui.dp(6), Ui.dp(8), Ui.dp(2))
        filterRow.addView(context.label("Filter Name/Type:", 14f, Palette.primary))
        val filter = context.textBox(hint = "name or type")
        binder.bindText(filter, tab, "filter", { tab.filter }, { tab.filter = it })
        filterRow.addView(filter, lp(0, WRAP, 1f).also { it.leftMargin = Ui.dp(8) })
        addView(filterRow, lp(MATCH, WRAP))

        val scroll = PinchScroll(context) { enlarge -> Engine.post { tab.spriteScale = tab.spriteScale * (if (enlarge) 2.0 else 0.5) } }
        grid = DexGrid(context, tab, scroll, binder)
        scroll.addView(grid, LayoutParams(MATCH, WRAP))
        scroll.isVerticalScrollBarEnabled = true

        val buttons = FlowLayout(context)
        buttons.hGap = Ui.dp(6)
        buttons.vGap = Ui.dp(6)
        buttons.setPadding(Ui.dp(8), Ui.dp(4), Ui.dp(8), Ui.dp(4))
        val range = CheckRow(context, "Range", false)
        range.onChange = { grid.rangeMode = it }
        buttons.addView(range, android.view.ViewGroup.MarginLayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(6) })
        for ((label, delta) in listOf("-10" to -10, "-1" to -1, "+1" to 1, "+10" to 10)) {
            buttons.addView(context.angleButton(label) { moveBy(delta) }, android.view.ViewGroup.MarginLayoutParams(WRAP, WRAP))
        }
        buttons.addView(context.angleButton("Move to...") { askMoveTo() }, android.view.ViewGroup.MarginLayoutParams(WRAP, WRAP))
        buttons.addView(context.angleButton("-") { zoom(false) }, android.view.ViewGroup.MarginLayoutParams(WRAP, WRAP))
        buttons.addView(context.angleButton("+") { zoom(true) }, android.view.ViewGroup.MarginLayoutParams(WRAP, WRAP))
        addView(buttons, lp(MATCH, WRAP))

        status.setPadding(Ui.dp(10), Ui.dp(2), Ui.dp(10), Ui.dp(4))
        addView(status, lp(MATCH, WRAP))
        addView(scroll, lp(MATCH, 0, 1f))

        grid.onFrame = { status.text = it.status }
        status.text = grid.currentStatus()
    }

    private fun zoom(enlarge: Boolean) {
        Engine.post { tab.spriteScale = tab.spriteScale * (if (enlarge) 2.0 else 0.5) }
    }

    private fun moveBy(delta: Int) {
        Engine.post {
            val first = Math.min(tab.selectionStart, tab.selectionEnd)
            val moved = tab.handleMove(first, first + delta)
            if (moved.isNotEmpty()) tab.completeCurrentInteraction()
        }
    }

    private fun askMoveTo() {
        Dialogs.text(context, "Move to position", "Move the selected sprites so the first one lands on this dex number:", "") { result ->
            val target = result?.trim()?.toIntOrNull() ?: return@text
            Engine.post {
                val first = Math.min(tab.selectionStart, tab.selectionEnd)
                val moved = tab.handleMove(first, target - 1)
                if (moved.isNotEmpty()) tab.completeCurrentInteraction()
            }
        }
    }
}
