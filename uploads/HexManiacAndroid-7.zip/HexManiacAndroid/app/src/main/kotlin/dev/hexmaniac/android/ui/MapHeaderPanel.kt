package dev.hexmaniac.android.ui

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.system.ICommand
import dev.hexmaniac.core.viewmodels.map.BlockMapViewModel
import dev.hexmaniac.core.viewmodels.map.MapEditorViewModel
import dev.hexmaniac.core.viewmodels.map.MapRepointer
import dev.hexmaniac.core.viewmodels.map.MapScriptViewModel

/** The "Map Header" panel of the map editor. */
internal class HeaderPanel(context: Context, private val tab: MapEditorViewModel, private val binder: Binder) : LinearLayout(context) {
    init {
        orientation = VERTICAL
        addView(PanelUi.titleBar(context, "Map Header") { Engine.post { tab.cancel() } }, lp(MATCH, WRAP))
        val content = MapBound(context, tab, binder) { map, b -> buildFor(map, b) }
        addView(context.vscroll(content), lp(MATCH, 0, 1f))
    }

    private fun buildFor(map: BlockMapViewModel, b: Binder): View {
        val header = map.header
        val box = context.vbox()
        box.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(18))
        val form = MapForm(context, b, box)

        form.action("View Table in Data Tab") { map.gotoData() }
        form.button("Export Image...") {
            Dialogs.pick(
                context, "Export Image",
                listOf(
                    "This Map: Hide Events", "This Map: Show Objects", "This Map: Show All Events",
                    "All Connected Maps: Hide Events", "All Connected Maps: Show Objects", "All Connected Maps: Show All Events",
                ),
                -1,
            ) { index ->
                Engine.post {
                    when (index) {
                        0 -> tab.exportMapImageNoEvents()
                        1 -> tab.exportMapImageObjectEvents()
                        2 -> tab.exportMapImageAllEvents()
                        3 -> tab.exportAllMapImagesNoEvents()
                        4 -> tab.exportAllMapImagesObjectEvents()
                        else -> tab.exportAllMapImagesAllEvents()
                    }
                }
            }
        }

        // blocksets
        form.combo(
            "Primary Blockset:", header, { header.primaryOptions.map { it.addressText } }, { header.primaryIndex }, { header.primaryIndex = it }, header.primaryOptions,
        )
        form.image(header, 1f, { header.primaryOptions.getOrNull(header.primaryIndex)?.render }).maxWidthDp = 280
        form.combo(
            "Secondary Blockset:", header, { header.secondaryOptions.map { it.addressText } }, { header.secondaryIndex }, { header.secondaryIndex = it }, header.secondaryOptions,
        )
        form.image(header, 1f, { header.secondaryOptions.getOrNull(header.secondaryIndex)?.render }).maxWidthDp = 280

        form.button("Data Operations...") { readSoon { DataOperationsDialog.show(context, map.mapRepointer) } }

        // layouts shared between maps
        form.group(map, { map.blockMapIsShared }) { g ->
            val note = g.dynamicNote(map, Palette.data2) { "This layout is used by " + map.blockMapShareCount + " maps." }
            note.gravity = Gravity.CENTER
            val flow = FlowLayout(context)
            flow.hGap = Ui.dp(4)
            flow.vGap = Ui.dp(4)
            flow.setPadding(Ui.dp(6), Ui.dp(2), Ui.dp(6), Ui.dp(6))
            g.box.addView(flow, lp(MATCH, WRAP))
            b.watchCollection(map.blockMapUses) {
                flow.removeAllViews()
                for (use in map.blockMapUses.toList()) {
                    val button = context.angleButton(use.group.toString() + "-" + use.map, AngleDrawable.Direction.None, size = 12f) { Engine.post { use.gotoMap() } }
                    button.setOnLongClickListener { Toast.makeText(context, use.name, Toast.LENGTH_SHORT).show(); true }
                    flow.addView(button, android.view.ViewGroup.MarginLayoutParams(WRAP, WRAP))
                }
            }
        }

        // dive / emerge connection
        val surf = map.surfConnection
        form.group(surf, { surf.canCreate }) { g ->
            g.button("New Z-Connection...") {
                Dialogs.pick(context, "New Z-Connection", listOf("Dive to Existing Map", "Emerge to Existing Map", "Dive to New Map", "Emerge to New Map"), -1) { index ->
                    Engine.post {
                        when (index) {
                            0 -> surf.diveExisting()
                            1 -> surf.emergeExisting()
                            2 -> surf.diveNew()
                            else -> surf.emergeNew()
                        }
                    }
                }
            }
        }
        form.group(surf, { surf.canWarp }) { g ->
            val follow = g.action("Dive", surf) { surf.followConnection() }
            b.watch(surf) { follow.text = if (surf.canEmerge) "Emerge" else "Dive" }
            g.action("Delete Connection", surf, { surf.canRemoveConnection }) { surf.removeConnection() }
        }

        // the header fields
        form.section("Header")
        form.combo(
            "Map Name:", map, { map.availableNames.toList() }, { map.selectedNameIndex }, { map.selectedNameIndex = it }, map.availableNames,
            form.miniButton("\u2192") { tab.gotoMapNames() },
        )
        form.combo("Music:", header, { header.musicOptions.toList() }, { header.music }, { header.music = it }, header.musicOptions, null, header) { header.hasMusicOptions }
        form.combo("Cave:", header, { header.caveOptions.toList() }, { header.cave }, { header.cave = it }, header.caveOptions)
        form.combo("Weather:", header, { header.weatherOptions.toList() }, { header.weather }, { header.weather = it }, header.weatherOptions)
        form.combo("MapType:", header, { header.mapTypeOptions.toList() }, { header.mapType }, { header.mapType = it }, header.mapTypeOptions, null, header) { header.hasMapTypeOptions }
        form.check("Allow Running", header, { header.allowRunning }, { header.allowRunning = it })
        form.check("Show Map Name", header, { header.showMapName }, { header.showMapName = it })
        form.check("Allow Biking", header, { header.allowBiking }, { header.allowBiking = it }, header) { header.showAllowBikingField }
        form.check("Allow Escaping", header, { header.allowEscaping }, { header.allowEscaping = it })
        form.combo("BattleType:", header, { header.battleOptions.toList() }, { header.battleType }, { header.battleType = it }, header.battleOptions)
        form.number("FloorNum:", header, { header.floorNum }, { header.floorNum = it }, null, header) { header.showFloorNumField }

        // map scripts
        form.section("Map Scripts")
        val scripts = map.mapScriptCollection
        val holder = context.vbox()
        box.addView(holder, lp(MATCH, WRAP))
        var scriptsBinder: Binder? = null
        b.watchCollection(scripts.scripts) {
            scriptsBinder?.dispose()
            val own = b.child()
            scriptsBinder = own
            holder.removeAllViews()
            for (script in scripts.scripts.toList()) addScript(holder, own, script)
        }
        form.action("Add New Script", scripts, null, { scripts.allowAddMoreScripts }) { scripts.addScript() }
        return box
    }

    private fun addScript(holder: LinearLayout, own: Binder, script: MapScriptViewModel) {
        val item = context.vbox()
        item.setPadding(0, Ui.dp(2), 0, Ui.dp(6))
        holder.addView(item, lp(MATCH, WRAP))
        val f = MapForm(context, own, item)
        val delete = f.miniButton("\u00D7") { script.delete() }
        f.combo(
            "Script:", script, { script.scriptOptions.map { it.option } }, { script.scriptTypeIndex }, { script.scriptTypeIndex = it }, script.scriptOptions, delete,
            script, { script.showMapScript },
        )
        f.dynamicNote(script) { script.scriptOptions.getOrNull(script.scriptTypeIndex)?.shortDescription }
        f.text("Address:", script, { script.address }, { script.address = it }, f.miniButton("\u2192") { script.goto() }, true, script) { script.showMapScript }
        f.group(script, { script.hasSubScripts }) { g ->
            val subHolder = context.vbox()
            subHolder.setPadding(Ui.dp(14), 0, 0, 0)
            g.box.addView(subHolder, lp(MATCH, WRAP))
            var subBinder: Binder? = null
            own.watchCollection(script.subScripts) {
                subBinder?.dispose()
                val inner = own.child()
                subBinder = inner
                subHolder.removeAllViews()
                for (sub in script.subScripts.toList()) {
                    val line = context.vbox()
                    line.setPadding(0, Ui.dp(2), 0, Ui.dp(4))
                    subHolder.addView(line, lp(MATCH, WRAP))
                    val s = MapForm(context, inner, line)
                    val ends = context.hbox()
                    ends.addView(s.miniButton("\u2192") { sub.goto() })
                    ends.addView(s.miniButton("\u00D7") { sub.delete() }.also { (it.layoutParams as? LinearLayout.LayoutParams)?.leftMargin = Ui.dp(2) })
                    s.text("Address:", sub, { sub.address }, { sub.address = it }, ends, true)
                    s.text("Var:", sub, { sub.variable }, { sub.variable = it }, s.miniButton("+", sub, { sub.canGenerateNewVar }) { sub.generateNewVar() }, true)
                    s.text("Value:", sub, { sub.value }, { sub.value = it }, null, true)
                }
            }
            g.action("Add Table Script") { script.addSubScript() }
        }
        f.note("Further scripts truncated for performance. View the table data to see the remaining scripts.", script) { script.moreScriptsTruncated }
    }
}

/** The repoint / expand / import / export tools of a map layout. */
internal object DataOperationsDialog {
    /** Engine lock held. */
    fun show(context: Context, repointer: MapRepointer) {
        val own = Binder()
        val root = context.vbox()
        root.addView(Dialogs.title(context, "Data Operations"))
        val body = context.vbox()
        body.setPadding(Ui.dp(10), 0, Ui.dp(10), Ui.dp(12))
        root.addView(context.vscroll(body), lp(MATCH, Ui.dp(460)))
        val hint = context.label("Tap a button to run it. Long-press a button to read what it does.", 12f, Palette.secondary)
        hint.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(6))
        body.addView(hint, lp(MATCH, WRAP))

        fun tip(button: TextView, text: (() -> String)?) {
            if (text == null) return
            button.setOnLongClickListener {
                val message = Engine.read { text() }
                if (message.isNotBlank()) Toast.makeText(context, message, Toast.LENGTH_LONG).show()
                true
            }
        }

        fun command(label: String, command: ICommand, text: (() -> String)?): TextView {
            val button = context.angleButton(label, AngleDrawable.Direction.None, size = 12f) { command.fire() }
            own.watchCommand(command) {
                val on = command.canExecute(null)
                button.isEnabled = on
                button.alpha = if (on) 1f else 0.4f
            }
            tip(button, text)
            return button
        }

        fun method(label: String, run: () -> Unit): TextView =
            context.angleButton(label, AngleDrawable.Direction.None, size = 12f) { Engine.post { run() } }

        fun heading(text: String) {
            val view = context.label(text, 13f, Palette.accent, bold = true)
            view.setPadding(Ui.dp(4), Ui.dp(12), Ui.dp(4), Ui.dp(4))
            body.addView(view, lp(MATCH, WRAP))
        }

        fun row(name: String, vararg buttons: TextView) {
            val line = context.hbox()
            line.setPadding(0, Ui.dp(2), 0, Ui.dp(2))
            val label = context.label(name, 13f, Palette.primary)
            line.addView(label, lp(Ui.dp(84), WRAP))
            val flow = FlowLayout(context)
            flow.hGap = Ui.dp(4)
            flow.vGap = Ui.dp(4)
            for (button in buttons) flow.addView(button, android.view.ViewGroup.MarginLayoutParams(WRAP, WRAP))
            line.addView(flow, lp(0, WRAP, 1f))
            body.addView(line, lp(MATCH, WRAP))
        }

        heading("Layout")
        row("Layout", command("Repoint Layout", repointer.repointLayout) { repointer.repointLayoutText })
        row("Border", command("Repoint", repointer.repointBorderBlock) { repointer.repointBorderText }, method("Import") { repointer.importBorderBlock() }, method("Export") { repointer.exportBorderBlock() })
        row("Block Map", command("Repoint", repointer.repointBlockMap) { repointer.repointBlockMapText }, method("Import") { repointer.importBlockMap() }, method("Export") { repointer.exportBlockMap() })

        heading("Primary")
        row("Blockset", command("Repoint", repointer.repointPrimaryBlockset) { repointer.repointPrimaryBlocksetText })
        row(
            "Blocks", command("Repoint", repointer.repointPrimaryBlocks) { repointer.repointPrimaryBlocksText },
            command("Expand", repointer.expandPrimaryBlocks) { repointer.expandPrimaryBlocksText },
            method("Import") { repointer.importPrimaryBlocks() }, method("Export") { repointer.exportPrimaryBlocks() },
        )
        row(
            "Tileset", command("Repoint", repointer.repointPrimaryTileset) { repointer.repointPrimaryTilesetText },
            command("Expand", repointer.expandPrimaryTileset) { repointer.expandPrimaryTilesetText },
            method("Import") { repointer.importPrimaryTileset() }, method("Export") { repointer.exportPrimaryTileset() },
        )
        row(
            "Palette", command("Repoint", repointer.repointPrimaryPalette) { repointer.repointPrimaryPalettesText },
            command("Expand", repointer.expandPrimaryPalette) { repointer.expandPrimaryPaletteText },
            method("Import") { repointer.importPrimaryPalette() }, method("Export") { repointer.exportPrimaryPalette() },
        )
        row("Animation", command("Create", repointer.createPrimaryTilesetAnimations) { repointer.createPrimaryTilesetAnimationsText })

        heading("Secondary")
        row("Blockset", command("Repoint", repointer.repointSecondaryBlockset) { repointer.repointSecondaryBlocksetText })
        row(
            "Blocks", command("Repoint", repointer.repointSecondaryBlocks) { repointer.repointSecondaryBlocksText },
            command("Expand", repointer.expandSecondaryBlocks) { repointer.expandSecondaryBlocksText },
            method("Import") { repointer.importSecondaryBlocks() }, method("Export") { repointer.exportSecondaryBlocks() },
        )
        row(
            "Tileset", command("Repoint", repointer.repointSecondaryTileset) { repointer.repointSecondaryTilesetText },
            command("Expand", repointer.expandSecondaryTileset) { repointer.expandSecondaryTilesetText },
            method("Import") { repointer.importSecondaryTileset() }, method("Export") { repointer.exportSecondaryTileset() },
        )
        row(
            "Palette", command("Repoint", repointer.repointSecondaryPalette) { repointer.repointSecondaryPalettesText },
            command("Expand", repointer.expandSecondaryPalette) { repointer.expandSecondaryPaletteText },
            method("Import") { repointer.importSecondaryPalette() }, method("Export") { repointer.exportSecondaryPalette() },
        )
        row("Animation", command("Create", repointer.createSecondaryTilesetAnimations) { repointer.createSecondaryTilesetAnimationsText })

        heading("Map")
        row("Duplicate", command("Duplicate Map", repointer.duplicateMap) { repointer.duplicateMapText })

        val actions = context.hbox()
        actions.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(10), Ui.dp(10))
        val dialog = Dialogs.create(context, root, 420, true)
        actions.addView(context.angleButton("Close", AngleDrawable.Direction.Out) { dialog.dismiss() })
        root.addView(actions, lp(MATCH, WRAP))
        dialog.setOnDismissListener { own.dispose() }
        dialog.show()
    }
}
