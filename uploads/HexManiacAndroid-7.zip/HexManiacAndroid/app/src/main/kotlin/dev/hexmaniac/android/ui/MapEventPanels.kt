package dev.hexmaniac.android.ui

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.system.INotifyPropertyChanged
import dev.hexmaniac.core.viewmodels.map.EventCycleDirection
import dev.hexmaniac.core.viewmodels.map.EventTemplate
import dev.hexmaniac.core.viewmodels.map.FlyEventViewModel
import dev.hexmaniac.core.viewmodels.map.IEventViewModel
import dev.hexmaniac.core.viewmodels.map.MapEditorViewModel
import dev.hexmaniac.core.viewmodels.map.ObjectEventViewModel
import dev.hexmaniac.core.viewmodels.map.ScriptEventViewModel
import dev.hexmaniac.core.viewmodels.map.SignpostEventViewModel
import dev.hexmaniac.core.viewmodels.map.TemplateType
import dev.hexmaniac.core.viewmodels.map.TrainerTeamViewModel
import dev.hexmaniac.core.viewmodels.map.WarpEventViewModel

/** The editors of the five kinds of map events (objects, warps, scripts, signposts, fly spots). */
internal object EventForms {
    fun build(context: Context, binder: Binder, ev: IEventViewModel): View {
        val box = context.vbox()
        box.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(12))
        val form = MapForm(context, binder, box)
        when (ev) {
            is ObjectEventViewModel -> objectForm(form, ev)
            is WarpEventViewModel -> warpForm(form, ev)
            is ScriptEventViewModel -> scriptForm(form, ev)
            is SignpostEventViewModel -> signpostForm(form, ev)
            is FlyEventViewModel -> form.text("(x, y):", ev, { ev.xy }, { ev.xy = it })
            else -> form.note("This kind of event has no editor.")
        }
        return box
    }

    private fun relabel(form: MapForm, edit: View, vm: INotifyPropertyChanged, name: () -> String) {
        val row = edit.parent as? LinearLayout ?: return
        val label = row.getChildAt(0) as? TextView ?: return
        form.binder.watch(vm) { label.text = name() }
    }

    private fun scriptRow(form: MapForm, ev: ObjectEventViewModel) {
        val edit = form.text(
            "Script Address:", ev, { ev.scriptAddressText }, { ev.scriptAddressText = it },
            form.gotoCreate(ev, { ev.canCreateScript }, { ev.gotoScript() }, { ev.createScript() }), true,
        )
        form.dynamicNote(ev, Palette.error) { if (ev.hasScriptAddressError) ev.scriptAddressError else null }
        edit.hint = "hex address"
    }

    private fun objectForm(f: MapForm, ev: ObjectEventViewModel) {
        f.number("ID:", ev, { ev.objectID }, { ev.objectID = it })
        f.check("Dynamic Graphics", ev, { ev.showGraphicsAsText }, { ev.showGraphicsAsText = it })
        f.group(ev, { ev.canAddDynamicGraphicsToTransitionScript }) { g ->
            g.action("Insert setvar gfx (adjusts the map transition script)") { ev.addDynamicGraphicsToTransitionScript() }
        }
        f.filtering("Graphics Group:", ev.dynamicOverworldGraphicsCategories, null, ev) { ev.hasGraphicsInTransitionScript }
        f.visualPicker("Graphics:", ev, { ev.options.toList() }, { ev.graphics }, { ev.graphics = it }, ev) { !ev.showGraphicsAsText }
        f.visualPicker(
            "Dynamic Graphics:", ev, { ev.dynamicOverworldOptions.toList() }, { ev.dynamicOverworldGraphicsSelectedIndex },
            { ev.dynamicOverworldGraphicsSelectedIndex = it }, ev,
        ) { ev.hasGraphicsInTransitionScript }
        f.text("Graphics:", ev, { ev.graphicsText }, { ev.graphicsText = it }, null, false, ev) { ev.showGraphicsAsText }
        f.check("Clone (a copy of an NPC on a neighboring map)", ev, { ev.kind }, { ev.kind = it }, ev) { ev.hasKind }
        f.text("(x, y):", ev, { ev.xy }, { ev.xy = it })
        relabel(f, f.number("Elevation:", ev, { ev.elevation }, { ev.elevation = it }), ev) { if (ev.kind) "Clone ID:" else "Elevation:" }
        f.filtering("Movement Type:", ev.facingOptions)
        f.text("Range:", ev, { ev.rangeXY }, { ev.rangeXY = it })
        relabel(f, f.number("Trainer Type:", ev, { ev.trainerType }, { ev.trainerType = it }), ev) { if (ev.kind) "Clone Map:" else "Trainer Type:" }
        relabel(f, f.number("Trainer Range:", ev, { ev.trainerRangeOrBerryID }, { ev.trainerRangeOrBerryID = it }), ev) {
            if (ev.kind) "Clone Bank:" else if (ev.trainerType == 0) "Berry ID:" else "Trainer Range:"
        }
        scriptRow(f, ev)
        f.text("Flag:", ev, { ev.flagText }, { ev.flagText = it }, f.miniButton("+", ev, { ev.canGenerateNewFlag }) { ev.generateNewFlag() }, true)
        f.number("Padding:", ev, { ev.padding }, { ev.padding = it })

        f.group(ev, { ev.showBerryContent }) { g ->
            g.section("Berry")
            g.dynamicNote(ev) { "Initial Berry: " + ev.berryText }
            g.action("Go to berry code") { ev.gotoBerryCode() }
        }
        f.group(ev, { ev.showTrainerContent }) { g ->
            g.section("Trainer")
            g.filtering("Trainer:", ev.trainerOptions)
            g.combo("Class:", ev, { ev.classOptions.toList() }, { ev.trainerClass }, { ev.trainerClass = it }, ev.classOptions)
            g.text("Name:", ev, { ev.trainerName }, { ev.trainerName = it })
            g.dynamicEditor("Before Battle:", ev) { ev.trainerBeforeTextEditor }
            g.dynamicEditor("When You Win:", ev) { ev.trainerWinTextEditor }
            g.dynamicEditor("After Battle:", ev) { ev.trainerAfterTextEditor }
            g.editor("Team:", ev.trainerContent)
            g.imageStrip(ev, ev.teamVisualizations, 1f)
            g.image(ev, 1f, { ev.trainerSprite })
            g.action("Edit trainer data in the table") { ev.openTrainerData.let { c -> if (c.canExecute(null)) c.execute(null) } }
        }
        f.group(ev, { ev.showRematchTrainerContent }) { g ->
            g.section("Rematch Trainer")
            g.note("(Rematch script logic and text must be edited with the script editor.)")
            g.action("Go to script") { ev.gotoScript() }
            g.action("Edit Rematches") { ev.gotoRematches() }
            g.action("Convert to Basic Trainer") { ev.replaceRematchScript() }
            teamList(g, ev)
        }
        f.group(ev, { ev.showItemContents }) { g ->
            g.section("Item")
            g.filtering("Item:", ev.itemOptions)
        }
        f.group(ev, { ev.showNpcText }) { g ->
            g.section("NPC")
            g.dynamicEditor("Text:", ev) { ev.npcTextEditor }
        }
        f.group(ev, { ev.showMartContents }) { g ->
            g.section("Mart")
            g.dynamicEditor("Greeting:", ev) { ev.martHelloEditor }
            g.multiline("Shop:", ev, { ev.martContent }, { ev.martContent = it })
            g.dynamicEditor("Goodbye:", ev) { ev.martGoodbyeEditor }
        }
        f.group(ev, { ev.showTutorContent }) { g ->
            g.section("Move Tutor")
            g.dynamicEditor("Info:", ev) { ev.tutorInfoText }
            g.dynamicEditor("Which Pokemon:", ev) { ev.tutorWhichPokemonText }
            g.filtering("Tutor Move:", ev.tutorOptions, ElementViews.jumpButton(f.context) { Engine.post { ev.gotoTutors() } })
            g.dynamicEditor("Success:", ev) { ev.tutorSucessText }
            g.dynamicEditor("Fail:", ev) { ev.tutorFailedText }
        }
        f.group(ev, { ev.showTradeContent }) { g ->
            g.section("Trade")
            g.dynamicEditor("Info:", ev) { ev.tradeInitialEditor }
            g.filtering("Trade:", ev.tradeOptions, ElementViews.jumpButton(f.context) { Engine.post { ev.gotoTrades() } })
            g.dynamicEditor("Cancel:", ev) { ev.tradeFailedEditor }
            g.dynamicEditor("Wrong Pokemon:", ev) { ev.tradeWrongSpeciesEditor }
            g.dynamicEditor("Success:", ev) { ev.tradeThanksEditor }
            g.dynamicEditor("After Trade:", ev) { ev.tradeSuccessEditor }
        }
        f.group(ev, { ev.showLegendaryContent }) { g ->
            g.section("Legendary Pokemon")
            g.filtering("Pokemon:", ev.pokemonOptions, ElementViews.jumpButton(f.context) { Engine.post { ev.gotoPokemon() } })
            g.number("Level:", ev, { ev.level }, { ev.level = it })
            g.filtering("Hold Item:", ev.holdItemOptions, ElementViews.jumpButton(f.context) { Engine.post { ev.gotoHoldItem() } })
            g.text("Capture Flag:", ev, { ev.legendaryFlagText }, { ev.legendaryFlagText = it }, null, true)
            g.group(ev, { ev.hasCryText }) { c -> c.dynamicEditor("Cry:", ev) { ev.cryEditor } }
            g.note("Use this to make the legendary reappear if you haven't captured it:")
            g.editor("Sample script:", ev.sampleLegendClearScript)
        }
        f.group(ev, { ev.showNoContent }) { g ->
            g.section("Script")
            g.group(ev, { ev.hasBasicFlag }) { b -> b.text("Flag:", ev, { ev.basicFlagText }, { ev.basicFlagText = it }, null, true) }
            g.group(ev, { ev.hasBasicItem }) { b -> b.filtering("Item:", ev.basicItem) }
            basicTexts(g, ev)
            g.action("Go to script") { ev.gotoScript() }
        }
    }

    private fun basicTexts(g: MapForm, ev: ObjectEventViewModel) {
        val holder = g.context.vbox()
        g.box.addView(holder, LinearLayout.LayoutParams(MATCH, WRAP))
        var child: Binder? = null
        g.binder.watchCollection(ev.basicText) {
            child?.dispose()
            val own = g.binder.child()
            child = own
            holder.removeAllViews()
            for (entry in ev.basicText.toList()) {
                val inner = g.context.vbox()
                holder.addView(inner, LinearLayout.LayoutParams(MATCH, WRAP))
                val sub = MapForm(g.context, own, inner)
                sub.dynamicNote(entry) { entry.pointerAddressText }
                sub.editor("Text:", entry.text)
            }
        }
    }

    private fun teamList(g: MapForm, ev: ObjectEventViewModel) {
        val holder = g.context.vbox()
        g.box.addView(holder, LinearLayout.LayoutParams(MATCH, WRAP))
        var child: Binder? = null
        g.binder.watchCollection(ev.trainerTeams) {
            child?.dispose()
            val own = g.binder.child()
            child = own
            holder.removeAllViews()
            for (team in ev.trainerTeams.toList()) teamView(MapForm(g.context, own, holder), team)
        }
    }

    private fun teamView(g: MapForm, team: TrainerTeamViewModel) {
        g.section("Trainer")
        g.dynamicNote(team, Palette.primary) { team.trainerIDText }
        g.editor("Team:", team.trainerContent)
        g.imageStrip(team, team.teamVisualizations, 1f)
        g.action("Refresh") { team.refresh() }
    }

    private fun warpForm(f: MapForm, ev: WarpEventViewModel) {
        f.text("(x, y):", ev, { ev.xy }, { ev.xy = it })
        f.number("Elevation:", ev, { ev.elevation }, { ev.elevation = it })
        f.text("Target (bank, map):", ev, { ev.bankMap }, { ev.bankMap = it }, f.miniButton("\u2192", ev, { ev.canGotoBankMap }) { ev.gotoBankMap() })
        f.dynamicNote(ev, Palette.primary) { ev.targetMapName }
        f.number("Target Warp:", ev, { ev.warpID }, { ev.warpID = it })
    }

    private fun scriptForm(f: MapForm, ev: ScriptEventViewModel) {
        f.text("(x, y):", ev, { ev.xy }, { ev.xy = it })
        f.number("Elevation:", ev, { ev.elevation }, { ev.elevation = it })
        f.text("Trigger:", ev, { ev.triggerHex }, { ev.triggerHex = it }, f.miniButton("+", ev, { ev.canGenerateNewTrigger }) { ev.generateNewTrigger() }, true)
        f.number("Index:", ev, { ev.index }, { ev.index = it })
        f.text(
            "Script Address:", ev, { ev.scriptAddressText }, { ev.scriptAddressText = it },
            f.gotoCreate(ev, { ev.canCreateScript }, { ev.gotoScript() }, { ev.createScript() }), true,
        )
        f.dynamicNote(ev, Palette.error) { if (ev.hasScriptAddressError) ev.scriptAddressError else null }
    }

    private fun signpostForm(f: MapForm, ev: SignpostEventViewModel) {
        f.text("(x, y):", ev, { ev.xy }, { ev.xy = it })
        f.number("Elevation:", ev, { ev.elevation }, { ev.elevation = it })
        f.combo("Kind:", ev, { ev.kindOptions.toList() }, { ev.kind }, { ev.kind = it }, ev.kindOptions)
        f.text("Secret Base ID:", ev, { ev.argText }, { ev.argText = it }, null, true, ev) { ev.showArg }
        f.text(
            "Script:", ev, { ev.pointerText }, { ev.pointerText = it },
            f.gotoCreate(ev, { ev.canCreateScript }, { ev.gotoScript() }, { ev.createScript() }), true, ev,
        ) { ev.showPointer }
        f.multiline("Text", ev, { ev.signpostText }, { ev.signpostText = it }, ev) { ev.showSignpostText }
        f.combo("Item:", ev, { ev.itemOptions.toList() }, { ev.itemID }, { ev.itemID = it }, ev.itemOptions, null, ev) { ev.showHiddenItemProperties }
        f.number(
            "Hidden Item ID:", ev, { ev.hiddenItemID }, { ev.hiddenItemID = it },
            f.miniButton("+", ev, { ev.canGenerateNewHiddenItemID }) { ev.generateNewHiddenItemID() }, ev,
        ) { ev.showHiddenItemProperties }
        f.number("Quantity:", ev, { ev.quantity }, { ev.quantity = it }, null, ev) { ev.showHiddenItemProperties }
        f.check("Is Beneath Player", ev, { ev.isUnderFoot }, { ev.isUnderFoot = it }, ev) { ev.showHiddenItemProperties }
        f.dynamicNote(ev, Palette.error) { if (ev.hasScriptAddressError) ev.scriptAddressError else null }
    }
}

/** The "Events" panel: previous/next event, the editor of the selected event and a delete button. */
class EventsPanel(context: Context, private val tab: MapEditorViewModel, private val binder: Binder, private val onTemplates: () -> Unit) : LinearLayout(context) {
    private var formBinder: Binder? = null
    private val formHolder = context.vbox()

    init {
        orientation = VERTICAL
        val cycle = context.hbox()
        cycle.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(2))
        val prev = context.angleButton("Prev Group", AngleDrawable.Direction.Left, size = 12f) { cycleEvent(EventCycleDirection.PreviousCategory) }
        val next = context.angleButton("Next Group", AngleDrawable.Direction.Right, size = 12f) { cycleEvent(EventCycleDirection.NextCategory) }
        val title = context.label("", 13f, Palette.primary)
        title.gravity = android.view.Gravity.CENTER
        cycle.addView(prev, lp(WRAP, WRAP))
        cycle.addView(title, lp(0, WRAP, 1f))
        cycle.addView(next, lp(WRAP, WRAP))
        addView(cycle, lp(MATCH, WRAP))

        val selectors = FlowLayout(context)
        selectors.hGap = Ui.dp(4)
        selectors.vGap = Ui.dp(4)
        selectors.setPadding(Ui.dp(8), Ui.dp(2), Ui.dp(8), Ui.dp(4))
        addView(selectors, lp(MATCH, WRAP))

        val tools = context.hbox()
        tools.setPadding(Ui.dp(6), Ui.dp(2), Ui.dp(6), Ui.dp(4))
        val delete = context.angleButton("Delete Event", AngleDrawable.Direction.Out, size = 12f) { Engine.post { tab.deleteCurrentEvent() } }
        val templates = context.angleButton("Object Template...", AngleDrawable.Direction.Out, size = 12f) { onTemplates() }
        tools.addView(delete, lp(WRAP, WRAP))
        tools.addView(templates, lp(WRAP, WRAP).also { it.leftMargin = Ui.dp(8) })
        addView(tools, lp(MATCH, WRAP))

        val hint = context.label("Tap an event on the map to edit it. Use the Obj, W, Sc, Sp and F buttons above the map to drop new events.", 12f, Palette.secondary)
        hint.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), Ui.dp(8))
        addView(hint, lp(MATCH, WRAP))
        addView(context.vscroll(formHolder), lp(MATCH, 0, 1f))

        var shownEvent: IEventViewModel? = null
        binder.watch(tab, "selectedEvent", "primaryMap") {
            val ev = tab.selectedEvent
            title.text = if (ev == null) "No event selected" else ev.eventType + "  " + ev.eventIndex
            delete.visibility = if (ev == null) View.GONE else View.VISIBLE
            hint.visibility = if (ev == null) View.VISIBLE else View.GONE
            prev.visibility = if (ev == null) View.INVISIBLE else View.VISIBLE
            next.visibility = if (ev == null) View.INVISIBLE else View.VISIBLE
            if (ev !== shownEvent) {
                shownEvent = ev
                formBinder?.dispose()
                formHolder.removeAllViews()
                if (ev != null) {
                    val own = binder.child()
                    formBinder = own
                    formHolder.addView(EventForms.build(context, own, ev), lp(MATCH, WRAP))
                }
            }
            selectors.removeAllViews()
            val map = tab.primaryMap
            for (selector in map.eventSelectors.toList()) {
                val dot = context.angleButton(((selector.index) + 1).toString(), AngleDrawable.Direction.None, fill = if (selector.isSelected) Palette.accent else Palette.backlight,
                    textColor = if (selector.isSelected) android.graphics.Color.BLACK else Palette.primary, size = 12f) { Engine.post { selector.select() } }
                dot.minimumWidth = Ui.dp(32)
                dot.minHeight = Ui.dp(30)
                dot.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(2))
                selectors.addView(dot, ViewGroup.MarginLayoutParams(WRAP, WRAP))
            }
        }
        binder.watchCollection(tab.primaryMap.eventSelectors) { }
    }

    private fun cycleEvent(direction: EventCycleDirection) {
        Engine.post {
            val ev = tab.selectedEvent ?: return@post
            val command = ev.cycleEventCommand
            if (command.canExecute(direction)) command.execute(direction)
        }
    }
}

/** The settings of the "new object" template (what a freshly dropped object becomes). */
internal object TemplateSettings {
    fun show(context: Context, binder: Binder, tab: MapEditorViewModel, onDismiss: () -> Unit) {
        val own = binder.child()
        val templates = tab.templates
        val root = context.vbox()
        root.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10))
        root.addView(Dialogs.title(context, "Object Template"))
        val form = MapForm(context, own, root)
        form.note("What a newly created object starts as. Click an object template, then drop it on the map.")
        form.combo(
            "Template:", templates, { templates.availableTemplateTypes.map { it.name } }, { templates.availableTemplateTypes.indexOf(templates.selectedTemplate) },
            { index -> templates.availableTemplateTypes.getOrNull(index)?.let { templates.selectedTemplate = it } }, templates.availableTemplateTypes,
        )
        form.combo("Item:", templates, { templates.itemOptions.toList() }, { templates.itemID }, { templates.itemID = it }, templates.itemOptions, null, templates) { templates.selectedTemplate == TemplateType.Item }
        form.group(templates, { templates.selectedTemplate == TemplateType.Trainer }) { g ->
            g.check("Use Existing Trainer Data", templates, { templates.useExistingTrainer }, { templates.useExistingTrainer = it })
            g.group(templates, { !templates.useExistingTrainer }) { n ->
                n.note("This trainer prefers to use pokemon of")
                n.number("Max level:", templates, { templates.maxLevel }, { templates.maxLevel = it })
                n.combo("Type:", templates, { templates.typeOptions.toList() }, { templates.preferredType }, { templates.preferredType = it }, templates.typeOptions)
                n.number("From the first (pokemon):", templates, { templates.maxPokedex }, { templates.maxPokedex = it })
                n.check("Use the national dex order", templates, { templates.useNationalDex }, { templates.useNationalDex = it })
            }
            g.group(templates, { templates.useExistingTrainer }) { e -> e.filtering("Trainer:", templates.trainerOptions) }
        }
        val graphics = setOf(TemplateType.Legendary, TemplateType.Npc, TemplateType.Tutor, TemplateType.Trade, TemplateType.Trainer)
        form.visualPicker(
            "Graphics:", templates, { templates.graphicsOptions.toList() }, { templates.trainerGraphics }, { templates.trainerGraphics = it },
            templates,
        ) { templates.selectedTemplate in graphics }
        form.image(templates, 1f, { templates.trainerSprite }) { templates.selectedTemplate == TemplateType.Trainer }
        form.combo(
            "Type:", templates, { templates.hmObjectOptions.toList() }, { templates.hmObjectIndex }, { templates.hmObjectIndex = it }, templates.hmObjectOptions,
            null, templates,
        ) { templates.selectedTemplate == TemplateType.HMObject }
        val dialog = Dialogs.create(context, context.vscroll(root), 420, true)
        dialog.setOnDismissListener {
            own.dispose()
            onDismiss()
            Engine.post { tab.showTemplateSettings = false }
        }
        dialog.show()
    }
}
