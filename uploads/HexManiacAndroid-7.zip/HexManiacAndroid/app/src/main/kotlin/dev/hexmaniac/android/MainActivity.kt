package dev.hexmaniac.android

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import dev.hexmaniac.android.host.AndroidDispatcher
import dev.hexmaniac.android.host.AndroidFileSystem
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.android.host.HostUi
import dev.hexmaniac.android.ui.AboutDialog
import dev.hexmaniac.android.ui.AppState
import dev.hexmaniac.android.ui.Binder
import dev.hexmaniac.android.ui.HostDialogs
import dev.hexmaniac.android.ui.MATCH
import dev.hexmaniac.android.ui.MainScreen
import dev.hexmaniac.android.ui.MenuSheet
import dev.hexmaniac.android.ui.Palette
import dev.hexmaniac.android.ui.ThemeDialog
import dev.hexmaniac.android.ui.Ui
import dev.hexmaniac.android.ui.fire
import dev.hexmaniac.android.ui.label
import dev.hexmaniac.core.models.ProcessModel
import dev.hexmaniac.core.models.VisualOption
import dev.hexmaniac.core.system.INotifyPropertyChanged
import dev.hexmaniac.core.viewmodels.EditorViewModel

class MainActivity : Activity(), HostUi, MenuSheet.Callbacks {
    override val context: Context get() = this

    private var screen: MainScreen? = null
    private var themeBinder: Binder? = null
    private var themeEditing = false
    private var rebuildVersion = 0
    private var firstThemeCallback = true
    private val pending = HashMap<Int, Engine.Resume<Intent?>>()
    private var nextCode = 100
    private var pendingUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.init(this)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        showLoading()
        Engine.start()
        Engine.onFailure = { t ->
            Log.e("HexManiac", "engine failure", t)
            Engine.ui { Toast.makeText(this, "Error: " + (t.message ?: t.javaClass.simpleName), Toast.LENGTH_LONG).show() }
        }
        val fs = if (AppState.hasFileSystem()) AppState.fileSystem else AndroidFileSystem(applicationContext).also { AppState.fileSystem = it }
        fs.ui = this
        remember(intent)
        val existing = AppState.editor
        if (existing != null) {
            attach(existing)
        } else {
            Engine.post {
                val editor = EditorViewModel(fs, AndroidDispatcher(), true)
                AppState.editor = editor
                Engine.ui { attach(editor) }
            }
        }
    }

    private fun showLoading() {
        val frame = FrameLayout(this)
        frame.setBackgroundColor(Palette.background)
        val text = label(this, "Loading...")
        frame.addView(text, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        setContentView(frame)
    }

    private fun label(context: Context, text: String): View = context.label(text, 18f, Palette.secondary)

    private fun attach(editor: EditorViewModel) {
        Engine.read { Palette.apply(editor.theme) }
        themeBinder?.dispose()
        firstThemeCallback = true
        val binder = Binder()
        themeBinder = binder
        Engine.read {
            binder.watch(editor.theme as INotifyPropertyChanged) {
                if (firstThemeCallback) firstThemeCallback = false else scheduleRebuild()
            }
        }
        buildScreen()
        consumePendingUri()
    }

    private fun scheduleRebuild() {
        if (themeEditing) return
        val version = ++rebuildVersion
        Engine.uiDelayed(200) { if (version == rebuildVersion && !themeEditing) buildScreen() }
    }

    private fun buildScreen() {
        val editor = AppState.editor ?: return
        Engine.read {
            Palette.apply(editor.theme)
            screen?.dispose()
            val next = MainScreen(this, editor)
            screen = next
            setContentView(next.root)
        }
        window.statusBarColor = Palette.background
        window.navigationBarColor = Palette.background
        window.decorView.setBackgroundColor(Palette.background)
    }

    // ---------------------------------------------------------------- intents

    private fun remember(intent: Intent?) {
        val uri = intent?.data ?: return
        if (intent.action == Intent.ACTION_VIEW) pendingUri = uri
    }

    private fun consumePendingUri() {
        val uri = pendingUri ?: return
        val editor = AppState.editor ?: return
        pendingUri = null
        Engine.post {
            val fs = AppState.fileSystem
            val path = fs.registerExternal(uri)
            val file = fs.loadFile(path)
            if (file != null) editor.open.execute(file)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        remember(intent)
        consumePendingUri()
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onResume() {
        super.onResume()
        Engine.post { if (AppState.hasFileSystem()) AppState.fileSystem.pollExternalChanges() }
    }

    override fun onStop() {
        super.onStop()
        val editor = AppState.editor ?: return
        Engine.post { editor.writeAppLevelMetadata() }
    }

    override fun onDestroy() {
        super.onDestroy()
        screen?.dispose()
        screen = null
        themeBinder?.dispose()
        themeBinder = null
        if (AppState.hasFileSystem() && AppState.fileSystem.ui === this) AppState.fileSystem.ui = null
        val waiting = pending.values.toList()
        pending.clear()
        for (resume in waiting) resume.resume(null)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val editor = AppState.editor
        if (editor == null) {
            moveTaskToBack(true)
            return
        }
        val handled = Engine.read {
            when {
                editor.gotoViewModel.controlVisible -> {
                    Engine.post { editor.gotoViewModel.showGoto.execute(false) }
                    true
                }
                editor.findControlVisible || editor.hexConverterVisible -> {
                    Engine.post { editor.hideSearchControls.execute(null) }
                    true
                }
                else -> false
            }
        }
        if (!handled) moveTaskToBack(true)
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val editor = AppState.editor
        if (editor != null && event.action == KeyEvent.ACTION_DOWN && event.isCtrlPressed) {
            val inText = currentFocus is EditText
            val shift = event.isShiftPressed
            val handled = when (event.keyCode) {
                KeyEvent.KEYCODE_S -> { (if (shift) editor.saveAs else editor.save).fire(); true }
                KeyEvent.KEYCODE_O -> { editor.open.fire(); true }
                KeyEvent.KEYCODE_N -> { editor.new.fire(); true }
                KeyEvent.KEYCODE_F -> { editor.showFind.fire(true); true }
                KeyEvent.KEYCODE_G -> { editor.gotoViewModel.showGoto.fire(true); true }
                KeyEvent.KEYCODE_H -> { editor.showHexConverter.fire(true); true }
                KeyEvent.KEYCODE_W -> { editor.close.fire(AppState.fileSystem); true }
                KeyEvent.KEYCODE_Z -> if (inText) false else { editor.undo.fire(); true }
                KeyEvent.KEYCODE_Y -> if (inText) false else { editor.redo.fire(); true }
                KeyEvent.KEYCODE_C -> if (inText) false else { (if (shift) editor.deepCopy else editor.copy).fire(); true }
                KeyEvent.KEYCODE_V, KeyEvent.KEYCODE_B -> if (inText) false else { editor.paste.fire(); true }
                KeyEvent.KEYCODE_X -> if (inText) false else { editor.cut.fire(); true }
                KeyEvent.KEYCODE_A -> if (inText) false else { editor.selectAll.fire(); true }
                else -> false
            }
            if (handled) return true
        }
        if (editor != null && event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_F5) {
            editor.runFile.fire(AppState.fileSystem)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    // ---------------------------------------------------------------- HostUi

    override fun launchForResult(intent: Intent, resume: Engine.Resume<Intent?>) {
        val code = (nextCode++) and 0xFFFF
        pending[code] = resume
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(intent, code)
        } catch (e: Exception) {
            pending.remove(code)
            resume.resume(null)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        pending.remove(requestCode)?.resume(if (resultCode == RESULT_OK) data else null)
    }

    override fun showMessage(message: String, yesNoCancel: Boolean, links: List<ProcessModel>, resume: Engine.Resume<Boolean?>) {
        HostDialogs.message(this, this, message, yesNoCancel, links, resume)
    }

    override fun showOptions(title: String, prompt: String, details: List<List<Any>>?, options: List<VisualOption>, resume: Engine.Resume<Int>) {
        HostDialogs.options(this, title, prompt, details, options, resume)
    }

    override fun requestText(title: String, prompt: String, resume: Engine.Resume<String?>) {
        dev.hexmaniac.android.ui.Dialogs.text(this, title, prompt, "") { resume.resume(it) }
    }

    override fun readClipboard(): String? {
        val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = manager.primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).coerceToText(this)?.toString()
    }

    override fun writeClipboard(text: String) {
        val manager = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        manager.setPrimaryClip(ClipData.newPlainText("HexManiac", text))
    }

    override fun openLink(link: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)))
        } catch (e: Exception) {
            Toast.makeText(this, "Cannot open $link", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- MenuSheet.Callbacks

    fun showMenu() {
        val editor = AppState.editor ?: return
        MenuSheet(this, editor, this).show()
    }

    override fun exit() {
        finish()
    }

    override fun showThemeEditor() {
        val editor = AppState.editor ?: return
        themeEditing = true
        ThemeDialog.show(this, editor) {
            themeEditing = false
            buildScreen()
        }
    }

    override fun showAbout() {
        AboutDialog.show(this)
    }
}
