package dev.hexmaniac.android.ui

import android.content.Context
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.system.ICommand
import dev.hexmaniac.core.system.INotifyCollectionChanged
import dev.hexmaniac.core.system.INotifyPropertyChanged
import dev.hexmaniac.core.viewmodels.TextEditorViewModel
import dev.hexmaniac.core.viewmodels.images.IPixelViewModel
import dev.hexmaniac.core.viewmodels.tools.FilteringComboOptions
import dev.hexmaniac.core.viewmodels.tools.VisualComboOption

/**
 * Builds the label-and-field rows of the map editor panels. Every row is bound to a view-model: [get] callbacks run
 * with the engine lock held (UI thread), [set] callbacks run on the engine thread.
 */
internal class MapForm(val context: Context, val binder: Binder, val box: LinearLayout) {

    private fun <T : View> place(view: T, vm: INotifyPropertyChanged?, visible: (() -> Boolean)?): T {
        box.addView(view, LinearLayout.LayoutParams(MATCH, WRAP))
        if (visible != null && vm != null) binder.watch(vm) { view.visibility = if (visible()) View.VISIBLE else View.GONE }
        return view
    }

    fun section(text: String, vm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null): View {
        val view = context.label(text, 13f, Palette.accent, bold = true)
        view.setPadding(Ui.dp(6), Ui.dp(10), Ui.dp(6), Ui.dp(2))
        return place(view, vm, visible)
    }

    fun note(text: String, vm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null): TextView {
        val view = context.label(text, 12f, Palette.secondary)
        view.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4))
        return place(view, vm, visible)
    }

    /** A line of text that follows the view-model. */
    fun dynamicNote(vm: INotifyPropertyChanged, color: Int = Palette.secondary, get: () -> String?): TextView {
        val view = context.label("", 12f, color)
        view.setPadding(Ui.dp(6), Ui.dp(2), Ui.dp(6), Ui.dp(2))
        binder.watch(vm) {
            val value = get() ?: ""
            view.text = value
            view.visibility = if (value.isEmpty()) View.GONE else View.VISIBLE
        }
        return place(view, null, null)
    }

    fun group(vm: INotifyPropertyChanged?, visible: (() -> Boolean)?, build: (MapForm) -> Unit): LinearLayout {
        val inner = context.vbox()
        place(inner, vm, visible)
        build(MapForm(context, binder, inner))
        return inner
    }

    private fun textEdit(vm: INotifyPropertyChanged, get: () -> String?, set: (String) -> Unit, mono: Boolean, numeric: Boolean): EditText {
        val edit = context.textBox(size = 13f, mono = mono)
        if (numeric) edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        var updating = false
        fun show() {
            val value = get() ?: ""
            if (edit.text.toString() != value) {
                updating = true
                edit.setText(value)
                updating = false
            }
        }
        binder.watch(vm) { if (!edit.hasFocus()) show() }
        edit.setOnFocusChangeListener { _, focused -> if (!focused) readSoon { show() } }
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                if (updating) return
                val text = s?.toString() ?: ""
                Engine.post { set(text) }
            }
        })
        return edit
    }

    fun text(
        name: String, vm: INotifyPropertyChanged, get: () -> String?, set: (String) -> Unit, trailing: View? = null,
        mono: Boolean = false, visibleVm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null,
    ): EditText {
        val edit = textEdit(vm, get, set, mono, false)
        place(ElementViews.fieldRow(context, name, edit, trailing), visibleVm, visible)
        return edit
    }

    fun number(
        name: String, vm: INotifyPropertyChanged, get: () -> Int, set: (Int) -> Unit, trailing: View? = null,
        visibleVm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null,
    ): EditText = text(name, vm, { get().toString() }, { t -> t.trim().toIntOrNull()?.let(set) }, trailing, false, visibleVm, visible)

    fun hex(
        name: String, vm: INotifyPropertyChanged, get: () -> Int, set: (Int) -> Unit, trailing: View? = null,
        visibleVm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null,
    ): EditText = text(
        name, vm, { Integer.toHexString(get()).uppercase() },
        { t -> t.trim().removePrefix("0x").toIntOrNull(16)?.let(set) }, trailing, true, visibleVm, visible,
    )

    fun combo(
        name: String, vm: INotifyPropertyChanged, options: () -> List<String>, selected: () -> Int, set: (Int) -> Unit,
        source: INotifyCollectionChanged? = null, trailing: View? = null, visibleVm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null,
    ): Dropdown {
        val dropdown = Dropdown(context, name)
        binder.watch(vm) { dropdown.setItems(options(), selected()) }
        if (source != null) binder.watchCollection(source) { dropdown.setItems(options(), selected()) }
        dropdown.onSelect = { index -> Engine.post { set(index) } }
        place(ElementViews.fieldRow(context, name, dropdown, trailing), visibleVm, visible)
        return dropdown
    }

    fun filtering(name: String, options: FilteringComboOptions, trailing: View? = null, visibleVm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null): Dropdown {
        val dropdown = ElementViews.comboDropdown(context, binder, options, name)
        place(ElementViews.fieldRow(context, name, dropdown, trailing), visibleVm, visible)
        return dropdown
    }

    fun check(text: String, vm: INotifyPropertyChanged, get: () -> Boolean, set: (Boolean) -> Unit, visibleVm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null): CheckRow {
        val row = CheckRow(context, text, false)
        row.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4))
        binder.watch(vm) { row.setCheckedSilently(get()) }
        row.onChange = { checked -> Engine.post { set(checked) } }
        place(row, visibleVm, visible)
        return row
    }

    fun button(
        text: String, vm: INotifyPropertyChanged? = null, enabled: (() -> Boolean)? = null, visible: (() -> Boolean)? = null,
        direction: AngleDrawable.Direction = AngleDrawable.Direction.Out, onClick: () -> Unit,
    ): TextView {
        val button = context.angleButton(text, direction, size = 13f) { onClick() }
        if (vm != null && enabled != null) {
            binder.watch(vm) {
                val on = enabled()
                button.isEnabled = on
                button.alpha = if (on) 1f else 0.4f
            }
        }
        val holder = context.hbox()
        holder.setPadding(Ui.dp(6), Ui.dp(3), Ui.dp(6), Ui.dp(3))
        holder.addView(button, LinearLayout.LayoutParams(WRAP, WRAP))
        place(holder, vm, visible)
        return button
    }

    fun commandButton(text: String, command: () -> ICommand?, vm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null): TextView =
        button(text, vm, null, visible) { command().fire() }

    fun editor(name: String, editor: TextEditorViewModel?, vm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null, fontSize: Float = 13f): View? {
        if (editor == null) return null
        val holder = context.vbox()
        holder.addView(context.label(name, 13f, Palette.secondary).also { it.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(2)) })
        val edit = ToolPanels.codeEditor(context, binder, editor, false, fontSize)
        (edit as? EditText)?.minLines = 2
        holder.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(4); it.rightMargin = Ui.dp(4) })
        return place(holder, vm, visible)
    }

    fun image(vm: INotifyPropertyChanged, scale: Float = 1f, get: () -> IPixelViewModel?, visible: (() -> Boolean)? = null): PixelView {
        val view = PixelView(context)
        view.scaleDp = scale
        binder.watch(vm) { view.setImage(get()) }
        val holder = context.hbox()
        holder.setPadding(Ui.dp(6), Ui.dp(4), Ui.dp(6), Ui.dp(4))
        holder.addView(view, LinearLayout.LayoutParams(WRAP, WRAP))
        place(holder, vm, visible)
        return view
    }

    /** A button that runs [block] on the engine thread. */
    fun action(text: String, vm: INotifyPropertyChanged? = null, enabled: (() -> Boolean)? = null, visible: (() -> Boolean)? = null, block: () -> Unit): TextView =
        button(text, vm, enabled, visible) { Engine.post { block() } }

    /** A small square button for the end of a row. */
    fun miniButton(text: String, vm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null, block: () -> Unit): TextView {
        val button = context.angleButton(text, AngleDrawable.Direction.Right, size = 13f) { Engine.post { block() } }
        button.minimumWidth = Ui.dp(36)
        if (vm != null && visible != null) binder.watch(vm) { button.visibility = if (visible()) View.VISIBLE else View.GONE }
        return button
    }

    /** Two small buttons ("go to" and "create") for rows holding an address. */
    fun gotoCreate(vm: INotifyPropertyChanged, canCreate: () -> Boolean, goto: () -> Unit, create: () -> Unit): View {
        val pair = context.hbox()
        pair.addView(miniButton("\u2192", null, null, goto))
        pair.addView(miniButton("+", vm, canCreate, create).also { (it.layoutParams as? LinearLayout.LayoutParams)?.leftMargin = Ui.dp(2) })
        return pair
    }

    fun multiline(name: String, vm: INotifyPropertyChanged, get: () -> String?, set: (String) -> Unit, visibleVm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null): EditText {
        val holder = context.vbox()
        holder.addView(context.label(name, 13f, Palette.secondary).also { it.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(2)) })
        val edit = textEdit(vm, get, set, true, false)
        edit.isSingleLine = false
        edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        edit.gravity = Gravity.TOP or Gravity.START
        edit.minLines = 3
        holder.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(4); it.rightMargin = Ui.dp(4) })
        place(holder, visibleVm, visible)
        return edit
    }

    /** A text editor whose view-model can be replaced while the panel is open. */
    fun dynamicEditor(name: String, vm: INotifyPropertyChanged, get: () -> TextEditorViewModel?): View {
        val holder = context.vbox()
        var current: TextEditorViewModel? = null
        var child: Binder? = null
        binder.watch(vm) {
            val next = get()
            if (next !== current) {
                current = next
                child?.dispose()
                holder.removeAllViews()
                if (next != null) {
                    val own = binder.child()
                    child = own
                    holder.addView(context.label(name, 13f, Palette.secondary).also { it.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(2)) })
                    val edit = ToolPanels.codeEditor(context, own, next, false, 13f)
                    (edit as? EditText)?.minLines = 2
                    holder.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(4); it.rightMargin = Ui.dp(4) })
                }
            }
        }
        return place(holder, null, null)
    }

    /** A wrapping row of small pictures that follows a collection. */
    fun imageStrip(vm: INotifyPropertyChanged, source: dev.hexmaniac.core.system.ObservableCollection<IPixelViewModel>, scale: Float = 1f): View {
        val flow = FlowLayout(context)
        flow.hGap = Ui.dp(4)
        flow.vGap = Ui.dp(4)
        flow.setPadding(Ui.dp(6), Ui.dp(2), Ui.dp(6), Ui.dp(2))
        val rebuild = {
            flow.removeAllViews()
            for (item in source.toList()) {
                val view = PixelView(context)
                view.scaleDp = scale
                view.setImage(item)
                flow.addView(view, android.view.ViewGroup.MarginLayoutParams(WRAP, WRAP))
            }
        }
        binder.watchCollection(source) { rebuild() }
        binder.watch(vm) { if (flow.childCount != source.size) rebuild() }
        return place(flow, null, null)
    }

    /** A button showing a sprite; tapping it opens a grid of all the choices. */
    fun visualPicker(
        name: String, vm: INotifyPropertyChanged, options: () -> List<VisualComboOption>, selected: () -> Int, set: (Int) -> Unit,
        visibleVm: INotifyPropertyChanged? = null, visible: (() -> Boolean)? = null,
    ): View {
        val pixels = PixelView(context)
        pixels.scaleDp = 1.5f
        pixels.minSideDp = 24
        val caption = context.label("", 13f, Palette.primary)
        val picker = context.hbox()
        picker.minimumHeight = Ui.dp(34)
        picker.setPadding(Ui.dp(8), Ui.dp(2), Ui.dp(8), Ui.dp(2))
        picker.background = BoxDrawable(Palette.backlight, Palette.secondary)
        picker.isClickable = true
        picker.addView(pixels, LinearLayout.LayoutParams(WRAP, WRAP))
        picker.addView(caption, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.leftMargin = Ui.dp(6) })
        binder.watch(vm) {
            val list = options()
            val index = selected()
            val option = list.getOrNull(index)
            pixels.setImage(option)
            caption.text = option?.text ?: ("#" + index)
        }
        picker.setOnClickListener {
            readSoon {
                val list = options()
                showGrid(name, list) { index -> Engine.post { set(index) } }
            }
        }
        place(ElementViews.fieldRow(context, name, picker, null), visibleVm, visible)
        return picker
    }

    private fun showGrid(title: String, list: List<VisualComboOption>, onPick: (Int) -> Unit) {
        val flow = FlowLayout(context)
        flow.hGap = Ui.dp(4)
        flow.vGap = Ui.dp(4)
        flow.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6))
        val dialogRef = arrayOfNulls<android.app.Dialog>(1)
        val root = context.vbox()
        root.addView(Dialogs.title(context, title).also { it.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), Ui.dp(4)) })
        val scroll = ScrollView(context)
        scroll.addView(flow, android.view.ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(scroll, LinearLayout.LayoutParams(MATCH, Ui.dp(420)))
        for ((i, option) in list.withIndex()) {
            val cell = context.vbox()
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2))
            cell.background = BoxDrawable(Palette.backlight, Palette.secondary)
            val pixel = PixelView(context)
            pixel.scaleDp = 1f
            pixel.minSideDp = 16
            pixel.setImage(option)
            cell.addView(pixel, LinearLayout.LayoutParams(WRAP, WRAP))
            cell.addView(context.label(i.toString(), 10f, Palette.secondary))
            cell.isClickable = true
            cell.setOnClickListener {
                dialogRef[0]?.dismiss()
                onPick(i)
            }
            flow.addView(cell, android.view.ViewGroup.MarginLayoutParams(WRAP, WRAP))
        }
        val dialog = Dialogs.create(context, root, 420, true)
        dialogRef[0] = dialog
        dialog.show()
    }
}

/** Helper for panels: a vertical scroll area with a [MapForm] inside. */
internal fun Context.formScroll(binder: Binder, build: (MapForm) -> Unit): ScrollView {
    val box = vbox()
    box.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(12))
    build(MapForm(this, binder, box))
    return vscroll(box)
}
