package dev.hexmaniac.android.ui

import android.content.Context
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.viewmodels.tools.PagedElementViewModel
import dev.hexmaniac.core.viewmodels.tools.PaletteElementViewModel
import dev.hexmaniac.core.viewmodels.tools.SpriteElementViewModel
import dev.hexmaniac.core.viewmodels.tools.StreamElementViewModel

/** Views for the table tool's stream, sprite and palette fields (the ones that can own data of their own). */
object StreamViews {
    private val Left = AngleDrawable.Direction.Left
    private val Right = AngleDrawable.Direction.Right
    private val Out = AngleDrawable.Direction.Out

    /** The strip every stream field starts with: repoint buttons, the usage count and the "create new data" button. */
    fun header(context: Context, binder: Binder, vm: StreamElementViewModel): LinearLayout {
        val box = context.vbox()
        val repointRow = context.hbox()
        repointRow.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2))
        val info = context.label("", 12f, Palette.secondary, italic = true)
        repointRow.addView(info, LinearLayout.LayoutParams(0, WRAP, 1f))
        val repoint = context.angleButton("Repoint this one", Right, size = 12f) { vm.repoint.fire() }
        val repointMenu = context.angleButton("Repoint\u2026", Right, size = 12f) {
            Dialogs.pick(context, "Repoint", listOf("This One", "All"), -1) { which ->
                if (which == 0) vm.repoint.fire() else vm.repointAll.fire()
            }
        }
        repointRow.addView(repoint)
        repointRow.addView(repointMenu)
        box.addView(repointRow, LinearLayout.LayoutParams(MATCH, WRAP))
        val conflictRow = context.hbox()
        conflictRow.setPadding(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2))
        val conflict = context.label("Data conflict detected.", 12f, Palette.secondary, italic = true)
        conflictRow.addView(conflict, LinearLayout.LayoutParams(0, WRAP, 1f))
        val create = context.angleButton("Create new data", Out, size = 12f) { vm.createNew.fire() }
        conflictRow.addView(create)
        box.addView(conflictRow, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watch(vm) {
            val canRepoint = vm.canRepoint
            repointRow.visibility = if (canRepoint || vm.hasMultipleUses) View.VISIBLE else View.GONE
            repoint.visibility = if (canRepoint && !vm.canRepointAll) View.VISIBLE else View.GONE
            repointMenu.visibility = if (canRepoint && vm.canRepointAll) View.VISIBLE else View.GONE
            info.text = if (vm.hasMultipleUses) "This is used by " + vm.usageCount + " pointers." else ""
            conflictRow.visibility = if (vm.dataIsValidButNoRun) View.VISIBLE else View.GONE
            create.visibility = if (vm.canCreateNew) View.VISIBLE else View.GONE
        }
        return box
    }

    fun generic(context: Context, binder: Binder, vm: StreamElementViewModel): View = header(context, binder, vm)

    private fun pageControls(context: Context, binder: Binder, vm: PagedElementViewModel, small: Boolean = true): LinearLayout {
        val row = context.hbox()
        row.setPadding(Ui.dp(2), Ui.dp(4), Ui.dp(2), Ui.dp(4))
        val size = if (small) 12f else 14f
        val previous = context.angleButton("Previous", Left, size = size) { Engine.post { vm.movePrevious() } }
        val next = context.angleButton("Next", Right, size = size) { Engine.post { vm.moveNext() } }
        val label = context.label("", 12f, Palette.secondary)
        label.gravity = Gravity.CENTER
        row.addView(previous)
        row.addView(label, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(next)
        binder.watch(vm, "currentPage", "pages", "showPageControls", "canMovePrevious", "canMoveNext") {
            row.visibility = if (vm.showPageControls) View.VISIBLE else View.GONE
            previous.alpha = if (vm.canMovePrevious) 1f else 0.35f
            next.alpha = if (vm.canMoveNext) 1f else 0.35f
            label.text = "page " + (vm.currentPage + 1) + " of " + vm.pages
        }
        return row
    }

    fun sprite(context: Context, binder: Binder, vm: SpriteElementViewModel): View {
        val box = header(context, binder, vm)
        val pixels = PixelView(context)
        pixels.scaleDp = 1f
        pixels.maxWidthDp = 300
        binder.watch(vm, "pixelData", "pixelWidth", "pixelHeight", "spriteScale") { pixels.setImage(vm) }
        box.addView(pixels, LinearLayout.LayoutParams(WRAP, WRAP).also { it.gravity = Gravity.CENTER_HORIZONTAL; it.topMargin = Ui.dp(2) })

        val paletteLabel = context.label("Palette Selection", 11f, Palette.secondary)
        paletteLabel.gravity = Gravity.CENTER
        val paletteRow = context.hbox()
        paletteRow.gravity = Gravity.CENTER
        val paletteScroll = context.hscroll(paletteRow)
        box.addView(paletteLabel, LinearLayout.LayoutParams(MATCH, WRAP))
        box.addView(paletteScroll, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watch(vm, "hasMultiplePalettes", "currentPalette", "maxPalette") {
            val show = vm.hasMultiplePalettes
            paletteLabel.visibility = if (show) View.VISIBLE else View.GONE
            paletteScroll.visibility = if (show) View.VISIBLE else View.GONE
        }
        binder.watchCollection(vm.paletteSelection) {
            paletteRow.removeAllViews()
            for (choice in vm.paletteSelection) {
                val button = context.angleButton(choice.name.ifEmpty { choice.index.toString() }, Out, size = 11f) {
                    Engine.post { vm.currentPalette = choice.index }
                }
                binder.watch(choice, "selected") { button.setTextColor(if (choice.selected) Palette.accent else Palette.primary) }
                paletteRow.addView(button, LinearLayout.LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(3) })
            }
        }

        box.addView(pageControls(context, binder, vm))
        val actions = FlowLayout(context)
        actions.hGap = Ui.dp(4)
        actions.vGap = Ui.dp(4)
        actions.addView(context.angleButton("Import", Left, size = 12f) { vm.importPair.fire(AppState.fileSystem) })
        val export = context.angleButton("Export", Right, size = 12f) {
            val options = ArrayList<String>()
            val actionsList = ArrayList<() -> Unit>()
            options.add("Single Page")
            actionsList.add { vm.exportPair.fire(AppState.fileSystem) }
            if (Engine.read { vm.canExportMany }) {
                options.add("All Pages")
                actionsList.add { vm.exportMany.fire(AppState.fileSystem) }
            }
            if (Engine.read { vm.canExportAll }) {
                options.add("All Table")
                actionsList.add { vm.exportAll.fire(AppState.fileSystem) }
            }
            if (options.size == 1) actionsList[0]() else Dialogs.pick(context, "Export", options, -1) { actionsList[it]() }
        }
        actions.addView(export)
        actions.addView(context.angleButton("Edit", Out, size = 12f) { vm.openEditor.fire() })
        box.addView(actions, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(4) })
        return box
    }

    fun palette(context: Context, binder: Binder, vm: PaletteElementViewModel): View {
        val box = header(context, binder, vm)
        val view = PaletteView(context, vm.colors, binder.child())
        view.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) Engine.post { vm.activate() }
            false
        }
        box.addView(view, LinearLayout.LayoutParams(MATCH, WRAP).also { it.leftMargin = Ui.dp(4) })
        box.addView(pageControls(context, binder, vm))
        return box
    }
}
