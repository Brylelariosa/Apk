package dev.hexmaniac.android.ui

import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.EditText
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.system.ICommand
import dev.hexmaniac.core.system.INotifyCollectionChanged
import dev.hexmaniac.core.system.INotifyPropertyChanged
import dev.hexmaniac.core.system.PropertyChangedEventArgs
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Connects view-model change notifications (raised on the engine thread) to Android views (updated on the UI thread).
 *
 * Every `watch*` call runs its update lambda once immediately, so call them on the UI thread while holding the engine
 * lock (`Engine.read { }`), which is also where views are built. Later updates are coalesced and run on the UI thread
 * under [Engine.tryRead], so the UI thread never waits long for a busy engine.
 */
class Binder {
    internal class Sub(val owner: Binder, val update: () -> Unit)

    private val unsubscribers = ArrayList<() -> Unit>()
    private val children = ArrayList<Binder>()
    @Volatile var disposed = false
        private set

    private fun onEngine(block: () -> Unit) {
        if (Engine.lock.isHeldByCurrentThread) block() else Engine.post(block)
    }

    private fun subscribe(subscribeAndGetUnsubscribe: () -> () -> Unit) {
        onEngine {
            if (!disposed) {
                val unsubscribe = subscribeAndGetUnsubscribe()
                synchronized(unsubscribers) { unsubscribers.add(unsubscribe) }
            }
        }
    }

    fun watch(vm: INotifyPropertyChanged, vararg names: String, update: () -> Unit) {
        val sub = Sub(this, update)
        val handler: (Any?, PropertyChangedEventArgs) -> Unit = { _, e ->
            val name = e.propertyName
            if (names.isEmpty() || name == null || names.contains(name)) Flusher.enqueue(sub)
        }
        subscribe {
            vm.propertyChanged += handler
            val undo: () -> Unit = { vm.propertyChanged -= handler }
            undo
        }
        update()
    }

    fun watchCollection(collection: INotifyCollectionChanged, update: () -> Unit) {
        val sub = Sub(this, update)
        val handler: (Any?, dev.hexmaniac.core.system.NotifyCollectionChangedEventArgs) -> Unit = { _, _ -> Flusher.enqueue(sub) }
        subscribe {
            collection.collectionChanged += handler
            val undo: () -> Unit = { collection.collectionChanged -= handler }
            undo
        }
        update()
    }

    fun watchCommand(command: ICommand?, update: () -> Unit) {
        if (command == null) {
            update()
            return
        }
        val sub = Sub(this, update)
        val handler: (Any?, dev.hexmaniac.core.system.EventArgs) -> Unit = { _, _ -> Flusher.enqueue(sub) }
        subscribe {
            command.canExecuteChanged += handler
            val undo: () -> Unit = { command.canExecuteChanged -= handler }
            undo
        }
        update()
    }

    /** Subscribes a raw engine-thread callback that is disposed together with this binder. */
    fun onEngineEvent(subscribeAndGetUnsubscribe: () -> () -> Unit) = subscribe(subscribeAndGetUnsubscribe)

    fun child(): Binder {
        val binder = Binder()
        synchronized(children) { children.add(binder) }
        return binder
    }

    fun dispose() {
        if (disposed) return
        disposed = true
        val mine = synchronized(unsubscribers) { unsubscribers.toList().also { unsubscribers.clear() } }
        if (mine.isNotEmpty()) onEngine { for (undo in mine) undo() }
        val kids = synchronized(children) { children.toList().also { children.clear() } }
        for (kid in kids) kid.dispose()
    }

    // ---------------------------------------------------------------- two way helpers

    /** Keeps [edit] and a string property of [vm] in sync. [set] is called on the engine thread. */
    fun bindText(edit: EditText, vm: INotifyPropertyChanged, property: String, get: () -> String?, set: (String) -> Unit) {
        var updating = false
        watch(vm, property) {
            val text = get() ?: ""
            if (edit.text.toString() != text) {
                updating = true
                edit.setText(text)
                edit.setSelection(edit.text.length)
                updating = false
            }
        }
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                if (updating) return
                val text = s?.toString() ?: ""
                Engine.post { set(text) }
            }
        })
    }

    fun bindChecked(row: CheckRow, vm: INotifyPropertyChanged, property: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        watch(vm, property) { row.setCheckedSilently(get()) }
        row.onChange = { checked -> Engine.post { set(checked) } }
    }
}

/** Delivers queued updates on the UI thread, never blocking it for long. */
private object Flusher {
    private val pending = ConcurrentLinkedQueue<Binder.Sub>()
    private val scheduled = AtomicBoolean(false)

    fun enqueue(sub: Binder.Sub) {
        pending.add(sub)
        if (scheduled.compareAndSet(false, true)) Engine.ui { run() }
    }

    private fun run() {
        val done = Engine.tryRead(10) {
            while (true) {
                val sub = pending.poll() ?: break
                if (sub.owner.disposed) continue
                try {
                    sub.update()
                } catch (t: Throwable) {
                    Log.e("HexManiac", "view update failed", t)
                }
            }
            true
        }
        if (done == null) {
            Engine.uiDelayed(20) { run() }
        } else {
            scheduled.set(false)
            if (!pending.isEmpty() && scheduled.compareAndSet(false, true)) Engine.ui { run() }
        }
    }
}

/** Posts a command to the engine thread if it can run. */
fun ICommand?.fire(parameter: Any? = null) {
    val command = this ?: return
    Engine.post { if (command.canExecute(parameter)) command.execute(parameter) }
}

/** Runs [block] on the UI thread under the engine lock as soon as the engine is not busy. */
fun readSoon(block: () -> Unit) {
    Engine.ui {
        val done = Engine.tryRead(8) { block(); true }
        if (done == null) Engine.uiDelayed(16) { readSoon(block) }
    }
}
