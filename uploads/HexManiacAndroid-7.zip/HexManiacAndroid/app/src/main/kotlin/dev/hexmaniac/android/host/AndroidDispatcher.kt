package dev.hexmaniac.android.host

import android.view.Choreographer
import dev.hexmaniac.core.DelayWorkResult
import dev.hexmaniac.core.IDelayWorkTimer
import dev.hexmaniac.core.models.IWorkDispatcher
import dev.hexmaniac.core.system.Task
import dev.hexmaniac.core.system.TimeSpan
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory

/** [IWorkDispatcher] for the engine thread (see [Engine]). "UI work" means "engine thread work". */
class AndroidDispatcher : IWorkDispatcher {
    private val background = Executors.newCachedThreadPool(ThreadFactory { r ->
        Thread(r, "hma-background").also { it.isDaemon = true }
    })

    override fun waitForRenderingAsync(): Task<Unit> {
        val task = Task<Unit>()
        Engine.ui {
            Choreographer.getInstance().postFrameCallback { task.trySetResult(Unit) }
        }
        return task
    }

    override fun blockOnUIWork(action: () -> Unit) {
        Engine.call { action() }
    }

    override fun dispatchWork(action: (() -> Unit)?): Task<Unit> {
        val task = Task<Unit>()
        Engine.post {
            try {
                action?.invoke()
                task.trySetResult(Unit)
            } catch (t: Throwable) {
                task.trySetException(t)
                throw t
            }
        }
        return task
    }

    override fun runBackgroundWork(action: () -> Unit): Task<Unit> {
        val task = Task<Unit>()
        background.execute {
            try {
                action()
                task.trySetResult(Unit)
            } catch (t: Throwable) {
                task.trySetException(t)
            }
        }
        return task
    }

    override fun createDelayTimer(): IDelayWorkTimer = DelayTimer()

    private class DelayTimer : IDelayWorkTimer {
        private var pending: Engine.Cancel? = null
        private var scheduled = false

        override val hasScheduledWork: Boolean get() = scheduled

        override fun delayCall(delay: TimeSpan, action: () -> Unit): DelayWorkResult {
            val result = if (scheduled) DelayWorkResult.WorkScheduledAndPreviousWorkCleared else DelayWorkResult.WorkScheduled
            pending?.cancel()
            scheduled = true
            pending = Engine.postDelayed(delay.totalMilliseconds.toLong()) {
                scheduled = false
                pending = null
                action()
            }
            return result
        }

        override fun reset() {
            pending?.cancel()
            pending = null
            scheduled = false
        }
    }
}
