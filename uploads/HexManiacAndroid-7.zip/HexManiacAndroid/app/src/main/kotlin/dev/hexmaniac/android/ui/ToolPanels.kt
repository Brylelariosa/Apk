package dev.hexmaniac.android.ui

import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.system.ICommand
import dev.hexmaniac.core.viewmodels.tools.CodeBody
import dev.hexmaniac.core.viewmodels.tools.CodeMode
import dev.hexmaniac.core.viewmodels.tools.CodeTool
import dev.hexmaniac.core.viewmodels.tools.IToolTrayViewModel
import dev.hexmaniac.core.viewmodels.tools.LogTool
import dev.hexmaniac.core.viewmodels.tools.PCSTool
import dev.hexmaniac.core.viewmodels.tools.SpriteTool
import dev.hexmaniac.core.viewmodels.tools.TableGroupViewModel
import dev.hexmaniac.core.viewmodels.tools.TableTool
import dev.hexmaniac.core.viewmodels.visitors.CompositeContextItem
import dev.hexmaniac.core.viewmodels.visitors.ContextItemGroup
import dev.hexmaniac.core.viewmodels.visitors.DisabledContextItem
import dev.hexmaniac.core.viewmodels.visitors.IContextItem

/** An [EditText] that reports its selection, used by the text tool to keep the hex selection in sync. */
class SelectionEditText(context: Context) : EditText(context) {
    var onSelection: ((Int, Int) -> Unit)? = null
    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        onSelection?.invoke(selStart, selEnd)
    }
}

/** Shows the engine's context items (menu entries, possibly nested) in a list dialog. */
object ContextMenus {
    fun show(context: Context, title: String, items: List<IContextItem>) {
        val usable = items.filter { !it.text.isNullOrEmpty() }
        if (usable.isEmpty()) return
        val names = usable.map { item ->
            var name = item.text ?: ""
            if (item is DisabledContextItem) name = "($name)"
            if (item.shortcutText.isNotEmpty()) name += "   " + item.shortcutText
            if (item is ContextItemGroup || item is CompositeContextItem) name += "  \u25B8"
            name
        }
        Dialogs.pick(context, title, names, -1) { index ->
            val item = usable[index]
            when (item) {
                is DisabledContextItem -> Unit
                is ContextItemGroup -> show(context, item.text ?: "", item.toList())
                is CompositeContextItem -> show(context, item.text ?: "", item.toList())
                else -> {
                    val command = item.command
                    val parameter = item.parameter
                    Engine.post { if (command.canExecute(parameter)) command.execute(parameter) }
                }
            }
        }
    }
}

/** The tool panels that live beside (or below) the hex view. */
object ToolPanels {
    private val Left = AngleDrawable.Direction.Left
    private val Right = AngleDrawable.Direction.Right
    private val Out = AngleDrawable.Direction.Out

    private fun pad(view: View, l: Int = 6, t: Int = 4, r: Int = 6, b: Int = 4): View {
        view.setPadding(Ui.dp(l), Ui.dp(t), Ui.dp(r), Ui.dp(b))
        return view
    }

    private fun commandButton(context: Context, binder: Binder, text: String, direction: AngleDrawable.Direction, command: () -> ICommand?, size: Float = 13f): View {
        val button = context.angleButton(text, direction, size = size) { command().fire() }
        binder.watchCommand(command()) {
            val c = command()
            button.alpha = if (c == null || c.canExecute(null)) 1f else 0.4f
        }
        return button
    }

    // ---------------------------------------------------------------- table

    fun table(context: Context, binder: Binder, tool: TableTool): View {
        val root = context.vbox()
        root.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(4))
        val message = context.label("Select a table to edit it here.", 13f, Palette.secondary, italic = true)
        message.gravity = Gravity.CENTER
        message.setPadding(Ui.dp(12), Ui.dp(24), Ui.dp(12), Ui.dp(24))

        val sections = Dropdown(context, "Section")
        val tables = Dropdown(context, "Table")
        val selectors = context.hbox()
        selectors.addView(sections, LinearLayout.LayoutParams(0, WRAP, 1f))
        selectors.addView(tables, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.leftMargin = Ui.dp(4) })
        val elementName = context.label("", 13f, Palette.primary)
        elementName.gravity = Gravity.CENTER
        elementName.setPadding(0, Ui.dp(4), 0, Ui.dp(2))
        val content = context.vbox()
        val navRow = context.hbox()
        val navHolder = context.hbox()
        val previous = commandButton(context, binder, "Previous", Left, { tool.previous }, 12f)
        val next = commandButton(context, binder, "Next", Right, { tool.next }, 12f)
        navRow.addView(previous)
        navRow.addView(navHolder, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.leftMargin = Ui.dp(4); it.rightMargin = Ui.dp(4) })
        navRow.addView(next)
        val elementSelector = ElementViews.comboDropdown(context, binder, tool.currentElementSelector, "Element")
        navHolder.addView(elementSelector, LinearLayout.LayoutParams(MATCH, WRAP))

        val usesButton = context.angleButton("Show Uses", Out, size = 12f) { Engine.post { tool.usageOptionsOpen = !tool.usageOptionsOpen } }
        val usesBox = context.vbox()
        val usesChild = binder.child()

        val filterRow = context.hbox()
        filterRow.addView(context.label("Filter", 13f, Palette.secondary), LinearLayout.LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(6) })
        val filter = context.textBox(size = 13f)
        binder.bindText(filter, tool, "fieldFilter", { tool.fieldFilter }, { tool.fieldFilter = it })
        filterRow.addView(filter, LinearLayout.LayoutParams(0, WRAP, 1f))
        val group = CheckRow(context, "Group Similar Fields", false)
        binder.bindChecked(group, tool, "useMultiFieldFeature", { tool.useMultiFieldFeature }, { tool.useMultiFieldFeature = it })

        val appendRow = context.hbox()
        appendRow.gravity = Gravity.CENTER
        val count = context.textBox(size = 13f, inputType = InputType.TYPE_CLASS_NUMBER)
        count.minimumWidth = Ui.dp(52)
        count.gravity = Gravity.CENTER
        binder.watch(tool, "addCount") {
            val text = tool.addCount.toString()
            if (count.text.toString() != text) count.setText(text)
        }
        count.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, c: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, c: Int) = Unit
            override fun afterTextChanged(s: android.text.Editable?) {
                val parsed = s?.toString()?.toIntOrNull() ?: return
                if (parsed != Engine.read { tool.addCount }) Engine.post { tool.addCount = parsed }
            }
        })
        val append = commandButton(context, binder, "Add", Out, { tool.append })
        appendRow.addView(append)
        appendRow.addView(count, LinearLayout.LayoutParams(WRAP, WRAP).also { it.leftMargin = Ui.dp(4); it.rightMargin = Ui.dp(4) })
        appendRow.addView(context.label("New", 13f, Palette.primary))
        appendRow.addView(context.iconButton(Icon.Add, 36) { tool.incrementAdd.fire() }.margin(left = 6))
        appendRow.addView(context.iconButton(Icon.Remove, 36) { tool.decrementAdd.fire() })

        val groups = context.vbox()
        val groupsBinder = binder.child()
        var rebuildBinder: Binder? = null

        fun rebuild() {
            rebuildBinder?.dispose()
            val b = groupsBinder.child()
            rebuildBinder = b
            groups.removeAllViews()
            for (g in tool.groups) {
                val gv = context.vbox()
                if (g.displayHeader) {
                    val title = context.label(g.groupName, 18f, Palette.primary)
                    title.gravity = Gravity.CENTER
                    title.setPadding(0, Ui.dp(4), 0, Ui.dp(4))
                    title.setBackgroundColor(Palette.backlight)
                    gv.addView(title, LinearLayout.LayoutParams(MATCH, WRAP))
                }
                for (member in g.members) gv.addView(ElementViews.create(context, b, member), LinearLayout.LayoutParams(MATCH, WRAP))
                groups.addView(gv, LinearLayout.LayoutParams(MATCH, WRAP))
                b.watchCollection(g.members) { }
            }
        }
        // rebuild when the group list or any group's members change
        var subscribed = ArrayList<TableGroupViewModel>()
        binder.watchCollection(tool.groups) {
            rebuild()
            for (g in tool.groups) if (subscribed.none { it === g }) {
                subscribed.add(g)
                binder.watchCollection(g.members) { rebuild() }
            }
        }

        binder.watch(tool, "currentElementName") { elementName.text = tool.currentElementName }
        binder.watch(tool, "tableSections", "selectedTableSection") { sections.setItems(tool.tableSections, tool.selectedTableSection) }
        binder.watch(tool, "tableList", "selectedTableIndex") { tables.setItems(tool.tableList, tool.selectedTableIndex) }
        sections.onSelect = { index -> Engine.post { tool.selectedTableSection = index } }
        tables.onSelect = { index -> Engine.post { tool.selectedTableIndex = index } }
        binder.watch(tool, "hasUsageOptions", "usageOptionsOpen") {
            usesButton.alpha = if (tool.hasUsageOptions) 1f else 0.4f
            usesButton.setTextColor(if (tool.usageOptionsOpen) Palette.accent else Palette.primary)
            usesBox.visibility = if (tool.usageOptionsOpen && tool.hasUsageOptions) View.VISIBLE else View.GONE
        }
        binder.watchCollection(tool.usageChildren) {
            usesBox.removeAllViews()
            usesChild.dispose()
            for (use in tool.usageChildren) usesBox.addView(ElementViews.create(context, binder.child(), use), LinearLayout.LayoutParams(MATCH, WRAP))
        }

        content.addView(selectors, LinearLayout.LayoutParams(MATCH, WRAP))
        content.addView(elementName, LinearLayout.LayoutParams(MATCH, WRAP))
        content.addView(navRow, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(2) })
        content.addView(usesButton, LinearLayout.LayoutParams(WRAP, WRAP).also { it.gravity = Gravity.CENTER_HORIZONTAL; it.topMargin = Ui.dp(4) })
        content.addView(usesBox, LinearLayout.LayoutParams(MATCH, WRAP))
        content.addView(filterRow, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
        content.addView(group, LinearLayout.LayoutParams(WRAP, WRAP).also { it.gravity = Gravity.CENTER_HORIZONTAL; it.topMargin = Ui.dp(4) })
        content.addView(appendRow, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4); it.bottomMargin = Ui.dp(4) })
        content.addView(groups, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(message, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(content, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watch(tool, "enabled", "address") {
            message.visibility = if (tool.enabled) View.GONE else View.VISIBLE
            content.visibility = if (tool.enabled) View.VISIBLE else View.GONE
        }
        return root
    }

    // ---------------------------------------------------------------- text

    fun text(context: Context, binder: Binder, tool: PCSTool): View {
        val root = context.vbox()
        root.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6))
        val top = context.hbox()
        val address = context.label("Address: ", 13f, Palette.primary)
        top.addView(address, LinearLayout.LayoutParams(0, WRAP, 1f))
        val gotoSource = context.angleButton("Goto Source", Right, size = 12f) {
            val items = Engine.read { tool.gotoOptions.toList() }
            ContextMenus.show(context, "Goto Source", items)
        }
        top.addView(gotoSource)
        root.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))
        val message = context.label("", 13f, Palette.primary)
        message.gravity = Gravity.CENTER
        root.addView(message, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
        val checkIsText = commandButton(context, binder, "Show As Text", Out, { tool.checkIsText })
        val insert = commandButton(context, binder, "Insert New Text", Out, { tool.insertText })
        root.addView(checkIsText, LinearLayout.LayoutParams(WRAP, WRAP).also { it.gravity = Gravity.END; it.topMargin = Ui.dp(4) })
        root.addView(insert, LinearLayout.LayoutParams(WRAP, WRAP).also { it.gravity = Gravity.END; it.topMargin = Ui.dp(2) })
        root.addView(context.label("Content:", 13f, Palette.primary), LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(10) })
        val edit = SelectionEditText(context)
        edit.setTextColor(Palette.primary)
        edit.typeface = android.graphics.Typeface.MONOSPACE
        edit.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
        edit.background = BoxDrawable(Palette.backlight, Palette.secondary)
        edit.setPadding(Ui.dp(8), Ui.dp(6), Ui.dp(8), Ui.dp(6))
        edit.gravity = Gravity.TOP or Gravity.START
        edit.minLines = 5
        edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        edit.setHorizontallyScrolling(false)
        binder.bindText(edit, tool, "content", { tool.content }, { tool.content = it })
        edit.onSelection = { start, end ->
            if (edit.hasFocus()) Engine.post {
                tool.contentIndex = minOf(start, end)
                tool.contentSelectionLength = Math.abs(end - start)
            }
        }
        root.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(2) })
        val searchLabel = context.label("Search:", 13f, Palette.primary)
        root.addView(searchLabel, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(10) })
        val searchRow = context.hbox()
        val search = context.textBox(size = 13f)
        binder.bindText(search, tool, "searchText", { tool.searchText }, { tool.searchText = it })
        search.setOnEditorActionListener { _, _, _ ->
            tool.search.fire()
            true
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, WRAP, 1f))
        searchRow.addView(commandButton(context, binder, "Search", Out, { tool.search }).margin(left = 6))
        root.addView(searchRow, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watch(tool, "address", "enabled") {
            address.text = "Address: " + String.format("%X", tool.address)
            edit.isEnabled = tool.enabled
            edit.alpha = if (tool.enabled) 1f else 0.5f
        }
        binder.watch(tool, "showMessage", "message") {
            message.visibility = if (tool.showMessage) View.VISIBLE else View.GONE
            message.text = tool.message
        }
        binder.watch(tool, "gotoOptions") { gotoSource.visibility = if (tool.gotoOptions.size > 0) View.VISIBLE else View.GONE }
        binder.watchCollection(tool.gotoOptions) { gotoSource.visibility = if (tool.gotoOptions.size > 0) View.VISIBLE else View.GONE }
        return root
    }

    // ---------------------------------------------------------------- image

    private fun addressRow(context: Context, binder: Binder, tool: SpriteTool, label: String, property: String, get: () -> String, set: (String) -> Unit, go: () -> ICommand): View {
        val row = context.hbox()
        row.addView(context.label(label, 13f, Palette.primary), LinearLayout.LayoutParams(0, WRAP, 1f))
        val edit = context.textBox(size = 13f, mono = true)
        binder.bindText(edit, tool, property, get, set)
        edit.setOnEditorActionListener { _, _, _ ->
            go().fire()
            true
        }
        row.addView(edit, LinearLayout.LayoutParams(0, WRAP, 1f))
        return row
    }

    fun image(context: Context, binder: Binder, tool: SpriteTool): View {
        val root = context.vbox()
        root.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6))
        val actions = FlowLayout(context)
        actions.hGap = Ui.dp(6)
        actions.vGap = Ui.dp(4)
        actions.addView(context.angleButton("Import", Left) { tool.importPair.fire(AppState.fileSystem) })
        actions.addView(context.angleButton("Edit", Out) { tool.openInImageTab.fire(AppState.fileSystem) })
        actions.addView(context.angleButton("Export", Right) {
            if (Engine.read { tool.canExportMany }) {
                Dialogs.pick(context, "Export", listOf("Single Page", "All Pages"), -1) { which ->
                    if (which == 0) tool.exportPair.fire(AppState.fileSystem) else tool.exportMany.fire(AppState.fileSystem)
                }
            } else tool.exportPair.fire(AppState.fileSystem)
        })
        root.addView(actions, LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(addressRow(context, binder, tool, "Image Address:", "spriteAddressText", { tool.spriteAddressText }, { tool.spriteAddressText = it }, { tool.gotoSpriteAddress }), LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(10) })

        val props = context.vbox()
        val is256 = CheckRow(context, "256 Color Image", false)
        binder.bindChecked(is256, tool, "spriteIs256Color", { tool.spriteIs256Color }, { tool.spriteIs256Color = it })
        val tilemap = CheckRow(context, "Tilemap", false)
        binder.bindChecked(tilemap, tool, "spriteIsTilemap", { tool.spriteIsTilemap }, { tool.spriteIsTilemap = it })
        val checks = context.hbox()
        checks.addView(is256, LinearLayout.LayoutParams(0, WRAP, 1f))
        checks.addView(tilemap, LinearLayout.LayoutParams(0, WRAP, 1f))
        props.addView(checks)
        val sizeRow = context.hbox()
        sizeRow.addView(context.label("Tile Size:", 13f, Palette.primary), LinearLayout.LayoutParams(0, WRAP, 1f))
        val size = context.textBox(size = 13f, mono = true)
        binder.bindText(size, tool, "spriteWidthHeight", { tool.spriteWidthHeight }, { tool.spriteWidthHeight = it })
        sizeRow.addView(size, LinearLayout.LayoutParams(0, WRAP, 1f))
        props.addView(sizeRow, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(2) })
        val hint = context.label("", 12f, Palette.secondary, italic = true)
        props.addView(hint, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(2) })
        root.addView(props, LinearLayout.LayoutParams(MATCH, WRAP))
        val noSprite = context.label("Could not find sprite data starting at that address.", 12f, Palette.error, italic = true)
        root.addView(noSprite, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(2) })
        val pixels = PixelView(context)
        pixels.scaleDp = 1f
        pixels.maxWidthDp = 320
        root.addView(pixels, LinearLayout.LayoutParams(WRAP, WRAP).also { it.gravity = Gravity.CENTER_HORIZONTAL; it.topMargin = Ui.dp(6) })
        val spritePages = context.hbox()
        spritePages.addView(commandButton(context, binder, "Previous", Left, { tool.previousSpritePage }, 12f))
        spritePages.addView(context.fill())
        spritePages.addView(commandButton(context, binder, "Next", Right, { tool.nextSpritePage }, 12f))
        root.addView(spritePages, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watch(tool, "pixelData", "pixelWidth", "pixelHeight", "spriteScale") { pixels.setImage(tool) }
        binder.watch(tool, "showSpriteProperties", "spritePaletteHint", "showNoSpriteAnchorMessage", "hasMultipleSpritePages") {
            props.visibility = if (tool.showSpriteProperties) View.VISIBLE else View.GONE
            hint.text = tool.spritePaletteHint
            hint.visibility = if (tool.spritePaletteHint.isEmpty()) View.GONE else View.VISIBLE
            noSprite.visibility = if (tool.showNoSpriteAnchorMessage) View.VISIBLE else View.GONE
            spritePages.visibility = if (tool.hasMultipleSpritePages) View.VISIBLE else View.GONE
        }

        root.addView(addressRow(context, binder, tool, "Palette Address:", "paletteAddressText", { tool.paletteAddressText }, { tool.paletteAddressText = it }, { tool.gotoPaletteAddress }), LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(14) })
        val paletteProps = context.vbox()
        val is256Palette = CheckRow(context, "256 Color Palette", false)
        binder.bindChecked(is256Palette, tool, "paletteIs256Color", { tool.paletteIs256Color }, { tool.paletteIs256Color = it })
        paletteProps.addView(is256Palette)
        val pagesRow = context.hbox()
        pagesRow.addView(context.label("Pages:", 13f, Palette.primary), LinearLayout.LayoutParams(0, WRAP, 1f))
        val pagesValue = context.label("", 13f, Palette.accent)
        pagesRow.addView(pagesValue, LinearLayout.LayoutParams(0, WRAP, 1f))
        paletteProps.addView(pagesRow)
        root.addView(paletteProps, LinearLayout.LayoutParams(MATCH, WRAP))
        val noPalette = context.label("Could not find palette data starting at that address.", 12f, Palette.error, italic = true)
        root.addView(noPalette, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(2) })
        root.addView(PaletteView(context, tool.colors, binder.child()), LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(6) })
        val palettePagesRow = context.hbox()
        palettePagesRow.addView(commandButton(context, binder, "Previous", Left, { tool.previousPalettePage }, 12f))
        palettePagesRow.addView(context.fill())
        palettePagesRow.addView(commandButton(context, binder, "Next", Right, { tool.nextPalettePage }, 12f))
        root.addView(palettePagesRow, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watch(tool, "showPaletteProperties", "palettePages", "showNoPaletteAnchorMessage", "hasMultiplePalettePages") {
            paletteProps.visibility = if (tool.showPaletteProperties) View.VISIBLE else View.GONE
            pagesValue.text = tool.palettePages
            noPalette.visibility = if (tool.showNoPaletteAnchorMessage) View.VISIBLE else View.GONE
            palettePagesRow.visibility = if (tool.hasMultiplePalettePages) View.VISIBLE else View.GONE
        }
        return root
    }

    // ---------------------------------------------------------------- code

    internal fun codeEditor(context: Context, binder: Binder, editor: dev.hexmaniac.core.viewmodels.TextEditorViewModel, readOnly: Boolean, fontSize: Float): View {
        val edit = context.textBox(mono = true, size = fontSize)
        edit.isSingleLine = false
        edit.setHorizontallyScrolling(true)
        edit.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        edit.gravity = Gravity.TOP or Gravity.START
        edit.minLines = 4
        edit.isEnabled = !readOnly
        binder.bindText(edit, editor, "content", { editor.content }, { editor.content = it })
        return edit
    }

    fun code(context: Context, binder: Binder, tool: CodeTool): View {
        val root = context.vbox()
        root.setPadding(Ui.dp(6), Ui.dp(6), Ui.dp(6), Ui.dp(6))
        val modeRow = context.hbox()
        modeRow.addView(context.label("Code Type", 13f, Palette.primary), LinearLayout.LayoutParams(0, WRAP, 1f))
        val modes = CodeMode.entries.toList()
        val mode = Dropdown(context, "Code Type")
        mode.setItems(modes.map { it.name }, modes.indexOf(tool.mode))
        mode.onSelect = { index -> Engine.post { tool.mode = modes[index] } }
        binder.watch(tool, "mode") { mode.setSelection(modes.indexOf(tool.mode)) }
        modeRow.addView(mode, LinearLayout.LayoutParams(0, WRAP, 1.4f))
        root.addView(modeRow, LinearLayout.LayoutParams(MATCH, WRAP))

        val error = context.label("", 12f, Palette.error)
        root.addView(error, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
        val thumb = context.angleButton("Insert Thumb Hook", Out) { Engine.post { tool.repointThumb() } }
        root.addView(thumb, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
        val body = context.vbox()
        root.addView(body, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
        var bodyBinder = binder.child()

        fun rebuild() {
            bodyBinder.dispose()
            bodyBinder = binder.child()
            val b = bodyBinder
            body.removeAllViews()
            val font = 12f
            if (tool.useSingleContent) {
                body.addView(codeEditor(context, b, tool.editor, tool.isReadOnly, font), LinearLayout.LayoutParams(MATCH, WRAP))
            } else if (tool.useMultiContent) {
                for (item in tool.contents) {
                    val box = context.vbox()
                    val header = context.hbox()
                    val label = context.label(item.label, 13f, Palette.secondary)
                    header.addView(label, LinearLayout.LayoutParams(0, WRAP, 1f))
                    if (item.canGotoAddress) header.addView(context.angleButton("Goto", Right, size = 11f) { item.gotoAddressCommand.fire() })
                    if (item.canGotoSource) header.addView(context.angleButton("Source", Right, size = 11f) { item.gotoSourceCommand.fire() }.margin(left = 4))
                    if (item.canFindUses) header.addView(context.angleButton("Uses", Right, size = 11f) { item.findUsesCommand.fire() }.margin(left = 4))
                    box.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))
                    box.addView(codeEditor(context, b, item.editor, tool.isReadOnly, font), LinearLayout.LayoutParams(MATCH, WRAP))
                    val tools = context.hbox()
                    if (item.canInsertVar) tools.addView(context.angleButton("Insert Var", Out, size = 11f) { Engine.post { item.insertVar() } })
                    if (item.canInsertFlag) tools.addView(context.angleButton("Insert Flag", Out, size = 11f) { Engine.post { item.insertFlag() } }.margin(left = 4))
                    box.addView(tools, LinearLayout.LayoutParams(MATCH, WRAP))
                    val itemError = context.label("", 12f, Palette.error)
                    box.addView(itemError, LinearLayout.LayoutParams(MATCH, WRAP))
                    b.watch(item, "hasError", "errorText") {
                        itemError.text = item.errorText ?: ""
                        itemError.visibility = if (item.hasError) View.VISIBLE else View.GONE
                    }
                    body.addView(box, LinearLayout.LayoutParams(MATCH, WRAP).also { it.bottomMargin = Ui.dp(8) })
                }
            }
        }
        binder.watch(tool, "useSingleContent", "useMultiContent", "content", "isReadOnly") { rebuild() }
        binder.watchCollection(tool.contents) { rebuild() }
        binder.watch(tool, "mode", "showErrorText", "errorText", "canRepointThumb") {
            error.text = tool.errorText ?: ""
            error.visibility = if (tool.showErrorText) View.VISIBLE else View.GONE
            thumb.visibility = if (tool.mode == CodeMode.Thumb && tool.canRepointThumb) View.VISIBLE else View.GONE
        }
        return root
    }

    // ---------------------------------------------------------------- logs

    fun log(context: Context, binder: Binder, tool: LogTool): View {
        val edit = context.textBox(mono = true, size = 12f)
        edit.isSingleLine = false
        edit.inputType = InputType.TYPE_NULL
        edit.setTextIsSelectable(true)
        edit.gravity = Gravity.TOP or Gravity.START
        binder.watch(tool, "allLogText", "logMessages") { edit.setText(tool.allLogText) }
        val box = context.vbox()
        box.setPadding(Ui.dp(4), Ui.dp(4), Ui.dp(4), Ui.dp(4))
        box.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP))
        return box
    }
}

/** The row of tool buttons (Table, Text, Image, Code, Logs). Tapping the selected one closes the tool panel. */
class ToolTabsRow(context: Context, private val tray: IToolTrayViewModel, binder: Binder) : LinearLayout(context) {
    private val buttons = ArrayList<android.widget.TextView>()

    init {
        orientation = HORIZONTAL
        gravity = android.view.Gravity.CENTER_VERTICAL
        setBackgroundColor(Palette.backlight)
        val names = listOf("Table", "Text", "Image", "Code", "Logs")
        for ((i, name) in names.withIndex()) {
            val button = context.angleButton(name, AngleDrawable.Direction.Out, size = 12f) {
                Engine.post {
                    if (tray.selectedIndex == i) {
                        tray.hideCommand.execute(null)
                    } else {
                        val command = when (i) {
                            0 -> tray.tableToolCommand
                            1 -> tray.stringToolCommand
                            2 -> tray.spriteToolCommand
                            3 -> tray.codeToolCommand
                            else -> (tray as? dev.hexmaniac.core.viewmodels.tools.ToolTray)?.logToolCommand
                        }
                        if (command != null && command.canExecute(null)) command.execute(null)
                    }
                }
            }
            button.minimumHeight = Ui.dp(32)
            button.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(2))
            buttons.add(button)
            addView(button, LayoutParams(0, WRAP, 1f).also { it.setMargins(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2)) })
        }
        binder.watch(tray, "selectedIndex", "selectedTool") {
            for ((i, button) in buttons.withIndex()) button.setTextColor(if (i == tray.selectedIndex) Palette.accent else Palette.primary)
        }
    }
}

/** The panel of the selected tool; hidden while no tool is selected. */
class ToolPanelView(context: Context, private val tray: IToolTrayViewModel, private val binder: Binder) : LinearLayout(context) {
    private val holder = android.widget.FrameLayout(context)
    private var shownTool: Any? = null
    private var shownBinder: Binder? = null

    init {
        orientation = VERTICAL
        setBackgroundColor(Palette.background)
        addView(context.vscroll(holder), LayoutParams(MATCH, MATCH))
        binder.watch(tray, "selectedIndex", "selectedTool") { show() }
    }

    private fun show() {
        val index = tray.selectedIndex
        visibility = if (index < 0) View.GONE else View.VISIBLE
        val tool = if (index < 0) null else tray.selectedTool
        if (tool === shownTool) return
        shownTool = tool
        shownBinder?.dispose()
        holder.removeAllViews()
        if (tool == null) return
        val b = binder.child()
        shownBinder = b
        val view: View? = when (tool) {
            is TableTool -> ToolPanels.table(context, b, tool)
            is PCSTool -> ToolPanels.text(context, b, tool)
            is SpriteTool -> ToolPanels.image(context, b, tool)
            is CodeTool -> ToolPanels.code(context, b, tool)
            is LogTool -> ToolPanels.log(context, b, tool)
            else -> null
        }
        if (view != null) holder.addView(view, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
    }
}
