package dev.hexmaniac.android.ui

import android.app.Dialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import dev.hexmaniac.core.viewmodels.images.IPixelViewModel

/** A check box in the style of the desktop app: a small square with a check mark, followed by its text. */
class CheckRow(context: Context, text: CharSequence, checked: Boolean = false) : LinearLayout(context) {
    private val box = object : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            val s = Ui.dpf(1f)
            val rect = RectF(s, s, width - s, height - s)
            paint.style = Paint.Style.FILL
            paint.color = Palette.backlight
            canvas.drawRect(rect, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = s
            paint.color = if (isEnabled) Palette.secondary else Palette.backlight
            canvas.drawRect(rect, paint)
            if (this@CheckRow.isChecked) {
                paint.style = Paint.Style.FILL
                paint.color = if (isEnabled) Palette.accent else Palette.secondary
                Icon.Check.draw(canvas, paint, width * .2f, height * .22f, width * .82f, height * .78f)
            }
        }
    }
    val label: TextView = context.label(text)
    var onChange: ((Boolean) -> Unit)? = null

    var isChecked: Boolean = checked
        set(value) {
            if (field == value) return
            field = value
            box.invalidate()
        }

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        minimumHeight = Ui.dp(36)
        setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(8), Ui.dp(2))
        addView(box, LayoutParams(Ui.dp(20), Ui.dp(20)))
        addView(label, LayoutParams(WRAP, WRAP).also { it.leftMargin = Ui.dp(8) })
        isClickable = true
        setOnClickListener {
            isChecked = !isChecked
            onChange?.invoke(isChecked)
        }
    }

    fun setCheckedSilently(value: Boolean) {
        isChecked = value
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        box.isEnabled = enabled
        label.setTextColor(if (enabled) Palette.primary else Palette.secondary)
        box.invalidate()
    }
}

/** Shows one choice out of many, in the style of the desktop app's combo boxes. Tapping opens a searchable list. */
class Dropdown(context: Context, private val title: String = "") : TextView(context) {
    private var items: List<String> = emptyList()
    var selectedIndex: Int = -1
        private set
    var onSelect: ((Int) -> Unit)? = null

    init {
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        setTextColor(Palette.primary)
        gravity = Gravity.CENTER_VERTICAL
        minHeight = Ui.dp(34)
        setPadding(Ui.dp(8), Ui.dp(4), Ui.dp(26), Ui.dp(4))
        background = BoxDrawable(Palette.backlight, Palette.secondary)
        isSingleLine = true
        ellipsize = android.text.TextUtils.TruncateAt.END
        isClickable = true
        setOnClickListener {
            Dialogs.pick(context, title, items, selectedIndex) { index ->
                setSelection(index)
                onSelect?.invoke(index)
            }
        }
    }

    fun setItems(newItems: List<String>, selected: Int) {
        items = newItems
        setSelection(selected)
    }

    fun setSelection(index: Int) {
        selectedIndex = index
        text = if (index in items.indices) items[index] else ""
    }

    private val chevron = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        chevron.color = Palette.secondary
        val size = Ui.dpf(10f)
        val x = width - Ui.dpf(8f) - size
        val y = (height - size / 2f) / 2f
        Icon.Chevron.draw(canvas, chevron, x, y, x + size, y + size / 2f)
    }
}

/** Draws an [IPixelViewModel] (GBA 15 bit colors) with nearest-neighbor scaling. */
class PixelView(context: Context) : View(context) {
    private var bitmap: Bitmap? = null
    private val paint = Paint().apply { isFilterBitmap = false; isAntiAlias = false; isDither = false }
    private val checker = Paint()
    var scaleDp: Float = 1f
        set(value) {
            field = value
            requestLayout()
            invalidate()
        }
    var maxWidthDp: Int = 0
    var minSideDp: Int = 0
    var transparentColor: Int? = null
    var trueTransparency: Boolean = false
    var showGrid: Boolean = false

    private var pw = 0
    private var ph = 0

    /** Call with the engine lock held (the pixel data belongs to the view-model). */
    fun setImage(vm: IPixelViewModel?) {
        if (vm == null) {
            bitmap = null
            pw = 0
            ph = 0
            requestLayout()
            invalidate()
            return
        }
        val width = vm.pixelWidth
        val height = vm.pixelHeight
        val data = vm.pixelData
        if (width <= 0 || height <= 0 || data.size < width * height) {
            bitmap = null
            pw = 0
            ph = 0
            requestLayout()
            invalidate()
            return
        }
        val transparent = vm.transparent.toInt()
        val hasTransparent = transparent != -1
        val colors = IntArray(width * height)
        val replace = transparentColor
        for (i in colors.indices) {
            val c = data[i].toInt()
            if (hasTransparent && c == transparent) {
                colors[i] = if (trueTransparency) 0 else replace ?: toArgb(c)
            } else {
                colors[i] = toArgb(c)
            }
        }
        if (showGrid && vm.spriteScale >= 4) Unit
        var target = bitmap
        if (target == null || target.width != width || target.height != height) {
            target?.recycle()
            target = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bitmap = target
        }
        target!!.setPixels(colors, 0, width, 0, 0, width, height)
        val newScale = vm.spriteScale.toFloat().takeIf { it > 0f } ?: 1f
        if (pw != width || ph != height || scaleDp != newScale) {
            pw = width
            ph = height
            scaleDp = newScale
        }
        requestLayout()
        invalidate()
    }

    private fun toArgb(c: Int): Int {
        val r = (c shr 10) and 31
        val g = (c shr 5) and 31
        val b = c and 31
        return Color.rgb(r * 255 / 31, g * 255 / 31, b * 255 / 31)
    }

    private fun effectiveScale(): Float {
        var s = scaleDp
        if (maxWidthDp > 0 && pw > 0) {
            val limit = maxWidthDp.toFloat() / pw
            if (s > limit) s = limit
        }
        return s
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = effectiveScale()
        var w = (pw * s * Ui.density).toInt()
        var h = (ph * s * Ui.density).toInt()
        w = maxOf(w, Ui.dp(minSideDp))
        h = maxOf(h, Ui.dp(minSideDp))
        setMeasuredDimension(resolveSize(w + paddingLeft + paddingRight, widthMeasureSpec), resolveSize(h + paddingTop + paddingBottom, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val b = bitmap ?: return
        val s = effectiveScale() * Ui.density
        val dw = (pw * s).toInt()
        val dh = (ph * s).toInt()
        val left = paddingLeft + (width - paddingLeft - paddingRight - dw) / 2
        val top = paddingTop + (height - paddingTop - paddingBottom - dh) / 2
        canvas.drawBitmap(b, Rect(0, 0, pw, ph), Rect(left, top, left + dw, top + dh), paint)
        if (showGrid && s >= Ui.density * 4f) {
            val line = Paint().apply { color = Palette.alpha(Palette.secondary, 150); strokeWidth = 1f }
            var x = 0f
            while (x <= dw) { canvas.drawLine(left + x, top.toFloat(), left + x, (top + dh).toFloat(), line); x += 8 * s }
            var y = 0f
            while (y <= dh) { canvas.drawLine(left.toFloat(), top + y, (left + dw).toFloat(), top + y, line); y += 8 * s }
        }
    }
}

/** Modal dialogs in the colors of the app. */
object Dialogs {
    fun create(context: Context, content: View, widthDp: Int = 420, cancelable: Boolean = true): Dialog {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val frame = FrameLayout(context)
        frame.setBackgroundColor(Palette.background)
        frame.setPadding(Ui.dp(1), Ui.dp(1), Ui.dp(1), Ui.dp(1))
        val inner = FrameLayout(context)
        inner.setBackgroundColor(Palette.background)
        inner.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        frame.addView(inner, FrameLayout.LayoutParams(MATCH, WRAP))
        frame.background = BoxDrawable(Palette.background, Palette.accent)
        dialog.setContentView(frame)
        dialog.setCancelable(cancelable)
        dialog.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            val metrics = context.resources.displayMetrics
            val width = minOf(Ui.dp(widthDp), (metrics.widthPixels * 0.94f).toInt())
            setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        }
        return dialog
    }

    fun title(context: Context, text: String): View = context.label(text, 16f, Palette.primary, bold = true).also {
        it.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(4))
    }

    /** A filterable list; resumes with the index in [items] (not the filtered index). */
    fun pick(context: Context, title: String, items: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val box = context.vbox()
        if (title.isNotEmpty()) box.addView(title(context, title))
        var shown = items.indices.toList()
        val list = ListView(context)
        list.divider = null
        list.setBackgroundColor(Palette.background)
        val dialog = create(context, box, 360)
        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(position: Int): Any = items[shown[position]]
            override fun getItemId(position: Int): Long = shown[position].toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val row = (convertView as? TextView) ?: context.label("", 15f).also {
                    it.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10))
                    it.layoutParams = ViewGroup.LayoutParams(MATCH, WRAP)
                    it.isSingleLine = true
                    it.ellipsize = android.text.TextUtils.TruncateAt.END
                }
                val index = shown[position]
                row.text = items[index]
                row.setTextColor(if (index == selected) Palette.accent else Palette.primary)
                row.setBackgroundColor(if (index == selected) Palette.backlight else Color.TRANSPARENT)
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ ->
            dialog.dismiss()
            onPick(shown[position])
        }
        if (items.size > 12) {
            val filter = context.textBox(hint = "Filter")
            filter.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
                override fun afterTextChanged(s: Editable?) {
                    val query = s?.toString()?.trim() ?: ""
                    shown = if (query.isEmpty()) items.indices.toList() else items.indices.filter { items[it].contains(query, ignoreCase = true) }
                    adapter.notifyDataSetChanged()
                }
            })
            box.addView(filter, lp(MATCH, WRAP).also { it.setMargins(Ui.dp(10), Ui.dp(6), Ui.dp(10), Ui.dp(6)) })
        }
        val height = minOf(Ui.dp(420), context.resources.displayMetrics.heightPixels * 6 / 10)
        box.addView(list, lp(MATCH, height))
        dialog.show()
        if (selected in items.indices) list.setSelection(maxOf(0, selected - 3))
    }

    /** Single line text request. */
    fun text(context: Context, title: String, prompt: String, initial: String = "", onResult: (String?) -> Unit) {
        val box = context.vbox()
        box.setPadding(Ui.dp(14), Ui.dp(12), Ui.dp(14), Ui.dp(10))
        if (title.isNotEmpty()) box.addView(context.label(title, 16f, Palette.primary, bold = true))
        box.addView(context.label(prompt, 14f, Palette.primary).also { it.setPadding(0, Ui.dp(8), 0, Ui.dp(8)) })
        val edit = context.textBox(initial)
        box.addView(edit, lp(MATCH, WRAP))
        val buttons = context.hbox()
        buttons.gravity = Gravity.END
        var answered = false
        val dialog = create(context, box, 420)
        fun finish(value: String?) {
            if (answered) return
            answered = true
            dialog.dismiss()
            onResult(value)
        }
        buttons.addView(context.angleButton("OK", AngleDrawable.Direction.Right, Palette.accent, Palette.background) { finish(edit.text.toString()) })
        buttons.addView(context.spacer(8))
        buttons.addView(context.angleButton("Cancel") { finish(null) })
        box.addView(buttons, lp(MATCH, WRAP).also { it.topMargin = Ui.dp(12) })
        edit.setOnEditorActionListener { _, _, _ -> finish(edit.text.toString()); true }
        dialog.setOnCancelListener { finish(null) }
        dialog.setOnDismissListener { finish(null) }
        dialog.show()
        edit.requestFocus()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }
}
