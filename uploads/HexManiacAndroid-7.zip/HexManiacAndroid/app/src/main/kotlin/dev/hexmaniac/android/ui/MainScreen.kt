package dev.hexmaniac.android.ui

import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import dev.hexmaniac.android.MainActivity
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.system.ICommand
import dev.hexmaniac.core.system.INotifyPropertyChanged
import dev.hexmaniac.core.viewmodels.DexReorderTab
import dev.hexmaniac.core.viewmodels.EditorViewModel
import dev.hexmaniac.core.viewmodels.ITabContent
import dev.hexmaniac.core.viewmodels.ImageEditorViewModel
import dev.hexmaniac.core.viewmodels.IViewPort
import dev.hexmaniac.core.viewmodels.ViewPort
import dev.hexmaniac.core.viewmodels.map.MapEditorViewModel

/** Creates the view that shows one tab. */
object TabViews {
    fun create(context: Context, tab: ITabContent, editor: EditorViewModel, binder: Binder): View = when (tab) {
        is IViewPort -> HexTabView(context, tab, editor, binder)
        is ImageEditorViewModel -> ImageEditorView(context, tab, binder)
        is MapEditorViewModel -> MapEditorView(context, tab, binder)
        is DexReorderTab -> DexReorderView(context, tab, binder)
        else -> context.label(tab.name, 14f, Palette.secondary).also { it.gravity = Gravity.CENTER }
    }
}

/** The whole window: toolbar, tabs, search bars, message bars and the selected tab. Built under the engine lock. */
class MainScreen(private val activity: MainActivity, private val editor: EditorViewModel) {
    val root = FrameLayout(activity)
    private val context: Context = activity
    private val binder = Binder()
    private val tabViews = HashMap<ITabContent, Pair<View, Binder>>()
    private val content = FrameLayout(activity)
    private val tabsRow = context.hbox()
    private val widthControls = context.hbox()
    private var widthBinder: Binder? = null
    private val gotoPanel = FrameLayout(activity)
    private var shownTab: ITabContent? = null
    private var startScreen: View? = null

    init {
        root.setBackgroundColor(Palette.background)
        val column = context.vbox()
        column.addView(buildToolbar(), LinearLayout.LayoutParams(MATCH, WRAP))
        column.addView(context.hscroll(tabsRow), LinearLayout.LayoutParams(MATCH, WRAP))
        column.addView(buildFindBar(), LinearLayout.LayoutParams(MATCH, WRAP))
        column.addView(buildHexConverterBar(), LinearLayout.LayoutParams(MATCH, WRAP))
        column.addView(buildMessageBar(), LinearLayout.LayoutParams(MATCH, WRAP))
        column.addView(buildErrorBar(), LinearLayout.LayoutParams(MATCH, WRAP))
        val holder = FrameLayout(activity)
        holder.addView(content, FrameLayout.LayoutParams(MATCH, MATCH))
        holder.addView(buildGoto(), FrameLayout.LayoutParams(MATCH, MATCH))
        column.addView(holder, LinearLayout.LayoutParams(MATCH, 0, 1f))
        column.addView(buildAutomationPanel(), LinearLayout.LayoutParams(MATCH, WRAP))
        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(buildOverlayText(), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).also { it.bottomMargin = Ui.dp(120) })
        binder.watchCollection(editor) { rebuildTabs() }
        binder.watch(editor, "selectedIndex", "count") {
            rebuildTabs()
            showSelectedTab()
        }
    }

    fun dispose() {
        binder.dispose()
        widthBinder?.dispose()
        for ((_, entry) in tabViews) entry.second.dispose()
        tabViews.clear()
    }

    fun focusContent() {
        (content.getChildAt(0) as? HexTabView)?.focusHex()
    }

    // ---------------------------------------------------------------- toolbar

    private fun iconCommand(icon: Icon, command: () -> ICommand?, parameter: () -> Any? = { null }): IconView {
        val button = context.iconButton(icon, 40, Palette.primary) { command().fire(parameter()) }
        binder.watchCommand(command()) {
            val c = command()
            button.alpha = if (c != null && c.canExecute(parameter())) 1f else 0.35f
        }
        return button
    }

    private fun buildToolbar(): View {
        val bar = context.hbox()
        bar.setBackgroundColor(Palette.background)
        bar.addView(context.iconButton(Icon.Menu, 44, Palette.primary) { activity.showMenu() })
        bar.addView(iconCommand(Icon.LeftArrow, { editor.back }))
        bar.addView(iconCommand(Icon.RightArrow, { editor.forward }))
        val save = iconCommand(Icon.Save, { editor.save })
        bar.addView(save)
        bar.addView(iconCommand(Icon.UndoArrow, { editor.undo }))
        bar.addView(iconCommand(Icon.RedoArrow, { editor.redo }))
        bar.addView(iconCommand(Icon.Home, { editor.gotoViewModel.showGoto }))
        bar.addView(iconCommand(Icon.Search, { editor.showFind }, { true }))
        bar.addView(iconCommand(Icon.Play, { editor.runFile }, { AppState.fileSystem }))
        bar.addView(widthControls, LinearLayout.LayoutParams(WRAP, WRAP).also { it.leftMargin = Ui.dp(6) })
        val scroll = context.hscroll(bar)
        val frame = context.vbox()
        frame.addView(scroll, LinearLayout.LayoutParams(MATCH, WRAP))
        frame.addView(context.divider(Palette.backlight))
        return frame
    }

    private fun toggleButton(binder: Binder, text: String?, icon: Icon?, vm: INotifyPropertyChanged, property: String, get: () -> Boolean, set: (Boolean) -> Unit): View {
        val view: View
        val setColor: (Int) -> Unit
        if (icon != null) {
            val v = context.iconButton(icon, 34, Palette.secondary) { Engine.post { set(!get()) } }
            view = v
            setColor = { v.setIconTint(it) }
        } else {
            val v = context.angleButton(text ?: "", size = 12f) { Engine.post { set(!get()) } }
            v.minimumHeight = Ui.dp(28)
            view = v
            setColor = { v.setTextColor(it) }
        }
        binder.watch(vm, property) { setColor(if (get()) Palette.accent else Palette.secondary) }
        return view
    }

    private fun bindWidthControls() {
        widthBinder?.dispose()
        widthControls.removeAllViews()
        val tab = editor.selectedTab as? ViewPort ?: return
        if (!editor.showWidthOptions) return
        val b = binder.child()
        widthBinder = b
        widthControls.addView(context.label("Row Width:", 12f, Palette.secondary), LinearLayout.LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(4) })
        val edit = context.textBox(size = 12f, mono = true, inputType = InputType.TYPE_CLASS_NUMBER)
        edit.minHeight = Ui.dp(28)
        edit.setPadding(Ui.dp(4), Ui.dp(2), Ui.dp(4), Ui.dp(2))
        edit.gravity = Gravity.END
        b.bindText(edit, tab, "preferredWidth", { tab.preferredWidth.toString() }, { text -> text.toIntOrNull()?.let { tab.preferredWidth = it } })
        widthControls.addView(edit, LinearLayout.LayoutParams(Ui.dp(52), WRAP))
        widthControls.addView(toggleButton(b, null, Icon.ArrowsLeftRight, tab, "stretchData", { tab.stretchData }, { tab.stretchData = it }))
        widthControls.addView(toggleButton(b, "Auto", null, tab, "autoAdjustDataWidth", { tab.autoAdjustDataWidth }, { tab.autoAdjustDataWidth = it }))
        widthControls.addView(toggleButton(b, null, Icon.Multiple, tab, "allowMultipleElementsPerLine", { tab.allowMultipleElementsPerLine }, { tab.allowMultipleElementsPerLine = it }))
    }

    // ---------------------------------------------------------------- tabs

    private fun rebuildTabs() {
        tabsRow.removeAllViews()
        tabsRow.setBackgroundColor(Palette.background)
        val tabs = editor.toList()
        for ((i, tab) in tabs.withIndex()) {
            val selected = i == editor.selectedIndex
            val pill = context.hbox()
            pill.setPadding(Ui.dp(10), Ui.dp(2), Ui.dp(2), Ui.dp(2))
            pill.background = AngleDrawable(if (selected) Palette.backlight else Palette.background, if (selected) Palette.accent else Palette.secondary, AngleDrawable.Direction.Out)
            val name = context.label(tab.name, 13f, if (selected) Palette.primary else Palette.secondary)
            name.maxWidth = Ui.dp(200)
            name.isSingleLine = true
            name.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            pill.addView(name)
            val close = context.iconButton(Icon.Exit, 30, Palette.secondary) { tab.close.fire(AppState.fileSystem) }
            pill.addView(close)
            pill.setOnClickListener { Engine.post { editor.selectedIndex = i } }
            pill.setOnLongClickListener {
                showTabMenu(tab, i)
                true
            }
            tabsRow.addView(pill, LinearLayout.LayoutParams(WRAP, Ui.dp(36)).also { it.setMargins(Ui.dp(2), Ui.dp(2), Ui.dp(2), Ui.dp(2)) })
            val vm = tab as? INotifyPropertyChanged
            if (vm != null) binder.watch(vm, "name") { name.text = tab.name }
        }
        val plus = context.iconButton(Icon.Add, 34, Palette.secondary) {
            val recent = Engine.read { editor.recentFileViewModels.toList() }
            val items = ArrayList<String>()
            items.add("New")
            items.add("Open")
            for (file in recent.take(8)) items.add(file.shortName)
            Dialogs.pick(context, "Add Tab", items, -1) { which ->
                when (which) {
                    0 -> editor.new.fire()
                    1 -> editor.open.fire()
                    else -> recent[which - 2].open.fire()
                }
            }
        }
        tabsRow.addView(plus)
        bindWidthControls()
    }

    private fun showTabMenu(tab: ITabContent, index: Int) {
        val items = ArrayList<IContextItemLike>()
        items.add(IContextItemLike("Duplicate Tab", { tab.canDuplicate }) { Engine.post { tab.duplicate() } })
        items.add(IContextItemLike("Diff with Left", { Engine.read { tab.diffLeft.canExecute(null) } }) { tab.diffLeft.fire() })
        items.add(IContextItemLike("Diff with Right", { Engine.read { tab.diffRight.canExecute(null) } }) { tab.diffRight.fire() })
        items.add(IContextItemLike("Make IPS Patch, this -> Right", { Engine.read { tab.canIpsPatchRight } }) { Engine.post { tab.ipsPatchRight() } })
        items.add(IContextItemLike("Make UPS Patch, this -> Right", { Engine.read { tab.canUpsPatchRight } }) { Engine.post { tab.upsPatchRight() } })
        items.add(IContextItemLike("Close", { true }) { tab.close.fire(AppState.fileSystem) })
        val available = Engine.read { items.filter { it.enabled() } }
        Dialogs.pick(context, tab.name, available.map { it.text }, -1) { which -> available[which].action() }
    }

    private class IContextItemLike(val text: String, val enabled: () -> Boolean, val action: () -> Unit)

    private fun showSelectedTab() {
        val tab = editor.selectedTab
        if (tab === shownTab && (tab != null || startScreen != null)) return
        shownTab = tab
        content.removeAllViews()
        // forget views of tabs that were closed
        val live = editor.toList()
        val dead = tabViews.keys.filter { key -> live.none { it === key } }
        for (key in dead) tabViews.remove(key)?.second?.dispose()
        if (tab == null) {
            val screen = startScreen ?: buildStartScreen().also { startScreen = it }
            content.addView(screen, FrameLayout.LayoutParams(MATCH, MATCH))
            return
        }
        val entry = tabViews.getOrPut(tab) {
            val b = binder.child()
            Pair(TabViews.create(context, tab, editor, b), b)
        }
        (entry.first.parent as? ViewGroup)?.removeView(entry.first)
        content.addView(entry.first, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ---------------------------------------------------------------- start screen

    private fun buildStartScreen(): View {
        val box = context.vbox()
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(Ui.dp(16), Ui.dp(32), Ui.dp(16), Ui.dp(16))
        box.addView(context.label("HexManiac Advance", 26f, Palette.primary, bold = true))
        box.addView(context.label("A ROM editor for GBA Pok\u00E9mon games", 14f, Palette.secondary).also { it.setPadding(0, Ui.dp(4), 0, Ui.dp(20)) })
        val actions = context.hbox()
        actions.addView(context.angleButton("Open ROM", AngleDrawable.Direction.Out, size = 16f) { editor.open.fire() }.also { it.minimumHeight = Ui.dp(48) })
        actions.addView(context.angleButton("New", AngleDrawable.Direction.Out, size = 16f) { editor.new.fire() }.also { it.minimumHeight = Ui.dp(48) }.margin(left = 10))
        box.addView(actions)
        val recentTitle = context.label("Recent files", 14f, Palette.secondary)
        recentTitle.setPadding(0, Ui.dp(24), 0, Ui.dp(6))
        box.addView(recentTitle)
        val recentList = context.vbox()
        box.addView(recentList, LinearLayout.LayoutParams(MATCH, WRAP))
        binder.watchCollection(editor.recentFileViewModels) {
            recentList.removeAllViews()
            recentTitle.visibility = if (editor.recentFileViewModels.size > 0) View.VISIBLE else View.GONE
            for (recent in editor.recentFileViewModels) {
                val row = context.label(recent.shortName, 15f, Palette.accent)
                row.setPadding(Ui.dp(10), Ui.dp(10), Ui.dp(10), Ui.dp(10))
                row.background = AngleDrawable(Palette.background, Palette.backlight, AngleDrawable.Direction.None)
                row.setOnClickListener { recent.open.fire() }
                recentList.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(4) })
            }
        }
        val links = context.hbox()
        links.addView(context.label("Wiki", 13f, Palette.accent).also { v -> v.setOnClickListener { activity.openLink("https://github.com/haven1433/HexManiacAdvance/wiki") } })
        links.addView(context.label("Tutorials", 13f, Palette.accent).also { v -> v.setOnClickListener { activity.openLink("https://github.com/haven1433/HexManiacAdvance/wiki/Tutorials") } }.margin(left = 20))
        box.addView(links, LinearLayout.LayoutParams(WRAP, WRAP).also { it.topMargin = Ui.dp(24) })
        return context.vscroll(box)
    }

    // ---------------------------------------------------------------- find / hex converter

    private fun buildFindBar(): View {
        val bar = context.hbox()
        bar.setPadding(Ui.dp(6), Ui.dp(3), Ui.dp(6), Ui.dp(3))
        bar.setBackgroundColor(Palette.backlight)
        bar.addView(toggleButton(binder, null, Icon.Multiple, editor, "searchAllFiles", { editor.searchAllFiles }, { editor.searchAllFiles = it }))
        bar.addView(toggleButton(binder, "Aa", null, editor, "matchExactCase", { editor.matchExactCase }, { editor.matchExactCase = it }))
        val edit = context.textBox(hint = "Find", size = 14f, mono = true)
        edit.imeOptions = EditorInfo.IME_ACTION_SEARCH or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        binder.bindText(edit, editor, "findText", { editor.findText }, { editor.findText = it })
        edit.setOnEditorActionListener { _, _, _ ->
            val text = edit.text.toString()
            editor.find.fire(text)
            true
        }
        bar.addView(edit, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.leftMargin = Ui.dp(4) })
        bar.addView(context.iconButton(Icon.LeftArrow, 36) { editor.findPrevious.fire(edit.text.toString()) })
        bar.addView(context.iconButton(Icon.RightArrow, 36) { editor.findNext.fire(edit.text.toString()) })
        bar.addView(context.iconButton(Icon.Exit, 36, Palette.secondary) { editor.showFind.fire(false) })
        binder.watch(editor, "findControlVisible") { bar.visibility = if (editor.findControlVisible) View.VISIBLE else View.GONE }
        return bar
    }

    private fun buildHexConverterBar(): View {
        val bar = context.hbox()
        bar.setPadding(Ui.dp(6), Ui.dp(3), Ui.dp(6), Ui.dp(3))
        bar.setBackgroundColor(Palette.backlight)
        bar.addView(context.label("Hex:", 13f, Palette.secondary))
        val hex = context.textBox(size = 14f, mono = true)
        binder.bindText(hex, editor, "hexText", { editor.hexText }, { editor.hexText = it })
        bar.addView(hex, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.leftMargin = Ui.dp(4); it.rightMargin = Ui.dp(8) })
        bar.addView(context.label("Decimal:", 13f, Palette.secondary))
        val dec = context.textBox(size = 14f, mono = true)
        binder.bindText(dec, editor, "decText", { editor.decText }, { editor.decText = it })
        bar.addView(dec, LinearLayout.LayoutParams(0, WRAP, 1f).also { it.leftMargin = Ui.dp(4) })
        bar.addView(context.iconButton(Icon.Exit, 36, Palette.secondary) { editor.showHexConverter.fire(false) })
        binder.watch(editor, "hexConverterVisible") { bar.visibility = if (editor.hexConverterVisible) View.VISIBLE else View.GONE }
        return bar
    }

    // ---------------------------------------------------------------- messages

    private fun buildMessageBar(): View {
        val bar = context.hbox()
        bar.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(4), Ui.dp(4))
        bar.setBackgroundColor(Palette.backlight)
        val text = context.label("", 13f, Palette.accent)
        bar.addView(text, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(context.angleButton("Copy", size = 11f) { Engine.post { editor.copyMessage() } }.also { it.minimumHeight = Ui.dp(28) })
        bar.addView(context.iconButton(Icon.Exit, 32, Palette.secondary) { editor.clearMessage.fire() })
        binder.watch(editor, "showMessage", "informationMessage") {
            bar.visibility = if (editor.showMessage) View.VISIBLE else View.GONE
            text.text = editor.informationMessage
        }
        return bar
    }

    private fun buildErrorBar(): View {
        val bar = context.hbox()
        bar.setPadding(Ui.dp(10), Ui.dp(4), Ui.dp(4), Ui.dp(4))
        bar.setBackgroundColor(Palette.background)
        bar.background = BoxDrawable(Palette.background, Palette.error)
        val text = context.label("", 13f, Palette.error)
        bar.addView(text, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(context.angleButton("Copy", size = 11f) { Engine.post { editor.copyError() } }.also { it.minimumHeight = Ui.dp(28) })
        bar.addView(context.iconButton(Icon.Exit, 32, Palette.secondary) { editor.clearError.fire() })
        binder.watch(editor, "showError", "errorMessage") {
            bar.visibility = if (editor.showError) View.VISIBLE else View.GONE
            text.text = editor.errorMessage ?: ""
        }
        return bar
    }

    private fun buildOverlayText(): View {
        val label = context.label("", 15f, Palette.primary)
        label.setPadding(Ui.dp(16), Ui.dp(10), Ui.dp(16), Ui.dp(10))
        label.background = BoxDrawable(Palette.alpha(Palette.backlight, 235), Palette.accent)
        label.isClickable = false
        binder.watch(editor, "showOverlayText", "overlayText") {
            label.text = editor.overlayText
            label.visibility = if (editor.showOverlayText && editor.overlayText.isNotEmpty()) View.VISIBLE else View.GONE
        }
        return label
    }

    // ---------------------------------------------------------------- automation panel

    private fun buildAutomationPanel(): View {
        val panel = context.vbox()
        panel.setBackgroundColor(Palette.background)
        panel.addView(context.divider(Palette.secondary))
        val head = context.hbox()
        head.setPadding(Ui.dp(8), Ui.dp(2), Ui.dp(2), Ui.dp(2))
        head.addView(context.label("Automation", 13f, Palette.secondary), LinearLayout.LayoutParams(0, WRAP, 1f))
        val python = editor.pythonTool
        head.addView(context.angleButton("Run", AngleDrawable.Direction.Out, size = 12f) { Engine.post { python.runPython() } }.also { it.minimumHeight = Ui.dp(30) })
        head.addView(context.iconButton(Icon.Exit, 34, Palette.secondary) { Engine.post { editor.showAutomationPanel = false } })
        panel.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        val code = context.textBox(mono = true, size = 12f)
        code.isSingleLine = false
        code.minLines = 3
        code.maxLines = 8
        code.gravity = Gravity.TOP or Gravity.START
        code.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val editorVm = python.pythonEditor
        binder.bindText(code, editorVm, "content", { editorVm.content }, { editorVm.content = it })
        panel.addView(code, LinearLayout.LayoutParams(MATCH, WRAP).also { it.setMargins(Ui.dp(6), 0, Ui.dp(6), Ui.dp(2)) })
        val result = context.label("", 12f, Palette.text2, mono = true)
        result.setPadding(Ui.dp(8), 0, Ui.dp(8), Ui.dp(4))
        panel.addView(result)
        binder.watch(python, "resultText") { result.text = python.resultText }
        binder.watch(editor, "showAutomationPanel") { panel.visibility = if (editor.showAutomationPanel) View.VISIBLE else View.GONE }
        return panel
    }

    // ---------------------------------------------------------------- goto

    private fun buildGoto(): View {
        val goto = editor.gotoViewModel
        val panel = context.vbox()
        panel.setBackgroundColor(Palette.background)
        panel.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), Ui.dp(8))
        val head = context.hbox()
        head.addView(context.label("Goto:", 20f, Palette.primary), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(context.iconButton(Icon.Exit, 40, Palette.secondary) { goto.showGoto.fire(false) })
        panel.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        val edit = context.textBox(hint = "address, label or table", size = 16f, mono = true)
        edit.imeOptions = EditorInfo.IME_ACTION_GO or EditorInfo.IME_FLAG_NO_EXTRACT_UI
        binder.bindText(edit, goto, "text", { goto.text }, { goto.text = it })
        edit.setOnEditorActionListener { _, _, _ ->
            Engine.post { goto.goto?.let { if (it.canExecute(null)) it.execute(null) } }
            true
        }
        panel.addView(edit, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(8) })
        val loading = context.label("Loading...", 18f, Palette.secondary)
        loading.gravity = Gravity.CENTER
        panel.addView(loading, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(12) })
        binder.watch(goto, "loading") { loading.visibility = if (goto.loading) View.VISIBLE else View.GONE }
        val options = context.vbox()
        val tokens = context.vbox()
        val shortcuts = FlowLayout(context)
        shortcuts.hGap = Ui.dp(6)
        shortcuts.vGap = Ui.dp(6)
        val scroll = context.vscroll(context.vbox().also { box ->
            box.addView(options, LinearLayout.LayoutParams(MATCH, WRAP))
            box.addView(tokens, LinearLayout.LayoutParams(MATCH, WRAP))
            box.addView(shortcuts, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(10) })
        })
        panel.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        binder.watch(goto, "autoCompleteOptions", "showAutoCompleteOptions", "completionIndex") {
            options.removeAllViews()
            if (goto.showAutoCompleteOptions) {
                for ((i, option) in goto.autoCompleteOptions.withIndex()) {
                    val row = context.label(option.displayText, 15f, if (i == goto.completionIndex || option.isSelected) Palette.accent else Palette.primary, mono = true)
                    row.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(8))
                    row.background = AngleDrawable(Palette.background, Palette.backlight, AngleDrawable.Direction.None)
                    row.setOnClickListener {
                        Engine.post {
                            goto.completionIndex = i
                            goto.goto?.let { if (it.canExecute(null)) it.execute(null) }
                        }
                    }
                    options.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).also { it.topMargin = Ui.dp(2) })
                }
            }
        }
        binder.watchCollection(goto.prefixSelections) {
            tokens.removeAllViews()
            for (section in goto.prefixSelections) {
                val flow = FlowLayout(context)
                flow.hGap = Ui.dp(4)
                flow.vGap = Ui.dp(4)
                for (token in section.tokens) {
                    val button = context.angleButton(token.content, AngleDrawable.Direction.None, size = 13f) {
                        Engine.post { if (token.isSelectable) token.isSelected = !token.isSelected }
                    }
                    button.alpha = if (token.isSelectable) 1f else 0.4f
                    if (token.isSelected) button.setTextColor(Palette.accent)
                    flow.addView(button)
                }
                tokens.addView(flow, LinearLayout.LayoutParams(MATCH, WRAP).also { it.bottomMargin = Ui.dp(6) })
            }
        }
        binder.watchCollection(goto.shortcuts) {
            shortcuts.removeAllViews()
            for (shortcut in goto.shortcuts) {
                if (!shortcut.visible) continue
                val button = context.vbox()
                button.gravity = Gravity.CENTER_HORIZONTAL
                button.setPadding(Ui.dp(8), Ui.dp(6), Ui.dp(8), Ui.dp(6))
                button.background = AngleDrawable(Palette.backlight, Palette.secondary, AngleDrawable.Direction.Out)
                val image = shortcut.image
                if (image != null) {
                    val pixels = PixelView(context)
                    pixels.scaleDp = 1f
                    pixels.trueTransparency = true
                    pixels.setImage(image)
                    button.addView(pixels, LinearLayout.LayoutParams(WRAP, WRAP))
                }
                button.addView(context.label(shortcut.displayText, 13f, Palette.primary))
                button.setOnClickListener { Engine.post { shortcut.goto() } }
                shortcuts.addView(button)
            }
        }
        binder.watch(goto, "controlVisible") {
            gotoPanel.visibility = if (goto.controlVisible) View.VISIBLE else View.GONE
            if (goto.controlVisible) edit.post { edit.requestFocus() }
        }
        gotoPanel.addView(panel, FrameLayout.LayoutParams(MATCH, MATCH))
        gotoPanel.isClickable = true
        return gotoPanel
    }
}
