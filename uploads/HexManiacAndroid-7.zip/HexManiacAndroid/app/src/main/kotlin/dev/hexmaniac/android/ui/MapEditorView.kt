package dev.hexmaniac.android.ui

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import dev.hexmaniac.android.host.Engine
import dev.hexmaniac.core.viewmodels.MenuCommandNonGeneric
import dev.hexmaniac.core.viewmodels.map.BlockMapViewModel
import dev.hexmaniac.core.viewmodels.map.EventCreationType
import dev.hexmaniac.core.viewmodels.map.MapDirection
import dev.hexmaniac.core.viewmodels.map.MapEditorViewModel
import dev.hexmaniac.core.viewmodels.map.MapSlider
import dev.hexmaniac.core.viewmodels.map.ZoomDirection

/** Builds its content the first time it is asked to (with the engine lock held). */
internal class LazyPanel(context: Context, private val factory: () -> View) : FrameLayout(context) {
    private var built = false

    fun ensure() {
        if (built) return
        built = true
        addView(factory(), LayoutParams(MATCH, MATCH))
    }
}

/**
 * The map editor tab: the touch map canvas with its toolbar, plus the Blocks / Events / Header panels and the Tiles / Border
 * panels. Wide screens put the panels beside the map, narrow screens put them under it.
 */
internal class MapEditorView(context: Context, private val tab: MapEditorViewModel, private val binder: Binder) : FrameLayout(context), MapHost {
    private val canvas: MapCanvas = MapCanvas(context, tab, binder, this)
    private val blocksPanel = BlocksPanel(context, tab, binder)
    private val eventsPanel = LazyPanel(context) { EventsPanel(context, tab, binder) { Engine.post { tab.showTemplateSettings = true } } }
    private val headerPanel = LazyPanel(context) { HeaderPanel(context, tab, binder) }
    private val tilesPanel = LazyPanel(context) { TilesPanel(context, tab, binder) }
    private val borderPanel = LazyPanel(context) { BorderPanel(context, tab, binder) }
    private val leftStack = FrameLayout(context)
    private val overlayStack = FrameLayout(context)
    private val mapColumn = LinearLayout(context)
    private val root = LinearLayout(context)
    private val toolbar = context.hbox()

    private val modeButtons = LinkedHashMap<MapMode, TextView>()
    private val creationButtons = LinkedHashMap<EventCreationType, TextView>()
    private lateinit var beneathButton: TextView
    private lateinit var eventsButton: TextView
    private lateinit var headerButton: TextView
    private lateinit var wildButton: TextView
    private lateinit var borderButton: TextView
    private lateinit var panelsButton: TextView
    private lateinit var mapIdLabel: TextView
    private val gotoDropdown = Dropdown(context, "Quick Goto")
    private val tutorialsChip = PanelUi.chip(context, "Tutorials")

    private var wide: Boolean = context.resources.configuration.screenWidthDp >= 640
    private var panelArea: FrameLayout? = null
    private var panelsVisible = true
    private var leftKind = 0 // 0 blocks, 1 events, 2 header
    private var overlayKind = 0 // 0 none, 1 tiles, 2 border
    private var armed = EventCreationType.None
    private var wildOpen = false
    private var templateOpen = false
    private var watchedMap: BlockMapViewModel? = null
    private var mapBinder: Binder? = null

    init {
        for (panel in listOf<View>(blocksPanel, eventsPanel, headerPanel)) leftStack.addView(panel, LayoutParams(MATCH, MATCH))
        for (panel in listOf<View>(tilesPanel, borderPanel)) overlayStack.addView(panel, LayoutParams(MATCH, MATCH))
        leftStack.setBackgroundColor(Palette.background)
        overlayStack.setBackgroundColor(Palette.background)

        buildToolbar()
        val scroller = HorizontalScrollView(context)
        scroller.isHorizontalScrollBarEnabled = false
        scroller.overScrollMode = OVER_SCROLL_NEVER
        toolbar.setPadding(Ui.dp(4), Ui.dp(3), Ui.dp(4), Ui.dp(3))
        scroller.addView(toolbar, ViewGroup.LayoutParams(WRAP, WRAP))

        val mapFrame = FrameLayout(context)
        mapFrame.addView(canvas, LayoutParams(MATCH, MATCH))
        tutorialsChip.setOnClickListener { readSoon { TutorialsDialog.show(context, tab.tutorials) } }
        mapFrame.addView(tutorialsChip, LayoutParams(WRAP, WRAP, Gravity.END or Gravity.TOP).also { it.topMargin = Ui.dp(6); it.rightMargin = Ui.dp(6) })

        mapColumn.orientation = LinearLayout.VERTICAL
        mapColumn.addView(scroller, lp(MATCH, WRAP))
        mapColumn.addView(context.divider(), lp(MATCH, 1))
        mapColumn.addView(mapFrame, lp(MATCH, 0, 1f))

        root.orientation = LinearLayout.HORIZONTAL
        addView(root, LayoutParams(MATCH, MATCH))
        arrange(wide)

        binder.watch(tab, "showHeaderPanel", "selectedEvent", "showEventPanel", "primaryMap") {
            rewatchMap()
            refreshPanels()
        }
        binder.watch(tab, "showBeneath", "hideEvents", "showHeaderPanel") {
            active(beneathButton, tab.showBeneath)
            active(eventsButton, !tab.hideEvents)
            active(headerButton, tab.showHeaderPanel)
        }
        binder.watch(tab, "showTemplateSettings") {
            if (tab.showTemplateSettings && !templateOpen) {
                templateOpen = true
                TemplateSettings.show(context, binder, tab) { templateOpen = false }
            }
        }
        val tutorials = tab.tutorials
        binder.watch(tutorials, "completionPercent", "seeMore") {
            val percent = tutorials.completionPercent
            tutorialsChip.text = "Tutorials (" + percent + ")"
            tutorialsChip.visibility = if (percent == "100.00%") View.GONE else View.VISIBLE
        }
        refreshModes()
        refreshCreation()
    }

    // ------------------------------------------------------------------------------------------ toolbar

    private fun tool(text: String, tip: String? = null, onClick: () -> Unit): TextView {
        val button = context.angleButton(text, AngleDrawable.Direction.None, size = 12f, onClick = onClick)
        button.minimumWidth = Ui.dp(34)
        button.minHeight = Ui.dp(34)
        button.setPadding(Ui.dp(9), Ui.dp(2), Ui.dp(9), Ui.dp(2))
        if (tip != null) button.setOnLongClickListener { Toast.makeText(context, tip, Toast.LENGTH_LONG).show(); true }
        toolbar.addView(button, LinearLayout.LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(3) })
        return button
    }

    private fun active(button: TextView, on: Boolean) {
        val background = button.background as? AngleDrawable ?: return
        background.fill = if (on) Palette.accent else Palette.backlight
        background.invalidateSelf()
        button.setTextColor(if (on) Color.BLACK else Palette.primary)
    }

    private fun gap() {
        toolbar.addView(View(context), LinearLayout.LayoutParams(Ui.dp(10), 1))
    }

    private fun buildToolbar() {
        tool("Esc", "Unselect the block or event, and close the panels (Escape)") {
            armed = EventCreationType.None
            canvas.cancelCreation()
            refreshCreation()
        }
        gap()
        val modes = listOf(
            Triple(MapMode.Draw, "Draw", "One finger draws with the selected block. Double-tap paints (flood fill)."),
            Triple(MapMode.Rect, "Rect", "Drag to fill a rectangle with the selected block (Ctrl+drag)."),
            Triple(MapMode.Fill, "Fill", "Tap to paint an area of identical blocks with the selected block."),
            Triple(MapMode.Pan, "Pan", "One finger moves the map around."),
            Triple(MapMode.Select, "Pick", "One finger picks a block (or a rectangle of blocks) from the map. Long-press does this in any mode."),
        )
        for ((mode, label, tip) in modes) modeButtons[mode] = tool(label, tip) { canvas.mode = mode; refreshModes() }
        gap()
        tool("\u2212", "Zoom Out") { Engine.post { tab.zoom(ZoomDirection.Shrink) } }
        tool("+", "Zoom In") { Engine.post { tab.zoom(ZoomDirection.Enlarge) } }
        beneathButton = tool("Beneath", "Show the map that the Dive/Emerge connection leads to, underneath this one (Spacebar).") { Engine.post { tab.showBeneath = !tab.showBeneath } }
        eventsButton = tool("Events", "Show or hide the events on the map (hold Ctrl).") { Engine.post { tab.hideEvents = !tab.hideEvents } }
        gap()
        headerButton = tool("Edit Map Header", "Each map has additional information, such as its music and weather.") { Engine.post { tab.toggleHeaderPanel() } }
        wildButton = tool("Create Wild Data", "The wild pokemon of this map: grass, rocks, surfing and fishing.") {
            Engine.post {
                val wild = tab.primaryMap.wildPokemon
                wild.showWildData = !wild.showWildData
            }
        }
        borderButton = tool("Edit Border Block", "Each map has a border block that shows for anything out of bounds of the map.") { Engine.post { tab.primaryMap.borderEditor.toggleBorderEditor() } }
        gap()
        creationButton("Auto", EventCreationType.WaveFunction, "Drag to auto-fill a region of identical blocks with random blocks. Blocks fill at about 1000 per second and backtrack when they get stuck. Editing the map cancels the auto-fill.")
        creationButton("Obj", EventCreationType.Object, "Create a new object: tap, then drag on the map. Tap Template to choose what the object is.")
        tool("Template", "Choose the template for new objects (trainer, item, NPC, legendary ...)") { Engine.post { tab.showTemplateSettings = !tab.showTemplateSettings } }
        creationButton("W", EventCreationType.Warp, "Create a new warp: tap, then drag on the map.")
        creationButton("Sc", EventCreationType.Script, "Create a new script event: tap, then drag on the map.")
        creationButton("Sp", EventCreationType.Signpost, "Create a new signpost (or hidden item): tap, then drag on the map.")
        creationButton("F", EventCreationType.Fly, "Create a new fly spot: tap, then drag on the map. Fly events are limited to 1 per map name.")
        gap()
        mapIdLabel = context.label("", 12f, Palette.primary)
        toolbar.addView(mapIdLabel, LinearLayout.LayoutParams(WRAP, WRAP).also { it.rightMargin = Ui.dp(6) })
        gotoDropdown.minimumWidth = Ui.dp(150)
        toolbar.addView(gotoDropdown, LinearLayout.LayoutParams(WRAP, Ui.dp(34)).also { it.rightMargin = Ui.dp(6) })
        gap()
        panelsButton = tool("Panels", "Show or hide the side panels") {
            panelsVisible = !panelsVisible
            applyPanels()
        }
    }

    private fun creationButton(text: String, type: EventCreationType, tip: String) {
        creationButtons[type] = tool(text, tip) { toggleCreation(type) }
    }

    private fun toggleCreation(type: EventCreationType) {
        if (type == EventCreationType.Fly && !Engine.read { tab.primaryMap.canCreateFlyEvent }) {
            Toast.makeText(context, "Fly events are limited to 1 per map name.", Toast.LENGTH_SHORT).show()
            return
        }
        if (armed == type) {
            armed = EventCreationType.None
            canvas.cancelCreation()
        } else {
            armed = type
            canvas.beginCreation(type)
        }
        refreshCreation()
    }

    private fun refreshModes() {
        for ((mode, button) in modeButtons) active(button, canvas.mode == mode)
    }

    private fun refreshCreation() {
        for ((type, button) in creationButtons) active(button, armed == type)
    }

    // ------------------------------------------------------------------------------------------ the map the editor shows

    /** Engine lock held. Follows the properties of whichever map is the primary one. */
    private fun rewatchMap() {
        val map = tab.primaryMap
        if (map === watchedMap) return
        watchedMap = map
        mapBinder?.dispose()
        val own = binder.child()
        mapBinder = own
        val editor = map.blockEditor
        if (editor != null) own.watch(editor, "showTiles") { refreshPanels() }
        val border = map.borderEditor
        own.watch(border, "showBorderPanel") {
            active(borderButton, border.showBorderPanel)
            refreshPanels()
        }
        val wild = map.wildPokemon
        own.watch(wild, "hasWildData", "showWildData") {
            wildButton.text = if (wild.hasWildData) "Edit Wild Data" else "Create Wild Data"
            active(wildButton, wild.showWildData)
            if (wild.showWildData && !wildOpen) {
                wildOpen = true
                WildDialog.show(context, wild) { wildOpen = false }
            }
        }
        own.watch(map, "canCreateFlyEvent") {
            creationButtons[EventCreationType.Fly]?.alpha = if (map.canCreateFlyEvent) 1f else 0.4f
        }
        own.watch(map, "fullName", "name") {
            mapIdLabel.text = "Map ID: " + map.name
            gotoDropdown.setItems(map.sortedAvailableNames.toList(), map.gotoNameIndex)
        }
        gotoDropdown.onSelect = { index -> Engine.post { tab.primaryMap.gotoNameIndex = index } }
    }

    // ------------------------------------------------------------------------------------------ panels

    /** Engine lock held. Decides which panels the view-model state asks for. */
    private fun refreshPanels() {
        val map = tab.primaryMap
        val newLeft = when {
            tab.showHeaderPanel -> 2
            tab.selectedEvent != null -> 1
            else -> 0
        }
        val newOverlay = when {
            map.borderEditor.showBorderPanel -> 2
            map.blockEditor?.showTiles == true -> 1
            else -> 0
        }
        if (newLeft == 1) eventsPanel.ensure()
        if (newLeft == 2) headerPanel.ensure()
        if (newOverlay == 1) tilesPanel.ensure()
        if (newOverlay == 2) borderPanel.ensure()
        if ((newLeft != 0 && newLeft != leftKind) || (newOverlay != 0 && newOverlay != overlayKind)) panelsVisible = true
        leftKind = newLeft
        overlayKind = newOverlay
        applyPanels()
    }

    private fun applyPanels() {
        blocksPanel.visibility = if (leftKind == 0) View.VISIBLE else View.GONE
        eventsPanel.visibility = if (leftKind == 1) View.VISIBLE else View.GONE
        headerPanel.visibility = if (leftKind == 2) View.VISIBLE else View.GONE
        tilesPanel.visibility = if (overlayKind == 1) View.VISIBLE else View.GONE
        borderPanel.visibility = if (overlayKind == 2) View.VISIBLE else View.GONE
        val overlay = overlayKind != 0
        if (wide) {
            leftStack.visibility = if (panelsVisible) View.VISIBLE else View.GONE
            overlayStack.visibility = if (panelsVisible && overlay) View.VISIBLE else View.GONE
        } else {
            panelArea?.visibility = if (panelsVisible) View.VISIBLE else View.GONE
            leftStack.visibility = if (overlay) View.GONE else View.VISIBLE
            overlayStack.visibility = if (overlay) View.VISIBLE else View.GONE
        }
        active(panelsButton, panelsVisible)
    }

    private fun detach(view: View) {
        (view.parent as? ViewGroup)?.removeView(view)
    }

    private fun arrange(wideNow: Boolean) {
        wide = wideNow
        root.removeAllViews()
        detach(leftStack)
        detach(overlayStack)
        detach(mapColumn)
        if (wideNow) {
            panelArea = null
            root.orientation = LinearLayout.HORIZONTAL
            root.addView(leftStack, lp(Ui.dp(320), MATCH))
            root.addView(context.divider().also { it.layoutParams = lp(1, MATCH) })
            root.addView(overlayStack, lp(Ui.dp(340), MATCH))
            root.addView(context.divider().also { it.layoutParams = lp(1, MATCH) })
            root.addView(mapColumn, lp(0, MATCH, 1f))
        } else {
            root.orientation = LinearLayout.VERTICAL
            root.addView(mapColumn, lp(MATCH, 0, 11f))
            val area = FrameLayout(context)
            area.addView(leftStack, LayoutParams(MATCH, MATCH))
            area.addView(overlayStack, LayoutParams(MATCH, MATCH))
            root.addView(context.divider().also { it.layoutParams = lp(MATCH, 1) })
            root.addView(area, lp(MATCH, 0, 9f))
            panelArea = area
        }
        applyPanels()
        canvas.requestFrame()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val wideNow = newConfig.screenWidthDp >= 640
        if (wideNow != wide) arrange(wideNow)
    }

    // ------------------------------------------------------------------------------------------ MapHost

    override fun showContextItems(title: String, items: List<MenuCommandNonGeneric>) {
        val usable = Engine.read { items.filter { it.canExecute(null) } }
        if (usable.isEmpty()) return
        Dialogs.pick(context, title, usable.map { it.text ?: "" }, -1) { index -> Engine.post { usable[index].execute(null) } }
    }

    override fun showSliderMenu(slider: MapSlider) {
        val (title, items) = Engine.read { slider.tooltip to slider.contextItems.toList() }
        if (items.isEmpty()) return
        Dialogs.pick(context, title, items.map { it.text ?: "" }, -1) { index ->
            Engine.post {
                val item = items[index]
                if (item.canExecute(null)) item.execute(null)
            }
        }
    }

    override fun creationFinished() {
        armed = EventCreationType.None
        refreshCreation()
    }

    // ------------------------------------------------------------------------------------------ hardware keyboard

    private fun editing(): Boolean = findFocus() is EditText

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && !editing()) {
            val direction = when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> MapDirection.Left
                KeyEvent.KEYCODE_DPAD_RIGHT -> MapDirection.Right
                KeyEvent.KEYCODE_DPAD_UP -> MapDirection.Up
                KeyEvent.KEYCODE_DPAD_DOWN -> MapDirection.Down
                else -> null
            }
            if (direction != null) {
                Engine.post { tab.pan(direction) }
                return true
            }
            when (event.keyCode) {
                KeyEvent.KEYCODE_ESCAPE -> {
                    Engine.post { tab.cancel() }
                    return true
                }
                KeyEvent.KEYCODE_DEL, KeyEvent.KEYCODE_FORWARD_DEL -> {
                    Engine.post { tab.delete() }
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }
}
