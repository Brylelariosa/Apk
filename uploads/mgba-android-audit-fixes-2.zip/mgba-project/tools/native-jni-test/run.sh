#!/usr/bin/env bash
# Host-side test of the array-taking JNI functions (nativeReadAudioSamples,
# nativeReadMemory) in mgba_jni.c: pulls them straight out of the real source
# and runs them against stubbed JNI/blip/core APIs under ASan/UBSan, with Java
# arrays modelled as exactly-sized heap copies so any out-of-bounds access
# is caught. Needs gcc; no Android NDK or mGBA source.
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
s = open('../../app/src/main/cpp/mgba_jni.c', encoding='utf-8').read()
a = s.index('/* ── nativeReadAudioSamples')
b = s.index('/* ── nativeSetKeys')
open('extracted.c', 'w', encoding='utf-8').write(s[a:b])
PY
gcc -std=gnu11 -Wall -Wextra -Wno-unused-parameter -g -fsanitize=address,undefined \
    -fno-omit-frame-pointer -I. harness.c -o harness -lpthread
ASAN_OPTIONS=detect_leaks=1 ./harness
rm -f extracted.c harness
