#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <pthread.h>

/* ---- jni stub: arrays are heap copies sized EXACTLY to the Java array, so
 *      ASan flags any write/read past the length the caller really has ---- */
typedef int jint; typedef int jsize; typedef short jshort; typedef signed char jbyte;
typedef unsigned char jboolean; typedef void *jobject;
typedef struct { int len; short *data; } *jshortArray;
typedef struct { int len; signed char *data; } *jbyteArray;
struct JNINativeInterface_;
typedef const struct JNINativeInterface_ *JNIEnv;
struct JNINativeInterface_ {
    jsize (*GetArrayLength)(JNIEnv *, void *);
    jshort *(*GetShortArrayElements)(JNIEnv *, jshortArray, jboolean *);
    void (*ReleaseShortArrayElements)(JNIEnv *, jshortArray, jshort *, jint);
    jbyte *(*GetByteArrayElements)(JNIEnv *, jbyteArray, jboolean *);
    void (*ReleaseByteArrayElements)(JNIEnv *, jbyteArray, jbyte *, jint);
};
static jsize f_len(JNIEnv *e, void *a){ (void)e; return *(int *)a; }
static jshort *f_gs(JNIEnv *e, jshortArray a, jboolean *c){ (void)e;(void)c; jshort *p=malloc((size_t)a->len*sizeof(jshort)); memcpy(p,a->data,(size_t)a->len*sizeof(jshort)); return p; }
static void f_rs(JNIEnv *e, jshortArray a, jshort *p, jint m){ (void)e;(void)m; memcpy(a->data,p,(size_t)a->len*sizeof(jshort)); free(p); }
static jbyte *f_gb(JNIEnv *e, jbyteArray a, jboolean *c){ (void)e;(void)c; jbyte *p=malloc((size_t)a->len); memcpy(p,a->data,(size_t)a->len); return p; }
static void f_rb(JNIEnv *e, jbyteArray a, jbyte *p, jint m){ (void)e;(void)m; memcpy(a->data,p,(size_t)a->len); free(p); }
static const struct JNINativeInterface_ g_iface = { f_len, f_gs, f_rs, f_gb, f_rb };
#define JNIEXPORT
#define JNICALL

/* ---- blip stub: both channels have `g_avail` samples queued ---- */
typedef struct { int ch; } blip_t;
static int g_avail = 5000;
static int blip_samples_avail(blip_t *b){ (void)b; return g_avail; }
static int blip_read_samples(blip_t *b, short *out, int count, int stereo){
    int step = stereo ? 2 : 1;
    for (int i = 0; i < count; i++) out[i*step] = (short)(b->ch ? -(i+1) : (i+1));
    g_avail -= count; return count; }
static blip_t g_left = {0}, g_right = {1};

/* ---- core stub ---- */
struct mCore {
    blip_t *(*getAudioChannel)(struct mCore *, int);
    uint8_t (*busRead8)(struct mCore *, uint32_t);
};
static blip_t *gac(struct mCore *c, int i){ (void)c; return i ? &g_right : &g_left; }
static uint8_t br8(struct mCore *c, uint32_t a){ (void)c; return (uint8_t)(a * 31u + 7u); }
static struct mCore g_core_obj = { gac, br8 };
static struct mCore *g_core = &g_core_obj;
static pthread_mutex_t g_core_mutex = PTHREAD_MUTEX_INITIALIZER;

#include "extracted.c"

static int fails = 0;
#define CHECK(c,msg) do{ if(c) printf("PASS  %s\n",msg); else { printf("FAIL  %s\n",msg); fails++; } }while(0)
static JNIEnv env_obj = &g_iface;
#define AUDIO(arr,n) Java_com_mgba_android_EmulatorEngine_nativeReadAudioSamples(&env_obj,NULL,(arr),(n))
#define MEM(addr,arr,n) Java_com_mgba_android_EmulatorEngine_nativeReadMemory(&env_obj,NULL,(addr),(arr),(n))

int main(void){
    printf("== nativeReadAudioSamples\n");
    { short d[2048]; memset(d,0,sizeof d); struct { int len; short *data; } a = {2048,d}; g_avail=5000;
      jint n = AUDIO((jshortArray)&a, 1024);
      CHECK(n==1024 && d[0]==1 && d[1]==-1 && d[2046]==1024 && d[2047]==-1024,"normal call: 1024 pairs, interleaved L/R");
    }
    { short d[100]; memset(d,0,sizeof d); struct { int len; short *data; } a = {100,d}; g_avail=5000;
      jint n = AUDIO((jshortArray)&a, 1024);
      CHECK(n==50 && d[98]==50 && d[99]==-50,"array too small for maxSamples: clamped to 50 pairs, no overflow");
    }
    { short d[101]; memset(d,0,sizeof d); struct { int len; short *data; } a = {101,d}; g_avail=5000;
      jint n = AUDIO((jshortArray)&a, 1024);
      CHECK(n==50,"odd-length array: floor(101/2)=50 pairs");
    }
    { short d[2]; struct { int len; short *data; } a = {1,d}; g_avail=5000;
      CHECK(AUDIO((jshortArray)&a, 1024)==0,"1-element array: no room for a pair -> 0");
    }
    { short d[64]; struct { int len; short *data; } a = {64,d};
      CHECK(AUDIO(NULL, 10)==0,"NULL array -> 0");
      CHECK(AUDIO((jshortArray)&a, 0)==0,"maxSamples 0 -> 0");
      CHECK(AUDIO((jshortArray)&a, -5)==0,"negative maxSamples -> 0");
      g_avail=0; CHECK(AUDIO((jshortArray)&a, 10)==0,"nothing buffered -> 0");
      struct mCore *saved=g_core; g_core=NULL; g_avail=5000;
      CHECK(AUDIO((jshortArray)&a, 10)==0,"no core -> 0");
      g_core=saved;
    }

    printf("== nativeReadMemory\n");
    { signed char d[512]; struct { int len; signed char *data; } a = {512,d};
      jint n = MEM(0x08000000, (jbyteArray)&a, 512);
      CHECK(n==512 && (uint8_t)d[0]==br8(NULL,0x08000000u) && (uint8_t)d[511]==br8(NULL,0x08000000u+511u),"normal 512-byte read");
    }
    { signed char d[16]; struct { int len; signed char *data; } a = {16,d};
      CHECK(MEM(0,(jbyteArray)&a, 4096)==16,"length > array: clamped to array size, no overflow");
    }
    { signed char *d=calloc(200000,1); struct { int len; signed char *data; } a = {200000,d};
      CHECK(MEM(0,(jbyteArray)&a, 0x7fffffff)==0x10000,"absurd length: clamped to MGBA_MEM_READ_MAX");
      free(d);
    }
    { signed char d[8]; struct { int len; signed char *data; } a = {8,d};
      CHECK(MEM(0,NULL,8)==0,"NULL array -> 0");
      CHECK(MEM(0,(jbyteArray)&a,0)==0,"length 0 -> 0");
      CHECK(MEM(0,(jbyteArray)&a,-1)==0,"negative length -> 0");
      struct mCore *saved=g_core; g_core=NULL;
      CHECK(MEM(0,(jbyteArray)&a,8)==0,"no core -> 0");
      g_core=saved;
    }
    printf("\n%s (%d failure(s))\n", fails?"FAILED":"ALL PASSED", fails);
    return fails?1:0;
}
