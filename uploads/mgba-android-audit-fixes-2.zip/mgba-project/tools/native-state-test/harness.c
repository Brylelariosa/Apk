#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <pthread.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <zlib.h>

/* ---- jni stub ---- */
typedef unsigned char jboolean; typedef const char *jstring; typedef void *jobject;
struct JNINativeInterface_;
typedef const struct JNINativeInterface_ *JNIEnv;
struct JNINativeInterface_ {
    const char *(*GetStringUTFChars)(JNIEnv *, jstring, jboolean *);
    void (*ReleaseStringUTFChars)(JNIEnv *, jstring, const char *);
};
static int g_str_outstanding = 0;
static const char *fake_get(JNIEnv *e, jstring s, jboolean *c){ (void)e;(void)c; g_str_outstanding++; return s; }
static void fake_rel(JNIEnv *e, jstring s, const char *c){ (void)e;(void)s;(void)c; g_str_outstanding--; }
static const struct JNINativeInterface_ g_iface = { fake_get, fake_rel };
#define JNI_TRUE 1
#define JNI_FALSE 0
#define JNIEXPORT
#define JNICALL

/* ---- logging stub ---- */
#define LOGI(...) do{ printf("  [I] "); printf(__VA_ARGS__); printf("\n"); }while(0)
#define LOGW(...) do{ printf("  [W] "); printf(__VA_ARGS__); printf("\n"); }while(0)
#define LOGE(...) do{ printf("  [E] "); printf(__VA_ARGS__); printf("\n"); }while(0)

/* ---- mGBA VFile stub ---- */
#define MAP_READ 1
#define MAP_WRITE 2
struct VFile {
    bool (*close)(struct VFile*);
    off_t (*seek)(struct VFile*, off_t, int);
    ssize_t (*read)(struct VFile*, void*, size_t);
    ssize_t (*write)(struct VFile*, const void*, size_t);
    void* (*map)(struct VFile*, size_t, int);
    void (*unmap)(struct VFile*, void*, size_t);
    void (*truncate)(struct VFile*, size_t);
    ssize_t (*size)(struct VFile*);
};
struct FdVf { struct VFile d; int fd; };
static bool fd_close(struct VFile*v){ struct FdVf*f=(struct FdVf*)v; close(f->fd); free(f); return true; }
static off_t fd_seek(struct VFile*v,off_t o,int w){ return lseek(((struct FdVf*)v)->fd,o,w); }
static ssize_t fd_read(struct VFile*v,void*b,size_t n){ return read(((struct FdVf*)v)->fd,b,n); }
static ssize_t fd_size(struct VFile*v){ struct stat st; if(fstat(((struct FdVf*)v)->fd,&st)) return -1; return st.st_size; }
static struct VFile *VFileOpen(const char *path, int flags){
    int fd=open(path,flags,0600); if(fd<0) return NULL;
    struct FdVf*f=calloc(1,sizeof(*f)); f->fd=fd; f->d.close=fd_close; f->d.seek=fd_seek; f->d.read=fd_read; f->d.size=fd_size; return &f->d;
}
struct MemVf { struct VFile d; uint8_t *buf; size_t size, cap, pos; };
static bool mem_close(struct VFile*v){ struct MemVf*m=(struct MemVf*)v; free(m->buf); free(m); return true; }
static off_t mem_seek(struct VFile*v,off_t o,int w){ struct MemVf*m=(struct MemVf*)v; size_t np = w==SEEK_SET?(size_t)o: w==SEEK_CUR? m->pos+o : m->size+o; m->pos=np; return np; }
static ssize_t mem_read(struct VFile*v,void*b,size_t n){ struct MemVf*m=(struct MemVf*)v; if(m->pos>=m->size) return 0; if(n>m->size-m->pos) n=m->size-m->pos; memcpy(b,m->buf+m->pos,n); m->pos+=n; return n; }
static void mem_grow(struct MemVf*m,size_t need){ if(need>m->cap){ size_t nc=m->cap?m->cap:16; while(nc<need) nc*=2; m->buf=realloc(m->buf,nc); memset(m->buf+m->cap,0,nc-m->cap); m->cap=nc; } }
static ssize_t mem_write(struct VFile*v,const void*b,size_t n){ struct MemVf*m=(struct MemVf*)v; mem_grow(m,m->pos+n); memcpy(m->buf+m->pos,b,n); m->pos+=n; if(m->pos>m->size) m->size=m->pos; return n; }
static void* mem_map(struct VFile*v,size_t s,int fl){ (void)fl; struct MemVf*m=(struct MemVf*)v; mem_grow(m,s); return m->buf; }
static void mem_unmap(struct VFile*v,void*p,size_t s){ (void)v;(void)p;(void)s; }
static void mem_trunc(struct VFile*v,size_t s){ struct MemVf*m=(struct MemVf*)v; mem_grow(m,s); m->size=s; }
static ssize_t mem_size(struct VFile*v){ return ((struct MemVf*)v)->size; }
static struct VFile *VFileMemChunk(const void *mem, size_t sz){ (void)mem;(void)sz; struct MemVf*m=calloc(1,sizeof(*m));
    m->d.close=mem_close; m->d.seek=mem_seek; m->d.read=mem_read; m->d.write=mem_write; m->d.map=mem_map; m->d.unmap=mem_unmap; m->d.truncate=mem_trunc; m->d.size=mem_size; return &m->d; }

/* ---- core stub ---- */
struct mCore { int dummy; };
#define SAVESTATE_SAVEDATA 1
#define SAVESTATE_RTC 2
#define SAVESTATE_METADATA 4
static pthread_mutex_t g_core_mutex = PTHREAD_MUTEX_INITIALIZER;
static struct mCore *g_core = NULL;
#define STATE_BYTES 400000
static uint8_t g_expected[STATE_BYTES];
static bool g_save_fail = false;
static bool mCoreSaveStateNamed(struct mCore*c, struct VFile*vf, int fl){ (void)c;(void)fl; if(g_save_fail) return false; return vf->write(vf,g_expected,STATE_BYTES)==STATE_BYTES; }
static bool mCoreLoadStateNamed(struct mCore*c, struct VFile*vf, int fl){ (void)c;(void)fl;
    uint8_t *b=malloc(STATE_BYTES+1); ssize_t n=vf->read(vf,b,STATE_BYTES+1);
    bool ok = n==STATE_BYTES && memcmp(b,g_expected,STATE_BYTES)==0; free(b); return ok; }

/* nativeLoadState() tells the link driver its timing queue was rebuilt after a successful load. */
static int g_reset_calls = 0, g_reset_queue_discarded = 0;
static void link_host_deferred_reset(bool queueDiscarded){ g_reset_calls++; if (queueDiscarded) g_reset_queue_discarded++; }
/* fsync() on a FIFO is EINVAL by design; real slot files are regular files. */
static int harness_fsync(int fd){ struct stat st; if(fstat(fd,&st)==0 && S_ISFIFO(st.st_mode)) return 0; return fsync(fd); }
#define fsync(fd) harness_fsync(fd)
#include "extracted.c"
#undef fsync

/* ---- tests ---- */
static int fails=0;
#define CHECK(c,msg) do{ if(c) printf("PASS  %s\n",msg); else { printf("FAIL  %s\n",msg); fails++; } }while(0)
static JNIEnv env_obj = &g_iface;
#define SAVE(p) Java_com_mgba_android_EmulatorEngine_nativeSaveState(&env_obj,NULL,(p))
#define LOAD(p) Java_com_mgba_android_EmulatorEngine_nativeLoadState(&env_obj,NULL,(p))

static void *save_thread(void*arg){ long r=SAVE((const char*)arg); return (void*)r; }

int main(void){
    struct mCore core; g_core=&core;
    for(int i=0;i<STATE_BYTES;i++) g_expected[i]=(uint8_t)((i*7)^(i>>5)) & ((i%64)<40?0x0F:0xFF);
    const char *P="/tmp/st_test.bin";
    unlink(P);

    printf("== round trip\n");
    CHECK(SAVE(P)==JNI_TRUE,"save returns true");
    struct stat st; stat(P,&st);
    CHECK(st.st_size>24 && st.st_size<STATE_BYTES,"file is compressed (smaller than raw)");
    CHECK(LOAD(P)==JNI_TRUE,"load of compressed state round-trips byte-exact");
    CHECK(g_reset_calls==1 && g_reset_queue_discarded==1,"successful load resets the link driver's deferred-transfer state (queue discarded)");

    printf("== legacy uncompressed file\n");
    { FILE*f=fopen("/tmp/st_legacy.bin","wb"); fwrite(g_expected,1,STATE_BYTES,f); fclose(f); }
    CHECK(LOAD("/tmp/st_legacy.bin")==JNI_TRUE,"uncompressed legacy state still loads");

    printf("== failure paths\n");
    g_save_fail=true; unlink("/tmp/st_fail.bin");
    CHECK(SAVE("/tmp/st_fail.bin")==JNI_FALSE,"core snapshot failure -> false");
    CHECK(access("/tmp/st_fail.bin",F_OK)!=0,"  ... and the target file was never created/touched");
    g_save_fail=false;
    CHECK(SAVE("/nonexistent_dir/x.bin")==JNI_FALSE,"unwritable path -> false");
    CHECK(LOAD("/tmp/does_not_exist.bin")==JNI_FALSE,"missing file -> false");
    int resetsBefore = g_reset_calls;      /* the legacy-file load above legitimately counted one */
    { /* truncated payload */
      FILE*f=fopen(P,"rb"); uint8_t b[100000]; size_t n=fread(b,1,sizeof b,f); fclose(f);
      f=fopen("/tmp/st_trunc.bin","wb"); fwrite(b,1,n/2,f); fclose(f);
      CHECK(LOAD("/tmp/st_trunc.bin")==JNI_FALSE,"truncated compressed payload -> false");
      /* corrupt payload bytes */
      f=fopen("/tmp/st_corrupt.bin","wb"); for(size_t i=40;i<n;i++) b[i]^=0xA5; fwrite(b,1,n,f); fclose(f);
      CHECK(LOAD("/tmp/st_corrupt.bin")==JNI_FALSE,"corrupted payload -> false");
      CHECK(g_reset_calls==resetsBefore,"failed loads do NOT reset it (queue untouched)");
      /* absurd size in header */
      uint64_t big=(uint64_t)1<<40; memcpy(b+8,&big,8);
      f=fopen("/tmp/st_bighdr.bin","wb"); fwrite(b,1,n,f); fclose(f);
      CHECK(LOAD("/tmp/st_bighdr.bin")==JNI_FALSE,"implausible original_size -> false, no huge malloc");
    }
    g_core=NULL;
    CHECK(SAVE("/tmp/st_nocore.bin")==JNI_FALSE,"save with no core -> false");
    CHECK(LOAD(P)==JNI_FALSE,"load with no core -> false");
    g_core=&core;

    printf("== g_core_mutex is NOT held during file I/O\n");
    { const char *F="/tmp/st_fifo"; unlink(F); mkfifo(F,0600);
      pthread_t t; pthread_create(&t,NULL,save_thread,(void*)F);   /* blocks in open(O_WRONLY) until a reader appears */
      usleep(300*1000);
      int got = pthread_mutex_trylock(&g_core_mutex);
      CHECK(got==0,"game-thread lock acquirable while save is blocked on disk I/O");
      if(got==0) pthread_mutex_unlock(&g_core_mutex);
      int rfd=open(F,O_RDONLY); uint8_t sink[65536]; ssize_t total=0,n; while((n=read(rfd,sink,sizeof sink))>0) total+=n; close(rfd);
      void *rv; pthread_join(t,&rv);
      CHECK((long)rv==JNI_TRUE && total>24,"save completes once reader drains the pipe");
      unlink(F);
    }
    CHECK(g_str_outstanding==0,"every GetStringUTFChars matched by a Release");
    printf("\n%s (%d failure(s))\n", fails?"FAILED":"ALL PASSED", fails);
    return fails?1:0;
}
