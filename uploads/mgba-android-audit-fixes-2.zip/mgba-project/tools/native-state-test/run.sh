#!/usr/bin/env bash
# Host-side test of nativeSaveState()/nativeLoadState() in mgba_jni.c.
# Pulls the two functions (plus their helpers) straight out of the real
# source, compiles them against tiny stubs of the JNI/mGBA API (see
# harness.c), and runs round-trip, corruption and lock-scope tests under
# ASan/UBSan. Needs gcc and zlib headers; no Android NDK or mGBA source.
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
s = open('../../app/src/main/cpp/mgba_jni.c', encoding='utf-8').read()
a = s.index('static const uint8_t MGBA_STATE_MAGIC')
b = s.index('/* ═══════════════════════════════════════════════════════════════════════════\n * GBA LINK CABLE MULTIPLAYER')
open('extracted.c', 'w', encoding='utf-8').write(s[a:b])
PY
gcc -std=gnu11 -Wall -Wextra -Wno-unused-function -g -fsanitize=address,undefined \
    -fno-omit-frame-pointer -I. harness.c -o harness -lz -lpthread
ASAN_OPTIONS=detect_leaks=1 ./harness
rm -f extracted.c harness
