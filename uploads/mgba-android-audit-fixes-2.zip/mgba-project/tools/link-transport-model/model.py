"""
Model of the HOST-side Wi-Fi exchange, old logic vs new logic, over a UDP socket
queue. It models my READING of LinkMultiplayer.kt (not the Kotlin itself).

Child: answers request k after a random delay (mostly short, occasionally a
frame-or-two when its game thread holds the core mutex), and sends a KEEPALIVE
every 2 s. Reply payload = a value unique to that round, so a desync is visible.
"""
import random, heapq

def make_child_events(n_rounds, gap_ms, seed, tail_p, keepalive_ms=2000):
    rnd = random.Random(seed)
    return rnd, gap_ms

def run(mode, seed=1, rounds=3000, gap_ms=2.0, tail_p=0.02, loss_p=0.0):
    rnd = random.Random(seed)
    t = 0.0
    queue = []                 # (arrival_time, kind, seq, payload)  min-heap by arrival
    next_keepalive = rnd.uniform(0, 2000)
    tx_seq = 0
    last_rx_seq = -1
    good = bad = timeouts = 0
    wrong_after_first = 0
    first_fault_round = None
    truth = {}
    WIFI_MS = 30.0 if mode == "old" else 150.0
    RESEND_MS = 60.0

    def deliver_keepalives_until(now):
        nonlocal next_keepalive
        while next_keepalive <= now:
            heapq.heappush(queue, (next_keepalive + 0.5, "KA", 0, 0))
            next_keepalive += 2000.0

    for k in range(rounds):
        seq = tx_seq & 0xFF; tx_seq += 1
        payload = 1000 + k
        truth[k] = payload
        # child's reply (echoes request seq in the NEW protocol; own counter in the OLD one)
        delay = rnd.uniform(1.5, 9.0) + (rnd.uniform(25, 60) if rnd.random() < tail_p else 0.0)
        send_t = t
        replies = []
        if rnd.random() >= loss_p:
            replies.append(send_t + delay)
        reply_seq = (seq if mode == "new" else (k * 1) & 0xFF)   # old: child's own txSeq++
        for rt in replies:
            heapq.heappush(queue, (rt, "DATA", reply_seq, payload))

        deadline = send_t + WIFI_MS
        resent = False
        result = None
        while True:
            deliver_keepalives_until(deadline)
            if not queue or queue[0][0] > deadline:
                if mode == "new" and not resent and t + RESEND_MS < deadline:
                    resent = True
                    # retransmit: child dedupes by seq and re-answers with cached payload
                    heapq.heappush(queue, (send_t + RESEND_MS + rnd.uniform(1.5, 6.0), "DATA", reply_seq, payload))
                    t = send_t + RESEND_MS
                    continue
                t = deadline
                result = ("TIMEOUT", None)
                break
            arr, kind, rseq, rpay = heapq.heappop(queue)
            t = max(t, arr)
            if mode == "old":
                if kind != "DATA":
                    result = ("FAIL", None); break          # keepalive treated as the reply
                if rseq == last_rx_seq:
                    result = ("FAIL", None); break
                last_rx_seq = rseq
                result = ("OK", rpay); break
            else:
                if kind != "DATA" or rseq != seq:
                    continue                                 # discard keepalive / stale / duplicate
                result = ("OK", rpay); break
        status, got = result
        if status == "OK" and got == truth[k]:
            good += 1
        elif status == "OK":
            bad += 1
            if first_fault_round is None: first_fault_round = k
        else:
            timeouts += 1
            if first_fault_round is None: first_fault_round = k
        t += gap_ms
    return dict(good=good, wrong_data=bad, failed_rounds=timeouts, first_fault=first_fault_round)

for loss in (0.0, 0.01):
    print(f"--- packet loss {loss:.0%}, 3000 back-to-back rounds, child tail-latency 2% ---")
    for mode in ("old", "new"):
        r = run(mode, loss_p=loss)
        total = r["good"] + r["wrong_data"] + r["failed_rounds"]
        print(f"{mode:3s}: correct={r['good']:5d} ({100*r['good']/total:5.1f}%)  "
              f"WRONG data accepted={r['wrong_data']:5d}  failed rounds={r['failed_rounds']:4d}  first fault at round {r['first_fault']}")
