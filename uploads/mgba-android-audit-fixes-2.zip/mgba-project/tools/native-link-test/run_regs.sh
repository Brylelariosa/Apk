#!/usr/bin/env bash
# Host-side test of the link SIO register logic in mgba_jni.c: link_sio_write_register(),
# link_child_apply(), link_child_deliver_pending() and the lock-step
# nativeLinkChildExchange(), extracted verbatim from the real source and run against
# stubbed JNI/mGBA types. Needs gcc only.
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
s = open('../../app/src/main/cpp/mgba_jni.c', encoding='utf-8').read()
def cut(a_marker, b_marker, name):
    a = s.index(a_marker); b = s.index(b_marker, a)
    open(name, 'w', encoding='utf-8').write(s[a:b])
cut('static jobject   g_link_obj      = NULL;', 'static void jni_log(', 'extracted_r1.c')
cut('static struct timespec g_link_last_exchange_ts;', '/* FIX 9 — passive-child responder entry point.', 'extracted_r2.c')
cut('/* AUDIT FIX (multiplayer): with LINK_CHILD_LOCKSTEP this no longer touches',
    'JNIEXPORT jboolean JNICALL\nJava_com_mgba_android_EmulatorEngine_nativeLinkStart(', 'extracted_r3.c')
PY
gcc -std=gnu11 -Wall -Wextra -Wno-unused-function -Wno-unused-parameter -g -fsanitize=address,undefined \
    -fno-omit-frame-pointer test_sio_regs.c -o test_sio_regs -lpthread
./test_sio_regs
rm -f test_sio_regs extracted_r1.c extracted_r2.c extracted_r3.c
