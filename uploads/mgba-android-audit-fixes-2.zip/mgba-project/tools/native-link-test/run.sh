#!/usr/bin/env bash
# Host-side test of link_mailbox.h — the lock-step hand-off between the link
# child's network thread and its game thread. Real pthreads, fake "game
# thread"; runs under ASan/UBSan and then ThreadSanitizer. Needs gcc only.
set -euo pipefail
cd "$(dirname "$0")"
gcc -std=gnu11 -Wall -Wextra -g -fsanitize=address,undefined -fno-omit-frame-pointer test_mailbox.c -o test_mailbox_asan -lpthread
./test_mailbox_asan
gcc -std=gnu11 -Wall -Wextra -g -fsanitize=thread test_mailbox.c -o test_mailbox_tsan -lpthread
echo "--- ThreadSanitizer run ---"
./test_mailbox_tsan 2>&1 | tail -4
rm -f test_mailbox_asan test_mailbox_tsan
