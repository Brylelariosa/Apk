#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

/* ---- minimal stand-ins for the JNI / mGBA types the extracted code touches ---- */
typedef int jint; typedef void *jobject; typedef void *jmethodID; typedef void *jthrowable; typedef unsigned char jboolean;
struct JNINativeInterface_;
typedef const struct JNINativeInterface_ *JNIEnv;
struct JNINativeInterface_ {
    jint (*CallIntMethod)(JNIEnv *, jobject, jmethodID, jint);
    jthrowable (*ExceptionOccurred)(JNIEnv *);
    void (*ExceptionClear)(JNIEnv *);
};
#define JNIEXPORT
#define JNICALL
static int g_calls = 0, g_last_sent = -1; static jint g_script_reply = 0;
static jint f_call(JNIEnv *e, jobject o, jmethodID m, jint d){ (void)e;(void)o;(void)m; g_calls++; g_last_sent = d; return g_script_reply; }
static jthrowable f_exc(JNIEnv *e){ (void)e; return NULL; }
static void f_clr(JNIEnv *e){ (void)e; }
static const struct JNINativeInterface_ g_iface = { f_call, f_exc, f_clr };
static JNIEnv g_env = &g_iface;

struct GBASIODriver {
    void *p;
    bool (*init)(struct GBASIODriver *); void (*deinit)(struct GBASIODriver *);
    bool (*load)(struct GBASIODriver *);  bool (*unload)(struct GBASIODriver *);
    uint16_t (*writeRegister)(struct GBASIODriver *, uint32_t, uint16_t);
};
struct mTiming;
struct mTimingEvent { void *context; void (*callback)(struct mTiming *, void *, uint32_t); const char *name; uint32_t when; unsigned priority; };
struct mTiming { struct mTimingEvent *ev; int32_t due; };       /* a one-slot queue is enough: the code under test uses one event */
struct GBA { struct { uint16_t rcnt, siocnt; } sio; struct { uint16_t io[0x200]; } memory; struct mTiming timing; };
static int g_double_schedules = 0, g_schedule_calls = 0;
static void mTimingSchedule(struct mTiming *t, struct mTimingEvent *e, int32_t when){
    g_schedule_calls++;
    if (t->ev == e) g_double_schedules++;          /* real mGBA would corrupt its list */
    t->ev = e; t->due = when; }
static void timing_advance(struct GBA *g, int32_t cycles){
    struct mTiming *t = &g->timing;
    if (!t->ev) return;
    t->due -= cycles;
    if (t->due <= 0) { struct mTimingEvent *e = t->ev; t->ev = NULL; e->callback(t, e->context, (uint32_t)(-t->due)); }
}
static void timing_clear(struct GBA *g){ g->timing.ev = NULL; }
struct mCore { int x; };
#define GBA_IRQ_SIO 7
static int g_irq_count = 0;
static void GBARaiseIRQ(struct GBA *g, int irq, int late){ (void)g;(void)irq;(void)late; g_irq_count++; }
#define LOGI(...) do{}while(0)
#define LOGW(...) do{}while(0)
#define LOGE(...) do{}while(0)

static struct mCore g_core_obj; static struct mCore *g_core = &g_core_obj;
#include "../../app/src/main/cpp/link_mailbox.h"

/* ---- code under test, pulled verbatim from mgba_jni.c ---- */
#include "extracted_r1.c"
static bool link_child_deliver_pending(void);
#include "extracted_r2.c"
#include "extracted_r3.c"

static int fails = 0;
#define CHECK(c,msg) do{ if(c) printf("PASS  %s\n",msg); else { printf("FAIL  %s\n",msg); fails++; } }while(0)
static struct GBA gba;

static void reset_world(bool host, uint16_t siocnt, uint16_t rcnt) {
    memset(&gba, 0, sizeof gba);
    gba.sio.siocnt = siocnt; gba.sio.rcnt = rcnt;
    g_link_gba = &gba; g_link_active = true; g_link_is_host = host;
    g_link_obj = (jobject)&g_iface; g_link_xchg_mid = (jmethodID)&g_iface;
    g_link_driver.d.writeRegister = link_sio_write_register;
    g_link_driver.env = &g_env; g_link_driver.localSend = 0xFFFF;
    g_calls = 0; g_irq_count = 0; g_link_pace_window_active = false;
    link_host_deferred_reset(true); g_link_done_event_inited = false; g_link_done_scheduled = false; g_link_done_core = NULL;
    g_double_schedules = 0; g_schedule_calls = 0; timing_clear(&gba);
}

typedef struct { int hostData; jint rc; } ChildCall;
static void *child_call_thread(void *a){ ChildCall *c=a; c->rc = Java_com_mgba_android_EmulatorEngine_nativeLinkChildExchange(&g_env,NULL,c->hostData); return NULL; }

int main(void) {
    printf("== HOST: SIOCNT Start write (multi mode, IRQ enabled, 115200 baud) — completion is DEFERRED\n");
    reset_world(true, 0x6003, 0);
    gba.memory.io[0x120>>1] = 0x1111; gba.memory.io[0x122>>1] = 0x2222;      /* stale values from an earlier transfer */
    link_sio_write_register(&g_link_driver.d, 0x12A, 0x00AB);          /* ROM stages SIOMLT_SEND */
    g_script_reply = 0x0CD2;
    uint16_t out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);
    CHECK(g_calls==1 && g_last_sent==0x00AB,"exchange runs once and sends the staged SIOMLT_SEND");
    CHECK((out & 0x0080)!=0,"write RETURNS with Start/Busy still set (hardware: a transfer takes time)");
    CHECK(g_irq_count==0,"no IRQ inside the write (the ROM's next instruction runs before any ISR)");
    CHECK(gba.memory.io[0x120>>1]==0x1111 && gba.memory.io[0x122>>1]==0x2222,"SIOMULTI registers not updated yet");
    CHECK((out & 0x0008)!=0 && (out & 0x0004)==0 && (out & 0x0030)==0,"SD set, SI clear (parent), ID=0");
    CHECK((out & 0x6000)==0x6000,"mode bits and IRQ-enable preserved");
    gba.sio.siocnt = out;                                              /* mGBA stores what the driver returns */
    timing_advance(&gba, 6409);
    CHECK(g_irq_count==0 && (gba.sio.siocnt & 0x0080)!=0,"still busy one cycle before the 115200-baud transfer time (6410)");
    timing_advance(&gba, 1);
    CHECK((gba.sio.siocnt & 0x0080)==0,"busy clears when the event fires");
    CHECK(gba.memory.io[0x120>>1]==0x00AB && gba.memory.io[0x122>>1]==0x0CD2 && gba.memory.io[0x124>>1]==0xFFFF && gba.memory.io[0x126>>1]==0xFFFF,"SIOMULTI0=host, SIOMULTI1=child, SIOMULTI2/3=0xFFFF delivered at completion");
    CHECK(g_irq_count==1,"SIO IRQ raised exactly once, at completion");
    CHECK((gba.sio.siocnt & 0x0040)==0 && (gba.sio.siocnt & 0x0030)==0 && (gba.sio.siocnt & 0x6000)==0x6000,"no error, ID 0, mode/IRQ bits intact");
    CHECK(gba.memory.io[0x128>>1]==gba.sio.siocnt,"memory.io mirror consistent");

    printf("== HOST: transfer time follows the baud bits\n");
    { int expect[4]={76900,19225,12820,6410};
      for (int baud=0; baud<4; baud++) {
        reset_world(true, 0x6000|baud, 0); g_script_reply=1;
        out = link_sio_write_register(&g_link_driver.d, 0x128, (uint16_t)(0x6080|baud)); gba.sio.siocnt = out;
        timing_advance(&gba, expect[baud]-1); int early = (gba.sio.siocnt & 0x80)!=0;
        timing_advance(&gba, 1); int done = (gba.sio.siocnt & 0x80)==0;
        char m[80]; snprintf(m,sizeof m,"baud bits %d -> completes at exactly %d cycles",baud,expect[baud]); CHECK(early && done,m);
      } }

    printf("== HOST: a second Start (or a clearing write) while busy is ignored\n");
    reset_world(true, 0x6003, 0); g_script_reply = 0x0111;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    int callsBefore = g_calls;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_calls==callsBefore && g_schedule_calls==1,"second Start: no second exchange, no second event");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6003); gba.sio.siocnt = out;
    CHECK((out & 0x0080)!=0,"software cannot clear Start/Busy mid-transfer");
    timing_advance(&gba, 7000);
    CHECK(g_irq_count==1 && (gba.sio.siocnt & 0x0080)==0,"still exactly one completion");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);
    CHECK(g_calls==callsBefore+1,"a new Start after completion starts a new transfer");

    printf("== HOST: SIO IRQ disabled by the ROM -> no IRQ at completion\n");
    reset_world(true, 0x2003, 0); g_script_reply = 0x1111;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x2083); gba.sio.siocnt = out;
    timing_advance(&gba, 7000);
    CHECK(g_calls==1 && g_irq_count==0 && (gba.sio.siocnt & 0x0080)==0,"transfer completes, IRQ NOT raised when SIOCNT bit14=0");

    printf("== HOST: no answer from child -> error flag appears at completion, not before\n");
    reset_world(true, 0x6003, 0); g_script_reply = -1;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK((out & 0x0040)==0,"error flag not set inside the write");
    timing_advance(&gba, 7000);
    CHECK((gba.sio.siocnt & 0x0040)!=0 && gba.memory.io[0x122>>1]==0xFFFF,"timeout -> error bit set, SIOMULTI1=0xFFFF at completion");
    CHECK(g_irq_count==1 && (gba.sio.siocnt & 0x0080)==0,"transfer still completes (busy cleared, IRQ raised)");

    printf("== HOST: teardown while a transfer is in flight\n");
    reset_world(true, 0x6003, 0); g_script_reply = 0x0222;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    link_host_deferred_reset(false);                                     /* link stopped; core + queue live on */
    CHECK((gba.sio.siocnt & 0x0080)==0 && !g_link_xfer_pending,"stop mid-transfer clears Start/Busy (no ROM stuck waiting)");
    int sched = g_schedule_calls;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;   /* restarted inside the old event's window */
    CHECK(g_double_schedules==0 && g_schedule_calls==sched,"event still queued -> NOT scheduled twice (queue corruption guard)");
    CHECK((out & 0x0080)==0 && g_irq_count==1,"...falls back to instant completion for that one transfer");
    timing_advance(&gba, 7000);
    CHECK(g_irq_count==1,"the stale event later fires as a harmless no-op");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_schedule_calls==sched+1 && (out & 0x0080)!=0,"after it has fired, deferral works again");
    timing_advance(&gba, 7000);

    printf("== HOST: core swap / save-state load discards the queue\n");
    reset_world(true, 0x6003, 0); g_script_reply = 0x0333;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    timing_clear(&gba); link_host_deferred_reset(true);                  /* what GBADeserialize does to the queue + our hook */
    CHECK((gba.sio.siocnt & 0x0080)==0 && !g_link_done_scheduled,"load mid-transfer: busy cleared, nothing considered scheduled");
    sched = g_schedule_calls;
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083); gba.sio.siocnt = out;
    CHECK(g_schedule_calls==sched+1 && g_double_schedules==0 && (out & 0x0080)!=0,"next transfer defers normally (no permanent fallback)");
    timing_advance(&gba, 7000);

    printf("== CHILD role: SIOCNT writes\n");
    reset_world(false, 0x6003, 0);
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6083);       /* child ROM writes Start by mistake */
    CHECK(g_calls==0,"child never starts a transfer of its own");
    CHECK((out & 0x0080)==0,"child's Start/Busy write is ignored (read-only for slaves)");
    CHECK((out & 0x000C)==0x000C,"SD and SI (child) set");
    CHECK((out & 0x0030)==0x0010,"ID bits = 01 survive an ordinary SIOCNT write (used to be reset to 0)");
    out = link_sio_write_register(&g_link_driver.d, 0x128, 0x6003 | 0x0030);
    CHECK((out & 0x0030)==0x0010,"ROM can't overwrite the read-only ID bits");

    printf("== CHILD: lock-step delivery through the mailbox\n");
    reset_world(false, 0x6003, 0);
    lm_open(link_mbox());
    g_link_driver.localSend = 0x1234;
    ChildCall cc = { 0x5A5A, 99 }; pthread_t t; pthread_create(&t,NULL,child_call_thread,&cc);
    bool took=false; for(int i=0;i<500 && !took;i++){ usleep(1000); took = link_child_deliver_pending(); }
    CHECK(took,"game thread takes the posted request");
    CHECK(gba.memory.io[0x120>>1]==0x5A5A && gba.memory.io[0x122>>1]==0x1234,"SIOMULTI0=host word, SIOMULTI1=child's own word");
    CHECK(gba.sio.siocnt==0x601F,"REAL gba->sio.siocnt updated: mode/IRQ bits kept, SD+SI set, ID=1, busy clear (0x601F)");
    CHECK(gba.memory.io[0x128>>1]==0x601F,"memory.io mirror kept consistent");
    CHECK(g_irq_count==1,"child SIO IRQ raised once");
    pthread_join(t,NULL);
    CHECK(cc.rc==0x1234,"network thread released at delivery with the child's staged word (0x1234)");
    /* one transfer per frame: a second request must wait for the NEXT frame start */
    g_link_driver.localSend = 0x9999;                       /* "ISR staged the next word during the frame" */
    ChildCall cc2 = { 0x6B6B, 99 }; pthread_t t2; pthread_create(&t2,NULL,child_call_thread,&cc2);
    usleep(30000);
    CHECK(cc2.rc==99 && gba.memory.io[0x120>>1]==0x5A5A,"2nd request is NOT delivered mid-frame (registers still show the 1st)");
    took = link_child_deliver_pending();
    pthread_join(t2,NULL);
    CHECK(took && gba.memory.io[0x120>>1]==0x6B6B && cc2.rc==0x9999,"next frame start delivers it, and the reply reflects the word staged in between");
    CHECK(g_irq_count==2,"one IRQ per delivered transfer");

    printf("== CHILD not in Multi-Player mode: no register writes, reply = no answer\n");
    reset_world(false, 0x0000, 0);
    lm_open(link_mbox());
    gba.memory.io[0x120>>1]=0x7777; g_link_driver.localSend = 0x4321;
    cc.hostData=0x1111; cc.rc=99; pthread_create(&t,NULL,child_call_thread,&cc);
    took=false; for(int i=0;i<500 && !took;i++){ usleep(1000); took = link_child_deliver_pending(); }
    pthread_join(t,NULL);
    CHECK(took && gba.memory.io[0x120>>1]==0x7777 && gba.sio.siocnt==0x0000 && g_irq_count==0,"registers and SIOCNT untouched (SIODATA32 shares those addresses)");
    CHECK(cc.rc==0xFFFF,"reply is 0xFFFF");

    printf("== CHILD with SIO IRQ disabled: data lands, no IRQ\n");
    reset_world(false, 0x2003, 0); lm_open(link_mbox()); g_link_driver.localSend = 0x0001;
    cc.hostData=0x2222; pthread_create(&t,NULL,child_call_thread,&cc);
    took=false; for(int i=0;i<500 && !took;i++){ usleep(1000); took = link_child_deliver_pending(); }
    pthread_join(t,NULL);
    CHECK(took && gba.memory.io[0x120>>1]==0x2222 && g_irq_count==0,"no IRQ when SIOCNT bit14=0");

    printf("== link closed / nobody running frames\n");
    lm_close(link_mbox());
    cc.hostData=1; cc.rc=99; child_call_thread(&cc);
    CHECK(cc.rc==-1,"closed link -> -1 (host's 'no answer')");
    reset_world(false, 0x6003, 0); lm_open(link_mbox());
    cc.rc=99; struct timespec a,b; clock_gettime(CLOCK_MONOTONIC,&a); child_call_thread(&cc); clock_gettime(CLOCK_MONOTONIC,&b);
    double ms=(b.tv_sec-a.tv_sec)*1000.0+(b.tv_nsec-a.tv_nsec)/1e6;
    CHECK(cc.rc==-1 && ms>=90 && ms<400,"no game thread: -1 after about LINK_CHILD_WAIT_MS (100 ms)");

    printf("\n%s (%d failure(s))\n", fails?"FAILED":"ALL PASSED", fails);
    return fails?1:0;
}
