"""Single source of truth for the launcher icon: emits Android vector XML AND a PIL render."""
import os, math
from PIL import Image, ImageDraw
import numpy as np

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app', 'src', 'main', 'res')

# ---- geometry (108x108 adaptive viewport; everything inside the 66dp safe circle) ----
BODY   = dict(x=26,  y=37,  w=56, h=34, r=8)
SH_L   = dict(x=30,  y=33.4, w=12, h=4.6, r=2)
SH_R   = dict(x=66,  y=33.4, w=12, h=4.6, r=2)
BEZEL  = dict(x=38,  y=42.5, w=32, h=23, r=3)
SCREEN = dict(x=40.5, y=45,  w=27, h=18, r=1.6)
TRI    = [(51.6, 50.4), (51.6, 57.6), (58.0, 54.0)]
DPAD_H = dict(x=28.2, y=52.6, w=8.2, h=2.8, r=1.0)
DPAD_V = dict(x=30.9, y=49.9, w=2.8, h=8.2, r=1.0)
PLUS = [(30.9,49.9),(33.7,49.9),(33.7,52.6),(36.4,52.6),(36.4,55.4),(33.7,55.4),(33.7,58.1),
        (30.9,58.1),(30.9,55.4),(28.2,55.4),(28.2,52.6),(30.9,52.6)]
BTN_A  = (77.6, 51.8, 2.5)
BTN_B  = (73.0, 57.0, 2.5)

C_BG0, C_BG1 = '#4B3597', '#12112A'
C_BODY0, C_BODY1 = '#F1E8FF', '#B895FF'
C_BEZEL = '#17142E'
C_SCR0, C_SCR1 = '#86F4FF', '#B38CFF'
C_DARK = '#241C4A'
C_A, C_B = '#FF6B9D', '#6BD1FF'

def rr_path(d):
    x,y,w,h,r = d['x'],d['y'],d['w'],d['h'],d['r']
    f=lambda v: ('%.2f'%v).rstrip('0').rstrip('.')
    return (f"M{f(x+r)},{f(y)}H{f(x+w-r)}A{f(r)},{f(r)} 0 0 1 {f(x+w)},{f(y+r)}V{f(y+h-r)}"
            f"A{f(r)},{f(r)} 0 0 1 {f(x+w-r)},{f(y+h)}H{f(x+r)}A{f(r)},{f(r)} 0 0 1 {f(x)},{f(y+h-r)}"
            f"V{f(y+r)}A{f(r)},{f(r)} 0 0 1 {f(x+r)},{f(y)}Z")
def circ_path(c):
    cx,cy,r=c; f=lambda v: ('%.2f'%v).rstrip('0').rstrip('.')
    return f"M{f(cx-r)},{f(cy)}a{f(r)},{f(r)} 0 1,0 {f(2*r)},0a{f(r)},{f(r)} 0 1,0 {f(-2*r)},0Z"
def poly_path(pts):
    f=lambda v: ('%.2f'%v).rstrip('0').rstrip('.')
    return 'M'+'L'.join(f"{f(x)},{f(y)}" for x,y in pts)+'Z'

AAPT='xmlns:aapt="http://schemas.android.com/aapt"'
HDR='<?xml version="1.0" encoding="utf-8"?>\n'
def vec_open(extra=''):
    return (f'<vector xmlns:android="http://schemas.android.com/apk/res/android" {extra}\n'
            '    android:width="108dp"\n    android:height="108dp"\n'
            '    android:viewportWidth="108"\n    android:viewportHeight="108">\n')
def grad(c0,c1,x0,y0,x1,y1):
    return ('    <path android:pathData="%s">\n      <aapt:attr name="android:fillColor">\n'
            '        <gradient android:type="linear" android:startX="%s" android:startY="%s"\n'
            '            android:endX="%s" android:endY="%s"\n'
            '            android:startColor="%s" android:endColor="%s"/>\n'
            '      </aapt:attr>\n    </path>\n')
def gpath(d,c0,c1,x0,y0,x1,y1):
    return grad(c0,c1,x0,y0,x1,y1) % (d,x0,y0,x1,y1,c0,c1)
def spath(d,color,extra=''):
    return f'    <path android:fillColor="{color}" {extra}\n        android:pathData="{d}"/>\n'

def write(rel, text):
    p=os.path.join(OUT,rel); os.makedirs(os.path.dirname(p),exist_ok=True)
    open(p,'w',encoding='utf-8').write(text)

# ---- background ----
write('drawable/ic_launcher_background.xml',
      HDR+vec_open(AAPT)+gpath('M0,0h108v108H0z',C_BG0,C_BG1,0,0,108,108)+
      spath('M-6,92 Q54,66 114,96 V114 H-6Z','#FFFFFF','android:fillAlpha="0.05"')+'</vector>\n')

# ---- foreground ----
def fg_paths(logo=False):
    s=''
    s+=gpath(rr_path(SH_L),'#CDB4FF','#9E7CF2',30,33,30,38)
    s+=gpath(rr_path(SH_R),'#CDB4FF','#9E7CF2',66,33,66,38)
    s+=gpath(rr_path(BODY),C_BODY0,C_BODY1,54,37,54,71)
    s+=spath(rr_path(BEZEL),C_BEZEL)
    s+=gpath(rr_path(SCREEN),C_SCR0,C_SCR1,40.5,45,67.5,63)
    s+=spath(poly_path(TRI),'#FFFFFF','android:fillAlpha="0.92"')
    s+=spath(poly_path(PLUS),C_DARK)
    s+=spath(circ_path(BTN_A),C_A)+spath(circ_path(BTN_B),C_B)
    return s
write('drawable/ic_launcher_foreground.xml', HDR+vec_open(AAPT)+fg_paths()+'</vector>\n')

# ---- monochrome (Android 13 themed icons): body with punched-out details ----
mono_body = rr_path(BODY)+rr_path(BEZEL)+poly_path(PLUS)+circ_path(BTN_A)+circ_path(BTN_B)
write('drawable/ic_launcher_monochrome.xml',
      HDR+vec_open()+
      spath(mono_body,'#FFFFFF','android:fillType="evenOdd"')+
      spath(rr_path(SH_L),'#FFFFFF')+spath(rr_path(SH_R),'#FFFFFF')+
      spath(rr_path(SCREEN),'#FFFFFF','android:fillAlpha="0.55"')+
      spath(poly_path(TRI),'#FFFFFF')+'</vector>\n')

# ---- adaptive icon definitions ----
adaptive=(HDR+'<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
 '    <background android:drawable="@drawable/ic_launcher_background"/>\n'
 '    <foreground android:drawable="@drawable/ic_launcher_foreground"/>\n'
 '    <monochrome android:drawable="@drawable/ic_launcher_monochrome"/>\n</adaptive-icon>\n')
write('mipmap-anydpi-v26/ic_launcher.xml',adaptive)
write('mipmap-anydpi-v26/ic_launcher_round.xml',adaptive)

# ---- in-app logo badge (settings header / About): the central 72x72 of the
#      adaptive art — i.e. what a launcher would show inside its mask — as one
#      vector, so it can be dropped into an ImageView at any size ----
write('drawable/ic_logo_badge.xml',
      HDR+('<vector xmlns:android="http://schemas.android.com/apk/res/android" %s\n'
           '    android:width="72dp"\n    android:height="72dp"\n'
           '    android:viewportWidth="72"\n    android:viewportHeight="72">\n'
           '    <group android:translateX="-18" android:translateY="-18">\n' % AAPT)+
      gpath('M0,0h108v108H0z',C_BG0,C_BG1,0,0,108,108)+
      spath('M-6,92 Q54,66 114,96 V114 H-6Z','#FFFFFF','android:fillAlpha="0.05"')+
      fg_paths()+'    </group>\n</vector>\n')

# ---------------- PIL render (same geometry) ----------------
SS=3  # supersample
def lerp(c0,c1,t):
    a=[int(c0[i:i+2],16) for i in (1,3,5)]; b=[int(c1[i:i+2],16) for i in (1,3,5)]
    return tuple(int(round(a[i]+(b[i]-a[i])*t)) for i in range(3))
def grad_img(size,c0,c1,p0,p1):
    W,H=size
    a=np.array([int(c0[i:i+2],16) for i in (1,3,5)],dtype=np.float32)
    b=np.array([int(c1[i:i+2],16) for i in (1,3,5)],dtype=np.float32)
    dx,dy=p1[0]-p0[0],p1[1]-p0[1]; L=(dx*dx+dy*dy) or 1.0
    xs=np.arange(W,dtype=np.float32)[None,:]; ys=np.arange(H,dtype=np.float32)[:,None]
    t=np.clip(((xs-p0[0])*dx+(ys-p0[1])*dy)/L,0,1)[...,None]
    arr=(a+(b-a)*t).astype(np.uint8)
    return Image.fromarray(arr,'RGB')
def render(px_size, legacy=None):
    """legacy: None -> full 108 canvas RGBA adaptive composite (square); 'round'/'square' -> legacy icon"""
    N=px_size*SS; k=N/108.0
    def S(v): return v*k
    def mask_rr(d):
        m=Image.new('L',(N,N),0); ImageDraw.Draw(m).rounded_rectangle([S(d['x']),S(d['y']),S(d['x']+d['w']),S(d['y']+d['h'])],radius=S(d['r']),fill=255); return m
    canvas=grad_img((N,N),C_BG0,C_BG1,(0,0),(N,N)).convert('RGBA')
    ov=Image.new('RGBA',(N,N),(0,0,0,0)); od=ImageDraw.Draw(ov)
    od.polygon([(S(-6),S(92))]+[(S(-6+120*i/20),S(92+ (4*math.sin(i/20*math.pi)*-1) + 4*i/20)) for i in range(21)]+[(S(114),S(114)),(S(-6),S(114))],fill=(255,255,255,13))
    canvas=Image.alpha_composite(canvas,ov)
    def paste_grad(d,c0,c1,p0,p1):
        g=grad_img((N,N),c0,c1,(S(p0[0]),S(p0[1])),(S(p1[0]),S(p1[1]))).convert('RGBA')
        canvas.paste(g,(0,0),mask_rr(d))
    def paste_solid(mask,color,alpha=1.0):
        layer=Image.new('RGBA',(N,N),color+(int(255*alpha),)) if len(color)==3 else Image.new('RGBA',(N,N),color)
        canvas.paste(layer,(0,0),mask)
    def hexrgb(h): return tuple(int(h[i:i+2],16) for i in (1,3,5))
    paste_grad(SH_L,'#CDB4FF','#9E7CF2',(30,33),(30,38))
    paste_grad(SH_R,'#CDB4FF','#9E7CF2',(66,33),(66,38))
    paste_grad(BODY,C_BODY0,C_BODY1,(54,37),(54,71))
    paste_solid(mask_rr(BEZEL),hexrgb(C_BEZEL))
    paste_grad(SCREEN,C_SCR0,C_SCR1,(40.5,45),(67.5,63))
    m=Image.new('L',(N,N),0); ImageDraw.Draw(m).polygon([(S(x),S(y)) for x,y in TRI],fill=int(255*0.92)); paste_solid(m,(255,255,255))
    m=Image.new('L',(N,N),0); ImageDraw.Draw(m).polygon([(S(x),S(y)) for x,y in PLUS],fill=255); paste_solid(m,hexrgb(C_DARK))
    for c,col in ((BTN_A,C_A),(BTN_B,C_B)):
        m=Image.new('L',(N,N),0); ImageDraw.Draw(m).ellipse([S(c[0]-c[2]),S(c[1]-c[2]),S(c[0]+c[2]),S(c[1]+c[2])],fill=255); paste_solid(m,hexrgb(col))
    return canvas.resize((px_size,px_size),Image.LANCZOS)

def legacy_icon(px, round_=False):
    full=render(px*2 if px<96 else px)   # render 108-space, then crop to the 72dp visible area and scale
    full=render(px)                      # px here is the 108dp canvas size
    return full

_cache={}
def art_for(density_px):
    if density_px not in _cache:
        big=render(int(density_px*108/72)+2)
        W=big.size[0]; c0=int(W*18/108); c1=int(W*90/108)
        _cache[density_px]=big.crop((c0,c0,c1,c1)).resize((density_px,density_px),Image.LANCZOS)
    return _cache[density_px]
def make_legacy(density_px, round_):
    art=art_for(density_px)
    m=Image.new('L',(density_px*4,density_px*4),0); d=ImageDraw.Draw(m)
    if round_: d.ellipse([0,0,density_px*4-1,density_px*4-1],fill=255)
    else: d.rounded_rectangle([0,0,density_px*4-1,density_px*4-1],radius=int(density_px*4*0.22),fill=255)
    m=m.resize((density_px,density_px),Image.LANCZOS)
    out=Image.new('RGBA',(density_px,density_px),(0,0,0,0)); out.paste(art,(0,0),m); return out

for dens,px in (('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)):
    d=os.path.join(OUT,f'mipmap-{dens}'); os.makedirs(d,exist_ok=True)
    make_legacy(px,False).save(os.path.join(d,'ic_launcher.png'),optimize=True)
    make_legacy(px,True).save(os.path.join(d,'ic_launcher_round.png'),optimize=True)

# preview sheet
prev=Image.new('RGBA',(1100,330),(24,24,28,255))
big=render(300); prev.paste(big,(10,15))
sq=make_legacy(192,False); rd=make_legacy(192,True)
prev.paste(sq,(340,15),sq); prev.paste(rd,(550,15),rd)
adaptive_circle=big.resize((192,192)); m=Image.new('L',(192,192),0); ImageDraw.Draw(m).ellipse([0,0,191,191],fill=255)
# adaptive mask preview: show the safe-zone circle on the full canvas
chk=render(192); 
cm=Image.new('L',(192*4,192*4),0); ImageDraw.Draw(cm).ellipse([(192*4)*(108-72)/216,(192*4)*(108-72)/216,(192*4)*(108+72)/216,(192*4)*(108+72)/216],fill=255)
cm=cm.resize((192,192),Image.LANCZOS)
cc=Image.new('RGBA',(192,192),(0,0,0,0)); cc.paste(chk,(0,0),cm); prev.paste(cc,(760,15),cc)
for sz,x in ((96,340),(72,450),(48,540),(36,600)):
    t=make_legacy(192,False).resize((sz,sz),Image.LANCZOS); prev.paste(t,(x,235),t)
prev.convert('RGB').save(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'launcher_icon_preview.png'))
print('done')
