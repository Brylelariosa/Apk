plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace  = "com.mgba.android"
    compileSdk = 34

    // Pin to the primary NDK the workflow installs.  Without an explicit
    // ndkVersion, AGP may pick up a stale 25.1 toolchain from the .cxx
    // cache of a previous build, which causes strtof_l redefinition
    // errors (NDK 25.1 exposes it as an inline that check_function_exists
    // misses, so mGBA compiles its own copy and clang rejects the duplicate).
    //
    // AUDIT FIX: this used to sit inside defaultConfig { ndk { } }, where it
    // only compiled because Kotlin lets a nested lambda reach the OUTER
    // android { } receiver's ndkVersion — the ndk { } block itself has no such
    // property. It is an android { } property, so it lives here.
    ndkVersion = "25.2.9519653"

    defaultConfig {
        applicationId = "com.mgba.android"
        minSdk    = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }

        externalNativeBuild {
            cmake {
                arguments(
                    "-DLIBMGBA_ONLY=ON",
                    "-DM_CORE_GBA=ON",
                    // FIX: removed "-DM_CORE_GB=ON".
                    //
                    // CMakeLists.txt uses  set(M_CORE_GB OFF CACHE BOOL "" FORCE).
                    // CMake CACHE FORCE overwrites the cache variable even when the
                    // same variable is supplied on the command line (-D flag).
                    // Passing -DM_CORE_GB=ON here therefore had no effect — the FORCE
                    // in CMakeLists.txt won unconditionally — while creating a false
                    // impression that GB/GBC support was enabled.  Removed to match
                    // actual build behaviour (GBA-only).  If GB/GBC is ever needed,
                    // remove the FORCE from CMakeLists.txt and re-add this argument.
                    "-DBUILD_STATIC=ON",
                    "-DBUILD_SHARED=OFF",
                    "-DDISABLE_FRONTENDS=ON",
                    "-DDISABLE_DEPS=ON"
                )
                // Compiler flags applied to our JNI wrapper (mgba_jni.c) and,
                // via add_subdirectory, to the mGBA core itself (these become
                // CMAKE_C_FLAGS / CMAKE_CXX_FLAGS, which are global — this is
                // the flag set that actually governs how fast the CPU
                // interpreter/audio mixer run, not just the small JNI file).
                // PERF: was -Os (optimise for size). Switched to -O2 -DNDEBUG
                // because this is a CPU-bound emulator core, where runtime
                // speed is worth far more than the modest .so size increase.
                // -O3 was considered but skipped: it can expose latent
                // undefined-behavior bugs in older C codebases (mGBA wasn't
                // written/tested against -O3-level auto-vectorization and
                // aggressive inlining), so -O2 is the safer "real" speed win.
                // -ffunction/data-sections + --gc-sections at link time dead-strips
                //   any mGBA code paths that our JNI bridge never calls.
                // -fvisibility=hidden hides internal symbols; JNIEXPORT overrides per-function.
                cFlags  ("-O2 -DNDEBUG -ffunction-sections -fdata-sections -fvisibility=hidden")
                cppFlags("-O2 -DNDEBUG -ffunction-sections -fdata-sections -fvisibility=hidden -std=c++17")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            // Signed with the debug keystore (same as the debug build) so CI
            // keeps producing a directly-installable APK with no keystore/
            // secrets setup. This is a personal-use sideload build, not a
            // Play Store release, so there's no real signing identity to
            // protect — if that ever changes, replace this with a proper
            // release signingConfig (keystore file + GitHub Actions secrets)
            // instead.
            signingConfig = signingConfigs.getByName("debug")
            // Was false. proguard-rules.pro already keeps everything the
            // native side touches (EmulatorEngine's native methods/KEY_*
            // constants, all of MainActivity), so flipping this on only
            // strips/obfuscates the parts nothing depends on — mainly the
            // unused portions of the AndroidX libraries pulled in
            // transitively. Native .so size is unaffected either way; it's
            // already stripped/GC'd at link time in CMakeLists.txt.
            isMinifyEnabled   = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    packaging {
        jniLibs {
            // useLegacyPackaging = true stores the .so compressed inside the APK
            // (smaller download).  This requires android:extractNativeLibs="true"
            // in AndroidManifest.xml so the system extracts the .so at install
            // time — see the comment in AndroidManifest.xml for the full
            // explanation.  AGP 7+ auto-merges that attribute into the merged
            // manifest, but we declare it explicitly in the source manifest as
            // defence-in-depth.
            useLegacyPackaging = true
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    // documentfile: DocumentFile.fromTreeUri()/listFiles() backing the
    // in-app ROM folder browser (see buildRomBrowser() in MainActivity.kt).
    // Tiny, stable, no transitive surprises — just a thin wrapper over SAF's
    // own content:// tree APIs, which is why it needs no extra permission
    // despite letting the app browse folders like a file manager (see the
    // comment above buildRomBrowser() for the full reasoning).
    implementation("androidx.documentfile:documentfile:1.0.1")
    // com.google.android.material:material — REMOVED. Nothing in this app
    // imports it (grep confirms zero androidx.material/com.google usages)
    // and the theme's parent is plain Theme.AppCompat.NoActionBar, not a
    // MaterialComponents theme, so it was dead weight: one of the larger
    // AndroidX libraries (buttons, chips, nav, cards, text fields, …),
    // included but never touched. Every dialog/widget here is
    // AlertDialog/CheckBox/RadioButton/etc. from appcompat or plain
    // android.widget, so removing it changes nothing at runtime.
}
