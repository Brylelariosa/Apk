/*
 * link_mailbox.h — hand-off between the child's NETWORK thread and its GAME
 * thread for one Multi-Player transfer at a time.
 *
 * Why this exists (audit, multiplayer pass)
 * -----------------------------------------
 * The child used to answer a host's request straight from the network thread:
 * write SIOMULTI0/1 into its own core, raise its SIO IRQ, and reply with
 * whatever SIOMLT_SEND already held — all without its CPU having executed a
 * single instruction since the previous request. A host ROM in its
 * connect/negotiation loop starts one transfer after another as fast as the
 * network allows (hundreds per second), so the child's ISR — which can only
 * run when the child's own game thread runs a frame — saw only a sample of
 * them, and every reply carried the child's data from BEFORE its ISR had
 * reacted to the previous transfer. Multi-Player link code is a lock-step
 * protocol (each side's next word depends on what it just received), so that
 * aliasing alone is enough to make a ROM give up with a communication error.
 *
 * With this mailbox the exchange is lock-step by construction:
 *   1. network thread: lm_post_and_wait(hostData) — blocks.
 *   2. game thread, start of its NEXT frame (once per frame, never more):
 *      lm_take_request() — the data is written into the core and the IRQ
 *      raised; the reply (the child's SIOMLT_SEND at THAT moment, i.e. what a
 *      real child would have put on the wire) is recorded with lm_set_reply()
 *      and the waiter is released with lm_complete().
 *   3. game thread runs the frame — the ISR reads the host's word and stages
 *      the NEXT outgoing word.
 *   4. the host's next request can only be taken at the start of the next
 *      frame, after step 3 has happened, so its reply reflects it. Exactly
 *      one transfer per child frame, in order, none skipped or merged.
 * (lm_complete() could instead be called after the frame; that would keep the
 * host blocked for a further frame per transfer without changing which data
 * goes where, so the caller releases at delivery.)
 *
 * Pure C + pthreads, no mGBA dependency, so it is unit-tested on the host
 * (tools/native-link-test/run.sh).
 */
#ifndef LINK_MAILBOX_H
#define LINK_MAILBOX_H

#include <pthread.h>
#include <stdbool.h>
#include <stdint.h>
#include <time.h>
#include <errno.h>

enum LinkMailboxState {
    LM_IDLE = 0,      /* nothing in flight                                   */
    LM_POSTED,        /* network thread posted a request, game thread hasn't taken it */
    LM_DELIVERED,     /* game thread took it and is running the frame        */
    LM_DONE           /* frame finished; the waiter may collect the reply    */
};

/* Result of lm_post_and_wait(). */
enum LinkMailboxResult {
    LM_OK = 1,
    LM_TIMEOUT = 0,
    LM_ABORTED = -1
};

typedef struct {
    pthread_mutex_t m;
    pthread_cond_t  cv;
    int             state;
    bool            abandoned;   /* waiter gave up while DELIVERED */
    bool            aborted;     /* link torn down: refuse/wake everyone */
    uint16_t        hostData;
    uint16_t        replyData;
} LinkMailbox;

static inline void lm_init(LinkMailbox *mb)
{
    pthread_condattr_t attr;
    pthread_mutex_init(&mb->m, NULL);
    pthread_condattr_init(&attr);
    pthread_condattr_setclock(&attr, CLOCK_MONOTONIC);
    pthread_cond_init(&mb->cv, &attr);
    pthread_condattr_destroy(&attr);
    mb->state = LM_IDLE;
    mb->abandoned = false;
    mb->aborted = true;          /* closed until lm_open() */
    mb->hostData = 0;
    mb->replyData = 0xFFFFu;
}

static inline void lm_deadline(struct timespec *ts, int timeout_ms)
{
    clock_gettime(CLOCK_MONOTONIC, ts);
    ts->tv_sec  += timeout_ms / 1000;
    ts->tv_nsec += (long)(timeout_ms % 1000) * 1000000L;
    if (ts->tv_nsec >= 1000000000L) { ts->tv_sec++; ts->tv_nsec -= 1000000000L; }
}

/* Start accepting requests (link session began). */
static inline void lm_open(LinkMailbox *mb)
{
    pthread_mutex_lock(&mb->m);
    mb->state = LM_IDLE;
    mb->abandoned = false;
    mb->aborted = false;
    pthread_mutex_unlock(&mb->m);
}

/* Stop accepting requests and wake any waiter (link ended / ROM swapped). */
static inline void lm_close(LinkMailbox *mb)
{
    pthread_mutex_lock(&mb->m);
    mb->aborted = true;
    mb->state = LM_IDLE;
    mb->abandoned = false;
    pthread_cond_broadcast(&mb->cv);
    pthread_mutex_unlock(&mb->m);
}

/* NETWORK THREAD. Posts one request and blocks until the game thread has run
 * a whole frame with it (LM_OK, *replyOut filled), the timeout passes
 * (LM_TIMEOUT), or the mailbox is closed (LM_ABORTED). */
static inline int lm_post_and_wait(LinkMailbox *mb, uint16_t hostData,
                                   int timeout_ms, uint16_t *replyOut)
{
    struct timespec dl;
    int result = LM_TIMEOUT;
    lm_deadline(&dl, timeout_ms);
    pthread_mutex_lock(&mb->m);

    /* A previous waiter that timed out mid-frame leaves the slot busy until
     * that frame ends; wait it out (bounded by the same deadline). */
    while (!mb->aborted && mb->state != LM_IDLE) {
        if (pthread_cond_timedwait(&mb->cv, &mb->m, &dl) == ETIMEDOUT) {
            pthread_mutex_unlock(&mb->m);
            return LM_TIMEOUT;
        }
    }
    if (mb->aborted) { pthread_mutex_unlock(&mb->m); return LM_ABORTED; }

    mb->hostData = hostData;
    mb->state = LM_POSTED;
    pthread_cond_broadcast(&mb->cv);

    while (!mb->aborted && mb->state != LM_DONE) {
        if (pthread_cond_timedwait(&mb->cv, &mb->m, &dl) == ETIMEDOUT) break;
    }

    if (mb->aborted) {
        result = LM_ABORTED;
    } else if (mb->state == LM_DONE) {
        if (replyOut) *replyOut = mb->replyData;
        mb->state = LM_IDLE;
        pthread_cond_broadcast(&mb->cv);
        result = LM_OK;
    } else if (mb->state == LM_POSTED) {
        mb->state = LM_IDLE;                 /* never taken: just withdraw it */
        pthread_cond_broadcast(&mb->cv);
        result = LM_TIMEOUT;
    } else {                                 /* LM_DELIVERED: frame still running */
        mb->abandoned = true;                /* lm_complete() will free the slot */
        result = LM_TIMEOUT;
    }
    pthread_mutex_unlock(&mb->m);
    return result;
}

/* GAME THREAD, start of a frame. If a request is waiting, takes it
 * (POSTED -> DELIVERED) and returns true with its data. */
static inline bool lm_take_request(LinkMailbox *mb, uint16_t *hostDataOut)
{
    bool took = false;
    pthread_mutex_lock(&mb->m);
    if (!mb->aborted && mb->state == LM_POSTED) {
        mb->state = LM_DELIVERED;
        if (hostDataOut) *hostDataOut = mb->hostData;
        took = true;
    }
    pthread_mutex_unlock(&mb->m);
    return took;
}

/* GAME THREAD, right after lm_take_request(): the value to send back. */
static inline void lm_set_reply(LinkMailbox *mb, uint16_t replyData)
{
    pthread_mutex_lock(&mb->m);
    mb->replyData = replyData;
    pthread_mutex_unlock(&mb->m);
}

/* GAME THREAD, end of the frame that followed lm_take_request(). */
static inline void lm_complete(LinkMailbox *mb)
{
    pthread_mutex_lock(&mb->m);
    if (mb->state == LM_DELIVERED) {
        if (mb->abandoned) {                 /* waiter already left */
            mb->abandoned = false;
            mb->state = LM_IDLE;
        } else {
            mb->state = LM_DONE;
        }
        pthread_cond_broadcast(&mb->cv);
    }
    pthread_mutex_unlock(&mb->m);
}

#endif /* LINK_MAILBOX_H */
