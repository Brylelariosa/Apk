package com.mgba.android

import android.content.Context
import android.graphics.Color
import android.text.TextUtils
import android.text.format.DateUtils
import android.text.format.Formatter
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/** Backs the ROM browser's ListView (audit-fix pass 5).
 *
 *  The old screen built one View tree per directory entry up front inside a
 *  ScrollView: a folder with a few thousand files meant a few thousand
 *  eagerly-inflated rows, all measured and held in memory at once. A
 *  ListView only ever creates the handful of rows that fit on screen and
 *  recycles them as you scroll — and it gets fast-scroll for free. It's the
 *  platform's own list, deliberately: RecyclerView would be one more
 *  dependency in build.gradle.kts for what is a flat, single-type list.
 *
 *  Rows carry no click handling or background of their own — the ListView
 *  owns item clicks and draws the press ripple through its selector (see
 *  RomBrowserActivity.buildUi()). A clickable row would swallow the tap
 *  before onItemClick ever fired. */
internal class RomBrowserAdapter(private val ctx: Context) : BaseAdapter() {

    private var items: List<BrowserEntry> = emptyList()

    // The size/date text is the only per-row work that isn't trivial
    // (locale-aware formatting), and ListView calls getView() constantly
    // while scrolling, so each subtitle is built once per listing.
    private val subtitles = HashMap<File, String>()

    fun submit(newItems: List<BrowserEntry>) {
        items = newItems
        subtitles.clear()
        notifyDataSetChanged()
    }

    override fun getCount(): Int = items.size

    override fun getItem(position: Int): BrowserEntry = items[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val row = convertView as? RowView ?: RowView(ctx)
        val entry = items[position]
        row.bind(entry, subtitleFor(entry))
        return row
    }

    private fun subtitleFor(e: BrowserEntry): String = subtitles.getOrPut(e.file) {
        val parts = ArrayList<String>(3)
        if (e.isZip) parts.add("ZIP")
        if (!e.isDirectory) parts.add(Formatter.formatShortFileSize(ctx, e.sizeBytes))
        if (e.modifiedMs > 0L) {
            parts.add(
                DateUtils.formatDateTime(
                    ctx, e.modifiedMs,
                    DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_ABBREV_MONTH or DateUtils.FORMAT_SHOW_YEAR
                )
            )
        }
        parts.joinToString(" · ")
    }

    private class RowView(ctx: Context) : LinearLayout(ctx) {
        private val icon = TextView(ctx)
        private val title = TextView(ctx)
        private val subtitle = TextView(ctx)
        private val chevron = TextView(ctx)

        init {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = ctx.dp(60)
            setPadding(ctx.dp(20), ctx.dp(10), ctx.dp(14), ctx.dp(10))

            icon.textSize = 20f
            icon.gravity = Gravity.CENTER
            icon.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            addView(icon, LinearLayout.LayoutParams(ctx.dp(40), LinearLayout.LayoutParams.WRAP_CONTENT))

            // Two lines for a long ROM name ("Pokemon - Emerald Version
            // (USA, Europe) (Rev 1).gba") instead of cutting it off at one.
            title.textSize = 15f
            title.setTextColor(Color.WHITE)
            title.maxLines = 2
            title.ellipsize = TextUtils.TruncateAt.END
            subtitle.textSize = 12f
            subtitle.setTextColor(Color.parseColor("#888892"))
            subtitle.maxLines = 1
            subtitle.ellipsize = TextUtils.TruncateAt.END
            val textColumn = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(title)
                addView(subtitle)
            }
            addView(textColumn, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

            chevron.text = "›"
            chevron.textSize = 22f
            chevron.setTextColor(Color.parseColor("#666670"))
            chevron.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            addView(
                chevron,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            )
        }

        fun bind(entry: BrowserEntry, subtitleText: String) {
            icon.text = when {
                entry.isDirectory -> "📁"
                entry.isZip -> "📦"
                else -> "🎮"
            }
            title.text = entry.name
            subtitle.text = subtitleText
            subtitle.visibility = if (subtitleText.isEmpty()) View.GONE else View.VISIBLE
            chevron.visibility = if (entry.isDirectory) View.VISIBLE else View.GONE
            contentDescription = when {
                entry.isDirectory -> "${entry.name}, folder"
                subtitleText.isNotEmpty() -> "${entry.name}, $subtitleText"
                else -> entry.name
            }
        }
    }
}
