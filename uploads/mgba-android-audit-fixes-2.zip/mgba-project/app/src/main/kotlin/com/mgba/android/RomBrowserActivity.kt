package com.mgba.android

import android.Manifest
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory

/** Where a list was scrolled to: the file shown at the top and how far down
 *  from the top edge it sat. Remembered per folder so Back returns to the
 *  place you left, and used to keep the list steady when rows are pruned
 *  out from under a scroll (see RomBrowserActivity.applyPrune()). [index] is
 *  only the fallback for when [path] has since disappeared. */
private class ScrollAnchor(val path: String, val offset: Int, val index: Int)

/** ROM selection — a free-roam local-storage file manager. Its own Activity
 *  (Thirty-second pass), not an overlay inside MainActivity the way it was
 *  through Thirty-first pass. That change exists for one reason: an actual
 *  forced orientation change for this screen, tried twice while it lived
 *  inside MainActivity's own window (once outright, once with the
 *  orientation change carefully spaced apart from other view work — the
 *  standard fix for exactly this class of race), caused a real native
 *  RenderThread SIGABRT — "drawRenderNode called on a context with no
 *  surface!" — on an actual device both times. The system's hardware
 *  renderer tried to draw a queued frame for a view whose window surface
 *  had been reconfigured out from under it by the orientation change; a
 *  native abort, not a JVM exception, so no try/catch in Kotlin could ever
 *  have caught it either time.
 *
 *  A separate Activity sidesteps the whole failure class rather than
 *  fighting it a third time: android:screenOrientation="portrait" in the
 *  manifest locks this screen's orientation statically, entirely at the
 *  platform level, with zero runtime requestedOrientation calls anywhere in
 *  this file — there is no "change" for RenderThread to race against.
 *  MainActivity's own game window is a genuinely separate window, paused
 *  while this one is in front, so there is also no shared window for a game
 *  frame and a browser frame to ever collide in.
 *
 *  Talks to MainActivity purely through registerForActivityResult(): picking
 *  a ROM calls setResult(RESULT_OK, Intent().setData(uri)) and finish()s;
 *  backing out with nothing picked (permission denied, system Back at the
 *  root, ✕ Close) leaves the result RESULT_CANCELED. See MainActivity's
 *  romBrowserLauncher/changeRom().
 *
 *  STRUCTURE (audit-fix pass 5). This file is now only UI + navigation. What
 *  gets listed, in which order, and which archives hold a ROM lives in three
 *  UI-free pieces:
 *    - RomBrowserModel.kt   — BrowserEntry, natural sort, SortMode, the
 *                              one-stat-per-entry DirectoryLister, search
 *                              filtering, storage volumes.
 *    - ZipRomVerifier.kt    — process-wide zip verdict cache + the shared
 *                              scan pool and its cancellable ZipScanJob.
 *    - RomBrowserAdapter.kt — recycled ListView rows.
 *  Listing and sorting run on a worker thread; the main thread only ever
 *  applies a finished result. */
class RomBrowserActivity : AppCompatActivity() {

    companion object {
        // Last folder browsed, a plain absolute path (not a SAF tree Uri —
        // this Activity doesn't use SAF for browsing at all, see
        // MainActivity.kt/AndroidManifest.xml for the ROM browser's own
        // permission choice). Just a starting point for convenience: an
        // invalid/vanished path here isn't an error, it's treated exactly
        // like "nothing remembered yet" and falls back to the device root
        // — see openAtRoot().
        private const val PREF_ROMS_LAST_FOLDER = "roms_last_folder"
        private const val PREF_ROMS_SORT = "roms_sort"
        private const val PREF_ROMS_SHOW_HIDDEN = "roms_show_hidden"
    }

    // ── Views ───────────────────────────────────────────────────────────
    private lateinit var listView: ListView
    private lateinit var emptyText: TextView
    private lateinit var backBtn: TextView
    private lateinit var crumbScroll: HorizontalScrollView
    private lateinit var crumbRow: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var statusSpinner: ProgressBar
    private lateinit var sortBtn: TextView
    private lateinit var searchRow: View
    private lateinit var searchInput: EditText

    // ── Collaborators ───────────────────────────────────────────────────
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val romAdapter by lazy { RomBrowserAdapter(this) }
    // Resolved once and reused by every crumb and the list selector instead
    // of re-resolving the same theme attribute each time (see
    // rippleBackgroundResId() in SharedUi.kt).
    private val rippleResId: Int by lazy { rippleBackgroundResId() }
    private val mainHandler = Handler(Looper.getMainLooper())
    // One worker, so listings never interleave: a stale one is skipped by
    // its generation check before it touches the disk (see refreshList()).
    private val listExecutor = Executors.newSingleThreadExecutor(ThreadFactory { r ->
        Thread(r, "mGBA-rom-list").apply { isDaemon = true }
    })

    // Internal storage plus any SD card / USB volume. Resolved on first use
    // (a Binder call or two), not at construction.
    private val roots: List<StorageRoot> by lazy { StorageRoots.list(this) }
    private lateinit var currentRoot: StorageRoot

    // ── Navigation / listing state (main thread only, unless noted) ─────
    // Root-to-current chain of folders; the last element is what's shown.
    private val stack = mutableListOf<File>()
    private var sortMode = SortMode.NAME_ASC
    private var showHidden = false
    private var browsing = false          // true once openAtRoot() has run (i.e. access was granted)
    // Bumped on every folder navigation so a listing or zip scan started for
    // a folder the user has since left can recognise its own result as stale
    // and drop it. Written on the main thread, read by the list worker.
    @Volatile private var generation = 0
    private var loading = false
    private var scanning = false
    private var unreadable = false
    private var allEntries: List<BrowserEntry> = emptyList()   // current folder, sorted, unfiltered
    private var searchQuery = ""
    private var scanJob: ZipScanJob? = null
    private var listScrolling = false
    // A scan result that arrived mid-scroll waits here and is applied when
    // the list next goes idle — see onScanFinished(). Paired with the
    // generation it belongs to.
    private var pendingPrune: Pair<Int, Set<File>>? = null
    private val scrollMemory = HashMap<String, ScrollAnchor>()
    private var emptyAction: (() -> Unit)? = null
    private var pickerLive = false
    private var pendingFileAccessAction: (() -> Unit)? = null

    // ── Permission plumbing ─────────────────────────────────────────────

    private val legacyStoragePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingFileAccessAction; pendingFileAccessAction = null
        if (granted) action?.invoke()
        else { uiToast("Storage permission is needed to browse for ROMs"); showAccessNeeded() }
    }

    // Android doesn't reliably report grant/deny in this screen's result
    // code across OEM skins, so this re-checks the real permission state
    // via hasBroadFileAccess() on return instead of trusting the callback
    // argument either way.
    private val allFilesAccessLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        val action = pendingFileAccessAction; pendingFileAccessAction = null
        if (hasBroadFileAccess()) action?.invoke()
        else { uiToast("Storage access wasn't granted — can't browse the device for ROMs"); showAccessNeeded() }
    }

    // Escape hatch: the classic single-file system picker, for anything
    // free-roam local browsing can't reach at all — a cloud-backed SAF
    // provider (Drive, Dropbox, ...) — or in case direct File access ever
    // misbehaves for someone's device. Needs no storage permission of its
    // own (that's the whole point of SAF), so this stays usable even if
    // broad file access above was denied.
    private val romPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pickerLive = false
        uri ?: return@registerForActivityResult
        setResult(RESULT_OK, Intent().setData(uri))
        finish()
    }

    // hasBroadFileAccess() lives in SharedUi.kt (Context.hasBroadFileAccess())
    // — MainActivity's own automatic own-folder mirror needs the exact same
    // check.

    /** Runs [action] immediately if broad file access is already granted,
     *  otherwise asks for it first — a normal runtime permission dialog on
     *  API < 30, or the dedicated "All files access" system Settings screen
     *  on API 30+, since that one *can't* be granted from an in-app dialog
     *  at all. Safe to call repeatedly: once granted, every later call just
     *  runs [action] straight away with no prompt. */
    private fun ensureBroadFileAccess(action: () -> Unit) {
        if (hasBroadFileAccess()) { action(); return }
        pendingFileAccessAction = action
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            uiToast("Pick \"Allow access to manage all files\" on the next screen")
            try {
                allFilesAccessLauncher.launch(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                // A handful of OEM skins don't ship the per-app variant of
                // this screen — fall back to the general all-apps list one,
                // which every API 30+ device has.
                Log.w(TAG, "per-app All files access screen unavailable, using general one", e)
                allFilesAccessLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            legacyStoragePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    // ── Lifecycle ───────────────────────────────────────────────────────

    // FIX (Fortieth pass — reported directly: opening this screen shows a
    // brief landscape flash before settling into portrait). Matches
    // MainActivity.changeRom()'s overridePendingTransition(0, 0) on the
    // way in — see that function's own comment for the full diagnosis.
    // Overriding finish() itself, rather than adding the same call before
    // each of this class's several finish() call sites (✕ Close, picking
    // a ROM, the SAF-picker callback, backing out at the root via
    // OnBackPressedCallback), covers all of them from one place and can't
    // be missed if a future pass adds another exit path. This is purely a
    // window-transition/animation call — it doesn't touch
    // requestedOrientation or anything else about this Activity's live
    // window, so it carries none of the RenderThread risk this file's own
    // top-of-file comment describes for that *different* class of change.
    @Suppress("DEPRECATION")
    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // MainActivity has handled the camera-cutout area since an earlier
        // pass; this Activity matches its choice (ALWAYS from API 30,
        // SHORT_EDGES down to 28) rather than the platform default. Locked
        // to Portrait (see the manifest), so the cutout sits at the top.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        sortMode = SortMode.fromId(prefs.getString(PREF_ROMS_SORT, null))
        showHidden = prefs.getBoolean(PREF_ROMS_SHOW_HIDDEN, false)
        setContentView(buildUi())

        // System Back unwinds one level at a time — close the filter box,
        // then go up a folder — and only exits (cancelled, same as ✕ Close)
        // once already at the root. OnBackPressedCallback (the base
        // androidx.activity API, not the activity-ktx addCallback{} lambda
        // extension — this project's build.gradle.kts doesn't declare that
        // artifact, only appcompat, which pulls in base androidx.activity
        // transitively) is the modern, predictive-back-aware way to do this
        // on this app's targetSdk.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    searchRow.visibility == View.VISIBLE -> closeSearch(rerender = true)
                    stack.size > 1 -> up()
                    else -> { setResult(RESULT_CANCELED); finish() }
                }
            }
        })

        if (!hasBroadFileAccess()) showAccessNeeded()
        ensureBroadFileAccess { openAtRoot() }
    }

    // Stops all background work when this Activity goes away for good.
    // shutdownNow() rather than shutdown(): nothing past this point cares
    // about a listing still in flight, since there's no Activity left to
    // post a result back to. The zip scan pool is process-wide (see
    // ZipRomVerifier) and deliberately NOT shut down here — its threads are
    // daemons that exit on their own once idle.
    override fun onDestroy() {
        super.onDestroy()
        generation++
        scanJob?.cancel()
        scanJob = null
        mainHandler.removeCallbacksAndMessages(null)
        listExecutor.shutdownNow()
    }

    // ── Navigation ──────────────────────────────────────────────────────

    /** Opens the browser where it was last left (see PREF_ROMS_LAST_FOLDER),
     *  on whichever storage volume that folder lives on, or at internal
     *  storage's root when nothing valid is remembered. */
    private fun openAtRoot() {
        browsing = true
        val saved = prefs.getString(PREF_ROMS_LAST_FOLDER, null)?.let { File(it) }?.takeIf { it.isDirectory }
        val root = saved?.let { rootContaining(it) } ?: roots.first()
        currentRoot = root
        stack.clear()
        stack.addAll(buildStack(root.dir, saved ?: root.dir))
        refreshList()
    }

    private fun rootContaining(f: File): StorageRoot? =
        roots.filter { f.path == it.dir.path || f.path.startsWith(it.dir.path + File.separator) }
            .maxByOrNull { it.dir.path.length }

    /** The chain of folders from [rootDir] down to [target]. Falls back to
     *  just the root alone if [target] isn't actually inside it (a stale
     *  remembered path whose folder has since moved or been deleted, most
     *  likely). */
    private fun buildStack(rootDir: File, target: File): MutableList<File> {
        val chain = mutableListOf<File>()
        var f: File? = target
        while (f != null) {
            chain.add(f)
            if (f == rootDir) break
            f = f.parentFile
        }
        return if (chain.last() == rootDir) chain.asReversed().toMutableList() else mutableListOf(rootDir)
    }

    private fun up() {
        if (stack.size > 1) navigateToDepth(stack.size - 2)
    }

    /** Pops the stack back so that [depth] (0 = the volume root) is the
     *  folder on screen. Used by Back/up and by tapping a breadcrumb. */
    private fun navigateToDepth(depth: Int) {
        if (depth < 0 || depth >= stack.size - 1) return
        rememberScroll()
        while (stack.size > depth + 1) stack.removeAt(stack.size - 1)
        refreshList()
    }

    private fun switchRoot(root: StorageRoot) {
        currentRoot = root
        stack.clear()
        stack.add(root.dir)
        refreshList()
    }

    private fun onEntryClicked(entry: BrowserEntry) {
        if (entry.isDirectory) {
            rememberScroll()
            // A folder opened fresh starts at its top; only coming *back* to
            // one restores where it was.
            scrollMemory.remove(entry.file.path)
            stack.add(entry.file)
            refreshList()
        } else {
            setResult(RESULT_OK, Intent().setData(Uri.fromFile(entry.file)))
            finish()
        }
    }

    private fun onCrumbClicked(index: Int) {
        if (index == 0 && roots.size > 1) showVolumePicker() else navigateToDepth(index)
    }

    // ── Listing pipeline ────────────────────────────────────────────────

    /** Shows the folder on top of [stack]. Everything slow happens on the
     *  list worker: the directory read, one stat() per entry, and the sort.
     *  The old implementation did all of that on the UI thread — with the
     *  sort calling File.isDirectory() (a syscall) inside its comparator,
     *  O(n log n) of them — so a big folder, or slow storage, froze the
     *  screen.
     *
     *  Folders, .gba files and .zip files all appear together the moment the
     *  listing lands, by name/extension alone (the instant full listing
     *  asked for in the "my boy file manager shows everything at once"
     *  report). Archives whose contents haven't been checked yet are then
     *  verified in the background (ZipScanJob) and the ones with no .gba
     *  inside are pruned back out — but verdicts are cached for the life of
     *  the process (ZipRomVerifier), so a folder you've already seen shows
     *  no spinner and no vanishing rows the second time. */
    private fun refreshList() {
        val myGeneration = ++generation
        scanJob?.cancel()
        scanJob = null
        pendingPrune = null
        scanning = false
        unreadable = false
        loading = true
        closeSearch(rerender = false)

        val dir = stack.last()
        // Remembered so reopening the browser later starts back here instead
        // of the device root every time. Written on every navigation rather
        // than only on close, so the app being killed mid-browse doesn't
        // lose it.
        prefs.edit().putString(PREF_ROMS_LAST_FOLDER, dir.path).apply()

        renderBreadcrumbs()
        allEntries = emptyList()
        romAdapter.submit(emptyList())
        refreshStatus()

        val sortUsed = sortMode
        val hidden = showHidden
        val anchor = scrollMemory[dir.path]
        listExecutor.execute {
            if (generation != myGeneration) return@execute
            val snapshot = (DirectoryLister.list(dir, hidden) as? ListResult.Ok)
                ?.let { buildSnapshot(it.entries, sortUsed) }
            mainHandler.post { onListed(myGeneration, sortUsed, snapshot, anchor) }
        }
    }

    private fun onListed(gen: Int, sortUsed: SortMode, snapshot: FolderSnapshot?, anchor: ScrollAnchor?) {
        if (gen != generation || isFinishing || isDestroyed) return
        loading = false
        if (snapshot == null) {
            unreadable = true
            allEntries = emptyList()
            romAdapter.submit(emptyList())
            refreshStatus()
            return
        }
        // The sort mode may have been changed while this listing was in flight.
        allEntries = if (sortUsed == sortMode) snapshot.entries
        else snapshot.entries.sortedWith(sortMode.comparator)
        val needScan = snapshot.unverifiedZips.isNotEmpty()
        scanning = needScan
        renderEntries(anchor)
        if (needScan) {
            val job = ZipScanJob(snapshot.unverifiedZips) { invalid ->
                mainHandler.post { onScanFinished(gen, invalid) }
            }
            scanJob = job
            job.start()
        }
    }

    private fun onScanFinished(gen: Int, invalid: Set<File>) {
        if (gen != generation || isFinishing || isDestroyed) return
        scanning = false
        if (invalid.isEmpty()) { refreshStatus(); return }
        // FIX (direct reports: "if i scroll some of the rom rearrange it's
        // weird" / "...happens then you scroll down"): a row vanishing while
        // a finger or fling is moving the list is exactly what read as
        // "rearranging". A result that lands mid-scroll waits until the list
        // is idle again (the OnScrollListener in buildUi()); applyPrune()
        // then also pins the row you were looking at, so nothing visible
        // jumps either way.
        if (listScrolling) { pendingPrune = gen to invalid; refreshStatus(); return }
        applyPrune(invalid)
    }

    private fun applyPrune(invalid: Set<File>) {
        val anchor = captureAnchor()
        allEntries = allEntries.filter { it.file !in invalid }
        renderEntries(anchor)
    }

    // ── Rendering ───────────────────────────────────────────────────────

    /** Pushes [allEntries] — narrowed by the current search — into the list,
     *  then puts the scroll position back at [anchor] (or the top). */
    private fun renderEntries(anchor: ScrollAnchor?) {
        val shown = allEntries.filteredBy(searchQuery)
        romAdapter.submit(shown)
        restoreScroll(shown, anchor)
        refreshStatus()
    }

    private fun restoreScroll(shown: List<BrowserEntry>, anchor: ScrollAnchor?) {
        if (anchor == null || shown.isEmpty()) { listView.setSelection(0); return }
        var index = shown.indexOfFirst { it.file.path == anchor.path }
        var offset = anchor.offset
        if (index < 0) { index = anchor.index.coerceIn(0, shown.size - 1); offset = 0 }
        listView.setSelectionFromTop(index, offset)
    }

    private fun captureAnchor(): ScrollAnchor? {
        val pos = listView.firstVisiblePosition
        if (pos < 0 || pos >= romAdapter.count) return null
        val top = (listView.getChildAt(0)?.top ?: 0) - listView.paddingTop
        return ScrollAnchor(romAdapter.getItem(pos).file.path, top, pos)
    }

    /** Call before leaving the folder on screen. */
    private fun rememberScroll() {
        val dir = stack.lastOrNull() ?: return
        val anchor = captureAnchor()
        if (anchor != null) {
            scrollMemory[dir.path] = anchor
        } else {
            scrollMemory.remove(dir.path)
        }
    }

    /** The status line (count / filter result / what's still running) and
     *  the centred message that replaces an empty list. Always derived from
     *  the current state, never patched piecemeal. */
    private fun refreshStatus() {
        statusSpinner.visibility = if (loading || scanning) View.VISIBLE else View.GONE
        val total = allEntries.size
        val shown = romAdapter.count
        val base = when {
            loading -> "Loading…"
            unreadable -> ""
            searchQuery.isNotBlank() -> "$shown of $total"
            total == 1 -> "1 item"
            else -> "$total items"
        }
        statusText.text = if (scanning && !loading && !unreadable) "$base · checking archives…" else base

        when {
            loading -> hideMessage()
            unreadable -> showMessage(
                "Can't open this folder.\n\nAndroid may be hiding it from apps, or the storage isn't available."
            )
            shown == 0 && searchQuery.isNotBlank() -> showMessage("No matches for “${searchQuery.trim()}”")
            shown == 0 -> showMessage("No ROMs or folders here")
            else -> hideMessage()
        }
    }

    private fun showMessage(text: String, action: (() -> Unit)? = null) {
        emptyText.text = text
        emptyAction = action
        emptyText.visibility = View.VISIBLE
    }

    private fun hideMessage() {
        emptyAction = null
        emptyText.visibility = View.GONE
    }

    private fun showAccessNeeded() {
        showMessage("Storage access is needed to browse for ROMs.\n\nTap here to allow it, or use the system file picker below.") {
            ensureBroadFileAccess { openAtRoot() }
        }
    }

    /** Path as tappable crumbs — jump straight to any ancestor instead of
     *  pressing Back once per level. A long path scrolls sideways (kept
     *  scrolled to the end, where you are) rather than wrapping onto extra
     *  lines and shoving the list down. With more than one storage volume,
     *  the first crumb opens the volume picker. */
    private fun renderBreadcrumbs() {
        crumbRow.removeAllViews()
        backBtn.visibility = if (stack.size > 1) View.VISIBLE else View.INVISIBLE
        stack.forEachIndexed { index, dir ->
            if (index > 0) {
                crumbRow.addView(TextView(this).apply {
                    text = "›"; textSize = 13f
                    setTextColor(Color.parseColor("#666670"))
                })
            }
            val label = if (index == 0) {
                if (roots.size > 1) currentRoot.label + " ▾" else currentRoot.label
            } else dir.name
            crumbRow.addView(crumb(label, isLast = index == stack.lastIndex) { onCrumbClicked(index) })
        }
        crumbScroll.post { crumbScroll.fullScroll(View.FOCUS_RIGHT) }
    }

    // ── Search & view options ───────────────────────────────────────────

    private fun toggleSearch() {
        if (searchRow.visibility == View.VISIBLE) { closeSearch(rerender = true); return }
        searchRow.visibility = View.VISIBLE
        searchInput.requestFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT)
    }

    /** Hides the filter box and drops its text. [rerender] is false when the
     *  list is about to be replaced anyway (a navigation). */
    private fun closeSearch(rerender: Boolean) {
        val hadQuery = searchQuery.isNotEmpty()
        searchQuery = ""
        searchInput.setText("")
        searchRow.visibility = View.GONE
        hideKeyboard()
        if (rerender && hadQuery && browsing && !loading) renderEntries(null)
    }

    private fun onQueryChanged(text: CharSequence?) {
        val q = text?.toString().orEmpty()
        if (q == searchQuery) return
        searchQuery = q
        // While a listing is in flight there's nothing to filter yet; the
        // query is applied when it lands (see onListed()).
        if (!browsing || loading) return
        renderEntries(null)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(searchInput.windowToken, 0)
    }

    /** Sort order + hidden-files switch. Both apply the instant they change
     *  (like Settings → Gameplay) — the list behind the dialog updates
     *  live, and Done just closes it. */
    private fun showViewOptions() {
        val modes = SortMode.values()
        val group = RadioGroup(this)
        modes.forEach { group.dlgAddOpt(it.label) }
        val currentOption = group.getChildAt(modes.indexOf(sortMode)) as RadioButton
        currentOption.isChecked = true
        group.setOnCheckedChangeListener { g, checkedId ->
            for (i in 0 until g.childCount) {
                if (g.getChildAt(i).id == checkedId) { applySortMode(modes[i]); break }
            }
        }
        val hiddenCheck = CheckBox(this).apply {
            text = "Show hidden files"
            isChecked = showHidden
            setTextColor(Color.WHITE)
            setPadding(0, dp(16), 0, 0)
            setOnCheckedChangeListener { _, checked -> applyShowHidden(checked) }
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(12), dp(24), dp(4))
            addView(TextView(this@RomBrowserActivity).apply {
                text = "Sort by"; textSize = 12f
                setTextColor(Color.parseColor("#888892"))
                setPadding(0, 0, 0, dp(6))
            })
            addView(group)
            addView(hiddenCheck)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("View options")
            .setView(content)
            .setPositiveButton("Done", null)
            .create()
        dlg.window?.setBackgroundDrawable(roundedDialogBackground())
        dlg.show()
    }

    private fun applySortMode(mode: SortMode) {
        if (mode == sortMode) return
        sortMode = mode
        prefs.edit().putString(PREF_ROMS_SORT, mode.id).apply()
        updateSortChip()
        // Re-sorting is purely in memory — no need to touch the disk again.
        // (A listing still in flight is re-sorted when it lands.)
        if (!browsing || loading) return
        allEntries = allEntries.sortedWith(mode.comparator)
        renderEntries(null)
    }

    private fun applyShowHidden(show: Boolean) {
        if (show == showHidden) return
        showHidden = show
        prefs.edit().putBoolean(PREF_ROMS_SHOW_HIDDEN, show).apply()
        if (!browsing) return
        // Hidden entries are filtered at the source, so this one does need a
        // fresh listing — but stay where you were in it.
        rememberScroll()
        refreshList()
    }

    private fun updateSortChip() {
        sortBtn.text = "↕ " + sortMode.shortLabel
    }

    private fun showVolumePicker() {
        val labels = roots.map { it.label }.toTypedArray()
        val dlg = AlertDialog.Builder(this)
            .setTitle("Storage")
            .setItems(labels) { _, which ->
                val picked = roots[which]
                if (picked == currentRoot) navigateToDepth(0) else switchRoot(picked)
            }
            .create()
        dlg.window?.setBackgroundDrawable(roundedDialogBackground())
        dlg.show()
    }

    // ── UI construction ─────────────────────────────────────────────────

    /** Small outlined button in the same style as the ✕ Close chip. */
    private fun chip(label: String, description: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(colorAccentLight)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        isClickable = true; isFocusable = true
        background = iconChipBackground()
        contentDescription = description
        setOnClickListener { onClick() }
    }

    private fun crumb(label: String, isLast: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 13f
        if (isLast) {
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        } else {
            setTextColor(colorAccentLight)
        }
        setPadding(dp(6), dp(10), dp(6), dp(10))
        isClickable = true; isFocusable = true
        setBackgroundResource(rippleResId)
        setOnClickListener { onClick() }
    }

    private fun buildUi(): View {
        val ctx = this

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(16), dp(14))
            addView(TextView(ctx).apply {
                text = "Load game"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(ctx).apply {
                text = "✕ Close"; textSize = 13f
                setTextColor(colorAccentLight)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
                setOnClickListener { setResult(RESULT_CANCELED); finish() }
            })
        }

        // Path: ⟵ up, then the breadcrumb trail.
        backBtn = TextView(ctx).apply {
            text = "⟵"; textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(8), dp(12), dp(8))
            isClickable = true; isFocusable = true
            contentDescription = "Up one folder"
            setOnClickListener { up() }
        }
        crumbRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        crumbScroll = HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(crumbRow)
        }
        val pathRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(2), dp(14), 0)
            addView(backBtn)
            addView(crumbScroll, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }

        // Status line + search / sort buttons. A fixed row, outside the
        // list, so a scan starting or finishing can't shift any rows.
        statusSpinner = ProgressBar(ctx).apply {
            isIndeterminate = true
            indeterminateTintList = ColorStateList.valueOf(colorAccentLight)
            visibility = View.GONE
        }
        statusText = TextView(ctx).apply {
            textSize = 12f
            setTextColor(Color.parseColor("#888892"))
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        sortBtn = chip("↕ " + sortMode.shortLabel, "Sort and view options") { showViewOptions() }
        val toolsRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(4), dp(14), dp(8))
            addView(statusSpinner, LinearLayout.LayoutParams(dp(14), dp(14)).apply { marginEnd = dp(8) })
            addView(statusText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(chip("🔍", "Search this folder") { toggleSearch() },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .apply { marginEnd = dp(8) })
            addView(sortBtn)
        }

        // Filter box, hidden until the 🔍 button opens it.
        searchInput = EditText(ctx).apply {
            hint = "Filter this folder"
            setHintTextColor(Color.parseColor("#666670"))
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            background = iconChipBackground()
            setPadding(dp(14), dp(8), dp(14), dp(8))
            doAfterTextChanged { onQueryChanged(it) }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) { hideKeyboard(); true } else false
            }
        }
        searchRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(20), 0, dp(20), dp(8))
            visibility = View.GONE
            addView(searchInput, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }

        // The list itself: a ListView only builds the handful of rows on
        // screen and recycles them (see RomBrowserAdapter). Press feedback
        // comes from the list's selector, which is why rows aren't
        // individually clickable.
        listView = ListView(ctx).apply {
            adapter = romAdapter
            divider = null
            dividerHeight = 0
            setSelector(rippleResId)
            isFastScrollEnabled = true
            setOnItemClickListener { _, _, position, _ -> onEntryClicked(romAdapter.getItem(position)) }
            setOnScrollListener(object : AbsListView.OnScrollListener {
                override fun onScrollStateChanged(view: AbsListView?, scrollState: Int) {
                    listScrolling = scrollState != AbsListView.OnScrollListener.SCROLL_STATE_IDLE
                    if (listScrolling) {
                        if (searchRow.visibility == View.VISIBLE) hideKeyboard()
                    } else {
                        val pending = pendingPrune
                        pendingPrune = null
                        if (pending != null && pending.first == generation) applyPrune(pending.second)
                    }
                }

                override fun onScroll(view: AbsListView?, firstVisibleItem: Int, visibleItemCount: Int, totalItemCount: Int) {}
            })
        }
        emptyText = TextView(ctx).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#888892"))
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
            visibility = View.GONE
            setOnClickListener { emptyAction?.invoke() }
        }
        val listFrame = FrameLayout(ctx).apply {
            addView(listView, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(emptyText, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        }

        val fallbackRow = TextView(ctx).apply {
            text = "Use system file picker instead"
            textSize = 12f
            setTextColor(Color.parseColor("#888892"))
            setPadding(dp(20), dp(10), dp(20), dp(16))
            isClickable = true; isFocusable = true
            setOnClickListener {
                if (!pickerLive) { pickerLive = true; romPicker.launch(arrayOf("*/*")) }
            }
        }

        // Full screen, edge to edge — this Activity's whole window really is
        // portrait (manifest-locked), so there's nothing to fake or center
        // against.
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FF17171B"))
            addView(header)
            addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
            addView(pathRow)
            addView(toolsRow)
            addView(searchRow)
            addView(listFrame, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(fallbackRow)
        }
    }
}
