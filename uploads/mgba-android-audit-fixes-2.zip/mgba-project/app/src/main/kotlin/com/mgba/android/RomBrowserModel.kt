package com.mgba.android

import android.content.Context
import android.os.Environment
import android.os.storage.StorageManager
import android.system.ErrnoException
import android.system.Os
import android.system.OsConstants
import android.system.StructStat
import android.util.Log
import androidx.core.content.ContextCompat
import java.io.File

// ── ROM browser data layer (audit-fix pass 5) ─────────────────────────
// Everything about *what* the file manager lists and in what order: no
// views, no Activity. RomBrowserActivity.kt is now only UI + navigation;
// these pieces are plain Kotlin over java.io.File, so listing, sorting and
// filtering can run on a worker thread and stay small enough to unit-test
// on a plain JVM later if that is ever wanted.

/** One row in the browser. Built once per directory entry from a single
 *  stat() (see [DirectoryLister]) and immutable afterwards, so it can be
 *  handed from the listing thread to the UI thread, sorted, filtered and
 *  cached without any copying or locking. [name] is captured once because
 *  File.getName() allocates a new String on every call and the sort
 *  comparators call it O(n log n) times. */
internal class BrowserEntry(
    val file: File,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val modifiedMs: Long,
) {
    val name: String = file.name
    val isZip: Boolean = !isDirectory && name.endsWith(".zip", ignoreCase = true)

    /** What name-sorting compares first: the name without its extension
     *  (folders keep theirs — "v1.5" is not an extension). Without this,
     *  "Advance Wars 2.gba" sorts before "Advance Wars.gba", because a
     *  space orders ahead of the "." that starts the extension. */
    val sortStem: String = if (isDirectory) name else name.substringBeforeLast('.', name)
}

/** Case-insensitive "natural" ordering: runs of digits compare by numeric
 *  value, so "Game 2.gba" sorts before "Game 10.gba" (a plain alphabetical
 *  sort puts 10 first). A digit run is one token; when two runs have the
 *  same value the one with fewer leading zeros goes first, and every other
 *  character compares case-insensitively. A digit run versus a non-digit
 *  compares by the characters themselves, and no non-digit character sits
 *  between '0' and '9', so the ordering stays transitive — which matters,
 *  because the platform's TimSort throws on a comparator that breaks that
 *  contract. */
internal object NaturalOrder : Comparator<String> {
    override fun compare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (isAsciiDigit(ca) && isAsciiDigit(cb)) {
                var zi = i
                while (zi < a.length && a[zi] == '0') zi++
                var zj = j
                while (zj < b.length && b[zj] == '0') zj++
                var ei = zi
                while (ei < a.length && isAsciiDigit(a[ei])) ei++
                var ej = zj
                while (ej < b.length && isAsciiDigit(b[ej])) ej++
                val lenA = ei - zi
                val lenB = ej - zj
                if (lenA != lenB) return if (lenA < lenB) -1 else 1
                for (k in 0 until lenA) {
                    val d = a[zi + k] - b[zj + k]
                    if (d != 0) return d
                }
                val zerosA = zi - i
                val zerosB = zj - j
                if (zerosA != zerosB) return if (zerosA < zerosB) -1 else 1
                i = ei
                j = ej
            } else {
                val la = Character.toLowerCase(ca)
                val lb = Character.toLowerCase(cb)
                if (la != lb) return la.compareTo(lb)
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }

    private fun isAsciiDigit(c: Char): Boolean = c in '0'..'9'
}

// Name order: natural order of the extension-less names, then of the full
// names, then a case-sensitive tie-break so two names that differ only by
// case (possible on a case-sensitive filesystem) still order
// deterministically. Each step is a valid ordering of its own, and a
// lexicographic chain of valid orderings is one too.
private val NAME_ORDER = Comparator<BrowserEntry> { a, b ->
    var c = NaturalOrder.compare(a.sortStem, b.sortStem)
    if (c == 0) c = NaturalOrder.compare(a.name, b.name)
    if (c == 0) c = a.name.compareTo(b.name)
    c
}
private val NAME_ORDER_DESC = Comparator<BrowserEntry> { a, b -> NAME_ORDER.compare(b, a) }
private val FOLDERS_FIRST = Comparator<BrowserEntry> { a, b ->
    when {
        a.isDirectory == b.isDirectory -> 0
        a.isDirectory -> -1
        else -> 1
    }
}
private val BY_DATE_DESC = Comparator<BrowserEntry> { a, b -> b.modifiedMs.compareTo(a.modifiedMs) }
// FOLDERS_FIRST has already separated the two kinds by the time this runs,
// so "a is a folder" means both are — a folder's own size is meaningless,
// leave those to the name tie-break.
private val BY_SIZE_DESC = Comparator<BrowserEntry> { a, b ->
    if (a.isDirectory) 0 else b.sizeBytes.compareTo(a.sizeBytes)
}

/** The browser's sort orders. Folders always group above files, whatever
 *  the mode — the way every file manager does it. [id] is what gets
 *  persisted; [label] is the dialog text, [shortLabel] the toolbar chip's. */
internal enum class SortMode(val id: String, val label: String, val shortLabel: String) {
    NAME_ASC("name_asc", "Name (A–Z)", "A–Z"),
    NAME_DESC("name_desc", "Name (Z–A)", "Z–A"),
    DATE_DESC("date_desc", "Newest first", "Newest"),
    SIZE_DESC("size_desc", "Largest first", "Largest");

    val comparator: Comparator<BrowserEntry>
        get() = when (this) {
            NAME_ASC -> FOLDERS_FIRST.then(NAME_ORDER)
            NAME_DESC -> FOLDERS_FIRST.then(NAME_ORDER_DESC)
            DATE_DESC -> FOLDERS_FIRST.then(BY_DATE_DESC).then(NAME_ORDER)
            SIZE_DESC -> FOLDERS_FIRST.then(BY_SIZE_DESC).then(NAME_ORDER)
        }

    companion object {
        fun fromId(id: String?): SortMode = values().firstOrNull { it.id == id } ?: NAME_ASC
    }
}

internal sealed class ListResult {
    class Ok(val entries: List<BrowserEntry>) : ListResult()
    /** listFiles() returned null: no permission, a folder Android hides
     *  from apps (Android/data on API 30+), a vanished mount, an I/O error. */
    object Unreadable : ListResult()
}

internal object DirectoryLister {

    /** Lists [dir]: sub-folders, .gba files and .zip files (the only things
     *  the loader can open), minus dot-files unless [showHidden].
     *
     *  Meant for a worker thread. The old implementation did this on the UI
     *  thread and called File.isDirectory() inside the sort comparator —
     *  a stat() syscall per comparison, O(n log n) of them for a folder of
     *  n entries. Here every entry gets exactly one stat() (via Os.stat, which
     *  also hands back size and mtime for free), and nothing downstream ever
     *  touches the filesystem again. */
    fun list(dir: File, showHidden: Boolean): ListResult {
        val children = dir.listFiles() ?: return ListResult.Unreadable
        val out = ArrayList<BrowserEntry>(children.size)
        for (f in children) {
            val name = f.name
            if (!showHidden && name.startsWith(".")) continue
            val st = statOrNull(f)
            val isDir = if (st != null) OsConstants.S_ISDIR(st.st_mode) else f.isDirectory
            if (!isDir && !isRomName(name)) continue
            val size = if (isDir) 0L else (st?.st_size ?: f.length())
            val modified = if (st != null) st.st_mtime * 1000L else f.lastModified()
            out.add(BrowserEntry(f, isDir, size, modified))
        }
        return ListResult.Ok(out)
    }

    private fun isRomName(name: String): Boolean =
        name.endsWith(".gba", ignoreCase = true) || name.endsWith(".zip", ignoreCase = true)

    // Falls back to the java.io.File getters when stat() fails (broken
    // symlink, a path the app can't traverse): same answers the old code
    // got, just three syscalls instead of one.
    private fun statOrNull(f: File): StructStat? = try {
        Os.stat(f.path)
    } catch (e: ErrnoException) {
        null
    }
}

/** A folder's listing, ready to display: [entries] already sorted, with any
 *  .zip already *known* not to hold a .gba left out; [unverifiedZips] are
 *  the shown archives whose contents haven't been checked yet (see
 *  [ZipRomVerifier]). */
internal class FolderSnapshot(
    val entries: List<BrowserEntry>,
    val unverifiedZips: List<BrowserEntry>,
)

/** Turns a raw listing into a [FolderSnapshot]. Zips are shown straight
 *  away by name (the instant full listing this screen has promised since
 *  the "my boy file manager shows everything at once" report), except that
 *  an archive already proven *not* to contain a .gba — in an earlier visit,
 *  this process — is never shown at all, so it can't flash up and vanish a
 *  second time. */
internal fun buildSnapshot(raw: List<BrowserEntry>, sort: SortMode): FolderSnapshot {
    val visible = ArrayList<BrowserEntry>(raw.size)
    val unknown = ArrayList<BrowserEntry>()
    for (e in raw) {
        if (e.isZip) {
            val verdict = ZipRomVerifier.cachedVerdict(e)
            if (verdict == false) continue
            if (verdict == null) unknown.add(e)
        }
        visible.add(e)
    }
    visible.sortWith(sort.comparator)
    return FolderSnapshot(visible, unknown)
}

/** In-memory search: case-insensitive "name contains query". A blank query
 *  returns the receiver itself. */
internal fun List<BrowserEntry>.filteredBy(query: String): List<BrowserEntry> {
    val q = query.trim()
    if (q.isEmpty()) return this
    return filter { it.name.contains(q, ignoreCase = true) }
}

/** A browsable storage volume: internal shared storage, or an SD card / USB
 *  drive. */
internal class StorageRoot(val dir: File, val label: String)

internal object StorageRoots {

    /** Internal shared storage first, then every other mounted volume the
     *  platform reports. The old browser's ceiling was internal storage
     *  alone, so ROMs on an SD card were unreachable except through the
     *  system picker (KNOWN_LIMITATIONS, Thirty-first pass).
     *
     *  Other volumes are found through getExternalFilesDirs(): each entry is
     *  this app's own folder on one volume, ".../Android/data/<pkg>/files",
     *  so everything before "/Android/" is that volume's root. That works
     *  from API 19 on and avoids StorageVolume.getDirectory(), which only
     *  exists on API 30+ (this app's minSdk is 24). Never throws: on any
     *  failure the result is just internal storage, i.e. the old behaviour. */
    fun list(context: Context): List<StorageRoot> {
        val primary = Environment.getExternalStorageDirectory()
        val out = ArrayList<StorageRoot>()
        out.add(StorageRoot(primary, "Internal storage"))
        try {
            val primaryCanonical = primary.canonicalPath
            val storageManager = context.getSystemService(Context.STORAGE_SERVICE) as? StorageManager
            for (appDir in ContextCompat.getExternalFilesDirs(context, null)) {
                val path = appDir?.absolutePath ?: continue
                val cut = path.indexOf("/Android/")
                if (cut <= 0) continue
                val root = File(path.substring(0, cut))
                val canonical = root.canonicalPath
                if (canonical == primaryCanonical || out.any { it.dir.canonicalPath == canonical }) continue
                if (!root.isDirectory) continue
                val described = storageManager?.getStorageVolume(root)?.getDescription(context)
                out.add(StorageRoot(root, if (described.isNullOrBlank()) root.name else described))
            }
        } catch (e: Exception) {
            Log.w(TAG, "storage volume scan failed — browsing internal storage only", e)
        }
        return out
    }
}
