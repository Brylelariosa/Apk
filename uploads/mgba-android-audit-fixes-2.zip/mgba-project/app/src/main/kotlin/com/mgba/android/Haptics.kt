package com.mgba.android

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/**
 * Short vibration "tick" for on-screen button presses (Settings -> Gameplay ->
 * Haptic feedback).
 *
 * Uses the Vibrator service directly rather than View.performHapticFeedback():
 * that route obeys the system-wide "touch feedback" switch (and on Android 13+
 * ignores the flag that used to override it), so an in-app toggle that is ON
 * could still do nothing and look broken. This needs the plain VIBRATE
 * permission (granted at install, no prompt).
 *
 * [strength] is 0 = light, 1 = medium, 2 = strong. Amplitude control is used
 * where the hardware has it; otherwise only the duration differs.
 */
internal class Haptics(context: Context) {

    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)
                ?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

    fun tick(strength: Int) {
        val v = vibrator ?: return
        if (!v.hasVibrator()) return
        val level = strength.coerceIn(0, 2)
        val ms = DURATIONS_MS[level]
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val amplitude = if (v.hasAmplitudeControl()) AMPLITUDES[level]
                                else VibrationEffect.DEFAULT_AMPLITUDE
                v.vibrate(VibrationEffect.createOneShot(ms, amplitude))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        } catch (_: Exception) {
            // A vibrator that refuses (permission revoked, service hiccup) must
            // never take the touch handler down with it.
        }
    }

    private companion object {
        val DURATIONS_MS = longArrayOf(8L, 14L, 22L)
        val AMPLITUDES = intArrayOf(70, 150, 255)
    }
}
