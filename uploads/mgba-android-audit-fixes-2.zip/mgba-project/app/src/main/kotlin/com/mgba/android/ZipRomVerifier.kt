package com.mgba.android

import android.util.Log
import java.io.File
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

// ── "Does this .zip actually contain a .gba?" (audit-fix pass 5) ───────
// The ROM browser lists archives instantly by name and checks their
// contents in the background (see RomZipUtils.zipContainsGba(File), a
// central-directory read). Two things used to be wrong with how that was
// orchestrated inside RomBrowserActivity:
//   * every verdict was thrown away when the Activity closed, so reopening
//     the browser re-scanned every archive and showed (then pruned) the same
//     non-ROM zips again;
//   * each folder navigation created a waiter Thread whose only job was to
//     block on the pool's futures.
// The cache and the pool live here now, process-wide; the Activity only
// holds a [ZipScanJob] handle per navigation.

internal object ZipRomVerifier {
    private const val WORKERS = 4
    private const val MAX_CACHED = 4096

    // Access-ordered LinkedHashMap used as an LRU: get() reorders it, so
    // *every* access takes the lock (not just writes).
    private val verdicts = object : LinkedHashMap<String, Boolean>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?): Boolean =
            size > MAX_CACHED
    }

    // Same worker count the old per-Activity pool used (this work is I/O
    // bound, so core count is the wrong thing to size it by), but daemon
    // threads that exit after a few idle seconds — nothing has to shut this
    // pool down when an Activity goes away, and an idle process holds none.
    private val pool = ThreadPoolExecutor(
        WORKERS, WORKERS, 3L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>(),
        ThreadFactory { r -> Thread(r, "mGBA-rom-zip-scan").apply { isDaemon = true } }
    ).apply { allowCoreThreadTimeOut(true) }

    // Path + size + mtime: a replaced or re-downloaded archive gets a new
    // key and is scanned again; an untouched one is never scanned twice.
    private fun keyOf(e: BrowserEntry): String = e.file.path + '|' + e.sizeBytes + '|' + e.modifiedMs

    /** true / false = already checked (holds / doesn't hold a .gba);
     *  null = never checked, or the file changed since. */
    fun cachedVerdict(e: BrowserEntry): Boolean? = synchronized(verdicts) { verdicts[keyOf(e)] }

    /** Checks [e] now, on the calling thread, and remembers the answer.
     *  Anything unreadable counts as "no .gba", as zipContainsGba() itself
     *  already treats it. */
    fun scan(e: BrowserEntry): Boolean {
        val valid = try {
            RomZipUtils.zipContainsGba(e.file)
        } catch (t: Throwable) {
            Log.e(TAG, "zip content scan failed for ${e.name}", t)
            false
        }
        synchronized(verdicts) { verdicts[keyOf(e)] = valid }
        return valid
    }

    fun submit(task: Runnable) {
        pool.execute(task)
    }
}

/** One background pass over the archives of one folder listing. [onFinished]
 *  is called once, on a pool thread (post to the UI thread yourself), with
 *  the files that turned out NOT to hold a .gba — and not at all if
 *  [cancel] was called first. [zips] must be non-empty, otherwise
 *  [onFinished] never fires.
 *
 *  Cancelling is cooperative: archives not started yet are skipped
 *  outright, one already running is allowed to finish (a central-directory
 *  read is a few KB) and its verdict still lands in the cache. */
internal class ZipScanJob(
    private val zips: List<BrowserEntry>,
    private val onFinished: (invalid: Set<File>) -> Unit,
) {
    @Volatile private var cancelled = false
    private val remaining = AtomicInteger(zips.size)
    private val invalid = HashSet<File>()   // guarded by itself

    fun start() {
        for (z in zips) ZipRomVerifier.submit(Runnable { scanOne(z) })
    }

    fun cancel() {
        cancelled = true
    }

    private fun scanOne(z: BrowserEntry) {
        if (!cancelled && !ZipRomVerifier.scan(z)) {
            synchronized(invalid) { invalid.add(z.file) }
        }
        // The last worker to finish reports — no thread ever has to sit and
        // wait on the others.
        if (remaining.decrementAndGet() == 0 && !cancelled) {
            onFinished(synchronized(invalid) { HashSet(invalid) })
        }
    }
}
