package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


// isZipSignature()/zipContainsGba() moved to RomZipUtils.kt this pass
// (Thirty-second) when the ROM browser became its own Activity —
// RomBrowserActivity needs zipContainsGba() too, and this way there's
// still only one copy of the byte comparison between it and
// stageRomFile() below, same as when both lived in this class.

/** Copies [uri] into [tmp]. If the source is a zip archive — detected by
 *  its real magic bytes (see RomZipUtils.isZipSignature()), not by file
 *  extension, so a misnamed archive still works and a .zip that somehow
 *  isn't a real zip is correctly rejected instead of handed to the core
 *  as garbage — the first .gba entry found inside is extracted instead
 *  of the raw archive bytes. This is what lets both the file browser
 *  and the classic system picker load a ROM straight out of a .zip with
 *  no separate extraction step. Returns false if nothing worth loading
 *  ended up in [tmp] (unreadable source, or a zip with no .gba entry). */
internal fun MainActivity.stageRomFile(uri: Uri, tmp: File): Boolean {
    val raw = contentResolver.openInputStream(uri) ?: return false
    raw.use { stream ->
        val input = stream.buffered()
        if (!RomZipUtils.isZipSignature(input)) {
            val ok = tmp.outputStream().use { o -> copyCapped(input, o, MAX_ROM_BYTES) }
            if (!ok) tmp.delete()
            return ok
        }
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".gba", ignoreCase = true)) {
                    val ok = tmp.outputStream().use { o -> copyCapped(zip, o, MAX_ROM_BYTES) }
                    if (!ok) tmp.delete()
                    return ok
                }
                entry = zip.nextEntry
            }
        }
        return false
    }
}

/** AUDIT FIX: ceiling on how many bytes stageRomFile() will write. A GBA
 *  cartridge tops out at 32 MiB; 64 MiB leaves room for odd dumps while
 *  keeping a wrong pick — a huge file renamed .gba, or a zip bomb whose one
 *  .gba entry inflates to gigabytes — from filling the app's cache. */
private const val MAX_ROM_BYTES = 64L * 1024 * 1024

/** Copies [input] to [output], stopping with false (and logging) as soon as
 *  more than [limit] bytes would be written. */
private fun copyCapped(input: java.io.InputStream, output: java.io.OutputStream, limit: Long): Boolean {
    val buf = ByteArray(64 * 1024)
    var total = 0L
    while (true) {
        val n = input.read(buf)
        if (n < 0) return true
        total += n
        if (total > limit) {
            Log.w(TAG, "stageRomFile: source exceeds $limit bytes — refusing to stage it as a ROM")
            return false
        }
        output.write(buf, 0, n)
    }
}


/** Stages [uri] (transparently unzipping it first if needed — see
 *  stageRomFile()), swaps it into the running core, and updates the UI
 *  on success or failure. Shared by every ROM entry point — the classic
 *  system picker above and the in-app file browser's file rows below
 *  both just call this now, instead of each duplicating the load. */
internal fun MainActivity.loadRomFromUri(uri: Uri) {
    // AUDIT FIX (ROM-swap races): capture whether a session exists and mark
    // it gone for the duration of the swap, synchronously, before the loader
    // thread even starts. romLoaded used to stay true all the way through, so
    // an onPause() landing between the native core swap and the UI-thread
    // post below would autosave the NEW ROM's state under the OLD ROM's name
    // (currentRomBaseName isn't updated until that post), and an onResume()
    // in the same window could restart the old core's loop mid-swap. With it
    // false, both skip — there is no consistent session to save or resume
    // until the post below (or resumeSessionAfterFailedSwap()) says so.
    val hadSession = romLoaded
    if (hadSession) romLoaded = false
    Thread {
        // Set once nativeLoadROM() has actually replaced the old core; before
        // that point any failure leaves the previous session intact and
        // resumable (see resumeSessionAfterFailedSwap()).
        var swapped = false
        try {
            // FIX: nativeLoadROM() silently drops any active link session
            // as part of swapping the native core (see the "ROM swapped
            // while a link session was active" comment in mgba_jni.c) —
            // that side is careful to avoid leaving a dangling pointer,
            // but it has no way to tell the Kotlin side this happened.
            // Without this, link.isConnected and the ⬤ LINK overlay would
            // keep claiming "Connected" after a ROM swap even though the
            // native SIO driver backing the exchange no longer exists —
            // a silently broken multiplayer session with no indication
            // in the UI of why. Disconnect first so both sides agree.
            if (link.isConnected) stopLink()
            // FIX (Twenty-first pass): if a Storage folder is configured
            // and a ROM is already running, its battery save has only
            // ever been mirrored to internal storage (see
            // SaveEntry.batteryMirrorPath()) — the real document in the
            // chosen folder hasn't seen anything played since the last
            // sync point. Flush it out now, before that mirror file gets
            // reused for the ROM we're about to swap in, or whatever was
            // played this session never reaches the chosen folder at all.
            // mirrorToAutoFolder() alongside it: same flush moment, just
            // for the automatic own-folder mirror instead of a chosen
            // SAF folder — see the FEATURE block above dataFolderTree().
            // AUDIT FIX: the game thread is stopped FIRST and the flush
            // happens after. It used to be the other way round, so SRAM
            // writes the still-running game made between the flush and the
            // stop never reached the Storage-folder mirror.
            //
            // FIX: stop any in-progress game loop *before* touching the
            // native core, and reset transient input/FF state. Previously
            // there was no way to load a second ROM at all (loadRomBtn was
            // permanently hidden after the first successful load), so this
            // path was never exercised. nativeLoadROM() now builds the new
            // core fully before swapping it in, so a failed load here
            // leaves the previous session running rather than destroying
            // it (see mgba_jni.c).
            stopGameLoop()
            if (hadSession) {
                batterySaveEntry(currentRomBaseName).syncBatteryMirror()
                batterySaveEntry(currentRomBaseName).mirrorToAutoFolder()
            }
            // AUDIT FIX: stage into its OWN file, not rom_loaded.gba. The
            // running core memory-maps its ROM file for its whole lifetime
            // (mGBA's GBALoadROM maps the VFile), and stageRomFile()
            // truncates and rewrites whatever file it is given — doing that
            // to rom_loaded.gba rewrote the live core's ROM out from under
            // it, and left a corrupt copy behind for resetGame() whenever
            // staging or loading then failed. The staged file is only
            // renamed over rom_loaded.gba once the new core has loaded it.
            val tmp = cacheDir.resolve("rom_loading.gba")
            if (!stageRomFile(uri, tmp)) {
                tmp.delete()
                uiToast("Couldn't read that file (or found no .gba inside the zip)")
                resumeSessionAfterFailedSwap(hadSession)
                return@Thread
            }
            // ROM SAVE: identify the ROM by its picked display name —
            // not the fixed "rom_loaded.gba" cache path above, which
            // every ROM shares — so its battery save persists under a
            // name stable across app restarts and re-picking the same
            // file later. See deriveRomBaseName()/batterySaveEntry().
            val baseName = deriveRomBaseName(uri, tmp)
            migrateLegacyRomFiles(legacyRomBaseName(uri), baseName)
            val saveEntry = batterySaveEntry(baseName)
            backupBatteryIfExists(saveEntry)   // AUDIT FIX: copy, not rename — see SaveEntry.copyInto()
            // FIX (Twenty-first pass): was saveEntry.nativePath(forWrite
            // = true).path — a /proc/self/fd bridge straight onto the SAF
            // document, mmap'd by the core for the whole session. See the
            // block comment above dataFolderTree() for why that doesn't
            // hold up on a real device. batteryMirrorPath() below is
            // always a plain local path; when a Storage folder is
            // configured it stages the existing save in from there first.
            val savePath = saveEntry.batteryMirrorPath()
            val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath, savePath)
            if (ok) {
                swapped = true
                // The new core now has tmp mapped; renaming keeps that
                // mapping valid (same inode) while making this the ROM copy
                // resetGame() reloads from. The old core, already torn down
                // inside nativeLoadROM(), held the previous inode.
                val canonical = cacheDir.resolve("rom_loaded.gba")
                canonical.delete()
                if (!tmp.renameTo(canonical)) {
                    Log.w(TAG, "Couldn't publish ${tmp.name} as ${canonical.name} — Reset Game may not find the ROM")
                }
            } else {
                tmp.delete()
            }
            Handler(Looper.getMainLooper()).post romLoadDone@ {
                // FIX: onDestroy() may have already run and freed the
                // native core by the time this posts, if the load was
                // slow (large ROM, a slow SAF/cloud-backed URI) and the
                // user backed out of the app in the meantime. Without
                // this check, the block below would re-init AudioTrack
                // and start a brand new game thread + Choreographer
                // registration after teardown — resources nothing would
                // ever clean up, since onDestroy() has already run and
                // won't run again for this instance.
                if (isFinishing || isDestroyed) return@romLoadDone
                // BUG FIX: this whole block runs on the MAIN thread,
                // asynchronously, well after loadRomFromUri's own
                // try/catch — wrapping the background Thread body above
                // — has already finished and returned. That catch does
                // NOT protect anything in here despite the misleading
                // nesting; Handler.post() only schedules this lambda,
                // it doesn't run it, so by the time this body actually
                // executes the outer try is long gone. Any exception
                // here (Bitmap.createBitmap, AudioTrack init, the
                // thread/Choreographer setup in startGameLoop()) was
                // previously a genuine uncaught exception on the main
                // thread — a hard app crash, with the ROM having *just*
                // finished loading successfully.
                try {
                    if (ok) {
                        val w = EmulatorEngine.nativeGetWidth().coerceAtLeast(1)
                        val h = EmulatorEngine.nativeGetHeight().coerceAtLeast(1)
                        frameBuffers = Array(3) {
                            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        }
                        writeIdx = 0
                        readyIdx = -1
                        displayIdx = -1
                        // AUDIT FIX: the name is set BEFORE romLoaded flips
                        // true, so no reader can ever see "a ROM is loaded"
                        // paired with the previous ROM's save key.
                        currentRomBaseName = baseName
                        romLoaded = true
                        // FIX (this pass): see applyScreenOrientationPref()'s
                        // own doc comment. This activity was Portrait the
                        // whole time RomBrowserActivity was open (idle —
                        // see that function) — now that a ROM is actually
                        // loaded, switch to the user's chosen gameplay
                        // orientation, before startGameLoop() below starts
                        // rendering.
                        applyScreenOrientationPref()
                        clearPointerState()
                        currentKeys.set(0)
                        fastForwardActive = false
                        // FEATURE (direct report — Misc setting "Auto
                        // Save & Load": "...points load it back on
                        // start"): the other half of onPause()'s own
                        // autosave write — see that function's doc
                        // comment for why *that* half is synchronous.
                        // This half is synchronous for a related but
                        // different reason: it has to finish before
                        // startGameLoop() below starts rendering, or
                        // the very first frame(s) shown would briefly
                        // be the ROM's own boot state before snapping
                        // to the restored one. currentRomBaseName is
                        // already set above, so autoStateEntry() below
                        // resolves to *this* ROM's own autosave, not
                        // whichever ROM was playing last. Silent when
                        // there's nothing to load (no toast, no
                        // "nothing found" message) — this runs on
                        // literally every ROM load, and most of the
                        // time, especially the very first time this ROM
                        // is ever opened, there won't be one yet.
                        if (autoSaveLoadEnabled) {
                            val autoEntry = autoStateEntry()
                            if (autoEntry.exists()) {
                                val autoLocalPath = autoEntry.stageForRead()
                                if (autoLocalPath != null && EmulatorEngine.nativeLoadState(autoLocalPath)) {
                                    uiToast("Autosave loaded")
                                }
                            }
                        }
                        initAudioTrack()
                        startGameLoop()
                    } else {
                        uiToast("Unsupported ROM format")
                        if (hadSession) {
                            // AUDIT FIX: nativeLoadROM() builds the new core
                            // off to the side and leaves the old one
                            // untouched on failure, but this used to leave
                            // the loop stopped and romLoaded false anyway —
                            // a dead screen on top of a perfectly good
                            // session. Put the old one back.
                            romLoaded = true
                            startGameLoop()
                        } else {
                            romLoaded = false
                        }
                    }
                } catch (e: Throwable) {
                    // Leave the app in a state the user can recover from
                    // instead of a crash: no half-started game, surface
                    // wiped, and romLoaded left false so a tap on the
                    // idle screen (see onGameTouch()) reopens the ROM
                    // browser instead of leaving a dead screen behind.
                    Log.e(TAG, "ROM load post-processing failed", e)
                    uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
                    romLoaded = false
                    clearSurfaceToBlack()
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "ROM load failed", e)
            uiToast("Load error: ${e.message ?: e.javaClass.simpleName}")
            // Only safe to resume if the old core is still the live one.
            if (!swapped) resumeSessionAfterFailedSwap(hadSession)
        }
    }.apply { name = "mGBA-load" }.start()
}

/**
 * AUDIT FIX: a ROM swap (or Reset) that fails BEFORE the native core is
 * replaced — unreadable file, no .gba in the zip, a thrown exception —
 * leaves the previous core alive and untouched, so the previous session
 * should simply carry on. It used to be left with its loop stopped and
 * romLoaded false, i.e. a dead screen. No-op when there was no session to
 * go back to. Posts to the UI thread because it restarts the game loop.
 */
internal fun MainActivity.resumeSessionAfterFailedSwap(hadSession: Boolean) {
    if (!hadSession) return
    Handler(Looper.getMainLooper()).post {
        if (isFinishing || isDestroyed) return@post
        romLoaded = true
        startGameLoop()
    }
}


/** Entry point for loading/swapping the ROM — called from onCreate() on
 *  first launch, from closeGame() when backing out of a game, and from
 *  onGameTouch() when the idle (no-ROM-loaded) surface is tapped.
 *  Launches RomBrowserActivity (a separate Activity as of Thirty-second
 *  pass, not an overlay in this one — see its own top-of-file comment)
 *  and waits for a result; romBrowserLauncher above hands whatever it
 *  returns to loadRomFromUri(). Broad file access, the folder browsing
 *  itself, and the classic single-document SAF picker fallback are all
 *  that Activity's own concern now, not this one's. */
internal fun MainActivity.changeRom() {
    romBrowserLauncher.launch(Intent(this, RomBrowserActivity::class.java))
    // FIX (Fortieth pass — reported directly: opens in landscape,
    // "then it go to portrait instantly"). This app is normally in
    // landscape during play; RomBrowserActivity is manifest-locked to
    // portrait (see its own top-of-file comment for why that's a
    // static declaration and NOT a runtime requestedOrientation call —
    // this fix doesn't touch that at all, for the same reason).
    // Actually rotating the physical display for the new Activity is a
    // real reconfiguration, and the default slide/fade activity
    // transition gives it a couple of animated frames to be visible
    // mid-rotation, which is what reads as "opens landscape, then
    // snaps to portrait". overridePendingTransition(0, 0) collapses
    // that transition to nothing, so the swap is an instant cut
    // instead of an animated one with a wrong-orientation frame in the
    // middle. Deprecated as of API 34 (replaced by
    // overrideActivityTransition) but still fully functional at this
    // app's targetSdk 34 — kept as the plain call rather than a
    // version-gated branch since the two behave identically here and
    // there's nothing to verify a newer, unfamiliar signature against
    // in this sandbox (no compiler/device, as every pass). See
    // RomBrowserActivity's own finish() override for the matching
    // fix on the way back.
    @Suppress("DEPRECATION")
    overridePendingTransition(0, 0)
}


// ── Save / state file naming ─────────────────────────────────────────
// SAF (Storage Access Framework) URIs don't carry a real filesystem
// path, and the only identifier for "which ROM is this" that's stable
// across app restarts and re-picking the same file is the picked
// document's display name — queried via ContentResolver, since
// uri.lastPathSegment is often an opaque provider-specific ID rather
// than the actual filename on many document providers (Downloads,
// Google Drive, etc).

/** The ROM's display name minus its extension, exactly as the provider
 *  reported it (or the URI's last path segment as a fallback) — not yet
 *  sanitized. Shared by deriveRomBaseName() and legacyRomBaseName(). */
private fun MainActivity.romRawBaseName(uri: Uri): String {
    var display: String? = null
    try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) display = c.getString(idx)
            }
    } catch (_: Exception) {
        // Provider didn't support the query — fall through to the
        // URI-based fallback below.
    }
    return (display ?: uri.lastPathSegment ?: "rom").substringBeforeLast('.')
}

/** CRC32 of the staged ROM file as 8 lowercase hex digits, or null if it
 *  can't be read. java.util.zip.CRC32 is intrinsified on arm64, so even a
 *  32 MB ROM takes a few tens of milliseconds. */
private fun romCrc32Hex(file: File): String? = try {
    val crc = java.util.zip.CRC32()
    val buf = ByteArray(64 * 1024)
    file.inputStream().use { input ->
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            crc.update(buf, 0, n)
        }
    }
    "%08x".format(crc.value)
} catch (e: Exception) {
    Log.w(TAG, "romCrc32Hex(${file.name}) failed — falling back to a name-only save key", e)
    null
}

/**
 * AUDIT FIX (save collisions): the key every battery save, state slot,
 * quicksave, autosave and thumbnail is filed under.
 *
 * It used to be only the sanitized file name, so two different ROMs with
 * the same name (a ROM hack and its base game, "Pokemon.gba" in two
 * folders, ...) silently shared one .sav and one set of states — and any
 * title that sanitized away entirely (an all-Japanese name became "____")
 * collided with every other such title. The key is now
 * `<sanitized name>_<CRC32 of the ROM>`: same file = same saves, different
 * ROM = different saves, even under an identical name. Unicode letters and
 * digits are kept in the readable part (modern Android filesystems are fine
 * with them), so non-Latin titles stay distinguishable by name too.
 *
 * [stagedRom] is the local copy stageRomFile() already produced (already
 * unzipped if the source was a .zip), so the hash is of the actual ROM
 * bytes, not of the archive around them.
 *
 * Existing installs: files saved under the old name-only key are copied
 * across by migrateLegacyRomFiles(), called right after this.
 */
internal fun MainActivity.deriveRomBaseName(uri: Uri, stagedRom: File): String {
    val readable = romRawBaseName(uri)
        .replace(Regex("[^\\p{L}\\p{N}_-]"), "_")
        .take(48)
        .ifBlank { "rom" }
    val crc = romCrc32Hex(stagedRom)
    return if (crc != null) "${readable}_$crc" else readable
}

/** The key saves were filed under BEFORE the CRC suffix was added — the
 *  old sanitizer, verbatim. Only used to find files to migrate. */
internal fun MainActivity.legacyRomBaseName(uri: Uri): String =
    romRawBaseName(uri).replace(Regex("[^A-Za-z0-9_-]"), "_").take(80).ifBlank { "rom" }

/**
 * One-time carry-over of saves filed under the old name-only key
 * ([legacyBase]) to the new CRC-suffixed one ([newBase]): every
 * `<legacyBase>.*` file in the local saves/ and states/ folders, and — best
 * effort — in the chosen Storage folder's "save" subfolder.
 *
 * COPIES, never moves. Which ROM a legacy file "really" belongs to can't be
 * known (that is the collision this change ends), and a file that merely
 * shares a name — a corrupt download, an unsupported ROM that then fails to
 * load — must not be able to take saves away from the real one. The old
 * files are left in place, so the worst case is some duplicated bytes, never
 * a lost save; once you've confirmed everything carried over they are safe
 * to delete by hand.
 *
 * Only copies when the destination doesn't exist yet, so it can never
 * overwrite saves made under the new key, and each copy goes through a temp
 * file + rename so a crash can't leave a truncated file that then blocks the
 * real migration. The exact "<legacyBase>." prefix (sanitized names contain
 * no dots) means one ROM's migration can't pick up another ROM's files.
 *
 * Call from a background thread: it does file and SAF I/O.
 */
internal fun MainActivity.migrateLegacyRomFiles(legacyBase: String, newBase: String) {
    if (legacyBase == newBase) return
    // First ROM to load under a given legacy key claims it; every later ROM
    // that used to share that key starts clean instead of also inheriting a
    // copy of the shared save (which is exactly the collision being fixed).
    val claimKey = "legacy_saves_claimed_$legacyBase"
    val claims = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    if (claims.contains(claimKey)) return
    val legacyPrefix = "$legacyBase."
    val newPrefix = "$newBase."
    for (dir in listOf(savesDir(), statesDir())) {
        dir.listFiles { f -> f.isFile && f.name.startsWith(legacyPrefix) && !f.name.contains(".tmp-") }
            ?.forEach { old ->
                val dest = File(dir, newPrefix + old.name.substring(legacyPrefix.length))
                if (dest.exists()) return@forEach
                val tmp = File(dir, "${dest.name}.tmp-mig")
                try {
                    old.copyTo(tmp, overwrite = true)
                    if (tmp.renameTo(dest)) Log.i(TAG, "Carried over ${old.name} -> ${dest.name}")
                    else Log.w(TAG, "Couldn't carry over ${old.name} -> ${dest.name}")
                } catch (e: Exception) {
                    Log.w(TAG, "Couldn't carry over ${old.name} -> ${dest.name}", e)
                } finally {
                    tmp.delete()   // no-op once the rename succeeded
                }
            }
    }
    val folder = dataSubfolder("save")
    try {
        if (folder != null) for (doc in folder.listFiles()) {
            val n = doc.name ?: continue
            if (!n.startsWith(legacyPrefix)) continue
            val newName = newPrefix + n.substring(legacyPrefix.length)
            if (folder.findFile(newName) != null) continue
            val dst = folder.createFile("application/octet-stream", newName) ?: continue
            contentResolver.openInputStream(doc.uri)?.use { input ->
                contentResolver.openOutputStream(dst.uri, "wt")?.use { out -> input.copyTo(out) }
            }
        }
    } catch (e: Exception) {
        Log.w(TAG, "Storage-folder carry-over skipped", e)
    }
    claims.edit().putString(claimKey, newBase).apply()
}

