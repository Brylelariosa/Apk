# NovaLLM build order

Custom text-only LLM for Android. No TensorFlow, no ONNX, no third-party ML
framework — every piece below is hand-written C++, compiled via NDK, called
through a thin JNI bridge. Built one subsystem at a time, verified on-device
before moving to the next.

Name/package (`com.jarry.novallm`) is a placeholder — rename `applicationId`/
`namespace` in `app/build.gradle` and the `com/jarry/novallm` folder anytime.

## Status

- [x] **1. core/math** — Tensor, Matrix (matmul/add/transpose/addBias/scale), MemoryPool.
      Naive O(n^3) matmul, correctness-first. Verified with a standalone g++
      test suite (`tests/test_math.cpp`) AND on-device via the JNI test button
      in the shipped APK.
- [x] **2. core/tokenizer** — UTF8 (decode/validate), Vocabulary (256 base
      byte tokens + growable), BPE (train + greedy lowest-rank encode),
      Tokenizer facade (train/encode/decode/save/load). Byte-level, so
      there is no "unknown token" case - anything not covered by a learned
      merge just stays as raw byte tokens and still round-trips exactly.
      No pretokenization step yet (whole byte stream is one BPE sequence,
      not pre-split on whitespace) - simpler and still fully correct, just
      leaves some compression quality on the table; worth revisiting once
      the rest of the pipeline exists to actually benefit from it.
      Verified with a standalone g++ test suite (`tests/test_tokenizer.cpp`,
      24 checks) AND on-device via a second JNI test button.
- [x] **3. core/embedding** — TokenEmbedding (learned {vocabSize, embedDim}
      lookup table, GPT-2-style small Gaussian init, single + sequence
      lookup) and PositionalEncoding (fixed sinusoidal table, `applyTo()`
      adds it to embeddings). RoPE is intentionally NOT here - it rotates
      Q/K vectors inside attention, so it belongs in core/transformer once
      attention exists, not at the embedding stage. Verified with a
      standalone g++ suite (`tests/test_embedding.cpp`, 33 checks) AND
      on-device via a third JNI button that chains the real pipeline:
      text -> trained tokenizer -> ids -> embeddings -> +positional encoding.
- [x] **4. core/transformer** — Linear (shared weight+bias layer),
      LayerNorm, FeedForward (GELU, tanh approximation), MultiHeadAttention
      (causal, scaled dot-product, head split/merge via new
      `matrix::sliceColumns`/`setColumns`), TransformerBlock (pre-norm:
      x -> LN -> Attn -> +x -> LN -> FFN -> +). Residual connections are
      just `matrix::add()` calls, not a separate class - no Residual.cpp on
      purpose. KVCache is deferred to core/runtime (subsystem 6) since it's
      a generation-loop optimization, not a correctness requirement for a
      single forward pass.
      Verified with a standalone g++ suite (`tests/test_transformer.cpp`,
      19 checks) that includes the single most important correctness test
      in the project so far: changing only the LAST token in a sequence
      must leave every earlier position's output byte-for-byte identical.
      That held both at the raw attention level and end-to-end through the
      full block. Also verified by actually *executing* jni_bridge.cpp's
      real exported functions locally against a stubbed JNI env (not just
      compiling them) before this ever reached device, and on-device via a
      fourth JNI button running the same causal-leakage check with real
      random weights.
- [x] **5. core/decoder** — Model (stacks TokenEmbedding + N TransformerBlocks
      + final LayerNorm + LM head into one forward pass; "Logits" is just
      its {seqLen, vocabSize} output shape, not a separate class), Sampling
      (temperature -> softmax -> top-k -> top-p -> renormalize -> sample;
      temperature=0 is deterministic greedy argmax), Generator (the actual
      autoregressive loop: encode prompt, repeatedly forward+sample+append,
      decode). No KV cache yet (subsystem 6) - every new token recomputes
      the whole forward pass, correct but O(n^2). Text generation is now
      real and running end to end, but weights are untrained (random), so
      output is structurally correct gibberish until subsystem 7 exists -
      that's expected, not a bug.
      One real hazard caught here: sampling can select ANY byte-level
      token, so generated text can contain embedded nulls / invalid UTF-8.
      Handing that straight to JNI's `NewStringUTF` was unsafe (silent
      truncation at minimum, undefined behavior at worst) - added
      `escapeForDisplay()` in jni_bridge.cpp so raw bytes are always shown
      safely (confirmed necessary: the on-device run's output did contain
      non-printable bytes).
      Verified with a standalone g++ suite (`tests/test_decoder.cpp`, 8
      checks - including re-proving causality at the full multi-layer
      model level, greedy determinism, top-k/top-p edge behavior, and an
      empirical sampling-distribution check against known softmax
      probabilities) AND by actually executing all five JNI functions
      locally against the stub before this ever reached device.
- [x] **6. core/runtime** — split into two independently-verified halves:
      **Model save/load** (fulfills "ModelLoader" from the original list -
      it's methods on Model itself, not a separate class, same reasoning
      as Residual/Logits earlier): every learned-parameter class
      (Tensor -> Linear -> LayerNorm -> TokenEmbedding -> MultiHeadAttention
      -> FeedForward -> TransformerBlock -> Model) now has stream-based
      save/load, composed hierarchically. Generation cache state is
      deliberately NOT persisted - it's ephemeral per-sequence state, not
      a learned parameter.
      **KVCache** (fulfills "Cache" from the original list; lives in
      core/transformer/ since it's tightly coupled to attention, not
      core/runtime/) - one per layer, appends new K/V and serves the full
      cached history back for attention. `MultiHeadAttention::
      forwardIncremental()` and `TransformerBlock::forwardIncremental()`
      use it; LayerNorm/FeedForward needed no changes since they're
      already position-wise. `PositionalEncoding::encodeRange()` was
      required too - new tokens sit at their TRUE sequence position, not
      position 0, and getting that wrong would silently produce a broken
      model rather than crash. `Generator` now actually uses this path.
      Scheduler/ThreadPool/Quantization from the original runtime/ list
      are correctly deferred to subsystem 8 (Android optimization pass),
      not forgotten.
      Verification for this subsystem went further than usual given how
      easy KV-cache position bugs are to get subtly wrong: KVCache was
      tested in isolation first, then the standalone suite
      (`tests/test_decoder.cpp`, now 13 checks) directly compares
      KV-cached incremental output against the already-trusted non-cached
      forward() - both token-by-token AND whole-prompt-priming - and
      confirms save/load round-trips bit-for-bit. Every prior subsystem's
      test suite was re-run after these changes with zero regressions.
      On-device (sixth button): save/load round trip PASS, KV cache
      exactness PASS, and a real speed comparison - generating 40 tokens
      took 85ms non-cached vs 8ms KV-cached on-device, roughly 10x, even
      on this tiny model.
- [ ] 7. **training** — dataset loader, loss (cross-entropy), backprop, optimizer (start with plain SGD or Adam), checkpointing
- [ ] 8. **Android optimization pass** — quantization (int8), NEON SIMD, thread pool, memory pool wiring throughout

## Versioning

Zip filenames and `versionName`/`versionCode` in `app/build.gradle` are now
tied to subsystem count (v7 = subsystems 1-6 done + training part 1) so
it's obvious which delivery is which. Bumps each time a zip goes out.

## APK size pass (alongside subsystem 7)

No feature removed, no ABI split (still one universal apk, not multiple
per-architecture outputs):

- Dropped `androidx.appcompat` + `androidx.core:core-ktx` entirely - never
  actually used beyond one theme string and `.apply{}` (Kotlin stdlib, not
  core-ktx). `MainActivity` is now a plain `Activity`, manifest theme is a
  built-in platform theme.
- `abiFilters` restricted to `arm64-v8a` only - your Hot 11 is 64-bit: this
  was compiling every subsystem's C++ twice for an architecture nothing
  here uses. Add `armeabi-v7a` back if you ever test on a 32-bit device.
- `ANDROID_STL` switched from `c++_shared` to `c++_static` - with exactly
  one native lib in this app, static linking drops the separate
  libc++_shared.so and only pulls in the libc++ pieces actually used.
- Native symbols now explicitly stripped at link time (`-s`) regardless of
  buildType. This mattered more than expected: **your CI builds
  `assembleDebug` by default (no keystore secret configured)**, and AGP
  does not strip native debug info from debug builds the way it does for
  release - every .so shipped so far has been carrying full debug symbols.
- `minifyEnabled`/`shrinkResources` enabled on the `debug` buildType
  specifically (not just `release`), since debug is what your pipeline
  actually produces. Added `proguard-rules.pro` with an explicit keep rule
  for `MainActivity`'s native methods - R8 renaming the JNI-bound class or
  an `external fun` wouldn't fail the build, it'd fail at runtime with
  `UnsatisfiedLinkError` the first time a button is tapped, silently past
  compile time. Worth knowing about if any *future* class ever needs
  reflection or name-based lookup too.

Can't measure the actual before/after size in this sandbox (no Android
SDK/NDK here) - compare the artifact size in your next Actions run against
a previous one.

## Training (subsystem 7) - part 1 of N

Backprop through a whole transformer is the single biggest remaining
subsystem, so it's being built in verified slices rather than one pass.
This slice: gradient-check infrastructure, plus backward() for everything
that ISN'T attention (attention's backward - through softmax, causal
masking, and the multi-head split - is real enough to deserve its own
focused pass, not to be rushed alongside everything else).

- [x] `core/training/GradientCheck.h` - numerical gradient checking via
      central differences, the standard way to verify a hand-written
      backward pass. Every backward() below is checked against this.
- [x] `Linear::backward`, `LayerNorm::backward` - both add a `Grads`
      struct and a `backward(x, gradOutput)` method alongside `forward()`.
- [x] `geluGrad()` alongside `gelu()`.
- [x] `FeedForward::backward` - composes `Linear::backward` on both
      layers through `geluGrad`, recomputing the fc1/gelu intermediate
      rather than caching it from forward() (simpler interface, one
      redundant fc1 pass per backward call).
- [x] `core/training/Loss.h` - `CrossEntropyLoss::forwardBackward()`,
      combining softmax+cross-entropy analytically for the classic
      `probs - one_hot(target)` gradient, reusing `matrix::softmaxRows`
      for the third time now.
- [ ] Attention backward (softmax + causal mask + multi-head split/merge)
- [ ] Embedding backward (scatter-add into the embedding table)
- [ ] Full `Model::backward()` composing all of the above through N
      blocks in reverse
- [ ] Optimizer (Adam, not plain SGD - transformers famously don't train
      well with vanilla SGD, and building SGD first here would be
      throwaway work)
- [ ] Dataset loader, training loop, checkpointing via the save/load
      from subsystem 6

### A debugging detour worth recording

Every backward pass above initially "failed" gradient checking, and none
of those failures were real - all four were fixed without touching a
single line of backward-pass math:

1. **The checker itself had a bug.** Its near-zero handling
   (`denom < 1e-8f`) was far tighter than the actual float32 noise floor
   of central-difference estimation. When a true gradient is exactly 0,
   the numerical estimate lands on tiny rounding noise (~1e-6), not exact
   0 - dividing by a near-zero denominator turned that harmless noise into
   a misleading ~100% relative error. Fixed by flooring the denominator at
   1e-3 instead of branching on it.
2. **Clean/symmetric test inputs are actively bad for gradient checking.**
   Arithmetic-sequence x values combined with a uniform gradOutput
   (loss = sum(output)) kept coincidentally producing true gradients that
   are genuinely tiny for specific dimensions - not a bug, just an
   unlucky test fixture, but tiny-true-gradient cases are exactly where
   finite-difference noise reads as a large *relative* error even after
   fix #1. Switched every check to pseudo-random x AND a pseudo-random
   loss direction (`loss = dot(output, random_vector)`), which essentially
   never produces an exact-zero true gradient by coincidence.
3. **Finite-difference epsilon needs to match the computation's local
   curvature scale**, not be a fixed global constant. Confirmed by sweeping
   epsilon from 1e-1 to 1e-6 against LayerNorm and watching the
   numerical/analytical ratio go 0.01 -> 0.56 -> 0.96 -> 0.84 -> 0.22 ->
   -0.07 - too large an epsilon picks up second-order curvature the
   analytical (first-derivative) gradient doesn't include; too small and
   float32 rounding dominates. 1e-3 was the sweet spot here.
4. **Longer computation chains need more tolerance, not more suspicion.**
   CrossEntropy (softmax: exp, sum, divide, then log) accumulates more
   float32 rounding than a single matmul. 21/24 sampled elements matched
   under 1%; the rest were small-magnitude gradients where a couple
   percent of noise is expected. Confirmed independently via a
   numerical-precision-free structural check (gradient sign must be
   negative at the target class, positive elsewhere) before loosening the
   tolerance, specifically to rule out "loosened the threshold to hide a
   real bug."

Net lesson for the rest of training: random test data, floored/relative
error with a sane denominator floor, and tolerance scaled to how many
operations are actually chained - all four apply directly to the harder
attention-backward pass coming next.

### v8: on-device failures found by actual testing

Real device run (ARM64, `-O2`, `-DCMAKE_BUILD_TYPE=Release`) failed two of
the five training checks that passed cleanly on the x86_64/unoptimized
desktop build: LayerNorm backward and CrossEntropyLoss backward. Linear,
GELU, and FeedForward all passed on-device too - and those three had the
most margin locally, while the two that failed had the least. That
pattern (comfortable-margin checks survive, tight-margin checks don't) is
consistent with cross-platform/optimization floating-point variance
tipping an already-close-to-threshold comparison over the edge, not two
unrelated implementations suddenly being wrong - but it isn't proof.

Response, in order of how much confidence each part deserves:
- Added a **precision-independent structural check** for each: LayerNorm's
  gradInput must sum to exactly zero per row (an algebraic consequence of
  LayerNorm being invariant to constant shifts, not a finite-difference
  estimate); CrossEntropy's gradient must be negative at the target class
  and positive elsewhere (a sign relationship, immune to magnitude noise).
  Both passed in local re-testing. These are the most trustworthy new
  signal - if they ever fail on-device where the numerical check doesn't,
  that's strong evidence of a real bug rather than platform noise.
- Widened numerical tolerances (1e-2 -> 2e-2 for Linear/LayerNorm/
  FeedForward/GELU, 3e-2 -> 5e-2 for CrossEntropy) and now print the
  actual error value alongside PASS/FAIL instead of just a verdict, so
  any future on-device failure comes with real diagnostic data instead of
  a bare "no."
- Genuinely can't rule out a real -O2-triggered bug (e.g. latent UB that
  happens to behave at -O0) without ARM64 compilation access, which this
  sandbox doesn't have. If the widened thresholds + structural checks
  fail again on-device, that's the strongest signal yet of an actual bug
  worth digging into rather than a tolerance problem.

Items 2-6 get you a *working inference engine* that can run a model whose
weights come from somewhere else. Item 7 is what makes training actually
happen on-device — that's real but toy-scale only (small vocab, small
context, small param count); do not expect chat-quality output from
on-device training alone.

## Why matmul is naive right now

Correctness has to be provable before it's optimized. The i-p-j loop order
in `matrix::matmul` is cache-friendlier than the textbook i-j-p order and
skips zero entries in A, but it's still O(n^3) with no SIMD. NEON
intrinsics land in step 8, once every subsystem that depends on matmul
being *correct* already exists and can catch a regression.

## Testing loop

Two independent checks exist on purpose:

1. `tests/test_math.cpp` — compiles standalone with clang/g++ in Termux,
   no Android toolchain needed. Fastest iteration loop for pure logic bugs.
2. The JNI test button in the app — proves the same code actually builds
   and runs correctly through NDK/JNI on your Infinix Hot 11, which is a
   different (and historically more failure-prone, per the mgba JNI work)
   code path than plain Linux compilation.

## One CI gotcha worth fixing

Your `Build APK` workflow's C++ build cache is keyed on:

```
hashFiles('**/CMakeLists.txt', '**/core/*.cpp', '**/core/*.h', '**/jni_bridge.cpp')
```

`**/core/*.cpp` only matches files directly inside a `core/` folder, not
nested ones. This project's C++ lives in `core/math/*.cpp` (and will grow
into `core/tokenizer/`, `core/transformer/`, etc.) — one level deeper than
the glob reaches. That means edits to files under `core/math/` won't change
the cache key, so CI can restore a stale `.cxx` build cache instead of
picking up your change. Worth changing that line to:

```
hashFiles('**/CMakeLists.txt', '**/core/**/*.cpp', '**/core/**/*.h', '**/jni_bridge.cpp')
```

so nested subsystem folders actually invalidate the cache.
