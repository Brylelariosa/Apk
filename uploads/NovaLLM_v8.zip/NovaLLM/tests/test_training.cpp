// Standalone gradient-check tests for core/training (part 1: everything
// except attention). No Android/JNI needed.
//
// IMPORTANT METHODOLOGY NOTE, learned the hard way while building this:
// gradient checks MUST use pseudo-random input data and a pseudo-random
// loss direction (dot product against a fixed random vector), never clean
// arithmetic sequences with a uniform gradOutput. Structured/symmetric
// test inputs repeatedly produced coincidentally-tiny true gradients
// during development, which made ordinary float32 finite-difference noise
// look like a real bug (100%+ relative error) when the implementation was
// actually correct - confirmed by cross-checking against hand-derived
// values and sweeping the finite-difference epsilon. Random data avoids
// this whole class of false alarm.
//
// Termux:
//   clang++ -std=c++17 -I../app/src/main/cpp \
//     test_training.cpp \
//     ../app/src/main/cpp/core/math/Tensor.cpp \
//     ../app/src/main/cpp/core/math/Matrix.cpp \
//     ../app/src/main/cpp/core/transformer/Linear.cpp \
//     ../app/src/main/cpp/core/transformer/LayerNorm.cpp \
//     ../app/src/main/cpp/core/transformer/FeedForward.cpp \
//     ../app/src/main/cpp/core/training/GradientCheck.cpp \
//     ../app/src/main/cpp/core/training/Loss.cpp \
//     -o test_training && ./test_training
#include <cstdio>
#include <cmath>
#include <random>
#include <vector>
#include "core/transformer/Linear.h"
#include "core/transformer/LayerNorm.h"
#include "core/transformer/FeedForward.h"
#include "core/training/GradientCheck.h"
#include "core/training/Loss.h"

using namespace novallm;

static int g_failures = 0;

void expectTrue(bool cond, const char* what) {
    if (!cond) { std::printf("FAIL  %s\n", what); g_failures++; }
    else { std::printf("pass  %s\n", what); }
}

Tensor randomTensor(std::mt19937& rng, std::vector<int> shape, float stddev = 0.3f) {
    Tensor t(shape);
    std::normal_distribution<float> dist(0.0f, stddev);
    for (size_t i = 0; i < t.size(); ++i) t.data()[i] = dist(rng);
    return t;
}

// A pseudo-random scalar "loss" - dot product of the layer's output
// against a fixed random direction vector. This is what makes gradOutput
// meaningfully non-uniform (see the methodology note above).
float dotLoss(const Tensor& output, const Tensor& direction) {
    float s = 0.0f;
    for (size_t i = 0; i < output.size(); ++i) s += output.data()[i] * direction.data()[i];
    return s;
}

void testLinearGradient() {
    std::mt19937 rng(101);
    Linear lin(5, 4, 7);
    Tensor x = randomTensor(rng, {3, 5});
    Tensor y = lin.forward(x);
    Tensor direction = randomTensor(rng, y.shape(), 1.0f);

    Linear::Grads grads = lin.backward(x, direction); // gradOutput = direction since d(dot)/dy = direction

    auto lossFn = [&]() { return dotLoss(lin.forward(x), direction); };
    float errX = gradcheck::maxRelativeError(x, grads.gradInput, lossFn);
    float errW = gradcheck::maxRelativeError(lin.weight(), grads.gradWeight, lossFn);
    float errB = gradcheck::maxRelativeError(lin.bias(), grads.gradBias, lossFn);

    expectTrue(errX < 2e-2f, "Linear backward: gradInput matches numerical gradient");
    expectTrue(errW < 2e-2f, "Linear backward: gradWeight matches numerical gradient");
    expectTrue(errB < 2e-2f, "Linear backward: gradBias matches numerical gradient");
}

void testLayerNormGradient() {
    std::mt19937 rng(202);
    LayerNorm ln(6);
    for (int j = 0; j < 6; ++j) {
        ln.gamma().data()[j] = 0.8f + 0.1f * static_cast<float>(j);
        ln.beta().data()[j] = 0.05f * static_cast<float>(j - 2);
    }
    Tensor x = randomTensor(rng, {3, 6});
    Tensor y = ln.forward(x);
    Tensor direction = randomTensor(rng, y.shape(), 1.0f);

    LayerNorm::Grads grads = ln.backward(x, direction);

    auto lossFn = [&]() { return dotLoss(ln.forward(x), direction); };
    float errX = gradcheck::maxRelativeError(x, grads.gradInput, lossFn);
    float errGamma = gradcheck::maxRelativeError(ln.gamma(), grads.gradGamma, lossFn);
    float errBeta = gradcheck::maxRelativeError(ln.beta(), grads.gradBeta, lossFn);

    expectTrue(errX < 2e-2f, "LayerNorm backward: gradInput matches numerical gradient");
    expectTrue(errGamma < 2e-2f, "LayerNorm backward: gradGamma matches numerical gradient");
    expectTrue(errBeta < 2e-2f, "LayerNorm backward: gradBeta matches numerical gradient");

    // Precision-immune structural check: LayerNorm is exactly invariant to
    // adding a constant to every element of a row, so the gradient w.r.t.
    // that uniform shift must be exactly zero - each row of gradInput
    // must sum to zero. An algebraic property of a correct implementation,
    // not a finite-difference estimate.
    bool sumOk = true;
    for (int i = 0; i < grads.gradInput.dim(0); ++i) {
        float rowSum = 0.0f;
        for (int j = 0; j < grads.gradInput.dim(1); ++j) rowSum += grads.gradInput.at({i, j});
        if (std::fabs(rowSum) > 1e-3f) sumOk = false;
    }
    expectTrue(sumOk, "LayerNorm structural check: each gradInput row sums to zero (precision-independent)");
}

void testGeluGradient() {
    // Pure scalar function - direct central-difference check, no
    // gradcheck infrastructure needed for a 1D case.
    float eps = 1e-3f;
    bool allOk = true;
    for (float x : {-3.0f, -1.0f, -0.1f, 0.0f, 0.1f, 1.0f, 3.0f}) {
        float numerical = (gelu(x + eps) - gelu(x - eps)) / (2.0f * eps);
        float analytical = geluGrad(x);
        float denom = std::max(std::max(std::fabs(numerical), std::fabs(analytical)), 1e-3f);
        if (std::fabs(numerical - analytical) / denom > 2e-2f) allOk = false;
    }
    expectTrue(allOk, "GELU: geluGrad matches numerical derivative across +/- range");
}

void testFeedForwardGradient() {
    std::mt19937 rng(303);
    FeedForward ffn(5, 16, 11);
    Tensor x = randomTensor(rng, {3, 5});
    Tensor y = ffn.forward(x);
    Tensor direction = randomTensor(rng, y.shape(), 1.0f);

    FeedForward::Grads grads = ffn.backward(x, direction);
    auto lossFn = [&]() { return dotLoss(ffn.forward(x), direction); };

    float errX = gradcheck::maxRelativeError(x, grads.gradInput, lossFn);
    expectTrue(errX < 2e-2f, "FeedForward backward: gradInput matches numerical gradient "
                             "(composed Linear->GELU->Linear)");
}

void testCrossEntropyGradient() {
    std::mt19937 rng(2026);
    int seqLen = 3, vocabSize = 8;
    Tensor logits = randomTensor(rng, {seqLen, vocabSize}, 1.5f);
    std::vector<int> targets = {2, 5, 0};

    Tensor gradLogits;
    float loss = CrossEntropyLoss::forwardBackward(logits, targets, gradLogits);
    expectTrue(loss > 0.0f, "CrossEntropyLoss: loss is positive (as any NLL should be)");

    auto lossFn = [&]() {
        Tensor dummyGrad;
        return CrossEntropyLoss::forwardBackward(logits, targets, dummyGrad);
    };
    // Slightly wider tolerance than the other checks: softmax+log is a
    // longer computation chain (exp, sum, divide, log) than a single
    // matmul, so float32 finite-difference noise is proportionally larger
    // even when the analytical formula is exactly right. 21/24 elements
    // land under 1% in practice; the rest are small-magnitude gradients
    // (~1e-3) where a few percent of noise is expected, not a bug -
    // confirmed independently by the sign-check below, which has no
    // numerical-precision sensitivity at all.
    float err = gradcheck::maxRelativeError(logits, gradLogits, lossFn, 1e-3f, 30);
    expectTrue(err < 5e-2f, "CrossEntropyLoss backward: gradLogits matches numerical gradient "
                            "(the softmax(logits)-one_hot(target) identity)");

    // A sanity check independent of finite differences: the gradient at
    // the correct-class logit must be negative (increasing that logit
    // should decrease the loss) and every other class's gradient must be
    // positive - this is a structural property of softmax+CE, not just a
    // numerical coincidence.
    bool signsOk = true;
    for (int i = 0; i < seqLen; ++i) {
        for (int v = 0; v < vocabSize; ++v) {
            float g = gradLogits.at({i, v});
            if (v == targets[static_cast<size_t>(i)]) {
                if (g >= 0.0f) signsOk = false;
            } else {
                if (g <= 0.0f) signsOk = false;
            }
        }
    }
    expectTrue(signsOk, "CrossEntropyLoss: gradient sign is correct at target vs non-target classes");
}

int main() {
    testLinearGradient();
    testLayerNormGradient();
    testGeluGradient();
    testFeedForwardGradient();
    testCrossEntropyGradient();

    std::printf("\n%s (%d failures)\n", g_failures == 0 ? "ALL PASS" : "FAILURES", g_failures);
    return g_failures == 0 ? 0 : 1;
}
