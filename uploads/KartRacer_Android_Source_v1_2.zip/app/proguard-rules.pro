# Nothing is accessed by reflection. Keep line numbers so crash logs stay readable.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
