package com.kartracer.app;

/** Navigation and actions the screens need from the activity. */
public interface Router {
    int MAIN = 0, SETUP = 1, GARAGE = 2, MP_MENU = 3, JOIN = 4, LOBBY = 5, SETTINGS = 6, DIAG = 7;

    void go(int screen);
    void back();
    void toast(String message);
    void saveSettings();
    void startOffline();
    void editLayout();
    void resume();
    void restart();
    void quit();
    void hostStart();
    void leaveLobby();
    void startHostingAndShowLobby();
    void joinHost(String ip, int port);
    void lobbyRaceAgain();
    String exportLog();
    void shareLog();
    void copyLog();
    void applyGraphics();
    void afterProfileChange();
}
