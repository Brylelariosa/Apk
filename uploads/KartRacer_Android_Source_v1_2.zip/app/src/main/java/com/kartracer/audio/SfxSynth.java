package com.kartracer.audio;

/**
 * Procedural sound effects. Every effect is synthesised from oscillators, filtered noise and envelopes into
 * 16 bit mono PCM, so the game needs no audio files. Pure Java (no Android classes).
 */
public final class SfxSynth {
    private SfxSynth() {}

    public static final int RATE = 22050;
    private static final float TAU = (float) (Math.PI * 2.0);

    // ------------------------------------------------------------------ small DSP toolkit

    /** Deterministic white noise in [-1, 1). */
    private static final class Noise {
        private int s;
        Noise(int seed) { s = seed * 747796405 + 12345; }
        float next() { s = s * 1664525 + 1013904223; return (s >> 8) * (1f / 8388608f); }
    }

    /** State variable filter (band-pass output, unity gain at the centre). */
    private static final class Band {
        private float ic1, ic2;
        float run(float x, float fc, float q) {
            float f = Math.max(30f, Math.min(fc, RATE * 0.45f));
            float g = (float) Math.tan(Math.PI * f / RATE);
            float k = 1f / q;
            float a1 = 1f / (1f + g * (g + k)), a2 = g * a1, a3 = g * a2;
            float v3 = x - ic2;
            float v1 = a1 * ic1 + a2 * v3;
            float v2 = ic2 + a2 * ic1 + a3 * v3;
            ic1 = 2f * v1 - ic1;
            ic2 = 2f * v2 - ic2;
            return v1 * k;
        }
    }

    private static float[] buf(float seconds) { return new float[Math.max(1, Math.round(seconds * RATE))]; }
    private static float t(int i) { return i / (float) RATE; }
    private static float clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
    private static float lerp(float a, float b, float k) { return a + (b - a) * k; }

    /** Exponential sweep from f0 to f1 over `dur` seconds: returns the frequency at time tt. */
    private static float sweep(float f0, float f1, float tt, float dur) {
        float k = clamp(tt / dur, 0f, 1f);
        return (float) (f0 * Math.pow(f1 / f0, k));
    }

    private static float tri(float ph) {
        float x = ph / TAU; x -= (float) Math.floor(x);
        return 4f * Math.abs(x - 0.5f) - 1f;
    }

    private static float saw(float ph) {
        float x = ph / TAU; x -= (float) Math.floor(x);
        return 2f * x - 1f;
    }

    /** Soft square: sine plus odd harmonics. */
    private static float sq(float ph) { return (float) (Math.sin(ph) + Math.sin(3 * ph) / 3.0 + Math.sin(5 * ph) / 5.0) * 0.9f; }

    /** Bell-like note that starts at time t0 inside buffer b. */
    private static void note(float[] b, float t0, float freq, float amp, float decay, float bright) {
        int s0 = Math.max(0, Math.round(t0 * RATE));
        for (int i = s0; i < b.length; i++) {
            float tt = (i - s0) / (float) RATE;
            float e = (float) Math.exp(-tt * decay) * Math.min(1f, tt / 0.003f);
            if (tt > 0.01f && e < 0.0008f) break;
            float ph = TAU * freq * tt;
            b[i] += amp * e * ((float) Math.sin(ph) + bright * (float) Math.sin(ph * 2.01f) * 0.5f + bright * 0.25f * (float) Math.sin(ph * 3.02f));
        }
    }

    private static void lowpass(float[] b, float hz) {
        float a = 1f - (float) Math.exp(-TAU * hz / RATE), y = 0f;
        for (int i = 0; i < b.length; i++) { y += a * (b[i] - y); b[i] = y; }
    }

    private static void highpass(float[] b, float hz) {
        float a = 1f - (float) Math.exp(-TAU * hz / RATE), y = 0f;
        for (int i = 0; i < b.length; i++) { y += a * (b[i] - y); b[i] -= y; }
    }

    private static void normalize(float[] b, float peak) {
        float m = 1e-6f;
        for (float v : b) m = Math.max(m, Math.abs(v));
        float k = peak / m;
        for (int i = 0; i < b.length; i++) b[i] *= k;
    }

    private static void fades(float[] b, float inSec, float outSec) {
        int a = Math.min(b.length / 2, Math.round(inSec * RATE)), o = Math.min(b.length / 2, Math.round(outSec * RATE));
        for (int i = 0; i < a; i++) b[i] *= i / (float) a;
        for (int i = 0; i < o; i++) b[b.length - 1 - i] *= i / (float) o;
    }

    /** Makes a buffer loop seamlessly by blending its tail into its head. g must be n + x samples long. */
    private static float[] loopable(float[] g, int x) {
        int n = g.length - x;
        float[] out = new float[n];
        System.arraycopy(g, 0, out, 0, n);
        for (int i = 0; i < x; i++) {
            float w = i / (float) x;
            float a = (float) Math.sin(w * Math.PI / 2.0), c = (float) Math.cos(w * Math.PI / 2.0);
            out[i] = g[i] * a + g[n + i] * c;
        }
        return out;
    }

    private static short[] pcm(float[] b) {
        short[] o = new short[b.length];
        for (int i = 0; i < b.length; i++) {
            float v = b[i];
            v = v < -1f ? -1f : (v > 1f ? 1f : v);
            o[i] = (short) Math.round(v * 32000f);
        }
        return o;
    }

    // ------------------------------------------------------------------ the sounds

    public static short[] make(int id) {
        float[] b;
        float peak = 0.8f;
        boolean loop = false;
        switch (id) {
            case Snd.CLICK: b = click(1500f, 1100f); peak = 0.55f; break;
            case Snd.BACK: b = click(900f, 600f); peak = 0.5f; break;
            case Snd.BEEP: b = beep(); peak = 0.5f; break;
            case Snd.GO: b = go(); peak = 0.8f; break;
            case Snd.ITEM_PICK: b = itemPick(); peak = 0.8f; break;
            case Snd.TURBO: b = whoosh(0.6f, 450f, 3600f, 140f, 560f); peak = 0.85f; break;
            case Snd.ROCKET: b = rocket(); peak = 0.9f; break;
            case Snd.COCONUT: b = coconut(); peak = 0.8f; break;
            case Snd.OIL: b = oil(); peak = 0.8f; break;
            case Snd.SHIELD_ON: b = shieldOn(); peak = 0.75f; break;
            case Snd.SHIELD_POP: b = shieldPop(); peak = 0.8f; break;
            case Snd.PAD: b = pad(); peak = 0.85f; break;
            case Snd.BOOST: b = whoosh(0.5f, 380f, 2600f, 110f, 380f); peak = 0.8f; break;
            case Snd.SPIN: b = spin(); peak = 0.85f; break;
            case Snd.EXPLODE: b = explode(); peak = 0.95f; break;
            case Snd.BUMP: b = bump(); peak = 0.85f; break;
            case Snd.SMASH: b = smash(); peak = 0.85f; break;
            case Snd.LAND: b = land(); peak = 0.8f; break;
            case Snd.SPLASH: b = splash(); peak = 0.7f; break;
            case Snd.JUMP: b = jump(); peak = 0.75f; break;
            case Snd.SPARK: b = spark(); peak = 0.7f; break;
            case Snd.LAP: b = lap(false); peak = 0.8f; break;
            case Snd.FINAL_LAP: b = lap(true); peak = 0.85f; break;
            case Snd.FINISH: b = finish(); peak = 0.9f; break;
            case Snd.RESPAWN: b = respawn(); peak = 0.75f; break;
            case Snd.WRONG_WAY: b = wrongWay(); peak = 0.42f; break;
            case Snd.ENGINE: b = engine(); peak = 0.7f; loop = true; break;
            case Snd.SKID: b = skid(); peak = 0.7f; loop = true; break;
            default: b = new float[RATE / 100]; break;
        }
        if (loop) {
            float mean = 0f;
            for (float v : b) mean += v;
            mean /= b.length;
            for (int i = 0; i < b.length; i++) b[i] -= mean;
        }
        normalize(b, peak);
        if (!loop) fades(b, 0.002f, 0.01f);
        return pcm(b);
    }

    private static float[] click(float f0, float f1) {
        float[] b = buf(0.07f);
        Noise n = new Noise(1);
        float ph = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            ph += TAU * lerp(f0, f1, tt / 0.07f) / RATE;
            b[i] = (float) Math.sin(ph) * (float) Math.exp(-tt * 70f) + 0.25f * n.next() * (float) Math.exp(-tt * 400f);
        }
        return b;
    }

    private static float[] beep() {
        float[] b = buf(0.24f);
        float ph = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            ph += TAU * 660f / RATE;
            float env = Math.min(1f, tt / 0.004f) * (tt > 0.19f ? Math.max(0f, (0.24f - tt) / 0.05f) : 1f);
            b[i] = sq(ph) * env;
        }
        return b;
    }

    private static float[] go() {
        float[] b = buf(0.7f);
        float p1 = 0f, p2 = 0f, p3 = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            float chirp = 1f + 0.04f * (float) Math.exp(-tt * 40f);
            p1 += TAU * 880f * chirp / RATE; p2 += TAU * 1320f * chirp / RATE; p3 += TAU * 1760f * chirp / RATE;
            float env = Math.min(1f, tt / 0.004f) * (float) Math.exp(-tt * 4.5f);
            b[i] = (sq(p1) + 0.7f * (float) Math.sin(p2) + 0.5f * (float) Math.sin(p3)) * env;
        }
        return b;
    }

    private static float[] itemPick() {
        float[] b = buf(0.55f);
        float[] f = {880f, 1108.7f, 1318.5f, 1760f};
        for (int k = 0; k < f.length; k++) note(b, k * 0.055f, f[k], 0.7f, 11f, 0.8f);
        Noise n = new Noise(7);
        for (int i = 0; i < b.length; i++) { float tt = t(i); if (tt > 0.15f) b[i] += 0.05f * n.next() * (float) Math.exp(-(tt - 0.15f) * 14f); }
        return b;
    }

    /** Filtered noise sweep plus a rising saw tone. */
    private static float[] whoosh(float dur, float f0, float f1, float tone0, float tone1) {
        float[] b = buf(dur);
        Noise n = new Noise(11);
        Band bp = new Band();
        float ph = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i), k = tt / dur;
            float env = Math.min(1f, tt / 0.04f) * (float) Math.pow(1f - k, 1.6f);
            float fc = sweep(f0, f1, tt, dur);
            ph += TAU * sweep(tone0, tone1, tt, dur) / RATE;
            b[i] = (bp.run(n.next(), fc, 1.4f) * 1.5f + 0.22f * saw(ph)) * env;
        }
        return b;
    }

    private static float[] rocket() {
        float[] b = buf(0.8f);
        Noise n = new Noise(21);
        Band bp = new Band();
        float ph = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            float env = Math.min(1f, tt / 0.01f) * (float) Math.exp(-tt * 3.6f);
            float fc = sweep(2200f, 520f, tt, 0.8f);
            ph += TAU * sweep(130f, 48f, tt, 0.25f) / RATE;
            b[i] = bp.run(n.next(), fc, 0.9f) * 1.6f * env + 0.8f * (float) Math.sin(ph) * (float) Math.exp(-tt * 16f);
        }
        return b;
    }

    private static float[] coconut() {
        float[] b = buf(0.22f);
        Noise n = new Noise(31);
        float ph = 0f, ph2 = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            ph += TAU * sweep(640f, 190f, tt, 0.12f) / RATE;
            ph2 += TAU * 140f / RATE;
            b[i] = (float) Math.sin(ph) * (float) Math.exp(-tt * 20f) + 0.5f * (float) Math.sin(ph2) * (float) Math.exp(-tt * 28f) + 0.4f * n.next() * (float) Math.exp(-tt * 260f);
        }
        return b;
    }

    private static float[] oil() {
        float[] b = buf(0.4f);
        Noise n = new Noise(41);
        float ph = 0f;
        float[] burst = buf(0.4f);
        for (int i = 0; i < burst.length; i++) burst[i] = n.next() * (float) Math.exp(-t(i) * 30f);
        lowpass(burst, 900f);
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            ph += TAU * (sweep(420f, 85f, tt, 0.3f) * (1f + 0.04f * (float) Math.sin(tt * 60f))) / RATE;
            b[i] = (float) Math.sin(ph) * (float) Math.exp(-tt * 9f) + 1.3f * burst[i];
        }
        return b;
    }

    private static float[] shieldOn() {
        float[] b = buf(0.7f);
        float[] f = {523.25f, 659.25f, 783.99f, 1046.5f};
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            float env = Math.min(1f, tt / 0.16f) * (float) Math.exp(-Math.max(0f, tt - 0.18f) * 5.5f);
            float trem = 1f + 0.2f * (float) Math.sin(TAU * 12f * tt);
            float v = 0f;
            for (int k = 0; k < f.length; k++) v += (float) Math.sin(TAU * f[k] * tt * (1f + 0.012f * tt)) * (0.7f - 0.1f * k);
            b[i] = v * env * trem * 0.35f;
        }
        for (int k = 0; k < 6; k++) note(b, 0.06f * k + 0.05f, 2093f + 180f * k, 0.12f, 20f, 0.4f);
        return b;
    }

    private static float[] shieldPop() {
        float[] b = buf(0.35f);
        Noise n = new Noise(51);
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            float v = (float) Math.sin(TAU * 1568f * tt) * 0.7f + (float) Math.sin(TAU * 2349f * tt) * 0.5f;
            b[i] = v * (float) Math.exp(-tt * 14f) + 0.7f * n.next() * (float) Math.exp(-tt * 170f);
        }
        float[] low = buf(0.35f);
        float ph = 0f;
        for (int i = 0; i < low.length; i++) { float tt = t(i); ph += TAU * sweep(800f, 200f, tt, 0.1f) / RATE; low[i] = (float) Math.sin(ph) * (float) Math.exp(-tt * 28f) * 0.6f; }
        for (int i = 0; i < b.length; i++) b[i] += low[i];
        return b;
    }

    private static float[] pad() {
        float[] b = buf(0.55f);
        Noise n = new Noise(61);
        Band bp = new Band();
        float ph = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i), k = tt / 0.55f;
            float env = Math.min(1f, tt / 0.02f) * (float) Math.pow(1f - k, 1.3f);
            ph += TAU * sweep(260f, 1900f, tt, 0.4f) / RATE;
            float tone = (float) Math.sin(ph) + 0.5f * saw(ph) + 0.4f * (float) Math.sin(ph * 2f);
            b[i] = (tone * 0.55f + bp.run(n.next(), sweep(500f, 4200f, tt, 0.45f), 1.1f) * 1.2f) * env;
        }
        return b;
    }

    private static float[] spin() {
        float[] b = buf(0.85f);
        Noise n = new Noise(71);
        float ph = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            float f = 540f * (float) Math.exp(-tt * 1.5f) + 70f * (float) Math.sin(TAU * 13f * tt) * (float) Math.exp(-tt * 1.8f);
            ph += TAU * Math.max(80f, f) / RATE;
            float env = Math.min(1f, tt / 0.01f) * (float) Math.exp(-tt * 2.6f);
            b[i] = (tri(ph) * 0.8f + 0.25f * (float) Math.sin(ph * 2f)) * env + 0.5f * n.next() * (float) Math.exp(-tt * 28f);
        }
        return b;
    }

    private static float[] explode() {
        float[] b = buf(1.0f);
        Noise n = new Noise(81);
        float y = 0f, ph = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            float fc = 150f + 3800f * (float) Math.exp(-tt * 7f);
            float a = 1f - (float) Math.exp(-TAU * fc / RATE);
            y += a * (n.next() - y);
            float env = Math.min(1f, tt / 0.004f) * (float) Math.exp(-tt * 4.2f);
            ph += TAU * sweep(95f, 28f, tt, 0.5f) / RATE;
            b[i] = y * 3.2f * env + 0.9f * (float) Math.sin(ph) * (float) Math.exp(-tt * 5f);
        }
        Noise c = new Noise(83);
        for (int k = 0; k < 18; k++) {
            int p = Math.round((0.05f + c.next() * 0.5f + 0.5f) * 0.55f * RATE);
            for (int j = 0; j < 90 && p + j < b.length; j++) b[p + j] += 0.5f * c.next() * (1f - j / 90f) * (1f - p / (float) b.length);
        }
        return b;
    }

    private static float[] bump() {
        float[] b = buf(0.18f);
        Noise n = new Noise(91);
        float ph = 0f;
        float[] ns = buf(0.18f);
        for (int i = 0; i < ns.length; i++) ns[i] = n.next();
        lowpass(ns, 500f);
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            ph += TAU * sweep(190f, 58f, tt, 0.1f) / RATE;
            b[i] = (float) Math.sin(ph) * (float) Math.exp(-tt * 26f) + 2.2f * ns[i] * (float) Math.exp(-tt * 40f);
        }
        return b;
    }

    private static float[] smash() {
        float[] b = buf(0.4f);
        Noise n = new Noise(101);
        Band bp = new Band();
        float ph = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            ph += TAU * sweep(280f, 120f, tt, 0.12f) / RATE;
            b[i] = bp.run(n.next(), 2300f, 0.8f) * 1.6f * (float) Math.exp(-tt * 32f) + 0.9f * (float) Math.sin(ph) * (float) Math.exp(-tt * 24f);
        }
        Noise c = new Noise(103);
        for (int k = 0; k < 6; k++) {
            int p = Math.round((0.02f + c.next() * 0.5f + 0.5f) * 0.28f * RATE);
            float fc = 1200f + (c.next() + 1f) * 1400f;
            Band q = new Band();
            for (int j = 0; j < 700 && p + j < b.length; j++) b[p + j] += q.run(c.next(), fc, 2f) * 1.2f * (float) Math.exp(-j / 160f);
        }
        return b;
    }

    private static float[] land() {
        float[] b = buf(0.25f);
        Noise n = new Noise(111);
        float ph = 0f;
        float[] ns = buf(0.25f);
        for (int i = 0; i < ns.length; i++) ns[i] = n.next();
        lowpass(ns, 650f);
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            ph += TAU * sweep(120f, 44f, tt, 0.15f) / RATE;
            b[i] = (float) Math.sin(ph) * (float) Math.exp(-tt * 18f) + 2f * ns[i] * (float) Math.exp(-tt * 30f);
        }
        return b;
    }

    private static float[] splash() {
        float[] b = buf(0.4f);
        Noise n = new Noise(121);
        Band bp = new Band();
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            float env = Math.min(1f, tt / 0.02f) * (float) Math.exp(-tt * 8f);
            b[i] = bp.run(n.next(), 1500f - 600f * tt, 0.7f) * 1.5f * env;
        }
        Noise c = new Noise(123);
        for (int k = 0; k < 7; k++) {
            float t0 = 0.03f + (c.next() + 1f) * 0.12f, f = 500f + (c.next() + 1f) * 500f;
            int s0 = Math.round(t0 * RATE);
            for (int i = s0; i < b.length; i++) { float tt = (i - s0) / (float) RATE; if (tt > 0.08f) break; b[i] += 0.35f * (float) Math.sin(TAU * f * (1f + 3f * tt) * tt) * (float) Math.exp(-tt * 55f); }
        }
        return b;
    }

    private static float[] jump() {
        float[] b = buf(0.4f);
        Noise n = new Noise(131);
        float ph = 0f;
        float[] ns = buf(0.4f);
        for (int i = 0; i < ns.length; i++) ns[i] = n.next();
        lowpass(ns, 1500f);
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            ph += TAU * (sweep(200f, 640f, tt, 0.25f) * (1f + 0.06f * (float) Math.sin(TAU * 18f * tt))) / RATE;
            float env = Math.min(1f, tt / 0.01f) * (float) Math.exp(-tt * 6.5f);
            b[i] = (tri(ph) * 0.8f + 0.3f * (float) Math.sin(ph)) * env + 0.5f * ns[i] * (float) Math.exp(-tt * 12f);
        }
        return b;
    }

    private static float[] spark() {
        float[] b = buf(0.2f);
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            float e = Math.min(1f, tt / 0.001f) * (float) Math.exp(-tt * 22f);
            b[i] = ((float) Math.sin(TAU * 1760f * tt) + 0.6f * (float) Math.sin(TAU * 2637f * tt)) * e;
        }
        return b;
    }

    private static float[] lap(boolean fin) {
        float[] b = buf(fin ? 0.95f : 0.6f);
        if (!fin) { note(b, 0f, 1046.5f, 0.8f, 7f, 0.8f); note(b, 0.14f, 1318.5f, 0.8f, 6f, 0.8f); }
        else { note(b, 0f, 784f, 0.7f, 6f, 0.8f); note(b, 0.12f, 1046.5f, 0.7f, 6f, 0.8f); note(b, 0.24f, 1318.5f, 0.75f, 5.5f, 0.8f); note(b, 0.36f, 1568f, 0.85f, 4.5f, 0.9f); }
        return b;
    }

    private static float[] finish() {
        float[] b = buf(1.5f);
        float[] f = {523.25f, 659.25f, 783.99f};
        for (int k = 0; k < 3; k++) {
            int s0 = Math.round(k * 0.17f * RATE), s1 = Math.round((k * 0.17f + 0.17f) * RATE);
            for (int i = s0; i < s1 && i < b.length; i++) {
                float tt = (i - s0) / (float) RATE;
                float ph = TAU * f[k] * tt;
                float env = Math.min(1f, tt / 0.005f) * (tt > 0.13f ? Math.max(0f, (0.17f - tt) / 0.04f) : 1f);
                b[i] += (sq(ph) * 0.8f + saw(ph) * 0.25f) * env;
            }
        }
        int s0 = Math.round(0.51f * RATE);
        float[] chord = {1046.5f, 1318.5f, 1568f};
        for (int i = s0; i < b.length; i++) {
            float tt = (i - s0) / (float) RATE;
            float env = Math.min(1f, tt / 0.006f) * (float) Math.exp(-tt * 2.6f);
            float v = 0f;
            for (int k = 0; k < 3; k++) v += sq(TAU * chord[k] * tt) * 0.45f + saw(TAU * chord[k] * tt) * 0.1f;
            b[i] += v * env;
        }
        Noise n = new Noise(141);
        float[] cym = buf(1.5f);
        for (int i = s0; i < cym.length; i++) cym[i] = n.next() * (float) Math.exp(-(i - s0) / (float) RATE * 4.5f);
        highpass(cym, 5000f);
        for (int i = 0; i < b.length; i++) b[i] += 0.35f * cym[i];
        return b;
    }

    private static float[] respawn() {
        float[] b = buf(0.6f);
        float ph = 0f;
        for (int i = 0; i < b.length; i++) {
            float tt = t(i);
            ph += TAU * sweep(180f, 1300f, tt, 0.35f) / RATE;
            float env = Math.min(1f, tt / 0.02f) * (float) Math.exp(-tt * 4.5f);
            b[i] = ((float) Math.sin(ph) + 0.35f * (float) Math.sin(ph * 2f)) * env * 0.7f;
        }
        for (int k = 0; k < 5; k++) note(b, 0.25f + k * 0.04f, 1500f + k * 280f, 0.18f, 18f, 0.3f);
        return b;
    }

    private static float[] wrongWay() {
        float[] b = buf(0.62f);
        float[] f = {540f, 420f};
        for (int k = 0; k < 2; k++) {
            int s0 = Math.round(k * 0.3f * RATE);
            for (int i = s0; i < s0 + Math.round(0.24f * RATE) && i < b.length; i++) {
                float tt = (i - s0) / (float) RATE;
                float env = Math.min(1f, tt / 0.005f) * (tt > 0.2f ? Math.max(0f, (0.24f - tt) / 0.04f) : 1f);
                b[i] += sq(TAU * f[k] * tt) * env;
            }
        }
        return b;
    }

    /** Kart engine loop: 44 cycles of a 110 Hz harmonic stack inside 0.4 s, so it loops without a click. */
    private static float[] engine() {
        int n = Math.round(0.4f * RATE);
        float[] b = new float[n];
        Noise r = new Noise(151);
        float[] phase = new float[16];
        for (int h = 0; h < phase.length; h++) phase[h] = (r.next() + 1f) * (float) Math.PI;
        int base = 44; // cycles per loop of the fundamental
        for (int i = 0; i < n; i++) {
            float x = i / (float) n;
            float v = 0f;
            for (int h = 1; h <= 14; h++) {
                float hz = h * 110f;
                float formant = 1f + 1.6f * (float) Math.exp(-Math.pow((hz - 700f) / 350f, 2.0)) + 0.8f * (float) Math.exp(-Math.pow((hz - 1500f) / 500f, 2.0));
                v += (float) Math.sin(TAU * base * h * x + phase[h]) * formant / (float) Math.pow(h, 0.85);
            }
            // sub harmonic gives the "putt-putt" pulse of a small two stroke engine
            float sub = (float) Math.sin(TAU * (base / 2) * x + phase[0]);
            float pulse = 0.72f + 0.28f * (float) Math.sin(TAU * (base / 2) * x + 1.1f);
            b[i] = (v * 0.35f + sub * 0.7f) * pulse;
        }
        // gentle rasp from periodic noise (random phase partials at integer cycles per loop)
        Noise q = new Noise(157);
        int partials = 90;
        float[] pf = new float[partials], pp = new float[partials];
        for (int k = 0; k < partials; k++) { pf[k] = 160f + k * 28f; pf[k] = Math.round(pf[k] * 0.4f) / 0.4f; pp[k] = (q.next() + 1f) * (float) Math.PI; }
        for (int i = 0; i < n; i++) {
            float tt = i / (float) RATE, v = 0f;
            for (int k = 0; k < partials; k++) v += (float) Math.sin(TAU * pf[k] * tt + pp[k]);
            b[i] += v * 0.012f;
        }
        return b;
    }

    /** Tyre squeal loop: band limited noise with a little flutter, blended so it loops seamlessly. */
    private static float[] skid() {
        int n = Math.round(0.6f * RATE), x = Math.round(0.06f * RATE);
        float[] g = new float[n + x];
        Noise r = new Noise(161);
        Band a = new Band(), c = new Band();
        for (int i = 0; i < g.length; i++) {
            float tt = i / (float) RATE;
            float s = r.next();
            float fl = 1f + 0.18f * (float) Math.sin(TAU * 8f * tt);
            g[i] = (a.run(s, 2300f * fl, 2.2f) * 1.1f + c.run(s, 1350f, 1.4f) * 0.7f) * (0.85f + 0.15f * (float) Math.sin(TAU * 5f * tt));
        }
        return loopable(g, x);
    }
}
