package com.kartracer.util;

/** Small math helpers (float based, allocation free). */
public final class MathX {
    private MathX() {}

    public static final float PI = (float) Math.PI;
    public static final float TAU = PI * 2f;
    public static final float DEG = PI / 180f;

    public static float clamp(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
    public static int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    public static float sat(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    public static float sign(float v) { return v < 0f ? -1f : 1f; }
    public static float abs(float v) { return v < 0f ? -v : v; }
    public static float sqr(float v) { return v * v; }

    /** Smoothstep; edges may be reversed (e0 > e1) to produce a falling ramp. */
    public static float smooth(float e0, float e1, float x) {
        float t = sat((x - e0) / (e1 - e0));
        return t * t * (3f - 2f * t);
    }

    public static float wrapAngle(float a) {
        if (a != a) return 0f;
        return (float) (a - TAU * Math.floor((a + PI) / TAU));
    }

    /** Shortest signed angle from -> to. */
    public static float angleDiff(float to, float from) { return wrapAngle(to - from); }

    public static float approach(float v, float target, float maxStep) {
        if (v < target) return Math.min(v + maxStep, target);
        return Math.max(v - maxStep, target);
    }

    /** Frame-rate independent exponential smoothing. */
    public static float damp(float cur, float target, float rate, float dt) {
        return cur + (target - cur) * (1f - (float) Math.exp(-rate * dt));
    }

    public static int ifloor(float v) { int i = (int) v; return v < i ? i - 1 : i; }
    public static float len2(float x, float z) { return (float) Math.sqrt(x * x + z * z); }
    public static float len3(float x, float y, float z) { return (float) Math.sqrt(x * x + y * y + z * z); }
}
