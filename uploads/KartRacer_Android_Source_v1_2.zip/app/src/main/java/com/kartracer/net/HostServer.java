package com.kartracer.net;

import com.kartracer.sim.Participant;
import com.kartracer.sim.RaceNet;
import com.kartracer.sim.RaceSettings;
import com.kartracer.util.MathX;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Hosts a LAN lobby and race: accepts players over TCP, exchanges kart state over UDP, relays race events. */
public final class HostServer implements Conn.Listener, RaceNet {
    public interface Events {
        void onLobby(Msg.Lobby lobby);
        /** The race clock starts: GO happens at goMs on the host clock. */
        void onGo(int goMs);
        void onNotice(String text);
    }

    private static final String[] AI_NAMES = {"Bolt", "Mango", "Zippy", "Coral", "Rusty", "Pixel", "Tiki"};

    private static final class Player {
        int id, raceSlot = -1, kart, color, driver, ping;
        Conn conn;
        String name = "Player";
        boolean ready, connected = true, host, loaded, tcpState;
        long tokHi, tokLo;
        volatile InetSocketAddress udp;
    }

    private final Events ev;
    private final PlatformHooks hooks;
    private final Clock clock = new Clock();
    private final Object lock = new Object();
    private final Player[] players = new Player[NetConst.MAX_PLAYERS];
    private final List<Conn> conns = new ArrayList<Conn>();
    private final ConcurrentLinkedQueue<Msg> inbox = new ConcurrentLinkedQueue<Msg>();
    private final Random random = new Random();
    private RaceSettings settings = new RaceSettings();
    private ServerSocket server;
    private DatagramSocket udp;
    private Discovery.Announcer announcer;
    private volatile boolean running;
    private volatile int raceState; // 0 lobby, 1 loading, 2 racing
    private int goMs;
    private long loadStartMs;
    private Msg.Start lastStart;
    private String hostName = "Host";
    public volatile int tcpPort, udpPort;
    private int snapSeq;

    public HostServer(PlatformHooks hooks, Events ev) {
        this.hooks = hooks == null ? PlatformHooks.NONE : hooks;
        this.ev = ev;
    }

    public Clock clock() { return clock; }

    // ------------------------------------------------------------------ lifecycle

    public void start(String name, int kart, int color, int driver) throws IOException {
        hostName = name;
        Player h = new Player();
        h.id = 0; h.host = true; h.ready = true; h.name = name; h.kart = kart; h.color = color; h.driver = driver;
        players[0] = h;
        server = bindServer();
        udp = bindUdp();
        tcpPort = server.getLocalPort();
        udpPort = udp.getLocalPort();
        running = true;
        spawn("kr-accept", new Runnable() { public void run() { acceptLoop(); } });
        spawn("kr-udp", new Runnable() { public void run() { udpLoop(); } });
        spawn("kr-maint", new Runnable() { public void run() { maintLoop(); } });
        announcer = new Discovery.Announcer(hooks, new Discovery.InfoSource() {
            public Discovery.HostInfo get() { return info(); }
        });
        announcer.start();
        broadcastLobby();
    }

    private ServerSocket bindServer() throws IOException {
        IOException last = null;
        for (int i = 0; i < 10; i++) {
            try {
                ServerSocket s = new ServerSocket();
                s.setReuseAddress(true);
                s.bind(new InetSocketAddress(NetConst.TCP_PORT + i * 10));
                return s;
            } catch (IOException e) { last = e; }
        }
        throw last != null ? last : new IOException("no free port");
    }

    private DatagramSocket bindUdp() throws IOException {
        IOException last = null;
        for (int i = 0; i < 10; i++) {
            try {
                DatagramSocket s = new DatagramSocket(null);
                s.setReuseAddress(true);
                s.bind(new InetSocketAddress(NetConst.UDP_PORT + i * 10));
                s.setSoTimeout(500);
                try { s.setTrafficClass(0x88); } catch (Exception ignored) { }
                return s;
            } catch (IOException e) { last = e; }
        }
        throw last != null ? last : new IOException("no free udp port");
    }

    private void spawn(String name, Runnable r) {
        Thread t = new Thread(r, name);
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        if (!running) return;
        running = false;
        List<Conn> copy;
        synchronized (lock) { copy = new ArrayList<Conn>(conns); }
        for (Conn c : copy) { c.send(new Msg.Kick("The host closed the lobby")); c.closeAfterFlush(); }
        if (announcer != null) announcer.stop();
        try { server.close(); } catch (Exception ignored) { }
        try { udp.close(); } catch (Exception ignored) { }
    }

    private Discovery.HostInfo info() {
        Discovery.HostInfo h = new Discovery.HostInfo();
        synchronized (lock) {
            h.name = hostName; h.tcpPort = tcpPort; h.players = connectedCount(); h.max = settings.maxKarts;
            h.track = settings.track; h.laps = settings.laps; h.inRace = raceState != 0;
        }
        return h;
    }

    // ------------------------------------------------------------------ lobby API (UI thread)

    public void setSettings(RaceSettings s) {
        synchronized (lock) {
            RaceSettings c = s.copy();
            c.laps = MathX.clamp(c.laps, 1, 9);
            c.maxKarts = NetConst.MAX_PLAYERS;
            c.aiCount = MathX.clamp(c.aiCount, 0, c.maxKarts - 1);
            c.difficulty = MathX.clamp(c.difficulty, 0, 2);
            settings = c;
        }
        broadcastLobby();
    }

    public RaceSettings settings() { synchronized (lock) { return settings.copy(); } }

    public void updateHostProfile(String name, int kart, int color, int driver) {
        synchronized (lock) {
            Player h = players[0];
            h.name = name; h.kart = kart; h.color = color; h.driver = driver;
            hostName = name;
        }
        broadcastLobby();
    }

    public void kick(int playerId) {
        Conn c = null;
        synchronized (lock) {
            if (playerId > 0 && playerId < players.length && players[playerId] != null) c = players[playerId].conn;
        }
        if (c != null) { c.send(new Msg.Kick("Removed by the host")); c.closeAfterFlush(); }
    }

    public Msg.Lobby lobby() {
        synchronized (lock) { return buildLobby(); }
    }

    private Msg.Lobby buildLobby() {
        Msg.Lobby l = new Msg.Lobby();
        l.settings = settings.copy();
        List<Msg.PlayerInfo> list = new ArrayList<Msg.PlayerInfo>();
        for (Player p : players) {
            if (p == null || (!p.connected && raceState == 0)) continue;
            Msg.PlayerInfo i = new Msg.PlayerInfo();
            i.slot = p.id; i.name = p.name; i.kart = p.kart; i.color = p.color; i.driver = p.driver;
            i.ready = p.ready; i.connected = p.connected; i.host = p.host; i.ping = p.ping;
            list.add(i);
        }
        l.players = list.toArray(new Msg.PlayerInfo[0]);
        return l;
    }

    private void broadcastLobby() {
        Msg.Lobby l;
        List<Conn> targets = new ArrayList<Conn>();
        synchronized (lock) {
            l = buildLobby();
            for (Player p : players) if (p != null && !p.host && p.connected && p.conn != null) targets.add(p.conn);
        }
        for (Conn c : targets) c.send(l);
        ev.onLobby(l);
    }

    private int connectedCount() {
        int c = 0;
        for (Player p : players) if (p != null && p.connected) c++;
        return c;
    }

    // ------------------------------------------------------------------ race start / end

    /** Builds the grid, tells everyone to load. Returns the Start message (also for the host's own loading). */
    public Msg.Start startRace() {
        Msg.Start s;
        List<Conn> targets = new ArrayList<Conn>();
        synchronized (lock) {
            if (raceState != 0) return null;
            List<Player> humans = new ArrayList<Player>();
            for (Player p : players) if (p != null && p.connected) humans.add(p);
            int ai = Math.min(settings.aiCount, settings.maxKarts - humans.size());
            List<Participant> parts = new ArrayList<Participant>();
            for (int i = 0; i < humans.size(); i++) {
                Player p = humans.get(i);
                p.raceSlot = i; p.loaded = false;
                Participant pt = new Participant(i, false, p.name, p.kart, p.color, p.driver, 0);
                pt.playerId = p.id;
                parts.add(pt);
            }
            for (int a = 0; a < ai; a++) {
                int slot = humans.size() + a;
                parts.add(new Participant(slot, true, AI_NAMES[a % AI_NAMES.length], (a * 2 + 1) % 6, (a + 1) % 6, (a * 5 + 2) % 6, a % 3));
            }
            s = new Msg.Start();
            s.settings = settings.copy();
            s.settings.aiCount = ai;
            s.seed = random.nextLong();
            s.parts = parts.toArray(new Participant[0]);
            lastStart = s;
            raceState = 1;
            loadStartMs = System.currentTimeMillis();
            inbox.clear();
            for (Player p : players) if (p != null && !p.host && p.connected && p.conn != null) targets.add(p.conn);
        }
        for (Conn c : targets) c.send(s);
        return s;
    }

    /** The host's own scene finished loading. */
    public void hostLoaded() {
        synchronized (lock) { if (players[0] != null) players[0].loaded = true; }
        checkAllLoaded();
    }

    private void checkAllLoaded() {
        int go = 0;
        List<Conn> targets = new ArrayList<Conn>();
        synchronized (lock) {
            if (raceState != 1) return;
            for (Player p : players) if (p != null && p.connected && !p.loaded) return;
            go = clock.hostMs() + 3500;
            goMs = go;
            raceState = 2;
            for (Player p : players) if (p != null && !p.host && p.connected && p.conn != null) targets.add(p.conn);
        }
        Msg.Go g = new Msg.Go(go);
        for (Conn c : targets) c.send(g);
        ev.onGo(go);
    }

    public void backToLobby() {
        List<Conn> targets = new ArrayList<Conn>();
        synchronized (lock) {
            raceState = 0;
            inbox.clear();
            for (int i = 0; i < players.length; i++) {
                Player p = players[i];
                if (p == null) continue;
                if (!p.connected) { players[i] = null; continue; }
                p.ready = p.host; p.loaded = false; p.raceSlot = -1;
                if (!p.host && p.conn != null) targets.add(p.conn);
            }
        }
        Msg.Simple back = new Msg.Simple(Msg.BACK);
        for (Conn c : targets) c.send(back);
        broadcastLobby();
    }

    // ------------------------------------------------------------------ connection handling

    private void acceptLoop() {
        while (running) {
            try {
                Socket s = server.accept();
                Conn c = new Conn(s, this);
                synchronized (lock) { conns.add(c); }
                c.start("kr-host-conn");
            } catch (Exception e) {
                if (!running) return;
            }
        }
    }

    private Player playerOf(Conn c) {
        synchronized (lock) {
            for (Player p : players) if (p != null && p.conn == c) return p;
        }
        return null;
    }

    public void onMessage(Conn c, Msg m) {
        switch (m.type()) {
            case Msg.JOIN: handleJoin(c, (Msg.Join) m); return;
            case Msg.PING: c.send(new Msg.Pong(((Msg.Ping) m).t, clock.hostMs())); return;
            default: break;
        }
        Player p = playerOf(c);
        if (p == null) return;
        switch (m.type()) {
            case Msg.PONG:
                p.ping = Math.max(0, Math.min(999, clock.localMs() - ((Msg.Pong) m).t));
                break;
            case Msg.UPDATE: {
                Msg.Update u = (Msg.Update) m;
                synchronized (lock) {
                    if (raceState == 0) { p.kart = u.kart; p.color = u.color; p.driver = u.driver; p.ready = u.ready; }
                }
                broadcastLobby();
                break;
            }
            case Msg.LEAVE: removePlayer(p, true); c.close(); break;
            case Msg.LOADED: {
                boolean late;
                synchronized (lock) { p.loaded = true; late = raceState == 2; }
                if (late) {
                    c.send(new Msg.Go(goMs));
                    inbox.add(new Msg.Status(p.raceSlot, 2));
                    broadcastExcept(p, new Msg.Status(p.raceSlot, 2));
                } else checkAllLoaded();
                break;
            }
            case Msg.TCP_STATE: p.tcpState = true; break;
            case Msg.PICKUP: ((Msg.Pickup) m).from = p.raceSlot; inbox.add(m); break;
            case Msg.USE_ITEM: ((Msg.UseItem) m).from = p.raceSlot; inbox.add(m); break;
            case Msg.FINISHED: ((Msg.Finished) m).from = p.raceSlot; inbox.add(m); break;
            case Msg.DESTROY: broadcastExcept(p, m); inbox.add(m); break;
            case Msg.STATE: ((Msg.State) m).k.slot = p.raceSlot; inbox.add(m); break;
            default: break;
        }
    }

    private void handleJoin(Conn c, Msg.Join j) {
        if (c.tag >= 0) return;
        Player joined = null;
        String reject = null;
        boolean rejoin = false;
        Msg.Welcome w = new Msg.Welcome();
        synchronized (lock) {
            if (j.version != NetConst.PROTOCOL) reject = "Game version mismatch";
            else {
                Player existing = null;
                for (Player p : players) if (p != null && !p.host && p.tokHi == j.tokHi && p.tokLo == j.tokLo) existing = p;
                if (existing != null && raceState != 0) {
                    if (existing.conn != null && existing.conn.isOpen()) existing.conn.close();
                    existing.conn = c; existing.connected = true; existing.loaded = false;
                    joined = existing; rejoin = true;
                } else if (raceState != 0) reject = "A race is already in progress";
                else if (connectedCount() >= settings.maxKarts) reject = "The lobby is full";
                else {
                    int id = -1;
                    for (int i = 1; i < players.length; i++) if (players[i] == null) { id = i; break; }
                    if (id < 0) reject = "The lobby is full";
                    else {
                        Player p = new Player();
                        p.id = id; p.conn = c; p.name = j.name.length() == 0 ? "Player" + id : j.name;
                        p.kart = j.kart; p.color = j.color; p.driver = j.driver; p.tokHi = j.tokHi; p.tokLo = j.tokLo;
                        players[id] = p;
                        joined = p;
                    }
                }
            }
            if (joined != null) {
                c.tag = joined.id;
                w.slot = joined.id; w.rejoin = rejoin; w.raceState = raceState; w.udpPort = udpPort;
                w.hostName = hostName; w.settings = settings.copy();
                w.players = buildLobby().players;
            }
        }
        if (reject != null) { c.send(new Msg.Reject(reject)); c.closeAfterFlush(); return; }
        c.send(w);
        if (rejoin) {
            ev.onNotice(joined.name + " reconnected");
            if (lastStart != null) c.send(lastStart);
        } else {
            ev.onNotice(joined.name + " joined");
            broadcastLobby();
        }
    }

    public void onClosed(Conn c) {
        synchronized (lock) { conns.remove(c); }
        Player p = playerOf(c);
        if (p != null && running) removePlayer(p, false);
    }

    private void removePlayer(Player p, boolean left) {
        boolean inRace;
        synchronized (lock) {
            if (p.host) return;
            inRace = raceState != 0;
            if (inRace) {
                if (!p.connected) return;
                p.connected = false;
                p.conn = null;
            } else {
                if (players[p.id] == p) players[p.id] = null;
            }
        }
        ev.onNotice(p.name + (left ? " left" : " disconnected"));
        if (inRace) {
            Msg.Status st = new Msg.Status(p.raceSlot, left ? 0 : 1);
            inbox.add(st);
            broadcastExcept(p, st);
            checkAllLoaded();
        } else broadcastLobby();
    }

    private void broadcastExcept(Player skip, Msg m) {
        List<Conn> targets = new ArrayList<Conn>();
        synchronized (lock) {
            for (Player p : players) if (p != null && p != skip && !p.host && p.connected && p.conn != null) targets.add(p.conn);
        }
        for (Conn c : targets) c.send(m);
    }

    // ------------------------------------------------------------------ udp

    private void udpLoop() {
        byte[] buf = new byte[2048];
        while (running) {
            try {
                DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                udp.receive(pkt);
                Msg m = Udp.decode(pkt.getData(), pkt.getLength());
                if (m == null) continue;
                InetSocketAddress from = new InetSocketAddress(pkt.getAddress(), pkt.getPort());
                if (m.type() == Msg.UDP_HELLO) {
                    Msg.UdpHello h = (Msg.UdpHello) m;
                    Player p;
                    synchronized (lock) { p = (h.slot >= 0 && h.slot < players.length) ? players[h.slot] : null; }
                    if (p != null && p.tokHi == h.tokHi && p.tokLo == h.tokLo) {
                        p.udp = from;
                        byte[] ack = Udp.encode(new Msg.Simple(Msg.UDP_ACK));
                        udp.send(new DatagramPacket(ack, ack.length, from));
                    }
                } else if (m.type() == Msg.STATE) {
                    Player p = null;
                    synchronized (lock) { for (Player q : players) if (q != null && from.equals(q.udp)) p = q; }
                    if (p != null && p.raceSlot >= 0) {
                        ((Msg.State) m).k.slot = p.raceSlot;
                        inbox.add(m);
                    }
                }
            } catch (java.net.SocketTimeoutException ignored) {
            } catch (Exception e) {
                if (!running) return;
            }
        }
    }

    // ------------------------------------------------------------------ maintenance

    private void maintLoop() {
        long lastPing = 0, lastLobby = 0;
        while (running) {
            try { Thread.sleep(400); } catch (InterruptedException e) { return; }
            long now = System.currentTimeMillis();
            List<Conn> stale = new ArrayList<Conn>();
            List<Conn> pingTargets = new ArrayList<Conn>();
            boolean loadTimeout = false;
            synchronized (lock) {
                for (Conn c : conns) {
                    if (c.tag < 0 && now - c.lastRecvMs > 6000) stale.add(c);
                    else if (c.tag >= 0 && now - c.lastRecvMs > 8000) stale.add(c);
                }
                if (now - lastPing > 2000) {
                    lastPing = now;
                    for (Player p : players) if (p != null && !p.host && p.connected && p.conn != null) pingTargets.add(p.conn);
                }
                if (raceState == 1 && now - loadStartMs > 45000) loadTimeout = true;
            }
            for (Conn c : stale) c.close();
            int t = clock.localMs();
            for (Conn c : pingTargets) c.send(new Msg.Ping(t));
            if (loadTimeout) {
                synchronized (lock) { for (Player p : players) if (p != null && p.connected && !p.loaded && !p.host) p.loaded = true; }
                checkAllLoaded();
            }
            if (raceState == 0 && now - lastLobby > 1500) { lastLobby = now; broadcastLobby(); }
        }
    }

    // ------------------------------------------------------------------ RaceNet

    public boolean isHost() { return true; }
    public int clockMs() { return clock.hostMs(); }

    public void sendReliable(Msg m) { broadcastExcept(null, m); }

    public void sendReliableTo(int raceSlot, Msg m) {
        Conn c = null;
        synchronized (lock) { for (Player p : players) if (p != null && p.raceSlot == raceSlot && p.connected) c = p.conn; }
        if (c != null) c.send(m);
    }

    public void sendFast(Msg m) {
        byte[] pkt;
        try { pkt = Udp.encode(m); } catch (IOException e) { return; }
        List<Player> targets = new ArrayList<Player>();
        synchronized (lock) { for (Player p : players) if (p != null && !p.host && p.connected) targets.add(p); }
        for (Player p : targets) {
            InetSocketAddress a = p.udp;
            if (a != null && !p.tcpState) {
                try { udp.send(new DatagramPacket(pkt, pkt.length, a)); } catch (Exception ignored) { }
            } else if (p.conn != null) p.conn.send(m);
        }
    }

    public Msg poll() { return inbox.poll(); }
}
