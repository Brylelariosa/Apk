package com.kartracer.app;

import android.graphics.Path;

import com.kartracer.world.Road;
import com.kartracer.world.TrackData;
import com.kartracer.world.TrackDef;
import com.kartracer.world.Tracks;

/** Lightweight top-down track outlines for track cards and the in-race minimap. */
public final class MapPaths {
    private MapPaths() {}

    public static final class Data {
        public final float[] x, z;
        public final int n;
        public final float minX, maxX, minZ, maxZ;

        Data(float[] x, float[] z) {
            this.x = x; this.z = z; n = x.length;
            float a = 1e9f, b = -1e9f, c = 1e9f, d = -1e9f;
            for (int i = 0; i < n; i++) { a = Math.min(a, x[i]); b = Math.max(b, x[i]); c = Math.min(c, z[i]); d = Math.max(d, z[i]); }
            minX = a; maxX = b; minZ = c; maxZ = d;
        }
    }

    private static final Data[] cache = new Data[Tracks.COUNT];

    public static synchronized Data forDef(TrackDef def) {
        int i = def.id;
        if (cache[i] == null) {
            Road r = Road.fromControl(def.controlPoints(), true, 8f, 0);
            cache[i] = new Data(r.x.clone(), r.z.clone());
        }
        return cache[i];
    }

    public static Data forTrack(TrackData td) {
        int step = Math.max(1, td.main.n / 140);
        int c = (td.main.n + step - 1) / step;
        float[] x = new float[c], z = new float[c];
        for (int i = 0; i < c; i++) { x[i] = td.main.x[i * step]; z[i] = td.main.z[i * step]; }
        return new Data(x, z);
    }

    /** out = {scale, offsetX, offsetY} mapping world x,z to view coordinates inside the box. */
    public static void fit(Data d, float left, float top, float w, float h, float pad, float[] out) {
        float rx = Math.max(1f, d.maxX - d.minX), rz = Math.max(1f, d.maxZ - d.minZ);
        float k = Math.min((w - 2 * pad) / rx, (h - 2 * pad) / rz);
        out[0] = k;
        out[1] = left + (w - rx * k) / 2f - d.minX * k;
        out[2] = top + (h - rz * k) / 2f - d.minZ * k;
    }

    public static void buildPath(Data d, float[] fit, Path p) {
        p.reset();
        for (int i = 0; i < d.n; i++) {
            float u = d.x[i] * fit[0] + fit[1], v = d.z[i] * fit[0] + fit[2];
            if (i == 0) p.moveTo(u, v); else p.lineTo(u, v);
        }
        p.close();
    }
}
