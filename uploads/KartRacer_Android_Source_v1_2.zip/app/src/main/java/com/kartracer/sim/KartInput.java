package com.kartracer.sim;

/** Driver intent for one kart (from touch controls, tilt or AI). */
public final class KartInput {
    public float steer, throttle, brake;
    public boolean drift, boost;
    /** Set true for one step when the item button was pressed. */
    public boolean item;

    public void clear() { steer = throttle = brake = 0f; drift = boost = item = false; }

    public void set(KartInput o) { steer = o.steer; throttle = o.throttle; brake = o.brake; drift = o.drift; boost = o.boost; item = o.item; }
}
