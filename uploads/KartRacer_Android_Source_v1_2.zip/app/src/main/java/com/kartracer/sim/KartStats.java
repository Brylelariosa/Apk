package com.kartracer.sim;

/** Per kart tuning. Visual parameters live in gfx.KartModels. */
public final class KartStats {
    public final String name, tagline;
    public final float maxSpeed, accel, handling, grip, mass, durability, offRoad;

    private KartStats(String name, String tagline, float maxSpeed, float accel, float handling, float grip, float mass,
                      float durability, float offRoad) {
        this.name = name; this.tagline = tagline; this.maxSpeed = maxSpeed; this.accel = accel; this.handling = handling;
        this.grip = grip; this.mass = mass; this.durability = durability; this.offRoad = offRoad;
    }

    public static final int COUNT = 6;
    public static final KartStats[] ALL = {
            new KartStats("Dune Hopper", "Balanced all-rounder", 38.0f, 19f, 1.00f, 1.00f, 1.0f, 0.5f, 0.5f),
            new KartStats("Sand Viper", "Fast and fragile", 41.0f, 17f, 0.88f, 0.95f, 0.85f, 0.3f, 0.3f),
            new KartStats("Rock Crusher", "Heavy and tough", 36.0f, 15f, 0.86f, 1.00f, 1.5f, 0.9f, 0.8f),
            new KartStats("Wave Runner", "Agile and quick off the line", 36.5f, 21f, 1.15f, 1.05f, 0.8f, 0.3f, 0.5f),
            new KartStats("Lava Rod", "Explosive acceleration", 38.5f, 23f, 0.95f, 0.95f, 1.05f, 0.5f, 0.4f),
            new KartStats("Jungle Rover", "Shrugs off rough terrain", 36.0f, 18f, 1.05f, 1.05f, 1.2f, 0.7f, 1.0f),
    };

    public static KartStats get(int i) { return ALL[Math.floorMod(i, COUNT)]; }

    // 0..1 bars for the garage UI
    public float speedBar() { return (maxSpeed - 33f) / 10f; }
    public float accelBar() { return (accel - 12f) / 13f; }
    public float handlingBar() { return (handling - 0.7f) / 0.5f; }
    public float toughBar() { return durability; }
}
