package com.kartracer.sim;

/** One line of the final standings. */
public final class ResultRow {
    public int slot, place, timeMs; // timeMs < 0 = did not finish
    public String name = "";
    public boolean ai;
}
