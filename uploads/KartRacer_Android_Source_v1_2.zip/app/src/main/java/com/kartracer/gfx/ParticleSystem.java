package com.kartracer.gfx;

/** Pooled billboard particles (struct of arrays, swap-remove). Allocation free after construction. */
public final class ParticleSystem {
    public final int cap;
    private final float[] x, y, z, vx, vy, vz, age, life, s0, s1, r, g, b, a, drag, grav;
    private final boolean[] add;
    private int n;

    public ParticleSystem(int cap) {
        this.cap = cap;
        x = new float[cap]; y = new float[cap]; z = new float[cap]; vx = new float[cap]; vy = new float[cap]; vz = new float[cap];
        age = new float[cap]; life = new float[cap]; s0 = new float[cap]; s1 = new float[cap];
        r = new float[cap]; g = new float[cap]; b = new float[cap]; a = new float[cap]; drag = new float[cap]; grav = new float[cap];
        add = new boolean[cap];
    }

    public int count() { return n; }
    public void clear() { n = 0; }

    public void emit(boolean additive, float px, float py, float pz, float pvx, float pvy, float pvz, float size0, float size1,
                     float lifeSec, float cr, float cg, float cb, float ca, float dragK, float gravity) {
        if (n >= cap) return;
        int i = n++;
        x[i] = px; y[i] = py; z[i] = pz; vx[i] = pvx; vy[i] = pvy; vz[i] = pvz;
        age[i] = 0f; life[i] = Math.max(0.05f, lifeSec); s0[i] = size0; s1[i] = size1;
        r[i] = cr; g[i] = cg; b[i] = cb; a[i] = ca; drag[i] = dragK; grav[i] = gravity; add[i] = additive;
    }

    public void update(float dt) {
        for (int i = 0; i < n; ) {
            age[i] += dt;
            if (age[i] >= life[i]) {
                int l = n - 1;
                if (i != l) copy(l, i);
                n--;
                continue;
            }
            float k = Math.max(0f, 1f - drag[i] * dt);
            vx[i] *= k; vz[i] *= k; vy[i] = vy[i] * k - grav[i] * dt;
            x[i] += vx[i] * dt; y[i] += vy[i] * dt; z[i] += vz[i] * dt;
            i++;
        }
    }

    private void copy(int from, int to) {
        x[to] = x[from]; y[to] = y[from]; z[to] = z[from]; vx[to] = vx[from]; vy[to] = vy[from]; vz[to] = vz[from];
        age[to] = age[from]; life[to] = life[from]; s0[to] = s0[from]; s1[to] = s1[from];
        r[to] = r[from]; g[to] = g[from]; b[to] = b[from]; a[to] = a[from]; drag[to] = drag[from]; grav[to] = grav[from]; add[to] = add[from];
    }

    /** Writes 8 floats per particle (x,y,z,size, r,g,b,a) for the requested blend mode. Returns the particle count. */
    public int fill(float[] out, boolean additive) {
        int c = 0;
        for (int i = 0; i < n; i++) {
            if (add[i] != additive) continue;
            float t = age[i] / life[i];
            float fade = t < 0.12f ? t / 0.12f : 1f - (t - 0.12f) / 0.88f;
            int o = c * 8;
            if (o + 8 > out.length) break;
            out[o] = x[i]; out[o + 1] = y[i]; out[o + 2] = z[i]; out[o + 3] = s0[i] + (s1[i] - s0[i]) * t;
            out[o + 4] = r[i]; out[o + 5] = g[i]; out[o + 6] = b[i]; out[o + 7] = a[i] * Math.max(0f, fade);
            c++;
        }
        return c;
    }
}
