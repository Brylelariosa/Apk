package com.kartracer.gfx;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/** CPU side mesh: interleaved vertex layout pos(3f) normal(4b) color(4ub) uv(2f) = 28 bytes, 16 bit indices. */
public final class MeshData {
    public static final int STRIDE = 28;

    public final int vcount, icount;
    public final byte[] verts;
    public final short[] indices;
    public float radius;
    public float cx, cy, cz;

    public MeshData(int vcount, byte[] verts, short[] indices) {
        this.vcount = vcount; this.verts = verts; this.indices = indices; this.icount = indices.length;
    }

    public ByteBuffer vertexBuffer() {
        ByteBuffer b = ByteBuffer.allocateDirect(verts.length).order(ByteOrder.nativeOrder());
        b.put(verts);
        b.position(0);
        return b;
    }

    public ShortBuffer indexBuffer() { return indexBuffer(indices); }

    public static ShortBuffer indexBuffer(short[] idx) {
        ShortBuffer b = ByteBuffer.allocateDirect(idx.length * 2).order(ByteOrder.nativeOrder()).asShortBuffer();
        b.put(idx);
        b.position(0);
        return b;
    }

    // accessors for tests / software preview
    private ByteBuffer le() { return ByteBuffer.wrap(verts).order(ByteOrder.LITTLE_ENDIAN); }
    public float px(int i) { return le().getFloat(i * STRIDE); }
    public float py(int i) { return le().getFloat(i * STRIDE + 4); }
    public float pz(int i) { return le().getFloat(i * STRIDE + 8); }
    public float nx(int i) { return verts[i * STRIDE + 12] / 127f; }
    public float ny(int i) { return verts[i * STRIDE + 13] / 127f; }
    public float nz(int i) { return verts[i * STRIDE + 14] / 127f; }
    public int color(int i) { return le().getInt(i * STRIDE + 16); }
    public float uu(int i) { return le().getFloat(i * STRIDE + 20); }
    public float vv(int i) { return le().getFloat(i * STRIDE + 24); }
    public void setColor(int i, int c) { le().putInt(i * STRIDE + 16, c); }
}
