package com.kartracer.gfx;

/** Graphics quality presets. */
public final class Quality {
    public int shadowSize;      // 0 = blob shadows only
    public boolean pcf;         // 4 tap shadow filter
    public float renderScale;   // 0.5 .. 1
    public float drawDist;      // meters
    public int particleCap;
    public boolean waterWaves = true;
    public float terrainLodNear, terrainLodFar;
    public float propDensity = 1f;

    public static final String[] NAMES = {"Low", "Medium", "High"};

    public static Quality preset(int level) {
        Quality q = new Quality();
        switch (level) {
            case 0:
                q.shadowSize = 0; q.pcf = false; q.renderScale = 0.7f; q.drawDist = 240f; q.particleCap = 350;
                q.waterWaves = false; q.terrainLodNear = 70f; q.terrainLodFar = 150f; q.propDensity = 0.6f; break;
            case 1:
                q.shadowSize = 1024; q.pcf = false; q.renderScale = 0.85f; q.drawDist = 340f; q.particleCap = 700;
                q.terrainLodNear = 95f; q.terrainLodFar = 200f; q.propDensity = 0.85f; break;
            default:
                q.shadowSize = 2048; q.pcf = true; q.renderScale = 1f; q.drawDist = 460f; q.particleCap = 1200;
                q.terrainLodNear = 120f; q.terrainLodFar = 250f; q.propDensity = 1f; break;
        }
        return q;
    }
}
