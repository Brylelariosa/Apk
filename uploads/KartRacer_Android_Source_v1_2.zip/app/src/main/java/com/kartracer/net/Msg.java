package com.kartracer.net;

import com.kartracer.sim.Participant;
import com.kartracer.sim.RaceSettings;
import com.kartracer.sim.ResultRow;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/** Wire messages shared by TCP (reliable) and UDP (fast) transports. */
public abstract class Msg {
    public static final int JOIN = 1, WELCOME = 2, REJECT = 3, LOBBY = 4, UPDATE = 5, START = 6, LOADED = 7, GO = 8, LEAVE = 9,
            KICK = 10, PING = 11, PONG = 12, PICKUP = 13, BOX_TAKEN = 14, USE_ITEM = 15, HIT = 16, DESTROY = 17, FINISHED = 18,
            RESULTS = 19, STATUS = 20, BACK = 21, STATE = 22, SNAPSHOT = 23, UDP_HELLO = 24, UDP_ACK = 25, TCP_STATE = 26;

    public abstract int type();
    public abstract void write(DataOutputStream o) throws IOException;

    // ---------------------------------------------------------------- helpers
    static void str(DataOutputStream o, String s) throws IOException {
        if (s == null) s = "";
        if (s.length() > 40) s = s.substring(0, 40);
        o.writeUTF(s);
    }

    static void settings(DataOutputStream o, RaceSettings s) throws IOException {
        o.writeByte(s.track); o.writeByte(s.laps); o.writeByte(s.aiCount); o.writeByte(s.difficulty); o.writeByte(s.maxKarts);
        o.writeBoolean(s.items);
    }

    static RaceSettings settings(DataInputStream in) throws IOException {
        RaceSettings s = new RaceSettings();
        s.track = in.readByte(); s.laps = in.readByte(); s.aiCount = in.readByte(); s.difficulty = in.readByte();
        s.maxKarts = in.readByte(); s.items = in.readBoolean();
        return s;
    }

    // ---------------------------------------------------------------- data blocks
    public static final class PlayerInfo {
        public int slot, kart, color, driver, ping;
        public String name = "";
        public boolean ready, connected = true, host;

        void write(DataOutputStream o) throws IOException {
            o.writeByte(slot); str(o, name); o.writeByte(kart); o.writeByte(color); o.writeByte(driver);
            o.writeBoolean(ready); o.writeBoolean(connected); o.writeBoolean(host); o.writeShort(ping);
        }

        static PlayerInfo read(DataInputStream in) throws IOException {
            PlayerInfo p = new PlayerInfo();
            p.slot = in.readByte(); p.name = in.readUTF(); p.kart = in.readByte(); p.color = in.readByte(); p.driver = in.readByte();
            p.ready = in.readBoolean(); p.connected = in.readBoolean(); p.host = in.readBoolean(); p.ping = in.readShort();
            return p;
        }
    }

    public static final class KartNet {
        public int slot, stamp, flags, crossings;
        public float x, y, z, yaw, vx, vy, vz;

        void write(DataOutputStream o) throws IOException {
            o.writeByte(slot); o.writeInt(stamp); o.writeInt(flags); o.writeByte(crossings);
            o.writeFloat(x); o.writeFloat(y); o.writeFloat(z); o.writeFloat(yaw);
            o.writeFloat(vx); o.writeFloat(vy); o.writeFloat(vz);
        }

        static KartNet read(DataInputStream in) throws IOException {
            KartNet k = new KartNet();
            k.slot = in.readByte(); k.stamp = in.readInt(); k.flags = in.readInt(); k.crossings = in.readByte();
            k.x = in.readFloat(); k.y = in.readFloat(); k.z = in.readFloat(); k.yaw = in.readFloat();
            k.vx = in.readFloat(); k.vy = in.readFloat(); k.vz = in.readFloat();
            return k;
        }
    }

    public static final class EntNet {
        public int id, type, owner;
        public float x, y, z, vx, vy, vz, yaw;

        void write(DataOutputStream o) throws IOException {
            o.writeShort(id); o.writeByte(type); o.writeByte(owner);
            o.writeFloat(x); o.writeFloat(y); o.writeFloat(z); o.writeFloat(vx); o.writeFloat(vy); o.writeFloat(vz); o.writeFloat(yaw);
        }

        static EntNet read(DataInputStream in) throws IOException {
            EntNet e = new EntNet();
            e.id = in.readShort(); e.type = in.readByte(); e.owner = in.readByte();
            e.x = in.readFloat(); e.y = in.readFloat(); e.z = in.readFloat();
            e.vx = in.readFloat(); e.vy = in.readFloat(); e.vz = in.readFloat(); e.yaw = in.readFloat();
            return e;
        }
    }

    // ---------------------------------------------------------------- lobby messages
    public static final class Join extends Msg {
        public int version, kart, color, driver;
        public long tokHi, tokLo;
        public String name = "";
        public int type() { return JOIN; }
        public void write(DataOutputStream o) throws IOException {
            o.writeInt(version); o.writeLong(tokHi); o.writeLong(tokLo); str(o, name); o.writeByte(kart); o.writeByte(color); o.writeByte(driver);
        }
        static Join read(DataInputStream in) throws IOException {
            Join j = new Join();
            j.version = in.readInt(); j.tokHi = in.readLong(); j.tokLo = in.readLong(); j.name = in.readUTF();
            j.kart = in.readByte(); j.color = in.readByte(); j.driver = in.readByte();
            return j;
        }
    }

    public static final class Welcome extends Msg {
        public int slot, raceState, udpPort;
        public boolean rejoin;
        public String hostName = "";
        public RaceSettings settings = new RaceSettings();
        public PlayerInfo[] players = new PlayerInfo[0];
        public int type() { return WELCOME; }
        public void write(DataOutputStream o) throws IOException {
            o.writeByte(slot); o.writeByte(raceState); o.writeInt(udpPort); o.writeBoolean(rejoin); str(o, hostName);
            settings(o, settings); o.writeByte(players.length);
            for (PlayerInfo p : players) p.write(o);
        }
        static Welcome read(DataInputStream in) throws IOException {
            Welcome w = new Welcome();
            w.slot = in.readByte(); w.raceState = in.readByte(); w.udpPort = in.readInt(); w.rejoin = in.readBoolean();
            w.hostName = in.readUTF(); w.settings = settings(in);
            w.players = new PlayerInfo[in.readByte()];
            for (int i = 0; i < w.players.length; i++) w.players[i] = PlayerInfo.read(in);
            return w;
        }
    }

    public static final class Reject extends Msg {
        public String reason = "";
        public Reject() {}
        public Reject(String r) { reason = r; }
        public int type() { return REJECT; }
        public void write(DataOutputStream o) throws IOException { str(o, reason); }
        static Reject read(DataInputStream in) throws IOException { return new Reject(in.readUTF()); }
    }

    public static final class Lobby extends Msg {
        public RaceSettings settings = new RaceSettings();
        public PlayerInfo[] players = new PlayerInfo[0];
        public int type() { return LOBBY; }
        public void write(DataOutputStream o) throws IOException {
            settings(o, settings); o.writeByte(players.length);
            for (PlayerInfo p : players) p.write(o);
        }
        static Lobby read(DataInputStream in) throws IOException {
            Lobby l = new Lobby();
            l.settings = settings(in);
            l.players = new PlayerInfo[in.readByte()];
            for (int i = 0; i < l.players.length; i++) l.players[i] = PlayerInfo.read(in);
            return l;
        }
    }

    public static final class Update extends Msg {
        public int kart, color, driver;
        public boolean ready;
        public int type() { return UPDATE; }
        public void write(DataOutputStream o) throws IOException {
            o.writeByte(kart); o.writeByte(color); o.writeByte(driver); o.writeBoolean(ready);
        }
        static Update read(DataInputStream in) throws IOException {
            Update u = new Update();
            u.kart = in.readByte(); u.color = in.readByte(); u.driver = in.readByte(); u.ready = in.readBoolean();
            return u;
        }
    }

    public static final class Start extends Msg {
        public RaceSettings settings = new RaceSettings();
        public long seed;
        public Participant[] parts = new Participant[0];
        public int type() { return START; }
        public void write(DataOutputStream o) throws IOException {
            settings(o, settings); o.writeLong(seed); o.writeByte(parts.length);
            for (Participant p : parts) {
                o.writeByte(p.slot); o.writeBoolean(p.ai); str(o, p.name); o.writeByte(p.kart); o.writeByte(p.color);
                o.writeByte(p.driver); o.writeByte(p.skill); o.writeByte(p.playerId);
            }
        }
        static Start read(DataInputStream in) throws IOException {
            Start s = new Start();
            s.settings = settings(in); s.seed = in.readLong();
            s.parts = new Participant[in.readByte()];
            for (int i = 0; i < s.parts.length; i++) {
                Participant p = new Participant();
                p.slot = in.readByte(); p.ai = in.readBoolean(); p.name = in.readUTF(); p.kart = in.readByte();
                p.color = in.readByte(); p.driver = in.readByte(); p.skill = in.readByte(); p.playerId = in.readByte();
                s.parts[i] = p;
            }
            return s;
        }
    }

    /** Empty control messages. */
    public static final class Simple extends Msg {
        public final int t;
        public Simple(int t) { this.t = t; }
        public int type() { return t; }
        public void write(DataOutputStream o) {}
    }

    public static final class Go extends Msg {
        public int goMs;
        public Go() {}
        public Go(int g) { goMs = g; }
        public int type() { return GO; }
        public void write(DataOutputStream o) throws IOException { o.writeInt(goMs); }
        static Go read(DataInputStream in) throws IOException { return new Go(in.readInt()); }
    }

    public static final class Kick extends Msg {
        public String reason = "";
        public Kick() {}
        public Kick(String r) { reason = r; }
        public int type() { return KICK; }
        public void write(DataOutputStream o) throws IOException { str(o, reason); }
        static Kick read(DataInputStream in) throws IOException { return new Kick(in.readUTF()); }
    }

    public static final class Ping extends Msg {
        public int t;
        public Ping() {}
        public Ping(int t) { this.t = t; }
        public int type() { return PING; }
        public void write(DataOutputStream o) throws IOException { o.writeInt(t); }
        static Ping read(DataInputStream in) throws IOException { return new Ping(in.readInt()); }
    }

    public static final class Pong extends Msg {
        public int t, hostMs;
        public Pong() {}
        public Pong(int t, int h) { this.t = t; hostMs = h; }
        public int type() { return PONG; }
        public void write(DataOutputStream o) throws IOException { o.writeInt(t); o.writeInt(hostMs); }
        static Pong read(DataInputStream in) throws IOException { return new Pong(in.readInt(), in.readInt()); }
    }

    // ---------------------------------------------------------------- race messages
    public static final class Pickup extends Msg {
        public int box;
        public Pickup() {}
        public Pickup(int b) { box = b; }
        public int type() { return PICKUP; }
        public void write(DataOutputStream o) throws IOException { o.writeShort(box); }
        static Pickup read(DataInputStream in) throws IOException { return new Pickup(in.readShort()); }
        /** Filled by the host session: who sent it. */
        public int from = -1;
    }

    public static final class BoxTaken extends Msg {
        public int box, slot, item;
        public BoxTaken() {}
        public BoxTaken(int b, int s, int i) { box = b; slot = s; item = i; }
        public int type() { return BOX_TAKEN; }
        public void write(DataOutputStream o) throws IOException { o.writeShort(box); o.writeByte(slot); o.writeByte(item); }
        static BoxTaken read(DataInputStream in) throws IOException { return new BoxTaken(in.readShort(), in.readByte(), in.readByte()); }
    }

    public static final class UseItem extends Msg {
        public int item, from = -1;
        public float x, y, z, yaw, speed;
        public int type() { return USE_ITEM; }
        public void write(DataOutputStream o) throws IOException {
            o.writeByte(item); o.writeFloat(x); o.writeFloat(y); o.writeFloat(z); o.writeFloat(yaw); o.writeFloat(speed);
        }
        static UseItem read(DataInputStream in) throws IOException {
            UseItem u = new UseItem();
            u.item = in.readByte(); u.x = in.readFloat(); u.y = in.readFloat(); u.z = in.readFloat(); u.yaw = in.readFloat(); u.speed = in.readFloat();
            return u;
        }
    }

    public static final class Hit extends Msg {
        public int slot, kind, src;
        public float x, y, z;
        public int type() { return HIT; }
        public void write(DataOutputStream o) throws IOException {
            o.writeByte(slot); o.writeByte(kind); o.writeByte(src); o.writeFloat(x); o.writeFloat(y); o.writeFloat(z);
        }
        static Hit read(DataInputStream in) throws IOException {
            Hit h = new Hit();
            h.slot = in.readByte(); h.kind = in.readByte(); h.src = in.readByte(); h.x = in.readFloat(); h.y = in.readFloat(); h.z = in.readFloat();
            return h;
        }
    }

    public static final class Destroy extends Msg {
        public int id;
        public Destroy() {}
        public Destroy(int i) { id = i; }
        public int type() { return DESTROY; }
        public void write(DataOutputStream o) throws IOException { o.writeShort(id); }
        static Destroy read(DataInputStream in) throws IOException { return new Destroy(in.readShort()); }
    }

    public static final class Finished extends Msg {
        public int timeMs, from = -1;
        public Finished() {}
        public Finished(int t) { timeMs = t; }
        public int type() { return FINISHED; }
        public void write(DataOutputStream o) throws IOException { o.writeInt(timeMs); }
        static Finished read(DataInputStream in) throws IOException { return new Finished(in.readInt()); }
    }

    public static final class Results extends Msg {
        public ResultRow[] rows = new ResultRow[0];
        public int type() { return RESULTS; }
        public void write(DataOutputStream o) throws IOException {
            o.writeByte(rows.length);
            for (ResultRow r : rows) { o.writeByte(r.slot); o.writeByte(r.place); o.writeInt(r.timeMs); str(o, r.name); o.writeBoolean(r.ai); }
        }
        static Results read(DataInputStream in) throws IOException {
            Results r = new Results();
            r.rows = new ResultRow[in.readByte()];
            for (int i = 0; i < r.rows.length; i++) {
                ResultRow w = new ResultRow();
                w.slot = in.readByte(); w.place = in.readByte(); w.timeMs = in.readInt(); w.name = in.readUTF(); w.ai = in.readBoolean();
                r.rows[i] = w;
            }
            return r;
        }
    }

    /** status: 0 left, 1 disconnected (AI takes over), 2 reconnected. */
    public static final class Status extends Msg {
        public int slot, status;
        public Status() {}
        public Status(int s, int st) { slot = s; status = st; }
        public int type() { return STATUS; }
        public void write(DataOutputStream o) throws IOException { o.writeByte(slot); o.writeByte(status); }
        static Status read(DataInputStream in) throws IOException { return new Status(in.readByte(), in.readByte()); }
    }

    public static final class State extends Msg {
        public KartNet k = new KartNet();
        public State() {}
        public State(KartNet k) { this.k = k; }
        public int type() { return STATE; }
        public void write(DataOutputStream o) throws IOException { k.write(o); }
        static State read(DataInputStream in) throws IOException { return new State(KartNet.read(in)); }
    }

    public static final class Snapshot extends Msg {
        public int seq, stamp;
        public KartNet[] karts = new KartNet[0];
        public EntNet[] ents = new EntNet[0];
        public int type() { return SNAPSHOT; }
        public void write(DataOutputStream o) throws IOException {
            o.writeInt(seq); o.writeInt(stamp); o.writeByte(karts.length);
            for (KartNet k : karts) k.write(o);
            o.writeByte(ents.length);
            for (EntNet e : ents) e.write(o);
        }
        static Snapshot read(DataInputStream in) throws IOException {
            Snapshot s = new Snapshot();
            s.seq = in.readInt(); s.stamp = in.readInt();
            s.karts = new KartNet[in.readByte()];
            for (int i = 0; i < s.karts.length; i++) s.karts[i] = KartNet.read(in);
            s.ents = new EntNet[in.readByte()];
            for (int i = 0; i < s.ents.length; i++) s.ents[i] = EntNet.read(in);
            return s;
        }
    }

    public static final class UdpHello extends Msg {
        public int slot;
        public long tokHi, tokLo;
        public int type() { return UDP_HELLO; }
        public void write(DataOutputStream o) throws IOException { o.writeByte(slot); o.writeLong(tokHi); o.writeLong(tokLo); }
        static UdpHello read(DataInputStream in) throws IOException {
            UdpHello h = new UdpHello();
            h.slot = in.readByte(); h.tokHi = in.readLong(); h.tokLo = in.readLong();
            return h;
        }
    }

    public static Msg read(int type, DataInputStream in) throws IOException {
        switch (type) {
            case JOIN: return Join.read(in);
            case WELCOME: return Welcome.read(in);
            case REJECT: return Reject.read(in);
            case LOBBY: return Lobby.read(in);
            case UPDATE: return Update.read(in);
            case START: return Start.read(in);
            case GO: return Go.read(in);
            case KICK: return Kick.read(in);
            case PING: return Ping.read(in);
            case PONG: return Pong.read(in);
            case PICKUP: return Pickup.read(in);
            case BOX_TAKEN: return BoxTaken.read(in);
            case USE_ITEM: return UseItem.read(in);
            case HIT: return Hit.read(in);
            case DESTROY: return Destroy.read(in);
            case FINISHED: return Finished.read(in);
            case RESULTS: return Results.read(in);
            case STATUS: return Status.read(in);
            case STATE: return State.read(in);
            case SNAPSHOT: return Snapshot.read(in);
            case UDP_HELLO: return UdpHello.read(in);
            case LOADED: case LEAVE: case BACK: case UDP_ACK: case TCP_STATE: return new Simple(type);
            default: throw new IOException("unknown message type " + type);
        }
    }
}
