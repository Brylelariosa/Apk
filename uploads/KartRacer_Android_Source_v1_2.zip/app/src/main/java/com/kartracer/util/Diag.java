package com.kartracer.util;

import java.util.ArrayDeque;

/** In-memory diagnostic log (works without adb). A sink can forward lines to logcat / files. */
public final class Diag {
    private Diag() {}

    public interface Sink { void line(String s); }

    private static final ArrayDeque<String> lines = new ArrayDeque<String>();
    private static final int MAX = 600;
    private static volatile Sink sink;
    private static final long t0 = System.currentTimeMillis();

    public static void setSink(Sink s) { sink = s; }

    public static synchronized void log(String tag, String msg) {
        String l = String.format("%7.2f %s: %s", (System.currentTimeMillis() - t0) / 1000.0, tag, msg);
        lines.addLast(l);
        while (lines.size() > MAX) lines.removeFirst();
        Sink s = sink;
        if (s != null) s.line(l);
    }

    public static void err(String tag, String msg, Throwable t) {
        log(tag, "ERROR " + msg + (t == null ? "" : " :: " + stack(t)));
    }

    public static String stack(Throwable t) {
        StringBuilder sb = new StringBuilder();
        int depth = 0;
        for (Throwable c = t; c != null && depth < 4; c = c.getCause(), depth++) {
            sb.append(depth == 0 ? "" : " caused by ").append(c.getClass().getName()).append(": ").append(c.getMessage());
            StackTraceElement[] st = c.getStackTrace();
            for (int i = 0; i < Math.min(st.length, 8); i++) sb.append("\n    at ").append(st[i]);
        }
        return sb.toString();
    }

    public static synchronized String dump() {
        StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append('\n');
        return sb.toString();
    }

    public static synchronized void clear() { lines.clear(); }
}
