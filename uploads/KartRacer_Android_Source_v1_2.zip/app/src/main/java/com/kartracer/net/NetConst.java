package com.kartracer.net;

public final class NetConst {
    private NetConst() {}

    public static final int PROTOCOL = 2;
    public static final int TCP_PORT = 47231;
    public static final int UDP_PORT = 47232;
    public static final int DISCOVERY_PORT = 47233;
    public static final int MAX_PLAYERS = 8;
    public static final byte[] DISC_MAGIC = {'K', 'R', 'D', '1'};
    public static final int UDP_MAGIC = 0x4B52;
}
