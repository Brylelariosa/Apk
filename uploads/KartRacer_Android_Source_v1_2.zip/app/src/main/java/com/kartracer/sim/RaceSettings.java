package com.kartracer.sim;

/** Race configuration chosen in the setup / lobby screen. */
public final class RaceSettings {
    public int track = 0, laps = 3, aiCount = 5, difficulty = 1, maxKarts = 8;
    public boolean items = true;

    public RaceSettings copy() {
        RaceSettings s = new RaceSettings();
        s.track = track; s.laps = laps; s.aiCount = aiCount; s.difficulty = difficulty; s.maxKarts = maxKarts; s.items = items;
        return s;
    }
}
