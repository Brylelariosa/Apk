package com.kartracer.sim;

/** One racer on the grid. */
public final class Participant {
    public int slot;
    public boolean ai;
    public String name = "Racer";
    public int kart, color, driver;
    public int skill; // AI skill 0..2
    /** Lobby id of the human behind this racer (-1 for AI). */
    public int playerId = -1;

    public Participant() {}

    public Participant(int slot, boolean ai, String name, int kart, int color, int driver, int skill) {
        this.slot = slot; this.ai = ai; this.name = name; this.kart = kart; this.color = color; this.driver = driver; this.skill = skill;
    }
}
