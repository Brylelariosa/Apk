package com.kartracer.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.kartracer.gfx.KartModels;
import com.kartracer.gl.GameRenderer;
import com.kartracer.net.Discovery;
import com.kartracer.net.Msg;
import com.kartracer.net.NetConst;
import com.kartracer.net.NetUtil;
import com.kartracer.sim.KartStats;
import com.kartracer.sim.RaceSettings;
import com.kartracer.sim.ResultRow;
import com.kartracer.world.TrackDef;
import com.kartracer.world.Tracks;

import java.util.List;
import java.util.Locale;

/** Builders for every menu screen (programmatic views). */
public final class Screens {
    private final Context ctx;
    private final Settings settings;
    private final GameEngine engine;
    private final GameRenderer renderer;
    private final Router router;

    public Screens(Context ctx, Settings s, GameEngine e, GameRenderer r, Router router) {
        this.ctx = ctx; settings = s; engine = e; renderer = r; this.router = router;
    }

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT, WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    // ------------------------------------------------------------------ shared pieces

    private LinearLayout frame(String title, View.OnClickListener back, boolean dim) {
        LinearLayout root = Ui.vbox(ctx);
        if (dim) root.setBackgroundColor(0xB0030A14);
        LinearLayout head = Ui.hbox(ctx);
        head.setPadding(Ui.dp(20), Ui.dp(14), Ui.dp(20), Ui.dp(6));
        if (back != null) { head.addView(Ui.iconButton(ctx, Icons.BACK, 42, back)); head.addView(Ui.space(ctx, 14, 1)); }
        TextView t = Ui.text(ctx, title.toUpperCase(Locale.US), 20, Ui.TEXT, true);
        t.setLetterSpacing(0.08f);
        head.addView(t);
        root.addView(head, Ui.lp(MATCH, WRAP));
        return root;
    }

    private View dots(int value, int max) {
        return new View(ctx) {
            private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override protected void onMeasure(int w, int h) { setMeasuredDimension(Ui.dp(max * 14), Ui.dp(10)); }
            @Override protected void onDraw(Canvas c) {
                for (int i = 0; i < max; i++) {
                    p.setStyle(i < value ? Paint.Style.FILL : Paint.Style.STROKE);
                    p.setStrokeWidth(Ui.dp(1.5f));
                    p.setColor(i < value ? Ui.ACCENT : 0x88FFFFFF);
                    c.drawCircle(Ui.dp(5 + i * 14), Ui.dp(5), Ui.dp(4), p);
                }
            }
        };
    }

    private static String fmtTime(int ms) {
        if (ms < 0) return "--:--.---";
        int m = ms / 60000, s = (ms / 1000) % 60, t = ms % 1000;
        return String.format(Locale.US, "%d:%02d.%03d", m, s, t);
    }

    private EditText nameField() {
        final EditText e = new EditText(ctx);
        e.setText(settings.playerName);
        e.setTextColor(Ui.TEXT);
        e.setHintTextColor(Ui.DIM);
        e.setHint("Your name");
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setImeOptions(EditorInfo.IME_ACTION_DONE);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(14)});
        e.setBackground(Ui.roundedStroke(0x66000000, 10, Ui.STROKE, 1));
        e.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable s) {
                String n = s.toString().trim();
                settings.playerName = n.length() == 0 ? "Player" : n;
                router.saveSettings();
            }
        });
        return e;
    }

    // ------------------------------------------------------------------ main menu

    public View main() {
        FrameLayout root = new FrameLayout(ctx);
        LinearLayout left = Ui.vbox(ctx);
        left.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xE6050E1A, 0xAA050E1A, 0x00050E1A}));
        left.setPadding(Ui.dp(36), Ui.dp(10), Ui.dp(70), Ui.dp(10));
        left.setGravity(Gravity.CENTER_VERTICAL);
        TextView k = Ui.text(ctx, "KART", 46, Ui.TEXT, true);
        k.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC));
        k.setShadowLayer(Ui.dp(6), 0, Ui.dp(3), 0xFF000000);
        TextView r = Ui.text(ctx, "RACER", 46, Ui.ACCENT, true);
        r.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC));
        r.setShadowLayer(Ui.dp(6), 0, Ui.dp(3), 0xFF000000);
        left.addView(k); left.addView(r);
        TextView tag = Ui.text(ctx, "Arcade kart racing with local Wi-Fi multiplayer", 13, Ui.DIM, false);
        left.addView(tag, Ui.lpm(WRAP, WRAP, 0, 4, 0, 18));
        left.addView(Ui.button(ctx, "QUICK RACE", Icons.PLAY, 0, v -> router.go(Router.SETUP)), Ui.lpm(MATCH, WRAP, 0, 0, 0, 10));
        left.addView(Ui.button(ctx, "MULTIPLAYER", Icons.WIFI, 1, v -> router.go(Router.MP_MENU)), Ui.lpm(MATCH, WRAP, 0, 0, 0, 10));
        left.addView(Ui.button(ctx, "GARAGE", Icons.WRENCH, 1, v -> router.go(Router.GARAGE)), Ui.lpm(MATCH, WRAP, 0, 0, 0, 10));
        left.addView(Ui.button(ctx, "SETTINGS", Icons.GEAR, 1, v -> router.go(Router.SETTINGS)), Ui.lpm(MATCH, WRAP, 0, 0, 0, 0));
        root.addView(left, new FrameLayout.LayoutParams(Ui.dp(400), MATCH, Gravity.START));
        TextView who = Ui.text(ctx, "Driver: " + settings.playerName + "   |   " + KartStats.get(settings.kart).name, 13, 0xFFFFFFFF, true);
        who.setShadowLayer(Ui.dp(4), 0, Ui.dp(2), 0xFF000000);
        root.addView(who, Ui.flpm(WRAP, WRAP, Gravity.BOTTOM | Gravity.END, 0, 0, 24, 18));
        return root;
    }

    // ------------------------------------------------------------------ quick race setup

    public View setup() {
        LinearLayout root = frame("Quick race", v -> router.back(), true);
        LinearLayout body = Ui.hbox(ctx);
        body.setPadding(Ui.dp(20), Ui.dp(4), Ui.dp(20), Ui.dp(16));
        body.setGravity(Gravity.TOP);

        HorizontalScrollView hs = new HorizontalScrollView(ctx);
        hs.setHorizontalScrollBarEnabled(false);
        final LinearLayout cards = Ui.hbox(ctx);
        cards.setGravity(Gravity.TOP);
        final View[] card = new View[Tracks.COUNT];
        for (int i = 0; i < Tracks.COUNT; i++) {
            final int idx = i;
            TrackDef def = Tracks.get(i);
            LinearLayout c = Ui.vbox(ctx);
            c.setPadding(Ui.dp(8), Ui.dp(8), Ui.dp(8), Ui.dp(10));
            c.addView(new MapView(ctx, def), Ui.lp(Ui.dp(206), Ui.dp(130)));
            c.addView(Ui.text(ctx, def.name, 17, Ui.TEXT, true), Ui.lpm(WRAP, WRAP, 4, 8, 4, 0));
            TextView tl = Ui.text(ctx, def.tagline, 12, Ui.DIM, false);
            tl.setMaxLines(2);
            c.addView(tl, Ui.lpm(Ui.dp(200), WRAP, 4, 3, 4, 6));
            LinearLayout meta = Ui.hbox(ctx);
            meta.addView(Ui.text(ctx, "Difficulty", 11, Ui.DIM, false));
            meta.addView(Ui.space(ctx, 8, 1));
            meta.addView(dots(def.difficulty, 3));
            c.addView(meta, Ui.lpm(WRAP, WRAP, 4, 0, 4, 0));
            card[i] = c;
            cards.addView(c, Ui.lpm(Ui.dp(222), WRAP, 0, 0, 12, 0));
        }
        final Runnable refresh = new Runnable() {
            @Override public void run() {
                for (int i = 0; i < card.length; i++)
                    card[i].setBackground(i == settings.track ? Ui.roundedStroke(0xDD1E3F66, 14, Ui.ACCENT, 2.5f) : Ui.roundedStroke(Ui.CARD, 14, Ui.STROKE, 1));
            }
        };
        for (int i = 0; i < card.length; i++) {
            final int idx = i;
            card[i].setOnClickListener(v -> { settings.track = idx; router.saveSettings(); refresh.run(); });
        }
        refresh.run();
        hs.addView(cards);
        body.addView(hs, Ui.lpw(0, MATCH, 1f));

        LinearLayout side = Ui.card(ctx);
        side.addView(Ui.sectionTitle(ctx, "Race settings"));
        side.addView(Ui.stepper(ctx, "Laps", 1, 9, settings.laps, n -> { settings.laps = n; router.saveSettings(); }));
        side.addView(Ui.stepper(ctx, "Opponents", 0, 7, settings.aiCount, n -> { settings.aiCount = n; router.saveSettings(); }));
        TextView dl = Ui.text(ctx, "Difficulty", 14, Ui.TEXT, false);
        side.addView(dl, Ui.lpm(WRAP, WRAP, 0, 8, 0, 6));
        side.addView(Ui.chips(ctx, new String[]{"Easy", "Normal", "Hard"}, settings.difficulty, n -> { settings.difficulty = n; router.saveSettings(); }));
        side.addView(Ui.toggle(ctx, "Power-ups", settings.items, b -> { settings.items = b; router.saveSettings(); }), Ui.lpm(MATCH, WRAP, 0, 8, 0, 0));
        View spacer = new View(ctx);
        side.addView(spacer, Ui.lpw(MATCH, 0, 1f));
        TextView kart = Ui.text(ctx, "Kart: " + KartStats.get(settings.kart).name, 12, Ui.DIM, false);
        side.addView(kart, Ui.lpm(WRAP, WRAP, 0, 4, 0, 8));
        side.addView(Ui.button(ctx, "START RACE", Icons.FLAG, 0, v -> router.startOffline()), Ui.lp(MATCH, WRAP));
        body.addView(side, Ui.lp(Ui.dp(270), MATCH));
        root.addView(body, Ui.lpw(MATCH, 0, 1f));
        return root;
    }

    // ------------------------------------------------------------------ garage

    public View garage() {
        final FrameLayout root = new FrameLayout(ctx);
        final LinearLayout left = Ui.card(ctx);
        final TextView name = Ui.text(ctx, "", 22, Ui.TEXT, true);
        final TextView tag = Ui.text(ctx, "", 13, Ui.DIM, false);
        final LinearLayout bars = Ui.vbox(ctx);
        left.addView(Ui.sectionTitle(ctx, "Kart"));
        left.addView(name);
        left.addView(tag, Ui.lpm(WRAP, WRAP, 0, 2, 0, 10));
        left.addView(bars);
        root.addView(left, Ui.flpm(Ui.dp(250), WRAP, Gravity.START | Gravity.CENTER_VERTICAL, 20, 0, 0, 0));

        final LinearLayout right = Ui.card(ctx);
        right.addView(Ui.sectionTitle(ctx, "Paint"));
        final View[] swatch = new View[KartModels.PAINTS.length];
        LinearLayout row1 = Ui.hbox(ctx), row2 = Ui.hbox(ctx);
        for (int i = 0; i < swatch.length; i++) {
            final int idx = i;
            View sw = new View(ctx);
            swatch[i] = sw;
            sw.setOnClickListener(v -> { settings.paint = idx; apply(root); });
            (i < 4 ? row1 : row2).addView(sw, Ui.lpm(Ui.dp(40), Ui.dp(40), 0, 0, 10, 10));
        }
        right.addView(row1); right.addView(row2);
        right.addView(Ui.sectionTitle(ctx, "Driver"));
        final TextView[] dr = new TextView[KartModels.DRIVERS];
        LinearLayout d1 = Ui.hbox(ctx), d2 = Ui.hbox(ctx);
        for (int i = 0; i < dr.length; i++) {
            final int idx = i;
            TextView t = Ui.text(ctx, KartModels.DRIVER_NAMES[i], 13, Ui.TEXT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(Ui.dp(6), Ui.dp(9), Ui.dp(6), Ui.dp(9));
            t.setOnClickListener(v -> { settings.driver = idx; apply(root); });
            dr[i] = t;
            (i < 3 ? d1 : d2).addView(t, Ui.lpm(0, WRAP, 0, 0, 6, 6));
            ((LinearLayout.LayoutParams) t.getLayoutParams()).weight = 1f;
        }
        right.addView(d1); right.addView(d2);
        root.addView(right, Ui.flpm(Ui.dp(270), WRAP, Gravity.END | Gravity.CENTER_VERTICAL, 0, 0, 20, 0));

        LinearLayout nav = Ui.hbox(ctx);
        nav.addView(Ui.iconButton(ctx, Icons.ARROW_L, 50, v -> { settings.kart = Math.floorMod(settings.kart - 1, KartStats.COUNT); apply(root); }));
        final TextView idx = Ui.text(ctx, "", 14, Ui.TEXT, true);
        idx.setGravity(Gravity.CENTER);
        nav.addView(idx, Ui.lp(Ui.dp(70), WRAP));
        nav.addView(Ui.iconButton(ctx, Icons.ARROW_R, 50, v -> { settings.kart = Math.floorMod(settings.kart + 1, KartStats.COUNT); apply(root); }));
        root.addView(nav, Ui.flpm(WRAP, WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0, 0, 16));
        root.addView(Ui.button(ctx, "DONE", Icons.CHECK, 0, v -> router.back()), Ui.flpm(Ui.dp(130), WRAP, Gravity.TOP | Gravity.START, 20, 14, 0, 0));
        root.setTag(new Object[]{name, tag, bars, swatch, dr, idx});
        apply(root);
        return root;
    }

    private void apply(View root) {
        Object[] t = (Object[]) root.getTag();
        TextView name = (TextView) t[0], tag = (TextView) t[1], idx = (TextView) t[5];
        LinearLayout bars = (LinearLayout) t[2];
        View[] swatch = (View[]) t[3];
        TextView[] dr = (TextView[]) t[4];
        KartStats st = KartStats.get(settings.kart);
        name.setText(st.name);
        tag.setText(st.tagline);
        bars.removeAllViews();
        bars.addView(Ui.statBar(ctx, "Speed", st.speedBar(), 0xFFEF5350));
        bars.addView(Ui.statBar(ctx, "Acceleration", st.accelBar(), 0xFFFFA726));
        bars.addView(Ui.statBar(ctx, "Handling", st.handlingBar(), 0xFF66BB6A));
        bars.addView(Ui.statBar(ctx, "Toughness", st.toughBar(), 0xFF42A5F5));
        idx.setText((settings.kart + 1) + " / " + KartStats.COUNT);
        for (int i = 0; i < swatch.length; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(0xFF000000 | KartModels.PAINTS[i]);
            g.setStroke(Ui.dp(i == settings.paint ? 3 : 1.5f), i == settings.paint ? 0xFFFFFFFF : 0x66FFFFFF);
            swatch[i].setBackground(g);
        }
        for (int i = 0; i < dr.length; i++) {
            dr[i].setBackground(i == settings.driver ? Ui.rounded(Ui.ACCENT, 9) : Ui.roundedStroke(0x55000000, 9, Ui.STROKE, 1));
            dr[i].setTextColor(i == settings.driver ? 0xFF1A1000 : Ui.TEXT);
        }
        renderer.setMenuKart(settings.kart, settings.paint, settings.driver);
        router.saveSettings();
        router.afterProfileChange();
    }

    // ------------------------------------------------------------------ multiplayer menu

    public View mpMenu() {
        LinearLayout root = frame("Multiplayer", v -> router.back(), true);
        LinearLayout body = Ui.hbox(ctx);
        body.setPadding(Ui.dp(24), Ui.dp(6), Ui.dp(24), Ui.dp(20));
        LinearLayout left = Ui.card(ctx);
        left.addView(Ui.sectionTitle(ctx, "Your name"));
        left.addView(nameField(), Ui.lp(MATCH, WRAP));
        TextView hint = Ui.text(ctx, "Race against friends on the same Wi-Fi network or phone hotspot. No internet or server needed.", 13, Ui.DIM, false);
        left.addView(hint, Ui.lpm(WRAP, WRAP, 0, 14, 0, 0));
        body.addView(left, Ui.lpm(Ui.dp(300), MATCH, 0, 0, 16, 0));

        LinearLayout hostCard = bigCard(Icons.WIFI, "HOST GAME", "Create a lobby. Friends on your network can find and join it.", v -> router.startHostingAndShowLobby());
        LinearLayout joinCard = bigCard(Icons.PEOPLE, "JOIN GAME", "Find a lobby on your network or enter the host's IP address.", v -> router.go(Router.JOIN));
        body.addView(hostCard, Ui.lpm(0, MATCH, 0, 0, 16, 0));
        ((LinearLayout.LayoutParams) hostCard.getLayoutParams()).weight = 1f;
        body.addView(joinCard, Ui.lpw(0, MATCH, 1f));
        root.addView(body, Ui.lpw(MATCH, 0, 1f));
        return root;
    }

    private LinearLayout bigCard(int icon, String title, String desc, View.OnClickListener click) {
        LinearLayout c = Ui.card(ctx);
        c.setGravity(Gravity.CENTER);
        c.setBackground(Ui.roundedStroke(0xCC163352, 16, 0x44FFFFFF, 1.5f));
        c.addView(Ui.iconView(ctx, icon, 54, Ui.ACCENT));
        TextView t = Ui.text(ctx, title, 20, Ui.TEXT, true);
        t.setLetterSpacing(0.06f);
        c.addView(t, Ui.lpm(WRAP, WRAP, 0, 10, 0, 4));
        TextView d = Ui.text(ctx, desc, 13, Ui.DIM, false);
        d.setGravity(Gravity.CENTER);
        c.addView(d, Ui.lpm(Ui.dp(240), WRAP, 0, 0, 0, 12));
        c.setOnClickListener(click);
        return c;
    }

    // ------------------------------------------------------------------ join

    public final class JoinScreen {
        public final View view;
        private final LinearLayout list;
        private final TextView status, searching;
        private final EditText ip;

        JoinScreen() {
            LinearLayout root = frame("Join game", v -> router.back(), true);
            LinearLayout body = Ui.hbox(ctx);
            body.setPadding(Ui.dp(24), Ui.dp(6), Ui.dp(24), Ui.dp(20));
            LinearLayout left = Ui.card(ctx);
            LinearLayout head = Ui.hbox(ctx);
            head.addView(Ui.sectionTitle(ctx, "Games on your network"), Ui.lpw(0, WRAP, 1f));
            head.addView(Ui.iconButton(ctx, Icons.REFRESH, 34, v -> engine.startBrowsing()));
            left.addView(head);
            searching = Ui.text(ctx, "Searching... Make sure both phones use the same Wi-Fi or hotspot.", 13, Ui.DIM, false);
            left.addView(searching, Ui.lpm(WRAP, WRAP, 0, 4, 0, 8));
            ScrollView sv = new ScrollView(ctx);
            list = Ui.vbox(ctx);
            sv.addView(list);
            left.addView(sv, Ui.lpw(MATCH, 0, 1f));
            body.addView(left, Ui.lpm(0, MATCH, 0, 0, 16, 0));
            ((LinearLayout.LayoutParams) left.getLayoutParams()).weight = 1f;

            LinearLayout right = Ui.card(ctx);
            right.addView(Ui.sectionTitle(ctx, "Enter IP address"));
            ip = new EditText(ctx);
            ip.setText(settings.lastIp);
            ip.setHint("192.168.43.1");
            ip.setHintTextColor(Ui.DIM);
            ip.setTextColor(Ui.TEXT);
            ip.setTextSize(16);
            ip.setSingleLine(true);
            ip.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            ip.setImeOptions(EditorInfo.IME_ACTION_DONE);
            ip.setBackground(Ui.roundedStroke(0x66000000, 10, Ui.STROKE, 1));
            ip.setPadding(Ui.dp(14), Ui.dp(10), Ui.dp(14), Ui.dp(10));
            right.addView(ip, Ui.lp(MATCH, WRAP));
            right.addView(Ui.button(ctx, "CONNECT", Icons.WIFI, 0, v -> connectManual()), Ui.lpm(MATCH, WRAP, 0, 12, 0, 0));
            status = Ui.text(ctx, "", 13, Ui.BAD, false);
            right.addView(status, Ui.lpm(WRAP, WRAP, 0, 10, 0, 0));
            TextView tip = Ui.text(ctx, "Tip: when a phone is the hotspot, its address is usually 192.168.43.1. The host sees it in the lobby screen.", 12, Ui.DIM, false);
            right.addView(tip, Ui.lpm(WRAP, WRAP, 0, 14, 0, 0));
            body.addView(right, Ui.lp(Ui.dp(300), MATCH));
            root.addView(body, Ui.lpw(MATCH, 0, 1f));
            view = root;
        }

        private void connectManual() {
            String t = ip.getText().toString().trim();
            if (t.length() == 0) { status.setText("Enter the host's IP address."); return; }
            String host = t;
            int port = NetConst.TCP_PORT;
            int colon = t.indexOf(':');
            if (colon > 0) {
                host = t.substring(0, colon);
                try { port = Integer.parseInt(t.substring(colon + 1)); } catch (NumberFormatException e) { status.setText("Invalid port."); return; }
            }
            status.setText("");
            router.joinHost(host, port);
        }

        public void setStatus(String s) { status.setText(s); }

        public void setHosts(List<Discovery.HostInfo> hosts) {
            list.removeAllViews();
            searching.setText(hosts.isEmpty() ? "Searching... Make sure both phones use the same Wi-Fi or hotspot." : "Tap a game to join.");
            for (final Discovery.HostInfo h : hosts) {
                LinearLayout row = Ui.hbox(ctx);
                row.setBackground(Ui.roundedStroke(0x55000000, 10, Ui.STROKE, 1));
                row.setPadding(Ui.dp(12), Ui.dp(10), Ui.dp(12), Ui.dp(10));
                row.addView(Ui.iconView(ctx, Icons.WIFI, 26, Ui.TEAL));
                LinearLayout info = Ui.vbox(ctx);
                info.setPadding(Ui.dp(12), 0, 0, 0);
                info.addView(Ui.text(ctx, h.name, 16, Ui.TEXT, true));
                info.addView(Ui.text(ctx, Tracks.get(h.track).name + "  |  " + h.laps + " laps  |  " + h.players + "/" + h.max + " players  |  " + h.address, 12, Ui.DIM, false));
                row.addView(info, Ui.lpw(0, WRAP, 1f));
                if (h.inRace) row.addView(Ui.text(ctx, "In race", 13, Ui.DIM, true));
                else row.addView(Ui.button(ctx, "JOIN", -1, 0, v -> router.joinHost(h.address, h.tcpPort)));
                list.addView(row, Ui.lpm(MATCH, WRAP, 0, 0, 0, 8));
            }
        }
    }

    public JoinScreen join() { return new JoinScreen(); }

    // ------------------------------------------------------------------ lobby

    public final class LobbyScreen {
        public final View view;
        private final LinearLayout players, settingsBox;
        private final TextView addr, title;
        private final LinearLayout actions;
        private boolean amHost;
        private int mySlot;
        private boolean ready;
        private Msg.Lobby last;
        private RaceSettings shown;
        private boolean shownHost;
        private boolean built;

        LobbyScreen() {
            LinearLayout root = frame("Lobby", v -> router.leaveLobby(), true);
            title = (TextView) ((LinearLayout) root.getChildAt(0)).getChildAt(2);
            LinearLayout body = Ui.hbox(ctx);
            body.setPadding(Ui.dp(24), Ui.dp(4), Ui.dp(24), Ui.dp(14));
            LinearLayout left = Ui.card(ctx);
            left.addView(Ui.sectionTitle(ctx, "Players"));
            ScrollView sv = new ScrollView(ctx);
            players = Ui.vbox(ctx);
            sv.addView(players);
            left.addView(sv, Ui.lpw(MATCH, 0, 1f));
            addr = Ui.text(ctx, "", 12, Ui.DIM, false);
            left.addView(addr, Ui.lpm(WRAP, WRAP, 0, 8, 0, 0));
            body.addView(left, Ui.lpm(0, MATCH, 0, 0, 14, 0));
            ((LinearLayout.LayoutParams) left.getLayoutParams()).weight = 1.25f;

            LinearLayout right = Ui.vbox(ctx);
            LinearLayout sc = Ui.card(ctx);
            sc.addView(Ui.sectionTitle(ctx, "Race"));
            settingsBox = Ui.vbox(ctx);
            ScrollView ssv = new ScrollView(ctx);
            ssv.addView(settingsBox);
            sc.addView(ssv, Ui.lpw(MATCH, 0, 1f));
            right.addView(sc, Ui.lpw(MATCH, 0, 1f));
            actions = Ui.hbox(ctx);
            right.addView(actions, Ui.lpm(MATCH, WRAP, 0, 10, 0, 0));
            body.addView(right, Ui.lp(Ui.dp(320), MATCH));
            root.addView(body, Ui.lpw(MATCH, 0, 1f));
            view = root;
        }

        public boolean isReady() { return ready; }

        public void update(Msg.Lobby l, int mySlot, boolean amHost) {
            this.last = l; this.mySlot = mySlot; this.amHost = amHost;
            title.setText(amHost ? "HOSTING" : "LOBBY");
            if (amHost) {
                StringBuilder sb = new StringBuilder("Others can join with: ");
                List<String> ips = NetUtil.localAddresses();
                if (ips.isEmpty()) sb.append("(no network found - turn on Wi-Fi or hotspot)");
                for (int i = 0; i < ips.size(); i++) { if (i > 0) sb.append("  or  "); sb.append(ips.get(i)); }
                int port = engine.hostPort();
                if (port != NetConst.TCP_PORT && port != 0) sb.append("  (port ").append(port).append(")");
                addr.setText(sb.toString());
            } else addr.setText("Connected to the host. Press Ready when you are set.");
            rebuildPlayers(l);
            if (!built || shownHost != amHost || !same(shown, l.settings)) rebuildSettings(l.settings);
            rebuildActions();
        }

        private void rebuildPlayers(Msg.Lobby l) {
            players.removeAllViews();
            for (final Msg.PlayerInfo p : l.players) {
                LinearLayout row = Ui.hbox(ctx);
                row.setBackground(Ui.roundedStroke(p.slot == mySlot ? 0x66284A73 : 0x44000000, 10, Ui.STROKE, 1));
                row.setPadding(Ui.dp(10), Ui.dp(8), Ui.dp(10), Ui.dp(8));
                View dot = new View(ctx);
                GradientDrawable g = new GradientDrawable();
                g.setShape(GradientDrawable.OVAL);
                g.setColor(0xFF000000 | KartModels.PAINTS[Math.floorMod(p.color, KartModels.PAINTS.length)]);
                g.setStroke(Ui.dp(2), 0xFFFFFFFF);
                dot.setBackground(g);
                row.addView(dot, Ui.lp(Ui.dp(26), Ui.dp(26)));
                LinearLayout info = Ui.vbox(ctx);
                info.setPadding(Ui.dp(12), 0, 0, 0);
                LinearLayout nm = Ui.hbox(ctx);
                nm.addView(Ui.text(ctx, p.name + (p.slot == mySlot ? "  (you)" : ""), 15, Ui.TEXT, true));
                if (p.host) { nm.addView(Ui.space(ctx, 6, 1)); nm.addView(Ui.iconView(ctx, Icons.CROWN, 16, Ui.ACCENT)); }
                info.addView(nm);
                info.addView(Ui.text(ctx, KartStats.get(p.kart).name + (p.host || p.ping <= 0 ? "" : "  |  " + p.ping + " ms"), 12, Ui.DIM, false));
                row.addView(info, Ui.lpw(0, WRAP, 1f));
                if (p.ready || p.host) row.addView(Ui.iconView(ctx, Icons.CHECK, 22, Ui.OK));
                else row.addView(Ui.text(ctx, "not ready", 12, Ui.DIM, false));
                if (amHost && !p.host) {
                    row.addView(Ui.space(ctx, 8, 1));
                    row.addView(Ui.iconButton(ctx, Icons.CLOSE, 30, v -> engine.hostKick(p.slot)));
                }
                players.addView(row, Ui.lpm(MATCH, WRAP, 0, 0, 0, 8));
            }
        }

        private boolean same(RaceSettings a, RaceSettings b) {
            return a != null && a.track == b.track && a.laps == b.laps && a.aiCount == b.aiCount && a.difficulty == b.difficulty && a.items == b.items;
        }

        private void rebuildSettings(final RaceSettings s) {
            settingsBox.removeAllViews();
            built = true;
            shownHost = amHost;
            shown = s;
            if (amHost) {
                final RaceSettings cur = s.copy();
                shown = cur;
                settingsBox.addView(Ui.text(ctx, "Track", 14, Ui.TEXT, false));
                final String[] names = new String[Tracks.COUNT];
                for (int i = 0; i < names.length; i++) names[i] = Tracks.get(i).name.split(" ")[0];
                settingsBox.addView(Ui.chips(ctx, names, cur.track, n -> { cur.track = n; settings.track = n; engine.hostSetSettings(cur); router.saveSettings(); }), Ui.lpm(MATCH, WRAP, 0, 4, 0, 6));
                settingsBox.addView(Ui.stepper(ctx, "Laps", 1, 9, cur.laps, n -> { cur.laps = n; settings.laps = n; engine.hostSetSettings(cur); router.saveSettings(); }));
                settingsBox.addView(Ui.stepper(ctx, "AI opponents", 0, 7, cur.aiCount, n -> { cur.aiCount = n; settings.aiCount = n; engine.hostSetSettings(cur); router.saveSettings(); }));
                settingsBox.addView(Ui.text(ctx, "AI difficulty", 14, Ui.TEXT, false), Ui.lpm(WRAP, WRAP, 0, 6, 0, 6));
                settingsBox.addView(Ui.chips(ctx, new String[]{"Easy", "Normal", "Hard"}, cur.difficulty, n -> { cur.difficulty = n; settings.difficulty = n; engine.hostSetSettings(cur); router.saveSettings(); }));
                settingsBox.addView(Ui.toggle(ctx, "Power-ups", cur.items, b -> { cur.items = b; settings.items = b; engine.hostSetSettings(cur); router.saveSettings(); }), Ui.lpm(MATCH, WRAP, 0, 6, 0, 0));
            } else {
                settingsBox.addView(Ui.text(ctx, Tracks.get(s.track).name, 18, Ui.TEXT, true));
                settingsBox.addView(Ui.text(ctx, Tracks.get(s.track).tagline, 12, Ui.DIM, false), Ui.lpm(WRAP, WRAP, 0, 2, 0, 10));
                settingsBox.addView(Ui.text(ctx, s.laps + " laps  |  " + s.aiCount + " AI opponents  |  " + new String[]{"Easy", "Normal", "Hard"}[Math.max(0, Math.min(2, s.difficulty))] + " AI", 13, Ui.TEXT, false));
                settingsBox.addView(Ui.text(ctx, "Power-ups: " + (s.items ? "on" : "off"), 13, Ui.TEXT, false), Ui.lpm(WRAP, WRAP, 0, 4, 0, 0));
                settingsBox.addView(Ui.text(ctx, "Only the host can change the race settings.", 12, Ui.DIM, false), Ui.lpm(WRAP, WRAP, 0, 12, 0, 0));
            }
        }

        private void rebuildActions() {
            actions.removeAllViews();
            actions.addView(Ui.button(ctx, "GARAGE", Icons.WRENCH, 1, v -> router.go(Router.GARAGE)), Ui.lpm(0, WRAP, 0, 0, 8, 0));
            ((LinearLayout.LayoutParams) actions.getChildAt(0).getLayoutParams()).weight = 1f;
            if (amHost) {
                actions.addView(Ui.button(ctx, "START", Icons.FLAG, 0, v -> router.hostStart()), Ui.lpw(0, WRAP, 1.3f));
            } else {
                boolean me = false;
                if (last != null) for (Msg.PlayerInfo p : last.players) if (p.slot == mySlot) me = p.ready;
                ready = me;
                actions.addView(Ui.button(ctx, ready ? "READY" : "NOT READY", ready ? Icons.CHECK : Icons.CLOSE, ready ? 0 : 1, v -> { ready = !ready; engine.clientUpdate(ready); }), Ui.lpw(0, WRAP, 1.3f));
            }
        }
    }

    public LobbyScreen lobby() { return new LobbyScreen(); }

    // ------------------------------------------------------------------ settings

    public View settingsScreen() {
        LinearLayout root = frame("Settings", v -> router.back(), true);
        ScrollView sv = new ScrollView(ctx);
        LinearLayout col = Ui.vbox(ctx);
        col.setPadding(Ui.dp(24), Ui.dp(4), Ui.dp(24), Ui.dp(24));
        sv.addView(col);

        LinearLayout row = Ui.hbox(ctx);
        row.setGravity(Gravity.TOP);
        LinearLayout c1 = Ui.vbox(ctx), c2 = Ui.vbox(ctx);
        row.addView(c1, Ui.lpm(0, WRAP, 0, 0, 14, 0));
        ((LinearLayout.LayoutParams) c1.getLayoutParams()).weight = 1f;
        row.addView(c2, Ui.lpw(0, WRAP, 1f));

        LinearLayout player = Ui.card(ctx);
        player.addView(Ui.sectionTitle(ctx, "Player"));
        player.addView(nameField(), Ui.lp(MATCH, WRAP));
        c1.addView(player, Ui.lpm(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout gfx = Ui.card(ctx);
        gfx.addView(Ui.sectionTitle(ctx, "Graphics"));
        gfx.addView(Ui.text(ctx, "Quality preset", 14, Ui.TEXT, false), Ui.lpm(WRAP, WRAP, 0, 2, 0, 6));
        gfx.addView(Ui.chips(ctx, new String[]{"Low", "Medium", "High"}, settings.quality, n -> { settings.quality = n; settings.scalePct = 0; router.applyGraphics(); }));
        gfx.addView(Ui.toggle(ctx, "Shadows", settings.shadows, b -> { settings.shadows = b; router.applyGraphics(); }), Ui.lpm(MATCH, WRAP, 0, 8, 0, 0));
        gfx.addView(Ui.text(ctx, "Resolution", 14, Ui.TEXT, false), Ui.lpm(WRAP, WRAP, 0, 6, 0, 6));
        final int[] pcts = {0, 100, 85, 70, 55};
        int sel = 0;
        for (int i = 0; i < pcts.length; i++) if (pcts[i] == settings.scalePct) sel = i;
        gfx.addView(Ui.chips(ctx, new String[]{"Auto", "100%", "85%", "70%", "55%"}, sel, n -> { settings.scalePct = pcts[n]; router.applyGraphics(); }));
        gfx.addView(Ui.text(ctx, "Frame rate limit", 14, Ui.TEXT, false), Ui.lpm(WRAP, WRAP, 0, 10, 0, 6));
        gfx.addView(Ui.chips(ctx, new String[]{"30 FPS", "60 FPS"}, settings.fpsCap <= 30 ? 0 : 1, n -> { settings.fpsCap = n == 0 ? 30 : 60; router.applyGraphics(); }));
        gfx.addView(Ui.toggle(ctx, "Auto-lower resolution if slow", settings.autoQuality, b -> { settings.autoQuality = b; router.applyGraphics(); }), Ui.lpm(MATCH, WRAP, 0, 8, 0, 0));
        gfx.addView(Ui.toggle(ctx, "Show FPS", settings.showFps, b -> { settings.showFps = b; router.saveSettings(); }));
        c1.addView(gfx, Ui.lp(MATCH, WRAP));

        LinearLayout cam = Ui.card(ctx);
        cam.addView(Ui.sectionTitle(ctx, "Camera"));
        cam.addView(Ui.chips(ctx, new String[]{"Close", "Normal", "Far"}, settings.cameraMode, n -> { settings.cameraMode = n; router.saveSettings(); }));
        cam.addView(Ui.slider(ctx, "Field of view", 50, 85, settings.fov, "\u00B0", n -> { settings.fov = n; router.saveSettings(); }));
        cam.addView(Ui.toggle(ctx, "Camera shake", settings.camShake, b -> { settings.camShake = b; router.saveSettings(); }));
        c2.addView(cam, Ui.lpm(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout snd = Ui.card(ctx);
        snd.addView(Ui.sectionTitle(ctx, "Sound"));
        snd.addView(Ui.toggle(ctx, "Sound effects", settings.sound, b -> { settings.sound = b; router.saveSettings(); if (b) com.kartracer.audio.Sfx.click(); }));
        snd.addView(Ui.slider(ctx, "Volume", 10, 100, settings.sfxVolume, "%", n -> { settings.sfxVolume = n; router.saveSettings(); }));
        c2.addView(snd, Ui.lpm(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout ctl = Ui.card(ctx);
        ctl.addView(Ui.sectionTitle(ctx, "Controls"));
        ctl.addView(Ui.text(ctx, "Steering", 14, Ui.TEXT, false), Ui.lpm(WRAP, WRAP, 0, 2, 0, 6));
        ctl.addView(Ui.chips(ctx, new String[]{"Buttons", "Tilt", "Slide"}, settings.steerMode, n -> { settings.steerMode = n; router.saveSettings(); }));
        ctl.addView(Ui.toggle(ctx, "Auto accelerate", settings.autoGas, b -> { settings.autoGas = b; router.saveSettings(); }), Ui.lpm(MATCH, WRAP, 0, 6, 0, 0));
        ctl.addView(Ui.slider(ctx, "Tilt sensitivity", 50, 200, settings.tiltSens, "%", n -> { settings.tiltSens = n; router.saveSettings(); }));
        ctl.addView(Ui.slider(ctx, "Button size", 70, 140, settings.buttonScale, "%", n -> { settings.buttonScale = n; router.saveSettings(); }));
        ctl.addView(Ui.slider(ctx, "Button opacity", 30, 100, settings.controlOpacity, "%", n -> { settings.controlOpacity = n; router.saveSettings(); }));
        ctl.addView(Ui.toggle(ctx, "Left-handed layout", settings.leftHanded, b -> { settings.leftHanded = b; settings.resetLayout(); router.saveSettings(); }));
        ctl.addView(Ui.toggle(ctx, "Vibration feedback", settings.haptics, b -> { settings.haptics = b; router.saveSettings(); }));
        LinearLayout br = Ui.hbox(ctx);
        br.addView(Ui.button(ctx, "EDIT LAYOUT", Icons.EDIT, 1, v -> router.editLayout()), Ui.lpm(0, WRAP, 0, 0, 8, 0));
        ((LinearLayout.LayoutParams) br.getChildAt(0).getLayoutParams()).weight = 1f;
        br.addView(Ui.button(ctx, "RESET", Icons.REFRESH, 1, v -> { settings.resetLayout(); router.saveSettings(); router.toast("Layout reset"); }), Ui.lpw(0, WRAP, 1f));
        ctl.addView(br, Ui.lpm(MATCH, WRAP, 0, 10, 0, 0));
        c2.addView(ctl, Ui.lpm(MATCH, WRAP, 0, 0, 0, 12));

        LinearLayout dg = Ui.card(ctx);
        dg.addView(Ui.sectionTitle(ctx, "Diagnostics"));
        dg.addView(Ui.text(ctx, "If something goes wrong, open the log and send it to the developer.", 12, Ui.DIM, false), Ui.lpm(WRAP, WRAP, 0, 0, 0, 8));
        dg.addView(Ui.button(ctx, "VIEW LOG", Icons.BUG, 1, v -> router.go(Router.DIAG)), Ui.lp(MATCH, WRAP));
        c2.addView(dg, Ui.lp(MATCH, WRAP));

        col.addView(row);
        root.addView(sv, Ui.lpw(MATCH, 0, 1f));
        return root;
    }

    public View diag() {
        LinearLayout root = frame("Diagnostics log", v -> router.back(), true);
        LinearLayout bar = Ui.hbox(ctx);
        bar.setPadding(Ui.dp(24), 0, Ui.dp(24), Ui.dp(8));
        bar.addView(Ui.button(ctx, "COPY", Icons.COPY, 1, v -> router.copyLog()), Ui.lpm(0, WRAP, 0, 0, 8, 0));
        bar.addView(Ui.button(ctx, "SAVE TO DOWNLOADS", Icons.SAVE, 1, v -> {
            String where = router.exportLog();
            router.toast(where == null ? "Could not save the log" : "Saved to " + where);
        }), Ui.lpm(0, WRAP, 0, 0, 8, 0));
        bar.addView(Ui.button(ctx, "SHARE", Icons.SHARE, 1, v -> router.shareLog()), Ui.lp(WRAP, WRAP));
        for (int i = 0; i < 2; i++) ((LinearLayout.LayoutParams) bar.getChildAt(i).getLayoutParams()).weight = 0f;
        root.addView(bar, Ui.lp(MATCH, WRAP));
        ScrollView sv = new ScrollView(ctx);
        TextView t = new TextView(ctx);
        t.setTypeface(Typeface.MONOSPACE);
        t.setTextSize(10.5f);
        t.setTextColor(0xFFC8E6C9);
        t.setText(DiagLog.readAll());
        t.setTextIsSelectable(true);
        t.setPadding(Ui.dp(24), Ui.dp(4), Ui.dp(24), Ui.dp(24));
        sv.addView(t);
        root.addView(sv, Ui.lpw(MATCH, 0, 1f));
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
        return root;
    }

    // ------------------------------------------------------------------ results / pause / loading

    public View results(List<ResultRow> rows, final boolean multiplayer, final boolean isHost, int localSlot) {
        FrameLayout root = new FrameLayout(ctx);
        root.setBackgroundColor(0xB0030A14);
        LinearLayout card = Ui.card(ctx);
        LinearLayout head = Ui.hbox(ctx);
        head.addView(Ui.iconView(ctx, Icons.TROPHY, 28, Ui.ACCENT));
        TextView t = Ui.text(ctx, "  RESULTS", 22, Ui.TEXT, true);
        t.setLetterSpacing(0.08f);
        head.addView(t);
        card.addView(head, Ui.lpm(WRAP, WRAP, 0, 0, 0, 8));
        ScrollView sv = new ScrollView(ctx);
        LinearLayout list = Ui.vbox(ctx);
        for (ResultRow r : rows) {
            LinearLayout row = Ui.hbox(ctx);
            boolean me = r.slot == localSlot;
            row.setBackground(me ? Ui.roundedStroke(0x66E6A02B, 10, Ui.ACCENT, 1.5f) : Ui.rounded(0x33000000, 10));
            row.setPadding(Ui.dp(12), Ui.dp(7), Ui.dp(12), Ui.dp(7));
            TextView pl = Ui.text(ctx, String.valueOf(r.place), 18, r.place == 1 ? Ui.ACCENT : Ui.TEXT, true);
            row.addView(pl, Ui.lp(Ui.dp(34), WRAP));
            row.addView(Ui.text(ctx, r.name + (r.ai ? "  (AI)" : ""), 15, Ui.TEXT, me), Ui.lpw(0, WRAP, 1f));
            row.addView(Ui.text(ctx, r.timeMs < 0 ? "DNF" : fmtTime(r.timeMs), 15, r.timeMs < 0 ? Ui.DIM : Ui.TEXT, false));
            list.addView(row, Ui.lpm(MATCH, WRAP, 0, 0, 0, 6));
        }
        sv.addView(list);
        card.addView(sv, Ui.lpw(MATCH, 0, 1f));
        LinearLayout btn = Ui.hbox(ctx);
        if (!multiplayer) btn.addView(Ui.button(ctx, "RACE AGAIN", Icons.REFRESH, 0, v -> router.restart()), Ui.lpm(0, WRAP, 0, 0, 8, 0));
        else if (isHost) btn.addView(Ui.button(ctx, "BACK TO LOBBY", Icons.PEOPLE, 0, v -> router.lobbyRaceAgain()), Ui.lpm(0, WRAP, 0, 0, 8, 0));
        else btn.addView(Ui.text(ctx, "Waiting for the host...", 13, Ui.DIM, false), Ui.lpm(0, WRAP, 0, 0, 8, 0));
        ((LinearLayout.LayoutParams) btn.getChildAt(0).getLayoutParams()).weight = 1f;
        btn.addView(Ui.button(ctx, "MAIN MENU", Icons.HOME, 1, v -> router.quit()), Ui.lpw(0, WRAP, 1f));
        card.addView(btn, Ui.lpm(MATCH, WRAP, 0, 8, 0, 0));
        root.addView(card, Ui.flp(Ui.dp(460), MATCH, Gravity.CENTER));
        ((FrameLayout.LayoutParams) card.getLayoutParams()).setMargins(0, Ui.dp(14), 0, Ui.dp(14));
        return root;
    }

    public View pause(boolean multiplayer) {
        FrameLayout root = new FrameLayout(ctx);
        root.setBackgroundColor(0x99030A14);
        LinearLayout card = Ui.card(ctx);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView t = Ui.text(ctx, multiplayer ? "MENU" : "PAUSED", 22, Ui.TEXT, true);
        t.setLetterSpacing(0.1f);
        card.addView(t, Ui.lpm(WRAP, WRAP, 0, 0, 0, 12));
        card.addView(Ui.button(ctx, "RESUME", Icons.PLAY, 0, v -> router.resume()), Ui.lpm(MATCH, WRAP, 0, 0, 0, 8));
        if (!multiplayer) card.addView(Ui.button(ctx, "RESTART", Icons.REFRESH, 1, v -> router.restart()), Ui.lpm(MATCH, WRAP, 0, 0, 0, 8));
        card.addView(Ui.button(ctx, multiplayer ? "LEAVE RACE" : "QUIT TO MENU", Icons.HOME, 2, v -> router.quit()), Ui.lp(MATCH, WRAP));
        root.addView(card, Ui.flp(Ui.dp(260), WRAP, Gravity.CENTER));
        return root;
    }

    /** Spinner + message. */
    public final class Loading extends FrameLayout {
        private final TextView msg;
        private final View spinner;

        Loading() {
            super(ctx);
            setBackgroundColor(0xE6050E1A);
            LinearLayout c = Ui.vbox(ctx);
            c.setGravity(Gravity.CENTER);
            spinner = new View(ctx) {
                private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
                private final android.graphics.RectF r = new android.graphics.RectF();
                @Override protected void onMeasure(int w, int h) { setMeasuredDimension(Ui.dp(56), Ui.dp(56)); }
                @Override protected void onDraw(Canvas cv) {
                    float a = (System.currentTimeMillis() % 1000) / 1000f * 360f;
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Ui.dp(5)); p.setStrokeCap(Paint.Cap.ROUND);
                    p.setColor(0x33FFFFFF);
                    r.set(Ui.dp(6), Ui.dp(6), Ui.dp(50), Ui.dp(50));
                    cv.drawArc(r, 0, 360, false, p);
                    p.setColor(Ui.ACCENT);
                    cv.drawArc(r, a, 100, false, p);
                    postInvalidateOnAnimation();
                }
            };
            c.addView(spinner);
            msg = Ui.text(ctx, "Loading...", 16, Ui.TEXT, true);
            c.addView(msg, Ui.lpm(WRAP, WRAP, 0, 14, 0, 0));
            addView(c, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER));
            setClickable(true);
        }

        public void setMessage(String m) { msg.setText(m); }
    }

    public Loading loading() { return new Loading(); }
}
