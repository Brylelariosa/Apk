package com.kartracer.util;

/** Packed colors: int = A<<24 | B<<16 | G<<8 | R, i.e. bytes R,G,B,A in little endian memory. */
public final class Col {
    private Col() {}

    public static int rgba(int r, int g, int b, int a) { return (a & 255) << 24 | (b & 255) << 16 | (g & 255) << 8 | (r & 255); }
    public static int rgb(int r, int g, int b) { return rgba(r, g, b, 255); }
    /** From 0xRRGGBB. */
    public static int hex(int rrggbb) { return rgba((rrggbb >> 16) & 255, (rrggbb >> 8) & 255, rrggbb & 255, 255); }
    public static int r(int c) { return c & 255; }
    public static int g(int c) { return (c >> 8) & 255; }
    public static int b(int c) { return (c >> 16) & 255; }
    public static int a(int c) { return (c >>> 24) & 255; }
    public static int withAlpha(int c, int a) { return (c & 0x00FFFFFF) | ((a & 255) << 24); }

    public static int mix(int c0, int c1, float t) {
        t = MathX.sat(t);
        return rgba((int) (r(c0) + (r(c1) - r(c0)) * t), (int) (g(c0) + (g(c1) - g(c0)) * t),
                (int) (b(c0) + (b(c1) - b(c0)) * t), (int) (a(c0) + (a(c1) - a(c0)) * t));
    }

    /** Scales rgb, keeps alpha. */
    public static int scale(int c, float f) {
        return rgba(MathX.clamp((int) (r(c) * f), 0, 255), MathX.clamp((int) (g(c) * f), 0, 255),
                MathX.clamp((int) (b(c) * f), 0, 255), a(c));
    }

    /** To Android ARGB int (for Bitmap / Canvas). */
    public static int toArgb(int c) { return (a(c) << 24) | (r(c) << 16) | (g(c) << 8) | b(c); }
}
