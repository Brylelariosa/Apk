package com.kartracer.net;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

/** Datagram codec: [short magic][byte type][payload]. */
final class Udp {
    private Udp() {}

    static byte[] encode(Msg m) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(128);
        DataOutputStream d = new DataOutputStream(bo);
        d.writeShort(NetConst.UDP_MAGIC);
        d.writeByte(m.type());
        m.write(d);
        d.flush();
        return bo.toByteArray();
    }

    static Msg decode(byte[] b, int len) throws IOException {
        DataInputStream d = new DataInputStream(new ByteArrayInputStream(b, 0, len));
        if (d.readShort() != (short) NetConst.UDP_MAGIC) return null;
        int type = d.readByte() & 255;
        return Msg.read(type, d);
    }
}
