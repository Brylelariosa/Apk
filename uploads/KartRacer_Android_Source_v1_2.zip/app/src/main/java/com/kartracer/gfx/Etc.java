package com.kartracer.gfx;

/**
 * Small ETC1-compatible texture encoder (individual mode blocks, decodable as GL_COMPRESSED_RGB8_ETC2 on every OpenGL ES 3.0 GPU).
 * 4 bits per pixel; used for the procedural textures to cut texture memory and bandwidth.
 */
public final class Etc {
    private Etc() {}

    private static final int[][] MOD = {{2, 8, -2, -8}, {5, 17, -5, -17}, {9, 29, -9, -29}, {13, 42, -13, -42},
            {18, 60, -18, -60}, {24, 80, -24, -80}, {33, 106, -33, -106}, {47, 183, -47, -183}};

    /** Mip chain (level 0 first) down to 1x1, box filtered. Each entry is {w, h, rgbaBytes...} via the arrays below. */
    public static final class Level {
        public final int w, h;
        public final byte[] rgba;
        public byte[] etc;
        Level(int w, int h, byte[] rgba) { this.w = w; this.h = h; this.rgba = rgba; }
    }

    public static Level[] buildChain(byte[] rgba, int w, int h) {
        int n = 1;
        for (int s = Math.max(w, h); s > 1; s >>= 1) n++;
        Level[] out = new Level[n];
        out[0] = new Level(w, h, rgba);
        for (int i = 1; i < n; i++) {
            Level p = out[i - 1];
            int nw = Math.max(1, p.w / 2), nh = Math.max(1, p.h / 2);
            byte[] d = new byte[nw * nh * 4];
            for (int y = 0; y < nh; y++) for (int x = 0; x < nw; x++) {
                for (int c = 0; c < 4; c++) {
                    int sum = 0;
                    for (int dy = 0; dy < 2; dy++) for (int dx = 0; dx < 2; dx++) {
                        int sx = Math.min(p.w - 1, x * 2 + dx), sy = Math.min(p.h - 1, y * 2 + dy);
                        sum += p.rgba[(sy * p.w + sx) * 4 + c] & 255;
                    }
                    d[(y * nw + x) * 4 + c] = (byte) ((sum + 2) >> 2);
                }
            }
            out[i] = new Level(nw, nh, d);
        }
        for (Level l : out) l.etc = encode(l.rgba, l.w, l.h);
        return out;
    }

    private static int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    /** Encodes RGBA (alpha ignored) into 8-byte blocks, rows of blocks top to bottom. Dimensions need not be multiples of 4. */
    public static synchronized byte[] encode(byte[] rgba, int w, int h) {
        int bw = (w + 3) / 4, bh = (h + 3) / 4;
        byte[] out = new byte[bw * bh * 8];
        int[] px = new int[16 * 3];
        for (int by = 0; by < bh; by++) for (int bx = 0; bx < bw; bx++) {
            for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) {
                int sx = Math.min(w - 1, bx * 4 + x), sy = Math.min(h - 1, by * 4 + y);
                int o = (sy * w + sx) * 4, k = (y * 4 + x) * 3;
                px[k] = rgba[o] & 255; px[k + 1] = rgba[o + 1] & 255; px[k + 2] = rgba[o + 2] & 255;
            }
            encodeBlock(px, out, (by * bw + bx) * 8);
        }
        return out;
    }

    // result scratch for sub-block fitting
    private static int fitErr, fitTable, fitBase0, fitBase1, fitBase2;
    private static final int[] fitIdx = new int[8];

    /** Fits one 8 pixel sub-block. ids = pixel numbers (y*4+x). */
    private static void fit(int[] px, int[] ids) {
        int r = 0, g = 0, b = 0;
        for (int i = 0; i < 8; i++) { r += px[ids[i] * 3]; g += px[ids[i] * 3 + 1]; b += px[ids[i] * 3 + 2]; }
        int q0 = Math.min(15, (int) Math.round(r / 8.0 / 17.0)), q1 = Math.min(15, (int) Math.round(g / 8.0 / 17.0)), q2 = Math.min(15, (int) Math.round(b / 8.0 / 17.0));
        int b0 = q0 * 17, b1 = q1 * 17, b2 = q2 * 17;
        int bestErr = Integer.MAX_VALUE, bestT = 0;
        int[] tmp = new int[8];
        for (int t = 0; t < 8; t++) {
            int err = 0;
            for (int i = 0; i < 8; i++) {
                int pr = px[ids[i] * 3], pg = px[ids[i] * 3 + 1], pb = px[ids[i] * 3 + 2];
                int be = Integer.MAX_VALUE, bi = 0;
                for (int m = 0; m < 4; m++) {
                    int d = MOD[t][m];
                    int er = clamp(b0 + d) - pr, eg = clamp(b1 + d) - pg, eb = clamp(b2 + d) - pb;
                    int e = er * er + eg * eg + eb * eb;
                    if (e < be) { be = e; bi = m; }
                }
                err += be; tmp[i] = bi;
            }
            if (err < bestErr) { bestErr = err; bestT = t; System.arraycopy(tmp, 0, fitIdx, 0, 8); }
        }
        fitErr = bestErr; fitTable = bestT; fitBase0 = q0; fitBase1 = q1; fitBase2 = q2;
    }

    private static final int[][][] SPLIT = new int[2][2][8];
    static {
        for (int flip = 0; flip < 2; flip++) {
            int a = 0, b = 0;
            for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) {
                boolean first = flip == 0 ? x < 2 : y < 2;
                if (first) SPLIT[flip][0][a++] = y * 4 + x; else SPLIT[flip][1][b++] = y * 4 + x;
            }
        }
    }

    private static void encodeBlock(int[] px, byte[] out, int off) {
        int bestErr = Integer.MAX_VALUE;
        int[] bestIdx = new int[16];
        int bq0 = 0, bq1 = 0, bq2 = 0, bq3 = 0, bq4 = 0, bq5 = 0, bt1 = 0, bt2 = 0, bflip = 0;
        for (int flip = 0; flip < 2; flip++) {
            fit(px, SPLIT[flip][0]);
            int e1 = fitErr, t1 = fitTable, r1 = fitBase0, g1 = fitBase1, b1 = fitBase2;
            int[] i1 = fitIdx.clone();
            fit(px, SPLIT[flip][1]);
            int e2 = fitErr, t2 = fitTable, r2 = fitBase0, g2 = fitBase1, b2 = fitBase2;
            if (e1 + e2 < bestErr) {
                bestErr = e1 + e2;
                for (int i = 0; i < 8; i++) { bestIdx[SPLIT[flip][0][i]] = i1[i]; bestIdx[SPLIT[flip][1][i]] = fitIdx[i]; }
                bq0 = r1; bq1 = r2; bq2 = g1; bq3 = g2; bq4 = b1; bq5 = b2; bt1 = t1; bt2 = t2; bflip = flip;
            }
        }
        out[off] = (byte) ((bq0 << 4) | bq1);
        out[off + 1] = (byte) ((bq2 << 4) | bq3);
        out[off + 2] = (byte) ((bq4 << 4) | bq5);
        out[off + 3] = (byte) ((bt1 << 5) | (bt2 << 2) | bflip);
        int msb = 0, lsb = 0;
        for (int y = 0; y < 4; y++) for (int x = 0; x < 4; x++) {
            int idx = bestIdx[y * 4 + x];
            int bit = x * 4 + y;
            if ((idx & 2) != 0) msb |= 1 << bit;
            if ((idx & 1) != 0) lsb |= 1 << bit;
        }
        out[off + 4] = (byte) (msb >> 8); out[off + 5] = (byte) msb;
        out[off + 6] = (byte) (lsb >> 8); out[off + 7] = (byte) lsb;
    }
}
