package com.kartracer.sim;

/** Thread safe bridge between the touch overlay (UI thread) and the game thread. */
public final class PlayerInput {
    public volatile float steer, throttle, brake;
    public volatile boolean drift, boost;
    private volatile boolean item, respawn;

    public void pressItem() { item = true; }
    public boolean takeItem() { boolean v = item; item = false; return v; }
    public void pressRespawn() { respawn = true; }
    public boolean takeRespawn() { boolean v = respawn; respawn = false; return v; }

    public void clear() { steer = 0f; throttle = 0f; brake = 0f; drift = false; boost = false; item = false; respawn = false; }
}
