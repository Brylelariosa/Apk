package com.kartracer.util;

/** Integer-hash value noise. Deterministic across platforms. */
public final class Noise {
    private Noise() {}

    public static float hash(int x, int y, int seed) {
        int h = x * 374761393 + y * 668265263 + seed * 1442695041;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFFFF) * (1f / 16777216f);
    }

    private static float fade(float t) { return t * t * t * (t * (t * 6f - 15f) + 10f); }

    /** Smooth value noise in [0,1]. */
    public static float value(float x, float y, int seed) {
        int ix = MathX.ifloor(x), iy = MathX.ifloor(y);
        float fx = fade(x - ix), fy = fade(y - iy);
        float a = hash(ix, iy, seed), b = hash(ix + 1, iy, seed);
        float c = hash(ix, iy + 1, seed), d = hash(ix + 1, iy + 1, seed);
        return MathX.lerp(MathX.lerp(a, b, fx), MathX.lerp(c, d, fx), fy);
    }

    /** Tileable value noise: lattice wraps every `period` cells. */
    public static float tile(float x, float y, int period, int seed) {
        int ix = MathX.ifloor(x), iy = MathX.ifloor(y);
        float fx = fade(x - ix), fy = fade(y - iy);
        int x0 = Math.floorMod(ix, period), x1 = Math.floorMod(ix + 1, period);
        int y0 = Math.floorMod(iy, period), y1 = Math.floorMod(iy + 1, period);
        float a = hash(x0, y0, seed), b = hash(x1, y0, seed);
        float c = hash(x0, y1, seed), d = hash(x1, y1, seed);
        return MathX.lerp(MathX.lerp(a, b, fx), MathX.lerp(c, d, fx), fy);
    }

    /** Fractal sum, roughly in [0,1]. */
    public static float fbm(float x, float y, int octaves, int seed) {
        float sum = 0f, amp = 0.5f, norm = 0f;
        for (int i = 0; i < octaves; i++) {
            sum += value(x, y, seed + i * 31) * amp;
            norm += amp;
            x *= 2.03f; y *= 2.03f; amp *= 0.5f;
        }
        return sum / norm;
    }

    /** Ridged variant in [0,1] (sharp crests). */
    public static float ridged(float x, float y, int octaves, int seed) {
        float sum = 0f, amp = 0.5f, norm = 0f;
        for (int i = 0; i < octaves; i++) {
            float n = 1f - Math.abs(value(x, y, seed + i * 17) * 2f - 1f);
            sum += n * n * amp;
            norm += amp;
            x *= 2.1f; y *= 2.1f; amp *= 0.5f;
        }
        return sum / norm;
    }
}
