package com.kartracer.gl;

import android.opengl.GLES30;

import com.kartracer.gfx.MeshData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** One vertex buffer drawn with up to three index sets (LOD levels). */
public final class GlChunk {
    private final byte[] verts;
    private final short[][] idx;
    private final int lods;
    private int vbo;
    private final int[] ibo, vao, counts;

    public GlChunk(byte[] verts, short[][] idx) {
        this.verts = verts; this.idx = idx; lods = idx.length;
        ibo = new int[lods]; vao = new int[lods]; counts = new int[lods];
    }

    public void upload() {
        int[] id = new int[1];
        GLES30.glGenBuffers(1, id, 0); vbo = id[0];
        ByteBuffer vb = ByteBuffer.allocateDirect(verts.length).order(ByteOrder.nativeOrder());
        vb.put(verts); vb.position(0);
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo);
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, verts.length, vb, GLES30.GL_STATIC_DRAW);
        for (int l = 0; l < lods; l++) {
            counts[l] = idx[l].length;
            GLES30.glGenVertexArrays(1, id, 0); vao[l] = id[0];
            GLES30.glGenBuffers(1, id, 0); ibo[l] = id[0];
            GLES30.glBindVertexArray(vao[l]);
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo);
            int s = MeshData.STRIDE;
            GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, s, 0);
            GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 4, GLES30.GL_BYTE, true, s, 12);
            GLES30.glEnableVertexAttribArray(2); GLES30.glVertexAttribPointer(2, 4, GLES30.GL_UNSIGNED_BYTE, true, s, 16);
            GLES30.glEnableVertexAttribArray(3); GLES30.glVertexAttribPointer(3, 2, GLES30.GL_FLOAT, false, s, 20);
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo[l]);
            GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, idx[l].length * 2, MeshData.indexBuffer(idx[l]), GLES30.GL_STATIC_DRAW);
        }
        GLES30.glBindVertexArray(0);
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
    }

    public void draw(int lod) {
        int l = Math.min(lod, lods - 1);
        if (counts[l] == 0) return;
        GLES30.glBindVertexArray(vao[l]);
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, counts[l], GLES30.GL_UNSIGNED_SHORT, 0);
    }

    public void release() {
        GLES30.glDeleteVertexArrays(lods, vao, 0);
        GLES30.glDeleteBuffers(lods, ibo, 0);
        int[] b = {vbo};
        GLES30.glDeleteBuffers(1, b, 0);
    }
}
