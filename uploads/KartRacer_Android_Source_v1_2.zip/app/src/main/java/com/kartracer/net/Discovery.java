package com.kartracer.net;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** LAN discovery over UDP broadcast: hosts announce themselves, clients listen and probe. */
public final class Discovery {
    private Discovery() {}

    public static final class HostInfo {
        public String name = "", address = "";
        public int tcpPort, players, max, track, laps;
        public boolean inRace;
        public long seenMs;
        public String key() { return address + ":" + tcpPort; }
    }

    public interface InfoSource { HostInfo get(); }

    public interface Listener { void onHosts(List<HostInfo> hosts); }

    private static byte[] encodeAnnounce(HostInfo h) throws java.io.IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        DataOutputStream d = new DataOutputStream(bo);
        d.write(NetConst.DISC_MAGIC);
        d.writeByte(1);
        d.writeInt(NetConst.PROTOCOL);
        d.writeUTF(h.name == null ? "Host" : h.name);
        d.writeInt(h.tcpPort);
        d.writeByte(h.players); d.writeByte(h.max); d.writeByte(h.track); d.writeByte(h.laps);
        d.writeBoolean(h.inRace);
        d.flush();
        return bo.toByteArray();
    }

    private static DatagramSocket openSocket() throws java.io.IOException {
        DatagramSocket s = new DatagramSocket(null);
        s.setReuseAddress(true);
        s.setBroadcast(true);
        s.bind(new InetSocketAddress(NetConst.DISCOVERY_PORT));
        s.setSoTimeout(250);
        return s;
    }

    // ------------------------------------------------------------------ host side
    public static final class Announcer {
        private final PlatformHooks hooks;
        private final InfoSource source;
        private volatile boolean running;
        private DatagramSocket socket;

        public Announcer(PlatformHooks hooks, InfoSource source) { this.hooks = hooks; this.source = source; }

        public void start() {
            if (running) return;
            running = true;
            hooks.acquireMulticastLock();
            Thread t = new Thread(new Runnable() { public void run() { loop(); } }, "kr-announce");
            t.setDaemon(true);
            t.start();
        }

        public void stop() {
            running = false;
            DatagramSocket s = socket;
            if (s != null) s.close();
            hooks.releaseMulticastLock();
        }

        private void loop() {
            try {
                socket = openSocket();
            } catch (Exception e) {
                running = false;
                return;
            }
            long last = 0;
            byte[] buf = new byte[256];
            while (running) {
                long now = System.currentTimeMillis();
                if (now - last >= 1000) {
                    last = now;
                    try {
                        byte[] pkt = encodeAnnounce(source.get());
                        for (InetAddress a : NetUtil.broadcastTargets(hooks)) {
                            try { socket.send(new DatagramPacket(pkt, pkt.length, a, NetConst.DISCOVERY_PORT)); } catch (Exception ignored) { }
                        }
                    } catch (Exception ignored) { }
                }
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    socket.receive(p);
                    if (isProbe(p)) {
                        byte[] pkt = encodeAnnounce(source.get());
                        socket.send(new DatagramPacket(pkt, pkt.length, p.getAddress(), p.getPort()));
                    }
                } catch (SocketTimeoutException ignored) {
                } catch (Exception e) {
                    if (!running) break;
                }
            }
            socket.close();
        }

        private boolean isProbe(DatagramPacket p) {
            byte[] d = p.getData();
            if (p.getLength() < 5) return false;
            for (int i = 0; i < 4; i++) if (d[i] != NetConst.DISC_MAGIC[i]) return false;
            return d[4] == 2;
        }
    }

    // ------------------------------------------------------------------ client side
    public static final class Browser {
        private final PlatformHooks hooks;
        private final Listener listener;
        private volatile boolean running;
        private DatagramSocket socket;
        private final Map<String, HostInfo> found = new LinkedHashMap<String, HostInfo>();

        public Browser(PlatformHooks hooks, Listener l) { this.hooks = hooks; this.listener = l; }

        public void start() {
            if (running) return;
            running = true;
            hooks.acquireMulticastLock();
            Thread t = new Thread(new Runnable() { public void run() { loop(); } }, "kr-browse");
            t.setDaemon(true);
            t.start();
        }

        public void stop() {
            running = false;
            DatagramSocket s = socket;
            if (s != null) s.close();
            hooks.releaseMulticastLock();
        }

        private void probe() {
            byte[] pkt = {NetConst.DISC_MAGIC[0], NetConst.DISC_MAGIC[1], NetConst.DISC_MAGIC[2], NetConst.DISC_MAGIC[3], 2};
            for (InetAddress a : NetUtil.broadcastTargets(hooks)) {
                try { socket.send(new DatagramPacket(pkt, pkt.length, a, NetConst.DISCOVERY_PORT)); } catch (Exception ignored) { }
            }
        }

        private void loop() {
            try {
                socket = openSocket();
            } catch (Exception e) {
                running = false;
                return;
            }
            long lastProbe = 0;
            byte[] buf = new byte[512];
            while (running) {
                long now = System.currentTimeMillis();
                if (now - lastProbe > 1500) { lastProbe = now; probe(); }
                boolean changed = false;
                try {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    socket.receive(p);
                    HostInfo h = parse(p);
                    if (h != null) {
                        synchronized (found) {
                            HostInfo old = found.get(h.key());
                            found.put(h.key(), h);
                            if (old == null || old.players != h.players || old.track != h.track || old.laps != h.laps
                                    || old.inRace != h.inRace || !old.name.equals(h.name)) changed = true;
                        }
                    }
                } catch (SocketTimeoutException ignored) {
                } catch (Exception e) {
                    if (!running) break;
                }
                synchronized (found) {
                    Iterator<HostInfo> it = found.values().iterator();
                    while (it.hasNext()) if (now - it.next().seenMs > 6000) { it.remove(); changed = true; }
                }
                if (changed) listener.onHosts(snapshot());
            }
            socket.close();
        }

        public List<HostInfo> snapshot() {
            synchronized (found) { return new ArrayList<HostInfo>(found.values()); }
        }

        private HostInfo parse(DatagramPacket p) {
            try {
                DataInputStream d = new DataInputStream(new ByteArrayInputStream(p.getData(), 0, p.getLength()));
                byte[] m = new byte[4];
                d.readFully(m);
                for (int i = 0; i < 4; i++) if (m[i] != NetConst.DISC_MAGIC[i]) return null;
                if (d.readByte() != 1) return null;
                if (d.readInt() != NetConst.PROTOCOL) return null;
                HostInfo h = new HostInfo();
                h.name = d.readUTF();
                h.tcpPort = d.readInt();
                h.players = d.readByte(); h.max = d.readByte(); h.track = d.readByte(); h.laps = d.readByte();
                h.inRace = d.readBoolean();
                h.address = p.getAddress().getHostAddress();
                h.seenMs = System.currentTimeMillis();
                return h;
            } catch (Exception e) {
                return null;
            }
        }
    }
}
