package com.kartracer.app;

import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.os.Build;

import com.kartracer.net.PlatformHooks;
import com.kartracer.util.Diag;

/** Android specifics for the LAN code: multicast lock and DHCP broadcast address. */
public final class AndroidHooks implements PlatformHooks {
    private final Context ctx;
    private WifiManager.MulticastLock lock;
    private WifiManager.WifiLock fastLock;

    public AndroidHooks(Context c) { ctx = c.getApplicationContext(); }

    private WifiManager wifi() { return (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE); }

    @Override
    public synchronized void acquireMulticastLock() {
        try {
            WifiManager wm = wifi();
            if (wm == null) return;
            if (lock == null) { lock = wm.createMulticastLock("kartracer-lan"); lock.setReferenceCounted(false); }
            if (!lock.isHeld()) lock.acquire();
        } catch (Exception e) {
            Diag.err("Net", "multicast lock", e);
        }
    }

    @Override
    public synchronized void releaseMulticastLock() {
        try { if (lock != null && lock.isHeld()) lock.release(); } catch (Exception ignored) { }
    }

    /** Wi-Fi power saving can hold packets back for 100 ms or more; this keeps the radio awake while racing online. */
    @Override
    @SuppressWarnings("deprecation")
    public synchronized void acquireLowLatency() {
        try {
            WifiManager wm = wifi();
            if (wm == null) return;
            if (fastLock == null) {
                int mode = Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
                fastLock = wm.createWifiLock(mode, "kartracer-fast");
                fastLock.setReferenceCounted(false);
            }
            if (!fastLock.isHeld()) fastLock.acquire();
        } catch (Exception e) {
            Diag.err("Net", "wifi low latency lock", e);
        }
    }

    @Override
    public synchronized void releaseLowLatency() {
        try { if (fastLock != null && fastLock.isHeld()) fastLock.release(); } catch (Exception ignored) { }
    }

    @Override
    @SuppressWarnings("deprecation")
    public String[] extraBroadcastAddresses() {
        try {
            WifiManager wm = wifi();
            DhcpInfo d = wm == null ? null : wm.getDhcpInfo();
            if (d != null && d.ipAddress != 0 && d.netmask != 0) {
                int bc = (d.ipAddress & d.netmask) | ~d.netmask;
                return new String[]{(bc & 255) + "." + ((bc >> 8) & 255) + "." + ((bc >> 16) & 255) + "." + ((bc >> 24) & 255)};
            }
        } catch (Exception ignored) { }
        return new String[0];
    }
}
