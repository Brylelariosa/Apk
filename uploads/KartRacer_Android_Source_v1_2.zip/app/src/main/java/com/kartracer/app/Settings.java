package com.kartracer.app;

/** User settings (plain data; persisted by SettingsStore). */
public final class Settings {
    // player
    public String playerName = "Player";
    public int kart = 0, paint = 0, driver = 0;
    // quick race setup
    public int track = 0, laps = 3, aiCount = 5, difficulty = 1;
    public boolean items = true;
    // graphics
    public int quality = 1;           // 0 low, 1 medium, 2 high
    public boolean autoQuality = true; // adapt render scale to frame time
    public boolean shadows = true;
    public int scalePct = 0;          // 0 = from preset, else 50..100
    public int fpsCap = 60;           // 30 or 60
    public boolean showFps = false;
    // sound
    public boolean sound = true;
    public int sfxVolume = 80;        // percent
    // camera
    public int cameraMode = 1;        // 0 close, 1 normal, 2 far
    public int fov = 62;
    public boolean camShake = true;
    // controls
    public int steerMode = 0;         // 0 buttons, 1 tilt, 2 slide
    public boolean autoGas = false;
    public int tiltSens = 100;        // percent
    public int buttonScale = 100;     // percent
    public int controlOpacity = 80;   // percent
    public boolean leftHanded = false;
    public boolean haptics = true;
    public boolean customLayout = false;
    /** Normalized centers (x,y) for: left, right, gas, brake, drift, item, boost. */
    public float[] layout = defaultLayout(false);
    // network
    public String lastIp = "";

    public static final int CONTROLS = 7;
    public static final String[] CONTROL_NAMES = {"Steer left", "Steer right", "Gas", "Brake", "Drift", "Item", "Boost"};

    public static float[] defaultLayout(boolean leftHanded) {
        // steering cluster on one side, pedals on the other
        float[] l = {0.11f, 0.80f, 0.27f, 0.80f, 0.91f, 0.78f, 0.77f, 0.86f, 0.90f, 0.50f, 0.90f, 0.27f, 0.76f, 0.60f};
        if (leftHanded) {
            for (int i = 0; i < CONTROLS; i++) l[i * 2] = 1f - l[i * 2];
            // keep "steer left" on the left of "steer right" after mirroring, and keep the item button clear of the place / lap display
            float t = l[0]; l[0] = l[2]; l[2] = t;
            l[11] = 0.34f;
        }
        return l;
    }

    public void resetLayout() { layout = defaultLayout(leftHanded); customLayout = false; }

    public Settings copy() {
        Settings s = new Settings();
        s.playerName = playerName; s.kart = kart; s.paint = paint; s.driver = driver;
        s.track = track; s.laps = laps; s.aiCount = aiCount; s.difficulty = difficulty; s.items = items;
        s.quality = quality; s.autoQuality = autoQuality; s.shadows = shadows; s.scalePct = scalePct; s.fpsCap = fpsCap; s.showFps = showFps;
        s.sound = sound; s.sfxVolume = sfxVolume;
        s.cameraMode = cameraMode; s.fov = fov; s.camShake = camShake;
        s.steerMode = steerMode; s.autoGas = autoGas; s.tiltSens = tiltSens; s.buttonScale = buttonScale; s.controlOpacity = controlOpacity;
        s.leftHanded = leftHanded; s.haptics = haptics; s.customLayout = customLayout; s.layout = layout.clone(); s.lastIp = lastIp;
        return s;
    }
}
