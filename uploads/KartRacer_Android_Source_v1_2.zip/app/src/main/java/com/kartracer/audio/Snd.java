package com.kartracer.audio;

/** Sound effect ids (shared by the synthesizer and the player). */
public final class Snd {
    private Snd() {}

    public static final int CLICK = 0, BACK = 1, BEEP = 2, GO = 3, ITEM_PICK = 4, TURBO = 5, ROCKET = 6, COCONUT = 7, OIL = 8,
            SHIELD_ON = 9, SHIELD_POP = 10, PAD = 11, BOOST = 12, SPIN = 13, EXPLODE = 14, BUMP = 15, SMASH = 16, LAND = 17,
            SPLASH = 18, JUMP = 19, SPARK = 20, LAP = 21, FINAL_LAP = 22, FINISH = 23, RESPAWN = 24, WRONG_WAY = 25,
            ENGINE = 26, SKID = 27, COUNT = 28;

    /** True for sounds that are meant to be looped. */
    public static boolean isLoop(int id) { return id == ENGINE || id == SKID; }
}
