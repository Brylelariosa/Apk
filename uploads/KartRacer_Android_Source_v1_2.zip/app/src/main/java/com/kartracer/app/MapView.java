package com.kartracer.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

import com.kartracer.world.TrackDef;

/** Track card preview: themed background with the road outline. */
public final class MapView extends View {
    private final TrackDef def;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF r = new RectF();
    private final float[] fit = new float[3];
    private static final int[][] BG = {{0xFF1A9CC8, 0xFF0B5A86}, {0xFF3E9A42, 0xFF1A4A20}, {0xFF7A3524, 0xFF2A1210}, {0xFFE0AB62, 0xFFA06F34}};

    public MapView(Context c, TrackDef def) { super(c); this.def = def; }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        int[] bg = BG[Math.max(0, Math.min(3, def.theme))];
        p.setShader(new LinearGradient(0, 0, 0, h, bg[0], bg[1], Shader.TileMode.CLAMP));
        r.set(0, 0, w, h);
        c.drawRoundRect(r, Ui.dp(12), Ui.dp(12), p);
        p.setShader(null);
        MapPaths.Data d = MapPaths.forDef(def);
        MapPaths.fit(d, 0, 0, w, h, Ui.dp(16), fit);
        MapPaths.buildPath(d, fit, path);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(Ui.dp(8));
        p.setColor(0xCC000000);
        c.drawPath(path, p);
        p.setStrokeWidth(Ui.dp(4.5f));
        p.setColor(0xFFF4F4F4);
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFA726);
        c.drawCircle(d.x[0] * fit[0] + fit[1], d.z[0] * fit[0] + fit[2], Ui.dp(5), p);
    }
}
