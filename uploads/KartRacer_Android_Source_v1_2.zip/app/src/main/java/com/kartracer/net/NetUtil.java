package com.kartracer.net;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class NetUtil {
    private NetUtil() {}

    /** Non-loopback IPv4 addresses of this device (Wi-Fi, hotspot, ethernet). */
    public static List<String> localAddresses() {
        List<String> out = new ArrayList<String>();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress a = ia.getAddress();
                    if (a instanceof Inet4Address && !a.isLoopbackAddress()) out.add(a.getHostAddress());
                }
            }
        } catch (Exception ignored) { }
        return out;
    }

    /** Directed broadcast addresses for every IPv4 interface that is up. */
    public static Set<InetAddress> broadcastTargets(PlatformHooks hooks) {
        Set<InetAddress> out = new LinkedHashSet<InetAddress>();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    if (!(ia.getAddress() instanceof Inet4Address)) continue;
                    InetAddress b = ia.getBroadcast();
                    if (b == null) b = computeBroadcast((Inet4Address) ia.getAddress(), ia.getNetworkPrefixLength());
                    if (b != null) out.add(b);
                }
            }
        } catch (Exception ignored) { }
        try { out.add(InetAddress.getByName("255.255.255.255")); } catch (Exception ignored) { }
        if (hooks != null) {
            for (String s : hooks.extraBroadcastAddresses()) {
                try { out.add(InetAddress.getByName(s)); } catch (Exception ignored) { }
            }
        }
        return out;
    }

    private static InetAddress computeBroadcast(Inet4Address a, short prefix) {
        try {
            if (prefix <= 0 || prefix >= 32) return null;
            byte[] b = a.getAddress();
            int ip = ((b[0] & 255) << 24) | ((b[1] & 255) << 16) | ((b[2] & 255) << 8) | (b[3] & 255);
            int mask = prefix == 0 ? 0 : (-1 << (32 - prefix));
            int bc = ip | ~mask;
            return InetAddress.getByAddress(new byte[]{(byte) (bc >>> 24), (byte) (bc >>> 16), (byte) (bc >>> 8), (byte) bc});
        } catch (Exception e) {
            return null;
        }
    }
}
