package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;
import com.kartracer.world.Road;
import com.kartracer.world.Terrain;
import com.kartracer.world.TrackData;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Builds terrain chunks (with LOD index sets and skirts), water chunks and road meshes. Pure Java. */
public final class WorldMesher {
    private WorldMesher() {}

    public static final int LODS = 3;

    public static final class ChunkMesh {
        public int vcount;
        public byte[] verts;
        public short[][] idx = new short[LODS][];
        public float cx, cy, cz, radius;
        public int wcount;
        public byte[] wverts;
        public short[][] widx = new short[LODS][];
        public boolean hasWater() { return wverts != null; }
    }

    public static int chunksX(TrackData t) { return (t.gnx - 1) / TrackData.CHUNK; }
    public static int chunksZ(TrackData t) { return (t.gnz - 1) / TrackData.CHUNK; }

    private static void put(ByteBuffer b, float x, float y, float z, float nx, float ny, float nz, int col, float u, float v) {
        b.putFloat(x); b.putFloat(y); b.putFloat(z);
        b.put((byte) Math.round(nx * 127f)); b.put((byte) Math.round(ny * 127f)); b.put((byte) Math.round(nz * 127f)); b.put((byte) 0);
        b.putInt(col); b.putFloat(u); b.putFloat(v);
    }

    private static float lowering(float sdf) { return 0.16f * MathX.smooth(3.2f, 1.8f, sdf); }

    public static ChunkMesh[] terrain(TrackData t) {
        int ncx = chunksX(t), ncz = chunksZ(t), C = TrackData.CHUNK;
        ChunkMesh[] out = new ChunkMesh[ncx * ncz];
        for (int cz = 0; cz < ncz; cz++) for (int cx = 0; cx < ncx; cx++) out[cz * ncx + cx] = chunk(t, cx, cz, C);
        return out;
    }

    private static ChunkMesh chunk(TrackData t, int cx, int cz, int C) {
        ChunkMesh m = new ChunkMesh();
        int n1 = C + 1;
        int skirtBase = n1 * n1;
        int vc = skirtBase + 4 * n1;
        ByteBuffer b = ByteBuffer.allocate(vc * MeshData.STRIDE).order(ByteOrder.LITTLE_ENDIAN);
        float[] ys = new float[vc];
        float miny = 1e9f, maxy = -1e9f;
        float[] px = new float[vc], pz = new float[vc], nxs = new float[vc], nzs = new float[vc];
        int[] cols = new int[vc];
        float cell = t.cell;
        for (int j = 0; j < n1; j++) for (int i = 0; i < n1; i++) {
            int gx = cx * C + i, gz = cz * C + j;
            int id = gz * t.gnx + gx;
            float x = t.gx0 + gx * cell, z = t.gz0 + gz * cell;
            float h = t.base[id];
            int x0 = Math.max(0, gx - 1), x1 = Math.min(t.gnx - 1, gx + 1), z0 = Math.max(0, gz - 1), z1 = Math.min(t.gnz - 1, gz + 1);
            float dhdx = (t.base[gz * t.gnx + x1] - t.base[gz * t.gnx + x0]) / ((x1 - x0) * cell);
            float dhdz = (t.base[z1 * t.gnx + gx] - t.base[z0 * t.gnx + gx]) / ((z1 - z0) * cell);
            float nl = (float) Math.sqrt(dhdx * dhdx + 1f + dhdz * dhdz);
            float nx = -dhdx / nl, ny = 1f / nl, nz = -dhdz / nl;
            float y = h - lowering(t.sdf[id]);
            float rho = Terrain.rho(t.def, x, z);
            int col = Terrain.color(t.def, t.surf[id], x, z, h, ny, t.sdf[id], rho);
            int vi = j * n1 + i;
            ys[vi] = y; px[vi] = x; pz[vi] = z; nxs[vi] = nx; nzs[vi] = nz; cols[vi] = col;
            miny = Math.min(miny, y); maxy = Math.max(maxy, y);
            put(b, x, y, z, nx, ny, nz, col, x * 0.12f, z * 0.12f);
        }
        // skirts: copies of the border lowered by 3 m (north, south, west, east)
        for (int e = 0; e < 4; e++) for (int k = 0; k < n1; k++) {
            int i = e == 2 ? 0 : (e == 3 ? C : k), j = e == 0 ? 0 : (e == 1 ? C : k);
            int vi = j * n1 + i;
            put(b, px[vi], ys[vi] - 3f, pz[vi], 0, 1, 0, cols[vi], px[vi] * 0.12f, pz[vi] * 0.12f);
        }
        miny -= 3f;
        m.vcount = vc; m.verts = b.array();
        m.cx = t.gx0 + (cx * C + C * 0.5f) * cell; m.cz = t.gz0 + (cz * C + C * 0.5f) * cell; m.cy = (miny + maxy) * 0.5f;
        float half = C * cell * 0.5f, hy = (maxy - miny) * 0.5f;
        m.radius = (float) Math.sqrt(2 * half * half + hy * hy);
        for (int l = 0; l < LODS; l++) m.idx[l] = terrainIndices(C, 1 << l, skirtBase);
        buildWater(t, cx, cz, C, m);
        return m;
    }

    private static short[] terrainIndices(int C, int s, int skirtBase) {
        int n1 = C + 1;
        int cells = (C / s) * (C / s);
        short[] ix = new short[cells * 6 + 4 * (C / s) * 12];
        int o = 0;
        for (int j = 0; j < C; j += s) for (int i = 0; i < C; i += s) {
            int a = j * n1 + i, b = (j + s) * n1 + i, c = j * n1 + i + s, d = (j + s) * n1 + i + s;
            ix[o++] = (short) a; ix[o++] = (short) b; ix[o++] = (short) c;
            ix[o++] = (short) c; ix[o++] = (short) b; ix[o++] = (short) d;
        }
        // skirts, both windings
        for (int e = 0; e < 4; e++) for (int k = 0; k < C; k += s) {
            int i0 = e == 2 ? 0 : (e == 3 ? C : k), j0 = e == 0 ? 0 : (e == 1 ? C : k);
            int i1 = e >= 2 ? i0 : k + s, j1 = e >= 2 ? k + s : j0;
            int p0 = j0 * n1 + i0, p1 = j1 * n1 + i1;
            int q0 = skirtBase + e * n1 + k, q1 = skirtBase + e * n1 + k + s;
            ix[o++] = (short) p0; ix[o++] = (short) p1; ix[o++] = (short) q0;
            ix[o++] = (short) p1; ix[o++] = (short) q1; ix[o++] = (short) q0;
            ix[o++] = (short) p0; ix[o++] = (short) q0; ix[o++] = (short) p1;
            ix[o++] = (short) p1; ix[o++] = (short) q0; ix[o++] = (short) q1;
        }
        return o == ix.length ? ix : java.util.Arrays.copyOf(ix, o);
    }

    private static void buildWater(TrackData t, int cx, int cz, int C, ChunkMesh m) {
        float wl = t.waterLevel;
        int n1 = C + 1;
        float[] depth = new float[n1 * n1];
        boolean any = false;
        for (int j = 0; j < n1; j++) for (int i = 0; i < n1; i++) {
            float d = wl - t.base[(cz * C + j) * t.gnx + cx * C + i];
            depth[j * n1 + i] = d;
            if (d > -0.4f) any = true;
        }
        if (!any) return;
        ByteBuffer b = ByteBuffer.allocate(n1 * n1 * MeshData.STRIDE).order(ByteOrder.LITTLE_ENDIAN);
        for (int j = 0; j < n1; j++) for (int i = 0; i < n1; i++) {
            float x = t.gx0 + (cx * C + i) * t.cell, z = t.gz0 + (cz * C + j) * t.cell;
            int a = (int) (255f * MathX.sat((depth[j * n1 + i] + 0.5f) / 3.5f));
            put(b, x, wl, z, 0, 1, 0, Col.rgba(255, 255, 255, a), x * 0.05f, z * 0.05f);
        }
        boolean hasCells = false;
        for (int l = 0; l < LODS; l++) {
            int s = 1 << l;
            short[] ix = new short[(C / s) * (C / s) * 6];
            int o = 0;
            for (int j = 0; j < C; j += s) for (int i = 0; i < C; i += s) {
                if (depth[j * n1 + i] < -0.6f && depth[(j + s) * n1 + i] < -0.6f && depth[j * n1 + i + s] < -0.6f && depth[(j + s) * n1 + i + s] < -0.6f) continue;
                int a = j * n1 + i, bb = (j + s) * n1 + i, c = j * n1 + i + s, d = (j + s) * n1 + i + s;
                ix[o++] = (short) a; ix[o++] = (short) bb; ix[o++] = (short) c;
                ix[o++] = (short) c; ix[o++] = (short) bb; ix[o++] = (short) d;
            }
            m.widx[l] = java.util.Arrays.copyOf(ix, o);
            if (o > 0) hasCells = true;
        }
        if (!hasCells) return;
        m.wcount = n1 * n1; m.wverts = b.array();
    }

    // ---------------------------------------------------------------- roads

    /** Road mesh for roads[k]: 4 columns per sample (shoulder, edge, edge, shoulder). */
    public static MeshData road(TrackData t, int k) {
        Road r = t.roads[k];
        MeshBuilder b = new MeshBuilder();
        int n = r.n;
        int cnt = r.closed ? n + 1 : n;
        float dy = k > 0 ? 0.02f : 0f;
        int white = Col.rgba(255, 255, 255, 0);
        int[][] ids = new int[cnt][4];
        float[] us = {0f, 0.14f, 0.86f, 1f};
        float sh = 2.4f;
        for (int i = 0; i < cnt; i++) {
            int a = i % n;
            float rx = -r.tz[a], rz = r.tx[a], hw = r.w[a] * 0.5f;
            // shortcut paths lose their dark shoulder strips where they merge into the main road, so no wedge shows on the road
            float shk = (!r.closed && k > 0) ? sh * MathX.smooth(0f, 16f, Math.min(i, cnt - 1 - i)) : sh;
            float[] off = {-(hw + shk), -hw, hw, hw + shk};
            float v = (i == n ? r.length : r.s[a]) / 12f;
            for (int c = 0; c < 4; c++) {
                ids[i][c] = b.vert(r.x[a] + rx * off[c], r.y[a] + dy, r.z[a] + rz * off[c], 0, 1, 0, white, us[c], v);
            }
        }
        for (int i = 0; i + 1 < cnt; i++) for (int c = 0; c < 3; c++) {
            // right vector = (-tz, tx); strip runs forward, so (left->right, then forward) is CCW seen from above
            b.quad(ids[i][c], ids[i][c + 1], ids[i + 1][c + 1], ids[i + 1][c]);
        }
        return b.build();
    }
}
