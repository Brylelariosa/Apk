package com.kartracer.app;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;

/**
 * Colourful, easy to recognise artwork for the five power-ups (drawn with Canvas paths on a 24 unit grid).
 * Item ids follow sim.Race: 0 none / mystery box, 1 turbo, 2 rocket, 3 coconut, 4 oil slick, 5 shield.
 */
public final class ItemArt {
    private ItemArt() {}

    public static final String[] NAME = {"ITEM", "TURBO", "ROCKET", "COCONUT", "OIL", "SHIELD"};
    /** Short explanation shown right after picking an item up. */
    public static final String[] HINT = {
            "",
            "Instant speed boost - tap ITEM to use it",
            "Homing missile - tap ITEM to fire at the racer ahead",
            "Tap ITEM to throw it straight ahead",
            "Tap ITEM to drop a slick behind you - rivals spin out",
            "Tap ITEM for a bubble that blocks the next hit"};
    public static final int[] COLOR = {0xFFB39DDB, 0xFFFFEE58, 0xFFFF7043, 0xFFBCAAA4, 0xFFB388FF, 0xFF4FC3F7};

    private static final Path P = new Path(), Q = new Path();
    private static final RectF R = new RectF();
    private static float cx, cy, s;

    private static float X(float u) { return cx + (u - 12f) * s; }
    private static float Y(float v) { return cy + (v - 12f) * s; }
    private static void m(Path p, float u, float v) { p.moveTo(X(u), Y(v)); }
    private static void l(Path p, float u, float v) { p.lineTo(X(u), Y(v)); }
    private static void q(Path p, float cu, float cv, float u, float v) { p.quadTo(X(cu), Y(cv), X(u), Y(v)); }
    private static void rect(float a, float b, float c, float d) { R.set(X(a), Y(b), X(c), Y(d)); }
    private static void fillCol(Paint p, int argb) { p.setStyle(Paint.Style.FILL); p.setColor(argb); }
    private static void strokeCol(Paint p, int argb, float w) {
        p.setStyle(Paint.Style.STROKE); p.setColor(argb); p.setStrokeWidth(w * s); p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
    }

    /** Draws the item art centred at (centerX, centerY) with half size r. Leaves the paint style at FILL. */
    public static void draw(Canvas c, int item, float centerX, float centerY, float r, Paint p) {
        cx = centerX; cy = centerY; s = r / 12f;
        float oldW = p.getStrokeWidth();
        Paint.Cap oldCap = p.getStrokeCap();
        Paint.Join oldJoin = p.getStrokeJoin();
        float oldSize = p.getTextSize();
        Paint.Align oldAlign = p.getTextAlign();
        P.reset(); Q.reset();
        switch (item) {
            case 1: turbo(c, p); break;
            case 2: rocket(c, p); break;
            case 3: coconut(c, p); break;
            case 4: oil(c, p); break;
            case 5: shield(c, p); break;
            default: mystery(c, p); break;
        }
        p.setStyle(Paint.Style.FILL);
        p.setStrokeWidth(oldW); p.setStrokeCap(oldCap); p.setStrokeJoin(oldJoin);
        p.setTextSize(oldSize); p.setTextAlign(oldAlign);
    }

    private static void turbo(Canvas c, Paint p) {
        // lightning bolt with speed streaks
        m(P, 14f, 0.8f); l(P, 4.5f, 13.2f); l(P, 10.6f, 13.2f); l(P, 8.8f, 23.2f); l(P, 19.5f, 9.6f); l(P, 13.2f, 9.6f); P.close();
        strokeCol(p, 0xFFFF8F00, 3.2f); c.drawPath(P, p);
        fillCol(p, 0xFFFFEE58); c.drawPath(P, p);
        Q.reset(); m(Q, 14f, 0.8f); l(Q, 4.5f, 13.2f); l(Q, 9f, 13.2f); l(Q, 13.4f, 5f); Q.close();
        fillCol(p, 0xFFFFFFFF); p.setAlpha(150); c.drawPath(Q, p); p.setAlpha(255);
        strokeCol(p, 0xFFFFFFFF, 1.6f);
        P.reset(); m(P, 0.8f, 9f); l(P, 4.2f, 9f); m(P, 0.4f, 13.5f); l(P, 3.2f, 13.5f); m(P, 1.4f, 18f); l(P, 5f, 18f);
        c.drawPath(P, p);
    }

    private static void rocket(Canvas c, Paint p) {
        c.save();
        c.rotate(45f, cx, cy);
        // flame
        P.reset(); m(P, 9.6f, 17f); q(P, 9f, 21.5f, 12f, 25f); q(P, 15f, 21.5f, 14.4f, 17f); P.close();
        fillCol(p, 0xFFFF9800); c.drawPath(P, p);
        P.reset(); m(P, 10.8f, 17f); q(P, 10.5f, 20f, 12f, 22.2f); q(P, 13.5f, 20f, 13.2f, 17f); P.close();
        fillCol(p, 0xFFFFEE58); c.drawPath(P, p);
        // fins
        P.reset(); m(P, 8.6f, 11.5f); l(P, 3.8f, 18.6f); l(P, 8.4f, 17.2f); P.close();
        m(P, 15.4f, 11.5f); l(P, 20.2f, 18.6f); l(P, 15.6f, 17.2f); P.close();
        fillCol(p, 0xFFE53935); c.drawPath(P, p);
        // body
        P.reset(); m(P, 12f, 0.6f); q(P, 17.8f, 5f, 15.6f, 17.4f); l(P, 8.4f, 17.4f); q(P, 6.2f, 5f, 12f, 0.6f); P.close();
        fillCol(p, 0xFFF5F5F5); c.drawPath(P, p);
        // nose cone
        P.reset(); m(P, 12f, 0.6f); q(P, 15.3f, 2.6f, 15.2f, 6.6f); l(P, 8.8f, 6.6f); q(P, 8.7f, 2.6f, 12f, 0.6f); P.close();
        fillCol(p, 0xFFE53935); c.drawPath(P, p);
        // window
        fillCol(p, 0xFF90A4AE); c.drawCircle(X(12f), Y(11f), 2.6f * s, p);
        fillCol(p, 0xFF29B6F6); c.drawCircle(X(12f), Y(11f), 1.9f * s, p);
        // body outline
        P.reset(); m(P, 12f, 0.6f); q(P, 17.8f, 5f, 15.6f, 17.4f); l(P, 8.4f, 17.4f); q(P, 6.2f, 5f, 12f, 0.6f); P.close();
        strokeCol(p, 0xFF37474F, 1.1f); c.drawPath(P, p);
        c.restore();
    }

    private static void coconut(Canvas c, Paint p) {
        // brown nut with three dark holes and a leaf
        fillCol(p, 0xFF6D4C41); c.drawCircle(X(12f), Y(13f), 9.4f * s, p);
        fillCol(p, 0xFF8D6E63); c.drawCircle(X(10.2f), Y(11.2f), 6.2f * s, p);
        fillCol(p, 0xFFA1887F); c.drawCircle(X(8.8f), Y(9.6f), 3.0f * s, p);
        strokeCol(p, 0xFF3E2723, 1.5f); c.drawCircle(X(12f), Y(13f), 9.4f * s, p);
        fillCol(p, 0xFF2B1810);
        c.drawCircle(X(9.6f), Y(14.6f), 1.35f * s, p);
        c.drawCircle(X(14.6f), Y(14.6f), 1.35f * s, p);
        c.drawCircle(X(12.1f), Y(18.2f), 1.35f * s, p);
        P.reset(); m(P, 12f, 4.2f); q(P, 15f, 0.6f, 20f, 1.8f); q(P, 17.5f, 5.4f, 12f, 4.2f); P.close();
        fillCol(p, 0xFF43A047); c.drawPath(P, p);
    }

    private static void oil(Canvas c, Paint p) {
        // dark glossy puddle with a falling drop
        rect(2f, 12.5f, 22f, 22.5f); fillCol(p, 0xFF1B1530); c.drawOval(R, p);
        rect(5f, 14.2f, 19f, 21f); fillCol(p, 0xFF2D2350); c.drawOval(R, p);
        rect(7.5f, 15.2f, 13.5f, 18f); fillCol(p, 0xFF7C5CBF); c.drawOval(R, p);
        rect(14f, 17f, 17f, 18.8f); fillCol(p, 0xFF26C6DA); c.drawOval(R, p);
        P.reset(); m(P, 12f, 0.8f); q(P, 16.2f, 6.4f, 16.2f, 9f); q(P, 16.2f, 12.6f, 12f, 12.6f); q(P, 7.8f, 12.6f, 7.8f, 9f); q(P, 7.8f, 6.4f, 12f, 0.8f); P.close();
        fillCol(p, 0xFF1B1530); c.drawPath(P, p);
        strokeCol(p, 0xFFB388FF, 1.2f); c.drawPath(P, p);
        fillCol(p, 0xFFFFFFFF); p.setAlpha(190); c.drawCircle(X(10.2f), Y(8.6f), 1.1f * s, p); p.setAlpha(255);
    }

    private static void shield(Canvas c, Paint p) {
        // blue heater shield with a white star
        P.reset(); m(P, 12f, 1.2f); l(P, 20.6f, 4.4f); l(P, 20.6f, 11.6f); q(P, 20.6f, 18.8f, 12f, 23f); q(P, 3.4f, 18.8f, 3.4f, 11.6f); l(P, 3.4f, 4.4f); P.close();
        fillCol(p, 0xFF1E6FD0); c.drawPath(P, p);
        Q.reset(); m(Q, 12f, 1.2f); l(Q, 3.4f, 4.4f); l(Q, 3.4f, 11.6f); q(Q, 3.4f, 18.8f, 12f, 23f); Q.close();
        fillCol(p, 0xFF3D8FEA); c.drawPath(Q, p);
        strokeCol(p, 0xFFFFFFFF, 1.8f); c.drawPath(P, p);
        P.reset();
        for (int k = 0; k < 10; k++) {
            double a = -Math.PI / 2.0 + k * Math.PI / 5.0;
            float rr = (k & 1) == 0 ? 6.0f : 2.6f;
            float u = 12f + rr * (float) Math.cos(a), v = 12.6f + rr * (float) Math.sin(a);
            if (k == 0) m(P, u, v); else l(P, u, v);
        }
        P.close();
        fillCol(p, 0xFFFFFFFF); c.drawPath(P, p);
    }

    private static void mystery(Canvas c, Paint p) {
        // gift style crate with a question mark
        rect(3.2f, 3.2f, 20.8f, 20.8f);
        fillCol(p, 0xFF7E57C2); c.drawRoundRect(R, 3.2f * s, 3.2f * s, p);
        rect(3.2f, 3.2f, 20.8f, 10f);
        fillCol(p, 0xFF9575CD); c.drawRoundRect(R, 3.2f * s, 3.2f * s, p);
        strokeCol(p, 0xFFFFFFFF, 1.5f);
        rect(3.2f, 3.2f, 20.8f, 20.8f); c.drawRoundRect(R, 3.2f * s, 3.2f * s, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(17f * s);
        c.drawText("?", X(12f), Y(18.2f), p);
    }
}
