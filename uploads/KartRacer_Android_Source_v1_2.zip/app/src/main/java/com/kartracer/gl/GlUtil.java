package com.kartracer.gl;

import android.opengl.GLES30;

import com.kartracer.util.Diag;

import java.util.HashMap;

/** Shader compilation helpers and a program wrapper with cached uniform locations. */
public final class GlUtil {
    private GlUtil() {}

    public static final class Prog {
        public final int id;
        public final String name;
        private final HashMap<String, Integer> locs = new HashMap<String, Integer>();

        Prog(int id, String name) { this.id = id; this.name = name; }

        public int u(String n) {
            Integer l = locs.get(n);
            if (l == null) { l = GLES30.glGetUniformLocation(id, n); locs.put(n, l); }
            return l;
        }

        public void use() { GLES30.glUseProgram(id); }
        public void set1i(String n, int v) { GLES30.glUniform1i(u(n), v); }
        public void set1f(String n, float v) { GLES30.glUniform1f(u(n), v); }
        public void set2f(String n, float a, float b) { GLES30.glUniform2f(u(n), a, b); }
        public void set3f(String n, float a, float b, float c) { GLES30.glUniform3f(u(n), a, b, c); }
        public void setMat(String n, float[] m) { GLES30.glUniformMatrix4fv(u(n), 1, false, m, 0); }
        public void setRgb(String n, int hex) {
            GLES30.glUniform3f(u(n), ((hex >> 16) & 255) / 255f, ((hex >> 8) & 255) / 255f, (hex & 255) / 255f);
        }
    }

    private static int compile(int type, String src, String name) {
        int s = GLES30.glCreateShader(type);
        GLES30.glShaderSource(s, src);
        GLES30.glCompileShader(s);
        int[] ok = new int[1];
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES30.glGetShaderInfoLog(s);
            GLES30.glDeleteShader(s);
            Diag.log("GL", "shader compile failed (" + name + (type == GLES30.GL_VERTEX_SHADER ? " vs" : " fs") + "): " + log);
            throw new RuntimeException("Shader compile failed: " + name + "\n" + log);
        }
        return s;
    }

    public static Prog program(String name, String vs, String fs, String defines) {
        String d = defines == null ? "" : defines;
        String vsrc = vs.replaceFirst("\n", "\n" + d);
        String fsrc = fs.replaceFirst("\n", "\n" + d);
        int v = compile(GLES30.GL_VERTEX_SHADER, vsrc, name);
        int f = compile(GLES30.GL_FRAGMENT_SHADER, fsrc, name);
        int p = GLES30.glCreateProgram();
        GLES30.glAttachShader(p, v);
        GLES30.glAttachShader(p, f);
        GLES30.glLinkProgram(p);
        int[] ok = new int[1];
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0);
        if (ok[0] == 0) {
            String log = GLES30.glGetProgramInfoLog(p);
            Diag.log("GL", "program link failed (" + name + "): " + log);
            throw new RuntimeException("Program link failed: " + name + "\n" + log);
        }
        GLES30.glDeleteShader(v);
        GLES30.glDeleteShader(f);
        return new Prog(p, name);
    }

    public static boolean checkError(String where) {
        int e = GLES30.glGetError();
        if (e != GLES30.GL_NO_ERROR) {
            Diag.log("GL", "glError 0x" + Integer.toHexString(e) + " at " + where);
            return true;
        }
        return false;
    }
}
