package com.kartracer.util;

/** Deterministic xorshift RNG so every device generates identical worlds. */
public final class Rng {
    private int s;

    public Rng(long seed) {
        int x = (int) (seed ^ (seed >>> 32)) * 0x9E3779B1;
        s = x == 0 ? 0x1234567 : x;
        for (int i = 0; i < 4; i++) nextInt();
    }

    public int nextInt() {
        int x = s;
        x ^= x << 13;
        x ^= x >>> 17;
        x ^= x << 5;
        s = x;
        return x;
    }

    /** [0,1) */
    public float next() { return (nextInt() >>> 8) * (1f / 16777216f); }
    public float range(float a, float b) { return a + (b - a) * next(); }
    public int nextInt(int n) { return (int) ((nextInt() >>> 1) % n); }
    public boolean chance(float p) { return next() < p; }
}
