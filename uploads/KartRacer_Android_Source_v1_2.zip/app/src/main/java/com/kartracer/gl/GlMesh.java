package com.kartracer.gl;

import android.opengl.GLES30;

import com.kartracer.gfx.MeshData;

import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ByteBuffer;

/** Static mesh on the GPU, optionally with a per-instance buffer (location 4/5, divisor 1). */
public final class GlMesh {
    public final MeshData data;
    private final int instCap;
    private int vao, vbo, ibo, inst;
    private FloatBuffer instBuf;

    public GlMesh(MeshData data, int instCap) {
        this.data = data;
        this.instCap = instCap;
    }

    public void upload() {
        int[] id = new int[1];
        GLES30.glGenVertexArrays(1, id, 0); vao = id[0];
        GLES30.glGenBuffers(1, id, 0); vbo = id[0];
        GLES30.glGenBuffers(1, id, 0); ibo = id[0];
        GLES30.glBindVertexArray(vao);
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, vbo);
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, data.verts.length, data.vertexBuffer(), GLES30.GL_STATIC_DRAW);
        int s = MeshData.STRIDE;
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, s, 0);
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 4, GLES30.GL_BYTE, true, s, 12);
        GLES30.glEnableVertexAttribArray(2); GLES30.glVertexAttribPointer(2, 4, GLES30.GL_UNSIGNED_BYTE, true, s, 16);
        GLES30.glEnableVertexAttribArray(3); GLES30.glVertexAttribPointer(3, 2, GLES30.GL_FLOAT, false, s, 20);
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, ibo);
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, data.icount * 2, data.indexBuffer(), GLES30.GL_STATIC_DRAW);
        if (instCap > 0) {
            GLES30.glGenBuffers(1, id, 0); inst = id[0];
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, inst);
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, instCap * 32, null, GLES30.GL_STREAM_DRAW);
            GLES30.glEnableVertexAttribArray(4); GLES30.glVertexAttribPointer(4, 4, GLES30.GL_FLOAT, false, 32, 0); GLES30.glVertexAttribDivisor(4, 1);
            GLES30.glEnableVertexAttribArray(5); GLES30.glVertexAttribPointer(5, 4, GLES30.GL_FLOAT, false, 32, 16); GLES30.glVertexAttribDivisor(5, 1);
            if (instBuf == null) instBuf = ByteBuffer.allocateDirect(instCap * 32).order(ByteOrder.nativeOrder()).asFloatBuffer();
        }
        GLES30.glBindVertexArray(0);
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0);
    }

    public FloatBuffer instanceBuffer() { return instBuf; }
    public int capacity() { return instCap; }

    public void draw() {
        GLES30.glBindVertexArray(vao);
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, data.icount, GLES30.GL_UNSIGNED_SHORT, 0);
    }

    /** Uploads the first `count` instances written into instanceBuffer() and draws them. */
    public void drawInstances(int count) {
        if (count <= 0) return;
        if (count > instCap) count = instCap;
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, inst);
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, instCap * 32, null, GLES30.GL_STREAM_DRAW);
        instBuf.position(0);
        GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, count * 32, instBuf);
        GLES30.glBindVertexArray(vao);
        GLES30.glDrawElementsInstanced(GLES30.GL_TRIANGLES, data.icount, GLES30.GL_UNSIGNED_SHORT, 0, count);
    }

    public void release() {
        int[] id = {vao};
        GLES30.glDeleteVertexArrays(1, id, 0);
        int[] b = {vbo, ibo, inst};
        GLES30.glDeleteBuffers(3, b, 0);
        vao = vbo = ibo = inst = 0;
    }
}
