package com.kartracer.app;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Log;

import com.kartracer.util.Diag;

import java.io.File;
import java.io.FileWriter;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Persists the in-app diagnostic log to a file and can export it where the user can find it (Downloads). */
public final class DiagLog {
    private DiagLog() {}

    private static File file, crashFlag;
    private static PrintWriter out;

    public static synchronized void init(Context c) {
        try {
            file = new File(c.getFilesDir(), "kartracer-log.txt");
            crashFlag = new File(c.getFilesDir(), "crash.flag");
            if (file.exists() && file.length() > 400 * 1024) file.delete();
            out = new PrintWriter(new FileWriter(file, true), true);
            out.println("---- session " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()) + " ----");
        } catch (Exception e) {
            out = null;
        }
        Diag.setSink(new Diag.Sink() {
            @Override public void line(String s) {
                Log.i("KartRacer", s);
                synchronized (DiagLog.class) { if (out != null) out.println(s); }
            }
        });
        Diag.log("App", "Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") " + Build.MANUFACTURER + " " + Build.MODEL
                + ", cores=" + Runtime.getRuntime().availableProcessors() + ", maxHeap=" + (Runtime.getRuntime().maxMemory() / 1048576) + "MB");
    }

    public static synchronized void markCrash() {
        try { if (crashFlag != null) crashFlag.createNewFile(); } catch (Exception ignored) { }
        if (out != null) out.flush();
    }

    public static synchronized boolean crashedLastTime() { return crashFlag != null && crashFlag.exists(); }
    public static synchronized void clearCrashFlag() { if (crashFlag != null) crashFlag.delete(); }

    /** Whole file (previous sessions + this one). */
    public static synchronized String readAll() {
        try {
            if (file == null || !file.exists()) return Diag.dump();
            java.io.FileInputStream in = new java.io.FileInputStream(file);
            byte[] b = new byte[(int) Math.min(file.length(), 600 * 1024)];
            int off = Math.max(0, (int) file.length() - b.length);
            in.skip(off);
            int n = in.read(b);
            in.close();
            return new String(b, 0, Math.max(0, n), "UTF-8");
        } catch (Exception e) {
            return Diag.dump();
        }
    }

    /** Saves the log as a text file in Downloads/KartRacer (or the app's external files dir on old Android). Returns a human readable location or null. */
    public static String export(Context c) {
        String text = readAll();
        String name = "kartracer-log-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date()) + ".txt";
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/KartRacer");
                Uri uri = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return null;
                OutputStream os = c.getContentResolver().openOutputStream(uri);
                os.write(text.getBytes("UTF-8"));
                os.close();
                return "Downloads/KartRacer/" + name;
            } else {
                File dir = c.getExternalFilesDir(null);
                if (dir == null) dir = c.getFilesDir();
                File f = new File(dir, name);
                java.io.FileOutputStream os = new java.io.FileOutputStream(f);
                os.write(text.getBytes("UTF-8"));
                os.close();
                return f.getAbsolutePath();
            }
        } catch (Exception e) {
            Diag.err("Diag", "export failed", e);
            return null;
        }
    }
}
