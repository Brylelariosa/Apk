package com.kartracer.world;

import com.kartracer.util.MathX;

/** A resampled road polyline with tangents, arc length and curvature. */
public final class Road {
    public int n;
    public boolean closed;
    public int surface;
    public float[] x, z, y, w, tx, tz, s, curv;
    public float length;

    public static Road fromControl(float[][] ctrl, boolean closed, float step, int surface) {
        return fromControl(ctrl, closed, step, surface, false);
    }

    public static Road fromControl(float[][] ctrl, boolean closed, float step, int surface, boolean helpers) {
        float[][] p = Spline.resample(ctrl, closed, step, helpers);
        Road r = new Road();
        r.closed = closed;
        r.surface = surface;
        r.n = p.length;
        int n = r.n;
        r.x = new float[n]; r.z = new float[n]; r.y = new float[n]; r.w = new float[n];
        r.tx = new float[n]; r.tz = new float[n]; r.s = new float[n]; r.curv = new float[n];
        for (int i = 0; i < n; i++) { r.x[i] = p[i][0]; r.z[i] = p[i][1]; r.y[i] = p[i][2]; r.w[i] = p[i][3]; }
        for (int i = 0; i < n; i++) {
            int a = closed ? (i - 1 + n) % n : Math.max(0, i - 1);
            int b = closed ? (i + 1) % n : Math.min(n - 1, i + 1);
            float dx = r.x[b] - r.x[a], dz = r.z[b] - r.z[a];
            float l = (float) Math.sqrt(dx * dx + dz * dz);
            if (l < 1e-6f) { dx = 0f; dz = -1f; l = 1f; }
            r.tx[i] = dx / l; r.tz[i] = dz / l;
        }
        float acc = 0f;
        for (int i = 1; i < n; i++) {
            acc += MathX.len2(r.x[i] - r.x[i - 1], r.z[i] - r.z[i - 1]);
            r.s[i] = acc;
        }
        r.length = closed ? acc + MathX.len2(r.x[0] - r.x[n - 1], r.z[0] - r.z[n - 1]) : acc;
        // curvature (positive = right turn, since yaw grows to the right)
        float[] raw = new float[n];
        for (int i = 0; i < n; i++) {
            int a = closed ? (i - 1 + n) % n : Math.max(0, i - 1);
            int b = closed ? (i + 1) % n : Math.min(n - 1, i + 1);
            float ha = (float) Math.atan2(r.tx[a], -r.tz[a]);
            float hb = (float) Math.atan2(r.tx[b], -r.tz[b]);
            float ds = MathX.len2(r.x[b] - r.x[a], r.z[b] - r.z[a]);
            raw[i] = ds > 1e-4f ? MathX.angleDiff(hb, ha) / ds : 0f;
        }
        for (int i = 0; i < n; i++) {
            float sum = 0f; int c = 0;
            for (int k = -3; k <= 3; k++) {
                int j = i + k;
                if (closed) j = (j % n + n) % n; else if (j < 0 || j >= n) continue;
                sum += raw[j]; c++;
            }
            r.curv[i] = sum / c;
        }
        return r;
    }

    /** Shifts the sample order so that sample k becomes index 0 (closed roads only). */
    public void rotate(int k) {
        if (!closed || k == 0) return;
        float[][] arrs = {x, z, y, w, tx, tz, curv};
        for (float[] a : arrs) {
            float[] t = new float[n];
            for (int i = 0; i < n; i++) t[i] = a[(i + k) % n];
            System.arraycopy(t, 0, a, 0, n);
        }
        float acc = 0f;
        s[0] = 0f;
        for (int i = 1; i < n; i++) { acc += MathX.len2(x[i] - x[i - 1], z[i] - z[i - 1]); s[i] = acc; }
        length = acc + MathX.len2(x[0] - x[n - 1], z[0] - z[n - 1]);
    }

    public int wrap(int i) { return closed ? ((i % n) + n) % n : MathX.clamp(i, 0, n - 1); }
}
