package com.kartracer.audio;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;

import com.kartracer.util.Diag;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Plays the procedural sound effects through a SoundPool. The effects are synthesised by {@link SfxSynth} on a
 * background thread at start-up, written as small WAV files into the app cache and loaded into the pool.
 * All methods are safe to call from any thread and do nothing until loading has finished.
 */
public final class Sfx {
    private Sfx() {}

    /** Bump when the synthesizer output changes so stale cache files are rebuilt. */
    private static final int VERSION = 1;
    private static final Object LOCK = new Object();
    private static final int[] sampleId = new int[Snd.COUNT];
    private static final long[] lastMs = new long[Snd.COUNT];
    private static volatile SoundPool pool;
    private static volatile boolean enabled = true;
    private static volatile float master = 0.8f;
    private static boolean started;
    private static int engineStream, skidStream;

    /** Starts loading in the background (safe to call more than once). */
    public static void init(Context ctx) {
        synchronized (LOCK) {
            if (started) return;
            started = true;
        }
        final File dir = new File(ctx.getApplicationContext().getCacheDir(), "sfx" + VERSION);
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                try {
                    load(dir);
                } catch (Throwable e) {
                    Diag.err("Sfx", "sound setup failed", e);
                }
            }
        }, "sfx-init");
        t.setPriority(Thread.MIN_PRIORITY);
        t.start();
    }

    /** Applies the user's sound settings (switch and 0..100 volume). */
    public static void configure(boolean on, int volumePercent) {
        enabled = on;
        master = Math.max(0f, Math.min(1f, volumePercent / 100f));
        if (!on) stopLoops();
    }

    public static boolean isEnabled() { return enabled; }

    private static void load(File dir) throws IOException {
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        SoundPool sp = new SoundPool.Builder().setMaxStreams(16).setAudioAttributes(aa).build();
        if (!dir.isDirectory() && !dir.mkdirs()) Diag.log("Sfx", "could not create " + dir);
        for (int id = 0; id < Snd.COUNT; id++) {
            File f = new File(dir, "s" + id + ".wav");
            if (!f.isFile() || f.length() < 100) writeWav(f, SfxSynth.make(id));
            sampleId[id] = sp.load(f.getAbsolutePath(), 1);
        }
        pool = sp;
        Diag.log("Sfx", "loaded " + Snd.COUNT + " sounds");
    }

    private static void writeWav(File f, short[] pcm) throws IOException {
        int dataLen = pcm.length * 2;
        byte[] out = new byte[44 + dataLen];
        put(out, 0, "RIFF"); putInt(out, 4, 36 + dataLen); put(out, 8, "WAVE"); put(out, 12, "fmt "); putInt(out, 16, 16);
        putShort(out, 20, 1); putShort(out, 22, 1); putInt(out, 24, SfxSynth.RATE); putInt(out, 28, SfxSynth.RATE * 2);
        putShort(out, 32, 2); putShort(out, 34, 16); put(out, 36, "data"); putInt(out, 40, dataLen);
        for (int i = 0; i < pcm.length; i++) { out[44 + i * 2] = (byte) pcm[i]; out[45 + i * 2] = (byte) (pcm[i] >> 8); }
        File tmp = new File(f.getPath() + ".tmp");
        FileOutputStream fo = new FileOutputStream(tmp);
        try { fo.write(out); } finally { fo.close(); }
        if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) throw new IOException("rename failed " + f); }
    }

    private static void put(byte[] b, int o, String s) { for (int i = 0; i < s.length(); i++) b[o + i] = (byte) s.charAt(i); }
    private static void putInt(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }
    private static void putShort(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }

    // ------------------------------------------------------------------ one shots

    public static void play(int id, float vol) { play(id, vol, 1f, 0f); }

    /**
     * @param vol  0..1 loudness before the master volume
     * @param rate playback speed (0.5..2), also changes the pitch
     * @param pan  -1 (left) .. 1 (right)
     */
    public static void play(int id, float vol, float rate, float pan) {
        SoundPool p = pool;
        if (p == null || !enabled || id < 0 || id >= Snd.COUNT) return;
        float v = Math.min(1f, vol * master);
        if (v < 0.02f) return;
        long now = System.currentTimeMillis();
        if (now - lastMs[id] < 35L) return; // never stack the same sound on top of itself in one instant
        lastMs[id] = now;
        float l = v, r = v;
        if (pan > 0f) l = v * (1f - 0.65f * Math.min(1f, pan));
        else if (pan < 0f) r = v * (1f + 0.65f * Math.max(-1f, pan));
        p.play(sampleId[id], l, r, 1, 0, Math.max(0.5f, Math.min(2f, rate)));
    }

    /** Menu click. */
    public static void click() { play(Snd.CLICK, 0.6f); }

    // ------------------------------------------------------------------ loops

    /** Keeps the engine loop running (or stops it). Call every frame while racing. */
    public static void engine(boolean on, float rate, float vol) {
        SoundPool p = pool;
        if (p == null) return;
        if ((!on || !enabled) && engineStream == 0) return;
        synchronized (LOCK) {
            float v = Math.min(1f, vol * master);
            if (!on || !enabled || v < 0.02f) {
                if (engineStream != 0) { p.stop(engineStream); engineStream = 0; }
                return;
            }
            float r = Math.max(0.5f, Math.min(2f, rate));
            if (engineStream == 0) engineStream = p.play(sampleId[Snd.ENGINE], v, v, 2, -1, r);
            else { p.setRate(engineStream, r); p.setVolume(engineStream, v, v); }
        }
    }

    /** Tyre squeal: pass 0 to stop. */
    public static void skid(float vol) {
        SoundPool p = pool;
        if (p == null) return;
        if ((vol <= 0.02f || !enabled) && skidStream == 0) return;
        synchronized (LOCK) {
            float v = Math.min(1f, vol * master);
            if (vol <= 0.02f || !enabled || v < 0.02f) {
                if (skidStream != 0) { p.stop(skidStream); skidStream = 0; }
                return;
            }
            if (skidStream == 0) skidStream = p.play(sampleId[Snd.SKID], v, v, 2, -1, 1f);
            else p.setVolume(skidStream, v, v);
        }
    }

    private static void stopLoops() {
        SoundPool p = pool;
        if (p == null) return;
        synchronized (LOCK) {
            if (engineStream != 0) { p.stop(engineStream); engineStream = 0; }
            if (skidStream != 0) { p.stop(skidStream); skidStream = 0; }
        }
    }

    /** Call from the activity's onPause. */
    public static void pauseAll() {
        SoundPool p = pool;
        if (p != null) p.autoPause();
    }

    /** Call from the activity's onResume. */
    public static void resumeAll() {
        SoundPool p = pool;
        if (p != null) p.autoResume();
    }

    /** Call from the activity's onDestroy. */
    public static void release() {
        SoundPool p;
        synchronized (LOCK) {
            p = pool;
            pool = null;
            engineStream = 0;
            skidStream = 0;
            started = false;
        }
        if (p != null) p.release();
    }
}
