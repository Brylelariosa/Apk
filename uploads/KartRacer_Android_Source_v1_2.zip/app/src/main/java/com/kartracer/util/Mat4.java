package com.kartracer.util;

/** Column-major 4x4 matrices on float[16] (OpenGL layout). Not thread safe (shared scratch). */
public final class Mat4 {
    private Mat4() {}

    private static final float[] T = new float[16];

    public static float[] create() { float[] m = new float[16]; identity(m); return m; }

    public static void identity(float[] m) {
        for (int i = 0; i < 16; i++) m[i] = 0f;
        m[0] = m[5] = m[10] = m[15] = 1f;
    }

    public static void copy(float[] dst, float[] src) { System.arraycopy(src, 0, dst, 0, 16); }

    /** out = a * b (b is applied first). out may alias a or b. */
    public static void mul(float[] out, float[] a, float[] b) {
        for (int c = 0; c < 4; c++) {
            for (int r = 0; r < 4; r++) {
                T[c * 4 + r] = a[r] * b[c * 4] + a[4 + r] * b[c * 4 + 1]
                        + a[8 + r] * b[c * 4 + 2] + a[12 + r] * b[c * 4 + 3];
            }
        }
        System.arraycopy(T, 0, out, 0, 16);
    }

    public static void rotationX(float[] m, float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        identity(m); m[5] = c; m[6] = s; m[9] = -s; m[10] = c;
    }

    public static void rotationY(float[] m, float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        identity(m); m[0] = c; m[2] = -s; m[8] = s; m[10] = c;
    }

    public static void rotationZ(float[] m, float a) {
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        identity(m); m[0] = c; m[1] = s; m[4] = -s; m[5] = c;
    }

    public static void translation(float[] m, float x, float y, float z) {
        identity(m); m[12] = x; m[13] = y; m[14] = z;
    }

    public static void scaling(float[] m, float x, float y, float z) {
        identity(m); m[0] = x; m[5] = y; m[10] = z;
    }

    /** Rotation for a kart-style yaw: model -Z maps to (sin yaw, 0, -cos yaw), model +X to (cos yaw, 0, sin yaw). */
    public static void yaw(float[] m, float yaw, float px, float py, float pz) {
        float c = (float) Math.cos(yaw), s = (float) Math.sin(yaw);
        identity(m);
        m[0] = c; m[2] = s;
        m[8] = -s; m[10] = c;
        m[12] = px; m[13] = py; m[14] = pz;
    }

    /** Build from basis vectors (columns) and translation. */
    public static void basis(float[] m, float rx, float ry, float rz, float ux, float uy, float uz,
                             float bx, float by, float bz, float px, float py, float pz) {
        m[0] = rx; m[1] = ry; m[2] = rz; m[3] = 0f;
        m[4] = ux; m[5] = uy; m[6] = uz; m[7] = 0f;
        m[8] = bx; m[9] = by; m[10] = bz; m[11] = 0f;
        m[12] = px; m[13] = py; m[14] = pz; m[15] = 1f;
    }

    public static void perspective(float[] m, float fovy, float aspect, float near, float far) {
        float f = 1f / (float) Math.tan(fovy * 0.5f);
        for (int i = 0; i < 16; i++) m[i] = 0f;
        m[0] = f / aspect; m[5] = f;
        m[10] = (far + near) / (near - far); m[11] = -1f;
        m[14] = 2f * far * near / (near - far);
    }

    public static void ortho(float[] m, float l, float r, float b, float t, float n, float f) {
        identity(m);
        m[0] = 2f / (r - l); m[5] = 2f / (t - b); m[10] = -2f / (f - n);
        m[12] = -(r + l) / (r - l); m[13] = -(t + b) / (t - b); m[14] = -(f + n) / (f - n);
    }

    public static void lookAt(float[] m, float ex, float ey, float ez, float cx, float cy, float cz,
                              float ux, float uy, float uz) {
        float fx = cx - ex, fy = cy - ey, fz = cz - ez;
        float fl = 1f / (float) Math.sqrt(fx * fx + fy * fy + fz * fz);
        fx *= fl; fy *= fl; fz *= fl;
        float sx = fy * uz - fz * uy, sy = fz * ux - fx * uz, sz = fx * uy - fy * ux;
        float sl = 1f / (float) Math.sqrt(sx * sx + sy * sy + sz * sz);
        sx *= sl; sy *= sl; sz *= sl;
        float tx = sy * fz - sz * fy, ty = sz * fx - sx * fz, tz = sx * fy - sy * fx;
        m[0] = sx; m[1] = tx; m[2] = -fx; m[3] = 0f;
        m[4] = sy; m[5] = ty; m[6] = -fy; m[7] = 0f;
        m[8] = sz; m[9] = tz; m[10] = -fz; m[11] = 0f;
        m[12] = -(sx * ex + sy * ey + sz * ez);
        m[13] = -(tx * ex + ty * ey + tz * ez);
        m[14] = fx * ex + fy * ey + fz * ez;
        m[15] = 1f;
    }

    /** Extracts 6 normalized frustum planes (nx,ny,nz,d) from a view-projection matrix. */
    public static void frustum(float[] vp, float[] planes) {
        for (int i = 0; i < 6; i++) {
            int axis = i >> 1;
            float sg = (i & 1) == 0 ? 1f : -1f;
            float a = vp[3] + sg * vp[axis];
            float b = vp[7] + sg * vp[4 + axis];
            float c = vp[11] + sg * vp[8 + axis];
            float d = vp[15] + sg * vp[12 + axis];
            float l = (float) Math.sqrt(a * a + b * b + c * c);
            if (l < 1e-9f) l = 1f;
            planes[i * 4] = a / l; planes[i * 4 + 1] = b / l; planes[i * 4 + 2] = c / l; planes[i * 4 + 3] = d / l;
        }
    }

    public static boolean sphereVisible(float[] planes, float x, float y, float z, float r) {
        for (int i = 0; i < 6; i++) {
            if (planes[i * 4] * x + planes[i * 4 + 1] * y + planes[i * 4 + 2] * z + planes[i * 4 + 3] < -r) return false;
        }
        return true;
    }
}
