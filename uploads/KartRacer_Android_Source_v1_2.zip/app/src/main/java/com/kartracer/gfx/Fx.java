package com.kartracer.gfx;

import com.kartracer.sim.FxEvents;
import com.kartracer.sim.Kart;
import com.kartracer.sim.Race;
import com.kartracer.util.MathX;
import com.kartracer.util.Rng;
import com.kartracer.world.Surf;
import com.kartracer.world.TrackData;

/** Turns simulation events and kart state into particles, skid marks and blob shadows. */
public final class Fx {
    public static final int SKID_CAP = 700;
    public static final int DECAL_FLOATS = 7;

    public final ParticleSystem ps;
    public final float[] skid = new float[SKID_CAP * 6 * DECAL_FLOATS];
    public int skidQuads;
    private int skidHead;
    public final float[] blob = new float[8 * 6 * DECAL_FLOATS];
    public int blobVerts;

    private final Rng rng = new Rng(4242);
    private final float[] acc = new float[24];
    private final float[][] lastSkid = new float[16][3];
    private float ambAcc, craterAcc;

    private static final float[][] DUST = {{0.72f, 0.70f, 0.66f}, {0.68f, 0.54f, 0.38f}, {0.90f, 0.80f, 0.60f}, {0.52f, 0.60f, 0.36f},
            {0.44f, 0.34f, 0.24f}, {0.60f, 0.58f, 0.60f}, {0.90f, 0.96f, 1.0f}, {1f, 0.5f, 0.2f}, {0.7f, 0.6f, 0.5f}};
    private static final float[][] LEVEL_COL = {{0.8f, 0.85f, 1f}, {0.35f, 0.65f, 1f}, {1f, 0.65f, 0.15f}, {0.85f, 0.35f, 1f}};

    public Fx(int cap) { ps = new ParticleSystem(cap); }

    public void reset() {
        ps.clear(); skidQuads = 0; skidHead = 0;
        for (float[] l : lastSkid) l[2] = 0f;
    }

    private float rnd(float a, float b) { return rng.range(a, b); }

    private void puff(float x, float y, float z, float spd, float up, float s0, float s1, float life, float r, float g, float b, float a, boolean add) {
        float ang = rnd(0f, MathX.TAU), sp = rnd(0.2f, 1f) * spd;
        ps.emit(add, x, y, z, (float) Math.cos(ang) * sp, rnd(0.3f, 1f) * up, (float) Math.sin(ang) * sp, s0, s1, life * rnd(0.7f, 1.2f), r, g, b, a, 1.6f, add ? 0f : -0.5f);
    }

    // ---------------------------------------------------------------- events

    public void processEvents(Race race, int localSlot, CameraRig cam, HudData hud) {
        FxEvents e = race.fx;
        for (int i = 0; i < e.count; i++) {
            float x = e.x[i], y = e.y[i], z = e.z[i], a = e.a[i];
            switch (e.type[i]) {
                case FxEvents.BOOST:
                    for (int k = 0; k < 14; k++) puff(x, y + 0.5f, z, 4f, 3f, 0.5f, 0.1f, 0.5f, 1f, 0.6f, 0.15f, 1f, true);
                    break;
                case FxEvents.HIT:
                case FxEvents.EXPLODE:
                    for (int k = 0; k < 26; k++) puff(x, y, z, 9f, 7f, 0.9f, 0.1f, 0.55f, 1f, rnd(0.4f, 0.8f), 0.1f, 1f, true);
                    for (int k = 0; k < 16; k++) puff(x, y, z, 6f, 4f, 1.6f, 3.4f, 1.1f, 0.25f, 0.23f, 0.22f, 0.7f, false);
                    for (int k = 0; k < 10; k++) ps.emit(true, x, y, z, rnd(-12f, 12f), rnd(4f, 14f), rnd(-12f, 12f), 0.18f, 0.05f, 0.6f, 1f, 0.9f, 0.4f, 1f, 0.5f, 22f);
                    if (e.type[i] == FxEvents.HIT && hud != null && ((int) a != 4)) { /* toast handled by renderer */ }
                    break;
                case FxEvents.SMASH:
                    for (int k = 0; k < 14; k++) ps.emit(false, x, y, z, rnd(-5f, 5f), rnd(2f, 9f), rnd(-5f, 5f), 0.35f, 0.25f, 0.9f, 0.62f, 0.42f, 0.22f, 1f, 0.4f, 24f);
                    for (int k = 0; k < 6; k++) puff(x, y, z, 3f, 1.5f, 0.8f, 2.2f, 0.9f, 0.7f, 0.62f, 0.5f, 0.5f, false);
                    break;
                case FxEvents.LAND: {
                    int n = (int) MathX.clamp(a, 4f, 20f);
                    for (int k = 0; k < n; k++) puff(x, y + 0.1f, z, 5f, 1f, 0.6f, 2.0f, 0.8f, 0.78f, 0.72f, 0.62f, 0.55f, false);
                    break;
                }
                case FxEvents.SPLASH:
                    for (int k = 0; k < 4; k++) ps.emit(false, x, y + 0.1f, z, rnd(-2f, 2f), rnd(2.5f, 5f), rnd(-2f, 2f), 0.28f, 0.1f, 0.7f, 0.85f, 0.95f, 1f, 0.7f, 0.5f, 14f);
                    break;
                case FxEvents.BUMP:
                    for (int k = 0; k < (int) MathX.clamp(a, 3f, 14f); k++) ps.emit(true, x, y, z, rnd(-7f, 7f), rnd(1f, 6f), rnd(-7f, 7f), 0.12f, 0.03f, 0.35f, 1f, 0.85f, 0.35f, 1f, 0.8f, 18f);
                    break;
                case FxEvents.ITEM_PICK:
                    for (int k = 0; k < 18; k++) puff(x, y, z, 5f, 4f, 0.35f, 0.05f, 0.6f, rnd(0.3f, 1f), rnd(0.6f, 1f), 1f, 1f, true);
                    // rainbow stars swirling upwards
                    for (int k = 0; k < 14; k++) {
                        float h = rnd(0f, 1f), ang = rnd(0f, MathX.TAU);
                        ps.emit(true, x, y + 0.4f, z, (float) Math.cos(ang) * 2.4f, rnd(3f, 7f), (float) Math.sin(ang) * 2.4f, 0.3f, 0.04f, 0.8f,
                                0.55f + 0.45f * (float) Math.sin(MathX.TAU * h), 0.55f + 0.45f * (float) Math.sin(MathX.TAU * (h + 0.33f)), 0.55f + 0.45f * (float) Math.sin(MathX.TAU * (h + 0.66f)), 1f, 0.6f, 6f);
                    }
                    break;
                case FxEvents.PAD: {
                    for (int k = 0; k < 10; k++) puff(x, y + 0.2f, z, 4f, 2f, 0.3f, 0.05f, 0.5f, 0.3f, 0.9f, 1f, 1f, true);
                    // streaks shooting forward along the driving direction
                    int ps_ = (int) a;
                    if (ps_ >= 0 && ps_ < race.nKarts) {
                        float yw = race.karts[ps_].yaw, fx = (float) Math.sin(yw), fz = -(float) Math.cos(yw);
                        for (int k = 0; k < 14; k++) ps.emit(true, x + rnd(-1.2f, 1.2f), y + 0.25f, z + rnd(-1.2f, 1.2f), fx * rnd(14f, 24f), rnd(0.2f, 1.2f), fz * rnd(14f, 24f), 0.26f, 0.04f, 0.45f,
                                k % 2 == 0 ? 0.2f : 1f, k % 2 == 0 ? 0.95f : 0.9f, k % 2 == 0 ? 1f : 0.25f, 1f, 1.5f, 0f);
                    }
                    break;
                }
                case FxEvents.LAUNCH:
                    for (int k = 0; k < 8; k++) puff(x, y, z, 3f, 1f, 0.7f, 1.8f, 0.7f, 0.85f, 0.85f, 0.85f, 0.5f, false);
                    if ((int) a == Race.I_ROCKET) {
                        ps.emit(true, x, y + 0.6f, z, 0f, 0f, 0f, 2.2f, 0.3f, 0.18f, 1f, 0.7f, 0.25f, 1f, 0f, 0f);
                        for (int k = 0; k < 10; k++) ps.emit(true, x, y + 0.6f, z, rnd(-3f, 3f), rnd(0f, 3f), rnd(-3f, 3f), 0.3f, 0.04f, 0.4f, 1f, rnd(0.5f, 0.9f), 0.2f, 1f, 1.2f, 4f);
                    } else if ((int) a == Race.I_SLICK) {
                        for (int k = 0; k < 14; k++) ps.emit(false, x, y + 0.2f, z, rnd(-3f, 3f), rnd(2f, 5f), rnd(-3f, 3f), 0.3f, 0.12f, 0.7f, 0.25f, 0.15f, 0.4f, 1f, 0.6f, 14f);
                    } else if ((int) a == Race.I_COCONUT) {
                        for (int k = 0; k < 6; k++) ps.emit(false, x, y + 0.5f, z, rnd(-2f, 2f), rnd(1f, 3f), rnd(-2f, 2f), 0.25f, 0.1f, 0.6f, 0.55f, 0.38f, 0.22f, 1f, 0.8f, 10f);
                    }
                    break;
                case FxEvents.SHIELD_ON:
                    // a ring and sparkles expand outwards from the kart
                    for (int k = 0; k < 24; k++) {
                        float ang = k * MathX.TAU / 24f;
                        ps.emit(true, x + (float) Math.cos(ang) * 0.8f, y + 0.8f, z + (float) Math.sin(ang) * 0.8f, (float) Math.cos(ang) * 6f, rnd(-0.3f, 0.8f), (float) Math.sin(ang) * 6f, 0.35f, 0.05f, 0.6f, 0.35f, 0.8f, 1f, 1f, 2.5f, 0f);
                    }
                    for (int k = 0; k < 12; k++) puff(x, y + 0.8f, z, 3f, 5f, 0.25f, 0.04f, 0.8f, 0.7f, 0.95f, 1f, 1f, true);
                    break;
                case FxEvents.RESPAWN:
                    for (int k = 0; k < 24; k++) puff(x, y + 0.5f, z, 5f, 4f, 0.4f, 0.05f, 0.9f, 0.9f, 0.95f, 1f, 1f, true);
                    break;
                case FxEvents.SHIELD_POP:
                    for (int k = 0; k < 20; k++) puff(x, y, z, 7f, 5f, 0.4f, 0.05f, 0.5f, 0.3f, 0.8f, 1f, 1f, true);
                    break;
                case FxEvents.DRIFT_SPARK: {
                    float[] c = LEVEL_COL[MathX.clamp((int) a, 0, 3)];
                    for (int k = 0; k < 12; k++) ps.emit(true, x, y + 0.3f, z, rnd(-4f, 4f), rnd(2f, 6f), rnd(-4f, 4f), 0.22f, 0.04f, 0.5f, c[0], c[1], c[2], 1f, 0.5f, 16f);
                    break;
                }
                case FxEvents.FINISH:
                    if ((int) a == localSlot || true) for (int k = 0; k < 40; k++) {
                        float r = rnd(0.2f, 1f), g = rnd(0.2f, 1f), b = rnd(0.2f, 1f);
                        ps.emit(false, x + rnd(-3f, 3f), y + 6f, z + rnd(-3f, 3f), rnd(-4f, 4f), rnd(0f, 6f), rnd(-4f, 4f), 0.3f, 0.3f, 2.2f, r, g, b, 1f, 0.8f, 5f);
                    }
                    break;
                default: break;
            }
            if (cam != null && (e.type[i] == FxEvents.BUMP || e.type[i] == FxEvents.LAND || e.type[i] == FxEvents.HIT || e.type[i] == FxEvents.EXPLODE)) {
                Kart me = race.karts[localSlot];
                float dx = me.x - x, dz = me.z - z;
                if (dx * dx + dz * dz < 900f) cam.addShake(e.type[i] == FxEvents.HIT || e.type[i] == FxEvents.EXPLODE ? 0.9f : MathX.clamp(a * 0.04f, 0.15f, 0.7f));
            }
        }
        e.clear();
    }

    // ---------------------------------------------------------------- continuous

    public void update(Race race, float dt, float time, float alpha, float camX, float camY, float camZ, boolean blobShadows) {
        TrackData w = race.track;
        blobVerts = 0;
        for (int i = 0; i < race.nKarts; i++) {
            Kart k = race.karts[i];
            float kx = k.ctrl == Kart.CTRL_REMOTE ? k.x : MathX.lerp(k.ox, k.x, alpha);
            float ky = k.ctrl == Kart.CTRL_REMOTE ? k.y : MathX.lerp(k.oy, k.y, alpha);
            float kz = k.ctrl == Kart.CTRL_REMOTE ? k.z : MathX.lerp(k.oz, k.z, alpha);
            float dxc = kx - camX, dzc = kz - camZ;
            boolean near = dxc * dxc + dzc * dzc < 120f * 120f;
            float sp = k.speed();
            float sy = (float) Math.sin(k.yaw), cy = (float) Math.cos(k.yaw);
            float fx = sy, fz = -cy, rx = cy, rz = sy;
            if (near) wheelEffects(w, k, i, kx, ky, kz, fx, fz, rx, rz, sp, dt);
            if (blobShadows && near) blob(w, k, kx, ky, kz, fx, fz, rx, rz);
            if (k.shield > 0f) {
                float p = 0.5f + 0.5f * (float) Math.sin(time * 6f + i);
                ps.emit(true, kx, ky + 0.8f, kz, 0f, 0f, 0f, 3.2f + p * 0.3f, 3.2f, dt * 1.3f, 0.25f, 0.6f, 1f, k.shield < 2f && ((int) (time * 8) & 1) == 0 ? 0.1f : 0.35f, 0f, 0f);
                // shimmering sparkles drifting over the surface of the bubble
                if (near) {
                    float aa = time * 3.2f + i * 1.7f + rnd(-0.5f, 0.5f), el = rnd(-0.2f, 1.1f), cr = (float) Math.cos(el);
                    ps.emit(true, kx + (float) Math.cos(aa) * cr * 1.7f, ky + 0.8f + (float) Math.sin(el) * 1.5f, kz + (float) Math.sin(aa) * cr * 1.7f, 0f, 0.4f, 0f, 0.22f, 0.04f, 0.45f, 0.6f, 0.92f, 1f, 0.9f, 0.5f, 0f);
                }
            }
        }
        projectileEffects(race, dt, time, camX, camZ);
        boxEffects(race, time, camX, camZ);
        hazardEffects(race, dt, time);
        ambient(w, camX, camY, camZ, dt);
        ps.update(dt);
    }

    private void wheelEffects(TrackData w, Kart k, int idx, float kx, float ky, float kz, float fx, float fz, float rx, float rz, float sp, float dt) {
        float lx = kx - fx * 0.95f, lz = kz - fz * 0.95f;
        float[] dust = DUST[MathX.clamp(k.surface, 0, DUST.length - 1)];
        boolean skidding = k.grounded && (k.drifting || k.spinTime > 0f || (k.in.brake > 0.6f && sp > 14f));
        if (k.grounded && sp > 5f && k.surface != Surf.ROAD || (k.grounded && sp > 12f && k.surface == Surf.ROAD && skidding)) {
            acc[idx] += MathX.clamp((sp - 5f) / 30f, 0f, 1f) * dt * (k.surface == Surf.WATER ? 70f : 45f);
            while (acc[idx] >= 1f) {
                acc[idx] -= 1f;
                float side = rng.chance(0.5f) ? 1f : -1f;
                float px = lx + rx * 0.8f * side, pz = lz + rz * 0.8f * side;
                if (k.surface == Surf.WATER) ps.emit(false, px, ky + 0.1f, pz, rnd(-1.5f, 1.5f) - fx * sp * 0.1f, rnd(2f, 4f), rnd(-1.5f, 1.5f) - fz * sp * 0.1f, 0.3f, 0.12f, 0.6f, 0.85f, 0.95f, 1f, 0.7f, 0.5f, 12f);
                else ps.emit(false, px, ky + 0.15f, pz, rnd(-1f, 1f) - fx * sp * 0.08f, rnd(0.5f, 1.8f), rnd(-1f, 1f) - fz * sp * 0.08f, 0.45f, 1.6f, 0.9f, dust[0], dust[1], dust[2], 0.42f, 1.5f, -0.3f);
            }
        }
        if (k.drifting && k.grounded) {
            float[] c = LEVEL_COL[MathX.clamp(k.driftLevel, 0, 3)];
            for (int s = -1; s <= 1; s += 2) {
                float px = lx + rx * 0.8f * s, pz = lz + rz * 0.8f * s;
                if (rng.chance(0.5f)) ps.emit(false, px, ky + 0.2f, pz, rnd(-0.8f, 0.8f), rnd(0.5f, 1.4f), rnd(-0.8f, 0.8f), 0.4f, 1.8f, 0.8f, 0.9f, 0.9f, 0.92f, 0.4f, 1.5f, -0.4f);
                if (rng.chance(0.6f)) ps.emit(true, px, ky + 0.12f, pz, rnd(-3f, 3f) - fx * 2f, rnd(1f, 3.5f), rnd(-3f, 3f) - fz * 2f, 0.14f, 0.03f, 0.3f, c[0], c[1], c[2], 1f, 0.6f, 12f);
            }
        }
        if (k.boostTime > 0f) {
            float ex = kx - fx * 1.6f, ez = kz - fz * 1.6f;
            for (int s = 0; s < 2; s++) {
                float off = (s == 0 ? -0.22f : 0.22f);
                // outer orange flame, hot white core and a few flying sparks
                ps.emit(true, ex + rx * off, ky + 0.65f, ez + rz * off, -fx * 3.5f + rnd(-0.4f, 0.4f), rnd(-0.2f, 0.6f), -fz * 3.5f + rnd(-0.4f, 0.4f), 0.55f, 0.05f, 0.34f, 1f, rnd(0.4f, 0.75f), 0.1f, 1f, 1.2f, 0f);
                ps.emit(true, ex + rx * off, ky + 0.65f, ez + rz * off, -fx * 2.2f, rnd(-0.1f, 0.3f), -fz * 2.2f, 0.26f, 0.03f, 0.2f, 1f, 0.97f, k.boostTime > 1.2f ? 1f : 0.7f, 1f, 1.2f, 0f);
                if (rng.chance(0.35f)) ps.emit(true, ex + rx * off, ky + 0.6f, ez + rz * off, -fx * rnd(6f, 11f) + rnd(-1f, 1f), rnd(0.5f, 2.5f), -fz * rnd(6f, 11f) + rnd(-1f, 1f), 0.1f, 0.02f, 0.4f, 1f, 0.8f, 0.3f, 1f, 0.6f, 9f);
            }
        }
        if (k.spinTime > 0f && rng.chance(0.5f)) {
            ps.emit(false, kx, ky + 1.8f, kz, rnd(-1f, 1f), 0.5f, rnd(-1f, 1f), 0.5f, 0.3f, 0.7f, 1f, 0.95f, 0.4f, 0.9f, 0.5f, 0f);
        }
        // skid marks on the ground
        for (int s = 0; s < 2; s++) {
            float side = s == 0 ? -1f : 1f;
            float px = lx + rx * 0.8f * side, pz = lz + rz * 0.8f * side;
            float[] ls = lastSkid[(idx % 8) * 2 + s];
            if (skidding && k.surface != Surf.WATER && k.surface != Surf.LAVA) {
                if (ls[2] > 0.5f) {
                    float dx = px - ls[0], dz = pz - ls[1];
                    if (dx * dx + dz * dz > 0.5f * 0.5f && dx * dx + dz * dz < 25f) { addSkid(w, ls[0], ls[1], px, pz); ls[0] = px; ls[1] = pz; }
                } else { ls[0] = px; ls[1] = pz; ls[2] = 1f; }
            } else ls[2] = 0f;
        }
    }

    private float simTime;

    private void addSkid(TrackData w, float x0, float z0, float x1, float z1) {
        float dx = x1 - x0, dz = z1 - z0, l = (float) Math.sqrt(dx * dx + dz * dz);
        if (l < 1e-4f) return;
        float px = -dz / l * 0.17f, pz = dx / l * 0.17f;
        float[] cx = {x0 + px, x0 - px, x1 - px, x1 + px}, cz = {z0 + pz, z0 - pz, z1 - pz, z1 + pz};
        float[] cy = new float[4];
        for (int i = 0; i < 4; i++) cy[i] = w.groundHeight(cx[i], cz[i]) + 0.05f;
        int o = skidHead * 6 * DECAL_FLOATS;
        int[] order = {0, 1, 2, 0, 2, 3};
        for (int v = 0; v < 6; v++) {
            int c = order[v];
            skid[o++] = cx[c]; skid[o++] = cy[c]; skid[o++] = cz[c]; skid[o++] = 0.5f; skid[o++] = 0.5f; skid[o++] = 0.5f; skid[o++] = simTime;
        }
        skidHead = (skidHead + 1) % SKID_CAP;
        skidQuads = Math.min(SKID_CAP, skidQuads + 1);
    }

    public void setTime(float t) { simTime = t; }

    private void blob(TrackData w, Kart k, float kx, float ky, float kz, float fx, float fz, float rx, float rz) {
        if (blobVerts + 6 > 8 * 6) return;
        float gh = w.groundHeight(kx, kz);
        float air = MathX.clamp((ky - gh) / 5f, 0f, 1f);
        float hl = 1.5f - air * 0.4f, hw = 1.15f - air * 0.3f;
        float a = 0.42f * (1f - air * 0.7f);
        float[][] c = {{-hw, -hl, 0, 0}, {hw, -hl, 1, 0}, {hw, hl, 1, 1}, {-hw, hl, 0, 1}};
        int[] order = {0, 1, 2, 0, 2, 3};
        int o = blobVerts * DECAL_FLOATS;
        for (int v = 0; v < 6; v++) {
            float[] p = c[order[v]];
            float x = kx + rx * p[0] + fx * p[1], z = kz + rz * p[0] + fz * p[1];
            blob[o++] = x; blob[o++] = w.groundHeight(x, z) + 0.06f; blob[o++] = z; blob[o++] = p[2]; blob[o++] = p[3]; blob[o++] = a; blob[o++] = 0f;
        }
        blobVerts += 6;
    }

    private float trailAcc;

    /** Exhaust fire and smoke behind rockets, glints on coconuts and bubbles on oil slicks. */
    private void projectileEffects(Race race, float dt, float time, float camX, float camZ) {
        trailAcc += dt;
        boolean tick = trailAcc >= 1f / 45f;
        if (tick) trailAcc = 0f;
        for (int e = 0; e < race.eAlive.length; e++) {
            if (!race.eAlive[e]) continue;
            float x = race.ex[e], y = race.ey[e], z = race.ez[e];
            float dx = x - camX, dz = z - camZ;
            if (dx * dx + dz * dz > 90f * 90f) continue;
            int type = race.eType[e];
            if (type == Race.E_ROCKET) {
                float vx = race.evx[e], vz = race.evz[e], sp = (float) Math.sqrt(vx * vx + vz * vz);
                float ux = sp > 0.1f ? vx / sp : 0f, uz = sp > 0.1f ? vz / sp : 1f;
                for (int k = 0; k < 2; k++) {
                    ps.emit(true, x - ux * 0.7f, y + 0.1f, z - uz * 0.7f, -ux * 6f + rnd(-0.7f, 0.7f), rnd(-0.4f, 0.6f), -uz * 6f + rnd(-0.7f, 0.7f), 0.6f, 0.05f, 0.3f, 1f, rnd(0.45f, 0.8f), 0.12f, 1f, 1.0f, 0f);
                    ps.emit(true, x - ux * 0.55f, y + 0.1f, z - uz * 0.55f, -ux * 3f, 0f, -uz * 3f, 0.28f, 0.03f, 0.18f, 1f, 0.95f, 0.7f, 1f, 1.0f, 0f);
                }
                if (tick) ps.emit(false, x - ux * 1.1f, y + 0.15f, z - uz * 1.1f, rnd(-0.4f, 0.4f), rnd(0.2f, 0.8f), rnd(-0.4f, 0.4f), 0.35f, 1.5f, 0.9f, 0.55f, 0.55f, 0.58f, 0.45f, 1.4f, -0.2f);
            } else if (type == Race.E_COCONUT) {
                if (tick && rng.chance(0.6f)) ps.emit(true, x + rnd(-0.3f, 0.3f), y + rnd(0.1f, 0.5f), z + rnd(-0.3f, 0.3f), 0f, rnd(0.2f, 1f), 0f, 0.16f, 0.03f, 0.35f, 1f, 0.9f, 0.5f, 0.9f, 0.5f, 0f);
            } else if (type == Race.E_SLICK) {
                if (tick && rng.chance(0.25f)) ps.emit(true, x + rnd(-1.1f, 1.1f), y + 0.15f, z + rnd(-1.1f, 1.1f), 0f, rnd(0.3f, 1.0f), 0f, 0.14f, 0.03f, 0.7f, 0.6f, 0.4f, 1f, 0.8f, 0.2f, 0f);
            }
        }
    }

    /** Twinkling stars around item boxes that are ready to be picked up. */
    private void boxEffects(Race race, float time, float camX, float camZ) {
        TrackData w = race.track;
        for (int b = 0; b < race.boxActive.length; b++) {
            if (!race.boxActive[b]) continue;
            float dx = w.boxX[b] - camX, dz = w.boxZ[b] - camZ;
            if (dx * dx + dz * dz > 55f * 55f || !rng.chance(0.22f)) continue;
            float h = rnd(0f, 1f), ang = rnd(0f, MathX.TAU);
            ps.emit(true, w.boxX[b] + (float) Math.cos(ang) * 0.95f, w.boxY[b] + rnd(0.1f, 1.5f), w.boxZ[b] + (float) Math.sin(ang) * 0.95f, 0f, rnd(0.5f, 1.4f), 0f, 0.2f, 0.03f, 0.9f,
                    0.6f + 0.4f * (float) Math.sin(MathX.TAU * h), 0.6f + 0.4f * (float) Math.sin(MathX.TAU * (h + 0.33f)), 0.6f + 0.4f * (float) Math.sin(MathX.TAU * (h + 0.66f)), 0.9f, 0.3f, 0f);
        }
    }

    private final float[] bz0 = new float[2], bz1 = new float[2];

    private void hazardEffects(Race race, float dt, float time) {
        TrackData w = race.track;
        for (int i = 0; i < w.hazards.length; i++) {
            TrackData.Haz h = w.hazards[i];
            if (h.type == 0) {
                // a rolling boulder kicks up dust at its base
                Race.boulderPos(h, race.raceTime, bz0);
                Race.boulderPos(h, race.raceTime + 0.05f, bz1);
                float mv = MathX.len2(bz1[0] - bz0[0], bz1[1] - bz0[1]) / 0.05f;
                if (mv > 1.5f && rng.chance(0.4f)) {
                    float gyb = w.groundHeight(bz0[0], bz0[1]);
                    ps.emit(false, bz0[0] + rnd(-0.8f, 0.8f), gyb + 0.15f, bz0[1] + rnd(-0.8f, 0.8f), rnd(-0.8f, 0.8f), rnd(0.4f, 1.3f), rnd(-0.8f, 0.8f),
                            0.5f, 1.7f, 0.8f, 0.72f, 0.64f, 0.5f, 0.28f, 1.8f, -0.3f);
                }
                continue;
            }
            if (h.type != 1) continue;
            if (Race.geyserActive(h, race.raceTime)) {
                for (int k = 0; k < 5; k++) {
                    ps.emit(false, h.x0 + rnd(-0.6f, 0.6f), h.y + 0.5f, h.z0 + rnd(-0.6f, 0.6f), rnd(-1.2f, 1.2f), rnd(14f, 26f), rnd(-1.2f, 1.2f), 1.2f, 3.2f, 1.0f, 0.95f, 0.95f, 0.95f, 0.6f, 0.3f, 6f);
                    if (k < 2) ps.emit(true, h.x0 + rnd(-0.5f, 0.5f), h.y + 0.5f, h.z0 + rnd(-0.5f, 0.5f), rnd(-1f, 1f), rnd(10f, 20f), rnd(-1f, 1f), 1.0f, 0.4f, 0.7f, 1f, 0.5f, 0.15f, 0.8f, 0.3f, 6f);
                }
            } else if (Race.geyserWarning(h, race.raceTime) && rng.chance(0.5f)) {
                ps.emit(false, h.x0 + rnd(-1f, 1f), h.y + 0.6f, h.z0 + rnd(-1f, 1f), rnd(-0.5f, 0.5f), rnd(1.5f, 3f), rnd(-0.5f, 0.5f), 0.5f, 1.4f, 0.9f, 0.85f, 0.85f, 0.85f, 0.4f, 0.5f, 0f);
                if (rng.chance(0.4f)) ps.emit(true, h.x0 + rnd(-1.4f, 1.4f), h.y + 0.5f, h.z0 + rnd(-1.4f, 1.4f), 0f, rnd(1f, 3f), 0f, 0.3f, 0.05f, 0.6f, 1f, 0.5f, 0.1f, 1f, 0.5f, 0f);
            }
        }
        if (w.def.theme == 2) {
            craterAcc += dt * 14f;
            float cy = w.terrainHeight(0f, 0f) + 4f;
            while (craterAcc >= 1f) {
                craterAcc -= 1f;
                ps.emit(false, rnd(-14f, 14f), cy, rnd(-14f, 14f), rnd(-2f, 2f), rnd(8f, 13f), rnd(-2f, 2f), 14f, 46f, 9f, 0.20f, 0.17f, 0.17f, 0.55f, 0.1f, 0f);
                if (rng.chance(0.3f)) ps.emit(true, rnd(-10f, 10f), cy - 2f, rnd(-10f, 10f), 0f, rnd(5f, 9f), 0f, 10f, 3f, 3f, 1f, 0.4f, 0.1f, 0.35f, 0.1f, 0f);
            }
        }
    }

    private void ambient(TrackData w, float cx, float cy, float cz, float dt) {
        int th = w.def.theme;
        if (th == 0) return;
        ambAcc += dt * (th == 2 ? 26f : 8f);
        while (ambAcc >= 1f) {
            ambAcc -= 1f;
            float x = cx + rnd(-45f, 45f), z = cz + rnd(-45f, 45f), y = w.terrainHeight(x, z) + rnd(0.5f, 8f);
            if (th == 2) ps.emit(true, x, y, z, rnd(-1f, 2f), rnd(2f, 5f), rnd(-1f, 2f), 0.18f, 0.04f, rnd(2f, 4f), 1f, rnd(0.3f, 0.6f), 0.1f, 1f, 0.1f, -0.2f);
            else if (th == 1) ps.emit(true, x, y, z, rnd(-0.4f, 0.4f), rnd(0.1f, 0.5f), rnd(-0.4f, 0.4f), 0.14f, 0.1f, rnd(3f, 5f), 0.85f, 1f, 0.45f, 0.7f, 0.2f, 0f);
            else ps.emit(false, x, y, z, rnd(2f, 5f), rnd(-0.2f, 0.4f), rnd(0.5f, 2f), 0.3f, 0.5f, rnd(2f, 3.5f), 0.9f, 0.78f, 0.55f, 0.18f, 0.1f, 0f);
        }
    }
}
