package com.kartracer.sim;

import com.kartracer.net.Msg;

/** What a race needs from the network layer. Implemented by the host / client sessions. */
public interface RaceNet {
    boolean isHost();
    /** Synchronized host clock in milliseconds. */
    int clockMs();
    /** Client: to host. Host: broadcast to all clients. */
    void sendReliable(Msg m);
    /** Host only: reliable message to one player slot. */
    void sendReliableTo(int slot, Msg m);
    /** Client: kart state to host. Host: snapshot broadcast. */
    void sendFast(Msg m);
    /** Next inbound race message or null. */
    Msg poll();
}
