package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;
import com.kartracer.util.Noise;

/** Procedural textures as RGBA bytes. Small, tileable, mipmapped on upload. */
public final class TexGen {
    private TexGen() {}

    public static final class Tex {
        public final int w, h;
        public final byte[] rgba;
        /** Optional ETC2 compressed mip chain (see Etc), built on a worker thread. */
        public Etc.Level[] etcChain;
        Tex(int w, int h) { this.w = w; this.h = h; rgba = new byte[w * h * 4]; }

        /** Builds the compressed mip chain once (textures of at least 16x16 pixels). */
        public Tex compress() {
            if (etcChain == null && w >= 16 && h >= 16) etcChain = Etc.buildChain(rgba, w, h);
            return this;
        }
        void set(int x, int y, int r, int g, int b, int a) {
            int o = (y * w + x) * 4;
            rgba[o] = (byte) MathX.clamp(r, 0, 255); rgba[o + 1] = (byte) MathX.clamp(g, 0, 255);
            rgba[o + 2] = (byte) MathX.clamp(b, 0, 255); rgba[o + 3] = (byte) MathX.clamp(a, 0, 255);
        }
    }

    public static Tex white() {
        Tex t = new Tex(1, 1);
        t.set(0, 0, 255, 255, 255, 255);
        return t;
    }

    private static float fbmTile(float u, float v, int baseCells, int octaves, int seed) {
        float sum = 0f, amp = 0.5f, norm = 0f;
        int cells = baseCells;
        for (int i = 0; i < octaves; i++) {
            sum += Noise.tile(u * cells, v * cells, cells, seed + i * 13) * amp;
            norm += amp; amp *= 0.5f; cells *= 2;
        }
        return sum / norm;
    }

    /** Gray detail multiplier (about 0.8..1.0). */
    public static Tex detail(int size) {
        Tex t = new Tex(size, size);
        for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
            float n = fbmTile(x / (float) size, y / (float) size, 6, 4, 5);
            int v = (int) (255f * (0.76f + 0.24f * n * 1.25f));
            t.set(x, y, v, v, v, 255);
        }
        return t;
    }

    /** Cloud / generic noise in all channels. */
    public static Tex noise(int size) {
        Tex t = new Tex(size, size);
        for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
            float n = fbmTile(x / (float) size, y / (float) size, 4, 5, 9);
            int v = (int) (255f * MathX.sat((n - 0.25f) * 1.6f));
            t.set(x, y, v, v, v, 255);
        }
        return t;
    }

    private static void put(Tex t, int x, int y, int rgb, float shade) {
        t.set(x, y, (int) (((rgb >> 16) & 255) * shade), (int) (((rgb >> 8) & 255) * shade), (int) ((rgb & 255) * shade), 255);
    }

    /** Road strip: u across (shoulder | edge line | road | edge line | shoulder), v along (12 m per tile). */
    public static Tex road(int theme) {
        int S = 256;
        Tex t = new Tex(S, S);
        int base, line, dash, shoulder;
        boolean lines = true, dashes = true, cracks = false, ruts = false;
        switch (theme) {
            case 1: base = 0xA67C52; line = 0x8A6840; dash = 0xB89060; shoulder = 0x6E6240; lines = false; dashes = false; ruts = true; break;
            case 2: base = 0x37333A; line = 0xFFA028; dash = 0xFFA028; shoulder = 0x463F40; cracks = true; dashes = false; break;
            case 3: base = 0xC49668; line = 0xF2EADA; dash = 0xF2EADA; shoulder = 0xD8B078; break;
            default: base = 0x5C5C62; line = 0xF4F4F4; dash = 0xF0C83C; shoulder = 0xDCC896; break;
        }
        for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
            float u = x / (float) S, v = y / (float) S;
            float n = fbmTile(u, v, 8, 4, 31);
            float fine = Noise.tile(u * 64, v * 64, 64, 77);
            int rgb; float shade = 0.86f + 0.28f * n + 0.06f * fine;
            float edgeU = Math.min(u, 1f - u);
            if (lines && theme != 1 && edgeU >= 0.11f && edgeU < 0.17f) {
                // rumble strips along both road edges
                boolean even = (((int) (v * 16f)) & 1) == 0;
                rgb = theme == 2 ? (even ? 0xFFA028 : 0x1E1A1E) : (even ? 0xD8322E : 0xF4F4F4);
                shade = 0.93f + 0.1f * fine - (n < 0.3f ? 0.12f : 0f);
            } else if (u < 0.14f || u > 0.86f) {
                rgb = shoulder; shade = 0.8f + 0.35f * n;
            } else if (lines && (u < 0.17f || u > 0.83f)) {
                rgb = line; shade = 0.9f + 0.1f * fine - (n < 0.35f ? 0.2f : 0f);
            } else {
                rgb = base;
                float rut = ruts ? Math.max(0f, 1f - Math.abs(u - 0.33f) / 0.06f) + Math.max(0f, 1f - Math.abs(u - 0.67f) / 0.06f) : 0.35f * (Math.max(0f, 1f - Math.abs(u - 0.33f) / 0.07f) + Math.max(0f, 1f - Math.abs(u - 0.67f) / 0.07f));
                shade *= 1f - 0.18f * rut;
                if (ruts) shade *= 1f + 0.12f * Math.max(0f, 1f - Math.abs(u - 0.5f) / 0.08f);
                if (dashes && Math.abs(u - 0.5f) < 0.011f && ((v * 2f) % 1f) < 0.5f) { rgb = dash; shade = 1f; }
                if (cracks) {
                    float gv = (v * 8f) % 1f, gu = ((u - 0.14f) / 0.72f * 5f) % 1f;
                    float edge = Math.min(Math.min(gv, 1f - gv), Math.min(gu, 1f - gu));
                    if (edge < 0.035f) { rgb = Noise.hash((int) (v * 8f), (int) ((u - 0.14f) / 0.72f * 5f), 3) > 0.7f ? 0xFF6A18 : 0x1E1A1E; shade = 1f; }
                }
            }
            put(t, x, y, rgb, shade);
        }
        return t;
    }

    public static Tex dirt() {
        int S = 128;
        Tex t = new Tex(S, S);
        for (int y = 0; y < S; y++) for (int x = 0; x < S; x++) {
            float u = x / (float) S, v = y / (float) S;
            float n = fbmTile(u, v, 8, 3, 47);
            float rut = Math.max(0f, 1f - Math.abs(u - 0.33f) / 0.06f) + Math.max(0f, 1f - Math.abs(u - 0.67f) / 0.06f);
            float shade = (0.88f + 0.3f * n) * (1f - 0.18f * rut);
            if (u < 0.14f || u > 0.86f) shade *= 1.05f;
            put(t, x, y, 0xB08A5E, shade);
        }
        return t;
    }
}
