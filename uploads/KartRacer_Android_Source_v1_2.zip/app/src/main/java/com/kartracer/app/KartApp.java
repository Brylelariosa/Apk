package com.kartracer.app;

import android.app.Application;

import com.kartracer.util.Diag;

public final class KartApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Ui.init(this);
        DiagLog.init(this);
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread t, Throwable e) {
                try {
                    Diag.err("CRASH", "uncaught exception in thread " + t.getName(), e);
                    DiagLog.markCrash();
                } catch (Throwable ignored) { }
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
    }
}
