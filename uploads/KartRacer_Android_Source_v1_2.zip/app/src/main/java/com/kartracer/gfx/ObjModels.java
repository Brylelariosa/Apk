package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;
import com.kartracer.world.TrackData;

/** Gameplay object meshes: item boxes, crates, boulders, vents, boost pads, ramps and the start gate. Alpha = emissive. */
public final class ObjModels {
    private ObjModels() {}

    private static int e(int hex, int emissive) { return Col.withAlpha(Col.hex(hex), emissive); }

    public static MeshData itemBox() {
        MeshBuilder b = new MeshBuilder();
        int bar = e(0x7FE3FF, 190), corner = e(0xFFFFFF, 255);
        float h = 0.8f, t = 0.07f;
        for (int sy = -1; sy <= 1; sy += 2) for (int sz = -1; sz <= 1; sz += 2) b.box(0, sy * h, sz * h, h, t, t, bar);
        for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) b.box(sx * h, 0, sz * h, t, h, t, bar);
        for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) b.box(sx * h, sy * h, 0, t, t, h, bar);
        for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) for (int sz = -1; sz <= 1; sz += 2) b.box(sx * h, sy * h, sz * h, 0.12f, 0.12f, 0.12f, corner);
        int g0 = e(0xFF3DB8, 255), g1 = e(0xFFE14D, 255);
        b.cyl(0, 0, 0, 0.55f, 0f, 0.7f, 4, g0, g1, false, false);
        b.push().rotX(MathX.PI).cyl(0, 0, 0, 0.55f, 0f, 0.7f, 4, g0, g1, false, false).pop();
        return b.build();
    }

    public static MeshData crate() {
        MeshBuilder b = new MeshBuilder();
        int wood = e(0xC08A4E, 0), dark = e(0x7A4E26, 0);
        b.box(0, 0.6f, 0, 0.6f, 0.6f, 0.6f, wood);
        float h = 0.6f, t = 0.07f;
        for (int sy = -1; sy <= 1; sy += 2) for (int sz = -1; sz <= 1; sz += 2) b.box(0, 0.6f + sy * h, sz * h, h + 0.02f, t, t, dark);
        for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) b.box(sx * h, 0.6f, sz * h, t, h + 0.02f, t, dark);
        for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) b.box(sx * h, 0.6f + sy * h, 0, t, t, h + 0.02f, dark);
        b.box(0, 0.6f, 0.61f, 0.5f, 0.06f, 0.01f, dark);
        b.box(0, 0.6f, -0.61f, 0.5f, 0.06f, 0.01f, dark);
        return b.build();
    }

    /** Rolling radius of the swinging boulder. The mesh is centred on its own middle so it rolls without bobbing. */
    public static final float BOULDER_R = 1.6f;

    /** Faceted boulder centred on the origin (the renderer lifts it by BOULDER_R so it sits on the road and rolls around its middle). */
    public static MeshData boulder(int theme) {
        MeshBuilder b = new MeshBuilder();
        int hi = theme == 3 ? 0xD3A472 : (theme == 2 ? 0x8A8392 : (theme == 1 ? 0xB4AFA2 : 0xBDB8AD));
        int lo = theme == 3 ? 0x94664A : (theme == 2 ? 0x4A4552 : 0x75706A);
        int moss = Col.hex(0x5C8038), crack = Col.withAlpha(Col.hex(0xFF6A18), 200);
        int segs = 14, rings = 9;
        float[][][] p = new float[rings + 1][segs + 1][3];
        for (int k = 0; k <= rings; k++) {
            float ph = -MathX.PI / 2f + MathX.PI * k / rings;
            for (int i = 0; i <= segs; i++) {
                int ii = i % segs;
                float th = MathX.TAU * ii / segs;
                float cx = (float) (Math.cos(ph) * Math.cos(th)), cy = (float) Math.sin(ph), cz = (float) (Math.cos(ph) * Math.sin(th));
                float lump = 1f + 0.08f * (float) Math.sin(3.1f * cx + 1.7f * cy + 0.5f) + 0.06f * (float) Math.sin(4.3f * cz - 2.1f * cx + 1.2f)
                        + 0.05f * (float) Math.sin(5.2f * cy + 2.6f * cz) + 0.07f * (com.kartracer.util.Noise.hash(ii, k, 91 + theme) - 0.5f);
                if (k == 0 || k == rings) lump = 1f;
                float r = BOULDER_R * lump;
                p[k][i][0] = cx * r; p[k][i][1] = cy * r * 0.95f; p[k][i][2] = cz * r;
            }
        }
        for (int k = 0; k < rings; k++) for (int i = 0; i < segs; i++) {
            float[][] q = {p[k][i], p[k + 1][i], p[k][i + 1], p[k][i + 1], p[k + 1][i], p[k + 1][i + 1]};
            for (int h = 0; h < 2; h++) {
                float[] a = q[h * 3], bb = q[h * 3 + 1], c = q[h * 3 + 2];
                float ux = bb[0] - a[0], uy = bb[1] - a[1], uz = bb[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
                float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
                float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                float up = nl < 1e-9f ? 0.5f : MathX.sat(ny / nl * 0.5f + 0.5f);
                float rnd = com.kartracer.util.Noise.hash(i * 2 + h, k, 17 + theme);
                int col = Col.mix(lo, hi, MathX.sat(0.18f + 0.5f * rnd + 0.32f * up));
                if (theme == 1 && up > 0.72f && rnd > 0.25f) col = Col.mix(col, moss, 0.6f);
                if (theme == 3 && (((int) Math.floor((a[1] / BOULDER_R + 1f) * 2.2f)) & 1) == 0) col = Col.mix(col, Col.hex(0xE3B98A), 0.35f);
                if (theme == 2 && rnd > 0.9f) col = crack;
                b.flatTri(a[0], a[1], a[2], bb[0], bb[1], bb[2], c[0], c[1], c[2], col);
            }
        }
        return b.build();
    }

    public static MeshData vent(int theme) {
        MeshBuilder b = new MeshBuilder();
        int rock = e(theme == 2 ? 0x3A3640 : 0x6A645C, 0), glow = e(0xFF6A10, 255);
        b.cyl(0, 0, 0, 2.6f, 1.7f, 0.5f, 10, Col.scale(rock, 0.8f), rock, false, false);
        b.cyl(0, 0.45f, 0, 1.7f, 1.55f, 0.08f, 10, glow, glow, false, true);
        return b.build();
    }

    /**
     * Boost pad in local space (forward -Z, centered on the pad). The plate carries its local x/z position as UV and
     * full emissive alpha: the pad shader paints scrolling chevrons on it. The hazard striped rails, end bars and
     * corner beacons are ordinary lit geometry.
     */
    public static MeshData pad(TrackData.Pad p) {
        MeshBuilder b = new MeshBuilder();
        float hl = p.len * 0.5f, hw = p.wid * 0.5f;
        float y = 0.08f;
        int plate = e(0x10243A, 255);
        int v0 = b.vert(-hw, y, hl, 0, 1, 0, plate, -hw, hl), v1 = b.vert(hw, y, hl, 0, 1, 0, plate, hw, hl);
        int v2 = b.vert(hw, y, -hl, 0, 1, 0, plate, hw, -hl), v3 = b.vert(-hw, y, -hl, 0, 1, 0, plate, -hw, -hl);
        b.quad(v0, v1, v2, v3);
        // hazard striped side rails
        int n = Math.max(2, Math.round(p.len / 0.9f));
        float step = p.len / n;
        for (int i = 0; i < n; i++) {
            float zc = -hl + (i + 0.5f) * step;
            int col = (i & 1) == 0 ? e(0xFFC400, 0) : e(0x20242B, 0);
            for (int s = -1; s <= 1; s += 2) b.box(s * (hw + 0.14f), 0.09f, zc, 0.14f, 0.09f, step * 0.5f, col);
        }
        // dark end bars
        int bar = e(0x20242B, 0);
        b.box(0f, 0.06f, hl + 0.1f, hw + 0.28f, 0.06f, 0.1f, bar);
        b.box(0f, 0.06f, -hl - 0.1f, hw + 0.28f, 0.06f, 0.1f, bar);
        // glowing corner beacons
        int post = e(0x20242B, 0), glow = e(0x7DF6FF, 230);
        for (int sx = -1; sx <= 1; sx += 2) for (int sz = -1; sz <= 1; sz += 2) {
            float cx = sx * (hw + 0.14f), cz = sz * (hl + 0.05f);
            b.box(cx, 0.3f, cz, 0.07f, 0.22f, 0.07f, post);
            b.sphere(cx, 0.58f, cz, 0.13f, 8, 6, glow);
        }
        return b.build();
    }

    /** Wooden ramp in local space: starts at origin, rises toward -Z. */
    public static MeshData ramp(TrackData.Ramp r) {
        MeshBuilder b = new MeshBuilder();
        float hw = r.wid * 0.5f, len = r.len, h = r.h;
        float k = h / len;
        float nl = (float) Math.sqrt(1f + k * k);
        int planks = (int) len;
        for (int i = 0; i < planks; i++) {
            float z0 = -len * i / planks, z1 = -len * (i + 1) / planks;
            float y0 = h * i / planks, y1 = h * (i + 1) / planks;
            int col = (i == planks - 1) ? e(0xFFC400, 0) : ((i & 1) == 0 ? e(0xB88A55, 0) : e(0x9C7142, 0));
            int a = b.vert(-hw, y0, z0, 0, 1 / nl, k / nl, col), bb = b.vert(hw, y0, z0, 0, 1 / nl, k / nl, col);
            int c = b.vert(hw, y1, z1, 0, 1 / nl, k / nl, col), d = b.vert(-hw, y1, z1, 0, 1 / nl, k / nl, col);
            b.quad(a, bb, c, d);
        }
        int side = e(0x6E4B2A, 0);
        int l0 = b.vert(-hw, 0, 0, -1, 0, 0, side), l1 = b.vert(-hw, 0, -len, -1, 0, 0, side), l2 = b.vert(-hw, h, -len, -1, 0, 0, side);
        b.tri(l0, l2, l1);
        int r0 = b.vert(hw, 0, 0, 1, 0, 0, side), r1 = b.vert(hw, 0, -len, 1, 0, 0, side), r2 = b.vert(hw, h, -len, 1, 0, 0, side);
        b.tri(r0, r1, r2);
        int q0 = b.vert(-hw, 0, -len, 0, 0, -1, side), q1 = b.vert(hw, 0, -len, 0, 0, -1, side), q2 = b.vert(hw, h, -len, 0, 0, -1, side), q3 = b.vert(-hw, h, -len, 0, 0, -1, side);
        b.quad(q1, q0, q3, q2);
        // side rails
        for (int s = -1; s <= 1; s += 2) {
            b.tube(s * (hw + 0.05f), 0.0f, -0.2f, s * (hw + 0.05f), h + 0.45f, -len + 0.1f, 0.09f, 0.09f, 6, e(0xE53935, 0), e(0xFFFFFF, 0), true);
        }
        return b.build();
    }

    /** Start / finish arch in local space (forward -Z, origin at road center on the line). */
    public static MeshData startGate(float roadWidth, int theme) {
        MeshBuilder b = new MeshBuilder();
        float hw = roadWidth * 0.5f + 1.6f;
        int red = e(0xD32F2F, 0), white = e(0xF5F5F5, 0);
        for (int s = -1; s <= 1; s += 2) {
            for (int i = 0; i < 6; i++) b.tube(s * hw, i * 1.1f, 0, s * hw, (i + 1) * 1.1f, 0, 0.28f, 0.28f, 8, (i & 1) == 0 ? red : white, (i & 1) == 0 ? red : white, false);
            b.sphere(s * hw, 6.7f, 0, 0.35f, 8, 5, red);
        }
        b.box(0, 6.3f, 0, hw + 0.3f, 0.75f, 0.12f, e(0x212121, 0));
        int tiles = (int) (hw * 2f / 0.75f);
        float tw = hw * 2f / tiles;
        for (int i = 0; i < tiles; i++) for (int j = 0; j < 2; j++) {
            int col = ((i + j) & 1) == 0 ? e(0xFFFFFF, 0) : e(0x111111, 0);
            b.box(-hw + tw * (i + 0.5f), 6.3f + (j == 0 ? 0.37f : -0.37f), 0.13f, tw * 0.5f, 0.37f, 0.02f, col);
            b.box(-hw + tw * (i + 0.5f), 6.3f + (j == 0 ? 0.37f : -0.37f), -0.13f, tw * 0.5f, 0.37f, 0.02f, col);
        }
        // checkered line on the road
        float rw = roadWidth * 0.5f;
        int nt = (int) (roadWidth / 1.0f);
        float cw = roadWidth / nt;
        for (int i = 0; i < nt; i++) for (int j = 0; j < 2; j++) {
            int col = ((i + j) & 1) == 0 ? e(0xFFFFFF, 0) : e(0x151515, 0);
            b.box(-rw + cw * (i + 0.5f), 0.06f, (j == 0 ? -0.5f : 0.5f), cw * 0.5f, 0.02f, 0.5f, col);
        }
        return b.build();
    }

    public static MeshData rocket() {
        MeshBuilder b = new MeshBuilder();
        int red = e(0xE53935, 0), white = e(0xF5F5F5, 0), grey = e(0x90A4AE, 0), flame = e(0xFFB020, 255);
        b.tube(0, 0.3f, 0.6f, 0, 0.3f, -0.55f, 0.2f, 0.2f, 8, white, red, true);
        b.tube(0, 0.3f, -0.55f, 0, 0.3f, -1.15f, 0.2f, 0.0f, 8, red, red, false);
        for (int i = 0; i < 4; i++) {
            float a = i * MathX.PI / 2f;
            b.push().translate(0, 0.3f, 0.45f).rotZ(a).box(0, 0.28f, 0, 0.03f, 0.18f, 0.18f, grey).pop();
        }
        b.tube(0, 0.3f, 0.6f, 0, 0.3f, 1.4f, 0.16f, 0.0f, 8, flame, flame, false);
        return b.build();
    }

    public static MeshData coconut() {
        MeshBuilder b = new MeshBuilder();
        b.sphere(0, 0.35f, 0, 0.35f, 10, 7, e(0x5B3A1E, 0));
        b.sphere(0, 0.5f, -0.2f, 0.09f, 6, 4, e(0x2A1A0E, 0));
        b.sphere(-0.12f, 0.45f, -0.25f, 0.07f, 6, 4, e(0x2A1A0E, 0));
        return b.build();
    }

    public static MeshData slick() {
        MeshBuilder b = new MeshBuilder();
        b.cyl(0, 0.04f, 0, 1.7f, 1.7f, 0.0f, 16, e(0x14101C, 0), e(0x14101C, 0), false, true);
        b.cyl(0, 0.05f, 0, 1.2f, 1.2f, 0.0f, 14, e(0x3A2A5A, 40), e(0x3A2A5A, 40), false, true);
        b.cyl(0, 0.06f, 0, 0.6f, 0.6f, 0.0f, 12, e(0x1B7F8A, 60), e(0x1B7F8A, 60), false, true);
        return b.build();
    }
}
