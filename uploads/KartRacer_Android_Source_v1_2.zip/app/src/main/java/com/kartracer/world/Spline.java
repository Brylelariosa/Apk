package com.kartracer.world;

/** Centripetal Catmull-Rom splines over rows of {x, z, y, w}, resampled at even arc length. */
public final class Spline {
    private Spline() {}

    private static float knot(float[] a, float[] b) {
        float dx = b[0] - a[0], dz = b[1] - a[1];
        return (float) Math.sqrt(Math.sqrt(dx * dx + dz * dz)) + 1e-3f;
    }

    private static void eval(float[] out, float[] p0, float[] p1, float[] p2, float[] p3, float u) {
        float t0 = 0f, t1 = t0 + knot(p0, p1), t2 = t1 + knot(p1, p2), t3 = t2 + knot(p2, p3);
        float t = t1 + (t2 - t1) * u;
        for (int k = 0; k < 4; k++) {
            float a1 = ((t1 - t) * p0[k] + (t - t0) * p1[k]) / (t1 - t0);
            float a2 = ((t2 - t) * p1[k] + (t - t1) * p2[k]) / (t2 - t1);
            float a3 = ((t3 - t) * p2[k] + (t - t2) * p3[k]) / (t3 - t2);
            float b1 = ((t2 - t) * a1 + (t - t0) * a2) / (t2 - t0);
            float b2 = ((t3 - t) * a2 + (t - t1) * a3) / (t3 - t1);
            out[k] = ((t2 - t) * b1 + (t - t1) * b2) / (t2 - t1);
        }
    }

    private static float[] reflect(float[] a, float[] b) {
        float[] r = new float[4];
        for (int k = 0; k < 4; k++) r[k] = 2f * a[k] - b[k];
        return r;
    }

    public static float[][] resample(float[][] p, boolean closed, float step) { return resample(p, closed, step, false); }

    /**
     * Returns samples {x,z,y,w}. Closed loops do not repeat the first sample.
     * With helpers=true (open curves only) the first and last control points only shape the tangents.
     */
    public static float[][] resample(float[][] p, boolean closed, float step, boolean helpers) {
        int m = p.length;
        int first = (helpers && !closed) ? 1 : 0;
        int segs = closed ? m : (helpers ? m - 3 : m - 1);
        final int K = 24;
        float[][] dense = new float[segs * K + 1][];
        int dn = 0;
        float[] tmp = new float[4];
        for (int si = 0; si < segs; si++) {
            int i = si + first;
            float[] p1 = p[i], p2 = p[(i + 1) % m];
            float[] p0 = closed ? p[(i - 1 + m) % m] : (i == 0 ? reflect(p[0], p[1]) : p[i - 1]);
            float[] p3 = closed ? p[(i + 2) % m] : (i + 2 >= m ? reflect(p[m - 1], p[m - 2]) : p[i + 2]);
            for (int j = 0; j < K; j++) {
                eval(tmp, p0, p1, p2, p3, j / (float) K);
                dense[dn++] = new float[]{tmp[0], tmp[1], tmp[2], tmp[3]};
            }
        }
        if (!closed) dense[dn++] = p[helpers ? m - 2 : m - 1].clone();
        // arc length
        float[] cum = new float[dn + (closed ? 1 : 0)];
        for (int i = 1; i < cum.length; i++) {
            float[] a = dense[i - 1], b = dense[i % dn];
            float dx = b[0] - a[0], dz = b[1] - a[1];
            cum[i] = cum[i - 1] + (float) Math.sqrt(dx * dx + dz * dz);
        }
        float total = cum[cum.length - 1];
        int n = closed ? Math.max(8, Math.round(total / step)) : Math.max(2, (int) Math.ceil(total / step) + 1);
        float dstep = closed ? total / n : total / (n - 1);
        float[][] out = new float[n][4];
        int seg = 0;
        for (int i = 0; i < n; i++) {
            float d = i * dstep;
            while (seg < cum.length - 2 && cum[seg + 1] < d) seg++;
            float span = cum[seg + 1] - cum[seg];
            float f = span > 1e-6f ? (d - cum[seg]) / span : 0f;
            if (f > 1f) f = 1f;
            float[] a = dense[seg], b = dense[(seg + 1) % dn];
            for (int k = 0; k < 4; k++) out[i][k] = a[k] + (b[k] - a[k]) * f;
        }
        return out;
    }
}
