package com.kartracer.world;

/** Ground surface types and their driving properties. */
public final class Surf {
    private Surf() {}

    public static final int ROAD = 0, DIRT = 1, SAND = 2, GRASS = 3, MUD = 4, ROCK = 5, WATER = 6, LAVA = 7, WOOD = 8;
    public static final int COUNT = 9;
    /** Lateral grip multiplier. */
    public static final float[] GRIP = {1.00f, 0.90f, 0.78f, 0.86f, 0.62f, 1.00f, 0.70f, 0.60f, 1.00f};
    /** Top speed multiplier. */
    public static final float[] SPEED = {1.00f, 0.96f, 0.80f, 0.85f, 0.58f, 0.94f, 0.66f, 0.50f, 1.00f};
    /** Acceleration multiplier. */
    public static final float[] ACCEL = {1.00f, 0.95f, 0.78f, 0.85f, 0.65f, 0.95f, 0.70f, 0.60f, 1.00f};
    /** True for surfaces that count as off-road (affected by kart off-road resistance). */
    public static boolean offRoad(int s) { return s == SAND || s == GRASS || s == MUD || s == WATER; }
}
