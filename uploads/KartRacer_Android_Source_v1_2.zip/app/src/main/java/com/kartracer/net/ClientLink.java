package com.kartracer.net;

import com.kartracer.sim.RaceNet;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Random;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Client side of a LAN game: joins a host, syncs the clock, exchanges kart state and race events. */
public final class ClientLink implements Conn.Listener, RaceNet {
    public interface Events {
        void onConnected(Msg.Welcome w);
        void onLobby(Msg.Lobby l);
        void onRejected(String reason);
        void onStart(Msg.Start s);
        void onGo(int goMs);
        void onKicked(String reason);
        void onConnectionLost(boolean retrying);
        void onBack();
    }

    private final String host;
    private final int port;
    private final Events ev;
    private final long tokHi, tokLo;
    private String name;
    private int kart, color, driver;
    private final Clock clock = new Clock();
    private final ConcurrentLinkedQueue<Msg> inbox = new ConcurrentLinkedQueue<Msg>();
    private volatile Conn conn;
    private DatagramSocket udp;
    private InetAddress hostAddr;
    private volatile int hostUdpPort;
    private volatile boolean running, userLeft, udpOk, tcpState, inRace, joined;
    private volatile long joinedAtMs;
    public volatile int mySlot = -1;
    private volatile boolean retrying;

    // clock sync: best (lowest rtt) of recent samples
    private final int[] sRtt = new int[8], sOff = new int[8];
    private int sCount;
    private int pingsSent;

    public ClientLink(String host, int port, String name, int kart, int color, int driver, Events ev) {
        this.host = host; this.port = port; this.name = name; this.kart = kart; this.color = color; this.driver = driver; this.ev = ev;
        Random r = new Random();
        tokHi = r.nextLong(); tokLo = r.nextLong();
    }

    public Clock clock() { return clock; }

    public void connect() {
        running = true;
        Thread t = new Thread(new Runnable() { public void run() { connectOnce(true); } }, "kr-connect");
        t.setDaemon(true);
        t.start();
    }

    private boolean connectOnce(boolean first) {
        try {
            hostAddr = InetAddress.getByName(host);
            Socket s = new Socket();
            s.connect(new InetSocketAddress(hostAddr, port), 4000);
            Conn c = new Conn(s, this);
            conn = c;
            c.start("kr-client-conn");
            Msg.Join j = new Msg.Join();
            j.version = NetConst.PROTOCOL; j.tokHi = tokHi; j.tokLo = tokLo; j.name = name; j.kart = kart; j.color = color; j.driver = driver;
            c.send(j);
            if (udp == null) {
                udp = new DatagramSocket();
                udp.setSoTimeout(400);
                try { udp.setTrafficClass(0x88); } catch (Exception ignored) { }
                Thread ut = new Thread(new Runnable() { public void run() { udpLoop(); } }, "kr-client-udp");
                ut.setDaemon(true);
                ut.start();
                Thread mt = new Thread(new Runnable() { public void run() { maintLoop(); } }, "kr-client-maint");
                mt.setDaemon(true);
                mt.start();
            }
            return true;
        } catch (Exception e) {
            if (first) ev.onRejected("Could not connect to " + host + ": " + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()));
            return false;
        }
    }

    // ------------------------------------------------------------------ lobby API

    public void sendUpdate(int kart, int color, int driver, boolean ready) {
        this.kart = kart; this.color = color; this.driver = driver;
        Msg.Update u = new Msg.Update();
        u.kart = kart; u.color = color; u.driver = driver; u.ready = ready;
        sendReliable(u);
    }

    public void sendLoaded() { sendReliable(new Msg.Simple(Msg.LOADED)); }

    public void leave() {
        userLeft = true;
        running = false;
        Conn c = conn;
        if (c != null) { c.send(new Msg.Simple(Msg.LEAVE)); c.closeAfterFlush(); }
        closeUdpLater();
    }

    public void stop() {
        userLeft = true;
        running = false;
        Conn c = conn;
        if (c != null) c.close();
        closeUdpLater();
    }

    private void closeUdpLater() {
        new Thread(new Runnable() {
            public void run() {
                try { Thread.sleep(300); } catch (InterruptedException ignored) { }
                DatagramSocket u = udp;
                if (u != null) u.close();
            }
        }).start();
    }

    // ------------------------------------------------------------------ Conn.Listener

    public void onMessage(Conn c, Msg m) {
        switch (m.type()) {
            case Msg.WELCOME: {
                Msg.Welcome w = (Msg.Welcome) m;
                mySlot = w.slot;
                hostUdpPort = w.udpPort;
                joined = true;
                joinedAtMs = System.currentTimeMillis();
                udpOk = false; tcpState = false;
                retrying = false;
                pingsSent = 0;
                ev.onConnected(w);
                break;
            }
            case Msg.REJECT: ev.onRejected(((Msg.Reject) m).reason); userLeft = true; running = false; break;
            case Msg.LOBBY: ev.onLobby((Msg.Lobby) m); break;
            case Msg.START: inRace = true; ev.onStart((Msg.Start) m); break;
            case Msg.GO: ev.onGo(((Msg.Go) m).goMs); break;
            case Msg.KICK: userLeft = true; running = false; ev.onKicked(((Msg.Kick) m).reason); break;
            case Msg.BACK: inRace = false; ev.onBack(); break;
            case Msg.PING: c.send(new Msg.Pong(((Msg.Ping) m).t, 0)); break;
            case Msg.PONG: onPong((Msg.Pong) m); break;
            default: inbox.add(m); break;
        }
    }

    public void onClosed(Conn c) {
        if (c != conn) return;
        joined = false;
        if (userLeft || !running) return;
        boolean retry = inRace;
        ev.onConnectionLost(retry);
        if (retry && !retrying) {
            retrying = true;
            Thread t = new Thread(new Runnable() {
                public void run() {
                    for (int i = 0; i < 20 && running && !userLeft && retrying; i++) {
                        try { Thread.sleep(2000); } catch (InterruptedException e) { return; }
                        if (connectOnce(false)) {
                            try { Thread.sleep(2500); } catch (InterruptedException e) { return; }
                            if (joined) return;
                        }
                    }
                    if (!joined && running) { retrying = false; running = false; ev.onRejected("Lost connection to the host"); }
                }
            }, "kr-reconnect");
            t.setDaemon(true);
            t.start();
        } else if (!retry) {
            running = false;
        }
    }

    private void onPong(Msg.Pong p) {
        int now = clock.localMs();
        int rtt = now - p.t;
        if (rtt < 0 || rtt > 3000) return;
        int off = p.hostMs + rtt / 2 - now;
        synchronized (sRtt) {
            int i = sCount % sRtt.length;
            sRtt[i] = rtt; sOff[i] = off;
            sCount++;
            int n = Math.min(sCount, sRtt.length), best = 0;
            for (int k = 1; k < n; k++) if (sRtt[k] < sRtt[best]) best = k;
            int target = sOff[best];
            int cur = clock.getOffset();
            // the first samples set the clock directly, later ones glide so the shared time never jumps around
            if (sCount <= 3 || Math.abs(target - cur) > 40) clock.setOffset(target);
            else clock.setOffset(cur + Math.round((target - cur) * 0.2f));
        }
    }

    // ------------------------------------------------------------------ udp + maintenance

    private void udpLoop() {
        byte[] buf = new byte[2048];
        while (udp != null && !udp.isClosed()) {
            try {
                DatagramPacket pkt = new DatagramPacket(buf, buf.length);
                udp.receive(pkt);
                Msg m = Udp.decode(pkt.getData(), pkt.getLength());
                if (m == null) continue;
                if (m.type() == Msg.UDP_ACK) udpOk = true;
                else if (m.type() == Msg.SNAPSHOT) inbox.add(m);
            } catch (java.net.SocketTimeoutException ignored) {
            } catch (Exception e) {
                if (udp == null || udp.isClosed()) return;
            }
        }
    }

    private void maintLoop() {
        long lastHello = 0, lastPing = 0;
        while (running || retrying) {
            try { Thread.sleep(100); } catch (InterruptedException e) { return; }
            long now = System.currentTimeMillis();
            Conn c = conn;
            if (c == null || !c.isOpen() || !joined) continue;
            if (now - c.lastRecvMs > 9000) { c.close(); continue; }
            if (!udpOk && !tcpState) {
                if (now - lastHello > 250) {
                    lastHello = now;
                    Msg.UdpHello h = new Msg.UdpHello();
                    h.slot = mySlot; h.tokHi = tokHi; h.tokLo = tokLo;
                    try {
                        byte[] b = Udp.encode(h);
                        udp.send(new DatagramPacket(b, b.length, hostAddr, hostUdpPort));
                    } catch (Exception ignored) { }
                }
                if (now - joinedAtMs > 4000) { tcpState = true; c.send(new Msg.Simple(Msg.TCP_STATE)); }
            }
            int period = pingsSent < 8 ? 250 : 2000;
            if (now - lastPing > period) {
                lastPing = now;
                pingsSent++;
                c.send(new Msg.Ping(clock.localMs()));
            }
        }
    }

    public boolean usingUdp() { return udpOk && !tcpState; }

    // ------------------------------------------------------------------ RaceNet

    public boolean isHost() { return false; }
    public int clockMs() { return clock.hostMs(); }

    public void sendReliable(Msg m) {
        Conn c = conn;
        if (c != null) c.send(m);
    }

    public void sendReliableTo(int slot, Msg m) { }

    public void sendFast(Msg m) {
        if (udpOk && !tcpState) {
            try {
                byte[] b = Udp.encode(m);
                udp.send(new DatagramPacket(b, b.length, hostAddr, hostUdpPort));
            } catch (IOException ignored) {
            }
        } else sendReliable(m);
    }

    public Msg poll() { return inbox.poll(); }

    public void clearInbox() { inbox.clear(); }
}
