package com.kartracer.net;

/** Millisecond clock that can be offset to match the host's clock. */
public final class Clock {
    private final long base = System.nanoTime();
    private volatile int offset;

    /** Local monotonic milliseconds since this clock was created. */
    public int localMs() { return (int) ((System.nanoTime() - base) / 1000000L); }

    /** Estimated host time. */
    public int hostMs() { return localMs() + offset; }

    public void setOffset(int off) { offset = off; }
    public int getOffset() { return offset; }
}
