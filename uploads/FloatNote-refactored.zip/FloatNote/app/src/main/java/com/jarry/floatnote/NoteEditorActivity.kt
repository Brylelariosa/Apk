package com.jarry.floatnote

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.data.NoteRepository
import com.jarry.floatnote.databinding.ActivityNoteEditorBinding
import com.jarry.floatnote.util.Debouncer
import com.jarry.floatnote.util.OverlayPermission
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.UndoRedoManager
import com.jarry.floatnote.util.applyBottomSystemBarPadding
import com.jarry.floatnote.util.applyContentTextSize
import com.jarry.floatnote.util.applyTopSystemBarPadding
import com.jarry.floatnote.util.bindCopyButton
import com.jarry.floatnote.util.bindNumberedListButton
import com.jarry.floatnote.util.bindPasteButton
import com.jarry.floatnote.util.bindToButtons
import com.jarry.floatnote.util.simpleWatcher
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.launch

class NoteEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNoteEditorBinding
    private lateinit var repository: NoteRepository
    private lateinit var undoRedo: UndoRedoManager
    private lateinit var saveDebouncer: Debouncer
    private var note = Note()

    // The final save fired from onPause() (see there) - retained across a
    // configuration-change recreation via onRetainCustomNonConfigurationInstance
    // so the *new* instance can pick up its result (in particular, the id a
    // brand-new note was just assigned) instead of racing it. Null once
    // nothing is outstanding.
    private var pendingSave: Deferred<Note>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        binding = ActivityNoteEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = NoteRepository.getInstance(this)
        saveDebouncer = Debouncer(lifecycleScope)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        applyInsets()

        applyGlobalStyle()
        applyContentTextSize(binding.editContent, this)

        undoRedo = UndoRedoManager(binding.editContent, lifecycleScope)
        undoRedo.bindToButtons(binding.buttonUndo, binding.buttonRedo)
        bindNumberedListButton(binding.editContent, binding.buttonNumberedList, this)
        bindCopyButton(binding.editContent, binding.buttonCopy, this)
        bindPasteButton(binding.editContent, binding.buttonPaste, this)

        val watcher = simpleWatcher { scheduleAutoSave() }
        binding.editTitle.addTextChangedListener(watcher)
        binding.editContent.addTextChangedListener(watcher)

        // A configuration change (rotation, dark mode toggle, multi-window
        // resize, etc.) recreates this Activity with the *original* Intent,
        // whose EXTRA_NOTE_ID is still 0 for a note that was brand new when
        // this screen first opened - even if it has since been assigned a
        // real id by an autosave. Without restoring that id from saved
        // state, the recreated instance would treat the note as new again
        // and the next autosave would INSERT a second, duplicate row
        // instead of updating the first.
        @Suppress("DEPRECATION") // see pendingSave / onRetainCustomNonConfigurationInstance
        val retainedSave = lastCustomNonConfigurationInstance as? Deferred<Note>
        val restoredNoteId = savedInstanceState?.getLong(STATE_NOTE_ID, 0L) ?: 0L
        val noteId = if (restoredNoteId != 0L) restoredNoteId else intent.getLongExtra(EXTRA_NOTE_ID, 0L)

        lifecycleScope.launch {
            // If the previous instance's onPause save is still in flight -
            // only possible right after an immediate rotation, since it's
            // otherwise long finished by the time anything reads `note`
            // again - wait for it first (a plain coroutine suspend, not a
            // thread block) so a brand-new note's just-assigned id is
            // picked up here instead of this instance also treating it as
            // unsaved and inserting a duplicate row on its own next
            // autosave. Also covers the ordinary case of resuming an
            // existing note faster than its pause-triggered re-save
            // finished: either way `note` ends up holding the freshest
            // known copy before the reload below runs.
            if (retainedSave != null) {
                note = runCatching { retainedSave.await() }.getOrDefault(note)
            }
            val idToLoad = if (note.id != 0L) note.id else noteId
            if (idToLoad != 0L) {
                repository.getById(idToLoad)?.let {
                    note = it
                    binding.editTitle.setText(it.title)
                    binding.editContent.setText(it.content)
                    undoRedo.reset()
                    restoreCursorSelection(savedInstanceState)
                }
            }
        }

        binding.buttonDelete.setOnClickListener {
            lifecycleScope.launch {
                saveDebouncer.cancel()
                if (note.id != 0L) repository.delete(note.id)
                finish()
            }
        }

        binding.buttonPopOut.setOnClickListener {
            if (!OverlayPermission.isGranted(this)) {
                OverlayPermission.request(this, binding.root)
                return@setOnClickListener
            }
            lifecycleScope.launch {
                saveDebouncer.cancel()
                persist()
                val serviceIntent = Intent(this@NoteEditorActivity, FloatingNoteService::class.java)
                    .setAction(FloatingNoteService.ACTION_SHOW_NOTE)
                    .putExtra(FloatingNoteService.EXTRA_NOTE_ID, note.id)
                ContextCompat.startForegroundService(this@NoteEditorActivity, serviceIntent)
                finish()
            }
        }
    }

    // Hands `pendingSave` (if any) to the Activity instance that's about to
    // replace this one across a configuration change, entirely in memory -
    // no Bundle/parcelling involved, which matters here since a Deferred
    // can't be parcelled at all. This API is deprecated in favor of
    // ViewModel-retained state, but remains fully supported; using it here
    // keeps this fix localized to the one piece of state that actually
    // needs to survive recreation, rather than introducing a new
    // ViewModel-based architecture for the rest of this screen.
    @Suppress("DEPRECATION")
    override fun onRetainCustomNonConfigurationInstance(): Any? = pendingSave

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(STATE_NOTE_ID, note.id)
        outState.putInt(STATE_CURSOR_START, binding.editContent.selectionStart)
        outState.putInt(STATE_CURSOR_END, binding.editContent.selectionEnd)
    }

    private fun restoreCursorSelection(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) return
        val start = savedInstanceState.getInt(STATE_CURSOR_START, -1)
        val end = savedInstanceState.getInt(STATE_CURSOR_END, -1)
        val length = binding.editContent.text?.length ?: 0
        if (start in 0..length && end in 0..length) {
            binding.editContent.setSelection(start, end)
        }
    }

    private fun applyInsets() {
        binding.toolbar.applyTopSystemBarPadding()
        binding.bottomBar.applyBottomSystemBarPadding()
    }

    /** Style is a single app-wide choice made in Settings now, not a per-note
     *  picker living on this screen - just reflect it here. */
    private fun applyGlobalStyle() {
        val style = PaperStyles.current(this)
        binding.spineAccent.setBackgroundColor(ContextCompat.getColor(this, style.coverColor))
        binding.editContent.pattern = style.pattern
    }

    override fun onResume() {
        super.onResume()
        applyGlobalStyle()
        applyContentTextSize(binding.editContent, this)
        // Guards the same two-editors-one-note conflict as MainActivity.openNote,
        // just from the other direction: if this note became a floating window
        // while this screen was backgrounded (e.g. a stale multi-window/recents
        // instance), defer to that window instead of resuming a second,
        // uncoordinated editor for it.
        if (FloatingNoteService.isNoteFloating(note.id)) {
            finish()
        }
        // Handles rapid pause/resume (no destroy in between, so the
        // onRetainCustomNonConfigurationInstance hand-off never comes into
        // play): adopt onPause's save result once it lands, so if the user
        // resumes and starts typing again before it finishes, the next
        // autosave uses the correct, up-to-date id/version instead of
        // racing it.
        pendingSave?.let { deferred ->
            lifecycleScope.launch {
                runCatching { deferred.await() }.onSuccess { note = it }
            }
        }
        pendingSave = null
    }

    private fun scheduleAutoSave() {
        saveDebouncer.schedule { persist() }
    }

    override fun onPause() {
        super.onPause()
        saveDebouncer.cancel()
        // Captures the on-screen text synchronously (fast: just reading two
        // EditTexts on the main thread, no I/O) and hands the actual write
        // off to NoteRepository's durable scope, which outlives this
        // Activity - see NoteRepository.saveOrDeleteIfEmptyDurable. This
        // used to be `runBlocking { persist() }`, which blocked the main
        // thread for every single pause (including brief ones, like a
        // permission dialog appearing) to get the same "definitely saved,
        // definitely has an id before onSaveInstanceState runs" guarantee
        // synchronously. That guarantee now comes from `pendingSave` being
        // retained across a configuration change and awaited (non-blocking)
        // by whichever instance needs it next - see onCreate() and
        // onResume() above.
        val snapshot = note.copy(
            title = binding.editTitle.text.toString(),
            content = binding.editContent.text.toString()
        )
        pendingSave = repository.saveOrDeleteIfEmptyDurable(snapshot)
    }

    private suspend fun persist() {
        val title = binding.editTitle.text.toString()
        val content = binding.editContent.text.toString()
        note = repository.saveOrDeleteIfEmpty(note.copy(title = title, content = content))
    }

    companion object {
        const val EXTRA_NOTE_ID = "extra_note_id"
        private const val STATE_NOTE_ID = "state_note_id"
        private const val STATE_CURSOR_START = "state_cursor_start"
        private const val STATE_CURSOR_END = "state_cursor_end"
    }
}
