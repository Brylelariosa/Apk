package com.jarry.floatnote

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.core.view.marginBottom
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.jarry.floatnote.adapter.NotesAdapter
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.data.NoteRepository
import com.jarry.floatnote.databinding.ActivityMainBinding
import com.jarry.floatnote.util.Debouncer
import com.jarry.floatnote.util.OverlayPermission
import com.jarry.floatnote.util.PrefsManager
import com.jarry.floatnote.util.applyTopSystemBarPadding
import com.jarry.floatnote.util.dpToPx
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: NoteRepository
    private lateinit var adapter: NotesAdapter
    private var currentQuery: String = ""
    private var loadNotesJob: Job? = null
    private val searchDebouncer = Debouncer(lifecycleScope, delayMillis = 200L)

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        repository = NoteRepository.getInstance(this)

        setSupportActionBar(binding.toolbar)
        applyInsets()

        adapter = NotesAdapter(
            onClick = { note -> openNote(note) },
            onLongClick = { note -> togglePin(note); true }
        )
        binding.recyclerNotes.layoutManager =
            StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        binding.recyclerNotes.adapter = adapter
        // A few more offscreen views than the default (2) stay bound while
        // scrolling a 2-column staggered grid, so flinging back and forth
        // over recently-seen cards re-binds less often.
        binding.recyclerNotes.setItemViewCacheSize(8)

        ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            0, ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ) = false

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                // bindingAdapterPosition can be NO_POSITION if the list changed
                // (e.g. a concurrent search/refresh) between the swipe starting
                // and this callback firing - indexing with it unchecked would
                // crash. No extra cleanup is needed here if we bail out:
                // ItemTouchHelper's own clearView() resets the swiped view's
                // translation/alpha regardless of what onSwiped does.
                val position = viewHolder.bindingAdapterPosition
                if (position == RecyclerView.NO_POSITION || position >= adapter.currentList.size) return
                deleteNote(adapter.currentList[position])
            }
        }).attachToRecyclerView(binding.recyclerNotes)

        binding.fabAdd.setOnClickListener { createNewNote() }
    }

    private fun applyInsets() {
        binding.appBar.applyTopSystemBarPadding()
        val fabBaseMargin = binding.fabAdd.marginBottom
        ViewCompat.setOnApplyWindowInsetsListener(binding.recyclerNotes) { v, insets ->
            val bottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            v.updatePadding(bottom = bottom + dpToPx(88f))
            (binding.fabAdd.layoutParams as CoordinatorLayout.LayoutParams).bottomMargin =
                fabBaseMargin + bottom
            insets
        }
    }

    override fun onResume() {
        super.onResume()
        // The paper style is a single app-wide setting that can only change
        // via Settings, so re-resolving it here (cheap) rather than on every
        // row bind covers the one place it actually needs to change.
        adapter.refreshStyle(this)
        loadNotes()
    }

    private fun loadNotes() {
        // Cancels any load already in flight so a fast search keystroke (or
        // rapid pin/delete actions) can't have an older, slower query finish
        // after a newer one and overwrite the list with stale results.
        // repository.getAll ties this cancellation to a CancellationSignal on
        // the underlying SQLite query itself (see NoteDbHelper.getAll), so a
        // superseded query is actually interrupted rather than running to
        // completion in the background and just having its result quietly
        // discarded - the latter still wouldn't have shown stale data, but
        // could waste real time/IO on a big/unindexed search and, under
        // enough contention, delay the query that *does* matter.
        loadNotesJob?.cancel()
        loadNotesJob = lifecycleScope.launch {
            val notes = repository.getAll(currentQuery)
            adapter.submitList(notes)
            binding.emptyState.isVisible = notes.isEmpty()
        }
    }

    private fun createNewNote() {
        if (PrefsManager.isFloatingModeEnabled(this)) {
            openFloating(Note())
        } else {
            startActivity(Intent(this, NoteEditorActivity::class.java))
        }
    }

    private fun openNote(note: Note) {
        // Even with Floating Mode off, a note already popped out to a floating
        // window takes priority - it has its own live, possibly-unsaved copy
        // of the note, so opening a second editor here would let the two
        // silently race to save over each other. Bring the floating one
        // forward instead of duplicating it.
        if (PrefsManager.isFloatingModeEnabled(this) || FloatingNoteService.isNoteFloating(note.id)) {
            openFloating(note)
        } else {
            val intent = Intent(this, NoteEditorActivity::class.java)
                .putExtra(NoteEditorActivity.EXTRA_NOTE_ID, note.id)
            startActivity(intent)
        }
    }

    private fun openFloating(note: Note) {
        ensureNotificationPermission()
        if (!OverlayPermission.isGranted(this)) {
            OverlayPermission.request(this, binding.root)
            return
        }
        val intent = Intent(this, FloatingNoteService::class.java)
            .setAction(FloatingNoteService.ACTION_SHOW_NOTE)
            .putExtra(FloatingNoteService.EXTRA_NOTE_ID, note.id)
        ContextCompat.startForegroundService(this, intent)
        moveTaskToBack(true)
    }

    private fun togglePin(note: Note) {
        lifecycleScope.launch {
            // Narrow write (pinned column only) - see
            // NoteRepository.setPinned - so this can never overwrite
            // title/content a floating window or the editor autosaved
            // moments ago that just hasn't reached this screen's own
            // (periodically refreshed) list snapshot yet.
            repository.setPinned(note.id, !note.isPinned)
            loadNotes()
        }
    }

    private fun deleteNote(note: Note) {
        lifecycleScope.launch {
            repository.delete(note.id)
            loadNotes()
            Snackbar.make(binding.root, R.string.note_deleted, Snackbar.LENGTH_LONG)
                .setAction(R.string.undo) {
                    lifecycleScope.launch {
                        repository.save(note.copy(id = 0L))
                        loadNotes()
                    }
                }.show()
        }
    }

    private fun ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        val searchItem = menu.findItem(R.id.action_search)
        (searchItem.actionView as SearchView).setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = true
            override fun onQueryTextChange(newText: String?): Boolean {
                currentQuery = newText.orEmpty()
                searchDebouncer.schedule { loadNotes() }
                return true
            }
        })
        menu.findItem(R.id.action_floating_mode).isChecked = PrefsManager.isFloatingModeEnabled(this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_floating_mode) {
            val newState = !item.isChecked
            item.isChecked = newState
            PrefsManager.setFloatingModeEnabled(this, newState)
            return true
        }
        if (item.itemId == R.id.action_settings) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
