package com.torrix.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.torrix.app.engine.Fmt

/**
 * The add-torrent sheet. Magnet links need their metadata from peers first,
 * so the file list appears once that has arrived; nothing is downloaded
 * until the user confirms the selection.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSheet(vm: MainViewModel, state: AddUi) {
    ModalBottomSheet(
        onDismissRequest = { vm.dismissAdd() },
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 16.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            when (state) {
                is AddUi.Resolving -> ResolvingContent(state, onCancel = { vm.dismissAdd() })
                is AddUi.Ready -> ReadyContent(vm, state)
                is AddUi.Adding -> AddingContent(state)
                is AddUi.Failed -> FailedContent(state, onClose = { vm.dismissAdd() })
                AddUi.Idle -> Unit
            }
        }
    }
}

@Composable
private fun ResolvingContent(s: AddUi.Resolving, onCancel: () -> Unit) {
    Text("Getting torrent details", style = MaterialTheme.typography.titleLarge)
    Text(s.label, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    LinearProgressIndicator(Modifier.fillMaxWidth())
    Text(
        resolvingHint(s),
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
}

private fun resolvingHint(s: AddUi.Resolving): String = when {
    s.elapsedSecs < 10 ->
        "Torrix is looking for peers and reading the file list. Most torrents take a few seconds."
    s.attempt <= 1 ->
        "Still looking for peers (${s.elapsedSecs} s). A torrent with few peers can take longer."
    else ->
        "Still looking for peers (${s.elapsedSecs} s, search ${s.attempt}). " +
            "Torrix starts a fresh search when one gets no answer."
}

@Composable
private fun AddingContent(s: AddUi.Adding) {
    Text("Starting download", style = MaterialTheme.typography.titleLarge)
    Text(s.name, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    LinearProgressIndicator(Modifier.fillMaxWidth())
    if (s.elapsedSecs >= 10) {
        Text(
            "This is taking longer than usual (${s.elapsedSecs} s). You can close this sheet: " +
                "the torrent shows up in Downloads as soon as it starts, and Torrix tells you if it cannot.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun FailedContent(s: AddUi.Failed, onClose: () -> Unit) {
    Text("Could not add this torrent", style = MaterialTheme.typography.titleLarge)
    Text(s.message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.error)
    Button(onClick = onClose, modifier = Modifier.fillMaxWidth()) { Text("Close") }
}

@Composable
private fun ReadyContent(vm: MainViewModel, s: AddUi.Ready) {
    val files = s.preview.files
    val selectedBytes = files.filter { it.index in s.selected }.sumOf { it.length }
    val free = remember(s.requestId) { vm.engine.freeStagingBytes() }
    val needed = selectedBytes + 32L * 1024 * 1024
    val enough = free >= needed

    Text(s.preview.name, style = MaterialTheme.typography.titleLarge, maxLines = 2, overflow = TextOverflow.Ellipsis)
    Text(
        "${files.size} ${if (files.size == 1) "file" else "files"} · ${Fmt.bytes(s.preview.totalBytes)}",
        style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    if (files.size > 1) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = { vm.selectAllFiles(true) }) { Text("Select all") }
            TextButton(onClick = { vm.selectAllFiles(false) }) { Text("Select none") }
        }
    }
    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 340.dp)) {
        items(files, key = { it.index }) { f ->
            Row(
                Modifier.fillMaxWidth().clickable { vm.toggleFile(f.index) }.padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Checkbox(checked = f.index in s.selected, onCheckedChange = { vm.toggleFile(f.index) })
                Column(Modifier.weight(1f)) {
                    Text(
                        f.path.substringAfterLast('/'),
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    val folder = f.path.substringBeforeLast('/', "")
                    Text(
                        if (folder.isEmpty()) Fmt.bytes(f.length) else "$folder · ${Fmt.bytes(f.length)}",
                        style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
        }
    }
    Spacer(Modifier.height(2.dp))
    if (!enough) {
        Text(
            "Not enough free storage: this needs about ${Fmt.bytes(needed)} and ${Fmt.bytes(free)} is free. Select fewer files or free some space.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
        )
    }
    Button(
        onClick = { vm.confirmAdd() },
        enabled = s.selected.isNotEmpty() && enough,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(if (s.selected.isEmpty()) "Select at least one file" else "Download ${Fmt.bytes(selectedBytes)}")
    }
    OutlinedButton(onClick = { vm.dismissAdd() }, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
}
