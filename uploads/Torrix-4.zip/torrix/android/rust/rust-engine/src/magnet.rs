//! Magnet link parsing and input classification. Std-only so it is trivially
//! testable. Everything here treats its input as hostile: sizes are capped,
//! only http/https/udp trackers survive, and the info hash must be a valid
//! 40-character hex or 32-character base32 string.

use std::fmt;

pub const MAX_INPUT_LEN: usize = 8 * 1024;
pub const MAX_TRACKERS: usize = 64;
const MAX_NAME_CHARS: usize = 255;
const MAX_TRACKER_LEN: usize = 512;
const MAX_URL_LEN: usize = 2048;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Magnet {
    /// 40 lowercase hex characters.
    pub info_hash: String,
    pub display_name: Option<String>,
    pub trackers: Vec<String>,
    pub exact_length: Option<u64>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MagnetError {
    Empty,
    TooLong,
    NotMagnet,
    MissingInfoHash,
    BadInfoHash,
    V2Only,
}

impl fmt::Display for MagnetError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let msg = match self {
            MagnetError::Empty => "Nothing to add.",
            MagnetError::TooLong => "That magnet link is too long.",
            MagnetError::NotMagnet => "That is not a magnet link (it should start with magnet:?).",
            MagnetError::MissingInfoHash => "The magnet link has no info hash (xt=urn:btih:...).",
            MagnetError::BadInfoHash => "The info hash in the magnet link is not valid.",
            MagnetError::V2Only => "This magnet link only has a BitTorrent v2 hash, which is not supported yet.",
        };
        f.write_str(msg)
    }
}

impl std::error::Error for MagnetError {}

fn hex_val(b: u8) -> Option<u8> {
    match b {
        b'0'..=b'9' => Some(b - b'0'),
        b'a'..=b'f' => Some(b - b'a' + 10),
        b'A'..=b'F' => Some(b - b'A' + 10),
        _ => None,
    }
}

pub fn percent_decode(s: &str, plus_as_space: bool) -> String {
    let b = s.as_bytes();
    let mut out: Vec<u8> = Vec::with_capacity(b.len());
    let mut i = 0usize;
    while i < b.len() {
        match b[i] {
            b'%' if i + 2 < b.len() => match (hex_val(b[i + 1]), hex_val(b[i + 2])) {
                (Some(h), Some(l)) => {
                    out.push(h * 16 + l);
                    i += 3;
                }
                _ => {
                    out.push(b'%');
                    i += 1;
                }
            },
            b'+' if plus_as_space => {
                out.push(b' ');
                i += 1;
            }
            c => {
                out.push(c);
                i += 1;
            }
        }
    }
    String::from_utf8_lossy(&out).into_owned()
}

pub fn percent_encode(s: &str) -> String {
    let mut out = String::with_capacity(s.len() * 3 / 2 + 1);
    for &b in s.as_bytes() {
        if b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_' | b'.' | b'~') {
            out.push(b as char);
        } else {
            out.push_str(&format!("%{:02X}", b));
        }
    }
    out
}

fn base32_to_hex(s: &str) -> Option<String> {
    let mut bits: u32 = 0;
    let mut nbits: u32 = 0;
    let mut bytes: Vec<u8> = Vec::with_capacity(20);
    for c in s.bytes() {
        let v = u32::from(match c {
            b'A'..=b'Z' => c - b'A',
            b'a'..=b'z' => c - b'a',
            b'2'..=b'7' => c - b'2' + 26,
            _ => return None,
        });
        bits = (bits << 5) | v;
        nbits += 5;
        if nbits >= 8 {
            nbits -= 8;
            bytes.push(((bits >> nbits) & 0xFF) as u8);
            bits &= (1u32 << nbits) - 1;
        }
    }
    if bytes.len() != 20 {
        return None;
    }
    Some(bytes.iter().map(|b| format!("{:02x}", b)).collect())
}

/// Accepts 40 hex characters or 32 base32 characters, returns lowercase hex.
pub fn decode_btih(h: &str) -> Result<String, MagnetError> {
    let h = h.trim();
    match h.len() {
        40 if h.bytes().all(|b| b.is_ascii_hexdigit()) => Ok(h.to_ascii_lowercase()),
        32 => base32_to_hex(h).ok_or(MagnetError::BadInfoHash),
        _ => Err(MagnetError::BadInfoHash),
    }
}

fn clean_name(raw: &str) -> Option<String> {
    let cleaned: String = raw.chars().filter(|c| !c.is_control()).collect();
    let trimmed = cleaned.trim();
    if trimmed.is_empty() {
        return None;
    }
    Some(trimmed.chars().take(MAX_NAME_CHARS).collect())
}

fn clean_tracker(raw: &str) -> Option<String> {
    let t = raw.trim();
    if t.is_empty() || t.len() > MAX_TRACKER_LEN {
        return None;
    }
    if t.chars().any(|c| c.is_whitespace() || c.is_control()) {
        return None;
    }
    let lower = t.to_ascii_lowercase();
    if lower.starts_with("http://") || lower.starts_with("https://") || lower.starts_with("udp://") {
        Some(t.to_string())
    } else {
        None
    }
}

pub fn parse(input: &str) -> Result<Magnet, MagnetError> {
    let s = input.trim();
    if s.is_empty() {
        return Err(MagnetError::Empty);
    }
    if s.len() > MAX_INPUT_LEN {
        return Err(MagnetError::TooLong);
    }
    let prefix: String = s.chars().take(8).collect::<String>().to_ascii_lowercase();
    if prefix != "magnet:?" {
        return Err(MagnetError::NotMagnet);
    }
    let query = &s[8..]; // the first 8 chars are ASCII, so byte 8 is a boundary

    let mut btih: Option<String> = None;
    let mut saw_btmh = false;
    let mut name: Option<String> = None;
    let mut trackers: Vec<String> = Vec::new();
    let mut exact_length: Option<u64> = None;

    for pair in query.split('&') {
        if pair.is_empty() {
            continue;
        }
        let (k_raw, v_raw) = pair.split_once('=').unwrap_or((pair, ""));
        let key = percent_decode(k_raw, true).to_ascii_lowercase();
        let value = percent_decode(v_raw, true);
        let base_key = key.split('.').next().unwrap_or("");
        match base_key {
            "xt" => {
                let lv = value.trim().to_ascii_lowercase();
                if let Some(h) = lv.strip_prefix("urn:btih:") {
                    if btih.is_none() {
                        btih = Some(decode_btih(h)?);
                    }
                } else if lv.starts_with("urn:btmh:") {
                    saw_btmh = true;
                }
            }
            "dn" => {
                if name.is_none() {
                    name = clean_name(&value);
                }
            }
            "tr" => {
                if trackers.len() < MAX_TRACKERS {
                    if let Some(t) = clean_tracker(&value) {
                        if !trackers.contains(&t) {
                            trackers.push(t);
                        }
                    }
                }
            }
            "xl" => {
                if exact_length.is_none() {
                    exact_length = value.trim().parse::<u64>().ok();
                }
            }
            _ => {}
        }
    }

    match btih {
        Some(info_hash) => Ok(Magnet {
            info_hash,
            display_name: name,
            trackers,
            exact_length,
        }),
        None if saw_btmh => Err(MagnetError::V2Only),
        None => Err(MagnetError::MissingInfoHash),
    }
}

/// Canonical magnet URI built only from validated parts.
pub fn to_uri(m: &Magnet) -> String {
    let mut s = format!("magnet:?xt=urn:btih:{}", m.info_hash);
    if let Some(n) = &m.display_name {
        s.push_str("&dn=");
        s.push_str(&percent_encode(n));
    }
    for t in &m.trackers {
        s.push_str("&tr=");
        s.push_str(&percent_encode(t));
    }
    s
}

/// Well-known public trackers that are added to every magnet lookup. Many
/// links carry no tracker at all, or only dead ones; then the metadata can only
/// come from the DHT, which is slow to find peers on a phone. A tracker answers
/// in a second or two. Only schemes that `clean_tracker` accepts are listed.
pub const PUBLIC_TRACKERS: &[&str] = &[
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.torrent.eu.org:451/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://open.demonii.com:1337/announce",
    "udp://explodie.org:6969/announce",
    "udp://tracker.dler.org:6969/announce",
    "udp://open.demonoid.ch:6969/announce",
    "udp://tracker.bittor.pw:1337/announce",
    "http://tracker.opentrackr.org:1337/announce",
];

/// The same magnet with [`PUBLIC_TRACKERS`] added behind its own trackers,
/// which keep their place at the front. Duplicates are skipped and the total
/// stays within `MAX_TRACKERS`.
pub fn with_public_trackers(m: &Magnet) -> Magnet {
    let mut out = m.clone();
    for t in PUBLIC_TRACKERS {
        if out.trackers.len() >= MAX_TRACKERS {
            break;
        }
        if !out.trackers.iter().any(|x| x.eq_ignore_ascii_case(t)) {
            out.trackers.push((*t).to_string());
        }
    }
    out
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Source {
    Magnet(Magnet),
    TorrentUrl(String),
}

impl Source {
    pub fn label(&self) -> String {
        match self {
            Source::Magnet(m) => m
                .display_name
                .clone()
                .unwrap_or_else(|| format!("{}...", &m.info_hash[..8])),
            Source::TorrentUrl(u) => url_host(u).unwrap_or_else(|| "torrent file".to_string()),
        }
    }
}

/// Decide what the user typed or pasted: a magnet link, the URL of a .torrent
/// file, or a bare info hash.
pub fn classify(input: &str) -> Result<Source, String> {
    let s = input.trim();
    if s.is_empty() {
        return Err(MagnetError::Empty.to_string());
    }
    let lower = s.to_ascii_lowercase();
    if lower.starts_with("magnet:") {
        return parse(s).map(Source::Magnet).map_err(|e| e.to_string());
    }
    if lower.starts_with("http://") || lower.starts_with("https://") {
        validate_url(s)?;
        return Ok(Source::TorrentUrl(s.to_string()));
    }
    if let Ok(h) = decode_btih(s) {
        return Ok(Source::Magnet(Magnet {
            info_hash: h,
            display_name: None,
            trackers: Vec::new(),
            exact_length: None,
        }));
    }
    Err("Enter a magnet link, the address of a .torrent file, or a 40-character info hash.".to_string())
}

fn validate_url(s: &str) -> Result<(), String> {
    if s.len() > MAX_URL_LEN {
        return Err("That address is too long.".to_string());
    }
    if s.chars().any(|c| c.is_whitespace() || c.is_control()) {
        return Err("That address contains invalid characters.".to_string());
    }
    match url_host(s) {
        Some(_) => Ok(()),
        None => Err("That address has no host name.".to_string()),
    }
}

/// Lowercase host of an http(s) URL (without user info and port).
pub fn url_host(url: &str) -> Option<String> {
    let rest = url.split_once("://")?.1;
    let authority = rest.split(|c: char| c == '/' || c == '?' || c == '#').next()?;
    let authority = authority.rsplit('@').next()?;
    let host = if let Some(stripped) = authority.strip_prefix('[') {
        stripped.split(']').next()?
    } else {
        authority.split(':').next()?
    };
    if host.is_empty() {
        None
    } else {
        Some(host.to_ascii_lowercase())
    }
}

/// True for loopback / private / link-local literal addresses and local names.
pub fn is_private_host(host: &str) -> bool {
    torrix_search::http::is_private_host(host)
}

#[cfg(test)]
mod tests {
    use super::*;

    const HASH: &str = "da39a3ee5e6b4b0d3255bfef95601890afd80709";
    const HASH_B32: &str = "3I42H3S6NNFQ2MSVX7XZKYAYSCX5QBYJ";

    #[test]
    fn parses_a_typical_link() {
        let m = parse(&format!(
            "magnet:?xt=urn:btih:{HASH}&dn=Ubuntu+24.04+Desktop&tr=udp%3A%2F%2Ftracker.example.org%3A6969&tr=https://t.example.net/announce&xl=6144000000"
        ))
        .unwrap();
        assert_eq!(m.info_hash, HASH);
        assert_eq!(m.display_name.as_deref(), Some("Ubuntu 24.04 Desktop"));
        assert_eq!(
            m.trackers,
            vec!["udp://tracker.example.org:6969", "https://t.example.net/announce"]
        );
        assert_eq!(m.exact_length, Some(6_144_000_000));
    }

    #[test]
    fn hex_hash_is_lowercased_and_scheme_is_case_insensitive() {
        let upper = HASH.to_ascii_uppercase();
        let m = parse(&format!("MAGNET:?XT=URN:BTIH:{upper}")).unwrap();
        assert_eq!(m.info_hash, HASH);
    }

    #[test]
    fn base32_hash_matches_python_reference() {
        let m = parse(&format!("magnet:?xt=urn:btih:{HASH_B32}")).unwrap();
        assert_eq!(m.info_hash, HASH);
        let m2 = parse("magnet:?xt=urn:btih:AERUKZ4JVPG66AJDIVTYTK6N54ASGRLH").unwrap();
        assert_eq!(m2.info_hash, "0123456789abcdef0123456789abcdef01234567");
        // lowercase base32 is accepted too
        let m3 = parse(&format!("magnet:?xt=urn:btih:{}", HASH_B32.to_ascii_lowercase())).unwrap();
        assert_eq!(m3.info_hash, HASH);
    }

    #[test]
    fn encoded_colons_in_xt_are_handled() {
        let m = parse(&format!("magnet:?xt=urn%3Abtih%3A{HASH}")).unwrap();
        assert_eq!(m.info_hash, HASH);
    }

    #[test]
    fn rejects_bad_input() {
        assert_eq!(parse(""), Err(MagnetError::Empty));
        assert_eq!(parse("   "), Err(MagnetError::Empty));
        assert_eq!(parse("http://example.org"), Err(MagnetError::NotMagnet));
        assert_eq!(parse("magnet:xt=urn:btih:abc"), Err(MagnetError::NotMagnet));
        assert_eq!(parse("magnet:?dn=just-a-name"), Err(MagnetError::MissingInfoHash));
        assert_eq!(parse("magnet:?xt=urn:btih:abc"), Err(MagnetError::BadInfoHash));
        assert_eq!(
            parse(&format!("magnet:?xt=urn:btih:{}z", &HASH[..39])),
            Err(MagnetError::BadInfoHash)
        );
        assert_eq!(parse(&format!("magnet:?xt=urn:btih:{}", "1".repeat(41))), Err(MagnetError::BadInfoHash));
        assert_eq!(
            parse("magnet:?xt=urn:btmh:1220aabbccddeeff00112233445566778899aabbccddeeff0011223344556677"),
            Err(MagnetError::V2Only)
        );
        let huge = format!("magnet:?xt=urn:btih:{HASH}&dn={}", "a".repeat(MAX_INPUT_LEN));
        assert_eq!(parse(&huge), Err(MagnetError::TooLong));
    }

    #[test]
    fn hybrid_v1_v2_links_use_the_v1_hash() {
        let m = parse(&format!(
            "magnet:?xt=urn:btih:{HASH}&xt=urn:btmh:1220aabbccddeeff00112233445566778899aabbccddeeff0011223344556677"
        ))
        .unwrap();
        assert_eq!(m.info_hash, HASH);
    }

    #[test]
    fn only_safe_tracker_schemes_survive_and_duplicates_are_dropped() {
        let m = parse(&format!(
            "magnet:?xt=urn:btih:{HASH}&tr=udp://a.example:1&tr=udp://a.example:1&tr=javascript:alert(1)&tr=file:///etc/passwd&tr=ws://x.example&tr=http://b.example/ann"
        ))
        .unwrap();
        assert_eq!(m.trackers, vec!["udp://a.example:1", "http://b.example/ann"]);
    }

    #[test]
    fn tracker_count_is_capped() {
        let mut s = format!("magnet:?xt=urn:btih:{HASH}");
        for i in 0..200 {
            s.push_str(&format!("&tr=udp://t{i}.example:80"));
        }
        assert_eq!(parse(&s).unwrap().trackers.len(), MAX_TRACKERS);
    }

    #[test]
    fn display_names_are_cleaned() {
        let m = parse(&format!("magnet:?xt=urn:btih:{HASH}&dn=%0A%00Evil%20Name%09")).unwrap();
        assert_eq!(m.display_name.as_deref(), Some("Evil Name"));
        let m2 = parse(&format!("magnet:?xt=urn:btih:{HASH}&dn=%20%20")).unwrap();
        assert_eq!(m2.display_name, None);
        let long = format!("magnet:?xt=urn:btih:{HASH}&dn={}", "x".repeat(1000));
        assert_eq!(parse(&long).unwrap().display_name.unwrap().chars().count(), MAX_NAME_CHARS);
    }

    #[test]
    fn canonical_uri_round_trips() {
        let m = parse(&format!(
            "magnet:?xt=urn:btih:{HASH_B32}&dn=Name+with%20spaces%26more&tr=udp%3A%2F%2Ftracker.example.org%3A6969"
        ))
        .unwrap();
        let uri = to_uri(&m);
        assert!(uri.starts_with(&format!("magnet:?xt=urn:btih:{HASH}")));
        assert_eq!(parse(&uri).unwrap(), Magnet { exact_length: None, ..m });
    }

    #[test]
    fn public_trackers_are_valid_and_added_once() {
        // every built-in tracker must survive the cleaning that user input goes through
        for t in PUBLIC_TRACKERS {
            assert_eq!(clean_tracker(t).as_deref(), Some(*t), "{t}");
        }
        assert!(PUBLIC_TRACKERS.len() < MAX_TRACKERS);

        let own = "udp://tracker.example.org:6969/announce";
        let m = parse(&format!(
            "magnet:?xt=urn:btih:{HASH}&tr={}&tr={}",
            percent_encode(own),
            percent_encode(PUBLIC_TRACKERS[0])
        ))
        .unwrap();
        let merged = with_public_trackers(&m);
        assert_eq!(merged.trackers[0], own, "the link's own trackers stay in front");
        assert_eq!(
            merged.trackers.len(),
            1 + PUBLIC_TRACKERS.len(),
            "a tracker the link already has is not added twice"
        );
        assert_eq!(merged.info_hash, m.info_hash);
        // and the result survives the canonical URI round trip
        let back = parse(&to_uri(&merged)).unwrap();
        assert_eq!(back.trackers, merged.trackers);
        assert_eq!(back.info_hash, HASH);
    }

    #[test]
    fn public_trackers_never_push_a_link_over_the_cap() {
        let mut s = format!("magnet:?xt=urn:btih:{HASH}");
        for i in 0..MAX_TRACKERS {
            s.push_str(&format!("&tr=udp://t{i}.example:80"));
        }
        let full = parse(&s).unwrap();
        assert_eq!(full.trackers.len(), MAX_TRACKERS);
        assert_eq!(with_public_trackers(&full).trackers.len(), MAX_TRACKERS);
        // a bare info hash (no trackers at all) gets the whole list
        let bare = parse(&format!("magnet:?xt=urn:btih:{HASH}")).unwrap();
        assert_eq!(with_public_trackers(&bare).trackers.len(), PUBLIC_TRACKERS.len());
    }

    #[test]
    fn percent_codec_edge_cases() {
        assert_eq!(percent_decode("a%2", false), "a%2");
        assert_eq!(percent_decode("100%", false), "100%");
        assert_eq!(percent_decode("%zz", false), "%zz");
        assert_eq!(percent_decode("a+b", true), "a b");
        assert_eq!(percent_decode("a+b", false), "a+b");
        assert_eq!(percent_decode("%41%42", false), "AB");
        assert_eq!(percent_encode("a b&c"), "a%20b%26c");
        assert_eq!(percent_encode("é"), "%C3%A9");
    }

    #[test]
    fn classify_recognises_the_three_input_kinds() {
        assert!(matches!(classify(&format!("magnet:?xt=urn:btih:{HASH}")), Ok(Source::Magnet(_))));
        assert!(matches!(classify(HASH), Ok(Source::Magnet(_))));
        assert!(matches!(classify(HASH_B32), Ok(Source::Magnet(_))));
        assert!(matches!(
            classify("https://example.org/files/a.torrent"),
            Ok(Source::TorrentUrl(_))
        ));
        assert!(classify("").is_err());
        assert!(classify("hello world").is_err());
        assert!(classify("ftp://example.org/a.torrent").is_err());
        assert!(classify("http://").is_err());
        assert!(classify("https://exa mple.org/a").is_err());
        assert!(classify("magnet:?dn=nothing").is_err());
    }

    #[test]
    fn hosts_are_extracted() {
        assert_eq!(url_host("https://User:pw@Example.ORG:8443/a?b#c").as_deref(), Some("example.org"));
        assert_eq!(url_host("http://[::1]:9696/x").as_deref(), Some("::1"));
        assert_eq!(url_host("http://192.168.1.5/dl").as_deref(), Some("192.168.1.5"));
        assert_eq!(url_host("https:///nohost"), None);
        assert_eq!(url_host("not a url"), None);
    }

    #[test]
    fn private_hosts_are_detected() {
        for h in ["localhost", "nas.local", "127.0.0.1", "10.1.2.3", "192.168.0.9", "172.16.5.5", "169.254.1.1", "100.64.0.1", "0.0.0.0", "::1", "fd00::1", "fe80::1"] {
            assert!(is_private_host(h), "{h} should be private");
        }
        for h in ["example.org", "8.8.8.8", "100.128.0.1", "2001:4860:4860::8888", "archive.org"] {
            assert!(!is_private_host(h), "{h} should be public");
        }
    }
}
