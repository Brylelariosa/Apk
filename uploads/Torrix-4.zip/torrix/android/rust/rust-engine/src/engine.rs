//! The engine: a thin, defensive wrapper around a librqbit session.
//!
//! librqbit provides the BitTorrent protocol itself (peer wire protocol,
//! trackers, DHT, magnet metadata exchange, piece download and SHA-1
//! verification, resume). This module adds what a phone app needs on top:
//! the add-torrent flow with file selection, user pause/queue rules, speed
//! limits, the network gate and a cached snapshot for the UI.

use std::collections::HashMap;
use std::num::NonZeroU32;
use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, AtomicU32, AtomicU64, Ordering};
use std::sync::{Arc, Mutex, MutexGuard};
use std::time::Duration;

use librqbit::api::{Api, ApiTorrentListOpts, TorrentIdOrHash};
use librqbit::dht::PersistentDhtConfig;
use librqbit::limits::LimitsConfig;
use librqbit::{
    AddTorrent, AddTorrentOptions, AddTorrentResponse, Session, SessionOptions,
    SessionPersistenceConfig,
};
use serde_json::{json, Value};
use tokio::sync::Notify;

use crate::download_manager::{self, Ema, Order, Policy};
use crate::magnet::{self, Source};
use crate::settings::Settings;
use crate::state::AppState;
use crate::{logging, now_ms, storage, torrent};

const MAX_FILES: usize = 100_000;
/// Free space kept in reserve on top of the selected download size.
const SPACE_MARGIN: u64 = 32 * 1024 * 1024;

fn lock<T>(m: &Mutex<T>) -> MutexGuard<'_, T> {
    m.lock().unwrap_or_else(|e| e.into_inner())
}

fn is_hex40(s: &str) -> bool {
    s.len() == 40 && s.bytes().all(|b| b.is_ascii_hexdigit())
}

fn parse_idx(hash: &str) -> Result<TorrentIdOrHash, String> {
    if !is_hex40(hash) {
        return Err("invalid torrent id".to_string());
    }
    TorrentIdOrHash::parse(hash).map_err(|e| format!("{e:#}"))
}

fn kib_to_limit(kib: u32) -> Option<NonZeroU32> {
    NonZeroU32::new(kib.saturating_mul(1024))
}

/// How long each lookup of a magnet's metadata may run before it is abandoned
/// and started again. A lookup either answers within a few seconds or can sit
/// there without finding anyone until the full timeout, while a fresh one
/// started a moment later succeeds, so waiting the whole timeout on one lookup
/// wastes minutes. The last lookup gets whatever time is left.
const LOOKUP_SLICES_SECS: [u64; 2] = [25, 35];
/// A slice that would leave less than this behind takes the rest instead: a
/// fresh lookup with only a few seconds to live is of no use.
const MIN_TAIL: Duration = Duration::from_secs(10);

fn lookup_slice(attempt: usize, remaining: Duration) -> Duration {
    let want = match LOOKUP_SLICES_SECS.get(attempt) {
        Some(secs) => Duration::from_secs(*secs),
        None => remaining,
    };
    if want.saturating_add(MIN_TAIL) >= remaining {
        remaining
    } else {
        want
    }
}

/// Run the future that `make` builds. If it has not finished when its time
/// slice ends, drop it and start a new one, until `total` has run out
/// (`None`). `attempt` always holds the number of the running lookup (1-based)
/// so the UI can show it.
async fn run_with_restarts<T, F, Fut>(total: Duration, attempt: &AtomicU32, mut make: F) -> Option<T>
where
    F: FnMut() -> Fut,
    Fut: std::future::Future<Output = T>,
{
    let started = tokio::time::Instant::now();
    let mut n = 0usize;
    loop {
        let remaining = total.saturating_sub(started.elapsed());
        if remaining.is_zero() {
            return None;
        }
        let slice = lookup_slice(n, remaining);
        attempt.store(n as u32 + 1, Ordering::Relaxed);
        match tokio::time::timeout(slice, make()).await {
            Ok(done) => return Some(done),
            Err(_) => {
                if started.elapsed() >= total {
                    return None;
                }
                logging::info(format!(
                    "add: no answer after {} s, starting lookup {}",
                    slice.as_secs(),
                    n + 2
                ));
                n += 1;
            }
        }
    }
}

#[derive(Debug, Clone)]
pub struct Paths {
    /// Private app storage: session database, DHT table, state, settings.
    pub engine_dir: PathBuf,
    /// Where torrent data is written while downloading.
    pub staging_dir: PathBuf,
    /// App cache: used for imported .torrent files.
    pub cache_dir: PathBuf,
}

impl Paths {
    fn state_file(&self) -> PathBuf {
        self.engine_dir.join("state.json")
    }
    fn settings_file(&self) -> PathBuf {
        self.engine_dir.join("settings.json")
    }
}

#[derive(Debug)]
struct PreviewFile {
    path: String,
    length: u64,
}

#[derive(Debug)]
struct Preview {
    info_hash: String,
    name: String,
    total_bytes: u64,
    files: Vec<PreviewFile>,
}

enum Phase {
    Resolving,
    Ready,
    Adding,
    Done(String),
    Failed(String),
}

struct AddRequest {
    phase: Phase,
    /// `None` for imported .torrent files (their bytes are in `bytes`).
    source: Option<Source>,
    preview: Option<Preview>,
    bytes: Option<Vec<u8>>,
    task: Option<tokio::task::JoinHandle<()>>,
    /// When the current step (looking up the details, then adding) began.
    step_started_ms: u64,
    /// Number of the lookup the current step is on (1-based), for the UI.
    attempt: Arc<AtomicU32>,
}

/// What the final add hands to the engine.
enum AddInput {
    Bytes(Vec<u8>),
    Url(String),
}

pub struct Core {
    paths: Paths,
    settings: Mutex<Settings>,
    session: Arc<Session>,
    api: Api,
    app_state: Mutex<AppState>,
    emas: Mutex<HashMap<String, Ema>>,
    snapshot_json: Mutex<String>,
    net_allowed: AtomicBool,
    poll_ms: AtomicU64,
    stop: AtomicBool,
    wake: Notify,
    adds: Mutex<HashMap<u64, AddRequest>>,
    next_request: AtomicU64,
}

fn session_options(paths: &Paths, s: &Settings) -> SessionOptions {
    SessionOptions {
        disable_dht: !s.dht_enabled,
        dht_config: Some(PersistentDhtConfig {
            dump_interval: Some(Duration::from_secs(300)),
            config_filename: Some(paths.engine_dir.join("dht.json")),
        }),
        persistence: Some(SessionPersistenceConfig::Json {
            folder: Some(paths.engine_dir.join("session")),
        }),
        // Persist the piece bitfield so a restart does not re-hash everything.
        fastresume: true,
        listen_port_range: if s.listen_port == 0 {
            None
        } else {
            Some(s.listen_port..s.listen_port.saturating_add(10))
        },
        ratelimits: LimitsConfig {
            download_bps: kib_to_limit(s.download_limit_kib),
            upload_bps: kib_to_limit(s.upload_limit_kib),
        },
        ..Default::default()
    }
}

fn preview_from_meta(m: &torrent::TorrentMeta) -> Preview {
    Preview {
        info_hash: m.info_hash.clone(),
        name: m.name.clone(),
        total_bytes: m.total_size,
        files: m
            .files
            .iter()
            .map(|f| PreviewFile {
                path: f.path.clone(),
                length: f.length,
            })
            .collect(),
    }
}

/// Build a preview from the engine's torrent details. Every file path is
/// validated: metadata that came from strangers is never trusted.
fn preview_from_details(d: &Value) -> Result<Preview, String> {
    let info_hash = d
        .get("info_hash")
        .and_then(Value::as_str)
        .unwrap_or("")
        .to_ascii_lowercase();
    if !is_hex40(&info_hash) {
        return Err("The torrent details were incomplete.".to_string());
    }
    let files_v = d
        .get("files")
        .and_then(Value::as_array)
        .ok_or("The torrent has no file list.")?;
    if files_v.is_empty() || files_v.len() > MAX_FILES {
        return Err("The torrent has an unsupported number of files.".to_string());
    }
    let mut files = Vec::with_capacity(files_v.len());
    let mut total: u64 = 0;
    for f in files_v {
        let path = f.get("name").and_then(Value::as_str).unwrap_or("");
        if !storage::is_safe_relative_path(path) {
            return Err("This torrent contains unsafe file paths and was rejected.".to_string());
        }
        let length = f.get("length").and_then(Value::as_u64).unwrap_or(0);
        total = total
            .checked_add(length)
            .ok_or("The torrent size is invalid.")?;
        files.push(PreviewFile {
            path: path.to_string(),
            length,
        });
    }
    let mut name = d
        .get("name")
        .and_then(Value::as_str)
        .unwrap_or("")
        .trim()
        .to_string();
    if name.is_empty() {
        name = files[0].path.split('/').next().unwrap_or("").to_string();
    }
    if name.is_empty() {
        name = info_hash[..8].to_string();
    }
    Ok(Preview {
        info_hash,
        name,
        total_bytes: total,
        files,
    })
}

impl Core {
    pub async fn start(
        paths: Paths,
        settings: Settings,
        net_allowed: bool,
    ) -> Result<Arc<Core>, String> {
        let session_dir = paths.engine_dir.join("session");
        for dir in [&paths.engine_dir, &session_dir, &paths.staging_dir, &paths.cache_dir] {
            std::fs::create_dir_all(dir)
                .map_err(|e| format!("could not create {}: {e}", dir.display()))?;
        }
        logging::info("engine: opening the torrent session");
        let session = Session::new_with_opts(
            paths.staging_dir.clone(),
            session_options(&paths, &settings),
        )
        .await
        .map_err(|e| format!("could not start the torrent engine: {e:#}"))?;
        logging::info("engine: torrent session open");
        let api = Api::new(session.clone(), None);
        let app_state = AppState::load(&paths.state_file());
        let initial = serde_json::to_string(&download_manager::Snapshot::default())
            .unwrap_or_else(|_| "{}".to_string());
        if let Err(e) = settings.save(&paths.settings_file()) {
            logging::warn(format!("could not save settings: {e}"));
        }
        let core = Arc::new(Core {
            paths,
            settings: Mutex::new(settings),
            session,
            api,
            app_state: Mutex::new(app_state),
            emas: Mutex::new(HashMap::new()),
            snapshot_json: Mutex::new(initial),
            net_allowed: AtomicBool::new(net_allowed),
            poll_ms: AtomicU64::new(1000),
            stop: AtomicBool::new(false),
            wake: Notify::new(),
            adds: Mutex::new(HashMap::new()),
            next_request: AtomicU64::new(1),
        });
        let looping = core.clone();
        tokio::spawn(async move {
            looping.run_loop().await;
        });
        logging::info("engine started");
        Ok(core)
    }

    pub fn shutdown(&self) {
        self.stop.store(true, Ordering::Relaxed);
        self.wake.notify_one();
    }

    // ---------------------------------------------------------------- loop

    async fn run_loop(self: Arc<Self>) {
        loop {
            if self.stop.load(Ordering::Relaxed) {
                break;
            }
            self.tick().await;
            let ms = self.poll_ms.load(Ordering::Relaxed).clamp(250, 10_000);
            tokio::select! {
                _ = tokio::time::sleep(Duration::from_millis(ms)) => {}
                _ = self.wake.notified() => {}
            }
        }
    }

    fn policy(&self) -> Policy {
        let s = lock(&self.settings);
        Policy {
            max_active: s.max_active_downloads as usize,
            seed_after_complete: s.seed_after_complete,
            network_allowed: self.net_allowed.load(Ordering::Relaxed),
        }
    }

    fn save_state(&self, st: &AppState) {
        if let Err(e) = st.save(&self.paths.state_file()) {
            logging::error(format!("could not save state: {e}"));
        }
    }

    async fn tick(&self) {
        let list = match serde_json::to_value(
            self.api
                .api_torrent_list_ext(ApiTorrentListOpts { with_stats: true }),
        ) {
            Ok(v) => v,
            Err(e) => {
                logging::error(format!("could not read the torrent list: {e}"));
                return;
            }
        };
        let now = now_ms();
        let policy = self.policy();
        let parsed = {
            let mut st = lock(&self.app_state);
            let mut emas = lock(&self.emas);
            let parsed = download_manager::parse_list(&list, &mut st.torrents, &mut emas, &policy, now);
            if parsed.records_changed {
                self.save_state(&st);
            }
            parsed
        };
        let snapshot = download_manager::build_snapshot(parsed.views, policy.network_allowed, now);
        match serde_json::to_string(&snapshot) {
            Ok(s) => *lock(&self.snapshot_json) = s,
            Err(e) => logging::error(format!("could not encode the snapshot: {e}")),
        }
        for order in download_manager::plan(&parsed.slots, &policy) {
            self.apply(order).await;
        }
    }

    async fn apply(&self, order: Order) {
        let (hash, pause) = match order {
            Order::Start(h) => (h, false),
            Order::Pause(h) => (h, true),
        };
        if let Err(e) = self.set_paused(&hash, pause).await {
            logging::warn(format!(
                "{} {}: {e}",
                if pause { "pause" } else { "resume" },
                &hash[..8]
            ));
        }
    }

    async fn set_paused(&self, hash: &str, paused: bool) -> Result<(), String> {
        let idx = parse_idx(hash)?;
        let handle = self.api.mgr_handle(idx).map_err(|e| e.to_string())?;
        let result = if paused {
            self.session.pause(&handle).await
        } else {
            self.session.unpause(&handle).await
        };
        result.map_err(|e| format!("{e:#}"))
    }

    // ------------------------------------------------------------ accessors

    pub fn snapshot_json(&self) -> String {
        lock(&self.snapshot_json).clone()
    }

    pub fn set_net_allowed(&self, allowed: bool) {
        self.net_allowed.store(allowed, Ordering::Relaxed);
        self.wake.notify_one();
    }

    pub fn set_poll_ms(&self, ms: u64) {
        self.poll_ms.store(ms.clamp(250, 10_000), Ordering::Relaxed);
        self.wake.notify_one();
    }

    /// Returns true when a restart is needed for the change to take effect.
    pub fn set_settings(&self, new: Settings) -> bool {
        let new = new.sanitized();
        let restart = {
            let old = lock(&self.settings);
            old.dht_enabled != new.dht_enabled || old.listen_port != new.listen_port
        };
        // Speed limits apply immediately, without restarting the session.
        self.session
            .ratelimits
            .set_download_bps(kib_to_limit(new.download_limit_kib));
        self.session
            .ratelimits
            .set_upload_bps(kib_to_limit(new.upload_limit_kib));
        if let Err(e) = new.save(&self.paths.settings_file()) {
            logging::warn(format!("could not save settings: {e}"));
        }
        *lock(&self.settings) = new;
        self.wake.notify_one();
        restart
    }

    // ------------------------------------------------------- user actions

    pub fn set_hold(&self, hash: &str, hold: bool) -> Result<(), String> {
        if !is_hex40(hash) {
            return Err("invalid torrent id".to_string());
        }
        {
            let mut st = lock(&self.app_state);
            let rec = st.torrents.entry(hash.to_ascii_lowercase()).or_default();
            rec.hold = hold;
            if rec.added_ms == 0 {
                rec.added_ms = now_ms();
            }
            self.save_state(&st);
        }
        self.wake.notify_one();
        Ok(())
    }

    /// Pause or resume every torrent that is not finished yet.
    pub fn set_hold_all(&self, hold: bool) {
        {
            let mut st = lock(&self.app_state);
            for rec in st.torrents.values_mut() {
                if rec.completed_ms.is_none() {
                    rec.hold = hold;
                }
            }
            self.save_state(&st);
        }
        self.wake.notify_one();
    }

    pub async fn remove(&self, hash: &str, delete_files: bool) -> Result<(), String> {
        let idx = parse_idx(hash)?;
        self.session
            .delete(idx, delete_files)
            .await
            .map_err(|e| format!("{e:#}"))?;
        {
            let mut st = lock(&self.app_state);
            st.torrents.remove(&hash.to_ascii_lowercase());
            self.save_state(&st);
        }
        lock(&self.emas).remove(&hash.to_ascii_lowercase());
        self.wake.notify_one();
        Ok(())
    }

    /// File list of a torrent that is already in the session (used when
    /// saving finished downloads to the user's chosen location).
    pub fn details(&self, hash: &str) -> Result<Value, String> {
        let idx = parse_idx(hash)?;
        let d = self
            .api
            .api_torrent_details(idx)
            .map_err(|e| e.to_string())?;
        let v = serde_json::to_value(&d).map_err(|e| e.to_string())?;
        let mut files: Vec<Value> = Vec::new();
        if let Some(arr) = v.get("files").and_then(Value::as_array) {
            for f in arr {
                let path = f.get("name").and_then(Value::as_str).unwrap_or("");
                if !storage::is_safe_relative_path(path) {
                    continue;
                }
                files.push(json!({
                    "path": path,
                    "length": f.get("length").and_then(Value::as_u64).unwrap_or(0),
                    "included": f.get("included").and_then(Value::as_bool).unwrap_or(true),
                }));
            }
        }
        Ok(json!({
            "name": v.get("name"),
            "output_folder": v.get("output_folder"),
            "files": files,
        }))
    }

    // ------------------------------------------------------------- search

    pub async fn search(&self, query: &str) -> Result<Value, String> {
        let s = lock(&self.settings).clone();
        let torznab = if s.torznab_url.is_empty() {
            None
        } else {
            Some(torrix_search::TorznabConfig {
                url: s.torznab_url.clone(),
                api_key: s.torznab_api_key.clone(),
            })
        };
        let cfg = torrix_search::SearchConfig {
            internet_archive: s.internet_archive_enabled,
            linux_distros: s.linux_distros_enabled,
            torznab,
        };
        let manager = torrix_search::SearchManager::from_config(&cfg)?;
        let resp = manager.search(query, 30, Duration::from_secs(14)).await?;
        serde_json::to_value(&resp).map_err(|e| e.to_string())
    }

    // ------------------------------------------------------ add-torrent flow
    //
    // 1. add_start / add_start_file  -> request id, work happens in the background
    // 2. add_status                  -> resolving | ready (file list) | failed
    // 3. add_confirm(selected files) -> adding | done | failed
    //
    // Magnet links need their metadata from peers first; nothing is added to
    // the session until the user has seen the file list and confirmed.

    fn check_url_allowed(&self, url: &str) -> Result<(), String> {
        let host = magnet::url_host(url).ok_or("That address is not valid.")?;
        if magnet::is_private_host(&host) {
            let allowed = lock(&self.settings).torznab_host();
            if allowed.as_deref() != Some(host.as_str()) {
                return Err("Addresses on your local network are blocked for safety.".to_string());
            }
        }
        Ok(())
    }

    fn new_request(
        &self,
        source: Option<Source>,
        preview: Option<Preview>,
        bytes: Option<Vec<u8>>,
        phase: Phase,
    ) -> u64 {
        let id = self.next_request.fetch_add(1, Ordering::Relaxed);
        let mut adds = lock(&self.adds);
        if adds.len() >= 8 {
            adds.retain(|_, r| !matches!(r.phase, Phase::Done(_) | Phase::Failed(_)));
        }
        adds.insert(
            id,
            AddRequest {
                phase,
                source,
                preview,
                bytes,
                task: None,
                step_started_ms: now_ms(),
                attempt: Arc::new(AtomicU32::new(1)),
            },
        );
        id
    }

    /// The lookup counter of a request (a throw-away one if it was cancelled already).
    fn attempt_counter(&self, id: u64) -> Arc<AtomicU32> {
        lock(&self.adds)
            .get(&id)
            .map(|r| r.attempt.clone())
            .unwrap_or_else(|| Arc::new(AtomicU32::new(1)))
    }

    pub fn add_start(self: &Arc<Self>, input: &str) -> Result<u64, String> {
        let source = magnet::classify(input)?;
        if let Source::TorrentUrl(u) = &source {
            self.check_url_allowed(u)?;
        }
        let id = self.new_request(Some(source.clone()), None, None, Phase::Resolving);
        let attempt = self.attempt_counter(id);
        let core = self.clone();
        let handle = crate::runtime().spawn(async move {
            core.resolve(id, source, attempt).await;
        });
        if let Some(r) = lock(&self.adds).get_mut(&id) {
            r.task = Some(handle);
        }
        Ok(id)
    }

    /// Import a .torrent file that Kotlin copied into the cache directory.
    pub fn add_start_file(self: &Arc<Self>, path: &str) -> Result<u64, String> {
        let canon = std::fs::canonicalize(path)
            .map_err(|_| "Could not read the .torrent file.".to_string())?;
        let cache = std::fs::canonicalize(&self.paths.cache_dir).map_err(|e| e.to_string())?;
        if !canon.starts_with(&cache) {
            return Err("That file location is not allowed.".to_string());
        }
        let len = std::fs::metadata(&canon)
            .map_err(|_| "Could not read the .torrent file.".to_string())?
            .len();
        if len as usize > torrent::MAX_TORRENT_BYTES {
            return Err("The .torrent file is too large.".to_string());
        }
        let bytes =
            std::fs::read(&canon).map_err(|_| "Could not read the .torrent file.".to_string())?;
        let _ = std::fs::remove_file(&canon);
        let meta = torrent::parse_torrent(&bytes)
            .map_err(|e| format!("That is not a valid .torrent file: {e}"))?;
        Ok(self.new_request(None, Some(preview_from_meta(&meta)), Some(bytes), Phase::Ready))
    }

    async fn resolve(self: Arc<Self>, id: u64, source: Source, attempt: Arc<AtomicU32>) {
        let timeout = Duration::from_secs(lock(&self.settings).resolve_timeout_secs as u64);
        let result = match source {
            Source::Magnet(m) => self.resolve_magnet(&m, timeout, &attempt).await,
            Source::TorrentUrl(u) => self.resolve_url(&u).await,
        };
        let mut adds = lock(&self.adds);
        if let Some(r) = adds.get_mut(&id) {
            match result {
                Ok((preview, bytes)) => {
                    r.preview = Some(preview);
                    r.bytes = bytes;
                    r.phase = Phase::Ready;
                }
                Err(e) => r.phase = Phase::Failed(e),
            }
        }
    }

    async fn resolve_magnet(
        &self,
        m: &magnet::Magnet,
        timeout: Duration,
        attempt: &AtomicU32,
    ) -> Result<(Preview, Option<Vec<u8>>), String> {
        // Public trackers give peers within a second or two even when the link
        // has no (working) tracker of its own and the DHT is still warming up.
        let with_trackers = magnet::with_public_trackers(m);
        let dht = if lock(&self.settings).dht_enabled { "on" } else { "off" };
        logging::info(format!(
            "add: looking up a magnet ({} trackers, dht {dht})",
            with_trackers.trackers.len()
        ));
        let uri = magnet::to_uri(&with_trackers);
        let began = std::time::Instant::now();
        let outcome = run_with_restarts(timeout, attempt, || {
            let opts = AddTorrentOptions {
                list_only: true,
                ..Default::default()
            };
            self.api
                .api_add_torrent(AddTorrent::from_url(uri.clone()), Some(opts))
        })
        .await;
        let resp = match outcome {
            None => {
                logging::warn(format!(
                    "add: no details after {} s and {} lookups",
                    timeout.as_secs(),
                    attempt.load(Ordering::Relaxed)
                ));
                return Err("Timed out waiting for the torrent's file list. No peers answered yet; check your connection and try again.".to_string());
            }
            Some(Err(e)) => return Err(format!("{e}")),
            Some(Ok(r)) => r,
        };
        logging::info(format!(
            "add: details found in {} ms (lookup {})",
            began.elapsed().as_millis(),
            attempt.load(Ordering::Relaxed)
        ));
        let v = serde_json::to_value(&resp).map_err(|e| e.to_string())?;
        let details = v.get("details").unwrap_or(&v);
        Ok((preview_from_details(details)?, None))
    }

    async fn resolve_url(&self, url: &str) -> Result<(Preview, Option<Vec<u8>>), String> {
        let client = torrix_search::http::client()?;
        let bytes = torrix_search::http::fetch_bytes(&client, url, torrent::MAX_TORRENT_BYTES)
            .await
            .map_err(|e| format!("Could not download the .torrent file: {e}"))?;
        let meta = torrent::parse_torrent(&bytes)
            .map_err(|e| format!("That is not a valid .torrent file: {e}"))?;
        Ok((preview_from_meta(&meta), Some(bytes)))
    }

    pub fn add_status(&self, id: u64) -> Result<Value, String> {
        let adds = lock(&self.adds);
        let r = adds.get(&id).ok_or("Unknown add request.")?;
        Ok(match &r.phase {
            Phase::Resolving => json!({
                "state": "resolving",
                "elapsed_ms": now_ms().saturating_sub(r.step_started_ms),
                "attempt": r.attempt.load(Ordering::Relaxed),
            }),
            Phase::Adding => json!({
                "state": "adding",
                "elapsed_ms": now_ms().saturating_sub(r.step_started_ms),
                "attempt": r.attempt.load(Ordering::Relaxed),
            }),
            Phase::Done(h) => json!({"state": "done", "hash": h}),
            Phase::Failed(e) => json!({"state": "failed", "error": e}),
            Phase::Ready => {
                let p = r.preview.as_ref().ok_or("Missing torrent details.")?;
                let files: Vec<Value> = p
                    .files
                    .iter()
                    .enumerate()
                    .map(|(i, f)| json!({"index": i, "path": f.path, "length": f.length}))
                    .collect();
                json!({
                    "state": "ready",
                    "hash": p.info_hash,
                    "name": p.name,
                    "total_bytes": p.total_bytes,
                    "files": files,
                })
            }
        })
    }

    pub fn add_confirm(
        self: &Arc<Self>,
        id: u64,
        only_files: Option<Vec<usize>>,
    ) -> Result<(), String> {
        let (source, bytes, hash, selected_total, only, attempt) = {
            let mut adds = lock(&self.adds);
            let r = adds.get_mut(&id).ok_or("Unknown add request.")?;
            if !matches!(r.phase, Phase::Ready) {
                return Err("The torrent details are not ready yet.".to_string());
            }
            let preview = r.preview.as_ref().ok_or("Missing torrent details.")?;
            let count = preview.files.len();
            let only = match only_files {
                None => None,
                Some(mut v) => {
                    v.sort_unstable();
                    v.dedup();
                    if v.is_empty() {
                        return Err("Select at least one file to download.".to_string());
                    }
                    if v.iter().any(|&i| i >= count) {
                        return Err("The file selection is not valid.".to_string());
                    }
                    if v.len() == count {
                        None
                    } else {
                        Some(v)
                    }
                }
            };
            let selected_total = match &only {
                None => preview.total_bytes,
                Some(v) => v
                    .iter()
                    .map(|&i| preview.files[i].length)
                    .fold(0u64, |a, b| a.saturating_add(b)),
            };
            let hash = preview.info_hash.clone();
            r.phase = Phase::Adding;
            r.step_started_ms = now_ms();
            r.attempt.store(1, Ordering::Relaxed);
            (
                r.source.clone(),
                r.bytes.take(),
                hash,
                selected_total,
                only,
                r.attempt.clone(),
            )
        };
        let core = self.clone();
        let handle = crate::runtime().spawn(async move {
            core.finish_add(id, source, bytes, hash, only, selected_total, attempt)
                .await;
        });
        if let Some(r) = lock(&self.adds).get_mut(&id) {
            r.task = Some(handle);
        }
        Ok(())
    }

    #[allow(clippy::too_many_arguments)]
    async fn finish_add(
        self: Arc<Self>,
        id: u64,
        source: Option<Source>,
        bytes: Option<Vec<u8>>,
        hash: String,
        only_files: Option<Vec<usize>>,
        selected_total: u64,
        attempt: Arc<AtomicU32>,
    ) {
        let result = self
            .do_add(source, bytes, &hash, only_files, selected_total, &attempt)
            .await;
        {
            let mut adds = lock(&self.adds);
            if let Some(r) = adds.get_mut(&id) {
                r.phase = match result {
                    Ok(()) => Phase::Done(hash),
                    Err(e) => Phase::Failed(e),
                };
            }
        }
        self.wake.notify_one();
    }

    async fn do_add(
        &self,
        source: Option<Source>,
        bytes: Option<Vec<u8>>,
        hash: &str,
        only_files: Option<Vec<usize>>,
        selected_total: u64,
        attempt: &AtomicU32,
    ) -> Result<(), String> {
        if let Some(free) = storage::free_bytes(&self.paths.staging_dir) {
            let need = selected_total.saturating_add(SPACE_MARGIN);
            if free < need {
                return Err(format!(
                    "Not enough free storage: this needs {} but only {} is available.",
                    storage::human_bytes(need),
                    storage::human_bytes(free)
                ));
            }
        }
        // A magnet link needs its metadata from peers again here (the details
        // step only listed it), so it gets the same public trackers and the
        // same fresh-lookup treatment as that step.
        let input = match (bytes, source) {
            (Some(b), _) => AddInput::Bytes(b),
            (None, Some(Source::Magnet(m))) => {
                AddInput::Url(magnet::to_uri(&magnet::with_public_trackers(&m)))
            }
            (None, Some(Source::TorrentUrl(u))) => AddInput::Url(u),
            (None, None) => return Err("Nothing to add.".to_string()),
        };
        let output = self.paths.staging_dir.to_string_lossy().into_owned();
        let timeout = Duration::from_secs(lock(&self.settings).resolve_timeout_secs as u64);
        let began = std::time::Instant::now();
        let outcome = run_with_restarts(timeout, attempt, || {
            let add = match &input {
                AddInput::Bytes(b) => AddTorrent::from_bytes(b.clone()),
                AddInput::Url(u) => AddTorrent::from_url(u.clone()),
            };
            let opts = AddTorrentOptions {
                overwrite: true,
                output_folder: Some(output.clone()),
                only_files: only_files.clone(),
                ..Default::default()
            };
            self.session.add_torrent(add, Some(opts))
        })
        .await;
        let resp = match outcome {
            None => {
                logging::warn(format!(
                    "add: not started after {} s and {} lookups",
                    timeout.as_secs(),
                    attempt.load(Ordering::Relaxed)
                ));
                return Err("Timed out while adding the torrent.".to_string());
            }
            Some(r) => r.map_err(|e| format!("{e:#}"))?,
        };
        logging::info(format!(
            "add: torrent added in {} ms (lookup {})",
            began.elapsed().as_millis(),
            attempt.load(Ordering::Relaxed)
        ));
        if let AddTorrentResponse::ListOnly(_) = resp {
            return Err("The engine returned only a file list.".to_string());
        }
        {
            let mut st = lock(&self.app_state);
            st.torrents.entry(hash.to_string()).or_insert_with(|| {
                crate::state::TorrentRecord {
                    hold: false,
                    added_ms: now_ms(),
                    completed_ms: None,
                }
            });
            self.save_state(&st);
        }
        Ok(())
    }

    pub fn add_cancel(&self, id: u64) {
        let removed = lock(&self.adds).remove(&id);
        if let Some(r) = removed {
            // Only abort the metadata lookup; never interrupt the actual add.
            if matches!(r.phase, Phase::Resolving) {
                if let Some(h) = r.task {
                    h.abort();
                }
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn details_become_a_preview_with_total_size() {
        let d = json!({"info_hash": "DA39A3EE5E6B4B0D3255BFEF95601890AFD80709", "name": "Album",
            "files": [{"name": "Album/01.flac", "length": 3_000_000_000u64, "included": true},
                      {"name": "Album/02.flac", "length": 3_000_000_000u64, "included": true}]});
        let p = preview_from_details(&d).unwrap();
        assert_eq!(p.info_hash, "da39a3ee5e6b4b0d3255bfef95601890afd80709");
        assert_eq!(p.name, "Album");
        assert_eq!(p.total_bytes, 6_000_000_000);
        assert_eq!(p.files.len(), 2);
    }

    #[test]
    fn unsafe_or_incomplete_details_are_rejected() {
        let evil = json!({"info_hash": "da39a3ee5e6b4b0d3255bfef95601890afd80709", "files": [{"name": "../../etc/passwd", "length": 1}]});
        assert!(preview_from_details(&evil).unwrap_err().contains("unsafe"));
        let abs = json!({"info_hash": "da39a3ee5e6b4b0d3255bfef95601890afd80709", "files": [{"name": "/system/bin/sh", "length": 1}]});
        assert!(preview_from_details(&abs).is_err());
        assert!(preview_from_details(&json!({"info_hash": "xyz", "files": []})).is_err());
        assert!(preview_from_details(&json!({"info_hash": "da39a3ee5e6b4b0d3255bfef95601890afd80709"})).is_err());
        assert!(preview_from_details(&json!({"info_hash": "da39a3ee5e6b4b0d3255bfef95601890afd80709", "files": []})).is_err());
        let overflow = json!({"info_hash": "da39a3ee5e6b4b0d3255bfef95601890afd80709",
            "files": [{"name": "a", "length": u64::MAX}, {"name": "b", "length": 2}]});
        assert!(preview_from_details(&overflow).is_err());
    }

    #[test]
    fn missing_names_fall_back_to_the_first_path_component_or_the_hash() {
        let d = json!({"info_hash": "da39a3ee5e6b4b0d3255bfef95601890afd80709", "files": [{"name": "Show/e01.mkv", "length": 5}]});
        assert_eq!(preview_from_details(&d).unwrap().name, "Show");
    }

    #[test]
    fn lookups_restart_in_slices_and_the_last_one_gets_the_rest() {
        let mut left = Duration::from_secs(120);
        let mut slices = Vec::new();
        for n in 0..10 {
            if left.is_zero() {
                break;
            }
            let s = lookup_slice(n, left);
            slices.push(s.as_secs());
            left -= s;
        }
        assert_eq!(slices, vec![25, 35, 60]);
        // short timeouts are a single lookup, never a pointless short restart
        assert_eq!(lookup_slice(0, Duration::from_secs(30)).as_secs(), 30);
        assert_eq!(lookup_slice(0, Duration::from_secs(15)).as_secs(), 15);
        // 60 s: one 25 s lookup, then a 35 s one
        assert_eq!(lookup_slice(0, Duration::from_secs(60)).as_secs(), 25);
        assert_eq!(lookup_slice(1, Duration::from_secs(35)).as_secs(), 35);
    }

    #[test]
    fn limits_convert_kib_to_bytes_per_second() {
        assert_eq!(kib_to_limit(0), None);
        assert_eq!(kib_to_limit(1).map(|n| n.get()), Some(1024));
        assert_eq!(kib_to_limit(500).map(|n| n.get()), Some(512_000));
        assert!(kib_to_limit(u32::MAX).is_some(), "saturates instead of overflowing");
    }

    #[test]
    fn torrent_ids_must_be_info_hashes() {
        assert!(parse_idx("12").is_err(), "numeric ids are never accepted from the UI");
        assert!(parse_idx("zz39a3ee5e6b4b0d3255bfef95601890afd80709").is_err());
        assert!(parse_idx("da39a3ee5e6b4b0d3255bfef95601890afd80709").is_ok());
    }

    #[test]
    fn torrent_metadata_becomes_a_preview() {
        let meta = torrent::parse_torrent(crate::torrent::fixtures::MULTI_TORRENT).unwrap();
        let p = preview_from_meta(&meta);
        assert_eq!(p.name, "album");
        assert_eq!(p.total_bytes, 12);
        assert_eq!(p.files[0].path, "album/cd1/a.flac");
    }
}
