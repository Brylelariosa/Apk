//! Read-only access to the simulated planet at arbitrary positions and any level of detail.
//! Large scales come from the simulation grids; small scales are fractal detail whose amplitude
//! is steered by simulated roughness (tectonic activity, relief), so detail is consistent with the
//! geology instead of being random noise.

use crate::grid::*;
use crate::mathx::*;
use crate::world::*;
use crate::world_data::*;

pub struct DetailTab {
    pub n: usize,
    pub sc: [f64; 14],
    pub o1: [f64; 14],
    pub o2: [f64; 14],
    pub o3: [f64; 14],
}

/// Below this smooth height (metres) the sea floor lies under opaque water and gets no fractal detail at all.
const DEEP_FLOOR_M: f64 = -1500.0;
/// Fractal detail may never cancel more than this share of the simulated height above (or below) sea level.
const SHORE_KEEP: f64 = 0.85;

/// Share of the fractal detail amplitude a spot receives, from its smooth (simulated) height `base` in metres.
/// Rugged land gets all of it from 60 m upwards; it fades out towards the shoreline, and the open sea floor gets a
/// sixth of it. So the shelf stays smooth instead of sprouting islets and speckles, and coastal plains stay flat.
#[inline]
pub fn detail_envelope(base: f64) -> f64 {
    if base > 0.0 {
        smoothstep(0.0, 60.0, base)
    } else {
        0.16 * smoothstep(0.0, 60.0, -base)
    }
}

/// Limits fractal detail `sum` (metres) so it can never flip a spot between land and sea: the coastline stays exactly
/// where the simulation put it. Without this the noise poked islets out of the shallow shelf and dug ponds into
/// coastal plains, which showed up as dotted water.
#[inline]
pub fn keep_shoreline(base: f64, sum: f64) -> f64 {
    let keep = -SHORE_KEEP * base;
    if base > 0.0 {
        if sum < keep {
            keep
        } else {
            sum
        }
    } else if sum > keep {
        keep
    } else {
        sum
    }
}

/// Is a point under lake water? `lake_lvl` and `ground_lin` are the bilinearly interpolated lake surface and terrain
/// height of the fine grid at the point: their difference is the *simulated* lake depth, exactly 0 away from lakes
/// (the grid stores lake level == terrain height there). `h` is the detailed terrain height, `base` the smooth one.
/// The old test compared the lake level with the detailed height only, so every dip of the fractal detail on dry land
/// turned into a pond.
#[inline]
pub fn lake_flooded(lake_lvl: f64, ground_lin: f64, h: f64, base: f64) -> bool {
    lake_lvl - ground_lin > 1.0 && lake_lvl > h + 0.5 && lake_lvl > 0.5 && base > -5.0
}

pub struct Sampler<'a> {
    pub s: &'a StaticData,
    pub d: &'a DynamicData,
    pub fg: &'a CubeGrid,
    pub cg: &'a CubeGrid,
    pub t: &'a TerrainData,
    pub h: &'a HydroData,
    pub e: &'a EcoData,
    pub rm: f64,
    pub gam: f64,
}

impl<'a> Sampler<'a> {
    pub fn new(v: &'a View) -> Sampler<'a> {
        Sampler {
            s: &v.s,
            d: &v.d,
            fg: &v.s.fg,
            cg: &v.s.cg,
            t: v.s.t(),
            h: v.s.h(),
            e: v.s.e(),
            rm: v.s.dv.r,
            gam: v.s.dv.lapse,
        }
    }

    pub fn base_height(&self, p: V3) -> f64 {
        let mut h = self.fg.sample_cubic(&self.t.height, p) as f64;
        let gl = self.cg.sample(&self.d.glacier, p);
        if gl > 1.0 && h > 0.0 {
            h += 0.85 * (gl as f64);
        }
        h
    }

    pub fn rough_at(&self, p: V3) -> f64 {
        self.fg.sample(&self.t.rough, p) as f64
    }

    /// Per-octave constants of the fractal detail. They depend only on the planet radius and lam_min (not on the
    /// position), so a chunk builds this once instead of redoing a division per octave per sample.
    pub fn make_detail_tab(&self, lam_min: f64) -> DetailTab {
        let mut t = DetailTab { n: 0, sc: [0.0; 14], o1: [0.0; 14], o2: [0.0; 14], o3: [0.0; 14] };
        let mut lam = 62000.0f64;
        let mut j = 0usize;
        while j < 14 && lam >= lam_min {
            t.sc[j] = self.rm / lam;
            t.o1[j] = 17.3 * (j as f64);
            t.o2[j] = 9.1 * (j as f64);
            t.o3[j] = 5.7 * (j as f64);
            t.n = j + 1;
            j += 1;
            lam *= 0.5;
        }
        t
    }

    /// fractal detail (metres) from a prepared table.
    pub fn detail_t(&self, p: V3, rough: f64, base: f64, tb: &DetailTab) -> f64 {
        if base < DEEP_FLOOR_M {
            return 0.0;
        }
        let nz = &self.s.noise;
        let mut sum = 0.0f64;
        let mut amp = 560.0 * rough * detail_envelope(base);
        let mut gx = 0.0f32;
        let mut gy = 0.0f32;
        let mut gz = 0.0f32;
        for j in 0..tb.n {
            let sc = tb.sc[j];
            let (n, g) = nz.n3d((p.x * sc + tb.o1[j]) as f32, (p.y * sc - tb.o2[j]) as f32, (p.z * sc + tb.o3[j]) as f32);
            gx += g[0];
            gy += g[1];
            gz += g[2];
            let damp = 1.0 / (1.0 + 0.55 * ((gx * gx + gy * gy + gz * gz) as f64));
            let v: f32 = if j < 4 { (1.0f32 - n.abs()) * 1.6f32 - 0.8f32 } else { n };
            sum += amp * (v as f64) * damp;
            amp *= 0.5359;
        }
        keep_shoreline(base, sum)
    }

    /// fractal detail (metres). lam_min = smallest wavelength worth synthesising.
    pub fn detail(&self, p: V3, rough: f64, base: f64, lam_min: f64) -> f64 {
        let tb = self.make_detail_tab(lam_min);
        self.detail_t(p, rough, base, &tb)
    }

    pub fn height(&self, p: V3, lam_min: f64) -> f64 {
        let b = self.base_height(p);
        b + self.detail(p, self.rough_at(p), b, lam_min)
    }

    /// Height of the visible surface at `p` in metres: the detailed terrain, raised to the water level inside a lake
    /// and never below sea level. Same rules as the chunk builder, so the camera, the city markers and the "Why?"
    /// panel agree with what is drawn.
    pub fn surface_height(&self, p: V3, lam_min: f64) -> f64 {
        let base = self.base_height(p);
        let h = base + self.detail(p, self.rough_at(p), base, lam_min);
        let ll = self.fg.sample(&self.h.lake_level, p) as f64;
        let lb = self.fg.sample(&self.t.height, p) as f64;
        let top = if lake_flooded(ll, lb, h, base) { ll } else { h };
        top.max(0.0)
    }

    /// current-date climate at coarse resolution (bilinear)
    pub fn cur(&self, f: &[f32], p: V3) -> f32 {
        self.cg.sample(f, p)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn envelope_is_continuous_and_bounded() {
        assert!(detail_envelope(0.0).abs() < 1e-12);
        assert!(detail_envelope(-0.001) < 1e-6);
        assert!((detail_envelope(500.0) - 1.0).abs() < 1e-12);
        assert!((detail_envelope(-5000.0) - 0.16).abs() < 1e-12);
        let mut prev = detail_envelope(-200.0);
        let mut x = -200.0f64;
        while x < 200.0 {
            x += 0.5;
            let e = detail_envelope(x);
            assert!((e - prev).abs() < 0.05);
            assert!(e >= 0.0 && e <= 1.0);
            prev = e;
        }
    }

    #[test]
    fn detail_never_flips_land_and_sea() {
        for i in -300..300 {
            let base = (i as f64) * 0.7;
            for k in -40..40 {
                let sum = (k as f64) * 25.0;
                let h = base + keep_shoreline(base, sum);
                if base > 0.0 {
                    assert!(h > 0.0);
                } else if base < 0.0 {
                    assert!(h < 0.0);
                }
            }
        }
    }

    #[test]
    fn lakes_need_a_simulated_lake() {
        // no simulated lake (lake level == terrain height): a dip in the fractal detail must not become a pond
        assert!(!lake_flooded(500.0, 500.0, 470.0, 500.0));
        // inside a 20 m deep basin the water covers only terrain below the lake level
        assert!(lake_flooded(500.0, 480.0, 490.0, 480.0));
        assert!(!lake_flooded(500.0, 480.0, 510.0, 480.0));
        // never in the sea
        assert!(!lake_flooded(0.2, -30.0, -35.0, -30.0));
    }
}
