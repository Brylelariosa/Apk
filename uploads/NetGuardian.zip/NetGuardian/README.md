# NetGuardian

A Kotlin + Jetpack Compose (Material 3) network monitoring app: live per-app bandwidth,
historical usage (daily/weekly/monthly), and a foreground service that keeps tracking in the
background. MVVM + Repository pattern, Room for history, Hilt for DI, Coroutines/Flow
throughout.

## Building via your GitHub Actions workflow

1. Zip the **contents** of this folder (so `settings.gradle.kts` sits at the zip root, or at
   most a few folders deep) and place the zip under `uploads/` in your repo, then push.
2. The existing workflow unzips it, fetches `gradle-wrapper.jar` for Gradle 8.6, and runs
   `./gradlew assembleDebug` (or `assembleRelease` if you've configured the keystore secrets).
3. The APK is uploaded as a build artifact; the zip is deleted from the repo afterward so it
   doesn't retrigger the workflow.

### Getting a size-optimized (release) build, not just debug

Without `KEYSTORE_BASE64` / `STORE_PASSWORD` / `KEY_ALIAS` / `KEY_PASSWORD` repo secrets set,
the workflow builds the **debug** variant, which is intentionally left unminified (readable
stack traces, faster iteration) and is noticeably larger. The **release** build type has
R8 minification, resource shrinking, and locale stripping enabled — that's the one to build if
APK size matters. To get it:

1. Generate a keystore: `keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias netguardian`
2. Base64-encode it and add these repo secrets: `KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
3. Push again — the workflow will detect the secret and run `assembleRelease` instead.

## APK size optimizations already applied

- **R8 minification + resource shrinking** on the release build type (`isMinifyEnabled` /
  `isShrinkResources`), which is also why depending on `material-icons-extended` (needed for
  the bottom nav's outlined icons) is safe — R8 tree-shakes every icon the app doesn't
  reference; Google's own guidance is that this module is fine to depend on directly as long
  as minification is on.
- **`resConfigs("en")`** strips non-English string tables that AndroidX/Compose dependencies
  ship for accessibility labels (~60 languages otherwise bundled).
- **No support-library vector drawables** — `minSdk` is 30 (Android 11), which has native
  vector drawable support since API 21, so the compat shim is skipped entirely. The launcher
  icon is a pure vector adaptive icon (no raster PNGs at all).
- **Unused build features disabled explicitly** (`buildConfig`, `aidl`, `renderScript`,
  `resValues`, `shaders` all `false`) so nothing is generated or packaged that the app doesn't
  use.
- **Packaging excludes** for license/notice files and coroutines' debug-probe metadata that
  otherwise ride along in every dependency's jar.
- **kapt instead of KSP** for Room/Hilt — a build-time tradeoff (kapt is slower), not an APK
  size one; it was chosen for tighter version compatibility guarantees rather than sizing.

## Blocking apps from the network (Firewall)

Each app's detail screen (and a quick icon, plus multi-select batch blocking, on the Apps list)
has a "Block internet access" control. Settings > Firewall lets you switch between two modes:

- **Blocklist** (default): only the apps you pick are cut off. Everything else works normally.
- **Allowlist**: only the apps you pick get internet access - *everything* else on the device is
  blocked, including system apps like Google Play Services unless you explicitly add them too.
  This uses the exact same local-VPN sinkhole mechanism as Blocklist mode, just inverted
  (`addDisallowedApplication()` instead of `addAllowedApplication()`) - the real risk isn't
  technical, it's that it affects the whole device by default, which is why the UI shows a clear
  warning before you can use it.

First time you block anything, you'll see Android's one-time system VPN consent dialog - that's
expected and only appears once. Turning the firewall on disconnects any other VPN you're
actively using (Android only allows one at a time, system-wide).

### Data caps

From an app's detail screen you can set a daily data cap for that app - once it's used that much
today, NetGuardian blocks it automatically, and un-blocks it again the next day. From Settings
you can also set one global daily device cap, but that only sends a notification rather than
blocking anything - auto-blocking the whole device's internet on a soft usage threshold felt like
a much riskier default than a single app being blocked, so that stays a one-tap manual decision.

### Scheduled blocking

Settings > Firewall > "Manage schedules" lets you block a set of apps during recurring windows
(e.g. "Work apps off, weekdays, 9am-5pm"). Schedules only add to the Blocklist-mode block list -
they don't apply in Allowlist mode, and they don't support windows that wrap past midnight (a
schedule's end time must be later than its start time on the same day); both were deliberate
scope cuts rather than oversights.

## First-run setup

The first time you open the app, a short 3-step walkthrough explains Usage Access,
Notifications, and VPN permission before you land on the Dashboard - each step is skippable, and
the app works the same as before if you skip everything (you'll just see the in-context
permission prompts instead, same as always).

## Battery and heat

Two IPC-heavy calls the monitoring service makes each tick - `NetworkStatsManager` (per-app
bytes) and `UsageStatsManager` (foreground app detection) - now back off automatically as the
device's thermal status rises, using `PowerManager`'s thermal API. At normal temperature they run
at your configured refresh interval; under moderate thermal pressure (e.g. an intense game
session) the gap between those specific calls widens to 5s, then 15s, then 30s at more severe
levels, and returns to normal once the device cools down. The device-wide speed reading
(TrafficStats-based) keeps updating at full speed throughout, since it's just fast syscalls, not
IPC, and isn't a meaningful contributor to heat. This is intentionally not a Settings toggle -
it only ever kicks in when the device is already hot, where reduced polling granularity is a
reasonable tradeoff rather than a decision worth surfacing each time.

## Permissions you'll need to grant manually after installing

- **Usage Access** (Settings → Apps → Special access → Usage access): required for
  foreground/background classification and all historical stats. NetGuardian cannot request
  this via a normal permission dialog — the Dashboard shows a card with a button that opens
  the right settings screen for you.
- **Notifications**: requested automatically on first launch (Android 13+); needed for the
  persistent "monitoring active" status notification.
- Consider exempting the app from battery optimization if you want uninterrupted background
  tracking across long idle periods (OEM battery managers vary; not automated here since it's
  a system-level, per-OEM setting).

## Design notes / scope decisions worth knowing about

- **Per-app "active now" detection and per-app history** are sourced from `NetworkStatsManager`
  (gated by the Usage Access permission this app already requests), not `TrafficStats`'s
  per-UID calls. An earlier version of this app used `TrafficStats.getUidRxBytes/getUidTxBytes`
  for other apps' UIDs, which is only reliably documented to work for *your own app's* traffic -
  Android's own network-usage API docs are explicit that other UIDs need the Usage
  Access-gated path. If Active Apps still shows nothing and Usage Access is granted, the most
  likely remaining cause is Usage Access having been revoked or not yet taken effect - toggling
  it off/on in Settings and reopening the app is the first thing to try.
  A VPN-based packet interceptor (what GlassWire/NetGuard use for the most exact per-connection
  attribution) would be more precise still but is a much larger, riskier piece of engineering;
  sticking with `NetworkStatsManager` was a deliberate scope tradeoff.
- Live per-tick readings are batched in memory and flushed to Room every ~30s (not once per
  tick) to keep disk I/O — and battery draw — low even at a 1-second refresh interval.
- History is stored for 90 days by default and purged automatically; adjust
  `NetworkMonitorService.RETENTION_MS` if you want longer.
- The Room database bumped from version 1 to 2 to add the schedules table. Since the app still
  uses `fallbackToDestructiveMigration()`, upgrading wipes existing history once (not on every
  future run) - the known tradeoff already noted above about not having a real migration path
  yet applies here too.
- The Apps list's sort menu has a "Blocked First" option, and blocked apps show a red tint plus
  a "Blocked" label so they're visible without needing to sort or search for them.
- History's Wi-Fi/Mobile/Other filter only applies to the chart; "Top Downloaders"/"Top
  Uploaders" intentionally stay all-transport combined, a scope cut to avoid a second set of
  per-transport ranking queries for comparatively little benefit.

## What to do if the CI build fails

I was not able to compile this project in my own sandbox (no Android SDK / no network access
there), so despite a careful manual review there's a real chance the very first CI run
surfaces a small issue — usually a version-compatibility edge case between AGP/Kotlin/Compose
that only shows up mid-build. If that happens, paste the Gradle error output back and it can
be fixed directly against the real compiler output rather than guesswork.
