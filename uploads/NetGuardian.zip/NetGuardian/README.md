# NetGuardian

A Kotlin + Jetpack Compose (Material 3) network monitoring app: live per-app bandwidth,
historical usage (daily/weekly/monthly), and a foreground service that keeps tracking in the
background. MVVM + Repository pattern, Room for history, Hilt for DI, Coroutines/Flow
throughout.

## Building via your GitHub Actions workflow

1. Zip the **contents** of this folder (so `settings.gradle.kts` sits at the zip root, or at
   most a few folders deep) and place the zip under `uploads/` in your repo, then push.
2. The existing workflow unzips it, fetches `gradle-wrapper.jar` for Gradle 8.6, and runs
   `./gradlew assembleDebug` (or `assembleRelease` if you've configured the keystore secrets).
3. The APK is uploaded as a build artifact; the zip is deleted from the repo afterward so it
   doesn't retrigger the workflow.

### Getting a size-optimized (release) build, not just debug

Without `KEYSTORE_BASE64` / `STORE_PASSWORD` / `KEY_ALIAS` / `KEY_PASSWORD` repo secrets set,
the workflow builds the **debug** variant, which is intentionally left unminified (readable
stack traces, faster iteration) and is noticeably larger. The **release** build type has
R8 minification, resource shrinking, and locale stripping enabled — that's the one to build if
APK size matters. To get it:

1. Generate a keystore: `keytool -genkey -v -keystore release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias netguardian`
2. Base64-encode it and add these repo secrets: `KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
3. Push again — the workflow will detect the secret and run `assembleRelease` instead.

## APK size optimizations already applied

- **R8 minification + resource shrinking** on the release build type (`isMinifyEnabled` /
  `isShrinkResources`), which is also why depending on `material-icons-extended` (needed for
  the bottom nav's outlined icons) is safe — R8 tree-shakes every icon the app doesn't
  reference; Google's own guidance is that this module is fine to depend on directly as long
  as minification is on.
- **`resConfigs("en")`** strips non-English string tables that AndroidX/Compose dependencies
  ship for accessibility labels (~60 languages otherwise bundled).
- **No support-library vector drawables** — `minSdk` is 30 (Android 11), which has native
  vector drawable support since API 21, so the compat shim is skipped entirely. The launcher
  icon is a pure vector adaptive icon (no raster PNGs at all).
- **Unused build features disabled explicitly** (`buildConfig`, `aidl`, `renderScript`,
  `resValues`, `shaders` all `false`) so nothing is generated or packaged that the app doesn't
  use.
- **Packaging excludes** for license/notice files and coroutines' debug-probe metadata that
  otherwise ride along in every dependency's jar.
- **kapt instead of KSP** for Room/Hilt — a build-time tradeoff (kapt is slower), not an APK
  size one; it was chosen for tighter version compatibility guarantees rather than sizing.

## Permissions you'll need to grant manually after installing

- **Usage Access** (Settings → Apps → Special access → Usage access): required for
  foreground/background classification and all historical stats. NetGuardian cannot request
  this via a normal permission dialog — the Dashboard shows a card with a button that opens
  the right settings screen for you.
- **Notifications**: requested automatically on first launch (Android 13+); needed for the
  persistent "monitoring active" status notification.
- Consider exempting the app from battery optimization if you want uninterrupted background
  tracking across long idle periods (OEM battery managers vary; not automated here since it's
  a system-level, per-OEM setting).

## Design notes / scope decisions worth knowing about

- **Per-app "active now" detection** uses `TrafficStats` per-UID polling (delta between ticks)
  combined with `UsageStatsManager` for foreground/background classification — the same
  approach most non-root data-usage-monitor apps use. A VPN-based packet interceptor (what
  GlassWire/NetGuard use for more exact per-connection attribution) would be materially more
  accurate but is a much larger, riskier piece of engineering; this was a deliberate scope
  tradeoff, not an oversight.
- Live per-tick readings are batched in memory and flushed to Room every ~30s (not once per
  tick) to keep disk I/O — and battery draw — low even at a 1-second refresh interval.
- History is stored for 90 days by default and purged automatically; adjust
  `NetworkMonitorService.RETENTION_MS` if you want longer.

## What to do if the CI build fails

I was not able to compile this project in my own sandbox (no Android SDK / no network access
there), so despite a careful manual review there's a real chance the very first CI run
surfaces a small issue — usually a version-compatibility edge case between AGP/Kotlin/Compose
that only shows up mid-build. If that happens, paste the Gradle error output back and it can
be fixed directly against the real compiler output rather than guesswork.
