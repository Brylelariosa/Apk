# Add project specific ProGuard rules here.
# Room, Hilt and Compose ship their own consumer ProGuard rules, so no extra
# keep rules are required for them under normal circumstances.

# Keep line numbers for stack traces in release crash reports.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
