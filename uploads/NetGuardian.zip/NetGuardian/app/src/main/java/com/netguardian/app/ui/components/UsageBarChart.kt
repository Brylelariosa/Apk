package com.netguardian.app.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.netguardian.app.data.model.UsageBucket
import com.netguardian.app.ui.theme.DownloadAccent
import com.netguardian.app.ui.theme.UploadAccent

@Composable
fun UsageBarChart(buckets: List<UsageBucket>, modifier: Modifier = Modifier, maxBarHeight: androidx.compose.ui.unit.Dp = 140.dp) {
    val maxValue = (buckets.maxOfOrNull { maxOf(it.rxBytes, it.txBytes) } ?: 1L).coerceAtLeast(1L)

    Row(
        modifier = modifier.horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.Bottom
    ) {
        buckets.forEach { bucket ->
            UsageBar(bucket = bucket, maxValue = maxValue, maxBarHeight = maxBarHeight)
            Spacer(modifier = Modifier.width(10.dp))
        }
    }
}

@Composable
private fun UsageBar(bucket: UsageBucket, maxValue: Long, maxBarHeight: androidx.compose.ui.unit.Dp) {
    val rxFraction = bucket.rxBytes.toFloat() / maxValue
    val txFraction = bucket.txBytes.toFloat() / maxValue

    val rxHeight by animateDpAsState(
        targetValue = maxBarHeight * rxFraction.coerceIn(0f, 1f),
        animationSpec = tween(500),
        label = "rxHeight"
    )
    val txHeight by animateDpAsState(
        targetValue = maxBarHeight * txFraction.coerceIn(0f, 1f),
        animationSpec = tween(500),
        label = "txHeight"
    )

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.Bottom,
            modifier = Modifier.height(maxBarHeight)
        ) {
            Box(
                modifier = Modifier
                    .width(8.dp)
                    .height(rxHeight.coerceAtLeast(3.dp))
                    .background(DownloadAccent, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
            )
            Box(
                modifier = Modifier
                    .width(8.dp)
                    .height(txHeight.coerceAtLeast(3.dp))
                    .background(UploadAccent, RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = bucket.label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 2.dp)
        )
    }
}
