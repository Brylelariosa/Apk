package com.netguardian.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

/** Coarse transport bucket persisted alongside every snapshot, used for Wi-Fi vs Mobile rollups. */
enum class PersistedTransport { WIFI, MOBILE, OTHER }

/**
 * A single accumulated delta of traffic for one app over one flush period.
 *
 * The monitoring service batches many fast [TrafficStats] reads in memory and writes one row
 * per app every flush interval (see NetworkMonitorService.FLUSH_INTERVAL_MS), which keeps disk
 * I/O - and therefore battery usage - low while still giving fine-grained historical queries.
 */
@Entity(
    tableName = "network_usage_snapshot",
    indices = [
        Index(value = ["packageName", "timestamp"]),
        Index(value = ["timestamp"])
    ]
)
data class NetworkUsageSnapshot(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val packageName: String,
    val uid: Int,
    val rxBytesDelta: Long,
    val txBytesDelta: Long,
    val transport: PersistedTransport,
    val isForeground: Boolean
)
