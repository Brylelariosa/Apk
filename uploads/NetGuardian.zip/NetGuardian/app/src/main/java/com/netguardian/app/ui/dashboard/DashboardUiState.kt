package com.netguardian.app.ui.dashboard

import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.model.DeviceNetworkStatus
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.model.NetworkType
import com.netguardian.app.data.model.TotalUsage

data class DashboardUiState(
    val deviceStatus: DeviceNetworkStatus = DeviceNetworkStatus(
        isConnected = false,
        networkType = NetworkType.NONE,
        downloadBps = 0,
        uploadBps = 0,
        ipAddress = null,
        signalStrengthPercent = null
    ),
    val liveAppUsages: List<LiveAppUsage> = emptyList(),
    val todayTotal: TotalUsage = TotalUsage.ZERO,
    val currentHourTotal: TotalUsage = TotalUsage.ZERO,
    val sessionTotal: TotalUsage = TotalUsage.ZERO,
    val dataUnit: DataUnit = DataUnit.MBPS_BYTES,
    val liveGraphEnabled: Boolean = true,
    val isMonitoringActive: Boolean = false,
    val hasUsageAccess: Boolean = true,
    val downloadHistory: List<Float> = emptyList(),
    val uploadHistory: List<Float> = emptyList(),
    val isLoading: Boolean = true
)
