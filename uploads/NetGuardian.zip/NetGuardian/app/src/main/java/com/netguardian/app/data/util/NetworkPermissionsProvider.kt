package com.netguardian.app.data.util

import android.content.Context
import android.content.pm.PackageManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NetworkPermissionsProvider @Inject constructor(@ApplicationContext private val context: Context) {

    /** Human-readable, networking-relevant permissions the given app declares in its manifest. */
    fun networkingPermissionsFor(packageName: String): List<String> {
        val packageManager = context.packageManager
        val requested = try {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS)
                .requestedPermissions
                ?.toList()
                ?: emptyList()
        } catch (e: PackageManager.NameNotFoundException) {
            emptyList()
        }

        return requested
            .filter { permission -> RELEVANT_KEYWORDS.any { permission.contains(it, ignoreCase = true) } }
            .map { it.substringAfterLast('.') }
            .distinct()
            .sorted()
    }

    private companion object {
        val RELEVANT_KEYWORDS = listOf("INTERNET", "NETWORK", "WIFI", "BLUETOOTH", "NFC", "USAGE_STATS")
    }
}
