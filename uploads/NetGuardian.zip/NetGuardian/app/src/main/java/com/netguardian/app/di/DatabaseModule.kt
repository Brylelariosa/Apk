package com.netguardian.app.di

import android.content.Context
import androidx.room.Room
import com.netguardian.app.data.local.NetGuardianDatabase
import com.netguardian.app.data.local.dao.BlockScheduleDao
import com.netguardian.app.data.local.dao.NetworkUsageDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): NetGuardianDatabase =
        Room.databaseBuilder(context, NetGuardianDatabase::class.java, NetGuardianDatabase.DATABASE_NAME)
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    @Singleton
    fun provideNetworkUsageDao(database: NetGuardianDatabase): NetworkUsageDao =
        database.networkUsageDao()

    @Provides
    @Singleton
    fun provideBlockScheduleDao(database: NetGuardianDatabase): BlockScheduleDao =
        database.blockScheduleDao()
}
