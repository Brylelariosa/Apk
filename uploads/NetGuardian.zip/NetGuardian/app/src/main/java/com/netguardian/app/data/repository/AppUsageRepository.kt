package com.netguardian.app.data.repository

import com.netguardian.app.data.local.dao.AppUsageAggregateRow
import com.netguardian.app.data.local.dao.NetworkUsageDao
import com.netguardian.app.data.local.dao.UsageBucketRow
import com.netguardian.app.data.model.AppUsageAggregate
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.model.TotalUsage
import com.netguardian.app.data.model.TransportFilter
import com.netguardian.app.data.model.UsageBucket
import com.netguardian.app.data.util.TimeWindows
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.delay
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.TemporalAdjusters
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

interface AppUsageRepository {
    val liveAppUsages: StateFlow<List<LiveAppUsage>>
    fun observeTodayTotal(): Flow<TotalUsage>
    fun observeCurrentHourTotal(): Flow<TotalUsage>
    fun observeSessionTotal(sessionStartMillis: Long): Flow<TotalUsage>
    fun observeTodayAppAggregates(): Flow<List<AppUsageAggregate>>
    fun observeMonthAppAggregates(): Flow<List<AppUsageAggregate>>
    fun observeAllTimeAppAggregates(): Flow<List<AppUsageAggregate>>
    fun observeAppAggregate(packageName: String): Flow<AppUsageAggregate?>
    fun observeTodayAppAggregate(packageName: String): Flow<AppUsageAggregate?>
    fun observeHistoryBuckets(range: HistoryRange, transportFilter: TransportFilter = TransportFilter.ALL): Flow<List<UsageBucket>>
    fun observeAppHistoryBuckets(packageName: String, range: HistoryRange): Flow<List<UsageBucket>>
    suspend fun getTopDownloaders(range: HistoryRange, limit: Int, transportFilter: TransportFilter = TransportFilter.ALL): List<AppUsageAggregate>
    suspend fun getTopUploaders(range: HistoryRange, limit: Int, transportFilter: TransportFilter = TransportFilter.ALL): List<AppUsageAggregate>
    suspend fun getAllAggregatesOnce(): List<AppUsageAggregate>
    suspend fun purgeOlderThan(cutoffMillis: Long)
}

@Singleton
class AppUsageRepositoryImpl @Inject constructor(
    private val dao: NetworkUsageDao,
    private val liveMonitorState: LiveMonitorState
) : AppUsageRepository {

    override val liveAppUsages: StateFlow<List<LiveAppUsage>> = liveMonitorState.liveAppUsages

    override fun observeTodayTotal(): Flow<TotalUsage> =
        recomputingWindow(REFRESH_WINDOW_MS) { TimeWindows.startOfTodayMillis(it) }
            .flatMapLatest { start -> dao.observeTotalUsage(start, Long.MAX_VALUE) }
            .map { TotalUsage(it.rxBytes, it.txBytes) }

    override fun observeCurrentHourTotal(): Flow<TotalUsage> =
        recomputingWindow(REFRESH_WINDOW_MS) { TimeWindows.startOfCurrentHourMillis(it) }
            .flatMapLatest { start -> dao.observeTotalUsage(start, Long.MAX_VALUE) }
            .map { TotalUsage(it.rxBytes, it.txBytes) }

    override fun observeSessionTotal(sessionStartMillis: Long): Flow<TotalUsage> =
        dao.observeTotalUsage(sessionStartMillis, Long.MAX_VALUE)
            .map { TotalUsage(it.rxBytes, it.txBytes) }

    override fun observeTodayAppAggregates(): Flow<List<AppUsageAggregate>> =
        recomputingWindow(REFRESH_WINDOW_MS) { TimeWindows.startOfTodayMillis(it) }
            .flatMapLatest { start -> dao.observeAppAggregates(start, Long.MAX_VALUE) }
            .map { rows -> rows.map(AppUsageAggregateRow::toDomain) }

    override fun observeMonthAppAggregates(): Flow<List<AppUsageAggregate>> =
        recomputingWindow(REFRESH_WINDOW_MS) { TimeWindows.startOfMonthMillis(it) }
            .flatMapLatest { start -> dao.observeAppAggregates(start, Long.MAX_VALUE) }
            .map { rows -> rows.map(AppUsageAggregateRow::toDomain) }

    override fun observeAllTimeAppAggregates(): Flow<List<AppUsageAggregate>> =
        dao.observeAppAggregates(0L, Long.MAX_VALUE).map { rows -> rows.map(AppUsageAggregateRow::toDomain) }

    override fun observeAppAggregate(packageName: String): Flow<AppUsageAggregate?> =
        dao.observeSingleAppAggregate(packageName, 0L, Long.MAX_VALUE).map { it?.toDomain() }

    override fun observeTodayAppAggregate(packageName: String): Flow<AppUsageAggregate?> =
        recomputingWindow(REFRESH_WINDOW_MS) { TimeWindows.startOfTodayMillis(it) }
            .flatMapLatest { start -> dao.observeSingleAppAggregate(packageName, start, Long.MAX_VALUE) }
            .map { it?.toDomain() }

    override fun observeHistoryBuckets(range: HistoryRange, transportFilter: TransportFilter): Flow<List<UsageBucket>> {
        val daysBack = daysBackFor(range)
        return recomputingWindow(HISTORY_REFRESH_MS) { TimeWindows.startOfLastNDaysMillis(daysBack) }
            .flatMapLatest { start -> dao.observeDailyBuckets(transportFilter.toSqlValue(), start, Long.MAX_VALUE) }
            .map { rows -> regroup(rows, range) }
    }

    override fun observeAppHistoryBuckets(packageName: String, range: HistoryRange): Flow<List<UsageBucket>> {
        val daysBack = daysBackFor(range)
        return recomputingWindow(HISTORY_REFRESH_MS) { TimeWindows.startOfLastNDaysMillis(daysBack) }
            .flatMapLatest { start -> dao.observeAppDailyBuckets(packageName, start, Long.MAX_VALUE) }
            .map { rows -> regroup(rows, range) }
    }

    override suspend fun getTopDownloaders(range: HistoryRange, limit: Int, transportFilter: TransportFilter): List<AppUsageAggregate> {
        val start = windowStartFor(range)
        return dao.getTopDownloaders(transportFilter.toSqlValue(), start, Long.MAX_VALUE, limit).map { it.toDomain() }
    }

    override suspend fun getTopUploaders(range: HistoryRange, limit: Int, transportFilter: TransportFilter): List<AppUsageAggregate> {
        val start = windowStartFor(range)
        return dao.getTopUploaders(transportFilter.toSqlValue(), start, Long.MAX_VALUE, limit).map { it.toDomain() }
    }

    override suspend fun purgeOlderThan(cutoffMillis: Long) = dao.deleteOlderThan(cutoffMillis)

    override suspend fun getAllAggregatesOnce(): List<AppUsageAggregate> =
        dao.getTopApps(0L, Long.MAX_VALUE, Int.MAX_VALUE).map { it.toDomain() }

    /**
     * Same day-range as [observeHistoryBuckets] uses for its chart, so "Top Downloaders" for a
     * given tab reflects the same period the chart next to it is showing - these used to be
     * inconsistent (chart showing a 14-day trend while the list below it was "today only"),
     * which read as a bug even though each individually was "working as coded".
     */
    private fun windowStartFor(range: HistoryRange): Long =
        TimeWindows.startOfLastNDaysMillis(daysBackFor(range))

    private fun daysBackFor(range: HistoryRange): Int = when (range) {
        HistoryRange.DAILY -> 14
        HistoryRange.WEEKLY -> 56
        HistoryRange.MONTHLY -> 180
    }

    /**
     * Re-derives a time boundary (e.g. "start of today") on a slow timer so windows such as
     * "today" correctly roll over at midnight without every screen managing its own ticker.
     */
    private fun recomputingWindow(periodMs: Long, compute: (Long) -> Long): Flow<Long> = flow {
        while (true) {
            emit(compute(System.currentTimeMillis()))
            delay(periodMs)
        }
    }.distinctUntilChanged()

    private fun regroup(rows: List<UsageBucketRow>, range: HistoryRange): List<UsageBucket> {
        if (range == HistoryRange.DAILY) {
            return rows.map {
                UsageBucket(
                    label = formatDayLabel(it.bucketLabel),
                    bucketStartMillis = it.bucketStart,
                    rxBytes = it.rxBytes,
                    txBytes = it.txBytes
                )
            }
        }
        val grouped = LinkedHashMap<String, MutableList<UsageBucketRow>>()
        for (row in rows) {
            val date = runCatching { LocalDate.parse(row.bucketLabel) }.getOrNull() ?: continue
            val key = when (range) {
                HistoryRange.WEEKLY -> date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)).toString()
                HistoryRange.MONTHLY -> "${date.year}-${date.monthValue}"
                HistoryRange.DAILY -> row.bucketLabel
            }
            grouped.getOrPut(key) { mutableListOf() }.add(row)
        }
        return grouped.entries.map { (key, bucketRows) ->
            val totalRx = bucketRows.sumOf { it.rxBytes }
            val totalTx = bucketRows.sumOf { it.txBytes }
            val start = bucketRows.minOf { it.bucketStart }
            val label = when (range) {
                HistoryRange.WEEKLY -> {
                    val weekStart = LocalDate.parse(key)
                    weekStart.format(DateTimeFormatter.ofPattern("MMM d", Locale.getDefault()))
                }
                HistoryRange.MONTHLY -> {
                    val (year, month) = key.split("-").map { it.toInt() }
                    val monthName = java.time.Month.of(month).getDisplayName(TextStyle.SHORT, Locale.getDefault())
                    "$monthName $year"
                }
                HistoryRange.DAILY -> key
            }
            UsageBucket(label = label, bucketStartMillis = start, rxBytes = totalRx, txBytes = totalTx)
        }.sortedBy { it.bucketStartMillis }
    }

    private fun formatDayLabel(isoDate: String): String = runCatching {
        LocalDate.parse(isoDate).format(DateTimeFormatter.ofPattern("MMM d", Locale.getDefault()))
    }.getOrDefault(isoDate)

    private companion object {
        const val REFRESH_WINDOW_MS = 60_000L
        const val HISTORY_REFRESH_MS = 5 * 60_000L
    }
}

private fun AppUsageAggregateRow.toDomain() = AppUsageAggregate(
    packageName = packageName,
    wifiRxBytes = wifiRx,
    wifiTxBytes = wifiTx,
    mobileRxBytes = mobileRx,
    mobileTxBytes = mobileTx,
    otherRxBytes = otherRx,
    otherTxBytes = otherTx,
    foregroundBytes = foregroundBytes,
    backgroundBytes = backgroundBytes,
    lastActiveAt = lastActiveAt
)

/** Maps to the value stored in [com.netguardian.app.data.local.entity.PersistedTransport]; null
 *  means "no filter" for the DAO's `(:transport IS NULL OR transport = :transport)` queries. */
private fun TransportFilter.toSqlValue(): String? = when (this) {
    TransportFilter.ALL -> null
    TransportFilter.WIFI_ONLY -> "WIFI"
    TransportFilter.MOBILE_ONLY -> "MOBILE"
    TransportFilter.OTHER_ONLY -> "OTHER"
}
