package com.netguardian.app.ui.history

import com.netguardian.app.data.model.AppInfo
import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.model.TransportFilter
import com.netguardian.app.data.model.UsageBucket

data class TopAppUiModel(val appInfo: AppInfo, val bytes: Long)

data class HistoryUiState(
    val range: HistoryRange = HistoryRange.DAILY,
    val transportFilter: TransportFilter = TransportFilter.ALL,
    val buckets: List<UsageBucket> = emptyList(),
    val topDownloaders: List<TopAppUiModel> = emptyList(),
    val topUploaders: List<TopAppUiModel> = emptyList(),
    val dataUnit: DataUnit = DataUnit.MBPS_BYTES,
    val isLoading: Boolean = true
)
