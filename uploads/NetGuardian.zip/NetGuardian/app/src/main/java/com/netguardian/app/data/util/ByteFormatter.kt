package com.netguardian.app.data.util

import com.netguardian.app.data.model.DataUnit
import kotlin.math.abs

/** Pure formatting logic, kept free of Android framework types so it is trivially unit-testable. */
object ByteFormatter {

    /** Formats a cumulative byte count as e.g. "128 KB", "4.2 MB", "1.1 GB". */
    fun formatBytes(bytes: Long): String {
        val absBytes = abs(bytes).toDouble()
        val units = listOf("B", "KB", "MB", "GB", "TB")
        var value = absBytes
        var unitIndex = 0
        while (value >= 1024.0 && unitIndex < units.lastIndex) {
            value /= 1024.0
            unitIndex++
        }
        val sign = if (bytes < 0) "-" else ""
        val formatted = if (unitIndex == 0) value.toInt().toString() else "%.1f".format(value)
        return "$sign$formatted ${units[unitIndex]}"
    }

    /** Formats an instantaneous throughput according to the user's preferred [DataUnit]. */
    fun formatSpeed(bytesPerSecond: Long, unit: DataUnit): String {
        val bps = bytesPerSecond.coerceAtLeast(0)
        return when (unit) {
            DataUnit.KBPS -> "%.1f KB/s".format(bps / 1024.0)
            DataUnit.MBPS_BYTES -> "%.2f MB/s".format(bps / (1024.0 * 1024.0))
            DataUnit.MBPS_BITS -> "%.2f Mbps".format((bps * 8) / (1000.0 * 1000.0))
        }
    }
}
