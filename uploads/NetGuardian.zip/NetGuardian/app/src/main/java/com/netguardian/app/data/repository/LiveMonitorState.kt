package com.netguardian.app.data.repository

import com.netguardian.app.data.model.DeviceNetworkStatus
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.model.NetworkType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single source of truth for "right now" data, written by [com.netguardian.app.service.NetworkMonitorService]
 * every tick and read by every screen through the repositories below. Keeping this as one
 * process-local, Hilt-scoped singleton avoids the complexity of a bound-service/Messenger IPC
 * layer that would add nothing here, since the service and UI always share the same process.
 */
@Singleton
class LiveMonitorState @Inject constructor() {

    private val _deviceStatus = MutableStateFlow(
        DeviceNetworkStatus(
            isConnected = false,
            networkType = NetworkType.NONE,
            downloadBps = 0,
            uploadBps = 0,
            ipAddress = null,
            signalStrengthPercent = null
        )
    )
    val deviceStatus: StateFlow<DeviceNetworkStatus> = _deviceStatus.asStateFlow()

    private val _liveAppUsages = MutableStateFlow<List<LiveAppUsage>>(emptyList())
    val liveAppUsages: StateFlow<List<LiveAppUsage>> = _liveAppUsages.asStateFlow()

    private val _isServiceRunning = MutableStateFlow(false)
    val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

    private val _sessionStartMillis = MutableStateFlow(System.currentTimeMillis())
    val sessionStartMillis: StateFlow<Long> = _sessionStartMillis.asStateFlow()

    fun markSessionStart() {
        _sessionStartMillis.value = System.currentTimeMillis()
    }

    fun publishDeviceStatus(status: DeviceNetworkStatus) {
        _deviceStatus.value = status
    }

    fun publishLiveAppUsages(usages: List<LiveAppUsage>) {
        _liveAppUsages.value = usages
    }

    fun setServiceRunning(running: Boolean) {
        _isServiceRunning.value = running
        if (!running) {
            _liveAppUsages.value = emptyList()
        }
    }
}
