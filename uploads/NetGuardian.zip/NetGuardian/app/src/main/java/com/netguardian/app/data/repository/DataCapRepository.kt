package com.netguardian.app.data.repository

import com.netguardian.app.data.datastore.DataCapDataStore
import com.netguardian.app.data.datastore.DataCapSettings
import kotlinx.coroutines.flow.Flow
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

interface DataCapRepository {
    val settings: Flow<DataCapSettings>
    suspend fun setAppCap(packageName: String, capBytes: Long?)
    suspend fun setGlobalCap(capBytes: Long?)
    suspend fun markAutoBlocked(packageName: String)
    suspend fun clearAutoBlocked(packageNames: Set<String>)
    suspend fun setLastCheckedDate(date: LocalDate)
}

@Singleton
class DataCapRepositoryImpl @Inject constructor(
    private val dataStore: DataCapDataStore
) : DataCapRepository {
    override val settings: Flow<DataCapSettings> = dataStore.settings

    override suspend fun setAppCap(packageName: String, capBytes: Long?) =
        dataStore.setAppCap(packageName, capBytes)

    override suspend fun setGlobalCap(capBytes: Long?) = dataStore.setGlobalCap(capBytes)

    override suspend fun markAutoBlocked(packageName: String) = dataStore.markAutoBlocked(packageName)

    override suspend fun clearAutoBlocked(packageNames: Set<String>) = dataStore.clearAutoBlocked(packageNames)

    override suspend fun setLastCheckedDate(date: LocalDate) = dataStore.setLastCheckedDate(date)
}
