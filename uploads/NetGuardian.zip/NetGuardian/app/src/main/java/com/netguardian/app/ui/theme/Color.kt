package com.netguardian.app.ui.theme

import androidx.compose.ui.graphics.Color

// Primary: deep signal-blue, evokes connectivity/telemetry without feeling corporate-cold.
val GuardianBlue10 = Color(0xFF00174B)
val GuardianBlue20 = Color(0xFF002873)
val GuardianBlue30 = Color(0xFF073B93)
val GuardianBlue40 = Color(0xFF1E4FB0)
val GuardianBlue80 = Color(0xFFB3C6FF)
val GuardianBlue90 = Color(0xFFDAE2FF)

// Secondary: signal-strength teal, used for speed/graph accents.
val GuardianTeal20 = Color(0xFF00382E)
val GuardianTeal30 = Color(0xFF005142)
val GuardianTeal40 = Color(0xFF006C58)
val GuardianTeal80 = Color(0xFF63DBC0)
val GuardianTeal90 = Color(0xFF7FF8DB)

// Tertiary: warm amber for upload/attention accents, distinguishing up from down at a glance.
val GuardianAmber30 = Color(0xFF7A4E00)
val GuardianAmber40 = Color(0xFF9B6600)
val GuardianAmber80 = Color(0xFFFFC97A)
val GuardianAmber90 = Color(0xFFFFDDB0)

val GuardianError40 = Color(0xFFBA1A1A)
val GuardianError80 = Color(0xFFFFB4AB)

val GuardianNeutral10 = Color(0xFF1A1B1F)
val GuardianNeutral95 = Color(0xFFF3F3F9)
val GuardianNeutral99 = Color(0xFFFDFCFF)
val GuardianNeutralVariant30 = Color(0xFF44464C)
val GuardianNeutralVariant50 = Color(0xFF74777F)
val GuardianNeutralVariant80 = Color(0xFFC4C6D0)

// Fixed semantic colors used directly in charts/cards regardless of theme, so download/upload
// stay visually consistent between light and dark mode.
val DownloadAccent = Color(0xFF2E7DFF)
val UploadAccent = Color(0xFFFFA726)
val ActiveGreen = Color(0xFF2ECC71)
val IdleGray = Color(0xFF8A8F98)
