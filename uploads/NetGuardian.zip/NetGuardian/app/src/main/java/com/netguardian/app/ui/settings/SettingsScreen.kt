package com.netguardian.app.ui.settings

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.model.FirewallMode
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.data.model.ThemeMode
import com.netguardian.app.ui.components.SectionHeader
import com.netguardian.app.ui.theme.CardCornerRadius
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onManageSchedules: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val firewallSettings by viewModel.firewallSettings.collectAsStateWithLifecycle()
    val dataCapSettings by viewModel.dataCapSettings.collectAsStateWithLifecycle()
    val firewallError by viewModel.firewallLastError.collectAsStateWithLifecycle()
    val isVpnActive by viewModel.isVpnActive.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Scaffold(topBar = { TopAppBar(title = { Text("Settings") }) }) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            item {
                SettingsSection(title = "Appearance") {
                    ThemeModeRow(current = settings.themeMode, onSelect = viewModel::setThemeMode)
                }
            }

            item {
                SettingsSection(title = "Firewall") {
                    FirewallStatusRow(isVpnActive = isVpnActive, activeCount = firewallSettings.activePackages.size)
                    Spacer(modifier = Modifier.height(12.dp))
                    FirewallModeRow(current = firewallSettings.mode, onSelect = viewModel::setFirewallMode)

                    if (firewallSettings.mode == FirewallMode.ALLOWLIST) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Only apps you explicitly allow will have internet access - " +
                                "everything else on the device is blocked, including system apps " +
                                "like Google Play Services unless you allow them too. Add apps " +
                                "from the Apps list.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    val activeCount = firewallSettings.activePackages.size
                    Text(
                        text = when {
                            activeCount == 0 && firewallSettings.mode == FirewallMode.BLOCKLIST ->
                                "No apps are currently blocked."
                            activeCount == 0 ->
                                "No apps are allowed yet - the firewall isn't active until you add one."
                            firewallSettings.mode == FirewallMode.BLOCKLIST ->
                                "Blocking internet access for $activeCount app" + if (activeCount == 1) "." else "s."
                            else ->
                                "$activeCount app" + (if (activeCount == 1) " is" else "s are") + " allowed online."
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Manage apps from the Apps list or an app's own detail screen.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (firewallError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = firewallError.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row {
                        TextButton(onClick = onManageSchedules) { Text("Manage schedules") }
                        if (activeCount > 0) {
                            TextButton(onClick = { viewModel.stopFirewall() }) { Text("Turn off firewall") }
                        }
                    }
                }
            }

            item {
                SettingsSection(title = "Data caps") {
                    GlobalCapRow(
                        currentCapBytes = dataCapSettings.globalDailyCapBytes,
                        onSetCap = viewModel::setGlobalDataCap
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Per-app caps (which block that app automatically) are set from " +
                            "the app's own detail screen.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item {
                SettingsSection(title = "Monitoring") {
                    RefreshIntervalRow(current = settings.refreshIntervalSeconds, onSelect = viewModel::setRefreshInterval)
                    Spacer(modifier = Modifier.height(12.dp))
                    SwitchRow(
                        label = "Enable animations",
                        checked = settings.animationsEnabled,
                        onCheckedChange = viewModel::setAnimationsEnabled
                    )
                    SwitchRow(
                        label = "Enable live graph",
                        checked = settings.liveGraphEnabled,
                        onCheckedChange = viewModel::setLiveGraphEnabled
                    )
                    SwitchRow(
                        label = "Start on boot",
                        checked = settings.startOnBoot,
                        onCheckedChange = viewModel::setStartOnBoot
                    )
                }
            }

            item {
                SettingsSection(title = "Data units") {
                    DataUnitRow(current = settings.dataUnit, onSelect = viewModel::setDataUnit)
                }
            }

            item {
                SettingsSection(title = "Statistics") {
                    Text(
                        text = "Export every recorded app's usage totals as a CSV file you can save or share.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    TextButton(onClick = {
                        scope.launch {
                            val uri = viewModel.exportStatistics()
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/csv"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Export NetGuardian statistics"))
                        }
                    }) {
                        Text("Export statistics")
                    }
                }
            }

            item {
                SettingsSection(title = "About") {
                    Text(text = "NetGuardian", style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "Version 1.0.0 \u2022 On-device network monitoring, no data leaves your phone.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column {
        SectionHeader(title = title)
        Spacer(modifier = Modifier.height(10.dp))
        Card(
            shape = RoundedCornerShape(CardCornerRadius),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
        ) {
            Column(modifier = Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
private fun ThemeModeRow(current: ThemeMode, onSelect: (ThemeMode) -> Unit) {
    ThemeMode.values().forEach { mode ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = mode.name.lowercase().replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.bodyMedium)
            RadioButton(selected = mode == current, onClick = { onSelect(mode) })
        }
    }
}

@Composable
private fun FirewallStatusRow(isVpnActive: Boolean, activeCount: Int) {
    val (dotColor, statusText) = when {
        isVpnActive -> com.netguardian.app.ui.theme.ActiveGreen to "Active"
        activeCount > 0 -> MaterialTheme.colorScheme.error to "Not active - this shouldn't happen with apps configured; see any error below"
        else -> MaterialTheme.colorScheme.onSurfaceVariant to "Not active"
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(androidx.compose.foundation.shape.CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "Firewall: $statusText", style = MaterialTheme.typography.titleSmall)
    }
}

@Composable
private fun FirewallModeRow(current: FirewallMode, onSelect: (FirewallMode) -> Unit) {
    FirewallMode.values().forEach { mode ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = mode.label, style = MaterialTheme.typography.bodyMedium)
            RadioButton(selected = mode == current, onClick = { onSelect(mode) })
        }
    }
}

@Composable
private fun GlobalCapRow(currentCapBytes: Long?, onSetCap: (Long?) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(text = "Daily device cap", style = MaterialTheme.typography.bodyMedium)
            Text(
                text = if (currentCapBytes == null) {
                    "Not set - you'll get a notification if you set one and reach it"
                } else {
                    "${ByteFormatter.formatBytes(currentCapBytes)} per day \u2022 notifies, doesn't block"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        TextButton(onClick = { showDialog = true }) {
            Text(if (currentCapBytes == null) "Set" else "Change")
        }
    }

    if (showDialog) {
        var megabytesText by remember {
            mutableStateOf(currentCapBytes?.let { (it / (1024 * 1024)).toString() } ?: "")
        }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Daily device cap") },
            text = {
                Column {
                    Text(
                        text = "You'll get a one-time notification each day this is reached. " +
                            "This never blocks anything automatically - only per-app caps do that.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = megabytesText,
                        onValueChange = { input -> megabytesText = input.filter { it.isDigit() } },
                        label = { Text("Megabytes per day") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val megabytes = megabytesText.toLongOrNull()
                    onSetCap(if (megabytes == null || megabytes <= 0) null else megabytes * 1024 * 1024)
                    showDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                if (currentCapBytes != null) {
                    TextButton(onClick = { onSetCap(null); showDialog = false }) { Text("Remove") }
                } else {
                    TextButton(onClick = { showDialog = false }) { Text("Cancel") }
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RefreshIntervalRow(current: Int, onSelect: (Int) -> Unit) {
    Text(text = "Refresh interval", style = MaterialTheme.typography.bodyMedium)
    Spacer(modifier = Modifier.height(8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(1, 2, 5).forEach { seconds ->
            FilterChip(
                selected = current == seconds,
                onClick = { onSelect(seconds) },
                label = { Text("${seconds}s") }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DataUnitRow(current: DataUnit, onSelect: (DataUnit) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        DataUnit.values().forEach { unit ->
            FilterChip(
                selected = current == unit,
                onClick = { onSelect(unit) },
                label = { Text(unit.label) }
            )
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
