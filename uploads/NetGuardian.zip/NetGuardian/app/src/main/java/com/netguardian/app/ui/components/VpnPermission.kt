package com.netguardian.app.ui.components

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.netguardian.app.service.FirewallVpnService

/**
 * Returns a function that runs [onGranted] immediately if VPN consent was already given in a
 * previous session, or transparently shows the one-time system VPN consent dialog first and
 * only then runs it. Used to gate turning a block ON; turning a block back OFF never needs this.
 */
@Composable
fun rememberVpnPermissionRequester(): (onGranted: () -> Unit) -> Unit {
    val context = LocalContext.current
    var pendingAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            pendingAction?.invoke()
        }
        pendingAction = null
    }

    return { onGranted ->
        val consentIntent = FirewallVpnService.prepareIntent(context)
        if (consentIntent == null) {
            onGranted()
        } else {
            pendingAction = onGranted
            launcher.launch(consentIntent)
        }
    }
}
