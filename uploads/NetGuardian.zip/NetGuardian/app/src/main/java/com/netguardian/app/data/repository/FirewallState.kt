package com.netguardian.app.data.repository

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * "The user wants the firewall on" (persisted in [com.netguardian.app.data.datastore.FirewallDataStore])
 * and "the VPN tunnel is actually up" are different things - permission may not be granted yet,
 * or `establish()` can fail. [FirewallVpnService][com.netguardian.app.service.FirewallVpnService]
 * publishes the real runtime state here so the UI can reflect it accurately.
 */
@Singleton
class FirewallState @Inject constructor() {

    private val _isVpnActive = MutableStateFlow(false)
    val isVpnActive: StateFlow<Boolean> = _isVpnActive.asStateFlow()

    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    fun publishActive(active: Boolean) {
        _isVpnActive.value = active
        if (active) _lastError.value = null
    }

    fun publishError(message: String?) {
        _lastError.value = message
    }
}
