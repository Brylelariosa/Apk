package com.netguardian.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.SettingsRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject lateinit var settingsRepository: SettingsRepository
    @Inject lateinit var firewallRepository: FirewallRepository

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val appContext = context.applicationContext
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                if (settingsRepository.settings.first().startOnBoot) {
                    NetworkMonitorService.start(appContext)
                }
                resumeFirewallIfConfigured(appContext)
            } finally {
                pendingResult.finish()
            }
        }
    }

    /**
     * Without this, any apps blocked before a reboot would silently regain full internet
     * access after the device restarts - the VPN doesn't come back on its own, and a blocked
     * app quietly working again is a much worse silent failure than monitoring just missing
     * data. VPN consent persists across reboots once granted, so this can resume without any
     * UI as long as the user had already accepted the system VPN dialog previously.
     */
    private suspend fun resumeFirewallIfConfigured(context: Context) {
        // .activePackages, not .blockedPackages directly - this only checked the block list, so
        // resuming after a reboot silently never worked in Allowlist mode, where it's
        // .allowedPackages that actually matters.
        val hasConfiguredApps = firewallRepository.settings.first().activePackages.isNotEmpty()
        val alreadyConsented = FirewallVpnService.prepareIntent(context) == null
        if (hasConfiguredApps && alreadyConsented) {
            FirewallVpnService.start(context)?.let { firewallRepository.reportError(it) }
        }
    }
}
