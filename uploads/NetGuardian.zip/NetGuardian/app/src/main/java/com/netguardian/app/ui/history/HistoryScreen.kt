package com.netguardian.app.ui.history

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.ui.components.EmptyState
import com.netguardian.app.ui.components.SectionHeader
import com.netguardian.app.ui.components.UsageBarChart

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(viewModel: HistoryViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(topBar = { TopAppBar(title = { Text("History") }) }) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                RangeTabs(selected = uiState.range, onSelected = viewModel::onRangeChanged)
                Spacer(modifier = Modifier.height(16.dp))
            }

            item {
                if (uiState.buckets.isEmpty()) {
                    EmptyState(message = "No usage recorded yet for this period.")
                } else {
                    UsageBarChart(
                        buckets = uiState.buckets,
                        modifier = Modifier.fillMaxWidth().height(200.dp)
                    )
                }
                Spacer(modifier = Modifier.height(24.dp))
            }

            item {
                SectionHeader(title = "Top Downloaders")
                Spacer(modifier = Modifier.height(8.dp))
            }
            if (uiState.topDownloaders.isEmpty()) {
                item { EmptyState(message = "Nothing downloaded in this period yet.") }
            } else {
                items(uiState.topDownloaders, key = { "down_" + it.appInfo.packageName }) { top ->
                    TopAppRow(top)
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
                SectionHeader(title = "Top Uploaders")
                Spacer(modifier = Modifier.height(8.dp))
            }
            if (uiState.topUploaders.isEmpty()) {
                item { EmptyState(message = "Nothing uploaded in this period yet.") }
            } else {
                items(uiState.topUploaders, key = { "up_" + it.appInfo.packageName }) { top ->
                    TopAppRow(top)
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun RangeTabs(selected: HistoryRange, onSelected: (HistoryRange) -> Unit) {
    val ranges = HistoryRange.values()
    TabRow(selectedTabIndex = ranges.indexOf(selected)) {
        ranges.forEach { range ->
            Tab(
                selected = range == selected,
                onClick = { onSelected(range) },
                text = { Text(range.label) }
            )
        }
    }
}

@Composable
private fun TopAppRow(top: TopAppUiModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val drawable = top.appInfo.icon
            if (drawable != null) {
                val bitmap = remember(top.appInfo.packageName) { drawable.toBitmap(80, 80).asImageBitmap() }
                Image(
                    painter = BitmapPainter(bitmap),
                    contentDescription = top.appInfo.label,
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                )
                Spacer(modifier = Modifier.padding(start = 4.dp))
            }
            Text(text = top.appInfo.label, style = MaterialTheme.typography.bodyMedium)
        }
        Text(text = ByteFormatter.formatBytes(top.bytes), style = MaterialTheme.typography.bodyMedium)
    }
}
