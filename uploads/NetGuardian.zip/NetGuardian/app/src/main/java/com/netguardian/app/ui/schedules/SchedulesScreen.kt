package com.netguardian.app.ui.schedules

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.netguardian.app.data.model.BlockSchedule
import com.netguardian.app.ui.components.EmptyState
import com.netguardian.app.ui.theme.CardCornerRadius
import java.time.DayOfWeek

private val DAY_ORDER = listOf(
    DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY,
    DayOfWeek.FRIDAY, DayOfWeek.SATURDAY, DayOfWeek.SUNDAY
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SchedulesScreen(
    onBack: () -> Unit,
    viewModel: SchedulesViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var editingSchedule by remember { mutableStateOf<BlockSchedule?>(null) }
    var showEditor by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Schedules") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                editingSchedule = null
                showEditor = true
            }) {
                Icon(Icons.Filled.Add, contentDescription = "Add schedule")
            }
        }
    ) { innerPadding ->
        if (uiState.schedules.isEmpty()) {
            Column(modifier = Modifier.padding(innerPadding)) {
                EmptyState(
                    message = "No schedules yet. Add one to automatically block apps during " +
                        "specific hours, like work or bedtime."
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                items(uiState.schedules, key = { it.schedule.id }) { row ->
                    ScheduleCard(
                        row = row,
                        onToggleEnabled = { enabled -> viewModel.setEnabled(row.schedule, enabled) },
                        onEdit = {
                            editingSchedule = row.schedule
                            showEditor = true
                        },
                        onDelete = { viewModel.delete(row.schedule.id) },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }
        }
    }

    if (showEditor) {
        ScheduleEditorDialog(
            existing = editingSchedule,
            allApps = uiState.allApps,
            onDismiss = { showEditor = false },
            onSave = { schedule ->
                viewModel.save(schedule)
                showEditor = false
            }
        )
    }
}

@Composable
private fun ScheduleCard(
    row: ScheduleRowUiModel,
    onToggleEnabled: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val schedule = row.schedule
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = schedule.label, style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = formatDays(schedule.daysOfWeek) + " \u2022 " +
                            formatTime(schedule.startMinuteOfDay) + " - " + formatTime(schedule.endMinuteOfDay),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = schedule.enabled, onCheckedChange = onToggleEnabled)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = if (row.appLabels.isEmpty()) "No apps selected" else row.appLabels.joinToString(", "),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2
            )
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                TextButton(onClick = onEdit) { Text("Edit") }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete schedule")
                }
            }
        }
    }
}

@Composable
private fun ScheduleEditorDialog(
    existing: BlockSchedule?,
    allApps: List<SelectableApp>,
    onDismiss: () -> Unit,
    onSave: (BlockSchedule) -> Unit
) {
    var label by remember { mutableStateOf(existing?.label ?: "") }
    var selectedApps by remember { mutableStateOf(existing?.packageNames ?: emptySet()) }
    var selectedDays by remember { mutableStateOf(existing?.daysOfWeek ?: setOf(1, 2, 3, 4, 5)) }
    var startText by remember { mutableStateOf(existing?.let { formatTime(it.startMinuteOfDay) } ?: "09:00") }
    var endText by remember { mutableStateOf(existing?.let { formatTime(it.endMinuteOfDay) } ?: "17:00") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usesPlatformDefaultWidth = false)) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(CardCornerRadius)
        ) {
            LazyColumn(modifier = Modifier.padding(20.dp)) {
                item {
                    Text(
                        text = if (existing == null) "New schedule" else "Edit schedule",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it },
                        label = { Text("Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "Days", style = MaterialTheme.typography.labelLarge)
                    Spacer(modifier = Modifier.height(8.dp))
                    DayChipsRow(selectedDays = selectedDays, onToggle = { day ->
                        selectedDays = if (selectedDays.contains(day)) selectedDays - day else selectedDays + day
                    })
                    Spacer(modifier = Modifier.height(16.dp))
                    Row {
                        OutlinedTextField(
                            value = startText,
                            onValueChange = { startText = it },
                            label = { Text("Start (HH:MM)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        OutlinedTextField(
                            value = endText,
                            onValueChange = { endText = it },
                            label = { Text("End (HH:MM)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(text = "Apps to block", style = MaterialTheme.typography.labelLarge)
                }
                items(allApps, key = { it.packageName }) { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = selectedApps.contains(app.packageName),
                            onCheckedChange = { checked ->
                                selectedApps = if (checked) selectedApps + app.packageName else selectedApps - app.packageName
                            }
                        )
                        Text(text = app.label, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                item {
                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = errorMessage.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(onClick = {
                            val start = parseMinuteOfDay(startText)
                            val end = parseMinuteOfDay(endText)
                            errorMessage = when {
                                label.isBlank() -> "Give this schedule a name."
                                selectedApps.isEmpty() -> "Select at least one app."
                                selectedDays.isEmpty() -> "Select at least one day."
                                start == null || end == null -> "Use HH:MM, e.g. 09:00."
                                end <= start -> "End time must be after start time."
                                else -> null
                            }
                            if (errorMessage == null && start != null && end != null) {
                                onSave(
                                    BlockSchedule(
                                        id = existing?.id ?: java.util.UUID.randomUUID().toString(),
                                        label = label,
                                        packageNames = selectedApps,
                                        daysOfWeek = selectedDays,
                                        startMinuteOfDay = start,
                                        endMinuteOfDay = end,
                                        enabled = existing?.enabled ?: true
                                    )
                                )
                            }
                        }) { Text("Save") }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DayChipsRow(selectedDays: Set<Int>, onToggle: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        DAY_ORDER.forEach { day ->
            FilterChip(
                selected = selectedDays.contains(day.value),
                onClick = { onToggle(day.value) },
                label = { Text(day.name.take(1)) }
            )
        }
    }
}

private fun formatDays(days: Set<Int>): String {
    if (days.size == 7) return "Every day"
    if (days == setOf(1, 2, 3, 4, 5)) return "Weekdays"
    if (days == setOf(6, 7)) return "Weekends"
    return DAY_ORDER.filter { days.contains(it.value) }.joinToString(", ") { it.name.take(3) }
}

private fun formatTime(minuteOfDay: Int): String {
    val hour = minuteOfDay / 60
    val minute = minuteOfDay % 60
    return "%02d:%02d".format(hour, minute)
}

private fun parseMinuteOfDay(text: String): Int? {
    val parts = text.trim().split(":")
    if (parts.size != 2) return null
    val hour = parts[0].toIntOrNull() ?: return null
    val minute = parts[1].toIntOrNull() ?: return null
    if (hour !in 0..23 || minute !in 0..59) return null
    return hour * 60 + minute
}
