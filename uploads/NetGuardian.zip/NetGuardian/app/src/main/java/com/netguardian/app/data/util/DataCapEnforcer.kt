package com.netguardian.app.data.util

import android.content.Context
import androidx.core.app.NotificationCompat
import com.netguardian.app.NetGuardianApplication
import com.netguardian.app.R
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.DataCapRepository
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.service.FirewallVpnService
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.first
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Ties usage tracking and the firewall together: an app whose cap is exceeded today gets
 * blocked automatically, and that auto-block is released the next day when the cap resets.
 * A global cap only *notifies* rather than blocking everything - auto-blocking the entire
 * device's internet on a soft usage threshold is a much more disruptive failure mode than a
 * single app being blocked, so that stays a manual decision.
 */
@Singleton
class DataCapEnforcer @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dataCapRepository: DataCapRepository,
    private val appUsageRepository: AppUsageRepository,
    private val firewallRepository: FirewallRepository
) {

    @Volatile private var globalCapNotifiedToday: Boolean = false

    suspend fun checkAndEnforce() {
        val caps = dataCapRepository.settings.first()
        releaseAutoBlocksIfNewDay(caps.lastCheckedDate, caps.autoBlockedPackages)

        if (caps.perAppCapsBytes.isNotEmpty()) {
            enforcePerAppCaps(caps.perAppCapsBytes)
        }
        caps.globalDailyCapBytes?.let { checkGlobalCap(it) }
    }

    private suspend fun releaseAutoBlocksIfNewDay(lastCheckedDate: LocalDate?, autoBlocked: Set<String>) {
        val today = LocalDate.now()
        if (lastCheckedDate == today) return
        if (autoBlocked.isNotEmpty()) {
            autoBlocked.forEach { packageName -> firewallRepository.setBlocked(packageName, false) }
            dataCapRepository.clearAutoBlocked(autoBlocked)
        }
        dataCapRepository.setLastCheckedDate(today)
        globalCapNotifiedToday = false
    }

    private suspend fun enforcePerAppCaps(caps: Map<String, Long>) {
        val alreadyBlocked = firewallRepository.currentSettings().blockedPackages
        val todayByPackage = appUsageRepository.observeTodayAppAggregates().first().associateBy { it.packageName }

        var blockedSomethingNew = false
        for ((packageName, capBytes) in caps) {
            if (packageName in alreadyBlocked) continue
            val usedBytes = todayByPackage[packageName]?.totalBytes ?: 0L
            if (usedBytes >= capBytes) {
                firewallRepository.setBlocked(packageName, true)
                dataCapRepository.markAutoBlocked(packageName)
                blockedSomethingNew = true
            }
        }
        if (blockedSomethingNew) {
            FirewallVpnService.start(context)?.let { firewallRepository.reportError(it) }
        }
    }

    private suspend fun checkGlobalCap(capBytes: Long) {
        val total = appUsageRepository.observeTodayTotal().first()
        if (total.totalBytes < capBytes) return
        if (globalCapNotifiedToday) return
        globalCapNotifiedToday = true
        showGlobalCapNotification()
    }

    private fun showGlobalCapNotification() {
        val manager = androidx.core.content.ContextCompat.getSystemService(
            context,
            android.app.NotificationManager::class.java
        )
        val notification = NotificationCompat.Builder(context, NetGuardianApplication.MONITOR_CHANNEL_ID)
            .setContentTitle("Daily data cap reached")
            .setContentText("Your device has reached the data limit you set for today.")
            .setSmallIcon(R.drawable.ic_notification)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        manager?.notify(GLOBAL_CAP_NOTIFICATION_ID, notification)
    }

    private companion object {
        const val GLOBAL_CAP_NOTIFICATION_ID = 44
    }
}
