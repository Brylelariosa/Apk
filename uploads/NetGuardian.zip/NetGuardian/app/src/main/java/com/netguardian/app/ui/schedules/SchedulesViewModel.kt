package com.netguardian.app.ui.schedules

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.model.BlockSchedule
import com.netguardian.app.data.repository.ScheduleRepository
import com.netguardian.app.data.util.InstalledAppsProvider
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class SchedulesViewModel @Inject constructor(
    private val scheduleRepository: ScheduleRepository,
    private val installedAppsProvider: InstalledAppsProvider
) : ViewModel() {

    private val allApps = MutableStateFlow<List<SelectableApp>>(emptyList())

    val uiState: StateFlow<SchedulesUiState> = combine(
        scheduleRepository.schedules,
        allApps
    ) { schedules, apps ->
        val labelByPackage = apps.associateBy({ it.packageName }, { it.label })
        SchedulesUiState(
            schedules = schedules.map { schedule ->
                ScheduleRowUiModel(
                    schedule = schedule,
                    appLabels = schedule.packageNames.mapNotNull { labelByPackage[it] }
                )
            },
            allApps = apps,
            isLoading = apps.isEmpty()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SchedulesUiState())

    init {
        viewModelScope.launch {
            val apps = withContext(Dispatchers.IO) { installedAppsProvider.listAllApps() }
            allApps.value = apps.map { SelectableApp(it.packageName, it.label) }.sortedBy { it.label.lowercase() }
        }
    }

    fun newId(): String = scheduleRepository.newId()

    fun save(schedule: BlockSchedule) {
        viewModelScope.launch { scheduleRepository.save(schedule) }
    }

    fun delete(id: String) {
        viewModelScope.launch { scheduleRepository.delete(id) }
    }

    fun setEnabled(schedule: BlockSchedule, enabled: Boolean) {
        save(schedule.copy(enabled = enabled))
    }
}
