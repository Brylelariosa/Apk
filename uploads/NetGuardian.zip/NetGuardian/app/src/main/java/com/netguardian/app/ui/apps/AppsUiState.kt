package com.netguardian.app.ui.apps

import com.netguardian.app.data.model.AppInfo
import com.netguardian.app.data.model.AppSortOrder
import com.netguardian.app.data.model.AppUsageAggregate
import com.netguardian.app.data.model.DataUnit

data class AppRowUiModel(
    val appInfo: AppInfo,
    val todayBytes: Long,
    val monthBytes: Long,
    val totalWifiBytes: Long,
    val totalMobileBytes: Long,
    val backgroundBytes: Long,
    val lastActiveAt: Long,
    val isBlocked: Boolean
) {
    val totalBytes: Long get() = totalWifiBytes + totalMobileBytes
}

data class AppsUiState(
    val rows: List<AppRowUiModel> = emptyList(),
    val searchQuery: String = "",
    val sortOrder: AppSortOrder = AppSortOrder.ALPHABETICAL,
    val dataUnit: DataUnit = DataUnit.MBPS_BYTES,
    val isRefreshing: Boolean = false,
    val isLoading: Boolean = true
)

internal fun buildRows(
    allApps: List<AppInfo>,
    monthAggregates: Map<String, AppUsageAggregate>,
    todayAggregates: Map<String, AppUsageAggregate>,
    allTimeAggregates: Map<String, AppUsageAggregate>,
    blockedPackages: Set<String>
): List<AppRowUiModel> = allApps.map { app ->
    val allTime = allTimeAggregates[app.packageName]
    val today = todayAggregates[app.packageName]
    val month = monthAggregates[app.packageName]
    AppRowUiModel(
        appInfo = app,
        todayBytes = today?.totalBytes ?: 0L,
        monthBytes = month?.totalBytes ?: 0L,
        totalWifiBytes = (allTime?.wifiRxBytes ?: 0L) + (allTime?.wifiTxBytes ?: 0L),
        totalMobileBytes = (allTime?.mobileRxBytes ?: 0L) + (allTime?.mobileTxBytes ?: 0L),
        backgroundBytes = allTime?.backgroundBytes ?: 0L,
        lastActiveAt = allTime?.lastActiveAt ?: 0L,
        isBlocked = blockedPackages.contains(app.packageName)
    )
}

internal fun List<AppRowUiModel>.filteredAndSorted(query: String, sortOrder: AppSortOrder): List<AppRowUiModel> {
    val filtered = if (query.isBlank()) this else filter {
        it.appInfo.label.contains(query, ignoreCase = true) ||
            it.appInfo.packageName.contains(query, ignoreCase = true)
    }
    return when (sortOrder) {
        AppSortOrder.ALPHABETICAL -> filtered.sortedBy { it.appInfo.label.lowercase() }
        AppSortOrder.HIGHEST_USAGE -> filtered.sortedByDescending { it.totalBytes }
        AppSortOrder.RECENTLY_ACTIVE -> filtered.sortedByDescending { it.lastActiveAt }
        AppSortOrder.BACKGROUND_USAGE -> filtered.sortedByDescending { it.backgroundBytes }
    }
}
