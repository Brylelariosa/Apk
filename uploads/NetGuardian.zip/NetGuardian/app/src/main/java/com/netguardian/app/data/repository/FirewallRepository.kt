package com.netguardian.app.data.repository

import com.netguardian.app.data.datastore.FirewallDataStore
import com.netguardian.app.data.datastore.FirewallSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

interface FirewallRepository {
    val settings: Flow<FirewallSettings>
    val isVpnActive: StateFlow<Boolean>
    val lastError: StateFlow<String?>
    suspend fun setBlocked(packageName: String, blocked: Boolean)
    suspend fun clearAllBlocked()
}

@Singleton
class FirewallRepositoryImpl @Inject constructor(
    private val dataStore: FirewallDataStore,
    private val firewallState: FirewallState
) : FirewallRepository {
    override val settings: Flow<FirewallSettings> = dataStore.settings
    override val isVpnActive: StateFlow<Boolean> = firewallState.isVpnActive
    override val lastError: StateFlow<String?> = firewallState.lastError

    override suspend fun setBlocked(packageName: String, blocked: Boolean) =
        dataStore.setBlocked(packageName, blocked)

    override suspend fun clearAllBlocked() = dataStore.clearAllBlocked()
}
