package com.netguardian.app.data.repository

import com.netguardian.app.data.datastore.FirewallDataStore
import com.netguardian.app.data.datastore.FirewallSettings
import com.netguardian.app.data.model.FirewallMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

interface FirewallRepository {
    val settings: Flow<FirewallSettings>
    val isVpnActive: StateFlow<Boolean>
    val lastError: StateFlow<String?>
    suspend fun currentSettings(): FirewallSettings
    suspend fun setMode(mode: FirewallMode)
    suspend fun setBlocked(packageName: String, blocked: Boolean)
    suspend fun setBlockedMany(packageNames: Set<String>, blocked: Boolean)
    suspend fun setAllowed(packageName: String, allowed: Boolean)
    suspend fun setAllowedMany(packageNames: Set<String>, allowed: Boolean)
    suspend fun disableFirewall()

    /** Lets callers outside the service itself (which don't have direct access to
     *  [FirewallState]) surface a failure through the same error channel Settings already
     *  displays - e.g. when [com.netguardian.app.service.FirewallVpnService.start] fails before
     *  the service even reaches `onCreate()`, so nothing else would ever report it. */
    fun reportError(message: String)

    /** Adds/removes [packageName] from whichever list the *current* mode actually reads from -
     *  the block list in Blocklist mode, the allow list in Allowlist mode - so callers never
     *  need to know which list that is or invert a boolean to get the right effect. */
    suspend fun setActiveListMembership(packageName: String, isMember: Boolean) {
        when (currentSettings().mode) {
            FirewallMode.BLOCKLIST -> setBlocked(packageName, isMember)
            FirewallMode.ALLOWLIST -> setAllowed(packageName, isMember)
        }
    }

    suspend fun setActiveListMembershipMany(packageNames: Set<String>, isMember: Boolean) {
        when (currentSettings().mode) {
            FirewallMode.BLOCKLIST -> setBlockedMany(packageNames, isMember)
            FirewallMode.ALLOWLIST -> setAllowedMany(packageNames, isMember)
        }
    }
}

@Singleton
class FirewallRepositoryImpl @Inject constructor(
    private val dataStore: FirewallDataStore,
    private val firewallState: FirewallState
) : FirewallRepository {
    override val settings: Flow<FirewallSettings> = dataStore.settings
    override val isVpnActive: StateFlow<Boolean> = firewallState.isVpnActive
    override val lastError: StateFlow<String?> = firewallState.lastError

    override suspend fun currentSettings(): FirewallSettings = dataStore.currentSettings()

    override suspend fun setMode(mode: FirewallMode) = dataStore.setMode(mode)

    override suspend fun setBlocked(packageName: String, blocked: Boolean) =
        dataStore.setBlocked(packageName, blocked)

    override suspend fun setBlockedMany(packageNames: Set<String>, blocked: Boolean) =
        dataStore.setBlockedMany(packageNames, blocked)

    override suspend fun setAllowed(packageName: String, allowed: Boolean) =
        dataStore.setAllowed(packageName, allowed)

    override suspend fun setAllowedMany(packageNames: Set<String>, allowed: Boolean) =
        dataStore.setAllowedMany(packageNames, allowed)

    override suspend fun disableFirewall() = dataStore.disableFirewall()

    override fun reportError(message: String) = firewallState.publishError(message)
}
