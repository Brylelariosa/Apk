package com.netguardian.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/**
 * A minimal pull-to-refresh container implemented with a plain drag gesture and an [Animatable]
 * offset. Material3's built-in pull-to-refresh component is still experimental/version-sensitive
 * at the Compose BOM this project pins, so this small, dependency-free version is used instead -
 * it is fully our own reusable component and easy to reason about.
 */
@Composable
fun PullToRefreshBox(
    refreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    maxPullDistance: Dp = 72.dp,
    content: @Composable () -> Unit
) {
    val scope = rememberCoroutineScope()
    val offsetY = remember { Animatable(0f) }
    val density = LocalDensity.current
    val maxPullPx = with(density) { maxPullDistance.toPx() }

    Box(
        modifier = modifier.draggable(
            orientation = Orientation.Vertical,
            state = rememberDraggableState { delta ->
                scope.launch {
                    val proposed = (offsetY.value + delta * 0.5f).coerceIn(0f, maxPullPx)
                    offsetY.snapTo(proposed)
                }
            },
            onDragStopped = {
                if (offsetY.value >= maxPullPx * 0.85f && !refreshing) {
                    offsetY.animateTo(maxPullPx * 0.6f)
                    onRefresh()
                } else {
                    offsetY.animateTo(0f)
                }
            }
        )
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .height(with(density) { offsetY.value.toDp() }),
            contentAlignment = Alignment.BottomCenter
        ) {
            if (offsetY.value > 4f || refreshing) {
                CircularProgressIndicator(
                    modifier = Modifier.padding(bottom = 8.dp),
                    strokeWidth = 2.5.dp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
        Box(
            modifier = Modifier.offset { IntOffset(0, offsetY.value.toInt()) }
        ) {
            content()
        }
    }
}
