package com.netguardian.app.data.util

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.netguardian.app.data.model.AppUsageAggregate
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/** Writes a CSV snapshot of all recorded per-app usage and hands back a shareable content URI. */
@Singleton
class StatisticsExporter @Inject constructor(@ApplicationContext private val context: Context) {

    suspend fun exportToCsv(aggregates: List<AppUsageAggregate>): Uri = withContext(Dispatchers.IO) {
        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        deleteOldExports(exportsDir)

        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(exportsDir, "netguardian_export_$timestamp.csv")

        file.bufferedWriter().use { writer ->
            writer.write(
                "package,wifi_rx_bytes,wifi_tx_bytes,mobile_rx_bytes,mobile_tx_bytes," +
                    "other_rx_bytes,other_tx_bytes,foreground_bytes,background_bytes,last_active_epoch_ms"
            )
            writer.newLine()
            aggregates.forEach { row ->
                writer.write(
                    listOf(
                        row.packageName,
                        row.wifiRxBytes,
                        row.wifiTxBytes,
                        row.mobileRxBytes,
                        row.mobileTxBytes,
                        row.otherRxBytes,
                        row.otherTxBytes,
                        row.foregroundBytes,
                        row.backgroundBytes,
                        row.lastActiveAt
                    ).joinToString(",")
                )
                writer.newLine()
            }
        }

        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    /**
     * Every export used to leave its file behind in the cache dir forever - harmless for one
     * export, but each tap of "Export statistics" quietly added another file with no cleanup.
     * Clearing previous exports before writing a new one keeps that directory from growing
     * without bound over time.
     */
    private fun deleteOldExports(exportsDir: File) {
        exportsDir.listFiles()?.forEach { it.delete() }
    }
}
