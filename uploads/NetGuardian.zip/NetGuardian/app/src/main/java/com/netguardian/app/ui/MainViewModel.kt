package com.netguardian.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.model.ThemeMode
import com.netguardian.app.data.repository.SettingsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    settingsRepository: SettingsRepository
) : ViewModel() {
    val themeMode: StateFlow<ThemeMode> = settingsRepository.settings
        .map { it.themeMode }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    val animationsEnabled: StateFlow<Boolean> = settingsRepository.settings
        .map { it.animationsEnabled }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    /** Null until the very first DataStore read completes, so the caller can avoid flashing
     *  either onboarding or the main app UI before it actually knows which one is correct. */
    val hasCompletedOnboarding: StateFlow<Boolean?> = settingsRepository.settings
        .map { it.hasCompletedOnboarding }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
}
