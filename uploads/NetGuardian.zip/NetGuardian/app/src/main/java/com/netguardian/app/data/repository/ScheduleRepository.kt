package com.netguardian.app.data.repository

import com.netguardian.app.data.local.dao.BlockScheduleDao
import com.netguardian.app.data.local.entity.BlockScheduleEntity
import com.netguardian.app.data.model.BlockSchedule
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

interface ScheduleRepository {
    /** Always current, read synchronously by the firewall service's periodic time check. */
    val schedules: StateFlow<List<BlockSchedule>>
    suspend fun save(schedule: BlockSchedule)
    suspend fun delete(id: String)
    fun newId(): String
}

@Singleton
class ScheduleRepositoryImpl @Inject constructor(
    private val dao: BlockScheduleDao
) : ScheduleRepository {

    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override val schedules: StateFlow<List<BlockSchedule>> = dao.observeAll()
        .map { entities -> entities.map { it.toDomain() } }
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    override suspend fun save(schedule: BlockSchedule) = dao.upsert(schedule.toEntity())

    override suspend fun delete(id: String) = dao.deleteById(id)

    override fun newId(): String = UUID.randomUUID().toString()
}

private fun BlockScheduleEntity.toDomain() = BlockSchedule(
    id = id,
    label = label,
    packageNames = packageNames,
    daysOfWeek = daysOfWeek,
    startMinuteOfDay = startMinuteOfDay,
    endMinuteOfDay = endMinuteOfDay,
    enabled = enabled
)

private fun BlockSchedule.toEntity() = BlockScheduleEntity(
    id = id,
    label = label,
    packageNames = packageNames,
    daysOfWeek = daysOfWeek,
    startMinuteOfDay = startMinuteOfDay,
    endMinuteOfDay = endMinuteOfDay,
    enabled = enabled
)
