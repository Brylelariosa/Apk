package com.netguardian.app.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.netguardian.app.data.local.entity.BlockScheduleEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BlockScheduleDao {

    @Query("SELECT * FROM block_schedule ORDER BY label ASC")
    fun observeAll(): Flow<List<BlockScheduleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(schedule: BlockScheduleEntity)

    @Delete
    suspend fun delete(schedule: BlockScheduleEntity)

    @Query("DELETE FROM block_schedule WHERE id = :id")
    suspend fun deleteById(id: String)
}
