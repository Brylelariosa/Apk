package com.netguardian.app.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.NamedNavArgument
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.netguardian.app.ui.appdetail.AppDetailScreen
import com.netguardian.app.ui.apps.AppsScreen
import com.netguardian.app.ui.dashboard.DashboardScreen
import com.netguardian.app.ui.history.HistoryScreen
import com.netguardian.app.ui.settings.SettingsScreen

private const val TRANSITION_DURATION_MS = 280

@Composable
fun NetGuardianNavHost(navController: NavHostController, modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier) {
    NavHost(
        navController = navController,
        startDestination = Destination.Dashboard.route,
        modifier = modifier,
        enterTransition = { crossFadeSlideIn() },
        exitTransition = { crossFadeSlideOut() },
        popEnterTransition = { crossFadeSlideIn(reverse = true) },
        popExitTransition = { crossFadeSlideOut(reverse = true) }
    ) {
        tab(Destination.Dashboard.route) {
            DashboardScreen(
                onOpenApp = { pkg -> navController.navigateToAppDetail(pkg) },
                onNavigateToTab = { route -> navController.navigateToTab(route) }
            )
        }
        tab(Destination.Apps.route) {
            AppsScreen(onOpenApp = { pkg -> navController.navigateToAppDetail(pkg) })
        }
        tab(Destination.History.route) {
            HistoryScreen()
        }
        tab(Destination.Settings.route) {
            SettingsScreen()
        }
        composable(
            route = Destination.AppDetail.route,
            arguments = appDetailArguments()
        ) { backStackEntry ->
            val packageName = backStackEntry.arguments?.getString(Destination.AppDetail.ARG_PACKAGE_NAME).orEmpty()
            AppDetailScreen(packageName = packageName, onBack = { navController.popBackStack() })
        }
    }
}

private fun androidx.navigation.NavController.navigateToAppDetail(packageName: String) {
    navigate(Destination.AppDetail.createRoute(packageName))
}

private fun androidx.navigation.NavController.navigateToTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private fun appDetailArguments(): List<NamedNavArgument> = listOf(
    navArgument(Destination.AppDetail.ARG_PACKAGE_NAME) { type = NavType.StringType }
)

/** Shared fade+slide used for every top-level tab switch, per the "animated navigation transitions" spec. */
private fun AnimatedContentTransitionScope<*>.crossFadeSlideIn(reverse: Boolean = false) =
    fadeIn(tween(TRANSITION_DURATION_MS)) +
        slideInHorizontally(tween(TRANSITION_DURATION_MS)) { fullWidth ->
            if (reverse) -fullWidth / 6 else fullWidth / 6
        }

private fun AnimatedContentTransitionScope<*>.crossFadeSlideOut(reverse: Boolean = false) =
    fadeOut(tween(TRANSITION_DURATION_MS)) +
        slideOutHorizontally(tween(TRANSITION_DURATION_MS)) { fullWidth ->
            if (reverse) fullWidth / 6 else -fullWidth / 6
        }

private fun NavGraphBuilder.tab(route: String, content: @Composable () -> Unit) {
    composable(route = route) { content() }
}
