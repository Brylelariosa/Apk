package com.netguardian.app.ui.dashboard

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.netguardian.app.R
import com.netguardian.app.data.util.PermissionUtils
import com.netguardian.app.ui.components.AnimatedByteCounter
import com.netguardian.app.ui.components.AppUsageCard
import com.netguardian.app.ui.components.EmptyState
import com.netguardian.app.ui.components.LiveTrafficGraph
import com.netguardian.app.ui.components.NetworkStatusCard
import com.netguardian.app.ui.components.PermissionRequiredCard
import com.netguardian.app.ui.components.SectionHeader
import com.netguardian.app.ui.components.StatChip
import com.netguardian.app.ui.navigation.Destination
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    onOpenApp: (String) -> Unit,
    onNavigateToTab: (String) -> Unit,
    viewModel: DashboardViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = androidx.compose.ui.platform.LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Security,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = stringResource(R.string.app_name), style = MaterialTheme.typography.titleLarge)
                    }
                },
                actions = {
                    IconButton(onClick = { onNavigateToTab(Destination.Settings.route) }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                    IconButton(onClick = {
                        scope.launch {
                            val activeCount = uiState.liveAppUsages.size
                            val message = if (uiState.isMonitoringActive) {
                                if (activeCount == 0) "Monitoring active \u2022 no traffic right now"
                                else "Monitoring active \u2022 $activeCount app(s) using the network"
                            } else "Monitoring is not running"
                            snackbarHostState.showSnackbar(message)
                        }
                    }) {
                        Icon(Icons.Filled.Notifications, contentDescription = "Status")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = innerPadding.calculateTopPadding() + 8.dp,
                bottom = innerPadding.calculateBottomPadding() + 24.dp
            )
        ) {
            if (!uiState.hasUsageAccess) {
                item {
                    PermissionRequiredCard(
                        title = "Usage Access required",
                        description = "NetGuardian needs Usage Access to tell which app is in the " +
                            "foreground and to build accurate per-app history.",
                        onGrantClick = { context.startActivity(PermissionUtils.usageAccessSettingsIntent()) }
                    )
                }
                item { Spacer(modifier = Modifier.height(16.dp)) }
            }

            item {
                NetworkStatusCard(status = uiState.deviceStatus, dataUnit = uiState.dataUnit)
            }

            item {
                AnimatedVisibility(
                    visible = uiState.liveGraphEnabled,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    androidx.compose.foundation.layout.Column {
                        Spacer(modifier = Modifier.height(16.dp))
                        SectionHeader(title = "Live Traffic")
                        Spacer(modifier = Modifier.height(8.dp))
                        LiveTrafficGraph(
                            downloadSamples = uiState.downloadHistory,
                            uploadSamples = uiState.uploadHistory,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
                SectionHeader(title = "Active Apps")
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (uiState.liveAppUsages.isEmpty()) {
                item {
                    EmptyState(
                        message = if (uiState.hasUsageAccess) {
                            "No apps are actively using the network right now."
                        } else {
                            "Grant Usage Access above to see which apps are using the network."
                        }
                    )
                }
            } else {
                items(uiState.liveAppUsages, key = { it.appInfo.packageName }) { usage ->
                    AppUsageCard(
                        usage = usage,
                        dataUnit = uiState.dataUnit,
                        onClick = { onOpenApp(usage.appInfo.packageName) },
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(12.dp))
                SectionHeader(title = "Total Usage")
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TotalUsageTile(
                        label = "Today \u2193",
                        bytes = uiState.todayTotal.rxBytes,
                        modifier = Modifier.weight(1f)
                    )
                    TotalUsageTile(
                        label = "Today \u2191",
                        bytes = uiState.todayTotal.txBytes,
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TotalUsageTile(
                        label = "This Hour",
                        bytes = uiState.currentHourTotal.totalBytes,
                        modifier = Modifier.weight(1f)
                    )
                    TotalUsageTile(
                        label = "This Session",
                        bytes = uiState.sessionTotal.totalBytes,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(20.dp))
                SectionHeader(title = "Quick Actions")
                Spacer(modifier = Modifier.height(8.dp))
                QuickActionsRow(
                    onRefresh = { viewModel.refresh() },
                    onViewAllApps = { onNavigateToTab(Destination.Apps.route) },
                    onHistory = { onNavigateToTab(Destination.History.route) },
                    onSettings = { onNavigateToTab(Destination.Settings.route) }
                )
            }
        }
    }
}

@Composable
private fun TotalUsageTile(label: String, bytes: Long, modifier: Modifier = Modifier) {
    androidx.compose.material3.Card(
        modifier = modifier,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(com.netguardian.app.ui.theme.CardCornerRadius),
        colors = androidx.compose.material3.CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        )
    ) {
        androidx.compose.foundation.layout.Column(modifier = Modifier.padding(14.dp)) {
            AnimatedByteCounter(bytes = bytes, style = MaterialTheme.typography.titleLarge)
            Text(text = label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun QuickActionsRow(
    onRefresh: () -> Unit,
    onViewAllApps: () -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit
) {
    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            QuickActionButton("Refresh", Icons.Filled.Refresh, onRefresh)
        }
        item {
            QuickActionButton("All Apps", Icons.Filled.Apps, onViewAllApps)
        }
        item {
            QuickActionButton("History", Icons.Filled.History, onHistory)
        }
        item {
            QuickActionButton("Settings", Icons.Filled.Settings, onSettings)
        }
    }
}

@Composable
private fun QuickActionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label)
    }
}
