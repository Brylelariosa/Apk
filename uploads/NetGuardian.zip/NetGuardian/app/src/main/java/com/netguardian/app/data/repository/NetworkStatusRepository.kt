package com.netguardian.app.data.repository

import com.netguardian.app.data.model.DeviceNetworkStatus
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

interface NetworkStatusRepository {
    val deviceStatus: StateFlow<DeviceNetworkStatus>
    val isMonitoringActive: StateFlow<Boolean>
    val sessionStartMillis: StateFlow<Long>
}

@Singleton
class NetworkStatusRepositoryImpl @Inject constructor(
    private val liveMonitorState: LiveMonitorState
) : NetworkStatusRepository {
    override val deviceStatus: StateFlow<DeviceNetworkStatus> = liveMonitorState.deviceStatus
    override val isMonitoringActive: StateFlow<Boolean> = liveMonitorState.isServiceRunning
    override val sessionStartMillis: StateFlow<Long> = liveMonitorState.sessionStartMillis
}
