package com.netguardian.app.data.model

/** The transport currently carrying traffic, as reported by [android.net.ConnectivityManager]. */
enum class NetworkType(val label: String) {
    WIFI("Wi-Fi"),
    CELLULAR_5G("5G"),
    CELLULAR_LTE("LTE"),
    CELLULAR_OTHER("Mobile Data"),
    ETHERNET("Ethernet"),
    NONE("Disconnected"),
    OTHER("Other")
}

/** Whether a snapshot of usage happened while its app was in the foreground or background. */
enum class UsageOrigin { FOREGROUND, BACKGROUND }

/** Live activity classification for a single app's connection right now. */
enum class ActivityState { RECEIVING, UPLOADING, BOTH, IDLE }

enum class ThemeMode { LIGHT, DARK, SYSTEM }

enum class DataUnit(val label: String) {
    KBPS("KB/s"),
    MBPS_BYTES("MB/s"),
    MBPS_BITS("Mbps")
}

enum class AppSortOrder(val label: String) {
    ALPHABETICAL("Alphabetical"),
    HIGHEST_USAGE("Highest Usage"),
    RECENTLY_ACTIVE("Recently Active"),
    BACKGROUND_USAGE("Background Usage")
}

enum class HistoryRange(val label: String) { DAILY("Daily"), WEEKLY("Weekly"), MONTHLY("Monthly") }
