package com.netguardian.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.netguardian.app.data.model.ThemeMode

private val LightColors = lightColorScheme(
    primary = GuardianBlue40,
    onPrimary = Color.White,
    primaryContainer = GuardianBlue90,
    onPrimaryContainer = GuardianBlue10,
    secondary = GuardianTeal40,
    onSecondary = Color.White,
    secondaryContainer = GuardianTeal90,
    onSecondaryContainer = GuardianTeal20,
    tertiary = GuardianAmber40,
    onTertiary = Color.White,
    tertiaryContainer = GuardianAmber90,
    onTertiaryContainer = GuardianAmber30,
    error = GuardianError40,
    background = GuardianNeutral99,
    onBackground = GuardianNeutral10,
    surface = GuardianNeutral99,
    onSurface = GuardianNeutral10,
    surfaceVariant = GuardianNeutral95,
    onSurfaceVariant = GuardianNeutralVariant30,
    outline = GuardianNeutralVariant50
)

private val DarkColors = darkColorScheme(
    primary = GuardianBlue80,
    onPrimary = GuardianBlue20,
    primaryContainer = GuardianBlue30,
    onPrimaryContainer = GuardianBlue90,
    secondary = GuardianTeal80,
    onSecondary = GuardianTeal20,
    secondaryContainer = GuardianTeal30,
    onSecondaryContainer = GuardianTeal90,
    tertiary = GuardianAmber80,
    onTertiary = GuardianAmber30,
    tertiaryContainer = GuardianAmber40,
    onTertiaryContainer = GuardianAmber90,
    error = GuardianError80,
    background = GuardianNeutral10,
    onBackground = GuardianNeutral95,
    surface = GuardianNeutral10,
    onSurface = GuardianNeutral95,
    surfaceVariant = Color(0xFF2C2E33),
    onSurfaceVariant = GuardianNeutralVariant80,
    outline = GuardianNeutralVariant50
)

/**
 * Root theme for the app. Honors the user's Settings choice (light/dark/system) and, on Android
 * 12+, blends in Material You dynamic color so NetGuardian feels native to the device rather
 * than imposing a fixed palette - falling back to the hand-tuned [LightColors]/[DarkColors]
 * schemes above on Android 11, where dynamic color isn't available.
 */
@Composable
fun NetGuardianTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val systemDark = isSystemInDarkTheme()
    val useDarkTheme = when (themeMode) {
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
        ThemeMode.SYSTEM -> systemDark
    }

    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (useDarkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        useDarkTheme -> DarkColors
        else -> LightColors
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !useDarkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NetGuardianTypography,
        shapes = NetGuardianShapes,
        content = content
    )
}
