package com.netguardian.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "block_schedule")
data class BlockScheduleEntity(
    @PrimaryKey val id: String,
    val label: String,
    val packageNames: Set<String>,
    val daysOfWeek: Set<Int>,
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int,
    val enabled: Boolean
)
