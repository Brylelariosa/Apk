package com.netguardian.app.data.util

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.telephony.TelephonyDisplayInfo
import android.telephony.TelephonyManager
import com.netguardian.app.data.model.NetworkType
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Best-effort snapshot of "what is the device connected to right now". Every lookup is wrapped
 * defensively: signal strength in particular depends on OEM behavior and optional permissions,
 * so failures degrade to `null`/`NONE` rather than crashing the monitoring loop.
 */
@Singleton
class NetworkInfoProvider @Inject constructor(@ApplicationContext private val context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    fun isConnected(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val caps = connectivityManager.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ||
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun currentNetworkType(): NetworkType {
        val network = connectivityManager.activeNetwork ?: return NetworkType.NONE
        val caps = connectivityManager.getNetworkCapabilities(network) ?: return NetworkType.NONE
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.ETHERNET
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> currentCellularSubtype()
            else -> NetworkType.OTHER
        }
    }

    private fun currentCellularSubtype(): NetworkType {
        return try {
            val telephonyManager =
                context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
                    ?: return NetworkType.CELLULAR_OTHER
            when (telephonyManager.dataNetworkType) {
                TelephonyManager.NETWORK_TYPE_NR -> NetworkType.CELLULAR_5G
                TelephonyManager.NETWORK_TYPE_LTE -> NetworkType.CELLULAR_LTE
                else -> NetworkType.CELLULAR_OTHER
            }
        } catch (e: SecurityException) {
            NetworkType.CELLULAR_OTHER
        }
    }

    fun currentIpAddress(): String? {
        val network = connectivityManager.activeNetwork ?: return null
        val linkProperties = connectivityManager.getLinkProperties(network) ?: return null
        return linkProperties.linkAddresses
            .firstOrNull { !it.address.isLoopbackAddress }
            ?.address
            ?.hostAddress
    }

    /** Returns an approximate 0-100 signal quality, or null if it cannot be determined safely. */
    fun currentSignalStrengthPercent(): Int? {
        val type = currentNetworkType()
        return when (type) {
            NetworkType.WIFI -> wifiSignalPercent()
            NetworkType.CELLULAR_5G, NetworkType.CELLULAR_LTE, NetworkType.CELLULAR_OTHER ->
                cellularSignalPercent()
            else -> null
        }
    }

    private fun wifiSignalPercent(): Int? = runCatching {
        val wifiManager =
            context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val rssi = wifiManager.connectionInfo.rssi
        @Suppress("DEPRECATION")
        val level = WifiManager.calculateSignalLevel(rssi, 5)
        (level * 100) / 4
    }.getOrNull()

    private fun cellularSignalPercent(): Int? = runCatching {
        val telephonyManager =
            context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val strength = telephonyManager.signalStrength ?: return null
        (strength.level * 100) / 4
    }.getOrNull()

    // Retained for potential future use surfacing display-level (5G NSA vs SA) detail.
    fun describesNrDisplayInfo(displayInfo: TelephonyDisplayInfo?): Boolean =
        displayInfo?.overrideNetworkType == TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA
}
