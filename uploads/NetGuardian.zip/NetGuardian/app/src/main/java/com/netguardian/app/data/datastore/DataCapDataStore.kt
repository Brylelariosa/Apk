package com.netguardian.app.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataCapDataStore by preferencesDataStore(name = "netguardian_data_caps")

data class DataCapSettings(
    /** packageName -> cap in bytes for that app's usage *today*. */
    val perAppCapsBytes: Map<String, Long> = emptyMap(),
    val globalDailyCapBytes: Long? = null,
    /** Apps currently blocked *because* they hit their cap, as opposed to blocked manually -
     *  tracked separately so only these get released automatically at the next day rollover. */
    val autoBlockedPackages: Set<String> = emptySet(),
    val lastCheckedDate: LocalDate? = null
)

@Singleton
class DataCapDataStore @Inject constructor(@ApplicationContext private val context: Context) {

    private object Keys {
        val PER_APP_CAPS = stringSetPreferencesKey("per_app_caps") // "packageName|bytes" entries
        val GLOBAL_CAP = stringPreferencesKey("global_daily_cap_bytes")
        val AUTO_BLOCKED = stringSetPreferencesKey("auto_blocked_packages")
        val LAST_CHECKED_DATE = stringPreferencesKey("last_checked_date")
    }

    val settings: Flow<DataCapSettings> = context.dataCapDataStore.data.map { prefs ->
        val perApp = (prefs[Keys.PER_APP_CAPS] ?: emptySet())
            .mapNotNull { entry -> decodeCapEntry(entry) }
            .toMap()
        DataCapSettings(
            perAppCapsBytes = perApp,
            globalDailyCapBytes = prefs[Keys.GLOBAL_CAP]?.toLongOrNull(),
            autoBlockedPackages = prefs[Keys.AUTO_BLOCKED] ?: emptySet(),
            lastCheckedDate = prefs[Keys.LAST_CHECKED_DATE]?.let { runCatching { LocalDate.parse(it) }.getOrNull() }
        )
    }

    suspend fun setAppCap(packageName: String, capBytes: Long?) {
        context.dataCapDataStore.edit { prefs ->
            val current = (prefs[Keys.PER_APP_CAPS] ?: emptySet())
                .mapNotNull { decodeCapEntry(it) }
                .toMap()
                .toMutableMap()
            if (capBytes == null) current.remove(packageName) else current[packageName] = capBytes
            prefs[Keys.PER_APP_CAPS] = current.map { "${it.key}|${it.value}" }.toSet()
        }
    }

    suspend fun setGlobalCap(capBytes: Long?) {
        context.dataCapDataStore.edit { prefs ->
            if (capBytes == null) prefs.remove(Keys.GLOBAL_CAP) else prefs[Keys.GLOBAL_CAP] = capBytes.toString()
        }
    }

    suspend fun markAutoBlocked(packageName: String) {
        context.dataCapDataStore.edit { prefs ->
            prefs[Keys.AUTO_BLOCKED] = (prefs[Keys.AUTO_BLOCKED] ?: emptySet()) + packageName
        }
    }

    suspend fun clearAutoBlocked(packageNames: Set<String>) {
        context.dataCapDataStore.edit { prefs ->
            prefs[Keys.AUTO_BLOCKED] = (prefs[Keys.AUTO_BLOCKED] ?: emptySet()) - packageNames
        }
    }

    suspend fun setLastCheckedDate(date: LocalDate) {
        context.dataCapDataStore.edit { prefs -> prefs[Keys.LAST_CHECKED_DATE] = date.toString() }
    }

    private fun decodeCapEntry(entry: String): Pair<String, Long>? {
        val separatorIndex = entry.lastIndexOf('|')
        if (separatorIndex <= 0) return null
        val packageName = entry.substring(0, separatorIndex)
        val bytes = entry.substring(separatorIndex + 1).toLongOrNull() ?: return null
        return packageName to bytes
    }
}
