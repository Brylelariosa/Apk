package com.netguardian.app.data.model

import java.time.LocalDateTime

/**
 * A rule that blocks a set of apps during a recurring time window (e.g. "block social apps,
 * weekdays, 9am-5pm"). Deliberately does not support windows that wrap past midnight (where
 * end < start) - that adds meaningfully more edge-case logic for a use case ("block overnight")
 * that's rarer than the plain same-day window, so it's left unsupported for now rather than
 * risking getting the wraparound day-of-week math subtly wrong.
 */
data class BlockSchedule(
    val id: String,
    val label: String,
    val packageNames: Set<String>,
    val daysOfWeek: Set<Int>,
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int,
    val enabled: Boolean
) {
    init {
        require(startMinuteOfDay in 0..1439) { "startMinuteOfDay out of range" }
        require(endMinuteOfDay in 0..1439) { "endMinuteOfDay out of range" }
    }

    fun isActiveAt(dateTime: LocalDateTime): Boolean {
        if (!enabled) return false
        if (endMinuteOfDay <= startMinuteOfDay) return false
        if (!daysOfWeek.contains(dateTime.dayOfWeek.value)) return false
        val minuteOfDay = dateTime.hour * 60 + dateTime.minute
        return minuteOfDay in startMinuteOfDay until endMinuteOfDay
    }
}
