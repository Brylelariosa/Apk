package com.netguardian.app.di

import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.AppUsageRepositoryImpl
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.FirewallRepositoryImpl
import com.netguardian.app.data.repository.NetworkStatusRepository
import com.netguardian.app.data.repository.NetworkStatusRepositoryImpl
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.repository.SettingsRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindNetworkStatusRepository(impl: NetworkStatusRepositoryImpl): NetworkStatusRepository

    @Binds
    @Singleton
    abstract fun bindAppUsageRepository(impl: AppUsageRepositoryImpl): AppUsageRepository

    @Binds
    @Singleton
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository

    @Binds
    @Singleton
    abstract fun bindFirewallRepository(impl: FirewallRepositoryImpl): FirewallRepository
}
