package com.netguardian.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.netguardian.app.MainActivity
import com.netguardian.app.NetGuardianApplication
import com.netguardian.app.R
import com.netguardian.app.data.local.dao.NetworkUsageDao
import com.netguardian.app.data.local.entity.NetworkUsageSnapshot
import com.netguardian.app.data.local.entity.PersistedTransport
import com.netguardian.app.data.model.ActivityState
import com.netguardian.app.data.model.AppInfo
import com.netguardian.app.data.model.DeviceNetworkStatus
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.model.NetworkType
import com.netguardian.app.data.repository.LiveMonitorState
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.ByteCounters
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.data.util.ForegroundAppTracker
import com.netguardian.app.data.util.InstalledAppsProvider
import com.netguardian.app.data.util.NetworkInfoProvider
import com.netguardian.app.data.util.TrafficStatsSampler
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * Runs continuously while monitoring is enabled, sampling [TrafficStats][android.net.TrafficStats]
 * counters for every network-capable app at the user's chosen refresh interval.
 *
 * Design notes (see also the repository layer this feeds):
 *  - Every tick only reads cheap in-memory kernel counters, so 1-second polling is not the
 *    battery concern it would be if it touched disk; what *is* expensive is disk I/O, so raw
 *    per-tick deltas are accumulated in memory and flushed to Room in batches (see
 *    [FLUSH_INTERVAL_MS]) rather than written one row per tick.
 *  - The installed-app list is only re-enumerated periodically ([APP_LIST_REFRESH_MS]), since
 *    PackageManager enumeration is comparatively heavy and the set of installed apps rarely
 *    changes second to second.
 *  - Foreground/background classification comes from [ForegroundAppTracker], which is itself a
 *    thin, throttle-friendly wrapper over UsageStatsManager's event stream.
 */
@AndroidEntryPoint
class NetworkMonitorService : Service() {

    @Inject lateinit var trafficStatsSampler: TrafficStatsSampler
    @Inject lateinit var installedAppsProvider: InstalledAppsProvider
    @Inject lateinit var foregroundAppTracker: ForegroundAppTracker
    @Inject lateinit var networkInfoProvider: NetworkInfoProvider
    @Inject lateinit var liveMonitorState: LiveMonitorState
    @Inject lateinit var networkUsageDao: NetworkUsageDao
    @Inject lateinit var settingsRepository: SettingsRepository

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitorJob: Job? = null
    private var settingsJob: Job? = null
    private var purgeJob: Job? = null

    @Volatile private var refreshIntervalSeconds: Int = 2

    private var trackedApps: List<AppInfo> = emptyList()
    private var lastAppListRefreshAt: Long = 0L

    private val lastUidCounters = mutableMapOf<String, ByteCounters>()
    private var lastDeviceCounters: ByteCounters? = null
    private var lastTickAt: Long = 0L

    private val lastActiveAtMillis = mutableMapOf<String, Long>()
    private val sessionRxBytes = mutableMapOf<String, Long>()
    private val sessionTxBytes = mutableMapOf<String, Long>()
    private val recentSpeedSamples = mutableMapOf<String, ArrayDeque<Float>>()

    private val pendingDeltas = mutableMapOf<PendingKey, PendingAccumulator>()
    private var lastFlushAt: Long = 0L
    private var lastNotificationUpdateAt: Long = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification(0, 0))
        liveMonitorState.setServiceRunning(true)
        liveMonitorState.markSessionStart()

        settingsJob = serviceScope.launch {
            settingsRepository.settings.collect { settings ->
                refreshIntervalSeconds = settings.refreshIntervalSeconds.coerceIn(1, 10)
            }
        }
        purgeJob = serviceScope.launch {
            networkUsageDao.deleteOlderThan(System.currentTimeMillis() - RETENTION_MS)
        }
        startMonitoring()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        monitorJob?.cancel()
        settingsJob?.cancel()
        purgeJob?.cancel()
        serviceScope.launch { flushPendingDeltas() }
        serviceScope.cancel()
        liveMonitorState.setServiceRunning(false)
        super.onDestroy()
    }

    private fun startMonitoring() {
        monitorJob = serviceScope.launch {
            while (isActive) {
                runCatching { tick() }
                delay(refreshIntervalSeconds * 1000L)
            }
        }
    }

    private suspend fun tick() {
        val now = System.currentTimeMillis()
        val elapsedSeconds = if (lastTickAt == 0L) 0.0 else (now - lastTickAt) / 1000.0
        lastTickAt = now

        refreshTrackedAppsIfNeeded(now)
        publishDeviceStatus(now, elapsedSeconds)

        val foregroundPackage = foregroundAppTracker.refreshAndGetForegroundPackage()
        val transport = currentTransport()
        val liveUsages = mutableListOf<LiveAppUsage>()

        for (app in trackedApps) {
            val counters = trafficStatsSampler.sampleUid(app.uid)
            val previous = lastUidCounters[app.packageName]
            lastUidCounters[app.packageName] = counters
            if (previous == null) continue

            val rxDelta = (counters.rxBytes - previous.rxBytes).coerceAtLeast(0)
            val txDelta = (counters.txBytes - previous.txBytes).coerceAtLeast(0)
            val isForeground = app.packageName == foregroundPackage

            if (rxDelta > 0 || txDelta > 0) {
                lastActiveAtMillis[app.packageName] = now
                sessionRxBytes[app.packageName] = (sessionRxBytes[app.packageName] ?: 0L) + rxDelta
                sessionTxBytes[app.packageName] = (sessionTxBytes[app.packageName] ?: 0L) + txDelta
                accumulate(app, rxDelta, txDelta, transport, isForeground)
            }

            val lastActive = lastActiveAtMillis[app.packageName] ?: continue
            if (now - lastActive > ACTIVE_GRACE_PERIOD_MS) continue

            val downloadBps = if (elapsedSeconds > 0) (rxDelta / elapsedSeconds).toLong() else 0L
            val uploadBps = if (elapsedSeconds > 0) (txDelta / elapsedSeconds).toLong() else 0L
            val samples = recentSpeedSamples.getOrPut(app.packageName) { ArrayDeque() }
            samples.addLast((downloadBps + uploadBps).toFloat())
            while (samples.size > MAX_SAMPLES) samples.removeFirst()

            val state = when {
                rxDelta > 0 && txDelta > 0 -> ActivityState.BOTH
                rxDelta > 0 -> ActivityState.RECEIVING
                txDelta > 0 -> ActivityState.UPLOADING
                else -> ActivityState.IDLE
            }

            liveUsages += LiveAppUsage(
                appInfo = app,
                downloadBps = downloadBps,
                uploadBps = uploadBps,
                sessionRxBytes = sessionRxBytes[app.packageName] ?: 0L,
                sessionTxBytes = sessionTxBytes[app.packageName] ?: 0L,
                isForeground = isForeground,
                activityState = state,
                recentSamples = samples.toList()
            )
        }

        liveMonitorState.publishLiveAppUsages(
            liveUsages.sortedByDescending { it.downloadBps + it.uploadBps }
        )

        maybeFlush(now)
        maybeUpdateNotification(now)
    }

    private suspend fun publishDeviceStatus(now: Long, elapsedSeconds: Double) {
        val deviceCounters = trafficStatsSampler.sampleDeviceTotal()
        val previous = lastDeviceCounters
        lastDeviceCounters = deviceCounters

        val downloadBps: Long
        val uploadBps: Long
        if (previous != null && elapsedSeconds > 0) {
            val rxDelta = (deviceCounters.rxBytes - previous.rxBytes).coerceAtLeast(0)
            val txDelta = (deviceCounters.txBytes - previous.txBytes).coerceAtLeast(0)
            downloadBps = (rxDelta / elapsedSeconds).toLong()
            uploadBps = (txDelta / elapsedSeconds).toLong()
        } else {
            downloadBps = 0L
            uploadBps = 0L
        }

        liveMonitorState.publishDeviceStatus(
            DeviceNetworkStatus(
                isConnected = networkInfoProvider.isConnected(),
                networkType = networkInfoProvider.currentNetworkType(),
                downloadBps = downloadBps,
                uploadBps = uploadBps,
                ipAddress = networkInfoProvider.currentIpAddress(),
                signalStrengthPercent = networkInfoProvider.currentSignalStrengthPercent()
            )
        )
        this.lastKnownDownloadBps = downloadBps
        this.lastKnownUploadBps = uploadBps
    }

    @Volatile private var lastKnownDownloadBps: Long = 0
    @Volatile private var lastKnownUploadBps: Long = 0

    private suspend fun refreshTrackedAppsIfNeeded(now: Long) {
        if (trackedApps.isNotEmpty() && now - lastAppListRefreshAt < APP_LIST_REFRESH_MS) return
        trackedApps = withContext(Dispatchers.IO) { installedAppsProvider.listNetworkCapableApps() }
        lastAppListRefreshAt = now
    }

    private fun currentTransport(): PersistedTransport = when (networkInfoProvider.currentNetworkType()) {
        NetworkType.WIFI -> PersistedTransport.WIFI
        NetworkType.CELLULAR_5G, NetworkType.CELLULAR_LTE, NetworkType.CELLULAR_OTHER -> PersistedTransport.MOBILE
        else -> PersistedTransport.OTHER
    }

    private fun accumulate(
        app: AppInfo,
        rxDelta: Long,
        txDelta: Long,
        transport: PersistedTransport,
        isForeground: Boolean
    ) {
        val key = PendingKey(app.packageName, app.uid, transport, isForeground)
        val acc = pendingDeltas.getOrPut(key) { PendingAccumulator() }
        acc.rx += rxDelta
        acc.tx += txDelta
    }

    private suspend fun maybeFlush(now: Long) {
        if (now - lastFlushAt < FLUSH_INTERVAL_MS) return
        flushPendingDeltas()
        lastFlushAt = now
    }

    private suspend fun flushPendingDeltas() {
        if (pendingDeltas.isEmpty()) return
        val timestamp = System.currentTimeMillis()
        val rows = pendingDeltas.map { (key, acc) ->
            NetworkUsageSnapshot(
                timestamp = timestamp,
                packageName = key.packageName,
                uid = key.uid,
                rxBytesDelta = acc.rx,
                txBytesDelta = acc.tx,
                transport = key.transport,
                isForeground = key.isForeground
            )
        }
        networkUsageDao.insertAll(rows)
        pendingDeltas.clear()
    }

    private fun maybeUpdateNotification(now: Long) {
        if (now - lastNotificationUpdateAt < NOTIFICATION_UPDATE_INTERVAL_MS) return
        lastNotificationUpdateAt = now
        val manager = ContextCompat.getSystemService(this, android.app.NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(lastKnownDownloadBps, lastKnownUploadBps))
    }

    private fun buildNotification(downloadBps: Long, uploadBps: Long): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val speedText = "\u2193 ${ByteFormatter.formatBytes(downloadBps)}/s   " +
            "\u2191 ${ByteFormatter.formatBytes(uploadBps)}/s"
        return NotificationCompat.Builder(this, NetGuardianApplication.MONITOR_CHANNEL_ID)
            .setContentTitle(getString(R.string.monitor_notification_title))
            .setContentText(speedText)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent)
            .build()
    }

    private data class PendingKey(
        val packageName: String,
        val uid: Int,
        val transport: PersistedTransport,
        val isForeground: Boolean
    )

    private data class PendingAccumulator(var rx: Long = 0L, var tx: Long = 0L)

    companion object {
        private const val NOTIFICATION_ID = 42
        private const val APP_LIST_REFRESH_MS = 60_000L
        private const val FLUSH_INTERVAL_MS = 30_000L
        private const val NOTIFICATION_UPDATE_INTERVAL_MS = 5_000L
        private const val ACTIVE_GRACE_PERIOD_MS = 6_000L
        private const val RETENTION_MS = 90L * 24 * 60 * 60 * 1000
        private const val MAX_SAMPLES = 30

        fun start(context: Context) {
            val intent = Intent(context, NetworkMonitorService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, NetworkMonitorService::class.java))
        }
    }
}
