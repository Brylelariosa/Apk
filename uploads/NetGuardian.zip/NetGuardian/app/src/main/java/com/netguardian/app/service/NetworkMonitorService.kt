package com.netguardian.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.PowerManager
import android.os.Process
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.netguardian.app.MainActivity
import com.netguardian.app.NetGuardianApplication
import com.netguardian.app.R
import com.netguardian.app.data.datastore.FirewallSettings
import com.netguardian.app.data.local.dao.NetworkUsageDao
import com.netguardian.app.data.local.entity.NetworkUsageSnapshot
import com.netguardian.app.data.local.entity.PersistedTransport
import com.netguardian.app.data.model.ActivityState
import com.netguardian.app.data.model.AppInfo
import com.netguardian.app.data.model.DeviceNetworkStatus
import com.netguardian.app.data.model.FirewallMode
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.model.NetworkType
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.LiveMonitorState
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.AppIconCache
import com.netguardian.app.data.util.ByteCounters
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.data.util.DataCapEnforcer
import com.netguardian.app.data.util.ForegroundAppTracker
import com.netguardian.app.data.util.NetworkInfoProvider
import com.netguardian.app.data.util.NetworkStatsProvider
import com.netguardian.app.data.util.TrafficStatsSampler
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import javax.inject.Inject

/**
 * Runs continuously while monitoring is enabled, sampling network usage at the user's chosen
 * refresh interval.
 *
 * Design notes (see also the repository layer this feeds):
 *  - Device-wide totals come from [TrafficStatsSampler] (cheap, cumulative-since-boot kernel
 *    counters). Per-app totals come from [NetworkStatsProvider] (`NetworkStatsManager`) and
 *    foreground classification from [ForegroundAppTracker] (`UsageStatsManager`) - both involve
 *    real IPC to system services backed by actual file I/O, so they're the parts that matter for
 *    battery/heat/CPU contention, and the parts specifically throttled/isolated below.
 *  - **Thermal-aware throttling**: [PowerManager]'s thermal status widens the minimum gap
 *    between those two IPC-heavy calls as the device heats up (e.g. during a game), independent
 *    of the user's chosen display refresh interval - full frequency at NONE/LIGHT, backing off
 *    at MODERATE/SEVERE/beyond, returning to normal once it cools down.
 *  - **Runs on a background-priority thread, not the shared IO pool**: a foreground service
 *    needs high *process* priority to avoid being killed, but that doesn't have to mean this
 *    service's own worker *thread* competes evenly with a foreground game for CPU scheduling.
 *    [backgroundDispatcher] is backed by a single thread explicitly set to
 *    `Process.THREAD_PRIORITY_BACKGROUND`, so the OS scheduler favors foreground work under
 *    contention - this is what actually reduces game stutter, more than just doing less work.
 *  - **Blocked apps are cheaply skipped, not resolved then discarded**: a blocked app's failed
 *    connection attempts still show up in NetworkStatsManager's byte counts even though nothing
 *    reaches anywhere, and the more apps are blocked (especially in Allowlist mode, where every
 *    unlisted app - including many system apps - ends up blocked), the more of these "phantom"
 *    deltas show up every tick. Resolving each one's identity via PackageManager just to then
 *    discard it was real, avoidable overhead that scaled with how many apps were blocked -
 *    exactly what made this worse "when there's a lot of apps or system apps blocked". Blocked
 *    UIDs are now checked against a small cached set (rebuilt only when the block/allow list
 *    actually changes, not per tick) *before* any PackageManager resolution happens.
 *  - **Detecting a real block vs. a failed attempt, instead of hardcoding "never show blocked
 *    apps"**: the firewall's sinkhole never writes anything back into the VPN tunnel, so a
 *    genuinely blocked app's download bytes should be ~0 - it can send failed attempts (upload)
 *    but gets nothing back. If a blocked app's download bytes exceed a tiny noise threshold
 *    anyway, that's a real signal the block isn't fully effective for it, and it's surfaced
 *    normally rather than hidden - only apps that match the "blocked and getting nothing back"
 *    pattern are excluded from usage.
 *  - Live per-tick readings are batched in memory and flushed to Room every [FLUSH_INTERVAL_MS]
 *    (not once per tick) to keep disk I/O - and battery draw - low even at a 1-second interval.
 */
@AndroidEntryPoint
class NetworkMonitorService : Service() {

    @Inject lateinit var trafficStatsSampler: TrafficStatsSampler
    @Inject lateinit var networkStatsProvider: NetworkStatsProvider
    @Inject lateinit var appIconCache: AppIconCache
    @Inject lateinit var foregroundAppTracker: ForegroundAppTracker
    @Inject lateinit var networkInfoProvider: NetworkInfoProvider
    @Inject lateinit var liveMonitorState: LiveMonitorState
    @Inject lateinit var networkUsageDao: NetworkUsageDao
    @Inject lateinit var settingsRepository: SettingsRepository
    @Inject lateinit var firewallRepository: FirewallRepository
    @Inject lateinit var dataCapEnforcer: DataCapEnforcer

    /** A dedicated, single, background-priority thread for this service's IPC-heavy work (see
     *  class doc). Deliberately not [Dispatchers.IO], which is a shared pool of normal-priority
     *  threads used across the whole app - lowering priority there would affect everything, not
     *  just this service. */
    private val backgroundExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread({
            // Process.setThreadPriority sets the actual Linux nice value for this thread and
            // must be called from the thread itself; Thread.priority alone is a much weaker
            // JVM-level hint that ART doesn't map to OS scheduling as directly.
            Process.setThreadPriority(Process.THREAD_PRIORITY_BACKGROUND)
            runnable.run()
        }, "NetGuardian-Monitor")
    }
    private val backgroundDispatcher: CoroutineDispatcher = backgroundExecutor.asCoroutineDispatcher()

    private val serviceScope = CoroutineScope(SupervisorJob() + backgroundDispatcher)
    private var monitorJob: Job? = null
    private var settingsJob: Job? = null
    private var firewallJob: Job? = null
    private var purgeJob: Job? = null

    @Volatile private var refreshIntervalSeconds: Int = 2
    @Volatile private var currentFirewallSettings: FirewallSettings = FirewallSettings()
    @Volatile private var currentBlockedUids: Set<Int> = emptySet()
    @Volatile private var currentAllowedUids: Set<Int> = emptySet()

    private var powerManager: PowerManager? = null
    @Volatile private var thermalStatus: Int = PowerManager.THERMAL_STATUS_NONE
    private var thermalListener: PowerManager.OnThermalStatusChangedListener? = null

    private var lastDeviceCounters: ByteCounters? = null
    private var lastTickAt: Long = 0L
    private var lastStatsQueryAt: Long = 0L
    @Volatile private var lastKnownForegroundPackage: String? = null

    private val lastActiveAtMillis = mutableMapOf<String, Long>()
    private val sessionRxBytes = mutableMapOf<String, Long>()
    private val sessionTxBytes = mutableMapOf<String, Long>()
    private val recentSpeedSamples = mutableMapOf<String, ArrayDeque<Float>>()

    private val pendingDeltas = mutableMapOf<PendingKey, PendingAccumulator>()
    private var lastFlushAt: Long = 0L
    private var lastNotificationUpdateAt: Long = 0L

    @Volatile private var lastKnownDownloadBps: Long = 0
    @Volatile private var lastKnownUploadBps: Long = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification(0, 0))
        liveMonitorState.setServiceRunning(true)
        liveMonitorState.markSessionStart()
        registerThermalListener()

        settingsJob = serviceScope.launch {
            settingsRepository.settings.collect { settings ->
                refreshIntervalSeconds = settings.refreshIntervalSeconds.coerceIn(1, 10)
            }
        }
        firewallJob = serviceScope.launch {
            firewallRepository.settings.collect { settings -> onFirewallSettingsChanged(settings) }
        }
        purgeJob = serviceScope.launch {
            networkUsageDao.deleteOlderThan(System.currentTimeMillis() - RETENTION_MS)
        }
        startMonitoring()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        monitorJob?.cancel()
        settingsJob?.cancel()
        firewallJob?.cancel()
        purgeJob?.cancel()
        unregisterThermalListener()
        // Deliberately blocking: launching this in serviceScope and then cancelling that same
        // scope right after was a real bug - cancel() can tear down a just-launched coroutine
        // before it runs, silently dropping the last flush interval's worth of usage data
        // every time the service stopped. This flush is small (an in-memory map -> one batch
        // insert), so a brief synchronous wait here is the safer tradeoff.
        kotlinx.coroutines.runBlocking { flushPendingDeltas() }
        serviceScope.cancel()
        backgroundExecutor.shutdown()
        liveMonitorState.setServiceRunning(false)
        super.onDestroy()
    }

    /**
     * Resolving package -> UID happens here, once per settings *change*, specifically so the
     * hot per-tick loop never has to call PackageManager just to check "is this app blocked".
     */
    private fun onFirewallSettingsChanged(settings: FirewallSettings) {
        val previous = currentFirewallSettings
        currentFirewallSettings = settings
        currentBlockedUids = settings.blockedPackages.mapNotNullTo(mutableSetOf()) { resolveUidOrNull(it) }
        currentAllowedUids = settings.allowedPackages.mapNotNullTo(mutableSetOf()) { resolveUidOrNull(it) }

        // Drop tracking state immediately for anything that just became blocked, rather than
        // waiting for the grace period to expire - otherwise a just-blocked app can still show
        // a few seconds of leftover "activity" from before the block took effect.
        val newlyBlocked = settings.blockedPackages - previous.blockedPackages
        newlyBlocked.forEach { packageName ->
            lastActiveAtMillis.remove(packageName)
            recentSpeedSamples.remove(packageName)
        }
    }

    private fun resolveUidOrNull(packageName: String): Int? {
        val uid = runCatching { appIconCache.get(packageName).uid }.getOrNull() ?: return null
        // A resolution failure inside AppIconCache.get() falls back to uid = -1, not 0; guard
        // against that (and any other non-app UID) with the same threshold used elsewhere.
        return uid.takeIf { it >= Process.FIRST_APPLICATION_UID }
    }

    private fun registerThermalListener() {
        val manager = ContextCompat.getSystemService(this, PowerManager::class.java) ?: return
        powerManager = manager
        thermalStatus = manager.currentThermalStatus
        val listener = PowerManager.OnThermalStatusChangedListener { status -> thermalStatus = status }
        thermalListener = listener
        manager.addThermalStatusListener(listener)
    }

    private fun unregisterThermalListener() {
        val manager = powerManager ?: return
        thermalListener?.let { manager.removeThermalStatusListener(it) }
        thermalListener = null
    }

    private fun startMonitoring() {
        monitorJob = serviceScope.launch {
            while (isActive) {
                runCatching { tick() }
                delay(refreshIntervalSeconds * 1000L)
            }
        }
    }

    private suspend fun tick() {
        val now = System.currentTimeMillis()
        val elapsedSeconds = if (lastTickAt == 0L) 0.0 else (now - lastTickAt) / 1000.0
        lastTickAt = now

        // Cheap (kernel counters, no IPC) - always runs at full tick frequency regardless of
        // thermal state, since this alone isn't what causes heat or CPU contention.
        publishDeviceStatus(now, elapsedSeconds)

        val statsFloorMs = statsFloorMsFor(thermalStatus)
        if (now - lastStatsQueryAt >= statsFloorMs) {
            // On the very first query there's no prior timestamp to window from; look back one
            // second so it isn't a guaranteed zero-width (and therefore empty) query.
            val windowStart = if (lastStatsQueryAt == 0L) now - 1_000L else lastStatsQueryAt
            lastStatsQueryAt = now
            updatePerAppUsage(windowStart, now)
        } else {
            // Not due for a fresh (IPC-heavy) query this tick - still let already-active apps'
            // grace period expire on schedule using cached data, so backing off under thermal
            // pressure doesn't leave the Active Apps list looking permanently stuck.
            republishGracePeriodOnly(now)
        }

        maybeFlush(now)
        maybeUpdateNotification(now)
    }

    /** Backs off how often the two IPC-heavy calls (NetworkStatsManager, UsageStatsManager) run
     *  as the device gets hotter, independent of the user's chosen display refresh interval. */
    private fun statsFloorMsFor(status: Int): Long = when (status) {
        PowerManager.THERMAL_STATUS_NONE, PowerManager.THERMAL_STATUS_LIGHT -> 2_000L
        PowerManager.THERMAL_STATUS_MODERATE -> 5_000L
        PowerManager.THERMAL_STATUS_SEVERE -> 15_000L
        else -> 30_000L // CRITICAL, EMERGENCY, SHUTDOWN
    }

    private suspend fun updatePerAppUsage(windowStart: Long, now: Long) {
        val foregroundPackage = withContext(backgroundDispatcher) {
            foregroundAppTracker.refreshAndGetForegroundPackage()
        }
        lastKnownForegroundPackage = foregroundPackage
        val transport = currentTransport()
        val uidDeltas = withContext(backgroundDispatcher) {
            networkStatsProvider.queryUidDeltas(windowStart, now)
        }
        val tickSeconds = ((now - windowStart) / 1000.0).coerceAtLeast(0.001)
        val liveUsages = mutableListOf<LiveAppUsage>()

        for ((uid, delta) in uidDeltas) {
            // UIDs below this threshold are native system services (radio, wifi, dns, ...),
            // not installed apps - not useful to surface in a per-app breakdown.
            if (uid < Process.FIRST_APPLICATION_UID) continue
            val rxDelta = delta.rxBytes.coerceAtLeast(0L)
            val txDelta = delta.txBytes.coerceAtLeast(0L)
            if (rxDelta == 0L && txDelta == 0L) continue

            // Cheap Set lookup, no PackageManager call - skip the entire rest of this app's
            // processing immediately if it's blocked and behaving exactly as a block should
            // (nothing coming back). This is what keeps a tick's cost from scaling with how
            // many apps are blocked.
            if (isLikelyIneffectiveDueToBlock(uid, rxDelta)) continue

            val app = withContext(backgroundDispatcher) { appIconCache.getByUid(uid) } ?: continue
            val isForeground = app.packageName == foregroundPackage

            lastActiveAtMillis[app.packageName] = now
            sessionRxBytes[app.packageName] = (sessionRxBytes[app.packageName] ?: 0L) + rxDelta
            sessionTxBytes[app.packageName] = (sessionTxBytes[app.packageName] ?: 0L) + txDelta
            accumulate(app, rxDelta, txDelta, transport, isForeground)

            val downloadBps = (rxDelta / tickSeconds).toLong()
            val uploadBps = (txDelta / tickSeconds).toLong()
            val samples = recentSpeedSamples.getOrPut(app.packageName) { ArrayDeque() }
            samples.addLast((downloadBps + uploadBps).toFloat())
            while (samples.size > MAX_SAMPLES) samples.removeFirst()

            val state = when {
                rxDelta > 0 && txDelta > 0 -> ActivityState.BOTH
                rxDelta > 0 -> ActivityState.RECEIVING
                txDelta > 0 -> ActivityState.UPLOADING
                else -> ActivityState.IDLE
            }

            liveUsages += LiveAppUsage(
                appInfo = app,
                downloadBps = downloadBps,
                uploadBps = uploadBps,
                sessionRxBytes = sessionRxBytes[app.packageName] ?: 0L,
                sessionTxBytes = sessionTxBytes[app.packageName] ?: 0L,
                isForeground = isForeground,
                activityState = state,
                recentSamples = samples.toList()
            )
        }

        appendGracePeriodEntries(liveUsages, now, foregroundPackage)

        liveMonitorState.publishLiveAppUsages(
            liveUsages.sortedByDescending { it.downloadBps + it.uploadBps }
        )
    }

    /**
     * True when [uid] is blocked under the current firewall mode AND its download bytes are
     * low enough to be consistent with "nothing came back" - i.e. the block is working exactly
     * as intended, so there's nothing real to show. If a blocked UID's download bytes exceed
     * the noise threshold, this returns false *on purpose*: that's a sign the block might not be
     * fully effective for that app, and it should be surfaced normally rather than hidden.
     */
    private fun isLikelyIneffectiveDueToBlock(uid: Int, rxDelta: Long): Boolean {
        val isBlocked = when (currentFirewallSettings.mode) {
            FirewallMode.BLOCKLIST -> currentBlockedUids.contains(uid)
            FirewallMode.ALLOWLIST -> currentAllowedUids.isNotEmpty() && !currentAllowedUids.contains(uid)
        }
        return isBlocked && rxDelta <= BLOCKED_RX_NOISE_THRESHOLD_BYTES
    }

    /** Used on ticks where thermal backoff means we skip the fresh NetworkStatsManager query -
     *  still re-derives the Active Apps list from cached session state so grace-period expiry
     *  keeps working, just without any new delta data this tick. */
    private fun republishGracePeriodOnly(now: Long) {
        val liveUsages = mutableListOf<LiveAppUsage>()
        appendGracePeriodEntries(liveUsages, now, lastKnownForegroundPackage)
        liveMonitorState.publishLiveAppUsages(liveUsages)
    }

    /** Apps that had traffic recently but not this exact tick still get a short grace period in
     *  the list (per the "fade out after several seconds" behavior) rather than disappearing
     *  the instant a single tick shows no delta. */
    private fun appendGracePeriodEntries(
        liveUsages: MutableList<LiveAppUsage>,
        now: Long,
        foregroundPackage: String?
    ) {
        for ((packageName, lastActive) in lastActiveAtMillis) {
            if (liveUsages.any { it.appInfo.packageName == packageName }) continue
            if (now - lastActive > ACTIVE_GRACE_PERIOD_MS) continue
            val app = appIconCache.get(packageName)
            liveUsages += LiveAppUsage(
                appInfo = app,
                downloadBps = 0,
                uploadBps = 0,
                sessionRxBytes = sessionRxBytes[packageName] ?: 0L,
                sessionTxBytes = sessionTxBytes[packageName] ?: 0L,
                isForeground = packageName == foregroundPackage,
                activityState = ActivityState.IDLE,
                recentSamples = recentSpeedSamples[packageName]?.toList() ?: emptyList()
            )
        }
    }

    private fun publishDeviceStatus(now: Long, elapsedSeconds: Double) {
        val deviceCounters = trafficStatsSampler.sampleDeviceTotal()
        val previous = lastDeviceCounters
        lastDeviceCounters = deviceCounters

        val downloadBps: Long
        val uploadBps: Long
        if (previous != null && elapsedSeconds > 0) {
            val rxDelta = (deviceCounters.rxBytes - previous.rxBytes).coerceAtLeast(0)
            val txDelta = (deviceCounters.txBytes - previous.txBytes).coerceAtLeast(0)
            downloadBps = (rxDelta / elapsedSeconds).toLong()
            uploadBps = (txDelta / elapsedSeconds).toLong()
        } else {
            downloadBps = 0L
            uploadBps = 0L
        }

        liveMonitorState.publishDeviceStatus(
            DeviceNetworkStatus(
                isConnected = networkInfoProvider.isConnected(),
                networkType = networkInfoProvider.currentNetworkType(),
                downloadBps = downloadBps,
                uploadBps = uploadBps,
                ipAddress = networkInfoProvider.currentIpAddress(),
                signalStrengthPercent = networkInfoProvider.currentSignalStrengthPercent()
            )
        )
        lastKnownDownloadBps = downloadBps
        lastKnownUploadBps = uploadBps
    }

    private fun currentTransport(): PersistedTransport = when (networkInfoProvider.currentNetworkType()) {
        NetworkType.WIFI -> PersistedTransport.WIFI
        NetworkType.CELLULAR_5G, NetworkType.CELLULAR_LTE, NetworkType.CELLULAR_OTHER -> PersistedTransport.MOBILE
        else -> PersistedTransport.OTHER
    }

    private fun accumulate(
        app: AppInfo,
        rxDelta: Long,
        txDelta: Long,
        transport: PersistedTransport,
        isForeground: Boolean
    ) {
        val key = PendingKey(app.packageName, app.uid, transport, isForeground)
        val acc = pendingDeltas.getOrPut(key) { PendingAccumulator() }
        acc.rx += rxDelta
        acc.tx += txDelta
    }

    private suspend fun maybeFlush(now: Long) {
        if (now - lastFlushAt < FLUSH_INTERVAL_MS) return
        flushPendingDeltas()
        pruneStaleTrackingState(now)
        runCatching { dataCapEnforcer.checkAndEnforce() }
        lastFlushAt = now
    }

    /** Keeps [lastActiveAtMillis] and friends from growing unbounded over a long service run. */
    private fun pruneStaleTrackingState(now: Long) {
        val stale = lastActiveAtMillis.filterValues { now - it > STALE_TRACKING_MS }.keys
        stale.forEach { packageName ->
            lastActiveAtMillis.remove(packageName)
            recentSpeedSamples.remove(packageName)
            // Session totals intentionally survive here - "session" spans the whole service
            // run, not just recent activity, so a temporarily-quiet app shouldn't lose its
            // accumulated session bytes just because it fell out of the active list.
        }
    }

    private suspend fun flushPendingDeltas() {
        if (pendingDeltas.isEmpty()) return
        val timestamp = System.currentTimeMillis()
        val rows = pendingDeltas.map { (key, acc) ->
            NetworkUsageSnapshot(
                timestamp = timestamp,
                packageName = key.packageName,
                uid = key.uid,
                rxBytesDelta = acc.rx,
                txBytesDelta = acc.tx,
                transport = key.transport,
                isForeground = key.isForeground
            )
        }
        networkUsageDao.insertAll(rows)
        pendingDeltas.clear()
    }

    private fun maybeUpdateNotification(now: Long) {
        if (now - lastNotificationUpdateAt < NOTIFICATION_UPDATE_INTERVAL_MS) return
        lastNotificationUpdateAt = now
        val manager = ContextCompat.getSystemService(this, android.app.NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(lastKnownDownloadBps, lastKnownUploadBps))
    }

    private fun buildNotification(downloadBps: Long, uploadBps: Long): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val speedText = "\u2193 ${ByteFormatter.formatBytes(downloadBps)}/s   " +
            "\u2191 ${ByteFormatter.formatBytes(uploadBps)}/s"
        return NotificationCompat.Builder(this, NetGuardianApplication.MONITOR_CHANNEL_ID)
            .setContentTitle(getString(R.string.monitor_notification_title))
            .setContentText(speedText)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent)
            .build()
    }

    private data class PendingKey(
        val packageName: String,
        val uid: Int,
        val transport: PersistedTransport,
        val isForeground: Boolean
    )

    private data class PendingAccumulator(var rx: Long = 0L, var tx: Long = 0L)

    companion object {
        private const val NOTIFICATION_ID = 42
        private const val FLUSH_INTERVAL_MS = 30_000L
        private const val NOTIFICATION_UPDATE_INTERVAL_MS = 5_000L
        private const val ACTIVE_GRACE_PERIOD_MS = 6_000L
        private const val STALE_TRACKING_MS = 60 * 60 * 1000L
        private const val RETENTION_MS = 90L * 24 * 60 * 60 * 1000
        private const val MAX_SAMPLES = 30

        /** A blocked app's download bytes should be ~0 (the sinkhole never writes anything
         *  back); this small allowance is just for protocol-level noise, not a "some data is
         *  fine" threshold. */
        private const val BLOCKED_RX_NOISE_THRESHOLD_BYTES = 512L

        fun start(context: Context) {
            val intent = Intent(context, NetworkMonitorService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, NetworkMonitorService::class.java))
        }
    }
}
