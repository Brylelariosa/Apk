package com.netguardian.app.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.Process
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.netguardian.app.MainActivity
import com.netguardian.app.NetGuardianApplication
import com.netguardian.app.R
import com.netguardian.app.data.local.dao.NetworkUsageDao
import com.netguardian.app.data.local.entity.NetworkUsageSnapshot
import com.netguardian.app.data.local.entity.PersistedTransport
import com.netguardian.app.data.model.ActivityState
import com.netguardian.app.data.model.AppInfo
import com.netguardian.app.data.model.DeviceNetworkStatus
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.model.NetworkType
import com.netguardian.app.data.repository.LiveMonitorState
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.AppIconCache
import com.netguardian.app.data.util.ByteCounters
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.data.util.DataCapEnforcer
import com.netguardian.app.data.util.ForegroundAppTracker
import com.netguardian.app.data.util.NetworkInfoProvider
import com.netguardian.app.data.util.NetworkStatsProvider
import com.netguardian.app.data.util.TrafficStatsSampler
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

/**
 * Runs continuously while monitoring is enabled, sampling network usage at the user's chosen
 * refresh interval.
 *
 * Design notes (see also the repository layer this feeds):
 *  - Device-wide totals come from [TrafficStatsSampler] (cheap, cumulative-since-boot kernel
 *    counters) - fine for "my own device's overall throughput" since that's always visible to
 *    the calling app.
 *  - Per-app totals come from [NetworkStatsProvider] (`NetworkStatsManager`), not TrafficStats'
 *    per-UID calls: Android's own docs for network-usage APIs are explicit that, by default, an
 *    app can only see *its own* traffic through the plain TrafficStats UID calls - other UIDs
 *    require going through the Usage Access-gated NetworkStatsManager APIs, which is also what
 *    Android's own Settings > Data usage screen uses. This app already requests Usage Access
 *    for foreground/background classification, so it doubles as the source for per-app bytes.
 *  - Every tick is driven by *which UIDs NetworkStatsManager reports traffic for*, not by a
 *    separately-enumerated "installed apps" list: that list can't always be trusted to be
 *    complete, whereas the UID showing up in real traffic data is ground truth. [AppIconCache]
 *    resolves each UID to a display-friendly app on demand.
 *  - Querying NetworkStatsManager with an explicit [windowStart, now) range hands back the
 *    delta for that window directly, so there's no need to track a "previous cumulative
 *    counter" per app the way a TrafficStats-based approach would.
 *  - Live per-tick readings are batched in memory and flushed to Room every [FLUSH_INTERVAL_MS]
 *    (not once per tick) to keep disk I/O - and battery draw - low even at a 1-second interval.
 */
@AndroidEntryPoint
class NetworkMonitorService : Service() {

    @Inject lateinit var trafficStatsSampler: TrafficStatsSampler
    @Inject lateinit var networkStatsProvider: NetworkStatsProvider
    @Inject lateinit var appIconCache: AppIconCache
    @Inject lateinit var foregroundAppTracker: ForegroundAppTracker
    @Inject lateinit var networkInfoProvider: NetworkInfoProvider
    @Inject lateinit var liveMonitorState: LiveMonitorState
    @Inject lateinit var networkUsageDao: NetworkUsageDao
    @Inject lateinit var settingsRepository: SettingsRepository
    @Inject lateinit var dataCapEnforcer: DataCapEnforcer

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitorJob: Job? = null
    private var settingsJob: Job? = null
    private var purgeJob: Job? = null

    @Volatile private var refreshIntervalSeconds: Int = 2

    private var lastDeviceCounters: ByteCounters? = null
    private var lastTickAt: Long = 0L

    private val lastActiveAtMillis = mutableMapOf<String, Long>()
    private val sessionRxBytes = mutableMapOf<String, Long>()
    private val sessionTxBytes = mutableMapOf<String, Long>()
    private val recentSpeedSamples = mutableMapOf<String, ArrayDeque<Float>>()

    private val pendingDeltas = mutableMapOf<PendingKey, PendingAccumulator>()
    private var lastFlushAt: Long = 0L
    private var lastNotificationUpdateAt: Long = 0L

    @Volatile private var lastKnownDownloadBps: Long = 0
    @Volatile private var lastKnownUploadBps: Long = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification(0, 0))
        liveMonitorState.setServiceRunning(true)
        liveMonitorState.markSessionStart()

        settingsJob = serviceScope.launch {
            settingsRepository.settings.collect { settings ->
                refreshIntervalSeconds = settings.refreshIntervalSeconds.coerceIn(1, 10)
            }
        }
        purgeJob = serviceScope.launch {
            networkUsageDao.deleteOlderThan(System.currentTimeMillis() - RETENTION_MS)
        }
        startMonitoring()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        monitorJob?.cancel()
        settingsJob?.cancel()
        purgeJob?.cancel()
        // Deliberately blocking: launching this in serviceScope and then cancelling that same
        // scope right after was a real bug - cancel() can tear down a just-launched coroutine
        // before it runs, silently dropping the last flush interval's worth of usage data
        // every time the service stopped. This flush is small (an in-memory map -> one batch
        // insert), so a brief synchronous wait here is the safer tradeoff.
        kotlinx.coroutines.runBlocking { flushPendingDeltas() }
        serviceScope.cancel()
        liveMonitorState.setServiceRunning(false)
        super.onDestroy()
    }

    private fun startMonitoring() {
        monitorJob = serviceScope.launch {
            while (isActive) {
                runCatching { tick() }
                delay(refreshIntervalSeconds * 1000L)
            }
        }
    }

    private suspend fun tick() {
        val now = System.currentTimeMillis()
        val elapsedSeconds = if (lastTickAt == 0L) 0.0 else (now - lastTickAt) / 1000.0
        // On the very first tick there's no prior timestamp to window from; look back one
        // second so the first reading isn't a guaranteed zero-width (and therefore empty) query.
        val windowStart = if (lastTickAt == 0L) now - 1_000L else lastTickAt
        lastTickAt = now

        publishDeviceStatus(now, elapsedSeconds)

        val foregroundPackage = foregroundAppTracker.refreshAndGetForegroundPackage()
        val transport = currentTransport()
        val uidDeltas = withContext(Dispatchers.IO) {
            networkStatsProvider.queryUidDeltas(windowStart, now)
        }
        val tickSeconds = ((now - windowStart) / 1000.0).coerceAtLeast(0.001)
        val liveUsages = mutableListOf<LiveAppUsage>()

        for ((uid, delta) in uidDeltas) {
            // UIDs below this threshold are native system services (radio, wifi, dns, ...),
            // not installed apps - not useful to surface in a per-app breakdown.
            if (uid < Process.FIRST_APPLICATION_UID) continue
            val rxDelta = delta.rxBytes.coerceAtLeast(0L)
            val txDelta = delta.txBytes.coerceAtLeast(0L)
            if (rxDelta == 0L && txDelta == 0L) continue

            val app = withContext(Dispatchers.IO) { appIconCache.getByUid(uid) } ?: continue
            val isForeground = app.packageName == foregroundPackage

            lastActiveAtMillis[app.packageName] = now
            sessionRxBytes[app.packageName] = (sessionRxBytes[app.packageName] ?: 0L) + rxDelta
            sessionTxBytes[app.packageName] = (sessionTxBytes[app.packageName] ?: 0L) + txDelta
            accumulate(app, rxDelta, txDelta, transport, isForeground)

            val downloadBps = (rxDelta / tickSeconds).toLong()
            val uploadBps = (txDelta / tickSeconds).toLong()
            val samples = recentSpeedSamples.getOrPut(app.packageName) { ArrayDeque() }
            samples.addLast((downloadBps + uploadBps).toFloat())
            while (samples.size > MAX_SAMPLES) samples.removeFirst()

            val state = when {
                rxDelta > 0 && txDelta > 0 -> ActivityState.BOTH
                rxDelta > 0 -> ActivityState.RECEIVING
                txDelta > 0 -> ActivityState.UPLOADING
                else -> ActivityState.IDLE
            }

            liveUsages += LiveAppUsage(
                appInfo = app,
                downloadBps = downloadBps,
                uploadBps = uploadBps,
                sessionRxBytes = sessionRxBytes[app.packageName] ?: 0L,
                sessionTxBytes = sessionTxBytes[app.packageName] ?: 0L,
                isForeground = isForeground,
                activityState = state,
                recentSamples = samples.toList()
            )
        }

        // Apps that had traffic recently but not this exact tick still get a short grace period
        // in the list (per the "fade out after several seconds" behavior), even though this
        // tick's uidDeltas had nothing for them.
        for ((packageName, lastActive) in lastActiveAtMillis) {
            if (liveUsages.any { it.appInfo.packageName == packageName }) continue
            if (now - lastActive > ACTIVE_GRACE_PERIOD_MS) continue
            val app = appIconCache.get(packageName)
            liveUsages += LiveAppUsage(
                appInfo = app,
                downloadBps = 0,
                uploadBps = 0,
                sessionRxBytes = sessionRxBytes[packageName] ?: 0L,
                sessionTxBytes = sessionTxBytes[packageName] ?: 0L,
                isForeground = packageName == foregroundPackage,
                activityState = ActivityState.IDLE,
                recentSamples = recentSpeedSamples[packageName]?.toList() ?: emptyList()
            )
        }

        liveMonitorState.publishLiveAppUsages(
            liveUsages.sortedByDescending { it.downloadBps + it.uploadBps }
        )

        maybeFlush(now)
        maybeUpdateNotification(now)
    }

    private fun publishDeviceStatus(now: Long, elapsedSeconds: Double) {
        val deviceCounters = trafficStatsSampler.sampleDeviceTotal()
        val previous = lastDeviceCounters
        lastDeviceCounters = deviceCounters

        val downloadBps: Long
        val uploadBps: Long
        if (previous != null && elapsedSeconds > 0) {
            val rxDelta = (deviceCounters.rxBytes - previous.rxBytes).coerceAtLeast(0)
            val txDelta = (deviceCounters.txBytes - previous.txBytes).coerceAtLeast(0)
            downloadBps = (rxDelta / elapsedSeconds).toLong()
            uploadBps = (txDelta / elapsedSeconds).toLong()
        } else {
            downloadBps = 0L
            uploadBps = 0L
        }

        liveMonitorState.publishDeviceStatus(
            DeviceNetworkStatus(
                isConnected = networkInfoProvider.isConnected(),
                networkType = networkInfoProvider.currentNetworkType(),
                downloadBps = downloadBps,
                uploadBps = uploadBps,
                ipAddress = networkInfoProvider.currentIpAddress(),
                signalStrengthPercent = networkInfoProvider.currentSignalStrengthPercent()
            )
        )
        lastKnownDownloadBps = downloadBps
        lastKnownUploadBps = uploadBps
    }

    private fun currentTransport(): PersistedTransport = when (networkInfoProvider.currentNetworkType()) {
        NetworkType.WIFI -> PersistedTransport.WIFI
        NetworkType.CELLULAR_5G, NetworkType.CELLULAR_LTE, NetworkType.CELLULAR_OTHER -> PersistedTransport.MOBILE
        else -> PersistedTransport.OTHER
    }

    private fun accumulate(
        app: AppInfo,
        rxDelta: Long,
        txDelta: Long,
        transport: PersistedTransport,
        isForeground: Boolean
    ) {
        val key = PendingKey(app.packageName, app.uid, transport, isForeground)
        val acc = pendingDeltas.getOrPut(key) { PendingAccumulator() }
        acc.rx += rxDelta
        acc.tx += txDelta
    }

    private suspend fun maybeFlush(now: Long) {
        if (now - lastFlushAt < FLUSH_INTERVAL_MS) return
        flushPendingDeltas()
        pruneStaleTrackingState(now)
        runCatching { dataCapEnforcer.checkAndEnforce() }
        lastFlushAt = now
    }

    /** Keeps [lastActiveAtMillis] and friends from growing unbounded over a long service run. */
    private fun pruneStaleTrackingState(now: Long) {
        val stale = lastActiveAtMillis.filterValues { now - it > STALE_TRACKING_MS }.keys
        stale.forEach { packageName ->
            lastActiveAtMillis.remove(packageName)
            recentSpeedSamples.remove(packageName)
            // Session totals intentionally survive here - "session" spans the whole service
            // run, not just recent activity, so a temporarily-quiet app shouldn't lose its
            // accumulated session bytes just because it fell out of the active list.
        }
    }

    private suspend fun flushPendingDeltas() {
        if (pendingDeltas.isEmpty()) return
        val timestamp = System.currentTimeMillis()
        val rows = pendingDeltas.map { (key, acc) ->
            NetworkUsageSnapshot(
                timestamp = timestamp,
                packageName = key.packageName,
                uid = key.uid,
                rxBytesDelta = acc.rx,
                txBytesDelta = acc.tx,
                transport = key.transport,
                isForeground = key.isForeground
            )
        }
        networkUsageDao.insertAll(rows)
        pendingDeltas.clear()
    }

    private fun maybeUpdateNotification(now: Long) {
        if (now - lastNotificationUpdateAt < NOTIFICATION_UPDATE_INTERVAL_MS) return
        lastNotificationUpdateAt = now
        val manager = ContextCompat.getSystemService(this, android.app.NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(lastKnownDownloadBps, lastKnownUploadBps))
    }

    private fun buildNotification(downloadBps: Long, uploadBps: Long): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val speedText = "\u2193 ${ByteFormatter.formatBytes(downloadBps)}/s   " +
            "\u2191 ${ByteFormatter.formatBytes(uploadBps)}/s"
        return NotificationCompat.Builder(this, NetGuardianApplication.MONITOR_CHANNEL_ID)
            .setContentTitle(getString(R.string.monitor_notification_title))
            .setContentText(speedText)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent)
            .build()
    }

    private data class PendingKey(
        val packageName: String,
        val uid: Int,
        val transport: PersistedTransport,
        val isForeground: Boolean
    )

    private data class PendingAccumulator(var rx: Long = 0L, var tx: Long = 0L)

    companion object {
        private const val NOTIFICATION_ID = 42
        private const val FLUSH_INTERVAL_MS = 30_000L
        private const val NOTIFICATION_UPDATE_INTERVAL_MS = 5_000L
        private const val ACTIVE_GRACE_PERIOD_MS = 6_000L
        private const val STALE_TRACKING_MS = 60 * 60 * 1000L
        private const val RETENTION_MS = 90L * 24 * 60 * 60 * 1000
        private const val MAX_SAMPLES = 30

        fun start(context: Context) {
            val intent = Intent(context, NetworkMonitorService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, NetworkMonitorService::class.java))
        }
    }
}
