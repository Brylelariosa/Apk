package com.netguardian.app.data.local

import androidx.room.TypeConverter
import com.netguardian.app.data.local.entity.PersistedTransport

class Converters {
    @TypeConverter
    fun fromTransport(value: PersistedTransport): String = value.name

    @TypeConverter
    fun toTransport(value: String): PersistedTransport =
        runCatching { PersistedTransport.valueOf(value) }.getOrDefault(PersistedTransport.OTHER)

    // Package names never contain commas, so a simple join/split is safe and avoids pulling in
    // a JSON serialization library just to persist two small sets on one entity.
    @TypeConverter
    fun fromStringSet(value: Set<String>): String = value.joinToString(",")

    @TypeConverter
    fun toStringSet(value: String): Set<String> =
        if (value.isBlank()) emptySet() else value.split(",").toSet()

    @TypeConverter
    fun fromIntSet(value: Set<Int>): String = value.joinToString(",")

    @TypeConverter
    fun toIntSet(value: String): Set<Int> =
        if (value.isBlank()) emptySet() else value.split(",").mapNotNull { it.toIntOrNull() }.toSet()
}
