package com.netguardian.app.data.local

import androidx.room.TypeConverter
import com.netguardian.app.data.local.entity.PersistedTransport

class Converters {
    @TypeConverter
    fun fromTransport(value: PersistedTransport): String = value.name

    @TypeConverter
    fun toTransport(value: String): PersistedTransport =
        runCatching { PersistedTransport.valueOf(value) }.getOrDefault(PersistedTransport.OTHER)
}
