package com.netguardian.app.ui.onboarding

import android.app.Activity
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DataUsage
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.netguardian.app.data.util.PermissionUtils
import com.netguardian.app.service.FirewallVpnService
import com.netguardian.app.ui.theme.ActiveGreen

private data class OnboardingStep(
    val icon: ImageVector,
    val title: String,
    val description: String
)

private val STEPS = listOf(
    OnboardingStep(
        icon = Icons.Filled.DataUsage,
        title = "Usage Access",
        description = "Lets NetGuardian tell which app is in the foreground and build accurate " +
            "per-app history. Without it, active-app detection and history stay empty."
    ),
    OnboardingStep(
        icon = Icons.Filled.Notifications,
        title = "Notifications",
        description = "Shows a persistent status while monitoring or blocking is running, so " +
            "you always know it's active in the background."
    ),
    OnboardingStep(
        icon = Icons.Filled.Security,
        title = "VPN Permission",
        description = "Needed only if you want to block apps from the internet. NetGuardian " +
            "uses a local VPN tunnel that never leaves your device - no traffic is sent anywhere " +
            "external. You can set this up later instead if you'd rather skip it for now."
    )
)

@Composable
fun OnboardingScreen(
    onFinished: () -> Unit,
    viewModel: OnboardingViewModel = hiltViewModel()
) {
    var stepIndex by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasUsageAccess by remember { mutableStateOf(PermissionUtils.hasUsageAccess(context)) }
    var hasNotificationPermission by remember { mutableStateOf(PermissionUtils.hasNotificationPermission(context)) }
    var hasVpnConsent by remember { mutableStateOf(FirewallVpnService.prepareIntent(context) == null) }

    // Re-check permissions whenever the user comes back from system Settings or a system
    // dialog, so each step reflects reality immediately rather than only on next launch.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasUsageAccess = PermissionUtils.hasUsageAccess(context)
                hasNotificationPermission = PermissionUtils.hasNotificationPermission(context)
                hasVpnConsent = FirewallVpnService.prepareIntent(context) == null
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasNotificationPermission = granted }

    val vpnLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result -> hasVpnConsent = result.resultCode == Activity.RESULT_OK }

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(32.dp))
            StepDots(total = STEPS.size, current = stepIndex)
            Spacer(modifier = Modifier.height(32.dp))

            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                AnimatedContent(
                    targetState = stepIndex,
                    transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(250)) },
                    label = "onboardingStep"
                ) { index ->
                    val step = STEPS[index]
                    val granted = when (index) {
                        0 -> hasUsageAccess
                        1 -> hasNotificationPermission
                        else -> hasVpnConsent
                    }
                    StepContent(step = step, granted = granted)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            val isLastStep = stepIndex == STEPS.lastIndex
            Button(
                onClick = {
                    when (stepIndex) {
                        0 -> context.startActivity(PermissionUtils.usageAccessSettingsIntent())
                        1 -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            notificationLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                        2 -> FirewallVpnService.prepareIntent(context)?.let { vpnLauncher.launch(it) }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors()
            ) {
                Text(
                    when (stepIndex) {
                        0 -> "Open Settings"
                        1 -> "Allow Notifications"
                        else -> "Set Up VPN"
                    }
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            TextButton(
                onClick = {
                    if (isLastStep) {
                        viewModel.completeOnboarding(onFinished)
                    } else {
                        stepIndex += 1
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isLastStep) "Get Started" else "Skip for now")
            }
        }
    }
}

@Composable
private fun StepDots(total: Int, current: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        repeat(total) { index ->
            val color = if (index == current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
            Box(
                modifier = Modifier
                    .size(if (index == current) 10.dp else 8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
        }
    }
}

@Composable
private fun StepContent(step: OnboardingStep, granted: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(
            imageVector = step.icon,
            contentDescription = null,
            modifier = Modifier.size(72.dp),
            tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.height(24.dp))
        Text(text = step.title, style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = step.description,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(20.dp))
        if (granted) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = ActiveGreen)
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "Granted", color = ActiveGreen, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}
