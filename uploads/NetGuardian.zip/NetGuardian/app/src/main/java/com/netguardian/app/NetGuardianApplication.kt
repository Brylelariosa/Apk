package com.netguardian.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import dagger.hilt.android.HiltAndroidApp

/**
 * Application entry point. Hilt generates the top-level dependency graph from
 * this class, and it is also a convenient place to register the notification
 * channels used by [com.netguardian.app.service.NetworkMonitorService] and
 * [com.netguardian.app.service.FirewallVpnService], since channels must exist
 * before any notification referencing them is posted.
 */
@HiltAndroidApp
class NetGuardianApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        registerNotificationChannels()
    }

    private fun registerNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val monitorChannel = NotificationChannel(
            MONITOR_CHANNEL_ID,
            getString(R.string.monitor_notification_channel),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Persistent status while NetGuardian tracks live bandwidth"
            setShowBadge(false)
        }

        val firewallChannel = NotificationChannel(
            FIREWALL_CHANNEL_ID,
            "Firewall",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Persistent status while NetGuardian is blocking apps from the network"
            setShowBadge(false)
        }

        manager.createNotificationChannels(listOf(monitorChannel, firewallChannel))
    }

    companion object {
        const val MONITOR_CHANNEL_ID = "netguardian_monitor_channel"
        const val FIREWALL_CHANNEL_ID = "netguardian_firewall_channel"
    }
}
