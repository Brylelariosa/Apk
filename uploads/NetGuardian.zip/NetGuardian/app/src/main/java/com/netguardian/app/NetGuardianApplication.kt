package com.netguardian.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import dagger.hilt.android.HiltAndroidApp

/**
 * Application entry point. Hilt generates the top-level dependency graph from
 * this class, and it is also a convenient place to register the notification
 * channel used by [com.netguardian.app.service.NetworkMonitorService] since
 * channels must exist before any notification referencing them is posted.
 */
@HiltAndroidApp
class NetGuardianApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        registerMonitoringNotificationChannel()
    }

    private fun registerMonitoringNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            MONITOR_CHANNEL_ID,
            getString(R.string.monitor_notification_channel),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Persistent status while NetGuardian tracks live bandwidth"
            setShowBadge(false)
        }
        manager.createNotificationChannel(channel)
    }

    companion object {
        const val MONITOR_CHANNEL_ID = "netguardian_monitor_channel"
    }
}
