package com.netguardian.app.ui.appdetail

import com.netguardian.app.data.model.AppInfo
import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.model.UsageBucket

data class AppDetailUiState(
    val appInfo: AppInfo? = null,
    val isCurrentlyActive: Boolean = false,
    val currentDownloadBps: Long = 0,
    val currentUploadBps: Long = 0,
    val historyRange: HistoryRange = HistoryRange.DAILY,
    val historyBuckets: List<UsageBucket> = emptyList(),
    val foregroundBytes: Long = 0,
    val backgroundBytes: Long = 0,
    val lastActiveAt: Long = 0,
    val networkingPermissions: List<String> = emptyList(),
    val dataUnit: DataUnit = DataUnit.MBPS_BYTES,
    val isLoading: Boolean = true
)
