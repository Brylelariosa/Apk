package com.netguardian.app.ui.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.datastore.AppSettings
import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.model.ThemeMode
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.StatisticsExporter
import com.netguardian.app.service.NetworkMonitorService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: android.content.Context,
    private val settingsRepository: SettingsRepository,
    private val appUsageRepository: AppUsageRepository,
    private val statisticsExporter: StatisticsExporter
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun setThemeMode(mode: ThemeMode) = viewModelScope.launch { settingsRepository.setThemeMode(mode) }

    fun setRefreshInterval(seconds: Int) = viewModelScope.launch { settingsRepository.setRefreshInterval(seconds) }

    fun setDataUnit(unit: DataUnit) = viewModelScope.launch { settingsRepository.setDataUnit(unit) }

    fun setAnimationsEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setAnimationsEnabled(enabled) }

    fun setLiveGraphEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setLiveGraphEnabled(enabled) }

    fun setStartOnBoot(enabled: Boolean) = viewModelScope.launch { settingsRepository.setStartOnBoot(enabled) }

    fun stopMonitoring() = NetworkMonitorService.stop(context)

    fun startMonitoring() = NetworkMonitorService.start(context)

    suspend fun exportStatistics(): Uri {
        val aggregates = appUsageRepository.getAllAggregatesOnce()
        return statisticsExporter.exportToCsv(aggregates)
    }
}
