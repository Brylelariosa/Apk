package com.netguardian.app.ui.dashboard

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.datastore.AppSettings
import com.netguardian.app.data.model.DeviceNetworkStatus
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.model.TotalUsage
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.NetworkStatusRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.PermissionUtils
import com.netguardian.app.service.FirewallVpnService
import com.netguardian.app.service.NetworkMonitorService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val MAX_HISTORY_POINTS = 60

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class DashboardViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val networkStatusRepository: NetworkStatusRepository,
    private val appUsageRepository: AppUsageRepository,
    private val settingsRepository: SettingsRepository,
    private val firewallRepository: FirewallRepository
) : ViewModel() {

    private val downloadHistory = mutableListOf<Float>()
    private val uploadHistory = mutableListOf<Float>()
    private val historyTick = MutableStateFlow(0)

    private val sessionTotalFlow = networkStatusRepository.sessionStartMillis
        .flatMapLatest { start -> appUsageRepository.observeSessionTotal(start) }

    val uiState: StateFlow<DashboardUiState> = combine(
        networkStatusRepository.deviceStatus,
        appUsageRepository.liveAppUsages,
        appUsageRepository.observeTodayTotal(),
        appUsageRepository.observeCurrentHourTotal(),
        sessionTotalFlow,
        settingsRepository.settings,
        networkStatusRepository.isMonitoringActive,
        historyTick
    ) { values ->
        val deviceStatus = values[0] as DeviceNetworkStatus
        @Suppress("UNCHECKED_CAST")
        val liveUsages = values[1] as List<LiveAppUsage>
        val todayTotal = values[2] as TotalUsage
        val hourTotal = values[3] as TotalUsage
        val sessionTotal = values[4] as TotalUsage
        val settings = values[5] as AppSettings
        val monitoringActive = values[6] as Boolean

        DashboardUiState(
            deviceStatus = deviceStatus,
            liveAppUsages = liveUsages,
            todayTotal = todayTotal,
            currentHourTotal = hourTotal,
            sessionTotal = sessionTotal,
            dataUnit = settings.dataUnit,
            liveGraphEnabled = settings.liveGraphEnabled,
            isMonitoringActive = monitoringActive,
            hasUsageAccess = PermissionUtils.hasUsageAccess(context),
            downloadHistory = downloadHistory.toList(),
            uploadHistory = uploadHistory.toList(),
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    init {
        viewModelScope.launch {
            networkStatusRepository.deviceStatus.collect { status ->
                downloadHistory.add(status.downloadBps.toFloat())
                if (downloadHistory.size > MAX_HISTORY_POINTS) downloadHistory.removeAt(0)
                uploadHistory.add(status.uploadBps.toFloat())
                if (uploadHistory.size > MAX_HISTORY_POINTS) uploadHistory.removeAt(0)
                historyTick.value += 1
            }
        }
        if (PermissionUtils.hasUsageAccess(context)) {
            NetworkMonitorService.start(context)
        }
        resumeFirewallIfPreviouslyConfigured()
    }

    /** If the user had already blocked apps and already granted VPN consent in a past session,
     *  resume the firewall silently - otherwise leave it off until the user re-toggles a block,
     *  since we can't show the VPN consent dialog without an Activity in the loop. */
    private fun resumeFirewallIfPreviouslyConfigured() {
        viewModelScope.launch {
            val alreadyConsented = FirewallVpnService.prepareIntent(context) == null
            val hasBlockedApps = firewallRepository.settings.first().blockedPackages.isNotEmpty()
            if (alreadyConsented && hasBlockedApps) {
                FirewallVpnService.start(context)
            }
        }
    }

    fun startMonitoring() = NetworkMonitorService.start(context)

    /** Live values are push-driven already; refresh mainly re-checks the Usage Access gate so
     *  the UI updates immediately after the user grants it in Settings and returns to the app. */
    fun refresh() {
        historyTick.value += 1
    }
}
