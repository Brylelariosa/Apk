package com.netguardian.app.ui.firewall

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.netguardian.app.data.model.FirewallMode
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.ui.settings.SettingsViewModel
import com.netguardian.app.ui.theme.ActiveGreen
import com.netguardian.app.ui.theme.CardCornerRadius

/** Reuses [SettingsViewModel] rather than a dedicated ViewModel - this screen is a focused view
 *  onto the same firewall/data-cap state Settings already exposes, not a separate concern. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirewallScreen(
    onBack: () -> Unit,
    onManageSchedules: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val firewallSettings by viewModel.firewallSettings.collectAsStateWithLifecycle()
    val dataCapSettings by viewModel.dataCapSettings.collectAsStateWithLifecycle()
    val firewallError by viewModel.firewallLastError.collectAsStateWithLifecycle()
    val isVpnActive by viewModel.isVpnActive.collectAsStateWithLifecycle()
    val activeCount = firewallSettings.activePackages.size

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Firewall") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            item {
                FirewallStatusCard(isVpnActive = isVpnActive, activeCount = activeCount, mode = firewallSettings.mode)
            }

            item {
                FirewallSection(title = "Mode") {
                    FirewallModeRow(current = firewallSettings.mode, onSelect = viewModel::setFirewallMode)
                    if (firewallSettings.mode == FirewallMode.ALLOWLIST) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Only apps you explicitly allow will have internet access - " +
                                "everything else on the device is blocked, including system apps " +
                                "like Google Play Services unless you allow them too. Add apps " +
                                "from the Apps list.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            item {
                FirewallSection(title = "Status") {
                    Text(
                        text = when {
                            activeCount == 0 && firewallSettings.mode == FirewallMode.BLOCKLIST ->
                                "No apps are currently blocked."
                            activeCount == 0 ->
                                "No apps are allowed yet - the firewall isn't active until you add one."
                            firewallSettings.mode == FirewallMode.BLOCKLIST ->
                                "Blocking internet access for $activeCount app" + if (activeCount == 1) "." else "s."
                            else ->
                                "$activeCount app" + (if (activeCount == 1) " is" else "s are") + " allowed online."
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text(
                        text = "Manage apps from the Apps list or an app's own detail screen.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (firewallError != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = firewallError.orEmpty(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row {
                        TextButton(onClick = onManageSchedules) { Text("Manage schedules") }
                        if (activeCount > 0) {
                            TextButton(onClick = { viewModel.stopFirewall() }) { Text("Turn off firewall") }
                        }
                    }
                }
            }

            item {
                FirewallSection(title = "Data caps") {
                    GlobalCapRow(
                        currentCapBytes = dataCapSettings.globalDailyCapBytes,
                        onSetCap = viewModel::setGlobalDataCap
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Per-app caps (which block that app automatically) are set from " +
                            "the app's own detail screen.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun FirewallStatusCard(isVpnActive: Boolean, activeCount: Int, mode: FirewallMode) {
    val (dotColor, statusText) = when {
        isVpnActive -> ActiveGreen to "Active"
        activeCount > 0 -> MaterialTheme.colorScheme.error to "Not active - this shouldn't happen with apps configured; see Status below"
        else -> MaterialTheme.colorScheme.onSurfaceVariant to "Not active"
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .clip(CircleShape)
                    .background(dotColor)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = "Firewall: $statusText", style = MaterialTheme.typography.titleSmall)
                Text(
                    text = mode.label,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun FirewallSection(title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Column {
        com.netguardian.app.ui.components.SectionHeader(title = title)
        Spacer(modifier = Modifier.height(10.dp))
        Card(
            shape = RoundedCornerShape(CardCornerRadius),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
        ) {
            Column(modifier = Modifier.padding(16.dp), content = content)
        }
    }
}

@Composable
private fun FirewallModeRow(current: FirewallMode, onSelect: (FirewallMode) -> Unit) {
    FirewallMode.values().forEach { mode ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = mode.label, style = MaterialTheme.typography.bodyMedium)
            RadioButton(selected = mode == current, onClick = { onSelect(mode) })
        }
    }
}

@Composable
private fun GlobalCapRow(currentCapBytes: Long?, onSetCap: (Long?) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(text = "Daily device cap", style = MaterialTheme.typography.bodyMedium)
            Text(
                text = if (currentCapBytes == null) {
                    "Not set - you'll get a notification if you set one and reach it"
                } else {
                    "${ByteFormatter.formatBytes(currentCapBytes)} per day \u2022 notifies, doesn't block"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        TextButton(onClick = { showDialog = true }) {
            Text(if (currentCapBytes == null) "Set" else "Change")
        }
    }

    if (showDialog) {
        var megabytesText by remember {
            mutableStateOf(currentCapBytes?.let { (it / (1024 * 1024)).toString() } ?: "")
        }
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Daily device cap") },
            text = {
                Column {
                    Text(
                        text = "You'll get a one-time notification each day this is reached. " +
                            "This never blocks anything automatically - only per-app caps do that.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = megabytesText,
                        onValueChange = { input -> megabytesText = input.filter { it.isDigit() } },
                        label = { Text("Megabytes per day") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val megabytes = megabytesText.toLongOrNull()
                    onSetCap(if (megabytes == null || megabytes <= 0) null else megabytes * 1024 * 1024)
                    showDialog = false
                }) { Text("Save") }
            },
            dismissButton = {
                if (currentCapBytes != null) {
                    TextButton(onClick = { onSetCap(null); showDialog = false }) { Text("Remove") }
                } else {
                    TextButton(onClick = { showDialog = false }) { Text("Cancel") }
                }
            }
        )
    }
}
