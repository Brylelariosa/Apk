package com.netguardian.app.data.repository

import com.netguardian.app.data.datastore.AppSettings
import com.netguardian.app.data.datastore.SettingsDataStore
import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

interface SettingsRepository {
    val settings: Flow<AppSettings>
    suspend fun setThemeMode(mode: ThemeMode)
    suspend fun setRefreshInterval(seconds: Int)
    suspend fun setDataUnit(unit: DataUnit)
    suspend fun setAnimationsEnabled(enabled: Boolean)
    suspend fun setLiveGraphEnabled(enabled: Boolean)
    suspend fun setStartOnBoot(enabled: Boolean)
}

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    private val dataStore: SettingsDataStore
) : SettingsRepository {
    override val settings: Flow<AppSettings> = dataStore.settings
    override suspend fun setThemeMode(mode: ThemeMode) = dataStore.setThemeMode(mode)
    override suspend fun setRefreshInterval(seconds: Int) = dataStore.setRefreshInterval(seconds)
    override suspend fun setDataUnit(unit: DataUnit) = dataStore.setDataUnit(unit)
    override suspend fun setAnimationsEnabled(enabled: Boolean) = dataStore.setAnimationsEnabled(enabled)
    override suspend fun setLiveGraphEnabled(enabled: Boolean) = dataStore.setLiveGraphEnabled(enabled)
    override suspend fun setStartOnBoot(enabled: Boolean) = dataStore.setStartOnBoot(enabled)
}
