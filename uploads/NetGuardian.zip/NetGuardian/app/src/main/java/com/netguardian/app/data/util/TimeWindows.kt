package com.netguardian.app.data.util

import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters

/** Local-time window boundaries used throughout the app's aggregation queries. */
object TimeWindows {

    private fun zone(): ZoneId = ZoneId.systemDefault()

    fun startOfCurrentHourMillis(now: Long = System.currentTimeMillis()): Long {
        val instant = Instant.ofEpochMilli(now)
        val truncated = instant.atZone(zone()).withMinute(0).withSecond(0).withNano(0)
        return truncated.toInstant().toEpochMilli()
    }

    fun startOfTodayMillis(now: Long = System.currentTimeMillis()): Long {
        val date = LocalDate.now(zone())
        return date.atStartOfDay(zone()).toInstant().toEpochMilli()
    }

    fun startOfWeekMillis(now: Long = System.currentTimeMillis()): Long {
        val date = LocalDate.now(zone()).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        return date.atStartOfDay(zone()).toInstant().toEpochMilli()
    }

    fun startOfMonthMillis(now: Long = System.currentTimeMillis()): Long {
        val date = LocalDate.now(zone()).withDayOfMonth(1)
        return date.atStartOfDay(zone()).toInstant().toEpochMilli()
    }

    /** Bounds for "last N days", inclusive of today, for rolling history charts. */
    fun startOfLastNDaysMillis(days: Int): Long {
        val date = LocalDate.now(zone()).minusDays((days - 1).toLong())
        return date.atStartOfDay(zone()).toInstant().toEpochMilli()
    }
}
