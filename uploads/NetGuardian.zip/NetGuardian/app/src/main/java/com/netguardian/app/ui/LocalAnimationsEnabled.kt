package com.netguardian.app.ui

import androidx.compose.runtime.compositionLocalOf

/**
 * Defaults to `true` so anything that reads this outside of [MainActivity]'s tree (e.g. a
 * preview) still animates normally; the real value is provided once, near the root, from the
 * persisted Settings > "Enable animations" preference.
 */
val LocalAnimationsEnabled = compositionLocalOf { true }
