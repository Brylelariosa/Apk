package com.netguardian.app.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.AppIconCache
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val TOP_APPS_LIMIT = 5

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val appUsageRepository: AppUsageRepository,
    private val settingsRepository: SettingsRepository,
    private val appIconCache: AppIconCache
) : ViewModel() {

    private val range = MutableStateFlow(HistoryRange.DAILY)
    private val topDownloaders = MutableStateFlow(emptyList<TopAppUiModel>())
    private val topUploaders = MutableStateFlow(emptyList<TopAppUiModel>())

    private val bucketsFlow = range.flatMapLatest { appUsageRepository.observeHistoryBuckets(it) }

    val uiState: StateFlow<HistoryUiState> = combine(
        range,
        bucketsFlow,
        topDownloaders,
        topUploaders,
        settingsRepository.settings
    ) { currentRange, buckets, downloaders, uploaders, settings ->
        HistoryUiState(
            range = currentRange,
            buckets = buckets,
            topDownloaders = downloaders,
            topUploaders = uploaders,
            dataUnit = settings.dataUnit,
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HistoryUiState())

    init {
        viewModelScope.launch {
            range.collect { loadTopApps(it) }
        }
    }

    fun onRangeChanged(newRange: HistoryRange) {
        range.value = newRange
    }

    private suspend fun loadTopApps(currentRange: HistoryRange) {
        val downloaders = appUsageRepository.getTopDownloaders(currentRange, TOP_APPS_LIMIT)
        val uploaders = appUsageRepository.getTopUploaders(currentRange, TOP_APPS_LIMIT)
        topDownloaders.value = downloaders.map {
            TopAppUiModel(appIconCache.get(it.packageName, 0), it.wifiRxBytes + it.mobileRxBytes)
        }
        topUploaders.value = uploaders.map {
            TopAppUiModel(appIconCache.get(it.packageName, 0), it.wifiTxBytes + it.mobileTxBytes)
        }
    }
}
