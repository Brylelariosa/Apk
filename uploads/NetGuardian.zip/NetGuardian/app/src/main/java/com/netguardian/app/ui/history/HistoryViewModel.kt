package com.netguardian.app.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.model.TransportFilter
import com.netguardian.app.data.model.UsageBucket
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.AppIconCache
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val TOP_APPS_LIMIT = 5

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val appUsageRepository: AppUsageRepository,
    private val settingsRepository: SettingsRepository,
    private val appIconCache: AppIconCache
) : ViewModel() {

    private val range = MutableStateFlow(HistoryRange.DAILY)
    private val transportFilter = MutableStateFlow(TransportFilter.ALL)
    private val topDownloaders = MutableStateFlow(emptyList<TopAppUiModel>())
    private val topUploaders = MutableStateFlow(emptyList<TopAppUiModel>())

    private val rangeAndFilter = combine(range, transportFilter) { r, f -> r to f }

    private val bucketsFlow = rangeAndFilter.flatMapLatest { (r, f) -> appUsageRepository.observeHistoryBuckets(r, f) }

    val uiState: StateFlow<HistoryUiState> = combine(
        range,
        transportFilter,
        bucketsFlow,
        topDownloaders,
        topUploaders,
        settingsRepository.settings
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val buckets = values[2] as List<UsageBucket>
        HistoryUiState(
            range = values[0] as HistoryRange,
            transportFilter = values[1] as TransportFilter,
            buckets = buckets,
            totalRxBytes = buckets.sumOf { it.rxBytes },
            totalTxBytes = buckets.sumOf { it.txBytes },
            topDownloaders = values[3] as List<TopAppUiModel>,
            topUploaders = values[4] as List<TopAppUiModel>,
            dataUnit = (values[5] as com.netguardian.app.data.datastore.AppSettings).dataUnit,
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HistoryUiState())

    init {
        // Reload whenever EITHER the range or the transport filter changes - this used to only
        // react to range changes, so switching the Wi-Fi/Mobile/Other filter left Top
        // Downloaders/Uploaders showing stale all-transport data.
        viewModelScope.launch {
            rangeAndFilter.collect { (r, f) -> loadTopApps(r, f) }
        }
    }

    fun onRangeChanged(newRange: HistoryRange) {
        range.value = newRange
    }

    fun onTransportFilterChanged(filter: TransportFilter) {
        transportFilter.value = filter
    }

    private suspend fun loadTopApps(currentRange: HistoryRange, filter: TransportFilter) {
        val downloaders = appUsageRepository.getTopDownloaders(currentRange, TOP_APPS_LIMIT, filter)
        val uploaders = appUsageRepository.getTopUploaders(currentRange, TOP_APPS_LIMIT, filter)
        topDownloaders.value = downloaders.map {
            TopAppUiModel(appIconCache.get(it.packageName), it.wifiRxBytes + it.mobileRxBytes + it.otherRxBytes)
        }
        topUploaders.value = uploaders.map {
            TopAppUiModel(appIconCache.get(it.packageName), it.wifiTxBytes + it.mobileTxBytes + it.otherTxBytes)
        }
    }
}
