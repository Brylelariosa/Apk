package com.netguardian.app.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.model.TransportFilter
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.AppIconCache
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val TOP_APPS_LIMIT = 5

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val appUsageRepository: AppUsageRepository,
    private val settingsRepository: SettingsRepository,
    private val appIconCache: AppIconCache
) : ViewModel() {

    private val range = MutableStateFlow(HistoryRange.DAILY)
    private val transportFilter = MutableStateFlow(TransportFilter.ALL)
    private val topDownloaders = MutableStateFlow(emptyList<TopAppUiModel>())
    private val topUploaders = MutableStateFlow(emptyList<TopAppUiModel>())

    private val bucketsFlow = combine(range, transportFilter) { r, f -> r to f }
        .flatMapLatest { (r, f) -> appUsageRepository.observeHistoryBuckets(r, f) }

    val uiState: StateFlow<HistoryUiState> = combine(
        range,
        transportFilter,
        bucketsFlow,
        topDownloaders,
        topUploaders,
        settingsRepository.settings
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        HistoryUiState(
            range = values[0] as HistoryRange,
            transportFilter = values[1] as TransportFilter,
            buckets = values[2] as List<com.netguardian.app.data.model.UsageBucket>,
            topDownloaders = values[3] as List<TopAppUiModel>,
            topUploaders = values[4] as List<TopAppUiModel>,
            dataUnit = (values[5] as com.netguardian.app.data.datastore.AppSettings).dataUnit,
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HistoryUiState())

    init {
        viewModelScope.launch {
            range.collect { loadTopApps(it) }
        }
    }

    fun onRangeChanged(newRange: HistoryRange) {
        range.value = newRange
    }

    fun onTransportFilterChanged(filter: TransportFilter) {
        transportFilter.value = filter
    }

    private suspend fun loadTopApps(currentRange: HistoryRange) {
        val downloaders = appUsageRepository.getTopDownloaders(currentRange, TOP_APPS_LIMIT)
        val uploaders = appUsageRepository.getTopUploaders(currentRange, TOP_APPS_LIMIT)
        topDownloaders.value = downloaders.map {
            TopAppUiModel(appIconCache.get(it.packageName), it.wifiRxBytes + it.mobileRxBytes)
        }
        topUploaders.value = uploaders.map {
            TopAppUiModel(appIconCache.get(it.packageName), it.wifiTxBytes + it.mobileTxBytes)
        }
    }
}
