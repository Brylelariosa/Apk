package com.netguardian.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector

/** Every navigable route in the app, with a single source of truth for path building. */
sealed class Destination(val route: String) {
    data object Dashboard : Destination("dashboard")
    data object Apps : Destination("apps")
    data object History : Destination("history")
    data object Settings : Destination("settings")
    data object Firewall : Destination("firewall")
    data object Schedules : Destination("schedules")

    data object AppDetail : Destination("app_detail/{packageName}") {
        fun createRoute(packageName: String) = "app_detail/$packageName"
        const val ARG_PACKAGE_NAME = "packageName"
    }
}

data class BottomNavItem(
    val destination: Destination,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

val bottomNavItems = listOf(
    BottomNavItem(Destination.Dashboard, "Dashboard", Icons.Filled.Dashboard, Icons.Outlined.Dashboard),
    BottomNavItem(Destination.Apps, "Apps", Icons.Filled.Apps, Icons.Outlined.Apps),
    BottomNavItem(Destination.History, "History", Icons.Filled.History, Icons.Outlined.History),
    BottomNavItem(Destination.Settings, "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
)
