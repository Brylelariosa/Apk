package com.netguardian.app.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.firewallDataStore by preferencesDataStore(name = "netguardian_firewall")

/**
 * Persisted firewall configuration. There's deliberately no separate "firewall enabled" flag:
 * whether the tunnel should be up is entirely a function of whether anything is blocked, so
 * there's no state where those two facts could disagree with each other.
 */
data class FirewallSettings(val blockedPackages: Set<String> = emptySet())

@Singleton
class FirewallDataStore @Inject constructor(@ApplicationContext private val context: Context) {

    private object Keys {
        val BLOCKED_PACKAGES = stringSetPreferencesKey("blocked_packages")
    }

    val settings: Flow<FirewallSettings> = context.firewallDataStore.data.map { prefs ->
        FirewallSettings(blockedPackages = prefs[Keys.BLOCKED_PACKAGES] ?: emptySet())
    }

    suspend fun setBlocked(packageName: String, blocked: Boolean) {
        context.firewallDataStore.edit { prefs ->
            val current = prefs[Keys.BLOCKED_PACKAGES] ?: emptySet()
            prefs[Keys.BLOCKED_PACKAGES] = if (blocked) current + packageName else current - packageName
        }
    }

    suspend fun clearAllBlocked() {
        context.firewallDataStore.edit { prefs -> prefs[Keys.BLOCKED_PACKAGES] = emptySet() }
    }
}
