package com.netguardian.app.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.netguardian.app.data.model.FirewallMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.firewallDataStore by preferencesDataStore(name = "netguardian_firewall")

/**
 * Persisted firewall configuration. There's no separate "firewall enabled" flag: whether the
 * tunnel should be up is entirely a function of whether the *active* list for the current
 * [mode] is non-empty, so there's no state where those two facts could disagree with each
 * other. [blockedPackages] and [allowedPackages] are kept as two separate sets (rather than one
 * reused set whose meaning flips with the mode) so switching modes back and forth doesn't
 * discard whichever list isn't currently active.
 */
data class FirewallSettings(
    val mode: FirewallMode = FirewallMode.BLOCKLIST,
    val blockedPackages: Set<String> = emptySet(),
    val allowedPackages: Set<String> = emptySet()
) {
    /** The set actually enforced by the VPN tunnel right now, given the current mode. */
    val activePackages: Set<String> get() = if (mode == FirewallMode.BLOCKLIST) blockedPackages else allowedPackages

    /**
     * Whether a given app is currently cut off from the network. In Allowlist mode, an app only
     * counts as blocked once the allow-list actually has at least one entry - otherwise the
     * tunnel isn't running at all yet (mode picked but not configured), and showing every app
     * as "blocked" in that state would be actively misleading.
     */
    fun isAppBlocked(packageName: String): Boolean = when (mode) {
        FirewallMode.BLOCKLIST -> blockedPackages.contains(packageName)
        FirewallMode.ALLOWLIST -> allowedPackages.isNotEmpty() && !allowedPackages.contains(packageName)
    }
}

@Singleton
class FirewallDataStore @Inject constructor(@ApplicationContext private val context: Context) {

    private object Keys {
        val MODE = stringPreferencesKey("firewall_mode")
        val BLOCKED_PACKAGES = stringSetPreferencesKey("blocked_packages")
        val ALLOWED_PACKAGES = stringSetPreferencesKey("allowed_packages")
    }

    val settings: Flow<FirewallSettings> = context.firewallDataStore.data.map { prefs ->
        FirewallSettings(
            mode = prefs[Keys.MODE]?.let { runCatching { FirewallMode.valueOf(it) }.getOrNull() }
                ?: FirewallMode.BLOCKLIST,
            blockedPackages = prefs[Keys.BLOCKED_PACKAGES] ?: emptySet(),
            allowedPackages = prefs[Keys.ALLOWED_PACKAGES] ?: emptySet()
        )
    }

    suspend fun setMode(mode: FirewallMode) {
        context.firewallDataStore.edit { it[Keys.MODE] = mode.name }
    }

    suspend fun setBlocked(packageName: String, blocked: Boolean) {
        context.firewallDataStore.edit { prefs ->
            val current = prefs[Keys.BLOCKED_PACKAGES] ?: emptySet()
            prefs[Keys.BLOCKED_PACKAGES] = if (blocked) current + packageName else current - packageName
        }
    }

    /** Applies the same block/unblock change to many packages in a single DataStore edit,
     *  rather than one read-modify-write per package (which could race with itself under
     *  concurrent calls and is needlessly slow for a multi-select batch action). */
    suspend fun setBlockedMany(packageNames: Set<String>, blocked: Boolean) {
        context.firewallDataStore.edit { prefs ->
            val current = prefs[Keys.BLOCKED_PACKAGES] ?: emptySet()
            prefs[Keys.BLOCKED_PACKAGES] = if (blocked) current + packageNames else current - packageNames
        }
    }

    suspend fun setAllowed(packageName: String, allowed: Boolean) {
        context.firewallDataStore.edit { prefs ->
            val current = prefs[Keys.ALLOWED_PACKAGES] ?: emptySet()
            prefs[Keys.ALLOWED_PACKAGES] = if (allowed) current + packageName else current - packageName
        }
    }

    suspend fun setAllowedMany(packageNames: Set<String>, allowed: Boolean) {
        context.firewallDataStore.edit { prefs ->
            val current = prefs[Keys.ALLOWED_PACKAGES] ?: emptySet()
            prefs[Keys.ALLOWED_PACKAGES] = if (allowed) current + packageNames else current - packageNames
        }
    }

    /** Clears both lists and resets to Blocklist mode - a full, unambiguous "turn off firewall". */
    suspend fun disableFirewall() {
        context.firewallDataStore.edit { prefs ->
            prefs[Keys.BLOCKED_PACKAGES] = emptySet()
            prefs[Keys.ALLOWED_PACKAGES] = emptySet()
            prefs[Keys.MODE] = FirewallMode.BLOCKLIST.name
        }
    }

    suspend fun currentSettings(): FirewallSettings = settings.first()
}
