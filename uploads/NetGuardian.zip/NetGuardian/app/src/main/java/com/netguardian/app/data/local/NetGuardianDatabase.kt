package com.netguardian.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.netguardian.app.data.local.dao.NetworkUsageDao
import com.netguardian.app.data.local.entity.NetworkUsageSnapshot

@Database(
    entities = [NetworkUsageSnapshot::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class NetGuardianDatabase : RoomDatabase() {
    abstract fun networkUsageDao(): NetworkUsageDao

    companion object {
        const val DATABASE_NAME = "netguardian.db"
    }
}
