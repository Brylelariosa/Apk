package com.netguardian.app.data.util

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Android does not expose a live list of every background process to third-party apps, but
 * [UsageStatsManager] does report foreground/background transition events (with the Usage
 * Access permission granted). Polling the event stream since the last check is cheap and lets
 * the monitoring service tag each traffic sample as foreground or background activity.
 */
@Singleton
class ForegroundAppTracker @Inject constructor(@ApplicationContext private val context: Context) {

    private val usageStatsManager =
        context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

    private var currentForegroundPackage: String? = null
    private var lastQueriedAt: Long = System.currentTimeMillis() - INITIAL_LOOKBACK_MS

    /** Returns the best-known foreground package name, updating internal state as a side effect. */
    @Synchronized
    fun refreshAndGetForegroundPackage(): String? {
        val now = System.currentTimeMillis()
        val events: UsageEvents = runCatching {
            usageStatsManager.queryEvents(lastQueriedAt, now)
        }.getOrNull() ?: return currentForegroundPackage

        val event = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            when (event.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND, UsageEvents.Event.ACTIVITY_RESUMED ->
                    currentForegroundPackage = event.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND, UsageEvents.Event.ACTIVITY_PAUSED ->
                    if (event.packageName == currentForegroundPackage) {
                        // Clear rather than leave stale: without this, an app that was
                        // foregrounded and then backgrounded (e.g. the user pressed Home) kept
                        // being classified as "foreground" indefinitely until some other app
                        // happened to generate its own MOVE_TO_FOREGROUND event.
                        currentForegroundPackage = null
                    }
            }
        }
        lastQueriedAt = now
        return currentForegroundPackage
    }

    private companion object {
        const val INITIAL_LOOKBACK_MS = 60_000L
    }
}
