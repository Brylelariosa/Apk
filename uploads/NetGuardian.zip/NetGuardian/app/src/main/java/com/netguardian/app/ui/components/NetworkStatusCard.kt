package com.netguardian.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.model.DeviceNetworkStatus
import com.netguardian.app.data.model.NetworkType
import com.netguardian.app.ui.theme.CardCornerRadius
import com.netguardian.app.ui.theme.DownloadAccent
import com.netguardian.app.ui.theme.UploadAccent

@Composable
fun NetworkStatusCard(
    status: DeviceNetworkStatus,
    dataUnit: DataUnit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusChip(connected = status.isConnected, networkType = status.networkType)
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        imageVector = if (expanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                        contentDescription = if (expanded) "Collapse details" else "Expand details"
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                SpeedColumn(
                    label = "Download",
                    icon = Icons.Filled.ArrowDownward,
                    color = DownloadAccent,
                    bytesPerSecond = status.downloadBps,
                    dataUnit = dataUnit,
                    modifier = Modifier.weight(1f)
                )
                SpeedColumn(
                    label = "Upload",
                    icon = Icons.Filled.ArrowUpward,
                    color = UploadAccent,
                    bytesPerSecond = status.uploadBps,
                    dataUnit = dataUnit,
                    modifier = Modifier.weight(1f)
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = expandVertically(expandFrom = Alignment.Top) + fadeIn(),
                exit = shrinkVertically(shrinkTowards = Alignment.Top) + fadeOut()
            ) {
                Column(modifier = Modifier.padding(top = 16.dp)) {
                    DetailRow(label = "Connection type", value = status.networkType.label)
                    DetailRow(label = "IP address", value = status.ipAddress ?: "Unavailable")
                    DetailRow(
                        label = "Signal strength",
                        value = status.signalStrengthPercent?.let { "$it%" } ?: "Unavailable"
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusChip(connected: Boolean, networkType: NetworkType) {
    val icon = if (networkType == NetworkType.WIFI) Icons.Filled.Wifi else Icons.Filled.SignalCellularAlt
    val color = if (connected) com.netguardian.app.ui.theme.ActiveGreen else MaterialTheme.colorScheme.error
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = if (connected) "Connected \u2022 ${networkType.label}" else "Disconnected",
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun SpeedColumn(
    label: String,
    icon: ImageVector,
    color: androidx.compose.ui.graphics.Color,
    bytesPerSecond: Long,
    dataUnit: DataUnit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(modifier = Modifier.height(4.dp))
        AnimatedSpeedText(
            bytesPerSecond = bytesPerSecond,
            dataUnit = dataUnit,
            style = MaterialTheme.typography.headlineSmall
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(text = value, style = MaterialTheme.typography.bodyMedium)
    }
}
