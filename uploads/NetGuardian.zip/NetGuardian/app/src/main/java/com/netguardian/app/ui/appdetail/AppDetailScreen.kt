package com.netguardian.app.ui.appdetail

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.ui.components.AnimatedSpeedText
import com.netguardian.app.ui.components.EmptyState
import com.netguardian.app.ui.components.SectionHeader
import com.netguardian.app.ui.components.StatChip
import com.netguardian.app.ui.components.UsageBarChart
import com.netguardian.app.ui.components.rememberVpnPermissionRequester
import com.netguardian.app.ui.theme.CardCornerRadius
import com.netguardian.app.ui.theme.DownloadAccent
import com.netguardian.app.ui.theme.UploadAccent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDetailScreen(
    packageName: String,
    onBack: () -> Unit,
    viewModel: AppDetailViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(uiState.appInfo?.label ?: packageName) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                AppHeader(uiState)
                Spacer(modifier = Modifier.height(20.dp))
            }

            item {
                SectionHeader(title = "Firewall")
                Spacer(modifier = Modifier.height(8.dp))
                BlockAppCard(
                    isBlocked = uiState.isBlocked,
                    isAutoBlockedByCap = uiState.isAutoBlockedByCap,
                    onSetBlocked = viewModel::setBlocked
                )
                Spacer(modifier = Modifier.height(12.dp))
                DataCapCard(
                    todayUsageBytes = uiState.todayUsageBytes,
                    capBytes = uiState.dataCapBytes,
                    onSetCap = viewModel::setDataCap
                )
                Spacer(modifier = Modifier.height(20.dp))
            }

            item {
                SectionHeader(title = "Current Network Usage")
                Spacer(modifier = Modifier.height(8.dp))
                CurrentUsageCard(uiState)
                Spacer(modifier = Modifier.height(20.dp))
            }

            item {
                SectionHeader(title = "Usage History")
                Spacer(modifier = Modifier.height(8.dp))
                RangeTabs(selected = uiState.historyRange, onSelected = viewModel::onRangeChanged)
                Spacer(modifier = Modifier.height(12.dp))
                if (uiState.historyBuckets.isEmpty()) {
                    EmptyState(message = "No history recorded yet for this app.")
                } else {
                    UsageBarChart(
                        buckets = uiState.historyBuckets,
                        modifier = Modifier.fillMaxWidth().height(180.dp)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            item {
                SectionHeader(title = "Foreground vs Background")
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatChip(label = "Foreground", value = ByteFormatter.formatBytes(uiState.foregroundBytes))
                    StatChip(label = "Background", value = ByteFormatter.formatBytes(uiState.backgroundBytes))
                }
                Spacer(modifier = Modifier.height(20.dp))
            }

            item {
                SectionHeader(title = "Last Network Activity")
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = formatLastActive(uiState.lastActiveAt),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(20.dp))
            }

            item {
                SectionHeader(title = "Networking Permissions")
                Spacer(modifier = Modifier.height(8.dp))
                if (uiState.networkingPermissions.isEmpty()) {
                    Text(
                        text = "No networking permissions declared.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    uiState.networkingPermissions.forEach { permission ->
                        Text(text = "\u2022 $permission", style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun BlockAppCard(
    isBlocked: Boolean,
    isAutoBlockedByCap: Boolean,
    onSetBlocked: (android.content.Context, Boolean) -> Unit
) {
    val context = LocalContext.current
    val requestVpnPermission = rememberVpnPermissionRequester()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(
            containerColor = if (isBlocked) {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = "Block internet access", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = when {
                        isAutoBlockedByCap -> "Blocked automatically - today's data cap was reached. Releases tomorrow."
                        isBlocked -> "This app cannot reach the network right now."
                        else -> "Cuts this app off from Wi-Fi and mobile data using a local VPN tunnel."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = isBlocked,
                onCheckedChange = { checked ->
                    if (checked) {
                        requestVpnPermission { onSetBlocked(context, true) }
                    } else {
                        onSetBlocked(context, false)
                    }
                }
            )
        }
    }
}

@Composable
private fun DataCapCard(
    todayUsageBytes: Long,
    capBytes: Long?,
    onSetCap: (Long?) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = "Daily data cap", style = MaterialTheme.typography.titleSmall)
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (capBytes == null) {
                        "No cap set - ${ByteFormatter.formatBytes(todayUsageBytes)} used today"
                    } else {
                        "${ByteFormatter.formatBytes(todayUsageBytes)} of ${ByteFormatter.formatBytes(capBytes)} used today"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = { showDialog = true }) {
                Text(if (capBytes == null) "Set cap" else "Change")
            }
        }
    }

    if (showDialog) {
        DataCapDialog(
            currentCapBytes = capBytes,
            onDismiss = { showDialog = false },
            onConfirm = { newCap ->
                onSetCap(newCap)
                showDialog = false
            }
        )
    }
}

@Composable
private fun DataCapDialog(
    currentCapBytes: Long?,
    onDismiss: () -> Unit,
    onConfirm: (Long?) -> Unit
) {
    var megabytesText by remember {
        mutableStateOf(currentCapBytes?.let { (it / (1024 * 1024)).toString() } ?: "")
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Daily data cap") },
        text = {
            Column {
                Text(
                    text = "This app will be blocked automatically once it uses this much data today. It unblocks again the next day.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = megabytesText,
                    onValueChange = { input -> megabytesText = input.filter { it.isDigit() } },
                    label = { Text("Megabytes per day") },
                    singleLine = true
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val megabytes = megabytesText.toLongOrNull()
                onConfirm(if (megabytes == null || megabytes <= 0) null else megabytes * 1024 * 1024)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            if (currentCapBytes != null) {
                TextButton(onClick = { onConfirm(null) }) {
                    Text("Remove cap")
                }
            } else {
                TextButton(onClick = onDismiss) {
                    Text("Cancel")
                }
            }
        }
    )
}

@Composable
private fun AppHeader(uiState: AppDetailUiState) {
    val appInfo = uiState.appInfo
    Row(verticalAlignment = Alignment.CenterVertically) {
        val drawable = appInfo?.icon
        if (appInfo != null && drawable != null) {
            val bitmap = remember(appInfo.packageName) { drawable.toBitmap(160, 160).asImageBitmap() }
            Image(
                painter = BitmapPainter(bitmap),
                contentDescription = appInfo.label,
                modifier = Modifier.size(64.dp).clip(CircleShape)
            )
            Spacer(modifier = Modifier.width(16.dp))
        }
        Column {
            Text(
                text = appInfo?.label ?: "Unknown app",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = appInfo?.packageName.orEmpty(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CurrentUsageCard(uiState: AppDetailUiState) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (!uiState.isCurrentlyActive) {
                Text(
                    text = "Not currently using the network",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    Column {
                        Text(text = "Download", style = MaterialTheme.typography.labelMedium, color = DownloadAccent)
                        AnimatedSpeedText(
                            bytesPerSecond = uiState.currentDownloadBps,
                            dataUnit = uiState.dataUnit,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    Column {
                        Text(text = "Upload", style = MaterialTheme.typography.labelMedium, color = UploadAccent)
                        AnimatedSpeedText(
                            bytesPerSecond = uiState.currentUploadBps,
                            dataUnit = uiState.dataUnit,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RangeTabs(selected: HistoryRange, onSelected: (HistoryRange) -> Unit) {
    val ranges = HistoryRange.values()
    TabRow(selectedTabIndex = ranges.indexOf(selected)) {
        ranges.forEach { range ->
            Tab(selected = range == selected, onClick = { onSelected(range) }, text = { Text(range.label) })
        }
    }
}

private fun formatLastActive(epochMillis: Long): String {
    if (epochMillis <= 0L) return "No activity recorded yet"
    val formatter = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
    return formatter.format(Date(epochMillis))
}
