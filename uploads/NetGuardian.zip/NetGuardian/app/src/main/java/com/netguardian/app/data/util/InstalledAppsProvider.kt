package com.netguardian.app.data.util

import android.content.Context
import android.content.pm.PackageManager
import com.netguardian.app.data.model.AppInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Lists every installed app that declares the INTERNET permission - the universe of apps worth
 * polling with [TrafficStatsSampler]. Enumeration touches PackageManager for every package on
 * the device, so the monitoring service only re-runs it periodically rather than every tick.
 */
@Singleton
class InstalledAppsProvider @Inject constructor(
    @ApplicationContext private val context: Context,
    private val appIconCache: AppIconCache
) {
    private val packageManager: PackageManager = context.packageManager

    fun listNetworkCapableApps(): List<AppInfo> {
        @Suppress("DEPRECATION")
        val installed = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        return installed
            .filter { hasInternetPermission(it.packageName) }
            .map { appIconCache.get(it.packageName, it.uid) }
    }

    fun listAllApps(): List<AppInfo> {
        @Suppress("DEPRECATION")
        val installed = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        return installed.map { appIconCache.get(it.packageName, it.uid) }
    }

    private fun hasInternetPermission(packageName: String): Boolean = try {
        packageManager.checkPermission(
            android.Manifest.permission.INTERNET,
            packageName
        ) == PackageManager.PERMISSION_GRANTED
    } catch (e: Exception) {
        false
    }
}
