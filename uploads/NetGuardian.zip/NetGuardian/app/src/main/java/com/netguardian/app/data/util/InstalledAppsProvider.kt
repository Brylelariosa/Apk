package com.netguardian.app.data.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import com.netguardian.app.data.model.AppInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Lists installed apps for the Apps screen's full directory. The live monitoring service does
 * not use this - it resolves apps on demand from whichever UIDs actually show traffic (see
 * [AppIconCache.getByUid]), since that's a more reliable source of "what apps exist" for
 * monitoring purposes than a separately-enumerated list.
 *
 * Filtered to apps that declare the INTERNET permission, i.e. are even capable of making a
 * network call - without this, the directory is cluttered with dozens of resource-only OEM
 * overlay/theme packages (icon packs, `android.overlay.*`, `android.auto_generated_rro_*`, ...)
 * that have no code and can never generate any traffic, which have nothing to do with a
 * network-focused app and were confusing to see in a list meant for managing network access.
 */
@Singleton
class InstalledAppsProvider @Inject constructor(
    @ApplicationContext private val context: Context,
    private val appIconCache: AppIconCache
) {
    private val packageManager: PackageManager = context.packageManager

    fun listAllApps(): List<AppInfo> {
        @Suppress("DEPRECATION")
        val installed = packageManager.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        return installed
            .filter { it.requestedPermissions?.contains(Manifest.permission.INTERNET) == true }
            .mapNotNull { it.applicationInfo }
            .map { appIconCache.get(it.packageName, it.uid) }
    }
}
