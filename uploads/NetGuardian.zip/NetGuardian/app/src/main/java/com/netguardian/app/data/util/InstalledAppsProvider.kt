package com.netguardian.app.data.util

import android.content.Context
import android.content.pm.PackageManager
import com.netguardian.app.data.model.AppInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Lists every installed app, for the Apps screen's full directory. The live monitoring service
 * does not use this - it resolves apps on demand from whichever UIDs actually show traffic (see
 * [AppIconCache.getByUid]), since that's a more reliable source of "what apps exist" for
 * monitoring purposes than a separately-enumerated list.
 */
@Singleton
class InstalledAppsProvider @Inject constructor(
    @ApplicationContext private val context: Context,
    private val appIconCache: AppIconCache
) {
    private val packageManager: PackageManager = context.packageManager

    fun listAllApps(): List<AppInfo> {
        @Suppress("DEPRECATION")
        val installed = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        return installed.map { appIconCache.get(it.packageName, it.uid) }
    }
}
