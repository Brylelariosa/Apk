package com.netguardian.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.netguardian.app.ui.theme.CardCornerRadius
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip

/**
 * Scrolling line chart for the last ~60 seconds of download/upload throughput. Values are plotted
 * relative to the largest sample currently on screen so the graph auto-scales as speeds change.
 */
@Composable
fun LiveTrafficGraph(
    downloadSamples: List<Float>,
    uploadSamples: List<Float>,
    modifier: Modifier = Modifier
) {
    val downloadColor = com.netguardian.app.ui.theme.DownloadAccent
    val uploadColor = com.netguardian.app.ui.theme.UploadAccent

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulseAlpha"
    )

    Canvas(
        modifier = modifier
            .clip(RoundedCornerShape(CardCornerRadius))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
    ) {
        val maxValue = (downloadSamples + uploadSamples).maxOrNull()?.coerceAtLeast(1f) ?: 1f
        drawGridLines()
        drawSeries(downloadSamples, maxValue, downloadColor, pulse)
        drawSeries(uploadSamples, maxValue, uploadColor, pulse)
    }
}

private fun DrawScope.drawGridLines() {
    val lines = 3
    repeat(lines) { index ->
        val y = size.height * (index + 1) / (lines + 1)
        drawLine(
            color = Color.Gray.copy(alpha = 0.15f),
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = 1.dp.toPx()
        )
    }
}

private fun DrawScope.drawSeries(samples: List<Float>, maxValue: Float, color: Color, pulseAlpha: Float) {
    if (samples.size < 2) return

    val stepX = size.width / (samples.size - 1).coerceAtLeast(1)
    val path = Path()
    val fillPath = Path()

    samples.forEachIndexed { index, value ->
        val x = index * stepX
        val y = size.height - (value / maxValue) * size.height
        if (index == 0) {
            path.moveTo(x, y)
            fillPath.moveTo(x, size.height)
            fillPath.lineTo(x, y)
        } else {
            path.lineTo(x, y)
            fillPath.lineTo(x, y)
        }
    }
    fillPath.lineTo((samples.size - 1) * stepX, size.height)
    fillPath.close()

    drawPath(
        path = fillPath,
        brush = Brush.verticalGradient(listOf(color.copy(alpha = 0.28f), Color.Transparent))
    )
    drawPath(path = path, color = color, style = Stroke(width = 2.5.dp.toPx()))

    val lastX = (samples.size - 1) * stepX
    val lastY = size.height - (samples.last() / maxValue) * size.height
    drawCircle(color = color.copy(alpha = pulseAlpha), radius = 5.dp.toPx(), center = Offset(lastX, lastY))
}
