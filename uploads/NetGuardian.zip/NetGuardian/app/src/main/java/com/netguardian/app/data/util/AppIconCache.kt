package com.netguardian.app.data.util

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.netguardian.app.data.model.AppInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolving an app's label and icon via [PackageManager] involves disk I/O and is too slow to
 * repeat every monitoring tick. This cache resolves each package once and reuses the result,
 * which keeps the once-per-second sampling loop cheap on mid-range hardware.
 */
@Singleton
class AppIconCache @Inject constructor(@ApplicationContext private val context: Context) {

    private val packageManager: PackageManager = context.packageManager
    private val cacheByPackage = LinkedHashMap<String, AppInfo>()
    private val packageNameByUid = LinkedHashMap<Int, String>()

    /** Use when the caller already has a verified UID (e.g. from enumerating installed apps). */
    @Synchronized
    fun get(packageName: String, uid: Int): AppInfo {
        cacheByPackage[packageName]?.let { return it }
        val resolved = resolve(packageName, uid)
        cacheByPackage[packageName] = resolved
        packageNameByUid[uid] = packageName
        return resolved
    }

    /** Use when only the package name is known; the UID is looked up rather than guessed. */
    fun get(packageName: String): AppInfo {
        cacheByPackage[packageName]?.let { return it }
        val uid = runCatching { packageManager.getApplicationInfo(packageName, 0).uid }.getOrDefault(-1)
        return get(packageName, uid)
    }

    /**
     * Resolves a Linux UID (as reported by [NetworkStatsProvider]) back to a representative
     * app. A UID can be shared by more than one package (`sharedUserId`); the first match is
     * used for display purposes. Returns null for UIDs that aren't tied to any installed app
     * (system/core service UIDs), which callers should simply skip.
     */
    @Synchronized
    fun getByUid(uid: Int): AppInfo? {
        packageNameByUid[uid]?.let { return cacheByPackage[it] }
        val packageNames = runCatching { packageManager.getPackagesForUid(uid) }.getOrNull()
        val packageName = packageNames?.firstOrNull() ?: return null
        return get(packageName, uid)
    }

    @Synchronized
    fun invalidate(packageName: String) {
        cacheByPackage.remove(packageName)
        packageNameByUid.entries.removeAll { it.value == packageName }
    }

    private fun resolve(packageName: String, uid: Int): AppInfo {
        return try {
            val appInfo: ApplicationInfo = packageManager.getApplicationInfo(packageName, 0)
            AppInfo(
                packageName = packageName,
                uid = uid,
                label = packageManager.getApplicationLabel(appInfo).toString(),
                icon = runCatching { packageManager.getApplicationIcon(appInfo) }.getOrNull(),
                isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        } catch (e: PackageManager.NameNotFoundException) {
            AppInfo(packageName, uid, packageName, null, isSystemApp = false)
        }
    }
}
