package com.netguardian.app.data.util

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.netguardian.app.data.model.AppInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Resolving an app's label and icon via [PackageManager] involves disk I/O and is too slow to
 * repeat every monitoring tick. This cache resolves each package once and reuses the result,
 * which keeps the once-per-second sampling loop cheap on mid-range hardware.
 */
@Singleton
class AppIconCache @Inject constructor(@ApplicationContext private val context: Context) {

    private val packageManager: PackageManager = context.packageManager
    private val cache = LinkedHashMap<String, AppInfo>()

    @Synchronized
    fun get(packageName: String, uid: Int): AppInfo {
        cache[packageName]?.let { return it }
        val resolved = resolve(packageName, uid)
        cache[packageName] = resolved
        return resolved
    }

    @Synchronized
    fun invalidate(packageName: String) {
        cache.remove(packageName)
    }

    private fun resolve(packageName: String, uid: Int): AppInfo {
        return try {
            val appInfo: ApplicationInfo = packageManager.getApplicationInfo(packageName, 0)
            AppInfo(
                packageName = packageName,
                uid = uid,
                label = packageManager.getApplicationLabel(appInfo).toString(),
                icon = runCatching { packageManager.getApplicationIcon(appInfo) }.getOrNull(),
                isSystemApp = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            )
        } catch (e: PackageManager.NameNotFoundException) {
            AppInfo(packageName, uid, packageName, null, isSystemApp = false)
        }
    }
}
