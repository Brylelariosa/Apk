package com.netguardian.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.netguardian.app.data.local.entity.NetworkUsageSnapshot
import kotlinx.coroutines.flow.Flow

@Dao
interface NetworkUsageDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(snapshots: List<NetworkUsageSnapshot>)

    /** Per-app rollup for the given window, most-recently-active apps first is applied by callers. */
    @Query(
        """
        SELECT
            packageName AS packageName,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN rxBytesDelta ELSE 0 END), 0) AS wifiRx,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN txBytesDelta ELSE 0 END), 0) AS wifiTx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN rxBytesDelta ELSE 0 END), 0) AS mobileRx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN txBytesDelta ELSE 0 END), 0) AS mobileTx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN rxBytesDelta ELSE 0 END), 0) AS otherRx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN txBytesDelta ELSE 0 END), 0) AS otherTx,
            COALESCE(SUM(CASE WHEN isForeground = 1 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS foregroundBytes,
            COALESCE(SUM(CASE WHEN isForeground = 0 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS backgroundBytes,
            MAX(timestamp) AS lastActiveAt
        FROM network_usage_snapshot
        WHERE timestamp BETWEEN :startMillis AND :endMillis
        GROUP BY packageName
        """
    )
    fun observeAppAggregates(startMillis: Long, endMillis: Long): Flow<List<AppUsageAggregateRow>>

    @Query(
        """
        SELECT
            packageName AS packageName,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN rxBytesDelta ELSE 0 END), 0) AS wifiRx,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN txBytesDelta ELSE 0 END), 0) AS wifiTx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN rxBytesDelta ELSE 0 END), 0) AS mobileRx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN txBytesDelta ELSE 0 END), 0) AS mobileTx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN rxBytesDelta ELSE 0 END), 0) AS otherRx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN txBytesDelta ELSE 0 END), 0) AS otherTx,
            COALESCE(SUM(CASE WHEN isForeground = 1 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS foregroundBytes,
            COALESCE(SUM(CASE WHEN isForeground = 0 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS backgroundBytes,
            MAX(timestamp) AS lastActiveAt
        FROM network_usage_snapshot
        WHERE packageName = :packageName AND timestamp BETWEEN :startMillis AND :endMillis
        GROUP BY packageName
        """
    )
    fun observeSingleAppAggregate(
        packageName: String,
        startMillis: Long,
        endMillis: Long
    ): Flow<AppUsageAggregateRow?>

    @Query(
        """
        SELECT COALESCE(SUM(rxBytesDelta), 0) AS rxBytes, COALESCE(SUM(txBytesDelta), 0) AS txBytes
        FROM network_usage_snapshot
        WHERE timestamp BETWEEN :startMillis AND :endMillis
        """
    )
    fun observeTotalUsage(startMillis: Long, endMillis: Long): Flow<TotalUsageRow>

    /**
     * Daily buckets (local time) for the History screen's charts. [transport] is nullable so
     * one query covers both "All Data" (null - no filter) and a single transport
     * ("WIFI"/"MOBILE"/"OTHER"), rather than keeping a near-duplicate query per transport.
     */
    @Query(
        """
        SELECT
            strftime('%Y-%m-%d', timestamp / 1000, 'unixepoch', 'localtime') AS bucketLabel,
            MIN(timestamp) AS bucketStart,
            COALESCE(SUM(rxBytesDelta), 0) AS rxBytes,
            COALESCE(SUM(txBytesDelta), 0) AS txBytes
        FROM network_usage_snapshot
        WHERE (:transport IS NULL OR transport = :transport)
            AND timestamp BETWEEN :startMillis AND :endMillis
        GROUP BY bucketLabel
        ORDER BY bucketStart ASC
        """
    )
    fun observeDailyBuckets(transport: String?, startMillis: Long, endMillis: Long): Flow<List<UsageBucketRow>>

    /** Same daily bucketing as [observeDailyBuckets], scoped to a single app for its Detail screen. */
    @Query(
        """
        SELECT
            strftime('%Y-%m-%d', timestamp / 1000, 'unixepoch', 'localtime') AS bucketLabel,
            MIN(timestamp) AS bucketStart,
            COALESCE(SUM(rxBytesDelta), 0) AS rxBytes,
            COALESCE(SUM(txBytesDelta), 0) AS txBytes
        FROM network_usage_snapshot
        WHERE packageName = :packageName AND timestamp BETWEEN :startMillis AND :endMillis
        GROUP BY bucketLabel
        ORDER BY bucketStart ASC
        """
    )
    fun observeAppDailyBuckets(packageName: String, startMillis: Long, endMillis: Long): Flow<List<UsageBucketRow>>

    @Query(
        """
        SELECT
            packageName AS packageName,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN rxBytesDelta ELSE 0 END), 0) AS wifiRx,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN txBytesDelta ELSE 0 END), 0) AS wifiTx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN rxBytesDelta ELSE 0 END), 0) AS mobileRx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN txBytesDelta ELSE 0 END), 0) AS mobileTx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN rxBytesDelta ELSE 0 END), 0) AS otherRx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN txBytesDelta ELSE 0 END), 0) AS otherTx,
            COALESCE(SUM(CASE WHEN isForeground = 1 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS foregroundBytes,
            COALESCE(SUM(CASE WHEN isForeground = 0 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS backgroundBytes,
            MAX(timestamp) AS lastActiveAt
        FROM network_usage_snapshot
        WHERE timestamp BETWEEN :startMillis AND :endMillis
        GROUP BY packageName
        ORDER BY (wifiRx + wifiTx + mobileRx + mobileTx + otherRx + otherTx) DESC
        LIMIT :limit
        """
    )
    suspend fun getTopApps(startMillis: Long, endMillis: Long, limit: Int): List<AppUsageAggregateRow>

    /**
     * Top downloaders for the window, optionally scoped to one transport ([transport] null =
     * all transports combined). When scoped, the per-transport SUM columns other than the
     * matching one naturally come back 0, so [AppUsageAggregateRow] stays one consistent shape
     * either way.
     */
    @Query(
        """
        SELECT
            packageName AS packageName,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN rxBytesDelta ELSE 0 END), 0) AS wifiRx,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN txBytesDelta ELSE 0 END), 0) AS wifiTx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN rxBytesDelta ELSE 0 END), 0) AS mobileRx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN txBytesDelta ELSE 0 END), 0) AS mobileTx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN rxBytesDelta ELSE 0 END), 0) AS otherRx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN txBytesDelta ELSE 0 END), 0) AS otherTx,
            COALESCE(SUM(CASE WHEN isForeground = 1 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS foregroundBytes,
            COALESCE(SUM(CASE WHEN isForeground = 0 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS backgroundBytes,
            MAX(timestamp) AS lastActiveAt
        FROM network_usage_snapshot
        WHERE (:transport IS NULL OR transport = :transport)
            AND timestamp BETWEEN :startMillis AND :endMillis
        GROUP BY packageName
        ORDER BY (wifiRx + mobileRx + otherRx) DESC
        LIMIT :limit
        """
    )
    suspend fun getTopDownloaders(
        transport: String?,
        startMillis: Long,
        endMillis: Long,
        limit: Int
    ): List<AppUsageAggregateRow>

    /** Same as [getTopDownloaders] but ranked (and summed) by upload bytes. */
    @Query(
        """
        SELECT
            packageName AS packageName,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN rxBytesDelta ELSE 0 END), 0) AS wifiRx,
            COALESCE(SUM(CASE WHEN transport = 'WIFI' THEN txBytesDelta ELSE 0 END), 0) AS wifiTx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN rxBytesDelta ELSE 0 END), 0) AS mobileRx,
            COALESCE(SUM(CASE WHEN transport = 'MOBILE' THEN txBytesDelta ELSE 0 END), 0) AS mobileTx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN rxBytesDelta ELSE 0 END), 0) AS otherRx,
            COALESCE(SUM(CASE WHEN transport = 'OTHER' THEN txBytesDelta ELSE 0 END), 0) AS otherTx,
            COALESCE(SUM(CASE WHEN isForeground = 1 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS foregroundBytes,
            COALESCE(SUM(CASE WHEN isForeground = 0 THEN rxBytesDelta + txBytesDelta ELSE 0 END), 0) AS backgroundBytes,
            MAX(timestamp) AS lastActiveAt
        FROM network_usage_snapshot
        WHERE (:transport IS NULL OR transport = :transport)
            AND timestamp BETWEEN :startMillis AND :endMillis
        GROUP BY packageName
        ORDER BY (wifiTx + mobileTx + otherTx) DESC
        LIMIT :limit
        """
    )
    suspend fun getTopUploaders(
        transport: String?,
        startMillis: Long,
        endMillis: Long,
        limit: Int
    ): List<AppUsageAggregateRow>

    @Query("DELETE FROM network_usage_snapshot WHERE timestamp < :cutoffMillis")
    suspend fun deleteOlderThan(cutoffMillis: Long)
}
