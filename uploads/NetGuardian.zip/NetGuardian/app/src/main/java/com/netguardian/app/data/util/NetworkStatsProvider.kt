package com.netguardian.app.data.util

import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.RemoteException
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Per-app (per-UID) network usage, sourced from [NetworkStatsManager].
 *
 * This intentionally does NOT use `TrafficStats.getUidRxBytes/getUidTxBytes`. Those calls are
 * only guaranteed to reflect the *calling app's own* traffic - per Android's own docs for
 * network usage APIs, "by default, apps can only obtain data about themselves" for other UIDs
 * unless they go through the Usage Access-gated APIs. `NetworkStatsManager` is the API that
 * actually honors the Usage Access grant (`PACKAGE_USAGE_STATS`) this app already requests, and
 * is what Android's own Settings > Data usage screen is built on. Querying with an explicit
 * [startTime, endTime] window also hands back the delta for that window directly, so the
 * service no longer needs to track its own "previous cumulative counter" per app.
 */
@Singleton
class NetworkStatsProvider @Inject constructor(@ApplicationContext private val context: Context) {

    private val networkStatsManager =
        context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager

    /** uid -> bytes transferred within [startTime, endTime), merged across Wi-Fi and mobile. */
    fun queryUidDeltas(startTime: Long, endTime: Long): Map<Int, ByteCounters> {
        if (endTime <= startTime) return emptyMap()
        val merged = mutableMapOf<Int, ByteCounters>()
        mergeInto(merged, queryForType(ConnectivityManager.TYPE_WIFI, startTime, endTime))
        mergeInto(merged, queryForType(ConnectivityManager.TYPE_MOBILE, startTime, endTime))
        return merged
    }

    @Suppress("DEPRECATION")
    private fun queryForType(networkType: Int, startTime: Long, endTime: Long): Map<Int, ByteCounters> {
        val perUid = mutableMapOf<Int, ByteCounters>()
        var stats: NetworkStats? = null
        try {
            stats = networkStatsManager.querySummary(networkType, null, startTime, endTime)
            val bucket = NetworkStats.Bucket()
            while (stats.hasNextBucket()) {
                stats.getNextBucket(bucket)
                val existing = perUid[bucket.uid]
                perUid[bucket.uid] = ByteCounters(
                    rxBytes = (existing?.rxBytes ?: 0L) + bucket.rxBytes,
                    txBytes = (existing?.txBytes ?: 0L) + bucket.txBytes
                )
            }
        } catch (e: SecurityException) {
            // Usage Access not granted yet - the Dashboard already surfaces a card prompting
            // the user to grant it; degrade to "no data" rather than crashing the service.
        } catch (e: RemoteException) {
            // Transient system-service hiccup; next tick will simply try again.
        } finally {
            stats?.close()
        }
        return perUid
    }

    private fun mergeInto(target: MutableMap<Int, ByteCounters>, source: Map<Int, ByteCounters>) {
        for ((uid, counters) in source) {
            val existing = target[uid]
            target[uid] = ByteCounters(
                rxBytes = (existing?.rxBytes ?: 0L) + counters.rxBytes,
                txBytes = (existing?.txBytes ?: 0L) + counters.txBytes
            )
        }
    }
}
