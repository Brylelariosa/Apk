package com.netguardian.app.ui.schedules

import com.netguardian.app.data.model.BlockSchedule

data class ScheduleRowUiModel(
    val schedule: BlockSchedule,
    val appLabels: List<String>
)

data class SchedulesUiState(
    val schedules: List<ScheduleRowUiModel> = emptyList(),
    val allApps: List<SelectableApp> = emptyList(),
    val isLoading: Boolean = true
)

data class SelectableApp(val packageName: String, val label: String)
