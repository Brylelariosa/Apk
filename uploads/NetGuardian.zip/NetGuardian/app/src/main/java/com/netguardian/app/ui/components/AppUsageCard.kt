package com.netguardian.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.netguardian.app.data.model.ActivityState
import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.ui.LocalAnimationsEnabled
import com.netguardian.app.ui.theme.ActiveGreen
import com.netguardian.app.ui.theme.CardCornerRadius
import com.netguardian.app.ui.theme.DownloadAccent
import com.netguardian.app.ui.theme.IdleGray
import com.netguardian.app.ui.theme.UploadAccent

@Composable
fun AppUsageCard(
    usage: LiveAppUsage,
    dataUnit: DataUnit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var visible by remember(usage.appInfo.packageName) { mutableStateOf(false) }
    LaunchedEffect(usage.appInfo.packageName) { visible = true }
    val animationsEnabled = LocalAnimationsEnabled.current
    val entranceSpec = if (animationsEnabled) tween(350) else snap()
    val alpha by animateFloatAsState(if (visible) 1f else 0f, animationSpec = entranceSpec, label = "cardAlpha")
    val cardScale by animateFloatAsState(
        if (visible) 1f else 0.94f,
        animationSpec = entranceSpec,
        label = "cardScale"
    )

    Card(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .alpha(alpha)
            .scale(cardScale),
        shape = RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppIcon(usage = usage)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = usage.appInfo.label,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    ForegroundBadge(isForeground = usage.isForeground)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Session: ${ByteFormatter.formatBytes(usage.sessionRxBytes + usage.sessionTxBytes)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row {
                    SpeedLabel(Icons.Filled.ArrowDownward, DownloadAccent, usage.downloadBps, dataUnit)
                    Spacer(modifier = Modifier.width(12.dp))
                    SpeedLabel(Icons.Filled.ArrowUpward, UploadAccent, usage.uploadBps, dataUnit)
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            MiniActivityGraph(
                samples = usage.recentSamples,
                color = activityColor(usage.activityState),
                modifier = Modifier.size(width = 64.dp, height = 36.dp)
            )
        }
    }
}

@Composable
private fun AppIcon(usage: LiveAppUsage) {
    val drawable = usage.appInfo.icon
    if (drawable != null) {
        val bitmap = remember(usage.appInfo.packageName) { drawable.toBitmap(96, 96).asImageBitmap() }
        Image(
            painter = BitmapPainter(bitmap),
            contentDescription = usage.appInfo.label,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
        )
    } else {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = usage.appInfo.label.take(1).uppercase(),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@Composable
private fun ForegroundBadge(isForeground: Boolean) {
    Text(
        text = if (isForeground) "Foreground" else "Background",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun SpeedLabel(icon: ImageVector, color: Color, bps: Long, dataUnit: DataUnit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(12.dp))
        Spacer(modifier = Modifier.width(2.dp))
        Text(
            text = ByteFormatter.formatSpeed(bps, dataUnit),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun activityColor(state: ActivityState): Color = when (state) {
    ActivityState.RECEIVING -> DownloadAccent
    ActivityState.UPLOADING -> UploadAccent
    ActivityState.BOTH -> ActiveGreen
    ActivityState.IDLE -> IdleGray
}
