package com.netguardian.app.ui.apps

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.model.AppInfo
import com.netguardian.app.data.model.AppSortOrder
import com.netguardian.app.data.model.AppUsageAggregate
import com.netguardian.app.data.model.FirewallMode
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.InstalledAppsProvider
import com.netguardian.app.service.FirewallVpnService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class AppsViewModel @Inject constructor(
    private val installedAppsProvider: InstalledAppsProvider,
    private val appUsageRepository: AppUsageRepository,
    private val settingsRepository: SettingsRepository,
    private val firewallRepository: FirewallRepository
) : ViewModel() {

    private val allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    private val searchQuery = MutableStateFlow("")
    private val sortOrder = MutableStateFlow(AppSortOrder.ALPHABETICAL)
    private val isRefreshing = MutableStateFlow(false)
    private val isSelectionMode = MutableStateFlow(false)
    private val selectedPackages = MutableStateFlow<Set<String>>(emptySet())

    val uiState: StateFlow<AppsUiState> = combine(
        allApps,
        appUsageRepository.observeMonthAppAggregates(),
        appUsageRepository.observeTodayAppAggregates(),
        appUsageRepository.observeAllTimeAppAggregates(),
        searchQuery,
        sortOrder,
        settingsRepository.settings,
        isRefreshing,
        firewallRepository.settings,
        isSelectionMode,
        selectedPackages
    ) { values ->
        @Suppress("UNCHECKED_CAST") val apps = values[0] as List<AppInfo>
        @Suppress("UNCHECKED_CAST") val monthAggs = values[1] as List<AppUsageAggregate>
        @Suppress("UNCHECKED_CAST") val todayAggs = values[2] as List<AppUsageAggregate>
        @Suppress("UNCHECKED_CAST") val allTimeAggs = values[3] as List<AppUsageAggregate>
        val query = values[4] as String
        val sort = values[5] as AppSortOrder
        val settings = values[6] as com.netguardian.app.data.datastore.AppSettings
        val refreshing = values[7] as Boolean
        val firewallSettings = values[8] as com.netguardian.app.data.datastore.FirewallSettings
        val selectionMode = values[9] as Boolean
        @Suppress("UNCHECKED_CAST") val selected = values[10] as Set<String>

        val rows = buildRows(
            allApps = apps,
            monthAggregates = monthAggs.associateBy { it.packageName },
            todayAggregates = todayAggs.associateBy { it.packageName },
            allTimeAggregates = allTimeAggs.associateBy { it.packageName },
            firewallSettings = firewallSettings
        ).filteredAndSorted(query, sort)

        AppsUiState(
            rows = rows,
            searchQuery = query,
            sortOrder = sort,
            dataUnit = settings.dataUnit,
            isRefreshing = refreshing,
            isLoading = apps.isEmpty(),
            isSelectionMode = selectionMode,
            selectedPackages = selected
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppsUiState())

    init {
        refresh()
    }

    fun onSearchQueryChanged(query: String) {
        searchQuery.value = query
    }

    fun onSortOrderChanged(order: AppSortOrder) {
        sortOrder.value = order
    }

    fun refresh() {
        viewModelScope.launch {
            isRefreshing.value = true
            allApps.value = withContext(Dispatchers.IO) { installedAppsProvider.listAllApps() }
            isRefreshing.value = false
        }
    }

    /** "Blocked" always means "cut off from the network" regardless of firewall mode - in
     *  Blocklist mode that's an entry in the block list, in Allowlist mode it's the *absence*
     *  of an entry in the allow list. Call only after VPN consent is confirmed. */
    fun setBlocked(context: Context, packageName: String, blocked: Boolean) {
        viewModelScope.launch {
            when (firewallRepository.currentSettings().mode) {
                FirewallMode.BLOCKLIST -> firewallRepository.setBlocked(packageName, blocked)
                FirewallMode.ALLOWLIST -> firewallRepository.setAllowed(packageName, !blocked)
            }
            FirewallVpnService.start(context)
        }
    }

    fun enterSelectionMode(initialPackageName: String) {
        isSelectionMode.value = true
        selectedPackages.value = setOf(initialPackageName)
    }

    fun exitSelectionMode() {
        isSelectionMode.value = false
        selectedPackages.value = emptySet()
    }

    fun toggleSelected(packageName: String) {
        val current = selectedPackages.value
        selectedPackages.value = if (current.contains(packageName)) current - packageName else current + packageName
    }

    /** Call only after VPN consent is confirmed. */
    fun blockSelected(context: Context) {
        val toBlock = selectedPackages.value
        if (toBlock.isEmpty()) return
        viewModelScope.launch {
            when (firewallRepository.currentSettings().mode) {
                FirewallMode.BLOCKLIST -> firewallRepository.setBlockedMany(toBlock, true)
                FirewallMode.ALLOWLIST -> firewallRepository.setAllowedMany(toBlock, false)
            }
            FirewallVpnService.start(context)
        }
        exitSelectionMode()
    }

    fun unblockSelected() {
        val toUnblock = selectedPackages.value
        if (toUnblock.isEmpty()) return
        viewModelScope.launch {
            when (firewallRepository.currentSettings().mode) {
                FirewallMode.BLOCKLIST -> firewallRepository.setBlockedMany(toUnblock, false)
                FirewallMode.ALLOWLIST -> firewallRepository.setAllowedMany(toUnblock, true)
            }
        }
        exitSelectionMode()
    }
}
