package com.netguardian.app.ui.apps

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.model.AppInfo
import com.netguardian.app.data.model.AppSortOrder
import com.netguardian.app.data.model.AppUsageAggregate
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.InstalledAppsProvider
import com.netguardian.app.service.FirewallVpnService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class AppsViewModel @Inject constructor(
    private val installedAppsProvider: InstalledAppsProvider,
    private val appUsageRepository: AppUsageRepository,
    private val settingsRepository: SettingsRepository,
    private val firewallRepository: FirewallRepository
) : ViewModel() {

    private val allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    private val searchQuery = MutableStateFlow("")
    private val sortOrder = MutableStateFlow(AppSortOrder.ALPHABETICAL)
    private val isRefreshing = MutableStateFlow(false)
    private val isSelectionMode = MutableStateFlow(false)
    private val selectedPackages = MutableStateFlow<Set<String>>(emptySet())

    val uiState: StateFlow<AppsUiState> = combine(
        allApps,
        appUsageRepository.observeMonthAppAggregates(),
        appUsageRepository.observeTodayAppAggregates(),
        appUsageRepository.observeAllTimeAppAggregates(),
        searchQuery,
        sortOrder,
        settingsRepository.settings,
        isRefreshing,
        firewallRepository.settings,
        isSelectionMode,
        selectedPackages
    ) { values ->
        @Suppress("UNCHECKED_CAST") val apps = values[0] as List<AppInfo>
        @Suppress("UNCHECKED_CAST") val monthAggs = values[1] as List<AppUsageAggregate>
        @Suppress("UNCHECKED_CAST") val todayAggs = values[2] as List<AppUsageAggregate>
        @Suppress("UNCHECKED_CAST") val allTimeAggs = values[3] as List<AppUsageAggregate>
        val query = values[4] as String
        val sort = values[5] as AppSortOrder
        val settings = values[6] as com.netguardian.app.data.datastore.AppSettings
        val refreshing = values[7] as Boolean
        val firewallSettings = values[8] as com.netguardian.app.data.datastore.FirewallSettings
        val selectionMode = values[9] as Boolean
        @Suppress("UNCHECKED_CAST") val selected = values[10] as Set<String>

        val rows = buildRows(
            allApps = apps,
            monthAggregates = monthAggs.associateBy { it.packageName },
            todayAggregates = todayAggs.associateBy { it.packageName },
            allTimeAggregates = allTimeAggs.associateBy { it.packageName },
            firewallSettings = firewallSettings
        ).filteredAndSorted(query, sort)

        AppsUiState(
            rows = rows,
            searchQuery = query,
            sortOrder = sort,
            dataUnit = settings.dataUnit,
            firewallMode = firewallSettings.mode,
            isRefreshing = refreshing,
            isLoading = apps.isEmpty(),
            isSelectionMode = selectionMode,
            selectedPackages = selected
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppsUiState())

    init {
        refresh()
    }

    fun onSearchQueryChanged(query: String) {
        searchQuery.value = query
    }

    fun onSortOrderChanged(order: AppSortOrder) {
        sortOrder.value = order
    }

    fun refresh() {
        viewModelScope.launch {
            isRefreshing.value = true
            allApps.value = withContext(Dispatchers.IO) { installedAppsProvider.listAllApps() }
            isRefreshing.value = false
        }
    }

    /** Adds/removes this app from whichever list the current firewall mode reads from - the
     *  block list in Blocklist mode, the allow list in Allowlist mode. Call [isMember] = true
     *  only after VPN consent is confirmed (adding to either list can newly activate the
     *  tunnel); removal never needs consent. */
    fun setActiveListMembership(context: Context, packageName: String, isMember: Boolean) {
        viewModelScope.launch {
            firewallRepository.setActiveListMembership(packageName, isMember)
            if (isMember) {
                FirewallVpnService.start(context)?.let { firewallRepository.reportError(it) }
            }
        }
    }

    fun enterSelectionMode(initialPackageName: String) {
        isSelectionMode.value = true
        selectedPackages.value = setOf(initialPackageName)
    }

    fun exitSelectionMode() {
        isSelectionMode.value = false
        selectedPackages.value = emptySet()
    }

    fun toggleSelected(packageName: String) {
        val current = selectedPackages.value
        selectedPackages.value = if (current.contains(packageName)) current - packageName else current + packageName
    }

    /** Call only after VPN consent is confirmed. */
    fun addSelectedToActiveList(context: Context) {
        val toAdd = selectedPackages.value
        if (toAdd.isEmpty()) return
        viewModelScope.launch {
            firewallRepository.setActiveListMembershipMany(toAdd, true)
            FirewallVpnService.start(context)?.let { firewallRepository.reportError(it) }
        }
        exitSelectionMode()
    }

    fun removeSelectedFromActiveList() {
        val toRemove = selectedPackages.value
        if (toRemove.isEmpty()) return
        viewModelScope.launch { firewallRepository.setActiveListMembershipMany(toRemove, false) }
        exitSelectionMode()
    }
}
