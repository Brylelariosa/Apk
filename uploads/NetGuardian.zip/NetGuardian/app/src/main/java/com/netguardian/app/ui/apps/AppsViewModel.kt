package com.netguardian.app.ui.apps

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.model.AppInfo
import com.netguardian.app.data.model.AppSortOrder
import com.netguardian.app.data.model.AppUsageAggregate
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.InstalledAppsProvider
import com.netguardian.app.service.FirewallVpnService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import javax.inject.Inject

@HiltViewModel
class AppsViewModel @Inject constructor(
    private val installedAppsProvider: InstalledAppsProvider,
    private val appUsageRepository: AppUsageRepository,
    private val settingsRepository: SettingsRepository,
    private val firewallRepository: FirewallRepository
) : ViewModel() {

    private val allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    private val searchQuery = MutableStateFlow("")
    private val sortOrder = MutableStateFlow(AppSortOrder.ALPHABETICAL)
    private val isRefreshing = MutableStateFlow(false)

    val uiState: StateFlow<AppsUiState> = combine(
        allApps,
        appUsageRepository.observeMonthAppAggregates(),
        appUsageRepository.observeTodayAppAggregates(),
        appUsageRepository.observeAllTimeAppAggregates(),
        searchQuery,
        sortOrder,
        settingsRepository.settings,
        isRefreshing,
        firewallRepository.settings
    ) { values ->
        @Suppress("UNCHECKED_CAST") val apps = values[0] as List<AppInfo>
        @Suppress("UNCHECKED_CAST") val monthAggs = values[1] as List<AppUsageAggregate>
        @Suppress("UNCHECKED_CAST") val todayAggs = values[2] as List<AppUsageAggregate>
        @Suppress("UNCHECKED_CAST") val allTimeAggs = values[3] as List<AppUsageAggregate>
        val query = values[4] as String
        val sort = values[5] as AppSortOrder
        val settings = values[6] as com.netguardian.app.data.datastore.AppSettings
        val refreshing = values[7] as Boolean
        val firewallSettings = values[8] as com.netguardian.app.data.datastore.FirewallSettings

        val rows = buildRows(
            allApps = apps,
            monthAggregates = monthAggs.associateBy { it.packageName },
            todayAggregates = todayAggs.associateBy { it.packageName },
            allTimeAggregates = allTimeAggs.associateBy { it.packageName },
            blockedPackages = firewallSettings.blockedPackages
        ).filteredAndSorted(query, sort)

        AppsUiState(
            rows = rows,
            searchQuery = query,
            sortOrder = sort,
            dataUnit = settings.dataUnit,
            isRefreshing = refreshing,
            isLoading = apps.isEmpty()
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppsUiState())

    init {
        refresh()
    }

    fun onSearchQueryChanged(query: String) {
        searchQuery.value = query
    }

    fun onSortOrderChanged(order: AppSortOrder) {
        sortOrder.value = order
    }

    fun refresh() {
        viewModelScope.launch {
            isRefreshing.value = true
            allApps.value = withContext(Dispatchers.IO) { installedAppsProvider.listAllApps() }
            isRefreshing.value = false
        }
    }

    /** Call only after VPN consent is confirmed (see rememberVpnPermissionRequester). */
    fun setBlocked(context: Context, packageName: String, blocked: Boolean) {
        viewModelScope.launch {
            firewallRepository.setBlocked(packageName, blocked)
            if (blocked) FirewallVpnService.start(context)
        }
    }
}
