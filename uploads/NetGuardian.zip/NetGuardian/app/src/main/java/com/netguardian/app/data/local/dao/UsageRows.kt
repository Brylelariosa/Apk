package com.netguardian.app.data.local.dao

/** Row shape returned by Room for a per-app aggregate over a time window. */
data class AppUsageAggregateRow(
    val packageName: String,
    val wifiRx: Long,
    val wifiTx: Long,
    val mobileRx: Long,
    val mobileTx: Long,
    val otherRx: Long,
    val otherTx: Long,
    val foregroundBytes: Long,
    val backgroundBytes: Long,
    val lastActiveAt: Long
)

/** Row shape for a single bucketed point on a history chart. */
data class UsageBucketRow(
    val bucketLabel: String,
    val bucketStart: Long,
    val rxBytes: Long,
    val txBytes: Long
)

/** Device-wide total for a time window. */
data class TotalUsageRow(val rxBytes: Long, val txBytes: Long)
