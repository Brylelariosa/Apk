package com.netguardian.app.service

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.netguardian.app.MainActivity
import com.netguardian.app.NetGuardianApplication
import com.netguardian.app.R
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.FirewallState
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.IOException
import javax.inject.Inject

/**
 * Blocks internet access for specific apps without root, using the same technique tools like
 * NetGuard/AFWall+ use: capture only the *blocked* apps' traffic into a local VPN tunnel (via
 * [Builder.addAllowedApplication]), then never forward anything read from that tunnel anywhere.
 * Every other app is not part of the VPN at all and is completely unaffected - it's only the
 * blocked apps whose packets go in and are simply discarded, so their connections just time out.
 *
 * This deliberately does not attempt to parse/relay IP packets (that would be needed for an
 * *allow-listing* firewall or a traffic inspector); a pure sinkhole for a known, small set of
 * blocked apps doesn't need any of that complexity.
 */
@AndroidEntryPoint
class FirewallVpnService : VpnService() {

    @Inject lateinit var firewallRepository: FirewallRepository
    @Inject lateinit var firewallState: FirewallState

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var settingsJob: Job? = null
    private var drainJob: Job? = null
    private var tunnel: ParcelFileDescriptor? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification(0))
        settingsJob = serviceScope.launch {
            firewallRepository.settings
                .map { it.blockedPackages }
                .distinctUntilChanged()
                .collect { blocked -> rebuildTunnel(blocked) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    /** Called by the system if VPN control is taken over by another app or revoked by the user. */
    override fun onRevoke() {
        firewallState.publishError("VPN permission was revoked - another VPN app may have taken over.")
        stopSelfCleanly()
    }

    override fun onDestroy() {
        stopSelfCleanly()
        super.onDestroy()
    }

    private fun stopSelfCleanly() {
        settingsJob?.cancel()
        closeTunnel()
        serviceScope.cancel()
        firewallState.publishActive(false)
    }

    private fun rebuildTunnel(blockedPackages: Set<String>) {
        closeTunnel()

        if (blockedPackages.isEmpty()) {
            firewallState.publishActive(false)
            stopSelf()
            return
        }

        val builder = Builder()
            .setSession(getString(R.string.app_name))
            .addAddress(TUNNEL_IPV4_ADDRESS, 32)
            .addAddress(TUNNEL_IPV6_ADDRESS, 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .setMtu(1500)
            .setBlocking(true)

        var addedAny = false
        for (packageName in blockedPackages) {
            try {
                builder.addAllowedApplication(packageName)
                addedAny = true
            } catch (e: PackageManager.NameNotFoundException) {
                // App was uninstalled since being blocked; nothing to route for it.
            }
        }

        if (!addedAny) {
            firewallState.publishActive(false)
            stopSelf()
            return
        }

        val established = runCatching { builder.establish() }.getOrNull()
        if (established == null) {
            firewallState.publishActive(false)
            firewallState.publishError(
                "Couldn't start the firewall - VPN permission may be missing or another VPN is active."
            )
            stopSelf()
            return
        }

        tunnel = established
        firewallState.publishActive(true)
        updateNotification(blockedPackages.size)
        drainJob = serviceScope.launch(Dispatchers.IO) { drainAndDiscard(established) }
    }

    /**
     * Reads (and throws away) whatever the blocked apps try to send. Never writing anything
     * back is what makes this a sinkhole rather than a working connection: TCP handshakes never
     * complete, DNS queries never resolve, so those apps simply behave as if offline.
     */
    private suspend fun drainAndDiscard(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32 * 1024)
        try {
            while (kotlinx.coroutines.currentCoroutineContext().isActive) {
                val read = input.read(buffer)
                if (read < 0) break
            }
        } catch (e: IOException) {
            // Expected once the tunnel is torn down (its fd gets closed under us).
        }
    }

    private fun closeTunnel() {
        drainJob?.cancel()
        drainJob = null
        tunnel?.let { runCatching { it.close() } }
        tunnel = null
    }

    private fun updateNotification(blockedCount: Int) {
        val manager = ContextCompat.getSystemService(this, android.app.NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(blockedCount))
    }

    private fun buildNotification(blockedCount: Int): android.app.Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = if (blockedCount == 0) {
            "No apps blocked"
        } else {
            "Blocking internet access for $blockedCount app" + if (blockedCount == 1) "" else "s"
        }
        return NotificationCompat.Builder(this, NetGuardianApplication.FIREWALL_CHANNEL_ID)
            .setContentTitle("NetGuardian Firewall")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 43
        private const val TUNNEL_IPV4_ADDRESS = "10.223.10.1"
        private const val TUNNEL_IPV6_ADDRESS = "fd00:1:fd00:1:fd00:1:fd00:1"

        /** Null if VPN consent is already granted (safe to call [start] directly); otherwise an
         *  Intent the caller must launch for a result before the tunnel can be established. */
        fun prepareIntent(context: Context): Intent? = VpnService.prepare(context)

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, FirewallVpnService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FirewallVpnService::class.java))
        }
    }
}
