package com.netguardian.app.service

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.netguardian.app.MainActivity
import com.netguardian.app.NetGuardianApplication
import com.netguardian.app.R
import com.netguardian.app.data.model.FirewallMode
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.FirewallState
import com.netguardian.app.data.repository.ScheduleRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileInputStream
import java.io.IOException
import java.time.LocalDateTime
import javax.inject.Inject

/**
 * Blocks internet access for specific apps without root, using the same technique tools like
 * NetGuard/AFWall+ use: capture only the intended apps' traffic into a local VPN tunnel, then
 * never forward anything read from that tunnel anywhere. Every other app is unaffected.
 *
 * Two modes, both using the exact same sinkhole mechanism underneath:
 *  - Blocklist ([Builder.addAllowedApplication] for each blocked app): only those apps enter
 *    the tunnel and get cut off; everything else bypasses it and works normally.
 *  - Allowlist ([Builder.addDisallowedApplication] for each allowed app): only those apps are
 *    *excluded* from the tunnel and keep working normally; every other app on the device -
 *    including system apps like Google Play Services unless explicitly allowed - gets captured
 *    and cut off. This is the same mechanism, just inverted; the real risk with Allowlist mode
 *    isn't technical, it's that it affects the whole device by default, which the UI warns
 *    about before letting someone turn it on.
 *
 * This deliberately does not attempt to parse/relay IP packets (that would be needed to let
 * *allowed* traffic actually reach the network while still being inspected); a pure sinkhole
 * for a known set of apps doesn't need any of that complexity.
 */
@AndroidEntryPoint
class FirewallVpnService : VpnService() {

    @Inject lateinit var firewallRepository: FirewallRepository
    @Inject lateinit var scheduleRepository: ScheduleRepository
    @Inject lateinit var firewallState: FirewallState

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var settingsJob: Job? = null
    private var scheduleTickerJob: Job? = null
    private var drainJob: Job? = null
    private var tunnel: ParcelFileDescriptor? = null

    private var latestMode: FirewallMode = FirewallMode.BLOCKLIST
    private var latestManualPackages: Set<String> = emptySet()
    private var latestScheduledPackages: Set<String> = emptySet()

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification(0))

        settingsJob = serviceScope.launch {
            firewallRepository.settings.distinctUntilChanged().collect { settings ->
                latestMode = settings.mode
                latestManualPackages = settings.activePackages
                // Deliberately broad: if rebuilding the tunnel throws anything unexpected here
                // and it isn't caught, it kills this collector coroutine entirely - meaning the
                // firewall would freeze on whatever list it had *before* the crash, and every
                // future change would silently stop taking effect until the app restarted. That
                // failure mode is worse than any single bad package, so nothing here is allowed
                // to escape uncaught.
                runCatching { recomputeAndRebuild() }.onFailure { e ->
                    firewallState.publishError("Firewall update failed: ${e.message ?: e::class.simpleName}")
                }
            }
        }

        // Schedules are re-evaluated every minute (not just when settings change), since the
        // same schedule config becomes active/inactive purely by the clock moving forward.
        scheduleTickerJob = serviceScope.launch {
            while (isActive) {
                val allSchedules = scheduleRepository.schedules.value
                val scheduledPackages = allSchedules
                    .filter { it.isActiveAt(LocalDateTime.now()) }
                    .flatMap { it.packageNames }
                    .toSet()
                if (scheduledPackages != latestScheduledPackages) {
                    latestScheduledPackages = scheduledPackages
                    runCatching { recomputeAndRebuild() }.onFailure { e ->
                        firewallState.publishError("Firewall update failed: ${e.message ?: e::class.simpleName}")
                    }
                }
                delay(SCHEDULE_CHECK_INTERVAL_MS)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    /** Called by the system if VPN control is taken over by another app or revoked by the user. */
    override fun onRevoke() {
        firewallState.publishError("VPN permission was revoked - another VPN app may have taken over.")
        stopSelfCleanly()
    }

    override fun onDestroy() {
        stopSelfCleanly()
        super.onDestroy()
    }

    private fun stopSelfCleanly() {
        settingsJob?.cancel()
        scheduleTickerJob?.cancel()
        closeTunnel()
        serviceScope.cancel()
        firewallState.publishActive(false)
    }

    /**
     * Schedules only ever *add* apps to the Blocklist-mode effective set (blocking specific apps
     * during specific hours is the supported use case); they don't apply in Allowlist mode,
     * where "only let these apps through" doesn't have an obvious schedule-driven analog.
     */
    private fun recomputeAndRebuild() {
        val effective = when (latestMode) {
            FirewallMode.BLOCKLIST -> latestManualPackages + latestScheduledPackages
            FirewallMode.ALLOWLIST -> latestManualPackages
        }
        rebuildTunnel(latestMode, effective)
    }

    private fun rebuildTunnel(mode: FirewallMode, packages: Set<String>) {
        closeTunnel()

        if (packages.isEmpty()) {
            firewallState.publishActive(false)
            stopSelf()
            return
        }

        val builder = Builder()
            .setSession(getString(R.string.app_name))
            .addAddress(TUNNEL_IPV4_ADDRESS, 32)
            .addAddress(TUNNEL_IPV6_ADDRESS, 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .setMtu(1500)
            .setBlocking(true)

        var addedCount = 0
        var failedCount = 0
        for (packageName in packages) {
            try {
                when (mode) {
                    FirewallMode.BLOCKLIST -> builder.addAllowedApplication(packageName)
                    FirewallMode.ALLOWLIST -> builder.addDisallowedApplication(packageName)
                }
                addedCount++
            } catch (e: PackageManager.NameNotFoundException) {
                // App was uninstalled since being added to the list; nothing to route for it.
                failedCount++
            } catch (e: UnsupportedOperationException) {
                // Per VpnService.Builder's own docs, this is only thrown if addAllowedApplication
                // and addDisallowedApplication are mixed on the same builder - which the mode
                // branch above never does, but catching it defensively still means a single
                // unexpected case can't abort the rest of the tunnel from being built.
                failedCount++
            }
        }

        if (addedCount == 0) {
            firewallState.publishActive(false)
            if (failedCount > 0) {
                firewallState.publishError("Couldn't apply the firewall list - none of the selected apps could be added.")
            }
            stopSelf()
            return
        }

        val established = runCatching { builder.establish() }.getOrNull()
        if (established == null) {
            firewallState.publishActive(false)
            firewallState.publishError(
                "Couldn't start the firewall - VPN permission may be missing or another VPN is active."
            )
            stopSelf()
            return
        }

        tunnel = established
        firewallState.publishActive(true)
        if (failedCount > 0) {
            firewallState.publishError(
                "Firewall is active, but $failedCount of ${packages.size} selected apps couldn't be applied."
            )
        }
        updateNotification(mode, addedCount)
        drainJob = serviceScope.launch(Dispatchers.IO) { drainAndDiscard(established) }
    }

    /**
     * Reads (and throws away) whatever the blocked-from-network apps try to send. Never writing
     * anything back is what makes this a sinkhole rather than a working connection: TCP
     * handshakes never complete, DNS queries never resolve, so those apps simply behave as if
     * offline.
     */
    private suspend fun drainAndDiscard(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val buffer = ByteArray(32 * 1024)
        try {
            while (kotlinx.coroutines.currentCoroutineContext().isActive) {
                val read = input.read(buffer)
                if (read < 0) break
            }
        } catch (e: IOException) {
            // Expected once the tunnel is torn down (its fd gets closed under us).
        }
    }

    private fun closeTunnel() {
        drainJob?.cancel()
        drainJob = null
        tunnel?.let { runCatching { it.close() } }
        tunnel = null
    }

    private fun updateNotification(mode: FirewallMode, count: Int) {
        val manager = ContextCompat.getSystemService(this, android.app.NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(count, mode))
    }

    private fun buildNotification(count: Int, mode: FirewallMode = FirewallMode.BLOCKLIST): android.app.Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = when {
            count == 0 -> "No apps blocked"
            mode == FirewallMode.BLOCKLIST ->
                "Blocking internet access for $count app" + if (count == 1) "" else "s"
            else ->
                "Only $count app" + (if (count == 1) "" else "s") + " allowed online - everything else is blocked"
        }
        return NotificationCompat.Builder(this, NetGuardianApplication.FIREWALL_CHANNEL_ID)
            .setContentTitle("NetGuardian Firewall")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openAppIntent)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 43
        private const val TUNNEL_IPV4_ADDRESS = "10.223.10.1"
        private const val TUNNEL_IPV6_ADDRESS = "fd00:1:fd00:1:fd00:1:fd00:1"
        private const val SCHEDULE_CHECK_INTERVAL_MS = 60_000L

        /** Null if VPN consent is already granted (safe to call [start] directly); otherwise an
         *  Intent the caller must launch for a result before the tunnel can be established. */
        fun prepareIntent(context: Context): Intent? = VpnService.prepare(context)

        /**
         * Returns null on success, or a description of what went wrong. `startForegroundService`
         * can genuinely throw - most commonly Android's background-service-start restrictions,
         * which reject the call if it happens outside a window where the app is allowed to start
         * one. Every call site should surface a non-null result rather than assume this always
         * succeeds: silently swallowing a failure here means the service never reaches
         * `onCreate()` at all, so there's no notification, no error, nothing - exactly the
         * "nothing visibly happens" failure mode that's much harder to diagnose than a shown
         * error message.
         */
        fun start(context: Context): String? = try {
            ContextCompat.startForegroundService(context, Intent(context, FirewallVpnService::class.java))
            null
        } catch (e: Exception) {
            "Couldn't start the firewall service: ${e.message ?: e::class.simpleName}"
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FirewallVpnService::class.java))
        }
    }
}
