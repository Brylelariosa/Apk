package com.netguardian.app.data.util

import android.net.TrafficStats
import javax.inject.Inject
import javax.inject.Singleton

data class ByteCounters(val rxBytes: Long, val txBytes: Long)

/**
 * [TrafficStats] exposes cumulative-since-boot kernel counters per UID. Wrapping the static
 * calls behind an interface-like class keeps [com.netguardian.app.service.NetworkMonitorService]
 * unit-testable and gives one place to handle the "unsupported" (-1) sentinel Android returns
 * on some devices/UIDs.
 */
@Singleton
class TrafficStatsSampler @Inject constructor() {

    fun sampleUid(uid: Int): ByteCounters {
        val rx = TrafficStats.getUidRxBytes(uid).takeIf { it >= 0 } ?: 0L
        val tx = TrafficStats.getUidTxBytes(uid).takeIf { it >= 0 } ?: 0L
        return ByteCounters(rx, tx)
    }

    fun sampleDeviceTotal(): ByteCounters {
        val rx = TrafficStats.getTotalRxBytes().takeIf { it >= 0 } ?: 0L
        val tx = TrafficStats.getTotalTxBytes().takeIf { it >= 0 } ?: 0L
        return ByteCounters(rx, tx)
    }
}
