package com.netguardian.app.data.util

import android.net.TrafficStats
import javax.inject.Inject
import javax.inject.Singleton

data class ByteCounters(val rxBytes: Long, val txBytes: Long)

/**
 * [TrafficStats] exposes cumulative-since-boot kernel counters, but only its device-wide totals
 * are used here. Its per-UID calls (`getUidRxBytes`/`getUidTxBytes`) are deliberately NOT used
 * for other apps: Android's own docs for network-usage APIs are explicit that, by default, an
 * app can only see its *own* traffic through those calls - see [NetworkStatsProvider] for how
 * per-app numbers are actually sourced (via the Usage Access-gated `NetworkStatsManager`).
 */
@Singleton
class TrafficStatsSampler @Inject constructor() {

    fun sampleDeviceTotal(): ByteCounters {
        val rx = TrafficStats.getTotalRxBytes().takeIf { it >= 0 } ?: 0L
        val tx = TrafficStats.getTotalTxBytes().takeIf { it >= 0 } ?: 0L
        return ByteCounters(rx, tx)
    }
}
