package com.netguardian.app.ui.apps

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.RemoveCircleOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.core.graphics.drawable.toBitmap
import com.netguardian.app.data.model.AppSortOrder
import com.netguardian.app.data.model.FirewallMode
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.ui.components.EmptyState
import com.netguardian.app.ui.components.PullToRefreshBox
import com.netguardian.app.ui.components.rememberVpnPermissionRequester
import com.netguardian.app.ui.theme.CardCornerRadius

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(
    onOpenApp: (String) -> Unit,
    viewModel: AppsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val requestVpnPermission = rememberVpnPermissionRequester()
    val mode = uiState.firewallMode

    Scaffold(
        topBar = {
            if (uiState.isSelectionMode) {
                TopAppBar(
                    title = { Text("${uiState.selectedPackages.size} selected") },
                    navigationIcon = {
                        IconButton(onClick = { viewModel.exitSelectionMode() }) {
                            Icon(Icons.Filled.Close, contentDescription = "Cancel selection")
                        }
                    },
                    actions = {
                        TextButton(onClick = { viewModel.removeSelectedFromActiveList() }) {
                            Text(if (mode == FirewallMode.ALLOWLIST) "Disallow" else "Unblock")
                        }
                        TextButton(onClick = {
                            requestVpnPermission { viewModel.addSelectedToActiveList(context) }
                        }) {
                            Text(if (mode == FirewallMode.ALLOWLIST) "Allow" else "Block")
                        }
                    }
                )
            } else {
                TopAppBar(
                    title = { Text("Apps") },
                    actions = {
                        if (uiState.rows.isNotEmpty()) {
                            IconButton(onClick = {
                                uiState.rows.firstOrNull()?.appInfo?.packageName?.let {
                                    // Entering selection mode needs a starting selection; using
                                    // the top app avoids a separate "select mode with nothing
                                    // selected yet" state that would need its own empty styling.
                                    viewModel.enterSelectionMode(it)
                                }
                            }) {
                                Icon(Icons.Filled.Checklist, contentDescription = "Select apps")
                            }
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            if (!uiState.isSelectionMode) {
                SearchAndSortBar(
                    query = uiState.searchQuery,
                    onQueryChange = viewModel::onSearchQueryChanged,
                    sortOrder = uiState.sortOrder,
                    onSortOrderChange = viewModel::onSortOrderChanged,
                    mode = mode
                )
                if (mode == FirewallMode.ALLOWLIST) {
                    AllowlistHint()
                }
                val blockedRows = uiState.rows.filter { it.isBlocked }
                if (blockedRows.isNotEmpty()) {
                    BlockedAppsSummary(
                        blockedRows = blockedRows,
                        // "Un-blocking" means different membership depending on mode: remove
                        // from the block list in Blocklist mode, but *add* to the allow list in
                        // Allowlist mode (since membership there is what lets an app through).
                        onUnblock = { packageName ->
                            val targetMembership = mode == FirewallMode.ALLOWLIST
                            if (targetMembership) {
                                requestVpnPermission {
                                    viewModel.setActiveListMembership(context, packageName, true)
                                }
                            } else {
                                viewModel.setActiveListMembership(context, packageName, false)
                            }
                        },
                        onOpenApp = onOpenApp
                    )
                }
            }

            PullToRefreshBox(refreshing = uiState.isRefreshing, onRefresh = { viewModel.refresh() }) {
                if (uiState.rows.isEmpty() && !uiState.isLoading) {
                    EmptyState(message = "No apps match your search.")
                } else {
                    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
                        items(uiState.rows, key = { it.appInfo.packageName }) { row ->
                            AppRow(
                                row = row,
                                mode = mode,
                                isSelectionMode = uiState.isSelectionMode,
                                isSelected = uiState.selectedPackages.contains(row.appInfo.packageName),
                                onClick = {
                                    if (uiState.isSelectionMode) {
                                        viewModel.toggleSelected(row.appInfo.packageName)
                                    } else {
                                        onOpenApp(row.appInfo.packageName)
                                    }
                                },
                                onLongClick = {
                                    if (!uiState.isSelectionMode) {
                                        viewModel.enterSelectionMode(row.appInfo.packageName)
                                    }
                                },
                                onToggleMembership = { addToList ->
                                    if (addToList) {
                                        requestVpnPermission {
                                            viewModel.setActiveListMembership(context, row.appInfo.packageName, true)
                                        }
                                    } else {
                                        viewModel.setActiveListMembership(context, row.appInfo.packageName, false)
                                    }
                                },
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AllowlistHint() {
    Text(
        text = "Allowlist mode: tap \"Allow\" on the apps that should keep working. Everything else is blocked.",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.error,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    )
}

@Composable
private fun BlockedAppsSummary(
    blockedRows: List<AppRowUiModel>,
    onUnblock: (String) -> Unit,
    onOpenApp: (String) -> Unit
) {
    Column(modifier = Modifier.padding(bottom = 8.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Block,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.error
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Blocked (${blockedRows.size})",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.error
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        androidx.compose.foundation.lazy.LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(blockedRows, key = { it.appInfo.packageName }) { row ->
                BlockedAppChip(
                    row = row,
                    onUnblock = { onUnblock(row.appInfo.packageName) },
                    onClick = { onOpenApp(row.appInfo.packageName) }
                )
            }
        }
    }
}

@Composable
private fun BlockedAppChip(row: AppRowUiModel, onUnblock: () -> Unit, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f))
            .clickable(onClick = onClick)
            .padding(start = 6.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val drawable = row.appInfo.icon
        if (drawable != null) {
            val bitmap = remember(row.appInfo.packageName) { drawable.toBitmap(80, 80).asImageBitmap() }
            Image(
                painter = BitmapPainter(bitmap),
                contentDescription = row.appInfo.label,
                modifier = Modifier.size(22.dp).clip(CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(
            text = row.appInfo.label,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            color = MaterialTheme.colorScheme.onErrorContainer
        )
        IconButton(onClick = onUnblock, modifier = Modifier.size(28.dp)) {
            Icon(
                imageVector = Icons.Filled.Close,
                contentDescription = "Unblock ${row.appInfo.label}",
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onErrorContainer
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchAndSortBar(
    query: String,
    onQueryChange: (String) -> Unit,
    sortOrder: AppSortOrder,
    onSortOrderChange: (AppSortOrder) -> Unit,
    mode: FirewallMode
) {
    // BLOCKED_FIRST sorts by whichever list matters for the current mode (see
    // AppsUiState.filteredAndSorted) - the label should say what it actually does.
    fun labelFor(option: AppSortOrder): String =
        if (option == AppSortOrder.BLOCKED_FIRST && mode == FirewallMode.ALLOWLIST) "Allowed First" else option.label

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search apps") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        var menuExpanded by remember { mutableStateOf(false) }
        Box {
            TextButton(onClick = { menuExpanded = true }) {
                Text("Sort: ${labelFor(sortOrder)}")
                Icon(Icons.Filled.ArrowDropDown, contentDescription = "Change sort order")
            }
            DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                AppSortOrder.values().forEach { option ->
                    DropdownMenuItem(
                        text = { Text(labelFor(option)) },
                        onClick = {
                            onSortOrderChange(option)
                            menuExpanded = false
                        }
                    )
                }
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
private fun AppRow(
    row: AppRowUiModel,
    mode: FirewallMode,
    isSelectionMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleMembership: (addToList: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(
            containerColor = if (row.isBlocked) {
                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (isSelectionMode) {
                Checkbox(checked = isSelected, onCheckedChange = { onClick() })
                Spacer(modifier = Modifier.width(4.dp))
            }
            val drawable = row.appInfo.icon
            if (drawable != null) {
                val bitmap = remember(row.appInfo.packageName) { drawable.toBitmap(96, 96).asImageBitmap() }
                Image(
                    painter = BitmapPainter(bitmap),
                    contentDescription = row.appInfo.label,
                    modifier = Modifier.size(40.dp).clip(CircleShape)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = row.appInfo.label, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                    if (row.isBlocked) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Blocked",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    } else if (mode == FirewallMode.ALLOWLIST && row.isActiveListMember) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Allowed",
                            style = MaterialTheme.typography.labelSmall,
                            color = com.netguardian.app.ui.theme.ActiveGreen
                        )
                    }
                }
                Text(
                    text = row.appInfo.packageName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatText(label = "Today", value = ByteFormatter.formatBytes(row.todayBytes))
                    StatText(label = "Month", value = ByteFormatter.formatBytes(row.monthBytes))
                    StatText(label = "Wi-Fi", value = ByteFormatter.formatBytes(row.totalWifiBytes))
                    StatText(label = "Mobile", value = ByteFormatter.formatBytes(row.totalMobileBytes))
                }
            }
            if (!isSelectionMode) {
                MembershipToggleButton(
                    mode = mode,
                    isMember = row.isActiveListMember,
                    appLabel = row.appInfo.label,
                    onToggle = onToggleMembership
                )
            }
        }
    }
}

/**
 * The button's meaning flips with [mode], but always toggles raw list membership directly
 * (never an inverted "blocked" boolean) - that's what makes it always do something visible when
 * tapped, in every mode, regardless of whether the relevant list happens to be empty.
 */
@Composable
private fun MembershipToggleButton(
    mode: FirewallMode,
    isMember: Boolean,
    appLabel: String,
    onToggle: (addToList: Boolean) -> Unit
) {
    val (icon, description, tint) = when (mode) {
        FirewallMode.BLOCKLIST -> if (isMember) {
            Triple(Icons.Filled.LockOpen, "Unblock $appLabel", MaterialTheme.colorScheme.error)
        } else {
            Triple(Icons.Filled.Block, "Block $appLabel", MaterialTheme.colorScheme.onSurfaceVariant)
        }
        FirewallMode.ALLOWLIST -> if (isMember) {
            Triple(Icons.Filled.RemoveCircleOutline, "Remove $appLabel from allowed", MaterialTheme.colorScheme.error)
        } else {
            Triple(Icons.Filled.CheckCircle, "Allow $appLabel", com.netguardian.app.ui.theme.ActiveGreen)
        }
    }
    IconButton(onClick = { onToggle(!isMember) }) {
        Icon(imageVector = icon, contentDescription = description, tint = tint)
    }
}

@Composable
private fun StatText(label: String, value: String) {
    Column {
        Text(text = value, style = MaterialTheme.typography.labelMedium)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
