package com.netguardian.app.ui.apps

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.core.graphics.drawable.toBitmap
import com.netguardian.app.data.model.AppSortOrder
import com.netguardian.app.data.util.ByteFormatter
import com.netguardian.app.ui.components.EmptyState
import com.netguardian.app.ui.components.PullToRefreshBox
import com.netguardian.app.ui.theme.CardCornerRadius

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(
    onOpenApp: (String) -> Unit,
    viewModel: AppsViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Apps") }) }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            SearchAndSortBar(
                query = uiState.searchQuery,
                onQueryChange = viewModel::onSearchQueryChanged,
                sortOrder = uiState.sortOrder,
                onSortOrderChange = viewModel::onSortOrderChanged
            )

            PullToRefreshBox(refreshing = uiState.isRefreshing, onRefresh = { viewModel.refresh() }) {
                if (uiState.rows.isEmpty() && !uiState.isLoading) {
                    EmptyState(message = "No apps match your search.")
                } else {
                    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
                        items(uiState.rows, key = { it.appInfo.packageName }) { row ->
                            AppRow(
                                row = row,
                                onClick = { onOpenApp(row.appInfo.packageName) },
                                modifier = Modifier.padding(bottom = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SearchAndSortBar(
    query: String,
    onQueryChange: (String) -> Unit,
    sortOrder: AppSortOrder,
    onSortOrderChange: (AppSortOrder) -> Unit
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search apps") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )
        Spacer(modifier = Modifier.height(8.dp))
        var menuExpanded by remember { mutableStateOf(false) }
        Box {
            TextButton(onClick = { menuExpanded = true }) {
                Text("Sort: ${sortOrder.label}")
                Icon(Icons.Filled.ArrowDropDown, contentDescription = "Change sort order")
            }
            DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                AppSortOrder.values().forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option.label) },
                        onClick = {
                            onSortOrderChange(option)
                            menuExpanded = false
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun AppRow(row: AppRowUiModel, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            val drawable = row.appInfo.icon
            if (drawable != null) {
                val bitmap = remember(row.appInfo.packageName) { drawable.toBitmap(96, 96).asImageBitmap() }
                androidx.compose.foundation.Image(
                    painter = BitmapPainter(bitmap),
                    contentDescription = row.appInfo.label,
                    modifier = Modifier.size(40.dp).clip(CircleShape)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = row.appInfo.label, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                Text(
                    text = row.appInfo.packageName,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatText(label = "Today", value = ByteFormatter.formatBytes(row.todayBytes))
                    StatText(label = "Month", value = ByteFormatter.formatBytes(row.monthBytes))
                    StatText(label = "Wi-Fi", value = ByteFormatter.formatBytes(row.totalWifiBytes))
                    StatText(label = "Mobile", value = ByteFormatter.formatBytes(row.totalMobileBytes))
                }
            }
        }
    }
}

@Composable
private fun StatText(label: String, value: String) {
    Column {
        Text(text = value, style = MaterialTheme.typography.labelMedium)
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
