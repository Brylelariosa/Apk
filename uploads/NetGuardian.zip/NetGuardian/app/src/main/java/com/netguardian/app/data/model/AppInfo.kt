package com.netguardian.app.data.model

import android.graphics.drawable.Drawable

/** Static metadata about an installed application, resolved once via PackageManager. */
data class AppInfo(
    val packageName: String,
    val uid: Int,
    val label: String,
    val icon: Drawable?,
    val isSystemApp: Boolean
)

/** Real-time bandwidth state for one app, rebuilt every monitoring tick. */
data class LiveAppUsage(
    val appInfo: AppInfo,
    val downloadBps: Long,
    val uploadBps: Long,
    val sessionRxBytes: Long,
    val sessionTxBytes: Long,
    val isForeground: Boolean,
    val activityState: ActivityState,
    val recentSamples: List<Float> = emptyList()
)

/** Current device-wide connection snapshot shown on the Dashboard. */
data class DeviceNetworkStatus(
    val isConnected: Boolean,
    val networkType: NetworkType,
    val downloadBps: Long,
    val uploadBps: Long,
    val ipAddress: String?,
    val signalStrengthPercent: Int?
)

/** Aggregated totals used for the "Today" / "This hour" / "Session" cards. */
data class TotalUsage(val rxBytes: Long, val txBytes: Long) {
    val totalBytes: Long get() = rxBytes + txBytes
    companion object { val ZERO = TotalUsage(0, 0) }
}

/** Per-app rollup produced by aggregation queries over historical snapshots. */
data class AppUsageAggregate(
    val packageName: String,
    val wifiRxBytes: Long,
    val wifiTxBytes: Long,
    val mobileRxBytes: Long,
    val mobileTxBytes: Long,
    val foregroundBytes: Long,
    val backgroundBytes: Long,
    val lastActiveAt: Long
) {
    val totalBytes: Long get() = wifiRxBytes + wifiTxBytes + mobileRxBytes + mobileTxBytes
}

/** One point on a historical bar/line chart (e.g. one day, one week bucket). */
data class UsageBucket(val label: String, val bucketStartMillis: Long, val rxBytes: Long, val txBytes: Long)
