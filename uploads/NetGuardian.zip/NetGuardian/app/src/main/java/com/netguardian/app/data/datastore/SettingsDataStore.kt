package com.netguardian.app.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.model.ThemeMode
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "netguardian_settings")

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val refreshIntervalSeconds: Int = 2,
    val dataUnit: DataUnit = DataUnit.MBPS_BYTES,
    val animationsEnabled: Boolean = true,
    val liveGraphEnabled: Boolean = true,
    val startOnBoot: Boolean = false,
    val hasCompletedOnboarding: Boolean = false
)

/** Thin, testable wrapper around Jetpack DataStore for every user-configurable preference. */
@Singleton
class SettingsDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val REFRESH_INTERVAL = intPreferencesKey("refresh_interval_seconds")
        val DATA_UNIT = stringPreferencesKey("data_unit")
        val ANIMATIONS_ENABLED = booleanPreferencesKey("animations_enabled")
        val LIVE_GRAPH_ENABLED = booleanPreferencesKey("live_graph_enabled")
        val START_ON_BOOT = booleanPreferencesKey("start_on_boot")
        val HAS_COMPLETED_ONBOARDING = booleanPreferencesKey("has_completed_onboarding")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
                ?: ThemeMode.SYSTEM,
            refreshIntervalSeconds = prefs[Keys.REFRESH_INTERVAL] ?: 2,
            dataUnit = prefs[Keys.DATA_UNIT]?.let { runCatching { DataUnit.valueOf(it) }.getOrNull() }
                ?: DataUnit.MBPS_BYTES,
            animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: true,
            liveGraphEnabled = prefs[Keys.LIVE_GRAPH_ENABLED] ?: true,
            startOnBoot = prefs[Keys.START_ON_BOOT] ?: false,
            hasCompletedOnboarding = prefs[Keys.HAS_COMPLETED_ONBOARDING] ?: false
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setRefreshInterval(seconds: Int) {
        context.dataStore.edit { it[Keys.REFRESH_INTERVAL] = seconds }
    }

    suspend fun setDataUnit(unit: DataUnit) {
        context.dataStore.edit { it[Keys.DATA_UNIT] = unit.name }
    }

    suspend fun setAnimationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ANIMATIONS_ENABLED] = enabled }
    }

    suspend fun setLiveGraphEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.LIVE_GRAPH_ENABLED] = enabled }
    }

    suspend fun setStartOnBoot(enabled: Boolean) {
        context.dataStore.edit { it[Keys.START_ON_BOOT] = enabled }
    }

    suspend fun setHasCompletedOnboarding(completed: Boolean) {
        context.dataStore.edit { it[Keys.HAS_COMPLETED_ONBOARDING] = completed }
    }
}
