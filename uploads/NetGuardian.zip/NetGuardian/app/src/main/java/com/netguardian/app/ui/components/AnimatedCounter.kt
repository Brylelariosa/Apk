package com.netguardian.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import com.netguardian.app.data.model.DataUnit
import com.netguardian.app.data.util.ByteFormatter

/**
 * Animates a cumulative byte value smoothly between updates instead of snapping, per the
 * "animated number counters" requirement. Formatting stays in [ByteFormatter] so this composable
 * only owns the interpolation.
 */
@Composable
fun AnimatedByteCounter(
    bytes: Long,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current
) {
    val animated by animateFloatAsState(
        targetValue = bytes.toFloat(),
        animationSpec = spring(dampingRatio = 0.85f, stiffness = 120f),
        label = "byteCounter"
    )
    Text(text = ByteFormatter.formatBytes(animated.toLong()), style = style, modifier = modifier)
}

@Composable
fun AnimatedSpeedText(
    bytesPerSecond: Long,
    dataUnit: DataUnit,
    modifier: Modifier = Modifier,
    style: TextStyle = LocalTextStyle.current
) {
    val animated by animateFloatAsState(
        targetValue = bytesPerSecond.toFloat(),
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 150f),
        label = "speedText"
    )
    Text(text = ByteFormatter.formatSpeed(animated.toLong(), dataUnit), style = style, modifier = modifier)
}
