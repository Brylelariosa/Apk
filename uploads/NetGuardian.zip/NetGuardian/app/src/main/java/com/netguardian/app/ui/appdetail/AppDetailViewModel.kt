package com.netguardian.app.ui.appdetail

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.datastore.AppSettings
import com.netguardian.app.data.datastore.DataCapSettings
import com.netguardian.app.data.datastore.FirewallSettings
import com.netguardian.app.data.model.AppUsageAggregate
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.model.UsageBucket
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.DataCapRepository
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.AppIconCache
import com.netguardian.app.data.util.NetworkPermissionsProvider
import com.netguardian.app.service.FirewallVpnService
import com.netguardian.app.ui.navigation.Destination
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class AppDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val appUsageRepository: AppUsageRepository,
    private val settingsRepository: SettingsRepository,
    private val firewallRepository: FirewallRepository,
    private val dataCapRepository: DataCapRepository,
    private val appIconCache: AppIconCache,
    private val networkPermissionsProvider: NetworkPermissionsProvider
) : ViewModel() {

    private val packageName: String = savedStateHandle.get<String>(Destination.AppDetail.ARG_PACKAGE_NAME).orEmpty()
    private val historyRange = MutableStateFlow(HistoryRange.DAILY)

    private val historyBucketsFlow = historyRange.flatMapLatest {
        appUsageRepository.observeAppHistoryBuckets(packageName, it)
    }

    val uiState: StateFlow<AppDetailUiState> = combine(
        appUsageRepository.observeAppAggregate(packageName),
        appUsageRepository.observeTodayAppAggregate(packageName),
        appUsageRepository.liveAppUsages,
        historyRange,
        historyBucketsFlow,
        settingsRepository.settings,
        firewallRepository.settings,
        dataCapRepository.settings
    ) { values ->
        val allTimeAggregate = values[0] as AppUsageAggregate?
        val todayAggregate = values[1] as AppUsageAggregate?
        @Suppress("UNCHECKED_CAST") val liveUsages = values[2] as List<LiveAppUsage>
        val range = values[3] as HistoryRange
        @Suppress("UNCHECKED_CAST") val buckets = values[4] as List<UsageBucket>
        val settings = values[5] as AppSettings
        val firewallSettings = values[6] as FirewallSettings
        val dataCapSettings = values[7] as DataCapSettings

        buildState(
            allTimeAggregate = allTimeAggregate,
            todayAggregate = todayAggregate,
            liveUsages = liveUsages,
            range = range,
            buckets = buckets,
            settings = settings,
            firewallSettings = firewallSettings,
            dataCapSettings = dataCapSettings
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppDetailUiState())

    private fun buildState(
        allTimeAggregate: AppUsageAggregate?,
        todayAggregate: AppUsageAggregate?,
        liveUsages: List<LiveAppUsage>,
        range: HistoryRange,
        buckets: List<UsageBucket>,
        settings: AppSettings,
        firewallSettings: FirewallSettings,
        dataCapSettings: DataCapSettings
    ): AppDetailUiState {
        val liveMatch = liveUsages.firstOrNull { it.appInfo.packageName == packageName }
        val appInfo = liveMatch?.appInfo ?: appIconCache.get(packageName)
        val isBlocked = firewallSettings.isAppBlocked(packageName)

        return AppDetailUiState(
            appInfo = appInfo,
            isCurrentlyActive = liveMatch != null,
            currentDownloadBps = liveMatch?.downloadBps ?: 0,
            currentUploadBps = liveMatch?.uploadBps ?: 0,
            historyRange = range,
            historyBuckets = buckets,
            foregroundBytes = allTimeAggregate?.foregroundBytes ?: 0,
            backgroundBytes = allTimeAggregate?.backgroundBytes ?: 0,
            lastActiveAt = allTimeAggregate?.lastActiveAt ?: 0,
            networkingPermissions = networkPermissionsProvider.networkingPermissionsFor(packageName),
            dataUnit = settings.dataUnit,
            firewallMode = firewallSettings.mode,
            isBlocked = isBlocked,
            isActiveListMember = firewallSettings.isAppActiveListMember(packageName),
            isAutoBlockedByCap = dataCapSettings.autoBlockedPackages.contains(packageName),
            todayUsageBytes = todayAggregate?.totalBytes ?: 0,
            dataCapBytes = dataCapSettings.perAppCapsBytes[packageName],
            isLoading = false
        )
    }

    fun onRangeChanged(range: HistoryRange) {
        historyRange.value = range
    }

    /** Adds/removes this app from whichever list the current firewall mode reads from. Call
     *  [isMember] = true only after VPN consent is confirmed (see rememberVpnPermissionRequester). */
    fun setActiveListMembership(context: android.content.Context, isMember: Boolean) {
        viewModelScope.launch {
            firewallRepository.setActiveListMembership(packageName, isMember)
            if (isMember) FirewallVpnService.start(context)
        }
    }

    fun setDataCap(capBytes: Long?) {
        viewModelScope.launch { dataCapRepository.setAppCap(packageName, capBytes) }
    }
}
