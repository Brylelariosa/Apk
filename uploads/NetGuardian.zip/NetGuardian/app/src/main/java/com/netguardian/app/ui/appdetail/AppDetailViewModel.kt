package com.netguardian.app.ui.appdetail

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.netguardian.app.data.datastore.AppSettings
import com.netguardian.app.data.model.AppUsageAggregate
import com.netguardian.app.data.model.HistoryRange
import com.netguardian.app.data.model.LiveAppUsage
import com.netguardian.app.data.model.UsageBucket
import com.netguardian.app.data.repository.AppUsageRepository
import com.netguardian.app.data.repository.FirewallRepository
import com.netguardian.app.data.repository.SettingsRepository
import com.netguardian.app.data.util.AppIconCache
import com.netguardian.app.data.util.NetworkPermissionsProvider
import com.netguardian.app.service.FirewallVpnService
import com.netguardian.app.ui.navigation.Destination
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class AppDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val appUsageRepository: AppUsageRepository,
    private val settingsRepository: SettingsRepository,
    private val firewallRepository: FirewallRepository,
    private val appIconCache: AppIconCache,
    private val networkPermissionsProvider: NetworkPermissionsProvider
) : ViewModel() {

    private val packageName: String = savedStateHandle.get<String>(Destination.AppDetail.ARG_PACKAGE_NAME).orEmpty()
    private val historyRange = MutableStateFlow(HistoryRange.DAILY)

    private val historyBucketsFlow = historyRange.flatMapLatest {
        appUsageRepository.observeAppHistoryBuckets(packageName, it)
    }

    private val baseState: Flow<AppDetailUiState> = combine(
        appUsageRepository.observeAppAggregate(packageName),
        appUsageRepository.liveAppUsages,
        historyRange,
        historyBucketsFlow,
        settingsRepository.settings
    ) { aggregate, liveUsages, range, buckets, settings ->
        buildState(aggregate, liveUsages, range, buckets, settings)
    }

    val uiState: StateFlow<AppDetailUiState> = combine(
        baseState,
        firewallRepository.settings.map { it.blockedPackages.contains(packageName) }
    ) { base, isBlocked ->
        base.copy(isBlocked = isBlocked)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppDetailUiState())

    private fun buildState(
        aggregate: AppUsageAggregate?,
        liveUsages: List<LiveAppUsage>,
        range: HistoryRange,
        buckets: List<UsageBucket>,
        settings: AppSettings
    ): AppDetailUiState {
        val liveMatch = liveUsages.firstOrNull { it.appInfo.packageName == packageName }
        val appInfo = liveMatch?.appInfo ?: appIconCache.get(packageName)

        return AppDetailUiState(
            appInfo = appInfo,
            isCurrentlyActive = liveMatch != null,
            currentDownloadBps = liveMatch?.downloadBps ?: 0,
            currentUploadBps = liveMatch?.uploadBps ?: 0,
            historyRange = range,
            historyBuckets = buckets,
            foregroundBytes = aggregate?.foregroundBytes ?: 0,
            backgroundBytes = aggregate?.backgroundBytes ?: 0,
            lastActiveAt = aggregate?.lastActiveAt ?: 0,
            networkingPermissions = networkPermissionsProvider.networkingPermissionsFor(packageName),
            dataUnit = settings.dataUnit,
            isLoading = false
        )
    }

    fun onRangeChanged(range: HistoryRange) {
        historyRange.value = range
    }

    /** Call only after VPN consent is confirmed (see rememberVpnPermissionRequester). */
    fun setBlocked(context: android.content.Context, blocked: Boolean) {
        viewModelScope.launch {
            firewallRepository.setBlocked(packageName, blocked)
            if (blocked) FirewallVpnService.start(context)
        }
    }
}
