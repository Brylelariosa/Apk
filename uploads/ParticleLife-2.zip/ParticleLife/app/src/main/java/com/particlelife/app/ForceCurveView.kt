package com.particlelife.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View

/**
 * Draws the force-vs-distance envelope that Repel/Gap/Distance control:
 * always-repulsive near r=0, a flat dead zone, then a hump rising to the
 * strongest possible attraction and fading to nothing at max range. The
 * hump shown is the +1 (strongest attract) envelope - an individual pair's
 * actual coefficient scales how tall its hump is, anywhere from this line
 * down through zero to an inverted (repel) hump; this just shows the
 * boundary shape those two sliders draw for every pair.
 *
 * Plain View + onDraw, not SurfaceView - this redraws only when a slider
 * changes (via setParams -> invalidate), not continuously like GameView.
 */
class ForceCurveView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var repelPercent = GameView.DEFAULT_REPEL_PERCENT
    private var gapPercent = GameView.DEFAULT_GAP_PERCENT
    private var range = GameView.DEFAULT_RANGE

    private val curvePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(225, 225, 235)
        strokeWidth = 4f
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val zeroLinePaint = Paint().apply {
        color = Color.rgb(80, 77, 100)
        strokeWidth = 2f
    }
    private val repelZonePaint = Paint().apply { color = Color.argb(70, 220, 60, 60) }
    private val gapZonePaint = Paint().apply { color = Color.argb(45, 120, 120, 140) }
    private val attractZonePaint = Paint().apply { color = Color.argb(70, 60, 210, 100) }
    private val axisLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(160, 158, 175)
        textSize = 18f
    }

    /** Repel/Gap are percents of range (matching the sliders); range is in world units, just shown as an axis label. */
    fun setParams(repelPercent: Int, gapPercent: Int, range: Int) {
        this.repelPercent = repelPercent
        this.gapPercent = gapPercent
        this.range = range
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val labelSpace = 20f
        val plotH = h - labelSpace
        val topY = plotH * 0.12f
        val bottomY = plotH * 0.88f
        val midY = plotH * 0.5f

        val repelEndFrac = (repelPercent / 100f).coerceIn(0f, 1f)
        val attractStartFrac = (repelEndFrac + gapPercent / 100f).coerceIn(0f, 0.98f)
        val repelEndX = w * repelEndFrac
        val attractStartX = w * attractStartFrac
        val peakX = attractStartX + (w - attractStartX) / 2f

        canvas.drawRect(0f, 0f, repelEndX, plotH, repelZonePaint)
        canvas.drawRect(repelEndX, 0f, attractStartX, plotH, gapZonePaint)
        canvas.drawRect(attractStartX, 0f, w, plotH, attractZonePaint)
        canvas.drawLine(0f, midY, w, midY, zeroLinePaint)

        val path = Path()
        path.moveTo(0f, bottomY)
        path.lineTo(repelEndX, midY)
        path.lineTo(attractStartX, midY)
        path.lineTo(peakX, topY)
        path.lineTo(w, midY)
        canvas.drawPath(path, curvePaint)

        canvas.drawText("0", 2f, h - 4f, axisLabelPaint)
        val rangeLabel = "${range}px"
        canvas.drawText(rangeLabel, w - axisLabelPaint.measureText(rangeLabel) - 2f, h - 4f, axisLabelPaint)
    }
}
