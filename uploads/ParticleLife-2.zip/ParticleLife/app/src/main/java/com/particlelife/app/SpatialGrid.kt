package com.particlelife.app

/**
 * Uniform spatial hash grid used to speed up neighbor lookups for the
 * particle-life force calculation.
 *
 * Cell size is set equal to the interaction radius, which means every
 * particle within range of a query point is guaranteed to live in the
 * 3x3 block of cells centered on the query point's own cell - so we
 * never need to scan the whole particle list, just those 9 buckets.
 */
class SpatialGrid(
    worldWidth: Float,
    worldHeight: Float,
    private val cellSize: Float
) {
    private val cols = (worldWidth / cellSize).toInt().coerceAtLeast(1) + 1
    private val rows = (worldHeight / cellSize).toInt().coerceAtLeast(1) + 1
    private val buckets = Array(cols * rows) { mutableListOf<Int>() }

    private fun indexFor(x: Float, y: Float): Int {
        val cx = (x / cellSize).toInt().coerceIn(0, cols - 1)
        val cy = (y / cellSize).toInt().coerceIn(0, rows - 1)
        return cy * cols + cx
    }

    /** Call once per frame before querying. */
    fun rebuild(particles: List<Particle>) {
        for (bucket in buckets) bucket.clear()
        for (i in particles.indices) {
            val p = particles[i]
            buckets[indexFor(p.x, p.y)].add(i)
        }
    }

    /** Invokes [action] with the index of every particle sharing or neighboring the cell at (x, y). */
    inline fun forEachNearby(x: Float, y: Float, action: (Int) -> Unit) {
        val cx = (x / cellSize).toInt().coerceIn(0, cols - 1)
        val cy = (y / cellSize).toInt().coerceIn(0, rows - 1)
        for (dy in -1..1) {
            val ny = cy + dy
            if (ny < 0 || ny >= rows) continue
            for (dx in -1..1) {
                val nx = cx + dx
                if (nx < 0 || nx >= cols) continue
                val bucket = buckets[ny * cols + nx]
                for (idx in bucket) action(idx)
            }
        }
    }
}
