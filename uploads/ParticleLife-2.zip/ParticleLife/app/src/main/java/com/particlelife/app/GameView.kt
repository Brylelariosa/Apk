package com.particlelife.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Particle Life: N species of particles, each pair of species has a signed
 * attraction coefficient. Every frame, every particle sums up forces from
 * nearby particles (weighted by that coefficient), integrates velocity with
 * friction, and moves. Random coefficients reliably produce clusters,
 * orbits, and chase/flee behavior - "life-like" motion with no explicit
 * rule for any of it.
 *
 * The world wraps at its edges (toroidal - no walls): a particle that exits
 * the right side re-enters on the left, and the force calculation uses
 * "minimum image" distance so pairs near opposite edges still interact
 * correctly across the seam, same technique used for periodic boundaries in
 * physics simulations. SpatialGrid's neighbor search wraps the same way.
 * Rendering also draws nearby wrapped copies of each particle (see the
 * tiling loop in draw()) so panning across the seam shows continuous
 * content instead of empty space.
 *
 * Camera: pinch to zoom (toward the pinch point, not just screen center),
 * drag to pan, Center button in the menu to reset. cameraX/cameraY are the
 * world coordinate shown at screen center; zoom is screen-px per world-unit.
 *
 * The force curve has three zones out to `interactionRange`, all adjustable
 * live via sliders in MainActivity - see forceAt():
 *   1. Repel  - always-repulsive zone near r=0, sized as a % of range.
 *   2. Gap    - optional dead zone right after Repel with zero force.
 *   3. Attract - ramps up to the rule coefficient, peaks at the midpoint of
 *      the remaining distance, back to 0 at interactionRange.
 *
 * The Rules overlay (toggled by the Rules button) doubles as an editor when
 * showing: tap a cell to nudge that specific pair's coefficient, tap one of
 * the 3 slots below the legend to load a saved rule set, or hold a slot to
 * save the current one there. Pausing (togglePause) freezes the physics but
 * keeps rendering/camera/rule-editing live, so you can freeze an interesting
 * moment and fine-tune the rules that produced it without them drifting
 * out from under you.
 *
 * The simulated world is larger than the visible screen (WORLD_SCALE).
 * PARTICLE_RADIUS_WORLD is a fixed world-space size, deliberately NOT
 * compensated for WORLD_SCALE - letting particles shrink a bit on screen
 * as WORLD_SCALE grows is what reads as "zoomed out to show more space."
 *
 * Runs its own render thread (matches the engine style used elsewhere:
 * SurfaceView + Runnable game loop, not Compose).
 *
 * Beyond the base attract/repel curve above, several optional behavior
 * layers can be toggled on top of the same per-pair rules - each one reuses
 * the attraction matrix and/or the existing spatial grid rather than
 * introducing a parallel simulation, so they compose instead of conflict:
 *
 *   - Preferred distance / Orbit: two more per-pair matrices alongside
 *     `attraction` (`preferredDistance`, `orbitStrength`), populated by the
 *     same randomize/mutate calls. A nonzero preferred distance adds a
 *     spring force settling that pair at an ideal ring radius instead of
 *     just attract-then-drift; a nonzero orbit strength adds a tangential
 *     (perpendicular-to-radius) force for genuine circular/spiral motion
 *     rather than incidental spin.
 *   - Alignment: local flocking - steers a particle's velocity toward the
 *     average heading of same-type neighbors already visited during the
 *     force pass, so it's a free extra accumulation in the existing
 *     neighbor loop, not a second pass over the grid.
 *   - Predator/Prey: no separate matrix at all - `chaseBoost` is derived
 *     from `attraction` itself (recomputeDerived()) by detecting pairs
 *     where one type strongly flees the other while the other strongly
 *     seeks it, then amplifying that pair's force. Any sufficiently
 *     asymmetric pair becomes an obvious chase/flee relationship.
 *   - Chemical trails: a separate coarse TrailField (much lower resolution
 *     than the particle simulation) that particles deposit into and steer
 *     by, using the same attraction matrix as "affinity" for whether a
 *     given species's trail attracts or repels.
 *   - Aging: a per-particle age counter that fades force response toward
 *     end of life, then respawns the particle - optional, off by default.
 *   - Friction is now a live-tunable slider instead of a constant; new
 *     forces still add to velocity (never replace it), so momentum/gliding
 *     behavior is preserved automatically as layers are added.
 *
 * All of the above default OFF (or, for preferred-distance/orbit, sparse -
 * only a fraction of pairs get a nonzero value on randomize) so existing
 * saves and existing behavior are unchanged until a person opts in.
 *
 * On top of all of that, particles now also collide as physical bodies
 * (resolveCollisions(), called at the end of update()): once two of them
 * are closer than their combined radius they get shoved apart and lose
 * some closing speed, regardless of species or the attract/repel sliders.
 * This is separate from - and always on top of - the Repel zone in
 * forceAt(), which is a smooth force and can still let particles slip
 * past each other; collision is a hard floor on top of it.
 */
class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    companion object {
        const val MIN_REPEL_PERCENT = 10
        const val MAX_REPEL_PERCENT = 50
        const val DEFAULT_REPEL_PERCENT = 28

        const val MIN_GAP_PERCENT = 0
        const val MAX_GAP_PERCENT = 30
        const val DEFAULT_GAP_PERCENT = 0

        const val MIN_RANGE = 80
        const val MAX_RANGE = 400
        const val DEFAULT_RANGE = 220

        // Friction was a fixed constant (0.94) - now a live slider. Same
        // semantics as before: this is a velocity-retention factor, so
        // HIGHER = less damping = more energetic/lively motion, LOWER =
        // more damping = calmer and slower.
        const val MIN_FRICTION_PERCENT = 85
        const val MAX_FRICTION_PERCENT = 99
        const val DEFAULT_FRICTION_PERCENT = 94

        const val MIN_TRAIL_PERCENT = 0
        const val MAX_TRAIL_PERCENT = 100
        const val DEFAULT_TRAIL_PERCENT = 40

        private const val NUM_TYPES = 8
        private const val PARTICLES_PER_TYPE = 68
        private const val FORCE_SCALE = 900f
        private const val MAX_SPEED = 900f              // world px/sec clamp, avoids blow-ups
        private const val TARGET_FPS = 60

        // ---- Alignment (flocking) ----
        private const val ALIGN_STRENGTH = 0.4f          // steering strength when enabled
        private const val ALIGN_RADIUS_FRACTION = 0.55f  // fraction of interactionRange counted as "nearby" for heading-matching
        private const val ALIGN_RATE = 6f                // how fast velocity steers toward the neighborhood average

        // ---- Aging ----
        private const val MAX_AGE_SECONDS = 25f
        private const val AGE_END_FADE = 0.3f            // force response multiplier right before a particle expires - not fully inert
        private const val AGE_VISUAL_FADE_SECONDS = 0.6f // opacity ramp at birth/death so a respawn reads as a soft
                                                           // fade instead of an instant pop in a new spot
        private const val AGE_RESPAWN_RADIUS_FRACTION = 0.5f // respawn near a same-type sibling (within this fraction
                                                               // of interactionRange) instead of anywhere in the whole
                                                               // world, so a respawn continues whatever cluster it left

        // ---- Chemical trails ----
        private const val TRAIL_CELL_SIZE = 120f         // coarse on purpose - see TrailField doc comment
        private const val TRAIL_DECAY = 0.985f           // per-frame multiplicative fade
        private const val TRAIL_DEPOSIT_RATE = 3f        // per-second deposit rate into a particle's own species channel
        private const val TRAIL_FORCE_SCALE = 0.02f      // normalizes raw trail-gradient units into the same -1..1-ish force scale as attraction

        // ---- Predator / Prey ----
        private const val PREDATOR_INTENSITY = 0.6f
        private const val PREDATOR_ASYMMETRY_THRESHOLD = 0.35f // both sides of a pair must clear this to count as predator/prey

        // ---- Preferred distance / Orbit (generated by randomize/mutate, not manually edited in the Rules overlay) ----
        private const val PREFERRED_DISTANCE_CHANCE = 0.18f
        private const val PREFERRED_DISTANCE_SPRING = 1f
        private const val ORBIT_CHANCE = 0.12f
        private const val ORBIT_STRENGTH_MAX = 0.8f
        private const val ORBIT_FORCE_SCALE = 1f

        // ---- Auto-mutate ----
        private const val AUTO_MUTATE_INTERVAL_SEC = 6f

        private const val WORLD_SCALE = 4f               // world is this many times bigger than the screen
        private const val RENDER_SCALE = 1f / WORLD_SCALE
        private const val PARTICLE_RADIUS_WORLD = 14f    // fixed - shrinks on screen as WORLD_SCALE grows (see class doc)

        // ---- Collision (hard-body, on top of the soft attract/repel curve) ----
        // The force curve's Repel zone is a smooth push, not a hard limit -
        // particles can still slip past each other, especially at speed.
        // This adds an actual physical size: once two particles are closer
        // than their combined radius they get shoved apart and lose some of
        // their closing speed, so they visibly bump instead of overlapping.
        private const val COLLISION_DIAMETER = PARTICLE_RADIUS_WORLD * 2f
        private const val COLLISION_PUSH = 0.6f          // fraction of overlap corrected per frame (softened, not instant)
        private const val COLLISION_RESTITUTION = 0.3f   // mild bounce on impact; 0 = no bounce, 1 = fully elastic

        // Zoom is screen-px per world-unit. DEFAULT_ZOOM shows exactly one
        // copy of the world (no wraparound tiling, no extra draw cost) -
        // this is what a fresh launch and the Center button reset to.
        // MIN_ZOOM lets a pinch go further out than that; MAX_TILE_SPAN
        // below is what actually bounds the tiling/draw cost when someone
        // does that, independent of how far MIN_ZOOM allows zooming out.
        private const val DEFAULT_ZOOM = RENDER_SCALE * 1.02f // slightly tighter than an exact world-width fit,
                                                                // so the boundary math below can't round into an extra tile
        private const val MIN_ZOOM = RENDER_SCALE / 2f
        private const val MAX_ZOOM = RENDER_SCALE * 40f
        private const val MAX_TILE_SPAN = 1 // wrapped copies drawn per axis beyond the center one - 1 = up to 3x3 total

        private const val MUTATE_STRENGTH = 0.25f       // max +/- nudge per coefficient on Mutate
        private const val RULE_EDIT_STEP = 0.4f         // per-tap nudge when editing a cell in the Rules overlay

        private const val PRESET_SLOTS = 3
        private const val TAP_SLOP_SQ = 400f            // 20px - total drag beyond this isn't a tap
        private const val LONG_PRESS_MS = 500L

        private const val PREFS_NAME = "particle_life_prefs"
        private const val KEY_REPEL = "repel_percent"
        private const val KEY_GAP = "gap_percent"
        private const val KEY_RANGE = "range"
        private const val KEY_PALETTE = "palette_index"
        private const val KEY_SYMMETRIC = "symmetric_rules"
        private const val KEY_PRESET_PREFIX = "preset_"
        private const val KEY_FRICTION = "friction_percent"
        private const val KEY_ALIGN_ENABLED = "align_enabled"
        private const val KEY_AGING_ENABLED = "aging_enabled"
        private const val KEY_TRAILS_ENABLED = "trails_enabled"
        private const val KEY_TRAIL_PERCENT = "trail_percent"
        private const val KEY_PREDATOR_ENABLED = "predator_enabled"
        private const val KEY_AUTO_MUTATE_ENABLED = "auto_mutate_enabled"

        // Each palette needs at least NUM_TYPES colors. Cycled with the Colors button.
        private val COLOR_PALETTES: Array<IntArray> = arrayOf(
            intArrayOf( // Neon (original)
                Color.rgb(255, 87, 87),
                Color.rgb(255, 200, 61),
                Color.rgb(102, 255, 128),
                Color.rgb(84, 209, 255),
                Color.rgb(140, 120, 255),
                Color.rgb(255, 120, 220),
                Color.rgb(200, 255, 90),
                Color.rgb(190, 90, 255)
            ),
            intArrayOf( // Pastel
                Color.rgb(255, 179, 186),
                Color.rgb(255, 223, 186),
                Color.rgb(255, 255, 186),
                Color.rgb(186, 255, 201),
                Color.rgb(186, 255, 255),
                Color.rgb(186, 201, 255),
                Color.rgb(223, 186, 255),
                Color.rgb(255, 186, 240)
            ),
            intArrayOf( // Fire
                Color.rgb(255, 244, 214),
                Color.rgb(255, 214, 120),
                Color.rgb(255, 170, 60),
                Color.rgb(255, 120, 40),
                Color.rgb(240, 70, 30),
                Color.rgb(200, 40, 30),
                Color.rgb(140, 20, 20),
                Color.rgb(255, 90, 0)
            )
        )
    }

    /** Screen-space layout of the Rules overlay - shared by drawing and touch hit-testing so they can't drift apart. */
    private class RulesGeometry(
        val panelLeft: Float, val panelTop: Float, val panelRight: Float, val panelBottom: Float,
        val pad: Float, val headerSize: Float,
        val gridLeft: Float, val gridTop: Float, val cell: Float, val gridSize: Float,
        val slotY: Float, val slotSize: Float, val slotSpacing: Float
    )

    /** Everything a preset slot needs to fully reproduce a rule set, including the generated (not manually edited) layers. */
    private data class RulePreset(
        val attraction: Array<FloatArray>,
        val preferredDistance: Array<FloatArray>,
        val orbitStrength: Array<FloatArray>
    )

    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var hasSurface = false
    @Volatile private var simPaused = false
    @Volatile private var pendingReset = false
    @Volatile private var pendingRandomize = false
    @Volatile private var pendingMutate = false
    @Volatile private var pendingRuleEditIndex = -1
    @Volatile private var pendingPresetSave = -1
    @Volatile private var pendingPresetLoad = -1
    @Volatile private var paletteIndex = 0
    @Volatile private var showRules = false
    @Volatile private var repelPercent = DEFAULT_REPEL_PERCENT
    @Volatile private var gapPercent = DEFAULT_GAP_PERCENT
    @Volatile private var interactionRange = DEFAULT_RANGE.toFloat()
    @Volatile private var symmetricRules = false

    @Volatile private var frictionPercent = DEFAULT_FRICTION_PERCENT
    @Volatile private var alignmentEnabled = false
    @Volatile private var agingEnabled = false
    @Volatile private var trailsEnabled = false
    @Volatile private var trailPercent = DEFAULT_TRAIL_PERCENT
    @Volatile private var predatorPreyEnabled = false
    @Volatile private var autoMutateEnabled = false
    private var autoMutateTimer = 0f  // sim-thread only (read/written inside update() alone), no need for @Volatile

    @Volatile private var cameraX = 0f
    @Volatile private var cameraY = 0f
    @Volatile private var zoom = DEFAULT_ZOOM
    private var cameraInitialized = false

    private var worldWidth = 0f
    private var worldHeight = 0f
    private var lastGridCellSize = 0f

    private val particles = mutableListOf<Particle>()
    private lateinit var attraction: Array<FloatArray>
    private lateinit var preferredDistance: Array<FloatArray>  // world units; 0f = disabled (plain attract/repel curve only)
    private lateinit var orbitStrength: Array<FloatArray>      // -1..1 tangential coefficient; 0 = no orbit; sign = spin direction
    private lateinit var chaseBoost: Array<FloatArray>         // derived from `attraction` by recomputeDerived() - see class doc
    private val presetSlots = arrayOfNulls<RulePreset>(PRESET_SLOTS)
    @Volatile private lateinit var grid: SpatialGrid
    @Volatile private lateinit var trailField: TrailField

    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fpsPaint = Paint().apply {
        color = Color.WHITE
        textSize = 34f
        isAntiAlias = true
    }
    private val rulesPanelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rulesSwatchPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rulesCellPaint = Paint()
    private val rulesLegendPaint = Paint().apply {
        color = Color.rgb(210, 210, 220)
        textSize = 22f
        isAntiAlias = true
    }

    private var lastFpsTime = 0L
    private var frameCount = 0
    private var fps = 0

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val oldZoom = zoom
            val newZoom = (oldZoom * detector.scaleFactor).coerceIn(MIN_ZOOM, MAX_ZOOM)
            if (worldWidth > 0f && worldHeight > 0f) {
                // Keep the point under the pinch focus stationary on screen
                // instead of always zooming toward the center - otherwise
                // content drifts out from under your fingers as you pinch.
                val focusWorldX = (detector.focusX - width / 2f) / oldZoom + cameraX
                val focusWorldY = (detector.focusY - height / 2f) / oldZoom + cameraY
                cameraX = wrapCoord(focusWorldX - (detector.focusX - width / 2f) / newZoom, worldWidth)
                cameraY = wrapCoord(focusWorldY - (detector.focusY - height / 2f) / newZoom, worldHeight)
            }
            zoom = newZoom
            return true
        }
    })

    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var touchDownX = 0f
    private var touchDownY = 0f
    private var touchDownTime = 0L

    init {
        holder.addCallback(this)
        randomizeAttractionMatrix()
    }

    // ---------- touch: pinch to zoom, drag to pan, tap/hold on the Rules overlay ----------
    // No GestureDetector/double-tap here - double-tap detection was firing
    // on quick consecutive drag gestures (two swipes done in a row look a
    // lot like a double-tap to the detector) and resetting the camera
    // mid-pan. A dedicated Center button in the menu covers that instead.
    // Tap/long-press detection for the Rules overlay is done manually below
    // for the same reason - one clear codepath rather than layering a
    // second detector with its own timing assumptions on top.

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                touchDownX = event.x
                touchDownY = event.y
                touchDownTime = System.currentTimeMillis()
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress && worldWidth > 0f && worldHeight > 0f) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    cameraX = wrapCoord(cameraX - dx / zoom, worldWidth)
                    cameraY = wrapCoord(cameraY - dy / zoom, worldHeight)
                }
                lastTouchX = event.x
                lastTouchY = event.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // A finger lifted but at least one remains - resync the
                // reference point to whichever pointer stays down, so
                // panning resumes cleanly with no jump once back to one
                // finger, instead of using a stale pointer-0 position.
                val remainingIndex = if (event.actionIndex == 0) 1 else 0
                if (remainingIndex < event.pointerCount) {
                    lastTouchX = event.getX(remainingIndex)
                    lastTouchY = event.getY(remainingIndex)
                }
            }
            MotionEvent.ACTION_UP -> {
                if (showRules) {
                    val dx = event.x - touchDownX
                    val dy = event.y - touchDownY
                    val movedFar = dx * dx + dy * dy > TAP_SLOP_SQ
                    if (!movedFar) {
                        val heldLong = System.currentTimeMillis() - touchDownTime >= LONG_PRESS_MS
                        handleRulesTouch(event.x, event.y, heldLong)
                    }
                }
            }
        }
        return true
    }

    private fun wrapCoord(value: Float, max: Float): Float {
        if (max <= 0f) return value
        var v = value % max
        if (v < 0f) v += max
        return v
    }

    /** Hit-tests a tap/hold against the Rules overlay's cells and preset slots. Returns true if it hit something. */
    private fun handleRulesTouch(screenX: Float, screenY: Float, isLongPress: Boolean): Boolean {
        val geo = rulesGeometry()

        if (screenX >= geo.gridLeft && screenX < geo.gridLeft + geo.gridSize &&
            screenY >= geo.gridTop && screenY < geo.gridTop + geo.gridSize
        ) {
            val col = ((screenX - geo.gridLeft) / geo.cell).toInt().coerceIn(0, NUM_TYPES - 1)
            val row = ((screenY - geo.gridTop) / geo.cell).toInt().coerceIn(0, NUM_TYPES - 1)
            pendingRuleEditIndex = row * NUM_TYPES + col
            return true
        }

        for (i in 0 until PRESET_SLOTS) {
            val slotX = geo.gridLeft + i * (geo.slotSize + geo.slotSpacing)
            if (screenX >= slotX && screenX < slotX + geo.slotSize &&
                screenY >= geo.slotY && screenY < geo.slotY + geo.slotSize
            ) {
                if (isLongPress) pendingPresetSave = i else pendingPresetLoad = i
                return true
            }
        }

        return false
    }

    // ---------- SurfaceHolder.Callback ----------

    override fun surfaceCreated(holder: SurfaceHolder) {
        hasSurface = true
        if (particles.isEmpty()) resetParticles()
        resume()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        worldWidth = w * WORLD_SCALE
        worldHeight = h * WORLD_SCALE
        grid = SpatialGrid(worldWidth, worldHeight, interactionRange)
        lastGridCellSize = interactionRange
        trailField = TrailField(worldWidth, worldHeight, TRAIL_CELL_SIZE, NUM_TYPES)
        if (!cameraInitialized) {
            cameraX = worldWidth / 2f
            cameraY = worldHeight / 2f
            cameraInitialized = true
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        hasSurface = false
        pause()
    }

    // ---------- lifecycle (called from MainActivity onResume/onPause) ----------

    fun resume() {
        if (running || !hasSurface) return
        running = true
        thread = Thread(this, "ParticleLifeLoop").apply { start() }
    }

    fun pause() {
        running = false
        thread?.join(500)
        thread = null
    }

    // ---------- public controls (called from the UI thread via button/slider/touch input) ----------

    /** Requests a brand new random rule matrix; applied on the sim thread at the top of the next frame. */
    fun randomizeRules() {
        pendingRandomize = true
    }

    /** Requests the CURRENT rule matrix be nudged a little rather than replaced; applied on the sim thread. */
    fun mutateRules() {
        pendingMutate = true
    }

    /** Requests particles be reshuffled to random positions using the current rules. */
    fun resetParticles() {
        pendingReset = true
    }

    /** Switches to the next color palette. Purely visual - safe to flip directly, no sim-thread handoff needed. */
    fun cycleColors() {
        paletteIndex = (paletteIndex + 1) % COLOR_PALETTES.size
    }

    /** Shows/hides the attraction-matrix legend overlay so you can see what color attracts/repels what - and edit it. */
    fun toggleRules() {
        showRules = !showRules
    }

    /** Freezes/resumes the physics. Rendering, camera, and rule editing all keep working while paused. */
    fun togglePause() {
        simPaused = !simPaused
    }

    /** Snaps the camera back to the default view (one world, no tiling), centered. */
    fun resetCamera() {
        zoom = DEFAULT_ZOOM
        if (worldWidth > 0f) cameraX = worldWidth / 2f
        if (worldHeight > 0f) cameraY = worldHeight / 2f
    }

    /** How far the always-repulsive zone extends, as a percent of the interaction range. Applies live. */
    fun setRepelPercent(percent: Int) {
        repelPercent = percent.coerceIn(MIN_REPEL_PERCENT, MAX_REPEL_PERCENT)
    }

    /** Width of the neutral dead zone right after Repel, before Attract begins - percent of range. Applies live. */
    fun setGapPercent(percent: Int) {
        gapPercent = percent.coerceIn(MIN_GAP_PERCENT, MAX_GAP_PERCENT)
    }

    /** Max distance particles can affect each other at all. Applies live; resizes the spatial grid next frame. */
    fun setInteractionRange(range: Int) {
        interactionRange = range.coerceIn(MIN_RANGE, MAX_RANGE).toFloat()
    }

    /** When on, Randomize/Mutate/tap-edit all keep attraction[i][j] == attraction[j][i] for every pair. */
    fun setSymmetricRules(enabled: Boolean) {
        symmetricRules = enabled
    }

    /** Velocity-retention factor - higher keeps more energy (livelier), lower damps harder (calmer). Applies live. */
    fun setFriction(percent: Int) {
        frictionPercent = percent.coerceIn(MIN_FRICTION_PERCENT, MAX_FRICTION_PERCENT)
    }

    /** Steers same-type neighbors toward a shared heading (local flocking). Off by default. */
    fun setAlignmentEnabled(enabled: Boolean) {
        alignmentEnabled = enabled
    }

    /** Gives particles a lifespan: force response fades near end of life, then they respawn. Off by default. */
    fun setAgingEnabled(enabled: Boolean) {
        agingEnabled = enabled
    }

    /** Chemical trails: particles deposit/follow a coarse pheromone field. Off by default. */
    fun setTrailsEnabled(enabled: Boolean) {
        trailsEnabled = enabled
    }

    /** How strongly particles steer by trails, once enabled. Applies live. */
    fun setTrailStrength(percent: Int) {
        trailPercent = percent.coerceIn(MIN_TRAIL_PERCENT, MAX_TRAIL_PERCENT)
    }

    /** Amplifies already-asymmetric pairs (one flees, one seeks) into obvious chase/flee behavior. Off by default. */
    fun setPredatorPreyEnabled(enabled: Boolean) {
        predatorPreyEnabled = enabled
    }

    /** Periodically calls the same mutateRules() a person would trigger by hand. Off by default. */
    fun setAutoMutateEnabled(enabled: Boolean) {
        autoMutateEnabled = enabled
        autoMutateTimer = 0f
    }

    fun getRepelPercent(): Int = repelPercent
    fun getGapPercent(): Int = gapPercent
    fun getInteractionRange(): Int = interactionRange.toInt()
    fun getPaletteIndex(): Int = paletteIndex
    fun isSymmetricRules(): Boolean = symmetricRules
    fun getFriction(): Int = frictionPercent
    fun isAlignmentEnabled(): Boolean = alignmentEnabled
    fun isAgingEnabled(): Boolean = agingEnabled
    fun isTrailsEnabled(): Boolean = trailsEnabled
    fun getTrailStrength(): Int = trailPercent
    fun isPredatorPreyEnabled(): Boolean = predatorPreyEnabled
    fun isAutoMutateEnabled(): Boolean = autoMutateEnabled

    /** Restores sliders/palette/symmetric-mode/presets saved by saveState(). Call once, before reading the getters above. */
    fun loadState(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        repelPercent = prefs.getInt(KEY_REPEL, DEFAULT_REPEL_PERCENT).coerceIn(MIN_REPEL_PERCENT, MAX_REPEL_PERCENT)
        gapPercent = prefs.getInt(KEY_GAP, DEFAULT_GAP_PERCENT).coerceIn(MIN_GAP_PERCENT, MAX_GAP_PERCENT)
        interactionRange = prefs.getInt(KEY_RANGE, DEFAULT_RANGE).coerceIn(MIN_RANGE, MAX_RANGE).toFloat()
        paletteIndex = prefs.getInt(KEY_PALETTE, 0).coerceIn(0, COLOR_PALETTES.size - 1)
        symmetricRules = prefs.getBoolean(KEY_SYMMETRIC, false)
        frictionPercent = prefs.getInt(KEY_FRICTION, DEFAULT_FRICTION_PERCENT).coerceIn(MIN_FRICTION_PERCENT, MAX_FRICTION_PERCENT)
        alignmentEnabled = prefs.getBoolean(KEY_ALIGN_ENABLED, false)
        agingEnabled = prefs.getBoolean(KEY_AGING_ENABLED, false)
        trailsEnabled = prefs.getBoolean(KEY_TRAILS_ENABLED, false)
        trailPercent = prefs.getInt(KEY_TRAIL_PERCENT, DEFAULT_TRAIL_PERCENT).coerceIn(MIN_TRAIL_PERCENT, MAX_TRAIL_PERCENT)
        predatorPreyEnabled = prefs.getBoolean(KEY_PREDATOR_ENABLED, false)
        autoMutateEnabled = prefs.getBoolean(KEY_AUTO_MUTATE_ENABLED, false)
        for (i in 0 until PRESET_SLOTS) {
            val saved = prefs.getString(KEY_PRESET_PREFIX + i, null)
            presetSlots[i] = saved?.let { deserializePreset(it) }
        }
    }

    /** Persists sliders/palette/symmetric-mode/presets. Call from onPause - cheap, just a handful of prefs. */
    fun saveState(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().apply {
            putInt(KEY_REPEL, repelPercent)
            putInt(KEY_GAP, gapPercent)
            putInt(KEY_RANGE, interactionRange.toInt())
            putInt(KEY_PALETTE, paletteIndex)
            putBoolean(KEY_SYMMETRIC, symmetricRules)
            putInt(KEY_FRICTION, frictionPercent)
            putBoolean(KEY_ALIGN_ENABLED, alignmentEnabled)
            putBoolean(KEY_AGING_ENABLED, agingEnabled)
            putBoolean(KEY_TRAILS_ENABLED, trailsEnabled)
            putInt(KEY_TRAIL_PERCENT, trailPercent)
            putBoolean(KEY_PREDATOR_ENABLED, predatorPreyEnabled)
            putBoolean(KEY_AUTO_MUTATE_ENABLED, autoMutateEnabled)
            for (i in 0 until PRESET_SLOTS) {
                val preset = presetSlots[i]
                if (preset != null) putString(KEY_PRESET_PREFIX + i, serializePreset(preset)) else remove(KEY_PRESET_PREFIX + i)
            }
            apply()
        }
    }

    private fun serializeMatrix(matrix: Array<FloatArray>): String =
        matrix.joinToString(",") { row -> row.joinToString(",") }

    private fun deserializeMatrix(s: String): Array<FloatArray>? {
        val values = s.split(",").mapNotNull { it.toFloatOrNull() }
        if (values.size != NUM_TYPES * NUM_TYPES) return null
        return Array(NUM_TYPES) { i -> FloatArray(NUM_TYPES) { j -> values[i * NUM_TYPES + j] } }
    }

    // Presets bundle all three per-pair matrices. "|" is a safe separator -
    // matrix cells only ever serialize as digits/./-/,. Presets saved by an
    // older build of this app (attraction-only, no separator) simply fail
    // to parse here and are dropped rather than crashing.
    private fun serializePreset(preset: RulePreset): String =
        "${serializeMatrix(preset.attraction)}|${serializeMatrix(preset.preferredDistance)}|${serializeMatrix(preset.orbitStrength)}"

    private fun deserializePreset(s: String): RulePreset? {
        val parts = s.split("|")
        if (parts.size != 3) return null
        val a = deserializeMatrix(parts[0]) ?: return null
        val pd = deserializeMatrix(parts[1]) ?: return null
        val ob = deserializeMatrix(parts[2]) ?: return null
        return RulePreset(a, pd, ob)
    }

    // All mutation of `particles` / `attraction` / `presetSlots` happens
    // only on the sim thread (inside update()), triggered by the volatile
    // flags above. That keeps the button/slider/touch-driven UI thread from
    // ever touching the lists the render/physics loop is iterating, so no
    // locking is needed.

    private fun doResetParticles() {
        val w = worldWidth.takeIf { it > 0f } ?: (1080f * WORLD_SCALE)
        val h = worldHeight.takeIf { it > 0f } ?: (1920f * WORLD_SCALE)
        particles.clear()
        repeat(NUM_TYPES) { type ->
            repeat(PARTICLES_PER_TYPE) {
                // age is staggered randomly across the full lifespan rather
                // than starting every particle at 0 - otherwise every
                // particle ages in lockstep and the whole population would
                // hit MAX_AGE_SECONDS and respawn on the exact same frame
                // (looks like the sim "restarting") instead of a natural,
                // continuous trickle of individual respawns.
                val startAge = Random.nextFloat() * MAX_AGE_SECONDS
                particles.add(Particle(x = Random.nextFloat() * w, y = Random.nextFloat() * h, type = type).apply {
                    age = startAge
                })
            }
        }
        if (::trailField.isInitialized) trailField.clear()
    }

    private fun randomizeAttractionMatrix() {
        attraction = Array(NUM_TYPES) { FloatArray(NUM_TYPES) }
        preferredDistance = Array(NUM_TYPES) { FloatArray(NUM_TYPES) }
        orbitStrength = Array(NUM_TYPES) { FloatArray(NUM_TYPES) }
        for (i in 0 until NUM_TYPES) {
            for (j in i until NUM_TYPES) {
                attraction[i][j] = Random.nextFloat() * 2f - 1f
                attraction[j][i] = if (symmetricRules) attraction[i][j] else Random.nextFloat() * 2f - 1f

                preferredDistance[i][j] = randomPreferredDistance()
                preferredDistance[j][i] = if (symmetricRules) preferredDistance[i][j] else randomPreferredDistance()

                orbitStrength[i][j] = randomOrbitStrength()
                orbitStrength[j][i] = if (symmetricRules) orbitStrength[i][j] else randomOrbitStrength()
            }
        }
        recomputeDerived()
    }

    /** Sparse on purpose - most pairs stay 0 (plain attract/repel), only PREFERRED_DISTANCE_CHANCE get a ring target. */
    private fun randomPreferredDistance(): Float =
        if (Random.nextFloat() < PREFERRED_DISTANCE_CHANCE) {
            MIN_RANGE + Random.nextFloat() * (interactionRange - MIN_RANGE)
        } else 0f

    private fun randomOrbitStrength(): Float =
        if (Random.nextFloat() < ORBIT_CHANCE) (Random.nextFloat() * 2f - 1f) * ORBIT_STRENGTH_MAX else 0f

    private fun mutateAttractionMatrix() {
        for (i in 0 until NUM_TYPES) {
            for (j in i until NUM_TYPES) {
                val delta = (Random.nextFloat() * 2f - 1f) * MUTATE_STRENGTH
                val newVal = (attraction[i][j] + delta).coerceIn(-1f, 1f)
                attraction[i][j] = newVal
                attraction[j][i] = if (symmetricRules) {
                    newVal
                } else {
                    val delta2 = (Random.nextFloat() * 2f - 1f) * MUTATE_STRENGTH
                    (attraction[j][i] + delta2).coerceIn(-1f, 1f)
                }

                preferredDistance[i][j] = mutatePreferredDistance(preferredDistance[i][j])
                preferredDistance[j][i] = if (symmetricRules) preferredDistance[i][j] else mutatePreferredDistance(preferredDistance[j][i])

                orbitStrength[i][j] = mutateOrbitStrength(orbitStrength[i][j])
                orbitStrength[j][i] = if (symmetricRules) orbitStrength[i][j] else mutateOrbitStrength(orbitStrength[j][i])
            }
        }
        recomputeDerived()
    }

    /** Small chance to switch on/off; otherwise a gentle nudge - keeps mutation gradual per pair, as with attraction. */
    private fun mutatePreferredDistance(current: Float): Float {
        if (current <= 0f) return if (Random.nextFloat() < PREFERRED_DISTANCE_CHANCE * 0.5f) randomPreferredDistance().coerceAtLeast(MIN_RANGE.toFloat()) else 0f
        if (Random.nextFloat() < 0.08f) return 0f
        val delta = (Random.nextFloat() * 2f - 1f) * (interactionRange * 0.15f)
        return (current + delta).coerceIn(MIN_RANGE.toFloat(), interactionRange)
    }

    private fun mutateOrbitStrength(current: Float): Float {
        if (current == 0f) return if (Random.nextFloat() < ORBIT_CHANCE * 0.5f) randomOrbitStrength() else 0f
        if (Random.nextFloat() < 0.08f) return 0f
        val delta = (Random.nextFloat() * 2f - 1f) * MUTATE_STRENGTH
        return (current + delta).coerceIn(-ORBIT_STRENGTH_MAX, ORBIT_STRENGTH_MAX)
    }

    /**
     * Derives predator/prey amplification from the attraction matrix itself
     * instead of a separate matrix to edit and save: a pair counts as
     * predator/prey when one side strongly flees the other (very negative
     * attraction[i][j]) while the other strongly seeks it back (very
     * positive attraction[j][i]). chaseBoost is symmetric per pair - it
     * scales BOTH the prey's flee force and the predator's chase force by
     * the same factor, since predatorPreyEnabled multiplies whichever
     * particle's own force term against the other. Call after anything
     * that changes `attraction` (randomize, mutate, per-cell edit, preset
     * load).
     */
    private fun recomputeDerived() {
        chaseBoost = Array(NUM_TYPES) { FloatArray(NUM_TYPES) }
        for (i in 0 until NUM_TYPES) {
            for (j in 0 until NUM_TYPES) {
                if (i == j) continue
                val fear = (-attraction[i][j]).coerceAtLeast(0f)   // how strongly i flees j
                val hunger = attraction[j][i].coerceAtLeast(0f)    // how strongly j is drawn to i
                val boost = if (fear > PREDATOR_ASYMMETRY_THRESHOLD && hunger > PREDATOR_ASYMMETRY_THRESHOLD) fear * hunger else 0f
                if (boost > chaseBoost[i][j]) chaseBoost[i][j] = boost
                if (boost > chaseBoost[j][i]) chaseBoost[j][i] = boost
            }
        }
    }

    /**
     * Resets a single particle to a fresh position/velocity/age - used by
     * the aging system, not the Reset button.
     *
     * Respawning at a uniformly random point anywhere in the world (4x the
     * screen) made aging look like particles randomly blinking out and
     * back with no connection to what was on screen - "shape disappearing
     * and reappearing" instead of anything life-like. Spawning near a
     * same-type sibling instead keeps a respawn inside whatever cluster
     * it left, like a generational handoff rather than a teleport.
     * Combined with the birth/death opacity fade in draw(), a respawn now
     * reads as one particle in a group fading out and a new one fading in
     * nearby, not a pop.
     */
    private fun respawnParticle(p: Particle, w: Float, h: Float) {
        val sibling = particles.firstOrNull { it !== p && it.type == p.type }
        if (sibling != null) {
            val spawnRadius = interactionRange * AGE_RESPAWN_RADIUS_FRACTION
            p.x = wrapCoord(sibling.x + (Random.nextFloat() * 2f - 1f) * spawnRadius, w)
            p.y = wrapCoord(sibling.y + (Random.nextFloat() * 2f - 1f) * spawnRadius, h)
        } else {
            p.x = Random.nextFloat() * w
            p.y = Random.nextFloat() * h
        }
        p.vx = 0f
        p.vy = 0f
        p.age = 0f
    }

    /** Steps one coefficient through the -1..1 range in fixed increments, wrapping past either end. */
    private fun nextRuleValue(current: Float): Float {
        return (current + 1f + RULE_EDIT_STEP).mod(2f) - 1f
    }

    // ---------- game loop ----------

    override fun run() {
        val frameTimeMs = 1000L / TARGET_FPS
        while (running) {
            val start = System.currentTimeMillis()
            val dt = 1f / TARGET_FPS

            update(dt)
            draw()
            trackFps(start)

            val sleep = frameTimeMs - (System.currentTimeMillis() - start)
            if (sleep > 0) {
                try {
                    Thread.sleep(sleep)
                } catch (_: InterruptedException) {
                }
            }
        }
    }

    private fun trackFps(now: Long) {
        frameCount++
        if (now - lastFpsTime >= 1000) {
            fps = frameCount
            frameCount = 0
            lastFpsTime = now
        }
    }

    // ---------- simulation ----------

    private fun update(dt: Float) {
        if (pendingRandomize) {
            randomizeAttractionMatrix()
            pendingRandomize = false
        }
        if (pendingMutate) {
            mutateAttractionMatrix()
            pendingMutate = false
        }
        if (pendingReset) {
            doResetParticles()
            pendingReset = false
        }
        if (pendingRuleEditIndex >= 0) {
            val idx = pendingRuleEditIndex
            pendingRuleEditIndex = -1
            val row = idx / NUM_TYPES
            val col = idx % NUM_TYPES
            val newVal = nextRuleValue(attraction[row][col])
            attraction[row][col] = newVal
            if (symmetricRules) {
                attraction[col][row] = newVal
            }
            recomputeDerived()
        }
        if (pendingPresetSave >= 0) {
            val slot = pendingPresetSave
            pendingPresetSave = -1
            presetSlots[slot] = RulePreset(
                attraction = Array(NUM_TYPES) { i -> attraction[i].copyOf() },
                preferredDistance = Array(NUM_TYPES) { i -> preferredDistance[i].copyOf() },
                orbitStrength = Array(NUM_TYPES) { i -> orbitStrength[i].copyOf() }
            )
        }
        if (pendingPresetLoad >= 0) {
            val slot = pendingPresetLoad
            pendingPresetLoad = -1
            presetSlots[slot]?.let { saved ->
                attraction = Array(NUM_TYPES) { i -> saved.attraction[i].copyOf() }
                preferredDistance = Array(NUM_TYPES) { i -> saved.preferredDistance[i].copyOf() }
                orbitStrength = Array(NUM_TYPES) { i -> saved.orbitStrength[i].copyOf() }
                recomputeDerived()
            }
        }

        if (!::grid.isInitialized || !::trailField.isInitialized || worldWidth == 0f || worldHeight == 0f) return

        // Cell size has to track the current range: cells smaller than the
        // range would make the 3x3-neighbor-cell search miss valid pairs.
        // Cheap to rebuild (just empty bucket lists, no particle work), so
        // it's fine to check every frame - this only actually reconstructs
        // when the Distance slider changed since last frame.
        val range = interactionRange
        if (range != lastGridCellSize) {
            grid = SpatialGrid(worldWidth, worldHeight, range)
            lastGridCellSize = range
        }

        // Rules/particles above can still be edited while paused (that's
        // the point - freeze the scene, then fine-tune it); only the
        // force calculation and movement below actually stop.
        if (simPaused) return

        if (autoMutateEnabled) {
            autoMutateTimer += dt
            if (autoMutateTimer >= AUTO_MUTATE_INTERVAL_SEC) {
                autoMutateTimer = 0f
                mutateAttractionMatrix()
            }
        }

        val g = grid
        g.rebuild(particles)

        val w = worldWidth
        val h = worldHeight
        val repelEnd = range * (repelPercent / 100f)
        val attractStart = (repelEnd + range * (gapPercent / 100f)).coerceAtMost(range - 1f)
        val friction = frictionPercent / 100f
        val alignOn = alignmentEnabled
        val alignRadiusSq = (range * ALIGN_RADIUS_FRACTION) * (range * ALIGN_RADIUS_FRACTION)
        val trailOn = trailsEnabled
        val trailStrength = trailPercent / 100f
        val predatorOn = predatorPreyEnabled

        for (p in particles) {
            var fx = 0f
            var fy = 0f
            var alignVX = 0f
            var alignVY = 0f
            var alignCount = 0

            g.forEachNearby(p.x, p.y) { j ->
                val other = particles[j]
                if (other !== p) {
                    // Minimum-image distance: on a wrapped world, the short
                    // way around an edge can be closer than the raw delta.
                    var dx = other.x - p.x
                    if (dx > w * 0.5f) dx -= w else if (dx < -w * 0.5f) dx += w
                    var dy = other.y - p.y
                    if (dy > h * 0.5f) dy -= h else if (dy < -h * 0.5f) dy += h

                    val distSq = dx * dx + dy * dy
                    if (distSq > 0.0001f && distSq < range * range) {
                        val dist = sqrt(distSq)
                        val invDist = 1f / dist
                        val a = attraction[p.type][other.type]

                        var f = forceAt(dist, a, repelEnd, attractStart, range)

                        // Preferred distance: soft spring pulling this pair
                        // toward an ideal ring radius instead of only
                        // attract/repel - supports stable clusters/chains.
                        val pd = preferredDistance[p.type][other.type]
                        if (pd > 0f) {
                            f += ((pd - dist) / pd).coerceIn(-1f, 1f) * PREFERRED_DISTANCE_SPRING
                        }

                        // Predator/Prey: amplify pairs that are already
                        // strongly asymmetric (one flees, one seeks) - see
                        // recomputeDerived(). Same force system, just scaled.
                        if (predatorOn) {
                            val boost = chaseBoost[p.type][other.type]
                            if (boost > 0f) f *= (1f + PREDATOR_INTENSITY * boost)
                        }

                        fx += f * dx * invDist
                        fy += f * dy * invDist

                        // Orbit: tangential push perpendicular to the radius
                        // vector, ramped down near the edge of range so
                        // pairs settle into a loop instead of flinging apart.
                        val orbit = orbitStrength[p.type][other.type]
                        if (orbit != 0f) {
                            val ramp = (1f - dist / range).coerceIn(0f, 1f)
                            val tangential = orbit * ORBIT_FORCE_SCALE * ramp
                            fx += -dy * invDist * tangential
                            fy += dx * invDist * tangential
                        }

                        // Alignment: accumulate heading of nearby same-type
                        // neighbors in this same pass - no second grid walk.
                        if (alignOn && other.type == p.type && distSq < alignRadiusSq) {
                            alignVX += other.vx
                            alignVY += other.vy
                            alignCount++
                        }
                    }
                }
            }

            if (trailOn) {
                trailField.sampleInto(p, { species -> attraction[p.type][species] }) { gx, gy ->
                    fx += gx * trailStrength * TRAIL_FORCE_SCALE
                    fy += gy * trailStrength * TRAIL_FORCE_SCALE
                }
            }

            // Aging: force response fades near end of life, then the
            // particle respawns fresh elsewhere. Optional - off leaves
            // ageFactor at 1 always, i.e. pure simulation mode.
            var ageFactor = 1f
            if (agingEnabled) {
                p.age += dt
                if (p.age >= MAX_AGE_SECONDS) {
                    respawnParticle(p, w, h)
                    continue
                }
                ageFactor = 1f - (p.age / MAX_AGE_SECONDS) * (1f - AGE_END_FADE)
            }

            p.vx = (p.vx + fx * FORCE_SCALE * ageFactor * dt) * friction
            p.vy = (p.vy + fy * FORCE_SCALE * ageFactor * dt) * friction

            if (alignCount > 0) {
                val avgVX = alignVX / alignCount
                val avgVY = alignVY / alignCount
                // Steer toward the neighborhood's average heading rather
                // than snapping to it - stays smooth, no instant clumping.
                p.vx += (avgVX - p.vx) * ALIGN_STRENGTH * ALIGN_RATE * dt
                p.vy += (avgVY - p.vy) * ALIGN_STRENGTH * ALIGN_RATE * dt
            }

            val speed = sqrt(p.vx * p.vx + p.vy * p.vy)
            if (speed > MAX_SPEED) {
                p.vx = p.vx / speed * MAX_SPEED
                p.vy = p.vy / speed * MAX_SPEED
            }

            p.x += p.vx * dt
            p.y += p.vy * dt

            // Toroidal wrap - no walls. A particle that exits one edge
            // re-enters the opposite edge with velocity untouched.
            if (p.x < 0f) p.x += w else if (p.x >= w) p.x -= w
            if (p.y < 0f) p.y += h else if (p.y >= h) p.y -= h

            if (trailOn) trailField.deposit(p, TRAIL_DEPOSIT_RATE * dt)
        }

        resolveCollisions(g, w, h)

        if (trailOn) trailField.decay(TRAIL_DECAY)
    }

    /**
     * Hard-body collision pass, run after this frame's forces/movement.
     * Reuses the grid already rebuilt this frame for the force pass above
     * (that rebuild reflects pre-movement positions) instead of rebuilding
     * a second time - a full rebuild is an O(particles) bucket-insert pass,
     * and doing it twice every frame was a real chunk of the lag reports.
     * A particle only moves a few px/frame, so a query against slightly
     * stale buckets still finds the right neighbors in practice; distances
     * themselves are recomputed fresh from each particle's current x/y, so
     * the correction below is accurate even though the buckets are a frame
     * stale. For every pair still sharing a neighborhood, pushes apart any
     * that are closer than their combined radius (COLLISION_DIAMETER) and
     * removes some of their closing speed. `j > i` skips re-processing
     * each pair from its other side. Runs every frame regardless of
     * species or the attract/repel sliders - this is about particles
     * having actual size, not the Rules matrix.
     */
    private fun resolveCollisions(g: SpatialGrid, w: Float, h: Float) {
        val minDist = COLLISION_DIAMETER
        val minDistSq = minDist * minDist

        for (i in particles.indices) {
            val p = particles[i]
            g.forEachNearby(p.x, p.y) { j ->
                if (j > i) {
                    val other = particles[j]
                    var dx = other.x - p.x
                    if (dx > w * 0.5f) dx -= w else if (dx < -w * 0.5f) dx += w
                    var dy = other.y - p.y
                    if (dy > h * 0.5f) dy -= h else if (dy < -h * 0.5f) dy += h

                    val distSq = dx * dx + dy * dy
                    if (distSq > 0.0001f && distSq < minDistSq) {
                        val dist = sqrt(distSq)
                        val nx = dx / dist
                        val ny = dy / dist

                        // Positional correction: split the overlap between
                        // both particles so neither one "owns" the push.
                        val overlap = minDist - dist
                        val push = overlap * COLLISION_PUSH * 0.5f
                        p.x -= nx * push
                        p.y -= ny * push
                        other.x += nx * push
                        other.y += ny * push

                        // Velocity response: only kill/reflect the part of
                        // their relative velocity that's closing the gap,
                        // so a graze doesn't kill unrelated sideways motion.
                        val rvx = other.vx - p.vx
                        val rvy = other.vy - p.vy
                        val closingSpeed = rvx * nx + rvy * ny
                        if (closingSpeed < 0f) {
                            val impulse = -(1f + COLLISION_RESTITUTION) * closingSpeed * 0.5f
                            p.vx -= impulse * nx
                            p.vy -= impulse * ny
                            other.vx += impulse * nx
                            other.vy += impulse * ny
                        }
                    }
                }
            }
        }

        // A correction above can push a particle just past a world edge.
        for (p in particles) {
            if (p.x < 0f) p.x += w else if (p.x >= w) p.x -= w
            if (p.y < 0f) p.y += h else if (p.y >= h) p.y -= h
        }
    }

    /**
     * Signed force magnitude (roughly -1..1) at distance [r]. Three zones:
     * always repulsive below [repelEnd]; zero force (dead zone) between
     * [repelEnd] and [attractStart]; beyond that, ramps up to rule
     * coefficient [a] at the midpoint of the remaining distance, back down
     * to 0 at [range].
     */
    private fun forceAt(r: Float, a: Float, repelEnd: Float, attractStart: Float, range: Float): Float {
        return when {
            r < repelEnd -> r / repelEnd - 1f
            r < attractStart -> 0f
            else -> {
                val span = range - attractStart
                val t = (r - attractStart) / span
                a * (1f - abs(2f * t - 1f))
            }
        }
    }

    // ---------- rendering ----------

    private fun draw() {
        val canvas: Canvas = holder.lockCanvas() ?: return
        try {
            // Hard clear every frame - no motion-trail overlay.
            canvas.drawColor(Color.rgb(8, 8, 16))

            if (worldWidth > 0f && worldHeight > 0f) {
                val colors = COLOR_PALETTES[paletteIndex]
                val z = zoom
                canvas.save()
                canvas.scale(z, z)
                canvas.translate(width / (2f * z) - cameraX, height / (2f * z) - cameraY)

                // Each particle only exists once, in [0,worldWidth) x
                // [0,worldHeight) - but the world wraps, so near an edge (or
                // whenever the viewport is close to a full world-width/
                // height across) that single copy isn't enough to cover
                // what's visible. Draw whichever wrapped copies (offset by
                // +/- a world size) actually fall inside the current view.
                val halfViewW = width / (2f * z)
                val halfViewH = height / (2f * z)
                val centerTileX = floor(cameraX / worldWidth).toInt()
                val centerTileY = floor(cameraY / worldHeight).toInt()
                // Clamped to MAX_TILE_SPAN around the center tile regardless
                // of zoom - a pinch past DEFAULT_ZOOM makes things look
                // smaller, not draw more copies, so draw cost never scales
                // with how far out someone zooms (this is what was tanking
                // FPS on lower-end hardware).
                val tileMinX = maxOf(floor((cameraX - halfViewW) / worldWidth).toInt(), centerTileX - MAX_TILE_SPAN)
                val tileMaxX = minOf(floor((cameraX + halfViewW) / worldWidth).toInt(), centerTileX + MAX_TILE_SPAN)
                val tileMinY = maxOf(floor((cameraY - halfViewH) / worldHeight).toInt(), centerTileY - MAX_TILE_SPAN)
                val tileMaxY = minOf(floor((cameraY + halfViewH) / worldHeight).toInt(), centerTileY + MAX_TILE_SPAN)

                val agingOn = agingEnabled
                for (tx in tileMinX..tileMaxX) {
                    val offsetX = tx * worldWidth
                    for (ty in tileMinY..tileMaxY) {
                        val offsetY = ty * worldHeight
                        for (p in particles) {
                            particlePaint.color = colors[p.type % colors.size]
                            // Fade in right after a respawn and fade out right
                            // before the next one, so aging reads as a soft
                            // birth/death rather than an instant pop - see
                            // respawnParticle()'s doc comment.
                            particlePaint.alpha = if (agingOn) {
                                val fadeIn = (p.age / AGE_VISUAL_FADE_SECONDS).coerceIn(0f, 1f)
                                val fadeOut = ((MAX_AGE_SECONDS - p.age) / AGE_VISUAL_FADE_SECONDS).coerceIn(0f, 1f)
                                (minOf(fadeIn, fadeOut) * 255f).toInt().coerceIn(0, 255)
                            } else {
                                255
                            }
                            canvas.drawCircle(p.x + offsetX, p.y + offsetY, PARTICLE_RADIUS_WORLD, particlePaint)
                        }
                    }
                }
                canvas.restore()
            }

            // Everything below draws in raw screen pixels, outside the
            // camera transform, so it stays fixed to the screen regardless
            // of pan/zoom.
            if (showRules) drawRulesOverlay(canvas)
            val status = if (simPaused) {
                "FPS: $fps  |  particles: ${particles.size}  |  PAUSED"
            } else {
                "FPS: $fps  |  particles: ${particles.size}"
            }
            canvas.drawText(status, 24f, 60f, fpsPaint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    private fun rulesGeometry(): RulesGeometry {
        val cell = 30f
        val headerSize = 26f
        val pad = 16f
        val panelLeft = 24f
        val panelTop = 100f

        val gridLeft = panelLeft + pad + headerSize
        val gridTop = panelTop + pad + headerSize
        val gridSize = cell * NUM_TYPES

        val legendWidth = maxOf(
            rulesLegendPaint.measureText("rows react to columns"),
            rulesLegendPaint.measureText("green = attract, red = repel"),
            rulesLegendPaint.measureText("tap a cell to nudge it"),
            rulesLegendPaint.measureText("hold a slot to save, tap to load")
        )
        val contentWidth = maxOf(gridSize, legendWidth)
        val panelRight = panelLeft + pad + headerSize + contentWidth + pad

        val slotSize = 30f
        val slotSpacing = 14f
        val textBlockTop = gridTop + gridSize + pad
        val slotY = textBlockTop + 102f + 14f
        val panelBottom = slotY + slotSize + pad

        return RulesGeometry(
            panelLeft, panelTop, panelRight, panelBottom,
            pad, headerSize,
            gridLeft, gridTop, cell, gridSize,
            slotY, slotSize, slotSpacing
        )
    }

    /**
     * Small legend panel: an NxN grid where cell (row, col) shows how the
     * row's species reacts to the column's species - green means attract,
     * red means repel, brightness is the strength. Row/column headers are
     * color swatches so they map directly to what's on screen. Below that,
     * 3 preset slots (filled = has a saved rule set, dim = empty) - see
     * handleRulesTouch() for the tap/hold interaction. `attraction` and
     * `presetSlots` are only ever touched from this same sim thread, so no
     * locking is needed here either.
     */
    private fun drawRulesOverlay(canvas: Canvas) {
        val colors = COLOR_PALETTES[paletteIndex]
        val geo = rulesGeometry()

        rulesPanelPaint.color = Color.argb(225, 14, 14, 22)
        canvas.drawRoundRect(geo.panelLeft, geo.panelTop, geo.panelRight, geo.panelBottom, 20f, 20f, rulesPanelPaint)

        for (i in 0 until NUM_TYPES) {
            rulesSwatchPaint.color = colors[i % colors.size]
            canvas.drawCircle(geo.gridLeft + i * geo.cell + geo.cell / 2f, geo.panelTop + geo.pad + geo.headerSize / 2f, 8f, rulesSwatchPaint)
            canvas.drawCircle(geo.panelLeft + geo.pad + geo.headerSize / 2f, geo.gridTop + i * geo.cell + geo.cell / 2f, 8f, rulesSwatchPaint)
        }

        for (i in 0 until NUM_TYPES) {
            for (j in 0 until NUM_TYPES) {
                val v = attraction[i][j].coerceIn(-1f, 1f)
                val mag = abs(v)
                rulesCellPaint.color = if (v >= 0f) {
                    Color.rgb(lerp(40, 60, mag), lerp(40, 210, mag), lerp(50, 90, mag))
                } else {
                    Color.rgb(lerp(40, 220, mag), lerp(40, 55, mag), lerp(50, 60, mag))
                }
                val cx = geo.gridLeft + j * geo.cell
                val cy = geo.gridTop + i * geo.cell
                canvas.drawRect(cx + 1f, cy + 1f, cx + geo.cell - 1f, cy + geo.cell - 1f, rulesCellPaint)
            }
        }

        val textBlockTop = geo.gridTop + geo.gridSize + geo.pad
        canvas.drawText("rows react to columns", geo.panelLeft + geo.pad, textBlockTop + 24f, rulesLegendPaint)
        canvas.drawText("green = attract, red = repel", geo.panelLeft + geo.pad, textBlockTop + 50f, rulesLegendPaint)
        canvas.drawText("tap a cell to nudge it", geo.panelLeft + geo.pad, textBlockTop + 76f, rulesLegendPaint)
        canvas.drawText("hold a slot to save, tap to load", geo.panelLeft + geo.pad, textBlockTop + 102f, rulesLegendPaint)

        for (i in 0 until PRESET_SLOTS) {
            val slotX = geo.gridLeft + i * (geo.slotSize + geo.slotSpacing)
            rulesSwatchPaint.color = if (presetSlots[i] != null) Color.rgb(140, 120, 255) else Color.rgb(55, 52, 72)
            canvas.drawRoundRect(slotX, geo.slotY, slotX + geo.slotSize, geo.slotY + geo.slotSize, 6f, 6f, rulesSwatchPaint)
        }
    }

    private fun lerp(a: Int, b: Int, t: Float): Int = (a + (b - a) * t.coerceIn(0f, 1f)).toInt()
}
