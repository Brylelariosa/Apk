package com.particlelife.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Particle Life: N species of particles, each pair of species has a signed
 * attraction coefficient. Every frame, every particle sums up forces from
 * nearby particles (weighted by that coefficient), integrates velocity with
 * friction, and moves. Random coefficients reliably produce clusters,
 * orbits, and chase/flee behavior - "life-like" motion with no explicit
 * rule for any of it.
 *
 * The world wraps at its edges (toroidal - no walls): a particle that exits
 * the right side re-enters on the left, and the force calculation uses
 * "minimum image" distance so pairs near opposite edges still interact
 * correctly across the seam, same technique used for periodic boundaries in
 * physics simulations. SpatialGrid's neighbor search wraps the same way.
 * Rendering also draws nearby wrapped copies of each particle (see the
 * tiling loop in draw()) so panning across the seam shows continuous
 * content instead of empty space.
 *
 * Camera: pinch to zoom (toward the pinch point, not just screen center),
 * drag to pan, Center button in the menu to reset. cameraX/cameraY are the
 * world coordinate shown at screen center; zoom is screen-px per world-unit.
 *
 * The force curve has three zones out to `interactionRange`, all adjustable
 * live via sliders in MainActivity - see forceAt():
 *   1. Repel  - always-repulsive zone near r=0, sized as a % of range.
 *   2. Gap    - optional dead zone right after Repel with zero force.
 *   3. Attract - ramps up to the rule coefficient, peaks at the midpoint of
 *      the remaining distance, back to 0 at interactionRange.
 *
 * The Rules overlay (toggled by the Rules button) doubles as an editor when
 * showing: tap a cell to nudge that specific pair's coefficient, tap one of
 * the 3 slots below the legend to load a saved rule set, or hold a slot to
 * save the current one there. Pausing (togglePause) freezes the physics but
 * keeps rendering/camera/rule-editing live, so you can freeze an interesting
 * moment and fine-tune the rules that produced it without them drifting
 * out from under you.
 *
 * The simulated world is larger than the visible screen (WORLD_SCALE).
 * PARTICLE_RADIUS_WORLD is a fixed world-space size, deliberately NOT
 * compensated for WORLD_SCALE - letting particles shrink a bit on screen
 * as WORLD_SCALE grows is what reads as "zoomed out to show more space."
 *
 * Runs its own render thread (matches the engine style used elsewhere:
 * SurfaceView + Runnable game loop, not Compose).
 */
class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    companion object {
        const val MIN_REPEL_PERCENT = 10
        const val MAX_REPEL_PERCENT = 50
        const val DEFAULT_REPEL_PERCENT = 28

        const val MIN_GAP_PERCENT = 0
        const val MAX_GAP_PERCENT = 30
        const val DEFAULT_GAP_PERCENT = 0

        const val MIN_RANGE = 80
        const val MAX_RANGE = 400
        const val DEFAULT_RANGE = 220

        private const val NUM_TYPES = 8
        private const val PARTICLES_PER_TYPE = 68
        private const val FRICTION = 0.94f              // velocity damping per frame - was 0.88, too aggressive: an
                                                          // isolated particle (no force acting on it) would decay to
                                                          // a dead stop within a few hundred ms - 0.94 lets them
                                                          // coast for seconds instead of snapping still
        private const val FORCE_SCALE = 900f
        private const val MAX_SPEED = 900f              // world px/sec clamp, avoids blow-ups
        private const val TARGET_FPS = 60

        private const val WORLD_SCALE = 4f               // world is this many times bigger than the screen
        private const val RENDER_SCALE = 1f / WORLD_SCALE
        private const val PARTICLE_RADIUS_WORLD = 14f    // fixed - shrinks on screen as WORLD_SCALE grows (see class doc)

        // Zoom is screen-px per world-unit. MIN_ZOOM shows up to a 3x3 block
        // of repeated world copies (bounded, not unlimited - see draw()'s
        // tiling loop for why unlimited zoom-out isn't free). MAX_ZOOM is
        // just a generous close-up cap, no real cost either direction there.
        private const val MIN_ZOOM = RENDER_SCALE / 2f
        private const val MAX_ZOOM = RENDER_SCALE * 40f

        private const val MUTATE_STRENGTH = 0.25f       // max +/- nudge per coefficient on Mutate
        private const val RULE_EDIT_STEP = 0.4f         // per-tap nudge when editing a cell in the Rules overlay

        private const val PRESET_SLOTS = 3
        private const val TAP_SLOP_SQ = 400f            // 20px - total drag beyond this isn't a tap
        private const val LONG_PRESS_MS = 500L

        private const val PREFS_NAME = "particle_life_prefs"
        private const val KEY_REPEL = "repel_percent"
        private const val KEY_GAP = "gap_percent"
        private const val KEY_RANGE = "range"
        private const val KEY_PALETTE = "palette_index"
        private const val KEY_SYMMETRIC = "symmetric_rules"
        private const val KEY_PRESET_PREFIX = "preset_"

        // Each palette needs at least NUM_TYPES colors. Cycled with the Colors button.
        private val COLOR_PALETTES: Array<IntArray> = arrayOf(
            intArrayOf( // Neon (original)
                Color.rgb(255, 87, 87),
                Color.rgb(255, 200, 61),
                Color.rgb(102, 255, 128),
                Color.rgb(84, 209, 255),
                Color.rgb(140, 120, 255),
                Color.rgb(255, 120, 220),
                Color.rgb(200, 255, 90),
                Color.rgb(190, 90, 255)
            ),
            intArrayOf( // Pastel
                Color.rgb(255, 179, 186),
                Color.rgb(255, 223, 186),
                Color.rgb(255, 255, 186),
                Color.rgb(186, 255, 201),
                Color.rgb(186, 255, 255),
                Color.rgb(186, 201, 255),
                Color.rgb(223, 186, 255),
                Color.rgb(255, 186, 240)
            ),
            intArrayOf( // Fire
                Color.rgb(255, 244, 214),
                Color.rgb(255, 214, 120),
                Color.rgb(255, 170, 60),
                Color.rgb(255, 120, 40),
                Color.rgb(240, 70, 30),
                Color.rgb(200, 40, 30),
                Color.rgb(140, 20, 20),
                Color.rgb(255, 90, 0)
            )
        )
    }

    /** Screen-space layout of the Rules overlay - shared by drawing and touch hit-testing so they can't drift apart. */
    private class RulesGeometry(
        val panelLeft: Float, val panelTop: Float, val panelRight: Float, val panelBottom: Float,
        val pad: Float, val headerSize: Float,
        val gridLeft: Float, val gridTop: Float, val cell: Float, val gridSize: Float,
        val slotY: Float, val slotSize: Float, val slotSpacing: Float
    )

    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var hasSurface = false
    @Volatile private var simPaused = false
    @Volatile private var pendingReset = false
    @Volatile private var pendingRandomize = false
    @Volatile private var pendingMutate = false
    @Volatile private var pendingRuleEditIndex = -1
    @Volatile private var pendingPresetSave = -1
    @Volatile private var pendingPresetLoad = -1
    @Volatile private var paletteIndex = 0
    @Volatile private var showRules = false
    @Volatile private var repelPercent = DEFAULT_REPEL_PERCENT
    @Volatile private var gapPercent = DEFAULT_GAP_PERCENT
    @Volatile private var interactionRange = DEFAULT_RANGE.toFloat()
    @Volatile private var symmetricRules = false

    @Volatile private var cameraX = 0f
    @Volatile private var cameraY = 0f
    @Volatile private var zoom = MIN_ZOOM
    private var cameraInitialized = false

    private var worldWidth = 0f
    private var worldHeight = 0f
    private var lastGridCellSize = 0f

    private val particles = mutableListOf<Particle>()
    private lateinit var attraction: Array<FloatArray>
    private val presetSlots = arrayOfNulls<Array<FloatArray>>(PRESET_SLOTS)
    @Volatile private lateinit var grid: SpatialGrid

    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fpsPaint = Paint().apply {
        color = Color.WHITE
        textSize = 34f
        isAntiAlias = true
    }
    private val rulesPanelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rulesSwatchPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rulesCellPaint = Paint()
    private val rulesLegendPaint = Paint().apply {
        color = Color.rgb(210, 210, 220)
        textSize = 22f
        isAntiAlias = true
    }

    private var lastFpsTime = 0L
    private var frameCount = 0
    private var fps = 0

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val oldZoom = zoom
            val newZoom = (oldZoom * detector.scaleFactor).coerceIn(MIN_ZOOM, MAX_ZOOM)
            if (worldWidth > 0f && worldHeight > 0f) {
                // Keep the point under the pinch focus stationary on screen
                // instead of always zooming toward the center - otherwise
                // content drifts out from under your fingers as you pinch.
                val focusWorldX = (detector.focusX - width / 2f) / oldZoom + cameraX
                val focusWorldY = (detector.focusY - height / 2f) / oldZoom + cameraY
                cameraX = wrapCoord(focusWorldX - (detector.focusX - width / 2f) / newZoom, worldWidth)
                cameraY = wrapCoord(focusWorldY - (detector.focusY - height / 2f) / newZoom, worldHeight)
            }
            zoom = newZoom
            return true
        }
    })

    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var touchDownX = 0f
    private var touchDownY = 0f
    private var touchDownTime = 0L

    init {
        holder.addCallback(this)
        randomizeAttractionMatrix()
    }

    // ---------- touch: pinch to zoom, drag to pan, tap/hold on the Rules overlay ----------
    // No GestureDetector/double-tap here - double-tap detection was firing
    // on quick consecutive drag gestures (two swipes done in a row look a
    // lot like a double-tap to the detector) and resetting the camera
    // mid-pan. A dedicated Center button in the menu covers that instead.
    // Tap/long-press detection for the Rules overlay is done manually below
    // for the same reason - one clear codepath rather than layering a
    // second detector with its own timing assumptions on top.

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
                touchDownX = event.x
                touchDownY = event.y
                touchDownTime = System.currentTimeMillis()
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress && worldWidth > 0f && worldHeight > 0f) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    cameraX = wrapCoord(cameraX - dx / zoom, worldWidth)
                    cameraY = wrapCoord(cameraY - dy / zoom, worldHeight)
                }
                lastTouchX = event.x
                lastTouchY = event.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // A finger lifted but at least one remains - resync the
                // reference point to whichever pointer stays down, so
                // panning resumes cleanly with no jump once back to one
                // finger, instead of using a stale pointer-0 position.
                val remainingIndex = if (event.actionIndex == 0) 1 else 0
                if (remainingIndex < event.pointerCount) {
                    lastTouchX = event.getX(remainingIndex)
                    lastTouchY = event.getY(remainingIndex)
                }
            }
            MotionEvent.ACTION_UP -> {
                if (showRules) {
                    val dx = event.x - touchDownX
                    val dy = event.y - touchDownY
                    val movedFar = dx * dx + dy * dy > TAP_SLOP_SQ
                    if (!movedFar) {
                        val heldLong = System.currentTimeMillis() - touchDownTime >= LONG_PRESS_MS
                        handleRulesTouch(event.x, event.y, heldLong)
                    }
                }
            }
        }
        return true
    }

    private fun wrapCoord(value: Float, max: Float): Float {
        if (max <= 0f) return value
        var v = value % max
        if (v < 0f) v += max
        return v
    }

    /** Hit-tests a tap/hold against the Rules overlay's cells and preset slots. Returns true if it hit something. */
    private fun handleRulesTouch(screenX: Float, screenY: Float, isLongPress: Boolean): Boolean {
        val geo = rulesGeometry()

        if (screenX >= geo.gridLeft && screenX < geo.gridLeft + geo.gridSize &&
            screenY >= geo.gridTop && screenY < geo.gridTop + geo.gridSize
        ) {
            val col = ((screenX - geo.gridLeft) / geo.cell).toInt().coerceIn(0, NUM_TYPES - 1)
            val row = ((screenY - geo.gridTop) / geo.cell).toInt().coerceIn(0, NUM_TYPES - 1)
            pendingRuleEditIndex = row * NUM_TYPES + col
            return true
        }

        for (i in 0 until PRESET_SLOTS) {
            val slotX = geo.gridLeft + i * (geo.slotSize + geo.slotSpacing)
            if (screenX >= slotX && screenX < slotX + geo.slotSize &&
                screenY >= geo.slotY && screenY < geo.slotY + geo.slotSize
            ) {
                if (isLongPress) pendingPresetSave = i else pendingPresetLoad = i
                return true
            }
        }

        return false
    }

    // ---------- SurfaceHolder.Callback ----------

    override fun surfaceCreated(holder: SurfaceHolder) {
        hasSurface = true
        if (particles.isEmpty()) resetParticles()
        resume()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        worldWidth = w * WORLD_SCALE
        worldHeight = h * WORLD_SCALE
        grid = SpatialGrid(worldWidth, worldHeight, interactionRange)
        lastGridCellSize = interactionRange
        if (!cameraInitialized) {
            cameraX = worldWidth / 2f
            cameraY = worldHeight / 2f
            cameraInitialized = true
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        hasSurface = false
        pause()
    }

    // ---------- lifecycle (called from MainActivity onResume/onPause) ----------

    fun resume() {
        if (running || !hasSurface) return
        running = true
        thread = Thread(this, "ParticleLifeLoop").apply { start() }
    }

    fun pause() {
        running = false
        thread?.join(500)
        thread = null
    }

    // ---------- public controls (called from the UI thread via button/slider/touch input) ----------

    /** Requests a brand new random rule matrix; applied on the sim thread at the top of the next frame. */
    fun randomizeRules() {
        pendingRandomize = true
    }

    /** Requests the CURRENT rule matrix be nudged a little rather than replaced; applied on the sim thread. */
    fun mutateRules() {
        pendingMutate = true
    }

    /** Requests particles be reshuffled to random positions using the current rules. */
    fun resetParticles() {
        pendingReset = true
    }

    /** Switches to the next color palette. Purely visual - safe to flip directly, no sim-thread handoff needed. */
    fun cycleColors() {
        paletteIndex = (paletteIndex + 1) % COLOR_PALETTES.size
    }

    /** Shows/hides the attraction-matrix legend overlay so you can see what color attracts/repels what - and edit it. */
    fun toggleRules() {
        showRules = !showRules
    }

    /** Freezes/resumes the physics. Rendering, camera, and rule editing all keep working while paused. */
    fun togglePause() {
        simPaused = !simPaused
    }

    /** Snaps the camera back to fully zoomed out, centered on the world. */
    fun resetCamera() {
        zoom = MIN_ZOOM
        if (worldWidth > 0f) cameraX = worldWidth / 2f
        if (worldHeight > 0f) cameraY = worldHeight / 2f
    }

    /** How far the always-repulsive zone extends, as a percent of the interaction range. Applies live. */
    fun setRepelPercent(percent: Int) {
        repelPercent = percent.coerceIn(MIN_REPEL_PERCENT, MAX_REPEL_PERCENT)
    }

    /** Width of the neutral dead zone right after Repel, before Attract begins - percent of range. Applies live. */
    fun setGapPercent(percent: Int) {
        gapPercent = percent.coerceIn(MIN_GAP_PERCENT, MAX_GAP_PERCENT)
    }

    /** Max distance particles can affect each other at all. Applies live; resizes the spatial grid next frame. */
    fun setInteractionRange(range: Int) {
        interactionRange = range.coerceIn(MIN_RANGE, MAX_RANGE).toFloat()
    }

    /** When on, Randomize/Mutate/tap-edit all keep attraction[i][j] == attraction[j][i] for every pair. */
    fun setSymmetricRules(enabled: Boolean) {
        symmetricRules = enabled
    }

    fun getRepelPercent(): Int = repelPercent
    fun getGapPercent(): Int = gapPercent
    fun getInteractionRange(): Int = interactionRange.toInt()
    fun getPaletteIndex(): Int = paletteIndex
    fun isSymmetricRules(): Boolean = symmetricRules

    /** Restores sliders/palette/symmetric-mode/presets saved by saveState(). Call once, before reading the getters above. */
    fun loadState(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        repelPercent = prefs.getInt(KEY_REPEL, DEFAULT_REPEL_PERCENT).coerceIn(MIN_REPEL_PERCENT, MAX_REPEL_PERCENT)
        gapPercent = prefs.getInt(KEY_GAP, DEFAULT_GAP_PERCENT).coerceIn(MIN_GAP_PERCENT, MAX_GAP_PERCENT)
        interactionRange = prefs.getInt(KEY_RANGE, DEFAULT_RANGE).coerceIn(MIN_RANGE, MAX_RANGE).toFloat()
        paletteIndex = prefs.getInt(KEY_PALETTE, 0).coerceIn(0, COLOR_PALETTES.size - 1)
        symmetricRules = prefs.getBoolean(KEY_SYMMETRIC, false)
        for (i in 0 until PRESET_SLOTS) {
            val saved = prefs.getString(KEY_PRESET_PREFIX + i, null)
            presetSlots[i] = saved?.let { deserializeMatrix(it) }
        }
    }

    /** Persists sliders/palette/symmetric-mode/presets. Call from onPause - cheap, just a handful of prefs. */
    fun saveState(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().apply {
            putInt(KEY_REPEL, repelPercent)
            putInt(KEY_GAP, gapPercent)
            putInt(KEY_RANGE, interactionRange.toInt())
            putInt(KEY_PALETTE, paletteIndex)
            putBoolean(KEY_SYMMETRIC, symmetricRules)
            for (i in 0 until PRESET_SLOTS) {
                val matrix = presetSlots[i]
                if (matrix != null) putString(KEY_PRESET_PREFIX + i, serializeMatrix(matrix)) else remove(KEY_PRESET_PREFIX + i)
            }
            apply()
        }
    }

    private fun serializeMatrix(matrix: Array<FloatArray>): String =
        matrix.joinToString(",") { row -> row.joinToString(",") }

    private fun deserializeMatrix(s: String): Array<FloatArray>? {
        val values = s.split(",").mapNotNull { it.toFloatOrNull() }
        if (values.size != NUM_TYPES * NUM_TYPES) return null
        return Array(NUM_TYPES) { i -> FloatArray(NUM_TYPES) { j -> values[i * NUM_TYPES + j] } }
    }

    // All mutation of `particles` / `attraction` / `presetSlots` happens
    // only on the sim thread (inside update()), triggered by the volatile
    // flags above. That keeps the button/slider/touch-driven UI thread from
    // ever touching the lists the render/physics loop is iterating, so no
    // locking is needed.

    private fun doResetParticles() {
        val w = worldWidth.takeIf { it > 0f } ?: (1080f * WORLD_SCALE)
        val h = worldHeight.takeIf { it > 0f } ?: (1920f * WORLD_SCALE)
        particles.clear()
        repeat(NUM_TYPES) { type ->
            repeat(PARTICLES_PER_TYPE) {
                particles.add(Particle(x = Random.nextFloat() * w, y = Random.nextFloat() * h, type = type))
            }
        }
    }

    private fun randomizeAttractionMatrix() {
        attraction = Array(NUM_TYPES) { FloatArray(NUM_TYPES) }
        for (i in 0 until NUM_TYPES) {
            for (j in i until NUM_TYPES) {
                attraction[i][j] = Random.nextFloat() * 2f - 1f
                attraction[j][i] = if (symmetricRules) attraction[i][j] else Random.nextFloat() * 2f - 1f
            }
        }
    }

    private fun mutateAttractionMatrix() {
        for (i in 0 until NUM_TYPES) {
            for (j in i until NUM_TYPES) {
                val delta = (Random.nextFloat() * 2f - 1f) * MUTATE_STRENGTH
                val newVal = (attraction[i][j] + delta).coerceIn(-1f, 1f)
                attraction[i][j] = newVal
                attraction[j][i] = if (symmetricRules) {
                    newVal
                } else {
                    val delta2 = (Random.nextFloat() * 2f - 1f) * MUTATE_STRENGTH
                    (attraction[j][i] + delta2).coerceIn(-1f, 1f)
                }
            }
        }
    }

    /** Steps one coefficient through the -1..1 range in fixed increments, wrapping past either end. */
    private fun nextRuleValue(current: Float): Float {
        return (current + 1f + RULE_EDIT_STEP).mod(2f) - 1f
    }

    // ---------- game loop ----------

    override fun run() {
        val frameTimeMs = 1000L / TARGET_FPS
        while (running) {
            val start = System.currentTimeMillis()
            val dt = 1f / TARGET_FPS

            update(dt)
            draw()
            trackFps(start)

            val sleep = frameTimeMs - (System.currentTimeMillis() - start)
            if (sleep > 0) {
                try {
                    Thread.sleep(sleep)
                } catch (_: InterruptedException) {
                }
            }
        }
    }

    private fun trackFps(now: Long) {
        frameCount++
        if (now - lastFpsTime >= 1000) {
            fps = frameCount
            frameCount = 0
            lastFpsTime = now
        }
    }

    // ---------- simulation ----------

    private fun update(dt: Float) {
        if (pendingRandomize) {
            randomizeAttractionMatrix()
            pendingRandomize = false
        }
        if (pendingMutate) {
            mutateAttractionMatrix()
            pendingMutate = false
        }
        if (pendingReset) {
            doResetParticles()
            pendingReset = false
        }
        if (pendingRuleEditIndex >= 0) {
            val idx = pendingRuleEditIndex
            pendingRuleEditIndex = -1
            val row = idx / NUM_TYPES
            val col = idx % NUM_TYPES
            val newVal = nextRuleValue(attraction[row][col])
            attraction[row][col] = newVal
            if (symmetricRules) {
                attraction[col][row] = newVal
            }
        }
        if (pendingPresetSave >= 0) {
            val slot = pendingPresetSave
            pendingPresetSave = -1
            presetSlots[slot] = Array(NUM_TYPES) { i -> attraction[i].copyOf() }
        }
        if (pendingPresetLoad >= 0) {
            val slot = pendingPresetLoad
            pendingPresetLoad = -1
            presetSlots[slot]?.let { saved ->
                attraction = Array(NUM_TYPES) { i -> saved[i].copyOf() }
            }
        }

        if (!::grid.isInitialized || worldWidth == 0f || worldHeight == 0f) return

        // Cell size has to track the current range: cells smaller than the
        // range would make the 3x3-neighbor-cell search miss valid pairs.
        // Cheap to rebuild (just empty bucket lists, no particle work), so
        // it's fine to check every frame - this only actually reconstructs
        // when the Distance slider changed since last frame.
        val range = interactionRange
        if (range != lastGridCellSize) {
            grid = SpatialGrid(worldWidth, worldHeight, range)
            lastGridCellSize = range
        }

        // Rules/particles above can still be edited while paused (that's
        // the point - freeze the scene, then fine-tune it); only the
        // force calculation and movement below actually stop.
        if (simPaused) return

        val g = grid
        g.rebuild(particles)

        val w = worldWidth
        val h = worldHeight
        val repelEnd = range * (repelPercent / 100f)
        val attractStart = (repelEnd + range * (gapPercent / 100f)).coerceAtMost(range - 1f)

        for (p in particles) {
            var fx = 0f
            var fy = 0f

            g.forEachNearby(p.x, p.y) { j ->
                val other = particles[j]
                if (other !== p) {
                    // Minimum-image distance: on a wrapped world, the short
                    // way around an edge can be closer than the raw delta.
                    var dx = other.x - p.x
                    if (dx > w * 0.5f) dx -= w else if (dx < -w * 0.5f) dx += w
                    var dy = other.y - p.y
                    if (dy > h * 0.5f) dy -= h else if (dy < -h * 0.5f) dy += h

                    val distSq = dx * dx + dy * dy
                    if (distSq > 0.0001f && distSq < range * range) {
                        val dist = sqrt(distSq)
                        val f = forceAt(dist, attraction[p.type][other.type], repelEnd, attractStart, range)
                        fx += f * dx / dist
                        fy += f * dy / dist
                    }
                }
            }

            p.vx = (p.vx + fx * FORCE_SCALE * dt) * FRICTION
            p.vy = (p.vy + fy * FORCE_SCALE * dt) * FRICTION

            val speed = sqrt(p.vx * p.vx + p.vy * p.vy)
            if (speed > MAX_SPEED) {
                p.vx = p.vx / speed * MAX_SPEED
                p.vy = p.vy / speed * MAX_SPEED
            }

            p.x += p.vx * dt
            p.y += p.vy * dt

            // Toroidal wrap - no walls. A particle that exits one edge
            // re-enters the opposite edge with velocity untouched.
            if (p.x < 0f) p.x += w else if (p.x >= w) p.x -= w
            if (p.y < 0f) p.y += h else if (p.y >= h) p.y -= h
        }
    }

    /**
     * Signed force magnitude (roughly -1..1) at distance [r]. Three zones:
     * always repulsive below [repelEnd]; zero force (dead zone) between
     * [repelEnd] and [attractStart]; beyond that, ramps up to rule
     * coefficient [a] at the midpoint of the remaining distance, back down
     * to 0 at [range].
     */
    private fun forceAt(r: Float, a: Float, repelEnd: Float, attractStart: Float, range: Float): Float {
        return when {
            r < repelEnd -> r / repelEnd - 1f
            r < attractStart -> 0f
            else -> {
                val span = range - attractStart
                val t = (r - attractStart) / span
                a * (1f - abs(2f * t - 1f))
            }
        }
    }

    // ---------- rendering ----------

    private fun draw() {
        val canvas: Canvas = holder.lockCanvas() ?: return
        try {
            // Hard clear every frame - no motion-trail overlay.
            canvas.drawColor(Color.rgb(8, 8, 16))

            if (worldWidth > 0f && worldHeight > 0f) {
                val colors = COLOR_PALETTES[paletteIndex]
                val z = zoom
                canvas.save()
                canvas.scale(z, z)
                canvas.translate(width / (2f * z) - cameraX, height / (2f * z) - cameraY)

                // Each particle only exists once, in [0,worldWidth) x
                // [0,worldHeight) - but the world wraps, so near an edge (or
                // whenever the viewport is close to a full world-width/
                // height across) that single copy isn't enough to cover
                // what's visible. Draw whichever wrapped copies (offset by
                // +/- a world size) actually fall inside the current view.
                val halfViewW = width / (2f * z)
                val halfViewH = height / (2f * z)
                val tileMinX = floor((cameraX - halfViewW) / worldWidth).toInt()
                val tileMaxX = floor((cameraX + halfViewW) / worldWidth).toInt()
                val tileMinY = floor((cameraY - halfViewH) / worldHeight).toInt()
                val tileMaxY = floor((cameraY + halfViewH) / worldHeight).toInt()

                for (tx in tileMinX..tileMaxX) {
                    val offsetX = tx * worldWidth
                    for (ty in tileMinY..tileMaxY) {
                        val offsetY = ty * worldHeight
                        for (p in particles) {
                            particlePaint.color = colors[p.type % colors.size]
                            canvas.drawCircle(p.x + offsetX, p.y + offsetY, PARTICLE_RADIUS_WORLD, particlePaint)
                        }
                    }
                }
                canvas.restore()
            }

            // Everything below draws in raw screen pixels, outside the
            // camera transform, so it stays fixed to the screen regardless
            // of pan/zoom.
            if (showRules) drawRulesOverlay(canvas)
            val status = if (simPaused) {
                "FPS: $fps  |  particles: ${particles.size}  |  PAUSED"
            } else {
                "FPS: $fps  |  particles: ${particles.size}"
            }
            canvas.drawText(status, 24f, 60f, fpsPaint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    private fun rulesGeometry(): RulesGeometry {
        val cell = 30f
        val headerSize = 26f
        val pad = 16f
        val panelLeft = 24f
        val panelTop = 100f

        val gridLeft = panelLeft + pad + headerSize
        val gridTop = panelTop + pad + headerSize
        val gridSize = cell * NUM_TYPES

        val legendWidth = maxOf(
            rulesLegendPaint.measureText("rows react to columns"),
            rulesLegendPaint.measureText("green = attract, red = repel"),
            rulesLegendPaint.measureText("tap a cell to nudge it"),
            rulesLegendPaint.measureText("hold a slot to save, tap to load")
        )
        val contentWidth = maxOf(gridSize, legendWidth)
        val panelRight = panelLeft + pad + headerSize + contentWidth + pad

        val slotSize = 30f
        val slotSpacing = 14f
        val textBlockTop = gridTop + gridSize + pad
        val slotY = textBlockTop + 102f + 14f
        val panelBottom = slotY + slotSize + pad

        return RulesGeometry(
            panelLeft, panelTop, panelRight, panelBottom,
            pad, headerSize,
            gridLeft, gridTop, cell, gridSize,
            slotY, slotSize, slotSpacing
        )
    }

    /**
     * Small legend panel: an NxN grid where cell (row, col) shows how the
     * row's species reacts to the column's species - green means attract,
     * red means repel, brightness is the strength. Row/column headers are
     * color swatches so they map directly to what's on screen. Below that,
     * 3 preset slots (filled = has a saved rule set, dim = empty) - see
     * handleRulesTouch() for the tap/hold interaction. `attraction` and
     * `presetSlots` are only ever touched from this same sim thread, so no
     * locking is needed here either.
     */
    private fun drawRulesOverlay(canvas: Canvas) {
        val colors = COLOR_PALETTES[paletteIndex]
        val geo = rulesGeometry()

        rulesPanelPaint.color = Color.argb(225, 14, 14, 22)
        canvas.drawRoundRect(geo.panelLeft, geo.panelTop, geo.panelRight, geo.panelBottom, 20f, 20f, rulesPanelPaint)

        for (i in 0 until NUM_TYPES) {
            rulesSwatchPaint.color = colors[i % colors.size]
            canvas.drawCircle(geo.gridLeft + i * geo.cell + geo.cell / 2f, geo.panelTop + geo.pad + geo.headerSize / 2f, 8f, rulesSwatchPaint)
            canvas.drawCircle(geo.panelLeft + geo.pad + geo.headerSize / 2f, geo.gridTop + i * geo.cell + geo.cell / 2f, 8f, rulesSwatchPaint)
        }

        for (i in 0 until NUM_TYPES) {
            for (j in 0 until NUM_TYPES) {
                val v = attraction[i][j].coerceIn(-1f, 1f)
                val mag = abs(v)
                rulesCellPaint.color = if (v >= 0f) {
                    Color.rgb(lerp(40, 60, mag), lerp(40, 210, mag), lerp(50, 90, mag))
                } else {
                    Color.rgb(lerp(40, 220, mag), lerp(40, 55, mag), lerp(50, 60, mag))
                }
                val cx = geo.gridLeft + j * geo.cell
                val cy = geo.gridTop + i * geo.cell
                canvas.drawRect(cx + 1f, cy + 1f, cx + geo.cell - 1f, cy + geo.cell - 1f, rulesCellPaint)
            }
        }

        val textBlockTop = geo.gridTop + geo.gridSize + geo.pad
        canvas.drawText("rows react to columns", geo.panelLeft + geo.pad, textBlockTop + 24f, rulesLegendPaint)
        canvas.drawText("green = attract, red = repel", geo.panelLeft + geo.pad, textBlockTop + 50f, rulesLegendPaint)
        canvas.drawText("tap a cell to nudge it", geo.panelLeft + geo.pad, textBlockTop + 76f, rulesLegendPaint)
        canvas.drawText("hold a slot to save, tap to load", geo.panelLeft + geo.pad, textBlockTop + 102f, rulesLegendPaint)

        for (i in 0 until PRESET_SLOTS) {
            val slotX = geo.gridLeft + i * (geo.slotSize + geo.slotSpacing)
            rulesSwatchPaint.color = if (presetSlots[i] != null) Color.rgb(140, 120, 255) else Color.rgb(55, 52, 72)
            canvas.drawRoundRect(slotX, geo.slotY, slotX + geo.slotSize, geo.slotY + geo.slotSize, 6f, 6f, rulesSwatchPaint)
        }
    }

    private fun lerp(a: Int, b: Int, t: Float): Int = (a + (b - a) * t.coerceIn(0f, 1f)).toInt()
}
