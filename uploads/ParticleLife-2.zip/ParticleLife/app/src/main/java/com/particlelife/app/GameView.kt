package com.particlelife.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Particle Life: N species of particles, each pair of species has a signed
 * attraction coefficient. Every frame, every particle sums up forces from
 * nearby particles (weighted by that coefficient), integrates velocity with
 * friction, and moves. Random coefficients reliably produce clusters,
 * orbits, and chase/flee behavior - "life-like" motion with no explicit
 * rule for any of it.
 *
 * The world wraps at its edges (toroidal - no walls): a particle that exits
 * the right side re-enters on the left, and the force calculation uses
 * "minimum image" distance so pairs near opposite edges still interact
 * correctly across the seam, same technique used for periodic boundaries in
 * physics simulations. SpatialGrid's neighbor search wraps the same way.
 * Rendering also draws nearby wrapped copies of each particle (see the
 * tiling loop in draw()) so panning across the seam shows continuous
 * content instead of empty space - without that, only the physics would be
 * seamless and the world would still look bordered.
 *
 * Camera: pinch to zoom (toward the pinch point, not just screen center),
 * drag to pan, Center button in the menu to reset. cameraX/cameraY are the
 * world coordinate shown at screen center; zoom is screen-px per world-unit.
 *
 * The force curve has three zones out to `interactionRange`, all adjustable
 * live via sliders in MainActivity - see forceAt():
 *   1. Repel  - always-repulsive zone near r=0, sized as a % of range.
 *   2. Gap    - optional dead zone right after Repel with zero force.
 *   3. Attract - ramps up to the rule coefficient, peaks at the midpoint of
 *      the remaining distance, back to 0 at interactionRange.
 *
 * The simulated world is larger than the visible screen (WORLD_SCALE).
 * PARTICLE_RADIUS_WORLD is a fixed world-space size, deliberately NOT
 * compensated for WORLD_SCALE - letting particles shrink a bit on screen
 * as WORLD_SCALE grows is what reads as "zoomed out to show more space."
 *
 * Runs its own render thread (matches the engine style used elsewhere:
 * SurfaceView + Runnable game loop, not Compose).
 */
class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback, Runnable {

    companion object {
        const val MIN_REPEL_PERCENT = 10
        const val MAX_REPEL_PERCENT = 50
        const val DEFAULT_REPEL_PERCENT = 28

        const val MIN_GAP_PERCENT = 0
        const val MAX_GAP_PERCENT = 30
        const val DEFAULT_GAP_PERCENT = 0

        const val MIN_RANGE = 80
        const val MAX_RANGE = 400
        const val DEFAULT_RANGE = 220

        private const val NUM_TYPES = 8
        private const val PARTICLES_PER_TYPE = 68
        private const val FRICTION = 0.94f               // velocity damping per frame - was 0.88, too aggressive: an
                                                            // isolated particle (no force acting on it) would decay to
                                                            // a dead stop within a few hundred ms, which is most of
                                                            // what "particles sometimes stop moving" was - 0.94 lets
                                                            // them coast for seconds instead of snapping still
        private const val FORCE_SCALE = 900f
        private const val MAX_SPEED = 900f              // world px/sec clamp, avoids blow-ups
        private const val TARGET_FPS = 60

        private const val WORLD_SCALE = 4f               // world is this many times bigger than the screen
        private const val RENDER_SCALE = 1f / WORLD_SCALE
        private const val PARTICLE_RADIUS_WORLD = 14f    // fixed - shrinks on screen as WORLD_SCALE grows (see class doc)

        // Zoom is screen-px per world-unit. Genuinely unlimited zoom-out
        // would need an unbounded number of wrapped tile copies drawn every
        // frame (draw() tiles the world - see there), which would tank
        // frame rate with no ceiling - so this is "much wider than before"
        // rather than infinite: MIN_ZOOM now shows up to a 3x3 block of
        // repeated world copies (was capped at exactly one copy), and
        // MAX_ZOOM goes 4x closer in than before for close-up inspection.
        private const val MIN_ZOOM = RENDER_SCALE / 2f
        private const val MAX_ZOOM = RENDER_SCALE * 40f

        private const val MUTATE_STRENGTH = 0.25f       // max +/- nudge per coefficient on Mutate

        // Each palette needs at least NUM_TYPES colors. Cycled with the Colors button.
        private val COLOR_PALETTES: Array<IntArray> = arrayOf(
            intArrayOf( // Neon (original)
                Color.rgb(255, 87, 87),
                Color.rgb(255, 200, 61),
                Color.rgb(102, 255, 128),
                Color.rgb(84, 209, 255),
                Color.rgb(140, 120, 255),
                Color.rgb(255, 120, 220),
                Color.rgb(200, 255, 90),
                Color.rgb(190, 90, 255)
            ),
            intArrayOf( // Pastel
                Color.rgb(255, 179, 186),
                Color.rgb(255, 223, 186),
                Color.rgb(255, 255, 186),
                Color.rgb(186, 255, 201),
                Color.rgb(186, 255, 255),
                Color.rgb(186, 201, 255),
                Color.rgb(223, 186, 255),
                Color.rgb(255, 186, 240)
            ),
            intArrayOf( // Fire
                Color.rgb(255, 244, 214),
                Color.rgb(255, 214, 120),
                Color.rgb(255, 170, 60),
                Color.rgb(255, 120, 40),
                Color.rgb(240, 70, 30),
                Color.rgb(200, 40, 30),
                Color.rgb(140, 20, 20),
                Color.rgb(255, 90, 0)
            )
        )
    }

    private var thread: Thread? = null
    @Volatile private var running = false
    @Volatile private var hasSurface = false
    @Volatile private var pendingReset = false
    @Volatile private var pendingRandomize = false
    @Volatile private var pendingMutate = false
    @Volatile private var paletteIndex = 0
    @Volatile private var showRules = false
    @Volatile private var repelPercent = DEFAULT_REPEL_PERCENT
    @Volatile private var gapPercent = DEFAULT_GAP_PERCENT
    @Volatile private var interactionRange = DEFAULT_RANGE.toFloat()

    @Volatile private var cameraX = 0f
    @Volatile private var cameraY = 0f
    @Volatile private var zoom = MIN_ZOOM
    private var cameraInitialized = false

    private var worldWidth = 0f
    private var worldHeight = 0f
    private var lastGridCellSize = 0f

    private val particles = mutableListOf<Particle>()
    private lateinit var attraction: Array<FloatArray>
    @Volatile private lateinit var grid: SpatialGrid

    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fpsPaint = Paint().apply {
        color = Color.WHITE
        textSize = 34f
        isAntiAlias = true
    }
    private val rulesPanelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rulesSwatchPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rulesCellPaint = Paint()
    private val rulesLegendPaint = Paint().apply {
        color = Color.rgb(210, 210, 220)
        textSize = 22f
        isAntiAlias = true
    }

    private var lastFpsTime = 0L
    private var frameCount = 0
    private var fps = 0

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val oldZoom = zoom
            val newZoom = (oldZoom * detector.scaleFactor).coerceIn(MIN_ZOOM, MAX_ZOOM)
            if (worldWidth > 0f && worldHeight > 0f) {
                // Keep the point under the pinch focus stationary on screen
                // instead of always zooming toward the center - otherwise
                // content drifts out from under your fingers as you pinch.
                val focusWorldX = (detector.focusX - width / 2f) / oldZoom + cameraX
                val focusWorldY = (detector.focusY - height / 2f) / oldZoom + cameraY
                cameraX = wrapCoord(focusWorldX - (detector.focusX - width / 2f) / newZoom, worldWidth)
                cameraY = wrapCoord(focusWorldY - (detector.focusY - height / 2f) / newZoom, worldHeight)
            }
            zoom = newZoom
            return true
        }
    })

    private var lastTouchX = 0f
    private var lastTouchY = 0f

    init {
        holder.addCallback(this)
        randomizeAttractionMatrix()
    }

    // ---------- touch: pinch to zoom, drag to pan ----------
    // No GestureDetector/double-tap here - double-tap detection was firing
    // on quick consecutive drag gestures (two swipes done in a row look a
    // lot like a double-tap to the detector) and resetting the camera
    // mid-pan, which is why panning could feel like it "restarted." A
    // dedicated Center button in the menu covers that need instead.

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastTouchX = event.x
                lastTouchY = event.y
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1 && !scaleDetector.isInProgress && worldWidth > 0f && worldHeight > 0f) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    cameraX = wrapCoord(cameraX - dx / zoom, worldWidth)
                    cameraY = wrapCoord(cameraY - dy / zoom, worldHeight)
                }
                lastTouchX = event.x
                lastTouchY = event.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // A finger lifted but at least one remains - resync the
                // reference point to whichever pointer stays down, so
                // panning resumes cleanly with no jump once back to one
                // finger, instead of using a stale pointer-0 position.
                val remainingIndex = if (event.actionIndex == 0) 1 else 0
                if (remainingIndex < event.pointerCount) {
                    lastTouchX = event.getX(remainingIndex)
                    lastTouchY = event.getY(remainingIndex)
                }
            }
        }
        return true
    }

    private fun wrapCoord(value: Float, max: Float): Float {
        if (max <= 0f) return value
        var v = value % max
        if (v < 0f) v += max
        return v
    }

    // ---------- SurfaceHolder.Callback ----------

    override fun surfaceCreated(holder: SurfaceHolder) {
        hasSurface = true
        if (particles.isEmpty()) resetParticles()
        resume()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        worldWidth = w * WORLD_SCALE
        worldHeight = h * WORLD_SCALE
        grid = SpatialGrid(worldWidth, worldHeight, interactionRange)
        lastGridCellSize = interactionRange
        if (!cameraInitialized) {
            cameraX = worldWidth / 2f
            cameraY = worldHeight / 2f
            cameraInitialized = true
        }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        hasSurface = false
        pause()
    }

    // ---------- lifecycle (called from MainActivity onResume/onPause) ----------

    fun resume() {
        if (running || !hasSurface) return
        running = true
        thread = Thread(this, "ParticleLifeLoop").apply { start() }
    }

    fun pause() {
        running = false
        thread?.join(500)
        thread = null
    }

    // ---------- public controls (called from the UI thread via button/slider input) ----------

    /** Requests a brand new random rule matrix; applied on the sim thread at the top of the next frame. */
    fun randomizeRules() {
        pendingRandomize = true
    }

    /** Requests the CURRENT rule matrix be nudged a little rather than replaced; applied on the sim thread. */
    fun mutateRules() {
        pendingMutate = true
    }

    /** Requests particles be reshuffled to random positions using the current rules. */
    fun resetParticles() {
        pendingReset = true
    }

    /** Switches to the next color palette. Purely visual - safe to flip directly, no sim-thread handoff needed. */
    fun cycleColors() {
        paletteIndex = (paletteIndex + 1) % COLOR_PALETTES.size
    }

    /** Shows/hides the attraction-matrix legend overlay so you can see what color attracts/repels what. */
    fun toggleRules() {
        showRules = !showRules
    }

    /** Snaps the camera back to fully zoomed out, centered on the world. */
    fun resetCamera() {
        zoom = MIN_ZOOM
        if (worldWidth > 0f) cameraX = worldWidth / 2f
        if (worldHeight > 0f) cameraY = worldHeight / 2f
    }

    /** How far the always-repulsive zone extends, as a percent of the interaction range. Applies live. */
    fun setRepelPercent(percent: Int) {
        repelPercent = percent.coerceIn(MIN_REPEL_PERCENT, MAX_REPEL_PERCENT)
    }

    /** Width of the neutral dead zone right after Repel, before Attract begins - percent of range. Applies live. */
    fun setGapPercent(percent: Int) {
        gapPercent = percent.coerceIn(MIN_GAP_PERCENT, MAX_GAP_PERCENT)
    }

    /** Max distance particles can affect each other at all. Applies live; resizes the spatial grid next frame. */
    fun setInteractionRange(range: Int) {
        interactionRange = range.coerceIn(MIN_RANGE, MAX_RANGE).toFloat()
    }

    // All mutation of `particles` / `attraction` happens only on the sim
    // thread (inside update()), triggered by the volatile flags above.
    // That keeps the button/slider/touch-driven UI thread from ever
    // touching the lists the render/physics loop is iterating, so no
    // locking is needed.

    private fun doResetParticles() {
        val w = worldWidth.takeIf { it > 0f } ?: (1080f * WORLD_SCALE)
        val h = worldHeight.takeIf { it > 0f } ?: (1920f * WORLD_SCALE)
        particles.clear()
        repeat(NUM_TYPES) { type ->
            repeat(PARTICLES_PER_TYPE) {
                particles.add(Particle(x = Random.nextFloat() * w, y = Random.nextFloat() * h, type = type))
            }
        }
    }

    private fun randomizeAttractionMatrix() {
        attraction = Array(NUM_TYPES) { FloatArray(NUM_TYPES) { Random.nextFloat() * 2f - 1f } }
    }

    private fun mutateAttractionMatrix() {
        for (i in 0 until NUM_TYPES) {
            for (j in 0 until NUM_TYPES) {
                val delta = (Random.nextFloat() * 2f - 1f) * MUTATE_STRENGTH
                attraction[i][j] = (attraction[i][j] + delta).coerceIn(-1f, 1f)
            }
        }
    }

    // ---------- game loop ----------

    override fun run() {
        val frameTimeMs = 1000L / TARGET_FPS
        while (running) {
            val start = System.currentTimeMillis()
            val dt = 1f / TARGET_FPS

            update(dt)
            draw()
            trackFps(start)

            val sleep = frameTimeMs - (System.currentTimeMillis() - start)
            if (sleep > 0) {
                try {
                    Thread.sleep(sleep)
                } catch (_: InterruptedException) {
                }
            }
        }
    }

    private fun trackFps(now: Long) {
        frameCount++
        if (now - lastFpsTime >= 1000) {
            fps = frameCount
            frameCount = 0
            lastFpsTime = now
        }
    }

    // ---------- simulation ----------

    private fun update(dt: Float) {
        if (pendingRandomize) {
            randomizeAttractionMatrix()
            pendingRandomize = false
        }
        if (pendingMutate) {
            mutateAttractionMatrix()
            pendingMutate = false
        }
        if (pendingReset) {
            doResetParticles()
            pendingReset = false
        }

        if (!::grid.isInitialized || worldWidth == 0f || worldHeight == 0f) return

        // Cell size has to track the current range: cells smaller than the
        // range would make the 3x3-neighbor-cell search miss valid pairs.
        // Cheap to rebuild (just empty bucket lists, no particle work), so
        // it's fine to check every frame - this only actually reconstructs
        // when the Distance slider changed since last frame.
        val range = interactionRange
        if (range != lastGridCellSize) {
            grid = SpatialGrid(worldWidth, worldHeight, range)
            lastGridCellSize = range
        }
        val g = grid
        g.rebuild(particles)

        val w = worldWidth
        val h = worldHeight
        val repelEnd = range * (repelPercent / 100f)
        val attractStart = (repelEnd + range * (gapPercent / 100f)).coerceAtMost(range - 1f)

        for (p in particles) {
            var fx = 0f
            var fy = 0f

            g.forEachNearby(p.x, p.y) { j ->
                val other = particles[j]
                if (other !== p) {
                    // Minimum-image distance: on a wrapped world, the short
                    // way around an edge can be closer than the raw delta.
                    var dx = other.x - p.x
                    if (dx > w * 0.5f) dx -= w else if (dx < -w * 0.5f) dx += w
                    var dy = other.y - p.y
                    if (dy > h * 0.5f) dy -= h else if (dy < -h * 0.5f) dy += h

                    val distSq = dx * dx + dy * dy
                    if (distSq > 0.0001f && distSq < range * range) {
                        val dist = sqrt(distSq)
                        val f = forceAt(dist, attraction[p.type][other.type], repelEnd, attractStart, range)
                        fx += f * dx / dist
                        fy += f * dy / dist
                    }
                }
            }

            p.vx = (p.vx + fx * FORCE_SCALE * dt) * FRICTION
            p.vy = (p.vy + fy * FORCE_SCALE * dt) * FRICTION

            val speed = sqrt(p.vx * p.vx + p.vy * p.vy)
            if (speed > MAX_SPEED) {
                p.vx = p.vx / speed * MAX_SPEED
                p.vy = p.vy / speed * MAX_SPEED
            }

            p.x += p.vx * dt
            p.y += p.vy * dt

            // Toroidal wrap - no walls. A particle that exits one edge
            // re-enters the opposite edge with velocity untouched.
            if (p.x < 0f) p.x += w else if (p.x >= w) p.x -= w
            if (p.y < 0f) p.y += h else if (p.y >= h) p.y -= h
        }
    }

    /**
     * Signed force magnitude (roughly -1..1) at distance [r]. Three zones:
     * always repulsive below [repelEnd]; zero force (dead zone) between
     * [repelEnd] and [attractStart]; beyond that, ramps up to rule
     * coefficient [a] at the midpoint of the remaining distance, back down
     * to 0 at [range].
     */
    private fun forceAt(r: Float, a: Float, repelEnd: Float, attractStart: Float, range: Float): Float {
        return when {
            r < repelEnd -> r / repelEnd - 1f
            r < attractStart -> 0f
            else -> {
                val span = range - attractStart
                val t = (r - attractStart) / span
                a * (1f - abs(2f * t - 1f))
            }
        }
    }

    // ---------- rendering ----------

    private fun draw() {
        val canvas: Canvas = holder.lockCanvas() ?: return
        try {
            // Hard clear every frame - no motion-trail overlay.
            canvas.drawColor(Color.rgb(8, 8, 16))

            if (worldWidth > 0f && worldHeight > 0f) {
                val colors = COLOR_PALETTES[paletteIndex]
                val z = zoom
                canvas.save()
                canvas.scale(z, z)
                canvas.translate(width / (2f * z) - cameraX, height / (2f * z) - cameraY)

                // Each particle only exists once, in [0,worldWidth) x
                // [0,worldHeight) - but the world wraps, so near an edge (or
                // whenever the viewport is close to a full world-width/
                // height across) that single copy isn't enough to cover
                // what's visible. Draw whichever wrapped copies (offset by
                // +/- a world size) actually fall inside the current view -
                // without this, panning past the edge showed empty space
                // instead of the wrapped content, which is what made the
                // world feel bordered instead of seamless. At most 2 tiles
                // per axis are ever needed since MIN_ZOOM (max zoom-out) is
                // calibrated to show exactly one world-width at once.
                val halfViewW = width / (2f * z)
                val halfViewH = height / (2f * z)
                val tileMinX = floor((cameraX - halfViewW) / worldWidth).toInt()
                val tileMaxX = floor((cameraX + halfViewW) / worldWidth).toInt()
                val tileMinY = floor((cameraY - halfViewH) / worldHeight).toInt()
                val tileMaxY = floor((cameraY + halfViewH) / worldHeight).toInt()

                for (tx in tileMinX..tileMaxX) {
                    val offsetX = tx * worldWidth
                    for (ty in tileMinY..tileMaxY) {
                        val offsetY = ty * worldHeight
                        for (p in particles) {
                            particlePaint.color = colors[p.type % colors.size]
                            canvas.drawCircle(p.x + offsetX, p.y + offsetY, PARTICLE_RADIUS_WORLD, particlePaint)
                        }
                    }
                }
                canvas.restore()
            }

            // Everything below draws in raw screen pixels, outside the
            // camera transform, so it stays fixed to the screen regardless
            // of pan/zoom.
            if (showRules) drawRulesOverlay(canvas)
            canvas.drawText("FPS: $fps  |  particles: ${particles.size}", 24f, 60f, fpsPaint)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    /**
     * Small legend panel: an NxN grid where cell (row, col) shows how the
     * row's species reacts to the column's species - green means attract,
     * red means repel, brightness is the strength. Row/column headers are
     * color swatches so they map directly to what's on screen. `attraction`
     * is only ever touched from this same sim thread, so no locking is
     * needed here either.
     */
    private fun drawRulesOverlay(canvas: Canvas) {
        val colors = COLOR_PALETTES[paletteIndex]
        val cell = 30f
        val headerSize = 26f
        val pad = 16f
        val left = 24f
        val top = 100f

        val gridLeft = left + pad + headerSize
        val gridTop = top + pad + headerSize
        val gridSize = cell * NUM_TYPES

        val legendLine1 = "rows react to columns"
        val legendLine2 = "green = attract, red = repel"
        val legendWidth = maxOf(
            rulesLegendPaint.measureText(legendLine1),
            rulesLegendPaint.measureText(legendLine2)
        )
        val contentWidth = maxOf(gridSize, legendWidth)

        val panelRight = left + pad + headerSize + contentWidth + pad
        val panelBottom = gridTop + gridSize + pad + 58f

        rulesPanelPaint.color = Color.argb(225, 14, 14, 22)
        canvas.drawRoundRect(left, top, panelRight, panelBottom, 20f, 20f, rulesPanelPaint)

        for (i in 0 until NUM_TYPES) {
            rulesSwatchPaint.color = colors[i % colors.size]
            canvas.drawCircle(gridLeft + i * cell + cell / 2f, top + pad + headerSize / 2f, 8f, rulesSwatchPaint)
            canvas.drawCircle(left + pad + headerSize / 2f, gridTop + i * cell + cell / 2f, 8f, rulesSwatchPaint)
        }

        for (i in 0 until NUM_TYPES) {
            for (j in 0 until NUM_TYPES) {
                val v = attraction[i][j].coerceIn(-1f, 1f)
                val mag = abs(v)
                rulesCellPaint.color = if (v >= 0f) {
                    Color.rgb(lerp(40, 60, mag), lerp(40, 210, mag), lerp(50, 90, mag))
                } else {
                    Color.rgb(lerp(40, 220, mag), lerp(40, 55, mag), lerp(50, 60, mag))
                }
                val cx = gridLeft + j * cell
                val cy = gridTop + i * cell
                canvas.drawRect(cx + 1f, cy + 1f, cx + cell - 1f, cy + cell - 1f, rulesCellPaint)
            }
        }

        canvas.drawText(legendLine1, left + pad, gridTop + gridSize + pad + 24f, rulesLegendPaint)
        canvas.drawText(legendLine2, left + pad, gridTop + gridSize + pad + 50f, rulesLegendPaint)
    }

    private fun lerp(a: Int, b: Int, t: Float): Int = (a + (b - a) * t.coerceIn(0f, 1f)).toInt()
}
