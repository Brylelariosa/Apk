package com.particlelife.app

/**
 * Coarse grid of per-species pheromone/trail intensity. Particles deposit
 * into their own species' channel as they move and sample nearby channels
 * to steer - attracted to trails left by species they like (per the same
 * attraction matrix used for direct particle-to-particle forces), repelled
 * by trails from species they dislike. Trails fade every frame, which is
 * what produces path-following, looping, and colony-like movement instead
 * of a permanently painted-on world.
 *
 * Deliberately much coarser than SpatialGrid: a handful of pheromone cells
 * per particle radius is plenty of steering resolution, and keeping cell
 * count small keeps decay() (an O(cells) full-array pass every frame) cheap
 * on mobile even though the world itself is large (WORLD_SCALE in GameView).
 *
 * The world wraps (toroidal), so neighbor sampling in [sampleInto] wraps
 * cell indices at the edges too, same idea as SpatialGrid.
 *
 * `cols`/`rows`/`fields`/`cellX`/`cellY` are `@PublishedApi internal` rather
 * than `private` because [sampleInto] is `inline` - same reason SpatialGrid
 * marks its own internals `@PublishedApi internal` for `forEachNearby`. A
 * public inline function's body is copied to every call site, so it can
 * only reference declarations that are visible there too.
 */
class TrailField(
    worldWidth: Float,
    worldHeight: Float,
    @PublishedApi internal val cellSize: Float,
    @PublishedApi internal val numSpecies: Int
) {
    @PublishedApi internal val cols = (worldWidth / cellSize).toInt().coerceAtLeast(4)
    @PublishedApi internal val rows = (worldHeight / cellSize).toInt().coerceAtLeast(4)

    // One flat FloatArray per species ([row * cols + col] layout) rather
    // than array-of-arrays-of-arrays - this is a hot per-frame path for
    // every particle, so keep indexing cheap.
    @PublishedApi internal val fields: Array<FloatArray> = Array(numSpecies) { FloatArray(cols * rows) }

    @PublishedApi internal fun cellX(x: Float) = (x / cellSize).toInt().coerceIn(0, cols - 1)
    @PublishedApi internal fun cellY(y: Float) = (y / cellSize).toInt().coerceIn(0, rows - 1)

    /** Deposits [amount] of trail into [p]'s own species channel at its current cell. */
    fun deposit(p: Particle, amount: Float) {
        val idx = cellY(p.y) * cols + cellX(p.x)
        val field = fields[p.type % numSpecies]
        field[idx] = (field[idx] + amount).coerceAtMost(TRAIL_MAX)
    }

    /** Multiplies every cell of every species channel by [decay] (e.g. 0.985 = fades ~1.5%/frame). */
    fun decay(decay: Float) {
        for (field in fields) {
            for (i in field.indices) {
                val v = field[i]
                if (v > MIN_VISIBLE) field[i] = v * decay else if (v != 0f) field[i] = 0f
            }
        }
    }

    /** Zeroes every channel - used when resetting particles for a clean slate. */
    fun clear() {
        for (field in fields) field.fill(0f)
    }

    /**
     * Estimates the trail gradient at [p]'s position for every OTHER
     * species, weighted by [affinity] (typically that species pair's
     * attraction coefficient - positive follows the trail, negative avoids
     * it), and hands the combined steering vector to [onResult]. Uses a
     * 4-direction finite difference (N/E/S/W neighbor cells) rather than a
     * full kernel convolution - cheap, and a coarse direction is all that's
     * needed for steering.
     */
    inline fun sampleInto(p: Particle, affinity: (Int) -> Float, onResult: (Float, Float) -> Unit) {
        val cx = cellX(p.x)
        val cy = cellY(p.y)
        val xm1 = if (cx > 0) cx - 1 else cols - 1
        val xp1 = if (cx < cols - 1) cx + 1 else 0
        val ym1 = if (cy > 0) cy - 1 else rows - 1
        val yp1 = if (cy < rows - 1) cy + 1 else 0

        var gx = 0f
        var gy = 0f
        for (species in 0 until numSpecies) {
            val a = affinity(species)
            if (a == 0f) continue
            val field = fields[species]
            val east = field[cy * cols + xp1]
            val west = field[cy * cols + xm1]
            val south = field[yp1 * cols + cx]
            val north = field[ym1 * cols + cx]
            gx += (east - west) * a
            gy += (south - north) * a
        }
        onResult(gx, gy)
    }

    companion object {
        private const val TRAIL_MAX = 40f
        private const val MIN_VISIBLE = 0.001f
    }
}
