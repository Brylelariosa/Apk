package com.particlelife.app

/**
 * A single particle: a position, a velocity, and a species (type).
 * Type determines which row/column of the attraction matrix it uses
 * when computing forces against other particles.
 */
class Particle(
    var x: Float,
    var y: Float,
    var type: Int
) {
    var vx: Float = 0f
    var vy: Float = 0f
}
