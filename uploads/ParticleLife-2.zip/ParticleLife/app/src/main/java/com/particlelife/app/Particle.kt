package com.particlelife.app

/**
 * A single particle: a position, a velocity, and a species (type).
 * Type determines which row/column of the attraction matrix it uses
 * when computing forces against other particles.
 *
 * [age] only matters when GameView's aging system is enabled - seconds
 * since this particle last spawned, used to weaken and eventually respawn
 * it. Harmless dead weight when aging is off.
 */
class Particle(
    var x: Float,
    var y: Float,
    var type: Int
) {
    var vx: Float = 0f
    var vy: Float = 0f
    var age: Float = 0f
}
