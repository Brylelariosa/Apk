package com.particlelife.app

import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible

class MainActivity : AppCompatActivity() {

    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Without this, phones with a notch/punch-hole camera letterbox around
        // it by default - the window stops short instead of drawing behind it.
        // SHORT_EDGES forces true edge-to-edge, cutout included.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        setContentView(R.layout.activity_main)

        gameView = findViewById(R.id.gameView)
        // Restore sliders/palette/symmetric-mode/presets from last session
        // before anything below reads them for initial UI state.
        gameView.loadState(this)

        val actionPanel = findViewById<View>(R.id.actionPanelScroll)
        findViewById<View>(R.id.btnMenu).setOnClickListener {
            actionPanel.visibility = if (actionPanel.isVisible) View.GONE else View.VISIBLE
        }

        fun runAndCollapse(action: () -> Unit) {
            action()
            actionPanel.visibility = View.GONE
        }

        findViewById<View>(R.id.btnRandomize).setOnClickListener { runAndCollapse { gameView.randomizeRules() } }
        findViewById<View>(R.id.btnMutate).setOnClickListener { runAndCollapse { gameView.mutateRules() } }
        findViewById<View>(R.id.btnColors).setOnClickListener { runAndCollapse { gameView.cycleColors() } }
        findViewById<View>(R.id.btnRules).setOnClickListener { runAndCollapse { gameView.toggleRules() } }

        var isPaused = false
        val btnPause = findViewById<Button>(R.id.btnPause)
        btnPause.setOnClickListener {
            runAndCollapse {
                isPaused = !isPaused
                btnPause.text = if (isPaused) "Play" else "Pause"
                gameView.togglePause()
            }
        }

        findViewById<View>(R.id.btnCenter).setOnClickListener { runAndCollapse { gameView.resetCamera() } }
        findViewById<View>(R.id.btnReset).setOnClickListener { runAndCollapse { gameView.resetParticles() } }

        // liveApply on every drag tick - all three are just numbers read
        // fresh each frame in GameView, so there's no rebuild cost. Returns
        // a closure that snaps this slider (position, label, and
        // underlying value) back to its true default - used by the
        // Defaults button below. `initial` (possibly restored from last
        // session) seeds the starting position; `resetDefault` is always
        // the real factory default, so Defaults means Defaults even after
        // a restore.
        fun setupSlider(
            seekId: Int,
            labelId: Int,
            min: Int,
            max: Int,
            initial: Int,
            resetDefault: Int,
            labelPrefix: String,
            suffix: String = "",
            onChange: (Int) -> Unit
        ): () -> Unit {
            val seek = findViewById<SeekBar>(seekId)
            val label = findViewById<TextView>(labelId)

            fun applyValue(value: Int) {
                label.text = "$labelPrefix: $value$suffix"
                onChange(value)
            }

            seek.max = max - min
            seek.progress = initial - min
            applyValue(initial)

            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    applyValue(min + progress)
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })

            return {
                seek.progress = resetDefault - min
                applyValue(resetDefault)
            }
        }

        val forceCurveView = findViewById<ForceCurveView>(R.id.forceCurveView)
        fun refreshCurve() {
            forceCurveView.setParams(gameView.getRepelPercent(), gameView.getGapPercent(), gameView.getInteractionRange())
        }

        val resetRepel = setupSlider(
            R.id.seekRepel, R.id.lblRepel,
            GameView.MIN_REPEL_PERCENT, GameView.MAX_REPEL_PERCENT,
            gameView.getRepelPercent(), GameView.DEFAULT_REPEL_PERCENT,
            "Repel", suffix = "%"
        ) { gameView.setRepelPercent(it); refreshCurve() }

        val resetGap = setupSlider(
            R.id.seekGap, R.id.lblGap,
            GameView.MIN_GAP_PERCENT, GameView.MAX_GAP_PERCENT,
            gameView.getGapPercent(), GameView.DEFAULT_GAP_PERCENT,
            "Gap", suffix = "%"
        ) { gameView.setGapPercent(it); refreshCurve() }

        val resetDistance = setupSlider(
            R.id.seekDistance, R.id.lblDistance,
            GameView.MIN_RANGE, GameView.MAX_RANGE,
            gameView.getInteractionRange(), GameView.DEFAULT_RANGE,
            "Distance"
        ) { gameView.setInteractionRange(it); refreshCurve() }

        refreshCurve()

        var isSymmetric = gameView.isSymmetricRules()
        val btnSymmetric = findViewById<Button>(R.id.btnSymmetric)
        btnSymmetric.text = if (isSymmetric) "Symmetric: On" else "Symmetric: Off"
        btnSymmetric.setOnClickListener {
            runAndCollapse {
                isSymmetric = !isSymmetric
                btnSymmetric.text = if (isSymmetric) "Symmetric: On" else "Symmetric: Off"
                gameView.setSymmetricRules(isSymmetric)
            }
        }

        // ---- New behavior layers: Alignment, Aging, Trails, Predator/Prey, Auto-Mutate ----
        // Each is a simple on/off toggle following the exact same pattern as
        // Symmetric above; strength/tuning for the ones without a dedicated
        // slider uses a sensible fixed default inside GameView.

        var isAligning = gameView.isAlignmentEnabled()
        val btnAlign = findViewById<Button>(R.id.btnAlign)
        btnAlign.text = if (isAligning) "Align: On" else "Align: Off"
        btnAlign.setOnClickListener {
            runAndCollapse {
                isAligning = !isAligning
                btnAlign.text = if (isAligning) "Align: On" else "Align: Off"
                gameView.setAlignmentEnabled(isAligning)
            }
        }

        var isAging = gameView.isAgingEnabled()
        val btnAging = findViewById<Button>(R.id.btnAging)
        btnAging.text = if (isAging) "Age: On" else "Age: Off"
        btnAging.setOnClickListener {
            runAndCollapse {
                isAging = !isAging
                btnAging.text = if (isAging) "Age: On" else "Age: Off"
                gameView.setAgingEnabled(isAging)
            }
        }

        var isTrailing = gameView.isTrailsEnabled()
        val btnTrails = findViewById<Button>(R.id.btnTrails)
        btnTrails.text = if (isTrailing) "Trails: On" else "Trails: Off"
        btnTrails.setOnClickListener {
            runAndCollapse {
                isTrailing = !isTrailing
                btnTrails.text = if (isTrailing) "Trails: On" else "Trails: Off"
                gameView.setTrailsEnabled(isTrailing)
            }
        }

        var isPredatorPrey = gameView.isPredatorPreyEnabled()
        val btnPredator = findViewById<Button>(R.id.btnPredator)
        btnPredator.text = if (isPredatorPrey) "Predator: On" else "Predator: Off"
        btnPredator.setOnClickListener {
            runAndCollapse {
                isPredatorPrey = !isPredatorPrey
                btnPredator.text = if (isPredatorPrey) "Predator: On" else "Predator: Off"
                gameView.setPredatorPreyEnabled(isPredatorPrey)
            }
        }

        var isAutoMutate = gameView.isAutoMutateEnabled()
        val btnAutoMutate = findViewById<Button>(R.id.btnAutoMutate)
        btnAutoMutate.text = if (isAutoMutate) "Auto-Mutate: On" else "Auto-Mutate: Off"
        btnAutoMutate.setOnClickListener {
            runAndCollapse {
                isAutoMutate = !isAutoMutate
                btnAutoMutate.text = if (isAutoMutate) "Auto-Mutate: On" else "Auto-Mutate: Off"
                gameView.setAutoMutateEnabled(isAutoMutate)
            }
        }

        val resetFriction = setupSlider(
            R.id.seekFriction, R.id.lblFriction,
            GameView.MIN_FRICTION_PERCENT, GameView.MAX_FRICTION_PERCENT,
            gameView.getFriction(), GameView.DEFAULT_FRICTION_PERCENT,
            "Friction", suffix = "%"
        ) { gameView.setFriction(it) }

        val resetTrailStrength = setupSlider(
            R.id.seekTrailStrength, R.id.lblTrailStrength,
            GameView.MIN_TRAIL_PERCENT, GameView.MAX_TRAIL_PERCENT,
            gameView.getTrailStrength(), GameView.DEFAULT_TRAIL_PERCENT,
            "Trail Strength", suffix = "%"
        ) { gameView.setTrailStrength(it) }

        findViewById<View>(R.id.btnDefaults).setOnClickListener {
            runAndCollapse {
                resetRepel()
                resetGap()
                resetDistance()
                resetFriction()
                resetTrailStrength()
                refreshCurve()
            }
        }

        hideSystemUi()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
            )
    }

    override fun onPause() {
        super.onPause()
        gameView.saveState(this)
        gameView.pause()
    }

    override fun onResume() {
        super.onResume()
        gameView.resume()
    }
}
