# Add project specific ProGuard rules here.

# GameView is instantiated by name from activity_main.xml (LayoutInflater
# reflection), not from Kotlin code, so R8 has no call site to see - without
# this it's free to rename/strip it during release shrinking and the layout
# would fail to inflate at runtime.
-keep class com.particlelife.app.GameView {
    public <init>(android.content.Context);
    public <init>(android.content.Context, android.util.AttributeSet);
}
