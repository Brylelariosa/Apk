# VoxelGame HZCM — Development Log

---

## v23-debug  (2026-06-09)

### Context
All five v22 pipeline-stage counters confirmed working on first run:
- Generated: 323 chunks  ✅
- Meshed: 1292 clusters READY  ✅
- Uploaded: 38 758 faces resident  ✅
- Rendered: 441 draw calls  ✅
- Vertices: 232 548 visible verts  ✅

Pipeline is fully functional end-to-end. Screen is **still solid sky-blue** despite draw calls being issued.

### Root-cause analysis

#### Bug A — Camera spawns 46 blocks above terrain (y = 72 → terrain ≈ y 26)
With `pitch = 0` (horizontal view) and `RD = 7`:
- Y+ (top) faces of terrain blocks are **edge-on** — zero screen-space area — never rasterised.
- Side faces only enter the frustum at ≥ 66 blocks forward distance.
- At that range, fog (`fogStart = 0.70 × fogEnd = 63 blocks`) already tints terrain 10–100% sky colour.
- Result: either a sub-pixel strip at the screen bottom, or nothing visible at all.

**Fix**: `Camera::position.y` changed from `72` to `35` (≈ 9 blocks above surface). At y = 35 with horizontal pitch, terrain at y = 26 appears at NDC_y ≈ −0.86 from just 15 blocks forward, with vFog = 0 (well inside fog-clear zone).

#### Bug B — `GL_CULL_FACE` enabled with unverified winding
`glEnable(GL_CULL_FACE)` was active during all cluster draws.  The winding of faces in screen space has **never been independently verified** on a device:
- At certain camera orientations, CW faces are discarded even though the geometry is correct.
- With 100 % of faces potentially back-face-culled, the screen stays at clear colour (sky blue).

**Fix**: `glDisable(GL_CULL_FACE)` for this debugging session. Re-enable once winding is confirmed correct with visible geometry.

#### Bug C — Uniform locations never validated
`glGetUniformLocation` silently returns `-1` if the uniform name is misspelled, optimised out, or the program failed to link.  `glUniform*(-1, …)` is a no-op:
- `m_uMVP = -1` → `uMVP` stays as the default zero matrix → all `gl_Position = (0,0,0,0)` → degenerate triangles → nothing rasterises.
- `m_uOrigin = -1` → all clusters placed at world origin → all geometry stacked in a 16³ cube that may be outside the frustum.

**Fix**: After `glGetUniformLocation`, log each location value; `LOGE` with a descriptive message for any `-1`.

#### Bug D — `glVertexAttribDivisor` reset by driver on `glVertexAttribIPointer`
`DrawBatcher::issueDraws` calls `glVertexAttribIPointer(0/1, …)` once per cluster (~441×/frame).  On several known GLES3 drivers (Adreno 3xx/4xx, certain Mali) this silently resets the divisor from 1 back to 0, turning instanced into non-instanced rendering.  With divisor = 0 every vertex reads the same `aGeom`/`aMat` (the first face's data), producing degenerate same-position triangles for all 6 vertices.

**Fix**: Call `glVertexAttribDivisor(0, 1); glVertexAttribDivisor(1, 1)` immediately after `glBindVertexArray(m_clusterVao)` each frame.

#### Bug E — Fog onset too aggressive for current RD = 7
`fogStart = uFogEnd × 0.70`.  With `fogEnd = 7 × 16 × 0.8 = 89.6`:
- fogStart = 62.7 blocks.
- Nearest visible terrain (from spawn y = 35, horizontal): ≈ 13 blocks → vFog = 0 ✅ (this is fine now that spawn y is fixed).
- But at the old y = 72 spawn this was the reason any terrain that DID reach the screen appeared sky-coloured.

**Fix**: `fogStart = uFogEnd × 0.90` — reduces fog zone to the outermost 10 % of render distance.

### Changes made (v23-debug)
| File | Change |
|---|---|
| `Camera.h` | Spawn `position.y` 72 → 35 |
| `Renderer.cpp` | `glDisable(GL_CULL_FACE)` |
| `Renderer.cpp` | LOGI/LOGE for all uniform locations after link |
| `Renderer.cpp` | `glVertexAttribDivisor(0,1); (1,1)` after VAO bind each frame |
| `Renderer.cpp` | Fog onset 70 % → 90 % in vertex shader |
| `Renderer.cpp` | Per-frame log includes `camPos`, MVP column-0 values |
| `Renderer.cpp` | Commented diagnostic `fragColor = magenta` in frag shader |
| `DebugOverlay.h` | Added `camY`, `camPitch` fields to `WorldDebugStats` |
| `World.h` | Added `m_lastCamY` member |
| `World.cpp` | `update()` stores `m_lastCamY = camY` |
| `World.cpp` | `getDebugStats()` exposes `s.camY` |
| `jni_bridge.cpp` | DBG panel shows `CamY` in `[POSITION]` section |

### How to read the next debug run
1. Open logcat, filter `HZCMRenderer`.
2. Look for `init: prog=N uMVP=M …` — **all locations must be ≥ 0**.
3. Look for `render frame 1: MVP col0=(…)` — **must NOT be all zeros**.
4. Check `CamY` in DBG panel — **should be ~35 after landing, ~26-28 when on ground**.
5. If screen is still blue, uncomment the two `fragColor = magenta` lines in `Renderer.cpp` (fragment shader), rebuild, confirm screen turns magenta.  If it does → geometry correct, shader logic wrong.  If still blue → triangles degenerate, check MVP column-0 log.

---

## v23  (2026-06-09)

### Bug fix — `genTotal` used outside its scope
`genTotal` was declared inside the `if (!chunk->generated)` block (first-time generation path) but referenced in the mesh-logging loop below, which also runs for already-generated chunks being re-meshed.

**Fix**: replaced `genTotal` reference with a fresh `m_generatedChunks.load()` read named `genSoFar`.

---

## v22-fixed → v23 (initial debug instrumentation, 2026-06-09)

### Five pipeline-stage debug counters added
Required to diagnose the "only sky, no terrain" symptom by pinpointing which stage of the pipeline fails.

| Counter | Source |
|---|---|
| Generated Chunks | `m_generatedChunks` atomic, incremented in `workerChunkBuild` |
| Meshed Clusters READY | count of `ClusterState::READY` clusters across all chunks |
| Faces Resident | sum of `clusterFaceCount` for READY clusters |
| Draw Calls | `m_lastVisibleDraws` (unchanged) |
| Visible Vertices | `m_lastVisibleFaces × 6` |

### Culling disabled (Task 5)
`DISABLE_ALL_CULLING = true` in `gatherAndDraw()` bypasses:
- HierarchicalVisibility chunk-level cull
- Residency gate (`hasAnyResidentCluster`)
- Neighbour-in-flight soft guard
- Frustum AABB test
- Per-cluster sky/underground visibility
- Cluster state gate (READY/MESHED check)

The hard safety check (`offset == MEGA_INVALID || count == 0`) is **kept** — it only skips clusters with no actual GPU data and cannot hide valid geometry.

### Generation / mesh / upload logging
- `CHUNK_GENERATED (cx,cz) total=N` — first 50 chunks + every 100th.
- `MESH_FACES chunk(0,0) ci=N faces=N` — origin chunk logged on every build.
- `MESH_FACES_ZERO chunk(cx,cz) ci=N` — WARN for zero-face ground clusters.
- `GPU_UPLOAD OK chunk(cx,cz) ci=N faces=N` — first 20 uploads + origin chunk.

### Stats always updated
Removed `m_debugOverlay.isVisible()` gate — stats are refreshed every frame so counters are current the instant DBG is opened.

---

## v22 (baseline — world not rendering)

### Symptoms
- Game launches, UI renders (joystick, crosshair, health bar, DBG panel).
- Screen shows only sky colour.
- No world geometry visible regardless of player movement.

### Known fixes applied in v22
- `precision highp int` added to both vertex and fragment shaders (`flat out/in highp int vTexLayer` was rejected by strict Adreno/Mali/PowerVR drivers, causing `glLinkProgram` to fail silently and `glUseProgram(0)` to output solid blue).
- Atlas `glActiveTexture(GL_TEXTURE0)` made explicit before every bind.
- `glTexImage3D` error-checked immediately after upload.

### Open at end of v22
Despite shader precision fix, screen remains blue. Root causes identified in v23-debug session (see above).
