# VoxelGame HZCM — Changelog

## v22  (texture system bugfix)

### Root Cause: All Blocks Solid Blue

Every block appeared as a flat solid blue in-game when any PNG texture pack was
present. The underlying cause was a **GLSL shader compilation failure** triggered
by a missing integer precision qualifier, which silently disabled the entire
texture/rendering pipeline.

---

### Bug Fixes

#### 1. PRIMARY FIX — Missing `precision highp int;` in Fragment Shader
**File:** `app/src/main/cpp/core/Renderer.cpp` → `FRAG_SRC`

GLES 3.0 requires integer types in fragment shaders to have an explicit precision
qualifier. The fragment shader declared `precision mediump float;` but had no
`precision highp int;`. The `flat in int vTexLayer` varying therefore had no
precision — a hard error on strict GPU drivers (Qualcomm Adreno, ARM Mali,
PowerVR).

Without a valid int precision, `glCompileShader` failed on those drivers. The
`glLinkProgram` call received shader ID 0, returned 0 itself, and `m_prog` was
never set. Every frame `glUseProgram(0)` was called, activating no program. The
GPU fell back to an implementation-defined default fragment output — on most
Android devices this is `vec4(0, 0, 1, 1)` (solid blue) or the clear color.

**Fix:**
- Added `precision highp int;` to `FRAG_SRC` (fragment shader).
- Changed `flat in int vTexLayer` → `flat in highp int vTexLayer` so the
  precision is explicit on the input declaration as well.
- Added `int layer = clamp(vTexLayer, 0, 19);` before sampling for safety.

#### 2. Vertex Shader — Precision Mismatch on `vTexLayer` Output
Changed `flat out int vTexLayer` → `flat out highp int vTexLayer` to match
the fragment shader declaration exactly, as required by GLES 3.0 interface
matching rules.

#### 3. Vertex Shader — Atlas LUT Out-of-Bounds Guard
The `ATLAS_TILE[btype*3 + faceGroup]` lookup used `clamp(btype, 0, 15)` but did
not clamp the full expression. Added:
```glsl
int safeBtype = clamp(btype, 0, 15);
int lutIdx    = clamp(safeBtype * 3 + faceGroup, 0, 47);
vTexLayer     = clamp(ATLAS_TILE[lutIdx], 0, 19);
```
Prevents undefined behaviour if btype is corrupted or faceGroup is out of range.

#### 4. `initAtlas()` — Missing `glActiveTexture` + Silent Upload Failure
- Added `glActiveTexture(GL_TEXTURE0)` before `glBindTexture` to guarantee the
  atlas is bound to the correct unit regardless of what earlier code did.
- Added `glGetError()` check immediately after `glTexImage3D`. A silent upload
  failure here left all atlas layers as undefined data (often zero = black, or
  driver-specific garbage).
- Added null check on `m_atlasTexture` after `glGenTextures`.

#### 5. `setAtlasTile()` — Missing `glActiveTexture` + No Error Detection
- Added `glActiveTexture(GL_TEXTURE0)` before the bind (same reason as above).
- Clear pre-existing GL errors with `glGetError()` before the upload, then check
  after `glTexSubImage3D`. Errors here would previously be invisible in logcat.
- Added null pointer guard on `rgba16x16`.

#### 6. `compileShader()` / `linkProgram()` — Inadequate Error Reporting
- Log buffer enlarged from 512 → 2048 bytes. Precision-related error messages
  from GLES drivers are often very long and were being silently truncated.
- `compileShader` logs the shader type (VERTEX/FRAGMENT) with the error.
- `linkProgram` explicitly guards against receiving shader ID 0, logs
  "solid blue likely" as a diagnostic hint, and deletes shader objects cleanly.
- Both functions log on success so the developer can confirm the shader compiled.

#### 7. `GameRenderer.java` — Bitmap Loading Hardening
**File:** `app/src/main/java/com/voxelgame/GameRenderer.java`

Multiple failure modes in PNG loading could silently corrupt or skip tile uploads:

- **Hardware bitmap** (Android 8.1+): `BitmapFactory.decodeStream` can return a
  `Bitmap.Config.HARDWARE` bitmap on newer Android even when ARGB_8888 is
  preferred. Calling `getPixels()` on a HARDWARE bitmap throws
  `IllegalStateException`, which propagated past the `IOException` catch,
  aborting the load with no log entry and leaving the tile in its default state.
  **Fix:** Set `opts.inPreferredConfig = Bitmap.Config.ARGB_8888` and add an
  explicit post-decode HARDWARE check with a `copy(ARGB_8888)` fallback.
  The same guard is applied after `createScaledBitmap`, which can also return
  HARDWARE on some Android versions.

- **getPixels() unguarded**: Wrapped the `getPixels()` call in its own
  `try/catch (IllegalStateException)` so any remaining HARDWARE-bitmap slipthrough
  is caught and logged with the config name for diagnosis.

- **Density scaling**: Added `opts.inScaled = false` to prevent BitmapFactory from
  auto-scaling PNG assets based on device DPI. Texture pack images are
  density-independent and must not be scaled before the explicit 16×16 resize.

- **Pre-multiplied alpha**: Added `opts.inPremultiplied = false` to preserve raw
  channel values. Pre-multiplication would darken semi-transparent pixels (leaves,
  water) before they reach `getPixels()`, corrupting the texture data.

- **All-zero pixel detection**: After packing to RGBA bytes, a validation pass
  checks whether all RGB channels are zero and logs a warning. Zero-only pixels
  indicate a corrupt PNG, a completely transparent texture, or a silent decode
  failure upstream.

- **OOM handling**: Added `catch (OutOfMemoryError)` around the decode loop to
  prevent a single large texture from crashing the activity.

- **Leak-safe finally**: Revised `finally` to recycle both the original `bmp`
  reference and the intermediate `scaled` reference independently, preventing
  bitmap memory leaks on any error path.

- **Improved logging**: Every tile now logs its decoded size and config at DEBUG
  level; loaded/skipped counts are logged at INFO level at the end.

---

### No Breaking Changes
- PackedFace format unchanged.
- Chunk loading, streaming, MegaBuffer, DrawBatcher all unchanged.
- TextureAtlas.h procedural generator unchanged — procedural tiles remain the
  fallback for any PNG not found in assets/textures/.
- World, biome, and terrain generation unchanged.
- All v21 stability fixes intact.

---

## v22-patch2  (GPU slot exhaustion + diagnostics)

### Root Cause #2: GPU Slot Exhaustion at High Render Distance

With the shader precision fix applied (v22 patch1), the texture pipeline was
repaired. However at render distance **RD=36**, the screen remained blue because
no cluster ever reached the READY state needed to be drawn.

**The cause:** `PageAllocator` had 3,000 total GPU slots (size classes summing to
3,000 pages). At RD=36, approximately 16,284 cluster slots are needed. Every call
to `alloc()` beyond the 3,000th returned `MEGA_INVALID`, the upload was re-queued,
failed again next frame, and looped indefinitely. Clusters stayed permanently in
`MESHED` state. `gatherAndDraw` skipped them all (`offset == MEGA_INVALID`). The
screen stayed solid sky-blue.

The pressure eviction threshold (`evictThresh = RD*2/3 = 24`) only evicted chunks
at distance > 24, which still left ~1,809 chunks (7,236 cluster slots) competing
for the 3,000 available — far more than could ever fit.

### Fixes

#### 1. PageAllocator size class page counts raised (40 MB → safe up to RD≈36)
**File:** `app/src/main/cpp/core/hzcm/PageAllocator.h`

| Class | Old pages | New pages | Notes |
|-------|-----------|-----------|-------|
| 0 (≤64 faces)  | 600  | 1500 | Underground solid clusters |
| 1 (≤256 faces) | 1200 | 2500 | Most common surface clusters |
| 2 (≤1024 faces)| 900  | 1500 | Complex surface / biome variety |
| 3 (≤6144 faces)| 300  | 500  | Dense decorated clusters |
| **Total slots**| **3000** | **6000** | |
| **VRAM** | **~23.7 MB** | **~40.8 MB** | Acceptable on ≥2 GB RAM devices |

6,000 slots support ~1,500 chunks × 4 clusters comfortably.  At RD=36 the
pressure eviction keeps the nearest ~1,500 chunks GPU-resident and streams the
rest in as the camera moves.

#### 2. Pressure eviction threshold hard-capped at GPU_MAX_RESIDENT_RADIUS=20
**File:** `app/src/main/cpp/core/World.cpp`

Old formula `evictThresh = max(4, RD*2/3)` produced 24 at RD=36, keeping
too many distant chunks in VRAM. New formula:

```
evictThresh = min(max(4, RD*2/3), GPU_MAX_RESIDENT_RADIUS=20)
```

At RD=36: evictThresh=20, keeping ≤~1,256 chunks (≤5,024 clusters) — within
the 6,000 slot budget with room to spare.

#### 3. Diagnostic logging added
- `gatherAndDraw`: logs visible-draw count every 30 frames for the first 120 frames
- At frame 60: logs full cluster state breakdown (READY/MESHED/DIRTY/EMPTY) and
  GPU slot usage — makes "MESHED but no READY" instantly diagnosable in logcat
- `render()`: logs shader program ID, atlas texture ID, visible draw count, and
  fog distance for the first 10 frames
- `render()`: GL error check after the cluster draw pass with specific error message
- MegaBuffer init: validates VBO ID is non-zero and checks for OOM via `glGetError`

---

## v21  (texture atlas + biome overhaul)

### Texture Atlas (new feature)
- **Replaced** flat BLOCK_COL vec3 LUT with a real `GL_TEXTURE_2D_ARRAY` atlas.
- **20 layers × 16×16 RGBA8** pixel-art tiles generated procedurally at startup
  by the new `TextureAtlas.h` header (no external image files required).
- **Per-face tile assignment** via `ATLAS_TILE[blockType*3 + faceGroup]` LUT in
  the vertex shader — top / side / bottom faces get distinct tiles for every block.
- **Correct faces** for every block type:
  - Grass: green top, dirt-with-green-strip side, dirt bottom
  - Wood: bark-grain side, wood-ring top/bottom
  - Snow: bright-white top, cool-gray sides
  - Cactus: ribbed green side, cross-pattern top
  - Cobble: grout-line stone pattern
  - Stone, sand, gravel, red sand, clay, ice, basalt, water, leaves — all distinct
- **Greedy-mesh tiling**: `vRawUV = (cs, ct)` passed as unnormalized block-space
  coordinates (0..span0, 0..span1).  `GL_REPEAT` on the sampler tiles the 16×16
  tile once per block across any greedy-merged span with zero extra work.
- **Nearest-neighbour filtering** (`GL_NEAREST`) for crisp pixel-art look.
- **No texture bleeding** — each layer in the array is independent; GL_REPEAT
  wraps within that layer only, so atlas tiles can never bleed into each other.
- **AO and fog preserved** unchanged — vLight carries the combined factor.

### Biome Quality Improvements
- **Smooth biome gradients**: temperature and humidity now use 2-octave fbm at
  lower spatial frequency (0.0022 / 0.0028) instead of single noise2D calls.
  Biome regions are now large and smoothly varying instead of noisy patches.
- **Wider transition bands**: dithering increased from ±0.04 to ±0.06 combined
  with lower-frequency fbm creates 5-8 block wide blending zones vs old 3-4.
- **Tundra biome** (new): intermediate cold-grass zone (tN ∈ [0.24, 0.40]) with
  very sparse tree coverage — transitions snow ↔ temperate more naturally.
- **Shoreline smoothing**: height within ±4 blocks of sea level is pulled toward
  sea level by a quartic blend, eliminating abrupt beach cliffs and producing
  gentle sloping shores.
- **Valley floor materialisation**: high-erosion flat areas near sea level now
  place gravel in the sub-surface layer instead of stone, matching riverbeds.
- **Badlands** logic unchanged but better-looking due to smoother climate maps.

### Renderer Changes
- `TextureAtlas.h` added — procedural pixel-art generator, included by Renderer.cpp.
- `Renderer.h`: added `m_atlasTexture`, `m_uAtlas`, `initAtlas()`.
- `Renderer::init()`: calls `initAtlas()` after megabuffer init; sets `uAtlas=0`.
- `Renderer::render()`: binds atlas to `GL_TEXTURE0` before cluster draw pass.
- `Renderer::~Renderer()`: deletes atlas texture on teardown.
- Vertex shader: BLOCK_COL LUT removed; ATLAS_TILE LUT + vTexLayer + vRawUV added.
- Fragment shader: samples `sampler2DArray uAtlas`; applies lighting × fog.

### No Breaking Changes
- PackedFace format unchanged (geom + mat, 8 bytes).
- MegaBuffer, DrawBatcher, ClusterMesher all unchanged.
- Chunk loading, streaming, upload pipeline, render-distance system unchanged.
- Block types, Block.h unchanged.
- All v20 stability fixes (watchdog, retry queue, graveyard, thermal) intact.

---

## v20  (terrain + block-type expansion)
(see previous CHANGES.md)
