// ============================================================================
// HZCM v21 — Renderer.cpp
//
// Key changes from v20:
//   1. Texture atlas (GL_TEXTURE_2D_ARRAY) replaces flat BLOCK_COL LUT.
//      20 layers × 16×16 RGBA8 tiles, procedurally generated at init.
//   2. Top / side / bottom face texturing: ATLAS_TILE[48] LUT in the vertex
//      shader maps (blockType*3 + faceGroup) → atlas layer index.
//   3. UV coordinates (vRawUV) passed as unnormalized block-space coords so
//      GL_REPEAT tiles the texture naturally across greedy-merged spans.
//   4. Flat integer varying vTexLayer avoids interpolation artefacts.
//   5. AO and fog preserved unchanged.
//   6. Nearest-neighbour filtering (GL_NEAREST) for pixel-art look.
// ============================================================================
#include "Renderer.h"
#include "TextureAtlas.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <cstdio>
#include <vector>
#include <shared_mutex>

#define TAG  "HZCMRenderer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ============================================================================
// Vertex shader — texture-atlas driven  (GLES 3.0)
//
// Each face looks up its atlas tile from ATLAS_TILE[blockType*3+faceGroup].
// vRawUV = (cs, ct) in block-space units (0..span0, 0..span1).
// The fragment shader samples texture(uAtlas, vec3(vRawUV, layer))
// and GL_REPEAT handles tiling across greedy spans automatically.
//
// AO: bilinear across the greedy quad — unchanged from v20.
// Fog: onset at 70% of uFogEnd — unchanged from v20.
// ============================================================================
static const char* VERT_SRC = R"(#version 300 es
precision highp float;
precision highp int;

layout(location = 0) in uint aGeom;
layout(location = 1) in uint aMat;

uniform ivec3 uClusterOrigin;
uniform mat4  uMVP;
uniform vec3  uCamPos;
uniform float uFogEnd;

// Per-fragment outputs
flat out highp int  vTexLayer;   // atlas layer = tile index (flat: no interpolation)
out vec2      vRawUV;      // unnormalized block UV (0..span0, 0..span1)
out float     vLight;      // combined directional + AO factor
out float     vFog;

// ── LUT: per-face geometry ─────────────────────────────────────────────────
const vec3 FACE_S[6] = vec3[6](
    vec3(0,1,0), vec3(0,1,0),
    vec3(0,0,1), vec3(0,0,1),
    vec3(1,0,0), vec3(1,0,0)
);
const vec3 FACE_T[6] = vec3[6](
    vec3(0,0,1), vec3(0,0,1),
    vec3(1,0,0), vec3(1,0,0),
    vec3(0,1,0), vec3(0,1,0)
);
const vec3 FACE_N[6] = vec3[6](
    vec3(1,0,0), vec3(1,0,0),
    vec3(0,1,0), vec3(0,1,0),
    vec3(0,0,1), vec3(0,0,1)
);

const float FACE_LIGHT[6] = float[6](0.65, 0.65, 1.0, 0.35, 0.80, 0.80);

const int FRONT_CI[6] = int[6](0,1,2, 0,2,3);
const int BACK_CI [6] = int[6](0,2,1, 0,3,2);
const float CS4[4] = float[4](0.0, 1.0, 1.0, 0.0);
const float CT4[4] = float[4](0.0, 0.0, 1.0, 1.0);

// ── Atlas tile LUT ─────────────────────────────────────────────────────────
// Index: blockType * 3 + faceGroup  (faceGroup: 0=side, 1=top +Y, 2=bottom -Y)
// Tile indices match TextureAtlas.h:
//  0=debug  1=grassTop  2=grassSide  3=dirt      4=stone
//  5=sand   6=snowTop   7=snowSide   8=woodSide  9=woodTop
// 10=leaves 11=water   12=gravel    13=redSand  14=clay
// 15=ice   16=cactusSide 17=cactusTop 18=basalt 19=cobble
const int ATLAS_TILE[48] = int[48](
    // 0 AIR (unused — magenta debug)
    0, 0, 0,
    // 1 GRASS: side=grassSide, top=grassTop, bottom=dirt
    2, 1, 3,
    // 2 DIRT
    3, 3, 3,
    // 3 STONE
    4, 4, 4,
    // 4 SAND
    5, 5, 5,
    // 5 SNOW: side=snowSide, top=snowTop, bottom=snowSide
    7, 6, 7,
    // 6 WOOD: side=woodSide, top=woodTop, bottom=woodTop
    8, 9, 9,
    // 7 LEAVES
    10, 10, 10,
    // 8 WATER
    11, 11, 11,
    // 9 GRAVEL
    12, 12, 12,
    // 10 RED_SAND
    13, 13, 13,
    // 11 CLAY
    14, 14, 14,
    // 12 ICE
    15, 15, 15,
    // 13 CACTUS: side=cactusSide, top/bottom=cactusTop
    16, 17, 17,
    // 14 BASALT
    18, 18, 18,
    // 15 COBBLE
    19, 19, 19
);

void main() {
    int geom = int(aGeom);
    int mat  = int(aMat);

    // ── Unpack geometry word ───────────────────────────────────────────────
    int faceDir = geom & 7;
    int ox      = (geom >>  3) & 15;
    int oy      = (geom >>  7) & 15;
    int oz      = (geom >> 11) & 15;
    int span0   = ((geom >> 15) & 15) + 1;
    int span1   = ((geom >> 19) & 15) + 1;

    // ── Unpack material word ───────────────────────────────────────────────
    int btype = mat & 255;
    int ao0   = (mat >>  8) & 3;
    int ao1   = (mat >> 10) & 3;
    int ao2   = (mat >> 12) & 3;
    int ao3   = (mat >> 14) & 3;

    // ── Corner selection (branchless winding) ──────────────────────────────
    int vi        = gl_VertexID % 6;
    int cornerIdx = ((faceDir & 1) == 0) ? FRONT_CI[vi] : BACK_CI[vi];

    float cs = CS4[cornerIdx] * float(span0);
    float ct = CT4[cornerIdx] * float(span1);

    // ── Reconstruct world position ─────────────────────────────────────────
    vec3 lpos = vec3(float(ox), float(oy), float(oz));
    lpos += FACE_S[faceDir] * cs;
    lpos += FACE_T[faceDir] * ct;
    lpos += FACE_N[faceDir];

    vec3 wpos = lpos + vec3(float(uClusterOrigin.x),
                             float(uClusterOrigin.y),
                             float(uClusterOrigin.z));
    vec3 relPos = wpos - uCamPos;

    // ── AO (bilinear across greedy quad) ──────────────────────────────────
    float aof0 = 0.35 + float(ao0) * 0.2167;
    float aof1 = 0.35 + float(ao1) * 0.2167;
    float aof2 = 0.35 + float(ao2) * 0.2167;
    float aof3 = 0.35 + float(ao3) * 0.2167;
    float su = (span0 > 0) ? cs / float(span0) : 0.0;
    float sv = (span1 > 0) ? ct / float(span1) : 0.0;
    float ao = mix(mix(aof0, aof1, su), mix(aof3, aof2, su), sv);

    // ── Atlas tile lookup ──────────────────────────────────────────────────
    // FIX v22: clamp btype and final LUT index for out-of-bounds safety.
    int faceGroup = (faceDir == 2) ? 1 : (faceDir == 3) ? 2 : 0;
    int safeBtype = clamp(btype, 0, 15);
    int lutIdx    = clamp(safeBtype * 3 + faceGroup, 0, 47);
    int tileIdx   = ATLAS_TILE[lutIdx];
    vTexLayer     = clamp(tileIdx, 0, 19);

    // ── UV: pass unnormalized span coords — GL_REPEAT tiles the atlas ──────
    // cs ∈ [0, span0], ct ∈ [0, span1].  GPU interpolates between corners.
    // Fragment sampler repeats the 16×16 tile at every integer boundary.
    vRawUV = vec2(cs, ct);

    // ── Combined light factor (directional × AO) ───────────────────────────
    vLight = FACE_LIGHT[faceDir] * ao;

    // ── Fog (onset at 70% of uFogEnd) ─────────────────────────────────────
    float dist     = length(relPos);
    float fogStart = uFogEnd * 0.90; // FIX v23: 70->90% onset, terrain stays clear further
    vFog = clamp((dist - fogStart) / (uFogEnd - fogStart + 0.001), 0.0, 1.0);

    gl_Position = uMVP * vec4(relPos, 1.0);
}
)";

static const char* FRAG_SRC = R"(#version 300 es
// FIX v22: precision highp int is REQUIRED for the flat integer varying vTexLayer.
// Without it, strict GLES3 drivers (Adreno, Mali, PowerVR) reject compilation with
// "mediump/highp precision storage specifier required for int type".
// This causes glLinkProgram to fail, m_prog stays 0, and glUseProgram(0) produces
// an implementation-defined default color on the GPU -- commonly solid blue.
precision mediump float;
precision highp int;

uniform sampler2DArray uAtlas;   // 20 layers x 16x16 RGBA8

flat in highp int  vTexLayer;   // atlas layer (block-type + face-group lookup)
in vec2            vRawUV;      // unnormalized block UV -- GL_REPEAT tiles it
in float           vLight;      // directional + AO combined factor
in float           vFog;

out vec4 fragColor;

const vec3 SKY = vec3(0.52, 0.77, 0.95);

void main() {
    // Guard: clamp to valid atlas range [0, ATLAS_TILE_COUNT-1].
    // Prevents out-of-bounds layer sampling if btype somehow exceeds 15.
    int layer = clamp(vTexLayer, 0, 19);

    // Sample atlas tile.  vRawUV ranges 0..span, GL_REPEAT tiles the 16x16
    // texture once per block, giving correct tiling on greedy-merged faces.
    vec4 tex = texture(uAtlas, vec3(vRawUV, float(layer)));

    // Apply directional lighting + per-vertex AO
    vec3 lit = tex.rgb * vLight;

    // Diagnostic: uncomment next 2 lines → solid magenta on all cluster fragments.
    // If screen stays blue, vertex positions are degenerate (check MVP col0 in logcat).
    // fragColor = vec4(0.9, 0.1, 0.9, 1.0);
    // return;

    // Fog blend toward sky colour
    fragColor = vec4(mix(lit, SKY, vFog), 1.0);
}
)";

// ── Crosshair ─────────────────────────────────────────────────────────────────
static const char* HUD_VERT = R"(#version 300 es
layout(location=0) in vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }
)";
static const char* HUD_FRAG = R"(#version 300 es
precision mediump float;
out vec4 o;
void main() { o = vec4(1.0, 1.0, 1.0, 0.8); }
)";

// ── Debug overlay (coloured quad + no-font digit rendering) ───────────────────
// We draw thermal pressure as a horizontal bar and a small colour indicator.
// Full text requires a font atlas which is out of scope; we show a colour bar.
static const char* DBG_VERT = R"(#version 300 es
layout(location=0) in vec2 aPos;
layout(location=1) in vec3 aCol;
out vec3 vCol;
void main() { vCol = aCol; gl_Position = vec4(aPos, 0.0, 1.0); }
)";
static const char* DBG_FRAG = R"(#version 300 es
precision mediump float;
in  vec3 vCol;
out vec4 o;
void main() { o = vec4(vCol, 0.75); }
)";

// ── Shader helpers ────────────────────────────────────────────────────────────
GLuint Renderer::compileShader(GLenum type, const char* src) {
    if (!src) { LOGE("compileShader: null source"); return 0; }
    GLuint s = glCreateShader(type);
    if (!s) { LOGE("compileShader: glCreateShader returned 0 (context lost?)"); return 0; }
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = GL_FALSE;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        // FIX v22: use larger log buffer — precision/varying errors can be verbose.
        char log[2048];
        GLsizei len = 0;
        glGetShaderInfoLog(s, (GLsizei)sizeof(log)-1, &len, log);
        log[len] = '\0';
        LOGE("Shader compile error (type=%s):\n%s",
             (type == GL_VERTEX_SHADER ? "VERTEX" : "FRAGMENT"), log);
        LOGE(">>> If error mentions 'precision' or 'int': verify precision highp int; "
             "is declared at the top of each shader that uses int varyings <<<");
        glDeleteShader(s);
        return 0;
    }
    LOGI("Shader compiled OK (type=%s)", (type == GL_VERTEX_SHADER ? "VERTEX" : "FRAGMENT"));
    return s;
}

GLuint Renderer::linkProgram(GLuint v, GLuint f) {
    if (!v || !f) {
        LOGE("linkProgram: one or both shaders failed to compile (v=%u f=%u) — "
             "program will be invalid; textures will NOT render (solid blue likely)", v, f);
        if (v) glDeleteShader(v);
        if (f) glDeleteShader(f);
        return 0;
    }
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok = GL_FALSE;
    glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[2048];
        GLsizei len = 0;
        glGetProgramInfoLog(p, (GLsizei)sizeof(log)-1, &len, log);
        log[len] = '\0';
        LOGE("Program link error:\n%s", log);
        glDeleteProgram(p);
        glDeleteShader(v);
        glDeleteShader(f);
        return 0;
    }
    glDeleteShader(v); glDeleteShader(f);
    LOGI("Program linked OK (id=%u)", p);
    return p;
}

// ── Init ───────────────────────────────────────────────────────────────────────
void Renderer::init() {
    LOGI("Renderer::init()");

    m_prog   = linkProgram(compileShader(GL_VERTEX_SHADER,   VERT_SRC),
                            compileShader(GL_FRAGMENT_SHADER, FRAG_SRC));
    m_uMVP    = glGetUniformLocation(m_prog, "uMVP");
    m_uCamPos = glGetUniformLocation(m_prog, "uCamPos");
    m_uOrigin = glGetUniformLocation(m_prog, "uClusterOrigin");
    m_uFogEnd = glGetUniformLocation(m_prog, "uFogEnd");
    m_uAtlas  = glGetUniformLocation(m_prog, "uAtlas");

    // FIX v23: validate every uniform location — -1 means glUniform* is a no-op.
    // Most critical: m_uMVP=-1 → zero MVP → all vertices at (0,0,0,0) → invisible.
    LOGI("init: prog=%u uMVP=%d uCamPos=%d uOrigin=%d uFogEnd=%d uAtlas=%d",
         m_prog, m_uMVP, m_uCamPos, m_uOrigin, m_uFogEnd, m_uAtlas);
    if (m_uMVP    == -1) LOGE("init: uMVP=-1 → MVP never set → ALL GEOMETRY INVISIBLE");
    if (m_uCamPos == -1) LOGE("init: uCamPos=-1 → wrong relative positions");
    if (m_uOrigin == -1) LOGE("init: uClusterOrigin=-1 → all clusters at world origin");
    if (m_uAtlas  == -1) LOGE("init: uAtlas=-1 → sampler unbound → black blocks");

    if (!m_prog) {
        LOGE("init: shader program failed to link — texture atlas will NOT render!");
        LOGE("init: check shader compile log above for missing precision qualifiers.");
    }
    glUseProgram(m_prog);
    glUniform1f(m_uFogEnd, (float)(world.getEffectiveRadius()) * 16.f * 0.8f);
    glUniform1i(m_uAtlas, 0);   // FIX v22: atlas sampler bound to texture unit 0
    LOGI("init: uAtlas uniform = %d (texture unit 0)", m_uAtlas);

    // Cluster VAO: set up the instanced attribute layout once.
    glGenVertexArrays(1, &m_clusterVao);
    glBindVertexArray(m_clusterVao);
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glVertexAttribDivisor(0, 1);
    glVertexAttribDivisor(1, 1);
    glBindVertexArray(0);

    world.megaBuffer().init();

    // FIX v22: Verify the MegaBuffer VBO was created successfully.
    // If glGenBuffers or glBufferData fails (OOM, context not ready), the VBO
    // ID is 0. All subsequent glVertexAttribIPointer calls would silently use
    // offset 0 of the default VBO (nothing), producing no vertices → blue screen.
    if (!world.megaBuffer().vbo()) {
        LOGE("init: MegaBuffer VBO is 0 -- glGenBuffers or glBufferData failed!");
        LOGE("init: Check for GL_OUT_OF_MEMORY. totalFaces=%u (~%.1f MB)",
             world.megaBuffer().totalFaces(),
             (float)(world.megaBuffer().totalFaces() * 8) / (1024.f*1024.f));
    } else {
        LOGI("init: MegaBuffer VBO=%u totalFaces=%u (~%.1f MB)",
             world.megaBuffer().vbo(),
             world.megaBuffer().totalFaces(),
             (float)(world.megaBuffer().totalFaces() * 8) / (1024.f*1024.f));
    }

    // Task 4: flush + check GL errors after MegaBuffer init.
    {
        GLenum err = glGetError();
        if (err != GL_NO_ERROR)
            LOGE("init: GL error 0x%04X after MegaBuffer init (likely OOM for VBO)", err);
        else
            LOGI("init: MegaBuffer GL error check PASSED (no error)");
    }

    // Task 4: confirm VAO was created and divisors are set correctly.
    // glVertexAttribDivisor(0,1) + (1,1) means aGeom/aMat advance per instance.
    LOGI("init: clusterVAO=%u (divisors=1 on attribs 0,1; IPointers set per draw)",
         m_clusterVao);

    // v21: build + upload procedural texture atlas (GL_TEXTURE_2D_ARRAY)
    initAtlas();

    initHUD();
    initDebugOverlay();

    glEnable(GL_DEPTH_TEST);
    // FIX v23: GL_CULL_FACE disabled — winding unverified; back-face culling
    // may discard all geometry at spawn pitch=0.  Re-enable after winding audit.
    glDisable(GL_CULL_FACE);
    // glCullFace(GL_BACK);
    // glFrontFace(GL_CCW);
    glDepthFunc(GL_LEQUAL);
    glClearColor(SKY_R, SKY_G, SKY_B, 1.f);

    world.init(42);
    initialized = true;
    LOGI("Renderer init done. MegaBuffer: %.1f MB",
         (float)(world.megaBuffer().totalFaces() * sizeof(PackedFace)) / (1024.f*1024.f));
}

void Renderer::initAtlas() {
    // Generate all 20 tile layers into a flat buffer
    const int W = ATLAS_TILE_W, H = ATLAS_TILE_H, L = ATLAS_TILE_COUNT;
    std::vector<uint8_t> buf((size_t)(W * H * 4 * L));
    generateAtlasData(buf.data());

    glGenTextures(1, &m_atlasTexture);
    if (!m_atlasTexture) {
        LOGE("initAtlas: glGenTextures failed - no atlas texture ID");
        return;
    }
    // FIX v22: explicitly activate unit 0 before binding.
    // Default is GL_TEXTURE0 on a fresh context, but being explicit prevents
    // hard-to-trace bugs if any earlier code changed the active unit.
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D_ARRAY, m_atlasTexture);

    // Allocate the array storage and upload all layers at once
    glTexImage3D(GL_TEXTURE_2D_ARRAY,
                 0,            // mip level
                 GL_RGBA8,     // internal format
                 W, H, L,      // width, height, depth (= num layers)
                 0,            // border
                 GL_RGBA,      // pixel format
                 GL_UNSIGNED_BYTE,
                 buf.data());

    // FIX v22: check for GL errors immediately after upload.
    // Silent failures here leave the atlas uninitialised, causing all blocks
    // to sample from a zero/undefined texture (black or driver-specific color).
    {
        GLenum err = glGetError();
        if (err != GL_NO_ERROR) {
            LOGE("initAtlas: glTexImage3D error 0x%04X - atlas upload failed!", err);
        } else {
            LOGI("initAtlas: glTexImage3D OK");
        }
    }

    // Nearest-neighbour filtering — pixel-art crisp look
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    // GL_REPEAT enables seamless tiling across greedy-merged multi-block spans
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_REPEAT);

    glBindTexture(GL_TEXTURE_2D_ARRAY, 0);
    LOGI("Atlas: %d×%d×%d RGBA8 texture array uploaded (%.1f KB)",
         W, H, L, (float)(buf.size()) / 1024.f);
}

// v22: replace a single layer of the atlas with pixel data decoded from a PNG.
// glTexSubImage3D updates only the requested layer — all other tiles are untouched.
// Must be called on the GL thread (GameRenderer.onSurfaceCreated, after nativeInit).
void Renderer::setAtlasTile(int tileIdx, const uint8_t* rgba16x16) {
    if (tileIdx < 0 || tileIdx >= ATLAS_TILE_COUNT) {
        LOGE("setAtlasTile: index %d out of range [0,%d)", tileIdx, ATLAS_TILE_COUNT);
        return;
    }
    if (!m_atlasTexture) {
        LOGE("setAtlasTile: atlas not yet created — was initAtlas() called?");
        return;
    }
    if (!rgba16x16) {
        LOGE("setAtlasTile: null pixel data for tile %d", tileIdx);
        return;
    }
    // FIX v22: explicitly activate unit 0 before binding, for the same reason
    // as initAtlas — prevents binding to a wrong unit if the GL thread left a
    // different unit active after some other subsystem (HUD, debug overlay, etc.).
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D_ARRAY, m_atlasTexture);

    // Clear any pre-existing GL error so our error check below is reliable.
    glGetError();

    glTexSubImage3D(
        GL_TEXTURE_2D_ARRAY,
        0,                          // mip level
        0, 0,                       // x, y offset within layer
        tileIdx,                    // z offset = layer index
        ATLAS_TILE_W, ATLAS_TILE_H, // width, height
        1,                          // depth (one layer)
        GL_RGBA,                    // FIX: must match atlas internal format (GL_RGBA8)
        GL_UNSIGNED_BYTE,           // FIX: must match how Java encoded the bytes
        rgba16x16);

    // FIX v22: check for upload errors.
    // Common causes: texture not yet allocated (initAtlas failed), wrong format,
    // out-of-range tileIdx (already guarded above), or driver OOM.
    GLenum err = glGetError();
    if (err != GL_NO_ERROR) {
        LOGE("setAtlasTile: glTexSubImage3D error 0x%04X for tile %d", err, tileIdx);
    } else {
        LOGI("setAtlasTile: tile %d uploaded OK (RGBA8, 16x16)", tileIdx);
    }

    glBindTexture(GL_TEXTURE_2D_ARRAY, 0);
}

void Renderer::initHUD() {
    m_hudProg = linkProgram(compileShader(GL_VERTEX_SHADER, HUD_VERT),
                              compileShader(GL_FRAGMENT_SHADER, HUD_FRAG));
    float s=0.02f, t=0.002f;
    float verts[] = {
        -s,-t, s,-t, s,t,  -s,-t, s,t, -s,t,
        -t,-s, t,-s, t,s,  -t,-s, t,s, -t,s,
    };
    glGenVertexArrays(1, &m_hudVao);
    glGenBuffers(1, &m_hudVbo);
    glBindVertexArray(m_hudVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_hudVbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, nullptr);
    glBindVertexArray(0);
}

void Renderer::initDebugOverlay() {
    m_dbgProg = linkProgram(compileShader(GL_VERTEX_SHADER,   DBG_VERT),
                              compileShader(GL_FRAGMENT_SHADER, DBG_FRAG));
    glGenVertexArrays(1, &m_dbgVao);
    glGenBuffers(1, &m_dbgVbo);
    glBindVertexArray(m_dbgVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_dbgVbo);
    // Buffer size for dynamic data — updated each frame.
    // 3 bars × 6 verts + 1 pip × 6 verts = 24 verts × 5 floats × 4 bytes = 480 bytes.
    // Round up to 2 KB for headroom.
    glBufferData(GL_ARRAY_BUFFER, 2048, nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 5*4, (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5*4, (void*)(2*4));
    glBindVertexArray(0);
}

// ── Resize ─────────────────────────────────────────────────────────────────────
void Renderer::resize(int w, int h) {
    glViewport(0, 0, w, h);
    camera.aspect = (float)w / (float)h;
    LOGI("Resize %d×%d", w, h);
}

// ── Main render loop ───────────────────────────────────────────────────────────
void Renderer::render(float dt) {
    if (!initialized) return;

    // ── FPS EMA ───────────────────────────────────────────────────────────────
    // Smooth display: ~8-sample EMA damps single-frame spikes.
    // currentFps is read by jni_bridge::nativeGetDebugStats().
    if (dt > 0.f) {
        float fps = 1.f / dt;
        // Clamp outliers (first frame, suspend/resume) before EMA
        if (fps > 200.f) fps = 200.f;
        m_fpsEma  += 0.125f * (fps - m_fpsEma);
        currentFps = m_fpsEma;
    }

    camera.update(dt, reinterpret_cast<World*>(&world));

    float yaw = camera.yaw;
    world.update(camera.position.x, camera.position.z, camera.position.y,
                 0.f, 0.f, sinf(yaw), cosf(yaw), dt);

    world.updateGPU();

    // Task 1: always update debug stats regardless of overlay visibility.
    // Cost is one mutex lock per frame (~1 µs) which is negligible.
    // This ensures counters are populated the moment DBG is opened.
    {
        WorldDebugStats s = world.getDebugStats(currentFps);
        m_debugOverlay.updateDebugStats(s);
    }

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    Mat4    vp      = camera.getVP();
    // Fix #12: separate relative VP for chunk geometry (eye-at-origin).
    // The frustum uses the regular VP (world-space planes) for correct culling.
    // The shader receives relativeVP so it multiplies camera-relative coords,
    // eliminating float precision loss at large world coordinates.
    Mat4    relativeVP = camera.getRelativeVP();
    Frustum frustum = camera.getFrustum();

    // ── Cluster draw pass ─────────────────────────────────────────────────────
    glUseProgram(m_prog);
    glUniformMatrix4fv(m_uMVP, 1, GL_FALSE, relativeVP.m);
    glUniform3fv(m_uCamPos, 1, &camera.position.x);

    // Update fog distance from current effective radius.
    {
        float fogEnd = (float)world.getEffectiveRadius() * 16.f * 0.80f;
        glUniform1f(m_uFogEnd, fogEnd);
    }

    // FIX v22: bind texture atlas to unit 0 before issuing cluster draws.
    // glActiveTexture must be called every frame -- other render passes (HUD,
    // debug overlay) may bind different textures and change the active unit.
    glActiveTexture(GL_TEXTURE0);
    if (!m_atlasTexture) {
        LOGE("render: atlas texture ID is 0 -- initAtlas() must have failed!");
    }
    glBindTexture(GL_TEXTURE_2D_ARRAY, m_atlasTexture);

    // Bind mega-buffer and set up VAO attribute layout
    world.megaBuffer().bind();
    glBindVertexArray(m_clusterVao);
    // Note: glVertexAttribIPointer base addresses are overwritten per cluster
    // inside DrawBatcher::issueDraws — the VAO just carries the divisors.

    // FIX v23: re-assert divisors — some GLES3 drivers reset them in glVertexAttribIPointer.
    glVertexAttribDivisor(0, 1);
    glVertexAttribDivisor(1, 1);

    // Gather visible clusters, sort by mega-offset, issue all draws
    world.gatherAndDraw(frustum, m_uOrigin);

    // FIX v22: check for GL errors after the cluster draw pass.
    // Silent errors here indicate: bad uniform location, unbound VBO,
    // invalid VAO state, or driver-specific instanced-draw rejection.
    {
        GLenum err = glGetError();
        if (err != GL_NO_ERROR) {
            LOGE("render: GL error 0x%04X after cluster draw pass "
                 "(prog=%u atlas=%u vao=%u)",
                 err, m_prog, m_atlasTexture, m_clusterVao);
        }
    }

    // Log first 10 frames with draw counts so we can confirm geometry is issuing
    static int s_logFrames = 0;
    if (s_logFrames < 10) {
        ++s_logFrames;
        LOGI("render frame %d: prog=%u atlas=%u draws=%u faces=%u fogEnd=%.1f",
             s_logFrames, m_prog, m_atlasTexture,
             world.getVisibleCount(), 0u,
             (float)world.getEffectiveRadius() * 16.f * 0.8f);
    }

    glBindVertexArray(0);

    // ── HUD ───────────────────────────────────────────────────────────────────
    renderHUD();
    renderDebugOverlay();
}

// ── HUD (crosshair) ───────────────────────────────────────────────────────────
void Renderer::renderHUD() {
    glDisable(GL_DEPTH_TEST);
    glUseProgram(m_hudProg);
    glBindVertexArray(m_hudVao);
    glDrawArrays(GL_TRIANGLES, 0, 12);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

// ── Debug overlay — thermal bar + render-distance bar + FPS health bar ────────
//
// Three horizontal bars rendered at the bottom-left of the screen, always
// visible (not gated by debugVisible).  They give instant visual feedback
// without requiring the full text overlay to be open.
//
//   Bar 1 (bottom): Thermal pressure   green→yellow→red  [0..100%]
//   Bar 2 (middle): Effective radius / MAX_DIST           [0..100%]
//   Bar 3 (top):    FPS health         green = fast, red = slow
//
// When the debug text overlay is active (debugVisible) a small white accent
// stripe is drawn at the far-right of the FPS bar to confirm the panel is open.
void Renderer::renderDebugOverlay() {
    float pressure = world.thermal().thermalPressure();
    float rdFrac   = (float)world.getEffectiveRadius()
                   / (float)RenderDistanceSystem::MAX_DIST;

    // FPS health: 0 = 0 fps, 1 = 60+ fps (clamp)
    float fpsFrac  = std::min(1.f, currentFps / 60.f);

    // Bar widths in NDC (from x = -0.98)
    float tw = -0.98f + pressure  * 1.20f;
    float rw = -0.98f + rdFrac    * 1.20f;
    float fw = -0.98f + fpsFrac   * 1.20f;

    // Thermal colour: green (cool) → yellow (warm) → red (hot)
    float tr = std::min(1.f, pressure * 2.f);
    float tg = std::min(1.f, (1.f - pressure) * 2.f);

    // FPS colour: green (fast) → red (slow)
    float fr = std::min(1.f, (1.f - fpsFrac) * 2.f);
    float fg = std::min(1.f, fpsFrac * 2.f);

    // 3 quads × 6 verts × 5 floats (x,y,r,g,b) = 90 floats
    float verts[90] = {
        // Bar 1 — Thermal pressure  (y: -0.98 to -0.93)
        -0.98f,-0.98f, tr,tg,0.f,
        tw,    -0.98f, tr,tg,0.f,
        tw,    -0.93f, tr,tg,0.f,
        -0.98f,-0.98f, tr,tg,0.f,
        tw,    -0.93f, tr,tg,0.f,
        -0.98f,-0.93f, tr,tg,0.f,
        // Bar 2 — Render distance   (y: -0.93 to -0.91)
        -0.98f,-0.93f, 1.f,1.f,1.f,
        rw,    -0.93f, 1.f,1.f,1.f,
        rw,    -0.91f, 1.f,1.f,1.f,
        -0.98f,-0.93f, 1.f,1.f,1.f,
        rw,    -0.91f, 1.f,1.f,1.f,
        -0.98f,-0.91f, 1.f,1.f,1.f,
        // Bar 3 — FPS health        (y: -0.91 to -0.89)
        -0.98f,-0.91f, fr,fg,0.f,
        fw,    -0.91f, fr,fg,0.f,
        fw,    -0.89f, fr,fg,0.f,
        -0.98f,-0.91f, fr,fg,0.f,
        fw,    -0.89f, fr,fg,0.f,
        -0.98f,-0.89f, fr,fg,0.f,
    };

    glDisable(GL_DEPTH_TEST);
    glUseProgram(m_dbgProg);
    glBindVertexArray(m_dbgVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_dbgVbo);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(verts), verts);
    glDrawArrays(GL_TRIANGLES, 0, 18);

    // Debug-panel-open indicator: bright white pip at right edge of FPS bar
    if (m_debugOverlay.isVisible()) {
        float px = 0.20f;   // NDC x = right side of screen
        float py = -0.91f;
        float pipW = 0.015f, pipH = 0.02f;
        float pip[30] = {
            px,     py,      1.f,1.f,1.f,
            px+pipW,py,      1.f,1.f,1.f,
            px+pipW,py+pipH, 1.f,1.f,1.f,
            px,     py,      1.f,1.f,1.f,
            px+pipW,py+pipH, 1.f,1.f,1.f,
            px,     py+pipH, 1.f,1.f,1.f,
        };
        glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(pip), pip);
        glDrawArrays(GL_TRIANGLES, 0, 6);
    }

    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

// ── Destructor ─────────────────────────────────────────────────────────────────
Renderer::~Renderer() {
    if (m_prog)          glDeleteProgram(m_prog);
    if (m_hudProg)       glDeleteProgram(m_hudProg);
    if (m_dbgProg)       glDeleteProgram(m_dbgProg);
    if (m_hudVao)        glDeleteVertexArrays(1, &m_hudVao);
    if (m_hudVbo)        glDeleteBuffers(1, &m_hudVbo);
    if (m_dbgVao)        glDeleteVertexArrays(1, &m_dbgVao);
    if (m_dbgVbo)        glDeleteBuffers(1, &m_dbgVbo);
    if (m_clusterVao)    glDeleteVertexArrays(1, &m_clusterVao);
    if (m_atlasTexture)  glDeleteTextures(1, &m_atlasTexture);   // v21
}
