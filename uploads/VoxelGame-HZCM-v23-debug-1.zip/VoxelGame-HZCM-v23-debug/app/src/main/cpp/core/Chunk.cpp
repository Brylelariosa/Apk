// ============================================================================
// HZCM v4 — Chunk.cpp
// ============================================================================
#include "Chunk.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <algorithm>

#define TAG "HZCMChunk"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// ── Constructor ────────────────────────────────────────────────────────────────
Chunk::Chunk(int cx, int cz) : cx(cx), cz(cz) {
    memset(blocks, BLOCK_AIR, sizeof(blocks));
    for (int i = 0; i < CLUSTER_STACK; ++i) {
        clusterState[i].store(ClusterState::EMPTY, std::memory_order_relaxed);
        clusterGPUOffset[i] = MEGA_INVALID;
        clusterFaceCount[i] = 0;
        clusterDirtyGen[i]  = 0;
    }
}

// ── Terrain generation ─────────────────────────────────────────────────────────
//
// v21 improvements over v20:
//
//   Biome quality:
//   • Temperature and humidity now use 2-octave fbm at lower frequency
//     (0.0022 / 0.0028) instead of single noise2D calls.  This produces much
//     larger, smoother biome regions — transitions span dozens of blocks
//     rather than individual columns.
//   • Biome dithering band widened: ±0.04 → ±0.06.  Combined with the lower-
//     frequency fbm, blending zones are 5–8 columns wide vs the old 3–4.
//   • Distinct tundra/taiga band: tN ∈ [0.25, 0.40] → snowy dirt surface
//     instead of hard snow, creating a colder-grass intermediate zone.
//   • Shoreline smoothing: height within 4 blocks of SEA_LEVEL is pulled
//     gently toward sea level via a quartic blend, eliminating sharp cliffs.
//   • Valley floor materialisation: very flat high-erosion valleys now get
//     clay or gravel instead of stone, matching geological reality.
//   • Badlands logic tightened: red sand only in warm+dry+high-erosion zones;
//     rest get orange-tinted dirt layers for a more natural mesa look.
//
//   Performance (vs v20):
//   • No change to octave counts — v20 already reduced these.
//   • fbm for temp/humid adds 2 calls per column but removes 1 noise2D each
//     → net +2 noise2D calls per column (~4% overhead) in exchange for the
//     major biome quality gain.  Well worth the trade-off.
//   • All layer values (cont, erosion, ridge, detail, temp, humid) are
//     computed ONCE at the top of the column loop and reused throughout.
//
void Chunk::generate(const Noise& noise) {

    // ── Tuning constants ──────────────────────────────────────────────────────
    static constexpr int   SEA_LEVEL    = 26;
    static constexpr float WARP_SCALE   = 80.0f;
    static constexpr float WARP_FREQ    = 0.0012f;
    static constexpr int   TREE_BORDER  = 3;

    for (int lz = 0; lz < CHUNK_D; ++lz) {
        for (int lx = 0; lx < CHUNK_W; ++lx) {
            const float wx = (float)(cx * CHUNK_W + lx);
            const float wz = (float)(cz * CHUNK_D + lz);

            // ── Domain warp ────────────────────────────────────────────────
            float wox = noise.fbm(wx * WARP_FREQ + 3.7f,
                                  wz * WARP_FREQ + 1.3f, 2, 2.0f, 0.5f);
            float woz = noise.fbm(wx * WARP_FREQ + 8.1f,
                                  wz * WARP_FREQ + 5.9f, 2, 2.0f, 0.5f);
            float swx = wx + wox * WARP_SCALE;
            float swz = wz + woz * WARP_SCALE;

            // ── Layer 1: Continentalness ────────────────────────────────────
            float contN = noise.fbm(swx * 0.003f,
                                    swz * 0.003f, 3, 2.0f, 0.5f);
            float contH = 28.0f + contN * 14.0f;   // [14, 42]

            // ── Layer 2: Erosion ────────────────────────────────────────────
            float erosN   = noise.fbm(swx * 0.006f + 200.0f,
                                      swz * 0.006f + 200.0f, 2, 2.0f, 0.55f);
            float erosion = (erosN + 1.0f) * 0.5f;  // [0,1]

            // ── Layer 3: Peaks & Valleys ───────────────────────────────────
            float ridgeN = noise.fbmRidged(swx * 0.010f + 50.0f,
                                           swz * 0.010f + 50.0f, 3, 2.0f, 0.5f);

            float mountMask = std::max(0.0f, contN) * (1.0f - erosion * 0.75f);
            mountMask = mountMask * mountMask;
            float peakH = powf(ridgeN, 2.2f) * mountMask * 42.0f;

            // ── Layer 4: Valley carving ─────────────────────────────────────
            float valleyCarve = std::max(0.0f, erosion - 0.45f) * 18.0f;

            // ── Layer 5: Plateau detection ──────────────────────────────────
            float plateauH = 0.0f;
            if (erosion > 0.60f && contN > 0.05f) {
                float plateauBlend = std::min(1.0f, (erosion - 0.60f) * 2.5f);
                float targetH = SEA_LEVEL + 6.0f + contN * 8.0f;
                plateauH = (targetH - (contH + peakH - valleyCarve)) * plateauBlend * 0.45f;
            }

            // ── Layer 6: Fine surface detail ───────────────────────────────
            float detailN = noise.fbm(wx * 0.055f + 20.0f,
                                      wz * 0.055f + 20.0f, 2, 2.0f, 0.45f);
            float detailH = detailN * 2.0f;

            // ── Combine height layers ──────────────────────────────────────
            float rawH = contH + peakH - valleyCarve + plateauH + detailH;

            // ── Shoreline smoothing: gently blend toward sea level ─────────
            // Within 4 blocks of sea level the height curves toward SEA_LEVEL,
            // softening sharp cliffs at ocean edges and creating gentle beaches.
            float sl = (float)SEA_LEVEL;
            float distSea = rawH - sl;
            if (distSea > -4.0f && distSea < 6.0f) {
                // Quartic blend: stronger effect close to sea level
                float t = std::max(0.0f, 1.0f - std::abs(distSea) * 0.18f);
                t = t * t;
                rawH = rawH + (sl - rawH) * t * 0.30f;
            }

            int h = (int)rawH;
            h = std::max(2, std::min(CHUNK_H - 4, h));

            // ── Climate sampling (fbm for smooth biome gradients) ──────────
            // v21: use 2-octave fbm at lower frequency than noise2D.
            // This creates large, smooth biome regions instead of noisy ones.
            float tempN  = noise.fbm(wx * 0.0022f + 500.0f,
                                     wz * 0.0022f + 500.0f, 2, 2.0f, 0.5f);
            float humidN = noise.fbm(wx * 0.0028f + 900.0f,
                                     wz * 0.0028f + 900.0f, 2, 2.0f, 0.5f);

            // ── Biome dithering (±0.06 band at transitions) ────────────────
            // v21: wider band (±0.04 → ±0.06) + lower-freq fbm combine for
            // 5-8 column wide smooth blending zones instead of hard lines.
            unsigned ditherSd = (unsigned)(cx * 7919u + lx * 131u
                                         + cz * 4001u + lz * 37u);
            ditherSd = ditherSd * 1664525u + 1013904223u;
            float dither = ((float)(ditherSd & 0xFF) / 255.0f) * 0.12f - 0.06f;
            float tN = tempN  + dither;
            float hN = humidN + dither;

            // ── Biome classification ───────────────────────────────────────
            bool isOcean    = (h <  SEA_LEVEL - 3);
            bool isBeach    = (h >= SEA_LEVEL - 3) && (h <= SEA_LEVEL + 2);
            bool isMidMount = (h >= 42);
            bool isHighPeak = (h >= 54);

            bool isVolcanic = (contN > 0.52f && ridgeN > 0.68f
                               && mountMask > 0.30f && tN < 0.10f);
            bool isGlacier  = (isHighPeak && tN > 0.38f);
            bool isBadlands = (tN < -0.32f && hN < -0.20f && h < 48);

            // v21: tundra is cold-but-not-frozen grass (tN in [0.24, 0.40])
            bool isTundra   = (tN > 0.24f && tN <= 0.40f && !isHighPeak
                               && !isMidMount);

            // ── Surface block selection ────────────────────────────────────
            uint8_t surfBlock;
            if (isGlacier) {
                surfBlock = BLOCK_ICE;
            } else if (isVolcanic) {
                surfBlock = BLOCK_BASALT;
            } else if (isHighPeak) {
                surfBlock = (tN > 0.0f) ? BLOCK_SNOW : BLOCK_COBBLE;
            } else if (isMidMount) {
                if      (tN > 0.28f)       surfBlock = BLOCK_SNOW;
                else if (erosion < 0.4f)   surfBlock = BLOCK_COBBLE;
                else                       surfBlock = BLOCK_STONE;
            } else if (isBeach) {
                surfBlock = BLOCK_SAND;
            } else if (isBadlands) {
                // Warm arid: red sand in very dry zones, sand otherwise
                surfBlock = (hN < -0.42f) ? BLOCK_RED_SAND : BLOCK_SAND;
            } else if (tN > 0.40f) {
                // Fully cold: snow biome
                surfBlock = BLOCK_SNOW;
            } else if (isTundra) {
                // v21: tundra — transitions between snow and grass
                surfBlock = BLOCK_GRASS;  // with snowy-dirt sub-surface below
            } else {
                // Temperate / tropical grass
                surfBlock = BLOCK_GRASS;
            }

            // ── Block fill ─────────────────────────────────────────────────
            bool mountainZone = (h >= 42);
            bool sandSurf     = (surfBlock == BLOCK_SAND
                                 || surfBlock == BLOCK_RED_SAND);
            bool hasClay      = (humidN > 0.28f
                                 && h >= SEA_LEVEL - 2
                                 && h <= SEA_LEVEL + 4);

            // v21: valley floors (high erosion, near sea level) get gravel
            // instead of stone for a more natural riverbed appearance.
            bool valleyFloor  = (erosion > 0.72f
                                 && h > SEA_LEVEL - 2
                                 && h < SEA_LEVEL + 8
                                 && peakH < 2.0f);

            // v21: tundra sub-surface uses dirt (not stone) down 3 blocks
            bool isTundraSurf = (isTundra || (tN > 0.30f && !isMidMount
                                              && !isHighPeak));

            for (int ly = 0; ly < CHUNK_H; ++ly) {
                uint8_t bt = BLOCK_AIR;

                if (ly == 0) {
                    bt = BLOCK_STONE;
                } else if (ly <= h - 4) {
                    // Deep subsurface
                    if (isVolcanic)        bt = BLOCK_BASALT;
                    else if (valleyFloor && ly > h - 6)
                                           bt = BLOCK_GRAVEL;
                    else                   bt = BLOCK_STONE;
                } else if (ly <= h - 1) {
                    // Near-surface layers
                    if (sandSurf)          bt = surfBlock;
                    else if (hasClay)      bt = BLOCK_CLAY;
                    else if (mountainZone) bt = BLOCK_STONE;
                    else if (isTundraSurf) bt = BLOCK_DIRT;
                    else                   bt = BLOCK_DIRT;
                } else if (ly == h) {
                    bt = surfBlock;
                } else if (ly <= SEA_LEVEL && h < SEA_LEVEL) {
                    bt = (isGlacier || (h < SEA_LEVEL - 6 && tN > 0.32f))
                            ? BLOCK_ICE : BLOCK_WATER;
                }
                setBlock(lx, ly, lz, bt);
            }

            // ── Trees (grass biome) ─────────────────────────────────────────
            if (surfBlock == BLOCK_GRASS
                && h < CHUNK_H - 10
                && lx >= TREE_BORDER && lx < CHUNK_W - TREE_BORDER
                && lz >= TREE_BORDER && lz < CHUNK_D - TREE_BORDER)
            {
                unsigned seed = (unsigned)(cx * 7919 + lx * 131 + cz * 4001 + lz * 37);
                seed = seed * 1664525u + 1013904223u;

                // Density by humidity/temperature; tundra gets very sparse trees
                unsigned treeThresh;
                if (isTundra)                         treeThresh =  3u;
                else if (humidN > 0.30f && tN < 0.15f) treeThresh = 24u;
                else if (humidN > 0.10f)               treeThresh = 12u;
                else                                   treeThresh =  6u;

                if ((seed & 0xFF) < treeThresh) {
                    int treeH = 4 + (int)((seed >> 8) & 3);

                    for (int ty = h + 1; ty <= h + treeH && ty < CHUNK_H; ++ty)
                        setBlock(lx, ty, lz, BLOCK_WOOD);

                    static const float LEAF_RSQ[5] = {
                        1.5f, 5.0f, 5.5f, 4.5f, 1.5f,
                    };
                    int top = h + treeH;
                    for (int dyIdx = 0; dyIdx < 5; ++dyIdx) {
                        int ly2 = top + (dyIdx - 2);
                        if (ly2 < 0 || ly2 >= CHUNK_H) continue;
                        float maxRsq = LEAF_RSQ[dyIdx];
                        int   maxR   = (int)sqrtf(maxRsq) + 1;
                        for (int dx = -maxR; dx <= maxR; ++dx) {
                            for (int dz2 = -maxR; dz2 <= maxR; ++dz2) {
                                float distSq = (float)(dx*dx + dz2*dz2);
                                if (distSq > maxRsq + 0.5f) continue;
                                if (distSq > maxRsq - 0.5f) {
                                    unsigned ls = seed ^ (unsigned)(dx*37 + dz2*53 + (dyIdx-2)*97);
                                    ls = ls * 1664525u + 1013904223u;
                                    if ((ls & 3) == 0) continue;
                                }
                                int lx2 = lx + dx, lz3 = lz + dz2;
                                if (lx2>=0 && lx2<CHUNK_W && lz3>=0 && lz3<CHUNK_D)
                                    if (getBlock(lx2, ly2, lz3) == BLOCK_AIR)
                                        setBlock(lx2, ly2, lz3, BLOCK_LEAVES);
                            }
                        }
                    }
                }
            }

            // ── Cactus (hot dry biomes) ─────────────────────────────────────
            if ((surfBlock == BLOCK_SAND || surfBlock == BLOCK_RED_SAND)
                && h < CHUNK_H - 5
                && lx >= 1 && lx < CHUNK_W - 1
                && lz >= 1 && lz < CHUNK_D - 1)
            {
                unsigned cs2 = (unsigned)(cx * 3571 + lx * 211 + cz * 6131 + lz * 103);
                cs2 = cs2 * 1664525u + 1013904223u;
                if ((cs2 & 0xFF) < 5u) {
                    int cH = 2 + (int)((cs2 >> 8) & 1);
                    for (int ty = h + 1; ty <= h + cH && ty < CHUNK_H; ++ty)
                        setBlock(lx, ty, lz, BLOCK_CACTUS);
                }
            }

            // ── Gravel pockets (subsurface) ─────────────────────────────────
            {
                unsigned seed2 = (unsigned)(cx * 1231 + lx * 53 + cz * 9973 + lz * 73);
                seed2 = seed2 * 1664525u + 1013904223u;
                if ((seed2 & 0xFF) < 20u) {
                    int gy = 2 + (int)((seed2 >> 8) & 15);
                    if (gy < h - 4) setBlock(lx, gy, lz, BLOCK_GRAVEL);
                }
            }
        }
    }

    generated.store(true, std::memory_order_release);
    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
        clusterState[ci].store(ClusterState::DIRTY, std::memory_order_release);
        clusterDirtyGen[ci]++;
    }
}

// ── Extract 16³ voxels for cluster ci ─────────────────────────────────────────
void Chunk::extractClusterVoxels(int ci, uint8_t out[CL_VOLUME]) const {
    const int baseY = ci * CL_SIZE;
    for (int z = 0; z < CL_SIZE; ++z) {
        for (int y = 0; y < CL_SIZE; ++y) {
            const uint8_t* src = &blocks[0 + CHUNK_W * ((baseY + y) + CHUNK_H * z)];
            uint8_t*       dst = &out[0 + CL_SIZE * (y + CL_SIZE * z)];
            memcpy(dst, src, CL_SIZE);
        }
    }
}

// ── Build cluster mesh ─────────────────────────────────────────────────────────
void Chunk::buildClusterMesh(int ci,
                               const Chunk* nxC, const Chunk* pxC,
                               const Chunk* nzC, const Chunk* pzC)
{
    static thread_local uint8_t selfVox[CL_VOLUME];
    static thread_local uint8_t nxVox[CL_VOLUME], pxVox[CL_VOLUME];
    static thread_local uint8_t nyVox[CL_VOLUME], pyVox[CL_VOLUME];
    static thread_local uint8_t nzVox[CL_VOLUME], pzVox[CL_VOLUME];

    extractClusterVoxels(ci, selfVox);

    NeighbourVoxels nb;
    if (nxC && nxC->generated.load(std::memory_order_acquire))
        { nxC->extractClusterVoxels(ci, nxVox); nb.nx = nxVox; }
    if (pxC && pxC->generated.load(std::memory_order_acquire))
        { pxC->extractClusterVoxels(ci, pxVox); nb.px = pxVox; }
    if (nzC && nzC->generated.load(std::memory_order_acquire))
        { nzC->extractClusterVoxels(ci, nzVox); nb.nz = nzVox; }
    if (pzC && pzC->generated.load(std::memory_order_acquire))
        { pzC->extractClusterVoxels(ci, pzVox); nb.pz = pzVox; }
    if (ci > 0)               { extractClusterVoxels(ci - 1, nyVox); nb.ny = nyVox; }
    if (ci < CLUSTER_STACK-1) { extractClusterVoxels(ci + 1, pyVox); nb.py = pyVox; }

    std::vector<PackedFace> localFaces;
    ClusterMesher::buildCluster(selfVox, nb, localFaces);

    {
        std::lock_guard<std::mutex> lock(clusterMutex[ci]);
        clusterFaces[ci] = std::move(localFaces);
    }
    // Task 3: log face count per cluster — a zero here means the mesher
    // produced no visible faces for this cluster (all-air, or face-hidden).
    {
        size_t faceCount = clusterFaces[ci].size();
        if (faceCount == 0) {
            // Only log zero counts for ground clusters (ci=0,1) which should
            // have terrain — ci=2/3 may legitimately be sky-only near surface.
            if (ci <= 1) {
                __android_log_print(ANDROID_LOG_WARN, "HZCMChunk",
                    "buildClusterMesh ZERO faces chunk(%d,%d) ci=%d "
                    "(all-air? neighbours null?)", cx, cz, ci);
            }
        } else if (cx == 0 && cz == 0) {
            __android_log_print(ANDROID_LOG_INFO, "HZCMChunk",
                "buildClusterMesh chunk(%d,%d) ci=%d faces=%zu", cx, cz, ci, faceCount);
        }
    }
    clusterState[ci].store(ClusterState::MESHED, std::memory_order_release);
}

// ── AABB ───────────────────────────────────────────────────────────────────────
void Chunk::getAABB(float& mnX, float& mnY, float& mnZ,
                     float& mxX, float& mxY, float& mxZ) const {
    mnX = (float)(cx * CHUNK_W); mnY = 0.f;            mnZ = (float)(cz * CHUNK_D);
    mxX = mnX + CHUNK_W;         mxY = (float)CHUNK_H; mxZ = mnZ + CHUNK_D;
}
