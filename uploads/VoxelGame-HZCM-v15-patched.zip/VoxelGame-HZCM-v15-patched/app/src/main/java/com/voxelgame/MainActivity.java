package com.voxelgame;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private GameSurfaceView surfaceView;

    // ── Render-distance HUD button ────────────────────────────────────────────
    private Button  rdButton;
    private Handler rdHandler;
    private Runnable rdPoll;

    // ── Debug overlay ─────────────────────────────────────────────────────────
    // The overlay is a semi-transparent pass-through panel — it intercepts no
    // touch events so the joystick always works beneath it.
    //
    // Touch-passthrough design:
    //   • The ScrollView is set to non-clickable + non-focusable.
    //   • Its onTouchEvent always returns false.
    //   • Touch routing: FrameLayout → GameSurfaceView (MATCH_PARENT below the
    //     overlay), so joystick / right-look always receives all touch events.
    //
    // Only the two top-right buttons (DBG, RD) consume touches; they are
    // small (52 dp, 88 dp) and placed in the dead zone between the joystick
    // base (~200 dp from left) and the right edge.
    private PassThroughScrollView debugPanelScroll;
    private TextView    debugText;
    private Button      dbgButton;
    private Handler     debugHandler;
    private Runnable    debugPoll;
    private boolean     debugAdvanced = false;
    private boolean     debugVisible  = false;

    private static final int DEBUG_POLL_MS = 250;

    // ─────────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN            |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION       |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY      |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN     |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        FrameLayout root = new FrameLayout(this);

        // ── GL surface (bottom of z-stack) ────────────────────────────────────
        surfaceView = new GameSurfaceView(this);
        root.addView(surfaceView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // ── Joystick overlay (pass-through, draws joystick visuals) ───────────
        JoystickOverlay joystick = new JoystickOverlay(this);
        root.addView(joystick, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        surfaceView.setJoystickOverlay(joystick);

        // ── Debug stats panel (pass-through — never blocks joystick) ──────────
        // Added before the buttons so buttons sit above it in z-order.
        debugPanelScroll = makeDebugPanel();
        FrameLayout.LayoutParams panelParams = new FrameLayout.LayoutParams(
                dpToPx(275), FrameLayout.LayoutParams.WRAP_CONTENT);
        panelParams.gravity     = Gravity.TOP | Gravity.START;
        panelParams.topMargin   = dpToPx(12);
        panelParams.leftMargin  = dpToPx(12);
        debugPanelScroll.setVisibility(View.GONE);
        root.addView(debugPanelScroll, panelParams);

        // ── Render-distance button (top-right) ────────────────────────────────
        rdButton = makeRdButton();
        FrameLayout.LayoutParams rdParams = new FrameLayout.LayoutParams(
                dpToPx(88), dpToPx(36));
        rdParams.gravity     = Gravity.TOP | Gravity.END;
        rdParams.topMargin   = dpToPx(12);
        rdParams.rightMargin = dpToPx(12);
        root.addView(rdButton, rdParams);

        // ── DBG button (top-right, immediately left of RD button) ─────────────
        // rightMargin = rdRightMargin(12) + rdWidth(88) + gap(6) = 106 dp
        dbgButton = makeDbgButton();
        FrameLayout.LayoutParams dbgParams = new FrameLayout.LayoutParams(
                dpToPx(52), dpToPx(36));
        dbgParams.gravity     = Gravity.TOP | Gravity.END;
        dbgParams.topMargin   = dpToPx(12);
        dbgParams.rightMargin = dpToPx(106);
        root.addView(dbgButton, dbgParams);

        setContentView(root);

        // ── Pollers ───────────────────────────────────────────────────────────
        rdHandler    = new Handler(Looper.getMainLooper());
        rdPoll       = () -> { refreshRdLabel(); rdHandler.postDelayed(rdPoll, 1000); };
        debugHandler = new Handler(Looper.getMainLooper());
        debugPoll    = () -> {
            if (debugVisible) refreshDebugPanel();
            debugHandler.postDelayed(debugPoll, DEBUG_POLL_MS);
        };
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    @Override protected void onResume() {
        super.onResume();
        surfaceView.onResume();
        rdHandler.postDelayed(rdPoll, 1000);
        debugHandler.postDelayed(debugPoll, DEBUG_POLL_MS);
    }

    @Override protected void onPause() {
        super.onPause();
        surfaceView.onPause();
        rdHandler.removeCallbacks(rdPoll);
        debugHandler.removeCallbacks(debugPoll);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Render-distance button
    // ═════════════════════════════════════════════════════════════════════════
    private Button makeRdButton() {
        Button btn = new Button(this);
        btn.setText("RD: 7");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12f);
        btn.setTypeface(Typeface.MONOSPACE);
        btn.setBackgroundColor(0xCC000000);
        btn.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        btn.setOnClickListener(v -> showRdDialog());
        return btn;
    }

    private void refreshRdLabel() {
        try { rdButton.setText("RD: " + surfaceView.nativeGetRenderDistance()); }
        catch (Exception ignored) {}
    }

    private void showRdDialog() {
        final int MIN = 2, MAX = 200;
        int current;
        try { current = surfaceView.nativeGetRenderDistance(); } catch (Exception e) { current = 7; }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpToPx(24), dpToPx(16), dpToPx(24), dpToPx(8));

        TextView title = new TextView(this);
        title.setText("Render Distance");
        title.setTextSize(16f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView valueLabel = new TextView(this);
        valueLabel.setTextSize(28f);
        valueLabel.setGravity(Gravity.CENTER);
        valueLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        valueLabel.setText(String.valueOf(current));
        root.addView(valueLabel);

        TextView rangeHint = new TextView(this);
        rangeHint.setText("Range: " + MIN + " – " + MAX + " chunks");
        rangeHint.setTextSize(11f);
        rangeHint.setGravity(Gravity.CENTER);
        rangeHint.setTextColor(Color.GRAY);
        root.addView(rangeHint);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(MAX - MIN);
        seekBar.setProgress(current - MIN);
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        seekParams.topMargin = dpToPx(12);
        root.addView(seekBar, seekParams);

        TextView perfHint = new TextView(this);
        perfHint.setTextSize(11f);
        perfHint.setGravity(Gravity.CENTER);
        perfHint.setTextColor(0xFF888888);
        perfHint.setPadding(0, dpToPx(4), 0, 0);
        updatePerfHint(perfHint, current);
        root.addView(perfHint);

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.topMargin = dpToPx(12);
        inputRow.setLayoutParams(rowParams);

        TextView inputLabel = new TextView(this);
        inputLabel.setText("Exact value: ");
        inputLabel.setTextSize(13f);

        EditText editText = new EditText(this);
        editText.setInputType(InputType.TYPE_CLASS_NUMBER);
        editText.setHint("2–200");
        editText.setText(String.valueOf(current));
        editText.setSelectAllOnFocus(true);
        LinearLayout.LayoutParams etParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        editText.setLayoutParams(etParams);
        inputRow.addView(inputLabel);
        inputRow.addView(editText);
        root.addView(inputRow);

        final int[] pending = {current};
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int v = progress + MIN;
                pending[0] = v;
                valueLabel.setText(String.valueOf(v));
                editText.setText(String.valueOf(v));
                updatePerfHint(perfHint, v);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(root);
        builder.setPositiveButton("Apply", (dialog, which) -> {
            String typed = editText.getText().toString().trim();
            int finalVal = pending[0];
            try {
                int parsed = Integer.parseInt(typed);
                finalVal = Math.max(MIN, Math.min(MAX, parsed));
            } catch (NumberFormatException ignored) {}
            surfaceView.nativeSetRenderDistance(finalVal);
            rdButton.setText("RD: " + finalVal);
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void updatePerfHint(TextView tv, int dist) {
        String hint;
        if      (dist <= 4)  hint = "⚡ Very fast — minimum detail";
        else if (dist <= 8)  hint = "✓ Balanced — recommended for most devices";
        else if (dist <= 16) hint = "◎ High quality — needs a fast device";
        else if (dist <= 32) hint = "⚠ Demanding — may cause thermal throttling";
        else                 hint = "🔥 Extreme — stress-test only";
        tv.setText(hint);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // DBG button
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Creates the small "DBG" toggle button.
     *
     * Tap        → toggle debug panel visibility
     * Long press → show action menu (copy / save / advanced)
     */
    private Button makeDbgButton() {
        Button btn = new Button(this);
        btn.setText("DBG");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(11f);
        btn.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        btn.setBackgroundColor(0xBB0D1B2A);
        btn.setPadding(dpToPx(6), dpToPx(4), dpToPx(6), dpToPx(4));

        btn.setOnClickListener(v -> toggleDebugPanel());
        btn.setOnLongClickListener(v -> { showDebugActionMenu(); return true; });
        return btn;
    }

    /** Toggle debug panel — syncs both Java and C++ state. */
    private void toggleDebugPanel() {
        debugVisible = !debugVisible;
        try { surfaceView.nativeToggleDebug(); } catch (Exception ignored) {}

        if (debugVisible) {
            debugPanelScroll.setVisibility(View.VISIBLE);
            dbgButton.setBackgroundColor(0xDD1565C0);   // blue = active
            dbgButton.setText("DBG ●");
            refreshDebugPanel();
        } else {
            debugPanelScroll.setVisibility(View.GONE);
            dbgButton.setBackgroundColor(0xBB0D1B2A);
            dbgButton.setText("DBG");
            debugAdvanced = false;
        }
    }

    /**
     * Long-press action menu: Copy / Save to file / Toggle advanced / Close.
     * Non-blocking — the JNI call happens on the UI thread but the file write
     * is dispatched to a background thread so the GL surface never hitches.
     */
    private void showDebugActionMenu() {
        // Snapshot stats immediately on the UI thread (fast mutex read)
        final String stats;
        try { stats = surfaceView.nativeGetDebugStats(); }
        catch (Exception e) { return; }

        if (!debugVisible) {
            // Auto-open panel so the user can see what they're acting on
            toggleDebugPanel();
        }

        String advLabel = debugAdvanced ? "Basic stats" : "Advanced stats";

        new AlertDialog.Builder(this)
            .setTitle("Debug Stats")
            .setItems(new CharSequence[]{
                    "📋  Copy to clipboard",
                    "💾  Save to file",
                    advLabel,
                    "✕  Close"
            }, (dialog, which) -> {
                switch (which) {
                    case 0: copyStatsToClipboard(stats);  break;
                    case 1: saveStatsToFile(stats);        break;
                    case 2: toggleAdvancedMode();          break;
                    case 3: /* close — do nothing */       break;
                }
            })
            .show();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Debug panel view
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Creates the semi-transparent debug stats panel.
     *
     * TOUCH PASSTHROUGH: PassThroughScrollView overrides onTouchEvent to return
     * false, so every touch falls through to GameSurfaceView below.  The
     * joystick is never blocked regardless of where the panel is positioned.
     */
    private PassThroughScrollView makeDebugPanel() {
        PassThroughScrollView scroll = new PassThroughScrollView(this);
        scroll.setBackgroundColor(0xCC0D1B2A);   // dark navy 80% opaque
        // Do NOT set clickable/focusable — must stay transparent to touches
        scroll.setClickable(false);
        scroll.setFocusable(false);

        debugText = new TextView(this);
        debugText.setTypeface(Typeface.MONOSPACE);
        debugText.setTextColor(0xFFE0E0E0);
        debugText.setTextSize(10.5f);
        debugText.setLineSpacing(2f, 1f);
        debugText.setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(10));
        debugText.setClickable(false);
        debugText.setFocusable(false);
        debugText.setText("Waiting for stats…");

        scroll.addView(debugText);
        return scroll;
    }

    /** Refresh the overlay text with a fresh JNI stats snapshot. */
    private void refreshDebugPanel() {
        if (!debugVisible) return;
        try {
            String stats = surfaceView.nativeGetDebugStats();
            if (stats == null || stats.isEmpty()) return;
            if (!debugAdvanced) stats = extractBasicStats(stats);
            debugText.setText(stats);
        } catch (Exception ignored) {}
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Actions — copy / save / advanced toggle
    // ═════════════════════════════════════════════════════════════════════════

    /** Copy stats string to Android clipboard — called with pre-fetched snapshot. */
    private void copyStatsToClipboard(String stats) {
        try {
            ClipboardManager cm = (ClipboardManager)
                    getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("VoxelGame Debug Stats", stats));
                Toast.makeText(this, "Stats copied to clipboard", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Copy failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Save the stats snapshot to a timestamped .txt file in Downloads.
     * The file write runs on a background thread — the GL surface never hitches.
     */
    private void saveStatsToFile(final String stats) {
        new Thread(() -> {
            try {
                File dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) dir.mkdirs();

                String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                        .format(new Date());
                File out = new File(dir, "voxelgame_debug_" + ts + ".txt");

                try (FileWriter fw = new FileWriter(out)) {
                    fw.write("VoxelGame Debug Stats\n");
                    fw.write("Saved: " + new Date() + "\n");
                    fw.write("=".repeat(40) + "\n\n");
                    fw.write(stats);
                    fw.write("\n");
                }

                final String path = out.getAbsolutePath();
                runOnUiThread(() ->
                    Toast.makeText(this, "Saved to Downloads:\n" + out.getName(),
                            Toast.LENGTH_LONG).show()
                );
            } catch (IOException e) {
                runOnUiThread(() ->
                    Toast.makeText(this, "Save failed: " + e.getMessage(),
                            Toast.LENGTH_SHORT).show()
                );
            }
        }, "DebugStatsSaver").start();
    }

    /** Toggle advanced stats mode — shows all 6 sections vs. just Rendering+Streaming. */
    private void toggleAdvancedMode() {
        debugAdvanced = !debugAdvanced;
        try { surfaceView.nativeToggleAdvancedDebug(); } catch (Exception ignored) {}
        Toast.makeText(this,
                debugAdvanced ? "Advanced stats ON" : "Advanced stats OFF",
                Toast.LENGTH_SHORT).show();
        refreshDebugPanel();
    }

    // ═════════════════════════════════════════════════════════════════════════
    // Helpers
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * Trims the full stats string to just [RENDERING] + [STREAMING] for default view.
     * Sections are separated by "\n\n" in the JNI-formatted string.
     */
    private static String extractBasicStats(String full) {
        int count = 0, pos = 0;
        while (pos < full.length()) {
            int idx = full.indexOf("\n\n", pos);
            if (idx < 0) break;
            if (++count == 2)
                return full.substring(0, idx).trim()
                        + "\n\n[ long-press DBG for full stats & save ]";
            pos = idx + 2;
        }
        return full;
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // PassThroughScrollView — touch-transparent overlay panel
    // ═════════════════════════════════════════════════════════════════════════

    /**
     * A ScrollView subclass that passes all touch events through to the view
     * hierarchy below it.  This ensures the joystick (rendered by GameSurfaceView
     * underneath) remains fully responsive even when the debug panel is visible.
     *
     * onTouchEvent() returning false means the event is not consumed here and
     * continues down the view hierarchy to GameSurfaceView.onTouchEvent().
     * onInterceptTouchEvent() returning false ensures we never steal a touch
     * sequence from child views (there are none that need it here).
     */
    static class PassThroughScrollView extends ScrollView {
        PassThroughScrollView(Context ctx) {
            super(ctx);
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            // Do NOT consume — fall through to GameSurfaceView
            return false;
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent ev) {
            // Do NOT intercept — never steal touch sequences
            return false;
        }
    }
}
