# Hazard Yard

Top-down arena shooter for Android (pure framework code, no dependencies). Play solo against bots, or
2-4 players on the same Wi-Fi.

## What is new in 1.4
- **Battleground**: a new game mode on a huge island map (120 x 80 tiles, about four times the area of the biggest
  classic arena): ruins and a watch tower, a walled hill, a factory with a tank farm, a village, an old town with a
  plaza, a depot of container lanes, a harbour with piers, a lake with an island, and farmland, joined by canals with
  bridges and open ends. Eight fighters per match; bots fill every slot the real players leave empty (1 human = 7
  bots, 2 humans = 6 bots, 4 humans = 4 bots) and never take a human's place. Pick the mode in the solo setup or in the
  host's lobby.
- **Guns sound and reload like themselves**: every gun has its own shot and its own three reload sounds (it starts, the
  ammunition goes in, it is ready), and pump, bolt and hammer guns have an action sound after each shot. Reload times
  differ per gun (pistol 1.0 s ... magnum 2.5 s ... light MG 3.3 s); the ammunition comes back at the moment the new
  magazine seats, and the shotgun loads shell by shell (3.5 s from empty). A fresh trigger pull cuts a reload short when
  a round is in the gun; dodging, picking up a weapon or dying cancels it; an empty gun reloads again after a roll.
  The soldier's arms work the gun differently for each reload.
- **Dodge sound**: one short cloth-and-footwork whoosh per roll, never doubled when the button is mashed.
- **Manual weapon pickup**: walking over a weapon does nothing. A round Pick Up button appears (with the gun's name and
  what it replaces) while a weapon is within reach; the pad glows and an arrow bounces over it. Pressing it swaps your
  gun for that one.
- **Smooth bots**: steering, aiming and targeting were rewritten (see `bot/BotBrain`); they no longer shake.
- **Customize HUD** now only moves and resizes things (sticks, buttons, minimap, timer and scores, ammo, health bar,
  kill feed) and can reset the layout; **Controls** is a separate page (Pause menu or Settings) for how input works.
- Graphics quality "Auto" no longer drops soldiers to flat circles after a short slow patch, and recovers by itself.

## Features
- **Solo mode**: Classic (1-3 computer opponents, Easy / Normal / Hard, on any of the eight arenas) or Battleground.
- **Arenas**: Hazard Yard (smallest), Dockside Warehouse, Toxic Foundry, Ruined Outpost, Bunker Complex, and the
  newer Rotunda Plaza (wide open), Silo Yard and Diamond Hall. Besides square walls and crates they use round
  pillars and tanks and angled corner pieces. The host picks the arena in the lobby. Fences are thin lines
  you can stand right next to; fences and toxic pools block movement but not bullets.
- **Eight guns**: pistol, assault rifle, shotgun, SMG, sniper rifle, magnum, plasma rifle, light MG.
  Pushing the aim stick all the way out fires every gun at its own rate, reloads included; bullets leave from the barrel.
  Each gun has its own camera zoom (`WeaponDef.zoom`): the sniper rifle pulls the view back to show its long range, the
  shotgun moves in close, and the view eases from one to the other when you pick up a different gun.
  Every gun has its own sound, synthesised in code (`audio/SoundBank`), no audio files; hits and the plasma
  rifle are electric zaps.
- **Aim line**: while you aim, a dashed line in the gun's colour runs from the muzzle as far as the gun reaches and stops at
  the first wall; guns that scatter their shots also show the edges of their spread. Only your own line is drawn, so it
  tells nothing about the other players. Can be switched off in Settings.
- **Dodge roll**: a button next to the aim stick. A short invulnerable somersault in the move direction
  (or the way you face), about 1.3 s cooldown. Bots roll too.
- **Heard shots only**: other players are not tracked on the minimap or by edge arrows; one shows up only
  where and while its gun was just heard firing.
- **3D look**: lit low-poly soldiers and guns, extruded walls and crates (`render/model`). Can be switched
  off in Settings for slow phones; Graphics quality "Auto" (default) lowers effects by itself when a phone
  cannot hold a steady frame rate (`render/QualityGovernor`). Frames follow the display's vsync and are
  interpolated, so 60, 90 and 120 Hz screens all look smooth.
- **Fullscreen** into the camera cutout; the HUD and controls keep to the safe area.
- **Customize HUD** (Settings > Customize HUD, or Pause > Customize HUD): move and resize every control and HUD element,
  reset the layout. Elements are shown exactly as in a match; overlapping ones are outlined in red. Nothing about how
  the controls behave is on this screen.
- **Controls** (Settings > Controls, or Pause > Controls): fixed or floating sticks, fire mode (stick fires / button fires /
  both), the "Stick fires at" level, aim dead zone, aim line and control opacity. The aim stick aims once it is past its
  dead zone and only fires once it is pushed out to the "Stick fires at" level (default 100% = all the way out,
  adjustable down to 30%); with "Button fires" the stick never fires and the fire button does the shooting. Changes apply
  at once, also during a paused match.

## Layout of the code (`app/src/main/java/com/hazardyard/game`)
| Package    | What lives there |
|------------|------------------|
| `core`     | Match rules and modes (`GameMode`), players, weapons and their reload model (`WeaponDef`, `Weapon`), pickups (`Pickups`), tile maps (`MapLibrary`, `BattlegroundMap`), collision. No Android types. |
| `bot`      | Bot AI: `BotBrain` (intent, then smooth steering), `BotSquad` (all bots of a match; spreads route searches over ticks), time-sliced A* `PathFinder`, `NavGrid`, `BotDifficulty`. |
| `engine`   | `GameEngine` implementations: `HostEngine`, `ClientEngine`, `SoloEngine`; `Presentation` turns events into effects and sounds. |
| `net`      | LAN discovery, lobby and match protocol (bump `Protocol.VERSION` when the wire format changes). |
| `input`    | `InputController` (touch routing), `ControlGeometry` (pixel layout), `VirtualJoystick`. No Android types. |
| `settings` | `ControlSettings` (HUD layout: `resetLayout`; control options: `resetOptions`) / `GameSettings` and their SharedPreferences store. |
| `render`   | Canvas renderers: floor, blocks, units, pickups, shots, HUD, controls. `render/model` is the pure-Java 3D mesh pipeline. |
| `audio`    | `Synth` + `SoundBank` (sound design), `Mixer` (software mixing), `SoundEngine` (AudioTrack output). |
| `ui`       | Screens, the HUD layout editor (`HudEditorView`), the Controls page (`ControlsPanel`) and the Android views. |

## Adding things
- **A map**: add its rows to `MapLibrary` (legend in the comment there), a theme in `render/MapTheme`, and bump `MapLibrary.COUNT`
  (and `CLASSIC_COUNT` if players should be able to choose it). Keep it to 32 weapon pickups at most (the snapshot carries a
  32-bit pickup mask) and positions below 4096 units (they are sent as 1/8-unit 16-bit numbers).
- **A game mode**: add a `GameMode` (limits, respawn times, fixed arena, bot roster); the lobby, the solo setup and the host
  engine pick it up from there.
- **A gun**: add a `WeaponDef` (with its reload style and timings), a model in `render/model/GunModels`, sound recipes in
  `audio/SoundBank` (the shot sound id equals the weapon id, plus three reload sounds and optionally an action sound, see
  `core/Sounds`), a reload pose in `UnitRenderer.reloadPose`, and a map letter in `TileMap.weaponForLetter` if it should
  lie on a map.
