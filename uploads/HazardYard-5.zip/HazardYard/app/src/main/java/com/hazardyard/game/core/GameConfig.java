package com.hazardyard.game.core;

/** Central tuning values. Everything gameplay related that is meant to be tweaked lives here. */
public final class GameConfig {
    private GameConfig() {}

    /** Player slots in a match (humans and bots together). */
    public static final int MAX_PLAYERS = 8;
    /** Real players a hosted game can hold (the host plus the phones that join it). Slots 0..MAX_HUMANS-1 are theirs. */
    public static final int MAX_HUMANS = 4;
    /** World units per map tile. */
    public static final float TILE = 32f;

    // ---- simulation / timing ----
    public static final int SIM_HZ = 60;
    public static final float SIM_DT = 1f / SIM_HZ;
    /** Upper bound of fixed steps per rendered frame, so a slow device slows down instead of spiralling. */
    public static final int MAX_STEPS_PER_FRAME = 5;
    /** The host sends a snapshot every N simulation ticks (3 -> 20 Hz). */
    public static final int SNAPSHOT_EVERY_TICKS = 3;
    public static final float SNAPSHOT_INTERVAL = SNAPSHOT_EVERY_TICKS * SIM_DT;
    /** Client input packet interval while the player is moving / idle. */
    public static final float INPUT_SEND_INTERVAL_MOVING = 1f / 30f;
    public static final float INPUT_SEND_INTERVAL_IDLE = 0.25f;

    // ---- player ----
    public static final float PLAYER_RADIUS = 12f;
    public static final float PLAYER_SPEED = 160f;
    /** Radians per second the body can turn toward the aim direction. */
    public static final float PLAYER_TURN_RATE = 16f;
    public static final int PLAYER_MAX_HEALTH = 100;
    public static final float RESPAWN_DELAY = 3f;
    public static final float SPAWN_PROTECTION = 2.5f;
    /** A semi-automatic trigger pull that arrives during cooldown is remembered for this long (only used by weapons with {@code automatic == false}). */
    public static final float PULL_BUFFER = 0.18f;

    // ---- dodge roll ----
    /** Seconds a roll lasts. */
    public static final float DODGE_DURATION = 0.40f;
    /** Peak speed of a roll in world units per second (walking is {@link #PLAYER_SPEED}). */
    public static final float DODGE_SPEED = 320f;
    /** Seconds from the start of one roll until the next may start. */
    public static final float DODGE_COOLDOWN = 1.30f;
    /** The landing at the end of a roll leaves the player hittable again. */
    public static final float DODGE_VULNERABLE_TAIL = 0.08f;
    /** The host accepts a roll request this early, so network delay never turns a client's roll down. */
    public static final float DODGE_GRACE = 0.15f;

    // ---- match ----
    public static final float COUNTDOWN_SECONDS = 3f;
    public static final int MATCH_SECONDS = 180;
    public static final int KILL_LIMIT = 15;
    public static final float RESULTS_SECONDS = 10f;

    // ---- pickups ----
    public static final float PICKUP_RADIUS = 14f;
    public static final float PICKUP_RESPAWN = 12f;
    /**
     * How close (centre to centre) the player has to stand to a weapon to be offered it. Weapons are
     * never taken by walking over them: the player presses the Pick Up button. The prompt and the host
     * use this same distance, so the button is never shown for a pickup the host would turn down.
     */
    public static final float PICKUP_REACH = 46f;
    /** The host accepts a pickup this much further out, so network delay never turns a valid press down. */
    public static final float PICKUP_REACH_SLACK = 18f;

    // ---- projectiles ----
    public static final int MAX_PROJECTILES = 256;

    // ---- input ----
    /** Left stick: deflection below this is ignored, the rest is rescaled. */
    public static final float MOVE_DEAD_ZONE = 0.10f;
    /** Right stick: deflection at which aiming starts (the weapon only fires further out, see {@link #FIRE_THRESHOLD}). */
    public static final float AIM_DEAD_ZONE = 0.30f;
    /** Right stick: default deflection at which the weapon starts firing (1 = the stick has to be pushed all the way out). */
    public static final float FIRE_THRESHOLD = 1.00f;
    /** Once firing, the stick may fall this far below the fire threshold before the trigger lets go (thumb jitter). */
    public static final float FIRE_RELEASE_BAND = 0.08f;

    // ---- camera: the view always shows at least this much of the world ----
    public static final float VIEW_MIN_HEIGHT = 340f;
    public static final float VIEW_MIN_WIDTH = 600f;
    public static final float CAMERA_FOLLOW_RATE = 12f;
    /** How fast the view eases to the zoom of a newly equipped gun (higher is quicker). */
    public static final float ZOOM_RATE = 6f;
    /** Safety bounds for a gun's {@link WeaponDef#zoom}. */
    public static final float ZOOM_MIN = 0.4f;
    public static final float ZOOM_MAX = 2.0f;
}
