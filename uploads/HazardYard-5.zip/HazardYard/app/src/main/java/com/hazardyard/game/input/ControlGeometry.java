package com.hazardyard.game.input;

import com.hazardyard.game.settings.ControlSettings;

/**
 * Pixel layout of every on-screen control for one screen size: the single source of truth shared by
 * touch routing, the HUD and the layout editor, so what is drawn is exactly what is touchable.
 * Pure math; no Android types.
 */
public final class ControlGeometry {
    private static final float STICK_DP = 58f;
    private static final float FIRE_DP = 40f;
    private static final float RELOAD_DP = 34f;
    private static final float PAUSE_DP = 22f;
    private static final float DODGE_DP = 32f;
    private static final float PICKUP_DP = 36f;

    /** Element centres in screen pixels (touch controls and HUD widgets alike). */
    public final float[] cx = new float[ControlSettings.COUNT];
    public final float[] cy = new float[ControlSettings.COUNT];
    /** Visual radius in pixels of a touch control (half the side for the pause button); for a widget, half its larger side. */
    public final float[] r = new float[ControlSettings.COUNT];
    /** Half width and half height in pixels (equal to {@link #r} for the round controls). */
    public final float[] hw = new float[ControlSettings.COUNT];
    public final float[] hh = new float[ControlSettings.COUNT];
    /** The user's size multiplier of each element, 1 = default. */
    public final float[] sc = new float[ControlSettings.COUNT];

    public int width = 1;
    public int height = 1;
    public float density = 1f;
    /** Display cutout / system bar insets: controls never sit inside them. */
    public float insetL, insetT, insetR, insetB;

    /** Unscaled radius of a touch control in dp (for a widget: half of its larger side). */
    public static float baseRadiusDp(int control) {
        switch (control) {
            case ControlSettings.FIRE: return FIRE_DP;
            case ControlSettings.RELOAD: return RELOAD_DP;
            case ControlSettings.PAUSE: return PAUSE_DP;
            case ControlSettings.DODGE: return DODGE_DP;
            case ControlSettings.PICKUP: return PICKUP_DP;
            case ControlSettings.MOVE:
            case ControlSettings.AIM: return STICK_DP;
            default: return Math.max(baseHalfWidthDp(control), baseHalfHeightDp(control));
        }
    }

    /** Unscaled half width in dp of an element: the radius for the round controls, the box for the widgets. */
    public static float baseHalfWidthDp(int element) {
        switch (element) {
            case ControlSettings.MINIMAP: return 64f;
            case ControlSettings.SCORE: return 100f;
            case ControlSettings.AMMO: return 34f;
            case ControlSettings.HEALTH: return 91f;
            case ControlSettings.FEED: return 88f;
            default: return baseRadiusDp(element);
        }
    }

    /** Unscaled half height in dp of an element. */
    public static float baseHalfHeightDp(int element) {
        switch (element) {
            case ControlSettings.MINIMAP: return 44f;
            case ControlSettings.SCORE: return 28f;
            case ControlSettings.AMMO: return 23f;
            case ControlSettings.HEALTH: return 11f;
            case ControlSettings.FEED: return 39f;
            default: return baseRadiusDp(element);
        }
    }

    public void compute(ControlSettings s, int w, int h, float dens, float l, float t, float rt, float b) {
        width = Math.max(1, w);
        height = Math.max(1, h);
        density = dens;
        insetL = l;
        insetT = t;
        insetR = rt;
        insetB = b;
        float usableW = Math.max(1f, width - l - rt);
        float usableH = Math.max(1f, height - t - b);
        for (int i = 0; i < ControlSettings.COUNT; i++) {
            float k = dens * s.scale[i];
            sc[i] = s.scale[i];
            r[i] = baseRadiusDp(i) * k;
            hw[i] = baseHalfWidthDp(i) * k;
            hh[i] = baseHalfHeightDp(i) * k;
            // The whole element stays on the usable screen, whatever its position and size.
            cx[i] = clampAxis(l + s.x[i] * usableW, l + hw[i], width - rt - hw[i]);
            cy[i] = clampAxis(t + s.y[i] * usableH, t + hh[i], height - b - hh[i]);
        }
    }

    /** Touch radius of a control: a little larger than it looks; sticks get a generous grab area. */
    public float hitRadius(int control) {
        switch (control) {
            case ControlSettings.PAUSE: return r[control] * 1.27f;
            case ControlSettings.RELOAD: return r[control] * 1.14f;
            case ControlSettings.DODGE: return r[control] * 1.2f;
            case ControlSettings.FIRE: return r[control] * 1.12f;
            case ControlSettings.PICKUP: return r[control] * 1.3f;
            default: return r[control] * 1.5f;
        }
    }

    public boolean inside(int control, float px, float py) {
        if (!ControlSettings.isControl(control)) return insideBox(control, px, py);
        float dx = px - cx[control];
        float dy = py - cy[control];
        float hr = hitRadius(control);
        return dx * dx + dy * dy <= hr * hr;
    }

    /** True when the point is inside the element's box (used for the HUD widgets, and by the layout editor). */
    public boolean insideBox(int element, float px, float py) {
        return Math.abs(px - cx[element]) <= hw[element] && Math.abs(py - cy[element]) <= hh[element];
    }

    /**
     * True when two elements overlap on screen (the layout editor warns about it): round controls count as
     * circles, widgets as boxes.
     */
    public boolean overlaps(int a, int b) {
        boolean ra = ControlSettings.isControl(a);
        boolean rb = ControlSettings.isControl(b);
        if (ra && rb) {
            float dx = cx[a] - cx[b];
            float dy = cy[a] - cy[b];
            float rr = r[a] + r[b];
            return dx * dx + dy * dy < rr * rr;
        }
        if (ra != rb) {
            int c = ra ? a : b;
            int w = ra ? b : a;
            float nx = Math.max(cx[w] - hw[w], Math.min(cx[w] + hw[w], cx[c]));
            float ny = Math.max(cy[w] - hh[w], Math.min(cy[w] + hh[w], cy[c]));
            float dx = cx[c] - nx;
            float dy = cy[c] - ny;
            return dx * dx + dy * dy < r[c] * r[c];
        }
        return Math.abs(cx[a] - cx[b]) < hw[a] + hw[b] && Math.abs(cy[a] - cy[b]) < hh[a] + hh[b];
    }

    /** Normalised x (0..1 of the usable width) for an element centred at pixel {@code px}, kept entirely on screen. */
    public float normalizeX(int element, float px) {
        float usable = Math.max(1f, width - insetL - insetR);
        float c = clampAxis(px, insetL + hw[element], width - insetR - hw[element]);
        return (c - insetL) / usable;
    }

    public float normalizeY(int element, float py) {
        float usable = Math.max(1f, height - insetT - insetB);
        float c = clampAxis(py, insetT + hh[element], height - insetB - hh[element]);
        return (c - insetT) / usable;
    }

    private static float clampAxis(float v, float lo, float hi) {
        if (lo > hi) return (lo + hi) * 0.5f;
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
