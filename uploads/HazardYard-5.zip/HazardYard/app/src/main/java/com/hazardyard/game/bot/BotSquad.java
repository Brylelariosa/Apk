package com.hazardyard.game.bot;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.GameWorld;

/**
 * All the bots of one match. They share one {@link NavGrid} and one {@link PathFinder}, which saves a
 * lot of memory on the huge Battleground map. A route search is the most expensive thing a bot does, so
 * the squad runs them one at a time and spreads each over several simulation ticks: every tick the active
 * search gets a small work budget, and when it finishes the route is handed straight to the bot that asked.
 * Bots whose turn has not come keep following their old route meanwhile.
 */
public final class BotSquad {
    private static final String[] NAMES = {"Rex", "Nova", "Viper", "Blitz", "Ghost", "Rogue", "Titan", "Echo"};

    private final GameState st;
    private final GameWorld world;
    private final BotDifficulty diff;
    private final NavGrid nav;
    private final PathFinder paths;
    private final BotBrain[] brains = new BotBrain[GameConfig.MAX_PLAYERS];
    /** Tile expansions of route searching per simulation tick (about half a millisecond on a phone). */
    private static final int EXPANSIONS_PER_TICK = 450;

    /** Slot of the bot whose route search is running, or -1. */
    private int searchOwner = -1;
    private int turn;

    public BotSquad(GameState st, GameWorld world, int difficulty) {
        this.st = st;
        this.world = world;
        this.diff = BotDifficulty.of(difficulty);
        this.nav = new NavGrid(st.map);
        this.paths = new PathFinder(nav);
    }

    /** The name a bot in this slot goes by; the same on the host and on every client. */
    public static String nameFor(int slot) {
        return NAMES[Math.floorMod(slot, NAMES.length)];
    }

    /** Puts a brain in charge of {@code slot} (the slot must already be added to the world as a bot). */
    public void add(int slot, int seed) {
        if (slot < 0 || slot >= brains.length) return;
        brains[slot] = new BotBrain(slot, st, world, this, diff, seed);
    }

    public void remove(int slot) {
        if (slot >= 0 && slot < brains.length) {
            cancelSearch(slot);
            brains[slot] = null;
        }
    }

    public int count() {
        int n = 0;
        for (BotBrain b : brains) if (b != null) n++;
        return n;
    }

    /** Runs every bot's decision step; call once per simulation tick before {@link GameWorld#step}. */
    public void think(float dt) {
        if (searchOwner >= 0) {
            int r = paths.advance(EXPANSIONS_PER_TICK);
            if (r != 0) finishSearch(r > 0);
        }
        int n = brains.length;
        for (int k = 0; k < n; k++) {
            BotBrain b = brains[(turn + k) % n];
            if (b != null) b.think(dt);
        }
        turn = (turn + 1) % n;
    }

    NavGrid nav() {
        return nav;
    }

    PathFinder paths() {
        return paths;
    }

    /**
     * Starts a route search for {@code slot} if no other bot's search is running. The result arrives through
     * {@link BotBrain#acceptRoute} (possibly before this method returns, for trivial routes).
     *
     * @return false when another bot is searching; ask again on a later tick
     */
    boolean beginSearch(int slot, float sx, float sy, float gx, float gy, float radius) {
        if (searchOwner >= 0 && searchOwner != slot) return false;
        searchOwner = slot;
        paths.begin(sx, sy, gx, gy, radius);
        int r = paths.advance(0);           // trivial and impossible searches finish right away
        if (r != 0) finishSearch(r > 0);
        return true;
    }

    void cancelSearch(int slot) {
        if (searchOwner == slot) searchOwner = -1;
    }

    private void finishSearch(boolean ok) {
        int owner = searchOwner;
        searchOwner = -1;
        BotBrain b = owner >= 0 ? brains[owner] : null;
        if (b != null) b.acceptRoute(paths, ok);
    }
}
