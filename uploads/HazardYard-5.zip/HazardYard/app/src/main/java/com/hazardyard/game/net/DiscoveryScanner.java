package com.hazardyard.game.net;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Client side of LAN discovery: once a second it broadcasts a probe on every active interface and
 * collects the unicast replies of hosts. Entries that stop answering expire after a few seconds.
 */
public final class DiscoveryScanner implements Runnable {
    public static final class HostInfo {
        public final String name;
        public final String address;
        public final int port;
        public final int players;
        public final int maxPlayers;
        public final boolean inMatch;
        public final boolean versionOk;
        /** {@link com.hazardyard.game.core.GameMode} the host has selected. */
        public final int modeId;
        long lastSeen;

        HostInfo(String name, String address, int port, int players, int maxPlayers, boolean inMatch,
                 boolean versionOk, int modeId) {
            this.name = name;
            this.address = address;
            this.port = port;
            this.players = players;
            this.maxPlayers = maxPlayers;
            this.inMatch = inMatch;
            this.versionOk = versionOk;
            this.modeId = modeId;
        }
    }

    public interface Listener {
        /** Called on the scanner thread whenever the list of visible hosts changed. */
        void onHostsChanged();
    }

    private static final long PROBE_INTERVAL_MS = 1000;
    private static final long EXPIRE_MS = 4000;

    private final int discoveryPort;
    private final List<InetAddress> extraTargets = new ArrayList<>();
    private final Map<String, HostInfo> hosts = new LinkedHashMap<>();
    private volatile boolean stopped;
    private DatagramSocket socket;
    private Listener listener;

    public DiscoveryScanner(int discoveryPort) {
        this.discoveryPort = discoveryPort;
    }

    /** Additional unicast probe target (used for tests and for a known host address). */
    public synchronized void addTarget(InetAddress address) {
        extraTargets.add(address);
    }

    public void start(Listener l) {
        listener = l;
        Thread t = new Thread(this, "hy-discovery-scan");
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        stopped = true;
        DatagramSocket s = socket;
        if (s != null) s.close();
    }

    public synchronized List<HostInfo> snapshot() {
        return new ArrayList<>(hosts.values());
    }

    @Override
    public void run() {
        try {
            socket = new DatagramSocket();
            socket.setBroadcast(true);
            socket.setSoTimeout(400);
        } catch (IOException e) {
            return;
        }
        byte[] probe = new PacketWriter(16).beginRaw().i32(Protocol.DISCOVERY_MAGIC).u8(Protocol.D_PROBE)
                .u8(Protocol.VERSION).finishRaw();
        byte[] buf = new byte[128];
        DatagramPacket in = new DatagramPacket(buf, buf.length);
        PacketReader r = new PacketReader();
        long nextProbe = 0;
        while (!stopped) {
            long now = System.currentTimeMillis();
            if (now >= nextProbe) {
                sendProbes(probe);
                nextProbe = now + PROBE_INTERVAL_MS;
            }
            boolean changed = false;
            try {
                in.setLength(buf.length);
                socket.receive(in);
                changed = handleReply(in, buf, r);
            } catch (SocketTimeoutException ignored) {
                // normal: nothing arrived within the wait
            } catch (IOException e) {
                if (stopped) break;
            } catch (RuntimeException ignored) {
                // malformed datagram
            }
            if (expire(System.currentTimeMillis())) changed = true;
            if (changed && listener != null) listener.onHostsChanged();
        }
    }

    private void sendProbes(byte[] probe) {
        List<InetAddress> targets = new ArrayList<>(NetUtilTargets.broadcast());
        synchronized (this) {
            targets.addAll(extraTargets);
        }
        for (InetAddress a : targets) {
            try {
                socket.send(new DatagramPacket(probe, probe.length, a, discoveryPort));
            } catch (IOException ignored) {
                // this interface may not be able to broadcast; try the others
            }
        }
    }

    private boolean handleReply(DatagramPacket in, byte[] buf, PacketReader r) {
        if (in.getLength() < 10) return false;
        r.wrap(buf, 0, in.getLength());
        if (r.i32() != Protocol.DISCOVERY_MAGIC || r.u8() != Protocol.D_REPLY) return false;
        int version = r.u8();
        int players = r.u8();
        int max = r.u8();
        boolean inMatch = r.u8() != 0;
        int port = r.u16();
        String name = r.str();
        int modeId = r.remaining() > 0 ? r.u8() : 0;
        String address = in.getAddress().getHostAddress();
        String key = address + ":" + port;
        HostInfo info = new HostInfo(Protocol.sanitizeName(name), address, port, players, max, inMatch,
                version == Protocol.VERSION, modeId);
        info.lastSeen = System.currentTimeMillis();
        synchronized (this) {
            HostInfo old = hosts.put(key, info);
            return old == null || old.players != info.players || old.inMatch != info.inMatch
                    || !old.name.equals(info.name) || old.modeId != info.modeId;
        }
    }

    private synchronized boolean expire(long now) {
        boolean removed = false;
        Iterator<HostInfo> it = hosts.values().iterator();
        while (it.hasNext()) {
            if (now - it.next().lastSeen > EXPIRE_MS) {
                it.remove();
                removed = true;
            }
        }
        return removed;
    }

    /** Indirection so the destination list is recomputed each round (interfaces come and go). */
    private static final class NetUtilTargets {
        static List<InetAddress> broadcast() {
            List<InetAddress> l = new ArrayList<>(NetUtil.broadcastAddresses());
            try {
                l.add(InetAddress.getByName("255.255.255.255"));
            } catch (IOException ignored) {
                // literal address, cannot fail
            }
            return l;
        }
    }
}
