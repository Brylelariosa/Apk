package com.hazardyard.game.core;

/**
 * Everything the renderer needs, plus everything the host simulates. The host mutates it through
 * {@link GameWorld}; a client fills it from network snapshots. Only the game thread touches it.
 */
public final class GameState {
    /** How far (0..1) the game clock is towards the next simulation step; the renderer draws bullets between their last two positions with it. */
    public float renderAlpha;

    /** Waiting for the match to begin (never simulated). */
    public static final int PHASE_LOBBY = 0;
    public static final int PHASE_COUNTDOWN = 1;
    public static final int PHASE_PLAYING = 2;
    /** Time or kill limit reached; results are on screen. */
    public static final int PHASE_ENDED = 3;
    /** Results shown long enough; the session should return to the lobby. */
    public static final int PHASE_FINISHED = 4;

    public final TileMap map;
    /** Rules of this match (time and kill limit, respawn delays). Fixed for the life of the state. */
    public final GameMode mode;
    public final CollisionSystem collision;
    public final Player[] players = new Player[GameConfig.MAX_PLAYERS];
    public final ProjectilePool projectiles = new ProjectilePool(GameConfig.MAX_PROJECTILES);
    public final Pickup[] pickups;
    public final Effects effects = new Effects();
    /** Turns events into sound requests; the sink is attached by the screen that owns the audio output. */
    public final AudioDirector audio = new AudioDirector(this);

    public int phase = PHASE_LOBBY;
    public float timeLeft;
    public float countdown;
    public float resultsTimer;
    /** Slot of the match winner, or -1 for a draw / undecided. */
    public int winnerId = -1;
    public final int localId;

    public GameState(TileMap map, int localId) {
        this(map, localId, GameMode.ALL[GameMode.CLASSIC]);
    }

    public GameState(TileMap map, int localId, GameMode mode) {
        this.map = map;
        this.mode = mode;
        this.timeLeft = mode.matchSeconds;
        this.localId = localId;
        this.collision = new CollisionSystem(map);
        for (int i = 0; i < players.length; i++) players[i] = new Player(i);
        pickups = new Pickup[map.pickupX.length];
        for (int i = 0; i < pickups.length; i++) {
            pickups[i] = new Pickup(map.pickupX[i], map.pickupY[i], map.pickupWeapon[i]);
        }
    }

    public Player local() {
        return players[localId];
    }

    public int connectedCount() {
        int n = 0;
        for (int i = 0; i < players.length; i++) if (players[i].connected) n++;
        return n;
    }
}
