package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.WeaponDef;

/**
 * Flat side-on silhouettes of the eight guns, pointing right. Used where a weapon has to be recognised
 * at a glance without a 3D model: the Pick Up button and the weapon pads in the light graphics mode.
 * Allocation-free: the caller passes the paint and path to use.
 */
final class GunGlyph {
    private GunGlyph() {}

    /**
     * @param cx   centre of the glyph
     * @param cy   centre of the glyph
     * @param size half of the glyph's length in pixels (the long guns are drawn a little longer than that)
     */
    static void draw(Canvas c, Paint fill, Path path, float cx, float cy, float size, int weaponId, int color) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        float u = size;
        switch (weaponId) {
            case WeaponDef.PISTOL:
                body(c, fill, cx - 0.55f * u, cy - 0.30f * u, cx + 0.45f * u, cy - 0.02f * u, 0.07f * u);
                grip(c, fill, path, cx - 0.40f * u, cy - 0.02f * u, 0.28f * u, 0.55f * u, 0.12f * u);
                barrel(c, fill, cx + 0.45f * u, cy - 0.24f * u, cx + 0.70f * u, cy - 0.10f * u);
                break;
            case WeaponDef.MAGNUM:
                body(c, fill, cx - 0.55f * u, cy - 0.34f * u, cx + 0.30f * u, cy + 0.02f * u, 0.10f * u);
                grip(c, fill, path, cx - 0.48f * u, cy + 0.0f, 0.34f * u, 0.60f * u, 0.18f * u);
                barrel(c, fill, cx + 0.30f * u, cy - 0.30f * u, cx + 0.92f * u, cy - 0.10f * u);
                break;
            case WeaponDef.SMG:
                body(c, fill, cx - 0.55f * u, cy - 0.30f * u, cx + 0.52f * u, cy + 0.0f, 0.06f * u);
                grip(c, fill, path, cx - 0.30f * u, cy, 0.22f * u, 0.50f * u, 0.12f * u);
                c.drawRect(cx + 0.05f * u, cy, cx + 0.22f * u, cy + 0.62f * u, fill);          // long magazine
                barrel(c, fill, cx + 0.52f * u, cy - 0.24f * u, cx + 0.82f * u, cy - 0.12f * u);
                break;
            case WeaponDef.SHOTGUN:
                body(c, fill, cx - 0.30f * u, cy - 0.26f * u, cx + 0.50f * u, cy - 0.04f * u, 0.05f * u);
                stock(c, fill, path, cx - 0.30f * u, cy - 0.26f * u, cx - 0.98f * u, cy + 0.18f * u, 0.30f * u);
                barrel(c, fill, cx + 0.50f * u, cy - 0.26f * u, cx + 1.10f * u, cy - 0.12f * u);
                c.drawRect(cx + 0.18f * u, cy - 0.04f * u, cx + 0.62f * u, cy + 0.10f * u, fill);   // pump
                break;
            case WeaponDef.SNIPER:
                body(c, fill, cx - 0.30f * u, cy - 0.20f * u, cx + 0.40f * u, cy - 0.02f * u, 0.04f * u);
                stock(c, fill, path, cx - 0.30f * u, cy - 0.20f * u, cx - 1.00f * u, cy + 0.20f * u, 0.26f * u);
                barrel(c, fill, cx + 0.40f * u, cy - 0.17f * u, cx + 1.18f * u, cy - 0.09f * u);
                c.drawRect(cx - 0.05f * u, cy - 0.40f * u, cx + 0.42f * u, cy - 0.22f * u, fill);   // scope
                break;
            case WeaponDef.PLASMA:
                body(c, fill, cx - 0.45f * u, cy - 0.32f * u, cx + 0.45f * u, cy + 0.04f * u, 0.16f * u);
                grip(c, fill, path, cx - 0.30f * u, cy + 0.02f * u, 0.24f * u, 0.50f * u, 0.12f * u);
                barrel(c, fill, cx + 0.45f * u, cy - 0.24f * u, cx + 0.88f * u, cy - 0.06f * u);
                fill.setColor(0xFFFFFFFF);
                c.drawCircle(cx + 0.02f * u, cy - 0.14f * u, 0.07f * u, fill);                      // glowing cell
                fill.setColor(color);
                break;
            case WeaponDef.LMG:
                body(c, fill, cx - 0.40f * u, cy - 0.28f * u, cx + 0.50f * u, cy + 0.0f, 0.05f * u);
                stock(c, fill, path, cx - 0.40f * u, cy - 0.28f * u, cx - 0.98f * u, cy + 0.16f * u, 0.26f * u);
                barrel(c, fill, cx + 0.50f * u, cy - 0.24f * u, cx + 1.08f * u, cy - 0.10f * u);
                c.drawRect(cx - 0.05f * u, cy, cx + 0.32f * u, cy + 0.34f * u, fill);              // ammo box
                break;
            default:    // assault rifle
                body(c, fill, cx - 0.40f * u, cy - 0.28f * u, cx + 0.45f * u, cy - 0.02f * u, 0.05f * u);
                stock(c, fill, path, cx - 0.40f * u, cy - 0.28f * u, cx - 0.95f * u, cy + 0.14f * u, 0.26f * u);
                grip(c, fill, path, cx - 0.22f * u, cy - 0.02f * u, 0.20f * u, 0.46f * u, 0.12f * u);
                path.reset();
                path.moveTo(cx + 0.05f * u, cy - 0.02f * u);                                         // curved magazine
                path.lineTo(cx + 0.24f * u, cy - 0.02f * u);
                path.lineTo(cx + 0.30f * u, cy + 0.50f * u);
                path.lineTo(cx + 0.12f * u, cy + 0.50f * u);
                path.close();
                c.drawPath(path, fill);
                barrel(c, fill, cx + 0.45f * u, cy - 0.24f * u, cx + 1.02f * u, cy - 0.12f * u);
                break;
        }
    }

    private static void body(Canvas c, Paint fill, float l, float t, float r, float b, float radius) {
        c.drawRoundRect(l, t, r, b, radius, radius, fill);
    }

    private static void barrel(Canvas c, Paint fill, float l, float t, float r, float b) {
        c.drawRect(l, t, r, b, fill);
    }

    /** A grip hanging below (x, y), leaning back by {@code lean}. */
    private static void grip(Canvas c, Paint fill, Path path, float x, float y, float w, float h, float lean) {
        path.reset();
        path.moveTo(x, y);
        path.lineTo(x + w, y);
        path.lineTo(x + w - lean, y + h);
        path.lineTo(x - lean, y + h);
        path.close();
        c.drawPath(path, fill);
    }

    /** A stock reaching back from (x0, y0) to the butt at x1, dropping to y1. */
    private static void stock(Canvas c, Paint fill, Path path, float x0, float y0, float x1, float y1, float drop) {
        path.reset();
        path.moveTo(x0, y0);
        path.lineTo(x0, y0 + 0.16f * drop);
        path.lineTo(x1, y1);
        path.lineTo(x1, y1 - drop);
        path.close();
        c.drawPath(path, fill);
    }
}
