package com.hazardyard.game.audio;

/**
 * Tiny sound-design toolkit: oscillators with pitch sweeps, filtered noise, envelopes, echo and soft
 * clipping, all working on mono float buffers. Everything is deterministic (the noise generator is
 * seeded) so a sound always comes out the same. Pure Java, no Android types.
 */
final class Synth {
    private Synth() {}

    static final int RATE = 44100;
    private static final float TWO_PI = (float) (Math.PI * 2.0);

    static float[] buffer(float seconds) {
        return new float[Math.max(1, Math.round(seconds * RATE))];
    }

    // ------------------------------------------------------------------ noise

    /** Seeded white noise in [-1, 1). */
    static final class Noise {
        private int s;

        Noise(int seed) {
            s = seed == 0 ? 0x2545F491 : seed;
        }

        float next() {
            s ^= s << 13;
            s ^= s >>> 17;
            s ^= s << 5;
            return (s >> 8) * (1f / 8388608f);
        }
    }

    // ------------------------------------------------------------------ envelopes

    /** Exponential decay with the given time constant (seconds) after {@code t0}. */
    static float decay(float t, float t0, float tau) {
        return t < t0 ? 0f : (float) Math.exp(-(t - t0) / tau);
    }

    /** Linear fade-in over {@code attack} seconds, then exponential decay. */
    static float attackDecay(float t, float attack, float tau) {
        float a = attack <= 0f ? 1f : Math.min(1f, t / attack);
        return a * (float) Math.exp(-t / tau);
    }

    // ------------------------------------------------------------------ filters (in place)

    static void lowPass(float[] b, float cutoffHz) {
        float a = 1f - (float) Math.exp(-TWO_PI * cutoffHz / RATE);
        float y = 0f;
        for (int i = 0; i < b.length; i++) {
            y += a * (b[i] - y);
            b[i] = y;
        }
    }

    static void highPass(float[] b, float cutoffHz) {
        float a = 1f - (float) Math.exp(-TWO_PI * cutoffHz / RATE);
        float y = 0f;
        for (int i = 0; i < b.length; i++) {
            y += a * (b[i] - y);
            b[i] -= y;
        }
    }

    static void bandPass(float[] b, float lowHz, float highHz) {
        lowPass(b, highHz);
        highPass(b, lowHz);
    }

    // ------------------------------------------------------------------ generators (added into dst)

    /**
     * Adds a noise burst shaped by an exponential decay, filtered to [lowHz, highHz]. Starts at
     * {@code t0} seconds into the buffer.
     */
    static void addNoise(float[] dst, Noise n, float t0, float tau, float amp, float lowHz, float highHz) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(tau * 8f * RATE));
        if (len <= 0) return;
        float[] tmp = new float[len];
        for (int i = 0; i < len; i++) tmp[i] = n.next();
        if (highHz > 0f) lowPass(tmp, highHz);
        if (lowHz > 0f) highPass(tmp, lowHz);
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            dst[start + i] += tmp[i] * amp * (float) Math.exp(-t / tau);
        }
    }

    /**
     * Adds a sine whose frequency glides exponentially from {@code f0} to {@code f1} (rate
     * {@code sweep} per second), with a decaying amplitude.
     */
    static void addSweep(float[] dst, float t0, float tau, float amp, float f0, float f1, float sweep) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(tau * 8f * RATE));
        float phase = 0f;
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            float f = f1 + (f0 - f1) * (float) Math.exp(-t * sweep);
            phase += TWO_PI * f / RATE;
            dst[start + i] += (float) Math.sin(phase) * amp * (float) Math.exp(-t / tau);
        }
    }

    /** Adds a steady tone (sine blended with a saw for a buzzier edge) with an attack/decay envelope. */
    static void addTone(float[] dst, float t0, float attack, float tau, float amp, float freq, float sawMix) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round((attack + tau * 8f) * RATE));
        float phase = 0f;
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            phase += TWO_PI * freq / RATE;
            float cycle = (phase / TWO_PI) % 1f;
            float saw = 2f * cycle - 1f;
            float s = (float) Math.sin(phase) * (1f - sawMix) + saw * sawMix;
            dst[start + i] += s * amp * attackDecay(t, attack, tau);
        }
    }

    // ------------------------------------------------------------------ electric toolkit

    /**
     * Sparse, bright clicks like an electric arc: random impulses of random sign whose density
     * (probability per sample at the start) fades with time constant {@code tau}, high-passed so only
     * the crisp part is left. Starts at {@code t0}, lasts {@code dur} seconds.
     */
    static void addCrackle(float[] dst, Noise n, float t0, float dur, float density, float tau, float amp, float lowHz) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(dur * RATE));
        if (len <= 0) return;
        float[] tmp = new float[len];
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            float p = density * (float) Math.exp(-t / tau);
            float r = n.next() * 0.5f + 0.5f;                 // 0..1
            if (r < p) {
                float v = n.next();
                tmp[i] += v >= 0f ? 0.4f + 0.6f * v : -0.4f + 0.6f * v;
                if (i + 1 < len) tmp[i + 1] -= tmp[i] * 0.6f;   // a two-sample click
            }
        }
        if (lowHz > 0f) highPass(tmp, lowHz);
        for (int i = 0; i < len; i++) dst[start + i] += tmp[i] * amp;
    }

    /**
     * A zap: a sawtooth that dives in pitch from {@code f0} to {@code f1} (rate {@code sweep} per
     * second), ring-modulated at {@code ringHz} (depth 0..1) so it gets the harsh, metallic sidebands
     * of electricity, with an exponential decay.
     */
    static void addZap(float[] dst, float t0, float tau, float amp, float f0, float f1, float sweep, float ringHz, float ringDepth) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(tau * 8f * RATE));
        float phase = 0f;
        float ring = 0f;
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            float f = f1 + (f0 - f1) * (float) Math.exp(-t * sweep);
            phase += f / RATE;
            ring += ringHz / RATE;
            float saw = 2f * (phase - (float) Math.floor(phase)) - 1f;
            float m = 1f - ringDepth + ringDepth * (float) Math.sin(TWO_PI * ring);
            dst[start + i] += saw * m * amp * (float) Math.exp(-t / tau);
        }
    }

    /** An FM tone whose modulation index falls from {@code index0} to 0 with time constant {@code tau}: sparkly at the start, then a plain tone. */
    static void addFm(float[] dst, float t0, float tau, float amp, float carrierHz, float modHz, float index0, float indexSweep) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(tau * 8f * RATE));
        float pc = 0f;
        float pm = 0f;
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            pc += TWO_PI * carrierHz / RATE;
            pm += TWO_PI * modHz / RATE;
            float idx = index0 * (float) Math.exp(-t * indexSweep / 8f);
            dst[start + i] += (float) Math.sin(pc + idx * (float) Math.sin(pm)) * amp * (float) Math.exp(-t / tau);
        }
    }

    /**
     * Mains-style buzz: a sawtooth at {@code freq} chopped by a soft tremolo at {@code amHz}, which
     * sounds like a stuttering electrical hum. Lasts {@code dur} seconds with a tail of time constant {@code tau}.
     */
    static void addBuzz(float[] dst, float t0, float dur, float amp, float freq, float amHz, float tau) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(dur * RATE));
        float phase = 0f;
        for (int i = 0; i < len; i++) {
            float t = i / (float) RATE;
            phase += freq / RATE;
            float saw = 2f * (phase - (float) Math.floor(phase)) - 1f;
            float chop = 0.55f + 0.45f * (float) Math.signum(Math.sin(TWO_PI * amHz * t));
            dst[start + i] += saw * chop * amp * (float) Math.exp(-t / tau) * Math.min(1f, t / 0.004f);
        }
    }

    // ------------------------------------------------------------------ mechanical toolkit (reloads, actions, footwork)

    /**
     * A hard click, like a latch or a catch: a very short band-limited noise burst around {@code centerHz}
     * with a tiny ping at the same pitch. {@code tau} (seconds) is how long it rings.
     */
    static void addClick(float[] dst, Noise n, float t0, float amp, float centerHz, float tau) {
        addNoise(dst, n, t0, tau, amp, centerHz * 0.55f, Math.min(centerHz * 2.2f, 16000f));
        addTone(dst, t0, 0f, tau * 1.4f, amp * 0.28f, centerHz, 0f);
    }

    /** A dull knock: a low sine that drops in pitch and a muffled noise puff (a magazine landing, a heavy lock). */
    static void addThunk(float[] dst, Noise n, float t0, float amp, float freq, float tau) {
        addSweep(dst, t0, tau, amp, freq * 1.6f, freq * 0.75f, 70f);
        addNoise(dst, n, t0, tau * 0.7f, amp * 0.5f, 0f, freq * 6f);
    }

    /** Metal ringing after an impact: three inharmonic partials of a struck bar. */
    static void addRing(float[] dst, float t0, float amp, float freq, float tau) {
        addTone(dst, t0, 0f, tau, amp, freq, 0f);
        addTone(dst, t0, 0f, tau * 0.62f, amp * 0.55f, freq * 2.76f, 0f);
        addTone(dst, t0, 0f, tau * 0.38f, amp * 0.30f, freq * 5.40f, 0f);
    }

    /** A burst of friction noise whose pitch glides from {@code f0} to {@code f1}: a slide or a bolt travelling. */
    static void addScrape(float[] dst, Noise n, float t0, float dur, float amp, float f0, float f1) {
        addWhoosh(dst, n, t0, dur, amp, f0, f1, 3.2f, Math.min(0.012f, dur * 0.2f), true);
    }

    /** A swept band-pass whoosh with a smooth swell; {@code q} is the resonance (higher = narrower, more tonal). */
    static void addWhoosh(float[] dst, Noise n, float t0, float dur, float amp, float f0, float f1, float q, float attack) {
        addWhoosh(dst, n, t0, dur, amp, f0, f1, q, attack, false);
    }

    private static void addWhoosh(float[] dst, Noise n, float t0, float dur, float amp, float f0, float f1, float q,
                                  float attack, boolean flatEnvelope) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(dur * RATE));
        if (len <= 0) return;
        float low = 0f;
        float band = 0f;
        float q1 = 1f / q;
        for (int i = 0; i < len; i++) {
            float u = i / (float) len;
            float fc = f0 + (f1 - f0) * u;
            float f = 2f * (float) Math.sin(Math.PI * Math.min(fc, 9000f) / RATE);
            float x = n.next();
            low += f * band;
            float high = x - low - q1 * band;
            band += f * high;
            float swell = (float) Math.sin(Math.PI * u);
            float env = flatEnvelope ? (float) Math.sqrt(swell) : swell * swell * (1.4f - 0.4f * u);
            float a = attack > 0f ? Math.min(1f, (i / (float) RATE) / attack) : 1f;
            dst[start + i] += band * amp * env * a * (0.55f + 0.2f * q);
        }
    }

    /**
     * A run of small clicks: {@code count} of them, the gap between two growing by {@code growth} each time
     * (above 1 the run slows down like a spinning cylinder; 1 keeps a steady rattle).
     */
    static void addRatchet(float[] dst, Noise n, float t0, int count, float spacing, float growth, float amp, float centerHz) {
        float t = t0;
        float gap = spacing;
        for (int k = 0; k < count; k++) {
            float v = 0.65f + 0.35f * (k % 2 == 0 ? 1f : 0.7f);
            addClick(dst, n, t, amp * v, centerHz * (0.92f + 0.16f * ((k * 37 % 11) / 10f)), 0.004f);
            t += gap;
            gap *= growth;
        }
    }

    /** Pneumatic hiss: high-passed noise with a quick swell and fade. */
    static void addHiss(float[] dst, Noise n, float t0, float dur, float amp, float lowHz) {
        int start = Math.min(dst.length, Math.round(t0 * RATE));
        int len = Math.min(dst.length - start, Math.round(dur * RATE));
        if (len <= 0) return;
        float[] tmp = new float[len];
        for (int i = 0; i < len; i++) tmp[i] = n.next();
        highPass(tmp, lowHz);
        for (int i = 0; i < len; i++) {
            float u = i / (float) len;
            float env = (float) Math.sin(Math.PI * Math.pow(u, 0.6));
            dst[start + i] += tmp[i] * amp * env;
        }
    }

    // ------------------------------------------------------------------ effects (in place)

    /** Feed-forward echo: adds delayed, attenuated copies of the signal. */
    static void echo(float[] b, float delaySeconds, float gain, int taps) {
        int d = Math.round(delaySeconds * RATE);
        for (int tap = taps; tap >= 1; tap--) {
            float g = (float) Math.pow(gain, tap);
            int shift = d * tap;
            for (int i = b.length - 1; i >= shift; i--) b[i] += b[i - shift] * g;
        }
    }

    /** Soft clipping: {@code drive} above 1 adds punch and harmonics. */
    static void saturate(float[] b, float drive) {
        float norm = 1f / (float) Math.tanh(drive);
        for (int i = 0; i < b.length; i++) b[i] = (float) Math.tanh(b[i] * drive) * norm;
    }

    /** Fades the last milliseconds to zero so the sound can never end with a click. */
    static void fadeOut(float[] b, float seconds) {
        int n = Math.min(b.length, Math.round(seconds * RATE));
        for (int i = 0; i < n; i++) b[b.length - 1 - i] *= i / (float) n;
    }

    /** Scales so the loudest sample is exactly {@code peak}. */
    static void normalize(float[] b, float peak) {
        float max = 0f;
        for (float v : b) max = Math.max(max, Math.abs(v));
        if (max < 1e-6f) return;
        float k = peak / max;
        for (int i = 0; i < b.length; i++) b[i] *= k;
    }

    static short[] toPcm(float[] b) {
        short[] out = new short[b.length];
        for (int i = 0; i < b.length; i++) {
            float v = Math.max(-1f, Math.min(1f, b[i]));
            out[i] = (short) Math.round(v * 32767f);
        }
        return out;
    }
}
