package com.hazardyard.game.net;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;

/**
 * Host side of LAN discovery. Clients broadcast a tiny probe; this answers each probe with a unicast
 * reply describing the game. It is passive (no periodic broadcasting), so it costs no battery
 * while nobody is looking for a game.
 */
public final class DiscoveryResponder implements Runnable {
    private final int port;
    private volatile int gamePort;
    private volatile String name = "";
    private volatile int players = 1;
    private volatile boolean inMatch;
    private volatile int modeId;
    private volatile boolean stopped;
    private DatagramSocket socket;

    public DiscoveryResponder(int port) {
        this.port = port;
    }

    /** Returns false when the port is unavailable; joining by IP address still works then. */
    public boolean start(int gamePort, String hostName) {
        this.gamePort = gamePort;
        this.name = hostName;
        try {
            socket = new DatagramSocket(null);
            socket.setReuseAddress(true);
            socket.setBroadcast(true);
            socket.bind(new InetSocketAddress(port));
        } catch (IOException e) {
            if (socket != null) socket.close();
            socket = null;
            return false;
        }
        Thread t = new Thread(this, "hy-discovery-host");
        t.setDaemon(true);
        t.start();
        return true;
    }

    public void update(int playerCount, boolean matchRunning, int mode) {
        modeId = mode;
        players = playerCount;
        inMatch = matchRunning;
    }

    public void stop() {
        stopped = true;
        DatagramSocket s = socket;
        if (s != null) s.close();
    }

    @Override
    public void run() {
        byte[] buf = new byte[64];
        DatagramPacket in = new DatagramPacket(buf, buf.length);
        PacketReader r = new PacketReader();
        PacketWriter w = new PacketWriter(64);
        while (!stopped) {
            try {
                in.setLength(buf.length);
                socket.receive(in);
                if (in.getLength() < 6) continue;
                r.wrap(buf, 0, in.getLength());
                if (r.i32() != Protocol.DISCOVERY_MAGIC || r.u8() != Protocol.D_PROBE) continue;
                byte[] reply = w.beginRaw().i32(Protocol.DISCOVERY_MAGIC).u8(Protocol.D_REPLY)
                        .u8(Protocol.VERSION).u8(players).u8(com.hazardyard.game.core.GameConfig.MAX_HUMANS)
                        .u8(inMatch ? 1 : 0).u16(gamePort).str(name).u8(modeId).finishRaw();
                socket.send(new DatagramPacket(reply, reply.length, in.getAddress(), in.getPort()));
            } catch (IOException | RuntimeException e) {
                if (stopped) break;
            }
        }
    }
}
