package com.hazardyard.game.core;

/**
 * Sound ids. The first {@link WeaponDef#ALL} ids are the gun shots, so a weapon id is its shot sound.
 * Every weapon also owns three reload sounds (start, load, done) and, for guns with a mechanical
 * action (pump, bolt, hammer), one action sound: no two weapons share a firing, reload or action sound.
 */
public final class Sounds {
    private Sounds() {}

    /** Shot sound of weapon {@code weaponId}: ids 0..7 are the eight guns. */
    public static int shot(int weaponId) {
        return weaponId >= 0 && weaponId < WeaponDef.ALL.length ? weaponId : WeaponDef.PISTOL;
    }

    public static final int PICKUP = 8;
    public static final int HIT = 9;
    public static final int HURT = 10;
    public static final int KILL = 11;
    public static final int DEATH = 12;
    public static final int RESPAWN = 13;
    public static final int IMPACT = 14;
    public static final int COUNTDOWN = 15;
    public static final int GO = 16;
    public static final int WIN = 17;
    public static final int LOSE = 18;
    public static final int CONFIRM = 19;
    /** The dodge roll: one short, snappy cloth-and-footwork whoosh, unlike any gun or movement sound. */
    public static final int DODGE = 20;

    /** First of the 3 x 8 reload sounds. */
    public static final int RELOAD_BASE = 21;
    private static final int GUNS = 8;
    /** First of the 8 mechanical action sounds (only some guns use theirs). */
    public static final int ACTION_BASE = RELOAD_BASE + 3 * GUNS;
    public static final int COUNT = ACTION_BASE + GUNS;

    private static int w(int weaponId) {
        return weaponId >= 0 && weaponId < GUNS ? weaponId : WeaponDef.PISTOL;
    }

    /** The reload begins: magazine release, ejector, bolt or lid. */
    public static int reloadStart(int weaponId) {
        return RELOAD_BASE + 3 * w(weaponId);
    }

    /** The moment the ammunition is restored: the new magazine seats, or a shell goes in. */
    public static int reloadLoad(int weaponId) {
        return RELOAD_BASE + 3 * w(weaponId) + 1;
    }

    /** The reload is over and the gun is ready: slide, bolt, pump or cylinder snapping shut. */
    public static int reloadDone(int weaponId) {
        return RELOAD_BASE + 3 * w(weaponId) + 2;
    }

    /** Mechanical action heard a moment after a shot (pump, bolt, hammer), or -1 for guns without one. */
    public static int action(int weaponId) {
        WeaponDef d = WeaponDef.byId(weaponId);
        return d.actionDelay > 0f ? ACTION_BASE + w(weaponId) : -1;
    }
}
