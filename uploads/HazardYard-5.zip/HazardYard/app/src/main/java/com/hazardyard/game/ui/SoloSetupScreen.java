package com.hazardyard.game.ui;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.hazardyard.game.bot.BotDifficulty;
import com.hazardyard.game.core.GameMode;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.render.Palette;

/** Picks the game mode, the arena, the number of computer opponents and how good they are, then starts a solo match. */
final class SoloSetupScreen implements Screen {
    private final Navigator nav;
    private final FrameLayout root;
    private final ScreenPadding padding;
    private final MapPreviewView preview;
    private final TextView mapName;
    private final TextView mapBlurb;
    private final TextView mapSize;
    private final SegmentedControl bots;
    private final SegmentedControl difficulty;
    private final SegmentedControl modeControl;
    private final TextView footer;
    private final View arenaLabel;
    private final View arenaRow;
    private final View botsLabel;
    private final View botsRow;
    private final TextView botsNote;
    private final TextView pickName;
    /** The classic arena chosen (kept while Battleground, which has its own arena, is selected). */
    private int mapId;
    private int mode;

    SoloSetupScreen(Context c, Navigator navigator) {
        nav = navigator;
        int[] last = navigator.soloChoices();
        mapId = last[0] < 0 || last[0] >= MapLibrary.CLASSIC_COUNT ? MapLibrary.DEFAULT_ID : last[0];
        mode = last.length > 3 ? GameMode.clampId(last[3]) : GameMode.CLASSIC;

        root = new FrameLayout(c);
        root.addView(new BackdropView(c), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.HORIZONTAL);
        padding = new ScreenPadding(content, c, 40, 24, 40, 24);
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- left: what you are about to play on ----
        LinearLayout left = Ui.column(c);
        content.addView(left, Ui.lp(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f, 0, 0, 24, 0, c));
        left.addView(Ui.label(c, "Play solo", 32f, Palette.TEXT, true));
        left.addView(new BackdropView.StripeBar(c), Ui.lp(Ui.dp(c, 110), Ui.dp(c, 8), 0f, 0, 8, 0, 0, c));
        preview = new MapPreviewView(c);
        left.addView(preview, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f, 0, 12, 0, 0, c));
        mapName = Ui.label(c, "", 20f, Palette.TEXT, true);
        left.addView(mapName, Ui.fillWidth(c, 10));
        mapSize = Ui.label(c, "", 12f, Palette.ACCENT, true);
        left.addView(mapSize, Ui.fillWidth(c, 2));
        mapBlurb = Ui.label(c, "", 13f, Palette.TEXT_DIM, false);
        left.addView(mapBlurb, Ui.fillWidth(c, 4));

        // ---- right: choices ----
        ScrollView scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        content.addView(scroll, Ui.lp(Ui.dp(c, 320), ViewGroup.LayoutParams.MATCH_PARENT, 0f, 0, 0, 0, 0, c));
        LinearLayout panel = Ui.panel(c);
        scroll.addView(panel, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        panel.addView(Ui.label(c, "Game mode", 13f, Palette.TEXT_DIM, false));
        String[] modeNames = new String[GameMode.COUNT];
        for (int i = 0; i < modeNames.length; i++) modeNames[i] = GameMode.byId(i).name;
        modeControl = new SegmentedControl(c, modeNames, mode, new SegmentedControl.OnChange() {
            @Override
            public void onChange(int i) {
                setMode(i);
            }
        });
        panel.addView(modeControl, Ui.fillWidth(c, 6));

        arenaLabel = Ui.label(c, "Arena", 13f, Palette.TEXT_DIM, false);
        panel.addView(arenaLabel, Ui.fillWidth(c, 14));
        LinearLayout mapRow = Ui.row(c);
        mapRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView prev = arrow(c, "\u25C0");
        TextView next = arrow(c, "\u25B6");
        pickName = Ui.label(c, "", 16f, Palette.TEXT, true);
        pickName.setGravity(Gravity.CENTER);
        pickName.setSingleLine(true);
        mapRow.addView(prev, Ui.lp(Ui.dp(c, 44), Ui.dp(c, 44), 0f, 0, 0, 0, 0, c));
        mapRow.addView(pickName, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 0, 0, c));
        mapRow.addView(next, Ui.lp(Ui.dp(c, 44), Ui.dp(c, 44), 0f, 0, 0, 0, 0, c));
        panel.addView(mapRow, Ui.fillWidth(c, 6));
        arenaRow = mapRow;
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapId = (mapId + MapLibrary.CLASSIC_COUNT - 1) % MapLibrary.CLASSIC_COUNT;
                showMap();
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapId = (mapId + 1) % MapLibrary.CLASSIC_COUNT;
                showMap();
            }
        });

        botsLabel = Ui.label(c, "Opponents", 13f, Palette.TEXT_DIM, false);
        panel.addView(botsLabel, Ui.fillWidth(c, 14));
        bots = new SegmentedControl(c, new String[] {"1", "2", "3"}, Math.max(0, Math.min(2, last[1] - 1)), new SegmentedControl.OnChange() {
            @Override
            public void onChange(int i) {
                // value read on start
            }
        });
        panel.addView(bots, Ui.fillWidth(c, 6));
        botsRow = bots;
        botsNote = Ui.label(c, "", 12f, Palette.ACCENT, true);
        panel.addView(botsNote, Ui.fillWidth(c, 14));

        panel.addView(Ui.label(c, "Difficulty", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 14));
        String[] names = new String[BotDifficulty.COUNT];
        for (int i = 0; i < names.length; i++) names[i] = BotDifficulty.of(i).name;
        difficulty = new SegmentedControl(c, names, Math.max(0, Math.min(BotDifficulty.COUNT - 1, last[2])), new SegmentedControl.OnChange() {
            @Override
            public void onChange(int i) {
                // value read on start
            }
        });
        panel.addView(difficulty, Ui.fillWidth(c, 6));

        Button start = Ui.button(c, "Start match", true);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nav.startSolo(mode, mapId, bots.selected() + 1, difficulty.selected());
            }
        });
        panel.addView(start, Ui.fillWidth(c, 18));
        footer = Ui.label(c, "", 11f, Palette.TEXT_DIM, false);
        panel.addView(footer, Ui.fillWidth(c, 8));
        Button back = Ui.button(c, "Back", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nav.showMenu(null);
            }
        });
        panel.addView(back, Ui.fillWidth(c, 10));

        setMode(mode);
    }

    private static TextView arrow(Context c, String glyph) {
        TextView t = Ui.label(c, glyph, 16f, Palette.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        t.setBackground(Ui.rounded(c, 0xFF1E2733, 0xFF3A4757, 10f, 1.5f));
        return t;
    }

    /** Switches between Classic (choose an arena and 1-3 opponents) and Battleground (its own huge map, bots fill the roster). */
    private void setMode(int id) {
        mode = GameMode.clampId(id);
        GameMode m = GameMode.byId(mode);
        boolean fixed = m.fixedMap();
        int vis = fixed ? View.GONE : View.VISIBLE;
        arenaLabel.setVisibility(vis);
        arenaRow.setVisibility(vis);
        botsLabel.setVisibility(vis);
        botsRow.setVisibility(vis);
        botsNote.setVisibility(fixed ? View.VISIBLE : View.GONE);
        if (fixed) {
            botsNote.setText((m.roster - 1) + " bots fill the roster: " + m.roster + " fighters in all.");
        }
        int minutes = m.matchSeconds / 60;
        footer.setText("First to " + m.killLimit + " kills wins, or the most kills when the clock runs out ("
                + minutes + (m.matchSeconds % 60 == 0 ? "" : ":" + (m.matchSeconds % 60 < 10 ? "0" : "") + m.matchSeconds % 60) + " min).");
        showMap();
    }

    private void showMap() {
        GameMode m = GameMode.byId(mode);
        int id = m.fixedMap() ? m.mapId : mapId;
        preview.setMap(id);
        mapName.setText(MapLibrary.name(id));
        pickName.setText(MapLibrary.name(mapId));
        mapBlurb.setText(m.fixedMap() ? m.blurb : MapLibrary.blurb(id));
        mapSize.setText(MapLibrary.sizeText(id));
    }

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShow() {
        // nothing to start
    }

    @Override
    public void onHide() {
        // nothing to stop
    }

    @Override
    public boolean onBack() {
        nav.showMenu(null);
        return true;
    }

    @Override
    public void onInsets(int l, int t, int r, int b) {
        padding.apply(l, t, r, b);
    }
}
