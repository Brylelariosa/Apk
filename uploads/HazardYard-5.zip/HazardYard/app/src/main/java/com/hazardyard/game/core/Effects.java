package com.hazardyard.game.core;

/**
 * Pooled short-lived visual effects (muzzle flashes, impact sparks, death bursts), the kill feed and
 * the "heard shots" that reveal where other players fired from. Purely presentational; never affects
 * gameplay and never allocates after construction.
 */
public final class Effects {
    public static final int MAX = 96;
    public static final int KIND_FLASH = 0;
    public static final int KIND_SPARK = 1;
    public static final int KIND_BURST = 2;
    /** Soft puff that grows, drifts and fades (roll dust). */
    public static final int KIND_DUST = 3;
    /** Jagged electric arcs (energy weapons hitting something). */
    public static final int KIND_ZAP = 4;
    /** A weapon was taken off its pad: a ring that opens and sparks that rise. */
    public static final int KIND_PICKUP = 5;

    public final boolean[] active = new boolean[MAX];
    public final int[] kind = new int[MAX];
    public final int[] color = new int[MAX];
    public final float[] x = new float[MAX];
    public final float[] y = new float[MAX];
    public final float[] angle = new float[MAX];
    public final float[] age = new float[MAX];
    public final float[] life = new float[MAX];
    /** Final radius of a dust puff. */
    public final float[] size = new float[MAX];
    private int cursor;

    public static final int FEED_MAX = 3;
    public static final float FEED_LIFE = 4.5f;
    public final int[] feedKiller = new int[FEED_MAX];
    public final int[] feedVictim = new int[FEED_MAX];
    public final int[] feedWeapon = new int[FEED_MAX];
    public final float[] feedAge = new float[FEED_MAX];
    /** Entry 0 is the oldest. */
    public int feedCount;

    /** How long a heard shot stays on the minimap and as an edge arrow. */
    public static final float NOISE_LIFE = 2.8f;
    /** Where player i was last heard firing. Only meaningful while {@link #noiseAge} is below {@link #NOISE_LIFE}. */
    public final float[] noiseX = new float[GameConfig.MAX_PLAYERS];
    public final float[] noiseY = new float[GameConfig.MAX_PLAYERS];
    /** Seconds since player i was last heard; {@link #NOISE_LIFE} or more means there is nothing to show. */
    public final float[] noiseAge = new float[GameConfig.MAX_PLAYERS];

    public Effects() {
        for (int i = 0; i < noiseAge.length; i++) noiseAge[i] = NOISE_LIFE;
    }

    /** Player {@code player} was heard firing at (px, py). */
    public void noise(int player, float px, float py) {
        if (player < 0 || player >= noiseAge.length) return;
        noiseX[player] = px;
        noiseY[player] = py;
        noiseAge[player] = 0f;
    }

    /** 1 right after the shot, fading to 0 when the ping runs out. */
    public float noiseStrength(int player) {
        float a = noiseAge[player];
        return a >= NOISE_LIFE ? 0f : 1f - a / NOISE_LIFE;
    }

    public void muzzle(float px, float py, float ang, int argb) {
        spawn(KIND_FLASH, px, py, ang, argb, 0.07f);
    }

    public void impact(float px, float py, int argb) {
        spawn(KIND_SPARK, px, py, 0f, argb, 0.20f);
    }

    public void burst(float px, float py, int argb) {
        spawn(KIND_BURST, px, py, 0f, argb, 0.50f);
    }

    /** A weapon was picked up from the pad at (px, py). */
    public void pickup(float px, float py, int argb) {
        spawn(KIND_PICKUP, px, py, 0f, argb, 0.55f);
    }

    /** Electric arcs, for energy weapons. */
    public void zap(float px, float py, int argb) {
        spawn(KIND_ZAP, px, py, 0f, argb, 0.24f);
    }

    /** A puff of dust at (px, py) that drifts along {@code ang} while it grows to {@code radius} and fades. */
    public void dust(float px, float py, float ang, float radius, int argb, float lifeSeconds) {
        size[spawn(KIND_DUST, px, py, ang, argb, lifeSeconds)] = radius;
    }

    private int spawn(int k, float px, float py, float ang, int argb, float lifeSeconds) {
        int slot = -1;
        for (int n = 0; n < MAX; n++) {
            int i = (cursor + n) % MAX;
            if (!active[i]) {
                slot = i;
                break;
            }
        }
        if (slot < 0) slot = cursor;
        cursor = (slot + 1) % MAX;
        active[slot] = true;
        kind[slot] = k;
        x[slot] = px;
        y[slot] = py;
        angle[slot] = ang;
        color[slot] = argb;
        age[slot] = 0f;
        life[slot] = lifeSeconds;
        return slot;
    }

    public void addKill(int killer, int victim, int weaponId) {
        if (feedCount == FEED_MAX) {
            for (int i = 1; i < FEED_MAX; i++) copyFeed(i, i - 1);
            feedCount--;
        }
        int i = feedCount++;
        feedKiller[i] = killer;
        feedVictim[i] = victim;
        feedWeapon[i] = weaponId;
        feedAge[i] = 0f;
    }

    private void copyFeed(int from, int to) {
        feedKiller[to] = feedKiller[from];
        feedVictim[to] = feedVictim[from];
        feedWeapon[to] = feedWeapon[from];
        feedAge[to] = feedAge[from];
    }

    public void update(float dt) {
        for (int i = 0; i < MAX; i++) {
            if (!active[i]) continue;
            age[i] += dt;
            if (age[i] >= life[i]) active[i] = false;
        }
        for (int i = 0; i < noiseAge.length; i++) {
            if (noiseAge[i] < NOISE_LIFE) noiseAge[i] += dt;
        }
        for (int i = 0; i < feedCount; i++) feedAge[i] += dt;
        while (feedCount > 0 && feedAge[0] > FEED_LIFE) {
            for (int i = 1; i < feedCount; i++) copyFeed(i, i - 1);
            feedCount--;
        }
    }

    public void clear() {
        for (int i = 0; i < MAX; i++) active[i] = false;
        for (int i = 0; i < noiseAge.length; i++) noiseAge[i] = NOISE_LIFE;
        feedCount = 0;
    }
}
