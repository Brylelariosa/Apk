package com.hazardyard.game.render;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.core.Weapon;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.input.ControlGeometry;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.settings.ControlSettings;

/**
 * Screen-space interface drawn over the world: match timer and scores, minimap, the on-screen
 * controls, the ammo readout, a slim health strip, the kill feed, edge arrows towards shots that were
 * heard, and the countdown / respawn / results overlays. The centre of the screen stays free for the
 * action.
 *
 * <p>The five information widgets (minimap, timer and scores, ammo, health, kill feed) sit where the
 * player's HUD layout puts them and are drawn at the size the player chose: each one is drawn in its own
 * little coordinate system centred on its position, which is scaled as a whole. The same code draws them
 * live in a match and, with sample data, in the HUD editor. Sizes are in dp (density scaled) and text is
 * fitted to its box, so the layout holds on any resolution, aspect ratio or system font. Allocation-free
 * per frame.
 */
public final class HudRenderer {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();
    private final Typeface bold = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    private final Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    private final int[] order = new int[GameConfig.MAX_PLAYERS];
    private final ControlsRenderer controls = new ControlsRenderer();
    /** The walls of the minimap never change during a match, so they are drawn once into this bitmap. */
    private Bitmap miniBitmap;
    private int miniKey;
    /** Lighter than {@link Palette#PANEL}: HUD plates should not shout over the game. */
    private static final int PLATE = 0x8A131A22;

    private int lastSeconds = -1;
    private String timerText = "0:00";
    private float d = 1f;
    private int w = 1;
    private int h = 1;
    // safe area (display cutout / system bars): the HUD keeps clear of it, the world draws under it
    private float sl, st_, sr, sb;
    /** Horizontal centre of the safe area. */
    private float mid;

    public HudRenderer() {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    public void draw(Canvas c, GameState st, Camera cam, InputController in, int pingMs, float density, float time) {
        ControlGeometry geo = in.geometry();
        begin(cam.viewW, cam.viewH, density, geo);
        Player me = st.local();

        drawDamageTint(c, me);
        drawHeardArrows(c, st, cam);
        widgetMinimap(c, st, cam, geo, pingMs);
        widgetScore(c, st, geo);
        widgetKillFeed(c, st, geo);
        controls.draw(c, in, st, me, d, time);
        widgetAmmo(c, me, geo);
        widgetHealth(c, me, geo);
        drawCenterMessage(c, st, me, time);
        if (st.phase == GameState.PHASE_ENDED) drawResults(c, st);
    }

    /**
     * The HUD editor's picture of the five widgets, drawn from a made-up match so the player sees exactly
     * what each element looks like where it will sit. {@code selected} (or -1) gets a highlight; widgets whose
     * boxes overlap another element are outlined in red.
     */
    public void drawEditorWidgets(Canvas c, GameState sample, ControlGeometry geo, ControlSettings layout, int selected,
                                  float density) {
        begin(geo.width, geo.height, density, geo);
        Player me = sample.local();
        widgetMinimap(c, sample, null, geo, 42);
        widgetScore(c, sample, geo);
        widgetKillFeed(c, sample, geo);
        widgetAmmo(c, me, geo);
        widgetHealth(c, me, geo);
        for (int i = ControlSettings.CONTROL_COUNT; i < ControlSettings.COUNT; i++) {
            outline(c, geo, i, i == selected, clashes(geo, layout, i));
        }
    }

    /** True when element {@code i} overlaps another element that is visible in the current layout. */
    public static boolean clashes(ControlGeometry geo, ControlSettings layout, int i) {
        for (int j = 0; j < ControlSettings.COUNT; j++) {
            if (j == i || (j == ControlSettings.FIRE && !layout.fireButtonEnabled())) continue;
            if (geo.overlaps(i, j)) return true;
        }
        return false;
    }

    /** A rounded outline around an element's box: accent for the selected one, red where it overlaps something. */
    public void outline(Canvas c, ControlGeometry geo, int element, boolean selected, boolean clash) {
        if (!selected && !clash) return;
        float pad = 4f * d;
        rect.set(geo.cx[element] - geo.hw[element] - pad, geo.cy[element] - geo.hh[element] - pad,
                geo.cx[element] + geo.hw[element] + pad, geo.cy[element] + geo.hh[element] + pad);
        stroke.setColor(selected ? Palette.ACCENT : Palette.withAlpha(Palette.BAD, 220));
        stroke.setStrokeWidth((selected ? 2.4f : 1.8f) * d);
        c.drawRoundRect(rect, 10f * d, 10f * d, stroke);
    }

    private void begin(int viewW, int viewH, float density, ControlGeometry geo) {
        d = density;
        w = viewW;
        h = viewH;
        sl = geo.insetL;
        st_ = geo.insetT;
        sr = geo.insetR;
        sb = geo.insetB;
        mid = sl + (w - sl - sr) * 0.5f;
    }

    /** Moves the origin to the centre of a widget and applies the player's size for it: draw in local, dp-based coordinates. */
    private void enter(Canvas c, ControlGeometry geo, int element) {
        c.save();
        c.translate(geo.cx[element], geo.cy[element]);
        c.scale(geo.sc[element], geo.sc[element]);
    }

    // ------------------------------------------------------------------ helpers

    private void label(Canvas c, String s, float x, float y, float sizeDp, int color, Paint.Align align, Typeface tf) {
        text.setTypeface(tf);
        text.setTextSize(sizeDp * d);
        text.setColor(color);
        text.setTextAlign(align);
        c.drawText(s, x, y, text);
    }

    private float measure(String s, float sizeDp, Typeface tf) {
        text.setTypeface(tf);
        text.setTextSize(sizeDp * d);
        return text.measureText(s);
    }

    /** Like {@link #label} but shrinks the text (down to 60%) so it never wider than {@code maxWidthDp}, whatever font the phone uses. */
    private void labelFit(Canvas c, String s, float x, float y, float sizeDp, float maxWidthDp, int color,
                          Paint.Align align, Typeface tf) {
        float wpx = measure(s, sizeDp, tf);
        float maxPx = maxWidthDp * d;
        if (wpx > maxPx && wpx > 0f) sizeDp = Math.max(sizeDp * 0.6f, sizeDp * maxPx / wpx);
        label(c, s, x, y, sizeDp, color, align, tf);
    }

    /** Width of a string once fitted to {@code maxWidthDp}, in pixels. */
    private float measureFit(String s, float sizeDp, float maxWidthDp, Typeface tf) {
        float wpx = measure(s, sizeDp, tf);
        float maxPx = maxWidthDp * d;
        if (wpx > maxPx && wpx > 0f) {
            sizeDp = Math.max(sizeDp * 0.6f, sizeDp * maxPx / wpx);
            return measure(s, sizeDp, tf);
        }
        return wpx;
    }

    private void panel(Canvas c, float l, float t, float r, float b, float radiusDp) {
        rect.set(l, t, r, b);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(PLATE);
        c.drawRoundRect(rect, radiusDp * d, radiusDp * d, fill);
    }

    // ------------------------------------------------------------------ overlays on the whole screen

    private void drawDamageTint(Canvas c, Player me) {
        if (me.hitFlash <= 0f) return;
        int a = (int) (80f * Math.min(1f, me.hitFlash / 0.15f));
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(Palette.BAD, a));
        c.drawRect(0f, 0f, w, h, fill);
    }

    /**
     * Edge arrows towards shots the player has just heard from off-screen. Enemies are not tracked:
     * an arrow only exists for a moment after somebody fires and points at where the shot came from.
     */
    private void drawHeardArrows(Canvas c, GameState st, Camera cam) {
        Effects fx = st.effects;
        float margin = 30f * d;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (i == st.localId || !p.connected || !p.alive) continue;
            float strength = fx.noiseStrength(i);
            if (strength <= 0f) continue;
            float sx = cam.screenX(fx.noiseX[i]);
            float sy = cam.screenY(fx.noiseY[i]);
            if (sx >= 0f && sx <= w && sy >= 0f && sy <= h) continue;
            float cx = mid;
            float cy = st_ + (h - st_ - sb) * 0.5f;
            float dx = sx - cx;
            float dy = sy - cy;
            float halfW = (w - sl - sr) * 0.5f - margin;
            float halfH = (h - st_ - sb) * 0.5f - margin;
            float kx = Math.abs(dx) > 1e-3f ? halfW / Math.abs(dx) : Float.MAX_VALUE;
            float ky = Math.abs(dy) > 1e-3f ? halfH / Math.abs(dy) : Float.MAX_VALUE;
            float k = Math.min(kx, ky);
            float ax = cx + dx * k;
            float ay = cy + dy * k;
            float ang = (float) Math.atan2(dy, dx);
            float ca = (float) Math.cos(ang);
            float sa = (float) Math.sin(ang);
            float s = 11f * d;
            int color = PlayerColors.of(i);
            int alpha = 70 + (int) (170f * strength);
            path.reset();
            path.moveTo(ax + ca * s, ay + sa * s);
            path.lineTo(ax - ca * s * 0.6f - sa * s * 0.85f, ay - sa * s * 0.6f + ca * s * 0.85f);
            path.lineTo(ax - ca * s * 0.6f + sa * s * 0.85f, ay - sa * s * 0.6f - ca * s * 0.85f);
            path.close();
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Palette.withAlpha(color, alpha));
            c.drawPath(path, fill);
            stroke.setColor(Palette.withAlpha(0xFF0B0F14, alpha * 200 / 255));
            stroke.setStrokeWidth(1.5f * d);
            c.drawPath(path, stroke);
            // a ring that grows while the sound is fresh: "something just fired over there"
            float grow = Math.min(1f, fx.noiseAge[i] / 0.5f);
            stroke.setColor(Palette.withAlpha(color, (int) (alpha * (1f - grow) * 0.7f)));
            stroke.setStrokeWidth(1.6f * d);
            c.drawCircle(ax - ca * s * 0.2f, ay - sa * s * 0.2f, (s * 0.9f) + grow * 12f * d, stroke);
        }
    }

    // ------------------------------------------------------------------ top of the screen

    /** The minimap sits in a fixed 128 x 88 dp panel; the map is fitted into it whatever its shape. */
    private void widgetMinimap(Canvas c, GameState st, Camera cam, ControlGeometry geo, int pingMs) {
        TileMap map = st.map;
        enter(c, geo, ControlSettings.MINIMAP);
        float pw = 128f * d;
        float ph = 88f * d;
        panel(c, -pw * 0.5f, -ph * 0.5f, pw * 0.5f, ph * 0.5f, 8f);
        float s = Math.min(120f * d / map.worldW, 80f * d / map.worldH);
        float mw = map.worldW * s;
        float mh = map.worldH * s;
        float mx = -mw * 0.5f;
        float my = -mh * 0.5f;
        MapTheme th = MapTheme.of(map.id);
        fill.setStyle(Paint.Style.FILL);
        drawMinimapWalls(c, map, th, mx, my, mw, mh, geo.sc[ControlSettings.MINIMAP]);
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (!pk.active) continue;
            fill.setColor(WeaponDef.byId(pk.weaponId).color);
            c.drawCircle(mx + pk.x * s, my + pk.y * s, (map.worldW > 2400f ? 1.3f : 1.6f) * d, fill);
        }
        if (cam != null) {
            float vx0 = Math.max(0f, cam.x - cam.halfViewWorldW());
            float vy0 = Math.max(0f, cam.y - cam.halfViewWorldH());
            float vx1 = Math.min(map.worldW, cam.x + cam.halfViewWorldW());
            float vy1 = Math.min(map.worldH, cam.y + cam.halfViewWorldH());
            stroke.setColor(Palette.withAlpha(0xFFFFFFFF, 90));
            stroke.setStrokeWidth(1f * d);
            c.drawRect(mx + vx0 * s, my + vy0 * s, mx + vx1 * s, my + vy1 * s, stroke);
        }

        // Other players are NOT tracked: one shows up only where (and while) its gun was just heard.
        Effects fx = st.effects;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (i == st.localId || !p.connected || !p.alive) continue;
            float strength = fx.noiseStrength(i);
            if (strength <= 0f) continue;
            float px = mx + fx.noiseX[i] * s;
            float py = my + fx.noiseY[i] * s;
            int color = PlayerColors.of(i);
            float grow = Math.min(1f, fx.noiseAge[i] / 0.55f);
            stroke.setColor(Palette.withAlpha(color, (int) (210f * strength * (1f - grow * 0.65f))));
            stroke.setStrokeWidth(1.3f * d);
            c.drawCircle(px, py, (3f + 8f * grow) * d, stroke);
            fill.setColor(Palette.withAlpha(color, 90 + (int) (165f * strength)));
            c.drawCircle(px, py, 2.6f * d, fill);
        }
        Player me = st.local();
        if (me.connected && me.alive) {
            float px = mx + me.rx * s;
            float py = my + me.ry * s;
            fill.setColor(PlayerColors.of(st.localId));
            c.drawCircle(px, py, 3f * d, fill);
            stroke.setColor(0xFFFFFFFF);
            stroke.setStrokeWidth(1.2f * d);
            c.drawCircle(px, py, 5f * d, stroke);
        }
        if (pingMs > 0) {
            float y = ph * 0.5f + 14f * d;
            float x = -pw * 0.5f + 4f * d;
            label(c, "Ping ", x, y, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
            x += measure("Ping ", 11f, medium);
            label(c, Txt.of(pingMs), x, y, 11f, pingMs > 120 ? Palette.WARN : Palette.TEXT_DIM, Paint.Align.LEFT, medium);
            x += measure(Txt.of(pingMs), 11f, medium);
            label(c, " ms", x, y, 11f, Palette.TEXT_DIM, Paint.Align.LEFT, medium);
        }
        c.restore();
    }

    /**
     * Blits the minimap's walls in local coordinates; the bitmap is rebuilt only when the map or its on-screen
     * size changes (it is drawn at the size it is shown, so a big minimap stays sharp).
     */
    private void drawMinimapWalls(Canvas c, TileMap map, MapTheme th, float mx, float my, float mw, float mh, float userScale) {
        int bw = Math.max(2, (int) Math.ceil(mw * userScale));
        int bh = Math.max(2, (int) Math.ceil(mh * userScale));
        int key = (map.id * 7919 + bw) * 7919 + bh;
        if (miniBitmap == null || miniKey != key) {
            if (miniBitmap != null) miniBitmap.recycle();
            miniBitmap = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
            miniKey = key;
            Canvas mc = new Canvas(miniBitmap);
            float s = bw / map.worldW;
            float thin = Math.max(1f, 0.8f * d);
            fill.setStyle(Paint.Style.FILL);
            for (int pass = 0; pass < 4; pass++) {
                for (int b = 0; b < map.blockCount; b++) {
                    int kind = map.blocks[b * 5 + 4];
                    if (MapShapes.layerOf(kind) != pass) continue;
                    switch (kind) {
                        case TileMap.WATER: fill.setColor(Palette.withAlpha(th.waterLight, 190)); break;
                        case TileMap.FENCE:
                        case TileMap.FENCE_JOINT: fill.setColor(Palette.withAlpha(th.fence, 200)); break;
                        case TileMap.CRATE: fill.setColor(0xFF9C6A2E); break;
                        case TileMap.PILLAR:
                        case TileMap.TANK: fill.setColor(0xFF8497B4); break;
                        default: fill.setColor(0xFF6F809A); break;
                    }
                    MapShapes.fill(mc, map, b, 0f, 0f, s, fill, path, thin);
                }
            }
        }
        rect.set(mx, my, mx + mw, my + mh);
        c.drawBitmap(miniBitmap, null, rect, null);
    }

    /** Timer on a plate, the fighters' scores in a row beneath it (compact numbers in their colours when there are many). */
    private void widgetScore(Canvas c, GameState st, ControlGeometry geo) {
        enter(c, geo, ControlSettings.SCORE);
        float pw = 92f * d;
        float ph = 30f * d;
        float top = -28f * d;
        panel(c, -pw * 0.5f, top, pw * 0.5f, top + ph, 10f);
        int secs = (int) Math.ceil(st.timeLeft);
        if (secs != lastSeconds) {
            lastSeconds = secs;
            int sec = secs % 60;
            timerText = Txt.of(secs / 60) + (sec < 10 ? ":0" : ":") + Txt.of(sec);
        }
        boolean urgent = st.phase == GameState.PHASE_PLAYING && secs <= 10;
        labelFit(c, timerText, 0f, top + ph * 0.73f, 20f, 76f, urgent ? Palette.BAD : Palette.TEXT, Paint.Align.CENTER, bold);

        int n = 0;
        for (int i = 0; i < st.players.length; i++) if (st.players[i].connected) n++;
        if (n == 0) {
            c.restore();
            return;
        }
        float gap = 4f * d;
        float maxTotal = 196f * d;
        float cw = Math.min(44f * d, (maxTotal - (n - 1) * gap) / n);
        boolean compact = cw < 34f * d;
        float chh = 20f * d;
        float total = n * cw + (n - 1) * gap;
        float x = -total * 0.5f;
        float y = top + ph + 5f * d;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            panel(c, x, y, x + cw, y + chh, 8f);
            if (i == st.localId) {
                stroke.setColor(Palette.withAlpha(Palette.ACCENT, 190));
                stroke.setStrokeWidth(1.3f * d);
                c.drawRoundRect(rect, 8f * d, 8f * d, stroke);
            }
            if (compact) {
                labelFit(c, Txt.of(p.kills), x + cw * 0.5f, y + chh * 0.74f, 13f, cw / d - 2f, PlayerColors.of(i), Paint.Align.CENTER, bold);
            } else {
                fill.setStyle(Paint.Style.FILL);
                fill.setColor(PlayerColors.of(i));
                c.drawCircle(x + 10f * d, y + chh * 0.5f, 4.6f * d, fill);
                labelFit(c, Txt.of(p.kills), x + cw - 8f * d, y + chh * 0.74f, 13f, 22f, Palette.TEXT, Paint.Align.RIGHT, bold);
            }
            x += cw + gap;
        }
        c.restore();
    }

    private void widgetKillFeed(Canvas c, GameState st, ControlGeometry geo) {
        Effects fx = st.effects;
        enter(c, geo, ControlSettings.FEED);
        float left = -88f * d;
        float top = -39f * d;
        for (int i = fx.feedCount - 1, k = 0; i >= 0 && k < 3; i--, k++) {
            int victim = fx.feedVictim[i];
            int killer = fx.feedKiller[i];
            if (victim < 0 || victim >= st.players.length) continue;
            float fade = Effects.FEED_LIFE - fx.feedAge[i];
            int alpha = fade < 0.8f ? (int) (255f * Math.max(0f, fade) / 0.8f) : 255;
            String vn = st.players[victim].name;
            boolean hasKiller = killer >= 0 && killer < st.players.length;
            String kn = hasKiller ? st.players[killer].name : "";
            String joint = hasKiller ? "  \u00BB  " : " was eliminated";
            float wk = hasKiller ? measureFit(kn, 13f, 84f, medium) : 0f;
            float wm = measure(joint, 13f, medium);
            float wv = measureFit(vn, 13f, 84f, medium);
            float total = wk + wm + wv;
            float y = top + k * 26f * d;
            rect.set(left, y, left + total + 16f * d, y + 22f * d);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Palette.withAlpha(0xFF131A22, (int) (alpha * 0.7f)));
            c.drawRoundRect(rect, 8f * d, 8f * d, fill);
            float x = left + 8f * d;
            float by = y + 16f * d;
            if (hasKiller) {
                labelFit(c, kn, x, by, 13f, 84f, Palette.withAlpha(PlayerColors.of(killer), alpha), Paint.Align.LEFT, medium);
                x += wk;
                label(c, joint, x, by, 13f, Palette.withAlpha(Palette.TEXT_DIM, alpha), Paint.Align.LEFT, medium);
                x += wm;
                labelFit(c, vn, x, by, 13f, 84f, Palette.withAlpha(PlayerColors.of(victim), alpha), Paint.Align.LEFT, medium);
            } else {
                labelFit(c, vn, x, by, 13f, 84f, Palette.withAlpha(PlayerColors.of(victim), alpha), Paint.Align.LEFT, medium);
                x += wv;
                label(c, joint, x, by, 13f, Palette.withAlpha(Palette.TEXT_DIM, alpha), Paint.Align.LEFT, medium);
            }
        }
        c.restore();
    }

    // ------------------------------------------------------------------ ammo and health

    /**
     * Ammunition and the weapon's name, in a small box the player can place anywhere. While the gun reloads the
     * name line says so, and the number shows the rounds that are really in the gun (a shotgun counts up shell by shell).
     */
    private void widgetAmmo(Canvas c, Player me, ControlGeometry geo) {
        enter(c, geo, ControlSettings.AMMO);
        Weapon wp = me.weapon;
        float top = -23f * d;
        int mag = wp.def.magSize;
        int ammoColor = wp.ammo == 0 ? Palette.BAD : (wp.ammo * 4 <= mag ? Palette.WARN : Palette.TEXT);
        String ammo = Txt.of(wp.ammo);
        String magText = Txt.of(mag);
        float wa = measure(ammo, 24f, bold);
        float ws = measure("/", 12f, bold);
        float wm = measure(magText, 12f, bold);
        float gap = 2f * d;
        float x = -(wa + gap + ws + wm) * 0.5f;
        float by = top + 24f * d;
        label(c, ammo, x, by, 24f, ammoColor, Paint.Align.LEFT, bold);
        label(c, "/", x + wa + gap, by, 12f, Palette.TEXT_DIM, Paint.Align.LEFT, bold);
        label(c, magText, x + wa + gap + ws, by, 12f, Palette.TEXT_DIM, Paint.Align.LEFT, bold);
        if (wp.reloading) {
            labelFit(c, "Reloading", 0f, top + 38f * d, 11f, 66f, Palette.ACCENT, Paint.Align.CENTER, medium);
        } else {
            labelFit(c, wp.def.name, 0f, top + 38f * d, 11f, 66f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
        }
        c.restore();
    }

    /** A thin strip, faint while health is full. */
    private void widgetHealth(Canvas c, Player me, ControlGeometry geo) {
        if (!me.connected || !me.alive) return;
        enter(c, geo, ControlSettings.HEALTH);
        float bw = 150f * d;
        float bh = 6f * d;
        float textW = 26f * d;
        float bx = -(bw + 6f * d + textW) * 0.5f;
        float by = -bh * 0.5f - 1f * d;
        int hp = Math.max(0, me.health);
        float frac = Math.max(0f, Math.min(1f, hp / (float) GameConfig.PLAYER_MAX_HEALTH));
        boolean full = hp >= GameConfig.PLAYER_MAX_HEALTH;
        float a = full ? 0.45f : 1f;
        fill.setStyle(Paint.Style.FILL);
        rect.set(bx, by, bx + bw, by + bh);
        fill.setColor(Palette.withAlpha(0xFFFFFFFF, (int) (48f * a)));
        c.drawRoundRect(rect, bh * 0.5f, bh * 0.5f, fill);
        if (frac > 0f) {
            rect.set(bx, by, bx + bw * frac, by + bh);
            int base = frac > 0.5f ? Palette.GOOD : (frac > 0.25f ? Palette.WARN : Palette.BAD);
            fill.setColor(Palette.withAlpha(base, (int) (255f * a)));
            c.drawRoundRect(rect, bh * 0.5f, bh * 0.5f, fill);
        }
        label(c, Txt.of(hp), bx + bw + 6f * d, by + bh + 2.5f * d, 11f, Palette.withAlpha(Palette.TEXT, (int) (255f * a)),
                Paint.Align.LEFT, bold);
        c.restore();
    }

    // ------------------------------------------------------------------ centre messages

    private void drawCenterMessage(Canvas c, GameState st, Player me, float time) {
        float cx = mid;
        float cy = h * 0.5f;
        switch (st.phase) {
            case GameState.PHASE_LOBBY:
                label(c, "Waiting for the host\u2026", cx, cy, 20f, Palette.TEXT, Paint.Align.CENTER, medium);
                return;
            case GameState.PHASE_COUNTDOWN: {
                int n = Math.max(1, (int) Math.ceil(st.countdown));
                label(c, Txt.of(n), cx + 2f * d, cy + 34f * d + 2f * d, 96f, 0x66000000, Paint.Align.CENTER, bold);
                label(c, Txt.of(n), cx, cy + 34f * d, 96f, Palette.ACCENT, Paint.Align.CENTER, bold);
                label(c, "Get ready", cx, cy - 56f * d, 18f, Palette.TEXT, Paint.Align.CENTER, medium);
                return;
            }
            case GameState.PHASE_PLAYING:
                if (!me.alive) {
                    label(c, "Eliminated", cx, h * 0.34f, 30f, Palette.BAD, Paint.Align.CENTER, bold);
                    int s = Math.max(1, (int) Math.ceil(me.respawnTimer));
                    label(c, "Respawning in", cx - 12f * d, h * 0.34f + 28f * d, 16f, Palette.TEXT, Paint.Align.RIGHT, medium);
                    label(c, Txt.of(s), cx - 6f * d, h * 0.34f + 28f * d, 18f, Palette.ACCENT, Paint.Align.LEFT, bold);
                } else if (me.spawnProtect > 0f) {
                    label(c, "Spawn shield", cx, h * 0.27f, 13f, Palette.SHIELD, Paint.Align.CENTER, medium);
                }
                return;
            default:
                return;
        }
    }

    private boolean ranksAbove(GameState st, int a, int b) {
        Player pa = st.players[a];
        Player pb = st.players[b];
        return pa.kills > pb.kills || (pa.kills == pb.kills && pa.deaths < pb.deaths);
    }

    private void drawResults(Canvas c, GameState st) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x99000000);
        c.drawRect(0f, 0f, w, h, fill);

        int n = 0;
        for (int i = 0; i < st.players.length; i++) if (st.players[i].connected) order[n++] = i;
        for (int a = 1; a < n; a++) {
            int v = order[a];
            int b = a - 1;
            while (b >= 0 && ranksAbove(st, v, order[b])) {
                order[b + 1] = order[b];
                b--;
            }
            order[b + 1] = v;
        }

        float pw = 360f * d;
        // Up to eight fighters have to fit into the screen height: the rows shrink when there are many.
        float rowH = Math.max(22f * d, Math.min(38f * d, (h - st_ - sb - 150f * d) / Math.max(1, n)));
        float ph = 138f * d + n * rowH;
        float px = mid - pw * 0.5f;
        float py = Math.max(10f * d, (h - ph) * 0.5f);
        rect.set(px, py, px + pw, py + ph);
        fill.setColor(Palette.PANEL_SOLID);
        c.drawRoundRect(rect, 14f * d, 14f * d, fill);
        stroke.setColor(Palette.PANEL_EDGE);
        stroke.setStrokeWidth(1.5f * d);
        c.drawRoundRect(rect, 14f * d, 14f * d, stroke);

        float cx = mid;
        if (st.winnerId == st.localId) {
            label(c, "Victory", cx, py + 44f * d, 34f, Palette.ACCENT, Paint.Align.CENTER, bold);
        } else if (st.winnerId >= 0 && st.winnerId < st.players.length) {
            labelFit(c, st.players[st.winnerId].name, cx, py + 40f * d, 26f, 300f, PlayerColors.of(st.winnerId), Paint.Align.CENTER, bold);
            label(c, "wins the match", cx, py + 60f * d, 13f, Palette.TEXT_DIM, Paint.Align.CENTER, medium);
        } else {
            label(c, "Draw", cx, py + 44f * d, 34f, Palette.TEXT, Paint.Align.CENTER, bold);
        }
        float hy = py + 82f * d;
        label(c, "K", px + pw - 70f * d, hy, 12f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        label(c, "D", px + pw - 24f * d, hy, 12f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        for (int r = 0; r < n; r++) {
            int i = order[r];
            Player p = st.players[i];
            float y = py + 90f * d + r * rowH;
            if (i == st.localId) {
                rect.set(px + 8f * d, y + 2f * d, px + pw - 8f * d, y + rowH - 4f * d);
                fill.setColor(0x22FFFFFF);
                c.drawRoundRect(rect, 8f * d, 8f * d, fill);
            }
            float by = y + rowH * 0.62f;
            label(c, Txt.of(r + 1), px + 26f * d, by, 15f, Palette.TEXT_DIM, Paint.Align.CENTER, bold);
            fill.setColor(PlayerColors.of(i));
            c.drawCircle(px + 52f * d, y + rowH * 0.5f - 1f * d, 7f * d, fill);
            labelFit(c, p.name, px + 68f * d, by, 16f, 180f, Palette.TEXT, Paint.Align.LEFT, medium);
            label(c, Txt.of(p.kills), px + pw - 70f * d, by, 18f, Palette.TEXT, Paint.Align.RIGHT, bold);
            label(c, Txt.of(p.deaths), px + pw - 24f * d, by, 18f, Palette.TEXT_DIM, Paint.Align.RIGHT, bold);
        }
        int secs = Math.max(0, (int) Math.ceil(st.resultsTimer));
        label(c, "Returning in", cx - 6f * d, py + ph - 14f * d, 12f, Palette.TEXT_DIM, Paint.Align.RIGHT, medium);
        label(c, Txt.of(secs), cx, py + ph - 14f * d, 13f, Palette.ACCENT, Paint.Align.LEFT, bold);
    }
}
