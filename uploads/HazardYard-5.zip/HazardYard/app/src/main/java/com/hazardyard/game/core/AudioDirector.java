package com.hazardyard.game.core;

/**
 * Turns what happens in a match into sound requests. Events that carry a position (shots, hits,
 * kills) are reported by the engines through the small methods below; everything that is visible
 * as a change of state (reload started, weapon picked up, respawn, countdown, match end) is
 * detected here by comparing the state with the previous frame, which works the same for the
 * host, a solo game and a client that only mirrors snapshots.
 */
public final class AudioDirector {
    /** Hits and impacts further than this from the listener are not worth a mixer voice. */
    private static final float EARSHOT = 900f;

    private final GameState st;
    private volatile SoundSink sink = SoundSink.NONE;

    /** A second dodge sound for the same player is held back this long (state flicker on a client, rapid taps). */
    private static final float DODGE_SOUND_GAP = 0.40f;
    /** A reload counts as having run to its end (not been cut short) when it was this far along. */
    private static final float RELOAD_FINISHED = 0.90f;

    private final boolean[] wasAlive = new boolean[GameConfig.MAX_PLAYERS];
    private final boolean[] wasReloading = new boolean[GameConfig.MAX_PLAYERS];
    private final boolean[] wasRolling = new boolean[GameConfig.MAX_PLAYERS];
    private final int[] lastWeapon = new int[GameConfig.MAX_PLAYERS];
    private final int[] lastAmmo = new int[GameConfig.MAX_PLAYERS];
    private final float[] lastReloadFraction = new float[GameConfig.MAX_PLAYERS];
    private final float[] dodgeSoundGap = new float[GameConfig.MAX_PLAYERS];
    private boolean primed;
    private int lastPhase = -1;
    private int lastCountdownNumber = -1;

    public AudioDirector(GameState st) {
        this.st = st;
    }

    public void setSink(SoundSink s) {
        sink = s == null ? SoundSink.NONE : s;
    }

    // ------------------------------------------------------------------ events with a position

    public void shot(int weaponId, float x, float y) {
        sink.play(Sounds.shot(weaponId), x, y, 1f);
        // Pump, bolt or hammer: the mechanical action that follows the shot.
        int action = Sounds.action(weaponId);
        if (action >= 0) {
            sink.playDelayed(action, x, y, 0.85f, WeaponDef.byId(weaponId).actionDelay);
        }
    }

    public void projectileHit(int victimId, float x, float y) {
        sink.play(Sounds.HIT, x, y, 0.8f);
        if (victimId == st.localId) {
            Player me = st.local();
            sink.play(Sounds.HURT, me.rx, me.ry, 1f);
        }
    }

    public void wallImpact(float x, float y) {
        Player me = st.local();
        float dx = x - me.rx;
        float dy = y - me.ry;
        if (dx * dx + dy * dy > EARSHOT * EARSHOT) return;
        sink.play(Sounds.IMPACT, x, y, 0.5f);
    }

    public void kill(int killerId, int victimId, float x, float y) {
        sink.play(Sounds.KILL, x, y, 1f);
        Player me = st.local();
        if (victimId == st.localId) sink.play(Sounds.DEATH, me.rx, me.ry, 1f);
        else if (killerId == st.localId) sink.play(Sounds.CONFIRM, me.rx, me.ry, 1f);
    }

    // ------------------------------------------------------------------ events seen as state changes

    /** Call once per rendered frame, after the engine has updated the state. */
    public void update(float dt) {
        SoundSink out = sink;
        Player me = st.local();
        out.setListener(me.rx, me.ry);

        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            boolean local = i == st.localId;
            boolean alive = p.connected && p.alive;
            Weapon w = p.weapon;
            boolean reloading = alive && w.reloading;
            boolean rolling = alive && p.isRolling();
            int weapon = w.def.id;
            int ammo = w.ammo;
            if (dodgeSoundGap[i] > 0f) dodgeSoundGap[i] -= dt;
            if (primed) {
                boolean sameGun = weapon == lastWeapon[i];
                if (alive && !wasAlive[i]) {
                    out.play(Sounds.RESPAWN, p.rx, p.ry, local ? 1f : 0.6f);
                } else if (alive && !sameGun) {
                    // A different weapon in hand: it was picked up (or swapped for the one on the ground).
                    out.play(Sounds.PICKUP, p.rx, p.ry, local ? 1f : 0.7f);
                } else if (alive && ammo > lastAmmo[i] && !reloading && !wasReloading[i]) {
                    // Same gun, fuller magazine, no reload: took the same weapon off the ground to refill.
                    out.play(Sounds.PICKUP, p.rx, p.ry, local ? 1f : 0.7f);
                } else if (alive) {
                    float vol = local ? 1f : 0.65f;
                    // Reload, in step with what the gun really does: it starts, the ammunition comes
                    // back (new magazine seated / a shell in), and it is ready again.
                    if (reloading && !wasReloading[i]) {
                        out.play(Sounds.reloadStart(weapon), p.rx, p.ry, vol);
                    }
                    if ((reloading || wasReloading[i]) && ammo > lastAmmo[i]) {
                        out.play(Sounds.reloadLoad(weapon), p.rx, p.ry, vol);
                    }
                    if (!reloading && wasReloading[i] && ammo >= w.def.magSize
                            && lastReloadFraction[i] >= RELOAD_FINISHED) {
                        out.play(Sounds.reloadDone(weapon), p.rx, p.ry, vol);
                    }
                }
                if (rolling && !wasRolling[i] && dodgeSoundGap[i] <= 0f) {
                    out.play(Sounds.DODGE, p.rx, p.ry, local ? 1f : 0.8f);
                    dodgeSoundGap[i] = DODGE_SOUND_GAP;
                }
            }
            if (reloading) lastReloadFraction[i] = w.reloadFraction;
            wasAlive[i] = alive;
            wasReloading[i] = reloading;
            wasRolling[i] = rolling;
            lastWeapon[i] = weapon;
            lastAmmo[i] = ammo;
        }
        primed = true;

        int phase = st.phase;
        if (phase == GameState.PHASE_COUNTDOWN) {
            int number = (int) Math.ceil(st.countdown);
            if (number != lastCountdownNumber && number > 0) out.play(Sounds.COUNTDOWN, me.rx, me.ry, 0.9f);
            lastCountdownNumber = number;
        } else {
            lastCountdownNumber = -1;
        }
        if (phase != lastPhase) {
            if (lastPhase == GameState.PHASE_COUNTDOWN && phase == GameState.PHASE_PLAYING) {
                out.play(Sounds.GO, me.rx, me.ry, 1f);
            } else if (phase == GameState.PHASE_ENDED && lastPhase != GameState.PHASE_FINISHED) {
                out.play(st.winnerId == st.localId ? Sounds.WIN : Sounds.LOSE, me.rx, me.ry, 1f);
            }
            lastPhase = phase;
        }
    }
}
