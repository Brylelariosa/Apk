package com.hazardyard.game.ui;

import android.content.Context;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.hazardyard.game.render.Palette;
import com.hazardyard.game.settings.ControlSettings;
import com.hazardyard.game.settings.GameSettings;

/**
 * The Controls page: how the controls <em>work</em>. Fixed or floating sticks, how the gun fires (aim stick,
 * fire button or both, and how far the stick must be pushed), the aim dead zone, the aim line and the opacity
 * of the controls. It deliberately has nothing about where controls sit or how big they are: that is
 * Customize HUD. Every change is applied to the live settings at once, so it takes effect in a running match
 * the moment it is touched; the owner saves when the page closes.
 */
final class ControlsPanel {
    interface Callback {
        /** A setting changed (apply it to the running game). */
        void onChanged();

        /** Done was pressed. */
        void onDone();
    }

    private ControlsPanel() {}

    /** The panel with all control options; put it in a ScrollView. */
    static LinearLayout create(Context c, final GameSettings settings, final Callback cb) {
        final ControlSettings controls = settings.controls;
        LinearLayout panel = Ui.panel(c);
        panel.addView(Ui.label(c, "Controls", 22f, Palette.TEXT, true));
        panel.addView(Ui.label(c, "How the sticks and buttons work. To move or resize them, use Customize HUD.", 12f,
                Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));

        panel.addView(Ui.label(c, "Move stick", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 14));
        final SegmentedControl moveMode = new SegmentedControl(c, new String[] {"Fixed", "Floating"}, controls.moveFloating ? 1 : 0,
                new SegmentedControl.OnChange() {
                    @Override
                    public void onChange(int i) {
                        controls.moveFloating = i == 1;
                        cb.onChanged();
                    }
                });
        panel.addView(moveMode, Ui.fillWidth(c, 4));

        panel.addView(Ui.label(c, "Aim stick", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 12));
        final SegmentedControl aimMode = new SegmentedControl(c, new String[] {"Fixed", "Floating"}, controls.aimFloating ? 1 : 0,
                new SegmentedControl.OnChange() {
                    @Override
                    public void onChange(int i) {
                        controls.aimFloating = i == 1;
                        cb.onChanged();
                    }
                });
        panel.addView(aimMode, Ui.fillWidth(c, 4));
        panel.addView(Ui.label(c, "Fixed: the stick stays where you put it. Floating: it appears under your thumb.", 11f,
                Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));

        panel.addView(Ui.label(c, "Firing", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 14));
        final SliderRow fireLevel = new SliderRow(c, "Stick fires at", ControlSettings.FIRE_THRESHOLD_MIN,
                ControlSettings.FIRE_THRESHOLD_MAX, controls.fireThreshold, SliderRow.percent(), new SliderRow.OnValue() {
                    @Override
                    public void onValue(float v) {
                        controls.fireThreshold = v;
                        cb.onChanged();
                    }
                });
        final SegmentedControl fireMode = new SegmentedControl(c, new String[] {"Stick fires", "Button fires", "Both"},
                controls.fireMode, new SegmentedControl.OnChange() {
                    @Override
                    public void onChange(int i) {
                        controls.fireMode = i;
                        fireLevel.setSliderEnabled(controls.stickFires());
                        cb.onChanged();
                    }
                });
        panel.addView(fireMode, Ui.fillWidth(c, 4));
        panel.addView(Ui.label(c, "Stick fires: push the aim stick out to shoot. Button fires: the stick only aims and the "
                + "fire button shoots. Both: either one shoots.", 11f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));
        fireLevel.setSliderEnabled(controls.stickFires());
        panel.addView(fireLevel, Ui.fillWidth(c, 12));
        panel.addView(Ui.label(c, "How far the aim stick must be pushed before the gun fires (100% = all the way out). "
                + "Between the dead zone and this ring the stick only aims.", 11f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));

        final SliderRow deadZone = new SliderRow(c, "Aim dead zone", ControlSettings.DEAD_ZONE_MIN, ControlSettings.DEAD_ZONE_MAX,
                controls.aimDeadZone, SliderRow.percent(), new SliderRow.OnValue() {
                    @Override
                    public void onValue(float v) {
                        controls.aimDeadZone = v;
                        cb.onChanged();
                    }
                });
        panel.addView(deadZone, Ui.fillWidth(c, 12));

        panel.addView(Ui.label(c, "Aim line", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 12));
        final SegmentedControl aimLine = new SegmentedControl(c, new String[] {"On", "Off"}, settings.aimLine ? 0 : 1,
                new SegmentedControl.OnChange() {
                    @Override
                    public void onChange(int i) {
                        settings.aimLine = i == 0;
                        cb.onChanged();
                    }
                });
        panel.addView(aimLine, Ui.fillWidth(c, 4));
        panel.addView(Ui.label(c, "Shows where your gun points, as far as it reaches, while you aim.", 11f, Palette.TEXT_DIM, false),
                Ui.fillWidth(c, 4));

        final SliderRow opacity = new SliderRow(c, "Control opacity", ControlSettings.OPACITY_MIN, ControlSettings.OPACITY_MAX,
                controls.opacity, SliderRow.percent(), new SliderRow.OnValue() {
                    @Override
                    public void onValue(float v) {
                        controls.opacity = v;
                        cb.onChanged();
                    }
                });
        panel.addView(opacity, Ui.fillWidth(c, 12));

        Button reset = Ui.button(c, "Reset controls to default", false);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controls.resetOptions();          // behaviour only: the HUD layout is not touched
                settings.aimLine = true;
                moveMode.select(controls.moveFloating ? 1 : 0);
                aimMode.select(controls.aimFloating ? 1 : 0);
                fireMode.select(controls.fireMode);
                fireLevel.setValue(controls.fireThreshold);
                fireLevel.setSliderEnabled(controls.stickFires());
                deadZone.setValue(controls.aimDeadZone);
                aimLine.select(settings.aimLine ? 0 : 1);
                opacity.setValue(controls.opacity);
                cb.onChanged();
            }
        });
        panel.addView(reset, Ui.fillWidth(c, 14));

        Button done = Ui.button(c, "Done", true);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cb.onDone();
            }
        });
        panel.addView(done, Ui.fillWidth(c, 8));
        return panel;
    }
}
