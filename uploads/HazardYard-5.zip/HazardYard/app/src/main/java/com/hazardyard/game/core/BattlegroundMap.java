package com.hazardyard.game.core;

import java.util.ArrayDeque;
import java.util.Random;

/**
 * The Battleground arena: 120 x 80 tiles, roughly four times the area of the biggest classic map.
 * It is built in code, zone by zone, instead of being typed out as 9600 characters:
 *
 * <pre>
 *   Ruins        Bunker Hill     Factory
 *   Village      Old Town        Depot
 *   Harbour      Lake            Farm
 * </pre>
 *
 * Every zone has its own kind of fight: ruins and a watch tower for long shots, a walled keep, dense
 * town blocks and a plaza for close quarters, container lanes, a sea with piers, a lake with an island,
 * a tank farm, fenced fields. Canals have bridges and open ends, so there is always more than one way
 * between two places. The result is deterministic, and {@link #build()} finishes with a clean-up
 * pass: unreachable pockets are walled in and every spawn or weapon is moved onto the connected floor.
 */
final class BattlegroundMap {
    static final int W = 120;
    static final int H = 80;

    private final char[][] g = new char[H][W];
    private final Random rnd = new Random(0xB477L);

    /** Spawn points and weapon pads as (x, y, letter) triples, resolved against the finished terrain. */
    private final int[] marks = new int[3 * 160];
    private int markCount;

    private BattlegroundMap() {
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) g[y][x] = '.';
        }
    }

    static String[] build() {
        BattlegroundMap m = new BattlegroundMap();
        m.design();
        m.settle();
        String[] rows = new String[H];
        for (int y = 0; y < H; y++) rows[y] = new String(m.g[y]);
        return rows;
    }

    // ------------------------------------------------------------------ drawing helpers (inclusive corners)

    private void set(int x, int y, char c) {
        if (x > 0 && y > 0 && x < W - 1 && y < H - 1) g[y][x] = c;
    }

    private void fill(int x0, int y0, int x1, int y1, char c) {
        for (int y = y0; y <= y1; y++) {
            for (int x = x0; x <= x1; x++) set(x, y, c);
        }
    }

    private void frame(int x0, int y0, int x1, int y1, char c) {
        for (int x = x0; x <= x1; x++) {
            set(x, y0, c);
            set(x, y1, c);
        }
        for (int y = y0; y <= y1; y++) {
            set(x0, y, c);
            set(x1, y, c);
        }
    }

    /** Walls around an empty floor. */
    private void building(int x0, int y0, int x1, int y1) {
        fill(x0, y0, x1, y1, '.');
        frame(x0, y0, x1, y1, '#');
    }

    /** A doorway: opens floor tiles in a wall. */
    private void gap(int x0, int y0, int x1, int y1) {
        fill(x0, y0, x1, y1, '.');
    }

    private void crates(int x0, int y0, int x1, int y1) {
        fill(x0, y0, x1, y1, 'C');
    }

    private void tank(int x, int y) {
        set(x, y, 'T');
        set(x + 1, y, 'T');
        set(x, y + 1, 'T');
        set(x + 1, y + 1, 'T');
    }

    private void pillar(int x, int y) {
        set(x, y, 'O');
    }

    private void water(int x0, int y0, int x1, int y1) {
        fill(x0, y0, x1, y1, '~');
    }

    private void fence(int x0, int y0, int x1, int y1) {
        fill(x0, y0, x1, y1, '+');
    }

    private void spawn(int x, int y) {
        mark(x, y, 'S');
    }

    private void pick(int x, int y, char weapon) {
        mark(x, y, weapon);
    }

    private void mark(int x, int y, char c) {
        if (markCount * 3 + 2 >= marks.length) return;
        marks[markCount * 3] = x;
        marks[markCount * 3 + 1] = y;
        marks[markCount * 3 + 2] = c;
        markCount++;
    }

    /** Drops {@code count} single crates or pillars on open ground inside a region, never against a wall. */
    private void scatter(int x0, int y0, int x1, int y1, int count, char c) {
        int placed = 0;
        for (int tries = 0; tries < count * 40 && placed < count; tries++) {
            int x = x0 + rnd.nextInt(x1 - x0 + 1);
            int y = y0 + rnd.nextInt(y1 - y0 + 1);
            if (!openAround(x, y, 2)) continue;
            set(x, y, c);
            if (c == 'C' && rnd.nextInt(3) == 0 && openAround(x + 1, y, 2)) set(x + 1, y, c);
            placed++;
        }
    }

    private boolean openAround(int cx, int cy, int r) {
        for (int y = cy - r; y <= cy + r; y++) {
            for (int x = cx - r; x <= cx + r; x++) {
                if (x < 1 || y < 1 || x >= W - 1 || y >= H - 1) return false;
                if (g[y][x] != '.') return false;
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ the map

    private void design() {
        for (int x = 0; x < W; x++) {
            g[0][x] = '#';
            g[H - 1][x] = '#';
        }
        for (int y = 0; y < H; y++) {
            g[y][0] = '#';
            g[y][W - 1] = '#';
        }
        water();
        ruins();
        bunkerHill();
        factory();
        village();
        oldTown();
        depot();
        harbour();
        lake();
        farm();
        cover();
        spawns();
        weapons();
    }

    /** Canals, the sea and the east river (their crossings are carved afterwards). */
    private void water() {
        // Harbour canal with three bridges and an open east end.
        water(1, 51, 39, 52);
        gap(8, 51, 11, 52);
        gap(22, 51, 25, 52);
        gap(34, 51, 36, 52);
        // The sea in the south-west corner; piers are carved in harbour().
        water(1, 67, 34, 78);
        water(35, 70, 38, 78);
        // East river between the town and the depot / farm, three bridges.
        water(80, 29, 81, 53);
        gap(80, 34, 81, 37);
        gap(80, 42, 81, 45);
        gap(80, 49, 81, 51);
        water(80, 54, 81, 78);
        gap(80, 60, 81, 63);
        gap(80, 70, 81, 73);
    }

    private void ruins() {
        // Broken fort walls with ragged ends (angled pieces) and gaps to slip through.
        fill(6, 6, 14, 6, '#');
        fill(18, 6, 26, 6, '#');
        fill(6, 7, 6, 12, '#');
        fill(26, 7, 26, 11, '#');
        fill(6, 17, 11, 17, '#');
        fill(16, 17, 26, 17, '#');
        set(15, 6, '3');
        set(17, 6, '1');
        set(6, 13, '9');
        set(26, 12, '7');
        set(12, 17, '3');
        set(15, 17, '1');
        // A colonnade and rubble.
        for (int x = 10; x <= 22; x += 4) pillar(x, 21);
        for (int x = 8; x <= 24; x += 4) pillar(x, 24);
        crates(9, 10, 10, 11);
        crates(21, 9, 22, 10);
        crates(13, 13, 15, 13);
        // Watch tower for the long shots.
        building(31, 3, 36, 9);
        gap(33, 9, 34, 9);
        gap(31, 6, 31, 6);
        pillar(33, 5);
        // Collapsed house.
        fill(3, 20, 3, 25, '#');
        fill(3, 20, 5, 20, '#');
        crates(4, 23, 5, 24);
    }

    private void bunkerHill() {
        // Walled compound with four gates, towers in the corners and a keep in the middle.
        frame(46, 4, 73, 19, '#');
        gap(58, 4, 61, 4);
        gap(58, 19, 61, 19);
        gap(46, 10, 46, 13);
        gap(73, 10, 73, 13);
        building(47, 5, 51, 9);
        gap(51, 7, 51, 8);
        building(68, 5, 72, 9);
        gap(68, 7, 68, 8);
        building(47, 14, 51, 18);
        gap(51, 15, 51, 16);
        building(68, 14, 72, 18);
        gap(68, 15, 68, 16);
        building(54, 8, 65, 15);
        gap(54, 11, 54, 12);
        gap(65, 11, 65, 12);
        gap(59, 15, 60, 15);
        pillar(56, 10);
        pillar(63, 10);
        pillar(56, 13);
        pillar(63, 13);
        // Trenches in front of the south gate.
        fence(43, 22, 55, 22);
        fence(64, 22, 76, 22);
        crates(57, 17, 58, 17);
        crates(61, 17, 62, 17);
    }

    private void factory() {
        // Hall A with conveyor lines (low fences: shoot over them, cannot walk through).
        building(84, 4, 100, 16);
        gap(84, 9, 84, 10);
        gap(90, 16, 91, 16);
        gap(100, 9, 100, 10);
        gap(92, 4, 93, 4);
        fence(87, 8, 97, 8);
        fence(87, 12, 97, 12);
        crates(86, 6, 87, 6);
        crates(97, 14, 98, 14);
        pillar(90, 10);
        pillar(94, 10);
        // Hall B.
        building(104, 4, 116, 12);
        gap(104, 7, 104, 8);
        gap(108, 12, 109, 12);
        crates(112, 6, 114, 6);
        pillar(108, 9);
        pillar(112, 9);
        // Tank farm and a toxic pool.
        for (int x = 86; x <= 110; x += 6) tank(x, 20);
        fence(84, 18, 116, 18);
        gap(89, 18, 90, 18);
        gap(101, 18, 102, 18);
        water(88, 25, 100, 27);
        crates(104, 25, 106, 26);
    }

    private void village() {
        building(4, 30, 11, 37);
        gap(7, 37, 8, 37);
        gap(11, 33, 11, 34);
        building(15, 30, 24, 39);
        gap(15, 34, 15, 35);
        gap(24, 34, 24, 35);
        gap(19, 39, 20, 39);
        building(28, 31, 35, 37);
        gap(31, 37, 32, 37);
        gap(28, 34, 28, 34);
        building(4, 42, 10, 48);
        gap(6, 42, 7, 42);
        gap(10, 45, 10, 46);
        building(14, 43, 22, 48);
        gap(17, 43, 18, 43);
        gap(22, 45, 22, 46);
        building(27, 42, 36, 48);
        gap(27, 45, 27, 46);
        gap(31, 42, 32, 42);
        // Garden fences and a well.
        fence(12, 39, 14, 39);
        fence(25, 40, 25, 47);
        gap(25, 44, 25, 45);
        pillar(12, 41);
        pillar(13, 41);
        pillar(12, 42);
        crates(29, 39, 30, 39);
    }

    private void oldTown() {
        // City blocks around a plaza; the streets between them are four to five tiles wide.
        building(44, 27, 53, 34);
        gap(53, 30, 53, 31);
        gap(47, 34, 48, 34);
        building(44, 40, 53, 48);
        gap(47, 40, 48, 40);
        gap(53, 43, 53, 44);
        building(67, 27, 76, 34);
        gap(67, 30, 67, 31);
        gap(71, 34, 72, 34);
        building(67, 40, 76, 48);
        gap(71, 40, 72, 40);
        gap(67, 43, 67, 44);
        building(56, 26, 60, 30);
        gap(57, 30, 58, 30);
        building(62, 26, 65, 30);
        gap(63, 30, 64, 30);
        building(57, 45, 65, 49);
        gap(60, 45, 61, 45);
        // Plaza: a monument tank ringed by pillars, with low fence arcs.
        tank(59, 36);
        pillar(57, 34);
        pillar(62, 34);
        pillar(57, 40);
        pillar(62, 40);
        fence(55, 37, 55, 38);
        fence(64, 37, 64, 38);
        crates(54, 36, 54, 36);
        crates(66, 38, 66, 38);
    }

    private void depot() {
        // Container yard: staggered runs form lanes with sharp corners.
        int row = 0;
        for (int y = 33; y <= 49; y += 4) {
            int off = (row++ % 2) * 3;
            crates(84 + off, y, 89 + off, y + 1);
            crates(93 + off, y, 96 + off, y + 1);
            crates(100 + off, y, 103 + off, y + 1);
        }
        building(106, 34, 116, 46);
        gap(106, 39, 106, 40);
        gap(110, 46, 111, 46);
        gap(116, 38, 116, 38);
        crates(108, 36, 109, 37);
        pillar(112, 42);
        pillar(112, 38);
        // Rail line along the north edge of the depot.
        fence(84, 30, 104, 30);
        gap(92, 30, 93, 30);
        gap(100, 30, 101, 30);
    }

    private void harbour() {
        // Warehouses on the quay, container stacks, fuel tanks.
        building(4, 54, 16, 61);
        gap(9, 54, 10, 54);
        gap(9, 61, 10, 61);
        gap(16, 57, 16, 58);
        building(22, 54, 34, 60);
        gap(27, 54, 28, 54);
        gap(27, 60, 28, 60);
        gap(22, 56, 22, 57);
        crates(6, 56, 8, 57);
        crates(24, 57, 26, 58);
        crates(18, 62, 20, 63);
        crates(36, 61, 38, 62);
        tank(36, 55);
        tank(36, 58);
        // Piers into the sea, each ending in a stack of containers.
        for (int x = 4; x <= 28; x += 8) {
            fill(x, 66, x + 2, 76, '.');
            crates(x, 75, x + 2, 76);
            fill(x + 1, 66, x + 1, 66, '.');
        }
        fill(2, 64, 34, 65, '.');
        pillar(12, 64);
        pillar(20, 64);
        pillar(28, 64);
        pillar(5, 64);
    }

    private void lake() {
        water(51, 60, 69, 74);
        water(48, 63, 72, 71);
        water(49, 61, 71, 73);
        // Island with a ruined temple, reached by three bridges.
        fill(56, 64, 64, 70, '.');
        gap(50, 66, 55, 67);
        gap(65, 66, 70, 67);
        gap(59, 59, 60, 63);
        fill(56, 64, 64, 64, '#');
        fill(56, 70, 64, 70, '#');
        gap(59, 64, 60, 64);
        gap(59, 70, 60, 70);
        fill(56, 65, 56, 69, '#');
        gap(56, 66, 56, 67);
        fill(64, 65, 64, 69, '#');
        gap(64, 66, 64, 67);
        pillar(58, 67);
        pillar(62, 67);
        // Boat houses on the shore.
        building(44, 76, 50, 77);
        crates(54, 76, 56, 77);
        fence(40, 56, 46, 56);
        fence(46, 56, 46, 59);
        fence(74, 56, 80, 56);
        fence(74, 56, 74, 59);
    }

    private void farm() {
        // Fenced fields with haystacks (crates).
        frame(86, 56, 100, 66, '+');
        gap(92, 56, 94, 56);
        gap(86, 61, 86, 62);
        gap(100, 61, 100, 62);
        frame(103, 56, 116, 66, '+');
        gap(108, 66, 110, 66);
        gap(103, 60, 103, 61);
        crates(90, 60, 91, 61);
        crates(96, 63, 97, 64);
        crates(107, 59, 108, 60);
        crates(112, 62, 113, 63);
        // Barn, farmhouse, silos.
        building(90, 69, 104, 76);
        gap(95, 69, 98, 69);
        gap(90, 72, 90, 73);
        gap(104, 72, 104, 73);
        crates(93, 73, 95, 74);
        pillar(100, 72);
        building(108, 69, 115, 75);
        gap(108, 72, 108, 73);
        gap(111, 69, 112, 69);
        tank(84, 69);
        tank(84, 73);
        tank(86, 76);
    }

    /** Loose cover on the open ground between the zones. */
    private void cover() {
        scatter(40, 2, 45, 25, 6, 'C');
        scatter(2, 26, 38, 29, 4, 'O');
        scatter(40, 26, 43, 52, 8, 'C');
        scatter(77, 2, 82, 28, 6, 'C');
        scatter(54, 50, 70, 56, 7, 'C');
        scatter(40, 53, 46, 76, 6, 'O');
        scatter(74, 54, 79, 76, 6, 'C');
        scatter(2, 2, 40, 5, 4, 'O');
        scatter(44, 20, 76, 25, 8, 'C');
        scatter(84, 52, 117, 55, 5, 'C');
        scatter(100, 20, 117, 24, 4, 'O');
    }

    private void spawns() {
        int[][] s = {
            {3, 3}, {39, 2}, {44, 2}, {78, 2}, {82, 2}, {117, 2},
            {2, 27}, {41, 28}, {41, 50}, {78, 27}, {83, 31}, {118, 28},
            {2, 53}, {41, 53}, {78, 55}, {83, 54}, {118, 54},
            {38, 64}, {43, 78}, {78, 77}, {118, 77}, {2, 65},
            {40, 24}, {79, 25},
        };
        for (int[] p : s) spawn(p[0], p[1]);
    }

    private void weapons() {
        // Ruins and the watch tower: long guns and a magnum.
        pick(33, 6, 'N');
        pick(16, 10, 'R');
        pick(10, 14, 'G');
        // Bunker Hill: the prize in the keep, rifles in the towers.
        pick(59, 11, 'P');
        pick(60, 12, 'K');
        pick(49, 7, 'R');
        pick(70, 16, 'G');
        // Factory.
        pick(92, 10, 'K');
        pick(90, 14, 'M');
        pick(110, 8, 'P');
        pick(95, 22, 'R');
        // Village.
        pick(7, 34, 'M');
        pick(20, 35, 'G');
        pick(32, 34, 'N');
        pick(8, 45, 'V');
        pick(18, 46, 'R');
        // Old Town.
        pick(48, 31, 'G');
        pick(72, 31, 'M');
        pick(48, 44, 'R');
        pick(72, 44, 'V');
        pick(60, 41, 'K');
        // Depot.
        pick(110, 40, 'P');
        pick(98, 40, 'M');
        // Harbour and lake.
        pick(10, 58, 'G');
        pick(29, 57, 'K');
        pick(6, 74, 'N');
        pick(30, 74, 'R');
        pick(60, 67, 'N');
        pick(61, 69, 'V');
        // Farm.
        pick(97, 73, 'G');
        pick(111, 72, 'M');
        pick(106, 63, 'N');
    }

    // ------------------------------------------------------------------ clean-up

    private static final int[] DX = {1, -1, 0, 0};
    private static final int[] DY = {0, 0, 1, -1};

    private boolean floorAt(int x, int y) {
        return x >= 0 && y >= 0 && x < W && y < H && g[y][x] == '.';
    }

    /** Wall in every floor pocket the main ground cannot reach, then place the marks on connected floor. */
    private void settle() {
        // The biggest floor region is the playable one.
        int[] label = new int[W * H];
        int best = 0, bestSize = 0, regions = 0;
        ArrayDeque<Integer> q = new ArrayDeque<>();
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (!floorAt(x, y) || label[y * W + x] != 0) continue;
                regions++;
                int size = 0;
                label[y * W + x] = regions;
                q.add(y * W + x);
                while (!q.isEmpty()) {
                    int c = q.poll();
                    size++;
                    int cx = c % W, cy = c / W;
                    for (int d = 0; d < 4; d++) {
                        int nx = cx + DX[d], ny = cy + DY[d];
                        if (floorAt(nx, ny) && label[ny * W + nx] == 0) {
                            label[ny * W + nx] = regions;
                            q.add(ny * W + nx);
                        }
                    }
                }
                if (size > bestSize) {
                    bestSize = size;
                    best = regions;
                }
            }
        }
        for (int y = 0; y < H; y++) {
            for (int x = 0; x < W; x++) {
                if (floorAt(x, y) && label[y * W + x] != best) g[y][x] = '#';
            }
        }
        // Marks: nearest free connected floor tile, never two marks on one tile.
        for (int i = 0; i < markCount; i++) {
            int x = marks[i * 3], y = marks[i * 3 + 1];
            char c = (char) marks[i * 3 + 2];
            int[] at = nearestFree(x, y);
            if (at != null) g[at[1]][at[0]] = c;
        }
    }

    private int[] nearestFree(int x, int y) {
        for (int r = 0; r < 12; r++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    if (Math.max(Math.abs(dx), Math.abs(dy)) != r) continue;
                    int nx = x + dx, ny = y + dy;
                    if (!floorAt(nx, ny)) continue;
                    // Keep pads off tiles that touch another pad or spawn.
                    boolean crowded = false;
                    for (int ty = ny - 1; ty <= ny + 1 && !crowded; ty++) {
                        for (int tx = nx - 1; tx <= nx + 1; tx++) {
                            if (tx < 0 || ty < 0 || tx >= W || ty >= H) continue;
                            char t = g[ty][tx];
                            if (t == 'S' || TileMap.weaponForLetter(t) >= 0) {
                                crowded = true;
                                break;
                            }
                        }
                    }
                    if (!crowded) return new int[] {nx, ny};
                }
            }
        }
        return null;
    }
}
