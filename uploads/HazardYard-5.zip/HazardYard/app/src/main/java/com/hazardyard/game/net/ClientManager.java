package com.hazardyard.game.net;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * Client side of the LAN game: one thread connects and then reads, one thread writes (and pings once
 * a second). Lobby messages are handled here and reported through {@link Listener}; gameplay messages
 * are queued for the game thread.
 */
public final class ClientManager extends NetworkManager {
    public interface Listener {
        void onConnected(int playerId);

        void onLobbyChanged();

        void onRejected(int reason);

        void onMatchStart();

        void onReturnToLobby();

        void onDisconnected(String reason);
    }

    private static final byte[] POISON = new byte[0];
    private static final int CONNECT_TIMEOUT_MS = 3000;
    private static final int READ_TIMEOUT_MS = 6000;
    private static final int MAX_QUEUE = 2000;

    private final LobbyManager lobby = new LobbyManager();
    private final LinkedBlockingQueue<byte[]> queue = new LinkedBlockingQueue<>();
    private volatile Listener listener;
    private volatile Socket socket;
    private volatile int myId = -1;
    private volatile boolean closed;
    private volatile boolean intentional;
    private volatile boolean inMatch;
    private volatile boolean returnedToLobby;
    private boolean reported; // guarded by this

    public LobbyManager lobby() {
        return lobby;
    }

    public void setListener(Listener l) {
        listener = l;
    }

    /** Connects asynchronously; progress and failure are reported through the listener. */
    public void connect(final String host, final int port, final String playerName, Listener l) {
        listener = l;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                runConnection(host, port, playerName);
            }
        }, "hy-client-read");
        t.setDaemon(true);
        t.start();
    }

    private void runConnection(String host, int port, String playerName) {
        DataInputStream in;
        try {
            Socket s = new Socket();
            s.setTcpNoDelay(true);
            s.setKeepAlive(true);
            s.connect(new InetSocketAddress(host, port), CONNECT_TIMEOUT_MS);
            s.setSoTimeout(READ_TIMEOUT_MS);
            if (intentional) {
                s.close();
                return;
            }
            socket = s;
            in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 4096));
            final BufferedOutputStream out = new BufferedOutputStream(s.getOutputStream(), 2048);
            Thread writer = new Thread(new Runnable() {
                @Override
                public void run() {
                    writeLoop(out);
                }
            }, "hy-client-write");
            writer.setDaemon(true);
            writer.start();
            queue.offer(new PacketWriter(32).begin(Protocol.C_HELLO).u8(Protocol.VERSION)
                    .str(Protocol.sanitizeName(playerName)).finishFrame());
        } catch (IOException | RuntimeException e) {
            fail("Could not connect to " + host + ":" + port);
            return;
        }
        PacketReader reader = new PacketReader();
        try {
            while (!closed) {
                byte[] d = Protocol.readFrame(in);
                handle(d, reader);
            }
        } catch (IOException e) {
            fail(closed ? "Disconnected" : "Connection to the host was lost");
        } catch (RuntimeException e) {
            fail("Received invalid data from the host");
        }
    }

    private void handle(byte[] d, PacketReader r) {
        int type = d[0] & 0xFF;
        Listener l = listener;
        switch (type) {
            case Protocol.S_WELCOME:
                myId = d[1] & 0xFF;
                if (l != null) l.onConnected(myId);
                break;
            case Protocol.S_REJECT:
                synchronized (this) {
                    reported = true;
                }
                if (l != null) l.onRejected(d.length > 1 ? d[1] & 0xFF : 0);
                closeSocket();
                break;
            case Protocol.S_LOBBY:
                lobby.read(r.wrap(d, 1, d.length - 1));
                if (l != null) l.onLobbyChanged();
                break;
            case Protocol.S_START:
                lobby.read(r.wrap(d, 1, d.length - 1));
                clearInbound();
                returnedToLobby = false;
                inMatch = true;
                if (l != null) l.onMatchStart();
                break;
            case Protocol.S_TO_LOBBY:
                inMatch = false;
                returnedToLobby = true;
                if (l != null) l.onReturnToLobby();
                break;
            case Protocol.S_PONG:
                if (d.length >= 5) {
                    int echoed = ((d[1] & 0xFF) << 24) | ((d[2] & 0xFF) << 16) | ((d[3] & 0xFF) << 8) | (d[4] & 0xFF);
                    pingMs = Math.max(0, (int) System.currentTimeMillis() - echoed);
                }
                break;
            case Protocol.S_SNAPSHOT:
            case Protocol.S_FIRE:
            case Protocol.S_HIT:
            case Protocol.S_KILL:
                if (inMatch) enqueue(new Inbound(-1, d));
                break;
            default:
                break;
        }
    }

    private void writeLoop(BufferedOutputStream out) {
        long nextPing = System.currentTimeMillis() + 1000;
        try {
            while (!closed) {
                long wait = nextPing - System.currentTimeMillis();
                byte[] f = wait > 0 ? queue.poll(wait, TimeUnit.MILLISECONDS) : null;
                if (f == POISON) break;
                if (f != null) out.write(f);
                long now = System.currentTimeMillis();
                if (now >= nextPing) {
                    out.write(new PacketWriter(8).begin(Protocol.C_PING).i32((int) now).finishFrame());
                    nextPing = now + 1000;
                }
                if (queue.isEmpty()) out.flush();
            }
        } catch (IOException | InterruptedException e) {
            fail("Connection to the host was lost");
        } finally {
            closeSocket();
        }
    }

    // ------------------------------------------------------------------ sending

    public void send(byte[] frame) {
        if (closed) return;
        if (queue.size() > MAX_QUEUE) {
            fail("Connection too slow");
            return;
        }
        queue.offer(frame);
    }

    public void sendReady(boolean ready) {
        send(new PacketWriter(8).begin(Protocol.C_READY).u8(ready ? 1 : 0).finishFrame());
    }

    public void sendReload() {
        send(new PacketWriter(8).begin(Protocol.C_RELOAD).finishFrame());
    }

    /** Presses Pick Up: asks the host for the weapon on pad {@code padIndex} (or the nearest one when negative). */
    public void sendPickup(int padIndex) {
        send(new PacketWriter(8).begin(Protocol.C_PICKUP).u8(padIndex < 0 || padIndex > 254 ? 255 : padIndex).finishFrame());
    }

    /** Asks the host for a dodge roll; {@code angle16} is the direction as a 16-bit turn ({@code MathUtil.angleToU16}). */
    public void sendDodge(int angle16) {
        send(new PacketWriter(8).begin(Protocol.C_DODGE).u16(angle16).finishFrame());
    }

    // ------------------------------------------------------------------ state

    public boolean isInMatch() {
        return inMatch;
    }

    /** True once after the host sent everybody back to the lobby. */
    public boolean consumeReturnToLobby() {
        boolean r = returnedToLobby;
        returnedToLobby = false;
        return r;
    }

    private void fail(String reason) {
        boolean report;
        synchronized (this) {
            report = !reported && !intentional;
            reported = true;
        }
        closeSocket();
        Listener l = listener;
        if (report && l != null) l.onDisconnected(reason);
    }

    private void closeSocket() {
        closed = true;
        queue.offer(POISON);
        Socket s = socket;
        if (s != null) {
            try {
                s.close();
            } catch (IOException ignored) {
                // nothing more to do
            }
        }
    }

    @Override
    public boolean isHost() {
        return false;
    }

    @Override
    public int localPlayerId() {
        return myId;
    }

    @Override
    public boolean isClosed() {
        return closed;
    }

    /** Leaves the game. The host notices the closed connection and frees the slot. */
    @Override
    public void close() {
        intentional = true;
        closeSocket();
        clearInbound();
    }
}
