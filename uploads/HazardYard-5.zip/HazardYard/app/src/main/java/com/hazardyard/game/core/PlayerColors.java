package com.hazardyard.game.core;

/** One distinct colour per player slot (ARGB), shared by the world renderer, HUD and lobby. */
public final class PlayerColors {
    private PlayerColors() {}

    public static final int[] ARGB = {
        0xFFFF5A5F, // coral
        0xFF2EC4E6, // cyan
        0xFF8FD14F, // lime
        0xFFB48CFF, // violet
        0xFFFFB347, // amber (bots and extra fighters from here on)
        0xFFFF86C8, // pink
        0xFF3DF2B0, // mint
        0xFFF5F0DC, // cream
    };

    public static int of(int slot) {
        return ARGB[((slot % ARGB.length) + ARGB.length) % ARGB.length];
    }
}
