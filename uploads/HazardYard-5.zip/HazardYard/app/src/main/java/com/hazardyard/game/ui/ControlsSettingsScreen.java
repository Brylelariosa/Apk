package com.hazardyard.game.ui;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.hazardyard.game.render.Palette;

/** The Controls page opened from Settings (in a match it opens over the pause menu instead). */
final class ControlsSettingsScreen implements Screen {
    private final Navigator nav;
    private final FrameLayout root;
    private final ScreenPadding padding;

    ControlsSettingsScreen(Context c, Navigator navigator) {
        nav = navigator;
        root = new FrameLayout(c);
        root.addView(new BackdropView(c), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        padding = new ScreenPadding(content, c, 40, 24, 40, 24);
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout hero = Ui.column(c);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(hero, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 24, 0, c));
        hero.addView(Ui.label(c, "Controls", 44f, Palette.TEXT, true));
        hero.addView(new BackdropView.StripeBar(c), Ui.lp(Ui.dp(c, 130), Ui.dp(c, 9), 0f, 0, 10, 0, 0, c));
        hero.addView(Ui.label(c, "Choose how aiming and firing work: fixed or floating sticks, a fire button, "
                + "how far the stick must be pushed, and the dead zone.", 15f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 14));

        ScrollView scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        content.addView(scroll, Ui.lp(Ui.dp(c, 360), ViewGroup.LayoutParams.MATCH_PARENT, 0f, 0, 0, 0, 0, c));
        LinearLayout panel = ControlsPanel.create(c, navigator.settings(), new ControlsPanel.Callback() {
            @Override
            public void onChanged() {
                // nothing is running; the values are saved when the page closes
            }

            @Override
            public void onDone() {
                nav.saveSettings();
                nav.showSettings();
            }
        });
        scroll.addView(panel, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShow() {
        // nothing to start
    }

    @Override
    public void onHide() {
        nav.saveSettings();
    }

    @Override
    public boolean onBack() {
        nav.saveSettings();
        nav.showSettings();
        return true;
    }

    @Override
    public void onInsets(int l, int t, int r, int b) {
        padding.apply(l, t, r, b);
    }
}
