package com.hazardyard.game.settings;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.MathUtil;

/**
 * Where the on-screen controls and HUD elements sit, how big they are, and how the controls behave.
 * Pure data (no Android types) so the routing rules that depend on it can be tested on a plain JVM.
 *
 * <p>Two separate things live here, and the game keeps them apart in the UI:
 * <ul>
 *   <li><b>HUD layout</b> (position and size of every element): edited in <em>Customize HUD</em>, see
 *       {@link #resetLayout()}. It covers the touch controls ({@link #MOVE}..{@link #PICKUP}) and the
 *       information widgets ({@link #MINIMAP}..{@link #FEED}).</li>
 *   <li><b>Control options</b> (how input works: fixed or floating sticks, how the gun fires, dead zone,
 *       opacity): edited on the <em>Controls</em> screen, see {@link #resetOptions()}.</li>
 * </ul>
 *
 * <p>Positions are normalised: 0..1 across the usable screen area (the screen minus the display
 * cutout and system bars), so a layout survives different resolutions and aspect ratios.
 */
public final class ControlSettings {
    public static final int MOVE = 0;
    public static final int AIM = 1;
    public static final int FIRE = 2;
    public static final int RELOAD = 3;
    public static final int PAUSE = 4;
    public static final int DODGE = 5;
    /** The Pick Up button: only shown while a weapon is within reach. */
    public static final int PICKUP = 6;
    /** Number of touch controls (the ids above): these take touches. */
    public static final int CONTROL_COUNT = 7;
    // HUD widgets: drawn on the screen, they do not take touches, but they can be moved and resized.
    public static final int MINIMAP = 7;
    /** Match timer and the scores of the fighters. */
    public static final int SCORE = 8;
    /** Ammunition and weapon name. */
    public static final int AMMO = 9;
    public static final int HEALTH = 10;
    /** The kill feed. */
    public static final int FEED = 11;
    /** Number of HUD elements in total (touch controls and widgets): the size of the layout arrays. */
    public static final int COUNT = 12;

    /** Pushing the aim stick out to the fire level fires; there is no fire button. */
    public static final int FIRE_STICK = 0;
    /** The aim stick only aims (it never fires); the fire button shoots. */
    public static final int FIRE_BUTTON = 1;
    /** Both of the above work at the same time. */
    public static final int FIRE_BOTH = 2;

    public static final float SCALE_MIN = 0.6f;
    public static final float SCALE_MAX = 1.8f;
    public static final float DEAD_ZONE_MIN = 0.10f;
    public static final float DEAD_ZONE_MAX = 0.70f;
    /** Range of the "stick fires at" setting (1 = the stick has to be pushed all the way out). */
    public static final float FIRE_THRESHOLD_MIN = 0.30f;
    public static final float FIRE_THRESHOLD_MAX = 1.00f;
    public static final float OPACITY_MIN = 0.25f;
    public static final float OPACITY_MAX = 1.0f;

    private static final float[] DEFAULT_X = {0.140f, 0.860f, 0.740f, 0.935f, 0.948f, 0.840f, 0.675f,
            0.105f, 0.500f, 0.945f, 0.500f, 0.135f};
    private static final float[] DEFAULT_Y = {0.740f, 0.740f, 0.500f, 0.356f, 0.117f, 0.455f, 0.775f,
            0.165f, 0.095f, 0.515f, 0.945f, 0.450f};
    private static final String[] NAMES = {"Move stick", "Aim stick", "Fire button", "Reload button", "Pause button",
            "Dodge button", "Pick Up button", "Minimap", "Timer & scores", "Ammo", "Health bar", "Kill feed"};

    /** Control centres, 0..1 across the usable width / height. */
    public final float[] x = new float[COUNT];
    public final float[] y = new float[COUNT];
    /** Size multiplier per control, {@link #SCALE_MIN}..{@link #SCALE_MAX}. */
    public final float[] scale = new float[COUNT];

    /** True: the move stick appears wherever the thumb lands. False: it stays where it is drawn. */
    public boolean moveFloating;
    public boolean aimFloating;
    public int fireMode;
    /** Aim stick deflection (0..1) at which the player starts aiming. */
    public float aimDeadZone;
    /**
     * Aim stick deflection (0..1) at which the gun starts firing, when the stick fires. Between the
     * dead zone and this point the stick only aims, so the player can line up a shot without shooting.
     */
    public float fireThreshold;
    /** Overall control opacity. */
    public float opacity;

    public ControlSettings() {
        reset();
    }

    /** Back to the factory state: default layout and default control options. */
    public void reset() {
        resetLayout();
        resetOptions();
    }

    /** Puts every HUD element (controls and widgets) back at its default position and size. Options are untouched. */
    public void resetLayout() {
        for (int i = 0; i < COUNT; i++) {
            x[i] = DEFAULT_X[i];
            y[i] = DEFAULT_Y[i];
            scale[i] = 1f;
        }
    }

    /** Fixed sticks, the aim stick fires, default dead zone and opacity. The HUD layout is untouched. */
    public void resetOptions() {
        moveFloating = false;
        aimFloating = false;
        fireMode = FIRE_STICK;
        aimDeadZone = GameConfig.AIM_DEAD_ZONE;
        fireThreshold = GameConfig.FIRE_THRESHOLD;
        opacity = 0.85f;
    }

    public void copyFrom(ControlSettings o) {
        for (int i = 0; i < COUNT; i++) {
            x[i] = o.x[i];
            y[i] = o.y[i];
            scale[i] = o.scale[i];
        }
        moveFloating = o.moveFloating;
        aimFloating = o.aimFloating;
        fireMode = o.fireMode;
        aimDeadZone = o.aimDeadZone;
        fireThreshold = o.fireThreshold;
        opacity = o.opacity;
    }

    /** Copies only the layout (positions and sizes), not the control options. */
    public void copyLayoutFrom(ControlSettings o) {
        for (int i = 0; i < COUNT; i++) {
            x[i] = o.x[i];
            y[i] = o.y[i];
            scale[i] = o.scale[i];
        }
    }

    /** True for the ids that take touches (sticks and buttons); false for the information widgets. */
    public static boolean isControl(int element) {
        return element >= 0 && element < CONTROL_COUNT;
    }

    public ControlSettings copy() {
        ControlSettings c = new ControlSettings();
        c.copyFrom(this);
        return c;
    }

    /** Pulls every value back into its valid range (settings may come from an old or damaged file). */
    public void sanitize() {
        for (int i = 0; i < COUNT; i++) {
            x[i] = MathUtil.isFinite(x[i]) ? MathUtil.clamp(x[i], 0f, 1f) : DEFAULT_X[i];
            y[i] = MathUtil.isFinite(y[i]) ? MathUtil.clamp(y[i], 0f, 1f) : DEFAULT_Y[i];
            scale[i] = MathUtil.isFinite(scale[i]) ? MathUtil.clamp(scale[i], SCALE_MIN, SCALE_MAX) : 1f;
        }
        fireMode = MathUtil.clamp(fireMode, FIRE_STICK, FIRE_BOTH);
        aimDeadZone = MathUtil.isFinite(aimDeadZone)
                ? MathUtil.clamp(aimDeadZone, DEAD_ZONE_MIN, DEAD_ZONE_MAX) : GameConfig.AIM_DEAD_ZONE;
        fireThreshold = MathUtil.isFinite(fireThreshold)
                ? MathUtil.clamp(fireThreshold, FIRE_THRESHOLD_MIN, FIRE_THRESHOLD_MAX) : GameConfig.FIRE_THRESHOLD;
        opacity = MathUtil.isFinite(opacity) ? MathUtil.clamp(opacity, OPACITY_MIN, OPACITY_MAX) : 0.85f;
    }

    /** The fire button exists (and is drawn) in these modes. */
    public boolean fireButtonEnabled() {
        return fireMode != FIRE_STICK;
    }

    /** Pushing the aim stick out to the fire level fires in these modes. */
    public boolean stickFires() {
        return fireMode != FIRE_BUTTON;
    }

    /**
     * The stick deflection at which firing really starts: the chosen threshold, but never inside the
     * aim dead zone (a stick cannot fire before it aims).
     */
    public float fireStartLevel() {
        return Math.max(fireThreshold, Math.min(1f, aimDeadZone + 0.05f));
    }

    public static String nameOf(int element) {
        return element >= 0 && element < COUNT ? NAMES[element] : "";
    }

    public static float defaultX(int element) {
        return DEFAULT_X[element];
    }

    public static float defaultY(int element) {
        return DEFAULT_Y[element];
    }
}
