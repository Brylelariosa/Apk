package com.hazardyard.game.bot;

import com.hazardyard.game.core.GameConfig;

/**
 * A* over the tile grid (8 directions, no corner cutting) followed by line-of-sight smoothing, so
 * bots walk straight lines where they can instead of tile by tile. The instance owns the scratch
 * arrays, so searching never allocates. The finished route is left in {@link #wx}/{@link #wy}.
 *
 * <p>A search can run in one go ({@link #find}) or be spread over several game ticks
 * ({@link #begin} then {@link #advance} with a work budget per call): on the huge Battleground map a long
 * search is a few milliseconds of work, which is a dropped frame on a phone if it happens all at once.
 */
public final class PathFinder {
    public static final int MAX_WAYPOINTS = 160;
    /** How many tiles of the raw route the smoothing looks ahead when it searches for the next visible waypoint. */
    private static final int SMOOTH_LOOKAHEAD = 28;
    /** Waypoints the smoothing produces per {@link #advance} call. */
    private static final int SMOOTH_PER_STEP = 6;
    private static final float DIAGONAL = 1.41421356f;
    private static final float NEAR_WALL_COST = 0.45f;
    /**
     * The search is "weighted" A*: the estimate to the goal counts a little extra, so on big open maps it
     * heads for the goal instead of flooding the whole neighbourhood. Routes can be a few percent longer than
     * the optimum, which the smoothing step mostly hides, and a search costs a fraction of the time.
     */
    private static final float HEURISTIC_WEIGHT = 1.35f;
    /** Safety valve: a search that has expanded this many tiles gives up and walks to the closest tile it reached. */
    private static final int MAX_EXPANSIONS = 6000;
    private static final int[] DX = {1, -1, 0, 0, 1, 1, -1, -1};
    private static final int[] DY = {0, 0, 1, -1, 1, -1, 1, -1};

    private static final int IDLE = 0;
    private static final int SEARCHING = 1;
    private static final int SMOOTHING = 2;
    private static final int DONE = 3;
    private static final int FAILED = 4;

    private final NavGrid nav;
    private final int n;
    private final float[] g;
    private final int[] parent;
    private final int[] stamp;
    private final boolean[] closed;
    private final float[] nearWall;
    private int token;

    private final int[] heapNode;
    private final float[] heapKey;
    private int heapSize;

    private final int[] chain;

    /** Smoothed route: waypoints 0..count-1, the last one is the goal. */
    public final float[] wx = new float[MAX_WAYPOINTS];
    public final float[] wy = new float[MAX_WAYPOINTS];
    public int count;
    /** True when the last waypoint is the goal; false when the route was cut short (too long, or the search ran out of budget). */
    public boolean complete;

    // state of the search in progress
    private int phase = IDLE;
    private float startX, startY, goalPx, goalPy, radius;
    private int startTile, goalTile, goalX, goalY;
    private int expanded, closest;
    private float closestH;
    private boolean found;
    private int chainLen, smoothI;
    private float curX, curY;

    public PathFinder(NavGrid nav) {
        this.nav = nav;
        this.n = nav.width * nav.height;
        g = new float[n];
        parent = new int[n];
        stamp = new int[n];
        closed = new boolean[n];
        nearWall = new float[n];
        heapNode = new int[n * 8];
        heapKey = new float[n * 8];
        chain = new int[n];
        for (int y = 0; y < nav.height; y++) {
            for (int x = 0; x < nav.width; x++) {
                boolean next = false;
                for (int k = 0; k < 8 && !next; k++) next = !nav.walkable(x + DX[k], y + DY[k]);
                nearWall[y * nav.width + x] = next ? NEAR_WALL_COST : 0f;
            }
        }
    }

    /**
     * Finds a route from (sx,sy) to (gx,gy) for a body of the given radius, all at once.
     *
     * @return true and {@link #count} &gt; 0 on success
     */
    public boolean find(float sx, float sy, float gx, float gy, float radius) {
        begin(sx, sy, gx, gy, radius);
        int r;
        do {
            r = advance(Integer.MAX_VALUE);
        } while (r == 0);
        return r > 0;
    }

    /** Starts a search; continue it with {@link #advance}. Any search in progress is dropped. */
    public void begin(float sx, float sy, float gx, float gy, float body) {
        count = 0;
        complete = false;
        startX = sx;
        startY = sy;
        goalPx = gx;
        goalPy = gy;
        radius = body;
        found = false;
        startTile = nav.nearestWalkable(nav.tileOf(sx, sy));
        goalTile = nav.nearestWalkable(nav.tileOf(gx, gy));
        if (startTile < 0 || goalTile < 0) {
            phase = FAILED;
            return;
        }
        if (startTile == goalTile) {
            boolean standable = nav.walkable((int) (gx / GameConfig.TILE), (int) (gy / GameConfig.TILE));
            add(standable ? gx : nav.centerX(goalTile), standable ? gy : nav.centerY(goalTile));
            complete = true;
            phase = DONE;
            return;
        }
        token++;
        if (token == Integer.MAX_VALUE) {
            java.util.Arrays.fill(stamp, 0);
            token = 1;
        }
        heapSize = 0;
        int w = nav.width;
        goalX = goalTile % w;
        goalY = goalTile / w;
        touch(startTile, 0f, -1);
        push(startTile, estimate(startTile % w, startTile / w, goalX, goalY));
        expanded = 0;
        closest = startTile;
        closestH = Float.MAX_VALUE;
        phase = SEARCHING;
    }

    /** True while a search started with {@link #begin} has not finished yet. */
    public boolean busy() {
        return phase == SEARCHING || phase == SMOOTHING;
    }

    /**
     * Works on the search for at most about {@code budget} tile expansions (the smoothing counts as well).
     *
     * @return 0 = not finished (call again), 1 = a route is ready in {@link #wx}/{@link #wy}, -1 = no route
     */
    public int advance(int budget) {
        if (phase == SEARCHING) {
            int w = nav.width;
            int steps = 0;
            while (heapSize > 0) {
                if (steps++ >= budget) return 0;
                int cur = pop();
                if (closed[cur]) continue;
                closed[cur] = true;
                if (cur == goalTile) {
                    found = true;
                    break;
                }
                int cx = cur % w;
                int cy = cur / w;
                float hCur = estimate(cx, cy, goalX, goalY);
                if (hCur < closestH) {
                    closestH = hCur;
                    closest = cur;
                }
                if (++expanded > MAX_EXPANSIONS) break;
                for (int k = 0; k < 8; k++) {
                    int nx = cx + DX[k];
                    int ny = cy + DY[k];
                    if (!nav.walkable(nx, ny)) continue;
                    if (k >= 4 && (!nav.walkable(cx + DX[k], cy) || !nav.walkable(cx, cy + DY[k]))) continue;
                    int nb = ny * w + nx;
                    float step = (k >= 4 ? DIAGONAL : 1f) + nearWall[nb];
                    float ng = g[cur] + step;
                    if (stamp[nb] == token) {
                        if (closed[nb] || ng >= g[nb]) continue;
                    } else {
                        touch(nb, 0f, -1);
                    }
                    g[nb] = ng;
                    parent[nb] = cur;
                    if (heapSize < heapNode.length) push(nb, ng + estimate(nx, ny, goalX, goalY));
                }
            }
            if (!found) {
                if (expanded <= MAX_EXPANSIONS || closest == startTile) {
                    phase = FAILED;
                    return -1;
                }
                goalTile = closest;      // out of budget: head for the closest point reached; the bot replans on arrival
            }
            chainLen = 0;
            for (int t = goalTile; t >= 0 && chainLen < chain.length; t = parent[t]) {
                chain[chainLen++] = t;
                if (t == startTile) break;
            }
            // chain holds goal ... start. Smooth it into waypoints, starting from the real position.
            curX = startX;
            curY = startY;
            smoothI = chainLen - 1;
            phase = SMOOTHING;
        }
        if (phase == SMOOTHING) {
            int made = 0;
            while (smoothI > 0 && count < MAX_WAYPOINTS - 1) {
                if (made++ >= SMOOTH_PER_STEP && budget != Integer.MAX_VALUE) return 0;
                int far = smoothI - 1;
                // Look from the far end of the window back towards the next tile: the first visible one wins.
                for (int j = Math.max(0, smoothI - SMOOTH_LOOKAHEAD); j < smoothI; j++) {
                    if (nav.lineClear(curX, curY, nav.centerX(chain[j]), nav.centerY(chain[j]), radius)) {
                        far = j;
                        break;
                    }
                }
                curX = nav.centerX(chain[far]);
                curY = nav.centerY(chain[far]);
                add(curX, curY);
                smoothI = far;
            }
            complete = found && smoothI == 0;
            // Finish exactly on the goal point when that point itself is standable (not for a partial route).
            if (found && chain[0] == goalTile) {
                if (nav.walkable((int) Math.floor(goalPx / GameConfig.TILE), (int) Math.floor(goalPy / GameConfig.TILE))
                        && nav.lineClear(curX, curY, goalPx, goalPy, radius * 0.6f)) {
                    wx[Math.max(0, count - 1)] = goalPx;
                    wy[Math.max(0, count - 1)] = goalPy;
                    if (count == 0) count = 1;
                }
            }
            phase = count > 0 ? DONE : FAILED;
        }
        return phase == DONE ? 1 : phase == FAILED ? -1 : 0;
    }

    private void add(float x, float y) {
        if (count < MAX_WAYPOINTS) {
            wx[count] = x;
            wy[count] = y;
            count++;
        }
    }

    private void touch(int node, float cost, int par) {
        stamp[node] = token;
        closed[node] = false;
        g[node] = cost;
        parent[node] = par;
    }

    private static float estimate(int x, int y, int goalX, int goalY) {
        float dx = Math.abs(x - goalX);
        float dy = Math.abs(y - goalY);
        return HEURISTIC_WEIGHT * (Math.max(dx, dy) + (DIAGONAL - 1f) * Math.min(dx, dy));
    }

    // ------------------------------------------------------------------ binary min-heap

    private void push(int node, float key) {
        int i = heapSize++;
        while (i > 0) {
            int p = (i - 1) >> 1;
            if (heapKey[p] <= key) break;
            heapNode[i] = heapNode[p];
            heapKey[i] = heapKey[p];
            i = p;
        }
        heapNode[i] = node;
        heapKey[i] = key;
    }

    private int pop() {
        int top = heapNode[0];
        heapSize--;
        if (heapSize > 0) {
            int node = heapNode[heapSize];
            float key = heapKey[heapSize];
            int i = 0;
            while (true) {
                int c = 2 * i + 1;
                if (c >= heapSize) break;
                if (c + 1 < heapSize && heapKey[c + 1] < heapKey[c]) c++;
                if (heapKey[c] >= key) break;
                heapNode[i] = heapNode[c];
                heapKey[i] = heapKey[c];
                i = c;
            }
            heapNode[i] = node;
            heapKey[i] = key;
        }
        return top;
    }
}
