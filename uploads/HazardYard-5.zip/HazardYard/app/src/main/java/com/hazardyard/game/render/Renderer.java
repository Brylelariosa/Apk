package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.settings.GameSettings;

/**
 * Draws the arena and everything in it. The world is drawn in world units under one camera
 * transform with a slightly tilted look: flat floor first, then walls, crates, soldiers and weapon
 * pickups mixed in back-to-front order so a soldier standing behind a wall is hidden by it, then
 * bullets, effects and health bars. All paints and scratch objects are created once, so a frame
 * allocates nothing.
 */
public final class Renderer {
    private static final int MAX_DYNAMIC = 40;
    private static final int KIND_PLAYER = 0;
    private static final int KIND_PICKUP = 1;

    private final GameSettings settings;
    private final PolyDrawer poly = new PolyDrawer();
    private final FloorRenderer floor = new FloorRenderer();
    private final BlockRenderer blocks = new BlockRenderer();
    private final UnitRenderer units = new UnitRenderer(poly);
    private final PickupRenderer pickups = new PickupRenderer(poly);
    private final ShotRenderer shots = new ShotRenderer();
    private final AimLineRenderer aimLine = new AimLineRenderer();
    private float aimStrength;
    private boolean aimFiring;
    private final Paint vignette = new Paint();
    private int vignetteW, vignetteH;
    private int quality = QualityGovernor.FULL;
    private boolean flatModels;

    // objects that have to be interleaved with the blocks, sorted by depth
    private final int[] dynKind = new int[MAX_DYNAMIC];
    private final int[] dynIndex = new int[MAX_DYNAMIC];
    private final float[] dynKey = new float[MAX_DYNAMIC];

    public Renderer(GameSettings settings) {
        this.settings = settings;
    }

    /** One of the {@link QualityGovernor} levels; takes effect with the next frame. */
    public void setQuality(int level) {
        quality = level;
    }

    /** The player chose the Light look: soldiers and weapons are drawn flat (otherwise they only go flat at the last quality level). */
    public void setFlatModels(boolean flat) {
        flatModels = flat;
    }

    /** The local player's aim line for the next frame: how visible it is (0 = hidden) and whether the trigger is down. */
    public void setAimLine(float strength, boolean firing) {
        aimStrength = strength;
        aimFiring = firing;
    }

    public void draw(Canvas canvas, GameState st, Camera cam, float time) {
        TileMap map = st.map;
        MapTheme th = MapTheme.of(map.id);
        boolean models3d = settings.models3d && !flatModels && quality < QualityGovernor.MINIMAL;
        boolean lite = quality >= QualityGovernor.LIGHT;
        canvas.drawColor(th.backdrop);
        canvas.save();
        canvas.translate(cam.viewW * 0.5f, cam.viewH * 0.5f);
        canvas.scale(cam.scale, cam.scale);
        canvas.translate(-cam.x, -cam.y);

        float hw = cam.halfViewWorldW();
        float hh = cam.halfViewWorldH();
        float vx0 = cam.x - hw;
        float vx1 = cam.x + hw;
        float vy0 = cam.y - hh;
        float vy1 = cam.y + hh;

        units.update(st, time);
        floor.draw(canvas, st, th, cam.scale, time, vx0, vx1, vy0, vy1, lite, !models3d);
        if (quality < QualityGovernor.MINIMAL) blocks.drawShadows(canvas, map, vx0, vx1, vy0, vy1);

        int n = collectDynamic(st, cam, models3d);
        int d = 0;
        for (int b = 0; b < map.blockCount; b++) {
            int kind = map.blocks[b * 5 + 4];
            if (!BlockRenderer.isBox(kind)) continue;
            float south = (map.blocks[b * 5 + 1] + map.blocks[b * 5 + 3]) * com.hazardyard.game.core.GameConfig.TILE;
            while (d < n && dynKey[d] < south) drawDynamic(canvas, st, d++, time, models3d);
            if (BlockRenderer.inView(map, b, vx0, vx1, vy0, vy1)) blocks.draw(canvas, map, th, b);
        }
        while (d < n) drawDynamic(canvas, st, d++, time, models3d);

        if (aimStrength > 0.01f) aimLine.draw(canvas, st, st.local(), cam.scale, aimStrength, aimFiring, lite, time);
        shots.drawProjectiles(canvas, st.projectiles, cam, st.renderAlpha);
        shots.drawEffects(canvas, st.effects, lite);
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.connected && p.alive && cam.isVisible(p.rx, p.ry, 50f)) units.drawTag(canvas, st, i, models3d);
        }
        canvas.restore();
        if (!lite) drawVignette(canvas, cam.viewW, cam.viewH);
    }

    /** Gathers visible soldiers and pickups and sorts them by how far south (closer to the viewer) they stand. */
    private int collectDynamic(GameState st, Camera cam, boolean models3d) {
        int n = 0;
        for (int i = 0; i < st.players.length && n < MAX_DYNAMIC; i++) {
            Player p = st.players[i];
            if (!p.connected || !p.alive || !cam.isVisible(p.rx, p.ry, 50f)) continue;
            n = insert(n, KIND_PLAYER, i, p.ry);
        }
        if (models3d) {
            for (int i = 0; i < st.pickups.length && n < MAX_DYNAMIC; i++) {
                Pickup pk = st.pickups[i];
                if (!pk.active || !cam.isVisible(pk.x, pk.y, 40f)) continue;
                n = insert(n, KIND_PICKUP, i, pk.y);
            }
        }
        return n;
    }

    private int insert(int n, int kind, int index, float key) {
        int j = n - 1;
        while (j >= 0 && dynKey[j] > key) {
            dynKind[j + 1] = dynKind[j];
            dynIndex[j + 1] = dynIndex[j];
            dynKey[j + 1] = dynKey[j];
            j--;
        }
        dynKind[j + 1] = kind;
        dynIndex[j + 1] = index;
        dynKey[j + 1] = key;
        return n + 1;
    }

    private void drawDynamic(Canvas canvas, GameState st, int slot, float time, boolean models3d) {
        if (dynKind[slot] == KIND_PLAYER) units.draw(canvas, st, dynIndex[slot], time, models3d);
        else pickups.draw(canvas, st.pickups[dynIndex[slot]], dynIndex[slot], time);
    }

    /** Darkens the screen edges so the eye stays on the action. */
    private void drawVignette(Canvas canvas, int w, int h) {
        if (w != vignetteW || h != vignetteH) {
            vignetteW = w;
            vignetteH = h;
            float r = (float) Math.sqrt(w * (double) w + h * (double) h) * 0.5f;
            vignette.setShader(new RadialGradient(w * 0.5f, h * 0.5f, r,
                    new int[] {0x00000000, 0x00000000, 0x66000000}, new float[] {0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        }
        canvas.drawRect(0f, 0f, w, h, vignette);
    }
}
