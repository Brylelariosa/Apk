package com.hazardyard.game.bot;

import com.hazardyard.game.core.CollisionSystem;
import com.hazardyard.game.core.Dodge;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameMode;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.GameWorld;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Pickups;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.Weapon;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.core.XorShift;

/**
 * The AI of one computer-controlled soldier. Every simulation tick it looks at the match, decides
 * what to do and feeds {@link GameWorld#setInput} exactly like a human's touch controls would, so
 * bots obey the same movement, turning, ammunition and reload rules as everybody else.
 *
 * <p>Behaviour in priority order: fight an enemy it can see (keep a sensible distance for the
 * weapon, strafe, lead the shot, wait out its reaction time); go after an enemy it just lost sight
 * of; collect a clearly better weapon (walk to it and press Pick Up, like a player); otherwise roam
 * the map and hunt.
 *
 * <p>What makes the movement steady: the decision layers only say <em>where to go</em> ("intent");
 * a separate steering stage turns that into the stick the world sees. It steers around walls with
 * gradual whisker feedback (no yes/no switching), keeps its distance from other soldiers, and eases the
 * stick and the facing instead of snapping them, the way a thumb moves. Targets are held with
 * hysteresis, routes are only replanned when they have to be, and the aim sways smoothly instead of
 * jumping to a new random offset.
 */
public final class BotBrain {
    private static final float R = GameConfig.PLAYER_RADIUS - 1f;
    private static final float WAYPOINT_REACH = 14f;
    private static final float MEMORY_SECONDS = 2.5f;
    /** A target that cannot be seen for this long is dropped (shorter gaps are corner flicker). */
    private static final float TARGET_GRACE = 0.45f;
    /** Minimum time on a target before a different (clearly closer) one is taken. */
    private static final float TARGET_LOCK = 1.2f;
    private static final float REPATH_SECONDS = 2.4f;
    private static final float WHISKER = 34f;
    private static final float WHISKER_ANGLE = 0.75f;
    private static final float CROWD_RADIUS = 46f;

    /** How much each weapon is worth to a bot (1.0 = assault rifle). */
    private static final float[] RATING = {0.45f, 1.00f, 0.85f, 0.80f, 0.95f, 0.90f, 1.10f, 1.05f};

    private final int id;
    private final GameState st;
    private final GameWorld world;
    private final BotSquad squad;
    private final NavGrid nav;
    private final BotDifficulty diff;
    private final XorShift rng;
    private final boolean huge;
    /** Each bot likes some guns more than others, so a match is not eight bots all chasing the same gun. */
    private final float[] taste = new float[RATING.length];

    private float time;

    // target tracking
    private int target = -1;
    private float targetAge;
    private boolean targetVisible;
    private float lostFor;
    private float lastSeenX, lastSeenY;
    private float sinceSeen = 99f;
    private float reactTimer;
    private float enemyVX, enemyVY, prevEnX, prevEnY;
    private boolean enemyTracked;
    private boolean hitLatch;

    // smooth aim: sway phases, and the facing handed to the world
    private final float ph1, ph2, ph3;
    private float aimOut;
    private boolean aimPrimed;

    // movement: intent (what the layers above want), and the smoothed stick
    private float intX, intY;
    private float stickX, stickY;
    private float strafe, strafeDir = 1f, strafeTimer, strafeLock;
    private float radial;
    private float avoidSide = 1f;
    private boolean directToEnemy = true;
    private float directFlip;

    // route following
    private final float[] routeX = new float[PathFinder.MAX_WAYPOINTS];
    private final float[] routeY = new float[PathFinder.MAX_WAYPOINTS];
    private int routeLen, routeIdx;
    private boolean routeComplete;
    private float routeGoalX, routeGoalY;
    private float repathTimer;
    private float noRouteUntil;
    /** A route search for this bot is running (see {@link BotSquad}); the old route stays in use meanwhile. */
    private boolean searching;
    private float pendGX, pendGY;
    private boolean hasWander;
    private float wanderX, wanderY;
    private int pickupGoal = -1;
    private float pickupCheck;
    private int pickupTries;
    private int ignorePad = -1;
    private float ignoreUntil;
    private float pickupAsk;

    // fire control
    private boolean burstOpen = true;
    private float burstClock;
    private boolean aligned;

    // stuck detection
    private float progressClock, progressX, progressY, wantedSum;
    private int progressTicks;
    private float escapeTimer, escapeX, escapeY;
    private int escapeCount;

    public BotBrain(int id, GameState st, GameWorld world, BotSquad squad, BotDifficulty diff, int seed) {
        this.id = id;
        this.st = st;
        this.world = world;
        this.squad = squad;
        this.nav = squad.nav();
        this.diff = diff;
        this.huge = st.mode.id == GameMode.BATTLEGROUND;
        this.rng = new XorShift(seed * 7919 + id * 104729 + 13);
        strafeDir = rng.nextFloat() < 0.5f ? 1f : -1f;
        avoidSide = rng.nextFloat() < 0.5f ? 1f : -1f;
        for (int w = 0; w < taste.length; w++) taste[w] = (rng.nextFloat() - 0.5f) * 0.5f;
        burstClock = diff.burstOn * (0.6f + rng.nextFloat() * 0.8f);
        ph1 = rng.nextFloat() * MathUtil.TWO_PI;
        ph2 = rng.nextFloat() * MathUtil.TWO_PI;
        ph3 = rng.nextFloat() * MathUtil.TWO_PI;
    }

    /** Runs one decision step; call once per simulation tick before {@link GameWorld#step}. */
    public void think(float dt) {
        Player me = st.players[id];
        if (!me.connected) return;
        if (!me.alive || st.phase != GameState.PHASE_PLAYING) {
            stickX = 0f;
            stickY = 0f;
            aimPrimed = false;
            world.setInput(id, 0f, 0f, me.aim, false, 0);
            forgetEverything();
            return;
        }
        if (!aimPrimed) {
            aimPrimed = true;
            aimOut = me.aim;
            progressX = me.x;
            progressY = me.y;
            progressClock = 0f;
            wantedSum = 0f;
            progressTicks = 0;
        }
        time += dt;
        updateTarget(me, dt);

        intX = 0f;
        intY = 0f;
        boolean firing = false;
        float aimGoal = aimOut;
        if (target >= 0) {
            Player en = st.players[target];
            float ex = targetVisible ? en.x : lastSeenX;
            float ey = targetVisible ? en.y : lastSeenY;
            float dx = ex - me.x;
            float dy = ey - me.y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            trackEnemy(en, dt);
            combatIntent(me, ex, ey, dx, dy, dist, dt);
            aimGoal = aimAt(me, ex, ey, dist);
            if (targetVisible) firing = fireDecision(me, aimGoal, dist, dt);
            else maintainWeapon(me);
        } else {
            enemyTracked = false;
            roamIntent(me, dt);
            maintainWeapon(me);
        }

        if (escapeTimer > 0f) {
            escapeTimer -= dt;
            intX = escapeX;
            intY = escapeY;
        }
        steer(me, dt);
        trackProgress(me, dt);

        float stickMag = (float) Math.sqrt(stickX * stickX + stickY * stickY);
        if (target < 0 && stickMag > 0.3f) aimGoal = (float) Math.atan2(stickY, stickX);
        aimOut = slewAngle(aimOut, aimGoal, dt, target >= 0 ? 18f : 9f, target >= 0 ? 14f : 8f);
        world.setInput(id, stickX * diff.speed, stickY * diff.speed, aimOut, firing, 0);
    }

    private void forgetEverything() {
        if (searching) {
            squad.cancelSearch(id);
            searching = false;
        }
        target = -1;
        targetVisible = false;
        sinceSeen = 99f;
        routeLen = 0;
        routeIdx = 0;
        hasWander = false;
        pickupGoal = -1;
        escapeTimer = 0f;
        enemyTracked = false;
        aligned = false;
        strafe = 0f;
        radial = 0f;
    }

    // ------------------------------------------------------------------ perception

    private void updateTarget(Player me, float dt) {
        sinceSeen += dt;
        targetAge += dt;
        if (reactTimer > 0f) reactTimer -= dt;
        CollisionSystem col = st.collision;

        if (target >= 0) {
            Player t = st.players[target];
            if (!t.connected || !t.alive) {
                target = -1;
                targetVisible = false;
            }
        }
        boolean curVisible = target >= 0 && visible(me, st.players[target], col);
        if (curVisible) lostFor = 0f;
        else lostFor += dt;

        // Nearest visible enemy.
        int best = -1;
        float bestD2 = diff.sightRange * diff.sightRange;
        for (int j = 0; j < st.players.length; j++) {
            if (j == id) continue;
            Player q = st.players[j];
            if (!q.connected || !q.alive) continue;
            float dx = q.x - me.x;
            float dy = q.y - me.y;
            float d2 = dx * dx + dy * dy;
            if (d2 >= bestD2 || !visible(me, q, col)) continue;
            best = j;
            bestD2 = d2;
        }

        int chosen = target;
        if (curVisible) {
            // Stay on the current target unless a clearly closer one showed up and the lock has run out.
            if (best >= 0 && best != target && targetAge > TARGET_LOCK) {
                Player t = st.players[target];
                float dx = t.x - me.x;
                float dy = t.y - me.y;
                if (bestD2 < (dx * dx + dy * dy) * 0.42f) chosen = best;
            }
        } else if (target >= 0 && lostFor < TARGET_GRACE) {
            chosen = target;        // corner flicker: keep going for a moment towards where it was
        } else {
            chosen = best;
        }

        if (chosen >= 0) {
            if (chosen != target) {
                reactTimer = diff.reaction * (0.7f + rng.nextFloat() * 0.6f);
                targetAge = 0f;
                enemyTracked = false;
                aligned = false;
            }
            target = chosen;
            targetVisible = chosen == best || curVisible;
            if (targetVisible) {
                Player t = st.players[chosen];
                lastSeenX = t.x;
                lastSeenY = t.y;
                sinceSeen = 0f;
            }
        } else {
            if (target >= 0) {
                Player t = st.players[target];
                if (t.alive) {
                    lastSeenX = t.x;
                    lastSeenY = t.y;
                }
            }
            target = -1;
            targetVisible = false;
        }
    }

    private boolean visible(Player me, Player q, CollisionSystem col) {
        if (!q.connected || !q.alive) return false;
        float dx = q.x - me.x;
        float dy = q.y - me.y;
        if (dx * dx + dy * dy > diff.sightRange * diff.sightRange) return false;
        return col.raycast(me.x, me.y, q.x, q.y) < 0f;
    }

    /** Smoothed estimate of the enemy's velocity, from how it really moved (not from its raw input). */
    private void trackEnemy(Player en, float dt) {
        if (!enemyTracked) {
            enemyTracked = true;
            enemyVX = 0f;
            enemyVY = 0f;
        } else if (dt > 1e-5f) {
            float vx = (en.x - prevEnX) / dt;
            float vy = (en.y - prevEnY) / dt;
            if (vx * vx + vy * vy < 500f * 500f) {
                float k = 1f - (float) Math.exp(-dt / 0.15f);
                enemyVX += (vx - enemyVX) * k;
                enemyVY += (vy - enemyVY) * k;
            }
        }
        prevEnX = en.x;
        prevEnY = en.y;
    }

    // ------------------------------------------------------------------ combat

    private void combatIntent(Player me, float ex, float ey, float dx, float dy, float dist, float dt) {
        WeaponDef def = me.weapon.def;
        float preferred = MathUtil.clamp(def.range * 0.5f, 120f, 380f);
        float inv = dist > 1e-3f ? 1f / dist : 0f;
        float ux = dx * inv;
        float uy = dy * inv;

        strafeTimer -= dt;
        strafeLock -= dt;
        if (me.hitFlash > 0.1f) {
            if (!hitLatch) {
                hitLatch = true;
                if (strafeLock <= 0f) {
                    strafeDir = -strafeDir;
                    strafeLock = 0.8f;
                }
                // Just got hit: sometimes roll sideways out of the line of fire (not when a reload is nearly done).
                Weapon w = me.weapon;
                boolean nearlyReloaded = w.reloading && w.reloadFraction > 0.45f;
                if (!nearlyReloaded && rng.nextFloat() < diff.dodgeChance && Dodge.canStart(me, 0f)) {
                    world.requestDodge(id, -uy * strafeDir, ux * strafeDir);
                }
            }
        } else {
            hitLatch = false;
        }
        if (strafeTimer <= 0f) {
            if (strafeLock <= 0f && rng.nextFloat() < 0.5f) {
                strafeDir = -strafeDir;
                strafeLock = 0.8f;
            }
            strafeTimer = 1.3f + rng.nextFloat() * 1.3f;
        }
        // Do not strafe into a wall: that side is blocked, so go the other way (with a lock against flapping).
        float sideAngle = (float) Math.atan2(ux * strafeDir, -uy * strafeDir);
        if (strafeLock <= 0f && nav.clearDistance(me.x, me.y, sideAngle, 40f) < 22f
                && nav.clearDistance(me.x, me.y, sideAngle + MathUtil.PI, 40f) > 30f) {
            strafeDir = -strafeDir;
            strafeLock = 1.0f;
        }
        // The strafe speed ramps between -1 and +1 instead of flipping.
        strafe += (strafeDir - strafe) * (1f - (float) Math.exp(-dt / 0.22f));

        // Too far and no straight walk: follow a route to the enemy instead of pushing at a wall.
        boolean clear = nav.lineClear(me.x, me.y, ex, ey, R);
        if (clear != directToEnemy) {
            directFlip += dt;
            if (directFlip > 0.3f) {
                directToEnemy = clear;
                directFlip = 0f;
            }
        } else {
            directFlip = 0f;
        }
        if (dist > preferred + 50f && !directToEnemy) {
            followRoute(me, ex, ey, dt, 96f);
            return;
        }
        // Approach / back off with a smooth ramp around the preferred distance (no on/off switch).
        float wantRadial = MathUtil.clamp((dist - preferred) / 90f, -1f, 1f);
        radial += (wantRadial - radial) * (1f - (float) Math.exp(-dt / 0.25f));
        intX = ux * radial - uy * strafe * 0.85f;
        intY = uy * radial + ux * strafe * 0.85f;
    }

    /** The angle to turn the body to: the enemy, led by its real velocity, with a slow smooth sway on top. */
    private float aimAt(Player me, float ex, float ey, float dist) {
        float t = dist / me.weapon.def.projectileSpeed;
        float px = ex + enemyVX * t * diff.lead;
        float py = ey + enemyVY * t * diff.lead;
        float ang = (float) Math.atan2(py - me.y, px - me.x);
        float sway = (float) (Math.sin(time * 2.1 + ph1) + 0.6 * Math.sin(time * 3.7 + ph2)
                + 0.3 * Math.sin(time * 6.1 + ph3)) * (1f / 1.9f);
        float off = MathUtil.clamp(diff.aimError * sway / Math.max(dist, 60f), -0.09f, 0.09f);
        return ang + off;
    }

    private boolean fireDecision(Player me, float desiredAim, float dist, float dt) {
        Weapon w = me.weapon;
        WeaponDef def = w.def;
        if (w.ammo <= 0 && !w.reloading) world.requestReload(id);
        if (w.reloading) {
            // A gun with a round in it can be fired mid-reload (a fresh trigger pull cuts the reload short),
            // but only when the enemy is on top of us; otherwise let the reload finish.
            boolean close = dist < def.range * (def.loadsRoundByRound() ? 0.55f : 0.30f);
            boolean enough = w.ammo >= (def.loadsRoundByRound() ? 1 : Math.max(2, def.magSize / 4));
            if (!(w.canInterruptReload() && close && enough)) {
                aligned = false;
                return false;
            }
        }
        if (reactTimer > 0f || w.ammo <= 0) return false;
        if (dist > def.range * 0.95f) return false;
        float err = Math.abs(MathUtil.angleDiff(me.aim, desiredAim));
        float bodyAngle = (float) Math.atan2(GameConfig.PLAYER_RADIUS, Math.max(dist, 40f));
        float tolerance = Math.min(diff.fireTolerance, Math.max(bodyAngle * 1.5f, 0.03f));
        // Hysteresis: once lined up, the trigger stays down through small wobbles.
        aligned = err <= (aligned ? tolerance * 1.6f : tolerance);
        if (!aligned) return false;
        if (def.rapidFire && diff.burstOff > 0f) {
            burstClock -= dt;
            if (burstClock <= 0f) {
                burstOpen = !burstOpen;
                float len = burstOpen ? diff.burstOn : diff.burstOff;
                burstClock = len * (0.7f + rng.nextFloat() * 0.6f);
            }
            if (!burstOpen) return false;
        }
        return true;
    }

    private void maintainWeapon(Player me) {
        Weapon w = me.weapon;
        if (!w.reloading && w.ammo < w.def.magSize * 0.4f) world.requestReload(id);
    }

    // ------------------------------------------------------------------ roaming

    private void roamIntent(Player me, float dt) {
        if (sinceSeen < MEMORY_SECONDS) {
            // Just lost sight of somebody: go where they were.
            if (dist2(me.x, me.y, lastSeenX, lastSeenY) > 30f * 30f) {
                followRoute(me, lastSeenX, lastSeenY, dt, 64f);
                return;
            }
        }
        pickupCheck -= dt;
        if (pickupCheck <= 0f) {
            pickupCheck = 1f + rng.nextFloat() * 0.5f;
            int goal = choosePickup(me);
            if (goal != pickupGoal) pickupTries = 0;
            pickupGoal = goal;
        }
        if (pickupGoal >= 0) {
            Pickup pk = st.pickups[pickupGoal];
            if (!pk.active || !Pickups.worthTaking(me, pk)) {
                pickupGoal = -1;
            } else {
                float d2 = dist2(me.x, me.y, pk.x, pk.y);
                float near = GameConfig.PICKUP_REACH * 0.6f;
                if (d2 < near * near) {
                    // Standing at the pad: press Pick Up, like a player would (not every tick).
                    pickupAsk -= dt;
                    if (pickupAsk <= 0f) {
                        pickupAsk = 0.35f;
                        world.requestPickup(id, pickupGoal);
                        if (++pickupTries >= 4) {
                            ignorePad = pickupGoal;
                            ignoreUntil = time + 12f;
                            pickupGoal = -1;
                        }
                    }
                    return;
                }
                followRoute(me, pk.x, pk.y, dt, 48f);
                return;
            }
        }
        float arrive = 28f * 28f;
        if (!hasWander || dist2(me.x, me.y, wanderX, wanderY) < arrive
                || (routeIdx >= routeLen && routeLen > 0 && routeComplete)) {
            chooseWander(me);
        }
        followRoute(me, wanderX, wanderY, dt, 64f);
    }

    private int choosePickup(Player me) {
        float mine = rating(me.weapon.def.id) + (me.weapon.ammo < me.weapon.def.magSize * 0.25f ? 0.25f : 0f);
        float range = diff.pickupRange * (huge ? 2.0f : 1f);
        int best = -1;
        float bestScore = 0f;
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (!pk.active) continue;
            if (i == ignorePad && time < ignoreUntil) continue;
            float d = (float) Math.sqrt(dist2(me.x, me.y, pk.x, pk.y));
            if (d > range) continue;
            float gain = rating(pk.weaponId) - mine;
            if (pk.weaponId == me.weapon.def.id) gain = Pickups.worthTaking(me, pk) ? 0.2f : 0f;
            if (gain < 0.08f) continue;
            float score = gain * 700f - d * (huge ? 0.5f : 1f);
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        return best;
    }

    private float rating(int weaponId) {
        return weaponId >= 0 && weaponId < RATING.length ? RATING[weaponId] + taste[weaponId] : 0.5f;
    }

    private void chooseWander(Player me) {
        hasWander = false;
        routeLen = 0;
        if (rng.nextFloat() < diff.aggression) {
            // Hunt: head for the general area of a random living enemy.
            int pick = -1;
            int seen = 0;
            for (int j = 0; j < st.players.length; j++) {
                Player q = st.players[j];
                if (j == id || !q.connected || !q.alive) continue;
                seen++;
                if (rng.nextFloat() * seen < 1f) pick = j;
            }
            if (pick >= 0) {
                Player q = st.players[pick];
                float gx = q.x + rng.nextSigned() * 140f;
                float gy = q.y + rng.nextSigned() * 140f;
                int tile = nav.nearestWalkable(nav.tileOf(gx, gy));
                if (tile >= 0) {
                    wanderX = nav.centerX(tile);
                    wanderY = nav.centerY(tile);
                    hasWander = true;
                    return;
                }
            }
        }
        float minDist = huge ? 600f : 250f;
        for (int tries = 0; tries < 30; tries++) {
            int tx = (int) (rng.nextFloat() * nav.width);
            int ty = (int) (rng.nextFloat() * nav.height);
            if (!nav.walkable(tx, ty)) continue;
            float gx = (tx + 0.5f) * GameConfig.TILE;
            float gy = (ty + 0.5f) * GameConfig.TILE;
            if (dist2(me.x, me.y, gx, gy) < minDist * minDist) continue;
            wanderX = gx;
            wanderY = gy;
            hasWander = true;
            return;
        }
        int tile = nav.nearestWalkable(nav.tileOf(me.x, me.y));
        if (tile >= 0) {
            wanderX = nav.centerX(tile);
            wanderY = nav.centerY(tile);
            hasWander = true;
        }
    }

    // ------------------------------------------------------------------ route following

    /**
     * Walks a route to (gx, gy). The route is only replanned when it has to be: there is none, the goal moved
     * more than {@code goalSlack}, the route was cut short and has run out, or it is old. Replanning goes
     * through the squad, which spreads the (expensive) searches over several ticks.
     */
    private void followRoute(Player me, float gx, float gy, float dt, float goalSlack) {
        repathTimer -= dt;
        if (searching && dist2(gx, gy, pendGX, pendGY) > goalSlack * goalSlack * 4f) {
            squad.cancelSearch(id);              // the goal moved away while the search was running: start over
            searching = false;
        }
        boolean goalMoved = dist2(gx, gy, routeGoalX, routeGoalY) > goalSlack * goalSlack;
        boolean spent = routeLen > 0 && routeIdx >= routeLen - 1 && !routeComplete;
        if (!searching && (routeLen == 0 || goalMoved || spent || repathTimer <= 0f)
                && !(routeLen == 0 && time < noRouteUntil)) {   // after a failed search, do not retry at once
            pendGX = gx;
            pendGY = gy;
            searching = true;
            if (!squad.beginSearch(id, me.x, me.y, gx, gy, R)) searching = false;   // another bot is searching: ask again next tick
        }
        if (routeLen == 0) return;               // still waiting for a route
        while (routeIdx < routeLen - 1 && dist2(me.x, me.y, routeX[routeIdx], routeY[routeIdx]) < WAYPOINT_REACH * WAYPOINT_REACH) {
            routeIdx++;
        }
        if (routeIdx + 1 < routeLen && nav.lineClear(me.x, me.y, routeX[routeIdx + 1], routeY[routeIdx + 1], R)) routeIdx++;
        float wx = routeX[routeIdx];
        float wy = routeY[routeIdx];
        float dx = wx - me.x;
        float dy = wy - me.y;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        if (routeIdx == routeLen - 1 && d < 8f) {
            routeIdx = routeLen;
            return;
        }
        if (routeIdx >= routeLen) return;
        intX = dx / Math.max(d, 1e-3f);
        intY = dy / Math.max(d, 1e-3f);
    }

    /** The squad delivers a finished search: take the new route (or note that there is none). */
    void acceptRoute(PathFinder pf, boolean ok) {
        searching = false;
        if (ok) {
            routeLen = pf.count;
            routeComplete = pf.complete;
            System.arraycopy(pf.wx, 0, routeX, 0, routeLen);
            System.arraycopy(pf.wy, 0, routeY, 0, routeLen);
            routeIdx = 0;
            routeGoalX = pendGX;
            routeGoalY = pendGY;
            repathTimer = REPATH_SECONDS + rng.nextFloat() * 0.8f;
        } else {
            routeLen = 0;
            routeIdx = 0;
            hasWander = false;                   // unreachable goal: pick another
            noRouteUntil = time + 0.8f;
        }
    }

    // ------------------------------------------------------------------ steering

    /**
     * Turns the intent into the stick the world sees. Walls bend the heading in proportion to how close they
     * are (three whiskers, a remembered side for head-on blocks), other soldiers push gently away, and the
     * result is eased: the stick changes like a thumb, not like a switch.
     */
    private void steer(Player me, float dt) {
        float mag = (float) Math.sqrt(intX * intX + intY * intY);
        float dX = 0f;
        float dY = 0f;
        if (mag > 0.01f) {
            float base = (float) Math.atan2(intY, intX);
            float l = whisker(me, base - WHISKER_ANGLE);
            float c = whisker(me, base);
            float r = whisker(me, base + WHISKER_ANGLE);
            float turn = (l - r) * 0.9f;
            if (c > 0.15f) {
                // Head-on: bend to the freer side and keep to it until the way is open again.
                if (Math.abs(l - r) > 0.12f) avoidSide = l < r ? -1f : 1f;
                turn += avoidSide * c * 1.1f;
            }
            float a = base + MathUtil.clamp(turn, -1.4f, 1.4f);
            float speedK = mag > 1f ? 1f : mag;
            speedK *= 1f - 0.45f * c;
            dX = (float) Math.cos(a) * speedK;
            dY = (float) Math.sin(a) * speedK;
        }
        // Keep clear of other soldiers (also stops two bots from sitting inside each other).
        float sx = 0f;
        float sy = 0f;
        for (int j = 0; j < st.players.length; j++) {
            if (j == id) continue;
            Player q = st.players[j];
            if (!q.connected || !q.alive) continue;
            float ox = me.x - q.x;
            float oy = me.y - q.y;
            float d2 = ox * ox + oy * oy;
            if (d2 > CROWD_RADIUS * CROWD_RADIUS || d2 < 1e-4f) continue;
            float d = (float) Math.sqrt(d2);
            float push = (1f - d / CROWD_RADIUS) * 0.9f;
            sx += ox / d * push;
            sy += oy / d * push;
        }
        dX += sx;
        dY += sy;
        float dm = (float) Math.sqrt(dX * dX + dY * dY);
        if (dm > 1f) {
            dX /= dm;
            dY /= dm;
        }
        float tau = target >= 0 ? 0.13f : 0.10f;
        float k = 1f - (float) Math.exp(-dt / tau);
        stickX += (dX - stickX) * k;
        stickY += (dY - stickY) * k;
        wantedSum += mag > 1f ? 1f : mag;
        progressTicks++;
    }

    /** 0 when the way along {@code angle} is free for {@link #WHISKER} units, towards 1 as a wall gets closer. */
    private float whisker(Player me, float angle) {
        float free = nav.clearDistance(me.x, me.y, angle, WHISKER);
        return 1f - free / WHISKER;
    }

    private void trackProgress(Player me, float dt) {
        progressClock += dt;
        if (progressClock < 0.8f) return;
        float moved = (float) Math.sqrt(dist2(me.x, me.y, progressX, progressY));
        float wanted = wantedSum / Math.max(1, progressTicks);
        if (wanted > 0.5f && moved < 8f && escapeTimer <= 0f) {
            beginEscape(me);
        } else if (moved > 40f) {
            escapeCount = 0;
        }
        progressX = me.x;
        progressY = me.y;
        progressClock = 0f;
        wantedSum = 0f;
        progressTicks = 0;
    }

    /** Stuck: walk out along the most open direction (leaning towards where we wanted to go), then replan. */
    private void beginEscape(Player me) {
        float want = (float) Math.atan2(intY, intX);
        float bestScore = -1e9f;
        float bestAngle = want;
        for (int k = 0; k < 8; k++) {
            float a = k * (MathUtil.TWO_PI / 8f);
            float clear = nav.clearDistance(me.x, me.y, a, 70f);
            float score = clear + 25f * (float) Math.cos(a - want) + rng.nextFloat() * 6f;
            if (score > bestScore) {
                bestScore = score;
                bestAngle = a;
            }
        }
        escapeX = (float) Math.cos(bestAngle);
        escapeY = (float) Math.sin(bestAngle);
        escapeTimer = 0.55f;
        if (searching) {
            squad.cancelSearch(id);
            searching = false;
        }
        routeLen = 0;
        repathTimer = 0f;
        strafeDir = -strafeDir;
        if (++escapeCount >= 3) {
            // Repeatedly stuck: give up on this goal.
            escapeCount = 0;
            hasWander = false;
            if (pickupGoal >= 0) {
                ignorePad = pickupGoal;
                ignoreUntil = time + 12f;
                pickupGoal = -1;
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    /**
     * Turns {@code cur} towards {@code goal}: fast when far, easing in as it gets close ({@code gain} per radian of
     * error), never faster than {@code maxRate} radians per second.
     */
    private static float slewAngle(float cur, float goal, float dt, float gain, float maxRate) {
        float diff = MathUtil.angleDiff(cur, goal);
        float rate = MathUtil.clamp(Math.abs(diff) * gain, 0.8f, maxRate);
        float step = rate * dt;
        if (Math.abs(diff) <= step) return MathUtil.wrapAngle(goal);
        return MathUtil.wrapAngle(cur + Math.signum(diff) * step);
    }

    private static float dist2(float ax, float ay, float bx, float by) {
        float dx = ax - bx;
        float dy = ay - by;
        return dx * dx + dy * dy;
    }
}
