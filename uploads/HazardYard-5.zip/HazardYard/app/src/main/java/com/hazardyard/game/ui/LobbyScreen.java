package com.hazardyard.game.ui;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameMode;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.net.ClientManager;
import com.hazardyard.game.net.HostManager;
import com.hazardyard.game.net.LobbyManager;
import com.hazardyard.game.net.NetUtil;
import com.hazardyard.game.net.Protocol;
import com.hazardyard.game.render.Palette;

/**
 * The lobby, shared by both roles. The host sees its address, the player list, picks the game mode
 * and the arena, and gets a Start Game button that unlocks once everybody is ready. A client sees the
 * same list and a Ready toggle. In Battleground the match is filled up with bots to eight fighters; the
 * real players always keep their slots and the bots only take what is left.
 */
final class LobbyScreen implements Screen {
    private final Context ctx;
    private final Navigator nav;
    private final boolean isHost;
    /** Set only for a client that still has to open its connection. */
    private final String connectAddress;
    private final int connectPort;

    private final FrameLayout root;
    private final ScreenPadding padding;
    private final MapPreviewView mapPreview;
    private final TextView mapName;
    private final TextView mapBlurb;
    private final TextView mapPrev;
    private final TextView mapNext;
    private final SegmentedControl modeControl;
    private final TextView modeText;
    private final TextView botsInfo;
    private final TextView info;
    private final TextView status;
    private final View[] dots = new View[GameConfig.MAX_HUMANS];
    private final TextView[] names = new TextView[GameConfig.MAX_HUMANS];
    private final TextView[] states = new TextView[GameConfig.MAX_HUMANS];
    private final Button primary;
    private final Button leave;
    private final LobbyManager.Entry[] entries = new LobbyManager.Entry[GameConfig.MAX_HUMANS];
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile boolean connected;

    /** Host lobby. */
    static LobbyScreen forHost(Context c, Navigator n) {
        return new LobbyScreen(c, n, true, null, 0);
    }

    /** Client lobby for a connection that is already open (returning from a match). */
    static LobbyScreen forClient(Context c, Navigator n) {
        return new LobbyScreen(c, n, false, null, 0);
    }

    /** Client lobby that opens the connection when shown. */
    static LobbyScreen forClientConnecting(Context c, Navigator n, String address, int port) {
        return new LobbyScreen(c, n, false, address, port);
    }

    private LobbyScreen(Context c, Navigator navigator, boolean host, String address, int port) {
        ctx = c;
        nav = navigator;
        isHost = host;
        connectAddress = address;
        connectPort = port;
        connected = host || address == null;
        for (int i = 0; i < entries.length; i++) entries[i] = new LobbyManager.Entry();

        root = new FrameLayout(c);
        root.addView(new BackdropView(c), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.HORIZONTAL);
        padding = new ScreenPadding(content, c, 40, 30, 40, 30);
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- left: heading and connection info ----
        LinearLayout left = Ui.column(c);
        content.addView(left, Ui.lp(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f, 0, 0, 24, 0, c));
        left.addView(Ui.label(c, isHost ? "Your lobby" : "Lobby", 32f, Palette.TEXT, true));
        left.addView(new BackdropView.StripeBar(c), Ui.lp(Ui.dp(c, 110), Ui.dp(c, 8), 0f, 0, 8, 0, 0, c));
        info = Ui.label(c, "", 14f, Palette.TEXT_DIM, false);
        info.setLineSpacing(0f, 1.15f);
        left.addView(info, Ui.fillWidth(c, 14));
        status = Ui.label(c, "", 14f, Palette.WARN, false);
        left.addView(status, Ui.fillWidth(c, 12));

        // ---- game mode: the host picks it, everybody sees it ----
        String[] modeNames = new String[GameMode.COUNT];
        for (int i = 0; i < modeNames.length; i++) modeNames[i] = GameMode.byId(i).name;
        modeControl = new SegmentedControl(c, modeNames, GameMode.CLASSIC, new SegmentedControl.OnChange() {
            @Override
            public void onChange(int i) {
                HostManager hm = nav.host();
                if (hm != null) hm.setModeId(i);
            }
        });
        modeControl.setVisibility(isHost ? View.VISIBLE : View.GONE);
        left.addView(modeControl, Ui.fillWidth(c, 12));
        modeText = Ui.label(c, "", 15f, Palette.ACCENT, true);
        modeText.setVisibility(isHost ? View.GONE : View.VISIBLE);
        left.addView(modeText, Ui.fillWidth(c, 12));

        // ---- arena: the host picks it, everybody sees it ----
        LinearLayout mapRow = Ui.row(c);
        mapRow.setGravity(Gravity.CENTER_VERTICAL);
        left.addView(mapRow, Ui.fillWidth(c, 14));
        mapPrev = arrow(c, "\u25C0");
        mapNext = arrow(c, "\u25B6");
        mapName = Ui.label(c, "", 17f, Palette.TEXT, true);
        mapName.setGravity(Gravity.CENTER);
        mapRow.addView(mapPrev, Ui.lp(Ui.dp(c, 44), Ui.dp(c, 40), 0f, 0, 0, 0, 0, c));
        mapRow.addView(mapName, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 0, 0, c));
        mapRow.addView(mapNext, Ui.lp(Ui.dp(c, 44), Ui.dp(c, 40), 0f, 0, 0, 0, 0, c));
        mapPrev.setVisibility(isHost ? View.VISIBLE : View.GONE);
        mapNext.setVisibility(isHost ? View.VISIBLE : View.GONE);
        mapPreview = new MapPreviewView(c);
        left.addView(mapPreview, Ui.lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f, 0, 8, 0, 0, c));
        mapBlurb = Ui.label(c, "", 12f, Palette.TEXT_DIM, false);
        left.addView(mapBlurb, Ui.fillWidth(c, 8));
        mapPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stepMap(-1);
            }
        });
        mapNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stepMap(1);
            }
        });

        // ---- right: players and actions ----
        ScrollView scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        content.addView(scroll, Ui.lp(Ui.dp(c, 330), ViewGroup.LayoutParams.MATCH_PARENT, 0f, 0, 0, 0, 0, c));
        LinearLayout right = Ui.column(c);
        scroll.addView(right, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout panel = Ui.panel(c);
        right.addView(panel, Ui.fillWidth(c, 0));
        panel.addView(Ui.label(c, "Players", 16f, Palette.TEXT, true));
        for (int i = 0; i < GameConfig.MAX_HUMANS; i++) {
            LinearLayout row = Ui.row(c);
            row.setPadding(Ui.dp(c, 12), Ui.dp(c, 9), Ui.dp(c, 12), Ui.dp(c, 9));
            row.setBackground(Ui.rounded(c, 0xFF1B2430, 0xFF2B3542, 10f, 1f));
            panel.addView(row, Ui.fillWidth(c, 8));
            View dot = new View(c);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(PlayerColors.of(i));
            dot.setBackground(g);
            row.addView(dot, Ui.lp(Ui.dp(c, 14), Ui.dp(c, 14), 0f, 0, 0, 12, 0, c));
            TextView name = Ui.label(c, "", 17f, Palette.TEXT, true);
            name.setSingleLine(true);
            row.addView(name, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 0, 0, c));
            TextView state = Ui.label(c, "", 13f, Palette.TEXT_DIM, true);
            state.setGravity(Gravity.END);
            row.addView(state);
            dots[i] = dot;
            names[i] = name;
            states[i] = state;
        }

        botsInfo = Ui.label(c, "", 12f, Palette.ACCENT, true);
        panel.addView(botsInfo, Ui.fillWidth(c, 12));

        primary = Ui.button(c, isHost ? "Start Game" : "I'm ready", true);
        right.addView(primary, Ui.fillWidth(c, 14));
        leave = Ui.button(c, isHost ? "Close lobby" : "Leave", false);
        right.addView(leave, Ui.fillWidth(c, 10));

        primary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPrimary();
            }
        });
        leave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nav.showMenu(null);
            }
        });
        refresh();
    }

    // ------------------------------------------------------------------ actions

    private void onPrimary() {
        if (isHost) {
            nav.startMatch();
            return;
        }
        ClientManager cm = nav.client();
        if (cm == null || !connected) return;
        boolean nowReady = !myReady(cm);
        cm.sendReady(nowReady);
    }

    private static TextView arrow(Context c, String glyph) {
        TextView t = Ui.label(c, glyph, 16f, Palette.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        t.setBackground(Ui.rounded(c, 0xFF1E2733, 0xFF3A4757, 10f, 1.5f));
        return t;
    }

    private void stepMap(int delta) {
        HostManager hm = nav.host();
        if (hm == null) return;
        int next = (hm.lobby().getArenaChoice() + delta + MapLibrary.CLASSIC_COUNT) % MapLibrary.CLASSIC_COUNT;
        hm.setMapId(next);
    }

    private boolean myReady(ClientManager cm) {
        int id = cm.localPlayerId();
        cm.lobby().copyTo(entries);
        return id >= 0 && id < entries.length && entries[id].used && entries[id].ready;
    }

    // ------------------------------------------------------------------ rendering of the state

    private void refresh() {
        LobbyManager lobby;
        int myId;
        if (isHost) {
            HostManager hm = nav.host();
            if (hm == null) return;
            lobby = hm.lobby();
            myId = 0;
        } else {
            ClientManager cm = nav.client();
            if (cm == null) return;
            lobby = cm.lobby();
            myId = cm.localPlayerId();
        }
        lobby.copyTo(entries);
        int mapId = lobby.getMapId();
        GameMode mode = GameMode.byId(lobby.getModeId());
        modeControl.select(mode.id);
        modeText.setText("Mode: " + mode.name);
        mapPreview.setMap(mapId);
        mapName.setText(MapLibrary.name(mapId));
        mapBlurb.setText(mode.fixedMap() ? mode.blurb : MapLibrary.blurb(mapId));
        boolean pickArena = isHost && !mode.fixedMap();
        mapPrev.setVisibility(pickArena ? View.VISIBLE : View.GONE);
        mapNext.setVisibility(pickArena ? View.VISIBLE : View.GONE);
        int count = 0;
        boolean othersReady = true;
        for (int i = 0; i < entries.length; i++) {
            LobbyManager.Entry e = entries[i];
            if (e.used) {
                count++;
                if (!e.host && !e.ready) othersReady = false;
            }
            boolean mine = e.used && i == myId;
            names[i].setText(e.used ? (mine ? e.name + " (you)" : e.name) : "Open slot");
            names[i].setTextColor(e.used ? Palette.TEXT : Palette.TEXT_DIM);
            dots[i].setAlpha(e.used ? 1f : 0.25f);
            if (!e.used) {
                states[i].setText("");
            } else if (e.host) {
                states[i].setText("Host");
                states[i].setTextColor(Palette.ACCENT);
            } else if (e.ready) {
                states[i].setText("Ready");
                states[i].setTextColor(Palette.GOOD);
            } else {
                states[i].setText("Not ready");
                states[i].setTextColor(Palette.TEXT_DIM);
            }
        }

        if (mode.roster > 0) {
            int bots = mode.botsFor(count);
            botsInfo.setText(bots == 0 ? "No bots needed: all " + mode.roster + " fighters are real players."
                    : bots + (bots == 1 ? " bot fills" : " bots fill") + " the empty slots when the match starts ("
                    + mode.roster + " fighters in all).");
        } else {
            botsInfo.setText("");
        }

        if (isHost) {
            HostManager hm = nav.host();
            String ip = NetUtil.localAddressText();
            String where = ip.isEmpty() ? "No Wi-Fi address found. Connect to Wi-Fi or turn on your hotspot."
                    : "Friends on this Wi-Fi or hotspot will find this game automatically.\nTo join by address use  "
                    + ip + (hm != null && hm.port() != Protocol.GAME_PORT ? ":" + hm.port() : "");
            info.setText(where);
            boolean canStart = othersReady;
            Ui.setEnabled(primary, canStart);
            if (count == 1) {
                status.setText("No other players yet. You can start a solo practice match, or wait for friends.");
            } else if (!othersReady) {
                status.setText("Waiting for everyone to get ready.");
            } else {
                status.setText("Everyone is ready.");
            }
            status.setTextColor(othersReady && count > 1 ? Palette.GOOD : Palette.WARN);
        } else {
            ClientManager cm = nav.client();
            if (!connected) {
                info.setText("Connecting to " + connectAddress + ":" + connectPort + "\u2026");
                status.setText("");
                Ui.setEnabled(primary, false);
            } else {
                info.setText("Connected. Tap ready when you are set; the host starts the match.");
                boolean mineReady = cm != null && myReady(cm);
                primary.setText(mineReady ? "Not ready" : "I'm ready");
                Ui.setEnabled(primary, true);
                status.setText(mineReady ? "Waiting for the host to start." : "");
                status.setTextColor(Palette.GOOD);
            }
        }
    }

    private final Runnable refreshTask = new Runnable() {
        @Override
        public void run() {
            refresh();
        }
    };

    // ------------------------------------------------------------------ network callbacks (any thread)

    private final HostManager.Listener hostListener = new HostManager.Listener() {
        @Override
        public void onLobbyChanged() {
            ui.post(refreshTask);
        }

        @Override
        public void onFailure(final String message) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    nav.showMenu(message);
                }
            });
        }
    };

    private final ClientManager.Listener clientListener = new ClientManager.Listener() {
        @Override
        public void onConnected(int playerId) {
            connected = true;
            ui.post(refreshTask);
        }

        @Override
        public void onLobbyChanged() {
            ui.post(refreshTask);
        }

        @Override
        public void onRejected(final int reason) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    nav.toast(Protocol.rejectMessage(reason));
                    nav.showJoin();
                }
            });
        }

        @Override
        public void onMatchStart() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    nav.startMatch();
                }
            });
        }

        @Override
        public void onReturnToLobby() {
            ui.post(refreshTask);
        }

        @Override
        public void onDisconnected(final String reason) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    nav.toast(reason);
                    nav.showJoin();
                }
            });
        }
    };

    // ------------------------------------------------------------------ Screen

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShow() {
        if (isHost) {
            HostManager hm = nav.host();
            if (hm != null) hm.setListener(hostListener);
        } else {
            ClientManager cm = nav.client();
            if (cm != null) {
                if (connectAddress != null) cm.connect(connectAddress, connectPort, nav.playerName(), clientListener);
                else cm.setListener(clientListener);
            }
        }
        refresh();
    }

    @Override
    public void onHide() {
        ui.removeCallbacksAndMessages(null);
        if (isHost) {
            HostManager hm = nav.host();
            if (hm != null) hm.setListener(null);
        } else {
            ClientManager cm = nav.client();
            if (cm != null) cm.setListener(null);
        }
    }

    @Override
    public boolean onBack() {
        nav.showMenu(null);
        return true;
    }

    @Override
    public void onInsets(int l, int t, int r, int b) {
        padding.apply(l, t, r, b);
    }
}
