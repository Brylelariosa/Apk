package com.hazardyard.game.ui;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.hazardyard.game.render.Palette;
import com.hazardyard.game.settings.GameSettings;

/** Entry points to Customize HUD and Controls, plus graphics and sound. Every change is applied and saved immediately. */
final class SettingsScreen implements Screen {
    private final Navigator nav;
    private final FrameLayout root;
    private final ScreenPadding padding;

    SettingsScreen(Context c, Navigator navigator) {
        nav = navigator;
        final GameSettings settings = navigator.settings();
        root = new FrameLayout(c);
        root.addView(new BackdropView(c), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout content = new LinearLayout(c);
        content.setOrientation(LinearLayout.HORIZONTAL);
        content.setGravity(Gravity.CENTER_VERTICAL);
        padding = new ScreenPadding(content, c, 40, 24, 40, 24);
        root.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout hero = Ui.column(c);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        content.addView(hero, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 24, 0, c));
        hero.addView(Ui.label(c, "Settings", 44f, Palette.TEXT, true));
        hero.addView(new BackdropView.StripeBar(c), Ui.lp(Ui.dp(c, 130), Ui.dp(c, 9), 0f, 0, 10, 0, 0, c));
        hero.addView(Ui.label(c, "Arrange the HUD wherever your thumbs are comfortable, choose how the controls work, "
                + "and tune graphics and sound for your phone.", 15f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 14));

        ScrollView scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        content.addView(scroll, Ui.lp(Ui.dp(c, 340), ViewGroup.LayoutParams.MATCH_PARENT, 0f, 0, 0, 0, 0, c));
        LinearLayout panel = Ui.panel(c);
        scroll.addView(panel, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        panel.addView(Ui.label(c, "Controls and HUD", 16f, Palette.TEXT, true));
        Button hud = Ui.button(c, "Customize HUD", true);
        hud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nav.showHudEditor();
            }
        });
        panel.addView(hud, Ui.fillWidth(c, 8));
        panel.addView(Ui.label(c, "Move and resize the sticks and buttons, the minimap, scores, ammo, health bar and kill feed.", 11f,
                Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));
        Button controlsButton = Ui.button(c, "Controls", false);
        controlsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nav.showControlsSettings();
            }
        });
        panel.addView(controlsButton, Ui.fillWidth(c, 10));
        panel.addView(Ui.label(c, "Fixed or floating sticks, how firing works, the dead zone, the aim line and control opacity.", 11f,
                Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));

        panel.addView(Ui.label(c, "Graphics", 16f, Palette.TEXT, true), Ui.fillWidth(c, 18));
        panel.addView(Ui.label(c, "3D soldier and weapon models", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 6));
        SegmentedControl models = new SegmentedControl(c, new String[] {"On", "Off"}, settings.models3d ? 0 : 1,
                new SegmentedControl.OnChange() {
                    @Override
                    public void onChange(int i) {
                        settings.models3d = i == 0;
                        nav.saveSettings();
                    }
                });
        panel.addView(models, Ui.fillWidth(c, 4));
        panel.addView(Ui.label(c, "Turn off if the game runs slowly on your phone.", 11f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));

        panel.addView(Ui.label(c, "Graphics quality", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 12));
        SegmentedControl quality = new SegmentedControl(c, new String[] {"Auto", "High", "Light"}, settings.quality,
                new SegmentedControl.OnChange() {
                    @Override
                    public void onChange(int i) {
                        settings.quality = i;
                        settings.autoLevel = 0;
                        nav.saveSettings();
                    }
                });
        panel.addView(quality, Ui.fillWidth(c, 4));
        panel.addView(Ui.label(c, "Auto lowers the effects only when your phone clearly cannot keep up for a while, and raises "
                + "them again when it can. High never lowers anything. Light always uses the simple look.", 11f,
                Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));

        panel.addView(Ui.label(c, "Sound", 16f, Palette.TEXT, true), Ui.fillWidth(c, 18));
        SegmentedControl soundOn = new SegmentedControl(c, new String[] {"On", "Off"}, settings.soundOn ? 0 : 1,
                new SegmentedControl.OnChange() {
                    @Override
                    public void onChange(int i) {
                        settings.soundOn = i == 0;
                        nav.saveSettings();
                    }
                });
        panel.addView(soundOn, Ui.fillWidth(c, 6));
        SliderRow volume = new SliderRow(c, "Volume", 0f, 1f, settings.volume, SliderRow.percent(), new SliderRow.OnValue() {
            @Override
            public void onValue(float v) {
                settings.volume = v;
            }
        });
        panel.addView(volume, Ui.fillWidth(c, 8));
        // Saving on every slider tick would hammer the disk; save when the page closes instead.

        Button back = Ui.button(c, "Back", false);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nav.saveSettings();
                nav.showMenu(null);
            }
        });
        panel.addView(back, Ui.fillWidth(c, 18));
    }

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShow() {
        // nothing to start
    }

    @Override
    public void onHide() {
        nav.saveSettings();
    }

    @Override
    public boolean onBack() {
        nav.showMenu(null);
        return true;
    }

    @Override
    public void onInsets(int l, int t, int r, int b) {
        padding.apply(l, t, r, b);
    }
}
