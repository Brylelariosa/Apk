package com.hazardyard.game.bot;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.TileMap;

/**
 * Walkability view of a {@link TileMap} for bots: which tiles can be stood on, and whether a
 * straight walk for a circle of a given radius is free. Immutable after construction and safe to
 * share between bots.
 */
public final class NavGrid {
    public final TileMap map;
    public final int width;
    public final int height;
    private final boolean[] walk;

    public NavGrid(TileMap map) {
        this.map = map;
        this.width = map.width;
        this.height = map.height;
        this.walk = new boolean[width * height];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) walk[y * width + x] = !map.isSolid(x, y);
        }
    }

    public boolean walkable(int tx, int ty) {
        return tx >= 0 && ty >= 0 && tx < width && ty < height && walk[ty * width + tx];
    }

    public int tileOf(float wx, float wy) {
        int tx = (int) Math.floor(wx / GameConfig.TILE);
        int ty = (int) Math.floor(wy / GameConfig.TILE);
        if (tx < 0) tx = 0;
        if (ty < 0) ty = 0;
        if (tx >= width) tx = width - 1;
        if (ty >= height) ty = height - 1;
        return ty * width + tx;
    }

    public float centerX(int tile) {
        return ((tile % width) + 0.5f) * GameConfig.TILE;
    }

    public float centerY(int tile) {
        return ((tile / width) + 0.5f) * GameConfig.TILE;
    }

    /** The walkable tile nearest to {@code tile} (itself when it is walkable), or -1 when the map has none. */
    public int nearestWalkable(int tile) {
        if (walk[tile]) return tile;
        int cx = tile % width;
        int cy = tile / width;
        int maxR = Math.max(width, height);
        for (int r = 1; r < maxR; r++) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    if (Math.max(Math.abs(dx), Math.abs(dy)) != r) continue;
                    if (walkable(cx + dx, cy + dy)) return (cy + dy) * width + cx + dx;
                }
            }
        }
        return -1;
    }

    /**
     * How far one can look from (x, y) along {@code angle} before the ground is blocked, in steps of
     * 6 units, up to {@code maxDist}. Used for smooth wall avoidance: it changes gradually with the
     * distance to the wall, unlike a yes/no test.
     */
    public float clearDistance(float x, float y, float angle, float maxDist) {
        float cx = (float) Math.cos(angle);
        float cy = (float) Math.sin(angle);
        for (float d = 6f; d <= maxDist; d += 6f) {
            if (map.isSolidAt(x + cx * d, y + cy * d)) return d - 6f;
        }
        return maxDist;
    }

    /**
     * True when a circle of radius {@code r} can walk the straight line from (x0,y0) to (x1,y1)
     * without touching anything that blocks movement (walls, crates, fences, pools).
     */
    public boolean lineClear(float x0, float y0, float x1, float y1, float r) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-3f) return !map.isSolidAt(x0, y0);
        float ux = dx / len;
        float uy = dy / len;
        float sx = -uy * r;
        float sy = ux * r;
        int steps = (int) Math.ceil(len / 8f);
        for (int i = 0; i <= steps; i++) {
            float t = i == steps ? len : i * 8f;
            float px = x0 + ux * t;
            float py = y0 + uy * t;
            if (map.isSolidAt(px, py) || map.isSolidAt(px + sx, py + sy) || map.isSolidAt(px - sx, py - sy)) return false;
        }
        return true;
    }
}
