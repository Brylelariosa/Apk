package com.hazardyard.game.render;

import com.hazardyard.game.core.MapLibrary;

/** The colours and small style choices that give each arena its own look. */
public final class MapTheme {
    // ground
    public final int floorA, floorB, grid, decal, accent, backdrop;
    // walls (top face, south face, west face)
    public final int wallTop, wallFront, wallSide, wallTrim;
    // crates
    public final int crateTop, crateFront, crateSide, crateDark;
    // pools / canals
    public final int waterDeep, waterLight, waterEdge;
    /** Draw hazard stripes along the edge of the pools. */
    public final boolean stripes;
    public final int stripeA, stripeB;
    public final int fence;

    private MapTheme(int floorA, int floorB, int grid, int decal, int accent, int backdrop,
                     int wallTop, int wallFront, int wallSide, int wallTrim,
                     int crateTop, int crateFront, int crateSide, int crateDark,
                     int waterDeep, int waterLight, int waterEdge, boolean stripes, int stripeA, int stripeB, int fence) {
        this.floorA = floorA;
        this.floorB = floorB;
        this.grid = grid;
        this.decal = decal;
        this.accent = accent;
        this.backdrop = backdrop;
        this.wallTop = wallTop;
        this.wallFront = wallFront;
        this.wallSide = wallSide;
        this.wallTrim = wallTrim;
        this.crateTop = crateTop;
        this.crateFront = crateFront;
        this.crateSide = crateSide;
        this.crateDark = crateDark;
        this.waterDeep = waterDeep;
        this.waterLight = waterLight;
        this.waterEdge = waterEdge;
        this.stripes = stripes;
        this.stripeA = stripeA;
        this.stripeB = stripeB;
        this.fence = fence;
    }

    private static final MapTheme[] THEMES = new MapTheme[MapLibrary.COUNT];

    static {
        // Hazard Yard: cool concrete, yellow hazard markings, toxic green pools.
        THEMES[MapLibrary.HAZARD_YARD] = new MapTheme(
                0xFF27313C, 0xFF2C3744, 0xFF212A34, 0xFF3B4958, 0xFFF2C230, 0xFF0E1319,
                0xFF93A4BE, 0xFF566B88, 0xFF3D4D64, 0xFF2A3445,
                0xFFDDA760, 0xFFB27A35, 0xFF86571F, 0xFF603E14,
                0xFF1B6A3B, 0xFF3DC46E, 0xFF8DF2AB, true, 0xFFF2C230, 0xFF1A1D22, 0xFFC4CEDC);
        // Dockside Warehouse: dark slab, steel containers, blue canal.
        THEMES[MapLibrary.DOCKSIDE] = new MapTheme(
                0xFF2A2E37, 0xFF2F343E, 0xFF242831, 0xFF3D4452, 0xFF54B6F5, 0xFF0D1117,
                0xFF7E98B4, 0xFF4E6A89, 0xFF354B63, 0xFF273445,
                0xFFCFA063, 0xFFA87740, 0xFF7C5326, 0xFF593A18,
                0xFF123B66, 0xFF2F88CC, 0xFF93D2FF, false, 0xFF54B6F5, 0xFF1A1D22, 0xFFB5C3D6);
        // Toxic Foundry: warm dark metal, orange glow, bright toxic moat.
        THEMES[MapLibrary.FOUNDRY] = new MapTheme(
                0xFF2B2624, 0xFF312B28, 0xFF251F1D, 0xFF4B3B34, 0xFFFF8A3D, 0xFF0F0C0B,
                0xFFA39690, 0xFF6A5D58, 0xFF4B403C, 0xFF372E2B,
                0xFFE29C58, 0xFFB86A2F, 0xFF8A4A1F, 0xFF5E3112,
                0xFF135D2E, 0xFF55F585, 0xFFB9FFCC, true, 0xFFFF8A3D, 0xFF1A1512, 0xFFC9BCB4);
        // Ruined Outpost: sand and sandstone, turquoise oasis.
        THEMES[MapLibrary.OUTPOST] = new MapTheme(
                0xFF7A6A4A, 0xFF807050, 0xFF6E6043, 0xFF94835C, 0xFFE8C26A, 0xFF1A150D,
                0xFFDCC590, 0xFFB69E6C, 0xFF8D7751, 0xFF6B5A3B,
                0xFFA87444, 0xFF875A2C, 0xFF65411F, 0xFF472C12,
                0xFF0F6D72, 0xFF39C7C6, 0xFFB7F3F0, false, 0xFFE8C26A, 0xFF1A1D22, 0xFF584A33);
        // Bunker Complex: cold steel, green indicator lights.
        THEMES[MapLibrary.BUNKER] = new MapTheme(
                0xFF1F262D, 0xFF232B33, 0xFF1A2026, 0xFF334049, 0xFF6DD47E, 0xFF0A0E12,
                0xFF8393A4, 0xFF4F5D6C, 0xFF38444F, 0xFF27313B,
                0xFF8A9E57, 0xFF66773D, 0xFF4B5A2C, 0xFF343F1E,
                0xFF123B66, 0xFF2F88CC, 0xFF93D2FF, false, 0xFF6DD47E, 0xFF1A1D22, 0xFFB5C3D6);
        // Rotunda Plaza: pale marble floor, slate walls, copper accents.
        THEMES[MapLibrary.ROTUNDA] = new MapTheme(
                0xFF3A3F4A, 0xFF404652, 0xFF343944, 0xFF565D6C, 0xFFE0A24A, 0xFF0F1116,
                0xFFB9C3D6, 0xFF7C89A3, 0xFF59657D, 0xFF3F4A5F,
                0xFFD8A765, 0xFFB07A3A, 0xFF865A25, 0xFF5E3D14,
                0xFF123B66, 0xFF2F88CC, 0xFF93D2FF, false, 0xFFE0A24A, 0xFF1A1D22, 0xFFC7D0DE);
        // Silo Yard: rust-brown ground, grey-green silos, safety orange.
        THEMES[MapLibrary.SILO_YARD] = new MapTheme(
                0xFF2D2C27, 0xFF33322C, 0xFF272620, 0xFF494636, 0xFFFF9A2E, 0xFF0E0D0A,
                0xFFA8B0A0, 0xFF6F7B6C, 0xFF4D584B, 0xFF353E34,
                0xFFC9955A, 0xFF9F6B35, 0xFF744A21, 0xFF52330F,
                0xFF2B6B22, 0xFF7CE04A, 0xFFCFFFB0, true, 0xFFFF9A2E, 0xFF1A1812, 0xFFC8CCC0);
        // Diamond Hall: deep violet steel, cyan light strips.
        THEMES[MapLibrary.DIAMOND_HALL] = new MapTheme(
                0xFF232335, 0xFF28283C, 0xFF1E1E2E, 0xFF3A3A55, 0xFF5CE1E6, 0xFF0B0B14,
                0xFF9A9CC8, 0xFF5C5E8C, 0xFF42446A, 0xFF2D2E4C,
                0xFF8E7FC4, 0xFF6D5FA3, 0xFF4E4380, 0xFF362D5C,
                0xFF123B66, 0xFF2F88CC, 0xFF93D2FF, false, 0xFF5CE1E6, 0xFF1A1D22, 0xFFB9BCDD);
    }

    static {
        // Battleground: dusty earth and sun-bleached concrete, moss-green accents, clean blue water.
        THEMES[MapLibrary.BATTLEGROUND] = new MapTheme(
                0xFF2E3A2C, 0xFF334031, 0xFF283325, 0xFF445340, 0xFF8BD450, 0xFF0C100B,
                0xFFA7B39C, 0xFF6D7C67, 0xFF4A5847, 0xFF343F32,
                0xFFC79B5D, 0xFF9E7640, 0xFF745423, 0xFF523914,
                0xFF1B5C86, 0xFF3FA3DA, 0xFF9ADCFF, false, 0xFF8BD450, 0xFF1A1D22, 0xFFBFC8B4);
    }

    public static MapTheme of(int mapId) {
        return THEMES[MapLibrary.clampId(mapId)];
    }
}
