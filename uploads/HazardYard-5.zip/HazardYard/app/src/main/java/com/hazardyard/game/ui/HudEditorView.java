package com.hazardyard.game.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.input.ControlGeometry;
import com.hazardyard.game.render.ControlsRenderer;
import com.hazardyard.game.render.HudRenderer;
import com.hazardyard.game.render.Palette;
import com.hazardyard.game.settings.ControlSettings;
import com.hazardyard.game.settings.GameSettings;

/**
 * "Customize HUD": a full-screen editor for where everything on the screen sits and how big it is, and
 * nothing else. Drag any element (the sticks and buttons, the minimap, the timer and scores, the ammo
 * readout, the health bar, the kill feed) to move it, pinch it or use the size slider to resize it, and
 * reset the whole layout to the default. Elements are shown exactly as they look in a match; anything
 * that overlaps something else is outlined in red. How the controls <em>behave</em> (fixed or floating
 * sticks, firing, dead zone, opacity) is not here: that is the separate Controls screen.
 *
 * <p>Works on a copy: Save writes only the layout back, Cancel throws the changes away. Used both from
 * Settings and over a paused match.
 */
final class HudEditorView extends FrameLayout {
    interface Listener {
        /** The editor finished; {@code saved} tells whether the changes were kept. */
        void onClose(boolean saved);
    }

    private final GameSettings live;
    private final ControlSettings work = new ControlSettings();
    private final Listener listener;
    private final float density;

    private final EditorCanvas canvas;
    private final SliderRow sizeRow;
    private final FrameLayout.LayoutParams barParams;
    private final FrameLayout.LayoutParams sizeParams;

    private int selected = -1;
    private int insetL, insetT, insetR, insetB;

    HudEditorView(Context c, GameSettings settings, Listener listener) {
        super(c);
        this.live = settings;
        this.listener = listener;
        this.density = c.getResources().getDisplayMetrics().density;
        work.copyFrom(settings.controls);
        setClickable(true);

        canvas = new EditorCanvas(c);
        addView(canvas, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- top bar: Cancel, Reset layout, Save ----
        LinearLayout bar = Ui.row(c);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.rounded(c, 0xE6121A23, 0xFF3A4757, 14f, 1.5f));
        bar.setPadding(Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8), Ui.dp(c, 6));
        Button cancel = Ui.smallButton(c, "Cancel", false);
        Button reset = Ui.smallButton(c, "Reset layout", false);
        Button save = Ui.smallButton(c, "Save", true);
        bar.addView(cancel, Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(c, 40), 0f, 0, 0, 6, 0, c));
        bar.addView(reset, Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(c, 40), 0f, 0, 0, 6, 0, c));
        bar.addView(save, Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(c, 40), 0f, 0, 0, 0, 0, c));
        barParams = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        addView(bar, barParams);

        // ---- size of the selected element ----
        sizeRow = new SliderRow(c, "Tap an element to select it", ControlSettings.SCALE_MIN, ControlSettings.SCALE_MAX, 1f,
                SliderRow.percent(), new SliderRow.OnValue() {
                    @Override
                    public void onValue(float value) {
                        if (selected >= 0) {
                            work.scale[selected] = value;
                            canvas.relayout();
                        }
                    }
                });
        sizeRow.setBackground(Ui.rounded(c, 0xE6121A23, 0xFF3A4757, 14f, 1.5f));
        sizeRow.setPadding(Ui.dp(c, 14), Ui.dp(c, 8), Ui.dp(c, 14), Ui.dp(c, 4));
        sizeRow.setSliderEnabled(false);
        sizeParams = new LayoutParams(Ui.dp(c, 300), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        addView(sizeRow, sizeParams);

        cancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(false);
            }
        });
        save.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(true);
            }
        });
        reset.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                work.resetLayout();           // positions and sizes only: control options are not touched here
                select(selected);
                canvas.relayout();
            }
        });
        applyMargins();
    }

    /** Safe-area insets in pixels: the bars and the layout stay clear of the camera cutout. */
    void setInsets(int l, int t, int r, int b) {
        insetL = l;
        insetT = t;
        insetR = r;
        insetB = b;
        applyMargins();
        canvas.relayout();
    }

    private void applyMargins() {
        int gap = Math.round(8f * density);
        barParams.topMargin = insetT + gap;
        barParams.leftMargin = insetL;
        barParams.rightMargin = insetR;
        sizeParams.topMargin = insetT + gap + Math.round(58f * density);
        requestLayout();
    }

    /** Back button: leaves the editor, discarding the changes. */
    boolean handleBack() {
        finish(false);
        return true;
    }

    private void finish(boolean saved) {
        if (saved) {
            work.sanitize();
            live.controls.copyLayoutFrom(work);      // the layout only; the control options stay as they are
        }
        listener.onClose(saved);
    }

    private void select(int element) {
        if (element == ControlSettings.FIRE && !work.fireButtonEnabled()) element = -1;
        selected = element;
        if (element < 0) {
            sizeRow.setTitle("Tap an element to select it");
            sizeRow.setSliderEnabled(false);
        } else {
            sizeRow.setTitle(ControlSettings.nameOf(element) + " size");
            sizeRow.setValue(work.scale[element]);
            sizeRow.setSliderEnabled(true);
        }
        canvas.invalidate();
    }

    /** A made-up match to draw the HUD widgets from: four fighters, a kill feed, a rifle with some ammo used. */
    private static GameState buildSample() {
        GameState st = new GameState(MapLibrary.get(MapLibrary.DEFAULT_ID), 0);
        String[] names = {"You", "Nova", "Rex", "Viper"};
        int[] kills = {5, 7, 3, 2};
        for (int i = 0; i < 4; i++) {
            Player p = st.players[i];
            p.connected = true;
            p.alive = true;
            p.name = names[i];
            p.kills = kills[i];
            p.health = 100;
            p.x = p.rx = st.map.worldW * (0.2f + 0.2f * i);
            p.y = p.ry = st.map.worldH * (0.35f + 0.1f * (i % 2));
        }
        Player me = st.players[0];
        me.health = 76;
        me.weapon.equip(WeaponDef.ALL[WeaponDef.RIFLE]);
        me.weapon.ammo = 21;
        st.phase = GameState.PHASE_PLAYING;
        st.timeLeft = 142.4f;
        st.effects.addKill(1, 2, WeaponDef.SMG);
        st.effects.addKill(0, 3, WeaponDef.RIFLE);
        st.effects.noise(1, st.map.worldW * 0.6f, st.map.worldH * 0.45f);
        return st;
    }

    // ------------------------------------------------------------------ the drawing / dragging surface

    private final class EditorCanvas extends View {
        private final ControlGeometry geom = new ControlGeometry();
        private final ControlsRenderer controls = new ControlsRenderer();
        private final HudRenderer hud = new HudRenderer();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private GameState sample;
        private boolean dragging;
        private boolean pinching;
        private int dragPointer = -1;
        private float grabDx, grabDy;
        private float pinchStartDist, pinchStartScale;

        EditorCanvas(Context c) {
            super(c);
        }

        void relayout() {
            if (getWidth() > 0) geom.compute(work, getWidth(), getHeight(), density, insetL, insetT, insetR, insetB);
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            relayout();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            if (sample == null) sample = buildSample();
            c.drawColor(0xF4090D12);
            // grid
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1f);
            paint.setColor(0x14FFFFFF);
            float step = 40f * density;
            for (float x = insetL % step; x < w; x += step) c.drawLine(x, 0f, x, h, paint);
            for (float y = insetT % step; y < h; y += step) c.drawLine(0f, y, w, y, paint);
            // safe area
            paint.setColor(0x33FFFFFF);
            paint.setStrokeWidth(1.5f);
            rect.set(insetL + 1f, insetT + 1f, w - insetR - 1f, h - insetB - 1f);
            c.drawRoundRect(rect, 10f * density, 10f * density, paint);

            hud.drawEditorWidgets(c, sample, geom, work, selected, density);
            controls.drawIdle(c, geom, work, selected, density);
            drawClashRings(c);
            drawHint(c, w, h);
        }

        /** A red ring around a round control that overlaps something else. */
        private void drawClashRings(Canvas c) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1.8f * density);
            paint.setColor(Palette.withAlpha(Palette.BAD, 220));
            for (int i = 0; i < ControlSettings.CONTROL_COUNT; i++) {
                if (i == ControlSettings.FIRE && !work.fireButtonEnabled()) continue;
                if (i == selected || !HudRenderer.clashes(geom, work, i)) continue;
                c.drawCircle(geom.cx[i], geom.cy[i], geom.r[i] + 5f * density, paint);
            }
        }

        private void drawHint(Canvas c, float w, float h) {
            float mid = insetL + (w - insetL - insetR) * 0.5f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x66FFFFFF);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(12f * density);
            c.drawText("Drag an element to move it. Pinch it, or use the slider, to resize.", mid, h * 0.5f + 20f * density, paint);
            paint.setColor(Palette.withAlpha(Palette.BAD, 200));
            paint.setTextSize(11f * density);
            c.drawText("Red outline: it overlaps something else.", mid, h * 0.5f + 38f * density, paint);
            paint.setTextAlign(Paint.Align.LEFT);
        }

        /** The element under the finger: the one whose centre is closest, measured against its own size, so a small button wins over a big panel. */
        private int hitTest(float x, float y) {
            int best = -1;
            float bestScore = Float.MAX_VALUE;
            float minGrab = 30f * density;
            for (int i = 0; i < ControlSettings.COUNT; i++) {
                if (i == ControlSettings.FIRE && !work.fireButtonEnabled()) continue;
                float dx = x - geom.cx[i];
                float dy = y - geom.cy[i];
                float score;
                if (ControlSettings.isControl(i)) {
                    float d = (float) Math.sqrt(dx * dx + dy * dy);
                    if (d > Math.max(geom.r[i] * 1.2f, minGrab)) continue;
                    score = d / Math.max(1f, geom.r[i]);
                } else {
                    float grab = 8f * density;
                    if (Math.abs(dx) > geom.hw[i] + grab || Math.abs(dy) > geom.hh[i] + grab) continue;
                    score = Math.max(Math.abs(dx) / geom.hw[i], Math.abs(dy) / geom.hh[i]) * 1.2f + 0.2f;
                }
                if (score < bestScore) {
                    bestScore = score;
                    best = i;
                }
            }
            return best;
        }

        private float pointerDistance(MotionEvent e) {
            float dx = e.getX(0) - e.getX(1);
            float dy = e.getY(0) - e.getY(1);
            return (float) Math.sqrt(dx * dx + dy * dy);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    float x = e.getX();
                    float y = e.getY();
                    int hit = hitTest(x, y);
                    select(hit);
                    dragging = hit >= 0;
                    pinching = false;
                    if (dragging) {
                        dragPointer = e.getPointerId(0);
                        grabDx = geom.cx[hit] - x;
                        grabDy = geom.cy[hit] - y;
                    }
                    return true;
                }
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (selected >= 0 && e.getPointerCount() == 2) {
                        pinching = true;
                        dragging = false;
                        pinchStartDist = Math.max(1f, pointerDistance(e));
                        pinchStartScale = work.scale[selected];
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (pinching && e.getPointerCount() >= 2 && selected >= 0) {
                        float s = pinchStartScale * pointerDistance(e) / pinchStartDist;
                        s = Math.max(ControlSettings.SCALE_MIN, Math.min(ControlSettings.SCALE_MAX, s));
                        work.scale[selected] = s;
                        sizeRow.setValue(s);
                        relayout();
                    } else if (dragging && selected >= 0) {
                        for (int i = 0; i < e.getPointerCount(); i++) {
                            if (e.getPointerId(i) != dragPointer) continue;
                            work.x[selected] = geom.normalizeX(selected, e.getX(i) + grabDx);
                            work.y[selected] = geom.normalizeY(selected, e.getY(i) + grabDy);
                            relayout();
                            break;
                        }
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_UP:
                    pinching = false;
                    dragging = false;
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    pinching = false;
                    dragging = false;
                    return true;
                default:
                    return true;
            }
        }
    }
}
