package com.hazardyard.game.core;

/**
 * Immutable description of a weapon. All weapons share the same firing code; only these numbers
 * differ, so adding a weapon means adding one entry to {@link #ALL}.
 */
public final class WeaponDef {
    public static final int PISTOL = 0;
    public static final int RIFLE = 1;
    public static final int SHOTGUN = 2;
    public static final int SMG = 3;
    public static final int SNIPER = 4;
    public static final int MAGNUM = 5;
    public static final int PLASMA = 6;
    public static final int LMG = 7;

    /** Bullet look: a thin tracer, or a glowing energy bolt. */
    public static final int STYLE_BULLET = 0;
    public static final int STYLE_ENERGY = 1;

    /** Reload style: the empty magazine is swapped; its rounds all arrive when the new one seats. */
    public static final int RELOAD_MAG = 0;
    /** Reload style: rounds go in one at a time (a tube-fed shotgun), each one counts as soon as it is in. */
    public static final int RELOAD_SHELLS = 1;

    public final int id;
    public final String name;
    public final int damage;
    /** Seconds between two shots. */
    public final float fireInterval;
    public final int magSize;
    /**
     * Seconds a complete reload from empty takes. For {@link #RELOAD_MAG} this is the whole swap; for
     * {@link #RELOAD_SHELLS} it is {@link #loadLead} + one {@link #loadPerRound} per round + {@link #loadTail}.
     */
    public final float reloadTime;
    /** {@link #RELOAD_MAG} or {@link #RELOAD_SHELLS}. */
    public final int reloadStyle;
    /** Magazine reloads: share of the reload (0..1) after which the fresh magazine is in and the ammo is back. */
    public final float seatFraction;
    /** Shell reloads: seconds before the first round goes in, per round, and after the last one (closing the action). */
    public final float loadLead, loadPerRound, loadTail;
    /**
     * Seconds after a shot until the weapon's mechanical action is heard (pump, bolt, hammer and
     * cylinder); 0 for guns that cycle on their own. Presentation only.
     */
    public final float actionDelay;
    /** World units per second. */
    public final float projectileSpeed;
    /** Half-angle of the random cone in radians. */
    public final float spread;
    /** World units a bullet travels before it disappears. */
    public final float range;
    /**
     * True: keeps firing at {@link #fireInterval} while the aim stick is held. False: one shot per
     * trigger pull. Every built-in gun is automatic, so holding the stick always shoots.
     */
    public final boolean automatic;
    /** Fast spray weapon (bots shoot it in bursts instead of holding the trigger down). */
    public final boolean rapidFire;
    public final int pellets;

    // presentation only
    public final float barrelLength;
    public final float barrelWidth;
    public final float bulletRadius;
    public final int color;
    public final int style;
    /**
     * Camera zoom while this gun is equipped, a multiplier on the standard view: 1 is the standard
     * view, below 1 pulls the camera back (sees further, for long-range guns), above 1 moves it in
     * closer (for close-range guns). The camera eases between the zooms when the gun changes.
     */
    public final float zoom;

    private WeaponDef(int id, String name, int damage, float fireInterval, int magSize, float reloadTime,
                      float projectileSpeed, float spreadDegrees, float range, boolean automatic, int pellets,
                      float barrelLength, float barrelWidth, float bulletRadius, int color, int style, float zoom,
                      int reloadStyle, float seatFraction, float loadLead, float loadPerRound, float loadTail,
                      float actionDelay) {
        this.id = id;
        this.name = name;
        this.damage = damage;
        this.fireInterval = fireInterval;
        this.magSize = magSize;
        this.reloadStyle = reloadStyle;
        this.seatFraction = MathUtil.clamp(seatFraction, 0.1f, 0.95f);
        this.loadLead = loadLead;
        this.loadPerRound = loadPerRound;
        this.loadTail = loadTail;
        this.actionDelay = actionDelay;
        this.reloadTime = reloadStyle == RELOAD_SHELLS ? loadLead + magSize * loadPerRound + loadTail : reloadTime;
        this.projectileSpeed = projectileSpeed;
        this.spread = (float) Math.toRadians(spreadDegrees);
        this.range = range;
        this.automatic = automatic;
        this.rapidFire = fireInterval < 0.2f;
        this.pellets = pellets;
        this.barrelLength = barrelLength;
        this.barrelWidth = barrelWidth;
        this.bulletRadius = bulletRadius;
        this.color = color;
        this.style = style;
        this.zoom = MathUtil.clamp(zoom, GameConfig.ZOOM_MIN, GameConfig.ZOOM_MAX);
    }

    public static final WeaponDef[] ALL = {
        // Reload numbers: MAG weapons give (total seconds, share at which the new magazine seats); the shotgun
        // gives (lead, seconds per shell, tail). The last number is the delay of the mechanical action sound.
        //        id       name             dmg  interval mag  reload speed  spread range auto   pellets barrel width bullet color        style         zoom  rStyle      seat  lead  /rnd  tail  action
        new WeaponDef(PISTOL,  "Pistol",          20, 0.22f, 12, 1.00f,  560f, 1.5f,  420f, true,  1,  9f,  4f, 2.5f, 0xFFFFE08A, STYLE_BULLET, 1.00f, RELOAD_MAG,    0.62f, 0f,    0f,    0f,    0f),
        new WeaponDef(RIFLE,   "Assault Rifle",   15, 0.12f, 30, 1.75f,  660f, 3.0f,  540f, true,  1, 15f,  4f, 2.5f, 0xFFFFB347, STYLE_BULLET, 0.90f, RELOAD_MAG,    0.60f, 0f,    0f,    0f,    0f),
        new WeaponDef(SHOTGUN, "Shotgun",          9, 0.85f,  6, 0f,     520f, 8.0f,  260f, true,  8, 13f,  6f, 2.2f, 0xFFFF7A59, STYLE_BULLET, 1.15f, RELOAD_SHELLS, 0f,     0.50f, 0.42f, 0.45f, 0.34f),
        new WeaponDef(SMG,     "SMG",              8, 0.07f, 35, 1.55f,  600f, 6.0f,  330f, true,  1, 11f,  4f, 2.0f, 0xFF8DE0FF, STYLE_BULLET, 1.08f, RELOAD_MAG,    0.58f, 0f,    0f,    0f,    0f),
        new WeaponDef(SNIPER,  "Sniper Rifle",    70, 1.15f,  4, 2.60f, 1500f, 0.2f, 1100f, true,  1, 22f,  3f, 2.2f, 0xFFE6F0FF, STYLE_BULLET, 0.70f, RELOAD_MAG,    0.50f, 0f,    0f,    0f,    0.46f),
        new WeaponDef(MAGNUM,  "Magnum",          42, 0.50f,  6, 2.45f,  900f, 1.0f,  520f, true,  1, 10f,  5f, 2.8f, 0xFFFF9A5A, STYLE_BULLET, 0.92f, RELOAD_MAG,    0.66f, 0f,    0f,    0f,    0.20f),
        new WeaponDef(PLASMA,  "Plasma Rifle",   12, 0.09f, 40, 2.00f,  880f, 1.5f,  480f, true,  1, 14f,  5f, 3.4f, 0xFFB066FF, STYLE_ENERGY, 0.96f, RELOAD_MAG,    0.55f, 0f,    0f,    0f,    0f),
        new WeaponDef(LMG,     "Light MG",        12, 0.085f, 60, 3.30f, 640f, 5.0f,  480f, true,  1, 17f,  5f, 2.6f, 0xFFE8D36A, STYLE_BULLET, 0.86f, RELOAD_MAG,    0.62f, 0f,    0f,    0f,    0f),
    };

    /**
     * Seconds a reload takes when {@code ammoLeft} rounds are still in the gun: a magazine swap always
     * takes the same time, a shell reload only as long as the missing shells need.
     */
    public float reloadDuration(int ammoLeft) {
        if (reloadStyle == RELOAD_SHELLS) {
            int need = Math.max(1, magSize - Math.max(0, ammoLeft));
            return loadLead + need * loadPerRound + loadTail;
        }
        return reloadTime;
    }

    /** True for guns that reload round by round. */
    public boolean loadsRoundByRound() {
        return reloadStyle == RELOAD_SHELLS;
    }

    /** Bounds-safe lookup for ids that came off the network. */
    public static WeaponDef byId(int id) {
        return (id >= 0 && id < ALL.length) ? ALL[id] : ALL[PISTOL];
    }

    /** How far to the shooter's right the barrel axis sits (matches the soldier model). */
    public static final float MUZZLE_SIDE = 0.8f;

    /** Distance from the shooter's centre to the muzzle, along the aim. */
    public float muzzleReach() {
        return GameConfig.PLAYER_RADIUS + barrelLength;
    }

    /** World x of the muzzle of a shooter at (x, ·) aiming along {@code angle}. */
    public float muzzleX(float x, float angle) {
        return x + (float) Math.cos(angle) * muzzleReach() - (float) Math.sin(angle) * MUZZLE_SIDE;
    }

    /** World y of the muzzle of a shooter at (·, y) aiming along {@code angle}. */
    public float muzzleY(float y, float angle) {
        return y + (float) Math.sin(angle) * muzzleReach() + (float) Math.cos(angle) * MUZZLE_SIDE;
    }

    /**
     * Spawns this weapon's pellets into {@code pool}. Bullets leave from the muzzle, the tip of the
     * barrel the soldier is holding. When a wall stands between the body and the muzzle (the
     * shooter is pressed against it) they start at the wall face instead, so a bullet can never
     * appear on the far side of a wall. Host and clients call this with identical arguments and
     * therefore get identical bullets.
     *
     * @return number of bullets actually spawned
     */
    public int spawn(ProjectilePool pool, CollisionSystem col, int ownerId, float x, float y, float angle,
                     int seed, int baseId) {
        float mx = muzzleX(x, angle);
        float my = muzzleY(y, angle);
        float cut = col.raycast(x, y, mx, my);
        if (cut >= 0f) {
            float k = Math.max(0f, cut - 0.02f);
            mx = x + (mx - x) * k;
            my = y + (my - y) * k;
        }
        XorShift rng = pool.rng;
        rng.setSeed(seed);
        int spawned = 0;
        for (int i = 0; i < pellets; i++) {
            Projectile p = pool.acquire();
            if (p == null) break;
            float a = angle + rng.nextSigned() * spread;
            p.x = mx;
            p.y = my;
            p.px = mx;
            p.py = my;
            p.vx = (float) Math.cos(a) * projectileSpeed;
            p.vy = (float) Math.sin(a) * projectileSpeed;
            p.remaining = range;
            p.id = (baseId + i) & 0xFFFF;
            p.owner = ownerId;
            p.weaponId = id;
            p.damage = damage;
            p.radius = bulletRadius;
            spawned++;
        }
        return spawned;
    }
}
