package com.hazardyard.game.core;

/**
 * Per-player weapon state: which weapon, ammunition, cooldown and reload progress.
 *
 * <p>Reloading is not instant and is not the same for every gun. A magazine gun spends its reload
 * taking the old magazine out, putting a new one in (the ammunition comes back at that moment, see
 * {@link WeaponDef#seatFraction}) and chambering a round; it cannot fire before the reload is over.
 * A shotgun loads one shell at a time, each shell counts as soon as it is in, and the reload can be
 * cut short once at least one shell is loaded. {@link #cancelReload()} aborts a reload at any time and
 * keeps whatever already made it into the gun.
 */
public final class Weapon {
    public WeaponDef def = WeaponDef.ALL[WeaponDef.PISTOL];
    public int ammo = def.magSize;
    /** Seconds until the next shot is allowed. */
    public float cooldown;
    public boolean reloading;
    /** Seconds the current reload has been running (host side). */
    public float reloadElapsed;
    /** Seconds the current reload will take in total (host side). */
    public float reloadTotal;
    /** 0..1 progress of the current reload, for the HUD (host computes it, clients receive it). */
    public float reloadFraction;

    /** Magazine reloads: the fresh magazine is already in (ammunition restored), the gun is being chambered. */
    private boolean seated;
    /** Shell reloads: rounds put in so far during this reload. */
    private int loaded;
    /** The reload started on an empty gun: nothing is chambered, so it cannot be interrupted by firing. */
    private boolean startedEmpty;

    public void equip(WeaponDef d) {
        def = d;
        ammo = d.magSize;
        cooldown = 0f;
        clearReload();
    }

    private void clearReload() {
        reloading = false;
        reloadElapsed = 0f;
        reloadTotal = 0f;
        reloadFraction = 0f;
        seated = false;
        loaded = 0;
        startedEmpty = false;
    }

    public void update(float dt) {
        if (cooldown > 0f) cooldown -= dt;
        if (!reloading) return;
        reloadElapsed += dt;
        if (def.reloadStyle == WeaponDef.RELOAD_SHELLS) {
            // Rounds that have gone in by now; each one is usable the moment it is in.
            while (ammo < def.magSize && reloadElapsed >= def.loadLead + (loaded + 1) * def.loadPerRound) {
                loaded++;
                ammo++;
            }
        } else if (!seated && reloadElapsed >= reloadTotal * def.seatFraction) {
            seated = true;
            ammo = def.magSize;
        }
        if (reloadElapsed >= reloadTotal) {
            // Whatever is still outstanding (a very long frame) arrives with the end of the reload.
            ammo = def.magSize;
            clearReload();
        } else {
            reloadFraction = reloadElapsed / reloadTotal;
        }
    }

    public boolean canFire() {
        return !reloading && ammo > 0 && cooldown <= 0f;
    }

    /** Book-keeping after a shot left the barrel. The caller decides about an automatic reload (see GameWorld). */
    public void onFired() {
        ammo--;
        // Adding (instead of assigning) keeps the leftover part of the last tick, so the effective
        // rate matches fireInterval even though time advances in fixed steps.
        cooldown += def.fireInterval;
    }

    /** Starts a reload. Returns false when the gun is full or already reloading. */
    public boolean startReload() {
        if (reloading || ammo >= def.magSize) return false;
        reloading = true;
        reloadElapsed = 0f;
        reloadTotal = def.reloadDuration(ammo);
        reloadFraction = 0f;
        seated = false;
        loaded = 0;
        startedEmpty = ammo <= 0;
        return true;
    }

    /** Aborts a running reload. Rounds already loaded stay; a magazine that was not seated yet changes nothing. */
    public void cancelReload() {
        if (reloading) clearReload();
    }

    /**
     * True while firing may cut the reload short: there is a round in the gun and (for magazine guns)
     * one is already chambered, so the gun is usable right away. A magazine gun that started empty has
     * to finish its reload first.
     */
    public boolean canInterruptReload() {
        if (!reloading || ammo <= 0) return false;
        return def.reloadStyle == WeaponDef.RELOAD_SHELLS || !startedEmpty;
    }

    /** Shell reloads: rounds loaded so far in the current reload. */
    public int roundsLoadedThisReload() {
        return loaded;
    }
}
