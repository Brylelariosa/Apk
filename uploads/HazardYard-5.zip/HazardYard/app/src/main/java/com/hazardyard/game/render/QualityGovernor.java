package com.hazardyard.game.render;

/**
 * Keeps the game smooth on weaker phones without spoiling the picture on good ones. It watches how
 * long rendered frames really take and steps the graphics down only when a phone clearly cannot keep
 * up for a good while, and back up again once it keeps up comfortably. Pure logic with no Android types,
 * so it is easy to test.
 *
 * <p>Levels: {@link #FULL} everything; {@link #LIGHT} no screen-edge shading, no floor grime, simpler
 * effects (the soldiers keep their 3D look); {@link #MINIMAL} additionally no shadows and flat soldiers.
 *
 * <p>Why it is cautious: the first seconds of a match are slow on every phone (code is still warming up,
 * pictures are being prepared), a single heavy moment is not a slow phone, and an earlier version that
 * dropped quickly and never came back left players stuck with flat circles for soldiers. So now:
 * <ul>
 *   <li>the first {@link #START_GRACE} seconds are never judged;</li>
 *   <li>dropping to LIGHT needs the average frame to be well over budget for {@link #PATIENCE_LIGHT} seconds,
 *       dropping to the flat look needs it to be far over budget for {@link #PATIENCE_MINIMAL} seconds;</li>
 *   <li>after {@link #RISE_PATIENCE} seconds of comfortable frames the level goes back up one step, and if
 *       that step fails again straight away the lower level is kept for the rest of the session;</li>
 *   <li>the level is not carried over from one match to the next.</li>
 * </ul>
 */
public final class QualityGovernor {
    public static final int FULL = 0;
    public static final int LIGHT = 1;
    public static final int MINIMAL = 2;

    /** Frames slower than this many seconds (a hitch, a pause, a screen change) say nothing about the phone and are ignored. */
    private static final float HITCH = 0.25f;
    /** Seconds at the start of a session that are never judged (code warming up, pictures being prepared). */
    static final float START_GRACE = 5f;
    /** After any change, how long the new level gets to settle before it is judged. */
    private static final float SETTLE = 1.5f;
    /** Average frame time above this multiple of the target counts as struggling (FULL to LIGHT). */
    private static final float RATIO_LIGHT = 1.35f;
    /** ... and this multiple for the last resort (LIGHT to MINIMAL). */
    private static final float RATIO_MINIMAL = 1.9f;
    static final float PATIENCE_LIGHT = 2.5f;
    static final float PATIENCE_MINIMAL = 3f;
    /** Average frame time below this multiple of the target counts as comfortable. */
    private static final float RATIO_COMFORT = 1.10f;
    /** How long it has to be comfortable before the level goes up one step. */
    static final float RISE_PATIENCE = 12f;
    /** A step up that has to be taken back within this many seconds is not tried again this session. */
    private static final float PROBATION = 8f;

    private final boolean adaptive;
    private int level;
    /** The best level this session may still try (a step up that failed locks the level below it). */
    private int bestAllowed = FULL;
    private float averaged;
    private float struggling;
    private float comfortable;
    private float grace = START_GRACE;
    private float settle;
    private float sinceChange;
    private float probation;

    /**
     * @param adaptive false keeps {@code startLevel} for the whole session
     * @param startLevel the level to begin with (0..2)
     */
    public QualityGovernor(boolean adaptive, int startLevel) {
        this.adaptive = adaptive;
        this.level = Math.max(FULL, Math.min(MINIMAL, startLevel));
    }

    public int level() {
        return level;
    }

    /**
     * Reports one rendered frame.
     *
     * @param frameSeconds time since the previous rendered frame
     * @param vsyncSeconds the display's refresh interval (about 0.0167 at 60 Hz, 0.0083 at 120 Hz)
     * @return true when the level just changed (down or up)
     */
    public boolean onFrame(float frameSeconds, float vsyncSeconds) {
        if (!adaptive) return false;
        if (!(frameSeconds > 0f) || frameSeconds > HITCH) {
            struggling = 0f;
            comfortable = 0f;
            return false;
        }
        if (grace > 0f) {
            grace -= frameSeconds;
            averaged = frameSeconds;
            return false;
        }
        if (settle > 0f) {
            settle -= frameSeconds;
            averaged = frameSeconds;
            return false;
        }
        sinceChange += frameSeconds;
        if (probation > 0f) probation -= frameSeconds;
        // The game asks for at most about 90 frames a second, and a phone that manages 60 is fine.
        float target = Math.max(vsyncSeconds, 1f / 60f);
        averaged += (frameSeconds - averaged) * 0.10f;
        float ratio = averaged / target;

        if (level < MINIMAL) {
            float limit = level == FULL ? RATIO_LIGHT : RATIO_MINIMAL;
            float patience = level == FULL ? PATIENCE_LIGHT : PATIENCE_MINIMAL;
            if (ratio > limit) {
                comfortable = 0f;
                struggling += frameSeconds;
                if (struggling >= patience) {
                    if (probation > 0f) bestAllowed = Math.max(bestAllowed, level + 1);   // the step up did not hold
                    level++;
                    changed();
                    return true;
                }
            } else {
                struggling = Math.max(0f, struggling - frameSeconds * 2f);
            }
        }
        if (level > bestAllowed) {
            if (ratio < RATIO_COMFORT) {
                comfortable += frameSeconds;
                if (comfortable >= RISE_PATIENCE && sinceChange >= RISE_PATIENCE) {
                    level--;
                    changed();
                    probation = PROBATION;
                    return true;
                }
            } else {
                comfortable = 0f;
            }
        }
        return false;
    }

    private void changed() {
        struggling = 0f;
        comfortable = 0f;
        settle = SETTLE;
        sinceChange = 0f;
    }
}
