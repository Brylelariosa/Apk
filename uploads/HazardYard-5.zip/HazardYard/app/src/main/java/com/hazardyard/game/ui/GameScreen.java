package com.hazardyard.game.ui;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.hazardyard.game.audio.SoundEngine;
import com.hazardyard.game.engine.GameEngine;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.render.Palette;

/**
 * The match: a full-screen GameView with the pause menu on top. The pause menu offers Resume,
 * Customize HUD (the layout editor: where things sit and how big they are), Controls (how the sticks
 * and firing work), Restart match (solo only) and Leave match. Both Customize HUD and Controls open in
 * place over the match; it resumes with the new settings applied.
 */
final class GameScreen implements Screen, GameLoop.Callback, InputController.Listener {
    private final Context ctx;
    private final Navigator nav;
    private final GameEngine engine;
    private final boolean solo;
    private final FrameLayout root;
    private final GameView gameView;
    private final FrameLayout pauseOverlay;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private HudEditorView editor;
    private FrameLayout controlsOverlay;
    private int insetL, insetT, insetR, insetB;
    private boolean paused;
    private boolean finishing;

    GameScreen(Context c, Navigator navigator, GameEngine eng, boolean multiplayer, boolean solo) {
        ctx = c;
        nav = navigator;
        engine = eng;
        this.solo = solo;
        SoundEngine sound = navigator.sound();
        if (sound != null) eng.state().audio.setSink(sound);

        root = new FrameLayout(c);
        gameView = new GameView(c, eng, navigator.settings(), sound, this);
        gameView.input().setListener(this);
        root.addView(gameView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        FrameLayout overlay = new FrameLayout(c);
        overlay.setBackgroundColor(0xB0000000);
        overlay.setClickable(true);
        overlay.setVisibility(View.GONE);
        LinearLayout panel = Ui.panel(c);
        panel.addView(Ui.label(c, "Paused", 28f, Palette.TEXT, true));
        if (multiplayer) {
            panel.addView(Ui.label(c, "The match keeps running for the other players.", 13f, Palette.TEXT_DIM, false),
                    Ui.fillWidth(c, 6));
        }
        Button resume = Ui.button(c, "Resume", true);
        resume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPaused(false);
            }
        });
        panel.addView(resume, Ui.fillWidth(c, 16));

        // Customize HUD (layout) and Controls (how input works) are two separate things, side by side.
        Button customize = Ui.button(c, "Customize HUD", false);
        customize.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditor();
            }
        });
        Button controls = Ui.button(c, "Controls", false);
        controls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openControls();
            }
        });
        LinearLayout row1 = Ui.row(c);
        row1.addView(customize, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 5, 0, c));
        row1.addView(controls, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 5, 0, 0, 0, c));
        panel.addView(row1, Ui.fillWidth(c, 10));

        Button quit = Ui.button(c, "Leave match", false);
        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishing = true;
                if (GameScreen.this.solo) nav.showSoloSetup();
                else nav.showMenu(null);
            }
        });
        if (solo) {
            Button restart = Ui.button(c, "Restart match", false);
            restart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finishing = true;
                    nav.restartSolo();
                }
            });
            LinearLayout row2 = Ui.row(c);
            row2.addView(restart, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 0, 0, 5, 0, c));
            row2.addView(quit, Ui.lp(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f, 5, 0, 0, 0, c));
            panel.addView(row2, Ui.fillWidth(c, 10));
        } else {
            panel.addView(quit, Ui.fillWidth(c, 10));
        }
        // On a small phone the menu scrolls instead of running off the screen.
        ScrollView scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(panel, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(Ui.dp(c, 380),
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        overlay.addView(scroll, plp);
        root.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pauseOverlay = overlay;
    }

    private void setPaused(boolean p) {
        paused = p;
        pauseOverlay.setVisibility(p ? View.VISIBLE : View.GONE);
        gameView.input().cancelAll();
        engine.setPaused(p);
    }

    // ------------------------------------------------------------------ Customize HUD and Controls (over the paused match)

    /** Customize HUD: the layout editor (position and size only). */
    private void openEditor() {
        if (editor != null || controlsOverlay != null) return;
        editor = new HudEditorView(ctx, nav.settings(), new HudEditorView.Listener() {
            @Override
            public void onClose(boolean saved) {
                if (editor != null) {
                    root.removeView(editor);
                    editor = null;
                }
                if (saved) {
                    nav.saveSettings();
                    gameView.applySettings();
                }
            }
        });
        editor.setInsets(insetL, insetT, insetR, insetB);
        root.addView(editor, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Controls: how the sticks and firing work. Changes take effect at once. */
    private void openControls() {
        if (editor != null || controlsOverlay != null) return;
        final FrameLayout overlay = new FrameLayout(ctx);
        overlay.setBackgroundColor(0xE6000000);
        overlay.setClickable(true);
        overlay.setPadding(insetL, insetT, insetR, insetB);
        LinearLayout panel = ControlsPanel.create(ctx, nav.settings(), new ControlsPanel.Callback() {
            @Override
            public void onChanged() {
                gameView.applySettings();
            }

            @Override
            public void onDone() {
                closeControls();
            }
        });
        ScrollView scroll = new ScrollView(ctx);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.addView(panel, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.dp(ctx, 380), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        overlay.addView(scroll, lp);
        controlsOverlay = overlay;
        root.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void closeControls() {
        if (controlsOverlay == null) return;
        root.removeView(controlsOverlay);
        controlsOverlay = null;
        gameView.applySettings();
        nav.saveSettings();
    }

    // ------------------------------------------------------------------ callbacks

    /** Pause button tapped (UI thread). */
    @Override
    public void onPausePressed() {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (!paused) setPaused(true);
            }
        });
    }

    /** Game thread: the session ended. */
    @Override
    public void onEngineFinished(final String reason) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (finishing) return;
                finishing = true;
                nav.onMatchFinished(reason);
            }
        });
    }

    // ------------------------------------------------------------------ Screen

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShow() {
        // The loop starts by itself when the surface is ready.
    }

    @Override
    public void onHide() {
        finishing = true;
        ui.removeCallbacksAndMessages(null);
        gameView.stopLoop();
        engine.close();
    }

    @Override
    public boolean onBack() {
        if (editor != null) return editor.handleBack();
        if (controlsOverlay != null) {
            closeControls();
            return true;
        }
        setPaused(!paused);
        return true;
    }

    @Override
    public void onInsets(int l, int t, int r, int b) {
        insetL = l;
        insetT = t;
        insetR = r;
        insetB = b;
        gameView.setInsets(l, t, r, b);
        pauseOverlay.setPadding(l, t, r, b);
        if (controlsOverlay != null) controlsOverlay.setPadding(l, t, r, b);
        if (editor != null) editor.setInsets(l, t, r, b);
    }
}
