package com.hazardyard.game.audio;

import com.hazardyard.game.core.Sounds;
import com.hazardyard.game.core.WeaponDef;

/**
 * Builds every sound effect of the game from scratch with {@link Synth}: no audio files.
 *
 * <p>Every weapon has its own audio identity, built from different ingredients rather than the same
 * recipe with other numbers: a bright compact crack and slide rattle for the pistol, a raspy buzzing
 * tick for the SMG, a punchy mid-range crack for the rifle, a huge broad blast for the shotgun, a razor
 * crack with a long echo for the sniper, a deep boom with recoil thump and ringing frame for the magnum,
 * an electric zap for the plasma rifle and a dull thud with belt clank for the light machine gun.
 *
 * <p>Reloads are told as small mechanical stories, three sounds per gun (it starts, the ammunition
 * goes in, it is ready), and guns with a pump, bolt or hammer also have an action sound that follows
 * a shot. The game plays each of them at the moment the gun really reaches that stage.
 */
public final class SoundBank {
    private SoundBank() {}

    /** How far each sound carries, as a multiple of the normal hearing distance. */
    private static final float[] CARRY = new float[Sounds.COUNT];
    /** Default loudness of each sound before distance and master volume. */
    private static final float[] LEVEL = new float[Sounds.COUNT];

    static {
        java.util.Arrays.fill(CARRY, 1f);
        java.util.Arrays.fill(LEVEL, 1f);
        CARRY[WeaponDef.PISTOL] = 1.0f;
        CARRY[WeaponDef.RIFLE] = 1.3f;
        CARRY[WeaponDef.SHOTGUN] = 1.6f;
        CARRY[WeaponDef.SMG] = 0.9f;
        CARRY[WeaponDef.SNIPER] = 3.2f;
        CARRY[WeaponDef.MAGNUM] = 1.7f;
        CARRY[WeaponDef.PLASMA] = 1.3f;
        CARRY[WeaponDef.LMG] = 1.5f;
        CARRY[Sounds.KILL] = 1.4f;
        CARRY[Sounds.IMPACT] = 0.5f;
        CARRY[Sounds.PICKUP] = 0.7f;
        CARRY[Sounds.RESPAWN] = 0.7f;
        CARRY[Sounds.DODGE] = 0.6f;
        LEVEL[WeaponDef.SMG] = 0.8f;
        LEVEL[WeaponDef.PLASMA] = 0.85f;
        LEVEL[WeaponDef.PISTOL] = 0.9f;
        LEVEL[Sounds.IMPACT] = 0.5f;
        LEVEL[Sounds.HIT] = 0.8f;
        LEVEL[Sounds.DODGE] = 0.95f;
        LEVEL[Sounds.PICKUP] = 0.9f;
        LEVEL[Sounds.COUNTDOWN] = 0.7f;
        // Reload and action sounds are small, close-by sounds: quiet and short-ranged.
        for (int w = 0; w < WeaponDef.ALL.length; w++) {
            for (int stage = 0; stage < 3; stage++) {
                CARRY[Sounds.RELOAD_BASE + 3 * w + stage] = 0.5f;
                LEVEL[Sounds.RELOAD_BASE + 3 * w + stage] = 0.85f;
            }
            CARRY[Sounds.ACTION_BASE + w] = 0.7f;
            LEVEL[Sounds.ACTION_BASE + w] = 0.85f;
        }
    }

    public static float carry(int sound) {
        return CARRY[sound];
    }

    public static float level(int sound) {
        return LEVEL[sound];
    }

    /** Synthesises all sounds (a fraction of a second of work in total). Index = {@link Sounds} id. */
    public static short[][] build() {
        short[][] pcm = new short[Sounds.COUNT][];
        for (int id = 0; id < Sounds.COUNT; id++) pcm[id] = Synth.toPcm(make(id));
        return pcm;
    }

    /** Float version of one sound, used by {@link #build} and by the tests. */
    static float[] make(int id) {
        if (id >= Sounds.RELOAD_BASE && id < Sounds.ACTION_BASE) {
            int rel = id - Sounds.RELOAD_BASE;
            return reload(rel / 3, rel % 3);
        }
        if (id >= Sounds.ACTION_BASE && id < Sounds.COUNT) return action(id - Sounds.ACTION_BASE);
        switch (id) {
            case WeaponDef.PISTOL: return pistol();
            case WeaponDef.RIFLE: return rifle();
            case WeaponDef.SHOTGUN: return shotgun();
            case WeaponDef.SMG: return smg();
            case WeaponDef.SNIPER: return sniper();
            case WeaponDef.MAGNUM: return magnum();
            case WeaponDef.PLASMA: return plasma();
            case WeaponDef.LMG: return lmg();
            case Sounds.PICKUP: return pickup();
            case Sounds.HIT: return hit();
            case Sounds.HURT: return hurt();
            case Sounds.KILL: return kill();
            case Sounds.DEATH: return death();
            case Sounds.RESPAWN: return respawn();
            case Sounds.IMPACT: return impact();
            case Sounds.COUNTDOWN: return beep(880f, 0.14f);
            case Sounds.GO: return go();
            case Sounds.WIN: return arpeggio(new float[] {523.25f, 659.25f, 783.99f, 1046.5f}, 0.11f, 0.5f, 0.1f);
            case Sounds.LOSE: return arpeggio(new float[] {392f, 349.23f, 293.66f, 233.08f}, 0.16f, 0.45f, 0.5f);
            case Sounds.CONFIRM: return confirm();
            case Sounds.DODGE: return dodge();
            default: return new float[1];
        }
    }

    /** A copy of {@code dry} through a dark room: low-passed and echoed, mixed back under the dry signal. */
    private static void room(float[] b, float cutoffHz, float delay, float gain, int taps, float wet) {
        float[] w = b.clone();
        Synth.lowPass(w, cutoffHz);
        Synth.echo(w, delay, gain, taps);
        for (int i = 0; i < b.length; i++) b[i] += w[i] * wet;
    }

    // ------------------------------------------------------------------ guns: one identity each

    /** Pistol: a sharp, compact 9 mm. A bright crack, a short mid \"pop\", the slide's metallic rattle, almost no bass. */
    private static float[] pistol() {
        float[] b = Synth.buffer(0.20f);
        Synth.Noise n = new Synth.Noise(11);
        Synth.addNoise(b, n, 0f, 0.009f, 0.9f, 2000f, 9000f);
        Synth.addSweep(b, 0f, 0.030f, 0.95f, 700f, 200f, 50f);
        Synth.addNoise(b, n, 0.001f, 0.035f, 0.42f, 400f, 2500f);
        Synth.addClick(b, n, 0.038f, 0.30f, 3500f, 0.004f);
        Synth.addClick(b, n, 0.066f, 0.20f, 2600f, 0.004f);
        Synth.saturate(b, 1.4f);
        room(b, 3500f, 0.045f, 0.3f, 2, 0.35f);
        return finish(b, 0.9f);
    }

    /** SMG: a raspy, buzzing tick (a saw tone in the mid range), tight and aggressive; twelve a second make a \"brrrt\". */
    private static float[] smg() {
        float[] b = Synth.buffer(0.09f);
        Synth.Noise n = new Synth.Noise(41);
        Synth.addNoise(b, n, 0f, 0.0055f, 0.9f, 2600f, 12000f);
        Synth.addTone(b, 0f, 0.0004f, 0.014f, 0.65f, 1500f, 0.9f);
        Synth.addTone(b, 0f, 0f, 0.010f, 0.40f, 3000f, 0.7f);
        Synth.addClick(b, n, 0.018f, 0.32f, 4800f, 0.003f);
        Synth.saturate(b, 2.2f);
        return finish(b, 0.85f);
    }

    /** Assault rifle: a punchy mid-range crack with a quick \"thump\", a supersonic snap and a short echo. */
    private static float[] rifle() {
        float[] b = Synth.buffer(0.34f);
        Synth.Noise n = new Synth.Noise(23);
        Synth.addNoise(b, n, 0f, 0.020f, 1.0f, 800f, 7000f);
        Synth.addSweep(b, 0f, 0.07f, 0.95f, 240f, 75f, 36f);
        Synth.addNoise(b, n, 0.006f, 0.09f, 0.33f, 150f, 1500f);
        Synth.addTone(b, 0.001f, 0f, 0.028f, 0.18f, 1650f, 0f);
        Synth.saturate(b, 2.2f);
        room(b, 1800f, 0.11f, 0.32f, 2, 0.45f);
        return finish(b, 0.92f);
    }

    /** Shotgun: a huge, wide blast: broad-band noise, a rumble underneath and a deep sub-bass whump, long and heavy. */
    private static float[] shotgun() {
        float[] b = Synth.buffer(0.65f);
        Synth.Noise n = new Synth.Noise(37);
        Synth.addNoise(b, n, 0f, 0.12f, 1.0f, 0f, 5200f);
        Synth.addNoise(b, n, 0f, 0.30f, 0.50f, 0f, 900f);
        Synth.addSweep(b, 0f, 0.16f, 0.95f, 95f, 30f, 14f);
        Synth.addNoise(b, n, 0f, 0.012f, 0.7f, 1000f, 9000f);
        Synth.addNoise(b, n, 0.04f, 0.09f, 0.60f, 300f, 3500f);
        Synth.saturate(b, 3.4f);
        room(b, 1700f, 0.085f, 0.45f, 3, 0.55f);
        return finish(b, 0.95f);
    }

    /** Sniper: a razor-thin supersonic crack, a deep boom and a long rumbling echo off far walls. */
    private static float[] sniper() {
        float[] b = Synth.buffer(1.30f);
        Synth.Noise n = new Synth.Noise(53);
        Synth.addNoise(b, n, 0f, 0.006f, 1.3f, 3000f, 14000f);
        Synth.addNoise(b, n, 0f, 0.040f, 0.9f, 700f, 6000f);
        Synth.addSweep(b, 0f, 0.26f, 1.1f, 150f, 36f, 10f);
        Synth.addSweep(b, 0f, 0.05f, 0.30f, 4200f, 1800f, 30f);
        Synth.saturate(b, 2.0f);
        room(b, 2200f, 0.19f, 0.5f, 5, 0.75f);
        return finish(b, 0.95f);
    }

    /** Magnum: a deep boom with a heavy recoil thump right behind it and the ring of the revolver frame. */
    private static float[] magnum() {
        float[] b = Synth.buffer(0.90f);
        Synth.Noise n = new Synth.Noise(67);
        Synth.addSweep(b, 0f, 0.22f, 1.35f, 170f, 44f, 15f);
        Synth.addNoise(b, n, 0f, 0.028f, 0.85f, 250f, 4500f);
        Synth.addNoise(b, n, 0.002f, 0.12f, 0.30f, 0f, 1000f);
        Synth.addRing(b, 0.003f, 0.32f, 1200f, 0.20f);
        Synth.addSweep(b, 0.075f, 0.09f, 0.70f, 90f, 42f, 25f);
        Synth.saturate(b, 2.4f);
        room(b, 2000f, 0.15f, 0.4f, 3, 0.6f);
        return finish(b, 0.93f);
    }

    /**
     * Plasma rifle: an electric zap. A ring-modulated saw dives from a shriek to a low growl, an FM
     * sparkle and a second detuned zap sit on top, random arc crackles rain over it, and a short
     * buzzing hum trails off. Short (0.3 s) so it stays clean at eleven shots a second.
     */
    private static float[] plasma() {
        float[] b = Synth.buffer(0.30f);
        Synth.Noise n = new Synth.Noise(79);
        Synth.addZap(b, 0f, 0.085f, 0.95f, 3300f, 210f, 26f, 137f, 0.8f);
        Synth.addZap(b, 0.002f, 0.065f, 0.45f, 4700f, 540f, 30f, 211f, 0.7f);
        Synth.addFm(b, 0f, 0.075f, 0.35f, 1900f, 2650f, 7f, 20f);
        Synth.addCrackle(b, n, 0f, 0.24f, 0.010f, 0.075f, 0.85f, 2500f);
        Synth.addSweep(b, 0f, 0.05f, 0.55f, 260f, 70f, 40f);
        Synth.addBuzz(b, 0.02f, 0.26f, 0.20f, 96f, 38f, 0.09f);
        Synth.saturate(b, 1.8f);
        return finish(b, 0.85f);
    }

    /** Light machine gun: a dull, heavy thud, a flat crack and the clank of the ammunition belt. */
    private static float[] lmg() {
        float[] b = Synth.buffer(0.22f);
        Synth.Noise n = new Synth.Noise(97);
        Synth.addSweep(b, 0f, 0.055f, 1.0f, 120f, 45f, 36f);
        Synth.addNoise(b, n, 0f, 0.042f, 0.95f, 120f, 2200f);
        Synth.addNoise(b, n, 0f, 0.008f, 0.30f, 2200f, 6000f);
        Synth.addClick(b, n, 0.038f, 0.35f, 2000f, 0.006f);
        Synth.addRing(b, 0.038f, 0.12f, 1700f, 0.05f);
        Synth.saturate(b, 2.8f);
        return finish(b, 0.9f);
    }

    // ------------------------------------------------------------------ reloads: three little stories per gun

    /**
     * Stage 0 = it starts (release, eject, open), 1 = the ammunition goes in (the magazine seats, a shell
     * drops in), 2 = it is ready (slide, bolt, pump or cylinder closes).
     */
    private static float[] reload(int weapon, int stage) {
        float[] b;
        Synth.Noise n = new Synth.Noise(200 + weapon * 7 + stage);
        switch (weapon) {
            case WeaponDef.PISTOL: b = pistolReload(n, stage); break;
            case WeaponDef.RIFLE: b = rifleReload(n, stage); break;
            case WeaponDef.SHOTGUN: b = shotgunReload(n, stage); break;
            case WeaponDef.SMG: b = smgReload(n, stage); break;
            case WeaponDef.SNIPER: b = sniperReload(n, stage); break;
            case WeaponDef.MAGNUM: b = magnumReload(n, stage); break;
            case WeaponDef.PLASMA: b = plasmaReload(n, stage); break;
            default: b = lmgReload(n, stage); break;
        }
        return finish(b, 0.7f);
    }

    /** Pistol: light plastic-and-steel. Release button and the magazine dropping, a slap and a latch click, the slide racked. */
    private static float[] pistolReload(Synth.Noise n, int stage) {
        float[] b;
        if (stage == 0) {
            b = Synth.buffer(0.30f);
            Synth.addClick(b, n, 0f, 0.7f, 2200f, 0.005f);
            Synth.addScrape(b, n, 0.01f, 0.07f, 0.25f, 3500f, 1500f);
            Synth.addThunk(b, n, 0.13f, 0.5f, 110f, 0.05f);
            Synth.addClick(b, n, 0.15f, 0.25f, 1800f, 0.004f);
        } else if (stage == 1) {
            // A plastic knock as the magazine hits home, then the latch.
            b = Synth.buffer(0.14f);
            Synth.addThunk(b, n, 0f, 0.5f, 330f, 0.03f);
            Synth.addClick(b, n, 0.002f, 0.7f, 2200f, 0.005f);
            Synth.addClick(b, n, 0.045f, 0.5f, 3300f, 0.004f);
        } else {
            b = Synth.buffer(0.24f);
            Synth.addScrape(b, n, 0f, 0.045f, 0.5f, 1000f, 4000f);
            Synth.addClick(b, n, 0.07f, 0.4f, 3200f, 0.004f);
            Synth.addScrape(b, n, 0.09f, 0.05f, 0.4f, 4000f, 1500f);
            Synth.addClick(b, n, 0.15f, 0.9f, 2400f, 0.005f);
            Synth.addThunk(b, n, 0.15f, 0.4f, 150f, 0.04f);
        }
        return b;
    }

    /** SMG: quick and rattly. Rounds rattle in the stick magazine, a sharp \"tak\" as it seats, a snappy charging handle. */
    private static float[] smgReload(Synth.Noise n, int stage) {
        float[] b;
        if (stage == 0) {
            b = Synth.buffer(0.30f);
            Synth.addClick(b, n, 0f, 0.6f, 3000f, 0.004f);
            Synth.addScrape(b, n, 0.02f, 0.08f, 0.25f, 2000f, 700f);
            Synth.addRatchet(b, n, 0.03f, 6, 0.011f, 1f, 0.3f, 3600f);
            Synth.addThunk(b, n, 0.14f, 0.35f, 160f, 0.04f);
        } else if (stage == 1) {
            // The stick magazine zips up into the well and clicks in.
            b = Synth.buffer(0.14f);
            Synth.addScrape(b, n, 0f, 0.035f, 0.5f, 1500f, 5000f);
            Synth.addClick(b, n, 0.034f, 0.8f, 4200f, 0.003f);
            Synth.addRatchet(b, n, 0.05f, 3, 0.012f, 1f, 0.25f, 3200f);
        } else {
            b = Synth.buffer(0.26f);
            Synth.addScrape(b, n, 0f, 0.09f, 0.55f, 800f, 3200f);
            Synth.addRatchet(b, n, 0.02f, 3, 0.012f, 1f, 0.2f, 2500f);
            Synth.addClick(b, n, 0.12f, 0.95f, 4200f, 0.004f);
            Synth.addRing(b, 0.12f, 0.15f, 3600f, 0.05f);
            Synth.addScrape(b, n, 0.13f, 0.05f, 0.25f, 3000f, 900f);
        }
        return b;
    }

    /** Magnum: a big revolver. The cylinder swings out and the fired shells tinkle down, a speed loader goes in, the cylinder snaps shut and spins. */
    private static float[] magnumReload(Synth.Noise n, int stage) {
        float[] b;
        if (stage == 0) {
            b = Synth.buffer(0.64f);
            Synth.addClick(b, n, 0f, 0.6f, 1900f, 0.005f);
            Synth.addThunk(b, n, 0.05f, 0.35f, 220f, 0.05f);
            Synth.addScrape(b, n, 0.08f, 0.10f, 0.25f, 700f, 2400f);
            float[] rings = {3300f, 4100f, 2800f, 3700f, 3100f, 4400f};
            float[] when = {0.24f, 0.30f, 0.37f, 0.43f, 0.50f, 0.55f};
            for (int i = 0; i < rings.length; i++) Synth.addRing(b, when[i], 0.30f - 0.02f * i, rings[i], 0.07f);
            Synth.addThunk(b, n, 0.30f, 0.25f, 90f, 0.05f);
        } else if (stage == 1) {
            b = Synth.buffer(0.24f);
            Synth.addClick(b, n, 0f, 0.7f, 1500f, 0.005f);
            Synth.addThunk(b, n, 0.005f, 0.7f, 180f, 0.05f);
            Synth.addRing(b, 0.01f, 0.3f, 2600f, 0.06f);
            Synth.addRatchet(b, n, 0.03f, 6, 0.012f, 1f, 0.25f, 1800f);
        } else {
            b = Synth.buffer(0.55f);
            Synth.addThunk(b, n, 0f, 0.7f, 130f, 0.06f);
            Synth.addClick(b, n, 0.002f, 0.9f, 2200f, 0.005f);
            Synth.addRing(b, 0.002f, 0.3f, 1500f, 0.12f);
            Synth.addRatchet(b, n, 0.09f, 10, 0.018f, 1.12f, 0.3f, 2800f);
        }
        return b;
    }

    /** Shotgun: pump action. The pump slides back and a spent shell tinkles out, each shell goes in with a plastic tick, the pump locks forward with a heavy chunk. */
    private static float[] shotgunReload(Synth.Noise n, int stage) {
        float[] b;
        if (stage == 0) {
            b = Synth.buffer(0.36f);
            Synth.addClick(b, n, 0f, 0.6f, 1600f, 0.005f);
            Synth.addScrape(b, n, 0.02f, 0.12f, 0.5f, 500f, 1800f);
            Synth.addThunk(b, n, 0.14f, 0.5f, 140f, 0.05f);
            Synth.addRing(b, 0.17f, 0.35f, 3800f, 0.07f);
            Synth.addClick(b, n, 0.22f, 0.3f, 2200f, 0.004f);
        } else if (stage == 1) {
            // A shell drops in: plastic tick, brass ring, the carrier spring.
            b = Synth.buffer(0.20f);
            Synth.addClick(b, n, 0f, 0.5f, 700f, 0.006f);
            Synth.addRing(b, 0.004f, 0.45f, 3500f, 0.10f);
            Synth.addClick(b, n, 0.06f, 0.35f, 2800f, 0.004f);
        } else {
            b = Synth.buffer(0.42f);
            Synth.addScrape(b, n, 0f, 0.14f, 0.5f, 1800f, 600f);
            Synth.addThunk(b, n, 0.15f, 0.95f, 110f, 0.07f);
            Synth.addClick(b, n, 0.15f, 0.95f, 1500f, 0.006f);
            Synth.addRing(b, 0.15f, 0.30f, 1100f, 0.12f);
            Synth.addClick(b, n, 0.21f, 0.3f, 3000f, 0.004f);
        }
        return b;
    }

    /** Assault rifle: solid and mechanical. Magazine catch and the magazine sliding out, a deep seat with a latch click, the charging handle slammed home. */
    private static float[] rifleReload(Synth.Noise n, int stage) {
        float[] b;
        if (stage == 0) {
            b = Synth.buffer(0.34f);
            Synth.addClick(b, n, 0f, 0.65f, 1700f, 0.005f);
            Synth.addScrape(b, n, 0.02f, 0.10f, 0.3f, 900f, 2600f);
            Synth.addThunk(b, n, 0.16f, 0.5f, 100f, 0.05f);
            Synth.addClick(b, n, 0.19f, 0.3f, 2000f, 0.004f);
        } else if (stage == 1) {
            // A deep, heavy seat: the magazine thuds home and rattles.
            b = Synth.buffer(0.22f);
            Synth.addThunk(b, n, 0f, 1.0f, 85f, 0.07f);
            Synth.addClick(b, n, 0.012f, 0.55f, 1300f, 0.006f);
            Synth.addRatchet(b, n, 0.06f, 3, 0.02f, 1.15f, 0.25f, 1700f);
        } else {
            b = Synth.buffer(0.32f);
            Synth.addScrape(b, n, 0f, 0.11f, 0.45f, 700f, 2200f);
            Synth.addClick(b, n, 0.12f, 0.4f, 2200f, 0.004f);
            Synth.addScrape(b, n, 0.13f, 0.06f, 0.3f, 2200f, 800f);
            Synth.addClick(b, n, 0.20f, 0.95f, 1800f, 0.005f);
            Synth.addThunk(b, n, 0.20f, 0.6f, 120f, 0.05f);
            Synth.addRing(b, 0.20f, 0.2f, 2000f, 0.08f);
        }
        return b;
    }

    /** Sniper: bolt action. The bolt handle lifts and is pulled back, the brass tinkles out, rounds press into the box one by one, the bolt slides forward and locks down. */
    private static float[] sniperReload(Synth.Noise n, int stage) {
        float[] b;
        if (stage == 0) {
            b = Synth.buffer(0.52f);
            Synth.addClick(b, n, 0f, 0.7f, 1400f, 0.006f);
            Synth.addScrape(b, n, 0.06f, 0.20f, 0.5f, 600f, 2400f);
            Synth.addClick(b, n, 0.28f, 0.4f, 2200f, 0.004f);
            Synth.addRing(b, 0.30f, 0.35f, 3600f, 0.09f);
            Synth.addRing(b, 0.38f, 0.20f, 4300f, 0.07f);
        } else if (stage == 1) {
            b = Synth.buffer(0.40f);
            for (int k = 0; k < 4; k++) {
                float t = 0.07f * k;
                Synth.addClick(b, n, t, 0.5f, 1500f + 180f * k, 0.005f);
                Synth.addThunk(b, n, t, 0.35f, 150f + 25f * k, 0.03f);
            }
            Synth.addClick(b, n, 0.30f, 0.6f, 2600f, 0.004f);
        } else {
            b = Synth.buffer(0.55f);
            Synth.addScrape(b, n, 0f, 0.16f, 0.5f, 2200f, 600f);
            Synth.addThunk(b, n, 0.17f, 0.9f, 90f, 0.08f);
            Synth.addClick(b, n, 0.17f, 0.9f, 1600f, 0.006f);
            Synth.addRing(b, 0.17f, 0.35f, 1300f, 0.2f);
            Synth.addClick(b, n, 0.28f, 0.5f, 2500f, 0.005f);
            Synth.addThunk(b, n, 0.28f, 0.7f, 110f, 0.05f);
        }
        return b;
    }

    /** Plasma rifle: sci-fi. The spent energy cell is vented with a hiss and a power-down whine, the new cell clunks in and the capacitor whines up, a bright ready chirp with a crackle. */
    private static float[] plasmaReload(Synth.Noise n, int stage) {
        float[] b;
        if (stage == 0) {
            b = Synth.buffer(0.36f);
            Synth.addHiss(b, n, 0f, 0.16f, 0.4f, 3500f);
            Synth.addSweep(b, 0.02f, 0.12f, 0.35f, 1100f, 160f, 7f);
            Synth.addThunk(b, n, 0.05f, 0.6f, 160f, 0.05f);
            Synth.addClick(b, n, 0.05f, 0.5f, 2600f, 0.004f);
            Synth.addCrackle(b, n, 0f, 0.2f, 0.006f, 0.08f, 0.4f, 2500f);
        } else if (stage == 1) {
            b = Synth.buffer(0.42f);
            Synth.addThunk(b, n, 0f, 0.7f, 190f, 0.05f);
            Synth.addClick(b, n, 0.005f, 0.5f, 3000f, 0.004f);
            Synth.addSweep(b, 0.03f, 0.28f, 0.5f, 250f, 2600f, 7f);
            Synth.addFm(b, 0.05f, 0.2f, 0.2f, 1500f, 2100f, 4f, 10f);
        } else {
            b = Synth.buffer(0.34f);
            Synth.addTone(b, 0f, 0.003f, 0.05f, 0.6f, 1200f, 0.1f);
            Synth.addTone(b, 0.07f, 0.003f, 0.08f, 0.6f, 1800f, 0.1f);
            Synth.addCrackle(b, n, 0.07f, 0.18f, 0.008f, 0.06f, 0.5f, 2500f);
            Synth.addZap(b, 0.07f, 0.05f, 0.35f, 2800f, 600f, 25f, 150f, 0.8f);
        }
        return b;
    }

    /** Light machine gun: heavy and slow. The cover latch and the lid swinging open, belt links ticking, the belt fed in with a heavy seat, the lid slammed shut with a big metallic clang. */
    private static float[] lmgReload(Synth.Noise n, int stage) {
        float[] b;
        if (stage == 0) {
            b = Synth.buffer(0.52f);
            Synth.addClick(b, n, 0f, 0.7f, 1200f, 0.006f);
            Synth.addThunk(b, n, 0.04f, 0.6f, 70f, 0.08f);
            Synth.addScrape(b, n, 0.06f, 0.20f, 0.35f, 300f, 1100f);
            Synth.addRing(b, 0.04f, 0.2f, 1500f, 0.1f);
            Synth.addRatchet(b, n, 0.25f, 5, 0.045f, 1.1f, 0.3f, 1500f);
        } else if (stage == 1) {
            b = Synth.buffer(0.42f);
            Synth.addRatchet(b, n, 0f, 7, 0.025f, 1f, 0.35f, 1400f);
            Synth.addThunk(b, n, 0.19f, 0.9f, 100f, 0.07f);
            Synth.addClick(b, n, 0.19f, 0.7f, 1400f, 0.006f);
            Synth.addRing(b, 0.19f, 0.25f, 1800f, 0.10f);
        } else {
            b = Synth.buffer(0.58f);
            Synth.addThunk(b, n, 0f, 1.0f, 70f, 0.09f);
            Synth.addClick(b, n, 0f, 0.9f, 1000f, 0.007f);
            Synth.addRing(b, 0f, 0.45f, 900f, 0.22f);
            Synth.addScrape(b, n, 0.25f, 0.12f, 0.4f, 600f, 2000f);
            Synth.addClick(b, n, 0.38f, 0.8f, 2000f, 0.005f);
            Synth.addThunk(b, n, 0.38f, 0.6f, 90f, 0.05f);
        }
        return b;
    }

    // ------------------------------------------------------------------ mechanical actions that follow a shot

    /** The pump, bolt or hammer of the guns that have one; a tiny silent buffer for the others (the mixer skips it). */
    private static float[] action(int weapon) {
        Synth.Noise n = new Synth.Noise(300 + weapon);
        float[] b;
        switch (weapon) {
            case WeaponDef.SHOTGUN:
                // Pump: back (clack) and forward (clack-chunk).
                b = Synth.buffer(0.44f);
                Synth.addScrape(b, n, 0f, 0.10f, 0.5f, 500f, 1700f);
                Synth.addClick(b, n, 0.10f, 0.8f, 1700f, 0.005f);
                Synth.addThunk(b, n, 0.10f, 0.5f, 130f, 0.05f);
                Synth.addScrape(b, n, 0.18f, 0.09f, 0.45f, 1700f, 500f);
                Synth.addClick(b, n, 0.27f, 0.95f, 1500f, 0.006f);
                Synth.addThunk(b, n, 0.27f, 0.8f, 110f, 0.06f);
                Synth.addRing(b, 0.27f, 0.25f, 1000f, 0.12f);
                return finish(b, 0.8f);
            case WeaponDef.SNIPER:
                // Bolt cycle: lift and pull back, push forward and lock down.
                b = Synth.buffer(0.60f);
                Synth.addClick(b, n, 0f, 0.7f, 1400f, 0.006f);
                Synth.addScrape(b, n, 0.05f, 0.16f, 0.5f, 600f, 2400f);
                Synth.addClick(b, n, 0.22f, 0.4f, 2200f, 0.004f);
                Synth.addRing(b, 0.24f, 0.25f, 3600f, 0.08f);
                Synth.addScrape(b, n, 0.30f, 0.14f, 0.5f, 2200f, 600f);
                Synth.addThunk(b, n, 0.45f, 0.9f, 90f, 0.07f);
                Synth.addClick(b, n, 0.45f, 0.9f, 1600f, 0.006f);
                Synth.addRing(b, 0.45f, 0.3f, 1300f, 0.15f);
                return finish(b, 0.8f);
            case WeaponDef.MAGNUM:
                // Hammer cocked and the cylinder clicking round.
                b = Synth.buffer(0.22f);
                Synth.addClick(b, n, 0f, 0.8f, 2000f, 0.004f);
                Synth.addRatchet(b, n, 0.005f, 3, 0.022f, 1f, 0.5f, 2600f);
                Synth.addThunk(b, n, 0.07f, 0.4f, 160f, 0.03f);
                return finish(b, 0.75f);
            default:
                return new float[1];
        }
    }

    // ------------------------------------------------------------------ everything else

    /** Taking a weapon: the grab (click and a short slide), a thunk of the gun settling, and a bright two-note chirp. */
    private static float[] pickup() {
        float[] b = Synth.buffer(0.38f);
        Synth.Noise n = new Synth.Noise(139);
        Synth.addClick(b, n, 0f, 0.7f, 2000f, 0.005f);
        Synth.addThunk(b, n, 0.002f, 0.4f, 200f, 0.04f);
        Synth.addScrape(b, n, 0.01f, 0.06f, 0.25f, 900f, 2800f);
        Synth.addTone(b, 0.08f, 0.004f, 0.07f, 0.55f, 880f, 0.1f);
        Synth.addTone(b, 0.15f, 0.004f, 0.10f, 0.6f, 1318.5f, 0.1f);
        Synth.addTone(b, 0.15f, 0.004f, 0.06f, 0.2f, 2637f, 0f);
        Synth.addRing(b, 0.15f, 0.10f, 3100f, 0.06f);
        return finish(b, 0.85f);
    }

    /** A bullet landing on a player: a short electric zap with arc crackle and a dull thump under it. */
    private static float[] hit() {
        float[] b = Synth.buffer(0.16f);
        Synth.Noise n = new Synth.Noise(107);
        Synth.addZap(b, 0f, 0.035f, 0.9f, 2400f, 260f, 38f, 160f, 0.85f);
        Synth.addCrackle(b, n, 0f, 0.14f, 0.012f, 0.04f, 0.9f, 2200f);
        Synth.addSweep(b, 0f, 0.03f, 0.6f, 190f, 70f, 45f);
        Synth.saturate(b, 1.7f);
        return finish(b, 0.8f);
    }

    /** The local player is hit: a heavier electric jolt, a low stuttering buzz with crackle and a deep thump. */
    private static float[] hurt() {
        float[] b = Synth.buffer(0.34f);
        Synth.Noise n = new Synth.Noise(109);
        Synth.addBuzz(b, 0f, 0.30f, 0.85f, 62f, 26f, 0.12f);
        Synth.addZap(b, 0f, 0.09f, 0.7f, 1500f, 130f, 20f, 90f, 0.9f);
        Synth.addCrackle(b, n, 0f, 0.28f, 0.010f, 0.10f, 0.7f, 1800f);
        Synth.addSweep(b, 0f, 0.09f, 0.8f, 160f, 50f, 22f);
        Synth.saturate(b, 2.3f);
        return finish(b, 0.9f);
    }

    private static float[] kill() {
        float[] b = Synth.buffer(0.55f);
        Synth.Noise n = new Synth.Noise(113);
        Synth.addSweep(b, 0f, 0.17f, 1.0f, 130f, 32f, 14f);
        Synth.addNoise(b, n, 0f, 0.11f, 0.7f, 0f, 2200f);
        Synth.addNoise(b, n, 0f, 0.015f, 0.5f, 1500f, 7000f);
        Synth.saturate(b, 2.0f);
        return finish(b, 0.9f);
    }

    private static float[] death() {
        float[] b = Synth.buffer(0.80f);
        float phase = 0f;
        for (int i = 0; i < b.length; i++) {
            float t = i / (float) Synth.RATE;
            float f = 90f + 260f * (float) Math.exp(-t * 4.5f);
            phase += (float) (2.0 * Math.PI) * f * (1f + 0.04f * (float) Math.sin(2.0 * Math.PI * 7.0 * t)) / Synth.RATE;
            b[i] = (float) Math.sin(phase) * Synth.attackDecay(t, 0.01f, 0.30f);
        }
        Synth.lowPass(b, 900f);
        Synth.saturate(b, 1.6f);
        return finish(b, 0.85f);
    }

    private static float[] respawn() {
        float[] b = Synth.buffer(0.45f);
        float phase = 0f;
        Synth.Noise n = new Synth.Noise(127);
        for (int i = 0; i < b.length; i++) {
            float t = i / (float) Synth.RATE;
            float f = 220f * (float) Math.pow(4.0, t / 0.45f);
            phase += (float) (2.0 * Math.PI) * f / Synth.RATE;
            float env = (float) Math.sin(Math.PI * Math.min(1f, t / 0.45f));
            b[i] = (float) Math.sin(phase) * env * 0.8f + n.next() * env * 0.05f;
        }
        return finish(b, 0.75f);
    }

    private static float[] impact() {
        float[] b = Synth.buffer(0.10f);
        Synth.Noise n = new Synth.Noise(131);
        Synth.addNoise(b, n, 0f, 0.012f, 0.9f, 1500f, 7000f);
        Synth.addTone(b, 0f, 0f, 0.03f, 0.25f, 2400f, 0f);
        return finish(b, 0.6f);
    }

    private static float[] beep(float freq, float seconds) {
        float[] b = Synth.buffer(seconds + 0.03f);
        Synth.addTone(b, 0f, 0.003f, seconds * 0.5f, 0.9f, freq, 0.15f);
        return finish(b, 0.7f);
    }

    private static float[] go() {
        float[] b = Synth.buffer(0.55f);
        Synth.addTone(b, 0f, 0.003f, 0.14f, 0.8f, 1320f, 0.15f);
        Synth.addTone(b, 0f, 0.003f, 0.14f, 0.4f, 1980f, 0f);
        Synth.addTone(b, 0f, 0.003f, 0.14f, 0.3f, 660f, 0f);
        return finish(b, 0.8f);
    }

    private static float[] arpeggio(float[] notes, float step, float tail, float sawMix) {
        float total = step * (notes.length - 1) + tail;
        float[] b = Synth.buffer(total);
        for (int i = 0; i < notes.length; i++) {
            boolean last = i == notes.length - 1;
            Synth.addTone(b, i * step, 0.005f, last ? tail * 0.35f : step * 1.1f, last ? 0.9f : 0.7f, notes[i], sawMix);
        }
        Synth.lowPass(b, 5000f);
        return finish(b, 0.8f);
    }

    /**
     * The roll: short and snappy, and unlike anything else in the game. A cloth snap and a soft push-off at
     * the start, a bright whoosh that sweeps upwards, and a quick \"fwip\" that falls away at the end. It has no
     * boom and no bang, so it can never be mistaken for a gun, and it is over in a quarter of a second.
     */
    private static float[] dodge() {
        float[] b = Synth.buffer(0.27f);
        Synth.Noise n = new Synth.Noise(137);
        Synth.addNoise(b, n, 0f, 0.005f, 0.5f, 3000f, 9000f);
        Synth.addSweep(b, 0f, 0.03f, 0.35f, 150f, 70f, 60f);
        Synth.addWhoosh(b, n, 0f, 0.20f, 1.0f, 900f, 4600f, 1.6f, 0.012f);
        Synth.addWhoosh(b, n, 0.10f, 0.14f, 0.35f, 5200f, 2400f, 2.0f, 0.02f);
        return finish(b, 0.85f);
    }

    private static float[] confirm() {
        float[] b = Synth.buffer(0.35f);
        Synth.addTone(b, 0.00f, 0.002f, 0.05f, 0.7f, 1760f, 0f);
        Synth.addTone(b, 0.07f, 0.002f, 0.09f, 0.7f, 2637f, 0f);
        return finish(b, 0.75f);
    }

    private static float[] finish(float[] b, float peak) {
        Synth.normalize(b, peak);
        Synth.fadeOut(b, 0.006f);
        return b;
    }
}
