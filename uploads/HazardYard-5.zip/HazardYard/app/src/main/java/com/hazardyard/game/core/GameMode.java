package com.hazardyard.game.core;

/**
 * The rule set of a match. Classic is the original deathmatch on one of the arenas; Battleground is
 * a free-for-all on one huge map with a full roster: real players come first and bots fill every
 * remaining slot, so the map never feels empty.
 */
public final class GameMode {
    public static final int CLASSIC = 0;
    public static final int BATTLEGROUND = 1;
    public static final int COUNT = 2;

    public final int id;
    public final String name;
    public final String blurb;
    /** Arena this mode is played on, or -1 when the players choose one. */
    public final int mapId;
    public final int matchSeconds;
    public final int killLimit;
    public final float respawnDelay;
    public final float pickupRespawn;
    /**
     * Combatants a match is filled up to with bots (real players are never replaced: bots only take
     * slots no human holds). 0 means the mode adds no bots by itself.
     */
    public final int roster;

    private GameMode(int id, String name, String blurb, int mapId, int matchSeconds, int killLimit,
                     float respawnDelay, float pickupRespawn, int roster) {
        this.id = id;
        this.name = name;
        this.blurb = blurb;
        this.mapId = mapId;
        this.matchSeconds = matchSeconds;
        this.killLimit = killLimit;
        this.respawnDelay = respawnDelay;
        this.pickupRespawn = pickupRespawn;
        this.roster = roster;
    }

    public static final GameMode[] ALL = {
        new GameMode(CLASSIC, "Classic",
                "Deathmatch on a compact arena. First to the kill limit wins.",
                -1, GameConfig.MATCH_SECONDS, GameConfig.KILL_LIMIT,
                GameConfig.RESPAWN_DELAY, GameConfig.PICKUP_RESPAWN, 0),
        new GameMode(BATTLEGROUND, "Battleground",
                "Eight fighters on one huge map: towns, a harbour, a canal, ruins and open fields. "
                        + "Bots fill every slot the real players leave empty.",
                MapLibrary.BATTLEGROUND, 360, 20, 4f, 20f, 8),
    };

    public static GameMode byId(int id) {
        return (id >= 0 && id < ALL.length) ? ALL[id] : ALL[CLASSIC];
    }

    public static int clampId(int id) {
        return (id >= 0 && id < ALL.length) ? id : CLASSIC;
    }

    /** True when the mode fixes the arena (the players cannot pick one). */
    public boolean fixedMap() {
        return mapId >= 0;
    }

    /**
     * How many bots a match needs: the roster minus the real players. Bots never push a human out:
     * with more humans than the roster allows there are simply none.
     */
    public int botsFor(int humans) {
        return Math.max(0, roster - Math.max(0, humans));
    }
}
