package com.hazardyard.game.engine;

import com.hazardyard.game.bot.BotSquad;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameMode;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.GameWorld;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.core.WorldListener;

/**
 * A match against computer opponents, no network involved. The player is slot 0 and the bots fill
 * the next slots. The rules run in the same {@link GameWorld} as a hosted game, so a solo match plays
 * exactly like a multiplayer one; pausing really freezes it.
 */
public final class SoloEngine implements GameEngine, WorldListener {
    private final GameState st;
    private final GameWorld world;
    private final BotSquad squad;
    private volatile boolean finished;
    private volatile boolean paused;

    /**
     * A classic match.
     *
     * @param botCount   1..3 computer opponents
     * @param difficulty a {@link com.hazardyard.game.bot.BotDifficulty} level
     */
    public SoloEngine(int mapId, int botCount, int difficulty, String playerName, int seed) {
        this(GameMode.CLASSIC, mapId, botCount, difficulty, playerName, seed);
    }

    /**
     * @param modeId     a {@link GameMode} id; Battleground plays on its own map and fills the roster with bots
     * @param botCount   computer opponents for a classic match (1..3); a Battleground match uses the whole roster
     * @param difficulty a {@link com.hazardyard.game.bot.BotDifficulty} level
     */
    public SoloEngine(int modeId, int mapId, int botCount, int difficulty, String playerName, int seed) {
        GameMode mode = GameMode.byId(modeId);
        st = new GameState(MapLibrary.get(mode.fixedMap() ? mode.mapId : mapId), 0, mode);
        world = new GameWorld(st, this);
        world.addPlayer(0, playerName);
        int bots = mode.roster > 0 ? mode.botsFor(1) : Math.max(1, Math.min(GameConfig.MAX_HUMANS - 1, botCount));
        bots = Math.min(bots, GameConfig.MAX_PLAYERS - 1);
        squad = new BotSquad(st, world, difficulty);
        for (int i = 0; i < bots; i++) {
            int slot = i + 1;
            world.addPlayer(slot, BotSquad.nameFor(slot), true);
            squad.add(slot, seed + i);
        }
        world.startMatch();
    }

    @Override
    public GameState state() {
        return st;
    }

    @Override
    public void fixedUpdate(float dt, LocalInput in) {
        if (finished) return;
        Interpolation.begin(st);
        if (!paused) {
            world.setInput(0, in.moveX, in.moveY, in.aim, in.firing, 0);
            if (in.reload) world.requestReload(0);
            if (in.dodge) world.requestDodge(0, 0f, 0f);
            if (in.pickup) world.requestPickup(0, -1);
            squad.think(dt);
            world.step(dt);
        }
        Interpolation.end(st);
        if (!paused) st.effects.update(dt);
        if (st.phase == GameState.PHASE_FINISHED) finished = true;
    }

    @Override
    public void frameUpdate(float dt, float alpha) {
        Interpolation.apply(st, alpha);
    }

    @Override
    public boolean isFinished() {
        return finished;
    }

    @Override
    public String finishReason() {
        return null;
    }

    @Override
    public int pingMs() {
        return 0;
    }

    @Override
    public void setPaused(boolean p) {
        paused = p;
    }

    @Override
    public void close() {
        finished = true;
    }

    // ------------------------------------------------------------------ WorldListener

    @Override
    public void onShot(Player shooter, WeaponDef def, float x, float y, float angle, int seed, int baseId) {
        Presentation.shot(st, shooter.id, def.id, x, y, angle);
    }

    @Override
    public void onProjectileHit(int projectileId, int victimId, float x, float y, int damage, int weaponId) {
        Presentation.hit(st, victimId, x, y, weaponId, damage);
    }

    @Override
    public void onPickup(Player p, int pickupIndex) {
        Presentation.pickup(st, pickupIndex, st.pickups[pickupIndex].weaponId);
    }

    @Override
    public void onWallImpact(float x, float y, int weaponId) {
        Presentation.wallImpact(st, x, y, weaponId);
    }

    @Override
    public void onKill(int killerId, int victimId, int weaponId) {
        Presentation.kill(st, killerId, victimId, weaponId);
    }
}
