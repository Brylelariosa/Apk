# Rubik AI Lab - NEXT TASK

Checkpoint 0 - 2026-10-17

## Do this next (in order)
1. Write the C++ cube core (core/cube.h, core/cube.cpp) and host tests (tests/). Verify with g++: move order 4, (R U R' U')^6 = identity, QTM BFS state counts 1,12,114,1068,10011,93840,878880.
2. Write search (core/search.*), baseline heuristic, MLP (core/net.*), trainer (core/trainer.*), checkpoint I/O, JNI bridge.
3. Write the Kotlin app (programmatic UI, GLSurfaceView renderer, training controls, charts).
4. Write README.md, AI_DESIGN.md, BUILD.md, CHANGELOG.md.
5. Update this file + PROJECT_STATE.md, save shared-memory handoff, create ZIP/RubikAILab.zip with the FileBridge create_zip tool, verify it.

## Rules
- Never touch GitHub. Never claim a test/build/save happened unless a tool confirmed it.
- Keep CI layout: app/src/main/cpp/jni_bridge.cpp and app/src/main/cpp/core/*.cpp (flat).
