package com.rubikailab.app.ui

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import android.widget.Button
import android.widget.TextView
import com.rubikailab.app.Lab
import com.rubikailab.app.TrainingService
import com.rubikailab.app.core.TrainStats

/**
 * Tab 2: start and stop training, watch the metrics, change the training settings, save or reset
 * the model. Training itself runs in [TrainingService]; this page only listens to [Lab].
 */
class TrainPage(context: Context) : PageView(context), Lab.Listener {

    private val table = StatTable(context, STAT_NAMES)
    private val lossChart = ChartView(context, "Loss", Theme.WARN, null, null, 3)
    private val accuracyChart = ChartView(context, "Accuracy (within 0.5 moves of the target)", Theme.GOOD, 0f, 1f, 2)
    private val depthChart = ChartView(context, "Curriculum depth", Theme.ACCENT, null, null, 0)
    private val speedChart = ChartView(context, "Samples per second", Theme.MUTED, null, null, 0)

    private val startButton: Button
    private val stopButton: Button
    private val resetButton: Button
    private val messageView: TextView
    private val batchStepper: OptionStepper
    private val rateStepper: OptionStepper
    private val depthStepper: OptionStepper
    private val threadStepper: OptionStepper

    private var lastChartAt = 0L
    private var askedNotifications = false

    init {
        val statusCard = context.card()
        statusCard.addView(context.heading("Training"))
        statusCard.addTo(table, 8)
        body.addView(statusCard, lp(MATCH, WRAP))

        startButton = context.button("Start training", true) { startTraining() }
        stopButton = context.button("Stop", false) { TrainingService.stop(context) }
        body.addTo(context.row(startButton, stopButton), 10)
        messageView = context.muted("")
        body.addTo(messageView, 6)

        body.addTo(lossChart, 12)
        body.addTo(accuracyChart, 8)
        body.addTo(depthChart, 8)
        body.addTo(speedChart, 8)

        val settings = context.card()
        settings.addView(context.heading("Training settings"))
        settings.addTo(context.muted("Changes apply immediately, also while training."), 2)
        batchStepper = OptionStepper(
            context, "Batch size", BATCH_OPTIONS.map { it.toString() },
            nearestIndex(BATCH_OPTIONS, Lab.train.batch)
        ) { i ->
            Lab.train.batch = BATCH_OPTIONS[i]
            Lab.applyTrainSettings()
        }
        rateStepper = OptionStepper(
            context, "Learning rate", RATE_LABELS,
            nearestIndex(RATE_OPTIONS, Lab.train.learningRate)
        ) { i ->
            Lab.train.learningRate = RATE_OPTIONS[i]
            Lab.applyTrainSettings()
        }
        depthStepper = OptionStepper(
            context, "Max scramble depth", DEPTH_LABELS, Lab.train.maxDepth - MIN_DEPTH
        ) { i ->
            Lab.train.maxDepth = i + MIN_DEPTH
            Lab.applyTrainSettings()
        }
        val maxThreads = maxOf(1, minOf(8, Lab.cores()))
        threadStepper = OptionStepper(
            context, "Threads", (1..maxThreads).map { it.toString() }, Lab.train.threads - 1
        ) { i ->
            Lab.train.threads = i + 1
            Lab.applyTrainSettings()
        }
        settings.addTo(batchStepper, 10)
        settings.addTo(rateStepper, 8)
        settings.addTo(depthStepper, 8)
        settings.addTo(threadStepper, 8)
        body.addTo(settings, 14)

        val saveButton = context.button("Save checkpoint", false) { saveCheckpoint() }
        resetButton = context.button("Reset model", false) { confirmReset() }
        body.addTo(context.row(saveButton, resetButton), 12)
        body.addTo(context.muted(HOW_IT_LEARNS), 14)

        showStats(Lab.latest)
        setRunning(Lab.training)
        refreshCharts()
    }

    override fun onShow() {
        Lab.removeListener(this)
        Lab.addListener(this)
        refreshSettings()
        showStats(Lab.latest)
        setRunning(Lab.training)
        refreshCharts()
    }

    override fun onHide() {
        Lab.removeListener(this)
    }

    // ------------------------------------------------------------------ Lab.Listener (UI thread)

    override fun onStats(stats: TrainStats) {
        showStats(stats)
        val now = SystemClock.elapsedRealtime()
        if (now - lastChartAt >= 1000L) {
            lastChartAt = now
            refreshCharts()
        }
    }

    override fun onTrainingChanged(running: Boolean) {
        setRunning(running)
        showStats(Lab.latest)
        refreshCharts()
    }

    // ------------------------------------------------------------------ actions

    private fun startTraining() {
        if (!Lab.ready) {
            messageView.text = Lab.error ?: "The engine is not ready."
            return
        }
        requestNotificationPermission()
        messageView.text = if (TrainingService.start(context)) {
            "Training keeps running in the background. Use Stop here or in the notification."
        } else {
            "Android refused to start the training service."
        }
    }

    /** Android 13+ hides the foreground notification until this is granted; training works either way. */
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33 || askedNotifications) return
        val activity = context as? Activity ?: return
        if (activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        askedNotifications = true
        activity.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun saveCheckpoint() {
        messageView.text = if (Lab.saveCheckpoint()) "Checkpoint saved." else "Saving the checkpoint failed."
    }

    private fun confirmReset() {
        AlertDialog.Builder(context)
            .setTitle("Reset model?")
            .setMessage("All learned weights and the training history are discarded. This cannot be undone.")
            .setPositiveButton("Reset") { _, _ -> resetModel() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun resetModel() {
        if (Lab.resetModel()) {
            messageView.text = "Model reset to a fresh network."
            showStats(Lab.currentStats())
            refreshCharts()
        } else {
            messageView.text = "Stop training before resetting the model."
        }
    }

    // ------------------------------------------------------------------ display

    private fun setRunning(running: Boolean) {
        startButton.isEnabled = !running
        stopButton.isEnabled = running
        resetButton.isEnabled = !running
        table.set(0, if (running) "Training" else "Idle")
    }

    private fun showStats(s: TrainStats) {
        table.set(1, s.depth.toString() + " of " + Lab.train.maxDepth)
        table.set(2, Format.count(s.iterations))
        table.set(3, Format.count(s.steps))
        table.set(4, Format.count(s.samples))
        table.set(5, Format.fixed(s.loss, 4))
        table.set(6, Format.fixed(s.mae, 2) + " moves")
        table.set(7, Format.percent(s.accuracy))
        table.set(8, Format.count(s.samplesPerSec.toLong()) + " /s on " + s.threads + " thread(s)")
        table.set(9, Format.count(Lab.paramCount))
        table.set(10, if (Lab.checkpointLoaded) "yes" else "no")
    }

    private fun refreshCharts() {
        val h = Lab.historySnapshot()
        lossChart.setValues(FloatArray(h.size) { h[it].loss.toFloat() })
        accuracyChart.setValues(FloatArray(h.size) { h[it].accuracy.toFloat() })
        depthChart.setValues(FloatArray(h.size) { h[it].depth.toFloat() })
        speedChart.setValues(FloatArray(h.size) { h[it].samplesPerSec.toFloat() })
    }

    private fun refreshSettings() {
        batchStepper.select(nearestIndex(BATCH_OPTIONS, Lab.train.batch))
        rateStepper.select(nearestIndex(RATE_OPTIONS, Lab.train.learningRate))
        depthStepper.select(Lab.train.maxDepth - MIN_DEPTH)
        threadStepper.select(Lab.train.threads - 1)
    }

    private companion object {
        val STAT_NAMES = listOf(
            "State", "Curriculum depth", "Target updates", "Training steps", "Samples seen", "Loss",
            "Mean error", "Accuracy", "Speed", "Parameters", "Restored checkpoint"
        )
        val BATCH_OPTIONS = intArrayOf(64, 128, 256, 512, 1024)
        val RATE_OPTIONS = floatArrayOf(1.0e-4f, 3.0e-4f, 1.0e-3f, 3.0e-3f, 1.0e-2f)
        val RATE_LABELS = listOf("1e-4", "3e-4", "1e-3", "3e-3", "1e-2")
        const val MIN_DEPTH = 4
        val DEPTH_LABELS = (MIN_DEPTH..20).map { it.toString() }
        const val HOW_IT_LEARNS =
            "How it learns: the network estimates how many moves a cube is from solved. It trains on random " +
                "scrambles; the target for a state is 1 + the best estimate among the states one move away " +
                "(approximate value iteration), and 0 for the solved cube. No solver and no stored solutions " +
                "are involved. The scramble depth grows as the accuracy improves."
    }
}
