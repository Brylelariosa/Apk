package com.rubikailab.app.ui

import android.content.Context
import android.widget.LinearLayout
import com.rubikailab.app.Lab
import java.util.Locale

/**
 * The three limits every search uses: node budget, A* weight and time limit. Reads and writes
 * [Lab.search], so the Cube tab and the Test tab always agree. Call [refresh] when a page is shown.
 */
class SearchSettingsCard(context: Context) : LinearLayout(context) {

    private val nodeOptions = intArrayOf(2000, 5000, 10000, 20000, 50000)
    private val weightOptions = floatArrayOf(0f, 0.2f, 0.4f, 0.6f, 0.8f, 1f)
    private val timeoutOptions = intArrayOf(2000, 5000, 10000, 20000, 60000)

    private val nodes: OptionStepper
    private val weight: OptionStepper
    private val timeout: OptionStepper

    init {
        orientation = VERTICAL
        background = context.rounded(Theme.PANEL, 14f)
        setPadding(context.dp(14), context.dp(12), context.dp(14), context.dp(12))
        addView(context.heading("Search limits"))
        addTo(
            context.muted(
                "Used by every solve and benchmark. The search ranks states by w x (moves so far) + estimate: " +
                    "w = 1 is classic A*, a lower w is faster but gives longer solutions."
            ),
            2
        )

        nodes = OptionStepper(
            context, "Node budget", nodeOptions.map { Format.compact(it.toLong()) },
            nearestIndex(nodeOptions, Lab.search.maxExpansions)
        ) { i ->
            Lab.search.maxExpansions = nodeOptions[i]
            Lab.saveSearchSettings()
        }
        weight = OptionStepper(
            context, "Weight w", weightOptions.map { String.format(Locale.US, "%.1f", it) },
            nearestIndex(weightOptions, Lab.search.lambda)
        ) { i ->
            Lab.search.lambda = weightOptions[i]
            Lab.saveSearchSettings()
        }
        timeout = OptionStepper(
            context, "Time limit", timeoutOptions.map { (it / 1000).toString() + " s" },
            nearestIndex(timeoutOptions, Lab.search.timeoutMs)
        ) { i ->
            Lab.search.timeoutMs = timeoutOptions[i]
            Lab.saveSearchSettings()
        }
        addTo(nodes, 10)
        addTo(weight, 8)
        addTo(timeout, 8)
    }

    /** Shows the values currently stored in [Lab.search]. */
    fun refresh() {
        nodes.select(nearestIndex(nodeOptions, Lab.search.maxExpansions))
        weight.select(nearestIndex(weightOptions, Lab.search.lambda))
        timeout.select(nearestIndex(timeoutOptions, Lab.search.timeoutMs))
    }

    /** Locks the steppers while a search or benchmark is running. */
    fun setActive(on: Boolean) {
        nodes.setActive(on)
        weight.setActive(on)
        timeout.setActive(on)
    }
}
