package com.rubikailab.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import com.rubikailab.app.ui.CubePage
import com.rubikailab.app.ui.MATCH
import com.rubikailab.app.ui.PageView
import com.rubikailab.app.ui.TestPage
import com.rubikailab.app.ui.Theme
import com.rubikailab.app.ui.TrainPage
import com.rubikailab.app.ui.WRAP
import com.rubikailab.app.ui.dp
import com.rubikailab.app.ui.heading
import com.rubikailab.app.ui.label
import com.rubikailab.app.ui.lp
import com.rubikailab.app.ui.muted

/**
 * Single activity with three tabs (Cube, Train, Test). Only the selected page is attached to the
 * window; the pages themselves live as long as the activity, so their state survives tab switches.
 * Training is not tied to this activity: [TrainingService] keeps running when it is closed.
 */
class MainActivity : Activity() {

    private lateinit var content: FrameLayout
    private val tabs = ArrayList<TextView>()
    private val pages = arrayOfNulls<PageView>(TAB_NAMES.size)
    private var selected = -1
    private var resumed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Lab.ready) {
            showFailure(Lab.error)
            return
        }
        buildUi()
        select(savedInstanceState?.getInt(KEY_TAB, 0) ?: 0)
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        if (selected >= 0) pageAt(selected).onShow()
    }

    override fun onPause() {
        if (selected >= 0) pageAt(selected).onHide()
        resumed = false
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_TAB, selected)
    }

    // ------------------------------------------------------------------ layout

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Theme.BG)

        content = FrameLayout(this)
        root.addView(content, lp(MATCH, 0, 1f))

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.setBackgroundColor(Theme.NAV)
        for (i in TAB_NAMES.indices) {
            val tab = label(TAB_NAMES[i], 14f, Theme.MUTED, true)
            tab.gravity = Gravity.CENTER
            tab.setPadding(0, dp(14), 0, dp(14))
            tab.setOnClickListener { select(i) }
            nav.addView(tab, lp(0, WRAP, 1f))
            tabs.add(tab)
        }
        root.addView(nav, lp(MATCH, WRAP))
        setContentView(root)
    }

    private fun select(index: Int) {
        val target = index.coerceIn(0, TAB_NAMES.size - 1)
        if (target == selected && content.childCount > 0) return
        if (selected >= 0 && resumed) pageAt(selected).onHide()
        selected = target
        val page = pageAt(target)
        content.removeAllViews()
        content.addView(page, FrameLayout.LayoutParams(MATCH, MATCH))
        for (i in tabs.indices) styleTab(i, i == target)
        if (resumed) page.onShow()
    }

    private fun styleTab(i: Int, on: Boolean) {
        val tab = tabs[i]
        tab.setTextColor(if (on) Theme.ACCENT else Theme.MUTED)
        tab.setBackgroundColor(if (on) Theme.PANEL else Theme.NAV)
    }

    private fun pageAt(i: Int): PageView {
        val existing = pages[i]
        if (existing != null) return existing
        val created: PageView = when (i) {
            0 -> CubePage(this)
            1 -> TrainPage(this)
            else -> TestPage(this)
        }
        pages[i] = created
        return created
    }

    private fun showFailure(message: String?) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.setBackgroundColor(Theme.BG)
        box.setPadding(dp(24), dp(24), dp(24), dp(24))
        box.addView(heading("Rubik AI Lab cannot start"))
        val detail = muted(message ?: "The native engine is not available on this device.")
        detail.setPadding(0, dp(12), 0, 0)
        box.addView(detail)
        setContentView(box)
    }

    private companion object {
        val TAB_NAMES = arrayOf("Cube", "Train", "Test")
        const val KEY_TAB = "tab"
    }
}
