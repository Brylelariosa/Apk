package com.rubikailab.app.core

import java.util.Random

/**
 * Kotlin side of the cube model. Geometry and move tables are copied from the native core, so the
 * renderer, the search and the UI can never disagree about what a move does.
 *
 * State: 54 bytes, faces U R F D L B (9 facelets each); every byte is the id of the face the colour
 * belongs to in the solved cube. Move = face * 2 + direction (0 = clockwise, 1 = counter-clockwise,
 * both seen from outside the face).
 * Axes: x = R, y = U, z = F. Facelet position values are cubie coordinates in {-1, 0, 1}.
 */
object Cube {
    const val FACELETS = 54
    const val MOVES = 12

    val MOVE_NAMES = arrayOf("U", "U'", "R", "R'", "F", "F'", "D", "D'", "L", "L'", "B", "B'")

    @Volatile
    private var perm: Array<IntArray> = emptyArray()

    @Volatile
    private var geometry: IntArray = IntArray(0)

    val ready: Boolean get() = perm.isNotEmpty()

    /** Copies the tables out of the native library. Returns false when the library is unavailable. */
    @Synchronized
    fun init(): Boolean {
        if (perm.isNotEmpty()) return true
        if (!NativeBridge.ensureLoaded()) return false
        val flat = NativeBridge.nativeMoveTable()
        val geo = NativeBridge.nativeGeometry()
        if (flat.size != MOVES * FACELETS || geo.size != FACELETS * 6) return false
        geometry = geo
        perm = Array(MOVES) { m -> IntArray(FACELETS) { i -> flat[m * FACELETS + i] } }
        return true
    }

    /** Cubie coordinate (-1, 0 or 1) of a facelet along axis k (0 = x / R, 1 = y / U, 2 = z / F). */
    fun pos(facelet: Int, k: Int): Int = geometry[facelet * 6 + k]

    /** Outward normal component of a facelet along axis k. */
    fun normal(facelet: Int, k: Int): Int = geometry[facelet * 6 + 3 + k]

    /** Outward normal of the face that [move] turns (taken from that face's centre facelet). */
    fun faceNormal(move: Int, k: Int): Int = normal((move / 2) * 9 + 4, k)

    fun solved(): ByteArray = ByteArray(FACELETS) { (it / 9).toByte() }

    fun apply(state: ByteArray, move: Int): ByteArray {
        val p = perm[move]
        return ByteArray(FACELETS) { state[p[it]] }
    }

    fun applyAll(state: ByteArray, moves: IntArray): ByteArray {
        var s = state
        for (m in moves) s = apply(s, m)
        return s
    }

    fun isSolved(state: ByteArray): Boolean {
        for (i in 0 until FACELETS) {
            if (state[i].toInt() != i / 9) return false
        }
        return true
    }

    fun inverse(move: Int): Int = move xor 1

    fun format(moves: IntArray): String = moves.joinToString(" ") { MOVE_NAMES[it] }

    /** Random walk scramble: never undoes the previous move, never turns one face three times in a row. */
    fun scramble(rng: Random, length: Int): IntArray {
        val out = IntArray(length)
        var prev = -1
        var run = 0
        for (i in 0 until length) {
            var m = 0
            var ok = false
            while (!ok) {
                m = rng.nextInt(MOVES)
                ok = true
                if (prev >= 0) {
                    if (m == (prev xor 1)) ok = false
                    if (m / 2 == prev / 2 && run >= 2) ok = false
                }
            }
            run = if (prev >= 0 && m / 2 == prev / 2) run + 1 else 1
            prev = m
            out[i] = m
        }
        return out
    }
}
