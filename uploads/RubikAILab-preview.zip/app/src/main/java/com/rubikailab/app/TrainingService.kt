package com.rubikailab.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import com.rubikailab.app.core.NativeBridge
import com.rubikailab.app.core.TrainStats
import java.util.Locale

/**
 * Foreground service that keeps the value network training while the app is in the background.
 * It only calls the native trainer in short chunks and reports through [Lab]; no network is used.
 * The checkpoint is saved every 30 s and whenever training stops.
 */
class TrainingService : Service() {

    @Volatile
    private var running = false
    private var thread: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            // The training loop notices the flag, saves, and stops the service itself.
            running = false
            if (thread == null) stopSelf()
            return START_NOT_STICKY
        }
        startTraining()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    private fun startTraining() {
        try {
            ensureChannel()
            startForegroundCompat(buildNotification("Starting..."))
        } catch (t: Throwable) {
            Lab.setTraining(false)
            stopSelf()
            return
        }
        if (running) return
        if (!Lab.ready) {
            stopForeground(Service.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        running = true
        Lab.setTraining(true)
        val t = Thread({ trainLoop() }, "rubik-train")
        t.priority = Thread.NORM_PRIORITY - 1
        thread = t
        t.start()
    }

    private fun trainLoop() {
        var lastSave = SystemClock.elapsedRealtime()
        var lastNotify = 0L
        try {
            while (running) {
                val stats = TrainStats.decode(NativeBridge.nativeTrain(Lab.handle, CHUNK_MS))
                Lab.publishStats(stats)
                val now = SystemClock.elapsedRealtime()
                if (now - lastNotify >= 2000L) {
                    lastNotify = now
                    notifyProgress(stats)
                }
                if (now - lastSave >= AUTOSAVE_MS) {
                    lastSave = now
                    Lab.saveCheckpoint()
                }
            }
        } finally {
            running = false
            Lab.saveCheckpoint()
            Lab.setTraining(false)
            Handler(Looper.getMainLooper()).post {
                thread = null
                stopForeground(Service.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    // ------------------------------------------------------------------ notification

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Training", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun newBuilder(): Notification.Builder =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            Notification.Builder(this)
        }

    private fun buildNotification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, TrainingService::class.java).setAction(ACTION_STOP),
            flags
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Stop", stop
        ).build()
        return newBuilder()
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("Rubik AI Lab is training")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(stopAction)
            .build()
    }

    private fun startForegroundCompat(n: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun notifyProgress(s: TrainStats) {
        val text = String.format(
            Locale.US, "Depth %d, loss %.3f, %d samples/s", s.depth, s.loss, s.samplesPerSec.toInt()
        )
        try {
            getSystemService(NotificationManager::class.java)?.notify(NOTIF_ID, buildNotification(text))
        } catch (t: Throwable) {
            // A missing notification must never stop training.
        }
    }

    companion object {
        const val ACTION_START = "com.rubikailab.app.action.START"
        const val ACTION_STOP = "com.rubikailab.app.action.STOP"
        private const val CHANNEL_ID = "training"
        private const val NOTIF_ID = 1
        private const val CHUNK_MS = 250
        private const val AUTOSAVE_MS = 30000L

        /** Returns false when Android refused to start the service. */
        fun start(context: Context): Boolean {
            return try {
                val i = Intent(context, TrainingService::class.java).setAction(ACTION_START)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(i)
                } else {
                    context.startService(i)
                }
                true
            } catch (t: Throwable) {
                false
            }
        }

        fun stop(context: Context) {
            try {
                context.startService(Intent(context, TrainingService::class.java).setAction(ACTION_STOP))
            } catch (t: Throwable) {
                // The service is not running, nothing to stop.
            }
        }
    }
}
