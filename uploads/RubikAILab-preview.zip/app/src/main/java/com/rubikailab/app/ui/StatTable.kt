package com.rubikailab.app.ui

import android.content.Context
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/** Two-column list: muted name on the left, bold value on the right. */
class StatTable(context: Context, names: List<String>) : LinearLayout(context) {

    private val values = ArrayList<TextView>()

    init {
        orientation = VERTICAL
        for (name in names) {
            val row = LinearLayout(context)
            row.orientation = HORIZONTAL
            row.addView(context.label(name, 13f, Theme.MUTED, false), lp(0, WRAP, 1f))
            val value = context.label("-", 13f, Theme.TEXT, true)
            value.gravity = Gravity.END
            row.addView(value, lp(WRAP, WRAP))
            val params = lp(MATCH, WRAP)
            params.topMargin = context.dp(3)
            addView(row, params)
            values.add(value)
        }
    }

    fun set(index: Int, text: String) {
        if (index in values.indices) values[index].text = text
    }
}
