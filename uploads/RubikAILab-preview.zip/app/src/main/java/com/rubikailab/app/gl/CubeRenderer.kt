package com.rubikailab.app.gl

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.SystemClock
import android.util.Log
import com.rubikailab.app.core.Cube
import java.nio.Buffer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * OpenGL ES 2.0 cube renderer.
 *
 * The scene is built from the native facelet geometry (Cube.pos / Cube.normal), the same table the
 * move permutations were generated from, so what is drawn always matches the simulated state.
 * A turn animates the stickers and cubies of the turning layer about the face normal; when the
 * animation ends the move is applied to the displayed state with the native move table.
 *
 * Threading: public methods may be called from any thread; all drawing happens on the GL thread.
 */
class CubeRenderer(
    private val requestRender: () -> Unit,
    private val onMoveDone: (Int) -> Unit
) : GLSurfaceView.Renderer {

    private class Mesh(val buffer: FloatBuffer, val count: Int)

    private class Frame(
        val finished: Int,
        val angle: Float,
        val nx: Float,
        val ny: Float,
        val nz: Float,
        val more: Boolean,
        val staticMesh: Mesh?,
        val movingMesh: Mesh?
    )

    private class MeshBuilder {
        private var data = FloatArray(9 * 8192)
        private var size = 0

        fun vertex(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float, c: FloatArray) {
            if (size + 9 > data.size) data = data.copyOf(data.size * 2)
            data[size] = x
            data[size + 1] = y
            data[size + 2] = z
            data[size + 3] = nx
            data[size + 4] = ny
            data[size + 5] = nz
            data[size + 6] = c[0]
            data[size + 7] = c[1]
            data[size + 8] = c[2]
            size += 9
        }

        fun build(): Mesh {
            val fb = ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            fb.put(data, 0, size)
            return Mesh(fb, size / 9)
        }
    }

    private val lock = Any()
    private var display: ByteArray = Cube.solved()
    private val queue = java.util.ArrayDeque<Int>()
    private var current = -1
    private var currentStart = 0L
    private var currentDuration = 260L
    private var version = 0
    private var builtVersion = -1
    private var staticMesh: Mesh? = null
    private var movingMesh: Mesh? = null

    @Volatile
    var yaw = DEFAULT_YAW

    @Volatile
    var pitch = DEFAULT_PITCH

    private var program = 0
    private var aPos = 0
    private var aNormal = 0
    private var aColor = 0
    private var uVP = 0
    private var uModel = 0
    private var uNormalMat = 0

    private val proj = FloatArray(16)
    private val camera = FloatArray(16)
    private val vp = FloatArray(16)
    private val orbit = FloatArray(16)
    private val layer = FloatArray(16)
    private val model = FloatArray(16)
    private val normalMat = FloatArray(9)

    // ---------------------------------------------------------------- public API (any thread)

    /** Shows [state] immediately and drops every queued animation. */
    fun setState(state: ByteArray) {
        synchronized(lock) {
            display = state.copyOf()
            queue.clear()
            current = -1
            version++
        }
        requestRender()
    }

    fun enqueue(move: Int) {
        synchronized(lock) { queue.addLast(move) }
        requestRender()
    }

    fun enqueueAll(moves: IntArray) {
        synchronized(lock) {
            for (m in moves) queue.addLast(m)
        }
        requestRender()
    }

    fun isAnimating(): Boolean = synchronized(lock) { current >= 0 || !queue.isEmpty() }

    fun rotate(dx: Float, dy: Float) {
        yaw += dx * 0.45f
        pitch = (pitch + dy * 0.45f).coerceIn(-89f, 89f)
        requestRender()
    }

    fun resetView() {
        yaw = DEFAULT_YAW
        pitch = DEFAULT_PITCH
        requestRender()
    }

    // ---------------------------------------------------------------- GLSurfaceView.Renderer

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.039f, 0.047f, 0.067f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        program = buildProgram()
        if (program != 0) {
            aPos = GLES20.glGetAttribLocation(program, "aPos")
            aNormal = GLES20.glGetAttribLocation(program, "aNormal")
            aColor = GLES20.glGetAttribLocation(program, "aColor")
            uVP = GLES20.glGetUniformLocation(program, "uVP")
            uModel = GLES20.glGetUniformLocation(program, "uModel")
            uNormalMat = GLES20.glGetUniformLocation(program, "uNormalMat")
        }
        synchronized(lock) { builtVersion = -1 }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val aspect = if (height > 0) width.toFloat() / height.toFloat() else 1f
        Matrix.perspectiveM(proj, 0, 34f, aspect, 4f, 40f)
        val dist = minOf(24f, 10.6f / minOf(1f, aspect))
        Matrix.setLookAtM(camera, 0, 0f, 0f, dist, 0f, 0f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, camera, 0)
    }

    override fun onDrawFrame(gl: GL10?) {
        val f = advance()
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (program != 0) {
            GLES20.glUseProgram(program)
            Matrix.setIdentityM(orbit, 0)
            Matrix.rotateM(orbit, 0, pitch, 1f, 0f, 0f)
            Matrix.rotateM(orbit, 0, yaw, 0f, 1f, 0f)
            val sm = f.staticMesh
            if (sm != null && sm.count > 0) drawMesh(sm, orbit)
            val mm = f.movingMesh
            if (mm != null && mm.count > 0) {
                Matrix.setRotateM(layer, 0, f.angle, f.nx, f.ny, f.nz)
                Matrix.multiplyMM(model, 0, orbit, 0, layer, 0)
                drawMesh(mm, model)
            }
        }
        if (f.finished >= 0) onMoveDone(f.finished)
        if (f.more) requestRender()
    }

    // ---------------------------------------------------------------- animation clock

    private fun advance(): Frame = synchronized(lock) {
        val now = SystemClock.uptimeMillis()
        if (current < 0 && !queue.isEmpty()) {
            current = queue.pollFirst()
            currentStart = now
            // The longer the backlog, the faster the turns, so long solutions do not drag on.
            currentDuration = (780L / (3 + queue.size)).coerceIn(70L, 260L)
            version++
        }
        var finished = -1
        var angle = 0f
        var nx = 0f
        var ny = 0f
        var nz = 1f
        if (current >= 0) {
            val t = ((now - currentStart).toFloat() / currentDuration.toFloat()).coerceIn(0f, 1f)
            if (t >= 1f) {
                display = Cube.apply(display, current)
                finished = current
                current = -1
                version++
            } else {
                val eased = t * t * (3f - 2f * t)
                // Clockwise seen from outside is a -90 degree turn about the outward normal (right-hand rule).
                angle = (if (current % 2 == 0) -90f else 90f) * eased
                nx = Cube.faceNormal(current, 0).toFloat()
                ny = Cube.faceNormal(current, 1).toFloat()
                nz = Cube.faceNormal(current, 2).toFloat()
            }
        }
        if (builtVersion != version) {
            rebuild()
            builtVersion = version
        }
        Frame(finished, angle, nx, ny, nz, current >= 0 || !queue.isEmpty(), staticMesh, movingMesh)
    }

    // ---------------------------------------------------------------- mesh building

    /** Rebuilds both meshes from [display] and [current]. Caller holds [lock]. */
    private fun rebuild() {
        val st = MeshBuilder()
        val mv = MeshBuilder()
        var nx = 0
        var ny = 0
        var nz = 0
        val turning = current >= 0
        if (turning) {
            nx = Cube.faceNormal(current, 0)
            ny = Cube.faceNormal(current, 1)
            nz = Cube.faceNormal(current, 2)
        }
        for (x in -1..1) {
            for (y in -1..1) {
                for (z in -1..1) {
                    val inLayer = turning && (x * nx + y * ny + z * nz) == 1
                    addCubie(if (inLayer) mv else st, x, y, z)
                }
            }
        }
        for (i in 0 until Cube.FACELETS) {
            val inLayer = turning &&
                (Cube.pos(i, 0) * nx + Cube.pos(i, 1) * ny + Cube.pos(i, 2) * nz) == 1
            addSticker(if (inLayer) mv else st, i, display[i].toInt())
        }
        staticMesh = st.build()
        movingMesh = mv.build()
    }

    private fun addCubie(mb: MeshBuilder, cx: Int, cy: Int, cz: Int) {
        for (a in 0..2) {
            for (s in -1..1 step 2) {
                val n = floatArrayOf(0f, 0f, 0f)
                n[a] = s.toFloat()
                val u = AXES[(a + 1) % 3]
                val v = AXES[(a + 2) % 3]
                val cxf = cx + n[0] * HALF
                val cyf = cy + n[1] * HALF
                val czf = cz + n[2] * HALF
                val p00 = floatArrayOf(cxf - u[0] * HALF - v[0] * HALF, cyf - u[1] * HALF - v[1] * HALF, czf - u[2] * HALF - v[2] * HALF)
                val p10 = floatArrayOf(cxf + u[0] * HALF - v[0] * HALF, cyf + u[1] * HALF - v[1] * HALF, czf + u[2] * HALF - v[2] * HALF)
                val p11 = floatArrayOf(cxf + u[0] * HALF + v[0] * HALF, cyf + u[1] * HALF + v[1] * HALF, czf + u[2] * HALF + v[2] * HALF)
                val p01 = floatArrayOf(cxf - u[0] * HALF + v[0] * HALF, cyf - u[1] * HALF + v[1] * HALF, czf - u[2] * HALF + v[2] * HALF)
                tri(mb, p00, p10, p11, n, BODY)
                tri(mb, p00, p11, p01, n, BODY)
            }
        }
    }

    private fun addSticker(mb: MeshBuilder, facelet: Int, colorId: Int) {
        val n = floatArrayOf(
            Cube.normal(facelet, 0).toFloat(),
            Cube.normal(facelet, 1).toFloat(),
            Cube.normal(facelet, 2).toFloat()
        )
        var axis = 0
        for (k in 0..2) {
            if (n[k] != 0f) axis = k
        }
        val u = AXES[(axis + 1) % 3]
        val v = AXES[(axis + 2) % 3]
        val off = HALF + 0.006f
        val c = floatArrayOf(
            Cube.pos(facelet, 0) + n[0] * off,
            Cube.pos(facelet, 1) + n[1] * off,
            Cube.pos(facelet, 2) + n[2] * off
        )
        val col = COLORS[colorId.coerceIn(0, 5)]
        for (k in 0 until 8) {
            val k2 = (k + 1) % 8
            val a1 = OCT[k * 2]
            val b1 = OCT[k * 2 + 1]
            val a2 = OCT[k2 * 2]
            val b2 = OCT[k2 * 2 + 1]
            val p1 = floatArrayOf(c[0] + u[0] * a1 + v[0] * b1, c[1] + u[1] * a1 + v[1] * b1, c[2] + u[2] * a1 + v[2] * b1)
            val p2 = floatArrayOf(c[0] + u[0] * a2 + v[0] * b2, c[1] + u[1] * a2 + v[1] * b2, c[2] + u[2] * a2 + v[2] * b2)
            tri(mb, c, p1, p2, n, col)
        }
    }

    private fun tri(mb: MeshBuilder, a: FloatArray, b: FloatArray, c: FloatArray, n: FloatArray, col: FloatArray) {
        mb.vertex(a[0], a[1], a[2], n[0], n[1], n[2], col)
        mb.vertex(b[0], b[1], b[2], n[0], n[1], n[2], col)
        mb.vertex(c[0], c[1], c[2], n[0], n[1], n[2], col)
    }

    // ---------------------------------------------------------------- drawing

    private fun seek(b: Buffer, position: Int) {
        b.position(position)
    }

    private fun drawMesh(mesh: Mesh, modelMatrix: FloatArray) {
        GLES20.glUniformMatrix4fv(uVP, 1, false, vp, 0)
        GLES20.glUniformMatrix4fv(uModel, 1, false, modelMatrix, 0)
        // Normal matrix = rotation part of the model matrix (the model is a pure rotation).
        normalMat[0] = modelMatrix[0]
        normalMat[1] = modelMatrix[1]
        normalMat[2] = modelMatrix[2]
        normalMat[3] = modelMatrix[4]
        normalMat[4] = modelMatrix[5]
        normalMat[5] = modelMatrix[6]
        normalMat[6] = modelMatrix[8]
        normalMat[7] = modelMatrix[9]
        normalMat[8] = modelMatrix[10]
        GLES20.glUniformMatrix3fv(uNormalMat, 1, false, normalMat, 0)

        val b = mesh.buffer
        seek(b, 0)
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, STRIDE, b)
        GLES20.glEnableVertexAttribArray(aPos)
        seek(b, 3)
        GLES20.glVertexAttribPointer(aNormal, 3, GLES20.GL_FLOAT, false, STRIDE, b)
        GLES20.glEnableVertexAttribArray(aNormal)
        seek(b, 6)
        GLES20.glVertexAttribPointer(aColor, 3, GLES20.GL_FLOAT, false, STRIDE, b)
        GLES20.glEnableVertexAttribArray(aColor)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, mesh.count)
    }

    private fun buildProgram(): Int {
        val vs = compile(GLES20.GL_VERTEX_SHADER, VERTEX_SHADER)
        val fs = compile(GLES20.GL_FRAGMENT_SHADER, FRAGMENT_SHADER)
        if (vs == 0 || fs == 0) return 0
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, vs)
        GLES20.glAttachShader(p, fs)
        GLES20.glLinkProgram(p)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(TAG, "program link failed: " + GLES20.glGetProgramInfoLog(p))
            GLES20.glDeleteProgram(p)
            return 0
        }
        return p
    }

    private fun compile(type: Int, source: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, source)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(TAG, "shader compile failed: " + GLES20.glGetShaderInfoLog(s))
            GLES20.glDeleteShader(s)
            return 0
        }
        return s
    }

    companion object {
        private const val TAG = "CubeRenderer"
        const val DEFAULT_YAW = -35f
        const val DEFAULT_PITCH = 28f

        private const val STRIDE = 9 * 4
        private const val HALF = 0.485f

        private val AXES = arrayOf(
            floatArrayOf(1f, 0f, 0f),
            floatArrayOf(0f, 1f, 0f),
            floatArrayOf(0f, 0f, 1f)
        )

        private val BODY = floatArrayOf(0.05f, 0.05f, 0.06f)

        // Colour id = id of the face the colour belongs to: U R F D L B.
        private val COLORS = arrayOf(
            floatArrayOf(0.96f, 0.96f, 0.94f), // U white
            floatArrayOf(0.80f, 0.09f, 0.12f), // R red
            floatArrayOf(0.06f, 0.62f, 0.26f), // F green
            floatArrayOf(0.98f, 0.80f, 0.08f), // D yellow
            floatArrayOf(0.98f, 0.45f, 0.04f), // L orange
            floatArrayOf(0.08f, 0.30f, 0.82f)  // B blue
        )

        // Sticker outline: a square with chamfered corners, (a, b) pairs counter-clockwise.
        private const val S = 0.43f
        private const val CH = 0.11f
        private val OCT = floatArrayOf(
            -S + CH, -S, S - CH, -S, S, -S + CH, S, S - CH,
            S - CH, S, -S + CH, S, -S, S - CH, -S, -S + CH
        )

        private const val VERTEX_SHADER = """
uniform mat4 uVP;
uniform mat4 uModel;
uniform mat3 uNormalMat;
attribute vec3 aPos;
attribute vec3 aNormal;
attribute vec3 aColor;
varying vec3 vColor;
void main() {
  vec3 n = normalize(uNormalMat * aNormal);
  float diff = max(dot(n, normalize(vec3(0.35, 0.8, 0.6))), 0.0);
  vColor = aColor * (0.60 + 0.50 * diff);
  gl_Position = uVP * uModel * vec4(aPos, 1.0);
}
"""

        private const val FRAGMENT_SHADER = """
precision mediump float;
varying vec3 vColor;
void main() {
  gl_FragColor = vec4(vColor, 1.0);
}
"""
    }
}
