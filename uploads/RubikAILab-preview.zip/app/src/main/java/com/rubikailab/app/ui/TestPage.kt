package com.rubikailab.app.ui

import android.content.Context
import android.widget.Button
import android.widget.TextView
import com.rubikailab.app.Lab
import com.rubikailab.app.core.EvalResult
import com.rubikailab.app.core.SolverMode
import com.rubikailab.app.core.TrainStats
import java.util.Locale

/**
 * Tab 3: held-out benchmark. The native engine owns a fixed set of test scrambles (depth 1 to 20,
 * 50 each) that are never used for training. The learned model and the conventional baseline are
 * measured separately with the same search limits, and every finished depth is saved as one line.
 */
class TestPage(context: Context) : PageView(context) {

    private val solverStepper: OptionStepper
    private val depthStepper: OptionStepper
    private val casesStepper: OptionStepper
    private val runButton: Button
    private val sweepButton: Button
    private val cancelButton: Button
    private val statusView: TextView
    private val resultsView: TextView
    private val chart = ChartView(context, "Solved % by depth (last sweep)", Theme.GOOD, 0f, 100f, 0)
    private val searchCard: SearchSettingsCard

    private val sweepRates = ArrayList<Float>()
    private var running = false
    private var sweeping = false
    private var stopRequested = false

    init {
        body.addView(context.heading("Held-out benchmark"))
        body.addTo(
            context.muted(
                "Fixed test scrambles that are never used for training (50 per depth, depth 1 to 20). " +
                    "The learned AI and the baseline use the same search limits and are listed separately."
            ),
            4
        )

        val card = context.card()
        solverStepper = OptionStepper(context, "Solver", listOf("Learned", "Baseline"), 0) { }
        depthStepper = OptionStepper(context, "Scramble depth", DEPTH_LABELS, DEFAULT_DEPTH_INDEX) { }
        casesStepper = OptionStepper(context, "Cases per depth", CASE_LABELS, CASE_LABELS.size - 1) { }
        card.addView(solverStepper)
        card.addTo(depthStepper, 8)
        card.addTo(casesStepper, 8)
        body.addTo(card, 12)

        runButton = context.button("Run this depth", true) { start(false) }
        sweepButton = context.button("Sweep depth 1 to N", false) { start(true) }
        body.addTo(context.row(runButton, sweepButton), 10)
        cancelButton = context.button("Cancel", false) { cancel() }
        body.addTo(cancelButton, 8)
        statusView = context.muted("Ready.")
        body.addTo(statusView, 8)
        body.addTo(chart, 10)

        val results = context.card()
        results.addView(context.heading("Saved results (newest first)"))
        resultsView = context.label("", 13f, Theme.TEXT, false)
        results.addTo(resultsView, 6)
        results.addTo(context.button("Clear results", false) { clearResults() }, 10)
        body.addTo(results, 14)

        searchCard = SearchSettingsCard(context)
        body.addTo(searchCard, 14)

        refreshControls()
        showResults()
    }

    override fun onShow() {
        searchCard.refresh()
        showResults()
    }

    // ------------------------------------------------------------------ running a benchmark

    private fun start(sweep: Boolean) {
        if (running) return
        if (!Lab.ready) {
            statusView.text = Lab.error ?: "The engine is not ready."
            return
        }
        val mode = if (solverStepper.index == 0) SolverMode.LEARNED else SolverMode.BASELINE
        val last = depthStepper.index + 1
        val cases = CASES[casesStepper.index]
        running = true
        sweeping = sweep
        stopRequested = false
        sweepRates.clear()
        chart.setValues(FloatArray(0))
        refreshControls()
        runDepth(mode, if (sweep) 1 else last, last, cases)
    }

    private fun runDepth(mode: Int, depth: Int, last: Int, cases: Int) {
        statusView.text = SolverMode.label(mode) + ": depth " + depth + " of " + last + ", " + cases + " cases..."
        Lab.evaluateAsync(mode, depth, cases) { result, model ->
            if (result.cancelled) {
                finish("Cancelled. Depth " + depth + " was not completed and is not saved.")
                return@evaluateAsync
            }
            Lab.addResult(line(mode, depth, result, model))
            if (sweeping) {
                sweepRates.add(if (result.total > 0) 100f * result.solved / result.total else 0f)
                chart.setValues(sweepRates.toFloatArray())
            }
            showResults()
            if (sweeping && depth < last && !stopRequested) {
                runDepth(mode, depth + 1, last, cases)
            } else if (stopRequested) {
                finish("Cancelled after depth " + depth + ".")
            } else {
                finish("Finished.")
            }
        }
    }

    private fun cancel() {
        if (!running) return
        stopRequested = true
        Lab.cancelJobs()
        statusView.text = "Cancelling..."
    }

    private fun finish(message: String) {
        running = false
        statusView.text = message
        refreshControls()
    }

    // ------------------------------------------------------------------ results

    private fun line(mode: Int, depth: Int, r: EvalResult, model: TrainStats): String {
        val sb = StringBuilder()
        sb.append(SolverMode.label(mode)).append(" | depth ").append(depth)
        val pct = if (r.total > 0) 100.0 * r.solved / r.total else 0.0
        sb.append(" | solved ").append(r.solved).append('/').append(r.total)
        sb.append(String.format(Locale.US, " (%.0f%%)", pct))
        if (r.solved > 0) {
            sb.append(String.format(Locale.US, " | avg %.1f moves", r.avgLength))
            sb.append(" | avg ").append(Format.count(r.avgExpanded.toLong())).append(" nodes")
            sb.append(String.format(Locale.US, " | avg %.0f ms", r.avgMs))
        }
        sb.append(" | limits ").append(Format.compact(Lab.search.maxExpansions.toLong()))
        sb.append(" nodes, w ").append(String.format(Locale.US, "%.1f", Lab.search.lambda))
        if (mode == SolverMode.LEARNED) {
            sb.append(" | model ").append(Format.model(model))
        }
        return sb.toString()
    }

    private fun showResults() {
        val lines = Lab.results()
        resultsView.text = if (lines.isEmpty()) "No benchmark has been run yet." else lines.joinToString("\n\n")
    }

    private fun clearResults() {
        Lab.clearResults()
        showResults()
    }

    private fun refreshControls() {
        val idle = !running
        runButton.isEnabled = idle
        sweepButton.isEnabled = idle
        cancelButton.isEnabled = running
        solverStepper.setActive(idle)
        depthStepper.setActive(idle)
        casesStepper.setActive(idle)
        searchCard.setActive(idle)
    }

    private companion object {
        val DEPTH_LABELS = (1..20).map { it.toString() }
        const val DEFAULT_DEPTH_INDEX = 5
        val CASES = intArrayOf(10, 25, 50)
        val CASE_LABELS = CASES.map { it.toString() }
    }
}
