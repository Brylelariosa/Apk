package com.rubikailab.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.rubikailab.app.core.Cube
import com.rubikailab.app.core.EvalResult
import com.rubikailab.app.core.NativeBridge
import com.rubikailab.app.core.SolveResult
import com.rubikailab.app.core.SolveStatus
import com.rubikailab.app.core.TrainStats
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/**
 * Process-wide owner of the native engine, the training history, the user settings and the
 * background executor that runs searches and benchmarks. The training loop itself lives in
 * [TrainingService]; it reports through [publishStats] / [setTraining].
 */
object Lab {
    interface Listener {
        fun onStats(stats: TrainStats)
        fun onTrainingChanged(running: Boolean)
    }

    class SearchSettings(var maxExpansions: Int, var lambda: Float, var timeoutMs: Int)

    class TrainSettings(var batch: Int, var learningRate: Float, var maxDepth: Int, var threads: Int)

    private const val PREFS = "rubikailab"
    private const val KEY_SEED = "seed"
    private const val KEY_RESULTS = "results"
    private const val MAX_RESULTS = 40
    private const val MAX_HISTORY = 1600

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "rubik-jobs") }
    private val listeners = CopyOnWriteArrayList<Listener>()
    private val historyLock = Any()
    private val history = ArrayList<TrainStats>()
    private var lastHistoryAt = 0L

    private var prefs: SharedPreferences? = null
    private lateinit var checkpoint: File

    @Volatile
    var handle = 0L
        private set

    @Volatile
    var error: String? = null
        private set

    @Volatile
    var training = false
        private set

    @Volatile
    var latest: TrainStats = TrainStats.EMPTY
        private set

    var checkpointLoaded = false
        private set

    var paramCount = 0
        private set

    val search = SearchSettings(20000, 0.6f, 20000)
    val train = TrainSettings(256, 1.0e-3f, 12, 2)

    val ready: Boolean get() = handle != 0L

    fun cores(): Int = Runtime.getRuntime().availableProcessors()

    private fun defaultThreads(): Int = maxOf(1, minOf(4, cores() / 2))

    // ------------------------------------------------------------------ start-up

    @Synchronized
    fun init(context: Context) {
        if (handle != 0L || error != null) return
        val app = context.applicationContext
        val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs = p
        checkpoint = File(app.filesDir, "checkpoint.bin")
        if (!NativeBridge.ensureLoaded()) {
            error = "The native library could not be loaded: " + NativeBridge.loadError
            return
        }
        if (!Cube.init()) {
            error = "The native cube tables are unavailable."
            return
        }
        loadSettings(p)
        paramCount = NativeBridge.nativeParamCount()
        val h = NativeBridge.nativeCreate(p.getLong(KEY_SEED, 1L))
        if (h == 0L) {
            error = "The native engine could not be created."
            return
        }
        if (checkpoint.exists()) {
            checkpointLoaded = NativeBridge.nativeLoad(h, checkpoint.absolutePath)
        }
        NativeBridge.nativeConfigure(h, train.batch, train.learningRate, train.maxDepth, train.threads)
        handle = h
        latest = TrainStats.decode(NativeBridge.nativeStats(h))
    }

    private fun loadSettings(p: SharedPreferences) {
        search.maxExpansions = p.getInt("s_exp", 20000)
        search.lambda = p.getFloat("s_lambda", 0.6f)
        search.timeoutMs = p.getInt("s_timeout", 20000)
        train.batch = p.getInt("t_batch", 256)
        train.learningRate = p.getFloat("t_lr", 1.0e-3f)
        train.maxDepth = p.getInt("t_depth", 12)
        train.threads = p.getInt("t_threads", defaultThreads())
    }

    fun saveSearchSettings() {
        val e = prefs?.edit() ?: return
        e.putInt("s_exp", search.maxExpansions)
        e.putFloat("s_lambda", search.lambda)
        e.putInt("s_timeout", search.timeoutMs)
        e.apply()
    }

    /** Stores the training settings and pushes them to the engine (safe while training runs). */
    fun applyTrainSettings() {
        val e = prefs?.edit()
        if (e != null) {
            e.putInt("t_batch", train.batch)
            e.putFloat("t_lr", train.learningRate)
            e.putInt("t_depth", train.maxDepth)
            e.putInt("t_threads", train.threads)
            e.apply()
        }
        if (ready) {
            NativeBridge.nativeConfigure(handle, train.batch, train.learningRate, train.maxDepth, train.threads)
        }
    }

    // ------------------------------------------------------------------ listeners and history

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    fun setTraining(on: Boolean) {
        training = on
        main.post {
            for (l in listeners) l.onTrainingChanged(on)
        }
    }

    fun publishStats(s: TrainStats) {
        latest = s
        val now = SystemClock.elapsedRealtime()
        synchronized(historyLock) {
            if (now - lastHistoryAt >= 1000L) {
                lastHistoryAt = now
                history.add(s)
                if (history.size > MAX_HISTORY) {
                    // Keep the whole run, just thinner: drop every second point.
                    val thinned = ArrayList<TrainStats>(history.size / 2 + 1)
                    var i = 0
                    while (i < history.size) {
                        thinned.add(history[i])
                        i += 2
                    }
                    history.clear()
                    history.addAll(thinned)
                }
            }
        }
        main.post {
            for (l in listeners) l.onStats(s)
        }
    }

    fun historySnapshot(): List<TrainStats> {
        synchronized(historyLock) {
            return ArrayList(history)
        }
    }

    private fun clearHistory() {
        synchronized(historyLock) {
            history.clear()
            lastHistoryAt = 0L
        }
    }

    // ------------------------------------------------------------------ model

    fun saveCheckpoint(): Boolean {
        if (!ready) return false
        return NativeBridge.nativeSave(handle, checkpoint.absolutePath)
    }

    /** Throws the learned weights away and starts a fresh model. Refused while training runs. */
    fun resetModel(): Boolean {
        if (!ready || training) return false
        val seed = System.currentTimeMillis()
        prefs?.edit()?.putLong(KEY_SEED, seed)?.apply()
        NativeBridge.nativeReset(handle, seed)
        NativeBridge.nativeConfigure(handle, train.batch, train.learningRate, train.maxDepth, train.threads)
        clearHistory()
        latest = TrainStats.decode(NativeBridge.nativeStats(handle))
        checkpointLoaded = false
        saveCheckpoint()
        return true
    }

    fun currentStats(): TrainStats {
        if (!ready) return TrainStats.EMPTY
        return TrainStats.decode(NativeBridge.nativeStats(handle))
    }

    // ------------------------------------------------------------------ searches and benchmarks

    fun solveAsync(mode: Int, state: ByteArray, done: (SolveResult) -> Unit) {
        val exp = search.maxExpansions
        val lambda = search.lambda
        val timeout = search.timeoutMs
        worker.execute {
            val result: SolveResult
            if (!ready) {
                result = SolveResult.failed(SolveStatus.INVALID)
            } else {
                NativeBridge.nativeSetCancel(handle, false)
                result = SolveResult.decode(NativeBridge.nativeSolve(handle, mode, state, exp, lambda, timeout))
            }
            main.post { done(result) }
        }
    }

    /** Runs the held-out scrambles of [depth]; [done] also receives the model state the run started from. */
    fun evaluateAsync(mode: Int, depth: Int, cases: Int, done: (EvalResult, TrainStats) -> Unit) {
        val exp = search.maxExpansions
        val lambda = search.lambda
        val timeout = search.timeoutMs
        worker.execute {
            var result = EvalResult(0, 0, 0.0, 0.0, 0.0, true)
            var model = TrainStats.EMPTY
            if (ready) {
                model = TrainStats.decode(NativeBridge.nativeStats(handle))
                NativeBridge.nativeSetCancel(handle, false)
                result = EvalResult.decode(
                    NativeBridge.nativeEvaluate(handle, mode, depth, cases, exp, lambda, timeout)
                )
            }
            val finalResult = result
            val finalModel = model
            main.post { done(finalResult, finalModel) }
        }
    }

    fun cancelJobs() {
        if (ready) NativeBridge.nativeSetCancel(handle, true)
    }

    // ------------------------------------------------------------------ saved benchmark lines

    fun results(): List<String> {
        val raw = prefs?.getString(KEY_RESULTS, "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split('\n')
    }

    fun addResult(line: String) {
        val list = ArrayList<String>(results())
        list.add(0, line)
        while (list.size > MAX_RESULTS) list.removeAt(list.size - 1)
        prefs?.edit()?.putString(KEY_RESULTS, list.joinToString("\n"))?.apply()
    }

    fun clearResults() {
        prefs?.edit()?.remove(KEY_RESULTS)?.apply()
    }
}
