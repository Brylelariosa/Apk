package com.rubikailab.app.core

/**
 * JNI surface of the native library "rubikcore". Every external function maps 1:1 to
 * app/src/main/cpp/jni_bridge.cpp (same names, same argument order); the result array layouts are
 * documented there and decoded in Models.kt.
 *
 * This must stay a Kotlin `object` in package com.rubikailab.app.core: the native side binds to
 * Java_com_rubikailab_app_core_NativeBridge_* and receives the singleton as its `jobject` argument.
 */
object NativeBridge {
    @Volatile
    private var loaded = false

    @Volatile
    var loadError: String? = null
        private set

    /** Loads the native library once. Returns false (and sets [loadError]) instead of crashing the app. */
    @Synchronized
    fun ensureLoaded(): Boolean {
        if (loaded) return true
        try {
            System.loadLibrary("rubikcore")
            loaded = true
            loadError = null
        } catch (t: Throwable) {
            loadError = t.message ?: t.javaClass.simpleName
        }
        return loaded
    }

    /** 54 x 6 ints: cubie position (x, y, z) then outward normal (x, y, z) of every facelet. */
    external fun nativeGeometry(): IntArray

    /** 12 x 54 ints: after move m the new facelet i holds the colour of old facelet table[m * 54 + i]. */
    external fun nativeMoveTable(): IntArray

    external fun nativeParamCount(): Int

    external fun nativeCreate(seed: Long): Long

    external fun nativeDestroy(handle: Long)

    external fun nativeReset(handle: Long, seed: Long)

    external fun nativeConfigure(handle: Long, batch: Int, learningRate: Float, maxDepth: Int, threads: Int)

    /** Trains for about [budgetMs] milliseconds, returns double[12] (see TrainStats.decode). */
    external fun nativeTrain(handle: Long, budgetMs: Int): DoubleArray

    external fun nativeStats(handle: Long): DoubleArray

    /** mode: 0 = learned heuristic, 1 = conventional baseline. Returns int[5 + n] (see SolveResult.decode). */
    external fun nativeSolve(
        handle: Long,
        mode: Int,
        state: ByteArray,
        maxExpansions: Int,
        lambda: Float,
        timeoutMs: Int
    ): IntArray

    /** Runs the held-out scrambles of one depth, returns double[6] (see EvalResult.decode). */
    external fun nativeEvaluate(
        handle: Long,
        mode: Int,
        depth: Int,
        cases: Int,
        maxExpansions: Int,
        lambda: Float,
        timeoutMs: Int
    ): DoubleArray

    /** The cancel flag is sticky: it stays set until it is cleared with cancel = false. */
    external fun nativeSetCancel(handle: Long, cancel: Boolean)

    external fun nativeSave(handle: Long, path: String): Boolean

    external fun nativeLoad(handle: Long, path: String): Boolean
}
