package com.rubikailab.app.ui

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Colours of the dark UI (kept in sync with res/values/colors.xml). */
object Theme {
    val BG = Color.rgb(10, 12, 17)
    val NAV = Color.rgb(14, 17, 23)
    val PANEL = Color.rgb(20, 24, 33)
    val PANEL_HI = Color.rgb(32, 39, 54)
    val ACCENT = Color.rgb(124, 156, 255)
    val ACCENT_DIM = Color.rgb(64, 86, 160)
    val TEXT = Color.rgb(232, 236, 245)
    val MUTED = Color.rgb(140, 150, 170)
    val GOOD = Color.rgb(96, 205, 138)
    val WARN = Color.rgb(240, 182, 72)
    val BAD = Color.rgb(238, 104, 104)
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun Context.rounded(fill: Int, radiusDp: Float): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(fill)
    d.cornerRadius = dpf(radiusDp)
    return d
}

fun Context.label(s: String, sizeSp: Float, textColor: Int, bold: Boolean): TextView {
    val tv = TextView(this)
    tv.text = s
    tv.textSize = sizeSp
    tv.setTextColor(textColor)
    if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
    return tv
}

fun Context.label(s: String): TextView = label(s, 14f, Theme.TEXT, false)

fun Context.heading(s: String): TextView = label(s, 16f, Theme.TEXT, true)

fun Context.muted(s: String): TextView = label(s, 13f, Theme.MUTED, false)

fun Context.button(text: String, primary: Boolean, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = text
    b.setAllCaps(false)
    b.textSize = 14f
    b.stateListAnimator = null
    b.minHeight = 0
    b.minimumHeight = 0
    b.minWidth = 0
    b.minimumWidth = 0
    val base = if (primary) Theme.ACCENT_DIM else Theme.PANEL_HI
    val pressed = if (primary) Theme.ACCENT else Color.rgb(52, 62, 86)
    val states = StateListDrawable()
    states.addState(intArrayOf(-android.R.attr.state_enabled), rounded(Theme.PANEL, 10f))
    states.addState(intArrayOf(android.R.attr.state_pressed), rounded(pressed, 10f))
    states.addState(intArrayOf(), rounded(base, 10f))
    b.background = states
    b.setTextColor(
        ColorStateList(
            arrayOf(intArrayOf(-android.R.attr.state_enabled), intArrayOf()),
            intArrayOf(Theme.MUTED, Theme.TEXT)
        )
    )
    b.setPadding(dp(12), dp(10), dp(12), dp(10))
    b.setOnClickListener { onClick() }
    return b
}

fun Context.card(): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.background = rounded(Theme.PANEL, 14f)
    c.setPadding(dp(14), dp(12), dp(14), dp(12))
    return c
}

fun lp(w: Int, h: Int, weight: Float): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

fun lp(w: Int, h: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)

/** Adds [child] to this vertical layout with a top margin in dp. */
fun LinearLayout.addTo(child: View, topDp: Int) {
    val p = LinearLayout.LayoutParams(MATCH, WRAP)
    p.topMargin = context.dp(topDp)
    addView(child, p)
}

/** A horizontal row of equally wide children. */
fun Context.row(vararg children: View): LinearLayout {
    val r = LinearLayout(this)
    r.orientation = LinearLayout.HORIZONTAL
    val gap = dp(3)
    for (c in children) {
        val p = LinearLayout.LayoutParams(0, WRAP, 1f)
        p.setMargins(gap, 0, gap, 0)
        r.addView(c, p)
    }
    return r
}

/** Base class of the three tabs: a vertical scrolling column. */
open class PageView(context: Context) : ScrollView(context) {
    val body = LinearLayout(context)

    init {
        setBackgroundColor(Theme.BG)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(context.dp(14), context.dp(14), context.dp(14), context.dp(24))
        addView(body, ViewGroup.LayoutParams(MATCH, WRAP))
    }

    /** The page became visible (or the app returned to the foreground with this page selected). */
    open fun onShow() {}

    /** The page was hidden (or the app left the foreground). */
    open fun onHide() {}
}

/** "title - [-] value [+]" selector over a fixed list of options. */
class OptionStepper(
    context: Context,
    title: String,
    private val options: List<String>,
    startIndex: Int,
    private val onChange: (Int) -> Unit
) : LinearLayout(context) {

    var index = startIndex.coerceIn(0, options.size - 1)
        private set

    private val valueView: TextView
    private val minus: Button
    private val plus: Button
    private var active = true

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        addView(context.label(title, 14f, Theme.MUTED, false), LayoutParams(0, WRAP, 1f))
        minus = context.button("-", false) { step(-1) }
        valueView = context.label(options[index], 15f, Theme.TEXT, true)
        valueView.gravity = Gravity.CENTER
        plus = context.button("+", false) { step(1) }
        addView(minus, LayoutParams(context.dp(44), context.dp(40)))
        addView(valueView, LayoutParams(context.dp(78), WRAP))
        addView(plus, LayoutParams(context.dp(44), context.dp(40)))
        refresh()
    }

    private fun step(delta: Int) {
        select(index + delta)
        onChange(index)
    }

    /** Moves the selection without calling the change listener. */
    fun select(i: Int) {
        index = i.coerceIn(0, options.size - 1)
        valueView.text = options[index]
        refresh()
    }

    fun setActive(on: Boolean) {
        active = on
        refresh()
    }

    private fun refresh() {
        minus.isEnabled = active && index > 0
        plus.isEnabled = active && index < options.size - 1
    }
}
