package com.rubikailab.app.gl

import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent

/**
 * GLSurfaceView hosting [CubeRenderer]. Dragging orbits the camera around the cube.
 * [onMoveDone] is delivered on the UI thread each time an animated turn has finished.
 */
class CubeView(context: Context, onMoveDone: (Int) -> Unit) : GLSurfaceView(context) {

    val renderer: CubeRenderer
    private var lastX = 0f
    private var lastY = 0f

    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        renderer = CubeRenderer({ requestRender() }, { move -> post { onMoveDone(move) } })
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    override fun onResume() {
        super.onResume()
        requestRender()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                renderer.rotate(event.x - lastX, event.y - lastY)
                lastX = event.x
                lastY = event.y
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
            }
        }
        return true
    }
}
