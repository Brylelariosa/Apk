package com.rubikailab.app.ui

import com.rubikailab.app.core.TrainStats
import java.util.Locale
import kotlin.math.abs

/** Number and text formatting shared by the pages. Always Locale.US so output never depends on the phone's locale. */
object Format {
    /** 1234567 -> "1,234,567". */
    fun count(n: Long): String = String.format(Locale.US, "%,d", n)

    fun count(n: Int): String = count(n.toLong())

    /** 950, 1.2k, 35k, 4.5M: short enough for one phone line. */
    fun compact(n: Long): String = when {
        n >= 1_000_000_000L -> scaled(n / 1.0e9, "B")
        n >= 1_000_000L -> scaled(n / 1.0e6, "M")
        n >= 1_000L -> scaled(n / 1.0e3, "k")
        else -> n.toString()
    }

    fun fixed(v: Double, decimals: Int): String = String.format(Locale.US, "%." + decimals + "f", v)

    /** 0.874 -> "87%". */
    fun percent(fraction: Double): String = String.format(Locale.US, "%.0f%%", fraction * 100.0)

    /** "untrained", or for example "12.3k steps, depth 7". */
    fun model(s: TrainStats): String =
        if (s.steps <= 0L) "untrained" else compact(s.steps) + " steps, depth " + s.depth

    private fun scaled(v: Double, suffix: String): String {
        val s = String.format(Locale.US, "%.1f", v)
        val trimmed = if (s.endsWith(".0")) s.substring(0, s.length - 2) else s
        return trimmed + suffix
    }
}

/** Index of the option closest to [value] (used to restore stepper positions from saved settings). */
fun nearestIndex(options: IntArray, value: Int): Int {
    var best = 0
    for (i in options.indices) {
        if (abs(options[i] - value) < abs(options[best] - value)) best = i
    }
    return best
}

fun nearestIndex(options: FloatArray, value: Float): Int {
    var best = 0
    for (i in options.indices) {
        if (abs(options[i] - value) < abs(options[best] - value)) best = i
    }
    return best
}
