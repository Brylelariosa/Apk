package com.rubikailab.app.ui

import android.content.Context
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import com.rubikailab.app.Lab
import com.rubikailab.app.core.Cube
import com.rubikailab.app.core.SolveResult
import com.rubikailab.app.core.SolveStatus
import com.rubikailab.app.core.SolverMode
import com.rubikailab.app.gl.CubeView
import java.util.Random

/**
 * Tab 1: the 3D cube. Turn it by hand, scramble it, and let the learned AI or the conventional
 * baseline solve it. Every returned solution is replayed on the Kotlin cube model before it is
 * animated, so a wrong answer can never be shown as a success.
 */
class CubePage(context: Context) : PageView(context) {

    private val rng = Random()
    private val cubeView: CubeView = CubeView(context) { onTurnFinished() }
    private val moveButtons = ArrayList<Button>()

    /** Cube state once every queued turn has finished; the renderer animates towards it. */
    private var state: ByteArray = Cube.solved()
    private var busy = false

    private val statusView: TextView
    private val modelView: TextView
    private val scrambleView: TextView
    private val resultView: TextView
    private val scrambleStepper: OptionStepper
    private val scrambleButton: Button
    private val resetButton: Button
    private val solveAiButton: Button
    private val solveBaseButton: Button
    private val stopButton: Button
    private val searchCard: SearchSettingsCard

    init {
        val frame = FrameLayout(context)
        frame.background = context.rounded(Theme.PANEL, 14f)
        frame.addView(cubeView, FrameLayout.LayoutParams(MATCH, MATCH))
        body.addView(frame, lp(MATCH, context.dp(300)))

        statusView = context.label("", 16f, Theme.TEXT, true)
        body.addTo(statusView, 12)
        modelView = context.muted("")
        body.addTo(modelView, 2)
        body.addTo(context.muted("Drag the cube to rotate the view."), 2)

        scrambleStepper = OptionStepper(context, "Scramble length", SCRAMBLE_LABELS, DEFAULT_SCRAMBLE_INDEX) { }
        body.addTo(scrambleStepper, 12)
        scrambleButton = context.button("Scramble", false) { scramble() }
        resetButton = context.button("Reset cube", false) { reset() }
        body.addTo(context.row(scrambleButton, resetButton), 8)
        scrambleView = context.muted("")
        body.addTo(scrambleView, 6)

        solveAiButton = context.button("Solve with the learned AI", true) { solve(SolverMode.LEARNED) }
        solveBaseButton = context.button("Solve with the baseline (no learning)", false) { solve(SolverMode.BASELINE) }
        stopButton = context.button("Stop search", false) { Lab.cancelJobs() }
        body.addTo(solveAiButton, 12)
        body.addTo(solveBaseButton, 8)
        body.addTo(stopButton, 8)

        val resultCard = context.card()
        resultCard.addView(context.heading("Result"))
        resultView = context.label(NO_SEARCH, 14f, Theme.TEXT, false)
        resultCard.addTo(resultView, 6)
        body.addTo(resultCard, 14)

        body.addTo(context.heading("Turn by hand"), 18)
        val upper = ArrayList<View>()
        val lower = ArrayList<View>()
        for (face in 0 until 6) {
            upper.add(moveButton(context, face * 2))
            lower.add(moveButton(context, face * 2 + 1))
        }
        body.addTo(context.row(*upper.toTypedArray()), 8)
        body.addTo(context.row(*lower.toTypedArray()), 6)

        searchCard = SearchSettingsCard(context)
        body.addTo(searchCard, 18)

        refreshControls()
        updateStatus()
    }

    override fun onShow() {
        cubeView.onResume()
        modelView.text = "Learned model: " + Format.model(Lab.latest)
        searchCard.refresh()
    }

    override fun onHide() {
        cubeView.onPause()
    }

    // ------------------------------------------------------------------ actions

    private fun moveButton(context: Context, move: Int): Button {
        val b = context.button(Cube.MOVE_NAMES[move], false) { turn(move) }
        moveButtons.add(b)
        return b
    }

    private fun turn(move: Int) {
        if (busy) return
        state = Cube.apply(state, move)
        cubeView.renderer.enqueue(move)
        scrambleView.text = ""
        updateStatus()
    }

    private fun scramble() {
        if (busy) return
        val moves = Cube.scramble(rng, SCRAMBLE_LENGTHS[scrambleStepper.index])
        val solved = Cube.solved()
        state = Cube.applyAll(solved, moves)
        cubeView.renderer.setState(solved)
        cubeView.renderer.enqueueAll(moves)
        scrambleView.text = "Scramble: " + Cube.format(moves)
        resultView.text = NO_SEARCH
        updateStatus()
    }

    private fun reset() {
        if (busy) return
        state = Cube.solved()
        cubeView.renderer.setState(state)
        scrambleView.text = ""
        resultView.text = NO_SEARCH
        updateStatus()
    }

    private fun solve(mode: Int) {
        if (busy) return
        if (!Lab.ready) {
            resultView.text = Lab.error ?: "The engine is not ready."
            return
        }
        if (Cube.isSolved(state)) {
            resultView.text = "The cube is already solved. Scramble it first."
            return
        }
        val start = state.copyOf()
        busy = true
        resultView.text = SolverMode.label(mode) + " is searching..."
        refreshControls()
        updateStatus()
        Lab.solveAsync(mode, start) { result -> onSolved(mode, start, result) }
    }

    private fun onSolved(mode: Int, start: ByteArray, result: SolveResult) {
        busy = false
        val sb = StringBuilder()
        sb.append(SolverMode.label(mode)).append(": ")
        val end = if (result.solved) Cube.applyAll(start, result.moves) else start
        if (result.solved && Cube.isSolved(end)) {
            sb.append("solved in ").append(result.moves.size).append(" quarter turns\n")
            sb.append(Cube.format(result.moves)).append('\n')
            state = end
            cubeView.renderer.enqueueAll(result.moves)
        } else if (result.solved) {
            sb.append("the returned moves do not solve this cube (internal error)\n")
        } else {
            sb.append(SolveStatus.label(result.status)).append('\n')
        }
        sb.append("Expanded ").append(Format.count(result.expanded))
        sb.append(" nodes, generated ").append(Format.count(result.generated))
        sb.append(", ").append(result.elapsedMs).append(" ms")
        resultView.text = sb.toString()
        refreshControls()
        updateStatus()
    }

    // ------------------------------------------------------------------ state shown on screen

    /** Called on the UI thread after every animated turn. */
    private fun onTurnFinished() {
        updateStatus()
    }

    private fun updateStatus() {
        statusView.text = when {
            busy -> "Searching..."
            cubeView.renderer.isAnimating() -> "Turning..."
            Cube.isSolved(state) -> "Cube is solved"
            else -> "Cube is scrambled"
        }
    }

    private fun refreshControls() {
        val idle = !busy
        scrambleButton.isEnabled = idle
        resetButton.isEnabled = idle
        solveAiButton.isEnabled = idle
        solveBaseButton.isEnabled = idle
        stopButton.isEnabled = busy
        for (b in moveButtons) b.isEnabled = idle
        scrambleStepper.setActive(idle)
        searchCard.setActive(idle)
    }

    private companion object {
        val SCRAMBLE_LENGTHS = intArrayOf(3, 5, 8, 10, 12, 15, 20, 25)
        val SCRAMBLE_LABELS = SCRAMBLE_LENGTHS.map { it.toString() }
        const val DEFAULT_SCRAMBLE_INDEX = 3
        const val NO_SEARCH = "No search yet."
    }
}
