#include "net.h"

#include <cmath>

namespace rubik {

void initParams(std::vector<float>& p, Rng& rng) {
  p.assign(static_cast<size_t>(kParamCount), 0.0f);
  const float s1 = 0.15f;  // 20 active rows are summed, so keep each row small
  for (int i = 0; i < kFeatures * kH1; ++i) p[static_cast<size_t>(kOffW1 + i)] = s1 * rng.gaussian();
  const float s2 = std::sqrt(2.0f / static_cast<float>(kH1));
  for (int i = 0; i < kH1 * kH2; ++i) p[static_cast<size_t>(kOffW2 + i)] = s2 * rng.gaussian();
  const float s3 = 0.02f;  // near-zero output at the start keeps the first targets sane
  for (int j = 0; j < kH2; ++j) p[static_cast<size_t>(kOffW3 + j)] = s3 * rng.gaussian();
}

float forward(const float* p, const int* feats, int nFeats, Activations& a) {
  const float* b1 = p + kOffB1;
  for (int i = 0; i < kH1; ++i) a.z1[i] = b1[i];
  for (int k = 0; k < nFeats; ++k) {
    const float* w = p + kOffW1 + static_cast<size_t>(feats[k]) * kH1;
    for (int i = 0; i < kH1; ++i) a.z1[i] += w[i];
  }
  for (int i = 0; i < kH1; ++i) a.a1[i] = a.z1[i] > 0.0f ? a.z1[i] : 0.0f;

  const float* b2 = p + kOffB2;
  for (int j = 0; j < kH2; ++j) a.z2[j] = b2[j];
  const float* w2 = p + kOffW2;
  for (int i = 0; i < kH1; ++i) {
    const float x = a.a1[i];
    if (x == 0.0f) continue;
    const float* row = w2 + i * kH2;
    for (int j = 0; j < kH2; ++j) a.z2[j] += x * row[j];
  }

  const float* w3 = p + kOffW3;
  float out = p[kOffB3];
  for (int j = 0; j < kH2; ++j) {
    const float v = a.z2[j] > 0.0f ? a.z2[j] : 0.0f;
    a.a2[j] = v;
    out += v * w3[j];
  }
  return out;
}

void backward(const float* p, float* g, const int* feats, int nFeats, const Activations& a, float dOut) {
  g[kOffB3] += dOut;

  const float* w3 = p + kOffW3;
  float* gw3 = g + kOffW3;
  float* gb2 = g + kOffB2;
  float dz2[kH2];
  for (int j = 0; j < kH2; ++j) {
    gw3[j] += dOut * a.a2[j];
    const float d = a.z2[j] > 0.0f ? dOut * w3[j] : 0.0f;
    dz2[j] = d;
    gb2[j] += d;
  }

  const float* w2 = p + kOffW2;
  float* gw2 = g + kOffW2;
  float* gb1 = g + kOffB1;
  float dz1[kH1];
  for (int i = 0; i < kH1; ++i) {
    if (a.z1[i] <= 0.0f) {
      dz1[i] = 0.0f;
      continue;
    }
    const float x = a.a1[i];
    const float* row = w2 + i * kH2;
    float* grow = gw2 + i * kH2;
    float acc = 0.0f;
    for (int j = 0; j < kH2; ++j) {
      acc += row[j] * dz2[j];
      grow[j] += x * dz2[j];
    }
    dz1[i] = acc;
    gb1[i] += acc;
  }

  for (int k = 0; k < nFeats; ++k) {
    float* gr = g + kOffW1 + static_cast<size_t>(feats[k]) * kH1;
    for (int i = 0; i < kH1; ++i) gr[i] += dz1[i];
  }
}

float estimateCost(const float* params, const uint8_t* state) {
  if (isSolved(state)) return 0.0f;
  int feats[kSlots];
  const int n = encodeFeatures(state, feats);
  if (n < 0) return 1.0e6f;
  Activations act;
  const float v = forward(params, feats, n, act) * kValueScale;
  return v > 0.0f ? v : 0.0f;
}

}  // namespace rubik
