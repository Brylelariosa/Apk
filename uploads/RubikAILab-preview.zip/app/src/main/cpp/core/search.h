#pragma once
// Weighted A* search over cube states, with pluggable heuristics.
//
//   f(n) = lambda * g(n) + h(n)
//
// lambda = 1 is classic A*, smaller values trade solution length for speed (lambda = 0 is greedy).

#include <atomic>
#include <cstdint>
#include <vector>

namespace rubik {

class Heuristic {
 public:
  virtual ~Heuristic() = default;
  virtual float estimate(const uint8_t* state) const = 0;
};

// Learned heuristic: the value network.
class NetHeuristic : public Heuristic {
 public:
  explicit NetHeuristic(const float* params) : params_(params) {}
  float estimate(const uint8_t* state) const override;

 private:
  const float* params_;
};

// Conventional baseline heuristic (no learning): a quarter turn changes at most 4 corners and 4 edges,
// so ceil(wrong corners / 4) and ceil(wrong edges / 4) are admissible lower bounds; use their maximum.
class MisplacedHeuristic : public Heuristic {
 public:
  float estimate(const uint8_t* state) const override;
};

enum SearchStatus {
  kSolved = 0,
  kNodeLimit = 1,
  kTimeout = 2,
  kCancelled = 3,
  kInvalid = 4,
};

struct SearchConfig {
  int maxExpansions = 20000;
  int maxNodes = 400000;
  float lambda = 0.6f;
  int timeoutMs = 20000;
};

struct SearchResult {
  int status = kInvalid;
  int expanded = 0;
  int generated = 0;
  int elapsedMs = 0;
  std::vector<uint8_t> moves;  // move indices, in the order they must be applied
};

SearchResult solveWeightedAStar(const uint8_t* start, const Heuristic& heuristic, const SearchConfig& cfg,
                                const std::atomic<bool>* cancel);

}  // namespace rubik
