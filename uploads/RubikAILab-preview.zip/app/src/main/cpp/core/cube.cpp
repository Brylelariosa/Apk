#include "cube.h"

#include <cstring>

namespace rubik {
namespace {

// Outward normal, "up" and "right" direction (as seen from outside) of each face: U R F D L B.
const int kNormalOf[6][3] = {{0, 1, 0}, {1, 0, 0}, {0, 0, 1}, {0, -1, 0}, {-1, 0, 0}, {0, 0, -1}};
const int kUpOf[6][3] = {{0, 0, -1}, {0, 1, 0}, {0, 1, 0}, {0, 0, 1}, {0, 1, 0}, {0, 1, 0}};
const int kRightOf[6][3] = {{1, 0, 0}, {0, 0, -1}, {1, 0, 0}, {1, 0, 0}, {0, 0, 1}, {-1, 0, 0}};

int featureIndex(int slot, int piece, int ori) {
  if (slot < kCornerSlots) return (slot * kCornerSlots + piece) * 3 + ori;
  return kCornerFeatures + ((slot - kCornerSlots) * kEdgeSlots + (piece - kCornerSlots)) * 2 + ori;
}

// Feature of every slot = (piece sitting in the slot, index of its reference colour among the
// slot's facelets). Works on any valid colouring without reasoning about handedness.
int encodeWith(const CubeTables& t, const uint8_t* s, int* out) {
  for (int slot = 0; slot < kSlots; ++slot) {
    const int n = t.slotSize[slot];
    int mask = 0;
    uint8_t c[3] = {0, 0, 0};
    for (int k = 0; k < n; ++k) {
      c[k] = s[t.slotFacelet[slot][k]];
      if (c[k] > 5) return -1;
      mask |= 1 << c[k];
    }
    const int piece = t.pieceOfMask[mask];
    if (piece < 0) return -1;
    if ((slot < kCornerSlots) != (piece < kCornerSlots)) return -1;
    const int ref = t.refColor[piece];
    int ori = 0;
    for (int k = 0; k < n; ++k) {
      if (c[k] == ref) ori = k;
    }
    out[slot] = featureIndex(slot, piece, ori);
  }
  return kSlots;
}

// Rotates v by 90 degrees about the outward normal n. Clockwise as seen from outside the face is a
// -90 degree rotation by the right-hand rule: v' = n (n.v) + sin(theta) (n x v), cos(theta) = 0.
void rotateAbout(const int* n, bool clockwise, const int* v, int* out) {
  const int dot = n[0] * v[0] + n[1] * v[1] + n[2] * v[2];
  const int cx = n[1] * v[2] - n[2] * v[1];
  const int cy = n[2] * v[0] - n[0] * v[2];
  const int cz = n[0] * v[1] - n[1] * v[0];
  const int sgn = clockwise ? -1 : 1;
  out[0] = n[0] * dot + sgn * cx;
  out[1] = n[1] * dot + sgn * cy;
  out[2] = n[2] * dot + sgn * cz;
}

CubeTables build() {
  CubeTables t;
  std::memset(&t, 0, sizeof(t));

  // 1. Facelet geometry.
  for (int f = 0; f < 6; ++f) {
    for (int r = 0; r < 3; ++r) {
      for (int c = 0; c < 3; ++c) {
        const int i = f * 9 + r * 3 + c;
        for (int k = 0; k < 3; ++k) {
          t.pos[i][k] = static_cast<int8_t>(kNormalOf[f][k] + (c - 1) * kRightOf[f][k] + (1 - r) * kUpOf[f][k]);
          t.normal[i][k] = static_cast<int8_t>(kNormalOf[f][k]);
        }
      }
    }
  }

  // 2. Move permutations: a sticker at facelet i travels to the facelet matching the rotated
  //    (position, normal) pair, so new[j] = old[i].
  for (int f = 0; f < 6; ++f) {
    for (int dir = 0; dir < 2; ++dir) {
      const int m = f * 2 + dir;
      const int* n = kNormalOf[f];
      for (int i = 0; i < kFacelets; ++i) t.perm[m][i] = static_cast<uint8_t>(i);
      for (int i = 0; i < kFacelets; ++i) {
        const int p[3] = {t.pos[i][0], t.pos[i][1], t.pos[i][2]};
        if (p[0] * n[0] + p[1] * n[1] + p[2] * n[2] != 1) continue;  // outside the turning layer
        const int q[3] = {t.normal[i][0], t.normal[i][1], t.normal[i][2]};
        int p2[3];
        int q2[3];
        rotateAbout(n, dir == 0, p, p2);
        rotateAbout(n, dir == 0, q, q2);
        for (int j = 0; j < kFacelets; ++j) {
          if (t.pos[j][0] == p2[0] && t.pos[j][1] == p2[1] && t.pos[j][2] == p2[2] &&
              t.normal[j][0] == q2[0] && t.normal[j][1] == q2[1] && t.normal[j][2] == q2[2]) {
            t.perm[m][j] = static_cast<uint8_t>(i);
            break;
          }
        }
      }
    }
  }

  // 3. Slots: 8 corners then 12 edges.
  int slotPos[kSlots][3];
  int count = 0;
  for (int x = -1; x <= 1; x += 2) {
    for (int y = -1; y <= 1; y += 2) {
      for (int z = -1; z <= 1; z += 2) {
        slotPos[count][0] = x;
        slotPos[count][1] = y;
        slotPos[count][2] = z;
        ++count;
      }
    }
  }
  for (int x = -1; x <= 1; ++x) {
    for (int y = -1; y <= 1; ++y) {
      for (int z = -1; z <= 1; ++z) {
        const int zeros = (x == 0 ? 1 : 0) + (y == 0 ? 1 : 0) + (z == 0 ? 1 : 0);
        if (zeros != 1) continue;
        slotPos[count][0] = x;
        slotPos[count][1] = y;
        slotPos[count][2] = z;
        ++count;
      }
    }
  }

  std::memset(t.pieceOfMask, 0xFF, sizeof(t.pieceOfMask));
  for (int s = 0; s < kSlots; ++s) {
    int found = 0;
    int mask = 0;
    for (int i = 0; i < kFacelets; ++i) {
      if (t.pos[i][0] == slotPos[s][0] && t.pos[i][1] == slotPos[s][1] && t.pos[i][2] == slotPos[s][2]) {
        t.slotFacelet[s][found++] = static_cast<uint8_t>(i);
        mask |= 1 << (i / 9);
      }
    }
    t.slotSize[s] = static_cast<uint8_t>(found);
    t.pieceOfMask[mask] = static_cast<int8_t>(s);
    int ref = 0;
    while (((mask >> ref) & 1) == 0) ++ref;
    t.refColor[s] = static_cast<uint8_t>(ref);
  }

  // 4. Features of the solved cube.
  uint8_t solved[kFacelets];
  for (int i = 0; i < kFacelets; ++i) solved[i] = static_cast<uint8_t>(i / 9);
  int feats[kSlots];
  encodeWith(t, solved, feats);
  for (int s = 0; s < kSlots; ++s) t.solvedFeature[s] = static_cast<int16_t>(feats[s]);
  return t;
}

}  // namespace

const CubeTables& cubeTables() {
  static const CubeTables tables = build();
  return tables;
}

void setSolved(uint8_t* s) {
  for (int i = 0; i < kFacelets; ++i) s[i] = static_cast<uint8_t>(i / 9);
}

bool isSolved(const uint8_t* s) {
  for (int f = 0; f < 6; ++f) {
    const uint8_t c = static_cast<uint8_t>(f);
    for (int k = 0; k < 9; ++k) {
      if (s[f * 9 + k] != c) return false;
    }
  }
  return true;
}

void applyMove(const uint8_t* src, uint8_t* dst, int move) {
  const uint8_t* p = cubeTables().perm[move];
  for (int i = 0; i < kFacelets; ++i) dst[i] = src[p[i]];
}

uint64_t hashState(const uint8_t* s) {
  uint64_t h = 1469598103934665603ULL;
  for (int i = 0; i < kFacelets; ++i) {
    h ^= s[i];
    h *= 1099511628211ULL;
  }
  h ^= h >> 29;
  return h;
}

int encodeFeatures(const uint8_t* s, int* out) { return encodeWith(cubeTables(), s, out); }

int countMisplaced(const uint8_t* s, int* corners, int* edges) {
  const CubeTables& t = cubeTables();
  int feats[kSlots];
  if (encodeWith(t, s, feats) < 0) return -1;
  int c = 0;
  int e = 0;
  for (int slot = 0; slot < kSlots; ++slot) {
    if (feats[slot] != t.solvedFeature[slot]) {
      if (slot < kCornerSlots) {
        ++c;
      } else {
        ++e;
      }
    }
  }
  *corners = c;
  *edges = e;
  return c + e;
}

}  // namespace rubik
