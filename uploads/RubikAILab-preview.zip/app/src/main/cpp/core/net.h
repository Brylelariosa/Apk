#pragma once
// Value network: sparse piece-position features -> 192 -> 96 -> 1 (ReLU).
//
// Input: for each of the 20 cubie slots exactly one feature is active ("piece P sits in slot S with
// orientation O"), so the first layer is the sum of 20 weight rows (the same trick used by NNUE).
// The output is the estimated number of quarter turns to the solved cube divided by kValueScale.
// All parameters live in one flat float array so copying, Adam updates and checkpoints are trivial.

#include <cstdint>
#include <vector>

#include "cube.h"
#include "rng.h"

namespace rubik {

constexpr int kH1 = 192;
constexpr int kH2 = 96;

constexpr int kOffW1 = 0;                          // [kFeatures][kH1]
constexpr int kOffB1 = kOffW1 + kFeatures * kH1;   // [kH1]
constexpr int kOffW2 = kOffB1 + kH1;               // [kH1][kH2]
constexpr int kOffB2 = kOffW2 + kH1 * kH2;         // [kH2]
constexpr int kOffW3 = kOffB2 + kH2;               // [kH2]
constexpr int kOffB3 = kOffW3 + kH2;               // [1]
constexpr int kParamCount = kOffB3 + 1;

constexpr float kValueScale = 10.0f;

struct Activations {
  float z1[kH1];
  float a1[kH1];
  float z2[kH2];
  float a2[kH2];
};

void initParams(std::vector<float>& params, Rng& rng);

// Returns the raw network output (before kValueScale).
float forward(const float* params, const int* feats, int nFeats, Activations& act);

// Accumulates d(loss)/d(params) into grad given d(loss)/d(raw output).
void backward(const float* params, float* grad, const int* feats, int nFeats, const Activations& act, float dOut);

// Estimated cost-to-go in quarter turns (never negative, exactly 0 for the solved cube).
float estimateCost(const float* params, const uint8_t* state);

}  // namespace rubik
