#include "trainer.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <thread>

namespace rubik {
namespace {

// Runs fn(0..threads-1), the first index on the calling thread.
template <typename F>
void parallelFor(int threads, F&& fn) {
  if (threads <= 1) {
    fn(0);
    return;
  }
  std::vector<std::thread> pool;
  pool.reserve(static_cast<size_t>(threads - 1));
  for (int t = 1; t < threads; ++t) pool.emplace_back([&fn, t]() { fn(t); });
  fn(0);
  for (std::thread& th : pool) th.join();
}

const char kMagic[4] = {'R', 'A', 'I', 'L'};
const char kEnd[4] = {'E', 'N', 'D', '!'};
const uint32_t kVersion = 2;  // 2: adds the RNG state after the moving averages

template <typename T>
bool writeVal(std::FILE* f, const T& v) {
  return std::fwrite(&v, sizeof(T), 1, f) == 1;
}

template <typename T>
bool readVal(std::FILE* f, T& v) {
  return std::fread(&v, sizeof(T), 1, f) == 1;
}

bool writeVec(std::FILE* f, const std::vector<float>& v) {
  return std::fwrite(v.data(), sizeof(float), v.size(), f) == v.size();
}

bool readVec(std::FILE* f, std::vector<float>& v) {
  v.assign(static_cast<size_t>(kParamCount), 0.0f);
  return std::fread(v.data(), sizeof(float), v.size(), f) == v.size();
}

bool allFinite(const std::vector<float>& v) {
  for (float x : v) {
    if (!std::isfinite(x)) return false;
  }
  return true;
}

}  // namespace

void randomScramble(Rng& rng, int depth, uint8_t* out) {
  setSolved(out);
  uint8_t tmp[kFacelets];
  int prev = -1;
  int prev2 = -1;
  for (int d = 0; d < depth; ++d) {
    int m = 0;
    do {
      m = static_cast<int>(rng.below(static_cast<uint32_t>(kMoves)));
    } while (prev >= 0 && (m == (prev ^ 1) || (m == prev && prev2 == prev)));
    applyMove(out, tmp, m);
    std::memcpy(out, tmp, kFacelets);
    prev2 = prev;
    prev = m;
  }
}

TestSet::TestSet() {
  states_.assign(static_cast<size_t>(kMaxDepth) * kPerDepth * kFacelets, 0);
  for (int d = 1; d <= kMaxDepth; ++d) {
    for (int i = 0; i < kPerDepth; ++i) {
      uint8_t* dst = &states_[(static_cast<size_t>(d - 1) * kPerDepth + static_cast<size_t>(i)) * kFacelets];
      Rng rng(0x7E575EEDULL + static_cast<uint64_t>(d) * 1000003ULL + static_cast<uint64_t>(i) * 7919ULL);
      for (int attempt = 0; attempt < 16; ++attempt) {
        randomScramble(rng, d, dst);
        if (!isSolved(dst)) break;
      }
      if (d >= kMinExcludedDepth) heldOut_.insert(hashState(dst));
    }
  }
}

const uint8_t* TestSet::state(int depth, int index) const {
  const int d = std::min(std::max(depth, 1), kMaxDepth);
  const int i = std::min(std::max(index, 0), kPerDepth - 1);
  return &states_[(static_cast<size_t>(d - 1) * kPerDepth + static_cast<size_t>(i)) * kFacelets];
}

Trainer::Trainer(const TestSet* tests) : tests_(tests) { reset(1); }

void Trainer::reset(uint64_t seed) {
  rng_.reseed(seed);
  initParams(net_, rng_);
  target_ = net_;
  m_.assign(static_cast<size_t>(kParamCount), 0.0f);
  v_.assign(static_cast<size_t>(kParamCount), 0.0f);
  steps_ = 0;
  samples_ = 0;
  adamT_ = 0;
  iterations_ = 0;
  stepsSinceSync_ = 0;
  depth_ = std::min(cfg_.startDepth, cfg_.maxDepth);
  emaLoss_ = 0.0f;
  emaMae_ = 0.0f;
  emaAcc_ = 0.0f;
  samplesPerSec_ = 0.0f;
  chunkSteps_ = 0;
}

void Trainer::setConfig(const TrainConfig& cfg) {
  cfg_ = cfg;
  cfg_.batch = std::min(std::max(cfg_.batch, 32), 2048);
  cfg_.lr = std::min(std::max(cfg_.lr, 1.0e-5f), 1.0e-1f);
  cfg_.maxDepth = std::min(std::max(cfg_.maxDepth, 2), TestSet::kMaxDepth);
  cfg_.threads = std::min(std::max(cfg_.threads, 1), 8);
  cfg_.startDepth = std::min(std::max(cfg_.startDepth, 1), cfg_.maxDepth);
  depth_ = std::min(std::max(depth_, 1), cfg_.maxDepth);
}

void Trainer::sampleState(Rng& rng, int maxDepth, uint8_t* out) const {
  for (int attempt = 0; attempt < 8; ++attempt) {
    const int depth = static_cast<int>(rng.below(static_cast<uint32_t>(maxDepth + 1)));
    randomScramble(rng, depth, out);
    if (!tests_->isHeldOut(hashState(out))) return;  // held-out states never reach training, at any depth
  }
  setSolved(out);  // practically unreachable; keeps the held-out guarantee strict
}

void Trainer::adamUpdate(const float* g) {
  ++adamT_;
  const float b1 = 0.9f;
  const float b2 = 0.999f;
  const float eps = 1.0e-8f;
  const float c1 = 1.0f - std::pow(b1, static_cast<float>(adamT_));
  const float c2 = 1.0f - std::pow(b2, static_cast<float>(adamT_));
  const float lrT = cfg_.lr * std::sqrt(c2) / c1;
  float* p = net_.data();
  float* m = m_.data();
  float* v = v_.data();
  for (int i = 0; i < kParamCount; ++i) {
    const float gi = g[i];
    m[i] = b1 * m[i] + (1.0f - b1) * gi;
    v[i] = b2 * v[i] + (1.0f - b2) * gi * gi;
    p[i] -= lrT * m[i] / (std::sqrt(v[i]) + eps);
  }
}

void Trainer::step() {
  const int batch = cfg_.batch;
  const int threads = std::min(std::max(cfg_.threads, 1), 8);
  if (static_cast<int>(workers_.size()) < threads) workers_.resize(static_cast<size_t>(threads));

  const uint64_t base = rng_.next();
  for (int t = 0; t < threads; ++t) {
    Worker& w = workers_[static_cast<size_t>(t)];
    if (static_cast<int>(w.grad.size()) != kParamCount) {
      w.grad.assign(static_cast<size_t>(kParamCount), 0.0f);
    } else {
      std::fill(w.grad.begin(), w.grad.end(), 0.0f);
    }
    w.rng.reseed(base + 0x9E37ULL * static_cast<uint64_t>(t + 1));
    w.lossSum = 0.0;
    w.absSum = 0.0;
    w.hits = 0;
    w.count = 0;
  }

  const float* net = net_.data();
  const float* target = target_.data();
  const int depthLimit = depth_;
  const float invBatch = 1.0f / static_cast<float>(batch);
  const float delta = 2.0f;  // Huber threshold in quarter turns

  parallelFor(threads, [&](int t) {
    Worker& w = workers_[static_cast<size_t>(t)];
    const int b0 = static_cast<int>(static_cast<int64_t>(batch) * t / threads);
    const int b1 = static_cast<int>(static_cast<int64_t>(batch) * (t + 1) / threads);
    Activations act;
    uint8_t s[kFacelets];
    uint8_t c[kFacelets];
    int feats[kSlots];
    for (int b = b0; b < b1; ++b) {
      sampleState(w.rng, depthLimit, s);
      float tgt = 0.0f;
      if (!isSolved(s)) {
        float best = 1.0e9f;
        for (int m = 0; m < kMoves; ++m) {
          applyMove(s, c, m);
          const float v = isSolved(c) ? 0.0f : estimateCost(target, c);
          if (v < best) best = v;
        }
        tgt = 1.0f + best;
      }
      const int nf = encodeFeatures(s, feats);
      if (nf < 0) continue;
      const float out = forward(net, feats, nf, act);
      const float err = out * kValueScale - tgt;
      const float aerr = std::fabs(err);
      w.absSum += aerr;
      w.lossSum += aerr <= delta ? 0.5 * err * err : delta * (aerr - 0.5 * delta);
      if (aerr < 0.5f) ++w.hits;
      ++w.count;
      const float clipped = err > delta ? delta : (err < -delta ? -delta : err);
      backward(net, w.grad.data(), feats, nf, act, clipped * kValueScale * invBatch);
    }
  });

  std::vector<float>& g = workers_[0].grad;
  for (int t = 1; t < threads; ++t) {
    const std::vector<float>& o = workers_[static_cast<size_t>(t)].grad;
    for (int i = 0; i < kParamCount; ++i) g[static_cast<size_t>(i)] += o[static_cast<size_t>(i)];
  }
  double sq = 0.0;
  for (float x : g) sq += static_cast<double>(x) * static_cast<double>(x);
  const float norm = static_cast<float>(std::sqrt(sq));
  const float clipNorm = 20.0f;
  if (std::isfinite(norm)) {
    if (norm > clipNorm) {
      const float scale = clipNorm / norm;
      for (float& x : g) x *= scale;
    }
    adamUpdate(g.data());
  }

  double loss = 0.0;
  double absErr = 0.0;
  int hits = 0;
  int count = 0;
  for (int t = 0; t < threads; ++t) {
    const Worker& w = workers_[static_cast<size_t>(t)];
    loss += w.lossSum;
    absErr += w.absSum;
    hits += w.hits;
    count += w.count;
  }
  if (count > 0) {
    const float bl = static_cast<float>(loss / count);
    const float bm = static_cast<float>(absErr / count);
    const float ba = static_cast<float>(hits) / static_cast<float>(count);
    const float a = steps_ == 0 ? 1.0f : 0.1f;
    emaLoss_ += a * (bl - emaLoss_);
    emaMae_ += a * (bm - emaMae_);
    emaAcc_ += (stepsSinceSync_ == 0 ? 1.0f : 0.1f) * (ba - emaAcc_);
  }

  ++steps_;
  samples_ += batch;
  ++stepsSinceSync_;

  if (stepsSinceSync_ >= cfg_.minSync && (emaAcc_ >= cfg_.accThreshold || stepsSinceSync_ >= cfg_.maxSync)) {
    const bool learned = emaAcc_ >= cfg_.accThreshold;
    target_ = net_;
    ++iterations_;
    stepsSinceSync_ = 0;
    if (learned && depth_ < cfg_.maxDepth) ++depth_;
  }
}

TrainStats Trainer::run(int budgetMs) {
  const auto t0 = std::chrono::steady_clock::now();
  const int64_t startSamples = samples_;
  chunkSteps_ = 0;
  for (;;) {
    step();
    ++chunkSteps_;
    const auto now = std::chrono::steady_clock::now();
    if (std::chrono::duration_cast<std::chrono::milliseconds>(now - t0).count() >= budgetMs) break;
  }
  const double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  samplesPerSec_ = sec > 0.0 ? static_cast<float>(static_cast<double>(samples_ - startSamples) / sec) : 0.0f;
  return stats();
}

TrainStats Trainer::stats() const {
  TrainStats s;
  s.steps = steps_;
  s.samples = samples_;
  s.iterations = iterations_;
  s.depth = depth_;
  s.loss = emaLoss_;
  s.mae = emaMae_;
  s.accuracy = emaAcc_;
  s.samplesPerSec = samplesPerSec_;
  s.lr = cfg_.lr;
  s.stepsSinceSync = stepsSinceSync_;
  s.chunkSteps = chunkSteps_;
  s.threads = cfg_.threads;
  return s;
}

bool Trainer::save(std::FILE* f) const {
  const uint32_t dims[4] = {static_cast<uint32_t>(kFeatures), static_cast<uint32_t>(kH1),
                            static_cast<uint32_t>(kH2), static_cast<uint32_t>(kParamCount)};
  bool ok = std::fwrite(kMagic, 1, 4, f) == 4;
  ok = ok && writeVal(f, kVersion);
  ok = ok && std::fwrite(dims, sizeof(uint32_t), 4, f) == 4;
  ok = ok && writeVal(f, steps_) && writeVal(f, samples_) && writeVal(f, adamT_);
  ok = ok && writeVal(f, iterations_) && writeVal(f, depth_) && writeVal(f, stepsSinceSync_);
  ok = ok && writeVal(f, emaLoss_) && writeVal(f, emaMae_) && writeVal(f, emaAcc_);
  const uint64_t rngState = rng_.state();
  ok = ok && writeVal(f, rngState);
  ok = ok && writeVec(f, net_) && writeVec(f, target_) && writeVec(f, m_) && writeVec(f, v_);
  ok = ok && std::fwrite(kEnd, 1, 4, f) == 4;
  return ok;
}

bool Trainer::load(std::FILE* f) {
  char magic[4] = {0, 0, 0, 0};
  uint32_t version = 0;
  uint32_t dims[4] = {0, 0, 0, 0};
  if (std::fread(magic, 1, 4, f) != 4 || std::memcmp(magic, kMagic, 4) != 0) return false;
  if (!readVal(f, version) || version != kVersion) return false;
  if (std::fread(dims, sizeof(uint32_t), 4, f) != 4) return false;
  if (dims[0] != static_cast<uint32_t>(kFeatures) || dims[1] != static_cast<uint32_t>(kH1) ||
      dims[2] != static_cast<uint32_t>(kH2) || dims[3] != static_cast<uint32_t>(kParamCount)) {
    return false;
  }

  int64_t steps = 0;
  int64_t samples = 0;
  int64_t adamT = 0;
  int iterations = 0;
  int depth = 0;
  int since = 0;
  float emaLoss = 0.0f;
  float emaMae = 0.0f;
  float emaAcc = 0.0f;
  uint64_t rngState = 0;
  std::vector<float> net;
  std::vector<float> target;
  std::vector<float> m;
  std::vector<float> v;
  bool ok = readVal(f, steps) && readVal(f, samples) && readVal(f, adamT);
  ok = ok && readVal(f, iterations) && readVal(f, depth) && readVal(f, since);
  ok = ok && readVal(f, emaLoss) && readVal(f, emaMae) && readVal(f, emaAcc);
  ok = ok && readVal(f, rngState);
  ok = ok && readVec(f, net) && readVec(f, target) && readVec(f, m) && readVec(f, v);
  char end[4] = {0, 0, 0, 0};
  ok = ok && std::fread(end, 1, 4, f) == 4 && std::memcmp(end, kEnd, 4) == 0;
  if (!ok) return false;
  if (!allFinite(net) || !allFinite(target) || !allFinite(m) || !allFinite(v)) return false;
  if (steps < 0 || samples < 0 || adamT < 0 || iterations < 0 || depth < 1 || since < 0) return false;

  net_.swap(net);
  target_.swap(target);
  m_.swap(m);
  v_.swap(v);
  steps_ = steps;
  samples_ = samples;
  adamT_ = adamT;
  iterations_ = iterations;
  depth_ = std::min(std::max(depth, 1), cfg_.maxDepth);
  stepsSinceSync_ = since;
  emaLoss_ = emaLoss;
  emaMae_ = emaMae;
  emaAcc_ = emaAcc;
  rng_.setState(rngState);
  samplesPerSec_ = 0.0f;
  chunkSteps_ = 0;
  return true;
}

}  // namespace rubik
