#pragma once
// Engine = trainer + held-out test scrambles + inference snapshot + search.
//
// Threading: train/save/load/reset/configure are serialised by one mutex. solve/evaluate never touch
// the trainable network; they read an immutable snapshot that the trainer republishes after every
// training chunk, so searching while training is safe and lock-free on the hot path.

#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <vector>

#include "search.h"
#include "trainer.h"

namespace rubik {

enum SolverMode {
  kLearnedMode = 0,
  kBaselineMode = 1,
};

struct EvalResult {
  int solved = 0;
  int total = 0;
  double avgLength = 0.0;    // over solved cases
  double avgExpanded = 0.0;  // over solved cases
  double avgMs = 0.0;        // over solved cases
  bool cancelled = false;
};

class Engine {
 public:
  explicit Engine(uint64_t seed);

  void reset(uint64_t seed);
  void configure(const TrainConfig& cfg);
  TrainStats train(int budgetMs);
  TrainStats stats();

  SearchResult solve(int mode, const uint8_t* state, const SearchConfig& cfg);
  EvalResult evaluate(int mode, int depth, int cases, const SearchConfig& cfg);
  void setCancel(bool cancel) { cancel_.store(cancel); }

  bool save(const char* path);
  bool load(const char* path);

 private:
  using Snapshot = std::shared_ptr<const std::vector<float>>;

  void publish();
  Snapshot snapshot();

  TestSet tests_;
  Trainer trainer_;
  std::mutex trainMutex_;
  std::mutex snapMutex_;
  Snapshot snapshot_;
  std::atomic<bool> cancel_{false};
};

}  // namespace rubik
