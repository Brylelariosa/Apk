#include "engine.h"

#include <algorithm>
#include <cstdio>
#include <string>

namespace rubik {

Engine::Engine(uint64_t seed) : trainer_(&tests_) {
  trainer_.reset(seed);
  publish();
}

void Engine::publish() {
  std::shared_ptr<std::vector<float>> copy = std::make_shared<std::vector<float>>(trainer_.params());
  const Snapshot frozen = copy;
  std::lock_guard<std::mutex> lock(snapMutex_);
  snapshot_ = frozen;
}

Engine::Snapshot Engine::snapshot() {
  std::lock_guard<std::mutex> lock(snapMutex_);
  return snapshot_;
}

void Engine::reset(uint64_t seed) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  trainer_.reset(seed);
  publish();
}

void Engine::configure(const TrainConfig& cfg) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  trainer_.setConfig(cfg);
}

TrainStats Engine::train(int budgetMs) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  const TrainStats s = trainer_.run(budgetMs);
  publish();
  return s;
}

TrainStats Engine::stats() {
  std::lock_guard<std::mutex> lock(trainMutex_);
  return trainer_.stats();
}

SearchResult Engine::solve(int mode, const uint8_t* state, const SearchConfig& cfgIn) {
  SearchConfig cfg = cfgIn;
  if (mode == kBaselineMode) {
    // Classic A* with an admissible heuristic: this is the conventional, non-learning reference.
    cfg.lambda = 1.0f;
    MisplacedHeuristic heuristic;
    return solveWeightedAStar(state, heuristic, cfg, &cancel_);
  }
  const Snapshot snap = snapshot();
  NetHeuristic heuristic(snap->data());
  return solveWeightedAStar(state, heuristic, cfg, &cancel_);
}

EvalResult Engine::evaluate(int mode, int depth, int cases, const SearchConfig& cfg) {
  EvalResult result;
  const int d = std::min(std::max(depth, 1), TestSet::kMaxDepth);
  const int n = std::min(std::max(cases, 1), TestSet::kPerDepth);
  double sumLen = 0.0;
  double sumExpanded = 0.0;
  double sumMs = 0.0;
  for (int i = 0; i < n; ++i) {
    if (cancel_.load()) {
      result.cancelled = true;
      break;
    }
    const SearchResult r = solve(mode, tests_.state(d, i), cfg);
    if (r.status == kCancelled) {
      result.cancelled = true;
      break;
    }
    ++result.total;
    if (r.status == kSolved) {
      ++result.solved;
      sumLen += static_cast<double>(r.moves.size());
      sumExpanded += static_cast<double>(r.expanded);
      sumMs += static_cast<double>(r.elapsedMs);
    }
  }
  if (result.solved > 0) {
    result.avgLength = sumLen / result.solved;
    result.avgExpanded = sumExpanded / result.solved;
    result.avgMs = sumMs / result.solved;
  }
  return result;
}

bool Engine::save(const char* path) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  const std::string tmp = std::string(path) + ".tmp";
  std::FILE* f = std::fopen(tmp.c_str(), "wb");
  if (f == nullptr) return false;
  bool ok = trainer_.save(f);
  ok = (std::fflush(f) == 0) && ok;
  ok = (std::fclose(f) == 0) && ok;
  if (!ok) {
    std::remove(tmp.c_str());
    return false;
  }
  if (std::rename(tmp.c_str(), path) != 0) {
    std::remove(tmp.c_str());
    return false;
  }
  return true;
}

bool Engine::load(const char* path) {
  std::lock_guard<std::mutex> lock(trainMutex_);
  std::FILE* f = std::fopen(path, "rb");
  if (f == nullptr) return false;
  const bool ok = trainer_.load(f);
  std::fclose(f);
  if (ok) publish();
  return ok;
}

}  // namespace rubik
