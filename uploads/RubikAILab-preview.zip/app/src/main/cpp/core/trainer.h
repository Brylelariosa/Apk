#pragma once
// Approximate value iteration trainer (DeepCubeA style, scaled down for a phone).
//
//   target(s) = 0                         if s is solved
//             = 1 + min_m J_target(m(s))  otherwise
//
// J is the value network. The target network is a lagging copy of the network that is refreshed once
// the main network fits its targets (or after a step limit). The scramble depth range of the training
// states grows as the network learns (curriculum). Nothing here consults a solver: the only supervision
// comes from the cube dynamics and the lagging network itself.

#include <cstdint>
#include <cstdio>
#include <unordered_set>
#include <vector>

#include "cube.h"
#include "net.h"
#include "rng.h"

namespace rubik {

// Random walk scramble (never undoes the previous move, never turns the same face three times in a row).
void randomScramble(Rng& rng, int depth, uint8_t* out);

// Fixed, reproducible test scrambles (depth 1..kMaxDepth, kPerDepth each). Every test state with a scramble
// length of at least kMinExcludedDepth is excluded from the training distribution, whichever scramble depth
// would have produced it. Shallower test states are not excluded: the whole state space at those depths is
// tiny (10011 states at 4 quarter turns), so they only check that the model has not forgotten the basics.
class TestSet {
 public:
  static constexpr int kMaxDepth = 20;
  static constexpr int kPerDepth = 50;
  static constexpr int kMinExcludedDepth = 5;

  TestSet();
  const uint8_t* state(int depth, int index) const;
  bool isHeldOut(uint64_t hash) const { return heldOut_.count(hash) != 0; }

 private:
  std::vector<uint8_t> states_;
  std::unordered_set<uint64_t> heldOut_;
};

struct TrainConfig {
  int batch = 256;
  float lr = 1.0e-3f;
  int maxDepth = 12;
  int threads = 2;
  int startDepth = 3;
  int minSync = 60;     // minimum steps between target network refreshes
  int maxSync = 500;    // refresh anyway after this many steps
  float accThreshold = 0.85f;  // fraction of samples within 0.5 moves of their target
};

struct TrainStats {
  int64_t steps = 0;
  int64_t samples = 0;
  int iterations = 0;
  int depth = 3;
  float loss = 0.0f;
  float mae = 0.0f;
  float accuracy = 0.0f;
  float samplesPerSec = 0.0f;
  float lr = 0.0f;
  int stepsSinceSync = 0;
  int chunkSteps = 0;
  int threads = 1;
};

class Trainer {
 public:
  explicit Trainer(const TestSet* tests);

  void reset(uint64_t seed);
  void setConfig(const TrainConfig& cfg);

  // Trains until the time budget is spent (at least one step).
  TrainStats run(int budgetMs);
  TrainStats stats() const;

  const std::vector<float>& params() const { return net_; }

  bool save(std::FILE* f) const;
  bool load(std::FILE* f);

 private:
  struct Worker {
    std::vector<float> grad;
    Rng rng;
    double lossSum = 0.0;
    double absSum = 0.0;
    int hits = 0;
    int count = 0;
  };

  void step();
  void sampleState(Rng& rng, int maxDepth, uint8_t* out) const;
  void adamUpdate(const float* grad);

  const TestSet* tests_;
  TrainConfig cfg_;
  Rng rng_;
  std::vector<float> net_;
  std::vector<float> target_;
  std::vector<float> m_;
  std::vector<float> v_;
  std::vector<Worker> workers_;

  int64_t steps_ = 0;
  int64_t samples_ = 0;
  int64_t adamT_ = 0;
  int iterations_ = 0;
  int depth_ = 3;
  int stepsSinceSync_ = 0;
  float emaLoss_ = 0.0f;
  float emaMae_ = 0.0f;
  float emaAcc_ = 0.0f;
  float samplesPerSec_ = 0.0f;
  int chunkSteps_ = 0;
};

}  // namespace rubik
