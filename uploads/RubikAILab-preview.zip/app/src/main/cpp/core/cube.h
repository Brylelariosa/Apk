#pragma once
// Cube model: 54 facelets, quarter-turn metric (12 moves).
//
// Facelet order: faces U R F D L B, nine facelets each, row-major as seen from outside the face
// (Kociemba layout). A state is one byte per facelet holding its colour, which equals the id of the
// face the colour belongs to in the solved cube.
//
// Move index = face * 2 + direction (0 = clockwise, 1 = counter-clockwise, seen from outside).
// All permutation tables are generated from the 3D geometry of the facelets, and the renderer uses
// the very same geometry, so simulation and drawing cannot disagree.

#include <cstdint>

namespace rubik {

constexpr int kFacelets = 54;
constexpr int kMoves = 12;
constexpr int kCornerSlots = 8;
constexpr int kEdgeSlots = 12;
constexpr int kSlots = kCornerSlots + kEdgeSlots;
constexpr int kCornerFeatures = kCornerSlots * kCornerSlots * 3;  // 192
constexpr int kEdgeFeatures = kEdgeSlots * kEdgeSlots * 2;        // 288
constexpr int kFeatures = kCornerFeatures + kEdgeFeatures;        // 480

struct CubeTables {
  int8_t pos[kFacelets][3];         // cubie coordinates of each facelet, every value in {-1, 0, 1}
  int8_t normal[kFacelets][3];      // outward facelet normal
  uint8_t perm[kMoves][kFacelets];  // after a move: new[i] = old[perm[move][i]]
  uint8_t slotSize[kSlots];         // facelets per slot: 3 (corner) or 2 (edge)
  uint8_t slotFacelet[kSlots][3];   // facelet indices of each slot, ascending
  int8_t pieceOfMask[64];           // colour-set bit mask -> piece id, -1 when no such piece exists
  uint8_t refColor[kSlots];         // reference colour (lowest face id) of each piece
  int16_t solvedFeature[kSlots];    // feature index of each slot in the solved cube
};

const CubeTables& cubeTables();

void setSolved(uint8_t* state);
bool isSolved(const uint8_t* state);
void applyMove(const uint8_t* src, uint8_t* dst, int move);  // src and dst must not alias
uint64_t hashState(const uint8_t* state);

// Writes one active feature index per slot (kSlots values).
// Returns kSlots, or -1 when the state is not a valid cube colouring.
int encodeFeatures(const uint8_t* state, int* out);

// Counts pieces that are not at their solved position and orientation.
// Returns the total, or -1 for an invalid state.
int countMisplaced(const uint8_t* state, int* corners, int* edges);

}  // namespace rubik
