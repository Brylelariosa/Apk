#include "search.h"

#include <chrono>
#include <cstring>
#include <queue>
#include <unordered_map>

#include "cube.h"
#include "net.h"

namespace rubik {
namespace {

struct Node {
  uint8_t s[kFacelets];
  int8_t move;
  int16_t g;
  int32_t parent;
  uint64_t hash;
};

struct Item {
  float f;
  int32_t idx;
};

// std::priority_queue pops the "largest" element, so order by descending f; ties prefer newer nodes.
struct ItemOrder {
  bool operator()(const Item& a, const Item& b) const {
    if (a.f != b.f) return a.f > b.f;
    return a.idx < b.idx;
  }
};

}  // namespace

float NetHeuristic::estimate(const uint8_t* state) const { return estimateCost(params_, state); }

float MisplacedHeuristic::estimate(const uint8_t* state) const {
  int corners = 0;
  int edges = 0;
  if (countMisplaced(state, &corners, &edges) < 0) return 1.0e6f;
  const int hc = (corners + 3) / 4;
  const int he = (edges + 3) / 4;
  return static_cast<float>(hc > he ? hc : he);
}

SearchResult solveWeightedAStar(const uint8_t* start, const Heuristic& heuristic, const SearchConfig& cfg,
                                const std::atomic<bool>* cancel) {
  SearchResult res;
  const auto t0 = std::chrono::steady_clock::now();
  auto elapsedMs = [&t0]() -> int {
    return static_cast<int>(
        std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count());
  };

  int probe[kSlots];
  if (encodeFeatures(start, probe) < 0) {
    res.status = kInvalid;
    return res;
  }
  if (isSolved(start)) {
    res.status = kSolved;
    return res;
  }

  std::vector<Node> nodes;
  nodes.reserve(4096);
  std::unordered_map<uint64_t, int16_t> best;
  best.reserve(4096);
  std::priority_queue<Item, std::vector<Item>, ItemOrder> open;

  Node root;
  std::memcpy(root.s, start, kFacelets);
  root.move = -1;
  root.g = 0;
  root.parent = -1;
  root.hash = hashState(start);
  nodes.push_back(root);
  best[root.hash] = 0;
  open.push(Item{heuristic.estimate(root.s), 0});

  res.status = kNodeLimit;
  bool finished = false;
  while (!open.empty() && !finished) {
    if ((res.expanded & 15) == 0) {
      if (cancel != nullptr && cancel->load(std::memory_order_relaxed)) {
        res.status = kCancelled;
        break;
      }
      if (elapsedMs() > cfg.timeoutMs) {
        res.status = kTimeout;
        break;
      }
    }

    const Item top = open.top();
    open.pop();
    const Node cur = nodes[static_cast<size_t>(top.idx)];  // copy: push_back below may reallocate
    const auto known = best.find(cur.hash);
    if (known != best.end() && known->second < cur.g) continue;  // a cheaper path to this state exists
    if (res.expanded >= cfg.maxExpansions) {
      res.status = kNodeLimit;
      break;
    }
    ++res.expanded;

    for (int m = 0; m < kMoves; ++m) {
      if (cur.move >= 0 && m == (cur.move ^ 1)) continue;  // never undo the previous move
      Node child;
      applyMove(cur.s, child.s, m);
      child.move = static_cast<int8_t>(m);
      child.g = static_cast<int16_t>(cur.g + 1);
      child.parent = top.idx;
      child.hash = hashState(child.s);

      if (isSolved(child.s)) {
        std::vector<uint8_t> reversed;
        reversed.push_back(static_cast<uint8_t>(m));
        int32_t i = top.idx;
        while (i >= 0 && nodes[static_cast<size_t>(i)].move >= 0) {
          reversed.push_back(static_cast<uint8_t>(nodes[static_cast<size_t>(i)].move));
          i = nodes[static_cast<size_t>(i)].parent;
        }
        res.moves.assign(reversed.rbegin(), reversed.rend());
        res.status = kSolved;
        finished = true;
        break;
      }

      const auto seen = best.find(child.hash);
      if (seen != best.end() && seen->second <= child.g) continue;
      if (static_cast<int>(nodes.size()) >= cfg.maxNodes) {
        res.status = kNodeLimit;
        finished = true;
        break;
      }
      best[child.hash] = child.g;
      const float h = heuristic.estimate(child.s);
      nodes.push_back(child);
      open.push(Item{cfg.lambda * static_cast<float>(child.g) + h, static_cast<int32_t>(nodes.size()) - 1});
      ++res.generated;
    }
  }

  res.elapsedMs = elapsedMs();
  return res;
}

}  // namespace rubik
