// JNI surface of the native core. Package/class: com.rubikailab.app.core.NativeBridge (a Kotlin object,
// so every function receives the singleton as its second argument).
//
// Result layouts (see NativeBridge.kt for the matching decoders):
//   nativeTrain / nativeStats -> double[12]: steps, samples, iterations, depth, loss, mae, accuracy,
//                                samplesPerSec, learningRate, stepsSinceSync, chunkSteps, threads
//   nativeSolve    -> int[5 + n]: status, expanded, generated, elapsedMs, n, move_0 .. move_n-1
//   nativeEvaluate -> double[6]: solved, total, avgLength, avgExpanded, avgMs, cancelled(0/1)

#include <jni.h>

#include <cstdint>
#include <vector>

#include "core/cube.h"
#include "core/engine.h"

namespace {

using rubik::Engine;

inline Engine* engineOf(jlong handle) { return reinterpret_cast<Engine*>(handle); }

jdoubleArray packStats(JNIEnv* env, const rubik::TrainStats& s) {
  const jdouble v[12] = {static_cast<jdouble>(s.steps),
                         static_cast<jdouble>(s.samples),
                         static_cast<jdouble>(s.iterations),
                         static_cast<jdouble>(s.depth),
                         static_cast<jdouble>(s.loss),
                         static_cast<jdouble>(s.mae),
                         static_cast<jdouble>(s.accuracy),
                         static_cast<jdouble>(s.samplesPerSec),
                         static_cast<jdouble>(s.lr),
                         static_cast<jdouble>(s.stepsSinceSync),
                         static_cast<jdouble>(s.chunkSteps),
                         static_cast<jdouble>(s.threads)};
  jdoubleArray arr = env->NewDoubleArray(12);
  if (arr != nullptr) env->SetDoubleArrayRegion(arr, 0, 12, v);
  return arr;
}

jintArray packInts(JNIEnv* env, const std::vector<jint>& values) {
  jintArray arr = env->NewIntArray(static_cast<jsize>(values.size()));
  if (arr != nullptr && !values.empty()) {
    env->SetIntArrayRegion(arr, 0, static_cast<jsize>(values.size()), values.data());
  }
  return arr;
}

}  // namespace

extern "C" {

JNIEXPORT jintArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeGeometry(JNIEnv* env, jobject) {
  const rubik::CubeTables& t = rubik::cubeTables();
  std::vector<jint> out(static_cast<size_t>(rubik::kFacelets) * 6);
  for (int i = 0; i < rubik::kFacelets; ++i) {
    for (int k = 0; k < 3; ++k) {
      out[static_cast<size_t>(i * 6 + k)] = t.pos[i][k];
      out[static_cast<size_t>(i * 6 + 3 + k)] = t.normal[i][k];
    }
  }
  return packInts(env, out);
}

JNIEXPORT jintArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeMoveTable(JNIEnv* env, jobject) {
  const rubik::CubeTables& t = rubik::cubeTables();
  std::vector<jint> out(static_cast<size_t>(rubik::kMoves) * rubik::kFacelets);
  for (int m = 0; m < rubik::kMoves; ++m) {
    for (int i = 0; i < rubik::kFacelets; ++i) {
      out[static_cast<size_t>(m * rubik::kFacelets + i)] = t.perm[m][i];
    }
  }
  return packInts(env, out);
}

JNIEXPORT jint JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeParamCount(JNIEnv*, jobject) {
  return static_cast<jint>(rubik::kParamCount);
}

JNIEXPORT jlong JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeCreate(JNIEnv*, jobject, jlong seed) {
  return reinterpret_cast<jlong>(new Engine(static_cast<uint64_t>(seed)));
}

JNIEXPORT void JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeDestroy(JNIEnv*, jobject, jlong handle) {
  delete engineOf(handle);
}

JNIEXPORT void JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeReset(JNIEnv*, jobject, jlong handle,
                                                                             jlong seed) {
  engineOf(handle)->reset(static_cast<uint64_t>(seed));
}

JNIEXPORT void JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeConfigure(JNIEnv*, jobject, jlong handle,
                                                                                 jint batch, jfloat learningRate,
                                                                                 jint maxDepth, jint threads) {
  rubik::TrainConfig cfg;
  cfg.batch = batch;
  cfg.lr = learningRate;
  cfg.maxDepth = maxDepth;
  cfg.threads = threads;
  engineOf(handle)->configure(cfg);
}

JNIEXPORT jdoubleArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeTrain(JNIEnv* env, jobject,
                                                                                     jlong handle, jint budgetMs) {
  return packStats(env, engineOf(handle)->train(budgetMs));
}

JNIEXPORT jdoubleArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeStats(JNIEnv* env, jobject,
                                                                                     jlong handle) {
  return packStats(env, engineOf(handle)->stats());
}

JNIEXPORT jintArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeSolve(
    JNIEnv* env, jobject, jlong handle, jint mode, jbyteArray state, jint maxExpansions, jfloat lambda,
    jint timeoutMs) {
  std::vector<jint> out;
  if (state == nullptr || env->GetArrayLength(state) != rubik::kFacelets) {
    out = {rubik::kInvalid, 0, 0, 0, 0};
    return packInts(env, out);
  }
  jbyte raw[rubik::kFacelets];
  env->GetByteArrayRegion(state, 0, rubik::kFacelets, raw);
  uint8_t cube[rubik::kFacelets];
  for (int i = 0; i < rubik::kFacelets; ++i) cube[i] = static_cast<uint8_t>(raw[i]);

  rubik::SearchConfig cfg;
  cfg.maxExpansions = maxExpansions;
  cfg.lambda = lambda;
  cfg.timeoutMs = timeoutMs;
  const rubik::SearchResult r = engineOf(handle)->solve(mode, cube, cfg);

  out.reserve(5 + r.moves.size());
  out.push_back(r.status);
  out.push_back(r.expanded);
  out.push_back(r.generated);
  out.push_back(r.elapsedMs);
  out.push_back(static_cast<jint>(r.moves.size()));
  for (uint8_t m : r.moves) out.push_back(static_cast<jint>(m));
  return packInts(env, out);
}

JNIEXPORT jdoubleArray JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeEvaluate(
    JNIEnv* env, jobject, jlong handle, jint mode, jint depth, jint cases, jint maxExpansions, jfloat lambda,
    jint timeoutMs) {
  rubik::SearchConfig cfg;
  cfg.maxExpansions = maxExpansions;
  cfg.lambda = lambda;
  cfg.timeoutMs = timeoutMs;
  const rubik::EvalResult r = engineOf(handle)->evaluate(mode, depth, cases, cfg);
  const jdouble v[6] = {static_cast<jdouble>(r.solved), static_cast<jdouble>(r.total), r.avgLength,
                        r.avgExpanded,                  r.avgMs,                       r.cancelled ? 1.0 : 0.0};
  jdoubleArray arr = env->NewDoubleArray(6);
  if (arr != nullptr) env->SetDoubleArrayRegion(arr, 0, 6, v);
  return arr;
}

JNIEXPORT void JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeSetCancel(JNIEnv*, jobject, jlong handle,
                                                                                 jboolean cancel) {
  engineOf(handle)->setCancel(cancel == JNI_TRUE);
}

JNIEXPORT jboolean JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeSave(JNIEnv* env, jobject, jlong handle,
                                                                                jstring path) {
  if (path == nullptr) return JNI_FALSE;
  const char* chars = env->GetStringUTFChars(path, nullptr);
  if (chars == nullptr) return JNI_FALSE;
  const bool ok = engineOf(handle)->save(chars);
  env->ReleaseStringUTFChars(path, chars);
  return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL Java_com_rubikailab_app_core_NativeBridge_nativeLoad(JNIEnv* env, jobject, jlong handle,
                                                                                jstring path) {
  if (path == nullptr) return JNI_FALSE;
  const char* chars = env->GetStringUTFChars(path, nullptr);
  if (chars == nullptr) return JNI_FALSE;
  const bool ok = engineOf(handle)->load(chars);
  env->ReleaseStringUTFChars(path, chars);
  return ok ? JNI_TRUE : JNI_FALSE;
}

}  // extern "C"
