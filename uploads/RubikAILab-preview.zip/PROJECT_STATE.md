# Rubik AI Lab - PROJECT STATE

Checkpoint 0 (recovery) - 2026-10-17

## Recovery findings (verified, not assumed)
- Workspace (Download/Claude) held NO Rubik AI Lab files (only the unrelated CodeWaveStudio folder/zip).
- Shared memory held NO entries (0 projects, 0 Rubik matches).
- Conclusion: the previous account produced nothing recoverable. Work starts from zero.

## Owner constraints
- DO NOT use GitHub. Owner uploads the final ZIP himself. His GitHub Actions workflow ("Build APK") unzips the newest ZIP under uploads/, finds settings.gradle, and runs ./gradlew assembleDebug (JDK 17, Gradle 8.6, NDK 25.2.9519653, CMake 3.22.1).
- Do not modify or rebuild Claude FileBridge.
- No fake learning: no prerecorded solutions, no fabricated stats. Conventional-solver benchmarks are reported separately from the learned model.
- Real files + saved checkpoints first. Do not burn usage on planning.

## Decisions so far
- Project folder: RubikAILab/ ; ZIP target: ZIP/RubikAILab.zip
- Stack: Kotlin UI (framework views only, no AndroidX) + OpenGL ES 2.0 renderer (Kotlin) + native C++17 core via JNI.
- CI-compatible layout: app/src/main/cpp/{CMakeLists.txt, jni_bridge.cpp, core/*.cpp|*.h} (core/ is flat because the CI cache key hashes core/*.cpp).
- Cube: 54-facelet model, quarter-turn metric (12 moves). Move tables are generated from 3D geometry, the same geometry the renderer consumes.
- AI: small MLP value function (sparse cubie one-hot input) trained by approximate value iteration, used as heuristic in weighted A*. Curriculum by scramble depth.

## Status
- [ ] C++ cube core + host tests
- [ ] Search (weighted A*), baseline heuristic
- [ ] Neural net + trainer + checkpoints
- [ ] JNI bridge
- [ ] Kotlin app (UI, GL renderer, controls)
- [ ] Docs (README, AI_DESIGN, BUILD, CHANGELOG)
- [ ] ZIP exported and verified
- Android build verified: NO (no Android SDK/network in Claude's sandbox; CI is the owner's)
