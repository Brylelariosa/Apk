package com.immortalascension

import kotlin.random.Random

object WorldEventSystem {

    private const val MIN_DAYS_BETWEEN_EVENTS = 20

    // ── CHECK FOR NEW EVENTS ──────────────────────────────────────────────────

    fun checkWorldEvents(state: GameState): List<LogEntry> {
        val log = mutableListOf<LogEntry>()
        val world = state.world

        if (world.daysSinceLastWorldEvent < MIN_DAYS_BETWEEN_EVENTS) return log
        if (Random.nextFloat() > 0.35f) return log  // 35% chance each check

        world.daysSinceLastWorldEvent = 0

        val existingTypes = world.activeEvents.map { it.type }.toSet()
        val available = WorldEventType.values().filter { it !in existingTypes }
        if (available.isEmpty()) return log

        val event = generateEvent(available.random(), state)
        world.activeEvents.add(event)
        world.eventHistory.add("[Year ${world.year}] ${event.title}")

        log += LogEntry("")
        log += LogEntry("━━━ WORLD EVENT ━━━", LogType.WORLD)
        log += LogEntry("✦ ${event.title} ✦", LogType.WORLD)
        log += LogEntry(event.desc, LogType.WORLD)
        if (event.playerOpportunity.isNotEmpty()) {
            log += LogEntry("Opportunity: ${event.playerOpportunity}", LogType.EVENT)
        }

        // Immediate effects
        val immediate = immediateEventEffect(event, state)
        if (immediate.isNotEmpty()) log += LogEntry(immediate, LogType.WORLD)

        return log
    }

    // ── EVENT GENERATORS ──────────────────────────────────────────────────────

    private fun generateEvent(type: WorldEventType, state: GameState): WorldEvent = when (type) {

        WorldEventType.SECT_WAR -> WorldEvent(
            id = "sect_war_${state.world.year}",
            title = "The Sects Clash",
            desc = "Open conflict erupts between the Azure Mountain Sect and the Crimson Flame Sect. Disciples are deployed. The roads are dangerous. The opportunistic grow rich, and the weak disappear.",
            type = WorldEventType.SECT_WAR,
            daysRemaining = Random.nextInt(30, 90),
            playerOpportunity = "Fight for a sect as a mercenary, loot the battlefield, or stay neutral and watch the power shift."
        )

        WorldEventType.DEMON_INVASION -> WorldEvent(
            id = "demon_invasion_${state.world.year}",
            title = "The Demon Tide Breaks",
            desc = "Demonic entities from the Demon Wastes surge outward in an organized assault. Villages burn. Sects mobilize. The sky in the west has been wrong for three days.",
            type = WorldEventType.DEMON_INVASION,
            daysRemaining = Random.nextInt(20, 60),
            playerOpportunity = "Demon kills yield rare materials. Inner demon level increases near the front lines."
        )

        WorldEventType.SECRET_REALM -> WorldEvent(
            id = "secret_realm_${state.world.year}",
            title = "A Secret Realm Opens",
            desc = "A spatial rift has appeared near Thunder Peak — a temporary pocket dimension from a fallen ancient sect. Inside: techniques, artifacts, and dangers that have waited ten thousand years. It will close in thirty days.",
            type = WorldEventType.SECRET_REALM,
            daysRemaining = 30,
            playerOpportunity = "Travel to Thunder Peak while the realm is open for a chance at legendary loot and ancient inheritance."
        )

        WorldEventType.HEAVENLY_PHENOMENON -> WorldEvent(
            id = "heaven_phen_${state.world.year}",
            title = "Heavenly Phenomenon",
            desc = "The stars rearrange. Three suns rise simultaneously for a single morning. Qi density across the entire region increases dramatically. Even mortals feel it.",
            type = WorldEventType.HEAVENLY_PHENOMENON,
            daysRemaining = Random.nextInt(5, 15),
            playerOpportunity = "Cultivation speed doubled during this event. Breakthrough chances increase by 20%."
        )

        WorldEventType.BEAST_TIDE -> WorldEvent(
            id = "beast_tide_${state.world.year}",
            title = "The Beast Tide",
            desc = "A massive tide of spiritual beasts pours from the forest, driven out by something deeper inside that terrified even them. Settlements brace for impact.",
            type = WorldEventType.BEAST_TIDE,
            daysRemaining = Random.nextInt(10, 25),
            playerOpportunity = "Defeating beast tide enemies yields more loot than usual. Dangerous but profitable."
        )

        WorldEventType.ANCIENT_TOMB -> WorldEvent(
            id = "ancient_tomb_${state.world.year}",
            title = "An Ancient Tomb Surfaces",
            desc = "The earth split open near the ruins, revealing a previously buried Nascent Soul cultivator's tomb. The array sealing it has begun to fail after ten thousand years.",
            type = WorldEventType.ANCIENT_TOMB,
            daysRemaining = 45,
            playerOpportunity = "The tomb contains ancient techniques and pills — but also ancient guardians that have been waiting patiently."
        )

        WorldEventType.GRAND_AUCTION -> WorldEvent(
            id = "grand_auction_${state.world.year}",
            title = "The Grand Auction Opens",
            desc = "Iron Cauldron City hosts its annual grand auction. Rare pills, legendary weapons, ancient scrolls, and one item rumored to be Heaven-grade are on offer. Half the cultivators in the region are attending.",
            type = WorldEventType.GRAND_AUCTION,
            daysRemaining = 15,
            playerOpportunity = "Travel to Iron Cauldron City during this event for access to premium shop items at premium prices."
        )

        WorldEventType.CELESTIAL_EVENT -> WorldEvent(
            id = "celestial_${state.world.year}",
            title = "The Celestial Gate Stirs",
            desc = "Something beyond the sky has noticed the mortal world. Tribulation clouds gather over powerful cultivators unprompted. Those near breakthrough should be careful — or seize the chance.",
            type = WorldEventType.CELESTIAL_EVENT,
            daysRemaining = Random.nextInt(7, 20),
            playerOpportunity = "Breakthroughs attempted during this event may be more intense — but the rewards are greater on success."
        )
    }

    // ── IMMEDIATE EFFECTS ─────────────────────────────────────────────────────

    private fun immediateEventEffect(event: WorldEvent, state: GameState): String {
        val p = state.player
        return when (event.type) {
            WorldEventType.HEAVENLY_PHENOMENON -> {
                val qi = p.maxQi / 10
                p.qi = (p.qi + qi).coerceAtMost(p.maxQi)
                "The surge of Qi is immediate. You absorb +$qi Qi from the phenomenon."
            }
            WorldEventType.DEMON_INVASION -> {
                p.innerDemonLevel = (p.innerDemonLevel + 8).coerceAtMost(100)
                "The wave of demonic intent presses against your mind. +8 Inner Demon."
            }
            WorldEventType.SECT_WAR -> {
                "The sound of distant explosions carries on the wind. The air tastes of blood and burning Qi."
            }
            WorldEventType.CELESTIAL_EVENT -> {
                p.daoHeart = (p.daoHeart + 5).coerceAtMost(100)
                "The celestial pressure steadies your Dao Heart oddly. +5 Dao Heart."
            }
            else -> ""
        }
    }

    // ── EVENT MODIFIERS (called by other systems) ─────────────────────────────

    fun cultivationBonus(world: WorldState): Float {
        var bonus = 1.0f
        world.activeEvents.forEach {
            when (it.type) {
                WorldEventType.HEAVENLY_PHENOMENON -> bonus *= 2.0f
                WorldEventType.DEMON_INVASION      -> bonus *= 0.8f
                WorldEventType.CELESTIAL_EVENT     -> bonus *= 1.3f
                else -> {}
            }
        }
        return bonus
    }

    fun breakthroughBonus(world: WorldState): Float {
        var bonus = 0.0f
        world.activeEvents.forEach {
            when (it.type) {
                WorldEventType.HEAVENLY_PHENOMENON -> bonus += 0.2f
                WorldEventType.CELESTIAL_EVENT     -> bonus += 0.15f
                WorldEventType.SECT_WAR            -> bonus -= 0.05f
                else -> {}
            }
        }
        return bonus
    }

    fun explorationLootBonus(world: WorldState): Float {
        var bonus = 1.0f
        world.activeEvents.forEach {
            when (it.type) {
                WorldEventType.BEAST_TIDE   -> bonus *= 1.5f
                WorldEventType.ANCIENT_TOMB -> bonus *= 1.4f
                WorldEventType.SECRET_REALM -> bonus *= 1.6f
                WorldEventType.GRAND_AUCTION-> bonus *= 0.7f  // everyone is at the city
                else -> {}
            }
        }
        return bonus
    }

    fun activeEventsSummary(world: WorldState): String {
        if (world.activeEvents.isEmpty()) return "The world is quiet."
        return world.activeEvents.joinToString("\n") {
            "• ${it.title} (${it.daysRemaining} days remaining)"
        }
    }
}
