package com.immortalascension

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder

object SaveSystem {

    private const val PREF_NAME = "immortal_save"
    private const val KEY_GAME = "game_state"
    private const val KEY_LAST_SAVE = "last_save_time"

    private val gson: Gson = GsonBuilder().serializeNulls().create()

    fun save(context: Context, engine: GameEngine) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json = gson.toJson(engine.state)
        prefs.edit()
            .putString(KEY_GAME, json)
            .putLong(KEY_LAST_SAVE, System.currentTimeMillis())
            .apply()
    }

    fun load(context: Context): GameState? {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_GAME, null) ?: return null
        return try {
            gson.fromJson(json, GameState::class.java)
        } catch (e: Exception) {
            null
        }
    }

    fun hasSave(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.contains(KEY_GAME)
    }

    fun deleteSave(context: Context) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun lastSaveTime(context: Context): Long {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getLong(KEY_LAST_SAVE, 0L)
    }
}
