package com.immortalascension

object InventorySystem {

    // ── ITEM CATALOG ──────────────────────────────────────────────────────────

    // Pills
    val MINOR_HEALING_PILL = Item("minor_heal", "Minor Healing Pill",
        "A basic pill that restores a small amount of vitality.", ItemType.PILL, value = 5,
        hpRestore = 60)
    val MAJOR_HEALING_PILL = Item("major_heal", "Major Healing Pill",
        "A high-grade pill. Warm energy floods the meridians.", ItemType.PILL, value = 20,
        hpRestore = 200)
    val QI_RECOVERY_PILL = Item("qi_pill", "Qi Recovery Pill",
        "Dissolves in the dantian, replenishing expended Qi.", ItemType.PILL, value = 8,
        qiRestore = 100)
    val PURE_QI_PILL = Item("pure_qi", "Pure Qi Condensation Pill",
        "Refined over forty-nine days. Restores Qi to full.", ItemType.PILL, value = 35,
        qiRestore = 9999)
    val DEMON_SUPPRESSION_PILL = Item("demon_pill", "Demon Suppression Pill",
        "Bitter to the tongue. Quiets the inner demons.", ItemType.PILL, value = 25,
        innerDemonReduce = 30, daoHeartBonus = 10)
    val FOUNDATION_CONSOLIDATION_PILL = Item("foundation_pill", "Foundation Consolidation Pill",
        "Strengthens the foundation before a breakthrough.", ItemType.PILL, value = 60,
        breakthroughBonus = 0.12f, maxHpBonus = 20, maxQiBonus = 50)
    val COMPREHENSION_PILL = Item("comp_pill", "Enlightenment Elixir",
        "A single dose opens the mind's eye for hours.", ItemType.PILL, value = 80,
        daoHeartBonus = 15)
    val BODY_TEMPERING_PILL = Item("body_pill", "Body Tempering Pill",
        "Scorching pain followed by a permanent toughening of flesh.", ItemType.PILL, value = 40,
        maxHpBonus = 50)

    // Weapons
    val IRON_SWORD = Item("iron_sword", "Iron Sword",
        "A mortal-grade sword. Better than bare hands.", ItemType.WEAPON, value = 12,
        atkBonus = 8)
    val SPIRIT_EDGE = Item("spirit_edge", "Spirit-Infused Edge",
        "A blade that hums with Qi. Its edge never dulls.", ItemType.WEAPON, value = 60,
        atkBonus = 22)
    val THUNDER_SABER = Item("thunder_saber", "Thunder Saber",
        "Forged during a lightning tribulation. Crackles with electricity.", ItemType.WEAPON, value = 180,
        atkBonus = 45)
    val VOID_NEEDLE = Item("void_needle", "Void Needle",
        "A thin blade that pierces spiritual defenses.", ItemType.WEAPON, value = 120,
        atkBonus = 30)

    // Armor
    val LEATHER_ROBE = Item("leather_robe", "Reinforced Leather Robe",
        "Basic protection. Worn by every outer disciple.", ItemType.ARMOR, value = 10,
        defBonus = 5)
    val SPIRIT_SILK_VEST = Item("spirit_silk", "Spirit Silk Protective Vest",
        "Woven from spiritual spider silk. Absorbs impact.", ItemType.ARMOR, value = 55,
        defBonus = 18)
    val JADE_ARMOR = Item("jade_armor", "Jade Body Armor",
        "Jade plates infused with earth Qi. Heavy but nearly impenetrable.", ItemType.ARMOR, value = 150,
        defBonus = 40, maxHpBonus = 80)

    // Materials (for trading / sect contribution)
    val WOLF_PELT         = Item("wolf_pelt",    "Wolf Pelt",         "Still warm.",                      ItemType.MATERIAL, value = 2)
    val SPIRIT_JADE_SHARD = Item("spirit_jade",  "Spirit Jade Shard", "Faintly luminous.",                ItemType.MATERIAL, value = 15)
    val THUNDER_FEATHER   = Item("thunder_feat", "Thunder Feather",   "Crackles when touched.",           ItemType.MATERIAL, value = 30)
    val DEMON_CORE_SHARD  = Item("demon_core",   "Demon Core Shard",  "Radiates suppressed darkness.",    ItemType.MATERIAL, value = 50)
    val ANCIENT_BONE      = Item("ancient_bone", "Ancient Cultivator's Bone","Still contains faint Qi.",  ItemType.MATERIAL, value = 25)
    val HEAVENLY_SILK     = Item("heaven_silk",  "Heavenly Silk Thread","Used in formation arrays.",      ItemType.MATERIAL, value = 80)

    // Technique Scrolls
    val SCROLL_VOID_STEP      = Item("scroll_void",    "Scroll: Void Step",           "Teaches the Void Step technique.",          ItemType.TECHNIQUE_SCROLL, value = 100, linkedTechId = "void_step")
    val SCROLL_THUNDER_DOMAIN = Item("scroll_thunder", "Scroll: Thunder Domain",      "Teaches Thunder Domain.",                   ItemType.TECHNIQUE_SCROLL, value = 200, linkedTechId = "thunder_domain")
    val SCROLL_BLOOD_PHOENIX  = Item("scroll_phoenix", "Scroll: Blood Phoenix Art",   "Teaches the Blood Phoenix Art.",            ItemType.TECHNIQUE_SCROLL, value = 250, linkedTechId = "blood_phoenix")
    val SCROLL_IRON_DEFENSE   = Item("scroll_iron",    "Scroll: Iron Body Sutra",     "Teaches Iron Body Technique.",              ItemType.TECHNIQUE_SCROLL, value = 80,  linkedTechId = "iron_body")

    // Artifacts
    val LUCK_JADE    = Item("luck_jade",   "Luck Jade Pendant",   "An old cultivator's charm. Warm to the touch.", ItemType.ARTIFACT, value = 40, daoHeartBonus = 8)
    val INSIGHT_BEAD = Item("insight_bead","Insight Prayer Bead", "Turns slowly on its own.",                      ItemType.ARTIFACT, value = 90, daoHeartBonus = 15, innerDemonReduce = 10)

    // ── SHOP STOCK BY LOCATION ─────────────────────────────────────────────────

    fun shopStockFor(locationId: String): List<Item> = when (locationId) {
        "azure_wind_village" -> listOf(
            MINOR_HEALING_PILL.copy(), QI_RECOVERY_PILL.copy(), IRON_SWORD.copy(), LEATHER_ROBE.copy()
        )
        "cultivation_city" -> listOf(
            MINOR_HEALING_PILL.copy(), MAJOR_HEALING_PILL.copy(), QI_RECOVERY_PILL.copy(),
            PURE_QI_PILL.copy(), DEMON_SUPPRESSION_PILL.copy(), FOUNDATION_CONSOLIDATION_PILL.copy(),
            COMPREHENSION_PILL.copy(), SPIRIT_EDGE.copy(), SPIRIT_SILK_VEST.copy(),
            SCROLL_IRON_DEFENSE.copy(), LUCK_JADE.copy()
        )
        "azure_mountain_sect", "crimson_flame_sect", "silent_moon_pavilion" -> listOf(
            MINOR_HEALING_PILL.copy(), MAJOR_HEALING_PILL.copy(), FOUNDATION_CONSOLIDATION_PILL.copy(),
            DEMON_SUPPRESSION_PILL.copy(), BODY_TEMPERING_PILL.copy(), SPIRIT_EDGE.copy(),
            JADE_ARMOR.copy(), SCROLL_VOID_STEP.copy()
        )
        else -> listOf(MINOR_HEALING_PILL.copy(), QI_RECOVERY_PILL.copy())
    }

    // ── USE ITEM ──────────────────────────────────────────────────────────────

    fun useItem(player: Player, item: Item): String {
        return when (item.type) {
            ItemType.PILL, ItemType.ARTIFACT -> consumeItem(player, item)
            ItemType.WEAPON -> equipWeapon(player, item)
            ItemType.ARMOR  -> equipArmor(player, item)
            ItemType.TECHNIQUE_SCROLL -> learnFromScroll(player, item)
            ItemType.MATERIAL -> "You examine the ${item.name}. It can be sold or offered to a sect."
        }
    }

    private fun consumeItem(player: Player, item: Item): String {
        val sb = StringBuilder()
        if (item.hpRestore > 0) {
            val actual = minOf(item.hpRestore, player.maxHp - player.hp)
            player.hp = (player.hp + item.hpRestore).coerceAtMost(player.maxHp)
            sb.append("+$actual HP. ")
        }
        if (item.qiRestore > 0) {
            val actual = minOf(item.qiRestore, player.maxQi - player.qi)
            player.qi = (player.qi + item.qiRestore).coerceAtMost(player.maxQi)
            sb.append("+$actual Qi. ")
        }
        if (item.maxHpBonus > 0) { player.maxHp += item.maxHpBonus; player.hp += item.maxHpBonus; sb.append("+${item.maxHpBonus} Max HP. ") }
        if (item.maxQiBonus > 0) { player.maxQi += item.maxQiBonus; sb.append("+${item.maxQiBonus} Max Qi. ") }
        if (item.daoHeartBonus > 0) { player.daoHeart = (player.daoHeart + item.daoHeartBonus).coerceAtMost(100); sb.append("+${item.daoHeartBonus} Dao Heart. ") }
        if (item.innerDemonReduce > 0) { player.innerDemonLevel = (player.innerDemonLevel - item.innerDemonReduce).coerceAtLeast(0); sb.append("-${item.innerDemonReduce} Inner Demon. ") }

        removeOrDecrement(player, item)
        return "You consume ${item.name}. $sb"
    }

    private fun equipWeapon(player: Player, item: Item): String {
        player.equippedWeapon?.equipped = false
        player.equippedWeapon = item
        item.equipped = true
        return "You equip ${item.name}. Attack +${item.atkBonus}."
    }

    private fun equipArmor(player: Player, item: Item): String {
        player.equippedArmor?.equipped = false
        player.equippedArmor = item
        item.equipped = true
        return "You don ${item.name}. Defense +${item.defBonus}."
    }

    private fun learnFromScroll(player: Player, item: Item): String {
        val alreadyKnows = player.techniques.any { it.id == item.linkedTechId }
        if (alreadyKnows) return "You already know this technique. The scroll crumbles to ash nonetheless."

        val tech = EventSystem.RARE_TECHNIQUES.firstOrNull { it.id == item.linkedTechId }
            ?: EventSystem.STARTING_TECHNIQUES.firstOrNull { it.id == item.linkedTechId }
            ?: return "The scroll's content is beyond your current comprehension."

        player.techniques.add(tech.copy())
        removeOrDecrement(player, item)
        return "You study the scroll intently. Technique learned: ${tech.name}."
    }

    fun removeOrDecrement(player: Player, item: Item) {
        if (item.quantity > 1) {
            item.quantity--
        } else {
            player.inventory.remove(item)
            if (player.equippedWeapon == item) player.equippedWeapon = null
            if (player.equippedArmor == item) player.equippedArmor = null
        }
    }

    // ── TECHNIQUE EVOLUTION ───────────────────────────────────────────────────

    fun checkTechEvolution(tech: Technique): String? {
        if (tech.evolutionPath.isNotEmpty()) return null  // already evolved
        val up = tech.usageProfile
        val totalUses = up.offensiveUses + up.defensiveUses

        return when {
            totalUses < 30 -> null
            up.killFinishes >= 15 && up.offensiveUses > up.defensiveUses * 2 -> "Killing"
            up.defensiveUses >= 20 && up.defensiveUses > up.offensiveUses -> "Guardian"
            up.offensiveUses > 20 && up.defensiveUses > 10 -> "Enlightened"
            else -> null
        }
    }

    // ── LOOT GENERATOR ────────────────────────────────────────────────────────

    fun randomLootItem(playerRealm: Realm): Item? {
        val roll = kotlin.random.Random.nextFloat()
        return when {
            roll < 0.35f -> MINOR_HEALING_PILL.copy()
            roll < 0.50f -> QI_RECOVERY_PILL.copy()
            roll < 0.60f -> when (playerRealm.tier) {
                RealmTier.QI_GATHERING -> WOLF_PELT.copy()
                RealmTier.FOUNDATION   -> SPIRIT_JADE_SHARD.copy()
                else -> DEMON_CORE_SHARD.copy()
            }
            roll < 0.70f -> DEMON_SUPPRESSION_PILL.copy()
            roll < 0.78f -> MAJOR_HEALING_PILL.copy()
            roll < 0.84f -> when (playerRealm.tier) {
                RealmTier.QI_GATHERING -> IRON_SWORD.copy()
                else -> SPIRIT_EDGE.copy()
            }
            roll < 0.90f -> FOUNDATION_CONSOLIDATION_PILL.copy()
            roll < 0.95f -> THUNDER_FEATHER.copy()
            roll < 0.98f -> SCROLL_IRON_DEFENSE.copy()
            else         -> SCROLL_VOID_STEP.copy()
        }
    }
}
