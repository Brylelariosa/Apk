package com.immortalascension

object LocationSystem {

    // ── LOCATION CATALOG ──────────────────────────────────────────────────────

    val ALL_LOCATIONS = mapOf(
        "azure_wind_village" to Location(
            id = "azure_wind_village",
            name = "Azure Wind Village",
            desc = "A small mortal settlement at the base of the Azure Mountains. Spiritual energy here is thin but steady. A few cultivators pass through each season.",
            qiQuality = QiQuality.THIN,
            dangerLevel = 1,
            cultivationBonus = 0.8f,
            hasShop = true,
            hasSect = false,
            travelHours = 0,
            flavorLines = listOf(
                "Dogs bark in the distance. Smoke rises from cookfires.",
                "A child runs past, clutching a wooden sword.",
                "The village elder nods at you with quiet knowing.",
                "Wind carries the smell of rice wine and pine resin.",
                "The market is winding down. Merchants cover their stalls."
            )
        ),
        "verdant_forest" to Location(
            id = "verdant_forest",
            name = "Verdant Spirit Forest",
            desc = "Ancient trees older than any living sect. Spiritual beasts make their home here. Qi flows thick through the underbrush.",
            qiQuality = QiQuality.RICH,
            dangerLevel = 3,
            cultivationBonus = 1.2f,
            hasShop = false,
            travelHours = 4,
            flavorLines = listOf(
                "The canopy filters sunlight into emerald shards.",
                "Something large moves just beyond your vision.",
                "Ancient Qi saturates every breath. Your meridians respond.",
                "A stream runs clear over stones worn smooth by centuries.",
                "The forest has its own silence — deep, watchful, alive."
            )
        ),
        "thunder_peak" to Location(
            id = "thunder_peak",
            name = "Thunder Peak Mountains",
            desc = "Lightning strikes this range year-round. Violent Qi churns in the stone itself. Powerful beasts and rogue cultivators compete for its resources.",
            qiQuality = QiQuality.VIOLENT,
            dangerLevel = 6,
            minRealm = RealmTier.QI_GATHERING,
            cultivationBonus = 1.5f,
            hasShop = false,
            travelHours = 8,
            flavorLines = listOf(
                "Thunder rolls even under a clear sky.",
                "The stone beneath your feet hums with suppressed lightning.",
                "A charred skeleton near the path. A cautionary sight.",
                "Your Qi sparks and writhes — the environment is aggressive.",
                "The air smells of ozone and burning stone."
            )
        ),
        "ancient_ruins" to Location(
            id = "ancient_ruins",
            name = "Shattered Heaven Ruins",
            desc = "Ruins of a sect that ascended — or was destroyed — ten thousand years ago. Ancient Qi lingers in the broken formations. Treasures and dangers in equal measure.",
            qiQuality = QiQuality.ANCIENT,
            dangerLevel = 7,
            minRealm = RealmTier.QI_GATHERING,
            cultivationBonus = 1.4f,
            hasShop = false,
            travelHours = 10,
            flavorLines = listOf(
                "Cracked stone pillars rise from the earth like broken teeth.",
                "A formation array still flickers, ten millennia later.",
                "Faint echoes of the ancient cultivators can almost be heard.",
                "Something sealed here stirs in its sleep.",
                "The Qi here carries memory. It presses against your mind."
            )
        ),
        "cultivation_city" to Location(
            id = "cultivation_city",
            name = "Iron Cauldron City",
            desc = "The nearest cultivator city. Auction houses, pill shops, information brokers, and five minor sects all compete for influence within its walls.",
            qiQuality = QiQuality.DENSE,
            dangerLevel = 2,
            cultivationBonus = 1.1f,
            hasShop = true,
            hasSect = false,
            travelHours = 12,
            flavorLines = listOf(
                "Flying swords arc overhead. Nobody looks up.",
                "The auction house banners snap in the wind.",
                "A sect war's rumor is the topic of every tea house.",
                "You pass three Foundation-realm cultivators in as many minutes.",
                "Pill smoke drifts from a hundred alchemist furnaces."
            )
        ),
        "demon_wastes" to Location(
            id = "demon_wastes",
            name = "Demon Wastes",
            desc = "A blighted land where demonic Qi corrodes reality itself. Twisted beasts, fallen cultivators, and ancient evils wander freely. Most never return.",
            qiQuality = QiQuality.CORRUPTED,
            dangerLevel = 9,
            minRealm = RealmTier.FOUNDATION,
            cultivationBonus = 0.7f,
            hasShop = false,
            travelHours = 16,
            flavorLines = listOf(
                "The sky here is a permanent bruised purple.",
                "Qi enters your body wrong. Something resists you.",
                "Twisted shapes move at the edge of vision. They watch.",
                "You pass the ruins of a village. The silence is absolute.",
                "Inner demons stir without warning here."
            )
        ),
        "sacred_spring" to Location(
            id = "sacred_spring",
            name = "Sacred Spring Valley",
            desc = "A hidden valley where a heavenly spring surfaces. Cultivators who find it often achieve breakthrough here. Jealously guarded.",
            qiQuality = QiQuality.HEAVENLY,
            dangerLevel = 4,
            minRealm = RealmTier.QI_GATHERING,
            cultivationBonus = 2.0f,
            hasShop = false,
            travelHours = 14,
            flavorLines = listOf(
                "The spring glows faintly gold at its source.",
                "Flowers bloom here regardless of season.",
                "The Qi density is physically visible as a golden haze.",
                "Even breathing slowly restores vitality.",
                "Previous meditators left formations carved into the valley walls."
            )
        ),
        "azure_mountain_sect" to Location(
            id = "azure_mountain_sect",
            name = "Azure Mountain Sect",
            desc = "One of the three major sects of this region. Focused on sword Dao and righteous cultivation. Founded three thousand years ago.",
            qiQuality = QiQuality.DENSE,
            dangerLevel = 2,
            cultivationBonus = 1.3f,
            hasShop = true,
            hasSect = true,
            travelHours = 10
        ),
        "crimson_flame_sect" to Location(
            id = "crimson_flame_sect",
            name = "Crimson Flame Sect",
            desc = "A fire-focused sect known for aggressive techniques and battlefield prowess. Rivals the Azure Mountain Sect for regional dominance.",
            qiQuality = QiQuality.DENSE,
            dangerLevel = 2,
            cultivationBonus = 1.3f,
            hasShop = true,
            hasSect = true,
            travelHours = 12
        ),
        "silent_moon_pavilion" to Location(
            id = "silent_moon_pavilion",
            name = "Silent Moon Pavilion",
            desc = "A reclusive sect of alchemists and defensive cultivators. Neutral in sect politics. Welcoming to those who seek knowledge over power.",
            qiQuality = QiQuality.DENSE,
            dangerLevel = 1,
            cultivationBonus = 1.4f,
            hasShop = true,
            hasSect = true,
            travelHours = 15
        )
    )

    fun get(id: String): Location = ALL_LOCATIONS[id] ?: ALL_LOCATIONS["azure_wind_village"]!!

    // ── TRAVEL ────────────────────────────────────────────────────────────────

    fun canTravel(player: Player, location: Location): Pair<Boolean, String> {
        if (player.realm.tier.ordinal < location.minRealm.ordinal) {
            return Pair(false, "Your current realm is insufficient for ${location.name}. The Qi there would tear you apart.")
        }
        if (player.hp < player.maxHp * 0.3f) {
            return Pair(false, "You are too wounded to travel safely. Rest first.")
        }
        return Pair(true, "")
    }

    fun travelTo(state: GameState, locationId: String): List<LogEntry> {
        val log = mutableListOf<LogEntry>()
        val location = get(locationId)
        val (canGo, reason) = canTravel(state.player, location)

        if (!canGo) {
            log += LogEntry(reason, LogType.DANGER)
            return log
        }

        state.world.advance(location.travelHours)
        state.world.locationId = locationId
        state.world.location = location.name

        if (!state.world.discoveredPlaces.contains(locationId)) {
            state.world.discoveredPlaces.add(locationId)
            log += LogEntry("✦ New location discovered: ${location.name}", LogType.EVENT)
        }

        log += LogEntry("")
        log += LogEntry("You arrive at ${location.name}.", LogType.SYSTEM)
        log += LogEntry(location.desc, LogType.NORMAL)
        log += LogEntry(location.flavorLines.randomOrNull() ?: "", LogType.NORMAL)
        log += LogEntry("Qi Quality: ${qiQualityDesc(location.qiQuality)}  Danger: ${"⚔".repeat(location.dangerLevel / 2 + 1)}", LogType.SYSTEM)

        // Qi quality effect on player
        val qiEffect = qiArrivalEffect(state.player, location.qiQuality)
        if (qiEffect.isNotEmpty()) log += LogEntry(qiEffect, LogType.CULTIVATION)

        return log
    }

    private fun qiArrivalEffect(p: Player, quality: QiQuality): String = when (quality) {
        QiQuality.HEAVENLY -> {
            p.qi = (p.qi + p.maxQi / 5).coerceAtMost(p.maxQi)
            "Heavenly Qi floods your meridians the moment you arrive. +${p.maxQi / 5} Qi."
        }
        QiQuality.CORRUPTED -> {
            p.innerDemonLevel = (p.innerDemonLevel + 5).coerceAtMost(100)
            "Corrupted Qi presses against your mental defenses immediately. +5 Inner Demon."
        }
        QiQuality.ANCIENT -> {
            p.daoHeart = (p.daoHeart + 3).coerceAtMost(100)
            "Ancient Qi carries memory and weight. Your Dao Heart steadies in response."
        }
        QiQuality.VIOLENT -> {
            p.daoHeart = (p.daoHeart - 2).coerceAtLeast(0)
            "Violent Qi batters your spiritual senses. Your Dao Heart is unsettled."
        }
        else -> ""
    }

    private fun qiQualityDesc(q: QiQuality) = when (q) {
        QiQuality.THIN -> "Thin"; QiQuality.NORMAL -> "Normal"; QiQuality.RICH -> "Rich"
        QiQuality.DENSE -> "Dense"; QiQuality.ANCIENT -> "Ancient"; QiQuality.CORRUPTED -> "Corrupted"
        QiQuality.HEAVENLY -> "Heavenly"; QiQuality.VIOLENT -> "Violent"
    }

    // ── AVAILABLE DESTINATIONS ────────────────────────────────────────────────

    fun availableFrom(currentId: String): List<Location> =
        ALL_LOCATIONS.values.filter { it.id != currentId }
}
