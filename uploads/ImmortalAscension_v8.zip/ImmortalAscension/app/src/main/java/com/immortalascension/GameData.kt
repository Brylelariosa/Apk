package com.immortalascension

import kotlin.random.Random

// ─── REALMS ───────────────────────────────────────────────────────────────────

enum class RealmTier(
    val display: String,
    val stages: Int,
    val qiBase: Int,
    val hpBonus: Int,
    val atkBonus: Int,
    val defBonus: Int
) {
    MORTAL("Mortal", 1, 0, 0, 0, 0),
    QI_GATHERING("Qi Gathering", 9, 300, 15, 3, 2),
    FOUNDATION("Foundation Building", 4, 3000, 80, 15, 8),
    CORE_FORMATION("Core Formation", 3, 30000, 400, 60, 30),
    NASCENT_SOUL("Nascent Soul", 3, 300000, 1500, 250, 120),
    SPIRIT_SEVERING("Spirit Severing", 3, 3000000, 6000, 1000, 500),
}

data class Realm(val tier: RealmTier, val stage: Int) {
    val display: String get() = when {
        tier == RealmTier.MORTAL -> "Mortal"
        tier.stages == 1 -> tier.display
        else -> "${tier.display} — Stage $stage"
    }
    val qiCap: Int get() = (tier.qiBase * stage).coerceAtLeast(200)
    val power: Int get() = tier.ordinal * 100 + stage * 10
    fun next(): Realm? {
        if (stage < tier.stages) return Realm(tier, stage + 1)
        val nextTier = RealmTier.values().getOrNull(tier.ordinal + 1) ?: return null
        return Realm(nextTier, 1)
    }
    fun dominates(other: Realm): Int = power - other.power
}

// ─── TECHNIQUES ───────────────────────────────────────────────────────────────

enum class TechElement { NONE, FIRE, WATER, LIGHTNING, WIND, EARTH, ICE, VOID, WOOD }
enum class TechEffect  { NONE, STUN, BURN, BLEED, WEAKEN, SHIELD, HASTE }
enum class TechniqueType { ATTACK, DEFENSE, SUPPORT, MOVEMENT }

data class TechUsageProfile(
    var offensiveUses: Int = 0,
    var defensiveUses: Int = 0,
    var killFinishes: Int = 0
)

data class Technique(
    val id: String,
    val name: String,
    val desc: String,
    val type: TechniqueType = TechniqueType.ATTACK,
    val element: TechElement = TechElement.NONE,
    val qiCost: Int = 0,
    val damage: Int = 0,
    val healAmount: Int = 0,
    val effect: TechEffect = TechEffect.NONE,
    val effectChance: Float = 0f,
    val effectDuration: Int = 0,
    val cooldownMax: Int = 0,
    var cooldown: Int = 0,
    var mastery: Int = 0,
    var evolutionPath: String = "",
    val usageProfile: TechUsageProfile = TechUsageProfile()
) {
    val effectiveDamage: Int get() = damage + (mastery / 8) + if (evolutionPath == "Killing") mastery / 5 else 0
    val masteryBonus: Float get() = 1f + mastery * 0.003f
    val evolvedName: String get() = when (evolutionPath) {
        "Killing"    -> "[$name · Killing Path]"
        "Guardian"   -> "[$name · Guardian Path]"
        "Enlightened"-> "[$name · Enlightened]"
        else -> name
    }
}

// ─── ITEMS ────────────────────────────────────────────────────────────────────

enum class ItemType { PILL, WEAPON, ARMOR, MATERIAL, TECHNIQUE_SCROLL, ARTIFACT }

data class Item(
    val id: String,
    val name: String,
    val desc: String,
    val type: ItemType,
    val value: Int = 0,
    val hpRestore: Int = 0,
    val qiRestore: Int = 0,
    val atkBonus: Int = 0,
    val defBonus: Int = 0,
    val maxHpBonus: Int = 0,
    val maxQiBonus: Int = 0,
    val daoHeartBonus: Int = 0,
    val innerDemonReduce: Int = 0,
    val breakthroughBonus: Float = 0f,
    val linkedTechId: String = "",
    var quantity: Int = 1,
    var equipped: Boolean = false
)

// ─── LOCATIONS ────────────────────────────────────────────────────────────────

enum class QiQuality { THIN, NORMAL, RICH, DENSE, ANCIENT, CORRUPTED, HEAVENLY, VIOLENT }

data class Location(
    val id: String,
    val name: String,
    val desc: String,
    val qiQuality: QiQuality = QiQuality.NORMAL,
    val dangerLevel: Int = 1,
    val minRealm: RealmTier = RealmTier.MORTAL,
    val cultivationBonus: Float = 1.0f,
    val hasShop: Boolean = false,
    val hasSect: Boolean = false,
    val travelHours: Int = 4,
    val flavorLines: List<String> = emptyList()
)

// ─── NPCS ─────────────────────────────────────────────────────────────────────

enum class NPCPersonality { COLD, WARM, ARROGANT, HUMBLE, CUNNING, RIGHTEOUS, CHAOTIC, MELANCHOLY }
enum class NPCDisposition { HOSTILE, WARY, NEUTRAL, FRIENDLY, DEVOTED }

enum class NPCActivity {
    IDLE, CULTIVATING, TRAVELING, HUNTING, TRADING, SEEKING_SECT,
    SEEKING_REVENGE, FORMING_ALLIANCE, EXPLORING, IN_SECLUSION, DUELING
}

data class NPCRelationship(
    val targetId: String,
    var score: Int = 0,
    var isRival: Boolean = false,
    var isAlly: Boolean = false,
    var isMaster: Boolean = false,
    var isDisciple: Boolean = false
)

data class NPC(
    val id: String,
    val name: String,
    var realm: Realm,
    val personality: NPCPersonality,
    val goals: MutableList<String> = mutableListOf(),
    var relationship: Int = 0,
    var alive: Boolean = true,
    var metPlayer: Boolean = false,
    var disposition: NPCDisposition = NPCDisposition.NEUTRAL,
    var currentLocation: String = "",
    var destinationLocation: String = "",
    var daysAlive: Int = 0,
    var daysInLocation: Int = 0,
    var activity: NPCActivity = NPCActivity.IDLE,
    var activityDaysLeft: Int = 0,
    var qi: Int = 0,
    var maxQi: Int = 100,
    var hp: Int = 100,
    var maxHp: Int = 100,
    var sectId: String = "",
    var spiritStones: Int = 0,
    var kills: Int = 0,
    var breakthroughsAttempted: Int = 0,
    var isRogue: Boolean = false,
    var isDemonic: Boolean = false,
    var npcRelationships: MutableList<NPCRelationship> = mutableListOf(),
    var techniques: MutableList<String> = mutableListOf(),
    var lifeEvents: MutableList<String> = mutableListOf(),
    val backstory: String = "",
    val deathNote: String = ""
)

// ─── SECTS ────────────────────────────────────────────────────────────────────

enum class SectRank(val display: String, val contributionRequired: Int) {
    OUTER("Outer Disciple", 0),
    INNER("Inner Disciple", 200),
    CORE("Core Disciple", 1000),
    ELDER("Elder", 5000),
    SECT_MASTER("Sect Master", 20000)
}

data class Sect(
    val id: String,
    val name: String,
    val desc: String,
    val element: TechElement,
    val locationId: String,
    val joinBonus: String = "",
    val rivalSectId: String = ""
)

data class SectMembership(
    val sectId: String,
    var rank: SectRank = SectRank.OUTER,
    var contribution: Int = 0,
    var missionsCompleted: Int = 0,
    var standing: Int = 50
)

data class SectMission(
    val id: String,
    val title: String,
    val desc: String,
    val type: MissionType,
    val targetId: String = "",
    val targetCount: Int = 1,
    var progress: Int = 0,
    val contribution: Int,
    val stoneReward: Int,
    var accepted: Boolean = false,
    var completed: Boolean = false
)

enum class MissionType { KILL_ENEMY, CULTIVATE_DAYS, EXPLORE_LOCATION, REACH_REALM, SPIRIT_STONE_TITHE }

// ─── WORLD EVENTS ─────────────────────────────────────────────────────────────

data class WorldEvent(
    val id: String,
    val title: String,
    val desc: String,
    val type: WorldEventType,
    var active: Boolean = true,
    var daysRemaining: Int = 30,
    val playerOpportunity: String = ""
)

enum class WorldEventType {
    SECT_WAR, DEMON_INVASION, SECRET_REALM, HEAVENLY_PHENOMENON,
    BEAST_TIDE, ANCIENT_TOMB, GRAND_AUCTION, CELESTIAL_EVENT
}

// ─── PLAYER ───────────────────────────────────────────────────────────────────

data class Player(
    var name: String = "Unnamed",
    var realm: Realm = Realm(RealmTier.QI_GATHERING, 1),
    var hp: Int = 150,
    var maxHp: Int = 150,
    var qi: Int = 0,
    var maxQi: Int = 300,
    var attack: Int = 14,
    var defense: Int = 6,
    var speed: Int = 12,
    var spirit: Int = 10,
    var comprehension: Int = 14,
    var luck: Int = 10,
    var daoHeart: Int = 40,
    var innerDemonLevel: Int = 0,
    var spiritStones: Int = 15,
    var techniques: MutableList<Technique> = mutableListOf(),
    var inventory: MutableList<Item> = mutableListOf(),
    var equippedWeapon: Item? = null,
    var equippedArmor: Item? = null,
    var titles: MutableList<String> = mutableListOf(),
    var karma: Int = 0,
    var cultivationDays: Int = 0,
    var kills: Int = 0,
    var battlesWon: Int = 0,
    var daoInsights: MutableList<String> = mutableListOf(),
    var mentalScars: MutableList<String> = mutableListOf(),
    var daoPath: String = "",
    var bodyRefinementLevel: Int = 0,
    var fateless: Boolean = false
) {
    val hpPercent: Float get() = hp.toFloat() / maxHp
    val qiPercent: Float get() = qi.toFloat() / maxQi
    val isAlive: Boolean get() = hp > 0
    val totalAttack: Int get() = attack + (equippedWeapon?.atkBonus ?: 0)
    val totalDefense: Int get() = defense + (equippedArmor?.defBonus ?: 0)
    val karmaTitle: String get() = when {
        karma > 80 -> "Righteous Saint"; karma > 40 -> "Righteous Cultivator"
        karma > 10 -> "Neutral";         karma > -10 -> "Neutral"
        karma > -40 -> "Gray Path Walker"; karma > -80 -> "Demonic Cultivator"
        else -> "Demon Lord"
    }
}

// ─── ENEMIES ──────────────────────────────────────────────────────────────────

enum class EnemyBehavior { AGGRESSIVE, CAUTIOUS, TACTICAL, BERSERKER }

data class Enemy(
    val name: String,
    val realm: Realm,
    var hp: Int,
    val maxHp: Int,
    val attack: Int,
    val defense: Int,
    val speed: Int,
    val behavior: EnemyBehavior = EnemyBehavior.AGGRESSIVE,
    val lootStones: IntRange = 0..2,
    val lootDesc: String = "",
    val killDesc: String = "",
    var stunned: Boolean = false,
    var weakened: Boolean = false,
    var weakenedTurns: Int = 0,
    val lootItems: List<Item> = emptyList()
)

// ─── WORLD ────────────────────────────────────────────────────────────────────

data class WorldState(
    var year: Int = 1,
    var month: Int = 3,
    var day: Int = 1,
    var hour: Int = 7,
    var location: String = "Azure Wind Village",
    var locationId: String = "azure_wind_village",
    var weather: String = "Clear",
    var season: String = "Spring",
    var discoveredPlaces: MutableList<String> = mutableListOf("azure_wind_village"),
    var activeEvents: MutableList<WorldEvent> = mutableListOf(),
    var eventHistory: MutableList<String> = mutableListOf(),
    var daysSinceLastWorldEvent: Int = 0
) {
    val timeDisplay: String get() = "Year $year · ${monthName(month)} $day · $timeOfDay"
    val timeOfDay: String get() = when (hour) {
        in 5..7 -> "Dawn"; in 8..11 -> "Morning"; in 12..13 -> "Noon"
        in 14..17 -> "Afternoon"; in 18..20 -> "Dusk"; in 21..23 -> "Night"
        else -> "Midnight"
    }
    private fun monthName(m: Int) = listOf("","Frost","Plum","Jade","Fire","Lotus","Vermillion",
        "Golden","Harvest","Chrysanthemum","Cold","Bitter","Iron")[m.coerceIn(1,12)] + " Moon"

    fun advance(hours: Int) {
        hour += hours
        while (hour >= 24) { hour -= 24; day++; daysSinceLastWorldEvent++ }
        while (day > 30) { day -= 30; month++ }
        while (month > 12) { month -= 12; year++ }
        season = when (month) { in 3..5->"Spring"; in 6..8->"Summer"; in 9..11->"Autumn"; else->"Winter" }
        if (Random.nextInt(8) == 0) weather = listOf("Clear","Cloudy","Misty","Rainy","Stormy","Serene").random()
        activeEvents.forEach { it.daysRemaining-- }
        activeEvents.removeAll { it.daysRemaining <= 0 }
    }
}

// ─── COMBAT ───────────────────────────────────────────────────────────────────

data class CombatState(
    val enemy: Enemy,
    var round: Int = 1,
    var playerEffects: MutableList<Pair<TechEffect, Int>> = mutableListOf(),
    var finished: Boolean = false,
    var playerWon: Boolean = false,
    var shieldActive: Boolean = false,
    var hasteActive: Boolean = false
)

// ─── GAME STATE ───────────────────────────────────────────────────────────────

data class GameState(
    var player: Player = Player(),
    var world: WorldState = WorldState(),
    var combat: CombatState? = null,
    var npcs: MutableList<NPC> = mutableListOf(),
    var sectMembership: SectMembership? = null,
    var activeMissions: MutableList<SectMission> = mutableListOf(),
    var worldNews: MutableList<WorldNewsEntry> = mutableListOf(),
    var log: MutableList<LogEntry> = mutableListOf(),
    var started: Boolean = false,
    var gameOver: Boolean = false
)

data class LogEntry(val text: String, val type: LogType = LogType.NORMAL)

enum class LogType { NORMAL, SYSTEM, COMBAT, EVENT, BREAKTHROUGH, CULTIVATION, DANGER, NPC, SECT, WORLD }
