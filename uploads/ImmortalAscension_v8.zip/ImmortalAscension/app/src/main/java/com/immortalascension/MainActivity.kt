package com.immortalascension

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.immortalascension.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val engine = GameEngine()
    private val logAdapter = LogAdapter()

    // ── LIFECYCLE ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupLog()
        setupEngineCallbacks()
        showMainMenu()
    }

    override fun onPause() {
        super.onPause()
        if (engine.state.started) SaveSystem.save(this, engine)
    }

    // ── LOG ───────────────────────────────────────────────────────────────────

    private fun setupLog() {
        binding.rvLog.apply {
            layoutManager = LinearLayoutManager(this@MainActivity).also { it.stackFromEnd = true }
            adapter = logAdapter
        }
    }

    // ── ENGINE CALLBACKS ──────────────────────────────────────────────────────

    private fun setupEngineCallbacks() {
        engine.onLogUpdate = { entries ->
            runOnUiThread {
                entries.forEach { logAdapter.addEntry(it) }
                binding.rvLog.scrollToPosition(logAdapter.itemCount - 1)
            }
        }
        engine.onStateChange = { runOnUiThread { updateStatsUI(); updateActionButtons() } }
        engine.onCombatStart = { _ -> runOnUiThread { flashBackground("#3A1010"); vibrate(80); showCombatButtons() } }
        engine.onCombatEnd   = { _ -> runOnUiThread { showMainButtons() } }
        engine.onBreakthrough= { _ -> runOnUiThread { flashBackground("#1A1A00"); vibrate(250) } }
        engine.onGameOver    = { runOnUiThread { showGameOver() } }
        engine.onWorldEvent  = { event -> runOnUiThread { flashBackground("#001A1A"); showWorldEventBanner(event) } }
        engine.onWorldNews   = { news  -> runOnUiThread { showWorldNewsBadge(news) } }
    }

    // ── MAIN MENU ─────────────────────────────────────────────────────────────

    private fun showMainMenu() {
        binding.layoutGame.visibility = android.view.View.GONE
        binding.layoutMenu.visibility = android.view.View.VISIBLE

        binding.btnContinue.isEnabled = SaveSystem.hasSave(this)
        binding.btnContinue.alpha     = if (SaveSystem.hasSave(this)) 1f else 0.4f

        binding.btnNewGame.setOnClickListener { showNewGameDialog() }
        binding.btnContinue.setOnClickListener {
            val saved = SaveSystem.load(this) ?: return@setOnClickListener
            engine.state = saved
            logAdapter.setEntries(engine.state.log)
            binding.layoutMenu.visibility = android.view.View.GONE
            binding.layoutGame.visibility = android.view.View.VISIBLE
            updateStatsUI()
            updateActionButtons()
            if (engine.state.combat != null) showCombatButtons() else showMainButtons()
            binding.rvLog.scrollToPosition(logAdapter.itemCount - 1)
        }
    }

    private fun showNewGameDialog() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 32, 48, 16)
        }
        val nameInput = EditText(this).apply {
            hint = "Your name"
            setHintTextColor(Color.parseColor("#5A5A4A"))
            setTextColor(Color.parseColor("#E8D5A3"))
            background = null
            textSize = 16f
        }
        val fatelessCheck = CheckBox(this).apply {
            text = "Walk the Fateless Path (harder, unlimited potential)"
            setTextColor(Color.parseColor("#C85A5A"))
            textSize = 13f
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.parseColor("#C85A5A"))
        }
        layout.addView(nameInput)
        layout.addView(fatelessCheck)

        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Begin Cultivation")
            .setView(layout)
            .setPositiveButton("Begin") { _, _ ->
                binding.layoutMenu.visibility = android.view.View.GONE
                binding.layoutGame.visibility = android.view.View.VISIBLE
                engine.newGame(nameInput.text.toString().trim(), fatelessCheck.isChecked)
                showMainButtons()
            }
            .setNegativeButton("Back", null)
            .show()
    }

    // ── STATS BAR ─────────────────────────────────────────────────────────────

    private fun updateStatsUI() {
        val p = engine.state.player
        val w = engine.state.world

        binding.tvRealm.text  = p.realm.display
        binding.tvTime.text   = w.timeDisplay
        binding.tvStones.text = "◈ ${p.spiritStones}"

        binding.progressHp.progress = (p.hpPercent * 100).toInt()
        binding.tvHp.text = "${p.hp}/${p.maxHp}"

        binding.progressQi.progress = (p.qiPercent * 100).toInt()
        binding.tvQi.text = "${p.qi}/${p.maxQi}"

        binding.tvBreakthroughHint.visibility =
            if (p.qi >= p.maxQi) android.view.View.VISIBLE else android.view.View.GONE

        val cs = engine.state.combat
        if (cs != null) {
            binding.tvEnemyStatus.visibility    = android.view.View.VISIBLE
            binding.progressEnemyHp.visibility  = android.view.View.VISIBLE
            binding.tvEnemyStatus.text = "${cs.enemy.name}  ❤ ${cs.enemy.hp}/${cs.enemy.maxHp}  Rd ${cs.round}"
            binding.progressEnemyHp.progress = (cs.enemy.hp.toFloat() / cs.enemy.maxHp * 100).toInt()
        } else {
            binding.tvEnemyStatus.visibility   = android.view.View.GONE
            binding.progressEnemyHp.visibility = android.view.View.GONE
        }

        // Active world events badge
        val events = engine.state.world.activeEvents
        binding.btnWorldEvents.text = if (events.isEmpty()) "WORLD" else "WORLD (${events.size})"
    }

    // ── BUTTON VISIBILITY ─────────────────────────────────────────────────────

    private fun showMainButtons() {
        binding.layoutCombatButtons.visibility = android.view.View.GONE
        binding.layoutMainButtons.visibility   = android.view.View.VISIBLE
        updateActionButtons()
    }

    private fun showCombatButtons() {
        binding.layoutMainButtons.visibility   = android.view.View.GONE
        binding.layoutCombatButtons.visibility = android.view.View.VISIBLE
        refreshCombatButtons()
    }

    private fun updateActionButtons() {
        val p  = engine.state.player
        val w  = engine.state.world
        binding.btnBreakthrough.alpha = if (p.qi >= p.maxQi) 1f else 0.45f

        // Sect button label
        val sm = engine.state.sectMembership
        binding.btnSect.text = if (sm != null) {
            val sname = SectSystem.SECTS[sm.sectId]?.name?.split(" ")?.first() ?: "Sect"
            "$sname\n${sm.rank.display.split(" ").first()}"
        } else "JOIN\nSECT"

        // Shop only at locations with shops
        val loc = LocationSystem.get(w.locationId)
        binding.btnShop.alpha = if (loc.hasShop) 1f else 0.4f
    }

    private fun refreshCombatButtons() {
        val p = engine.state.player
        p.techniques.getOrNull(0)?.let { t ->
            binding.btnTech1.text  = "${t.evolvedName.take(14)}\n(${t.qiCost}qi${if (t.cooldown > 0) " ⏳${t.cooldown}" else ""})"
            binding.btnTech1.alpha = if (t.cooldown > 0 || p.qi < t.qiCost) 0.45f else 1f
        }
        p.techniques.getOrNull(1)?.let { t ->
            binding.btnTech2.visibility = android.view.View.VISIBLE
            binding.btnTech2.text  = "${t.evolvedName.take(14)}\n(${t.qiCost}qi${if (t.cooldown > 0) " ⏳${t.cooldown}" else ""})"
            binding.btnTech2.alpha = if (t.cooldown > 0 || p.qi < t.qiCost) 0.45f else 1f
        } ?: run { binding.btnTech2.visibility = android.view.View.GONE }
        p.techniques.getOrNull(2)?.let { t ->
            binding.btnTech3.visibility = android.view.View.VISIBLE
            binding.btnTech3.text  = "${t.evolvedName.take(14)}\n(${t.qiCost}qi${if (t.cooldown > 0) " ⏳${t.cooldown}" else ""})"
            binding.btnTech3.alpha = if (t.cooldown > 0 || p.qi < t.qiCost) 0.45f else 1f
        } ?: run { binding.btnTech3.visibility = android.view.View.GONE }
    }

    // ── BUTTON WIRING (called once layout is inflated) ─────────────────────────

    override fun onStart() {
        super.onStart()
        wireButtons()
    }

    private fun wireButtons() {
        // Main
        binding.btnCultivate.setOnClickListener { engine.cultivate() }
        binding.btnExplore.setOnClickListener   { engine.explore() }
        binding.btnRest.setOnClickListener      { engine.rest() }
        binding.btnBreakthrough.setOnClickListener { engine.breakthrough() }
        binding.btnSeclusion.setOnClickListener { showSeclusionDialog() }
        binding.btnCharacter.setOnClickListener { showCharacterSheet() }
        binding.btnTravel.setOnClickListener    { showTravelDialog() }
        binding.btnInventory.setOnClickListener { showInventoryScreen() }
        binding.btnSect.setOnClickListener      { showSectScreen() }
        binding.btnWorldEvents.setOnClickListener { showWorldEventsScreen() }
        binding.btnShop.setOnClickListener      { showShopScreen() }

        // Combat
        binding.btnAttack.setOnClickListener  { engine.combatAttack(); refreshCombatButtons() }
        binding.btnTech1.setOnClickListener   { engine.combatTechnique(0); refreshCombatButtons() }
        binding.btnTech2.setOnClickListener   { engine.combatTechnique(1); refreshCombatButtons() }
        binding.btnTech3.setOnClickListener   { engine.combatTechnique(2); refreshCombatButtons() }
        binding.btnDefend.setOnClickListener  { engine.combatDefend(); refreshCombatButtons() }
        binding.btnFlee.setOnClickListener    { engine.combatFlee() }
        binding.btnUseItem.setOnClickListener { showCombatItemDialog() }
    }

    // ── CHARACTER SHEET ───────────────────────────────────────────────────────

    private fun showCharacterSheet() {
        val p  = engine.state.player
        val sb = StringBuilder()
        sb.appendLine("━━━ ${p.name} ━━━")
        sb.appendLine("${p.realm.display}  ·  ${p.karmaTitle}")
        if (p.daoPath.isNotEmpty()) sb.appendLine("Dao Path: ${p.daoPath}")
        if (p.fateless) sb.appendLine("[Fateless Path]")
        sb.appendLine()
        sb.appendLine("HP  ${p.hp}/${p.maxHp}     Qi  ${p.qi}/${p.maxQi}")
        sb.appendLine("ATK ${p.totalAttack}  DEF ${p.totalDefense}  SPD ${p.speed}  SPR ${p.spirit}")
        sb.appendLine("Comprehension ${p.comprehension}  Luck ${p.luck}")
        sb.appendLine("Dao Heart ${p.daoHeart}/100  Inner Demon ${p.innerDemonLevel}/100")
        if (p.bodyRefinementLevel > 0) sb.appendLine("Body Refinement: Rank ${p.bodyRefinementLevel}")
        sb.appendLine()
        sb.appendLine("Spirit Stones: ${p.spiritStones}")
        sb.appendLine("Kills ${p.kills}  Battles Won ${p.battlesWon}  Days Cultivated ${p.cultivationDays}")
        sb.appendLine("Karma: ${p.karma}")
        sb.appendLine()

        if (p.equippedWeapon != null || p.equippedArmor != null) {
            sb.appendLine("── Equipped ──")
            p.equippedWeapon?.let { sb.appendLine("Weapon: ${it.name} (+${it.atkBonus} ATK)") }
            p.equippedArmor?.let  { sb.appendLine("Armor:  ${it.name} (+${it.defBonus} DEF)") }
            sb.appendLine()
        }

        if (p.techniques.isNotEmpty()) {
            sb.appendLine("── Techniques ──")
            p.techniques.forEach { t ->
                sb.appendLine("${t.evolvedName}  [Mastery ${t.mastery}%]")
                sb.appendLine("  ${t.desc}")
                sb.appendLine("  Qi:${t.qiCost}  Dmg:${t.effectiveDamage}  CD:${t.cooldownMax}")
            }
            sb.appendLine()
        }

        if (p.titles.isNotEmpty()) {
            sb.appendLine("── Titles ──")
            p.titles.forEach { sb.appendLine("「$it」") }
            sb.appendLine()
        }

        if (p.daoInsights.isNotEmpty()) {
            sb.appendLine("── Dao Insights ──")
            p.daoInsights.forEach { sb.appendLine("\"$it\"") }
            sb.appendLine()
        }

        if (p.mentalScars.isNotEmpty()) {
            sb.appendLine("── Mental Scars ──")
            p.mentalScars.forEach { sb.appendLine("• $it") }
            sb.appendLine()
        }

        val opts = if (p.daoPath.isEmpty()) arrayOf("Choose Dao Path", "Close") else arrayOf("Close")
        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Character")
            .setMessage(sb.toString())
            .setItems(opts) { _, i ->
                if (opts[i] == "Choose Dao Path") showDaoPathDialog()
            }
            .show()
    }

    // ── DAO PATH ──────────────────────────────────────────────────────────────

    private fun showDaoPathDialog() {
        if (engine.state.player.daoPath.isNotEmpty()) return
        val paths = arrayOf("Sword Dao","Body Dao","Freedom Dao","Destruction Dao","Silence Dao","Samsara Dao")
        val descs = arrayOf(
            "Attack +8, Speed +3. The path of the sword.",
            "Max HP +100, Defense +5, Body Refinement 1. The path of the flesh.",
            "Luck +5, Speed +5. The path of no path.",
            "Attack +12, Dao Heart -10. Power at cost.",
            "Spirit +8, Comprehension +3. The path of stillness.",
            "Dao Heart +15, Comprehension +2. The path of cycles."
        )
        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Choose Your Dao Path")
            .setMessage("This choice is permanent. Your Dao will shape your entire cultivation.\n\n" +
                paths.zip(descs).joinToString("\n\n") { (p, d) -> "▸ $p\n  $d" })
            .setItems(paths) { _, i -> engine.chooseDaoPath(paths[i]) }
            .setNegativeButton("Not yet", null)
            .show()
    }

    // ── TRAVEL ────────────────────────────────────────────────────────────────

    private fun showTravelDialog() {
        val currentId   = engine.state.world.locationId
        val destinations = LocationSystem.availableFrom(currentId)
        val discovered   = engine.state.world.discoveredPlaces

        val labels = destinations.map { loc ->
            val known  = discovered.contains(loc.id)
            val danger = "⚔".repeat(loc.dangerLevel / 2 + 1)
            val qi     = loc.qiQuality.name.lowercase().replaceFirstChar { it.uppercase() }
            val tag    = if (!known) "  [Unexplored]" else ""
            "${loc.name}$tag\n  $danger  Qi: $qi  Travel: ${loc.travelHours}h"
        }.toTypedArray()

        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Travel — Current: ${engine.state.world.location}")
            .setItems(labels) { _, i ->
                val loc = destinations[i]
                val (canGo, reason) = LocationSystem.canTravel(engine.state.player, loc)
                if (!canGo) {
                    AlertDialog.Builder(this, R.style.CultivationDialog)
                        .setMessage(reason).setPositiveButton("Ok", null).show()
                } else {
                    engine.travelTo(loc.id)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── INVENTORY ─────────────────────────────────────────────────────────────

    private fun showInventoryScreen() {
        val p = engine.state.player
        if (p.inventory.isEmpty()) {
            AlertDialog.Builder(this, R.style.CultivationDialog)
                .setTitle("Inventory")
                .setMessage("Your storage ring is empty.")
                .setPositiveButton("Close", null).show()
            return
        }

        val labels = p.inventory.map { item ->
            val qty    = if (item.quantity > 1) " ×${item.quantity}" else ""
            val equip  = if (item.equipped) " [Equipped]" else ""
            "${item.name}$qty$equip\n  ${item.desc.take(55)}"
        }.toTypedArray()

        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Inventory  ◈ ${p.spiritStones} stones")
            .setItems(labels) { _, i ->
                val item = p.inventory.getOrNull(i) ?: return@setItems
                showItemDetail(item, i)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showItemDetail(item: Item, index: Int) {
        val sb = StringBuilder()
        sb.appendLine(item.name)
        sb.appendLine(item.desc)
        sb.appendLine()
        if (item.hpRestore > 0)       sb.appendLine("Restores: ${item.hpRestore} HP")
        if (item.qiRestore > 0)       sb.appendLine("Restores: ${item.qiRestore} Qi")
        if (item.atkBonus > 0)        sb.appendLine("Attack: +${item.atkBonus}")
        if (item.defBonus > 0)        sb.appendLine("Defense: +${item.defBonus}")
        if (item.maxHpBonus > 0)      sb.appendLine("Max HP: +${item.maxHpBonus}")
        if (item.maxQiBonus > 0)      sb.appendLine("Max Qi: +${item.maxQiBonus}")
        if (item.daoHeartBonus > 0)   sb.appendLine("Dao Heart: +${item.daoHeartBonus}")
        if (item.innerDemonReduce>0)  sb.appendLine("Inner Demon: -${item.innerDemonReduce}")
        if (item.breakthroughBonus>0) sb.appendLine("Breakthrough Bonus: +${(item.breakthroughBonus*100).toInt()}%")
        sb.appendLine()
        sb.appendLine("Value: ${item.value} spirit stones")

        val actionLabel = when (item.type) {
            ItemType.PILL, ItemType.ARTIFACT -> "Use"
            ItemType.WEAPON, ItemType.ARMOR  -> if (item.equipped) "Equipped" else "Equip"
            ItemType.TECHNIQUE_SCROLL        -> "Study Scroll"
            ItemType.MATERIAL                -> "Sell (${item.value} stones)"
        }

        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle(item.name)
            .setMessage(sb.toString())
            .setPositiveButton(actionLabel) { _, _ ->
                if (item.type == ItemType.MATERIAL) {
                    engine.state.player.spiritStones += item.value
                    InventorySystem.removeOrDecrement(engine.state.player, item)
                    engine.onStateChange?.invoke()
                } else {
                    engine.useItem(index)
                }
            }
            .setNegativeButton("Back", null)
            .show()
    }

    private fun showCombatItemDialog() {
        val p     = engine.state.player
        val pills = p.inventory.filter { it.type == ItemType.PILL }
        if (pills.isEmpty()) {
            AlertDialog.Builder(this, R.style.CultivationDialog)
                .setMessage("You have no pills to use.")
                .setPositiveButton("Ok", null).show()
            return
        }
        val labels = pills.map { "${it.name} ×${it.quantity}\n  HP+${it.hpRestore}  Qi+${it.qiRestore}" }.toTypedArray()
        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Use Pill (costs one turn)")
            .setItems(labels) { _, i ->
                val pill = pills.getOrNull(i) ?: return@setItems
                val idx  = p.inventory.indexOf(pill)
                engine.useItemInCombat(idx)
                refreshCombatButtons()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── SHOP ──────────────────────────────────────────────────────────────────

    private fun showShopScreen() {
        val loc = LocationSystem.get(engine.state.world.locationId)
        if (!loc.hasShop) {
            AlertDialog.Builder(this, R.style.CultivationDialog)
                .setMessage("There is no shop at ${loc.name}.")
                .setPositiveButton("Ok", null).show()
            return
        }
        val stock  = InventorySystem.shopStockFor(engine.state.world.locationId)
        val labels = stock.map { "${it.name}\n  ${it.desc.take(50)}\n  Cost: ${it.value} ◈" }.toTypedArray()

        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Shop  ◈ ${engine.state.player.spiritStones} stones")
            .setItems(labels) { _, i ->
                val item = stock.getOrNull(i) ?: return@setItems
                AlertDialog.Builder(this, R.style.CultivationDialog)
                    .setMessage("Buy ${item.name} for ${item.value} spirit stones?")
                    .setPositiveButton("Buy") { _, _ -> engine.shopBuy(item) }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Leave", null)
            .show()
    }

    // ── SECT ──────────────────────────────────────────────────────────────────

    private fun showSectScreen() {
        val sm = engine.state.sectMembership

        if (sm == null) {
            // Show sect joining options
            val sects  = SectSystem.SECTS.values.toList()
            val labels = sects.map { s ->
                "${s.name}\n  ${s.desc.take(70)}\n  Bonus: ${s.joinBonus.take(50)}"
            }.toTypedArray()

            AlertDialog.Builder(this, R.style.CultivationDialog)
                .setTitle("Join a Sect")
                .setMessage("Joining a sect unlocks missions, techniques, and rank progression.\nYou must be at the sect's location to join.")
                .setItems(labels) { _, i ->
                    val sect = sects.getOrNull(i) ?: return@setItems
                    if (engine.state.world.locationId != sect.locationId) {
                        AlertDialog.Builder(this, R.style.CultivationDialog)
                            .setMessage("You must travel to ${sect.name} before joining.")
                            .setPositiveButton("Ok", null).show()
                    } else {
                        AlertDialog.Builder(this, R.style.CultivationDialog)
                            .setTitle("Join ${sect.name}?")
                            .setMessage(sect.desc + "\n\nJoining bonus: ${sect.joinBonus}")
                            .setPositiveButton("Swear the Oath") { _, _ -> engine.joinSect(sect.id) }
                            .setNegativeButton("Decline", null).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
            return
        }

        // Show sect membership details
        val sect     = SectSystem.SECTS[sm.sectId]!!
        val missions = engine.state.activeMissions
        val sb       = StringBuilder()
        sb.appendLine("${sect.name}")
        sb.appendLine("Rank: ${sm.rank.display}")
        sb.appendLine("Contribution: ${sm.contribution}  Standing: ${sm.standing}/100")
        sb.appendLine("Missions completed: ${sm.missionsCompleted}")
        sb.appendLine()
        sb.appendLine("Next rank at: ${SectRank.values().getOrNull(sm.rank.ordinal + 1)?.contributionRequired ?: "MAX"} contribution")
        sb.appendLine()
        sb.appendLine(SectSystem.rankBenefitDesc(sm.rank))
        sb.appendLine()
        sb.appendLine("── Active Missions ──")
        if (missions.isEmpty()) sb.appendLine("No active missions.")
        missions.forEachIndexed { i, m ->
            val done = if (m.completed) "✓" else "${m.progress}/${m.targetCount}"
            sb.appendLine("${i+1}. ${m.title}  [$done]")
            sb.appendLine("   ${m.desc}")
            sb.appendLine("   Reward: +${m.contribution} contribution  +${m.stoneReward} stones")
        }

        val opts = buildList {
            missions.filter { !it.completed && it.type == MissionType.SPIRIT_STONE_TITHE }
                .forEach { add("Pay Tithe: ${it.title}") }
            add("Leave Sect")
            add("Close")
        }.toTypedArray()

        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Sect")
            .setMessage(sb.toString())
            .setItems(opts) { _, i ->
                when {
                    opts[i] == "Close" -> {}
                    opts[i] == "Leave Sect" -> {
                        AlertDialog.Builder(this, R.style.CultivationDialog)
                            .setTitle("Leave ${sect.name}?")
                            .setMessage("This cannot be undone easily. Your standing determines the consequence.")
                            .setPositiveButton("Leave") { _, _ -> engine.leaveSect() }
                            .setNegativeButton("Stay", null).show()
                    }
                    opts[i].startsWith("Pay Tithe") -> {
                        val mIdx = engine.state.activeMissions.indexOfFirst {
                            !it.completed && it.type == MissionType.SPIRIT_STONE_TITHE
                        }
                        if (mIdx >= 0) engine.titheForMission(mIdx)
                    }
                }
            }
            .show()
    }

    // ── WORLD EVENTS ──────────────────────────────────────────────────────────

    private fun showWorldEventsScreen() {
        val tabs = arrayOf("World Events", "World News", "NPC Tracker")
        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("The Living World")
            .setItems(tabs) { _, i -> when (i) {
                0 -> showActiveWorldEvents()
                1 -> showWorldNewsLog()
                2 -> showNPCTracker()
            }}
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showActiveWorldEvents() {
        val world  = engine.state.world
        val sb     = StringBuilder()
        if (world.activeEvents.isEmpty()) {
            sb.appendLine("The world is quiet. No major events active.")
        } else {
            world.activeEvents.forEach { e ->
                sb.appendLine("━━ ${e.title} ━━")
                sb.appendLine(e.desc)
                if (e.playerOpportunity.isNotEmpty()) sb.appendLine("↳ ${e.playerOpportunity}")
                sb.appendLine("Time remaining: ${e.daysRemaining} days")
                sb.appendLine()
            }
        }
        if (world.eventHistory.isNotEmpty()) {
            sb.appendLine("── Historical Events ──")
            world.eventHistory.takeLast(6).forEach { sb.appendLine("• $it") }
        }
        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("World Events")
            .setMessage(sb.toString())
            .setPositiveButton("Back") { _, _ -> showWorldEventsScreen() }
            .show()
    }

    private fun showWorldNewsLog() {
        val news = engine.state.worldNews.takeLast(30).reversed()
        val sb   = StringBuilder()
        if (news.isEmpty()) {
            sb.appendLine("No notable events recorded yet.")
            sb.appendLine("Cultivate, travel, or rest — the world moves as you do.")
        } else {
            news.forEach { n ->
                val icon = when (n.type) {
                    WorldNewsType.DEATH        -> "☠"
                    WorldNewsType.BATTLE       -> "⚔"
                    WorldNewsType.ADVANCEMENT  -> "✦"
                    WorldNewsType.WENT_DEMONIC -> "⚠"
                    WorldNewsType.JOINED_SECT  -> "◈"
                    WorldNewsType.ALLIANCE     -> "♦"
                    WorldNewsType.DISCOVERY    -> "★"
                    WorldNewsType.MOVEMENT     -> "→"
                }
                sb.appendLine("$icon ${n.headline}")
                sb.appendLine("   ${n.detail}")
                sb.appendLine("   [${n.timestamp}]")
                sb.appendLine()
            }
        }
        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("World News")
            .setMessage(sb.toString())
            .setPositiveButton("Back") { _, _ -> showWorldEventsScreen() }
            .show()
    }

    private fun showNPCTracker() {
        val alive = engine.state.npcs.filter { it.alive }.sortedByDescending { it.realm.power }
        val sb    = StringBuilder()
        sb.appendLine("Living cultivators: ${alive.size}")
        sb.appendLine()

        val named  = alive.filter { !it.id.startsWith("npc_") }
        val random = alive.filter { it.id.startsWith("npc_") }

        if (named.isNotEmpty()) {
            sb.appendLine("── Known Figures ──")
            named.forEach { npc ->
                val actIcon = when (npc.activity) {
                    NPCActivity.CULTIVATING     -> "◉"; NPCActivity.HUNTING -> "⚔"
                    NPCActivity.TRAVELING       -> "→"; NPCActivity.IN_SECLUSION -> "◎"
                    NPCActivity.SEEKING_REVENGE -> "!"; NPCActivity.FORMING_ALLIANCE -> "♦"
                    NPCActivity.EXPLORING       -> "★"; NPCActivity.DUELING -> "⚡"
                    NPCActivity.TRADING         -> "◈"; else -> "·"
                }
                val tags = buildString {
                    if (npc.isDemonic) append(" [DEMONIC]")
                    if (npc.isRogue)   append(" [ROGUE]")
                }
                sb.appendLine("$actIcon ${npc.name}$tags")
                sb.appendLine("   ${npc.realm.display}  ·  ${LocationSystem.get(npc.currentLocation).name}")
                sb.appendLine("   Rel:${npc.relationship}  Stones:${npc.spiritStones}  Kills:${npc.kills}")
                if (npc.lifeEvents.isNotEmpty()) sb.appendLine("   → ${npc.lifeEvents.last()}")
                sb.appendLine()
            }
        }

        if (random.isNotEmpty()) {
            sb.appendLine("── Other Cultivators ──")
            val byLoc = random.groupBy { it.currentLocation }
            byLoc.forEach { (locId, locNPCs) ->
                val loc      = LocationSystem.get(locId)
                val demCount = locNPCs.count { it.isDemonic }
                val strongest = locNPCs.maxByOrNull { it.realm.power }
                sb.appendLine("${loc.name}: ${locNPCs.size}${if (demCount > 0) " ($demCount demonic)" else ""}")
                if (strongest != null)
                    sb.appendLine("   Strongest: ${strongest.name} [${strongest.realm.display}]")
            }
        }

        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("NPC Tracker")
            .setMessage(sb.toString())
            .setPositiveButton("Back") { _, _ -> showWorldEventsScreen() }
            .show()
    }

    private fun showWorldEventBanner(event: WorldEvent) {
        Toast.makeText(this, "⚡ ${event.title}", Toast.LENGTH_LONG).show()
    }

    private fun showWorldNewsBadge(news: List<WorldNewsEntry>) {
        if (news.isEmpty()) return
        val notable = news.firstOrNull {
            it.type == WorldNewsType.DEATH || it.type == WorldNewsType.WENT_DEMONIC ||
            it.type == WorldNewsType.ADVANCEMENT
        } ?: return
        val icon = when (notable.type) {
            WorldNewsType.DEATH        -> "☠"
            WorldNewsType.WENT_DEMONIC -> "⚠"
            WorldNewsType.ADVANCEMENT  -> "✦"
            else -> "·"
        }
        Toast.makeText(this, "$icon ${notable.headline}", Toast.LENGTH_LONG).show()
        binding.btnWorldEvents.text = "WORLD (!)"
    }

    // ── SECLUSION ─────────────────────────────────────────────────────────────

    private fun showSeclusionDialog() {
        val opts = arrayOf("3 Days", "7 Days", "30 Days", "100 Days", "365 Days", "1000 Days")
        val days = arrayOf(3, 7, 30, 100, 365, 1000)
        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Enter Seclusion")
            .setMessage("Time will pass. The world will change.\nYour inner demons may stir in the silence.")
            .setItems(opts) { _, i -> engine.longSeclusion(days[i]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── GAME OVER ─────────────────────────────────────────────────────────────

    private fun showGameOver() {
        val p = engine.state.player
        AlertDialog.Builder(this, R.style.CultivationDialog)
            .setTitle("Path Ended")
            .setMessage(
                "${p.name} has fallen.\n\n" +
                "Realm: ${p.realm.display}\n" +
                "Battles Won: ${p.battlesWon}\n" +
                "Days Cultivated: ${p.cultivationDays}\n" +
                "Spirit Stones: ${p.spiritStones}\n" +
                "Titles: ${p.titles.size}\n" +
                "Dao Insights: ${p.daoInsights.size}\n\n" +
                "\"Even the heavens bury the fallen eventually.\""
            )
            .setPositiveButton("Begin Anew") { _, _ ->
                SaveSystem.deleteSave(this)
                logAdapter.clear()
                showMainMenu()
            }
            .setCancelable(false)
            .show()
    }

    // ── VISUAL FX ─────────────────────────────────────────────────────────────

    private fun flashBackground(hex: String) {
        val base   = Color.parseColor("#0A0A0F")
        val target = Color.parseColor(hex)
        ValueAnimator.ofObject(ArgbEvaluator(), base, target, base).apply {
            duration = 600
            addUpdateListener { binding.root.setBackgroundColor(it.animatedValue as Int) }
            start()
        }
    }

    private fun vibrate(ms: Long) {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
            v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
    }
}

// ── LOG ADAPTER ───────────────────────────────────────────────────────────────

class LogAdapter : RecyclerView.Adapter<LogAdapter.VH>() {
    private val items = mutableListOf<LogEntry>()

    fun addEntry(e: LogEntry)             { items.add(e); notifyItemInserted(items.size - 1) }
    fun setEntries(es: List<LogEntry>)    { items.clear(); items.addAll(es); notifyDataSetChanged() }
    fun clear()                            { items.clear(); notifyDataSetChanged() }

    override fun onCreateViewHolder(parent: ViewGroup, vt: Int): VH {
        val tv = TextView(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setPadding(32, 5, 32, 5)
            textSize = 13.5f
            typeface = android.graphics.Typeface.SERIF
            setLineSpacing(4f, 1.1f)
        }
        return VH(tv)
    }

    override fun onBindViewHolder(h: VH, pos: Int) {
        val e = items[pos]
        h.tv.setTextColor(when (e.type) {
            LogType.SYSTEM      -> Color.parseColor("#7A9DBF")
            LogType.COMBAT      -> Color.parseColor("#D4956A")
            LogType.DANGER      -> Color.parseColor("#C85A5A")
            LogType.BREAKTHROUGH-> Color.parseColor("#FFD700")
            LogType.CULTIVATION -> Color.parseColor("#8FBC8F")
            LogType.EVENT       -> Color.parseColor("#B8A4D4")
            LogType.NPC         -> Color.parseColor("#AAC8D4")
            LogType.SECT        -> Color.parseColor("#D4AA70")
            LogType.WORLD       -> Color.parseColor("#70D4C8")
            LogType.NORMAL      -> Color.parseColor("#C8BC9E")
        })
        h.tv.text = e.text
    }

    override fun getItemCount() = items.size
    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)
}
