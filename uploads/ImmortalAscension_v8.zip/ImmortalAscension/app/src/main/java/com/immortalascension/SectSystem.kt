package com.immortalascension

import kotlin.random.Random

object SectSystem {

    // ── SECT CATALOG ──────────────────────────────────────────────────────────

    val SECTS = mapOf(
        "azure_mountain_sect" to Sect(
            id = "azure_mountain_sect",
            name = "Azure Mountain Sect",
            desc = "A three-thousand-year lineage built on Sword Dao and righteous cultivation. Strict but fair. Known for producing powerful sword cultivators and loyal warriors.",
            element = TechElement.WIND,
            locationId = "azure_mountain_sect",
            joinBonus = "You are granted the Azure Wind Sword Technique upon joining.",
            rivalSectId = "crimson_flame_sect"
        ),
        "crimson_flame_sect" to Sect(
            id = "crimson_flame_sect",
            name = "Crimson Flame Sect",
            desc = "Aggressive, ambitious, fire-focused. They believe strength justifies all. Their disciples advance fast and die young.",
            element = TechElement.FIRE,
            locationId = "crimson_flame_sect",
            joinBonus = "You receive the Crimson Burst Technique upon joining.",
            rivalSectId = "azure_mountain_sect"
        ),
        "silent_moon_pavilion" to Sect(
            id = "silent_moon_pavilion",
            name = "Silent Moon Pavilion",
            desc = "Reclusive alchemists and defensive cultivators. They value knowledge and longevity. Less powerful in open battle, far more dangerous in preparation.",
            element = TechElement.WATER,
            locationId = "silent_moon_pavilion",
            joinBonus = "You learn the Moon Reflection Sutra and receive three Minor Healing Pills."
        )
    )

    // ── SECT JOINING TECHNIQUES ───────────────────────────────────────────────

    val SECT_TECHNIQUES = mapOf(
        "azure_mountain_sect" to Technique(
            "azure_wind_sword", "Azure Wind Sword", "The fundamental sword technique of the Azure Mountain Sect. Fast, clean, decisive.",
            TechniqueType.ATTACK, TechElement.WIND, qiCost = 20, damage = 40, cooldownMax = 1
        ),
        "crimson_flame_sect" to Technique(
            "crimson_burst", "Crimson Burst", "A devastating fire technique that sacrifices defense for pure offense.",
            TechniqueType.ATTACK, TechElement.FIRE, qiCost = 30, damage = 65, effect = TechEffect.BURN,
            effectChance = 0.5f, effectDuration = 2, cooldownMax = 2
        ),
        "silent_moon_pavilion" to Technique(
            "moon_reflection", "Moon Reflection Sutra", "A water technique that deflects spiritual attacks and regenerates Qi.",
            TechniqueType.SUPPORT, TechElement.WATER, qiCost = 15, healAmount = 35,
            effect = TechEffect.SHIELD, effectChance = 0.6f, effectDuration = 2, cooldownMax = 3
        )
    )

    // ── MISSION POOL ──────────────────────────────────────────────────────────

    fun generateMissions(membership: SectMembership): List<SectMission> {
        val pool = mutableListOf<SectMission>()

        when (membership.rank) {
            SectRank.OUTER -> {
                pool += SectMission("m_kill_wolves", "Cull the Wolf Pack",
                    "Spirit wolves near the village are troubling farmers. Eliminate 5.",
                    MissionType.KILL_ENEMY, "wolf", 5, contribution = 30, stoneReward = 15)
                pool += SectMission("m_cultivate_5", "Five Days of Cultivation",
                    "Dedicate yourself to cultivation for 5 days to prove your commitment.",
                    MissionType.CULTIVATE_DAYS, targetCount = 5, contribution = 20, stoneReward = 10)
                pool += SectMission("m_explore_forest", "Patrol the Forest",
                    "Survey the Verdant Spirit Forest and report back. Explore and survive.",
                    MissionType.EXPLORE_LOCATION, "verdant_forest", 1, contribution = 25, stoneReward = 12)
                pool += SectMission("m_tithe_outer", "Spirit Stone Tithe",
                    "Contribute 20 spirit stones to the sect treasury.",
                    MissionType.SPIRIT_STONE_TITHE, targetCount = 20, contribution = 15, stoneReward = 5)
            }
            SectRank.INNER -> {
                pool += SectMission("m_kill_cultivators", "Eliminate Rogue Cultivators",
                    "Rogue cultivators have been attacking our outer disciples. Eliminate 3.",
                    MissionType.KILL_ENEMY, "rogue", 3, contribution = 80, stoneReward = 40)
                pool += SectMission("m_cultivate_30", "Month of Seclusion",
                    "Remain in cultivation for 30 days without interruption.",
                    MissionType.CULTIVATE_DAYS, targetCount = 30, contribution = 70, stoneReward = 35)
                pool += SectMission("m_ruins_survey", "Survey the Ancient Ruins",
                    "Explore the Shattered Heaven Ruins and recover any spiritual artifacts.",
                    MissionType.EXPLORE_LOCATION, "ancient_ruins", 1, contribution = 90, stoneReward = 60)
                pool += SectMission("m_tithe_inner", "Inner Disciple Tithe",
                    "Contribute 80 spirit stones to sect resources.",
                    MissionType.SPIRIT_STONE_TITHE, targetCount = 80, contribution = 50, stoneReward = 20)
            }
            SectRank.CORE -> {
                pool += SectMission("m_kill_demon", "Purge the Demon Waste Border",
                    "Demonic creatures encroach on sect territory. Eliminate 5 demon-type enemies.",
                    MissionType.KILL_ENEMY, "demon", 5, contribution = 200, stoneReward = 120)
                pool += SectMission("m_reach_foundation", "Foundation Building",
                    "The sect demands their Core Disciples reach Foundation Building realm.",
                    MissionType.REACH_REALM, "FOUNDATION", 1, contribution = 300, stoneReward = 200)
                pool += SectMission("m_cultivate_100", "Hundred-Day Retreat",
                    "A hundred days of unbroken seclusion.",
                    MissionType.CULTIVATE_DAYS, targetCount = 100, contribution = 250, stoneReward = 150)
            }
            else -> {
                pool += SectMission("m_elder_duty", "Elder's Standing Duty",
                    "Maintain the sect's honor through your actions and cultivation.",
                    MissionType.CULTIVATE_DAYS, targetCount = 7, contribution = 100, stoneReward = 80)
            }
        }

        return pool.shuffled().take(3)
    }

    // ── JOIN ──────────────────────────────────────────────────────────────────

    fun joinSect(state: GameState, sectId: String): List<LogEntry> {
        val log = mutableListOf<LogEntry>()
        val sect = SECTS[sectId] ?: return listOf(LogEntry("Unknown sect.", LogType.DANGER))
        val p = state.player

        if (state.sectMembership != null) {
            log += LogEntry("You already belong to ${SECTS[state.sectMembership!!.sectId]?.name}. To join another sect you must leave your current one.", LogType.DANGER)
            return log
        }

        state.sectMembership = SectMembership(sectId)
        state.world.location = sect.name
        state.world.locationId = sect.locationId

        log += LogEntry("")
        log += LogEntry("━━━ SECT JOINED ━━━", LogType.SECT)
        log += LogEntry("You kneel before the sect elders and swear the cultivation oath.", LogType.SECT)
        log += LogEntry("You are now an Outer Disciple of ${sect.name}.", LogType.SECT)
        log += LogEntry(sect.desc, LogType.NORMAL)
        log += LogEntry(sect.joinBonus, LogType.EVENT)

        // Give joining technique
        val tech = SECT_TECHNIQUES[sectId]
        if (tech != null && p.techniques.none { it.id == tech.id }) {
            p.techniques.add(tech.copy())
            log += LogEntry("Technique learned: ${tech.name}.", LogType.BREAKTHROUGH)
        }

        // Give joining items
        if (sectId == "silent_moon_pavilion") {
            repeat(3) { p.inventory.add(InventorySystem.MINOR_HEALING_PILL.copy()) }
        }

        // Generate initial missions
        state.activeMissions.addAll(generateMissions(state.sectMembership!!))
        log += LogEntry("Three missions have been assigned. Visit the Sect screen to review them.", LogType.SECT)

        return log
    }

    // ── LEAVE SECT ────────────────────────────────────────────────────────────

    fun leaveSect(state: GameState): List<LogEntry> {
        val membership = state.sectMembership ?: return listOf(LogEntry("You are not in a sect.", LogType.DANGER))
        val sect = SECTS[membership.sectId]
        val standing = membership.standing

        state.sectMembership = null
        state.activeMissions.clear()

        val consequence = when {
            standing > 70 -> "The elders accept your departure with disappointment but no malice."
            standing > 30 -> "You leave on neutral terms. The sect will not hunt you."
            else -> { state.player.karma -= 10; "You are branded a traitor. The sect marks you as an enemy." }
        }

        return listOf(
            LogEntry(""),
            LogEntry("You have left ${sect?.name ?: "the sect"}.", LogType.SECT),
            LogEntry(consequence, LogType.EVENT)
        )
    }

    // ── MISSION TRACKING ──────────────────────────────────────────────────────

    fun onKillEnemy(state: GameState, enemyName: String) {
        val lower = enemyName.lowercase()
        state.activeMissions.filter {
            it.type == MissionType.KILL_ENEMY && !it.completed &&
            (it.targetId.isEmpty() || lower.contains(it.targetId))
        }.forEach { mission ->
            mission.progress++
            if (mission.progress >= mission.targetCount) completeMission(state, mission)
        }
    }

    fun onCultivateDay(state: GameState) {
        state.activeMissions.filter {
            it.type == MissionType.CULTIVATE_DAYS && !it.completed
        }.forEach { mission ->
            mission.progress++
            if (mission.progress >= mission.targetCount) completeMission(state, mission)
        }
    }

    fun onExploreLocation(state: GameState, locationId: String) {
        state.activeMissions.filter {
            it.type == MissionType.EXPLORE_LOCATION && !it.completed && it.targetId == locationId
        }.forEach { mission ->
            mission.progress = mission.targetCount
            completeMission(state, mission)
        }
    }

    fun onRealmAdvance(state: GameState) {
        state.activeMissions.filter {
            it.type == MissionType.REACH_REALM && !it.completed
        }.forEach { mission ->
            val targetTier = RealmTier.values().firstOrNull { it.name == mission.targetId }
            if (targetTier != null && state.player.realm.tier.ordinal >= targetTier.ordinal) {
                mission.progress = mission.targetCount
                completeMission(state, mission)
            }
        }
    }

    fun titheStones(state: GameState, mission: SectMission): Pair<Boolean, String> {
        val p = state.player
        if (p.spiritStones < mission.targetCount) {
            return Pair(false, "Insufficient spirit stones. (Need ${mission.targetCount}, have ${p.spiritStones})")
        }
        p.spiritStones -= mission.targetCount
        mission.progress = mission.targetCount
        completeMission(state, mission)
        return Pair(true, "")
    }

    private fun completeMission(state: GameState, mission: SectMission) {
        if (mission.completed) return
        mission.completed = true
        val membership = state.sectMembership ?: return

        membership.contribution += mission.contribution
        membership.missionsCompleted++
        state.player.spiritStones += mission.stoneReward
        membership.standing = (membership.standing + 5).coerceAtMost(100)

        // Check rank up
        checkRankUp(state, membership)
    }

    private fun checkRankUp(state: GameState, membership: SectMembership) {
        val nextRank = SectRank.values().getOrNull(membership.rank.ordinal + 1) ?: return
        if (membership.contribution >= nextRank.contributionRequired) {
            membership.rank = nextRank
            state.player.titles.add("${SECTS[membership.sectId]?.name} — ${nextRank.display}")
            // Refresh missions for new rank
            state.activeMissions.removeAll { it.completed }
            state.activeMissions.addAll(generateMissions(membership))
        }
    }

    // ── RANK BENEFITS ─────────────────────────────────────────────────────────

    fun rankBenefitDesc(rank: SectRank): String = when (rank) {
        SectRank.OUTER  -> "Access to sect library (basic). Weekly resource stipend."
        SectRank.INNER  -> "Access to inner library. Monthly resource stipend. Private cultivation room."
        SectRank.CORE   -> "Access to all sect techniques. Priority resource allocation. Sect formation protection."
        SectRank.ELDER  -> "Authority over disciples. Control of sect resources. Voice in sect decisions."
        SectRank.SECT_MASTER -> "Absolute authority. All sect resources. The heavens acknowledge your standing."
    }
}
