package com.immortalascension

import kotlin.random.Random
import kotlin.math.max

object CombatSystem {

    fun playerAttack(state: GameState): List<LogEntry> {
        val cs = state.combat ?: return emptyList()
        val p = state.player
        val e = cs.enemy
        val log = mutableListOf<LogEntry>()

        if (e.stunned) {
            log += entry("${e.name} is still stunned.", LogType.COMBAT)
        }

        val realmGap = p.realm.dominates(e.realm)
        val atkMulti = realmMod(realmGap, attacking = true)
        val shieldMod = if (cs.shieldActive) { cs.shieldActive = false; 0.6f } else 1.0f

        val raw = ((p.totalAttack * atkMulti * shieldMod).toInt() - e.defense / 2).coerceAtLeast(1)
        val crit = Random.nextFloat() < (0.08f + p.luck * 0.005f + if (cs.hasteActive) 0.1f else 0f)
        val dmg = if (crit) (raw * 1.8f).toInt() else raw

        e.hp -= dmg
        log += if (crit)
            entry("⚡ Critical! Your strike finds a fatal gap — $dmg damage to ${e.name}. [${e.hp}/${e.maxHp}]", LogType.COMBAT)
        else
            entry("You strike ${e.name} for $dmg damage. [${e.hp}/${e.maxHp}]", LogType.COMBAT)

        cs.hasteActive = false
        return log
    }

    fun playerTechnique(state: GameState, tech: Technique): List<LogEntry> {
        val cs = state.combat ?: return emptyList()
        val p = state.player
        val e = cs.enemy
        val log = mutableListOf<LogEntry>()

        if (p.qi < tech.qiCost) {
            log += entry("Insufficient Qi. (Need ${tech.qiCost}, have ${p.qi})", LogType.DANGER)
            return log
        }
        if (tech.cooldown > 0) {
            log += entry("${tech.name} is still on cooldown. (${tech.cooldown} rounds)", LogType.DANGER)
            return log
        }

        p.qi -= tech.qiCost
        tech.cooldown = tech.cooldownMax

        // Track mastery and usage
        tech.mastery = (tech.mastery + Random.nextInt(1, 4)).coerceAtMost(100)
        when (tech.type) {
            TechniqueType.ATTACK, TechniqueType.MOVEMENT -> tech.usageProfile.offensiveUses++
            TechniqueType.DEFENSE, TechniqueType.SUPPORT -> tech.usageProfile.defensiveUses++
        }

        // Check evolution
        val evo = InventorySystem.checkTechEvolution(tech)
        if (evo != null) {
            tech.evolutionPath = evo
            log += entry("✦ ${tech.name} has evolved along the $evo Path!", LogType.BREAKTHROUGH)
        }

        val realmMod  = realmMod(p.realm.dominates(e.realm), attacking = true)
        val weakenMod = if (e.weakened) 1.25f else 1.0f
        val evolveMod = when (tech.evolutionPath) {
            "Killing" -> 1.2f; "Enlightened" -> 1.1f; else -> 1.0f
        }

        val effectiveDmg = ((tech.effectiveDamage * realmMod * weakenMod * evolveMod * tech.masteryBonus).toInt())
            .coerceAtLeast(if (tech.damage > 0) 1 else 0)

        when {
            tech.healAmount > 0 -> {
                val heal = (tech.healAmount * tech.masteryBonus).toInt()
                p.hp = (p.hp + heal).coerceAtMost(p.maxHp)
                log += entry("✦ ${tech.evolvedName}: Healing Qi floods your meridians. +$heal HP. [${p.hp}/${p.maxHp}]", LogType.CULTIVATION)
            }
            effectiveDmg > 0 -> {
                e.hp -= effectiveDmg
                log += entry("✦ ${tech.evolvedName}! ${elementDesc(tech.element)}${e.name} takes $effectiveDmg damage. [${e.hp}/${e.maxHp}]", LogType.COMBAT)
                if (e.hp <= 0) tech.usageProfile.killFinishes++

                if (tech.effect != TechEffect.NONE && Random.nextFloat() < tech.effectChance) {
                    applyEffectToEnemy(e, tech.effect, tech.effectDuration)
                    log += entry("  ↳ ${effectName(tech.effect)} applied!", LogType.COMBAT)
                }
            }
            else -> {
                // Pure support / shield / haste
                when (tech.effect) {
                    TechEffect.SHIELD -> { cs.shieldActive = true;  log += entry("✦ ${tech.evolvedName}: A shield of Qi forms around you.", LogType.CULTIVATION) }
                    TechEffect.HASTE  -> { cs.hasteActive  = true;  log += entry("✦ ${tech.evolvedName}: Your speed surges. Next attack criticals.", LogType.CULTIVATION) }
                    else -> log += entry("✦ ${tech.evolvedName} activated. ${tech.desc}", LogType.CULTIVATION)
                }
            }
        }

        return log
    }

    fun playerDefend(state: GameState): List<LogEntry> {
        val p = state.player
        val qiGain = p.maxQi / 20
        p.qi = (p.qi + qiGain).coerceAtMost(p.maxQi)
        return listOf(entry("You enter a defensive stance, recovering $qiGain Qi. Incoming damage halved this round.", LogType.COMBAT))
    }

    fun enemyTurn(state: GameState, defending: Boolean): List<LogEntry> {
        val cs = state.combat ?: return emptyList()
        val e = cs.enemy
        val p = state.player
        val log = mutableListOf<LogEntry>()

        if (e.stunned) {
            e.stunned = false
            log += entry("${e.name} shakes off the stun!", LogType.COMBAT)
            cs.round++
            tickCooldowns(p)
            return log
        }

        if (e.weakened && e.weakenedTurns > 0) {
            e.weakenedTurns--
            if (e.weakenedTurns == 0) e.weakened = false
        }

        val atkMod = when (e.behavior) {
            EnemyBehavior.AGGRESSIVE -> 1.15f
            EnemyBehavior.BERSERKER  -> if (e.hp < e.maxHp / 3) 1.5f else 1.0f
            EnemyBehavior.CAUTIOUS   -> 0.9f
            EnemyBehavior.TACTICAL   -> if (cs.round % 3 == 0) 1.4f else 0.85f
        }
        val defMod    = if (defending) 0.5f else 1.0f
        val weakMod   = if (e.weakened) 0.7f else 1.0f
        val realmGap  = e.realm.dominates(p.realm)
        val rMod      = realmMod(realmGap, attacking = true)
        val shieldMod = if (cs.shieldActive) { cs.shieldActive = false; 0.5f } else 1.0f

        // Body refinement reduces incoming damage
        val bodyMod = 1f - p.bodyRefinementLevel * 0.04f

        if (realmGap >= 30 && cs.round == 1)
            log += entry("⚠ ${e.name}'s overwhelming aura suppresses you. Your Qi stutters.", LogType.DANGER)

        val raw  = ((e.attack * atkMod * weakMod * rMod).toInt() - p.totalDefense / 2).coerceAtLeast(1)
        val dmg  = (raw * defMod * shieldMod * bodyMod).toInt().coerceAtLeast(1)
        p.hp -= dmg

        val desc = enemyAttackDesc(e, cs.round)
        log += entry("$desc You take $dmg damage. [${p.hp}/${p.maxHp}]", LogType.DANGER)

        cs.round++
        tickCooldowns(p)
        return log
    }

    fun flee(state: GameState): Pair<Boolean, List<LogEntry>> {
        val p = state.player
        val e = state.combat?.enemy ?: return Pair(true, emptyList())
        val chance = (0.4f + p.speed * 0.01f - e.speed * 0.01f).coerceIn(0.15f, 0.9f)
        return if (Random.nextFloat() < chance) {
            p.hp -= (p.maxHp * 0.06f).toInt()
            Pair(true, listOf(entry("You retreat, taking a minor wound as you go.", LogType.EVENT)))
        } else {
            val log = mutableListOf(entry("${e.name} cuts off your retreat!", LogType.DANGER))
            log += enemyTurn(state, false)
            Pair(false, log)
        }
    }

    fun checkBattleEnd(state: GameState): BattleResult = when {
        (state.combat?.enemy?.hp ?: 1) <= 0 -> BattleResult.PLAYER_WIN
        state.player.hp <= 0                 -> BattleResult.PLAYER_DEAD
        else                                 -> BattleResult.ONGOING
    }

    // ── HELPERS ───────────────────────────────────────────────────────────────

    private fun realmMod(gap: Int, attacking: Boolean): Float = when {
        gap >=  30 -> if (attacking) 1.45f else 0.55f
        gap >=  20 -> if (attacking) 1.25f else 0.75f
        gap <= -30 -> if (attacking) 0.55f else 1.45f
        gap <= -20 -> if (attacking) 0.75f else 1.25f
        else       -> 1.0f
    }

    private fun applyEffectToEnemy(e: Enemy, effect: TechEffect, duration: Int) {
        when (effect) {
            TechEffect.STUN   -> e.stunned = true
            TechEffect.WEAKEN -> { e.weakened = true; e.weakenedTurns = duration }
            else -> {}
        }
    }

    private fun tickCooldowns(p: Player) = p.techniques.forEach { if (it.cooldown > 0) it.cooldown-- }

    private fun elementDesc(elem: TechElement): String = when (elem) {
        TechElement.FIRE      -> "Flames engulf — "
        TechElement.LIGHTNING -> "Lightning tears through — "
        TechElement.ICE       -> "Ice shatters against — "
        TechElement.VOID      -> "Void energy devours — "
        TechElement.WIND      -> "Blade-wind slices — "
        TechElement.EARTH     -> "Earth force crushes — "
        TechElement.WATER     -> "Water force strikes — "
        TechElement.WOOD      -> "Wood force binds — "
        else -> ""
    }

    private fun effectName(e: TechEffect) = when (e) {
        TechEffect.STUN -> "Stun"; TechEffect.BURN -> "Burn"; TechEffect.BLEED -> "Bleed"
        TechEffect.WEAKEN -> "Weaken"; TechEffect.SHIELD -> "Shield"; TechEffect.HASTE -> "Haste"
        else -> ""
    }

    private fun enemyAttackDesc(e: Enemy, round: Int): String {
        val t = listOf(
            "${e.name} strikes with brutal force.",
            "${e.name}'s blow finds a gap in your defense.",
            "${e.name} surges forward in a burst of Qi.",
            "${e.name} channels killing intent into a heavy blow.",
            "${e.name} moves with unnerving calm."
        )
        return t[round % t.size]
    }

    private fun entry(text: String, type: LogType = LogType.COMBAT) = LogEntry(text, type)
}

enum class BattleResult { ONGOING, PLAYER_WIN, PLAYER_DEAD }
