# FEATURES_ADDED — Seventeenth pass

One feature, prompted by hitting a real limitation of Twelfth pass's
original debug-log tool: it depended on OS logcat access, which turns out
not to work on every phone.

## Durable, logcat-independent link debug logging

**Description:** The "Copy link log" tool (quick game menu) no longer
shells out to `logcat`. `mgba_jni.c`'s `LOGI`/`LOGW`/`LOGE` calls, plus
`LinkMultiplayer.kt`'s own connection-lifecycle log lines, now also write
to a plain private file this app owns outright (`filesDir/
link_debug.log`) — no permission needed, no dependency on OS logcat access
of any kind, on any OEM build. The file resets fresh at the start of every
link connection attempt (`nativeLinkStart()`), so a capture reflects one
attempt rather than accumulating across a whole app session, with an 8MB
backstop cap for the rare session that runs long before anyone reads it.

**User benefit:** The debug-log tool now works the same way on every
phone, including the one where the old logcat-based version returned
nothing at all — confirmed by W's own side-by-side test (real output on
one phone, empty on the other, same build, same tool). This specifically
unblocks getting a synchronized capture from *both* phones during the same
connection attempt, which every pass investigating the multiplayer issue
since the Twelfth has needed and not been able to get.

**Files modified:** `mgba_jni.c` (the actual file-writing logic and the
new `nativeSetLinkLogPath()` entry point), `EmulatorEngine.kt` (JNI
declaration), `MainActivity.kt` (calls it once from `onCreate()`;
`copyLinkDebugLog()` reads the file instead of invoking `logcat`),
`LinkMultiplayer.kt` (mirrors its own 7 log lines into the same file via a
new `linkLog()` helper, so one file has everything the old combined
3-tag logcat filter used to).

---

# FEATURES_ADDED — Fourteenth pass

Three related changes from one request, all in `changeRom()`'s neighborhood:
transparent zip loading, an in-app file-manager-style ROM browser to
replace the raw system picker, and a Screen orientation setting. Requested
against a reference screenshot of another emulator's Video settings and
"Load game" screen — matched the general shape (file-manager layout,
five-way orientation dialog) rather than that app's exact code, which
this project has no access to and wouldn't want to depend on anyway (see
storage-permission note below for why the underlying approach couldn't be
identical even if it were available).

## 1. Transparent zip ROM loading

**Description:** Any ROM entry point (system picker or the new browser
below) now accepts a `.zip` containing a `.gba` directly — no separate
extraction step. Detected by the real zip magic bytes ("PK\x03\x04"), not
the file's name, so a misnamed archive still works and a same-named non-zip
file is correctly rejected rather than handed to the core as garbage. See
`stageRomFile()` in `MainActivity.kt`.

**User benefit:** Most GBA ROM distributions are a `.zip` with one `.gba`
inside it (see the reference screenshot's own "Load game" list — almost
every entry is a `.zip`); previously each one had to be extracted by hand
before this app could open it.

**Files modified:** `MainActivity.kt` (new `stageRomFile()`; `romPicker`'s
callback and the new browser's file-tap both route through it now via the
shared `loadRomFromUri()` — see Feature 2).

## 2. In-app ROM folder browser

**Description:** `changeRom()` now opens a custom "Load game" screen
(`romBrowserOverlay`/`buildRomBrowser()`) instead of launching the system
document picker directly: a path readout, an up button, and a plain
scrollable list of subfolders and `.zip`/`.gba` files, styled to match this
app's existing Settings screen rather than the reference screenshot's
Material dialog chrome specifically. Backed by SAF's `OpenDocumentTree` +
`DocumentFile`, asked for once and persisted (`PREF_ROMS_TREE_URI`) —
**not** raw `java.io.File` against a hardcoded path like
`/storage/emulated/0/Download/Roms`.

**Reason for the SAF-tree approach instead of a literal hardcoded-path
file manager:** this app deliberately removed `READ_EXTERNAL_STORAGE`
already (see `AndroidManifest.xml`) so ROM loading needs no storage
permission at all. A literal file-manager rooted at an absolute path would
need that permission at minimum, and on this app's targetSdk 34 (API 30+
scoped storage) realistically `MANAGE_EXTERNAL_STORAGE` ("All files
access") to reach an arbitrary folder like `Download/Roms` — a real
regression from "asks for nothing but the ROM itself." Whatever the
reference app is doing to show a raw path like that, this app matches the
*look* (folders, path, up button) without taking on that permission.

**User benefit:** Browsing for a ROM now looks and works like a file
manager instead of the bare-bones system document picker (which, on many
devices/launchers, defaults to an unhelpful "Recent" view rather than the
ROMs folder).

**Files modified:** `MainActivity.kt` (new `romTreePicker`,
`openRomBrowserAtRoot()`, `refreshRomBrowserList()`, `romBrowserRow()`,
`romBrowserUp()`, `buildRomBrowser()`; `changeRom()` rewritten;
`romPicker`'s callback slimmed down, its body extracted into the new
shared `loadRomFromUri()`). `build.gradle.kts` (added the
`androidx.documentfile` dependency this needs).

**Note:** the classic system picker isn't removed — it's one tap away as
"Use system file picker instead" at the bottom of the new browser, in case
tree-based browsing ever misbehaves for someone's device or storage
provider.

## 3. Screen orientation setting

**Description:** Video settings gained a five-way "Screen orientation"
choice (Auto rotate / Landscape / Reverse landscape / Portrait / System
default), matching the reference screenshot's dialog. Was previously fixed
to landscape both in code (`requestedOrientation` set once in `onCreate`)
and in the manifest (`android:screenOrientation="landscape"`); both are now
driven by a persisted preference instead (`PREF_ORIENTATION`, applied via
the new `applyScreenOrientationPref()`), defaulting to landscape so
existing installs behave identically until this is actually changed.

**Files modified:** `MainActivity.kt` (new `applyScreenOrientationPref()`;
`showVideoSettings()` gained the radio group and its Save handling;
`onCreate()`'s hardcoded orientation line replaced). `AndroidManifest.xml`
(`android:screenOrientation` changed from `"landscape"` to `"unspecified"`
— the existing `android:configChanges` entry already keeps the activity,
and the running core, alive across the resulting orientation change
without a restart, exactly as it did for the old hardcoded value).

---

# FEATURES_ADDED — Earlier passes (summary)

Full entries trimmed for length — all unrelated to multiplayer/link.

- **Thirteenth** — Save-state thumbnails in the slot picker.
- **Tenth** — Screenshot, Reset, and Close added to the quick game menu
  (matching a reference screenshot's full item list).
- **Fifth** — Auto save-file backup (`.bak` before overwrite) and an
  optional performance overlay (core FPS + audio underrun count), off by
  default.
