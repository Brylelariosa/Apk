package com.gamepad.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class JoystickView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var onMoveListener: ((Float, Float) -> Unit)? = null
    var onReleaseListener: (() -> Unit)? = null

    // Normalized joystick values [-1, 1]
    var normalizedX = 0f
        private set
    var normalizedY = 0f
        private set

    private val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val outerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(160, 120, 120, 255)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val innerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(60, 150, 150, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val thumbBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 180, 180, 255)
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }
    private val crossPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(50, 200, 200, 255)
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
    }

    private var cx = 0f
    private var cy = 0f
    private var thumbX = 0f
    private var thumbY = 0f
    private var outerRadius = 0f
    private var innerRadius = 0f
    private var maxThumbTravel = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        cx = w / 2f
        cy = h / 2f
        thumbX = cx
        thumbY = cy
        outerRadius = min(w, h) / 2f * 0.92f
        innerRadius = outerRadius * 0.38f
        maxThumbTravel = outerRadius - innerRadius

        // Radial gradient for base
        outerRingPaint.shader = RadialGradient(
            cx, cy, outerRadius,
            intArrayOf(Color.argb(100, 60, 60, 180), Color.argb(140, 30, 30, 100)),
            null,
            Shader.TileMode.CLAMP
        )
        // Gradient for thumb
        thumbPaint.shader = RadialGradient(
            cx, cy, innerRadius,
            intArrayOf(Color.argb(240, 160, 160, 255), Color.argb(200, 80, 80, 200)),
            null,
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        // Outer base
        canvas.drawCircle(cx, cy, outerRadius, outerRingPaint)
        canvas.drawCircle(cx, cy, outerRadius, outerBorderPaint)
        // Inner ring guide
        canvas.drawCircle(cx, cy, outerRadius * 0.55f, innerRingPaint)
        // Crosshair
        canvas.drawLine(cx - outerRadius * 0.65f, cy, cx + outerRadius * 0.65f, cy, crossPaint)
        canvas.drawLine(cx, cy - outerRadius * 0.65f, cx, cy + outerRadius * 0.65f, crossPaint)
        // Cardinal dots
        val dotR = 4f
        val dotDist = outerRadius * 0.82f
        val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(80, 180, 180, 255)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(cx, cy - dotDist, dotR, dotPaint)
        canvas.drawCircle(cx, cy + dotDist, dotR, dotPaint)
        canvas.drawCircle(cx - dotDist, cy, dotR, dotPaint)
        canvas.drawCircle(cx + dotDist, cy, dotR, dotPaint)

        // Update thumb gradient center to follow thumb
        thumbPaint.shader = RadialGradient(
            thumbX, thumbY, innerRadius * 1.2f,
            intArrayOf(Color.argb(255, 180, 180, 255), Color.argb(200, 70, 70, 200)),
            null,
            Shader.TileMode.CLAMP
        )
        // Shadow
        val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(60, 0, 0, 80)
        }
        canvas.drawCircle(thumbX + 3f, thumbY + 4f, innerRadius, shadowPaint)
        // Thumb
        canvas.drawCircle(thumbX, thumbY, innerRadius, thumbPaint)
        canvas.drawCircle(thumbX, thumbY, innerRadius, thumbBorderPaint)
        // Thumb highlight
        val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(80, 255, 255, 255)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(thumbX - innerRadius * 0.25f, thumbY - innerRadius * 0.3f, innerRadius * 0.3f, highlightPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val dx = event.x - cx
                val dy = event.y - cy
                val dist = sqrt(dx * dx + dy * dy)

                if (dist <= maxThumbTravel) {
                    thumbX = event.x
                    thumbY = event.y
                } else {
                    val angle = atan2(dy, dx)
                    thumbX = cx + cos(angle) * maxThumbTravel
                    thumbY = cy + sin(angle) * maxThumbTravel
                }
                normalizedX = (thumbX - cx) / maxThumbTravel
                normalizedY = (thumbY - cy) / maxThumbTravel
                onMoveListener?.invoke(normalizedX, normalizedY)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                thumbX = cx
                thumbY = cy
                normalizedX = 0f
                normalizedY = 0f
                onReleaseListener?.invoke()
                onMoveListener?.invoke(0f, 0f)
                invalidate()
                return true
            }
        }
        return false
    }
}
