package com.gamepad.overlay

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences(OverlayService.PREFS, Context.MODE_PRIVATE) }

    // ── All available controller keycodes the user can assign ────────────────
    data class KcEntry(val label: String, val code: Int)

    private val ALL_KEYCODES: List<KcEntry> = listOf(
        KcEntry("A  (Button A)",        KeyEvent.KEYCODE_BUTTON_A),
        KcEntry("B  (Button B)",        KeyEvent.KEYCODE_BUTTON_B),
        KcEntry("X  (Button X)",        KeyEvent.KEYCODE_BUTTON_X),
        KcEntry("Y  (Button Y)",        KeyEvent.KEYCODE_BUTTON_Y),
        KcEntry("L1 / LB",             KeyEvent.KEYCODE_BUTTON_L1),
        KcEntry("L2 / LT",             KeyEvent.KEYCODE_BUTTON_L2),
        KcEntry("R1 / RB",             KeyEvent.KEYCODE_BUTTON_R1),
        KcEntry("R2 / RT",             KeyEvent.KEYCODE_BUTTON_R2),
        KcEntry("Start",               KeyEvent.KEYCODE_BUTTON_START),
        KcEntry("Select",              KeyEvent.KEYCODE_BUTTON_SELECT),
        KcEntry("L3 (Left Stick Btn)", KeyEvent.KEYCODE_BUTTON_THUMBL),
        KcEntry("R3 (Right Stick Btn)",KeyEvent.KEYCODE_BUTTON_THUMBR),
        KcEntry("D-Pad Up",            KeyEvent.KEYCODE_DPAD_UP),
        KcEntry("D-Pad Down",          KeyEvent.KEYCODE_DPAD_DOWN),
        KcEntry("D-Pad Left",          KeyEvent.KEYCODE_DPAD_LEFT),
        KcEntry("D-Pad Right",         KeyEvent.KEYCODE_DPAD_RIGHT),
        KcEntry("C  (Button C)",       KeyEvent.KEYCODE_BUTTON_C),
        KcEntry("Z  (Button Z)",       KeyEvent.KEYCODE_BUTTON_Z),
        KcEntry("Mode",                KeyEvent.KEYCODE_BUTTON_MODE),
        KcEntry("Menu",                KeyEvent.KEYCODE_MENU),
        KcEntry("Back",                KeyEvent.KEYCODE_BACK),
        KcEntry("⬛ Tap Screen (no key)", -1),
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupUI()
        setupCustomizeSection()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        syncSwitches()
    }

    // ── Permission / launch UI ────────────────────────────────────────────────

    private fun setupUI() {
        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnLaunchOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Please grant overlay permission first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val intent = Intent(this, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
            else startService(intent)
            Toast.makeText(this,
                "Overlay launched! Buttons send real controller keys.\n" +
                "Long-press a button to drag it.",
                Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
        findViewById<Button>(R.id.btnStopOverlay).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Overlay stopped", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateStatus() {
        val overlayGranted = Settings.canDrawOverlays(this)
        val accessEnabled  = isAccessibilityServiceEnabled()
        findViewById<TextView>(R.id.tvOverlayStatus).apply {
            text = if (overlayGranted) "✅  Overlay Permission: Granted"
                   else "❌  Overlay Permission: Not Granted"
            setTextColor(if (overlayGranted) 0xFF7aff9a.toInt() else 0xFFff6060.toInt())
        }
        findViewById<TextView>(R.id.tvAccessibilityStatus).apply {
            text = if (accessEnabled) "✅  Accessibility Service: Enabled"
                   else "❌  Accessibility Service: Disabled"
            setTextColor(if (accessEnabled) 0xFF7aff9a.toInt() else 0xFFff9060.toInt())
        }
        findViewById<Button>(R.id.btnLaunchOverlay).isEnabled = overlayGranted
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val am = getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabled = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
        return enabled.any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    // ── Customisation section ─────────────────────────────────────────────────

    private fun setupCustomizeSection() {

        // ── Visibility switches ───────────────────────────────────────────────
        val switchMap = mapOf(
            R.id.swJoystick to "show_joystick",
            R.id.swDpad     to "show_dpad",
            R.id.swABXY     to "show_abxy",
            R.id.swShoulder to "show_shoulder",
            R.id.swCenter   to "show_center"
        )
        for ((viewId, prefKey) in switchMap) {
            findViewById<Switch>(viewId).setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putBoolean(prefKey, isChecked).apply()
                refreshOverlay()
            }
        }

        // ── Vibration switch ──────────────────────────────────────────────────
        findViewById<Switch>(R.id.swVibration).setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("vibration_enabled", isChecked).apply()
        }

        // ── Remap built-in buttons ────────────────────────────────────────────
        setupRemapSection()

        // ── Preset extra-button row ───────────────────────────────────────────
        data class Preset(val label: String, val color: Int, val defaultKc: Int)

        val allPresets = listOf(
            Preset("A",  Color.argb(220,   0,160, 70), KeyEvent.KEYCODE_BUTTON_A),
            Preset("B",  Color.argb(220, 210, 40, 40), KeyEvent.KEYCODE_BUTTON_B),
            Preset("X",  Color.argb(220,  20,100,210), KeyEvent.KEYCODE_BUTTON_X),
            Preset("Y",  Color.argb(220, 200,160,  0), KeyEvent.KEYCODE_BUTTON_Y),
            Preset("▲",  Color.argb(200,  70, 70,110), KeyEvent.KEYCODE_DPAD_UP),
            Preset("▼",  Color.argb(200,  70, 70,110), KeyEvent.KEYCODE_DPAD_DOWN),
            Preset("◄",  Color.argb(200,  70, 70,110), KeyEvent.KEYCODE_DPAD_LEFT),
            Preset("►",  Color.argb(200,  70, 70,110), KeyEvent.KEYCODE_DPAD_RIGHT),
            Preset("LB", Color.argb(200,  60, 60,160), KeyEvent.KEYCODE_BUTTON_L1),
            Preset("RB", Color.argb(200,  60, 60,160), KeyEvent.KEYCODE_BUTTON_R1),
            Preset("LT", Color.argb(200,  40, 40,130), KeyEvent.KEYCODE_BUTTON_L2),
            Preset("RT", Color.argb(200,  40, 40,130), KeyEvent.KEYCODE_BUTTON_R2),
            Preset("L3", Color.argb(200,  60, 60,100), KeyEvent.KEYCODE_BUTTON_THUMBL),
            Preset("R3", Color.argb(200,  60, 60,100), KeyEvent.KEYCODE_BUTTON_THUMBR),
            Preset("ZL", Color.argb(200,  30,100,130), KeyEvent.KEYCODE_BUTTON_L2),
            Preset("ZR", Color.argb(200,  30,100,130), KeyEvent.KEYCODE_BUTTON_R2),
            Preset("Z",  Color.argb(200,  80, 50,150), KeyEvent.KEYCODE_BUTTON_Z),
            Preset("C",  Color.argb(200, 150,120, 20), KeyEvent.KEYCODE_BUTTON_C),
            Preset("⚡", Color.argb(200, 160, 80,  0), KeyEvent.KEYCODE_BUTTON_MODE),
            Preset("★",  Color.argb(200, 160,130,  0), KeyEvent.KEYCODE_BUTTON_SELECT),
        )

        val presetContainer = findViewById<LinearLayout>(R.id.presetBtnContainer)
        presetContainer.removeAllViews()
        for (preset in allPresets) {
            val btn = Button(this).apply {
                text = "+ ${preset.label}"
                textSize = 12f
                setTextColor(Color.WHITE)
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = 24f * resources.displayMetrics.density
                    setColor(preset.color)
                }
                val dp8 = (8 * resources.displayMetrics.density).toInt()
                setPadding(dp8 * 2, dp8, dp8 * 2, dp8)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(dp8, 0, dp8, 0) }
                setOnClickListener { addExtraButton(preset.label, preset.color, preset.defaultKc) }
            }
            presetContainer.addView(btn)
        }

        // ── Custom button dialog ──────────────────────────────────────────────
        findViewById<Button>(R.id.btnAddCustom).setOnClickListener { showAddCustomDialog() }

        // ── Reset positions ───────────────────────────────────────────────────
        findViewById<Button>(R.id.btnResetPositions).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Reset Button Positions")
                .setMessage("Return all buttons to their default positions?")
                .setPositiveButton("Reset") { _, _ ->
                    val edit = prefs.edit()
                    prefs.all.keys.filter { it.endsWith("_x") || it.endsWith("_y") }
                        .forEach { edit.remove(it) }
                    edit.apply()
                    refreshOverlay()
                    Toast.makeText(this, "Positions reset", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null).show()
        }

        // ── Remove one / all extra ────────────────────────────────────────────
        findViewById<Button>(R.id.btnRemoveOne).setOnClickListener { showRemoveOneDialog() }
        findViewById<Button>(R.id.btnClearExtra).setOnClickListener {
            val count = prefs.getInt("extra_btn_count", 0)
            if (count == 0) {
                Toast.makeText(this, "No extra buttons to remove", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            AlertDialog.Builder(this)
                .setTitle("Remove All Extra Buttons")
                .setMessage("Remove all $count custom extra button(s)?")
                .setPositiveButton("Remove All") { _, _ ->
                    val edit = prefs.edit()
                    for (i in 0 until count) {
                        val t = "extra_$i"
                        edit.remove("${t}_label").remove("${t}_color")
                            .remove("${t}_x").remove("${t}_y")
                            .remove("${t}_keycode")
                    }
                    edit.putInt("extra_btn_count", 0).apply()
                    refreshOverlay()
                    Toast.makeText(this, "All extra buttons removed", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null).show()
        }
    }

    // ── Remap section — one row per built-in button ───────────────────────────

    private val REMAP_BUTTONS = listOf(
        "btn_a"      to "A",
        "btn_b"      to "B",
        "btn_x"      to "X",
        "btn_y"      to "Y",
        "btn_lb"     to "LB",
        "btn_rb"     to "RB",
        "btn_lt"     to "LT",
        "btn_rt"     to "RT",
        "btn_start"  to "Start",
        "btn_select" to "Select",
        "dpad_up"    to "D-Pad ▲",
        "dpad_dn"    to "D-Pad ▼",
        "dpad_lt"    to "D-Pad ◄",
        "dpad_rt"    to "D-Pad ►",
    )

    private fun setupRemapSection() {
        val container = findViewById<LinearLayout>(R.id.remapContainer)
        container.removeAllViews()
        val dp = resources.displayMetrics.density

        for ((tag, displayName) in REMAP_BUTTONS) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    (44 * dp).toInt()
                ).apply { bottomMargin = (4 * dp).toInt() }
            }

            val nameView = TextView(this).apply {
                text = displayName
                setTextColor(0xFFDDDDDD.toInt())
                textSize = 13f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val remapBtn = Button(this).apply {
                text = kcLabel(tag)
                textSize = 11f
                setTextColor(Color.WHITE)
                background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                    cornerRadius = 20f * dp
                    setColor(Color.argb(200, 40, 60, 120))
                }
                val dp6 = (6 * dp).toInt()
                setPadding(dp6 * 2, dp6, dp6 * 2, dp6)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                setOnClickListener { showKeycodePickerFor(tag, displayName, this) }
            }

            row.addView(nameView)
            row.addView(remapBtn)
            container.addView(row)
        }
    }

    private fun kcLabel(tag: String): String {
        val saved = prefs.getInt("${tag}_keycode", Int.MIN_VALUE)
        val code  = if (saved == Int.MIN_VALUE) OverlayService.DEFAULT_KEYCODES[tag] ?: -1 else saved
        return ALL_KEYCODES.find { it.code == code }?.label?.substringBefore("(")?.trim()
            ?: if (code == -1) "Tap Screen" else "Key $code"
    }

    private fun showKeycodePickerFor(tag: String, displayName: String, btn: Button) {
        val labels = ALL_KEYCODES.map { it.label }.toTypedArray()
        val currentCode = prefs.getInt("${tag}_keycode",
            OverlayService.DEFAULT_KEYCODES[tag] ?: -1)
        val currentIdx = ALL_KEYCODES.indexOfFirst { it.code == currentCode }.coerceAtLeast(0)

        AlertDialog.Builder(this)
            .setTitle("Remap: $displayName")
            .setSingleChoiceItems(labels, currentIdx) { dialog, which ->
                val kc = ALL_KEYCODES[which].code
                prefs.edit().putInt("${tag}_keycode", kc).apply()
                btn.text = ALL_KEYCODES[which].label.substringBefore("(").trim()
                refreshOverlay()
                dialog.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ── Extra button helpers ──────────────────────────────────────────────────

    private fun syncSwitches() {
        val switchMap = mapOf(
            R.id.swJoystick to "show_joystick",
            R.id.swDpad     to "show_dpad",
            R.id.swABXY     to "show_abxy",
            R.id.swShoulder to "show_shoulder",
            R.id.swCenter   to "show_center"
        )
        for ((viewId, prefKey) in switchMap) {
            val sw = findViewById<Switch>(viewId)
            sw.setOnCheckedChangeListener(null)
            sw.isChecked = prefs.getBoolean(prefKey, true)
            sw.setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putBoolean(prefKey, isChecked).apply()
                refreshOverlay()
            }
        }
        val swVib = findViewById<Switch>(R.id.swVibration)
        swVib.setOnCheckedChangeListener(null)
        swVib.isChecked = prefs.getBoolean("vibration_enabled", true)
        swVib.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("vibration_enabled", isChecked).apply()
        }
    }

    private fun addExtraButton(label: String, color: Int, keyCode: Int) {
        val idx = prefs.getInt("extra_btn_count", 0)
        val tag = "extra_$idx"
        prefs.edit()
            .putInt("extra_btn_count", idx + 1)
            .putString("${tag}_label", label)
            .putInt("${tag}_color", color)
            .putInt("${tag}_keycode", keyCode)
            .apply()
        refreshOverlay()
        Toast.makeText(this,
            "Added \"$label\" (${kcLabelForCode(keyCode)}) — drag it into position",
            Toast.LENGTH_LONG).show()
    }

    private fun kcLabelForCode(code: Int): String =
        ALL_KEYCODES.find { it.code == code }?.label?.substringBefore("(")?.trim()
            ?: if (code == -1) "Tap Screen" else "Key $code"

    private fun showRemoveOneDialog() {
        val count = prefs.getInt("extra_btn_count", 0)
        if (count == 0) {
            Toast.makeText(this, "No extra buttons to remove", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = Array(count) { i ->
            val lbl = prefs.getString("extra_${i}_label", "?") ?: "?"
            val kc  = prefs.getInt("extra_${i}_keycode", -1)
            "$lbl  (${kcLabelForCode(kc)})"
        }
        AlertDialog.Builder(this)
            .setTitle("Remove Which Button?")
            .setItems(labels) { _, which -> removeExtraButtonAt(which) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun removeExtraButtonAt(index: Int) {
        val count = prefs.getInt("extra_btn_count", 0)
        if (index < 0 || index >= count) return
        val label = prefs.getString("extra_${index}_label", "?") ?: "?"
        val edit  = prefs.edit()
        for (i in index until count - 1) {
            val next = "extra_${i + 1}"; val cur = "extra_$i"
            edit.putString("${cur}_label",   prefs.getString("${next}_label", "?"))
            edit.putInt("${cur}_color",      prefs.getInt("${next}_color", Color.argb(200,90,60,160)))
            edit.putInt("${cur}_keycode",    prefs.getInt("${next}_keycode", -1))
            if (prefs.contains("${next}_x")) {
                edit.putFloat("${cur}_x", prefs.getFloat("${next}_x", 0.5f))
                edit.putFloat("${cur}_y", prefs.getFloat("${next}_y", 0.5f))
            } else {
                edit.remove("${cur}_x").remove("${cur}_y")
            }
        }
        val last = "extra_${count - 1}"
        edit.remove("${last}_label").remove("${last}_color")
            .remove("${last}_x").remove("${last}_y").remove("${last}_keycode")
        edit.putInt("extra_btn_count", count - 1).apply()
        refreshOverlay()
        Toast.makeText(this, "Removed \"$label\"", Toast.LENGTH_SHORT).show()
    }

    private fun showAddCustomDialog() {
        val dp = resources.displayMetrics.density
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = (20 * dp).toInt(); setPadding(pad, pad, pad, 0)
        }

        val labelInput = EditText(this).apply {
            hint = "Label (1-3 chars, e.g. L3, ⚡, Z)"; maxLines = 1
        }

        val colorLabel = TextView(this).apply {
            text = "Color:"; setTextColor(Color.LTGRAY)
            setPadding(0, (12 * dp).toInt(), 0, 4)
        }
        val colors = listOf(
            "Green"  to Color.argb(220,   0,160, 70),
            "Blue"   to Color.argb(220,  20,100,210),
            "Red"    to Color.argb(220, 210, 40, 40),
            "Yellow" to Color.argb(220, 200,160,  0),
            "Purple" to Color.argb(220,  90, 60,160),
            "Teal"   to Color.argb(220,  30,140,130),
            "Gray"   to Color.argb(220,  80, 80, 80)
        )
        val colorSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                colors.map { it.first })
        }

        val kcLabel2 = TextView(this).apply {
            text = "Controller Input:"; setTextColor(Color.LTGRAY)
            setPadding(0, (12 * dp).toInt(), 0, 4)
        }
        val kcSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                ALL_KEYCODES.map { it.label })
            // Default to BUTTON_A
            setSelection(ALL_KEYCODES.indexOfFirst { it.code == KeyEvent.KEYCODE_BUTTON_A }.coerceAtLeast(0))
        }

        container.addView(labelInput)
        container.addView(colorLabel)
        container.addView(colorSpinner)
        container.addView(kcLabel2)
        container.addView(kcSpinner)

        AlertDialog.Builder(this)
            .setTitle("Add Custom Button")
            .setView(container)
            .setPositiveButton("Add") { _, _ ->
                val label = labelInput.text.toString().trim().take(3)
                if (label.isEmpty()) {
                    Toast.makeText(this, "Enter a label", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val color  = colors[colorSpinner.selectedItemPosition].second
                val keyCode = ALL_KEYCODES[kcSpinner.selectedItemPosition].code
                addExtraButton(label, color, keyCode)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshOverlay() {
        val intent = Intent(this, OverlayService::class.java).apply { action = "ACTION_REFRESH" }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
    }
}
