package com.gamepad.overlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.hardware.input.InputManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import java.lang.reflect.Method

/**
 * Accessibility service — injects real controller KeyEvents using
 * InputManager reflection, called from WITHIN the accessibility service
 * context (same trick as Key Mapper). Falls back to gesture taps only
 * if injection is blocked.
 */
class InputService : AccessibilityService() {

    enum class InjectResult { SUCCESS, FAILED }

    companion object {
        @Volatile var instance: InputService? = null

        // Cache reflection handles
        private var imInstance: Any?  = null
        private var imInject: Method? = null

        private fun ensureReflection(): Boolean {
            if (imInstance != null && imInject != null) return true
            return try {
                imInstance = InputManager::class.java
                    .getDeclaredMethod("getInstance")
                    .invoke(null)
                imInject = InputManager::class.java
                    .getDeclaredMethod("injectInputEvent",
                        InputEvent::class.java, Int::class.java)
                    .also { it.isAccessible = true }
                true
            } catch (e: Exception) { false }
        }

        /**
         * Inject a DOWN or UP gamepad KeyEvent.
         * Must be called from the main/accessibility thread.
         */
        fun injectKey(keyCode: Int, down: Boolean): InjectResult {
            if (!ensureReflection()) return InjectResult.FAILED
            return try {
                val ev = KeyEvent(
                    SystemClock.uptimeMillis(),
                    SystemClock.uptimeMillis(),
                    if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP,
                    keyCode, 0, 0,
                    KeyCharacterMap.VIRTUAL_KEYBOARD, 0,
                    KeyEvent.FLAG_FROM_SYSTEM or KeyEvent.FLAG_VIRTUAL_HARD_KEY,
                    InputDevice.SOURCE_GAMEPAD
                )
                // mode 0 = INJECT_INPUT_EVENT_MODE_ASYNC
                imInject!!.invoke(imInstance, ev, 0)
                InjectResult.SUCCESS
            } catch (e: Exception) {
                InjectResult.FAILED
            }
        }

        /**
         * Send a full button press: DOWN now, UP after [holdMs].
         * Schedules both calls on the main thread so they run in the
         * accessibility service context.
         */
        fun pressButton(keyCode: Int, holdMs: Long = 80L) {
            Handler(Looper.getMainLooper()).post {
                if (injectKey(keyCode, true) == InjectResult.SUCCESS) {
                    Handler(Looper.getMainLooper()).postDelayed(
                        { injectKey(keyCode, false) }, holdMs
                    )
                } else {
                    // Injection unavailable — tap at the button's screen pos
                    // (OverlayService handles this fallback via tapAtSelf)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        ensureReflection()   // warm up reflection handles early
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    // ── Gesture helpers (used as fallback when injection fails) ──────────────

    fun performTap(x: Float, y: Float, duration: Long = 60L) {
        val path   = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun performSwipe(startX: Float, startY: Float, dx: Float, dy: Float, duration: Long) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(startX + dx, startY + dy)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration.coerceAtLeast(50L))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
