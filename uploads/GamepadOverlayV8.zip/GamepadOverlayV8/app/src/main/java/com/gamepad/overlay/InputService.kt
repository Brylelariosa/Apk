package com.gamepad.overlay

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.hardware.input.InputManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import java.lang.reflect.Method

/**
 * Accessibility service that injects real controller KeyEvents via InputManager
 * reflection, or falls back to touch gestures when injection is unavailable.
 */
class InputService : AccessibilityService() {

    enum class InjectResult { SUCCESS, PERMISSION_DENIED, UNAVAILABLE }

    companion object {
        @Volatile var instance: InputService? = null

        private val imInstance: Any? by lazy {
            runCatching {
                InputManager::class.java.getDeclaredMethod("getInstance").invoke(null)
            }.getOrNull()
        }

        private val imInjectMethod: Method? by lazy {
            runCatching {
                InputManager::class.java
                    .getDeclaredMethod("injectInputEvent", InputEvent::class.java, Int::class.java)
                    .also { it.isAccessible = true }
            }.getOrNull()
        }

        fun injectKey(keyCode: Int, down: Boolean): InjectResult {
            val im     = imInstance     ?: return InjectResult.UNAVAILABLE
            val method = imInjectMethod ?: return InjectResult.UNAVAILABLE
            return runCatching {
                val kev = KeyEvent(
                    SystemClock.uptimeMillis(), SystemClock.uptimeMillis(),
                    if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP,
                    keyCode, 0, 0,
                    KeyCharacterMap.VIRTUAL_KEYBOARD, 0,
                    KeyEvent.FLAG_FROM_SYSTEM or KeyEvent.FLAG_VIRTUAL_HARD_KEY,
                    InputDevice.SOURCE_GAMEPAD
                )
                method.invoke(im, kev, 0)
                InjectResult.SUCCESS
            }.getOrElse { e ->
                if (e is SecurityException || e.cause is SecurityException)
                    InjectResult.PERMISSION_DENIED
                else
                    InjectResult.UNAVAILABLE
            }
        }

        /** DOWN now + UP 80 ms later. Returns result of the DOWN. */
        fun performKeyTap(keyCode: Int): InjectResult {
            val result = injectKey(keyCode, true)
            if (result == InjectResult.SUCCESS) {
                Handler(Looper.getMainLooper()).postDelayed({ injectKey(keyCode, false) }, 80L)
            }
            return result
        }
    }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy()         { super.onDestroy();           instance = null }

    fun performTap(x: Float, y: Float, duration: Long = 60L) {
        val path   = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun performSwipe(startX: Float, startY: Float, dx: Float, dy: Float, duration: Long) {
        val path = Path().apply {
            moveTo(startX, startY); lineTo(startX + dx, startY + dy)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, duration.coerceAtLeast(50L))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
