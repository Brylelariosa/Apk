package com.gamepad.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.sqrt

class OverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "gamepad_overlay_channel"
        private const val NOTIF_ID   = 42
        const val PREFS              = "gamepad_overlay_prefs"

        // Default keycode for each button tag (used for injection)
        val DEFAULT_KEYCODE = mapOf(
            "btn_a"      to android.view.KeyEvent.KEYCODE_BUTTON_A,
            "btn_b"      to android.view.KeyEvent.KEYCODE_BUTTON_B,
            "btn_x"      to android.view.KeyEvent.KEYCODE_BUTTON_X,
            "btn_y"      to android.view.KeyEvent.KEYCODE_BUTTON_Y,
            "btn_lb"     to android.view.KeyEvent.KEYCODE_BUTTON_L1,
            "btn_rb"     to android.view.KeyEvent.KEYCODE_BUTTON_R1,
            "btn_lt"     to android.view.KeyEvent.KEYCODE_BUTTON_L2,
            "btn_rt"     to android.view.KeyEvent.KEYCODE_BUTTON_R2,
            "btn_start"  to android.view.KeyEvent.KEYCODE_BUTTON_START,
            "btn_select" to android.view.KeyEvent.KEYCODE_BUTTON_SELECT,
            "btn_l3"     to android.view.KeyEvent.KEYCODE_BUTTON_THUMBL,
            "btn_r3"     to android.view.KeyEvent.KEYCODE_BUTTON_THUMBR,
            "btn_c"      to android.view.KeyEvent.KEYCODE_BUTTON_C,
            "btn_z"      to android.view.KeyEvent.KEYCODE_BUTTON_Z,
            "dpad_up"    to android.view.KeyEvent.KEYCODE_DPAD_UP,
            "dpad_dn"    to android.view.KeyEvent.KEYCODE_DPAD_DOWN,
            "dpad_lt"    to android.view.KeyEvent.KEYCODE_DPAD_LEFT,
            "dpad_rt"    to android.view.KeyEvent.KEYCODE_DPAD_RIGHT,
        )

        // All possible buttons. Order = order shown in add-button list.
        data class BtnDef(
            val tag: String,
            val label: String,
            val color: Int,
            val sizeDp: Float = 54f,
            val defXFrac: Float = 0.5f,   // default x as fraction of screenW
            val defYFrac: Float = 0.5f,   // default y as fraction of screenH
        )

        val ALL_BUTTONS = listOf(
            BtnDef("btn_a",     "A",  Color.argb(220,   0,160, 70), 54f, 0.82f, 0.72f),
            BtnDef("btn_b",     "B",  Color.argb(220, 210, 40, 40), 54f, 0.90f, 0.65f),
            BtnDef("btn_x",     "X",  Color.argb(220,  20,100,210), 54f, 0.74f, 0.65f),
            BtnDef("btn_y",     "Y",  Color.argb(220, 200,160,  0), 54f, 0.82f, 0.58f),
            BtnDef("btn_lb",    "LB", Color.argb(200,  60, 60,160), 72f, 0.04f, 0.06f),
            BtnDef("btn_rb",    "RB", Color.argb(200,  60, 60,160), 72f, 0.77f, 0.06f),
            BtnDef("btn_lt",    "LT", Color.argb(200,  40, 40,130), 60f, 0.15f, 0.02f),
            BtnDef("btn_rt",    "RT", Color.argb(200,  40, 40,130), 60f, 0.68f, 0.02f),
            BtnDef("btn_start", "▶",  Color.argb(160,  50, 50,100), 44f, 0.58f, 0.06f),
            BtnDef("btn_select","☰",  Color.argb(160,  50, 50,100), 44f, 0.42f, 0.06f),
            BtnDef("dpad_up",   "▲",  Color.argb(200,  70, 70,110), 46f, 0.15f, 0.60f),
            BtnDef("dpad_dn",   "▼",  Color.argb(200,  70, 70,110), 46f, 0.15f, 0.74f),
            BtnDef("dpad_lt",   "◄",  Color.argb(200,  70, 70,110), 46f, 0.07f, 0.67f),
            BtnDef("dpad_rt",   "►",  Color.argb(200,  70, 70,110), 46f, 0.23f, 0.67f),
            BtnDef("btn_l3",    "L3", Color.argb(200,  60, 60,100), 48f, 0.30f, 0.85f),
            BtnDef("btn_r3",    "R3", Color.argb(200,  60, 60,100), 48f, 0.65f, 0.85f),
            BtnDef("btn_c",     "C",  Color.argb(200, 150,120, 20), 48f, 0.50f, 0.80f),
            BtnDef("btn_z",     "Z",  Color.argb(200,  80, 50,150), 48f, 0.50f, 0.72f),
            BtnDef("joy",       "🕹", Color.argb(180,  40, 40, 80),160f, 0.04f, 0.65f),
        )

        // Default active set when first installed (basic GBA layout)
        val DEFAULT_ACTIVE = setOf(
            "joy","btn_a","btn_b","btn_start","btn_select",
            "dpad_up","dpad_dn","dpad_lt","dpad_rt"
        )

        fun defFor(tag: String) = ALL_BUTTONS.find { it.tag == tag }
    }

    private lateinit var wm: WindowManager
    private val uiHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    private var screenW = 0f
    private var screenH = 0f

    private data class WinEntry(
        val tag: String,
        val view: View,
        val params: WindowManager.LayoutParams,
        var xPct: Float,
        var yPct: Float,
        val wPx: Int,
        val hPx: Int,
        val alwaysVisible: Boolean = false
    )

    private val windows   = mutableListOf<WinEntry>()
    private var controlsVisible = true

    @Volatile private var joystickActive = false
    private var joystickThread: Thread? = null
    @Volatile private var joyNx = 0f
    @Volatile private var joyNy = 0f
    private var joystickEntry: WinEntry? = null

    private lateinit var displayManager: DisplayManager
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayChanged(id: Int) { uiHandler.post { onRotation() } }
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
    }

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.registerDisplayListener(displayListener, uiHandler)
        resolveScreen()
        createChannel()
        startForeground(NOTIF_ID, buildNotif())
        spawnControls()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "ACTION_STOP"    -> stopSelf()
            "ACTION_REFRESH" -> {
                joystickActive = false
                joystickThread?.interrupt()
                windows.forEach { runCatching { wm.removeView(it.view) } }
                windows.clear()
                joystickEntry = null
                spawnControls()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        joystickActive = false
        joystickThread?.interrupt()
        displayManager.unregisterDisplayListener(displayListener)
        windows.forEach { runCatching { wm.removeView(it.view) } }
        windows.clear()
        super.onDestroy()
    }

    // ── Screen ────────────────────────────────────────────────────────────────

    private fun resolveScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width().toFloat(); screenH = b.height().toFloat()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels.toFloat(); screenH = dm.heightPixels.toFloat()
        }
    }

    private fun onRotation() {
        resolveScreen()
        windows.forEach { e ->
            e.params.x = (e.xPct * screenW).toInt()
                .coerceIn(0, (screenW - e.wPx).toInt().coerceAtLeast(0))
            e.params.y = (e.yPct * screenH).toInt()
                .coerceIn(0, (screenH - e.hPx).toInt().coerceAtLeast(0))
            runCatching { wm.updateViewLayout(e.view, e.params) }
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Gamepad Overlay",
                NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification {
        val openPi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(this, 1,
            Intent(this, OverlayService::class.java).apply { action = "ACTION_STOP" },
            PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Gamepad Overlay Active")
            .setContentText("Drag buttons onto the game's on-screen controls")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_delete, "Stop", stopPi)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true).build()
    }

    // ── Prefs ─────────────────────────────────────────────────────────────────

    fun activeButtons(): Set<String> =
        prefs.getStringSet("active_buttons", null) ?: DEFAULT_ACTIVE

    private fun savedX(tag: String, def: Float) = prefs.getFloat("${tag}_x", def)
    private fun savedY(tag: String, def: Float) = prefs.getFloat("${tag}_y", def)
    private fun savePos(tag: String, xPct: Float, yPct: Float) {
        prefs.edit().putFloat("${tag}_x", xPct).putFloat("${tag}_y", yPct).apply()
    }

    // ── Spawn ─────────────────────────────────────────────────────────────────

    private fun spawnControls() {
        val dp = resources.displayMetrics.density
        fun px(v: Float) = (v * dp).toInt()

        val active = activeButtons()

        for (def in ALL_BUTTONS) {
            if (def.tag !in active) continue

            if (def.tag == "joy") {
                val joyPx = px(def.sizeDp)
                val joyView = JoystickView(this).apply {
                    onMoveListener = { nx, ny ->
                        joyNx = nx; joyNy = ny
                        val moving = abs(nx) > 0.12f || abs(ny) > 0.12f
                        if (!joystickActive && moving) { joystickActive = true; startJoystickLoop() }
                        else if (!moving) joystickActive = false
                    }
                    onReleaseListener = { joystickActive = false }
                }
                joystickEntry = addWin("joy", joyView, joyPx, joyPx,
                    savedX("joy", def.defXFrac), savedY("joy", def.defYFrac), draggable = true)
                continue
            }

            val sizePx = px(def.sizeDp)
            val view = makeBtn(def.label, def.color) {
                vibrate(40)
                fireButton(def.tag)
            }
            addWin(def.tag, view, sizePx, sizePx,
                savedX(def.tag, def.defXFrac),
                savedY(def.tag, def.defYFrac),
                draggable = true,
                alwaysVisible = def.tag in setOf("btn_lt","btn_rt","btn_lb","btn_rb","btn_start","btn_select")
            )
        }

        // Visibility toggle — always present
        val tSz = px(40f)
        addWin("toggle", makeBtn("👁", Color.argb(200, 30, 30, 70)) {
            controlsVisible = !controlsVisible
            windows.forEach { e ->
                if (!e.alwaysVisible)
                    e.view.visibility = if (controlsVisible) View.VISIBLE else View.INVISIBLE
            }
        }, tSz, tSz,
            savedX("toggle", (screenW - tSz - px(16f)) / screenW),
            savedY("toggle", px(70f) / screenH),
            draggable = true, alwaysVisible = true)
    }

    // ── Fire button: inject key or fall back to screen tap ──────────────────

    // true once injection confirmed working, false once confirmed failing
    @Volatile private var injectionWorking: Boolean? = null

    private fun fireButton(tag: String) {
        val keyCode = DEFAULT_KEYCODE[tag]

        // Try injection if not yet known to fail
        if (injectionWorking != false && keyCode != null) {
            val result = InputService.injectKey(keyCode, true)
            if (result == InputService.InjectResult.SUCCESS) {
                injectionWorking = true
                uiHandler.postDelayed({ InputService.injectKey(keyCode, false) }, 80L)
                return
            } else {
                injectionWorking = false
                android.widget.Toast.makeText(this,
                    "Key injection unavailable on this ROM — using screen tap fallback",
                    android.widget.Toast.LENGTH_LONG).show()
            }
        }

        // Fallback: tap at this button's screen position
        tapAtSelf(tag)
    }

    private fun tapAtSelf(tag: String) {
        val e  = windows.find { it.tag == tag } ?: return
        val cx = e.params.x + e.wPx / 2f
        val cy = e.params.y + e.hPx / 2f

        val baseFlags = e.params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        e.params.flags = baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        runCatching { wm.updateViewLayout(e.view, e.params) }

        uiHandler.postDelayed({
            InputService.instance?.performTap(cx, cy, 80L)
            uiHandler.postDelayed({
                e.params.flags = baseFlags
                runCatching { wm.updateViewLayout(e.view, e.params) }
            }, 150L)
        }, 50L)
    }

    // ── Joystick swipe loop ───────────────────────────────────────────────────

    private fun startJoystickLoop() {
        joystickThread?.interrupt()
        joystickThread = Thread {
            while (joystickActive && !Thread.currentThread().isInterrupted) {
                val nx = joyNx; val ny = joyNy
                val mag = sqrt(nx * nx + ny * ny)
                if (mag > 0.15f) {
                    val e    = joystickEntry
                    val sx   = if (e != null) e.params.x + e.wPx / 2f else screenW * 0.5f
                    val sy   = if (e != null) e.params.y + e.hPx / 2f else screenH * 0.55f
                    val dist = (mag * 160f).coerceIn(30f, 200f)

                    if (e != null) {
                        // All on main thread: set flag → wait 1 frame → swipe → restore
                        uiHandler.post {
                            val baseFlags = e.params.flags and
                                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                            e.params.flags = baseFlags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            runCatching { wm.updateViewLayout(e.view, e.params) }
                            uiHandler.postDelayed({
                                InputService.instance?.performSwipe(sx, sy, nx * dist, ny * dist, 90)
                                uiHandler.postDelayed({
                                    e.params.flags = baseFlags
                                    runCatching { wm.updateViewLayout(e.view, e.params) }
                                }, 150L)
                            }, 50L)
                        }
                    } else {
                        InputService.instance?.performSwipe(sx, sy, nx * dist, ny * dist, 90)
                    }
                }
                try { Thread.sleep(110) } catch (_: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    // ── Window helpers ────────────────────────────────────────────────────────

    private fun addWin(
        tag: String, view: View,
        wPx: Int, hPx: Int,
        xPct: Float, yPct: Float,
        draggable: Boolean,
        alwaysVisible: Boolean = false
    ): WinEntry {
        val params = WindowManager.LayoutParams(
            wPx, hPx,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (xPct * screenW).toInt()
            y = (yPct * screenH).toInt()
        }
        val entry = WinEntry(tag, view, params, xPct, yPct, wPx, hPx, alwaysVisible)
        if (draggable) attachDrag(view, entry)
        windows.add(entry)
        wm.addView(view, params)
        return entry
    }

    private fun attachDrag(view: View, entry: WinEntry) {
        var dragging = false
        var downRawX = 0f; var downRawY = 0f
        var startX = 0; var startY = 0
        var longPressRunnable: Runnable? = null
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()

        view.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX; downRawY = ev.rawY
                    startX = entry.params.x; startY = entry.params.y
                    dragging = false
                    longPressRunnable?.let { v.removeCallbacks(it) }
                    longPressRunnable = Runnable {
                        dragging = true
                        v.performHapticFeedback(
                            android.view.HapticFeedbackConstants.LONG_PRESS,
                            android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                        )
                        v.alpha = 0.55f
                    }.also { v.postDelayed(it, 450L) }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX; val dy = ev.rawY - downRawY
                    if (dragging) {
                        entry.params.x = (startX + dx).toInt()
                            .coerceIn(0, (screenW - entry.wPx).toInt().coerceAtLeast(0))
                        entry.params.y = (startY + dy).toInt()
                            .coerceIn(0, (screenH - entry.hPx).toInt().coerceAtLeast(0))
                        runCatching { wm.updateViewLayout(v, entry.params) }
                    } else if (dx * dx + dy * dy > touchSlop * touchSlop) {
                        longPressRunnable?.let { v.removeCallbacks(it) }
                        longPressRunnable = null
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    longPressRunnable?.let { v.removeCallbacks(it) }
                    longPressRunnable = null
                    if (dragging) {
                        dragging = false; v.alpha = 1f
                        entry.xPct = entry.params.x / screenW
                        entry.yPct = entry.params.y / screenH
                        savePos(entry.tag, entry.xPct, entry.yPct)
                    } else {
                        v.performClick()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    longPressRunnable?.let { v.removeCallbacks(it) }
                    longPressRunnable = null
                    if (dragging) { dragging = false; v.alpha = 1f }
                    true
                }
                else -> false
            }
        }
    }

    private fun makeBtn(label: String, bgColor: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = if (label.length <= 2) 15f else 11f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(bgColor)
                setStroke(3, Color.argb(140, 200, 200, 255))
            }
            isFocusable = false; isClickable = true
            isHapticFeedbackEnabled = true
            setOnClickListener { v ->
                if (prefs.getBoolean("vibration_enabled", true)) {
                    v.performHapticFeedback(
                        android.view.HapticFeedbackConstants.VIRTUAL_KEY,
                        android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                    )
                    vibrateService(40)
                }
                onClick()
            }
        }

    // ── Vibration ─────────────────────────────────────────────────────────────

    private fun vibrateService(ms: Long) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
                    .vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                else @Suppress("DEPRECATION") v.vibrate(ms)
            }
        }
    }

    private fun vibrate(ms: Long) {
        if (!prefs.getBoolean("vibration_enabled", true)) return
        vibrateService(ms)
    }
}
