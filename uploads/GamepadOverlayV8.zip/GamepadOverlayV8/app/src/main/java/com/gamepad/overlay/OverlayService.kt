package com.gamepad.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.sqrt

class OverlayService : Service() {

    companion object {
        private const val CHANNEL_ID = "gamepad_overlay_channel"
        private const val NOTIF_ID   = 42
        const val PREFS              = "gamepad_overlay_prefs"

        /** Default controller keycode for each built-in button tag. */
        val DEFAULT_KEYCODES: Map<String, Int> = mapOf(
            "btn_a"      to KeyEvent.KEYCODE_BUTTON_A,
            "btn_b"      to KeyEvent.KEYCODE_BUTTON_B,
            "btn_x"      to KeyEvent.KEYCODE_BUTTON_X,
            "btn_y"      to KeyEvent.KEYCODE_BUTTON_Y,
            "btn_lb"     to KeyEvent.KEYCODE_BUTTON_L1,
            "btn_rb"     to KeyEvent.KEYCODE_BUTTON_R1,
            "btn_lt"     to KeyEvent.KEYCODE_BUTTON_L2,
            "btn_rt"     to KeyEvent.KEYCODE_BUTTON_R2,
            "btn_start"  to KeyEvent.KEYCODE_BUTTON_START,
            "btn_select" to KeyEvent.KEYCODE_BUTTON_SELECT,
            "dpad_up"    to KeyEvent.KEYCODE_DPAD_UP,
            "dpad_dn"    to KeyEvent.KEYCODE_DPAD_DOWN,
            "dpad_lt"    to KeyEvent.KEYCODE_DPAD_LEFT,
            "dpad_rt"    to KeyEvent.KEYCODE_DPAD_RIGHT,
        )
    }

    private lateinit var wm: WindowManager
    private val uiHandler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    private var screenW = 0f
    private var screenH = 0f

    private data class WinEntry(
        val tag: String,
        val view: View,
        val params: WindowManager.LayoutParams,
        var xPct: Float,
        var yPct: Float,
        val wPx: Int,
        val hPx: Int,
        val alwaysVisible: Boolean = false
    )

    private val windows = mutableListOf<WinEntry>()
    private var controlsVisible = true

    @Volatile private var joystickActive = false
    private var joystickThread: Thread? = null
    @Volatile private var joyNx = 0f
    @Volatile private var joyNy = 0f
    @Volatile private var heldJoyKeys: Set<Int> = emptySet()
    private var joystickEntry: WinEntry? = null

    /** True once injection fails due to missing permission — then we stay in tap-fallback mode. */
    @Volatile private var injectionFailed = false
    private var injectionHintShown = false

    private lateinit var displayManager: DisplayManager
    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayChanged(displayId: Int) { uiHandler.post { onRotation() } }
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
    }

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.registerDisplayListener(displayListener, uiHandler)
        resolveScreen()
        createChannel()
        startForeground(NOTIF_ID, buildNotif())
        spawnControls()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "ACTION_STOP"    -> stopSelf()
            "ACTION_REFRESH" -> {
                joystickActive = false
                joystickThread?.interrupt()
                releaseAllJoyKeys()
                windows.forEach { runCatching { wm.removeView(it.view) } }
                windows.clear()
                joystickEntry = null
                spawnControls()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        joystickActive = false
        joystickThread?.interrupt()
        releaseAllJoyKeys()
        displayManager.unregisterDisplayListener(displayListener)
        windows.forEach { runCatching { wm.removeView(it.view) } }
        windows.clear()
        super.onDestroy()
    }

    // ── Key injection with tap fallback ──────────────────────────────────────

    /**
     * Press [tag]'s configured controller button.
     * Tries real key injection first; falls back to tapping at the button's
     * screen position if injection is blocked.
     */
    private fun fireButton(tag: String) {
        val keyCode = getSavedKeyCode(tag)
        if (!injectionFailed && keyCode > 0) {
            when (InputService.performKeyTap(keyCode)) {
                InputService.InjectResult.SUCCESS -> return
                InputService.InjectResult.PERMISSION_DENIED -> {
                    injectionFailed = true
                    if (!injectionHintShown) {
                        injectionHintShown = true
                        uiHandler.post {
                            Toast.makeText(
                                this,
                                "⚠ Key injection blocked.\n" +
                                "Grant via ADB (some ROMs):\n" +
                                "pm grant $packageName android.permission.INJECT_EVENTS\n" +
                                "Falling back to screen tap.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                    tapAtSelf(tag)
                }
                InputService.InjectResult.UNAVAILABLE -> tapAtSelf(tag)
            }
        } else {
            tapAtSelf(tag)   // keyCode == -1  → user chose "Tap Screen" mode
        }
    }

    private fun getSavedKeyCode(tag: String): Int =
        prefs.getInt("${tag}_keycode", DEFAULT_KEYCODES[tag] ?: -1)

    // ── Screen resolution ─────────────────────────────────────────────────────

    private fun resolveScreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width().toFloat(); screenH = b.height().toFloat()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            screenW = dm.widthPixels.toFloat(); screenH = dm.heightPixels.toFloat()
        }
    }

    private fun onRotation() {
        resolveScreen()
        windows.forEach { e ->
            e.params.x = (e.xPct * screenW).toInt()
                .coerceIn(0, (screenW - e.wPx).toInt().coerceAtLeast(0))
            e.params.y = (e.yPct * screenH).toInt()
                .coerceIn(0, (screenH - e.hPx).toInt().coerceAtLeast(0))
            runCatching { wm.updateViewLayout(e.view, e.params) }
        }
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Gamepad Overlay",
                NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(ch)
        }
    }

    private fun buildNotif(): Notification {
        val openPi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(this, 1,
            Intent(this, OverlayService::class.java).apply { action = "ACTION_STOP" },
            PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Gamepad Overlay Active")
            .setContentText("Controller keys active — long-press a button to drag it")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_delete, "Stop", stopPi)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true).build()
    }

    // ── Prefs helpers ─────────────────────────────────────────────────────────

    private fun savedX(tag: String, default: Float) = prefs.getFloat("${tag}_x", default)
    private fun savedY(tag: String, default: Float) = prefs.getFloat("${tag}_y", default)
    private fun savePos(tag: String, xPct: Float, yPct: Float) {
        prefs.edit().putFloat("${tag}_x", xPct).putFloat("${tag}_y", yPct).apply()
    }

    // ── Controls factory ──────────────────────────────────────────────────────

    private fun spawnControls() {
        val dp = resources.displayMetrics.density
        fun px(v: Float) = (v * dp).toInt()

        val showJoystick = prefs.getBoolean("show_joystick", true)
        val showDpad     = prefs.getBoolean("show_dpad",     true)
        val showABXY     = prefs.getBoolean("show_abxy",     true)
        val showShoulder = prefs.getBoolean("show_shoulder", true)
        val showCenter   = prefs.getBoolean("show_center",   true)

        // ── Joystick ──────────────────────────────────────────────────────────
        if (showJoystick) {
            val joyPx = px(160f)
            val defX  = px(16f) / screenW
            val defY  = (screenH - joyPx - px(60f)) / screenH
            val joyView = JoystickView(this).apply {
                onMoveListener = { nx, ny ->
                    joyNx = nx; joyNy = ny
                    val moving = abs(nx) > 0.12f || abs(ny) > 0.12f
                    if (!joystickActive && moving) { joystickActive = true; startJoystickLoop() }
                    else if (!moving) { joystickActive = false }
                }
                onReleaseListener = {
                    joystickActive = false
                    releaseAllJoyKeys()
                }
            }
            joystickEntry = addWin("joy", joyView, joyPx, joyPx,
                xPct = savedX("joy", defX), yPct = savedY("joy", defY), draggable = true)
        }

        // ── D-Pad ─────────────────────────────────────────────────────────────
        if (showDpad) {
            val dSz = px(46f); val dGap = px(50f)
            val dcx = px(290f).toInt(); val dcy = (screenH - px(185f)).toInt()
            fun dBtn(tag: String, label: String, dx: Int, dy: Int) {
                val defX = (dcx + dx - dSz / 2f) / screenW
                val defY = (dcy + dy - dSz / 2f) / screenH
                addWin(tag, makeBtn(label, Color.argb(200, 70, 70, 100)) {
                    vibrate(18); fireButton(tag) },
                    dSz, dSz, savedX(tag, defX), savedY(tag, defY), draggable = true)
            }
            dBtn("dpad_up", "▲",    0, -dGap)
            dBtn("dpad_dn", "▼",    0, +dGap)
            dBtn("dpad_lt", "◄", -dGap,    0)
            dBtn("dpad_rt", "►", +dGap,    0)
        }

        // ── ABXY ──────────────────────────────────────────────────────────────
        if (showABXY) {
            val aSz = px(54f); val aGap = px(56f)
            val acx = (screenW - px(90f)).toInt(); val acy = (screenH - px(130f)).toInt()
            fun aBtn(tag: String, label: String, color: Int, dx: Int, dy: Int) {
                val defX = (acx + dx - aSz / 2f) / screenW
                val defY = (acy + dy - aSz / 2f) / screenH
                addWin(tag, makeBtn(label, color) { vibrate(40); fireButton(tag) },
                    aSz, aSz, savedX(tag, defX), savedY(tag, defY), draggable = true)
            }
            aBtn("btn_a", "A", Color.argb(220,   0, 160,  70),    0, +aGap)
            aBtn("btn_b", "B", Color.argb(220, 210,  40,  40), +aGap,    0)
            aBtn("btn_x", "X", Color.argb(220,  20, 100, 210), -aGap,    0)
            aBtn("btn_y", "Y", Color.argb(220, 200, 160,   0),    0, -aGap)
        }

        // ── Shoulder buttons ──────────────────────────────────────────────────
        if (showShoulder) {
            val bW = px(72f); val bH = px(36f)
            val ltW = px(60f); val ltH = px(30f)
            fun shBtn(tag: String, label: String, defXPx: Float, defYPx: Float, w: Int, h: Int) {
                addWin(tag, makeBtn(label, Color.argb(200, 60, 60, 160)) {
                    vibrate(25); fireButton(tag) },
                    w, h,
                    savedX(tag, defXPx / screenW), savedY(tag, defYPx / screenH),
                    draggable = true, alwaysVisible = true)
            }
            shBtn("btn_lb", "LB", px(16f).toFloat(),       px(24f).toFloat(), bW, bH)
            shBtn("btn_rb", "RB", screenW - bW - px(16f),  px(24f).toFloat(), bW, bH)
            shBtn("btn_lt", "LT", px(94f).toFloat(),       px(10f).toFloat(), ltW, ltH)
            shBtn("btn_rt", "RT", screenW - ltW - px(94f), px(10f).toFloat(), ltW, ltH)
        }

        // ── Center (Start / Select) ───────────────────────────────────────────
        if (showCenter) {
            val sW = px(44f); val sH = px(28f)
            fun cenBtn(tag: String, label: String, defXPx: Float, defYPx: Float) {
                addWin(tag, makeBtn(label, Color.argb(160, 50, 50, 100)) {
                    vibrate(20); fireButton(tag) },
                    sW, sH,
                    savedX(tag, defXPx / screenW), savedY(tag, defYPx / screenH),
                    draggable = true, alwaysVisible = true)
            }
            cenBtn("btn_start",  "▶", screenW / 2f + px(10f),      px(20f).toFloat())
            cenBtn("btn_select", "☰", screenW / 2f - sW - px(10f), px(20f).toFloat())
        }

        // ── Extra buttons ─────────────────────────────────────────────────────
        val extraCount = prefs.getInt("extra_btn_count", 0)
        for (i in 0 until extraCount) {
            val tag   = "extra_$i"
            val label = prefs.getString("${tag}_label", "?") ?: "?"
            val color = prefs.getInt("${tag}_color", Color.argb(200, 90, 60, 160))
            val eSz   = px(54f)
            addWin(tag, makeBtn(label, color) { vibrate(40); fireButton(tag) },
                eSz, eSz, savedX(tag, 0.5f), savedY(tag, 0.5f), draggable = true)
        }

        // ── Visibility toggle ─────────────────────────────────────────────────
        val tSz = px(46f)
        val togView = makeBtn("👁", Color.argb(200, 30, 30, 70)) {
            controlsVisible = !controlsVisible
            windows.forEach { e ->
                if (!e.alwaysVisible)
                    e.view.visibility = if (controlsVisible) View.VISIBLE else View.INVISIBLE
            }
        }
        addWin("toggle", togView, tSz, tSz,
            xPct = savedX("toggle", (screenW - tSz - px(16f)) / screenW),
            yPct = savedY("toggle", px(70f) / screenH),
            draggable = true, alwaysVisible = true)
    }

    // ── Tap fallback ──────────────────────────────────────────────────────────

    private fun tapAtSelf(tag: String) {
        val e  = windows.find { it.tag == tag } ?: return
        val cx = e.params.x + e.wPx / 2f
        val cy = e.params.y + e.hPx / 2f
        InputService.instance?.performTap(cx, cy)
    }

    // ── Joystick loop (key injection with swipe fallback) ─────────────────────

    private fun releaseAllJoyKeys() {
        val keys = heldJoyKeys
        heldJoyKeys = emptySet()
        keys.forEach { InputService.injectKey(it, false) }
    }

    private fun startJoystickLoop() {
        joystickThread?.interrupt()
        joystickThread = Thread {
            var useSwipeFallback = injectionFailed   // start in swipe mode if injection already known-broken
            while (joystickActive && !Thread.currentThread().isInterrupted) {
                val nx  = joyNx; val ny = joyNy
                val mag = sqrt(nx * nx + ny * ny)

                if (!useSwipeFallback) {
                    // Build desired key set
                    val newKeys = mutableSetOf<Int>()
                    if (mag > 0.15f) {
                        val diagonal = mag > 0.55f && abs(nx) > 0.3f && abs(ny) > 0.3f
                        if (diagonal || abs(ny) >= abs(nx))
                            newKeys += if (ny < 0) KeyEvent.KEYCODE_DPAD_UP else KeyEvent.KEYCODE_DPAD_DOWN
                        if (diagonal || abs(nx) >= abs(ny))
                            newKeys += if (nx < 0) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
                    }
                    // Release keys no longer needed
                    (heldJoyKeys - newKeys).forEach { InputService.injectKey(it, false) }
                    // Press newly needed keys; detect permission failure
                    var blocked = false
                    (newKeys - heldJoyKeys).forEach { kc ->
                        if (InputService.injectKey(kc, true) == InputService.InjectResult.PERMISSION_DENIED) {
                            blocked = true
                        }
                    }
                    heldJoyKeys = newKeys

                    if (blocked) {
                        injectionFailed = true
                        heldJoyKeys.forEach { InputService.injectKey(it, false) }
                        heldJoyKeys = emptySet()
                        useSwipeFallback = true
                    }
                } else {
                    // Swipe fallback for joystick
                    if (mag > 0.15f) {
                        val e    = joystickEntry
                        val sx   = if (e != null) e.params.x + e.wPx / 2f else screenW * 0.5f
                        val sy   = if (e != null) e.params.y + e.hPx / 2f else screenH * 0.55f
                        val dist = (mag * 160f).coerceIn(30f, 200f)
                        InputService.instance?.performSwipe(sx, sy, nx * dist, ny * dist, 90)
                    }
                }

                try { Thread.sleep(100) } catch (_: InterruptedException) { break }
            }
            heldJoyKeys.forEach { InputService.injectKey(it, false) }
            heldJoyKeys = emptySet()
        }.also { it.isDaemon = true; it.start() }
    }

    // ── Window helpers ────────────────────────────────────────────────────────

    private fun addWin(
        tag: String, view: View,
        wPx: Int, hPx: Int,
        xPct: Float, yPct: Float,
        draggable: Boolean,
        alwaysVisible: Boolean = false
    ): WinEntry {
        val params = WindowManager.LayoutParams(
            wPx, hPx,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (xPct * screenW).toInt()
            y = (yPct * screenH).toInt()
        }
        val entry = WinEntry(tag, view, params, xPct, yPct, wPx, hPx, alwaysVisible)
        if (draggable) attachDrag(view, entry)
        windows.add(entry)
        wm.addView(view, params)
        return entry
    }

    private fun attachDrag(view: View, entry: WinEntry) {
        var dragging = false
        var downRawX = 0f; var downRawY = 0f
        var startX = 0; var startY = 0
        var longPressRunnable: Runnable? = null
        val longPressDelayMs = 450L
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop.toFloat()

        view.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX; downRawY = ev.rawY
                    startX = entry.params.x; startY = entry.params.y
                    dragging = false
                    longPressRunnable?.let { v.removeCallbacks(it) }
                    longPressRunnable = Runnable {
                        dragging = true
                        v.performHapticFeedback(
                            android.view.HapticFeedbackConstants.LONG_PRESS,
                            android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                        )
                        vibrate(80)
                        v.alpha = 0.55f
                    }.also { v.postDelayed(it, longPressDelayMs) }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX; val dy = ev.rawY - downRawY
                    if (dragging) {
                        entry.params.x = (startX + dx).toInt()
                            .coerceIn(0, (screenW - entry.wPx).toInt().coerceAtLeast(0))
                        entry.params.y = (startY + dy).toInt()
                            .coerceIn(0, (screenH - entry.hPx).toInt().coerceAtLeast(0))
                        runCatching { wm.updateViewLayout(v, entry.params) }
                    } else if (dx * dx + dy * dy > touchSlop * touchSlop) {
                        longPressRunnable?.let { v.removeCallbacks(it) }
                        longPressRunnable = null
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    longPressRunnable?.let { v.removeCallbacks(it) }
                    longPressRunnable = null
                    if (dragging) {
                        dragging = false; v.alpha = 1f
                        entry.xPct = entry.params.x / screenW
                        entry.yPct = entry.params.y / screenH
                        savePos(entry.tag, entry.xPct, entry.yPct)
                    } else {
                        v.performClick()
                    }
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    longPressRunnable?.let { v.removeCallbacks(it) }
                    longPressRunnable = null
                    if (dragging) { dragging = false; v.alpha = 1f }
                    true
                }
                else -> false
            }
        }
    }

    private fun makeBtn(label: String, bgColor: Int, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = if (label.length <= 2) 15f else 11f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(bgColor)
                setStroke(3, Color.argb(140, 200, 200, 255))
            }
            isFocusable = false
            isClickable = true
            // View-level haptic works even when Vibrator service is blocked by XOS/MIUI etc.
            isHapticFeedbackEnabled = true
            setOnClickListener { v ->
                if (prefs.getBoolean("vibration_enabled", true)) {
                    // Primary: view haptic — bypasses background-service vibration restrictions
                    v.performHapticFeedback(
                        android.view.HapticFeedbackConstants.VIRTUAL_KEY,
                        android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
                    )
                    // Secondary: Vibrator service for stronger / longer pulses
                    vibrate(40)
                }
                onClick()
            }
        }

    // ── Vibration (secondary — view haptic is primary) ────────────────────────
    private fun vibrate(ms: Long) {
        if (!prefs.getBoolean("vibration_enabled", true)) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
                    .vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
                else @Suppress("DEPRECATION") v.vibrate(ms)
            }
        }
    }
}
