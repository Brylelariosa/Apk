/*
 * mgba_jni.c — JNI bridge between mGBA core and Android/Kotlin.
 *
 * Fixes applied in this revision
 * ───────────────────────────────
 * FIX 1  pthread_mutex_t g_core_mutex protects g_core / g_fb.
 *         The original code had no synchronisation between nativeLoadROM
 *         (background thread) and nativeDestroy (UI thread via onDestroy),
 *         allowing concurrent destroy_core() calls — a double-free / use-
 *         after-free SIGSEGV.  Every JNI function that reads or writes the
 *         globals now takes the mutex.  g_core is only published after
 *         core->reset() completes, so nativeRunFrame never sees a half-
 *         initialised core.
 *
 * FIX 2  mCoreLoadConfig(core)  →  core->loadConfig(core).
 *         mCoreLoadConfig() tries to open $HOME/.config/mgba-android/config.ini.
 *         On Android, HOME / XDG_CONFIG_HOME are unset; VFileOpen() returns
 *         NULL and mCoreLoadConfig() returns false WITHOUT ever calling
 *         core->loadConfig().  Every option written by mCoreConfigLoadDefaults
 *         (skipBios, sampleRate, volume …) was silently discarded and
 *         core->opts stayed zeroed.  core->loadConfig() directly syncs
 *         core->config.opts → core->opts without touching the filesystem.
 *
 * FIX 3  nativeRunFrame pixel copy respects info.stride.
 *         The previous loop used dst[i] with a flat index i = 0 … w*h-1,
 *         treating the bitmap as a packed array.  Android bitmaps may have
 *         per-row padding (stride > width × 4), which caused every row after
 *         the first to be written at the wrong offset — a visible horizontal
 *         shift artefact.  The loop now addresses each row via
 *         (uint8_t*)pixels + row * info.stride.
 */

#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>
#include <pthread.h>

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <mgba/core/core.h>       /* mCoreLoadFile, mCoreInitConfig         */
#include <mgba/core/config.h>     /* mCoreOptions, mCoreConfigLoadDefaults  */
#include <mgba/core/log.h>        /* mLogSetDefaultLogger                   */
/* mColor is typedef uint32_t in every mGBA version.  We define it here
 * directly rather than including <mgba-util/image.h>, which is absent from
 * the mGBA 0.10.3 include tree and causes a fatal compile error.           */
#ifndef mColor
typedef uint32_t mColor;
#endif
#include <mgba/gba/core.h>        /* GBACoreCreate                          */

#define LOG_TAG "mGBA-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* ── Globals — all access must hold g_core_mutex ────────────────────────── */

static pthread_mutex_t g_core_mutex = PTHREAD_MUTEX_INITIALIZER;
static struct mCore   *g_core   = NULL;
static mColor         *g_fb     = NULL;
static int             g_width  = 240;
static int             g_height = 160;

/* ── Logger ─────────────────────────────────────────────────────────────── */

static void jni_log(struct mLogger *logger, int category,
                    enum mLogLevel level, const char *fmt, va_list args)
{
    (void)logger; (void)category; (void)level;
    char buf[512];
    vsnprintf(buf, sizeof(buf), fmt, args);
    LOGI("%s", buf);
}
static struct mLogger g_logger = { .log = jni_log };

/* ── Internal cleanup — CALLER MUST HOLD g_core_mutex ───────────────────── */

static void destroy_core(void)
{
    if (g_core) {
        g_core->deinit(g_core);
        g_core = NULL;
    }
    free(g_fb);
    g_fb = NULL;
}

/* ── nativeLoadROM ──────────────────────────────────────────────────────── */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadROM(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    /*
     * FIX 1 — tear down any previously loaded core while holding the lock
     * so that concurrent nativeRunFrame / nativeSetKeys calls see a clean
     * NULL and early-return rather than racing on a dangling pointer.
     */
    pthread_mutex_lock(&g_core_mutex);
    destroy_core();
    pthread_mutex_unlock(&g_core_mutex);

    mLogSetDefaultLogger(&g_logger);

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    if (!path) return JNI_FALSE;
    LOGI("Loading ROM: %s", path);

    /* 1. Create GBA core — GBA-only build; no auto-detect needed */
    struct mCore *core = GBACoreCreate();
    if (!core) {
        LOGE("GBACoreCreate failed");
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    /* 2. Allocate core-internal structures */
    if (!core->init(core)) {
        LOGE("core->init failed");
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    /*
     * 3. ── REQUIRED ── initialise config BEFORE touching anything else.
     *    Without this call, mCoreLoadFile dereferences uninitialised config
     *    memory → SIGSEGV.  (Original crash; this fix was already present.)
     */
    mCoreInitConfig(core, "mgba-android");

    /*
     * 4. Apply options.
     *
     * FIX 2 — use core->loadConfig(core), NOT mCoreLoadConfig(core).
     *
     * mCoreLoadConfig() tries to open $HOME/.config/mgba-android/config.ini.
     * On Android that path does not exist; VFileOpen() returns NULL and
     * mCoreLoadConfig() returns false WITHOUT calling core->loadConfig().
     * Every value written below by mCoreConfigLoadDefaults() would then be
     * silently ignored (core->opts stays all-zero, skipBios never takes
     * effect at reset time).
     *
     * core->loadConfig() reads directly from core->config.opts and syncs
     * them into core->opts — no filesystem access, always succeeds.
     */
    struct mCoreOptions opts;
    memset(&opts, 0, sizeof(opts));
    opts.skipBios     = true;
    opts.useBios      = false;
    opts.sampleRate   = 44100;
    opts.audioBuffers = 1024;
    opts.volume       = 256;
    mCoreConfigLoadDefaults(&core->config, &opts);
    /* mGBA 0.10.3 changed loadConfig to take an explicit config pointer.
     * Old API: loadConfig(struct mCore*)
     * New API: loadConfig(struct mCore*, const struct mCoreConfig*)        */
    core->loadConfig(core, &core->config);

    /* 5. GBA screen is always 240x160.
     *    baseVideoSize() was removed from struct mCore in mGBA 0.10.3 —
     *    there is no need to query it for a GBA-only build.               */
    const unsigned w = 240, h = 160;

    mColor *fb = (mColor *)calloc((size_t)w * (size_t)h, sizeof(mColor));
    if (!fb) {
        LOGE("framebuffer alloc failed (%ux%u)", w, h);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    core->setVideoBuffer(core, fb, (size_t)w);

    /* 6. Load the ROM from the cache-file path we were given */
    if (!mCoreLoadFile(core, path)) {
        LOGE("mCoreLoadFile failed: %s", path);
        free(fb);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    (*env)->ReleaseStringUTFChars(env, jpath, path);

    /* 7. Reset into known-good state; now reads synced core->opts */
    core->reset(core);

    /*
     * 8. FIX 1 — publish the new core atomically.
     *    We only set g_core after reset() completes so that nativeRunFrame
     *    never observes a core that has been init()-ed but not yet reset().
     *    g_width / g_height are also updated here under the same lock so
     *    nativeGetWidth / nativeGetHeight are always consistent with g_fb.
     */
    pthread_mutex_lock(&g_core_mutex);
    g_core   = core;
    g_fb     = fb;
    g_width  = (int)w;
    g_height = (int)h;
    pthread_mutex_unlock(&g_core_mutex);

    LOGI("ROM loaded OK — core=%p  %dx%d", (void*)core, (int)w, (int)h);
    return JNI_TRUE;
}

/* ── nativeRunFrame ─────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeRunFrame(
        JNIEnv *env, jobject thiz, jobject bitmap)
{
    /* FIX 1 — hold the lock for the entire frame so nativeDestroy cannot
     * free g_core / g_fb under us.                                       */
    pthread_mutex_lock(&g_core_mutex);
    if (!g_core || !g_fb) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    g_core->runFrame(g_core);

    /* ── Link cable SIO exchange (frame-boundary polling) ──────────────────
     * mGBA 0.10.3 does not expose a public callback-registration API.
     * We service any pending SIO transfer immediately after runFrame()
     * returns — equivalent to "start of next VBlank", which is exactly
     * when GBA link-cable games (including Pokémon Gen 3) initiate and
     * check transfers.  g_core_mutex is already held; env is available.   */
    if (g_link_active && g_link_obj && g_link_xchg_mid) {
        uint16_t siocnt = (uint16_t)g_core->rawRead16(g_core, 0x04000128, 0);
        if (siocnt & 0x0080u) {
            uint32_t local_data = g_core->rawRead32(g_core, 0x04000120, 0);
            uint32_t remote_data = link_exchange(env, local_data);

            /* NORMAL_32 / NORMAL_8 — SIODATA32 at 0x04000120 */
            g_core->rawWrite32(g_core, 0x04000120, 0, remote_data);

            /* MULTI mode — SIOMULTI0..3 at 0x04000120..0x04000126.
             * Host = player 0 (master), client = player 1 (slave).
             * Players 2 and 3 absent → 0xFFFF (GBA "not connected").     */
            uint16_t local16  = (uint16_t)(local_data  & 0xFFFFu);
            uint16_t remote16 = (uint16_t)(remote_data & 0xFFFFu);
            if (g_link_is_host) {
                g_core->rawWrite16(g_core, 0x04000120, 0, local16);   /* SIOMULTI0 */
                g_core->rawWrite16(g_core, 0x04000122, 0, remote16);  /* SIOMULTI1 */
            } else {
                g_core->rawWrite16(g_core, 0x04000120, 0, remote16);  /* SIOMULTI0 */
                g_core->rawWrite16(g_core, 0x04000122, 0, local16);   /* SIOMULTI1 */
            }
            g_core->rawWrite16(g_core, 0x04000124, 0, 0xFFFFu);       /* SIOMULTI2 */
            g_core->rawWrite16(g_core, 0x04000126, 0, 0xFFFFu);       /* SIOMULTI3 */

            /* Clear the start/busy bit so the game's polling loop exits. */
            g_core->rawWrite16(g_core, 0x04000128, 0, siocnt & ~0x0080u);
        }
    }

    /*
     * Convert mGBA native pixel format → Android ARGB_8888.
     *   mGBA GBA output: 0x00BBGGRR  (XBGR, X = unused/0)
     *   bswap32(0x00BBGGRR) = 0xRRGGBB00
     *   >> 8               = 0x00RRGGBB
     *   | 0xFF000000       = 0xFFRRGGBB   (Android ARGB_8888, fully opaque) ✓
     *
     * FIX 3 — address each destination row via info.stride rather than a
     * flat index.  When stride > width × 4 (padding for alignment), the
     * old loop wrote row N into the padding bytes of row N-1, causing a
     * one-row horizontal shift that accumulated across the whole screen.
     */
    AndroidBitmapInfo info;
    void *pixels = NULL;
    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) {
        pthread_mutex_unlock(&g_core_mutex);
        return;
    }

    /* mGBA 0.10.3 software renderer outputs XRGB8888 (0x00RRGGBB).
     * Android Bitmap ARGB_8888 is also 0xAARRGGBB.
     * Channel order already matches — only set alpha to 0xFF.
     *
     * The previous bswap formula assumed XBGR which swaps R↔B:
     *   red pixels appeared blue, blue appeared red.                      */
    for (int row = 0; row < g_height; row++) {
        const mColor *srcRow = g_fb + (size_t)row * (size_t)g_width;
        uint32_t     *dstRow = (uint32_t *)((uint8_t *)pixels
                                            + (size_t)row * info.stride);
        for (int col = 0; col < g_width; col++) {
            dstRow[col] = (srcRow[col] & 0x00FFFFFFu) | 0xFF000000u;
        }
    }

    AndroidBitmap_unlockPixels(env, bitmap);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeSetKeys ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSetKeys(
        JNIEnv *env, jobject thiz, jint keys)
{
    pthread_mutex_lock(&g_core_mutex);
    if (g_core) g_core->setKeys(g_core, (uint32_t)keys);
    pthread_mutex_unlock(&g_core_mutex);
}

/* ── nativeGetWidth / nativeGetHeight ───────────────────────────────────── */

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetWidth(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint w = (jint)g_width;
    pthread_mutex_unlock(&g_core_mutex);
    return w;
}

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetHeight(JNIEnv *env, jobject thiz)
{
    pthread_mutex_lock(&g_core_mutex);
    jint h = (jint)g_height;
    pthread_mutex_unlock(&g_core_mutex);
    return h;
}

/* ── nativeDestroy ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeDestroy(JNIEnv *env, jobject thiz)
{
    /* FIX 1 — mutex ensures we wait for any in-flight nativeRunFrame to
     * complete before freeing g_core / g_fb.                             */
    pthread_mutex_lock(&g_core_mutex);
    destroy_core();
    pthread_mutex_unlock(&g_core_mutex);
    LOGI("mGBA core destroyed");
}

/* ═══════════════════════════════════════════════════════════════════════════
 * GBA LINK CABLE MULTIPLAYER — frame-boundary SIO polling
 *
 * Architecture
 * ────────────
 * mGBA 0.10.3 does not export a public callback-registration API
 * (mCoreAddCallback / mCoreCallbacksRegister do not exist in the library).
 * Instead, we poll the SIO registers in nativeRunFrame() immediately after
 * g_core->runFrame() returns.  This fires at the frame boundary — the same
 * point at which GBA link-cable games (including Pokémon Gen 3) check and
 * initiate serial transfers.
 *
 * Why not GBASIODriver?
 * ─────────────────────
 * mGBA 0.10.3 redesigned struct GBASIODriver — legacy field names and enum
 * values no longer exist.  Frame-boundary polling requires zero internal
 * headers and works across mGBA versions.
 *
 * Thread safety
 * ─────────────
 * The SIO exchange runs inside nativeRunFrame() while g_core_mutex is held
 * and env is directly available — no thread-local storage needed.
 * ═══════════════════════════════════════════════════════════════════════════ */

/* ── Link state ─────────────────────────────────────────────────────────── */

static jobject   g_link_obj      = NULL;   /* global ref to LinkMultiplayer  */
static jmethodID g_link_xchg_mid = NULL;   /* jniExchangeData(I)I            */
static bool      g_link_active   = false;
static bool      g_link_is_host  = false;

/* ── Kotlin callback ─────────────────────────────────────────────────────── */

static uint32_t link_exchange(JNIEnv *env, uint32_t local_data)
{
    if (!env || !g_link_obj || !g_link_xchg_mid) return 0xFFFFFFFFu;
    jint r = (*env)->CallIntMethod(env, g_link_obj,
                                    g_link_xchg_mid, (jint)local_data);
    if ((*env)->ExceptionOccurred(env)) {
        (*env)->ExceptionClear(env);
        return 0xFFFFFFFFu;
    }
    return (uint32_t)r;
}

/* ── nativeLinkStart ─────────────────────────────────────────────────────── */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStart(
        JNIEnv *env, jobject thiz, jobject link_obj, jboolean is_host)
{
    (void)thiz;

    /* Release any previous global ref */
    if (g_link_obj) { (*env)->DeleteGlobalRef(env, g_link_obj); g_link_obj = NULL; }

    jclass cls = (*env)->GetObjectClass(env, link_obj);
    g_link_xchg_mid = (*env)->GetMethodID(env, cls, "jniExchangeData", "(I)I");
    if (!g_link_xchg_mid) {
        LOGE("LinkMultiplayer.jniExchangeData(I)I not found");
        return JNI_FALSE;
    }
    g_link_obj     = (*env)->NewGlobalRef(env, link_obj);
    g_link_is_host = (bool)is_host;

    pthread_mutex_lock(&g_core_mutex);
    g_link_active = true;
    pthread_mutex_unlock(&g_core_mutex);

    LOGI("Link multiplayer started (host=%d)", (int)is_host);
    return JNI_TRUE;
}

/* ── nativeLinkStop ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLinkStop(JNIEnv *env, jobject thiz)
{
    (void)thiz;

    pthread_mutex_lock(&g_core_mutex);
    g_link_active = false;
    pthread_mutex_unlock(&g_core_mutex);

    if (g_link_obj) {
        (*env)->DeleteGlobalRef(env, g_link_obj);
        g_link_obj = NULL;
    }
    g_link_xchg_mid = NULL;
    LOGI("Link multiplayer stopped");
}


