package com.hazardyard.game.settings;

/** Everything the player can configure. One live instance is shared by the input, HUD and renderer. */
public final class GameSettings {
    public final ControlSettings controls = new ControlSettings();
    /** Draw the soldiers and weapons as lit 3D models (off = the simple flat look, cheaper on slow phones). */
    public volatile boolean models3d = true;
    /** Graphics quality: {@link #QUALITY_AUTO} adapts to the phone while playing, the other two stay fixed. */
    public volatile int quality = QUALITY_AUTO;
    public static final int QUALITY_AUTO = 0;
    public static final int QUALITY_HIGH = 1;
    public static final int QUALITY_LIGHT = 2;
    /** The level the automatic mode has settled on in this run of the app (not saved), so the next match starts there. */
    public volatile int autoLevel;
    /** Master switch for all sound effects. */
    public volatile boolean soundOn = true;
    /** Master volume, 0..1. */
    public volatile float volume = 0.8f;

    public GameSettings copy() {
        GameSettings g = new GameSettings();
        g.copyFrom(this);
        return g;
    }

    public void copyFrom(GameSettings o) {
        controls.copyFrom(o.controls);
        models3d = o.models3d;
        quality = o.quality;
        autoLevel = o.autoLevel;
        soundOn = o.soundOn;
        volume = o.volume;
    }
}
