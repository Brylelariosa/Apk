package com.hazardyard.game.settings;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.MathUtil;

/**
 * Where the on-screen controls sit, how big they are and how they behave. Pure data (no Android
 * types) so the routing rules that depend on it can be tested on a plain JVM.
 *
 * <p>Positions are normalised: 0..1 across the usable screen area (the screen minus the display
 * cutout and system bars), so a layout survives different resolutions and aspect ratios.
 */
public final class ControlSettings {
    public static final int MOVE = 0;
    public static final int AIM = 1;
    public static final int FIRE = 2;
    public static final int RELOAD = 3;
    public static final int PAUSE = 4;
    public static final int DODGE = 5;
    public static final int COUNT = 6;

    /** Pushing the aim stick past the dead zone fires; there is no fire button. */
    public static final int FIRE_STICK = 0;
    /** The aim stick only aims; the fire button shoots. */
    public static final int FIRE_BUTTON = 1;
    /** Both of the above work at the same time. */
    public static final int FIRE_BOTH = 2;

    public static final float SCALE_MIN = 0.6f;
    public static final float SCALE_MAX = 1.8f;
    public static final float DEAD_ZONE_MIN = 0.10f;
    public static final float DEAD_ZONE_MAX = 0.70f;
    public static final float OPACITY_MIN = 0.25f;
    public static final float OPACITY_MAX = 1.0f;

    private static final float[] DEFAULT_X = {0.140f, 0.860f, 0.740f, 0.935f, 0.948f, 0.840f};
    private static final float[] DEFAULT_Y = {0.740f, 0.740f, 0.500f, 0.356f, 0.117f, 0.455f};
    private static final String[] NAMES = {"Move stick", "Aim stick", "Fire button", "Reload button", "Pause button", "Dodge button"};

    /** Control centres, 0..1 across the usable width / height. */
    public final float[] x = new float[COUNT];
    public final float[] y = new float[COUNT];
    /** Size multiplier per control, {@link #SCALE_MIN}..{@link #SCALE_MAX}. */
    public final float[] scale = new float[COUNT];

    /** True: the move stick appears wherever the thumb lands. False: it stays where it is drawn. */
    public boolean moveFloating;
    public boolean aimFloating;
    public int fireMode;
    /** Aim stick deflection (0..1) at which the player starts aiming (and firing, if the stick fires). */
    public float aimDeadZone;
    /** Overall control opacity. */
    public float opacity;

    public ControlSettings() {
        reset();
    }

    /** Back to the factory layout: fixed sticks, the aim stick fires, everything at its default spot. */
    public void reset() {
        for (int i = 0; i < COUNT; i++) {
            x[i] = DEFAULT_X[i];
            y[i] = DEFAULT_Y[i];
            scale[i] = 1f;
        }
        moveFloating = false;
        aimFloating = false;
        fireMode = FIRE_STICK;
        aimDeadZone = GameConfig.AIM_DEAD_ZONE;
        opacity = 0.85f;
    }

    public void copyFrom(ControlSettings o) {
        for (int i = 0; i < COUNT; i++) {
            x[i] = o.x[i];
            y[i] = o.y[i];
            scale[i] = o.scale[i];
        }
        moveFloating = o.moveFloating;
        aimFloating = o.aimFloating;
        fireMode = o.fireMode;
        aimDeadZone = o.aimDeadZone;
        opacity = o.opacity;
    }

    public ControlSettings copy() {
        ControlSettings c = new ControlSettings();
        c.copyFrom(this);
        return c;
    }

    /** Pulls every value back into its valid range (settings may come from an old or damaged file). */
    public void sanitize() {
        for (int i = 0; i < COUNT; i++) {
            x[i] = MathUtil.isFinite(x[i]) ? MathUtil.clamp(x[i], 0f, 1f) : DEFAULT_X[i];
            y[i] = MathUtil.isFinite(y[i]) ? MathUtil.clamp(y[i], 0f, 1f) : DEFAULT_Y[i];
            scale[i] = MathUtil.isFinite(scale[i]) ? MathUtil.clamp(scale[i], SCALE_MIN, SCALE_MAX) : 1f;
        }
        fireMode = MathUtil.clamp(fireMode, FIRE_STICK, FIRE_BOTH);
        aimDeadZone = MathUtil.isFinite(aimDeadZone)
                ? MathUtil.clamp(aimDeadZone, DEAD_ZONE_MIN, DEAD_ZONE_MAX) : GameConfig.AIM_DEAD_ZONE;
        opacity = MathUtil.isFinite(opacity) ? MathUtil.clamp(opacity, OPACITY_MIN, OPACITY_MAX) : 0.85f;
    }

    /** The fire button exists (and is drawn) in these modes. */
    public boolean fireButtonEnabled() {
        return fireMode != FIRE_STICK;
    }

    /** Pushing the aim stick fires in these modes. */
    public boolean stickFires() {
        return fireMode != FIRE_BUTTON;
    }

    public static String nameOf(int control) {
        return control >= 0 && control < COUNT ? NAMES[control] : "";
    }
}
