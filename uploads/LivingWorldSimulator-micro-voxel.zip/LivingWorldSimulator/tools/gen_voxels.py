#!/usr/bin/env python3
"""Bakes the micro-voxel plant models used by the Rust renderer (rust/src/flora_voxel.rs).

Every plant kind is described once, analytically (blobs, tubes, strips: the same shapes the old triangle meshes had),
then voxelised at five levels of detail (2.5: cubes are half the size they were in 2.4 and there is no single giant
cube per plant any more, the far levels are small grids too):

    LOD 0  s0       finest cubes (grass 2 cm ... trees 12 cm)
    LOD 1  2 * s0   each cube is the merge of 2x2x2 finer ones
    LOD 2  4 * s0
    LOD 3  8 * s0
    LOD 4  16 * s0  the coarsest grid: a handful of cubes for a tree, one or two for a tuft of grass

Only surface voxels are stored (the inside is never visible). Each voxel is
    x y z (i16, 1/1024 m)  r g b (u8)  tint (u8)  nx ny nz (i8)  sway (u8)
and every (kind, LOD) block starts with its voxel count and its cube size.

Usage:   python3 tools/gen_voxels.py [--preview preview.png]      (needs numpy and Pillow; takes about 3-4 minutes)
Writes:  rust/assets/voxels.b64   (the binary block below, base64, 100 characters per line, so the project stays text only)

The order of KINDS must match the K_* constants in rust/src/flora_voxel.rs.
"""
import base64
import math
import os
import struct
import sys

import numpy as np

NLOD = 5
SS = 3  # samples per voxel edge when deciding what a voxel covers


# ----------------------------------------------------------------------------------------------------------------------
# deterministic noise
# ----------------------------------------------------------------------------------------------------------------------
def hash3(ix, iy, iz, seed):
    h = (ix.astype(np.int64) * 73856093) ^ (iy.astype(np.int64) * 19349663) ^ (iz.astype(np.int64) * 83492791)
    h = h ^ ((int(seed) * 2654435761) & 0xFFFFFFFF)
    h = h & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    h = h ^ (h >> 16)
    return (h & 0xFFFFFF) / float(0x1000000)


def vnoise3(p, seed):
    f = np.floor(p)
    t = p - f
    t = t * t * (3.0 - 2.0 * t)
    ix, iy, iz = f[..., 0], f[..., 1], f[..., 2]
    out = 0.0
    for dx in (0, 1):
        for dy in (0, 1):
            for dz in (0, 1):
                w = (t[..., 0] if dx else 1 - t[..., 0]) * (t[..., 1] if dy else 1 - t[..., 1]) * (t[..., 2] if dz else 1 - t[..., 2])
                out = out + w * hash3(ix + dx, iy + dy, iz + dz, seed)
    return out


def mix(a, b, t):
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    t = np.asarray(t)[..., None]
    return a + (b - a) * t


# ----------------------------------------------------------------------------------------------------------------------
# primitives: each answers "is this point inside?" and "what colour is it?"
# ----------------------------------------------------------------------------------------------------------------------
class Prim:
    thr = 0.3     # share of a voxel that must be covered before the voxel exists
    tint = 1.0    # how much the per-plant tint colour is multiplied in (0 = fixed colour)
    sway = 0.0    # how much this part moves in the wind (before the height factor)
    holes = 0.0   # share of surface voxels left out at fine detail (leafy look)


class Blob(Prim):
    """lumpy ellipsoid: crowns, bushes, boulders, petals"""

    def __init__(self, c, r, cb, ct, rough=0.0, seed=1, tint=1.0, sway=0.5, thr=0.35, freq=2.0, zr=None, holes=0.0):
        self.c = np.array(c, dtype=np.float64)
        self.r = np.array(r, dtype=np.float64)
        self.cb, self.ct = cb, ct
        self.rough, self.seed, self.freq = rough, seed, freq
        self.tint, self.sway, self.thr, self.holes = tint, sway, thr, holes
        self.zr = zr if zr is not None else (self.c[2] - self.r[2], self.c[2] + self.r[2])

    def inside(self, P):
        d = (P - self.c) / self.r
        q = np.sqrt((d * d).sum(-1))
        if self.rough > 0.0:
            u = d / np.maximum(q[..., None], 1e-6)
            jit = 1.0 + self.rough * (vnoise3(u * self.freq + self.seed * 7.13, self.seed) - 0.5)
        else:
            jit = 1.0
        return q <= jit

    def color(self, P):
        t = np.clip((P[..., 2] - self.zr[0]) / max(self.zr[1] - self.zr[0], 1e-6), 0.0, 1.0)
        return mix(self.cb, self.ct, t)


class Frus(Prim):
    """tapered tube (trunks, branches, blades, cactus arms, cones when r1 = 0)"""

    def __init__(self, p0, p1, r0, r1, c0, c1, tint=1.0, sway=0.0, thr=0.08, zr=None):
        self.p0 = np.array(p0, dtype=np.float64)
        self.p1 = np.array(p1, dtype=np.float64)
        self.r0, self.r1 = r0, r1
        self.c0, self.c1 = c0, c1
        self.tint, self.sway, self.thr = tint, sway, thr
        self.zr = zr if zr is not None else (min(self.p0[2], self.p1[2]), max(self.p0[2], self.p1[2]))

    def inside(self, P):
        a = self.p1 - self.p0
        l2 = float((a * a).sum())
        t = ((P - self.p0) * a).sum(-1) / l2
        tc = np.clip(t, 0.0, 1.0)
        proj = self.p0 + tc[..., None] * a
        d = np.sqrt(((P - proj) ** 2).sum(-1))
        rad = self.r0 + (self.r1 - self.r0) * tc
        return (t >= 0.0) & (t <= 1.0) & (d <= rad)

    def color(self, P):
        z0, z1 = self.zr
        t = np.clip((P[..., 2] - z0) / max(z1 - z0, 1e-6), 0.0, 1.0)
        return mix(self.c0, self.c1, t)


class Strip(Prim):
    """flat curved leaf (ferns, palm fronds): a chain of thin discs along a rising, drooping path"""

    def __init__(self, base, az, length, width, rise, droop, c0, c1, tint=1.0, sway=0.8, thr=0.12, n=10, thick=0.03):
        self.discs = []
        ca, sa = math.cos(az), math.sin(az)
        for i in range(n + 1):
            t = i / n
            out = length * t
            z = rise * t - droop * t * t
            hw = width * (1.0 - t * 0.92) * 0.5
            self.discs.append((base[0] + ca * out, base[1] + sa * out, base[2] + z, hw, t))
        self.c0, self.c1 = c0, c1
        self.tint, self.sway, self.thr, self.thick = tint, sway, thr, thick

    def _hit(self, P):
        best = np.full(P.shape[:-1], 9e9)
        tt = np.zeros(P.shape[:-1])
        for (cx, cy, cz, hw, t) in self.discs:
            dx = (P[..., 0] - cx) / max(hw, 0.012)
            dy = (P[..., 1] - cy) / max(hw, 0.012)
            dz = (P[..., 2] - cz) / self.thick
            q = dx * dx + dy * dy + dz * dz
            better = q < best
            best = np.where(better, q, best)
            tt = np.where(better, t, tt)
        return best, tt

    def inside(self, P):
        best, _ = self._hit(P)
        return best <= 1.0

    def color(self, P):
        _, tt = self._hit(P)
        return mix(self.c0, self.c1, tt)


def blade(base, ang, lean, height, width, c0, c1, tint=1.0, sway=1.0, thr=0.02):
    ca, sa = math.cos(ang), math.sin(ang)
    bx, by = base
    mid = (bx + ca * lean * 0.35, by + sa * lean * 0.35, height * 0.55)
    tip = (bx + ca * lean, by + sa * lean, height)
    hw = width * 0.5
    zr = (0.0, height)
    return [
        Frus((bx, by, 0.0), mid, hw, hw * 0.8, c0, c1, tint, sway, thr, zr),
        Frus(mid, tip, hw * 0.8, hw * 0.12, c0, c1, tint, sway, thr, zr),
    ]


# ----------------------------------------------------------------------------------------------------------------------
# the plants (same order as the K_* constants in the Rust code)
# ----------------------------------------------------------------------------------------------------------------------
def k_grass():
    p = []
    heights = [0.30, 0.42, 0.26, 0.38, 0.34, 0.46, 0.28]
    for i in range(7):
        ang = i * (2 * math.pi / 7) + 0.35 * ((i * 5) % 7)
        r0 = 0.03 + 0.012 * (i % 3)
        lean = 0.10 + 0.05 * (i % 4)
        p += blade((math.cos(ang) * r0, math.sin(ang) * r0), ang, lean, heights[i], 0.05, (0.20, 0.30, 0.10), (0.62, 0.82, 0.36))
    return p


def k_tall_grass():
    p = []
    heights = [0.95, 1.15, 0.80, 1.05, 0.90, 1.10]
    for i in range(6):
        ang = i * (2 * math.pi / 6) + 0.5 * ((i * 3) % 5)
        r0 = 0.02 + 0.015 * (i % 2)
        lean = 0.18 + 0.07 * (i % 3)
        p += blade((math.cos(ang) * r0, math.sin(ang) * r0), ang, lean, heights[i], 0.05, (0.30, 0.38, 0.14), (0.78, 0.74, 0.38))
    return p


def k_flower():
    p = blade((0.0, 0.0), 0.0, 0.03, 0.32, 0.03, (0.18, 0.30, 0.10), (0.28, 0.45, 0.16), tint=0.4)
    p.append(Blob((0, 0, 0.35), (0.032, 0.032, 0.03), (1.0, 0.86, 0.35), (1.0, 0.86, 0.35), tint=0.25, sway=1.0, thr=0.05))
    for k in range(6):
        a = k * (2 * math.pi / 6)
        p.append(Blob((math.cos(a) * 0.065, math.sin(a) * 0.065, 0.375), (0.034, 0.034, 0.022), (1, 1, 1), (1, 1, 1), tint=1.0, sway=1.0, thr=0.05))
    return p


def k_fern():
    p = []
    for k in range(7):
        az = k * (2 * math.pi / 7) + 0.3
        p.append(Strip((0, 0, 0.02), az, 0.80, 0.20, 0.42, 0.55, (0.08, 0.26, 0.08), (0.24, 0.52, 0.18), 1.0, 0.6, 0.12, 8, 0.03))
    return p


def k_bush():
    c0, c1 = (0.11, 0.26, 0.08), (0.28, 0.50, 0.17)
    zr = (0.0, 0.88)
    return [
        Blob((0.0, 0.0, 0.42), (0.62, 0.60, 0.46), c0, c1, 0.32, 31, 1.0, 0.4, 0.35, zr=zr),
        Blob((0.48, 0.22, 0.34), (0.40, 0.38, 0.32), c0, c1, 0.32, 32, 1.0, 0.4, 0.35, zr=zr),
        Blob((-0.38, -0.30, 0.32), (0.38, 0.36, 0.30), c0, c1, 0.32, 33, 1.0, 0.4, 0.35, zr=zr),
    ]


def k_rock():
    return [Blob((0.0, 0.0, 0.16), (0.55, 0.46, 0.34), (0.28, 0.27, 0.25), (0.52, 0.50, 0.46), 0.55, 41, 0.25, 0.0, 0.4)]


def k_broadleaf():
    bark0, bark1 = (0.34, 0.23, 0.14), (0.28, 0.19, 0.12)
    ct = (0.30, 0.58, 0.20)
    cb = (0.12, 0.30, 0.09)
    zr = (2.4, 6.4)
    return [
        Frus((0, 0, 0), (0.08, 0, 2.9), 0.21, 0.10, bark0, bark1, 0.12, 0.05, 0.08),
        Blob((0.05, 0, 4.5), (2.3, 2.3, 1.9), cb, ct, 0.30, 11, 1.0, 0.5, 0.40, zr=zr, holes=0.10),
        Blob((1.35, 0.55, 3.7), (1.35, 1.30, 1.10), cb, (0.28, 0.54, 0.18), 0.30, 12, 1.0, 0.5, 0.40, zr=zr, holes=0.10),
        Blob((-1.25, -0.70, 3.8), (1.25, 1.20, 1.05), cb, (0.28, 0.54, 0.18), 0.30, 13, 1.0, 0.5, 0.40, zr=zr, holes=0.10),
    ]


def k_conifer():
    p = [Frus((0, 0, 0), (0, 0, 1.4), 0.17, 0.12, (0.30, 0.20, 0.12), (0.26, 0.18, 0.11), 0.1, 0.03, 0.08)]
    tiers = [(0.9, 1.75, 2.3), (2.2, 1.40, 2.1), (3.4, 1.05, 1.9), (4.5, 0.70, 1.7)]
    for i, (z0, r, h) in enumerate(tiers):
        sh = 1.0 - 0.08 * i
        low = (0.07 * sh, 0.20 * sh, 0.11 * sh)
        p.append(Frus((0, 0, z0), (0, 0, z0 + h), r, 0.0, low, (0.15, 0.36, 0.22), 1.0, 0.08 + 0.12 * i, 0.30, (z0, z0 + h)))
    return p


def k_palm():
    trunk = (0.44, 0.34, 0.22)
    pts = [(0.0, 0.0, 0.0), (0.12, 0.0, 1.6), (0.30, 0.05, 3.2), (0.48, 0.05, 4.8), (0.55, 0.05, 6.0)]
    p = []
    for i in range(4):
        p.append(Frus(pts[i], pts[i + 1], 0.19 - 0.025 * i, 0.19 - 0.025 * (i + 1), trunk, trunk, 0.1, 0.05, 0.08))
    for k in range(9):
        az = k * (2 * math.pi / 9) + 0.2
        p.append(Strip((0.55, 0.05, 6.0), az, 2.7, 0.60, 0.9, 1.9, (0.16, 0.40, 0.12), (0.36, 0.64, 0.22), 1.0, 0.6, 0.15, 14, 0.07))
    return p


def k_acacia():
    bark = (0.36, 0.26, 0.17)
    cb, ct = (0.20, 0.36, 0.10), (0.46, 0.60, 0.20)
    zr = (3.2, 4.3)
    return [
        Frus((0, 0, 0), (0.35, 0, 2.3), 0.17, 0.11, bark, bark, 0.1, 0.0, 0.08),
        Frus((0.35, 0, 2.3), (1.35, 0.45, 3.3), 0.10, 0.06, bark, bark, 0.1, 0.05, 0.08),
        Frus((0.35, 0, 2.3), (-0.70, -0.50, 3.2), 0.09, 0.05, bark, bark, 0.1, 0.05, 0.08),
        Blob((0.45, 0, 3.75), (3.0, 3.0, 0.55), cb, ct, 0.25, 21, 1.0, 0.4, 0.40, zr=zr, holes=0.08),
        Blob((1.60, 0.70, 3.50), (1.4, 1.4, 0.40), cb, (0.44, 0.58, 0.19), 0.25, 22, 1.0, 0.4, 0.40, zr=zr, holes=0.08),
    ]


def k_cactus():
    g0, g1 = (0.16, 0.38, 0.17), (0.26, 0.52, 0.26)
    t = 0.35

    def f(a, b, r0, r1):
        return Frus(a, b, r0, r1, g0, g1, t, 0.05, 0.10, (0.0, 2.85))

    return [
        f((0, 0, 0), (0, 0, 2.4), 0.28, 0.26),
        f((0, 0, 2.4), (0, 0, 2.85), 0.26, 0.0),
        f((0.2, 0, 1.2), (0.85, 0, 1.4), 0.12, 0.12),
        f((0.85, 0, 1.4), (0.9, 0, 2.1), 0.12, 0.11),
        f((0.9, 0, 2.1), (0.9, 0, 2.45), 0.11, 0.0),
        f((-0.2, 0, 0.9), (-0.7, 0, 1.05), 0.10, 0.10),
        f((-0.7, 0, 1.05), (-0.74, 0, 1.65), 0.10, 0.09),
        f((-0.74, 0, 1.65), (-0.74, 0, 1.95), 0.09, 0.0),
    ]


def k_dead_tree():
    wood, grey = (0.38, 0.32, 0.27), (0.30, 0.26, 0.22)
    p = [Frus((0, 0, 0), (0.1, 0, 3.1), 0.20, 0.06, wood, grey, 0.0, 0.0, 0.08, (0.0, 3.8))]
    for (z, a) in [(1.5, 0.3), (2.0, 2.4), (2.4, 4.2), (2.7, 5.5), (1.2, 3.4)]:
        s = (0.03 * z, 0.0, z)
        e = (s[0] + math.cos(a), s[1] + math.sin(a), z + 0.7)
        p.append(Frus(s, e, 0.06, 0.02, wood, grey, 0.0, 0.2, 0.06, (0.0, 3.8)))
    return p


# name, builder, finest cube (m), how much the normal leans towards "up" (like the old `soft` of the meshes),
# colour jitter between neighbouring cubes
KINDS = [
    ("grass", k_grass, 0.02, 0.85, 0.16),
    ("tall_grass", k_tall_grass, 0.03, 0.70, 0.14),
    ("flower", k_flower, 0.02, 0.60, 0.06),
    ("fern", k_fern, 0.025, 0.70, 0.12),
    ("bush", k_bush, 0.05, 0.15, 0.14),
    ("rock", k_rock, 0.04, 0.00, 0.10),
    ("broadleaf", k_broadleaf, 0.125, 0.05, 0.14),
    ("conifer", k_conifer, 0.11, 0.05, 0.12),
    ("palm", k_palm, 0.125, 0.05, 0.12),
    ("acacia", k_acacia, 0.125, 0.05, 0.14),
    ("cactus", k_cactus, 0.06, 0.05, 0.08),
    ("dead_tree", k_dead_tree, 0.075, 0.05, 0.08),
]


# ----------------------------------------------------------------------------------------------------------------------
# voxelising
# ----------------------------------------------------------------------------------------------------------------------
def model_height(prims):
    top = 0.0
    for p in prims:
        if isinstance(p, Blob):
            top = max(top, p.c[2] + p.r[2])
        elif isinstance(p, Frus):
            top = max(top, p.p0[2], p.p1[2])
        elif isinstance(p, Strip):
            top = max(top, max(d[2] for d in p.discs))
    return top


def model_extent(prims):
    """symmetric xy half extent and top"""
    ext = 0.0
    for p in prims:
        if isinstance(p, Blob):
            ext = max(ext, abs(p.c[0]) + p.r[0], abs(p.c[1]) + p.r[1])
        elif isinstance(p, Frus):
            ext = max(ext, abs(p.p0[0]) + p.r0, abs(p.p1[0]) + p.r1, abs(p.p0[1]) + p.r0, abs(p.p1[1]) + p.r1)
        elif isinstance(p, Strip):
            ext = max(ext, max(abs(d[0]) + d[3] for d in p.discs), max(abs(d[1]) + d[3] for d in p.discs))
    return ext * 1.08 + 0.05


def sample_coverage(prims, s, n, nz):
    """share of every finest-level voxel that each primitive covers (supersampled)"""
    ss = int(min(5, max(3, math.ceil(s / 0.02))))
    ix = np.arange(-n, n)
    iz = np.arange(0, nz)
    gx, gy, gz = np.meshgrid(ix, ix, iz, indexing="ij")
    centre = np.stack([(gx + 0.5) * s, (gy + 0.5) * s, (gz + 0.5) * s], axis=-1)
    offs = ((np.arange(ss) + 0.5) / ss - 0.5) * s
    covs = []
    for p in prims:
        cov = np.zeros(gx.shape)
        for ox in offs:
            for oy in offs:
                for oz in offs:
                    cov += p.inside(centre + np.array([ox, oy, oz]))
        covs.append(cov / float(ss ** 3))
    return covs


def downsample(c):
    """2x2x2 box filter: the next coarser level of a coverage field"""
    nx, ny, nz = c.shape
    return c.reshape(nx // 2, 2, ny // 2, 2, nz // 2, 2).mean(axis=(1, 3, 5))


def extract(prims, covs, s, n, soft, jit_amt, lod, height):
    """surface voxels of one level of detail from the per-primitive coverage fields"""
    shape = covs[0].shape
    ix = np.arange(-n, n)
    iz = np.arange(0, shape[2])
    gx, gy, gz = np.meshgrid(ix, ix, iz, indexing="ij")
    cx = (gx + 0.5) * s
    cy = (gy + 0.5) * s
    cz = (gz + 0.5) * s
    centre = np.stack([cx, cy, cz], axis=-1)

    cov_all = np.zeros(shape)
    best_cov = np.full(shape, -1.0)
    col = np.zeros(shape + (3,))
    tint = np.zeros(shape)
    sway = np.zeros(shape)
    holes = np.zeros(shape)
    occ = np.zeros(shape, dtype=bool)
    for p, cov in zip(prims, covs):
        thr = max(0.01, p.thr * (0.6 ** lod))
        passed = cov >= thr
        cov_all = np.maximum(cov_all, np.where(passed, np.maximum(cov, 0.5), cov))
        take = passed & (cov > best_cov)
        col = np.where(take[..., None], p.color(centre), col)
        tint = np.where(take, p.tint, tint)
        sway = np.where(take, p.sway, sway)
        holes = np.where(take, p.holes, holes)
        best_cov = np.where(take, cov, best_cov)
        occ |= passed

    # normals from the smoothed coverage field (outward = against the gradient)
    f = cov_all.copy()
    for _ in range(2):
        for ax in range(3):
            f = (np.roll(f, 1, ax) + 2.0 * f + np.roll(f, -1, ax)) * 0.25
    nrm = -np.stack([np.roll(f, -1, 0) - np.roll(f, 1, 0), np.roll(f, -1, 1) - np.roll(f, 1, 1), np.roll(f, -1, 2) - np.roll(f, 1, 2)], axis=-1)
    ln = np.sqrt((nrm ** 2).sum(-1))
    up = np.zeros_like(nrm)
    up[..., 2] = 1.0
    nrm = np.where((ln > 1e-4)[..., None], nrm / np.maximum(ln, 1e-9)[..., None], up)
    nrm = nrm * (1.0 - soft) + up * soft
    nrm = nrm / np.maximum(np.sqrt((nrm ** 2).sum(-1)), 1e-9)[..., None]

    # surface voxels only: a voxel with all six neighbours filled can never be seen
    inner = occ.copy()
    for ax in range(3):
        inner &= np.roll(occ, 1, ax) & np.roll(occ, -1, ax)
    inner[0, :, :] = inner[-1, :, :] = False
    inner[:, 0, :] = inner[:, -1, :] = False
    inner[:, :, 0] = inner[:, :, -1] = False
    shell = occ & ~inner

    # per cube colour jitter (the micro-voxel mosaic) and leaf holes at fine detail
    r1 = hash3(gx, gy, gz, 1000 + lod)
    r2 = hash3(gx, gy, gz, 2000 + lod)
    col = col * (1.0 + jit_amt * (r1 - 0.5) * 2.0)[..., None]
    if lod <= 1:
        shell &= ~((holes > 0.0) & (r2 < holes) & (cz > 0.5))

    idx = np.nonzero(shell)
    return {
        "pos": np.stack([cx[idx], cy[idx], cz[idx]], axis=-1),
        "col": np.clip(col[idx], 0.0, 1.0),
        "tint": tint[idx],
        "nrm": nrm[idx],
        "sway": sway[idx] * np.clip(cz[idx] / max(height, 1e-6), 0.0, 1.0) ** 1.5,
        "size": s,
        "proj_xz": int(occ.any(axis=1).sum()),
        "proj_yz": int(occ.any(axis=0).sum()),
    }


def make_dot(v0, s0):
    """one cube for the whole plant, derived from the finest level"""
    pos = v0["pos"]
    colr = np.sqrt((v0["col"] ** 2).mean(0))
    area = 0.5 * (v0["proj_xz"] + v0["proj_yz"]) * s0 * s0
    return {
        "pos": np.array([[0.0, 0.0, float(pos[:, 2].mean())]]),
        "col": colr[None, :],
        "tint": np.array([float(v0["tint"].mean())]),
        "nrm": np.array([[0.0, 0.0, 1.0]]),
        "sway": np.array([float(v0["sway"].mean())]),
        "size": math.sqrt(max(area, 1e-4)),
    }


def build_all():
    models = []
    for (name, fn, s0, soft, jit) in KINDS:
        prims = fn()
        h = model_height(prims)
        div = 2 ** (NLOD - 1)                                       # multiples of 16 keep all five levels aligned
        n = int(math.ceil(model_extent(prims) / s0 / div)) * div
        nz = int(math.ceil(h * 1.04 / s0 / div)) * div + div
        covs = sample_coverage(prims, s0, n, nz)
        lods = []
        for l in range(NLOD):
            if l > 0:
                covs = [downsample(c) for c in covs]
            lods.append(extract(prims, covs, s0 * (2 ** l), n >> l, soft, jit, l, h))
        dot = make_dot(lods[0], s0)
        for l in range(NLOD):
            if len(lods[l]["pos"]) == 0:          # never leave a level empty: fall back to one cube for the plant
                lods[l] = dict(dot, size=max(dot["size"], s0 * (2 ** l)))
        models.append((name, lods))
    return models


# ----------------------------------------------------------------------------------------------------------------------
# packing
# ----------------------------------------------------------------------------------------------------------------------
def pack(models, path):
    out = bytearray()
    out += b"LWVX"
    out += struct.pack("<III", 1, len(models), NLOD)
    for (name, lods) in models:
        for v in lods:
            n = len(v["pos"])
            out += struct.pack("<If", n, float(v["size"]))
            for i in range(n):
                x, y, z = (int(round(c * 1024.0)) for c in v["pos"][i])
                r, g, b = (int(round(c * 255.0)) for c in v["col"][i])
                t = int(round(float(v["tint"][i]) * 255.0))
                nx, ny, nz = (int(round(c * 127.0)) for c in v["nrm"][i])
                sw = int(round(min(1.0, max(0.0, float(v["sway"][i]))) * 255.0))
                out += struct.pack("<hhhBBBBbbbB", x, y, z, r, g, b, t, nx, ny, nz, sw)
    text = base64.b64encode(bytes(out)).decode("ascii")
    lines = [text[i:i + 100] for i in range(0, len(text), 100)]
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write("\n".join(lines) + "\n")
    return len(out)


# ----------------------------------------------------------------------------------------------------------------------
# preview sheet (orthographic, painter's order, simple sun)
# ----------------------------------------------------------------------------------------------------------------------
def preview(models, path):
    from PIL import Image, ImageDraw

    cell_w, cell_h = 300, 300
    img = Image.new("RGB", (cell_w * NLOD, cell_h * len(models)), (150, 190, 235))
    dr = ImageDraw.Draw(img)
    yaw = math.radians(35.0)
    elev = math.radians(18.0)
    sun = np.array([0.5, -0.35, 0.8])
    sun /= np.linalg.norm(sun)
    for row, (name, lods) in enumerate(models):
        top = max(float(l["pos"][:, 2].max() + l["size"]) for l in lods)
        scale = 250.0 / max(top, 0.3)
        for li, v in enumerate(lods):
            ox, oy = li * cell_w + cell_w // 2, row * cell_h + cell_h - 24
            pos = v["pos"]
            c, s = math.cos(yaw), math.sin(yaw)
            xr = pos[:, 0] * c - pos[:, 1] * s
            yr = pos[:, 0] * s + pos[:, 1] * c
            depth = yr
            sx = ox + xr * scale
            sy = oy - (pos[:, 2] * math.cos(elev) + yr * math.sin(elev)) * scale
            order = np.argsort(-depth)
            px = max(2.0, v["size"] * scale)
            dr.line([(li * cell_w + 10, oy), (li * cell_w + cell_w - 10, oy)], fill=(90, 120, 70))
            for i in order:
                n = v["nrm"][i]
                nrot = np.array([n[0] * c - n[1] * s, n[0] * s + n[1] * c, n[2]])
                lit = 0.30 + 0.80 * max(float(nrot @ (sun / 1.0)), 0.0)
                base = v["col"][i] * np.array([1.0, 1.0, 1.0])
                tinted = base * (1.0 + 0.0 * v["tint"][i])
                rgb = tuple(int(max(0, min(255, 255.0 * math.sqrt(max(0.0, (tinted[k] ** 2) * lit))))) for k in range(3))
                dr.rectangle([sx[i] - px / 2, sy[i] - px / 2, sx[i] + px / 2 - 1, sy[i] + px / 2 - 1], fill=rgb)
            dr.text((li * cell_w + 8, row * cell_h + 6), f"{name} L{li}  {len(pos)} vox  {v['size']*100:.0f}cm", fill=(255, 255, 255))
    img.save(path)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    root = os.path.dirname(here)
    out = os.path.join(root, "rust", "assets", "voxels.b64")
    prev = None
    if "--preview" in sys.argv:
        prev = sys.argv[sys.argv.index("--preview") + 1]
    models = build_all()
    total = 0
    print(f"{'kind':12s} " + " ".join(f"L{l:<10d}" for l in range(NLOD)))
    for (name, lods) in models:
        cells = []
        for v in lods:
            total += len(v["pos"])
            cells.append(f"{len(v['pos']):5d}@{v['size']*100:4.0f}cm")
        print(f"{name:12s} " + " ".join(cells))
    nbytes = pack(models, out)
    print(f"total voxels {total}, {nbytes} bytes -> {out}")
    if prev:
        preview(models, prev)
        print("preview ->", prev)


if __name__ == "__main__":
    main()
