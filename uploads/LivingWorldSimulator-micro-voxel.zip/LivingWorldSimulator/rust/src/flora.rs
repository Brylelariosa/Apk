//! Placement of plants and props. The ground is divided into tiles of 32 m on the cube-sphere face grid, so a tile
//! always holds the same plants wherever it is looked at from. Each tile samples the terrain on a small grid, derives its
//! biome / snow / fertility from the simulated climate exactly like the terrain texture does, and scatters grass,
//! flowers, ferns, bushes, rocks and trees accordingly. Kinds are generated on demand (grass only near the viewer)
//! within a per-frame time budget, so walking never stutters. The instances around the viewer are sorted into buckets,
//! one per kind and level of detail, because every plant is drawn as micro voxels whose cube size grows with distance
//! (see flora_voxel.rs); even the farthest level is a small grid of cubes, not one cube for the whole plant.

use crate::biome::*;
use crate::flora_voxel::*;
use crate::grid::{dir_to_face, face_dir};
use crate::mathx::*;
use crate::sampler::Sampler;
use crate::world::View;
use crate::world_data::*;
use std::collections::HashMap;
use std::time::Instant;

pub const TILE_M: f64 = 32.0;
/// tiles in each direction that can hold something visible (the longest view range is 460 m)
const TILE_R: i32 = 16;
/// ground samples per tile edge (4 m apart)
const GN: usize = 9;
/// finest terrain wavelength (m): the same as the terrain mesh at its finest level, so plants sit on the drawn ground
const LAM: f64 = 5.0;
/// rebuild the instance buffers when the viewer moved this far (m) from where they were built: the level of detail of
/// every plant is chosen from its distance to that spot, so it must stay close to the viewer
const REBUILD_DIST: f64 = 2.5;
/// but never more often than this (s)
const MIN_REBUILD_S: f64 = 0.10;

pub struct KindInfo {
    /// distances (m) where the next coarser level of detail takes over: level 1, 2, 3 and 4
    pub lod: [f64; NLOD - 1],
    /// plants further away than this are not drawn (m); the last stretch thins out at random instead of cutting off
    pub far: f64,
    /// most instances per level of detail; a full level hands its farthest plants down to the next coarser one
    pub cap: [usize; NLOD],
}

pub static KIND_INFO: [KindInfo; K_COUNT] = [
    KindInfo { lod: [8.0, 16.0, 32.0, 58.0], far: 90.0, cap: [50, 200, 700, 3000, 16000] },    // grass tufts
    KindInfo { lod: [12.0, 24.0, 48.0, 70.0], far: 110.0, cap: [40, 170, 650, 2500, 9000] },    // tall grass
    KindInfo { lod: [8.0, 16.0, 32.0, 45.0], far: 70.0, cap: [30, 120, 450, 1500, 3000] },    // flowers
    KindInfo { lod: [10.0, 20.0, 40.0, 65.0], far: 100.0, cap: [16, 70, 260, 900, 4000] },    // ferns
    KindInfo { lod: [20.0, 40.0, 80.0, 140.0], far: 220.0, cap: [20, 90, 350, 1100, 5000] },    // bushes
    KindInfo { lod: [16.0, 32.0, 64.0, 125.0], far: 200.0, cap: [20, 90, 350, 1100, 4000] },    // rocks
    KindInfo { lod: [50.0, 100.0, 200.0, 300.0], far: 460.0, cap: [10, 50, 250, 900, 10000] },    // broadleaf trees
    KindInfo { lod: [44.0, 88.0, 176.0, 290.0], far: 460.0, cap: [10, 60, 350, 1300, 10000] },    // conifers
    KindInfo { lod: [50.0, 100.0, 200.0, 260.0], far: 400.0, cap: [24, 130, 500, 2200, 6000] },    // palms
    KindInfo { lod: [50.0, 100.0, 200.0, 260.0], far: 400.0, cap: [8, 45, 220, 800, 5000] },    // acacias
    KindInfo { lod: [24.0, 48.0, 96.0, 145.0], far: 220.0, cap: [16, 70, 260, 700, 3000] },    // cacti
    KindInfo { lod: [30.0, 60.0, 120.0, 170.0], far: 260.0, cap: [24, 100, 340, 1300, 4000] },    // dead trees
];

/// jitter-grid cell size (m) per kind; the cell also limits how close two of them can get
const CELL: [f64; K_COUNT] = [1.45, 1.8, 3.0, 2.5, 4.5, 6.0, 6.5, 6.5, 7.0, 9.0, 7.0, 8.0];

const FLOWER_COLORS: [[f32; 3]; 6] = [
    [1.00, 0.90, 0.25],
    [0.96, 0.96, 0.96],
    [0.90, 0.28, 0.32],
    [0.62, 0.38, 0.90],
    [0.98, 0.58, 0.22],
    [0.42, 0.58, 0.98],
];

#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct TileKey {
    pub face: u8,
    pub i: i32,
    pub j: i32,
}

#[derive(Clone, Copy)]
pub struct Inst {
    /// position in the tile frame (east, north, up in metres from the tile centre)
    pub p: [f32; 3],
    pub scale: f32,
    pub yaw: f32,
    pub tint: [f32; 3],
}

/// everything about a tile that is needed to generate its kinds later
struct Ctx {
    face: usize,
    u0: f64,
    v0: f64,
    kf: f64,
    dir: V3,
    e: V3,
    n: V3,
    r: f64,
    hc: f64,
    seed: u64,
    gh: [f64; GN * GN],
    gw: [f64; GN * GN],
    bio: u8,
    dens: [f64; K_COUNT],
    tint: [f32; 3],
}

pub struct Tile {
    pub key: TileKey,
    pub dir: V3,
    pub hc: f64,
    pub e: V3,
    pub n: V3,
    pub inst: Vec<Vec<Inst>>,
    have: u32,
    ctx: Ctx,
}

// ---------------------------------------------------------------------------------------------------
// small helpers
// ---------------------------------------------------------------------------------------------------

fn hash2(seed: u64, a: i64, b: i64) -> f64 {
    let h = mix64(seed ^ (a as u64).wrapping_mul(0x9E3779B97F4A7C15u64) ^ (b as u64).wrapping_mul(0xC2B2AE3D27D4EB4Fu64));
    ((h >> 11) as f64) * (1.0 / 9007199254740992.0)
}

/// smooth value noise in 0..1
fn vnoise(seed: u64, x: f64, y: f64) -> f64 {
    let xf = x.floor();
    let yf = y.floor();
    let fx = x - xf;
    let fy = y - yf;
    let ix = xf as i64;
    let iy = yf as i64;
    let a = hash2(seed, ix, iy);
    let b = hash2(seed, ix + 1, iy);
    let c = hash2(seed, ix, iy + 1);
    let d = hash2(seed, ix + 1, iy + 1);
    let sx = fx * fx * (3.0 - 2.0 * fx);
    let sy = fy * fy * (3.0 - 2.0 * fy);
    let top = a + (b - a) * sx;
    let bot = c + (d - c) * sx;
    top + (bot - top) * sy
}

/// plants per square metre for each kind, by biome
fn biome_density(bio: u8) -> [f64; K_COUNT] {
    //   grass  tall   flower fern   bush   rock   broad  conif  palm   acacia cactus dead
    match bio {
        B_RAINFOREST => [0.25, 0.02, 0.010, 0.14, 0.020, 0.002, 0.040, 0.0, 0.012, 0.0, 0.0, 0.0],
        B_SEASONAL_FOREST => [0.45, 0.04, 0.030, 0.05, 0.018, 0.003, 0.028, 0.0, 0.004, 0.0, 0.0, 0.0],
        B_SAVANNA => [0.55, 0.30, 0.020, 0.0, 0.004, 0.004, 0.001, 0.0, 0.0, 0.0035, 0.0, 0.0006],
        B_DESERT => [0.012, 0.0, 0.0005, 0.0, 0.0025, 0.010, 0.0, 0.0, 0.0, 0.0, 0.0012, 0.0005],
        B_SEMIARID => [0.20, 0.06, 0.006, 0.0, 0.008, 0.006, 0.0, 0.0, 0.0, 0.0008, 0.0003, 0.0004],
        B_GRASSLAND => [0.85, 0.08, 0.070, 0.0, 0.003, 0.003, 0.0006, 0.0, 0.0, 0.0, 0.0, 0.0],
        B_TEMP_FOREST => [0.40, 0.02, 0.025, 0.06, 0.020, 0.003, 0.030, 0.008, 0.0, 0.0, 0.0, 0.0],
        B_BOREAL => [0.18, 0.0, 0.006, 0.05, 0.012, 0.006, 0.004, 0.040, 0.0, 0.0, 0.0, 0.001],
        B_TUNDRA => [0.22, 0.0, 0.012, 0.0, 0.006, 0.016, 0.0, 0.0006, 0.0, 0.0, 0.0, 0.0006],
        B_ALPINE => [0.10, 0.0, 0.014, 0.0, 0.002, 0.024, 0.0, 0.003, 0.0, 0.0, 0.0, 0.0004],
        B_WETLAND => [0.45, 0.45, 0.020, 0.03, 0.006, 0.0, 0.004, 0.0, 0.0, 0.0, 0.0, 0.0],
        B_MANGROVE => [0.15, 0.35, 0.0, 0.0, 0.010, 0.0, 0.020, 0.0, 0.004, 0.0, 0.0, 0.0],
        B_ICE => [0.0, 0.0, 0.0, 0.0, 0.0, 0.003, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        _ => [0.0; K_COUNT],
    }
}

/// colour multiplier for grass and leaves in a biome (golden savanna, dark boreal, ...)
fn foliage_tint(bio: u8) -> [f32; 3] {
    match bio {
        B_RAINFOREST => [0.72, 1.00, 0.80],
        B_SEASONAL_FOREST => [0.90, 1.00, 0.75],
        B_SAVANNA => [1.40, 1.10, 0.55],
        B_DESERT => [1.50, 1.10, 0.70],
        B_SEMIARID => [1.32, 1.08, 0.62],
        B_GRASSLAND => [1.00, 1.06, 0.74],
        B_TEMP_FOREST => [0.86, 1.00, 0.76],
        B_BOREAL => [0.74, 0.94, 0.82],
        B_TUNDRA => [1.00, 0.95, 0.68],
        B_ALPINE => [0.95, 1.00, 0.78],
        B_WETLAND => [0.86, 1.05, 0.80],
        B_MANGROVE => [0.72, 1.00, 0.82],
        _ => [1.0, 1.0, 1.0],
    }
}

/// large-scale clumping: forests have clearings, meadows have patches, flowers grow in drifts
fn clump_factor(kind: usize, seed: u64, gx: f64, gy: f64) -> f64 {
    match kind {
        K_BROADLEAF | K_CONIFER | K_PALM | K_ACACIA => {
            let n = vnoise(seed ^ 0x51, gx / 70.0, gy / 70.0) * 0.65 + vnoise(seed ^ 0x52, gx / 23.0, gy / 23.0) * 0.35;
            0.15 + 1.9 * smoothstep(0.30, 0.65, n)
        }
        K_GRASS | K_TALL_GRASS | K_FERN => {
            let n = vnoise(seed ^ 0x61, gx / 9.0, gy / 9.0);
            0.55 + 0.9 * n
        }
        K_FLOWER | K_BUSH => {
            let n = vnoise(seed ^ 0x71, gx / 14.0, gy / 14.0);
            0.2 + 1.6 * smoothstep(0.35, 0.8, n)
        }
        _ => 1.0,
    }
}

/// bit mask of the kinds that can be visible from `dist` metres away
fn kinds_needed(dist: f64) -> u32 {
    let mut m = 0u32;
    for k in 0..K_COUNT {
        if dist <= KIND_INFO[k].far + TILE_M * 1.2 {
            m |= 1u32 << k;
        }
    }
    m
}

// ---------------------------------------------------------------------------------------------------
// tiles
// ---------------------------------------------------------------------------------------------------

/// sample the ground and the climate of a tile and decide what grows there
fn new_tile(v: &View, key: TileKey) -> Tile {
    let s = Sampler::new(v);
    let r = s.rm;
    let kf = r * PI / 4.0;
    let du = TILE_M / kf;
    let face = key.face as usize;
    let u0 = (key.i as f64) * du;
    let v0 = (key.j as f64) * du;
    let dir_c = face_dir(face, u0 + du * 0.5, v0 + du * 0.5);
    let (e, n) = east_north(dir_c);

    let mut gh = [0.0f64; GN * GN];
    let mut gw = [0.0f64; GN * GN];
    let step = du / ((GN - 1) as f64);
    for gj in 0..GN {
        for gi in 0..GN {
            let d = face_dir(face, u0 + step * (gi as f64), v0 + step * (gj as f64));
            let (g, w) = s.ground_and_water(d, LAM);
            gh[gj * GN + gi] = g;
            gw[gj * GN + gi] = w;
        }
    }
    let c = GN / 2;
    let hc = gh[c * GN + c];
    let spacing = TILE_M / ((GN - 1) as f64);
    let gx = (gh[c * GN + c + 1] - gh[c * GN + c - 1]) / (2.0 * spacing);
    let gy = (gh[(c + 1) * GN + c] - gh[(c - 1) * GN + c]) / (2.0 * spacing);
    let slope_c = (gx * gx + gy * gy).sqrt();

    // climate at the tile, lapse-corrected for the local height exactly like the terrain texture
    let hb = s.fg.sample(&s.t.height, dir_c) as f64;
    let dh = hc - hb;
    let gam = s.gam;
    let t_ann = s.fg.sample(&s.e.t_ann, dir_c) as f64 - gam * dh;
    let t_min = s.fg.sample(&s.e.t_min, dir_c) as f64 - gam * dh;
    let t_max = s.fg.sample(&s.e.t_max, dir_c) as f64 - gam * dh;
    let p_ann = s.fg.sample(&s.e.p_ann, dir_c) as f64;
    let arid = s.fg.sample(&s.e.aridity, dir_c) as f64;
    let moist = s.fg.sample(&s.e.soil_moist, dir_c) as f64;
    let dry = s.fg.sample(&s.e.p_dry_frac, dir_c) as f64 * 12.0;
    let fert = s.fg.sample(&s.e.fertility, dir_c) as f64;
    let wet = clampv(moist * (1.0 - clampv(slope_c / 0.1, 0.0, 1.0)) * 0.9 - 0.2, 0.0, 1.0);
    let bi = BiomeIn {
        t_ann,
        t_min,
        t_max,
        p_ann,
        aridity: arid,
        dry_months: dry,
        elev: hc,
        slope: slope_c * 0.25,
        wetness: wet,
        lat_abs: 0.0,
        coastal: hb < 14.0,
    };
    let bio = classify_biome_lazy(&bi, || lat_of(dir_c).abs() * RAD2DEG);

    // snow cover like the terrain texture: seasonal snow from the simulated depth + permanent snow
    let z_mean = s.cg.sample(&s.s.st().z_mean, dir_c) as f64;
    let tcur = s.cg.sample(&s.d.ta, dir_c) as f64 - 273.15 - gam * (hc - z_mean);
    let sdepth = s.cg.sample(&s.d.snow, dir_c) as f64;
    let snow_season = smoothstep(1.0, -3.0, tcur) * clampv(0.15 + sdepth / 50.0, 0.0, 1.0);
    let glc = s.cg.sample(&s.d.glacier, dir_c) as f64;
    let gk = smoothstep(2.0, 70.0, glc);
    let snow_perm = smoothstep(2.0, -1.0, t_max).max(gk * smoothstep(9.0, 0.0, t_max));
    let mut snow = snow_season.max(snow_perm);
    if bio == B_ICE {
        snow = 1.0;
    }

    // density per kind
    let mut dens = biome_density(bio);
    let fert_k = 0.55 + 0.45 * clampv(fert, 0.0, 1.0);
    let steep = smoothstep(0.45, 1.1, slope_c);
    let bare = steep.max(smoothstep(9.0, 3.0, t_max) * 0.8);
    let grass_k = (1.0 - snow) * (1.0 - 0.7 * bare);
    let tree_k = (1.0 - smoothstep(0.75, 1.0, snow)) * (1.0 - bare);
    for k in 0..K_COUNT {
        let m = match k {
            K_GRASS | K_TALL_GRASS | K_FERN => fert_k * grass_k,
            K_FLOWER => fert_k * grass_k * (1.0 - snow),
            K_BUSH => fert_k * (1.0 - 0.8 * bare) * (1.0 - 0.8 * snow),
            K_ROCK => 1.0 + 6.0 * bare,
            K_BROADLEAF | K_CONIFER | K_PALM | K_ACACIA | K_DEAD_TREE => fert_k * tree_k,
            _ => 1.0,
        };
        dens[k] *= m;
    }

    let seed = mix64(s.s.seed ^ hash2(0x7F1, key.face as i64, 0).to_bits() ^ hash2(0x7F2, key.i as i64, key.j as i64).to_bits());
    let ctx = Ctx {
        face,
        u0,
        v0,
        kf,
        dir: dir_c,
        e,
        n,
        r,
        hc,
        seed,
        gh,
        gw,
        bio,
        dens,
        tint: foliage_tint(bio),
    };
    let mut inst: Vec<Vec<Inst>> = Vec::with_capacity(K_COUNT);
    for _ in 0..K_COUNT {
        inst.push(Vec::new());
    }
    Tile { key, dir: dir_c, hc, e, n, inst, have: 0, ctx }
}

/// scale and tint of one new instance
fn look(kind: usize, c: &Ctx, rng: &mut Rng) -> (f64, [f32; 3]) {
    let var = (0.90 + 0.20 * rng.uni()) as f32;
    let ft = c.tint;
    let tint = [ft[0] * var, ft[1] * var, ft[2] * var];
    match kind {
        K_GRASS => (0.7 + 0.7 * rng.uni(), tint),
        K_TALL_GRASS => (0.8 + 0.5 * rng.uni(), tint),
        K_FLOWER => {
            let pi = ((rng.uni() * 6.0) as usize) % 6;
            (0.8 + 0.5 * rng.uni(), FLOWER_COLORS[pi])
        }
        K_FERN => (0.8 + 0.6 * rng.uni(), tint),
        K_BUSH => (0.6 + 0.9 * rng.uni(), tint),
        K_ROCK => {
            let t = rng.uni();
            (0.25 + 1.5 * t * t, [0.92 * var, 0.92 * var, 0.95 * var])
        }
        K_BROADLEAF => (0.75 + 0.7 * rng.uni(), tint),
        K_CONIFER => (0.8 + 0.8 * rng.uni(), tint),
        K_PALM => (0.8 + 0.5 * rng.uni(), tint),
        K_ACACIA => (0.8 + 0.5 * rng.uni(), tint),
        K_CACTUS => (0.6 + 0.8 * rng.uni(), [var, var, var]),
        _ => (0.7 + 0.6 * rng.uni(), [1.0, 1.0, 1.0]),
    }
}

/// try to put one instance of `kind` at (x, y) metres inside the tile
fn place(c: &Ctx, kind: usize, x: f64, y: f64, spacing: f64, rng: &mut Rng) -> Option<Inst> {
    let gxf = x / spacing;
    let gyf = y / spacing;
    let ix = (gxf as usize).min(GN - 2);
    let iy = (gyf as usize).min(GN - 2);
    let fx = gxf - (ix as f64);
    let fy = gyf - (iy as f64);
    let i00 = iy * GN + ix;
    let h00 = c.gh[i00];
    let h10 = c.gh[i00 + 1];
    let h01 = c.gh[i00 + GN];
    let h11 = c.gh[i00 + GN + 1];
    let hh = (h00 * (1.0 - fx) + h10 * fx) * (1.0 - fy) + (h01 * (1.0 - fx) + h11 * fx) * fy;
    let w00 = c.gw[i00];
    let w10 = c.gw[i00 + 1];
    let w01 = c.gw[i00 + GN];
    let w11 = c.gw[i00 + GN + 1];
    let ww = (w00 * (1.0 - fx) + w10 * fx) * (1.0 - fy) + (w01 * (1.0 - fx) + w11 * fx) * fy;
    if ww > hh + 0.03 {
        return None; // under water
    }
    let sx = ((h10 - h00) * (1.0 - fy) + (h11 - h01) * fy) / spacing;
    let sy = ((h01 - h00) * (1.0 - fx) + (h11 - h10) * fx) / spacing;
    let slope = (sx * sx + sy * sy).sqrt();
    let ok = match kind {
        K_GRASS | K_TALL_GRASS | K_FLOWER | K_FERN => slope < 1.3 && hh > 0.15,
        K_BUSH => slope < 1.0 && hh > 0.4,
        K_ROCK => hh > 0.1,
        K_BROADLEAF => slope < 0.9 && hh > (if c.bio == B_MANGROVE { 0.1 } else { 1.5 }),
        K_CONIFER | K_ACACIA | K_DEAD_TREE => slope < 0.9 && hh > 1.5,
        K_PALM => slope < 0.9 && hh > 0.4,
        K_CACTUS => slope < 0.8 && hh > 1.0,
        _ => true,
    };
    if !ok {
        return None;
    }
    let yaw = rng.uni() * TAU;
    let (scale, tint) = look(kind, c, rng);
    let d = face_dir(c.face, c.u0 + x / c.kf, c.v0 + y / c.kf);
    let rel = d * (c.r + hh) - c.dir * (c.r + c.hc);
    Some(Inst {
        p: [dot(rel, c.e) as f32, dot(rel, c.n) as f32, dot(rel, c.dir) as f32],
        scale: scale as f32,
        yaw: yaw as f32,
        tint,
    })
}

impl Tile {
    /// scatter one kind over the tile (deterministic: the same tile always gets the same plants)
    fn gen_kind(&mut self, kind: usize) {
        self.have |= 1u32 << kind;
        let dens = self.ctx.dens[kind];
        if dens <= 0.0 {
            return;
        }
        let cs = CELL[kind];
        let ncell = ((TILE_M / cs).ceil() as usize).max(1);
        let cell = TILE_M / (ncell as f64);
        let spacing = TILE_M / ((GN - 1) as f64);
        let kseed = mix64(self.ctx.seed ^ (((kind as u64) + 1).wrapping_mul(0xA24BAED4963EE407u64)));
        let ti = self.key.i as f64;
        let tj = self.key.j as f64;
        let mut out: Vec<Inst> = Vec::new();
        for cj in 0..ncell {
            for ci in 0..ncell {
                let cid = ((cj * ncell + ci) as u64).wrapping_mul(0x9FB21C651E98DF25u64);
                let mut rng = Rng::new(mix64(kseed ^ cid));
                let gxm = ti * TILE_M + ((ci as f64) + 0.5) * cell;
                let gym = tj * TILE_M + ((cj as f64) + 0.5) * cell;
                let clump = clump_factor(kind, self.ctx.seed, gxm, gym);
                let expect = dens * clump * cell * cell;
                let mut cnt = expect.floor() as usize;
                if rng.uni() < expect - expect.floor() {
                    cnt += 1;
                }
                for _ in 0..cnt {
                    let x = ((ci as f64) + rng.uni()) * cell;
                    let y = ((cj as f64) + rng.uni()) * cell;
                    if let Some(inst) = place(&self.ctx, kind, x, y, spacing, &mut rng) {
                        out.push(inst);
                    }
                }
            }
        }
        self.inst[kind] = out;
    }
}

// ---------------------------------------------------------------------------------------------------
// the cache around the viewer
// ---------------------------------------------------------------------------------------------------

pub struct Flora {
    tiles: HashMap<TileKey, Tile>,
    order: Vec<(i32, i32)>,
    /// per entry of `order`: the kinds that can be visible from there
    need: Vec<u32>,
    epoch: i64,
    frame: u64,
    /// per bucket (`kind * NLOD + level`): 8 floats per instance (x y z scale yaw r g b), positions relative to the
    /// build anchor
    pub out: Vec<Vec<f32>>,
    pub built_dir: V3,
    pub built_h: f64,
    pub built_valid: bool,
    /// scale of the view and level-of-detail distances the buffers were built with
    pub built_detail: f64,
    detail: f64,
    last_build: Instant,
    pending: bool,
    pub tile_count: usize,
    pub inst_total: usize,
}

impl Flora {
    pub fn new() -> Flora {
        let mut order: Vec<(i32, i32)> = Vec::new();
        for di in -TILE_R..=TILE_R {
            for dj in -TILE_R..=TILE_R {
                let d2 = (di * di + dj * dj) as f64;
                let lim = (TILE_R as f64) + 0.5;
                if d2 <= lim * lim {
                    order.push((di, dj));
                }
            }
        }
        order.sort_by(|a, b| {
            let da = a.0 * a.0 + a.1 * a.1;
            let db = b.0 * b.0 + b.1 * b.1;
            da.cmp(&db)
        });
        let mut need: Vec<u32> = Vec::with_capacity(order.len());
        for &(di, dj) in order.iter() {
            let dist = (((di * di + dj * dj) as f64).sqrt()) * TILE_M;
            need.push(kinds_needed(dist));
        }
        let mut out: Vec<Vec<f32>> = Vec::with_capacity(NBUCKET);
        for _ in 0..NBUCKET {
            out.push(Vec::new());
        }
        Flora {
            tiles: HashMap::new(),
            order,
            need,
            epoch: -1,
            frame: 0,
            out,
            built_dir: V3::new(1.0, 0.0, 0.0),
            built_h: 0.0,
            built_valid: false,
            built_detail: 1.0,
            detail: 1.0,
            last_build: Instant::now(),
            pending: false,
            tile_count: 0,
            inst_total: 0,
        }
    }

    pub fn clear(&mut self) {
        self.tiles.clear();
        self.built_valid = false;
        self.pending = false;
        for b in 0..NBUCKET {
            self.out[b].clear();
        }
        self.tile_count = 0;
        self.inst_total = 0;
    }

    /// scale every view and level-of-detail distance (0.4 .. 1); the buffers follow at the next rebuild
    pub fn set_detail(&mut self, d: f64) {
        self.detail = clampv(d, 0.4, 1.0);
    }

    /// Generate what is missing around the viewer within `budget_ms` and rebuild the instance buffers when needed.
    /// `dir` / `h` is the surface point under the viewer (unit vector, height in metres). Returns true when `out` changed.
    pub fn update(&mut self, v: &View, epoch: i64, dir: V3, h: f64, budget_ms: f64) -> bool {
        self.frame += 1;
        if epoch != self.epoch {
            self.clear();
            self.epoch = epoch;
        }
        let r = v.s.dv.r;
        let kf = r * PI / 4.0;
        let (face, u, vv) = dir_to_face(dir);
        let ai = ((u * kf) / TILE_M).floor() as i32;
        let aj = ((vv * kf) / TILE_M).floor() as i32;
        let t0 = Instant::now();
        let mut generated = false;
        'tiles: for (oi, &(di, dj)) in self.order.iter().enumerate() {
            let key = TileKey { face: face as u8, i: ai + di, j: aj + dj };
            let need = self.need[oi];
            if !self.tiles.contains_key(&key) {
                if t0.elapsed().as_secs_f64() * 1000.0 > budget_ms {
                    break 'tiles;
                }
                let t = new_tile(v, key);
                self.tiles.insert(key, t);
                generated = true;
            }
            if let Some(t) = self.tiles.get_mut(&key) {
                for k in 0..K_COUNT {
                    let bit = 1u32 << k;
                    if need & bit != 0 && t.have & bit == 0 {
                        t.gen_kind(k);
                        generated = true;
                        if t0.elapsed().as_secs_f64() * 1000.0 > budget_ms {
                            break 'tiles;
                        }
                    }
                }
            }
        }
        if generated {
            self.pending = true;
        }
        // forget tiles far away (also when the viewer crossed to another cube face)
        if self.frame % 16 == 0 {
            let keep = TILE_R + 2;
            self.tiles.retain(|k, _| k.face == (face as u8) && (k.i - ai).abs() <= keep && (k.j - aj).abs() <= keep);
        }
        let moved = if self.built_valid { length(dir - self.built_dir) * r } else { 1.0e9 };
        let since = self.last_build.elapsed().as_secs_f64();
        let due = self.pending && since > 0.15;
        let moved_enough = moved > REBUILD_DIST && since > MIN_REBUILD_S;
        let detail_changed = self.built_valid && (self.detail - self.built_detail).abs() > 0.06 && since > 0.5;
        if moved_enough || due || detail_changed || (!self.built_valid && self.pending) {
            self.rebuild(dir, h, r);
            return true;
        }
        false
    }

    /// Collect the instances around the anchor into one bucket per kind and level of detail, nearest tiles first (the
    /// caps cut the far ones). The level follows from the distance to the anchor.
    fn rebuild(&mut self, dir: V3, h: f64, r: f64) {
        let (ea, na) = east_north(dir);
        let a_pos = dir * (r + h);
        for b in 0..NBUCKET {
            self.out[b].clear();
        }
        let detail = self.detail;
        let mut list: Vec<(f64, TileKey)> = Vec::with_capacity(self.tiles.len());
        for (key, t) in self.tiles.iter() {
            let rel = t.dir * (r + t.hc) - a_pos;
            list.push((dot(rel, rel), *key));
        }
        list.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
        let mut total = 0usize;
        for item in list.iter() {
            let t = match self.tiles.get(&item.1) {
                Some(t) => t,
                None => continue,
            };
            let dist = item.0.sqrt();
            let rel = t.dir * (r + t.hc) - a_pos;
            let o = [dot(rel, ea), dot(rel, na), dot(rel, dir)];
            let te = [dot(t.e, ea), dot(t.e, na), dot(t.e, dir)];
            let tn = [dot(t.n, ea), dot(t.n, na), dot(t.n, dir)];
            let tu = [dot(t.dir, ea), dot(t.dir, na), dot(t.dir, dir)];
            for k in 0..K_COUNT {
                if t.inst[k].is_empty() {
                    continue;
                }
                let info = &KIND_INFO[k];
                let far = info.far * detail + 6.0;
                if dist - TILE_M > far {
                    continue;
                }
                let far2 = far * far;
                let c1 = info.lod[0] * detail;
                let c2 = info.lod[1] * detail;
                let c3 = info.lod[2] * detail;
                let c4 = info.lod[3] * detail;
                let (c1s, c2s, c3s, c4s) = (c1 * c1, c2 * c2, c3 * c3, c4 * c4);
                for inst in t.inst[k].iter() {
                    let x = inst.p[0] as f64;
                    let y = inst.p[1] as f64;
                    let z = inst.p[2] as f64;
                    let px = o[0] + te[0] * x + tn[0] * y + tu[0] * z;
                    let py = o[1] + te[1] * x + tn[1] * y + tu[1] * z;
                    let pz = o[2] + te[2] * x + tn[2] * y + tu[2] * z;
                    let d2 = px * px + py * py + pz * pz;
                    if d2 > far2 {
                        continue;
                    }
                    let mut l: usize = if d2 < c1s {
                        0
                    } else if d2 < c2s {
                        1
                    } else if d2 < c3s {
                        2
                    } else if d2 < c4s {
                        3
                    } else {
                        4
                    };
                    // a full bucket hands the plant down to the next coarser level
                    while l < NLOD && self.out[k * NLOD + l].len() >= info.cap[l] * 8 {
                        l += 1;
                    }
                    if l >= NLOD {
                        continue;
                    }
                    let out = &mut self.out[k * NLOD + l];
                    out.push(px as f32);
                    out.push(py as f32);
                    out.push(pz as f32);
                    out.push(inst.scale);
                    out.push(inst.yaw);
                    out.push(inst.tint[0]);
                    out.push(inst.tint[1]);
                    out.push(inst.tint[2]);
                    total += 1;
                }
            }
        }
        self.built_dir = dir;
        self.built_h = h;
        self.built_valid = true;
        self.built_detail = detail;
        self.pending = false;
        self.last_build = Instant::now();
        self.tile_count = self.tiles.len();
        self.inst_total = total;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn noise_is_in_range_and_smooth() {
        let mut prev = vnoise(7, 0.0, 3.3);
        for i in 1..400 {
            let x = (i as f64) * 0.05;
            let n = vnoise(7, x, 3.3);
            assert!(n >= 0.0 && n <= 1.0);
            let a = vnoise(7, x, 3.3);
            assert!((a - prev).abs() < 0.3);
            prev = a;
        }
    }

    #[test]
    fn forests_have_trees_and_deserts_have_cacti() {
        let f = biome_density(B_TEMP_FOREST);
        assert!(f[K_BROADLEAF] > 0.0);
        let d = biome_density(B_DESERT);
        assert!(d[K_CACTUS] > 0.0);
        assert!(d[K_BROADLEAF] == 0.0);
        let o = biome_density(B_OCEAN);
        for k in 0..K_COUNT {
            assert!(o[k] == 0.0);
        }
    }

    #[test]
    fn clumping_stays_bounded() {
        for k in 0..K_COUNT {
            for i in 0..200 {
                let c = clump_factor(k, 99, (i as f64) * 3.7, (i as f64) * 1.9);
                assert!(c >= 0.0 && c < 3.0);
            }
        }
    }

    #[test]
    fn level_distances_grow_and_buckets_have_room() {
        for k in 0..K_COUNT {
            let i = &KIND_INFO[k];
            assert!(i.lod[0] < i.lod[1] && i.lod[1] < i.lod[2] && i.lod[2] < i.lod[3] && i.lod[3] < i.far);
            for l in 0..NLOD {
                assert!(i.cap[l] > 0);
            }
        }
        // the tile ring must reach the farthest view distance
        let far_max = KIND_INFO.iter().fold(0.0f64, |m, i| if i.far > m { i.far } else { m });
        assert!((TILE_R as f64) * TILE_M >= far_max);
    }

    #[test]
    fn view_order_is_nearest_first() {
        let f = Flora::new();
        assert_eq!(f.order[0], (0, 0));
        let mut last = 0;
        for &(a, b) in f.order.iter() {
            let d = a * a + b * b;
            assert!(d >= last);
            last = d;
        }
    }
}
