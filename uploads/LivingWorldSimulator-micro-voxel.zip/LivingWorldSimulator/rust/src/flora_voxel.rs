//! Micro-voxel plant models. Every plant kind is a small cloud of cubes ("voxels") in five levels of detail, all of
//! them voxel grids (each level merges 2 x 2 x 2 cubes of the finer one; the finest cubes are 2 cm for grass and 12 cm
//! for trees, the coarsest are 16 times bigger).
//! The models are baked offline by `tools/gen_voxels.py` into `rust/assets/voxels.b64` (base64 text, so the project stays
//! free of binary files), which is embedded in the library and decoded at start-up; nothing is generated at run time and
//! the shapes can be changed without touching any Rust code.
//!
//! Decoded layout (little endian):
//!   "LWVX", u32 version (1), u32 kinds, u32 lods
//!   for every kind, for every level: u32 voxel count, f32 cube size (m), then `count` records of 14 bytes:
//!       i16 x, y, z (1/1024 m)   u8 r, g, b   u8 tint   i8 nx, ny, nz (1/127)   u8 sway

pub const K_GRASS: usize = 0;
pub const K_TALL_GRASS: usize = 1;
pub const K_FLOWER: usize = 2;
pub const K_FERN: usize = 3;
pub const K_BUSH: usize = 4;
pub const K_ROCK: usize = 5;
pub const K_BROADLEAF: usize = 6;
pub const K_CONIFER: usize = 7;
pub const K_PALM: usize = 8;
pub const K_ACACIA: usize = 9;
pub const K_CACTUS: usize = 10;
pub const K_DEAD_TREE: usize = 11;
pub const K_COUNT: usize = 12;

/// levels of detail per kind: 0 = finest cubes, every next level merges 2 x 2 x 2 cubes of the one before
pub const NLOD: usize = 5;
/// one bucket = one kind at one level of detail
pub const NBUCKET: usize = K_COUNT * NLOD;
/// floats per voxel in the GPU buffer: x y z size | r g b tint | nx ny nz sway
pub const VOX_FLOATS: usize = 12;

const RECORD_BYTES: usize = 14;

static VOXEL_B64: &str = include_str!("../assets/voxels.b64");

/// the voxels of one kind at one level of detail, ready to be uploaded
pub struct VoxLod {
    /// edge length of one cube in metres (at plant scale 1)
    pub size: f32,
    /// `VOX_FLOATS` floats per voxel
    pub data: Vec<f32>,
}

impl VoxLod {
    pub fn count(&self) -> usize {
        self.data.len() / VOX_FLOATS
    }
}

pub struct VoxModels {
    /// indexed by `kind * NLOD + level`
    pub lods: Vec<VoxLod>,
}

/// standard base64 (whitespace is skipped, padding ends the data); no crates needed
fn b64_decode(s: &str) -> Result<Vec<u8>, String> {
    let mut out: Vec<u8> = Vec::with_capacity(s.len() / 4 * 3 + 3);
    let mut acc: u32 = 0;
    let mut nbits: u32 = 0;
    for c in s.bytes() {
        let v: u32 = match c {
            b'A'..=b'Z' => (c - b'A') as u32,
            b'a'..=b'z' => (c - b'a') as u32 + 26,
            b'0'..=b'9' => (c - b'0') as u32 + 52,
            b'+' => 62,
            b'/' => 63,
            b'=' => break,
            b' ' | b'\n' | b'\r' | b'\t' => continue,
            _ => return Err(String::from("voxel models: bad character in data")),
        };
        acc = (acc << 6) | v;
        nbits += 6;
        if nbits >= 8 {
            nbits -= 8;
            out.push(((acc >> nbits) & 0xFF) as u8);
            acc &= (1u32 << nbits) - 1;
        }
    }
    Ok(out)
}

fn rd_u32(b: &[u8], p: usize) -> u32 {
    u32::from_le_bytes([b[p], b[p + 1], b[p + 2], b[p + 3]])
}

fn rd_i16(b: &[u8], p: usize) -> i16 {
    i16::from_le_bytes([b[p], b[p + 1]])
}

impl VoxModels {
    /// parse the embedded model file
    pub fn load() -> Result<VoxModels, String> {
        let bytes = b64_decode(VOXEL_B64)?;
        VoxModels::parse(&bytes)
    }

    pub fn parse(b: &[u8]) -> Result<VoxModels, String> {
        if b.len() < 16 || &b[0..4] != &b"LWVX"[..] {
            return Err(String::from("voxel models: bad header"));
        }
        let version = rd_u32(b, 4);
        let kinds = rd_u32(b, 8) as usize;
        let lods = rd_u32(b, 12) as usize;
        if version != 1 || kinds != K_COUNT || lods != NLOD {
            return Err(format!("voxel models: unexpected layout (v{} {} kinds {} levels)", version, kinds, lods));
        }
        let mut p = 16usize;
        let mut out: Vec<VoxLod> = Vec::with_capacity(NBUCKET);
        for _ in 0..NBUCKET {
            if p + 8 > b.len() {
                return Err(String::from("voxel models: file ends early"));
            }
            let n = rd_u32(b, p) as usize;
            let size = f32::from_bits(rd_u32(b, p + 4));
            p += 8;
            if p + n * RECORD_BYTES > b.len() {
                return Err(String::from("voxel models: file ends early"));
            }
            let mut data: Vec<f32> = Vec::with_capacity(n * VOX_FLOATS);
            for _ in 0..n {
                let x = (rd_i16(b, p) as f32) / 1024.0;
                let y = (rd_i16(b, p + 2) as f32) / 1024.0;
                let z = (rd_i16(b, p + 4) as f32) / 1024.0;
                let r = (b[p + 6] as f32) / 255.0;
                let g = (b[p + 7] as f32) / 255.0;
                let bl = (b[p + 8] as f32) / 255.0;
                let tint = (b[p + 9] as f32) / 255.0;
                let nx = ((b[p + 10] as i8) as f32) / 127.0;
                let ny = ((b[p + 11] as i8) as f32) / 127.0;
                let nz = ((b[p + 12] as i8) as f32) / 127.0;
                let sway = (b[p + 13] as f32) / 255.0;
                data.extend_from_slice(&[x, y, z, size, r, g, bl, tint, nx, ny, nz, sway]);
                p += RECORD_BYTES;
            }
            out.push(VoxLod { size, data });
        }
        Ok(VoxModels { lods: out })
    }

    pub fn lod(&self, kind: usize, level: usize) -> &VoxLod {
        &self.lods[kind * NLOD + level]
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn embedded_models_load() {
        let m = VoxModels::load().expect("voxel models");
        assert_eq!(m.lods.len(), NBUCKET);
        for k in 0..K_COUNT {
            for l in 0..NLOD {
                assert!(m.lod(k, l).count() > 0, "kind {} level {} is empty", k, l);
            }
            // every coarser level has fewer, bigger cubes
            for l in 0..NLOD - 1 {
                assert!(m.lod(k, l).size < m.lod(k, l + 1).size, "kind {} level {} is not coarser", k, l + 1);
            }
        }
    }

    #[test]
    fn base64_decodes() {
        assert_eq!(b64_decode("TWFu").unwrap(), b"Man".to_vec());
        assert_eq!(b64_decode("TWE=").unwrap(), b"Ma".to_vec());
        assert_eq!(b64_decode("TQ==").unwrap(), b"M".to_vec());
        assert_eq!(b64_decode("TW\nFu\n").unwrap(), b"Man".to_vec());
        assert!(b64_decode("T$Fu").is_err());
    }

    #[test]
    fn bad_data_is_rejected() {
        assert!(VoxModels::parse(&[0u8; 4]).is_err());
        assert!(VoxModels::parse(b"XXXX00000000000000000").is_err());
    }
}
