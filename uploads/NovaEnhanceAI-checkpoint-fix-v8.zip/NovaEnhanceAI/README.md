# NovaEnhance AI

An offline, on-device AI photo enhancement app for Android. You teach the
model with your own low-quality/high-quality image pairs; it keeps improving
through real on-device training - no cloud, no accounts, no servers, no API
keys, and (deliberately) no TensorFlow or Python step required by anyone
building this project.

## What's actually running on-device

- **Inference & training**: a small residual CNN, entirely hand-written in
  C++ (`app/src/main/cpp/nn/network.cpp`) - forward pass, backward pass
  (backpropagation), and an Adam optimizer, all implemented from scratch. No
  TensorFlow, no TFLite, no ONNX Runtime, no bundled model asset, and no
  external generation step for anyone building this app: a fresh model is
  just `NativeNeuralEngine.TOTAL_PARAMS` randomly-initialized floats,
  created directly in Kotlin the first time the app runs (see
  `ai/model/ModelRepository.createModel`). "Training" is real gradient
  descent against your image pairs, not a simulated progress bar.
- **Correctness verification**: the hand-derived backward-pass math is
  checked against numerical (finite-difference) gradients before being
  trusted - see `tools/nn_verification/`. All checked gradients match
  analytically to within ~1e-5 relative error (effectively floating-point
  precision limits), which is the standard, rigorous way to confirm a
  backprop implementation is correct.
- **Classical image processing**: a separate native library doing
  tile-based Gaussian blur, unsharp-mask sharpening, bilateral denoise,
  bilinear resize, and the synthetic degradations (noise/JPEG-blocking/
  motion-blur/color-fade) used by the automatic dataset generator.
- **Anti-forgetting**: experience replay (a curated buffer of past training
  pairs mixed into every new session) + L2-SP regularization (a penalty for
  drifting away from an anchored snapshot of pre-session weights, computed
  directly in `network.cpp`'s `trainStep`). Described honestly as replay +
  L2-SP, not as full Elastic Weight Consolidation, which would need
  Fisher-information machinery this project doesn't implement.
- **Adaptive training / self-improvement loop**: rule-based heuristics
  (batch size / learning rate / epochs derived from RAM, thermal state, and
  recent loss trends) and a weak-area rescoring pass after each promoted
  session - see `training/trainer/AdaptiveTrainingController.kt` and
  `SelfImprovementOrchestrator.kt` for exactly what each does and why.
  Thermal/RAM safety itself lives in one place, `utils/ThermalGovernor.kt`,
  and is re-checked continuously (not just once at session start) by every
  sustained-compute path that shares it: the training batch loop,
  validation, rescoring, AND a manual "Enhance" tap on a photo - see that
  file's doc comment for the graduated NONE/LIGHT (full speed) ->
  MODERATE (paced) -> SEVERE/CRITICAL (paused, or paced hard if the user
  disabled the hard pause) behavior.

## Before your first build

Nothing extra required. Unlike an earlier version of this project (which
used TensorFlow Lite's on-device training feature and needed a one-time
Python step to author the initial model graph), the app now creates its own
default model the first time it runs - no bundled asset, no Python, no
network access needed by the build pipeline or the app itself. If you're
looking at an old build log or an older copy of this README that mentions
`tools/model_builder/build_model.py` or a `.tflite` asset, that's the
previous architecture; it's gone.

## Build commands

```
./gradlew assembleDebug --no-daemon --configuration-cache --build-cache --parallel
./gradlew assembleRelease --no-daemon --configuration-cache --build-cache --parallel
```

Requires JDK 17, Gradle 8.6 (the CI workflow materializes the wrapper itself
- see the workflow file's comments for why a wrapper jar isn't hand-committed),
Android SDK, NDK 25.2.9519653, CMake 3.22.1. Release builds fall back to
debug signing if no `RELEASE_STORE_*` secrets/`app/keystore.properties` are
configured, so `assembleRelease` succeeds on a brand-new checkout with zero
manual setup - replace that with real signing before shipping to users.

## Testing

`app/src/test` has JVM unit tests for every piece of pure logic that doesn't
need a real Android framework/device (pixel-buffer padding/cropping, tensor
codec round-trips including a regression test for a rounding-bias fix, the
`.novamodel` bundle format, model metadata JSON round-tripping,
degradation-recipe range invariants, and the result-type helpers). Run them
with:

```
./gradlew testDebugUnitTest
```

The neural network's own correctness is verified separately, outside the
Android test framework entirely - see `tools/nn_verification/README.md`.
That's deliberate: gradient checking needs double-precision arithmetic to
be trustworthy (see that README for why), which is a property of the
*verification* tooling, not something the production (float32, performance-
oriented) engine should carry.

Code that needs `android.graphics.Bitmap`, `Context`, or other
framework/device behavior (dataset analysis, the DAOs) is written to be
exercised by instrumented tests (`app/src/androidTest`) on a real
device/emulator - none are included yet, since I can't run an emulator in
the environment this was built in to verify them.

## Architecture

```
ui/            Jetpack Compose screens, ViewModels, navigation, theme
ai/
  engine/      NovaModelEngine (model state + checkpoint I/O), NativeNeuralEngine
               (JNI bridge to the C++ CNN), tile processing, classical filters
  model/       Model metadata + registry/version repository
training/
  trainer/     Adaptive controller, experience replay, validator, the training
               orchestrator itself, and the self-improvement loop
  dataset/     Dataset analysis (dedup/quality/difficulty), degradation generator,
               dataset manager (add/remove/import/export)
  checkpoint/  The .novamodel export/import bundle format
database/      Room entities/DAOs (model registry, versions, dataset, sessions,
               loss history, validation metrics, replay buffer)
storage/       Centralized file-path resolution + DataStore-backed settings
workers/       WorkManager (constraint scheduling) + the training foreground service
di/            Manual dependency-injection container (see ServiceLocator's doc
               comment for why this isn't Hilt)
```

`app/src/main/cpp` holds the native code: `nn/` is the from-scratch neural
network, `filters/` is the classical image-processing library.
`tools/nn_verification/` holds the (non-Android, standalone) correctness
checks for the network math.

## The network architecture

```
input (64x64x3, float32, [0,1])
  -> Conv 3x3, 3->48, ReLU
  -> Conv 3x3, 48->48, ReLU
  -> Conv 3x3, 48->48, ReLU
  -> Conv 3x3, 48->3            (near-zero init, see below)
  -> output = clip(input + conv4_out, 0, 1)     (global residual)
```

~44,211 parameters (widened from an original ~20,259 on 2026-09-06 - C1/C2
went 32->48 for more capacity headroom; see `network.h`'s dated comment).
Deliberately small: every layer's backward pass is hand-derived and
gradient-checked, and this runs on a phone CPU with cache-friendly
nested-loop convolution the compiler can auto-vectorize (no hand-written
SIMD intrinsics, no BLAS, no GPU delegate) - capacity is traded for being
small enough to verify correctly and fast enough to actually train in the
background. `conv2dForward`/`conv2dBackward` take Cin/Cout as arguments
rather than hardcoding them, so widening channels is a `network.h` constants
change, not new backward-pass math; adding another *layer* (depth, not
width) would be the real undertaking, since `inferForward`/`trainStep` call
each layer by hand in sequence rather than looping over a layer list. The
tail convolution is initialized with a very small standard deviation so a
fresh install "enhances" photos as an approximate no-op rather than emitting
random-noise garbage, visibly improving from there as the user trains it -
the same identity-at-init rationale as before, just implemented as a plain
`std::normal_distribution` call now instead of a Keras initializer.

## Honest limitations

- This was built without the ability to run an actual Android/Gradle build
  end-to-end - there's no Android SDK, emulator, or network access in the
  environment it was written in. What COULD be verified, was: the C++ math
  (compiled and gradient-checked standalone with plain g++, independent of
  Android), and static consistency checks (JNI method names matching
  exactly between Kotlin and C++, package declarations matching directory
  structure, import resolution, dependency injection wiring). "The CI badge
  is green" is still the actual end-to-end verification step.
- The four validation metrics (detail recovery, noise reduction, sharpness
  improvement, artifact removal) are deliberately simple, explainable
  proxies (PSNR, a Laplacian-based sharpness/noise estimate, a block-edge
  gradient ratio) - not a claim of research-grade no-reference image quality
  assessment, which remains an open problem.
- No hand-written SIMD intrinsics, no multi-threading within a single
  `trainStep`/`inferForward` call, and no INT8 quantization - the
  convolution loops were restructured (Cout innermost, so weight access is
  contiguous and the compiler can auto-vectorize it) for cache locality and
  auto-vectorization, but nothing here manually targets NEON or fans a
  single call out across threads. That restructuring was verified, not just
  argued: `inferForward` output and per-step loss are bit-for-bit identical
  to the pre-change version; params/momentum/velocity after several
  training steps differ by at most ~6e-8 absolute (one documented,
  intentional float32 reassociation in `conv2dBackward`'s `dxPadded`
  accumulation - see the comment there), two orders of magnitude under the
  ~1e-5 relative tolerance `tools/nn_verification/` already holds this
  network to. All three existing checks there
  (`gradient_check`/`production_integration_check`/`lr_saturation_check`)
  pass against the restructured code. Measured ~3-4x faster `trainStep`
  calls on an x86 dev machine at `-O3` - a directional signal from better
  cache reuse and auto-vectorization, not a claim about what NEON on an
  actual ARM device will show, but the two prior bottlenecks in the batch
  loop are now compute time and non-CPU I/O, not this. Explicit NEON
  intrinsics, multi-threading, and quantization remain real, meaningful
  headroom beyond this if it's still not enough on some device - re-verify
  against `tools/nn_verification/` again before trusting any further change
  here, same as before.
- Tile processing (`TileProcessor`) computes tiles concurrently (bounded by
  device core count and, via `ThermalGovernor`, current thermal/RAM state)
  but always *writes* each computed tile into the output bitmap
  sequentially, in raster order, before starting the next chunk - so a
  tile's seam always blends against a left/top neighbor that's already
  been written, exactly as the single-threaded version did. Compute and
  write are deliberately split for this reason; see the class doc comment
  before changing either half.
