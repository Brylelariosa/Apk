// Verifies the app's configured learning rates (Constants.DEFAULT_LEARNING_RATE
// and its adaptive-controller ceiling) stay clear of a real failure mode
// this architecture has: the clip[0,1] output activation has EXACTLY zero
// gradient outside that range, so a too-high learning rate can push the
// pre-clip value far enough out that gradients stop flowing entirely - the
// network gets permanently stuck rather than just training slowly. This
// isn't theoretical; it was found by running this exact kind of check
// during development (an early stress test using lr=0.02 got stuck within
// 30 steps). Re-run this if DEFAULT_LEARNING_RATE or the adaptive
// controller's boost factor ever change.
//
// NOTE on runtime: a single trainStep on this architecture (64x64 tile, 32
// channels, unoptimized scalar convolution - no SIMD/threading, by design,
// see the README's "Honest limitations") takes roughly 200ms on a modern
// desktop CPU. This script keeps step counts modest specifically so it
// stays quick to re-run; that's a property of the *verification script*,
// not a claim about real training throughput on a phone (which trains on
// varied batches over many sessions, not hundreds of repeated steps on one
// fixed example).
#include "../../app/src/main/cpp/nn/network.cpp"

#include <cstdio>
#include <random>

using namespace novaenhance::nn;

namespace {

bool runAndCheck(float learningRate, int steps, const char* label) {
    std::vector<float> params(TOTAL_PARAMS);
    initializeParams(params.data(), 7);

    std::mt19937 rng(99);
    std::uniform_real_distribution<float> dist(0.0f, 1.0f);
    std::vector<float> input(INPUT_FLOATS), target(OUTPUT_FLOATS);
    for (auto& v : input) v = dist(rng);
    for (auto& v : target) v = dist(rng);

    std::vector<float> momentum(TOTAL_PARAMS, 0.0f), velocity(TOTAL_PARAMS, 0.0f);
    float first = -1.0f, last = -1.0f;
    for (int step = 1; step <= steps; ++step) {
        float loss = trainStep(input.data(), target.data(), 1, params.data(),
                                momentum.data(), velocity.data(), nullptr, step, learningRate, 0.0f);
        if (step == 1) first = loss;
        last = loss;
    }
    bool improved = last < first;
    printf("%-40s lr=%.5f steps=%4d  first=%.5f last=%.5f  %s\n",
           label, learningRate, steps, first, last, improved ? "IMPROVED" : "STUCK/WORSE");
    return improved;
}

}  // namespace

int main() {
    printf("--- Known-bad case (documents the failure mode exists) ---\n");
    bool badCaseStuck = !runAndCheck(0.02f, 30, "Unsafe rate (should get stuck)");

    printf("\n--- App's actual configuration ---\n");
    bool defaultOk = runAndCheck(1e-4f, 50, "Constants.DEFAULT_LEARNING_RATE");
    bool boostedOk = runAndCheck(1.5e-4f, 50, "Adaptive ceiling (1.5x default)");

    printf("\n--- Margin check (still safe somewhat above the ceiling) ---\n");
    bool marginOk = runAndCheck(1e-3f, 50, "10x the default (still safe)");

    printf("\n%s\n", (badCaseStuck && defaultOk && boostedOk && marginOk) ? "PASS" : "FAIL");
    return (badCaseStuck && defaultOk && boostedOk && marginOk) ? 0 : 1;
}

