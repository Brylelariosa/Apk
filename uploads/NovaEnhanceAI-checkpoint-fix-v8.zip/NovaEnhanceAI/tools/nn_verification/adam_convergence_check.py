"""Sanity check for the Adam optimizer update - verifies it actually
descends on a simple quadratic loss and that bias correction behaves as
expected in early steps (this is the exact formula that'll get ported to C++)."""
import numpy as np

def adam_step(param, grad, m, v, t, lr=0.01, beta1=0.9, beta2=0.999, eps=1e-8):
    m = beta1 * m + (1 - beta1) * grad
    v = beta2 * v + (1 - beta2) * (grad * grad)
    m_hat = m / (1 - beta1 ** t)
    v_hat = v / (1 - beta2 ** t)
    param = param - lr * m_hat / (np.sqrt(v_hat) + eps)
    return param, m, v

# Minimize f(x) = (x - 3)^2, gradient = 2(x-3)
x = np.array([0.0])
m = np.zeros_like(x)
v = np.zeros_like(x)

losses = []
for t in range(1, 201):
    grad = 2 * (x - 3.0)
    x, m, v = adam_step(x, grad, m, v, t, lr=0.05)
    losses.append(float((x[0] - 3.0) ** 2))

print(f"Start loss: {(0-3.0)**2:.4f}")
print(f"Final x: {x[0]:.4f} (target 3.0)")
print(f"Final loss: {losses[-1]:.8f}")
print("Monotonically converging (loss[150] > loss[199]):", losses[150] > losses[199])
print("PASS" if abs(x[0] - 3.0) < 0.01 else "FAIL")
