// Standalone test harness (not part of the Android build). This file is
// self-contained in double precision specifically so gradient checking is
// unambiguous: float32 finite-difference checking of a network with tiny
// (~1e-4) gradients runs into catastrophic cancellation (the two nearly-
// equal loss values lose almost all significant digits when subtracted),
// and using a large epsilon to compensate risks crossing a ReLU/clip
// "kink" (a genuine discontinuity in the derivative) and reporting a false
// mismatch that isn't actually a bug. Double precision with a small epsilon
// avoids both problems at once. The formulas/indexing here are IDENTICAL
// to network.cpp's float32 implementation (same layout, same operation
// order) - only the numeric type differs - so verifying this validates the
// same algorithm network.cpp implements.
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <random>
#include <vector>

namespace {

constexpr int KERNEL = 3;

inline int idx3(int i, int j, int c, int W, int C) { return (i * W + j) * C + c; }
inline int widx(int ki, int kj, int cin, int cout, int Cin, int Cout) {
    return ((ki * KERNEL + kj) * Cin + cin) * Cout + cout;
}

void conv2dForward(const double* x, int H, int W, int Cin,
                    const double* w, const double* b, int Cout,
                    double* out, double* xPadded) {
    const int pad = KERNEL / 2;
    const int PW = W + 2 * pad, PH = H + 2 * pad;
    std::fill(xPadded, xPadded + static_cast<size_t>(PH) * PW * Cin, 0.0);
    for (int i = 0; i < H; ++i)
        for (int j = 0; j < W; ++j)
            for (int c = 0; c < Cin; ++c)
                xPadded[idx3(i + pad, j + pad, c, PW, Cin)] = x[idx3(i, j, c, W, Cin)];

    for (int i = 0; i < H; ++i) {
        for (int j = 0; j < W; ++j) {
            for (int co = 0; co < Cout; ++co) {
                double sum = b[co];
                for (int ki = 0; ki < KERNEL; ++ki)
                    for (int kj = 0; kj < KERNEL; ++kj)
                        for (int ci = 0; ci < Cin; ++ci)
                            sum += xPadded[idx3(i + ki, j + kj, ci, PW, Cin)] * w[widx(ki, kj, ci, co, Cin, Cout)];
                out[idx3(i, j, co, W, Cout)] = sum;
            }
        }
    }
}

void conv2dBackward(const double* dout, const double* xPadded, int H, int W, int Cin,
                     const double* w, int Cout,
                     double* dxPadded, double* dw, double* db) {
    const int pad = KERNEL / 2;
    const int PW = W + 2 * pad, PH = H + 2 * pad;
    std::fill(dxPadded, dxPadded + static_cast<size_t>(PH) * PW * Cin, 0.0);
    for (int i = 0; i < H; ++i) {
        for (int j = 0; j < W; ++j) {
            for (int co = 0; co < Cout; ++co) {
                double doutVal = dout[idx3(i, j, co, W, Cout)];
                db[co] += doutVal;
                for (int ki = 0; ki < KERNEL; ++ki) {
                    for (int kj = 0; kj < KERNEL; ++kj) {
                        for (int ci = 0; ci < Cin; ++ci) {
                            double xpVal = xPadded[idx3(i + ki, j + kj, ci, PW, Cin)];
                            double wVal = w[widx(ki, kj, ci, co, Cin, Cout)];
                            dw[widx(ki, kj, ci, co, Cin, Cout)] += xpVal * doutVal;
                            dxPadded[idx3(i + ki, j + kj, ci, PW, Cin)] += wVal * doutVal;
                        }
                    }
                }
            }
        }
    }
}

void cropAccumulate(const double* padded, int H, int W, int C, double* dst) {
    const int pad = KERNEL / 2;
    const int PW = W + 2 * pad;
    for (int i = 0; i < H; ++i)
        for (int j = 0; j < W; ++j)
            for (int c = 0; c < C; ++c)
                dst[idx3(i, j, c, W, C)] += padded[idx3(i + pad, j + pad, c, PW, C)];
}

void reluForward(const double* x, double* out, int n) {
    for (int i = 0; i < n; ++i) out[i] = x[i] > 0.0 ? x[i] : 0.0;
}
void reluBackwardFromPost(const double* dout, const double* post, double* dx, int n) {
    for (int i = 0; i < n; ++i) dx[i] = post[i] > 0.0 ? dout[i] : 0.0;
}
void clip01Forward(const double* x, double* out, int n) {
    for (int i = 0; i < n; ++i) out[i] = std::min(1.0, std::max(0.0, x[i]));
}
void clip01BackwardFromPre(const double* dout, const double* pre, double* dx, int n) {
    for (int i = 0; i < n; ++i) dx[i] = (pre[i] >= 0.0 && pre[i] <= 1.0) ? dout[i] : 0.0;
}
double l1Loss(const double* pred, const double* target, int n) {
    double s = 0.0;
    for (int i = 0; i < n; ++i) s += std::fabs(pred[i] - target[i]);
    return s / n;
}
void l1LossGrad(const double* pred, const double* target, double* grad, int n) {
    for (int i = 0; i < n; ++i) {
        double diff = pred[i] - target[i];
        grad[i] = (diff > 0.0 ? 1.0 : (diff < 0.0 ? -1.0 : 0.0)) / n;
    }
}

std::mt19937 rng(1234);
std::vector<double> randomVec(int n, double scale, double bias) {
    std::uniform_real_distribution<double> dist(0.0, 1.0);
    std::vector<double> v(n);
    for (auto& x : v) x = dist(rng) * scale + bias;
    return v;
}

struct SmallNet {
    static constexpr int H = 6, W = 6, CIN_ = 3, C1_ = 4, C2_ = 4, COUT_ = 3;
    static constexpr int PAD = KERNEL / 2, P = H + 2 * PAD;

    std::vector<double> w1, b1, w2, b2, w3, b3, w4, b4;

    SmallNet() {
        // Deliberately avoid exact zeros so we're not accidentally testing
        // only the "both sides agree it's zero" case.
        w1 = randomVec(KERNEL * KERNEL * CIN_ * C1_, 0.4, -0.2);
        b1 = randomVec(C1_, 0.2, -0.1);
        w2 = randomVec(KERNEL * KERNEL * C1_ * C1_, 0.4, -0.2);
        b2 = randomVec(C1_, 0.2, -0.1);
        w3 = randomVec(KERNEL * KERNEL * C1_ * C2_, 0.4, -0.2);
        b3 = randomVec(C2_, 0.2, -0.1);
        w4 = randomVec(KERNEL * KERNEL * C2_ * COUT_, 0.4, -0.2);
        b4 = randomVec(COUT_, 0.2, -0.1);
    }

    struct Grads {
        std::vector<double> dx, dw1, db1, dw2, db2, dw3, db3, dw4, db4;
    };

    double forward(const std::vector<double>& x, const std::vector<double>& target, Grads* g) {
        std::vector<double> xp1(P * P * CIN_), c1(H * W * C1_), r1(H * W * C1_);
        std::vector<double> xp2(P * P * C1_), c2(H * W * C1_), r2(H * W * C1_);
        std::vector<double> xp3(P * P * C1_), c3(H * W * C2_), r3(H * W * C2_);
        std::vector<double> xp4(P * P * C2_), c4(H * W * COUT_);
        std::vector<double> residual(H * W * COUT_), output(H * W * COUT_);

        conv2dForward(x.data(), H, W, CIN_, w1.data(), b1.data(), C1_, c1.data(), xp1.data());
        reluForward(c1.data(), r1.data(), H * W * C1_);
        conv2dForward(r1.data(), H, W, C1_, w2.data(), b2.data(), C1_, c2.data(), xp2.data());
        reluForward(c2.data(), r2.data(), H * W * C1_);
        conv2dForward(r2.data(), H, W, C1_, w3.data(), b3.data(), C2_, c3.data(), xp3.data());
        reluForward(c3.data(), r3.data(), H * W * C2_);
        conv2dForward(r3.data(), H, W, C2_, w4.data(), b4.data(), COUT_, c4.data(), xp4.data());
        for (int i = 0; i < H * W * COUT_; ++i) residual[i] = x[i] + c4[i];
        clip01Forward(residual.data(), output.data(), H * W * COUT_);

        double loss = l1Loss(output.data(), target.data(), H * W * COUT_);
        if (g == nullptr) return loss;

        std::vector<double> dOutput(H * W * COUT_), dResidual(H * W * COUT_);
        l1LossGrad(output.data(), target.data(), dOutput.data(), H * W * COUT_);
        clip01BackwardFromPre(dOutput.data(), residual.data(), dResidual.data(), H * W * COUT_);

        std::vector<double> dxp4(P * P * C2_, 0.0);
        g->dw4.assign(KERNEL * KERNEL * C2_ * COUT_, 0.0);
        g->db4.assign(COUT_, 0.0);
        conv2dBackward(dResidual.data(), xp4.data(), H, W, C2_, w4.data(), COUT_, dxp4.data(), g->dw4.data(), g->db4.data());
        std::vector<double> dr3(H * W * C2_, 0.0);
        cropAccumulate(dxp4.data(), H, W, C2_, dr3.data());
        std::vector<double> dc3(H * W * C2_);
        reluBackwardFromPost(dr3.data(), r3.data(), dc3.data(), H * W * C2_);

        std::vector<double> dxp3(P * P * C1_, 0.0);
        g->dw3.assign(KERNEL * KERNEL * C1_ * C2_, 0.0);
        g->db3.assign(C2_, 0.0);
        conv2dBackward(dc3.data(), xp3.data(), H, W, C1_, w3.data(), C2_, dxp3.data(), g->dw3.data(), g->db3.data());
        std::vector<double> dr2(H * W * C1_, 0.0);
        cropAccumulate(dxp3.data(), H, W, C1_, dr2.data());
        std::vector<double> dc2(H * W * C1_);
        reluBackwardFromPost(dr2.data(), r2.data(), dc2.data(), H * W * C1_);

        std::vector<double> dxp2(P * P * C1_, 0.0);
        g->dw2.assign(KERNEL * KERNEL * C1_ * C1_, 0.0);
        g->db2.assign(C1_, 0.0);
        conv2dBackward(dc2.data(), xp2.data(), H, W, C1_, w2.data(), C1_, dxp2.data(), g->dw2.data(), g->db2.data());
        std::vector<double> dr1(H * W * C1_, 0.0);
        cropAccumulate(dxp2.data(), H, W, C1_, dr1.data());
        std::vector<double> dc1(H * W * C1_);
        reluBackwardFromPost(dr1.data(), r1.data(), dc1.data(), H * W * C1_);

        std::vector<double> dxp1(P * P * CIN_, 0.0);
        g->dw1.assign(KERNEL * KERNEL * CIN_ * C1_, 0.0);
        g->db1.assign(C1_, 0.0);
        conv2dBackward(dc1.data(), xp1.data(), H, W, CIN_, w1.data(), C1_, dxp1.data(), g->dw1.data(), g->db1.data());

        g->dx.assign(H * W * CIN_, 0.0);
        cropAccumulate(dxp1.data(), H, W, CIN_, g->dx.data());
        for (int i = 0; i < H * W * CIN_; ++i) g->dx[i] += dResidual[i];  // input also appears directly in "residual = input + c4"

        return loss;
    }
};

int g_checked = 0, g_failed = 0;
double g_maxRelErr = 0.0;

void checkGrad(const char* name, int idx, double numerical, double analytical) {
    double relErr = std::fabs(numerical - analytical) / std::max(std::fabs(numerical) + std::fabs(analytical), 1e-10);
    g_checked++;
    if (relErr > 1e-4) {
        g_failed++;
        if (g_failed <= 15) {
            printf("  MISMATCH %s[%d]: numerical=%.10f analytical=%.10f relErr=%.6f\n", name, idx, numerical, analytical, relErr);
        }
    }
    g_maxRelErr = std::max(g_maxRelErr, relErr);
}

void checkVec(SmallNet& net, const char* name, std::vector<double>& param,
              const std::vector<double>& x, const std::vector<double>& target,
              const std::vector<double>& analytical, int limit, double eps) {
    int n = std::min((int)param.size(), limit);
    for (int i = 0; i < n; ++i) {
        double orig = param[i];
        param[i] = orig + eps;
        double lossPlus = net.forward(x, target, nullptr);
        param[i] = orig - eps;
        double lossMinus = net.forward(x, target, nullptr);
        param[i] = orig;
        double numerical = (lossPlus - lossMinus) / (2 * eps);
        checkGrad(name, i, numerical, analytical[i]);
    }
}

}  // namespace

int main() {
    SmallNet net;
    auto x = randomVec(SmallNet::H * SmallNet::W * SmallNet::CIN_, 0.6, 0.2);
    auto target = randomVec(SmallNet::H * SmallNet::W * SmallNet::COUT_, 1.0, 0.0);

    SmallNet::Grads g;
    double loss = net.forward(x, target, &g);
    printf("Forward loss: %.6f\n", loss);

    const double eps = 1e-6;  // safe for double precision, small enough to avoid crossing ReLU/clip kinks
    checkVec(net, "w1", net.w1, x, target, g.dw1, 100, eps);
    checkVec(net, "b1", net.b1, x, target, g.db1, 100, eps);
    checkVec(net, "w2", net.w2, x, target, g.dw2, 100, eps);
    checkVec(net, "b2", net.b2, x, target, g.db2, 100, eps);
    checkVec(net, "w3", net.w3, x, target, g.dw3, 100, eps);
    checkVec(net, "b3", net.b3, x, target, g.db3, 100, eps);
    checkVec(net, "w4", net.w4, x, target, g.dw4, 100, eps);
    checkVec(net, "b4", net.b4, x, target, g.db4, 100, eps);

    // Input gradient.
    std::vector<double> xCopy = x;
    for (int i = 0; i < (int)xCopy.size(); ++i) {
        double orig = xCopy[i];
        xCopy[i] = orig + eps;
        double lossPlus = net.forward(xCopy, target, nullptr);
        xCopy[i] = orig - eps;
        double lossMinus = net.forward(xCopy, target, nullptr);
        xCopy[i] = orig;
        double numerical = (lossPlus - lossMinus) / (2 * eps);
        checkGrad("input_x", i, numerical, g.dx[i]);
    }

    printf("\nChecked %d values, %d mismatches (relErr > 1e-4), max relative error = %.8f\n",
           g_checked, g_failed, g_maxRelErr);
    printf("%s\n", g_failed == 0 ? "PASS" : "FAIL");
    return g_failed == 0 ? 0 : 1;
}
