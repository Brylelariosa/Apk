# Neural Network Verification Tools

These are NOT part of the Android build - they're standalone checks used to
verify the from-scratch CNN's math (in `app/src/main/cpp/nn/`) before it's
trusted inside the app. Re-run these if you ever change the architecture or
the forward/backward pass logic.

- `numpy_reference_check.py` - the original reference implementation and
  gradient check, in NumPy. Run with `python3 numpy_reference_check.py`.
- `adam_convergence_check.py` - sanity-checks the Adam optimizer formula
  converges on a toy problem. Run with `python3 adam_convergence_check.py`.
- `gradient_check.cpp` - a double-precision C++ reimplementation of the same
  network (same formulas/indexing as `network.cpp`, just `double` instead of
  `float`) with rigorous gradient checking against numerical
  (finite-difference) derivatives. Double precision is used deliberately:
  float32 checking of a network with small gradients runs into catastrophic
  cancellation at a small epsilon, and a larger epsilon risks crossing a
  ReLU/clip "kink" and reporting a false mismatch. Compile and run with:
  ```
  g++ -std=c++17 -O2 -o /tmp/gradient_check gradient_check.cpp
  /tmp/gradient_check
  ```
  Expect all checked gradients to match analytically to within ~1e-5
  relative error ("0 mismatches... PASS").
- `production_integration_check.cpp` - exercises the REAL production
  float32 code (`inferForward`, `trainStep` at full architecture size, not
  a scaled-down test network): output stays in [0,1], loss decreases when
  overfitting one example, and the anti-forgetting anchor measurably
  reduces parameter drift. Compile and run with:
  ```
  g++ -std=c++17 -O2 -o /tmp/prod_check production_integration_check.cpp
  /tmp/prod_check
  ```
- `lr_saturation_check.cpp` - a real failure mode this architecture has:
  the clip[0,1] output activation has EXACTLY zero gradient outside that
  range, so a too-high learning rate can saturate the network and get it
  permanently stuck (found empirically, not theoretically - see the
  comment on `clip01BackwardFromPre` in `network.cpp`). This confirms the
  app's actual configured learning rate (`Constants.DEFAULT_LEARNING_RATE`)
  and its adaptive-controller ceiling both stay safely clear of that
  boundary. Compile and run with:
  ```
  g++ -std=c++17 -O2 -o /tmp/lr_check lr_saturation_check.cpp
  /tmp/lr_check
  ```
  Re-run this one specifically if `DEFAULT_LEARNING_RATE` or the adaptive
  controller's boost factor ever change.

None of this requires TensorFlow, Python ML libraries, or a GPU - just a
C++17 compiler and (for the two `.py` scripts) NumPy.
