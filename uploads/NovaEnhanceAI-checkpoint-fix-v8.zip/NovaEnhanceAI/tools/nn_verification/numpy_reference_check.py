"""
Reference implementation + gradient checking for the from-scratch CNN
that will replace TFLite in NovaEnhance AI. Every op's analytical backward
pass is checked against numerical (finite-difference) gradients before any
of this gets ported to Kotlin/C++.
"""
import numpy as np

np.random.seed(42)

# ---------- Ops: forward + backward ----------

def conv2d_forward(x, w, b):
    # x: (H, W, Cin), w: (kh, kw, Cin, Cout), b: (Cout,)  'same' padding, stride 1
    H, W, Cin = x.shape
    kh, kw, _, Cout = w.shape
    ph, pw = kh // 2, kw // 2
    xp = np.pad(x, ((ph, ph), (pw, pw), (0, 0)))
    out = np.zeros((H, W, Cout))
    for i in range(H):
        for j in range(W):
            patch = xp[i:i+kh, j:j+kw, :]  # (kh, kw, Cin)
            out[i, j, :] = np.tensordot(patch, w, axes=([0,1,2],[0,1,2])) + b
    return out, xp

def conv2d_backward(dout, x, xp, w, b):
    H, W, Cin = x.shape
    kh, kw, _, Cout = w.shape
    ph, pw = kh // 2, kw // 2
    dw = np.zeros_like(w)
    db = np.zeros_like(b)
    dxp = np.zeros_like(xp)
    for i in range(H):
        for j in range(W):
            patch = xp[i:i+kh, j:j+kw, :]
            for co in range(Cout):
                dw[:, :, :, co] += patch * dout[i, j, co]
                dxp[i:i+kh, j:j+kw, :] += w[:, :, :, co] * dout[i, j, co]
            db += dout[i, j, :]
    dx = dxp[ph:ph+H, pw:pw+W, :]
    return dx, dw, db

def relu_forward(x):
    return np.maximum(0, x)

def relu_backward(dout, x):
    return dout * (x > 0)

def clip01_forward(x):
    return np.clip(x, 0, 1)

def clip01_backward(dout, x):
    return dout * ((x >= 0) & (x <= 1))

# ---------- Small network: conv-relu-conv-relu-conv + global residual + clip ----------

def build_random_weights(cin, c1, c2, cout, k=3):
    return {
        "w1": np.random.randn(k, k, cin, c1) * 0.1, "b1": np.zeros(c1),
        "w2": np.random.randn(k, k, c1, c2) * 0.1, "b2": np.zeros(c2),
        "w3": np.random.randn(k, k, c2, cout) * 0.01, "b3": np.zeros(cout),
    }

def forward(x, p):
    c1, xp1 = conv2d_forward(x, p["w1"], p["b1"])
    r1 = relu_forward(c1)
    c2, xp2 = conv2d_forward(r1, p["w2"], p["b2"])
    r2 = relu_forward(c2)
    c3, xp3 = conv2d_forward(r2, p["w3"], p["b3"])
    residual = x + c3
    out = clip01_forward(residual)
    cache = (x, xp1, c1, r1, xp2, c2, r2, xp3, c3, residual)
    return out, cache

def backward(dout, cache, p):
    x, xp1, c1, r1, xp2, c2, r2, xp3, c3, residual = cache
    dresidual = clip01_backward(dout, residual)
    dx_from_res = dresidual  # residual = x + c3
    dc3 = dresidual
    dr2, dw3, db3 = conv2d_backward(dc3, r2, xp3, p["w3"], p["b3"])
    dc2 = relu_backward(dr2, c2)
    dr1, dw2, db2 = conv2d_backward(dc2, r1, xp2, p["w2"], p["b2"])
    dc1 = relu_backward(dr1, c1)
    dx_from_conv, dw1, db1 = conv2d_backward(dc1, x, xp1, p["w1"], p["b1"])
    dx = dx_from_res + dx_from_conv
    grads = {"w1": dw1, "b1": db1, "w2": dw2, "b2": db2, "w3": dw3, "b3": db3}
    return dx, grads

def l1_loss(pred, target):
    return np.mean(np.abs(pred - target))

def l1_loss_grad(pred, target):
    n = pred.size
    return np.sign(pred - target) / n

# ---------- Gradient check ----------

def gradient_check():
    H, W, Cin, C1, C2, Cout = 6, 6, 3, 4, 4, 3
    x = np.random.rand(H, W, Cin) * 0.5 + 0.25  # keep away from 0/1 clip boundary mostly
    target = np.random.rand(H, W, Cout)
    p = build_random_weights(Cin, C1, C2, Cout)

    out, cache = forward(x, p)
    loss = l1_loss(out, target)
    dloss_dout = l1_loss_grad(out, target)
    dx, grads = backward(dloss_dout, cache, p)

    eps = 1e-4
    max_rel_err = 0.0
    worst = None

    def loss_fn(p_):
        o, _ = forward(x, p_)
        return l1_loss(o, target)

    # Check a sample of weight gradients (checking every single one would be slow but exhaustive works fine at this size)
    for name in ["w1", "b1", "w2", "b2", "w3", "b3"]:
        arr = p[name]
        analytical = grads[name]
        it = np.nditer(arr, flags=['multi_index'])
        checked = 0
        for _ in it:
            idx = it.multi_index
            orig = arr[idx]
            arr[idx] = orig + eps
            loss_plus = loss_fn(p)
            arr[idx] = orig - eps
            loss_minus = loss_fn(p)
            arr[idx] = orig
            numerical = (loss_plus - loss_minus) / (2 * eps)
            ana = analytical[idx]
            rel_err = abs(numerical - ana) / max(abs(numerical) + abs(ana), 1e-8)
            if rel_err > max_rel_err:
                max_rel_err = rel_err
                worst = (name, idx, numerical, ana)
            checked += 1
            if checked > 30:  # sample per-tensor to keep runtime reasonable
                break

    # Also check input gradient (a few entries)
    def loss_fn_x(x_):
        o, _ = forward(x_, p)
        return l1_loss(o, target)

    checked = 0
    for i in range(H):
        for j in range(W):
            for c in range(Cin):
                orig = x[i, j, c]
                x[i, j, c] = orig + eps
                loss_plus = loss_fn_x(x)
                x[i, j, c] = orig - eps
                loss_minus = loss_fn_x(x)
                x[i, j, c] = orig
                numerical = (loss_plus - loss_minus) / (2 * eps)
                ana = dx[i, j, c]
                rel_err = abs(numerical - ana) / max(abs(numerical) + abs(ana), 1e-8)
                if rel_err > max_rel_err:
                    max_rel_err = rel_err
                    worst = ("input_x", (i, j, c), numerical, ana)
                checked += 1
                if checked > 30:
                    break

    print(f"Forward loss: {loss:.6f}")
    print(f"Max relative error across sampled gradients: {max_rel_err:.8f}")
    print(f"Worst case: {worst}")
    print("PASS" if max_rel_err < 1e-3 else "FAIL")

if __name__ == "__main__":
    gradient_check()
