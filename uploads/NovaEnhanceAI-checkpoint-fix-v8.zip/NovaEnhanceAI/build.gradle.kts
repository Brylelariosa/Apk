// Top-level build file. Plugin versions are declared here (applied false) and
// resolved per-module in app/build.gradle.kts. This keeps versions in one
// place without pulling in a separate version catalog, which keeps the
// project easy to read for a single-module app.
plugins {
    // AGP 8.4.x is the version line whose *minimum required* Gradle version is
    // 8.6 - matching the Gradle version pinned in gradle-wrapper.properties.
    id("com.android.application") version "8.4.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    // Note: we deliberately do NOT use org.jetbrains.kotlin.plugin.compose here -
    // that plugin only exists for Kotlin 2.0+. On Kotlin 1.9.24 the Compose
    // compiler is wired via composeOptions { kotlinCompilerExtensionVersion }
    // in app/build.gradle.kts instead.
    id("com.google.devtools.ksp") version "1.9.24-1.0.20" apply false
}

tasks.register("clean", Delete::class) {
    delete(rootProject.layout.buildDirectory)
}
