# NovaEnhance AI - release shrinking rules.
# Goal: keep the release APK small (minifyEnabled + shrinkResources are on)
# while protecting the handful of classes that are accessed reflectively,
# via JNI, or via Room's generated code.

# --- Room ---
# Entities/DAOs are referenced by generated code (*_Impl classes); keep
# field/annotation info so the generated implementations resolve correctly.
-keep class com.novaenhance.ai.database.entities.** { *; }
-keepclassmembers class com.novaenhance.ai.database.entities.** { *; }
-dontwarn androidx.room.**

# --- JNI (native image processing + neural network bridges) ---
# Native code calls into these methods by exact signature; R8 must not
# rename, inline, or remove them.
-keep class com.novaenhance.ai.ai.engine.NativeImageProcessor {
    native <methods>;
}
-keep class com.novaenhance.ai.ai.engine.NativeNeuralEngine {
    native <methods>;
}

# --- Kotlin coroutines / metadata ---
-keepattributes Signature, InnerClasses, EnclosingMethod
-keepattributes *Annotation*
-dontwarn kotlinx.coroutines.**

# --- Compose (defensive; AGP's default compose rules already cover most of this) ---
-dontwarn androidx.compose.**
