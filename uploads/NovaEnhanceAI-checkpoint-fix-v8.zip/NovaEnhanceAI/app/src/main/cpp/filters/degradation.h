#ifndef NOVAENHANCE_DEGRADATION_H
#define NOVAENHANCE_DEGRADATION_H

#include <cstdint>
#include <vector>

namespace novaenhance {

// Adds Gaussian sensor-style noise. `amount` in [0,1], sigma scales up to ~40
// intensity levels at amount=1.
std::vector<int32_t> addGaussianNoise(const std::vector<int32_t>& pixels,
                                       int width, int height,
                                       float amount, uint32_t seed);

// Simulates blocky JPEG-style compression artifacts via 8x8-block
// quantization of the (approximate) luma/chroma planes. This is a fast
// approximation of DCT quantization loss, not a bit-exact JPEG codec -
// good enough to teach the network to recognize and remove blockiness,
// which is the actual training goal.
std::vector<int32_t> simulateJpegArtifacts(const std::vector<int32_t>& pixels,
                                            int width, int height,
                                            int qualityPercent);

// Directional motion blur along `angleDegrees` over `lengthPx` pixels.
std::vector<int32_t> motionBlur(const std::vector<int32_t>& pixels,
                                 int width, int height,
                                 float angleDegrees, int lengthPx);

// Desaturates and shifts white balance to simulate faded/aged color.
std::vector<int32_t> colorFade(const std::vector<int32_t>& pixels,
                                int width, int height,
                                float fadeAmount);

}  // namespace novaenhance

#endif  // NOVAENHANCE_DEGRADATION_H
