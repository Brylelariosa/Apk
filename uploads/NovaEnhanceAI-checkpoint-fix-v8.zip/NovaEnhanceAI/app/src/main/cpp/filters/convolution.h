#ifndef NOVAENHANCE_CONVOLUTION_H
#define NOVAENHANCE_CONVOLUTION_H

#include <cstdint>
#include <vector>

namespace novaenhance {

// All functions operate on tightly-packed ARGB_8888 pixel buffers
// (one int32 per pixel: 0xAARRGGBB), matching Android's Bitmap.Config.ARGB_8888
// row layout. This keeps the JNI surface to plain int arrays so a tile can be
// handed across the JNI boundary without any Bitmap (de)serialization.
//
// `width`/`height` describe the tile being processed, NOT necessarily the
// full image - the caller (Kotlin TileProcessor) is responsible for slicing
// the source image into overlapping tiles (see TileProcessor.kt) so that a
// 4GB-RAM device never has to hold a full-resolution buffer plus a full-size
// duplicate in memory at once.

// Separable Gaussian blur. `sigma` <= 0 is treated as a no-op copy.
std::vector<int32_t> gaussianBlur(const std::vector<int32_t>& pixels,
                                   int width, int height, float sigma);

// Unsharp-mask sharpening: out = in + amount * (in - blur(in, sigma)).
// `amount` in [0, 3] where 1.0 is a mild, natural sharpen.
std::vector<int32_t> unsharpMask(const std::vector<int32_t>& pixels,
                                  int width, int height,
                                  float sigma, float amount);

// 3x3 edge-aware denoise: a bilateral-style filter that blurs flat regions
// while preserving strong edges, used for the "noise reduction" control.
std::vector<int32_t> denoiseBilateral(const std::vector<int32_t>& pixels,
                                       int width, int height,
                                       float spatialSigma, float rangeSigma);

// Bilinear resize used by both the resolution-enhancement path (upscale)
// and the dataset degradation generator (downscale to simulate low-res input).
std::vector<int32_t> resizeBilinear(const std::vector<int32_t>& pixels,
                                     int srcWidth, int srcHeight,
                                     int dstWidth, int dstHeight);

// Simple, fast structural-similarity-ish per-tile score in [0,1] used by
// the automatic model validator to compare "before" vs "after" tiles
// against a ground-truth tile without shipping a full SSIM implementation.
float quickSimilarityScore(const std::vector<int32_t>& a,
                            const std::vector<int32_t>& b,
                            int width, int height);

}  // namespace novaenhance

#endif  // NOVAENHANCE_CONVOLUTION_H
