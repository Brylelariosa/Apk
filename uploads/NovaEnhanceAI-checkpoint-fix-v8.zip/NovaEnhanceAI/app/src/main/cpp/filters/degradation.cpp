#include "degradation.h"

#include <algorithm>
#include <cmath>
#include <random>

namespace novaenhance {

namespace {
inline uint8_t channel(int32_t pixel, int shift) {
    return static_cast<uint8_t>((pixel >> shift) & 0xFF);
}
inline int clamp8(int v) { return std::min(255, std::max(0, v)); }
inline int32_t packArgb(int a, int r, int g, int b) {
    return (clamp8(a) << 24) | (clamp8(r) << 16) | (clamp8(g) << 8) | clamp8(b);
}
inline int clampi(int v, int lo, int hi) { return std::min(hi, std::max(lo, v)); }
}  // namespace

std::vector<int32_t> addGaussianNoise(const std::vector<int32_t>& pixels,
                                       int width, int height,
                                       float amount, uint32_t seed) {
    std::vector<int32_t> out(pixels.size());
    std::mt19937 rng(seed);
    float sigma = std::max(0.0f, amount) * 40.0f;
    std::normal_distribution<float> dist(0.0f, sigma);

    for (size_t i = 0; i < pixels.size(); ++i) {
        int32_t p = pixels[i];
        int r = channel(p, 16) + static_cast<int>(dist(rng));
        int g = channel(p, 8) + static_cast<int>(dist(rng));
        int b = channel(p, 0) + static_cast<int>(dist(rng));
        out[i] = packArgb(channel(p, 24), r, g, b);
    }
    return out;
}

std::vector<int32_t> simulateJpegArtifacts(const std::vector<int32_t>& pixels,
                                            int width, int height,
                                            int qualityPercent) {
    std::vector<int32_t> out = pixels;
    int quality = clampi(qualityPercent, 1, 100);
    // Lower quality -> larger quantization step -> blockier result.
    // At quality=100 step=1 (no visible change); at quality=1 step is large.
    int step = std::max(1, (100 - quality) / 4);

    for (int by = 0; by < height; by += 8) {
        for (int bx = 0; bx < width; bx += 8) {
            int blockH = std::min(8, height - by);
            int blockW = std::min(8, width - bx);

            // Average the block (mimics low-frequency-only DCT retention),
            // then quantize that average - this is what produces the
            // characteristic flat, blocky look of over-compressed JPEGs.
            long sumR = 0, sumG = 0, sumB = 0;
            int count = blockW * blockH;
            for (int y = 0; y < blockH; ++y) {
                for (int x = 0; x < blockW; ++x) {
                    int32_t p = pixels[(by + y) * width + (bx + x)];
                    sumR += channel(p, 16);
                    sumG += channel(p, 8);
                    sumB += channel(p, 0);
                }
            }
            int avgR = static_cast<int>(sumR / count);
            int avgG = static_cast<int>(sumG / count);
            int avgB = static_cast<int>(sumB / count);

            // Quantize the average to simulate coefficient rounding loss.
            auto quantize = [step](int v) { return (v / step) * step; };
            avgR = quantize(avgR);
            avgG = quantize(avgG);
            avgB = quantize(avgB);

            for (int y = 0; y < blockH; ++y) {
                for (int x = 0; x < blockW; ++x) {
                    int idx = (by + y) * width + (bx + x);
                    int32_t orig = pixels[idx];
                    // Blend original detail back in proportional to quality
                    // so we get a spectrum from subtle to severe, not just
                    // a binary flat-block vs original.
                    float blend = quality / 100.0f;
                    int r = static_cast<int>(avgR * (1 - blend) + channel(orig, 16) * blend);
                    int g = static_cast<int>(avgG * (1 - blend) + channel(orig, 8) * blend);
                    int b = static_cast<int>(avgB * (1 - blend) + channel(orig, 0) * blend);
                    out[idx] = packArgb(channel(orig, 24), r, g, b);
                }
            }
        }
    }
    return out;
}

std::vector<int32_t> motionBlur(const std::vector<int32_t>& pixels,
                                 int width, int height,
                                 float angleDegrees, int lengthPx) {
    if (lengthPx <= 1) return pixels;
    std::vector<int32_t> out(pixels.size());
    float rad = angleDegrees * static_cast<float>(M_PI) / 180.0f;
    float dx = std::cos(rad);
    float dy = std::sin(rad);
    int half = lengthPx / 2;

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            float r = 0, g = 0, b = 0;
            int count = 0;
            for (int t = -half; t <= half; ++t) {
                int sx = clampi(static_cast<int>(x + dx * t), 0, width - 1);
                int sy = clampi(static_cast<int>(y + dy * t), 0, height - 1);
                int32_t p = pixels[sy * width + sx];
                r += channel(p, 16);
                g += channel(p, 8);
                b += channel(p, 0);
                ++count;
            }
            int32_t centerAlpha = channel(pixels[y * width + x], 24);
            out[y * width + x] = packArgb(
                centerAlpha, static_cast<int>(r / count), static_cast<int>(g / count), static_cast<int>(b / count));
        }
    }
    return out;
}

std::vector<int32_t> colorFade(const std::vector<int32_t>& pixels,
                                int width, int height,
                                float fadeAmount) {
    std::vector<int32_t> out(pixels.size());
    float f = std::min(1.0f, std::max(0.0f, fadeAmount));

    for (size_t i = 0; i < pixels.size(); ++i) {
        int32_t p = pixels[i];
        int r = channel(p, 16), g = channel(p, 8), b = channel(p, 0);
        int luma = (r * 299 + g * 587 + b * 114) / 1000;

        // Desaturate toward luma...
        int fr = static_cast<int>(r * (1 - f) + luma * f);
        int fg = static_cast<int>(g * (1 - f) + luma * f);
        int fb = static_cast<int>(b * (1 - f) + luma * f);

        // ...then push slightly warm/yellow, the classic look of aged prints.
        fr = clamp8(static_cast<int>(fr + 15 * f));
        fg = clamp8(static_cast<int>(fg + 8 * f));
        fb = clamp8(static_cast<int>(fb - 15 * f));

        out[i] = packArgb(channel(p, 24), fr, fg, fb);
    }
    return out;
}

}  // namespace novaenhance
