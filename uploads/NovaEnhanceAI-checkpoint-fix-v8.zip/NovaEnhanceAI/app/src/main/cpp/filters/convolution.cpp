#include "convolution.h"

#include <algorithm>
#include <cmath>

namespace novaenhance {

namespace {

inline uint8_t channel(int32_t pixel, int shift) {
    return static_cast<uint8_t>((pixel >> shift) & 0xFF);
}

inline int32_t packArgb(int a, int r, int g, int b) {
    auto clamp8 = [](int v) { return std::min(255, std::max(0, v)); };
    return (clamp8(a) << 24) | (clamp8(r) << 16) | (clamp8(g) << 8) | clamp8(b);
}

inline int clampi(int v, int lo, int hi) { return std::min(hi, std::max(lo, v)); }

// Builds a normalized 1D Gaussian kernel for the given sigma.
std::vector<float> makeGaussianKernel(float sigma, int& radiusOut) {
    int radius = std::max(1, static_cast<int>(std::ceil(sigma * 3.0f)));
    radiusOut = radius;
    std::vector<float> kernel(2 * radius + 1);
    float sum = 0.0f;
    float twoSigmaSq = 2.0f * sigma * sigma;
    for (int i = -radius; i <= radius; ++i) {
        float v = std::exp(-(i * i) / twoSigmaSq);
        kernel[i + radius] = v;
        sum += v;
    }
    for (float& v : kernel) v /= sum;
    return kernel;
}

// Separable convolution pass along one axis (0 = horizontal, 1 = vertical).
std::vector<int32_t> convolve1D(const std::vector<int32_t>& src, int width, int height,
                                 const std::vector<float>& kernel, int radius, int axis) {
    std::vector<int32_t> dst(src.size());
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            float a = 0, r = 0, g = 0, b = 0;
            for (int k = -radius; k <= radius; ++k) {
                int sx = axis == 0 ? clampi(x + k, 0, width - 1) : x;
                int sy = axis == 1 ? clampi(y + k, 0, height - 1) : y;
                int32_t p = src[sy * width + sx];
                float w = kernel[k + radius];
                a += w * channel(p, 24);
                r += w * channel(p, 16);
                g += w * channel(p, 8);
                b += w * channel(p, 0);
            }
            dst[y * width + x] = packArgb(
                static_cast<int>(a), static_cast<int>(r),
                static_cast<int>(g), static_cast<int>(b));
        }
    }
    return dst;
}

}  // namespace

std::vector<int32_t> gaussianBlur(const std::vector<int32_t>& pixels,
                                   int width, int height, float sigma) {
    if (sigma <= 0.0f || pixels.empty()) return pixels;
    int radius;
    auto kernel = makeGaussianKernel(sigma, radius);
    auto horizontal = convolve1D(pixels, width, height, kernel, radius, 0);
    return convolve1D(horizontal, width, height, kernel, radius, 1);
}

std::vector<int32_t> unsharpMask(const std::vector<int32_t>& pixels,
                                  int width, int height,
                                  float sigma, float amount) {
    if (pixels.empty()) return pixels;
    auto blurred = gaussianBlur(pixels, width, height, sigma);
    std::vector<int32_t> out(pixels.size());
    for (size_t i = 0; i < pixels.size(); ++i) {
        int32_t orig = pixels[i];
        int32_t blur = blurred[i];
        int a = channel(orig, 24);
        int r = channel(orig, 16) + static_cast<int>(amount * (channel(orig, 16) - channel(blur, 16)));
        int g = channel(orig, 8) + static_cast<int>(amount * (channel(orig, 8) - channel(blur, 8)));
        int b = channel(orig, 0) + static_cast<int>(amount * (channel(orig, 0) - channel(blur, 0)));
        out[i] = packArgb(a, r, g, b);
    }
    return out;
}

std::vector<int32_t> denoiseBilateral(const std::vector<int32_t>& pixels,
                                       int width, int height,
                                       float spatialSigma, float rangeSigma) {
    if (pixels.empty()) return pixels;
    const int radius = 2;  // 5x5 window keeps this affordable on a 256x256 tile.
    std::vector<int32_t> out(pixels.size());
    float spatialTwoSigmaSq = 2.0f * spatialSigma * spatialSigma;
    float rangeTwoSigmaSq = 2.0f * rangeSigma * rangeSigma;

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int32_t centerPixel = pixels[y * width + x];
            int centerLuma = (channel(centerPixel, 16) * 299 + channel(centerPixel, 8) * 587 +
                               channel(centerPixel, 0) * 114) / 1000;

            float wr = 0, wg = 0, wb = 0, wsum = 0;
            for (int ky = -radius; ky <= radius; ++ky) {
                for (int kx = -radius; kx <= radius; ++kx) {
                    int sx = clampi(x + kx, 0, width - 1);
                    int sy = clampi(y + ky, 0, height - 1);
                    int32_t p = pixels[sy * width + sx];
                    int luma = (channel(p, 16) * 299 + channel(p, 8) * 587 + channel(p, 0) * 114) / 1000;

                    float spatialW = std::exp(-(kx * kx + ky * ky) / spatialTwoSigmaSq);
                    float rangeDiff = static_cast<float>(luma - centerLuma);
                    float rangeW = std::exp(-(rangeDiff * rangeDiff) / rangeTwoSigmaSq);
                    float w = spatialW * rangeW;

                    wr += w * channel(p, 16);
                    wg += w * channel(p, 8);
                    wb += w * channel(p, 0);
                    wsum += w;
                }
            }
            int a = channel(centerPixel, 24);
            out[y * width + x] = packArgb(
                a, static_cast<int>(wr / wsum), static_cast<int>(wg / wsum), static_cast<int>(wb / wsum));
        }
    }
    return out;
}

std::vector<int32_t> resizeBilinear(const std::vector<int32_t>& pixels,
                                     int srcWidth, int srcHeight,
                                     int dstWidth, int dstHeight) {
    std::vector<int32_t> out(static_cast<size_t>(dstWidth) * dstHeight);
    if (pixels.empty() || srcWidth <= 0 || srcHeight <= 0) return out;

    float xRatio = static_cast<float>(srcWidth) / dstWidth;
    float yRatio = static_cast<float>(srcHeight) / dstHeight;

    for (int dy = 0; dy < dstHeight; ++dy) {
        float sy = (dy + 0.5f) * yRatio - 0.5f;
        int y0 = clampi(static_cast<int>(std::floor(sy)), 0, srcHeight - 1);
        int y1 = clampi(y0 + 1, 0, srcHeight - 1);
        float fy = sy - std::floor(sy);

        for (int dx = 0; dx < dstWidth; ++dx) {
            float sx = (dx + 0.5f) * xRatio - 0.5f;
            int x0 = clampi(static_cast<int>(std::floor(sx)), 0, srcWidth - 1);
            int x1 = clampi(x0 + 1, 0, srcWidth - 1);
            float fx = sx - std::floor(sx);

            int32_t p00 = pixels[y0 * srcWidth + x0];
            int32_t p10 = pixels[y0 * srcWidth + x1];
            int32_t p01 = pixels[y1 * srcWidth + x0];
            int32_t p11 = pixels[y1 * srcWidth + x1];

            auto lerpChannel = [&](int shift) {
                float top = channel(p00, shift) * (1 - fx) + channel(p10, shift) * fx;
                float bottom = channel(p01, shift) * (1 - fx) + channel(p11, shift) * fx;
                return top * (1 - fy) + bottom * fy;
            };

            out[dy * dstWidth + dx] = packArgb(
                static_cast<int>(lerpChannel(24)), static_cast<int>(lerpChannel(16)),
                static_cast<int>(lerpChannel(8)), static_cast<int>(lerpChannel(0)));
        }
    }
    return out;
}

float quickSimilarityScore(const std::vector<int32_t>& a,
                            const std::vector<int32_t>& b,
                            int width, int height) {
    if (a.empty() || b.empty() || a.size() != b.size()) return 0.0f;
    double sumAbsDiff = 0.0;
    size_t n = static_cast<size_t>(width) * height;
    for (size_t i = 0; i < n; ++i) {
        int lumaA = (channel(a[i], 16) * 299 + channel(a[i], 8) * 587 + channel(a[i], 0) * 114) / 1000;
        int lumaB = (channel(b[i], 16) * 299 + channel(b[i], 8) * 587 + channel(b[i], 0) * 114) / 1000;
        sumAbsDiff += std::abs(lumaA - lumaB);
    }
    double meanAbsDiff = sumAbsDiff / static_cast<double>(n);
    // Normalize: 0 diff -> score 1.0, 255 diff (max possible) -> score 0.0.
    return static_cast<float>(1.0 - (meanAbsDiff / 255.0));
}

}  // namespace novaenhance
