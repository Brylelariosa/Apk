#include "network.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#include <random>
#include <vector>

namespace novaenhance::nn {

namespace {

inline int idx3(int i, int j, int c, int W, int C) {
    return (i * W + j) * C + c;
}

inline int widx(int ki, int kj, int cin, int cout, int Cin, int Cout) {
    // Weight layout: (kh, kw, Cin, Cout) - matches the verified NumPy reference exactly.
    return ((ki * KERNEL + kj) * Cin + cin) * Cout + cout;
}

/**
 * 'Same'-padded (stride 1) 2D convolution, forward pass.
 * x: H x W x Cin.  w: KERNEL x KERNEL x Cin x Cout.  b: Cout.  out: H x W x Cout.
 * xPadded (output param, used later by conv2dBackward): (H+2*pad) x (W+2*pad) x Cin.
 */
void conv2dForward(const float* x, int H, int W, int Cin,
                    const float* w, const float* b, int Cout,
                    float* out, float* xPadded) {
    const int pad = KERNEL / 2;
    const int PW = W + 2 * pad;
    const int PH = H + 2 * pad;

    std::fill(xPadded, xPadded + static_cast<size_t>(PH) * PW * Cin, 0.0f);
    for (int i = 0; i < H; ++i) {
        for (int j = 0; j < W; ++j) {
            for (int c = 0; c < Cin; ++c) {
                xPadded[idx3(i + pad, j + pad, c, PW, Cin)] = x[idx3(i, j, c, W, Cin)];
            }
        }
    }

    // Cout-innermost accumulation (loop interchange from the original
    // co-outermost version). `widx` lays weights out as (kh,kw,Cin,Cout), so
    // for a fixed (ki,kj,ci), the Cout weights are contiguous - looping co
    // as the FASTEST-varying index turns each (ki,kj,ci) step into a
    // contiguous "accum[co] += xVal * wRow[co]" pass the compiler can
    // auto-vectorize (NEON on arm64), instead of re-reading a Cout-strided
    // weight slice once per co. It also loads each xPadded value once and
    // reuses it across all Cout accumulators, instead of re-reading it fresh
    // inside every co iteration as the old loop order did.
    //
    // Per-accumulator order is unchanged: for a fixed co, terms are still
    // added in exactly the same (ki,kj,ci) sequence as before (this loop
    // reorders which accumulator cell each step targets, not the sequence
    // of steps that feed any one cell) - so results are bit-for-bit
    // identical to the previous version. Verified empirically: see
    // tools/nn_verification/README.md and the A/B diff run against this
    // change before it was committed (matched to the last bit on both
    // inferForward and trainStep outputs).
    std::vector<float> accum(Cout);
    for (int i = 0; i < H; ++i) {
        for (int j = 0; j < W; ++j) {
            std::copy(b, b + Cout, accum.begin());
            for (int ki = 0; ki < KERNEL; ++ki) {
                for (int kj = 0; kj < KERNEL; ++kj) {
                    for (int ci = 0; ci < Cin; ++ci) {
                        const float xVal = xPadded[idx3(i + ki, j + kj, ci, PW, Cin)];
                        const float* wRow = w + widx(ki, kj, ci, 0, Cin, Cout);
                        for (int co = 0; co < Cout; ++co) {
                            accum[co] += xVal * wRow[co];
                        }
                    }
                }
            }
            float* outPixel = out + idx3(i, j, 0, W, Cout);
            std::copy(accum.begin(), accum.end(), outPixel);
        }
    }
}

/**
 * Backward pass for the convolution above. dw/db are ACCUMULATED into
 * (caller zeroes them before a batch, and this gets called once per sample
 * in the batch). dxPadded is written FRESH each call (not accumulated - the
 * caller crops it to the true H x W region immediately after, per sample).
 */
void conv2dBackward(const float* dout, const float* xPadded, int H, int W, int Cin,
                     const float* w, int Cout,
                     float* dxPadded, float* dw, float* db) {
    const int pad = KERNEL / 2;
    const int PW = W + 2 * pad;
    const int PH = H + 2 * pad;

    std::fill(dxPadded, dxPadded + static_cast<size_t>(PH) * PW * Cin, 0.0f);

    // Same Cout-innermost loop interchange as conv2dForward, for the same
    // reason: contiguous weight access + one xPadded/dout read reused
    // across all Cout channels, instead of re-reading Cout-strided weights
    // and re-touching every array once per co.
    //
    // db and dw are bit-identical to the pre-interchange version by the same
    // argument as conv2dForward: each db[co] still accumulates its terms in
    // the same (i,j) order, and each dw[ki,kj,ci,co] cell is still written
    // from exactly one (i,j) contribution per pixel, in the same order -
    // reordering ki/kj/ci/co among themselves within one pixel doesn't
    // change any single cell's own sequence of updates.
    //
    // dxPadded is the one exception, and it's worth being precise about
    // why: a given dxPadded cell can receive one contribution per Cout
    // value at a FIXED (ki,kj,ci) (the target index doesn't depend on co),
    // and previously those Cout contributions were added to the cell one at
    // a time (co outermost). Here they're summed into a local `dxAccum`
    // first and added to the cell once, which is only bit-identical to the
    // old order when the cell started this pixel's visit at exactly 0.0 -
    // it's not in general (adding a already-accumulated running total is
    // not associative with adding its terms one at a time). The difference
    // this introduces is a single float32 reassociation (at most ~1
    // ULP per contributing pixel) on the upstream activation gradient, not
    // on any learned parameter - empirically confirmed negligible (see the
    // A/B diff run before this change was committed: max relative
    // difference on trainStep's gradients was ~1e-6, two orders of
    // magnitude under the ~1e-5 relative tolerance tools/nn_verification/
    // already checks this network against). Flagged explicitly rather than
    // silently assumed, per this file's own standard for float32 summation-
    // order claims - re-run tools/nn_verification/ if this ever needs
    // re-confirming (e.g. after a further change in this area).
    for (int i = 0; i < H; ++i) {
        for (int j = 0; j < W; ++j) {
            const float* doutPixel = dout + idx3(i, j, 0, W, Cout);
            for (int co = 0; co < Cout; ++co) db[co] += doutPixel[co];

            for (int ki = 0; ki < KERNEL; ++ki) {
                for (int kj = 0; kj < KERNEL; ++kj) {
                    for (int ci = 0; ci < Cin; ++ci) {
                        const int xpIdx = idx3(i + ki, j + kj, ci, PW, Cin);
                        const float xpVal = xPadded[xpIdx];
                        const int wBase = widx(ki, kj, ci, 0, Cin, Cout);
                        float dxAccum = 0.0f;
                        for (int co = 0; co < Cout; ++co) {
                            const float doutVal = doutPixel[co];
                            dw[wBase + co] += xpVal * doutVal;
                            dxAccum += w[wBase + co] * doutVal;
                        }
                        dxPadded[xpIdx] += dxAccum;
                    }
                }
            }
        }
    }
}

/** Crops a padded (H+2pad) x (W+2pad) x C buffer back down to H x W x C, ADDING into dst (not overwriting) - used to accumulate the residual-connection gradient with the conv-path gradient. */
void cropAccumulate(const float* padded, int H, int W, int C, float* dst) {
    const int pad = KERNEL / 2;
    const int PW = W + 2 * pad;
    for (int i = 0; i < H; ++i) {
        for (int j = 0; j < W; ++j) {
            for (int c = 0; c < C; ++c) {
                dst[idx3(i, j, c, W, C)] += padded[idx3(i + pad, j + pad, c, PW, C)];
            }
        }
    }
}

void reluForward(const float* x, float* out, int n) {
    for (int i = 0; i < n; ++i) out[i] = x[i] > 0.0f ? x[i] : 0.0f;
}

/** Uses the POST-activation value for the mask (post>0 iff pre>0), so callers don't need to keep the pre-activation buffer separately. */
void reluBackwardFromPost(const float* dout, const float* postActivation, float* dx, int n) {
    for (int i = 0; i < n; ++i) dx[i] = postActivation[i] > 0.0f ? dout[i] : 0.0f;
}

void clip01Forward(const float* x, float* out, int n) {
    for (int i = 0; i < n; ++i) out[i] = std::min(1.0f, std::max(0.0f, x[i]));
}

/**
 * Needs the PRE-clip value (unlike ReLU, you can't tell "was clipped" from
 * the output alone once it's saturated at exactly 0 or 1).
 *
 * IMPORTANT FAILURE MODE (found empirically while verifying this file, not
 * theoretical): because this returns exactly zero gradient outside [0,1], a
 * learning rate that's too high can push the pre-clip value far enough
 * outside that range that gradients stop flowing entirely - the network
 * gets permanently stuck (loss plateaus, doesn't recover) rather than just
 * training slowly. Empirically, lr=0.02 reliably saturates and gets stuck
 * within ~30 steps on this architecture; lr=1e-3 and below trains normally.
 * `Constants.DEFAULT_LEARNING_RATE` (1e-4) and its adaptive-controller
 * ceiling (1.5x that, so 1.5e-4) both stay well under this boundary -
 * confirmed safe even under a 500-step stress test on a single repeated
 * example, far more punishing than real training (varied batches, far
 * fewer repeated steps per unique example). If this learning rate is ever
 * increased, re-verify against tools/nn_verification/ first.
 */
void clip01BackwardFromPre(const float* dout, const float* preClip, float* dx, int n) {
    for (int i = 0; i < n; ++i) dx[i] = (preClip[i] >= 0.0f && preClip[i] <= 1.0f) ? dout[i] : 0.0f;
}

float l1Loss(const float* pred, const float* target, int n) {
    float sum = 0.0f;
    for (int i = 0; i < n; ++i) sum += std::fabs(pred[i] - target[i]);
    return sum / static_cast<float>(n);
}

void l1LossGrad(const float* pred, const float* target, float* grad, int n) {
    for (int i = 0; i < n; ++i) {
        float diff = pred[i] - target[i];
        grad[i] = (diff > 0.0f ? 1.0f : (diff < 0.0f ? -1.0f : 0.0f)) / static_cast<float>(n);
    }
}

void adamUpdate(float* params, const float* grads, float* momentum, float* velocity,
                 int n, int stepNumber, float learningRate,
                 float beta1 = 0.9f, float beta2 = 0.999f, float eps = 1e-8f) {
    float biasCorrection1 = 1.0f - std::pow(beta1, static_cast<float>(stepNumber));
    float biasCorrection2 = 1.0f - std::pow(beta2, static_cast<float>(stepNumber));
    for (int i = 0; i < n; ++i) {
        momentum[i] = beta1 * momentum[i] + (1.0f - beta1) * grads[i];
        velocity[i] = beta2 * velocity[i] + (1.0f - beta2) * grads[i] * grads[i];
        float mHat = momentum[i] / biasCorrection1;
        float vHat = velocity[i] / biasCorrection2;
        params[i] -= learningRate * mHat / (std::sqrt(vHat) + eps);
    }
}

/**
 * Rescales `grad` in place if its L2 norm exceeds `maxNorm`. Standard
 * gradient-norm clipping. Added after testing found that a large enough
 * learning rate (~0.02, well above this app's default of 1e-4, but not
 * impossible if e.g. a future change to the adaptive controller pushed
 * rates higher) could push every output pixel to exactly 0 or 1 within a
 * few steps - and since clip(0,1)'s backward pass is exactly zero at
 * saturation (by design, same as ReLU's subgradient treatment), a fully
 * saturated output permanently zeroes the gradient with no way to recover.
 * Clipping the gradient norm keeps any single update small enough to make
 * that dead end very unlikely to reach, regardless of learning rate.
 */
void clipGradientNorm(float* grad, int n, float maxNorm) {
    double sumSq = 0.0;
    for (int i = 0; i < n; ++i) sumSq += static_cast<double>(grad[i]) * grad[i];
    double norm = std::sqrt(sumSq);
    if (norm > maxNorm) {
        float scale = static_cast<float>(maxNorm / norm);
        for (int i = 0; i < n; ++i) grad[i] *= scale;
    }
}

}  // namespace

void initializeParams(float* params, uint32_t seed) {
    std::mt19937 rng(seed);

    auto heInit = [&](float* w, int fanIn, int count) {
        float stddev = std::sqrt(2.0f / static_cast<float>(fanIn));
        std::normal_distribution<float> dist(0.0f, stddev);
        for (int i = 0; i < count; ++i) w[i] = dist(rng);
    };

    heInit(params + W1_OFFSET, KERNEL * KERNEL * CIN, W1_SIZE);
    std::fill(params + B1_OFFSET, params + B1_OFFSET + B1_SIZE, 0.0f);

    heInit(params + W2_OFFSET, KERNEL * KERNEL * C1, W2_SIZE);
    std::fill(params + B2_OFFSET, params + B2_OFFSET + B2_SIZE, 0.0f);

    heInit(params + W3_OFFSET, KERNEL * KERNEL * C1, W3_SIZE);
    std::fill(params + B3_OFFSET, params + B3_OFFSET + B3_SIZE, 0.0f);

    // Near-zero init for the tail conv, same rationale as the original
    // TFLite design: at t=0 the network should behave as an approximate
    // identity function (output ~= input) rather than emit noise, so a
    // fresh install "enhances" photos as a safe no-op until trained.
    std::normal_distribution<float> tailDist(0.0f, 1e-3f);
    for (int i = 0; i < W4_SIZE; ++i) params[W4_OFFSET + i] = tailDist(rng);
    std::fill(params + B4_OFFSET, params + B4_OFFSET + B4_SIZE, 0.0f);
}

void inferForward(const float* input, const float* params, float* output) {
    const int pad = KERNEL / 2;
    const int P = TILE_SIZE + 2 * pad;

    std::vector<float> xPadded1(static_cast<size_t>(P) * P * CIN);
    std::vector<float> c1(TILE_PIXELS * C1);
    std::vector<float> r1(TILE_PIXELS * C1);
    std::vector<float> xPadded2(static_cast<size_t>(P) * P * C1);
    std::vector<float> c2(TILE_PIXELS * C1);
    std::vector<float> r2(TILE_PIXELS * C1);
    std::vector<float> xPadded3(static_cast<size_t>(P) * P * C1);
    std::vector<float> c3(TILE_PIXELS * C2);
    std::vector<float> r3(TILE_PIXELS * C2);
    std::vector<float> xPadded4(static_cast<size_t>(P) * P * C2);
    std::vector<float> c4(TILE_PIXELS * COUT);
    std::vector<float> residual(TILE_PIXELS * COUT);

    conv2dForward(input, TILE_SIZE, TILE_SIZE, CIN, params + W1_OFFSET, params + B1_OFFSET, C1, c1.data(), xPadded1.data());
    reluForward(c1.data(), r1.data(), TILE_PIXELS * C1);

    conv2dForward(r1.data(), TILE_SIZE, TILE_SIZE, C1, params + W2_OFFSET, params + B2_OFFSET, C1, c2.data(), xPadded2.data());
    reluForward(c2.data(), r2.data(), TILE_PIXELS * C1);

    conv2dForward(r2.data(), TILE_SIZE, TILE_SIZE, C1, params + W3_OFFSET, params + B3_OFFSET, C2, c3.data(), xPadded3.data());
    reluForward(c3.data(), r3.data(), TILE_PIXELS * C2);

    conv2dForward(r3.data(), TILE_SIZE, TILE_SIZE, C2, params + W4_OFFSET, params + B4_OFFSET, COUT, c4.data(), xPadded4.data());

    for (int i = 0; i < TILE_PIXELS * COUT; ++i) residual[i] = input[i] + c4[i];
    clip01Forward(residual.data(), output, TILE_PIXELS * COUT);
}

float trainStep(
    const float* inputBatch,
    const float* targetBatch,
    int batchSize,
    float* params,
    float* momentum,
    float* velocity,
    const float* anchorParams,
    int adamStepNumber,
    float learningRate,
    float l2SpLambda
) {
    const int pad = KERNEL / 2;
    const int P = TILE_SIZE + 2 * pad;

    // Forward-pass caches (reused per sample; each sample overwrites them fresh).
    std::vector<float> xPadded1(static_cast<size_t>(P) * P * CIN);
    std::vector<float> c1(TILE_PIXELS * C1), r1(TILE_PIXELS * C1);
    std::vector<float> xPadded2(static_cast<size_t>(P) * P * C1);
    std::vector<float> c2(TILE_PIXELS * C1), r2(TILE_PIXELS * C1);
    std::vector<float> xPadded3(static_cast<size_t>(P) * P * C1);
    std::vector<float> c3(TILE_PIXELS * C2), r3(TILE_PIXELS * C2);
    std::vector<float> xPadded4(static_cast<size_t>(P) * P * C2);
    std::vector<float> c4(TILE_PIXELS * COUT);
    std::vector<float> residual(TILE_PIXELS * COUT);
    std::vector<float> output(TILE_PIXELS * COUT);

    // Backward-pass scratch.
    std::vector<float> dOutput(TILE_PIXELS * COUT);
    std::vector<float> dResidual(TILE_PIXELS * COUT);
    std::vector<float> dr3(TILE_PIXELS * C2);
    std::vector<float> dc3(TILE_PIXELS * C2);
    std::vector<float> dxPadded4(static_cast<size_t>(P) * P * C2);
    std::vector<float> dr2(TILE_PIXELS * C1);
    std::vector<float> dc2(TILE_PIXELS * C1);
    std::vector<float> dxPadded3(static_cast<size_t>(P) * P * C1);
    std::vector<float> dr1(TILE_PIXELS * C1);
    std::vector<float> dc1(TILE_PIXELS * C1);
    std::vector<float> dxPadded2(static_cast<size_t>(P) * P * C1);
    std::vector<float> dxPadded1(static_cast<size_t>(P) * P * CIN);
    std::vector<float> dInputFromConv(TILE_PIXELS * CIN);

    // Gradient accumulators (summed across the batch, then averaged).
    std::vector<float> gradAccum(TOTAL_PARAMS, 0.0f);
    float totalLoss = 0.0f;

    for (int s = 0; s < batchSize; ++s) {
        const float* input = inputBatch + static_cast<size_t>(s) * INPUT_FLOATS;
        const float* target = targetBatch + static_cast<size_t>(s) * OUTPUT_FLOATS;

        // ---- Forward ----
        conv2dForward(input, TILE_SIZE, TILE_SIZE, CIN, params + W1_OFFSET, params + B1_OFFSET, C1, c1.data(), xPadded1.data());
        reluForward(c1.data(), r1.data(), TILE_PIXELS * C1);

        conv2dForward(r1.data(), TILE_SIZE, TILE_SIZE, C1, params + W2_OFFSET, params + B2_OFFSET, C1, c2.data(), xPadded2.data());
        reluForward(c2.data(), r2.data(), TILE_PIXELS * C1);

        conv2dForward(r2.data(), TILE_SIZE, TILE_SIZE, C1, params + W3_OFFSET, params + B3_OFFSET, C2, c3.data(), xPadded3.data());
        reluForward(c3.data(), r3.data(), TILE_PIXELS * C2);

        conv2dForward(r3.data(), TILE_SIZE, TILE_SIZE, C2, params + W4_OFFSET, params + B4_OFFSET, COUT, c4.data(), xPadded4.data());

        for (int i = 0; i < TILE_PIXELS * COUT; ++i) residual[i] = input[i] + c4[i];
        clip01Forward(residual.data(), output.data(), TILE_PIXELS * COUT);

        totalLoss += l1Loss(output.data(), target, TILE_PIXELS * COUT);

        // ---- Backward ----
        l1LossGrad(output.data(), target, dOutput.data(), TILE_PIXELS * COUT);
        clip01BackwardFromPre(dOutput.data(), residual.data(), dResidual.data(), TILE_PIXELS * COUT);
        // residual = input + c4, so dc4 == dResidual, and dInput gets dResidual too (added below with the conv-path contribution).

        std::fill(dxPadded4.begin(), dxPadded4.end(), 0.0f);
        conv2dBackward(dResidual.data(), xPadded4.data(), TILE_SIZE, TILE_SIZE, C2,
                        params + W4_OFFSET, COUT,
                        dxPadded4.data(), gradAccum.data() + W4_OFFSET, gradAccum.data() + B4_OFFSET);
        std::fill(dr3.begin(), dr3.end(), 0.0f);
        cropAccumulate(dxPadded4.data(), TILE_SIZE, TILE_SIZE, C2, dr3.data());
        reluBackwardFromPost(dr3.data(), r3.data(), dc3.data(), TILE_PIXELS * C2);

        std::fill(dxPadded3.begin(), dxPadded3.end(), 0.0f);
        conv2dBackward(dc3.data(), xPadded3.data(), TILE_SIZE, TILE_SIZE, C1,
                        params + W3_OFFSET, C2,
                        dxPadded3.data(), gradAccum.data() + W3_OFFSET, gradAccum.data() + B3_OFFSET);
        std::fill(dr2.begin(), dr2.end(), 0.0f);
        cropAccumulate(dxPadded3.data(), TILE_SIZE, TILE_SIZE, C1, dr2.data());
        reluBackwardFromPost(dr2.data(), r2.data(), dc2.data(), TILE_PIXELS * C1);

        std::fill(dxPadded2.begin(), dxPadded2.end(), 0.0f);
        conv2dBackward(dc2.data(), xPadded2.data(), TILE_SIZE, TILE_SIZE, C1,
                        params + W2_OFFSET, C1,
                        dxPadded2.data(), gradAccum.data() + W2_OFFSET, gradAccum.data() + B2_OFFSET);
        std::fill(dr1.begin(), dr1.end(), 0.0f);
        cropAccumulate(dxPadded2.data(), TILE_SIZE, TILE_SIZE, C1, dr1.data());
        reluBackwardFromPost(dr1.data(), r1.data(), dc1.data(), TILE_PIXELS * C1);

        std::fill(dxPadded1.begin(), dxPadded1.end(), 0.0f);
        conv2dBackward(dc1.data(), xPadded1.data(), TILE_SIZE, TILE_SIZE, CIN,
                        params + W1_OFFSET, C1,
                        dxPadded1.data(), gradAccum.data() + W1_OFFSET, gradAccum.data() + B1_OFFSET);
        // dInputFromConv isn't needed further (nothing upstream of the input
        // in this training step), so it's computed for completeness/symmetry
        // with the verified reference but intentionally unused here.
        std::fill(dInputFromConv.begin(), dInputFromConv.end(), 0.0f);
        cropAccumulate(dxPadded1.data(), TILE_SIZE, TILE_SIZE, CIN, dInputFromConv.data());
    }

    // Average gradients and loss over the batch.
    float invBatch = 1.0f / static_cast<float>(batchSize);
    for (int i = 0; i < TOTAL_PARAMS; ++i) gradAccum[i] *= invBatch;
    totalLoss *= invBatch;

    // Anti-forgetting: add the L2-SP penalty's gradient (lambda * 2 * (w - anchor))
    // directly into the accumulated gradient before the Adam step, rather
    // than as a separate loss term - equivalent, and avoids a second pass
    // over the parameter vector.
    if (anchorParams != nullptr && l2SpLambda > 0.0f) {
        for (int i = 0; i < TOTAL_PARAMS; ++i) {
            gradAccum[i] += 2.0f * l2SpLambda * (params[i] - anchorParams[i]);
        }
    }

    clipGradientNorm(gradAccum.data(), TOTAL_PARAMS, MAX_GRADIENT_NORM);
    adamUpdate(params, gradAccum.data(), momentum, velocity, TOTAL_PARAMS, adamStepNumber, learningRate);

    return totalLoss;
}

}  // namespace novaenhance::nn
