package com.novaenhance.ai.ai.engine

/**
 * The five sliders on the Enhance Image screen. All values are 0f..1f
 * except [upscaleFactor], which is a discrete multiplier.
 */
data class EnhancementOptions(
    /** Blend between the original pixel (0) and the AI model's output (1) for this tile. */
    val strength: Float = 1.0f,
    /** Additional classical unsharp-mask amount applied on top of the AI result. */
    val sharpness: Float = 0.3f,
    /** Additional classical bilateral-denoise amount applied on top of the AI result. */
    val noiseReduction: Float = 0.3f,
    /** Saturation/vibrance boost applied on top of the AI result. */
    val colorRestoration: Float = 0.2f,
    /** 1x (no resize), 2x, or 4x classical upscale applied after AI enhancement. */
    val upscaleFactor: Int = 1
) {
    init {
        require(strength in 0f..1f) { "strength must be in 0f..1f" }
        require(sharpness in 0f..1f) { "sharpness must be in 0f..1f" }
        require(noiseReduction in 0f..1f) { "noiseReduction must be in 0f..1f" }
        require(colorRestoration in 0f..1f) { "colorRestoration must be in 0f..1f" }
        require(upscaleFactor in setOf(1, 2, 4)) { "upscaleFactor must be 1, 2, or 4" }
    }
}
