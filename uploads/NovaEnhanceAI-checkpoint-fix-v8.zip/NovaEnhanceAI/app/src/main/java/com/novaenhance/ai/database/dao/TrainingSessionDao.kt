package com.novaenhance.ai.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface TrainingSessionDao {

    @Query("SELECT * FROM training_sessions WHERE modelId = :modelId ORDER BY startedAt DESC")
    fun observeForModel(modelId: String): Flow<List<TrainingSessionEntity>>

    @Query("SELECT * FROM training_sessions WHERE id = :sessionId")
    suspend fun getById(sessionId: Long): TrainingSessionEntity?

    @Query("SELECT * FROM training_sessions WHERE id = :sessionId")
    fun observeById(sessionId: Long): Flow<TrainingSessionEntity?>

    /** Crash recovery: find an interrupted session (process died while status was RUNNING). */
    @Query("SELECT * FROM training_sessions WHERE status = :status ORDER BY startedAt DESC LIMIT 1")
    suspend fun findLatestWithStatus(status: TrainingStatus = TrainingStatus.RUNNING): TrainingSessionEntity?

    @Query(
        """SELECT * FROM training_sessions WHERE modelId = :modelId
           AND status = 'COMPLETED' ORDER BY startedAt DESC LIMIT :limit"""
    )
    suspend fun getRecentCompleted(modelId: String, limit: Int): List<TrainingSessionEntity>

    @Insert
    suspend fun insert(session: TrainingSessionEntity): Long

    @Update
    suspend fun update(session: TrainingSessionEntity)
}
