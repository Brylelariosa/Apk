package com.novaenhance.ai.ai.engine

import kotlin.math.min

/**
 * Small shared helpers for working with fixed-size ARGB tile buffers.
 * Pulled out of [TileProcessor] so [com.novaenhance.ai.training.trainer.ModelTrainer]'s
 * random-patch extraction for training batches doesn't have to duplicate
 * the same pad/crop logic.
 */
object PixelBufferOps {

    /** Pads a `srcW x srcH` tile up to `targetSize x targetSize` by replicating edge pixels. */
    fun padByReplication(pixels: IntArray, srcW: Int, srcH: Int, targetSize: Int): IntArray {
        if (srcW == targetSize && srcH == targetSize) return pixels
        val out = IntArray(targetSize * targetSize)
        for (y in 0 until targetSize) {
            val sy = min(y, srcH - 1)
            for (x in 0 until targetSize) {
                val sx = min(x, srcW - 1)
                out[y * targetSize + x] = pixels[sy * srcW + sx]
            }
        }
        return out
    }

    /** Crops the top-left `w x h` region out of a `srcSize x srcSize` tile. */
    fun cropTopLeft(pixels: IntArray, srcSize: Int, w: Int, h: Int): IntArray {
        if (w == srcSize && h == srcSize) return pixels
        val out = IntArray(w * h)
        for (y in 0 until h) {
            System.arraycopy(pixels, y * srcSize, out, y * w, w)
        }
        return out
    }
}
