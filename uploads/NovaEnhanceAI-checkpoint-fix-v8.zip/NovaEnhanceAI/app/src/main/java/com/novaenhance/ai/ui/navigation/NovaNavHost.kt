package com.novaenhance.ai.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.novaenhance.ai.ui.screens.DashboardScreen
import com.novaenhance.ai.ui.screens.DatasetManagerScreen
import com.novaenhance.ai.ui.screens.EnhanceScreen
import com.novaenhance.ai.ui.screens.ModelManagerScreen
import com.novaenhance.ai.ui.screens.SettingsScreen
import com.novaenhance.ai.ui.screens.TrainingScreen

@Composable
fun NovaNavHost() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = NovaDestination.Dashboard.route) {
        composable(NovaDestination.Dashboard.route) {
            DashboardScreen(
                onNavigateToEnhance = { navController.navigate(NovaDestination.Enhance.route) },
                onNavigateToTraining = { navController.navigate(NovaDestination.Training.route) },
                onNavigateToDataset = { navController.navigate(NovaDestination.DatasetManager.route) },
                onNavigateToModelManager = { navController.navigate(NovaDestination.ModelManager.route) },
                onNavigateToSettings = { navController.navigate(NovaDestination.Settings.route) }
            )
        }
        composable(NovaDestination.Enhance.route) { EnhanceScreen(onBack = { navController.popBackStack() }) }
        composable(NovaDestination.Training.route) { TrainingScreen(onBack = { navController.popBackStack() }) }
        composable(NovaDestination.DatasetManager.route) { DatasetManagerScreen(onBack = { navController.popBackStack() }) }
        composable(NovaDestination.ModelManager.route) { ModelManagerScreen(onBack = { navController.popBackStack() }) }
        composable(NovaDestination.Settings.route) { SettingsScreen(onBack = { navController.popBackStack() }) }
    }
}
