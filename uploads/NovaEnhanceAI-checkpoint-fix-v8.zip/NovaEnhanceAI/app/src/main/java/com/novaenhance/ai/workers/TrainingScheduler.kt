package com.novaenhance.ai.workers

import android.content.Context
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.novaenhance.ai.utils.Constants

/**
 * Entry point the Train AI screen calls to start (or resume) a session.
 * Whether this goes through WorkManager's constraint system or starts the
 * foreground service immediately depends on the user's Settings choice.
 *
 * `NetworkType.NOT_REQUIRED` is set explicitly (rather than left default)
 * as a small, deliberate signal in the code that this app never needs
 * network connectivity to train - it's not just absent, it's asserted.
 */
object TrainingScheduler {

    fun start(context: Context, modelId: String, resumeSessionId: Long? = null, requireCharging: Boolean) {
        if (!requireCharging) {
            TrainingForegroundService.start(context, modelId, resumeSessionId)
            return
        }

        val constraints = Constraints.Builder()
            .setRequiresCharging(true)
            .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
            .build()

        val inputData = Data.Builder()
            .putString(KEY_MODEL_ID, modelId)
            .apply { resumeSessionId?.let { putLong(KEY_RESUME_SESSION_ID, it) } }
            .build()

        val request = OneTimeWorkRequestBuilder<TrainingWorker>()
            .setConstraints(constraints)
            .setInputData(inputData)
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(
            Constants.WORK_NAME_TRAINING,
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    fun cancelScheduled(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(Constants.WORK_NAME_TRAINING)
    }
}
