package com.novaenhance.ai.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.dao.LossHistoryDao
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.dao.ReplayBufferDao
import com.novaenhance.ai.database.dao.TrainingSessionDao
import com.novaenhance.ai.database.dao.ValidationMetricDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.LossHistoryEntity
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import com.novaenhance.ai.database.entities.ReplayBufferEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.ValidationMetricEntity

@Database(
    entities = [
        ModelEntity::class,
        ModelVersionEntity::class,
        DatasetPairEntity::class,
        TrainingSessionEntity::class,
        LossHistoryEntity::class,
        ValidationMetricEntity::class,
        ReplayBufferEntity::class
    ],
    version = 2,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun modelDao(): ModelDao
    abstract fun modelVersionDao(): ModelVersionDao
    abstract fun datasetPairDao(): DatasetPairDao
    abstract fun trainingSessionDao(): TrainingSessionDao
    abstract fun lossHistoryDao(): LossHistoryDao
    abstract fun validationMetricDao(): ValidationMetricDao
    abstract fun replayBufferDao(): ReplayBufferDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "novaenhance.db"
                )
                    // Version bumped to 2 alongside ModelVersionEntity's schema
                    // change (architecturePath/checkpointPathPrefix -> a single
                    // weightsFilePath, when the on-device training engine was
                    // switched from TFLite to the from-scratch native CNN).
                    //
                    // fallbackToDestructiveMigration() is a deliberate, temporary
                    // choice for this stage of development, not an oversight:
                    // this app has no real released users yet, so there is
                    // nothing to lose by recreating the database on a schema
                    // change, and the alternative - a real Migration - would be
                    // migrating data OUT of a TFLite-era schema that no longer
                    // corresponds to anything the app can use anyway (the
                    // weights files themselves are gone; there's no meaningful
                    // migration path for old NovaModelEngine checkpoints written
                    // in the old format). Replace this with real Migration
                    // objects once this ships to real users whose data matters.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
