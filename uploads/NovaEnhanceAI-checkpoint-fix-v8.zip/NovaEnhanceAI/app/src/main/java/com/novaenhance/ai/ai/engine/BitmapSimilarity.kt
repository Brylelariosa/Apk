package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap

/**
 * Downsamples two bitmaps to a common small size and returns a fast [0,1]
 * similarity score via the native quick-similarity filter. Shared by
 * [com.novaenhance.ai.training.dataset.DatasetAnalyzer] (invalid-pair
 * detection) and [com.novaenhance.ai.training.trainer.SelfImprovementOrchestrator]
 * (weak-area rescoring) so both use exactly the same notion of "how similar
 * are these two images" rather than two subtly different implementations
 * drifting apart over time.
 */
object BitmapSimilarity {

    fun quickSimilarity(a: Bitmap, b: Bitmap, size: Int = 64): Float {
        val scaledA = Bitmap.createScaledBitmap(a, size, size, true)
        val scaledB = Bitmap.createScaledBitmap(b, size, size, true)
        try {
            val pixelsA = IntArray(size * size)
            val pixelsB = IntArray(size * size)
            scaledA.getPixels(pixelsA, 0, size, 0, 0, size, size)
            scaledB.getPixels(pixelsB, 0, size, 0, 0, size, size)
            return NativeImageProcessor.quickSimilarityScore(pixelsA, pixelsB, size, size)
        } finally {
            if (scaledA != a) scaledA.recycle()
            if (scaledB != b) scaledB.recycle()
        }
    }
}
