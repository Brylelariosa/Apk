package com.novaenhance.ai.ai.engine

/**
 * Bridges [TileProcessor]'s ARGB_8888 IntArray tiles and the normalized
 * (0-1) float32 HWC arrays [NativeNeuralEngine] expects. Plain [FloatArray]
 * rather than a [java.nio.ByteBuffer] - unlike the old TFLite-based engine,
 * there's no tensor-format contract to satisfy here, just whatever shape
 * the JNI bridge declares, so the simplest representation wins.
 */
object TensorImageCodec {

    /** Encodes a single ARGB tile as `size*size*3` floats in `[0,1]`, HWC order. */
    fun encodeSingle(pixels: IntArray, size: Int): FloatArray {
        val out = FloatArray(size * size * 3)
        writeTile(pixels, out, 0)
        return out
    }

    /** Encodes a batch of same-size ARGB tiles as `batch*size*size*3` floats, tiles concatenated in order. */
    fun encodeBatch(tiles: List<IntArray>, size: Int): FloatArray {
        val perTile = size * size * 3
        val out = FloatArray(perTile * tiles.size)
        for ((i, tile) in tiles.withIndex()) {
            writeTile(tile, out, i * perTile)
        }
        return out
    }

    /** Decodes `size*size*3` floats (the model's raw output) back to ARGB pixels. */
    fun decodeSingle(floats: FloatArray, size: Int): IntArray {
        val pixels = IntArray(size * size)
        for (i in pixels.indices) {
            // Round rather than truncate: an arbitrary model output like
            // 0.4999997 truncating to 127 instead of rounding to 128 would
            // introduce a small systematic darkening bias across every
            // pixel, every tile.
            val r = kotlin.math.round(floats[i * 3].coerceIn(0f, 1f) * 255f).toInt()
            val g = kotlin.math.round(floats[i * 3 + 1].coerceIn(0f, 1f) * 255f).toInt()
            val b = kotlin.math.round(floats[i * 3 + 2].coerceIn(0f, 1f) * 255f).toInt()
            pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        return pixels
    }

    private fun writeTile(pixels: IntArray, out: FloatArray, offset: Int) {
        for ((i, pixel) in pixels.withIndex()) {
            val base = offset + i * 3
            out[base] = ((pixel shr 16) and 0xFF) / 255f
            out[base + 1] = ((pixel shr 8) and 0xFF) / 255f
            out[base + 2] = (pixel and 0xFF) / 255f
        }
    }
}
