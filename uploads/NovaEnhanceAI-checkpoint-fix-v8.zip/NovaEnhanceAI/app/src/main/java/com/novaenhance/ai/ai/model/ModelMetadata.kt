package com.novaenhance.ai.ai.model

import com.novaenhance.ai.ai.engine.NativeNeuralEngine
import org.json.JSONObject
import java.io.File

/**
 * Descriptive metadata carried alongside a `.novamodel` bundle (see
 * [com.novaenhance.ai.training.checkpoint.CheckpointManager]) so an
 * exported/imported model is self-describing independent of this
 * install's database. Much simpler than the old TFLite-era version: there's
 * no signature list or configurable tile/channel size to record, since the
 * network architecture is fixed at compile time (`nn/network.h`) - the only
 * things worth recording are display info and the version this bundle
 * represents.
 */
data class ModelMetadata(
    val modelName: String,
    val parameterCount: Int,
    val versionNumber: Int
) {
    companion object {
        fun fromFile(jsonFile: File): ModelMetadata {
            val json = JSONObject(jsonFile.readText())
            return ModelMetadata(
                modelName = json.getString("modelName"),
                parameterCount = json.optInt("parameterCount", NativeNeuralEngine.TOTAL_PARAMS),
                versionNumber = json.getInt("versionNumber")
            )
        }

        /** Sidecar path convention: `foo.weights` <-> `foo.json`. */
        fun sidecarFor(weightsFile: File): File =
            File(weightsFile.parentFile, weightsFile.nameWithoutExtension + ".json")
    }

    fun toJson(): String {
        val json = JSONObject()
        json.put("modelName", modelName)
        json.put("parameterCount", parameterCount)
        json.put("versionNumber", versionNumber)
        return json.toString(2)
    }
}
