package com.novaenhance.ai.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A single low-quality/high-quality training pair. Populated either by the
 * user manually selecting both images, or automatically by
 * [com.novaenhance.ai.training.dataset.DegradationGenerator] from a single
 * high-quality source image.
 *
 * The quality/difficulty/duplicate fields are filled in by
 * [com.novaenhance.ai.training.dataset.DatasetAnalyzer] as part of "Smart
 * Dataset Analysis" before training is allowed to start.
 */
@Entity(
    tableName = "dataset_pairs",
    foreignKeys = [
        ForeignKey(
            entity = ModelEntity::class,
            parentColumns = ["id"],
            childColumns = ["modelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("modelId"), Index("perceptualHashLow")]
)
data class DatasetPairEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val modelId: String,
    val lowQualityPath: String,
    val highQualityPath: String,
    val addedAt: Long,
    val isSynthetic: Boolean, // true if lowQuality was auto-generated from highQuality

    // --- Smart Dataset Analysis ---
    val qualityScore: Float = 0f, // 0-1, sharpness-derived quality of the high-quality target
    val difficultyScore: Float = 0f, // 0-1, higher = network currently struggles more on this pair
    val perceptualHashLow: Long = 0L,
    val perceptualHashHigh: Long = 0L,
    val isDuplicate: Boolean = false,
    val isValid: Boolean = true,
    val invalidReason: String? = null,
    val analyzedAt: Long? = null,

    // --- Usage tracking ---
    val timesUsedInTraining: Int = 0,
    val lastUsedInSessionId: Long? = null
)
