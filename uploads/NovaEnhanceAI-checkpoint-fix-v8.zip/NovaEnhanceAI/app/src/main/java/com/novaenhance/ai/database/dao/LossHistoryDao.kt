package com.novaenhance.ai.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.novaenhance.ai.database.entities.LossHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LossHistoryDao {

    @Query("SELECT * FROM loss_history WHERE sessionId = :sessionId ORDER BY epoch, batchIndex")
    fun observeForSession(sessionId: Long): Flow<List<LossHistoryEntity>>

    @Query("SELECT * FROM loss_history WHERE sessionId = :sessionId ORDER BY epoch, batchIndex")
    suspend fun getForSession(sessionId: Long): List<LossHistoryEntity>

    @Insert
    suspend fun insert(entry: LossHistoryEntity): Long

    @Query(
        """SELECT AVG(loss) FROM loss_history
           WHERE sessionId = :sessionId AND epoch = (SELECT MAX(epoch) FROM loss_history WHERE sessionId = :sessionId)"""
    )
    suspend fun getLatestEpochAverageLoss(sessionId: Long): Float?
}
