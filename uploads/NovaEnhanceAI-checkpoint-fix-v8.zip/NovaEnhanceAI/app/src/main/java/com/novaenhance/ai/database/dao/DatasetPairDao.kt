package com.novaenhance.ai.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.novaenhance.ai.database.entities.DatasetPairEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DatasetPairDao {

    @Query("SELECT * FROM dataset_pairs WHERE modelId = :modelId ORDER BY addedAt DESC")
    fun observeForModel(modelId: String): Flow<List<DatasetPairEntity>>

    @Query("SELECT * FROM dataset_pairs WHERE modelId = :modelId AND isValid = 1 AND isDuplicate = 0")
    suspend fun getUsablePairs(modelId: String): List<DatasetPairEntity>

    /** Difficulty-weighted ordering for the self-improvement loop: harder examples first. */
    @Query(
        """SELECT * FROM dataset_pairs
           WHERE modelId = :modelId AND isValid = 1 AND isDuplicate = 0
           ORDER BY difficultyScore DESC"""
    )
    suspend fun getUsablePairsByDifficulty(modelId: String): List<DatasetPairEntity>

    @Query("SELECT * FROM dataset_pairs WHERE id = :pairId")
    suspend fun getById(pairId: Long): DatasetPairEntity?

    @Query("SELECT * FROM dataset_pairs WHERE modelId = :modelId AND analyzedAt IS NULL")
    suspend fun getUnanalyzed(modelId: String): List<DatasetPairEntity>

    @Query("SELECT COUNT(*) FROM dataset_pairs WHERE modelId = :modelId")
    suspend fun countForModel(modelId: String): Int

    @Query("SELECT perceptualHashLow FROM dataset_pairs WHERE modelId = :modelId AND isDuplicate = 0")
    suspend fun getAllHashesForModel(modelId: String): List<Long>

    @Insert
    suspend fun insert(pair: DatasetPairEntity): Long

    @Insert
    suspend fun insertAll(pairs: List<DatasetPairEntity>): List<Long>

    @Update
    suspend fun update(pair: DatasetPairEntity)

    @Update
    suspend fun updateAll(pairs: List<DatasetPairEntity>)

    @Query("DELETE FROM dataset_pairs WHERE id = :pairId")
    suspend fun delete(pairId: Long)

    @Query("DELETE FROM dataset_pairs WHERE modelId = :modelId")
    suspend fun deleteAllForModel(modelId: String)

    @Query(
        """UPDATE dataset_pairs SET timesUsedInTraining = timesUsedInTraining + 1,
           lastUsedInSessionId = :sessionId WHERE id IN (:pairIds)"""
    )
    suspend fun markUsedInSession(pairIds: List<Long>, sessionId: Long)
}
