package com.novaenhance.ai.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.os.Build
import android.util.Size

/**
 * Decodes just [path]'s pixel dimensions without loading any pixel data -
 * the "bounds only" half of Android's standard efficient-bitmap-loading
 * pattern, split out so callers that only need a size (not a bitmap) don't
 * pay for a full decode either.
 */
fun decodeBitmapBounds(path: String): Size? = try {
    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, options)
    if (options.outWidth <= 0 || options.outHeight <= 0) null
    else Size(options.outWidth, options.outHeight)
} catch (t: Throwable) {
    null
}

/**
 * Decodes [path] at roughly [targetSizePx] on its longest side, using
 * inSampleSize so the full-resolution file is never fully loaded into
 * memory - the standard Android "load a large bitmap efficiently" pattern
 * (bounds first, pick a power-of-two sample size, then decode once at that
 * reduced size).
 *
 * Lives in `utils` (rather than `ui/components`, where this used to live)
 * because it has no Compose/UI dependency and is just as useful to the
 * training pipeline - [com.novaenhance.ai.training.dataset.DatasetAnalyzer]
 * only ever needs a small downsampled bitmap to compute perceptual hash/
 * sharpness/similarity scores, so decoding full camera-resolution photos
 * there was pure waste on exactly the same kind of memory (and, worse,
 * CPU/wall-clock time) this function exists to avoid.
 */
fun decodeSampledBitmap(path: String, targetSizePx: Int): Bitmap? {
    return try {
        val bounds = decodeBitmapBounds(path) ?: return null
        val width = bounds.width
        val height = bounds.height

        var sampleSize = 1
        if (height > targetSizePx || width > targetSizePx) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / sampleSize) >= targetSizePx && (halfWidth / sampleSize) >= targetSizePx) {
                sampleSize *= 2
            }
        }

        val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
        BitmapFactory.decodeFile(path, decodeOptions)
    } catch (t: Throwable) {
        null
    }
}

/**
 * Decodes only the [region] rectangle of the image at [path], full
 * resolution, without ever materializing the whole image in memory - the
 * same efficiency goal as [decodeSampledBitmap], but for callers that need a
 * small crop at *full* detail (e.g. a random training patch) rather than
 * the whole image at *reduced* detail. [com.novaenhance.ai.training.trainer.ModelTrainer]
 * uses this to pull one `tileSize x tileSize` training patch out of a
 * multi-megapixel source photo: decoding the entire photo just to keep a
 * 64x64 corner of it, once per pair per batch for every batch of every
 * epoch, was the single most repeated waste in the whole training loop.
 */
fun decodeBitmapRegion(path: String, region: Rect): Bitmap? {
    val decoder = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            BitmapRegionDecoder.newInstance(path)
        } else {
            @Suppress("DEPRECATION")
            BitmapRegionDecoder.newInstance(path, false)
        }
    } catch (t: Throwable) {
        null
    } ?: return null

    return try {
        decoder.decodeRegion(region, null)
    } catch (t: Throwable) {
        null
    } finally {
        decoder.recycle()
    }
}
