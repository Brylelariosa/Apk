package com.novaenhance.ai.training.trainer

import com.novaenhance.ai.database.entities.TrainingStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * The single shared sink for "what is the background training pipeline
 * doing right now." [ModelTrainer] publishes the TRAINING /
 * SAVING_CHECKPOINT / VALIDATING phases of one session; a promoted
 * session's follow-up RESCORING pass ([SelfImprovementOrchestrator])
 * publishes here too, so the Train AI screen and the training
 * notification (which just observe [progress]) see one continuous stream
 * across the whole pipeline instead of only the part [ModelTrainer] itself
 * runs. One instance for the process (see
 * [com.novaenhance.ai.di.ServiceLocator]), matching there only ever being
 * one training pipeline active at once.
 */
class TrainingProgressPublisher {

    private val _progress = MutableStateFlow<TrainingProgressState?>(null)
    val progress: StateFlow<TrainingProgressState?> = _progress.asStateFlow()

    // Setup failures (dataset analysis, adaptive planning) happen before any
    // TrainingSessionEntity row exists, so a failure there has nowhere in
    // the DB to land - without this, the Train AI screen could only show
    // "I tapped Start and nothing happened."
    private val _lastError = MutableStateFlow<String?>(null)
    val lastError: StateFlow<String?> = _lastError.asStateFlow()

    fun publish(state: TrainingProgressState) {
        _progress.value = state
    }

    /** Updates just the status on whatever was last published, e.g. RUNNING -> PAUSED/CANCELLED. */
    fun updateStatus(status: TrainingStatus) {
        _progress.value = _progress.value?.copy(status = status)
    }

    fun reportStartupFailure(message: String) {
        _lastError.value = message
    }

    fun clearLastError() {
        _lastError.value = null
    }

    /**
     * Call once the *whole* pipeline - session plus any post-promotion
     * rescoring - has truly ended, so a finished run's card doesn't linger
     * on screen forever at its last stale percentage (nothing previously
     * cleared [progress], so the Train AI screen kept rendering it
     * indefinitely even after status flipped to COMPLETED).
     */
    fun clear() {
        _progress.value = null
    }
}
