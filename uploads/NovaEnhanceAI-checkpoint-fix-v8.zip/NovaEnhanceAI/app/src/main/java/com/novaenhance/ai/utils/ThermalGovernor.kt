package com.novaenhance.ai.utils

import com.novaenhance.ai.storage.SettingsRepository
import kotlinx.coroutines.flow.first
import kotlin.math.min

/**
 * Single shared answer to "how should CPU-bound work behave right now?" -
 * every sustained-compute path in the app asks this the same way: the
 * training batch loop, the post-session validation and weak-area rescoring
 * passes (see [com.novaenhance.ai.training.trainer]), AND tile-based image
 * enhancement itself ([com.novaenhance.ai.ai.engine.TileProcessor]), which
 * both the training pipeline and a manual "Enhance" tap on a photo run
 * through. Living here (rather than inside
 * [com.novaenhance.ai.training.trainer.AdaptiveTrainingController], where an
 * earlier version of this lived) is deliberate: this has nothing to do with
 * training plans specifically, and an engine class for plain photo
 * enhancement depending on a *training* controller class to know whether to
 * ease off was a layering smell as soon as the interactive Enhance flow
 * needed the same protection.
 *
 * Used at two layers, which is why the result is a graduated decision
 * rather than a plain pause/proceed boolean:
 *  - [com.novaenhance.ai.training.trainer.ModelTrainer]'s batch loop is the
 *    one caller that treats a whole unit of work as abandonable: it calls
 *    [evaluate] between batches and can treat PAUSE as "stop here, there's
 *    a later cycle to pick this back up" - see its call site.
 *  - [com.novaenhance.ai.ai.engine.TileProcessor] calls it *between tile
 *    chunks inside one image*, where abandoning a partially-processed image
 *    isn't a meaningful thing to do - there it treats PAUSE as "back off as
 *    hard as COOL_DOWN ever does," not as a reason to return an unfinished
 *    result. A validation pass's held-out pairs and a rescoring pass's
 *    sampled pairs go through this same tile-level path once per pair,
 *    deliberately WITHOUT a between-pairs check of their own - see
 *    [com.novaenhance.ai.training.trainer.ModelValidator] and
 *    [com.novaenhance.ai.training.trainer.SelfImprovementOrchestrator] for
 *    why truncating either sample would undermine what it exists to measure.
 *
 * Graduated rather than binary is the other deliberate change from the
 * version of this that used to live inline in
 * [com.novaenhance.ai.training.trainer.AdaptiveTrainingController]: that
 * only ever acted at SEVERE/CRITICAL, so the device ran flat out -
 * every available core, no pacing - all the way up to Android's own
 * late-stage thermal warnings before anything backed off. NONE/LIGHT still
 * proceed at full speed (Android's earliest, most conservative warnings),
 * but MODERATE now gets a small paced cooldown and reduced concurrency
 * instead of nothing, so sustained CPU-bound work - which is what actually
 * drives sustained heat, far more than any single burst - eases off
 * progressively instead of staying pinned until SEVERE.
 */
class ThermalGovernor(
    private val deviceCapabilities: DeviceCapabilities,
    private val settingsRepository: SettingsRepository
) {

    enum class ThrottleAction { PROCEED, COOL_DOWN, PAUSE }

    /**
     * @param cooldownMillis meaningful only when [action] is COOL_DOWN - how
     *   long the caller should suspend before its next unit of work.
     * @param maxConcurrency how many concurrent CPU-bound sub-tasks (e.g.
     *   [com.novaenhance.ai.ai.engine.TileProcessor] tiles) should run at
     *   once right now. Callers that don't fan work out concurrently (e.g.
     *   the training batch loop, which does one JNI call at a time) can
     *   ignore this field.
     */
    data class ThrottleDecision(
        val action: ThrottleAction,
        val cooldownMillis: Long = 0L,
        val maxConcurrency: Int = 1
    )

    /**
     * CRITICAL thermal status and a critically-low-RAM device always PAUSE -
     * hardware-safety floors, not configurable preferences. SEVERE PAUSEs
     * only when the user's "thermal protection" setting is on; with it off
     * this still eases off hard (a long cooldown, concurrency capped to 1)
     * rather than doing nothing - that setting opts out of the hard stop
     * specifically, not out of the app ever easing off.
     *
     * @param concurrencyCeiling the caller's own normal concurrency ceiling
     *   (e.g. [com.novaenhance.ai.ai.engine.TileProcessor]'s configured max)
     *   - PROCEED and MODERATE both scale relative to this rather than a
     *   fixed number, so a caller that never wants more than a couple of
     *   concurrent tasks doesn't get told to run more than it asked for.
     */
    suspend fun evaluate(concurrencyCeiling: Int = 1): ThrottleDecision {
        val snapshot = deviceCapabilities.snapshot()
        val settings = settingsRepository.settings.first()

        if (snapshot.thermalStatus == ThermalStatus.CRITICAL) {
            return ThrottleDecision(ThrottleAction.PAUSE)
        }
        if (snapshot.availableRamMb < Constants.CRITICAL_RAM_THRESHOLD_MB / 2) {
            return ThrottleDecision(ThrottleAction.PAUSE)
        }
        if (snapshot.thermalStatus == ThermalStatus.SEVERE) {
            return if (settings.thermalProtectionEnabled) {
                ThrottleDecision(ThrottleAction.PAUSE)
            } else {
                ThrottleDecision(
                    ThrottleAction.COOL_DOWN,
                    cooldownMillis = Constants.THERMAL_COOLDOWN_SEVERE_UNPROTECTED_MS,
                    maxConcurrency = Constants.THERMAL_CONCURRENCY_SEVERE_UNPROTECTED
                )
            }
        }
        if (snapshot.thermalStatus == ThermalStatus.MODERATE) {
            return ThrottleDecision(
                ThrottleAction.COOL_DOWN,
                cooldownMillis = Constants.THERMAL_COOLDOWN_MODERATE_MS,
                maxConcurrency = min(concurrencyCeiling, Constants.THERMAL_CONCURRENCY_MODERATE)
            )
        }
        return ThrottleDecision(ThrottleAction.PROCEED, maxConcurrency = concurrencyCeiling)
    }
}
