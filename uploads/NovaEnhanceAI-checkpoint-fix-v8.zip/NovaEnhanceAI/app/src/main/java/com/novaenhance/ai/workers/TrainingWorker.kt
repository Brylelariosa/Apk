package com.novaenhance.ai.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.novaenhance.ai.utils.NovaLog

private const val TAG = "TrainingWorker"
const val KEY_MODEL_ID = "modelId"
const val KEY_RESUME_SESSION_ID = "resumeSessionId"

/**
 * The WorkManager half of background training: its only job is to wait for
 * whatever constraints [TrainingScheduler] attached (e.g. "requires
 * charging," per the Settings "train while charging" option) and then hand
 * off to [TrainingForegroundService], which does the actual long-running
 * CPU-bound work. Splitting it this way means the *waiting* survives
 * process death/reboots via WorkManager's own persistence, while the
 * *running* gets a proper foreground-service lifecycle with a live
 * notification - each technology doing the part it's actually good at,
 * rather than one trying to do both.
 */
class TrainingWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val modelId = inputData.getString(KEY_MODEL_ID) ?: return Result.failure()
        val resumeSessionId = inputData.getLong(KEY_RESUME_SESSION_ID, -1L).takeIf { it >= 0 }

        return try {
            TrainingForegroundService.start(applicationContext, modelId, resumeSessionId)
            Result.success()
        } catch (t: Throwable) {
            NovaLog.w(TAG, "Failed to hand off to TrainingForegroundService", t)
            Result.failure()
        }
    }
}
