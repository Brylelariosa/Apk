package com.novaenhance.ai.database

import androidx.room.TypeConverter
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.database.entities.ValidationMetricType

class Converters {
    @TypeConverter
    fun fromTrainingStatus(status: TrainingStatus): String = status.name

    @TypeConverter
    fun toTrainingStatus(value: String): TrainingStatus = TrainingStatus.valueOf(value)

    @TypeConverter
    fun fromValidationMetricType(type: ValidationMetricType): String = type.name

    @TypeConverter
    fun toValidationMetricType(value: String): ValidationMetricType = ValidationMetricType.valueOf(value)
}
