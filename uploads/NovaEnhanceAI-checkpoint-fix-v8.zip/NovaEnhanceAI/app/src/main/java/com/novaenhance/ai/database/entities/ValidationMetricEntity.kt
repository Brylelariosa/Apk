package com.novaenhance.ai.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class ValidationMetricType {
    DETAIL_RECOVERY, NOISE_REDUCTION, SHARPNESS_IMPROVEMENT, ARTIFACT_REMOVAL
}

/**
 * Records one before/after comparison for [com.novaenhance.ai.training.trainer.ModelValidator]'s
 * four validation dimensions. A training session is only promoted (its new
 * checkpoint made active) if the aggregate of these shows improvement -
 * see [TrainingSessionEntity.wasPromoted].
 */
@Entity(
    tableName = "validation_metrics",
    foreignKeys = [
        ForeignKey(
            entity = TrainingSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sessionId")]
)
data class ValidationMetricEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val metricType: ValidationMetricType,
    val scoreBeforeTraining: Float,
    val scoreAfterTraining: Float,
    val recordedAt: Long
) {
    val improved: Boolean get() = scoreAfterTraining > scoreBeforeTraining
    val delta: Float get() = scoreAfterTraining - scoreBeforeTraining
}
