package com.novaenhance.ai.training.dataset

import android.graphics.Bitmap
import com.novaenhance.ai.ai.engine.BitmapSimilarity
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.utils.Constants
import com.novaenhance.ai.utils.ImageMetrics
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.decodeSampledBitmap

private const val TAG = "DatasetAnalyzer"

/**
 * "Smart Dataset Analysis": runs once per newly-added pair (both
 * user-supplied and synthetically-generated) before it's allowed into a
 * training batch. Fills in [DatasetPairEntity.qualityScore],
 * [DatasetPairEntity.difficultyScore], duplicate flags, and validity.
 *
 * Difficulty is deliberately *not* "how blurry the low-quality image is" in
 * isolation - it's how far apart the low/high pair are from each other,
 * since that's what determines how much the network actually has to learn
 * from this specific example. [ModelTrainer]/[SelfImprovementOrchestrator]
 * use this to prioritize harder pairs.
 */
class DatasetAnalyzer(private val datasetPairDao: DatasetPairDao) {

    suspend fun analyzeNewPairs(modelId: String): Int {
        val unanalyzed = datasetPairDao.getUnanalyzed(modelId)
        if (unanalyzed.isEmpty()) return 0

        val startMs = System.currentTimeMillis()
        val seenHashes = datasetPairDao.getAllHashesForModel(modelId).toMutableList()
        val updated = mutableListOf<DatasetPairEntity>()

        for (pair in unanalyzed) {
            updated.add(analyzeOne(pair, seenHashes))
        }

        datasetPairDao.updateAll(updated)
        val elapsedMs = System.currentTimeMillis() - startMs
        // This is the gate every "Start Training" tap runs through first, so
        // its duration directly explains any "nothing happens when I tap
        // Start" report - logged unconditionally (not just on slow runs) so
        // it always shows up in a copied debug report.
        NovaLog.i(TAG, "Analyzed ${updated.size} pairs for model $modelId in ${elapsedMs}ms")
        return updated.size
    }

    private fun analyzeOne(pair: DatasetPairEntity, seenHashes: MutableList<Long>): DatasetPairEntity {
        val now = System.currentTimeMillis()
        val lowBitmap = decodeBitmap(pair.lowQualityPath)
        val highBitmap = decodeBitmap(pair.highQualityPath)

        if (lowBitmap == null || highBitmap == null) {
            lowBitmap?.recycle()
            highBitmap?.recycle()
            return pair.copy(isValid = false, invalidReason = "Could not decode one or both images", analyzedAt = now)
        }

        try {
            val hashLow = ImageMetrics.perceptualHash(lowBitmap)
            val hashHigh = ImageMetrics.perceptualHash(highBitmap)

            val isDuplicate = seenHashes.any {
                ImageMetrics.hammingDistance(it, hashLow) <= Constants.DUPLICATE_HASH_DISTANCE_THRESHOLD
            }

            val similarity = BitmapSimilarity.quickSimilarity(lowBitmap, highBitmap)
            var isValid = true
            var invalidReason: String? = null
            when {
                similarity < Constants.MIN_VALID_PAIR_SIMILARITY -> {
                    isValid = false
                    invalidReason = "Low- and high-quality images appear to show different content"
                }
                similarity > Constants.MAX_VALID_PAIR_SIMILARITY && !pair.isSynthetic -> {
                    isValid = false
                    invalidReason = "Images are nearly identical - nothing for the model to learn from this pair"
                }
            }

            val qualityScore = ImageMetrics.normalizeQuality(ImageMetrics.sharpnessScore(highBitmap))
            val difficultyScore = (1f - similarity).coerceIn(0f, 1f)

            if (!isDuplicate) seenHashes.add(hashLow)

            return pair.copy(
                qualityScore = qualityScore,
                difficultyScore = difficultyScore,
                perceptualHashLow = hashLow,
                perceptualHashHigh = hashHigh,
                isDuplicate = isDuplicate,
                isValid = isValid,
                invalidReason = invalidReason,
                analyzedAt = now
            )
        } finally {
            lowBitmap.recycle()
            highBitmap.recycle()
        }
    }

    private fun decodeBitmap(path: String): Bitmap? =
        decodeSampledBitmap(path, targetSizePx = Constants.DATASET_ANALYSIS_DECODE_TARGET_PX)
            ?: run { NovaLog.w(TAG, "Failed to decode $path"); null }
}
