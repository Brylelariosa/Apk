package com.novaenhance.ai.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A curated example retained for anti-forgetting via experience replay.
 *
 * Deliberately NOT a foreign key to [DatasetPairEntity] for its image paths:
 * the product requirement is "deleting training images must NOT delete
 * learned AI knowledge," so when a pair is selected into the replay buffer
 * (see [com.novaenhance.ai.training.trainer.ExperienceMemory]) its images are
 * *copied* into the app's private replay_buffer/ directory. The buffer then
 * survives the user clearing their dataset entirely.
 *
 * `originatingPairId` is kept only as an informational back-reference (for
 * "why is this example in the buffer" debugging in Dataset Manager) and is
 * allowed to dangle once the source pair is deleted.
 */
@Entity(
    tableName = "replay_buffer",
    foreignKeys = [
        ForeignKey(
            entity = ModelEntity::class,
            parentColumns = ["id"],
            childColumns = ["modelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("modelId")]
)
data class ReplayBufferEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val modelId: String,
    val lowQualityPath: String, // path inside replay_buffer/, an independent copy
    val highQualityPath: String,
    val originatingPairId: Long?,
    val difficultyScore: Float,
    val addedAt: Long,
    val timesReplayed: Int = 0
)
