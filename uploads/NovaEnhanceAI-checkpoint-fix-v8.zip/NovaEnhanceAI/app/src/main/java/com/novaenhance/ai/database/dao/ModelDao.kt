package com.novaenhance.ai.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.novaenhance.ai.database.entities.ModelEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ModelDao {

    @Query("SELECT * FROM models ORDER BY isActive DESC, lastTrainedAt DESC")
    fun observeAll(): Flow<List<ModelEntity>>

    @Query("SELECT * FROM models WHERE id = :modelId")
    suspend fun getById(modelId: String): ModelEntity?

    @Query("SELECT * FROM models WHERE id = :modelId")
    fun observeById(modelId: String): Flow<ModelEntity?>

    @Query("SELECT * FROM models WHERE isActive = 1 LIMIT 1")
    suspend fun getActive(): ModelEntity?

    @Query("SELECT * FROM models WHERE isActive = 1 LIMIT 1")
    fun observeActive(): Flow<ModelEntity?>

    /** Any model row at all, regardless of active flag - used by ModelRepository.getOrCreateActiveModel() to detect "a model exists but isn't marked active" before deciding a brand-new one is actually needed. */
    @Query("SELECT * FROM models LIMIT 1")
    suspend fun getAny(): ModelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(model: ModelEntity)

    @Update
    suspend fun update(model: ModelEntity)

    @Query("UPDATE models SET isActive = 0")
    suspend fun deactivateAll()

    @Query("UPDATE models SET isActive = 1 WHERE id = :modelId")
    suspend fun setActive(modelId: String)

    @Query("DELETE FROM models WHERE id = :modelId")
    suspend fun delete(modelId: String)

    @Query(
        """UPDATE models SET
            currentVersionNumber = :versionNumber,
            parameterCount = :parameterCount,
            sizeBytes = :sizeBytes,
            trainingSessionCount = trainingSessionCount + 1,
            totalImagesLearned = totalImagesLearned + :newImagesLearned,
            lastTrainedAt = :trainedAt,
            improvementScore = :improvementScore
           WHERE id = :modelId"""
    )
    suspend fun recordTrainingPromotion(
        modelId: String,
        versionNumber: Int,
        parameterCount: Long,
        sizeBytes: Long,
        newImagesLearned: Int,
        trainedAt: Long,
        improvementScore: Float
    )
}
