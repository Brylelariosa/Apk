package com.novaenhance.ai.utils

import android.graphics.Bitmap
import kotlin.math.log10
import kotlin.math.max

/**
 * Cheap, pure-Kotlin image metrics used by dataset analysis (Smart Dataset
 * Analysis: duplicate detection, quality scoring, difficulty scoring).
 * These run on small (8x8-64x64) downsampled thumbnails, so there's no need
 * to reach for the native filter library here - the cost is negligible even
 * on a low-end device, and keeping this in Kotlin means dataset scanning
 * doesn't need a live JNI/bitmap-locking session at all.
 */
object ImageMetrics {

    /**
     * Difference hash (dHash): downsample to (size+1) x size grayscale,
     * then set bit i if pixel[i] < pixel[i+1] (brightness gradient). Two
     * images with a small Hamming distance between their hashes are
     * near-duplicates - this is far cheaper and more robust to minor
     * recompression/resizing than a byte-for-byte comparison.
     */
    fun perceptualHash(bitmap: Bitmap, size: Int = Constants.PERCEPTUAL_HASH_SIZE): Long {
        val scaled = Bitmap.createScaledBitmap(bitmap, size + 1, size, true)
        var hash = 0L
        var bitIndex = 0
        val gray = IntArray((size + 1) * size)
        scaled.getPixels(gray, 0, size + 1, 0, 0, size + 1, size)

        for (y in 0 until size) {
            for (x in 0 until size) {
                val left = luma(gray[y * (size + 1) + x])
                val right = luma(gray[y * (size + 1) + x + 1])
                if (left < right) {
                    hash = hash or (1L shl bitIndex)
                }
                bitIndex++
            }
        }
        if (scaled != bitmap) scaled.recycle()
        return hash
    }

    fun hammingDistance(a: Long, b: Long): Int = java.lang.Long.bitCount(a xor b)

    /**
     * Sharpness proxy via Laplacian variance on a downsampled grayscale copy:
     * blurry/low-quality images have low variance in their second derivative,
     * sharp/detailed images have high variance. Returned value is unbounded
     * (typically 0-2000 for phone photos); callers normalize as needed.
     */
    fun sharpnessScore(bitmap: Bitmap, sampleSize: Int = 128): Double {
        val w = minOf(sampleSize, bitmap.width)
        val h = minOf(sampleSize, bitmap.height)
        val scaled = Bitmap.createScaledBitmap(bitmap, w, h, true)
        val pixels = IntArray(w * h)
        scaled.getPixels(pixels, 0, w, 0, 0, w, h)

        val lumaArr = IntArray(w * h) { luma(pixels[it]) }
        var sum = 0.0
        var sumSq = 0.0
        var count = 0

        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val center = lumaArr[y * w + x]
                val laplacian = (
                    lumaArr[(y - 1) * w + x] + lumaArr[(y + 1) * w + x] +
                        lumaArr[y * w + (x - 1)] + lumaArr[y * w + (x + 1)] - 4 * center
                    )
                sum += laplacian
                sumSq += laplacian.toDouble() * laplacian
                count++
            }
        }
        if (scaled != bitmap) scaled.recycle()
        if (count == 0) return 0.0
        val mean = sum / count
        return (sumSq / count) - (mean * mean)
    }

    /** Peak signal-to-noise ratio in dB between two same-size images (higher = closer match). */
    fun psnr(a: Bitmap, b: Bitmap): Double {
        require(a.width == b.width && a.height == b.height) { "PSNR requires equal dimensions" }
        val w = a.width
        val h = a.height
        val pa = IntArray(w * h)
        val pb = IntArray(w * h)
        a.getPixels(pa, 0, w, 0, 0, w, h)
        b.getPixels(pb, 0, w, 0, 0, w, h)

        var sumSquaredError = 0.0
        for (i in pa.indices) {
            val la = luma(pa[i])
            val lb = luma(pb[i])
            val diff = (la - lb).toDouble()
            sumSquaredError += diff * diff
        }
        val mse = sumSquaredError / (w * h)
        if (mse == 0.0) return 100.0 // identical images; cap rather than return Infinity
        return 20 * log10(255.0 / kotlin.math.sqrt(mse))
    }

    /** Normalizes a raw sharpness score into a rough 0-1 "quality" estimate. */
    fun normalizeQuality(rawSharpness: Double): Float {
        val clamped = max(0.0, rawSharpness)
        // Empirically, phone-camera JPEGs land in the low hundreds to ~1500;
        // this squashes that range into 0-1 without needing a learned model
        // just to rank "is this pair usable" during dataset intake.
        return (clamped / (clamped + 400.0)).toFloat()
    }

    private fun luma(pixel: Int): Int {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return (r * 299 + g * 587 + b * 114) / 1000
    }
}
