package com.novaenhance.ai.utils

/**
 * A richer alternative to [kotlin.Result] for operations (inference, training,
 * dataset import) that need a distinguishable "in progress" state in addition
 * to success/failure, and that want a human-readable message alongside the
 * throwable for surfacing in the UI without a giant `when` on exception types.
 */
sealed class NovaResult<out T> {
    data class Success<T>(val value: T) : NovaResult<T>()
    data class Error(val message: String, val cause: Throwable? = null) : NovaResult<Nothing>()
    data class Progress(val fraction: Float, val message: String = "") : NovaResult<Nothing>()

    inline fun onSuccess(action: (T) -> Unit): NovaResult<T> {
        if (this is Success) action(value)
        return this
    }

    inline fun onError(action: (String, Throwable?) -> Unit): NovaResult<T> {
        if (this is Error) action(message, cause)
        return this
    }

    companion object {
        fun <T> of(block: () -> T): NovaResult<T> = try {
            Success(block())
        } catch (t: Throwable) {
            Error(t.message ?: "Unknown error", t)
        }
    }
}
