package com.novaenhance.ai.ai.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

private const val CHECKPOINT_MAGIC = 0x4E564149 // "NVAI" as int32
private const val CHECKPOINT_FORMAT_VERSION = 1
private const val HEADER_SIZE_BYTES = 12 // magic(4) + formatVersion(4) + adamStep(4)

/**
 * Thrown by [NovaModelEngine.restoreCheckpoint] when a checkpoint file's size doesn't match what
 * the current [NativeNeuralEngine.TOTAL_PARAMS] expects - i.e. it was saved under a different
 * network architecture (see `network.h`'s dated widening notes for the kind of change that causes
 * this). There's no partial or resizable way to load it: a different channel count is a
 * different-shaped parameter array, not a truncated/padded version of the same one. Callers should
 * treat this the same as "no checkpoint exists yet" and fall back to [NovaModelEngine.createFresh]
 * rather than surface it as a raw crash - see [com.novaenhance.ai.ai.model.ModelRepository.getEngine].
 */
class CheckpointSizeMismatchException(val expectedBytes: Long, val actualBytes: Long, path: String) : Exception(
    "Checkpoint at $path is sized for a different architecture " +
        "(expected $expectedBytes bytes for the current TOTAL_PARAMS=${NativeNeuralEngine.TOTAL_PARAMS}, " +
        "file is $actualBytes bytes) - likely saved before an architecture change."
)

/**
 * Owns one model's live state: its [NativeNeuralEngine.TOTAL_PARAMS]
 * weights, plus the Adam optimizer's momentum/velocity accumulators and
 * step counter. This is the entire replacement for the old TFLite-based
 * `TFLiteEngine` - there's no interpreter, no signature runner, no
 * checkpoint-file-format complexity inherited from TensorFlow. A "model" is
 * just these arrays; see [NativeNeuralEngine] for where the actual forward/
 * backward/optimizer math happens (verified in `tools/nn_verification/`).
 *
 * Kept as a plain Kotlin class (no native handle, no `close()` to forget) -
 * all state lives in ordinary [FloatArray]s that Kotlin's GC manages
 * normally; [NativeNeuralEngine]'s JNI calls are stateless functions that
 * read/mutate whatever arrays are passed in.
 */
class NovaModelEngine private constructor(
    private var params: FloatArray,
    private var momentum: FloatArray,
    private var velocity: FloatArray,
    private var adamStep: Int
) {
    private var anchorParams: FloatArray? = null

    val tileSize: Int get() = NativeNeuralEngine.TILE_SIZE

    suspend fun inferTile(pixels: IntArray): IntArray = withContext(Dispatchers.Default) {
        val input = TensorImageCodec.encodeSingle(pixels, tileSize)
        val output = NativeNeuralEngine.infer(input, params)
        TensorImageCodec.decodeSingle(output, tileSize)
    }

    /**
     * Runs one training step over a batch of (low-quality, high-quality)
     * tile pairs and returns the loss. `l2SpLambda` is 0 to disable the
     * anti-forgetting penalty entirely (e.g. a model's very first training
     * session, with nothing yet to protect).
     */
    suspend fun trainBatch(
        lowQualityTiles: List<IntArray>,
        highQualityTiles: List<IntArray>,
        learningRate: Float,
        l2SpLambda: Float
    ): Float = withContext(Dispatchers.Default) {
        require(lowQualityTiles.size == highQualityTiles.size) {
            "Batch size mismatch: ${lowQualityTiles.size} low-quality vs ${highQualityTiles.size} high-quality tiles"
        }
        val inputBatch = TensorImageCodec.encodeBatch(lowQualityTiles, tileSize)
        val targetBatch = TensorImageCodec.encodeBatch(highQualityTiles, tileSize)
        adamStep += 1
        NativeNeuralEngine.trainStep(
            inputBatch, targetBatch, lowQualityTiles.size,
            params, momentum, velocity,
            anchorParams, adamStep, learningRate, l2SpLambda
        )
    }

    /** Snapshots current weights as the anti-forgetting anchor. Call once per session, before any [trainBatch]. */
    suspend fun setAnchor() = withContext(Dispatchers.Default) {
        anchorParams = params.copyOf()
    }

    suspend fun saveCheckpoint(path: String): String = withContext(Dispatchers.IO) {
        val file = File(path)
        file.parentFile?.mkdirs()
        file.outputStream().buffered().use { out ->
            val header = ByteBuffer.allocate(HEADER_SIZE_BYTES).order(ByteOrder.nativeOrder())
            header.putInt(CHECKPOINT_MAGIC)
            header.putInt(CHECKPOINT_FORMAT_VERSION)
            header.putInt(adamStep)
            out.write(header.array())
            out.write(floatArrayToBytes(params))
            out.write(floatArrayToBytes(momentum))
            out.write(floatArrayToBytes(velocity))
        }
        path
    }

    suspend fun restoreCheckpoint(path: String) = withContext(Dispatchers.IO) {
        val file = File(path)
        val expectedBytes = HEADER_SIZE_BYTES + 3L * NativeNeuralEngine.TOTAL_PARAMS * 4L
        val actualBytes = file.length()
        if (actualBytes != expectedBytes) {
            throw CheckpointSizeMismatchException(expectedBytes, actualBytes, path)
        }
        file.inputStream().buffered().use { input ->
            val header = ByteArray(HEADER_SIZE_BYTES)
            readFully(input, header)
            val headerBuffer = ByteBuffer.wrap(header).order(ByteOrder.nativeOrder())
            val magic = headerBuffer.int
            val formatVersion = headerBuffer.int
            require(magic == CHECKPOINT_MAGIC) { "Not a NovaEnhance checkpoint file: $path" }
            require(formatVersion == CHECKPOINT_FORMAT_VERSION) { "Unsupported checkpoint format version $formatVersion" }
            adamStep = headerBuffer.int

            params = readFloatArray(input, NativeNeuralEngine.TOTAL_PARAMS)
            momentum = readFloatArray(input, NativeNeuralEngine.TOTAL_PARAMS)
            velocity = readFloatArray(input, NativeNeuralEngine.TOTAL_PARAMS)
        }
    }

    private fun floatArrayToBytes(array: FloatArray): ByteArray {
        val buffer = ByteBuffer.allocate(array.size * 4).order(ByteOrder.nativeOrder())
        buffer.asFloatBuffer().put(array)
        return buffer.array()
    }

    private fun readFloatArray(input: java.io.InputStream, size: Int): FloatArray {
        val bytes = ByteArray(size * 4)
        readFully(input, bytes)
        val floatArray = FloatArray(size)
        ByteBuffer.wrap(bytes).order(ByteOrder.nativeOrder()).asFloatBuffer().get(floatArray)
        return floatArray
    }

    private fun readFully(input: java.io.InputStream, dest: ByteArray) {
        var offset = 0
        while (offset < dest.size) {
            val read = input.read(dest, offset, dest.size - offset)
            if (read == -1) error("Unexpected end of stream reading checkpoint (got $offset of ${dest.size} bytes)")
            offset += read
        }
    }

    companion object {
        /** A brand-new model with freshly (randomly) initialized weights - no file, no asset, no external step needed. */
        fun createFresh(seed: Long = System.nanoTime()): NovaModelEngine {
            val params = FloatArray(NativeNeuralEngine.TOTAL_PARAMS)
            NativeNeuralEngine.initializeParams(params, seed)
            return NovaModelEngine(
                params = params,
                momentum = FloatArray(NativeNeuralEngine.TOTAL_PARAMS),
                velocity = FloatArray(NativeNeuralEngine.TOTAL_PARAMS),
                adamStep = 0
            )
        }

        suspend fun loadFromCheckpoint(path: String): NovaModelEngine = withContext(Dispatchers.IO) {
            val engine = createFresh(seed = 0L) // placeholder arrays, immediately overwritten below
            engine.restoreCheckpoint(path)
            engine
        }
    }
}
