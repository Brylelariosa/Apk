package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.dao.LossHistoryDao
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.TrainingSessionDao
import com.novaenhance.ai.database.dao.ValidationMetricDao
import com.novaenhance.ai.database.entities.LossHistoryEntity
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.database.entities.ValidationMetricEntity
import com.novaenhance.ai.storage.SettingsRepository
import com.novaenhance.ai.training.dataset.DatasetManager
import com.novaenhance.ai.training.trainer.ModelTrainer
import com.novaenhance.ai.training.trainer.TrainingControlFlow
import com.novaenhance.ai.workers.TrainingScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TrainingUiState(
    val activeModel: ModelEntity? = null,
    val datasetPairCount: Int = 0,
    val currentSession: TrainingSessionEntity? = null,
    val showKeepOrDeleteDatasetPrompt: Boolean = false,
    val isStarting: Boolean = false,
    val message: String? = null
)

data class SessionDetailUiState(
    val lossHistory: List<LossHistoryEntity> = emptyList(),
    val validationMetrics: List<ValidationMetricEntity> = emptyList()
)

class TrainingViewModel(
    private val appContext: Context,
    private val modelDao: ModelDao,
    private val modelRepository: ModelRepository,
    private val trainingSessionDao: TrainingSessionDao,
    private val lossHistoryDao: LossHistoryDao,
    private val validationMetricDao: ValidationMetricDao,
    private val modelTrainer: ModelTrainer,
    private val controlFlow: TrainingControlFlow,
    private val settingsRepository: SettingsRepository,
    private val datasetManager: DatasetManager,
    private val datasetPairDao: DatasetPairDao
) : ViewModel() {

    private val showPrompt = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)
    private val isStarting = MutableStateFlow(false)

    private var lastSeenStatusBySessionId = mutableMapOf<Long, TrainingStatus>()

    // ModelTrainer.lastError carries setup failures (dataset analysis,
    // adaptive planning) that happen before any session row exists - see
    // ModelTrainer.reportStartupFailure. Merged with the ViewModel's own
    // `message` (used for failures in this screen's own start/resume call)
    // so TrainingScreen only has to render one message field either way.
    private val resolvedMessage: Flow<String?> =
        combine(message, modelTrainer.lastError) { explicit, trainerError -> explicit ?: trainerError }

    val uiState: StateFlow<TrainingUiState> = modelDao.observeActive()
        .flatMapLatest { model ->
            if (model == null) {
                flowOf(TrainingUiState())
            } else {
                combine(
                    trainingSessionDao.observeForModel(model.id),
                    datasetPairDao.observeForModel(model.id).map { it.size },
                    showPrompt,
                    isStarting,
                    resolvedMessage
                ) { sessions, count, prompt, starting, msg ->
                    val mostRecent = sessions.maxByOrNull { it.startedAt }
                    detectCompletionTransition(mostRecent)
                    TrainingUiState(
                        activeModel = model,
                        datasetPairCount = count,
                        currentSession = mostRecent,
                        showKeepOrDeleteDatasetPrompt = prompt,
                        isStarting = resolveIsStarting(starting, mostRecent, msg),
                        message = msg
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TrainingUiState())

    val liveProgress = modelTrainer.progress

    private val _sessionDetail = MutableStateFlow(SessionDetailUiState())
    val sessionDetail: StateFlow<SessionDetailUiState> = _sessionDetail.asStateFlow()

    private fun detectCompletionTransition(session: TrainingSessionEntity?) {
        if (session == null) return
        val previousStatus = lastSeenStatusBySessionId[session.id]
        val wasActive = previousStatus == TrainingStatus.RUNNING || previousStatus == TrainingStatus.PAUSED
        if (wasActive && session.status == TrainingStatus.COMPLETED && session.wasPromoted) {
            showPrompt.value = true
        }
        lastSeenStatusBySessionId[session.id] = session.status
    }

    /**
     * Tapping "Start Training" can take a while to show up as a RUNNING
     * session (dataset analysis runs first - see [ModelTrainer.runSession]),
     * so [isStarting] gives the button immediate feedback instead of
     * appearing to do nothing until that finishes. Cleared the moment the
     * real state catches up, whether that's the session actually running/
     * resumed, or a startup error arriving instead.
     */
    private fun resolveIsStarting(starting: Boolean, session: TrainingSessionEntity?, resolvedMsg: String?): Boolean {
        if (!starting) return false
        val settled = session?.status == TrainingStatus.RUNNING || session?.status == TrainingStatus.PAUSED || resolvedMsg != null
        if (settled) isStarting.value = false
        return !settled
    }

    fun startOrResumeTraining() {
        isStarting.value = true
        message.value = null
        modelTrainer.clearLastError()
        viewModelScope.launch {
            try {
                val model = modelRepository.getOrCreateActiveModel()
                val settings = settingsRepository.settings.first()
                val resumeId = uiState.value.currentSession?.takeIf { it.status == TrainingStatus.PAUSED }?.id
                TrainingScheduler.start(appContext, model.id, resumeId, settings.trainOnlyWhileCharging)
            } catch (t: Throwable) {
                isStarting.value = false
                message.value = "Couldn't start training: ${t.message ?: t::class.simpleName}"
            }
        }
    }

    fun pauseTraining() = controlFlow.pause()

    fun cancelTraining() = controlFlow.cancel()

    fun keepDataset() {
        showPrompt.value = false
    }

    fun deleteDataset() {
        viewModelScope.launch {
            uiState.value.activeModel?.let { model -> datasetManager.deleteAllForModel(model.id) }
            showPrompt.value = false
        }
    }

    fun loadSessionDetail(sessionId: Long) {
        viewModelScope.launch {
            _sessionDetail.value = SessionDetailUiState(
                lossHistory = lossHistoryDao.getForSession(sessionId),
                validationMetrics = validationMetricDao.getForSession(sessionId)
            )
        }
    }
}
