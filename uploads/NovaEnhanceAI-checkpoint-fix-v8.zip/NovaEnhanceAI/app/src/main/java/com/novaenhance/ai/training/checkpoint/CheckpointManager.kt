package com.novaenhance.ai.training.checkpoint

import com.novaenhance.ai.utils.NovaLog
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

private const val TAG = "CheckpointManager"
private const val ENTRY_WEIGHTS = "model.weights"
private const val ENTRY_METADATA = "metadata.json"

/**
 * Packages/unpacks a `.novamodel` bundle: a version's single weights file
 * (see [com.novaenhance.ai.ai.engine.NovaModelEngine]'s save/restore
 * format) plus its metadata sidecar, zipped together into one portable,
 * importable file. Much simpler than this project's earlier TFLite-based
 * design, which needed to juggle several sibling checkpoint shard files
 * sharing a prefix plus a separately-shared architecture graph file - here
 * a version is just one file, so backup/export/import is just "copy/zip/
 * unzip one file," full stop.
 */
class CheckpointManager {

    fun exportBundle(weightsFile: File, metadataFile: File, destZip: File) {
        destZip.parentFile?.mkdirs()
        ZipOutputStream(destZip.outputStream().buffered()).use { zip ->
            addEntry(zip, ENTRY_WEIGHTS, weightsFile)
            addEntry(zip, ENTRY_METADATA, metadataFile)
        }
        NovaLog.i(TAG, "Exported bundle to ${destZip.path} (${destZip.length()} bytes)")
    }

    data class ImportedBundle(val weightsFile: File, val metadataFile: File)

    fun importBundle(zipFile: File, destDir: File, versionNumber: Int): ImportedBundle {
        destDir.mkdirs()
        val weightsFile = File(destDir, "v$versionNumber.weights")
        val metadataFile = File(destDir, "v$versionNumber.json")

        ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
            var entry: ZipEntry? = zip.nextEntry
            while (entry != null) {
                when (entry.name) {
                    ENTRY_WEIGHTS -> writeEntry(zip, weightsFile)
                    ENTRY_METADATA -> writeEntry(zip, metadataFile)
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }

        require(weightsFile.exists()) { "Bundle is missing $ENTRY_WEIGHTS" }
        require(metadataFile.exists()) { "Bundle is missing $ENTRY_METADATA" }
        return ImportedBundle(weightsFile, metadataFile)
    }

    private fun addEntry(zip: ZipOutputStream, name: String, file: File) {
        zip.putNextEntry(ZipEntry(name))
        file.inputStream().use { it.copyTo(zip) }
        zip.closeEntry()
    }

    private fun writeEntry(zip: ZipInputStream, dest: File) {
        dest.outputStream().use { out -> zip.copyTo(out) }
    }
}
