package com.novaenhance.ai.training.dataset

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.storage.AppStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import kotlin.random.Random

/**
 * Dataset Manager screen's backing repository: add/remove/preview pairs,
 * import/export a dataset, and the post-training "keep or delete images"
 * decision. Per the product requirement, deleting a pair here only removes
 * the *dataset* copy - anything already promoted into
 * [com.novaenhance.ai.training.trainer.ExperienceMemory]'s replay buffer has
 * its own independent copy and is unaffected.
 *
 * Every function below that touches disk, a Bitmap, or a native filter is
 * wrapped in `withContext(Dispatchers.IO)`, making this repository main-safe
 * on its own: callers (currently just [com.novaenhance.ai.ui.viewmodel.DatasetViewModel],
 * which invokes these via a plain `viewModelScope.launch { }` with no
 * dispatcher override) can call any of them directly from Main without
 * blocking the UI thread. [addSyntheticPairs] in particular chains a decode
 * plus, per variant, up to several full-resolution native degradation passes
 * (see [DegradationGenerator.degrade]) and two JPEG encodes - multiple
 * seconds of real work for a large source photo, all of which used to run
 * synchronously on whichever thread called it.
 */
class DatasetManager(
    private val context: Context,
    private val storage: AppStorage,
    private val datasetPairDao: DatasetPairDao,
    private val analyzer: DatasetAnalyzer,
    private val degradationGenerator: DegradationGenerator = DegradationGenerator()
) {

    fun observePairs(modelId: String): Flow<List<DatasetPairEntity>> = datasetPairDao.observeForModel(modelId)

    /** Adds a manually-selected (low, high) pair, copying both images into app-private storage. */
    suspend fun addManualPair(modelId: String, lowQualityUri: Uri, highQualityUri: Uri): DatasetPairEntity =
        withContext(Dispatchers.IO) {
            val pairId = UUID.randomUUID().toString()
            val lowDest = File(storage.datasetLowQualityDir(modelId), "$pairId.jpg")
            val highDest = File(storage.datasetHighQualityDir(modelId), "$pairId.jpg")

            copyUriToFile(lowQualityUri, lowDest)
            copyUriToFile(highQualityUri, highDest)

            val entity = DatasetPairEntity(
                modelId = modelId,
                lowQualityPath = lowDest.path,
                highQualityPath = highDest.path,
                addedAt = System.currentTimeMillis(),
                isSynthetic = false
            )
            val id = datasetPairDao.insert(entity)
            val saved = entity.copy(id = id)
            analyzer.analyzeNewPairs(modelId)
            saved
        }

    /** Generates one or more synthetic (low, high) pairs from a single high-quality source image. */
    suspend fun addSyntheticPairs(modelId: String, highQualitySourceUri: Uri, variantCount: Int = 3): List<DatasetPairEntity> =
        withContext(Dispatchers.IO) {
            val sourceBitmap = context.contentResolver.openInputStream(highQualitySourceUri)?.use {
                BitmapFactory.decodeStream(it)
            } ?: error("Could not decode source image")

            val created = mutableListOf<DatasetPairEntity>()
            try {
                repeat(variantCount) {
                    val pairId = UUID.randomUUID().toString()
                    val highDest = File(storage.datasetHighQualityDir(modelId), "$pairId.jpg")
                    val lowDest = File(storage.datasetLowQualityDir(modelId), "$pairId.jpg")

                    saveBitmap(sourceBitmap, highDest)

                    // randomRecipe()'s default severity floor (0.4) means every
                    // synthetic pair otherwise guarantees a real correction is
                    // needed - the model never sees a rewarded "this is already
                    // mostly fine, go easy" example, which risks over-correcting
                    // (over-sharpening/over-denoising) genuinely good photos at
                    // inference. A minority of variants deliberately draw from a
                    // low severity range instead - not zero, so this still keeps
                    // DegradationGenerator's own guarantee that some blur/noise
                    // is always applied and doesn't produce a functionally
                    // identical pair.
                    val recipe = if (Random.nextFloat() < LOW_SEVERITY_VARIANT_CHANCE) {
                        degradationGenerator.randomRecipe(severity = Random.nextFloat() * LOW_SEVERITY_CEILING)
                    } else {
                        degradationGenerator.randomRecipe()
                    }
                    val degraded = degradationGenerator.degrade(sourceBitmap, recipe)
                    saveBitmap(degraded, lowDest)
                    degraded.recycle()

                    val entity = DatasetPairEntity(
                        modelId = modelId,
                        lowQualityPath = lowDest.path,
                        highQualityPath = highDest.path,
                        addedAt = System.currentTimeMillis(),
                        isSynthetic = true
                    )
                    val id = datasetPairDao.insert(entity)
                    created.add(entity.copy(id = id))
                }
            } finally {
                sourceBitmap.recycle()
            }

            analyzer.analyzeNewPairs(modelId)
            created
        }

    suspend fun removePair(pair: DatasetPairEntity) {
        withContext(Dispatchers.IO) {
            File(pair.lowQualityPath).delete()
            File(pair.highQualityPath).delete()
            datasetPairDao.delete(pair.id)
        }
    }

    /** "Training completed. Delete training images?" -> Delete Dataset option. Learned weights are unaffected. */
    suspend fun deleteAllForModel(modelId: String) {
        withContext(Dispatchers.IO) {
            val pairs = datasetPairDao.getUsablePairs(modelId)
            pairs.forEach {
                File(it.lowQualityPath).delete()
                File(it.highQualityPath).delete()
            }
            datasetPairDao.deleteAllForModel(modelId)
            storage.datasetDir(modelId).deleteRecursively()
        }
    }

    suspend fun datasetSizeBytes(modelId: String): Long = withContext(Dispatchers.IO) {
        storage.datasetDir(modelId).walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }

    /** Exports every usable pair as a single zip (`low/pair_0001.jpg` + `high/pair_0001.jpg`, ...) for backup/sharing. */
    suspend fun exportDataset(modelId: String): File = withContext(Dispatchers.IO) {
        val destZip = File(storage.datasetsDir(), "${modelId}_dataset_${System.currentTimeMillis()}.zip")
        java.util.zip.ZipOutputStream(destZip.outputStream().buffered()).use { zip ->
            val pairs = datasetPairDao.getUsablePairs(modelId)
            for ((index, pair) in pairs.withIndex()) {
                val name = "pair_%04d.jpg".format(index)
                addZipEntry(zip, "low/$name", File(pair.lowQualityPath))
                addZipEntry(zip, "high/$name", File(pair.highQualityPath))
            }
        }
        destZip
    }

    /**
     * Imports a dataset zip previously produced by [exportDataset] (or hand-built
     * with the same `low/`+`high/` matching-filename convention).
     *
     * Deliberately does NOT run [DatasetAnalyzer] itself - a bulk import can be
     * large, and analysis belongs on a durable background worker
     * (`DatasetAnalysisWorker`) rather than blocking this call or risking
     * losing progress to process death. Callers should enqueue that worker
     * for [modelId] after a successful import; this keeps `training.dataset`
     * from depending on the `workers` package, which depends on it instead.
     *
     * Returns the number of pairs imported.
     */
    suspend fun importDataset(modelId: String, zipUri: Uri): Int = withContext(Dispatchers.IO) {
        val tempDir = File(context.cacheDir, "dataset_import_${System.currentTimeMillis()}").apply { mkdirs() }
        try {
            context.contentResolver.openInputStream(zipUri)?.use { input ->
                java.util.zip.ZipInputStream(input.buffered()).use { zip ->
                    var entry = zip.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            val dest = File(tempDir, entry.name)
                            dest.parentFile?.mkdirs()
                            dest.outputStream().use { out -> zip.copyTo(out) }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: error("Could not open $zipUri")

            val lowFiles = File(tempDir, "low").listFiles()?.associateBy { it.name } ?: emptyMap()
            val highFiles = File(tempDir, "high").listFiles()?.associateBy { it.name } ?: emptyMap()

            val newPairs = lowFiles.mapNotNull { (name, lowFile) ->
                val highFile = highFiles[name] ?: return@mapNotNull null
                val pairId = UUID.randomUUID().toString()
                val lowDest = File(storage.datasetLowQualityDir(modelId), "$pairId.jpg")
                val highDest = File(storage.datasetHighQualityDir(modelId), "$pairId.jpg")
                lowFile.copyTo(lowDest, overwrite = true)
                highFile.copyTo(highDest, overwrite = true)
                DatasetPairEntity(
                    modelId = modelId, lowQualityPath = lowDest.path, highQualityPath = highDest.path,
                    addedAt = System.currentTimeMillis(), isSynthetic = false
                )
            }

            if (newPairs.isNotEmpty()) datasetPairDao.insertAll(newPairs)
            newPairs.size
        } finally {
            tempDir.deleteRecursively()
        }
    }

    private fun addZipEntry(zip: java.util.zip.ZipOutputStream, name: String, file: File) {
        zip.putNextEntry(java.util.zip.ZipEntry(name))
        file.inputStream().use { it.copyTo(zip) }
        zip.closeEntry()
    }

    private fun copyUriToFile(uri: Uri, dest: File) {
        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Could not open $uri")
    }

    private fun saveBitmap(bitmap: Bitmap, dest: File) {
        dest.outputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
        }
    }

    private companion object {
        /** Fraction of synthetic variants that get a low-severity (rather than default) recipe. */
        const val LOW_SEVERITY_VARIANT_CHANCE = 0.15f
        /** Upper bound of the severity range those low-severity variants are drawn from. */
        const val LOW_SEVERITY_CEILING = 0.15f
    }
}
