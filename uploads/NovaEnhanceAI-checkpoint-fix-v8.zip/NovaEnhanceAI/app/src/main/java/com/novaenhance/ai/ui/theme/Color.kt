package com.novaenhance.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Signature palette: a cool, clear teal stands for what the AI restores
// toward (clarity, sharpness, signal); a warm amber stands for the
// degraded/analog "before" state it's restoring away from. Used
// consistently across the before/after slider, progress indicators, and
// improvement-score accents so the palette itself tells the enhancement
// story rather than being decoration.

val TealPrimaryDark = Color(0xFF4FD1C5)
val TealPrimaryLight = Color(0xFF0F9C8E)

val AmberAccentDark = Color(0xFFE8A855)
val AmberAccentLight = Color(0xFFC9862E)

val GraphiteBackgroundDark = Color(0xFF12151A)
val GraphiteSurfaceDark = Color(0xFF1B1F26)
val GraphiteSurfaceVariantDark = Color(0xFF262B34)

val CloudBackgroundLight = Color(0xFFF7F8FA)
val CloudSurfaceLight = Color(0xFFFFFFFF)
val CloudSurfaceVariantLight = Color(0xFFEDEFF2)

val OnDark = Color(0xFFE7EAEE)
val OnDarkMuted = Color(0xFFA3ACB8)
val OnLight = Color(0xFF1B1F26)
val OnLightMuted = Color(0xFF5A6472)

val ErrorDark = Color(0xFFFF6B6B)
val ErrorLight = Color(0xFFC0392B)

val SuccessDark = Color(0xFF6EE7B7)
val SuccessLight = Color(0xFF1F9D63)
