package com.novaenhance.ai

import android.app.Application
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.di.ServiceLocator
import com.novaenhance.ai.utils.NovaLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

private const val TAG = "NovaEnhanceApplication"

class NovaEnhanceApplication : Application() {

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        val locator = ServiceLocator.get(this)

        appScope.launch {
            try {
                // getOrCreateActiveModel() is idempotent and safe to call
                // eagerly here purely as an optimization (so the Dashboard
                // has something to show the moment it's first drawn,
                // instead of a brief "no model yet" flash) - it's ALSO
                // called lazily by ViewModels the first time a
                // model-requiring action is taken, using the exact same
                // default identity (see ModelRepository.DEFAULT_MODEL_ID),
                // so there's no dependency on this eager call succeeding or
                // even finishing before the app is usable.
                locator.modelRepository.getOrCreateActiveModel()
                NovaLog.i(TAG, "Default model ready: ${ModelRepository.DEFAULT_MODEL_ID}")
            } catch (t: Throwable) {
                // Should essentially never happen: creating a model needs no
                // bundled asset and no external generation step, just
                // in-memory random weight initialization followed by a
                // normal file write. A failure here means something more
                // fundamental is wrong (e.g. out of disk space) - but this
                // still must never crash app startup, and the lazy fallback
                // in ModelRepository.getOrCreateActiveModel() will simply
                // try again the first time a screen actually needs a model.
                NovaLog.e(TAG, "Eager default-model bootstrap failed (will retry lazily on first use)", t)
            }
        }
    }
}
