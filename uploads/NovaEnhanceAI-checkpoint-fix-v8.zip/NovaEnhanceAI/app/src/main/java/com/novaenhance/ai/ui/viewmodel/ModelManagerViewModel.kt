package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.ModelVersionDao
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.ModelVersionEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class ModelManagerUiState(
    val models: List<ModelEntity> = emptyList(),
    val selectedModelId: String? = null,
    val versionsForSelected: List<ModelVersionEntity> = emptyList(),
    val lastExportedFile: File? = null
)

class ModelManagerViewModel(
    private val appContext: Context,
    private val modelDao: ModelDao,
    private val modelVersionDao: ModelVersionDao,
    private val modelRepository: ModelRepository
) : ViewModel() {

    private val selectedModelId = MutableStateFlow<String?>(null)
    private val exportedFile = MutableStateFlow<File?>(null)

    val uiState: StateFlow<ModelManagerUiState> = combine(
        modelDao.observeAll(),
        selectedModelId,
        exportedFile
    ) { models, selectedId, exported -> Triple(models, selectedId ?: models.firstOrNull()?.id, exported) }
        .flatMapLatest { (models, selectedId, exported) ->
            if (selectedId == null) {
                flowOf(ModelManagerUiState(models = models, lastExportedFile = exported))
            } else {
                modelVersionDao.observeForModel(selectedId).map { versions ->
                    ModelManagerUiState(
                        models = models,
                        selectedModelId = selectedId,
                        versionsForSelected = versions,
                        lastExportedFile = exported
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ModelManagerUiState())

    fun selectModel(modelId: String) {
        selectedModelId.value = modelId
    }

    fun switchActive(modelId: String) = viewModelScope.launch { modelRepository.switchActiveModel(modelId) }

    fun renameModel(modelId: String, newName: String) = viewModelScope.launch { modelRepository.renameModel(modelId, newName) }

    fun deleteModel(modelId: String) = viewModelScope.launch { modelRepository.deleteModel(modelId) }

    fun restoreVersion(modelId: String, versionId: Long) =
        viewModelScope.launch { modelRepository.restoreVersion(modelId, versionId) }

    fun deleteVersion(versionId: Long) = viewModelScope.launch { modelRepository.deleteVersion(versionId) }

    fun backupVersion(versionId: Long) = viewModelScope.launch {
        val file = modelRepository.backupVersion(uiState.value.selectedModelId ?: return@launch, versionId)
        exportedFile.value = file
    }

    fun exportVersion(versionId: Long) = viewModelScope.launch {
        exportedFile.value = modelRepository.exportVersion(versionId)
    }

    fun importModel(bundleUri: Uri, displayName: String) = viewModelScope.launch {
        val tempFile = File(appContext.cacheDir, "import_${System.currentTimeMillis()}.novamodel")
        appContext.contentResolver.openInputStream(bundleUri)?.use { input ->
            tempFile.outputStream().use { output -> input.copyTo(output) }
        }
        val modelId = "imported_${UUID.randomUUID().toString().take(8)}"
        modelRepository.importModel(tempFile, modelId, displayName)
        tempFile.delete()
    }
}
