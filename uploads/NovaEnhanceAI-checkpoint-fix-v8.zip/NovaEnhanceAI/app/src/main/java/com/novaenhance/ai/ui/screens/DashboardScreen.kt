package com.novaenhance.ai.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.novaenhance.ai.ui.components.StatCard
import com.novaenhance.ai.ui.viewmodel.DashboardViewModel
import com.novaenhance.ai.ui.viewmodel.NovaViewModelFactory
import java.text.DateFormat
import java.util.Date

@Composable
fun DashboardScreen(
    onNavigateToEnhance: () -> Unit,
    onNavigateToTraining: () -> Unit,
    onNavigateToDataset: () -> Unit,
    onNavigateToModelManager: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val context = LocalContext.current
    val viewModel: DashboardViewModel = viewModel(factory = NovaViewModelFactory(context))
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("NovaEnhance AI") }) }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    text = state.activeModel?.displayName ?: "No model yet",
                    style = MaterialTheme.typography.headlineMedium
                )
            }

            if (state.activeModel == null && !state.isLoading) {
                item {
                    Text(
                        "No AI model is bundled in this build yet, so Enhance/Train/Dataset Manager " +
                            "won't do anything until one is available. The initial model has to be " +
                            "generated once by a Python script (see this project's README) before it " +
                            "can be bundled - it isn't something the app can create on its own. Once " +
                            "you have one, use Model Manager's Import to add it.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            state.activeModel?.let { model ->
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard(
                            label = "Model size",
                            value = formatBytes(model.sizeBytes),
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            label = "Parameters",
                            value = formatParams(model.parameterCount),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard(
                            label = "Training sessions",
                            value = model.trainingSessionCount.toString(),
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            label = "Images learned",
                            value = model.totalImagesLearned.toString(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatCard(
                            label = "Model version",
                            value = "v${model.currentVersionNumber}",
                            modifier = Modifier.weight(1f)
                        )
                        StatCard(
                            label = "Improvement score",
                            value = "${model.improvementScore.toInt()}%",
                            modifier = Modifier.weight(1f),
                            accent = true
                        )
                    }
                }
                item {
                    StatCard(
                        label = "Last training date",
                        value = model.lastTrainedAt?.let { DateFormat.getDateInstance().format(Date(it)) } ?: "Never"
                    )
                }
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onNavigateToEnhance, modifier = Modifier.fillMaxWidth()) { Text("Enhance Image") }
                    Button(onClick = onNavigateToTraining, modifier = Modifier.fillMaxWidth()) { Text("Train AI") }
                    OutlinedButton(onClick = onNavigateToDataset, modifier = Modifier.fillMaxWidth()) { Text("Dataset Manager") }
                    OutlinedButton(onClick = onNavigateToModelManager, modifier = Modifier.fillMaxWidth()) { Text("Model Manager") }
                    OutlinedButton(onClick = onNavigateToSettings, modifier = Modifier.fillMaxWidth()) { Text("Settings") }
                }
            }

            if (state.recentSessions.isNotEmpty()) {
                item { Text("Recent training", style = MaterialTheme.typography.titleMedium) }
                items(state.recentSessions) { session ->
                    Text(
                        "${DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(session.startedAt))} - " +
                            "${session.status} ${if (session.wasPromoted) "(improved)" else ""}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_000_000 -> "%.1f MB".format(bytes / 1_000_000.0)
    bytes >= 1_000 -> "%.1f KB".format(bytes / 1_000.0)
    else -> "$bytes B"
}

private fun formatParams(count: Long): String = when {
    count >= 1_000_000 -> "%.1fM".format(count / 1_000_000.0)
    count >= 1_000 -> "%.1fK".format(count / 1_000.0)
    else -> count.toString()
}
