package com.novaenhance.ai.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.novaenhance.ai.utils.decodeSampledBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Shows a small preview of an image file (a dataset pair's low- or
 * high-quality image, on disk). Decodes a downsampled thumbnail off the
 * main thread rather than the full-resolution file - the whole point of a
 * list of thumbnails is to glance at many pairs at once, so decoding full
 * multi-megapixel bitmaps just to shrink them on screen would be exactly
 * the kind of memory waste this app's tile-based processing elsewhere goes
 * out of its way to avoid.
 */
@Composable
fun ThumbnailImage(
    path: String,
    modifier: Modifier = Modifier,
    size: Dp = 72.dp
) {
    var bitmap by remember(path) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(path) { mutableStateOf(false) }

    LaunchedEffect(path) {
        bitmap = null
        failed = false
        val decoded = withContext(Dispatchers.IO) { decodeSampledBitmap(path, targetSizePx = 216) } // ~3x a 72dp box for hi-dpi screens
        if (decoded == null) failed = true else bitmap = decoded
    }

    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        val current = bitmap
        when {
            current != null -> Image(
                bitmap = current.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.size(size),
                contentScale = ContentScale.Crop
            )
            failed -> { /* leave the plain surfaceVariant background - a broken thumbnail shouldn't look alarming */ }
            else -> CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        }
    }
}

