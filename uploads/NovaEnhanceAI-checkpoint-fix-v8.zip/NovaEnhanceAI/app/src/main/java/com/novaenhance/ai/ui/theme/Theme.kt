package com.novaenhance.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = TealPrimaryDark,
    onPrimary = GraphiteBackgroundDark,
    secondary = AmberAccentDark,
    onSecondary = GraphiteBackgroundDark,
    background = GraphiteBackgroundDark,
    onBackground = OnDark,
    surface = GraphiteSurfaceDark,
    onSurface = OnDark,
    surfaceVariant = GraphiteSurfaceVariantDark,
    onSurfaceVariant = OnDarkMuted,
    error = ErrorDark,
    onError = GraphiteBackgroundDark
)

private val LightColors = lightColorScheme(
    primary = TealPrimaryLight,
    onPrimary = CloudSurfaceLight,
    secondary = AmberAccentLight,
    onSecondary = CloudSurfaceLight,
    background = CloudBackgroundLight,
    onBackground = OnLight,
    surface = CloudSurfaceLight,
    onSurface = OnLight,
    surfaceVariant = CloudSurfaceVariantLight,
    onSurfaceVariant = OnLightMuted,
    error = ErrorLight,
    onError = CloudSurfaceLight
)

/**
 * Deliberately does NOT offer a dynamic-color (Material You wallpaper-based)
 * option - this app's teal/amber restoration-lab identity is a considered
 * design choice (see [Color.kt]), not a placeholder meant to be overridden
 * by whatever wallpaper the user has.
 */
@Composable
fun NovaEnhanceTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = NovaTypography,
        content = content
    )
}
