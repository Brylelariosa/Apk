package com.novaenhance.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.storage.AppSettings
import com.novaenhance.ai.storage.SettingsRepository
import com.novaenhance.ai.storage.ThemePreference
import com.novaenhance.ai.utils.DeviceCapabilities
import com.novaenhance.ai.utils.DiagnosticsReport
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val deviceCapabilities: DeviceCapabilities
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun setTheme(theme: ThemePreference) = viewModelScope.launch { settingsRepository.setTheme(theme) }
    fun setTrainOnlyWhileCharging(enabled: Boolean) = viewModelScope.launch { settingsRepository.setTrainOnlyWhileCharging(enabled) }
    fun setThermalProtectionEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setThermalProtectionEnabled(enabled) }
    fun setLowRamModeEnabled(enabled: Boolean) = viewModelScope.launch { settingsRepository.setLowRamModeEnabled(enabled) }

    /** Plain-text device info + recent activity log, for the user to copy and share when reporting a problem - see [DiagnosticsReport]. */
    fun buildDebugReport(): String = DiagnosticsReport.build(deviceCapabilities.snapshot())
}
