package com.novaenhance.ai.training.trainer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.novaenhance.ai.ai.engine.BitmapSimilarity
import com.novaenhance.ai.ai.engine.EnhancementEngine
import com.novaenhance.ai.ai.engine.EnhancementOptions
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.DatasetPairDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import com.novaenhance.ai.database.entities.TrainingStatus
import com.novaenhance.ai.utils.NovaLog
import com.novaenhance.ai.utils.ThermalGovernor

private const val TAG = "SelfImprovementLoop"
private const val RESCORE_SAMPLE_SIZE = 50

/**
 * Ties the full "Self Improvement Loop" together:
 *
 *     Collect Training Data -> Train -> Evaluate -> Find Weak Areas
 *         -> Prioritize Similar Data -> Improve Again
 *
 * "Collect -> Train -> Evaluate" is [ModelTrainer.runSession] (dataset
 * analysis gate, adaptive planning, the batch loop, and validation-gated
 * promotion). This class adds the last two steps: after a session is
 * promoted, it re-runs the *newly active* model over a sample of the
 * remaining dataset and re-scores each pair's difficulty by how far the
 * model's own current output still is from the target. Pairs the model
 * still struggles with get a HIGHER difficulty score, so the next call to
 * [com.novaenhance.ai.database.dao.DatasetPairDao.getUsablePairsByDifficulty]
 * automatically surfaces them first - "prioritize similar data" without
 * needing a separate content-clustering system, since perceptual
 * difficulty (not just visual similarity) is exactly what should drive
 * priority.
 */
class SelfImprovementOrchestrator(
    private val modelTrainer: ModelTrainer,
    private val modelRepository: ModelRepository,
    private val datasetPairDao: DatasetPairDao,
    private val progressPublisher: TrainingProgressPublisher,
    private val thermalGovernor: ThermalGovernor
) {

    suspend fun runCycle(modelId: String, resumeSessionId: Long?, control: TrainingControlFlow): TrainingSessionEntity {
        val session = modelTrainer.runSession(modelId, resumeSessionId, control)
        if (session.status == TrainingStatus.COMPLETED && session.wasPromoted) {
            runCatching { rescoreWeakAreas(modelId, session.id) }
                .onFailure { NovaLog.w(TAG, "Weak-area rescoring failed (non-fatal, training result is unaffected)", it) }
        }
        return session
    }

    // See ModelValidator's class doc comment for why [thermalGovernor] flows
    // into the EnhancementEngine here rather than this loop skipping/
    // truncating its sample under thermal pressure: pacing keeps the full
    // RESCORE_SAMPLE_SIZE sample intact (and therefore the weak-area
    // priority signal this feeds into DatasetPairDao meaningful), and this
    // pass runs automatically right after a training session's own batch
    // loop and validation pass, so it's exactly the phase most likely to
    // start already warm.
    private suspend fun rescoreWeakAreas(modelId: String, sessionId: Long) {
        // Bounded sample, not the whole dataset - this runs after every
        // promoted session, and re-inferring the entire dataset each time
        // would grow unbounded as it accumulates. Checked before touching
        // the model/engine at all, so a model with nothing left to rescore
        // skips straight past without loading anything.
        val sample = datasetPairDao.getUsablePairs(modelId).shuffled().take(RESCORE_SAMPLE_SIZE)
        if (sample.isEmpty()) return

        val engine = modelRepository.getEngine(modelId)
        val enhancer = EnhancementEngine(engine, thermalGovernor)
        val neutralOptions = EnhancementOptions(strength = 1f, sharpness = 0f, noiseReduction = 0f, colorRestoration = 0f)
        val updated = mutableListOf<DatasetPairEntity>()

        for ((index, pair) in sample.withIndex()) {
            publishRescoringProgress(sessionId, index, sample.size)
            val lowBitmap = decodeBitmap(pair.lowQualityPath) ?: continue
            val targetBitmap = decodeBitmap(pair.highQualityPath)
            if (targetBitmap == null) {
                lowBitmap.recycle()
                continue
            }

            try {
                val enhanced = enhancer.enhance(lowBitmap, neutralOptions)
                val similarity = BitmapSimilarity.quickSimilarity(enhanced, targetBitmap)
                enhanced.recycle()
                // Still far from the target even after the model's own best
                // effort -> a genuine weak area, not just "started out hard."
                updated += pair.copy(difficultyScore = (1f - similarity).coerceIn(0f, 1f))
            } finally {
                lowBitmap.recycle()
                targetBitmap.recycle()
            }
        }
        publishRescoringProgress(sessionId, sample.size, sample.size)

        if (updated.isNotEmpty()) {
            datasetPairDao.updateAll(updated)
            NovaLog.i(TAG, "Re-scored ${updated.size} pairs for $modelId based on current model performance")
        }
    }

    /**
     * This pass runs *after* [ModelTrainer] has already reported its
     * session as COMPLETED, re-inferring up to [RESCORE_SAMPLE_SIZE] full
     * images one at a time - without this, that whole stretch (which can
     * take longer than training itself on a large sample) reported no
     * progress at all, the same "did it freeze?" symptom the session's own
     * checkpoint/validation phases had.
     */
    private fun publishRescoringProgress(sessionId: Long, unitsCompleted: Int, totalUnits: Int) {
        progressPublisher.publish(
            TrainingProgressState(
                sessionId = sessionId,
                phase = TrainingPhase.RESCORING,
                epoch = 0,
                totalEpochs = 1,
                phaseStepIndex = unitsCompleted,
                phaseStepTotal = totalUnits,
                unitsCompleted = unitsCompleted,
                totalUnits = totalUnits,
                latestLoss = null,
                imagesPerSecond = 0f,
                estimatedSecondsRemaining = -1L,
                memoryUsedMb = 0L,
                status = TrainingStatus.RUNNING
            )
        )
    }

    private fun decodeBitmap(path: String): Bitmap? = try {
        BitmapFactory.decodeFile(path)
    } catch (t: Throwable) {
        null
    }
}
