package com.novaenhance.ai.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.ai.model.ModelRepository
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.training.dataset.DatasetManager
import com.novaenhance.ai.workers.DatasetAnalysisWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DatasetUiState(
    val activeModel: ModelEntity? = null,
    val pairs: List<DatasetPairEntity> = emptyList(),
    val totalSizeBytes: Long = 0L,
    val isBusy: Boolean = false,
    val message: String? = null
)

class DatasetViewModel(
    private val appContext: Context,
    private val modelDao: ModelDao,
    private val modelRepository: ModelRepository,
    private val datasetManager: DatasetManager
) : ViewModel() {

    private val busy = MutableStateFlow(false)
    private val message = MutableStateFlow<String?>(null)
    private val sizeBytes = MutableStateFlow(0L)

    val uiState: StateFlow<DatasetUiState> = modelDao.observeActive()
        .flatMapLatest { model ->
            if (model == null) {
                flowOf(DatasetUiState())
            } else {
                refreshSize(model.id)
                combine(datasetManager.observePairs(model.id), busy, message, sizeBytes) { pairs, isBusy, msg, size ->
                    DatasetUiState(activeModel = model, pairs = pairs, totalSizeBytes = size, isBusy = isBusy, message = msg)
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DatasetUiState())

    fun addManualPair(lowUri: Uri, highUri: Uri) = withActiveModel { model ->
        datasetManager.addManualPair(model.id, lowUri, highUri)
        refreshSize(model.id)
    }

    fun addSyntheticPairs(sourceUri: Uri, variantCount: Int = 3) = withActiveModel { model ->
        datasetManager.addSyntheticPairs(model.id, sourceUri, variantCount)
        refreshSize(model.id)
    }

    fun removePair(pair: DatasetPairEntity) = withActiveModel { model ->
        datasetManager.removePair(pair)
        refreshSize(model.id)
    }

    fun importDataset(zipUri: Uri) = withActiveModel { model ->
        val count = datasetManager.importDataset(model.id, zipUri)
        DatasetAnalysisWorker.enqueue(appContext, model.id)
        message.value = "Imported $count pairs - analyzing in the background"
        refreshSize(model.id)
    }

    fun exportDataset(onExported: (java.io.File) -> Unit) = withActiveModel { model ->
        val file = datasetManager.exportDataset(model.id)
        onExported(file)
    }

    fun clearMessage() {
        message.value = null
    }

    /**
     * Resolves the active model via [ModelRepository.getOrCreateActiveModel]
     * - not a plain null-check against [uiState]'s current snapshot - so
     * this can never fail with a "no model" error: unlike this project's
     * earlier TFLite-based design, creating a model needs no external asset
     * or generation step, so there's no legitimate reason a dataset action
     * should ever be blocked by "no model exists yet." Any exception caught
     * here is a genuine, unexpected failure (e.g. a disk I/O problem), not
     * a missing-setup-step case.
     */
    private fun withActiveModel(block: suspend (ModelEntity) -> Unit) {
        viewModelScope.launch {
            busy.value = true
            try {
                val model = modelRepository.getOrCreateActiveModel()
                block(model)
            } catch (t: Throwable) {
                message.value = "That didn't work: ${t.message ?: t::class.simpleName}"
            } finally {
                busy.value = false
            }
        }
    }

    private fun refreshSize(modelId: String) {
        viewModelScope.launch {
            sizeBytes.value = datasetManager.datasetSizeBytes(modelId)
        }
    }
}
