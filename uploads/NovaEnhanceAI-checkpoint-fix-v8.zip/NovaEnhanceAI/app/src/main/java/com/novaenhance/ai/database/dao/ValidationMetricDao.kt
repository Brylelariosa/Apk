package com.novaenhance.ai.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.novaenhance.ai.database.entities.ValidationMetricEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ValidationMetricDao {

    @Query("SELECT * FROM validation_metrics WHERE sessionId = :sessionId")
    fun observeForSession(sessionId: Long): Flow<List<ValidationMetricEntity>>

    @Query("SELECT * FROM validation_metrics WHERE sessionId = :sessionId")
    suspend fun getForSession(sessionId: Long): List<ValidationMetricEntity>

    @Insert
    suspend fun insertAll(metrics: List<ValidationMetricEntity>)
}
