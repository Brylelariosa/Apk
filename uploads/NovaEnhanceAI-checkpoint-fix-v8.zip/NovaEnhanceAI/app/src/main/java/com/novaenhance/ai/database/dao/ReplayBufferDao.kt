package com.novaenhance.ai.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.novaenhance.ai.database.entities.ReplayBufferEntity

@Dao
interface ReplayBufferDao {

    @Query("SELECT * FROM replay_buffer WHERE modelId = :modelId ORDER BY addedAt DESC")
    suspend fun getForModel(modelId: String): List<ReplayBufferEntity>

    @Query("SELECT * FROM replay_buffer WHERE modelId = :modelId ORDER BY RANDOM() LIMIT :count")
    suspend fun getRandomSample(modelId: String, count: Int): List<ReplayBufferEntity>

    @Query("SELECT COUNT(*) FROM replay_buffer WHERE modelId = :modelId")
    suspend fun countForModel(modelId: String): Int

    @Insert
    suspend fun insert(entry: ReplayBufferEntity): Long

    @Update
    suspend fun updateAll(entries: List<ReplayBufferEntity>)

    /** Evicts the lowest-difficulty (least informative) entries once over capacity. */
    @Query(
        """DELETE FROM replay_buffer WHERE id IN (
            SELECT id FROM replay_buffer WHERE modelId = :modelId
            ORDER BY difficultyScore ASC, addedAt ASC LIMIT :count
        )"""
    )
    suspend fun evictLowestDifficulty(modelId: String, count: Int)

    @Query("DELETE FROM replay_buffer WHERE id = :id")
    suspend fun delete(id: Long)
}
