package com.novaenhance.ai.utils

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager

/** Point-in-time snapshot of device conditions relevant to training decisions. */
data class DeviceSnapshot(
    val availableRamMb: Long,
    val totalRamMb: Long,
    val isLowRamDevice: Boolean,
    val isCharging: Boolean,
    val batteryPercent: Int,
    val thermalStatus: ThermalStatus,
    val cpuCoreCount: Int
)

enum class ThermalStatus { NONE, LIGHT, MODERATE, SEVERE, CRITICAL, UNKNOWN }

/**
 * Reads live device state via standard Android system services. Nothing here
 * is cached beyond the lifetime of a single [snapshot] call, since RAM/thermal/
 * charging state can all change mid-training-session and the adaptive
 * controller re-checks periodically (see [com.novaenhance.ai.training.trainer.AdaptiveTrainingController]).
 */
class DeviceCapabilities(private val context: Context) {

    fun snapshot(): DeviceSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val batteryPercent = batteryManager
            ?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val isCharging = batteryManager
            ?.isCharging ?: false

        val thermalStatus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> ThermalStatus.NONE
                PowerManager.THERMAL_STATUS_LIGHT -> ThermalStatus.LIGHT
                PowerManager.THERMAL_STATUS_MODERATE -> ThermalStatus.MODERATE
                PowerManager.THERMAL_STATUS_SEVERE -> ThermalStatus.SEVERE
                PowerManager.THERMAL_STATUS_CRITICAL,
                PowerManager.THERMAL_STATUS_EMERGENCY,
                PowerManager.THERMAL_STATUS_SHUTDOWN -> ThermalStatus.CRITICAL
                else -> ThermalStatus.UNKNOWN
            }
        } else {
            ThermalStatus.UNKNOWN
        }

        return DeviceSnapshot(
            availableRamMb = memInfo.availMem / (1024 * 1024),
            totalRamMb = memInfo.totalMem / (1024 * 1024),
            isLowRamDevice = am.isLowRamDevice,
            isCharging = isCharging,
            batteryPercent = batteryPercent,
            thermalStatus = thermalStatus,
            cpuCoreCount = Runtime.getRuntime().availableProcessors()
        )
    }
}
