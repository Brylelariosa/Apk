package com.novaenhance.ai.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per distinct AI model the user has (General Photo AI, Anime AI,
 * Manga AI, ...). The actual weights live on disk (see [com.novaenhance.ai.storage.AppStorage]);
 * this row + its [ModelVersionEntity] children are the registry/metadata
 * describing what's on disk and how it got there.
 */
@Entity(tableName = "models")
data class ModelEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val description: String,
    val createdAt: Long,
    val currentVersionNumber: Int,
    val parameterCount: Long,
    val sizeBytes: Long,
    val trainingSessionCount: Int,
    val totalImagesLearned: Int,
    val lastTrainedAt: Long?,
    val improvementScore: Float, // rolling aggregate used on the dashboard
    val isActive: Boolean // the model currently selected for Enhance Image
)
