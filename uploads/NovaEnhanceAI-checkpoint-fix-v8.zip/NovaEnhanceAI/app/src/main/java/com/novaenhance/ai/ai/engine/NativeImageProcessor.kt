package com.novaenhance.ai.ai.engine

import android.graphics.Bitmap

/**
 * Thin JNI bridge over the native (`app/src/main/cpp`) image filter library.
 *
 * All tile-based operations work on plain [IntArray] pixel buffers in
 * Android's ARGB_8888 int layout (as produced by [Bitmap.getPixels]), which
 * keeps the JNI surface simple and lets [com.novaenhance.ai.ai.engine.TileProcessor]
 * own all memory/tiling decisions. [resizeBitmapInto] is the one exception -
 * it operates on raw bitmap memory directly for cheap whole-image thumbnails
 * where an extra IntArray round trip isn't worth it.
 *
 * These are classic (non-learned) filters: they back the manual enhancement
 * sliders (sharpness/noise-reduction controls a user can drag) and the
 * synthetic dataset degradation generator. The *learned* part of the pipeline
 * (the part that actually improves from training) lives in [NovaModelEngine].
 */
object NativeImageProcessor {

    init {
        System.loadLibrary("novaenhance_native")
    }

    fun gaussianBlur(pixels: IntArray, width: Int, height: Int, sigma: Float): IntArray =
        nativeGaussianBlur(pixels, width, height, sigma)

    fun unsharpMask(pixels: IntArray, width: Int, height: Int, sigma: Float, amount: Float): IntArray =
        nativeUnsharpMask(pixels, width, height, sigma, amount)

    fun denoiseBilateral(
        pixels: IntArray,
        width: Int,
        height: Int,
        spatialSigma: Float,
        rangeSigma: Float
    ): IntArray = nativeDenoiseBilateral(pixels, width, height, spatialSigma, rangeSigma)

    fun resizeBilinear(
        pixels: IntArray,
        srcWidth: Int,
        srcHeight: Int,
        dstWidth: Int,
        dstHeight: Int
    ): IntArray = nativeResizeBilinear(pixels, srcWidth, srcHeight, dstWidth, dstHeight)

    /** Fast proxy similarity in [0,1]; used by the validator, not a full SSIM. */
    fun quickSimilarityScore(a: IntArray, b: IntArray, width: Int, height: Int): Float =
        nativeQuickSimilarityScore(a, b, width, height)

    fun addGaussianNoise(pixels: IntArray, width: Int, height: Int, amount: Float, seed: Int): IntArray =
        nativeAddGaussianNoise(pixels, width, height, amount, seed)

    fun simulateJpegArtifacts(pixels: IntArray, width: Int, height: Int, qualityPercent: Int): IntArray =
        nativeSimulateJpegArtifacts(pixels, width, height, qualityPercent)

    fun motionBlur(pixels: IntArray, width: Int, height: Int, angleDegrees: Float, lengthPx: Int): IntArray =
        nativeMotionBlur(pixels, width, height, angleDegrees, lengthPx)

    fun colorFade(pixels: IntArray, width: Int, height: Int, fadeAmount: Float): IntArray =
        nativeColorFade(pixels, width, height, fadeAmount)

    /** Resizes [src] directly into [dst] (must be pre-allocated at the target size). */
    fun resizeBitmapInto(src: Bitmap, dst: Bitmap): Boolean = nativeResizeBitmapInto(src, dst)

    // --- JNI declarations, implemented in native-lib.cpp ---
    private external fun nativeGaussianBlur(pixels: IntArray, width: Int, height: Int, sigma: Float): IntArray
    private external fun nativeUnsharpMask(
        pixels: IntArray, width: Int, height: Int, sigma: Float, amount: Float
    ): IntArray
    private external fun nativeDenoiseBilateral(
        pixels: IntArray, width: Int, height: Int, spatialSigma: Float, rangeSigma: Float
    ): IntArray
    private external fun nativeResizeBilinear(
        pixels: IntArray, srcWidth: Int, srcHeight: Int, dstWidth: Int, dstHeight: Int
    ): IntArray
    private external fun nativeQuickSimilarityScore(a: IntArray, b: IntArray, width: Int, height: Int): Float
    private external fun nativeAddGaussianNoise(
        pixels: IntArray, width: Int, height: Int, amount: Float, seed: Int
    ): IntArray
    private external fun nativeSimulateJpegArtifacts(
        pixels: IntArray, width: Int, height: Int, qualityPercent: Int
    ): IntArray
    private external fun nativeMotionBlur(
        pixels: IntArray, width: Int, height: Int, angleDegrees: Float, lengthPx: Int
    ): IntArray
    private external fun nativeColorFade(pixels: IntArray, width: Int, height: Int, fadeAmount: Float): IntArray
    private external fun nativeResizeBitmapInto(src: Bitmap, dst: Bitmap): Boolean
}
