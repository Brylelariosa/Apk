package com.novaenhance.ai.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.novaenhance.ai.database.dao.ModelDao
import com.novaenhance.ai.database.dao.TrainingSessionDao
import com.novaenhance.ai.database.entities.ModelEntity
import com.novaenhance.ai.database.entities.TrainingSessionEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

data class DashboardUiState(
    val activeModel: ModelEntity? = null,
    val recentSessions: List<TrainingSessionEntity> = emptyList(),
    val isLoading: Boolean = true
)

class DashboardViewModel(
    modelDao: ModelDao,
    trainingSessionDao: TrainingSessionDao
) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = modelDao.observeActive()
        .flatMapLatest { model ->
            if (model == null) {
                flowOf(DashboardUiState(activeModel = null, isLoading = false))
            } else {
                trainingSessionDao.observeForModel(model.id).map { sessions ->
                    DashboardUiState(activeModel = model, recentSessions = sessions.take(5), isLoading = false)
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())
}
