package com.novaenhance.ai.utils

import android.util.Log
import com.novaenhance.ai.BuildConfig
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MAX_HISTORY_LINES = 300

/**
 * Thin wrapper around [android.util.Log] that no-ops verbose/debug logs in
 * release builds. Kept intentionally tiny - this is not a logging framework,
 * just a seam so we're not sprinkling `if (BuildConfig.DEBUG)` everywhere.
 *
 * Also keeps the last [MAX_HISTORY_LINES] lines (every level, including
 * debug, regardless of build type) in memory so [DiagnosticsReport] can
 * include real recent activity - tile-processing/dataset-analysis timings,
 * training failures, etc. - in a report the user can copy out of Settings.
 * This is purely additive: every existing `NovaLog.x(...)` call site is
 * unaffected, and nothing here is persisted or leaves the device except
 * when the user explicitly taps "Copy debug info."
 */
object NovaLog {
    private const val GLOBAL_TAG = "NovaEnhance"
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private val history = ArrayDeque<String>()

    private fun record(level: Char, tag: String, message: String, throwable: Throwable?) {
        synchronized(history) {
            if (history.size >= MAX_HISTORY_LINES) history.removeFirst()
            val timestamp = timeFormat.format(Date(System.currentTimeMillis()))
            val throwableSuffix = throwable?.let { " - ${it::class.simpleName}: ${it.message}" } ?: ""
            history.addLast("$timestamp $level/$tag: $message$throwableSuffix")
        }
    }

    /** Recent log lines, oldest first, for display or export - see [DiagnosticsReport]. */
    fun recentHistory(): List<String> = synchronized(history) { history.toList() }

    fun d(tag: String, message: String) {
        record('D', tag, message, null)
        if (BuildConfig.DEBUG) Log.d("$GLOBAL_TAG:$tag", message)
    }

    fun i(tag: String, message: String) {
        record('I', tag, message, null)
        Log.i("$GLOBAL_TAG:$tag", message)
    }

    fun w(tag: String, message: String, throwable: Throwable? = null) {
        record('W', tag, message, throwable)
        Log.w("$GLOBAL_TAG:$tag", message, throwable)
    }

    fun e(tag: String, message: String, throwable: Throwable? = null) {
        record('E', tag, message, throwable)
        Log.e("$GLOBAL_TAG:$tag", message, throwable)
    }
}
