package com.novaenhance.ai.training.trainer

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.novaenhance.ai.ai.engine.EnhancementEngine
import com.novaenhance.ai.ai.engine.EnhancementOptions
import com.novaenhance.ai.ai.engine.NovaModelEngine
import com.novaenhance.ai.database.entities.DatasetPairEntity
import com.novaenhance.ai.database.entities.ValidationMetricEntity
import com.novaenhance.ai.database.entities.ValidationMetricType
import com.novaenhance.ai.utils.ImageMetrics
import com.novaenhance.ai.utils.ThermalGovernor
import kotlin.math.abs

/**
 * "Automatic Model Validation": runs the OLD and NEW model over the same
 * held-out validation pairs and scores four dimensions. A training result
 * is only promoted (see [ModelTrainer]) if the aggregate shows genuine
 * improvement - otherwise the new checkpoint is discarded and the old
 * model stays active, so training can never make the app's actual
 * behavior worse.
 *
 * Each metric is a deliberately simple, explainable proxy rather than a
 * research-grade image quality model (no-reference IQA is itself an open
 * research problem) - see the per-metric comments for exactly what's being
 * approximated and why.
 *
 * [thermalGovernor] flows into every [EnhancementEngine] this creates, so
 * the tile-based enhance passes below pace themselves under thermal
 * pressure exactly like a manual "Enhance" tap does (see
 * [com.novaenhance.ai.ai.engine.TileProcessor]) - this used to run
 * completely unthrottled, right after a training session's own batch loop
 * had potentially already warmed the device up. Deliberately NOT a reason
 * to skip any validation pair, though: pacing preserves the full held-out
 * sample (and therefore the statistical soundness of the promotion
 * decision this class makes); only speed changes.
 */
class ModelValidator(private val thermalGovernor: ThermalGovernor) {

    data class ValidationResult(
        val metrics: List<ValidationMetricEntity>,
        val overallImproved: Boolean
    )

    /**
     * [validationPairs] should be pairs NOT used in this training session
     * (a held-out split) so the comparison reflects generalization, not
     * memorization of the exact training batch.
     */
    suspend fun validate(
        oldEngine: NovaModelEngine?,
        newEngine: NovaModelEngine,
        validationPairs: List<DatasetPairEntity>,
        sessionId: Long,
        onProgress: (passesCompleted: Int) -> Unit = {}
    ): ValidationResult {
        if (validationPairs.isEmpty()) {
            // Nothing to validate against (e.g. a tiny first dataset with no
            // spare pairs to hold out) - treat as a pass so the very first
            // training session isn't permanently blocked. Subsequent
            // sessions will have history to validate against.
            return ValidationResult(emptyList(), overallImproved = true)
        }

        val newEnhancer = EnhancementEngine(newEngine, thermalGovernor)
        val oldEnhancer = oldEngine?.let { EnhancementEngine(it, thermalGovernor) }

        val detailBefore = mutableListOf<Float>()
        val detailAfter = mutableListOf<Float>()
        val sharpBefore = mutableListOf<Float>()
        val sharpAfter = mutableListOf<Float>()
        val noiseBefore = mutableListOf<Float>()
        val noiseAfter = mutableListOf<Float>()
        val artifactBefore = mutableListOf<Float>()
        val artifactAfter = mutableListOf<Float>()

        val neutralOptions = EnhancementOptions(strength = 1f, sharpness = 0f, noiseReduction = 0f, colorRestoration = 0f)
        var passesCompleted = 0

        for (pair in validationPairs) {
            val lowBitmap = decode(pair.lowQualityPath) ?: continue
            val targetBitmap = decode(pair.highQualityPath) ?: continue

            try {
                val newResult = newEnhancer.enhance(lowBitmap, neutralOptions)
                onProgress(++passesCompleted)
                val oldResult = oldEnhancer?.enhance(lowBitmap, neutralOptions)
                if (oldResult != null) onProgress(++passesCompleted)

                detailAfter += normalizedPsnr(newResult, targetBitmap)
                if (oldResult != null) detailBefore += normalizedPsnr(oldResult, targetBitmap)

                sharpAfter += sharpnessMatchScore(newResult, targetBitmap)
                if (oldResult != null) sharpBefore += sharpnessMatchScore(oldResult, targetBitmap)

                noiseAfter += 1f - relativeNoiseLevel(newResult)
                noiseBefore += 1f - relativeNoiseLevel(lowBitmap)

                artifactAfter += 1f - blockiness(newResult)
                artifactBefore += 1f - blockiness(lowBitmap)

                newResult.recycle()
                oldResult?.recycle()
            } finally {
                lowBitmap.recycle()
                targetBitmap.recycle()
            }
        }

        val now = System.currentTimeMillis()
        val metrics = mutableListOf<ValidationMetricEntity>()

        fun addMetric(type: ValidationMetricType, before: List<Float>, after: List<Float>) {
            if (after.isEmpty()) return
            val beforeAvg = if (before.isNotEmpty()) before.average().toFloat() else after.average().toFloat()
            metrics += ValidationMetricEntity(
                sessionId = sessionId,
                metricType = type,
                scoreBeforeTraining = beforeAvg,
                scoreAfterTraining = after.average().toFloat(),
                recordedAt = now
            )
        }

        addMetric(ValidationMetricType.DETAIL_RECOVERY, detailBefore, detailAfter)
        addMetric(ValidationMetricType.SHARPNESS_IMPROVEMENT, sharpBefore, sharpAfter)
        addMetric(ValidationMetricType.NOISE_REDUCTION, noiseBefore, noiseAfter)
        addMetric(ValidationMetricType.ARTIFACT_REMOVAL, artifactBefore, artifactAfter)

        // Require the AVERAGE across all four dimensions to improve, rather
        // than every single one - a training session that meaningfully
        // improves detail/sharpness/artifacts at a tiny noise-metric cost
        // (a common, acceptable trade-off in restoration models) shouldn't
        // be thrown away.
        val overallImproved = metrics.isNotEmpty() && metrics.map { it.delta }.average() > 0.0

        return ValidationResult(metrics, overallImproved)
    }

    private fun decode(path: String): Bitmap? = try {
        BitmapFactory.decodeFile(path)
    } catch (t: Throwable) {
        null
    }

    /** PSNR against the ground-truth target, normalized to ~0-1 (50dB is treated as effectively perfect). */
    private fun normalizedPsnr(enhanced: Bitmap, target: Bitmap): Float {
        val resizedTarget = if (enhanced.width != target.width || enhanced.height != target.height) {
            Bitmap.createScaledBitmap(target, enhanced.width, enhanced.height, true)
        } else target
        val psnr = ImageMetrics.psnr(enhanced, resizedTarget)
        if (resizedTarget !== target) resizedTarget.recycle()
        return (psnr / 50.0).coerceIn(0.0, 1.0).toFloat()
    }

    /** How close the enhanced image's sharpness is to the target's (over- or under-sharpening both score lower). */
    private fun sharpnessMatchScore(enhanced: Bitmap, target: Bitmap): Float {
        val enhancedSharpness = ImageMetrics.sharpnessScore(enhanced)
        val targetSharpness = ImageMetrics.sharpnessScore(target).coerceAtLeast(1.0)
        val ratio = enhancedSharpness / targetSharpness
        return (1.0 - abs(1.0 - ratio)).coerceIn(0.0, 1.0).toFloat()
    }

    /**
     * Noise proxy: mean absolute difference between an image and a mildly
     * blurred copy of itself, relative to its own sharpness. This conflates
     * "noise" with "fine detail" to some degree (a genuinely detailed sharp
     * photo also has high high-frequency energy) - it's a deliberately
     * simple, fast, on-device-feasible proxy, not a true noise estimator.
     */
    private fun relativeNoiseLevel(bitmap: Bitmap): Float {
        val sample = Bitmap.createScaledBitmap(bitmap, 128.coerceAtMost(bitmap.width), 128.coerceAtMost(bitmap.height), true)
        val w = sample.width
        val h = sample.height
        val pixels = IntArray(w * h)
        sample.getPixels(pixels, 0, w, 0, 0, w, h)
        val blurred = com.novaenhance.ai.ai.engine.NativeImageProcessor.gaussianBlur(pixels, w, h, 1.0f)

        var sumAbsDiff = 0.0
        for (i in pixels.indices) {
            val lumaOrig = luma(pixels[i])
            val lumaBlur = luma(blurred[i])
            sumAbsDiff += abs(lumaOrig - lumaBlur)
        }
        if (sample !== bitmap) sample.recycle()
        val meanDiff = sumAbsDiff / pixels.size
        return (meanDiff / 40.0).coerceIn(0.0, 1.0).toFloat() // 40 chosen empirically as a "very noisy" ceiling
    }

    /** Blockiness proxy: average gradient at 8px block boundaries vs. within blocks. Higher = more JPEG-style blocking. */
    private fun blockiness(bitmap: Bitmap): Float {
        val sample = Bitmap.createScaledBitmap(bitmap, 128.coerceAtMost(bitmap.width), 128.coerceAtMost(bitmap.height), true)
        val w = sample.width
        val h = sample.height
        val pixels = IntArray(w * h)
        sample.getPixels(pixels, 0, w, 0, 0, w, h)

        var boundaryGradSum = 0.0
        var boundaryCount = 0
        var interiorGradSum = 0.0
        var interiorCount = 0

        for (y in 0 until h) {
            for (x in 1 until w) {
                val grad = abs(luma(pixels[y * w + x]) - luma(pixels[y * w + x - 1]))
                if (x % 8 == 0) {
                    boundaryGradSum += grad; boundaryCount++
                } else {
                    interiorGradSum += grad; interiorCount++
                }
            }
        }
        if (sample !== bitmap) sample.recycle()
        if (boundaryCount == 0 || interiorCount == 0) return 0f
        val boundaryAvg = boundaryGradSum / boundaryCount
        val interiorAvg = interiorGradSum / interiorCount
        // Ratio > 1 means block edges are sharper than the surrounding
        // texture, i.e. visible blocking; normalize to 0-1 with 3x as "severe."
        val ratio = (boundaryAvg / (interiorAvg + 1.0)).coerceAtLeast(1.0)
        return ((ratio - 1.0) / 2.0).coerceIn(0.0, 1.0).toFloat()
    }

    private fun luma(pixel: Int): Int {
        val r = (pixel shr 16) and 0xFF
        val g = (pixel shr 8) and 0xFF
        val b = pixel and 0xFF
        return (r * 299 + g * 587 + b * 114) / 1000
    }
}
