package com.novaenhance.ai.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * A single saved checkpoint in a model's version history
 * (v1 -> train -> v2 -> train -> v3, ...). A row is only ever created here
 * for a version that PASSED [com.novaenhance.ai.training.trainer.ModelValidator]
 * validation and was promoted - a rejected training attempt (the model got
 * worse) never becomes a version, since there'd be nothing useful about
 * letting a user "restore" or "compare" to a checkpoint known to be worse
 * than what's active. Rejected attempts are still recorded, just on
 * [TrainingSessionEntity] (`wasPromoted = false`, `failureReason`) instead,
 * which is where "what did I try and why didn't it stick" belongs.
 * `isPromoted` here is always true; it's kept (rather than removed) so a
 * query joining through training sessions doesn't need special-casing.
 *
 * Each version is one self-contained `weightsFilePath` file (see
 * [com.novaenhance.ai.ai.engine.NovaModelEngine]'s save/restore format) -
 * unlike the project's earlier TFLite-based design, there's no separate
 * "architecture" file shared across versions plus per-version checkpoint
 * shards to juggle. The network architecture itself is fixed at compile
 * time (`app/src/main/cpp/nn/network.h`), so a version is simply its
 * weights + Adam optimizer state.
 */
@Entity(
    tableName = "model_versions",
    foreignKeys = [
        ForeignKey(
            entity = ModelEntity::class,
            parentColumns = ["id"],
            childColumns = ["modelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("modelId")]
)
data class ModelVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val modelId: String,
    val versionNumber: Int,
    val weightsFilePath: String,
    val sizeBytes: Long,
    val parameterCount: Long,
    val createdAt: Long,
    val trainingSessionId: Long?,
    val validationScore: Float,
    val isPromoted: Boolean, // false = training attempt that failed validation and was discarded from "active" but kept for history
    val isActive: Boolean,
    val notes: String
)
