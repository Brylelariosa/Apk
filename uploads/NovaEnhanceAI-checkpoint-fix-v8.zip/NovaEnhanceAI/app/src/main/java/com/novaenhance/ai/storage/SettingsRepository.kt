package com.novaenhance.ai.storage

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "novaenhance_settings")

enum class ThemePreference { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val theme: ThemePreference = ThemePreference.SYSTEM,
    val trainOnlyWhileCharging: Boolean = false,
    val thermalProtectionEnabled: Boolean = true,
    val lowRamModeEnabled: Boolean = false
)

/** Backs the Settings screen. All reads are a [Flow] so the screen recomposes live as values change. */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val TRAIN_ONLY_WHILE_CHARGING = booleanPreferencesKey("train_only_while_charging")
        val THERMAL_PROTECTION = booleanPreferencesKey("thermal_protection_enabled")
        val LOW_RAM_MODE = booleanPreferencesKey("low_ram_mode_enabled")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            theme = prefs[Keys.THEME]?.let { runCatching { ThemePreference.valueOf(it) }.getOrNull() } ?: ThemePreference.SYSTEM,
            trainOnlyWhileCharging = prefs[Keys.TRAIN_ONLY_WHILE_CHARGING] ?: false,
            thermalProtectionEnabled = prefs[Keys.THERMAL_PROTECTION] ?: true,
            lowRamModeEnabled = prefs[Keys.LOW_RAM_MODE] ?: false
        )
    }

    suspend fun setTheme(theme: ThemePreference) {
        context.dataStore.edit { it[Keys.THEME] = theme.name }
    }

    suspend fun setTrainOnlyWhileCharging(enabled: Boolean) {
        context.dataStore.edit { it[Keys.TRAIN_ONLY_WHILE_CHARGING] = enabled }
    }

    suspend fun setThermalProtectionEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.THERMAL_PROTECTION] = enabled }
    }

    suspend fun setLowRamModeEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.LOW_RAM_MODE] = enabled }
    }
}
