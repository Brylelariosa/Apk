package com.novaenhance.ai.ui.navigation

/** The six required screens, as a sealed type so every navigation call site is exhaustive-checkable. */
sealed class NovaDestination(val route: String) {
    data object Dashboard : NovaDestination("dashboard")
    data object Enhance : NovaDestination("enhance")
    data object Training : NovaDestination("training")
    data object DatasetManager : NovaDestination("dataset_manager")
    data object ModelManager : NovaDestination("model_manager")
    data object Settings : NovaDestination("settings")
}
