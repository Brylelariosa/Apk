package com.novaenhance.ai.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class TrainingStatus {
    RUNNING, PAUSED, COMPLETED, CANCELLED, FAILED
}

/**
 * One row per training run. This is also the crash-recovery record: if the
 * process dies mid-session, [com.novaenhance.ai.training.trainer.ModelTrainer]
 * finds the most recent row with status == RUNNING on next app start and
 * offers to resume from `epochsCompleted` / the last saved checkpoint rather
 * than silently losing progress.
 */
@Entity(
    tableName = "training_sessions",
    foreignKeys = [
        ForeignKey(
            entity = ModelEntity::class,
            parentColumns = ["id"],
            childColumns = ["modelId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("modelId")]
)
data class TrainingSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val modelId: String,
    val startedAt: Long,
    val completedAt: Long? = null,
    val status: TrainingStatus,

    // Plan decided by the adaptive controller at session start (see
    // AdaptiveTrainingController) - recorded so training history shows *why*
    // a given session behaved the way it did, not just the outcome.
    val plannedEpochs: Int,
    val epochsCompleted: Int = 0,
    val batchSize: Int,
    val learningRate: Float,
    val replayFraction: Float,

    val datasetPairCount: Int,
    val initialLoss: Float? = null,
    val finalLoss: Float? = null,

    val deviceRamMbAtStart: Long,
    val wasThrottledByThermal: Boolean = false,

    val resultModelVersionId: Long? = null,
    val wasPromoted: Boolean = false, // true only if ModelValidator approved the result
    val failureReason: String? = null
)
