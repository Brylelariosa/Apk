package com.novaenhance.ai.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.novaenhance.ai.database.entities.ModelVersionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ModelVersionDao {

    @Query("SELECT * FROM model_versions WHERE modelId = :modelId ORDER BY versionNumber DESC")
    fun observeForModel(modelId: String): Flow<List<ModelVersionEntity>>

    @Query("SELECT * FROM model_versions WHERE modelId = :modelId AND isActive = 1 LIMIT 1")
    suspend fun getActiveVersion(modelId: String): ModelVersionEntity?

    @Query("SELECT * FROM model_versions WHERE id = :versionId")
    suspend fun getById(versionId: Long): ModelVersionEntity?

    @Query("SELECT MAX(versionNumber) FROM model_versions WHERE modelId = :modelId")
    suspend fun getLatestVersionNumber(modelId: String): Int?

    @Insert
    suspend fun insert(version: ModelVersionEntity): Long

    @Update
    suspend fun update(version: ModelVersionEntity)

    @Query("UPDATE model_versions SET isActive = 0 WHERE modelId = :modelId")
    suspend fun deactivateAllForModel(modelId: String)

    @Query("UPDATE model_versions SET isActive = 1 WHERE id = :versionId")
    suspend fun activate(versionId: Long)

    @Query("DELETE FROM model_versions WHERE id = :versionId AND isActive = 0")
    suspend fun deleteIfInactive(versionId: Long): Int
}
