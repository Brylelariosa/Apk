package com.novaenhance.ai.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ImageMetricsTest {

    @Test
    fun `hammingDistance is zero for identical hashes`() {
        assertEquals(0, ImageMetrics.hammingDistance(0b10110101L, 0b10110101L))
    }

    @Test
    fun `hammingDistance counts every differing bit`() {
        // 0b0000 vs 0b1111 -> 4 bits differ
        assertEquals(4, ImageMetrics.hammingDistance(0b0000L, 0b1111L))
        // Single bit flip -> distance of 1
        assertEquals(1, ImageMetrics.hammingDistance(0b1000L, 0b0000L))
    }

    @Test
    fun `hammingDistance is symmetric`() {
        val a = 0x1F2E3D4C5B6A7988L
        val b = 0x0000000000000001L
        assertEquals(ImageMetrics.hammingDistance(a, b), ImageMetrics.hammingDistance(b, a))
    }

    @Test
    fun `normalizeQuality maps zero sharpness to zero quality`() {
        assertEquals(0f, ImageMetrics.normalizeQuality(0.0), 0.0001f)
    }

    @Test
    fun `normalizeQuality is monotonically increasing and bounded under 1`() {
        val low = ImageMetrics.normalizeQuality(50.0)
        val mid = ImageMetrics.normalizeQuality(400.0)
        val high = ImageMetrics.normalizeQuality(5000.0)

        assertTrue(low < mid)
        assertTrue(mid < high)
        assertTrue(high < 1f) // asymptotic, never reaches exactly 1
    }

    @Test
    fun `normalizeQuality clamps negative input to zero`() {
        assertEquals(0f, ImageMetrics.normalizeQuality(-100.0), 0.0001f)
    }
}
