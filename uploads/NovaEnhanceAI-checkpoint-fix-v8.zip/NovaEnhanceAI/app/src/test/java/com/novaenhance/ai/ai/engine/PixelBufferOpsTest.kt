package com.novaenhance.ai.ai.engine

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Test

class PixelBufferOpsTest {

    @Test
    fun `padByReplication returns same reference when already target size`() {
        val pixels = IntArray(16) { it }
        val result = PixelBufferOps.padByReplication(pixels, 4, 4, 4)
        assertSame("no-op path should avoid allocating a new array", pixels, result)
    }

    @Test
    fun `padByReplication replicates edge pixels into the padded region`() {
        // 2x2 source: [ [1,2], [3,4] ], padded to 4x4 should replicate the
        // last row/column outward rather than leaving zeros.
        val pixels = intArrayOf(1, 2, 3, 4)
        val padded = PixelBufferOps.padByReplication(pixels, 2, 2, 4)

        assertEquals(16, padded.size)
        // Row 0: 1,2,2,2 ; Row 1: 3,4,4,4 ; Row 2 and 3 replicate row 1.
        assertArrayEquals(
            intArrayOf(
                1, 2, 2, 2,
                3, 4, 4, 4,
                3, 4, 4, 4,
                3, 4, 4, 4
            ),
            padded
        )
    }

    @Test
    fun `cropTopLeft returns same reference when already requested size`() {
        val pixels = IntArray(9) { it }
        val result = PixelBufferOps.cropTopLeft(pixels, 3, 3, 3)
        assertSame(pixels, result)
    }

    @Test
    fun `cropTopLeft extracts the top-left region correctly`() {
        // 4x4 source, crop to top-left 2x2.
        val pixels = intArrayOf(
            1, 2, 3, 4,
            5, 6, 7, 8,
            9, 10, 11, 12,
            13, 14, 15, 16
        )
        val cropped = PixelBufferOps.cropTopLeft(pixels, 4, 2, 2)
        assertArrayEquals(intArrayOf(1, 2, 5, 6), cropped)
    }

    @Test
    fun `pad then crop round-trips the original content for the valid region`() {
        val original = intArrayOf(10, 20, 30, 40, 50, 60) // 3x2
        val padded = PixelBufferOps.padByReplication(original, 3, 2, 6)
        val cropped = PixelBufferOps.cropTopLeft(padded, 6, 3, 2)
        assertArrayEquals(original, cropped)
    }
}
