package com.novaenhance.ai.training.checkpoint

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files

class CheckpointManagerTest {

    private lateinit var tempDir: File
    private lateinit var manager: CheckpointManager

    @Before
    fun setUp() {
        tempDir = Files.createTempDirectory("nova_checkpoint_test").toFile()
        manager = CheckpointManager()
    }

    @Test
    fun `exportBundle then importBundle round-trips the weights file and metadata exactly`() {
        val weights = File(tempDir, "v5.weights").apply { writeBytes(byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)) }
        val metadata = File(tempDir, "v5.json").apply { writeText("""{"modelName":"Test","parameterCount":20259,"versionNumber":5}""") }

        val bundleZip = File(tempDir, "export.novamodel")
        manager.exportBundle(weights, metadata, bundleZip)
        assertTrue(bundleZip.exists())

        val destDir = File(tempDir, "imported")
        val imported = manager.importBundle(bundleZip, destDir, versionNumber = 5)

        assertTrue(imported.weightsFile.exists())
        assertEquals("v5.weights", imported.weightsFile.name)
        assertArrayEquals(byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8), imported.weightsFile.readBytes())
        assertEquals("""{"modelName":"Test","parameterCount":20259,"versionNumber":5}""", imported.metadataFile.readText())
    }

    @Test
    fun `importBundle names the restored files after the destination version number, not the original`() {
        val weights = File(tempDir, "v1.weights").apply { writeBytes(byteArrayOf(9, 9, 9)) }
        val metadata = File(tempDir, "v1.json").apply { writeText("{}") }

        val bundleZip = File(tempDir, "export_v1.novamodel")
        manager.exportBundle(weights, metadata, bundleZip)

        // Import as a DIFFERENT version number than it was exported as (e.g. importing
        // someone else's model as your own model's v1, regardless of what they called it).
        val imported = manager.importBundle(bundleZip, File(tempDir, "imported2"), versionNumber = 7)

        assertEquals("v7.weights", imported.weightsFile.name)
        assertEquals("v7.json", imported.metadataFile.name)
    }

    @Test
    fun `exportBundle produces a real, non-empty zip file`() {
        val weights = File(tempDir, "v1.weights").apply { writeBytes(ByteArray(100) { it.toByte() }) }
        val metadata = File(tempDir, "v1.json").apply { writeText("{}") }

        val bundleZip = File(tempDir, "export.novamodel")
        manager.exportBundle(weights, metadata, bundleZip)

        assertTrue(bundleZip.exists())
        assertTrue(bundleZip.length() > 0)
    }
}
