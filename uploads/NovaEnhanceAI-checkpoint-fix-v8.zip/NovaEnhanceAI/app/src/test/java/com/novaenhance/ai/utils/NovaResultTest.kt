package com.novaenhance.ai.utils

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NovaResultTest {

    @Test
    fun `of wraps a successful computation in Success`() {
        val result = NovaResult.of { 2 + 2 }
        assertTrue(result is NovaResult.Success)
        assertEquals(4, (result as NovaResult.Success).value)
    }

    @Test
    fun `of catches a thrown exception into Error`() {
        val result = NovaResult.of { throw IllegalStateException("boom") }
        assertTrue(result is NovaResult.Error)
        assertEquals("boom", (result as NovaResult.Error).message)
    }

    @Test
    fun `onSuccess runs only for Success and returns the same instance for chaining`() {
        var observed = 0
        val result: NovaResult<Int> = NovaResult.Success(7)
        val chained = result.onSuccess { observed = it }

        assertEquals(7, observed)
        assertEquals(result, chained)
    }

    @Test
    fun `onError does not run for a Success result`() {
        var called = false
        val result: NovaResult<Int> = NovaResult.Success(1)
        result.onError { _, _ -> called = true }

        assertTrue(!called)
    }

    @Test
    fun `onSuccess does not run for an Error result`() {
        var called = false
        val result: NovaResult<Int> = NovaResult.Error("failed")
        result.onSuccess { called = true }

        assertTrue(!called)
    }
}
