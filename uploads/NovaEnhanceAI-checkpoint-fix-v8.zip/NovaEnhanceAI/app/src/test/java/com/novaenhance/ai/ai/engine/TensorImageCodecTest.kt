package com.novaenhance.ai.ai.engine

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class TensorImageCodecTest {

    @Test
    fun `encodeSingle then decodeSingle round-trips an exact ARGB tile`() {
        val size = 2
        val pixels = intArrayOf(
            argb(255, 10, 20, 30),
            argb(255, 40, 50, 60),
            argb(255, 70, 80, 90),
            argb(255, 100, 110, 120)
        )

        val encoded = TensorImageCodec.encodeSingle(pixels, size)
        val decoded = TensorImageCodec.decodeSingle(encoded, size)

        // Alpha is always forced to 0xFF by the codec (the model has no
        // concept of alpha), so compare RGB channels rather than full ARGB.
        for (i in pixels.indices) {
            assertEquals("red channel mismatch at $i", channel(pixels[i], 16), channel(decoded[i], 16))
            assertEquals("green channel mismatch at $i", channel(pixels[i], 8), channel(decoded[i], 8))
            assertEquals("blue channel mismatch at $i", channel(pixels[i], 0), channel(decoded[i], 0))
        }
    }

    @Test
    fun `encodeBatch produces an array sized for every tile in the batch`() {
        val size = 4
        val tile = IntArray(size * size) { argb(255, it, it, it) }
        val batch = listOf(tile, tile, tile)

        val encoded = TensorImageCodec.encodeBatch(batch, size)

        // size*size pixels * 3 channels * batch size
        assertEquals(size * size * 3 * batch.size, encoded.size)
    }

    @Test
    fun `decodeSingle rounds rather than truncates near half-integer float values`() {
        // A raw model-style output array (not produced by encodeSingle) at
        // a value that would truncate to a different integer than it rounds
        // to - regression test for the darkening-bias fix.
        val size = 1
        val justUnderHalfLevel = 127.9999f / 255f
        val floats = floatArrayOf(justUnderHalfLevel, justUnderHalfLevel, justUnderHalfLevel)

        val decoded = TensorImageCodec.decodeSingle(floats, size)
        assertEquals(128, channel(decoded[0], 16))
    }

    private fun argb(a: Int, r: Int, g: Int, b: Int): Int =
        (a shl 24) or (r shl 16) or (g shl 8) or b

    private fun channel(pixel: Int, shift: Int): Int = (pixel shr shift) and 0xFF
}
