package com.novaenhance.ai.ai.model

import org.junit.Assert.assertEquals
import org.junit.Test
import java.io.File
import java.nio.file.Files

class ModelMetadataTest {

    @Test
    fun `toJson then fromFile round-trips every field exactly`() {
        val original = ModelMetadata(
            modelName = "General Photo AI",
            parameterCount = 20259,
            versionNumber = 3
        )

        val tempFile = Files.createTempFile("metadata", ".json").toFile()
        tempFile.writeText(original.toJson())

        val parsed = ModelMetadata.fromFile(tempFile)

        assertEquals(original, parsed)
    }

    @Test
    fun `fromFile falls back to NativeNeuralEngine's parameter count when the field is missing`() {
        val tempFile = Files.createTempFile("metadata", ".json").toFile()
        tempFile.writeText("""{"modelName": "Imported Model", "versionNumber": 1}""")

        val parsed = ModelMetadata.fromFile(tempFile)

        assertEquals("Imported Model", parsed.modelName)
        assertEquals(com.novaenhance.ai.ai.engine.NativeNeuralEngine.TOTAL_PARAMS, parsed.parameterCount)
    }

    @Test
    fun `sidecarFor swaps the weights extension for json`() {
        val weightsFile = File("/some/dir/v1.weights")
        val sidecar = ModelMetadata.sidecarFor(weightsFile)
        assertEquals(File("/some/dir/v1.json"), sidecar)
    }

    @Test
    fun `sidecarFor handles version-numbered names`() {
        val weightsFile = File("/models/general/v3.weights")
        val sidecar = ModelMetadata.sidecarFor(weightsFile)
        assertEquals("v3.json", sidecar.name)
    }
}
