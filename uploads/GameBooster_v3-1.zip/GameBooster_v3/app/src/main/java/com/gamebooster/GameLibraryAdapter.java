package com.gamebooster;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * RecyclerView adapter for the in-dashboard game library.
 *
 * <p>Each item shows:
 * <ul>
 *   <li>App icon (lazy-loaded off-thread)</li>
 *   <li>App name</li>
 *   <li>Status badge: <b>BOOSTED</b> (green) | <b>SELECTED</b> (purple) | none</li>
 *   <li>Remove (×) button</li>
 * </ul>
 *
 * <p>Tapping a row calls {@link OnGameAction#onSelect}.
 * Tapping × calls {@link OnGameAction#onRemove}.
 *
 * <h3>Thread safety</h3>
 * All methods must be called from the main thread.
 * Icons are loaded on a shared executor and posted back to the main thread.
 */
public class GameLibraryAdapter extends RecyclerView.Adapter<GameLibraryAdapter.ViewHolder> {

    public interface OnGameAction {
        void onSelect(AppInfo app);
        void onRemove(AppInfo app);
    }

    // ── Data ──────────────────────────────────────────────────────────────────
    private final List<AppInfo> items = new ArrayList<>();
    private String selectedPackage;
    private String boostedPackage;

    // ── Listeners ─────────────────────────────────────────────────────────────
    private OnGameAction actionListener;

    public void setOnGameAction(OnGameAction l) { actionListener = l; }

    // ── Icon loading ──────────────────────────────────────────────────────────
    private final ExecutorService iconExecutor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // ── Public API ────────────────────────────────────────────────────────────

    /** Replaces the full list and refreshes the UI. */
    public void setGames(List<AppInfo> list) {
        items.clear();
        items.addAll(list);
        notifyDataSetChanged();
    }

    /**
     * Adds a game at the top of the list.
     * Silent no-op if the package is already present.
     */
    public void addGame(AppInfo app) {
        for (AppInfo g : items) {
            if (g.packageName.equals(app.packageName)) return; // duplicate
        }
        items.add(0, app);
        notifyItemInserted(0);
    }

    /**
     * Removes the game with the given package name.
     * Silent no-op if not found.
     */
    public void removeGame(String packageName) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).packageName.equals(packageName)) {
                items.remove(i);
                notifyItemRemoved(i);
                return;
            }
        }
    }

    /** Returns {@code true} if the package is already in the adapter. */
    public boolean contains(String packageName) {
        for (AppInfo g : items)
            if (g.packageName.equals(packageName)) return true;
        return false;
    }

    /** Updates the currently-selected package and refreshes all rows. */
    public void setSelectedPackage(String pkg) {
        selectedPackage = pkg;
        notifyDataSetChanged();
    }

    /** Updates the boosted package and refreshes all rows. */
    public void setBoostedPackage(String pkg) {
        boostedPackage = pkg;
        notifyDataSetChanged();
    }

    /** Refreshes boost/selected badges without reloading icons. */
    public void notifyStateChanged() {
        notifyDataSetChanged();
    }

    /** Shuts down the icon-loading executor. Call from onDestroyView / onDestroy. */
    public void shutdown() {
        iconExecutor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
    }

    // ── RecyclerView.Adapter ──────────────────────────────────────────────────

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                               .inflate(R.layout.item_game_library, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder h, int position) {
        AppInfo app  = items.get(position);
        Context ctx  = h.itemView.getContext();

        h.tvName.setText(app.label);

        // Icon
        if (app.icon != null) {
            h.ivIcon.setImageDrawable(app.icon);
        } else {
            h.ivIcon.setImageResource(R.drawable.ic_gamepad);
            loadIconAsync(app, h, position);
        }

        // Badge
        boolean isBoosted  = app.packageName.equals(boostedPackage);
        boolean isSelected = app.packageName.equals(selectedPackage) && !isBoosted;

        if (isBoosted) {
            h.tvBadge.setVisibility(View.VISIBLE);
            h.tvBadge.setText("BOOSTED");
            h.tvBadge.setTextColor(ContextCompat.getColor(ctx, R.color.badge_boosted_text));
            setBadgeBackground(h.tvBadge,
                ContextCompat.getColor(ctx, R.color.badge_boosted_bg));
        } else if (isSelected) {
            h.tvBadge.setVisibility(View.VISIBLE);
            h.tvBadge.setText("SELECTED");
            h.tvBadge.setTextColor(ContextCompat.getColor(ctx, R.color.badge_selected_text));
            setBadgeBackground(h.tvBadge,
                ContextCompat.getColor(ctx, R.color.badge_selected_bg));
        } else {
            h.tvBadge.setVisibility(View.GONE);
        }

        // Row click
        h.itemView.setOnClickListener(v -> {
            if (actionListener != null) actionListener.onSelect(app);
        });

        // Remove click
        h.btnRemove.setOnClickListener(v -> {
            if (actionListener != null) actionListener.onRemove(app);
        });
    }

    @Override
    public int getItemCount() { return items.size(); }

    // ── Icon loading ──────────────────────────────────────────────────────────

    private void loadIconAsync(AppInfo app, ViewHolder holder, int position) {
        final String pkg = app.packageName;
        iconExecutor.execute(() -> {
            Drawable icon = null;
            try {
                // Use the holder's context to get PackageManager
                icon = holder.itemView.getContext()
                             .getPackageManager()
                             .getApplicationIcon(pkg);
            } catch (PackageManager.NameNotFoundException ignored) {}
            final Drawable fi = icon;
            mainHandler.post(() -> {
                if (fi == null) return;
                // Only apply if this holder still shows the same package
                int currentPos = holder.getBindingAdapterPosition();
                if (currentPos == RecyclerView.NO_ID) return;
                if (currentPos < items.size()
                        && items.get(currentPos).packageName.equals(pkg)) {
                    app.icon = fi;
                    holder.ivIcon.setImageDrawable(fi);
                }
            });
        });
    }

    // ── Badge helper ──────────────────────────────────────────────────────────

    private void setBadgeBackground(View v, int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(v.getContext().getResources()
                            .getDisplayMetrics().density * 6);
        bg.setColor(color);
        v.setBackground(bg);
    }

    // ── ViewHolder ────────────────────────────────────────────────────────────

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView ivIcon;
        final TextView  tvName;
        final TextView  tvBadge;
        final View      btnRemove;

        ViewHolder(View v) {
            super(v);
            ivIcon    = v.findViewById(R.id.iv_lib_icon);
            tvName    = v.findViewById(R.id.tv_lib_name);
            tvBadge   = v.findViewById(R.id.tv_lib_badge);
            btnRemove = v.findViewById(R.id.btn_lib_remove);
        }
    }
}
