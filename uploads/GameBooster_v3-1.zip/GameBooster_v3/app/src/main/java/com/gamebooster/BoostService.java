package com.gamebooster;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * Foreground service that applies system-level performance boosts.
 *
 * <h3>Critical fix: no automatic boost stopping</h3>
 * The previous revision contained a {@code monitorRunnable} that polled
 * {@link android.app.usage.UsageStatsManager} and called {@code stopSelf()} when
 * the boosted game was not the foreground app. This caused boost to stop every
 * time the user returned to the dashboard.
 *
 * <p><b>That runnable has been removed entirely.</b>
 *
 * <p>Boost now stops ONLY when:
 * <ol>
 *   <li>The user presses STOP BOOST → {@link #ACTION_STOP} with reason
 *       {@link BoostStateManager#STOP_USER}</li>
 *   <li>The user removes the boosted game → {@link #ACTION_STOP} with reason
 *       {@link BoostStateManager#STOP_GAME_REMOVED}</li>
 *   <li>A fatal service error occurs — the service exits with reason
 *       {@link BoostStateManager#STOP_SERVICE_ERROR} (rare / OS-level kill)</li>
 * </ol>
 *
 * <p>Boost does NOT stop because of:
 * returning to dashboard, opening another screen, locking/unlocking the device,
 * screen rotation, Activity/Fragment recreation, app backgrounding/foregrounding,
 * navigation events, or configuration changes.
 *
 * <h3>Service restart (START_STICKY)</h3>
 * The service uses {@code START_STICKY} so if the OS kills it under memory
 * pressure, the system will attempt to restart it. On restart with a null intent,
 * state is restored from {@link BoostStateManager}.
 *
 * <h3>Three-finger screenshot</h3>
 * Disabled on boost start via {@link ThreeFingerScreenshotHelper}; restored on stop.
 */
public class BoostService extends Service {

    private static final String TAG = "BoostService";

    // ── Intent actions & extras ───────────────────────────────────────────────
    public static final String EXTRA_PACKAGE     = "extra_package_name";
    public static final String EXTRA_LABEL       = "extra_app_label";
    public static final String EXTRA_PROFILE     = "extra_boost_profile";
    public static final String EXTRA_STOP_REASON = "extra_stop_reason";
    public static final String ACTION_STOP       = "com.gamebooster.action.STOP";

    // ── Broadcast actions & extras ────────────────────────────────────────────
    public static final String ACTION_STATE_CHANGED   = "com.gamebooster.STATE_CHANGED";
    public static final String EXTRA_IS_RUNNING       = "is_running";
    public static final String ACTION_THERMAL_WARNING = "com.gamebooster.THERMAL_WARNING";
    public static final String EXTRA_THERMAL_HEADROOM = "thermal_headroom";
    public static final String ACTION_THERMAL_OK      = "com.gamebooster.THERMAL_OK";
    public static final String ACTION_RAM_WARNING     = "com.gamebooster.RAM_WARNING";
    public static final String EXTRA_RAM_FREE_MB      = "ram_free_mb";
    public static final String ACTION_RAM_OK          = "com.gamebooster.RAM_OK";

    private static final int NOTIFICATION_ID = 1001;

    // ── SharedPreferences (legacy compatibility key) ───────────────────────────
    // Still written so any component that reads it directly keeps working.
    static final  String PREFS_BOOST    = "boost_service_state";
    public static final String KEY_IS_RUNNING = "service_running";

    // ── Timing ────────────────────────────────────────────────────────────────
    private static final long WAKELOCK_MAX_MS    = 3 * 60 * 60 * 1000L;
    private static final long THERMAL_INTERVAL   = 10_000L;
    private static final float THERMAL_WARN_LVL  = 0.80f;
    private static final long  RAM_WARN_MB       = 600L;

    // ── Fields ────────────────────────────────────────────────────────────────
    private String      gamePackage;
    private String      appLabel;
    private BoostProfile profile;
    private String      stopReason = BoostStateManager.STOP_SERVICE_ERROR; // default if killed

    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock  wifiLock;
    private HandlerThread         monitorThread;
    private Handler               monitorHandler;
    private ThreeFingerScreenshotHelper threeFingerHelper;

    private int     savedBrightness   = -1;
    private boolean brightnessApplied = false;

    private boolean thermalWarningActive = false;
    private boolean ramWarningActive     = false;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        monitorThread = new HandlerThread("GameBoosterMonitor");
        monitorThread.start();
        monitorHandler = new Handler(monitorThread.getLooper());
        threeFingerHelper = new ThreeFingerScreenshotHelper();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // ── Handle STOP action ──
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            String reason = intent.getStringExtra(EXTRA_STOP_REASON);
            stopReason = (reason != null) ? reason : BoostStateManager.STOP_USER;
            stopSelf();
            return START_NOT_STICKY;
        }

        // ── Restore from BoostStateManager if restarted with null intent ──
        if (intent == null) {
            BoostStateManager bsm = BoostStateManager.getInstance(this);
            if (!bsm.isActive()) {
                Log.w(TAG, "Restarted with null intent but no active boost — stopping.");
                stopSelf();
                return START_NOT_STICKY;
            }
            gamePackage = bsm.getBoostedPackage();
            appLabel    = bsm.getBoostedLabel();
            profile     = parseProfile(bsm.getBoostedProfile());
        } else {
            gamePackage = intent.getStringExtra(EXTRA_PACKAGE);
            appLabel    = intent.getStringExtra(EXTRA_LABEL);
            profile     = parseProfile(intent.getStringExtra(EXTRA_PROFILE));
        }

        if (gamePackage == null || gamePackage.isEmpty()) {
            Log.w(TAG, "No game package — stopping.");
            stopSelf();
            return START_NOT_STICKY;
        }

        if (appLabel == null || appLabel.isEmpty())
            appLabel = resolveLabel(gamePackage);

        // ── Start foreground ──
        startForeground(NOTIFICATION_ID, buildNotification());

        // ── Write legacy flag (synchronous for immediate readability) ──
        setLegacyRunningFlag(true);

        // ── Update BoostStateManager ──
        BoostStateManager.getInstance(this).onBoostConfirmed();

        // ── Broadcast ──
        broadcastState(true);

        // ── Apply tweaks ──
        if (profile.enableWakeLock)      acquireWakeLock();
        if (profile.enableWifiLock)      acquireWifiLock();
        if (profile.enableDnd)           applyDnd();
        if (profile.enableMaxBrightness) applyMaxBrightness();

        // ── Three-finger screenshot ──
        threeFingerHelper.disable(this);

        // ── Start thermal + RAM monitor (warnings only — does NOT stop boost) ──
        monitorHandler.postDelayed(thermalRunnable, THERMAL_INTERVAL);

        Log.i(TAG, "Boost Started — " + gamePackage + " [" + profile.name() + "]");

        // START_STICKY: system restarts service if killed (e.g. memory pressure)
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        // Write legacy flag first
        setLegacyRunningFlag(false);

        // Notify BoostStateManager (reason was set by whoever called stopSelf)
        BoostStateManager.getInstance(this).onBoostStopped(stopReason);

        // Broadcast
        broadcastState(false);

        // Stop monitoring
        monitorHandler.removeCallbacksAndMessages(null);
        monitorThread.quitSafely();

        // Release resources
        releaseWakeLock();
        releaseWifiLock();
        restoreDnd();
        restoreBrightness();
        threeFingerHelper.restore(this);

        Log.i(TAG, "Boost Stopped — reason=" + stopReason + " — settings restored.");
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ── Notification ──────────────────────────────────────────────────────────

    private Notification buildNotification() {
        PendingIntent openApp = PendingIntent.getActivity(this, 0,
            new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE);

        PendingIntent stopPi = PendingIntent.getService(this, 1,
            new Intent(this, BoostService.class)
                .setAction(ACTION_STOP)
                .putExtra(EXTRA_STOP_REASON, BoostStateManager.STOP_USER),
            PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, App.BOOST_CHANNEL_ID)
            .setContentTitle("⚡ GameBooster Active")
            .setContentText("Boosting " + appLabel + "  ·  "
                + (profile != null ? profile.displayName : "Balanced"))
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_media_pause, "Stop Boost", stopPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    // ── WakeLock ──────────────────────────────────────────────────────────────

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GameBooster:boost");
            wakeLock.acquire(WAKELOCK_MAX_MS);
        } catch (Exception e) { Log.w(TAG, "WakeLock failed", e); }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
    }

    // ── WifiLock ──────────────────────────────────────────────────────────────

    private void acquireWifiLock() {
        try {
            WifiManager wm = (WifiManager)
                getApplicationContext().getSystemService(WIFI_SERVICE);
            wifiLock = wm.createWifiLock(
                WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "GameBooster:wifi");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        } catch (Exception e) { Log.w(TAG, "WifiLock failed", e); }
    }

    private void releaseWifiLock() {
        if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        wifiLock = null;
    }

    // ── DND ───────────────────────────────────────────────────────────────────

    private static final String KEY_DND_APPLIED = "dnd_applied";
    private static final String KEY_DND_FILTER  = "dnd_saved_filter";

    private void applyDnd() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) return;
        int current = nm.getCurrentInterruptionFilter();
        getSharedPreferences(PREFS_BOOST, MODE_PRIVATE).edit()
            .putBoolean(KEY_DND_APPLIED, true)
            .putInt(KEY_DND_FILTER, current)
            .apply();
        nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE);
    }

    private void restoreDnd() {
        android.content.SharedPreferences sp =
            getSharedPreferences(PREFS_BOOST, MODE_PRIVATE);
        if (!sp.getBoolean(KEY_DND_APPLIED, false)) return;
        int saved = sp.getInt(KEY_DND_FILTER,
            NotificationManager.INTERRUPTION_FILTER_UNKNOWN);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm.isNotificationPolicyAccessGranted()
                && saved != NotificationManager.INTERRUPTION_FILTER_UNKNOWN)
            nm.setInterruptionFilter(saved);
        sp.edit().remove(KEY_DND_APPLIED).remove(KEY_DND_FILTER).apply();
    }

    // ── Brightness ────────────────────────────────────────────────────────────

    private void applyMaxBrightness() {
        if (!Settings.System.canWrite(this)) return;
        try {
            savedBrightness = Settings.System.getInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            Settings.System.putInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 255);
            brightnessApplied = true;
        } catch (Settings.SettingNotFoundException e) {
            Log.w(TAG, "Brightness read failed", e);
        }
    }

    private void restoreBrightness() {
        if (!brightnessApplied || savedBrightness < 0) return;
        if (Settings.System.canWrite(this))
            Settings.System.putInt(
                getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, savedBrightness);
        brightnessApplied = false;
    }

    // ── Thermal + RAM monitor ─────────────────────────────────────────────────
    // These runnables broadcast WARNINGS to the UI — they never stop the boost.

    private final Runnable thermalRunnable = new Runnable() {
        @Override public void run() {
            checkThermal();
            checkRam();
            monitorHandler.postDelayed(this, THERMAL_INTERVAL);
        }
    };

    private void checkThermal() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            float headroom = pm.getThermalHeadroom(10);
            if (headroom >= THERMAL_WARN_LVL && !thermalWarningActive) {
                thermalWarningActive = true;
                broadcast(new Intent(ACTION_THERMAL_WARNING)
                    .putExtra(EXTRA_THERMAL_HEADROOM, headroom));
            } else if (headroom < THERMAL_WARN_LVL - 0.05f && thermalWarningActive) {
                thermalWarningActive = false;
                broadcast(new Intent(ACTION_THERMAL_OK));
            }
        } catch (Exception ignored) {}
    }

    private void checkRam() {
        try {
            android.app.ActivityManager am =
                (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi =
                new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long freeMb = mi.availMem / (1024 * 1024);
            if (freeMb < RAM_WARN_MB && !ramWarningActive) {
                ramWarningActive = true;
                broadcast(new Intent(ACTION_RAM_WARNING).putExtra(EXTRA_RAM_FREE_MB, freeMb));
            } else if (freeMb >= RAM_WARN_MB + 50 && ramWarningActive) {
                ramWarningActive = false;
                broadcast(new Intent(ACTION_RAM_OK));
            }
        } catch (Exception ignored) {}
    }

    // ── Legacy SharedPreferences flag ─────────────────────────────────────────

    /**
     * Writes the legacy {@code KEY_IS_RUNNING} flag synchronously so any
     * component reading it directly sees the correct value immediately.
     */
    private void setLegacyRunningFlag(boolean running) {
        getSharedPreferences(PREFS_BOOST, MODE_PRIVATE).edit()
            .putBoolean(KEY_IS_RUNNING, running)
            .commit(); // synchronous — intentional
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void broadcastState(boolean running) {
        broadcast(new Intent(ACTION_STATE_CHANGED)
            .putExtra(EXTRA_IS_RUNNING, running));
    }

    private void broadcast(Intent intent) {
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    private String resolveLabel(String pkg) {
        try {
            PackageManager pm = getPackageManager();
            return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) { return pkg; }
    }

    private static BoostProfile parseProfile(String name) {
        if (name == null) return BoostProfile.BALANCED;
        try { return BoostProfile.valueOf(name); }
        catch (IllegalArgumentException e) { return BoostProfile.BALANCED; }
    }
}
