package com.gamebooster;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Persistent storage for the user's game library.
 *
 * <p>Games are stored as an ordered set of package names. Labels are stored
 * separately keyed by package name. The order reflects insertion order
 * (most recently added first).
 *
 * <p>Duplicate entries are silently ignored — calling {@link #addGame} with a
 * package already in the library is a no-op.
 */
public final class GameLibrary {

    private static final String PREFS_NAME  = "game_library";
    private static final String KEY_PKGS    = "packages";
    private static final String KEY_LABEL_  = "label_";   // prefix + packageName

    private final SharedPreferences prefs;

    public GameLibrary(Context ctx) {
        prefs = ctx.getApplicationContext()
                   .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // ── Write ─────────────────────────────────────────────────────────────────

    /**
     * Adds a game to the library. If already present, does nothing.
     *
     * @return {@code true} if the game was newly added, {@code false} if duplicate.
     */
    public boolean addGame(AppInfo app) {
        Set<String> pkgs = getPackageSet();
        if (pkgs.contains(app.packageName)) return false;
        pkgs.add(app.packageName);
        prefs.edit()
            .putStringSet(KEY_PKGS, pkgs)
            .putString(KEY_LABEL_ + app.packageName, app.label)
            .apply();
        return true;
    }

    /**
     * Removes a game from the library. Safe to call if the game is not present.
     */
    public void removeGame(String packageName) {
        Set<String> pkgs = getPackageSet();
        pkgs.remove(packageName);
        prefs.edit()
            .putStringSet(KEY_PKGS, pkgs)
            .remove(KEY_LABEL_ + packageName)
            .apply();
    }

    /** Updates the cached label for a package (e.g. after icon/label reload). */
    public void updateLabel(String packageName, String label) {
        if (contains(packageName)) {
            prefs.edit().putString(KEY_LABEL_ + packageName, label).apply();
        }
    }

    // ── Read ──────────────────────────────────────────────────────────────────

    /** Returns {@code true} if the package is in the library. */
    public boolean contains(String packageName) {
        return getPackageSet().contains(packageName);
    }

    /**
     * Returns all games in the library as a list of {@link AppInfo} objects.
     * Icons are not loaded here — they must be loaded asynchronously by the caller.
     */
    public List<AppInfo> getGames() {
        Set<String> pkgs = getPackageSet();
        List<AppInfo> list = new ArrayList<>(pkgs.size());
        for (String pkg : pkgs) {
            String label = prefs.getString(KEY_LABEL_ + pkg, pkg);
            list.add(new AppInfo(label, pkg));
        }
        return list;
    }

    /** Returns the number of games in the library. */
    public int size() {
        return getPackageSet().size();
    }

    // ── Private ───────────────────────────────────────────────────────────────

    /**
     * Returns a mutable copy of the package-name set.
     * Uses {@link LinkedHashSet} to preserve insertion order.
     */
    private Set<String> getPackageSet() {
        Set<String> stored = prefs.getStringSet(KEY_PKGS, null);
        // Always copy — SharedPreferences may return a live reference.
        return stored != null ? new LinkedHashSet<>(stored) : new LinkedHashSet<>();
    }
}
