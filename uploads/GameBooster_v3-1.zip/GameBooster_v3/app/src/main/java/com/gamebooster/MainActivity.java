package com.gamebooster;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.Drawable;
import android.net.VpnService;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Dashboard Activity for GameBooster.
 *
 * <h3>Architecture changes in this revision</h3>
 * <ul>
 *   <li><b>Manual game entry removed</b> — games can only be added from the
 *       installed-app picker ({@link AppPickerBottomSheet}). The
 *       {@code ManualGameDialog} and its dialog layout are gone.</li>
 *   <li><b>Game library</b> — a persistent list of added games is shown as a
 *       {@link RecyclerView} above the permission/profile sections. Games are
 *       stored in {@link GameLibrary} and displayed by {@link GameLibraryAdapter}
 *       with NORMAL / SELECTED / BOOSTED status badges.</li>
 *   <li><b>Centralized state</b> — {@link BoostStateManager} is the single
 *       source of truth for boost state. The Activity never owns boost state;
 *       it only observes and reflects it.</li>
 *   <li><b>Boost active flow</b> — tapping a game that is currently boosted shows
 *       a BOOST ACTIVE dialog (Launch Game / Stop Boost / Dismiss) instead of
 *       attempting to re-enter the boost workflow.</li>
 *   <li><b>No auto-stop</b> — {@code onResume}, navigation events, orientation
 *       changes, and Activity recreation never stop or restart boost.</li>
 *   <li><b>Boost starts only from BOOST button</b> — Boost stops only from
 *       STOP BOOST button or game removal.</li>
 * </ul>
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    // ── Views — Hero ──────────────────────────────────────────────────────────
    private ImageView ivHeroIcon;
    private TextView  tvHeroGameName;
    private TextView  tvHeroStatus;
    private TextView  tvHeroTweaks;

    // ── Views — Game Library ──────────────────────────────────────────────────
    private RecyclerView       rvLibrary;
    private View               cardLibrary;
    private GameLibraryAdapter libraryAdapter;
    private View               tvLibraryEmpty;

    // ── Views — Warning banners ───────────────────────────────────────────────
    private View     bannerThermal;
    private TextView tvThermalMsg;
    private View     bannerRam;
    private TextView tvRamMsg;

    // ── Views — Permission cards ──────────────────────────────────────────────
    private MaterialCardView cardPermUsage,      cardPermDnd;
    private MaterialCardView cardPermBrightness, cardPermBattery;
    private ImageView        ivPermUsage,        ivPermDnd;
    private ImageView        ivPermBrightness,   ivPermBattery;
    private TextView         tvPermUsage,        tvPermDnd;
    private TextView         tvPermBrightness,   tvPermBattery;

    // ── Views — Profiles ──────────────────────────────────────────────────────
    private MaterialCardView cardBattery, cardBalanced, cardMax;

    // ── Views — Stats + Options + Action ─────────────────────────────────────
    private View           statsSection;
    private TextView       tvStatRam, tvStatCpu, tvStatBattery;
    private SwitchCompat   switchVpn;
    private MaterialButton btnBoost;
    private MaterialButton btnPickGame;

    // ── State ─────────────────────────────────────────────────────────────────
    private AppInfo          selectedApp;
    private BoostProfile     selectedProfile;
    private BoostStateManager boostState;
    private GameLibrary       gameLibrary;
    private GamePreferences   prefs;

    // ── Sound ─────────────────────────────────────────────────────────────────
    private BoostSoundManager soundManager;

    // ── Executors ─────────────────────────────────────────────────────────────
    private final ExecutorService iconExecutor = Executors.newSingleThreadExecutor();
    private final Handler         mainHandler  = new Handler(Looper.getMainLooper());
    private final Handler         statsHandler = new Handler(Looper.getMainLooper());

    // ── Activity result launchers ─────────────────────────────────────────────
    private ActivityResultLauncher<Intent> permLauncher;
    private ActivityResultLauncher<Intent> vpnConsentLauncher;
    private String pendingVpnPackage;

    // ── Broadcast receiver ────────────────────────────────────────────────────
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context ctx, Intent intent) {
            if (intent == null || intent.getAction() == null) return;
            switch (intent.getAction()) {
                case BoostService.ACTION_STATE_CHANGED:
                    boolean running = intent.getBooleanExtra(
                        BoostService.EXTRA_IS_RUNNING, false);
                    syncBoostUi(running);
                    break;
                case BoostService.ACTION_THERMAL_WARNING:
                    showThermalBanner(intent.getFloatExtra(
                        BoostService.EXTRA_THERMAL_HEADROOM, 0f));
                    break;
                case BoostService.ACTION_THERMAL_OK:
                    hideThermalBanner();
                    break;
                case BoostService.ACTION_RAM_WARNING:
                    showRamBanner(intent.getLongExtra(BoostService.EXTRA_RAM_FREE_MB, 0));
                    break;
                case BoostService.ACTION_RAM_OK:
                    hideRamBanner();
                    break;
            }
        }
    };

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        boostState   = BoostStateManager.getInstance(this);
        gameLibrary  = new GameLibrary(this);
        prefs        = new GamePreferences(this);
        soundManager = new BoostSoundManager(this);

        bindViews();
        setupActivityResultLaunchers();
        setupProfileCards();
        setupVpnSwitch();
        setupPickGameButton();
        setupLibrary();
        hideThreeFingerOptionIfUnsupported();

        // Restore selected game
        if (savedInstanceState != null) {
            // Activity was recreated — restore from instance state
            String pkg   = savedInstanceState.getString("sel_pkg");
            String label = savedInstanceState.getString("sel_label");
            if (pkg != null) {
                AppInfo a = new AppInfo(label != null ? label : pkg, pkg);
                a.isFavorite = prefs.isFavorite(pkg);
                setSelectedApp(a, false);
            }
        } else {
            // Fresh start — restore from preferences
            restoreLastGame();
        }

        selectedProfile = prefs.getProfile();
        switchVpn.setChecked(prefs.isVpnEnabled());
        highlightProfileCard(selectedProfile);
        showXosGuideOnFirstLaunch();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updatePermissionCards();
        registerBroadcasts();

        // Read authoritative boost state from BoostStateManager.
        // This is safe in all lifecycle events — it never stops or starts boost.
        boolean active = boostState.isActive();
        syncBoostUi(active);
        libraryAdapter.setBoostedPackage(
            active ? boostState.getBoostedPackage() : null);
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        stopStatsPolling();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        soundManager.release();
        libraryAdapter.shutdown();
        iconExecutor.shutdownNow();
        mainHandler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (selectedApp != null) {
            out.putString("sel_pkg",   selectedApp.packageName);
            out.putString("sel_label", selectedApp.label);
        }
    }

    // ── View binding ──────────────────────────────────────────────────────────

    private void bindViews() {
        ivHeroIcon     = findViewById(R.id.iv_hero_icon);
        tvHeroGameName = findViewById(R.id.tv_hero_game_name);
        tvHeroStatus   = findViewById(R.id.tv_hero_status);
        tvHeroTweaks   = findViewById(R.id.tv_hero_tweaks);

        rvLibrary      = findViewById(R.id.rv_game_library);
        cardLibrary    = findViewById(R.id.card_game_library);
        tvLibraryEmpty = findViewById(R.id.tv_library_empty);

        bannerThermal = findViewById(R.id.banner_thermal);
        tvThermalMsg  = findViewById(R.id.tv_thermal_msg);
        bannerRam     = findViewById(R.id.banner_ram);
        tvRamMsg      = findViewById(R.id.tv_ram_msg);

        cardPermUsage      = findViewById(R.id.card_perm_usage);
        cardPermDnd        = findViewById(R.id.card_perm_dnd);
        cardPermBrightness = findViewById(R.id.card_perm_brightness);
        cardPermBattery    = findViewById(R.id.card_perm_battery);
        ivPermUsage        = findViewById(R.id.iv_perm_usage);
        ivPermDnd          = findViewById(R.id.iv_perm_dnd);
        ivPermBrightness   = findViewById(R.id.iv_perm_brightness);
        ivPermBattery      = findViewById(R.id.iv_perm_battery);
        tvPermUsage        = findViewById(R.id.tv_perm_usage_label);
        tvPermDnd          = findViewById(R.id.tv_perm_dnd_label);
        tvPermBrightness   = findViewById(R.id.tv_perm_brightness_label);
        tvPermBattery      = findViewById(R.id.tv_perm_battery_label);

        cardBattery  = findViewById(R.id.card_profile_battery);
        cardBalanced = findViewById(R.id.card_profile_balanced);
        cardMax      = findViewById(R.id.card_profile_max);

        statsSection  = findViewById(R.id.section_live_stats);
        tvStatRam     = findViewById(R.id.tv_stat_ram);
        tvStatCpu     = findViewById(R.id.tv_stat_cpu);
        tvStatBattery = findViewById(R.id.tv_stat_battery);

        switchVpn   = findViewById(R.id.switch_vpn);
        btnBoost    = findViewById(R.id.btn_boost);
        btnPickGame = findViewById(R.id.btn_pick_game);

        btnBoost.setOnClickListener(v -> onBoostClicked());
    }

    // ── Activity result launchers ─────────────────────────────────────────────

    private void setupActivityResultLaunchers() {
        permLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> updatePermissionCards());
        vpnConsentLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            r -> {
                if (r.getResultCode() == Activity.RESULT_OK && pendingVpnPackage != null)
                    launchVpnService(pendingVpnPackage);
                pendingVpnPackage = null;
            });
    }

    // ── Game Library ──────────────────────────────────────────────────────────

    private void setupLibrary() {
        libraryAdapter = new GameLibraryAdapter();
        libraryAdapter.setOnGameAction(new GameLibraryAdapter.OnGameAction() {
            @Override
            public void onSelect(AppInfo app) {
                onLibraryGameTapped(app);
            }
            @Override
            public void onRemove(AppInfo app) {
                onLibraryGameRemoved(app);
            }
        });

        rvLibrary.setLayoutManager(new LinearLayoutManager(this));
        rvLibrary.setAdapter(libraryAdapter);
        rvLibrary.setNestedScrollingEnabled(false); // let NestedScrollView handle scroll
        rvLibrary.setHasFixedSize(false);

        // Load saved games from library
        List<AppInfo> savedGames = gameLibrary.getGames();
        libraryAdapter.setGames(savedGames);

        // Show card wrapper only when there are games
        boolean hasGames = !savedGames.isEmpty();
        cardLibrary.setVisibility(hasGames ? View.VISIBLE : View.GONE);
        tvLibraryEmpty.setVisibility(hasGames ? View.GONE : View.VISIBLE);

        // Show boost state on library if active
        if (boostState.isActive()) {
            libraryAdapter.setBoostedPackage(boostState.getBoostedPackage());
        }
        // Show selected game in library
        if (selectedApp != null) {
            libraryAdapter.setSelectedPackage(selectedApp.packageName);
        }
    }

    /**
     * Called when the user taps a game card in the library.
     *
     * <ul>
     *   <li>If that game is currently being boosted → show BOOST ACTIVE dialog.</li>
     *   <li>Otherwise → select it as the active game.</li>
     * </ul>
     *
     * <p>This method NEVER starts or stops boost — it only changes the selected game.
     */
    private void onLibraryGameTapped(AppInfo app) {
        boolean isBoosted = boostState.isActive()
            && app.packageName.equals(boostState.getBoostedPackage());

        if (isBoosted) {
            showBoostActiveDialog(app);
        } else {
            setSelectedApp(app, true);
        }
    }

    /**
     * Shows the BOOST ACTIVE dialog when a boosted game is tapped.
     * Does NOT restart or re-enter the boost workflow.
     */
    private void showBoostActiveDialog(AppInfo app) {
        String profile = boostState.getBoostedProfile();
        new AlertDialog.Builder(this)
            .setTitle("⚡ BOOST ACTIVE")
            .setMessage(app.label + "\n\nProfile: "
                + (profile != null ? profile : "Balanced")
                + "\n\nBoost is running. Use the buttons below.")
            .setPositiveButton("🎮  Launch Game", (d, w) -> launchGame(app.packageName))
            .setNeutralButton("■  Stop Boost",   (d, w) -> stopBoosting())
            .setNegativeButton("Dismiss", null)
            .show();
    }

    /** Launches the game app via PackageManager. */
    private void launchGame(String packageName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch != null) {
            startActivity(launch);
        } else {
            toast("Cannot launch — app not installed");
        }
    }

    /**
     * Called when the user taps the × remove button on a library game card.
     * If the game is currently boosted, boost is stopped first.
     */
    private void onLibraryGameRemoved(AppInfo app) {
        new AlertDialog.Builder(this)
            .setTitle("Remove Game")
            .setMessage("Remove \"" + app.label + "\" from your library?")
            .setPositiveButton("Remove", (d, w) -> doRemoveGame(app))
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void doRemoveGame(AppInfo app) {
        // If this game is currently boosted, stop the boost first
        if (boostState.isActive()
                && app.packageName.equals(boostState.getBoostedPackage())) {
            stopService(new Intent(this, BoostService.class)
                .setAction(BoostService.ACTION_STOP)
                .putExtra(BoostService.EXTRA_STOP_REASON,
                    BoostStateManager.STOP_GAME_REMOVED));
            BoostStateManager.getInstance(this)
                             .onBoostStopped(BoostStateManager.STOP_GAME_REMOVED);
            syncBoostUi(false);
        }

        // Clear selected app if it was this one
        if (selectedApp != null && selectedApp.packageName.equals(app.packageName)) {
            selectedApp = null;
            tvHeroGameName.setText(R.string.hero_no_game);
            tvHeroStatus.setText(R.string.status_no_game);
            tvHeroTweaks.setVisibility(View.INVISIBLE);
            ivHeroIcon.setImageResource(R.drawable.ic_gamepad);
        }

        // Remove from library + adapter
        gameLibrary.removeGame(app.packageName);
        libraryAdapter.removeGame(app.packageName);
        updateLibraryEmptyState();
        toast("\"" + app.label + "\" removed from library");
    }

    private void updateLibraryEmptyState() {
        boolean empty = gameLibrary.size() == 0;
        tvLibraryEmpty.setVisibility(empty ? View.VISIBLE : View.GONE);
        cardLibrary.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    // ── Profile cards ─────────────────────────────────────────────────────────

    private void setupProfileCards() {
        cardBattery.setOnClickListener(v -> selectProfile(BoostProfile.BATTERY_SAVER));
        cardBalanced.setOnClickListener(v -> selectProfile(BoostProfile.BALANCED));
        cardMax.setOnClickListener(v -> selectProfile(BoostProfile.MAX_PERFORMANCE));
    }

    private void selectProfile(BoostProfile p) {
        selectedProfile = p;
        prefs.saveProfile(p);
        highlightProfileCard(p);
        updateHeroTweaks();
        if (p == BoostProfile.MAX_PERFORMANCE && !switchVpn.isChecked()) {
            switchVpn.setChecked(true);
            prefs.saveVpnEnabled(true);
        }
    }

    private void highlightProfileCard(BoostProfile p) {
        int sS = ContextCompat.getColor(this, R.color.boost_color);
        int nS = ContextCompat.getColor(this, R.color.card_stroke);
        int sB = ContextCompat.getColor(this, R.color.profile_selected_bg);
        int nB = ContextCompat.getColor(this, R.color.bg_card);
        resetProfileCard(cardBattery,  nS, nB);
        resetProfileCard(cardBalanced, nS, nB);
        resetProfileCard(cardMax,      nS, nB);
        MaterialCardView sel = p == BoostProfile.BATTERY_SAVER ? cardBattery
            : p == BoostProfile.MAX_PERFORMANCE ? cardMax : cardBalanced;
        sel.setStrokeColor(sS);
        sel.setStrokeWidth(dpToPx(2));
        sel.setCardBackgroundColor(sB);
    }

    private void resetProfileCard(MaterialCardView c, int stroke, int bg) {
        c.setStrokeColor(stroke);
        c.setStrokeWidth(dpToPx(1));
        c.setCardBackgroundColor(bg);
    }

    // ── VPN switch ────────────────────────────────────────────────────────────

    private void setupVpnSwitch() {
        switchVpn.setOnCheckedChangeListener((b, c) -> prefs.saveVpnEnabled(c));
    }

    // ── App picker ────────────────────────────────────────────────────────────

    private void setupPickGameButton() {
        btnPickGame.setOnClickListener(v -> {
            AppPickerBottomSheet sheet = AppPickerBottomSheet.newInstance();
            sheet.setOnAppPicked(app -> onAppPicked(app));
            sheet.show(getSupportFragmentManager(), AppPickerBottomSheet.TAG);
        });
    }

    /**
     * Called when the user selects an app from the picker.
     * Adds it to the library (duplicate-safe) and selects it.
     */
    private void onAppPicked(AppInfo app) {
        boolean wasNew = gameLibrary.addGame(app);
        if (wasNew) {
            libraryAdapter.addGame(app);
            updateLibraryEmptyState();
            soundManager.playGameSelected();
        } else {
            toast("\"" + app.label + "\" is already in your library");
        }
        setSelectedApp(app, wasNew);
    }

    /** Hide the three-finger option card on unsupported devices. */
    private void hideThreeFingerOptionIfUnsupported() {
        View card = findViewById(R.id.card_option_three_finger);
        if (card != null) {
            card.setVisibility(
                ThreeFingerScreenshotHelper.isSupported(this)
                    ? View.VISIBLE : View.GONE);
        }
    }

    // ── Selected game display ─────────────────────────────────────────────────

    /**
     * Sets the currently-selected game in the hero card and library adapter.
     * Does NOT start boost.
     *
     * @param playSound {@code true} to play the game-selected sound effect
     */
    private void setSelectedApp(AppInfo app, boolean playSound) {
        selectedApp = app;
        prefs.saveLastGame(app);
        tvHeroGameName.setText(app.label);
        tvHeroTweaks.setVisibility(View.VISIBLE);
        updateHeroTweaks();

        if (playSound) soundManager.playGameSelected();

        // Library badge
        libraryAdapter.setSelectedPackage(app.packageName);

        // Hero icon
        if (app.icon != null) {
            ivHeroIcon.setImageDrawable(app.icon);
        } else {
            ivHeroIcon.setImageResource(R.drawable.ic_gamepad);
            final String pkg = app.packageName;
            iconExecutor.execute(() -> {
                Drawable icon = null;
                try { icon = getPackageManager().getApplicationIcon(pkg); }
                catch (Exception ignored) {}
                final Drawable fi = icon;
                mainHandler.post(() -> {
                    if (selectedApp != null && selectedApp.packageName.equals(pkg)) {
                        if (fi != null) {
                            app.icon = fi;
                            ivHeroIcon.setImageDrawable(fi);
                        }
                    }
                });
            });
        }
    }

    private void restoreLastGame() {
        String pkg   = prefs.getLastPackage();
        String label = prefs.getLastLabel();
        if (pkg != null) {
            AppInfo a = new AppInfo(label != null ? label : pkg, pkg);
            a.isFavorite = prefs.isFavorite(pkg);
            setSelectedApp(a, false);
        }
    }

    // ── Boost control ─────────────────────────────────────────────────────────

    private void onBoostClicked() {
        if (boostState.isActive()) stopBoosting();
        else                       startBoosting();
    }

    private void startBoosting() {
        if (!PermissionHelper.hasUsageAccess(this)) {
            showSettingsDialog("Usage Access Required",
                "GameBooster needs Usage Access to monitor your game.\n\n"
                    + "Tap OK → enable GameBooster under Usage access.",
                PermissionHelper.usageAccessIntent());
            return;
        }

        if (PermissionHelper.isXosDevice()
                && !PermissionHelper.isBatteryOptimizationIgnored(this)) {
            new AlertDialog.Builder(this)
                .setTitle("⚠️  Battery Restriction Active")
                .setMessage("XOS may kill the boost service because GameBooster "
                    + "is battery-restricted.\n\nTap \"Allow\" to exempt it, "
                    + "then start the boost again.")
                .setPositiveButton("Allow", (d, w) ->
                    permLauncher.launch(PermissionHelper.batteryOptimizationIntent(this)))
                .setNegativeButton("Boost Anyway", (d, w) -> doStartBoosting())
                .show();
            return;
        }

        doStartBoosting();
    }

    private void doStartBoosting() {
        if (selectedApp == null) {
            toast("Tap \"Select Game\" to choose a game first");
            return;
        }

        if (selectedProfile.enableDnd && !PermissionHelper.hasNotificationPolicyAccess(this))
            toast("DND access not granted — silent mode will be skipped");
        if (selectedProfile.enableMaxBrightness && !PermissionHelper.canWriteSettings(this))
            toast("Write Settings not granted — brightness boost will be skipped");

        // Update BoostStateManager BEFORE starting service so state is persisted
        // immediately, even if the service takes a moment to start.
        boostState.onBoostStarting(
            selectedApp.packageName, selectedApp.label, selectedProfile.name());

        startForegroundService(new Intent(this, BoostService.class)
            .putExtra(BoostService.EXTRA_PACKAGE, selectedApp.packageName)
            .putExtra(BoostService.EXTRA_LABEL,   selectedApp.label)
            .putExtra(BoostService.EXTRA_PROFILE,  selectedProfile.name()));

        if (selectedProfile.enableVpn && switchVpn.isChecked())
            requestVpnConsent(selectedApp.packageName);

        syncBoostUi(true);
        soundManager.playBoostOn();
        toast("⚡ Boost started — " + selectedProfile.displayName);
    }

    /**
     * Stops the active boost. Only called when the user explicitly presses STOP BOOST.
     * Sets stop reason to USER_STOP.
     */
    private void stopBoosting() {
        // Send ACTION_STOP with USER_STOP reason
        stopService(new Intent(this, BoostService.class)
            .setAction(BoostService.ACTION_STOP)
            .putExtra(BoostService.EXTRA_STOP_REASON, BoostStateManager.STOP_USER));

        if (BoostVpnService.isRunning)
            startService(new Intent(this, BoostVpnService.class)
                .setAction(BoostVpnService.ACTION_STOP));

        // Update state immediately (service onDestroy also does this, but this is faster)
        boostState.onBoostStopped(BoostStateManager.STOP_USER);

        syncBoostUi(false);
        soundManager.playBoostOff();
        toast("Boost stopped");
    }

    // ── VPN consent ───────────────────────────────────────────────────────────

    private void requestVpnConsent(String pkg) {
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) {
            pendingVpnPackage = pkg;
            vpnConsentLauncher.launch(prepare);
        } else {
            launchVpnService(pkg);
        }
    }

    private void launchVpnService(String pkg) {
        startService(new Intent(this, BoostVpnService.class)
            .putExtra(BoostVpnService.EXTRA_GAME_PACKAGE, pkg));
    }

    // ── UI sync ───────────────────────────────────────────────────────────────

    /**
     * Synchronises the entire UI to reflect the given boost state.
     *
     * <p>Called from:
     * <ul>
     *   <li>{@code onResume} — reads from BoostStateManager</li>
     *   <li>Broadcast receiver — service confirmed state</li>
     *   <li>After user taps BOOST or STOP BOOST</li>
     * </ul>
     *
     * <p>This method NEVER starts or stops boost — it only updates UI.
     */
    private void syncBoostUi(boolean boosting) {
        // Update button
        if (boosting) {
            btnBoost.setText(R.string.btn_stop);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.stop_color));
            tvHeroStatus.setText(R.string.status_active);
            tvHeroStatus.setTextColor(
                ContextCompat.getColor(this, R.color.perm_ok));
            statsSection.setVisibility(View.VISIBLE);
            startStatsPolling();
        } else {
            btnBoost.setText(R.string.btn_boost);
            btnBoost.setBackgroundTintList(
                ContextCompat.getColorStateList(this, R.color.boost_color));
            tvHeroStatus.setText(
                selectedApp != null ? R.string.status_ready : R.string.status_no_game);
            tvHeroStatus.setTextColor(
                ContextCompat.getColor(this, R.color.text_secondary));
            statsSection.setVisibility(View.GONE);
            stopStatsPolling();
            hideThermalBanner();
            hideRamBanner();
        }

        // Update library badges
        libraryAdapter.setBoostedPackage(
            boosting ? boostState.getBoostedPackage() : null);
    }

    // ── Permission cards ──────────────────────────────────────────────────────

    private void updatePermissionCards() {
        setPermCard(cardPermUsage, ivPermUsage, tvPermUsage,
            PermissionHelper.hasUsageAccess(this),
            getString(R.string.perm_usage_short), PermissionHelper.usageAccessIntent());
        setPermCard(cardPermDnd, ivPermDnd, tvPermDnd,
            PermissionHelper.hasNotificationPolicyAccess(this),
            getString(R.string.perm_dnd_short), PermissionHelper.notificationPolicyIntent());
        setPermCard(cardPermBrightness, ivPermBrightness, tvPermBrightness,
            PermissionHelper.canWriteSettings(this),
            getString(R.string.perm_brightness_short), PermissionHelper.writeSettingsIntent(this));
        setPermCard(cardPermBattery, ivPermBattery, tvPermBattery,
            PermissionHelper.isBatteryOptimizationIgnored(this),
            getString(R.string.perm_battery_short),
            PermissionHelper.batteryOptimizationIntent(this));
    }

    private void setPermCard(MaterialCardView card, ImageView icon, TextView label,
                              boolean granted, String text, Intent intent) {
        int okC = ContextCompat.getColor(this, R.color.perm_ok);
        int wC  = ContextCompat.getColor(this, R.color.perm_warn);
        int okS = ContextCompat.getColor(this, R.color.perm_ok_stroke);
        int wS  = ContextCompat.getColor(this, R.color.perm_warn_stroke);
        label.setText(text);
        if (granted) {
            icon.setImageResource(R.drawable.ic_check_circle);
            icon.setColorFilter(okC);
            card.setStrokeColor(okS);
            card.setOnClickListener(null);
        } else {
            icon.setImageResource(R.drawable.ic_warning);
            icon.setColorFilter(wC);
            card.setStrokeColor(wS);
            card.setOnClickListener(v -> permLauncher.launch(intent));
        }
    }

    // ── Warning banners ───────────────────────────────────────────────────────

    private void showThermalBanner(float h) {
        tvThermalMsg.setText("🌡️  Phone heating up ("
            + (int)(h * 100) + "% — throttle risk). Consider a short break.");
        bannerThermal.setVisibility(View.VISIBLE);
    }

    private void hideThermalBanner() {
        if (bannerThermal != null) bannerThermal.setVisibility(View.GONE);
    }

    private void showRamBanner(long mb) {
        tvRamMsg.setText("💾  Low RAM: " + mb + " MB free. "
            + "Close background apps to keep the boost stable.");
        bannerRam.setVisibility(View.VISIBLE);
    }

    private void hideRamBanner() {
        if (bannerRam != null) bannerRam.setVisibility(View.GONE);
    }

    public void dismissThermalBanner(View v) { hideThermalBanner(); }
    public void dismissRamBanner(View v)     { hideRamBanner(); }

    // ── XOS first-launch guide ────────────────────────────────────────────────

    private void showXosGuideOnFirstLaunch() {
        if (!PermissionHelper.isXosDevice()) return;
        android.content.SharedPreferences sp =
            getSharedPreferences("gamebooster_app", MODE_PRIVATE);
        if (sp.getBoolean("xos_guide_shown", false)) return;
        sp.edit().putBoolean("xos_guide_shown", true).apply();
        mainHandler.postDelayed(() -> XosGuideDialog.showIfNeeded(this, null), 800L);
    }

    // ── Hero tweaks count ─────────────────────────────────────────────────────

    private void updateHeroTweaks() {
        if (selectedProfile == null) return;
        int n = selectedProfile.activeTweakCount();
        tvHeroTweaks.setText(n + " optimization" + (n == 1 ? "" : "s") + " active");
    }

    // ── Live stats ────────────────────────────────────────────────────────────

    private final Runnable statsRunnable = this::refreshStats;

    private void startStatsPolling() {
        statsHandler.removeCallbacks(statsRunnable);
        statsHandler.post(statsRunnable);
    }

    private void stopStatsPolling() {
        statsHandler.removeCallbacks(statsRunnable);
    }

    private void refreshStats() {
        android.app.ActivityManager am =
            (android.app.ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        android.app.ActivityManager.MemoryInfo mi =
            new android.app.ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        tvStatRam.setText((mi.totalMem - mi.availMem) / (1024 * 1024)
            + " / " + mi.totalMem / (1024 * 1024) + " MB");

        IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent bat = registerReceiver(null, f);
        int lvl = bat != null ? bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
        int scl = bat != null ? bat.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;
        tvStatBattery.setText((lvl >= 0 && scl > 0)
            ? ((int)(lvl * 100f / scl)) + "%" : "—");
        tvStatCpu.setText((int)(100 - mi.availMem * 100.0 / mi.totalMem) + "%");

        if (boostState.isActive()) statsHandler.postDelayed(statsRunnable, 2_000L);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void registerBroadcasts() {
        IntentFilter f = new IntentFilter();
        f.addAction(BoostService.ACTION_STATE_CHANGED);
        f.addAction(BoostService.ACTION_THERMAL_WARNING);
        f.addAction(BoostService.ACTION_THERMAL_OK);
        f.addAction(BoostService.ACTION_RAM_WARNING);
        f.addAction(BoostService.ACTION_RAM_OK);
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, f);
    }

    private void showSettingsDialog(String title, String msg, Intent intent) {
        new AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setPositiveButton("Open Settings", (d, w) -> permLauncher.launch(intent))
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private int dpToPx(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
