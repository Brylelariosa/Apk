package com.gamebooster;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

/**
 * Centralized, persistent boost state manager. Single source of truth.
 *
 * <h3>Allowed states</h3>
 * <pre>
 *   IDLE     — no game selected / not boosting
 *   SELECTED — game picked but boost not active
 *   BOOSTING — boost command sent, service starting
 *   BOOSTED  — service confirmed running
 * </pre>
 *
 * <h3>Stop reasons (logged)</h3>
 * <ul>
 *   <li>{@link #STOP_USER}         — user pressed STOP BOOST</li>
 *   <li>{@link #STOP_GAME_REMOVED} — game removed from library</li>
 *   <li>{@link #STOP_SERVICE_ERROR}— service crashed / fatal error</li>
 * </ul>
 *
 * <p>State is written with {@code commit()} (synchronous) so it is immediately
 * readable from any component in the same process without race windows.
 *
 * <h3>Persistence guarantee</h3>
 * State survives: Activity recreation, orientation changes, navigation events,
 * app backgrounding/foregrounding, and app restarts.
 *
 * <h3>What NEVER causes a stop</h3>
 * Dashboard return, navigation, Activity/Fragment recreation, screen rotation,
 * app startup, clicking a boosted game — none of these touch boost state.
 */
public final class BoostStateManager {

    private static final String TAG = "BoostStateManager";

    // ── Stop reason constants ─────────────────────────────────────────────────
    public static final String STOP_USER          = "USER_STOP";
    public static final String STOP_GAME_REMOVED  = "GAME_REMOVED";
    public static final String STOP_SERVICE_ERROR = "SERVICE_ERROR";

    // ── State enum ────────────────────────────────────────────────────────────
    public enum State { IDLE, SELECTED, BOOSTING, BOOSTED }

    // ── SharedPreferences keys ────────────────────────────────────────────────
    private static final String PREFS_NAME    = "boost_state_manager";
    private static final String KEY_STATE     = "state";
    private static final String KEY_PKG       = "boosted_pkg";
    private static final String KEY_LABEL     = "boosted_label";
    private static final String KEY_PROFILE   = "boosted_profile";

    // ── Singleton ─────────────────────────────────────────────────────────────
    private static volatile BoostStateManager instance;

    public static BoostStateManager getInstance(Context ctx) {
        if (instance == null) {
            synchronized (BoostStateManager.class) {
                if (instance == null)
                    instance = new BoostStateManager(ctx.getApplicationContext());
            }
        }
        return instance;
    }

    // ── Fields ────────────────────────────────────────────────────────────────
    private final SharedPreferences prefs;
    private State  currentState;
    private String boostedPkg;
    private String boostedLabel;
    private String boostedProfile;

    private BoostStateManager(Context appCtx) {
        prefs = appCtx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        restoreFromPrefs();
    }

    // ── Public read API ───────────────────────────────────────────────────────

    public State  getState()          { return currentState; }
    public String getBoostedPackage() { return boostedPkg; }
    public String getBoostedLabel()   { return boostedLabel; }
    public String getBoostedProfile() { return boostedProfile; }

    /** {@code true} while the service is starting or fully running. */
    public boolean isActive() {
        return currentState == State.BOOSTING || currentState == State.BOOSTED;
    }

    // ── Transitions ───────────────────────────────────────────────────────────

    /**
     * Called immediately when the user presses BOOST.
     * Persists state before the service even starts.
     */
    public void onBoostStarting(String pkg, String label, String profile) {
        currentState  = State.BOOSTING;
        boostedPkg    = pkg;
        boostedLabel  = label;
        boostedProfile = profile;
        Log.i(TAG, "Boost Started — pkg=" + pkg + " profile=" + profile);
        persist();
    }

    /**
     * Called by {@link BoostService} once it is fully running.
     * Transitions BOOSTING → BOOSTED.
     */
    public void onBoostConfirmed() {
        currentState = State.BOOSTED;
        persist();
    }

    /**
     * Called when boost ends for any reason.
     *
     * @param reason one of {@link #STOP_USER}, {@link #STOP_GAME_REMOVED},
     *               {@link #STOP_SERVICE_ERROR}
     */
    public void onBoostStopped(String reason) {
        Log.i(TAG, "Boost Stopped — reason=" + reason);
        currentState   = State.IDLE;
        boostedPkg     = null;
        boostedLabel   = null;
        boostedProfile = null;
        persist();
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private void restoreFromPrefs() {
        String name = prefs.getString(KEY_STATE, State.IDLE.name());
        try {
            currentState = State.valueOf(name);
        } catch (IllegalArgumentException e) {
            currentState = State.IDLE;
        }
        boostedPkg     = prefs.getString(KEY_PKG,     null);
        boostedLabel   = prefs.getString(KEY_LABEL,   null);
        boostedProfile = prefs.getString(KEY_PROFILE, null);
        Log.i(TAG, "Boost Restored — state=" + currentState + " pkg=" + boostedPkg);
    }

    /**
     * Writes state synchronously ({@code commit()}) so it is guaranteed to be
     * readable by any component immediately — no async race windows.
     */
    private void persist() {
        prefs.edit()
            .putString(KEY_STATE,   currentState.name())
            .putString(KEY_PKG,     boostedPkg)
            .putString(KEY_LABEL,   boostedLabel)
            .putString(KEY_PROFILE, boostedProfile)
            .commit(); // synchronous — intentional
    }
}
