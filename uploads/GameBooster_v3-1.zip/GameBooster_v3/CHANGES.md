# GameBooster v3 — Change Summary

## New Files

| File | Purpose |
|---|---|
| `BoostStateManager.java` | Centralized, persistent boost state singleton |
| `GameLibrary.java` | Persistent storage for the game library (added games) |
| `GameLibraryAdapter.java` | RecyclerView adapter for game library with BOOSTED/SELECTED badges |
| `item_game_library.xml` | Layout for a single game row in the library |

## Deleted Files

| File | Reason |
|---|---|
| `ManualGameDialog.java` | Manual package entry removed per spec |
| `dialog_manual_game.xml` | Layout for deleted dialog |

## Modified Files

### `BoostService.java` — Critical bug fixes

**Root cause of auto-stop bug removed:**
The `monitorRunnable` polled `UsageStatsManager` every 5 seconds and called
`stopSelf()` when the boosted game was not the foreground app. This caused boost
to stop every time the user returned to the dashboard. **The runnable has been
removed entirely.**

**Other fixes:**
- Changed `START_NOT_STICKY` → `START_STICKY` so the OS restarts the service
  if it is killed under memory pressure
- Added `EXTRA_STOP_REASON` to the stop intent so the reason is logged correctly
- Removed `monitorRunnable`; thermal/RAM runnables now only broadcast warnings,
  they never stop the service
- Integrates with `BoostStateManager` to update authoritative state on
  confirm and stop
- `android:stopWithTask="false"` added in the manifest so the service is not
  killed when the user swipes the app away
- Stop reason constants: `USER_STOP`, `GAME_REMOVED`, `SERVICE_ERROR`

### `MainActivity.java` — Major rewrite

**Manual entry removed:**
- `btnAddManual` and its click handler removed
- `ManualGameDialog` call removed

**Game library added:**
- `GameLibrary` instance manages persistence
- `GameLibraryAdapter` displays games with BOOSTED / SELECTED / NORMAL badges
- Tapping a library row:
  - If that game is **boosted** → shows BOOST ACTIVE dialog (Launch / Stop Boost / Dismiss)
  - Otherwise → selects it as the current game
- × button shows a confirmation dialog before removing a game
- Removing a boosted game first stops the boost (with `GAME_REMOVED` reason)

**Boost state centralized:**
- All boost state read from `BoostStateManager`, never from Activity fields
- `onResume` reads `BoostStateManager.isActive()` — safe in ALL lifecycle events
- No grace-window hack needed — state is written synchronously before service starts
- `syncBoostUi()` only updates UI, never starts/stops boost
- Boost starts ONLY from BOOST button press
- Boost stops ONLY from STOP BOOST button or game removal

**Boost active flow:**
- Tapping a boosted game shows BOOST ACTIVE dialog instead of re-entering boost workflow
- `launchGame()` opens the app via `PackageManager.getLaunchIntentForPackage`

### `AndroidManifest.xml`

- Added `android:configChanges="orientation|screenSize|keyboardHidden"` to
  `MainActivity` so orientation changes do not recreate the Activity
  (eliminates a class of lifecycle-triggered UI resets)
- Added `android:stopWithTask="false"` to `BoostService` so the service
  survives the user swiping the app from the recents list

### `activity_main.xml`

- `btn_add_manual` removed
- `btn_pick_game` renamed to "Add Game" (single entry point)
- Game library section added with `rv_game_library` inside `card_game_library`
- Empty-state view `tv_library_empty` shown when library is empty

### `strings.xml`

- `btn_add_manual`, `btn_select_game`, `manual_dialog_title` removed
- `btn_add_game` added
- `section_game_library`, `library_empty_title`, `library_empty_subtitle` added
- `status_no_game` updated to reference "Add Game"

### `colors.xml`

- `badge_boosted_bg`, `badge_boosted_text` added (green)
- `badge_selected_bg`, `badge_selected_text` added (purple)

---

## Boost State Rules (enforced)

| Event | Boost changes? |
|---|---|
| Returning to dashboard | ✖ No |
| Opening another screen | ✖ No |
| Opening the boosted game | ✖ No |
| Locking / unlocking device | ✖ No |
| Screen rotation | ✖ No |
| Activity recreation | ✖ No |
| Fragment recreation | ✖ No |
| App backgrounding / foregrounding | ✖ No |
| Navigation events | ✖ No |
| App startup / state restore | ✖ No |
| **User presses STOP BOOST** | ✔ Stops |
| **User removes boosted game** | ✔ Stops |
| **Fatal service error** | ✔ Stops |

## Logged Stop Reasons

| Constant | When |
|---|---|
| `USER_STOP` | User pressed STOP BOOST |
| `GAME_REMOVED` | User removed the game from the library |
| `SERVICE_ERROR` | Default if service is killed without an explicit stop |

The previous `monitorRunnable` caused implicit stops with no logged reason.
That code path no longer exists.

## Three-Finger Screenshot

Behaviour unchanged from v2:
- Disabled automatically when boost starts (in `BoostService.onStartCommand`)
- Restored automatically when boost stops (in `BoostService.onDestroy`)
- Card hidden on unsupported devices
- Handles `WRITE_SETTINGS` not granted gracefully
