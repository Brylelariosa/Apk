package com.hazardyard.game.survival;

import com.hazardyard.game.core.GameConfig;

/**
 * Everything of a survival match that is not a player's position: the endless terrain, the zombies, cars and dropped items,
 * every survivor's pack and hunger, the clock. The host changes it (through {@link SurvivalSim}); clients keep a copy that
 * the snapshots keep up to date.
 */
public final class SurvivalState {
    public static final int MAX_ZOMBIES = 56;
    public static final int MAX_CARS = 24;
    public static final int MAX_DROPS = 80;
    /** Seconds in a full day (dawn to dawn). */
    public static final float DAY_LENGTH = 480f;

    public final int seed;
    public final SurvivalTerrain terrain;
    /** Seconds since the world began; the world starts shortly after dawn. */
    public float time = DAY_LENGTH * 0.10f;
    public final Zombie[] zombies = new Zombie[MAX_ZOMBIES];
    public final Car[] cars = new Car[MAX_CARS];
    public final Drop[] drops = new Drop[MAX_DROPS];
    public final Inventory[] inv = new Inventory[GameConfig.MAX_PLAYERS];
    public final float[] hunger = new float[GameConfig.MAX_PLAYERS];
    /** The car each survivor sits in (id) or -1. */
    public final int[] drivingCar = new int[GameConfig.MAX_PLAYERS];
    /** Fishing: 0 not fishing, 1 line in the water, 2 a fish is biting; and where the float is. */
    public final int[] fishState = new int[GameConfig.MAX_PLAYERS];
    public final float[] fishX = new float[GameConfig.MAX_PLAYERS];
    public final float[] fishY = new float[GameConfig.MAX_PLAYERS];
    /** The host's rules engine (null on clients). */
    public SurvivalSim sim;

    /** A short message for the local player ("Needs a wrench") and how long it stays up. */
    public int toast = -1;
    public float toastTimer;

    public SurvivalState(int seed) {
        this.seed = seed;
        this.terrain = new SurvivalTerrain(seed);
        for (int i = 0; i < zombies.length; i++) zombies[i] = new Zombie();
        for (int i = 0; i < cars.length; i++) cars[i] = new Car();
        for (int i = 0; i < drops.length; i++) drops[i] = new Drop();
        for (int i = 0; i < inv.length; i++) {
            inv[i] = new Inventory();
            hunger[i] = 85f;
            drivingCar[i] = -1;
        }
    }

    /** Fraction of the day: 0 dawn, 0.5 dusk-ish; wraps at 1. */
    public float dayFraction() {
        return (time % DAY_LENGTH) / DAY_LENGTH;
    }

    public int dayNumber() {
        return 1 + (int) (time / DAY_LENGTH);
    }

    /** 1 in full daylight, 0 in the dead of night. */
    public float daylight() {
        float f = dayFraction();
        if (f < 0.06f) return 0.30f + 0.70f * (f / 0.06f);          // dawn
        if (f < 0.56f) return 1f;                                    // day
        if (f < 0.68f) return 1f - 0.85f * ((f - 0.56f) / 0.12f);    // dusk
        if (f < 0.92f) return 0.15f;                                 // night
        return 0.15f + 0.15f * ((f - 0.92f) / 0.08f);                // before dawn
    }

    public boolean isNight() {
        return daylight() < 0.5f;
    }

    public Car carById(int id) {
        for (Car c : cars) if (c.active && c.id == id) return c;
        return null;
    }

    public Zombie zombieById(int id) {
        for (Zombie z : zombies) if (z.active && z.id == id) return z;
        return null;
    }

    public Drop dropById(int id) {
        for (Drop d : drops) if (d.active && d.id == id) return d;
        return null;
    }
}
