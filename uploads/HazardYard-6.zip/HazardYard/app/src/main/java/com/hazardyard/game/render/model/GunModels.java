package com.hazardyard.game.render.model;

import com.hazardyard.game.core.WeaponDef;

/**
 * One low-poly model per weapon, authored in soldier space: x forward, the barrel axis at about
 * (y = 0.8, z = 14.7), the muzzle exactly at {@code PLAYER_RADIUS + barrelLength} so the muzzle flash
 * and bullets leave from the visible barrel tip. Each gun comes in two variants: held (with the
 * soldier's forearms and gloves) and display (just the gun, for pickups on the ground).
 */
public final class GunModels {
    private GunModels() {}

    static final int METAL_DARK = 0xFF454C58;
    static final int METAL = 0xFF6E7888;
    static final int METAL_LIGHT = 0xFFB4BFCF;
    static final int POLYMER = 0xFF313843;
    static final int WOOD = 0xFF9A6A38;
    static final float Y = 0.8f;
    static final float Z = 14.7f;

    private static final Mesh[] HELD = new Mesh[WeaponDef.ALL.length];
    private static final Mesh[] DISPLAY = new Mesh[WeaponDef.ALL.length];
    private static final float[] CENTER_X = new float[WeaponDef.ALL.length];

    public static synchronized Mesh held(int weaponId) {
        int id = clamp(weaponId);
        if (HELD[id] == null) HELD[id] = build(id, true);
        return HELD[id];
    }

    public static synchronized Mesh display(int weaponId) {
        int id = clamp(weaponId);
        if (DISPLAY[id] == null) {
            DISPLAY[id] = build(id, false);
            CENTER_X[id] = centerX(DISPLAY[id]);
        }
        return DISPLAY[id];
    }

    /** Model-space x of the middle of the display model, so a pickup can spin the gun about its centre. */
    public static synchronized float displayCenterX(int weaponId) {
        display(weaponId);
        return CENTER_X[clamp(weaponId)];
    }

    private static int clamp(int id) {
        return id >= 0 && id < WeaponDef.ALL.length ? id : WeaponDef.PISTOL;
    }

    private static float centerX(Mesh m) {
        float lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
        for (int i = 0; i < m.vertexCount(); i++) {
            float x = m.verts[i * 3];
            lo = Math.min(lo, x);
            hi = Math.max(hi, x);
        }
        return (lo + hi) * 0.5f;
    }

    private static Mesh build(int id, boolean hands) {
        MeshBuilder b = new MeshBuilder();
        b.group(SoldierModel.G_GUN);
        float muzzle = 12f + WeaponDef.ALL[id].barrelLength;
        switch (id) {
            case WeaponDef.RIFLE: rifle(b, muzzle, hands); break;
            case WeaponDef.SHOTGUN: shotgun(b, muzzle, hands); break;
            case WeaponDef.SMG: smg(b, muzzle, hands); break;
            case WeaponDef.SNIPER: sniper(b, muzzle, hands); break;
            case WeaponDef.MAGNUM: magnum(b, muzzle, hands); break;
            case WeaponDef.PLASMA: plasma(b, muzzle, hands); break;
            case WeaponDef.LMG: lmg(b, muzzle, hands); break;
            case WeaponDef.REVOLVER: revolver(b, muzzle, hands); break;
            case WeaponDef.DOUBLE_BARREL: doubleBarrel(b, muzzle, hands); break;
            case WeaponDef.HUNTING_RIFLE: huntingRifle(b, muzzle, hands); break;
            case WeaponDef.AK: ak(b, muzzle, hands); break;
            case WeaponDef.DMR: dmr(b, muzzle, hands); break;
            case WeaponDef.MACHINE_PISTOL: machinePistol(b, muzzle, hands); break;
            case WeaponDef.KNIFE: knife(b, hands); break;
            case WeaponDef.BAT: bat(b, hands); break;
            case WeaponDef.CROWBAR: crowbar(b, hands); break;
            case WeaponDef.MACHETE: machete(b, hands); break;
            case WeaponDef.AXE: axe(b, hands); break;
            case WeaponDef.PICKAXE: pickaxe(b, hands); break;
            case WeaponDef.FISTS: hands(b, hands, 8.5f, Z - 0.5f, 8.5f, Z - 0.5f + 0f); break;
            default: pistol(b, muzzle, hands); break;
        }
        return b.build();
    }

    // ------------------------------------------------------------------ hands

    /** Forearms and gloves: right hand at (rx, rz) near the grip, left hand at (lx, lz) on the support. */
    private static void hands(MeshBuilder b, boolean on, float rx, float rz, float lx, float lz) {
        if (!on) return;
        b.accent(false).emissive(false);
        b.color(SoldierModel.FATIGUE).beam(SoldierModel.ELBOW_R_X, SoldierModel.ELBOW_R_Y, SoldierModel.ELBOW_Z, rx, Y + 0.9f, rz, 2.7f, 2.7f);
        b.color(SoldierModel.FATIGUE).beam(SoldierModel.ELBOW_L_X, SoldierModel.ELBOW_L_Y, SoldierModel.ELBOW_Z, lx, Y - 0.9f, lz, 2.7f, 2.7f);
        b.color(SoldierModel.GLOVE)
                .box(rx - 1.3f, Y - 0.3f, rz - 1.3f, rx + 1.3f, Y + 2.3f, rz + 1.3f)
                .box(lx - 1.3f, Y - 2.4f, lz - 1.3f, lx + 1.3f, Y + 0.2f, lz + 1.3f);
    }

    // ------------------------------------------------------------------ guns

    private static void pistol(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL_DARK).box(8.2f, Y - 1.1f, Z - 1.2f, muzzle - 2.5f, Y + 1.1f, Z - 0.1f);           // frame
        b.color(METAL).box(8.4f, Y - 1.0f, Z - 0.1f, muzzle, Y + 1.0f, Z + 1.9f);                          // slide
        b.color(METAL_DARK).box(muzzle - 1.4f, Y - 0.5f, Z + 0.5f, muzzle + 0.1f, Y + 0.5f, Z + 1.3f);     // muzzle
        b.color(METAL_DARK).box(muzzle - 1.8f, Y - 0.3f, Z + 1.9f, muzzle - 1.0f, Y + 0.3f, Z + 2.5f);      // front sight
        b.color(POLYMER).beam(9.8f, Y, Z - 1.0f, 8.6f, Y, Z - 4.2f, 2.3f, 3.0f);                            // grip
        hands(b, hands, 9.4f, Z - 2.6f, 9.0f, Z - 3.2f);
    }

    private static void rifle(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL_DARK).box(5.0f, Y - 1.2f, Z - 1.5f, 19.0f, Y + 1.3f, Z + 1.7f);                       // receiver
        b.color(POLYMER).box(17.5f, Y - 1.4f, Z - 1.3f, 24.0f, Y + 1.5f, Z + 1.3f);                         // handguard
        b.color(METAL).tube(24.0f, Y, Z + 0.1f, muzzle - 1.4f, Y, Z + 0.1f, 1.0f, 1.0f, 6);               // barrel
        b.color(METAL_DARK).box(muzzle - 1.5f, Y - 0.8f, Z - 0.7f, muzzle, Y + 0.8f, Z + 0.9f);             // flash hider
        b.color(POLYMER).beam(6.0f, Y, Z + 0.5f, 1.4f, Y, Z - 0.1f, 2.3f, 3.9f);                            // stock
        b.color(METAL).box(10.2f, Y - 0.9f, Z - 5.0f, 13.4f, Y + 0.9f, Z - 1.5f);                           // magazine
        b.color(METAL_DARK).box(8.0f, Y - 0.5f, Z + 1.7f, 14.0f, Y + 0.5f, Z + 3.0f);                       // carry handle
        b.color(METAL_DARK).box(22.4f, Y - 0.4f, Z + 1.3f, 23.2f, Y + 0.4f, Z + 2.6f);                      // front sight
        b.color(POLYMER).beam(9.6f, Y, Z - 1.2f, 8.5f, Y, Z - 4.2f, 2.0f, 2.6f);                            // grip
        hands(b, hands, 9.0f, Z - 2.6f, 19.6f, Z - 0.7f);
    }

    private static void shotgun(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL).tube(8.0f, Y, Z + 1.0f, muzzle, Y, Z + 1.0f, 1.35f, 1.35f, 6);                       // barrel
        b.color(METAL_DARK).tube(10.0f, Y, Z - 0.9f, muzzle - 3.0f, Y, Z - 0.9f, 1.1f, 1.1f, 6);            // magazine tube
        b.color(METAL_DARK).box(5.0f, Y - 1.2f, Z - 0.6f, 12.5f, Y + 1.3f, Z + 2.4f);                       // receiver
        b.color(WOOD).box(14.0f, Y - 1.9f, Z - 2.4f, 20.0f, Y + 2.1f, Z - 0.2f);                            // pump
        b.color(WOOD).beam(6.0f, Y, Z + 0.4f, 1.0f, Y, Z - 0.5f, 2.4f, 4.4f);                               // stock
        b.color(WOOD).beam(7.6f, Y, Z - 0.3f, 6.8f, Y, Z - 3.2f, 2.0f, 2.6f);                               // grip
        b.color(METAL_DARK).box(muzzle - 0.9f, Y - 0.5f, Z + 2.0f, muzzle - 0.1f, Y + 0.5f, Z + 2.7f);      // bead sight
        hands(b, hands, 7.4f, Z - 1.7f, 17.0f, Z - 1.4f);
    }

    private static void smg(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL_DARK).box(6.0f, Y - 1.3f, Z - 1.5f, 18.0f, Y + 1.4f, Z + 1.5f);                       // receiver
        b.color(METAL).tube(18.0f, Y, Z + 0.1f, 20.8f, Y, Z + 0.1f, 1.2f, 1.2f, 6);                         // barrel
        b.color(POLYMER).tube(19.5f, Y, Z + 0.1f, muzzle, Y, Z + 0.1f, 1.35f, 1.35f, 6);                    // suppressor
        b.color(METAL).box(9.4f, Y - 0.9f, Z - 7.0f, 11.8f, Y + 0.9f, Z - 1.5f);                            // long magazine
        b.color(METAL).box(1.6f, Y - 0.6f, Z - 0.1f, 6.0f, Y + 0.6f, Z + 0.9f);                             // folded stock
        b.color(METAL_DARK).box(8.0f, Y - 0.5f, Z + 1.5f, 12.0f, Y + 0.5f, Z + 2.3f);                       // sight
        b.color(POLYMER).beam(8.2f, Y, Z - 1.3f, 7.2f, Y, Z - 4.0f, 2.0f, 2.6f);                            // grip
        b.color(POLYMER).beam(14.4f, Y, Z - 1.4f, 14.2f, Y, Z - 3.4f, 1.8f, 2.2f);                          // foregrip
        hands(b, hands, 7.8f, Z - 2.4f, 14.3f, Z - 2.9f);
    }

    private static void sniper(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL).tube(14.0f, Y, Z + 0.4f, muzzle - 1.4f, Y, Z + 0.4f, 1.05f, 1.05f, 6);                 // long barrel
        b.color(METAL_DARK).tube(15.0f, Y, Z + 0.4f, 24.0f, Y, Z + 0.4f, 1.15f, 1.15f, 6);                  // barrel shroud
        b.color(METAL_DARK).box(muzzle - 1.5f, Y - 0.9f, Z - 0.5f, muzzle, Y + 0.9f, Z + 1.3f);             // muzzle brake
        b.color(METAL_DARK).box(5.0f, Y - 1.2f, Z - 1.1f, 16.0f, Y + 1.3f, Z + 1.9f);                       // receiver
        b.color(POLYMER).tube(7.5f, Y, Z + 4.0f, 16.0f, Y, Z + 4.0f, 1.55f, 1.55f, 6);                       // scope body
        b.color(POLYMER).tube(16.0f, Y, Z + 4.0f, 18.0f, Y, Z + 4.0f, 1.55f, 2.05f, 6);                      // scope bell
        b.emissive(true).color(0xFF9FE8FF).box(18.0f, Y - 1.2f, Z + 3.1f, 18.3f, Y + 1.2f, Z + 4.9f).emissive(false);
        b.color(METAL_DARK).box(9.0f, Y - 0.5f, Z + 1.9f, 10.2f, Y + 0.5f, Z + 3.0f);                       // scope mounts
        b.color(METAL_DARK).box(13.4f, Y - 0.5f, Z + 1.9f, 14.6f, Y + 0.5f, Z + 3.0f);
        b.color(POLYMER).beam(6.0f, Y, Z + 0.1f, 0.6f, Y, Z - 1.0f, 2.3f, 4.8f);                            // stock
        b.color(METAL).box(8.4f, Y - 0.8f, Z - 3.6f, 11.0f, Y + 0.8f, Z - 1.1f);                            // magazine
        b.color(POLYMER).beam(8.8f, Y, Z - 1.2f, 7.8f, Y, Z - 4.0f, 2.0f, 2.6f);                            // grip
        hands(b, hands, 8.4f, Z - 2.5f, 15.0f, Z - 1.6f);
    }

    private static void magnum(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL_LIGHT).box(11.0f, Y - 0.9f, Z + 0.4f, muzzle, Y + 0.9f, Z + 2.0f);                    // barrel
        b.color(METAL).box(12.0f, Y - 0.8f, Z - 0.5f, muzzle - 1.5f, Y + 0.8f, Z + 0.4f);                   // under-lug
        b.color(METAL).tube(9.0f, Y, Z + 0.9f, 12.8f, Y, Z + 0.9f, 2.25f, 2.25f, 6);                         // cylinder
        b.color(METAL_DARK).box(6.0f, Y - 1.1f, Z - 1.1f, 10.0f, Y + 1.2f, Z + 2.1f);                       // frame
        b.color(METAL_DARK).box(5.2f, Y - 0.4f, Z + 2.1f, 6.8f, Y + 0.4f, Z + 3.3f);                        // hammer
        b.color(WOOD).beam(7.8f, Y, Z - 0.8f, 5.8f, Y, Z - 4.6f, 2.5f, 3.4f);                               // grip
        b.color(METAL_DARK).box(muzzle - 1.2f, Y - 0.4f, Z + 2.0f, muzzle - 0.3f, Y + 0.4f, Z + 2.8f);      // sight
        hands(b, hands, 7.0f, Z - 2.7f, 7.6f, Z - 3.3f);
    }

    private static void plasma(MeshBuilder b, float muzzle, boolean hands) {
        final int purple = 0xFFB066FF;
        b.color(0xFF3A424F).box(5.0f, Y - 1.4f, Z - 1.6f, 17.0f, Y + 1.6f, Z + 2.0f);                       // body
        b.color(0xFF566073).box(7.0f, Y - 1.5f, Z + 2.0f, 15.0f, Y + 1.5f, Z + 3.0f);                       // top fin
        b.emissive(true).color(purple).box(6.5f, Y + 1.55f, Z - 0.4f, 15.5f, Y + 1.8f, Z + 0.8f).emissive(false);
        b.color(METAL_DARK).tube(17.0f, Y, Z + 0.2f, muzzle, Y, Z + 0.2f, 1.05f, 1.05f, 6);                 // barrel
        b.emissive(true).color(purple);                                                                     // glowing coil rings
        for (float x = 18.6f; x < muzzle - 1.2f; x += 2.5f) b.tube(x, Y, Z + 0.2f, x + 0.9f, Y, Z + 0.2f, 1.75f, 1.75f, 6);
        b.color(0xFFE8D4FF).tube(muzzle - 1.0f, Y, Z + 0.2f, muzzle, Y, Z + 0.2f, 1.45f, 1.45f, 6);         // emitter
        b.emissive(false);
        b.color(METAL_DARK).box(1.6f, Y - 0.8f, Z - 0.6f, 5.2f, Y + 0.8f, Z + 1.6f);                        // stock block
        b.color(0xFF6D45C2).box(9.0f, Y - 0.9f, Z - 4.8f, 13.0f, Y + 0.9f, Z - 1.6f);                       // energy cell
        b.color(POLYMER).beam(8.4f, Y, Z - 1.4f, 7.6f, Y, Z - 4.2f, 2.2f, 3.0f);                            // grip
        hands(b, hands, 8.0f, Z - 2.6f, 14.5f, Z - 1.9f);
    }

    private static void lmg(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL_DARK).box(5.0f, Y - 1.4f, Z - 1.6f, 19.0f, Y + 1.5f, Z + 2.0f);                       // receiver
        b.color(0xFF5E6E3C).box(9.0f, Y + 1.5f, Z - 3.8f, 15.5f, Y + 4.6f, Z + 0.2f);                       // ammo box
        b.color(0xFF47552D).box(9.0f, Y + 1.5f, Z + 0.2f, 15.5f, Y + 4.6f, Z + 0.8f);                       // ammo box lid
        b.color(METAL).tube(19.0f, Y, Z + 0.2f, muzzle - 1.4f, Y, Z + 0.2f, 1.25f, 1.25f, 6);               // barrel
        b.color(METAL_DARK).tube(19.0f, Y, Z + 0.2f, 25.5f, Y, Z + 0.2f, 1.5f, 1.5f, 6);                    // heat shield
        b.color(METAL_DARK).box(muzzle - 1.6f, Y - 0.9f, Z - 0.6f, muzzle, Y + 0.9f, Z + 1.0f);             // flash hider
        b.color(POLYMER).beam(6.0f, Y, Z + 0.4f, 1.0f, Y, Z - 0.4f, 2.5f, 4.6f);                            // stock
        b.color(METAL_DARK).box(8.0f, Y - 0.6f, Z + 2.0f, 15.0f, Y + 0.6f, Z + 3.4f);                       // carry handle
        b.color(METAL).beam(22.0f, Y - 0.7f, Z - 0.4f, 23.8f, Y - 2.4f, Z - 2.6f, 0.8f, 0.8f);               // folded bipod
        b.color(METAL).beam(22.0f, Y + 0.7f, Z - 0.4f, 23.8f, Y + 2.4f, Z - 2.6f, 0.8f, 0.8f);
        b.color(POLYMER).beam(8.8f, Y, Z - 1.4f, 7.8f, Y, Z - 4.2f, 2.0f, 2.6f);                            // grip
        hands(b, hands, 8.4f, Z - 2.6f, 17.2f, Z - 1.4f);
    }

    private static void revolver(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL_LIGHT).box(10.0f, Y - 0.9f, Z + 0.4f, muzzle, Y + 0.9f, Z + 1.9f);                    // barrel
        b.color(METAL).box(11.0f, Y - 0.7f, Z - 0.5f, muzzle - 1.5f, Y + 0.7f, Z + 0.4f);                   // under-lug
        b.color(METAL).tube(8.0f, Y, Z + 0.8f, 11.4f, Y, Z + 0.8f, 2.0f, 2.0f, 6);                           // cylinder
        b.color(METAL_DARK).box(5.5f, Y - 1.0f, Z - 1.0f, 9.0f, Y + 1.1f, Z + 1.9f);                        // frame
        b.color(METAL_DARK).box(4.8f, Y - 0.4f, Z + 1.9f, 6.2f, Y + 0.4f, Z + 3.0f);                        // hammer
        b.color(WOOD).beam(7.0f, Y, Z - 0.8f, 5.2f, Y, Z - 4.4f, 2.3f, 3.2f);                               // grip
        b.color(METAL_DARK).box(muzzle - 1.1f, Y - 0.4f, Z + 1.9f, muzzle - 0.3f, Y + 0.4f, Z + 2.6f);      // sight
        hands(b, hands, 6.4f, Z - 2.7f, 7.0f, Z - 3.2f);
    }

    private static void doubleBarrel(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL).tube(8.0f, Y - 0.95f, Z + 0.8f, muzzle, Y - 0.95f, Z + 0.8f, 1.2f, 1.2f, 6);          // left barrel
        b.color(METAL).tube(8.0f, Y + 0.95f, Z + 0.8f, muzzle, Y + 0.95f, Z + 0.8f, 1.2f, 1.2f, 6);          // right barrel
        b.color(METAL_DARK).box(5.0f, Y - 1.5f, Z - 0.6f, 10.5f, Y + 1.6f, Z + 2.3f);                       // action
        b.color(WOOD).box(12.0f, Y - 1.7f, Z - 1.5f, 18.0f, Y + 1.8f, Z + 0.3f);                            // fore-end
        b.color(WOOD).beam(6.0f, Y, Z + 0.4f, 1.0f, Y, Z - 0.7f, 2.4f, 4.4f);                               // stock
        b.color(METAL_DARK).box(muzzle - 0.9f, Y - 0.4f, Z + 2.0f, muzzle - 0.1f, Y + 0.4f, Z + 2.7f);      // bead sight
        hands(b, hands, 7.0f, Z - 1.7f, 15.0f, Z - 1.0f);
    }

    private static void huntingRifle(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL).tube(12.0f, Y, Z + 0.5f, muzzle, Y, Z + 0.5f, 0.95f, 0.95f, 6);                      // barrel
        b.color(METAL_DARK).box(5.0f, Y - 1.1f, Z - 0.8f, 14.0f, Y + 1.2f, Z + 1.9f);                       // receiver
        b.color(WOOD).box(13.0f, Y - 1.4f, Z - 1.4f, 21.0f, Y + 1.5f, Z + 0.5f);                            // fore-end
        b.color(WOOD).beam(6.0f, Y, Z + 0.3f, 0.6f, Y, Z - 1.0f, 2.3f, 4.8f);                               // stock
        b.color(POLYMER).tube(7.0f, Y, Z + 3.4f, 14.5f, Y, Z + 3.4f, 1.25f, 1.25f, 6);                      // scope
        b.emissive(true).color(0xFF9FE8FF).box(14.5f, Y - 1.0f, Z + 2.7f, 14.8f, Y + 1.0f, Z + 4.1f).emissive(false);
        b.color(METAL_DARK).box(8.5f, Y - 0.4f, Z + 1.9f, 9.5f, Y + 0.4f, Z + 2.4f);                        // scope mounts
        b.color(METAL_DARK).box(12.0f, Y - 0.4f, Z + 1.9f, 13.0f, Y + 0.4f, Z + 2.4f);
        b.color(WOOD).beam(8.6f, Y, Z - 0.8f, 7.6f, Y, Z - 3.8f, 2.0f, 2.6f);                               // grip
        hands(b, hands, 8.2f, Z - 2.4f, 16.0f, Z - 0.8f);
    }

    private static void ak(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL_DARK).box(5.0f, Y - 1.2f, Z - 1.5f, 18.0f, Y + 1.3f, Z + 1.7f);                       // receiver
        b.color(WOOD).box(17.0f, Y - 1.4f, Z - 1.3f, 25.0f, Y + 1.5f, Z + 1.2f);                            // wooden handguard
        b.color(METAL).tube(25.0f, Y, Z + 0.1f, muzzle - 1.0f, Y, Z + 0.1f, 0.95f, 0.95f, 6);               // barrel
        b.color(METAL_DARK).box(muzzle - 1.5f, Y - 0.7f, Z - 0.6f, muzzle, Y + 0.7f, Z + 0.9f);             // muzzle brake
        b.color(WOOD).beam(6.0f, Y, Z + 0.4f, 1.0f, Y, Z - 0.3f, 2.3f, 4.2f);                               // wooden stock
        b.color(METAL).beam(11.0f, Y, Z - 1.4f, 13.4f, Y, Z - 6.4f, 1.8f, 2.0f);                            // banana magazine
        b.color(METAL_DARK).box(23.0f, Y - 0.4f, Z + 1.2f, 24.0f, Y + 0.4f, Z + 2.5f);                      // front sight
        b.color(WOOD).beam(9.4f, Y, Z - 1.2f, 8.3f, Y, Z - 4.2f, 2.0f, 2.6f);                               // grip
        hands(b, hands, 8.8f, Z - 2.6f, 20.0f, Z - 0.6f);
    }

    private static void dmr(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL).tube(14.0f, Y, Z + 0.3f, muzzle - 1.2f, Y, Z + 0.3f, 1.0f, 1.0f, 6);                 // barrel
        b.color(METAL_DARK).tube(16.0f, Y, Z + 0.3f, 24.0f, Y, Z + 0.3f, 1.2f, 1.2f, 6);                    // handguard
        b.color(METAL_DARK).box(muzzle - 1.4f, Y - 0.8f, Z - 0.4f, muzzle, Y + 0.8f, Z + 1.0f);             // muzzle brake
        b.color(METAL_DARK).box(5.0f, Y - 1.2f, Z - 1.3f, 16.0f, Y + 1.3f, Z + 1.8f);                       // receiver
        b.color(POLYMER).tube(7.0f, Y, Z + 3.8f, 15.0f, Y, Z + 3.8f, 1.4f, 1.4f, 6);                        // scope
        b.emissive(true).color(0xFF9FE8FF).box(15.0f, Y - 1.1f, Z + 3.0f, 15.3f, Y + 1.1f, Z + 4.6f).emissive(false);
        b.color(POLYMER).beam(6.0f, Y, Z + 0.2f, 0.8f, Y, Z - 0.9f, 2.3f, 4.6f);                            // stock
        b.color(METAL).box(9.2f, Y - 0.8f, Z - 4.6f, 12.0f, Y + 0.8f, Z - 1.3f);                            // magazine
        b.color(POLYMER).beam(8.8f, Y, Z - 1.2f, 7.8f, Y, Z - 4.0f, 2.0f, 2.6f);                            // grip
        hands(b, hands, 8.6f, Z - 2.5f, 16.5f, Z - 1.3f);
    }

    private static void machinePistol(MeshBuilder b, float muzzle, boolean hands) {
        b.color(METAL_DARK).box(7.0f, Y - 1.2f, Z - 1.3f, 15.5f, Y + 1.3f, Z + 1.3f);                       // body
        b.color(METAL).tube(15.5f, Y, Z + 0.1f, muzzle, Y, Z + 0.1f, 1.1f, 1.1f, 6);                        // barrel
        b.color(METAL).box(10.0f, Y - 0.8f, Z - 7.5f, 12.2f, Y + 0.8f, Z - 1.3f);                           // long magazine
        b.color(POLYMER).beam(8.8f, Y, Z - 1.1f, 7.8f, Y, Z - 4.0f, 2.1f, 2.8f);                            // grip
        b.color(METAL_DARK).box(8.0f, Y - 0.4f, Z + 1.3f, 12.0f, Y + 0.4f, Z + 2.0f);                       // sight
        hands(b, hands, 8.6f, Z - 2.4f, 9.2f, Z - 3.0f);
    }

    // ------------------------------------------------------------------ melee (held forward, swung round the body)

    private static void knife(MeshBuilder b, boolean hands) {
        b.color(POLYMER).box(8.0f, Y - 1.0f, Z - 1.0f, 12.5f, Y + 1.0f, Z + 0.9f);                          // handle
        b.color(METAL_DARK).box(12.5f, Y - 1.1f, Z - 1.2f, 13.3f, Y + 1.1f, Z + 1.1f);                      // guard
        b.color(METAL_LIGHT).box(13.3f, Y - 0.3f, Z - 1.5f, 20.0f, Y + 0.3f, Z + 1.5f);                     // blade
        b.color(METAL_LIGHT).box(20.0f, Y - 0.25f, Z - 0.9f, 23.0f, Y + 0.25f, Z + 0.6f);                   // tip
        hands(b, hands, 10.0f, Z - 0.2f, 5.0f, Z - 4.0f);
    }

    private static void bat(MeshBuilder b, boolean hands) {
        b.color(0xFF1F2630).tube(8.0f, Y, Z, 15.0f, Y, Z, 0.9f, 0.95f, 6);                                  // taped grip
        b.color(WOOD).tube(15.0f, Y, Z, 24.0f, Y, Z, 1.0f, 1.9f, 6);                                        // taper
        b.color(WOOD).tube(24.0f, Y, Z, 35.0f, Y, Z, 1.9f, 2.1f, 6);                                        // barrel
        b.color(0xFF7A5028).box(34.6f, Y - 1.5f, Z - 1.5f, 35.4f, Y + 1.5f, Z + 1.5f);                      // end cap
        hands(b, hands, 10.0f, Z - 0.2f, 13.5f, Z - 0.2f);
    }

    private static void crowbar(MeshBuilder b, boolean hands) {
        b.color(0xFF9A2A2A).tube(8.0f, Y, Z, 33.0f, Y, Z, 0.85f, 0.85f, 6);                                 // shaft
        b.color(METAL_DARK).beam(33.0f, Y, Z, 36.0f, Y + 2.4f, Z, 1.5f, 1.5f);                              // the hook
        b.color(METAL_DARK).beam(36.0f, Y + 2.4f, Z, 35.0f, Y + 4.4f, Z, 1.5f, 1.5f);
        b.color(METAL).box(6.5f, Y - 0.9f, Z - 0.8f, 8.0f, Y + 0.9f, Z + 0.8f);                             // chisel end
        hands(b, hands, 11.0f, Z - 0.2f, 15.5f, Z - 0.2f);
    }

    private static void machete(MeshBuilder b, boolean hands) {
        b.color(POLYMER).box(8.0f, Y - 1.0f, Z - 1.0f, 13.0f, Y + 1.0f, Z + 1.0f);                          // handle
        b.color(METAL_DARK).box(13.0f, Y - 1.1f, Z - 1.5f, 13.8f, Y + 1.1f, Z + 1.6f);                      // guard
        b.color(METAL_LIGHT).box(13.8f, Y - 0.3f, Z - 1.9f, 28.0f, Y + 0.3f, Z + 1.9f);                     // blade
        b.color(METAL_LIGHT).box(28.0f, Y - 0.25f, Z - 1.5f, 31.0f, Y + 0.25f, Z + 1.6f);                   // belly
        b.color(METAL).box(31.0f, Y - 0.2f, Z - 0.8f, 32.5f, Y + 0.2f, Z + 1.2f);                           // tip
        hands(b, hands, 10.5f, Z - 0.2f, 5.0f, Z - 4.0f);
    }

    private static void axe(MeshBuilder b, boolean hands) {
        b.color(WOOD).tube(8.0f, Y, Z, 31.0f, Y, Z, 0.95f, 0.95f, 6);                                       // haft
        b.color(0xFFB02828).box(27.0f, Y - 1.0f, Z - 1.4f, 32.0f, Y + 1.0f, Z + 1.4f);                      // head
        b.color(METAL_LIGHT).box(31.0f, Y - 0.35f, Z - 1.2f, 33.0f, Y + 6.0f, Z + 1.2f);                    // blade edge (sweeps out sideways)
        b.color(METAL_DARK).box(25.0f, Y - 1.2f, Z - 1.6f, 27.0f, Y + 1.2f, Z + 1.6f);                      // collar
        hands(b, hands, 10.0f, Z - 0.2f, 14.5f, Z - 0.2f);
    }

    private static void pickaxe(MeshBuilder b, boolean hands) {
        b.color(WOOD).tube(8.0f, Y, Z, 31.0f, Y, Z, 0.95f, 0.95f, 6);                                       // haft
        b.color(METAL_DARK).box(28.5f, Y - 7.0f, Z - 0.9f, 31.5f, Y + 7.0f, Z + 0.9f);                      // the head
        b.color(METAL).box(28.5f, Y - 8.4f, Z - 0.6f, 31.0f, Y - 7.0f, Z + 0.6f);                           // pointed ends
        b.color(METAL).box(28.5f, Y + 7.0f, Z - 0.6f, 31.0f, Y + 8.4f, Z + 0.6f);
        hands(b, hands, 10.0f, Z - 0.2f, 14.5f, Z - 0.2f);
    }
}
