package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.Zone;

/**
 * Draws the safe zone in the world: everything outside the circle is tinted red, the edge of the circle is a glowing blue
 * wall, and while the zone waits (and while it shrinks) a thin white circle shows where it will close to.
 */
final class ZoneRenderer {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    ZoneRenderer() {
        fill.setStyle(Paint.Style.FILL);
        stroke.setStyle(Paint.Style.STROKE);
    }

    void draw(Canvas c, Zone z, float vx0, float vx1, float vy0, float vy1, float scale, float time, boolean lite) {
        if (!z.enabled) return;
        float pad = 60f;
        // the storm: the visible rectangle minus the safe circle
        float dxl = Math.max(Math.abs(vx0 - z.cx), Math.abs(vx1 - z.cx));
        float dyl = Math.max(Math.abs(vy0 - z.cy), Math.abs(vy1 - z.cy));
        boolean fullyInside = !z.collapsed && dxl * dxl + dyl * dyl < z.radius * z.radius;
        if (!fullyInside) {
            path.reset();
            path.setFillType(Path.FillType.EVEN_ODD);
            path.addRect(vx0 - pad, vy0 - pad, vx1 + pad, vy1 + pad, Path.Direction.CW);
            if (!z.collapsed && z.radius > 0.5f) path.addCircle(z.cx, z.cy, z.radius, Path.Direction.CW);
            fill.setColor(0x4DC0281C);
            c.drawPath(path, fill);
            path.setFillType(Path.FillType.WINDING);
        }
        if (!z.collapsed && z.radius > 0.5f) {
            float pulse = 0.5f + 0.5f * (float) Math.sin(time * 3f);
            if (!lite) {
                stroke.setColor(0x334FA0FF);
                stroke.setStrokeWidth(16f / scale + 6f);
                c.drawCircle(z.cx, z.cy, z.radius, stroke);
            }
            stroke.setColor(0xFF4FA0FF);
            stroke.setStrokeWidth(4.5f);
            c.drawCircle(z.cx, z.cy, z.radius, stroke);
            stroke.setColor(0x66FFFFFF);
            stroke.setStrokeWidth(1.4f + pulse);
            c.drawCircle(z.cx, z.cy, z.radius, stroke);
        }
        if (!z.collapsed && z.toRadius > 0.5f && (z.toCx != z.cx || z.toCy != z.cy || z.toRadius != z.radius)) {
            stroke.setColor(0xCCFFFFFF);
            stroke.setStrokeWidth(2.6f);
            c.drawCircle(z.toCx, z.toCy, z.toRadius, stroke);
        }
    }
}
