package com.hazardyard.game.core;

/**
 * Rules for taking things off the ground (guns, vests, first-aid kits). Nothing is ever picked up by walking over
 * it: the player presses Pick Up while standing close to it. The prompt on the HUD and the host use the same
 * functions, so the button only ever shows for a pickup the host will accept.
 */
public final class Pickups {
    private Pickups() {}

    /**
     * True when {@code p} would gain something from {@code pk}: a different gun, or the same gun with a magazine to
     * refill; a vest that gives more armour than the player has; a first-aid kit while health is not full.
     */
    public static boolean worthTaking(Player p, Pickup pk) {
        int item = pk.item;
        if (Items.isWeapon(item)) {
            Weapon w = p.weapon;
            return !(w.def.id == item && w.ammo >= w.def.magSize);
        }
        if (Items.isVest(item)) return p.armor < Items.armorOf(item);
        if (Items.isMedkit(item)) return p.health < GameConfig.PLAYER_MAX_HEALTH;
        return false;
    }

    /**
     * The pad this player can take right now: the nearest active one within {@code reach} that has an
     * open line to the player. Returns -1 when there is none.
     */
    public static int nearest(GameState st, Player p, float reach) {
        if (p == null || !p.alive) return -1;
        float best = reach * reach;
        int found = -1;
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (!pk.active) continue;
            float dx = p.x - pk.x;
            float dy = p.y - pk.y;
            float d2 = dx * dx + dy * dy;
            if (d2 > best) continue;
            if (!worthTaking(p, pk)) continue;
            if (st.collision.raycast(p.x, p.y, pk.x, pk.y) >= 0f) continue;   // a wall is in between
            best = d2;
            found = i;
        }
        return found;
    }

    /** The pad the local player is being offered, for the HUD (-1: none). */
    public static int offered(GameState st, Player p) {
        if (st.phase != GameState.PHASE_PLAYING || p == null || p.isRolling()) return -1;
        return nearest(st, p, GameConfig.PICKUP_REACH);
    }
}
