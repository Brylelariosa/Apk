package com.hazardyard.game.core;

/**
 * The safe zone of a Battleground match: a circle that closes in on the island in {@link #SHRINKS} steps.
 * Fighters outside it take storm damage every second, more with every step, and the last step shrinks the
 * circle to a point, so a match always ends.
 *
 * <p>The match starts calm: the circle covers the whole map. While the zone waits, the next (smaller) circle is
 * already known and shown to the players; when the wait is over the zone shrinks towards it at a steady speed
 * and then waits again. The host runs {@link #step}; clients receive the numbers with every snapshot and only
 * call {@link #advance} to keep the picture smooth in between. Pure Java, no Android types.
 */
public final class Zone {
    /** Shrinks per match; the last one closes the circle completely. */
    public static final int SHRINKS = 7;

    /** Seconds of calm before shrink {@code i + 1} begins (index 0 is the calm at the start of the match). */
    private static final float[] WAIT = {55f, 40f, 30f, 25f, 20f, 12f, 8f};
    /** Seconds shrink {@code i + 1} takes. */
    private static final float[] SHRINK_TIME = {60f, 50f, 45f, 40f, 35f, 30f, 25f};
    /** Radius of the circle after shrink {@code i + 1}, as a fraction of the smaller side of the map. */
    private static final float[] RADIUS_FRACTION = {0.41f, 0.26f, 0.155f, 0.085f, 0.040f, 0.012f, 0f};
    /** Storm damage per second outside the circle once shrink {@code i} has begun (index 0: before the first shrink). */
    private static final float[] DPS = {1f, 2f, 3f, 5f, 7f, 10f, 14f, 22f};

    public boolean enabled;
    /** Shrinks begun so far (0 before the first one). The circle being shown next is shrink {@code phase + 1}. */
    public int phase;
    public boolean shrinking;
    /** The last shrink is over: the circle is a point and the whole map is storm. */
    public boolean collapsed;
    /** The safe circle right now. */
    public float cx, cy, radius;
    /** The circle the zone is heading for (shown on the map while it waits and while it shrinks). */
    public float toCx, toCy, toRadius;
    /** The circle at the moment the current shrink began (host side). */
    private float fromCx, fromCy, fromRadius;
    /** Seconds left of the current wait or shrink, and how long that stage is in all. */
    public float timer, stageLength;
    /** Storm damage per second outside the circle. */
    public float dps;

    private TileMap map;
    private final XorShift rng = new XorShift(0x2B07);

    /** Starts a match: the circle covers the whole map and the first target is chosen. */
    public void reset(TileMap m, int seed) {
        map = m;
        enabled = true;
        rng.setSeed(seed);
        phase = 0;
        shrinking = false;
        collapsed = false;
        cx = m.worldW * 0.5f;
        cy = m.worldH * 0.5f;
        radius = 0.5f * (float) Math.sqrt(m.worldW * (double) m.worldW + m.worldH * (double) m.worldH) + 64f;
        dps = DPS[0];
        chooseTarget();
        timer = WAIT[0];
        stageLength = timer;
    }

    /** Clears the zone (classic matches have none). */
    public void disable() {
        enabled = false;
        map = null;
    }

    /** Host: advances the zone by {@code dt} seconds. */
    public void step(float dt) {
        if (!enabled || collapsed) return;
        timer -= dt;
        if (shrinking) {
            float u = stageLength > 1e-3f ? 1f - Math.max(0f, timer) / stageLength : 1f;
            cx = fromCx + (toCx - fromCx) * u;
            cy = fromCy + (toCy - fromCy) * u;
            radius = fromRadius + (toRadius - fromRadius) * u;
            if (timer <= 0f) {
                cx = toCx;
                cy = toCy;
                radius = toRadius;
                shrinking = false;
                if (phase >= SHRINKS) {
                    collapsed = true;
                    timer = 0f;
                } else {
                    chooseTarget();
                    timer = WAIT[phase];
                    stageLength = timer;
                }
            }
        } else if (timer <= 0f) {
            phase++;
            shrinking = true;
            fromCx = cx;
            fromCy = cy;
            fromRadius = radius;
            timer = SHRINK_TIME[phase - 1];
            stageLength = timer;
            dps = DPS[phase];
        }
    }

    /** Client: smooths the numbers of the last snapshot over the time until the next one arrives. */
    public void advance(float dt) {
        if (!enabled || collapsed) return;
        if (shrinking && timer > 1e-3f) {
            float k = Math.min(1f, dt / timer);
            cx += (toCx - cx) * k;
            cy += (toCy - cy) * k;
            radius += (toRadius - radius) * k;
        }
        timer = Math.max(0f, timer - dt);
    }

    /** True when the point is inside the safe circle. */
    public boolean inside(float x, float y) {
        if (!enabled) return true;
        float dx = x - cx;
        float dy = y - cy;
        return dx * dx + dy * dy <= radius * radius;
    }

    /** Like {@link #inside} for the circle the zone is heading for, with a margin (world units) kept from its edge. */
    public boolean insideTarget(float x, float y, float margin) {
        if (!enabled) return true;
        float dx = x - toCx;
        float dy = y - toCy;
        float r = Math.max(0f, toRadius - margin);
        return dx * dx + dy * dy <= r * r;
    }

    /** How far outside the safe circle the point lies (0 when it is inside). */
    public float distanceOutside(float x, float y) {
        if (!enabled) return 0f;
        float dx = x - cx;
        float dy = y - cy;
        float d = (float) Math.sqrt(dx * dx + dy * dy) - radius;
        return d > 0f ? d : 0f;
    }

    /** Number of the shrink the HUD talks about: the one running, or the one that comes next. */
    public int displayedShrink() {
        return Math.min(SHRINKS, shrinking ? phase : phase + 1);
    }

    /** Copies what a snapshot carries (client side). */
    public void load(int phase, boolean shrinking, boolean collapsed, float cx, float cy, float r,
                     float toCx, float toCy, float toR, float timer, float stage) {
        this.enabled = true;
        this.phase = MathUtil.clamp(phase, 0, SHRINKS);
        this.shrinking = shrinking;
        this.collapsed = collapsed;
        this.cx = cx;
        this.cy = cy;
        this.radius = r;
        this.toCx = toCx;
        this.toCy = toCy;
        this.toRadius = toR;
        this.timer = timer;
        this.stageLength = stage;
        this.dps = DPS[this.phase];
    }

    /** Storm damage per second at a given phase (for the HUD and the tests). */
    public static float dpsOf(int phase) {
        return DPS[MathUtil.clamp(phase, 0, SHRINKS)];
    }

    /** Total seconds of waiting and shrinking in a whole match (the match ends by then at the latest). */
    public static float totalSeconds() {
        float t = 0f;
        for (int i = 0; i < SHRINKS; i++) t += WAIT[i] + SHRINK_TIME[i];
        return t;
    }

    // ------------------------------------------------------------------ choosing the next circle

    /** Picks the circle of shrink {@code phase + 1}: smaller than the current one and entirely inside it, centred on dry land. */
    private void chooseTarget() {
        int next = phase + 1;
        float base = Math.min(map.worldW, map.worldH);
        float r = base * RADIUS_FRACTION[next - 1];
        float slack = Math.max(0f, radius - r);
        float margin = base * 0.08f;
        float bx = cx;
        float by = cy;
        boolean found = false;
        for (int tries = 0; tries < 40 && !found; tries++) {
            float ang = rng.nextFloat() * MathUtil.TWO_PI;
            float dist = (float) Math.sqrt(rng.nextFloat()) * slack * 0.9f;
            float px = cx + (float) Math.cos(ang) * dist;
            float py = cy + (float) Math.sin(ang) * dist;
            if (px < margin || py < margin || px > map.worldW - margin || py > map.worldH - margin) continue;
            if (map.isSolidAt(px, py)) continue;
            bx = px;
            by = py;
            found = true;
        }
        if (!found) {
            bx = MathUtil.clamp(cx, margin, map.worldW - margin);
            by = MathUtil.clamp(cy, margin, map.worldH - margin);
        }
        toCx = bx;
        toCy = by;
        toRadius = Math.min(r, radius);
    }
}
