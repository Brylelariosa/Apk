package com.hazardyard.game.survival;

/** A zombie. The host moves and fights; clients only show what the snapshots say (smoothed in {@link #rx}, {@link #ry}). */
public final class Zombie {
    public static final int WALKER = 0, RUNNER = 1, BRUTE = 2;
    public static final float RADIUS = 13f;

    public int id;
    /** Client: the snapshot this entity was last in (older ones are gone). */
    public int seen;
    public boolean active;
    public int type;
    public float x, y, aim;
    public int hp;
    public boolean attacking;
    /** Smoothed position for drawing (clients) and a walk-cycle clock. */
    public float rx, ry, rAim, walk;
    /** Seconds the zombie has just been hit (draws it flashing). */
    public float hurt;

    // ---- host-side behaviour
    public int target = -1;
    public float attackCd, wanderT, wanderX, wanderY, groanT, stuckT, lastX, lastY, stunT, farT, alertT;
    public boolean hasWander;

    public static int maxHp(int type) {
        return type == BRUTE ? 220 : (type == RUNNER ? 45 : 70);
    }

    public static float speed(int type) {
        return type == BRUTE ? 46f : (type == RUNNER ? 104f : 54f);
    }

    public static int damage(int type) {
        return type == BRUTE ? 28 : (type == RUNNER ? 9 : 14);
    }

    public static String typeName(int type) {
        return type == BRUTE ? "Brute" : (type == RUNNER ? "Runner" : "Walker");
    }
}
