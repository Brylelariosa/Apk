package com.hazardyard.game.survival;

import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.WeaponDef;

/** What can be crafted. Some recipes need a workbench or a campfire within reach. */
public final class Recipes {
    private Recipes() {}

    public static final int NONE = 0, BENCH = 1, FIRE = 2;
    /** How close (world units) a workbench or campfire must be. */
    public static final float STATION_REACH = 110f;

    public static final class Recipe {
        public final String name;
        public final int out, outCount, station;
        /** item, count, item, count... */
        public final int[] in;

        Recipe(String name, int out, int outCount, int station, int... in) {
            this.name = name;
            this.out = out;
            this.outCount = outCount;
            this.station = station;
            this.in = in;
        }
    }

    public static final Recipe[] ALL = {
            new Recipe("Wood Wall", Items.WALL, 1, NONE, Items.WOOD, 3, Items.NAILS, 2),
            new Recipe("Wood Door", Items.DOOR, 1, NONE, Items.WOOD, 3, Items.NAILS, 3),
            new Recipe("Wood Floor", Items.FLOOR, 4, NONE, Items.WOOD, 3, Items.NAILS, 2),
            new Recipe("Campfire", Items.CAMPFIRE, 1, NONE, Items.WOOD, 3, Items.STONE, 3),
            new Recipe("Workbench", Items.WORKBENCH, 1, NONE, Items.WOOD, 8, Items.NAILS, 4, Items.SCRAP, 2),
            new Recipe("Fire Axe", WeaponDef.AXE, 1, NONE, Items.WOOD, 3, Items.STONE, 2, Items.FIBER, 2),
            new Recipe("Pickaxe", WeaponDef.PICKAXE, 1, NONE, Items.WOOD, 3, Items.STONE, 3, Items.FIBER, 2),
            new Recipe("Hoe", Items.HOE, 1, NONE, Items.WOOD, 2, Items.STONE, 2, Items.FIBER, 1),
            new Recipe("Fishing Rod", Items.ROD, 1, NONE, Items.WOOD, 2, Items.FIBER, 3),
            new Recipe("Knife", WeaponDef.KNIFE, 1, NONE, Items.STONE, 1, Items.WOOD, 1, Items.FIBER, 1),
            new Recipe("Baseball Bat", WeaponDef.BAT, 1, BENCH, Items.WOOD, 4, Items.NAILS, 2),
            new Recipe("Bandage x2", Items.BANDAGE, 2, NONE, Items.CLOTH, 2),
            new Recipe("Cooked Fish", Items.FISH_COOKED, 1, FIRE, Items.FISH_RAW, 1),
            new Recipe("Carrot Seeds x2", Items.SEED_CARROT, 2, NONE, Items.CARROT, 1),
            new Recipe("Potato Seeds x2", Items.SEED_POTATO, 2, NONE, Items.POTATO, 1),
            new Recipe("Nails x4", Items.NAILS, 4, BENCH, Items.SCRAP, 1),
            new Recipe("Light Vest", Items.VEST_LIGHT, 1, BENCH, Items.CLOTH, 4, Items.SCRAP, 2),
            new Recipe("Bullets x8", Items.AMMO_BULLETS, 8, BENCH, Items.SCRAP, 3),
            new Recipe("Shells x4", Items.AMMO_SHELLS, 4, BENCH, Items.SCRAP, 2, Items.CLOTH, 1),
            new Recipe("Rifle Rounds x6", Items.AMMO_RIFLE, 6, BENCH, Items.SCRAP, 4),
    };

    /** True when the inventory holds everything the recipe needs (the station is not checked here). */
    public static boolean canAfford(Inventory inv, Recipe r) {
        for (int i = 0; i < r.in.length; i += 2) {
            if (!inv.has(r.in[i], r.in[i + 1])) return false;
        }
        return true;
    }

    /** Takes the ingredients and gives the result; false (nothing changed) if it cannot be done. */
    public static boolean craft(Inventory inv, Recipe r) {
        if (!canAfford(inv, r)) return false;
        // the result must fit: count the free room first
        int room = 0;
        int max = Items.stackMax(r.out);
        for (int i = 0; i < Inventory.SLOTS; i++) {
            if (inv.item[i] == r.out) room += max - inv.count[i];
            else if (inv.isEmpty(i)) room += max;
        }
        // ingredients that vanish completely free their slots too, so only a nearly full pack can fail
        if (room < r.outCount && inv.freeSlots() == 0) return false;
        for (int i = 0; i < r.in.length; i += 2) inv.remove(r.in[i], r.in[i + 1]);
        return inv.add(r.out, r.outCount) == 0 || true;
    }
}
