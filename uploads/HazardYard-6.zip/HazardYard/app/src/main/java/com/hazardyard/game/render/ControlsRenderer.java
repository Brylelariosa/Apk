package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Items;
import com.hazardyard.game.survival.Interaction;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.Weapon;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.input.ControlGeometry;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.input.VirtualJoystick;
import com.hazardyard.game.settings.ControlSettings;

/**
 * Draws the on-screen controls: both sticks, the fire / reload / dodge / pause buttons and the Pick Up
 * button (shown only while a weapon is within reach). It uses the same
 * {@link ControlGeometry} as the touch routing, so what is drawn is exactly what is touchable. Used
 * live during a match and by the layout editor (with static "idle" states). Allocation-free.
 */
public final class ControlsRenderer {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Typeface bold = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    private final Typeface medium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
    /** The pad the Pick Up button showed last frame and when it appeared, for its pop-in animation. */
    private int shownPad = -1;
    private float shownSince;

    public ControlsRenderer() {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
    }

    /** The live controls of a running match. */
    public void draw(Canvas c, InputController in, GameState st, Player me, float d, float time) {
        ControlSettings s = in.settings();
        ControlGeometry g = in.geometry();
        float op = s.opacity;
        float fireRing = s.stickFires() ? s.fireStartLevel() : 0f;
        drawStick(c, in.moveStick, g, ControlSettings.MOVE, s.moveFloating, false, s.aimDeadZone, 0f, op, d, false);
        drawStick(c, in.aimStick, g, ControlSettings.AIM, s.aimFloating, true, s.aimDeadZone, fireRing, op, d, in.isStickFiring());
        if (s.fireButtonEnabled()) drawFire(c, g, in.isFireHeld(), op, d);
        drawReload(c, g, me.weapon, in.isReloadHeld(), op, d);
        drawDodge(c, g, me, in.isDodgeHeld(), op, d);
        drawPause(c, g, op, d);
        int pad = in.pickupOffered();
        if (st.survival != null) {
            if (pad >= 0 && inter.find(st.survival, me)) {
                if (shownPad != 0) {
                    shownPad = 0;
                    shownSince = time;
                }
                float age = time - shownSince;
                float pop = age >= 0.2f ? 1f : easeOutBack(Math.max(0f, age) / 0.2f);
                drawInteract(c, g, inter, in.isPickupHeld(), op, d, time, pop);
            } else {
                shownPad = -1;
            }
        } else if (pad >= 0 && pad < st.pickups.length) {
            if (pad != shownPad) {
                shownPad = pad;
                shownSince = time;
            }
            Pickup pk = st.pickups[pad];
            float age = time - shownSince;
            float pop = age >= 0.2f ? 1f : easeOutBack(Math.max(0f, age) / 0.2f);
            drawPickup(c, g, pk.item, me, in.isPickupHeld(), op, d, time, pop);
        } else {
            shownPad = -1;
        }
    }

    /** Overshoots a little before settling at 1: the button "pops" in. */
    private static float easeOutBack(float t) {
        float k = 1.70158f;
        float u = t - 1f;
        return 1f + (k + 1f) * u * u * u + k * u * u;
    }

    private final Interaction inter = new Interaction();
    private Player sample;

    /** A fighter holding the pistol, for the layout editor's sample Pick Up button. */
    private Player samplePlayer() {
        if (sample == null) {
            sample = new Player(0);
            sample.weapon.equip(WeaponDef.byId(WeaponDef.PISTOL));
        }
        return sample;
    }

    /** Idle controls for the layout editor; {@code selected} gets a highlight ring (-1 = none). */
    public void drawIdle(Canvas c, ControlGeometry g, ControlSettings s, int selected, float d) {
        float op = s.opacity;
        VirtualJoystick idle = new VirtualJoystick();
        float fireRing = s.stickFires() ? s.fireStartLevel() : 0f;
        drawStick(c, idle, g, ControlSettings.MOVE, s.moveFloating, false, s.aimDeadZone, 0f, op, d, false);
        drawStick(c, idle, g, ControlSettings.AIM, s.aimFloating, true, s.aimDeadZone, fireRing, op, d, false);
        if (s.fireButtonEnabled()) drawFire(c, g, false, op, d);
        drawReload(c, g, null, false, op, d);
        drawDodge(c, g, null, false, op, d);
        drawPause(c, g, op, d);
        // The Pick Up button only exists next to a weapon; the editor shows it with a sample weapon so it can be placed.
        drawPickup(c, g, WeaponDef.SHOTGUN, samplePlayer(), false, op, d, 0f, 1f);
        if (selected >= 0 && selected < ControlSettings.CONTROL_COUNT && (selected != ControlSettings.FIRE || s.fireButtonEnabled())) {
            stroke.setColor(Palette.ACCENT);
            stroke.setStrokeWidth(2.4f * d);
            float r = g.r[selected] + 7f * d;
            if (selected == ControlSettings.PAUSE) {
                rect.set(g.cx[selected] - r, g.cy[selected] - r, g.cx[selected] + r, g.cy[selected] + r);
                c.drawRoundRect(rect, 12f * d, 12f * d, stroke);
            } else {
                c.drawCircle(g.cx[selected], g.cy[selected], r, stroke);
            }
        }
    }

    // ------------------------------------------------------------------ sticks

    /**
     * @param deadZone ring (as a fraction of the radius) where aiming starts, drawn on the aim stick
     * @param fireRing ring where the gun starts firing, drawn on the aim stick when the stick fires (0 = none)
     * @param firing   the stick is pulling the trigger: it is drawn in the accent colour
     */
    private void drawStick(Canvas c, VirtualJoystick s, ControlGeometry g, int control, boolean floating, boolean aim,
                           float deadZone, float fireRing, float op, float d, boolean firing) {
        float r = g.r[control];
        if (!s.active) {
            float cx = g.cx[control];
            float cy = g.cy[control];
            stroke.setColor(Palette.withAlpha(0xFFFFFFFF, a(62, op)));
            stroke.setStrokeWidth(2f * d);
            if (floating) dashedCircle(c, cx, cy, r, d);
            else c.drawCircle(cx, cy, r, stroke);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Palette.withAlpha(0xFFFFFFFF, a(18, op)));
            c.drawCircle(cx, cy, r, fill);
            fill.setColor(Palette.withAlpha(0xFFFFFFFF, a(60, op)));
            c.drawCircle(cx, cy, r * 0.34f, fill);
            if (aim) {
                stroke.setColor(Palette.withAlpha(0xFFFFFFFF, a(34, op)));
                stroke.setStrokeWidth(1.2f * d);
                c.drawCircle(cx, cy, r * deadZone, stroke);
                if (fireRing > deadZone && fireRing < 0.97f) {
                    stroke.setColor(Palette.withAlpha(Palette.ACCENT, a(70, op)));
                    stroke.setStrokeWidth(1.4f * d);
                    c.drawCircle(cx, cy, r * fireRing, stroke);
                }
            }
            return;
        }
        int tone = firing ? Palette.ACCENT : 0xFFFFFFFF;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(tone, a(30, op)));
        c.drawCircle(s.baseX, s.baseY, r, fill);
        stroke.setColor(Palette.withAlpha(tone, a(140, op)));
        stroke.setStrokeWidth(2.5f * d);
        c.drawCircle(s.baseX, s.baseY, r, stroke);
        if (aim) {
            stroke.setColor(Palette.withAlpha(0xFFFFFFFF, a(60, op)));
            stroke.setStrokeWidth(1.2f * d);
            c.drawCircle(s.baseX, s.baseY, r * deadZone, stroke);
            if (fireRing > deadZone && fireRing < 0.97f) {
                // where the gun starts firing: push the knob out past this ring
                stroke.setColor(Palette.withAlpha(Palette.ACCENT, a(firing ? 200 : 120, op)));
                stroke.setStrokeWidth(1.6f * d);
                c.drawCircle(s.baseX, s.baseY, r * fireRing, stroke);
            }
        }
        fill.setColor(Palette.withAlpha(tone, a(190, op)));
        c.drawCircle(s.knobX, s.knobY, r * 0.42f, fill);
    }

    /** A ring made of dashes: marks a floating stick (it appears where the thumb lands). */
    private void dashedCircle(Canvas c, float cx, float cy, float r, float d) {
        final int dashes = 18;
        for (int i = 0; i < dashes; i++) {
            float a0 = (float) (2.0 * Math.PI * i / dashes);
            float a1 = a0 + (float) (Math.PI / dashes);
            c.drawLine(cx + (float) Math.cos(a0) * r, cy + (float) Math.sin(a0) * r,
                    cx + (float) Math.cos(a1) * r, cy + (float) Math.sin(a1) * r, stroke);
        }
    }

    // ------------------------------------------------------------------ buttons

    private void drawFire(Canvas c, ControlGeometry g, boolean held, float op, float d) {
        float cx = g.cx[ControlSettings.FIRE];
        float cy = g.cy[ControlSettings.FIRE];
        float r = g.r[ControlSettings.FIRE];
        int tone = held ? Palette.ACCENT : 0xFFFFFFFF;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(held ? Palette.ACCENT_DARK : 0xFF131A22, a(held ? 235 : 175, op)));
        c.drawCircle(cx, cy, r, fill);
        stroke.setColor(Palette.withAlpha(tone, a(held ? 230 : 120, op)));
        stroke.setStrokeWidth(2.4f * d);
        c.drawCircle(cx, cy, r, stroke);
        // crosshair
        float ir = r * 0.46f;
        stroke.setColor(Palette.withAlpha(tone, a(held ? 255 : 210, op)));
        stroke.setStrokeWidth(2.6f * d);
        c.drawCircle(cx, cy, ir * 0.72f, stroke);
        float gap = ir * 0.38f;
        c.drawLine(cx - ir, cy, cx - gap, cy, stroke);
        c.drawLine(cx + gap, cy, cx + ir, cy, stroke);
        c.drawLine(cx, cy - ir, cx, cy - gap, stroke);
        c.drawLine(cx, cy + gap, cx, cy + ir, stroke);
        fill.setColor(Palette.withAlpha(tone, a(230, op)));
        c.drawCircle(cx, cy, 2.2f * d, fill);
    }

    private void drawReload(Canvas c, ControlGeometry g, Weapon wp, boolean held, float op, float d) {
        float cx = g.cx[ControlSettings.RELOAD];
        float cy = g.cy[ControlSettings.RELOAD];
        float r = g.r[ControlSettings.RELOAD];
        boolean needed = wp == null || wp.ammo < wp.def.magSize || wp.reloading;
        int dim = needed ? 255 : 110;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(0xFF131A22, a(held ? 235 : 170, op)));
        c.drawCircle(cx, cy, r, fill);
        stroke.setColor(Palette.withAlpha(0xFFFFFFFF, a((int) (60 * dim / 255f), op)));
        stroke.setStrokeWidth(1.5f * d);
        c.drawCircle(cx, cy, r, stroke);
        if (wp != null && wp.reloading) {
            stroke.setColor(Palette.withAlpha(Palette.ACCENT, a(255, op)));
            stroke.setStrokeWidth(4f * d);
            rect.set(cx - r + 3f * d, cy - r + 3f * d, cx + r - 3f * d, cy + r - 3f * d);
            c.drawArc(rect, -90f, 360f * Math.max(0.02f, wp.reloadFraction), false, stroke);
        }
        float ir = r * 0.42f;
        stroke.setColor(Palette.withAlpha(0xFFFFFFFF, a(dim, op)));
        stroke.setStrokeWidth(3f * d);
        rect.set(cx - ir, cy - ir, cx + ir, cy + ir);
        c.drawArc(rect, -60f, 280f, false, stroke);
        float px = cx + ir * -0.7660f;
        float py = cy + ir * -0.6428f;
        float hd = r * 0.19f;
        path.reset();
        path.moveTo(px + 0.6428f * hd * 1.4f, py - 0.7660f * hd * 1.4f);
        path.lineTo(px - 0.7660f * hd, py - 0.6428f * hd);
        path.lineTo(px + 0.7660f * hd, py + 0.6428f * hd);
        path.close();
        fill.setColor(Palette.withAlpha(0xFFFFFFFF, a(dim, op)));
        c.drawPath(path, fill);
    }

    /**
     * The dodge button: a rolling ball with speed lines behind it. A dark sweep shows the cooldown
     * running down (the button is ready when the sweep is gone); the ring lights up during the roll.
     */
    private void drawDodge(Canvas c, ControlGeometry g, Player me, boolean held, float op, float d) {
        float cx = g.cx[ControlSettings.DODGE];
        float cy = g.cy[ControlSettings.DODGE];
        float r = g.r[ControlSettings.DODGE];
        boolean rolling = me != null && me.isRolling();
        float cd = me == null ? 0f : Math.max(0f, Math.min(1f, me.dodgeCooldown / GameConfig.DODGE_COOLDOWN));
        boolean ready = cd <= 0f && !rolling;
        int tone = rolling || held ? Palette.ACCENT : 0xFFFFFFFF;

        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(rolling || held ? Palette.ACCENT_DARK : 0xFF131A22, a(held || rolling ? 235 : 175, op)));
        c.drawCircle(cx, cy, r, fill);
        if (cd > 0f) {
            // the part of the cooldown that is still to run, clockwise from the elapsed point up to 12 o'clock
            rect.set(cx - r, cy - r, cx + r, cy + r);
            fill.setColor(Palette.withAlpha(0xFF000000, a(120, op)));
            c.drawArc(rect, -90f + 360f * (1f - cd), 360f * cd, true, fill);
        }
        stroke.setColor(Palette.withAlpha(tone, a(rolling || held ? 235 : (ready ? 150 : 70), op)));
        stroke.setStrokeWidth((rolling ? 3.2f : 2.2f) * d);
        c.drawCircle(cx, cy, r, stroke);

        int ink = Palette.withAlpha(0xFFFFFFFF, a(ready || rolling ? 255 : 120, op));
        // speed lines behind the ball
        stroke.setColor(ink);
        stroke.setStrokeWidth(2.4f * d);
        float lx = cx - r * 0.68f;
        c.drawLine(lx, cy - r * 0.34f, lx + r * 0.30f, cy - r * 0.34f, stroke);
        c.drawLine(lx - r * 0.06f, cy, lx + r * 0.36f, cy, stroke);
        c.drawLine(lx, cy + r * 0.34f, lx + r * 0.30f, cy + r * 0.34f, stroke);
        // the ball with a swirl: a ring that is not closed reads as "spinning"
        float bx = cx + r * 0.20f;
        float br = r * 0.34f;
        rect.set(bx - br, cy - br, bx + br, cy + br);
        stroke.setStrokeWidth(2.8f * d);
        c.drawArc(rect, -40f, 270f, false, stroke);
        fill.setColor(ink);
        c.drawCircle(bx, cy, br * 0.34f, fill);
    }

    /**
     * The Pick Up button: a round button in the colour of the item on offer with its icon in it, the words
     * PICK UP, the item's name above and what it will do (replace a gun, add armour...) below. A ring pulses around
     * it to catch the eye. It exists only while a weapon is within reach; nothing is ever picked up by
     * walking over it.
     */
    private void drawPickup(Canvas c, ControlGeometry g, int item, Player me, boolean held, float op, float d,
                            float time, float pop) {
        drawPrompt(c, g, item, Items.color(item), Items.name(item), Items.effect(me, item), "PICK UP", held, op, d, time, pop);
    }

    /** Survival: the Pick Up button for whatever the survivor can do right now (search, open, harvest, get in the car...). */
    private void drawInteract(Canvas c, ControlGeometry g, Interaction it, boolean held, float op, float d, float time, float pop) {
        drawPrompt(c, g, it.icon, Items.color(it.icon), it.title, it.sub, "USE", held, op, d, time, pop);
    }

    private void drawPrompt(Canvas c, ControlGeometry g, int item, int tone, String offerName, String sub, String button,
                            boolean held, float op, float d, float time, float pop) {
        float cx = g.cx[ControlSettings.PICKUP];
        float cy = g.cy[ControlSettings.PICKUP];
        float r = g.r[ControlSettings.PICKUP];
        float k = Math.max(0.85f, Math.min(1.3f, g.sc[ControlSettings.PICKUP]));
        c.save();
        if (pop != 1f) c.scale(pop, pop, cx, cy);
        // a ring that breathes outwards
        float pulse = 0.5f + 0.5f * (float) Math.sin(time * 5.5f);
        stroke.setColor(Palette.withAlpha(tone, a((int) (150 * (1f - pulse)), op)));
        stroke.setStrokeWidth(3f * d);
        c.drawCircle(cx, cy, r + (2f + 7f * pulse) * d, stroke);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(held ? Palette.ACCENT_DARK : 0xFF131A22, a(held ? 240 : 210, op)));
        c.drawCircle(cx, cy, r, fill);
        stroke.setColor(Palette.withAlpha(tone, a(240, op)));
        stroke.setStrokeWidth(3f * d);
        c.drawCircle(cx, cy, r - 1.5f * d, stroke);
        boolean room = r >= 28f * d;
        ItemGlyph.draw(c, fill, path, cx, cy - (room ? r * 0.12f : 0f), r * (room ? 0.50f : 0.56f), item,
                Palette.withAlpha(tone, a(255, op)));
        if (room) {
            text.setTypeface(bold);
            text.setTextAlign(Paint.Align.CENTER);
            text.setTextSize(10f * d * k);
            text.setColor(Palette.withAlpha(0xFFFFFFFF, a(255, op)));
            c.drawText(button, cx, cy + r * 0.66f, text);
        }
        c.restore();

        op *= Math.min(1f, Math.max(0f, pop));      // the captions fade in with the button
        // Name above the button; what it replaces below. Flipped when the button sits near an edge.
        boolean above = cy - r - 40f * d * k >= g.insetT;
        float nameY = above ? cy - r - 8f * d : cy + r + 18f * d * k;

        text.setTypeface(bold);
        text.setTextSize(14f * d * k);
        float wName = text.measureText(offerName);
        float wSub = 0f;
        if (!sub.isEmpty()) {
            text.setTypeface(medium);
            text.setTextSize(10.5f * d * k);
            wSub = text.measureText(sub);
        }
        // A dark plate behind the words keeps them readable over any floor.
        float plateW = Math.max(wName, wSub) + 14f * d;
        float plateTop = above ? nameY - 16f * d * k - (sub.isEmpty() ? 0f : 15f * d * k) : nameY - 16f * d * k;
        float plateBottom = above ? nameY + 6f * d : (sub.isEmpty() ? nameY + 6f * d : nameY + 20f * d * k);
        rect.set(cx - plateW * 0.5f, plateTop, cx + plateW * 0.5f, plateBottom);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(0xFF0E141B, a(170, op)));
        c.drawRoundRect(rect, 8f * d, 8f * d, fill);
        text.setTextAlign(Paint.Align.CENTER);
        text.setTypeface(bold);
        text.setTextSize(14f * d * k);
        text.setColor(Palette.withAlpha(tone, a(255, op)));
        c.drawText(offerName, cx, nameY, text);
        if (!sub.isEmpty()) {
            text.setTypeface(medium);
            text.setTextSize(10.5f * d * k);
            text.setColor(Palette.withAlpha(Palette.TEXT_DIM, a(240, op)));
            c.drawText(sub, cx, above ? nameY - 15f * d * k : nameY + 14f * d * k, text);
        }
    }

    private void drawPause(Canvas c, ControlGeometry g, float op, float d) {
        float cx = g.cx[ControlSettings.PAUSE];
        float cy = g.cy[ControlSettings.PAUSE];
        float half = g.r[ControlSettings.PAUSE];
        rect.set(cx - half, cy - half, cx + half, cy + half);
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(0xFF131A22, a(179, op)));
        c.drawRoundRect(rect, 10f * d, 10f * d, fill);
        fill.setColor(Palette.withAlpha(Palette.TEXT, a(255, op)));
        float bw = half * 0.23f;
        float bh = half * 0.77f;
        float off = half * 0.32f;
        c.drawRect(cx - off - bw * 0.5f, cy - bh * 0.5f, cx - off + bw * 0.5f, cy + bh * 0.5f, fill);
        c.drawRect(cx + off - bw * 0.5f, cy - bh * 0.5f, cx + off + bw * 0.5f, cy + bh * 0.5f, fill);
    }

    private static int a(int alpha, float opacity) {
        int v = (int) (alpha * opacity);
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }
}
