package com.hazardyard.game.net;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameMode;
import com.hazardyard.game.core.MapLibrary;

/**
 * The player list shown in the lobby: who is in, who is ready. The host owns the authoritative copy
 * and mirrors it to clients with S_LOBBY messages; clients keep a read-only copy decoded from those.
 * All methods are synchronized because network threads and the UI thread both touch it.
 */
public final class LobbyManager {
    public static final class Entry {
        public boolean used;
        public boolean ready;
        public boolean host;
        public String name = "";
    }

    /** Only real players have a lobby row; bots are added by the host when the match starts. */
    private final Entry[] entries = new Entry[GameConfig.MAX_HUMANS];
    private int mapId = MapLibrary.DEFAULT_ID;
    private int modeId = GameMode.CLASSIC;
    /** Survival: the seed of the world (the host picks it; everybody generates the same world from it). */
    private int seed = (int) (System.nanoTime() & 0x3FFFFFFF);

    public LobbyManager() {
        for (int i = 0; i < entries.length; i++) entries[i] = new Entry();
    }

    /** Adds a player to the lowest free slot and returns it, or -1 when the lobby is full. */
    public synchronized int addPlayer(String name, boolean isHost) {
        for (int i = 0; i < entries.length; i++) {
            if (!entries[i].used) {
                Entry e = entries[i];
                e.used = true;
                e.ready = false;
                e.host = isHost;
                e.name = uniqueName(name);
                return i;
            }
        }
        return -1;
    }

    private String uniqueName(String base) {
        String candidate = base;
        int n = 2;
        while (nameTaken(candidate)) {
            String suffix = " " + n++;
            int keep = Math.min(base.length(), Protocol.MAX_NAME - suffix.length());
            candidate = base.substring(0, Math.max(keep, 1)) + suffix;
        }
        return candidate;
    }

    private boolean nameTaken(String n) {
        for (Entry e : entries) {
            if (e.used && e.name.equalsIgnoreCase(n)) return true;
        }
        return false;
    }

    public synchronized void removePlayer(int id) {
        if (id < 0 || id >= entries.length) return;
        Entry e = entries[id];
        e.used = false;
        e.ready = false;
        e.host = false;
        e.name = "";
    }

    public synchronized void setReady(int id, boolean ready) {
        if (id >= 0 && id < entries.length && entries[id].used) entries[id].ready = ready;
    }

    public synchronized int count() {
        int n = 0;
        for (Entry e : entries) if (e.used) n++;
        return n;
    }

    /** True when every non-host player is ready (a lone host may always start). */
    public synchronized boolean allReady() {
        for (Entry e : entries) {
            if (e.used && !e.host && !e.ready) return false;
        }
        return true;
    }

    public synchronized void resetReady() {
        for (Entry e : entries) e.ready = false;
    }

    public synchronized void clear() {
        for (int i = 0; i < entries.length; i++) removePlayer(i);
    }

    /** Copies the current state into caller-owned entries (length MAX_PLAYERS). */
    public synchronized void copyTo(Entry[] out) {
        for (int i = 0; i < entries.length && i < out.length; i++) {
            Entry s = entries[i];
            Entry d = out[i];
            d.used = s.used;
            d.ready = s.ready;
            d.host = s.host;
            d.name = s.name;
        }
    }

    /**
     * The arena the next match is played on: the one the host picked, or the mode's own arena when the
     * mode fixes it (Battleground). Travels with every lobby message.
     */
    public synchronized int getMapId() {
        GameMode m = GameMode.byId(modeId);
        return m.fixedMap() ? m.mapId : mapId;
    }

    /** The classic arena the host has selected (even while a mode with its own arena is chosen). */
    public synchronized int getArenaChoice() {
        return mapId;
    }

    public synchronized void setMapId(int id) {
        mapId = id < 0 || id >= MapLibrary.CLASSIC_COUNT ? MapLibrary.DEFAULT_ID : id;
    }

    public synchronized int getSeed() {
        return seed;
    }

    public synchronized void setSeed(int s) {
        seed = s;
    }

    /** The {@link GameMode} of the next match. */
    public synchronized int getModeId() {
        return modeId;
    }

    public synchronized void setModeId(int id) {
        modeId = GameMode.clampId(id);
    }

    public synchronized String nameOf(int id) {
        return (id >= 0 && id < entries.length && entries[id].used) ? entries[id].name : "";
    }

    public synchronized void write(PacketWriter w) {
        w.u8(entries.length);
        for (Entry e : entries) {
            int flags = (e.used ? 1 : 0) | (e.ready ? 2 : 0) | (e.host ? 4 : 0);
            w.u8(flags);
            w.str(e.name);
        }
        w.u8(mapId);
        w.u8(modeId);
        w.i32(seed);
    }

    public synchronized void read(PacketReader r) {
        int n = r.u8();
        for (int i = 0; i < n; i++) {
            int flags = r.u8();
            String name = r.str();
            if (i >= entries.length) continue;
            Entry e = entries[i];
            e.used = (flags & 1) != 0;
            e.ready = (flags & 2) != 0;
            e.host = (flags & 4) != 0;
            e.name = e.used ? name : "";
        }
        if (r.remaining() > 0) {
            int m = r.u8();
            mapId = m < 0 || m >= MapLibrary.CLASSIC_COUNT ? MapLibrary.DEFAULT_ID : m;
        }
        if (r.remaining() > 0) modeId = GameMode.clampId(r.u8());
        if (r.remaining() >= 4) seed = r.i32();
    }
}
