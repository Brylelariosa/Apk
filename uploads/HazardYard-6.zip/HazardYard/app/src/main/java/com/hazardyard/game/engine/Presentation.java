package com.hazardyard.game.engine;

import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;

/**
 * The visual and audible side of gameplay events, shared by every engine (host, solo, client) so a
 * muzzle flash or a kill looks and sounds the same wherever the match is simulated.
 */
final class Presentation {
    private Presentation() {}

    /** A weapon fired from (x, y): flash at the barrel tip, the shot sound, and a heard-shot ping for everyone but the local player. */
    static void shot(GameState st, int ownerId, int weaponId, float x, float y, float angle) {
        WeaponDef d = WeaponDef.byId(weaponId);
        if (d.melee) {
            // A swing: no flash and no heard-shot ping; the weapon sweeps (see UnitRenderer) and whooshes.
            if (ownerId >= 0 && ownerId < st.players.length) {
                Player o = st.players[ownerId];
                o.swingT = 0f;
                o.swingDur = Math.max(0.22f, d.fireInterval * 0.8f);
            }
            st.audio.shot(d.id, x, y);
            return;
        }
        st.effects.muzzle(d.muzzleX(x, angle), d.muzzleY(y, angle), angle, d.color);
        st.audio.shot(d.id, x, y);
        if (ownerId != st.localId) st.effects.noise(ownerId, x, y);
    }

    private static void impactFx(GameState st, int weaponId, float x, float y) {
        WeaponDef d = WeaponDef.byId(weaponId);
        if (d.style == WeaponDef.STYLE_ENERGY) st.effects.zap(x, y, d.color);
        else st.effects.impact(x, y, d.color);
    }

    static void hit(GameState st, int victimId, float x, float y, int weaponId, int damage) {
        if (weaponId >= 250 || WeaponDef.byId(weaponId).melee) {       // a melee blow, a zombie's bite, a car
            st.effects.impact(x, y, 0xFFB03030);
            if (damage > 0) st.audio.meleeHit(victimId, x, y);
            return;
        }
        impactFx(st, weaponId, x, y);
        if (damage > 0) st.audio.projectileHit(victimId, x, y);
    }

    static void wallImpact(GameState st, float x, float y, int weaponId) {
        impactFx(st, weaponId, x, y);
        st.audio.wallImpact(x, y);
    }

    /** An item was taken from pad {@code padIndex}: the pad pops (the pickup sound follows from the change in the taker's gear). */
    static void pickup(GameState st, int padIndex, int item) {
        if (padIndex < 0 || padIndex >= st.pickups.length) return;
        com.hazardyard.game.core.Pickup pk = st.pickups[padIndex];
        st.effects.pickup(pk.x, pk.y, Items.color(item));
    }

    static void kill(GameState st, int killerId, int victimId, int weaponId) {
        Effects fx = st.effects;
        fx.addKill(killerId, victimId, weaponId);
        if (victimId < 0 || victimId >= st.players.length) return;
        Player v = st.players[victimId];
        fx.burst(v.rx, v.ry, PlayerColors.of(victimId));
        st.audio.kill(killerId, victimId, v.rx, v.ry);
    }
}
