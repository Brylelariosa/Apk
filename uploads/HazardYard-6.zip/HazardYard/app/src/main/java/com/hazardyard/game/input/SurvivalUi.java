package com.hazardyard.game.input;

import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.survival.Inventory;
import com.hazardyard.game.survival.Recipes;
import com.hazardyard.game.survival.SurvivalSim;

/**
 * The survival screens' touch handling and layout: a hotbar of six slots with a bag button beside it, and the bag, a panel
 * with the pack on the left (tap an item to select it, tap another slot to swap, buttons to use or drop) and the crafting
 * list on the right (tap a recipe, then Craft). Pure Java: the renderer reads the geometry from here, so what is drawn is
 * what can be touched. Everything it wants done is queued as commands for the host.
 */
public final class SurvivalUi {
    /** True in survival mode; when false this does nothing. */
    public volatile boolean active;
    public volatile boolean bagOpen;
    public int selSlot = -1;
    public int selRecipe = -1;
    public float recipeScroll;

    // the world around the survivor, as far as crafting is concerned (set every frame by the game loop)
    private Inventory inv;
    private boolean nearBench, nearFire;

    // ---- geometry (pixels)
    public float density = 1f;
    public float slot, gap;
    public float hotX0, hotY;
    public float bagBtnX, bagBtnY, bagBtnS;
    public float panelX0, panelY0, panelX1, panelY1;
    public float gridX0, gridY0, cell, cellGap;
    public static final int COLS = 6;
    public float listX0, listY0, listX1, listY1, rowH;
    public float useX, dropX, btnY, btnW, btnH;
    public float craftX, craftY, craftW;
    public float closeX, closeY, closeS;
    private int viewW, viewH;

    // ---- pointer
    private int owner = -1;
    private float downX, downY, lastX, lastY;
    private boolean dragged;
    private int downTarget;

    private final int[] cmdQueueType = new int[16];
    private final int[] cmdQueueA = new int[16];
    private final int[] cmdQueueB = new int[16];
    private int queued;

    public synchronized void setContext(Inventory inv, boolean nearBench, boolean nearFire) {
        this.inv = inv;
        this.nearBench = nearBench;
        this.nearFire = nearFire;
    }

    public boolean nearBench() {
        return nearBench;
    }

    public boolean nearFire() {
        return nearFire;
    }

    /** True when the recipe could be crafted right now (ingredients in the pack, station within reach). */
    public synchronized boolean craftable(int recipe) {
        if (inv == null || recipe < 0 || recipe >= Recipes.ALL.length) return false;
        Recipes.Recipe r = Recipes.ALL[recipe];
        if (r.station == Recipes.BENCH && !nearBench) return false;
        if (r.station == Recipes.FIRE && !nearFire) return false;
        return Recipes.canAfford(inv, r);
    }

    public synchronized void layout(int w, int h, float dens, float insetL, float insetT, float insetR, float insetB) {
        viewW = w;
        viewH = h;
        density = dens;
        float d = dens;
        slot = 42f * d;
        gap = 4f * d;
        float total = Inventory.HOTBAR * slot + (Inventory.HOTBAR - 1) * gap + gap + slot;      // six slots, a gap, the bag button
        hotX0 = (w - total) * 0.5f;
        hotY = h - insetB - slot - 46f * d;           // above the health bar
        bagBtnS = slot;
        bagBtnX = hotX0 + Inventory.HOTBAR * (slot + gap) + gap;
        bagBtnY = hotY;
        panelX0 = Math.max(insetL, 0f) + 14f * d;
        panelX1 = w - Math.max(insetR, 0f) - 14f * d;
        panelY0 = insetT + 10f * d;
        panelY1 = h - insetB - 10f * d;
        closeS = 34f * d;
        closeX = panelX1 - closeS - 6f * d;
        closeY = panelY0 + 6f * d;
        float availH = panelY1 - panelY0 - 112f * d;                 // room for titles and the button rows
        cell = Math.min(46f * d, Math.max(30f * d, availH / 4f - 4f * d));
        cellGap = 4f * d;
        gridX0 = panelX0 + 12f * d;
        gridY0 = panelY0 + 40f * d;
        float gridW = COLS * cell + (COLS - 1) * cellGap;
        btnH = 36f * d;
        btnY = gridY0 + 4 * cell + 3 * cellGap + 10f * d;
        btnW = (gridW - 8f * d) * 0.5f;
        useX = gridX0;
        dropX = gridX0 + btnW + 8f * d;
        listX0 = gridX0 + gridW + 18f * d;
        listX1 = panelX1 - 12f * d;
        listY0 = panelY0 + 40f * d;
        listY1 = panelY1 - btnH - 20f * d;
        rowH = 42f * d;
        craftW = Math.min(150f * d, listX1 - listX0);
        craftX = listX1 - craftW;
        craftY = panelY1 - btnH - 10f * d;
    }

    public float slotX(int i) {
        return hotX0 + i * (slot + gap);
    }

    public float cellX(int i) {
        return gridX0 + (i % COLS) * (cell + cellGap);
    }

    public float cellY(int i) {
        return gridY0 + (i / COLS) * (cell + cellGap);
    }

    public float rowY(int r) {
        return listY0 + r * rowH - recipeScroll;
    }

    public float maxScroll() {
        return Math.max(0f, Recipes.ALL.length * rowH - (listY1 - listY0));
    }

    private static boolean in(float x, float y, float x0, float y0, float w, float h) {
        return x >= x0 && x <= x0 + w && y >= y0 && y <= y0 + h;
    }

    // ------------------------------------------------------------------ touches

    /** Returns true when the touch belongs to this layer (and must not reach the game controls). */
    public synchronized boolean onDown(int id, float x, float y) {
        if (!active || owner >= 0) return false;
        downX = x;
        downY = y;
        lastX = x;
        lastY = y;
        dragged = false;
        if (!bagOpen) {
            for (int i = 0; i < Inventory.HOTBAR; i++) {
                if (in(x, y, slotX(i), hotY, slot, slot)) {
                    push(SurvivalSim.CMD_SELECT, i, 0);
                    return true;           // handled right away; nothing to track
                }
            }
            if (in(x, y, bagBtnX, bagBtnY, bagBtnS, bagBtnS)) {
                bagOpen = true;
                selSlot = -1;
                return true;
            }
            return false;
        }
        owner = id;
        downTarget = 0;
        return true;
    }

    public synchronized boolean owns(int id) {
        return owner == id;
    }

    public synchronized void onMove(int id, float x, float y) {
        if (owner != id) return;
        if (Math.abs(y - downY) > 10f * density || dragged) {
            dragged = true;
            if (x >= listX0 && downX >= listX0) recipeScroll = Math.max(0f, Math.min(maxScroll(), recipeScroll - (y - lastY)));
        }
        lastX = x;
        lastY = y;
    }

    public synchronized void onUp(int id) {
        if (owner != id) return;
        owner = -1;
        float x = lastX, y = lastY;
        if (dragged) return;
        // close
        if (in(x, y, closeX, closeY, closeS, closeS) || x < panelX0 || x > panelX1 || y < panelY0 || y > panelY1) {
            bagOpen = false;
            selSlot = -1;
            return;
        }
        for (int i = 0; i < Inventory.SLOTS; i++) {
            if (!in(x, y, cellX(i), cellY(i), cell, cell)) continue;
            if (selSlot < 0) {
                if (inv != null && !inv.isEmpty(i)) selSlot = i;
            } else if (selSlot == i) {
                selSlot = -1;
            } else {
                push(SurvivalSim.CMD_SWAP, selSlot, i);
                selSlot = -1;
            }
            return;
        }
        if (selSlot >= 0 && in(x, y, useX, btnY, btnW, btnH)) {
            push(SurvivalSim.CMD_USE, selSlot, 0);
            return;
        }
        if (selSlot >= 0 && in(x, y, dropX, btnY, btnW, btnH)) {
            push(SurvivalSim.CMD_DROP, selSlot, 0);
            selSlot = -1;
            return;
        }
        if (x >= listX0 && x <= listX1 && y >= listY0 && y <= listY1) {
            int r = (int) Math.floor((y - listY0 + recipeScroll) / rowH);
            if (r >= 0 && r < Recipes.ALL.length) selRecipe = r;
            return;
        }
        if (selRecipe >= 0 && in(x, y, craftX, craftY, craftW, btnH)) {
            push(SurvivalSim.CMD_CRAFT, selRecipe, 0);
        }
    }

    public synchronized void cancel() {
        owner = -1;
        dragged = false;
    }

    private void push(int type, int a, int b) {
        if (queued >= cmdQueueType.length) return;
        cmdQueueType[queued] = type;
        cmdQueueA[queued] = a;
        cmdQueueB[queued] = b;
        queued++;
    }

    /** Moves the queued commands into this frame's input. */
    public synchronized void drainCommands(LocalInput out) {
        for (int i = 0; i < queued; i++) out.pushCommand(cmdQueueType[i], cmdQueueA[i], cmdQueueB[i]);
        queued = 0;
    }

    /** How the item in a slot is described under the pack (name and what it does). */
    public static String describe(int item) {
        if (item < 0) return "";
        int food = Items.foodValue(item);
        if (food > 0) return Items.name(item) + "  \u2022  restores " + food + " hunger";
        int heal = Items.healValue(item);
        if (heal > 0) return Items.name(item) + "  \u2022  heals " + heal;
        if (Items.isVest(item)) return Items.name(item) + "  \u2022  " + Items.armorOf(item) + " armour";
        return Items.name(item);
    }
}
