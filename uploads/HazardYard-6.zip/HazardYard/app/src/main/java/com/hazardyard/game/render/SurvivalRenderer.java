package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.render.model.Projection;
import com.hazardyard.game.survival.Car;
import com.hazardyard.game.survival.Drop;
import com.hazardyard.game.survival.Obj;
import com.hazardyard.game.survival.SurvivalState;
import com.hazardyard.game.survival.SurvivalTerrain;
import com.hazardyard.game.survival.Zombie;

/**
 * Draws the endless survival world: ground, trees, ruined houses with their furniture, crops, campfires, then zombies,
 * cars, survivors and dropped items sorted by depth, and at night a darkness with a circle of light round the survivor.
 */
final class SurvivalRenderer {
    /** Draws one survivor (the regular soldier renderer). */
    interface PlayerDrawer {
        void draw(Canvas c, int playerIndex);
    }

    private static final float T = GameConfig.TILE;
    private static final float LEAN = Projection.LEAN;
    private static final float TILT = Projection.TILT;
    private static final float WALL_H = 24f;

    private final TerrainRenderer terrain = new TerrainRenderer();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint night = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final Path path2 = new Path();
    private SurvivalTerrain src;
    private GroundSource groundSrc;
    private final float[] gx = new float[8];
    private final float[] gy = new float[8];

    // depth-sorted things that move
    private static final int K_PLAYER = 0, K_ZOMBIE = 1, K_CAR = 2, K_DROP = 3;
    private static final int MAX_DYN = 160;
    private final int[] dynKind = new int[MAX_DYN];
    private final int[] dynIndex = new int[MAX_DYN];
    private final float[] dynKey = new float[MAX_DYN];
    private int nDyn;

    private int nightW, nightH;
    private float lastLight = -1f;

    SurvivalRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    private GroundSource groundOf(final SurvivalTerrain t) {
        if (src != t) {
            src = t;
            groundSrc = new GroundSource() {
                @Override
                public byte ground(int tx, int ty) {
                    return t.groundAt(tx, ty);
                }

                @Override
                public boolean water(int tx, int ty) {
                    return t.groundAt(tx, ty) == TileMap.G_WATER;
                }
            };
        }
        return groundSrc;
    }

    // ------------------------------------------------------------------ the world

    void draw(Canvas c, GameState st, Camera cam, float time, boolean lite, PlayerDrawer players, BlockRenderer blocks,
              float vx0, float vx1, float vy0, float vy1) {
        SurvivalState sv = st.survival;
        SurvivalTerrain t = sv.terrain;
        int tx0 = (int) Math.floor(vx0 / T) - 1, tx1 = (int) Math.floor(vx1 / T) + 1;
        int ty0 = (int) Math.floor(vy0 / T) - 1, ty1 = (int) Math.floor(vy1 / T) + 2;
        terrain.draw(c, groundOf(t), time, tx0, tx1, ty0, ty1, lite);
        shadows(c, t, tx0, tx1, ty0, ty1);
        collect(st, cam);
        int d = 0;
        for (int ty = ty0; ty <= ty1; ty++) {
            float south = (ty + 1) * T;
            while (d < nDyn && dynKey[d] < south) drawDyn(c, st, d++, time, players, lite);
            for (int tx = tx0; tx <= tx1; tx++) {
                byte o = t.objAt(tx, ty);
                if (o != Obj.NONE) drawObject(c, t, blocks, o, tx, ty, t.metaAt(tx, ty), time, lite);
            }
        }
        while (d < nDyn) drawDyn(c, st, d++, time, players, lite);
        drawFishing(c, st, time);
    }

    private void shadows(Canvas c, SurvivalTerrain t, int tx0, int tx1, int ty0, int ty1) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x33000000);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                byte o = t.objAt(tx, ty);
                if (o == Obj.TREE) c.drawCircle((tx + 0.5f) * T + 9f, (ty + 0.5f) * T + 9f, 17f, fill);
                else if (o == Obj.ROCK) c.drawCircle((tx + 0.5f) * T + 6f, (ty + 0.5f) * T + 6f, 12f, fill);
                else if (o == Obj.BUSH) c.drawCircle((tx + 0.5f) * T + 3f, (ty + 0.5f) * T + 5f, 10f, fill);
            }
        }
    }

    private void collect(GameState st, Camera cam) {
        nDyn = 0;
        SurvivalState sv = st.survival;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected || !p.alive || sv.drivingCar[i] >= 0 || !cam.isVisible(p.rx, p.ry, 60f)) continue;
            add(K_PLAYER, i, p.ry);
        }
        for (int i = 0; i < sv.zombies.length; i++) {
            Zombie z = sv.zombies[i];
            if (z.active && cam.isVisible(z.rx, z.ry, 60f)) add(K_ZOMBIE, i, z.ry);
        }
        for (int i = 0; i < sv.cars.length; i++) {
            Car car = sv.cars[i];
            if (car.active && cam.isVisible(car.rx, car.ry, 80f)) add(K_CAR, i, car.ry);
        }
        for (int i = 0; i < sv.drops.length; i++) {
            Drop dr = sv.drops[i];
            if (dr.active && cam.isVisible(dr.x, dr.y, 40f)) add(K_DROP, i, dr.y);
        }
    }

    private void add(int kind, int index, float key) {
        if (nDyn >= MAX_DYN) return;
        int i = nDyn++;
        while (i > 0 && dynKey[i - 1] > key) {
            dynKind[i] = dynKind[i - 1];
            dynIndex[i] = dynIndex[i - 1];
            dynKey[i] = dynKey[i - 1];
            i--;
        }
        dynKind[i] = kind;
        dynIndex[i] = index;
        dynKey[i] = key;
    }

    private void drawDyn(Canvas c, GameState st, int slot, float time, PlayerDrawer players, boolean lite) {
        SurvivalState sv = st.survival;
        int i = dynIndex[slot];
        switch (dynKind[slot]) {
            case K_PLAYER: players.draw(c, i); break;
            case K_ZOMBIE: drawZombie(c, sv.zombies[i], time, sv.isNight()); break;
            case K_CAR: drawCar(c, sv.cars[i], time, sv.isNight()); break;
            default: drawDrop(c, sv.drops[i], time); break;
        }
    }

    // ------------------------------------------------------------------ objects

    private void drawObject(Canvas c, SurvivalTerrain t, BlockRenderer blocks, byte o, int tx, int ty, int meta, float time, boolean lite) {
        float x = tx * T, y = ty * T;
        switch (o) {
            case Obj.TREE: blocks.drawTree(c, tx, ty); break;
            case Obj.ROCK: blocks.drawRock(c, tx, ty); break;
            case Obj.WALL: drawWall(c, t, tx, ty, meta); break;
            case Obj.DOOR: drawDoor(c, x, y, meta); break;
            case Obj.CUPBOARD: box(c, x, y, 5f, 14f, 0xFFC09060, 0xFF9A7048, 0xFF785632, true, meta); break;
            case Obj.FRIDGE: box(c, x, y, 5f, 21f, 0xFFF0F4F8, 0xFFC4CCD4, 0xFF9AA4AE, true, meta); break;
            case Obj.SHELF: box(c, x, y, 4f, 19f, 0xFFA88050, 0xFF856038, 0xFF664A28, true, meta); shelfItems(c, x, y, 19f, meta); break;
            case Obj.WARDROBE: box(c, x, y, 4f, 26f, 0xFF8A6844, 0xFF6A4E30, 0xFF503A22, true, meta); break;
            case Obj.TOOLBOX: box(c, x, y, 8f, 10f, 0xFFD04A3C, 0xFFA03228, 0xFF7C241C, true, meta); break;
            case Obj.GUNCASE: box(c, x, y, 6f, 11f, 0xFF4A505C, 0xFF343942, 0xFF262A32, true, meta); break;
            case Obj.CRATE: box(c, x, y, 5f, 15f, 0xFFB8843C, 0xFF94672A, 0xFF744F1E, true, meta); crateSlats(c, x, y, 15f); break;
            case Obj.TABLE: box(c, x, y, 3f, 11f, 0xFF9A7A50, 0xFF7A5E3C, 0xFF5E462C, false, 0); break;
            case Obj.BED: bed(c, x, y); break;
            case Obj.WORKBENCH: box(c, x, y, 3f, 15f, 0xFFA88050, 0xFF856038, 0xFF664A28, false, 0); vise(c, x, y); break;
            case Obj.CAMPFIRE: drawFire(c, x, y, time); break;
            case Obj.CROP: drawCrop(c, x, y, meta, time); break;
            case Obj.BUSH: drawBush(c, x, y); break;
            case Obj.STUMP: stump(c, x, y); break;
            case Obj.RUBBLE: rubble(c, x, y, tx, ty); break;
            default: break;
        }
    }

    private void drawWall(Canvas c, SurvivalTerrain t, int tx, int ty, int meta) {
        boolean ruin = meta == Obj.UNBREAKABLE_WALL;
        int top = ruin ? 0xFFE0D2B6 : 0xFFC79B5D;
        int front = ruin ? 0xFFB09C7C : 0xFF9E7640;
        int side = ruin ? 0xFF8A785C : 0xFF745423;
        float x0 = tx * T, y0 = ty * T, x1 = x0 + T, y1 = y0 + T;
        float lean = LEAN * WALL_H, rise = TILT * WALL_H;
        if (t.objAt(tx, ty + 1) != Obj.WALL) {
            fill.setColor(front);
            quad(c, x0, y1, x1, y1, x1 + lean, y1 - rise, x0 + lean, y1 - rise);
            if (!ruin && meta < 60) {                    // a damaged wall shows cracks
                line.setColor(0x88200E04);
                line.setStrokeWidth(1.4f);
                c.drawLine(x0 + 8f, y1 - 2f, x0 + 14f + lean, y1 - rise + 4f, line);
                c.drawLine(x0 + 20f, y1 - 3f, x0 + 17f + lean, y1 - rise + 6f, line);
            }
        }
        if (t.objAt(tx - 1, ty) != Obj.WALL) {
            fill.setColor(side);
            quad(c, x0, y0, x0, y1, x0 + lean, y1 - rise, x0 + lean, y0 - rise);
        }
        fill.setColor(top);
        quad(c, x0 + lean, y0 - rise, x1 + lean, y0 - rise, x1 + lean, y1 - rise, x0 + lean, y1 - rise);
    }

    private void drawDoor(Canvas c, float x, float y, int meta) {
        boolean open = (meta & 1) != 0;
        float h = 22f;
        float lean = LEAN * h, rise = TILT * h;
        if (open) {
            // an open door: the leaf swung back against the frame
            fill.setColor(0xFF7A5226);
            quad(c, x, y, x + 5f, y, x + 5f, y + T, x, y + T);
            fill.setColor(0xFFB07840);
            quad(c, x + lean, y - rise, x + 5f + lean, y - rise, x + 5f + lean, y + T - rise, x + lean, y + T - rise);
            return;
        }
        fill.setColor(0xFF8A5A2C);
        quad(c, x, y + T, x + T, y + T, x + T + lean, y + T - rise, x + lean, y + T - rise);
        fill.setColor(0xFF6A4420);
        quad(c, x, y, x, y + T, x + lean, y + T - rise, x + lean, y - rise);
        fill.setColor(0xFFB07840);
        quad(c, x + lean, y - rise, x + T + lean, y - rise, x + T + lean, y + T - rise, x + lean, y + T - rise);
        fill.setColor(0xFFE8D090);
        c.drawCircle(x + T * 0.78f + lean * 0.6f, y + T - rise * 0.55f, 1.8f, fill);
    }

    /** A box standing on a tile, inset from the edges; drawn with a lit top, a south face and a west face. */
    private void box(Canvas c, float x, float y, float inset, float h, int top, int front, int side, boolean searchable, int meta) {
        float x0 = x + inset, y0 = y + inset, x1 = x + T - inset, y1 = y + T - inset;
        float lean = LEAN * h, rise = TILT * h;
        boolean done = searchable && (meta & Obj.SEARCHED) != 0;
        if (done) {
            top = dim(top);
            front = dim(front);
            side = dim(side);
        }
        fill.setColor(front);
        quad(c, x0, y1, x1, y1, x1 + lean, y1 - rise, x0 + lean, y1 - rise);
        fill.setColor(side);
        quad(c, x0, y0, x0, y1, x0 + lean, y1 - rise, x0 + lean, y0 - rise);
        fill.setColor(top);
        quad(c, x0 + lean, y0 - rise, x1 + lean, y0 - rise, x1 + lean, y1 - rise, x0 + lean, y1 - rise);
        if (searchable && !done) {
            // a little glint on furniture that has not been searched yet
            float a = 0.5f + 0.5f * (float) Math.sin(glint + x * 0.05f + y * 0.03f);
            fill.setColor(((int) (140 + 100 * a) << 24) | 0xFFE680);
            float sx = (x0 + x1) * 0.5f + lean, sy = y0 - rise + (y1 - y0) * 0.35f;
            c.drawCircle(sx, sy, 2.1f, fill);
            line.setColor(((int) (110 * a) << 24) | 0xFFE680);
            line.setStrokeWidth(1f);
            c.drawLine(sx - 4.5f, sy, sx + 4.5f, sy, line);
            c.drawLine(sx, sy - 4.5f, sx, sy + 4.5f, line);
        }
    }

    private float glint;

    private static int dim(int argb) {
        int r = ((argb >> 16) & 255) * 7 / 10, g = ((argb >> 8) & 255) * 7 / 10, b = (argb & 255) * 7 / 10;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void shelfItems(Canvas c, float x, float y, float h, int meta) {
        float lean = LEAN * h, rise = TILT * h;
        int[] cols = {0xFFE05A4A, 0xFF58A6FF, 0xFFE8C84A, 0xFF6EE08A};
        for (int i = 0; i < 4; i++) {
            fill.setColor(cols[i]);
            c.drawRect(x + 7f + i * 5f + lean, y + 8f - rise, x + 10f + i * 5f + lean, y + 11f - rise, fill);
        }
    }

    private void crateSlats(Canvas c, float x, float y, float h) {
        float lean = LEAN * h, rise = TILT * h;
        line.setColor(0x55402010);
        line.setStrokeWidth(1.3f);
        c.drawLine(x + 5f + lean, y + 5f - rise, x + T - 5f + lean, y + T - 5f - rise, line);
        c.drawLine(x + T - 5f + lean, y + 5f - rise, x + 5f + lean, y + T - 5f - rise, line);
    }

    private void bed(Canvas c, float x, float y) {
        box(c, x, y, 3f, 9f, 0xFF6A8FC0, 0xFF4E6E98, 0xFF3C5878, false, 0);
        float lean = LEAN * 9f, rise = TILT * 9f;
        fill.setColor(0xFFF2F2F2);
        c.drawRoundRect(x + 5f + lean, y + 5f - rise, x + T - 5f + lean, y + 12f - rise, 3f, 3f, fill);
    }

    private void vise(Canvas c, float x, float y) {
        float lean = LEAN * 15f, rise = TILT * 15f;
        fill.setColor(0xFF6A727E);
        c.drawRect(x + 21f + lean, y + 9f - rise, x + 27f + lean, y + 17f - rise, fill);
        line.setColor(0xFFC8CED8);
        line.setStrokeWidth(1.6f);
        c.drawLine(x + 7f + lean, y + 12f - rise, x + 17f + lean, y + 22f - rise, line);
    }

    private void drawFire(Canvas c, float x, float y, float time) {
        float cx = x + T * 0.5f, cy = y + T * 0.62f;
        fill.setColor(0x33000000);
        c.drawOval(cx - 13f, cy - 2f, cx + 13f, cy + 7f, fill);
        line.setStrokeWidth(4.2f);
        line.setColor(0xFF4A2F1A);
        c.drawLine(cx - 11f, cy + 2f, cx + 10f, cy - 3f, line);
        c.drawLine(cx - 10f, cy - 3f, cx + 11f, cy + 3f, line);
        line.setColor(0xFF6A4424);
        line.setStrokeWidth(2f);
        c.drawLine(cx - 11f, cy + 1f, cx + 9f, cy - 4f, line);
        float f = (float) Math.sin(time * 11f + x) * 1.6f;
        path.reset();
        path.moveTo(cx - 6f, cy - 1f);
        path.lineTo(cx - 3f + f, cy - 12f);
        path.lineTo(cx + f * 0.5f, cy - 7f);
        path.lineTo(cx + 3f - f, cy - 15f - f);
        path.lineTo(cx + 6f, cy - 1f);
        path.close();
        fill.setColor(0xFFFF8A2A);
        c.drawPath(path, fill);
        path.reset();
        path.moveTo(cx - 3f, cy - 1f);
        path.lineTo(cx + f * 0.4f, cy - 8f);
        path.lineTo(cx + 3f, cy - 1f);
        path.close();
        fill.setColor(0xFFFFE070);
        c.drawPath(path, fill);
    }

    private void drawCrop(Canvas c, float x, float y, int meta, float time) {
        int stage = meta & 3;
        boolean potato = ((meta >> 2) & 3) == 1;
        float cx = x + T * 0.5f, cy = y + T * 0.6f;
        line.setStrokeWidth(2f);
        for (int k = -1; k <= 1; k++) {
            float px = cx + k * 9f, py = cy + 3f;
            float h = 3f + stage * 5f;
            line.setColor(potato ? 0xFF5E9A3A : 0xFF6FB04A);
            c.drawLine(px, py, px - 2f, py - h, line);
            c.drawLine(px, py, px + 2.4f, py - h * 0.8f, line);
            if (stage >= 2) c.drawLine(px, py, px + 0.4f, py - h * 1.1f, line);
            if (stage == 3) {
                fill.setColor(potato ? 0xFFF2E27A : 0xFFFF9534);
                c.drawCircle(px, py + 1f, 2.6f, fill);
            }
        }
    }

    private void drawBush(Canvas c, float x, float y) {
        float cx = x + T * 0.5f, cy = y + T * 0.55f;
        fill.setColor(0xFF2E7A36);
        c.drawCircle(cx - 5f, cy, 9f, fill);
        c.drawCircle(cx + 5f, cy + 1f, 9f, fill);
        fill.setColor(0xFF4A9A44);
        c.drawCircle(cx, cy - 5f, 9f, fill);
        fill.setColor(0xFFB04AC8);
        c.drawCircle(cx - 4f, cy - 4f, 1.9f, fill);
        c.drawCircle(cx + 5f, cy - 1f, 1.9f, fill);
        c.drawCircle(cx - 1f, cy + 3f, 1.9f, fill);
    }

    private void stump(Canvas c, float x, float y) {
        float cx = x + T * 0.5f, cy = y + T * 0.55f;
        fill.setColor(0xFF4A2F1A);
        c.drawOval(cx - 8f, cy - 3f, cx + 8f, cy + 6f, fill);
        fill.setColor(0xFFC8A06A);
        c.drawOval(cx - 8f, cy - 6f, cx + 8f, cy + 3f, fill);
        line.setColor(0xFF9A7448);
        line.setStrokeWidth(1f);
        c.drawOval(cx - 4f, cy - 4f, cx + 4f, cy + 1f, line);
    }

    private void rubble(Canvas c, float x, float y, int tx, int ty) {
        fill.setColor(0xFF7A6A58);
        int h = FloorRenderer.hash(tx, ty);
        for (int k = 0; k < 4; k++) {
            float rx = x + 5f + ((h >> (k * 4)) & 15) * 1.4f, ry = y + 6f + ((h >> (k * 3 + 2)) & 15) * 1.2f;
            c.drawRect(rx, ry, rx + 4f + (k & 1) * 2f, ry + 3f, fill);
        }
    }

    // ------------------------------------------------------------------ moving things

    private void drawZombie(Canvas c, Zombie z, float time, boolean night) {
        float s = z.type == Zombie.BRUTE ? 1.32f : (z.type == Zombie.RUNNER ? 0.94f : 1f);
        float x = z.rx, y = z.ry;
        float ang = z.rAim;
        float cs = (float) Math.cos(ang), sn = (float) Math.sin(ang);
        float px = -sn, py = cs;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        c.drawOval(x - 12f * s, y - 4f * s + 2f, x + 12f * s, y + 6f * s + 2f, fill);
        int skin = z.hurt > 0f ? 0xFFFFFFFF : (z.type == Zombie.BRUTE ? 0xFF8FA07A : (z.type == Zombie.RUNNER ? 0xFFA6B88A : 0xFF9DB382));
        int shirt = z.hurt > 0f ? 0xFFFFFFFF : (z.type == Zombie.BRUTE ? 0xFF4A3A3A : (z.type == Zombie.RUNNER ? 0xFF5A6A7A : 0xFF6A5A4A));
        float sway = (float) Math.sin(z.walk * 2f + z.id) * 2f;
        // legs
        fill.setColor(0xFF2E3238);
        float lf = (float) Math.sin(z.walk * 2f + z.id) * 3.5f * s;
        c.drawCircle(x + px * 3.5f * s + cs * lf, y + py * 3.5f * s + sn * lf, 3f * s, fill);
        c.drawCircle(x - px * 3.5f * s - cs * lf, y - py * 3.5f * s - sn * lf, 3f * s, fill);
        // arms reaching forward
        float shoulderZ = 13f * s;
        float ox = LEAN * shoulderZ, oy = -TILT * shoulderZ;
        float reach = (z.attacking ? 17f + (float) Math.sin(time * 16f) * 3f : 13f) * s;
        line.setColor(skin);
        line.setStrokeWidth(3.6f * s);
        for (int side = -1; side <= 1; side += 2) {
            float sx = x + ox + px * 6f * s * side, sy = y + oy + py * 6f * s * side;
            float ex = sx + cs * reach + px * side * sway * 0.3f, ey = sy + sn * reach + py * side * sway * 0.3f;
            c.drawLine(sx, sy, ex, ey, line);
        }
        // torso
        float tz = 10f * s;
        fill.setColor(shirt);
        c.drawCircle(x + LEAN * tz, y - TILT * tz, 7.8f * s, fill);
        fill.setColor(0x33000000);
        c.drawCircle(x + LEAN * tz + px * 2f, y - TILT * tz + py * 2f, 4f * s, fill);
        // head
        float hz = 20f * s;
        float hx = x + LEAN * hz + cs * 2f, hy = y - TILT * hz + sn * 2f;
        fill.setColor(skin);
        c.drawCircle(hx, hy, 5.6f * s, fill);
        fill.setColor(night ? 0xFFFF3A2A : 0xFF3A2020);
        c.drawCircle(hx + cs * 3f + px * 2f, hy + sn * 3f + py * 2f, 0.9f * s + 0.3f, fill);
        c.drawCircle(hx + cs * 3f - px * 2f, hy + sn * 3f - py * 2f, 0.9f * s + 0.3f, fill);
    }

    private void drawDrop(Canvas c, Drop d, float time) {
        float bob = (float) Math.sin(time * 3f + d.id) * 1.4f;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        c.drawOval(d.x - 8f, d.y - 2f, d.x + 8f, d.y + 4f, fill);
        int col = 0xFF000000 | (com.hazardyard.game.core.Items.color(d.item) & 0x00FFFFFF);
        fill.setColor((col & 0x00FFFFFF) | 0x33000000);
        c.drawCircle(d.x, d.y - 8f, 12f, fill);
        ItemGlyph.draw(c, fill, path2, d.x, d.y - 9f + bob, 7.5f, d.item, col);
    }

    private void drawCar(Canvas c, Car car, float time, boolean night) {
        float x = car.rx, y = car.ry, h = car.rHeading;
        float cs = (float) Math.cos(h), sn = (float) Math.sin(h);
        float px = -sn, py = cs;
        int[] bodies = {0xFFB8403A, 0xFF3A6AA8, 0xFFC8B84A, 0xFF4A8A5A, 0xFFD8D8DC, 0xFF3A3E46};
        int body = bodies[Math.abs(car.variant) % bodies.length];
        if (!car.engineOk || car.hp < 25) body = rust(body);
        // shadow
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0x44000000);
        poly4(x + 3f, y + 5f, cs, sn, px, py, 25f, 13f);
        c.drawPath(path, fill);
        // wheels
        fill.setColor(car.tyresOk ? 0xFF1E2126 : 0xFF50555E);
        for (int fx = -1; fx <= 1; fx += 2) {
            for (int sx = -1; sx <= 1; sx += 2) {
                float wx = x + cs * 15f * fx + px * 12f * sx, wy = y + sn * 15f * fx + py * 12f * sx;
                c.drawCircle(wx, wy - 2f, 4.4f, fill);
            }
        }
        extrude(c, x, y, cs, sn, px, py, 24f, 11.5f, 8f, body, shade(body, 0.78f), shade(body, 0.6f));
        // cabin
        extrude(c, x - cs * 2f, y - sn * 2f, cs, sn, px, py, 12f, 9.5f, 15f, shade(body, 1.08f), shade(body, 0.72f), shade(body, 0.55f), 8f);
        // windscreen
        float wz = 16f;
        float wx = x + cs * 8f + LEAN * wz, wy = y + sn * 8f - TILT * wz;
        path.reset();
        path.moveTo(wx + px * 8f, wy + py * 8f);
        path.lineTo(wx - px * 8f, wy - py * 8f);
        path.lineTo(wx - px * 8f + cs * 3f, wy - py * 8f + sn * 3f);
        path.lineTo(wx + px * 8f + cs * 3f, wy + py * 8f + sn * 3f);
        path.close();
        fill.setColor(0xCC9AD0F0);
        c.drawPath(path, fill);
        // lights
        if (car.running || night) {
            fill.setColor(car.running ? 0xFFFFF2B0 : 0x55FFF2B0);
            c.drawCircle(x + cs * 24f + px * 8f + LEAN * 6f, y + sn * 24f + py * 8f - TILT * 6f, 2.4f, fill);
            c.drawCircle(x + cs * 24f - px * 8f + LEAN * 6f, y + sn * 24f - py * 8f - TILT * 6f, 2.4f, fill);
        }
        if (car.running && car.speed > 20f) {
            fill.setColor(0x33FFFFFF);
            c.drawCircle(x - cs * 28f + LEAN * 4f, y - sn * 28f - TILT * 4f, 3f + (float) Math.sin(time * 20f), fill);
        }
        if (!car.engineOk && !car.running) {
            fill.setColor(0x44505050);
            c.drawCircle(x + cs * 18f + LEAN * 12f + (float) Math.sin(time * 2f) * 2f, y + sn * 18f - TILT * 12f - 6f - (time * 6f % 8f), 4f, fill);
        }
    }

    private static int rust(int c) {
        int r = ((c >> 16) & 255) * 6 / 10 + 40, g = ((c >> 8) & 255) * 5 / 10 + 20, b = (c & 255) * 4 / 10 + 10;
        return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
    }

    private static int shade(int c, float k) {
        int r = Math.min(255, (int) (((c >> 16) & 255) * k)), g = Math.min(255, (int) (((c >> 8) & 255) * k)), b = Math.min(255, (int) ((c & 255) * k));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private void poly4(float x, float y, float cs, float sn, float px, float py, float half, float wide) {
        path.reset();
        path.moveTo(x + cs * half + px * wide, y + sn * half + py * wide);
        path.lineTo(x + cs * half - px * wide, y + sn * half - py * wide);
        path.lineTo(x - cs * half - px * wide, y - sn * half - py * wide);
        path.lineTo(x - cs * half + px * wide, y - sn * half + py * wide);
        path.close();
    }

    private void extrude(Canvas c, float x, float y, float cs, float sn, float px, float py, float half, float wide, float h,
                         int top, int sideA, int sideB) {
        extrude(c, x, y, cs, sn, px, py, half, wide, h, top, sideA, sideB, 0f);
    }

    /** A box seen from the side: its visible walls, then its top, raised by {@code lift} (a cabin on a body). */
    private void extrude(Canvas c, float x, float y, float cs, float sn, float px, float py, float half, float wide, float h,
                         int top, int sideA, int sideB, float lift) {
        gx[0] = x + cs * half + px * wide;
        gy[0] = y + sn * half + py * wide;
        gx[1] = x + cs * half - px * wide;
        gy[1] = y + sn * half - py * wide;
        gx[2] = x - cs * half - px * wide;
        gy[2] = y - sn * half - py * wide;
        gx[3] = x - cs * half + px * wide;
        gy[3] = y - sn * half + py * wide;
        float vx = LEAN * h, vy = -TILT * h;
        float bx = LEAN * lift, by = -TILT * lift;
        for (int i = 0; i < 4; i++) {
            int j = (i + 1) & 3;
            float ex = gx[j] - gx[i], ey = gy[j] - gy[i];
            float nx = ey, ny = -ex;
            float mx = (gx[i] + gx[j]) * 0.5f - x, my = (gy[i] + gy[j]) * 0.5f - y;
            if (nx * mx + ny * my < 0f) {
                nx = -nx;
                ny = -ny;
            }
            if (nx * vx + ny * vy >= 0f) continue;         // this wall faces away from the viewer
            path.reset();
            path.moveTo(gx[i] + bx, gy[i] + by);
            path.lineTo(gx[j] + bx, gy[j] + by);
            path.lineTo(gx[j] + bx + vx, gy[j] + by + vy);
            path.lineTo(gx[i] + bx + vx, gy[i] + by + vy);
            path.close();
            fill.setColor(ny > 0.3f ? sideA : sideB);
            c.drawPath(path, fill);
        }
        path.reset();
        path.moveTo(gx[0] + bx + vx, gy[0] + by + vy);
        path.lineTo(gx[1] + bx + vx, gy[1] + by + vy);
        path.lineTo(gx[2] + bx + vx, gy[2] + by + vy);
        path.lineTo(gx[3] + bx + vx, gy[3] + by + vy);
        path.close();
        fill.setColor(top);
        c.drawPath(path, fill);
    }

    private void drawFishing(Canvas c, GameState st, float time) {
        SurvivalState sv = st.survival;
        for (int i = 0; i < st.players.length; i++) {
            if (sv.fishState[i] == 0) continue;
            Player p = st.players[i];
            if (!p.connected || !p.alive) continue;
            float fx = sv.fishX[i], fy = sv.fishY[i];
            boolean bite = sv.fishState[i] == 2;
            float dip = bite ? (float) Math.sin(time * 30f) * 1.5f + 2f : (float) Math.sin(time * 2.5f) * 0.8f;
            float hx = p.rx + (float) Math.cos(p.rAim) * 10f + LEAN * 12f, hy = p.ry + (float) Math.sin(p.rAim) * 10f - TILT * 12f;
            line.setColor(0xCCFFFFFF);
            line.setStrokeWidth(1.1f);
            c.drawLine(hx, hy, fx, fy + dip, line);
            line.setColor(0x66FFFFFF);
            line.setStrokeWidth(1.2f);
            float ring = (time * 14f) % 10f;
            c.drawCircle(fx, fy, 3f + ring, line);
            fill.setColor(0xFFE04A4A);
            c.drawCircle(fx, fy + dip, 3.6f, fill);
            fill.setColor(0xFFFFFFFF);
            c.drawCircle(fx, fy + dip - 1.6f, 1.8f, fill);
            if (bite) {
                fill.setColor(0xFFFFE066);
                c.drawCircle(fx, fy - 20f, 6f, fill);
                fill.setColor(0xFF402000);
                c.drawRect(fx - 1f, fy - 25f, fx + 1f, fy - 20f, fill);
                c.drawCircle(fx, fy - 16.5f, 1.1f, fill);
            }
        }
    }

    // ------------------------------------------------------------------ night

    /** Called after the world is drawn, in screen space: the dark, a circle of light round the survivor, warm light at fires. */
    void drawNight(Canvas c, GameState st, Camera cam, float time) {
        SurvivalState sv = st.survival;
        float light = sv.daylight();
        glint = time * 3f;
        if (light >= 0.97f) return;
        float dark = (1f - light);
        Player v = st.view();
        float sx = cam.screenX(v.rx), sy = cam.screenY(v.ry - 8f);
        float radius = Math.max(150f, 240f * cam.scale);
        int edgeA = (int) (dark * 215f);
        int midA = (int) (dark * 150f);
        night.setShader(new RadialGradient(sx, sy, radius,
                new int[] {0x00060A18, 0x00060A18, (midA << 24) | 0x060A18, (edgeA << 24) | 0x040612},
                new float[] {0f, 0.22f, 0.62f, 1f}, Shader.TileMode.CLAMP));
        // beyond the circle: the same darkness, flat
        night.setStyle(Paint.Style.FILL);
        c.drawRect(0f, 0f, cam.viewW, cam.viewH, night);
        night.setShader(null);
        // campfires and car headlights glow warm in the dark
        float hw = cam.halfViewWorldW() + 60f, hh = cam.halfViewWorldH() + 60f;
        int tx0 = (int) Math.floor((cam.x - hw) / T), tx1 = (int) Math.floor((cam.x + hw) / T);
        int ty0 = (int) Math.floor((cam.y - hh) / T), ty1 = (int) Math.floor((cam.y + hh) / T);
        for (int ty = ty0; ty <= ty1; ty++) {
            for (int tx = tx0; tx <= tx1; tx++) {
                if (sv.terrain.objAt(tx, ty) != Obj.CAMPFIRE) continue;
                float fx = cam.screenX((tx + 0.5f) * T), fy = cam.screenY((ty + 0.5f) * T);
                float r = 130f * cam.scale * (0.92f + 0.08f * (float) Math.sin(time * 9f + tx));
                glow.setShader(new RadialGradient(fx, fy, r, new int[] {(int) (dark * 150f) << 24 | 0xFFA040, 0x00FF8A2A},
                        new float[] {0f, 1f}, Shader.TileMode.CLAMP));
                c.drawCircle(fx, fy, r, glow);
                glow.setShader(null);
            }
        }
        for (Car car : sv.cars) {
            if (!car.active || !car.running) continue;
            float fx = cam.screenX(car.rx + (float) Math.cos(car.rHeading) * 60f), fy = cam.screenY(car.ry + (float) Math.sin(car.rHeading) * 60f);
            float r = 120f * cam.scale;
            glow.setShader(new RadialGradient(fx, fy, r, new int[] {(int) (dark * 110f) << 24 | 0xFFF0B0, 0x00FFF0B0},
                    new float[] {0f, 1f}, Shader.TileMode.CLAMP));
            c.drawCircle(fx, fy, r, glow);
            glow.setShader(null);
        }
    }

    private void quad(Canvas c, float ax, float ay, float bx, float by, float cx, float cy, float dx, float dy) {
        path.reset();
        path.moveTo(ax, ay);
        path.lineTo(bx, by);
        path.lineTo(cx, cy);
        path.lineTo(dx, dy);
        path.close();
        c.drawPath(path, fill);
    }
}
