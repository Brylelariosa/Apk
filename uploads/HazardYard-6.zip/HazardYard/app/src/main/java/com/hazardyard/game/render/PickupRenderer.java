package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.render.model.GunModels;
import com.hazardyard.game.render.model.SceneBuffer;
import com.hazardyard.game.render.model.SoldierModel;

/**
 * An item pickup. A gun is drawn as its own 3D model hovering above its pad, spinning and bobbing; vests, kits and the
 * other things are flat icons that bob in the same place with a soft glow under them.
 */
final class PickupRenderer {
    private static final float SCALE = 1.3f;

    private final PolyDrawer poly;
    private final SceneBuffer scene = new SceneBuffer(160, 1400);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    PickupRenderer(PolyDrawer poly) {
        this.poly = poly;
    }

    void draw(Canvas c, Pickup pk, int index, float time) {
        float bob = (float) Math.sin(time * 2.4f + index * 1.3f) * 1.6f;
        if (!pk.isWeapon()) {
            drawFlat(c, pk, bob);
            return;
        }
        float spin = time * 1.35f + index * 0.9f;
        scene.begin();
        scene.yaw[SoldierModel.G_GUN] = spin;
        scene.offX[SoldierModel.G_GUN] = -GunModels.displayCenterX(pk.item);
        scene.offZ[SoldierModel.G_GUN] = -14.7f;      // the models are authored at soldier grip height
        scene.addMesh(GunModels.display(pk.item), pk.x, pk.y, 15f + bob, SCALE, 0xFFFFFFFF, 0.18f);
        poly.begin(c);
        scene.flush(poly);
    }

    private void drawFlat(Canvas c, Pickup pk, float bob) {
        int color = 0xFF000000 | (Items.color(pk.item) & 0x00FFFFFF);
        float y = pk.y - 17f + bob;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor((color & 0x00FFFFFF) | 0x33000000);
        c.drawCircle(pk.x, pk.y - 2f, 15f, fill);
        fill.setColor(0x66101820);
        c.drawCircle(pk.x, y, 13.5f, fill);
        ItemGlyph.draw(c, fill, path, pk.x, y, 10.5f, pk.item, color);
    }
}
