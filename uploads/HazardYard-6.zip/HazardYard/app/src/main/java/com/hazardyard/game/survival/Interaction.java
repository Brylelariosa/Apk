package com.hazardyard.game.survival;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.Player;

/**
 * The one thing the Pick Up button would do for a survivor right now: take an item off the ground, search a cupboard, open
 * a door, pick a ripe crop, get into or repair a car. Found the same way on the host (to do it) and on a client (to label
 * the button), from the survivor's position and the world around them.
 */
public final class Interaction {
    public static final int NONE = 0, DROP = 1, CAR = 2, CONTAINER = 3, DOOR = 4, CROP = 5, BUSH = 6;

    public int kind;
    public int tx, ty;
    public int id;
    public String title = "";
    public String sub = "";
    /** An item whose icon stands for the action on the button. */
    public int icon = Items.CANNED;

    public void clear() {
        kind = NONE;
        title = "";
        sub = "";
    }

    private static final float DROP_REACH = 46f;
    private static final float TILE_REACH = 54f;
    private static final float CAR_REACH = 62f;

    /** Fills this with the best interaction around the survivor; returns false (and kind NONE) when there is none. */
    public boolean find(SurvivalState sv, Player p) {
        clear();
        if (!p.alive) return false;
        Inventory inv = sv.inv[p.id];
        // sitting in a car: the only thing to do is get out
        int carId = sv.drivingCar[p.id];
        if (carId >= 0) {
            kind = CAR;
            id = carId;
            title = "Car";
            sub = "Get out";
            icon = Items.WRENCH;
            return true;
        }
        float best = Float.MAX_VALUE;
        // dropped items
        for (Drop d : sv.drops) {
            if (!d.active) continue;
            float dx = d.x - p.x, dy = d.y - p.y;
            float dist = dx * dx + dy * dy;
            if (dist < DROP_REACH * DROP_REACH && dist < best) {
                best = dist;
                kind = DROP;
                id = d.id;
                title = Items.name(d.item) + (d.count > 1 ? " x" + d.count : "");
                sub = "Pick up";
                icon = d.item;
            }
        }
        if (kind != NONE) return true;
        // cars
        Car bestCar = null;
        for (Car c : sv.cars) {
            if (!c.active) continue;
            float dx = c.x - p.x, dy = c.y - p.y;
            float dist = dx * dx + dy * dy;
            if (dist < CAR_REACH * CAR_REACH && dist < best) {
                best = dist;
                bestCar = c;
            }
        }
        if (bestCar != null) {
            kind = CAR;
            id = bestCar.id;
            icon = Items.WRENCH;
            title = "Car";
            String need = carNeed(bestCar, inv);
            if (need != null && need.startsWith("fit:")) {
                sub = "Fit " + need.substring(4);
            } else {
                sub = bestCar.ready() ? "Get in" : "Get in (needs " + (need == null ? "repairs" : need.substring(need.indexOf(':') + 1)) + ")";
            }
            return true;
        }
        // objects on the tiles around
        int ptx = (int) Math.floor(p.x / GameConfig.TILE);
        int pty = (int) Math.floor(p.y / GameConfig.TILE);
        SurvivalTerrain t = sv.terrain;
        for (int dy = -2; dy <= 2; dy++) {
            for (int dx = -2; dx <= 2; dx++) {
                int tx = ptx + dx, ty = pty + dy;
                byte o = t.objAt(tx, ty);
                if (o == Obj.NONE) continue;
                float cx = (tx + 0.5f) * GameConfig.TILE - p.x;
                float cy = (ty + 0.5f) * GameConfig.TILE - p.y;
                float dist = cx * cx + cy * cy;
                if (dist > TILE_REACH * TILE_REACH || dist >= best) continue;
                int meta = t.metaAt(tx, ty);
                if (Obj.container(o) && (meta & Obj.SEARCHED) == 0) {
                    take(CONTAINER, tx, ty, Obj.name(o), "Search", Items.CANNED);
                    best = dist;
                } else if (o == Obj.DOOR) {
                    take(DOOR, tx, ty, "Door", (meta & 1) != 0 ? "Close" : "Open", Items.DOOR);
                    best = dist;
                } else if (o == Obj.CROP && (meta & 3) == 3) {
                    boolean potato = ((meta >> 2) & 3) == 1;
                    take(CROP, tx, ty, potato ? "Potatoes" : "Carrots", "Harvest", potato ? Items.POTATO : Items.CARROT);
                    best = dist;
                } else if (o == Obj.BUSH) {
                    take(BUSH, tx, ty, "Berry bush", "Pick berries", Items.BERRIES);
                    best = dist;
                }
            }
        }
        return kind != NONE;
    }

    private void take(int k, int tx, int ty, String title, String sub, int icon) {
        kind = k;
        this.tx = tx;
        this.ty = ty;
        this.title = title;
        this.sub = sub;
        this.icon = icon;
    }

    /**
     * What a car lacks, from the point of view of a survivor with this pack: {@code "fit:Battery"} when they carry what
     * the first missing part needs, {@code "need:battery"} when they do not, or null when the car is complete.
     */
    public static String carNeed(Car c, Inventory inv) {
        if (!c.tyresOk) return inv.has(Items.TIRE, 1) ? "fit:Tyre" : "need:a tyre";
        if (!c.batteryOk) return inv.has(Items.BATTERY, 1) ? "fit:Battery" : "need:a battery";
        if (!c.engineOk) {
            if (!inv.has(Items.ENGINE, 1)) return "need:engine parts";
            return inv.has(Items.WRENCH, 1) ? "fit:Engine" : "need:a wrench";
        }
        if (c.fuel < 20) return inv.has(Items.GAS_CAN, 1) ? "fit:Fuel" : "need:fuel";
        return null;
    }
}
