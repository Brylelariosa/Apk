package com.hazardyard.game.survival;

/**
 * A car: a wreck at first. It needs a battery, an engine in working order, a tyre and some fuel before it will start;
 * the parts are found as loot and fitted with the Pick Up button (the engine needs a wrench). Whoever sits in it drives.
 */
public final class Car {
    public static final int F_ENGINE = 1, F_BATTERY = 2, F_TYRES = 4, F_RUNNING = 8;
    public static final float RADIUS = 21f;
    public static final float MAX_SPEED = 330f;

    public int id;
    /** Client: the snapshot this entity was last in (older ones are gone). */
    public int seen;
    public boolean active;
    public float x, y, heading, speed;
    /** Driver's player slot, or -1. */
    public int driver = -1;
    public int fuel;           // 0..100
    public int hp = 100;
    public boolean engineOk, batteryOk, tyresOk;
    public boolean running;
    /** Smoothed values for drawing (clients). */
    public float rx, ry, rHeading;
    public int variant;

    public boolean ready() {
        return engineOk && batteryOk && tyresOk && fuel > 0 && hp > 0;
    }

    public int flags() {
        return (engineOk ? F_ENGINE : 0) | (batteryOk ? F_BATTERY : 0) | (tyresOk ? F_TYRES : 0) | (running ? F_RUNNING : 0);
    }

    public void setFlags(int f) {
        engineOk = (f & F_ENGINE) != 0;
        batteryOk = (f & F_BATTERY) != 0;
        tyresOk = (f & F_TYRES) != 0;
        running = (f & F_RUNNING) != 0;
    }
}
