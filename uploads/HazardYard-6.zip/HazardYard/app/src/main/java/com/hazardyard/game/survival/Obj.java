package com.hazardyard.game.survival;

import com.hazardyard.game.core.TileMap;

/**
 * The things that can stand on a survival-world tile (the ground type is a separate layer). Each tile also has a
 * {@code meta} byte whose meaning depends on the object: damage taken (trees and rocks), hit points (walls, doors),
 * open flag (doors), growth stage (crops), searched flag and source building (furniture you can search).
 */
public final class Obj {
    private Obj() {}

    public static final byte NONE = 0;
    public static final byte TREE = 1;
    public static final byte ROCK = 2;
    public static final byte BUSH = 3;
    public static final byte STUMP = 4;
    public static final byte WALL = 5;
    public static final byte DOOR = 6;
    public static final byte CUPBOARD = 7;
    public static final byte FRIDGE = 8;
    public static final byte SHELF = 9;
    public static final byte WARDROBE = 10;
    public static final byte TOOLBOX = 11;
    public static final byte GUNCASE = 12;
    public static final byte CRATE = 13;
    public static final byte TABLE = 14;
    public static final byte BED = 15;
    public static final byte CAMPFIRE = 16;
    public static final byte WORKBENCH = 17;
    public static final byte CROP = 18;
    public static final byte RUBBLE = 19;
    public static final int COUNT = 20;

    /** Container meta: the container has been searched. Bits 0..2 hold the kind of building it stands in. */
    public static final int SEARCHED = 0x80;
    /** Door meta: bit 0 is the open flag, bits 1..7 are the hit points in units of 8. */
    /** Wall meta: hit points in units of 4; this value means it cannot be broken. */
    public static final int UNBREAKABLE_WALL = 255;

    public static boolean container(byte o) {
        return o >= CUPBOARD && o <= CRATE;
    }

    /** True for objects a fighter walks around (furniture, walls, trees...). */
    public static boolean solid(byte o, int meta) {
        switch (o) {
            case TREE: case ROCK: case WALL: case CUPBOARD: case FRIDGE: case SHELF: case WARDROBE: case TOOLBOX:
            case GUNCASE: case CRATE: case TABLE: case BED: case WORKBENCH:
                return true;
            case DOOR:
                return (meta & 1) == 0;
            default:
                return false;
        }
    }

    /** The {@link TileMap} kind the collision system uses for this object (FLOOR for anything walk-through). */
    public static byte collisionKind(byte o, int meta) {
        switch (o) {
            case TREE: return TileMap.TREE;
            case ROCK: return TileMap.ROCK;
            case WALL: return TileMap.WALL;
            case DOOR: return (meta & 1) == 0 ? TileMap.WALL : TileMap.FLOOR;
            case CUPBOARD: case FRIDGE: case SHELF: case WARDROBE: case TOOLBOX: case GUNCASE: case CRATE: case TABLE:
            case BED: case WORKBENCH:
                return TileMap.CRATE;
            default:
                return TileMap.FLOOR;
        }
    }

    public static String name(byte o) {
        switch (o) {
            case TREE: return "Tree";
            case ROCK: return "Boulder";
            case BUSH: return "Berry Bush";
            case STUMP: return "Stump";
            case WALL: return "Wall";
            case DOOR: return "Door";
            case CUPBOARD: return "Cupboard";
            case FRIDGE: return "Fridge";
            case SHELF: return "Shelves";
            case WARDROBE: return "Wardrobe";
            case TOOLBOX: return "Toolbox";
            case GUNCASE: return "Gun Case";
            case CRATE: return "Crate";
            case TABLE: return "Table";
            case BED: return "Bed";
            case CAMPFIRE: return "Campfire";
            case WORKBENCH: return "Workbench";
            case CROP: return "Crop";
            default: return "";
        }
    }
}
