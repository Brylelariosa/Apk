package com.hazardyard.game.core;

/**
 * The registry of everything a player can carry or find lying around. One id space for all game modes:
 * <ul>
 *   <li>0..31: weapons (the id is the {@link WeaponDef} id: guns first, then melee weapons and tools such as the axe);</li>
 *   <li>32 and up: vests, medicine, materials, food, seeds, tools, car parts, ammunition and things to build.</li>
 * </ul>
 * Ids never change once shipped (they travel over the network and live in save files). Battleground pads only ever
 * hold weapons, vests and first-aid kits; the survival items are used by the survival mode (see
 * {@code com.hazardyard.game.survival}).
 */
public final class Items {
    private Items() {}

    // ---- categories
    public static final int CAT_WEAPON = 0;
    public static final int CAT_ARMOR = 1;
    public static final int CAT_HEAL = 2;
    public static final int CAT_FOOD = 3;
    public static final int CAT_MATERIAL = 4;
    public static final int CAT_TOOL = 5;
    public static final int CAT_SEED = 6;
    public static final int CAT_PART = 7;
    public static final int CAT_AMMO = 8;
    public static final int CAT_BUILD = 9;

    /** First id that is not a weapon. */
    public static final int FIRST_OTHER = 32;

    public static final int VEST_LIGHT = 32;
    public static final int VEST_HEAVY = 33;
    public static final int MEDKIT = 34;
    public static final int BANDAGE = 35;
    public static final int WOOD = 36;
    public static final int STONE = 37;
    public static final int FIBER = 38;
    public static final int SCRAP = 39;
    public static final int CLOTH = 40;
    public static final int NAILS = 41;
    public static final int BERRIES = 42;
    public static final int APPLE = 43;
    public static final int CARROT = 44;
    public static final int POTATO = 45;
    public static final int FISH_RAW = 46;
    public static final int FISH_COOKED = 47;
    public static final int CANNED = 48;
    public static final int BREAD = 49;
    public static final int SEED_CARROT = 50;
    public static final int SEED_POTATO = 51;
    public static final int HOE = 52;
    public static final int ROD = 53;
    public static final int WRENCH = 54;
    public static final int TIRE = 55;
    public static final int BATTERY = 56;
    public static final int ENGINE = 57;
    public static final int GAS_CAN = 58;
    public static final int AMMO_BULLETS = 59;
    public static final int AMMO_RIFLE = 60;
    public static final int AMMO_SHELLS = 61;
    public static final int WALL = 62;
    public static final int DOOR = 63;
    public static final int FLOOR = 64;
    public static final int CAMPFIRE = 65;
    public static final int WORKBENCH = 66;
    public static final int COUNT = 67;

    /** Items of Battleground and the classic arenas only (the guns have their own ids below {@link #FIRST_OTHER}). */
    public static final int LIGHT_VEST_ARMOR = 50;
    public static final int HEAVY_VEST_ARMOR = 100;
    /** Health a first-aid kit restores. */
    public static final int MEDKIT_HEAL = 50;
    public static final int BANDAGE_HEAL = 20;

    private static final String[] NAME = new String[COUNT];
    private static final int[] COLOR = new int[COUNT];
    private static final int[] CATEGORY = new int[COUNT];
    private static final int[] STACK = new int[COUNT];
    private static final int[] ICON = new int[COUNT];
    private static final int[] VALUE = new int[COUNT];

    /** Icon shapes, drawn by the renderer ({@code ItemGlyph}). */
    public static final int I_VEST = 1, I_CROSS = 2, I_LOGS = 3, I_ROCK = 4, I_FIBER = 5, I_SCRAP = 6, I_CLOTH = 7,
            I_NAILS = 8, I_BERRIES = 9, I_APPLE = 10, I_CARROT = 11, I_POTATO = 12, I_FISH = 13, I_CAN = 14, I_BREAD = 15,
            I_SEEDS = 16, I_HOE = 17, I_ROD = 18, I_WRENCH = 19, I_TIRE = 20, I_BATTERY = 21, I_ENGINE = 22, I_GAS = 23,
            I_BULLETS = 24, I_SHELLS = 25, I_WALL = 26, I_DOOR = 27, I_FLOOR = 28, I_FIRE = 29, I_BENCH = 30, I_BANDAGE = 31,
            I_GUN = 32, I_MELEE = 33;

    private static void def(int id, String name, int color, int cat, int stack, int icon, int value) {
        NAME[id] = name;
        COLOR[id] = color;
        CATEGORY[id] = cat;
        STACK[id] = stack;
        ICON[id] = icon;
        VALUE[id] = value;
    }

    static {
        def(VEST_LIGHT, "Light Vest", 0xFF6FB6FF, CAT_ARMOR, 1, I_VEST, LIGHT_VEST_ARMOR);
        def(VEST_HEAVY, "Heavy Vest", 0xFF4F8CFF, CAT_ARMOR, 1, I_VEST, HEAVY_VEST_ARMOR);
        def(MEDKIT, "First Aid Kit", 0xFF6EE08A, CAT_HEAL, 4, I_CROSS, MEDKIT_HEAL);
        def(BANDAGE, "Bandage", 0xFFE8E8E8, CAT_HEAL, 8, I_BANDAGE, BANDAGE_HEAL);
        def(WOOD, "Wood", 0xFFB07840, CAT_MATERIAL, 30, I_LOGS, 0);
        def(STONE, "Stone", 0xFF9AA0A8, CAT_MATERIAL, 30, I_ROCK, 0);
        def(FIBER, "Plant Fibre", 0xFF7DBE5A, CAT_MATERIAL, 30, I_FIBER, 0);
        def(SCRAP, "Scrap Metal", 0xFF8C96A6, CAT_MATERIAL, 30, I_SCRAP, 0);
        def(CLOTH, "Cloth", 0xFFD8D2C0, CAT_MATERIAL, 20, I_CLOTH, 0);
        def(NAILS, "Nails", 0xFFB0B8C4, CAT_MATERIAL, 40, I_NAILS, 0);
        def(BERRIES, "Berries", 0xFFA24BD0, CAT_FOOD, 10, I_BERRIES, 8);
        def(APPLE, "Apple", 0xFFE04A3F, CAT_FOOD, 10, I_APPLE, 12);
        def(CARROT, "Carrot", 0xFFFF9534, CAT_FOOD, 10, I_CARROT, 14);
        def(POTATO, "Potato", 0xFFC9A064, CAT_FOOD, 10, I_POTATO, 16);
        def(FISH_RAW, "Raw Fish", 0xFF7FA6C4, CAT_FOOD, 8, I_FISH, 8);
        def(FISH_COOKED, "Cooked Fish", 0xFFE0A06A, CAT_FOOD, 8, I_FISH, 38);
        def(CANNED, "Canned Food", 0xFFC8B26A, CAT_FOOD, 6, I_CAN, 34);
        def(BREAD, "Bread", 0xFFE0B878, CAT_FOOD, 6, I_BREAD, 28);
        def(SEED_CARROT, "Carrot Seeds", 0xFFFFB066, CAT_SEED, 20, I_SEEDS, 0);
        def(SEED_POTATO, "Potato Seeds", 0xFFD9B77A, CAT_SEED, 20, I_SEEDS, 0);
        def(HOE, "Hoe", 0xFFB8A070, CAT_TOOL, 1, I_HOE, 0);
        def(ROD, "Fishing Rod", 0xFF7AC0E8, CAT_TOOL, 1, I_ROD, 0);
        def(WRENCH, "Wrench", 0xFFB0B8C4, CAT_TOOL, 1, I_WRENCH, 0);
        def(TIRE, "Tyre", 0xFF50555E, CAT_PART, 4, I_TIRE, 0);
        def(BATTERY, "Car Battery", 0xFFE6C84A, CAT_PART, 1, I_BATTERY, 0);
        def(ENGINE, "Engine Parts", 0xFFC87C50, CAT_PART, 1, I_ENGINE, 0);
        def(GAS_CAN, "Gas Can", 0xFFE05A4A, CAT_PART, 1, I_GAS, 0);
        def(AMMO_BULLETS, "Bullets", 0xFFFFD36A, CAT_AMMO, 90, I_BULLETS, 0);
        def(AMMO_RIFLE, "Rifle Rounds", 0xFFFFB347, CAT_AMMO, 90, I_BULLETS, 0);
        def(AMMO_SHELLS, "Shotgun Shells", 0xFFFF7A59, CAT_AMMO, 40, I_SHELLS, 0);
        def(WALL, "Wood Wall", 0xFFB07840, CAT_BUILD, 20, I_WALL, 0);
        def(DOOR, "Wood Door", 0xFFA06A38, CAT_BUILD, 10, I_DOOR, 0);
        def(FLOOR, "Wood Floor", 0xFFC89A60, CAT_BUILD, 40, I_FLOOR, 0);
        def(CAMPFIRE, "Campfire", 0xFFFF8A3A, CAT_BUILD, 4, I_FIRE, 0);
        def(WORKBENCH, "Workbench", 0xFF9A7448, CAT_BUILD, 2, I_BENCH, 0);
    }

    public static boolean isWeapon(int item) {
        return item >= 0 && item < WeaponDef.ALL.length;
    }

    public static boolean isValid(int item) {
        return isWeapon(item) || (item >= FIRST_OTHER && item < COUNT);
    }

    public static boolean isVest(int item) {
        return item == VEST_LIGHT || item == VEST_HEAVY;
    }

    public static boolean isMedkit(int item) {
        return item == MEDKIT;
    }

    public static int category(int item) {
        if (isWeapon(item)) return CAT_WEAPON;
        return item >= FIRST_OTHER && item < COUNT ? CATEGORY[item] : CAT_MATERIAL;
    }

    /** Armour points a vest item gives (0 for everything else). */
    public static int armorOf(int item) {
        return isVest(item) ? VALUE[item] : 0;
    }

    /** Hunger points a food item restores (0 for everything else). */
    public static int foodValue(int item) {
        return category(item) == CAT_FOOD ? VALUE[item] : 0;
    }

    /** Health a medicine item restores (0 for everything else). */
    public static int healValue(int item) {
        return category(item) == CAT_HEAL ? VALUE[item] : 0;
    }

    /** Most of this item in one inventory slot. */
    public static int stackMax(int item) {
        if (isWeapon(item)) return 1;
        return item >= FIRST_OTHER && item < COUNT ? STACK[item] : 1;
    }

    public static int icon(int item) {
        if (isWeapon(item)) return WeaponDef.byId(item).melee ? I_MELEE : I_GUN;
        return item >= FIRST_OTHER && item < COUNT ? ICON[item] : 0;
    }

    public static String name(int item) {
        if (isWeapon(item)) return WeaponDef.byId(item).name;
        return item >= FIRST_OTHER && item < COUNT ? NAME[item] : "Item";
    }

    /** The colour of an item's pad, button and slot (ARGB). */
    public static int color(int item) {
        if (isWeapon(item)) return WeaponDef.byId(item).color;
        return item >= FIRST_OTHER && item < COUNT ? COLOR[item] : 0xFFFFFFFF;
    }

    /** The ammunition item a gun uses (survival), or -1 for melee weapons and the plasma rifle. */
    public static int ammoFor(int weaponId) {
        WeaponDef d = WeaponDef.byId(weaponId);
        if (d.melee || d.id == WeaponDef.PLASMA) return -1;
        return d.ammoItem;
    }

    /** What the Pick Up button says it does with this item, given what the player holds now. */
    public static String effect(Player holder, int item) {
        if (isWeapon(item)) {
            Weapon w = holder.weapon;
            return w.def.id == item ? "Refill ammo" : "Replaces " + w.def.name;
        }
        if (isVest(item)) {
            int a = holder.armor;
            return a <= 0 ? "Armour +" + armorOf(item) : "Armour " + a + " \u2192 " + armorOf(item);
        }
        if (isMedkit(item)) return "Health +" + Math.min(MEDKIT_HEAL, GameConfig.PLAYER_MAX_HEALTH - holder.health);
        return "Pick up";
    }
}
