package com.hazardyard.game.core;

/**
 * Immutable description of a weapon. All weapons share the same firing code; only these numbers
 * differ, so adding a weapon means adding one entry to {@link #ALL}.
 */
public final class WeaponDef {
    public static final int PISTOL = 0;
    public static final int RIFLE = 1;
    public static final int SHOTGUN = 2;
    public static final int SMG = 3;
    public static final int SNIPER = 4;
    public static final int MAGNUM = 5;
    public static final int PLASMA = 6;
    public static final int LMG = 7;
    public static final int REVOLVER = 8;
    public static final int DOUBLE_BARREL = 9;
    public static final int HUNTING_RIFLE = 10;
    public static final int AK = 11;
    public static final int DMR = 12;
    public static final int MACHINE_PISTOL = 13;
    /** Number of firearms; the melee weapons follow them. */
    public static final int GUN_COUNT = 14;
    public static final int KNIFE = 14;
    public static final int BAT = 15;
    public static final int CROWBAR = 16;
    public static final int MACHETE = 17;
    public static final int AXE = 18;
    public static final int PICKAXE = 19;
    /** Bare hands: what a survivor holds while the selected item is not a weapon. Never found as loot. */
    public static final int FISTS = 20;

    /** What a melee weapon can harvest in survival mode besides hurting things. */
    public static final int TOOL_NONE = 0;
    public static final int TOOL_AXE = 1;
    public static final int TOOL_PICK = 2;

    /** Bullet look: a thin tracer, or a glowing energy bolt. */
    public static final int STYLE_BULLET = 0;
    public static final int STYLE_ENERGY = 1;

    /** Reload style: the empty magazine is swapped; its rounds all arrive when the new one seats. */
    public static final int RELOAD_MAG = 0;
    /** Reload style: rounds go in one at a time (a tube-fed shotgun), each one counts as soon as it is in. */
    public static final int RELOAD_SHELLS = 1;

    public final int id;
    public final String name;
    public final int damage;
    /** Seconds between two shots. */
    public final float fireInterval;
    public final int magSize;
    /**
     * Seconds a complete reload from empty takes. For {@link #RELOAD_MAG} this is the whole swap; for
     * {@link #RELOAD_SHELLS} it is {@link #loadLead} + one {@link #loadPerRound} per round + {@link #loadTail}.
     */
    public final float reloadTime;
    /** {@link #RELOAD_MAG} or {@link #RELOAD_SHELLS}. */
    public final int reloadStyle;
    /** Magazine reloads: share of the reload (0..1) after which the fresh magazine is in and the ammo is back. */
    public final float seatFraction;
    /** Shell reloads: seconds before the first round goes in, per round, and after the last one (closing the action). */
    public final float loadLead, loadPerRound, loadTail;
    /**
     * Seconds after a shot until the weapon's mechanical action is heard (pump, bolt, hammer and
     * cylinder); 0 for guns that cycle on their own. Presentation only.
     */
    public final float actionDelay;
    /** World units per second. */
    public final float projectileSpeed;
    /** Half-angle of the random cone in radians. */
    public final float spread;
    /** World units a bullet travels before it disappears. */
    public final float range;
    /**
     * True: keeps firing at {@link #fireInterval} while the aim stick is held. False: one shot per
     * trigger pull. Every built-in gun is automatic, so holding the stick always shoots.
     */
    public final boolean automatic;
    /** Fast spray weapon (bots shoot it in bursts instead of holding the trigger down). */
    public final boolean rapidFire;
    public final int pellets;

    // presentation only
    public final float barrelLength;
    public final float barrelWidth;
    public final float bulletRadius;
    public final int color;
    public final int style;
    /**
     * Camera zoom while this gun is equipped, a multiplier on the standard view: 1 is the standard
     * view, below 1 pulls the camera back (sees further, for long-range guns), above 1 moves it in
     * closer (for close-range guns). The camera eases between the zooms when the gun changes.
     */
    public final float zoom;

    // ---- melee (see GameWorld): a swing hits everything in an arc in front of the fighter {@link #hitDelay} seconds
    // after it starts. Guns have melee == false and the numbers below zero.
    public final boolean melee;
    /** World units from the fighter's centre to the tip of the blow (a target is hit when its edge is within it). */
    public final float reach;
    /** Half-angle of the arc, radians. */
    public final float arc;
    /** Seconds between the start of a swing and the moment it lands. */
    public final float hitDelay;
    /** {@link #TOOL_AXE} chops trees, {@link #TOOL_PICK} breaks rocks (survival); {@link #TOOL_NONE} only fights. */
    public final int toolKind;
    /** Survival: the ammunition item this gun uses (an {@link Items} id), or -1. */
    public final int ammoItem;

    /** A melee weapon. */
    private WeaponDef(int id, String name, int damage, float interval, float reach, float arcDegrees, float hitDelay,
                      int color, float zoom, int toolKind) {
        this.id = id;
        this.name = name;
        this.damage = damage;
        this.fireInterval = interval;
        this.magSize = 1;
        this.reloadTime = 0f;
        this.reloadStyle = RELOAD_MAG;
        this.seatFraction = 0.5f;
        this.loadLead = 0f;
        this.loadPerRound = 0f;
        this.loadTail = 0f;
        this.actionDelay = 0f;
        this.projectileSpeed = 0f;
        this.spread = 0f;
        this.range = reach;
        this.automatic = true;
        this.rapidFire = false;
        this.pellets = 0;
        this.barrelLength = 0f;
        this.barrelWidth = 0f;
        this.bulletRadius = 0f;
        this.color = color;
        this.style = STYLE_BULLET;
        this.zoom = MathUtil.clamp(zoom, GameConfig.ZOOM_MIN, GameConfig.ZOOM_MAX);
        this.melee = true;
        this.reach = reach;
        this.arc = (float) Math.toRadians(arcDegrees);
        this.hitDelay = hitDelay;
        this.toolKind = toolKind;
        this.ammoItem = -1;
    }

    private static int ammoItemFor(int id, int pellets, int reloadStyle) {
        if (id == PLASMA) return -1;
        if (pellets > 1) return Items.AMMO_SHELLS;
        switch (id) {
            case RIFLE: case SNIPER: case LMG: case AK: case DMR: case HUNTING_RIFLE: return Items.AMMO_RIFLE;
            default: return Items.AMMO_BULLETS;
        }
    }

    private WeaponDef(int id, String name, int damage, float fireInterval, int magSize, float reloadTime,
                      float projectileSpeed, float spreadDegrees, float range, boolean automatic, int pellets,
                      float barrelLength, float barrelWidth, float bulletRadius, int color, int style, float zoom,
                      int reloadStyle, float seatFraction, float loadLead, float loadPerRound, float loadTail,
                      float actionDelay) {
        this.id = id;
        this.name = name;
        this.damage = damage;
        this.fireInterval = fireInterval;
        this.magSize = magSize;
        this.reloadStyle = reloadStyle;
        this.seatFraction = MathUtil.clamp(seatFraction, 0.1f, 0.95f);
        this.loadLead = loadLead;
        this.loadPerRound = loadPerRound;
        this.loadTail = loadTail;
        this.actionDelay = actionDelay;
        this.reloadTime = reloadStyle == RELOAD_SHELLS ? loadLead + magSize * loadPerRound + loadTail : reloadTime;
        this.projectileSpeed = projectileSpeed;
        this.spread = (float) Math.toRadians(spreadDegrees);
        this.range = range;
        this.automatic = automatic;
        this.rapidFire = fireInterval < 0.2f;
        this.pellets = pellets;
        this.barrelLength = barrelLength;
        this.barrelWidth = barrelWidth;
        this.bulletRadius = bulletRadius;
        this.color = color;
        this.style = style;
        this.zoom = MathUtil.clamp(zoom, GameConfig.ZOOM_MIN, GameConfig.ZOOM_MAX);
        this.melee = false;
        this.reach = 0f;
        this.arc = 0f;
        this.hitDelay = 0f;
        this.toolKind = TOOL_NONE;
        this.ammoItem = ammoItemFor(id, pellets, reloadStyle);
    }

    public static final WeaponDef[] ALL = {
        // Reload numbers: MAG weapons give (total seconds, share at which the new magazine seats); the shotgun
        // gives (lead, seconds per shell, tail). The last number is the delay of the mechanical action sound.
        //        id       name             dmg  interval mag  reload speed  spread range auto   pellets barrel width bullet color        style         zoom  rStyle      seat  lead  /rnd  tail  action
        new WeaponDef(PISTOL,  "Pistol",          20, 0.22f, 12, 1.00f,  560f, 1.5f,  420f, true,  1,  9f,  4f, 2.5f, 0xFFFFE08A, STYLE_BULLET, 1.00f, RELOAD_MAG,    0.62f, 0f,    0f,    0f,    0f),
        new WeaponDef(RIFLE,   "Assault Rifle",   15, 0.12f, 30, 1.75f,  660f, 3.0f,  540f, true,  1, 15f,  4f, 2.5f, 0xFFFFB347, STYLE_BULLET, 0.90f, RELOAD_MAG,    0.60f, 0f,    0f,    0f,    0f),
        new WeaponDef(SHOTGUN, "Shotgun",          9, 0.85f,  6, 0f,     520f, 8.0f,  260f, true,  8, 13f,  6f, 2.2f, 0xFFFF7A59, STYLE_BULLET, 1.15f, RELOAD_SHELLS, 0f,     0.50f, 0.42f, 0.45f, 0.34f),
        new WeaponDef(SMG,     "SMG",              8, 0.07f, 35, 1.55f,  600f, 6.0f,  330f, true,  1, 11f,  4f, 2.0f, 0xFF8DE0FF, STYLE_BULLET, 1.08f, RELOAD_MAG,    0.58f, 0f,    0f,    0f,    0f),
        new WeaponDef(SNIPER,  "Sniper Rifle",    70, 1.15f,  4, 2.60f, 1500f, 0.2f, 1100f, true,  1, 22f,  3f, 2.2f, 0xFFE6F0FF, STYLE_BULLET, 0.70f, RELOAD_MAG,    0.50f, 0f,    0f,    0f,    0.46f),
        new WeaponDef(MAGNUM,  "Magnum",          42, 0.50f,  6, 2.45f,  900f, 1.0f,  520f, true,  1, 10f,  5f, 2.8f, 0xFFFF9A5A, STYLE_BULLET, 0.92f, RELOAD_MAG,    0.66f, 0f,    0f,    0f,    0.20f),
        new WeaponDef(PLASMA,  "Plasma Rifle",   12, 0.09f, 40, 2.00f,  880f, 1.5f,  480f, true,  1, 14f,  5f, 3.4f, 0xFFB066FF, STYLE_ENERGY, 0.96f, RELOAD_MAG,    0.55f, 0f,    0f,    0f,    0f),
        new WeaponDef(LMG,     "Light MG",        12, 0.085f, 60, 3.30f, 640f, 5.0f,  480f, true,  1, 17f,  5f, 2.6f, 0xFFE8D36A, STYLE_BULLET, 0.86f, RELOAD_MAG,    0.62f, 0f,    0f,    0f,    0f),
        new WeaponDef(REVOLVER, "Revolver",       36, 0.45f,  6, 0f,     820f, 1.2f,  500f, true,  1, 10f,  4.5f, 2.6f, 0xFFD9D9E0, STYLE_BULLET, 0.96f, RELOAD_SHELLS, 0f,    0.45f, 0.36f, 0.30f, 0.18f),
        new WeaponDef(DOUBLE_BARREL, "Double Barrel", 11, 0.30f, 2, 0f,    500f, 9.0f,  250f, true, 10, 13f,  7f,   2.3f, 0xFFE0A070, STYLE_BULLET, 1.14f, RELOAD_SHELLS, 0f,    0.50f, 0.50f, 0.40f, 0.22f),
        new WeaponDef(HUNTING_RIFLE, "Hunting Rifle", 55, 0.80f, 5, 2.40f, 1300f, 0.3f, 1000f, true,  1, 20f,  3.2f, 2.2f, 0xFFD9B58A, STYLE_BULLET, 0.74f, RELOAD_MAG,    0.55f, 0f,    0f,    0f,    0.42f),
        new WeaponDef(AK,      "AK Rifle",        19, 0.105f, 30, 2.00f,  650f, 4.2f,  520f, true,  1, 15f,  4f,   2.6f, 0xFFE0824A, STYLE_BULLET, 0.90f, RELOAD_MAG,    0.58f, 0f,    0f,    0f,    0f),
        new WeaponDef(DMR,     "Marksman Rifle",  40, 0.42f, 10, 2.30f, 1200f, 0.7f,  900f, true,  1, 19f,  3.4f, 2.3f, 0xFFB8D8A0, STYLE_BULLET, 0.76f, RELOAD_MAG,    0.55f, 0f,    0f,    0f,    0f),
        new WeaponDef(MACHINE_PISTOL, "Machine Pistol", 7, 0.055f, 24, 1.35f, 560f, 7.5f, 280f, true,  1,  8f,  3.6f, 2.0f, 0xFF9FE8C0, STYLE_BULLET, 1.10f, RELOAD_MAG,    0.60f, 0f,    0f,    0f,    0f),
        //                       id       name            dmg  interval reach arc   hitDelay color        zoom  tool
        new WeaponDef(KNIFE,   "Knife",          24, 0.30f, 34f, 42f, 0.08f, 0xFFD0D6DE, 1.12f, TOOL_NONE),
        new WeaponDef(BAT,     "Baseball Bat",   34, 0.55f, 46f, 55f, 0.16f, 0xFFC89A60, 1.08f, TOOL_NONE),
        new WeaponDef(CROWBAR, "Crowbar",        38, 0.62f, 44f, 50f, 0.17f, 0xFF8A94A6, 1.08f, TOOL_NONE),
        new WeaponDef(MACHETE, "Machete",        46, 0.52f, 48f, 62f, 0.15f, 0xFFB8C4D4, 1.06f, TOOL_NONE),
        new WeaponDef(AXE,     "Fire Axe",       62, 0.85f, 50f, 58f, 0.26f, 0xFFE05A4A, 1.04f, TOOL_AXE),
        new WeaponDef(PICKAXE, "Pickaxe",        48, 0.80f, 50f, 50f, 0.24f, 0xFF9AA0A8, 1.04f, TOOL_PICK),
        new WeaponDef(FISTS,   "Fists",          8, 0.45f, 30f, 42f, 0.10f, 0xFFB0B8C4, 1.10f, TOOL_NONE),
    };

    /**
     * Seconds a reload takes when {@code ammoLeft} rounds are still in the gun: a magazine swap always
     * takes the same time, a shell reload only as long as the missing shells need.
     */
    public float reloadDuration(int ammoLeft) {
        if (reloadStyle == RELOAD_SHELLS) {
            int need = Math.max(1, magSize - Math.max(0, ammoLeft));
            return loadLead + need * loadPerRound + loadTail;
        }
        return reloadTime;
    }

    /** True for guns that reload round by round. */
    public boolean loadsRoundByRound() {
        return reloadStyle == RELOAD_SHELLS;
    }

    /** Bounds-safe lookup for ids that came off the network. */
    public static WeaponDef byId(int id) {
        return (id >= 0 && id < ALL.length) ? ALL[id] : ALL[PISTOL];
    }

    /** How far to the shooter's right the barrel axis sits (matches the soldier model). */
    public static final float MUZZLE_SIDE = 0.8f;

    /** Distance from the shooter's centre to the muzzle, along the aim. */
    public float muzzleReach() {
        return GameConfig.PLAYER_RADIUS + barrelLength;
    }

    /** World x of the muzzle of a shooter at (x, ·) aiming along {@code angle}. */
    public float muzzleX(float x, float angle) {
        return x + (float) Math.cos(angle) * muzzleReach() - (float) Math.sin(angle) * MUZZLE_SIDE;
    }

    /** World y of the muzzle of a shooter at (·, y) aiming along {@code angle}. */
    public float muzzleY(float y, float angle) {
        return y + (float) Math.sin(angle) * muzzleReach() + (float) Math.cos(angle) * MUZZLE_SIDE;
    }

    /**
     * Spawns this weapon's pellets into {@code pool}. Bullets leave from the muzzle, the tip of the
     * barrel the soldier is holding. When a wall stands between the body and the muzzle (the
     * shooter is pressed against it) they start at the wall face instead, so a bullet can never
     * appear on the far side of a wall. Host and clients call this with identical arguments and
     * therefore get identical bullets.
     *
     * @return number of bullets actually spawned
     */
    public int spawn(ProjectilePool pool, CollisionSystem col, int ownerId, float x, float y, float angle,
                     int seed, int baseId) {
        float mx = muzzleX(x, angle);
        float my = muzzleY(y, angle);
        float cut = col.raycast(x, y, mx, my);
        if (cut >= 0f) {
            float k = Math.max(0f, cut - 0.02f);
            mx = x + (mx - x) * k;
            my = y + (my - y) * k;
        }
        XorShift rng = pool.rng;
        rng.setSeed(seed);
        int spawned = 0;
        for (int i = 0; i < pellets; i++) {
            Projectile p = pool.acquire();
            if (p == null) break;
            float a = angle + rng.nextSigned() * spread;
            p.x = mx;
            p.y = my;
            p.px = mx;
            p.py = my;
            p.vx = (float) Math.cos(a) * projectileSpeed;
            p.vy = (float) Math.sin(a) * projectileSpeed;
            p.remaining = range;
            p.id = (baseId + i) & 0xFFFF;
            p.owner = ownerId;
            p.weaponId = id;
            p.damage = damage;
            p.radius = bulletRadius;
            spawned++;
        }
        return spawned;
    }
}
