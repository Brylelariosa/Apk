package com.hazardyard.game.core;

/**
 * The authoritative game rules, run only on the host: movement, shooting, projectiles, damage,
 * death, respawn, pickups and the match clock. It works on a {@link GameState} and reports what
 * happened through a {@link WorldListener}. Pure Java, no Android dependencies.
 */
public final class GameWorld {
    private final GameState st;
    private final WorldListener listener;
    private final CollisionSystem col;
    private final XorShift rng = new XorShift(0x5EED);
    private final float[] dir = new float[2];
    private int nextProjectileId = 1;
    /** Distance from every living opponent beyond which one spawn point is as good as another. */
    private static final float SPAWN_FAR_ENOUGH = 900f;

    public GameWorld(GameState st, WorldListener listener) {
        this.st = st;
        this.listener = listener;
        this.col = st.collision;
    }

    public GameState state() {
        return st;
    }

    // ------------------------------------------------------------------ roster

    public void addPlayer(int id, String name) {
        addPlayer(id, name, false);
    }

    /** Adds a human or, with {@code bot}, a computer-controlled player to slot {@code id}. */
    public void addPlayer(int id, String name, boolean bot) {
        Player p = st.players[id];
        p.connected = true;
        p.bot = bot;
        p.name = name;
        p.resetForMatch();
    }

    /** The survival rules, when this match is a survival match (see {@link #attachSurvival}). */
    private com.hazardyard.game.survival.SurvivalSim sim;

    /** Survival: creates the rules engine; must be called before the match starts. {@code out} receives what the others must hear and see. */
    public void attachSurvival(com.hazardyard.game.survival.SurvivalSim.Out out) {
        sim = new com.hazardyard.game.survival.SurvivalSim(st, st.survival, this, col, out);
        st.survival.sim = sim;
    }

    /** Survival: an inventory or crafting command from a survivor. */
    public void survivalCommand(int id, int cmd, int a, int b) {
        if (sim == null || id < 0 || id >= st.players.length || !st.players[id].connected) return;
        sim.command(st.players[id], cmd, a, b);
    }

    /** Survival: hurts a fighter without a bullet (a zombie's bite, hunger, a car). */
    public void hurt(int victimId, int amount, int attackerId, int causeId, float hx, float hy) {
        damage(victimId, attackerId, amount, causeId, 0xFF00 | (causeId & 0xFF), hx, hy);
    }

    public void removePlayer(int id) {
        Player p = st.players[id];
        if (!p.connected) return;
        if (sim != null) sim.playerLeft(p);
        if (st.mode.royale && st.phase == GameState.PHASE_PLAYING && p.alive) p.placement = Math.max(1, st.aliveCount());
        p.connected = false;
        p.bot = false;
        p.alive = false;
        p.weapon.cancelReload();
        p.moveX = 0f;
        p.moveY = 0f;
        p.firing = false;
        p.rollTimer = 0f;
        p.dodgeRequest = false;
        // A fighter who leaves a battle royale counts as eliminated: the match may have just become decided.
        if (st.mode.royale && st.phase == GameState.PHASE_PLAYING && st.aliveCount() <= 1) endMatch();
    }

    // ------------------------------------------------------------------ input (validated here)

    /**
     * Stores the latest controls of a player. Values are sanitised: a misbehaving client cannot
     * move faster than the speed limit or feed NaNs into the simulation.
     */
    public void setInput(int id, float moveX, float moveY, float aim, boolean firing, int seq) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (!p.connected) return;
        if (!MathUtil.isFinite(moveX) || !MathUtil.isFinite(moveY)) {
            moveX = 0f;
            moveY = 0f;
        }
        p.moveX = MathUtil.clamp(moveX, -1f, 1f);
        p.moveY = MathUtil.clamp(moveY, -1f, 1f);
        p.aimTarget = MathUtil.wrapAngle(aim);
        p.hasAimInput = true;
        if (firing && !p.firing) p.pulls++;
        p.firing = firing;
        p.lastInputSeq = seq & 0xFF;
    }

    public void requestReload(int id) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (p.connected) p.reloadRequest = true;
    }

    /**
     * Asks to take the weapon on pad {@code padIndex} (-1: the nearest one in reach). Nothing happens
     * unless the player really is close to an active pad; walking over a weapon never takes it.
     */
    public void requestPickup(int id, int padIndex) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (!p.connected) return;
        p.pickupRequest = true;
        p.pickupRequestIndex = padIndex;
    }

    /**
     * Asks for a dodge roll along the unit vector (dx, dy). A zero vector lets the host choose from
     * the player's latest input (moving: that way, standing still: the way they face). The request
     * is turned down in {@link #updatePlayer} when a roll is not allowed right now.
     */
    public void requestDodge(int id, float dx, float dy) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (!p.connected) return;
        if (!MathUtil.isFinite(dx) || !MathUtil.isFinite(dy)) {
            dx = 0f;
            dy = 0f;
        }
        p.dodgeRequest = true;
        p.dodgeReqX = dx;
        p.dodgeReqY = dy;
    }

    // ------------------------------------------------------------------ match flow

    public void startMatch() {
        st.projectiles.clear();
        st.effects.clear();
        for (int i = 0; i < st.pickups.length; i++) {
            st.pickups[i].active = true;
            st.pickups[i].timer = 0f;
        }
        st.timeLeft = st.mode.matchSeconds;
        st.countdown = GameConfig.COUNTDOWN_SECONDS;
        st.winnerId = -1;
        st.resultsTimer = 0f;
        if (st.mode.royale) st.zone.reset(st.map, rng.nextInt());
        else st.zone.disable();
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            p.resetForMatch();
            placeAtSpawn(p);
            p.alive = true;
            if (sim != null) sim.onSpawned(p);
        }
        setPhase(GameState.PHASE_COUNTDOWN);
    }

    private void setPhase(int phase) {
        st.phase = phase;
        listener.onPhaseChanged(phase);
    }

    private void endMatch() {
        if (st.phase != GameState.PHASE_PLAYING) return;
        if (st.mode.royale) {
            endRoyale();
            return;
        }
        int best = -1;
        boolean tie = false;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            if (best < 0) {
                best = i;
                tie = false;
                continue;
            }
            Player b = st.players[best];
            if (p.kills > b.kills || (p.kills == b.kills && p.deaths < b.deaths)) {
                best = i;
                tie = false;
            } else if (p.kills == b.kills && p.deaths == b.deaths) {
                tie = true;
            }
        }
        st.winnerId = tie ? -1 : best;
        st.resultsTimer = GameConfig.RESULTS_SECONDS;
        setPhase(GameState.PHASE_ENDED);
    }

    /**
     * Battle royale: the winner is the last fighter standing. If several are still alive when the clock runs out, the
     * one with the most health and armour left wins (then the most kills), and the rest are placed behind in that
     * order. When everybody went down together, whoever was the last to fall has place 1 already.
     */
    private void endRoyale() {
        int n = 0;
        int[] left = new int[st.players.length];
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.connected && p.alive) left[n++] = i;
        }
        // Sort the survivors, best first (insertion sort: there are at most eight).
        for (int a = 1; a < n; a++) {
            int v = left[a];
            int b = a - 1;
            while (b >= 0 && royaleBetter(st.players[v], st.players[left[b]])) {
                left[b + 1] = left[b];
                b--;
            }
            left[b + 1] = v;
        }
        for (int r = 0; r < n; r++) st.players[left[r]].placement = r + 1;
        int winner = -1;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.connected && p.placement == 1) winner = i;
        }
        st.winnerId = winner;
        st.resultsTimer = GameConfig.RESULTS_SECONDS;
        setPhase(GameState.PHASE_ENDED);
    }

    private static boolean royaleBetter(Player a, Player b) {
        int ha = a.health + a.armor;
        int hb = b.health + b.armor;
        return ha > hb || (ha == hb && a.kills > b.kills);
    }

    // ------------------------------------------------------------------ simulation step

    public void step(float dt) {
        switch (st.phase) {
            case GameState.PHASE_COUNTDOWN:
                st.countdown -= dt;
                if (st.countdown <= 0f) {
                    st.countdown = 0f;
                    setPhase(GameState.PHASE_PLAYING);
                }
                break;
            case GameState.PHASE_PLAYING:
                if (!st.mode.survival) st.timeLeft -= dt;
                if (st.timeLeft <= 0f && !st.mode.survival) {
                    st.timeLeft = 0f;
                    endMatch();
                }
                break;
            case GameState.PHASE_ENDED:
                st.resultsTimer -= dt;
                if (st.resultsTimer <= 0f) {
                    st.resultsTimer = 0f;
                    setPhase(GameState.PHASE_FINISHED);
                }
                break;
            default:
                break;
        }
        boolean live = st.phase == GameState.PHASE_PLAYING;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.connected) updatePlayer(p, dt, live);
        }
        if (live) separatePlayers();
        updateProjectiles(dt);
        if (live) updatePickups(dt);
        if (live && sim != null) sim.step(dt);
        if (live && st.zone.enabled) {
            st.zone.step(dt);
            applyStorm(dt);
        }
    }

    /** Fighters outside the safe zone lose health in whole points, as fast as the current storm tier says. */
    private void applyStorm(float dt) {
        Zone z = st.zone;
        for (int i = 0; i < st.players.length; i++) {
            if (st.phase != GameState.PHASE_PLAYING) return;
            Player p = st.players[i];
            if (!p.connected || !p.alive || z.inside(p.x, p.y)) continue;
            p.stormAcc += z.dps * dt;
            if (p.stormAcc < 1f) continue;
            int points = (int) p.stormAcc;
            p.stormAcc -= points;
            p.health -= points;
            p.hitFlash = 0.12f;
            if (p.health <= 0) kill(p, -1, GameConfig.CAUSE_ZONE);
        }
    }

    private void updatePlayer(Player p, float dt, boolean live) {
        if (p.hitFlash > 0f) p.hitFlash -= dt;
        if (p.muzzleFlash > 0f) p.muzzleFlash -= dt;
        if (!p.alive) {
            p.dodgeRequest = false;
            p.pickupRequest = false;
            p.reloadRequest = false;
            if (live && !st.mode.royale) {
                p.respawnTimer -= dt;
                if (p.respawnTimer <= 0f) respawn(p);
            }
            return;
        }
        if (p.spawnProtect > 0f) p.spawnProtect -= dt;
        Weapon w = p.weapon;
        int ammoBefore = w.ammo;
        w.update(dt);
        if (sim != null && w.ammo > ammoBefore) sim.onReloaded(p, w.ammo - ammoBefore);   // survival: the rounds come out of the pack
        if (!live) {
            p.dodgeRequest = false;
            p.pickupRequest = false;
            return;
        }

        if (p.hasAimInput) {
            p.aim = MathUtil.rotateToward(p.aim, p.aimTarget, GameConfig.PLAYER_TURN_RATE * dt);
        }
        Dodge.tickCooldown(p, dt);
        if (p.swingT < 1f) p.swingT = Math.min(1f, p.swingT + dt / Math.max(0.05f, p.swingDur));
        if (p.swingTimer > 0f) {
            p.swingTimer -= dt;
            if (p.swingTimer <= 0f) {
                p.swingTimer = 0f;
                resolveSwing(p);
                if (!p.alive) return;
            }
        }

        if (p.pickupRequest) {
            p.pickupRequest = false;
            if (!p.isRolling()) {
                if (sim != null) sim.interact(p);
                else takePickup(p);
            }
        }
        if (sim != null && sim.isDriving(p)) {
            p.dodgeRequest = false;
            p.reloadRequest = false;
            return;                 // the car carries the survivor (see SurvivalSim)
        }
        // A reload asked for during a roll waits until the roll is over.
        if (p.reloadRequest && !p.isRolling()) {
            p.reloadRequest = false;
            beginReload(p);
        }

        if (p.dodgeRequest) {
            p.dodgeRequest = false;
            if (Dodge.canStart(p, GameConfig.DODGE_GRACE)) {
                float dx = p.dodgeReqX;
                float dy = p.dodgeReqY;
                if (dx == 0f && dy == 0f) {
                    Dodge.pickDirection(p.moveX, p.moveY, p.aim, dir);
                    dx = dir[0];
                    dy = dir[1];
                }
                Dodge.start(p, dx, dy);
                p.swingTimer = 0f;     // a roll cuts a swing short too
                w.cancelReload();      // a roll interrupts a reload; nothing of it is kept
            }
        }
        if (p.isRolling()) {
            // A roll replaces walking and shooting; the trigger keeps its state and resumes afterwards.
            Dodge.step(p, col, dt);
            if (!p.isRolling() && w.ammo <= 0 && !w.reloading) beginReload(p);   // an empty gun is reloaded after the roll
            return;
        }

        float mx = p.moveX;
        float my = p.moveY;
        float len2 = mx * mx + my * my;
        if (len2 > 1f) {
            float inv = 1f / (float) Math.sqrt(len2);
            mx *= inv;
            my *= inv;
            len2 = 1f;
        }
        if (len2 > 0f) {
            float step = GameConfig.PLAYER_SPEED * dt;
            col.moveCircle(p.x, p.y, mx * step, my * step, GameConfig.PLAYER_RADIUS);
            p.x = col.resX;
            p.y = col.resY;
        }

        if (p.pulls != p.handledPulls) {
            p.handledPulls = p.pulls;
            p.pullBuffer = GameConfig.PULL_BUFFER;
        }
        boolean trigger = w.def.automatic ? p.firing : p.pullBuffer > 0f;
        if (p.pullBuffer > 0f) p.pullBuffer -= dt;
        // A fresh trigger pull cuts a reload short when the gun is usable (a round is in it). A trigger that
        // was already held when the reload began does not: otherwise holding fire would cancel every reload.
        if (w.reloading && p.pulls != p.reloadPullMark) {
            if (w.canInterruptReload()) w.cancelReload();
            p.reloadPullMark = p.pulls;
        }
        if (trigger && sim != null && sim.handlesTrigger(p)) {
            sim.useSelected(p);                 // survival: eat, build, plant, fish with the item in hand
        } else if (trigger) {
            if (w.canFire()) {
                if (w.def.melee) startSwing(p);
                else fire(p);
                if (!w.def.automatic) p.pullBuffer = 0f;
            } else if (w.ammo <= 0 && !w.reloading && !w.def.melee) {
                beginReload(p);
            }
        }
    }

    /** Starts a reload and remembers which trigger pull was the last one before it (see {@link Player#reloadPullMark}). */
    private void beginReload(Player p) {
        if (sim != null) {
            if (p.weapon.def.melee) return;
            int have = sim.ammoFor(p);
            if (have <= 0) {
                sim.toast(p, com.hazardyard.game.survival.SurvivalSim.T_NO_AMMO);
                return;
            }
            p.weapon.reserve = have;       // survival: no more rounds than the pack holds
        } else {
            p.weapon.reserve = Integer.MAX_VALUE;
        }
        if (p.weapon.startReload()) p.reloadPullMark = p.pulls;
    }

    /** The Pick Up button: takes the item on the pad in reach (a gun replaces the one in hand; a vest or kit is used at once). */
    private void takePickup(Player p) {
        if (st.phase != GameState.PHASE_PLAYING || !p.alive) return;
        float reach = GameConfig.PICKUP_REACH + GameConfig.PICKUP_REACH_SLACK;
        int idx = p.pickupRequestIndex;
        p.pickupRequestIndex = -1;
        if (idx >= 0 && idx < st.pickups.length) {
            Pickup c = st.pickups[idx];
            float dx = p.x - c.x;
            float dy = p.y - c.y;
            boolean ok = c.active && dx * dx + dy * dy <= reach * reach && Pickups.worthTaking(p, c)
                    && col.raycast(p.x, p.y, c.x, c.y) < 0f;
            if (!ok) idx = -1;
        } else {
            idx = -1;
        }
        if (idx < 0) idx = Pickups.nearest(st, p, reach);
        if (idx < 0) return;
        Pickup pk = st.pickups[idx];
        int item = pk.item;
        if (Items.isWeapon(item)) {
            p.weapon.equip(WeaponDef.byId(item));      // replaces the weapon in hand and cancels any reload
            p.reloadPullMark = p.pulls;
            p.pullBuffer = 0f;
        } else if (Items.isVest(item)) {
            p.armor = Math.min(GameConfig.ARMOR_MAX, Math.max(p.armor, Items.armorOf(item)));
        } else if (Items.isMedkit(item)) {
            p.health = Math.min(GameConfig.PLAYER_MAX_HEALTH, p.health + Items.MEDKIT_HEAL);
        }
        pk.active = false;
        pk.timer = st.mode.pickupRespawn;
        listener.onPickup(p, idx);
    }

    private void fire(Player p) {
        WeaponDef d = p.weapon.def;
        int seed = rng.nextInt() & 0xFFFF;
        int baseId = nextProjectileId;
        nextProjectileId = (nextProjectileId + d.pellets) & 0xFFFF;
        d.spawn(st.projectiles, col, p.id, p.x, p.y, p.aim, seed, baseId);
        p.weapon.onFired();
        if (p.weapon.ammo <= 0) beginReload(p);
        p.muzzleFlash = 0.06f;
        listener.onShot(p, d, p.x, p.y, p.aim, seed, baseId);
        if (sim != null) sim.noise(p.x, p.y, d.range * 1.6f + 350f);
    }

    private void updateProjectiles(float dt) {
        ProjectilePool pool = st.projectiles;
        for (int i = pool.activeCount - 1; i >= 0; i--) {
            Projectile b = pool.items[pool.activeList[i]];
            int status = col.advance(b, dt);
            int victim = -1;
            float bestT = 2f;
            for (int j = 0; j < st.players.length; j++) {
                Player q = st.players[j];
                if (!q.connected || !q.alive || q.id == b.owner || Dodge.invulnerable(q)) continue;
                float t = CollisionSystem.segmentCircle(b.px, b.py, b.x, b.y, q.x, q.y,
                        GameConfig.PLAYER_RADIUS + b.radius);
                if (t >= 0f && t < bestT) {
                    bestT = t;
                    victim = j;
                }
            }
            if (victim < 0 && sim != null && sim.projectileHitsZombie(b)) {
                pool.release(b);
                continue;
            }
            if (victim >= 0) {
                float hx = b.px + (b.x - b.px) * bestT;
                float hy = b.py + (b.y - b.py) * bestT;
                hitPlayer(b, victim, hx, hy);
                pool.release(b);
            } else if (status == CollisionSystem.HIT_WALL) {
                listener.onWallImpact(b.x, b.y, b.weaponId);
                pool.release(b);
            } else if (status == CollisionSystem.EXPIRED) {
                pool.release(b);
            }
        }
    }

    private void hitPlayer(Projectile b, int victimId, float hx, float hy) {
        damage(victimId, b.owner, b.damage, b.weaponId, b.id, hx, hy);
    }

    /**
     * Hurts a fighter: a vest takes its share first, the rest comes off the health. {@code projectileId} is the id the
     * clients know the bullet by; a melee blow sends {@code 0xFF00 | weaponId} instead.
     */
    private void damage(int victimId, int attackerId, int amount, int weaponId, int projectileId, float hx, float hy) {
        Player v = st.players[victimId];
        int dmg = (v.spawnProtect > 0f || st.phase != GameState.PHASE_PLAYING) ? 0 : amount;
        listener.onProjectileHit(projectileId, victimId, hx, hy, dmg, weaponId);
        if (dmg <= 0) return;
        // A vest takes its share of the bullet first; the rest hurts. A spent vest is simply gone.
        int absorbed = 0;
        if (v.armor > 0) {
            absorbed = Math.min(v.armor, Math.round(dmg * GameConfig.ARMOR_ABSORB));
            v.armor -= absorbed;
        }
        v.health -= dmg - absorbed;
        v.hitFlash = 0.15f;
        if (v.health <= 0) kill(v, attackerId, weaponId);
    }

    // ------------------------------------------------------------------ melee

    /** A melee swing begins: the blow lands {@link WeaponDef#hitDelay} seconds from now. */
    private void startSwing(Player p) {
        WeaponDef d = p.weapon.def;
        p.weapon.cooldown += d.fireInterval;
        p.swingTimer = d.hitDelay;
        p.swingWeapon = d.id;
        p.swingT = 0f;
        p.swingDur = Math.max(0.22f, d.fireInterval * 0.8f);
        listener.onShot(p, d, p.x, p.y, p.aim, 0, 0);
    }

    /** The blow lands: everything in the arc in front of the fighter (up to three targets) is hit. */
    private void resolveSwing(Player p) {
        WeaponDef d = WeaponDef.byId(p.swingWeapon);
        if (!d.melee || !p.alive) return;
        int hits = 0;
        for (int j = 0; j < st.players.length && hits < 3; j++) {
            Player q = st.players[j];
            if (q == p || !q.connected || !q.alive || Dodge.invulnerable(q)) continue;
            float dx = q.x - p.x;
            float dy = q.y - p.y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist > d.reach + GameConfig.PLAYER_RADIUS) continue;
            if (dist > GameConfig.PLAYER_RADIUS * 1.2f) {
                float diff = Math.abs(MathUtil.angleDiff((float) Math.atan2(dy, dx), p.aim));
                float slack = (float) Math.atan2(GameConfig.PLAYER_RADIUS, Math.max(1f, dist));
                if (diff > d.arc + slack) continue;
            }
            if (dist > 1f && col.raycast(p.x, p.y, q.x, q.y) >= 0f) continue;      // a wall in between
            hits++;
            float inv = dist > 1f ? 1f / dist : 0f;
            damage(j, p.id, d.damage, d.id, 0xFF00 | d.id, q.x - dx * inv * GameConfig.PLAYER_RADIUS, q.y - dy * inv * GameConfig.PLAYER_RADIUS);
        }
        if (sim != null) sim.meleeSwing(p, d);
    }

    private void kill(Player v, int killerId, int weaponId) {
        int aliveBefore = st.aliveCount();      // v still counts: it is the Nth-to-last fighter to be out
        v.health = 0;
        v.armor = 0;
        v.alive = false;
        v.rollTimer = 0f;
        v.swingTimer = 0f;
        if (sim != null) sim.playerDied(v);
        v.deaths++;
        v.weapon.cancelReload();
        v.respawnTimer = st.mode.royale ? 0f : st.mode.respawnDelay;
        if (st.mode.royale) v.placement = Math.max(1, aliveBefore);
        Player k = (killerId >= 0 && killerId < st.players.length) ? st.players[killerId] : null;
        boolean credit = k != null && k != v && k.connected;
        if (credit) k.kills++;
        listener.onKill(killerId, v.id, weaponId);
        if (credit && st.mode.killLimit > 0 && k.kills >= st.mode.killLimit) endMatch();
        else if (st.mode.royale && st.aliveCount() <= 1) endMatch();
    }

    private void respawn(Player p) {
        placeAtSpawn(p);
        p.alive = true;
        p.health = GameConfig.PLAYER_MAX_HEALTH;
        p.weapon.equip(WeaponDef.ALL[WeaponDef.PISTOL]);
        p.spawnProtect = GameConfig.SPAWN_PROTECTION;
        p.rollTimer = 0f;
        p.dodgeCooldown = 0f;
        p.handledPulls = p.pulls;
        p.reloadPullMark = p.pulls;
        p.pullBuffer = 0f;
        p.reloadRequest = false;
        p.pickupRequest = false;
        if (sim != null) sim.onSpawned(p);
        listener.onRespawn(p);
    }

    /** Picks the spawn point farthest from every living opponent (with a little randomness). */
    private void placeAtSpawn(Player p) {
        if (sim != null) {
            sim.placeAtSpawn(p);
            return;
        }
        TileMap m = st.map;
        int best = 0;
        float bestScore = -1f;
        for (int i = 0; i < m.spawnX.length; i++) {
            float minD2 = Float.MAX_VALUE;
            for (int j = 0; j < st.players.length; j++) {
                Player q = st.players[j];
                if (q == p || !q.connected || !q.alive) continue;
                float dx = q.x - m.spawnX[i];
                float dy = q.y - m.spawnY[i];
                float d2 = dx * dx + dy * dy;
                if (d2 < minD2) minD2 = d2;
            }
            float dist = minD2 == Float.MAX_VALUE ? 1000f : (float) Math.sqrt(minD2);
            // On a huge map every spawn far enough from the fighting is as good as the farthest one.
            float cap = st.mode.royale ? 3600f : SPAWN_FAR_ENOUGH;
            if (dist > cap) dist = cap;
            float score = dist + rng.nextFloat() * (st.mode.royale ? 160f : 40f);
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        p.x = m.spawnX[best];
        p.y = m.spawnY[best];
        p.aim = (float) Math.atan2(m.worldH * 0.5f - p.y, m.worldW * 0.5f - p.x);
        p.aimTarget = p.aim;
        p.hasAimInput = false;
        p.rx = p.x;
        p.ry = p.y;
        p.rAim = p.aim;
    }

    /** Pushes overlapping players apart so they cannot walk through each other. */
    private void separatePlayers() {
        float minDist = 2f * GameConfig.PLAYER_RADIUS;
        for (int i = 0; i < st.players.length; i++) {
            Player a = st.players[i];
            if (!a.connected || !a.alive) continue;
            for (int j = i + 1; j < st.players.length; j++) {
                Player b = st.players[j];
                if (!b.connected || !b.alive) continue;
                float dx = b.x - a.x;
                float dy = b.y - a.y;
                float d2 = dx * dx + dy * dy;
                if (d2 >= minDist * minDist) continue;
                float d = (float) Math.sqrt(d2);
                float nx = 1f;
                float ny = 0f;
                if (d > 1e-4f) {
                    nx = dx / d;
                    ny = dy / d;
                }
                float push = (minDist - d) * 0.5f;
                a.x -= nx * push;
                a.y -= ny * push;
                b.x += nx * push;
                b.y += ny * push;
                col.pushOut(a.x, a.y, GameConfig.PLAYER_RADIUS);
                a.x = col.resX;
                a.y = col.resY;
                col.pushOut(b.x, b.y, GameConfig.PLAYER_RADIUS);
                b.x = col.resX;
                b.y = col.resY;
            }
        }
    }

    /** Items are only taken by {@link #takePickup}; here they just come back after their respawn time (never, on Battleground). */
    private void updatePickups(float dt) {
        if (st.mode.pickupRespawn < 0f) return;
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (pk.active) continue;
            pk.timer -= dt;
            if (pk.timer <= 0f) pk.active = true;
        }
    }
}
