package com.hazardyard.game.render;

import android.graphics.Bitmap;

import com.hazardyard.game.core.TileMap;

/** Paints the minimap picture of an outdoor map: ground colours, water, buildings, trees, one pixel per sampled tile. */
public final class MiniTerrain {
    private MiniTerrain() {}

    private static final int[] GROUND = new int[TileMap.G_COUNT];

    static {
        GROUND[TileMap.G_GRASS] = 0xFF5C9A3E;
        GROUND[TileMap.G_MEADOW] = 0xFF86B552;
        GROUND[TileMap.G_FOREST] = 0xFF3F7A33;
        GROUND[TileMap.G_DIRT] = 0xFF9A7A4C;
        GROUND[TileMap.G_SAND] = 0xFFD8C88C;
        GROUND[TileMap.G_ROAD] = 0xFF4C525C;
        GROUND[TileMap.G_ROAD_H] = 0xFF5A6070;
        GROUND[TileMap.G_ROAD_V] = 0xFF5A6070;
        GROUND[TileMap.G_PAVED] = 0xFF9EA4AC;
        GROUND[TileMap.G_FIELD] = 0xFFB08F45;
        GROUND[TileMap.G_BRIDGE] = 0xFF9A6A3A;
        GROUND[TileMap.G_ROCKY] = 0xFF8A8C84;
        GROUND[TileMap.G_WOOD] = 0xFFC8A878;
        GROUND[TileMap.G_TILES] = 0xFFD2D6DC;
        GROUND[TileMap.G_CONCRETE] = 0xFF7C828C;
        GROUND[TileMap.G_WATER] = 0xFF2B6AA8;
        GROUND[TileMap.G_TILLED] = 0xFF6B4A2C;
    }

    public static void paint(Bitmap bmp, TileMap map) {
        int bw = bmp.getWidth();
        int bh = bmp.getHeight();
        int[] px = new int[bw * bh];
        for (int y = 0; y < bh; y++) {
            int ty = Math.min(map.height - 1, y * map.height / bh);
            for (int x = 0; x < bw; x++) {
                int tx = Math.min(map.width - 1, x * map.width / bw);
                int c = GROUND[map.groundAt(tx, ty)];
                switch (map.kindAt(tx, ty)) {
                    case TileMap.WATER: c = 0xFF2B6AA8; break;
                    case TileMap.WALL: c = 0xFF39404C; break;
                    case TileMap.TREE: c = 0xFF2C6A32; break;
                    case TileMap.ROCK: c = 0xFF70757D; break;
                    case TileMap.CRATE: c = 0xFF8A5A2A; break;
                    case TileMap.FENCE: c = 0xFFC8B070; break;
                    case TileMap.PILLAR:
                    case TileMap.TANK: c = 0xFF8E96A4; break;
                    default:
                        if (map.houseAt(tx, ty) >= 0) c = 0xFFD2B38A;      // a floor inside a building
                        break;
                }
                px[y * bw + x] = c;
            }
        }
        bmp.setPixels(px, 0, bw, 0, 0, bw, bh);
    }
}
