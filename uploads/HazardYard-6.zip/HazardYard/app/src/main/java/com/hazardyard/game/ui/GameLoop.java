package com.hazardyard.game.ui;

import android.graphics.Canvas;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Process;
import android.util.Log;
import android.view.Choreographer;
import android.view.SurfaceHolder;

import com.hazardyard.game.core.Camera;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.core.Pickups;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.engine.GameEngine;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.render.HudRenderer;
import com.hazardyard.game.render.QualityGovernor;
import com.hazardyard.game.render.Renderer;
import com.hazardyard.game.settings.GameSettings;

/**
 * The one game thread. It is driven by the display's own vsync (through {@link Choreographer}), so
 * frames reach the screen at an even rhythm on 60, 90 and 120 Hz phones alike: the old timer-based
 * loop drifted against the screen's refresh, which looks like judder, most visibly on high-refresh
 * displays. Each frame runs the fixed-timestep simulation as many times as the elapsed time asks for
 * and then draws everything between its last two simulated states ({@code alpha}), so motion stays
 * smooth even when a frame holds no simulation step at all.
 *
 * <p>At most about 90 frames a second are drawn (a 120 Hz screen gets every second vsync), and a
 * {@link QualityGovernor} lowers the graphics when the phone cannot keep up. Input, rendering and
 * simulation run in strict sequence on this thread, so game state needs no locking; only the touch
 * input crosses threads and it does so through {@link InputController}'s own lock.
 */
final class GameLoop implements Choreographer.FrameCallback {
    interface Callback {
        /** The engine reports that the session is over. Called once, on the game thread. */
        void onEngineFinished(String reason);
    }

    /** Never render more often than this (about 90 fps); the slack lets a vsync that is a hair early still count. */
    private static final long MIN_FRAME_NANOS = 11_100_000L;
    private static final long SLACK_NANOS = 1_500_000L;
    private static final float FIRST_FRAME = 1f / 60f;

    private final SurfaceHolder holder;
    private final GameEngine engine;
    private final InputController input;
    private final Callback callback;
    private final GameSettings settings;
    private final float density;
    private final Renderer renderer;
    private final HudRenderer hud = new HudRenderer();
    private final Camera camera = new Camera();
    private final LocalInput local = new LocalInput();
    private final QualityGovernor governor;

    private volatile boolean running;
    private volatile int width;
    private volatile int height;
    private HandlerThread thread;
    private Handler handler;
    private Choreographer choreographer;

    // frame state (game thread only)
    private GameState st;
    private int appliedW = -1;
    private int appliedH = -1;
    private boolean cameraPlaced;
    private boolean zoomPlaced;
    private boolean aimPlaced;
    /** 0..1, how visible the aim line is (it fades in while aiming and out afterwards). */
    private float aimLineStrength;
    private boolean notified;
    private int errors;
    private float accumulator;
    private float time;
    private long lastRenderNanos;
    private long lastCallbackNanos;
    private float vsyncSeconds = FIRST_FRAME;

    GameLoop(SurfaceHolder holder, GameEngine engine, InputController input, GameSettings settings, float density,
             Callback callback) {
        this.holder = holder;
        this.engine = engine;
        this.input = input;
        this.settings = settings;
        this.density = density;
        this.callback = callback;
        this.renderer = new Renderer(settings);
        int mode = settings.quality;
        boolean adaptive = mode == GameSettings.QUALITY_AUTO;
        // Every match starts at full quality: a slow patch in an earlier match must not leave the next one stuck
        // with flat soldiers. (The explicit Light setting is the player's own choice and does flatten them.)
        int start = mode == GameSettings.QUALITY_LIGHT ? QualityGovernor.LIGHT : QualityGovernor.FULL;
        this.governor = new QualityGovernor(adaptive, start);
        this.renderer.setQuality(governor.level());
        this.renderer.setFlatModels(mode == GameSettings.QUALITY_LIGHT);
        settings.autoLevel = 0;
    }

    void setSize(int w, int h) {
        width = w;
        height = h;
    }

    void start() {
        running = true;
        st = engine.state();
        HandlerThread t = new HandlerThread("hy-game", Process.THREAD_PRIORITY_DISPLAY);
        t.start();
        thread = t;
        handler = new Handler(t.getLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                choreographer = Choreographer.getInstance();   // the instance of the game thread
                choreographer.postFrameCallback(GameLoop.this);
            }
        });
    }

    /** Stops the loop and waits until it has really stopped (the surface may be destroyed afterwards). */
    void stop() {
        running = false;
        final HandlerThread t = thread;
        final Handler h = handler;
        thread = null;
        handler = null;
        if (t == null) return;
        if (h != null) {
            h.post(new Runnable() {
                @Override
                public void run() {
                    if (choreographer != null) choreographer.removeFrameCallback(GameLoop.this);
                }
            });
        }
        t.quitSafely();
        if (t != Thread.currentThread()) {
            try {
                t.join(1500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    @Override
    public void doFrame(long frameTimeNanos) {
        if (!running) return;
        // Learn the length of a vsync from the callbacks themselves (the shortest gap seen).
        if (lastCallbackNanos != 0L) {
            float gap = (frameTimeNanos - lastCallbackNanos) * 1e-9f;
            if (gap > 0.002f && gap < 0.04f) {
                vsyncSeconds = vsyncSeconds > gap ? gap : vsyncSeconds + (gap - vsyncSeconds) * 0.002f;
            }
        }
        lastCallbackNanos = frameTimeNanos;

        boolean skip = lastRenderNanos != 0L && frameTimeNanos - lastRenderNanos < MIN_FRAME_NANOS - SLACK_NANOS;
        if (!skip) {
            try {
                renderFrame(frameTimeNanos);
                errors = 0;
            } catch (RuntimeException e) {
                // One bad frame is survivable; a persistent failure ends the session cleanly.
                Log.e("HazardYard", "Frame failed", e);
                if (++errors > 30 && !notified) {
                    notified = true;
                    callback.onEngineFinished("The match stopped because of an internal error.");
                }
            }
        }
        if (running) choreographer.postFrameCallback(this);
    }

    private void renderFrame(long frameTimeNanos) {
        float frame = lastRenderNanos == 0L ? FIRST_FRAME : (frameTimeNanos - lastRenderNanos) * 1e-9f;
        float realFrame = frame;
        frame = Math.min(frame, 0.1f);
        lastRenderNanos = frameTimeNanos;

        int w = width;
        int h = height;
        if (w != appliedW || h != appliedH) {
            appliedW = w;
            appliedH = h;
            camera.setViewport(w, h, st.survival != null ? 1e9f : st.map.worldW, st.survival != null ? 1e9f : st.map.worldH);
        }

        Player me = st.local();
        if (!aimPlaced && me.connected && me.alive) {
            local.aim = me.aim;
            aimPlaced = true;
        }

        // The weapon within reach (if any): the Pick Up button exists for touches and is drawn only while this is set.
        input.survivalUi.active = st.survival != null;
        if (st.survival != null) input.setPickupOffered(interaction.find(st.survival, me) ? 0 : -1);
        else input.setPickupOffered(Pickups.offered(st, me));

        accumulator += frame;
        int steps = 0;
        while (accumulator >= GameConfig.SIM_DT && steps < GameConfig.MAX_STEPS_PER_FRAME) {
            input.sample(local);
            engine.fixedUpdate(GameConfig.SIM_DT, local);
            accumulator -= GameConfig.SIM_DT;
            steps++;
        }
        if (steps == GameConfig.MAX_STEPS_PER_FRAME) accumulator = 0f;
        engine.frameUpdate(frame, accumulator / GameConfig.SIM_DT);
        st.audio.update(frame);
        time += frame;

        // Battle royale: once the local fighter is out, the camera moves on to somebody who is still in the match.
        updateViewTarget(st);
        Player view = st.view();

        // Every gun has its own view: the camera eases to the zoom of the equipped gun.
        float zoomGoal = view.connected ? view.weapon.def.zoom : 1f;
        if (st.survival != null && st.survival.drivingCar[st.viewId] >= 0) zoomGoal = 0.78f;      // a wider view at driving speed
        if (!zoomPlaced) {
            camera.snapZoom(zoomGoal);
            zoomPlaced = true;
        } else {
            camera.setZoomTarget(zoomGoal);
            camera.updateZoom(frame);
        }

        if (view.connected) {
            if (!cameraPlaced) {
                camera.snapTo(view.rx, view.ry);
                cameraPlaced = true;
            } else {
                camera.follow(view.rx, view.ry, frame);
            }
        } else if (!cameraPlaced) {
            camera.snapTo(st.map.worldW * 0.5f, st.map.worldH * 0.5f);
        }

        // The aim line shows while the player aims (or shoots) and fades in and out around it.
        boolean lineWanted = settings.aimLine && me.connected && me.alive
                && st.phase == GameState.PHASE_PLAYING && (input.isAiming() || local.firing);
        float lineStep = frame * (lineWanted ? 14f : 8f);
        aimLineStrength = lineWanted ? Math.min(1f, aimLineStrength + lineStep) : Math.max(0f, aimLineStrength - lineStep);
        boolean shooting = local.firing && !me.weapon.reloading && me.weapon.ammo > 0;
        renderer.setAimLine(aimLineStrength, shooting);

        draw(st, time);

        if (!notified && engine.isFinished()) {
            notified = true;
            callback.onEngineFinished(engine.finishReason());
        }

        if (governor.onFrame(realFrame, vsyncSeconds)) {
            renderer.setQuality(governor.level());
        }
    }

    private void draw(GameState st, float time) {
        if (!holder.getSurface().isValid()) return;
        Canvas canvas = null;
        try {
            canvas = holder.lockHardwareCanvas();
        } catch (IllegalStateException | IllegalArgumentException e) {
            return;
        }
        if (canvas == null) return;
        try {
            renderer.draw(canvas, st, camera, time);
            hud.draw(canvas, st, camera, input, engine.pingMs(), density, time);
        } finally {
            try {
                holder.unlockCanvasAndPost(canvas);
            } catch (IllegalStateException | IllegalArgumentException e) {
                // the surface went away while drawing; the next surfaceChanged restarts us
            }
        }
    }

    /**
     * After an elimination in a battle royale the camera (and what the player hears) follows a fighter who is still alive:
     * the one it is on while they stay in the match, otherwise the one nearest to where the camera is.
     */
    private final com.hazardyard.game.survival.Interaction interaction = new com.hazardyard.game.survival.Interaction();

    private void updateViewTarget(GameState st) {
        Player me = st.local();
        if (!st.mode.royale || st.phase != GameState.PHASE_PLAYING || !me.connected || me.alive) {
            st.viewId = st.localId;
            return;
        }
        Player cur = st.players[st.viewId];
        if (st.viewId != st.localId && cur.connected && cur.alive) return;
        int best = -1;
        float bestD = Float.MAX_VALUE;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (i == st.localId || !p.connected || !p.alive) continue;
            float dx = p.rx - camera.x;
            float dy = p.ry - camera.y;
            float d = dx * dx + dy * dy;
            if (d < bestD) {
                bestD = d;
                best = i;
            }
        }
        st.viewId = best >= 0 ? best : st.localId;
    }
}
