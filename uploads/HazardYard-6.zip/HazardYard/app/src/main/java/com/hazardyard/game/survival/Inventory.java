package com.hazardyard.game.survival;

import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.WeaponDef;

/**
 * What a survivor carries: {@link #SLOTS} stacks, the first {@link #HOTBAR} of them on the hotbar. A gun is a stack of
 * one that also remembers how many rounds are in it. The host owns the real inventory and sends each player their own.
 */
public final class Inventory {
    public static final int SLOTS = 24;
    public static final int HOTBAR = 6;

    public final int[] item = new int[SLOTS];
    public final int[] count = new int[SLOTS];
    /** For a gun: rounds in the magazine. */
    public final int[] ammo = new int[SLOTS];
    public int selected;
    /** The host changed something since it last sent the inventory. */
    public boolean dirty;

    public Inventory() {
        clear();
    }

    public void clear() {
        for (int i = 0; i < SLOTS; i++) {
            item[i] = -1;
            count[i] = 0;
            ammo[i] = 0;
        }
        selected = 0;
        dirty = true;
    }

    public boolean isEmpty(int slot) {
        return item[slot] < 0 || count[slot] <= 0;
    }

    public int countOf(int it) {
        int n = 0;
        for (int i = 0; i < SLOTS; i++) if (item[i] == it) n += count[i];
        return n;
    }

    public boolean has(int it, int n) {
        return countOf(it) >= n;
    }

    /** Takes {@code n} of an item out of the stacks (last stacks first); false (and nothing taken) if there is not enough. */
    public boolean remove(int it, int n) {
        if (!has(it, n)) return false;
        for (int i = SLOTS - 1; i >= 0 && n > 0; i--) {
            if (item[i] != it) continue;
            int take = Math.min(n, count[i]);
            count[i] -= take;
            n -= take;
            if (count[i] <= 0) {
                item[i] = -1;
                count[i] = 0;
                ammo[i] = 0;
            }
        }
        dirty = true;
        return true;
    }

    /** Puts items away: first onto stacks of the same item, then into empty slots. Returns how many did not fit. */
    public int add(int it, int n) {
        if (it < 0 || n <= 0) return 0;
        int max = Items.stackMax(it);
        for (int i = 0; i < SLOTS && n > 0; i++) {
            if (item[i] == it && count[i] < max) {
                int put = Math.min(n, max - count[i]);
                count[i] += put;
                n -= put;
                dirty = true;
            }
        }
        for (int i = 0; i < SLOTS && n > 0; i++) {
            if (item[i] < 0 || count[i] <= 0) {
                int put = Math.min(n, max);
                item[i] = it;
                count[i] = put;
                ammo[i] = Items.isWeapon(it) && !WeaponDef.byId(it).melee ? WeaponDef.byId(it).magSize : 0;
                n -= put;
                dirty = true;
            }
        }
        return n;
    }

    public int selectedItem() {
        return isEmpty(selected) ? -1 : item[selected];
    }

    public void swap(int a, int b) {
        if (a < 0 || b < 0 || a >= SLOTS || b >= SLOTS || a == b) return;
        int ti = item[a], tc = count[a], ta = ammo[a];
        item[a] = item[b];
        count[a] = count[b];
        ammo[a] = ammo[b];
        item[b] = ti;
        count[b] = tc;
        ammo[b] = ta;
        dirty = true;
    }

    /** Takes a whole slot out and returns its item (count and ammo are read before calling), or -1. */
    public void clearSlot(int slot) {
        item[slot] = -1;
        count[slot] = 0;
        ammo[slot] = 0;
        dirty = true;
    }

    public int freeSlots() {
        int n = 0;
        for (int i = 0; i < SLOTS; i++) if (isEmpty(i)) n++;
        return n;
    }
}
