package com.hazardyard.game.survival;

import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.core.XorShift;

/**
 * What a piece of furniture holds when it is searched: one to three rolls on a table that depends on the furniture and on
 * the kind of building it stands in (a police station's lockers hold ammunition and armour, a garage's toolbox car parts,
 * a clinic's cupboards bandages and first-aid kits). Every roll can also come up empty.
 */
public final class LootTable {
    private LootTable() {}

    /** item, min, max, weight */
    private static final int[][] FOOD = {
            {Items.CANNED, 1, 3, 22}, {Items.BREAD, 1, 2, 10}, {Items.APPLE, 1, 2, 8}, {Items.CARROT, 1, 2, 4},
            {Items.POTATO, 1, 2, 4}, {Items.SEED_CARROT, 1, 3, 4}, {Items.SEED_POTATO, 1, 3, 3}, {Items.BANDAGE, 1, 2, 7},
            {Items.CLOTH, 1, 2, 8}, {Items.NAILS, 3, 8, 6}, {-1, 0, 0, 14}};
    private static final int[][] WARDROBE = {
            {Items.CLOTH, 1, 3, 40}, {Items.VEST_LIGHT, 1, 1, 5}, {Items.BANDAGE, 1, 2, 10}, {WeaponDef.KNIFE, 1, 1, 3}, {-1, 0, 0, 22}};
    private static final int[][] TOOLBOX = {
            {Items.NAILS, 4, 12, 24}, {Items.SCRAP, 2, 6, 24}, {Items.WRENCH, 1, 1, 8}, {Items.HOE, 1, 1, 3},
            {WeaponDef.AXE, 1, 1, 4}, {WeaponDef.PICKAXE, 1, 1, 3}, {Items.GAS_CAN, 1, 1, 8}, {Items.BATTERY, 1, 1, 5},
            {Items.TIRE, 1, 1, 5}, {Items.ENGINE, 1, 1, 4}, {WeaponDef.CROWBAR, 1, 1, 5}, {WeaponDef.BAT, 1, 1, 4}, {-1, 0, 0, 10}};
    private static final int[][] SHELF = {
            {Items.CANNED, 1, 4, 24}, {Items.BREAD, 1, 3, 10}, {Items.APPLE, 1, 3, 8}, {Items.CLOTH, 1, 2, 6},
            {Items.BANDAGE, 1, 3, 8}, {Items.SCRAP, 1, 3, 5}, {Items.SEED_CARROT, 1, 3, 5}, {Items.SEED_POTATO, 1, 3, 5},
            {Items.AMMO_BULLETS, 4, 12, 6}, {Items.ROD, 1, 1, 3}, {-1, 0, 0, 18}};
    private static final int[][] CRATE = {
            {Items.SCRAP, 2, 5, 24}, {Items.NAILS, 3, 9, 10}, {Items.WOOD, 2, 4, 10}, {Items.CANNED, 1, 2, 10},
            {Items.AMMO_BULLETS, 5, 14, 8}, {Items.AMMO_SHELLS, 3, 8, 5}, {Items.AMMO_RIFLE, 4, 10, 4}, {Items.TIRE, 1, 1, 3},
            {Items.GAS_CAN, 1, 1, 3}, {Items.BATTERY, 1, 1, 2}, {-1, 0, 0, 18}};
    private static final int[][] GUNCASE = {
            {Items.AMMO_BULLETS, 8, 20, 14}, {Items.AMMO_RIFLE, 6, 16, 10}, {Items.AMMO_SHELLS, 4, 10, 8},
            {WeaponDef.REVOLVER, 1, 1, 7}, {WeaponDef.MACHINE_PISTOL, 1, 1, 5}, {WeaponDef.SMG, 1, 1, 5}, {WeaponDef.SHOTGUN, 1, 1, 5},
            {WeaponDef.DOUBLE_BARREL, 1, 1, 5}, {WeaponDef.AK, 1, 1, 4}, {WeaponDef.RIFLE, 1, 1, 4}, {WeaponDef.HUNTING_RIFLE, 1, 1, 3},
            {WeaponDef.DMR, 1, 1, 2}, {WeaponDef.MAGNUM, 1, 1, 3}, {WeaponDef.PISTOL, 1, 1, 6}, {Items.VEST_HEAVY, 1, 1, 4},
            {Items.VEST_LIGHT, 1, 1, 4}, {Items.MEDKIT, 1, 1, 4}, {-1, 0, 0, 8}};
    private static final int[][] LOCKER = {
            {Items.VEST_LIGHT, 1, 1, 10}, {Items.AMMO_BULLETS, 6, 14, 14}, {Items.AMMO_SHELLS, 3, 8, 6}, {WeaponDef.CROWBAR, 1, 1, 8},
            {WeaponDef.BAT, 1, 1, 6}, {Items.BANDAGE, 1, 3, 10}, {Items.CANNED, 1, 2, 8}, {Items.CLOTH, 1, 2, 6}, {-1, 0, 0, 20}};
    private static final int[][] MEDICINE = {
            {Items.BANDAGE, 1, 4, 34}, {Items.MEDKIT, 1, 1, 14}, {Items.CLOTH, 1, 3, 10}, {-1, 0, 0, 14}};

    private static int[][] tableFor(byte container, int building) {
        switch (container) {
            case Obj.GUNCASE:
                return GUNCASE;
            case Obj.TOOLBOX:
                return TOOLBOX;
            case Obj.WARDROBE:
                return WARDROBE;
            case Obj.CRATE:
                return CRATE;
            case Obj.FRIDGE:
                return FOOD;
            case Obj.SHELF:
                if (building == SurvivalGen.CLINIC) return MEDICINE;
                if (building == SurvivalGen.GARAGE) return TOOLBOX;
                if (building == SurvivalGen.POLICE) return LOCKER;
                return SHELF;
            case Obj.CUPBOARD:
                if (building == SurvivalGen.CLINIC) return MEDICINE;
                if (building == SurvivalGen.POLICE) return LOCKER;
                return FOOD;
            default:
                return FOOD;
        }
    }

    /**
     * Rolls the contents of a container into {@code items} / {@code counts}; returns how many entries were filled (0 when it
     * is empty). The arrays need room for 3.
     */
    public static int roll(byte container, int building, XorShift rng, int[] items, int[] counts) {
        int[][] table = tableFor(container, building);
        int total = 0;
        for (int[] row : table) total += row[3];
        int rolls = 1 + (rng.nextInt(10) < 4 ? 0 : (rng.nextInt(10) < 7 ? 1 : 2));
        int n = 0;
        for (int r = 0; r < rolls; r++) {
            int pick = rng.nextInt(total);
            for (int[] row : table) {
                pick -= row[3];
                if (pick < 0) {
                    if (row[0] >= 0) {
                        int c = row[1] + (row[2] > row[1] ? rng.nextInt(row[2] - row[1] + 1) : 0);
                        items[n] = row[0];
                        counts[n] = c;
                        n++;
                    }
                    break;
                }
            }
        }
        return n;
    }
}
