package com.hazardyard.game.render;

/** What {@link TerrainRenderer} needs to know about the ground of a map: the ground type of a tile and whether it is water. */
interface GroundSource {
    byte ground(int tx, int ty);

    boolean water(int tx, int ty);
}
