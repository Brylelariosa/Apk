package com.hazardyard.game.core;

/**
 * The rule set of a match. Classic is the original deathmatch on one of the arenas; Battleground is
 * a free-for-all on one huge map with a full roster: real players come first and bots fill every
 * remaining slot, so the map never feels empty.
 */
public final class GameMode {
    public static final int CLASSIC = 0;
    public static final int BATTLEGROUND = 1;
    public static final int SURVIVAL = 2;
    public static final int COUNT = 3;

    public final int id;
    public final String name;
    public final String blurb;
    /** Arena this mode is played on, or -1 when the players choose one. */
    public final int mapId;
    public final int matchSeconds;
    /** Kills that end the match, or 0 when kills do not end it. */
    public final int killLimit;
    public final float respawnDelay;
    /** Seconds until a taken pad refills; negative: it never does. */
    public final float pickupRespawn;
    /**
     * Combatants a match is filled up to with bots (real players are never replaced: bots only take
     * slots no human holds). 0 means the mode adds no bots by itself.
     */
    public final int roster;
    /**
     * Battle royale rules: one life (nobody respawns), the last fighter standing wins, a safe zone shrinks over the
     * whole match (see {@link Zone}) and armour and first-aid kits lie around next to the guns. A pad never refills.
     */
    public final boolean royale;
    /**
     * Survival: an endless generated world with zombies, scavenging, crafting, building, farming, fishing and cars (see
     * {@code com.hazardyard.game.survival}). No bots, no time limit, no score; survivors respawn after a while.
     */
    public final boolean survival;

    private GameMode(int id, String name, String blurb, int mapId, int matchSeconds, int killLimit,
                     float respawnDelay, float pickupRespawn, int roster, boolean royale, boolean survival) {
        this.id = id;
        this.name = name;
        this.blurb = blurb;
        this.mapId = mapId;
        this.matchSeconds = matchSeconds;
        this.killLimit = killLimit;
        this.respawnDelay = respawnDelay;
        this.pickupRespawn = pickupRespawn;
        this.roster = roster;
        this.royale = royale;
        this.survival = survival;
    }

    public static final GameMode[] ALL = {
        new GameMode(CLASSIC, "Classic",
                "Deathmatch on a compact arena. First to the kill limit wins.",
                -1, GameConfig.MATCH_SECONDS, GameConfig.KILL_LIMIT,
                GameConfig.RESPAWN_DELAY, GameConfig.PICKUP_RESPAWN, 0, false, false),
        new GameMode(BATTLEGROUND, "Battleground",
                "Eight fighters, one life each, on a huge island of forests, towns and farms. Loot guns, armour and "
                        + "first-aid kits from the houses, stay inside the shrinking zone, be the last one standing. "
                        + "Bots fill every slot the real players leave empty.",
                MapLibrary.BATTLEGROUND, 720, 0, 0f, -1f, 8, true, false),
        new GameMode(SURVIVAL, "Survival",
                "An endless world full of zombies. Search houses for food, guns and car parts, craft tools, build a base, "
                        + "farm and fish, repair a wreck and drive. Up to four friends can join on the same Wi-Fi.",
                MapLibrary.DEFAULT_ID, 0, 0, 6f, -1f, 0, false, true),
    };

    public static GameMode byId(int id) {
        return (id >= 0 && id < ALL.length) ? ALL[id] : ALL[CLASSIC];
    }

    public static int clampId(int id) {
        return (id >= 0 && id < ALL.length) ? id : CLASSIC;
    }

    /** One line of rules for the set-up screens. */
    public String rulesText() {
        if (survival) return "No time limit and no score: scavenge, craft, build, farm and fish, and stay alive. Zombies are worse at night.";
        if (royale) {
            return "One life each. Loot guns, armour and first-aid kits, stay inside the shrinking zone and be the last one standing (about "
                    + Math.round(Zone.totalSeconds() / 60f) + " min).";
        }
        int minutes = matchSeconds / 60;
        return "First to " + killLimit + " kills wins, or the most kills when the clock runs out ("
                + minutes + (matchSeconds % 60 == 0 ? "" : ":" + (matchSeconds % 60 < 10 ? "0" : "") + matchSeconds % 60) + " min).";
    }

    /** True when the mode fixes the arena (the players cannot pick one). */
    public boolean fixedMap() {
        return roster > 0 || survival;
    }

    /**
     * How many bots a match needs: the roster minus the real players. Bots never push a human out:
     * with more humans than the roster allows there are simply none.
     */
    public int botsFor(int humans) {
        return Math.max(0, roster - Math.max(0, humans));
    }
}
