package com.hazardyard.game.core;

/**
 * An item pad on the map: a weapon crate, a vest or a first-aid kit (see {@link Items}). On the classic
 * arenas it comes back a while after somebody takes it; on Battleground it does not.
 */
public final class Pickup {
    public final float x, y;
    /** What lies here: an {@link Items} id. */
    public final int item;
    public boolean active = true;
    public float timer;

    public Pickup(float x, float y, int item) {
        this.x = x;
        this.y = y;
        this.item = item;
    }

    public boolean isWeapon() {
        return Items.isWeapon(item);
    }
}
