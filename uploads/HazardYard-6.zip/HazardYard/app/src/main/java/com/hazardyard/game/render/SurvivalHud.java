package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.input.SurvivalUi;
import com.hazardyard.game.survival.Car;
import com.hazardyard.game.survival.Inventory;
import com.hazardyard.game.survival.Recipes;
import com.hazardyard.game.survival.SurvivalSim;
import com.hazardyard.game.survival.SurvivalState;

/**
 * The survival screens: the hotbar and the bag button, hunger, the clock, fishing and driving read-outs, short messages, and
 * the bag with the pack and the crafting list. Geometry comes from {@link SurvivalUi}.
 */
final class SurvivalHud {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private Player curPlayer;
    private final Typeface bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD);
    private final Typeface regular = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL);

    SurvivalHud() {
        stroke.setStyle(Paint.Style.STROKE);
    }

    private void label(Canvas c, String s, float x, float y, float sizePx, int color, Paint.Align align, boolean isBold) {
        text.setTypeface(isBold ? bold : regular);
        text.setTextSize(sizePx);
        text.setColor(color);
        text.setTextAlign(align);
        c.drawText(s, x, y, text);
    }

    private float measure(String s, float sizePx, boolean isBold) {
        text.setTypeface(isBold ? bold : regular);
        text.setTextSize(sizePx);
        return text.measureText(s);
    }

    private void round(Canvas c, float x, float y, float wd, float ht, float r, int color) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        rect.set(x, y, x + wd, y + ht);
        c.drawRoundRect(rect, r, r, fill);
    }

    private void outline(Canvas c, float x, float y, float wd, float ht, float r, int color, float width) {
        stroke.setColor(color);
        stroke.setStrokeWidth(width);
        rect.set(x, y, x + wd, y + ht);
        c.drawRoundRect(rect, r, r, stroke);
    }

    void draw(Canvas c, GameState st, SurvivalUi ui, int w, int h, float d, float time, float insetL, float insetT, float insetR, float insetB) {
        SurvivalState sv = st.survival;
        Player me = st.local();
        curPlayer = st.view();
        Inventory inv = sv.inv[st.localId];
        ui.layout(w, h, d, insetL, insetT, insetR, insetB);
        ui.setContext(inv, SurvivalSim.nearObject(sv, me.x, me.y, com.hazardyard.game.survival.Obj.WORKBENCH),
                SurvivalSim.nearObject(sv, me.x, me.y, com.hazardyard.game.survival.Obj.CAMPFIRE));
        drawClock(c, sv, w, d, insetT, time);
        if (me.alive) {
            drawHunger(c, sv, ui, st.localId, d);
            drawHotbar(c, inv, ui, me, d);
            drawFishing(c, sv, st.localId, w, h, d, time);
            drawDriving(c, sv, st.localId, w, d, insetT);
        }
        drawToast(c, sv, w, h, d);
        if (ui.bagOpen && me.alive) drawBag(c, inv, ui, d);
    }

    // ------------------------------------------------------------------ small read-outs

    private void drawClock(Canvas c, SurvivalState sv, int w, float d, float insetT, float time) {
        float f = sv.dayFraction();
        float hours = (6f + f * 24f) % 24f;
        int hh = (int) hours;
        int mm = (int) ((hours - hh) * 60f);
        String clock = (hh < 10 ? "0" : "") + hh + ":" + (mm < 10 ? "0" : "") + mm;
        float pw = 124f * d, ph = 26f * d;
        float x = (w - pw) * 0.5f, y = insetT + 6f * d;
        round(c, x, y, pw, ph, 9f * d, 0x99101820);
        boolean night = sv.isNight();
        fill.setColor(night ? 0xFFC8D4F0 : 0xFFFFD34A);
        float cx = x + 14f * d, cy = y + ph * 0.5f;
        c.drawCircle(cx, cy, 6f * d, fill);
        if (night) {
            fill.setColor(0xFF1A2230);
            c.drawCircle(cx + 3f * d, cy - 2f * d, 5f * d, fill);
        }
        label(c, "Day " + sv.dayNumber(), x + 28f * d, y + ph * 0.68f, 12f * d, 0xFFFFFFFF, Paint.Align.LEFT, true);
        label(c, clock, x + pw - 8f * d, y + ph * 0.68f, 12f * d, night ? 0xFF9FB4E8 : 0xFFE8E8E8, Paint.Align.RIGHT, false);
        // where the survivor is, in tiles from the start: the world is endless, so this is the only way to find the way home
        Player me = curPlayer;
        if (me != null) {
            String where = "x " + Math.round(me.rx / GameConfig.TILE) + "   y " + Math.round(me.ry / GameConfig.TILE);
            label(c, where, w * 0.5f, y + ph + 11f * d, 9.5f * d, 0xAAFFFFFF, Paint.Align.CENTER, false);
        }
    }

    private void drawHunger(Canvas c, SurvivalState sv, SurvivalUi ui, int id, float d) {
        float hunger = Math.max(0f, Math.min(100f, sv.hunger[id]));
        float total = ui.bagBtnX + ui.bagBtnS - ui.hotX0;
        float x = ui.hotX0, y = ui.hotY - 11f * d, ht = 6f * d;
        round(c, x, y, total, ht, ht * 0.5f, 0x55FFFFFF);
        int color = hunger > 50f ? 0xFFFFB347 : (hunger > 20f ? 0xFFFF8A3A : 0xFFFF4A3A);
        if (hunger > 0.5f) round(c, x, y, total * hunger / 100f, ht, ht * 0.5f, color);
        label(c, hunger <= 0.5f ? "Starving!" : "Hunger", x, y - 3f * d, 10f * d, hunger <= 20f ? 0xFFFF6A5A : 0xFFE0E0E0, Paint.Align.LEFT, hunger <= 20f);
    }

    private void drawHotbar(Canvas c, Inventory inv, SurvivalUi ui, Player me, float d) {
        for (int i = 0; i < Inventory.HOTBAR; i++) {
            float x = ui.slotX(i);
            boolean sel = i == inv.selected;
            round(c, x, ui.hotY, ui.slot, ui.slot, 8f * d, sel ? 0xCC2A3A52 : 0x99101820);
            outline(c, x, ui.hotY, ui.slot, ui.slot, 8f * d, sel ? 0xFFFFD34A : 0x55FFFFFF, sel ? 2.4f * d : 1.2f * d);
            drawStack(c, inv, i, x, ui.hotY, ui.slot, d, me, true);
            label(c, Integer.toString(i + 1), x + 5f * d, ui.hotY + 12f * d, 9f * d, 0x99FFFFFF, Paint.Align.LEFT, false);
        }
        // the bag button
        round(c, ui.bagBtnX, ui.bagBtnY, ui.bagBtnS, ui.bagBtnS, 8f * d, ui.bagOpen ? 0xCC2A3A52 : 0x99101820);
        outline(c, ui.bagBtnX, ui.bagBtnY, ui.bagBtnS, ui.bagBtnS, 8f * d, 0xFFB8C4D8, 1.6f * d);
        float cx = ui.bagBtnX + ui.bagBtnS * 0.5f, cy = ui.bagBtnY + ui.bagBtnS * 0.46f;
        fill.setColor(0xFFC8A06A);
        rect.set(cx - 10f * d, cy - 7f * d, cx + 10f * d, cy + 9f * d);
        c.drawRoundRect(rect, 4f * d, 4f * d, fill);
        fill.setColor(0xFF8A6A3A);
        rect.set(cx - 6f * d, cy - 11f * d, cx + 6f * d, cy - 5f * d);
        c.drawRoundRect(rect, 3f * d, 3f * d, fill);
        label(c, "BAG", cx, ui.bagBtnY + ui.bagBtnS - 4f * d, 8.5f * d, 0xFFE8E8E8, Paint.Align.CENTER, true);
    }

    /** The item in a slot: its icon, its count, and for a gun the rounds in the magazine. */
    private void drawStack(Canvas c, Inventory inv, int slot, float x, float y, float size, float d, Player me, boolean small) {
        if (inv.isEmpty(slot)) return;
        int item = inv.item[slot];
        int color = 0xFF000000 | (Items.color(item) & 0x00FFFFFF);
        ItemGlyph.draw(c, fill, path, x + size * 0.5f, y + size * 0.47f, size * 0.30f, item, color);
        if (inv.count[slot] > 1) label(c, "x" + inv.count[slot], x + size - 4f * d, y + size - 4f * d, 10f * d, 0xFFFFFFFF, Paint.Align.RIGHT, true);
        if (Items.isWeapon(item) && !WeaponDef.byId(item).melee) {
            int rounds = slot == inv.selected && me != null && me.weapon.def.id == item ? me.weapon.ammo : inv.ammo[slot];
            label(c, Integer.toString(rounds), x + size - 4f * d, y + size - 4f * d, 10f * d, 0xFFFFD34A, Paint.Align.RIGHT, true);
        }
    }

    private void drawFishing(Canvas c, SurvivalState sv, int id, int w, int h, float d, float time) {
        int state = sv.fishState[id];
        if (state == 0) return;
        if (state == 2) {
            float pulse = 0.5f + 0.5f * (float) Math.sin(time * 18f);
            round(c, w * 0.5f - 90f * d, h * 0.2f - 18f * d, 180f * d, 36f * d, 12f * d, 0xDD1A2A3A);
            outline(c, w * 0.5f - 90f * d, h * 0.2f - 18f * d, 180f * d, 36f * d, 12f * d, 0xFFFFE066, (2f + 2f * pulse) * d);
            label(c, "A fish! Tap to reel in", w * 0.5f, h * 0.2f + 5f * d, 15f * d, 0xFFFFE066, Paint.Align.CENTER, true);
        } else {
            label(c, "Waiting for a bite...", w * 0.5f, h * 0.2f, 12f * d, 0xCCFFFFFF, Paint.Align.CENTER, false);
        }
    }

    private void drawDriving(Canvas c, SurvivalState sv, int id, int w, float d, float insetT) {
        int carId = sv.drivingCar[id];
        if (carId < 0) return;
        Car car = sv.carById(carId);
        if (car == null) return;
        float pw = 150f * d, ph = 40f * d;
        float x = (w - pw) * 0.5f, y = insetT + 52f * d;
        round(c, x, y, pw, ph, 10f * d, 0xAA101820);
        int kmh = Math.round(Math.abs(car.speed) * 0.36f);
        label(c, kmh + " km/h", x + 10f * d, y + 16f * d, 14f * d, 0xFFFFFFFF, Paint.Align.LEFT, true);
        label(c, car.running ? "Engine on" : "Engine off", x + pw - 8f * d, y + 16f * d, 10f * d, car.running ? 0xFF6EE08A : 0xFFFF8A6A, Paint.Align.RIGHT, false);
        float bw = pw - 20f * d;
        round(c, x + 10f * d, y + 24f * d, bw, 5f * d, 2.5f * d, 0x44FFFFFF);
        round(c, x + 10f * d, y + 24f * d, bw * Math.max(0, car.fuel) / 100f, 5f * d, 2.5f * d, car.fuel < 15 ? 0xFFFF5A4A : 0xFFFFC04A);
        round(c, x + 10f * d, y + 32f * d, bw, 3f * d, 1.5f * d, 0x44FFFFFF);
        round(c, x + 10f * d, y + 32f * d, bw * Math.max(0, car.hp) / 100f, 3f * d, 1.5f * d, 0xFF6EE08A);
    }

    private void drawToast(Canvas c, SurvivalState sv, int w, int h, float d) {
        if (sv.toast < 0 || sv.toast >= SurvivalSim.TOASTS.length || sv.toastTimer <= 0f) return;
        String s = SurvivalSim.TOASTS[sv.toast];
        float a = Math.min(1f, sv.toastTimer / 0.5f);
        float tw = measure(s, 14f * d, true) + 28f * d;
        float x = (w - tw) * 0.5f, y = h * 0.30f;
        round(c, x, y, tw, 30f * d, 10f * d, ((int) (a * 200f) << 24) | 0x101820);
        label(c, s, w * 0.5f, y + 20f * d, 14f * d, ((int) (a * 255f) << 24) | 0xFFFFFF, Paint.Align.CENTER, true);
    }

    // ------------------------------------------------------------------ the bag

    private void drawBag(Canvas c, Inventory inv, SurvivalUi ui, float d) {
        round(c, ui.panelX0, ui.panelY0, ui.panelX1 - ui.panelX0, ui.panelY1 - ui.panelY0, 14f * d, 0xF610161E);
        outline(c, ui.panelX0, ui.panelY0, ui.panelX1 - ui.panelX0, ui.panelY1 - ui.panelY0, 14f * d, 0x66FFFFFF, 1.4f * d);
        label(c, "Pack", ui.gridX0, ui.panelY0 + 28f * d, 16f * d, 0xFFFFFFFF, Paint.Align.LEFT, true);
        label(c, "Crafting", ui.listX0, ui.panelY0 + 28f * d, 16f * d, 0xFFFFFFFF, Paint.Align.LEFT, true);
        // close button
        round(c, ui.closeX, ui.closeY, ui.closeS, ui.closeS, 9f * d, 0xFF3A2428);
        stroke.setColor(0xFFFFFFFF);
        stroke.setStrokeWidth(2.4f * d);
        float m = ui.closeS * 0.3f;
        c.drawLine(ui.closeX + m, ui.closeY + m, ui.closeX + ui.closeS - m, ui.closeY + ui.closeS - m, stroke);
        c.drawLine(ui.closeX + ui.closeS - m, ui.closeY + m, ui.closeX + m, ui.closeY + ui.closeS - m, stroke);
        // the pack
        for (int i = 0; i < Inventory.SLOTS; i++) {
            float x = ui.cellX(i), y = ui.cellY(i);
            boolean hot = i < Inventory.HOTBAR;
            round(c, x, y, ui.cell, ui.cell, 7f * d, hot ? 0xAA24324A : 0xAA1C222C);
            outline(c, x, y, ui.cell, ui.cell, 7f * d, i == ui.selSlot ? 0xFFFFD34A : (i == inv.selected && hot ? 0xFF8FC4FF : 0x44FFFFFF), i == ui.selSlot ? 2.6f * d : 1.1f * d);
            drawStack(c, inv, i, x, y, ui.cell, d, null, false);
        }
        label(c, "Top row: hotbar", ui.gridX0, ui.btnY + ui.btnH + 16f * d, 9f * d, 0x88FFFFFF, Paint.Align.LEFT, false);
        int sel = ui.selSlot >= 0 && !inv.isEmpty(ui.selSlot) ? inv.item[ui.selSlot] : -1;
        String desc = sel >= 0 ? SurvivalUi.describe(sel) : "Tap an item, then another slot to move it";
        label(c, desc, ui.gridX0, ui.btnY - 6f * d, 10f * d, 0xFFD8E0EC, Paint.Align.LEFT, false);
        boolean usable = sel >= 0 && (Items.foodValue(sel) > 0 || Items.healValue(sel) > 0 || Items.isVest(sel));
        button(c, ui.useX, ui.btnY, ui.btnW, ui.btnH, "Use", usable, 0xFF2E6A44, d);
        button(c, ui.dropX, ui.btnY, ui.btnW, ui.btnH, "Drop", sel >= 0, 0xFF6A3A2E, d);
        // crafting
        c.save();
        c.clipRect(ui.listX0, ui.listY0, ui.listX1, ui.listY1);
        for (int r = 0; r < Recipes.ALL.length; r++) {
            float y = ui.rowY(r);
            if (y + ui.rowH < ui.listY0 || y > ui.listY1) continue;
            Recipes.Recipe rc = Recipes.ALL[r];
            boolean can = ui.craftable(r);
            round(c, ui.listX0, y + 2f * d, ui.listX1 - ui.listX0, ui.rowH - 4f * d, 8f * d, r == ui.selRecipe ? 0xCC2A3A52 : 0x99181E28);
            if (r == ui.selRecipe) outline(c, ui.listX0, y + 2f * d, ui.listX1 - ui.listX0, ui.rowH - 4f * d, 8f * d, 0xFFFFD34A, 1.8f * d);
            int col = 0xFF000000 | (Items.color(rc.out) & 0x00FFFFFF);
            ItemGlyph.draw(c, fill, path, ui.listX0 + 22f * d, y + ui.rowH * 0.5f, 10f * d, rc.out, col);
            label(c, rc.name, ui.listX0 + 42f * d, y + 16f * d, 12f * d, can ? 0xFF8FE8A0 : 0xFFE0E4EC, Paint.Align.LEFT, true);
            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < rc.in.length; k += 2) {
                if (k > 0) sb.append(", ");
                sb.append(Items.name(rc.in[k])).append(' ').append(rc.in[k + 1]);
            }
            if (rc.station == Recipes.BENCH) sb.append("  \u00B7 Workbench");
            if (rc.station == Recipes.FIRE) sb.append("  \u00B7 Campfire");
            label(c, sb.toString(), ui.listX0 + 42f * d, y + 31f * d, 9.5f * d, 0xFFA8B4C8, Paint.Align.LEFT, false);
        }
        c.restore();
        boolean can = ui.selRecipe >= 0 && ui.craftable(ui.selRecipe);
        button(c, ui.craftX, ui.craftY, ui.craftW, ui.btnH, ui.selRecipe >= 0 ? "Craft" : "Pick a recipe", can, 0xFF2E6A44, d);
        if (ui.selRecipe >= 0 && !can) {
            Recipes.Recipe rc = Recipes.ALL[ui.selRecipe];
            String why = rc.station == Recipes.BENCH && !ui.nearBench() ? "Stand next to a workbench" : (rc.station == Recipes.FIRE && !ui.nearFire() ? "Stand next to a campfire" : "Missing materials");
            label(c, why, ui.craftX - 8f * d, ui.craftY + ui.btnH * 0.62f, 10f * d, 0xFFFF9A8A, Paint.Align.RIGHT, false);
        }
    }

    private void button(Canvas c, float x, float y, float wd, float ht, String s, boolean enabled, int color, float d) {
        round(c, x, y, wd, ht, 9f * d, enabled ? color : 0xFF2A2E36);
        outline(c, x, y, wd, ht, 9f * d, enabled ? 0xCCFFFFFF : 0x44FFFFFF, 1.4f * d);
        label(c, s, x + wd * 0.5f, y + ht * 0.64f, 13f * d, enabled ? 0xFFFFFFFF : 0x66FFFFFF, Paint.Align.CENTER, true);
    }
}
