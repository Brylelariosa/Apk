package com.hazardyard.game.survival;

import com.hazardyard.game.core.CollisionSystem;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.GameWorld;
import com.hazardyard.game.core.Items;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.Projectile;
import com.hazardyard.game.core.Sounds;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.core.XorShift;

import java.util.ArrayList;

/**
 * The rules of survival mode, run by the host (or by a solo game): hunger, zombies, searching furniture, crafting, building,
 * farming, fishing, harvesting, cars. It changes the {@link SurvivalState} and reports what other devices need to know
 * (sounds, changed tiles, messages) through {@link Out}.
 */
public final class SurvivalSim implements SurvivalTerrain.Listener {
    /** What the sim tells the outside world. */
    public interface Out {
        /** A sound at a place; {@code pitch} 0 means the usual variation. */
        void sound(int sound, float x, float y, float volume, float pitch);

        /** A tile changed: layer 0 object (value = {@link Obj}, meta), layer 1 ground. */
        void edit(int tx, int ty, int layer, int value, int meta);

        /** A short message for one survivor ({@link #TOASTS} index). */
        void toast(int playerId, int code);
    }

    public static final int CMD_SELECT = 1, CMD_DROP = 2, CMD_SWAP = 3, CMD_CRAFT = 4, CMD_USE = 5;

    public static final int T_NO_AMMO = 0, T_AIM_WATER = 1, T_GOT_AWAY = 2, T_NEEDS_PICK = 3, T_NOTHING = 4, T_PACK_FULL = 5,
            T_NEEDS_WRENCH = 6, T_NEEDS_BATTERY = 7, T_NEEDS_ENGINE = 8, T_NEEDS_TYRE = 9, T_NEEDS_FUEL = 10, T_CANT_PLACE = 11,
            T_NEEDS_TILLED = 12, T_STARVING = 13, T_NO_MATERIALS = 14, T_NEEDS_BENCH = 15, T_NEEDS_FIRE = 16, T_CAR_DEAD = 17,
            T_TILL_FIRST = 18, T_NOT_HUNGRY = 19;
    public static final String[] TOASTS = {
            "Out of ammunition", "Aim at the water to fish", "It got away...", "You need a pickaxe for that", "Nothing here",
            "Your pack is full", "You need a wrench", "The car needs a battery", "The car needs engine parts", "The car needs a tyre",
            "The car needs fuel", "Can't build there", "Plant seeds on tilled soil", "You are starving! Eat something",
            "Not enough materials", "You need a workbench nearby", "You need a campfire nearby", "The car is wrecked",
            "Till the soil with a hoe first", "You are not hungry"};

    private static final float TILE = GameConfig.TILE;
    private static final int TREE_HP = 9;
    private static final int ROCK_HP = 9;
    private static final float PLANT_STAGE_SECONDS = 70f;

    private final GameState st;
    private final SurvivalState sv;
    private final GameWorld world;
    private final CollisionSystem col;
    private final Out out;
    private final XorShift rng;

    private final float[] useCd = new float[GameConfig.MAX_PLAYERS];
    private final float[] toastCd = new float[GameConfig.MAX_PLAYERS];
    private final float[] starveT = new float[GameConfig.MAX_PLAYERS];
    private final float[] regenT = new float[GameConfig.MAX_PLAYERS];
    private final float[] fishT = new float[GameConfig.MAX_PLAYERS];
    private final int[] lastSel = new int[GameConfig.MAX_PLAYERS];
    private final Interaction inter = new Interaction();
    private final int[] lootItems = new int[4];
    private final int[] lootCounts = new int[4];
    private final float[] carBuf = new float[3 * 8];

    private static final class Crop {
        int tx, ty;
        float timer;
    }

    private final ArrayList<Crop> crops = new ArrayList<>();
    private int nextId = 1;
    private float chunkT, spawnT, ambientT;

    public SurvivalSim(GameState st, SurvivalState sv, GameWorld world, CollisionSystem col, Out out) {
        this.st = st;
        this.sv = sv;
        this.world = world;
        this.col = col;
        this.out = out;
        this.rng = new XorShift(sv.seed ^ 0x51ED);
        sv.terrain.listener = this;
        java.util.Arrays.fill(lastSel, -1);
    }

    private int newId() {
        nextId = (nextId + 1) & 0xFFFF;
        if (nextId == 0) nextId = 1;
        return nextId;
    }

    private static float dist2(float ax, float ay, float bx, float by) {
        float dx = ax - bx, dy = ay - by;
        return dx * dx + dy * dy;
    }

    // ------------------------------------------------------------------ spawning and respawning survivors

    /** Puts a survivor on open ground near the start (or near a living friend). */
    public void placeAtSpawn(Player p) {
        float cx = 0f, cy = 0f;
        int friend = -1;
        int seen = 0;
        for (Player q : st.players) {
            if (q == p || !q.connected || !q.alive) continue;
            if (rng.nextInt(++seen) == 0) friend = q.id;
        }
        if (friend >= 0) {
            cx = st.players[friend].x;
            cy = st.players[friend].y;
        }
        for (int tries = 0; tries < 80; tries++) {
            float ang = rng.nextFloat() * MathUtil.TWO_PI;
            float r = (friend >= 0 ? 90f : 60f) + rng.nextFloat() * (friend >= 0 ? 220f : 260f) + tries * 6f;
            float x = cx + (float) Math.cos(ang) * r;
            float y = cy + (float) Math.sin(ang) * r;
            int tx = SurvivalTerrain.tileOf(x), ty = SurvivalTerrain.tileOf(y);
            if (openArea(tx, ty)) {
                p.x = (tx + 0.5f) * TILE;
                p.y = (ty + 0.5f) * TILE;
                p.rx = p.x;
                p.ry = p.y;
                return;
            }
        }
        p.x = p.rx = 16f;
        p.y = p.ry = 16f;
    }

    private boolean openArea(int tx, int ty) {
        for (int dy = -1; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) if (!sv.terrain.walkable(tx + dx, ty + dy)) return false;
        }
        return true;
    }

    /** A survivor has just entered the world (first spawn or respawn): empty pack, a knife, bandages, a tin of food. */
    public void onSpawned(Player p) {
        Inventory inv = sv.inv[p.id];
        inv.clear();
        inv.add(WeaponDef.KNIFE, 1);
        inv.add(Items.BANDAGE, 2);
        inv.add(Items.CANNED, 1);
        inv.selected = 0;
        sv.hunger[p.id] = 80f;
        sv.drivingCar[p.id] = -1;
        sv.fishState[p.id] = 0;
        lastSel[p.id] = -1;
        useCd[p.id] = 0.5f;
        p.armor = 0;
        syncEquipment(p);
    }

    /** Called when a survivor dies: everything they carried falls to the ground. */
    public void playerDied(Player p) {
        Inventory inv = sv.inv[p.id];
        for (int i = 0; i < Inventory.SLOTS; i++) {
            if (inv.isEmpty(i)) continue;
            dropItem(inv.item[i], inv.count[i], p.x, p.y);
        }
        inv.clear();
        leaveCar(p, false);
        sv.fishState[p.id] = 0;
    }

    public void playerLeft(Player p) {
        playerDied(p);
    }

    // ------------------------------------------------------------------ the world fills up around the survivors

    @Override
    public void chunkCreated(Chunk c) {
        if (c.populated) return;
        c.populated = true;
        int n = sv.terrain.gen.zombiesIn(c.cx, c.cy);
        for (int i = 0; i < n; i++) {
            for (int tries = 0; tries < 6; tries++) {
                int tx = c.cx * Chunk.SIZE + rng.nextInt(Chunk.SIZE);
                int ty = c.cy * Chunk.SIZE + rng.nextInt(Chunk.SIZE);
                if (sv.terrain.walkable(tx, ty)) {
                    spawnZombie((tx + 0.5f) * TILE, (ty + 0.5f) * TILE);
                    break;
                }
            }
        }
        int cars = sv.terrain.gen.carSlots(c.cx, c.cy, carBuf);
        for (int i = 0; i < cars; i++) {
            Car car = freeCar();
            if (car == null) break;
            car.active = true;
            car.id = newId();
            car.x = car.rx = carBuf[i * 3];
            car.y = car.ry = carBuf[i * 3 + 1];
            car.heading = car.rHeading = carBuf[i * 3 + 2];
            car.speed = 0f;
            car.driver = -1;
            car.running = false;
            car.variant = rng.nextInt(6);
            car.engineOk = rng.nextInt(100) < 35;
            car.batteryOk = rng.nextInt(100) < 40;
            car.tyresOk = rng.nextInt(100) < 55;
            car.fuel = rng.nextInt(100) < 50 ? 10 + rng.nextInt(50) : 0;
            car.hp = 40 + rng.nextInt(61);
        }
    }

    private Car freeCar() {
        for (Car c : sv.cars) if (!c.active) return c;
        return null;
    }

    private Zombie freeZombie() {
        for (Zombie z : sv.zombies) if (!z.active) return z;
        return null;
    }

    private Drop freeDrop() {
        Drop oldest = null;
        for (Drop d : sv.drops) {
            if (!d.active) return d;
            if (oldest == null || d.ttl < oldest.ttl) oldest = d;
        }
        return oldest;
    }

    private Zombie spawnZombie(float x, float y) {
        Zombie z = freeZombie();
        if (z == null) return null;
        boolean night = sv.isNight();
        int roll = rng.nextInt(100);
        z.type = night ? (roll < 55 ? Zombie.WALKER : (roll < 90 ? Zombie.RUNNER : Zombie.BRUTE))
                : (roll < 78 ? Zombie.WALKER : (roll < 94 ? Zombie.RUNNER : Zombie.BRUTE));
        z.active = true;
        z.id = newId();
        z.hp = Zombie.maxHp(z.type);
        z.x = z.rx = x;
        z.y = z.ry = y;
        z.aim = z.rAim = rng.nextFloat() * MathUtil.TWO_PI;
        z.target = -1;
        z.attacking = false;
        z.hurt = 0f;
        z.stunT = 0f;
        z.farT = 0f;
        z.alertT = 0f;
        z.hasWander = false;
        z.wanderT = rng.nextFloat() * 3f;
        z.attackCd = 0.4f;
        z.groanT = 2f + rng.nextFloat() * 8f;
        return z;
    }

    // ------------------------------------------------------------------ the clock

    public void step(float dt) {
        sv.time += dt;
        if (sv.toastTimer > 0f) sv.toastTimer -= dt;
        for (int i = 0; i < GameConfig.MAX_PLAYERS; i++) {
            if (useCd[i] > 0f) useCd[i] -= dt;
            if (toastCd[i] > 0f) toastCd[i] -= dt;
        }
        chunkT -= dt;
        if (chunkT <= 0f) {
            chunkT = 0.5f;
            ensureChunks();
        }
        for (Player p : st.players) {
            if (p.connected && p.alive) stepPlayer(p, dt);
        }
        stepZombies(dt);
        stepCars(dt);
        stepCrops(dt);
        stepDrops(dt);
        stepSpawner(dt);
        // what is drawn follows what is simulated (the host and a solo game have nothing to smooth)
        for (Zombie z : sv.zombies) {
            if (!z.active) continue;
            z.rx = z.x;
            z.ry = z.y;
            z.rAim = z.aim;
        }
        for (Car c : sv.cars) {
            if (!c.active) continue;
            c.rx = c.x;
            c.ry = c.y;
            c.rHeading = c.heading;
        }
    }

    /** Generates the chunks round every survivor ahead of them, so zombies and cars are in place before anybody arrives. */
    private void ensureChunks() {
        for (Player p : st.players) {
            if (!p.connected || !p.alive) continue;
            int cx = Math.floorDiv(SurvivalTerrain.tileOf(p.x), Chunk.SIZE);
            int cy = Math.floorDiv(SurvivalTerrain.tileOf(p.y), Chunk.SIZE);
            for (int dy = -3; dy <= 3; dy++) for (int dx = -3; dx <= 3; dx++) sv.terrain.chunk(cx + dx, cy + dy);
        }
    }

    private void stepPlayer(Player p, float dt) {
        Inventory inv = sv.inv[p.id];
        syncEquipment(p);
        // hunger, starving and slow healing while fed
        float h = Math.max(0f, sv.hunger[p.id] - dt * 0.085f);
        sv.hunger[p.id] = h;
        if (h <= 0f) {
            starveT[p.id] += dt;
            if (starveT[p.id] >= 2f) {
                starveT[p.id] = 0f;
                toast(p, T_STARVING);
                world.hurt(p.id, 2, -1, GameConfig.CAUSE_HUNGER, p.x, p.y);
            }
        } else if (h > 40f && p.health < GameConfig.PLAYER_MAX_HEALTH) {
            regenT[p.id] += dt;
            if (regenT[p.id] >= 3.5f) {
                regenT[p.id] = 0f;
                p.health = Math.min(GameConfig.PLAYER_MAX_HEALTH, p.health + 1);
            }
        }
        stepFishing(p, dt);
        // the rounds in the gun in hand are remembered by the pack
        int it = inv.selectedItem();
        if (it >= 0 && Items.isWeapon(it) && !WeaponDef.byId(it).melee && p.weapon.def.id == it) inv.ammo[inv.selected] = p.weapon.ammo;
    }

    /** The weapon in the survivor's hands follows the selected hotbar slot; anything that is not a weapon means bare hands. */
    private void syncEquipment(Player p) {
        Inventory inv = sv.inv[p.id];
        int sel = inv.selected;
        int it = inv.selectedItem();
        WeaponDef want = it >= 0 && Items.isWeapon(it) ? WeaponDef.byId(it) : WeaponDef.byId(WeaponDef.FISTS);
        int last = lastSel[p.id];
        if (last != sel || p.weapon.def != want) {
            if (last >= 0 && last < Inventory.SLOTS && !inv.isEmpty(last) && Items.isWeapon(inv.item[last])
                    && inv.item[last] == p.weapon.def.id && !p.weapon.def.melee) {
                inv.ammo[last] = p.weapon.ammo;
            }
            if (p.weapon.def != want) {
                p.weapon.equip(want);
                if (!want.melee && it >= 0) p.weapon.ammo = MathUtil.clamp(inv.ammo[sel], 0, want.magSize);
                p.pullBuffer = 0f;
                p.reloadPullMark = p.pulls;
            }
            lastSel[p.id] = sel;
            cancelFishing(p);
        }
    }

    // ------------------------------------------------------------------ guns: ammunition comes out of the pack

    /** Rounds the survivor carries for the gun in hand. */
    public int ammoFor(Player p) {
        int item = Items.ammoFor(p.weapon.def.id);
        return item < 0 ? 0 : sv.inv[p.id].countOf(item);
    }

    /** The gun took {@code n} rounds out of the pack during a reload. */
    public void onReloaded(Player p, int n) {
        int item = Items.ammoFor(p.weapon.def.id);
        if (item >= 0) sv.inv[p.id].remove(item, Math.min(n, sv.inv[p.id].countOf(item)));
    }

    public void toast(Player p, int code) {
        if (toastCd[p.id] > 0f) return;
        toastCd[p.id] = 1.6f;
        out.toast(p.id, code);
    }

    /** A shot, an engine: zombies within hearing distance come to have a look. */
    public void noise(float x, float y, float radius) {
        float r2 = radius * radius;
        for (Zombie z : sv.zombies) {
            if (!z.active || z.target >= 0) continue;
            if (dist2(z.x, z.y, x, y) < r2) {
                z.hasWander = true;
                z.wanderX = x;
                z.wanderY = y;
                z.alertT = 7f;
                z.wanderT = 7f;
            }
        }
    }

    // ------------------------------------------------------------------ commands from the inventory screen

    public void command(Player p, int cmd, int a, int b) {
        if (!p.alive) return;
        Inventory inv = sv.inv[p.id];
        switch (cmd) {
            case CMD_SELECT:
                inv.selected = MathUtil.clamp(a, 0, Inventory.HOTBAR - 1);
                inv.dirty = true;
                break;
            case CMD_DROP:
                if (a >= 0 && a < Inventory.SLOTS && !inv.isEmpty(a)) {
                    if (a == inv.selected && Items.isWeapon(inv.item[a]) && !p.weapon.def.melee) inv.ammo[a] = p.weapon.ammo;
                    float ang = p.aim;
                    dropItem(inv.item[a], inv.count[a], p.x + (float) Math.cos(ang) * 30f, p.y + (float) Math.sin(ang) * 30f);
                    inv.clearSlot(a);
                }
                break;
            case CMD_SWAP:
                inv.swap(a, b);
                break;
            case CMD_CRAFT:
                craft(p, a);
                break;
            case CMD_USE:
                useSlot(p, a);
                break;
            default:
                break;
        }
    }

    private void craft(Player p, int index) {
        if (index < 0 || index >= Recipes.ALL.length) return;
        Recipes.Recipe r = Recipes.ALL[index];
        Inventory inv = sv.inv[p.id];
        if (r.station == Recipes.BENCH && !nearObject(p, Obj.WORKBENCH)) {
            toast(p, T_NEEDS_BENCH);
            return;
        }
        if (r.station == Recipes.FIRE && !nearObject(p, Obj.CAMPFIRE)) {
            toast(p, T_NEEDS_FIRE);
            return;
        }
        if (!Recipes.canAfford(inv, r) || !Recipes.craft(inv, r)) {
            toast(p, T_NO_MATERIALS);
            return;
        }
        out.sound(Sounds.CRAFT, p.x, p.y, 1f, 0f);
    }

    /** True when an object of this kind stands within crafting reach of the survivor. */
    public boolean nearObject(Player p, byte kind) {
        return nearObject(sv, p.x, p.y, kind);
    }

    public static boolean nearObject(SurvivalState sv, float x, float y, byte kind) {
        int ptx = SurvivalTerrain.tileOf(x), pty = SurvivalTerrain.tileOf(y);
        int r = (int) Math.ceil(Recipes.STATION_REACH / TILE);
        for (int dy = -r; dy <= r; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                if (sv.terrain.objAt(ptx + dx, pty + dy) != kind) continue;
                float cx = (ptx + dx + 0.5f) * TILE - x, cy = (pty + dy + 0.5f) * TILE - y;
                if (cx * cx + cy * cy <= Recipes.STATION_REACH * Recipes.STATION_REACH) return true;
            }
        }
        return false;
    }

    /** Uses an item straight from the pack (eat, bandage, vest). */
    private void useSlot(Player p, int slot) {
        Inventory inv = sv.inv[p.id];
        if (slot < 0 || slot >= Inventory.SLOTS || inv.isEmpty(slot)) return;
        int it = inv.item[slot];
        if (Items.foodValue(it) > 0 || Items.healValue(it) > 0 || Items.isVest(it)) consume(p, slot);
    }

    private boolean consume(Player p, int slot) {
        Inventory inv = sv.inv[p.id];
        int it = inv.item[slot];
        int food = Items.foodValue(it);
        if (food > 0) {
            if (sv.hunger[p.id] >= 97f) {
                toast(p, T_NOT_HUNGRY);
                return false;
            }
            sv.hunger[p.id] = Math.min(100f, sv.hunger[p.id] + food);
            p.health = Math.min(GameConfig.PLAYER_MAX_HEALTH, p.health + 2);
            take(inv, slot);
            out.sound(Sounds.EAT, p.x, p.y, 1f, 0f);
            return true;
        }
        int heal = Items.healValue(it);
        if (heal > 0) {
            if (p.health >= GameConfig.PLAYER_MAX_HEALTH) return false;
            p.health = Math.min(GameConfig.PLAYER_MAX_HEALTH, p.health + heal);
            take(inv, slot);
            out.sound(Sounds.HEAL, p.x, p.y, 1f, 0f);
            return true;
        }
        if (Items.isVest(it)) {
            int give = Items.armorOf(it);
            if (p.armor >= give) return false;
            p.armor = give;
            take(inv, slot);
            out.sound(Sounds.ARMOR_EQUIP, p.x, p.y, 1f, 0f);
            return true;
        }
        return false;
    }

    private static void take(Inventory inv, int slot) {
        inv.count[slot]--;
        if (inv.count[slot] <= 0) inv.clearSlot(slot);
        inv.dirty = true;
    }

    // ------------------------------------------------------------------ the primary action with something that is not a weapon in hand

    /** True when pulling the trigger means "use the item in hand" (eat, place, plant, fish) rather than fight. */
    public boolean handlesTrigger(Player p) {
        int it = sv.inv[p.id].selectedItem();
        return it >= 0 && !Items.isWeapon(it) && sv.drivingCar[p.id] < 0;
    }

    public void useSelected(Player p) {
        Inventory inv = sv.inv[p.id];
        int slot = inv.selected;
        int it = inv.selectedItem();
        if (it < 0) return;
        if (useCd[p.id] > 0f) return;
        useCd[p.id] = 0.4f;
        int cat = Items.category(it);
        switch (cat) {
            case Items.CAT_FOOD:
            case Items.CAT_HEAL:
            case Items.CAT_ARMOR:
                useCd[p.id] = 0.7f;
                consume(p, slot);
                break;
            case Items.CAT_SEED:
                plant(p, slot, it);
                break;
            case Items.CAT_BUILD:
                place(p, slot, it);
                break;
            case Items.CAT_TOOL:
                if (it == Items.HOE) till(p);
                else if (it == Items.ROD) useRod(p);
                break;
            default:
                break;
        }
    }

    private int aimTileX(Player p, float dist) {
        return SurvivalTerrain.tileOf(p.x + (float) Math.cos(p.aim) * dist);
    }

    private int aimTileY(Player p, float dist) {
        return SurvivalTerrain.tileOf(p.y + (float) Math.sin(p.aim) * dist);
    }

    private boolean tileFreeForBuilding(int tx, int ty, boolean solid, Player self) {
        SurvivalTerrain t = sv.terrain;
        if (t.groundAt(tx, ty) == TileMap.G_WATER || t.objAt(tx, ty) != Obj.NONE) return false;
        if (!solid) return true;
        float cx = (tx + 0.5f) * TILE, cy = (ty + 0.5f) * TILE;
        float lim = (TILE * 0.5f + GameConfig.PLAYER_RADIUS);
        for (Player q : st.players) {
            if (!q.connected || !q.alive) continue;
            if (Math.abs(q.x - cx) < lim && Math.abs(q.y - cy) < lim) return false;
        }
        for (Zombie z : sv.zombies) {
            if (z.active && Math.abs(z.x - cx) < lim && Math.abs(z.y - cy) < lim) return false;
        }
        for (Car c : sv.cars) {
            if (c.active && Math.abs(c.x - cx) < TILE * 0.5f + Car.RADIUS && Math.abs(c.y - cy) < TILE * 0.5f + Car.RADIUS) return false;
        }
        return true;
    }

    private void place(Player p, int slot, int it) {
        int tx = aimTileX(p, 50f), ty = aimTileY(p, 50f);
        float cx = (tx + 0.5f) * TILE, cy = (ty + 0.5f) * TILE;
        if (dist2(cx, cy, p.x, p.y) > 90f * 90f) {
            toast(p, T_CANT_PLACE);
            return;
        }
        Inventory inv = sv.inv[p.id];
        switch (it) {
            case Items.FLOOR:
                if (sv.terrain.groundAt(tx, ty) == TileMap.G_WATER || sv.terrain.objAt(tx, ty) != Obj.NONE
                        || sv.terrain.groundAt(tx, ty) == TileMap.G_WOOD) {
                    toast(p, T_CANT_PLACE);
                    return;
                }
                editGround(tx, ty, TileMap.G_WOOD);
                break;
            case Items.WALL:
                if (!tileFreeForBuilding(tx, ty, true, p)) {
                    toast(p, T_CANT_PLACE);
                    return;
                }
                editObj(tx, ty, Obj.WALL, 100);
                break;
            case Items.DOOR:
                if (!tileFreeForBuilding(tx, ty, true, p)) {
                    toast(p, T_CANT_PLACE);
                    return;
                }
                editObj(tx, ty, Obj.DOOR, 30 << 1);
                break;
            case Items.WORKBENCH:
                if (!tileFreeForBuilding(tx, ty, true, p)) {
                    toast(p, T_CANT_PLACE);
                    return;
                }
                editObj(tx, ty, Obj.WORKBENCH, 0);
                break;
            case Items.CAMPFIRE:
                if (!tileFreeForBuilding(tx, ty, false, p)) {
                    toast(p, T_CANT_PLACE);
                    return;
                }
                editObj(tx, ty, Obj.CAMPFIRE, 0);
                break;
            default:
                return;
        }
        take(inv, slot);
        out.sound(Sounds.BUILD, cx, cy, 1f, 0f);
    }

    private void till(Player p) {
        int tx = aimTileX(p, 48f), ty = aimTileY(p, 48f);
        byte g = sv.terrain.groundAt(tx, ty);
        boolean soft = g == TileMap.G_GRASS || g == TileMap.G_MEADOW || g == TileMap.G_DIRT || g == TileMap.G_FOREST;
        if (!soft || sv.terrain.objAt(tx, ty) != Obj.NONE) {
            toast(p, T_CANT_PLACE);
            return;
        }
        editGround(tx, ty, TileMap.G_TILLED);
        out.sound(Sounds.DIG, (tx + 0.5f) * TILE, (ty + 0.5f) * TILE, 1f, 0f);
    }

    private void plant(Player p, int slot, int seed) {
        int tx = aimTileX(p, 48f), ty = aimTileY(p, 48f);
        if (sv.terrain.groundAt(tx, ty) != TileMap.G_TILLED || sv.terrain.objAt(tx, ty) != Obj.NONE) {
            toast(p, sv.terrain.groundAt(tx, ty) == TileMap.G_TILLED ? T_CANT_PLACE : T_NEEDS_TILLED);
            return;
        }
        int type = seed == Items.SEED_POTATO ? 1 : 0;
        editObj(tx, ty, Obj.CROP, type << 2);
        Crop c = new Crop();
        c.tx = tx;
        c.ty = ty;
        c.timer = PLANT_STAGE_SECONDS;
        crops.add(c);
        take(sv.inv[p.id], slot);
        out.sound(Sounds.PLANT, (tx + 0.5f) * TILE, (ty + 0.5f) * TILE, 1f, 0f);
    }

    // ------------------------------------------------------------------ fishing

    private void useRod(Player p) {
        int id = p.id;
        int state = sv.fishState[id];
        if (state == 2) {                                   // a fish is biting: reel it in
            catchFish(p);
            return;
        }
        if (state == 1) {                                   // reel in an empty line
            cancelFishing(p);
            return;
        }
        // cast: the first water tile along the aim, within seven tiles
        for (float d = 48f; d <= 7f * TILE; d += 16f) {
            float x = p.x + (float) Math.cos(p.aim) * d;
            float y = p.y + (float) Math.sin(p.aim) * d;
            int tx = SurvivalTerrain.tileOf(x), ty = SurvivalTerrain.tileOf(y);
            if (sv.terrain.groundAt(tx, ty) == TileMap.G_WATER) {
                sv.fishState[id] = 1;
                sv.fishX[id] = (tx + 0.5f) * TILE;
                sv.fishY[id] = (ty + 0.5f) * TILE;
                fishT[id] = 3f + rng.nextFloat() * 7f;
                out.sound(Sounds.FISH_CAST, sv.fishX[id], sv.fishY[id], 1f, 0f);
                return;
            }
            if (sv.terrain.isSolid(tx, ty) && sv.terrain.groundAt(tx, ty) != TileMap.G_WATER) break;
        }
        toast(p, T_AIM_WATER);
    }

    private void stepFishing(Player p, float dt) {
        int id = p.id;
        if (sv.fishState[id] == 0) return;
        if (sv.inv[id].selectedItem() != Items.ROD || dist2(p.x, p.y, sv.fishX[id], sv.fishY[id]) > 9f * TILE * 9f * TILE) {
            cancelFishing(p);
            return;
        }
        fishT[id] -= dt;
        if (fishT[id] > 0f) return;
        if (sv.fishState[id] == 1) {
            sv.fishState[id] = 2;                           // a bite: a short moment to pull
            fishT[id] = 1.3f;
            out.sound(Sounds.FISH_BITE, sv.fishX[id], sv.fishY[id], 1f, 0f);
        } else {
            sv.fishState[id] = 0;                           // too slow
            out.toast(id, T_GOT_AWAY);
        }
    }

    private void catchFish(Player p) {
        int id = p.id;
        sv.fishState[id] = 0;
        int roll = rng.nextInt(100);
        if (roll < 78) giveOrDrop(p, Items.FISH_RAW, 1);
        else if (roll < 90) giveOrDrop(p, Items.FISH_RAW, 2);
        else if (roll < 95) giveOrDrop(p, Items.SCRAP, 1 + rng.nextInt(2));
        else if (roll < 98) giveOrDrop(p, Items.CLOTH, 1);
        else giveOrDrop(p, Items.NAILS, 2 + rng.nextInt(3));
        out.sound(Sounds.FISH_CATCH, p.x, p.y, 1f, 0f);
    }

    private void cancelFishing(Player p) {
        sv.fishState[p.id] = 0;
    }

    // ------------------------------------------------------------------ items on the ground and in the pack

    private void giveOrDrop(Player p, int item, int count) {
        int left = sv.inv[p.id].add(item, count);
        if (left > 0) {
            dropItem(item, left, p.x, p.y);
            toast(p, T_PACK_FULL);
        }
    }

    public void dropItem(int item, int count, float x, float y) {
        if (count <= 0) return;
        Drop d = freeDrop();
        if (d == null) return;
        d.active = true;
        d.id = newId();
        float ang = rng.nextFloat() * MathUtil.TWO_PI;
        float r = 6f + rng.nextFloat() * 16f;
        d.x = x + (float) Math.cos(ang) * r;
        d.y = y + (float) Math.sin(ang) * r;
        // never inside a wall
        int tx = SurvivalTerrain.tileOf(d.x), ty = SurvivalTerrain.tileOf(d.y);
        if (sv.terrain.isSolid(tx, ty)) {
            d.x = x;
            d.y = y;
        }
        d.item = item;
        d.count = count;
        d.ttl = 600f;
    }

    private void stepDrops(float dt) {
        for (Drop d : sv.drops) {
            if (!d.active) continue;
            d.ttl -= dt;
            if (d.ttl <= 0f) d.active = false;
        }
    }

    private void editObj(int tx, int ty, byte obj, int meta) {
        sv.terrain.setObj(tx, ty, obj, meta);
        out.edit(tx, ty, 0, obj, meta);
    }

    private void editGround(int tx, int ty, byte g) {
        sv.terrain.setGround(tx, ty, g);
        out.edit(tx, ty, 1, g, 0);
    }

    // ------------------------------------------------------------------ the Pick Up button

    public void interact(Player p) {
        if (!p.alive) return;
        if (!inter.find(sv, p)) return;
        Inventory inv = sv.inv[p.id];
        switch (inter.kind) {
            case Interaction.DROP: {
                Drop d = sv.dropById(inter.id);
                if (d == null) return;
                int left = inv.add(d.item, d.count);
                if (left >= d.count) {
                    toast(p, T_PACK_FULL);
                    return;
                }
                if (left == 0) d.active = false;
                else d.count = left;
                out.sound(Sounds.PICKUP, p.x, p.y, 0.9f, 0f);
                break;
            }
            case Interaction.CONTAINER:
                search(p, inter.tx, inter.ty);
                break;
            case Interaction.DOOR: {
                int meta = sv.terrain.metaAt(inter.tx, inter.ty);
                editObj(inter.tx, inter.ty, Obj.DOOR, meta ^ 1);
                out.sound(Sounds.DOOR, (inter.tx + 0.5f) * TILE, (inter.ty + 0.5f) * TILE, 1f, 0f);
                break;
            }
            case Interaction.CROP:
                harvestCrop(p, inter.tx, inter.ty);
                break;
            case Interaction.BUSH: {
                giveOrDrop(p, Items.BERRIES, 2 + rng.nextInt(3));
                if (rng.nextInt(100) < 40) giveOrDrop(p, Items.FIBER, 1);
                editObj(inter.tx, inter.ty, Obj.NONE, 0);
                out.sound(Sounds.HARVEST, p.x, p.y, 1f, 0f);
                break;
            }
            case Interaction.CAR:
                useCar(p, sv.carById(inter.id));
                break;
            default:
                break;
        }
    }

    private void search(Player p, int tx, int ty) {
        byte o = sv.terrain.objAt(tx, ty);
        int meta = sv.terrain.metaAt(tx, ty);
        if (!Obj.container(o) || (meta & Obj.SEARCHED) != 0) return;
        editObj(tx, ty, o, meta | Obj.SEARCHED);
        int n = LootTable.roll(o, SurvivalGen.buildingOf(meta), rng, lootItems, lootCounts);
        out.sound(Sounds.SEARCH, (tx + 0.5f) * TILE, (ty + 0.5f) * TILE, 1f, 0f);
        if (n == 0) {
            toast(p, T_NOTHING);
            return;
        }
        for (int i = 0; i < n; i++) giveOrDrop(p, lootItems[i], lootCounts[i]);
    }

    private void harvestCrop(Player p, int tx, int ty) {
        int meta = sv.terrain.metaAt(tx, ty);
        if ((meta & 3) != 3) return;
        boolean potato = ((meta >> 2) & 3) == 1;
        giveOrDrop(p, potato ? Items.POTATO : Items.CARROT, 2 + rng.nextInt(potato ? 3 : 2));
        if (rng.nextInt(100) < 75) giveOrDrop(p, potato ? Items.SEED_POTATO : Items.SEED_CARROT, 1 + rng.nextInt(2));
        editObj(tx, ty, Obj.NONE, 0);
        out.sound(Sounds.HARVEST, p.x, p.y, 1f, 0f);
    }

    // ------------------------------------------------------------------ cars

    private void useCar(Player p, Car c) {
        if (c == null) return;
        Inventory inv = sv.inv[p.id];
        if (sv.drivingCar[p.id] == c.id) {
            leaveCar(p, true);
            return;
        }
        String need = Interaction.carNeed(c, inv);
        if (need != null && need.startsWith("fit:")) {          // a part to fit: that comes first
            String part = need.substring(4);
            if (part.equals("Tyre")) {
                inv.remove(Items.TIRE, 1);
                c.tyresOk = true;
            } else if (part.equals("Battery")) {
                inv.remove(Items.BATTERY, 1);
                c.batteryOk = true;
            } else if (part.equals("Engine")) {
                inv.remove(Items.ENGINE, 1);
                c.engineOk = true;
                c.hp = Math.max(c.hp, 60);
            } else {
                inv.remove(Items.GAS_CAN, 1);
                c.fuel = Math.min(100, c.fuel + 55);
            }
            out.sound(Sounds.REPAIR, c.x, c.y, 1f, 0f);
            return;
        }
        if (c.driver >= 0) return;
        c.driver = p.id;
        sv.drivingCar[p.id] = c.id;
        p.dodgeRequest = false;
        cancelFishing(p);
        if (c.ready()) {
            c.running = true;
            out.sound(Sounds.ENGINE_START, c.x, c.y, 1f, 0f);
            noise(c.x, c.y, 900f);
        } else {
            out.sound(Sounds.ENGINE_FAIL, c.x, c.y, 1f, 0f);
            toastCar(p, c, need);
        }
    }

    private void toastCar(Player p, Car c, String need) {
        int code = T_CAR_DEAD;
        if (need != null) {
            if (need.contains("tyre")) code = T_NEEDS_TYRE;
            else if (need.contains("battery")) code = T_NEEDS_BATTERY;
            else if (need.contains("wrench")) code = T_NEEDS_WRENCH;
            else if (need.contains("engine")) code = T_NEEDS_ENGINE;
            else if (need.contains("fuel")) code = T_NEEDS_FUEL;
        } else if (c.fuel <= 0) {
            code = T_NEEDS_FUEL;
        }
        toast(p, code);
    }

    private void leaveCar(Player p, boolean placeNearby) {
        int id = sv.drivingCar[p.id];
        if (id < 0) return;
        Car c = sv.carById(id);
        sv.drivingCar[p.id] = -1;
        if (c == null) return;
        c.driver = -1;
        c.running = false;
        if (!placeNearby) return;
        float side = c.heading + MathUtil.PI * 0.5f;
        float[][] spots = {{(float) Math.cos(side), (float) Math.sin(side)}, {-(float) Math.cos(side), -(float) Math.sin(side)},
                {-(float) Math.cos(c.heading), -(float) Math.sin(c.heading)}, {(float) Math.cos(c.heading), (float) Math.sin(c.heading)}};
        for (float[] s : spots) {
            float x = c.x + s[0] * 38f, y = c.y + s[1] * 38f;
            if (!sv.terrain.isSolid(SurvivalTerrain.tileOf(x), SurvivalTerrain.tileOf(y))) {
                col.pushOut(x, y, GameConfig.PLAYER_RADIUS);
                p.x = col.resX;
                p.y = col.resY;
                return;
            }
        }
        p.x = c.x;
        p.y = c.y;
    }

    /** True while the survivor sits in a car (the world moves them with the car instead of by walking). */
    public boolean isDriving(Player p) {
        return sv.drivingCar[p.id] >= 0;
    }

    private float engineT;

    private void stepCars(float dt) {
        engineT -= dt;
        boolean tick = engineT <= 0f;
        if (tick) engineT = 0.3f;
        for (Car c : sv.cars) {
            if (!c.active) continue;
            Player d = c.driver >= 0 ? st.players[c.driver] : null;
            if (d != null && (!d.connected || !d.alive)) {
                if (d.connected) sv.drivingCar[d.id] = -1;
                c.driver = -1;
                c.running = false;
                d = null;
            }
            if (d == null && Math.abs(c.speed) < 0.5f) {
                c.speed = 0f;
                pushOutOfCar(c);
                continue;
            }
            float mag = 0f, mx = 0f, my = 0f;
            if (d != null && c.running) {
                mx = d.moveX;
                my = d.moveY;
                mag = Math.min(1f, (float) Math.sqrt(mx * mx + my * my));
            }
            if (c.running && c.fuel > 0 && mag > 0.15f) {
                float target = (float) Math.atan2(my, mx);
                float diff = MathUtil.angleDiff(c.heading, target);          // how far the stick points from where the car faces
                boolean back = Math.abs(diff) > 2.1f && c.speed < 45f;
                float accel;
                if (back) {
                    diff = MathUtil.angleDiff(c.heading, target + MathUtil.PI);
                    accel = -150f * mag;
                } else {
                    accel = 215f * mag * (Math.abs(diff) < 1.9f ? 1f : 0.25f);
                }
                float turn = 2.9f * MathUtil.clamp(Math.abs(c.speed) / 60f, 0.18f, 1f);
                c.heading = MathUtil.wrapAngle(c.heading + MathUtil.clamp(diff, -turn * dt, turn * dt));
                c.speed += accel * dt;
            } else if (c.speed != 0f) {
                float k = Math.min(Math.abs(c.speed), 130f * dt);
                c.speed -= Math.signum(c.speed) * k;
            }
            c.speed = MathUtil.clamp(c.speed, -95f, Car.MAX_SPEED);
            if (c.running) {
                c.fuel = Math.max(0, c.fuel);
                float burn = dt * (0.035f + 0.03f * Math.abs(c.speed) / Car.MAX_SPEED);
                fuelFrac += burn;
                if (fuelFrac >= 1f) {
                    fuelFrac -= 1f;
                    c.fuel--;
                    if (c.fuel <= 0) {
                        c.running = false;
                        out.sound(Sounds.ENGINE_FAIL, c.x, c.y, 1f, 0f);
                    }
                }
                if (tick) {
                    out.sound(Sounds.ENGINE_LOOP, c.x, c.y, 0.6f, 0.75f + 1.1f * Math.abs(c.speed) / Car.MAX_SPEED);
                    if (c.driver >= 0 && Math.abs(c.speed) > 40f) noise(c.x, c.y, 650f);
                }
            }
            float dx = (float) Math.cos(c.heading) * c.speed * dt;
            float dy = (float) Math.sin(c.heading) * c.speed * dt;
            col.moveCircle(c.x, c.y, dx, dy, Car.RADIUS);
            float rx = col.resX - (c.x + dx), ry = col.resY - (c.y + dy);
            boolean crashed = rx * rx + ry * ry > 0.25f * (dx * dx + dy * dy) + 0.5f;
            c.x = col.resX;
            c.y = col.resY;
            if (crashed && Math.abs(c.speed) > 40f) {
                if (Math.abs(c.speed) > 90f) {
                    out.sound(Sounds.CAR_HIT, c.x, c.y, 1f, 0f);
                    c.hp -= (int) (Math.abs(c.speed) / 22f);
                    if (c.hp <= 0) {
                        c.hp = 0;
                        c.engineOk = false;
                        c.running = false;
                    }
                }
                c.speed *= 0.3f;
            }
            // run things over
            if (Math.abs(c.speed) > 70f) hitThings(c, d);
            if (d != null) {
                d.x = c.x;
                d.y = c.y;
                d.rx = c.x;
                d.ry = c.y;
                d.aim = c.heading;
            }
            pushOutOfCar(c);
        }
    }

    private float fuelFrac;

    private void hitThings(Car c, Player driver) {
        float reach = Car.RADIUS + Zombie.RADIUS;
        for (Zombie z : sv.zombies) {
            if (!z.active || dist2(z.x, z.y, c.x, c.y) > reach * reach) continue;
            out.sound(Sounds.CAR_HIT, z.x, z.y, 0.8f, 0f);
            hitZombie(z, (int) (Math.abs(c.speed) * 0.6f), driver == null ? -1 : driver.id, c.heading, 24f);
            c.speed *= 0.9f;
            c.hp = Math.max(0, c.hp - 1);
        }
        for (Player q : st.players) {
            if (!q.connected || !q.alive || q == driver || sv.drivingCar[q.id] >= 0) continue;
            float lim = Car.RADIUS + GameConfig.PLAYER_RADIUS;
            if (dist2(q.x, q.y, c.x, c.y) < lim * lim && Math.abs(c.speed) > 110f) {
                world.hurt(q.id, (int) (Math.abs(c.speed) / 9f), driver == null ? -1 : driver.id, GameConfig.CAUSE_CAR, q.x, q.y);
                c.speed *= 0.8f;
            }
        }
    }

    /** Cars are solid for people and zombies on foot. */
    private void pushOutOfCar(Car c) {
        for (Player q : st.players) {
            if (!q.connected || !q.alive || sv.drivingCar[q.id] >= 0) continue;
            float lim = Car.RADIUS + GameConfig.PLAYER_RADIUS;
            float dx = q.x - c.x, dy = q.y - c.y;
            float d2 = dx * dx + dy * dy;
            if (d2 < lim * lim && d2 > 0.01f) {
                float d = (float) Math.sqrt(d2);
                col.moveCircle(q.x, q.y, dx / d * (lim - d), dy / d * (lim - d), GameConfig.PLAYER_RADIUS);
                q.x = col.resX;
                q.y = col.resY;
            }
        }
        for (Zombie z : sv.zombies) {
            if (!z.active) continue;
            float lim = Car.RADIUS + Zombie.RADIUS;
            float dx = z.x - c.x, dy = z.y - c.y;
            float d2 = dx * dx + dy * dy;
            if (d2 < lim * lim && d2 > 0.01f) {
                float d = (float) Math.sqrt(d2);
                z.x += dx / d * (lim - d);
                z.y += dy / d * (lim - d);
            }
        }
    }

    // ------------------------------------------------------------------ crops

    private void stepCrops(float dt) {
        for (int i = crops.size() - 1; i >= 0; i--) {
            Crop c = crops.get(i);
            if (sv.terrain.objAt(c.tx, c.ty) != Obj.CROP) {
                crops.remove(i);
                continue;
            }
            c.timer -= dt;
            if (c.timer > 0f) continue;
            int meta = sv.terrain.metaAt(c.tx, c.ty);
            int stage = meta & 3;
            if (stage >= 3) {
                crops.remove(i);
                continue;
            }
            editObj(c.tx, c.ty, Obj.CROP, (meta & ~3) | (stage + 1));
            c.timer = PLANT_STAGE_SECONDS;
            if (stage + 1 >= 3) crops.remove(i);
        }
    }

    // ------------------------------------------------------------------ zombies

    private void stepSpawner(float dt) {
        spawnT -= dt;
        if (spawnT > 0f) return;
        spawnT = 1.8f;
        int active = 0;
        for (Zombie z : sv.zombies) if (z.active) active++;
        if (active >= SurvivalState.MAX_ZOMBIES - 2) return;
        boolean night = sv.isNight();
        for (Player p : st.players) {
            if (!p.connected || !p.alive) continue;
            int near = 0;
            for (Zombie z : sv.zombies) if (z.active && dist2(z.x, z.y, p.x, p.y) < 1000f * 1000f) near++;
            int want = night ? 14 : 5;
            if (sv.terrain.gen.inTown(SurvivalTerrain.tileOf(p.x), SurvivalTerrain.tileOf(p.y))) want += 3;
            if (near >= want) continue;
            for (int tries = 0; tries < 8; tries++) {
                float ang = rng.nextFloat() * MathUtil.TWO_PI;
                float r = 760f + rng.nextFloat() * 260f;
                float x = p.x + (float) Math.cos(ang) * r;
                float y = p.y + (float) Math.sin(ang) * r;
                if (sv.terrain.walkable(SurvivalTerrain.tileOf(x), SurvivalTerrain.tileOf(y))) {
                    Zombie z = spawnZombie(x, y);
                    if (z != null) {
                        // drawn to the survivor, like a horde that heard something: it shambles their way
                        z.hasWander = true;
                        z.wanderX = p.x + (rng.nextFloat() - 0.5f) * 240f;
                        z.wanderY = p.y + (rng.nextFloat() - 0.5f) * 240f;
                        z.wanderT = 45f;
                        z.alertT = 45f;
                    }
                    break;
                }
            }
        }
    }

    private boolean sees(Zombie z, Player p) {
        return col.raycast(z.x, z.y, p.x, p.y) < 0f;
    }

    private void stepZombies(float dt) {
        boolean night = sv.isNight();
        float sight = night ? 300f : 460f;
        for (Zombie z : sv.zombies) {
            if (!z.active) continue;
            if (z.hurt > 0f) z.hurt -= dt;
            if (z.attackCd > 0f) z.attackCd -= dt;
            z.groanT -= dt;
            Player best = null;
            float bd = Float.MAX_VALUE;
            for (Player p : st.players) {
                if (!p.connected || !p.alive) continue;
                float d2 = dist2(z.x, z.y, p.x, p.y);
                if (d2 < bd) {
                    bd = d2;
                    best = p;
                }
            }
            if (best == null || bd > 1500f * 1500f) {
                z.farT += dt;
                if (z.farT > 8f) {
                    z.active = false;
                    continue;
                }
            } else {
                z.farT = 0f;
            }
            z.attacking = false;
            if (z.stunT > 0f) {
                z.stunT -= dt;
                continue;
            }
            // choose what to go after
            if (best != null && bd < sight * sight && sees(z, best)) {
                z.target = best.id;
            } else if (z.target >= 0) {
                Player t = st.players[z.target];
                if (!t.connected || !t.alive || dist2(z.x, z.y, t.x, t.y) > sight * sight * 2.5f) z.target = -1;
            }
            if (z.groanT <= 0f) {
                z.groanT = z.target >= 0 ? 3f + rng.nextFloat() * 4f : 7f + rng.nextFloat() * 10f;
                if (best != null && bd < 900f * 900f) out.sound(Sounds.ZOMBIE_GROAN + rng.nextInt(Sounds.ZOMBIE_GROANS), z.x, z.y, 0.9f, 0f);
            }
            float speed = Zombie.speed(z.type) * (night ? 1.15f : 1f);
            if (z.target >= 0) {
                Player t = st.players[z.target];
                float dx = t.x - z.x, dy = t.y - z.y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                float reach = Zombie.RADIUS + GameConfig.PLAYER_RADIUS + 8f;
                if (dist <= reach) {
                    z.aim = MathUtil.rotateToward(z.aim, (float) Math.atan2(dy, dx), 9f * dt);
                    z.attacking = true;
                    if (z.attackCd <= 0f) {
                        z.attackCd = z.type == Zombie.RUNNER ? 0.8f : 1.15f;
                        out.sound(Sounds.ZOMBIE_ATTACK, z.x, z.y, 0.9f, 0f);
                        int carId = sv.drivingCar[t.id];
                        if (carId >= 0) {
                            Car c = sv.carById(carId);
                            if (c != null) c.hp = Math.max(0, c.hp - 2);
                        } else {
                            world.hurt(t.id, Zombie.damage(z.type), -1, GameConfig.CAUSE_ZOMBIE, t.x, t.y);
                        }
                    }
                } else {
                    moveZombie(z, dx / dist, dy / dist, speed, dt, true);
                }
            } else {
                z.alertT -= dt;
                z.wanderT -= dt;
                if (z.hasWander) {
                    float dx = z.wanderX - z.x, dy = z.wanderY - z.y;
                    float dist = (float) Math.sqrt(dx * dx + dy * dy);
                    if (dist < 26f || z.wanderT <= 0f) {
                        z.hasWander = false;
                        z.wanderT = 2f + rng.nextFloat() * 5f;
                    } else {
                        moveZombie(z, dx / dist, dy / dist, speed * (z.alertT > 0f ? 0.8f : 0.45f), dt, false);
                    }
                } else if (z.wanderT <= 0f) {
                    float ang = rng.nextFloat() * MathUtil.TWO_PI;
                    float r = 80f + rng.nextFloat() * 180f;
                    z.wanderX = z.x + (float) Math.cos(ang) * r;
                    z.wanderY = z.y + (float) Math.sin(ang) * r;
                    z.hasWander = true;
                    z.wanderT = 6f;
                }
            }
        }
        // zombies do not stack on top of each other
        for (int i = 0; i < sv.zombies.length; i++) {
            Zombie a = sv.zombies[i];
            if (!a.active) continue;
            for (int j = i + 1; j < sv.zombies.length; j++) {
                Zombie b = sv.zombies[j];
                if (!b.active) continue;
                float dx = b.x - a.x, dy = b.y - a.y;
                float d2 = dx * dx + dy * dy;
                float lim = Zombie.RADIUS * 1.8f;
                if (d2 < lim * lim && d2 > 0.01f) {
                    float d = (float) Math.sqrt(d2);
                    float push = (lim - d) * 0.5f;
                    a.x -= dx / d * push;
                    a.y -= dy / d * push;
                    b.x += dx / d * push;
                    b.y += dy / d * push;
                }
            }
        }
    }

    private void moveZombie(Zombie z, float dx, float dy, float speed, float dt, boolean chasing) {
        float step = speed * dt;
        // Stuck behind something: sidestep to one side (a different side for each zombie), then try straight again.
        float ang = (float) Math.atan2(dy, dx);
        if (z.stuckT > 0.35f) ang += (z.id & 1) == 0 ? 1.1f : -1.1f;
        float mx = (float) Math.cos(ang), my = (float) Math.sin(ang);
        col.moveCircle(z.x, z.y, mx * step, my * step, Zombie.RADIUS);
        float moved = (float) Math.sqrt(dist2(col.resX, col.resY, z.x, z.y));
        z.x = col.resX;
        z.y = col.resY;
        z.aim = MathUtil.rotateToward(z.aim, (float) Math.atan2(my, mx), 7f * dt);
        z.walk += moved * 0.08f;
        if (moved < step * 0.35f) {
            z.stuckT += dt;
            if (chasing && z.stuckT > 0.6f && z.attackCd <= 0f) {
                // a built wall or a door in the way: tear at it
                int tx = SurvivalTerrain.tileOf(z.x + dx * (Zombie.RADIUS + 10f));
                int ty = SurvivalTerrain.tileOf(z.y + dy * (Zombie.RADIUS + 10f));
                byte o = sv.terrain.objAt(tx, ty);
                if ((o == Obj.WALL || (o == Obj.DOOR && (sv.terrain.metaAt(tx, ty) & 1) == 0)) && damageStructure(tx, ty, z.type == Zombie.BRUTE ? 16 : 7)) {
                    z.attacking = true;
                    z.attackCd = 1f;
                    out.sound(Sounds.ZOMBIE_ATTACK, z.x, z.y, 0.7f, 0f);
                }
            }
        } else {
            z.stuckT = Math.max(0f, z.stuckT - dt * 2f);
        }
    }

    /** Hurts a built wall or a door; false when it cannot be damaged (a wall of a ruined house). */
    private boolean damageStructure(int tx, int ty, int dmg) {
        byte o = sv.terrain.objAt(tx, ty);
        int meta = sv.terrain.metaAt(tx, ty);
        float cx = (tx + 0.5f) * TILE, cy = (ty + 0.5f) * TILE;
        if (o == Obj.WALL) {
            if (meta == Obj.UNBREAKABLE_WALL) return false;
            int hp = meta * 4 - dmg;
            if (hp <= 0) {
                editObj(tx, ty, Obj.NONE, 0);
                out.sound(Sounds.BREAK, cx, cy, 1f, 0f);
            } else {
                editObj(tx, ty, Obj.WALL, hp / 4);
            }
            return true;
        }
        if (o == Obj.DOOR) {
            int hp8 = (meta >> 1) - (int) Math.ceil(dmg / 8f);
            if (hp8 <= 0) {
                editObj(tx, ty, Obj.NONE, 0);
                out.sound(Sounds.BREAK, cx, cy, 1f, 0f);
            } else {
                editObj(tx, ty, Obj.DOOR, (hp8 << 1) | (meta & 1));
            }
            return true;
        }
        return false;
    }

    private void hitZombie(Zombie z, int dmg, int attacker, float dirAngle, float knock) {
        z.hp -= dmg;
        z.hurt = 0.18f;
        z.stunT = Math.max(z.stunT, z.type == Zombie.BRUTE ? 0.08f : 0.2f);
        if (attacker >= 0 && z.target < 0) z.target = attacker;
        if (knock > 0f) {
            col.moveCircle(z.x, z.y, (float) Math.cos(dirAngle) * knock, (float) Math.sin(dirAngle) * knock, Zombie.RADIUS);
            z.x = col.resX;
            z.y = col.resY;
        }
        if (z.hp <= 0) killZombie(z, attacker);
    }

    private void killZombie(Zombie z, int attacker) {
        z.active = false;
        out.sound(Sounds.ZOMBIE_DEATH, z.x, z.y, 1f, 0f);
        if (attacker >= 0 && attacker < st.players.length) st.players[attacker].kills++;
        int roll = rng.nextInt(100);
        if (roll < 12) dropItem(Items.CLOTH, 1 + rng.nextInt(2), z.x, z.y);
        else if (roll < 20) dropItem(Items.CANNED, 1, z.x, z.y);
        else if (roll < 26) dropItem(Items.BANDAGE, 1, z.x, z.y);
        else if (roll < 30) dropItem(Items.SCRAP, 1 + rng.nextInt(2), z.x, z.y);
        else if (roll < 32) dropItem(Items.AMMO_BULLETS, 3 + rng.nextInt(6), z.x, z.y);
    }

    /** A bullet in flight: true when it hit a zombie (the bullet is spent). */
    public boolean projectileHitsZombie(Projectile b) {
        Zombie hit = null;
        float bestT = 2f;
        for (Zombie z : sv.zombies) {
            if (!z.active) continue;
            float t = CollisionSystem.segmentCircle(b.px, b.py, b.x, b.y, z.x, z.y, Zombie.RADIUS + b.radius);
            if (t >= 0f && t < bestT) {
                bestT = t;
                hit = z;
            }
        }
        if (hit == null) return false;
        out.sound(Sounds.MELEE_HIT, hit.x, hit.y, 0.8f, 0f);
        hitZombie(hit, b.damage, b.owner, (float) Math.atan2(b.vy, b.vx), 5f);
        return true;
    }

    /** A melee blow has landed: it hurts zombies in the arc and, if there are none, works on what is in front (chop, mine, break). */
    public void meleeSwing(Player p, WeaponDef d) {
        int hits = 0;
        for (Zombie z : sv.zombies) {
            if (!z.active || hits >= 3) continue;
            float dx = z.x - p.x, dy = z.y - p.y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist > d.reach + Zombie.RADIUS) continue;
            if (dist > GameConfig.PLAYER_RADIUS * 1.2f) {
                float diff = Math.abs(MathUtil.angleDiff((float) Math.atan2(dy, dx), p.aim));
                float slack = (float) Math.atan2(Zombie.RADIUS, Math.max(1f, dist));
                if (diff > d.arc + slack) continue;
            }
            if (dist > 1f && col.raycast(p.x, p.y, z.x, z.y) >= 0f) continue;
            hits++;
            out.sound(Sounds.MELEE_HIT, z.x, z.y, 0.9f, 0f);
            hitZombie(z, d.damage, p.id, (float) Math.atan2(dy, dx), d.damage > 40 ? 16f : 9f);
        }
        if (hits > 0) return;
        // what is in front
        float[] reach = {GameConfig.PLAYER_RADIUS + 6f, GameConfig.PLAYER_RADIUS + d.reach * 0.55f, GameConfig.PLAYER_RADIUS + d.reach * 0.9f};
        for (float r : reach) {
            int tx = SurvivalTerrain.tileOf(p.x + (float) Math.cos(p.aim) * r);
            int ty = SurvivalTerrain.tileOf(p.y + (float) Math.sin(p.aim) * r);
            if (workOn(p, d, tx, ty)) return;
        }
    }

    private boolean workOn(Player p, WeaponDef d, int tx, int ty) {
        byte o = sv.terrain.objAt(tx, ty);
        int meta = sv.terrain.metaAt(tx, ty);
        float cx = (tx + 0.5f) * TILE, cy = (ty + 0.5f) * TILE;
        switch (o) {
            case Obj.TREE: {
                meta += d.toolKind == WeaponDef.TOOL_AXE ? 3 : 1;
                out.sound(Sounds.CHOP, cx, cy, 1f, 0f);
                if (meta >= TREE_HP) {
                    giveOrDrop(p, Items.WOOD, 3 + rng.nextInt(3));
                    if (rng.nextInt(100) < 40) giveOrDrop(p, Items.FIBER, 1 + rng.nextInt(2));
                    editObj(tx, ty, Obj.STUMP, 0);
                } else {
                    sv.terrain.setMeta(tx, ty, meta);
                }
                return true;
            }
            case Obj.ROCK: {
                if (d.toolKind != WeaponDef.TOOL_PICK) {
                    toast(p, T_NEEDS_PICK);
                    out.sound(Sounds.MINE, cx, cy, 0.5f, 0f);
                    return true;
                }
                meta += 3;
                out.sound(Sounds.MINE, cx, cy, 1f, 0f);
                if (meta >= ROCK_HP) {
                    giveOrDrop(p, Items.STONE, 3 + rng.nextInt(3));
                    if (rng.nextInt(100) < 30) giveOrDrop(p, Items.SCRAP, 1 + rng.nextInt(2));
                    editObj(tx, ty, Obj.NONE, 0);
                } else {
                    sv.terrain.setMeta(tx, ty, meta);
                }
                return true;
            }
            case Obj.WALL:
            case Obj.DOOR:
                if (o == Obj.DOOR && (meta & 1) != 0) return false;           // an open door is not in the way
                if (damageStructure(tx, ty, d.damage)) {
                    out.sound(Sounds.CHOP, cx, cy, 0.8f, 0f);
                    if (sv.terrain.objAt(tx, ty) == Obj.NONE && rng.nextInt(100) < 60) giveOrDrop(p, Items.WOOD, 1);
                } else {
                    out.sound(Sounds.MINE, cx, cy, 0.4f, 0f);
                }
                return true;
            default:
                return false;
        }
    }
}
