package com.hazardyard.game.survival;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.Terrain;
import com.hazardyard.game.core.TileMap;

import java.util.HashMap;

/**
 * The endless survival world as the collision system and the renderer see it: chunks are generated the moment somebody
 * looks at them (see {@link SurvivalGen}) and kept, so whatever players build or break stays. Not thread-safe; it is only
 * used from the game thread.
 */
public final class SurvivalTerrain implements Terrain {
    /** Told when a chunk has just been generated (the host fills it with zombies and cars). */
    public interface Listener {
        void chunkCreated(Chunk c);
    }

    public final SurvivalGen gen;
    public final int seed;
    private final HashMap<Long, Chunk> chunks = new HashMap<>();
    private Chunk cache;
    public Listener listener;

    public SurvivalTerrain(int seed) {
        this.seed = seed;
        this.gen = new SurvivalGen(seed);
    }

    private static long key(int cx, int cy) {
        return ((long) cx << 32) ^ (cy & 0xFFFFFFFFL);
    }

    public Chunk chunk(int cx, int cy) {
        Chunk c = cache;
        if (c != null && c.cx == cx && c.cy == cy) return c;
        long k = key(cx, cy);
        c = chunks.get(k);
        if (c == null) {
            c = new Chunk(cx, cy);
            gen.generate(c);
            chunks.put(k, c);
            cache = c;
            if (listener != null) listener.chunkCreated(c);
        }
        cache = c;
        return c;
    }

    public Chunk chunkOfTile(int tx, int ty) {
        return chunk(Math.floorDiv(tx, Chunk.SIZE), Math.floorDiv(ty, Chunk.SIZE));
    }

    public int loadedChunks() {
        return chunks.size();
    }

    private static int local(int t) {
        return Math.floorMod(t, Chunk.SIZE);
    }

    public byte groundAt(int tx, int ty) {
        return chunkOfTile(tx, ty).ground[Chunk.index(local(tx), local(ty))];
    }

    public byte objAt(int tx, int ty) {
        return chunkOfTile(tx, ty).obj[Chunk.index(local(tx), local(ty))];
    }

    public int metaAt(int tx, int ty) {
        return chunkOfTile(tx, ty).meta[Chunk.index(local(tx), local(ty))] & 0xFF;
    }

    public void setObj(int tx, int ty, byte obj, int meta) {
        Chunk c = chunkOfTile(tx, ty);
        int i = Chunk.index(local(tx), local(ty));
        c.obj[i] = obj;
        c.meta[i] = (byte) meta;
        c.edited = true;
    }

    public void setMeta(int tx, int ty, int meta) {
        Chunk c = chunkOfTile(tx, ty);
        c.meta[Chunk.index(local(tx), local(ty))] = (byte) meta;
        c.edited = true;
    }

    public void setGround(int tx, int ty, byte g) {
        Chunk c = chunkOfTile(tx, ty);
        c.ground[Chunk.index(local(tx), local(ty))] = g;
        c.edited = true;
    }

    public static int tileOf(float world) {
        return (int) Math.floor(world / GameConfig.TILE);
    }

    // ------------------------------------------------------------------ Terrain

    @Override
    public byte kindAt(int tx, int ty) {
        Chunk c = chunkOfTile(tx, ty);
        int i = Chunk.index(local(tx), local(ty));
        if (c.ground[i] == TileMap.G_WATER) return TileMap.WATER;
        return Obj.collisionKind(c.obj[i], c.meta[i] & 0xFF);
    }

    @Override
    public boolean isSolid(int tx, int ty) {
        return kindAt(tx, ty) != TileMap.FLOOR;
    }

    @Override
    public boolean blocksShotsFully(int tx, int ty) {
        byte k = kindAt(tx, ty);
        return k == TileMap.WALL || k == TileMap.CRATE;
    }

    @Override
    public boolean blocksShotsPartly(int tx, int ty) {
        byte k = kindAt(tx, ty);
        return k == TileMap.TREE || k == TileMap.ROCK;
    }

    @Override
    public int fenceArms(int tx, int ty) {
        return 0;
    }

    @Override
    public boolean roundAt(int tx, int ty, float[] out) {
        byte k = kindAt(tx, ty);
        if (k != TileMap.TREE && k != TileMap.ROCK) return false;
        out[0] = (tx + 0.5f) * GameConfig.TILE;
        out[1] = (ty + 0.5f) * GameConfig.TILE;
        out[2] = k == TileMap.TREE ? TileMap.TREE_RADIUS : TileMap.ROCK_RADIUS;
        return true;
    }

    /** True when a fighter can stand on the tile (nothing solid on it, and it is not water). */
    public boolean walkable(int tx, int ty) {
        return !isSolid(tx, ty);
    }
}
