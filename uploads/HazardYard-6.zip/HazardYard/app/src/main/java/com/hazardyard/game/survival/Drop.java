package com.hazardyard.game.survival;

/** An item (or a stack) lying on the ground. */
public final class Drop {
    public int id;
    /** Client: the snapshot this entity was last in (older ones are gone). */
    public int seen;
    public boolean active;
    public float x, y;
    public int item, count;
    /** Seconds until it rots away (host side). */
    public float ttl;
}
