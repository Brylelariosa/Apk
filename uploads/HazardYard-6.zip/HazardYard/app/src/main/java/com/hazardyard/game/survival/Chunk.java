package com.hazardyard.game.survival;

/** 16 x 16 tiles of the survival world: ground, object and meta byte for each. */
public final class Chunk {
    public static final int SIZE = 16;
    public final int cx, cy;
    public final byte[] ground = new byte[SIZE * SIZE];
    public final byte[] obj = new byte[SIZE * SIZE];
    public final byte[] meta = new byte[SIZE * SIZE];
    /** The host has put this chunk's zombies and cars into the world. */
    public boolean populated;
    /** Something was built or broken here (matters for saving). */
    public boolean edited;

    public Chunk(int cx, int cy) {
        this.cx = cx;
        this.cy = cy;
    }

    public static int index(int lx, int ly) {
        return ly * SIZE + lx;
    }
}
