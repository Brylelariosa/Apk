package com.hazardyard.game.core;

/**
 * What the collision system needs to know about the ground: which tiles are solid, what stops bullets, and where the
 * round obstacles (pillars, trunks, boulders) are. A {@link TileMap} is a fixed arena; the survival world is an endless
 * stream of generated chunks. Both answer in tile coordinates and treat everything unknown as they please (a fixed map
 * is walled in, the endless world has no edge).
 *
 * <p>{@link #kindAt} gives the kind of the tile as far as movement and shooting are concerned: FLOOR for everything a
 * fighter can walk through (open doors, crops, campfires, bushes), WALL, CRATE, WATER, FENCE and so on for what is in the way.
 */
public interface Terrain {
    byte kindAt(int tx, int ty);

    boolean isSolid(int tx, int ty);

    /** Walls and crates stop bullets over the whole tile. */
    boolean blocksShotsFully(int tx, int ty);

    /** Trees, boulders, pillars and angled pieces stop bullets only where their shape is. */
    boolean blocksShotsPartly(int tx, int ty);

    /** {@code TileMap.ARM_*} bits of the fence at this tile (0 when it is not a fence). */
    int fenceArms(int tx, int ty);

    /** For a round obstacle at this tile: writes its centre x, centre y and radius into {@code out} and returns true. */
    boolean roundAt(int tx, int ty, float[] out);
}
