# Hazard Yard

Top-down arena shooter for Android (pure framework code, no dependencies). Play solo against bots, or
2-4 players on the same Wi-Fi.

## What is new in 1.5
- **Battleground is a real battle royale now.** One life each, last fighter standing wins, and a safe zone that closes
  in seven steps (about 8 minutes in all; the last step shrinks it to a point). Outside the zone you take storm damage,
  more with every step; a warning, an arrow to the zone and the red edge of the screen tell you. After you are out the
  camera follows a fighter who is still alive, and the results show the places (#1 is the winner).
- **Armour and first-aid kits.** A light vest (50) and a heavy vest (100) absorb 60% of every bullet or blow until they are
  used up; a first-aid kit gives 50 health. They lie in the houses next to the guns, with an armour bar over the health bar.
- **A very big outdoor island** (192 x 192 tiles, 6144 x 6144 units, about four times the old Battleground): coast and
  beaches, meadows, forests with real trees, rocky ground with boulders, a river with bridges and two lakes, a harbour with a
  pier, a factory, farms with fenced fields, towns joined by roads, a military base with a fenced compound, and cabins,
  barns and sheds in between. **Every one of the 80+ buildings can be walked into**: walls, doors, rooms, furniture and loot
  inside, and a roof that hides the inside until you step through the door (it fades away while you are in). The island is
  generated from a fixed seed (`core/BattlegroundMap`), the same on every phone. Positions on the network now use 1/4-unit
  steps so maps up to 256 tiles across work (`GameConfig.POS_SCALE`).
- **Bots play the new rules**: they loot house to house, put on armour and use kits, run for the zone as it closes and fight
  harder as the circle shrinks.
- **Melee weapons**: knife, baseball bat, crowbar, machete, fire axe and pickaxe. A swing sweeps an arc in front of you
  (up to three targets) and lands a moment after it starts; the soldier really swings the weapon round his body. They lie around
  Battleground and are the weapons of survival.
- **Six more guns** (14 in all): revolver, double barrel, hunting rifle, AK rifle, marksman rifle, machine pistol.
- **Sound**: the assault rifle shot is exactly the one you liked (the file is byte for byte the old recipe); every other gun
  now has the same punchy character (a bright crack, a quick thump, a mid-range body, a short echo) with its own size and tail,
  so they sound like one set of guns. Reloads are new mechanical foley, no more bell-like rings: the magazine release and the
  magazine sliding out, the magazine seating, the slide or bolt; shotguns, the revolver, the LMG and the plasma rifle each have
  their own. Hits, hurt and death sounds are meatier. See `docs/gun-sounds.png`.
- **Survival mode (new)**: an endless, generated zombie-apocalypse world. See the section below.

## Survival mode
Pick *Survival* in the solo set-up, or in the host's lobby for up to four players on the same Wi-Fi (everybody gets the same
world from the host's seed). There are no bots and no time limit.
- **The world**: endless (about 30,000 tiles in every direction) and generated as you walk: lakes and seas, beaches, meadows,
  forests, rocky highlands, ruined towns (a grid of streets, houses, shops, garages, clinics and police stations with doors,
  rooms and furniture) and lonely cabins. Parked wrecks stand in the streets.
- **Zombies**: walkers, fast runners and tough brutes. They see you from 300-460 units, come to gunshots and engines, break
  walls and doors you build, and swarm at night (a full day is 8 minutes; the screen darkens, campfires and headlights glow).
- **Loot**: every cupboard, fridge, shelf, wardrobe, toolbox, crate and gun case can be searched once (the Pick Up button says
  what it will do); what is inside is random and depends on the furniture and the building: food, cloth, nails, scrap, tools,
  car parts, ammunition, bandages and first-aid kits, vests, and the 14 guns (police stations have the most).
- **Hunger and eating**: hunger drains slowly; starving hurts. Eat canned food, bread, apples, berries, crops and fish by
  selecting the item and pressing the aim stick (or *Use* in the bag). A fed survivor slowly heals.
- **Crafting**: the *BAG* button opens the pack (tap an item, then another slot to move it, *Use* / *Drop*) and the crafting
  list: walls, doors, floors, campfire, workbench, axe, pickaxe, hoe, fishing rod, knife, bat, bandages, cooked fish, seeds,
  nails, a vest, ammunition. Some recipes need a workbench or a campfire next to you.
- **Building**: select a wall, door, floor, campfire or workbench and aim at a free tile in front of you; zombies chew at walls
  and doors, you can break your own with a melee weapon (you get wood back), and doors open and close with Pick Up.
- **Chopping and mining**: hit trees with an axe (any melee weapon works, slowly) for wood and fibre; boulders need a pickaxe
  for stone and scrap.
- **Farming**: till grass with a hoe, plant seeds on the soil, wait (about 3.5 minutes) and harvest with Pick Up for food
  and new seeds. **Fishing**: with a rod, aim at water and press; when the float dips and the screen says *A fish!*, press
  again to reel it in.
- **Cars** (like Project Zomboid): most wrecks are missing a tyre, a battery, engine parts or fuel. Carry the part (the engine
  needs a wrench in the pack, fuel a gas can) and press Pick Up next to the car to fit it, then Pick Up again to get in. The
  left stick drives (it steers towards where you push it and pushes the gas), Pick Up gets you out. Cars run zombies over, burn
  fuel, can be wrecked, and the engine attracts zombies.
- **Death**: your pack drops where you fall and you come back after a few seconds with a knife, two bandages and a tin of food.
- The world is not saved when you leave (this is the first version of the mode).

![The new Battleground island](docs/battleground-map.png)
![Battleground in play: the zone timer, fighters left, armour and health, the minimap with the safe zone](docs/battleground-gameplay.png)
![Survival by day](docs/survival-day.png)
![Survival at night](docs/survival-night.png)
![The bag: the pack on the left, crafting on the right](docs/survival-bag.png)

## What was new in 1.4
- **Battleground**: a new game mode on a huge island map (120 x 80 tiles, about four times the area of the biggest
  classic arena): ruins and a watch tower, a walled hill, a factory with a tank farm, a village, an old town with a
  plaza, a depot of container lanes, a harbour with piers, a lake with an island, and farmland, joined by canals with
  bridges and open ends. Eight fighters per match; bots fill every slot the real players leave empty (1 human = 7
  bots, 2 humans = 6 bots, 4 humans = 4 bots) and never take a human's place. Pick the mode in the solo setup or in the
  host's lobby.
- **Guns sound and reload like themselves**: every gun has its own shot and its own three reload sounds (it starts, the
  ammunition goes in, it is ready), and pump, bolt and hammer guns have an action sound after each shot. Reload times
  differ per gun (pistol 1.0 s ... magnum 2.5 s ... light MG 3.3 s); the ammunition comes back at the moment the new
  magazine seats, and the shotgun loads shell by shell (3.5 s from empty). A fresh trigger pull cuts a reload short when
  a round is in the gun; dodging, picking up a weapon or dying cancels it; an empty gun reloads again after a roll.
  The soldier's arms work the gun differently for each reload.
- **Dodge sound**: one short cloth-and-footwork whoosh per roll, never doubled when the button is mashed.
- **Manual weapon pickup**: walking over a weapon does nothing. A round Pick Up button appears (with the gun's name and
  what it replaces) while a weapon is within reach; the pad glows and an arrow bounces over it. Pressing it swaps your
  gun for that one.
- **Smooth bots**: steering, aiming and targeting were rewritten (see `bot/BotBrain`); they no longer shake.
- **Customize HUD** now only moves and resizes things (sticks, buttons, minimap, timer and scores, ammo, health bar,
  kill feed) and can reset the layout; **Controls** is a separate page (Pause menu or Settings) for how input works.
- Graphics quality "Auto" no longer drops soldiers to flat circles after a short slow patch, and recovers by itself.

## Features
- **Solo mode**: Classic (1-3 computer opponents, Easy / Normal / Hard, on any of the eight arenas), Battleground (battle royale
  against 7 bots) or Survival (an endless zombie world, alone or with friends).
- **Arenas**: Hazard Yard (smallest), Dockside Warehouse, Toxic Foundry, Ruined Outpost, Bunker Complex, and the
  newer Rotunda Plaza (wide open), Silo Yard and Diamond Hall. Besides square walls and crates they use round
  pillars and tanks and angled corner pieces. The host picks the arena in the lobby. Fences are thin lines
  you can stand right next to; fences and toxic pools block movement but not bullets.
- **Fourteen guns and six melee weapons**: pistol, assault rifle, shotgun, SMG, sniper rifle, magnum, plasma rifle, light MG,
  revolver, double barrel, hunting rifle, AK rifle, marksman rifle, machine pistol; knife, bat, crowbar, machete, fire axe, pickaxe.
  Pushing the aim stick all the way out fires every gun at its own rate, reloads included; bullets leave from the barrel.
  Each gun has its own camera zoom (`WeaponDef.zoom`): the sniper rifle pulls the view back to show its long range, the
  shotgun moves in close, and the view eases from one to the other when you pick up a different gun.
  Every gun has its own sound, synthesised in code (`audio/SoundBank`), no audio files; the plasma rifle keeps an electric zap on top of the same punch.
- **Aim line**: while you aim, a dashed line in the gun's colour runs from the muzzle as far as the gun reaches and stops at
  the first wall; guns that scatter their shots also show the edges of their spread. Only your own line is drawn, so it
  tells nothing about the other players. Can be switched off in Settings.
- **Dodge roll**: a button next to the aim stick. A short invulnerable somersault in the move direction
  (or the way you face), about 1.3 s cooldown. Bots roll too.
- **Heard shots only**: other players are not tracked on the minimap or by edge arrows; one shows up only
  where and while its gun was just heard firing.
- **3D look**: lit low-poly soldiers and guns, extruded walls and crates (`render/model`). Can be switched
  off in Settings for slow phones; Graphics quality "Auto" (default) lowers effects by itself when a phone
  cannot hold a steady frame rate (`render/QualityGovernor`). Frames follow the display's vsync and are
  interpolated, so 60, 90 and 120 Hz screens all look smooth.
- **Fullscreen** into the camera cutout; the HUD and controls keep to the safe area.
- **Customize HUD** (Settings > Customize HUD, or Pause > Customize HUD): move and resize every control and HUD element,
  reset the layout. Elements are shown exactly as in a match; overlapping ones are outlined in red. Nothing about how
  the controls behave is on this screen.
- **Controls** (Settings > Controls, or Pause > Controls): fixed or floating sticks, fire mode (stick fires / button fires /
  both), the "Stick fires at" level, aim dead zone, aim line and control opacity. The aim stick aims once it is past its
  dead zone and only fires once it is pushed out to the "Stick fires at" level (default 100% = all the way out,
  adjustable down to 30%); with "Button fires" the stick never fires and the fire button does the shooting. Changes apply
  at once, also during a paused match.

## Layout of the code (`app/src/main/java/com/hazardyard/game`)
| Package    | What lives there |
|------------|------------------|
| `core`     | Match rules and modes (`GameMode`), players, weapons and their reload model (`WeaponDef`, `Weapon`), the item registry (`Items`), the safe zone (`Zone`), pickups (`Pickups`), tile maps (`MapLibrary`, `BattlegroundMap`), collision (`CollisionSystem` against a `Terrain`). No Android types. |
| `survival` | The endless world and its rules: `SurvivalGen` (world generation), `SurvivalTerrain` (chunks), `SurvivalSim` (host-side rules: hunger, zombies, loot, crafting, building, farming, fishing, cars), `Inventory`, `Recipes`, `LootTable`. No Android types. |
| `bot`      | Bot AI: `BotBrain` (intent, then smooth steering), `BotSquad` (all bots of a match; spreads route searches over ticks), time-sliced A* `PathFinder`, `NavGrid`, `BotDifficulty`. |
| `engine`   | `GameEngine` implementations: `HostEngine`, `ClientEngine`, `SoloEngine`; `Presentation` turns events into effects and sounds. |
| `net`      | LAN discovery, lobby and match protocol (bump `Protocol.VERSION` when the wire format changes); `SnapshotCodec` and `SurvivalCodec` are the wire formats of a match. |
| `input`    | `InputController` (touch routing), `ControlGeometry` (pixel layout), `VirtualJoystick`, `SurvivalUi` (hotbar, bag and crafting touches). No Android types. |
| `settings` | `ControlSettings` (HUD layout: `resetLayout`; control options: `resetOptions`) / `GameSettings` and their SharedPreferences store. |
| `render`   | Canvas renderers: terrain, floor, blocks, roofs, the zone, units, pickups, shots, HUD, controls, and for survival `SurvivalRenderer` and `SurvivalHud`. `render/model` is the pure-Java 3D mesh pipeline. |
| `audio`    | `Synth` + `SoundBank` (sound design), `Mixer` (software mixing), `SoundEngine` (AudioTrack output). |
| `ui`       | Screens, the HUD layout editor (`HudEditorView`), the Controls page (`ControlsPanel`) and the Android views. |

## Adding things
- **A map**: add its rows to `MapLibrary` (legend in the comment there), a theme in `render/MapTheme`, and bump `MapLibrary.COUNT`
  (and `CLASSIC_COUNT` if players should be able to choose it). Keep it to 32 weapon pickups at most (the snapshot carries a
  32-bit pickup mask) and positions below 4096 units (they are sent as 1/8-unit 16-bit numbers).
- **A game mode**: add a `GameMode` (limits, respawn times, fixed arena, bot roster); the lobby, the solo setup and the host
  engine pick it up from there.
- **A gun**: add a `WeaponDef` (with its reload style and timings), a model in `render/model/GunModels`, sound recipes in
  `audio/SoundBank` (the shot sound id equals the weapon id, plus three reload sounds and optionally an action sound, see
  `core/Sounds`), a reload pose in `UnitRenderer.reloadPose`, and a map letter in `TileMap.weaponForLetter` if it should
  lie on a map.
