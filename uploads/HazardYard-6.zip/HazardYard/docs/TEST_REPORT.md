# HazardYard 1.4 - what was tested, and how

This build was prepared without an Android device or the Android SDK, so everything that does not need a real screen,
finger or speaker was tested **headless on a PC JVM** (the game logic, bots, networking and sound synthesis are plain
Java), and the drawing code was run through a Java2D stand-in for `android.graphics` to produce the pictures in this
folder. **Not tested here: touch input on a real phone, how the sounds actually *sound* through a speaker, real frame
rates on a phone, and the Android view screens (menus) running on a device.** Those were compile-checked and reviewed,
nothing more. Please try the items marked "on device" below first.

## Results

| Area | How it was checked | Result |
|---|---|---|
| Whole project compiles | `javac` over every source file against stubs of the Android API; the **original** 1.3 project compiles against the same stubs with zero errors, so the stubs match real use | 0 errors |
| Pistol / SMG / Magnum / Shotgun (and the other four guns): reload | 114 rule tests: total time, moment the ammunition comes back (`seatFraction`), shotgun loads one shell per 0.42 s, rounds stay when interrupted | all pass |
| Reload interruption | new trigger pull cancels (keeps ammo, no refill); a trigger held before the reload does not; empty magazine gun cannot be interrupted; dodge cancels, empty gun reloads again after the roll; weapon pickup cancels; reload pressed mid-roll waits | all pass |
| Reload / dodge / pickup sounds follow the game state | recorded sound events: start x1, shell-in x4, ready x1 for the shotgun, also on a networked client; exactly **one** dodge sound when the dodge button is mashed; no "ready" sound for a cancelled reload; pump/bolt/hammer sounds scheduled 0.34 / 0.46 / 0.20 s after the shot | all pass |
| Gun sounds are different | A-weighted spectrogram distance between every pair of guns (min 9.6 dB, the original 1.3 shots were 8.4); every reload stage across the 8 guns has a pairwise distance of at least 9.7 dB; no two sounds share a waveform; no clipping, no clicks at the ends | pass (**listen on device**) |
| Manual pickup | standing on a weapon for 2 s takes nothing; the prompt appears only within reach and with a clear line; the press takes it, swaps the gun, refills the same gun; not during a roll; pads refill after their respawn time; every pad of every map is valid | all pass |
| Battleground, 2 real players + bots | real TCP loopback: host + 1 client -> 2 humans + 6 bots, client mirrors all 8 fighters, names, pads, weapons | pass |
| Battleground, 4 real players + bots | host + 3 clients -> 4 humans + 4 bots; a human who leaves is not replaced by a bot | pass |
| Pickup / reload / dodge over the network | client presses Pick Up -> host swaps the gun -> client sees it; reload and dodge interruption over the wire | pass |
| Full Battleground matches | 7 bots, 6 minutes each: matches end, 70-90 kills per match, bots empty ~80 pads, no NaN / out-of-map positions, 99% of ticks under 0.2 ms of game logic | pass |
| Map | 120 x 80 tiles (3.8x the area of the biggest classic map), 32 weapon pads, 24 spawns; every spawn can reach every pad (791 routes checked) | pass |
| Bot shaking (measured, 10 runs of 90 s) | heading reversals per second **12.5 -> 0.55**, aim reversals per second **13.9 -> 1.1**, big heading jumps 25% -> 2.3%, aim snaps 25% -> 6%, leg direction flips (with the old animation code) 12.2 -> 1.2 per second | fixed |
| Soldier leg flip (animation side of the shaking) | the legs now follow the smoothed velocity and only turn around with hysteresis (see `UnitRenderer`) | by construction + replay of the old logic |
| "Circle character" (quality governor) | simulated frame-time traces: slow first seconds, a 2 s slow patch, hitches, a really slow phone, recovery, flip-flop, 120 Hz screens | 12/12 pass |
| HUD layout | default layout has no overlaps on 20:9, 19.5:9, 16:9, 4:3 and 640x360 dp screens; an element can never leave the screen (also at maximum size in a corner); hit area grows exactly with the size | pass (one 533x320 dp case still overlaps, as the 1.3 layout did) |
| Customize HUD vs Controls | HUD editor only touches position and size (`copyLayoutFrom`), Controls only touches options (`resetOptions`); editor picture rendered (see `hud-editor.png`) | pass (**touch on device**) |

## Please try on a device first
1. Battleground with a friend (and with 3-4 phones): lobby mode switch, bots filling the roster.
2. Pick Up: walk over a weapon (nothing should happen), press the button.
3. A reload of each gun: sounds and the arm movement; fire in the middle of a reload.
4. Pause -> Customize HUD (drag, pinch, slider, Reset layout, Save/Cancel) and Pause -> Controls.
5. The sounds themselves: if one of them is not to your taste, the recipes are in `audio/SoundBank.java`.

## Version 1.5 (battle royale, melee, survival)

Checked the same way as before: every non-UI source file compiled with a stand-in for the Android graphics API, the pure-Java
logic run on a JVM, and real frames of the real renderers drawn to PNG (see the screenshots in this folder). The UI classes
(`ui/`, `MainActivity`) cannot be built off the phone; they were compiled together with everything else and every error
that remained was a missing Android framework class, none a project symbol. What cannot be judged without a device:
how the controls feel under a thumb, frame rate on the Infinix, and how the sounds actually sound.

**Battleground (battle royale)**
- 14 matches of 8 bots on the new island: every match ended with one winner holding place 1 and all places 1..8 handed out
  exactly once; matches lasted 90-260 s (bots find each other fast; a human takes longer). Vests were picked up 5-13 times and
  kits 1-5 times a match. Armour values never left 0..100.
- `Zone`: 300 random zones, every next circle lies inside the previous one, no target centre on water or a wall, and the
  collapse takes 476 s on average (the schedule adds up to 475 s).
- The island builds in about 120 ms on a laptop (192 x 192 tiles, 79 buildings, 190+ item pads, 20+ spawn points), is one
  connected stretch of ground (anything unreachable is filled in), and is identical on every run.
- Wire format: a battle-royale snapshot round-trips armour, places, positions beyond 4096 units, all 220 pad bits and the zone
  (125 bytes with 4 players).
- Classic arenas (all 8, 4 bots each) still play and end as before.

**Melee and guns**: a blow lands after its hit delay, does not reach 240 units, does not hit behind the fighter, a vest takes
60% (knife 24: armour 50 -> 36, health 100 -> 90), and an axe kills in a few blows.

**Sound**: the assault rifle shot is byte for byte the original; the other 13 gun shots, 14 x 3 reloads, the swings and the
survival sounds are all in range (peak 0.8-0.95) and the guns share the rifle's loudness (RMS 0.24-0.39 against its 0.32).
`gun-sounds.png` shows the envelopes and spectrograms: same attack-and-decay shape, separate size and tail per gun, and
distinct mechanical events in the reloads.

**Survival**: a scripted solo game on a fresh world: spawn with a kit, search 12 pieces of furniture in the start town (50
items), craft an axe and a workbench, place a wall, till soil, plant and grow a crop to ripe, fight 25 zombies at night (34 kills
with a knife, 0.05 ms of simulation per step), find a wreck, fit tyre, battery and engine parts with a wrench and fuel, get in, drive
(251 units/s after four seconds, the survivor follows the car), get out; die (the pack drops) and respawn with the starter kit.
The survival state frame holds 1291 bytes with 44 zombies, 12 cars and 40 items in sight (limit 4096), and zombies, cars, items,
hunger, fishing, the clock, inventories, commands and tile edits all round-trip through `SurvivalCodec` (including positions
100,000 units from the origin). Generating the 49 chunks round the start takes a few milliseconds.
