package com.hazardyard.game.ui;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.hazardyard.game.audio.SoundEngine;
import com.hazardyard.game.engine.GameEngine;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.render.Palette;

/**
 * The match: a full-screen GameView with the pause menu on top. From the pause menu the control
 * layout can be edited in place, and the match resumes with the new layout.
 */
final class GameScreen implements Screen, GameLoop.Callback, InputController.Listener {
    private final Context ctx;
    private final Navigator nav;
    private final GameEngine engine;
    private final boolean solo;
    private final FrameLayout root;
    private final GameView gameView;
    private final FrameLayout pauseOverlay;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private ControlsEditorView editor;
    private int insetL, insetT, insetR, insetB;
    private boolean paused;
    private boolean finishing;

    GameScreen(Context c, Navigator navigator, GameEngine eng, boolean multiplayer, boolean solo) {
        ctx = c;
        nav = navigator;
        engine = eng;
        this.solo = solo;
        SoundEngine sound = navigator.sound();
        if (sound != null) eng.state().audio.setSink(sound);

        root = new FrameLayout(c);
        gameView = new GameView(c, eng, navigator.settings(), sound, this);
        gameView.input().setListener(this);
        root.addView(gameView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        FrameLayout overlay = new FrameLayout(c);
        overlay.setBackgroundColor(0xB0000000);
        overlay.setClickable(true);
        overlay.setVisibility(View.GONE);
        LinearLayout panel = Ui.panel(c);
        panel.addView(Ui.label(c, "Paused", 28f, Palette.TEXT, true));
        if (multiplayer) {
            panel.addView(Ui.label(c, "The match keeps running for the other players.", 13f, Palette.TEXT_DIM, false),
                    Ui.fillWidth(c, 6));
        }
        Button resume = Ui.button(c, "Resume", true);
        resume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setPaused(false);
            }
        });
        panel.addView(resume, Ui.fillWidth(c, 16));
        if (solo) {
            Button restart = Ui.button(c, "Restart match", false);
            restart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finishing = true;
                    nav.restartSolo();
                }
            });
            panel.addView(restart, Ui.fillWidth(c, 10));
        }
        Button controls = Ui.button(c, "Controls", false);
        controls.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditor();
            }
        });
        panel.addView(controls, Ui.fillWidth(c, 10));
        Button quit = Ui.button(c, "Leave match", false);
        quit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishing = true;
                if (GameScreen.this.solo) nav.showSoloSetup();
                else nav.showMenu(null);
            }
        });
        panel.addView(quit, Ui.fillWidth(c, 10));
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(Ui.dp(c, 320),
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        overlay.addView(panel, plp);
        root.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pauseOverlay = overlay;
    }

    private void setPaused(boolean p) {
        paused = p;
        pauseOverlay.setVisibility(p ? View.VISIBLE : View.GONE);
        gameView.input().cancelAll();
        engine.setPaused(p);
    }

    // ------------------------------------------------------------------ control layout editor

    private void openEditor() {
        if (editor != null) return;
        editor = new ControlsEditorView(ctx, nav.settings(), new ControlsEditorView.Listener() {
            @Override
            public void onClose(boolean saved) {
                if (editor != null) {
                    root.removeView(editor);
                    editor = null;
                }
                if (saved) {
                    nav.saveSettings();
                    gameView.applySettings();
                }
            }
        });
        editor.setInsets(insetL, insetT, insetR, insetB);
        root.addView(editor, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // ------------------------------------------------------------------ callbacks

    /** Pause button tapped (UI thread). */
    @Override
    public void onPausePressed() {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (!paused) setPaused(true);
            }
        });
    }

    /** Game thread: the session ended. */
    @Override
    public void onEngineFinished(final String reason) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (finishing) return;
                finishing = true;
                nav.onMatchFinished(reason);
            }
        });
    }

    // ------------------------------------------------------------------ Screen

    @Override
    public View view() {
        return root;
    }

    @Override
    public void onShow() {
        // The loop starts by itself when the surface is ready.
    }

    @Override
    public void onHide() {
        finishing = true;
        ui.removeCallbacksAndMessages(null);
        gameView.stopLoop();
        engine.close();
    }

    @Override
    public boolean onBack() {
        if (editor != null) return editor.handleBack();
        setPaused(!paused);
        return true;
    }

    @Override
    public void onInsets(int l, int t, int r, int b) {
        insetL = l;
        insetT = t;
        insetR = r;
        insetB = b;
        gameView.setInsets(l, t, r, b);
        pauseOverlay.setPadding(l, t, r, b);
        if (editor != null) editor.setInsets(l, t, r, b);
    }
}
