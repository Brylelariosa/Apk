package com.hazardyard.game.core;

/**
 * One player slot. The same class serves the host (authoritative state plus received input) and
 * clients (last received state plus interpolation data), which keeps the renderer identical for both.
 */
public final class Player {
    public final int id;
    public String name = "";
    /** Slot is in use (a human is in the match). */
    public boolean connected;

    // ---- gameplay state: authoritative on the host, mirrored from snapshots on clients ----
    public boolean alive;
    public float x, y;
    public float aim;
    public int health = GameConfig.PLAYER_MAX_HEALTH;
    public float respawnTimer;
    public float spawnProtect;
    public int kills, deaths;
    public final Weapon weapon = new Weapon();

    // ---- dodge roll: authoritative on the host, predicted by a client for its own player, mirrored for the rest ----
    /** Seconds of roll left; 0 when not rolling. */
    public float rollTimer;
    public float rollDirX, rollDirY;
    /** Seconds until another roll may start. */
    public float dodgeCooldown;
    /** How far through the roll the player is as drawn (0..1, smoothed between simulation steps); only meaningful while rolling. */
    public float rollU;

    // ---- host side: latest input received for this player ----
    public float moveX, moveY;
    public float aimTarget;
    public boolean hasAimInput;
    public boolean firing;
    /** Counts trigger pulls (rising edges of {@link #firing}); semi-automatic weapons use it. */
    public int pulls;
    public int handledPulls;
    public float pullBuffer;
    public boolean reloadRequest;
    /** A dodge roll was requested; consumed by the next simulation step. */
    public boolean dodgeRequest;
    /** Requested roll direction (a unit vector); (0, 0) lets the host choose from the player's input. */
    public float dodgeReqX, dodgeReqY;
    /** Sequence number of the newest input applied; echoed to the owner for prediction. */
    public int lastInputSeq;

    // ---- presentation: what the renderer draws ----
    public float rx, ry, rAim;
    public float hitFlash;
    public float muzzleFlash;

    // ---- client side: interpolation of remote players ----
    public float fromX, fromY, fromAim;
    public float toX, toY, toAim;
    public float interpT;
    public boolean interpValid;
    /** Decaying visual offset applied after a prediction correction (local player only). */
    public float visX, visY;

    public Player(int id) {
        this.id = id;
    }

    public boolean isProtected() {
        return spawnProtect > 0f;
    }

    public boolean isRolling() {
        return rollTimer > 0f;
    }

    /** Clears everything that should not survive from one match into the next. */
    public void resetForMatch() {
        alive = false;
        health = GameConfig.PLAYER_MAX_HEALTH;
        respawnTimer = 0f;
        spawnProtect = 0f;
        kills = 0;
        deaths = 0;
        moveX = 0f;
        moveY = 0f;
        firing = false;
        pulls = 0;
        handledPulls = 0;
        pullBuffer = 0f;
        reloadRequest = false;
        dodgeRequest = false;
        rollTimer = 0f;
        dodgeCooldown = 0f;
        hitFlash = 0f;
        muzzleFlash = 0f;
        interpValid = false;
        visX = 0f;
        visY = 0f;
        weapon.equip(WeaponDef.ALL[WeaponDef.PISTOL]);
    }
}
