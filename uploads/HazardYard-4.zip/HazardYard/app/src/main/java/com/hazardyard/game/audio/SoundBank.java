package com.hazardyard.game.audio;

import com.hazardyard.game.core.Sounds;
import com.hazardyard.game.core.WeaponDef;

/**
 * Builds every sound effect of the game from scratch with {@link Synth}: no audio files. Each gun has
 * its own recipe (different noise colour, body pitch, tail and ring) so they are easy to tell apart
 * by ear: a snappy pop for the pistol, a heavy boom for the shotgun, a long echoing crack for the
 * sniper, a sci-fi zap for the plasma rifle, and so on.
 */
public final class SoundBank {
    private SoundBank() {}

    /** How far each sound carries, as a multiple of the normal hearing distance. */
    private static final float[] CARRY = new float[Sounds.COUNT];
    /** Default loudness of each sound before distance and master volume. */
    private static final float[] LEVEL = new float[Sounds.COUNT];

    static {
        java.util.Arrays.fill(CARRY, 1f);
        java.util.Arrays.fill(LEVEL, 1f);
        CARRY[WeaponDef.PISTOL] = 1.0f;
        CARRY[WeaponDef.RIFLE] = 1.3f;
        CARRY[WeaponDef.SHOTGUN] = 1.6f;
        CARRY[WeaponDef.SMG] = 0.9f;
        CARRY[WeaponDef.SNIPER] = 3.2f;
        CARRY[WeaponDef.MAGNUM] = 1.7f;
        CARRY[WeaponDef.PLASMA] = 1.3f;
        CARRY[WeaponDef.LMG] = 1.5f;
        CARRY[Sounds.KILL] = 1.4f;
        CARRY[Sounds.RELOAD] = 0.5f;
        CARRY[Sounds.IMPACT] = 0.5f;
        CARRY[Sounds.PICKUP] = 0.6f;
        CARRY[Sounds.RESPAWN] = 0.7f;
        CARRY[Sounds.DODGE] = 0.6f;
        LEVEL[WeaponDef.SMG] = 0.8f;
        LEVEL[WeaponDef.PLASMA] = 0.85f;
        LEVEL[Sounds.IMPACT] = 0.5f;
        LEVEL[Sounds.HIT] = 0.8f;
        LEVEL[Sounds.DODGE] = 0.8f;
        LEVEL[Sounds.RELOAD] = 0.8f;
        LEVEL[Sounds.COUNTDOWN] = 0.7f;
    }

    public static float carry(int sound) {
        return CARRY[sound];
    }

    public static float level(int sound) {
        return LEVEL[sound];
    }

    /** Synthesises all sounds (a few milliseconds of work in total). Index = {@link Sounds} id. */
    public static short[][] build() {
        short[][] pcm = new short[Sounds.COUNT][];
        for (int id = 0; id < Sounds.COUNT; id++) pcm[id] = Synth.toPcm(make(id));
        return pcm;
    }

    /** Float version of one sound, used by {@link #build} and by the tests. */
    static float[] make(int id) {
        switch (id) {
            case WeaponDef.PISTOL: return pistol();
            case WeaponDef.RIFLE: return rifle();
            case WeaponDef.SHOTGUN: return shotgun();
            case WeaponDef.SMG: return smg();
            case WeaponDef.SNIPER: return sniper();
            case WeaponDef.MAGNUM: return magnum();
            case WeaponDef.PLASMA: return plasma();
            case WeaponDef.LMG: return lmg();
            case Sounds.RELOAD: return reload();
            case Sounds.PICKUP: return pickup();
            case Sounds.HIT: return hit();
            case Sounds.HURT: return hurt();
            case Sounds.KILL: return kill();
            case Sounds.DEATH: return death();
            case Sounds.RESPAWN: return respawn();
            case Sounds.IMPACT: return impact();
            case Sounds.COUNTDOWN: return beep(880f, 0.14f);
            case Sounds.GO: return go();
            case Sounds.WIN: return arpeggio(new float[] {523.25f, 659.25f, 783.99f, 1046.5f}, 0.11f, 0.5f, 0.1f);
            case Sounds.LOSE: return arpeggio(new float[] {392f, 349.23f, 293.66f, 233.08f}, 0.16f, 0.45f, 0.5f);
            case Sounds.CONFIRM: return confirm();
            case Sounds.DODGE: return dodge();
            default: return new float[1];
        }
    }

    // ------------------------------------------------------------------ guns

    /** Snappy 9 mm pop: bright noise crack on top of a short mid "pock". */
    private static float[] pistol() {
        float[] b = Synth.buffer(0.22f);
        Synth.Noise n = new Synth.Noise(11);
        Synth.addNoise(b, n, 0f, 0.016f, 1.0f, 1800f, 9000f);
        Synth.addSweep(b, 0f, 0.05f, 0.9f, 720f, 170f, 40f);
        Synth.addNoise(b, n, 0.004f, 0.06f, 0.18f, 300f, 1800f);
        Synth.saturate(b, 1.7f);
        return finish(b, 0.9f);
    }

    /** Assault rifle: a harder crack, a low thump and a short tail. */
    private static float[] rifle() {
        float[] b = Synth.buffer(0.30f);
        Synth.Noise n = new Synth.Noise(23);
        Synth.addNoise(b, n, 0f, 0.028f, 1.0f, 700f, 6500f);
        Synth.addSweep(b, 0f, 0.075f, 1.0f, 200f, 62f, 38f);
        Synth.addNoise(b, n, 0.01f, 0.10f, 0.32f, 200f, 1400f);
        Synth.saturate(b, 2.3f);
        return finish(b, 0.92f);
    }

    /** Shotgun: huge low-passed blast, a deep sub boom and the pump action clacking afterwards. */
    private static float[] shotgun() {
        float[] b = Synth.buffer(0.70f);
        Synth.Noise n = new Synth.Noise(37);
        Synth.addNoise(b, n, 0f, 0.11f, 1.0f, 0f, 3800f);
        Synth.addNoise(b, n, 0f, 0.26f, 0.38f, 0f, 900f);
        Synth.addSweep(b, 0f, 0.18f, 1.1f, 115f, 34f, 17f);
        Synth.addNoise(b, n, 0.36f, 0.010f, 0.30f, 1200f, 4200f);
        Synth.addNoise(b, n, 0.47f, 0.012f, 0.38f, 900f, 3600f);
        Synth.saturate(b, 3.0f);
        return finish(b, 0.95f);
    }

    /** SMG: a light, fast tick that still sounds fine when it repeats twelve times a second. */
    private static float[] smg() {
        float[] b = Synth.buffer(0.12f);
        Synth.Noise n = new Synth.Noise(41);
        Synth.addNoise(b, n, 0f, 0.010f, 0.9f, 2600f, 10000f);
        Synth.addSweep(b, 0f, 0.022f, 0.7f, 1500f, 520f, 55f);
        Synth.saturate(b, 1.5f);
        return finish(b, 0.85f);
    }

    /** Sniper: a razor crack, a deep boom and a long rumbling echo off far walls. */
    private static float[] sniper() {
        float[] b = Synth.buffer(1.25f);
        Synth.Noise n = new Synth.Noise(53);
        Synth.addNoise(b, n, 0f, 0.012f, 1.2f, 1400f, 11000f);
        Synth.addSweep(b, 0f, 0.26f, 1.1f, 160f, 40f, 11f);
        Synth.addNoise(b, n, 0.005f, 0.30f, 0.30f, 0f, 700f);
        Synth.saturate(b, 2.0f);
        float[] dry = b.clone();
        Synth.lowPass(dry, 2500f);
        Synth.echo(dry, 0.17f, 0.45f, 4);
        for (int i = 0; i < b.length; i++) b[i] = b[i] * 0.8f + dry[i] * 0.6f;
        return finish(b, 0.95f);
    }

    /** Magnum: a big round boom with the metallic "ting" of a revolver frame ringing afterwards. */
    private static float[] magnum() {
        float[] b = Synth.buffer(0.75f);
        Synth.Noise n = new Synth.Noise(67);
        Synth.addSweep(b, 0f, 0.15f, 1.1f, 210f, 55f, 22f);
        Synth.addNoise(b, n, 0f, 0.034f, 0.95f, 400f, 5200f);
        Synth.addTone(b, 0.002f, 0f, 0.13f, 0.20f, 1250f, 0f);
        Synth.addTone(b, 0.002f, 0f, 0.10f, 0.14f, 1890f, 0f);
        Synth.addTone(b, 0.002f, 0f, 0.08f, 0.10f, 2650f, 0f);
        Synth.saturate(b, 2.4f);
        return finish(b, 0.93f);
    }

    /**
     * Plasma rifle: an electric zap. A ring-modulated saw dives from a shriek to a low growl, an FM
     * sparkle and a second detuned zap sit on top, random arc crackles rain over it, and a short
     * buzzing hum trails off. Short (0.3 s) so it stays clean at eleven shots a second.
     */
    private static float[] plasma() {
        float[] b = Synth.buffer(0.30f);
        Synth.Noise n = new Synth.Noise(79);
        Synth.addZap(b, 0f, 0.085f, 0.95f, 3300f, 210f, 26f, 137f, 0.8f);
        Synth.addZap(b, 0.002f, 0.065f, 0.45f, 4700f, 540f, 30f, 211f, 0.7f);
        Synth.addFm(b, 0f, 0.075f, 0.35f, 1900f, 2650f, 7f, 20f);
        Synth.addCrackle(b, n, 0f, 0.24f, 0.010f, 0.075f, 0.85f, 2500f);
        Synth.addSweep(b, 0f, 0.05f, 0.55f, 260f, 70f, 40f);
        Synth.addBuzz(b, 0.02f, 0.26f, 0.20f, 96f, 38f, 0.09f);
        Synth.saturate(b, 1.8f);
        return finish(b, 0.85f);
    }

    /** Light machine gun: a dull, heavy thud with a flat crack, clearly lower than the SMG. */
    private static float[] lmg() {
        float[] b = Synth.buffer(0.20f);
        Synth.Noise n = new Synth.Noise(97);
        Synth.addSweep(b, 0f, 0.05f, 1.0f, 150f, 52f, 42f);
        Synth.addNoise(b, n, 0f, 0.036f, 0.95f, 150f, 2600f);
        Synth.addNoise(b, n, 0f, 0.010f, 0.5f, 2500f, 6500f);
        Synth.saturate(b, 2.6f);
        return finish(b, 0.9f);
    }

    // ------------------------------------------------------------------ everything else

    private static float[] reload() {
        float[] b = Synth.buffer(0.52f);
        Synth.Noise n = new Synth.Noise(101);
        Synth.addNoise(b, n, 0.00f, 0.012f, 0.8f, 1800f, 5200f);
        Synth.addTone(b, 0.00f, 0f, 0.025f, 0.35f, 900f, 0f);
        Synth.addNoise(b, n, 0.17f, 0.030f, 0.30f, 900f, 3200f);
        Synth.addNoise(b, n, 0.35f, 0.014f, 1.0f, 1200f, 4200f);
        Synth.addTone(b, 0.35f, 0f, 0.035f, 0.45f, 610f, 0f);
        return finish(b, 0.8f);
    }

    private static float[] pickup() {
        float[] b = Synth.buffer(0.40f);
        Synth.addTone(b, 0.00f, 0.004f, 0.07f, 0.8f, 659.25f, 0.1f);
        Synth.addTone(b, 0.09f, 0.004f, 0.09f, 0.8f, 987.77f, 0.1f);
        Synth.addTone(b, 0.09f, 0.004f, 0.05f, 0.3f, 1975.5f, 0f);
        return finish(b, 0.8f);
    }

    /** A bullet landing on a player: a short electric zap with arc crackle and a dull thump under it. */
    private static float[] hit() {
        float[] b = Synth.buffer(0.16f);
        Synth.Noise n = new Synth.Noise(107);
        Synth.addZap(b, 0f, 0.035f, 0.9f, 2400f, 260f, 38f, 160f, 0.85f);
        Synth.addCrackle(b, n, 0f, 0.14f, 0.012f, 0.04f, 0.9f, 2200f);
        Synth.addSweep(b, 0f, 0.03f, 0.6f, 190f, 70f, 45f);
        Synth.saturate(b, 1.7f);
        return finish(b, 0.8f);
    }

    /** The local player is hit: a heavier electric jolt, a low stuttering buzz with crackle and a deep thump. */
    private static float[] hurt() {
        float[] b = Synth.buffer(0.34f);
        Synth.Noise n = new Synth.Noise(109);
        Synth.addBuzz(b, 0f, 0.30f, 0.85f, 62f, 26f, 0.12f);
        Synth.addZap(b, 0f, 0.09f, 0.7f, 1500f, 130f, 20f, 90f, 0.9f);
        Synth.addCrackle(b, n, 0f, 0.28f, 0.010f, 0.10f, 0.7f, 1800f);
        Synth.addSweep(b, 0f, 0.09f, 0.8f, 160f, 50f, 22f);
        Synth.saturate(b, 2.3f);
        return finish(b, 0.9f);
    }

    private static float[] kill() {
        float[] b = Synth.buffer(0.55f);
        Synth.Noise n = new Synth.Noise(113);
        Synth.addSweep(b, 0f, 0.17f, 1.0f, 130f, 32f, 14f);
        Synth.addNoise(b, n, 0f, 0.11f, 0.7f, 0f, 2200f);
        Synth.addNoise(b, n, 0f, 0.015f, 0.5f, 1500f, 7000f);
        Synth.saturate(b, 2.0f);
        return finish(b, 0.9f);
    }

    private static float[] death() {
        float[] b = Synth.buffer(0.80f);
        float phase = 0f;
        for (int i = 0; i < b.length; i++) {
            float t = i / (float) Synth.RATE;
            float f = 90f + 260f * (float) Math.exp(-t * 4.5f);
            phase += (float) (2.0 * Math.PI) * f * (1f + 0.04f * (float) Math.sin(2.0 * Math.PI * 7.0 * t)) / Synth.RATE;
            b[i] = (float) Math.sin(phase) * Synth.attackDecay(t, 0.01f, 0.30f);
        }
        Synth.lowPass(b, 900f);
        Synth.saturate(b, 1.6f);
        return finish(b, 0.85f);
    }

    private static float[] respawn() {
        float[] b = Synth.buffer(0.45f);
        float phase = 0f;
        Synth.Noise n = new Synth.Noise(127);
        for (int i = 0; i < b.length; i++) {
            float t = i / (float) Synth.RATE;
            float f = 220f * (float) Math.pow(4.0, t / 0.45f);
            phase += (float) (2.0 * Math.PI) * f / Synth.RATE;
            float env = (float) Math.sin(Math.PI * Math.min(1f, t / 0.45f));
            b[i] = (float) Math.sin(phase) * env * 0.8f + n.next() * env * 0.05f;
        }
        return finish(b, 0.75f);
    }

    private static float[] impact() {
        float[] b = Synth.buffer(0.10f);
        Synth.Noise n = new Synth.Noise(131);
        Synth.addNoise(b, n, 0f, 0.012f, 0.9f, 1500f, 7000f);
        Synth.addTone(b, 0f, 0f, 0.03f, 0.25f, 2400f, 0f);
        return finish(b, 0.6f);
    }

    private static float[] beep(float freq, float seconds) {
        float[] b = Synth.buffer(seconds + 0.03f);
        Synth.addTone(b, 0f, 0.003f, seconds * 0.5f, 0.9f, freq, 0.15f);
        return finish(b, 0.7f);
    }

    private static float[] go() {
        float[] b = Synth.buffer(0.55f);
        Synth.addTone(b, 0f, 0.003f, 0.14f, 0.8f, 1320f, 0.15f);
        Synth.addTone(b, 0f, 0.003f, 0.14f, 0.4f, 1980f, 0f);
        Synth.addTone(b, 0f, 0.003f, 0.14f, 0.3f, 660f, 0f);
        return finish(b, 0.8f);
    }

    private static float[] arpeggio(float[] notes, float step, float tail, float sawMix) {
        float total = step * (notes.length - 1) + tail;
        float[] b = Synth.buffer(total);
        for (int i = 0; i < notes.length; i++) {
            boolean last = i == notes.length - 1;
            Synth.addTone(b, i * step, 0.005f, last ? tail * 0.35f : step * 1.1f, last ? 0.9f : 0.7f, notes[i], sawMix);
        }
        Synth.lowPass(b, 5000f);
        return finish(b, 0.8f);
    }

    /**
     * The roll: a breathy whoosh (a low band that dies away and a bright band that swells and fades),
     * a click of gear at the start and a soft thud of the landing at the end.
     */
    private static float[] dodge() {
        float[] b = Synth.buffer(0.42f);
        Synth.Noise n = new Synth.Noise(137);
        float[] lo = Synth.buffer(0.42f);
        float[] hi = Synth.buffer(0.42f);
        for (int i = 0; i < lo.length; i++) {
            float v = n.next();
            lo[i] = v;
            hi[i] = v;
        }
        Synth.bandPass(lo, 180f, 900f);
        Synth.bandPass(hi, 1400f, 5200f);
        for (int i = 0; i < b.length; i++) {
            float t = i / (float) Synth.RATE;
            float envLo = (float) Math.exp(-t / 0.13f) * Math.min(1f, t / 0.012f);
            float s = (float) Math.sin(Math.PI * Math.min(1f, t / 0.32f));
            float envHi = s * s * (t < 0.32f ? 1f : (float) Math.exp(-(t - 0.32f) / 0.03f));
            b[i] = lo[i] * envLo * 1.6f + hi[i] * envHi * 1.1f;
        }
        Synth.addNoise(b, n, 0f, 0.006f, 0.35f, 2000f, 7000f);
        Synth.addSweep(b, 0.31f, 0.06f, 0.55f, 140f, 55f, 40f);
        Synth.addNoise(b, n, 0.31f, 0.02f, 0.18f, 300f, 1600f);
        return finish(b, 0.8f);
    }

    private static float[] confirm() {
        float[] b = Synth.buffer(0.35f);
        Synth.addTone(b, 0.00f, 0.002f, 0.05f, 0.7f, 1760f, 0f);
        Synth.addTone(b, 0.07f, 0.002f, 0.09f, 0.7f, 2637f, 0f);
        return finish(b, 0.75f);
    }

    private static float[] finish(float[] b, float peak) {
        Synth.normalize(b, peak);
        Synth.fadeOut(b, 0.006f);
        return b;
    }
}
