package com.hazardyard.game.core;

/** Small allocation-free math helpers. */
public final class MathUtil {
    private MathUtil() {}

    public static final float PI = (float) Math.PI;
    public static final float TWO_PI = PI * 2f;

    public static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    public static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** Wraps an angle to (-PI, PI]. Non-finite input returns 0. */
    public static float wrapAngle(float a) {
        if (Float.isNaN(a) || Float.isInfinite(a)) return 0f;
        while (a > PI) a -= TWO_PI;
        while (a <= -PI) a += TWO_PI;
        return a;
    }

    /** Shortest signed rotation that takes {@code from} to {@code to}. */
    public static float angleDiff(float from, float to) {
        return wrapAngle(to - from);
    }

    public static float lerpAngle(float from, float to, float t) {
        return wrapAngle(from + angleDiff(from, to) * t);
    }

    public static float rotateToward(float current, float target, float maxStep) {
        float d = angleDiff(current, target);
        if (d > maxStep) d = maxStep;
        else if (d < -maxStep) d = -maxStep;
        return wrapAngle(current + d);
    }

    public static int angleToU8(float a) {
        return Math.round(wrapAngle(a) * (256f / TWO_PI)) & 0xFF;
    }

    public static float u8ToAngle(int v) {
        return wrapAngle((v & 0xFF) * (TWO_PI / 256f));
    }

    public static int angleToU16(float a) {
        return Math.round(wrapAngle(a) * (65536f / TWO_PI)) & 0xFFFF;
    }

    public static float u16ToAngle(int v) {
        return wrapAngle((v & 0xFFFF) * (TWO_PI / 65536f));
    }

    public static boolean isFinite(float v) {
        return !Float.isNaN(v) && !Float.isInfinite(v);
    }
}
