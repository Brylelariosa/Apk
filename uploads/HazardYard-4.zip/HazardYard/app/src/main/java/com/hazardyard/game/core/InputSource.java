package com.hazardyard.game.core;

/** Supplies the local player's controls; implemented by the touch controller (and by bots in tests). */
public interface InputSource {
    /**
     * Fills {@code out} with the current controls. {@code out.aim} arrives holding the previous
     * value so implementations can leave it untouched while the aim stick is idle.
     */
    void sample(LocalInput out);
}
