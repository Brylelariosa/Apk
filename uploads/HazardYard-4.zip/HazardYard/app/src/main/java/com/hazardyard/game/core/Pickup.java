package com.hazardyard.game.core;

/** A weapon crate on the map. It respawns a while after somebody takes it. */
public final class Pickup {
    public final float x, y;
    public final int weaponId;
    public boolean active = true;
    public float timer;

    public Pickup(float x, float y, int weaponId) {
        this.x = x;
        this.y = y;
        this.weaponId = weaponId;
    }
}
