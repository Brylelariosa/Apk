package com.hazardyard.game.net;

import java.nio.charset.StandardCharsets;

/** Big-endian reader over a received frame. Throws IllegalStateException on truncated data. */
public final class PacketReader {
    private byte[] buf = new byte[0];
    private int pos;
    private int end;

    public PacketReader wrap(byte[] data, int offset, int length) {
        buf = data;
        pos = offset;
        end = offset + length;
        return this;
    }

    public int remaining() {
        return end - pos;
    }

    public int u8() {
        if (pos >= end) throw new IllegalStateException("packet underflow");
        return buf[pos++] & 0xFF;
    }

    public int i8() {
        return (byte) u8();
    }

    public int u16() {
        return (u8() << 8) | u8();
    }

    public int i16() {
        return (short) u16();
    }

    public int i32() {
        return (u8() << 24) | (u8() << 16) | (u8() << 8) | u8();
    }

    public String str() {
        int n = u8();
        if (pos + n > end) throw new IllegalStateException("packet underflow");
        String s = new String(buf, pos, n, StandardCharsets.UTF_8);
        pos += n;
        return s;
    }
}
