package com.hazardyard.game.ui;

import android.content.Context;
import android.graphics.Rect;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.hazardyard.game.audio.SoundEngine;
import com.hazardyard.game.engine.GameEngine;
import com.hazardyard.game.input.ControlGeometry;
import com.hazardyard.game.input.InputController;
import com.hazardyard.game.settings.ControlSettings;
import com.hazardyard.game.settings.GameSettings;

import java.util.ArrayList;
import java.util.List;

/**
 * Surface the match is drawn on. It fills the whole display (including the area behind a camera
 * cutout); the controls and HUD stay inside the safe area. Owns the game loop (started when the
 * surface is ready, stopped before it disappears) and the sound output, and translates Android
 * touch events into {@link InputController} calls.
 */
final class GameView extends SurfaceView implements SurfaceHolder.Callback {
    private final GameEngine engine;
    private final GameSettings settings;
    private final SoundEngine sound;
    private final GameLoop.Callback callback;
    private final InputController input;
    private final float density;
    private GameLoop loop;
    private int surfaceW, surfaceH;
    private int insetL, insetT, insetR, insetB;

    GameView(Context c, GameEngine engine, GameSettings settings, SoundEngine sound, GameLoop.Callback callback) {
        super(c);
        this.engine = engine;
        this.settings = settings;
        this.sound = sound;
        this.callback = callback;
        this.input = new InputController(settings.controls);
        this.density = c.getResources().getDisplayMetrics().density;
        getHolder().addCallback(this);
        setKeepScreenOn(true);
    }

    InputController input() {
        return input;
    }

    /** Safe-area insets (display cutout) in pixels; controls and HUD keep out of them. */
    void setInsets(int l, int t, int r, int b) {
        if (l == insetL && t == insetT && r == insetR && b == insetB) return;
        insetL = l;
        insetT = t;
        insetR = r;
        insetB = b;
        layoutControls();
    }

    /** Call after the control settings changed (layout editor closed). */
    void applySettings() {
        input.applySettings();
        updateGestureExclusion();
    }

    private void layoutControls() {
        if (surfaceW <= 0 || surfaceH <= 0) return;
        input.setViewport(surfaceW, surfaceH, density, insetL, insetT, insetR, insetB);
        updateGestureExclusion();
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // The loop starts in surfaceChanged, once the size is known.
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h) {
        surfaceW = w;
        surfaceH = h;
        layoutControls();
        if (loop == null) {
            loop = new GameLoop(holder, engine, input, settings, density, callback);
            loop.setSize(w, h);
            loop.start();
            if (sound != null) sound.start();
        } else {
            loop.setSize(w, h);
        }
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        stopLoop();
    }

    /** Stops the game thread and the sound output (idempotent). */
    void stopLoop() {
        if (loop != null) {
            loop.stop();
            loop = null;
        }
        if (sound != null) sound.stop();
        input.cancelAll();
    }

    /**
     * Keeps the Android "back" swipe away from the thumb zones: a gesture-exclusion strip along each
     * screen edge, covering whichever controls sit near that edge (Android allows at most 200dp of
     * height per edge).
     */
    private void updateGestureExclusion() {
        if (surfaceW <= 0 || surfaceH <= 0) return;
        ControlGeometry g = input.geometry();
        ControlSettings s = settings.controls;
        float zone = 56f * density;
        int maxH = Math.round(200f * density);
        int edge = Math.round(48f * density);
        float[] span = new float[4];   // left top, left bottom, right top, right bottom
        span[0] = span[2] = Float.MAX_VALUE;
        span[1] = span[3] = -1f;
        for (int i = 0; i < ControlSettings.COUNT; i++) {
            if (i == ControlSettings.FIRE && !s.fireButtonEnabled()) continue;
            float rad = g.hitRadius(i);
            float top = g.cy[i] - rad;
            float bottom = g.cy[i] + rad;
            if (g.cx[i] - rad < zone) {
                span[0] = Math.min(span[0], top);
                span[1] = Math.max(span[1], bottom);
            }
            if (g.cx[i] + rad > surfaceW - zone) {
                span[2] = Math.min(span[2], top);
                span[3] = Math.max(span[3], bottom);
            }
        }
        if (s.moveFloating) {                       // a floating stick can start anywhere on that side
            span[0] = Math.min(span[0], surfaceH - maxH);
            span[1] = surfaceH;
        }
        if (s.aimFloating) {
            span[2] = Math.min(span[2], surfaceH - maxH);
            span[3] = surfaceH;
        }
        List<Rect> rects = new ArrayList<>(2);
        addStrip(rects, 0, edge, span[0], span[1], maxH);
        addStrip(rects, surfaceW - edge, surfaceW, span[2], span[3], maxH);
        setSystemGestureExclusionRects(rects);
    }

    private void addStrip(List<Rect> out, int x0, int x1, float top, float bottom, int maxH) {
        if (bottom < 0f) return;
        float t = Math.max(0f, top);
        float b = Math.min(surfaceH, bottom);
        if (b - t > maxH) {
            float mid = (t + b) * 0.5f;
            t = mid - maxH * 0.5f;
            b = mid + maxH * 0.5f;
        }
        out.add(new Rect(x0, Math.round(t), x1, Math.round(b)));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                int i = e.getActionIndex();
                input.onPointerDown(e.getPointerId(i), e.getX(i), e.getY(i));
                break;
            }
            case MotionEvent.ACTION_MOVE:
                for (int i = 0; i < e.getPointerCount(); i++) {
                    input.onPointerMove(e.getPointerId(i), e.getX(i), e.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                input.onPointerUp(e.getPointerId(e.getActionIndex()));
                break;
            case MotionEvent.ACTION_CANCEL:
                input.cancelAll();
                break;
            default:
                break;
        }
        return true;
    }
}
