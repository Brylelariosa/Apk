package com.hazardyard.game.core;

/** Per-player weapon state: which weapon, ammunition, cooldown and reload progress. */
public final class Weapon {
    public WeaponDef def = WeaponDef.ALL[WeaponDef.PISTOL];
    public int ammo = def.magSize;
    /** Seconds until the next shot is allowed. */
    public float cooldown;
    public boolean reloading;
    /** Seconds of reload left (host side). */
    public float reloadTimer;
    /** 0..1 progress of the current reload, for the HUD (host computes it, clients receive it). */
    public float reloadFraction;

    public void equip(WeaponDef d) {
        def = d;
        ammo = d.magSize;
        cooldown = 0f;
        reloading = false;
        reloadTimer = 0f;
        reloadFraction = 0f;
    }

    public void update(float dt) {
        if (cooldown > 0f) cooldown -= dt;
        if (reloading) {
            reloadTimer -= dt;
            if (reloadTimer <= 0f) {
                reloading = false;
                reloadTimer = 0f;
                reloadFraction = 0f;
                ammo = def.magSize;
            } else {
                reloadFraction = 1f - reloadTimer / def.reloadTime;
            }
        }
    }

    public boolean canFire() {
        return !reloading && ammo > 0 && cooldown <= 0f;
    }

    /** Book-keeping after a shot left the barrel; an empty magazine reloads automatically. */
    public void onFired() {
        ammo--;
        // Adding (instead of assigning) keeps the leftover part of the last tick, so the effective
        // rate matches fireInterval even though time advances in fixed steps.
        cooldown += def.fireInterval;
        if (ammo <= 0) startReload();
    }

    public boolean startReload() {
        if (reloading || ammo >= def.magSize) return false;
        reloading = true;
        reloadTimer = def.reloadTime;
        reloadFraction = 0f;
        return true;
    }
}
