package com.hazardyard.game.input;

import com.hazardyard.game.settings.ControlSettings;

/**
 * Pixel layout of every on-screen control for one screen size: the single source of truth shared by
 * touch routing, the HUD and the layout editor, so what is drawn is exactly what is touchable.
 * Pure math; no Android types.
 */
public final class ControlGeometry {
    private static final float STICK_DP = 58f;
    private static final float FIRE_DP = 40f;
    private static final float RELOAD_DP = 34f;
    private static final float PAUSE_DP = 22f;
    private static final float DODGE_DP = 32f;

    /** Control centres in screen pixels. */
    public final float[] cx = new float[ControlSettings.COUNT];
    public final float[] cy = new float[ControlSettings.COUNT];
    /** Visual radius in pixels (half the side for the pause button). */
    public final float[] r = new float[ControlSettings.COUNT];

    public int width = 1;
    public int height = 1;
    public float density = 1f;
    /** Display cutout / system bar insets: controls never sit inside them. */
    public float insetL, insetT, insetR, insetB;

    /** Unscaled radius of a control in dp. */
    public static float baseRadiusDp(int control) {
        switch (control) {
            case ControlSettings.FIRE: return FIRE_DP;
            case ControlSettings.RELOAD: return RELOAD_DP;
            case ControlSettings.PAUSE: return PAUSE_DP;
            case ControlSettings.DODGE: return DODGE_DP;
            default: return STICK_DP;
        }
    }

    public void compute(ControlSettings s, int w, int h, float dens, float l, float t, float rt, float b) {
        width = Math.max(1, w);
        height = Math.max(1, h);
        density = dens;
        insetL = l;
        insetT = t;
        insetR = rt;
        insetB = b;
        float usableW = Math.max(1f, width - l - rt);
        float usableH = Math.max(1f, height - t - b);
        for (int i = 0; i < ControlSettings.COUNT; i++) {
            float rad = baseRadiusDp(i) * dens * s.scale[i];
            r[i] = rad;
            cx[i] = clampAxis(l + s.x[i] * usableW, l + rad, width - rt - rad);
            cy[i] = clampAxis(t + s.y[i] * usableH, t + rad, height - b - rad);
        }
    }

    /** Touch radius of a control: a little larger than it looks; sticks get a generous grab area. */
    public float hitRadius(int control) {
        switch (control) {
            case ControlSettings.PAUSE: return r[control] * 1.27f;
            case ControlSettings.RELOAD: return r[control] * 1.14f;
            case ControlSettings.DODGE: return r[control] * 1.2f;
            case ControlSettings.FIRE: return r[control] * 1.12f;
            default: return r[control] * 1.5f;
        }
    }

    public boolean inside(int control, float px, float py) {
        float dx = px - cx[control];
        float dy = py - cy[control];
        float hr = hitRadius(control);
        return dx * dx + dy * dy <= hr * hr;
    }

    /** Normalised x (0..1 of the usable width) for a control centred at pixel {@code px}, kept on screen. */
    public float normalizeX(int control, float px) {
        float usable = Math.max(1f, width - insetL - insetR);
        float c = clampAxis(px, insetL + r[control], width - insetR - r[control]);
        return (c - insetL) / usable;
    }

    public float normalizeY(int control, float py) {
        float usable = Math.max(1f, height - insetT - insetB);
        float c = clampAxis(py, insetT + r[control], height - insetB - r[control]);
        return (c - insetT) / usable;
    }

    private static float clampAxis(float v, float lo, float hi) {
        if (lo > hi) return (lo + hi) * 0.5f;
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
