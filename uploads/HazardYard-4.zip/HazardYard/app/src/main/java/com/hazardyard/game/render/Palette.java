package com.hazardyard.game.render;

/** Colour tokens shared by the world renderer, HUD and menus (ARGB ints). */
public final class Palette {
    private Palette() {}

    // arena
    public static final int BACKDROP = 0xFF10151C;
    public static final int FLOOR = 0xFF222B36;
    public static final int FLOOR_LINE = 0xFF2B3644;
    public static final int FLOOR_DECAL = 0xFF34424F;
    public static final int WALL_EDGE = 0xFF262E3A;
    public static final int WALL_BODY = 0xFF506076;
    public static final int WALL_TOP = 0xFF8596B0;
    public static final int WALL_SEAM = 0x33141A22;
    public static final int CRATE_DARK = 0xFF7A4F20;
    public static final int CRATE_BODY = 0xFFB27A35;
    public static final int CRATE_LIGHT = 0xFFD9A35B;
    public static final int SHADOW = 0x59000000;

    // interface
    public static final int ACCENT = 0xFFF2C230;
    public static final int ACCENT_DARK = 0xFF2A2208;
    public static final int PANEL = 0xB3131A22;
    public static final int PANEL_SOLID = 0xFF151C25;
    public static final int PANEL_EDGE = 0x33FFFFFF;
    public static final int TEXT = 0xFFF2F5F8;
    public static final int TEXT_DIM = 0xFF9AA7B8;
    public static final int GOOD = 0xFF6DD47E;
    public static final int WARN = 0xFFF2C230;
    public static final int BAD = 0xFFFF5A5F;
    public static final int SHIELD = 0xFF7FE7FF;

    /** Replaces the alpha channel of an ARGB colour. */
    public static int withAlpha(int argb, int alpha) {
        return (alpha << 24) | (argb & 0x00FFFFFF);
    }
}
