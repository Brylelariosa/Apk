package com.hazardyard.game.net;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Common face of {@link HostManager} and {@link ClientManager}. Network threads push complete
 * messages into a queue; the game thread drains it once per simulation step, so no game state is
 * ever touched from a network thread.
 */
public abstract class NetworkManager {
    /** One received message. {@code data[0]} is the type byte. */
    public static final class Inbound {
        /** Sender slot when this is the host, -1 for messages that came from the host. */
        public final int from;
        public final byte[] data;

        public Inbound(int from, byte[] data) {
            this.from = from;
            this.data = data;
        }
    }

    /** Messages beyond this are dropped: it only happens when the game thread is not running. */
    private static final int MAX_BACKLOG = 4000;

    private final ConcurrentLinkedQueue<Inbound> inbound = new ConcurrentLinkedQueue<>();
    private final AtomicInteger backlog = new AtomicInteger();
    /** Round-trip time in milliseconds (clients only; 0 until measured). */
    public volatile int pingMs;

    /** Called by network threads. */
    protected void enqueue(Inbound m) {
        if (backlog.get() >= MAX_BACKLOG) return;
        backlog.incrementAndGet();
        inbound.add(m);
    }

    protected void clearInbound() {
        while (inbound.poll() != null) backlog.decrementAndGet();
    }

    /** Called by the game thread once per step until it returns null. */
    public Inbound poll() {
        Inbound m = inbound.poll();
        if (m != null) backlog.decrementAndGet();
        return m;
    }

    public abstract boolean isHost();

    public abstract int localPlayerId();

    public abstract boolean isClosed();

    public abstract void close();
}
