package com.hazardyard.game.core;

/** One distinct colour per player slot (ARGB), shared by the world renderer, HUD and lobby. */
public final class PlayerColors {
    private PlayerColors() {}

    public static final int[] ARGB = {
        0xFFFF5A5F, // coral
        0xFF2EC4E6, // cyan
        0xFF8FD14F, // lime
        0xFFB48CFF, // violet
    };

    public static int of(int slot) {
        return ARGB[((slot % ARGB.length) + ARGB.length) % ARGB.length];
    }
}
