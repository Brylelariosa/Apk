package com.hazardyard.game.core;

/** The local player's controls for one simulation step. */
public final class LocalInput {
    /** Movement direction, each axis in [-1, 1] (analog). */
    public float moveX, moveY;
    /** Facing the player wants, in radians. Keeps its last value when the aim stick is released. */
    public float aim;
    /** Aim stick is beyond its dead zone: fire the equipped weapon. */
    public boolean firing;
    /** One-shot: reload was pressed since the previous sample. */
    public boolean reload;
    /** One-shot: the dodge button was pressed since the previous sample. */
    public boolean dodge;

    public void clear() {
        moveX = 0f;
        moveY = 0f;
        firing = false;
        reload = false;
        dodge = false;
    }

    /** Rounds the movement axes to the precision that travels over the network (1/127). */
    public void quantizeMove() {
        moveX = Math.round(MathUtil.clamp(moveX, -1f, 1f) * 127f) / 127f;
        moveY = Math.round(MathUtil.clamp(moveY, -1f, 1f) * 127f) / 127f;
    }
}
