package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.render.model.FaceSink;

/** Draws the polygons of a 3D object on a canvas, re-using one Path and one Paint. */
final class PolyDrawer implements FaceSink {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private Canvas canvas;

    PolyDrawer() {
        // A hairline stroke in the same colour closes the faint seams anti-aliasing leaves between
        // neighbouring faces of one object.
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setStrokeWidth(0.5f);
        paint.setStrokeJoin(Paint.Join.ROUND);
    }

    void begin(Canvas c) {
        canvas = c;
    }

    @Override
    public void polygon(float[] xs, float[] ys, int offset, int count, int argb) {
        path.reset();
        path.moveTo(xs[offset], ys[offset]);
        for (int i = 1; i < count; i++) path.lineTo(xs[offset + i], ys[offset + i]);
        path.close();
        paint.setColor(argb);
        canvas.drawPath(path, paint);
    }
}
