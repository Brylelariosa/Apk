package com.hazardyard.game.core;

/**
 * The dodge roll. A roll is a short committed dash in one direction: the player cannot be hit while
 * it lasts (apart from the landing at the very end), cannot shoot, and has to wait for a cooldown
 * before the next one. The host runs it inside {@link GameWorld}; a client runs the very same steps
 * for its own player so the roll feels instant. Both call these functions, so they move identically.
 */
public final class Dodge {
    private Dodge() {}

    /** Part of the roll at full speed; after it the roll eases out. */
    private static final float HOLD = 0.55f;
    /** Speed left at the very end of the roll (share of the peak). */
    private static final float END_SPEED = 0.35f;

    /** Share of the peak speed at roll progress 0..1. */
    public static float speedFactor(float progress) {
        if (progress <= HOLD) return 1f;
        float k = MathUtil.clamp((progress - HOLD) / (1f - HOLD), 0f, 1f);
        return 1f - (1f - END_SPEED) * k;
    }

    /** 0 at the start of the roll, 1 at its end. */
    public static float progress(Player p) {
        return MathUtil.clamp(1f - p.rollTimer / GameConfig.DODGE_DURATION, 0f, 1f);
    }

    /** True when a roll may start now; {@code grace} lets a nearly finished cooldown count as finished. */
    public static boolean canStart(Player p, float grace) {
        return p.alive && p.rollTimer <= 0f && p.dodgeCooldown <= grace;
    }

    /** Starts a roll along (dx, dy). A zero or invalid vector rolls the way the player is facing. */
    public static void start(Player p, float dx, float dy) {
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (!MathUtil.isFinite(len) || len < 1e-4f) {
            dx = (float) Math.cos(p.aim);
            dy = (float) Math.sin(p.aim);
        } else {
            dx /= len;
            dy /= len;
        }
        p.rollDirX = dx;
        p.rollDirY = dy;
        p.rollTimer = GameConfig.DODGE_DURATION;
        p.dodgeCooldown = GameConfig.DODGE_COOLDOWN;
    }

    /** Advances a running roll by {@code dt}: moves the player (sliding along walls) and ages the roll. */
    public static void step(Player p, CollisionSystem col, float dt) {
        if (p.rollTimer <= 0f) return;
        float dist = GameConfig.DODGE_SPEED * speedFactor(progress(p)) * dt;
        col.moveCircle(p.x, p.y, p.rollDirX * dist, p.rollDirY * dist, GameConfig.PLAYER_RADIUS);
        p.x = col.resX;
        p.y = col.resY;
        p.rollTimer = Math.max(0f, p.rollTimer - dt);
    }

    public static void tickCooldown(Player p, float dt) {
        if (p.dodgeCooldown > 0f) p.dodgeCooldown = Math.max(0f, p.dodgeCooldown - dt);
    }

    /** Bullets pass through a rolling player, except during the landing at the end of the roll. */
    public static boolean invulnerable(Player p) {
        return p.rollTimer > GameConfig.DODGE_VULNERABLE_TAIL;
    }

    /**
     * The direction to roll when the player did not choose one: the way they are moving, or the way
     * they face when standing still. The unit vector is left in {@code out[0], out[1]}.
     */
    public static void pickDirection(float moveX, float moveY, float aim, float[] out) {
        float len = (float) Math.sqrt(moveX * moveX + moveY * moveY);
        if (MathUtil.isFinite(len) && len > 0.2f) {
            out[0] = moveX / len;
            out[1] = moveY / len;
        } else {
            out[0] = (float) Math.cos(aim);
            out[1] = (float) Math.sin(aim);
        }
    }
}
