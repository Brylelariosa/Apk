package com.hazardyard.game.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

import com.hazardyard.game.render.Palette;

/**
 * Menu background: the arena floor grid, a soft vignette and hazard-striped bands along the top and
 * bottom edge. Drawn once per size change into paints; nothing is allocated while drawing.
 */
final class BackdropView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint grid = new Paint();
    private final Paint vignette = new Paint();
    private final Path stripe = new Path();
    private final float tile;
    private final float band;
    private final float stripeW;

    BackdropView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        tile = 40f * d;
        band = 10f * d;
        stripeW = 14f * d;
        grid.setColor(Palette.FLOOR_LINE);
        grid.setStrokeWidth(Math.max(1f, d));
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        float r = (float) Math.hypot(w, h) * 0.6f;
        vignette.setShader(new RadialGradient(w * 0.5f, h * 0.5f, r, new int[] {0x00000000, 0xCC05080C}, null,
                Shader.TileMode.CLAMP));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        canvas.drawColor(Palette.FLOOR);
        for (float x = 0f; x < w; x += tile) canvas.drawLine(x, 0f, x, h, grid);
        for (float y = 0f; y < h; y += tile) canvas.drawLine(0f, y, w, y, grid);
        canvas.drawRect(0f, 0f, w, h, vignette);
        drawStripes(canvas, 0f, 0f, w, band);
        drawStripes(canvas, 0f, h - band, w, h);
    }

    private void drawStripes(Canvas canvas, float l, float t, float r, float b) {
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xFF0E1218);
        canvas.drawRect(l, t, r, b, fill);
        fill.setColor(Palette.ACCENT);
        canvas.save();
        canvas.clipRect(l, t, r, b);
        float hgt = b - t;
        for (float x = l - hgt; x < r + hgt; x += stripeW * 2f) {
            stripe.reset();
            stripe.moveTo(x, b);
            stripe.lineTo(x + stripeW, b);
            stripe.lineTo(x + stripeW + hgt, t);
            stripe.lineTo(x + hgt, t);
            stripe.close();
            canvas.drawPath(stripe, fill);
        }
        canvas.restore();
    }

    /** A short striped bar used as a title underline. */
    static final class StripeBar extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path stripe = new Path();
        private final float stripeW;

        StripeBar(Context c) {
            super(c);
            stripeW = 9f * c.getResources().getDisplayMetrics().density;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float w = getWidth();
            float h = getHeight();
            fill.setColor(0xFF0E1218);
            canvas.drawRect(0f, 0f, w, h, fill);
            fill.setColor(Palette.ACCENT);
            canvas.save();
            canvas.clipRect(0f, 0f, w, h);
            for (float x = -h; x < w + h; x += stripeW * 2f) {
                stripe.reset();
                stripe.moveTo(x, h);
                stripe.lineTo(x + stripeW, h);
                stripe.lineTo(x + stripeW + h, 0f);
                stripe.lineTo(x + h, 0f);
                stripe.close();
                canvas.drawPath(stripe, fill);
            }
            canvas.restore();
        }
    }
}
