package com.hazardyard.game.core;

/**
 * Built-in arenas, from the compact Hazard Yard up to the sprawling Ruined Outpost. Each map is
 * authored as a fraction (a quarter, or the top half) and mirrored, so no spawn point is favoured.
 * Besides rectangular walls and crates they use round pillars and tanks and angled corner pieces;
 * Rotunda Plaza is the open one.
 *
 * <p>Maps are immutable once parsed, so one shared instance per id is handed out.
 */
public final class MapLibrary {
    private MapLibrary() {}

    public static final int HAZARD_YARD = 0;
    public static final int DOCKSIDE = 1;
    public static final int FOUNDRY = 2;
    public static final int OUTPOST = 3;
    public static final int BUNKER = 4;
    public static final int ROTUNDA = 5;
    public static final int SILO_YARD = 6;
    public static final int DIAMOND_HALL = 7;
    public static final int COUNT = 8;
    public static final int DEFAULT_ID = HAZARD_YARD;

    private static final String[] NAMES = {
        "Hazard Yard", "Dockside Warehouse", "Toxic Foundry", "Ruined Outpost", "Bunker Complex",
        "Rotunda Plaza", "Silo Yard", "Diamond Hall",
    };
    private static final String[] BLURBS = {
        "Compact arena. Fast duels around a toxic yard and a fenced centre pit.",
        "Long storage racks split by a canal. Three bridges, lots of sightlines.",
        "Pump rooms and conveyors around a reactor island ringed by a toxic moat.",
        "Huge open ruins with an oasis in the middle. Long-range fights, little cover.",
        "Tight corridors and rooms. Close combat around a central vault.",
        "Wide open octagon of round pillars around a central tank. Long sightlines, light cover.",
        "Big round silos linked by fences around a toxic sump. Mixed ranges, lots of corners.",
        "Angled walls and chevron halls around a central tank. Tricky flanks.",
    };

    private static final TileMap[] CACHE = new TileMap[COUNT];

    public static int clampId(int id) {
        return id < 0 || id >= COUNT ? DEFAULT_ID : id;
    }

    public static String name(int id) {
        return NAMES[clampId(id)];
    }

    public static String blurb(int id) {
        return BLURBS[clampId(id)];
    }

    /** "41 x 25 tiles" style size line. */
    public static String sizeText(int id) {
        TileMap m = get(id);
        return m.width + " \u00D7 " + m.height + " tiles  \u00B7  " + m.pickupX.length + " weapons";
    }

    /** The map with this id (an unknown id gives the default map). */
    public static synchronized TileMap get(int id) {
        id = clampId(id);
        if (CACHE[id] == null) CACHE[id] = build(id);
        return CACHE[id];
    }

    /** The default (smallest) arena. */
    public static TileMap arena() {
        return get(DEFAULT_ID);
    }

    private static TileMap build(int id) {
        switch (id) {
            case DOCKSIDE: return TileMap.parse(id, rotate180(DOCKSIDE_TOP));
            case FOUNDRY: return TileMap.parse(id, mirrorBoth(FOUNDRY_QUARTER));
            case OUTPOST: return TileMap.parse(id, mirrorBoth(OUTPOST_QUARTER));
            case BUNKER: return TileMap.parse(id, mirrorBoth(BUNKER_QUARTER));
            case ROTUNDA: return TileMap.parse(id, mirrorEven(ROTUNDA_QUARTER));
            case SILO_YARD: return TileMap.parse(id, mirrorEven(SILO_QUARTER));
            case DIAMOND_HALL: return TileMap.parse(id, mirrorEven(DIAMOND_QUARTER));
            default: return TileMap.parse(id, mirrorBoth(HAZARD_YARD_QUARTER));
        }
    }

    /** Angled pieces keep their meaning when a map is mirrored: their filled corner has to move with the mirror. */
    private static char flipH(char c) {
        switch (c) {
            case '7': return '9';
            case '9': return '7';
            case '1': return '3';
            case '3': return '1';
            default: return c;
        }
    }

    private static char flipV(char c) {
        switch (c) {
            case '7': return '1';
            case '1': return '7';
            case '9': return '3';
            case '3': return '9';
            default: return c;
        }
    }

    /** Mirrors the top-left quarter (which includes the centre column and the centre row) on both axes. */
    private static String[] mirrorBoth(String[] quarter) {
        int qh = quarter.length;
        int qw = quarter[0].length();
        String[] rows = new String[qh * 2 - 1];
        for (int y = 0; y < qh; y++) {
            String q = quarter[y];
            StringBuilder top = new StringBuilder(qw * 2 - 1);
            top.append(q);
            for (int x = qw - 2; x >= 0; x--) top.append(flipH(q.charAt(x)));
            rows[y] = top.toString();
            rows[rows.length - 1 - y] = flipRowV(rows[y]);
        }
        return rows;
    }

    /**
     * Mirrors the top-left quarter on both axes without sharing a centre row or column, which gives a
     * map of even size. A single {@code T} in the quarter's bottom-right corner becomes one big tank
     * exactly in the middle of the map.
     */
    private static String[] mirrorEven(String[] quarter) {
        int qh = quarter.length;
        int qw = quarter[0].length();
        String[] rows = new String[qh * 2];
        for (int y = 0; y < qh; y++) {
            String q = quarter[y];
            StringBuilder top = new StringBuilder(qw * 2);
            top.append(q);
            for (int x = qw - 1; x >= 0; x--) top.append(flipH(q.charAt(x)));
            rows[y] = top.toString();
            rows[rows.length - 1 - y] = flipRowV(rows[y]);
        }
        return rows;
    }

    private static String flipRowV(String row) {
        StringBuilder sb = new StringBuilder(row.length());
        for (int i = 0; i < row.length(); i++) sb.append(flipV(row.charAt(i)));
        return sb.toString();
    }

    /** Completes the top half (which includes the centre row) by rotating it 180 degrees. */
    private static String[] rotate180(String[] top) {
        int th = top.length;
        String[] rows = new String[th * 2 - 1];
        for (int y = 0; y < th; y++) rows[y] = top[y];
        for (int y = th - 2; y >= 0; y--) {
            String src = top[y];
            StringBuilder sb = new StringBuilder(src.length());
            for (int x = src.length() - 1; x >= 0; x--) sb.append(flipV(flipH(src.charAt(x))));
            rows[th + (th - 2 - y)] = sb.toString();
        }
        return rows;
    }

    // Legend: # wall, C crate, + fence (thin, bullets pass), ~ toxic pool (bullets pass), O round pillar,
    // T tank (2 x 2 round), 7 9 1 3 angled pieces (filled top-left / top-right / bottom-left / bottom-right,
    // written for the top-left quarter; mirroring flips them), S spawn,
    // R rifle, G shotgun, M SMG, N sniper, V magnum, P plasma, K light MG.
    private static final String[] HAZARD_YARD_QUARTER = {
        "#####################",
        "##7...#.............V",
        "#7S...#...TT.....O...",
        "#.....#...TT..R......",
        "#............~~......",
        "#####.##.....~~.##...",
        "#....M.......+...#...",
        "#............+...#...",
        "#..S...CC....+.......",
        "#......CC........O...",
        "#.......G...#+++##...",
        "#...........#........",
        "#...........#...+++.P",
    };

    private static final String[] DOCKSIDE_TOP = {
        "#######################################################",
        "####++###++##.....................................CCCC#",
        "##..........#..............N..........CC..............#",
        "##.CC....S..#..................................#......#",
        "##...............############....############..#......#",
        "##.S......C....C...............................#..CC..#",
        "##........C.#..CR.............CC........M......#..CC..#",
        "######..#####..................................#......#",
        "#.............########...############...#####..#......#",
        "#....K.................G.........................+++++#",
        "#...................S...............S..........V......#",
        "#.########...#######..###....#####...######..CC.......#",
        "#..........C..............CC...M.............CC....C..#",
        "#~~~~~~~~...~~~~~~~~~~~~~.....~~~~~~~~~~~~~...~~~~~~~~#",
        "#~~~~~~~~...~~~~~~~~~~~~~.....~~~~~~~~~~~~~...~~~~~~~~#",
        "#...................CC...........CC...................#",
        "#...................CC.....P.....CC...................#",
    };

    private static final String[] FOUNDRY_QUARTER = {
        "##############################",
        "###########..................N",
        "##...CC...+........######.....",
        "##.S......+.TT.#............CC",
        "##..........TT.#..............",
        "##.....S.......#.~~.......~...",
        "##........#......~~.......~...",
        "###+#..####.....R.........~...",
        "#............................V",
        "#.............#######....O....",
        "#..........G..#...............",
        "#..#..........#.......~~~~~~..",
        "#..#..++++....#.......~~~~~~..",
        "#..#..........#.......~~~~~~..",
        "#..#..O..........TT...~~~#....",
        "#..#....~~~~.....TT...~~~.C...",
        "#.......~~~~..................",
        "#.K..........................P",
    };

    private static final String[] OUTPOST_QUARTER = {
        "#################################",
        "#..#.CC..#.......................",
        "#..#...S.#......................N",
        "#....S...#...####.........#......",
        "#........#......#.........#......",
        "#..........R....#.........###....",
        "########.#........O........O.....",
        "#................................",
        "#...........C.O......####.....C..",
        "#....................#........C..",
        "#....................#...........",
        "#....####............#..........P",
        "#.......#.........#..............",
        "#.......#....CC...#.....O#.......",
        "#............CC.....K....#.C.+...",
        "#..CC.........O..........#.~~~~~~",
        "#..CC.G...................C~~~~~~",
        "#.......O.........CC.......~~~~~~",
        "#.........#####............~~~~~~",
        "#..........................~~~~~~",
    };

    private static final String[] BUNKER_QUARTER = {
        "########################",
        "#............#..........",
        "#.###++###.C.#.....CC...",
        "#.#C...S.#...#..........",
        "#.#.S........#..#####...",
        "#.#.........R...#.......",
        "#.#......#......#.......",
        "#.###..###...#...####...",
        "#............#.C.#.....#",
        "#............#.C....C..#",
        "#######..#...#...#.....#",
        "#........#.......##+####",
        "#...CC...#.....M........",
        "#.G.CC...#####...#...CCV",
        "#................#......",
        "#...........CC...#.....P",
    };

    private static final String[] ROTUNDA_QUARTER = {
        "########7#################",
        "#######7..................",
        "######7..........C........",
        "#####7.....CC.............",
        "####7............N........",
        "###7..................O...",
        "##7.......................",
        "#7....S...................",
        "7...............O.........",
        "#.........................",
        "#......CC.....R........O..",
        "#......CC.................",
        "#...................O.....",
        "#..S..................P...",
        "#........###.O............",
        "#...C....#........O.......",
        "#...C...G.................",
        "#...................+++..T",
    };

    private static final String[] SILO_QUARTER = {
        "####7#######################",
        "###7........................",
        "##7.........................",
        "#7...TT....TT....TT...N...#.",
        "7....TT++++TT++++TT.......#.",
        "#..S...............+++++..#.",
        "#...........R.............#.",
        "#.#####.....................",
        "#.......TT....TT.....TT.CC..",
        "#.......TT....TT.....TT.CC..",
        "#.C......+.....+............",
        "#.C......+.....+............",
        "#...TT...+.....+....#######.",
        "#...TT....TT.CC...#.........",
        "#......S..TT.CC...#.P...~~~~",
        "#..G..............#.....~~~~",
        "#.................#.....~~~~",
    };

    private static final String[] DIAMOND_QUARTER = {
        "#####7##################",
        "####7...................",
        "###7.............###.CC.",
        "##7............N........",
        "#7.........37...........",
        "7.........37............",
        "#......S.37...........37",
        "#.......37..+........37.",
        "#.###.......+.....P.37..",
        "#.........K........37...",
        "#....37...........37....",
        "#..S37........#..37O....",
        "#..37...CC....#.........",
        "#.++....CC....#.........",
        "#....V........#.........",
        "#......................T",
    };
}
