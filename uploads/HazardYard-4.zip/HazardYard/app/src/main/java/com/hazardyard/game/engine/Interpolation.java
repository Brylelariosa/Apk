package com.hazardyard.game.engine;

import com.hazardyard.game.core.Dodge;
import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Player;

/**
 * Smooth drawing of players that are simulated in fixed steps (the host, a solo match, and the
 * predicted local player of a client). The simulation runs at a fixed rate while the screen may
 * refresh at 60, 90 or 120 Hz, so the drawn position is blended between the state before the last
 * step ({@code from}) and after it ({@code to}). Without this, motion visibly stutters whenever the
 * two rates do not match.
 */
final class Interpolation {
    private Interpolation() {}

    /** A move bigger than this in one step is a teleport (respawn), not movement, and is never blended. */
    private static final float TELEPORT = 48f;

    /** Call before a fixed step: remembers where everybody is. */
    static void begin(GameState st) {
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            p.fromX = p.x;
            p.fromY = p.y;
            p.fromAim = p.aim;
        }
    }

    /** Call after a fixed step: remembers where everybody ended up and draws them there until the next frame blends. */
    static void end(GameState st) {
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            float dx = p.x - p.fromX;
            float dy = p.y - p.fromY;
            if (dx * dx + dy * dy > TELEPORT * TELEPORT) {
                p.fromX = p.x;
                p.fromY = p.y;
                p.fromAim = p.aim;
            }
            p.toX = p.x;
            p.toY = p.y;
            p.toAim = p.aim;
            p.rx = p.x;
            p.ry = p.y;
            p.rAim = p.aim;
            p.rollU = p.isRolling() ? Dodge.progress(p) : 0f;
        }
    }

    /** Once per frame: draws every simulated player {@code alpha} of the way from its previous state to its current one. */
    static void apply(GameState st, float alpha) {
        float a = MathUtil.clamp(alpha, 0f, 1f);
        st.renderAlpha = a;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            p.rx = p.fromX + (p.toX - p.fromX) * a;
            p.ry = p.fromY + (p.toY - p.fromY) * a;
            p.rAim = MathUtil.lerpAngle(p.fromAim, p.toAim, a);
            p.rollU = rollProgress(p, a);
        }
    }

    /** Roll progress as drawn: the state of the last step, taken back by the part of a step that has not happened yet. */
    static float rollProgress(Player p, float alpha) {
        if (!p.isRolling()) return 0f;
        float u = Dodge.progress(p) - (1f - alpha) * GameConfig.SIM_DT / GameConfig.DODGE_DURATION;
        return MathUtil.clamp(u, 0f, 1f);
    }
}
