package com.hazardyard.game.render.model;

/** Receives the finished, depth-sorted, shaded polygons of one 3D object. */
public interface FaceSink {
    /**
     * @param xs    screen x of the vertices, starting at {@code offset}
     * @param ys    screen y of the vertices, starting at {@code offset}
     * @param count number of vertices
     * @param argb  final colour including lighting
     */
    void polygon(float[] xs, float[] ys, int offset, int count, int argb);
}
