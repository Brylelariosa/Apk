package com.hazardyard.game.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import com.hazardyard.game.input.ControlGeometry;
import com.hazardyard.game.render.ControlsRenderer;
import com.hazardyard.game.render.Palette;
import com.hazardyard.game.settings.ControlSettings;
import com.hazardyard.game.settings.GameSettings;

/**
 * Full-screen editor for the on-screen controls. Drag a control to move it, pinch it or use the
 * size slider to resize it, and use Options for fixed / floating sticks, how firing works (stick,
 * fire button or both, and how far the stick must be pushed to fire), the aim dead zone and opacity. Works on a copy: Save writes it back, Cancel throws it away. Used both
 * from Settings and over a paused match.
 */
final class ControlsEditorView extends FrameLayout {
    interface Listener {
        /** The editor finished; {@code saved} tells whether the changes were kept. */
        void onClose(boolean saved);
    }

    private final GameSettings live;
    private final ControlSettings work = new ControlSettings();
    private final Listener listener;
    private final float density;

    private final EditorCanvas canvas;
    private final SliderRow sizeRow;
    private final View optionsCard;
    private final FrameLayout.LayoutParams barParams;
    private final FrameLayout.LayoutParams sizeParams;
    private final FrameLayout.LayoutParams optionsParams;
    private SegmentedControl moveMode;
    private SegmentedControl aimMode;
    private SegmentedControl fireMode;
    private SliderRow fireLevel;
    private SliderRow deadZone;
    private SliderRow opacity;

    private int selected = -1;
    private int insetL, insetT, insetR, insetB;

    ControlsEditorView(Context c, GameSettings settings, Listener listener) {
        super(c);
        this.live = settings;
        this.listener = listener;
        this.density = c.getResources().getDisplayMetrics().density;
        work.copyFrom(settings.controls);
        setClickable(true);

        canvas = new EditorCanvas(c);
        addView(canvas, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- top bar ----
        LinearLayout bar = Ui.row(c);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.rounded(c, 0xE6121A23, 0xFF3A4757, 14f, 1.5f));
        bar.setPadding(Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8), Ui.dp(c, 6));
        Button cancel = Ui.smallButton(c, "Cancel", false);
        Button reset = Ui.smallButton(c, "Reset", false);
        Button options = Ui.smallButton(c, "Options", false);
        Button save = Ui.smallButton(c, "Save", true);
        bar.addView(cancel, Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(c, 40), 0f, 0, 0, 6, 0, c));
        bar.addView(reset, Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(c, 40), 0f, 0, 0, 6, 0, c));
        bar.addView(options, Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(c, 40), 0f, 0, 0, 6, 0, c));
        bar.addView(save, Ui.lp(ViewGroup.LayoutParams.WRAP_CONTENT, Ui.dp(c, 40), 0f, 0, 0, 0, 0, c));
        barParams = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        addView(bar, barParams);

        // ---- size of the selected control ----
        sizeRow = new SliderRow(c, "Tap a control to select it", ControlSettings.SCALE_MIN, ControlSettings.SCALE_MAX, 1f,
                SliderRow.percent(), new SliderRow.OnValue() {
                    @Override
                    public void onValue(float value) {
                        if (selected >= 0) {
                            work.scale[selected] = value;
                            canvas.relayout();
                        }
                    }
                });
        sizeRow.setBackground(Ui.rounded(c, 0xE6121A23, 0xFF3A4757, 14f, 1.5f));
        sizeRow.setPadding(Ui.dp(c, 14), Ui.dp(c, 8), Ui.dp(c, 14), Ui.dp(c, 4));
        sizeRow.setSliderEnabled(false);
        sizeParams = new LayoutParams(Ui.dp(c, 300), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        addView(sizeRow, sizeParams);

        // ---- options card ----
        ScrollView scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout card = Ui.panel(c);
        scroll.addView(card, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(Ui.label(c, "Control options", 20f, Palette.TEXT, true));

        card.addView(Ui.label(c, "Move stick", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 12));
        moveMode = new SegmentedControl(c, new String[] {"Fixed", "Floating"}, work.moveFloating ? 1 : 0, new SegmentedControl.OnChange() {
            @Override
            public void onChange(int i) {
                work.moveFloating = i == 1;
                canvas.invalidate();
            }
        });
        card.addView(moveMode, Ui.fillWidth(c, 4));

        card.addView(Ui.label(c, "Aim stick", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 12));
        aimMode = new SegmentedControl(c, new String[] {"Fixed", "Floating"}, work.aimFloating ? 1 : 0, new SegmentedControl.OnChange() {
            @Override
            public void onChange(int i) {
                work.aimFloating = i == 1;
                canvas.invalidate();
            }
        });
        card.addView(aimMode, Ui.fillWidth(c, 4));
        card.addView(Ui.label(c, "Fixed: the stick stays where you put it. Floating: it appears under your thumb.", 11f,
                Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));

        card.addView(Ui.label(c, "Firing", 13f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 12));
        fireMode = new SegmentedControl(c, new String[] {"Stick fires", "Button fires", "Both"}, work.fireMode, new SegmentedControl.OnChange() {
            @Override
            public void onChange(int i) {
                work.fireMode = i;
                fireLevel.setSliderEnabled(work.stickFires());
                if (selected == ControlSettings.FIRE && !work.fireButtonEnabled()) select(-1);
                canvas.invalidate();
            }
        });
        card.addView(fireMode, Ui.fillWidth(c, 4));
        card.addView(Ui.label(c, "Stick fires: push the aim stick out to shoot. Button fires: the stick only aims and the "
                + "fire button shoots. Both: either one shoots.", 11f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));

        fireLevel = new SliderRow(c, "Stick fires at", ControlSettings.FIRE_THRESHOLD_MIN, ControlSettings.FIRE_THRESHOLD_MAX,
                work.fireThreshold, SliderRow.percent(), new SliderRow.OnValue() {
                    @Override
                    public void onValue(float v) {
                        work.fireThreshold = v;
                        canvas.invalidate();
                    }
                });
        fireLevel.setSliderEnabled(work.stickFires());
        card.addView(fireLevel, Ui.fillWidth(c, 12));
        card.addView(Ui.label(c, "How far the aim stick must be pushed before the gun fires (100% = all the way out). "
                + "Between the dead zone and this ring the stick only aims.", 11f, Palette.TEXT_DIM, false), Ui.fillWidth(c, 4));

        deadZone = new SliderRow(c, "Aim dead zone", ControlSettings.DEAD_ZONE_MIN, ControlSettings.DEAD_ZONE_MAX, work.aimDeadZone,
                SliderRow.percent(), new SliderRow.OnValue() {
                    @Override
                    public void onValue(float v) {
                        work.aimDeadZone = v;
                        canvas.invalidate();
                    }
                });
        card.addView(deadZone, Ui.fillWidth(c, 12));
        opacity = new SliderRow(c, "Control opacity", ControlSettings.OPACITY_MIN, ControlSettings.OPACITY_MAX, work.opacity,
                SliderRow.percent(), new SliderRow.OnValue() {
                    @Override
                    public void onValue(float v) {
                        work.opacity = v;
                        canvas.invalidate();
                    }
                });
        card.addView(opacity, Ui.fillWidth(c, 6));

        Button close = Ui.button(c, "Done", true);
        card.addView(close, Ui.fillWidth(c, 14));
        optionsCard = scroll;
        optionsCard.setVisibility(GONE);
        optionsParams = new LayoutParams(Ui.dp(c, 360), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        addView(optionsCard, optionsParams);

        cancel.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(false);
            }
        });
        save.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(true);
            }
        });
        reset.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                work.reset();
                syncOptions();
                canvas.relayout();
            }
        });
        options.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                optionsCard.setVisibility(VISIBLE);
            }
        });
        close.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                optionsCard.setVisibility(GONE);
            }
        });
        applyMargins();
    }

    /** Safe-area insets in pixels: the bars and the layout stay clear of the camera cutout. */
    void setInsets(int l, int t, int r, int b) {
        insetL = l;
        insetT = t;
        insetR = r;
        insetB = b;
        applyMargins();
        canvas.relayout();
    }

    private void applyMargins() {
        int gap = Math.round(8f * density);
        barParams.topMargin = insetT + gap;
        barParams.leftMargin = insetL;
        barParams.rightMargin = insetR;
        sizeParams.topMargin = insetT + gap + Math.round(58f * density);
        optionsParams.topMargin = insetT + gap;
        optionsParams.bottomMargin = insetB + gap;
        optionsParams.leftMargin = insetL;
        optionsParams.rightMargin = insetR;
        requestLayout();
    }

    /** Back button: closes the options card first, then the editor (discarding changes). */
    boolean handleBack() {
        if (optionsCard.getVisibility() == VISIBLE) {
            optionsCard.setVisibility(GONE);
            return true;
        }
        finish(false);
        return true;
    }

    private void finish(boolean saved) {
        if (saved) {
            work.sanitize();
            live.controls.copyFrom(work);
        }
        listener.onClose(saved);
    }

    /** Pushes the working values into the option widgets (after a reset). */
    private void syncOptions() {
        moveMode.select(work.moveFloating ? 1 : 0);
        aimMode.select(work.aimFloating ? 1 : 0);
        fireMode.select(work.fireMode);
        fireLevel.setValue(work.fireThreshold);
        fireLevel.setSliderEnabled(work.stickFires());
        deadZone.setValue(work.aimDeadZone);
        opacity.setValue(work.opacity);
        select(selected);
    }

    private void select(int control) {
        if (control == ControlSettings.FIRE && !work.fireButtonEnabled()) control = -1;
        selected = control;
        if (control < 0) {
            sizeRow.setTitle("Tap a control to select it");
            sizeRow.setSliderEnabled(false);
        } else {
            sizeRow.setTitle(ControlSettings.nameOf(control) + " size");
            sizeRow.setValue(work.scale[control]);
            sizeRow.setSliderEnabled(true);
        }
        canvas.invalidate();
    }

    // ------------------------------------------------------------------ the drawing / dragging surface

    private final class EditorCanvas extends View {
        private final ControlGeometry geom = new ControlGeometry();
        private final ControlsRenderer renderer = new ControlsRenderer();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private boolean dragging;
        private boolean pinching;
        private int dragPointer = -1;
        private float grabDx, grabDy;
        private float pinchStartDist, pinchStartScale;

        EditorCanvas(Context c) {
            super(c);
        }

        void relayout() {
            if (getWidth() > 0) geom.compute(work, getWidth(), getHeight(), density, insetL, insetT, insetR, insetB);
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            relayout();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            c.drawColor(0xF4090D12);
            // grid
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(1f);
            paint.setColor(0x14FFFFFF);
            float step = 40f * density;
            for (float x = insetL % step; x < w; x += step) c.drawLine(x, 0f, x, h, paint);
            for (float y = insetT % step; y < h; y += step) c.drawLine(0f, y, w, y, paint);
            // safe area
            paint.setColor(0x33FFFFFF);
            paint.setStrokeWidth(1.5f);
            rect.set(insetL + 1f, insetT + 1f, w - insetR - 1f, h - insetB - 1f);
            c.drawRoundRect(rect, 10f * density, 10f * density, paint);
            // where the HUD lives, so controls are not parked on top of it
            drawHudHint(c, w, h);
            renderer.drawIdle(c, geom, work, selected, density);
        }

        private void drawHudHint(Canvas c, float w, float h) {
            paint.setColor(0x26FFFFFF);
            paint.setStrokeWidth(1.2f);
            float mid = insetL + (w - insetL - insetR) * 0.5f;
            rect.set(insetL + 10f * density, insetT + 10f * density, insetL + 150f * density, insetT + 96f * density);
            c.drawRoundRect(rect, 8f * density, 8f * density, paint);
            rect.set(mid - 110f * density, insetT + 8f * density, mid + 110f * density, insetT + 44f * density);
            c.drawRoundRect(rect, 8f * density, 8f * density, paint);
            rect.set(mid - 130f * density, h - insetB - 66f * density, mid + 130f * density, h - insetB - 10f * density);
            c.drawRoundRect(rect, 8f * density, 8f * density, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0x55FFFFFF);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(11f * density);
            c.drawText("Drag controls to move them. Pinch to resize.", mid, h * 0.5f + 4f * density, paint);
            paint.setTextAlign(Paint.Align.LEFT);
            paint.setStyle(Paint.Style.STROKE);
        }

        private int hitTest(float x, float y) {
            int best = -1;
            float bestD = Float.MAX_VALUE;
            float minGrab = 30f * density;
            for (int i = 0; i < ControlSettings.COUNT; i++) {
                if (i == ControlSettings.FIRE && !work.fireButtonEnabled()) continue;
                float dx = x - geom.cx[i];
                float dy = y - geom.cy[i];
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                float reach = Math.max(geom.r[i] * 1.2f, minGrab);
                if (d <= reach && d < bestD) {
                    bestD = d;
                    best = i;
                }
            }
            return best;
        }

        private float pointerDistance(MotionEvent e) {
            float dx = e.getX(0) - e.getX(1);
            float dy = e.getY(0) - e.getY(1);
            return (float) Math.sqrt(dx * dx + dy * dy);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    float x = e.getX();
                    float y = e.getY();
                    int hit = hitTest(x, y);
                    select(hit);
                    dragging = hit >= 0;
                    pinching = false;
                    if (dragging) {
                        dragPointer = e.getPointerId(0);
                        grabDx = geom.cx[hit] - x;
                        grabDy = geom.cy[hit] - y;
                    }
                    return true;
                }
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (selected >= 0 && e.getPointerCount() == 2) {
                        pinching = true;
                        dragging = false;
                        pinchStartDist = Math.max(1f, pointerDistance(e));
                        pinchStartScale = work.scale[selected];
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (pinching && e.getPointerCount() >= 2 && selected >= 0) {
                        float s = pinchStartScale * pointerDistance(e) / pinchStartDist;
                        s = Math.max(ControlSettings.SCALE_MIN, Math.min(ControlSettings.SCALE_MAX, s));
                        work.scale[selected] = s;
                        sizeRow.setValue(s);
                        relayout();
                    } else if (dragging && selected >= 0) {
                        for (int i = 0; i < e.getPointerCount(); i++) {
                            if (e.getPointerId(i) != dragPointer) continue;
                            work.x[selected] = geom.normalizeX(selected, e.getX(i) + grabDx);
                            work.y[selected] = geom.normalizeY(selected, e.getY(i) + grabDy);
                            relayout();
                            break;
                        }
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_UP:
                    pinching = false;
                    dragging = false;
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    pinching = false;
                    dragging = false;
                    return true;
                default:
                    return true;
            }
        }
    }
}
