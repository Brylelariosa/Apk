package com.hazardyard.game.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.hazardyard.game.audio.SoundEngine;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.engine.ClientEngine;
import com.hazardyard.game.engine.GameEngine;
import com.hazardyard.game.engine.HostEngine;
import com.hazardyard.game.engine.SoloEngine;
import com.hazardyard.game.net.ClientManager;
import com.hazardyard.game.net.HostManager;
import com.hazardyard.game.net.Protocol;
import com.hazardyard.game.settings.GameSettings;
import com.hazardyard.game.settings.SettingsStore;

import java.util.Random;

/**
 * Owns the app's navigation and the lifetime of the network session (lobby host or client
 * connection) and the running match. MainActivity is only a thin window host around this class.
 */
public final class AppController implements Navigator {
    private static final String PREFS = "hazardyard";
    private static final String KEY_NAME = "player_name";
    private static final String KEY_SOLO_MAP = "solo_map";
    private static final String KEY_SOLO_BOTS = "solo_bots";
    private static final String KEY_SOLO_DIFFICULTY = "solo_difficulty";

    private final Context ctx;
    private final FrameLayout root;
    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private Screen current;
    private HostManager host;
    private ClientManager client;
    private GameEngine engine;

    private final GameSettings settings;
    private volatile SoundEngine sound;
    private int insetL, insetT, insetR, insetB;
    private int soloMap, soloBots, soloDifficulty;
    private boolean soloActive;

    public AppController(Context context, FrameLayout rootView) {
        ctx = context;
        root = rootView;
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        settings = SettingsStore.load(prefs);
        soloMap = MapLibrary.clampId(prefs.getInt(KEY_SOLO_MAP, MapLibrary.DEFAULT_ID));
        soloBots = Math.max(1, Math.min(3, prefs.getInt(KEY_SOLO_BOTS, 2)));
        soloDifficulty = Math.max(0, Math.min(2, prefs.getInt(KEY_SOLO_DIFFICULTY, 1)));
    }

    public void start() {
        // Building the sound effects takes a moment; do it off the UI thread while the menu shows.
        Thread audioInit = new Thread(new Runnable() {
            @Override
            public void run() {
                sound = new SoundEngine(settings);
            }
        }, "hy-audio-init");
        audioInit.setDaemon(true);
        audioInit.start();
        showMenu(null);
    }

    /** The display cutout (camera hole) insets in pixels; screens keep their content clear of them. */
    public void setInsets(int l, int t, int r, int b) {
        insetL = l;
        insetT = t;
        insetR = r;
        insetB = b;
        if (current != null) current.onInsets(l, t, r, b);
    }

    /** Returns true when the current screen consumed the back press. */
    public boolean handleBack() {
        return current != null && current.onBack();
    }

    /** Closes everything; called when the activity is destroyed. */
    public void shutdown() {
        closeSession();
        SoundEngine s = sound;
        if (s != null) s.stop();
        if (current != null) {
            current.onHide();
            root.removeView(current.view());
            current = null;
        }
        ui.removeCallbacksAndMessages(null);
    }

    // ------------------------------------------------------------------ Navigator

    @Override
    public String playerName() {
        String n = prefs.getString(KEY_NAME, null);
        if (n == null || n.isEmpty()) {
            n = "Player" + (1000 + new Random().nextInt(9000));
            prefs.edit().putString(KEY_NAME, n).apply();
        }
        return n;
    }

    @Override
    public void setPlayerName(String name) {
        prefs.edit().putString(KEY_NAME, Protocol.sanitizeName(name)).apply();
    }

    @Override
    public void showMenu(String notice) {
        closeSession();
        show(new MenuScreen(ctx, this, notice));
    }

    @Override
    public GameSettings settings() {
        return settings;
    }

    @Override
    public void saveSettings() {
        SettingsStore.save(prefs, settings);
    }

    @Override
    public SoundEngine sound() {
        return sound;
    }

    @Override
    public void showSettings() {
        closeSession();
        show(new SettingsScreen(ctx, this));
    }

    @Override
    public void showControlsEditor() {
        show(new ControlsScreen(ctx, this));
    }

    @Override
    public void showSoloSetup() {
        closeSession();
        show(new SoloSetupScreen(ctx, this));
    }

    @Override
    public int[] soloChoices() {
        return new int[] {soloMap, soloBots, soloDifficulty};
    }

    @Override
    public void startSolo(int mapId, int bots, int difficulty) {
        closeSession();
        soloMap = MapLibrary.clampId(mapId);
        soloBots = Math.max(1, Math.min(3, bots));
        soloDifficulty = Math.max(0, Math.min(2, difficulty));
        prefs.edit().putInt(KEY_SOLO_MAP, soloMap).putInt(KEY_SOLO_BOTS, soloBots)
                .putInt(KEY_SOLO_DIFFICULTY, soloDifficulty).apply();
        soloActive = true;
        engine = new SoloEngine(soloMap, soloBots, soloDifficulty, playerName(), (int) System.nanoTime());
        show(new GameScreen(ctx, this, engine, false, true));
    }

    @Override
    public void restartSolo() {
        startSolo(soloMap, soloBots, soloDifficulty);
    }

    @Override
    public void showJoin() {
        closeSession();
        show(new JoinScreen(ctx, this));
    }

    @Override
    public void createGame() {
        closeSession();
        final HostManager h = new HostManager();
        host = h;
        final String name = playerName();
        Thread starter = new Thread(new Runnable() {
            @Override
            public void run() {
                Exception failure = null;
                try {
                    h.start(name);
                } catch (Exception e) {
                    failure = e;
                }
                final Exception f = failure;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (host != h) {
                            h.close();
                            return;
                        }
                        if (f != null) {
                            showMenu("Could not open a lobby: " + f.getMessage());
                        } else {
                            show(LobbyScreen.forHost(ctx, AppController.this));
                        }
                    }
                });
            }
        }, "hy-host-start");
        starter.start();
    }

    @Override
    public void connectTo(String address, int port) {
        closeSession();
        client = new ClientManager();
        show(LobbyScreen.forClientConnecting(ctx, this, address, port));
    }

    @Override
    public void startMatch() {
        if (engine != null) return;
        if (host != null) {
            boolean others = host.lobby().count() > 1;
            if (!host.startMatch()) {
                toast("Everyone needs to be ready first.");
                return;
            }
            engine = new HostEngine(host);
            show(new GameScreen(ctx, this, engine, others, false));
        } else if (client != null && client.isInMatch()) {
            engine = new ClientEngine(client);
            show(new GameScreen(ctx, this, engine, true, false));
        }
    }

    @Override
    public HostManager host() {
        return host;
    }

    @Override
    public ClientManager client() {
        return client;
    }

    @Override
    public void onMatchFinished(String reason) {
        engine = null;
        if (soloActive) {
            soloActive = false;
            show(new SoloSetupScreen(ctx, this));
        } else if (host != null) {
            host.endMatch();
            show(LobbyScreen.forHost(ctx, this));
        } else if (client != null && !client.isClosed()) {
            show(LobbyScreen.forClient(ctx, this));
        } else {
            closeSession();
            toast(reason != null ? reason : "You were disconnected.");
            show(new MenuScreen(ctx, this, null));
        }
    }

    @Override
    public void toast(String message) {
        Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
    }

    // ------------------------------------------------------------------ internals

    private void show(Screen next) {
        if (current != null) {
            current.onHide();
            root.removeView(current.view());
        }
        current = next;
        root.addView(next.view(), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        next.onInsets(insetL, insetT, insetR, insetB);
        next.onShow();
    }

    private void closeSession() {
        soloActive = false;
        if (engine != null) {
            engine.close();
            engine = null;
        }
        if (host != null) {
            host.close();
            host = null;
        }
        if (client != null) {
            client.close();
            client = null;
        }
    }
}
