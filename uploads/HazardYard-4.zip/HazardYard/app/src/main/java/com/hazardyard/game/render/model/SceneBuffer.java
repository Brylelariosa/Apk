package com.hazardyard.game.render.model;

/**
 * Turns meshes into drawable polygons for one object (a soldier, a pickup): it moves, rotates and
 * projects the faces, throws away the ones that turn away from the viewer, lights the rest and sorts
 * them back to front. Reusable and allocation-free after construction; one instance per thread.
 */
public final class SceneBuffer {
    /** Number of independently animated parts (body, two legs, gun). */
    public static final int GROUPS = 4;

    private static final float AMBIENT = 0.46f;
    private static final float LIGHT_X = -0.46f, LIGHT_Y = -0.38f, LIGHT_Z = 0.80f;
    private static final float LIGHT_NORM;

    static {
        LIGHT_NORM = (float) Math.sqrt(LIGHT_X * LIGHT_X + LIGHT_Y * LIGHT_Y + LIGHT_Z * LIGHT_Z);
    }

    private final float[] xs;
    private final float[] ys;
    private final int[] faceOffset;
    private final int[] faceCount;
    private final int[] faceColor;
    private final float[] faceDepth;
    private final int[] order;
    private int faces;
    private int verts;

    // per-group animation: yaw (radians), offset in model space
    public final float[] yaw = new float[GROUPS];
    public final float[] offX = new float[GROUPS];
    public final float[] offY = new float[GROUPS];
    public final float[] offZ = new float[GROUPS];

    /**
     * Forward tumble of the whole object, in radians: it rotates about its own side axis (the one
     * through the pivot, at height {@link #pitchPivotZ}) before the groups are turned by their yaw.
     * A full turn is a somersault. 0 leaves the object untouched.
     */
    public float pitch;
    public float pitchPivotZ = 13f;

    private final float[] cs = new float[GROUPS];
    private final float[] sn = new float[GROUPS];

    public SceneBuffer(int maxFaces, int maxVerts) {
        xs = new float[maxVerts];
        ys = new float[maxVerts];
        faceOffset = new int[maxFaces];
        faceCount = new int[maxFaces];
        faceColor = new int[maxFaces];
        faceDepth = new float[maxFaces];
        order = new int[maxFaces];
    }

    /** Clears the polygons and resets every group's animation to neutral. */
    public void begin() {
        faces = 0;
        verts = 0;
        for (int g = 0; g < GROUPS; g++) {
            yaw[g] = 0f;
            offX[g] = 0f;
            offY[g] = 0f;
            offZ[g] = 0f;
        }
        pitch = 0f;
    }

    public void setAllYaw(float a) {
        for (int g = 0; g < GROUPS; g++) yaw[g] = a;
    }

    public int faceCount() {
        return faces;
    }

    /**
     * Adds a mesh placed at world position (wx, wy) at height wz, uniformly scaled.
     *
     * @param accent colour used by accent faces (the player's colour)
     * @param whiten 0..1: blends the final colours towards white (hit flash)
     */
    public void addMesh(Mesh m, float wx, float wy, float wz, float scale, int accent, float whiten) {
        for (int g = 0; g < GROUPS; g++) {
            cs[g] = (float) Math.cos(yaw[g]);
            sn[g] = (float) Math.sin(yaw[g]);
        }
        final boolean tumbling = pitch != 0f;
        final float cp = tumbling ? (float) Math.cos(pitch) : 1f;
        final float sp = tumbling ? (float) Math.sin(pitch) : 0f;
        final float pz = pitchPivotZ;
        for (int f = 0; f < m.faceCount; f++) {
            if (faces >= faceOffset.length) return;
            int g = m.group[f];
            float c = cs[g], s = sn[g];
            float nx = m.normals[f * 3], ny = m.normals[f * 3 + 1], nz = m.normals[f * 3 + 2];
            if (tumbling) {
                float tx = nx * cp + nz * sp;
                nz = -nx * sp + nz * cp;
                nx = tx;
            }
            float rnx = nx * c - ny * s;
            float rny = nx * s + ny * c;
            if (!Projection.facesViewer(rnx, rny, nz)) continue;
            int v0 = m.faceStart[f];
            int n = m.faceStart[f + 1] - v0;
            if (verts + n > xs.length) return;

            int base = (m.flags[f] & Mesh.FLAG_ACCENT) != 0 ? accent : m.color[f];
            int argb;
            if ((m.flags[f] & Mesh.FLAG_EMISSIVE) != 0) {
                argb = base;
            } else {
                float diffuse = (rnx * LIGHT_X + rny * LIGHT_Y + nz * LIGHT_Z) / LIGHT_NORM;
                if (diffuse < 0f) diffuse = 0f;
                argb = shade(base, AMBIENT + (1.12f - AMBIENT) * diffuse);
            }
            if (whiten > 0f) argb = mixWhite(argb, whiten);

            float depth = 0f;
            faceOffset[faces] = verts;
            faceCount[faces] = n;
            for (int k = 0; k < n; k++) {
                int vi = (v0 + k) * 3;
                float x = m.verts[vi] + offX[g];
                float y = m.verts[vi + 1] + offY[g];
                float z = m.verts[vi + 2] + offZ[g];
                if (tumbling) {
                    float zr = z - pz;
                    float tx = x * cp + zr * sp;
                    z = -x * sp + zr * cp + pz;
                    x = tx;
                }
                float X = (x * c - y * s) * scale + wx;
                float Y = (x * s + y * c) * scale + wy;
                float Z = z * scale + wz;
                xs[verts] = Projection.screenX(X, Z);
                ys[verts] = Projection.screenY(Y, Z);
                depth += Projection.nearness(X, Y, Z);
                verts++;
            }
            faceDepth[faces] = depth / n;
            faceColor[faces] = argb;
            faces++;
        }
    }

    /** Sorts the polygons far to near and hands them to the sink. */
    public void flush(FaceSink sink) {
        for (int i = 0; i < faces; i++) {
            int j = i - 1;
            float d = faceDepth[i];
            while (j >= 0 && faceDepth[order[j]] > d) {
                order[j + 1] = order[j];
                j--;
            }
            order[j + 1] = i;
        }
        for (int i = 0; i < faces; i++) {
            int f = order[i];
            sink.polygon(xs, ys, faceOffset[f], faceCount[f], faceColor[f]);
        }
    }

    // ------------------------------------------------------------------ colour helpers

    /** Multiplies the colour by {@code k}; shadows get a slight cool tint, highlights a warm one. */
    public static int shade(int argb, float k) {
        int a = argb >>> 24;
        float r = ((argb >> 16) & 0xFF) * k;
        float g = ((argb >> 8) & 0xFF) * k;
        float b = (argb & 0xFF) * k;
        if (k < 1f) {
            float t = 1f - k;
            r -= r * 0.06f * t * 2f;
            b += (255f - b) * 0.05f * t * 2f;
        }
        return (a << 24) | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(b);
    }

    public static int mixWhite(int argb, float t) {
        int a = argb >>> 24;
        int r = (argb >> 16) & 0xFF, g = (argb >> 8) & 0xFF, b = argb & 0xFF;
        r += (int) ((255 - r) * t);
        g += (int) ((255 - g) * t);
        b += (int) ((255 - b) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    private static int clamp255(float v) {
        return v < 0f ? 0 : (v > 255f ? 255 : (int) v);
    }
}
