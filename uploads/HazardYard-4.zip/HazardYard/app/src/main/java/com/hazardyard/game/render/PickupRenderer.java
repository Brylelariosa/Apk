package com.hazardyard.game.render;

import android.graphics.Canvas;

import com.hazardyard.game.core.Pickup;
import com.hazardyard.game.render.model.GunModels;
import com.hazardyard.game.render.model.SceneBuffer;
import com.hazardyard.game.render.model.SoldierModel;

/** A weapon pickup: the gun's own 3D model hovering above its pad, spinning and bobbing. */
final class PickupRenderer {
    private static final float SCALE = 1.3f;

    private final PolyDrawer poly;
    private final SceneBuffer scene = new SceneBuffer(160, 1400);

    PickupRenderer(PolyDrawer poly) {
        this.poly = poly;
    }

    void draw(Canvas c, Pickup pk, int index, float time) {
        float bob = (float) Math.sin(time * 2.4f + index * 1.3f) * 1.6f;
        float spin = time * 1.35f + index * 0.9f;
        scene.begin();
        scene.yaw[SoldierModel.G_GUN] = spin;
        scene.offX[SoldierModel.G_GUN] = -GunModels.displayCenterX(pk.weaponId);
        scene.offZ[SoldierModel.G_GUN] = -14.7f;      // the models are authored at soldier grip height
        scene.addMesh(GunModels.display(pk.weaponId), pk.x, pk.y, 15f + bob, SCALE, 0xFFFFFFFF, 0.18f);
        poly.begin(c);
        scene.flush(poly);
    }
}
