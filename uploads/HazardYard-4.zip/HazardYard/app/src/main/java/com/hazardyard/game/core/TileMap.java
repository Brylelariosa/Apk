package com.hazardyard.game.core;

import java.util.Arrays;

/**
 * Tile grid of the arena. Walls, crates, round pillars, tanks and angled corner pieces block players
 * and bullets; fences and toxic pools block players only (bullets fly over them), which makes them
 * useful low cover and map dividers. Also holds spawn points, weapon pickup locations and a list of
 * merged solid blocks so the renderer draws a few dozen shapes instead of one per tile.
 *
 * <p>Not every solid tile fills its whole square: a fence is a thin line, a pillar and a tank are
 * circles, and an angled corner piece is a triangle. {@link CollisionSystem} uses the real shapes.
 */
public final class TileMap {
    public static final byte FLOOR = 0;
    public static final byte WALL = 1;
    public static final byte CRATE = 2;
    /** Chain-link fence: a thin line players cannot cross, bullets pass through. */
    public static final byte FENCE = 3;
    /** Toxic pool / canal: players cannot cross it, bullets pass over it. */
    public static final byte WATER = 4;
    /** Round column filling most of one tile. Stops players and bullets. */
    public static final byte PILLAR = 5;
    /** Big round tank covering a 2 x 2 block of tiles (all four tiles carry this kind). */
    public static final byte TANK = 6;
    /** Angled corner pieces: a triangle filling the named half of the tile. Stop players and bullets. */
    public static final byte WEDGE_NW = 7;
    public static final byte WEDGE_NE = 8;
    public static final byte WEDGE_SW = 9;
    public static final byte WEDGE_SE = 10;
    /** Only used in {@link #blocks}: one fence tile where runs meet (a corner, a T or a cross). */
    public static final byte FENCE_JOINT = 11;

    public static final float PILLAR_RADIUS = 13f;
    public static final float TANK_RADIUS = 30f;
    /** Half the thickness of a fence line for collision. */
    public static final float FENCE_HALF = 3f;

    /** Fence arms: which of the four directions from the tile centre carry fence. */
    public static final int ARM_L = 1;
    public static final int ARM_R = 2;
    public static final int ARM_U = 4;
    public static final int ARM_D = 8;

    /** Which {@link MapLibrary} entry this is (the renderer picks its theme from it). */
    public final int id;
    public final int width;
    public final int height;
    public final byte[] tiles;
    public final float worldW;
    public final float worldH;

    public final float[] spawnX;
    public final float[] spawnY;
    public final float[] pickupX;
    public final float[] pickupY;
    public final int[] pickupWeapon;

    /**
     * Merged non-floor blocks, 5 ints each: tileX, tileY, tilesW, tilesH, kind. Sorted by their
     * south edge (then by x), which is the order the renderer needs for correct overlap.
     */
    public final int[] blocks;
    public final int blockCount;

    /** Round obstacles, 3 floats each: centre x, centre y, radius. */
    public final float[] circles;
    public final int circleCount;
    private final short[] circleAt;
    private final byte[] fenceArms;

    private TileMap(int id, int width, int height, byte[] tiles, float[] sx, float[] sy,
                    float[] px, float[] py, int[] pw, int[] blocks, int blockCount,
                    float[] circles, int circleCount, short[] circleAt, byte[] fenceArms) {
        this.id = id;
        this.width = width;
        this.height = height;
        this.tiles = tiles;
        this.worldW = width * GameConfig.TILE;
        this.worldH = height * GameConfig.TILE;
        this.spawnX = sx;
        this.spawnY = sy;
        this.pickupX = px;
        this.pickupY = py;
        this.pickupWeapon = pw;
        this.blocks = blocks;
        this.blockCount = blockCount;
        this.circles = circles;
        this.circleCount = circleCount;
        this.circleAt = circleAt;
        this.fenceArms = fenceArms;
    }

    /** Kinds with a shape smaller than the tile that is not a plain box: pillars, tanks, angled pieces. */
    public static boolean isShapeKind(byte k) {
        return k >= PILLAR && k <= WEDGE_SE;
    }

    public static boolean isWedge(byte k) {
        return k >= WEDGE_NW && k <= WEDGE_SE;
    }

    /** Blocks player movement (to some degree). Anything outside the grid counts as solid, so nothing can leave the arena. */
    public boolean isSolid(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return true;
        return tiles[ty * width + tx] != FLOOR;
    }

    public boolean isSolidAt(float wx, float wy) {
        return isSolid((int) Math.floor(wx / GameConfig.TILE), (int) Math.floor(wy / GameConfig.TILE));
    }

    /** Walls and crates (and the outside of the grid) stop bullets over the whole tile. */
    public boolean blocksShotsFully(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return true;
        byte k = tiles[ty * width + tx];
        return k == WALL || k == CRATE;
    }

    /** Pillars, tanks and angled pieces stop bullets, but only where their shape is. */
    public boolean blocksShotsPartly(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return false;
        return isShapeKind(tiles[ty * width + tx]);
    }

    public byte kindAt(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return WALL;
        return tiles[ty * width + tx];
    }

    /** Index into {@link #circles} of the round obstacle covering this tile, or -1. */
    public int circleAt(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return -1;
        return circleAt[ty * width + tx];
    }

    /** {@code ARM_*} bits of the fence at this tile (0 when it is not a fence). */
    public int fenceArms(int tx, int ty) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return 0;
        return fenceArms[ty * width + tx];
    }

    /**
     * Corners of an angled piece whose tile has its top-left corner at (left, top). Output is
     * {@code out[0..5]}: the right-angle corner first, then the two ends of the long (diagonal) edge.
     */
    public static void wedgeCorners(byte kind, float left, float top, float[] out) {
        float r = left + GameConfig.TILE;
        float b = top + GameConfig.TILE;
        switch (kind) {
            case WEDGE_NW: set6(out, left, top, r, top, left, b); break;
            case WEDGE_NE: set6(out, r, top, r, b, left, top); break;
            case WEDGE_SW: set6(out, left, b, left, top, r, b); break;
            default: set6(out, r, b, r, top, left, b); break;     // WEDGE_SE
        }
    }

    private static void set6(float[] o, float a, float b, float c, float d, float e, float f) {
        o[0] = a;
        o[1] = b;
        o[2] = c;
        o[3] = d;
        o[4] = e;
        o[5] = f;
    }

    /** The weapon a map letter stands for, or -1 when the letter is not a weapon pickup. */
    public static int weaponForLetter(char c) {
        switch (c) {
            case 'R': return WeaponDef.RIFLE;
            case 'G': return WeaponDef.SHOTGUN;
            case 'M': return WeaponDef.SMG;
            case 'N': return WeaponDef.SNIPER;
            case 'V': return WeaponDef.MAGNUM;
            case 'P': return WeaponDef.PLASMA;
            case 'K': return WeaponDef.LMG;
            default: return -1;
        }
    }

    private static byte kindForLetter(char c) {
        switch (c) {
            case '#': return WALL;
            case 'C': return CRATE;
            case '+': return FENCE;
            case '~': return WATER;
            case 'O': return PILLAR;
            case 'T': return TANK;
            case '7': return WEDGE_NW;
            case '9': return WEDGE_NE;
            case '1': return WEDGE_SW;
            case '3': return WEDGE_SE;
            default: return FLOOR;
        }
    }

    /**
     * Legend: {@code #} wall, {@code C} crate, {@code +} fence, {@code ~} toxic pool, {@code O} round
     * pillar, {@code T} tank (four of them in a 2 x 2 block make one big round tank), the numpad corners
     * {@code 7 9 1 3} for an angled piece filling the top-left, top-right, bottom-left or bottom-right
     * half of its tile, {@code .} floor, {@code S} spawn point, and one letter per weapon pickup
     * (R rifle, G shotgun, M SMG, N sniper, V magnum, P plasma, K light MG). All rows must have the
     * same length; an unknown character is an error.
     */
    public static TileMap parse(int id, String[] rows) {
        int h = rows.length;
        int w = rows[0].length();
        byte[] tiles = new byte[w * h];
        int spawns = 0;
        int pickups = 0;
        int solid = 0;
        for (int y = 0; y < h; y++) {
            if (rows[y].length() != w) throw new IllegalArgumentException("Map row " + y + " has wrong length");
            for (int x = 0; x < w; x++) {
                char c = rows[y].charAt(x);
                byte kind = kindForLetter(c);
                if (kind == FLOOR) {
                    if (c == 'S') spawns++;
                    else if (weaponForLetter(c) >= 0) pickups++;
                    else if (c != '.') throw new IllegalArgumentException("Unknown map tile '" + c + "' at " + x + "," + y);
                }
                tiles[y * w + x] = kind;
                if (kind != FLOOR) solid++;
            }
        }
        float[] sx = new float[spawns];
        float[] sy = new float[spawns];
        float[] px = new float[pickups];
        float[] py = new float[pickups];
        int[] pw = new int[pickups];
        int si = 0;
        int pi = 0;
        float t = GameConfig.TILE;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                char c = rows[y].charAt(x);
                float cx = (x + 0.5f) * t;
                float cy = (y + 0.5f) * t;
                if (c == 'S') {
                    sx[si] = cx;
                    sy[si] = cy;
                    si++;
                } else if (weaponForLetter(c) >= 0) {
                    px[pi] = cx;
                    py[pi] = cy;
                    pw[pi] = weaponForLetter(c);
                    pi++;
                }
            }
        }

        // Fence arms: a straight run keeps both arms along its line, a junction only the arms that have a neighbour.
        byte[] arms = new byte[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (tiles[y * w + x] != FENCE) continue;
                boolean l = x > 0 && tiles[y * w + x - 1] == FENCE;
                boolean r = x < w - 1 && tiles[y * w + x + 1] == FENCE;
                boolean u = y > 0 && tiles[(y - 1) * w + x] == FENCE;
                boolean d = y < h - 1 && tiles[(y + 1) * w + x] == FENCE;
                int a;
                if (!(l || r) && !(u || d)) a = ARM_L | ARM_R;
                else if ((l || r) && !(u || d)) a = ARM_L | ARM_R;
                else if ((u || d) && !(l || r)) a = ARM_U | ARM_D;
                else a = (l ? ARM_L : 0) | (r ? ARM_R : 0) | (u ? ARM_U : 0) | (d ? ARM_D : 0);
                arms[y * w + x] = (byte) a;
            }
        }

        boolean[] used = new boolean[w * h];
        int[] raw = new int[5 * Math.max(1, solid)];
        int bc = 0;
        int maxCircles = 0;
        for (int i = 0; i < tiles.length; i++) {
            if (tiles[i] == PILLAR) maxCircles++;
            else if (tiles[i] == TANK) maxCircles++;   // generous: a tank uses 1 of every 4 tiles
        }
        float[] circles = new float[3 * Math.max(1, maxCircles)];
        short[] circleAt = new short[w * h];
        Arrays.fill(circleAt, (short) -1);
        int cc = 0;

        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                byte kind = tiles[i];
                if (kind == FLOOR || used[i]) continue;

                if (kind == PILLAR) {
                    used[i] = true;
                    circles[cc * 3] = (x + 0.5f) * t;
                    circles[cc * 3 + 1] = (y + 0.5f) * t;
                    circles[cc * 3 + 2] = PILLAR_RADIUS;
                    circleAt[i] = (short) cc;
                    cc++;
                    bc = addBlock(raw, bc, x, y, 1, 1, kind);
                    continue;
                }
                if (kind == TANK) {
                    boolean ok = x + 1 < w && y + 1 < h && tiles[i + 1] == TANK && tiles[i + w] == TANK
                            && tiles[i + w + 1] == TANK && !used[i + 1] && !used[i + w] && !used[i + w + 1];
                    if (!ok) throw new IllegalArgumentException("Tank tiles 'T' must form 2x2 blocks (at " + x + "," + y + ")");
                    used[i] = used[i + 1] = used[i + w] = used[i + w + 1] = true;
                    circles[cc * 3] = (x + 1f) * t;
                    circles[cc * 3 + 1] = (y + 1f) * t;
                    circles[cc * 3 + 2] = TANK_RADIUS;
                    circleAt[i] = circleAt[i + 1] = circleAt[i + w] = circleAt[i + w + 1] = (short) cc;
                    cc++;
                    bc = addBlock(raw, bc, x, y, 2, 2, kind);
                    continue;
                }
                if (isWedge(kind)) {
                    used[i] = true;
                    bc = addBlock(raw, bc, x, y, 1, 1, kind);
                    continue;
                }
                if (kind == FENCE) {
                    int a = arms[i];
                    if (a == (ARM_L | ARM_R)) {
                        int len = 1;
                        while (x + len < w && tiles[i + len] == FENCE && arms[i + len] == a && !used[i + len]) len++;
                        for (int k = 0; k < len; k++) used[i + k] = true;
                        bc = addBlock(raw, bc, x, y, len, 1, FENCE);
                    } else if (a == (ARM_U | ARM_D)) {
                        int len = 1;
                        while (y + len < h && tiles[i + len * w] == FENCE && arms[i + len * w] == a && !used[i + len * w]) len++;
                        for (int k = 0; k < len; k++) used[i + k * w] = true;
                        bc = addBlock(raw, bc, x, y, 1, len, FENCE);
                    } else {
                        used[i] = true;
                        bc = addBlock(raw, bc, x, y, 1, 1, FENCE_JOINT);
                    }
                    continue;
                }

                // Walls, crates and pools: greedy rectangle merge of equal tiles.
                int bw = 1;
                while (x + bw < w && tiles[i + bw] == kind && !used[i + bw]) bw++;
                int bh = 1;
                boolean grow = true;
                while (grow && y + bh < h) {
                    for (int k = 0; k < bw; k++) {
                        int j = (y + bh) * w + x + k;
                        if (tiles[j] != kind || used[j]) {
                            grow = false;
                            break;
                        }
                    }
                    if (grow) bh++;
                }
                for (int yy = 0; yy < bh; yy++) {
                    for (int xx = 0; xx < bw; xx++) used[(y + yy) * w + x + xx] = true;
                }
                bc = addBlock(raw, bc, x, y, bw, bh, kind);
            }
        }

        // Order by south edge, then x, so drawing back-to-front is a single pass.
        long[] keys = new long[bc];
        for (int b = 0; b < bc; b++) {
            long south = raw[b * 5 + 1] + raw[b * 5 + 3];
            keys[b] = (south << 40) | ((long) raw[b * 5] << 20) | b;
        }
        Arrays.sort(keys);
        int[] blocks = new int[bc * 5];
        for (int n = 0; n < bc; n++) {
            int b = (int) (keys[n] & 0xFFFFF);
            System.arraycopy(raw, b * 5, blocks, n * 5, 5);
        }
        return new TileMap(id, w, h, tiles, sx, sy, px, py, pw, blocks, bc,
                Arrays.copyOf(circles, cc * 3), cc, circleAt, arms);
    }

    private static int addBlock(int[] raw, int bc, int x, int y, int bw, int bh, int kind) {
        raw[bc * 5] = x;
        raw[bc * 5 + 1] = y;
        raw[bc * 5 + 2] = bw;
        raw[bc * 5 + 3] = bh;
        raw[bc * 5 + 4] = kind;
        return bc + 1;
    }
}
