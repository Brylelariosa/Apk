package com.hazardyard.game.render.model;

/**
 * The low-poly soldier: boots, legs, armoured torso, backpack, helmet with a glowing visor and the
 * upper arms. Forearms and hands are part of each weapon's model (they hold it), so the grip always
 * lines up. Accent faces (helmet, chest plate, shoulder pads, backpack stripe) take the player's colour.
 *
 * <p>Parts: group 0 = body, 1 = left leg, 2 = right leg (animated by the renderer), 3 = weapon.
 */
public final class SoldierModel {
    private SoldierModel() {}

    public static final int G_BODY = 0;
    public static final int G_LEG_L = 1;
    public static final int G_LEG_R = 2;
    public static final int G_GUN = 3;

    /** Overall height of the model in world units. */
    public static final float HEIGHT = 27.5f;

    static final int FATIGUE = 0xFF6A7A91;
    static final int FATIGUE_LIGHT = 0xFF8393AA;
    static final int ARMOR_DARK = 0xFF3A4350;
    static final int BOOT = 0xFF2A313B;
    static final int GLOVE = 0xFF2C333D;
    static final int VISOR = 0xFF111A24;
    static final int VISOR_GLOW = 0xFF8FE8FF;
    static final int PACK = 0xFF485364;

    /** Where the weapon hand and the support hand rest, used by {@link GunModels}. */
    static final float ELBOW_R_X = 3.4f, ELBOW_R_Y = 7.7f, ELBOW_Z = 14.6f;
    static final float ELBOW_L_X = 3.8f, ELBOW_L_Y = -7.1f;

    private static Mesh body;

    public static synchronized Mesh body() {
        if (body == null) body = build();
        return body;
    }

    private static Mesh build() {
        MeshBuilder b = new MeshBuilder();

        // legs
        for (int side = 0; side < 2; side++) {
            float yc = side == 0 ? -3.7f : 3.7f;
            b.group(side == 0 ? G_LEG_L : G_LEG_R).accent(false);
            b.color(FATIGUE).box(-2.6f, yc - 2.3f, 2.8f, 2.6f, yc + 2.3f, 11.0f);
            b.color(ARMOR_DARK).box(-2.6f, yc - 2.35f, 6.6f, 2.8f, yc + 2.35f, 8.4f);   // knee pad
            b.color(BOOT).box(-2.7f, yc - 2.4f, 0f, 3.9f, yc + 2.4f, 3.2f);
        }

        // torso
        b.group(G_BODY);
        b.color(ARMOR_DARK).box(-3.5f, -6.3f, 10.4f, 3.5f, 6.3f, 12.4f);                // belt
        b.color(FATIGUE_LIGHT).box(-3.7f, -7.5f, 12.4f, 3.7f, 7.5f, 19.4f);              // chest
        b.accent(true).color(0xFFB0B0B0).box(3.0f, -5.3f, 13.4f, 4.5f, 5.3f, 18.4f);     // chest plate
        b.accent(false).color(ARMOR_DARK)
                .box(2.7f, -3.4f, 10.6f, 4.3f, -0.8f, 12.6f)                             // ammo pouches
                .box(2.7f, 0.8f, 10.6f, 4.3f, 3.4f, 12.6f);
        b.color(ARMOR_DARK).box(-1.6f, -1.9f, 19.4f, 1.6f, 1.9f, 20.3f);                 // neck

        // shoulder pads
        b.accent(true).color(0xFFB0B0B0)
                .box(-2.7f, -10.8f, 16.0f, 2.7f, -6.9f, 20.1f)
                .box(-2.7f, 6.9f, 16.0f, 2.7f, 10.8f, 20.1f);
        b.accent(false);

        // upper arms (the forearms belong to the weapon model)
        b.color(FATIGUE).beam(0.2f, 8.8f, 17.6f, ELBOW_R_X, ELBOW_R_Y, ELBOW_Z, 3.0f, 3.0f);
        b.color(FATIGUE).beam(0.2f, -8.8f, 17.6f, ELBOW_L_X, ELBOW_L_Y, ELBOW_Z, 3.0f, 3.0f);

        // backpack
        b.color(PACK).box(-8.6f, -5.3f, 11.0f, -3.7f, 5.3f, 19.2f);
        b.color(ARMOR_DARK).box(-7.8f, -3.2f, 19.2f, -4.4f, 3.2f, 20.6f);
        b.accent(true).color(0xFFB0B0B0).box(-8.9f, -3.7f, 12.2f, -8.5f, 3.7f, 18.0f).accent(false);

        // head: helmet shell, crest, visor
        b.accent(true).color(0xFFB0B0B0).prism(0.3f, 0f, 19.9f, 26.6f, 5.0f, 4.4f, 6);
        b.accent(false).color(ARMOR_DARK).box(-4.0f, -1.0f, 26.6f, 2.8f, 1.0f, 27.5f);
        b.color(VISOR).box(3.5f, -3.7f, 21.3f, 5.5f, 3.7f, 24.7f);
        b.emissive(true).color(VISOR_GLOW).box(5.4f, -3.0f, 22.4f, 5.75f, 3.0f, 23.6f).emissive(false);
        return b.build();
    }
}
