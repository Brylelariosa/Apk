package com.hazardyard.game.engine;

import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.LocalInput;

/**
 * One running match as seen by the game loop. {@link HostEngine} simulates it, {@link ClientEngine}
 * mirrors it from the host; the renderer only ever looks at {@link #state()}.
 */
public interface GameEngine {
    /** One fixed simulation step; called {@code SIM_HZ} times per second on the game thread. */
    void fixedUpdate(float dt, LocalInput input);

    /**
     * Once per rendered frame: visual smoothing. {@code dt} is the real time since the previous
     * frame; {@code alpha} (0..1) is how far the game clock has advanced towards the next fixed step,
     * so everything can be drawn between its last two simulated states and stay smooth on screens
     * that refresh at 60, 90 or 120 Hz.
     */
    void frameUpdate(float dt, float alpha);

    GameState state();

    /** True when the session is over: results were shown and the lobby is next, or the connection died. */
    boolean isFinished();

    /** Explanation for an abnormal end (shown to the player), or null for a normal one. */
    String finishReason();

    /** Round-trip time to the host in milliseconds; 0 on the host itself. */
    int pingMs();

    /** The pause menu is open. Only a host playing alone actually freezes the match. */
    default void setPaused(boolean paused) {}

    void close();
}
