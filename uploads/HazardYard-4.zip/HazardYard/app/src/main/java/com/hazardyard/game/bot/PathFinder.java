package com.hazardyard.game.bot;

import com.hazardyard.game.core.GameConfig;

/**
 * A* over the tile grid (8 directions, no corner cutting) followed by line-of-sight smoothing, so
 * bots walk straight lines where they can instead of tile by tile. One instance per bot: it owns the
 * scratch arrays, so searching never allocates. Results are left in {@link #wx}/{@link #wy}.
 */
public final class PathFinder {
    public static final int MAX_WAYPOINTS = 96;
    private static final float DIAGONAL = 1.41421356f;
    private static final float NEAR_WALL_COST = 0.45f;
    private static final int[] DX = {1, -1, 0, 0, 1, 1, -1, -1};
    private static final int[] DY = {0, 0, 1, -1, 1, -1, 1, -1};

    private final NavGrid nav;
    private final int n;
    private final float[] g;
    private final int[] parent;
    private final int[] stamp;
    private final boolean[] closed;
    private final float[] nearWall;
    private int token;

    private final int[] heapNode;
    private final float[] heapKey;
    private int heapSize;

    private final int[] chain;

    /** Smoothed route: waypoints 0..count-1, the last one is the goal. */
    public final float[] wx = new float[MAX_WAYPOINTS];
    public final float[] wy = new float[MAX_WAYPOINTS];
    public int count;

    public PathFinder(NavGrid nav) {
        this.nav = nav;
        this.n = nav.width * nav.height;
        g = new float[n];
        parent = new int[n];
        stamp = new int[n];
        closed = new boolean[n];
        nearWall = new float[n];
        heapNode = new int[n * 8];
        heapKey = new float[n * 8];
        chain = new int[n];
        for (int y = 0; y < nav.height; y++) {
            for (int x = 0; x < nav.width; x++) {
                boolean next = false;
                for (int k = 0; k < 8 && !next; k++) next = !nav.walkable(x + DX[k], y + DY[k]);
                nearWall[y * nav.width + x] = next ? NEAR_WALL_COST : 0f;
            }
        }
    }

    /**
     * Finds a route from (sx,sy) to (gx,gy) for a body of the given radius.
     *
     * @return true and {@link #count} &gt; 0 on success
     */
    public boolean find(float sx, float sy, float gx, float gy, float radius) {
        count = 0;
        int start = nav.nearestWalkable(nav.tileOf(sx, sy));
        int goal = nav.nearestWalkable(nav.tileOf(gx, gy));
        if (start < 0 || goal < 0) return false;
        if (start == goal) {
            add(nav.walkable((int) (gx / GameConfig.TILE), (int) (gy / GameConfig.TILE)) ? gx : nav.centerX(goal),
                    nav.walkable((int) (gx / GameConfig.TILE), (int) (gy / GameConfig.TILE)) ? gy : nav.centerY(goal));
            return true;
        }
        token++;
        if (token == Integer.MAX_VALUE) {
            java.util.Arrays.fill(stamp, 0);
            token = 1;
        }
        heapSize = 0;
        touch(start, 0f, -1);
        push(start, heuristic(start, goal));
        int w = nav.width;
        boolean found = false;
        while (heapSize > 0) {
            int cur = pop();
            if (closed[cur]) continue;
            closed[cur] = true;
            if (cur == goal) {
                found = true;
                break;
            }
            int cx = cur % w;
            int cy = cur / w;
            for (int k = 0; k < 8; k++) {
                int nx = cx + DX[k];
                int ny = cy + DY[k];
                if (!nav.walkable(nx, ny)) continue;
                if (k >= 4 && (!nav.walkable(cx + DX[k], cy) || !nav.walkable(cx, cy + DY[k]))) continue;
                int nb = ny * w + nx;
                float step = (k >= 4 ? DIAGONAL : 1f) + nearWall[nb];
                float ng = g[cur] + step;
                if (stamp[nb] == token) {
                    if (closed[nb] || ng >= g[nb]) continue;
                } else {
                    touch(nb, 0f, -1);
                }
                g[nb] = ng;
                parent[nb] = cur;
                if (heapSize < heapNode.length) push(nb, ng + heuristic(nb, goal));
            }
        }
        if (!found) return false;

        int len = 0;
        for (int t = goal; t >= 0 && len < chain.length; t = parent[t]) {
            chain[len++] = t;
            if (t == start) break;
        }
        // chain holds goal ... start. Smooth it into waypoints, starting from the real position.
        float curX = sx;
        float curY = sy;
        int i = len - 1;
        while (i > 0 && count < MAX_WAYPOINTS - 1) {
            int far = i - 1;
            for (int j = 0; j < i; j++) {
                if (nav.lineClear(curX, curY, nav.centerX(chain[j]), nav.centerY(chain[j]), radius)) {
                    far = j;
                    break;
                }
            }
            curX = nav.centerX(chain[far]);
            curY = nav.centerY(chain[far]);
            add(curX, curY);
            i = far;
        }
        // Finish exactly on the goal point when that point itself is standable.
        if (count == 0 || chain[0] == goal) {
            if (nav.walkable((int) Math.floor(gx / GameConfig.TILE), (int) Math.floor(gy / GameConfig.TILE))
                    && nav.lineClear(curX, curY, gx, gy, radius * 0.6f)) {
                wx[Math.max(0, count - 1)] = gx;
                wy[Math.max(0, count - 1)] = gy;
                if (count == 0) count = 1;
            }
        }
        return count > 0;
    }

    private void add(float x, float y) {
        if (count < MAX_WAYPOINTS) {
            wx[count] = x;
            wy[count] = y;
            count++;
        }
    }

    private void touch(int node, float cost, int par) {
        stamp[node] = token;
        closed[node] = false;
        g[node] = cost;
        parent[node] = par;
    }

    private float heuristic(int a, int b) {
        int w = nav.width;
        float dx = Math.abs(a % w - b % w);
        float dy = Math.abs(a / w - b / w);
        return Math.max(dx, dy) + (DIAGONAL - 1f) * Math.min(dx, dy);
    }

    // ------------------------------------------------------------------ binary min-heap

    private void push(int node, float key) {
        int i = heapSize++;
        while (i > 0) {
            int p = (i - 1) >> 1;
            if (heapKey[p] <= key) break;
            heapNode[i] = heapNode[p];
            heapKey[i] = heapKey[p];
            i = p;
        }
        heapNode[i] = node;
        heapKey[i] = key;
    }

    private int pop() {
        int top = heapNode[0];
        heapSize--;
        if (heapSize > 0) {
            int node = heapNode[heapSize];
            float key = heapKey[heapSize];
            int i = 0;
            while (true) {
                int c = 2 * i + 1;
                if (c >= heapSize) break;
                if (c + 1 < heapSize && heapKey[c + 1] < heapKey[c]) c++;
                if (heapKey[c] >= key) break;
                heapNode[i] = heapNode[c];
                heapKey[i] = heapKey[c];
                i = c;
            }
            heapNode[i] = node;
            heapKey[i] = key;
        }
        return top;
    }
}
