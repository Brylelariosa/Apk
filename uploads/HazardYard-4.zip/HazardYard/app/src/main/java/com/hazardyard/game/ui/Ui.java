package com.hazardyard.game.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hazardyard.game.render.Palette;

/** Small factory helpers so the menu screens share one visual language. */
final class Ui {
    private Ui() {}

    static final Typeface BOLD = Typeface.create("sans-serif-condensed", Typeface.BOLD);
    static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rounded(Context c, int fill, int stroke, float radiusDp, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0f) g.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        return g;
    }

    static TextView label(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, sp);
        t.setTextColor(color);
        t.setTypeface(bold ? BOLD : MEDIUM);
        t.setIncludeFontPadding(false);
        return t;
    }

    /** Large rounded button. Primary = hazard yellow with dark text, otherwise a quiet outlined panel. */
    static Button button(Context c, String s, boolean primary) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setTypeface(MEDIUM);
        b.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 17f);
        b.setMinHeight(dp(c, 56));
        b.setMinimumHeight(dp(c, 56));
        b.setPadding(dp(c, 20), 0, dp(c, 20), 0);
        int fill = primary ? Palette.ACCENT : 0xFF1E2733;
        int fillPressed = primary ? 0xFFD6A91C : 0xFF2B3746;
        int stroke = primary ? Palette.ACCENT : 0xFF3A4757;
        b.setTextColor(primary ? Palette.ACCENT_DARK : Palette.TEXT);
        StateListDrawable sl = new StateListDrawable();
        sl.addState(new int[] {android.R.attr.state_pressed}, rounded(c, fillPressed, stroke, 12f, 1.5f));
        sl.addState(new int[0], rounded(c, fill, stroke, 12f, 1.5f));
        b.setBackground(sl);
        return b;
    }

    /** Compact button for toolbars (40dp tall). */
    static Button smallButton(Context c, String s, boolean primary) {
        Button b = button(c, s, primary);
        b.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14f);
        b.setMinHeight(dp(c, 40));
        b.setMinimumHeight(dp(c, 40));
        b.setPadding(dp(c, 14), 0, dp(c, 14), 0);
        return b;
    }

    static void setEnabled(Button b, boolean enabled) {
        b.setEnabled(enabled);
        b.setAlpha(enabled ? 1f : 0.45f);
    }

    static LinearLayout.LayoutParams lp(int w, int h, float weight, int leftDp, int topDp, int rightDp, int bottomDp,
                                        Context c) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(c, leftDp), dp(c, topDp), dp(c, rightDp), dp(c, bottomDp));
        return p;
    }

    static LinearLayout.LayoutParams fillWidth(Context c, int topDp) {
        return lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0f, 0, topDp, 0, 0, c);
    }

    static LinearLayout column(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static LinearLayout panel(Context c) {
        LinearLayout l = column(c);
        l.setBackground(rounded(c, Palette.PANEL_SOLID, 0x33FFFFFF, 18f, 1.5f));
        int p = dp(c, 20);
        l.setPadding(p, p, p, p);
        return l;
    }
}
