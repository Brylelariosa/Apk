package com.hazardyard.game.core;

/** Gameplay events raised by {@link GameWorld}. The host engine turns them into effects and network events. */
public interface WorldListener {
    /** A weapon fired. Carries everything a client needs to recreate the bullets. */
    default void onShot(Player shooter, WeaponDef def, float x, float y, float angle, int seed, int baseId) {}

    /** A bullet ended on a player. {@code damage} is 0 when spawn protection absorbed it. */
    default void onProjectileHit(int projectileId, int victimId, float x, float y, int damage, int weaponId) {}

    default void onWallImpact(float x, float y, int weaponId) {}

    default void onKill(int killerId, int victimId, int weaponId) {}

    default void onRespawn(Player p) {}

    default void onPickup(Player p, int pickupIndex) {}

    default void onPhaseChanged(int phase) {}
}
