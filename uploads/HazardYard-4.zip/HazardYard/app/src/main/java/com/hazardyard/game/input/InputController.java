package com.hazardyard.game.input;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.InputSource;
import com.hazardyard.game.core.LocalInput;
import com.hazardyard.game.settings.ControlSettings;

/**
 * Turns raw multitouch pointers into game controls. Every pointer is bound to exactly one control
 * when it goes down and stays bound until it goes up, so the sticks and the buttons never
 * interfere with each other, however the fingers move.
 *
 * <p>The aim stick has two thresholds: it aims once pushed past its dead zone, and it fires once it
 * is pushed out to the fire level (or never, when only the fire button fires).
 *
 * <p>Where the controls are, how big they are and how they behave comes from {@link ControlSettings};
 * {@link ControlGeometry} turns that into pixels. Touch callbacks arrive on the UI thread while
 * {@link #sample} runs on the game thread; a small lock keeps the shared state consistent. This
 * class has no Android dependencies (the MotionEvent translation lives in GameView) so the routing
 * rules can be tested on a plain JVM.
 */
public final class InputController implements InputSource {
    public interface Listener {
        /** The pause button was tapped. Called on the thread that delivered the touch event. */
        void onPausePressed();
    }

    private final Object lock = new Object();
    private final ControlSettings settings;
    private final ControlGeometry geom = new ControlGeometry();
    public final VirtualJoystick moveStick = new VirtualJoystick();
    public final VirtualJoystick aimStick = new VirtualJoystick();

    private boolean hasViewport;
    private int viewW = 1, viewH = 1;
    private float density = 1f;
    private float insetL, insetT, insetR, insetB;

    private int movePointer = -1;
    private int aimPointer = -1;
    private int firePointer = -1;
    private int pausePointer = -1;
    private int reloadPointer = -1;
    private boolean reloadQueued;
    private int dodgePointer = -1;
    private boolean dodgeQueued;
    private float lastAim;
    /** True from the moment the aim stick passes its dead zone until it falls clearly back inside it, so a thumb that drifts slightly never lets go of the trigger. */
    private boolean aimLatched;
    /** True from the moment the aim stick is pushed out to the fire level until it falls clearly back below it: the stick is pulling the trigger. */
    private boolean fireLatched;
    private volatile Listener listener;

    public InputController(ControlSettings settings) {
        this.settings = settings;
    }

    public void setListener(Listener l) {
        listener = l;
    }

    /** Pixel layout of every control; read-only for the HUD (what is drawn is what is touchable). */
    public ControlGeometry geometry() {
        return geom;
    }

    public ControlSettings settings() {
        return settings;
    }

    /**
     * Lays out the controls for a screen of w x h pixels at the given density (px per dp). The
     * insets are the display cutout / system bars: controls are kept clear of them.
     */
    public void setViewport(int w, int h, float density, float insetL, float insetT, float insetR, float insetB) {
        synchronized (lock) {
            viewW = w;
            viewH = h;
            this.density = density;
            this.insetL = insetL;
            this.insetT = insetT;
            this.insetR = insetR;
            this.insetB = insetB;
            hasViewport = true;
            relayoutLocked();
        }
    }

    /** Call after the settings changed (editor closed): re-lays out and releases all touches. */
    public void applySettings() {
        synchronized (lock) {
            if (hasViewport) relayoutLocked();
        }
    }

    private void relayoutLocked() {
        geom.compute(settings, viewW, viewH, density, insetL, insetT, insetR, insetB);
        moveStick.radius = geom.r[ControlSettings.MOVE];
        aimStick.radius = geom.r[ControlSettings.AIM];
        cancelAllLocked();
    }

    // ------------------------------------------------------------------ pointer events

    public void onPointerDown(int id, float x, float y) {
        synchronized (lock) {
            if (!hasViewport) return;
            if (pausePointer < 0 && geom.inside(ControlSettings.PAUSE, x, y)) {
                pausePointer = id;
                return;
            }
            if (reloadPointer < 0 && geom.inside(ControlSettings.RELOAD, x, y)) {
                reloadPointer = id;
                reloadQueued = true;
                return;
            }
            if (dodgePointer < 0 && geom.inside(ControlSettings.DODGE, x, y)) {
                dodgePointer = id;
                dodgeQueued = true;
                return;
            }
            if (firePointer < 0 && settings.fireButtonEnabled() && geom.inside(ControlSettings.FIRE, x, y)) {
                firePointer = id;
                return;
            }
            int stick = pickStick(x, y);
            if (stick == ControlSettings.MOVE) {
                movePointer = id;
                beginStick(moveStick, ControlSettings.MOVE, settings.moveFloating, x, y);
            } else if (stick == ControlSettings.AIM) {
                aimPointer = id;
                beginStick(aimStick, ControlSettings.AIM, settings.aimFloating, x, y);
            }
        }
    }

    /**
     * Which free stick (if any) a new touch at (x, y) belongs to. A fixed stick is grabbed inside its
     * ring; a floating stick is grabbed anywhere in its half of the usable screen. When both would
     * take the touch, the one whose centre is closer wins.
     */
    private int pickStick(float x, float y) {
        float mid = insetL + (viewW - insetL - insetR) * 0.5f;
        boolean moveOk = movePointer < 0 && (settings.moveFloating
                ? x < mid && !geom.inside(ControlSettings.AIM, x, y)
                : geom.inside(ControlSettings.MOVE, x, y));
        boolean aimOk = aimPointer < 0 && (settings.aimFloating
                ? x >= mid && !geom.inside(ControlSettings.MOVE, x, y)
                : geom.inside(ControlSettings.AIM, x, y));
        if (moveOk && aimOk) {
            float dm = dist2(x, y, geom.cx[ControlSettings.MOVE], geom.cy[ControlSettings.MOVE]);
            float da = dist2(x, y, geom.cx[ControlSettings.AIM], geom.cy[ControlSettings.AIM]);
            return dm <= da ? ControlSettings.MOVE : ControlSettings.AIM;
        }
        if (moveOk) return ControlSettings.MOVE;
        if (aimOk) return ControlSettings.AIM;
        return -1;
    }

    private void beginStick(VirtualJoystick s, int control, boolean floating, float x, float y) {
        if (floating) s.begin(x, y);
        else s.beginFixed(geom.cx[control], geom.cy[control], x, y);
    }

    public void onPointerMove(int id, float x, float y) {
        synchronized (lock) {
            if (id == movePointer) moveStick.update(x, y);
            else if (id == aimPointer) aimStick.update(x, y);
        }
    }

    public void onPointerUp(int id) {
        boolean pauseTapped = false;
        synchronized (lock) {
            if (id == movePointer) {
                movePointer = -1;
                moveStick.end();
            } else if (id == aimPointer) {
                aimPointer = -1;
                aimStick.end();
                aimLatched = false;
                fireLatched = false;
            } else if (id == dodgePointer) {
                dodgePointer = -1;
            } else if (id == firePointer) {
                firePointer = -1;
            } else if (id == reloadPointer) {
                reloadPointer = -1;
            } else if (id == pausePointer) {
                pausePointer = -1;
                pauseTapped = true;
            }
        }
        Listener l = listener;
        if (pauseTapped && l != null) l.onPausePressed();
    }

    /** A cancelled gesture (system took over the touch): release everything without side effects. */
    public void cancelAll() {
        synchronized (lock) {
            cancelAllLocked();
        }
    }

    private void cancelAllLocked() {
        movePointer = -1;
        aimPointer = -1;
        firePointer = -1;
        pausePointer = -1;
        reloadPointer = -1;
        dodgePointer = -1;
        moveStick.end();
        aimStick.end();
        aimLatched = false;
        fireLatched = false;
    }

    // ------------------------------------------------------------------ game thread

    @Override
    public void sample(LocalInput out) {
        synchronized (lock) {
            float mx = moveStick.x;
            float my = moveStick.y;
            float mag = (float) Math.sqrt(mx * mx + my * my);
            float dz = GameConfig.MOVE_DEAD_ZONE;
            if (!moveStick.active || mag <= dz) {
                out.moveX = 0f;
                out.moveY = 0f;
            } else {
                // Rescale so movement ramps smoothly from zero right after the dead zone.
                float k = (mag - dz) / (1f - dz) / mag;
                out.moveX = mx * k;
                out.moveY = my * k;
            }
            boolean aiming = updateAimLatch();
            if (aiming) {
                lastAim = (float) Math.atan2(aimStick.y, aimStick.x);
                out.aim = lastAim;
            }
            boolean stickFires = updateFireLatch(aiming);
            boolean buttonFires = firePointer >= 0 && settings.fireButtonEnabled();
            out.firing = stickFires || buttonFires;
            out.reload = reloadQueued;
            reloadQueued = false;
            out.dodge = dodgeQueued;
            dodgeQueued = false;
        }
    }

    // ------------------------------------------------------------------ read-only state for the HUD

    public boolean isReloadHeld() {
        return reloadPointer >= 0;
    }

    public boolean isDodgeHeld() {
        return dodgePointer >= 0;
    }

    /** Aim stick state with a little hysteresis: it takes the dead zone to start aiming but only 60% of it to keep aiming. */
    private boolean updateAimLatch() {
        if (!aimStick.active) {
            aimLatched = false;
            return false;
        }
        float m = aimStick.magnitude();
        float dz = settings.aimDeadZone;
        if (aimLatched) {
            if (m < dz * 0.6f) aimLatched = false;
        } else if (m >= dz) {
            aimLatched = true;
        }
        return aimLatched;
    }

    /**
     * Whether the aim stick is pulling the trigger. Aiming starts at the dead zone, but firing only
     * starts once the stick is pushed out to the fire level ({@link ControlSettings#fireStartLevel}),
     * and it keeps firing until the stick falls a little below that level, so a thumb that wobbles on
     * the edge does not stutter the gun. Never true when the fire button is the only trigger.
     */
    private boolean updateFireLatch(boolean aiming) {
        if (!aiming || !settings.stickFires()) {
            fireLatched = false;
            return false;
        }
        float m = aimStick.magnitude();
        float start = settings.fireStartLevel();
        // A stick clamped to its ring can read a hair under 1.0, so "fully pushed" gets a little slack.
        float reach = start - 0.01f;
        float release = Math.max(settings.aimDeadZone, start - GameConfig.FIRE_RELEASE_BAND);
        if (fireLatched) {
            if (m < release) fireLatched = false;
        } else if (m >= reach) {
            fireLatched = true;
        }
        return fireLatched;
    }

    public boolean isFireHeld() {
        return firePointer >= 0;
    }

    /** True while the aim stick is pushed far enough to fire (the HUD tints it then). */
    public boolean isStickFiring() {
        synchronized (lock) {
            return fireLatched && aimStick.active;
        }
    }

    /** True while the aim stick is pushed past its dead zone (the HUD tints it when it is firing). */
    public boolean isAiming() {
        synchronized (lock) {
            return aimLatched && aimStick.active;
        }
    }

    private static float dist2(float ax, float ay, float bx, float by) {
        float dx = ax - bx;
        float dy = ay - by;
        return dx * dx + dy * dy;
    }
}
