package com.hazardyard.game.net;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Growable big-endian byte writer for frames and datagrams. Not thread-safe; keep one per thread. */
public final class PacketWriter {
    private byte[] buf;
    private int pos;

    public PacketWriter(int capacity) {
        buf = new byte[capacity];
    }

    /** Starts a TCP frame: reserves the 2-byte length prefix, then writes the type. */
    public PacketWriter begin(int type) {
        pos = 2;
        return u8(type);
    }

    /** Starts a raw datagram (no length prefix). */
    public PacketWriter beginRaw() {
        pos = 0;
        return this;
    }

    public PacketWriter u8(int v) {
        ensure(1);
        buf[pos++] = (byte) v;
        return this;
    }

    public PacketWriter i8(int v) {
        return u8(v);
    }

    public PacketWriter u16(int v) {
        ensure(2);
        buf[pos++] = (byte) (v >> 8);
        buf[pos++] = (byte) v;
        return this;
    }

    public PacketWriter i16(int v) {
        return u16(v);
    }

    public PacketWriter i32(int v) {
        ensure(4);
        buf[pos++] = (byte) (v >> 24);
        buf[pos++] = (byte) (v >> 16);
        buf[pos++] = (byte) (v >> 8);
        buf[pos++] = (byte) v;
        return this;
    }

    /** Length-prefixed (one byte) UTF-8 string, cut to 255 bytes. */
    public PacketWriter str(String s) {
        byte[] b = s.getBytes(StandardCharsets.UTF_8);
        int n = Math.min(b.length, 255);
        u8(n);
        ensure(n);
        System.arraycopy(b, 0, buf, pos, n);
        pos += n;
        return this;
    }

    /** Fills in the length prefix and returns an exact-size copy ready to send. */
    public byte[] finishFrame() {
        int len = pos - 2;
        buf[0] = (byte) (len >> 8);
        buf[1] = (byte) len;
        return Arrays.copyOf(buf, pos);
    }

    public byte[] finishRaw() {
        return Arrays.copyOf(buf, pos);
    }

    private void ensure(int n) {
        if (pos + n > buf.length) buf = Arrays.copyOf(buf, Math.max(buf.length * 2, pos + n));
    }
}
