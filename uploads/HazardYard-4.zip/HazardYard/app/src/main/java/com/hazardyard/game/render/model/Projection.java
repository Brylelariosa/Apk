package com.hazardyard.game.render.model;

/**
 * The fixed "camera" of the 3D look: the game is still a flat top-down world, but things have a
 * height, and height is drawn as a shift up and to the right on screen (an oblique projection, the
 * camera sits above, south and west of the scene). Ground positions are never distorted, so
 * collisions and aiming stay exactly where the player sees them.
 *
 * <p>World axes: x right, y down the screen, z up towards the viewer.
 */
public final class Projection {
    private Projection() {}

    /** Screen rise (towards the top of the screen) per unit of height. */
    public static final float TILT = 0.55f;
    /** Screen shift to the right per unit of height. */
    public static final float LEAN = 0.22f;

    public static float screenX(float x, float z) {
        return x + LEAN * z;
    }

    public static float screenY(float y, float z) {
        return y - TILT * z;
    }

    /** Larger means closer to the viewer; draw smaller values first. */
    public static float nearness(float x, float y, float z) {
        return -LEAN * x + TILT * y + z;
    }

    /** True when a surface with this outward normal turns towards the viewer. */
    public static boolean facesViewer(float nx, float ny, float nz) {
        return -LEAN * nx + TILT * ny + nz > 0.0005f;
    }
}
