package com.hazardyard.game.engine;

import com.hazardyard.game.core.Effects;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;

/**
 * The visual and audible side of gameplay events, shared by every engine (host, solo, client) so a
 * muzzle flash or a kill looks and sounds the same wherever the match is simulated.
 */
final class Presentation {
    private Presentation() {}

    /** A weapon fired from (x, y): flash at the barrel tip, the shot sound, and a heard-shot ping for everyone but the local player. */
    static void shot(GameState st, int ownerId, int weaponId, float x, float y, float angle) {
        WeaponDef d = WeaponDef.byId(weaponId);
        st.effects.muzzle(d.muzzleX(x, angle), d.muzzleY(y, angle), angle, d.color);
        st.audio.shot(d.id, x, y);
        if (ownerId != st.localId) st.effects.noise(ownerId, x, y);
    }

    private static void impactFx(GameState st, int weaponId, float x, float y) {
        WeaponDef d = WeaponDef.byId(weaponId);
        if (d.style == WeaponDef.STYLE_ENERGY) st.effects.zap(x, y, d.color);
        else st.effects.impact(x, y, d.color);
    }

    static void hit(GameState st, int victimId, float x, float y, int weaponId, int damage) {
        impactFx(st, weaponId, x, y);
        if (damage > 0) st.audio.projectileHit(victimId, x, y);
    }

    static void wallImpact(GameState st, float x, float y, int weaponId) {
        impactFx(st, weaponId, x, y);
        st.audio.wallImpact(x, y);
    }

    static void kill(GameState st, int killerId, int victimId, int weaponId) {
        Effects fx = st.effects;
        fx.addKill(killerId, victimId, weaponId);
        if (victimId < 0 || victimId >= st.players.length) return;
        Player v = st.players[victimId];
        fx.burst(v.rx, v.ry, PlayerColors.of(victimId));
        st.audio.kill(killerId, victimId, v.rx, v.ry);
    }
}
