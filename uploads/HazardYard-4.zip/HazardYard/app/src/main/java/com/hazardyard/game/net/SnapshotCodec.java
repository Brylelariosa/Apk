package com.hazardyard.game.net;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Player;

/**
 * Compact world snapshot (host -> clients, 20 Hz). Layout after the type byte:
 * tick u16, phase u8, timeLeft u16 (1/10 s), countdown u8 (1/10 s), winner u8, pickupMask u16,
 * presentMask u8, then 15 bytes for every present player:
 * x i16, y i16 (1/8 unit), aim u8, health u8, flags u8, weapon u8, ammo u8, reload u8,
 * ackSeq u8, kills u8, deaths u8, respawn u8 (1/10 s), dodge cooldown u8 (1/100 s).
 */
public final class SnapshotCodec {
    private SnapshotCodec() {}

    public static final int F_ALIVE = 1;
    public static final int F_RELOADING = 2;
    public static final int F_PROTECTED = 4;
    public static final int F_ROLLING = 8;

    /** Reusable decode target. */
    public static final class Data {
        public int tick, phase, timeLeftDs, countdownDs, winner, pickupMask, presentMask;
        public final float[] x = new float[GameConfig.MAX_PLAYERS];
        public final float[] y = new float[GameConfig.MAX_PLAYERS];
        public final float[] aim = new float[GameConfig.MAX_PLAYERS];
        public final int[] health = new int[GameConfig.MAX_PLAYERS];
        public final int[] flags = new int[GameConfig.MAX_PLAYERS];
        public final int[] weapon = new int[GameConfig.MAX_PLAYERS];
        public final int[] ammo = new int[GameConfig.MAX_PLAYERS];
        public final int[] reload = new int[GameConfig.MAX_PLAYERS];
        public final int[] ack = new int[GameConfig.MAX_PLAYERS];
        public final int[] kills = new int[GameConfig.MAX_PLAYERS];
        public final int[] deaths = new int[GameConfig.MAX_PLAYERS];
        public final int[] respawnDs = new int[GameConfig.MAX_PLAYERS];
        public final int[] dodgeCdCs = new int[GameConfig.MAX_PLAYERS];
    }

    public static byte[] encode(PacketWriter w, GameState st, int tick) {
        w.begin(Protocol.S_SNAPSHOT);
        w.u16(tick & 0xFFFF);
        w.u8(st.phase);
        w.u16(MathUtil.clamp(Math.round(st.timeLeft * 10f), 0, 65535));
        w.u8(MathUtil.clamp(Math.round(st.countdown * 10f), 0, 255));
        w.u8(st.winnerId < 0 ? 255 : st.winnerId);
        int mask = 0;
        for (int i = 0; i < st.pickups.length && i < 16; i++) {
            if (st.pickups[i].active) mask |= 1 << i;
        }
        w.u16(mask);
        int present = 0;
        for (int i = 0; i < st.players.length; i++) {
            if (st.players[i].connected) present |= 1 << i;
        }
        w.u8(present);
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            w.i16(Packets.quantizePos(p.x));
            w.i16(Packets.quantizePos(p.y));
            w.u8(MathUtil.angleToU8(p.aim));
            w.u8(MathUtil.clamp(p.health, 0, 255));
            int flags = 0;
            if (p.alive) flags |= F_ALIVE;
            if (p.weapon.reloading) flags |= F_RELOADING;
            if (p.spawnProtect > 0f) flags |= F_PROTECTED;
            if (p.isRolling()) flags |= F_ROLLING;
            w.u8(flags);
            w.u8(p.weapon.def.id);
            w.u8(MathUtil.clamp(p.weapon.ammo, 0, 255));
            w.u8(MathUtil.clamp(Math.round(p.weapon.reloadFraction * 255f), 0, 255));
            w.u8(p.lastInputSeq);
            w.u8(MathUtil.clamp(p.kills, 0, 255));
            w.u8(MathUtil.clamp(p.deaths, 0, 255));
            w.u8(MathUtil.clamp((int) Math.ceil(p.respawnTimer * 10f), 0, 255));
            w.u8(MathUtil.clamp((int) Math.ceil(p.dodgeCooldown * 100f), 0, 255));
        }
        return w.finishFrame();
    }

    public static void decode(PacketReader r, Data d) {
        d.tick = r.u16();
        d.phase = r.u8();
        d.timeLeftDs = r.u16();
        d.countdownDs = r.u8();
        int win = r.u8();
        d.winner = win == 255 ? -1 : win;
        d.pickupMask = r.u16();
        d.presentMask = r.u8();
        for (int i = 0; i < GameConfig.MAX_PLAYERS; i++) {
            if ((d.presentMask & (1 << i)) == 0) continue;
            d.x[i] = r.i16() / 8f;
            d.y[i] = r.i16() / 8f;
            d.aim[i] = MathUtil.u8ToAngle(r.u8());
            d.health[i] = r.u8();
            d.flags[i] = r.u8();
            d.weapon[i] = r.u8();
            d.ammo[i] = r.u8();
            d.reload[i] = r.u8();
            d.ack[i] = r.u8();
            d.kills[i] = r.u8();
            d.deaths[i] = r.u8();
            d.respawnDs[i] = r.u8();
            d.dodgeCdCs[i] = r.u8();
        }
    }
}
