package com.hazardyard.game.core;

/**
 * Where gameplay code reports sounds. The game logic only says <em>what</em> happened and
 * <em>where</em>; the Android audio engine decides how it is mixed (distance, panning, volume).
 */
public interface SoundSink {
    /** Ignores everything: used until audio is attached, in tests and when sound is off. */
    SoundSink NONE = new SoundSink() {
        @Override
        public void play(int sound, float x, float y, float volume) {}

        @Override
        public void setListener(float x, float y) {}
    };

    /**
     * @param sound  one of {@link Sounds}
     * @param x      world position of the source
     * @param y      world position of the source
     * @param volume 0..1 loudness at the source
     */
    void play(int sound, float x, float y, float volume);

    /** Where the player is: sources are heard relative to this point. */
    void setListener(float x, float y);
}
