package com.hazardyard.game.ui;

import android.content.Context;
import android.view.View;

/**
 * Keeps a screen's content clear of the display cutout: the background fills the window, the content
 * view gets its designed padding plus the cutout insets.
 */
final class ScreenPadding {
    private final View view;
    private final int left, top, right, bottom;

    /** Base padding in dp. */
    ScreenPadding(View view, Context c, int leftDp, int topDp, int rightDp, int bottomDp) {
        this.view = view;
        this.left = Ui.dp(c, leftDp);
        this.top = Ui.dp(c, topDp);
        this.right = Ui.dp(c, rightDp);
        this.bottom = Ui.dp(c, bottomDp);
        apply(0, 0, 0, 0);
    }

    void apply(int insetL, int insetT, int insetR, int insetB) {
        view.setPadding(left + insetL, top + insetT, right + insetR, bottom + insetB);
    }
}
