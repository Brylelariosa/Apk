package com.hazardyard.game.render;

/**
 * Keeps the game smooth on weaker phones. It watches how long rendered frames really take and, when a
 * phone cannot hold about 60 frames per second for a moment, steps the graphics down one level; it
 * never steps back up during a session, so the picture cannot flip-flop. Pure logic with no Android
 * types, so it is easy to test.
 *
 * <p>Levels: {@link #FULL} everything; {@link #LIGHT} flat soldiers and pickups, no screen-edge
 * shading, no floor grime, simpler effects; {@link #MINIMAL} additionally no shadows.
 */
public final class QualityGovernor {
    public static final int FULL = 0;
    public static final int LIGHT = 1;
    public static final int MINIMAL = 2;

    /** Frames slower than this many seconds (a hitch, a pause, a screen change) say nothing about the phone and are ignored. */
    private static final float HITCH = 0.25f;
    /** A frame time above this share of the target counts as struggling. */
    private static final float TOLERANCE = 1.30f;
    /** How long it has to struggle before the level drops, in seconds. */
    private static final float PATIENCE = 1.4f;
    /** After a drop, how long the new level gets to settle before it is judged. */
    private static final float SETTLE = 1.2f;

    private final boolean adaptive;
    private int level;
    private float averaged;
    private float struggling;
    private float settle;

    /**
     * @param adaptive false keeps {@code startLevel} for the whole session
     * @param startLevel the level to begin with (0..2)
     */
    public QualityGovernor(boolean adaptive, int startLevel) {
        this.adaptive = adaptive;
        this.level = Math.max(FULL, Math.min(MINIMAL, startLevel));
        this.settle = SETTLE;
    }

    public int level() {
        return level;
    }

    /**
     * Reports one rendered frame.
     *
     * @param frameSeconds time since the previous rendered frame
     * @param vsyncSeconds the display's refresh interval (about 0.0167 at 60 Hz, 0.0083 at 120 Hz)
     * @return true when the level just dropped
     */
    public boolean onFrame(float frameSeconds, float vsyncSeconds) {
        if (!adaptive || level >= MINIMAL) return false;
        if (!(frameSeconds > 0f) || frameSeconds > HITCH) {
            struggling = 0f;
            return false;
        }
        if (settle > 0f) {
            settle -= frameSeconds;
            averaged = frameSeconds;
            return false;
        }
        // The game asks for at most about 90 frames a second, and a phone that manages 60 is fine.
        float target = Math.max(vsyncSeconds, 1f / 60f);
        averaged += (frameSeconds - averaged) * 0.12f;
        if (averaged > target * TOLERANCE) {
            struggling += frameSeconds;
            if (struggling >= PATIENCE) {
                level++;
                struggling = 0f;
                settle = SETTLE;
                return true;
            }
        } else {
            struggling = Math.max(0f, struggling - frameSeconds * 2f);
        }
        return false;
    }
}
