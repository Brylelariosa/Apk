package com.hazardyard.game.core;

/**
 * Tiny deterministic xorshift generator. The host and every client run the same sequence for a shot
 * (seeded with a value carried in the fire event), so shotgun pellets need not be sent one by one.
 */
public final class XorShift {
    private int state = 1;

    public XorShift(int seed) {
        setSeed(seed);
    }

    public void setSeed(int seed) {
        state = seed != 0 ? seed : 0x2545F491;
        nextInt();
        nextInt();
    }

    public int nextInt() {
        int x = state;
        x ^= x << 13;
        x ^= x >>> 17;
        x ^= x << 5;
        state = x;
        return x;
    }

    /** Uniform in [0, 1). */
    public float nextFloat() {
        return (nextInt() >>> 8) * (1f / (1 << 24));
    }

    /** Uniform in [-1, 1). */
    public float nextSigned() {
        return nextFloat() * 2f - 1f;
    }
}
