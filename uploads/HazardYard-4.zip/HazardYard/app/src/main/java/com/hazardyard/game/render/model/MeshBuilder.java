package com.hazardyard.game.render.model;

import java.util.Arrays;

/**
 * Assembles a {@link Mesh} from simple solids: boxes, oriented beams and tapered tubes. Every call
 * uses the current colour / group / flags, set with the {@code color}, {@code group} and
 * {@code accent} / {@code emissive} methods.
 */
public final class MeshBuilder {
    private float[] verts = new float[512];
    private int vertCount;
    private int[] starts = new int[64];
    private float[] normals = new float[192];
    private int[] colors = new int[64];
    private byte[] groups = new byte[64];
    private byte[] flags = new byte[64];
    private int faces;
    private int maxFaceVerts;

    private int curColor = 0xFF808080;
    private int curGroup;
    private int curFlags;

    public MeshBuilder color(int argb) {
        curColor = argb;
        return this;
    }

    public MeshBuilder group(int g) {
        curGroup = g;
        return this;
    }

    public MeshBuilder accent(boolean on) {
        curFlags = on ? (curFlags | Mesh.FLAG_ACCENT) : (curFlags & ~Mesh.FLAG_ACCENT);
        return this;
    }

    public MeshBuilder emissive(boolean on) {
        curFlags = on ? (curFlags | Mesh.FLAG_EMISSIVE) : (curFlags & ~Mesh.FLAG_EMISSIVE);
        return this;
    }

    // ------------------------------------------------------------------ solids

    /** Axis-aligned box. */
    public MeshBuilder box(float x0, float y0, float z0, float x1, float y1, float z1) {
        float[] p = new float[24];
        int n = 0;
        for (int iz = 0; iz < 2; iz++) {
            for (int iy = 0; iy < 2; iy++) {
                for (int ix = 0; ix < 2; ix++) {
                    p[n++] = ix == 0 ? x0 : x1;
                    p[n++] = iy == 0 ? y0 : y1;
                    p[n++] = iz == 0 ? z0 : z1;
                }
            }
        }
        // corner index = ix + 2*iy + 4*iz
        quad(p, 1, 3, 7, 5, 1f, 0f, 0f);   // +x
        quad(p, 0, 2, 6, 4, -1f, 0f, 0f);  // -x
        quad(p, 2, 3, 7, 6, 0f, 1f, 0f);   // +y
        quad(p, 0, 1, 5, 4, 0f, -1f, 0f);  // -y
        quad(p, 4, 5, 7, 6, 0f, 0f, 1f);   // +z
        quad(p, 0, 1, 3, 2, 0f, 0f, -1f);  // -z
        return this;
    }

    /**
     * A box stretched from point a to point b with a rectangular cross-section: {@code w} wide
     * (sideways) and {@code h} tall (perpendicular to the beam, towards "up" where possible).
     */
    public MeshBuilder beam(float ax, float ay, float az, float bx, float by, float bz, float w, float h) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-5f) return this;
        dx /= len; dy /= len; dz /= len;
        // side = horizontal vector perpendicular to the beam (fallback when the beam is vertical)
        float sx = -dy, sy = dx, sz = 0f;
        float sl = (float) Math.sqrt(sx * sx + sy * sy);
        if (sl < 1e-4f) { sx = 0f; sy = 1f; sl = 1f; }
        sx /= sl; sy /= sl;
        // up = d x side (perpendicular to both)
        float ux = dy * sz - dz * sy, uy = dz * sx - dx * sz, uz = dx * sy - dy * sx;
        float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul; uy /= ul; uz /= ul;
        if (uz < 0f) { ux = -ux; uy = -uy; uz = -uz; sx = -sx; sy = -sy; sz = -sz; }
        float hw = w * 0.5f, hh = h * 0.5f;
        float[] p = new float[24];
        int n = 0;
        for (int e = 0; e < 2; e++) {
            float cx = e == 0 ? ax : bx, cy = e == 0 ? ay : by, cz = e == 0 ? az : bz;
            for (int i = 0; i < 4; i++) {
                float ws = (i == 0 || i == 3) ? -hw : hw;     // side offset
                float hs = (i < 2) ? -hh : hh;                 // up offset
                p[n++] = cx + sx * ws + ux * hs;
                p[n++] = cy + sy * ws + uy * hs;
                p[n++] = cz + sz * ws + uz * hs;
            }
        }
        // corners: 0..3 at a (i: 0=-w-h,1=+w-h,2=+w+h,3=-w+h), 4..7 at b
        quad(p, 3, 2, 6, 7, ux, uy, uz);                  // up
        quad(p, 0, 1, 5, 4, -ux, -uy, -uz);               // down
        quad(p, 1, 2, 6, 5, sx, sy, sz);                  // +side
        quad(p, 0, 3, 7, 4, -sx, -sy, -sz);               // -side
        quad(p, 4, 5, 6, 7, dx, dy, dz);                  // end at b
        quad(p, 0, 1, 2, 3, -dx, -dy, -dz);               // end at a
        return this;
    }

    /**
     * A tapered tube from a to b: radius {@code ra} at a, {@code rb} at b, {@code sides} flat faces
     * around it, plus both end caps.
     */
    public MeshBuilder tube(float ax, float ay, float az, float bx, float by, float bz, float ra, float rb, int sides) {
        float dx = bx - ax, dy = by - ay, dz = bz - az;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-5f || sides < 3) return this;
        dx /= len; dy /= len; dz /= len;
        float ux, uy, uz;
        if (Math.abs(dz) < 0.9f) { ux = 0f; uy = 0f; uz = 1f; } else { ux = 1f; uy = 0f; uz = 0f; }
        // u = normalised (up x d), v = d x u
        float px = uy * dz - uz * dy, py = uz * dx - ux * dz, pz = ux * dy - uy * dx;
        float pl = (float) Math.sqrt(px * px + py * py + pz * pz);
        px /= pl; py /= pl; pz /= pl;
        float qx = dy * pz - dz * py, qy = dz * px - dx * pz, qz = dx * py - dy * px;
        float slope = (ra - rb) / len;   // normal tilts towards the wide end
        float[] cap = new float[sides * 3];
        float[] cap2 = new float[sides * 3];
        float[] quad = new float[12];
        for (int i = 0; i < sides; i++) {
            float a0 = (float) (2.0 * Math.PI * i / sides);
            float a1 = (float) (2.0 * Math.PI * (i + 1) / sides);
            float c0 = (float) Math.cos(a0), s0 = (float) Math.sin(a0);
            float c1 = (float) Math.cos(a1), s1 = (float) Math.sin(a1);
            float[] r0 = radial(px, py, pz, qx, qy, qz, c0, s0);
            float[] r1 = radial(px, py, pz, qx, qy, qz, c1, s1);
            quad[0] = ax + r0[0] * ra; quad[1] = ay + r0[1] * ra; quad[2] = az + r0[2] * ra;
            quad[3] = ax + r1[0] * ra; quad[4] = ay + r1[1] * ra; quad[5] = az + r1[2] * ra;
            quad[6] = bx + r1[0] * rb; quad[7] = by + r1[1] * rb; quad[8] = bz + r1[2] * rb;
            quad[9] = bx + r0[0] * rb; quad[10] = by + r0[1] * rb; quad[11] = bz + r0[2] * rb;
            float am = (a0 + a1) * 0.5f;
            float[] rm = radial(px, py, pz, qx, qy, qz, (float) Math.cos(am), (float) Math.sin(am));
            float nx = rm[0] + dx * slope, ny = rm[1] + dy * slope, nz = rm[2] + dz * slope;
            addFace(quad, 4, nx, ny, nz);
            cap[i * 3] = quad[0]; cap[i * 3 + 1] = quad[1]; cap[i * 3 + 2] = quad[2];
            cap2[i * 3] = quad[9]; cap2[i * 3 + 1] = quad[10]; cap2[i * 3 + 2] = quad[11];
        }
        addFace(cap2, sides, dx, dy, dz);
        addFace(cap, sides, -dx, -dy, -dz);
        return this;
    }

    /** Vertical hexagonal (or n-sided) prism / frustum around the axis through (cx, cy). */
    public MeshBuilder prism(float cx, float cy, float z0, float z1, float r0, float r1, int sides) {
        return tube(cx, cy, z0, cx, cy, z1, r0, r1, sides);
    }

    private static float[] radial(float px, float py, float pz, float qx, float qy, float qz, float c, float s) {
        return new float[] {px * c + qx * s, py * c + qy * s, pz * c + qz * s};
    }

    // ------------------------------------------------------------------ faces

    private void quad(float[] p, int i0, int i1, int i2, int i3, float nx, float ny, float nz) {
        float[] q = new float[12];
        int[] idx = {i0, i1, i2, i3};
        for (int k = 0; k < 4; k++) {
            q[k * 3] = p[idx[k] * 3];
            q[k * 3 + 1] = p[idx[k] * 3 + 1];
            q[k * 3 + 2] = p[idx[k] * 3 + 2];
        }
        addFace(q, 4, nx, ny, nz);
    }

    private void addFace(float[] pts, int count, float nx, float ny, float nz) {
        float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (l < 1e-6f) return;
        if (faces + 2 >= colors.length) {
            starts = Arrays.copyOf(starts, starts.length * 2);
            normals = Arrays.copyOf(normals, normals.length * 2);
            colors = Arrays.copyOf(colors, colors.length * 2);
            groups = Arrays.copyOf(groups, groups.length * 2);
            flags = Arrays.copyOf(flags, flags.length * 2);
        }
        if ((vertCount + count) * 3 > verts.length) verts = Arrays.copyOf(verts, Math.max(verts.length * 2, (vertCount + count) * 3));
        starts[faces] = vertCount;
        System.arraycopy(pts, 0, verts, vertCount * 3, count * 3);
        vertCount += count;
        normals[faces * 3] = nx / l;
        normals[faces * 3 + 1] = ny / l;
        normals[faces * 3 + 2] = nz / l;
        colors[faces] = curColor;
        groups[faces] = (byte) curGroup;
        flags[faces] = (byte) curFlags;
        maxFaceVerts = Math.max(maxFaceVerts, count);
        faces++;
    }

    public Mesh build() {
        int[] st = Arrays.copyOf(starts, faces + 1);
        st[faces] = vertCount;
        return new Mesh(faces, Arrays.copyOf(verts, vertCount * 3), st, Arrays.copyOf(normals, faces * 3),
                Arrays.copyOf(colors, faces), Arrays.copyOf(groups, faces), Arrays.copyOf(flags, faces), maxFaceVerts);
    }
}
