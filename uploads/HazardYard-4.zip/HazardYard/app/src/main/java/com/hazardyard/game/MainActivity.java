package com.hazardyard.game;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Insets;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.hazardyard.game.render.Palette;
import com.hazardyard.game.ui.AppController;

/**
 * Thin window host: sets up the full-screen root view and hands everything else (navigation, lobby,
 * network session, match) to {@link AppController}.
 */
public final class MainActivity extends Activity {
    private AppController app;
    private WifiManager.WifiLock wifiLock;

    /**
     * The game's text sizes belong to the game: a phone set to a larger or smaller system font, or a
     * different display zoom, must not change how the menus and the match screen are laid out.
     */
    @Override
    protected void attachBaseContext(Context base) {
        Configuration config = new Configuration(base.getResources().getConfiguration());
        config.fontScale = 1f;
        super.attachBaseContext(base.createConfigurationContext(config));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        goEdgeToEdge();
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Palette.BACKDROP);
        setContentView(root);
        app = new AppController(this, root);
        // The window now covers the camera cutout too; tell the app how much of each edge it takes.
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                Insets cut = insets.getInsets(WindowInsets.Type.displayCutout());
                app.setInsets(cut.left, cut.top, cut.right, cut.bottom);
                return insets;
            }
        });
        app.start();
        root.requestApplyInsets();
    }

    /**
     * Draws under the system bars and into the camera cutout area (notch / punch hole), so no black
     * strip is left beside the camera. The theme asks for the same; this also covers devices whose
     * theme handling differs.
     */
    private void goEdgeToEdge() {
        getWindow().setDecorFitsSystemWindows(false);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        getWindow().setAttributes(lp);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    /** Immersive mode: bars stay hidden and reappear only on an edge swipe. */
    private void hideSystemBars() {
        WindowInsetsController controller = getWindow().getInsetsController();
        if (controller == null) return;
        controller.hide(WindowInsets.Type.systemBars());
        controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (app != null && app.handleBack()) return;
        super.onBackPressed();
    }

    /**
     * While the game is in front, ask Wi-Fi to stay in its low-latency mode. Without it many phones put
     * the radio to sleep between packets, which shows up as bursts of lag in a local match.
     */
    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (wifiLock == null) {
                WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wifi != null) {
                    wifiLock = wifi.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "HazardYard:match");
                    wifiLock.setReferenceCounted(false);
                }
            }
            if (wifiLock != null && !wifiLock.isHeld()) wifiLock.acquire();
        } catch (RuntimeException e) {
            // Not allowed or not supported on this phone: the game works without it.
            wifiLock = null;
        }
    }

    @Override
    protected void onPause() {
        try {
            if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        } catch (RuntimeException e) {
            wifiLock = null;
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (app != null) app.shutdown();
        super.onDestroy();
    }
}
