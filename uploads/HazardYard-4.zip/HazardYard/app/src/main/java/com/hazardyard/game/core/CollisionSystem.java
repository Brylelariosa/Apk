package com.hazardyard.game.core;

/**
 * Collision queries against the tile map. Results are returned through public scratch fields so the
 * hot paths never allocate. An instance must only be used from one thread.
 *
 * <p>Tiles are not all plain squares: fences are thin lines, pillars and tanks are circles and angled
 * corner pieces are triangles, and both movement and bullets respect those real shapes.
 */
public final class CollisionSystem {
    private static final float NONE = 2f;

    private final TileMap map;
    /** Output of {@link #moveCircle} and {@link #pushOut}. */
    public float resX, resY;
    private final float[] tri = new float[6];
    private final float[] nrm = new float[2];

    public CollisionSystem(TileMap map) {
        this.map = map;
    }

    /** Moves a circle by (dx, dy), sliding along walls. The new centre is left in resX/resY. */
    public void moveCircle(float x, float y, float dx, float dy, float r) {
        resX = x + dx;
        resY = y + dy;
        resolve(r);
    }

    /** Pushes a circle out of solid tiles. The new centre is left in resX/resY. */
    public boolean pushOut(float x, float y, float r) {
        resX = x;
        resY = y;
        return resolve(r);
    }

    private boolean resolve(float r) {
        final float t = GameConfig.TILE;
        boolean moved = false;
        for (int iter = 0; iter < 4; iter++) {
            boolean any = false;
            int minTx = (int) Math.floor((resX - r) / t);
            int maxTx = (int) Math.floor((resX + r) / t);
            int minTy = (int) Math.floor((resY - r) / t);
            int maxTy = (int) Math.floor((resY + r) / t);
            for (int ty = minTy; ty <= maxTy; ty++) {
                for (int tx = minTx; tx <= maxTx; tx++) {
                    byte kind = map.kindAt(tx, ty);
                    if (kind == TileMap.FLOOR) continue;
                    boolean hit;
                    if (kind == TileMap.FENCE) hit = pushFence(tx, ty, r);
                    else if (kind == TileMap.PILLAR || kind == TileMap.TANK) hit = pushRound(map.circleAt(tx, ty), r);
                    else if (TileMap.isWedge(kind)) hit = pushWedge(kind, tx, ty, r);
                    else hit = pushTile(tx, ty, r);
                    if (hit) {
                        any = true;
                        moved = true;
                    }
                }
            }
            if (!any) break;
        }
        return moved;
    }

    /** A plain square tile (wall, crate, pool, or the outside of the map). */
    private boolean pushTile(int tx, int ty, float r) {
        final float t = GameConfig.TILE;
        float left = tx * t;
        float top = ty * t;
        float right = left + t;
        float bottom = top + t;
        float cx = MathUtil.clamp(resX, left, right);
        float cy = MathUtil.clamp(resY, top, bottom);
        float dx = resX - cx;
        float dy = resY - cy;
        float d2 = dx * dx + dy * dy;
        if (d2 >= r * r) return false;
        if (d2 > 1e-8f) {
            float d = (float) Math.sqrt(d2);
            float push = (r - d) / d;
            resX += dx * push;
            resY += dy * push;
        } else {
            // Centre is inside the tile: leave through the nearest face that opens onto
            // free space (never through the map border or into another solid tile).
            float pl = resX - left + r;
            float pr = right - resX + r;
            float pt = resY - top + r;
            float pb = bottom - resY + r;
            float big = Float.MAX_VALUE;
            float cl = map.isSolid(tx - 1, ty) ? big : pl;
            float cr = map.isSolid(tx + 1, ty) ? big : pr;
            float ct = map.isSolid(tx, ty - 1) ? big : pt;
            float cb = map.isSolid(tx, ty + 1) ? big : pb;
            if (cl == big && cr == big && ct == big && cb == big) {
                cl = pl;
                cr = pr;
                ct = pt;
                cb = pb;
            }
            float m = Math.min(Math.min(cl, cr), Math.min(ct, cb));
            if (m == cl) resX -= pl;
            else if (m == cr) resX += pr;
            else if (m == ct) resY -= pt;
            else resY += pb;
        }
        return true;
    }

    /** A thin axis-aligned box (used for the pieces of a fence). Leaves through the nearest face when the centre is inside. */
    private boolean pushBox(float left, float top, float right, float bottom, float r) {
        float cx = MathUtil.clamp(resX, left, right);
        float cy = MathUtil.clamp(resY, top, bottom);
        float dx = resX - cx;
        float dy = resY - cy;
        float d2 = dx * dx + dy * dy;
        if (d2 >= r * r) return false;
        if (d2 > 1e-8f) {
            float d = (float) Math.sqrt(d2);
            float push = (r - d) / d;
            resX += dx * push;
            resY += dy * push;
        } else {
            float pl = resX - left + r;
            float pr = right - resX + r;
            float pt = resY - top + r;
            float pb = bottom - resY + r;
            float m = Math.min(Math.min(pl, pr), Math.min(pt, pb));
            if (m == pl) resX -= pl;
            else if (m == pr) resX += pr;
            else if (m == pt) resY -= pt;
            else resY += pb;
        }
        return true;
    }

    /** The fence in one tile: a post in the middle plus a thin box towards every arm. */
    private boolean pushFence(int tx, int ty, float r) {
        final float t = GameConfig.TILE;
        final float h = TileMap.FENCE_HALF;
        float left = tx * t;
        float top = ty * t;
        float right = left + t;
        float bottom = top + t;
        float cx = left + t * 0.5f;
        float cy = top + t * 0.5f;
        int arms = map.fenceArms(tx, ty);
        boolean hit = pushBox(cx - h, cy - h, cx + h, cy + h, r);
        if ((arms & TileMap.ARM_L) != 0) hit |= pushBox(left, cy - h, cx, cy + h, r);
        if ((arms & TileMap.ARM_R) != 0) hit |= pushBox(cx, cy - h, right, cy + h, r);
        if ((arms & TileMap.ARM_U) != 0) hit |= pushBox(cx - h, top, cx + h, cy, r);
        if ((arms & TileMap.ARM_D) != 0) hit |= pushBox(cx - h, cy, cx + h, bottom, r);
        return hit;
    }

    private boolean pushRound(int circle, float r) {
        if (circle < 0) return false;
        float cx = map.circles[circle * 3];
        float cy = map.circles[circle * 3 + 1];
        float rad = map.circles[circle * 3 + 2] + r;
        float dx = resX - cx;
        float dy = resY - cy;
        float d2 = dx * dx + dy * dy;
        if (d2 >= rad * rad) return false;
        if (d2 > 1e-8f) {
            float d = (float) Math.sqrt(d2);
            float k = (rad - d) / d;
            resX += dx * k;
            resY += dy * k;
        } else {
            resX += rad;
        }
        return true;
    }

    /** Outward unit-ish normal of the triangle edge a->b (the third corner is o, which lies inside), into {@link #nrm}. */
    private void edgeNormal(float ax, float ay, float bx, float by, float ox, float oy) {
        float nx = by - ay;
        float ny = -(bx - ax);
        if (nx * (ox - ax) + ny * (oy - ay) > 0f) {
            nx = -nx;
            ny = -ny;
        }
        float len = (float) Math.sqrt(nx * nx + ny * ny);
        if (len > 1e-9f) {
            nx /= len;
            ny /= len;
        }
        nrm[0] = nx;
        nrm[1] = ny;
    }

    private boolean pushWedge(byte kind, int tx, int ty, float r) {
        final float t = GameConfig.TILE;
        TileMap.wedgeCorners(kind, tx * t, ty * t, tri);
        float px = resX;
        float py = resY;
        boolean inside = true;
        float bestD2 = Float.MAX_VALUE;
        float qx = 0f;
        float qy = 0f;
        for (int e = 0; e < 3; e++) {
            int a = e * 2;
            int b = ((e + 1) % 3) * 2;
            int o = ((e + 2) % 3) * 2;
            float ax = tri[a], ay = tri[a + 1], bx = tri[b], by = tri[b + 1];
            edgeNormal(ax, ay, bx, by, tri[o], tri[o + 1]);
            if (nrm[0] * (px - ax) + nrm[1] * (py - ay) > 0f) inside = false;
            float ex = bx - ax;
            float ey = by - ay;
            float len2 = ex * ex + ey * ey;
            float u = len2 > 0f ? MathUtil.clamp(((px - ax) * ex + (py - ay) * ey) / len2, 0f, 1f) : 0f;
            float cx = ax + ex * u;
            float cy = ay + ey * u;
            float d2 = (px - cx) * (px - cx) + (py - cy) * (py - cy);
            if (d2 < bestD2) {
                bestD2 = d2;
                qx = cx;
                qy = cy;
            }
        }
        if (!inside) {
            if (bestD2 >= r * r) return false;
            float d = (float) Math.sqrt(bestD2);
            if (d > 1e-6f) {
                float k = (r - d) / d;
                resX += (px - qx) * k;
                resY += (py - qy) * k;
            } else {
                // exactly on the edge: use the diagonal's normal
                edgeNormal(tri[2], tri[3], tri[4], tri[5], tri[0], tri[1]);
                resX += nrm[0] * r;
                resY += nrm[1] * r;
            }
            return true;
        }
        // The centre is inside the triangle: leave through the long edge, which faces open floor.
        edgeNormal(tri[2], tri[3], tri[4], tri[5], tri[0], tri[1]);
        float s = nrm[0] * (px - tri[2]) + nrm[1] * (py - tri[3]);   // <= 0 inside
        float push = r - s;
        resX += nrm[0] * push;
        resY += nrm[1] * push;
        return true;
    }

    // ------------------------------------------------------------------ rays

    /**
     * Walks the segment through the tile grid. Returns the fraction t (0..1) at which it first hits
     * something that stops bullets (a wall, a crate, a pillar, a tank or an angled piece), or -1 when
     * the segment is free. Fences and pools do not stop bullets.
     */
    public float raycast(float x0, float y0, float x1, float y1) {
        final float t = GameConfig.TILE;
        float dx = x1 - x0;
        float dy = y1 - y0;
        int tx = (int) Math.floor(x0 / t);
        int ty = (int) Math.floor(y0 / t);
        if (map.blocksShotsFully(tx, ty)) return 0f;
        float best = NONE;
        if (map.blocksShotsPartly(tx, ty)) best = Math.min(best, shapeHit(tx, ty, x0, y0, x1, y1));
        if (best <= 0f) return 0f;
        int stepX = dx > 0f ? 1 : -1;
        int stepY = dy > 0f ? 1 : -1;
        float inf = Float.MAX_VALUE;
        float tDeltaX = dx != 0f ? t / Math.abs(dx) : inf;
        float tDeltaY = dy != 0f ? t / Math.abs(dy) : inf;
        float tMaxX = dx > 0f ? ((tx + 1) * t - x0) / dx : (dx < 0f ? (tx * t - x0) / dx : inf);
        float tMaxY = dy > 0f ? ((ty + 1) * t - y0) / dy : (dy < 0f ? (ty * t - y0) / dy : inf);
        while (true) {
            float enter;
            if (tMaxX < tMaxY) {
                enter = tMaxX;
                tx += stepX;
                tMaxX += tDeltaX;
            } else {
                enter = tMaxY;
                ty += stepY;
                tMaxY += tDeltaY;
            }
            if (enter > 1f || enter >= best) break;
            if (map.blocksShotsFully(tx, ty)) return enter;
            if (map.blocksShotsPartly(tx, ty)) best = Math.min(best, shapeHit(tx, ty, x0, y0, x1, y1));
        }
        return best <= 1f ? best : -1f;
    }

    /** First hit of the segment with the round or angled obstacle in this tile, or {@link #NONE}. */
    private float shapeHit(int tx, int ty, float x0, float y0, float x1, float y1) {
        byte kind = map.kindAt(tx, ty);
        float f;
        if (TileMap.isWedge(kind)) {
            TileMap.wedgeCorners(kind, tx * GameConfig.TILE, ty * GameConfig.TILE, tri);
            f = segmentTriangle(x0, y0, x1, y1);
        } else {
            int c = map.circleAt(tx, ty);
            if (c < 0) return NONE;
            f = segmentCircle(x0, y0, x1, y1, map.circles[c * 3], map.circles[c * 3 + 1], map.circles[c * 3 + 2]);
        }
        return f < 0f ? NONE : f;
    }

    /** First intersection (fraction 0..1) of a segment with the triangle held in {@link #tri}, or -1. Starting inside returns 0. */
    private float segmentTriangle(float x0, float y0, float x1, float y1) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        float enter = 0f;
        float leave = 1f;
        for (int e = 0; e < 3; e++) {
            int a = e * 2;
            int b = ((e + 1) % 3) * 2;
            int o = ((e + 2) % 3) * 2;
            edgeNormal(tri[a], tri[a + 1], tri[b], tri[b + 1], tri[o], tri[o + 1]);
            float num = nrm[0] * (tri[a] - x0) + nrm[1] * (tri[a + 1] - y0);   // >= 0: start is inside this edge
            float den = nrm[0] * dx + nrm[1] * dy;
            if (Math.abs(den) < 1e-9f) {
                if (num < 0f) return -1f;
                continue;
            }
            float u = num / den;
            if (den < 0f) {
                if (u > enter) enter = u;
            } else if (u < leave) {
                leave = u;
            }
            if (enter > leave) return -1f;
        }
        return enter <= 1f ? enter : -1f;
    }

    /** First intersection (fraction 0..1) of a segment with a circle, or -1. Starting inside returns 0. */
    public static float segmentCircle(float x0, float y0, float x1, float y1, float cx, float cy, float r) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        float fx = x0 - cx;
        float fy = y0 - cy;
        float c = fx * fx + fy * fy - r * r;
        if (c <= 0f) return 0f;
        float a = dx * dx + dy * dy;
        if (a < 1e-9f) return -1f;
        float b = fx * dx + fy * dy;
        float disc = b * b - a * c;
        if (disc < 0f) return -1f;
        float t = (-b - (float) Math.sqrt(disc)) / a;
        return (t >= 0f && t <= 1f) ? t : -1f;
    }

    /**
     * Advances a bullet by dt. On return the bullet holds its new position (cut short at the impact
     * point when it hit a wall), the previous position for swept tests, and its remaining range.
     *
     * @return {@link #FLYING}, {@link #EXPIRED} (range used up) or {@link #HIT_WALL}
     */
    public int advance(Projectile b, float dt) {
        float dx = b.vx * dt;
        float dy = b.vy * dt;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        boolean expired = false;
        if (len >= b.remaining) {
            float k = len > 0f ? b.remaining / len : 0f;
            dx *= k;
            dy *= k;
            len = b.remaining;
            expired = true;
        }
        b.px = b.x;
        b.py = b.y;
        float nx = b.x + dx;
        float ny = b.y + dy;
        float hit = raycast(b.x, b.y, nx, ny);
        if (hit >= 0f) {
            b.x += dx * hit;
            b.y += dy * hit;
            return HIT_WALL;
        }
        b.x = nx;
        b.y = ny;
        b.remaining -= len;
        return expired ? EXPIRED : FLYING;
    }

    public static final int FLYING = 0;
    public static final int EXPIRED = 1;
    public static final int HIT_WALL = 2;
}
