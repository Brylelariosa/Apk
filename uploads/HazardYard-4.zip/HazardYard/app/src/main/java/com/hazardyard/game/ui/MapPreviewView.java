package com.hazardyard.game.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.MapLibrary;
import com.hazardyard.game.core.TileMap;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.render.MapShapes;
import com.hazardyard.game.render.MapTheme;
import com.hazardyard.game.render.Palette;

/** A small top-down picture of an arena in its own colours: walls, crates, water, spawns and weapons. */
final class MapPreviewView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final Path path = new Path();
    private int mapId = -1;

    MapPreviewView(Context c) {
        super(c);
    }

    void setMap(int id) {
        id = MapLibrary.clampId(id);
        if (id == mapId) return;
        mapId = id;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (mapId < 0) return;
        TileMap map = MapLibrary.get(mapId);
        MapTheme th = MapTheme.of(mapId);
        float w = getWidth();
        float h = getHeight();
        float d = getContext().getResources().getDisplayMetrics().density;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(th.backdrop);
        rect.set(0f, 0f, w, h);
        c.drawRoundRect(rect, 12f * d, 12f * d, paint);

        float pad = 8f * d;
        float s = Math.min((w - 2f * pad) / map.worldW, (h - 2f * pad) / map.worldH);
        float ox = (w - map.worldW * s) * 0.5f;
        float oy = (h - map.worldH * s) * 0.5f;
        paint.setColor(th.floorA);
        c.drawRect(ox, oy, ox + map.worldW * s, oy + map.worldH * s, paint);

        for (int pass = 0; pass < 4; pass++) {
            for (int b = 0; b < map.blockCount; b++) {
                int o = b * 5;
                int kind = map.blocks[o + 4];
                if (MapShapes.layerOf(kind) != pass) continue;
                switch (kind) {
                    case TileMap.WATER: paint.setColor(th.waterLight); break;
                    case TileMap.FENCE:
                    case TileMap.FENCE_JOINT: paint.setColor(Palette.withAlpha(th.fence, 190)); break;
                    case TileMap.CRATE: paint.setColor(th.crateFront); break;
                    case TileMap.PILLAR:
                    case TileMap.TANK: paint.setColor(th.wallFront); break;
                    default: paint.setColor(th.wallTop); break;
                }
                MapShapes.fill(c, map, b, ox, oy, s, paint, path, 1f);
            }
        }
        paint.setColor(Palette.withAlpha(th.accent, 150));
        for (int i = 0; i < map.spawnX.length; i++) {
            c.drawCircle(ox + map.spawnX[i] * s, oy + map.spawnY[i] * s, 1.8f * d, paint);
        }
        for (int i = 0; i < map.pickupX.length; i++) {
            paint.setColor(WeaponDef.byId(map.pickupWeapon[i]).color);
            c.drawCircle(ox + map.pickupX[i] * s, oy + map.pickupY[i] * s, 2.4f * d, paint);
        }
    }
}
