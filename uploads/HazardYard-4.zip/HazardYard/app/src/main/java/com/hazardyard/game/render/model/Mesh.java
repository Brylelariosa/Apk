package com.hazardyard.game.render.model;

/**
 * A fixed low-poly model: flat-coloured convex polygons with outward normals. Built once by
 * {@link MeshBuilder}; never modified afterwards, so one instance is shared by every player and
 * pickup. Model space: x forward, y to the right, z up.
 */
public final class Mesh {
    /** Face colour is the player's colour instead of the colour stored in the mesh. */
    public static final int FLAG_ACCENT = 1;
    /** Face is lit by itself (lamps, glowing energy): no shading is applied. */
    public static final int FLAG_EMISSIVE = 2;

    public final int faceCount;
    /** Vertex coordinates of all faces, 3 floats per vertex, faces back to back. */
    public final float[] verts;
    /** faceStart[f] .. faceStart[f+1] is the vertex range of face f (in vertices, not floats). */
    public final int[] faceStart;
    public final float[] normals;
    public final int[] color;
    public final byte[] group;
    public final byte[] flags;
    /** Largest number of vertices of any face. */
    public final int maxFaceVerts;

    Mesh(int faceCount, float[] verts, int[] faceStart, float[] normals, int[] color, byte[] group, byte[] flags, int maxFaceVerts) {
        this.faceCount = faceCount;
        this.verts = verts;
        this.faceStart = faceStart;
        this.normals = normals;
        this.color = color;
        this.group = group;
        this.flags = flags;
        this.maxFaceVerts = maxFaceVerts;
    }

    public int vertexCount() {
        return faceStart[faceCount];
    }
}
