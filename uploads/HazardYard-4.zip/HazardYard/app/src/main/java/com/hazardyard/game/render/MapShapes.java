package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.TileMap;

/**
 * Flat top-down drawing of one merged map block (a wall, a round tank, an angled corner, a fence...)
 * in its real shape, shared by the minimap and the map preview so both show the same arena. The
 * caller sets the paint's colour (and FILL style) first.
 */
public final class MapShapes {
    private MapShapes() {}

    private static final float T = GameConfig.TILE;

    /** Draw order: pools first, then fences, crates, everything else on top. */
    public static int layerOf(int kind) {
        if (kind == TileMap.WATER) return 0;
        if (kind == TileMap.FENCE || kind == TileMap.FENCE_JOINT) return 1;
        if (kind == TileMap.CRATE) return 2;
        return 3;
    }

    /**
     * @param ox,oy screen position of the map's top-left corner
     * @param s     screen pixels per world unit
     * @param minLine thinnest line to draw for fences, in pixels
     */
    public static void fill(Canvas c, TileMap map, int block, float ox, float oy, float s, Paint paint, Path path, float minLine) {
        int o = block * 5;
        int kind = map.blocks[o + 4];
        float x0 = ox + map.blocks[o] * T * s;
        float y0 = oy + map.blocks[o + 1] * T * s;
        float x1 = x0 + map.blocks[o + 2] * T * s;
        float y1 = y0 + map.blocks[o + 3] * T * s;
        switch (kind) {
            case TileMap.PILLAR:
                c.drawCircle((x0 + x1) * 0.5f, (y0 + y1) * 0.5f, Math.max(minLine, TileMap.PILLAR_RADIUS * s), paint);
                break;
            case TileMap.TANK:
                c.drawCircle((x0 + x1) * 0.5f, (y0 + y1) * 0.5f, TileMap.TANK_RADIUS * s, paint);
                break;
            case TileMap.WEDGE_NW:
            case TileMap.WEDGE_NE:
            case TileMap.WEDGE_SW:
            case TileMap.WEDGE_SE:
                wedge(c, (byte) kind, x0, y0, x1, y1, paint, path);
                break;
            case TileMap.FENCE: {
                float half = Math.max(minLine, TileMap.FENCE_HALF * 2f * s) * 0.5f;
                if (x1 - x0 >= y1 - y0) {
                    float yc = (y0 + y1) * 0.5f;
                    c.drawRect(x0, yc - half, x1, yc + half, paint);
                } else {
                    float xc = (x0 + x1) * 0.5f;
                    c.drawRect(xc - half, y0, xc + half, y1, paint);
                }
                break;
            }
            case TileMap.FENCE_JOINT: {
                float half = Math.max(minLine, TileMap.FENCE_HALF * 2f * s) * 0.5f;
                float xc = (x0 + x1) * 0.5f;
                float yc = (y0 + y1) * 0.5f;
                int arms = map.fenceArms(map.blocks[o], map.blocks[o + 1]);
                c.drawRect(xc - half, yc - half, xc + half, yc + half, paint);
                if ((arms & TileMap.ARM_L) != 0) c.drawRect(x0, yc - half, xc, yc + half, paint);
                if ((arms & TileMap.ARM_R) != 0) c.drawRect(xc, yc - half, x1, yc + half, paint);
                if ((arms & TileMap.ARM_U) != 0) c.drawRect(xc - half, y0, xc + half, yc, paint);
                if ((arms & TileMap.ARM_D) != 0) c.drawRect(xc - half, yc, xc + half, y1, paint);
                break;
            }
            default:
                c.drawRect(x0, y0, Math.max(x1, x0 + 1f), Math.max(y1, y0 + 1f), paint);
                break;
        }
    }

    private static void wedge(Canvas c, byte kind, float l, float t, float r, float b, Paint paint, Path path) {
        path.reset();
        switch (kind) {
            case TileMap.WEDGE_NW:
                path.moveTo(l, t);
                path.lineTo(r, t);
                path.lineTo(l, b);
                break;
            case TileMap.WEDGE_NE:
                path.moveTo(r, t);
                path.lineTo(r, b);
                path.lineTo(l, t);
                break;
            case TileMap.WEDGE_SW:
                path.moveTo(l, b);
                path.lineTo(l, t);
                path.lineTo(r, b);
                break;
            default:
                path.moveTo(r, b);
                path.lineTo(r, t);
                path.lineTo(l, b);
                break;
        }
        path.close();
        c.drawPath(path, paint);
    }
}
