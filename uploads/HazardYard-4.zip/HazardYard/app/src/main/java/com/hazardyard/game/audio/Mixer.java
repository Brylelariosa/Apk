package com.hazardyard.game.audio;

/**
 * Software mixer: plays several of the pre-built sounds at once into a stereo 16-bit buffer, each
 * with its own left/right gain and playback speed (small pitch changes make repeated shots sound
 * less mechanical). {@link #trigger} is called from the game thread, {@link #mix} from the audio
 * thread; one short lock keeps the voice table consistent. Pure Java, so it runs in plain JVM tests.
 */
public final class Mixer {
    public static final int MAX_VOICES = 16;
    /** At most this many copies of one sound play at the same time (the oldest is cut off). */
    private static final int MAX_PER_SOUND = 5;
    private static final int CHUNK = 1024;

    private final short[][] pcm;
    private final int[] minGapFrames;
    private final long[] lastStart;
    private final Object lock = new Object();

    private final boolean[] active = new boolean[MAX_VOICES];
    private final int[] sound = new int[MAX_VOICES];
    private final float[] pos = new float[MAX_VOICES];
    private final float[] rate = new float[MAX_VOICES];
    private final float[] gainL = new float[MAX_VOICES];
    private final float[] gainR = new float[MAX_VOICES];
    private final long[] order = new long[MAX_VOICES];
    private long counter;
    private long frameClock;

    private final float[] accL = new float[CHUNK];
    private final float[] accR = new float[CHUNK];

    /**
     * @param pcm          mono 16-bit samples per sound id
     * @param minGapMillis minimum time between two starts of the same sound (0 = unlimited), per id
     */
    public Mixer(short[][] pcm, int[] minGapMillis) {
        this.pcm = pcm;
        this.minGapFrames = new int[pcm.length];
        this.lastStart = new long[pcm.length];
        for (int i = 0; i < pcm.length; i++) {
            minGapFrames[i] = i < minGapMillis.length ? minGapMillis[i] * Synth.RATE / 1000 : 0;
            lastStart[i] = Long.MIN_VALUE / 2;
        }
    }

    public int sampleRate() {
        return Synth.RATE;
    }

    /** Starts a sound. Returns false when it was skipped (unknown id, too soon after the last one, silent). */
    public boolean trigger(int soundId, float left, float right, float speed) {
        if (soundId < 0 || soundId >= pcm.length || pcm[soundId].length < 2) return false;
        if (left < 0.003f && right < 0.003f) return false;
        synchronized (lock) {
            if (frameClock - lastStart[soundId] < minGapFrames[soundId]) return false;
            int slot = -1;
            int sameCount = 0;
            int oldestSame = -1;
            int oldest = -1;
            for (int v = 0; v < MAX_VOICES; v++) {
                if (!active[v]) {
                    if (slot < 0) slot = v;
                    continue;
                }
                if (oldest < 0 || order[v] < order[oldest]) oldest = v;
                if (sound[v] == soundId) {
                    sameCount++;
                    if (oldestSame < 0 || order[v] < order[oldestSame]) oldestSame = v;
                }
            }
            if (sameCount >= MAX_PER_SOUND) slot = oldestSame;
            else if (slot < 0) slot = oldest;
            active[slot] = true;
            sound[slot] = soundId;
            pos[slot] = 0f;
            rate[slot] = speed < 0.25f ? 0.25f : (speed > 4f ? 4f : speed);
            gainL[slot] = left;
            gainR[slot] = right;
            order[slot] = counter++;
            lastStart[soundId] = frameClock;
            return true;
        }
    }

    public int activeVoices() {
        synchronized (lock) {
            int n = 0;
            for (boolean a : active) if (a) n++;
            return n;
        }
    }

    /** Stops everything immediately (the screen is going away). */
    public void silence() {
        synchronized (lock) {
            for (int v = 0; v < MAX_VOICES; v++) active[v] = false;
        }
    }

    /** Fills {@code out} (interleaved stereo, {@code frames} frames) with the next stretch of audio. */
    public void mix(short[] out, int frames) {
        int done = 0;
        while (done < frames) {
            int n = Math.min(CHUNK, frames - done);
            mixChunk(out, done, n);
            done += n;
        }
    }

    private void mixChunk(short[] out, int offsetFrames, int n) {
        for (int i = 0; i < n; i++) {
            accL[i] = 0f;
            accR[i] = 0f;
        }
        synchronized (lock) {
            for (int v = 0; v < MAX_VOICES; v++) {
                if (!active[v]) continue;
                short[] s = pcm[sound[v]];
                int len = s.length - 1;
                float p = pos[v];
                float r = rate[v];
                float gl = gainL[v] * (1f / 32768f);
                float gr = gainR[v] * (1f / 32768f);
                int i = 0;
                for (; i < n; i++) {
                    int idx = (int) p;
                    if (idx >= len) {
                        active[v] = false;
                        break;
                    }
                    float frac = p - idx;
                    float x = s[idx] + (s[idx + 1] - s[idx]) * frac;
                    accL[i] += x * gl;
                    accR[i] += x * gr;
                    p += r;
                }
                pos[v] = p;
            }
            frameClock += n;
        }
        int o = offsetFrames * 2;
        for (int i = 0; i < n; i++) {
            out[o++] = toPcm(accL[i]);
            out[o++] = toPcm(accR[i]);
        }
    }

    /** Gentle limiter: linear up to 0.7, then a smooth knee towards full scale, so loud scenes never clip harshly. */
    static short toPcm(float x) {
        float a = Math.abs(x);
        if (a > 0.7f) {
            float over = (a - 0.7f) / 0.3f;
            a = 0.7f + 0.3f * (float) Math.tanh(over);
        }
        float y = x < 0f ? -a : a;
        return (short) Math.round(y * 32767f);
    }
}
