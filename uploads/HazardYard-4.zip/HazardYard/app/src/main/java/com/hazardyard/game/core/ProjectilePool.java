package com.hazardyard.game.core;

/**
 * Fixed-capacity object pool for bullets: no allocation while playing. Active bullets are kept in a
 * compact index list so iteration cost follows the number of live bullets, not the capacity.
 */
public final class ProjectilePool {
    public final Projectile[] items;
    /** Slots of active bullets, valid in [0, activeCount). */
    public final int[] activeList;
    public int activeCount;
    /** Scratch generator used when spawning pellet spreads (see {@link WeaponDef#spawn}). */
    public final XorShift rng = new XorShift(1);

    private final int[] freeStack;
    private int freeCount;

    public ProjectilePool(int capacity) {
        items = new Projectile[capacity];
        activeList = new int[capacity];
        freeStack = new int[capacity];
        for (int i = 0; i < capacity; i++) {
            items[i] = new Projectile(i);
            freeStack[i] = capacity - 1 - i;
        }
        freeCount = capacity;
    }

    /** Returns a cleared bullet, or null when the pool is exhausted. */
    public Projectile acquire() {
        if (freeCount == 0) return null;
        Projectile p = items[freeStack[--freeCount]];
        p.active = true;
        p.activeIndex = activeCount;
        activeList[activeCount++] = p.slot;
        return p;
    }

    /**
     * Returns a bullet to the pool. Safe while iterating the active list backwards
     * (from activeCount - 1 down to 0): the swapped-in entry was already visited.
     */
    public void release(Projectile p) {
        if (!p.active) return;
        p.active = false;
        int idx = p.activeIndex;
        int lastSlot = activeList[--activeCount];
        activeList[idx] = lastSlot;
        items[lastSlot].activeIndex = idx;
        freeStack[freeCount++] = p.slot;
    }

    public void clear() {
        for (int i = activeCount - 1; i >= 0; i--) {
            release(items[activeList[i]]);
        }
    }

    /** Linear lookup by network id; only used when a hit event arrives. */
    public Projectile findById(int id) {
        for (int i = 0; i < activeCount; i++) {
            Projectile p = items[activeList[i]];
            if (p.id == id) return p;
        }
        return null;
    }
}
