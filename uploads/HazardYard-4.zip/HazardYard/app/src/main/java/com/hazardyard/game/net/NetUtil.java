package com.hazardyard.game.net;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

/** Small helpers around the device's network interfaces (Wi-Fi client or Wi-Fi hotspot alike). */
public final class NetUtil {
    private NetUtil() {}

    /** Directed broadcast addresses of every active IPv4 interface, e.g. 192.168.1.255. */
    public static List<InetAddress> broadcastAddresses() {
        List<InetAddress> out = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
            if (nis == null) return out;
            while (nis.hasMoreElements()) {
                NetworkInterface ni = nis.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null && !out.contains(b)) out.add(b);
                }
            }
        } catch (SocketException ignored) {
            // No usable interface: discovery simply finds nothing.
        }
        return out;
    }

    /** Best guess of this device's LAN address for showing it to other players, or "" if offline. */
    public static String localAddressText() {
        String fallback = "";
        try {
            Enumeration<NetworkInterface> nis = NetworkInterface.getNetworkInterfaces();
            if (nis == null) return "";
            while (nis.hasMoreElements()) {
                NetworkInterface ni = nis.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                String name = ni.getName() == null ? "" : ni.getName();
                boolean wifiLike = name.startsWith("wlan") || name.startsWith("ap") || name.startsWith("swlan")
                        || name.startsWith("eth");
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress a = addrs.nextElement();
                    if (!(a instanceof Inet4Address) || !a.isSiteLocalAddress()) continue;
                    if (wifiLike) return a.getHostAddress();
                    if (fallback.isEmpty()) fallback = a.getHostAddress();
                }
            }
        } catch (SocketException ignored) {
            // fall through
        }
        return fallback;
    }
}
