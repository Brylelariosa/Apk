package com.hazardyard.game.ui;

import android.content.Context;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hazardyard.game.render.Palette;

/** A row of mutually exclusive choices, each a rounded chip; the selected one is highlighted. */
final class SegmentedControl extends LinearLayout {
    interface OnChange {
        void onChange(int index);
    }

    private final TextView[] chips;
    private final OnChange listener;
    private int selected;

    SegmentedControl(Context c, String[] labels, int selected, OnChange listener) {
        super(c);
        this.listener = listener;
        this.selected = selected;
        setOrientation(HORIZONTAL);
        chips = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int index = i;
            TextView t = new TextView(c);
            t.setText(labels[i]);
            t.setGravity(Gravity.CENTER);
            t.setTypeface(Ui.MEDIUM);
            t.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14f);
            t.setIncludeFontPadding(false);
            t.setClickable(true);
            t.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    select(index);
                    SegmentedControl.this.listener.onChange(index);
                }
            });
            chips[i] = t;
            addView(t, Ui.lp(0, Ui.dp(c, 42), 1f, i == 0 ? 0 : 6, 0, 0, 0, c));
        }
        paint();
    }

    int selected() {
        return selected;
    }

    /** Changes the highlighted choice without calling the listener. */
    void select(int index) {
        if (index < 0 || index >= chips.length) return;
        selected = index;
        paint();
    }

    private void paint() {
        for (int i = 0; i < chips.length; i++) {
            boolean on = i == selected;
            chips[i].setTextColor(on ? Palette.ACCENT_DARK : Palette.TEXT);
            chips[i].setBackground(on
                    ? Ui.rounded(getContext(), Palette.ACCENT, Palette.ACCENT, 10f, 1.5f)
                    : Ui.rounded(getContext(), 0xFF1E2733, 0xFF3A4757, 10f, 1.5f));
        }
    }
}
