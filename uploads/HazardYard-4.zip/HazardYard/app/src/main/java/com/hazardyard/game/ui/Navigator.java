package com.hazardyard.game.ui;

import com.hazardyard.game.audio.SoundEngine;
import com.hazardyard.game.net.ClientManager;
import com.hazardyard.game.net.HostManager;
import com.hazardyard.game.settings.GameSettings;

/** What screens may ask of the activity; keeps screens free of any knowledge about each other. */
interface Navigator {
    String playerName();

    void setPlayerName(String name);

    /** Shows the main menu and closes any open lobby or connection. {@code notice} may be null. */
    void showMenu(String notice);

    void showJoin();

    /** Opens a lobby on this device. */
    void createGame();

    /** Connects to a host found by discovery or typed in by hand. */
    void connectTo(String address, int port);

    /** Host pressed Start Game. */
    void startMatch();

    /** Live hosting / client objects (null when not in that role). */
    HostManager host();

    ClientManager client();

    /** The running match ended (normally or because the connection died). */
    void onMatchFinished(String reason);

    void toast(String message);

    /** The live settings (controls layout, graphics, sound). Edit, then call {@link #saveSettings}. */
    GameSettings settings();

    void saveSettings();

    /** Sound output shared by all matches. */
    SoundEngine sound();

    void showSettings();

    /** The full-screen control layout editor. */
    void showControlsEditor();

    /** Setup page for a match against computer players. */
    void showSoloSetup();

    /** Starts a match against bots. */
    void startSolo(int mapId, int bots, int difficulty);

    /** Starts the same solo match again (pause menu). */
    void restartSolo();

    /** Remembered choices of the solo setup page: map, opponents, difficulty. */
    int[] soloChoices();
}
