package com.hazardyard.game.core;

/** One pooled bullet. Instances are owned and recycled by {@link ProjectilePool}. */
public final class Projectile {
    public boolean active;
    /** 16-bit id shared by host and clients so hit events can name the bullet. */
    public int id;
    public int owner;
    public int weaponId;
    public int damage;
    public float radius;
    public float x, y;
    /** Position before the latest step; the swept segment px,py -> x,y is what collides. */
    public float px, py;
    public float vx, vy;
    /** Distance the bullet may still travel. */
    public float remaining;

    /** Index of this bullet inside {@link ProjectilePool#activeList} (pool-internal). */
    int activeIndex;
    /** Slot of this bullet inside {@link ProjectilePool#items} (pool-internal). */
    final int slot;

    Projectile(int slot) {
        this.slot = slot;
    }
}
