package com.hazardyard.game.core;

/**
 * The authoritative game rules, run only on the host: movement, shooting, projectiles, damage,
 * death, respawn, pickups and the match clock. It works on a {@link GameState} and reports what
 * happened through a {@link WorldListener}. Pure Java, no Android dependencies.
 */
public final class GameWorld {
    private final GameState st;
    private final WorldListener listener;
    private final CollisionSystem col;
    private final XorShift rng = new XorShift(0x5EED);
    private final float[] dir = new float[2];
    private int nextProjectileId = 1;

    public GameWorld(GameState st, WorldListener listener) {
        this.st = st;
        this.listener = listener;
        this.col = st.collision;
    }

    public GameState state() {
        return st;
    }

    // ------------------------------------------------------------------ roster

    public void addPlayer(int id, String name) {
        Player p = st.players[id];
        p.connected = true;
        p.name = name;
        p.resetForMatch();
    }

    public void removePlayer(int id) {
        Player p = st.players[id];
        if (!p.connected) return;
        p.connected = false;
        p.alive = false;
        p.moveX = 0f;
        p.moveY = 0f;
        p.firing = false;
        p.rollTimer = 0f;
        p.dodgeRequest = false;
    }

    // ------------------------------------------------------------------ input (validated here)

    /**
     * Stores the latest controls of a player. Values are sanitised: a misbehaving client cannot
     * move faster than the speed limit or feed NaNs into the simulation.
     */
    public void setInput(int id, float moveX, float moveY, float aim, boolean firing, int seq) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (!p.connected) return;
        if (!MathUtil.isFinite(moveX) || !MathUtil.isFinite(moveY)) {
            moveX = 0f;
            moveY = 0f;
        }
        p.moveX = MathUtil.clamp(moveX, -1f, 1f);
        p.moveY = MathUtil.clamp(moveY, -1f, 1f);
        p.aimTarget = MathUtil.wrapAngle(aim);
        p.hasAimInput = true;
        if (firing && !p.firing) p.pulls++;
        p.firing = firing;
        p.lastInputSeq = seq & 0xFF;
    }

    public void requestReload(int id) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (p.connected) p.reloadRequest = true;
    }

    /**
     * Asks for a dodge roll along the unit vector (dx, dy). A zero vector lets the host choose from
     * the player's latest input (moving: that way, standing still: the way they face). The request
     * is turned down in {@link #updatePlayer} when a roll is not allowed right now.
     */
    public void requestDodge(int id, float dx, float dy) {
        if (id < 0 || id >= st.players.length) return;
        Player p = st.players[id];
        if (!p.connected) return;
        if (!MathUtil.isFinite(dx) || !MathUtil.isFinite(dy)) {
            dx = 0f;
            dy = 0f;
        }
        p.dodgeRequest = true;
        p.dodgeReqX = dx;
        p.dodgeReqY = dy;
    }

    // ------------------------------------------------------------------ match flow

    public void startMatch() {
        st.projectiles.clear();
        st.effects.clear();
        for (int i = 0; i < st.pickups.length; i++) {
            st.pickups[i].active = true;
            st.pickups[i].timer = 0f;
        }
        st.timeLeft = GameConfig.MATCH_SECONDS;
        st.countdown = GameConfig.COUNTDOWN_SECONDS;
        st.winnerId = -1;
        st.resultsTimer = 0f;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            p.resetForMatch();
            placeAtSpawn(p);
            p.alive = true;
        }
        setPhase(GameState.PHASE_COUNTDOWN);
    }

    private void setPhase(int phase) {
        st.phase = phase;
        listener.onPhaseChanged(phase);
    }

    private void endMatch() {
        if (st.phase != GameState.PHASE_PLAYING) return;
        int best = -1;
        boolean tie = false;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected) continue;
            if (best < 0) {
                best = i;
                tie = false;
                continue;
            }
            Player b = st.players[best];
            if (p.kills > b.kills || (p.kills == b.kills && p.deaths < b.deaths)) {
                best = i;
                tie = false;
            } else if (p.kills == b.kills && p.deaths == b.deaths) {
                tie = true;
            }
        }
        st.winnerId = tie ? -1 : best;
        st.resultsTimer = GameConfig.RESULTS_SECONDS;
        setPhase(GameState.PHASE_ENDED);
    }

    // ------------------------------------------------------------------ simulation step

    public void step(float dt) {
        switch (st.phase) {
            case GameState.PHASE_COUNTDOWN:
                st.countdown -= dt;
                if (st.countdown <= 0f) {
                    st.countdown = 0f;
                    setPhase(GameState.PHASE_PLAYING);
                }
                break;
            case GameState.PHASE_PLAYING:
                st.timeLeft -= dt;
                if (st.timeLeft <= 0f) {
                    st.timeLeft = 0f;
                    endMatch();
                }
                break;
            case GameState.PHASE_ENDED:
                st.resultsTimer -= dt;
                if (st.resultsTimer <= 0f) {
                    st.resultsTimer = 0f;
                    setPhase(GameState.PHASE_FINISHED);
                }
                break;
            default:
                break;
        }
        boolean live = st.phase == GameState.PHASE_PLAYING;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (p.connected) updatePlayer(p, dt, live);
        }
        if (live) separatePlayers();
        updateProjectiles(dt);
        if (live) updatePickups(dt);
    }

    private void updatePlayer(Player p, float dt, boolean live) {
        if (p.hitFlash > 0f) p.hitFlash -= dt;
        if (p.muzzleFlash > 0f) p.muzzleFlash -= dt;
        if (!p.alive) {
            p.dodgeRequest = false;
            if (live) {
                p.respawnTimer -= dt;
                if (p.respawnTimer <= 0f) respawn(p);
            }
            return;
        }
        if (p.spawnProtect > 0f) p.spawnProtect -= dt;
        Weapon w = p.weapon;
        w.update(dt);
        if (!live) {
            p.dodgeRequest = false;
            return;
        }

        if (p.hasAimInput) {
            p.aim = MathUtil.rotateToward(p.aim, p.aimTarget, GameConfig.PLAYER_TURN_RATE * dt);
        }
        Dodge.tickCooldown(p, dt);

        if (p.reloadRequest) {
            p.reloadRequest = false;
            w.startReload();
        }

        if (p.dodgeRequest) {
            p.dodgeRequest = false;
            if (Dodge.canStart(p, GameConfig.DODGE_GRACE)) {
                float dx = p.dodgeReqX;
                float dy = p.dodgeReqY;
                if (dx == 0f && dy == 0f) {
                    Dodge.pickDirection(p.moveX, p.moveY, p.aim, dir);
                    dx = dir[0];
                    dy = dir[1];
                }
                Dodge.start(p, dx, dy);
            }
        }
        if (p.isRolling()) {
            // A roll replaces walking and shooting; the trigger keeps its state and resumes afterwards.
            Dodge.step(p, col, dt);
            return;
        }

        float mx = p.moveX;
        float my = p.moveY;
        float len2 = mx * mx + my * my;
        if (len2 > 1f) {
            float inv = 1f / (float) Math.sqrt(len2);
            mx *= inv;
            my *= inv;
            len2 = 1f;
        }
        if (len2 > 0f) {
            float step = GameConfig.PLAYER_SPEED * dt;
            col.moveCircle(p.x, p.y, mx * step, my * step, GameConfig.PLAYER_RADIUS);
            p.x = col.resX;
            p.y = col.resY;
        }

        if (p.pulls != p.handledPulls) {
            p.handledPulls = p.pulls;
            p.pullBuffer = GameConfig.PULL_BUFFER;
        }
        boolean trigger = w.def.automatic ? p.firing : p.pullBuffer > 0f;
        if (p.pullBuffer > 0f) p.pullBuffer -= dt;
        if (trigger) {
            if (w.canFire()) {
                fire(p);
                if (!w.def.automatic) p.pullBuffer = 0f;
            } else if (w.ammo <= 0 && !w.reloading) {
                w.startReload();
            }
        }
    }

    private void fire(Player p) {
        WeaponDef d = p.weapon.def;
        int seed = rng.nextInt() & 0xFFFF;
        int baseId = nextProjectileId;
        nextProjectileId = (nextProjectileId + d.pellets) & 0xFFFF;
        d.spawn(st.projectiles, col, p.id, p.x, p.y, p.aim, seed, baseId);
        p.weapon.onFired();
        p.muzzleFlash = 0.06f;
        listener.onShot(p, d, p.x, p.y, p.aim, seed, baseId);
    }

    private void updateProjectiles(float dt) {
        ProjectilePool pool = st.projectiles;
        for (int i = pool.activeCount - 1; i >= 0; i--) {
            Projectile b = pool.items[pool.activeList[i]];
            int status = col.advance(b, dt);
            int victim = -1;
            float bestT = 2f;
            for (int j = 0; j < st.players.length; j++) {
                Player q = st.players[j];
                if (!q.connected || !q.alive || q.id == b.owner || Dodge.invulnerable(q)) continue;
                float t = CollisionSystem.segmentCircle(b.px, b.py, b.x, b.y, q.x, q.y,
                        GameConfig.PLAYER_RADIUS + b.radius);
                if (t >= 0f && t < bestT) {
                    bestT = t;
                    victim = j;
                }
            }
            if (victim >= 0) {
                float hx = b.px + (b.x - b.px) * bestT;
                float hy = b.py + (b.y - b.py) * bestT;
                hitPlayer(b, victim, hx, hy);
                pool.release(b);
            } else if (status == CollisionSystem.HIT_WALL) {
                listener.onWallImpact(b.x, b.y, b.weaponId);
                pool.release(b);
            } else if (status == CollisionSystem.EXPIRED) {
                pool.release(b);
            }
        }
    }

    private void hitPlayer(Projectile b, int victimId, float hx, float hy) {
        Player v = st.players[victimId];
        int dmg = (v.spawnProtect > 0f || st.phase != GameState.PHASE_PLAYING) ? 0 : b.damage;
        listener.onProjectileHit(b.id, victimId, hx, hy, dmg, b.weaponId);
        if (dmg <= 0) return;
        v.health -= dmg;
        v.hitFlash = 0.15f;
        if (v.health <= 0) kill(v, b.owner, b.weaponId);
    }

    private void kill(Player v, int killerId, int weaponId) {
        v.health = 0;
        v.alive = false;
        v.rollTimer = 0f;
        v.deaths++;
        v.respawnTimer = GameConfig.RESPAWN_DELAY;
        Player k = (killerId >= 0 && killerId < st.players.length) ? st.players[killerId] : null;
        boolean credit = k != null && k != v && k.connected;
        if (credit) k.kills++;
        listener.onKill(killerId, v.id, weaponId);
        if (credit && k.kills >= GameConfig.KILL_LIMIT) endMatch();
    }

    private void respawn(Player p) {
        placeAtSpawn(p);
        p.alive = true;
        p.health = GameConfig.PLAYER_MAX_HEALTH;
        p.weapon.equip(WeaponDef.ALL[WeaponDef.PISTOL]);
        p.spawnProtect = GameConfig.SPAWN_PROTECTION;
        p.rollTimer = 0f;
        p.dodgeCooldown = 0f;
        p.handledPulls = p.pulls;
        p.pullBuffer = 0f;
        p.reloadRequest = false;
        listener.onRespawn(p);
    }

    /** Picks the spawn point farthest from every living opponent (with a little randomness). */
    private void placeAtSpawn(Player p) {
        TileMap m = st.map;
        int best = 0;
        float bestScore = -1f;
        for (int i = 0; i < m.spawnX.length; i++) {
            float minD2 = Float.MAX_VALUE;
            for (int j = 0; j < st.players.length; j++) {
                Player q = st.players[j];
                if (q == p || !q.connected || !q.alive) continue;
                float dx = q.x - m.spawnX[i];
                float dy = q.y - m.spawnY[i];
                float d2 = dx * dx + dy * dy;
                if (d2 < minD2) minD2 = d2;
            }
            float dist = minD2 == Float.MAX_VALUE ? 1000f : (float) Math.sqrt(minD2);
            float score = dist + rng.nextFloat() * 40f;
            if (score > bestScore) {
                bestScore = score;
                best = i;
            }
        }
        p.x = m.spawnX[best];
        p.y = m.spawnY[best];
        p.aim = (float) Math.atan2(m.worldH * 0.5f - p.y, m.worldW * 0.5f - p.x);
        p.aimTarget = p.aim;
        p.hasAimInput = false;
        p.rx = p.x;
        p.ry = p.y;
        p.rAim = p.aim;
    }

    /** Pushes overlapping players apart so they cannot walk through each other. */
    private void separatePlayers() {
        float minDist = 2f * GameConfig.PLAYER_RADIUS;
        for (int i = 0; i < st.players.length; i++) {
            Player a = st.players[i];
            if (!a.connected || !a.alive) continue;
            for (int j = i + 1; j < st.players.length; j++) {
                Player b = st.players[j];
                if (!b.connected || !b.alive) continue;
                float dx = b.x - a.x;
                float dy = b.y - a.y;
                float d2 = dx * dx + dy * dy;
                if (d2 >= minDist * minDist) continue;
                float d = (float) Math.sqrt(d2);
                float nx = 1f;
                float ny = 0f;
                if (d > 1e-4f) {
                    nx = dx / d;
                    ny = dy / d;
                }
                float push = (minDist - d) * 0.5f;
                a.x -= nx * push;
                a.y -= ny * push;
                b.x += nx * push;
                b.y += ny * push;
                col.pushOut(a.x, a.y, GameConfig.PLAYER_RADIUS);
                a.x = col.resX;
                a.y = col.resY;
                col.pushOut(b.x, b.y, GameConfig.PLAYER_RADIUS);
                b.x = col.resX;
                b.y = col.resY;
            }
        }
    }

    private void updatePickups(float dt) {
        float reach = GameConfig.PICKUP_RADIUS + GameConfig.PLAYER_RADIUS;
        float reach2 = reach * reach;
        for (int i = 0; i < st.pickups.length; i++) {
            Pickup pk = st.pickups[i];
            if (!pk.active) {
                pk.timer -= dt;
                if (pk.timer <= 0f) pk.active = true;
                continue;
            }
            for (int j = 0; j < st.players.length; j++) {
                Player p = st.players[j];
                if (!p.connected || !p.alive) continue;
                float dx = p.x - pk.x;
                float dy = p.y - pk.y;
                if (dx * dx + dy * dy > reach2) continue;
                Weapon w = p.weapon;
                if (w.def.id == pk.weaponId && w.ammo >= w.def.magSize) continue;
                w.equip(WeaponDef.byId(pk.weaponId));
                pk.active = false;
                pk.timer = GameConfig.PICKUP_RESPAWN;
                listener.onPickup(p, i);
                break;
            }
        }
    }
}
