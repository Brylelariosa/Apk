package com.hazardyard.game.input;

/**
 * Geometry of one on-screen stick. A floating stick puts its base where the thumb lands; a fixed
 * stick keeps its base where the layout puts it. Pure math; drawing lives in the controls renderer.
 */
public final class VirtualJoystick {
    public boolean active;
    /** Centre of the ring (screen pixels). */
    public float baseX, baseY;
    /** Current knob position, clamped to the ring. */
    public float knobX, knobY;
    /** Ring radius in pixels; also the deflection that counts as "fully pushed". */
    public float radius = 100f;
    /** Normalised deflection, each axis in [-1, 1] and overall length at most 1. */
    public float x, y;

    public void begin(float touchX, float touchY) {
        active = true;
        baseX = touchX;
        baseY = touchY;
        update(touchX, touchY);
    }

    /** Starts a stick that stays at its own centre; the knob jumps to where the thumb landed. */
    public void beginFixed(float centerX, float centerY, float touchX, float touchY) {
        active = true;
        baseX = centerX;
        baseY = centerY;
        update(touchX, touchY);
    }

    public void update(float touchX, float touchY) {
        if (!active) return;
        float dx = touchX - baseX;
        float dy = touchY - baseY;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len > radius) {
            float k = radius / len;
            dx *= k;
            dy *= k;
            len = radius;
        }
        knobX = baseX + dx;
        knobY = baseY + dy;
        x = dx / radius;
        y = dy / radius;
    }

    public void end() {
        active = false;
        x = 0f;
        y = 0f;
        knobX = baseX;
        knobY = baseY;
    }

    /** Deflection length in [0, 1]. */
    public float magnitude() {
        return (float) Math.sqrt(x * x + y * y);
    }
}
