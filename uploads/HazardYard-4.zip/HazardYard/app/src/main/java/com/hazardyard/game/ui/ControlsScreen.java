package com.hazardyard.game.ui;

import android.content.Context;
import android.view.View;

/** The control layout editor as a page of its own (opened from Settings). */
final class ControlsScreen implements Screen {
    private final Navigator nav;
    private final ControlsEditorView editor;

    ControlsScreen(Context c, Navigator navigator) {
        nav = navigator;
        editor = new ControlsEditorView(c, navigator.settings(), new ControlsEditorView.Listener() {
            @Override
            public void onClose(boolean saved) {
                if (saved) nav.saveSettings();
                nav.showSettings();
            }
        });
    }

    @Override
    public View view() {
        return editor;
    }

    @Override
    public void onShow() {
        // nothing to start
    }

    @Override
    public void onHide() {
        // nothing to stop
    }

    @Override
    public boolean onBack() {
        return editor.handleBack();
    }

    @Override
    public void onInsets(int l, int t, int r, int b) {
        editor.setInsets(l, t, r, b);
    }
}
