package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;

import com.hazardyard.game.core.GameConfig;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.MathUtil;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.PlayerColors;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.render.model.GunModels;
import com.hazardyard.game.render.model.Projection;
import com.hazardyard.game.render.model.SceneBuffer;
import com.hazardyard.game.render.model.SoldierModel;

/**
 * Draws the soldiers: a lit 3D model whose torso follows the aim while the legs follow the movement
 * (and run backwards when the player backs away), with a walking cycle, gun recoil, hit flash and a
 * shield bubble. A flat version is used when 3D models are switched off. Also draws the health bars
 * and name tags, which go on top of everything.
 */
final class UnitRenderer {
    private static final float RAD_TO_DEG = 57.29578f;
    private static final float STRIDE = MathUtil.TWO_PI / 42f;

    private final PolyDrawer poly;
    private final SceneBuffer scene = new SceneBuffer(320, 2600);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();

    // animation state per player slot
    private final float[] lastX = new float[GameConfig.MAX_PLAYERS];
    private final float[] lastY = new float[GameConfig.MAX_PLAYERS];
    private final float[] legYaw = new float[GameConfig.MAX_PLAYERS];
    private final float[] phase = new float[GameConfig.MAX_PLAYERS];
    private final float[] speed = new float[GameConfig.MAX_PLAYERS];
    private final boolean[] primed = new boolean[GameConfig.MAX_PLAYERS];
    private final boolean[] wasRolling = new boolean[GameConfig.MAX_PLAYERS];
    private final float[] dustClock = new float[GameConfig.MAX_PLAYERS];
    private float lastTime = -1f;

    /** Colour of the dust a roll kicks up. */
    private static final int DUST = 0xFFC9BBA0;
    private static final float TWO_PI = MathUtil.TWO_PI;

    UnitRenderer(PolyDrawer poly) {
        this.poly = poly;
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        label.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        label.setTextAlign(Paint.Align.CENTER);
    }

    /** Advances the walking animation; call once per frame before drawing. */
    void update(GameState st, float time) {
        float dt = lastTime < 0f ? 0f : MathUtil.clamp(time - lastTime, 0f, 0.1f);
        lastTime = time;
        for (int i = 0; i < st.players.length; i++) {
            Player p = st.players[i];
            if (!p.connected || !p.alive) {
                primed[i] = false;
                wasRolling[i] = false;
                continue;
            }
            rollDust(st, p, i, dt);
            if (!primed[i]) {
                primed[i] = true;
                lastX[i] = p.rx;
                lastY[i] = p.ry;
                legYaw[i] = p.rAim;
                speed[i] = 0f;
                phase[i] = 0f;
                continue;
            }
            float dx = p.rx - lastX[i];
            float dy = p.ry - lastY[i];
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            lastX[i] = p.rx;
            lastY[i] = p.ry;
            if (dist > 90f) {              // teleported (respawn)
                legYaw[i] = p.rAim;
                speed[i] = 0f;
                continue;
            }
            float inst = dt > 1e-4f ? dist / dt : 0f;
            speed[i] += (inst - speed[i]) * Math.min(1f, dt * 14f);
            if (speed[i] > 20f && dist > 1e-3f) {
                float moveAngle = (float) Math.atan2(dy, dx);
                boolean backwards = Math.abs(MathUtil.angleDiff(p.rAim, moveAngle)) > MathUtil.PI * 0.5f;
                float target = backwards ? moveAngle + MathUtil.PI : moveAngle;
                legYaw[i] = MathUtil.rotateToward(legYaw[i], target, 16f * dt);
                phase[i] += (backwards ? -dist : dist) * STRIDE;
            } else {
                legYaw[i] = MathUtil.rotateToward(legYaw[i], p.rAim, 9f * dt);
            }
        }
    }

    /** Kicks up dust when a roll starts, along the way and when it ends. */
    private void rollDust(GameState st, Player p, int i, float dt) {
        boolean rolling = p.isRolling();
        if (rolling && !wasRolling[i]) {
            dustClock[i] = 0f;
            for (int k = 0; k < 4; k++) {
                float a = (float) Math.atan2(-p.rollDirY, -p.rollDirX) + (k - 1.5f) * 0.55f;
                st.effects.dust(p.rx + p.rollDirX * -4f, p.ry + p.rollDirY * -4f + 5f, a, 7f + k, DUST, 0.46f);
            }
        } else if (rolling) {
            dustClock[i] += dt;
            if (dustClock[i] >= 0.05f) {
                dustClock[i] = 0f;
                float side = (((int) (p.rollU * 40f)) & 1) == 0 ? 1f : -1f;
                float a = (float) Math.atan2(-p.rollDirY, -p.rollDirX) + side * 0.7f;
                st.effects.dust(p.rx, p.ry + 6f, a, 6f, DUST, 0.36f);
            }
        } else if (wasRolling[i]) {
            for (int k = 0; k < 5; k++) {
                st.effects.dust(p.rx, p.ry + 5f, k * 1.2566f + 0.4f, 6f + (k & 1) * 2f, DUST, 0.42f);
            }
        }
        wasRolling[i] = rolling;
    }

    /** Yaw of the body while rolling: turns from the aim to the roll direction, tumbles, and turns back to the aim. */
    private static float rollYaw(float u, float aim, float rollAngle) {
        float in = MathUtil.clamp(u / 0.16f, 0f, 1f);
        float out = MathUtil.clamp((u - 0.78f) / 0.22f, 0f, 1f);
        float a = MathUtil.lerpAngle(aim, rollAngle, in * in * (3f - 2f * in));
        return MathUtil.lerpAngle(a, aim, out * out * (3f - 2f * out));
    }

    // ------------------------------------------------------------------ the units themselves

    void draw(Canvas c, GameState st, int i, float time, boolean models3d) {
        Player p = st.players[i];
        float x = p.rx;
        float y = p.ry;
        int accent = PlayerColors.of(i);
        boolean shielded = p.spawnProtect > 0f;
        boolean blink = shielded && ((int) (time * 10f) & 1) == 0;

        boolean rolling = p.isRolling();
        float hop = rolling ? ROLL_HOP * (float) Math.sin(Math.PI * p.rollU) : 0f;

        // ground shadow (smaller and fainter while the soldier is in the air)
        float shrink = 1f - hop * 0.045f;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(Palette.withAlpha(0xFF000000, (int) (0x55 * (1f - hop * 0.05f))));
        oval.set(x - 11f * shrink + 3f, y - 6f * shrink + 4f, x + 11f * shrink + 3f, y + 6f * shrink + 4f);
        c.drawOval(oval, fill);
        if (rolling) drawSpeedLines(c, p, x, y);

        if (i == st.localId) {
            line.setColor(0x99FFFFFF);
            line.setStrokeWidth(1.3f);
            oval.set(x - 13.5f, y - 7.5f, x + 13.5f, y + 7.5f);
            c.drawOval(oval, line);
        }

        float flash = p.hitFlash > 0f ? Math.min(1f, p.hitFlash / 0.15f) * 0.85f : 0f;
        if (blink) flash = Math.max(flash, 0.35f);

        if (models3d) draw3d(c, p, i, x, y, accent, flash, hop);
        else drawFlat(c, p, x, y, accent, flash, hop);

        if (shielded) {
            line.setColor(Palette.withAlpha(Palette.SHIELD, blink ? 110 : 210));
            line.setStrokeWidth(1.8f);
            oval.set(x - 17f, y - 9.5f, x + 17f, y + 9.5f);
            c.drawOval(oval, line);
            float top = Projection.screenY(y, SoldierModel.HEIGHT + 3f);
            line.setStrokeWidth(1.2f);
            line.setColor(Palette.withAlpha(Palette.SHIELD, blink ? 70 : 140));
            c.drawArc(oval.left, top - 3f, oval.right, y + 6f, 180f, 180f, false, line);
        }
    }

    /** Highest point of the hop in a roll, in world height units. */
    private static final float ROLL_HOP = 6.5f;

    /** Three thin streaks behind a rolling soldier, longest in the middle, fading with the roll. */
    private void drawSpeedLines(Canvas c, Player p, float x, float y) {
        float fade = (float) Math.sin(Math.PI * p.rollU);
        if (fade <= 0.05f) return;
        float dx = -p.rollDirX;
        float dy = -p.rollDirY;
        float px = -dy;
        float py = dx;
        line.setStrokeWidth(1.5f);
        for (int k = -1; k <= 1; k++) {
            float len = (k == 0 ? 26f : 17f) * fade;
            float off = k * 6.5f;
            float sx = x + px * off + dx * 9f;
            float sy = y - 6f + py * off + dy * 9f;
            line.setColor(Palette.withAlpha(0xFFFFFFFF, (int) (95f * fade)));
            c.drawLine(sx, sy, sx + dx * len, sy + dy * len, line);
        }
    }

    private void draw3d(Canvas c, Player p, int i, float x, float y, int accent, float flash, float hop) {
        float swing = (float) Math.sin(phase[i]);
        float amp = MathUtil.clamp(speed[i] / 110f, 0f, 1f);
        float recoil = MathUtil.clamp(p.muzzleFlash / 0.06f, 0f, 1f);
        float bob = Math.abs(swing) * 0.9f * amp;

        scene.begin();
        if (p.isRolling()) {
            drawRoll3d(c, p, i, x, y, accent, flash, hop);
            return;
        }
        scene.yaw[SoldierModel.G_BODY] = p.rAim;
        scene.yaw[SoldierModel.G_GUN] = p.rAim;
        scene.yaw[SoldierModel.G_LEG_L] = legYaw[i];
        scene.yaw[SoldierModel.G_LEG_R] = legYaw[i];
        scene.offX[SoldierModel.G_LEG_L] = swing * 4.4f * amp;
        scene.offX[SoldierModel.G_LEG_R] = -swing * 4.4f * amp;
        scene.offZ[SoldierModel.G_LEG_L] = Math.max(0f, (float) Math.cos(phase[i])) * 1.5f * amp;
        scene.offZ[SoldierModel.G_LEG_R] = Math.max(0f, -(float) Math.cos(phase[i])) * 1.5f * amp;
        scene.offZ[SoldierModel.G_BODY] = bob;
        scene.offZ[SoldierModel.G_GUN] = bob;
        scene.offX[SoldierModel.G_GUN] = -recoil * 2.4f;
        scene.offX[SoldierModel.G_BODY] = -recoil * 0.6f;

        scene.addMesh(SoldierModel.body(), x, y, 0f, 1f, accent, flash);
        scene.addMesh(GunModels.held(p.weapon.def.id), x, y, 0f, 1f, accent, flash);
        poly.begin(c);
        scene.flush(poly);
    }

    /**
     * The roll: the soldier turns towards the roll direction, tucks the legs and does a full forward
     * somersault with a small hop (the pivot stays near the middle of the body, so it never dips
     * below the floor), then lands facing the aim again. One continuous motion from u = 0 to 1.
     */
    private void drawRoll3d(Canvas c, Player p, int i, float x, float y, int accent, float flash, float hop) {
        float u = p.rollU;
        float rollAngle = (float) Math.atan2(p.rollDirY, p.rollDirX);
        float yaw = rollYaw(u, p.rAim, rollAngle);
        float tuck = (float) Math.sin(Math.PI * u);
        scene.setAllYaw(yaw);
        scene.pitch = TWO_PI * u - (float) Math.sin(TWO_PI * u);   // eases in and out: upright at both ends
        scene.pitchPivotZ = 13f;
        scene.offX[SoldierModel.G_LEG_L] = 2.6f * tuck;
        scene.offX[SoldierModel.G_LEG_R] = 2.6f * tuck;
        scene.offZ[SoldierModel.G_LEG_L] = 3.8f * tuck;
        scene.offZ[SoldierModel.G_LEG_R] = 3.8f * tuck;
        scene.offX[SoldierModel.G_GUN] = -1.6f * tuck;
        scene.offZ[SoldierModel.G_GUN] = -1.2f * tuck;
        scene.addMesh(SoldierModel.body(), x, y, hop, 1f, accent, flash);
        scene.addMesh(GunModels.held(p.weapon.def.id), x, y, hop, 1f, accent, flash);
        poly.begin(c);
        scene.flush(poly);
    }

    private void drawFlat(Canvas c, Player p, float x, float y, int color, float flash, float hop) {
        final float r = GameConfig.PLAYER_RADIUS;
        if (p.isRolling()) {
            // a spinning ball: squashed circle with a turning marker, lifted by the hop
            float spin = TWO_PI * p.rollU * 1.5f;
            float rr = r * (0.82f + 0.18f * (float) Math.abs(Math.cos(spin)));
            float cy = y - hop * Projection.TILT;
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(color);
            c.drawCircle(x, cy, rr, fill);
            line.setColor(Palette.withAlpha(0xFF0B0F14, 200));
            line.setStrokeWidth(2f);
            c.drawCircle(x, cy, rr - 1f, line);
            line.setColor(Palette.withAlpha(0xFFFFFFFF, 220));
            line.setStrokeWidth(2.4f);
            c.drawLine(x, cy, x + (float) Math.cos(spin) * rr * 0.8f, cy + (float) Math.sin(spin) * rr * 0.8f, line);
            if (flash > 0f) {
                fill.setColor(Palette.withAlpha(0xFFFFFFFF, (int) (200f * flash)));
                c.drawCircle(x, cy, rr, fill);
            }
            return;
        }
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(color);
        c.drawCircle(x, y, r, fill);
        line.setColor(Palette.withAlpha(0xFF0B0F14, 200));
        line.setStrokeWidth(2f);
        c.drawCircle(x, y, r - 1f, line);
        WeaponDef def = p.weapon.def;
        c.save();
        c.translate(x, y);
        c.rotate(p.rAim * RAD_TO_DEG);
        fill.setColor(0xFF20252D);
        c.drawRect(r * 0.35f, -def.barrelWidth * 0.5f, r + def.barrelLength, def.barrelWidth * 0.5f, fill);
        fill.setColor(Palette.withAlpha(0xFFFFFFFF, 215));
        c.drawCircle(r * 0.42f, 0f, r * 0.46f, fill);
        c.restore();
        if (flash > 0f) {
            fill.setColor(Palette.withAlpha(0xFFFFFFFF, (int) (200f * flash)));
            c.drawCircle(x, y, r, fill);
        }
    }

    // ------------------------------------------------------------------ health bars and names

    void drawTag(Canvas c, GameState st, int i, boolean models3d) {
        Player p = st.players[i];
        float height = models3d ? SoldierModel.HEIGHT : 8f;
        float x = Projection.screenX(p.rx, height);
        float y = Projection.screenY(p.ry, height) - 8f;
        float frac = MathUtil.clamp(p.health / (float) GameConfig.PLAYER_MAX_HEALTH, 0f, 1f);
        float bw = 26f;
        fill.setStyle(Paint.Style.FILL);
        fill.setColor(0xAA0B0F14);
        c.drawRect(x - bw * 0.5f - 1f, y - 1f, x + bw * 0.5f + 1f, y + 4.5f, fill);
        fill.setColor(frac > 0.5f ? Palette.GOOD : (frac > 0.25f ? Palette.WARN : Palette.BAD));
        c.drawRect(x - bw * 0.5f, y, x - bw * 0.5f + bw * frac, y + 3.5f, fill);
        if (i != st.localId) {
            label.setTextSize(8.5f);
            label.setColor(0xCC0B0F14);
            c.drawText(p.name, x + 0.6f, y - 2.4f, label);
            label.setColor(PlayerColors.of(i));
            c.drawText(p.name, x, y - 3f, label);
        }
    }
}
