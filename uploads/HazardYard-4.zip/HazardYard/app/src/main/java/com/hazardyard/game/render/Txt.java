package com.hazardyard.game.render;

/** Cached number-to-string conversion so HUD text never allocates while playing. */
public final class Txt {
    private Txt() {}

    private static final String[] SMALL = new String[1000];

    public static String of(int v) {
        if (v < 0 || v >= SMALL.length) return Integer.toString(v);
        String s = SMALL[v];
        if (s == null) {
            s = Integer.toString(v);
            SMALL[v] = s;
        }
        return s;
    }
}
