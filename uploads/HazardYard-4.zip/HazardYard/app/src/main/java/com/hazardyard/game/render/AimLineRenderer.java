package com.hazardyard.game.render;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;

import com.hazardyard.game.core.CollisionSystem;
import com.hazardyard.game.core.GameState;
import com.hazardyard.game.core.Player;
import com.hazardyard.game.core.WeaponDef;
import com.hazardyard.game.render.model.Projection;

/**
 * The local player's aim line: a dashed line from the muzzle along the aim, as long as the gun's
 * range and cut short by the first wall, with a marker where it ends (a ring on a wall, a cross-bar
 * at the end of the gun's reach). A gun with a wide spread also shows the edges of its cone. The
 * line is in the colour of the gun and is drawn at the height the bullets fly at, so it lines up
 * with the shots. It is only ever drawn for the local player, so it gives nothing away about the
 * others. Allocation-free.
 */
final class AimLineRenderer {
    /** Height of the barrel: bullets (and so this line) fly at it. */
    private static final float Z = 14.7f;
    private static final float DASH = 8f;
    private static final float GAP = 7f;
    private static final float PERIOD = DASH + GAP;
    /** The line fades with distance in this many steps. */
    private static final int BANDS = 4;
    /** From this spread (radians, half-angle) on, a gun also shows its cone. */
    private static final float CONE_MIN = 0.04f;

    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    AimLineRenderer() {
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
    }

    /**
     * @param scale    screen pixels per world unit (strokes keep the same width on screen at any zoom)
     * @param strength 0..1 fade of the whole line
     * @param firing   the trigger is down and the gun can shoot: the line is drawn brighter and thicker
     * @param lite     simple graphics: no dark underlay and no spread cone
     */
    void draw(Canvas c, GameState st, Player me, float scale, float strength, boolean firing, boolean lite, float time) {
        if (strength <= 0.01f || !me.connected || !me.alive) return;
        WeaponDef def = me.weapon.def;
        CollisionSystem col = st.collision;
        float ang = me.rAim;
        float ca = (float) Math.cos(ang);
        float sa = (float) Math.sin(ang);

        // Start where the bullets start: at the muzzle, or at the wall face when a wall is in between.
        float sx = def.muzzleX(me.rx, ang);
        float sy = def.muzzleY(me.ry, ang);
        float cut = col.raycast(me.rx, me.ry, sx, sy);
        if (cut >= 0f) {
            float k = Math.max(0f, cut - 0.02f);
            sx = me.rx + (sx - me.rx) * k;
            sy = me.ry + (sy - me.ry) * k;
        }
        float len = reach(col, sx, sy, ca, sa, def.range);

        final float ox = Projection.LEAN * Z;
        final float oy = -Projection.TILT * Z;
        final float px = 1f / scale;                       // one screen pixel in world units
        final float alpha = strength * (firing ? 1f : 0.8f);
        final int color = def.color;

        // The edges of the spread cone, for guns that scatter their shots.
        if (!lite && def.spread >= CONE_MIN) {
            line.setStrokeWidth(1.3f * px);
            line.setColor(Palette.withAlpha(color, (int) (95f * alpha)));
            for (int side = -1; side <= 1; side += 2) {
                float a = ang + side * def.spread;
                float cx = (float) Math.cos(a);
                float cy = (float) Math.sin(a);
                float l = reach(col, sx, sy, cx, cy, def.range);
                c.drawLine(sx + ox, sy + oy, sx + cx * l + ox, sy + cy * l + oy, line);
            }
        }

        // The dashes creep away from the gun; each band further out is a little fainter.
        float phase = (time * 26f) % PERIOD;
        for (int band = 0; band < BANDS; band++) {
            float f0 = len * band / BANDS;
            float f1 = len * (band + 1) / BANDS;
            path.rewind();
            boolean any = false;
            for (int k = (int) Math.floor((f0 - phase) / PERIOD); ; k++) {
                float a = k * PERIOD + phase;
                if (a >= f1) break;
                float b = a + DASH;
                if (a < f0) a = f0;
                if (b > f1) b = f1;
                if (b - a < 0.5f) continue;
                path.moveTo(sx + ca * a + ox, sy + sa * a + oy);
                path.lineTo(sx + ca * b + ox, sy + sa * b + oy);
                any = true;
            }
            if (!any) continue;
            float fade = 1f - 0.6f * (band + 0.5f) / BANDS;
            if (!lite) {
                line.setStrokeWidth((firing ? 4.6f : 3.6f) * px);
                line.setColor(Palette.withAlpha(0xFF000000, (int) (70f * alpha * fade)));
                c.drawPath(path, line);
            }
            line.setStrokeWidth((firing ? 2.6f : 1.9f) * px);
            line.setColor(Palette.withAlpha(color, (int) (235f * alpha * fade)));
            c.drawPath(path, line);
        }

        // The end of the line.
        float ex = sx + ca * len + ox;
        float ey = sy + sa * len + oy;
        float r = 4.2f * px;
        if (len < def.range - 0.5f) {
            // a wall stops the bullets here
            fill.setColor(Palette.withAlpha(color, (int) (200f * alpha)));
            c.drawCircle(ex, ey, r * 0.55f, fill);
            line.setStrokeWidth(1.6f * px);
            line.setColor(Palette.withAlpha(color, (int) (170f * alpha)));
            c.drawCircle(ex, ey, r, line);
        } else {
            // the bullets run out of range here
            line.setStrokeWidth(2.2f * px);
            line.setColor(Palette.withAlpha(color, (int) (150f * alpha)));
            c.drawLine(ex + sa * r, ey - ca * r, ex - sa * r, ey + ca * r, line);
        }
    }

    /** How far a bullet leaving (x, y) along (dx, dy) gets: the gun's range, or less when a wall is in the way. */
    private static float reach(CollisionSystem col, float x, float y, float dx, float dy, float range) {
        float hit = col.raycast(x, y, x + dx * range, y + dy * range);
        return hit >= 0f ? range * hit : range;
    }
}
