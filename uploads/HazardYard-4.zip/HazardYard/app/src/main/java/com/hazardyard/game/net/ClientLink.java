package com.hazardyard.game.net;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.net.Socket;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Host-side connection to one client: a reader thread parses frames, a writer thread drains a queue.
 * Writing never happens on the game thread, so a stalled Wi-Fi client cannot freeze the host.
 */
final class ClientLink {
    private static final byte[] POISON = new byte[0];
    private static final int MAX_QUEUE = 600;
    private static final int DROP_SNAPSHOTS_ABOVE = 24;
    private static final int HANDSHAKE_TIMEOUT_MS = 4000;
    static final int ACTIVE_TIMEOUT_MS = 6000;

    private final HostManager host;
    private final Socket socket;
    private final DataInputStream in;
    private final BufferedOutputStream out;
    private final LinkedBlockingQueue<byte[]> queue = new LinkedBlockingQueue<>();
    private volatile boolean closed;
    /** Slot in the lobby / match, -1 until the HELLO handshake succeeded. */
    volatile int playerId = -1;

    ClientLink(HostManager host, Socket socket) throws IOException {
        this.host = host;
        this.socket = socket;
        socket.setTcpNoDelay(true);
        socket.setKeepAlive(true);
        socket.setSoTimeout(HANDSHAKE_TIMEOUT_MS);
        in = new DataInputStream(new BufferedInputStream(socket.getInputStream(), 2048));
        out = new BufferedOutputStream(socket.getOutputStream(), 4096);
    }

    void start() {
        Thread reader = new Thread(this::readLoop, "hy-host-read");
        Thread writer = new Thread(this::writeLoop, "hy-host-write");
        reader.setDaemon(true);
        writer.setDaemon(true);
        reader.start();
        writer.start();
    }

    void setActiveTimeout() {
        try {
            socket.setSoTimeout(ACTIVE_TIMEOUT_MS);
        } catch (IOException ignored) {
            // socket already dead; the reader will notice
        }
    }

    /** Queues a frame that must arrive. A client that falls hopelessly behind is dropped. */
    void send(byte[] frame) {
        if (closed) return;
        if (queue.size() >= MAX_QUEUE) {
            close();
            return;
        }
        queue.offer(frame);
    }

    /** Queues a frame that may be skipped when the client is lagging (snapshots). */
    void sendDroppable(byte[] frame) {
        if (closed || queue.size() > DROP_SNAPSHOTS_ABOVE) return;
        queue.offer(frame);
    }

    /** Queues a final frame and closes the connection once it has been written. */
    void sendAndClose(byte[] frame) {
        if (closed) return;
        queue.offer(frame);
        queue.offer(POISON);
    }

    private void readLoop() {
        try {
            while (!closed) {
                byte[] data = Protocol.readFrame(in);
                host.onFrame(this, data);
            }
        } catch (IOException | RuntimeException ignored) {
            // disconnect, timeout or malformed data: all end the same way
        } finally {
            close();
        }
    }

    private void writeLoop() {
        try {
            while (!closed) {
                byte[] f = queue.take();
                if (f == POISON) break;
                out.write(f);
                if (queue.isEmpty()) out.flush();
            }
            out.flush();
        } catch (IOException | InterruptedException ignored) {
            // fall through to close
        } finally {
            close();
        }
    }

    void close() {
        if (closed) return;
        closed = true;
        queue.offer(POISON);
        try {
            socket.close();
        } catch (IOException ignored) {
            // nothing more to do
        }
        host.onLinkClosed(this);
    }
}
