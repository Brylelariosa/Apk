# Hazard Yard

Top-down arena shooter for Android (pure framework code, no dependencies). Play solo against bots, or
2-4 players on the same Wi-Fi.

## Features
- **Solo mode**: 1-3 computer opponents (Easy / Normal / Hard) on any of the eight arenas.
- **Arenas**: Hazard Yard (smallest), Dockside Warehouse, Toxic Foundry, Ruined Outpost, Bunker Complex, and the
  newer Rotunda Plaza (wide open), Silo Yard and Diamond Hall. Besides square walls and crates they use round
  pillars and tanks and angled corner pieces. The host picks the arena in the lobby. Fences are thin lines
  you can stand right next to; fences and toxic pools block movement but not bullets.
- **Eight guns**: pistol, assault rifle, shotgun, SMG, sniper rifle, magnum, plasma rifle, light MG.
  Pushing the aim stick all the way out fires every gun at its own rate, reloads included; bullets leave from the barrel.
  Each gun has its own camera zoom (`WeaponDef.zoom`): the sniper rifle pulls the view back to show its long range, the
  shotgun moves in close, and the view eases from one to the other when you pick up a different gun.
  Every gun has its own sound, synthesised in code (`audio/SoundBank`), no audio files; hits and the plasma
  rifle are electric zaps.
- **Aim line**: while you aim, a dashed line in the gun's colour runs from the muzzle as far as the gun reaches and stops at
  the first wall; guns that scatter their shots also show the edges of their spread. Only your own line is drawn, so it
  tells nothing about the other players. Can be switched off in Settings.
- **Dodge roll**: a button next to the aim stick. A short invulnerable somersault in the move direction
  (or the way you face), about 1.3 s cooldown. Bots roll too.
- **Heard shots only**: other players are not tracked on the minimap or by edge arrows; one shows up only
  where and while its gun was just heard firing.
- **3D look**: lit low-poly soldiers and guns, extruded walls and crates (`render/model`). Can be switched
  off in Settings for slow phones; Graphics quality "Auto" (default) lowers effects by itself when a phone
  cannot hold a steady frame rate (`render/QualityGovernor`). Frames follow the display's vsync and are
  interpolated, so 60, 90 and 120 Hz screens all look smooth.
- **Fullscreen** into the camera cutout; the HUD and controls keep to the safe area.
- **Custom controls** (Settings > Edit controls layout, or Pause > Controls): move and resize every control,
  fixed or floating sticks, fire mode (stick fires / button fires / both), aim dead zone, opacity. The aim stick aims once it
  is past its dead zone and only fires once it is pushed out to the "Stick fires at" level (default 100% = all
  the way out, adjustable down to 30%); with "Button fires" the stick never fires and the fire button does the shooting. The same two options
  are also on the Settings page.

## Layout of the code (`app/src/main/java/com/hazardyard/game`)
| Package    | What lives there |
|------------|------------------|
| `core`     | Match rules, players, weapons, tile maps (`MapLibrary`), collision. No Android types. |
| `bot`      | Bot AI: `BotBrain`, A* `PathFinder`, `NavGrid`, `BotDifficulty`. |
| `engine`   | `GameEngine` implementations: `HostEngine`, `ClientEngine`, `SoloEngine`; `Presentation` turns events into effects and sounds. |
| `net`      | LAN discovery, lobby and match protocol (bump `Protocol.VERSION` when the wire format changes). |
| `input`    | `InputController` (touch routing), `ControlGeometry` (pixel layout), `VirtualJoystick`. No Android types. |
| `settings` | `ControlSettings` / `GameSettings` and their SharedPreferences store. |
| `render`   | Canvas renderers: floor, blocks, units, pickups, shots, HUD, controls. `render/model` is the pure-Java 3D mesh pipeline. |
| `audio`    | `Synth` + `SoundBank` (sound design), `Mixer` (software mixing), `SoundEngine` (AudioTrack output). |
| `ui`       | Screens, the control layout editor and the Android views. |

## Adding things
- **A map**: add its rows to `MapLibrary` (legend in the comment there), a theme in `render/MapTheme`, and bump `MapLibrary.COUNT`.
  Keep it to 16 weapon pickups at most (the snapshot carries a 16-bit pickup mask).
- **A gun**: add a `WeaponDef`, a model in `render/model/GunModels`, a sound recipe in `audio/SoundBank`
  (the shot sound id equals the weapon id), and a map letter in `TileMap.weaponForLetter` if it should lie on a map.
