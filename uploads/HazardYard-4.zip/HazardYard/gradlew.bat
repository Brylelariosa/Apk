@rem Gradle start script for Windows (HazardYard). See the `gradlew` script for details.
@if "%DEBUG%"=="" @echo off
setlocal
set "DIRNAME=%~dp0"

if exist "%DIRNAME%gradle\wrapper\gradle-wrapper.jar" (
    java -Dorg.gradle.appname=gradlew -classpath "%DIRNAME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
    exit /b %ERRORLEVEL%
)

where gradle >NUL 2>NUL
if %ERRORLEVEL%==0 (
    gradle %*
    exit /b %ERRORLEVEL%
)

echo ERROR: gradle-wrapper.jar is missing and no 'gradle' command was found on PATH.
echo Install Gradle 8.6, or open this folder in Android Studio.
exit /b 1
