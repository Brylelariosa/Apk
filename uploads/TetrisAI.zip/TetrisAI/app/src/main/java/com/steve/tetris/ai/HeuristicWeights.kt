package com.steve.tetris.ai

/**
 * Weights for the board-evaluation function the AI uses to score a potential
 * placement. The defaults deliberately represent a NAIVE strategy - "just
 * don't stack too high" - with no sense of avoiding holes, keeping the
 * surface flat, or clearing lines. That's intentional: this is what the AI
 * uses before any training, so there's an honest, visible gap between
 * "untrained" and what the genetic trainer evolves it into.
 */
data class HeuristicWeights(
    val aggregateHeight: Double = -1.0,
    val completeLines: Double = 0.0,
    val holes: Double = 0.0,
    val bumpiness: Double = 0.0
) {
    fun asArray(): DoubleArray = doubleArrayOf(aggregateHeight, completeLines, holes, bumpiness)

    companion object {
        fun fromArray(values: DoubleArray) = HeuristicWeights(values[0], values[1], values[2], values[3])
    }
}
