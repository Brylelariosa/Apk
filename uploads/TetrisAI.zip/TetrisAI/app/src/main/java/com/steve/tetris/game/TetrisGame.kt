package com.steve.tetris.game

import kotlin.random.Random

const val BOARD_ROWS = 20
const val BOARD_COLS = 10

data class ActivePiece(
    val type: PieceType,
    val rotation: Int = 0,
    val row: Int = -1,
    val col: Int = 3
) {
    fun cells(): List<Pair<Int, Int>> =
        Tetromino.cellsFor(type, rotation).map { (r, c) -> (r + row) to (c + col) }
}

/**
 * Self-contained Tetris engine. Deliberately framework-free (no Compose/Android
 * imports) so it can be driven both by the UI (real-time play / AI playback)
 * and headlessly at high speed by the genetic algorithm trainer.
 */
class TetrisGame(private val random: Random = Random.Default) {

    var board: Array<IntArray> = Array(BOARD_ROWS) { IntArray(BOARD_COLS) }
        private set

    lateinit var current: ActivePiece
        private set
    lateinit var next: PieceType
        private set

    var score = 0
        private set
    var linesCleared = 0
        private set
    var level = 1
        private set
    var isGameOver = false
        private set

    init {
        next = randomType()
        current = spawnFromBag()
    }

    private fun randomType(): PieceType = PieceType.entries[random.nextInt(PieceType.entries.size)]

    private fun spawnFromBag(): ActivePiece {
        val type = next
        next = randomType()
        return ActivePiece(type = type, rotation = 0, row = -1, col = 3)
    }

    fun isValid(piece: ActivePiece): Boolean = piece.cells().all { (r, c) ->
        c in 0 until BOARD_COLS && r < BOARD_ROWS && (r < 0 || board[r][c] == 0)
    }

    /** True if the current piece can still fall one more row (i.e. won't lock yet). */
    fun canMoveDown(): Boolean = isValid(current.copy(row = current.row + 1))

    /** Where the current piece would land if hard-dropped right now, without mutating state. */
    fun hardDropTarget(): ActivePiece {
        var moved = current
        while (isValid(moved.copy(row = moved.row + 1))) {
            moved = moved.copy(row = moved.row + 1)
        }
        return moved
    }

    fun moveLeft() = tryMove(current.copy(col = current.col - 1))
    fun moveRight() = tryMove(current.copy(col = current.col + 1))

    fun softDrop(): Boolean {
        if (isGameOver) return false
        val moved = current.copy(row = current.row + 1)
        return if (isValid(moved)) {
            current = moved
            true
        } else {
            lockPiece()
            false
        }
    }

    fun hardDrop() {
        if (isGameOver) return
        var moved = current
        while (isValid(moved.copy(row = moved.row + 1))) {
            moved = moved.copy(row = moved.row + 1)
        }
        current = moved
        lockPiece()
    }

    fun rotate() {
        if (isGameOver) return
        val rotated = current.copy(rotation = current.rotation + 1)
        if (isValid(rotated)) {
            current = rotated
            return
        }
        for (offset in intArrayOf(-1, 1, -2, 2)) {
            val kicked = rotated.copy(col = rotated.col + offset)
            if (isValid(kicked)) {
                current = kicked
                return
            }
        }
    }

    private fun tryMove(moved: ActivePiece) {
        if (!isGameOver && isValid(moved)) current = moved
    }

    private fun lockPiece() {
        for ((r, c) in current.cells()) {
            if (r < 0) {
                isGameOver = true
                return
            }
            board[r][c] = Tetromino.colorIndex.getValue(current.type)
        }
        clearLines()
        current = spawnFromBag()
        if (!isValid(current)) {
            isGameOver = true
        }
    }

    private fun clearLines() {
        val remaining = board.filter { row -> row.any { it == 0 } }
        val cleared = BOARD_ROWS - remaining.size
        if (cleared > 0) {
            val newRows = List(cleared) { IntArray(BOARD_COLS) }
            board = (newRows + remaining).toTypedArray()
            linesCleared += cleared
            score += when (cleared) {
                1 -> 40 * level
                2 -> 100 * level
                3 -> 300 * level
                else -> 1200 * level
            }
            level = 1 + linesCleared / 10
        }
    }

    fun copyBoard(): Array<IntArray> = Array(BOARD_ROWS) { r -> board[r].copyOf() }
}
