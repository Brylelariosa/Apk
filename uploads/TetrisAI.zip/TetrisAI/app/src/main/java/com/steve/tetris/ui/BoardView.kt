package com.steve.tetris.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.steve.tetris.game.ActivePiece
import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.game.BOARD_ROWS
import com.steve.tetris.game.Tetromino

@Composable
fun BoardView(
    board: Array<IntArray>,
    current: ActivePiece?,
    modifier: Modifier = Modifier,
    flashingRows: List<Int> = emptyList()
) {
    Canvas(
        // matchHeightConstraintsFirst: size from the AVAILABLE HEIGHT, not full
        // width - keeps the board (and controls below it) on screen on any phone.
        modifier = modifier.aspectRatio(BOARD_COLS / BOARD_ROWS.toFloat(), matchHeightConstraintsFirst = true)
    ) {
        val cellW = size.width / BOARD_COLS
        val cellH = size.height / BOARD_ROWS

        drawRect(color = boardBackground, size = size)

        // Grid lines are drawn UNDER the pieces. Drawing them on top (as
        // before) sliced every multi-cell piece into visibly separate little
        // squares instead of one solid shape - most obvious on the O piece,
        // which should read as one clean square, not four.
        for (c in 0..BOARD_COLS) {
            drawLine(
                color = Color(0x1FFFFFFF),
                start = Offset(c * cellW, 0f),
                end = Offset(c * cellW, size.height)
            )
        }
        for (r in 0..BOARD_ROWS) {
            drawLine(
                color = Color(0x1FFFFFFF),
                start = Offset(0f, r * cellH),
                end = Offset(size.width, r * cellH)
            )
        }

        for (r in 0 until BOARD_ROWS) {
            for (c in 0 until BOARD_COLS) {
                val value = board[r][c]
                if (value != 0) drawCell(r, c, cellW, cellH, pieceColors[value])
            }
        }

        current?.let { piece ->
            val color = pieceColors[Tetromino.colorIndex.getValue(piece.type)]
            piece.cells().forEach { (r, c) ->
                if (r in 0 until BOARD_ROWS && c in 0 until BOARD_COLS) {
                    drawCell(r, c, cellW, cellH, color)
                }
            }
        }

        flashingRows.forEach { r ->
            if (r in 0 until BOARD_ROWS) {
                drawRect(
                    color = Color.White,
                    topLeft = Offset(0f, r * cellH),
                    size = Size(size.width, cellH)
                )
            }
        }
    }
}

// Cells are drawn edge-to-edge (no shrink gap) so adjacent same-piece cells
// tile into one seamless shape rather than a checkerboard of tiny squares.
private fun DrawScope.drawCell(r: Int, c: Int, cellW: Float, cellH: Float, color: Color) {
    drawRect(
        color = color,
        topLeft = Offset(c * cellW, r * cellH),
        size = Size(cellW, cellH)
    )
}
