package com.steve.tetris.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.steve.tetris.ai.GenerationResult
import com.steve.tetris.ai.GeneticTrainer
import com.steve.tetris.ai.HeuristicWeights
import com.steve.tetris.storage.WeightsStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun TrainScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val results = remember { mutableStateListOf<GenerationResult>() }
    var isTraining by remember { mutableStateOf(false) }
    var totalGenerations by remember { mutableStateOf(20) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onBack) { Text("‹ Back") }
            Text("Train AI", style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(12.dp))
        Text("Generations: $totalGenerations")
        Slider(
            value = totalGenerations.toFloat(),
            onValueChange = { totalGenerations = it.toInt().coerceIn(5, 60) },
            valueRange = 5f..60f,
            enabled = !isTraining
        )
        Spacer(Modifier.height(8.dp))
        Button(
            enabled = !isTraining,
            onClick = {
                results.clear()
                isTraining = true
                scope.launch {
                    val trainer = GeneticTrainer()
                    var lastBestWeights = HeuristicWeights()
                    for (gen in 1..totalGenerations) {
                        val result = withContext(Dispatchers.Default) { trainer.runGeneration(gen) }
                        results.add(result)
                        lastBestWeights = result.bestWeights
                    }
                    withContext(Dispatchers.Default) {
                        WeightsStorage.save(context, lastBestWeights)
                    }
                    isTraining = false
                }
            }
        ) {
            Text(if (isTraining) "Training… (${results.size}/$totalGenerations)" else "Start Training")
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Each generation, 12 candidate strategies play a couple of games each. " +
                "The best ones breed the next generation. The fittest weights are saved " +
                "automatically and used in Watch AI Play.",
            style = MaterialTheme.typography.bodySmall
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(results.reversed()) { r ->
                Text("Gen ${r.generation}: best=${"%.1f".format(r.bestFitness)}  avg=${"%.1f".format(r.averageFitness)}")
            }
        }
    }
}
