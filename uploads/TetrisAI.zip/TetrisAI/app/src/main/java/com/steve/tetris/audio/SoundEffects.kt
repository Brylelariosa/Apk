package com.steve.tetris.audio

import android.media.AudioManager
import android.media.ToneGenerator

/**
 * All sound effects are synthesized tones (no bundled audio files). Cheap,
 * tiny APK footprint, and works everywhere without asset management.
 */
class SoundEffects {
    private val toneGen: ToneGenerator? = try {
        ToneGenerator(AudioManager.STREAM_MUSIC, 70)
    } catch (e: RuntimeException) {
        null // some emulators/devices without an audio output can fail here
    }

    fun rotate() = play(ToneGenerator.TONE_PROP_ACK, 25)
    fun lock() = play(ToneGenerator.TONE_PROP_BEEP, 35)
    fun lineClear() = play(ToneGenerator.TONE_PROP_BEEP2, 180)
    fun gameOver() = play(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 400)

    private fun play(tone: Int, durationMs: Int) {
        toneGen?.startTone(tone, durationMs)
    }

    fun release() {
        toneGen?.release()
    }
}
