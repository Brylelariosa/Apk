package com.steve.tetris.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

/**
 * All sound effects are synthesized sine-wave tones - no bundled audio files.
 *
 * The first version used ToneGenerator (phone dial/call-progress tones),
 * which sounds like a phone, not a game, and its "beep" vs "beep2" tones
 * were nearly indistinguishable. This generates actual short PCM waveforms
 * with a fade envelope (avoids clicks/pops) at chosen musical pitches, so
 * effects are clean and clearly distinct from each other.
 */
class SoundEffects {
    private val sampleRate = 44100
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    fun rotate() = playTone(700.0, 22, volume = 0.18f)

    fun lock() = playTone(140.0, 45, volume = 0.22f)

    fun gameOver() = playSequence(listOf(392.0, 330.0, 262.0, 196.0), 150, volume = 0.22f)

    /** [combo] is the resulting combo count (1 = first clear, 2 = second in a row, ...). */
    fun lineClear(combo: Int) {
        // C5 E5 G5 C6 E6 - a clean ascending major arpeggio; longer combos add notes.
        val notes = listOf(523.25, 659.25, 783.99, 1046.50, 1318.51)
        val noteCount = (1 + combo).coerceIn(2, notes.size)
        playSequence(notes.take(noteCount), 85, volume = 0.22f)
    }

    private fun playTone(freqHz: Double, durationMs: Int, volume: Float) {
        scope.launch {
            playOne(freqHz, durationMs, volume)
        }
    }

    private fun playSequence(freqsHz: List<Double>, noteDurationMs: Int, volume: Float) {
        scope.launch {
            for (f in freqsHz) {
                playOne(f, noteDurationMs, volume)
                delay((noteDurationMs * 0.75).toLong())
            }
        }
    }

    private suspend fun playOne(freqHz: Double, durationMs: Int, volume: Float) {
        try {
            val track = buildTone(freqHz, durationMs, volume)
            track.play()
            delay(durationMs.toLong() + 30L)
            track.release()
        } catch (e: Exception) {
            // Some devices/emulators have no usable audio output - fail silently.
        }
    }

    private fun buildTone(freqHz: Double, durationMs: Int, volume: Float): AudioTrack {
        val sampleCount = (sampleRate * durationMs / 1000.0).toInt().coerceAtLeast(1)
        val samples = ShortArray(sampleCount)
        val fadeCount = (sampleCount * 0.12).toInt().coerceAtLeast(1)
        for (i in 0 until sampleCount) {
            val angle = 2.0 * PI * i * freqHz / sampleRate
            val fadeIn = (i.toDouble() / fadeCount).coerceIn(0.0, 1.0)
            val fadeOut = ((sampleCount - i).toDouble() / fadeCount).coerceIn(0.0, 1.0)
            val envelope = minOf(fadeIn, fadeOut, 1.0)
            samples[i] = (sin(angle) * envelope * volume * Short.MAX_VALUE).toInt().toShort()
        }
        val bytesNeeded = sampleCount * 2
        val minBuffer = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val bufferSize = maxOf(bytesNeeded, minBuffer)

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track.write(samples, 0, samples.size)
        return track
    }

    fun release() {
        scope.cancel()
    }
}
