package com.melodiq.util

import android.content.Context
import android.net.Uri
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance

fun Color.isLight(): Boolean = luminance() > 0.5f

fun Long.msToSec(): Int = (this / 1000).toInt()

fun String.toSafeUri(): Uri? = try { Uri.parse(this) } catch (e: Exception) { null }

fun Context.hasAudioPermission(): Boolean {
    val perm = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU)
        android.Manifest.permission.READ_MEDIA_AUDIO
    else
        android.Manifest.permission.READ_EXTERNAL_STORAGE
    return checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED
}

/**
 * Runtime permissions SpotibaiNiJan asks for. READ_MEDIA_AUDIO / READ_EXTERNAL_STORAGE is what
 * actually lets it see your songs; POST_NOTIFICATIONS (Android 13+) only shows the
 * playback notification.
 */
fun requiredRuntimePermissions(): Array<String> =
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU)
        arrayOf(
            android.Manifest.permission.READ_MEDIA_AUDIO,
            android.Manifest.permission.POST_NOTIFICATIONS
        )
    else
        arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
