# Add project specific ProGuard rules here.
# Not used while minifyEnabled is false.
