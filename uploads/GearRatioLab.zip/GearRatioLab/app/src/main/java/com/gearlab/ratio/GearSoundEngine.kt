package com.gearlab.ratio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sin

class GearSoundEngine {

    private val sampleRate = 44100

    @Volatile private var running = false
    @Volatile private var muted = false
    private var thread: Thread? = null

    // Stage-1 input (drives the mesh-click rate) and the drivetrain's final
    // output speed (drives the second hum tone) — set from MainActivity.
    @Volatile var driverTeeth: Int = 12
    @Volatile var inputRpm: Float = 30f
    @Volatile var finalOutputRpm: Float = 15f

    fun start() {
        if (running) return
        running = true
        val t = Thread { playLoop() }
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        thread = null
    }

    fun setMuted(value: Boolean) {
        muted = value
    }

    private fun triangleWave(phase: Double): Double {
        val twoPi = 2.0 * PI
        var p = phase % twoPi
        if (p < 0.0) p += twoPi
        val t = p / twoPi
        return 4.0 * abs(t - 0.5) - 1.0
    }

    private fun playLoop() {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufSize = if (minBuf > 0) minBuf * 2 else sampleRate

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        track.play()

        var phaseHum1 = 0.0
        var phaseHum2 = 0.0
        var clickPhase = 0.0
        var clickEnvelope = 0.0
        var clickTonePhase = 0.0

        // One-pole lowpass to take the edge off, ~2.8kHz cutoff.
        val cutoffHz = 2800.0
        val rc = 1.0 / (2.0 * PI * cutoffHz)
        val dt = 1.0 / sampleRate
        val lpAlpha = dt / (rc + dt)
        var lpState = 0.0

        // Click decays over roughly 12ms — a short mechanical "tick", not a tone.
        val clickTau = 0.012
        val clickDecay = exp(-1.0 / (clickTau * sampleRate))

        val chunk = 1024
        val buffer = ShortArray(chunk)

        try {
            while (running) {
                val f1 = 55.0 + abs(inputRpm.toDouble()) * 1.6
                val f2 = 55.0 + abs(finalOutputRpm.toDouble()) * 1.6
                var meshFreq = abs(inputRpm.toDouble() / 60.0 * driverTeeth.toDouble())
                if (meshFreq < 0.4) meshFreq = 0.4
                if (meshFreq > 45.0) meshFreq = 45.0

                val clickPhaseInc = 2.0 * PI * meshFreq / sampleRate
                val twoPi = 2.0 * PI

                var i = 0
                while (i < chunk) {
                    phaseHum1 += 2.0 * PI * f1 / sampleRate
                    phaseHum2 += 2.0 * PI * f2 / sampleRate
                    clickTonePhase += 2.0 * PI * 720.0 / sampleRate

                    val hum1 = triangleWave(phaseHum1) * 0.09
                    val hum2 = triangleWave(phaseHum2) * 0.09

                    clickPhase += clickPhaseInc
                    if (clickPhase >= twoPi) {
                        clickPhase -= twoPi
                        clickEnvelope = 1.0
                    } else {
                        clickEnvelope *= clickDecay
                    }
                    val click = sin(clickTonePhase) * clickEnvelope * 0.16

                    var sample = hum1 + hum2 + click
                    if (muted) sample = 0.0

                    lpState += lpAlpha * (sample - lpState)
                    var out = lpState
                    if (out > 1.0) out = 1.0
                    if (out < -1.0) out = -1.0

                    buffer[i] = (out * Short.MAX_VALUE.toDouble()).toInt().toShort()
                    i++
                }
                track.write(buffer, 0, chunk)
            }
        } finally {
            track.stop()
            track.release()
        }
    }
}
