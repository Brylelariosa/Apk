package com.gearlab.ratio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

class GearSoundEngine {

    private val sampleRate = 44100

    @Volatile private var running = false
    @Volatile private var muted = false
    private var thread: Thread? = null

    @Volatile var driverTeeth: Int = 12
    @Volatile var drivenTeeth: Int = 24
    @Volatile var inputRpm: Float = 30f

    fun start() {
        if (running) return
        running = true
        val t = Thread { playLoop() }
        t.isDaemon = true
        thread = t
        t.start()
    }

    fun stop() {
        running = false
        thread = null
    }

    fun setMuted(value: Boolean) {
        muted = value
    }

    private fun outputRpm(): Float =
        if (drivenTeeth == 0) 0f else inputRpm * driverTeeth.toFloat() / drivenTeeth.toFloat()

    private fun sawtooth(phase: Double): Double {
        val twoPi = 2.0 * PI
        val p = phase % twoPi
        return (p / PI) - 1.0
    }

    private fun playLoop() {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufSize = if (minBuf > 0) minBuf * 2 else sampleRate

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(sampleRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufSize)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()

        track.play()

        var phaseHum1 = 0.0
        var phaseHum2 = 0.0
        var phaseClick = 0.0
        var phaseLfo = 0.0

        val chunk = 1024
        val buffer = ShortArray(chunk)

        try {
            while (running) {
                val out = outputRpm()
                val f1 = 40.0 + abs(inputRpm.toDouble()) * 1.8
                val f2 = 40.0 + abs(out.toDouble()) * 1.8
                var meshFreq = abs(inputRpm.toDouble() / 60.0 * driverTeeth.toDouble())
                if (meshFreq < 0.4) meshFreq = 0.4
                if (meshFreq > 45.0) meshFreq = 45.0

                var i = 0
                while (i < chunk) {
                    phaseHum1 += 2.0 * PI * f1 / sampleRate
                    phaseHum2 += 2.0 * PI * f2 / sampleRate
                    phaseClick += 2.0 * PI * 480.0 / sampleRate
                    phaseLfo += 2.0 * PI * meshFreq / sampleRate

                    val hum1 = sawtooth(phaseHum1) * 0.05
                    val hum2 = sawtooth(phaseHum2) * 0.05
                    val lfo = sin(phaseLfo)
                    var clickAmp = 0.05 + 0.05 * lfo
                    if (clickAmp < 0.0) clickAmp = 0.0
                    if (clickAmp > 0.12) clickAmp = 0.12
                    val click = sin(phaseClick) * clickAmp

                    var sample = hum1 + hum2 + click
                    if (muted) sample = 0.0
                    if (sample > 1.0) sample = 1.0
                    if (sample < -1.0) sample = -1.0

                    buffer[i] = (sample * Short.MAX_VALUE.toDouble()).toInt().toShort()
                    i++
                }
                track.write(buffer, 0, chunk)
            }
        } finally {
            track.stop()
            track.release()
        }
    }
}
