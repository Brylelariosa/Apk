package com.gearlab.ratio

import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CompoundButton
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var gearView: GearView
    private val soundEngine = GearSoundEngine()

    private lateinit var statRatio: TextView
    private lateinit var statOutput: TextView
    private lateinit var statTorque: TextView
    private lateinit var caption: TextView

    private lateinit var seekDriver: SeekBar
    private lateinit var seekDriven: SeekBar
    private lateinit var seekRpm: SeekBar
    private lateinit var valDriver: TextView
    private lateinit var valDriven: TextView
    private lateinit var valRpm: TextView

    private lateinit var btnEngine: Button
    private lateinit var btnMute: Button

    private lateinit var switchChallenge: Switch
    private lateinit var challengeBody: View
    private lateinit var targetValue: TextView
    private lateinit var btnCheck: Button
    private lateinit var scoreValue: TextView
    private lateinit var stamp: TextView

    private var driverTeeth = 12
    private var drivenTeeth = 24
    private var inputRpm = 30
    private var running = false
    private var muted = false

    private var target = 0
    private var score = 0

    private val minTeeth = 8
    private val maxTeeth = 28
    private val maxRpm = 120

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gearView = findViewById(R.id.gearView)
        statRatio = findViewById(R.id.statRatio)
        statOutput = findViewById(R.id.statOutput)
        statTorque = findViewById(R.id.statTorque)
        caption = findViewById(R.id.caption)

        seekDriver = findViewById(R.id.seekDriver)
        seekDriven = findViewById(R.id.seekDriven)
        seekRpm = findViewById(R.id.seekRpm)
        valDriver = findViewById(R.id.valDriver)
        valDriven = findViewById(R.id.valDriven)
        valRpm = findViewById(R.id.valRpm)

        btnEngine = findViewById(R.id.btnEngine)
        btnMute = findViewById(R.id.btnMute)

        switchChallenge = findViewById(R.id.switchChallenge)
        challengeBody = findViewById(R.id.challengeBody)
        targetValue = findViewById(R.id.targetValue)
        btnCheck = findViewById(R.id.btnCheck)
        scoreValue = findViewById(R.id.scoreValue)
        stamp = findViewById(R.id.stamp)

        seekDriver.max = maxTeeth - minTeeth
        seekDriver.progress = driverTeeth - minTeeth
        seekDriven.max = maxTeeth - minTeeth
        seekDriven.progress = drivenTeeth - minTeeth
        seekRpm.max = maxRpm
        seekRpm.progress = inputRpm

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                driverTeeth = seekDriver.progress + minTeeth
                drivenTeeth = seekDriven.progress + minTeeth
                inputRpm = seekRpm.progress
                onParamsChanged()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        seekDriver.setOnSeekBarChangeListener(listener)
        seekDriven.setOnSeekBarChangeListener(listener)
        seekRpm.setOnSeekBarChangeListener(listener)

        btnEngine.setOnClickListener {
            running = !running
            gearView.running = running
            btnEngine.text = if (running) getString(R.string.stop_engine) else getString(R.string.start_engine)
            btnMute.isEnabled = true
            if (running) soundEngine.start() else soundEngine.stop()
        }

        btnMute.setOnClickListener {
            muted = !muted
            btnMute.text = if (muted) "🔇" else "🔊"
            soundEngine.setMuted(muted)
        }

        switchChallenge.setOnCheckedChangeListener { _: CompoundButton, isChecked: Boolean ->
            challengeBody.visibility = if (isChecked) View.VISIBLE else View.GONE
            if (isChecked && target == 0) newTarget()
        }

        btnCheck.setOnClickListener { checkFit() }

        onParamsChanged()
    }

    private fun onParamsChanged() {
        valDriver.text = driverTeeth.toString()
        valDriven.text = drivenTeeth.toString()
        valRpm.text = "$inputRpm rpm"

        gearView.driverTeeth = driverTeeth
        gearView.drivenTeeth = drivenTeeth
        gearView.inputRpm = inputRpm.toFloat()

        soundEngine.driverTeeth = driverTeeth
        soundEngine.drivenTeeth = drivenTeeth
        soundEngine.inputRpm = inputRpm.toFloat()

        val out = outputRpm()
        val g = gcd(drivenTeeth, driverTeeth)
        val divisor = if (g == 0) 1 else g
        statRatio.text = "${drivenTeeth / divisor}:${driverTeeth / divisor}"
        statOutput.text = String.format("%.1f", out)
        val torque = drivenTeeth.toFloat() / driverTeeth.toFloat()
        statTorque.text = String.format("%.2f×", torque)
        caption.text = "The driver turns $driverTeeth teeth against $drivenTeeth, so it spins " +
            String.format("%.2f", torque) + "× for every turn of the driven gear — trading speed for torque."
    }

    private fun outputRpm(): Float =
        if (drivenTeeth == 0) 0f else inputRpm.toFloat() * driverTeeth.toFloat() / drivenTeeth.toFloat()

    private fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)

    private fun newTarget() {
        target = 10 + Random.nextInt(111)
        targetValue.text = "$target rpm"
        stamp.text = ""
    }

    private fun checkFit() {
        val out = outputRpm()
        val diff = abs(out - target.toFloat())
        if (diff <= 3f) {
            score++
            scoreValue.text = score.toString()
            stamp.text = "MATCH ✓  output " + String.format("%.1f", out) + " rpm"
            stamp.setTextColor(Color.parseColor("#6FE3A0"))
            newTarget()
        } else {
            stamp.text = "OFF SPEC — output " + String.format("%.1f", out) + " rpm (need $target)"
            stamp.setTextColor(Color.parseColor("#E3776F"))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        soundEngine.stop()
    }
}
