package com.gearlab.ratio

import android.app.Activity
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.pow
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var gearView: GearView
    private val soundEngine = GearSoundEngine()
    private lateinit var prefs: SharedPreferences

    private lateinit var statRatio: TextView
    private lateinit var statOutput: TextView
    private lateinit var statTorque: TextView
    private lateinit var caption: TextView

    private lateinit var seekDriver: SeekBar
    private lateinit var seekDriven: SeekBar
    private lateinit var seekRpm: SeekBar
    private lateinit var valDriver: TextView
    private lateinit var valDriven: TextView
    private lateinit var valRpm: TextView

    private lateinit var stage2Panel: View
    private lateinit var seekStage2Driver: SeekBar
    private lateinit var seekStage2Driven: SeekBar
    private lateinit var valStage2Driver: TextView
    private lateinit var valStage2Driven: TextView

    private lateinit var btnEngine: Button
    private lateinit var btnMute: ImageButton

    private lateinit var coinsValue: TextView
    private lateinit var productionValue: TextView
    private lateinit var upgradeTeethLabel: TextView
    private lateinit var btnUpgradeTeeth: Button
    private lateinit var upgradeRpmLabel: TextView
    private lateinit var btnUpgradeRpm: Button
    private lateinit var upgradeEfficiencyLabel: TextView
    private lateinit var btnUpgradeEfficiency: Button
    private lateinit var upgradeStage2Label: TextView
    private lateinit var btnUpgradeStage2: Button

    private var driverTeeth = 12
    private var drivenTeeth = 24
    private var inputRpm = 30
    private var running = false
    private var muted = false

    private var stage2Enabled = false
    private var stage2DriverTeeth = 12
    private var stage2DrivenTeeth = 12

    private val minTeeth = 8
    private var maxTeeth = 28
    private var maxRpm = 120

    private var coins = 0f
    private var teethLevel = 0
    private var rpmLevel = 0
    private var effLevel = 0
    private val efficiencyMultiplier: Float get() = 1f + effLevel * 0.25f
    private val stage2Cost = 300f

    private val coinHandler = Handler(Looper.getMainLooper())
    private val tickMs = 200L
    private val coinTick = object : Runnable {
        override fun run() {
            if (running) {
                coins += productionPerSecond() * (tickMs / 1000f)
                updateFactoryUi()
            }
            coinHandler.postDelayed(this, tickMs)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("gear_tycoon_prefs", MODE_PRIVATE)

        gearView = findViewById(R.id.gearView)
        statRatio = findViewById(R.id.statRatio)
        statOutput = findViewById(R.id.statOutput)
        statTorque = findViewById(R.id.statTorque)
        caption = findViewById(R.id.caption)

        seekDriver = findViewById(R.id.seekDriver)
        seekDriven = findViewById(R.id.seekDriven)
        seekRpm = findViewById(R.id.seekRpm)
        valDriver = findViewById(R.id.valDriver)
        valDriven = findViewById(R.id.valDriven)
        valRpm = findViewById(R.id.valRpm)

        stage2Panel = findViewById(R.id.stage2Panel)
        seekStage2Driver = findViewById(R.id.seekStage2Driver)
        seekStage2Driven = findViewById(R.id.seekStage2Driven)
        valStage2Driver = findViewById(R.id.valStage2Driver)
        valStage2Driven = findViewById(R.id.valStage2Driven)

        btnEngine = findViewById(R.id.btnEngine)
        btnMute = findViewById(R.id.btnMute)

        coinsValue = findViewById(R.id.coinsValue)
        productionValue = findViewById(R.id.productionValue)
        upgradeTeethLabel = findViewById(R.id.upgradeTeethLabel)
        btnUpgradeTeeth = findViewById(R.id.btnUpgradeTeeth)
        upgradeRpmLabel = findViewById(R.id.upgradeRpmLabel)
        btnUpgradeRpm = findViewById(R.id.btnUpgradeRpm)
        upgradeEfficiencyLabel = findViewById(R.id.upgradeEfficiencyLabel)
        btnUpgradeEfficiency = findViewById(R.id.btnUpgradeEfficiency)
        upgradeStage2Label = findViewById(R.id.upgradeStage2Label)
        btnUpgradeStage2 = findViewById(R.id.btnUpgradeStage2)

        loadState()

        seekDriver.max = maxTeeth - minTeeth
        seekDriver.progress = driverTeeth - minTeeth
        seekDriven.max = maxTeeth - minTeeth
        seekDriven.progress = drivenTeeth - minTeeth
        seekRpm.max = maxRpm
        seekRpm.progress = inputRpm

        seekStage2Driver.max = maxTeeth - minTeeth
        seekStage2Driver.progress = stage2DriverTeeth - minTeeth
        seekStage2Driven.max = maxTeeth - minTeeth
        seekStage2Driven.progress = stage2DrivenTeeth - minTeeth

        val listener = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                driverTeeth = seekDriver.progress + minTeeth
                drivenTeeth = seekDriven.progress + minTeeth
                inputRpm = seekRpm.progress
                stage2DriverTeeth = seekStage2Driver.progress + minTeeth
                stage2DrivenTeeth = seekStage2Driven.progress + minTeeth
                onParamsChanged()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        seekDriver.setOnSeekBarChangeListener(listener)
        seekDriven.setOnSeekBarChangeListener(listener)
        seekRpm.setOnSeekBarChangeListener(listener)
        seekStage2Driver.setOnSeekBarChangeListener(listener)
        seekStage2Driven.setOnSeekBarChangeListener(listener)

        btnEngine.setOnClickListener {
            running = !running
            gearView.running = running
            if (running) {
                btnEngine.text = getString(R.string.stop_engine)
                btnEngine.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_pause_dark, 0, 0, 0)
                soundEngine.start()
            } else {
                btnEngine.text = getString(R.string.start_engine)
                btnEngine.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_play_dark, 0, 0, 0)
                soundEngine.stop()
            }
            btnMute.isEnabled = true
            updateFactoryUi()
        }

        btnMute.setOnClickListener {
            muted = !muted
            btnMute.setImageResource(if (muted) R.drawable.ic_volume_off_cyan else R.drawable.ic_volume_cyan)
            soundEngine.setMuted(muted)
        }

        btnUpgradeTeeth.setOnClickListener {
            val cost = teethUpgradeCost()
            if (coins >= cost) {
                coins -= cost
                teethLevel++
                maxTeeth = 28 + teethLevel * 8
                seekDriver.max = maxTeeth - minTeeth
                seekDriven.max = maxTeeth - minTeeth
                seekStage2Driver.max = maxTeeth - minTeeth
                seekStage2Driven.max = maxTeeth - minTeeth
                updateFactoryUi()
            }
        }
        btnUpgradeRpm.setOnClickListener {
            val cost = rpmUpgradeCost()
            if (coins >= cost) {
                coins -= cost
                rpmLevel++
                maxRpm = 120 + rpmLevel * 40
                seekRpm.max = maxRpm
                updateFactoryUi()
            }
        }
        btnUpgradeEfficiency.setOnClickListener {
            val cost = effUpgradeCost()
            if (coins >= cost) {
                coins -= cost
                effLevel++
                updateFactoryUi()
            }
        }
        btnUpgradeStage2.setOnClickListener {
            if (!stage2Enabled && coins >= stage2Cost) {
                coins -= stage2Cost
                stage2Enabled = true
                stage2Panel.visibility = View.VISIBLE
                gearView.stage2Enabled = true
                onParamsChanged()
            }
        }

        applyStage2Visibility()
        onParamsChanged()
        updateFactoryUi()
        coinHandler.post(coinTick)
        grantOfflineEarnings()
    }

    private fun applyStage2Visibility() {
        stage2Panel.visibility = if (stage2Enabled) View.VISIBLE else View.GONE
        gearView.stage2Enabled = stage2Enabled
    }

    private fun onParamsChanged() {
        valDriver.text = driverTeeth.toString()
        valDriven.text = drivenTeeth.toString()
        valRpm.text = "$inputRpm rpm"
        valStage2Driver.text = stage2DriverTeeth.toString()
        valStage2Driven.text = stage2DrivenTeeth.toString()

        gearView.driverTeeth = driverTeeth
        gearView.drivenTeeth = drivenTeeth
        gearView.inputRpm = inputRpm.toFloat()
        gearView.stage2DriverTeeth = stage2DriverTeeth
        gearView.stage2DrivenTeeth = stage2DrivenTeeth
        gearView.stage2InputRpm = stage1OutputRpm()

        soundEngine.driverTeeth = driverTeeth
        soundEngine.inputRpm = inputRpm.toFloat()
        soundEngine.finalOutputRpm = finalOutputRpm()

        val stage1Out = stage1OutputRpm()
        val g = gcd(drivenTeeth, driverTeeth)
        val divisor = if (g == 0) 1 else g
        statRatio.text = "${drivenTeeth / divisor}:${driverTeeth / divisor}"
        statOutput.text = String.format("%.1f", finalOutputRpm())
        val torque = drivenTeeth.toFloat() / driverTeeth.toFloat()
        statTorque.text = String.format("%.2f×", torque)

        val baseCaption = "The driver turns $driverTeeth teeth against $drivenTeeth, so Stage 1 spins " +
            String.format("%.2f", torque) + "× for every turn — " + String.format("%.1f", stage1Out) + " rpm out."
        caption.text = if (stage2Enabled) {
            val stage2Torque = stage2DrivenTeeth.toFloat() / stage2DriverTeeth.toFloat()
            baseCaption + " Stage 2 re-multiplies that by " + String.format("%.2f", stage2Torque) +
                "× to a final " + String.format("%.1f", finalOutputRpm()) + " rpm driving the factory."
        } else {
            baseCaption
        }

        updateFactoryUi()
    }

    private fun stage1OutputRpm(): Float =
        if (drivenTeeth == 0) 0f else inputRpm.toFloat() * driverTeeth.toFloat() / drivenTeeth.toFloat()

    private fun stage2OutputRpm(): Float {
        val stage1Out = stage1OutputRpm()
        return if (stage2DrivenTeeth == 0) 0f else stage1Out * stage2DriverTeeth.toFloat() / stage2DrivenTeeth.toFloat()
    }

    private fun finalOutputRpm(): Float = if (stage2Enabled) stage2OutputRpm() else stage1OutputRpm()

    private fun gcd(a: Int, b: Int): Int = if (b == 0) a else gcd(b, a % b)

    // Coins are earned from the actual speed the factory shaft achieves — a 1:1 pair of
    // huge gears produces nothing extra, matching how gearing really works. Building a
    // genuinely fast (or, via Stage 2, doubly-multiplied) drivetrain is what pays off.
    private fun productionPerSecond(): Float = finalOutputRpm() * 0.15f * efficiencyMultiplier

    private fun teethUpgradeCost(): Float = 50f * 1.6f.pow(teethLevel)
    private fun rpmUpgradeCost(): Float = 40f * 1.6f.pow(rpmLevel)
    private fun effUpgradeCost(): Float = 80f * 1.7f.pow(effLevel)

    private fun updateFactoryUi() {
        coinsValue.text = String.format("%,.0f", coins)
        val rate = productionPerSecond()
        productionValue.text = if (running) {
            "+" + String.format("%.2f", rate) + " / sec"
        } else {
            "+" + String.format("%.2f", rate) + " / sec (stopped)"
        }

        val teethCost = teethUpgradeCost()
        upgradeTeethLabel.text = "Lv.$teethLevel — max teeth: $maxTeeth"
        btnUpgradeTeeth.text = teethCost.roundToInt().toString()
        btnUpgradeTeeth.isEnabled = coins >= teethCost
        btnUpgradeTeeth.alpha = if (btnUpgradeTeeth.isEnabled) 1f else 0.4f

        val rpmCost = rpmUpgradeCost()
        upgradeRpmLabel.text = "Lv.$rpmLevel — max speed: $maxRpm rpm"
        btnUpgradeRpm.text = rpmCost.roundToInt().toString()
        btnUpgradeRpm.isEnabled = coins >= rpmCost
        btnUpgradeRpm.alpha = if (btnUpgradeRpm.isEnabled) 1f else 0.4f

        val effCost = effUpgradeCost()
        upgradeEfficiencyLabel.text = "Lv.$effLevel — ×" + String.format("%.2f", efficiencyMultiplier) + " coins"
        btnUpgradeEfficiency.text = effCost.roundToInt().toString()
        btnUpgradeEfficiency.isEnabled = coins >= effCost
        btnUpgradeEfficiency.alpha = if (btnUpgradeEfficiency.isEnabled) 1f else 0.4f

        if (stage2Enabled) {
            upgradeStage2Label.text = "Owned — a second gearbox compounds your ratio"
            btnUpgradeStage2.text = "OWNED"
            btnUpgradeStage2.isEnabled = false
            btnUpgradeStage2.alpha = 0.6f
        } else {
            upgradeStage2Label.text = "Bolt on a second gearbox after the first"
            btnUpgradeStage2.text = stage2Cost.roundToInt().toString()
            btnUpgradeStage2.isEnabled = coins >= stage2Cost
            btnUpgradeStage2.alpha = if (btnUpgradeStage2.isEnabled) 1f else 0.4f
        }
    }

    private fun loadState() {
        coins = prefs.getFloat("coins", 0f)
        teethLevel = prefs.getInt("teeth_level", 0)
        rpmLevel = prefs.getInt("rpm_level", 0)
        effLevel = prefs.getInt("eff_level", 0)
        maxTeeth = 28 + teethLevel * 8
        maxRpm = 120 + rpmLevel * 40
        driverTeeth = prefs.getInt("driver_teeth", 12).coerceIn(minTeeth, maxTeeth)
        drivenTeeth = prefs.getInt("driven_teeth", 24).coerceIn(minTeeth, maxTeeth)
        inputRpm = prefs.getInt("input_rpm", 30).coerceIn(0, maxRpm)

        stage2Enabled = prefs.getBoolean("stage2_enabled", false)
        stage2DriverTeeth = prefs.getInt("stage2_driver_teeth", 12).coerceIn(minTeeth, maxTeeth)
        stage2DrivenTeeth = prefs.getInt("stage2_driven_teeth", 12).coerceIn(minTeeth, maxTeeth)
    }

    private fun grantOfflineEarnings() {
        val wasRunning = prefs.getBoolean("was_running", false)
        if (!wasRunning) return
        val lastTs = prefs.getLong("last_ts", System.currentTimeMillis())
        val elapsedMs = System.currentTimeMillis() - lastTs
        var elapsedSec = elapsedMs / 1000L
        val maxOfflineSec = 8L * 3600L
        if (elapsedSec > maxOfflineSec) elapsedSec = maxOfflineSec
        if (elapsedSec > 1L) {
            val earned = productionPerSecond() * elapsedSec
            if (earned > 0.5f) {
                coins += earned
                updateFactoryUi()
                Toast.makeText(
                    this,
                    "Welcome back! +" + earned.roundToInt() + " coins while the factory ran without you",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun saveState() {
        prefs.edit()
            .putFloat("coins", coins)
            .putLong("last_ts", System.currentTimeMillis())
            .putBoolean("was_running", running)
            .putInt("teeth_level", teethLevel)
            .putInt("rpm_level", rpmLevel)
            .putInt("eff_level", effLevel)
            .putInt("driver_teeth", driverTeeth)
            .putInt("driven_teeth", drivenTeeth)
            .putInt("input_rpm", inputRpm)
            .putBoolean("stage2_enabled", stage2Enabled)
            .putInt("stage2_driver_teeth", stage2DriverTeeth)
            .putInt("stage2_driven_teeth", stage2DrivenTeeth)
            .apply()
    }

    override fun onPause() {
        super.onPause()
        saveState()
    }

    override fun onDestroy() {
        super.onDestroy()
        coinHandler.removeCallbacks(coinTick)
        soundEngine.stop()
        saveState()
    }
}
