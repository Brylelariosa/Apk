package com.gearlab.ratio

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class GearView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var driverTeeth: Int = 12
    var drivenTeeth: Int = 24
    var inputRpm: Float = 30f
    var running: Boolean = false

    private var angle1: Float = 0f
    private var angle2: Float = 0f
    private var lastFrameNanos: Long = 0L

    private val choreographer = Choreographer.getInstance()
    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (lastFrameNanos != 0L) {
                val dtSeconds = (frameTimeNanos - lastFrameNanos).toDouble() / 1_000_000_000.0
                val dt = if (dtSeconds > 0.05) 0.05 else dtSeconds
                if (running) {
                    val outRpm = outputRpm()
                    val driverDegPerSec = inputRpm.toDouble() * 6.0
                    val drivenDegPerSec = outRpm.toDouble() * 6.0
                    angle1 += (driverDegPerSec * dt).toFloat()
                    angle2 -= (drivenDegPerSec * dt).toFloat()
                }
            }
            lastFrameNanos = frameTimeNanos
            invalidate()
            choreographer.postFrameCallback(this)
        }
    }

    fun outputRpm(): Float = if (drivenTeeth == 0) 0f else inputRpm * driverTeeth.toFloat() / drivenTeeth.toFloat()

    private val faceDriver = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E3AE63") }
    private val shadeDriver = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8B5E2B"); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val hubDriver = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8B5E2B") }

    private val faceDriven = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CFE3EE") }
    private val shadeDriven = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7C93A0"); style = Paint.Style.STROKE; strokeWidth = 3f
    }
    private val hubDriven = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#7C93A0") }

    private val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0A1F33") }

    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8CDCF5")
        alpha = 150
        style = Paint.Style.STROKE
        strokeWidth = 2f
        pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
    }
    private val crosshairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E3AE63")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8FE3FF")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.MONOSPACE
    }
    private val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CBE3F0")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastFrameNanos = 0L
        choreographer.postFrameCallback(frameCallback)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        choreographer.removeFrameCallback(frameCallback)
    }

    private fun radiusFor(teeth: Int, scale: Float): Float = (8f + teeth.toFloat() * 3.2f) * scale

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val scale = min(w / 460f, h / 300f)
        labelPaint.textSize = 26f * scale
        tagPaint.textSize = 22f * scale

        val cx = w / 2f
        val cy = h / 2f + 18f * scale

        val r1 = radiusFor(driverTeeth, scale)
        val r2 = radiusFor(drivenTeeth, scale)
        val x1 = cx - r1
        val y1 = cy
        val x2 = cx + r2
        val y2 = cy

        drawAnnotations(canvas, cx, cy, x1, y1, r1, driverTeeth, x2, y2, r2, drivenTeeth, scale)
        drawGear(canvas, x1, y1, driverTeeth, angle1, r1, faceDriver, shadeDriver, hubDriver)
        drawGear(canvas, x2, y2, drivenTeeth, angle2, r2, faceDriven, shadeDriven, hubDriven)

        canvas.drawText("DRIVER", x1, y1 + r1 * 1.45f + 34f * scale, tagPaint)
        canvas.drawText("DRIVEN", x2, y2 + r2 * 1.45f + 34f * scale, tagPaint)
    }

    private fun drawGear(
        canvas: Canvas, cx: Float, cy: Float, teeth: Int, angleDeg: Float, pitchR: Float,
        face: Paint, shade: Paint, hub: Paint
    ) {
        val rootR = pitchR * 0.78f
        val tipR = pitchR * 1.12f
        val halfToothAngle = (Math.PI * 2.0 / teeth.toDouble()) * 0.28

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(angleDeg)

        canvas.drawCircle(0f, 0f, rootR, face)

        for (i in 0 until teeth) {
            val centerAngleDeg = Math.toDegrees(i.toDouble() * (2.0 * Math.PI / teeth.toDouble())).toFloat()
            canvas.save()
            canvas.rotate(centerAngleDeg)
            val path = Path()
            val a0 = -halfToothAngle
            val a1 = halfToothAngle
            path.moveTo((cos(a0) * rootR).toFloat(), (sin(a0) * rootR).toFloat())
            path.lineTo((cos(a0) * tipR).toFloat(), (sin(a0) * tipR).toFloat())
            path.lineTo((cos(a1) * tipR).toFloat(), (sin(a1) * tipR).toFloat())
            path.lineTo((cos(a1) * rootR).toFloat(), (sin(a1) * rootR).toFloat())
            path.close()
            canvas.drawPath(path, face)
            canvas.restore()
        }

        canvas.drawCircle(0f, 0f, rootR, shade)
        canvas.drawCircle(0f, 0f, pitchR * 0.30f, hub)
        canvas.drawCircle(0f, 0f, pitchR * 0.13f, holePaint)

        canvas.restore()
    }

    private fun drawAnnotations(
        canvas: Canvas, cx: Float, cy: Float,
        x1: Float, y1: Float, r1: Float, t1: Int,
        x2: Float, y2: Float, r2: Float, t2: Int,
        scale: Float
    ) {
        val topY1 = y1 - r1 * 1.35f - 14f * scale
        val topY2 = y2 - r2 * 1.35f - 14f * scale

        canvas.drawLine(x1, y1, x1, topY1, dashPaint)
        canvas.drawLine(x2, y2, x2, topY2, dashPaint)
        canvas.drawLine(x1, topY1, x2, topY2, dashPaint)

        canvas.drawText("T=$t1", x1, topY1 - 8f * scale, labelPaint)
        canvas.drawText("T=$t2", x2, topY2 - 8f * scale, labelPaint)

        val ch = 10f * scale
        canvas.drawLine(cx - ch, cy, cx + ch, cy, crosshairPaint)
        canvas.drawLine(cx, cy - ch, cx, cy + ch, crosshairPaint)
    }
}
