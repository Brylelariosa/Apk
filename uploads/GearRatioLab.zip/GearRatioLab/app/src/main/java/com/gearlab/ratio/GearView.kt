package com.gearlab.ratio

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class GearView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    // Stage 1 (always present)
    var driverTeeth: Int = 12
    var drivenTeeth: Int = 24
    var inputRpm: Float = 30f
    var running: Boolean = false

    // Stage 2 (optional second gearbox, unlocked by an upgrade)
    var stage2Enabled: Boolean = false
    var stage2DriverTeeth: Int = 12
    var stage2DrivenTeeth: Int = 12
    var stage2InputRpm: Float = 0f

    private var angle1: Float = 0f
    private var angle2: Float = 0f
    private var angle3: Float = 0f
    private var angle4: Float = 0f
    private var lastFrameNanos: Long = 0L

    private val choreographer = Choreographer.getInstance()
    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (lastFrameNanos != 0L) {
                val dtSeconds = (frameTimeNanos - lastFrameNanos).toDouble() / 1_000_000_000.0
                val dt = if (dtSeconds > 0.05) 0.05 else dtSeconds
                if (running) {
                    val out1 = ratioOutput(driverTeeth, drivenTeeth, inputRpm)
                    angle1 += (inputRpm.toDouble() * 6.0 * dt).toFloat()
                    angle2 -= (out1.toDouble() * 6.0 * dt).toFloat()

                    if (stage2Enabled) {
                        val out2 = ratioOutput(stage2DriverTeeth, stage2DrivenTeeth, stage2InputRpm)
                        angle3 += (stage2InputRpm.toDouble() * 6.0 * dt).toFloat()
                        angle4 -= (out2.toDouble() * 6.0 * dt).toFloat()
                    }
                }
            }
            lastFrameNanos = frameTimeNanos
            invalidate()
            choreographer.postFrameCallback(this)
        }
    }

    private fun ratioOutput(driver: Int, driven: Int, rpmIn: Float): Float =
        if (driven == 0) 0f else rpmIn * driver.toFloat() / driven.toFloat()

    private val faceDriver = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E3AE63") }
    private val shadeDriver = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8B5E2B"); style = Paint.Style.STROKE; strokeWidth = 2.5f
    }
    private val hubDriver = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#8B5E2B") }

    private val faceDriven = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#CFE3EE") }
    private val shadeDriven = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7C93A0"); style = Paint.Style.STROKE; strokeWidth = 2.5f
    }
    private val hubDriven = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#7C93A0") }

    private val holePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0A1F33") }

    private val dashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8CDCF5")
        alpha = 150
        style = Paint.Style.STROKE
        strokeWidth = 2f
        pathEffect = DashPathEffect(floatArrayOf(10f, 10f), 0f)
    }
    private val crosshairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E3AE63")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8FE3FF")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.MONOSPACE
    }
    private val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CBE3F0")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }
    private val stagePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7FA8C9")
        textAlign = Paint.Align.LEFT
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        lastFrameNanos = 0L
        choreographer.postFrameCallback(frameCallback)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        choreographer.removeFrameCallback(frameCallback)
    }

    private fun radiusFor(teeth: Int, scale: Float): Float = (8f + teeth.toFloat() * 3.2f) * scale

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        if (!stage2Enabled) {
            drawRow(canvas, 0f, h, w, driverTeeth, drivenTeeth, angle1, angle2, null)
        } else {
            val rowH = h / 2f
            drawRow(canvas, 0f, rowH, w, driverTeeth, drivenTeeth, angle1, angle2, "STAGE 1")
            drawRow(canvas, rowH, rowH, w, stage2DriverTeeth, stage2DrivenTeeth, angle3, angle4, "STAGE 2")
        }
    }

    private fun drawRow(
        canvas: Canvas, top: Float, rowH: Float, w: Float,
        teethA: Int, teethB: Int, angleA: Float, angleB: Float, stageLabel: String?
    ) {
        val scale = min(w / 460f, rowH / 300f)
        labelPaint.textSize = 24f * scale
        tagPaint.textSize = 20f * scale

        val cx = w / 2f
        val cy = top + rowH / 2f + 16f * scale

        val rA = radiusFor(teethA, scale)
        val rB = radiusFor(teethB, scale)
        val xA = cx - rA
        val yA = cy
        val xB = cx + rB
        val yB = cy

        drawAnnotations(canvas, cx, cy, xA, yA, rA, teethA, xB, yB, rB, teethB, scale)
        drawGear(canvas, xA, yA, teethA, angleA, rA, faceDriver, shadeDriver, hubDriver)
        drawGear(canvas, xB, yB, teethB, angleB, rB, faceDriven, shadeDriven, hubDriven)

        canvas.drawText("DRIVER", xA, yA + rA * 1.5f + 30f * scale, tagPaint)
        canvas.drawText("DRIVEN", xB, yB + rB * 1.5f + 30f * scale, tagPaint)

        if (stageLabel != null) {
            stagePaint.textSize = 20f * scale
            canvas.drawText(stageLabel, 6f * scale, top + 20f * scale, stagePaint)
        }
    }

    private val gearPath = Path()
    private val tipRect = RectF()
    private val rootRect = RectF()

    private fun drawGear(
        canvas: Canvas, cx: Float, cy: Float, teeth: Int, angleDeg: Float, pitchR: Float,
        face: Paint, shade: Paint, hub: Paint
    ) {
        // Real-gear proportions: tooth depth is a fraction of pitch radius that shrinks
        // as tooth count grows (addendum = 2*pitchR/teeth, dedendum = 2.5*pitchR/teeth),
        // matching how an actual machined gear's module works — short, fine teeth,
        // not tall spikes.
        val addendum = 2f * pitchR / teeth.toFloat()
        val dedendum = 2.5f * pitchR / teeth.toFloat()
        val tipR = pitchR + addendum
        val rootR = pitchR - dedendum

        val pitchAngle = 2.0 * Math.PI / teeth.toDouble()
        val halfToothAngle = pitchAngle * 0.25 // tooth occupies half the pitch slot, gap the other half

        tipRect.set(-tipR, -tipR, tipR, tipR)
        rootRect.set(-rootR, -rootR, rootR, rootR)

        gearPath.reset()
        for (i in 0 until teeth) {
            val center = i.toDouble() * pitchAngle
            val aStart = center - halfToothAngle
            val aEnd = center + halfToothAngle

            val rootStartX = (cos(aStart) * rootR).toFloat()
            val rootStartY = (sin(aStart) * rootR).toFloat()
            val tipStartX = (cos(aStart) * tipR).toFloat()
            val tipStartY = (sin(aStart) * tipR).toFloat()
            val rootEndX = (cos(aEnd) * rootR).toFloat()
            val rootEndY = (sin(aEnd) * rootR).toFloat()

            if (i == 0) {
                gearPath.moveTo(rootStartX, rootStartY)
            } else {
                gearPath.lineTo(rootStartX, rootStartY)
            }
            gearPath.lineTo(tipStartX, tipStartY)

            val tipStartDeg = Math.toDegrees(aStart).toFloat()
            val tipSweepDeg = Math.toDegrees(aEnd - aStart).toFloat()
            gearPath.arcTo(tipRect, tipStartDeg, tipSweepDeg, false)

            gearPath.lineTo(rootEndX, rootEndY)

            val nextStart = (center + pitchAngle) - halfToothAngle
            val rootStartDeg = Math.toDegrees(aEnd).toFloat()
            val rootSweepDeg = Math.toDegrees(nextStart - aEnd).toFloat()
            gearPath.arcTo(rootRect, rootStartDeg, rootSweepDeg, false)
        }
        gearPath.close()

        canvas.save()
        canvas.translate(cx, cy)
        canvas.rotate(angleDeg)

        canvas.drawPath(gearPath, face)
        canvas.drawPath(gearPath, shade)
        canvas.drawCircle(0f, 0f, pitchR * 0.30f, hub)
        canvas.drawCircle(0f, 0f, pitchR * 0.13f, holePaint)

        canvas.restore()
    }

    private fun drawAnnotations(
        canvas: Canvas, cx: Float, cy: Float,
        x1: Float, y1: Float, r1: Float, t1: Int,
        x2: Float, y2: Float, r2: Float, t2: Int,
        scale: Float
    ) {
        val topY1 = y1 - r1 * 1.4f - 12f * scale
        val topY2 = y2 - r2 * 1.4f - 12f * scale

        canvas.drawLine(x1, y1, x1, topY1, dashPaint)
        canvas.drawLine(x2, y2, x2, topY2, dashPaint)
        canvas.drawLine(x1, topY1, x2, topY2, dashPaint)

        canvas.drawText("T=$t1", x1, topY1 - 8f * scale, labelPaint)
        canvas.drawText("T=$t2", x2, topY2 - 8f * scale, labelPaint)

        val ch = 9f * scale
        canvas.drawLine(cx - ch, cy, cx + ch, cy, crosshairPaint)
        canvas.drawLine(cx, cy - ch, cx, cy + ch, crosshairPaint)
    }
}
