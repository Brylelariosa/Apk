# Gear Ratio Lab (Android)

A small native Android app: two animated spur gears mesh on screen, teeth
rendered live on a Canvas, with blueprint-style dimension callouts showing
teeth count and ratio. Tap "Start Engine" to hear a synthesized engine hum
per gear (pitch follows RPM) plus a mechanical click/whine locked to the
real tooth-mesh frequency. A "Challenge Mode" gives you a target output RPM
to hit by adjusting the sliders.

No external assets, no native C++ — pure Kotlin + Canvas + AudioTrack, so
it builds with a plain Gradle/Java toolchain (nothing for the NDK/CMake
steps in your CI to do).

## Files
- `app/src/main/java/com/gearlab/ratio/MainActivity.kt` — UI wiring
- `app/src/main/java/com/gearlab/ratio/GearView.kt` — gear drawing + animation loop
- `app/src/main/java/com/gearlab/ratio/GearSoundEngine.kt` — AudioTrack sound synthesis
- `app/src/main/res/layout/activity_main.xml` — screen layout
- Gradle 8.6 wrapper config (`gradle/wrapper/gradle-wrapper.properties`) and
  a minimal `gradlew` launcher — your CI step fetches `gradle-wrapper.jar` itself.

## To build via your GitHub Actions workflow
1. Drop the zip this came in (e.g. `GearRatioLab.zip`) into the `uploads/`
   folder of your repo.
2. Commit and push — the `paths: uploads/**` trigger will fire the "Build APK"
   workflow automatically. (Or run it manually via **Actions → Build APK → Run workflow**.)
3. The workflow unzips it, finds `settings.gradle`, and runs `assembleDebug`
   (or `assembleRelease` if you've set the `KEYSTORE_BASE64` signing secrets).
4. Download the built APK from the workflow run's **Artifacts** section.
