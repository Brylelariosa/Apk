# Gear Ratio Tycoon (Android)

A small native Android app: two animated spur gears mesh on screen, drawn
with real-gear tooth proportions (tooth depth scales with tooth count, the
way an actual module-based gear works — short, fine teeth, not tall spikes)
as one continuous outline path so there are no seams. Blueprint-style
dimension callouts show teeth count and ratio live.

Tap "Start Engine" to hear two triangle-wave hum tones (pitch follows RPM)
plus a real percussive click synced to the tooth-mesh rate, run through a
gentle lowpass filter for warmth instead of a harsh raw waveform.

**The tycoon loop is now tied to actual output speed, not gear size.**
Coins/sec = final output RPM × efficiency — so setting both gears to the
same big tooth count earns nothing extra (1:1 ratio, no speedup), matching
how gearing really works. Upgrades:
- **Bigger Gears** — widens the teeth range, letting you reach more extreme ratios
- **Overclock** — raises the max input RPM
- **Efficiency Boost** — multiplies coins per RPM
- **Add Gearbox Stage** — bolts a second, independent gear pair onto the
  drivetrain's output shaft, so its ratio compounds with Stage 1's to reach
  a much higher (or lower) final speed

Progress, coins, and both stages' settings persist across restarts,
including offline earnings while the factory "ran without you."

All icons (play/pause, mute, upgrade arrow) are hand-authored vector
drawables — no emoji, no image assets. No external Maven dependencies
(no AppCompat/Material/core-ktx — the UI only uses framework widgets), and
both build types have `minifyEnabled`/`shrinkResources` on, to keep the
APK as small as it can be.

No native C++ — pure Kotlin + Canvas + AudioTrack, so it builds with a
plain Gradle/Java toolchain (nothing for the NDK/CMake steps in your CI
to do).

## Files
- `app/src/main/java/com/gearlab/ratio/MainActivity.kt` — UI wiring + tycoon economy
- `app/src/main/java/com/gearlab/ratio/GearView.kt` — gear drawing (Stage 1 + optional Stage 2) + animation loop
- `app/src/main/java/com/gearlab/ratio/GearSoundEngine.kt` — AudioTrack sound synthesis
- `app/src/main/res/layout/activity_main.xml` — screen layout
- `app/src/main/res/drawable/ic_*.xml` — vector icons
- Gradle 8.6 wrapper config (`gradle/wrapper/gradle-wrapper.properties`) and
  a minimal `gradlew` launcher — your CI step fetches `gradle-wrapper.jar` itself.

## To build via your GitHub Actions workflow
1. Drop the zip this came in (e.g. `GearRatioLab.zip`) into the `uploads/`
   folder of your repo.
2. Commit and push — the `paths: uploads/**` trigger will fire the "Build APK"
   workflow automatically. (Or run it manually via **Actions → Build APK → Run workflow**.)
3. The workflow unzips it, finds `settings.gradle`, and runs `assembleDebug`
   (or `assembleRelease` if you've set the `KEYSTORE_BASE64` signing secrets).
4. Download the built APK from the workflow run's **Artifacts** section.
