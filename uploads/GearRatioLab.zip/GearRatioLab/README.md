# Gear Ratio Tycoon (Android)

A small native Android app: two animated spur gears mesh on screen (drawn
as one continuous outline path, not overlapping pieces, so the teeth read
cleanly), with blueprint-style dimension callouts showing teeth count and
ratio. Tap "Start Engine" to hear a synthesized engine hum per gear (pitch
follows RPM) plus a mechanical click/whine locked to the real tooth-mesh
frequency.

Running the drivetrain earns **Coins**, spent on three upgrades (bigger
teeth range, higher max RPM, better efficiency) — a small idle-tycoon loop
layered on top of the simulation, with progress and coins saved across
app restarts (including offline earnings while the factory "ran without
you").

All icons (play/pause, mute, upgrade arrow) are hand-authored vector
drawables — no emoji, no image assets. No external Maven dependencies
(no AppCompat/Material/core-ktx — the UI only uses framework widgets), and
both build types have `minifyEnabled`/`shrinkResources` on, to keep the
APK as small as it can be.

No native C++ — pure Kotlin + Canvas + AudioTrack, so it builds with a
plain Gradle/Java toolchain (nothing for the NDK/CMake steps in your CI
to do).

## Files
- `app/src/main/java/com/gearlab/ratio/MainActivity.kt` — UI wiring + tycoon economy
- `app/src/main/java/com/gearlab/ratio/GearView.kt` — gear drawing + animation loop
- `app/src/main/java/com/gearlab/ratio/GearSoundEngine.kt` — AudioTrack sound synthesis
- `app/src/main/res/layout/activity_main.xml` — screen layout
- `app/src/main/res/drawable/ic_*.xml` — vector icons
- Gradle 8.6 wrapper config (`gradle/wrapper/gradle-wrapper.properties`) and
  a minimal `gradlew` launcher — your CI step fetches `gradle-wrapper.jar` itself.

## To build via your GitHub Actions workflow
1. Drop the zip this came in (e.g. `GearRatioLab.zip`) into the `uploads/`
   folder of your repo.
2. Commit and push — the `paths: uploads/**` trigger will fire the "Build APK"
   workflow automatically. (Or run it manually via **Actions → Build APK → Run workflow**.)
3. The workflow unzips it, finds `settings.gradle`, and runs `assembleDebug`
   (or `assembleRelease` if you've set the `KEYSTORE_BASE64` signing secrets).
4. Download the built APK from the workflow run's **Artifacts** section.
