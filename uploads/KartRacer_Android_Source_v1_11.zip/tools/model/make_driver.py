"""Sculpts the race driver (seat space: origin at the seat, forward -Z, up +Y) and bakes it to app/src/main/resources/models/driver.kmb.

Regions (coloured per driver at load time by KartModels.driver): 0 suit, 1 stripe, 2 glove, 3 helmet shell (kart paint), 4 visor,
5 black trim, 6 steel, 7 white patch, 8 belt, 9 suit dark.
"""
import os
import sys
import time
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from sdfkit import *  # noqa

SUIT, STRIPE, GLOVE, SHELL, VISOR, BLACK, STEEL, WHITE, BELT, SUITD = range(10)
HY = 0.945                       # helmet centre height
HC = np.array([0.0, HY, -0.02])  # helmet centre

SH = (0.305, 0.570, 0.020)
EL = (0.405, 0.335, -0.125)
WR = (0.218, 0.286, -0.455)


def suit_sdf(P):
    q = mirror_x(P)
    pelvis = ellipsoid(q, (0, 0.10, 0.08), (0.25, 0.14, 0.20))
    waist = ellipsoid(q, (0, 0.20, 0.06), (0.225, 0.16, 0.17))
    chest = ellipsoid(q, (0, 0.41, 0.01), (0.275, 0.26, 0.175))
    girdle = ellipsoid(q, (0, 0.585, 0.03), (0.315, 0.105, 0.165))
    torso = smin(smin(smin(pelvis, waist, 0.09), chest, 0.12), girdle, 0.09)
    neck = capsule(q, (0, 0.60, 0.0), (0, 0.79, 0.0), 0.090, 0.082)
    body = smin(torso, neck, 0.06)
    upper = capsule(q, SH, EL, 0.100, 0.076)
    fore = capsule(q, EL, WR, 0.076, 0.052)
    arm = smin(upper, fore, 0.035)
    body = smin(body, arm, 0.055)
    thigh = capsule(q, (0.13, 0.12, 0.06), (0.17, 0.25, -0.40), 0.108, 0.086)
    body = smin(body, thigh, 0.05)
    # a soft crease where the collar meets the helmet neck roll and between chest and arm
    return body


def helmet_shell_sdf(P):
    p = P - HC
    q = mirror_x(p)
    shell = ellipsoid(p, (0, 0, 0), (0.205, 0.235, 0.275))
    shell = smax(shell, -(p[:, 1] + 0.19), 0.035)
    chin = rbox(p, (0, -0.168, -0.150), (0.135, 0.062, 0.095), 0.04)
    shell = smin(shell, chin, 0.07)
    tail = ellipsoid(p, (0, -0.045, 0.215), (0.10, 0.095, 0.095))
    shell = smin(shell, tail, 0.05)
    ear = ellipsoid(q, (0.19, -0.012, 0.035), (0.050, 0.090, 0.078))
    shell = smin(shell, ear, 0.03)
    intake = rbox(p, (0, 0.225, -0.07), (0.04, 0.012, 0.075), 0.012)
    shell = smin(shell, intake, 0.012)
    return shell


def helmet_region(V):
    return np.full(len(V), SHELL, np.int64)


def visor_sdf(P):
    p = P - HC
    shell = helmet_shell_sdf(P)
    layer = np.abs(shell - 0.007) - 0.0075
    win = rbox(p, (0, 0.035, -0.20), (0.215, 0.072, 0.20), 0.045)
    # lens shaped: narrower at the bottom corners
    return smax(layer, win, 0.0)


def belts_sdf(P):
    q = mirror_x(P)
    s1 = capsule(q, (0.20, 0.68, 0.17), (0.19, 0.655, -0.07), 0.026)
    s2 = capsule(q, (0.19, 0.655, -0.07), (0.05, 0.25, -0.185), 0.026)
    lap = capsule(P, (-0.22, 0.15, -0.15), (0.22, 0.15, -0.15), 0.026)
    hans = capsule(q, (0.20, 0.655, 0.06), (0.135, 0.595, -0.15), 0.040, 0.030)
    hansb = capsule(q, (0.19, 0.66, 0.11), (0.0, 0.685, 0.11), 0.03)
    return np.minimum(np.minimum(np.minimum(s1, s2), lap), np.minimum(hans, hansb))


def belts_region(V):
    q = mirror_x(V)
    r = np.full(len(V), BELT, np.int64)
    hans = np.minimum(capsule(q, (0.20, 0.655, 0.06), (0.135, 0.595, -0.15), 0.040, 0.030), capsule(q, (0.19, 0.66, 0.11), (0.0, 0.685, 0.11), 0.03))
    r[hans < 0.004] = BLACK
    return r


def small_parts_sdf(P):
    q = mirror_x(P)
    buckle = rbox(P, (0, 0.215, -0.19), (0.040, 0.030, 0.010), 0.008)
    neckroll = torus(P, (0, 0.745, 0.0), (0, 1, 0), 0.105, 0.024)
    rim = torus(P, (0, HY - 0.205, -0.03), (0, 1, 0), 0.125, 0.020)
    wing = rbox(P, (0, HY + 0.085, 0.31), (0.105, 0.007, 0.055), 0.006)
    pivot = cylinder(q, (0.215, HY + 0.095, -0.12), (1, 0, 0), 0.022, 0.008)
    return np.minimum(np.minimum(np.minimum(buckle, neckroll), np.minimum(rim, wing)), pivot)


def small_parts_region(V):
    q = mirror_x(V)
    r = np.full(len(V), BLACK, np.int64)
    r[rbox(V, (0, 0.215, -0.19), (0.040, 0.030, 0.010), 0.008) < 0.004] = STEEL
    r[rbox(V, (0, HY + 0.085, 0.31), (0.105, 0.007, 0.055), 0.006) < 0.004] = STRIPE
    r[cylinder(q, (0.215, HY + 0.095, -0.12), (1, 0, 0), 0.022, 0.008) < 0.004] = STEEL
    return r


def slab(P, c, n, half):
    """Distance to the slab |(P - c) . n| < half (n unit)."""
    n = np.asarray(n, float); n = n / np.linalg.norm(n)
    return np.abs((P - np.asarray(c, float)) @ n) - half


def glove_sdf(P):
    q = mirror_x(P)
    fist = ellipsoid(q, (0.205, 0.288, -0.50), (0.058, 0.05, 0.07))
    fing = capsule(q, (0.222, 0.297, -0.52), (0.125, 0.30, -0.52), 0.042, 0.034)
    thumb = capsule(q, (0.208, 0.272, -0.47), (0.165, 0.318, -0.50), 0.022, 0.018)
    stub = capsule(q, (0.222, 0.289, -0.43), (0.208, 0.288, -0.50), 0.056, 0.056)
    hand = smin(smin(smin(fist, fing, 0.02), thumb, 0.012), stub, 0.02)
    return hand


def const(region):
    return lambda V: np.full(len(V), region, np.int64)


def ring_decal(f, center, axis, ref, t_list, radius_tmax, nu, region, offset=0.004, arc=None):
    """Band round an axis: rings at the offsets in t_list along the axis. arc = (start, end) angle in radians, None = full circle."""
    axis = np.asarray(axis, float); axis = axis / np.linalg.norm(axis)
    ref = np.asarray(ref, float); ref = ref - axis * (ref @ axis); ref = ref / np.linalg.norm(ref)
    side = np.cross(axis, ref)
    closed = arc is None
    a0, a1 = (0.0, 2 * np.pi) if closed else arc
    n_u = nu if closed else nu
    angs = np.linspace(a0, a1, n_u + (0 if closed else 1), endpoint=False if closed else True)
    O = np.zeros((len(t_list), len(angs), 3)); D = np.zeros_like(O)
    for j, t in enumerate(t_list):
        for i, a in enumerate(angs):
            d = np.cos(a) * ref + np.sin(a) * side
            O[j, i] = np.asarray(center, float) + axis * t
            D[j, i] = d
    return grid_decal(f, O, D, len(angs) - 1 if not closed else len(angs), len(t_list) - 1, region, closed_u=closed, offset=offset, tmax=radius_tmax)


def patch_decal(f, origin_fn, dir_fn, us, vs, region, offset=0.004, tmax=0.5):
    O = np.zeros((len(vs), len(us), 3)); D = np.zeros_like(O)
    for j, v in enumerate(vs):
        for i, u in enumerate(us):
            O[j, i] = origin_fn(u, v)
            D[j, i] = dir_fn(u, v)
    return grid_decal(f, O, D, len(us) - 1, len(vs) - 1, region, offset=offset, tmax=tmax)


def sph_dir(th, ph):
    return np.array([np.cos(ph) * np.sin(th), np.sin(ph), -np.cos(ph) * np.cos(th)])


def decals():
    out = []
    # race number patch on the back
    out.append(patch_decal(suit_sdf, lambda u, v: np.array([u, v, 0.0]), lambda u, v: np.array([0.0, 0.0, 1.0]),
                           np.linspace(-0.115, 0.115, 7), np.linspace(0.325, 0.475, 5), WHITE, offset=0.0035))
    # chest and back stripe (arcs round the torso)
    centre = (0.0, 0.45, 0.02)
    for mid in (-np.pi / 2, np.pi / 2):          # front (-Z) and back (+Z) in the (x,z) plane: angle 0 = +x, 90 deg = +z
        out.append(ring_decal(suit_sdf, centre, (0, 1, 0), (1, 0, 0), [-0.016, 0.016], 0.45, 14, STRIPE, arc=(mid - 1.0, mid + 1.0), offset=0.0035))
    # arm bands and cuffs (both arms)
    sh = np.array(SH); el = np.array(EL); wr = np.array(WR)
    for sd in (-1, 1):
        s_ = np.array([sd, 1, 1]); shs, els, wrs = sh * s_, el * s_, wr * s_
        ax = (els - shs) / np.linalg.norm(els - shs); L1 = np.linalg.norm(els - shs)
        c1 = shs + ax * 0.44 * L1
        out.append(ring_decal(suit_sdf, c1, ax, (0, 0, 1), [-0.04, 0.04], 0.25, 14, STRIPE, offset=0.004))
        ax2 = (wrs - els) / np.linalg.norm(wrs - els); L2 = np.linalg.norm(wrs - els)
        c2 = els + ax2 * 0.86 * L2
        out.append(ring_decal(suit_sdf, c2, ax2, (0, 1, 0), [-0.022, 0.022], 0.2, 12, STRIPE, offset=0.004))
    # helmet: centre stripe front and back, side stripes, vents
    hc = HC
    def horig(u, v): return hc.copy()
    for th0 in (0.0, np.pi):
        out.append(patch_decal(helmet_shell_sdf, horig, lambda u, v, th0=th0: sph_dir(th0 + u, v), np.linspace(-0.10, 0.10, 3), np.linspace(0.45 if th0 == 0 else 0.25, 1.52, 9), STRIPE, offset=0.004, tmax=0.5))
    for sd in (-1, 1):
        out.append(patch_decal(helmet_shell_sdf, horig, lambda u, v, sd=sd: sph_dir(sd * 1.70 + u, v), np.linspace(-0.05, 0.05, 3), np.linspace(-0.45, 0.90, 6), STRIPE, offset=0.004, tmax=0.5))
    out.append(patch_decal(helmet_shell_sdf, horig, lambda u, v: sph_dir(u, v), np.linspace(-0.24, 0.24, 5), np.linspace(1.17, 1.33, 2), BLACK, offset=0.005, tmax=0.5))
    out.append(patch_decal(helmet_shell_sdf, horig, lambda u, v: sph_dir(u, v), np.linspace(-0.30, 0.30, 5), np.linspace(-1.02, -0.84, 2), BLACK, offset=0.005, tmax=0.5))
    out.append(patch_decal(helmet_shell_sdf, horig, lambda u, v: sph_dir(np.pi + u, v), np.linspace(-0.30, 0.30, 5), np.linspace(-0.36, -0.12, 3), BLACK, offset=0.005, tmax=0.5))
    return out


def main():
    t0 = time.time()
    parts = []
    parts.append(build_part(suit_sdf, (-0.52, -0.02, -0.64), (0.52, 0.86, 0.32), 0.0095, 2000, const(SUIT), tag="suit"))
    parts.append(build_part(helmet_shell_sdf, (-0.30, 0.68, -0.42), (0.30, 1.22, 0.30), 0.0065, 1100, helmet_region, tag="helmet"))
    parts.append(build_part(visor_sdf, (-0.27, 0.86, -0.33), (0.27, 1.06, -0.02), 0.0045, 200, const(VISOR), tag="visor"))
    parts.append(build_part(belts_sdf, (-0.30, 0.10, -0.28), (0.30, 0.74, 0.26), 0.007, 300, belts_region, tag="belts"))
    parts.append(build_part(small_parts_sdf, (-0.30, 0.15, -0.30), (0.30, 1.10, 0.40), 0.006, 420, small_parts_region, tag="small"))
    parts.append(build_part(glove_sdf, (-0.30, 0.20, -0.62), (0.30, 0.40, -0.40), 0.004, 260, const(GLOVE), tag="gloves"))
    d = decals()
    print("decals: %d parts, %d triangles" % (len(d), sum(len(x["faces"]) for x in d)))
    parts += d
    m = merge_parts(parts)
    out = os.path.join(os.path.dirname(__file__), "..", "..", "app", "src", "main", "resources", "models")
    os.makedirs(out, exist_ok=True)
    export_kmb(m, os.path.join(out, "driver.kmb"))
    print("done in %.1f s" % (time.time() - t0))


if __name__ == "__main__":
    main()
