"""Sculpts kart bodies (kart space: forward -Z, +Y up, origin between the axles on the ground) and bakes them to
app/src/main/resources/models/body<N>.kmb.  Wheels and the driver are separate meshes.

Colours are stored in the file.  PAINT has alpha 255: the game multiplies it by the player's paint colour and gives it the clear coat gloss.

Usage: python3 make_kart.py [type ...]
"""
import os
import sys
import time
import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from sdfkit import *  # noqa

PAINT, DARK, STEEL, BLACK, LIGHT, RED, WHITE, CAGE, GLASS = range(9)
# base colours (r, g, b, a). alpha 255 = tinted by the kart paint and glossy.
PALETTE = {
    PAINT: (238, 238, 238, 255),
    DARK: (40, 42, 48, 0),
    STEEL: (176, 182, 192, 0),
    BLACK: (24, 26, 30, 0),
    LIGHT: (236, 242, 248, 0),
    RED: (200, 30, 36, 0),
    WHITE: (240, 240, 236, 0),
    CAGE: (70, 74, 84, 0),
    GLASS: (150, 180, 196, 90),
}

WHEELS = {  # type: (track half, base half, front radius, rear radius, wheel width)
    0: (0.84, 0.95, 0.42, 0.46, 0.34),
    1: (0.80, 1.05, 0.36, 0.42, 0.28),
    2: (1.02, 1.00, 0.64, 0.64, 0.46),
    3: (0.82, 0.90, 0.40, 0.40, 0.32),
    4: (0.86, 1.00, 0.36, 0.52, 0.34),
    5: (0.94, 1.00, 0.52, 0.52, 0.38),
}


KSCALE = float(os.environ.get("KSCALE", "1"))   # voxel size multiplier: 1.6 for quick previews, 1 for the final bake


def finish_colors(m):
    pal = np.array([PALETTE[i] for i in range(len(PALETTE))], float)
    reg = m["region"].astype(int)
    rgba = pal[reg].copy()
    k = 0.45 + 0.55 * m["ao"]
    rgba[:, :3] = np.clip(rgba[:, :3] * k[:, None], 0, 255)
    m["rgba"] = rgba.astype(np.uint8)
    return m


def const(region):
    return lambda V: np.full(len(V), region, np.int64)


def fender(q, c, R, hwo=0.275, hwi=0.215, clearance=0.045, thick=0.07, wedge=1.05, skirt=0.02, lean=0.0):
    """Wheel guard over a wheel centred at c (q already mirrored in x): a thick arch shell with rolled edges that covers only the top
    of the tyre (+- wedge radians round the vertical, shifted by lean) so the wheel stays visible."""
    outer = cylinder(q, c, (1, 0, 0), R + clearance + thick, hwo, rr=0.06)
    inner = cylinder(q, c, (1, 0, 0), R + clearance, hwi)
    shell = smax(outer, -inner, 0.015)
    dy, dz = q[:, 1] - c[1], q[:, 2] - c[2]
    # wedge limits: keep points whose direction lies within +-wedge of straight up (rotated by lean)
    a1, a2 = lean - wedge, lean + wedge
    n1 = (np.cos(a1), np.sin(a1)); n2 = (-np.cos(a2), -np.sin(a2))
    # direction angle from vertical measured in the (y,z) plane: up = (1,0); positive towards +z
    c1 = -(dy * np.sin(a1 + np.pi / 2) * 0 + (dy * np.cos(a1 + np.pi / 2) + dz * np.sin(a1 + np.pi / 2)))
    # plane through the axle with direction a1 (keep the side where the angle is larger than a1)
    p1 = dz * np.cos(a1) - dy * np.sin(a1)          # > 0 when the point is beyond the a1 ray towards +z
    p2 = -(dz * np.cos(a2) - dy * np.sin(a2))       # > 0 when the point is before the a2 ray
    shell = smax(shell, np.maximum(-p1, -p2), 0.03)
    shell = smax(shell, -(q[:, 1] - (c[1] - skirt)), 0.03)
    return shell


# ------------------------------------------------------------------ type 0: Dune Hopper (balanced rally buggy)


def hull0(P):
    q = mirror_x(P)
    tub = rbox(q, (0, 0.62, 0.05), (0.50, 0.17, 1.02), 0.15)
    nose = capsule(q, (0, 0.62, -0.95), (0, 0.56, -1.48), 0.30, 0.17)
    cowl = ellipsoid(q, (0, 0.92, 1.02), (0.46, 0.30, 0.60))
    body = smin(smin(tub, nose, 0.20), cowl, 0.16)
    # centre spine over the hood: a slight raised ridge
    ridge = capsule(q, (0, 0.80, -1.0), (0, 0.84, -0.30), 0.10, 0.12)
    body = smin(body, ridge, 0.12)
    # cockpit carved from the top, with a soft rolled edge
    cockpit = rbox(q, (0, 1.02, 0.20), (0.34, 0.32, 0.50), 0.22)
    body = smax(body, -cockpit, 0.06)
    # thick fenders joined to the tub
    wf, wr = (0.84, 0.42, -0.95), (0.84, 0.46, 0.95)
    ff = fender(q, wf, 0.42, lean=-0.10)
    fr = fender(q, wr, 0.46, lean=0.10)
    bridge_f = capsule(q, (0.40, 0.66, -0.95), (0.66, 0.80, -0.95), 0.11)
    bridge_r = capsule(q, (0.40, 0.70, 0.95), (0.66, 0.84, 0.95), 0.12)
    # keep the wheel wells open below the fenders
    well_f = cylinder(q, wf, (1, 0, 0), 0.42 + 0.04, 0.24)
    well_r = cylinder(q, wr, (1, 0, 0), 0.46 + 0.04, 0.24)
    body = smin(body, smin(bridge_f, bridge_r, 0.05), 0.12)
    body = smax(body, -well_f, 0.03)
    body = smax(body, -well_r, 0.03)
    body = smin(body, smin(ff, fr, 0.05), 0.09)
    return body


def cage0_sdf(P):
    q = mirror_x(P)
    r = 0.034
    t = []
    t.append(capsule(q, (0.46, 0.84, 0.50), (0.40, 1.72, 0.32), r))         # main hoop leg
    t.append(capsule(P, (-0.40, 1.72, 0.32), (0.40, 1.72, 0.32), r))        # main hoop top
    t.append(capsule(q, (0.40, 1.72, 0.32), (0.34, 0.98, 1.12), r))         # rear stay
    t.append(capsule(q, (0.50, 0.86, -0.34), (0.44, 1.28, -0.26), r))       # windscreen post
    t.append(capsule(P, (-0.44, 1.28, -0.26), (0.44, 1.28, -0.26), r))      # windscreen top
    t.append(capsule(q, (0.44, 1.28, -0.26), (0.40, 1.72, 0.32), r))        # roof rail
    t.append(capsule(q, (0.46, 1.10, 0.44), (0.47, 1.06, -0.30), r * 0.8))  # side door bar
    t.append(capsule(P, (-0.43, 1.40, 0.31), (0.43, 1.40, 0.31), r * 0.8))  # cross brace
    out = t[0]
    for x in t[1:]:
        out = np.minimum(out, x)
    return out


def front_bumper0(P):
    q = mirror_x(P)
    bar = capsule(P, (-0.58, 0.58, -1.66), (0.58, 0.58, -1.66), 0.045)
    arm = capsule(q, (0.58, 0.58, -1.66), (0.40, 0.64, -1.30), 0.04)
    low = capsule(P, (-0.40, 0.40, -1.58), (0.40, 0.40, -1.58), 0.035)
    return np.minimum(np.minimum(bar, arm), low)


def exhaust0(P):
    q = mirror_x(P)
    pipe = capsule(q, (0.24, 0.80, 1.44), (0.24, 0.735, 1.90), 0.072, 0.082)
    tip = cylinder(q, (0.24, 0.73, 1.95), (0, 0.03, 1.0), 0.086, 0.035)
    return smin(pipe, tip, 0.025)


def lamps0(P):
    q = mirror_x(P)
    housing = cylinder(q, (0.30, 0.66, -1.40), (0, 0.15, 1), 0.105, 0.05)
    return housing


def lens0(P):
    q = mirror_x(P)
    return ellipsoid(q, (0.30, 0.665, -1.455), (0.085, 0.085, 0.03))


def taillamps0(P):
    q = mirror_x(P)
    return rbox(q, (0.36, 0.86, 1.60), (0.07, 0.035, 0.02), 0.012)


def seat0(P):
    back = rbox(P, (0, 1.00, 0.56), (0.25, 0.30, 0.07), 0.06)
    base = rbox(P, (0, 0.82, 0.25), (0.25, 0.05, 0.28), 0.05)
    q = mirror_x(P)
    bolster = rbox(q, (0.27, 0.95, 0.52), (0.035, 0.24, 0.07), 0.03)
    head = rbox(P, (0, 1.36, 0.58), (0.14, 0.10, 0.06), 0.05)
    return np.minimum(np.minimum(back, base), np.minimum(bolster, head))


def steering0(P):
    axis = np.array([0.0, 0.5, 0.867])
    ring = torus(P, (0, 1.10, -0.32), axis, 0.15, 0.024)
    hub = rbox(local(P, (0, 1.10, -0.32), 1.05), (0, 0, 0), (0.06, 0.03, 0.045), 0.02)
    col = capsule(P, (0, 1.08, -0.34), (0, 0.80, -0.62), 0.03)
    q = mirror_x(P)
    grip = ellipsoid(q, (0.15 * 1.0, 1.10 + 0.0, -0.32), (0.04, 0.04, 0.075))
    dash = rbox(P, (0, 0.88, -0.66), (0.32, 0.07, 0.10), 0.05)
    return np.minimum(np.minimum(ring, hub), np.minimum(np.minimum(col, grip), dash))


def skid0(P):
    return rbox(P, (0, 0.46, 0.0), (0.40, 0.025, 0.82), 0.03)


def build_decals0(f):
    out = []
    # centre racing stripe over the hood, cockpit rim and engine cowl (cast from above onto the hull)
    def stripe(zs, half):
        O = np.zeros((len(zs), 3, 3)); D = np.zeros_like(O)
        for j, z in enumerate(zs):
            for i, x in enumerate((-half, 0.0, half)):
                O[j, i] = (x, 0.30, z); D[j, i] = (0, 1, 0)
        return grid_decal(f, O, D, 2, len(zs) - 1, WHITE, offset=0.004, tmax=1.5)
    out.append(stripe(np.linspace(-1.42, -0.60, 10), 0.075))
    out.append(stripe(np.linspace(0.62, 1.60, 10), 0.075))
    # number roundels on both sides of the tub
    for sd in (-1, 1):
        O = np.zeros((5, 5, 3)); D = np.zeros_like(O)
        for j, y in enumerate(np.linspace(0.54, 0.74, 5)):
            for i, z in enumerate(np.linspace(-0.12, 0.28, 5)):
                O[j, i] = (0.0, y, z); D[j, i] = (sd, 0, 0)
        out.append(grid_decal(f, O, D, 4, 4, WHITE, offset=0.004, tmax=1.5))
    return out


def build0():
    t0 = time.time()
    parts = []
    parts.append(build_part(hull0, (-1.25, 0.25, -1.65), (1.25, 1.62, 2.05), 0.030 * KSCALE, 3600, const(PAINT), tag="hull", ao_strength=0.7))
    parts.append(build_part(cage0_sdf, (-0.60, 0.80, -0.45), (0.60, 1.80, 1.20), 0.012, 600, const(CAGE), tag="cage"))
    parts.append(build_part(front_bumper0, (-0.70, 0.30, -1.75), (0.70, 0.75, -1.20), 0.012, 260, const(STEEL), tag="bumper"))
    parts.append(build_part(exhaust0, (-0.40, 0.55, 1.30), (0.40, 0.95, 2.05), 0.012, 260, const(STEEL), tag="exhaust"))
    parts.append(build_part(lamps0, (-0.50, 0.45, -1.55), (0.50, 0.90, -1.25), 0.01, 200, const(BLACK), tag="lamp housings"))
    parts.append(build_part(lens0, (-0.50, 0.45, -1.55), (0.50, 0.90, -1.35), 0.008, 140, const(LIGHT), tag="lenses"))
    parts.append(build_part(taillamps0, (-0.50, 0.75, 1.50), (0.50, 0.95, 1.70), 0.008, 100, const(RED), tag="tail lamps"))
    parts.append(build_part(seat0, (-0.35, 0.70, 0.10), (0.35, 1.55, 0.75), 0.012, 420, const(DARK), tag="seat"))
    parts.append(build_part(steering0, (-0.50, 0.70, -0.85), (0.50, 1.40, -0.05), 0.008, 420, const(BLACK), tag="steering"))
    parts.append(build_part(skid0, (-0.50, 0.38, -1.10), (0.50, 0.52, 1.20), 0.012, 100, const(DARK), tag="skid plate"))
    d = build_decals0(hull0)
    print("decals: %d parts, %d triangles" % (len(d), sum(len(x["faces"]) for x in d)))
    parts += d
    m = finish_colors(merge_parts(parts))
    out = os.path.join(os.path.dirname(__file__), "..", "..", "app", "src", "main", "resources", "models")
    os.makedirs(out, exist_ok=True)
    export_kmb(m, os.path.join(out, "body0.kmb"))
    print("kart 0 done in %.1f s" % (time.time() - t0))


# ------------------------------------------------------------------ shared parts for the other types

SEATS = {0: (0.84, 0.20), 1: (0.62, 0.25), 2: (1.50, 0.38), 3: (0.84, 0.30), 4: (0.90, 0.45), 5: (1.00, 0.30)}


def wheel_centres(t):
    tx, bh, rf, rr, ww = WHEELS[t]
    return (tx, rf, -bh), (tx, rr, bh), rf, rr


def seat_sdf(t):
    sy, sz = SEATS[t]
    def f(P):
        q = mirror_x(P)
        back = rbox(P, (0, sy + 0.16, sz + 0.36), (0.25, 0.30, 0.07), 0.06)
        base = rbox(P, (0, sy - 0.02, sz + 0.05), (0.25, 0.05, 0.28), 0.05)
        bolster = rbox(q, (0.27, sy + 0.11, sz + 0.32), (0.035, 0.24, 0.07), 0.03)
        head = rbox(P, (0, sy + 0.52, sz + 0.38), (0.14, 0.10, 0.06), 0.05)
        return np.minimum(np.minimum(back, base), np.minimum(bolster, head))
    return f


def steering_sdf(t):
    sy, sz = SEATS[t]
    wc = (0, sy + 0.26, sz - 0.52)
    def f(P):
        axis = np.array([0.0, 0.5, 0.867])
        ring = torus(P, wc, axis, 0.15, 0.024)
        hub = rbox(local(P, wc, 1.05), (0, 0, 0), (0.06, 0.03, 0.045), 0.02)
        col = capsule(P, (0, wc[1] - 0.02, wc[2] - 0.02), (0, sy - 0.04, sz - 0.82), 0.03)
        q = mirror_x(P)
        grip = ellipsoid(q, (0.15, wc[1], wc[2]), (0.04, 0.04, 0.075))
        dash = rbox(P, (0, sy + 0.04, sz - 0.86), (0.32, 0.07, 0.10), 0.05)
        return np.minimum(np.minimum(ring, hub), np.minimum(np.minimum(col, grip), dash))
    return f


def tubes_sdf(segs, r=0.034):
    def f(P):
        q = mirror_x(P)
        out = None
        for a, b, rr in segs:
            d = capsule(q, a, b, rr if rr else r)
            out = d if out is None else np.minimum(out, d)
        return out
    return f


def common_parts(t, parts, zmin, zmax, ymax):
    """Seat and steering wheel (every type)."""
    sy, sz = SEATS[t]
    parts.append(build_part(seat_sdf(t), (-0.35, sy - 0.15, sz - 0.15), (0.35, sy + 0.75, sz + 0.55), 0.012, 380, const(DARK), tag="seat"))
    parts.append(build_part(steering_sdf(t), (-0.50, sy - 0.15, sz - 1.00), (0.50, sy + 0.55, sz - 0.05), 0.008, 420, const(BLACK), tag="steering"))


def top_stripe_decal(f, z0, z1, y0, half=0.075, n=10, z_skip=None):
    zs = np.linspace(z0, z1, n)
    O = np.zeros((len(zs), 3, 3)); D = np.zeros_like(O)
    for j, z in enumerate(zs):
        for i, x in enumerate((-half, 0.0, half)):
            O[j, i] = (x, y0, z); D[j, i] = (0, 1, 0)
    return grid_decal(f, O, D, 2, len(zs) - 1, WHITE, offset=0.004, tmax=2.5)


def roundel_decals(f, y0, y1, z0, z1):
    out = []
    for sd in (-1, 1):
        O = np.zeros((5, 5, 3)); D = np.zeros_like(O)
        for j, y in enumerate(np.linspace(y0, y1, 5)):
            for i, z in enumerate(np.linspace(z0, z1, 5)):
                O[j, i] = (0.0, y, z); D[j, i] = (sd, 0, 0)
        out.append(grid_decal(f, O, D, 4, 4, WHITE, offset=0.004, tmax=2.0))
    return out


def bake(t, parts):
    m = finish_colors(merge_parts(parts))
    out = os.path.join(os.path.dirname(__file__), "..", "..", "app", "src", "main", "resources", "models")
    os.makedirs(out, exist_ok=True)
    export_kmb(m, os.path.join(out, "body%d.kmb" % t))


def lamp_parts(parts, pos, r=0.10, facing=(0, 0.1, 1), tag="lamps"):
    """Headlamp pair at pos (x>0, y, z): black housing + glass lens (front of the kart is -Z)."""
    def housing(P):
        q = mirror_x(P)
        return cylinder(q, pos, facing, r, 0.05)
    def lens(P):
        q = mirror_x(P)
        return ellipsoid(q, (pos[0], pos[1] + 0.005, pos[2] - 0.055), (r * 0.82, r * 0.82, 0.03))
    bmin = (-pos[0] - 0.25, pos[1] - 0.25, pos[2] - 0.25); bmax = (pos[0] + 0.25, pos[1] + 0.25, pos[2] + 0.12)
    parts.append(build_part(housing, bmin, bmax, 0.01, 200, const(BLACK), tag=tag + " housings"))
    parts.append(build_part(lens, bmin, bmax, 0.008, 140, const(LIGHT), tag=tag + " lenses"))


# ------------------------------------------------------------------ type 1: Sand Viper (low open wheel racer)


def hull1(P):
    q = mirror_x(P)
    mono = smin(capsule(q, (0, 0.50, -1.70), (0, 0.62, 0.60), 0.20, 0.32), ellipsoid(q, (0, 0.60, 0.30), (0.36, 0.28, 0.80)), 0.2)
    nose = capsule(q, (0, 0.46, -1.70), (0, 0.44, -1.98), 0.11, 0.05)
    pods = rbox(q, (0.50, 0.52, 0.18), (0.15, 0.14, 0.60), 0.10)
    airbox = ellipsoid(q, (0, 0.95, 0.85), (0.20, 0.30, 0.55))
    tail = capsule(q, (0, 0.62, 0.80), (0, 0.60, 1.62), 0.26, 0.10)
    body = smin(smin(smin(smin(mono, nose, 0.12), pods, 0.12), airbox, 0.14), tail, 0.15)
    cockpit = rbox(q, (0, 0.86, 0.25), (0.24, 0.30, 0.46), 0.2)
    body = smax(body, -cockpit, 0.05)
    wf, wr = (0.80, 0.36, -1.05), (0.80, 0.42, 1.05)
    ff = fender(q, wf, 0.36, hwo=0.22, hwi=0.175, clearance=0.04, thick=0.06, wedge=0.95, lean=-0.12)
    fr = fender(q, wr, 0.42, hwo=0.24, hwi=0.19, clearance=0.04, thick=0.065, wedge=0.95, lean=0.12)
    bf = capsule(q, (0.34, 0.52, -1.05), (0.62, 0.62, -1.05), 0.09)
    br = capsule(q, (0.34, 0.60, 1.05), (0.62, 0.70, 1.05), 0.10)
    body = smin(body, smin(bf, br, 0.05), 0.1)
    body = smax(body, -cylinder(q, wf, (1, 0, 0), 0.36 + 0.04, 0.20), 0.03)
    body = smax(body, -cylinder(q, wr, (1, 0, 0), 0.42 + 0.04, 0.22), 0.03)
    return smin(body, smin(ff, fr, 0.05), 0.08)


def wings1(P):
    q = mirror_x(P)
    fw = rbox(P, (0, 0.34, -1.95), (0.95, 0.02, 0.16), 0.015)
    fe = rbox(q, (0.95, 0.42, -1.95), (0.02, 0.09, 0.17), 0.012)
    fl = capsule(P, (-0.95, 0.30, -1.80), (0.95, 0.30, -1.80), 0.02)
    rw = rbox(P, (0, 1.22, 1.78), (0.72, 0.025, 0.19), 0.015)
    re = rbox(q, (0.72, 1.12, 1.78), (0.02, 0.13, 0.20), 0.012)
    st = capsule(q, (0.12, 0.78, 1.30), (0.12, 1.20, 1.74), 0.025)
    return np.minimum(np.minimum(np.minimum(fw, fe), np.minimum(fl, rw)), np.minimum(re, st))


def hoop1(P):
    q = mirror_x(P)
    return np.minimum(capsule(q, (0.24, 0.90, 0.62), (0.18, 1.34, 0.50), 0.03), capsule(P, (-0.18, 1.34, 0.50), (0.18, 1.34, 0.50), 0.03))


def exhaust1(P):
    q = mirror_x(P)
    return np.minimum(capsule(q, (0.12, 0.70, 1.45), (0.12, 0.66, 1.92), 0.06), cylinder(q, (0.12, 0.66, 1.91), (0, 0.05, 1), 0.07, 0.04))


def build1():
    parts = []
    parts.append(build_part(hull1, (-1.05, 0.25, -2.05), (1.05, 1.35, 1.75), 0.028 * KSCALE, 3800, const(PAINT), tag="hull", ao_strength=0.7))
    parts.append(build_part(wings1, (-1.10, 0.22, -2.15), (1.10, 1.40, 2.0), 0.012, 700, const(PAINT), tag="wings"))
    parts.append(build_part(hoop1, (-0.40, 0.85, 0.40), (0.40, 1.45, 0.75), 0.01, 200, const(CAGE), tag="hoop"))
    parts.append(build_part(exhaust1, (-0.30, 0.55, 1.35), (0.30, 0.80, 2.0), 0.01, 200, const(STEEL), tag="exhaust"))
    lamp_parts(parts, (0.16, 0.52, -1.78), r=0.06)
    common_parts(1, parts, -2.1, 2.0, 1.4)
    parts.append(top_stripe_decal(hull1, -1.9, -0.30, 0.2, half=0.06, n=10))
    parts.append(top_stripe_decal(hull1, 1.0, 1.6, 0.2, half=0.06, n=5))
    parts += roundel_decals(hull1, 0.50, 0.66, 0.0, 0.38)
    bake(1, parts)


# ------------------------------------------------------------------ type 2: Rock Crusher (monster truck)


def hull2(P):
    q = mirror_x(P)
    frame = np.minimum(capsule(q, (0.48, 1.00, -1.55), (0.48, 1.00, 1.55), 0.07), capsule(P, (-0.48, 1.05, -0.6), (0.48, 1.05, -0.6), 0.06))
    hood = rbox(q, (0, 1.62, -1.00), (0.58, 0.26, 0.62), 0.16)
    tub = rbox(q, (0, 1.38, 0.50), (0.60, 0.24, 1.10), 0.16)
    body = smin(hood, tub, 0.16)
    cockpit = rbox(q, (0, 1.80, 0.38), (0.42, 0.40, 0.58), 0.22)
    body = smax(body, -cockpit, 0.06)
    wf, wr = (1.02, 0.64, -1.00), (1.02, 0.64, 1.00)
    ff = fender(q, wf, 0.64, hwo=0.33, hwi=0.27, clearance=0.06, thick=0.08, wedge=1.05, lean=-0.05)
    fr = fender(q, wr, 0.64, hwo=0.33, hwi=0.27, clearance=0.06, thick=0.08, wedge=1.05, lean=0.05)
    bf = capsule(q, (0.55, 1.45, -1.00), (0.95, 1.40, -1.00), 0.13)
    br = capsule(q, (0.55, 1.45, 1.00), (0.95, 1.40, 1.00), 0.13)
    body = smin(body, smin(bf, br, 0.05), 0.1)
    body = smax(body, -cylinder(q, wf, (1, 0, 0), 0.64 + 0.06, 0.30), 0.04)
    body = smax(body, -cylinder(q, wr, (1, 0, 0), 0.64 + 0.06, 0.30), 0.04)
    body = smin(body, smin(ff, fr, 0.05), 0.09)
    return smin(body, frame, 0.06)


def cage2(P):
    q = mirror_x(P)
    r = 0.045
    segs = [((0.55, 1.78, 0.78), (0.50, 2.70, 0.55)), ((0.50, 2.70, 0.55), (0.44, 2.70, -0.30)), ((0.55, 1.78, -0.05), (0.46, 2.50, -0.28)),
            ((0.50, 2.70, 0.55), (0.46, 1.80, 1.30)), ((0.44, 2.70, -0.30), (0.46, 2.50, -0.28))]
    out = None
    for a, b in segs:
        d = capsule(q, a, b, r)
        out = d if out is None else np.minimum(out, d)
    out = np.minimum(out, capsule(P, (-0.50, 2.70, 0.55), (0.50, 2.70, 0.55), r))
    out = np.minimum(out, capsule(P, (-0.44, 2.70, -0.30), (0.44, 2.70, -0.30), r))
    return out


def bar2(P):
    q = mirror_x(P)
    bull = np.minimum(capsule(P, (-0.70, 1.28, -1.78), (0.70, 1.28, -1.78), 0.06), capsule(q, (0.70, 1.28, -1.78), (0.52, 1.50, -1.50), 0.05))
    light = capsule(P, (-0.55, 1.98, -1.30), (0.55, 1.98, -1.30), 0.045)
    return np.minimum(bull, light)


def build2():
    parts = []
    parts.append(build_part(hull2, (-1.45, 0.50, -1.80), (1.45, 2.35, 1.80), 0.032 * KSCALE, 4200, const(PAINT), tag="hull", ao_strength=0.7))
    parts.append(build_part(cage2, (-0.70, 1.70, -0.50), (0.70, 2.85, 1.45), 0.014, 500, const(CAGE), tag="cage"))
    parts.append(build_part(bar2, (-0.90, 1.15, -1.95), (0.90, 2.10, -1.15), 0.012, 400, const(STEEL), tag="bull bar"))
    lamp_parts(parts, (0.40, 1.50, -1.58), r=0.12)
    common_parts(2, parts, -1.8, 1.8, 2.8)
    parts.append(top_stripe_decal(hull2, -1.55, -0.45, 1.0, half=0.09, n=8))
    parts += roundel_decals(hull2, 1.30, 1.50, 0.35, 0.75)
    bake(2, parts)


# ------------------------------------------------------------------ type 3: Wave Runner (sleek enclosed hull)


def hull3(P):
    q = mirror_x(P)
    hullm = ellipsoid(q, (0, 0.72, 0.0), (0.64, 0.34, 1.60))
    nose = capsule(q, (0, 0.62, -1.00), (0, 0.55, -1.62), 0.30, 0.12)
    tail = capsule(q, (0, 0.80, 0.80), (0, 0.84, 1.55), 0.30, 0.16)
    body = smin(smin(hullm, nose, 0.2), tail, 0.15)
    cockpit = rbox(q, (0, 1.02, 0.30), (0.34, 0.30, 0.55), 0.24)
    body = smax(body, -cockpit, 0.06)
    wf, wr = (0.82, 0.40, -0.90), (0.82, 0.40, 0.90)
    ff = fender(q, wf, 0.40, hwo=0.26, hwi=0.20, clearance=0.045, thick=0.07, wedge=0.95, lean=-0.1)
    fr = fender(q, wr, 0.40, hwo=0.26, hwi=0.20, clearance=0.045, thick=0.07, wedge=0.95, lean=0.1)
    bf = capsule(q, (0.46, 0.62, -0.90), (0.70, 0.72, -0.90), 0.12)
    br = capsule(q, (0.46, 0.62, 0.90), (0.70, 0.72, 0.90), 0.12)
    body = smin(body, smin(bf, br, 0.05), 0.1)
    body = smax(body, -cylinder(q, wf, (1, 0, 0), 0.40 + 0.04, 0.24), 0.03)
    body = smax(body, -cylinder(q, wr, (1, 0, 0), 0.40 + 0.04, 0.24), 0.03)
    return smin(body, smin(ff, fr, 0.05), 0.08)


def fin3(P):
    q = mirror_x(P)
    fin = rbox(P, (0, 1.12, 1.50), (0.02, 0.22, 0.20), 0.015)
    wing = rbox(P, (0, 1.00, 1.60), (0.60, 0.015, 0.14), 0.012)
    strut = capsule(q, (0.30, 0.82, 1.35), (0.30, 1.00, 1.58), 0.025)
    return np.minimum(np.minimum(fin, wing), strut)


def screen3(P):
    shell = ellipsoid(P, (0, 1.00, -0.42), (0.36, 0.22, 0.30))
    thin = np.abs(shell) - 0.012
    return np.maximum(thin, np.maximum(-(P[:, 1] - 0.93), P[:, 2] - (-0.25)))


def build3():
    parts = []
    parts.append(build_part(hull3, (-1.15, 0.30, -1.75), (1.15, 1.50, 1.70), 0.028 * KSCALE, 3800, const(PAINT), tag="hull", ao_strength=0.7))
    parts.append(build_part(fin3, (-0.80, 0.75, 1.15), (0.80, 1.42, 1.80), 0.010, 300, const(PAINT), tag="fin"))
    parts.append(build_part(screen3, (-0.50, 0.88, -0.80), (0.50, 1.30, -0.15), 0.010, 260, const(GLASS), tag="screen"))
    lamp_parts(parts, (0.28, 0.62, -1.50), r=0.08)
    common_parts(3, parts, -1.75, 1.7, 1.5)
    parts.append(top_stripe_decal(hull3, -1.55, -0.50, 0.2, half=0.07, n=9))
    parts.append(top_stripe_decal(hull3, 0.95, 1.50, 0.2, half=0.07, n=6))
    parts += roundel_decals(hull3, 0.62, 0.80, 0.05, 0.45)
    bake(3, parts)


# ------------------------------------------------------------------ type 4: Lava Rod (hot rod)


def hull4(P):
    q = mirror_x(P)
    hood = capsule(q, (0, 0.82, -1.50), (0, 0.86, -0.10), 0.26, 0.32)
    tubb = rbox(q, (0, 0.80, 0.55), (0.42, 0.22, 0.85), 0.16)
    body = smin(hood, tubb, 0.2)
    cockpit = rbox(q, (0, 1.08, 0.45), (0.32, 0.34, 0.52), 0.22)
    body = smax(body, -cockpit, 0.06)
    wf, wr = (0.86, 0.36, -1.00), (0.86, 0.52, 1.00)
    ff = fender(q, wf, 0.36, hwo=0.22, hwi=0.17, clearance=0.04, thick=0.06, wedge=0.85, lean=-0.12)
    fr = fender(q, wr, 0.52, hwo=0.31, hwi=0.25, clearance=0.05, thick=0.08, wedge=1.00, lean=0.12)
    bf = capsule(q, (0.34, 0.60, -1.00), (0.66, 0.68, -1.00), 0.09)
    br = capsule(q, (0.40, 0.76, 1.00), (0.72, 0.84, 1.00), 0.14)
    body = smin(body, smin(bf, br, 0.05), 0.1)
    body = smax(body, -cylinder(q, wf, (1, 0, 0), 0.36 + 0.04, 0.20), 0.03)
    body = smax(body, -cylinder(q, wr, (1, 0, 0), 0.52 + 0.05, 0.28), 0.03)
    return smin(body, smin(ff, fr, 0.05), 0.08)


def engine4(P):
    blower = ellipsoid(P, (0, 1.20, -0.55), (0.26, 0.16, 0.34))
    scoop = rbox(P, (0, 1.38, -0.55), (0.15, 0.10, 0.20), 0.07)
    q = mirror_x(P)
    pipes = np.minimum(capsule(q, (0.45, 0.62, -0.95), (0.45, 0.64, 0.55), 0.05), capsule(q, (0.45, 0.64, 0.55), (0.46, 0.70, 0.85), 0.05))
    return np.minimum(np.minimum(blower, scoop), pipes)


def bumper4(P):
    q = mirror_x(P)
    return np.minimum(capsule(P, (-0.55, 0.52, -1.82), (0.55, 0.52, -1.82), 0.045), capsule(q, (0.55, 0.52, -1.82), (0.34, 0.62, -1.50), 0.04))


def hoop4(P):
    q = mirror_x(P)
    return np.minimum(capsule(q, (0.34, 0.95, 0.95), (0.28, 1.65, 0.80), 0.035), capsule(P, (-0.28, 1.65, 0.80), (0.28, 1.65, 0.80), 0.035))


def build4():
    parts = []
    parts.append(build_part(hull4, (-1.20, 0.30, -1.65), (1.20, 1.50, 1.75), 0.028 * KSCALE, 3800, const(PAINT), tag="hull", ao_strength=0.7))
    parts.append(build_part(engine4, (-0.60, 0.50, -1.00), (0.60, 1.60, 1.00), 0.012, 500, const(STEEL), tag="engine"))
    parts.append(build_part(bumper4, (-0.70, 0.40, -1.95), (0.70, 0.75, -1.40), 0.012, 220, const(STEEL), tag="bumper"))
    parts.append(build_part(hoop4, (-0.45, 0.85, 0.65), (0.45, 1.75, 1.10), 0.012, 240, const(CAGE), tag="hoop"))
    lamp_parts(parts, (0.34, 0.80, -1.52), r=0.09)
    common_parts(4, parts, -2.0, 1.7, 1.8)
    parts.append(top_stripe_decal(hull4, -1.45, -0.10, 0.4, half=0.07, n=9))
    parts += roundel_decals(hull4, 0.66, 0.86, 0.40, 0.80)
    bake(4, parts)


# ------------------------------------------------------------------ type 5: Jungle Rover (jeep)


def hull5(P):
    q = mirror_x(P)
    hood = rbox(q, (0, 1.05, -1.05), (0.50, 0.22, 0.62), 0.14)
    tub = rbox(q, (0, 0.98, 0.45), (0.58, 0.28, 1.12), 0.14)
    cowl = rbox(q, (0, 1.20, -0.35), (0.55, 0.12, 0.12), 0.08)
    body = smin(smin(hood, tub, 0.14), cowl, 0.1)
    cockpit = rbox(q, (0, 1.30, 0.28), (0.40, 0.34, 0.60), 0.18)
    body = smax(body, -cockpit, 0.05)
    wf, wr = (0.94, 0.52, -1.00), (0.94, 0.52, 1.00)
    ff = fender(q, wf, 0.52, hwo=0.31, hwi=0.25, clearance=0.05, thick=0.075, wedge=1.00, lean=-0.05)
    fr = fender(q, wr, 0.52, hwo=0.31, hwi=0.25, clearance=0.05, thick=0.075, wedge=1.00, lean=0.05)
    bf = capsule(q, (0.46, 0.96, -1.00), (0.80, 0.98, -1.00), 0.11)
    br = capsule(q, (0.46, 0.96, 1.00), (0.80, 0.98, 1.00), 0.11)
    body = smin(body, smin(bf, br, 0.05), 0.1)
    body = smax(body, -cylinder(q, wf, (1, 0, 0), 0.52 + 0.05, 0.27), 0.03)
    body = smax(body, -cylinder(q, wr, (1, 0, 0), 0.52 + 0.05, 0.27), 0.03)
    return smin(body, smin(ff, fr, 0.05), 0.08)


def rollbar5(P):
    q = mirror_x(P)
    r = 0.04
    segs = [((0.50, 1.20, 0.62), (0.44, 2.30, 0.50)), ((0.44, 2.30, 0.50), (0.44, 2.30, -0.10)), ((0.50, 1.18, -0.20), (0.44, 2.00, -0.12)),
            ((0.44, 2.30, 0.50), (0.40, 1.20, 1.45))]
    out = None
    for a, b in segs:
        d = capsule(q, a, b, r)
        out = d if out is None else np.minimum(out, d)
    out = np.minimum(out, capsule(P, (-0.44, 2.30, 0.50), (0.44, 2.30, 0.50), r))
    out = np.minimum(out, capsule(P, (-0.44, 2.30, -0.10), (0.44, 2.30, -0.10), r))
    return out


def grille5(P):
    q = mirror_x(P)
    frame = rbox(P, (0, 1.02, -1.70), (0.34, 0.15, 0.03), 0.03)
    bumper = capsule(P, (-0.62, 0.62, -1.76), (0.62, 0.62, -1.76), 0.06)
    spare = cylinder(P, (0, 1.10, 1.78), (0, 0, 1), 0.38, 0.12, rr=0.05)
    return np.minimum(np.minimum(frame, bumper), spare)


def build5():
    parts = []
    parts.append(build_part(hull5, (-1.30, 0.40, -1.75), (1.30, 1.60, 1.80), 0.030 * KSCALE, 4000, const(PAINT), tag="hull", ao_strength=0.7))
    parts.append(build_part(rollbar5, (-0.65, 1.10, -0.35), (0.65, 2.45, 1.55), 0.014, 480, const(CAGE), tag="roll bar"))
    parts.append(build_part(grille5, (-0.80, 0.50, -1.95), (0.80, 1.60, 1.95), 0.014, 600, const(DARK), tag="grille bumper spare"))
    lamp_parts(parts, (0.40, 1.04, -1.70), r=0.10)
    common_parts(5, parts, -1.8, 1.9, 2.6)
    parts.append(top_stripe_decal(hull5, -1.55, -0.55, 0.9, half=0.08, n=8))
    parts += roundel_decals(hull5, 0.90, 1.08, 0.30, 0.70)
    bake(5, parts)


BUILDERS = {0: build0, 1: build1, 2: build2, 3: build3, 4: build4, 5: build5}

if __name__ == "__main__":
    types = [int(a) for a in sys.argv[1:]] or [0]
    for t in types:
        BUILDERS[t]()
