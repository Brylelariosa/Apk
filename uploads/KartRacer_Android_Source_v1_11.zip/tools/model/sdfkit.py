"""
Small 3D modelling toolkit used to author the kart and driver models of Kart Racer.

Models are sculpted as signed distance fields (SDF) with smooth boolean operations (blends, carved cut-outs), turned into
a triangle mesh with marching cubes, simplified with quadric error metrics, and baked with ambient occlusion.  The result is
written to a compact binary file (.kmb) that the game loads (see BakedModels.java).

Coordinates are metres, +Y up, forward is -Z (the same as the game).
"""
import heapq
import struct
import numpy as np
from scipy import sparse
from skimage import measure

# ------------------------------------------------------------------ primitives (p is an (N,3) array of points)


def length(v):
    return np.sqrt((v * v).sum(axis=-1))


def sphere(p, c, r):
    return length(p - np.asarray(c, float)) - r


def ellipsoid(p, c, r):
    r = np.asarray(r, float)
    q = (p - np.asarray(c, float)) / r
    k0 = length(q)
    k1 = length(q / r)
    return k0 * (k0 - 1.0) / np.maximum(k1, 1e-9)


def rbox(p, c, h, r=0.0):
    """Rounded box: centre c, half sizes h (before rounding), corner radius r."""
    q = np.abs(p - np.asarray(c, float)) - np.asarray(h, float) + r
    return length(np.maximum(q, 0.0)) + np.minimum(np.max(q, axis=1), 0.0) - r


def capsule(p, a, b, ra, rb=None):
    """Round cone / capsule from a to b with radius ra at a and rb at b."""
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    rb = ra if rb is None else rb
    ba = b - a
    pa = p - a
    h = np.clip((pa @ ba) / (ba @ ba), 0.0, 1.0)
    r = ra + (rb - ra) * h
    return length(pa - np.outer(h, ba)) - r


def cylinder(p, c, axis, r, hh, rr=0.0):
    """Cylinder with centre c, unit axis, radius r and half length hh (rounded edges rr)."""
    axis = np.asarray(axis, float)
    axis = axis / np.linalg.norm(axis)
    d = p - np.asarray(c, float)
    along = d @ axis
    radial = length(d - np.outer(along, axis))
    q = np.stack([radial - r + rr, np.abs(along) - hh + rr], axis=1)
    return np.minimum(np.maximum(q[:, 0], q[:, 1]), 0.0) + length(np.maximum(q, 0.0)) - rr


def torus(p, c, axis, R, r):
    axis = np.asarray(axis, float)
    axis = axis / np.linalg.norm(axis)
    d = p - np.asarray(c, float)
    along = d @ axis
    radial = length(d - np.outer(along, axis))
    return np.sqrt((radial - R) ** 2 + along ** 2) - r


def plane(p, n, d):
    n = np.asarray(n, float)
    n = n / np.linalg.norm(n)
    return p @ n - d


def smin(a, b, k):
    if k <= 1e-9:
        return np.minimum(a, b)
    h = np.clip(0.5 + 0.5 * (b - a) / k, 0.0, 1.0)
    return b * (1 - h) + a * h - k * h * (1 - h)


def smax(a, b, k):
    return -smin(-a, -b, k)


def mirror_x(p):
    q = p.copy()
    q[:, 0] = np.abs(q[:, 0])
    return q


def rot_matrix(rx=0.0, ry=0.0, rz=0.0):
    cx, sx = np.cos(rx), np.sin(rx)
    cy, sy = np.cos(ry), np.sin(ry)
    cz, sz = np.cos(rz), np.sin(rz)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def local(p, c, rx=0.0, ry=0.0, rz=0.0):
    """Points expressed in a frame centred at c and rotated by the given angles (so a primitive can be rotated)."""
    R = rot_matrix(rx, ry, rz)
    return (p - np.asarray(c, float)) @ R


# ------------------------------------------------------------------ meshing


def sample_grid(f, bmin, bmax, h, chunk=250000):
    bmin = np.asarray(bmin, float)
    bmax = np.asarray(bmax, float)
    xs = np.arange(bmin[0], bmax[0] + h * 0.5, h)
    ys = np.arange(bmin[1], bmax[1] + h * 0.5, h)
    zs = np.arange(bmin[2], bmax[2] + h * 0.5, h)
    X, Y, Z = np.meshgrid(xs, ys, zs, indexing="ij")
    P = np.stack([X.ravel(), Y.ravel(), Z.ravel()], axis=1)
    out = np.empty(len(P))
    for i in range(0, len(P), chunk):
        out[i:i + chunk] = f(P[i:i + chunk])
    return out.reshape(X.shape)


def mesh_sdf(f, bmin, bmax, h):
    V = sample_grid(f, bmin, bmax, h)
    # pad with positive values so the surface is closed at the box boundary
    V = np.pad(V, 1, constant_values=1.0)
    verts, faces, _, _ = measure.marching_cubes(V, 0.0, spacing=(h, h, h))
    verts = verts + np.asarray(bmin, float) - h
    return verts, faces.astype(np.int64)


# ------------------------------------------------------------------ quadric error simplification


def simplify(verts, faces, target_faces, flip_dot=0.15):
    verts = verts.copy()
    nv = len(verts)
    faces = [tuple(f) for f in faces.tolist()]
    alive_f = [True] * len(faces)
    vfaces = [set() for _ in range(nv)]
    for fi, f in enumerate(faces):
        for v in f:
            vfaces[v].add(fi)
    Q = np.zeros((nv, 4, 4))

    def plane_of(f):
        a, b, c = verts[f[0]], verts[f[1]], verts[f[2]]
        n = np.cross(b - a, c - a)
        ar = np.linalg.norm(n)
        if ar < 1e-14:
            return None, 0.0
        n = n / ar
        return np.append(n, -n @ a), ar * 0.5

    for fi, f in enumerate(faces):
        pl, ar = plane_of(f)
        if pl is None:
            continue
        K = np.outer(pl, pl) * ar
        for v in f:
            Q[v] += K

    # keep open boundaries (decals) in place: heavy quadrics on planes through each boundary edge, perpendicular to its face
    ecount = {}
    for fi, f in enumerate(faces):
        for i in range(3):
            a, b = f[i], f[(i + 1) % 3]
            ecount.setdefault((min(a, b), max(a, b)), []).append(fi)
    for (a, b), fl in ecount.items():
        if len(fl) != 1:
            continue
        pl, ar = plane_of(faces[fl[0]])
        if pl is None:
            continue
        e = verts[b] - verts[a]
        el = np.linalg.norm(e)
        if el < 1e-12:
            continue
        m = np.cross(e / el, pl[:3])
        ml = np.linalg.norm(m)
        if ml < 1e-9:
            continue
        m = m / ml
        pp = np.append(m, -m @ verts[a])
        K = np.outer(pp, pp) * (1500.0 * el * el)
        Q[a] += K
        Q[b] += K

    nbr = [set() for _ in range(nv)]
    for f in faces:
        for i in range(3):
            a, b = f[i], f[(i + 1) % 3]
            nbr[a].add(b)
            nbr[b].add(a)
    ver = [0] * nv
    alive_v = [True] * nv

    def best_pos(a, b):
        K = Q[a] + Q[b]
        A = K.copy()
        A[3, :] = [0, 0, 0, 1]
        try:
            if abs(np.linalg.det(A)) > 1e-12:
                x = np.linalg.solve(A, np.array([0, 0, 0, 1.0]))[:3]
                # keep the optimum near the edge, otherwise fall back to the midpoint
                if np.linalg.norm(x - 0.5 * (verts[a] + verts[b])) < 2.0 * np.linalg.norm(verts[a] - verts[b]):
                    return x, float(np.append(x, 1) @ K @ np.append(x, 1))
        except np.linalg.LinAlgError:
            pass
        m = 0.5 * (verts[a] + verts[b])
        return m, float(np.append(m, 1) @ K @ np.append(m, 1))

    heap = []
    for a in range(nv):
        for b in nbr[a]:
            if a < b:
                pos, cost = best_pos(a, b)
                heapq.heappush(heap, (cost, a, b, 0, 0, pos))
    nfaces = len(faces)
    while nfaces > target_faces and heap:
        cost, a, b, va, vb, pos = heapq.heappop(heap)
        if not (alive_v[a] and alive_v[b]) or ver[a] != va or ver[b] != vb:
            continue
        # flip test
        ok = True
        old = verts[a].copy(), verts[b].copy()
        affected = (vfaces[a] | vfaces[b])
        shared = vfaces[a] & vfaces[b]
        for fi in affected:
            if fi in shared or not alive_f[fi]:
                continue
            f = faces[fi]
            p0 = [verts[x] for x in f]
            n0 = np.cross(p0[1] - p0[0], p0[2] - p0[0])
            p1 = [pos if x in (a, b) else verts[x] for x in f]
            n1 = np.cross(p1[1] - p1[0], p1[2] - p1[0])
            l0, l1 = np.linalg.norm(n0), np.linalg.norm(n1)
            if l0 < 1e-14 or l1 < 1e-14 or (n0 @ n1) / (l0 * l1) < flip_dot:
                ok = False
                break
        if not ok:
            continue
        # collapse b into a
        verts[a] = pos
        Q[a] = Q[a] + Q[b]
        alive_v[b] = False
        for fi in list(vfaces[b]):
            f = faces[fi]
            nf = tuple(a if x == b else x for x in f)
            if len(set(nf)) < 3:
                alive_f[fi] = False
                nfaces -= 1
                for x in f:
                    vfaces[x].discard(fi)
            else:
                faces[fi] = nf
                vfaces[a].add(fi)
        vfaces[b] = set()
        for x in nbr[b]:
            nbr[x].discard(b)
            if x != a:
                nbr[x].add(a)
                nbr[a].add(x)
        nbr[b] = set()
        ver[a] += 1
        for x in list(nbr[a]):
            p2, c2 = best_pos(a, x)
            lo, hi = (a, x) if a < x else (x, a)
            heapq.heappush(heap, (c2, lo, hi, ver[lo], ver[hi], p2))
    # compact
    remap = {}
    nv_list = []
    out_faces = []
    for fi, f in enumerate(faces):
        if not alive_f[fi]:
            continue
        tri = []
        for x in f:
            if x not in remap:
                remap[x] = len(nv_list)
                nv_list.append(verts[x])
            tri.append(remap[x])
        out_faces.append(tri)
    return np.array(nv_list), np.array(out_faces, dtype=np.int64)


# ------------------------------------------------------------------ surface refinement, normals, ambient occlusion


def gradient(f, P, eps=0.004):
    g = np.zeros_like(P)
    for i in range(3):
        d = np.zeros(3)
        d[i] = eps
        g[:, i] = f(P + d) - f(P - d)
    return g / (2 * eps)


def project(f, P, iters=3):
    for _ in range(iters):
        d = f(P)
        g = gradient(f, P)
        gl = np.maximum((g * g).sum(axis=1), 1e-12)
        P = P - (d / gl)[:, None] * g
    return P


def normals(f, P):
    g = gradient(f, P)
    return g / np.maximum(length(g), 1e-9)[:, None]


def ambient_occlusion(f, P, N, dists=(0.015, 0.04, 0.08, 0.16, 0.30), weights=(1.0, 0.8, 0.6, 0.4, 0.25)):
    occ = np.zeros(len(P))
    wsum = 0.0
    for d, w in zip(dists, weights):
        s = f(P + N * d)
        occ += w * np.clip((d - s) / d, 0.0, 1.0)
        wsum += w
    return np.clip(1.0 - 1.15 * occ / wsum, 0.0, 1.0)


def smooth_scalar(values, faces, iters=3, w=0.6):
    """Average a per vertex value with its neighbours (graph smoothing) to remove noise from a coarse mesh."""
    n = len(values)
    i = np.concatenate([faces[:, 0], faces[:, 1], faces[:, 2], faces[:, 1], faces[:, 2], faces[:, 0]])
    j = np.concatenate([faces[:, 1], faces[:, 2], faces[:, 0], faces[:, 0], faces[:, 1], faces[:, 2]])
    A = sparse.coo_matrix((np.ones(len(i)), (i, j)), shape=(n, n)).tocsr()
    A.data[:] = 1.0
    deg = np.asarray(A.sum(axis=1)).ravel()
    deg[deg == 0] = 1
    v = values.copy()
    for _ in range(iters):
        v = (1 - w) * v + w * (A @ v) / deg
    return v


def layer(f_vals, thickness):
    """Thin shell just outside a surface: 0 .. thickness above it (use to make crisp decals, stripes and patches)."""
    return np.abs(f_vals - thickness * 0.5) - thickness * 0.5


def raycast_surface(f, O, D, tmax=0.4, iters=28):
    """Distance along each ray from an inside point O to the surface f = 0 (bisection)."""
    lo = np.zeros(len(O))
    hi = np.full(len(O), tmax)
    for _ in range(iters):
        mid = 0.5 * (lo + hi)
        inside = f(O + D * mid[:, None]) < 0
        lo = np.where(inside, mid, lo)
        hi = np.where(inside, hi, mid)
    return 0.5 * (lo + hi)


def grid_decal(f, O, D, nu, nv, region, closed_u=False, offset=0.004, tmax=0.4, ao_strength=0.6):
    """A crisp low-poly decal: an (nv+1) x (nu+1) grid of rays cast onto the surface f = 0 and lifted by `offset`.
    O and D are (nv+1, nu+1, 3) arrays (ray origins inside the shape and unit directions)."""
    shp = O.shape[:2]
    Of, Df = O.reshape(-1, 3), D.reshape(-1, 3)
    t = raycast_surface(f, Of, Df, tmax)
    P = Of + Df * t[:, None]
    N = normals(f, P)
    P = P + N * offset
    n = len(P)
    idx = np.arange(n).reshape(shp)
    faces = []
    for j in range(shp[0] - 1):
        for i in range(shp[1] - 1):
            a, b, c, d = idx[j, i], idx[j, i + 1], idx[j + 1, i], idx[j + 1, i + 1]
            faces += [[a, b, c], [b, d, c]]
        if closed_u:
            a, b, c, d = idx[j, shp[1] - 1], idx[j, 0], idx[j + 1, shp[1] - 1], idx[j + 1, 0]
            faces += [[a, b, c], [b, d, c]]
    faces = np.array(faces, np.int64)
    ao = ambient_occlusion(f, P, N) ** ao_strength
    return dict(verts=P, faces=faces, normals=N, ao=ao, region=np.full(n, region, np.uint8), rgba=np.zeros((n, 4), np.uint8))


# ------------------------------------------------------------------ build and export


def drop_unused(verts, faces):
    used = np.unique(faces)
    remap = -np.ones(len(verts), np.int64)
    remap[used] = np.arange(len(used))
    return verts[used], remap[faces]


def build_part(f, bmin, bmax, h, target_faces, region_fn, base_rgba_fn=None, ao_strength=1.0, tag="", decal_of=None):
    """Mesh one SDF, simplify, refine and attach region ids, ambient occlusion and optional base colours.
    decal_of: SDF of the surface the part sits on; faces lying on that surface (the hidden underside of a decal) are removed."""
    verts, faces = mesh_sdf(f, bmin, bmax, h)
    if decal_of is not None:
        cen = verts[faces].mean(axis=1)
        keep = decal_of(cen) > 0.0016
        faces = faces[keep]
        verts, faces = drop_unused(verts, faces)
        # drop tiny disconnected islands left by the thin layer
        from scipy.sparse.csgraph import connected_components
        nvv = len(verts)
        ii = np.concatenate([faces[:, 0], faces[:, 1], faces[:, 2]])
        jj = np.concatenate([faces[:, 1], faces[:, 2], faces[:, 0]])
        A = sparse.coo_matrix((np.ones(len(ii)), (ii, jj)), shape=(nvv, nvv)).tocsr()
        ncomp, lab = connected_components(A, directed=False)
        sizes = np.bincount(lab[faces[:, 0]], minlength=ncomp)
        faces = faces[sizes[lab[faces[:, 0]]] >= 30]
        verts, faces = drop_unused(verts, faces)
    n0 = len(faces)
    if n0 > target_faces:
        verts, faces = simplify(verts, faces, target_faces)
    if decal_of is None:
        verts = project(f, verts)
        nrm = normals(f, verts)
        ao = ambient_occlusion(f, verts, nrm) ** ao_strength
    else:
        # the decal follows the surface it sits on: shade it like that surface
        nrm = normals(decal_of, verts)
        verts = verts + nrm * np.clip(0.0045 - decal_of(verts), -0.002, 0.002)[:, None]
        ao = ambient_occlusion(decal_of, verts, nrm) ** ao_strength
    ao = np.clip(smooth_scalar(ao, faces, 3), 0.0, 1.0)
    region = region_fn(verts)
    rgba = base_rgba_fn(verts, region) if base_rgba_fn else np.zeros((len(verts), 4), np.uint8)
    print("part %s: %d -> %d faces, %d verts" % (tag, n0, len(faces), len(verts)))
    return dict(verts=verts, faces=faces, normals=nrm, ao=ao, region=region.astype(np.uint8), rgba=rgba)


def merge_parts(parts):
    V, F, N, A, R, C = [], [], [], [], [], []
    off = 0
    for p in parts:
        V.append(p["verts"])
        F.append(p["faces"] + off)
        N.append(p["normals"])
        A.append(p["ao"])
        R.append(p["region"])
        C.append(p["rgba"])
        off += len(p["verts"])
    return dict(verts=np.concatenate(V), faces=np.concatenate(F), normals=np.concatenate(N), ao=np.concatenate(A),
                region=np.concatenate(R), rgba=np.concatenate(C))


def fix_winding(m):
    """Make every triangle face along its vertex normals."""
    v, f, n = m["verts"], m["faces"], m["normals"]
    a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
    fn = np.cross(b - a, c - a)
    avg = n[f[:, 0]] + n[f[:, 1]] + n[f[:, 2]]
    flip = (fn * avg).sum(axis=1) < 0
    f2 = f.copy()
    f2[flip, 1], f2[flip, 2] = f[flip, 2], f[flip, 1]
    m["faces"] = f2
    return m


def export_kmb(m, path):
    """Binary model file: 'KMB1', vertex count, index count, positions, normals, base colours, regions, ao, indices."""
    m = fix_winding(m)
    nv, ni = len(m["verts"]), m["faces"].size
    assert nv < 65535, "too many vertices for 16 bit indices: %d" % nv
    with open(path, "wb") as fh:
        fh.write(b"KMB1")
        fh.write(struct.pack("<II", nv, ni))
        fh.write(m["verts"].astype("<f4").tobytes())
        fh.write(np.clip(np.round(m["normals"] * 127), -127, 127).astype("<i1").tobytes())
        fh.write(m["rgba"].astype("<u1").tobytes())
        fh.write(m["region"].astype("<u1").tobytes())
        fh.write(np.clip(np.round(m["ao"] * 255), 0, 255).astype("<u1").tobytes())
        fh.write(m["faces"].astype("<u2").tobytes())
    print("wrote %s: %d verts, %d triangles, %d bytes" % (path, nv, ni // 3, 12 + nv * (12 + 3 + 4 + 1 + 1) + ni * 2))
