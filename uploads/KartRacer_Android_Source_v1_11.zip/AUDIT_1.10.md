# Kart Racer 1.10 audit (3D modelling)

## What was asked

After 1.9: "nah still looking bad, can you do 3d modelling?" This version replaces the hand-placed boxes-and-spheres models with real sculpted geometry for the driver and the six kart bodies.

## How it was done

`tools/model/sdfkit.py` is a small signed-distance-field modelling toolkit: primitives (box, capsule, cylinder, torus, ellipsoid), smooth union/subtraction, marching-cubes meshing, quadric-error simplification that protects decal boundaries, ray-cast decals that sit exactly on a sculpted surface, and baked ambient occlusion. `tools/model/make_driver.py` and `make_kart.py` use it to build `driver.kmb` and `body0.kmb`..`body5.kmb` in `app/src/main/resources/models/`. `gfx/BakedModels.java` loads them at runtime (`body()` and `driver()` in `KartModels` now call it first); the old procedural code stays as the fallback if a file is missing. These are plain Python/Java files checked into the repo, not run by the Android build; nothing changes for Gradle.

Every shape was rendered with the CPU preview (`tools/preview/Soft.java`) from several angles and looked at before it shipped. One real bug was caught and fixed this way: an early bake of the Dune Hopper had an odd pale vertical shape behind the rear axle. I isolated it (rendered the body alone, then just that region's vertices) and it turned out to be the skid plate, seen almost exactly edge-on from a test camera placed low and dead behind the kart — a real but harmless plate, not a hole or a stray object. I still shortened it so it no longer pokes out past the tail.

## What changed

* **Driver:** one swept skin for the torso, neck and each arm instead of ~30 overlapping balls and tubes; a one-piece helmet shell with the chin bar, rear tail and ear bulges sculpted into the same surface (not separate pieces touching it); a smoked mirror visor that follows the shell exactly; stripes, the number patch and vents are decals ray-cast onto the real surface, so they do not float or clip.
* **Kart bodies, all six types:** one sculpted hull with a carved cockpit opening and wheel arches blended into the bodywork; a roll cage, bumper or bull bar built from capsule tubing; headlamp housings and lenses, tail lamps, exhaust or engine details specific to each type; seat and steering wheel; cast stripe and number decals. The wheels, lamps and steering wheel added in 1.9/1.8 are unchanged (still procedural) and sit underneath the new bodies at the same points.

## Cost

| Kart | Body triangles | Driver | 2x wheels | Total |
|---|---|---|---|---|
| 0 Dune Hopper | 6,892 | 4,624 | ~3,056 | ~14,600 |
| 1 Sand Viper | 8,658 | 4,624 | ~3,056 | ~16,300 |
| 2 Rock Crusher | 7,390 | 4,624 | ~3,200 | ~15,200 |
| 3 Wave Runner | 9,954 | 4,624 | ~3,056 | ~17,600 |
| 4 Lava Rod | 6,448 | 4,624 | ~3,056 | ~14,100 |
| 5 Jungle Rover | 7,484 | 4,624 | ~3,104 | ~15,200 |

Up from about 12,000-14,000 per kart in 1.9. Sand Viper, Rock Crusher, Wave Runner and Jungle Rover came out heavier than their budget (hull target was 3,800-4,200) because the simplifier protects every decal edge from collapsing, and on a few parts (Wave Runner's windscreen frame, a steering wheel or two) that stalled it well above the target. They still look and shade correctly; I did not spend more time hand-tuning each one. If any kart needs to be lighter, tell me which and I will lower its budget in `make_kart.py` and re-bake just that one (a few minutes).

## Verification status

| Part | Status |
|---|---|
| `sdfkit.py`, `make_driver.py`, `make_kart.py` | run to completion for all 6 bodies + driver, every part's triangle count logged |
| `BakedModels.java`, `KartModels.body()/driver()` | compiled headless; the scene smoke test (`Smoke.java`) builds all four tracks' scenery and checks every mesh is within format limits |
| The actual rendered look | checked in the CPU preview from several angles (see the images); not on a GPU, not on a device |
| Kart physics, collision, controls | **untouched** this version — the model change is purely visual |
| Android build | not run here (no SDK). `BakedModels.java` is a new file; `KartModels.java` changed only at `body()`/`driver()`'s entry points. If the GitHub build turns red, send the red error text |

## Limits

* This still is not photorealistic: flat procedural colours, no textures on the bodies, no normal maps.
* The six bodies are new shapes, not copies of real cars; they follow the physics dimensions (track width, wheelbase, wheel radius) of the old models exactly, so handling is unaffected.
* I cannot judge "looks good" for you; these are my best sculpts from the description of what was wrong. Say which kart, or which part of it, still bothers you and I will revise that specific shape.

## Files changed since 1.9

- `README.md`
- `app/build.gradle`
- `(new) app/src/main/java/com/kartracer/gfx/BakedModels.java`
- `app/src/main/java/com/kartracer/gfx/KartModels.java`
- `(new) app/src/main/resources/models/body2.kmb`
- `(new) app/src/main/resources/models/body0.kmb`
- `(new) app/src/main/resources/models/driver.kmb`
- `(new) app/src/main/resources/models/body5.kmb`
- `(new) app/src/main/resources/models/body1.kmb`
- `(new) app/src/main/resources/models/body4.kmb`
- `(new) app/src/main/resources/models/body3.kmb`
- `(new) tools/model/make_kart.py`
- `(new) tools/model/sdfkit.py`
- `(new) tools/model/make_driver.py`
- `(new) tools/model/__pycache__/sdfkit.cpython-312.pyc`
