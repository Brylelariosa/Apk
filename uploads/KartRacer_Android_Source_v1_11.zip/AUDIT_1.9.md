# Kart Racer 1.9 audit (controls, driver, wheel guards)

## What was asked

After 1.8: "still bad control and character is just a bunch of circles overlapping each other, wheel guard still thin and ..." (the message ended there).

## How it was checked

The CPU preview (`tools/preview/Soft.java`) rendered the driver from three angles and the kart line-up after each step. The steering was measured headless: full steering pressed at a steady speed, time to half and 90 % of the final turn rate and the heading change after half a second, old code against new. The preview is an approximation and nothing was run on a device. I could not feel the controls, so the control changes are based on measurements and on the code, not on how it plays.

## Findings and changes

1. **Character (accurate: it was overlapping spheres).** The 1.8 driver was about 30 ellipsoids and tubes laid over each other, so the seams and bumps showed. Now: `sweep()` builds one continuous skin along a smooth curve with a per point elliptical section. Torso and neck are one sweep from pelvis to neck with sloping shoulders, each arm is one sweep (rounded shoulder cap, upper arm, elbow, forearm, wrist), the glove is a palm and a rounded mitten wrapped over the grip, the thighs are sweeps. The helmet is one smooth surface (`helmetSurface`): an ellipsoid with a flattened underside, the chin bar, the rear tail and the ear bulges built into the same function, and the visor, seal, stripes and vents are patches of that same surface, so nothing floats or overlaps. About 3.7k triangles.
2. **Wheel guards (accurate: still a thin strip).** 1.8 only thickened the strip and added edge tubes. Now `arch()` builds a real guard: crowned cross section (R rises 8.5 cm in the middle, curving down at both edges), outer and inner skins 7.5 cm apart, an inner liner in dark plastic, thick edges and end caps, wider than the tyre. Same helper for all six karts.
3. **Steering was slow (measured).** The wheel wind-up was 3.4 wheel units per second minus 1.2 at top speed, so full lock took up to 0.45 s. Now 4.2 minus 1.0 times a player setting (Slow 0.7, Normal 1.0, Fast 1.3, Quick 1.7, Instant 2.3; default Fast). Measured at 32 m/s: half the turn rate after 0.30 s before, 0.23 / 0.20 / 0.13 s at Normal / Fast / Instant; heading change in the first 0.5 s 13 degrees before, 16 / 18 / 21 after. At 12 m/s: 28 degrees before, 32 / 35 / 40 after. A scripted test lap is unchanged (the test driver steers gently, so it is not limited by the wheel).
4. **Steering buttons were all or nothing.** Each button gave full lock, so every small correction was a tap. Now the two buttons are one analog pad: steering follows the thumb's horizontal position (middle of a button is about 97 % lock, outer edge 100 %, the middle of the pad 0), the gap between the buttons counts as part of the pad, and sliding between the buttons works without lifting the thumb. The pressed look of the buttons follows the real steering.

## What I do not know

* What exactly feels bad about the controls for you. Steering that is too slow or too sharp, buttons that are hard to hit, the kart leaving the road, drifting, and being hit are all possible and I changed the first two and the hit behaviour. Please tell me which one it is.
* How the analog pad feels on a thumb. It is implemented from the code and not tried on a phone.

## Limits

* The car bodies are the same stylized shapes; only fenders, wheels, lamps, seat, wheel and driver changed.
* The driver is still low poly (no face under the visor, mitten gloves).

## Verification status

| Part | Status |
|---|---|
| Models and kart physics (pure Java) | compiled and run headless, scenes rendered in the preview, steering measured |
| Android files (`RaceOverlay`, `Screens`, `Settings`, `SettingsStore`, `GameRenderer`) | not compiled here (no SDK). The before / after compiler comparison shows no syntax errors and no new errors except unresolved Android classes |
| Behaviour on a device | **not run** |

If the GitHub build turns red, send the red error text.

## Files changed since 1.8

- `README.md`
- `app/build.gradle`
- `app/src/main/java/com/kartracer/app/RaceOverlay.java`
- `app/src/main/java/com/kartracer/app/Screens.java`
- `app/src/main/java/com/kartracer/app/Settings.java`
- `app/src/main/java/com/kartracer/app/SettingsStore.java`
- `app/src/main/java/com/kartracer/gfx/KartModels.java`
- `app/src/main/java/com/kartracer/gl/GameRenderer.java`
- `app/src/main/java/com/kartracer/sim/Kart.java`
- `app/src/main/java/com/kartracer/sim/KartInput.java`
