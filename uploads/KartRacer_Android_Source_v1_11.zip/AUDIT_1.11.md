# Kart Racer 1.11 audit (colour/light only)

## What changed this round, and why

Two things came out of a direct check-in: nothing from 1.5 through 1.10 had been built or run on a phone yet, and the look wanted is a bright toy/cartoon style, not realism. A render of the current kart against a plain sky (no track around it) was confirmed as the right direction. That meant the sculpted models from 1.10 are fine; what was wrong is that the game's actual **lighting and colour grade** (tuned toward "natural" starting in 1.6, for the realism push) was fighting those glossy, bright models. This version only touches grading, lighting and ground colour: `gl/SceneGfx.java`, `gl/Shaders.java`, `gfx/TexGen.java`, `world/Terrain.java`. No model, physics, or control files changed.

Numbers: sun/ambient scales 1.00/0.44/0.38 to 1.08/0.50/0.42; grade saturation 1.08 to 1.32; contrast curve 0.32 to 0.22; split-tone roughly halved; asphalt patch darkening 0.10 to 0.04, edge dust 0.10 to 0.04, crack darkening 0.72 to 0.85 (lighter); sand and grass base colours brightened and more saturated. The same numbers were mirrored in the CPU preview and the beach track and a close kart shot were rendered and looked at before shipping.

## What was NOT done

I have still never seen this run on an actual phone or in a real build. The change here is small and mechanical (a handful of constants), so the risk of it breaking the Android build is low, but "low risk" is not "verified." The before/after Android compiler comparison (no SDK, so it can only catch missing symbols and syntax errors) is clean, same as every prior version.

## What I need from you

Please build this one (or ask me to walk through why it won't build, if it doesn't) and send a screenshot, even a bad one. Everything since 1.5 has been me guessing at a target I've never been shown hit. If the colour is still wrong, a screenshot would let me match it directly instead of guessing again.

## Files changed since 1.10

- `README.md`
- `app/build.gradle`
- `app/src/main/java/com/kartracer/gfx/TexGen.java`
- `app/src/main/java/com/kartracer/gl/SceneGfx.java`
- `app/src/main/java/com/kartracer/gl/Shaders.java`
- `app/src/main/java/com/kartracer/world/Terrain.java`
