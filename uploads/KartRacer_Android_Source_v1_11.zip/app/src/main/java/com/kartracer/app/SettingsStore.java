package com.kartracer.app;

import android.app.ActivityManager;
import android.content.Context;
import android.content.SharedPreferences;

/** SharedPreferences persistence for Settings. */
public final class SettingsStore {
    private final SharedPreferences sp;
    private final Context ctx;

    public SettingsStore(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("kartracer_settings", Context.MODE_PRIVATE);
    }

    private int autoQuality() {
        try {
            ActivityManager am = (ActivityManager) ctx.getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            long gb10 = mi.totalMem / (1024L * 1024L * 102L); // ~ tenths of GB
            int cores = Runtime.getRuntime().availableProcessors();
            if (gb10 >= 55 && cores >= 8) return 2;
            if (gb10 >= 33) return 1;
            return 0;
        } catch (Exception e) {
            return 1;
        }
    }

    public Settings load() {
        Settings s = new Settings();
        s.playerName = sp.getString("name", s.playerName);
        s.kart = sp.getInt("kart", s.kart); s.paint = sp.getInt("paint", s.paint); s.driver = sp.getInt("driver", s.driver);
        s.track = sp.getInt("track", s.track); s.laps = sp.getInt("laps", s.laps); s.aiCount = sp.getInt("ai", s.aiCount);
        s.difficulty = sp.getInt("diff", s.difficulty); s.items = sp.getBoolean("items", s.items);
        s.quality = sp.contains("quality") ? sp.getInt("quality", 1) : autoQuality();
        s.autoQuality = sp.getBoolean("autoq", s.autoQuality); s.shadows = sp.getBoolean("shadows", s.shadows);
        s.scalePct = sp.getInt("scale", s.scalePct); s.fpsCap = sp.getInt("fpscap", s.fpsCap); s.showFps = sp.getBoolean("showfps", s.showFps);
        s.sound = sp.getBoolean("sound", s.sound); s.sfxVolume = Math.max(0, Math.min(100, sp.getInt("sfxvol", s.sfxVolume)));
        s.cameraMode = sp.getInt("cam", s.cameraMode); s.fov = sp.getInt("fov", s.fov); s.camShake = sp.getBoolean("shake", s.camShake);
        s.steerMode = sp.getInt("steer", s.steerMode); s.autoGas = sp.getBoolean("autogas", s.autoGas); s.tiltSens = sp.getInt("tilt", s.tiltSens);
        // controls revision 2 (v1.5): auto accelerate became the default (the right thumb cannot hold the gas and reach Drift / Nitro / Item).
        // Applied once to existing installs; the player can switch it off again in Settings > Controls.
        if (sp.getInt("ctlver", 0) < 2) {
            s.controlsChanged = sp.contains("kart") && !s.autoGas;
            s.autoGas = true;
        }
        s.steerAssist = Math.max(0, Math.min(3, sp.getInt("assist", s.steerAssist)));
        s.steerSpeed = Math.max(0, Math.min(4, sp.getInt("steerspeed", s.steerSpeed)));
        s.buttonScale = sp.getInt("btnscale", s.buttonScale); s.controlOpacity = sp.getInt("opacity", s.controlOpacity);
        s.leftHanded = sp.getBoolean("lefty", s.leftHanded); s.haptics = sp.getBoolean("haptics", s.haptics);
        s.customLayout = sp.getBoolean("customlayout", false);
        s.lastIp = sp.getString("lastip", "");
        s.layout = Settings.defaultLayout(s.leftHanded, s.autoGas);
        String lay = sp.getString("layout", null);
        if (s.customLayout && lay != null) {
            String[] p = lay.split(",");
            if (p.length == Settings.CONTROLS * 2) {
                try { for (int i = 0; i < p.length; i++) s.layout[i] = Float.parseFloat(p[i]); } catch (NumberFormatException e) { s.resetLayout(); }
            }
        }
        s.laps = Math.max(1, Math.min(9, s.laps)); s.aiCount = Math.max(0, Math.min(7, s.aiCount));
        return s;
    }

    public void save(Settings s) {
        SharedPreferences.Editor e = sp.edit();
        e.putString("name", s.playerName).putInt("kart", s.kart).putInt("paint", s.paint).putInt("driver", s.driver)
                .putInt("track", s.track).putInt("laps", s.laps).putInt("ai", s.aiCount).putInt("diff", s.difficulty).putBoolean("items", s.items)
                .putInt("quality", s.quality).putBoolean("autoq", s.autoQuality).putBoolean("shadows", s.shadows).putInt("scale", s.scalePct)
                .putInt("fpscap", s.fpsCap).putBoolean("showfps", s.showFps).putInt("cam", s.cameraMode).putInt("fov", s.fov)
                .putBoolean("shake", s.camShake).putInt("steer", s.steerMode).putBoolean("autogas", s.autoGas).putInt("assist", s.steerAssist).putInt("steerspeed", s.steerSpeed).putInt("tilt", s.tiltSens)
                .putInt("btnscale", s.buttonScale).putInt("opacity", s.controlOpacity).putBoolean("lefty", s.leftHanded)
                .putBoolean("haptics", s.haptics).putBoolean("customlayout", s.customLayout).putString("lastip", s.lastIp)
                .putBoolean("sound", s.sound).putInt("sfxvol", s.sfxVolume).putInt("ctlver", 2);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.layout.length; i++) { if (i > 0) sb.append(','); sb.append(s.layout[i]); }
        e.putString("layout", sb.toString());
        e.apply();
    }
}
