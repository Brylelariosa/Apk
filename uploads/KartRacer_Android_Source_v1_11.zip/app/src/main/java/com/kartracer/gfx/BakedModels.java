package com.kartracer.gfx;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Loads the sculpted models (made with tools/model, stored as .kmb files in app/src/main/resources/models).
 * Returns null when a model is missing or damaged, so the caller falls back to the procedural model and the game always starts.
 *
 * File layout (little endian): "KMB1", vertex count, index count, positions (float x3), normals (byte x3), base colours (byte x4),
 * regions (byte), ambient occlusion (byte), indices (unsigned short).
 */
public final class BakedModels {
    private BakedModels() { }

    /**
     * @param palette one colour per region id (packed like Col.rgba, alpha = paint / gloss mask); each is darkened by the baked ambient occlusion.
     *                null uses the colours stored in the file.
     */
    public static MeshData load(String name, int[] palette) {
        try {
            InputStream in = BakedModels.class.getResourceAsStream("/models/" + name + ".kmb");
            if (in == null) return null;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int r;
            while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
            in.close();
            ByteBuffer bb = ByteBuffer.wrap(bo.toByteArray()).order(ByteOrder.LITTLE_ENDIAN);
            if (bb.remaining() < 12 || bb.getInt() != 0x31424D4B) return null;
            int n = bb.getInt(), ni = bb.getInt();
            if (n <= 0 || n >= 65535 || ni <= 0 || ni % 3 != 0) return null;
            float[] pos = new float[n * 3];
            for (int i = 0; i < pos.length; i++) pos[i] = bb.getFloat();
            byte[] nrm = new byte[n * 3];
            bb.get(nrm);
            byte[] rgba = new byte[n * 4];
            bb.get(rgba);
            byte[] region = new byte[n];
            bb.get(region);
            byte[] ao = new byte[n];
            bb.get(ao);
            short[] idx = new short[ni];
            for (int i = 0; i < ni; i++) idx[i] = bb.getShort();
            ByteBuffer vb = ByteBuffer.allocate(n * MeshData.STRIDE).order(ByteOrder.LITTLE_ENDIAN);
            float minx = 1e9f, miny = 1e9f, minz = 1e9f, maxx = -1e9f, maxy = -1e9f, maxz = -1e9f;
            for (int i = 0; i < n; i++) {
                float x = pos[i * 3], y = pos[i * 3 + 1], z = pos[i * 3 + 2];
                vb.putFloat(x); vb.putFloat(y); vb.putFloat(z);
                vb.put(nrm[i * 3]); vb.put(nrm[i * 3 + 1]); vb.put(nrm[i * 3 + 2]); vb.put((byte) 0);
                int col;
                if (palette != null) {
                    int c = palette[(region[i] & 255) % palette.length];
                    float k = 0.45f + 0.55f * ((ao[i] & 255) / 255f);
                    int cr = Math.min(255, Math.round((c & 255) * k)), cg = Math.min(255, Math.round(((c >> 8) & 255) * k)), cb = Math.min(255, Math.round(((c >> 16) & 255) * k));
                    col = (c & 0xFF000000) | (cb << 16) | (cg << 8) | cr;
                } else {
                    col = (rgba[i * 4] & 255) | ((rgba[i * 4 + 1] & 255) << 8) | ((rgba[i * 4 + 2] & 255) << 16) | ((rgba[i * 4 + 3] & 255) << 24);
                }
                vb.putInt(col);
                vb.putFloat(0f); vb.putFloat(0f);
                minx = Math.min(minx, x); maxx = Math.max(maxx, x); miny = Math.min(miny, y); maxy = Math.max(maxy, y); minz = Math.min(minz, z); maxz = Math.max(maxz, z);
            }
            MeshData m = new MeshData(n, vb.array(), idx);
            m.cx = (minx + maxx) * 0.5f; m.cy = (miny + maxy) * 0.5f; m.cz = (minz + maxz) * 0.5f;
            float dx = maxx - minx, dy = maxy - miny, dz = maxz - minz;
            m.radius = 0.5f * (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            return m;
        } catch (Throwable t) {
            return null;
        }
    }
}
