package com.kartracer.app;

/** User settings (plain data; persisted by SettingsStore). */
public final class Settings {
    // player
    public String playerName = "Player";
    public int kart = 0, paint = 0, driver = 0;
    // quick race setup
    public int track = 0, laps = 3, aiCount = 5, difficulty = 1;
    public boolean items = true;
    // graphics
    public int quality = 1;           // 0 low, 1 medium, 2 high
    public boolean autoQuality = true; // adapt render scale to frame time
    public boolean shadows = true;
    public int scalePct = 0;          // 0 = from preset, else 50..100
    public int fpsCap = 60;           // 30 or 60
    public boolean showFps = false;
    // sound
    public boolean sound = true;
    public int sfxVolume = 80;        // percent
    // camera
    public int cameraMode = 1;        // 0 close, 1 normal, 2 far
    public int fov = 62;
    public boolean camShake = true;
    // controls
    public int steerMode = 0;         // 0 buttons, 1 tilt, 2 slide
    /** On by default: with gas on one thumb the other buttons (drift, nitro, item) are out of reach of the same thumb. */
    public boolean autoGas = true;
    /** Steering assist: 0 off, 1 low, 2 medium, 3 high (nudges the kart along the road, turns it round when it faces the wrong way). */
    public int steerAssist = 2;
    /** How fast the wheel turns (index into STEER_RATE): Slow, Normal, Fast, Quick, Instant. */
    public int steerSpeed = 2;
    public int tiltSens = 100;        // percent
    public int buttonScale = 100;     // percent
    public int controlOpacity = 80;   // percent
    public boolean leftHanded = false;
    public boolean haptics = true;
    public boolean customLayout = false;
    /** Set once after an update that changed the control defaults, so the app can tell the player (not saved). */
    public boolean controlsChanged = false;
    /** Normalized centers (x,y) for: left, right, gas, brake, drift, item, boost. */
    public float[] layout = defaultLayout(false, true);
    // network
    public String lastIp = "";

    public static final float[] ASSIST_STRENGTH = {0f, 0.35f, 0.6f, 0.9f};

    /** Assist strength 0..1 handed to the simulation. */
    public static final float[] STEER_RATE = {0.7f, 1.0f, 1.3f, 1.7f, 2.3f};
    public float steerRate() { return STEER_RATE[Math.max(0, Math.min(STEER_RATE.length - 1, steerSpeed))]; }
    public float assistStrength() { return ASSIST_STRENGTH[Math.max(0, Math.min(ASSIST_STRENGTH.length - 1, steerAssist))]; }

    public static final int CONTROLS = 7;
    public static final String[] CONTROL_NAMES = {"Steer left", "Steer right", "Gas", "Brake", "Drift", "Item", "Boost"};

    public static float[] defaultLayout(boolean leftHanded) { return defaultLayout(leftHanded, false); }

    /**
     * Default button positions (normalized x,y of each control).
     * With auto accelerate the gas pedal is not needed: the big Drift button takes its place under the right thumb,
     * with Brake, Nitro and Item around it, so every button can be reached without lifting the thumb far.
     */
    public static float[] defaultLayout(boolean leftHanded, boolean autoGas) {
        // steering cluster on one side, pedals on the other
        float[] l = autoGas
                ? new float[]{0.11f, 0.80f, 0.27f, 0.80f, 0.91f, 0.78f, 0.74f, 0.86f, 0.89f, 0.72f, 0.90f, 0.30f, 0.76f, 0.54f}
                : new float[]{0.11f, 0.80f, 0.27f, 0.80f, 0.91f, 0.78f, 0.77f, 0.86f, 0.90f, 0.50f, 0.90f, 0.27f, 0.76f, 0.60f};
        if (leftHanded) {
            for (int i = 0; i < CONTROLS; i++) l[i * 2] = 1f - l[i * 2];
            // keep "steer left" on the left of "steer right" after mirroring, and keep the item button clear of the place / lap display
            float t = l[0]; l[0] = l[2]; l[2] = t;
            l[11] = 0.40f;
        }
        return l;
    }

    public void resetLayout() { layout = defaultLayout(leftHanded, autoGas); customLayout = false; }

    public Settings copy() {
        Settings s = new Settings();
        s.playerName = playerName; s.kart = kart; s.paint = paint; s.driver = driver;
        s.track = track; s.laps = laps; s.aiCount = aiCount; s.difficulty = difficulty; s.items = items;
        s.quality = quality; s.autoQuality = autoQuality; s.shadows = shadows; s.scalePct = scalePct; s.fpsCap = fpsCap; s.showFps = showFps;
        s.sound = sound; s.sfxVolume = sfxVolume;
        s.cameraMode = cameraMode; s.fov = fov; s.camShake = camShake;
        s.steerMode = steerMode; s.autoGas = autoGas; s.steerAssist = steerAssist; s.steerSpeed = steerSpeed; s.tiltSens = tiltSens; s.buttonScale = buttonScale; s.controlOpacity = controlOpacity;
        s.leftHanded = leftHanded; s.haptics = haptics; s.customLayout = customLayout; s.layout = layout.clone(); s.lastIp = lastIp;
        return s;
    }
}
