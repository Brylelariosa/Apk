package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.MathX;

import java.util.ArrayList;

/**
 * Procedural kart, wheel and driver meshes. Body space: forward = -Z, right = +X, ground at y = 0.
 * Bodies are lofted from smooth cross sections (rounded shoulders, fenders over the wheels, chrome, lamps and a painted
 * racing stripe) instead of stacked boxes; drivers are chunky characters with helmets, faces, arms on the wheel and a number badge.
 */
public final class KartModels {
    private KartModels() {}

    public static final int TYPES = 6, DRIVERS = 6;
    public static final String[] DRIVER_NAMES = {"Rex", "Coco", "Bolt", "Mango", "Zippy", "Tiki"};
    /** Paint colors (0xRRGGBB) offered in the garage. */
    public static final int[] PAINTS = {0xE53935, 0xFF9800, 0xFDD835, 0x43A047, 0x00ACC1, 0x1E88E5, 0x8E24AA, 0xEC407A};
    public static final String[] PAINT_NAMES = {"Red", "Orange", "Yellow", "Green", "Teal", "Blue", "Purple", "Pink"};

    // wheel layout per kart type
    public static final float[] FRONT_R = {0.42f, 0.36f, 0.64f, 0.40f, 0.36f, 0.52f};
    public static final float[] REAR_R = {0.46f, 0.42f, 0.64f, 0.40f, 0.52f, 0.52f};
    public static final float[] WHEEL_W = {0.34f, 0.28f, 0.46f, 0.32f, 0.34f, 0.38f};
    public static final float[] TRACK_HALF = {0.84f, 0.80f, 1.02f, 0.82f, 0.86f, 0.94f};
    public static final float[] BASE_HALF = {0.95f, 1.05f, 1.00f, 0.90f, 1.00f, 1.00f};
    public static final float[] SEAT_Y = {0.84f, 0.62f, 1.50f, 0.84f, 0.90f, 1.00f};
    public static final float[] SEAT_Z = {0.20f, 0.25f, 0.38f, 0.30f, 0.45f, 0.30f};

    private static int paint(int shade) { return Col.rgba(shade, shade, shade, 255); }
    private static int fixed(int r, int g, int b) { return Col.rgba(r, g, b, 0); }

    private static final int STEEL = fixed(170, 176, 186), CHROME = fixed(226, 232, 240), DARK = fixed(46, 50, 58), BLACK = fixed(24, 26, 30),
            LIGHT = fixed(255, 248, 200), LIGHT_DIM = fixed(236, 214, 150), WHITE = fixed(246, 246, 240), RED = fixed(205, 30, 36), GLOW = fixed(255, 110, 84),
            SEAT = fixed(40, 44, 54), GLASS = fixed(120, 190, 225), INK = fixed(30, 32, 38);

    /** The sculpted body (tools/model/make_kart.py, body<N>.kmb) when it exists, otherwise the procedural one. */
    public static MeshData body(int type) {
        MeshData baked = BakedModels.load("body" + Math.floorMod(type, TYPES), null);
        return baked != null ? baked : bodyProcedural(type);
    }

    private static MeshData bodyProcedural(int type) {
        MeshBuilder b = new MeshBuilder();
        switch (Math.floorMod(type, TYPES)) {
            case 0: duneHopper(b); break;
            case 1: sandViper(b); break;
            case 2: rockCrusher(b); break;
            case 3: waveRunner(b); break;
            case 4: lavaRod(b); break;
            default: jungleRover(b); break;
        }
        return b.build();
    }

    // ---------------------------------------------------------------- shared parts

    private static float topAt(float[][] sec, float z) {
        if (z <= sec[0][0]) return sec[0][3];
        for (int i = 0; i + 1 < sec.length; i++) {
            if (z <= sec[i + 1][0]) {
                float t = (z - sec[i][0]) / (sec[i + 1][0] - sec[i][0]);
                return sec[i][3] + (sec[i + 1][3] - sec[i][3]) * t;
            }
        }
        return sec[sec.length - 1][3];
    }

    /** A narrow painted band lying on top of a lofted body between z0 and z1 (racing stripe). */
    private static void topStripe(MeshBuilder b, float[][] sec, float z0, float z1, float hw, int color, float x) {
        ArrayList<float[]> s = new ArrayList<>();
        s.add(new float[]{z0, hw, topAt(sec, z0) - 0.04f, topAt(sec, z0) + 0.012f, 6f, 6f, x});
        for (float[] q : sec) if (q[0] > z0 + 0.01f && q[0] < z1 - 0.01f) s.add(new float[]{q[0], hw, q[3] - 0.04f, q[3] + 0.012f, 6f, 6f, x});
        s.add(new float[]{z1, hw, topAt(sec, z1) - 0.04f, topAt(sec, z1) + 0.012f, 6f, 6f, x});
        b.loft(s.toArray(new float[0][]), 8, color, color, true, true);
    }

    /** Projector headlamp: black housing, chrome bezel, glass lens and a bright LED ring. */
    private static void headlamp(MeshBuilder b, float x, float y, float z, float r) {
        b.softBox(x, y, z + r * 0.05f, r * 1.05f, r * 0.92f, r * 0.55f, 2.6f, 10, 5, BLACK, DARK);
        b.push().translate(x, y, z - r * 0.38f).rotX(MathX.PI / 2f).torus(0, 0, 0, r * 0.80f, r * 0.07f, 16, 4, CHROME).pop();
        b.sphere(x, y, z - r * 0.36f, r * 0.74f, r * 0.74f, r * 0.20f, 10, 5, fixed(150, 166, 178), fixed(226, 236, 244));
        b.push().translate(x, y, z - r * 0.50f).rotX(MathX.PI / 2f).torus(0, 0, 0, r * 0.42f, r * 0.045f, 14, 4, LIGHT).pop();
    }

    private static void taillamp(MeshBuilder b, float x, float y, float z, float w, float h) {
        b.softBox(x, y, z, w, h * 0.85f, 0.03f, 3f, 8, 3, fixed(70, 8, 12), fixed(130, 14, 20));
        b.softBox(x, y, z + 0.016f, w * 0.86f, h * 0.36f, 0.02f, 3f, 8, 3, fixed(236, 40, 40), fixed(255, 90, 76));
    }

    /** Chrome exhaust pipe pointing along (dx, dy, dz) with a dark opening. */
    private static void exhaust(MeshBuilder b, float x, float y, float z, float dx, float dy, float dz, float r) {
        b.tube(x, y, z, x + dx, y + dy, z + dz, r * 0.85f, r, 10, fixed(118, 122, 130), fixed(172, 176, 184), true);
        b.tube(x + dx * 0.55f, y + dy * 0.55f, z + dz * 0.55f, x + dx * 0.72f, y + dy * 0.72f, z + dz * 0.72f, r * 0.96f, r * 0.98f, 10, fixed(150, 124, 70), fixed(120, 104, 150), false);
        b.tube(x + dx * 0.93f, y + dy * 0.93f, z + dz * 0.93f, x + dx, y + dy, z + dz, r * 1.10f, r * 1.10f, 10, fixed(150, 152, 160), fixed(214, 216, 222), true);
        float l = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        float ex = dx / l * 0.012f, ey = dy / l * 0.012f, ez = dz / l * 0.012f;
        b.tube(x + dx, y + dy, z + dz, x + dx + ex, y + dy + ey, z + dz + ez, r * 0.92f, r * 0.92f, 10, BLACK, BLACK, true);
    }

    /** Dark seat pad with a painted coaming ring: the cockpit opening. */
    private static void cockpit(MeshBuilder b, float cx, float cy, float cz, float rx, float rz, int rim) {
        b.softBox(cx, cy + 0.01f, cz, rx * 0.95f, 0.06f, rz * 0.95f, 4f, 14, 5, SEAT, fixed(58, 62, 74));
        b.push().translate(cx, cy + 0.02f, cz).torus(0, 0, 0, rx, rz, 0.05f, 20, 6, rim).pop();
    }

    /** Bucket seat: shell, side bolsters, head restraint and padding. */
    private static void seatBack(MeshBuilder b, float y, float z, float w, float h) {
        b.softBox(0, y, z, w, h, 0.07f, 3f, 12, 6, fixed(28, 30, 36), fixed(50, 54, 64));
        for (int sd = -1; sd <= 1; sd += 2) b.softBox(sd * w * 0.86f, y - h * 0.1f, z - 0.075f, w * 0.16f, h * 0.78f, 0.07f, 3f, 8, 5, fixed(32, 34, 40), fixed(58, 62, 72));
        b.softBox(0, y + h * 0.98f, z - 0.02f, w * 0.52f, h * 0.22f, 0.08f, 3f, 8, 5, fixed(34, 36, 42), fixed(60, 64, 74));
        b.softBox(0, y + h * 0.10f, z - 0.085f, w * 0.58f, h * 0.62f, 0.02f, 3.5f, 8, 4, fixed(62, 66, 80), fixed(62, 66, 80));
    }

    /** Steering wheel and column in front of a driver sitting at (0, seatY, seatZ) of this body. */
    private static void steering(MeshBuilder b, int t, float colY0, float colZ0) {
        float wy = SEAT_Y[t] + 0.26f, wz = SEAT_Z[t] - 0.52f;
        b.push().translate(wy * 0f, wy, wz).rotX(1.05f);
        b.torus(0, 0, 0, 0.15f, 0.024f, 18, 6, BLACK);                                   // rim
        for (int sd = -1; sd <= 1; sd += 2) b.sphere(sd * 0.15f, 0, 0, 0.04f, 0.04f, 0.075f, 8, 5, fixed(54, 56, 62), fixed(80, 82, 90));   // grips
        b.softBox(0, 0, 0, 0.065f, 0.026f, 0.05f, 2.6f, 10, 5, fixed(36, 38, 44), fixed(58, 60, 68));   // carbon hub
        for (int sd = -1; sd <= 1; sd += 2) b.box(sd * 0.085f, 0, 0, 0.07f, 0.010f, 0.016f, fixed(30, 32, 38));
        for (int i = 0; i < 3; i++) b.sphere(-0.03f + i * 0.03f, -0.024f, -0.012f, 0.009f, 5, 3, i == 1 ? fixed(220, 40, 40) : fixed(220, 190, 40));   // buttons
        b.pop();
        b.tube(0, wy - 0.02f, wz + 0.02f, 0, colY0, colZ0, 0.028f, 0.034f, 8, STEEL, STEEL, false);
    }

    /** A wheel arch: curved painted mudguard above a wheel centred at (x, y, z). */
    private static void quadFacing(MeshBuilder b, int a, int bb, int c, int d, float[] pa, float[] pb, float[] pc, float[] nOut) {
        // two triangles (a,bb,c) and (bb,d,c) wound so the face looks along nOut
        float[] n1 = cross3(pb[0] - pa[0], pb[1] - pa[1], pb[2] - pa[2], pc[0] - pa[0], pc[1] - pa[1], pc[2] - pa[2]);
        boolean ok = n1[0] * nOut[0] + n1[1] * nOut[1] + n1[2] * nOut[2] >= 0f;
        if (ok) { b.tri(a, bb, c); b.tri(bb, d, c); } else { b.tri(a, c, bb); b.tri(bb, c, d); }
    }

    /**
     * Wheel guard with a crowned top and flared edges, 7 cm thick, with an inner lining: a solid part of the body instead of a strip.
     * a0..a1 is the arc over the wheel (angles around the axle), the cross section across the width is curved (high in the middle, down at the edges).
     */
    private static void arch(MeshBuilder b, float x, float y, float z, float tireR, float tireW, int col, float a0, float a1) {
        float R0 = tireR + 0.065f, crown = 0.085f, hw = tireW * 0.5f + 0.095f, th = 0.075f;
        int nA = 12, nT = 6;
        float[][][] po = new float[nA + 1][nT + 1][], pi = new float[nA + 1][nT + 1][], no = new float[nA + 1][nT + 1][];
        int[][] vo = new int[nA + 1][nT + 1], vi = new int[nA + 1][nT + 1];
        int liner = fixed(26, 28, 34);
        for (int i = 0; i <= nA; i++) {
            float a = a0 + (a1 - a0) * i / nA;
            float ry = (float) Math.cos(a), rz = -(float) Math.sin(a);
            for (int j = 0; j <= nT; j++) {
                float t = -1f + 2f * j / nT;
                float Rt = R0 + crown * (1f - t * t);
                float dR = -2f * crown * t;
                float xo = x + t * hw;
                po[i][j] = new float[]{xo, y + ry * (Rt + th), z + rz * (Rt + th)};
                pi[i][j] = new float[]{xo, y + ry * Rt, z + rz * Rt};
                float[] n = norm3(new float[]{-dR / hw, ry, rz});
                no[i][j] = n;
                vo[i][j] = b.vert(po[i][j][0], po[i][j][1], po[i][j][2], n[0], n[1], n[2], Col.withAlpha(col, 200));
                vi[i][j] = b.vert(pi[i][j][0], pi[i][j][1], pi[i][j][2], -n[0], -n[1], -n[2], liner);
            }
        }
        for (int i = 0; i < nA; i++) for (int j = 0; j < nT; j++) {
            quadFacing(b, vo[i][j], vo[i][j + 1], vo[i + 1][j], vo[i + 1][j + 1], po[i][j], po[i][j + 1], po[i + 1][j], no[i][j]);
            float[] ni = new float[]{-no[i][j][0], -no[i][j][1], -no[i][j][2]};
            quadFacing(b, vi[i][j], vi[i][j + 1], vi[i + 1][j], vi[i + 1][j + 1], pi[i][j], pi[i][j + 1], pi[i + 1][j], ni);
        }
        // thick edges (left and right) and the two ends
        for (int sd = 0; sd < 2; sd++) {
            int j = sd == 0 ? 0 : nT;
            float sx = sd == 0 ? -1f : 1f;
            for (int i = 0; i < nA; i++) {
                int e0 = b.vert(po[i][j][0], po[i][j][1], po[i][j][2], sx, 0f, 0f, col), e1 = b.vert(pi[i][j][0], pi[i][j][1], pi[i][j][2], sx, 0f, 0f, col);
                int e2 = b.vert(po[i + 1][j][0], po[i + 1][j][1], po[i + 1][j][2], sx, 0f, 0f, col), e3 = b.vert(pi[i + 1][j][0], pi[i + 1][j][1], pi[i + 1][j][2], sx, 0f, 0f, col);
                quadFacing(b, e0, e1, e2, e3, po[i][j], pi[i][j], po[i + 1][j], new float[]{sx, 0f, 0f});
            }
        }
        for (int en = 0; en < 2; en++) {
            int i = en == 0 ? 0 : nA;
            float a = en == 0 ? a0 : a1;
            float[] dir = norm3(new float[]{0f, -(float) Math.sin(a) * (en == 0 ? -1f : 1f), -(float) Math.cos(a) * (en == 0 ? -1f : 1f)});
            for (int j = 0; j < nT; j++) {
                int e0 = b.vert(po[i][j][0], po[i][j][1], po[i][j][2], dir[0], dir[1], dir[2], col), e1 = b.vert(pi[i][j][0], pi[i][j][1], pi[i][j][2], dir[0], dir[1], dir[2], col);
                int e2 = b.vert(po[i][j + 1][0], po[i][j + 1][1], po[i][j + 1][2], dir[0], dir[1], dir[2], col), e3 = b.vert(pi[i][j + 1][0], pi[i][j + 1][1], pi[i][j + 1][2], dir[0], dir[1], dir[2], col);
                quadFacing(b, e0, e1, e2, e3, po[i][j], pi[i][j], po[i][j + 1], dir);
            }
        }
    }

    private static void antenna(MeshBuilder b, float x, float y, float z, int flagCol) {
        // removed in 1.7: a toy antenna with a flag and a glowing ball does not belong on a realistic kart
    }

    private static void plate(MeshBuilder b, float x, float y, float z, float hw) {
        b.softBox(x, y, z, hw, 0.08f, 0.014f, 3f, 6, 4, WHITE, WHITE);
        b.box(x - hw * 0.4f, y, z + 0.014f, 0.025f, 0.05f, 0.004f, INK);
        b.box(x + hw * 0.4f, y, z + 0.014f, 0.025f, 0.05f, 0.004f, INK);
        b.box(x, y + 0.03f, z + 0.014f, hw * 0.35f, 0.012f, 0.004f, INK);
    }

    private static float sgnp(float v, float p) {
        float a = Math.abs(v);
        return a < 1e-6f ? 0f : (v < 0f ? -1f : 1f) * (float) Math.pow(a, p);
    }

    /** Point on the surface of a lofted body at ring angle th (0 = right flank, PI/2 = top, PI = left) and depth z, lifted along the outward normal. */
    private static void surf(float[][] sec, float z, float th, float lift, float[] out) {
        int i = 0;
        while (i + 2 < sec.length && z > sec[i + 1][0]) i++;
        float t = MathX.clamp((z - sec[i][0]) / (sec[i + 1][0] - sec[i][0]), 0f, 1f);
        float hw = sec[i][1] + (sec[i + 1][1] - sec[i][1]) * t, yb = sec[i][2] + (sec[i + 1][2] - sec[i][2]) * t, yt = sec[i][3] + (sec[i + 1][3] - sec[i][3]) * t;
        float c = (float) Math.cos(th), s = (float) Math.sin(th);
        float n = s >= 0f ? sec[i][4] + (sec[i + 1][4] - sec[i][4]) * t : sec[i][5] + (sec[i + 1][5] - sec[i][5]) * t;
        float ym = (yb + yt) * 0.5f, hh = (yt - yb) * 0.5f;
        float e = 2f / n;
        float px = hw * sgnp(c, e), py = hh * sgnp(s, e);
        float gx = sgnp(px / hw, n - 1f) / hw, gy = sgnp(py / hh, n - 1f) / hh;
        float gl = (float) Math.sqrt(gx * gx + gy * gy);
        if (gl < 1e-6f) { gx = 1f; gy = 0f; gl = 1f; }
        out[0] = px + gx / gl * lift; out[1] = ym + py + gy / gl * lift; out[2] = z;
    }

    /** A flame tongue painted on the flank of a lofted body: starts wide at zFront and tapers to a point at zBack. */
    private static void flameTongue(MeshBuilder b, float[][] sec, int side, float zFront, float zBack, float th0, float amp, float w0, float phase, int c0, int c1) {
        int n = 14;
        float[][] l = new float[n + 1][3], r = new float[n + 1][3];
        for (int i = 0; i <= n; i++) {
            float u = i / (float) n;
            float z = zFront + (zBack - zFront) * u;
            float c = th0 + amp * (float) Math.sin(u * 6.5f + phase);
            float w = w0 * (float) Math.pow(1f - u, 0.85f) * (0.8f + 0.2f * (float) Math.sin(u * 17f + phase));
            float a = c - w, bb = c + w;
            if (side < 0) { a = MathX.PI - a; bb = MathX.PI - bb; }
            surf(sec, z, a, 0.014f, l[i]);
            surf(sec, z, bb, 0.014f, r[i]);
        }
        for (int i = 0; i < n; i++) {
            int col = Col.mix(c0, c1, (i + 0.5f) / n);
            float cy = (sec[0][2] + sec[0][3]) * 0.5f;
            float[][] tri1 = {l[i], r[i], l[i + 1]}, tri2 = {r[i], r[i + 1], l[i + 1]};
            for (float[][] tr : new float[][][]{tri1, tri2}) {
                float ux = tr[1][0] - tr[0][0], uy = tr[1][1] - tr[0][1], uz = tr[1][2] - tr[0][2], vx = tr[2][0] - tr[0][0], vy = tr[2][1] - tr[0][1], vz = tr[2][2] - tr[0][2];
                float nx = uy * vz - uz * vy;
                // outward means pointing away from the body axis in x for flank decals
                boolean flip = nx * side < 0f;
                float[] p1 = flip ? tr[2] : tr[1], p2 = flip ? tr[1] : tr[2];
                b.flatTri(tr[0][0], tr[0][1], tr[0][2], p1[0], p1[1], p1[2], p2[0], p2[1], p2[2], col);
            }
        }
    }

    private static void axle(MeshBuilder b, float y, float z, float halfSpan) {
        b.tube(-halfSpan, y, z, halfSpan, y, z, 0.05f, 0.05f, 8, DARK, DARK, false);
    }

    // ---------------------------------------------------------------- 0: Dune Hopper (balanced buggy)

    private static final float[][] DUNE = {
            {-1.62f, 0.15f, 0.40f, 0.58f, 2.4f, 2.4f},
            {-1.48f, 0.34f, 0.34f, 0.66f, 2.8f, 2.6f},
            {-1.20f, 0.50f, 0.30f, 0.76f, 3.0f, 3.0f},
            {-0.80f, 0.60f, 0.30f, 0.84f, 3.2f, 3.2f},
            {-0.30f, 0.64f, 0.30f, 0.86f, 3.4f, 3.4f},
            {0.30f, 0.66f, 0.32f, 0.90f, 3.4f, 3.4f},
            {0.90f, 0.62f, 0.34f, 0.94f, 3.2f, 3.2f},
            {1.30f, 0.48f, 0.38f, 0.90f, 3.0f, 3.0f},
            {1.50f, 0.26f, 0.44f, 0.80f, 2.4f, 2.4f}};

    private static void duneHopper(MeshBuilder b) {
        int p = paint(248), pd = paint(190);
        b.loft(DUNE, 20, paint(150), p, true, true);
        topStripe(b, DUNE, -1.50f, -0.42f, 0.12f, WHITE, 0f);
        topStripe(b, DUNE, 0.86f, 1.40f, 0.12f, WHITE, 0f);
        axle(b, 0.42f, -0.95f, 0.8f);
        axle(b, 0.46f, 0.95f, 0.8f);
        for (int s = -1; s <= 1; s += 2) {
            arch(b, s * 0.84f, 0.42f, -0.95f, 0.42f, 0.34f, p, -0.95f, 1.10f);
            arch(b, s * 0.84f, 0.46f, 0.95f, 0.46f, 0.34f, p, -1.10f, 0.95f);
            headlamp(b, s * 0.27f, 0.57f, -1.47f, 0.105f);
            taillamp(b, s * 0.30f, 0.66f, 1.37f, 0.10f, 0.05f);
            // roll hoop and braces
            b.tube(s * 0.55f, 0.80f, 0.56f, s * 0.50f, 1.86f, 0.46f, 0.05f, 0.05f, 7, STEEL, CHROME, true);
            b.tube(s * 0.50f, 1.86f, 0.46f, s * 0.44f, 0.98f, 1.12f, 0.04f, 0.04f, 8, CHROME, STEEL, true);
            b.sphere(s * 0.50f, 1.86f, 0.46f, 0.055f, 7, 4, STEEL);
            // exhausts
            exhaust(b, s * 0.26f, 0.92f, 1.04f, 0f, -0.04f, 0.90f, 0.07f);
            // front strut
            b.tube(s * 0.50f, 0.50f, -1.40f, s * 0.50f, 0.44f, -1.62f, 0.035f, 0.035f, 6, STEEL, STEEL, false);
        }
        b.tube(0, 1.86f, 0.46f, 0, 1.86f, 0.46f, 0.05f, 0.05f, 8, CHROME, CHROME, false);
        b.tube(-0.50f, 1.86f, 0.46f, 0.50f, 1.86f, 0.46f, 0.05f, 0.05f, 8, CHROME, STEEL, true);
        b.tube(-0.52f, 0.46f, -1.64f, 0.52f, 0.46f, -1.64f, 0.05f, 0.05f, 8, STEEL, CHROME, true);
        // engine block with air filters behind the seat
        b.softBox(0, 0.98f, 1.02f, 0.36f, 0.15f, 0.24f, 3.2f, 12, 6, fixed(40, 44, 52), fixed(86, 92, 104));
        for (int s = -1; s <= 1; s += 2) b.cyl(s * 0.17f, 1.10f, 1.02f, 0.085f, 0.07f, 0.11f, 8, CHROME, STEEL, true, true);
        cockpit(b, 0, 0.90f, 0.22f, 0.44f, 0.56f, p);
        seatBack(b, 1.00f, 0.62f, 0.34f, 0.17f);
        steering(b, 0, 0.90f, -0.20f);
        plate(b, 0, 0.62f, 1.44f, 0.20f);
        antenna(b, 0.70f, 0.88f, 1.00f, p);
    }

    // ---------------------------------------------------------------- 1: Sand Viper (low, sleek and fast)

    private static final float[][] VIPER = {
            {-2.10f, 0.05f, 0.38f, 0.46f, 2.2f, 2.2f},
            {-1.85f, 0.15f, 0.34f, 0.50f, 2.4f, 2.4f},
            {-1.40f, 0.30f, 0.30f, 0.58f, 2.8f, 2.6f},
            {-0.80f, 0.42f, 0.28f, 0.66f, 3.0f, 3.0f},
            {-0.20f, 0.50f, 0.28f, 0.72f, 3.2f, 3.2f},
            {0.40f, 0.52f, 0.28f, 0.74f, 3.2f, 3.2f},
            {0.95f, 0.46f, 0.30f, 0.72f, 3.0f, 3.0f},
            {1.40f, 0.34f, 0.34f, 0.68f, 2.6f, 2.6f},
            {1.62f, 0.16f, 0.40f, 0.60f, 2.2f, 2.2f}};

    private static void sandViper(MeshBuilder b) {
        int p = paint(248), pd = paint(172), gold = fixed(255, 196, 40);
        b.loft(VIPER, 20, paint(150), p, true, true);
        topStripe(b, VIPER, -2.00f, -0.40f, 0.045f, gold, -0.11f);
        topStripe(b, VIPER, -2.00f, -0.40f, 0.045f, gold, 0.11f);
        topStripe(b, VIPER, 0.90f, 1.55f, 0.045f, gold, -0.11f);
        topStripe(b, VIPER, 0.90f, 1.55f, 0.045f, gold, 0.11f);
        axle(b, 0.36f, -1.05f, 0.74f);
        axle(b, 0.42f, 1.05f, 0.74f);
        for (int s = -1; s <= 1; s += 2) {
            // side pods with dark intakes bridging body and wheels
            b.softBox(s * 0.62f, 0.50f, 0.10f, 0.15f, 0.17f, 0.66f, 3f, 12, 6, pd, p);
            b.box(s * 0.62f, 0.54f, -0.46f, 0.151f, 0.07f, 0.03f, BLACK);
            arch(b, s * 0.80f, 0.36f, -1.05f, 0.36f, 0.28f, p, -0.80f, 1.05f);
            arch(b, s * 0.80f, 0.42f, 1.05f, 0.42f, 0.28f, p, -1.00f, 0.85f);
            headlamp(b, s * 0.17f, 0.50f, -1.78f, 0.075f);
            taillamp(b, s * 0.26f, 0.60f, 1.52f, 0.08f, 0.04f);
            // rear wing: pylons and end plates
            b.tube(s * 0.20f, 0.66f, 1.36f, s * 0.20f, 1.18f, 1.52f, 0.035f, 0.03f, 6, STEEL, CHROME, true);
            b.softBox(s * 0.66f, 1.22f, 1.52f, 0.025f, 0.16f, 0.24f, 3f, 6, 5, pd, pd);
            // exhausts tucked under the tail
            exhaust(b, s * 0.17f, 0.46f, 1.46f, 0f, 0.02f, 0.44f, 0.055f);
            // front wing end plates
            b.softBox(s * 0.64f, 0.38f, -1.98f, 0.025f, 0.09f, 0.17f, 3f, 6, 4, pd, pd);
        }
        b.softBox(0, 1.22f, 1.52f, 0.66f, 0.03f, 0.22f, 4f, 14, 5, pd, p);
        b.softBox(0, 0.32f, -1.98f, 0.64f, 0.025f, 0.17f, 4f, 14, 4, pd, p);
        // tinted aero screen, airbox behind the driver
        b.push().translate(0, 0.94f, -0.62f).rotX(-0.95f).softBox(0, 0, 0, 0.27f, 0.015f, 0.14f, 3f, 10, 4, GLASS, fixed(190, 226, 244)).pop();
        b.softBox(0, 1.02f, 0.86f, 0.17f, 0.20f, 0.15f, 3f, 10, 6, fixed(34, 36, 44), fixed(70, 76, 92));
        b.softBox(0, 1.02f, 0.72f, 0.12f, 0.13f, 0.03f, 3f, 8, 4, BLACK, BLACK);
        cockpit(b, 0, 0.74f, 0.25f, 0.36f, 0.50f, pd);
        steering(b, 1, 0.76f, -0.50f);
        plate(b, 0, 1.22f, 1.78f, 0.17f);
    }

    // ---------------------------------------------------------------- 2: Rock Crusher (monster truck)

    private static final float[][] CRUSH = {
            {-1.55f, 0.46f, 0.92f, 1.40f, 3.6f, 3.2f},
            {-1.40f, 0.58f, 0.90f, 1.52f, 3.8f, 3.4f},
            {-0.95f, 0.66f, 0.90f, 1.62f, 3.6f, 3.4f},
            {-0.40f, 0.68f, 0.90f, 1.66f, 3.6f, 3.4f},
            {0.20f, 0.68f, 0.90f, 1.62f, 3.6f, 3.4f},
            {0.80f, 0.68f, 0.92f, 1.58f, 3.6f, 3.4f},
            {1.30f, 0.62f, 0.94f, 1.52f, 3.6f, 3.4f},
            {1.55f, 0.50f, 0.96f, 1.46f, 3.4f, 3.2f}};

    private static void rockCrusher(MeshBuilder b) {
        int p = paint(246), pd = paint(170);
        b.loft(CRUSH, 20, paint(140), p, true, true);
        topStripe(b, CRUSH, -1.50f, -0.50f, 0.13f, WHITE, 0f);
        topStripe(b, CRUSH, 0.85f, 1.50f, 0.13f, WHITE, 0f);
        // chassis rails, axles and differentials
        for (int s = -1; s <= 1; s += 2) b.box(s * 0.42f, 0.82f, 0f, 0.07f, 0.07f, 1.45f, DARK);
        for (int z = -1; z <= 1; z += 2) {
            axle(b, 0.64f, z * 1.0f, 0.95f);
            b.sphere(0, 0.64f, z * 1.0f, 0.17f, 8, 6, fixed(66, 72, 84));
        }
        for (int s = -1; s <= 1; s += 2) {
            arch(b, s * 1.02f, 0.64f, -1.00f, 0.64f, 0.46f, p, -0.95f, 1.00f);
            arch(b, s * 1.02f, 0.64f, 1.00f, 0.64f, 0.46f, p, -1.00f, 0.95f);
            headlamp(b, s * 0.40f, 1.18f, -1.56f, 0.13f);
            headlamp(b, s * 0.40f, 0.98f, -1.62f, 0.07f);
            taillamp(b, s * 0.40f, 1.18f, 1.60f, 0.12f, 0.06f);
            // roll cage: tall rear hoop, lower front hoop, roof rails
            b.tube(s * 0.62f, 1.55f, 0.84f, s * 0.60f, 2.75f, 0.78f, 0.06f, 0.06f, 7, STEEL, CHROME, true);
            b.tube(s * 0.62f, 1.62f, -0.18f, s * 0.60f, 2.40f, -0.12f, 0.06f, 0.06f, 7, STEEL, CHROME, true);
            b.tube(s * 0.60f, 2.75f, 0.78f, s * 0.60f, 2.55f, -0.12f, 0.055f, 0.055f, 7, CHROME, CHROME, true);
            b.sphere(s * 0.60f, 2.75f, 0.78f, 0.065f, 7, 4, STEEL);
            b.sphere(s * 0.60f, 2.40f, -0.12f, 0.065f, 7, 4, STEEL);
            b.tube(s * 0.62f, 1.60f, 0.84f, s * 0.52f, 1.60f, 1.50f, 0.045f, 0.045f, 6, STEEL, STEEL, false);
            // exhaust stacks behind the cab
            exhaust(b, s * 0.44f, 1.52f, 1.18f, 0f, 1.20f, 0f, 0.075f);
            // mud flaps
            b.box(s * 1.02f, 0.46f, 1.72f, 0.20f, 0.20f, 0.015f, DARK);
            b.box(s * 1.02f, 0.46f, -1.72f, 0.20f, 0.20f, 0.015f, DARK);
        }
        b.tube(-0.60f, 2.75f, 0.78f, 0.60f, 2.75f, 0.78f, 0.055f, 0.055f, 7, CHROME, CHROME, true);
        b.tube(-0.60f, 2.40f, -0.12f, 0.60f, 2.40f, -0.12f, 0.055f, 0.055f, 7, CHROME, CHROME, true);
        // light bar on the front hoop
        b.box(0, 2.52f, -0.18f, 0.50f, 0.06f, 0.05f, DARK);
        for (int i = 0; i < 5; i++) b.sphere(-0.40f + i * 0.20f, 2.52f, -0.25f, 0.075f, 0.075f, 0.04f, 8, 5, LIGHT_DIM, LIGHT);
        // bull bar and skid plate
        b.tube(-0.52f, 1.02f, -1.68f, 0.52f, 1.02f, -1.68f, 0.07f, 0.07f, 8, STEEL, CHROME, true);
        b.tube(-0.52f, 1.42f, -1.68f, 0.52f, 1.42f, -1.68f, 0.06f, 0.06f, 8, STEEL, CHROME, true);
        for (int s = -1; s <= 1; s += 2) b.tube(s * 0.52f, 0.98f, -1.68f, s * 0.52f, 1.46f, -1.68f, 0.06f, 0.06f, 7, STEEL, CHROME, true);
        b.softBox(0, 0.96f, -1.50f, 0.42f, 0.10f, 0.22f, 3f, 10, 5, DARK, DARK);
        cockpit(b, 0, 1.60f, 0.38f, 0.50f, 0.58f, p);
        seatBack(b, 1.78f, 0.88f, 0.38f, 0.26f);
        steering(b, 2, 1.62f, -0.10f);
        plate(b, 0, 1.18f, 1.62f, 0.20f);
    }

    // ---------------------------------------------------------------- 3: Wave Runner (round, sleek hull)

    private static final float[][] WAVE = {
            {-1.75f, 0.07f, 0.40f, 0.50f, 2.2f, 2.2f},
            {-1.52f, 0.27f, 0.34f, 0.66f, 2.3f, 2.2f},
            {-1.05f, 0.47f, 0.30f, 0.80f, 2.5f, 2.4f},
            {-0.45f, 0.60f, 0.28f, 0.88f, 2.7f, 2.5f},
            {0.20f, 0.64f, 0.28f, 0.92f, 2.7f, 2.5f},
            {0.80f, 0.58f, 0.30f, 0.90f, 2.7f, 2.5f},
            {1.28f, 0.44f, 0.34f, 0.82f, 2.5f, 2.4f},
            {1.55f, 0.22f, 0.40f, 0.72f, 2.2f, 2.2f}};

    private static void waveRunner(MeshBuilder b) {
        int p = paint(248), pd = paint(176), yel = fixed(255, 214, 0);
        b.loft(WAVE, 22, paint(150), p, true, true);
        topStripe(b, WAVE, -1.60f, -0.40f, 0.05f, yel, -0.13f);
        topStripe(b, WAVE, -1.60f, -0.40f, 0.05f, yel, 0.13f);
        topStripe(b, WAVE, 0.80f, 1.45f, 0.05f, yel, -0.13f);
        topStripe(b, WAVE, 0.80f, 1.45f, 0.05f, yel, 0.13f);
        axle(b, 0.40f, -0.90f, 0.76f);
        axle(b, 0.40f, 0.90f, 0.76f);
        for (int s = -1; s <= 1; s += 2) {
            arch(b, s * 0.82f, 0.40f, -0.90f, 0.40f, 0.32f, p, -0.85f, 1.00f);
            arch(b, s * 0.82f, 0.40f, 0.90f, 0.40f, 0.32f, p, -1.00f, 0.85f);
            headlamp(b, s * 0.26f, 0.58f, -1.48f, 0.09f);
            taillamp(b, s * 0.30f, 0.62f, 1.38f, 0.09f, 0.045f);
            // small stabiliser fins at the tail corners
            b.push().translate(s * 0.50f, 0.98f, 1.20f).rotZ(-s * 0.55f).softBox(0, 0, 0, 0.025f, 0.15f, 0.20f, 3f, 6, 4, pd, p).pop();
        }
        // tall tail fin, jet nozzle, curved windscreen
        b.push().translate(0, 1.26f, 1.18f).rotX(0.50f).softBox(0, 0, 0, 0.04f, 0.36f, 0.30f, 3f, 10, 7, pd, p).pop();
        b.cyl(0, 0.54f, 1.52f, 0.10f, 0.07f, 0.0f + 0.14f, 10, DARK, BLACK, true, true);
        b.push().translate(0, 1.10f, -0.42f).rotX(-0.80f).softBox(0, 0, 0, 0.40f, 0.02f, 0.17f, 3f, 12, 4, GLASS, fixed(196, 230, 246)).pop();
        b.softBox(0, 0.36f, -1.54f, 0.24f, 0.06f, 0.20f, 3f, 10, 4, DARK, DARK);
        cockpit(b, 0, 0.90f, 0.30f, 0.42f, 0.52f, pd);
        seatBack(b, 1.04f, 0.74f, 0.34f, 0.16f);
        steering(b, 3, 0.90f, -0.20f);
        plate(b, 0, 0.60f, 1.52f, 0.14f);
    }

    // ---------------------------------------------------------------- 4: Lava Rod (hot rod with a blown engine)

    private static final float[][] ROD = {
            {-1.95f, 0.10f, 0.48f, 0.64f, 2.4f, 2.4f},
            {-1.70f, 0.28f, 0.42f, 0.74f, 2.8f, 2.6f},
            {-1.20f, 0.40f, 0.38f, 0.84f, 3.0f, 3.0f},
            {-0.60f, 0.44f, 0.36f, 0.90f, 3.2f, 3.0f},
            {-0.10f, 0.54f, 0.36f, 0.94f, 3.2f, 3.0f},
            {0.50f, 0.60f, 0.36f, 1.00f, 3.0f, 3.0f},
            {1.00f, 0.62f, 0.38f, 1.06f, 3.0f, 3.0f},
            {1.40f, 0.50f, 0.42f, 1.04f, 2.8f, 2.8f},
            {1.64f, 0.26f, 0.46f, 0.94f, 2.4f, 2.4f}};

    private static void lavaRod(MeshBuilder b) {
        int p = paint(248), pd = paint(176);
        int fl0 = fixed(255, 106, 20), fl1 = fixed(255, 214, 60);
        b.loft(ROD, 22, paint(150), p, true, true);
        axle(b, 0.36f, -1.00f, 0.80f);
        axle(b, 0.52f, 1.00f, 0.80f);
        for (int s = -1; s <= 1; s += 2) {
            // flames licking back along the hood and flanks
            flameTongue(b, ROD, s, -1.82f, -0.25f, 0.02f, 0.10f, 0.60f, 0.0f, fl0, fl1);
            flameTongue(b, ROD, s, -1.75f, -0.55f, 0.78f, 0.08f, 0.34f, 1.7f, fl0, fl1);
            flameTongue(b, ROD, s, -1.75f, -0.62f, -0.62f, 0.08f, 0.30f, 3.1f, fl0, fl1);
            arch(b, s * 0.86f, 0.52f, 1.00f, 0.52f, 0.34f, p, -1.10f, 0.95f);
            // side pipes
            b.tube(s * 0.62f, 0.44f, -1.10f, s * 0.62f, 0.44f, 0.85f, 0.055f, 0.055f, 8, STEEL, CHROME, true);
            for (int k = 0; k < 4; k++) b.tube(s * 0.46f, 0.72f + k * 0.02f, -1.30f + k * 0.26f, s * 0.60f, 0.46f, -1.30f + k * 0.26f, 0.035f, 0.035f, 5, CHROME, STEEL, false);
            headlamp(b, s * 0.34f, 0.74f, -1.62f, 0.10f);
            taillamp(b, s * 0.32f, 0.70f, 1.52f, 0.10f, 0.05f);
            // tail fins and front springs
            b.push().translate(s * 0.50f, 1.12f, 1.26f).rotZ(-s * 0.35f).softBox(0, 0, 0, 0.03f, 0.16f, 0.24f, 3f, 6, 4, pd, p).pop();
            b.tube(s * 0.55f, 0.38f, -1.00f, s * 0.80f, 0.38f, -1.00f, 0.03f, 0.03f, 5, DARK, DARK, false);
        }
        // blown engine on the hood: chrome blower, intake and air filters
        b.softBox(0, 1.02f, -0.92f, 0.22f, 0.14f, 0.34f, 3f, 12, 6, fixed(104, 110, 122), fixed(196, 202, 214));
        b.softBox(0, 1.20f, -0.92f, 0.12f, 0.06f, 0.20f, 3f, 10, 5, BLACK, fixed(50, 52, 60));
        for (int i = 0; i < 3; i++) b.cyl(0, 0.92f, -1.14f + i * 0.20f, 0.0f + 0.09f, 0.08f, 0.0f + 0.08f, 8, STEEL, CHROME, false, true);
        // front bumper and grille
        b.tube(-0.38f, 0.50f, -1.98f, 0.38f, 0.50f, -1.98f, 0.045f, 0.045f, 7, STEEL, CHROME, true);
        b.softBox(0, 0.56f, -1.94f, 0.17f, 0.10f, 0.05f, 3f, 8, 4, DARK, BLACK);
        cockpit(b, 0, 1.01f, 0.52f, 0.42f, 0.52f, p);
        seatBack(b, 1.26f, 0.98f, 0.36f, 0.24f);
        // chrome roll hoop
        for (int s = -1; s <= 1; s += 2) b.tube(s * 0.46f, 0.98f, 0.98f, s * 0.42f, 1.78f, 1.04f, 0.045f, 0.045f, 7, STEEL, CHROME, true);
        b.tube(-0.42f, 1.78f, 1.04f, 0.42f, 1.78f, 1.04f, 0.045f, 0.045f, 7, CHROME, STEEL, true);
        steering(b, 4, 1.02f, -0.05f);
        plate(b, 0, 0.72f, 1.68f, 0.18f);
    }

    private static float[] reverse(float[] a) {
        float[] r = new float[a.length];
        for (int i = 0; i < a.length; i++) r[i] = a[a.length - 1 - i];
        return r;
    }

    // ---------------------------------------------------------------- 5: Jungle Rover (safari jeep)

    private static final float[][] ROVER = {
            {-1.60f, 0.42f, 0.56f, 0.94f, 3.8f, 3.4f},
            {-1.46f, 0.60f, 0.52f, 1.02f, 3.8f, 3.6f},
            {-1.00f, 0.70f, 0.50f, 1.08f, 3.8f, 3.6f},
            {-0.30f, 0.74f, 0.50f, 1.12f, 3.8f, 3.6f},
            {0.40f, 0.74f, 0.50f, 1.10f, 3.8f, 3.6f},
            {1.00f, 0.74f, 0.52f, 1.08f, 3.8f, 3.6f},
            {1.42f, 0.70f, 0.54f, 1.04f, 3.8f, 3.6f},
            {1.54f, 0.60f, 0.56f, 0.98f, 3.8f, 3.4f}};

    private static void jungleRover(MeshBuilder b) {
        int p = paint(248), pd = paint(176);
        int canvas = fixed(214, 188, 134), canvasD = fixed(170, 146, 100), olive = fixed(86, 96, 60);
        b.loft(ROVER, 20, paint(150), p, true, true);
        // dark cladding rails along the flanks
        for (int s = -1; s <= 1; s += 2) {
            b.softBox(s * 0.75f, 0.66f, 0.05f, 0.035f, 0.075f, 1.30f, 3f, 6, 5, DARK, DARK);
            arch(b, s * 0.94f, 0.52f, -1.00f, 0.52f, 0.38f, p, -0.95f, 1.00f);
            arch(b, s * 0.94f, 0.52f, 1.00f, 0.52f, 0.38f, p, -1.00f, 0.95f);
            headlamp(b, s * 0.46f, 0.80f, -1.62f, 0.13f);
            taillamp(b, s * 0.50f, 0.80f, 1.55f, 0.10f, 0.055f);
            // safari cage with a canvas roof
            b.tube(s * 0.74f, 1.08f, 0.86f, s * 0.72f, 2.50f, 0.80f, 0.05f, 0.05f, 7, olive, olive, true);
            b.tube(s * 0.74f, 1.12f, -0.34f, s * 0.72f, 2.42f, -0.28f, 0.05f, 0.05f, 7, olive, olive, true);
            b.tube(s * 0.72f, 2.50f, 0.80f, s * 0.72f, 2.42f, -0.28f, 0.045f, 0.045f, 7, olive, olive, true);
            b.sphere(s * 0.72f, 2.50f, 0.80f, 0.055f, 7, 4, olive);
            b.sphere(s * 0.72f, 2.42f, -0.28f, 0.055f, 7, 4, olive);
            // extra lamps on the bull bar
            b.sphere(s * 0.74f, 0.66f, -1.64f, 0.075f, 0.075f, 0.04f, 8, 5, LIGHT_DIM, LIGHT);
        }
        b.push().translate(0, 2.54f, 0.26f).rotX(0.0f).softBox(0, 0, 0, 0.88f, 0.045f, 1.12f, 4f, 14, 5, canvasD, canvas).pop();
        for (int i = -2; i <= 2; i++) b.box(i * 0.28f, 2.60f, 0.26f, 0.045f, 0.008f, 1.02f, fixed(240, 228, 196));
        b.tube(-0.72f, 2.46f, 0.80f, 0.72f, 2.46f, 0.80f, 0.045f, 0.045f, 7, olive, olive, true);
        b.tube(-0.72f, 2.38f, -0.28f, 0.72f, 2.38f, -0.28f, 0.045f, 0.045f, 7, olive, olive, true);
        // windscreen frame with glass
        b.tube(-0.66f, 1.92f, -0.62f, 0.66f, 1.92f, -0.62f, 0.035f, 0.035f, 6, olive, olive, true);
        b.tube(-0.66f, 1.14f, -0.40f, -0.66f, 1.92f, -0.62f, 0.035f, 0.035f, 6, olive, olive, true);
        b.tube(0.66f, 1.14f, -0.40f, 0.66f, 1.92f, -0.62f, 0.035f, 0.035f, 6, olive, olive, true);
        // grille, bull bar and winch
        for (int i = 0; i < 4; i++) b.box(0, 0.62f + i * 0.08f, -1.61f, 0.30f, 0.025f, 0.02f, BLACK);
        b.tube(-0.74f, 0.60f, -1.72f, 0.74f, 0.60f, -1.72f, 0.06f, 0.06f, 8, STEEL, CHROME, true);
        b.softBox(0, 0.48f, -1.66f, 0.20f, 0.09f, 0.10f, 3f, 8, 4, DARK, DARK);
        // spare tyre on the back, snorkel up the right pillar
        b.push().translate(0, 1.00f, 1.74f).rotX(MathX.PI / 2f).torus(0, 0, 0, 0.36f, 0.15f, 16, 7, fixed(32, 32, 36)).pop();
        b.push().translate(0, 1.00f, 1.80f).rotX(MathX.PI / 2f).cyl(0, 0, 0, 0.26f, 0.26f, 0.02f, 12, pd, p, true, true).pop();
        b.tube(0.80f, 0.90f, -0.78f, 0.84f, 2.30f, -0.78f, 0.05f, 0.05f, 7, BLACK, DARK, true);
        b.tube(0.84f, 2.30f, -0.78f, 0.84f, 2.40f, -0.60f, 0.05f, 0.05f, 7, DARK, BLACK, true);
        cockpit(b, 0, 1.10f, 0.30f, 0.50f, 0.58f, p);
        seatBack(b, 1.34f, 0.82f, 0.38f, 0.24f);
        steering(b, 5, 1.12f, -0.30f);
        plate(b, 0, 0.74f, 1.56f, 0.20f);
        antenna(b, -0.78f, 1.10f, 1.30f, p);
    }

    // ---------------------------------------------------------------- wheels

    public static MeshData wheel(int type, boolean rear) {
        int t = Math.floorMod(type, TYPES);
        float r = rear ? REAR_R[t] : FRONT_R[t], w = WHEEL_W[t];
        MeshBuilder b = new MeshBuilder();
        boolean off = t == 2 || t == 5;
        int rubber = fixed(24, 24, 27), wall = fixed(38, 38, 42), groove = fixed(12, 12, 14), lug = fixed(44, 44, 48);
        float h = w * 0.5f, cr = w * 0.22f, rimR = r * (off ? 0.54f : 0.64f);
        // tyre: convex side walls, rounded shoulders, flat tread
        ArrayList<float[]> prof = new ArrayList<>();
        ArrayList<Integer> pc = new ArrayList<>();
        prof.add(new float[]{rimR * 0.97f, -h * 0.80f}); pc.add(rubber);
        prof.add(new float[]{rimR + (r - rimR) * 0.35f, -h * 0.97f}); pc.add(wall);
        prof.add(new float[]{rimR + (r - rimR) * 0.70f, -h}); pc.add(wall);
        for (int i = 0; i <= 4; i++) {
            float a = -MathX.PI / 2f + (MathX.PI / 2f) * i / 4f;
            prof.add(new float[]{r - cr + cr * (float) Math.cos(a), -h + cr + cr * (float) Math.sin(a)}); pc.add(i < 2 ? wall : rubber);
        }
        for (int i = 0; i <= 4; i++) {
            float a = (MathX.PI / 2f) * i / 4f;
            prof.add(new float[]{r - cr + cr * (float) Math.cos(a), h - cr + cr * (float) Math.sin(a)}); pc.add(i > 2 ? wall : rubber);
        }
        prof.add(new float[]{rimR + (r - rimR) * 0.70f, h}); pc.add(wall);
        prof.add(new float[]{rimR + (r - rimR) * 0.35f, h * 0.97f}); pc.add(wall);
        prof.add(new float[]{rimR * 0.97f, h * 0.80f}); pc.add(rubber);
        int[] cols = new int[pc.size()];
        for (int i = 0; i < cols.length; i++) cols[i] = pc.get(i);
        b.push().rotZ(MathX.PI / 2f).lathe(0, 0, 0, prof.toArray(new float[0][]), 18, cols).pop();
        if (!off) {
            // road tyre: circumferential grooves
            b.push().rotZ(MathX.PI / 2f).torus(0, 0, 0, r - 0.004f, 0.010f, 20, 3, groove).pop();
        } else {
            // off-road tyre: two staggered rows of lugs
            int blocks = t == 2 ? 14 : 12;
            for (int i = 0; i < blocks; i++) for (int sd = -1; sd <= 1; sd += 2) {
                float a = MathX.TAU * (i + (sd > 0 ? 0.5f : 0f)) / blocks;
                b.push().rotX(a).translate(0, r, 0).box(sd * w * 0.21f, 0.010f, 0, w * 0.19f, 0.040f, r * 0.10f, lug).pop();
            }
        }
        // alloy rim: barrel, polished lip, spokes, hub with lug nuts, brake disc and caliper behind the spokes
        int alloy = off ? fixed(86, 90, 100) : fixed(190, 194, 202), alloyD = Col.scale(alloy, 0.5f), steelC = fixed(150, 154, 162);
        b.push().rotZ(MathX.PI / 2f).cyl(0, -h * 0.84f, 0, rimR, rimR, h * 1.68f, 14, alloyD, alloyD, true, true).pop();
        for (int sd = -1; sd <= 1; sd += 2) {
            float fx = sd * h * 0.86f;
            b.push().rotZ(MathX.PI / 2f).translate(0, -fx, 0).torus(0, 0, 0, rimR, 0.018f, 14, 3, off ? steelC : fixed(214, 218, 224)).pop();
            b.push().rotZ(MathX.PI / 2f).translate(0, -sd * h * 0.52f, 0).cyl(0, -0.012f, 0, rimR * 0.80f, rimR * 0.80f, 0.024f, 14, fixed(96, 98, 104), fixed(120, 122, 130), true, true).pop();
            if (!off) b.push().rotZ(MathX.PI / 2f).translate(0, -sd * h * 0.56f, 0).rotY(0.6f).softBox(0, 0, rimR * 0.60f, 0.05f, 0.04f, 0.10f, 3f, 6, 4, fixed(188, 28, 34), fixed(226, 50, 54)).pop();
            int n = off ? 6 : 8;
            for (int i = 0; i < n; i++) {
                float a = MathX.TAU * i / n + (sd > 0 ? 0f : 0.3f);
                b.push().rotZ(MathX.PI / 2f).translate(0, -fx, 0).rotY(a).box(0, 0, rimR * 0.52f, off ? 0.040f : 0.022f, 0.012f, rimR * 0.44f, alloy).pop();
            }
            b.push().rotZ(MathX.PI / 2f).translate(0, -fx, 0).cyl(0, -0.02f, 0, rimR * 0.22f, rimR * 0.20f, 0.05f, 10, alloy, steelC, true, true).pop();
            for (int i = 0; i < 4; i++) {
                float a = MathX.TAU * i / 4f;
                b.push().rotZ(MathX.PI / 2f).translate(0, -fx - sd * 0.02f, 0).rotY(a).translate(0, 0, rimR * 0.13f).cyl(0, 0, 0, 0.015f, 0.015f, 0.02f, 4, steelC, steelC, true, true).pop();
            }
        }
        return b.build();
    }

    // ---------------------------------------------------------------- drivers

    private static final int[] SKIN = {0xFFD6AA, 0x8D5C3C, 0xFFC8A0, 0xDCAA78, 0x5A3C28, 0xFADCBE};
    private static final int[] SHIRT = {0xE63C32, 0xFABE28, 0x3278E6, 0x3CBE6E, 0xB450DC, 0xF07828};

    /** Polyline of small tubes (with round joints) through the given points. */
    private static void path(MeshBuilder b, float[][] pts, float r, int color) {
        for (int i = 0; i + 1 < pts.length; i++) b.tube(pts[i][0], pts[i][1], pts[i][2], pts[i + 1][0], pts[i + 1][1], pts[i + 1][2], r, r, 5, color, color, false);
        for (float[] p : pts) b.sphere(p[0], p[1], p[2], r, 5, 3, color);
    }

    /** Arc in the YZ plane (a = 0 front, PI/2 top, PI back) on an ellipsoid of radii (ry, rz), centred at (cx, cy, cz). */
    private static void arcYZ(MeshBuilder b, float cx, float cy, float cz, float ry, float rz, float a0, float a1, float r, int color, int n) {
        float[][] pts = new float[n + 1][];
        for (int i = 0; i <= n; i++) {
            float a = a0 + (a1 - a0) * i / n;
            pts[i] = new float[]{cx, cy + ry * (float) Math.sin(a), cz - rz * (float) Math.cos(a)};
        }
        path(b, pts, r, color);
    }

    private static float[] sph(float cx, float cy, float cz, float rx, float ry, float rz, float ph, float th) {
        return new float[]{cx + rx * (float) (Math.cos(ph) * Math.cos(th)), cy + ry * (float) Math.sin(ph), cz + rz * (float) (Math.cos(ph) * Math.sin(th))};
    }

    /** Open-face racing helmet (or hair cap): dome with the face window cut out and a trim band along the opening. */
    private static void helmet(MeshBuilder b, float cx, float cy, float cz, float rad, int shell, int trim, float phi0, int kW) {
        int segs = 20, rings = 7;
        b.domeOpen(cx, cy, cz, rad, rad, rad, segs, rings, phi0, Col.scale(shell, 0.74f), shell, 12, 18, kW);
        float step = (MathX.PI / 2f - phi0) / rings;
        float rr = rad * 1.006f;
        float topPh = phi0 + step * kW;
        float thL = MathX.TAU * 12f / segs, thR = MathX.TAU * 18f / segs;
        java.util.ArrayList<float[]> l = new java.util.ArrayList<>();
        l.add(sph(cx, cy, cz, rr, rr, rr, phi0, thL));
        l.add(sph(cx, cy, cz, rr, rr, rr, topPh, thL));
        for (int i = 13; i <= 17; i++) l.add(sph(cx, cy, cz, rr, rr, rr, topPh, MathX.TAU * i / segs));
        l.add(sph(cx, cy, cz, rr, rr, rr, topPh, thR));
        l.add(sph(cx, cy, cz, rr, rr, rr, phi0, thR));
        path(b, l.toArray(new float[0][]), 0.02f, trim);
        // rubber trim around the back of the bottom edge
        java.util.ArrayList<float[]> bk = new java.util.ArrayList<>();
        for (int i = 18; i <= 32; i += 2) bk.add(sph(cx, cy, cz, rr, rr, rr, phi0, MathX.TAU * i / segs));
        path(b, bk.toArray(new float[0][]), 0.02f, trim);
    }

    /** Driver in seat space: origin at the seat, forward -Z. */
    private static final int[] SUIT = {0xC9302A, 0xE0A02A, 0x2F67C8, 0x2E9C5A, 0x8A3FB0, 0xD9651E};
    private static final int[] STRIPE = {0xF4F4F4, 0xE8508A, 0x1F5FBF, 0xF6F6F6, 0x8A3FC0, 0xF2C230};

    private static int fx(int hex, float k) {
        return Col.rgba(MathX.clamp((int) (((hex >> 16) & 255) * k), 0, 255), MathX.clamp((int) (((hex >> 8) & 255) * k), 0, 255), MathX.clamp((int) ((hex & 255) * k), 0, 255), 0);
    }

    /** Curved patch on an ellipsoid (helmet visor, stripes): th = angle around the vertical axis (0 = front, -Z), ph = elevation. */
    private static void ellipsoidPatch(MeshBuilder b, float cx, float cy, float cz, float rx, float ry, float rz, float th0, float th1, float ph0, float ph1, int nt, int np, float lift, int col) {
        ellipsoidPatch(b, cx, cy, cz, rx, ry, rz, th0, th1, ph0, ph1, nt, np, lift, col, 0f);
    }

    private static void ellipsoidPatch(MeshBuilder b, float cx, float cy, float cz, float rx, float ry, float rz, float th0, float th1, float ph0, float ph1, int nt, int np, float lift, int col, float pinch) {
        int[][] g = new int[np + 1][nt + 1];
        for (int j = 0; j <= np; j++) {
            for (int i = 0; i <= nt; i++) {
                float th = th0 + (th1 - th0) * i / nt;
                float u = (th0 + th1) * 0.5f == 0f ? Math.abs(th) / Math.max(1e-4f, Math.max(Math.abs(th0), Math.abs(th1))) : 0f;
                float pm = (ph0 + ph1) * 0.5f, ph_half = (ph1 - ph0) * 0.5f * (1f - pinch * u * u);
                float ph = pm - ph_half + 2f * ph_half * j / np;
                float ux = (float) (Math.cos(ph) * Math.sin(th)), uy = (float) Math.sin(ph), uz = (float) (-Math.cos(ph) * Math.cos(th));
                g[j][i] = b.vert(cx + rx * (1f + lift) * ux, cy + ry * (1f + lift) * uy, cz + rz * (1f + lift) * uz, ux / rx, uy / ry, uz / rz, col);
            }
        }
        for (int j = 0; j < np; j++) for (int i = 0; i < nt; i++) {
            int a = g[j][i], bb = g[j][i + 1], c = g[j + 1][i], d = g[j + 1][i + 1];
            b.tri(a, c, bb);
            b.tri(bb, c, d);
        }
    }

    // ---------------------------------------------------------------- smooth driver figure

    private static float[] cross3(float ax, float ay, float az, float bx, float by, float bz) {
        return new float[]{ay * bz - az * by, az * bx - ax * bz, ax * by - ay * bx};
    }

    private static float[] norm3(float[] v) {
        float l = (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        if (l < 1e-9f) return new float[]{0f, 1f, 0f};
        return new float[]{v[0] / l, v[1] / l, v[2] / l};
    }

    /** Catmull-Rom point (components) between p1 and p2 at t, with neighbours p0 and p3. */
    private static float cr(float p0, float p1, float p2, float p3, float t) {
        return 0.5f * ((2f * p1) + (-p0 + p2) * t + (2f * p0 - 5f * p1 + 4f * p2 - p3) * t * t + (-p0 + 3f * p1 - 3f * p2 + p3) * t * t * t);
    }

    /**
     * One continuous skin along a smooth curve through the control points, with an elliptical section (rx across, rz along the reference direction)
     * and a colour per control point. Used for the torso, arms, hands and legs so the figure is a few smooth shapes instead of overlapping balls.
     */
    private static void sweep(MeshBuilder b, float[][] pts, float[][] rad, int[] cols, float[] ref, int segs, int sub, boolean capEnd) {
        int n = pts.length, rings = (n - 1) * sub + 1;
        float[][] P = new float[rings][3], R = new float[rings][2];
        int[] C = new int[rings];
        for (int r = 0; r < rings; r++) {
            int seg = Math.min(n - 2, r / sub);
            float t = r == rings - 1 ? 1f : (r % sub) / (float) sub;
            if (r == rings - 1) seg = n - 2;
            int i0 = Math.max(0, seg - 1), i1 = seg, i2 = seg + 1, i3 = Math.min(n - 1, seg + 2);
            for (int c = 0; c < 3; c++) P[r][c] = cr(pts[i0][c], pts[i1][c], pts[i2][c], pts[i3][c], t);
            for (int c = 0; c < 2; c++) R[r][c] = pts[0].length > 0 ? rad[i1][c] + (rad[i2][c] - rad[i1][c]) * t : 0f;
            C[r] = Col.mix(cols[i1], cols[i2], t);
        }
        int[][] g = new int[rings][segs + 1];
        float[] prevS = null;
        for (int r = 0; r < rings; r++) {
            int ra = Math.max(0, r - 1), rb = Math.min(rings - 1, r + 1);
            float[] T = norm3(new float[]{P[rb][0] - P[ra][0], P[rb][1] - P[ra][1], P[rb][2] - P[ra][2]});
            float[] S0 = cross3(ref[0], ref[1], ref[2], T[0], T[1], T[2]);
            if (S0[0] * S0[0] + S0[1] * S0[1] + S0[2] * S0[2] < 1e-6f) S0 = cross3(1f, 0f, 0f, T[0], T[1], T[2]);
            float[] S = norm3(S0);
            if (prevS != null && S[0] * prevS[0] + S[1] * prevS[1] + S[2] * prevS[2] < 0f) { S[0] = -S[0]; S[1] = -S[1]; S[2] = -S[2]; }
            prevS = S;
            float[] V = cross3(T[0], T[1], T[2], S[0], S[1], S[2]);
            for (int k = 0; k <= segs; k++) {
                float th = MathX.TAU * (k % segs) / segs;
                float ct = (float) Math.cos(th), st = (float) Math.sin(th);
                float rx = Math.max(R[r][0], 1e-4f), rz = Math.max(R[r][1], 1e-4f);
                float x = P[r][0] + S[0] * rx * ct + V[0] * rz * st, y = P[r][1] + S[1] * rx * ct + V[1] * rz * st, z = P[r][2] + S[2] * rx * ct + V[2] * rz * st;
                float nx = S[0] * ct / rx + V[0] * st / rz, ny = S[1] * ct / rx + V[1] * st / rz, nz = S[2] * ct / rx + V[2] * st / rz;
                float nl = (float) Math.sqrt(nx * nx + ny * ny + nz * nz); nx /= nl; ny /= nl; nz /= nl;
                g[r][k] = b.vert(x, y, z, nx, ny, nz, C[r]);
            }
        }
        for (int r = 0; r + 1 < rings; r++) for (int k = 0; k < segs; k++) {
            // the section angle runs counter clockwise round the path direction, so this order faces outward
            b.tri(g[r][k], g[r][k + 1], g[r + 1][k]);
            b.tri(g[r][k + 1], g[r + 1][k + 1], g[r + 1][k]);
        }
        if (capEnd) {
            float[] e = P[rings - 1];
            int[] ring = g[rings - 1];
            float[] T = norm3(new float[]{P[rings - 1][0] - P[rings - 2][0], P[rings - 1][1] - P[rings - 2][1], P[rings - 1][2] - P[rings - 2][2]});
            int cen = b.vert(e[0], e[1], e[2], T[0], T[1], T[2], C[rings - 1]);
            for (int k = 0; k < segs; k++) b.tri(cen, ring[k], ring[k + 1]);
        }
    }

    /** Surface of the helmet shell: an ellipsoid with a flattened underside, an angular chin bar, a rear tail and ear bulges, as one smooth function. */
    private static float[] helmetSurface(float th, float ph, float lift) {
        float rx = 0.205f, ry = 0.235f, rz = 0.275f;
        float cph = (float) Math.cos(ph), sph = (float) Math.sin(ph), sth = (float) Math.sin(th), cth = (float) Math.cos(th);
        float x = rx * cph * sth, y = ry * sph, z = -rz * cph * cth;
        if (ph < 0f) { y *= 0.80f; float k = 1f - 0.12f * (float) Math.pow(-sph, 2.0); x *= k; z *= k; }
        float thw = (float) Math.atan2(sth, cth);                                   // -pi..pi, 0 = front
        float front = (float) Math.exp(-thw * thw / 0.50f);
        float chin = (float) Math.exp(-((ph + 0.66f) * (ph + 0.66f)) / 0.16f);
        z -= 0.075f * front * chin; y -= 0.030f * front * chin; x *= 1f + 0.10f * front * chin;
        float dr = (float) (Math.PI - Math.abs(thw));
        float rear = (float) Math.exp(-dr * dr / 0.40f) * (float) Math.exp(-((ph + 0.15f) * (ph + 0.15f)) / 0.22f);
        z += 0.045f * rear;
        float da = Math.abs(thw) - 1.55f;
        float ear = (float) Math.exp(-da * da / 0.10f) * (float) Math.exp(-((ph + 0.04f) * (ph + 0.04f)) / 0.10f);
        x += Math.signum(x) * 0.022f * ear;
        float top = (float) Math.exp(-thw * thw / 0.35f) * (float) Math.exp(-((ph - 1.05f) * (ph - 1.05f)) / 0.12f);
        y += 0.012f * top;
        if (lift != 0f) {
            float[] n = helmetNormal(th, ph);
            x += n[0] * lift; y += n[1] * lift; z += n[2] * lift;
        }
        return new float[]{x, y, z};
    }

    private static float[] helmetNormal(float th, float ph) {
        float e = 0.012f;
        float[] a = helmetSurface(th + e, ph, 0f), c = helmetSurface(th - e, ph, 0f), d = helmetSurface(th, ph + e, 0f), f = helmetSurface(th, ph - e, 0f);
        float[] n = cross3(a[0] - c[0], a[1] - c[1], a[2] - c[2], d[0] - f[0], d[1] - f[1], d[2] - f[2]);
        float[] c0 = helmetSurface(th, ph, 0f);
        float[] nn = norm3(n);
        // outward: away from the helmet centre
        if (nn[0] * c0[0] + nn[1] * (c0[1] - 0.0f) + nn[2] * c0[2] < 0f) { nn[0] = -nn[0]; nn[1] = -nn[1]; nn[2] = -nn[2]; }
        return nn;
    }

    /** A patch of the helmet surface (shell, visor, stripes): th0..th1 around, ph0..ph1 up, pinch makes the rows shorter toward the sides. */
    private static void helmetPatch(MeshBuilder b, float cx, float cy, float cz, float th0, float th1, float ph0, float ph1, int nt, int np, float lift, int colBot, int colTop, float pinch) {
        int[][] g = new int[np + 1][nt + 1];
        float thMid = (th0 + th1) * 0.5f, thHalf = (th1 - th0) * 0.5f;
        for (int j = 0; j <= np; j++) for (int i = 0; i <= nt; i++) {
            float th = th0 + (th1 - th0) * i / nt;
            float u = thHalf > 1e-4f ? Math.abs(th - thMid) / thHalf : 0f;
            float pm = (ph0 + ph1) * 0.5f, ph_half = (ph1 - ph0) * 0.5f * (1f - pinch * u * u);
            float ph = pm - ph_half + 2f * ph_half * j / np;
            float[] p = helmetSurface(th, ph, lift), n = helmetNormal(th, ph);
            float v = (j) / (float) np;
            g[j][i] = b.vert(cx + p[0], cy + p[1], cz + p[2], n[0], n[1], n[2], Col.mix(colBot, colTop, MathX.sat((p[1] + 0.25f) / 0.5f)));
        }
        for (int j = 0; j < np; j++) for (int i = 0; i < nt; i++) {
            int a = g[j][i], bb = g[j][i + 1], c = g[j + 1][i], d = g[j + 1][i + 1];
            b.tri(a, c, bb);
            b.tri(bb, c, d);
        }
    }

    /** Full face race helmet as one smooth shell in the kart colour, with a lens shaped mirror visor, vents, a wing and a livery stripe. */
    private static void helmet(MeshBuilder b, float cx, float hy, float cz, int stripe, int black, int steelC) {
        int shB = Col.rgba(150, 150, 150, 255), shT = Col.rgba(255, 255, 255, 255);
        float PI = MathX.PI;
        helmetPatch(b, cx, hy, cz, -PI, PI, -1.52f, 1.5707f, 30, 17, 0f, shB, shT, 0f);                               // the shell
        helmetPatch(b, cx, hy, cz, -1.34f, 1.34f, -0.30f, 0.52f, 20, 5, 0.004f, black, black, 0.60f);                    // visor seal
        helmetPatch(b, cx, hy, cz, -1.26f, 1.26f, -0.22f, 0.45f, 20, 5, 0.010f, Col.rgba(30, 40, 54, 255), Col.rgba(54, 70, 92, 255), 0.60f);   // smoked mirror visor
        helmetPatch(b, cx, hy, cz, -0.09f, 0.09f, 0.50f, 1.50f, 2, 8, 0.006f, stripe, stripe, 0f);                      // stripe, front
        helmetPatch(b, cx, hy, cz, PI - 0.09f, PI + 0.09f, 0.20f, 1.50f, 2, 8, 0.006f, stripe, stripe, 0f);             // stripe, rear
        for (int sd = -1; sd <= 1; sd += 2) helmetPatch(b, cx, hy, cz, sd * 1.70f - 0.05f, sd * 1.70f + 0.05f, -0.50f, 0.90f, 2, 6, 0.006f, stripe, stripe, 0f);   // side stripes
        helmetPatch(b, cx, hy, cz, -0.30f, 0.30f, -0.99f, -0.84f, 6, 2, 0.010f, black, black, 0f);                      // breath box on the chin
        helmetPatch(b, cx, hy, cz, -0.20f, 0.20f, 1.16f, 1.34f, 5, 2, 0.012f, black, black, 0f);                         // top intake
        helmetPatch(b, cx, hy, cz, PI - 0.28f, PI + 0.28f, -0.34f, -0.12f, 6, 2, 0.010f, black, black, 0f);             // rear vent
        b.softBox(cx, hy + 0.085f, cz + 0.30f, 0.105f, 0.008f, 0.058f, 3f, 8, 2, stripe, stripe);                         // rear wing
        for (int sd = -1; sd <= 1; sd += 2) {
            float[] pv = helmetSurface(sd * 1.36f, 0.12f, 0.012f);
            b.cyl(cx + pv[0] - sd * 0.004f, hy + pv[1] - 0.014f, cz + pv[2], 0.022f, 0.022f, 0.012f, 8, steelC, steelC, true, true);   // visor pivots
        }
        b.torus(cx, hy - 0.205f, cz - 0.01f, 0.118f, 0.138f, 0.022f, 18, 4, black);                                       // rubber edge round the neck opening
    }

    /** Racing driver in seat space (origin at the seat, forward -Z): one smooth torso, smooth arms and legs, gripping gloves, harness and a one piece helmet. */
    /** The sculpted driver (tools/model/make_driver.py); falls back to the procedural figure if the model file is missing. */
    public static MeshData driver(int id) {
        int d = Math.floorMod(id, DRIVERS);
        int[] pal = {
                fx(SUIT[d], 1f),                  // 0 suit
                fx(STRIPE[d], 1f),                // 1 stripe
                fixed(34, 35, 40),                // 2 glove
                Col.rgba(255, 255, 255, 255),     // 3 helmet shell: kart paint, glossy
                Col.rgba(34, 46, 62, 255),        // 4 mirror visor
                fixed(24, 26, 30),                // 5 black trim
                fixed(176, 182, 192),             // 6 steel
                fixed(238, 238, 234),             // 7 number patch
                fixed(28, 30, 34),                // 8 belt
                fx(SUIT[d], 0.66f)};              // 9 dark suit
        MeshData m = BakedModels.load("driver", pal);
        return m != null ? m : driverProcedural(id);
    }

    private static MeshData driverProcedural(int id) {
        int d = Math.floorMod(id, DRIVERS);
        MeshBuilder b = new MeshBuilder();
        int suit = fx(SUIT[d], 1f), suitD = fx(SUIT[d], 0.66f), suitL = fx(SUIT[d], 1.14f), stripe = fx(STRIPE[d], 1f);
        int black = fixed(24, 26, 30), glove = fixed(34, 35, 40), steelC = fixed(176, 182, 192), belt = fixed(28, 30, 34), skin = fixed(176, 138, 112), white = fixed(238, 238, 234);
        float[] upZ = {0f, 0f, 1f};
        // torso, neck and collar: one skin from the pelvis to the neck (width across, depth front to back)
        sweep(b, new float[][]{{0f, 0.02f, 0.10f}, {0f, 0.20f, 0.07f}, {0f, 0.38f, 0.03f}, {0f, 0.52f, 0.02f}, {0f, 0.595f, 0.02f}, {0f, 0.655f, 0.015f}, {0f, 0.76f, 0.0f}},
                new float[][]{{0.23f, 0.20f}, {0.215f, 0.165f}, {0.28f, 0.175f}, {0.315f, 0.16f}, {0.305f, 0.125f}, {0.15f, 0.105f}, {0.098f, 0.092f}},
                new int[]{suitD, suitD, suit, suitL, suitL, suitD, suitD}, upZ, 18, 3, false);
        // hips and thighs under the cowl
        for (int sd = -1; sd <= 1; sd += 2)
            sweep(b, new float[][]{{sd * 0.12f, 0.12f, 0.08f}, {sd * 0.15f, 0.18f, -0.15f}, {sd * 0.17f, 0.25f, -0.40f}},
                    new float[][]{{0.108f, 0.108f}, {0.096f, 0.096f}, {0.082f, 0.082f}}, new int[]{suit, suit, suit}, new float[]{1f, 0f, 0f}, 8, 2, true);
        // arms: shoulder, upper arm, elbow, forearm, wrist as one smooth sleeve each
        for (int sd = -1; sd <= 1; sd += 2) {
            sweep(b, new float[][]{{sd * 0.255f, 0.585f, 0.03f}, {sd * 0.30f, 0.575f, 0.02f}, {sd * 0.355f, 0.46f, -0.04f}, {sd * 0.405f, 0.335f, -0.125f}, {sd * 0.32f, 0.31f, -0.29f}, {sd * 0.218f, 0.286f, -0.455f}},
                    new float[][]{{0.03f, 0.03f}, {0.100f, 0.100f}, {0.088f, 0.088f}, {0.076f, 0.076f}, {0.066f, 0.066f}, {0.054f, 0.054f}},
                    new int[]{suitL, suitL, suit, suit, suit, suit}, new float[]{0f, 1f, 0f}, 10, 3, false);   // starts as a small rounded cap inside the torso, so the shoulder is a closed dome
            // stripe band on the upper arm and a cuff at the wrist
            sweep(b, new float[][]{{sd * 0.343f, 0.48f, -0.03f}, {sd * 0.366f, 0.43f, -0.055f}}, new float[][]{{0.094f, 0.094f}, {0.093f, 0.093f}}, new int[]{stripe, stripe}, new float[]{0f, 1f, 0f}, 10, 1, false);
            sweep(b, new float[][]{{sd * 0.236f, 0.289f, -0.436f}, {sd * 0.215f, 0.285f, -0.47f}}, new float[][]{{0.062f, 0.062f}, {0.062f, 0.062f}}, new int[]{stripe, stripe}, new float[]{0f, 1f, 0f}, 10, 1, false);
            // glove: the palm, then the fingers curling over the grip as one rounded mitten, and a thumb
            sweep(b, new float[][]{{sd * 0.215f, 0.285f, -0.47f}, {sd * 0.208f, 0.288f, -0.52f}}, new float[][]{{0.056f, 0.040f}, {0.054f, 0.036f}}, new int[]{glove, glove}, new float[]{0f, 1f, 0f}, 8, 1, false);
            sweep(b, new float[][]{{sd * 0.222f, 0.297f, -0.52f}, {sd * 0.172f, 0.332f, -0.52f}, {sd * 0.125f, 0.300f, -0.52f}},
                    new float[][]{{0.050f, 0.058f}, {0.044f, 0.058f}, {0.034f, 0.056f}}, new int[]{glove, glove, glove}, new float[]{0f, 0f, 1f}, 8, 2, true);
            sweep(b, new float[][]{{sd * 0.208f, 0.272f, -0.47f}, {sd * 0.165f, 0.318f, -0.50f}}, new float[][]{{0.022f, 0.022f}, {0.018f, 0.018f}}, new int[]{glove, glove}, new float[]{0f, 1f, 0f}, 6, 1, true);
        }
        // harness: shoulder belts over the collarbones, lap belt, buckle
        for (int sd = -1; sd <= 1; sd += 2) {
            b.tube(sd * 0.20f, 0.68f, 0.17f, sd * 0.19f, 0.655f, -0.07f, 0.026f, 0.026f, 5, belt, belt, false);
            b.tube(sd * 0.19f, 0.655f, -0.07f, sd * 0.05f, 0.25f, -0.185f, 0.026f, 0.026f, 5, belt, belt, false);
        }
        b.tube(-0.22f, 0.15f, -0.15f, 0.22f, 0.15f, -0.15f, 0.026f, 0.026f, 5, belt, belt, false);
        b.softBox(0, 0.215f, -0.19f, 0.040f, 0.030f, 0.012f, 2.6f, 8, 3, steelC, steelC);
        // number patch on the back, neck restraint
        b.softBox(0, 0.40f, 0.185f, 0.125f, 0.085f, 0.008f, 3f, 8, 4, white, white);
        b.box(0, 0.40f, 0.192f, 0.052f, 0.012f, 0.004f, black);
        for (int sd = -1; sd <= 1; sd += 2) b.tube(sd * 0.20f, 0.65f, 0.06f, sd * 0.135f, 0.59f, -0.15f, 0.040f, 0.030f, 6, black, black, false);
        helmet(b, 0f, 0.945f, -0.02f, stripe, black, steelC);
        return b.build();
    }

    private static final int DARKF = Col.hex(0x37474F);
}
