package dev.hexmaniac.android.ui

import android.content.Context

/** The version of the installed app, for the start screen and the About dialog (tells which build is running). */
object AppVersion {
    @Suppress("DEPRECATION")
    fun text(context: Context): String = try {
        val info = context.packageManager.getPackageInfo(context.packageName, 0)
        "Version " + info.versionName + " (build " + info.versionCode + ")"
    } catch (e: Exception) {
        ""
    }
}
