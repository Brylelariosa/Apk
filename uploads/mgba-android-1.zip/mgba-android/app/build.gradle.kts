plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mgba.android"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mgba.android"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }

        externalNativeBuild {
            cmake {
                // Tell mGBA to build as a library only — no SDL, no Qt, no deps
                arguments(
                    "-DLIBMGBA_ONLY=ON",
                    "-DM_CORE_GBA=ON",
                    "-DM_CORE_GB=ON",
                    "-DBUILD_STATIC=ON",
                    "-DBUILD_SHARED=OFF",
                    "-DDISABLE_FRONTENDS=ON",
                    "-DDISABLE_DEPS=ON"
                )
                cFlags("-O2")
                cppFlags("-O2 -std=c++17")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}
