/*
 * mgba_jni.c — JNI bridge between mGBA core and Android/Kotlin.
 *
 * Fix: mCoreInitConfig() MUST be called after core->init() and before
 * mCoreLoadFile(), otherwise the ROM loader dereferences uninitialised
 * config memory and crashes with SIGSEGV.
 */

#include <jni.h>
#include <android/bitmap.h>
#include <android/log.h>

#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <mgba/core/core.h>       /* mCoreFind, mCoreLoadFile     */
#include <mgba/core/config.h>     /* mCoreInitConfig, mCoreOptions */
#include <mgba/core/log.h>        /* mLogSetDefaultLogger          */
#include <mgba-util/image.h>      /* mColor                        */

#define LOG_TAG "mGBA-JNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* ── State ─────────────────────────────────────────────────────────────── */

static struct mCore *g_core  = NULL;
static mColor       *g_fb    = NULL;
static int           g_width  = 240;
static int           g_height = 160;

/* ── Logger ─────────────────────────────────────────────────────────────── */

static void jni_log(struct mLogger *logger, int category,
                    enum mLogLevel level, const char *fmt, va_list args)
{
    (void)logger; (void)category; (void)level;
    char buf[512];
    vsnprintf(buf, sizeof(buf), fmt, args);
    LOGI("%s", buf);
}
static struct mLogger g_logger = { .log = jni_log };

/* ── Internal cleanup ───────────────────────────────────────────────────── */

static void destroy_core(void)
{
    if (g_core) {
        g_core->deinit(g_core);
        g_core = NULL;
    }
    free(g_fb);
    g_fb = NULL;
}

/* ── nativeLoadROM ──────────────────────────────────────────────────────── */

JNIEXPORT jboolean JNICALL
Java_com_mgba_android_EmulatorEngine_nativeLoadROM(
        JNIEnv *env, jobject thiz, jstring jpath)
{
    destroy_core();
    mLogSetDefaultLogger(&g_logger);

    const char *path = (*env)->GetStringUTFChars(env, jpath, NULL);
    LOGI("Loading ROM: %s", path);

    /* 1. Auto-detect core type from file magic bytes */
    struct mCore *core = mCoreFind(path);
    if (!core) {
        LOGE("mCoreFind: unsupported/unreadable file");
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    /* 2. Allocate core-internal structures */
    if (!core->init(core)) {
        LOGE("core->init failed");
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    /* 3. ── REQUIRED ── initialise config before touching anything else.
     *    Without this, mCoreLoadFile dereferences uninitialised config
     *    memory → SIGSEGV.                                               */
    mCoreInitConfig(core, "mgba-android");

    /* 4. Apply sensible defaults (skip BIOS intro, set audio rate) */
    struct mCoreOptions opts;
    memset(&opts, 0, sizeof(opts));
    opts.skipBios    = true;
    opts.useBios     = false;
    opts.sampleRate  = 44100;
    opts.audioBuffers = 1024;
    opts.volume      = 256;          /* full volume */
    mCoreConfigLoadDefaults(&core->config, &opts);

    /* 5. Allocate framebuffer at the core's native resolution */
    unsigned w = 240, h = 160;
    core->baseVideoSize(core, &w, &h);
    if (w == 0 || h == 0) { w = 240; h = 160; }   /* safety fallback */
    g_width  = (int)w;
    g_height = (int)h;

    g_fb = (mColor *)calloc((size_t)g_width * (size_t)g_height, sizeof(mColor));
    if (!g_fb) {
        LOGE("framebuffer malloc failed (%dx%d)", g_width, g_height);
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }
    core->setVideoBuffer(core, g_fb, (size_t)g_width);

    /* 6. Load the ROM */
    if (!mCoreLoadFile(core, path)) {
        LOGE("mCoreLoadFile failed");
        free(g_fb); g_fb = NULL;
        core->deinit(core);
        (*env)->ReleaseStringUTFChars(env, jpath, path);
        return JNI_FALSE;
    }

    (*env)->ReleaseStringUTFChars(env, jpath, path);

    /* 7. Reset into known-good state */
    core->reset(core);
    g_core = core;

    LOGI("ROM loaded OK — core=%p  %dx%d", (void*)core, g_width, g_height);
    return JNI_TRUE;
}

/* ── nativeRunFrame ─────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeRunFrame(
        JNIEnv *env, jobject thiz, jobject bitmap)
{
    if (!g_core || !g_fb) return;

    g_core->runFrame(g_core);

    /* Convert mGBA native 0x00BBGGRR → Android ARGB_8888 0xFFRRGGBB
     * bswap32(0x00BBGGRR) = 0xRRGGBB00  →  >>8  =  0x00RRGGBB
     * | 0xFF000000                            →       0xFFRRGGBB       */
    AndroidBitmapInfo info;
    void *pixels = NULL;
    if (AndroidBitmap_getInfo(env, bitmap, &info) < 0) return;
    if (AndroidBitmap_lockPixels(env, bitmap, &pixels) < 0) return;

    const mColor *src = g_fb;
    uint32_t     *dst = (uint32_t *)pixels;
    const int     n   = g_width * g_height;
    for (int i = 0; i < n; i++) {
        dst[i] = (__builtin_bswap32(src[i]) >> 8) | 0xFF000000u;
    }

    AndroidBitmap_unlockPixels(env, bitmap);
}

/* ── nativeSetKeys ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeSetKeys(
        JNIEnv *env, jobject thiz, jint keys)
{
    if (g_core) g_core->setKeys(g_core, (uint32_t)keys);
}

/* ── nativeGetWidth / nativeGetHeight ───────────────────────────────────── */

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetWidth(JNIEnv *env, jobject thiz)
{ return (jint)g_width; }

JNIEXPORT jint JNICALL
Java_com_mgba_android_EmulatorEngine_nativeGetHeight(JNIEnv *env, jobject thiz)
{ return (jint)g_height; }

/* ── nativeDestroy ──────────────────────────────────────────────────────── */

JNIEXPORT void JNICALL
Java_com_mgba_android_EmulatorEngine_nativeDestroy(JNIEnv *env, jobject thiz)
{
    destroy_core();
    LOGI("mGBA core destroyed");
}
