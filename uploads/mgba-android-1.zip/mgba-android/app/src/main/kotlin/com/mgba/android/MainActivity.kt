package com.mgba.android

import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : AppCompatActivity(), SurfaceHolder.Callback {

    // ── Surface & rendering ──────────────────────────────────────────────────
    private lateinit var surfaceView: SurfaceView
    private var surfaceHolder: SurfaceHolder? = null

    // ── Game loop ────────────────────────────────────────────────────────────
    private var gameThread: Thread? = null
    @Volatile private var running = false
    @Volatile private var romLoaded = false
    private var frameBitmap: Bitmap? = null
    private val gameMatrix = Matrix()

    // ── Input ────────────────────────────────────────────────────────────────
    private val currentKeys = AtomicInteger(0)

    // ── Controller layout (computed once surface is sized) ───────────────────
    private val buttons = mutableListOf<ButtonDef>()
    private var controlsTop = 0f   // y where game area ends / controls begin

    // ── ROM file picker ──────────────────────────────────────────────────────
    private val romPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri ?: return@registerForActivityResult
        // Copy URI to a temp file so the native code gets a real filesystem path
        val tmp = cacheDir.resolve("rom.bin")
        contentResolver.openInputStream(uri)?.use { ins ->
            tmp.outputStream().use { out -> ins.copyTo(out) }
        }
        val ok = EmulatorEngine.nativeLoadROM(tmp.absolutePath)
        if (ok) {
            val w = EmulatorEngine.nativeGetWidth()
            val h = EmulatorEngine.nativeGetHeight()
            frameBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            romLoaded = true
            startGameLoop()
        } else {
            Toast.makeText(this, "Failed to load ROM", Toast.LENGTH_LONG).show()
        }
    }

    // ── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        surfaceView = SurfaceView(this)
        surfaceView.holder.addCallback(this)
        setContentView(surfaceView)

        // Touch input — handled directly on the SurfaceView
        surfaceView.setOnTouchListener { _, event -> onGameTouch(event); true }

        // Immersive fullscreen
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        stopGameLoop()
        EmulatorEngine.nativeDestroy()
    }

    // ── SurfaceHolder.Callback ───────────────────────────────────────────────

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceHolder = holder
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        surfaceHolder = holder
        buildControlLayout(w.toFloat(), h.toFloat())
        if (romLoaded) updateGameMatrix(w.toFloat(), h.toFloat())
        // Draw idle screen if no ROM loaded yet
        if (!romLoaded) drawIdleScreen(holder, w.toFloat(), h.toFloat())
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        stopGameLoop()
        surfaceHolder = null
    }

    // ── Game loop ────────────────────────────────────────────────────────────

    private fun startGameLoop() {
        if (running) return
        val sh = surfaceHolder ?: return
        val bmp = frameBitmap ?: return

        val sw = sh.surfaceFrame.width().toFloat()
        val sh2 = sh.surfaceFrame.height().toFloat()
        updateGameMatrix(sw, sh2)

        running = true
        gameThread = Thread {
            val targetMs = 1000L / 60
            while (running) {
                val t0 = System.currentTimeMillis()
                EmulatorEngine.nativeSetKeys(currentKeys.get())
                EmulatorEngine.nativeRunFrame(bmp)
                drawFrame(bmp)
                val elapsed = System.currentTimeMillis() - t0
                val sleep = targetMs - elapsed
                if (sleep > 0) Thread.sleep(sleep)
            }
        }.also { it.name = "mGBA-loop"; it.start() }
    }

    private fun stopGameLoop() {
        running = false
        gameThread?.join(500)
        gameThread = null
    }

    private fun drawFrame(bmp: Bitmap) {
        val holder = surfaceHolder ?: return
        val canvas: Canvas = try {
            holder.lockCanvas() ?: return
        } catch (e: Exception) { return }
        try {
            canvas.drawColor(Color.BLACK)
            canvas.drawBitmap(bmp, gameMatrix, null)
            drawControls(canvas)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    // ── Idle screen (before ROM loaded) ─────────────────────────────────────

    private fun drawIdleScreen(holder: SurfaceHolder, sw: Float, sh: Float) {
        val canvas: Canvas = holder.lockCanvas() ?: return
        try {
            canvas.drawColor(Color.BLACK)
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = sh * 0.045f
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText("mGBA  –  No ROM loaded", sw / 2f, sh * 0.35f, p)
            p.textSize = sh * 0.032f
            p.color = Color.LTGRAY
            canvas.drawText("Tap  ▶  to pick a ROM file", sw / 2f, sh * 0.43f, p)

            // "Load ROM" button
            val btnW = sw * 0.22f; val btnH = sh * 0.09f
            val btnL = (sw - btnW) / 2f; val btnT = sh * 0.52f
            val btnR = btnL + btnW; val btnB = btnT + btnH
            val pBtn = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#BB86FC") }
            canvas.drawRoundRect(btnL, btnT, btnR, btnB, 16f, 16f, pBtn)
            p.color = Color.BLACK
            p.textSize = sh * 0.038f
            canvas.drawText("▶  Load ROM", sw / 2f, btnT + btnH * 0.62f, p)

            drawControls(canvas)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    // ── Matrix scaling (game → screen) ───────────────────────────────────────

    private fun updateGameMatrix(sw: Float, sh: Float) {
        val bmp = frameBitmap ?: return
        val gameArea = sh * GAME_AREA_FRACTION
        val scaleX = sw / bmp.width.toFloat()
        val scaleY = gameArea / bmp.height.toFloat()
        val scale  = minOf(scaleX, scaleY)
        val tx = (sw  - bmp.width  * scale) / 2f
        val ty = (gameArea - bmp.height * scale) / 2f
        gameMatrix.reset()
        gameMatrix.postScale(scale, scale)
        gameMatrix.postTranslate(tx, ty)
    }

    // ── On-screen controller ─────────────────────────────────────────────────

    companion object {
        private const val GAME_AREA_FRACTION = 0.52f  // top 52 % of screen = game
    }

    private data class ButtonDef(
        val rect: RectF,
        val keyMask: Int,
        val label: String,
        val color: Int
    )

    /**
     * Builds the button rectangles once the surface dimensions are known.
     * All coordinates are in pixels.
     */
    private fun buildControlLayout(sw: Float, sh: Float) {
        buttons.clear()
        controlsTop = sh * GAME_AREA_FRACTION

        val padH = sh - controlsTop            // height of controls area
        val padSize  = minOf(padH * 0.80f, sw * 0.28f)
        val btnSize  = padSize * 0.30f         // individual pad button size
        val abSize   = padSize * 0.28f         // A / B button size

        // ── D-pad (left side) ────────────────────────────────────────────────
        val dpCx = sw * 0.18f
        val dpCy = controlsTop + padH * 0.52f
        fun padBtn(dx: Float, dy: Float, mask: Int, lbl: String) = ButtonDef(
            RectF(dpCx + dx - btnSize / 2, dpCy + dy - btnSize / 2,
                  dpCx + dx + btnSize / 2, dpCy + dy + btnSize / 2),
            mask, lbl, Color.parseColor("#555566")
        )
        val padStep = btnSize * 1.08f
        buttons += padBtn(0f,       -padStep, EmulatorEngine.KEY_UP,    "▲")
        buttons += padBtn(0f,       +padStep, EmulatorEngine.KEY_DOWN,  "▼")
        buttons += padBtn(-padStep, 0f,       EmulatorEngine.KEY_LEFT,  "◀")
        buttons += padBtn(+padStep, 0f,       EmulatorEngine.KEY_RIGHT, "▶")

        // ── A / B (right side) ───────────────────────────────────────────────
        val abCx = sw * 0.82f
        val abCy = controlsTop + padH * 0.52f
        val abGap = abSize * 1.15f
        buttons += ButtonDef(
            RectF(abCx + abGap - abSize / 2, abCy - abSize / 2,
                  abCx + abGap + abSize / 2, abCy + abSize / 2),
            EmulatorEngine.KEY_A, "A", Color.parseColor("#CF6679")
        )
        buttons += ButtonDef(
            RectF(abCx - abGap - abSize / 2, abCy - abSize / 2,
                  abCx - abGap + abSize / 2, abCy + abSize / 2),
            EmulatorEngine.KEY_B, "B", Color.parseColor("#4FC3F7")
        )

        // ── Start / Select (centre) ──────────────────────────────────────────
        val ssBtnW = sw * 0.11f
        val ssBtnH = sh * 0.038f
        val ssCy   = controlsTop + padH * 0.82f
        val gap    = sw * 0.07f
        buttons += ButtonDef(
            RectF(sw / 2f - gap - ssBtnW, ssCy,
                  sw / 2f - gap,          ssCy + ssBtnH),
            EmulatorEngine.KEY_SELECT, "SELECT", Color.parseColor("#444455")
        )
        buttons += ButtonDef(
            RectF(sw / 2f + gap, ssCy,
                  sw / 2f + gap + ssBtnW, ssCy + ssBtnH),
            EmulatorEngine.KEY_START, "START", Color.parseColor("#444455")
        )

        // ── L / R shoulder ───────────────────────────────────────────────────
        val lrBtnW = sw * 0.13f
        val lrBtnH = sh * 0.042f
        val lrY    = controlsTop + padH * 0.06f
        buttons += ButtonDef(
            RectF(sw * 0.03f, lrY, sw * 0.03f + lrBtnW, lrY + lrBtnH),
            EmulatorEngine.KEY_L, "L", Color.parseColor("#444455")
        )
        buttons += ButtonDef(
            RectF(sw - sw * 0.03f - lrBtnW, lrY, sw - sw * 0.03f, lrY + lrBtnH),
            EmulatorEngine.KEY_R, "R", Color.parseColor("#444455")
        )
    }

    private val btnPaint   = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color    = Color.WHITE
        textAlign = Paint.Align.CENTER
    }

    private fun drawControls(canvas: Canvas) {
        if (buttons.isEmpty()) return

        // Semi-transparent control area background
        btnPaint.color = Color.parseColor("#CC111122")
        canvas.drawRect(0f, controlsTop, canvas.width.toFloat(), canvas.height.toFloat(), btnPaint)

        for (btn in buttons) {
            // Button background
            val alpha = if ((currentKeys.get() and btn.keyMask) != 0) 220 else 140
            btnPaint.color = btn.color
            btnPaint.alpha = alpha
            canvas.drawRoundRect(btn.rect, 12f, 12f, btnPaint)

            // Label
            labelPaint.textSize = (btn.rect.height() * 0.48f).coerceAtLeast(18f)
            canvas.drawText(
                btn.label,
                btn.rect.centerX(),
                btn.rect.centerY() + labelPaint.textSize * 0.36f,
                labelPaint
            )
        }

        // "Load ROM" tap hint — centre of game area (only when idle)
        if (!romLoaded) {
            val sw = canvas.width.toFloat()
            val sh = canvas.height.toFloat()
            val btnW = sw * 0.22f; val btnH = sh * 0.09f
            val btnL = (sw - btnW) / 2f; val btnT = sh * 0.52f
            btnPaint.color = Color.parseColor("#BB86FC")
            btnPaint.alpha = 200
            canvas.drawRoundRect(btnL, btnT, btnL + btnW, btnT + btnH, 16f, 16f, btnPaint)
            labelPaint.textSize = sh * 0.038f
            canvas.drawText(
                "▶  Load ROM",
                sw / 2f,
                btnT + btnH * 0.62f,
                labelPaint
            )
        }
    }

    // ── Touch handling ───────────────────────────────────────────────────────

    private fun onGameTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_POINTER_DOWN,
            MotionEvent.ACTION_MOVE -> {
                var keys = 0
                for (i in 0 until event.pointerCount) {
                    val x = event.getX(i)
                    val y = event.getY(i)

                    // "Load ROM" tap zone (centre of game area, visible when idle)
                    if (!romLoaded) {
                        val sw = surfaceView.width.toFloat()
                        val sh = surfaceView.height.toFloat()
                        val btnW = sw * 0.22f; val btnH = sh * 0.09f
                        val btnL = (sw - btnW) / 2f; val btnT = sh * 0.52f
                        if (x in btnL..(btnL + btnW) && y in btnT..(btnT + btnH)) {
                            romPicker.launch(arrayOf("*/*"))
                        }
                    }

                    for (btn in buttons) {
                        if (btn.rect.contains(x, y)) keys = keys or btn.keyMask
                    }
                }
                currentKeys.set(keys)
            }
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_POINTER_UP,
            MotionEvent.ACTION_CANCEL -> {
                currentKeys.set(0)
            }
        }
    }
}
