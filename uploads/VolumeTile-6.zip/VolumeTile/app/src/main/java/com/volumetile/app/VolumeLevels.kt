package com.volumetile.app

import android.content.Context

/**
 * What the Louder and Quieter actions do: a media volume level each one jumps straight to, or
 * 0 for "one step at a time" (the default, and what they did before this was configurable).
 *
 * Plain SharedPreferences, like [BubblePrefs]. The accessibility service reads them each time
 * an action runs, so a change made in the app counts immediately.
 */
object VolumeLevels {

    private const val PREFS = "volume_levels"
    private const val KEY_LOUDER = "louder"
    private const val KEY_QUIETER = "quieter"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** The level Louder jumps to, or 0 for one step up. */
    fun louder(context: Context): Int = prefs(context).getInt(KEY_LOUDER, 0).coerceAtLeast(0)

    /** The level Quieter jumps to, or 0 for one step down. */
    fun quieter(context: Context): Int = prefs(context).getInt(KEY_QUIETER, 0).coerceAtLeast(0)

    fun setLouder(context: Context, level: Int) {
        prefs(context).edit().putInt(KEY_LOUDER, level.coerceAtLeast(0)).apply()
    }

    fun setQuieter(context: Context, level: Int) {
        prefs(context).edit().putInt(KEY_QUIETER, level.coerceAtLeast(0)).apply()
    }
}
