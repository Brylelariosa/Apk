# VolumeTile audit (1.6 -> 1.7)

**Scope:** every Kotlin file (14 files, about 2.7k lines), the manifest, the accessibility config, all
resources, the Gradle and CI files and the README of `VolumeTile-3.zip`.

**How:** read by hand, plus scripted cross-checks of every `R.string` / `R.drawable` / `R.id` reference
(nothing missing, nothing unused) and of XML well-formedness. **Not compiled and not run:** the
environment had no Gradle or Android SDK, so the pipeline build is the first compile of the 1.7 edits.
They are small and mechanical, and every changed file was diff-reviewed.

## Verdict: CPU and lag

Idle cost is effectively zero, and nothing in the code can cause sustained CPU use.

- `res/xml/system_action_service.xml` subscribes to no event types and no window content, so the system
  delivers nothing to the service. `onAccessibilityEvent` is empty.
- No timers, polling, wake locks or alarms. Every `Handler` post is one-shot (screenshot 250-800 ms,
  lock 160 ms, chooser auto-dismiss 15 s) and is removed in `release()`.
- The foreground notification is static; the foreground service does no work.
- Work happens only during a gesture: the arc animation (about 0.3-0.7 s per hold, GPU-accelerated,
  five icons) and dragging the bubble.
- The app's only repeating task is `VolumeControlActivity.watchService` (every 2 s), and only while the
  app is on screen and the service is on but not connected.
- One cost no code can remove: while any accessibility service is bound, the framework tells every app
  that accessibility is on, and a few UI frameworks do extra work when they hear that. A service with no
  event types is the cheapest way to be one.

To confirm on the phone (menu names vary by maker): Battery usage for Volume Tile should read about
0%, and Developer options > Running services should show it with a tiny RAM figure.

## Fixed in 1.7

| Finding | Where | Change |
|---|---|---|
| Bubble touch handling, the hold-to-open runnable and the arc's frame callback ran outside `guarded`; an exception there would crash the process, which the README ties to the "service dead until toggled" symptom | `FloatingBubble.kt`, `ArcMenu.kt` (`Tween`) | Wrapped. A failure drops the gesture or ends the animation; a closing arc still removes its window |
| A refused `startForeground()` (Android 12+ restricts background starts) was never retried | `VolumeControlActivity.onResume` | Re-asserts keep-alive each time the app is opened |
| Registering the nav-bar button was unguarded in `onServiceConnected`, and could stop keep-alive and the bubble from starting | `SystemActionService.kt` | Wrapped; a failure is logged and start-up continues |
| One window move per touch event while dragging (a window-manager round trip each) | `FloatingBubble.dragTo` | At most one move per frame, none when unchanged |
| On Android 8.x a saved action the phone can't run made its picker show "Nothing", and the picker then wrote "Nothing" back over the saved choice | `VolumeControlActivity.setupBubbleSection` | Writes only when the person changes a picker |
| Docs said the Volume tile opens the slider panel; it pops up the system panel | README, `VolumeControlActivity` KDoc | Corrected |
| Accessibility settings entry had no gear to the app; sliders had no spoken names | `system_action_service.xml`, layout | `settingsActivity` added; `contentDescription` on the four SeekBars |

## Added in 1.7

**Louder / Quieter / Mute** (`SystemAction.VOLUME_UP/DOWN/MUTE`): one step on the media volume, or mute
toggle, with the system volume panel showing the result. The app exists to replace a broken volume
button, but until now the only volume action was "open the panel". They appear in the chooser and in
the arc pickers, need no accessibility service, and launch nothing. Version 7 / 1.6 -> 8 / 1.7.

## Open items (not changed, in rough priority)

1. **Self-heal after the system drops the service.** Only Settings can rebind a dead accessibility service,
   so today the person has to toggle it. With a one-time `adb shell pm grant com.volumetile.app
   android.permission.WRITE_SECURE_SETTINGS`, the app could flip its own entry in
   `Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES` from the tile or the app when `isStalled()` is true. Optional and inert
   without the grant. Left out because it writes a system setting that also lists the person's other
   accessibility services, and could not be tested here.
2. **Service health line in the app** (running / keep-alive active / battery exempt). `KeepAlive.start`
   catches a refused `startForeground` but only logs it; it could record that and the app could show it.
3. **Screen metrics.** `resources.displayMetrics` plus fixed 24 dp / 56 dp safe zones are approximate on
   tall status bars, foldables and multi-window. `WindowManager.currentWindowMetrics` (API 30+) with the
   real insets would be exact.
4. **POST_NOTIFICATIONS** is not declared. On Android 13+ the foreground service still runs, but its
   notification may be hidden from the shade. Not needed for keep-alive; needed if you want to see or
   manage the notification.
5. **Tiles for Louder / Quieter**, a ringer-mode (sound / vibrate / silent) action, and hold-to-repeat on
   the arc.
6. **Per-app bubble hiding** (for example in a full-screen game). Needs the
   `typeWindowStateChanged` event, which gives up the zero-event design and lets the service see package
   names. Only worth it if the bubble ever gets in the way.
7. **Unit tests for `ArcLayout`.** It is pure Kotlin geometry (`indexAt`, overflow and turn search), so
   it can be tested on the JVM with no Android.
8. **`build.yml`** builds an unsigned release APK (the pipeline signs), so its upload step finds no
   `app-release.apk`. Fine while the pipeline is what builds this; point the path at `*.apk` or build
   debug if it is ever used on its own.
9. `allowBackup="true"` backs up only the two small preference files (`keep_alive`, `bubble`); harmless, but Android 12+ lint
   wants `dataExtractionRules` for it.

## Checked and fine

- Exported components: all four tiles and the accessibility service are protected by their
  `BIND_*` permissions; the launcher activity reads no extras. No `INTERNET` permission.
- Least privilege: `canRetrieveWindowContent="false"`, no events, no gestures.
- `PendingIntent`s are `FLAG_IMMUTABLE`; the notification is `VISIBILITY_SECRET`, minimum importance.
- Every `addView` / `removeView` / `updateViewLayout` is inside a `try`; window leaks on teardown are
  handled (`release()`, `detach()`, `dismissNow()`).
- Preferences store enum names through `name()` with a default fallback; nothing reflective for R8 to break.
- AGP 8.6.1, Kotlin 1.9.24, Gradle 8.9, JDK 17, compileSdk 35 and appcompat 1.7.0 are mutually consistent.
- `when (action)` over `SystemAction` in `perform()` is the only exhaustive switch; it is updated.
