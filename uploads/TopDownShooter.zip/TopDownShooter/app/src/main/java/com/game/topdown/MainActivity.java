package com.game.topdown;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText nameInput, ipInput;
    private Button   hostBtn, scanBtn, joinIpBtn;
    private ListView hostList;
    private final List<String[]>  hosts   = new ArrayList<>();
    private ArrayAdapter<String>  adapter;
    private final Handler         handler = new Handler(Looper.getMainLooper());
    private NetworkManager        scanner;

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        setContentView(R.layout.activity_main);

        nameInput = findViewById(R.id.nameInput);
        ipInput   = findViewById(R.id.ipInput);
        hostBtn   = findViewById(R.id.hostBtn);
        scanBtn   = findViewById(R.id.scanBtn);
        joinIpBtn = findViewById(R.id.joinIpBtn);
        hostList  = findViewById(R.id.hostList);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        hostList.setAdapter(adapter);

        hostBtn.setOnClickListener(v -> {
            String n = name(); if(n==null) return;
            launch(n, true, null);
        });
        scanBtn.setOnClickListener(v -> {
            String n = name(); if(n==null) return;
            scan();
        });
        joinIpBtn.setOnClickListener(v -> {
            String n = name(); if(n==null) return;
            String ip = ipInput.getText().toString().trim();
            if(ip.isEmpty()){ toast("Enter a host IP"); return; }
            launch(n, false, ip);
        });
        hostList.setOnItemClickListener((p,v,pos,id) -> {
            String n = name(); if(n==null) return;
            launch(n, false, hosts.get(pos)[0]);
        });
    }

    private String name(){
        String s = nameInput.getText().toString().trim();
        if(s.isEmpty()){ toast("Enter your name!"); return null; }
        return s;
    }

    private void scan(){
        hosts.clear(); adapter.clear();
        scanBtn.setEnabled(false); toast("Scanning for games…");
        if(scanner!=null) scanner.stop();
        scanner = new NetworkManager(new NetworkManager.Callback(){
            @Override public void onHostDiscovered(String ip, String hn){
                handler.post(()->{
                    // deduplicate
                    for(String[] h:hosts) if(h[0].equals(ip)) return;
                    hosts.add(new String[]{ip,hn});
                    adapter.add(hn+" ("+ip+")");
                });
            }
            @Override public void onJoined(int i){}
            @Override public void onPlayerJoined(int i,String n){}
            @Override public void onStateUpdate(String j){}
            @Override public void onInputReceived(int i,String j){}
        });
        scanner.discoverHosts(3000);
        handler.postDelayed(()->{
            scanBtn.setEnabled(true);
            if(hosts.isEmpty()) toast("No games found — enter IP manually.");
        }, 3500);
    }

    private void launch(String name, boolean host, String ip){
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("name", name); i.putExtra("isHost", host);
        if(ip!=null) i.putExtra("hostIp", ip);
        startActivity(i);
    }
    private void toast(String m){ Toast.makeText(this,m,Toast.LENGTH_SHORT).show(); }

    @Override protected void onDestroy(){ super.onDestroy(); if(scanner!=null) scanner.stop(); }
}
