package com.game.topdown;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameView extends SurfaceView
        implements SurfaceHolder.Callback, Runnable, NetworkManager.Callback {

    // ═══ WORLD ════════════════════════════════════════════════════════════════
    static final float MAP_W = 2400, MAP_H = 2400;
    static final int   PR    = 24;   // player radius
    static final long  RESPAWN_MS = 5000;

    // walls: {x1,y1,x2,y2}
    static final float[][] WALLS = {
        {400,310,760,350}, {880,120,920,560}, {280,660,315,980},
        {560,540,920,580}, {1100,370,1460,410}, {1530,210,1570,670},
        {680,960,720,1310}, {960,840,1320,880}, {180,1160,540,1200},
        {1430,960,1470,1320}, {540,1520,1060,1560}, {1250,1360,1570,1400},
        {1700,480,1740,920}, {300,1480,340,1920}, {820,1780,1220,1820},
        {1600,1580,1640,2020},
    };

    static final float[][] SPAWNS = {
        {120,120},{2280,120},{120,2280},{2280,2280},
        {1200,120},{120,1200},{2280,1200},{1200,2280},
    };

    // ═══ STATE ════════════════════════════════════════════════════════════════
    private Player           localPlayer;
    private final String     savedName;
    private final Map<Integer,Player> remote   = new ConcurrentHashMap<>();
    private final Map<Integer,Long>   deadAtMs = new ConcurrentHashMap<>();
    private final List<Bullet>        bullets  = new ArrayList<>();
    private int bulletId;

    // ═══ NETWORK ══════════════════════════════════════════════════════════════
    private final NetworkManager          net;
    private final boolean                 isHost;
    private volatile String               pendingState;
    private final Map<Integer,float[]>    inputs = new ConcurrentHashMap<>();
    private long lastBroadcast;

    // ═══ INPUT ════════════════════════════════════════════════════════════════
    private Joystick moveStick, aimStick;
    private RectF    switchRect, reloadRect;

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    private volatile boolean  gameRunning;
    private Thread            gameThread;
    private float             screenW, screenH, camX, camY;
    private int               tick;
    private long              deathTime;

    // paints
    private Paint bgP,gridP,wallP,bdrP,remP,locP,shP,hpBgP,
                  bulletP,nameP,hudP,hudBgP,btnP,btnTxtP,
                  deathBgP,deathTxtP,gunTxtP;

    // kill feed
    private final List<String> feed = new ArrayList<>();

    // ═══ CTOR ═════════════════════════════════════════════════════════════════
    public GameView(Context ctx, String name, boolean host, String hostIp) {
        super(ctx);
        savedName = name;
        isHost    = host;
        net       = new NetworkManager(this);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();
        try {
            if (host) { net.startHost(name); spawnLocal(0, name); }
            else        net.joinGame(hostIp, name);
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ═══ PAINTS ═══════════════════════════════════════════════════════════════
    private void initPaints() {
        bgP     = fill(Color.rgb(12,25,18));
        gridP   = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridP.setColor(Color.argb(22,255,255,255));
        gridP.setStyle(Paint.Style.STROKE); gridP.setStrokeWidth(1f);
        wallP   = fill(Color.rgb(68,72,112));
        bdrP    = new Paint(Paint.ANTI_ALIAS_FLAG);
        bdrP.setColor(Color.rgb(100,108,170)); bdrP.setStyle(Paint.Style.STROKE); bdrP.setStrokeWidth(6f);
        remP    = fill(Color.rgb(240,88,88));
        locP    = fill(Color.rgb(80,190,255));
        shP     = fill(Color.argb(65,0,0,0));
        hpBgP   = fill(Color.rgb(38,38,38));
        bulletP = fill(Color.rgb(255,218,0));
        nameP   = fill(Color.WHITE); nameP.setTextSize(21f); nameP.setTextAlign(Paint.Align.CENTER);
        nameP.setShadowLayer(3f,1f,1f,Color.BLACK);
        hudP    = fill(Color.WHITE); hudP.setTextSize(28f);
        hudBgP  = fill(Color.argb(145,0,0,0));
        btnP    = fill(Color.argb(205,195,55,85));
        btnTxtP = fill(Color.WHITE); btnTxtP.setTextSize(22f);
        btnTxtP.setTextAlign(Paint.Align.CENTER); btnTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        deathBgP  = fill(Color.argb(165,0,0,0));
        deathTxtP = fill(Color.rgb(255,55,55)); deathTxtP.setTextSize(58f);
        deathTxtP.setTextAlign(Paint.Align.CENTER);
        gunTxtP = fill(Color.WHITE); gunTxtP.setTextSize(25f); gunTxtP.setTextAlign(Paint.Align.CENTER);
    }
    private Paint fill(int c){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(c);p.setStyle(Paint.Style.FILL);return p;}

    // ═══ SURFACE ══════════════════════════════════════════════════════════════
    @Override public void surfaceCreated(SurfaceHolder h)  { screenW=getWidth(); screenH=getHeight(); initControls(); resume(); }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int hh) { screenW=w; screenH=hh; initControls(); }
    @Override public void surfaceDestroyed(SurfaceHolder h) { pause(); }

    private void initControls() {
        float r=Math.min(screenW,screenH)*0.145f, m=r+18f;
        moveStick = new Joystick(m,        screenH-m, r);
        aimStick  = new Joystick(screenW-m, screenH-m, r);
        float bw=160f,bh=58f,bx=screenW-bw-12f;
        switchRect = new RectF(bx,12,bx+bw,12+bh);
        reloadRect = new RectF(bx,12+bh+8,bx+bw,12+bh*2+8);
    }

    // ═══ TOUCH ════════════════════════════════════════════════════════════════
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act=e.getActionMasked(), idx=e.getActionIndex(), pid=e.getPointerId(idx);
        float x=e.getX(idx), y=e.getY(idx);
        switch(act){
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if(switchRect!=null&&switchRect.contains(x,y)){switchGun();break;}
                if(reloadRect!=null&&reloadRect.contains(x,y)){reload();break;}
                if(!moveStick.onTouchDown(pid,x,y)) aimStick.onTouchDown(pid,x,y);
                break;
            case MotionEvent.ACTION_MOVE:
                for(int i=0;i<e.getPointerCount();i++){
                    int p2=e.getPointerId(i);
                    moveStick.onTouchMove(p2,e.getX(i),e.getY(i));
                    aimStick.onTouchMove(p2,e.getX(i),e.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                moveStick.onTouchUp(pid); aimStick.onTouchUp(pid); break;
        }
        return true;
    }
    private void switchGun(){if(localPlayer!=null&&localPlayer.alive) localPlayer.gunIndex=(localPlayer.gunIndex+1)%3;}
    private void reload()   {if(localPlayer!=null&&localPlayer.alive) localPlayer.currentGun().startReload();}

    // ═══ LOOP ═════════════════════════════════════════════════════════════════
    public void resume(){
        if(gameRunning) return;
        gameRunning=true;
        gameThread=new Thread(this,"GameLoop"); gameThread.start();
    }
    public void pause(){
        gameRunning=false;
        if(gameThread!=null) try{gameThread.join(700);}catch(InterruptedException ignored){}
    }
    public void stopGame(){ pause(); net.stop(); }

    @Override public void run(){
        long prev=System.nanoTime();
        while(gameRunning){
            long now=System.nanoTime();
            float dt=Math.min((now-prev)/1e9f,0.08f); prev=now;
            update(dt); render();
            long sleep=16_666_000L-(System.nanoTime()-now);
            if(sleep>0) try{Thread.sleep(sleep/1_000_000,(int)(sleep%1_000_000));}catch(InterruptedException ig){}
        }
    }

    // ═══ UPDATE ═══════════════════════════════════════════════════════════════
    private void update(float dt){
        tick++;
        // apply server state (client only)
        if(!isHost && pendingState!=null){ applyState(pendingState); pendingState=null; }

        if(localPlayer==null) return;
        if(localPlayer.alive) for(Gun g:localPlayer.guns) g.tick();

        // host respawns its own player
        if(isHost&&!localPlayer.alive&&System.currentTimeMillis()-deathTime>=RESPAWN_MS)
            respawn(localPlayer);

        if(localPlayer.alive) moveAndAim(dt);

        updateBullets(dt);

        if(isHost){
            applyClientInputs(dt);
            checkRemoteRespawns();
            if(System.currentTimeMillis()-lastBroadcast>50){ broadcast(); lastBroadcast=System.currentTimeMillis(); }
        } else {
            if(tick%2==0) sendInput();
        }

        camX=localPlayer.x-screenW*0.5f;
        camY=localPlayer.y-screenH*0.5f;
    }

    private void moveAndAim(float dt){
        float nx=localPlayer.x+moveStick.getX()*280f*dt;
        float ny=localPlayer.y+moveStick.getY()*280f*dt;
        nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
        float[] pos=walls(localPlayer.x,localPlayer.y,nx,ny);
        localPlayer.x=pos[0]; localPlayer.y=pos[1];

        float ax=aimStick.getX(), ay=aimStick.getY();
        if(ax*ax+ay*ay>0.01f) localPlayer.angle=(float)Math.atan2(ay,ax);

        if(aimStick.isActive()){
            Gun g=localPlayer.currentGun();
            if(g.canFireNow()){ spawnBullets(localPlayer); g.markFired(); }
        }
    }

    // simple separating-axis slide for circle vs AABB
    private float[] walls(float ox,float oy,float nx,float ny){
        for(float[] w:WALLS){
            float cx=clamp(nx,w[0],w[2]), cy=clamp(ny,w[1],w[3]);
            if(d2(nx,ny,cx,cy)<PR*PR){
                // try X axis only
                float cx2=clamp(nx,w[0],w[2]), cy2=clamp(oy,w[1],w[3]);
                if(d2(nx,oy,cx2,cy2)<PR*PR) nx=ox;
                // try Y axis only
                float cx3=clamp(ox,w[0],w[2]), cy3=clamp(ny,w[1],w[3]);
                if(d2(ox,ny,cx3,cy3)<PR*PR) ny=oy;
            }
        }
        return new float[]{nx,ny};
    }

    private void spawnBullets(Player p){
        Gun g=p.guns[p.gunIndex];
        if(g.ammo<=0) return;
        g.ammo--;
        for(int i=0;i<g.pellets;i++){
            float s=(float)(Math.random()-0.5)*g.spread*2, a=p.angle+s;
            float spd=g.bulletSpeed*(0.88f+(float)Math.random()*0.24f);
            bullets.add(new Bullet(p.x,p.y,(float)Math.cos(a)*spd,(float)Math.sin(a)*spd,p.id,g.damage,bulletId++));
        }
    }

    private void updateBullets(float dt){
        Iterator<Bullet> it=bullets.iterator();
        while(it.hasNext()){
            Bullet b=it.next();
            b.x+=b.dx*dt; b.y+=b.dy*dt;
            boolean rm=false;
            if(b.x<0||b.x>MAP_W||b.y<0||b.y>MAP_H) rm=true;
            if(!rm) for(float[] w:WALLS)
                if(b.x>=w[0]&&b.x<=w[2]&&b.y>=w[1]&&b.y<=w[3]){rm=true;break;}
            if(!rm&&System.currentTimeMillis()-b.spawnTime>3500) rm=true;
            // hit detection – host only
            if(!rm&&isHost){
                if(localPlayer.alive&&b.ownerId!=localPlayer.id&&d2(b.x,b.y,localPlayer.x,localPlayer.y)<PR*PR){
                    localPlayer.hp=Math.max(0,localPlayer.hp-b.damage);
                    rm=true;
                    if(localPlayer.hp==0){localPlayer.alive=false;deathTime=System.currentTimeMillis();addFeed(nameOf(b.ownerId)+" ➜ "+localPlayer.name);}
                }
                if(!rm) for(Player rp:remote.values()){
                    if(b.ownerId==rp.id||!rp.alive) continue;
                    if(d2(b.x,b.y,rp.x,rp.y)<PR*PR){
                        rp.hp=Math.max(0,rp.hp-b.damage); rm=true;
                        if(rp.hp==0){rp.alive=false;deadAtMs.put(rp.id,System.currentTimeMillis());addFeed(nameOf(b.ownerId)+" ➜ "+rp.name);}
                        break;
                    }
                }
            }
            if(rm) it.remove();
        }
    }

    private void applyClientInputs(float dt){
        for(Map.Entry<Integer,float[]> e:inputs.entrySet()){
            Player p=remote.get(e.getKey()); if(p==null||!p.alive) continue;
            float[] inp=e.getValue();
            float nx=p.x+inp[0]*280f*dt, ny=p.y+inp[1]*280f*dt;
            nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
            float[] pos=walls(p.x,p.y,nx,ny); p.x=pos[0]; p.y=pos[1];
            if(inp[2]*inp[2]+inp[3]*inp[3]>0.01f) p.angle=(float)Math.atan2(inp[3],inp[2]);
            p.gunIndex=(int)inp[5];
            if(inp[6]>0.5f) p.guns[p.gunIndex].startReload();
            for(Gun g:p.guns) g.tick();
            if(inp[4]>0.5f){ Gun g=p.currentGun(); if(g.canFireNow()){spawnBullets(p);g.markFired();} }
        }
    }

    private void checkRemoteRespawns(){
        long now=System.currentTimeMillis();
        for(Player p:remote.values())
            if(!p.alive&&deadAtMs.containsKey(p.id)&&now-deadAtMs.get(p.id)>=RESPAWN_MS){
                respawn(p); deadAtMs.remove(p.id);
            }
    }

    private void respawn(Player p){
        float[] sp=SPAWNS[p.id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true; p.guns=Gun.createAll(); p.gunIndex=0;
    }
    private void spawnLocal(int id, String name){
        localPlayer=new Player(); localPlayer.id=id; localPlayer.name=name;
        localPlayer.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; localPlayer.x=sp[0]; localPlayer.y=sp[1];
    }

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    private void render(){
        Canvas c=getHolder().lockCanvas(); if(c==null) return;
        try{ draw(c); }finally{ getHolder().unlockCanvasAndPost(c); }
    }

    private void draw(Canvas c){
        c.drawRect(0,0,c.getWidth(),c.getHeight(),bgP);
        c.save(); c.translate(-camX,-camY);

        // grid
        for(float x=0;x<=MAP_W;x+=120) c.drawLine(x,0,x,MAP_H,gridP);
        for(float y=0;y<=MAP_H;y+=120) c.drawLine(0,y,MAP_W,y,gridP);
        c.drawRect(0,0,MAP_W,MAP_H,bdrP);

        // walls
        for(float[] w:WALLS) c.drawRect(w[0],w[1],w[2],w[3],wallP);

        // bullets
        for(Bullet b:bullets) c.drawCircle(b.x,b.y,5f,bulletP);

        // players
        for(Player p:remote.values()) drawPlayer(c,p,false);
        if(localPlayer!=null) drawPlayer(c,localPlayer,true);

        c.restore();
        drawHUD(c);
    }

    private void drawPlayer(Canvas c, Player p, boolean local){
        if(!p.alive){
            Paint xp=new Paint(Paint.ANTI_ALIAS_FLAG);
            xp.setColor(Color.argb(160,230,50,50)); xp.setStyle(Paint.Style.STROKE); xp.setStrokeWidth(4f);
            c.drawLine(p.x-13,p.y-13,p.x+13,p.y+13,xp);
            c.drawLine(p.x+13,p.y-13,p.x-13,p.y+13,xp); return;
        }
        float r=PR;
        c.drawCircle(p.x+4,p.y+4,r,shP);
        c.drawCircle(p.x,p.y,r,local?locP:remP);

        // barrel
        float gl=r+20f;
        Paint gp=new Paint(Paint.ANTI_ALIAS_FLAG);
        gp.setColor(local?Color.rgb(110,215,255):Color.rgb(255,135,135));
        gp.setStyle(Paint.Style.STROKE); gp.setStrokeWidth(7f);
        gp.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(p.x,p.y,p.x+(float)Math.cos(p.angle)*gl,p.y+(float)Math.sin(p.angle)*gl,gp);

        // hp bar
        float bw=50f,bh=6f,bx=p.x-25f,by=p.y-r-14f;
        c.drawRoundRect(bx,by,bx+bw,by+bh,3,3,hpBgP);
        float fr=Math.max(0,p.hp/100f);
        Paint hpP=new Paint(Paint.ANTI_ALIAS_FLAG); hpP.setStyle(Paint.Style.FILL);
        hpP.setColor(fr>0.5f?Color.rgb(50,220,50):fr>0.25f?Color.rgb(240,175,0):Color.rgb(230,50,50));
        c.drawRoundRect(bx,by,bx+bw*fr,by+bh,3,3,hpP);

        c.drawText(p.name,p.x,p.y-r-17f,nameP);
    }

    private void drawHUD(Canvas c){
        if(localPlayer==null) return;
        float w=screenW, h=screenH;

        // HP
        c.drawRoundRect(10,10,215,56,8,8,hudBgP);
        hudP.setColor(Color.rgb(255,75,75)); hudP.setTextSize(27f); hudP.setTextAlign(Paint.Align.LEFT);
        c.drawText("♥ "+(int)Math.ceil(localPlayer.hp), 22, 46, hudP);

        // gun + ammo (centre top)
        if(localPlayer.alive){
            Gun g=localPlayer.currentGun();
            String gs=g.name+"  "+(g.reloading?"RELOADING…":g.ammo+"/"+g.maxAmmo);
            c.drawRoundRect(w/2-175,10,w/2+175,54,8,8,hudBgP);
            gunTxtP.setColor(g.color);
            c.drawText(gs,w/2,43,gunTxtP);
        }

        // kill feed
        hudP.setColor(Color.rgb(255,210,70)); hudP.setTextSize(18f); hudP.setTextAlign(Paint.Align.LEFT);
        synchronized(feed){ for(int i=0;i<feed.size();i++) c.drawText(feed.get(i),12,72+i*24,hudP); }

        // death overlay
        if(!localPlayer.alive){
            c.drawRect(0,0,w,h,deathBgP);
            c.drawText("YOU DIED",w/2,h/2-18,deathTxtP);
            long rem=RESPAWN_MS-(System.currentTimeMillis()-deathTime);
            if(rem>0){
                Paint t2=new Paint(deathTxtP); t2.setTextSize(28f); t2.setColor(Color.WHITE);
                t2.setTextAlign(Paint.Align.CENTER);
                c.drawText("Respawning in "+(rem/1000+1)+"s",w/2,h/2+38,t2);
            }
        }

        // buttons
        c.drawRoundRect(switchRect,10,10,btnP);
        c.drawText("SWITCH GUN",switchRect.centerX(),switchRect.centerY()+8,btnTxtP);
        c.drawRoundRect(reloadRect,10,10,btnP);
        c.drawText("RELOAD",reloadRect.centerX(),reloadRect.centerY()+8,btnTxtP);

        // joysticks
        if(moveStick!=null) moveStick.draw(c);
        if(aimStick!=null)  aimStick.draw(c);

        // player count
        if(isHost){
            hudP.setColor(Color.argb(150,200,200,200)); hudP.setTextSize(18f);
            c.drawText("Players: "+(remote.size()+1),12,h-8,hudP);
        }
    }

    // ═══ NETWORK SERIALIZE ════════════════════════════════════════════════════
    private void broadcast(){
        try{
            JSONObject root=new JSONObject();
            JSONArray pa=new JSONArray();
            pa.put(pj(localPlayer));
            for(Player p:remote.values()) pa.put(pj(p));
            root.put("p",pa);
            JSONArray ba=new JSONArray();
            for(Bullet b:bullets){
                JSONObject bj=new JSONObject();
                bj.put("x",(int)b.x); bj.put("y",(int)b.y);
                bj.put("u",(int)b.dx); bj.put("v",(int)b.dy);
                bj.put("o",b.ownerId); bj.put("d",(int)b.damage); bj.put("i",b.id);
                ba.put(bj);
            }
            root.put("b",ba);
            net.broadcastState(root.toString());
        }catch(Exception e){ e.printStackTrace(); }
    }

    private JSONObject pj(Player p) throws Exception {
        JSONObject o=new JSONObject();
        o.put("i",p.id); o.put("n",p.name);
        o.put("x",(int)p.x); o.put("y",(int)p.y);
        o.put("a",(double)p.angle);
        o.put("h",(int)p.hp); o.put("g",p.gunIndex); o.put("v",p.alive);
        return o;
    }

    private void applyState(String json){
        try{
            JSONObject root=new JSONObject(json);
            JSONArray pa=root.getJSONArray("p");
            for(int i=0;i<pa.length();i++){
                JSONObject o=pa.getJSONObject(i);
                int id=o.getInt("i"); boolean alive=o.getBoolean("v");
                if(localPlayer!=null&&id==localPlayer.id){
                    boolean was=localPlayer.alive;
                    localPlayer.hp=o.getInt("h"); localPlayer.alive=alive;
                    if(was&&!alive) deathTime=System.currentTimeMillis();
                    continue;
                }
                Player p=remote.get(id);
                if(p==null){p=new Player();p.id=id;p.guns=Gun.createAll();remote.put(id,p);}
                p.name=o.getString("n"); p.x=o.getInt("x"); p.y=o.getInt("y");
                p.angle=(float)o.getDouble("a"); p.hp=o.getInt("h");
                p.gunIndex=o.getInt("g"); p.alive=alive;
            }
            JSONArray ba=root.getJSONArray("b");
            bullets.clear();
            for(int i=0;i<ba.length();i++){
                JSONObject bj=ba.getJSONObject(i);
                bullets.add(new Bullet(bj.getInt("x"),bj.getInt("y"),
                    bj.getInt("u"),bj.getInt("v"),
                    bj.getInt("o"),bj.getInt("d"),bj.getInt("i")));
            }
        }catch(Exception e){ e.printStackTrace(); }
    }

    private void sendInput(){
        if(localPlayer==null) return;
        try{
            JSONObject o=new JSONObject();
            o.put("0",moveStick.getX()); o.put("1",moveStick.getY());
            o.put("2",aimStick.getX());  o.put("3",aimStick.getY());
            o.put("4",aimStick.isActive());
            o.put("5",localPlayer.gunIndex);
            o.put("6",localPlayer.currentGun().reloading);
            net.sendInput(o.toString());
        }catch(Exception e){ e.printStackTrace(); }
    }

    // ═══ CALLBACKS ════════════════════════════════════════════════════════════
    @Override public void onHostDiscovered(String ip,String n){}
    @Override public void onJoined(int id){
        // called from network thread; assignment of reference is atomic
        Player p=new Player(); p.id=id; p.name=savedName; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        localPlayer=p;
    }
    @Override public void onPlayerJoined(int id,String name){
        if(remote.containsKey(id)) return;
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        remote.put(id,p); addFeed(name+" joined");
    }
    @Override public void onStateUpdate(String json){ pendingState=json; }
    @Override public void onInputReceived(int pid,String json){
        try{
            JSONObject o=new JSONObject(json);
            inputs.put(pid,new float[]{
                (float)o.getDouble("0"),(float)o.getDouble("1"),
                (float)o.getDouble("2"),(float)o.getDouble("3"),
                o.getBoolean("4")?1f:0f,(float)o.getInt("5"),o.getBoolean("6")?1f:0f
            });
        }catch(Exception e){ e.printStackTrace(); }
    }

    // ═══ UTIL ═════════════════════════════════════════════════════════════════
    private static float d2(float ax,float ay,float bx,float by){float dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private String nameOf(int id){
        if(localPlayer!=null&&id==localPlayer.id) return localPlayer.name;
        Player p=remote.get(id); return p!=null?p.name:"P"+id;
    }
    private void addFeed(String msg){
        synchronized(feed){feed.add(0,msg);if(feed.size()>4)feed.remove(feed.size()-1);}
    }
}
