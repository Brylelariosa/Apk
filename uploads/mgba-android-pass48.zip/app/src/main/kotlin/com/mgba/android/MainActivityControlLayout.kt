package com.mgba.android

// Split out of MainActivity.kt (pass 46 — "refactor main activity into
// separate classes so organized") as internal extension functions on
// MainActivity, exactly the pattern already established in SharedUi.kt's
// own top-of-file comment (Thirty-second pass) for the same reason: every
// existing unqualified call site inside MainActivity.kt (and inside every
// other split-out file) keeps compiling completely unchanged, since Kotlin
// resolves an unqualified call to an internal extension function on the
// enclosing receiver type the same way it resolves a member call — no
// behavior change, purely a file-organization move. See MainActivity.kt's
// own top-of-file comment for the full file map.

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.text.InputType
import android.text.TextUtils
import android.text.format.DateFormat
import android.util.Log
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.Closeable
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PrintWriter
import java.io.StringWriter
import java.util.concurrent.atomic.AtomicInteger
import java.util.zip.ZipInputStream
import kotlin.math.abs
import kotlin.math.roundToInt


/** True if [id] should currently be drawn/hit-tested. Base controls
 *  (the original 8 — dpad/a/b/select/start/l/r/ff) are opt-OUT via
 *  removedButtons; extraControlIds are opt-IN via addedExtraButtons.
 *  addButton() gates on this; everywhere else that used to check
 *  removedButtons directly (hitTestEditable, the old add/remove
 *  toggles) now goes through this instead so both catalogs behave
 *  consistently. */
internal fun MainActivity.isButtonVisible(id: String): Boolean =
    if (id in extraControlIds) id in addedExtraButtons else id !in removedButtons


// ── Controls layout ────────────────────────────────────────────────────

/**
 * Builds the on-screen button rects.
 * buttonScaleMultiplier (0.75 / 1.0 / 1.25) scales all button sizes.
 * gameScreenFraction controls where the controls strip begins — the
 * game screen's own actual rendered size can now be independently
 * dragged/resized past this (see gameScreenRect/updateGameMatrix()),
 * but this is still what determines where controls sit.
 */
// ── Layout persistence ───────────────────────────────────────────────────

internal fun MainActivity.orientationTag(): String =
    if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "land" else "port"


internal fun MainActivity.loadCustomLayout() {
    customLayout.clear()
    removedButtons.clear()
    addedExtraButtons.clear()
    // Captured once so every read below (and buildControlLayout()'s own
    // later comparison) agrees on exactly which orientation this call
    // loaded, and so loadedLayoutOrientationTag reflects reality the
    // moment this function returns — see that field's own doc comment
    // (MainActivity.kt) for why that matters.
    val tag = orientationTag()
    loadedLayoutOrientationTag = tag
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val raw = prefs.getString(PREF_LAYOUT_PREFIX + tag, null)
    if (raw != null) {
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                customLayout[o.getString("id")] = LayoutEntry(
                    xFrac = o.getDouble("x").toFloat(),
                    yFrac = o.getDouble("y").toFloat(),
                    scale = o.optDouble("scale", 1.0).toFloat(),
                    alphaOverride = o.optInt("alpha", -1),
                    locked = o.optBoolean("locked", false)
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Corrupt saved layout, ignoring", e)
        }
    }
    // ADD/REMOVE CONTROL — see the removedButtons field comment.
    val rawRemoved = prefs.getString(PREF_REMOVED_PREFIX + tag, null)
    if (rawRemoved != null) {
        try {
            val arr = JSONArray(rawRemoved)
            for (i in 0 until arr.length()) removedButtons.add(arr.getString(i))
        } catch (e: Exception) {
            Log.e(TAG, "Corrupt removed-controls list, ignoring", e)
        }
    }
    // Extra (opt-in) controls — see the addedExtraButtons field comment.
    val rawExtras = prefs.getString(PREF_EXTRAS_PREFIX + tag, null)
    if (rawExtras != null) {
        try {
            val arr = JSONArray(rawExtras)
            for (i in 0 until arr.length()) addedExtraButtons.add(arr.getString(i))
        } catch (e: Exception) {
            Log.e(TAG, "Corrupt extra-controls list, ignoring", e)
        }
    }
}


internal fun MainActivity.saveCustomLayout() {
    try {
        val arr = JSONArray()
        for ((id, e) in customLayout) {
            arr.put(JSONObject().apply {
                put("id", id); put("x", e.xFrac.toDouble()); put("y", e.yFrac.toDouble())
                put("scale", e.scale.toDouble()); put("alpha", e.alphaOverride); put("locked", e.locked)
            })
        }
        val removedArr = JSONArray().apply { removedButtons.forEach { put(it) } }
        val extrasArr = JSONArray().apply { addedExtraButtons.forEach { put(it) } }
        // FIX (direct report: "the button customization reset if you
        // closed the app ... not using the menu, but if you use menu
        // [it's] well saved"): this was .apply() — queues the actual
        // disk write on a background thread and returns immediately,
        // so the moment this call returns (and the "Layout saved"
        // toast fires below) is *not* the moment the data is actually
        // durable on disk, only the moment it's durable in this
        // process's own memory. Android does try to flush any pending
        // apply() before a normal activity transition, which is
        // exactly why leaving through some other in-app screen first
        // ("using the menu") gave that flush time to happen and made
        // this look fine — but a process torn down immediately and
        // more abruptly right after Save (swiping the app away, an
        // OEM task killer) can beat that flush outright, and the very
        // next cold start then reads whatever was on disk *before*
        // this save — indistinguishable from the customization having
        // been silently reset. commit() blocks this call until the
        // write has genuinely landed on disk, so by the time this
        // function returns (still just once, from a deliberate Save
        // tap — not a hot path) that race can't happen at all,
        // regardless of how or how soon the app is closed afterward.
        // exportLayoutBackup() right below was already a plain
        // synchronous File.writeText() and needed no equivalent
        // change.
        val committed = getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(PREF_LAYOUT_PREFIX + orientationTag(), arr.toString())
            .putString(PREF_REMOVED_PREFIX + orientationTag(), removedArr.toString())
            .putString(PREF_EXTRAS_PREFIX + orientationTag(), extrasArr.toString())
            .commit()
        if (!committed) Log.w(TAG, "saveCustomLayout(): SharedPreferences.commit() reported failure")
        exportLayoutBackup()
    } catch (e: Exception) {
        Log.e(TAG, "Failed to save layout", e)
        uiToast("Couldn't save layout")
    }
    editDirty = false
}


/** Mirrors the layout SharedPreferences data saveCustomLayout() just
 *  wrote out to a plain JSON file in the automatic own-folder mirror —
 *  see the FEATURE block above dataFolderTree(). Both orientation
 *  profiles ("land" and "port"), not just whichever one's active right
 *  now, so a restore later doesn't depend on which orientation happened
 *  to be live when the backup was taken. Steps aside once a Storage
 *  folder is configured, same as mirrorToAutoFolder() — see
 *  autoFolderMirrorActive()'s own doc comment for why. Never throws:
 *  same "must never fail the real save" discipline as every other
 *  mirror in this feature — SharedPreferences is already the save at
 *  this point, this is purely an extra copy on top of it. */
internal fun MainActivity.exportLayoutBackup() {
    if (!autoFolderMirrorActive()) return
    val dir = autoMirrorSubdir("Layout") ?: return
    try {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val out = JSONObject()
        for (tag in ORIENTATION_TAGS) {
            val entry = JSONObject()
            prefs.getString(PREF_LAYOUT_PREFIX + tag, null)?.let { entry.put("layout", JSONArray(it)) }
            prefs.getString(PREF_REMOVED_PREFIX + tag, null)?.let { entry.put("removed", JSONArray(it)) }
            prefs.getString(PREF_EXTRAS_PREFIX + tag, null)?.let { entry.put("extras", JSONArray(it)) }
            out.put(tag, entry)
        }
        File(dir, "controls_backup.json").writeText(out.toString(2))
    } catch (e: Exception) {
        Log.w(TAG, "exportLayoutBackup() failed", e)
    }
}


/** Restores the file exportLayoutBackup() above writes, but ONLY when
 *  SharedPreferences has genuinely never seen a saved layout for EITHER
 *  orientation profile — this pass's direct report ("if i clear cache my
 *  button reset") is exactly that: the live copy is gone from wherever
 *  it was cleared, but a copy in the automatic own-folder mirror
 *  survived, since that's outside this app's own storage entirely (see
 *  the FEATURE block above dataFolderTree()). Never overwrites a layout
 *  that's actually in use: if a save has ever landed in SharedPreferences
 *  for either orientation, however long ago, this does nothing at all —
 *  a stale backup restoring over live, current settings would be a worse
 *  bug than the one this fixes. Called once, from onCreate(), before
 *  loadCustomLayout() reads SharedPreferences as normal — this only
 *  ever pre-fills that read, loadCustomLayout() itself needs no changes. */
internal fun MainActivity.importLayoutBackupIfNeeded() {
    val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val alreadyHasLayout = ORIENTATION_TAGS.any {
        prefs.contains(PREF_LAYOUT_PREFIX + it) ||
        prefs.contains(PREF_REMOVED_PREFIX + it) ||
        prefs.contains(PREF_EXTRAS_PREFIX + it)
    }
    if (alreadyHasLayout) return
    val dir = autoMirrorSubdir("Layout") ?: return
    val file = File(dir, "controls_backup.json")
    if (!file.exists()) return
    try {
        val root = JSONObject(file.readText())
        val editor = prefs.edit()
        var restoredAny = false
        for (tag in ORIENTATION_TAGS) {
            val entry = root.optJSONObject(tag) ?: continue
            entry.optJSONArray("layout")?.let { editor.putString(PREF_LAYOUT_PREFIX + tag, it.toString()); restoredAny = true }
            entry.optJSONArray("removed")?.let { editor.putString(PREF_REMOVED_PREFIX + tag, it.toString()); restoredAny = true }
            entry.optJSONArray("extras")?.let { editor.putString(PREF_EXTRAS_PREFIX + tag, it.toString()); restoredAny = true }
        }
        if (restoredAny) {
            // FIX (consistency/robustness pass, prompted by the same
            // report as loadedLayoutOrientationTag's own fix): .commit()
            // rather than .apply(), matching saveCustomLayout()'s own
            // reasoning — this runs once, early in onCreate(), and a
            // process death in the narrow window before .apply()'s
            // background write actually lands would otherwise silently
            // undo the very restore this function exists to do.
            editor.commit()
            Log.i(TAG, "Restored control layout from the automatic own-folder backup")
        }
    } catch (e: Exception) {
        Log.w(TAG, "importLayoutBackupIfNeeded() failed", e)
    }
}


/** Computes the on-screen rect for [id] given its DEFAULT center/size,
 *  applying any saved/in-progress override. Always records the default
 *  geometry so "reset this button" and a brand-new drag both have a
 *  known baseline to work from, even if a saved override already exists. */
internal fun MainActivity.resolvedRect(id: String, cx: Float, cy: Float, w: Float, h: Float): RectF {
    defaultGeometry[id] = Geometry(cx, cy, w, h)
    val ov = customLayout[id]
    val fcx = if (ov != null) ov.xFrac * lastSw else cx
    val fcy = if (ov != null) ov.yFrac * lastSh else cy
    val scale = ov?.scale ?: 1f
    val fw = (w * scale).coerceAtLeast(1f)
    val fh = (h * scale).coerceAtLeast(1f)
    return RectF(fcx - fw / 2f, fcy - fh / 2f, fcx + fw / 2f, fcy + fh / 2f)
}


internal fun MainActivity.addButton(id: String, cx: Float, cy: Float, w: Float, h: Float, mask: Int, label: String, color: Int, isDpad: Boolean = false) {
    // Always resolve — and so record defaultGeometry — even if [id] is
    // currently hidden, so "+ Add control" (showAddControlMenu) has a
    // sane default position/size to bring it back at rather than
    // whatever stale geometry happened to be lying around.
    val rect = resolvedRect(id, cx, cy, w, h)
    if (!isButtonVisible(id)) return   // ADD/REMOVE CONTROL — hidden, skip drawing/hit-testing
    buildingButtons += ButtonDef(id, rect, mask, label, color, isDpad)
}


// ── Control layout (positions/sizes) ────────────────────────────────────
//
// CONTROL EDITOR (feature #2): every button below is now addressable by a
// stable id and routed through resolvedRect()/addButton(), which checks
// customLayout for a saved override before falling back to the default
// formula. The formulas themselves are UNCHANGED from the original
// design — they're still exactly what you get on a fresh install or
// after "Reset all" — only the indirection through an override is new.
internal fun MainActivity.buildControlLayout(sw: Float, sh: Float) {
    // FIX (direct report: "if you back the emulator without using the
    // closed on menu the layout reset you have to go to setting layout
    // to select the layout again") — see loadedLayoutOrientationTag's
    // own doc comment (MainActivity.kt) for the full diagnosis:
    // loadCustomLayout() only ever ran once, from onCreate(), at a point
    // that's always Portrait regardless of the player's actual chosen
    // game orientation. This is the single choke point every
    // layout-affecting path already funnels through — a real device
    // rotation reaches it via surfaceChanged()'s own call with the new
    // w/h, exactly the moment orientationTag() first reflects the
    // change — so reloading here the instant the real tag disagrees
    // with whichever one is currently loaded closes that gap, and as a
    // side effect also covers KNOWN_LIMITATIONS.md's separate,
    // previously-accepted note about a live orientation switch
    // mid-session not reloading the active layout, since that reaches
    // this same check the same way. Skipped while editModeActive: an
    // in-progress drag/resize has unsaved customLayout changes of its
    // own that a same-session rotation shouldn't discard (see
    // KNOWN_LIMITATIONS.md — rotating *while actively editing* remains
    // the one pre-existing, documented gap this doesn't attempt to
    // solve too).
    val currentOrientationTag = orientationTag()
    if (!editModeActive && currentOrientationTag != loadedLayoutOrientationTag) {
        loadCustomLayout()
    }

    buildingButtons = mutableListOf()
    lastSw = sw; lastSh = sh
    controlsTop = sh * gameScreenFraction
    val padH = sh - controlsTop

    // Apply scale multiplier to all button sizes
    val s      = buttonScaleMultiplier
    val btnSz  = minOf(padH * 0.24f, sw * 0.084f) * s
    val abSz   = btnSz * 0.94f
    outlineStrokeW = (minOf(sw, sh) * 0.006f).coerceIn(3f, 7f)

    // ── D-pad (left side) ────────────────────────────────────────────
    // FEATURE: unified into ONE control (id "dpad") instead of four
    // separate up/down/left/right hitboxes. Two problems that fixes:
    //  1. Editor UX — previously you had to drag/resize 4 buttons
    //     individually to reshape the d-pad, easy to knock out of
    //     alignment. Now it's one object, exactly like My Boy!'s pad.
    //  2. Diagonals — the old 4 separate rects had gaps between them
    //     (arranged in a cross with `step` spacing), so touching between
    //     e.g. up and right hit NEITHER hitbox — diagonal input was
    //     physically impossible. The unified pad hit-tests by angle
    //     (see dpadKeysFor()) so diagonals work like a real d-pad.
    val dpCx = sw * 0.18f
    val dpCy = controlsTop + padH * 0.52f
    val dpadSize = btnSz * 3.0f
    addButton("dpad", dpCx, dpCy, dpadSize, dpadSize, 0, "", colorAccentLight, isDpad = true)

    // ── A / B (right side) ────────────────────────────────────────────
    // OUTLINE SKIN: back to the same light/neutral accent as every other
    // button. The red outline read as a "turbo/rapid-fire" A/B variant
    // (that's the usual convention in emulator skins) rather than the
    // normal buttons, so A/B now match D-pad / L / R / Select / Start.
    val abCx  = sw * 0.82f
    val abCy  = controlsTop + padH * 0.52f
    val abGap = abSz * 1.2f
    addButton("a", abCx+abGap, abCy, abSz, abSz, EmulatorEngine.KEY_A, "A", colorAccentLight)
    addButton("b", abCx-abGap, abCy, abSz, abSz, EmulatorEngine.KEY_B, "B", colorAccentLight)

    // ── Turbo A / Turbo B (small red satellites, optional) ─────────────
    // FEATURE (this pass): moved from a single all-or-nothing Settings
    // checkbox (added both together, no way to get just one or to
    // reposition them independently) to the same opt-in-per-button
    // system as every other extra control — see extraControlIds above.
    // No "if" here any more: addButton() already checks
    // isButtonVisible() internally and only actually adds anything
    // tappable when the id's been added via "+ Add control", same as
    // "abturbo"/"ab"/etc. just above and below this block — these two
    // just weren't following that same pattern until now.
    //
    // Label changed from "T" to "A"/"B": "T" was identical on both
    // buttons, so there was no way to tell Turbo A from Turbo B by
    // looking at them — matches "abturbo"'s own convention instead
    // (reuses the equivalent normal button's letter, red color is what
    // signals "this one's the turbo version").
    //
    // keyMask is 0 here on purpose — they must NOT get OR'd straight
    // into currentKeys like a normal button (that'd just be a
    // continuous hold, not rapid-fire). Their held state is tracked
    // separately (turboAHeld/turboBHeld, set in updateGameKeys()) and
    // turned into an actual on/off square wave only at the point it's
    // sent to the core — see nativeSetKeys() call in startGameLoop().
    // BUG FIX (pass 43 — direct report: "turbo a and b not the same
    // size as normal a and b"): tSz was abSz * 0.75f — a fixed 75%
    // shrink baked into the DEFAULT size, applied underneath (before)
    // each button's own independent Control Size slider, not instead
    // of it. That meant Turbo A/B looked smaller than A/B even at
    // matching slider percentages — both set to the same 100% still
    // rendered two different sizes, since 100% of a smaller base is
    // still smaller. Turbo A/B keep their own independent
    // position/scale entries — still draggable/resizable separately
    // from A/B, same as before — only the DEFAULT size this scales
    // from now matches A/B's, so the same number on both sliders
    // actually means the same size on screen.
    val tSz = abSz
    val tOffX = abSz * 0.75f
    val tOffY = abSz * 0.95f
    addButton("ta", abCx+abGap+tOffX, abCy-tOffY, tSz, tSz, 0, "A", colorAccentRed)
    addButton("tb", abCx-abGap-tOffX, abCy-tOffY, tSz, tSz, 0, "B", colorAccentRed)

    // ── Select / Start (centre) ───────────────────────────────────────
    // Shortened from the old 0.11×/0.038× (≈6.4:1 — a long thin bar)
    // down to a squatter ≈3:1 pill.
    //
    // FIX (direct report: "if you go portrait the button ge weird"):
    // ssH used to be sh * 0.052f — sh alone. That only reads as the
    // intended squat pill because sw is normally *larger* than sh
    // (landscape): ssW (from sw) ends up bigger than ssH (from sh)
    // basically by coincidence, not because the formula says so. In
    // portrait sw and sh swap which one is bigger — ssW shrinks, ssH
    // grows — and the exact same formula flips into a tall, narrow
    // sliver instead. minOf(sw, sh) is the fix: in landscape it *is*
    // sh (sh is already the smaller of the two there), so this is a
    // no-op for every current landscape install; in portrait it's sw
    // instead of the larger sh, so ssH can never grow past ssW's own
    // reference and invert the shape. outlineStrokeW just above
    // already uses this exact minOf(sw, sh) pattern for the same
    // "stay sane across orientation" reason.
    val ssW  = sw * 0.072f * s;  val ssH  = minOf(sw, sh) * 0.052f * s
    val ssCy = controlsTop + padH * 0.82f + ssH / 2f
    val ssGap = sw * 0.07f
    addButton("select", sw/2f-ssGap-ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_SELECT, "SEL", colorAccentLight)
    addButton("start",  sw/2f+ssGap+ssW/2f, ssCy, ssW, ssH, EmulatorEngine.KEY_START,  "STA", colorAccentLight)

    // ── L / R shoulder buttons ─────────────────────────────────────────
    // Reshaped to match the reference skin: a squat ~2:1 trigger glyph
    // (flat hinge edge + one big rounded sweep — see shoulderButtonPath())
    // instead of the old 0.13×/0.042× (~6.9:1) long thin bar.
    //
    // FIX (direct report: "if you go portrait the button ge weird
    // like r l"): same root cause and same fix as ssH just above —
    // lrH was sh * 0.075f, so this "squat" shape only ever held up in
    // landscape (sw > sh) by coincidence; in portrait (sw < sh) it
    // inverted into a tall, narrow sliver instead of the intended
    // trigger shape. minOf(sw, sh) keeps landscape byte-for-byte
    // identical (sh already is the smaller side there) while making
    // portrait use the same reference axis as lrW, so the ~2:1
    // proportion holds regardless of orientation.
    val lrW = sw * 0.07f  * s;  val lrH = minOf(sw, sh) * 0.075f * s
    val lrY = controlsTop + padH * 0.06f + lrH / 2f
    val lrCxL = sw*0.03f+lrW/2f
    val lrCxR = sw-sw*0.03f-lrW/2f
    addButton("l", lrCxL, lrY, lrW, lrH, EmulatorEngine.KEY_L, "L", colorAccentLight)
    addButton("r", lrCxR, lrY, lrW, lrH, EmulatorEngine.KEY_R, "R", colorAccentLight)

    // ── ⏩ Fast-forward — docked directly under R (matching the
    // reference layout) instead of floating above SEL/STA. Roughly
    // square, sized off R's own height, with about one R-height of gap
    // between them.
    // Not pushed into `buttons` (it isn't a GBA key — see onGameTouch),
    // but still routed through resolvedRect() so it's just as draggable
    // and resizable in the editor as every other button.
    val utilSize = lrH
    val utilY = lrY + lrH/2f + lrH + utilSize/2f
    val ffRect = resolvedRect("ff", lrCxR, utilY, utilSize, utilSize)
    // ADD/REMOVE CONTROL: an empty RectF.contains() is always false for
    // any point, so this alone is enough to make a hidden ff both
    // undrawable and untappable — see drawControls()/onGameTouch().
    ffBtnRect = if (isButtonVisible("ff")) ffRect else RectF()
    // NOTE: fsBtnRect REMOVED — fullscreen is now in ⚙ Settings only

    // ── Extra controls (opt-in via "+ Add control") ────────────────────
    // FEATURE: new — the shoulder+face combos (TL+A/TL+B/TR+A/TR+B),
    // the A/B combos (plain + turbo), and three one-tap actions (quick
    // save/load, screenshot), matching the reference app's own "Add
    // control" catalog. Hidden until explicitly added (extraControlIds/
    // addedExtraButtons/isButtonVisible) — every one of these is a
    // completely ordinary addButton() entry once visible, so it's just
    // as draggable/resizable/lockable/removable as any base button with
    // no extra plumbing. This default spot (a small two-row cluster
    // between the shoulder buttons and the D-pad/A-B row — clear of
    // both at every screen size this app targets) only has to be a
    // reasonable starting point, since where it ends up is entirely up
    // to whoever adds it.
    val exSz    = btnSz * 0.56f
    val exGapX  = exSz * 1.35f
    val exRow1Y = controlsTop + padH * 0.27f
    val exRow2Y = controlsTop + padH * 0.42f
    val exRow1X0 = sw * 0.5f - exGapX * 2f
    addButton("la", exRow1X0,             exRow1Y, exSz, exSz, EmulatorEngine.KEY_L or EmulatorEngine.KEY_A, "LA", colorAccentLight)
    addButton("lb", exRow1X0 + exGapX,    exRow1Y, exSz, exSz, EmulatorEngine.KEY_L or EmulatorEngine.KEY_B, "LB", colorAccentLight)
    addButton("ab", exRow1X0 + exGapX*2f, exRow1Y, exSz, exSz, EmulatorEngine.KEY_A or EmulatorEngine.KEY_B, "AB", colorAccentLight)
    addButton("ra", exRow1X0 + exGapX*3f, exRow1Y, exSz, exSz, EmulatorEngine.KEY_R or EmulatorEngine.KEY_A, "RA", colorAccentLight)
    addButton("rb", exRow1X0 + exGapX*4f, exRow1Y, exSz, exSz, EmulatorEngine.KEY_R or EmulatorEngine.KEY_B, "RB", colorAccentLight)
    val exRow2X0 = sw * 0.5f - exGapX * 1.5f
    // "abturbo" reuses the same red-for-turbo convention as ta/tb above
    // (see updateGameKeys()'s "abturbo" case for how it actually drives
    // both satellites' phase-square-wave at once).
    // FIX (direct report: "it use emoji don't use emoji"): these three
    // were the only buttons in the whole customizable control layout
    // still using emoji glyphs as their drawn label — everything else
    // in this row (AB/LA/LB/RA/RB above) was already plain text. Same
    // 2-letter convention as those, so drawOutlineButton()'s label
    // sizing (rect.height()*0.42f, unchanged) needs no adjustment —
    // it was already tuned for exactly this length.
    addButton("abturbo",    exRow2X0,             exRow2Y, exSz, exSz, 0, "AB", colorAccentRed)
    // FIX (direct report: "...make real button that no letter but still
    // you know what that button and same for screenshot"): label is ""
    // for these four now — drawOutlineButton()'s own `when` special-
    // cases each of these ids to draw a real vector icon instead of
    // drawOutlineButton()'s default text-label rendering, same way "a"/
    // "l"/"select" etc. already get a shape instead of a plain rect.
    // "record" (FEATURE — screen recorder toggle) joins this same
    // one-tap-action row for the same reason: it belongs with these
    // three, not as a fifth different kind of control.
    addButton("quicksave",  exRow2X0 + exGapX,    exRow2Y, exSz, exSz, 0, "", colorAccentLight)
    addButton("quickload",  exRow2X0 + exGapX*2f, exRow2Y, exSz, exSz, 0, "", colorAccentLight)
    addButton("screenshot", exRow2X0 + exGapX*3f, exRow2Y, exSz, exSz, 0, "", colorAccentLight)
    addButton("record",     exRow2X0 + exGapX*4f, exRow2Y, exSz, exSz, 0, "", colorAccentRed)

    // Publish the whole list in one atomic reference write — see the
    // `buttons` field comment for why this matters.
    buttons = buildingButtons

    // FEATURE: keeps gameScreenRect (and the actual rendered image —
    // updateGameMatrix() is what gameScreenRect ultimately drives) in
    // sync with every button-layout change, live drag/resize included,
    // rather than needing updateGameMatrix() threaded individually
    // through every one of buildControlLayout's own call sites. Safe
    // to call unconditionally — updateGameMatrix() already no-ops via
    // its own frameBuffers null check on any call site reached before
    // a ROM is loaded.
    updateGameMatrix(sw, sh)

    if (editModeActive) refreshEditToolbarPosition()
}

internal fun MainActivity.updateLinearFilterPaint() { gamePaint.isFilterBitmap = linearFilterEnabled }


internal fun MainActivity.drawControls(canvas: Canvas) {
    // ADD/REMOVE CONTROL: `buttons` can now legitimately be empty (every
    // normal button removed) while ff is still shown, or vice versa —
    // used to be a flat "buttons.isEmpty() => bail entirely", which was
    // fine back when buttons was only empty before the very first
    // buildControlLayout() call. Now it'd also silently hide a still-
    // present ff button any time every OTHER control was removed. Bail
    // only when there is truly nothing to draw.
    val ffVisible = ffBtnRect.width() > 0f
    if (buttons.isEmpty() && !ffVisible) return

    val keys       = currentKeys.get()
    // Idle alpha scales with user preference; press brightens by +80.
    // Per-button opacity overrides from the editor take priority — see
    // the loop below.
    val idleAlpha  = buttonBaseAlpha

    for (btn in buttons) {
        val ov = customLayout[btn.id]?.alphaOverride ?: -1
        val btnIdle = if (ov >= 0) ov else idleAlpha
        if (btn.isDpad) {
            drawDpad(canvas, btn.rect, keys, btnIdle)
            continue
        }
        val pressed = when (btn.id) {
            "ta" -> turboAHeld
            "tb" -> turboBHeld
            "abturbo" -> turboAHeld && turboBHeld
            // FEATURE: "pressed" here drives drawActionButtonIcon()'s
            // hollow-ring-vs-filled-dot look — recording state, not
            // finger-down, same as turboAHeld/turboBHeld above being
            // held state rather than touch state.
            "record" -> screenRecorder?.isRecording == true
            // FIX (direct report: "quick load and save button is bad
            // there highlights same for screenshot button") — these
            // three fire instantly on ACTION_DOWN with no held state to
            // check (keyMask is always 0 for them, so the `else` branch
            // below never lit them up at all before this), so they need
            // their own short flash window instead — see
            // triggerActionButton()/actionButtonFlashId's own comments.
            "quicksave", "quickload", "screenshot" ->
                actionButtonFlashId == btn.id && System.currentTimeMillis() < actionButtonFlashUntil
            // BUG FIX: was `keys and btn.keyMask != 0` — correct for a
            // single-bit mask, but for the new combo buttons (e.g. "la"
            // = KEY_L|KEY_A) that lit up as soon as EITHER key was down
            // from any source, not just when this specific combo's own
            // full press was active. Requiring every bit fixes that and
            // is equivalent to the old check for every single-bit button.
            else -> btn.keyMask != 0 && keys and btn.keyMask == btn.keyMask
        }
        drawOutlineButton(canvas, btn.rect, btn.id, btn.label, btn.color, btnIdle, pressed)
    }

    // ── » Fast-forward button ────────────────────────────────────────
    if (!ffVisible) return
    val ffPressed = fastForwardActive
    val ffAlpha = (idleAlpha + 20).coerceAtMost(255)
    strokePaint.color = if (ffPressed) colorFfActive else colorAccentLight
    strokePaint.alpha = ffAlpha
    strokePaint.strokeWidth = outlineStrokeW
    if (ffPressed) {
        fillPaint.color = colorFfActive
        fillPaint.alpha = (ffAlpha * 0.35f).toInt().coerceIn(0, 255)
        canvas.drawRoundRect(ffBtnRect, 8f, 8f, fillPaint)
    }
    canvas.drawRoundRect(ffBtnRect, 8f, 8f, strokePaint)
    labelPaint.textSize = (ffBtnRect.height() * 0.52f).coerceAtLeast(12f)
    // FIX (this pass): used to show "» 4×" (the active speed) while
    // toggled on — reported as an indicator that shouldn't be there at
    // all. The color/fill change above (colorFfActive, the translucent
    // fill) already shows on/off state on its own; just "»" either way
    // now, no text distinguishing the two beyond that.
    canvas.drawText("»",
        ffBtnRect.centerX(), ffBtnRect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
    // NOTE: ⛶ fullscreen button no longer drawn here — it lives in ⚙ Settings
}


internal fun MainActivity.shoulderButtonPath(rect: RectF, mirrored: Boolean): Path {
    val path = if (mirrored) shoulderPathR else shoulderPathL
    val cachedRect = if (mirrored) shoulderRectR else shoulderRectL
    if (cachedRect == rect) return path   // geometry unchanged since last frame — reuse as-is
    cachedRect.set(rect)
    val w = rect.width(); val h = rect.height()
    val c = h * 0.22f              // small round on the two hinge-side corners
    val bottomRun = w * 0.30f      // length of the short flat bottom segment
    val left = rect.left; val top = rect.top; val right = rect.right; val bottom = rect.bottom
    path.rewind()
    if (!mirrored) {
        // L: hinge (flat) edge on the LEFT, big sweep on the RIGHT.
        path.moveTo(left, top + c)
        path.quadTo(left, top, left + c, top)
        path.lineTo(right, top)
        path.cubicTo(
            right + w * 0.02f, top + h * 0.35f,
            right - w * 0.04f, bottom - h * 0.10f,
            left + bottomRun, bottom
        )
        path.lineTo(left + c, bottom)
        path.quadTo(left, bottom, left, bottom - c)
        path.close()
    } else {
        // R: mirror of the above — hinge (flat) edge on the RIGHT.
        path.moveTo(right, top + c)
        path.quadTo(right, top, right - c, top)
        path.lineTo(left, top)
        path.cubicTo(
            left - w * 0.02f, top + h * 0.35f,
            left + w * 0.04f, bottom - h * 0.10f,
            right - bottomRun, bottom
        )
        path.lineTo(right - c, bottom)
        path.quadTo(right, bottom, right, bottom - c)
        path.close()
    }
    return path
}


/** Draws one outlined control button — a stroked circle for A/B (and the
 *  optional Turbo A/B satellites), a stroked shoulder-trigger glyph for
 *  L/R, a stroked pill (fully-rounded rect) for Select/Start, and a
 *  stroked rounded rect as a fallback for anything else. This is the
 *  line-art skin: no solid fill at rest, just a stroke — a soft matching
 *  fill fades in underneath only while the button is actually held, as
 *  the sole "pressed" cue. */
internal fun MainActivity.drawOutlineButton(
    canvas: Canvas, rect: RectF, id: String, label: String,
    accent: Int, idleAlpha: Int, pressed: Boolean
) {
    val alpha = if (pressed) (idleAlpha + 80).coerceAtMost(255) else idleAlpha
    strokePaint.color = accent
    strokePaint.alpha = alpha
    strokePaint.strokeWidth = outlineStrokeW
    if (pressed) {
        fillPaint.color = accent
        fillPaint.alpha = (alpha * 0.30f).toInt().coerceIn(0, 255)
    }
    var labelDx = 0f
    when (id) {
        // FIX (direct report: "quicksave or quickload button is bad i
        // don't like letter on it make real button that no letter but
        // still you know what that button and same for screenshot") —
        // these four used to fall into the plain rounded-rect `else`
        // branch below with a 2-letter text label (QS/QL/SS, and now
        // "record" would have been REC): a bug fix that itself replaced
        // this row's original emoji glyphs (see addButton() call sites'
        // own comment in buildControlLayout()). Letters read as an
        // abbreviation you have to learn, not an icon you recognize —
        // drawn as real vector glyphs instead, same stroke-only skin as
        // every other button, no text at all.
        "quicksave", "quickload", "screenshot", "record" ->
            drawActionButtonIcon(canvas, id, rect, pressed)
        "a", "b", "ta", "tb" -> {
            val cx = rect.centerX(); val cy = rect.centerY()
            val radius = minOf(rect.width(), rect.height()) / 2f - outlineStrokeW / 2f
            if (pressed) canvas.drawCircle(cx, cy, radius, fillPaint)
            canvas.drawCircle(cx, cy, radius, strokePaint)
        }
        "l", "r" -> {
            val p = shoulderButtonPath(rect, mirrored = id == "r")
            if (pressed) canvas.drawPath(p, fillPaint)
            canvas.drawPath(p, strokePaint)
            // Nudge the label into the "meat" of the glyph (the flat
            // hinge side), away from the tapering sweep.
            labelDx = if (id == "l") -rect.width() * 0.18f else rect.width() * 0.18f
        }
        "select", "start" -> {
            val r = rect.height() / 2f
            if (pressed) canvas.drawRoundRect(rect, r, r, fillPaint)
            canvas.drawRoundRect(rect, r, r, strokePaint)
        }
        else -> {
            if (pressed) canvas.drawRoundRect(rect, 12f, 12f, fillPaint)
            canvas.drawRoundRect(rect, 12f, 12f, strokePaint)
        }
    }
    if (label.isNotEmpty()) {
        labelPaint.textSize = (rect.height() * 0.42f).coerceAtLeast(13f)
        canvas.drawText(label, rect.centerX() + labelDx,
            rect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
    }
}


/** Vector glyph for the 4 one-tap action buttons (quicksave/quickload/
 *  screenshot/record) — see the drawOutlineButton() `when` case that
 *  dispatches here for the direct-report context. Same rounded-rect
 *  base and stroke-only skin as drawOutlineButton()'s own `else`
 *  branch (so these still visually belong to the same button family),
 *  with a small stroked icon in place of a text label. Uses the
 *  caller's already-configured strokePaint/fillPaint as-is rather than
 *  touching cap/join style on them — both are shared, reused-every-
 *  frame fields, so a per-icon tweak here would otherwise leak into
 *  every other button drawn afterward. */
internal fun MainActivity.drawActionButtonIcon(canvas: Canvas, id: String, rect: RectF, pressed: Boolean) {
    if (pressed) canvas.drawRoundRect(rect, 12f, 12f, fillPaint)
    canvas.drawRoundRect(rect, 12f, 12f, strokePaint)

    val cx = rect.centerX(); val cy = rect.centerY()
    val s = minOf(rect.width(), rect.height()) * 0.30f   // icon half-extent
    when (id) {
        // Floppy disk silhouette — see drawFloppyDiskIcon()'s own doc
        // comment (SharedUi.kt, shared with the Settings STORAGE glyph)
        // for the shape itself and the direct-report fix it carries.
        "quicksave" -> drawFloppyDiskIcon(canvas, strokePaint, cx, cy, s)
        "quickload" -> {
            // Downward arrow into a tray — the universal "load/restore"
            // silhouette, deliberately distinct from quicksave's floppy.
            canvas.drawLine(cx, cy - s, cx, cy + s * 0.30f, strokePaint)
            canvas.drawLine(cx, cy + s * 0.30f, cx - s * 0.5f, cy - s * 0.20f, strokePaint)
            canvas.drawLine(cx, cy + s * 0.30f, cx + s * 0.5f, cy - s * 0.20f, strokePaint)
            canvas.drawLine(cx - s, cy + s, cx + s, cy + s, strokePaint)
        }
        "screenshot" -> {
            // Simple camera: body + viewfinder bump on top + lens circle.
            canvas.drawRoundRect(cx - s, cy - s * 0.55f, cx + s, cy + s, s * 0.22f, s * 0.22f, strokePaint)
            // FIX (direct report: "highlight... two line[s] overlap" on
            // this button — same defect class as drawFloppyDiskIcon()'s
            // own fix, SharedUi.kt): the bump used to be a full stroked
            // rounded rect sharing its ENTIRE bottom edge with the
            // body's top edge above (both at cy - s*0.55f, the bump's
            // bottom edge in-bounds of the body's straight top edge for
            // its full x*0.32f run) — both strokes landed on that whole
            // stretch of pixels, doubling up into a bright seam right
            // across the join, worse than the floppy disk's original
            // bug since a whole edge overlapped rather than a corner
            // sliver. Only the bump's two exposed top corners stay
            // rounded; its left/right edges now run straight down into
            // the body's already-drawn top edge instead of curving back
            // to retrace it, and the bottom edge itself is never drawn
            // at all — the body already drew that pixel once.
            val bumpL = cx - s * 0.32f; val bumpR = cx + s * 0.32f
            val bumpT = cy - s * 0.95f; val bumpB = cy - s * 0.55f
            val bumpC = s * 0.10f
            canvas.drawLine(bumpL, bumpT + bumpC, bumpL, bumpB, strokePaint)
            canvas.drawLine(bumpR, bumpT + bumpC, bumpR, bumpB, strokePaint)
            canvas.drawLine(bumpL + bumpC, bumpT, bumpR - bumpC, bumpT, strokePaint)
            canvas.drawArc(bumpL, bumpT, bumpL + bumpC * 2f, bumpT + bumpC * 2f, 180f, 90f, false, strokePaint)
            canvas.drawArc(bumpR - bumpC * 2f, bumpT, bumpR, bumpT + bumpC * 2f, 270f, 90f, false, strokePaint)
            canvas.drawCircle(cx, cy + s * 0.15f, s * 0.40f, strokePaint)
        }
        "record" -> {
            // Plain dot — the universal record symbol. `pressed` here
            // means "recording active", not "finger down" — see
            // drawControls()'s own "record" case — so this reads as a
            // hollow ring while idle and fills in solid while recording,
            // same idle/active visual language as every other button.
            canvas.drawCircle(cx, cy, s * 0.85f, strokePaint)
        }
    }
}


/** Recomputes the 4 arm RectFs (and the shared corner radius) from the
 *  d-pad's overall [rect] — only when [rect] has actually changed
 *  since the last call. See drawDpad()'s own PERF FIX comment above
 *  for why this exists as a separate, cache-checked step instead of
 *  inline in drawDpad() the way it used to be. */
internal fun MainActivity.updateDpadArmRects(rect: RectF) {
    if (dpadLastRect == rect) return
    dpadLastRect.set(rect)
    val cx = rect.centerX(); val cy = rect.centerY()
    val r  = minOf(rect.width(), rect.height()) / 2f
    val armLen = r * 0.62f
    val armW   = r * 0.60f
    dpadArmCorner = armW * 0.24f
    fun place(out: RectF, dx: Float, dy: Float) {
        val ax = cx + dx * armLen; val ay = cy + dy * armLen
        out.set(ax - armW / 2f, ay - armW / 2f, ax + armW / 2f, ay + armW / 2f)
    }
    place(dpadArmRectUp,     0f, -1f)
    place(dpadArmRectDown,   0f,  1f)
    place(dpadArmRectLeft,  -1f,  0f)
    place(dpadArmRectRight,  1f,  0f)
}


internal fun MainActivity.drawDpad(canvas: Canvas, rect: RectF, keys: Int, idleAlpha: Int) {
    updateDpadArmRects(rect)
    fun drawArm(armRect: RectF, pressed: Boolean, label: String) {
        val alpha = if (pressed) (idleAlpha + 80).coerceAtMost(255) else idleAlpha
        if (pressed) {
            fillPaint.color = colorAccentLight
            fillPaint.alpha = (alpha * 0.30f).toInt().coerceIn(0, 255)
            canvas.drawRoundRect(armRect, dpadArmCorner, dpadArmCorner, fillPaint)
        }
        strokePaint.color = colorAccentLight
        strokePaint.alpha = alpha
        strokePaint.strokeWidth = outlineStrokeW
        canvas.drawRoundRect(armRect, dpadArmCorner, dpadArmCorner, strokePaint)
        labelPaint.textSize = (armRect.width() * 0.44f).coerceAtLeast(12f)
        canvas.drawText(label, armRect.centerX(), armRect.centerY() + labelPaint.textSize * 0.36f, labelPaint)
    }
    drawArm(dpadArmRectUp,    keys and EmulatorEngine.KEY_UP    != 0, "▲")
    drawArm(dpadArmRectDown,  keys and EmulatorEngine.KEY_DOWN  != 0, "▼")
    drawArm(dpadArmRectLeft,  keys and EmulatorEngine.KEY_LEFT  != 0, "◀")
    drawArm(dpadArmRectRight, keys and EmulatorEngine.KEY_RIGHT != 0, "▶")
}


/** Maps a touch point inside the unified d-pad rect to a GBA key-bit
 *  combination by angle from center, split into 8 x 45° sectors — the
 *  4 cardinal sectors give a single direction, the 4 sectors between
 *  them give the two adjacent bits (a genuine diagonal). A small
 *  circular dead-zone at the very center avoids accidental input from
 *  a light tap that lands near the middle. */
internal fun MainActivity.dpadKeysFor(rect: RectF, x: Float, y: Float): Int {
    val cx = rect.centerX(); val cy = rect.centerY()
    val halfW = (rect.width() / 2f).coerceAtLeast(1f)
    val halfH = (rect.height() / 2f).coerceAtLeast(1f)
    val dx = x - cx; val dy = y - cy
    val distNorm = maxOf(abs(dx) / halfW, abs(dy) / halfH)
    if (distNorm < 0.16f) return 0   // dead zone — no accidental direction from a center tap

    var deg = Math.toDegrees(kotlin.math.atan2(-dy.toDouble(), dx.toDouble()))
    if (deg < 0) deg += 360.0
    val U = EmulatorEngine.KEY_UP; val D = EmulatorEngine.KEY_DOWN
    val L = EmulatorEngine.KEY_LEFT; val R = EmulatorEngine.KEY_RIGHT
    return when {
        deg >= 337.5 || deg < 22.5  -> R
        deg < 67.5                  -> U or R
        deg < 112.5                 -> U
        deg < 157.5                 -> U or L
        deg < 202.5                 -> L
        deg < 247.5                 -> D or L
        deg < 292.5                 -> D
        else                         -> D or R
    }
}

