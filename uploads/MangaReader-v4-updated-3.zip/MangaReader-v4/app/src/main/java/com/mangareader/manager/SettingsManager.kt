package com.mangareader.manager

import android.content.Context

/**
 * Persists user-configurable reader preferences across sessions.
 */
class SettingsManager(context: Context) {

    private val prefs = context.getSharedPreferences("reader_settings", Context.MODE_PRIVATE)

    /**
     * Fling velocity multiplier fed into [ScrollUtils.rememberMomentumFlingBehavior].
     * 1.0 = stock Compose feel; higher = snappier momentum after a flick.
     */
    var scrollSpeed: Float
        get() = prefs.getFloat("scroll_speed", 1.5f)
        set(v) { prefs.edit().putFloat("scroll_speed", v).apply() }

    /**
     * Minimum pixel dimension (either width or height) an image must have to be
     * kept as a manga page. Images that fail this test are treated as site UI
     * noise (icons, ads, small banners) and silently dropped at extraction time.
     *
     * 0 = disabled (keep everything). Default 120 catches most tiny web icons
     * without touching any real manga page.
     *
     * Note: changing this only affects chapters extracted *after* the setting
     * is changed; already-cached chapters need to be cleared & re-opened to
     * reflect the new threshold.
     */
    var minImageDimension: Int
        get() = prefs.getInt("min_image_dim", 120)
        set(v) { prefs.edit().putInt("min_image_dim", v).apply() }
}
