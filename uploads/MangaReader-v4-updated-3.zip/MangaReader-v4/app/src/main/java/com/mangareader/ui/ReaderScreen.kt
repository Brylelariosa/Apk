package com.mangareader.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.SubcomposeAsyncImage
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingProgress
import com.mangareader.viewmodel.ReaderViewModel
import java.io.File
import kotlin.math.roundToInt

private val BAR_BG = Color.Black.copy(alpha = 0.78f)

@Composable
fun ReaderScreen(
    viewModel: ReaderViewModel,
    chapter: Chapter,
    chapterIndex: Int,
    allChapters: List<Chapter>,
    initialProgress: ReadingProgress?,
    onBack: () -> Unit,
    onChapterChange: (Chapter, Int) -> Unit
) {
    BackHandler { onBack() }

    val pages       by viewModel.pages.collectAsStateWithLifecycle()
    val loading     by viewModel.loading.collectAsStateWithLifecycle()
    val error       by viewModel.error.collectAsStateWithLifecycle()
    val scrollSpeed by viewModel.scrollSpeed.collectAsStateWithLifecycle()
    val minImageDim by viewModel.minImageDimension.collectAsStateWithLifecycle()

    // BUG FIX: Key the list state on chapter.id so the scroll position resets
    // to 0 whenever the user navigates to a different chapter.
    //
    // Why this was broken: ReaderScreen stays in the Compose tree across chapter
    // changes — only its parameters change. Without a key, remember() would
    // keep returning the *same* LazyListState (still scrolled to the last page
    // of the previous chapter) even though the pages have been swapped out.
    // Keying on chapter.id forces a fresh LazyListState() — starting at 0 —
    // every time a new chapter is opened.
    val listState = remember(chapter.id) { LazyListState() }

    var showControls by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    // Load chapter when it changes
    LaunchedEffect(chapter.id) {
        viewModel.loadChapter(chapter, chapterIndex)
    }

    // Restore scroll once pages are ready (only for the chapter that has saved progress)
    var scrollRestored by remember(chapter.id) { mutableStateOf(false) }
    LaunchedEffect(pages.size) {
        if (pages.isNotEmpty() && !scrollRestored) {
            scrollRestored = true
            if (initialProgress?.chapterIndex == chapterIndex) {
                val target = initialProgress.pageIndex.coerceIn(0, pages.size - 1)
                listState.scrollToItem(target, initialProgress.scrollOffset)
            }
        }
    }

    // Auto-save progress on every scroll event
    LaunchedEffect(
        listState.firstVisibleItemIndex,
        listState.firstVisibleItemScrollOffset
    ) {
        if (pages.isNotEmpty()) {
            viewModel.saveProgress(
                pageIndex    = listState.firstVisibleItemIndex,
                scrollOffset = listState.firstVisibleItemScrollOffset
            )
        }
    }

    // Settings dialog (shown on top of everything else)
    if (showSettings) {
        ReaderSettingsDialog(
            scrollSpeed   = scrollSpeed,
            minImageDim   = minImageDim,
            onScrollSpeed = { viewModel.setScrollSpeed(it) },
            onMinImageDim = { viewModel.setMinImageDimension(it) },
            onDismiss     = { showSettings = false }
        )
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        when {
            loading -> {
                Column(
                    Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = Color.White)
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "Extracting chapter…",
                        color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            error != null -> {
                Column(
                    Modifier
                        .align(Alignment.Center)
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.BrokenImage,
                        contentDescription = null,
                        tint     = Color.Red.copy(alpha = 0.7f),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        error ?: "Unknown error",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { viewModel.loadChapter(chapter, chapterIndex) }) {
                        Text("Retry")
                    }
                }
            }

            pages.isEmpty() -> {
                Text(
                    "No images found in this chapter",
                    color    = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            else -> {
                // ── Page list ──────────────────────────────────────────────
                LazyColumn(
                    state         = listState,
                    flingBehavior = rememberMomentumFlingBehavior(velocityMultiplier = scrollSpeed),
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectTapGestures { showControls = !showControls }
                        }
                ) {
                    itemsIndexed(pages, key = { _, f -> f.absolutePath }) { _, file ->
                        MangaPage(file)
                    }

                    // Chapter navigation footer
                    item(key = "footer") {
                        ChapterFooter(
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            onPrev = {
                                val i = chapterIndex - 1
                                onChapterChange(allChapters[i], i)
                            },
                            onNext = {
                                val i = chapterIndex + 1
                                onChapterChange(allChapters[i], i)
                            }
                        )
                    }
                }

                // ── Overlay controls (fade in/out on tap) ─────────────────
                AnimatedVisibility(
                    visible = showControls,
                    enter   = fadeIn(),
                    exit    = fadeOut()
                ) {
                    Box(Modifier.fillMaxSize()) {
                        // Top bar
                        ReaderTopBar(
                            chapter       = chapter,
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            currentPage   = listState.firstVisibleItemIndex + 1,
                            totalPages    = pages.size,
                            onBack        = onBack,
                            onSettings    = { showSettings = true },
                            modifier      = Modifier.align(Alignment.TopCenter)
                        )
                        // Bottom chapter navigation
                        ReaderBottomBar(
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            onPrev = {
                                val i = chapterIndex - 1
                                onChapterChange(allChapters[i], i)
                            },
                            onNext = {
                                val i = chapterIndex + 1
                                onChapterChange(allChapters[i], i)
                            },
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )
                    }
                }
            }
        }
    }
}

// ── Settings dialog ────────────────────────────────────────────────────────────

@Composable
private fun ReaderSettingsDialog(
    scrollSpeed: Float,
    minImageDim: Int,
    onScrollSpeed: (Float) -> Unit,
    onMinImageDim: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = Color(0xFF1C1340),
        titleContentColor = Color.White,
        title = { Text("Reader Settings", style = MaterialTheme.typography.titleMedium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {

                // ── Scroll speed ──────────────────────────────────────────
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Text(
                        "Scroll Speed",
                        color = Color.White,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        "%.1fx".format(scrollSpeed),
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleSmall
                    )
                }
                Slider(
                    value         = scrollSpeed,
                    onValueChange = onScrollSpeed,
                    valueRange    = 0.8f..3.0f,
                    steps         = 10,
                    colors        = SliderDefaults.colors(
                        thumbColor       = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary
                    )
                )
                Text(
                    "Controls how far pages travel after a flick. " +
                    "1.0x = stock Android; 2.0x = snappy webtoon feel.",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.45f)
                )

                Spacer(Modifier.height(16.dp))

                // ── Image quality filter ──────────────────────────────────
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Text(
                        "Image Filter",
                        color = Color.White,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        if (minImageDim == 0) "Off" else "${minImageDim}px min",
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.titleSmall
                    )
                }
                // Steps = 7 → 9 snap positions: 0, 100, 200, 300, 400, 500, 600, 700, 800
                Slider(
                    value         = minImageDim.toFloat(),
                    onValueChange = { onMinImageDim(it.roundToInt()) },
                    valueRange    = 0f..800f,
                    steps         = 7,
                    colors        = SliderDefaults.colors(
                        thumbColor       = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary
                    )
                )
                Text(
                    "Hides images smaller than this threshold — removes site icons, " +
                    "ad banners, and other noise mixed into the chapter. " +
                    "Recommended: 200–400px. Takes effect when a chapter is re-extracted " +
                    "(clear cache or re-open).",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.45f)
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                colors  = ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.primary
                )
            ) { Text("Done") }
        }
    )
}

// ── Sub-composables ────────────────────────────────────────────────────────────

@Composable
private fun MangaPage(file: File) {
    SubcomposeAsyncImage(
        model              = file,
        contentDescription = null,
        contentScale       = ContentScale.FillWidth,
        modifier           = Modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        loading = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.7f),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color       = Color.White.copy(alpha = 0.5f),
                    modifier    = Modifier.size(32.dp),
                    strokeWidth = 2.dp
                )
            }
        },
        error = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .background(Color(0xFF1A1A1A)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Page failed to load",
                    color = Color.White.copy(alpha = 0.4f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    )
}

@Composable
private fun ReaderTopBar(
    chapter: Chapter,
    chapterIndex: Int,
    totalChapters: Int,
    currentPage: Int,
    totalPages: Int,
    onBack: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier        = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 10.dp),
        shape           = RoundedCornerShape(18.dp),
        color           = BAR_BG,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    chapter.title,
                    color    = Color.White,
                    style    = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "Ch ${chapterIndex + 1}/$totalChapters  ·  Pg $currentPage/$totalPages",
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, "Settings", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ReaderBottomBar(
    chapterIndex: Int,
    totalChapters: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hasPrev = chapterIndex > 0
    val hasNext = chapterIndex < totalChapters - 1

    Surface(
        modifier        = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 10.dp),
        shape           = RoundedCornerShape(18.dp),
        color           = BAR_BG,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            TextButton(
                onClick  = onPrev,
                enabled  = hasPrev,
                colors   = ButtonDefaults.textButtonColors(contentColor = Color.White)
            ) {
                Icon(Icons.Default.NavigateBefore, null)
                Spacer(Modifier.width(4.dp))
                Text("Prev chapter")
            }

            Text(
                "Chapter ${chapterIndex + 1} / $totalChapters",
                color = Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.labelMedium
            )

            TextButton(
                onClick  = onNext,
                enabled  = hasNext,
                colors   = ButtonDefaults.textButtonColors(contentColor = Color.White)
            ) {
                Text("Next chapter")
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.NavigateNext, null)
            }
        }
    }
}

@Composable
private fun ChapterFooter(
    chapterIndex: Int,
    totalChapters: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF111111))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
        Spacer(Modifier.height(20.dp))

        if (chapterIndex < totalChapters - 1) {
            Button(
                onClick      = onNext,
                modifier     = Modifier.fillMaxWidth(0.7f),
                colors       = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Default.NavigateNext, null)
                Spacer(Modifier.width(6.dp))
                Text("Next Chapter")
            }
        } else {
            Text(
                "You've reached the end!",
                color = Color.White.copy(alpha = 0.5f),
                style = MaterialTheme.typography.bodyMedium
            )
        }

        if (chapterIndex > 0) {
            Spacer(Modifier.height(12.dp))
            TextButton(
                onClick = onPrev,
                colors  = ButtonDefaults.textButtonColors(contentColor = Color.White.copy(alpha = 0.6f))
            ) {
                Icon(Icons.Default.NavigateBefore, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Previous Chapter")
            }
        }

        Spacer(Modifier.height(8.dp))
    }
}
