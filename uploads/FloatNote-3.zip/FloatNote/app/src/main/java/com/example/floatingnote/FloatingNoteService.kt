package com.example.floatingnote

import android.app.AlertDialog
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.text.TextUtils
import android.view.*
import android.widget.*
import androidx.appcompat.content.res.AppCompatResources
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class FloatingNoteService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private lateinit var notesContainer: LinearLayout
    private lateinit var addNoteButton: View
    private var notesList: MutableList<String> = mutableListOf()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val inflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        floatingView = inflater.inflate(R.layout.floating_note, null)

        // Load saved notes
        notesList = NoteStorage.loadNotes(this)

        notesContainer = floatingView!!.findViewById(R.id.notesContainer)
        addNoteButton = floatingView!!.findViewById(R.id.addNoteButton)
        val closeButton = floatingView!!.findViewById<ImageButton>(R.id.closeButton)

        // Set up window params
        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.CENTER or Gravity.START
        params.x = 50
        params.y = 100

        windowManager?.addView(floatingView, params)

        // Make it touchable when user interacts
        floatingView!!.setOnTouchListener { _, _ -> false }

        // Build note list
        refreshNoteViews()

        addNoteButton.setOnClickListener { showNoteEditor(null, -1) }
        closeButton.setOnClickListener { stopSelf() }
    }

    private fun refreshNoteViews() {
        notesContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        notesList.forEachIndexed { index, text ->
            val noteView = inflater.inflate(R.layout.item_note, notesContainer, false) as View
            val preview = noteView.findViewById<TextView>(R.id.notePreview)
            val editBtn = noteView.findViewById<ImageButton>(R.id.editNoteButton)
            val deleteBtn = noteView.findViewById<ImageButton>(R.id.deleteNoteButton)

            // Show first line as preview, or truncated
            val previewText = if (text.contains("\n")) text.substringBefore("\n") + "…" else text
            preview.text = previewText

            editBtn.setOnClickListener { showNoteEditor(text, index) }
            deleteBtn.setOnClickListener {
                notesList.removeAt(index)
                NoteStorage.saveNotes(this, notesList)
                refreshNoteViews()
            }

            notesContainer.addView(noteView)
        }
    }

    private fun showNoteEditor(existingText: String?, position: Int) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_note, null)
        val editText = dialogView.findViewById<EditText>(R.id.noteEditText)
        if (existingText != null) {
            editText.setText(existingText)
            editText.setSelection(existingText.length)
        }

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(if (existingText != null) "Edit Note" else "New Note")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val newText = editText.text.toString().trim()
                if (!TextUtils.isEmpty(newText)) {
                    if (position >= 0) {
                        notesList[position] = newText
                    } else {
                        notesList.add(newText)
                    }
                    NoteStorage.saveNotes(this, notesList)
                    refreshNoteViews()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (floatingView != null) windowManager?.removeView(floatingView)
    }
}