package com.example.floatingnote

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object NoteStorage {
    private const val PREFS_NAME = "floating_notes"
    private const val NOTES_KEY = "notes"
    private val gson = Gson()

    fun loadNotes(context: Context): MutableList<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(NOTES_KEY, "[]") ?: "[]"
        val type = object : TypeToken<MutableList<String>>() {}.type
        return gson.fromJson(json, type) ?: mutableListOf()
    }

    fun saveNotes(context: Context, notes: List<String>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = gson.toJson(notes)
        prefs.edit().putString(NOTES_KEY, json).apply()
    }
}