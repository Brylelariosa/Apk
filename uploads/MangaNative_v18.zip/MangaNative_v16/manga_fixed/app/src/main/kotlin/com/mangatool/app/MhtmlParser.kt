package com.mangatool.app

import android.util.Base64
import com.mangatool.app.model.ImageGroup
import com.mangatool.app.model.ImageItem
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object MhtmlParser {

    /**
     * Stream-parse an MHTML file into an ImageGroup without loading the whole
     * file into RAM.
     *
     * Previous approach: readBytes() in MainActivity loaded the entire file
     * (e.g. 60 MB) into a ByteArray before parsing began — peak RAM was
     * 2–3× the file size.
     *
     * This version reads one line at a time via a BufferedReader and accumulates
     * only one MIME part (one image) in memory at a time.  For a typical 200 KB
     * image base64-encoded to ~270 KB of text that is a ~200× reduction in peak
     * RAM for a 60 MB chapter.
     *
     * Page order is preserved: [partIdx] increments for every MIME part in
     * document order, so sort keys and [ImageItem.originalIdx] assignments are
     * identical to the previous implementation.
     *
     * [onProgress] is called with (imagesFoundSoFar) during the parse pass.
     * Pixel dimensions start at 0 and are filled in a background pass by
     * MainActivity.
     */
    suspend fun parse(
        stream: InputStream,
        filename: String,
        tempDir: File,
        onProgress: ((done: Int) -> Unit)? = null
    ): ImageGroup? = withContext(Dispatchers.IO) {
        try {
            // ── 1. Detect MIME boundary ─────────────────────────────────────
            // ISO-8859-1 preserves all byte values (safe for binary/QP parts);
            // the boundary value is ASCII so the charset choice doesn't matter
            // for detection.
            val reader = stream.bufferedReader(Charsets.ISO_8859_1)

            var boundary: String? = null
            var line: String? = reader.readLine()
            while (line != null && boundary == null) {
                boundary = Regex("""boundary="?([^";\s\r\n]+)"?""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.get(1)
                if (boundary == null) line = reader.readLine()
            }
            if (boundary == null) return@withContext null

            val boundaryMarker = "--$boundary"
            val closingMarker  = "--$boundary--"

            // ── 2. Skip to the first boundary line ─────────────────────────
            while (line != null && !line.startsWith(boundaryMarker)) {
                line = reader.readLine()
            }

            data class Extracted(val sortKey: String, val filePath: String, val size: Int, val ext: String)
            val extracted = mutableListOf<Extracted>()
            var partIdx = 0

            tempDir.mkdirs()

            // ── 3. State machine: boundary → headers → body → boundary ──────
            while (line != null && !line.startsWith(closingMarker)) {

                // READ HEADERS — lines until the blank-line separator
                val headers = StringBuilder()
                line = reader.readLine()
                while (line != null && line.isNotBlank()) {
                    headers.append(line).append('\n')
                    line = reader.readLine()
                }

                val headStr   = headers.toString()
                val typeMatch = CONTENT_TYPE_RE.find(headStr)
                val encoding  = ENCODING_RE.find(headStr)?.groupValues?.get(1)?.lowercase()

                // READ BODY — accumulate lines until the next boundary.
                // A 200 KB image base64-encodes to ~270 KB of ASCII text;
                // StringBuilder holds only one image's worth of data at a time.
                val bodyBuf = StringBuilder()
                line = reader.readLine()
                while (line != null && !line.startsWith(boundaryMarker)) {
                    bodyBuf.append(line).append('\n')
                    line = reader.readLine()
                }

                if (typeMatch != null) {
                    val rawExt = typeMatch.groupValues[1].lowercase()
                    val ext    = if (rawExt == "jpeg") "jpg" else rawExt

                    val bytes: ByteArray? = when (encoding) {
                        "base64" -> try {
                            // Base64.DEFAULT ignores whitespace/newlines —
                            // the '\n' chars appended above are harmless.
                            Base64.decode(
                                bodyBuf.toString().toByteArray(Charsets.ISO_8859_1),
                                Base64.DEFAULT
                            )
                        } catch (_: Exception) { null }

                        "quoted-printable" ->
                            decodeQP(bodyBuf.toString()).toByteArray(Charsets.ISO_8859_1)

                        else -> bodyBuf.toString().toByteArray(Charsets.ISO_8859_1)
                    }

                    if (bytes != null && bytes.size > 100) {
                        // sortKey preserves document order — page numbering is
                        // identical to the previous ByteArray-based implementation.
                        val sortKey = partIdx.toString().padStart(8, '0')
                        val file    = File(tempDir, "$sortKey.$ext")
                        BufferedOutputStream(FileOutputStream(file)).use { it.write(bytes) }
                        extracted += Extracted(sortKey, file.absolutePath, bytes.size, ext)
                        onProgress?.invoke(extracted.size)
                        // bytes and bodyBuf contents go out of scope here — eligible for GC
                    }
                }

                partIdx++
            }

            if (extracted.isEmpty()) return@withContext null

            extracted.sortBy { it.sortKey }
            val images = extracted.mapIndexed { i, r ->
                ImageItem(originalIdx = i, filePath = r.filePath, ext = r.ext, size = r.size)
            }
            ImageGroup(groupName = smartRename(filename)).also { g -> g.allImages.addAll(images) }

        } catch (_: Exception) { null }
    }

    // ── Pattern constants — compiled once, not per call ──────────────────────
    private val CONTENT_TYPE_RE = Regex(
        """Content-Type:\s*image/(jpeg|jpg|png|gif|webp)""", RegexOption.IGNORE_CASE)
    private val ENCODING_RE = Regex(
        """Content-Transfer-Encoding:\s*(base64|quoted-printable)""", RegexOption.IGNORE_CASE)

    private fun decodeQP(s: String): String =
        s.replace(Regex("=[\\r\\n]+"), "")
         .replace(Regex("=[0-9A-Fa-f]{2}")) { it.value.substring(1).toInt(16).toChar().toString() }

    // ── Filename prettifier ───────────────────────────────────────────────────
    private fun smartRename(filename: String): String {
        var n = filename.replace(Regex("\\.mhtml?$", RegexOption.IGNORE_CASE), "")
        n = n.replace(Regex("[_+]"), " ")
        n = n.replace(Regex("\\b(read manga online|read online|manga)\\b", RegexOption.IGNORE_CASE), "")
        n = n.trim()

        val m = Regex("""^(.*?)(\b(?:chapter|ch\.?|no\.?|c\.?|vol\.?|volume|#)\s*[\d.]+|\b\d+)(.*)$""",
            RegexOption.IGNORE_CASE).find(n)

        if (m != null) {
            val prefix = m.groupValues[1].trim()
            var num    = m.groupValues[2].trim()
            val suffix = m.groupValues[3].trim()
            num = num.replace(Regex("(\\d+)")) { it.value.padStart(3, '0') }
            val cp = prefix.replace(Regex("\\[.*?]|\\(.*?\\)"), "").trimEnd('-', '_').trim()
            n = if (cp.isNotEmpty()) "$num - $cp $suffix".trim() else "$num $suffix".trim()
        } else {
            n = n.replace(Regex("\\[.*?]|\\(.*?\\)"), "").trim()
        }

        return n.replace(Regex("\\s+-\\s*$"), "").replace(Regex("\\s+"), " ").trim()
            .ifEmpty { filename.substringBefore('.') }
    }
}
