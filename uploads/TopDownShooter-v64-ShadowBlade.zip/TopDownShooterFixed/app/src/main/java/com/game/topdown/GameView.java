package com.game.topdown;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import org.json.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

public class GameView extends SurfaceView
        implements SurfaceHolder.Callback, Runnable, NetworkManager.Callback {

    // ═══ WORLD ════════════════════════════════════════════════════════════════
    static final float MAP_W = 3600, MAP_H = 3600;
    static final int   PR    = 24;
    static final long  RESPAWN_MS = 5000;

    static final float[][] WALLS = {
        // ── Original top-left quadrant ──────────────────────────────────────
        {400,310,760,350}, {880,120,920,560}, {280,660,315,980},
        {560,540,920,580}, {1100,370,1460,410}, {1530,210,1570,670},
        {680,960,720,1310}, {960,840,1320,880}, {180,1160,540,1200},
        {1430,960,1470,1320}, {540,1520,1060,1560}, {1250,1360,1570,1400},
        {1700,480,1740,920}, {300,1480,340,1920}, {820,1780,1220,1820},
        {1600,1580,1640,2020},
        // ── Top-right quadrant (x + ~1850) ──────────────────────────────────
        {2250,310,2610,350}, {2730,120,2770,560}, {2130,660,2165,980},
        {2410,540,2770,580}, {2950,370,3310,410}, {3380,210,3420,670},
        {2530,960,2570,1310}, {2810,840,3170,880}, {2030,1160,2390,1200},
        {3280,960,3320,1320}, {2390,1520,2910,1560}, {3100,1360,3420,1400},
        {3450,480,3490,920},  {2150,1480,2190,1920}, {2670,1780,3070,1820},
        {3450,1580,3490,2020},
        // ── Bottom-left quadrant (y + ~1800) ────────────────────────────────
        {400,2260,760,2300}, {880,2070,920,2510}, {280,2710,315,3030},
        {560,2490,920,2530}, {1100,2320,1460,2360}, {1530,2160,1570,2620},
        {680,2760,720,3110},  {960,2790,1320,2830}, {180,2960,540,3000},
        {1430,2810,1470,3170},{540,3170,1060,3210}, {1250,3010,1570,3050},
        {1700,2430,1740,2870},{300,3080,340,3520},  {820,3430,1220,3470},
        {1600,3230,1640,3570},
        // ── Bottom-right quadrant ────────────────────────────────────────────
        {2250,2260,2610,2300},{2730,2070,2770,2510},{2130,2710,2165,3030},
        {2410,2490,2770,2530},{2950,2320,3310,2360},{3380,2160,3420,2620},
        {2530,2760,2570,3110},{2810,2790,3170,2830},{2030,2960,2390,3000},
        {3280,2810,3320,3170},{2390,3170,2910,3210},{3100,3010,3420,3050},
        {3450,2430,3490,2870},{2150,3080,2190,3520},{2670,3430,3070,3470},
        {3450,3230,3490,3570},
    };
    static final float[][] SPAWNS = {
        {120,120},{3480,120},{120,3480},{3480,3480},
        {1800,120},{120,1800},{3480,1800},{1800,3480},
        {900,900},{2700,900},{900,2700},{2700,2700},
        {1800,1800},
    };

    // ═══ STATE ════════════════════════════════════════════════════════════════
    private volatile Player   localPlayer;   // volatile: written by net thread (client join)
    private final String      savedName;
    private final Map<Integer,Player> remote   = new ConcurrentHashMap<>();
    private final Map<Integer,Long>   deadAtMs = new ConcurrentHashMap<>();
    private final List<Bullet>        bullets    = new ArrayList<>();
    // Pre-allocated list reused every frame by resolvePlayerCollisions — avoids 60Hz GC
    private final List<Player>        collisionPlayers = new ArrayList<>();
    // Explosion visual: {x, y, spawnTimeMs}
    private final List<long[]>        explosionFx = new ArrayList<>();
    // Client-side predicted hit flash: {worldX, worldY, spawnTimeMs} — instant feedback before server confirms
    private final List<long[]>        predictedHitFx = new ArrayList<>();
    private int bulletId;

    // ── Volt Chakram ──────────────────────────────────────────────────────────
    private final List<VoltChakram> voltChakrams     = new ArrayList<>();
    private       float             voltOrbitAngle   = 0f;   // master orbit ring angle
    private       float             voltCharge       = 0f;   // 0.0–1.0 spin charge
    private       float             voltPrevAimAngle = Float.NaN; // prev frame aim angle
    private       float[]           pendingVoltLaunch = null; // [ax, ay, charge] to send to host

    // ── Shadow Blade ─────────────────────────────────────────────────────────
    // Slash trail entry: [startX, startY, endX, endY, spawnTimeMs, angle, fanSlot]
    private final List<float[]>     slashTrails      = new ArrayList<>();
    private       float             shadowBladeCharge = 0f;  // 0.0–1.0 hold charge

    // ═══ NETWORK ══════════════════════════════════════════════════════════════
    private final NetworkManager          net;
    private final boolean                 isHost;
    private final boolean                 singlePlayer;
    private final Set<Integer>            botIds   = new HashSet<>();
    private       boolean                 trainingMode = false;
    private final Set<Integer>            dummyIds = new HashSet<>();
    private final Map<Integer, float[]>   dummyHome = new HashMap<>();
    private static final int DUMMY_ID_BASE = 50;
    private static final int MAX_DUMMIES   = 6;
    private static final float[][] DUMMY_SPAWNS = {
        {1800,1800},{1500,1800},{2100,1800},
        {1800,1500},{1800,2100},{1650,1650}
    };
    private RectF trainAddDummyBtn, trainRemDummyBtn, trainAddMoneyBtn;
    private volatile String               pendingState;
    private final Map<Integer,float[]>    inputs = new ConcurrentHashMap<>();
    private long lastBroadcast;
    // FIX: network thread writes these; game thread drains them — avoids
    // ConcurrentModificationException on activeBombs / voltChakrams (plain ArrayLists).
    // float[] bomb entry  : [pid, spawnX, spawnY, vx, vy, maxRange]
    // float[] vc entry    : [pid, ax, ay, charge]
    private final ConcurrentLinkedQueue<float[]> netBombQ = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<float[]> netVcQ   = new ConcurrentLinkedQueue<>();
    private String hostIpDisplay = "";  // shown in HUD

    // ═══ INPUT ════════════════════════════════════════════════════════════════
    private Joystick moveStick, aimStick;
    private RectF    switchRect, reloadRect, bombRect, dropRect;

    // ═══ BOMBS ════════════════════════════════════════════════════════════════
    private final List<Bomb> activeBombs = new ArrayList<>();
    private volatile boolean throwingBomb = false;  // true while player is aiming a throw

    // ═══ AIR STRIKE (Pharsa SS) ══════════════════════════════════════════════
    // Each entry: [worldX, worldY, triggerTimeMs, ownerId, flashUntilMs]
    // Phase: triggerTimeMs in future = pending drop, flashUntilMs>0 = exploding
    private final List<double[]> airStrikes = new ArrayList<>();  // [x,y,triggerMs,ownerId,flashUntilMs]
    private static final float  AS_RADIUS   = 110f;   // AoE radius per strike
    private static final float  AS_DAMAGE   = 28f;    // damage per strike
    private static final int    AS_COUNT    = 1;      // single explosion
    private static final float  AS_SPACING  = 180f;   // world-px between points (unused with count=1)
    private static final long   AS_WARNING_MS = 1500L; // warning delay before explosion
    private static final long   AS_DELAY_MS = 220L;   // ms between successive drops
    private static final long   AS_FLASH_MS = 350L;   // explosion flash duration
    private static final float  AS_SPEED    = 1000f;  // bullet speed for aim guide

    // ── Air Strike ring-aim state ─────────────────────────────────────────────
    private static final float AS_RING_R   = 700f;   // big ring radius (world px)
    private float asAimAngle = Float.NaN;             // current aimed angle (NaN = ring hidden)
    private float asAimMag   = 0f;                    // 0‥1 normalised aim-stick magnitude

    // ═══ CONTROL SETTINGS ════════════════════════════════════════════════════
    private static final String PREFS = "shooter_ctrl";
    private volatile boolean settingsOpen = false;
    private RectF   gearRect, settingsPanel, closeSettingsRect;
    private final RectF[] jsSizeOpts  = new RectF[3];
    private final RectF[] swapOpts    = new RectF[2];
    private final RectF[] btnSizeOpts = new RectF[3];
    private final RectF[] opacityOpts   = new RectF[3];
    private final RectF[] aimSensOpts   = new RectF[3];
    private final RectF[] gunStatOpts   = new RectF[2]; // ON/OFF gun stat bars
    private final RectF[] aimLineOpts     = new RectF[2]; // ON/OFF aim line
    // ── Per-gun Release Fire panel ────────────────────────────────────────────
    private boolean relFireOpen    = false;
    private RectF   relFireOpenBtn = null;           // "RELEASE FIRE ▶" row in main settings
    private RectF   relFirePanel   = null;           // secondary overlay panel
    private RectF   relFireCloseBtn = null;
    private final RectF[] relFireToggleON  = new RectF[22];
    private final RectF[] relFireToggleOFF = new RectF[22];
    private static final String[] GUN_NAMES = {
        "Pistol","SMG","Shotgun","Assault","Sniper","Burst","Minigun","Revolver","LMG",
        "Plasma","Bouncer","Piercer","Seeker","Blaster","Ghost","Paint","Coin Gun","V.Chakram","Hook Spear","Air Strike",
        "Soul Reaper","Shadow Blade"};
    private static final int[] GUN_COLORS = {
        0xFF4FC3F7,0xFF81C784,0xFFFF8A65,0xFFFFB347,0xFFCE93D8,0xFF4DD0E1,
        0xFFFF5252,0xFFFFD54F,0xFF90A4AE,0xFF00E5FF,0xFF69F0AE,0xFF40C4FF,
        0xFFFF6E40,0xFFFFD740,0xFF26C6DA,0xFFFFD700,0xFF80D8FF,0xFFFF8F00,
        // 18=Air Strike, 19=Ghost(fixed), 20=Soul Reaper, 21=Shadow Blade
        0xFFE040FB,0xFF7B1FA2,0xFF9C27B0,0xFFFF1744};
    private RectF fireThreshEditBtn;   // tapping opens custom-value dialog
    private RectF fireThreshValRect;   // display of current value
    private RectF moveBtnsRect;        // "MOVE BUTTONS" button in settings
    private RectF mainMenuRect;        // "MAIN MENU" button in settings

    // ═══ SHOP ════════════════════════════════════════════════════════════════
    private volatile boolean shopOpen = false;
    private RectF   shopBtn, shopCloseRect;
    private final RectF[] shopBuyRects = new RectF[22];
    static final int[] GUN_PRICES = {0, 50, 60, 80, 120, 90, 150, 70, 100, 130, 110, 140, 160, 120, 85, 130, 110, 145, 170, 200, 130, 180};

    // ═══ SHOP SCROLL ═════════════════════════════════════════════════════════
    private float shopPanelH = 670f; // computed dynamically from screenH in initLayout
    private static final float SHOP_ROW_H   = 56f;  // weapon row height (was 68)
    private static final float SHOP_ROW_GAP = 2f;   // gap between rows (was 4)
    private final float[] shopTabScrollY  = {0f, 0f}; // per-tab scroll offset
    private final float[] shopTabScrollMax= {0f, 0f}; // per-tab max scroll (set in draw)
    private float  shopDragStartY  = 0f;
    private float  shopDragLastY   = 0f;
    private boolean shopIsDragging = false;

    // ═══ SKILL SHOP ══════════════════════════════════════════════════════════
    private int   shopTab = 0;   // 0 = guns, 1 = skills
    private RectF shopTabGuns, shopTabSkills;
    private RectF skillRect;                         // active-skill use button
    private final RectF[] passiveBuyRects = new RectF[4];
    private final RectF[] activeBuyRects  = new RectF[4];
    static final int[] PASSIVE_SKILL_COSTS = {40, 70, 100};   // per level
    static final int[] ACTIVE_SKILL_COSTS  = {80, 100, 80, 90}; // dash/stealth/heal/shield

    // ═══ CACHED PREFS (refreshed on settings change, avoid 60Hz disk reads) ════
    private int   cachedAimSens    = 1;        // 0=slow 1=norm 2=fast
    private boolean cachedAimLine  = false;
    private boolean cachedGunStats = true;
    private float cachedFireThresh = 0.40f;
    // Per-gun release-fire cache: index = gunIndex
    private final boolean[] cachedRelFire = new boolean[22];

    private void refreshCachedPrefs() {
        SharedPreferences p = getContext().getSharedPreferences(PREFS, 0);
        cachedAimSens    = p.getInt    ("aim_sens",  1);
        cachedAimLine    = p.getBoolean("aim_line",  false);
        cachedGunStats   = p.getBoolean("gun_stats", true);
        cachedFireThresh = p.getFloat  ("fire_thresh_val", 0.40f);
        for (int i = 0; i < 22; i++) cachedRelFire[i] = p.getBoolean("rel_fire_" + i, false);
    }
    // "kjm" → infinite ammo (no reload ever)
    // "khm" → zero skill cooldown (skills fire instantly, back-to-back)
    private boolean cheatInfiniteAmmo = false;
    private boolean cheatNoSkillCd    = false;
    private void detectCheats(String name) {
        if (name == null) return;
        String n = name.trim().toLowerCase();
        if (n.equals("kjm")) { cheatInfiniteAmmo = true; }
        if (n.equals("khm")) { cheatNoSkillCd    = true; }
    }
    private volatile boolean pendingPositionSync = false;  // send pos after dash
    private volatile float[] pendingBombSend     = null;   // [vx,vy,maxRange] from client bomb throw
    private volatile boolean pendingHealEvent    = false;  // FIX: notify host when Heal fires

    // ═══ DASH ANIMATION ══════════════════════════════════════════════════════
    private boolean dashAnimating  = false;
    private float   dashAnimStartX, dashAnimStartY;
    private float   dashAnimEndX,   dashAnimEndY;
    private long    dashAnimBegin;
    private static final long DASH_ANIM_MS = 160;

    // ═══ DASH AFTEREFFECTS ═══════════════════════════════════════════════════
    // Each ghost: [worldX, worldY, spawnTimeMs]
    private final List<float[]> dashGhosts      = new ArrayList<>();
    // Bot dash ghosts: [worldX, worldY, spawnTimeMs]  (drawn in orange/red)
    private final List<float[]> botDashGhosts   = new ArrayList<>();
    // Bot dash visual-only animation: botId -> [renderX, renderY, destX, destY, beginTimeMs]
    // Logical bot.x/bot.y is already at destination; this only affects rendering.
    private final Map<Integer, float[]> botDashVisual = new ConcurrentHashMap<>();
    private static final long   GHOST_LIFE_MS   = 420;
    private long                lastGhostTimeMs = 0;

    // ═══ DIFFICULTY (0=Easy 1=Normal 2=Hard) ══════════════════════════════
    private int difficulty = 1;

    // ═══ AI VELOCITY TRACKING (predictive aiming) ═════════════════════════
    private float lpVelX = 0f, lpVelY = 0f;
    private float lpPrevX = -1f, lpPrevY = -1f;

    // ═══ BUTTON DRAG ══════════════════════════════════════════════════════════
    private boolean btnMoveMode  = false; // drag-to-reposition mode
    private int     draggingBtn  = -1;    // 0=switch, 1=reload, -1=none
    private float   dragOffX, dragOffY;
    private RectF   confirmMoveRect;      // ✓ button to exit move mode
    // Per-button size slider (shown in btnMoveMode after tapping a button)
    private int     btnSizingId    = -1;  // which btn is being resized: 0=wheel,1=reload,5=skill
    private float   sizeSliderVal  = 0f;  // 0..1 → scale 0.4x..2.2x
    private RectF   sizeSliderTrack;      // drawn at bottom of screen
    private float   tapStartX, tapStartY; // for tap vs drag detection
    private boolean tapMoved       = false;

    // ═══ WEAPON WHEEL ═════════════════════════════════════════════════════════
    private boolean wheelOpen     = false;
    private float   wheelCX, wheelCY, wheelRadius;
    private int     wheelPid      = -1;   // pointer that opened the wheel
    private int     wheelHovered  = -1;   // currently highlighted slot index
    /** Slot array: each entry is a gun index (0-16), or -1 = bomb slot.
     *  Rebuilt every time the wheel opens. */
    private int[]   wheelSlots;

    // ═══ CAMERA ZOOM ══════════════════════════════════════════════════════════
    private float currentZoom = 0.85f;   // smoothly interpolated per-gun zoom (0.85 = 15% zoomed out)
    private Paint settingsBgP, settingsLabelP, optBtnP, optBtnSelP, optTxtP, settingsTitleP, closeBtnP;

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    private volatile boolean  gameRunning;
    private Thread            gameThread;
    /** Latest serialized state string; the sender thread drains this so the game loop never blocks on UDP. */
    private volatile String   broadcastSnapshot = null;
    private          Thread   senderThread;
    private float             screenW, screenH, camX, camY;
    private float             camPanX, camPanY;   // aim-pan offset (smoothly lerped)
    private int               tick;
    private long              deathTime;

    private Paint bgP,gridP,wallP,bdrP,remP,locP,shP,hpBgP,
                  bulletP,nameP,hudP,hudBgP,btnP,btnTxtP,
                  deathBgP,deathTxtP,gunTxtP,ipPaint;

    private final List<String> feed = new ArrayList<>();

    // ═══ CTOR ═════════════════════════════════════════════════════════════════

    /** Single-player constructor — no networking, with bot enemies. */
    public GameView(Context ctx, String name, int botCount, int difficulty) {
        super(ctx);
        savedName    = name;
        isHost       = true;
        singlePlayer = true;
        net          = null;
        this.difficulty = difficulty;
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();
        spawnLocal(0, name);
        // Spawn bots — IDs 10, 11, 12 … well away from real player IDs
        for (int i = 0; i < botCount; i++) {
            int botId = 10 + i;
            Player bot = new Player();
            bot.id = botId; bot.name = "Bot " + (i + 1); bot.guns = Gun.createAll();
            float[] sp = SPAWNS[botId % SPAWNS.length];
            bot.x = sp[0]; bot.y = sp[1]; bot.hp = 100; bot.alive = true;

            // Give each bot a DIFFERENT starting gun so they're varied
            // 0=Pistol 1=SMG 2=Shotgun 3=Assault 4=Sniper 5=Burst 6=Minigun
            int[] startGuns = {3, 1, 2, 5, 4, 0, 6}; // assault, smg, shotgun, burst, sniper, pistol, minigun
            int startGun = startGuns[i % startGuns.length];
            bot.gunIndex = startGun;
            bot.unlockedGuns[startGun] = true;

            // Give each bot a starting active skill — they'll never earn
            // enough coins fast enough otherwise, so they never use skills
            int[] startSkills = {Player.ACTIVE_HEAL, Player.ACTIVE_DASH,
                                 Player.ACTIVE_SHIELD, Player.ACTIVE_STEALTH};
            bot.activeSkillType = startSkills[i % startSkills.length];

            // Starting coins so Normal bots can buy upgrades after a few kills
            if (difficulty == 1) bot.coins = 40;
            if (difficulty == 2) bot.coins = 200;
            remote.put(botId, bot);
            botIds.add(botId);
        }
    }

    /** Training / practice constructor — no bots, no network. */
    public GameView(Context ctx, String name, boolean trainingMode) {
        super(ctx);
        savedName        = name;
        isHost           = true;
        singlePlayer     = true;
        this.trainingMode = trainingMode;
        net              = null;
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();
        spawnLocal(0, name);
        // In training mode, start near the dummy area (center of map)
        if (localPlayer != null) { localPlayer.x = 1800f; localPlayer.y = 2200f; }
        // Start with one dummy so the range feels populated
        spawnDummy();
    }

    /** Multiplayer constructor — host or client. */
    public GameView(Context ctx, String name, boolean host, String hostIp) {
        super(ctx);
        savedName    = name;
        isHost       = host;
        singlePlayer = false;
        net          = new NetworkManager(this);
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();

        if (host) hostIpDisplay = detectLocalIp();

        try {
            if (host) { net.startHost(name); spawnLocal(0, name); }
            else        net.joinGame(hostIp, name);
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ═══ PAINTS ═══════════════════════════════════════════════════════════════
    private void initPaints() {
        bgP     = fill(Color.rgb(12,25,18));
        gridP   = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridP.setColor(Color.argb(22,255,255,255));
        gridP.setStyle(Paint.Style.STROKE); gridP.setStrokeWidth(1f);
        wallP   = fill(Color.rgb(68,72,112));
        bdrP    = new Paint(Paint.ANTI_ALIAS_FLAG);
        bdrP.setColor(Color.rgb(100,108,170)); bdrP.setStyle(Paint.Style.STROKE); bdrP.setStrokeWidth(6f);
        remP    = fill(Color.rgb(240,88,88));
        locP    = fill(Color.rgb(80,190,255));
        shP     = fill(Color.argb(65,0,0,0));
        hpBgP   = fill(Color.rgb(38,38,38));
        bulletP = fill(Color.rgb(255,218,0));
        nameP   = fill(Color.WHITE); nameP.setTextSize(21f); nameP.setTextAlign(Paint.Align.CENTER);
        nameP.setShadowLayer(3f,1f,1f,Color.BLACK);
        hudP    = fill(Color.WHITE); hudP.setTextSize(28f);
        hudBgP  = fill(Color.argb(145,0,0,0));
        btnP    = fill(Color.argb(205,195,55,85));
        btnTxtP = fill(Color.WHITE); btnTxtP.setTextSize(22f);
        btnTxtP.setTextAlign(Paint.Align.CENTER); btnTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        deathBgP  = fill(Color.argb(165,0,0,0));
        deathTxtP = fill(Color.rgb(255,55,55)); deathTxtP.setTextSize(58f);
        deathTxtP.setTextAlign(Paint.Align.CENTER);
        gunTxtP = fill(Color.WHITE); gunTxtP.setTextSize(25f); gunTxtP.setTextAlign(Paint.Align.CENTER);
        // IP display paint – large, high contrast
        ipPaint = fill(Color.rgb(255,230,80)); ipPaint.setTextSize(28f);
        ipPaint.setTextAlign(Paint.Align.CENTER); ipPaint.setTypeface(Typeface.DEFAULT_BOLD);
        ipPaint.setShadowLayer(4f,0,2f,Color.BLACK);
        // Settings overlay paints
        settingsBgP   = fill(Color.argb(235,10,15,30));
        settingsTitleP= fill(Color.WHITE); settingsTitleP.setTextSize(26f);
        settingsTitleP.setTextAlign(Paint.Align.LEFT); settingsTitleP.setTypeface(Typeface.DEFAULT_BOLD);
        settingsLabelP= fill(Color.argb(210,200,210,230)); settingsLabelP.setTextSize(20f);
        settingsLabelP.setTextAlign(Paint.Align.LEFT);
        optBtnP   = fill(Color.argb(180,40,50,80));
        optBtnSelP= fill(Color.argb(230,80,130,220));
        optTxtP   = fill(Color.WHITE); optTxtP.setTextSize(17f);
        optTxtP.setTextAlign(Paint.Align.CENTER); optTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        closeBtnP = fill(Color.argb(200,180,50,60));
    }
    private Paint fill(int c){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(c);p.setStyle(Paint.Style.FILL);return p;}

    /** Finds this device's best local IP — works for regular WiFi AND hotspot AP mode. */
    private static String detectLocalIp() {
        String best = "???.???.???.???";
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            if (ifaces == null) return best;
            while (ifaces.hasMoreElements()) {
                NetworkInterface ni = ifaces.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress addr = addrs.nextElement();
                    if (addr.isLoopbackAddress() || !(addr instanceof Inet4Address)) continue;
                    String ip = addr.getHostAddress();
                    if (ip == null || ip.isEmpty()) continue;
                    best = ip; // keep last found
                    // Hotspot default range — prefer this immediately
                    if (ip.startsWith("192.168.43.") || ip.startsWith("192.168.1.")
                            || ip.startsWith("10.")) return ip;
                }
            }
        } catch (Exception ignored) {}
        return best;
    }

    // ═══ SURFACE ══════════════════════════════════════════════════════════════
    @Override public void surfaceCreated(SurfaceHolder h)  { /* Wait for surfaceChanged which always provides real dimensions */ }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int hh) { screenW=w; screenH=hh; initControls(); resume(); }
    @Override public void surfaceDestroyed(SurfaceHolder h) { pause(); }

    private void initControls() {
        refreshCachedPrefs(); // keep cached values in sync whenever layout is rebuilt
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, 0);
        int  jsSize  = prefs.getInt    ("js_size",  1);   // 0=S 1=M 2=L
        boolean swap = prefs.getBoolean("swap",     false);
        int  btnSize = prefs.getInt    ("btn_size", 1);   // 0=S 1=M 2=L
        int  opacity = prefs.getInt    ("opacity",  1);   // 0=lo 1=med 2=hi

        // Joysticks – use saved base positions if available
        float[] muls = {0.10f, 0.145f, 0.19f};
        float r = Math.min(screenW, screenH) * muls[Math.max(0, Math.min(2, jsSize))];
        float m = r + 18f;
        float lx = swap ? screenW - m : m;
        float rx = swap ? m           : screenW - m;
        float defLy = screenH - m;
        moveStick = new Joystick(
            clamp(prefs.getFloat("js_lx", lx),  r, screenW - r),
            clamp(prefs.getFloat("js_ly", defLy), r, screenH - r), r);
        aimStick  = new Joystick(
            clamp(prefs.getFloat("js_rx", rx),  r, screenW - r),
            clamp(prefs.getFloat("js_ry", defLy), r, screenH - r), r);
        int[] alphas = {90, 160, 225};
        int alpha = alphas[Math.max(0, Math.min(2, opacity))];
        moveStick.setAlpha(alpha);
        aimStick .setAlpha(alpha);

        // Action buttons with saved position + size
        float[] bws = {120f, 160f, 210f};
        float[] bhs = { 46f,  58f,  72f};
        float bw = bws[Math.max(0, Math.min(2, btnSize))];
        float bh = bhs[Math.max(0, Math.min(2, btnSize))];
        float defBx = screenW - bw - 14f;
        // Per-button scale (set via size slider in move mode). 0.4x..2.2x range.
        float switchScale = prefs.getFloat("scale_switch", 1.0f);
        float rldScale    = prefs.getFloat("scale_rld",    1.0f);
        float skillScale2 = prefs.getFloat("scale_skill",  1.0f);
        // Weapon wheel button — independently positioned, square for circle rendering
        float bx = prefs.getFloat("btn_x", defBx);
        float by = prefs.getFloat("btn_y", 14f);
        float swD = bh * switchScale;  // circle diameter scales per-button
        bx = Math.max(0, Math.min(screenW - swD, bx));
        by = Math.max(0, Math.min(screenH - swD, by));
        switchRect = new RectF(bx, by, bx+swD, by+swD);
        // Reload / bomb / drop group — independently positioned
        float rldW = bw * rldScale, rldH = bh * rldScale;
        float rldX = prefs.getFloat("rld_x", defBx);
        float rldY = prefs.getFloat("rld_y", by + swD + 8f);
        rldX = Math.max(0, Math.min(screenW - rldW, rldX));
        rldY = Math.max(0, Math.min(screenH - rldH, rldY));
        reloadRect = new RectF(rldX, rldY, rldX+rldW, rldY+rldH);
        // Bomb — independently positioned
        float bombX = prefs.getFloat("bomb_x", defBx);
        float bombY = prefs.getFloat("bomb_y", by + swD + rldH + 16f);
        bombX = Math.max(0, Math.min(screenW - rldW, bombX));
        bombY = Math.max(0, Math.min(screenH - rldH, bombY));
        bombRect = new RectF(bombX, bombY, bombX+rldW, bombY+rldH);
        // Drop — independently positioned
        float dropX = prefs.getFloat("drop_x", defBx);
        float dropY = prefs.getFloat("drop_y", by + swD + rldH*2 + 24f);
        dropX = Math.max(0, Math.min(screenW - rldW, dropX));
        dropY = Math.max(0, Math.min(screenH - rldH, dropY));
        dropRect = new RectF(dropX, dropY, dropX+rldW, dropY+rldH);

        // Skill button — circle, independently movable
        float skillDBase = bw * 0.88f;
        float skillD = skillDBase * skillScale2;
        float defSklX = prefs.getFloat("skill_x", bx + (swD - skillD) / 2f);
        float defSklY = prefs.getFloat("skill_y", by + swD * 4 + 32f);
        defSklX = Math.max(0, Math.min(screenW - skillD, defSklX));
        defSklY = Math.max(0, Math.min(screenH - skillD, defSklY));
        skillRect = new RectF(defSklX, defSklY, defSklX + skillD, defSklY + skillD);

        // Size slider track (shown when a button is tapped in move mode)
        float slW = Math.min(screenW * 0.65f, 420f);
        sizeSliderTrack = new RectF(screenW/2f - slW/2f, screenH - 210f, screenW/2f + slW/2f, screenH - 178f);

        // Gear button
        gearRect = new RectF(12, screenH-72, 72, screenH-12);
        wheelRadius = Math.min(screenW, screenH) * 0.20f;

        // Confirm-move button (shown only in btnMoveMode)
        confirmMoveRect = new RectF(screenW/2-70, screenH-90, screenW/2+70, screenH-30);

        // Settings panel — 8 option rows + MOVE BUTTONS
        float pw = Math.min(520f, screenW - 48f);
        float ph = 730f;
        float px = (screenW - pw) / 2f;
        float py = (screenH - ph) / 2f;
        settingsPanel     = new RectF(px, py, px+pw, py+ph);
        closeSettingsRect = new RectF(px+pw-54, py+8, px+pw-8, py+52);

        float optX = px + pw * 0.47f;
        float obw=72f, obh=40f, og=7f;
        // 8 rows, 62px apart
        float[] rowY = {py+66f, py+128f, py+190f, py+252f, py+314f, py+376f, py+438f, py+500f};
        for(int i=0;i<3;i++) jsSizeOpts[i]  = new RectF(optX+i*(obw+og), rowY[0], optX+i*(obw+og)+obw, rowY[0]+obh);
        for(int i=0;i<2;i++) swapOpts[i]    = new RectF(optX+i*(obw+og), rowY[1], optX+i*(obw+og)+obw, rowY[1]+obh);
        for(int i=0;i<3;i++) btnSizeOpts[i] = new RectF(optX+i*(obw+og), rowY[2], optX+i*(obw+og)+obw, rowY[2]+obh);
        for(int i=0;i<3;i++) aimSensOpts[i] = new RectF(optX+i*(obw+og), rowY[3], optX+i*(obw+og)+obw, rowY[3]+obh);
        for(int i=0;i<3;i++) opacityOpts[i] = new RectF(optX+i*(obw+og), rowY[4], optX+i*(obw+og)+obw, rowY[4]+obh);
        for(int i=0;i<2;i++) gunStatOpts[i] = new RectF(optX+i*(obw+og), rowY[5], optX+i*(obw+og)+obw, rowY[5]+obh);
        for(int i=0;i<2;i++) aimLineOpts[i] = new RectF(optX+i*(obw+og), rowY[6], optX+i*(obw+og)+obw, rowY[6]+obh);
        // Row 7: "RELEASE FIRE ▶" button (opens per-gun overlay)
        relFireOpenBtn = new RectF(optX, rowY[7], optX + obw*2 + og, rowY[7] + obh);
        // Fire threshold: value display + EDIT button
        float ftY = py + 562f;
        float ftEditW = 80f;
        float ftValW  = 90f;
        fireThreshValRect  = new RectF(optX,            ftY, optX+ftValW,          ftY+obh);
        fireThreshEditBtn  = new RectF(optX+ftValW+8f,  ftY, optX+ftValW+8f+ftEditW, ftY+obh);
        float mbY = py + 622f;
        moveBtnsRect = new RectF(px+20, mbY, px+pw-20, mbY+42f);
        float mmY = mbY + 50f;
        mainMenuRect = new RectF(px+20, mmY, px+pw-20, mmY+42f);

        // Per-gun Release Fire secondary panel (two-column grid, 10+10)
        float rfpW = Math.min(520f, screenW - 48f);
        float rfRowH = 38f, rfRowGap = 5f;
        int rfRows = 10;
        float rfpH = 62f + rfRows * (rfRowH + rfRowGap) + 12f;
        float rfpX = (screenW - rfpW) / 2f;
        float rfpY = (screenH - rfpH) / 2f;
        relFirePanel    = new RectF(rfpX, rfpY, rfpX + rfpW, rfpY + rfpH);
        relFireCloseBtn = new RectF(rfpX + rfpW - 54, rfpY + 8, rfpX + rfpW - 8, rfpY + 52);
        float rfColW = rfpW / 2f - 12f;
        float rfTogW = 46f, rfTogGap = 6f;
        float rfContentY = rfpY + 62f;
        for (int i = 0; i < GUN_NAMES.length; i++) {
            int col = i / rfRows, row = i % rfRows;
            float rfRx = rfpX + 10f + col * (rfColW + 12f);
            float rfRy = rfContentY + row * (rfRowH + rfRowGap);
            float tx = rfRx + rfColW - rfTogW*2 - rfTogGap;
            relFireToggleON[i]  = new RectF(tx,               rfRy + 3, tx + rfTogW,            rfRy + rfRowH - 3);
            relFireToggleOFF[i] = new RectF(tx + rfTogW + rfTogGap, rfRy + 3, tx + rfTogW*2 + rfTogGap, rfRy + rfRowH - 3);
        }
        float defSbx = 82f, defSby = screenH - 72f;
        float sbx = prefs.getFloat("shop_x", defSbx);
        float sby = prefs.getFloat("shop_y", defSby);
        sbx = Math.max(0, Math.min(screenW - 70f, sbx));
        sby = Math.max(0, Math.min(screenH - 60f, sby));
        shopBtn = new RectF(sbx, sby, sbx + 70f, sby + 60f);

        // Shop panel rects  ── shopPanelH field is shared with drawShop() ──
        float spw = Math.min(580f, screenW - 40f);
        shopPanelH = Math.min(screenH - 40f, screenH * 0.94f); // nearly full screen height
        float sph = shopPanelH;
        float spx = (screenW - spw) / 2f;
        float spy = (screenH - sph) / 2f;
        shopCloseRect = new RectF(spx+spw-54, spy+8, spx+spw-8, spy+52);

        // Shop tab buttons
        float tabW = (spw - 24f) / 2f;
        shopTabGuns   = new RectF(spx+12,       spy+58, spx+12+tabW,  spy+98);
        shopTabSkills = new RectF(spx+14+tabW,  spy+58, spx+spw-12,   spy+98);

        // Gun buy rects (shifted down for tab bar) — smaller rows for less scrolling
        float buyW = 90f, buyH = 36f, firstRowY = spy + 110f;
        for (int i = 0; i < 22; i++) {
            float ry = firstRowY + i*(SHOP_ROW_H + SHOP_ROW_GAP);
            shopBuyRects[i] = new RectF(spx+spw-buyW-16, ry+10, spx+spw-16, ry+10+buyH);
        }

        // Passive skill buy rects
        float skillBuyW = 86f, skillBuyH = 34f;
        float passiveRowY = spy + 132f, skillRowH = 54f, skillRowGap = 4f;
        for (int i = 0; i < 4; i++) {
            float ry = passiveRowY + i*(skillRowH + skillRowGap);
            passiveBuyRects[i] = new RectF(spx+spw-skillBuyW-16, ry+10, spx+spw-16, ry+10+skillBuyH);
        }
        // Active skill buy rects
        float activeRowY = spy + 392f;
        for (int i = 0; i < 4; i++) {
            float ry = activeRowY + i*(skillRowH + skillRowGap);
            activeBuyRects[i] = new RectF(spx+spw-skillBuyW-16, ry+10, spx+spw-16, ry+10+skillBuyH);
        }

        // Training mode panel — three buttons, each independently repositionable
        if (trainingMode) {
            float tbW = 140f, tbH = 46f, tbGap = 8f;
            float defTbX = screenW - tbW - 12f;
            float taDx = prefs.getFloat("train_add_x", defTbX);
            float taDy = prefs.getFloat("train_add_y", 70f);
            taDx = Math.max(0, Math.min(screenW - tbW, taDx));
            taDy = Math.max(0, Math.min(screenH - tbH, taDy));
            trainAddDummyBtn = new RectF(taDx, taDy, taDx+tbW, taDy+tbH);
            float trDx = prefs.getFloat("train_rem_x", defTbX);
            float trDy = prefs.getFloat("train_rem_y", 70f + tbH + tbGap);
            trDx = Math.max(0, Math.min(screenW - tbW, trDx));
            trDy = Math.max(0, Math.min(screenH - tbH, trDy));
            trainRemDummyBtn = new RectF(trDx, trDy, trDx+tbW, trDy+tbH);
            float tmDx = prefs.getFloat("train_money_x", defTbX);
            float tmDy = prefs.getFloat("train_money_y", 70f + 2*(tbH + tbGap));
            tmDx = Math.max(0, Math.min(screenW - tbW, tmDx));
            tmDy = Math.max(0, Math.min(screenH - tbH, tmDy));
            trainAddMoneyBtn = new RectF(tmDx, tmDy, tmDx+tbW, tmDy+tbH);
        }
    }

    // ═══ TOUCH ════════════════════════════════════════════════════════════════
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act=e.getActionMasked(), idx=e.getActionIndex(), pid=e.getPointerId(idx);
        float x=e.getX(idx), y=e.getY(idx);

        // Per-gun Release Fire panel — checked FIRST (settingsOpen is still true behind it)
        if (relFireOpen) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                if (relFireCloseBtn != null && relFireCloseBtn.contains(x, y)) {
                    relFireOpen = false; return true;
                }
                handleRelFireTap(x, y);
            }
            return true;
        }

        // Settings overlay absorbs all input when open
        if (settingsOpen) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                if (closeSettingsRect != null && closeSettingsRect.contains(x, y)) {
                    settingsOpen = false; return true;
                }
                handleSettingsTap(x, y);
            }
            return true;
        }

        // Shop overlay absorbs all input when open
        if (shopOpen) {
            switch (act) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    shopDragStartY = y;
                    shopDragLastY  = y;
                    shopIsDragging = false;
                    break;
                case MotionEvent.ACTION_MOVE: {
                    float scrollDelta = shopDragLastY - y;
                    shopDragLastY = y;
                    if (!shopIsDragging && Math.abs(y - shopDragStartY) > 12f) {
                        shopIsDragging = true;
                    }
                    if (shopIsDragging) {
                        shopTabScrollY[shopTab] = Math.max(0f,
                            Math.min(shopTabScrollMax[shopTab],
                                shopTabScrollY[shopTab] + scrollDelta));
                    }
                    break;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                    if (!shopIsDragging) {
                        if (shopCloseRect != null && shopCloseRect.contains(x, y)) {
                            shopOpen = false;
                        } else {
                            handleShopTap(x, y);
                        }
                    }
                    shopIsDragging = false;
                    break;
            }
            return true;
        }

        // Button-move mode: drag switch/reload buttons AND joysticks, tap ✓ to save
        if (btnMoveMode) {
            switch(act) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    tapStartX = x; tapStartY = y; tapMoved = false;
                    // Size slider drag — only when a button is selected for sizing
                    if (btnSizingId != -1 && sizeSliderTrack != null) {
                        RectF sliderHit = new RectF(sizeSliderTrack.left - 20, sizeSliderTrack.top - 30,
                                sizeSliderTrack.right + 20, sizeSliderTrack.bottom + 30);
                        if (sliderHit.contains(x, y)) { draggingBtn = 99; break; }
                    }
                    if (confirmMoveRect != null && confirmMoveRect.contains(x, y)) {
                        // Save positions + per-button scales and exit move mode
                        SharedPreferences.Editor ed = getContext().getSharedPreferences(PREFS, 0).edit();
                        if (switchRect != null) {
                            ed.putFloat("btn_x", switchRect.left); ed.putFloat("btn_y", switchRect.top);
                            SharedPreferences pr2 = getContext().getSharedPreferences(PREFS, 0);
                            float baseH = new float[]{46f,58f,72f}[Math.max(0,Math.min(2,pr2.getInt("btn_size",1)))];
                            ed.putFloat("scale_switch", switchRect.width() / baseH);
                        }
                        if (reloadRect != null) {
                            ed.putFloat("rld_x", reloadRect.left); ed.putFloat("rld_y", reloadRect.top);
                            SharedPreferences pr2 = getContext().getSharedPreferences(PREFS, 0);
                            float[] bws2 = {120f,160f,210f};
                            float baseW = bws2[Math.max(0,Math.min(2,pr2.getInt("btn_size",1)))];
                            ed.putFloat("scale_rld", reloadRect.width() / baseW);
                        }
                        if (skillRect  != null) {
                            ed.putFloat("skill_x", skillRect.left); ed.putFloat("skill_y", skillRect.top);
                            SharedPreferences pr2 = getContext().getSharedPreferences(PREFS, 0);
                            float[] bws3 = {120f,160f,210f};
                            float baseW = bws3[Math.max(0,Math.min(2,pr2.getInt("btn_size",1)))];
                            float baseSkillD = baseW * 0.88f;
                            ed.putFloat("scale_skill", skillRect.width() / baseSkillD);
                        }
                        if (moveStick != null) { ed.putFloat("js_lx", moveStick.getBaseX()); ed.putFloat("js_ly", moveStick.getBaseY()); }
                        if (aimStick  != null) { ed.putFloat("js_rx", aimStick.getBaseX());  ed.putFloat("js_ry", aimStick.getBaseY());  }
                        if (shopBtn   != null) { ed.putFloat("shop_x", shopBtn.left);        ed.putFloat("shop_y", shopBtn.top);          }
                        if (bombRect  != null) { ed.putFloat("bomb_x", bombRect.left);       ed.putFloat("bomb_y", bombRect.top);         }
                        if (dropRect  != null) { ed.putFloat("drop_x", dropRect.left);       ed.putFloat("drop_y", dropRect.top);         }
                        if (trainingMode) {
                            if (trainAddDummyBtn != null) { ed.putFloat("train_add_x",   trainAddDummyBtn.left); ed.putFloat("train_add_y",   trainAddDummyBtn.top); }
                            if (trainRemDummyBtn != null) { ed.putFloat("train_rem_x",   trainRemDummyBtn.left); ed.putFloat("train_rem_y",   trainRemDummyBtn.top); }
                            if (trainAddMoneyBtn != null) { ed.putFloat("train_money_x", trainAddMoneyBtn.left); ed.putFloat("train_money_y", trainAddMoneyBtn.top); }
                        }
                        ed.apply();
                        btnMoveMode = false; btnSizingId = -1; draggingBtn = -1; break;
                    }
                    if (switchRect != null && switchRect.contains(x, y)) {
                        draggingBtn=0; dragOffX=x-switchRect.left; dragOffY=y-switchRect.top;
                    } else if (reloadRect != null && reloadRect.contains(x, y)) {
                        draggingBtn=1; dragOffX=x-reloadRect.left; dragOffY=y-reloadRect.top;
                    } else if (bombRect != null && bombRect.contains(x, y)) {
                        draggingBtn=6; dragOffX=x-bombRect.left; dragOffY=y-bombRect.top;
                    } else if (dropRect != null && dropRect.contains(x, y)) {
                        draggingBtn=7; dragOffX=x-dropRect.left; dragOffY=y-dropRect.top;
                    } else if (moveStick != null) {
                        float dx=x-moveStick.getBaseX(), dy=y-moveStick.getBaseY();
                        float rr=moveStick.getRadius()*2f;
                        if(dx*dx+dy*dy<=rr*rr){ draggingBtn=2; dragOffX=dx; dragOffY=dy; }
                    }
                    if (draggingBtn==-1 && aimStick != null) {
                        float dx=x-aimStick.getBaseX(), dy=y-aimStick.getBaseY();
                        float rr=aimStick.getRadius()*2f;
                        if(dx*dx+dy*dy<=rr*rr){ draggingBtn=3; dragOffX=dx; dragOffY=dy; }
                    }
                    if (draggingBtn==-1 && shopBtn != null && shopBtn.contains(x, y)) {
                        draggingBtn=4; dragOffX=x-shopBtn.left; dragOffY=y-shopBtn.top;
                    }
                    if (draggingBtn==-1 && skillRect != null) {
                        float _sdx=x-skillRect.centerX(), _sdy=y-skillRect.centerY();
                        float _sr=skillRect.width()/2f*1.4f;
                        if(_sdx*_sdx+_sdy*_sdy<=_sr*_sr){
                            draggingBtn=5; dragOffX=x-skillRect.left; dragOffY=y-skillRect.top;
                        }
                    }
                    if (draggingBtn==-1 && trainingMode) {
                        if (trainAddDummyBtn != null && trainAddDummyBtn.contains(x, y)) {
                            draggingBtn=10; dragOffX=x-trainAddDummyBtn.left; dragOffY=y-trainAddDummyBtn.top;
                        } else if (trainRemDummyBtn != null && trainRemDummyBtn.contains(x, y)) {
                            draggingBtn=11; dragOffX=x-trainRemDummyBtn.left; dragOffY=y-trainRemDummyBtn.top;
                        } else if (trainAddMoneyBtn != null && trainAddMoneyBtn.contains(x, y)) {
                            draggingBtn=12; dragOffX=x-trainAddMoneyBtn.left; dragOffY=y-trainAddMoneyBtn.top;
                        }
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    float mdx = x - tapStartX, mdy = y - tapStartY;
                    if (mdx*mdx + mdy*mdy > 144f) tapMoved = true; // 12px threshold
                    if (draggingBtn == 99 && sizeSliderTrack != null) {
                        // Dragging the size slider knob
                        float knobX = Math.max(sizeSliderTrack.left, Math.min(sizeSliderTrack.right, x));
                        sizeSliderVal = (knobX - sizeSliderTrack.left) / sizeSliderTrack.width();
                        float scale = 0.4f + sizeSliderVal * 1.8f; // 0.4x .. 2.2x
                        applyBtnSizeScale(btnSizingId, scale);
                    } else if (draggingBtn == 0) {
                        if (switchRect != null) {
                            float bw2 = switchRect.width(), bh2 = switchRect.height();
                            float nx = Math.max(0, Math.min(screenW - bw2, x - dragOffX));
                            float ny = Math.max(0, Math.min(screenH - bh2, y - dragOffY));
                            switchRect.offsetTo(nx, ny);
                        }
                    } else if (draggingBtn == 1) {
                        if (reloadRect != null) {
                            float bw2 = reloadRect.width(), bh2 = reloadRect.height();
                            float nx = Math.max(0, Math.min(screenW - bw2,      x - dragOffX));
                            float ny = Math.max(0, Math.min(screenH - bh2*3-24, y - dragOffY));
                            reloadRect.offsetTo(nx, ny);
                            if (bombRect != null) bombRect.offsetTo(nx, ny + bh2 + 8f);
                            if (dropRect != null) dropRect.offsetTo(nx, ny + bh2*2 + 16f);
                        }
                    } else if (draggingBtn == 2 && moveStick != null) {
                        float r2=moveStick.getRadius();
                        moveStick.updateBase(clamp(x-dragOffX,r2,screenW-r2), clamp(y-dragOffY,r2,screenH-r2));
                    } else if (draggingBtn == 3 && aimStick != null) {
                        float r2=aimStick.getRadius();
                        aimStick.updateBase(clamp(x-dragOffX,r2,screenW-r2), clamp(y-dragOffY,r2,screenH-r2));
                    } else if (draggingBtn == 4 && shopBtn != null) {
                        float sw=shopBtn.width(), sh=shopBtn.height();
                        float nx=Math.max(0,Math.min(screenW-sw, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-sh, y-dragOffY));
                        shopBtn.offsetTo(nx, ny);
                    } else if (draggingBtn == 5 && skillRect != null) {
                        float sd = skillRect.width();
                        float nx = Math.max(0, Math.min(screenW - sd, x - dragOffX));
                        float ny = Math.max(0, Math.min(screenH - sd, y - dragOffY));
                        skillRect.offsetTo(nx, ny);
                    } else if (draggingBtn == 6 && bombRect != null) {
                        float bw2=bombRect.width(), bh2=bombRect.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        bombRect.offsetTo(nx, ny);
                    } else if (draggingBtn == 7 && dropRect != null) {
                        float bw2=dropRect.width(), bh2=dropRect.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        dropRect.offsetTo(nx, ny);
                    } else if (draggingBtn == 10 && trainAddDummyBtn != null) {
                        float bw2=trainAddDummyBtn.width(), bh2=trainAddDummyBtn.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        trainAddDummyBtn.offsetTo(nx, ny);
                    } else if (draggingBtn == 11 && trainRemDummyBtn != null) {
                        float bw2=trainRemDummyBtn.width(), bh2=trainRemDummyBtn.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        trainRemDummyBtn.offsetTo(nx, ny);
                    } else if (draggingBtn == 12 && trainAddMoneyBtn != null) {
                        float bw2=trainAddMoneyBtn.width(), bh2=trainAddMoneyBtn.height();
                        float nx=Math.max(0,Math.min(screenW-bw2, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-bh2, y-dragOffY));
                        trainAddMoneyBtn.offsetTo(nx, ny);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                    // Tap (no drag) on a button → enter per-button size slider mode
                    if (!tapMoved && draggingBtn >= 0 && draggingBtn != 99) {
                        int tappedId = draggingBtn; // 0=wheel, 1=reload, 5=skill
                        if (tappedId == 0 || tappedId == 1 || tappedId == 5) {
                            btnSizingId = tappedId;
                            // Init slider position from current button scale
                            float curScale = 1.0f;
                            SharedPreferences pr = getContext().getSharedPreferences(PREFS, 0);
                            if (tappedId == 0) curScale = pr.getFloat("scale_switch", 1.0f);
                            else if (tappedId == 1) curScale = pr.getFloat("scale_rld", 1.0f);
                            else curScale = pr.getFloat("scale_skill", 1.0f);
                            sizeSliderVal = Math.max(0f, Math.min(1f, (curScale - 0.4f) / 1.8f));
                        }
                    }
                    draggingBtn = -1; break;
            }
            return true;
        }

        switch(act){
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if(gearRect!=null&&gearRect.contains(x,y)){settingsOpen=true;break;}
                if(shopBtn!=null&&shopBtn.contains(x,y)){shopOpen=true;shopTabScrollY[0]=0f;shopTabScrollY[1]=0f;break;}
                // Training mode buttons
                if (trainingMode) {
                    if (trainAddDummyBtn != null && trainAddDummyBtn.contains(x, y)) { spawnDummy(); break; }
                    if (trainRemDummyBtn != null && trainRemDummyBtn.contains(x, y)) { removeLastDummy(); break; }
                    if (trainAddMoneyBtn != null && trainAddMoneyBtn.contains(x, y)) {
                        Player lp2 = localPlayer; if (lp2 != null) lp2.coins += 200; break;
                    }
                }
                if(switchRect!=null&&switchRect.contains(x,y)){openWeaponWheel(pid,x,y);break;}
                if(reloadRect!=null&&reloadRect.contains(x,y)){
                    // Air strike gun has no reload — tap is a no-op
                    if(localPlayer==null||!localPlayer.currentGun().bulletAirStrike) reload();
                    break;
                }
                if(bombRect!=null&&bombRect.contains(x,y)){startBombThrow();break;}
                if(dropRect!=null&&dropRect.contains(x,y)){dropWeapon();break;}
                if(skillRect!=null){
                    float _sdx=x-skillRect.centerX(),_sdy=y-skillRect.centerY(),_sr=skillRect.width()/2f;
                    if(_sdx*_sdx+_sdy*_sdy<=_sr*_sr){useActiveSkill();break;}
                }
                if(!moveStick.onTouchDown(pid,x,y)) aimStick.onTouchDown(pid,x,y);
                // Air Strike: reset ring when aim stick pressed (blocked while reloading)
                { Player _lp=localPlayer; if(_lp!=null&&_lp.currentGun().bulletAirStrike&&!_lp.currentGun().reloading) { asAimAngle=_lp.angle; asAimMag=0f; } }
                break;
            case MotionEvent.ACTION_MOVE:
                for(int i=0;i<e.getPointerCount();i++){
                    int p2=e.getPointerId(i);
                    if(wheelOpen && p2==wheelPid){
                        updateWheelHover(e.getX(i), e.getY(i));
                    } else {
                        boolean msWasActive = moveStick.isActive();
                        moveStick.onTouchMove(p2,e.getX(i),e.getY(i));
                        aimStick.onTouchMove(p2,e.getX(i),e.getY(i));
                        // Air Strike: update ring aim from stick; hide ring if walking or reloading
                        Player _lp2=localPlayer;
                        if(_lp2!=null && _lp2.currentGun().bulletAirStrike) {
                            if(_lp2.currentGun().reloading) {
                                asAimAngle = Float.NaN; asAimMag = 0f; // clear ring while reloading
                            } else if(moveStick.isActive()) {
                                float _mx=moveStick.getX(), _my=moveStick.getY();
                                if(_mx*_mx+_my*_my > 0.15f*0.15f) {
                                    asAimAngle = Float.NaN; // walking → hide ring
                                }
                            } else if(aimStick.isActive()) {
                                float _ax=aimStick.getX(), _ay=aimStick.getY();
                                asAimMag=(float)Math.sqrt(_ax*_ax+_ay*_ay);
                                if(asAimMag>0.05f) asAimAngle=(float)Math.atan2(_ay,_ax);
                            }
                        }
                    }
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                if(wheelOpen && pid==wheelPid){ closeWeaponWheel(); break; }
                float savedAX = aimStick != null ? aimStick.getX() : 0f;
                float savedAY = aimStick != null ? aimStick.getY() : 0f;
                boolean aimWasActive = aimStick != null && aimStick.isActive();
                moveStick.onTouchUp(pid);
                aimStick.onTouchUp(pid);
                if (throwingBomb && aimWasActive && (aimStick == null || !aimStick.isActive())) {
                    executeThrow(savedAX, savedAY);
                }
                // Volt Chakram: release stick → launch all orbiting discs
                if (!throwingBomb && aimWasActive && !aimStick.isActive()) {
                    Player lp2 = localPlayer;
                    if (lp2 != null && lp2.alive && isVoltChakram(lp2.currentGun())) {
                        if (!isHost) pendingVoltLaunch = new float[]{savedAX, savedAY, voltCharge};
                        launchVoltChakrams(lp2, savedAX, savedAY);
                    } else if (lp2 != null && lp2.alive && isShadowBlade(lp2.currentGun())) {
                        launchShadowBlade(lp2, savedAX, savedAY);
                    } else if (lp2 != null && lp2.alive && lp2.currentGun().bulletAirStrike) {
                        // Air Strike: detonate at ring-aimed position on stick release
                        if (!Float.isNaN(asAimAngle)) {
                            Gun ag = lp2.currentGun();
                            if (ag.ammo > 0 && !ag.reloading) {
                                spawnBullets(lp2); ag.markFired();
                            }
                        }
                        asAimAngle = Float.NaN; asAimMag = 0f;
                    } else if (lp2 != null && lp2.alive) {
                        // Per-gun fire-on-release: fire on stick-up if this gun uses REL mode
                        boolean rel = getContext().getSharedPreferences(PREFS,0)
                                .getBoolean("rel_fire_" + lp2.gunIndex, false);
                        if (rel) {
                            float ft = getFireThresh();
                            if (savedAX*savedAX + savedAY*savedAY > ft*ft) {
                                lp2.angle = (float)Math.atan2(savedAY, savedAX);
                                Gun g2 = lp2.currentGun();
                                if (g2.ammo > 0 && !g2.reloading) {
                                    spawnBullets(lp2); g2.markFired();
                                }
                            }
                        }
                    }
                }
                break;
        }
        return true;
    }

    private void handleRelFireTap(float x, float y) {
        SharedPreferences.Editor ed = getContext().getSharedPreferences(PREFS, 0).edit();
        for (int i = 0; i < GUN_NAMES.length; i++) {
            if (relFireToggleON[i]  != null && relFireToggleON[i].contains(x, y))  { ed.putBoolean("rel_fire_"+i, true);  ed.apply(); refreshCachedPrefs(); return; }
            if (relFireToggleOFF[i] != null && relFireToggleOFF[i].contains(x, y)) { ed.putBoolean("rel_fire_"+i, false); ed.apply(); refreshCachedPrefs(); return; }
        }
    }

    private void handleSettingsTap(float x, float y) {
        SharedPreferences.Editor ed = getContext().getSharedPreferences(PREFS, 0).edit();
        for(int i=0;i<3;i++) if(jsSizeOpts[i]!=null&&jsSizeOpts[i].contains(x,y)){ed.putInt("js_size",i);ed.apply();initControls();return;}
        for(int i=0;i<2;i++) if(swapOpts[i]!=null&&swapOpts[i].contains(x,y)){ed.putBoolean("swap",i==1);ed.apply();initControls();return;}
        for(int i=0;i<3;i++) if(btnSizeOpts[i]!=null&&btnSizeOpts[i].contains(x,y)){ed.putInt("btn_size",i);ed.apply();initControls();return;}
        for(int i=0;i<3;i++) if(aimSensOpts[i]!=null&&aimSensOpts[i].contains(x,y)){ed.putInt("aim_sens",i);ed.apply();refreshCachedPrefs();return;}
        for(int i=0;i<3;i++) if(opacityOpts[i]!=null&&opacityOpts[i].contains(x,y)){ed.putInt("opacity",i);ed.apply();initControls();return;}
        for(int i=0;i<2;i++) if(gunStatOpts[i]!=null&&gunStatOpts[i].contains(x,y)){ed.putBoolean("gun_stats",i==0);ed.apply();refreshCachedPrefs();return;}
        for(int i=0;i<2;i++) if(aimLineOpts[i]!=null&&aimLineOpts[i].contains(x,y)){ed.putBoolean("aim_line",i==0);ed.apply();refreshCachedPrefs();return;}
        if(relFireOpenBtn!=null&&relFireOpenBtn.contains(x,y)){ed.apply();relFireOpen=true;return;}
        if(fireThreshEditBtn!=null&&fireThreshEditBtn.contains(x,y)){ showFireThreshDialog(); return; }
        if(moveBtnsRect!=null&&moveBtnsRect.contains(x,y)){settingsOpen=false;btnMoveMode=true;btnSizingId=-1;return;}
        if(mainMenuRect!=null&&mainMenuRect.contains(x,y)){
            stopGame();
            ((android.app.Activity)getContext()).finish();
            return;
        }
    }

    /** Live-resize a button RectF during the size slider drag (keeps center fixed). */
    private void applyBtnSizeScale(int btnId, float scale) {
        scale = Math.max(0.4f, Math.min(2.2f, scale));
        if (btnId == 0 && switchRect != null) {
            // Wheel circle — keep top-left anchor, resize square
            float cx = switchRect.left, cy = switchRect.top;
            SharedPreferences pr = getContext().getSharedPreferences(PREFS, 0);
            float baseH = new float[]{46f,58f,72f}[Math.max(0,Math.min(2,pr.getInt("btn_size",1)))];
            float d = baseH * scale;
            switchRect.set(cx, cy, cx + d, cy + d);
        } else if (btnId == 1 && reloadRect != null) {
            // Keep each button's own top-left anchor, just resize width+height together
            SharedPreferences pr = getContext().getSharedPreferences(PREFS, 0);
            float[] bws2={120f,160f,210f}; float[] bhs2={46f,58f,72f};
            int sz=Math.max(0,Math.min(2,pr.getInt("btn_size",1)));
            float nw = bws2[sz] * scale, nh = bhs2[sz] * scale;
            reloadRect.set(reloadRect.left, reloadRect.top, reloadRect.left+nw, reloadRect.top+nh);
            if(bombRect!=null) bombRect.set(bombRect.left, bombRect.top, bombRect.left+nw, bombRect.top+nh);
            if(dropRect!=null) dropRect.set(dropRect.left, dropRect.top, dropRect.left+nw, dropRect.top+nh);
        } else if (btnId == 5 && skillRect != null) {
            // Skill circle — keep top-left anchor
            float sx = skillRect.left, sy = skillRect.top;
            SharedPreferences pr = getContext().getSharedPreferences(PREFS, 0);
            float[] bws3={120f,160f,210f};
            float baseSkillD = bws3[Math.max(0,Math.min(2,pr.getInt("btn_size",1)))] * 0.88f;
            float d = baseSkillD * scale;
            skillRect.set(sx, sy, sx + d, sy + d);
        }
    }

    private void switchGun(){
        if(localPlayer==null||!localPlayer.alive) return;
        Player p=localPlayer;
        int next=(p.gunIndex+1)%p.guns.length;
        for(int tries=0;tries<p.guns.length;tries++){
            if(p.unlockedGuns[next]){ p.gunIndex=next; return; }
            next=(next+1)%p.guns.length;
        }
    }

    // ── Weapon Wheel ──────────────────────────────────────────────────────────
    private void openWeaponWheel(int pid, float x, float y){
        Player lp=localPlayer; if(lp==null||!lp.alive) return;
        // Build slot list: all unlocked guns + bomb slot if player has bombs
        java.util.List<Integer> slots=new java.util.ArrayList<>();
        for(int i=0;i<lp.guns.length;i++) if(lp.unlockedGuns[i]) slots.add(i);
        if(lp.bombs>0) slots.add(-1); // -1 = bomb slot
        wheelSlots=new int[slots.size()];
        for(int i=0;i<slots.size();i++) wheelSlots[i]=slots.get(i);
        // Centre the wheel on the SWITCH button
        wheelCX=switchRect!=null?switchRect.centerX():x;
        wheelCY=switchRect!=null?switchRect.centerY():y;
        wheelHovered=-1; wheelPid=pid; wheelOpen=true;
    }

    private void updateWheelHover(float tx, float ty){
        if(!wheelOpen||wheelSlots==null||wheelSlots.length==0) return;
        float dx=tx-wheelCX, dy=ty-wheelCY;
        // Only register hover when finger has moved away from centre
        if(dx*dx+dy*dy < 18*18){ wheelHovered=-1; return; }
        float angle=(float)Math.atan2(dy,dx); // -π .. π
        // Map angle to slot index (start at top = -π/2, clockwise)
        float adjusted=angle+(float)(Math.PI/2);
        if(adjusted<0) adjusted+=(float)(Math.PI*2);
        float sliceAngle=(float)(Math.PI*2)/wheelSlots.length;
        wheelHovered=(int)(adjusted/sliceAngle)%wheelSlots.length;
    }

    private void closeWeaponWheel(){
        if(!wheelOpen) return;
        Player lp=localPlayer;
        if(lp!=null&&lp.alive&&wheelHovered>=0&&wheelSlots!=null&&wheelHovered<wheelSlots.length){
            int sel=wheelSlots[wheelHovered];
            if(sel==-1){
                // Bomb slot selected → start bomb throw
                startBombThrow();
            } else {
                lp.gunIndex=sel;
                asAimAngle = Float.NaN; asAimMag = 0f;
                shadowBladeCharge = 0f; // reset blade charge if switching away
            }
        }
        wheelOpen=false; wheelPid=-1; wheelHovered=-1;
    }
    private void reload()   {if(localPlayer!=null&&localPlayer.alive) localPlayer.currentGun().startReload();}

    private void dropWeapon() {
        Player lp = localPlayer;
        if (lp == null || !lp.alive) return;
        int unlockedCount = 0;
        for (boolean u : lp.unlockedGuns) if (u) unlockedCount++;
        if (unlockedCount <= 1) return;
        lp.unlockedGuns[lp.gunIndex] = false;
        int next = (lp.gunIndex + 1) % lp.guns.length;
        for (int tries = 0; tries < lp.guns.length; tries++) {
            if (lp.unlockedGuns[next]) { lp.gunIndex = next; return; }
            next = (next + 1) % lp.guns.length;
        }
    }

    private void useActiveSkill() {
        Player lp = localPlayer;
        if (lp == null || !lp.alive) return;
        if (lp.activeSkillType == Player.ACTIVE_NONE) return;
        if (lp.skillOnCooldown()) return;
        long now = System.currentTimeMillis();
        switch (lp.activeSkillType) {
            case Player.ACTIVE_DASH:
                // Dash in the MOVE joystick direction (where you're walking)
                float dashAngle = (moveStick!=null&&moveStick.isActive())
                    ? (float)Math.atan2(moveStick.getY(),moveStick.getX()) : lp.angle;
                float dashDist = 260f;
                // Step along the dash path and stop at the last wall-free position
                float[] dashEnd = dashWithWallStop(lp.x, lp.y, dashAngle, dashDist);
                float nx = dashEnd[0], ny = dashEnd[1];
                // Animate the dash smoothly instead of snapping
                dashAnimStartX = lp.x; dashAnimStartY = lp.y;
                dashAnimEndX   = nx;   dashAnimEndY   = ny;
                dashAnimBegin  = now;  dashAnimating  = true;
                lp.skillCooldownEnd = now + 6000;
                pendingPositionSync = true;
                break;
            case Player.ACTIVE_STEALTH:
                lp.skillActiveUntil = now + 4000;
                lp.skillCooldownEnd = now + 10000;
                break;
            case Player.ACTIVE_HEAL:
                lp.hp = Math.min(100, lp.hp + 40);
                lp.skillCooldownEnd = now + 12000;
                pendingHealEvent = true; // FIX: tell host to apply hp+40 on its authoritative copy
                break;
            case Player.ACTIVE_SHIELD:
                lp.shieldHp = 60f;
                lp.skillActiveUntil = now + 6000;
                lp.skillCooldownEnd = now + 14000;
                break;
        }
    }

    /** Enter throw-aiming mode — bomb is actually thrown when aim stick is released. */
    private void startBombThrow() {
        Player lp = localPlayer;
        if (lp == null || !lp.alive || lp.bombs <= 0) return;
        // Only one active bomb allowed at a time
        for (Bomb b : activeBombs) { if (b.ownerId == lp.id && !b.isDone() && b.explodedAt < 0) return; }
        if (throwingBomb) { throwingBomb = false; return; }  // tap again to cancel
        throwingBomb = true;
    }

    /** Called when the aim stick is released while throwingBomb is true. */
    private void executeThrow(float ax, float ay) {
        throwingBomb = false;
        Player lp = localPlayer;
        if (lp == null || !lp.alive || lp.bombs <= 0) return;
        float mag = (float) Math.sqrt(ax * ax + ay * ay);
        if (mag < 0.08f) return;
        for (Bomb b : activeBombs) { if (b.ownerId == lp.id && !b.isDone() && b.explodedAt < 0) return; }
        lp.bombs--;
        float vx = ax * Bomb.THROW_SPEED;
        float vy = ay * Bomb.THROW_SPEED;
        float maxRange = mag * Bomb.THROW_RANGE;
        if (isHost) {
            // Host owns all bombs — create directly
            Bomb bomb = new Bomb(lp.x, lp.y, lp.id);
            bomb.vx = vx; bomb.vy = vy; bomb.maxRange = maxRange;
            activeBombs.add(bomb);
        } else {
            // Client: queue for next sendInput so host creates the authoritative bomb
            pendingBombSend = new float[]{vx, vy, maxRange};
        }
    }

    // ═══ LOOP ═════════════════════════════════════════════════════════════════
    public synchronized void resume(){
        if(gameRunning) return;
        gameRunning=true;
        gameThread=new Thread(this,"GameLoop"); gameThread.start();
        // Dedicated UDP sender: the game loop writes broadcastSnapshot; this thread drains it.
        // Keeps the 16ms game-loop budget free of any socket-blocking time.
        senderThread = new Thread(() -> {
            while (gameRunning) {
                String snap = broadcastSnapshot;
                if (snap != null) { broadcastSnapshot = null; net.broadcastState(snap); }
                try { Thread.sleep(1); } catch (InterruptedException e) { break; }
            }
        }, "StateSender");
        senderThread.setDaemon(true);
        senderThread.start();
    }
    public synchronized void pause(){
        gameRunning=false;
        if(senderThread!=null){ senderThread.interrupt(); senderThread=null; }
        if(gameThread!=null) try{gameThread.join(700);}catch(InterruptedException ignored){}
        gameThread=null;
    }
    public void stopGame(){ pause(); if(net!=null) net.stop(); }

    @Override public void run(){
        long prev=System.nanoTime();
        while(gameRunning){
            long now=System.nanoTime();
            float dt=Math.min((now-prev)/1e9f,0.08f); prev=now;
            update(dt); render();
            long sleep=16_666_000L-(System.nanoTime()-now);
            if(sleep>0) try{Thread.sleep(sleep/1_000_000,(int)(sleep%1_000_000));}catch(InterruptedException ig){}
        }
    }

    // ═══ UPDATE ═══════════════════════════════════════════════════════════════
    private void update(float dt){
        tick++;
        if(!isHost && pendingState!=null){ applyState(pendingState); pendingState=null; }

        // ── Client-side dead-reckoning ─────────────────────────────────────────
        // Between host state packets (~33ms apart), extrapolate remote players
        // forward at their last known velocity so they never freeze or snap.
        if (!isHost) {
            long _drNow = System.currentTimeMillis();
            for (Player rp : remote.values()) {
                if (rp.alive && rp.netUpdateMs >= 0) {
                    long _age = _drNow - rp.netUpdateMs;
                    // Extrapolate up to 120ms; beyond that the player has stopped or packet is lost
                    if (_age > 0 && _age < 120) {
                        rp.x = clamp(rp.netX + rp.netVX * _age, PR, MAP_W - PR);
                        rp.y = clamp(rp.netY + rp.netVY * _age, PR, MAP_H - PR);
                    }
                }
            }
        }

        Player lp = localPlayer;  // snapshot reference — safe
        if(lp==null) return;

        if(lp.alive) {
            float rm = lp.reloadMult();
            for(Gun g:lp.guns) g.tick(rm);
        }

        if(isHost&&!lp.alive&&System.currentTimeMillis()-deathTime>=RESPAWN_MS)
            respawn(lp);

        if(lp.alive) moveAndAim(lp, dt);

        // Smooth dash animation — override position while active
        if (dashAnimating) {
            long elapsed = System.currentTimeMillis() - dashAnimBegin;
            float t = Math.min(1f, (float)elapsed / DASH_ANIM_MS);
            // Ease-out cubic: fast start, gentle stop — feels like a real dash
            float ease = 1f - (1f - t) * (1f - t) * (1f - t);
            lp.x = dashAnimStartX + (dashAnimEndX - dashAnimStartX) * ease;
            lp.y = dashAnimStartY + (dashAnimEndY - dashAnimStartY) * ease;
            if (t >= 1f) { lp.x = dashAnimEndX; lp.y = dashAnimEndY; dashAnimating = false; }

            // ── Emit aftereffect ghost at current position ─────────────────
            long nowGhost = System.currentTimeMillis();
            if (nowGhost - lastGhostTimeMs >= 16) {   // ~60fps cap
                dashGhosts.add(new float[]{lp.x, lp.y, nowGhost});
                lastGhostTimeMs = nowGhost;
            }
        }

        // ── Bot dash visual animation — expire finished entries ────────────────
        if (!botDashVisual.isEmpty()) {
            long nowAnim = System.currentTimeMillis();
            botDashVisual.entrySet().removeIf(e -> nowAnim - (long)e.getValue()[4] >= DASH_ANIM_MS);
        }


        // Track player velocity for AI predictive aiming (px / update)
        if (lpPrevX >= 0f) {
            lpVelX = lp.x - lpPrevX;
            lpVelY = lp.y - lpPrevY;
        }
        lpPrevX = lp.x;
        lpPrevY = lp.y;

        updateBullets(lp, dt);
        updateBombs(lp, dt);
        updateAirStrikes(lp);
        updateVoltChakrams(lp, dt);
        updateHookPulls(dt);
        resolvePlayerCollisions();
        applyPoisonTicks(lp);

        if(isHost){
            applyClientInputs(dt);
            drainNetEvents(); // FIX: apply queued bomb/VC events from network thread on game thread
            if(!botIds.isEmpty()) updateBots(dt);
            // Update volt chakrams for remote players (hit detection runs on host)
            for (Player rp : remote.values()) {
                if (rp.alive && isVoltChakram(rp.currentGun())) updateVoltChakrams(rp, dt);
            }
            checkRemoteRespawns();
            if(!singlePlayer && System.currentTimeMillis()-lastBroadcast>33){ broadcast(); lastBroadcast=System.currentTimeMillis(); }
        } else {
            sendInput(lp); // send every frame (60 Hz) for minimal input lag
        }

        // Smooth per-weapon zoom  (global 0.85 scale already baked into GunConfig)
        float targetZoom = (lp.alive) ? lp.currentGun().zoom : 0.85f;
        currentZoom += (targetZoom - currentZoom) * 0.07f;

        // Aim pan — shift camera toward aim stick so the player sees further ahead.
        // Vertical pan is stronger (PAN_Y > PAN_X) but we blend by direction so
        // diagonals feel smooth rather than snapping between the two extremes.
        final float PAN_X = 200f;
        final float PAN_Y = 340f;
        float aimPanTargetX = 0f, aimPanTargetY = 0f;
        if (!throwingBomb && aimStick != null && aimStick.isActive()) {
            float _sx = aimStick.getX(), _sy = aimStick.getY();
            float _mag = (float) Math.sqrt(_sx * _sx + _sy * _sy);
            if (_mag > 0.01f) {
                // vertFrac=0 → pure horizontal (use PAN_X), vertFrac=1 → pure vertical (use PAN_Y)
                float vertFrac = Math.abs(_sy) / _mag;
                float panR = PAN_X + (PAN_Y - PAN_X) * vertFrac;
                aimPanTargetX = _sx * panR;
                aimPanTargetY = _sy * panR;
            }
        }
        camPanX += (aimPanTargetX - camPanX) * 0.09f;
        camPanY += (aimPanTargetY - camPanY) * 0.09f;

        camX = lp.x + camPanX - screenW / (2f * currentZoom);
        camY = lp.y + camPanY - screenH / (2f * currentZoom);
    }

    private void moveAndAim(Player lp, float dt){
        if(moveStick==null||aimStick==null) return;
        // Hook Spear: pull overrides movement; stun freezes player entirely
        if (lp.isBeingPulled() || lp.isStunned()) return;
        float spd = 280f * lp.moveSpeedMult() * (lp.isSlowed() ? 0.40f : 1.0f) * (lp.isStealthed() ? 1.3f : 1.0f);
        float nx=lp.x+moveStick.getX()*spd*dt;
        float ny=lp.y+moveStick.getY()*spd*dt;
        nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
        float[] pos=walls(lp.x,lp.y,nx,ny);
        lp.x=pos[0]; lp.y=pos[1];

        float ax=aimStick.getX(), ay=aimStick.getY();
        if(ax*ax+ay*ay>0.01f){
            float targetAngle=(float)Math.atan2(ay,ax);
            // Aim sensitivity: 0=slow(0.10) 1=norm(0.35) 2=fast(1.0)
            float[] sensVals = {0.10f, 0.35f, 1.0f};
            float sens = sensVals[Math.max(0,Math.min(2,cachedAimSens))];
            lp.angle = lerpAngle(lp.angle, targetAngle, sens);
        }

        Gun g=lp.currentGun();
        // ── Cheat: infinite ammo — keep every gun topped up, never reload ────
        if (cheatInfiniteAmmo) {
            for (Gun cg : lp.guns) { cg.ammo = cg.maxAmmo; cg.reloading = false; }
        }
        // ── Cheat: no skill cooldown — reset CD every frame ──────────────────
        if (cheatNoSkillCd) { lp.skillCooldownEnd = 0; }
        // Auto-reload when clip is empty
        if(g.ammo<=0 && !g.reloading && !isVoltChakram(g) && !isShadowBlade(g)) g.startReload();

        // ── Volt Chakram: spin aim stick to charge; fire handled on stick-up ─
        if (isVoltChakram(g)) {
            // Passive idle orbit spin
            voltOrbitAngle += dt * 1.4f;
            // Hold aim stick to charge — orbit ring spins faster as power builds.
            // No joystick spinning needed; fully compatible with aim panning.
            if (aimStick.isActive() && ax*ax + ay*ay > 0.04f) {
                voltCharge = Math.min(1f, voltCharge + dt * 0.38f); // full charge in ~2.6s
            } else {
                voltCharge = Math.max(0f, voltCharge - dt * 0.25f); // slow decay when idle
            }
            // Orbit ring accelerates hard with charge: 1.5 rad/s idle → 18 rad/s full
            voltOrbitAngle += dt * (1.5f + voltCharge * voltCharge * 16.5f);
            return; // skip normal bullet fire
        }
        voltPrevAimAngle = Float.NaN; // unused for hold-charge but harmless to clear

        // ── Shadow Blade: hold aim stick to charge; release dashes and slashes ─
        if (isShadowBlade(g)) {
            if (aimStick.isActive() && ax*ax + ay*ay > 0.04f) {
                shadowBladeCharge = Math.min(1f, shadowBladeCharge + dt * 0.83f); // full in ~1.2s
            } else {
                shadowBladeCharge = Math.max(0f, shadowBladeCharge - dt * 0.6f); // decay when idle
            }
            return; // fire happens on stick-up via launchShadowBlade
        }

        // Fire with passive fire-rate bonus applied
        float aimMag2 = ax*ax + ay*ay;
        float fireThreshVal = getFireThresh();
        // Per-gun release-fire: skip continuous firing; bullet spawned on stick-up instead
        boolean fireOnRelease = getContext().getSharedPreferences(PREFS,0)
                .getBoolean("rel_fire_" + lp.gunIndex, false);
        boolean isAirStrike = g.bulletAirStrike;

        // Air Strike: track aim angle/mag from stick continuously (blocked while reloading)
        if (isAirStrike && aimStick.isActive()) {
            if (g.reloading) {
                asAimAngle = Float.NaN; asAimMag = 0f; // no aiming while reloading
            } else {
            float _ax = ax, _ay = ay;
            float _mag = (float) Math.sqrt(_ax*_ax + _ay*_ay);
            // Hide ring if walking
            float mvx = moveStick.getX(), mvy = moveStick.getY();
            if (mvx*mvx + mvy*mvy > 0.15f*0.15f) {
                asAimAngle = Float.NaN; asAimMag = 0f;
            } else if (_mag > 0.05f) {
                asAimAngle = (float)Math.atan2(_ay, _ax);
                asAimMag   = Math.min(1f, _mag);
            }
            }
        }

        if(!throwingBomb && aimStick.isActive() && aimMag2 > fireThreshVal*fireThreshVal
                && !fireOnRelease && !isAirStrike){
            float frMult = lp.fireRateMult();
            long fireCooldown = (long)(1000f / (g.fireRate * frMult));
            boolean canFire = g.ammo > 0 && !g.reloading
                    && System.currentTimeMillis() - g.lastFireTime >= fireCooldown;
            if(canFire){ spawnBullets(lp); g.markFired(); }
        }
    }

    private float[] walls(float ox,float oy,float nx,float ny){
        for(float[] w:WALLS){
            float cx=clamp(nx,w[0],w[2]), cy=clamp(ny,w[1],w[3]);
            float distSq=d2(nx,ny,cx,cy);
            if(distSq<PR*PR){
                float cx2=clamp(nx,w[0],w[2]), cy2=clamp(oy,w[1],w[3]);
                boolean xBlocked=d2(nx,oy,cx2,cy2)<PR*PR;
                float cx3=clamp(ox,w[0],w[2]), cy3=clamp(ny,w[1],w[3]);
                boolean yBlocked=d2(ox,ny,cx3,cy3)<PR*PR;
                if(xBlocked) nx=ox;
                if(yBlocked) ny=oy;
                if(!xBlocked&&!yBlocked){
                    // Corner hit: neither axis alone penetrates the wall face.
                    // Push player out along the corner->player vector so the
                    // circle sits exactly at radius PR from the corner.
                    if(distSq>0f){
                        float dist=(float)Math.sqrt(distSq);
                        nx=cx+(nx-cx)/dist*PR;
                        ny=cy+(ny-cy)/dist*PR;
                    } else {
                        nx=ox; ny=oy; // fully inside wall — full revert
                    }
                }
            }
        }
        return new float[]{nx,ny};
    }

    /** Shortest-path angle lerp accounting for ±π wrap. */
    private float lerpAngle(float from, float to, float t){
        float d=to-from;
        while(d>(float)Math.PI) d-=(float)(Math.PI*2);
        while(d<-(float)Math.PI) d+=(float)(Math.PI*2);
        return from+d*t;
    }

    private void spawnBullets(Player p){
        Gun g=p.guns[p.gunIndex];
        if(g.ammo<=0) return;

        // ── Air Strike: queue strikes at ring-aimed position ──────────────────
        if (g.bulletAirStrike) {
            if (Float.isNaN(asAimAngle)) return; // no target selected yet
            g.ammo--;
            if(p.isStealthed()) p.skillActiveUntil = 0;
            long now = System.currentTimeMillis();
            // Target world position: joystick magnitude maps 0→player, 1→ring edge
            float targetDist = asAimMag * AS_RING_R;
            float cx = p.x + (float)Math.cos(asAimAngle) * targetDist;
            float cy = p.y + (float)Math.sin(asAimAngle) * targetDist;
            cx = Math.max(0, Math.min(MAP_W, cx));
            cy = Math.max(0, Math.min(MAP_H, cy));
            // Single strike at center with warning delay
            long triggerMs = now + AS_WARNING_MS;
            airStrikes.add(new double[]{cx, cy, (double)triggerMs, (double)p.id, 0.0});
            asAimAngle = Float.NaN; asAimMag = 0f;
            return;
        }

        g.ammo--;
        // Firing breaks stealth immediately
        if(p.isStealthed()) p.skillActiveUntil = 0;
        // Coin Gun: scale damage with wealth  (20 @ 0 coins → 120 @ 600 coins)
        float coinDmg = g.coinScaling ? 20f + Math.min(p.coins, 600) * 0.167f : g.damage;
        for(int i=0;i<g.pellets;i++){
            float s=(float)(Math.random()-0.5)*g.spread*2, a=p.angle+s;
            float spd=g.bulletSpeed*(0.96f+(float)Math.random()*0.08f);
            float rangeVal = g.range * p.rangeMult();
            float dmg = g.coinScaling ? coinDmg : g.damage;
            Bullet bl = new Bullet(p.x,p.y,(float)Math.cos(a)*spd,(float)Math.sin(a)*spd,p.id,dmg,bulletId++,rangeVal);
            bl.bouncesLeft  = g.bulletBounces;
            bl.piercing     = g.bulletPiercing;
            bl.explosive    = g.bulletExplosive;
            bl.homing       = g.bulletHoming;
            bl.ghost        = g.bulletGhost;
            bl.hookSpear    = g.bulletHookSpear;
            bl.isSoulReaper = (p.gunIndex == 20);
            bl.isShadowBlade = (p.gunIndex == 21);
            // Paint color: 1=blue(slow), 2=green(poison), 3=per-shot alternating (toggle each shot)
            if(g.paintBulletColor==3) { bl.paintColor = g.paintShotToggle; }
            else bl.paintColor = g.paintBulletColor;
            bl.slowDurationMs   = g.slowMs;
            bl.poisonDurationMs = g.poisonMs;
            bl.poisonTickDamage = g.poisonDmg;
            bl.stunBonusMs      = g.stunBonusMs;
            if(bl.piercing) bl.hitIds = new HashSet<>();
            bullets.add(bl);
        }
        // Per-shot paint toggle: flip between poison(2) and slow(1) after each shot
        if(g.paintBulletColor==3) g.paintShotToggle = (g.paintShotToggle == 2) ? 1 : 2;
    }

    private void updateBombs(Player lp, float dt) {
        if (!isHost) return;
        long now = System.currentTimeMillis();
        Iterator<Bomb> it = activeBombs.iterator();
        while (it.hasNext()) {
            Bomb b = it.next();
            if (b.isDone()) { it.remove(); continue; }

            // ── Move the bomb while in flight ─────────────────────────────────
            if (!b.hasLanded) {
                float nx = b.x + b.vx * dt;
                float ny = b.y + b.vy * dt;
                boolean outOfRange = b.traveledSq() >= b.maxRange * b.maxRange;
                boolean outOfMap   = nx < 0 || nx > MAP_W || ny < 0 || ny > MAP_H;

                if (outOfRange || outOfMap) {
                    // Clamp to map and land with a roll in current travel direction
                    nx = Math.max(0, Math.min(MAP_W, nx));
                    ny = Math.max(0, Math.min(MAP_H, ny));
                    b.x = nx; b.y = ny;
                    b.rollVx = b.vx * Bomb.LAND_ROLL_FACTOR;
                    b.rollVy = b.vy * Bomb.LAND_ROLL_FACTOR;
                    b.hasLanded = true; b.vx = 0; b.vy = 0;
                } else {
                    // Axis-separated wall bounce so the reflection axis is correct
                    boolean xBlocked = false, yBlocked = false;
                    for (float[] w : WALLS) {
                        if (!xBlocked && nx >= w[0] && nx <= w[2] && b.y >= w[1] && b.y <= w[3]) xBlocked = true;
                        if (!yBlocked && b.x >= w[0] && b.x <= w[2] && ny >= w[1] && ny <= w[3]) yBlocked = true;
                    }
                    if (xBlocked) b.vx = -b.vx * Bomb.BOUNCE_RESTITUTION;
                    if (yBlocked) b.vy = -b.vy * Bomb.BOUNCE_RESTITUTION;
                    if (xBlocked || yBlocked) {
                        // Bounced off a wall — land and give roll velocity in reflected direction
                        b.rollVx = b.vx * Bomb.LAND_ROLL_FACTOR;
                        b.rollVy = b.vy * Bomb.LAND_ROLL_FACTOR;
                        b.hasLanded = true; b.vx = 0; b.vy = 0;
                    } else {
                        b.x = nx; b.y = ny;
                    }
                }
            }

            // ── Roll the bomb along the ground with friction ───────────────────
            if (b.hasLanded && (b.rollVx != 0 || b.rollVy != 0)) {
                float speed = (float) Math.sqrt(b.rollVx * b.rollVx + b.rollVy * b.rollVy);
                float decel = Bomb.ROLL_FRICTION * dt;
                if (decel >= speed) {
                    b.rollVx = 0; b.rollVy = 0;
                } else {
                    float factor = (speed - decel) / speed;
                    b.rollVx *= factor;
                    b.rollVy *= factor;
                    float rnx = b.x + b.rollVx * dt;
                    float rny = b.y + b.rollVy * dt;
                    // Axis-separated wall bounce while rolling (damped)
                    boolean rxBlocked = false, ryBlocked = false;
                    for (float[] w : WALLS) {
                        if (!rxBlocked && rnx >= w[0] && rnx <= w[2] && b.y >= w[1] && b.y <= w[3]) rxBlocked = true;
                        if (!ryBlocked && b.x >= w[0] && b.x <= w[2] && rny >= w[1] && rny <= w[3]) ryBlocked = true;
                    }
                    if (rxBlocked) b.rollVx = -b.rollVx * Bomb.BOUNCE_RESTITUTION;
                    if (ryBlocked) b.rollVy = -b.rollVy * Bomb.BOUNCE_RESTITUTION;
                    // Apply map boundary bounce
                    if (rnx < 0 || rnx > MAP_W) { b.rollVx = -b.rollVx * Bomb.BOUNCE_RESTITUTION; rnx = Math.max(0, Math.min(MAP_W, rnx)); }
                    if (rny < 0 || rny > MAP_H) { b.rollVy = -b.rollVy * Bomb.BOUNCE_RESTITUTION; rny = Math.max(0, Math.min(MAP_H, rny)); }
                    if (!rxBlocked) b.x = rnx;
                    if (!ryBlocked) b.y = rny;
                    // Kill negligible roll after bouncing
                    float newSpeed = (float) Math.sqrt(b.rollVx * b.rollVx + b.rollVy * b.rollVy);
                    if (newSpeed < Bomb.MIN_ROLL_SPEED) { b.rollVx = 0; b.rollVy = 0; }
                }
            }

            // ── Explode when fuse burns out ───────────────────────────────────
            if (b.shouldExplode()) {
                b.explodedAt = now;
                // Damage local player (no friendly fire)
                if (lp.alive && b.ownerId != lp.id
                        && d2(b.x, b.y, lp.x, lp.y) < Bomb.RADIUS * Bomb.RADIUS) {
                    if(!lp.isProtected()){
                        float dmg = Bomb.DAMAGE;
                        if(lp.isShielded()){
                            float reduced=dmg*0.5f;float abs=Math.min(reduced,lp.shieldHp); lp.shieldHp-=abs; dmg-=abs;
                            if(lp.shieldHp<=0) lp.skillActiveUntil=0;
                        }
                        lp.hp = Math.max(0, lp.hp - dmg);
                        if (lp.hp == 0) {
                            lp.alive = false; deathTime = now;
                            addFeed(nameOf(b.ownerId) + " \uD83D\uDCA3 " + lp.name);
                        }
                    }
                }
                // Damage remote players
                for (Player rp : remote.values()) {
                    if (!rp.alive || b.ownerId == rp.id) continue;
                    if (d2(b.x, b.y, rp.x, rp.y) < Bomb.RADIUS * Bomb.RADIUS) {
                        if(!rp.isProtected()){
                            float dmg = Bomb.DAMAGE;
                            if(rp.isShielded()){
                                float reduced=dmg*0.5f;float abs=Math.min(reduced,rp.shieldHp); rp.shieldHp-=abs; dmg-=abs;
                                if(rp.shieldHp<=0) rp.skillActiveUntil=0;
                            }
                            rp.hp = Math.max(0, rp.hp - dmg);
                            if (rp.hp == 0) {
                                rp.alive = false; deadAtMs.put(rp.id, now);
                                if (!dummyIds.contains(rp.id)) {
                                    addFeed(nameOf(b.ownerId) + " \uD83D\uDCA3 " + rp.name);
                                    if (b.ownerId == lp.id) {
                                        lp.coins += 25;
                                        // FIX: removed b.isSoulReaper here — Bomb has no such field (compile error)
                                        // and bomb kills should not count as Soul Reaper kills.
                                    } else {
                                        Player killer = remote.get(b.ownerId);
                                        if (killer != null) {
                                            killer.coins += 25;
                                            // FIX: removed b.isSoulReaper here — same reason
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ═══ AIR STRIKE ══════════════════════════════════════════════════════════

    private void updateAirStrikes(Player lp) {
        if (!isHost) return;
        long now = System.currentTimeMillis();
        Iterator<double[]> it = airStrikes.iterator();
        while (it.hasNext()) {
            double[] as = it.next();
            float sx = (float) as[0], sy = (float) as[1];
            long triggerMs = (long) as[2];
            int ownerId = (int) as[3];
            long flashUntil = (long) as[4];

            // Not yet triggered
            if (now < (long) triggerMs) continue;

            // Trigger: do damage once (flashUntil == 0 means not yet exploded)
            if (flashUntil == 0L) {
                as[4] = now + AS_FLASH_MS;
                // Damage local player
                if (lp != null && lp.alive && ownerId != lp.id
                        && d2(sx, sy, lp.x, lp.y) < AS_RADIUS * AS_RADIUS) {
                    if (!lp.isProtected()) {
                        float dmg = AS_DAMAGE;
                        if (lp.isShielded()) {
                            float reduced = dmg * 0.5f;
                            float abs = Math.min(reduced, lp.shieldHp);
                            lp.shieldHp -= abs; dmg -= abs;
                            if (lp.shieldHp <= 0) lp.skillActiveUntil = 0;
                        }
                        lp.hp = Math.max(0, lp.hp - dmg);
                        if (lp.hp == 0) {
                            lp.alive = false; deathTime = now;
                            addFeed(nameOf(ownerId) + " ✈ " + lp.name);
                        }
                    }
                }
                // Damage bots and remote players
                for (Player p : remote.values()) {
                    if (p.id == ownerId || !p.alive) continue;
                    if (d2(sx, sy, p.x, p.y) < AS_RADIUS * AS_RADIUS) {
                        if(!p.isProtected()){
                            float dmg = AS_DAMAGE;
                            if(p.isShielded()){
                                float reduced=dmg*0.5f;float abs=Math.min(reduced,p.shieldHp);p.shieldHp-=abs;dmg-=abs;
                                if(p.shieldHp<=0) p.skillActiveUntil=0;
                            }
                            p.hp = Math.max(0, p.hp - dmg);
                            if (p.hp == 0) {
                                p.alive = false;
                                deadAtMs.put(p.id, now); // FIX Bug1: air strike kills now trigger respawn
                                addFeed(nameOf(ownerId) + " ✈ " + p.name);
                                // FIX Bug2: award kill coins (was missing for air strikes)
                                if (!dummyIds.contains(p.id)) {
                                    Player asKiller = (lp != null && lp.id == ownerId) ? lp : remote.get(ownerId);
                                    if (asKiller != null) asKiller.coins += 25;
                                }
                            }
                        }
                    }
                }
            }

            // Remove when flash is done
            if (now > (long) as[4] && as[4] > 0f) it.remove();
        }
    }

    // ═══ VOLT CHAKRAM ══════════════════════════════════════════════════════════

    private boolean isVoltChakram(Gun g) {
        return g != null && "Volt Chakram".equals(g.name);
    }

    private boolean isShadowBlade(Gun g) {
        return g != null && "Shadow Blade".equals(g.name);
    }

    /**
     * Called on aim-stick release when Shadow Blade is equipped.
     *
     * Tap (charge < 0.25): quick single slash — fast piercing bullet, short range.
     * Charge  ≥ 0.25:      single slash with scaled damage + range.
     * Full charge (≥ 0.75): 3-fan slash + player dashes forward through enemies.
     */
    private void launchShadowBlade(Player lp, float ax, float ay) {
        Gun g = lp.currentGun();
        if (g.ammo <= 0 || g.reloading) return;
        float mag = (float) Math.sqrt(ax * ax + ay * ay);
        if (mag < 0.05f) return; // no direction

        float charge = shadowBladeCharge;
        float launchAngle = (float) Math.atan2(ay / mag, ax / mag);

        // Scale stats with charge
        float damage    = 35f  + charge * 65f;   // 35 → 100 dmg
        float range     = 260f + charge * 190f;  // 260 → 450 px
        float speed     = 1500f;

        // Break stealth
        if (lp.isStealthed()) lp.skillActiveUntil = 0;

        // ── Dash forward at full charge (≥ 0.75) ─────────────────────────────
        if (charge >= 0.75f && !dashAnimating) {
            float dashDist = 160f + charge * 100f; // 160–260 px
            float[] dashEnd = dashWithWallStop(lp.x, lp.y, launchAngle, dashDist);
            dashAnimStartX = lp.x; dashAnimStartY = lp.y;
            dashAnimEndX   = dashEnd[0]; dashAnimEndY = dashEnd[1];
            dashAnimBegin  = System.currentTimeMillis(); dashAnimating = true;
        }

        // ── Spawn slash bullets ───────────────────────────────────────────────
        int slashCount = (charge >= 0.75f) ? 3 : 1;
        float fanSpread = (charge >= 0.75f) ? 0.22f : 0f; // fan only at full charge
        float[] fanOffsets = {-fanSpread, 0f, fanSpread};

        for (int i = 0; i < slashCount; i++) {
            float a = launchAngle + fanOffsets[i];
            Bullet bl = new Bullet(lp.x, lp.y,
                    (float) Math.cos(a) * speed, (float) Math.sin(a) * speed,
                    lp.id, damage, bulletId++, range);
            bl.piercing      = true;
            bl.isShadowBlade = true;
            bl.hitIds        = new java.util.HashSet<>();
            bullets.add(bl);

            // Spawn slash trail: [startX, startY, endX, endY, spawnTimeMs, angle, fanSlot]
            float trailLen = range * 0.45f; // visual trail shorter than actual range
            slashTrails.add(new float[]{
                lp.x, lp.y,
                lp.x + (float) Math.cos(a) * trailLen,
                lp.y + (float) Math.sin(a) * trailLen,
                System.currentTimeMillis(), a, i
            });
        }

        g.ammo--;
        g.markFired();
        shadowBladeCharge = 0f;
    }

    /** Ensure exactly 3 chakrams (one per orbit slot) exist for lp; remove orbiters if gun switched away. */
    private void ensureVoltChakrams(Player lp) {
        boolean vcSelected = isVoltChakram(lp.currentGun());
        if (!vcSelected) {
            // Remove only ORBITING discs — launched/returning ones keep flying
            voltChakrams.removeIf(vc -> vc.ownerId == lp.id && vc.state == VoltChakram.ORBITING);
            return;
        }
        // Which of the 3 orbit slots already have a disc (any state)?
        boolean[] hasIdx = {false, false, false};
        for (VoltChakram vc : voltChakrams)
            if (vc.ownerId == lp.id && vc.orbitIdx >= 0 && vc.orbitIdx < 3)
                hasIdx[vc.orbitIdx] = true;
        for (int i = 0; i < 3; i++)
            if (!hasIdx[i]) voltChakrams.add(new VoltChakram(lp.id, i));
    }

    /** Called on aim-stick release when Volt Chakram is equipped. */
    private void launchVoltChakrams(Player lp, float ax, float ay) {
        launchVoltChakrams(lp, ax, ay, voltCharge);
    }
    private void launchVoltChakrams(Player lp, float ax, float ay, float charge) {
        float mag = (float) Math.sqrt(ax * ax + ay * ay);
        if (mag < 0.05f) return;          // no direction — don't launch
        float launchAngle = (float) Math.atan2(ay / mag, ax / mag);
        float speed  = 820f + charge * 680f;   // 820–1500 px/s (faster with charge)
        float damage = 18f  + charge * 24f;    // 18–42 per disc
        float range  = 660f + charge * 640f;   // 660–1300 px (longer with charge)
        // Three discs fan out — spread CONDENSES as charge builds (0.21→0.06 rad)
        float spreadAmt = 0.21f - charge * 0.15f;
        float[] spreads = {-spreadAmt, 0f, spreadAmt};
        int slot = 0;
        for (VoltChakram vc : voltChakrams) {
            if (vc.ownerId == lp.id && vc.state == VoltChakram.ORBITING && slot < 3) {
                float a = launchAngle + spreads[slot];
                vc.vx = (float) Math.cos(a) * speed;
                vc.vy = (float) Math.sin(a) * speed;
                vc.damage = damage;
                vc.distTraveled = 0f;
                vc.maxRange = range;
                vc.hitIds.clear();
                vc.state = VoltChakram.LAUNCHED;
                slot++;
            }
        }
        voltCharge = 0f;
        voltPrevAimAngle = Float.NaN;
    }

    /** Main per-frame update: orbit → launch → return cycle + hit detection. */
    private void updateVoltChakrams(Player lp, float dt) {
        ensureVoltChakrams(lp);

        // Self-spin of each disc graphic (always rotating for visual life)
        for (VoltChakram vc : voltChakrams) vc.spinAngle += dt * 4.5f;

        int orbiting = 0;
        Iterator<VoltChakram> it = voltChakrams.iterator();
        while (it.hasNext()) {
            VoltChakram vc = it.next();

            // Skip discs that belong to a different player — their positions
            // come from the host's authoritative broadcast, not from this update.
            if (vc.ownerId != lp.id) continue;

            // ── ORBITING ──────────────────────────────────────────────────────
            if (vc.state == VoltChakram.ORBITING) {
                float orbitA = voltOrbitAngle + vc.orbitIdx * (float)(Math.PI * 2 / 3);
                vc.x = lp.x + VoltChakram.ORBIT_RADIUS * (float) Math.cos(orbitA);
                vc.y = lp.y + VoltChakram.ORBIT_RADIUS * (float) Math.sin(orbitA);
                // Damage enemies that walk into orbit range (18 dmg every 700ms per disc)
                if (isHost) {
                    long now = System.currentTimeMillis();
                    if (now >= vc.nextOrbitHitMs) {
                        boolean hit = false;
                        // FIX Bug3: was `vc.ownerId != lp.id` which is always false here
                        // (non-owner VCs are skipped above). Check localPlayer explicitly
                        // so bot chakrams can correctly orbit-damage the human player.
                        Player hlp = localPlayer;
                        if (hlp != null && hlp.alive && vc.ownerId != hlp.id) {
                            float dx = hlp.x - vc.x, dy = hlp.y - vc.y;
                            if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                                Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, 18f, -1, 999f);
                                applyBulletDamage(proxy, hlp, null, hlp);
                                hit = true;
                            }
                        }
                        for (Player rp : remote.values()) {
                            if (!rp.alive || vc.ownerId == rp.id) continue;
                            float dx = rp.x - vc.x, dy = rp.y - vc.y;
                            if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                                Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, 18f, -1, 999f);
                                Player hlp2 = localPlayer;
                                applyBulletDamage(proxy, hlp2 != null ? hlp2 : lp, rp, hlp2 != null ? hlp2 : lp);
                                hit = true;
                            }
                        }
                        if (hit) vc.nextOrbitHitMs = now + 700L;
                    }
                }
                orbiting++;
                continue;
            }

            // ── LAUNCHED ──────────────────────────────────────────────────────
            if (vc.state == VoltChakram.LAUNCHED) {
                float nx = vc.x + vc.vx * dt;
                float ny = vc.y + vc.vy * dt;

                // Wall check → reverse to RETURNING
                boolean hitWall = false;
                for (float[] w : WALLS) {
                    if (nx >= w[0]-6 && nx <= w[2]+6 && ny >= w[1]-6 && ny <= w[3]+6) {
                        hitWall = true; break;
                    }
                }
                vc.distTraveled += (float) Math.sqrt((nx-vc.x)*(nx-vc.x)+(ny-vc.y)*(ny-vc.y));

                if (hitWall || vc.distTraveled >= vc.maxRange) {
                    vc.state = VoltChakram.RETURNING;
                    vc.hitIds.clear();  // can re-hit on the way back
                    continue;
                }
                vc.x = nx; vc.y = ny;

                // Hit detection (host only)
                if (isHost) applyChakramHits(vc, lp);
                continue;
            }

            // ── RETURNING ─────────────────────────────────────────────────────
            if (vc.state == VoltChakram.RETURNING) {
                float dx = lp.x - vc.x, dy = lp.y - vc.y;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);

                if (dist < 24f) {
                    // Disc caught by player — back to orbit
                    vc.state = VoltChakram.ORBITING;
                    vc.hitIds.clear();
                    orbiting++;
                    continue;
                }
                float spd = VoltChakram.RETURN_SPEED;
                vc.x += (dx / dist) * spd * dt;
                vc.y += (dy / dist) * spd * dt;

                if (isHost) applyChakramHits(vc, lp);
            }
        }

        // Keep gun ammo in sync with orbiting count for the HUD
        Gun g = lp.currentGun();
        if (isVoltChakram(g)) g.ammo = orbiting;
    }

    /** Apply damage to any players overlapping this chakram (skips already-hit IDs). */
    private void applyChakramHits(VoltChakram vc, Player lp) {
        // Local player
        if (lp.alive && vc.ownerId != lp.id && !vc.hitIds.contains(lp.id)) {
            float dx = lp.x - vc.x, dy = lp.y - vc.y;
            if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                vc.hitIds.add(lp.id);
                // Re-use applyBulletDamage by creating a thin proxy bullet
                Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, vc.damage, -1, 999f);
                applyBulletDamage(proxy, lp, null, lp);
            }
        }
        // Remote players
        for (Player rp : remote.values()) {
            if (!rp.alive || vc.ownerId == rp.id || vc.hitIds.contains(rp.id)) continue;
            float dx = rp.x - vc.x, dy = rp.y - vc.y;
            if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                vc.hitIds.add(rp.id);
                Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, vc.damage, -1, 999f);
                applyBulletDamage(proxy, lp, rp, lp);
            }
        }
    }

    /** Render all active chakram discs in world space. */
    private void drawVoltChakrams(Canvas c) {
        long now = System.currentTimeMillis();
        float pulse = 0.6f + 0.4f * (float) Math.sin(now / 180.0);  // gentle brightness pulse

        for (VoltChakram vc : voltChakrams) {
            float cx = vc.x, cy = vc.y;

            // Choose tint based on state
            int r, g, b;
            if (vc.state == VoltChakram.ORBITING) {
                // Electric cyan-white
                r = 140; g = 220; b = 255;
            } else if (vc.state == VoltChakram.LAUNCHED) {
                // Bright white-yellow at high speed
                r = 220; g = 245; b = 255;
            } else {
                // Returning: warmer cyan
                r = 80; g = 200; b = 255;
            }

            // ── Outer soft glow ──────────────────────────────────────────────
            float glowR = 18f + pulse * 5f;
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.FILL);
            glow.setColor(Color.argb((int)(60 * pulse), r, g, b));
            c.drawCircle(cx, cy, glowR, glow);

            // ── Hexagon disc ─────────────────────────────────────────────────
            Path hex = new Path();
            float hexR = 11f;
            for (int i = 0; i < 6; i++) {
                float a = vc.spinAngle + (float)(i * Math.PI / 3);
                float px = cx + hexR * (float) Math.cos(a);
                float py = cy + hexR * (float) Math.sin(a);
                if (i == 0) hex.moveTo(px, py); else hex.lineTo(px, py);
            }
            hex.close();

            // Disc fill
            Paint hexFill = new Paint(Paint.ANTI_ALIAS_FLAG);
            hexFill.setStyle(Paint.Style.FILL);
            hexFill.setColor(Color.argb(200, r / 2, g / 2, b));
            c.drawPath(hex, hexFill);

            // Disc bright edge
            Paint hexEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
            hexEdge.setStyle(Paint.Style.STROKE);
            hexEdge.setStrokeWidth(2.5f);
            hexEdge.setColor(Color.argb(240, r, g, b));
            c.drawPath(hex, hexEdge);

            // ── Inner bright core ────────────────────────────────────────────
            Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
            core.setStyle(Paint.Style.FILL);
            core.setColor(Color.argb((int)(200 + 55 * pulse), r, g, b));
            c.drawCircle(cx, cy, 3.5f, core);

            // ── Electric arc lines (orbiting only) ───────────────────────────
            if (vc.state == VoltChakram.ORBITING) {
                Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
                arc.setStyle(Paint.Style.STROKE);
                arc.setStrokeWidth(1.5f);
                arc.setColor(Color.argb((int)(120 * pulse), 180, 240, 255));
                // 3 short zap lines radiating outward at random-ish angles
                float seed = (now / 90f) + vc.orbitIdx * 2.1f;
                for (int z = 0; z < 3; z++) {
                    float za = seed + z * 2.09f;  // ~120° apart
                    float zapLen = 8f + 5f * (float) Math.abs(Math.sin(seed + z));
                    c.drawLine(cx, cy,
                               cx + (float) Math.cos(za) * zapLen,
                               cy + (float) Math.sin(za) * zapLen, arc);
                }
            }

            // ── Motion trail for launched / returning ────────────────────────
            if (vc.state != VoltChakram.ORBITING) {
                float speed = (float) Math.sqrt(vc.vx * vc.vx + vc.vy * vc.vy);
                if (speed > 10f) {
                    float trailLen = Math.min(28f, speed * 0.022f);
                    float ux = -vc.vx / speed, uy = -vc.vy / speed;
                    Paint trail = new Paint(Paint.ANTI_ALIAS_FLAG);
                    trail.setStyle(Paint.Style.STROKE);
                    trail.setStrokeWidth(3f);
                    trail.setColor(Color.argb(160, r, g, b));
                    c.drawLine(cx, cy, cx + ux * trailLen, cy + uy * trailLen, trail);
                }
            }
        }
    }

    private void updateBullets(Player lp, float dt){
        Iterator<Bullet> it=bullets.iterator();
        while(it.hasNext()){
            Bullet b=it.next();

            // ── Homing: steer toward nearest enemy ONLY if within 160px and in front 120° cone ──
            if(b.homing){
                float tx=Float.MAX_VALUE, ty=0; float bestDist=Float.MAX_VALUE;
                float curA=(float)Math.atan2(b.dy,b.dx);
                float coneHalf = (float)(Math.PI / 3); // 60 deg each side
                float seekRangeSq = 160f * 160f;       // only home within 160px
                if(lp.alive&&b.ownerId!=lp.id){
                    float d=d2(b.x,b.y,lp.x,lp.y);
                    float ang=(float)Math.atan2(lp.y-b.y,lp.x-b.x);
                    float diff=ang-curA; while(diff>Math.PI)diff-=2*(float)Math.PI; while(diff<-Math.PI)diff+=2*(float)Math.PI;
                    if(d<seekRangeSq&&Math.abs(diff)<coneHalf&&d<bestDist){bestDist=d;tx=lp.x;ty=lp.y;}
                }
                for(Player rp:remote.values()){
                    if(b.ownerId==rp.id||!rp.alive) continue;
                    float d=d2(b.x,b.y,rp.x,rp.y);
                    float ang=(float)Math.atan2(rp.y-b.y,rp.x-b.x);
                    float diff=ang-curA; while(diff>Math.PI)diff-=2*(float)Math.PI; while(diff<-Math.PI)diff+=2*(float)Math.PI;
                    if(d<seekRangeSq&&Math.abs(diff)<coneHalf&&d<bestDist){bestDist=d;tx=rp.x;ty=rp.y;}
                }
                if(tx!=Float.MAX_VALUE){
                    float tgtA=(float)Math.atan2(ty-b.y,tx-b.x);
                    float diff=tgtA-curA; while(diff>Math.PI)diff-=2*(float)Math.PI; while(diff<-Math.PI)diff+=2*(float)Math.PI;
                    // Weak 1.2 rad/s turn — curves toward enemy but still missable
                    float turn=Math.signum(diff)*Math.min(Math.abs(diff),1.2f*dt);
                    float na=curA+turn; float spd=(float)Math.sqrt(b.dx*b.dx+b.dy*b.dy);
                    b.dx=(float)Math.cos(na)*spd; b.dy=(float)Math.sin(na)*spd;
                }
            }

            // ── Move ─────────────────────────────────────────────────────────
            float nx=b.x+b.dx*dt, ny=b.y+b.dy*dt;
            boolean rm=false;

            // ── Boundary ─────────────────────────────────────────────────────
            boolean xOut=nx<0||nx>MAP_W, yOut=ny<0||ny>MAP_H;
            if(xOut||yOut){
                if(b.bouncesLeft>0){
                    if(xOut){b.dx=-b.dx;nx=Math.max(0,Math.min(MAP_W,nx));}
                    if(yOut){b.dy=-b.dy;ny=Math.max(0,Math.min(MAP_H,ny));}
                    b.bouncesLeft--; b.spawnX=nx; b.spawnY=ny;
                } else { if(b.explosive) doExplosion(b,lp); rm=true; }
            }

            // ── Walls ─────────────────────────────────────────────────────────
            if(!rm&&!b.ghost){
                boolean xB=false,yB=false;
                for(float[] w:WALLS){
                    if(!xB&&nx>=w[0]&&nx<=w[2]&&b.y>=w[1]&&b.y<=w[3]) xB=true;
                    if(!yB&&b.x>=w[0]&&b.x<=w[2]&&ny>=w[1]&&ny<=w[3]) yB=true;
                }
                if(!xB&&!yB) for(float[] w:WALLS) if(nx>=w[0]&&nx<=w[2]&&ny>=w[1]&&ny<=w[3]){xB=true;yB=true;break;}
                if(xB||yB){
                    if(b.bouncesLeft>0){
                        if(xB) b.dx=-b.dx; if(yB) b.dy=-b.dy;
                        if(!xB&&!yB){b.dx=-b.dx;b.dy=-b.dy;}
                        b.bouncesLeft--; b.spawnX=b.x; b.spawnY=b.y; nx=b.x; ny=b.y;
                    } else { if(b.explosive) doExplosion(b,lp); rm=true; }
                }
            }

            b.x=nx; b.y=ny;

            // ── Range culling ─────────────────────────────────────────────────
            if(!rm){float rdx=b.x-b.spawnX,rdy=b.y-b.spawnY;
                if(rdx*rdx+rdy*rdy>b.range*b.range){if(b.explosive)doExplosion(b,lp);rm=true;}}
            if(!rm&&System.currentTimeMillis()-b.spawnTime>5000) rm=true;

            // ── Hit detection ─────────────────────────────────────────────────
            if(!rm&&isHost){
                if(lp.alive&&b.ownerId!=lp.id&&d2(b.x,b.y,lp.x,lp.y)<PR*PR){
                    if(b.piercing){
                        if(b.hitIds!=null&&!b.hitIds.contains(lp.id)){b.hitIds.add(lp.id);applyBulletDamage(b,lp,null,lp);}
                    } else { rm=true; if(b.explosive) doExplosion(b,lp); else applyBulletDamage(b,lp,null,lp); }
                }
                if((!rm||b.piercing)) for(Player rp:remote.values()){
                    if(b.ownerId==rp.id||!rp.alive) continue;
                    if(d2(b.x,b.y,rp.x,rp.y)<PR*PR){
                        if(b.piercing){
                            if(b.hitIds!=null&&!b.hitIds.contains(rp.id)){b.hitIds.add(rp.id);applyBulletDamage(b,lp,rp,lp);}
                        } else { rm=true; if(b.explosive) doExplosion(b,lp); else applyBulletDamage(b,lp,rp,lp); break; }
                    }
                }
            }
            // ── Client-side hit prediction: instant visual feedback ───────────
            // On the client (not host), when a LOCAL bullet overlaps a remote player,
            // flash a hit marker immediately without waiting for server confirmation.
            if(!rm && !isHost && b.ownerId==lp.id){
                for(Player rp:remote.values()){
                    if(!rp.alive) continue;
                    if(d2(b.x,b.y,rp.x,rp.y)<(PR*1.4f)*(PR*1.4f)){
                        // Only flash once per bullet-player pair (check hitIds)
                        if(b.hitIds==null) b.hitIds=new java.util.HashSet<>();
                        if(!b.hitIds.contains(rp.id)){
                            b.hitIds.add(rp.id);
                            predictedHitFx.add(new long[]{(long)b.x,(long)b.y,System.currentTimeMillis()});
                        }
                    }
                }
            }
            if(rm) it.remove();
        }
    }

    private void applyBulletDamage(Bullet b, Player lp, Player rp, Player localP){
        Player t=(rp!=null)?rp:lp;
        if(t.isProtected()) return;
        // Being hit breaks stealth
        if(t.isStealthed()) t.skillActiveUntil = 0;
        float dmg=b.damage;
        if(t.isShielded()){float reduced=dmg*0.5f;float abs=Math.min(reduced,t.shieldHp);t.shieldHp-=abs;dmg-=abs;if(t.shieldHp<=0)t.skillActiveUntil=0;}
        t.hp=Math.max(0,t.hp-dmg);
        // ── Apply paint status effects ─────────────────────────────────────────
        long now=System.currentTimeMillis();
        if(b.paintColor==1){ // blue = slow
            t.slowUntil = Math.max(t.slowUntil, now+b.slowDurationMs);
        } else if(b.paintColor==2){ // green = poison
            t.poisonUntil = Math.max(t.poisonUntil, now+b.poisonDurationMs);
            t.poisonOwnerId    = b.ownerId;
            t.poisonTickDamage = b.poisonTickDamage;
        }
        if (b.hookSpear) {
            t.hookPullFromX  = b.spawnX;
            t.hookPullFromY  = b.spawnY;
            t.hookPullOwnerId = b.ownerId;
            float hdx = t.x - b.spawnX, hdy = t.y - b.spawnY;
            float hitDist = (float)Math.sqrt(hdx*hdx + hdy*hdy);
            long pullDuration = Math.max(600L, (long)(hitDist / StatusEffectConfig.HOOK_PULL_SPEED * 1000f) + 500L);
            t.hookPullUntil  = now + pullDuration;
            t.stunUntil      = now + pullDuration + b.stunBonusMs;
        }
        if(t.hp==0){
            if(rp==null){
                // Remote bullet killed the host's local player
                t.alive=false;deathTime=System.currentTimeMillis();throwingBomb=false;
                addFeed(nameOf(b.ownerId)+" ➜ "+t.name);
                Player k=remote.get(b.ownerId);
                if(k!=null){
                    k.coins+=25;
                    // FIX: Soul Reaper kill credit — isSoulReaper was set on the Bullet but
                    // never checked here, so the gun never upgraded. Fixed.
                    if(b.isSoulReaper){ k.guns[20].killCount++; k.guns[20].applySoulLevel(); }
                }
            } else {
                // A bullet killed a remote player
                t.alive=false;deadAtMs.put(t.id,System.currentTimeMillis());
                addFeed(nameOf(b.ownerId)+" ➜ "+t.name);
                if(b.ownerId==localP.id){
                    localP.coins+=25;
                    // FIX: Soul Reaper kill credit for host's local player bullet kills
                    if(b.isSoulReaper){ localP.guns[20].killCount++; localP.guns[20].applySoulLevel(); }
                } else {
                    Player k=remote.get(b.ownerId);
                    if(k!=null){
                        k.coins+=25;
                        // FIX: Soul Reaper kill credit for remote player bullet kills
                        if(b.isSoulReaper){ k.guns[20].killCount++; k.guns[20].applySoulLevel(); }
                    }
                }
            }
        }
    }

    /** Moves all players that are currently being pulled by a Hook Spear. */
    private void updateHookPulls(float dt) {
        if (!isHost) return;
        applyHookPull(localPlayer, dt);
        for (Player rp : remote.values()) applyHookPull(rp, dt);
    }

    private void applyHookPull(Player p, float dt) {
        if (p == null || !p.alive || !p.isBeingPulled()) return;
        // Keep pull origin locked to caster's current position so target is dragged all the way to them
        Player caster = (localPlayer != null && p.hookPullOwnerId == localPlayer.id)
                ? localPlayer : remote.get(p.hookPullOwnerId);
        if (caster != null) { p.hookPullFromX = caster.x; p.hookPullFromY = caster.y; }
        float dx = p.hookPullFromX - p.x, dy = p.hookPullFromY - p.y;
        float dist = (float) Math.sqrt(dx*dx + dy*dy);
        // Stop pulling when very close to caster (within 2*PR)
        if (dist < PR * 2f) { p.hookPullUntil = 0; return; }
        float pullSpd = StatusEffectConfig.HOOK_PULL_SPEED;
        float nx = p.x + (dx/dist) * pullSpd * dt;
        float ny = p.y + (dy/dist) * pullSpd * dt;
        nx = clamp(nx, PR, MAP_W-PR); ny = clamp(ny, PR, MAP_H-PR);
        float[] pos = walls(p.x, p.y, nx, ny); p.x = pos[0]; p.y = pos[1];
    }

    /** Draws a catenary-style bezier rope between two world-space points. */
    private void drawRope(Canvas c, float x1, float y1, float x2, float y2) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx*dx + dy*dy);
        if (len < 2f) return;
        // Mid-point sag: blend perpendicular + downward gravity
        float mx = (x1+x2)*0.5f, my = (y1+y2)*0.5f;
        float perpX = -dy/len, perpY = dx/len;  // unit perpendicular
        float sagAmt = Math.min(len * 0.14f, 45f);
        // Bias sag downward (+y in world) to simulate gravity
        float ctrlX = mx + perpX * sagAmt * 0.3f;
        float ctrlY = my + perpY * sagAmt * 0.3f + sagAmt * 0.8f;
        android.graphics.Path ropePath = new android.graphics.Path();
        ropePath.moveTo(x1, y1);
        ropePath.quadTo(ctrlX, ctrlY, x2, y2);
        // Outer dark shadow
        Paint outer = new Paint(Paint.ANTI_ALIAS_FLAG);
        outer.setStyle(Paint.Style.STROKE); outer.setStrokeWidth(5f);
        outer.setColor(Color.argb(180, 70, 45, 15));
        outer.setStrokeCap(Paint.Cap.ROUND);
        c.drawPath(ropePath, outer);
        // Inner lighter rope strand
        Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
        inner.setStyle(Paint.Style.STROKE); inner.setStrokeWidth(2.5f);
        inner.setColor(Color.argb(230, 205, 165, 90));
        inner.setStrokeCap(Paint.Cap.ROUND);
        c.drawPath(ropePath, inner);
        // Thin highlight strand for woven look
        Paint highlight = new Paint(Paint.ANTI_ALIAS_FLAG);
        highlight.setStyle(Paint.Style.STROKE); highlight.setStrokeWidth(1f);
        highlight.setColor(Color.argb(120, 255, 220, 140));
        c.drawPath(ropePath, highlight);
    }

    /** Draws pull-phase ropes for all players currently being yanked. Called in world space. */
    private void drawPullRopes(Canvas c) {
        for (Player p : remote.values()) {
            if (!p.alive || !p.isBeingPulled()) continue;
            Player caster = (localPlayer != null && p.hookPullOwnerId == localPlayer.id)
                    ? localPlayer : remote.get(p.hookPullOwnerId);
            float ox = (caster != null) ? caster.x : p.hookPullFromX;
            float oy = (caster != null) ? caster.y : p.hookPullFromY;
            drawRope(c, ox, oy, p.x, p.y);
        }
        // Local player being pulled
        if (localPlayer != null && localPlayer.alive && localPlayer.isBeingPulled()) {
            Player caster = remote.get(localPlayer.hookPullOwnerId);
            float ox = (caster != null) ? caster.x : localPlayer.hookPullFromX;
            float oy = (caster != null) ? caster.y : localPlayer.hookPullFromY;
            drawRope(c, ox, oy, localPlayer.x, localPlayer.y);
        }
    }

    /** Pushes all alive players apart so they can't overlap each other. */
    private void resolvePlayerCollisions() {
        collisionPlayers.clear();
        if (localPlayer != null && localPlayer.alive) collisionPlayers.add(localPlayer);
        for (Player rp : remote.values()) if (rp.alive) collisionPlayers.add(rp);
        float minDist = PR * 2f;
        for (int i = 0; i < collisionPlayers.size(); i++) {
            for (int j = i + 1; j < collisionPlayers.size(); j++) {
                Player a = collisionPlayers.get(i), b2 = collisionPlayers.get(j);
                float dx = a.x - b2.x, dy = a.y - b2.y;
                float dist = (float) Math.sqrt(dx*dx + dy*dy);
                if (dist < minDist && dist > 0.5f) {
                    float push = (minDist - dist) * 0.5f;
                    float nx2 = dx/dist, ny2 = dy/dist;
                    a.x  = clamp(a.x  + nx2*push, PR, MAP_W-PR);
                    a.y  = clamp(a.y  + ny2*push, PR, MAP_H-PR);
                    b2.x = clamp(b2.x - nx2*push, PR, MAP_W-PR);
                    b2.y = clamp(b2.y - ny2*push, PR, MAP_H-PR);
                }
            }
        }
    }

    private void doExplosion(Bullet b, Player lp){
        // Visual FX — stored as {x, y, spawnMs} drawn by all clients
        explosionFx.add(new long[]{(long)b.x, (long)b.y, System.currentTimeMillis()});
        if(!isHost) return;
        float R=150f;
        if(lp.alive&&b.ownerId!=lp.id&&d2(b.x,b.y,lp.x,lp.y)<R*R) applyBulletDamage(b,lp,null,lp);
        for(Player rp:remote.values()){
            if(b.ownerId==rp.id||!rp.alive) continue;
            if(d2(b.x,b.y,rp.x,rp.y)<R*R) applyBulletDamage(b,lp,rp,lp);
        }
    }

    /** Applies poison damage (8 dmg every 600 ms) to local + remote players. */
    private void applyPoisonTicks(Player lp){
        if(!isHost) return;
        long now=System.currentTimeMillis();
        // Local player
        if(lp.alive && lp.isPoisoned() && now-lp.poisonLastTick>=StatusEffectConfig.POISON_TICK_MS){
            lp.poisonLastTick=now;
            if(!lp.isProtected()){
                lp.hp=Math.max(0, lp.hp-lp.poisonTickDamage);
                if(lp.hp==0){
                    lp.alive=false; deathTime=now;
                    addFeed(nameOf(lp.poisonOwnerId)+" ☠ "+lp.name+" (poison)");
                    Player killer=remote.get(lp.poisonOwnerId);
                    if(killer!=null) killer.coins+=25;
                }
                if(lp.isStealthed()) lp.skillActiveUntil=0;
            }
        }
        // Remote players
        for(Player rp:remote.values()){
            if(!rp.alive||!rp.isPoisoned()) continue;
            if(now-rp.poisonLastTick>=StatusEffectConfig.POISON_TICK_MS){
                rp.poisonLastTick=now;
                if(!rp.isProtected()){
                    if(rp.isStealthed()) rp.skillActiveUntil=0;
                    rp.hp=Math.max(0, rp.hp-rp.poisonTickDamage);
                    if(rp.hp==0){
                        rp.alive=false; deadAtMs.put(rp.id,now);
                        addFeed(nameOf(rp.poisonOwnerId)+" ☠ "+rp.name+" (poison)");
                        if(rp.poisonOwnerId==lp.id) lp.coins+=25;
                        else{ Player killer=remote.get(rp.poisonOwnerId); if(killer!=null) killer.coins+=25; }
                    }
                }
            }
        }
    }

    private void applyClientInputs(float dt){
        for(Map.Entry<Integer,float[]> e:inputs.entrySet()){
            Player p=remote.get(e.getKey()); if(p==null||!p.alive) continue;
            float[] inp=e.getValue();
            // Sync skill levels from client input
            if(inp.length>13){
                p.skillReload    =Math.max(0,Math.min(3,(int)inp[7]));
                p.skillFireRate  =Math.max(0,Math.min(3,(int)inp[8]));
                p.skillRange     =Math.max(0,Math.min(3,(int)inp[9]));
                p.skillMoveSpeed =Math.max(0,Math.min(3,(int)inp[10]));
                p.activeSkillType=(int)inp[11];
                // FIX Bug6: field 12 is now ms remaining (was seconds — caused up to 999ms precision loss)
                long msRem2=(long)inp[12]; p.skillActiveUntil= msRem2>0?System.currentTimeMillis()+msRem2:0;
                p.shieldHp=inp[13];
                // FIX Bug5: apply heal on the host's authoritative copy so the hp change sticks
                if(inp.length>17 && inp[17]>0.5f && p.alive) p.hp=Math.min(100,p.hp+40);
            }
            // ── Use client's authoritative position if provided ─────────────────
            // inp[14]=px, inp[15]=py (−1 means not provided, fall back to delta)
            float clientX = inp.length>14 ? inp[14] : -1f;
            float clientY = inp.length>15 ? inp[15] : -1f;
            if (p.isBeingPulled() || p.isStunned()) {
                // Hook pull / stun: host position is authoritative — ignore client
            } else if(clientX >= 0 && clientY >= 0){
                // FIX: lerp toward client position to smooth network jitter.
                // Snap instantly if far away (respawn/teleport), otherwise ease in.
                float tX = clamp(clientX, PR, MAP_W-PR);
                float tY = clamp(clientY, PR, MAP_H-PR);
                float snapDist2 = 120f*120f;
                if ((tX-p.x)*(tX-p.x)+(tY-p.y)*(tY-p.y) > snapDist2) {
                    p.x = tX; p.y = tY; // far away: snap immediately
                } else {
                    p.x += (tX - p.x) * 0.3f; // close: smooth interpolation
                    p.y += (tY - p.y) * 0.3f;
                }
            } else {
                // Fallback: dead-reckon from joystick (should rarely happen)
                float nx=p.x+inp[0]*280f*p.moveSpeedMult()*dt, ny=p.y+inp[1]*280f*p.moveSpeedMult()*dt;
                nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
                float[] pos=walls(p.x,p.y,nx,ny); p.x=pos[0]; p.y=pos[1];
            }
            // Aim angle from joystick
            if(inp[2]*inp[2]+inp[3]*inp[3]>0.01f) p.angle=(float)Math.atan2(inp[3],inp[2]);
            p.gunIndex=Math.max(0,Math.min((int)inp[5], p.guns.length-1));
            if(inp[6]>0.5f) p.guns[p.gunIndex].startReload();
            float rm=p.reloadMult();
            for(Gun g:p.guns) g.tick(rm);
            { Gun g=p.currentGun(); if(g.ammo<=0&&!g.reloading) g.startReload(); }
            if(inp[4]>0.5f){
                Gun g=p.currentGun();
                float frMult=p.fireRateMult();
                long fireCd=(long)(1000f/(g.fireRate*frMult));
                if(g.ammo>0&&!g.reloading&&System.currentTimeMillis()-g.lastFireTime>=fireCd){
                    spawnBullets(p); g.markFired();
                }
            }
        }
    }

    private void checkRemoteRespawns(){
        long now=System.currentTimeMillis();
        for(Player p:remote.values()) {
            if (!p.alive && deadAtMs.containsKey(p.id)) {
                long delay = dummyIds.contains(p.id) ? 2000L : RESPAWN_MS;
                if (now - deadAtMs.get(p.id) >= delay) {
                    if (dummyIds.contains(p.id)) respawnDummy(p);
                    else respawn(p);
                    deadAtMs.remove(p.id);
                }
            }
        }
    }

    private void respawn(Player p){
        float[] sp=SPAWNS[p.id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true; p.guns=Gun.createAll();
        p.bombs = 2;
        p.spawnProtectionUntil = System.currentTimeMillis() + 3000;
        p.shieldHp = 0; p.skillActiveUntil = 0; p.skillCooldownEnd = 0;
        p.slowUntil = 0; p.poisonUntil = 0; p.poisonLastTick = 0; p.poisonOwnerId = -1;
        p.stunUntil = 0; p.hookPullUntil = 0; p.hookPullOwnerId = -1;  // clear status effects on respawn
        // Keep coins, skill levels, active skill type, and unlocked guns
        // FIX: only validate gunIndex for the LOCAL player. The host never receives
        // unlockedGuns data for remote players, so their copy is always {true,false,…}.
        // Without this guard, the host was resetting every remote player to pistol (index 0)
        // on every respawn, even when they had a different gun equipped.
        Player lp = localPlayer;
        if (p == lp && !p.unlockedGuns[p.gunIndex]) p.gunIndex = 0;
        // For remote players, applyClientInputs restores the correct gunIndex each frame.
    }
    private void spawnLocal(int id, String name){
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.spawnProtectionUntil = System.currentTimeMillis() + 3000;
        localPlayer=p;
    }

    /** Spawn one more training dummy (up to MAX_DUMMIES). */
    private void spawnDummy() {
        if (dummyIds.size() >= MAX_DUMMIES) return;
        int slot = dummyIds.size();
        int id   = DUMMY_ID_BASE + slot;
        float[] home = DUMMY_SPAWNS[slot % DUMMY_SPAWNS.length];
        Player d = new Player();
        d.id = id; d.name = "Dummy"; d.guns = Gun.createAll();
        d.x = home[0]; d.y = home[1]; d.hp = 100; d.alive = true;
        d.spawnProtectionUntil = 0; // dummies have no protection
        remote.put(id, d);
        dummyIds.add(id);
        dummyHome.put(id, new float[]{home[0], home[1]});
    }

    /** Remove the most recently added training dummy. */
    private void removeLastDummy() {
        if (dummyIds.isEmpty()) return;
        int lastId = DUMMY_ID_BASE + dummyIds.size() - 1;
        remote.remove(lastId);
        dummyIds.remove(lastId);
        dummyHome.remove(lastId);
        deadAtMs.remove(lastId);
        voltChakrams.removeIf(vc -> vc.ownerId == lastId);
    }

    /** Respawn a dummy at its fixed home position. */
    private void respawnDummy(Player d) {
        float[] home = dummyHome.get(d.id);
        if (home == null) return;
        d.x = home[0]; d.y = home[1];
        d.hp = 100; d.alive = true; d.guns = Gun.createAll();
        d.spawnProtectionUntil = 0;
        d.shieldHp = 0; d.skillActiveUntil = 0; d.skillCooldownEnd = 0;
        d.slowUntil = 0; d.poisonUntil = 0; d.poisonLastTick = 0; d.poisonOwnerId = -1;
        d.stunUntil = 0; d.hookPullUntil = 0; d.hookPullOwnerId = -1;
    }

    // ══ BOT AI ════════════════════════════════════════════════════════════════

    /** Tactical state-machine AI engine — fully separated from GameView. */
    private final BotAI botAI = new BotAI();

    /** Pre-built wall-corner waypoints used for around-wall routing. */
    private float[][] navWaypoints;

    /**
     * Builds waypoints at every wall corner (plus map corners) with a margin so
     * bots always stand outside the wall geometry.  Call once after WALLS is set.
     */
    private void buildNavWaypoints() {
        final float PAD = 52f;
        List<float[]> pts = new ArrayList<>();
        // Map corners
        pts.add(new float[]{PAD, PAD});
        pts.add(new float[]{MAP_W - PAD, PAD});
        pts.add(new float[]{PAD, MAP_H - PAD});
        pts.add(new float[]{MAP_W - PAD, MAP_H - PAD});
        // For every wall: 4 outer corners + 4 edge midpoints
        for (float[] w : WALLS) {
            float mx = (w[0] + w[2]) * 0.5f, my = (w[1] + w[3]) * 0.5f;
            pts.add(new float[]{w[0] - PAD, w[1] - PAD});
            pts.add(new float[]{w[2] + PAD, w[1] - PAD});
            pts.add(new float[]{w[0] - PAD, w[3] + PAD});
            pts.add(new float[]{w[2] + PAD, w[3] + PAD});
            pts.add(new float[]{mx,          w[1] - PAD});
            pts.add(new float[]{mx,          w[3] + PAD});
            pts.add(new float[]{w[0] - PAD,  my});
            pts.add(new float[]{w[2] + PAD,  my});
        }
        // Keep only points that are inside the map and not inside any wall
        List<float[]> valid = new ArrayList<>();
        for (float[] p : pts) {
            if (p[0] < PAD || p[0] > MAP_W - PAD || p[1] < PAD || p[1] > MAP_H - PAD) continue;
            boolean blocked = false;
            for (float[] w : WALLS) {
                if (p[0] > w[0] && p[0] < w[2] && p[1] > w[1] && p[1] < w[3]) { blocked = true; break; }
            }
            if (!blocked) valid.add(p);
        }
        navWaypoints = valid.toArray(new float[0][]);
    }

    /**
     * Finds the cheapest 1-hop waypoint such that: bot→wp has clear LOS AND
     * wp→target has clear LOS.  Returns null if no waypoint is needed / found.
     */
    private float[] findNavWaypoint(float bx, float by, float tx, float ty) {
        float bestCost = Float.MAX_VALUE;
        float[] best   = null;
        if (navWaypoints == null) return null;
        for (float[] wp : navWaypoints) {
            if (!hasLos(bx, by, wp[0], wp[1])) continue;
            if (!hasLos(wp[0], wp[1], tx, ty))  continue;
            float d1x = wp[0] - bx, d1y = wp[1] - by;
            float d2x = tx - wp[0], d2y = ty - wp[1];
            float cost = (float)(Math.sqrt(d1x*d1x + d1y*d1y) + Math.sqrt(d2x*d2x + d2y*d2y));
            if (cost < bestCost) { bestCost = cost; best = wp; }
        }
        return best;
    }

    /** Move bot by (moveX, moveY)*speed*dt with axis-separated wall sliding. */
    private void moveBotWithCollision(Player bot, float moveX, float moveY, float speed, float dt) {
        float nx = clamp(bot.x + moveX * speed * dt, PR, MAP_W - PR);
        float ny = clamp(bot.y + moveY * speed * dt, PR, MAP_H - PR);
        // Test each axis separately so the bot slides along wall faces
        boolean xOk = true, yOk = true;
        for (float[] w : WALLS) {
            if (xOk && nx + PR > w[0] && nx - PR < w[2] && bot.y + PR > w[1] && bot.y - PR < w[3]) xOk = false;
            if (yOk && bot.x + PR > w[0] && bot.x - PR < w[2] && ny + PR > w[1] && ny - PR < w[3]) yOk = false;
        }
        if (xOk) bot.x = nx;
        if (yOk) bot.y = ny;
    }

    /**
     * Per-frame AI update. Delegates entirely to {@link BotAI} via a Context
     * adapter so all tactical logic lives in the separated BotAI class.
     */
    private void updateBots(float dt) {
        Player lp = localPlayer;
        if (lp == null) return;
        if (navWaypoints == null) buildNavWaypoints();

        // Build a Context adapter once per frame — captures local references.
        BotAI.Context ctx = new BotAI.Context() {
            @Override public java.util.List<Bullet> getBullets()           { return bullets; }
            @Override public Player getLocalPlayer()                       { return localPlayer; }
            @Override public Map<Integer, Player> getRemote()              { return remote; }
            @Override public int    getDifficulty()                        { return difficulty; }
            @Override public int    getTick()                              { return tick; }
            @Override public float  getPlayerVelX()                        { return lpVelX; }
            @Override public float  getPlayerVelY()                        { return lpVelY; }
            @Override public float[][] getWalls()                          { return WALLS; }
            @Override public float[][] getNavWaypoints()                   { return navWaypoints; }
            @Override public boolean hasLos(float x1, float y1, float x2, float y2) {
                return GameView.this.hasLos(x1, y1, x2, y2);
            }
            @Override public void moveBotWithCollision(Player bot, float mx, float my, float spd, float dt2) {
                GameView.this.moveBotWithCollision(bot, mx, my, spd, dt2);
            }
            @Override public void spawnBotBullets(Player bot)              { spawnBullets(bot); }
            @Override public void doBotShopping(Player bot)                { GameView.this.doBotShopping(bot); }
            @Override public void doBotUseSkill(Player bot, Player lp2, float dist) {
                GameView.this.doBotUseSkill(bot, lp2, dist);
            }
            @Override public float[] findNavWaypoint(float bx, float by, float tx, float ty) {
                return GameView.this.findNavWaypoint(bx, by, tx, ty);
            }
        };

        for (Player bot : remote.values()) {
            if (!botIds.contains(bot.id) || !bot.alive) continue;
            botAI.update(bot, ctx, dt);
        }
    }

    /** Hard mode: bot spends coins on guns then skills. */
    private void doBotShopping(Player bot) {
        // ── Priority 1: buy the best gun this bot can afford ──────────────────
        // Iterate from most-expensive to cheapest
        // Bots prefer guns with long range first: Sniper(2100) > Plasma(1100) > Assault(900) > Burst(720) > Revolver(850) > LMG(750) > SMG(620) > Shotgun(220) > Minigun(420)
        int[] gunPriority = {4, 9, 3, 5, 7, 8, 1, 2, 6, 17};
        for (int i : gunPriority) {
            if (!bot.unlockedGuns[i] && bot.coins >= GUN_PRICES[i]) {
                bot.coins -= GUN_PRICES[i];
                // Drop any previously unlocked non-default gun to stay at 1 extra
                for (int j = 1; j < 7; j++) {
                    if (j != i && bot.unlockedGuns[j]) { bot.unlockedGuns[j] = false; break; }
                }
                bot.unlockedGuns[i] = true;
                bot.gunIndex = i;
                return;
            }
        }
        // ── Priority 2: passive fire rate upgrade ─────────────────────────────
        // (bots already have a starting active skill, so skip buying another)
        // ── Priority 3: upgrade passive fire rate then move speed ──────────────
        if (bot.skillFireRate < 3 && bot.coins >= PASSIVE_SKILL_COSTS[bot.skillFireRate]) {
            bot.coins -= PASSIVE_SKILL_COSTS[bot.skillFireRate];
            bot.skillFireRate++;
            return;
        }
        if (bot.skillMoveSpeed < 3 && bot.coins >= PASSIVE_SKILL_COSTS[bot.skillMoveSpeed]) {
            bot.coins -= PASSIVE_SKILL_COSTS[bot.skillMoveSpeed];
            bot.skillMoveSpeed++;
        }
    }

    /** Bot activates its skill when conditions are right. */
    private void doBotUseSkill(Player bot, Player lp, float dist) {
        if (bot.activeSkillType == Player.ACTIVE_NONE) return;
        if (bot.activeSkillType == Player.ACTIVE_STEALTH) return;  // bots don't stealth
        if (bot.activeSkillType == Player.ACTIVE_DASH) return;     // bots don't dash
        if (bot.skillOnCooldown()) return;
        long now = System.currentTimeMillis();
        Gun bg = bot.currentGun();
        float botRange = bg.range * bot.rangeMult();
        switch (bot.activeSkillType) {
            case Player.ACTIVE_HEAL:
                // Heal at 60 HP (not 45) so it's proactive, not last-resort
                if (bot.hp < 60) {
                    bot.hp = Math.min(100, bot.hp + 40);
                    bot.skillCooldownEnd = now + 12000;
                }
                break;
            case Player.ACTIVE_SHIELD:
                // Pop shield whenever health is moderate or player is in range
                if (bot.hp < 80 && !bot.isShielded()) {
                    bot.shieldHp = 60f;
                    bot.skillActiveUntil = now + 6000;
                    bot.skillCooldownEnd = now + 14000;
                }
                break;
            case Player.ACTIVE_STEALTH:
                // Go stealth whenever player has LOS on the bot (and not already stealthed)
                if (!bot.isStealthed() && hasLos(bot.x, bot.y, lp.x, lp.y)) {
                    bot.skillActiveUntil = now + 4000;
                    bot.skillCooldownEnd = now + 10000;
                }
                break;
            case Player.ACTIVE_DASH:
                float dashAngleBot = Float.NaN;
                if (bot.hp < 35) {
                    // Critically low HP -- dash away from player
                    dashAngleBot = (float) Math.atan2(bot.y - lp.y, bot.x - lp.x);
                } else if (dist > botRange * 1.6f && dist < botRange * 4f) {
                    // Out of range -- dash toward player to close the gap
                    dashAngleBot = (float) Math.atan2(lp.y - bot.y, lp.x - bot.x);
                }
                if (!Float.isNaN(dashAngleBot)) {
                    float[] botDashEnd = dashWithWallStop(bot.x, bot.y, dashAngleBot, 280f);
                    long ghostNow = System.currentTimeMillis();
                    float ghostDx = botDashEnd[0] - bot.x, ghostDy = botDashEnd[1] - bot.y;
                    float ghostLen = (float)Math.sqrt(ghostDx*ghostDx + ghostDy*ghostDy);
                    int numGhosts = Math.max(2, (int)(ghostLen / 32f));
                    for (int gi = 0; gi <= numGhosts; gi++) {
                        float t2 = (float)gi / numGhosts;
                        botDashGhosts.add(new float[]{
                            bot.x + ghostDx * t2,
                            bot.y + ghostDy * t2,
                            ghostNow - (long)(t2 * 60f)
                        });
                    }
                    // Store visual start for smooth render; logical position jumps immediately
                    botDashVisual.put(bot.id, new float[]{bot.x, bot.y, botDashEnd[0], botDashEnd[1], ghostNow});
                    bot.x = botDashEnd[0];
                    bot.y = botDashEnd[1];
                    bot.skillCooldownEnd = now + 6000;
                }
                break;
        }
    }

    /**
     * Steps along a dash from (startX,startY) in the given angle and returns the
     * last valid position before hitting a wall or the map boundary.
     * Uses the player radius (PR) so the circle never overlaps a wall.
     */
    private float[] dashWithWallStop(float startX, float startY, float angle, float maxDist) {
        // FIX: if player already clips a wall, nudge start clear so dash doesn't dead-stop
        for (float[] w : WALLS) {
            float csx = clamp(startX, w[0], w[2]);
            float csy = clamp(startY, w[1], w[3]);
            float dx = startX - csx, dy = startY - csy;
            if (dx*dx + dy*dy < (float)(PR*PR)) {
                startX = clamp(startX + (float)Math.cos(angle) * PR, PR, MAP_W - PR);
                startY = clamp(startY + (float)Math.sin(angle) * PR, PR, MAP_H - PR);
                break;
            }
        }
        final float STEP = 6f; // smaller step so thin walls (35px) are never tunnelled
        int steps = Math.max(1, (int)(maxDist / STEP));
        float lastX = startX, lastY = startY;
        for (int i = 1; i <= steps; i++) {
            float testX = startX + (float)Math.cos(angle) * STEP * i;
            float testY = startY + (float)Math.sin(angle) * STEP * i;
            testX = clamp(testX, PR, MAP_W - PR);
            testY = clamp(testY, PR, MAP_H - PR);
            // FIX: correct circle-vs-AABB check (same method as walls() movement function)
            boolean hit = false;
            for (float[] w : WALLS) {
                float cx = clamp(testX, w[0], w[2]);
                float cy = clamp(testY, w[1], w[3]);
                float ddx = testX - cx, ddy = testY - cy;
                if (ddx*ddx + ddy*ddy < (float)(PR*PR)) { hit = true; break; }
            }
            if (hit) break;
            lastX = testX; lastY = testY;
        }
        return new float[]{lastX, lastY};
    }

    /**
     * Checks line-of-sight by stepping along the segment in 25px increments.
     * Returns true if no wall blocks the path.
     */
    private boolean hasLos(float x1,float y1,float x2,float y2){
        float ddx=x2-x1, ddy=y2-y1;
        float dist=(float)Math.sqrt(ddx*ddx+ddy*ddy);
        int steps=Math.max(1,(int)(dist/25));
        float sx=ddx/steps, sy=ddy/steps;
        for(int i=1;i<steps;i++){
            float px=x1+sx*i, py=y1+sy*i;
            for(float[] w:WALLS)
                if(px>=w[0]&&px<=w[2]&&py>=w[1]&&py<=w[3]) return false;
        }
        return true;
    }

    /** Returns true if (x,y) is inside any wall (with player-radius margin). */
    private boolean inWall(float x,float y){
        for(float[] w:WALLS) if(x>=w[0]-PR&&x<=w[2]+PR&&y>=w[1]-PR&&y<=w[3]+PR) return true;
        return false;
    }

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    private void render(){
        Canvas c=getHolder().lockCanvas(); if(c==null) return;
        try{ doDraw(c); }finally{ getHolder().unlockCanvasAndPost(c); }
    }

    private void doDraw(Canvas c){
        c.drawRect(0,0,c.getWidth(),c.getHeight(),bgP);
        c.save();
        c.scale(currentZoom, currentZoom);   // per-weapon camera zoom
        c.translate(-camX,-camY);

        for(float x=0;x<=MAP_W;x+=120) c.drawLine(x,0,x,MAP_H,gridP);
        for(float y=0;y<=MAP_H;y+=120) c.drawLine(0,y,MAP_W,y,gridP);
        c.drawRect(0,0,MAP_W,MAP_H,bdrP);

        for(float[] w:WALLS) c.drawRect(w[0],w[1],w[2],w[3],wallP);

        // ── Explosion FX ────────────────────────────────────────────────────
        long nowMs=System.currentTimeMillis();
        Iterator<long[]> fxIt=explosionFx.iterator();
        while(fxIt.hasNext()){
            long[] fx=fxIt.next();
            float age=(nowMs-fx[2])/400f; // 0→1 over 400ms
            if(age>=1f){fxIt.remove();continue;}
            float r=120f*age;
            int alpha=(int)((1f-age)*200);
            Paint ep=fill(Color.argb(alpha,255,200,50));
            c.drawCircle(fx[0],fx[1],r,ep);
            Paint ep2=fill(Color.argb(alpha/2,255,100,0));
            c.drawCircle(fx[0],fx[1],r*0.5f,ep2);
        }

        // ── Client-side predicted hit flash (white burst, fades in 180 ms) ──
        Iterator<long[]> phIt=predictedHitFx.iterator();
        while(phIt.hasNext()){
            long[] ph=phIt.next();
            float phAge=(nowMs-ph[2])/180f;
            if(phAge>=1f){phIt.remove();continue;}
            float phR=PR*(0.6f+phAge*0.8f);
            int phA=(int)((1f-phAge)*220);
            c.drawCircle(ph[0],ph[1],phR,fill(Color.argb(phA,255,255,255)));
            c.drawCircle(ph[0],ph[1],phR*0.5f,fill(Color.argb(phA,255,220,100)));
        }

        // ── Hook Spear pull-phase ropes (world space) ────────────────────────
        drawPullRopes(c);

        for(Bullet b:bullets){
            if(b.homing){
                // missile: elongated orange oval in travel direction
                float a=(float)Math.atan2(b.dy,b.dx);
                c.save(); c.translate(b.x,b.y); c.rotate((float)Math.toDegrees(a));
                Paint mp=fill(0xFFFF6E40); c.drawOval(new RectF(-9,-4,9,4),mp);
                Paint mp2=fill(0xFFFFCC80); mp2.setTextSize(11); mp2.setTextAlign(Paint.Align.CENTER);
                c.drawText("🔺",0,4,mp2);
                c.restore();
            } else if(b.explosive){
                // blaster: glowing yellow circle with inner dot
                Paint ep=fill(Color.argb(180,255,215,0)); c.drawCircle(b.x,b.y,8f,ep);
                c.drawCircle(b.x,b.y,4f,fill(0xFFFFFF00));
            } else if(b.bouncesLeft>0 || (b.bouncesLeft==0&&b.spawnX!=b.x)){
                // bouncer: green circle
                c.drawCircle(b.x,b.y,6f,fill(0xFF69F0AE));
            } else if(b.piercing && b.isShadowBlade){
                // shadow blade: crimson elongated slash streak with glow
                float a=(float)Math.atan2(b.dy,b.dx);
                c.save(); c.translate(b.x,b.y); c.rotate((float)Math.toDegrees(a));
                // Outer glow
                Paint sbGlow=fill(Color.argb(80,255,30,80));
                c.drawOval(new android.graphics.RectF(-14,-5,14,5),sbGlow);
                // Main slash body
                Paint sbMain=fill(0xFFFF1744);
                c.drawOval(new android.graphics.RectF(-12,-2.5f,12,2.5f),sbMain);
                // Bright core
                c.drawRect(-8,-1f,8,1f,fill(0xFFFFCDD2));
                c.restore();
            } else if(b.piercing){
                // piercer: thin bright-blue elongated line
                float a=(float)Math.atan2(b.dy,b.dx);
                c.save(); c.translate(b.x,b.y); c.rotate((float)Math.toDegrees(a));
                c.drawRect(-10,-2,10,2,fill(0xFF40C4FF));
                c.restore();
            } else if(b.ghost){
                // ghost: semi-transparent purple circle
                c.drawCircle(b.x,b.y,5f,fill(Color.argb(160,234,128,252)));
            } else if(b.hookSpear){
                // ── Rope: catenary bezier from owner to spear tip ─────────────
                Player owner = (localPlayer!=null && b.ownerId==localPlayer.id)
                        ? localPlayer : remote.get(b.ownerId);
                float ox = (owner!=null) ? owner.x : b.spawnX;
                float oy = (owner!=null) ? owner.y : b.spawnY;
                drawRope(c, ox, oy, b.x, b.y);
                // ── Spear head ────────────────────────────────────────────────
                float a=(float)Math.atan2(b.dy,b.dx);
                c.save(); c.translate(b.x,b.y); c.rotate((float)Math.toDegrees(a));
                android.graphics.Path spearTip = new android.graphics.Path();
                spearTip.moveTo(14f, 0f); spearTip.lineTo(-2f, -5f); spearTip.lineTo(-2f, 5f); spearTip.close();
                c.drawPath(spearTip, fill(0xFFFFCC00));
                c.drawRect(-13f,-1.5f,-2f,1.5f,fill(0xFF8B5E20));
                c.restore();
            } else {
                c.drawCircle(b.x,b.y,5f,bulletP);
            }
        }

        // ── Shadow Blade slash trails ─────────────────────────────────────────
        {
            long nowSt = System.currentTimeMillis();
            Iterator<float[]> stIt = slashTrails.iterator();
            while (stIt.hasNext()) {
                float[] st = stIt.next();
                long age = nowSt - (long) st[4];
                final long SLASH_LIFE = 280L;
                if (age > SLASH_LIFE) { stIt.remove(); continue; }
                float frac = 1f - (float) age / SLASH_LIFE; // 1→0
                // st: [x1,y1,x2,y2,spawnMs,angle,slot]
                float x1=st[0], y1=st[1], x2=st[2], y2=st[3];
                float slashAngle = st[5];
                // Draw two parallel arcs perpendicular to slash direction
                float perpX = -(float)Math.sin(slashAngle);
                float perpY =  (float)Math.cos(slashAngle);
                float halfW = 9f * frac;
                // Outer crimson arc
                Paint slashOuter = new Paint(Paint.ANTI_ALIAS_FLAG);
                slashOuter.setStyle(Paint.Style.STROKE);
                slashOuter.setStrokeWidth(3.5f * frac);
                slashOuter.setColor(Color.argb((int)(200*frac), 255, 30, 70));
                c.drawLine(x1 + perpX*halfW, y1 + perpY*halfW,
                           x2 + perpX*halfW, y2 + perpY*halfW, slashOuter);
                c.drawLine(x1 - perpX*halfW, y1 - perpY*halfW,
                           x2 - perpX*halfW, y2 - perpY*halfW, slashOuter);
                // Inner bright white core
                Paint slashCore = new Paint(Paint.ANTI_ALIAS_FLAG);
                slashCore.setStyle(Paint.Style.STROKE);
                slashCore.setStrokeWidth(2f * frac);
                slashCore.setColor(Color.argb((int)(230*frac), 255, 200, 210));
                c.drawLine(x1, y1, x2, y2, slashCore);
            }
        }

        // ── Dash aftereffect ghosts (drawn below the player) ──────────────────
        long nowGhostDraw = System.currentTimeMillis();
        {
            Iterator<float[]> git = dashGhosts.iterator();
            while (git.hasNext()) {
                float[] ghost = git.next();
                long age = nowGhostDraw - (long) ghost[2];
                if (age < 0 || age > GHOST_LIFE_MS) { git.remove(); continue; }
                float frac  = (float) age / GHOST_LIFE_MS;
                float alpha = 1f - frac;              // 1 → 0 as ghost ages
                float scale = 1f - frac * 0.35f;     // shrinks slightly

                // Inner glow fill
                Paint gFill = new Paint(Paint.ANTI_ALIAS_FLAG);
                gFill.setStyle(Paint.Style.FILL);
                gFill.setColor(Color.argb((int)(100 * alpha), 80, 200, 255));
                c.drawCircle(ghost[0], ghost[1], PR * scale, gFill);

                // Bright cyan ring
                Paint gRing = new Paint(Paint.ANTI_ALIAS_FLAG);
                gRing.setStyle(Paint.Style.STROKE);
                gRing.setStrokeWidth(3.5f * alpha);
                gRing.setColor(Color.argb((int)(230 * alpha), 140, 230, 255));
                c.drawCircle(ghost[0], ghost[1], PR * scale, gRing);

                // Speed-streak line from ghost toward dash end point (first ghost only)
                if (frac < 0.15f && dashGhosts.size() > 1) {
                    Paint streak = new Paint(Paint.ANTI_ALIAS_FLAG);
                    streak.setStyle(Paint.Style.STROKE);
                    streak.setStrokeWidth(2f * alpha);
                    streak.setColor(Color.argb((int)(160 * alpha), 100, 210, 255));
                    streak.setPathEffect(new android.graphics.DashPathEffect(new float[]{10f, 6f}, 0f));
                    c.drawLine(ghost[0], ghost[1], dashAnimEndX, dashAnimEndY, streak);
                }
            }
        }
        // ── Bot dash afterimage ghosts (orange/red, drawn below bots) ──────────
        {
            long nowBotGhost = System.currentTimeMillis();
            Iterator<float[]> bgit = botDashGhosts.iterator();
            while (bgit.hasNext()) {
                float[] ghost = bgit.next();
                long age = nowBotGhost - (long) ghost[2];
                if (age < 0 || age > GHOST_LIFE_MS) { bgit.remove(); continue; }
                float frac  = (float) age / GHOST_LIFE_MS;
                float alpha = 1f - frac;
                float scale = 1f - frac * 0.35f;

                // Inner orange glow
                Paint bgFill = new Paint(Paint.ANTI_ALIAS_FLAG);
                bgFill.setStyle(Paint.Style.FILL);
                bgFill.setColor(Color.argb((int)(110 * alpha), 255, 120, 30));
                c.drawCircle(ghost[0], ghost[1], PR * scale, bgFill);

                // Bright orange-red ring
                Paint bgRing = new Paint(Paint.ANTI_ALIAS_FLAG);
                bgRing.setStyle(Paint.Style.STROKE);
                bgRing.setStrokeWidth(3.5f * alpha);
                bgRing.setColor(Color.argb((int)(230 * alpha), 255, 80, 0));
                c.drawCircle(ghost[0], ghost[1], PR * scale, bgRing);
            }
        }
        for(Player p:remote.values()) drawPlayer(c,p,false);
        Player lp=localPlayer;
        if(lp!=null) drawPlayer(c,lp,true);

        // Aim line (world-space dashed line) — hidden while a hook spear is in flight
        boolean hookInFlight = false;
        if (lp != null) { for (Bullet b : bullets) { if (b.hookSpear && b.ownerId == lp.id) { hookInFlight = true; break; } } }
        if(lp!=null && lp.alive && !hookInFlight && cachedAimLine){
            float lineLen = 350f;
            float ex = lp.x + (float)Math.cos(lp.angle) * lineLen;
            float ey = lp.y + (float)Math.sin(lp.angle) * lineLen;
            Paint aimLineP = new Paint(Paint.ANTI_ALIAS_FLAG);
            aimLineP.setColor(Color.argb(160,255,255,255));
            aimLineP.setStyle(Paint.Style.STROKE);
            aimLineP.setStrokeWidth(2.5f);
            aimLineP.setPathEffect(new android.graphics.DashPathEffect(new float[]{18f,10f},0f));
            c.drawLine(lp.x,lp.y,ex,ey,aimLineP);
        }

        // Draw active bombs (world space)
        long nowDraw = System.currentTimeMillis();
        for (Bomb bomb : activeBombs) {
            if (bomb.isFlashing()) {
                // (explosion circle removed)
            } else if (bomb.explodedAt < 0) {
                float fuse = (nowDraw - bomb.deployTime) / (float) Bomb.FUSE_MS;
                if (!bomb.hasLanded) {
                    // ── Flying: draw a shadow + emoji to indicate arc ─────────
                    // Shadow grows as bomb approaches max range (shows distance)
                    float travel = (float)Math.sqrt(bomb.traveledSq()) / Bomb.THROW_RANGE;
                    float shadowR = 8f + 22f * travel;
                    Paint shadowP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    shadowP.setStyle(Paint.Style.FILL);
                    shadowP.setColor(Color.argb((int)(120 * (1f - travel * 0.5f)), 0, 0, 0));
                    c.drawCircle(bomb.x, bomb.y, shadowR, shadowP);
                    // Emoji slightly offset upward to simulate height
                    Paint flyP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    flyP.setTextSize(34f); flyP.setTextAlign(Paint.Align.CENTER);
                    float bounce = -(float)Math.sin(travel * Math.PI) * 40f;
                    c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + bounce + 12f, flyP);
                } else {
                    // ── Landed: emoji only (danger ring removed) ────────────────────
                    Paint bombEmojiP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    bombEmojiP.setTextSize(32f); bombEmojiP.setTextAlign(Paint.Align.CENTER);
                    c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + 12f, bombEmojiP);
                }
            }
        }

        // ── Air Strike ring + orb (joystick-mag maps to target distance) ─────
        if (lp != null && lp.alive && lp.currentGun().bulletAirStrike) {
            boolean aimActive = aimStick != null && aimStick.isActive();
            boolean hasAngle  = !Float.isNaN(asAimAngle);
            boolean reloading = lp.currentGun().reloading;
            if (reloading) {
                // Show greyed-out ring + RELOADING label to signal aim is locked
                Paint ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
                ringP.setStyle(Paint.Style.STROKE); ringP.setStrokeWidth(3f);
                ringP.setColor(Color.argb(80, 180, 180, 180));
                c.drawCircle(lp.x, lp.y, AS_RING_R, ringP);
                Paint lblP = new Paint(Paint.ANTI_ALIAS_FLAG);
                lblP.setColor(Color.argb(200, 220, 100, 100));
                lblP.setTextSize(36f); lblP.setTextAlign(Paint.Align.CENTER);
                c.drawText("RELOADING — CAN'T AIM", lp.x, lp.y - AS_RING_R - 20f, lblP);
            } else if (aimActive && hasAngle) {
                float ringR = AS_RING_R; // fixed size, no pulse

                // Big ring around player
                Paint ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
                ringP.setStyle(Paint.Style.STROKE);
                ringP.setStrokeWidth(3f);
                ringP.setColor(Color.argb(180, 224, 64, 251));
                c.drawCircle(lp.x, lp.y, ringR, ringP);
                c.drawCircle(lp.x, lp.y, ringR, fill(Color.argb(18, 224, 64, 251)));

                // Small orb: distance = asAimMag * ring radius (joystick center = at player)
                float orbDist = asAimMag * ringR;
                float orbX = lp.x + (float)Math.cos(asAimAngle) * orbDist;
                float orbY = lp.y + (float)Math.sin(asAimAngle) * orbDist;
                float ORB_R = 26f;

                // Glow + body + dot
                c.drawCircle(orbX, orbY, ORB_R * 1.7f, fill(Color.argb(70, 224, 64, 251)));
                c.drawCircle(orbX, orbY, ORB_R,         fill(Color.argb(230, 224, 64, 251)));
                c.drawCircle(orbX, orbY, ORB_R * 0.38f, fill(Color.WHITE));

                // Dashed connector: player to orb
                Paint connP = new Paint(Paint.ANTI_ALIAS_FLAG);
                connP.setColor(Color.argb(110, 224, 64, 251));
                connP.setStrokeWidth(2f);
                connP.setPathEffect(new android.graphics.DashPathEffect(new float[]{10f,6f},0f));
                c.drawLine(lp.x, lp.y, orbX, orbY, connP);

                // Strike zone preview: circle showing explosion radius
                float zoneR = AS_RADIUS * 0.75f; // smaller preview circle
                Paint prevP = new Paint(Paint.ANTI_ALIAS_FLAG);
                prevP.setStyle(Paint.Style.STROKE); prevP.setStrokeWidth(3f);
                prevP.setColor(Color.argb(160, 255, 200, 50));
                c.drawCircle(orbX, orbY, zoneR, prevP);
                c.drawCircle(orbX, orbY, zoneR, fill(Color.argb(25, 255, 200, 50)));
                // Center crosshair on orb
                Paint xhP = new Paint(Paint.ANTI_ALIAS_FLAG);
                xhP.setColor(Color.argb(200, 255, 200, 50)); xhP.setStrokeWidth(2.5f);
                c.drawLine(orbX - 16, orbY, orbX + 16, orbY, xhP);
                c.drawLine(orbX, orbY - 16, orbX, orbY + 16, xhP);
            }
        }

        // Draw Air Strike targets and explosions (world space)
        long asNow = System.currentTimeMillis();
        for (double[] as : airStrikes) {
            float sx = (float) as[0], sy = (float) as[1];
            long trigMs = (long) as[2];
            long flashUntil = (long) as[4];
            boolean exploding = flashUntil > 0L && asNow < flashUntil;
            boolean pending   = asNow < trigMs;

            if (exploding) {
                // Explosion burst: bright purple ring + inner flash
                float progress = 1f - (flashUntil - asNow) / (float) AS_FLASH_MS;
                float er = AS_RADIUS * (0.4f + progress * 0.6f);
                int alpha = (int)(255 * (1f - progress));
                Paint exFill = fill(Color.argb(alpha / 3, 230, 80, 255));
                c.drawCircle(sx, sy, er, exFill);
                Paint exRing = new Paint(Paint.ANTI_ALIAS_FLAG);
                exRing.setStyle(Paint.Style.STROKE); exRing.setStrokeWidth(5f);
                exRing.setColor(Color.argb(alpha, 255, 100, 255));
                c.drawCircle(sx, sy, er, exRing);
                // Emoji
                Paint exEmoji = new Paint(Paint.ANTI_ALIAS_FLAG);
                exEmoji.setTextSize(36f); exEmoji.setTextAlign(Paint.Align.CENTER);
                c.drawText("💥", sx, sy + 14f, exEmoji);
            } else if (pending) {
                // Incoming warning: fixed danger ring visible to all players
                float countdown = Math.max(0f, (trigMs - asNow) / (float) AS_WARNING_MS);
                int ra = (int)(220 * (1f - countdown * 0.4f));
                // Outer danger ring (fixed size)
                Paint dangerRing = new Paint(Paint.ANTI_ALIAS_FLAG);
                dangerRing.setStyle(Paint.Style.STROKE); dangerRing.setStrokeWidth(4f);
                dangerRing.setColor(Color.argb(ra, 255, 50, 50));
                c.drawCircle(sx, sy, AS_RADIUS, dangerRing);
                // Danger fill (gets brighter as time runs out)
                c.drawCircle(sx, sy, AS_RADIUS, fill(Color.argb((int)(ra * 0.18f), 255, 50, 50)));
                // Warning text above
                Paint warnP = new Paint(Paint.ANTI_ALIAS_FLAG);
                warnP.setTextSize(22f); warnP.setTextAlign(Paint.Align.CENTER);
                warnP.setColor(Color.argb(ra, 255, 80, 80));
                c.drawText("⚠", sx, sy - AS_RADIUS - 8f, warnP);
                // Inner crosshair
                Paint cross = new Paint(Paint.ANTI_ALIAS_FLAG);
                cross.setColor(Color.argb(ra, 255, 100, 100)); cross.setStrokeWidth(2f);
                c.drawLine(sx - 12, sy, sx + 12, sy, cross);
                c.drawLine(sx, sy - 12, sx, sy + 12, cross);
            }
        }
        // ── Throw preview arc (world space) ──────────────────────────────────
        if (throwingBomb && lp != null && lp.alive && aimStick != null) {
            float tax = aimStick.getX(), tay = aimStick.getY();
            float tmag = (float) Math.sqrt(tax * tax + tay * tay);
            if (tmag > 0.08f) {
                float landX = lp.x + tax * Bomb.THROW_RANGE;
                float landY = lp.y + tay * Bomb.THROW_RANGE;
                // Dashed trajectory line
                Paint arcP = new Paint(Paint.ANTI_ALIAS_FLAG);
                arcP.setColor(Color.argb(210, 255, 210, 0));
                arcP.setStyle(Paint.Style.STROKE);
                arcP.setStrokeWidth(3.5f);
                arcP.setPathEffect(new android.graphics.DashPathEffect(new float[]{16f, 10f}, 0f));
                c.drawLine(lp.x, lp.y, landX, landY, arcP);
                // (blast radius preview circles removed)
                // Landing bullseye
                Paint dotP = new Paint(Paint.ANTI_ALIAS_FLAG);
                dotP.setColor(Color.argb(230, 255, 220, 0));
                dotP.setStyle(Paint.Style.FILL);
                c.drawCircle(landX, landY, 10f, dotP);
            }
        }

        c.restore();

        drawHUD(c);
    }

    private void drawPlayer(Canvas c, Player p, boolean local){
        // Resolve render position — bots use a visual-only dash interpolation
        float rx = p.x, ry = p.y;
        if (!local) {
            float[] bv = botDashVisual.get(p.id);
            if (bv != null) {
                float bt = Math.min(1f, (float)(System.currentTimeMillis() - (long)bv[4]) / DASH_ANIM_MS);
                float ease = 1f - (1f - bt) * (1f - bt) * (1f - bt);
                rx = bv[0] + (bv[2] - bv[0]) * ease;
                ry = bv[1] + (bv[3] - bv[1]) * ease;
            }
        }
        if(!p.alive){
            Paint xp=new Paint(Paint.ANTI_ALIAS_FLAG);
            xp.setColor(Color.argb(160,230,50,50)); xp.setStyle(Paint.Style.STROKE); xp.setStrokeWidth(4f);
            c.drawLine(rx-13,ry-13,rx+13,ry+13,xp);
            c.drawLine(rx+13,ry-13,rx-13,ry+13,xp); return;
        }
        // Stealth: remote players are invisible (skip draw); local is translucent
        if (!local && p.isStealthed()) return;
        int stealthAlpha = (local && p.isStealthed()) ? 100 : 255;
        float r=PR;
        Paint shadowP2 = new Paint(shP); shadowP2.setAlpha(stealthAlpha*65/255);
        c.drawCircle(rx+4,ry+4,r,shadowP2);
        // Dummies: grey body, no gun line, different name style
        boolean isDummy = dummyIds.contains(p.id);
        Paint bodyP = isDummy ? fill(Color.rgb(140,140,140)) : (local ? new Paint(locP) : new Paint(remP));
        bodyP.setAlpha(stealthAlpha);
        c.drawCircle(rx,ry,r,bodyP);
        if (!isDummy) {
            float gl=r+20f;
            Paint gp=new Paint(Paint.ANTI_ALIAS_FLAG);
            int barrelCol = p.currentGun().color;
            gp.setColor(barrelCol); gp.setAlpha(stealthAlpha);
            gp.setStyle(Paint.Style.STROKE); gp.setStrokeWidth(7f); gp.setStrokeCap(Paint.Cap.ROUND);
            c.drawLine(rx,ry,rx+(float)Math.cos(p.angle)*gl,ry+(float)Math.sin(p.angle)*gl,gp);
        }
        float bw=50f,bh=6f,bx=rx-25f,by=ry-r-14f;
        c.drawRoundRect(bx,by,bx+bw,by+bh,3,3,hpBgP);
        float fr=Math.max(0,p.hp/100f);
        Paint hpP=new Paint(Paint.ANTI_ALIAS_FLAG); hpP.setStyle(Paint.Style.FILL);
        hpP.setColor(fr>0.5f?Color.rgb(50,220,50):fr>0.25f?Color.rgb(240,175,0):Color.rgb(230,50,50));
        c.drawRoundRect(bx,by,bx+bw*fr,by+bh,3,3,hpP);
        Paint nameP2 = new Paint(nameP); nameP2.setAlpha(stealthAlpha);
        if (isDummy) {
            nameP2.setColor(Color.argb(180, 180, 180, 180));
            nameP2.setTypeface(Typeface.defaultFromStyle(Typeface.ITALIC));
        }
        c.drawText(p.name, rx, ry-r-17f, nameP2);
        // Volt Chakram charge arc — drawn around the player when charging
        if (local && isVoltChakram(p.currentGun()) && voltCharge > 0.02f) {
            float sweep = voltCharge * 360f;
            Paint chargePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            chargePaint.setStyle(Paint.Style.STROKE);
            chargePaint.setStrokeWidth(4.5f);
            int chargeAlpha = (int)(180 + voltCharge * 75);
            chargePaint.setColor(Color.argb(chargeAlpha, 100, 220, 255));
            float arcR = r + 14f;
            RectF arcRect = new RectF(rx - arcR, ry - arcR, rx + arcR, ry + arcR);
            c.drawArc(arcRect, -90f, sweep, false, chargePaint);
            // Bright tip dot at the leading edge
            float tipAngle = (float) Math.toRadians(-90f + sweep);
            float tipX = rx + arcR * (float) Math.cos(tipAngle);
            float tipY = ry + arcR * (float) Math.sin(tipAngle);
            Paint tipPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
            tipPaint.setStyle(Paint.Style.FILL);
            tipPaint.setColor(Color.argb(230, 180, 240, 255));
            c.drawCircle(tipX, tipY, 5f, tipPaint);
        }
        // Shadow Blade charge arc — crimson arc that fills as blade charges
        if (local && isShadowBlade(p.currentGun()) && shadowBladeCharge > 0.02f) {
            float sweep = shadowBladeCharge * 360f;
            long nowSb = System.currentTimeMillis();
            float pulse = 0.7f + 0.3f * (float) Math.abs(Math.sin(nowSb / 120.0));
            Paint sbCharge = new Paint(Paint.ANTI_ALIAS_FLAG);
            sbCharge.setStyle(Paint.Style.STROKE);
            sbCharge.setStrokeWidth(4.5f * pulse);
            int sbAlpha = (int)(170 + shadowBladeCharge * 85);
            sbCharge.setColor(Color.argb(sbAlpha, 255, 30, 70));
            float sbArcR = r + 14f;
            RectF sbRect = new RectF(rx - sbArcR, ry - sbArcR, rx + sbArcR, ry + sbArcR);
            c.drawArc(sbRect, -90f, sweep, false, sbCharge);
            // Flare at full charge
            if (shadowBladeCharge >= 0.75f) {
                Paint flare = new Paint(Paint.ANTI_ALIAS_FLAG);
                flare.setStyle(Paint.Style.FILL);
                flare.setColor(Color.argb((int)(120 * pulse), 255, 80, 100));
                c.drawCircle(rx, ry, sbArcR + 6f * pulse, flare);
            }
            // Bright tip
            float sbTipAngle = (float) Math.toRadians(-90f + sweep);
            float sbTipX = rx + sbArcR * (float) Math.cos(sbTipAngle);
            float sbTipY = ry + sbArcR * (float) Math.sin(sbTipAngle);
            Paint sbTip = new Paint(Paint.ANTI_ALIAS_FLAG);
            sbTip.setStyle(Paint.Style.FILL);
            sbTip.setColor(Color.argb(235, 255, 200, 210));
            c.drawCircle(sbTipX, sbTipY, 5f * pulse, sbTip);
        }
        // Spawn protection ring
        if (p.isProtected()) {
            long rem = p.spawnProtectionUntil - System.currentTimeMillis();
            float pulse = 0.7f+0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
            Paint protP = new Paint(Paint.ANTI_ALIAS_FLAG);
            protP.setStyle(Paint.Style.STROKE); protP.setStrokeWidth(4f*pulse);
            protP.setColor(Color.argb(Math.min(255,(int)(200*rem/800f)),100,200,255));
            c.drawCircle(rx,ry,(r+10)*pulse,protP);
        }
        // Shield ring
        if (p.isShielded()) {
            float pulse2 = 0.8f+0.2f*(float)Math.abs(Math.sin(System.currentTimeMillis()/150.0));
            Paint shP2 = new Paint(Paint.ANTI_ALIAS_FLAG);
            shP2.setStyle(Paint.Style.STROKE); shP2.setStrokeWidth(5f);
            shP2.setColor(Color.argb(200,255,200,0));
            c.drawCircle(rx,ry,(r+14)*pulse2,shP2);
        }
        // Slow ring (blue ice crystals)
        if (p.isSlowed()) {
            float pulse3 = 0.85f+0.15f*(float)Math.abs(Math.sin(System.currentTimeMillis()/250.0));
            Paint slowP = new Paint(Paint.ANTI_ALIAS_FLAG);
            slowP.setStyle(Paint.Style.STROKE); slowP.setStrokeWidth(4f);
            slowP.setColor(Color.argb(210,40,160,255));
            c.drawCircle(rx,ry,(r+18)*pulse3,slowP);
            // small "❄" label
            Paint iceP=new Paint(Paint.ANTI_ALIAS_FLAG); iceP.setTextSize(14f); iceP.setTextAlign(Paint.Align.CENTER);
            c.drawText("❄",rx,ry-r-30f,iceP);
        }
        // Poison ring (green dots)
        if (p.isPoisoned()) {
            float pulse4 = 0.85f+0.15f*(float)Math.abs(Math.sin(System.currentTimeMillis()/180.0));
            Paint poisP = new Paint(Paint.ANTI_ALIAS_FLAG);
            poisP.setStyle(Paint.Style.STROKE); poisP.setStrokeWidth(4f);
            poisP.setColor(Color.argb(210,50,210,80));
            c.drawCircle(rx,ry,(r+22)*pulse4,poisP);
            Paint dotP = new Paint(Paint.ANTI_ALIAS_FLAG); dotP.setStyle(Paint.Style.FILL);
            dotP.setColor(Color.argb(200,80,240,100));
            float dotR=4f, orbit=(r+22)*pulse4;
            long t2=System.currentTimeMillis();
            for(int d=0;d<4;d++){
                float da=(float)(t2/600.0 + d*Math.PI/2);
                c.drawCircle(rx+(float)Math.cos(da)*orbit, ry+(float)Math.sin(da)*orbit, dotR, dotP);
            }
        }
        // Stun ring (yellow spinning ★ stars)
        if (p.isStunned() || p.isBeingPulled()) {
            Paint stunP = new Paint(Paint.ANTI_ALIAS_FLAG);
            stunP.setStyle(Paint.Style.STROKE); stunP.setStrokeWidth(3f);
            stunP.setColor(Color.argb(220,255,230,0));
            float stunR = r + 26f;
            c.drawCircle(rx, ry, stunR, stunP);
            Paint starP = new Paint(Paint.ANTI_ALIAS_FLAG);
            starP.setTextSize(13f); starP.setTextAlign(Paint.Align.CENTER);
            long tnow = System.currentTimeMillis();
            for (int s = 0; s < 3; s++) {
                float sa = (float)(tnow/400.0 + s * Math.PI * 2 / 3);
                c.drawText("★", rx+(float)Math.cos(sa)*stunR, ry+(float)Math.sin(sa)*stunR+5f, starP);
            }
        }
    }

    private void drawHUD(Canvas c){
        Player lp=localPlayer;
        // Show connecting screen while waiting for server response (client only)
        if(lp==null){
            if(!isHost){
                float w=screenW, h=screenH;
                c.drawRect(0,0,w,h,fill(Color.argb(180,0,0,0)));
                Paint tp=fill(Color.WHITE); tp.setTextSize(32f); tp.setTextAlign(Paint.Align.CENTER);
                tp.setTypeface(Typeface.DEFAULT_BOLD); tp.setShadowLayer(4f,0,2f,Color.BLACK);
                c.drawText("Connecting to host…", w/2, h/2-20, tp);
                Paint tp2=fill(Color.argb(200,180,210,255)); tp2.setTextSize(18f); tp2.setTextAlign(Paint.Align.CENTER);
                c.drawText("Make sure you're on the host's hotspot", w/2, h/2+24, tp2);
            }
            return;
        }
        float w=screenW, h=screenH;

        // ── HP ────────────────────────────────────────────────────────────────
        c.drawRoundRect(10,10,215,56,8,8,hudBgP);
        hudP.setColor(Color.rgb(255,75,75)); hudP.setTextSize(27f); hudP.setTextAlign(Paint.Align.LEFT);
        c.drawText("♥ "+(int)Math.ceil(lp.hp), 22, 46, hudP);

        // ── Coins ─────────────────────────────────────────────────────────────
        c.drawRoundRect(222,10,355,56,8,8,hudBgP);
        Paint coinP2=fill(Color.rgb(255,210,50)); coinP2.setTextSize(22f);
        coinP2.setTextAlign(Paint.Align.LEFT); coinP2.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("\uD83D\uDCB0 "+lp.coins, 234, 44, coinP2);

        // ── Difficulty / mode badge ────────────────────────────────────────────
        if (singlePlayer) {
            String dlbl;
            int    dcol;
            if (trainingMode) {
                dlbl = "TRAINING"; dcol = 0xFF22aa66;
            } else {
                String[] diffLabels = {"EASY", "NORMAL", "HARD"};
                int[]    diffColors = {0xFF2ecc71, 0xFFe94560, 0xFF8855ee};
                dlbl = diffLabels[Math.max(0, Math.min(2, difficulty))];
                dcol = diffColors[Math.max(0, Math.min(2, difficulty))];
            }
            Paint diffP = fill(dcol); diffP.setTextSize(17f);
            diffP.setTextAlign(Paint.Align.LEFT); diffP.setTypeface(Typeface.DEFAULT_BOLD);
            diffP.setShadowLayer(3f,1f,1f,Color.BLACK);
            float dlblW = diffP.measureText(dlbl);
            c.drawRoundRect(362, 14, 362 + dlblW + 18, 52, 8, 8, fill(Color.argb(140,0,0,0)));
            c.drawText(dlbl, 371, 43, diffP);
        }

        // ── Gun + ammo ────────────────────────────────────────────────────────
        if(lp.alive){
            Gun g=lp.currentGun();
            String ammoStr = g.reloading ? "RELOADING…" : (g.ammo+"/"+g.maxAmmo);
            // Background panel – taller to fit stat bars when shown
            boolean showGunStats = cachedGunStats;
            c.drawRoundRect(w/2-195,6,w/2+195,showGunStats?106:52,10,10,hudBgP);
            // Gun name + ammo
            gunTxtP.setColor(g.color);
            c.drawText(g.name+"   "+ammoStr, w/2, 36, gunTxtP);
            // Soul Reaper: show tier and kill progress
            if (lp.gunIndex == 20) {
                int lv = g.soulLevel();
                int next = g.soulNextThreshold();
                String[] tierNames = {"☠ DORMANT","☠ TIER I","☠ TIER II","☠ TIER III","☠ TIER IV","☠ TIER V — FULL POWER"};
                String soulLine = tierNames[lv] + (next >= 0 ? "   (" + g.killCount + "/" + next + " kills)" : "");
                Paint soulP = new Paint(Paint.ANTI_ALIAS_FLAG);
                soulP.setTextSize(15f); soulP.setTextAlign(Paint.Align.CENTER);
                int[] tierColors = {0xFF9E9E9E,0xFFCE93D8,0xFFBA68C8,0xFFAB47BC,0xFF8E24AA,0xFF6A0080};
                soulP.setColor(tierColors[lv]);
                c.drawText(soulLine, w/2f, 50f, soulP);
            }
            // Stat bars: DMG | SPD | RANGE | RATE
            if(showGunStats){
            String[] statNames = {"DMG","SPD","RANGE","RATE"};
            float[]  statVals  = {g.statDamage(), g.statSpeed(), g.statRange(), g.statFireRate()};
            int[]    statColors= {0xFFFF5252, 0xFF64B5F6, 0xFF81C784, 0xFFFFD54F};
            float barW=68f, barH=9f, gap=10f;
            float totalW = statNames.length*(barW+gap)-gap;
            float barX = w/2 - totalW/2;
            float barY = 55f;
            Paint statLblP = new Paint(Paint.ANTI_ALIAS_FLAG);
            statLblP.setTextSize(13f); statLblP.setTextAlign(Paint.Align.LEFT);
            statLblP.setColor(Color.argb(180,200,220,255));
            Paint statBgP  = fill(Color.argb(80,255,255,255));
            for(int si=0;si<statNames.length;si++){
                float sx = barX + si*(barW+gap);
                c.drawRoundRect(sx,barY, sx+barW,barY+barH, 4,4, statBgP);
                Paint fp=fill(statColors[si]);
                c.drawRoundRect(sx,barY, sx+barW*statVals[si],barY+barH, 4,4, fp);
                c.drawText(statNames[si], sx, barY+barH+14f, statLblP);
            }
            }
        }

        // ── HOST: show IP so others can join ──────────────────────────────────
        if(isHost && !hostIpDisplay.isEmpty()){
            int count=remote.size()+1;
            String ipLine="Your IP: "+hostIpDisplay+"   Players: "+count;
            float bgW=ipPaint.measureText(ipLine)+24f;
            c.drawRoundRect(w/2-bgW/2,h-52,w/2+bgW/2,h-4,10,10,hudBgP);
            c.drawText(ipLine, w/2, h-14, ipPaint);
        }

        // ── Kill feed ─────────────────────────────────────────────────────────
        hudP.setColor(Color.rgb(255,210,70)); hudP.setTextSize(18f); hudP.setTextAlign(Paint.Align.LEFT);
        synchronized(feed){ for(int i=0;i<feed.size();i++) c.drawText(feed.get(i),12,72+i*24,hudP); }

        // ── Disconnect overlay ─────────────────────────────────────────────────
        if(!singlePlayer && !isHost && net!=null && net.isDisconnected()){
            // Pulsing amber banner across the top
            long now2=System.currentTimeMillis();
            int pulse=(int)(180+75*Math.abs(Math.sin(now2/500.0)));
            Paint discBg=fill(Color.argb(Math.min(255,pulse),120,40,0));
            c.drawRoundRect(w*0.1f,14,w*0.9f,66,12,12,discBg);
            Paint discTxt=new Paint(Paint.ANTI_ALIAS_FLAG);
            discTxt.setColor(Color.WHITE); discTxt.setTextSize(22f);
            discTxt.setTextAlign(Paint.Align.CENTER);
            discTxt.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            discTxt.setShadowLayer(4f,0,1f,Color.BLACK);
            c.drawText("\u26A0 DISCONNECTED \u2014 Reconnecting\u2026",w/2,48,discTxt);
        }

        // ── Death overlay ─────────────────────────────────────────────────────
        if(!lp.alive){
            c.drawRect(0,0,w,h,deathBgP);
            c.drawText("YOU DIED",w/2,h/2-18,deathTxtP);
            long rem=RESPAWN_MS-(System.currentTimeMillis()-deathTime);
            if(rem>0){
                Paint t2=new Paint(deathTxtP); t2.setTextSize(28f); t2.setColor(Color.WHITE);
                t2.setTextAlign(Paint.Align.CENTER);
                c.drawText("Respawning in "+(rem/1000+1)+"s",w/2,h/2+38,t2);
            }
        }

        // ── Buttons ───────────────────────────────────────────────────────────
        // Weapon wheel — drawn as a circle with just the gear icon
        { float _scx=switchRect.centerX(), _scy=switchRect.centerY(), _sr=switchRect.width()/2f;
          c.drawCircle(_scx, _scy, _sr, btnP);
          Paint _gp = new Paint(btnTxtP); _gp.setTextSize(_sr * 0.70f);
          c.drawText("⚙", _scx, _scy + _sr*0.25f, _gp); }
        // Reload button — greyed-out/locked when the air strike gun (no reload) is equipped
        { boolean asLocked = lp != null && lp.currentGun().bulletAirStrike;
          if (asLocked) {
              Paint lockedP = fill(Color.argb(70, 55, 55, 65));
              c.drawRoundRect(reloadRect, 10, 10, lockedP);
              Paint lockIconP = new Paint(btnTxtP); lockIconP.setColor(Color.argb(110, 190, 190, 190));
              lockIconP.setTextSize(btnTxtP.getTextSize() * 1.05f);
              c.drawText("\uD83D\uDD12", reloadRect.centerX(), reloadRect.centerY() + 8f, lockIconP);
          } else {
              c.drawRoundRect(reloadRect, 10, 10, btnP);
              c.drawText("RELOAD", reloadRect.centerX(), reloadRect.centerY() + 8, btnTxtP);
          }
        }
        // Bomb button
        if (bombRect != null && lp != null) {
            boolean hasBombs = lp.bombs > 0;
            Paint bombBtnP;
            String bombLabel;
            if (throwingBomb) {
                bombBtnP = fill(Color.argb(230, 220, 160, 0));  // glowing amber = aiming
                bombLabel = "CANCEL";
            } else {
                bombBtnP = fill(hasBombs ? Color.argb(210,160,60,0) : Color.argb(120,60,60,60));
                bombLabel = "\uD83D\uDCA3 " + lp.bombs;
            }
            c.drawRoundRect(bombRect, 10, 10, bombBtnP);
            c.drawText(bombLabel, bombRect.centerX(), bombRect.centerY() + 8, btnTxtP);
            // "AIM & RELEASE" hint while in throw mode
            if (throwingBomb) {
                Paint hintP = fill(Color.argb(200, 255, 230, 100));
                hintP.setTextSize(16f); hintP.setTextAlign(Paint.Align.CENTER);
                hintP.setShadowLayer(3f, 0, 1f, Color.BLACK);
                c.drawText("aim joystick \u2192 release", bombRect.centerX(), bombRect.top - 8f, hintP);
            }
        }
        // Drop weapon button
        if (dropRect != null && lp != null) {
            int unlockedCount = 0;
            for (boolean u : lp.unlockedGuns) if (u) unlockedCount++;
            boolean canDrop = unlockedCount > 1;
            Paint dropBtnP = fill(canDrop ? Color.argb(200,140,40,40) : Color.argb(80,60,60,60));
            c.drawRoundRect(dropRect, 10, 10, dropBtnP);
            c.drawText("DROP GUN", dropRect.centerX(), dropRect.centerY() + 8, btnTxtP);
        }

        // Active skill button
        if (skillRect != null && lp != null) {
            drawSkillButton(c, lp);
        }

        // Spawn protection pulsing shield ring (screen-space around player circle)
        if (lp != null && lp.alive && lp.isProtected()) {
            long rem = lp.spawnProtectionUntil - System.currentTimeMillis();
            float pulse = 0.7f + 0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
            float alpha = Math.min(1f, rem/800f);
            // Draw in screen centre (player is always at centre of screen)
            float cx2 = screenW/2f, cy2 = screenH/2f;
            Paint protP = new Paint(Paint.ANTI_ALIAS_FLAG);
            protP.setStyle(Paint.Style.STROKE); protP.setStrokeWidth(5f*pulse);
            protP.setColor(Color.argb((int)(200*alpha),100,200,255));
            c.drawCircle(cx2, cy2, (PR*currentZoom+18)*pulse, protP);
            // Timer text
            Paint protTxt = fill(Color.argb((int)(230*alpha),120,220,255));
            protTxt.setTextSize(16f); protTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("🛡 "+(rem/1000+1)+"s", cx2, cy2-(PR*currentZoom+32), protTxt);
        }

        // ── Gear button ───────────────────────────────────────────────────────
        if(gearRect!=null){
            Paint gearBg=fill(Color.argb(settingsOpen?210:140,40,50,80));
            c.drawRoundRect(gearRect,10,10,gearBg);
            Paint gearTxt=new Paint(Paint.ANTI_ALIAS_FLAG);
            gearTxt.setColor(Color.WHITE); gearTxt.setTextSize(26f);
            gearTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("⚙",gearRect.centerX(),gearRect.centerY()+10,gearTxt);
        }

        // ── Shop button ───────────────────────────────────────────────────────
        if(shopBtn!=null){
            Paint sbP=fill(Color.argb(shopOpen?210:150,160,120,10));
            c.drawRoundRect(shopBtn,10,10,sbP);
            Paint sTxt=new Paint(Paint.ANTI_ALIAS_FLAG);
            sTxt.setColor(Color.WHITE); sTxt.setTextSize(22f); sTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("\uD83D\uDED2",shopBtn.centerX(),shopBtn.centerY()+9,sTxt);
        }

        // ── Joysticks ─────────────────────────────────────────────────────────
        if(moveStick!=null) moveStick.draw(c);
        if(aimStick!=null)  aimStick.draw(c);

        // ── Button-move mode overlay ───────────────────────────────────────────
        if(btnMoveMode){
            Paint dimP = fill(Color.argb(120,0,0,0));
            c.drawRect(0,0,w,h,dimP);
            // Redraw buttons with highlight — selected button glows differently
            Paint hlP    = fill(Color.argb(220,80,160,255));
            Paint hlSelP = fill(Color.argb(240,255,190,40)); // gold = currently selected for sizing
            boolean sizing = btnSizingId != -1;
            if(switchRect!=null){
                Paint p2 = (sizing && btnSizingId==0) ? hlSelP : hlP;
                float _scx=switchRect.centerX(),_scy=switchRect.centerY(),_sr=switchRect.width()/2f;
                c.drawCircle(_scx,_scy,_sr,p2);
                Paint _gp2=new Paint(btnTxtP); _gp2.setTextSize(_sr*0.70f);
                c.drawText("⚙",_scx,_scy+_sr*0.25f,_gp2);
            }
            if(reloadRect!=null){
                Paint p2 = (sizing && btnSizingId==1) ? hlSelP : hlP;
                c.drawRoundRect(reloadRect,10,10,p2); c.drawText("RELOAD",reloadRect.centerX(),reloadRect.centerY()+8,btnTxtP);
            }
            if(bombRect!=null)  { c.drawRoundRect(bombRect,10,10,hlP);   c.drawText("\uD83D\uDCA3",bombRect.centerX(),bombRect.centerY()+8,btnTxtP); }
            if(dropRect!=null)  { c.drawRoundRect(dropRect,10,10,hlP);   c.drawText("DROP GUN",dropRect.centerX(),dropRect.centerY()+8,btnTxtP); }
            if(skillRect!=null) {
                Paint p2 = (sizing && btnSizingId==5) ? hlSelP : hlP;
                float _scx=skillRect.centerX(),_scy=skillRect.centerY(),_sr=skillRect.width()/2f;
                c.drawCircle(_scx, _scy, _sr, p2);
                Paint _st = new Paint(btnTxtP); _st.setTextSize(_sr*0.38f);
                c.drawText("SKILL", _scx, _scy+8, _st);
            }
            if(shopBtn!=null){
                c.drawRoundRect(shopBtn,10,10,hlP);
                Paint sTmp=new Paint(Paint.ANTI_ALIAS_FLAG); sTmp.setColor(Color.WHITE); sTmp.setTextSize(22f); sTmp.setTextAlign(Paint.Align.CENTER);
                c.drawText("\uD83D\uDED2",shopBtn.centerX(),shopBtn.centerY()+9,sTmp);
            }
                // Instruction label
            Paint infoP = fill(Color.WHITE); infoP.setTextSize(20f); infoP.setTextAlign(Paint.Align.CENTER);
            infoP.setShadowLayer(3f,0,2f,Color.BLACK);
            c.drawText(sizing ? "Drag slider to resize  |  Drag button to move" : "Drag to move  |  Tap button to resize", w/2, h/2 - 20, infoP);

            // ── Training buttons (shown in move mode so they can be repositioned) ──
            if (trainingMode) {
                Paint thlP = fill(Color.argb(220, 100, 200, 130));
                String[] tLabels = {"+ Dummy", "- Dummy", "+200 Coins"};
                RectF[]  tRects  = {trainAddDummyBtn, trainRemDummyBtn, trainAddMoneyBtn};
                for (int i = 0; i < tRects.length; i++) {
                    if (tRects[i] == null) continue;
                    c.drawRoundRect(tRects[i], 10, 10, thlP);
                    c.drawText(tLabels[i], tRects[i].centerX(), tRects[i].centerY()+8, btnTxtP);
                }
            }

            // ── Size slider (shown when a button is tapped) ───────────────────
            if(sizing && sizeSliderTrack != null) {
                // Derive current scale for label
                float curScale = 0.4f + sizeSliderVal * 1.8f;
                String btnName = btnSizingId==0 ? "⚙ WHEEL" : (btnSizingId==1 ? "RELOAD" : "SKILL");
                Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG);
                labelP.setColor(Color.argb(220,255,220,80)); labelP.setTextSize(19f);
                labelP.setTextAlign(Paint.Align.CENTER); labelP.setShadowLayer(3f,0,2f,Color.BLACK);
                c.drawText(btnName + "  SIZE: " + (int)(curScale*100) + "%",
                        sizeSliderTrack.centerX(), sizeSliderTrack.top - 14f, labelP);
                // Track background
                Paint trackBg = fill(Color.argb(180,30,40,80));
                c.drawRoundRect(sizeSliderTrack, 16f, 16f, trackBg);
                // Filled portion
                float knobX = sizeSliderTrack.left + sizeSliderVal * sizeSliderTrack.width();
                RectF filled = new RectF(sizeSliderTrack.left, sizeSliderTrack.top, knobX, sizeSliderTrack.bottom);
                Paint fillP = fill(Color.argb(220,80,180,255));
                c.drawRoundRect(filled, 16f, 16f, fillP);
                // Knob
                Paint knobP = fill(Color.argb(255,255,255,255));
                c.drawCircle(knobX, sizeSliderTrack.centerY(), sizeSliderTrack.height()*0.82f, knobP);
                // Min / Max labels
                Paint mmP = new Paint(Paint.ANTI_ALIAS_FLAG);
                mmP.setColor(Color.argb(180,200,200,200)); mmP.setTextSize(15f);
                mmP.setTextAlign(Paint.Align.LEFT);
                c.drawText("40%", sizeSliderTrack.left + 4, sizeSliderTrack.bottom + 18f, mmP);
                mmP.setTextAlign(Paint.Align.RIGHT);
                c.drawText("220%", sizeSliderTrack.right - 4, sizeSliderTrack.bottom + 18f, mmP);
            }

            // Confirm button
            if(confirmMoveRect!=null){
                Paint confP = fill(Color.argb(230,50,190,90));
                c.drawRoundRect(confirmMoveRect,12,12,confP);
                Paint confTxt = new Paint(btnTxtP); confTxt.setTextSize(24f);
                c.drawText("✓  DONE", confirmMoveRect.centerX(), confirmMoveRect.centerY()+9, confTxt);
            }
        }

        // ── Weapon wheel overlay ──────────────────────────────────────────────
        if(wheelOpen) drawWeaponWheel(c);

        // ── Settings overlay ──────────────────────────────────────────────────
        if(settingsOpen) drawSettings(c);

        // ── Per-gun Release Fire overlay ──────────────────────────────────────
        if(relFireOpen) drawRelFirePanel(c);

        // ── Shop overlay ──────────────────────────────────────────────────────
        if(shopOpen) drawShop(c);

        // ── Training overlay ──────────────────────────────────────────────────
        if(trainingMode) drawTrainingHUD(c);
    }

    // ═══ TRAINING HUD ════════════════════════════════════════════════════════
    private void drawTrainingHUD(Canvas c) {
        if (trainAddDummyBtn == null) return;

        // Label
        Paint labelP = fill(Color.argb(200, 180, 230, 255));
        labelP.setTextSize(14f); labelP.setTextAlign(Paint.Align.RIGHT);
        labelP.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("TRAINING RANGE", trainAddDummyBtn.right, trainAddDummyBtn.top - 6f, labelP);

        // Dummy count indicator
        String dCnt = dummyIds.size() + "/" + MAX_DUMMIES + " dummies";
        Paint cntP = fill(Color.argb(180, 200, 200, 200));
        cntP.setTextSize(12f); cntP.setTextAlign(Paint.Align.RIGHT);
        c.drawText(dCnt, trainAddDummyBtn.right, trainRemDummyBtn.bottom + 16f, cntP);

        // Button data: rect, label, bg color
        RectF[]  rects  = { trainAddDummyBtn, trainRemDummyBtn, trainAddMoneyBtn };
        String[] labels = { "+ Dummy", "- Dummy", "+200 Coins" };
        int[]    colors = { 0xFF2a6faa, 0xFF7a3030, 0xFF2a8a50 };

        Paint btnP  = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint txtP  = fill(Color.WHITE);
        txtP.setTextSize(15f); txtP.setTextAlign(Paint.Align.CENTER);
        txtP.setTypeface(Typeface.DEFAULT_BOLD);

        for (int i = 0; i < rects.length; i++) {
            RectF r = rects[i];
            boolean canAdd = (i == 0 && dummyIds.size() >= MAX_DUMMIES);
            int col = canAdd ? Color.argb(120, 60, 80, 60) : colors[i];
            btnP.setColor(Color.argb(210, Color.red(col), Color.green(col), Color.blue(col)));
            btnP.setStyle(Paint.Style.FILL);
            c.drawRoundRect(r, 10, 10, btnP);
            btnP.setColor(Color.argb(120, 255, 255, 255));
            btnP.setStyle(Paint.Style.STROKE); btnP.setStrokeWidth(1.5f);
            c.drawRoundRect(r, 10, 10, btnP);
            c.drawText(labels[i], r.centerX(), r.centerY() + 6f, txtP);
        }
    }

    // ═══ SKILL BUTTON ════════════════════════════════════════════════════════
    private void drawSkillButton(Canvas c, Player lp) {
        if (skillRect == null) return;
        String[] skillIcons  = {"", "💨", "👁", "💊", "🛡"};
        String[] skillNames  = {"NO SKILL", "DASH", "STEALTH", "HEAL", "SHIELD"};
        int t = lp.activeSkillType;

        boolean onCd    = lp.skillOnCooldown();
        boolean active  = lp.skillIsActive();
        boolean noSkill = (t == Player.ACTIVE_NONE);

        float cx = skillRect.centerX(), cy = skillRect.centerY(), r = skillRect.width() / 2f;

        // Button colour
        int btnColor;
        if (noSkill)      btnColor = Color.argb(100,50,50,50);
        else if (onCd)    btnColor = Color.argb(150,60,60,60);
        else if (active)  btnColor = Color.argb(220,50,200,160);
        else              btnColor = Color.argb(210,60,100,200);

        c.drawCircle(cx, cy, r, fill(btnColor));

        // Circle border
        Paint borderP = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderP.setStyle(Paint.Style.STROKE);
        borderP.setStrokeWidth(3f);
        borderP.setColor(noSkill ? Color.argb(60,150,150,150) : Color.argb(160,150,200,255));
        c.drawCircle(cx, cy, r, borderP);

        // Cooldown sweep overlay (arc over circle)
        if (onCd && !noSkill) {
            long total = skillCooldownTotal(t);
            long rem   = lp.skillCooldownEnd - System.currentTimeMillis();
            float frac = Math.max(0f, Math.min(1f, (float)rem / total));
            // Dark fill
            c.drawCircle(cx, cy, r, fill(Color.argb(140,0,0,0)));
            // Sweep arc to show progress
            Paint arcP = new Paint(Paint.ANTI_ALIAS_FLAG);
            arcP.setColor(Color.argb(180,60,100,200));
            arcP.setStyle(Paint.Style.FILL);
            RectF arcRect = new RectF(cx-r, cy-r, cx+r, cy+r);
            c.drawArc(arcRect, -90f, 360f * (1f - frac), true, arcP);
            // Re-draw border on top
            c.drawCircle(cx, cy, r, borderP);
            // Cooldown text
            Paint cdTxt = fill(Color.argb(220,255,200,0));
            cdTxt.setTextSize(r * 0.45f); cdTxt.setTextAlign(Paint.Align.CENTER);
            cdTxt.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText((rem/1000+1)+"s", cx, cy + r*0.17f, cdTxt);
        }

        // Label + icon (only when not on cooldown)
        if (!onCd || noSkill) {
            String icon  = noSkill ? "❌" : skillIcons[t];
            String label = noSkill ? "SKILL" : skillNames[t];
            Paint iconP = new Paint(Paint.ANTI_ALIAS_FLAG);
            iconP.setTextSize(r * 0.70f); iconP.setTextAlign(Paint.Align.CENTER);
            c.drawText(icon, cx, cy - r * 0.05f, iconP);
            Paint lbP = new Paint(btnTxtP); lbP.setTextSize(r * 0.30f);
            lbP.setColor(Color.argb(200,220,230,255));
            c.drawText(label, cx, cy + r * 0.62f, lbP);
        }

        // Active glow ring
        if (active) {
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.STROKE); glow.setStrokeWidth(4f);
            glow.setColor(Color.argb(200,80,255,180));
            float pulse = 0.5f+0.5f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
            glow.setAlpha((int)(200*pulse));
            c.drawCircle(cx, cy, r + 5f * pulse, glow);
        }
    }

    private long skillCooldownTotal(int type) {
        switch(type){
            case Player.ACTIVE_DASH:    return 6000;
            case Player.ACTIVE_STEALTH: return 10000;
            case Player.ACTIVE_HEAL:    return 12000;
            case Player.ACTIVE_SHIELD:  return 14000;
            default: return 1;
        }
    }

    // ═══ SETTINGS OVERLAY ════════════════════════════════════════════════════
    // ═══ WEAPON WHEEL ════════════════════════════════════════════════════════
    private void drawWeaponWheel(Canvas c) {
        if (wheelSlots == null || wheelSlots.length == 0) return;
        Player lp = localPlayer; if (lp == null) return;
        Gun[] allGuns = lp.guns;
        int n = wheelSlots.length;
        float sliceDeg = 360f / n;
        float startDeg = -90f; // top of circle = first slot

        // ── Dim background ────────────────────────────────────────────────────
        Paint dimP = fill(Color.argb(140, 0, 0, 0));
        c.drawRect(0, 0, screenW, screenH, dimP);

        // ── Outer ring background ─────────────────────────────────────────────
        float outerR = wheelRadius;
        float innerR = outerR * 0.38f;
        Paint ringBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        ringBg.setStyle(Paint.Style.FILL);
        ringBg.setColor(Color.argb(200, 15, 20, 35));
        c.drawCircle(wheelCX, wheelCY, outerR + 8f, ringBg);

        // ── Slices ────────────────────────────────────────────────────────────
        android.graphics.RectF oval = new android.graphics.RectF(
                wheelCX - outerR, wheelCY - outerR,
                wheelCX + outerR, wheelCY + outerR);

        Paint sliceP = new Paint(Paint.ANTI_ALIAS_FLAG);
        sliceP.setStyle(Paint.Style.FILL);
        Paint borderP = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderP.setStyle(Paint.Style.STROKE);
        borderP.setStrokeWidth(2.5f);

        for (int i = 0; i < n; i++) {
            float sweep = sliceDeg - 2f;          // 2° gap between slices
            float begin = startDeg + i * sliceDeg + 1f;
            boolean hovered = (i == wheelHovered);
            int slotGunIdx = wheelSlots[i];

            // Slice color
            int baseColor;
            if (slotGunIdx == -1) {
                baseColor = 0xFFFF6600; // bomb = orange
            } else {
                baseColor = allGuns[slotGunIdx].color;
            }
            int r = Color.red(baseColor), g = Color.green(baseColor), b = Color.blue(baseColor);

            // Dim empty guns in the wheel so players can spot usable weapons at a glance
            boolean isEmpty = (slotGunIdx >= 0) && allGuns[slotGunIdx].ammo == 0 && !allGuns[slotGunIdx].reloading;
            sliceP.setColor(hovered
                    ? Color.argb(230, r, g, b)
                    : isEmpty ? Color.argb(55, r/3, g/3, b/3)
                              : Color.argb(110, r / 2, g / 2, b / 2));
            borderP.setColor(hovered
                    ? Color.argb(255, r, g, b)
                    : isEmpty ? Color.argb(70, r, g, b)
                              : Color.argb(130, r, g, b));

            // Draw filled arc then border arc
            android.graphics.Path slicePath = new android.graphics.Path();
            slicePath.moveTo(wheelCX, wheelCY);
            slicePath.arcTo(oval, begin, sweep);
            slicePath.close();
            c.drawPath(slicePath, sliceP);
            c.drawPath(slicePath, borderP);

            // Label: icon + short name, placed at mid-radius
            float midAngleDeg = begin + sweep / 2f;
            float midAngleRad = (float) Math.toRadians(midAngleDeg);
            float labelR = (outerR + innerR) / 2f;
            float lx = wheelCX + (float) Math.cos(midAngleRad) * labelR;
            float ly = wheelCY + (float) Math.sin(midAngleRad) * labelR;

            Paint labelP = new Paint(Paint.ANTI_ALIAS_FLAG);
            labelP.setTextAlign(Paint.Align.CENTER);
            labelP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            labelP.setColor(hovered ? Color.WHITE : Color.argb(200, 220, 220, 220));
            labelP.setShadowLayer(3f, 0, 1f, Color.BLACK);

            String icon, shortName;
            if (slotGunIdx == -1) {
                icon = "💣";
                shortName = "BOMB\n×" + lp.bombs;
            } else {
                Gun sg = allGuns[slotGunIdx];
                // Map gun index to a simple emoji icon
                String[] gunIcons = {"🔫","🔫","🔫","🔫","🎯","🔫","⚙","🔫","🔫",
                                     "🔵","🟢","⚡","🎯","💥","👻","🎨","💰","🗡"};
                icon = (slotGunIdx < gunIcons.length) ? gunIcons[slotGunIdx] : "🔫";
                shortName = sg.name;
            }

            // Icon (emoji)
            labelP.setTextSize(hovered ? 22f : 18f);
            c.drawText(icon, lx, ly - 7f, labelP);
            // Gun name below icon
            labelP.setTextSize(hovered ? 14f : 11f);
            c.drawText(shortName, lx, ly + 14f, labelP);
            // Ammo or bomb count as small sub-label
            if (slotGunIdx >= 0) {
                Gun sg = allGuns[slotGunIdx];
                boolean isActive = (lp.gunIndex == slotGunIdx);
                // Ammo sub-label — color coded: red=empty, amber=reloading, green=active
                Paint subP = new Paint(Paint.ANTI_ALIAS_FLAG);
                subP.setTextSize(10f); subP.setTextAlign(Paint.Align.CENTER);
                String ammoLabel;
                if (sg.reloading) {
                    subP.setColor(Color.argb(255, 255, 185, 30)); // amber
                    ammoLabel = "RELOADING\u2026";
                } else if (sg.ammo == 0) {
                    subP.setColor(Color.argb(255, 255, 70, 70)); // red
                    ammoLabel = "EMPTY";
                } else {
                    subP.setColor(isActive ? Color.argb(255, 100, 255, 100) : Color.argb(160, 180, 180, 180));
                    ammoLabel = sg.ammo + "/" + sg.maxAmmo;
                }
                c.drawText(ammoLabel, lx, ly + 27f, subP);
                // Coin Gun: show current effective damage
                if (sg.coinScaling) {
                    float effDmg = 20f + Math.min(lp.coins, 600) * 0.167f;
                    Paint coinHint = new Paint(Paint.ANTI_ALIAS_FLAG);
                    coinHint.setTextSize(9f); coinHint.setTextAlign(Paint.Align.CENTER);
                    coinHint.setColor(Color.argb(200, 255, 215, 0));
                    c.drawText("⚡" + (int) effDmg + "dmg", lx, ly + 38f, coinHint);
                }
            }
        }

        // ── Inner hole — currently equipped gun name ───────────────────────────
        Paint holeFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        holeFill.setStyle(Paint.Style.FILL);
        holeFill.setColor(Color.argb(230, 10, 14, 24));
        c.drawCircle(wheelCX, wheelCY, innerR, holeFill);
        Paint holeRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        holeRing.setStyle(Paint.Style.STROKE);
        holeRing.setStrokeWidth(2f);
        holeRing.setColor(Color.argb(160, 100, 140, 200));
        c.drawCircle(wheelCX, wheelCY, innerR, holeRing);

        // Center label: hovered item or current gun
        String centerMain, centerSub;
        if (wheelHovered >= 0 && wheelHovered < n) {
            int sel = wheelSlots[wheelHovered];
            if (sel == -1) { centerMain = "💣 BOMB"; centerSub = "Throw!"; }
            else { centerMain = lp.guns[sel].name; centerSub = "SELECT"; }
        } else {
            centerMain = lp.currentGun().name;
            centerSub = "drag to pick";
        }
        Paint cTitleP = new Paint(Paint.ANTI_ALIAS_FLAG);
        cTitleP.setTextSize(15f); cTitleP.setTextAlign(Paint.Align.CENTER);
        cTitleP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        cTitleP.setColor(wheelHovered >= 0 ? Color.WHITE : Color.argb(200, 180, 200, 255));
        cTitleP.setShadowLayer(3f, 0, 1f, Color.BLACK);
        c.drawText(centerMain, wheelCX, wheelCY - 5f, cTitleP);
        Paint cSubP = new Paint(Paint.ANTI_ALIAS_FLAG);
        cSubP.setTextSize(11f); cSubP.setTextAlign(Paint.Align.CENTER);
        cSubP.setColor(Color.argb(150, 160, 180, 220));
        c.drawText(centerSub, wheelCX, wheelCY + 13f, cSubP);

        // ── Coins display (relevant for Coin Gun) ─────────────────────────────
        Paint coinP = new Paint(Paint.ANTI_ALIAS_FLAG);
        coinP.setTextSize(13f); coinP.setTextAlign(Paint.Align.CENTER);
        coinP.setColor(Color.argb(200, 255, 215, 0));
        coinP.setShadowLayer(2f, 0, 1f, Color.BLACK);
        c.drawText("💰 " + lp.coins, wheelCX, wheelCY + outerR + 26f, coinP);
    }

    private void drawSettings(Canvas c) {
        if(settingsPanel==null) return;
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, 0);
        int  jsSize  = prefs.getInt    ("js_size",  1);
        boolean swap = prefs.getBoolean("swap",     false);
        int  btnSize = prefs.getInt    ("btn_size", 1);
        int  opacity = prefs.getInt    ("opacity",  1);

        // Panel background + border
        c.drawRoundRect(settingsPanel, 16, 16, settingsBgP);
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setColor(Color.argb(160,80,120,200)); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
        c.drawRoundRect(settingsPanel, 16, 16, border);

        float px = settingsPanel.left, py = settingsPanel.top;
        float pw = settingsPanel.width();

        c.drawText("⚙  CONTROLS", px+20, py+42, settingsTitleP);

        c.drawRoundRect(closeSettingsRect, 8, 8, closeBtnP);
        Paint cTxt = new Paint(optTxtP); cTxt.setTextSize(20f);
        c.drawText("✕", closeSettingsRect.centerX(), closeSettingsRect.centerY()+7, cTxt);

        Paint div = fill(Color.argb(60,255,255,255));
        c.drawRect(px+16, py+58, px+pw-16, py+60, div);

        int aimSens = prefs.getInt("aim_sens", 1);
        boolean showGunStats = prefs.getBoolean("gun_stats", true);
        boolean showAimLine  = prefs.getBoolean("aim_line",  false);
        // Row labels
        String[] labels = {"JOYSTICK SIZE","SWAP SIDES","BUTTON SIZE","AIM SPEED","OPACITY","GUN STATS","AIM LINE","RELEASE FIRE","FIRE THRESH"};
        float[] rowY = {py+66f, py+128f, py+190f, py+252f, py+314f, py+376f, py+438f, py+500f, py+562f};
        for(int r=0;r<9;r++) c.drawText(labels[r], px+20, rowY[r]+26, settingsLabelP);

        String[] jsLabels = {"S","M","L"};
        for(int i=0;i<3;i++) drawOpt(c, jsSizeOpts[i],  jsLabels[i], i==jsSize);
        String[] swLabels = {"OFF","ON"};
        for(int i=0;i<2;i++) drawOpt(c, swapOpts[i],    swLabels[i], i==(swap?1:0));
        String[] bsLabels = {"S","M","L"};
        for(int i=0;i<3;i++) drawOpt(c, btnSizeOpts[i], bsLabels[i], i==btnSize);
        String[] asLabels = {"SLOW","NORM","FAST"};
        for(int i=0;i<3;i++) drawOpt(c, aimSensOpts[i], asLabels[i], i==aimSens);
        String[] opLabels = {"LO","MED","HI"};
        for(int i=0;i<3;i++) drawOpt(c, opacityOpts[i], opLabels[i], i==opacity);
        String[] gsLabels = {"ON","OFF"};
        for(int i=0;i<2;i++) drawOpt(c, gunStatOpts[i], gsLabels[i], i==(showGunStats?0:1));
        String[] alLabels = {"ON","OFF"};
        for(int i=0;i<2;i++) drawOpt(c, aimLineOpts[i], alLabels[i], i==(showAimLine?0:1));
        // RELEASE FIRE ▶ button — opens per-gun panel
        if (relFireOpenBtn != null) {
            // Count how many guns have release fire on
            int rfCount = 0;
            for (int i = 0; i < GUN_NAMES.length; i++) if (prefs.getBoolean("rel_fire_"+i,false)) rfCount++;
            c.drawRoundRect(relFireOpenBtn, 8, 8, optBtnSelP);
            Paint rfBtnTxt = new Paint(optTxtP); rfBtnTxt.setColor(Color.WHITE); rfBtnTxt.setTextSize(17f);
            String rfLabel = rfCount == 0 ? "OFF ▶" : rfCount + " gun" + (rfCount>1?"s":"") + " ▶";
            c.drawText(rfLabel, relFireOpenBtn.centerX(), relFireOpenBtn.centerY()+7f, rfBtnTxt);
        }

        // Fire threshold — value display box + EDIT button
        if (fireThreshValRect != null) {
            float curFt = getFireThresh();
            c.drawRoundRect(fireThreshValRect, 8, 8, fill(Color.argb(180,30,40,70)));
            Paint ftBorder = new Paint(Paint.ANTI_ALIAS_FLAG);
            ftBorder.setColor(Color.argb(140,80,120,200)); ftBorder.setStyle(Paint.Style.STROKE); ftBorder.setStrokeWidth(1.5f);
            c.drawRoundRect(fireThreshValRect, 8, 8, ftBorder);
            Paint ftVal = new Paint(optTxtP); ftVal.setColor(Color.WHITE); ftVal.setTextSize(18f);
            c.drawText(String.format(java.util.Locale.US, "%.2f", curFt),
                    fireThreshValRect.centerX(), fireThreshValRect.centerY()+7, ftVal);
        }
        if (fireThreshEditBtn != null) {
            c.drawRoundRect(fireThreshEditBtn, 8, 8, optBtnSelP);
            Paint editTxt = new Paint(optTxtP); editTxt.setColor(Color.WHITE); editTxt.setTextSize(17f);
            c.drawText("EDIT", fireThreshEditBtn.centerX(), fireThreshEditBtn.centerY()+7, editTxt);
        }

        // MOVE BUTTONS button
        if(moveBtnsRect!=null){
            Paint mbP = fill(Color.argb(210,60,110,190));
            c.drawRoundRect(moveBtnsRect, 10, 10, mbP);
            Paint mbTxt = new Paint(optTxtP); mbTxt.setTextSize(19f); mbTxt.setColor(Color.WHITE);
            c.drawText("✥  MOVE BUTTONS", moveBtnsRect.centerX(), moveBtnsRect.centerY()+7, mbTxt);
        }

        // MAIN MENU button
        if(mainMenuRect!=null){
            Paint mmP = fill(Color.argb(220,160,30,30));
            c.drawRoundRect(mainMenuRect, 10, 10, mmP);
            Paint mmTxt = new Paint(optTxtP); mmTxt.setTextSize(19f); mmTxt.setColor(Color.WHITE);
            c.drawText("⏎  MAIN MENU", mainMenuRect.centerX(), mainMenuRect.centerY()+7, mmTxt);
        }
    }

    /** Returns the fire-joystick magnitude threshold from cached settings (0.15–0.70). */
    private float getFireThresh() {
        return cachedFireThresh;
    }

    private void showFireThreshDialog() {
        android.app.Activity act = (android.app.Activity) getContext();
        act.runOnUiThread(() -> {
            android.widget.EditText input = new android.widget.EditText(getContext());
            input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER
                    | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
            float cur = getFireThresh();
            input.setText(String.format(java.util.Locale.US, "%.2f", cur));
            input.selectAll();
            input.setPadding(40, 24, 40, 24);

            new android.app.AlertDialog.Builder(getContext())
                .setTitle("Fire Threshold")
                .setMessage("How far to push aim stick before firing (0.05 – 0.99)")
                .setView(input)
                .setPositiveButton("Set", (dlg, which) -> {
                    try {
                        float val = Float.parseFloat(input.getText().toString().trim());
                        val = Math.max(0.05f, Math.min(0.99f, val));
                        getContext().getSharedPreferences(PREFS, 0).edit()
                            .putFloat("fire_thresh_val", val).apply();
                        refreshCachedPrefs();
                    } catch (NumberFormatException ignored) {}
                })
                .setNegativeButton("Cancel", null)
                .show();
        });
    }

    private void drawOpt(Canvas c, RectF r, String label, boolean selected) {
        if(r==null) return;
        c.drawRoundRect(r, 8, 8, selected ? optBtnSelP : optBtnP);
        Paint t = new Paint(optTxtP);
        if(selected) { t.setColor(Color.WHITE); } else { t.setColor(Color.argb(180,200,210,230)); }
        c.drawText(label, r.centerX(), r.centerY()+7, t);
    }

    // ═══ PER-GUN RELEASE FIRE PANEL ══════════════════════════════════════════
    private void drawRelFirePanel(Canvas c) {
        if (relFirePanel == null) return;
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, 0);
        float rfpX = relFirePanel.left, rfpY = relFirePanel.top;
        float rfpW = relFirePanel.width();

        // Background
        c.drawRoundRect(relFirePanel, 16, 16, settingsBgP);
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setColor(Color.argb(160, 80, 120, 200)); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
        c.drawRoundRect(relFirePanel, 16, 16, border);

        // Title
        Paint titleP = new Paint(settingsTitleP);
        c.drawText("⚡  RELEASE FIRE", rfpX + 20, rfpY + 42, titleP);

        // Close button
        c.drawRoundRect(relFireCloseBtn, 8, 8, closeBtnP);
        Paint cTxt = new Paint(optTxtP); cTxt.setTextSize(20f);
        c.drawText("✕", relFireCloseBtn.centerX(), relFireCloseBtn.centerY()+7, cTxt);

        // Divider
        Paint div = fill(Color.argb(60,255,255,255));
        c.drawRect(rfpX+16, rfpY+58, rfpX+rfpW-16, rfpY+60, div);

        // Column header labels
        float rfColW = rfpW / 2f - 12f;
        Paint hdrP = new Paint(Paint.ANTI_ALIAS_FLAG);
        hdrP.setTextSize(13f); hdrP.setColor(Color.argb(150,180,200,255));
        hdrP.setTextAlign(Paint.Align.LEFT); hdrP.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        float hdrY = rfpY + 58f;

        // Draw each gun row
        int rfRows = 10;
        float rfRowH = 38f, rfRowGap = 5f;
        float rfContentY = rfpY + 62f;
        Paint gunNameP = new Paint(Paint.ANTI_ALIAS_FLAG);
        gunNameP.setTextSize(15f); gunNameP.setTextAlign(Paint.Align.LEFT);

        for (int i = 0; i < GUN_NAMES.length; i++) {
            int col = i / rfRows, row = i % rfRows;
            float rfRx = rfpX + 10f + col * (rfColW + 12f);
            float ry = rfContentY + row * (rfRowH + rfRowGap);

            boolean isOn = prefs.getBoolean("rel_fire_"+i, false);
            int gunColor = GUN_COLORS[i];

            // Row background
            Paint rowBg = fill(Color.argb(30, Color.red(gunColor), Color.green(gunColor), Color.blue(gunColor)));
            c.drawRoundRect(new RectF(rfRx, ry, rfRx+rfColW, ry+rfRowH), 6, 6, rowBg);

            // Color accent bar
            Paint accentP = fill(gunColor);
            c.drawRoundRect(new RectF(rfRx, ry+8, rfRx+4, ry+rfRowH-8), 2, 2, accentP);

            // Gun name
            gunNameP.setColor(isOn ? Color.WHITE : Color.argb(160, 200, 210, 230));
            c.drawText(GUN_NAMES[i], rfRx+12, ry+rfRowH/2f+6, gunNameP);

            // ON / OFF toggle buttons
            if (relFireToggleON[i] != null) {
                Paint onP = isOn
                    ? fill(Color.argb(230, Color.red(gunColor)/2+60, Color.green(gunColor)/2+60, Color.blue(gunColor)/2+40))
                    : fill(Color.argb(80,40,50,80));
                c.drawRoundRect(relFireToggleON[i], 6, 6, onP);
                Paint onTxt = new Paint(optTxtP); onTxt.setTextSize(13f);
                onTxt.setColor(isOn ? Color.WHITE : Color.argb(120,180,190,210));
                c.drawText("ON", relFireToggleON[i].centerX(), relFireToggleON[i].centerY()+5, onTxt);
            }
            if (relFireToggleOFF[i] != null) {
                Paint offP = !isOn
                    ? fill(Color.argb(180,60,30,30))
                    : fill(Color.argb(80,40,50,80));
                c.drawRoundRect(relFireToggleOFF[i], 6, 6, offP);
                Paint offTxt = new Paint(optTxtP); offTxt.setTextSize(13f);
                offTxt.setColor(!isOn ? Color.argb(220,255,160,160) : Color.argb(120,180,190,210));
                c.drawText("OFF", relFireToggleOFF[i].centerX(), relFireToggleOFF[i].centerY()+5, offTxt);
            }
        }
    }

    // ═══ SHOP OVERLAY ════════════════════════════════════════════════════════
    private void drawShop(Canvas c) {
        Player lp = localPlayer;
        float spw = Math.min(580f, screenW - 40f);
        float sph = shopPanelH;
        float spx = (screenW - spw) / 2f;
        float spy = (screenH - sph) / 2f;

        // Panel background + border
        c.drawRoundRect(new RectF(spx,spy,spx+spw,spy+sph),18,18,settingsBgP);
        Paint border=new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setColor(Color.argb(180,80,120,200));
        border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
        c.drawRoundRect(new RectF(spx,spy,spx+spw,spy+sph),18,18,border);

        // Title
        c.drawText("\uD83D\uDED2  SHOP", spx+20, spy+44, settingsTitleP);

        // Coins
        Paint cpP=fill(Color.rgb(255,210,50)); cpP.setTextSize(22f);
        cpP.setTextAlign(Paint.Align.RIGHT); cpP.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("\uD83D\uDCB0 "+(lp!=null?lp.coins:0), spx+spw-20, spy+44, cpP);

        // Close button
        if(shopCloseRect!=null){
            c.drawRoundRect(shopCloseRect,8,8,closeBtnP);
            Paint cTxt=new Paint(optTxtP); cTxt.setTextSize(20f);
            c.drawText("✕",shopCloseRect.centerX(),shopCloseRect.centerY()+7,cTxt);
        }

        // Tab buttons
        if (shopTabGuns != null && shopTabSkills != null) {
            Paint tabActive   = fill(Color.argb(220,60,100,200));
            Paint tabInactive = fill(Color.argb(100,40,40,70));
            Paint tabTxt = fill(Color.WHITE); tabTxt.setTextSize(17f); tabTxt.setTextAlign(Paint.Align.CENTER); tabTxt.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawRoundRect(shopTabGuns,   10,10, shopTab==0?tabActive:tabInactive);
            c.drawRoundRect(shopTabSkills, 10,10, shopTab==1?tabActive:tabInactive);
            c.drawText("\uD83D\uDD2B Weapons", shopTabGuns.centerX(),   shopTabGuns.centerY()+7,   tabTxt);
            c.drawText("\u26A1 Skills",         shopTabSkills.centerX(), shopTabSkills.centerY()+7, tabTxt);
        }

        if (shopTab == 0) drawShopGuns(c, lp, spx, spy, spw);
        else              drawShopSkills(c, lp, spx, spy, spw);
    }

    private void drawShopGuns(Canvas c, Player lp, float spx, float spy, float spw) {
        Gun[] allGuns = Gun.createAll();
        float rowH=SHOP_ROW_H, rowGap=SHOP_ROW_GAP, firstRowY=spy+110f;
        float sph = shopPanelH;
        float contentH = allGuns.length * (rowH + rowGap);
        float visibleH  = sph - 110f;
        shopTabScrollMax[0] = Math.max(0f, contentH - visibleH);
        float scrollY = shopTabScrollY[0];

        Paint sbgP=fill(Color.argb(60,255,255,255));
        Paint slblP=fill(Color.argb(180,200,220,255)); slblP.setTextSize(10f);

        c.save();
        c.clipRect(spx, spy + 100f, spx + spw, spy + sph - 4f);

        for(int i=0;i<allGuns.length;i++){
            float ry = firstRowY + i*(rowH+rowGap) - scrollY;
            if (ry + rowH < spy + 100f || ry > spy + sph) continue;
            Gun g = allGuns[i];
            boolean owned = (lp==null)||lp.unlockedGuns[i];
            Paint rowBg=fill(owned?Color.argb(55,60,140,70):Color.argb(40,40,40,80));
            c.drawRoundRect(new RectF(spx+10,ry,spx+spw-10,ry+rowH),8,8,rowBg);
            c.drawCircle(spx+28,ry+rowH/2,10,fill(g.color));
            Paint gnP=fill(g.color); gnP.setTextSize(18f); gnP.setTypeface(Typeface.DEFAULT_BOLD); gnP.setTextAlign(Paint.Align.LEFT);
            c.drawText(g.name, spx+46, ry+21, gnP);
            if (i == 20 && lp != null) {
                // Soul Reaper: show tier + kill progress instead of stat bars
                Gun sr = lp.guns[20];
                int slv = sr.soulLevel();
                String[] tn2 = {"DORMANT","TIER I","TIER II","TIER III","TIER IV","TIER V"};
                int next2 = sr.soulNextThreshold();
                String srLine = "\u2620 " + tn2[slv] + (next2 >= 0 ? "  (" + sr.killCount + "/" + next2 + " kills)" : "  MAXED");
                Paint srP = fill(g.color); srP.setTextSize(11f); srP.setTextAlign(Paint.Align.LEFT);
                c.drawText(srLine, spx+46, ry+38, srP);
                Paint srHintP = fill(Color.argb(150,200,180,255)); srHintP.setTextSize(10f); srHintP.setTextAlign(Paint.Align.LEFT);
                c.drawText("pierce \u2192 bounce \u2192 home \u2192 explode", spx+46, ry+54, srHintP);
            } else {
                String[] sn={"DMG","SPD","RNG","RATE"};
                float[] sv={g.statDamage(),g.statSpeed(),g.statRange(),g.statFireRate()};
                int[]   sc={0xFFFF5252,0xFF64B5F6,0xFF81C784,0xFFFFD54F};
                float bw2=50f, bh2=6f, bgap=6f, barsX=spx+46f, barsY=ry+30f;
                for(int si=0;si<4;si++){
                    float bx2=barsX+si*(bw2+bgap);
                    c.drawRoundRect(bx2,barsY,bx2+bw2,barsY+bh2,3,3,sbgP);
                    c.drawRoundRect(bx2,barsY,bx2+bw2*sv[si],barsY+bh2,3,3,fill(sc[si]));
                    slblP.setTextAlign(Paint.Align.LEFT);
                    c.drawText(sn[si],bx2,barsY+bh2+11f,slblP);
                }
            }
            if(shopBuyRects[i]!=null){
                RectF br = new RectF(shopBuyRects[i].left, ry+10,
                                     shopBuyRects[i].right, ry+10+36f);
                if(owned){
                    c.drawRoundRect(br,8,8,fill(Color.argb(180,50,180,80)));
                    Paint otP=fill(Color.WHITE); otP.setTextSize(14f); otP.setTextAlign(Paint.Align.CENTER); otP.setTypeface(Typeface.DEFAULT_BOLD);
                    c.drawText("✓ OWNED",br.centerX(),br.centerY()+6,otP);
                } else {
                    int price=GUN_PRICES[i];
                    boolean afford=(lp!=null&&lp.coins>=price);
                    c.drawRoundRect(br,8,8,fill(afford?Color.argb(220,180,130,0):Color.argb(120,70,70,80)));
                    Paint btP=fill(afford?Color.WHITE:Color.argb(120,200,200,200)); btP.setTextSize(14f); btP.setTextAlign(Paint.Align.CENTER); btP.setTypeface(Typeface.DEFAULT_BOLD);
                    c.drawText("\uD83D\uDCB0 "+price,br.centerX(),br.centerY()+6,btP);
                }
            }
        }

        // Scroll indicator
        if (shopTabScrollMax[0] > 0f) {
            float trackX = spx + spw - 6f;
            float trackTop = spy + 104f, trackBot = spy + sph - 8f, trackH = trackBot - trackTop;
            float thumbH = Math.max(30f, trackH * (visibleH / contentH));
            float thumbTop = trackTop + (trackH - thumbH) * (scrollY / shopTabScrollMax[0]);
            Paint scrollP = fill(Color.argb(120, 200, 200, 255));
            c.drawRoundRect(trackX - 3f, thumbTop, trackX + 3f, thumbTop + thumbH, 3f, 3f, scrollP);
        }

        c.restore();
    }

    private void drawShopSkills(Canvas c, Player lp, float spx, float spy, float spw) {
        float sph = shopPanelH;
        // Total content: passive header(~16px) + 4 passive rows + active header(~35px) + 4 active rows
        float rowH=54f, rowGap=4f;
        float contentBottom = 412f + 4*(rowH+rowGap); // relative to spy
        float contentH = contentBottom - 110f;
        float visibleH  = sph - 110f;
        shopTabScrollMax[1] = Math.max(0f, contentH - visibleH);
        float scrollY = shopTabScrollY[1];

        c.save();
        c.clipRect(spx, spy + 100f, spx + spw, spy + sph - 4f);
        c.translate(0f, -scrollY);

        // ── Passive section header ──
        Paint secP=fill(Color.argb(220,180,180,255)); secP.setTextSize(17f); secP.setTextAlign(Paint.Align.LEFT); secP.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("● PASSIVE SKILLS", spx+18, spy+126, secP);

        String[] passNames={"⚡ Fast Reload","🔥 Fire Rate","🎯 Bullet Range","👟 Move Speed"};
        String[] passDesc ={"−20% reload per level","+20% fire rate per level","+25% range per level","+12% speed per level"};
        int[]    passLevels=(lp==null)?new int[4]:new int[]{lp.skillReload,lp.skillFireRate,lp.skillRange,lp.skillMoveSpeed};
        float firstY=spy+132f;
        for(int i=0;i<4;i++){
            float ry=firstY+i*(rowH+rowGap);
            int lv=passLevels[i];
            c.drawRoundRect(new RectF(spx+12,ry,spx+spw-12,ry+rowH),10,10,fill(Color.argb(80,30,30,70)));
            Paint nameP2=fill(Color.WHITE); nameP2.setTextSize(16f); nameP2.setTextAlign(Paint.Align.LEFT); nameP2.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(passNames[i],spx+18,ry+22,nameP2);
            Paint descP=fill(Color.argb(150,190,190,190)); descP.setTextSize(12f); descP.setTextAlign(Paint.Align.LEFT);
            c.drawText(passDesc[i],spx+18,ry+40,descP);
            for(int d=0;d<3;d++){
                Paint pip=fill(d<lv?Color.rgb(80,200,255):Color.argb(80,80,80,80));
                c.drawCircle(spx+spw-140+d*24,ry+rowH/2f,9,pip);
            }
            if(passiveBuyRects[i]!=null){
                if(lv>=3){
                    c.drawRoundRect(passiveBuyRects[i],8,8,fill(Color.argb(100,40,120,40)));
                    Paint ot=fill(Color.argb(200,150,255,150)); ot.setTextSize(13f); ot.setTextAlign(Paint.Align.CENTER);
                    c.drawText("MAX",passiveBuyRects[i].centerX(),passiveBuyRects[i].centerY()+5,ot);
                } else {
                    int cost=PASSIVE_SKILL_COSTS[lv];
                    boolean canBuy=lp!=null&&lp.coins>=cost;
                    c.drawRoundRect(passiveBuyRects[i],8,8,fill(canBuy?Color.argb(210,60,100,200):Color.argb(80,60,60,60)));
                    Paint bt=fill(canBuy?Color.WHITE:Color.argb(120,180,180,180)); bt.setTextSize(13f); bt.setTextAlign(Paint.Align.CENTER);
                    c.drawText("\uD83D\uDCB0"+cost,passiveBuyRects[i].centerX(),passiveBuyRects[i].centerY()+5,bt);
                }
            }
        }

        // ── Active section header ──
        Paint secP2=fill(Color.argb(220,255,210,80)); secP2.setTextSize(17f); secP2.setTextAlign(Paint.Align.LEFT); secP2.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("● ACTIVE SKILL  (equip one)", spx+18, spy+388, secP2);
        Paint noteP=fill(Color.argb(130,180,180,180)); noteP.setTextSize(12f); noteP.setTextAlign(Paint.Align.LEFT);
        c.drawText("Tap [SKILL] button in-game to activate", spx+18, spy+407, noteP);

        String[] actNames={"💨 Dash","👁 Stealth","💊 Heal","🛡 Shield"};
        String[] actDesc ={"Teleport 260px  •  6s cooldown","Invisible 4s  •  10s cooldown","+40 HP  •  12s cooldown","60-HP barrier 6s  •  14s cooldown"};
        int[]    actTypes={Player.ACTIVE_DASH,Player.ACTIVE_STEALTH,Player.ACTIVE_HEAL,Player.ACTIVE_SHIELD};
        float activeFirstY=spy+412f;
        for(int i=0;i<4;i++){
            float ry=activeFirstY+i*(rowH+rowGap);
            boolean owned=(lp!=null&&lp.activeSkillType==actTypes[i]);
            c.drawRoundRect(new RectF(spx+12,ry,spx+spw-12,ry+rowH),10,10,fill(owned?Color.argb(100,50,80,30):Color.argb(80,30,30,60)));
            Paint nameP2=fill(Color.WHITE); nameP2.setTextSize(16f); nameP2.setTextAlign(Paint.Align.LEFT); nameP2.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(actNames[i],spx+18,ry+22,nameP2);
            Paint descP=fill(Color.argb(150,190,190,190)); descP.setTextSize(12f); descP.setTextAlign(Paint.Align.LEFT);
            c.drawText(actDesc[i],spx+18,ry+40,descP);
            if(activeBuyRects[i]!=null){
                if(owned){
                    c.drawRoundRect(activeBuyRects[i],8,8,fill(Color.argb(100,40,120,40)));
                    Paint ot=fill(Color.argb(200,150,255,150)); ot.setTextSize(12f); ot.setTextAlign(Paint.Align.CENTER);
                    c.drawText("EQUIPPED",activeBuyRects[i].centerX(),activeBuyRects[i].centerY()+5,ot);
                } else {
                    int cost=ACTIVE_SKILL_COSTS[i];
                    boolean canBuy=lp!=null&&lp.coins>=cost;
                    c.drawRoundRect(activeBuyRects[i],8,8,fill(canBuy?Color.argb(210,100,60,200):Color.argb(80,60,60,60)));
                    Paint bt=fill(canBuy?Color.WHITE:Color.argb(120,180,180,180)); bt.setTextSize(12f); bt.setTextAlign(Paint.Align.CENTER);
                    c.drawText("\uD83D\uDCB0"+cost,activeBuyRects[i].centerX(),activeBuyRects[i].centerY()+5,bt);
                }
            }
        }

        c.restore();

        // Scroll indicator (drawn after restore so it's not clipped out)
        if (shopTabScrollMax[1] > 0f) {
            float trackX = spx + spw - 6f;
            float trackTop = spy + 104f, trackBot = spy + sph - 8f, trackH = trackBot - trackTop;
            float thumbH = Math.max(30f, trackH * (visibleH / contentH));
            float thumbTop = trackTop + (trackH - thumbH) * (scrollY / shopTabScrollMax[1]);
            Paint scrollP = fill(Color.argb(120, 200, 200, 255));
            c.drawRoundRect(trackX - 3f, thumbTop, trackX + 3f, thumbTop + thumbH, 3f, 3f, scrollP);
        }
    }
    private void handleShopTap(float x, float y) {
        Player lp=localPlayer; if(lp==null) return;

        // Tab switch (fixed UI — no scroll offset)
        if(shopTabGuns!=null   && shopTabGuns.contains(x,y))   { shopTab=0; shopTabScrollY[0]=0f; return; }
        if(shopTabSkills!=null && shopTabSkills.contains(x,y)) { shopTab=1; shopTabScrollY[1]=0f; return; }

        // Item rows are drawn with scroll offset applied, so adjust tap Y by current scroll
        float sy = y + shopTabScrollY[shopTab];

        if(shopTab==0){
            // Weapon purchases — shopBuyRects are at fixed content coords
            // FIX: was i<20, which skipped Soul Reaper at index 20
            for(int i=0;i<shopBuyRects.length;i++){
                if(shopBuyRects[i]!=null&&shopBuyRects[i].contains(x,sy)){
                    if(!lp.unlockedGuns[i]&&lp.coins>=GUN_PRICES[i]){
                        lp.coins-=GUN_PRICES[i];
                        int unlockedCount=0;
                        for(boolean u:lp.unlockedGuns) if(u) unlockedCount++;
                        if(unlockedCount>=2){
                            for(int j=0;j<7;j++){
                                if(lp.unlockedGuns[j]&&j!=lp.gunIndex){ lp.unlockedGuns[j]=false; break; }
                            }
                        }
                        lp.unlockedGuns[i]=true;
                    }
                    return;
                }
            }
        } else {
            // Passive skill purchases
            int[] passLevels ={lp.skillReload,lp.skillFireRate,lp.skillRange,lp.skillMoveSpeed};
            for(int i=0;i<4;i++){
                if(passiveBuyRects[i]!=null&&passiveBuyRects[i].contains(x,sy)){
                    int lv=passLevels[i];
                    if(lv<3){
                        int cost=PASSIVE_SKILL_COSTS[lv];
                        if(lp.coins>=cost){
                            lp.coins-=cost;
                            if(i==0) lp.skillReload++;
                            else if(i==1) lp.skillFireRate++;
                            else if(i==2) lp.skillRange++;
                            else          lp.skillMoveSpeed++;
                        }
                    }
                    return;
                }
            }
            // Active skill purchases (buy = equip, replaces current)
            int[] actTypes={Player.ACTIVE_DASH,Player.ACTIVE_STEALTH,Player.ACTIVE_HEAL,Player.ACTIVE_SHIELD};
            for(int i=0;i<4;i++){
                if(activeBuyRects[i]!=null&&activeBuyRects[i].contains(x,sy)){
                    if(lp.activeSkillType!=actTypes[i]){
                        int cost=ACTIVE_SKILL_COSTS[i];
                        if(lp.coins>=cost){
                            lp.coins-=cost;
                            lp.activeSkillType=actTypes[i];
                            lp.skillCooldownEnd=0; lp.skillActiveUntil=0; lp.shieldHp=0;
                        }
                    }
                    return;
                }
            }
        }
    }

    // ═══ NETWORK SERIALIZE ════════════════════════════════════════════════════
    private void broadcast(){
        try{
            JSONObject root=new JSONObject();
            JSONArray pa=new JSONArray();
            Player lp=localPlayer; if(lp!=null) pa.put(pj(lp));
            for(Player p:remote.values()) pa.put(pj(p));
            root.put("p",pa);
            // Bullets — cap at 100 to keep UDP packet inside buffer limits
            JSONArray ba=new JSONArray();
            int bCount=0;
            for(Bullet b:bullets){
                if(bCount++>=100) break;
                JSONObject bj=new JSONObject();
                bj.put("x",(int)b.x); bj.put("y",(int)b.y);
                bj.put("u",(int)b.dx); bj.put("v",(int)b.dy);
                bj.put("o",b.ownerId); bj.put("d",(int)b.damage); bj.put("i",b.id);
                ba.put(bj);
            }
            root.put("b",ba);
            // Bombs — full physics state so clients render them correctly
            JSONArray bma=new JSONArray();
            for(Bomb b:activeBombs){
                JSONObject bj=new JSONObject();
                bj.put("x",b.x); bj.put("y",b.y); bj.put("o",b.ownerId);
                bj.put("vx",b.vx); bj.put("vy",b.vy);
                bj.put("rx",b.rollVx); bj.put("ry",b.rollVy);
                bj.put("mr",b.maxRange);
                bj.put("ln",b.hasLanded); bj.put("ea",b.explodedAt);
                bj.put("dt",b.deployTime);
                bma.put(bj);
            }
            root.put("bm",bma);
            // VoltChakrams — positions + state for all active discs
            JSONArray vca=new JSONArray();
            for(VoltChakram vc:voltChakrams){
                JSONObject vcj=new JSONObject();
                vcj.put("o",vc.ownerId); vcj.put("x",(int)vc.x); vcj.put("y",(int)vc.y);
                vcj.put("st",vc.state); vcj.put("oi",vc.orbitIdx);
                vcj.put("vx",(int)vc.vx); vcj.put("vy",(int)vc.vy);
                vcj.put("d",(int)vc.damage); vcj.put("dt",(int)vc.distTraveled); vcj.put("mr",(int)vc.maxRange);
                vcj.put("sa",(int)(vc.spinAngle*100)); // sync self-spin angle
                vca.put(vcj);
            }
            root.put("vc",vca);
            // FIX: Sync airStrikes to clients so they see warning circles and explosions.
            // Previously absent — clients saw no airstrike visuals at all.
            JSONArray asa = new JSONArray();
            for (double[] as : airStrikes) {
                JSONObject asj = new JSONObject();
                asj.put("ax",(int)as[0]); asj.put("ay",(int)as[1]);
                asj.put("at",(long)as[2]);  // trigger time (epoch ms)
                asj.put("ao",(int)as[3]);   // ownerId
                asj.put("af",(long)as[4]);  // flashUntil (0 = not yet exploded)
                asa.put(asj);
            }
            root.put("as",asa);
            broadcastSnapshot = root.toString(); // hand off to sender thread — never blocks game loop
        }catch(Exception e){ e.printStackTrace(); }
    }
    private JSONObject pj(Player p) throws Exception {
        JSONObject o=new JSONObject();
        o.put("i",p.id); o.put("n",p.name);
        o.put("x",(int)p.x); o.put("y",(int)p.y);
        o.put("a",(double)p.angle);
        o.put("h",(int)p.hp); o.put("g",p.gunIndex); o.put("v",p.alive);
        o.put("c",p.coins);
        o.put("sr",p.skillReload); o.put("sf",p.skillFireRate);
        o.put("sg",p.skillRange);  o.put("sm",p.skillMoveSpeed);
        o.put("sa",p.activeSkillType);
        o.put("ss",(int)p.shieldHp);
        long rem=Math.max(0,p.spawnProtectionUntil-System.currentTimeMillis());
        o.put("sp",(int)rem);
        long aRem=Math.max(0,p.skillActiveUntil-System.currentTimeMillis());
        o.put("se",(int)aRem);
        long hpRem=Math.max(0,p.hookPullUntil-System.currentTimeMillis());
        o.put("hpu",(int)hpRem);
        o.put("hpo",p.hookPullOwnerId);
        // FIX: sync status-effect durations so clients render slow/poison/stun rings
        // on remote players. Previously omitted — all rings were invisible on clients.
        o.put("slw",(int)Math.max(0,p.slowUntil  -System.currentTimeMillis()));
        o.put("poi",(int)Math.max(0,p.poisonUntil-System.currentTimeMillis()));
        o.put("stu",(int)Math.max(0,p.stunUntil  -System.currentTimeMillis()));
        return o;
    }
    private void applyState(String json){
        try{
            JSONObject root=new JSONObject(json);
            JSONArray pa=root.getJSONArray("p");
            for(int i=0;i<pa.length();i++){
                JSONObject o=pa.getJSONObject(i);
                int id=o.getInt("i"); boolean alive=o.getBoolean("v");
                float hx=o.getInt("x"), hy=o.getInt("y");
                Player lp=localPlayer;
                if(lp!=null&&id==lp.id){
                    boolean was=lp.alive;
                    lp.hp=o.getInt("h"); lp.alive=alive;
                    lp.coins=o.optInt("c", lp.coins);
                    int spMs=o.optInt("sp",0);
                    if(spMs>0) lp.spawnProtectionUntil=System.currentTimeMillis()+spMs;
                    int hpRem=o.optInt("hpu",0);
                    if(hpRem>0){ lp.hookPullUntil=System.currentTimeMillis()+hpRem; lp.hookPullOwnerId=o.optInt("hpo",-1); }
                    else { lp.hookPullUntil=0; }
                    if(was&&!alive) deathTime=System.currentTimeMillis();
                    // Always reconcile position from host — on LAN ~1ms lag, prevents drift
                    float dx=lp.x-hx, dy=lp.y-hy;
                    if(dx*dx+dy*dy > 40*40){
                        // Only snap if significantly off (>40px) to avoid fighting local prediction
                        lp.x=hx; lp.y=hy;
                    }
                    continue;
                }
                Player p=remote.get(id);
                if(p==null){p=new Player();p.id=id;p.guns=Gun.createAll();remote.put(id,p);}
                p.name=o.getString("n");
                // ── Dead-reckoning: estimate velocity from successive positions ──
                boolean _first = (p.netUpdateMs < 0);
                long _nowMs = System.currentTimeMillis();
                if (!_first) {
                    long _dt = _nowMs - p.netUpdateMs;
                    if (_dt > 5 && _dt < 150) {
                        p.netVX = (hx - p.netX) / (float)_dt;
                        p.netVY = (hy - p.netY) / (float)_dt;
                    }
                } else { p.netVX = 0f; p.netVY = 0f; }
                p.netX = hx; p.netY = hy; p.netUpdateMs = _nowMs;
                p.x = hx; p.y = hy;
                // Smooth aim angle — lerp instead of snap to avoid jitter between packets
                float _ta = (float)o.getDouble("a");
                p.angle = _first ? _ta : lerpAngle(p.angle, _ta, 0.45f);
                p.hp=o.getInt("h");
                p.gunIndex=o.getInt("g"); p.alive=alive;
                p.skillReload   =o.optInt("sr",p.skillReload);
                p.skillFireRate =o.optInt("sf",p.skillFireRate);
                p.skillRange    =o.optInt("sg",p.skillRange);
                p.skillMoveSpeed=o.optInt("sm",p.skillMoveSpeed);
                p.activeSkillType=o.optInt("sa",p.activeSkillType);
                p.shieldHp      =(float)o.optInt("ss",0);
                int spMs=o.optInt("sp",0);
                if(spMs>0) p.spawnProtectionUntil=System.currentTimeMillis()+spMs;
                int aRem=o.optInt("se",0);
                if(aRem>0) p.skillActiveUntil=System.currentTimeMillis()+aRem;
                int hpRem=o.optInt("hpu",0);
                if(hpRem>0){ p.hookPullUntil=System.currentTimeMillis()+hpRem; p.hookPullOwnerId=o.optInt("hpo",-1); }
                else { p.hookPullUntil=0; }
                // FIX: restore status-effect timestamps so slow/poison/stun rings render on clients
                int slwRem=o.optInt("slw",0);   p.slowUntil   = slwRem>0 ? System.currentTimeMillis()+slwRem : 0;
                int poiRem=o.optInt("poi",0);   p.poisonUntil = poiRem>0 ? System.currentTimeMillis()+poiRem : 0;
                int stuRem=o.optInt("stu",0);   p.stunUntil   = stuRem>0 ? System.currentTimeMillis()+stuRem : 0;
            }
            // ── Bullets ──────────────────────────────────────────────────────
            JSONArray ba=root.getJSONArray("b");
            bullets.clear();
            for(int i=0;i<ba.length();i++){
                JSONObject bj=ba.getJSONObject(i);
                bullets.add(new Bullet(bj.getInt("x"),bj.getInt("y"),
                    bj.getInt("u"),bj.getInt("v"),
                    bj.getInt("o"),bj.getInt("d"),bj.getInt("i"),Float.MAX_VALUE));
            }
            // ── Bombs ─────────────────────────────────────────────────────────
            JSONArray bma=root.optJSONArray("bm");
            if(bma!=null){
                activeBombs.clear();
                for(int i=0;i<bma.length();i++){
                    JSONObject bj=bma.getJSONObject(i);
                    Bomb b=new Bomb((float)bj.getDouble("x"),(float)bj.getDouble("y"),bj.getInt("o"));
                    b.vx=(float)bj.getDouble("vx"); b.vy=(float)bj.getDouble("vy");
                    b.rollVx=(float)bj.getDouble("rx"); b.rollVy=(float)bj.getDouble("ry");
                    b.maxRange=(float)bj.getDouble("mr");
                    b.hasLanded=bj.getBoolean("ln");
                    b.explodedAt=bj.getLong("ea");
                    b.deployTime=bj.getLong("dt");
                    activeBombs.add(b);
                }
            }
            // ── VoltChakrams ──────────────────────────────────────────────────
            JSONArray vca=root.optJSONArray("vc");
            if(vca!=null){
                int lpId=localPlayer!=null?localPlayer.id:-1;
                voltChakrams.removeIf(vc->vc.ownerId!=lpId); // keep local discs, replace remote
                for(int i=0;i<vca.length();i++){
                    JSONObject vcj=vca.getJSONObject(i);
                    int oid=vcj.getInt("o");
                    if(oid==lpId) continue; // local player manages own discs
                    VoltChakram vc=new VoltChakram(oid,vcj.optInt("oi",-1));
                    vc.x=vcj.getInt("x"); vc.y=vcj.getInt("y");
                    vc.state=vcj.getInt("st");
                    vc.vx=vcj.getInt("vx"); vc.vy=vcj.getInt("vy");
                    vc.damage=vcj.getInt("d"); vc.distTraveled=vcj.getInt("dt"); vc.maxRange=vcj.getInt("mr");
                    vc.spinAngle=vcj.optInt("sa",0)/100f; // restore synced spin angle
                    voltChakrams.add(vc);
                }
            }
            // FIX: Receive host's authoritative airStrikes list so clients render
            // warning circles and explosion flashes for all players' air strikes.
            JSONArray asa = root.optJSONArray("as");
            if (asa != null) {
                airStrikes.clear();
                for (int i = 0; i < asa.length(); i++) {
                    JSONObject asj = asa.getJSONObject(i);
                    airStrikes.add(new double[]{
                        asj.getDouble("ax"), asj.getDouble("ay"),
                        asj.getLong("at"),   asj.getInt("ao"),
                        asj.getLong("af")
                    });
                }
            }
        }catch(Exception e){ e.printStackTrace(); }
    }
    private void sendInput(Player lp){
        try{
            JSONObject o=new JSONObject();
            // Joystick (kept for host-side angle/aim logic)
            o.put("0",moveStick.getX()); o.put("1",moveStick.getY());
            o.put("2",aimStick.getX());  o.put("3",aimStick.getY());
            float _ax=aimStick.getX(), _ay=aimStick.getY();
            float _ft=getFireThresh();
            o.put("4", aimStick.isActive() && (_ax*_ax+_ay*_ay) > _ft*_ft);
            o.put("5",lp.gunIndex);
            o.put("6",lp.currentGun().reloading);
            // ── Authoritative client position (avoids dual-simulation drift) ──
            o.put("px", lp.x); o.put("py", lp.y);
            // Passive skill levels
            o.put("7",lp.skillReload);
            o.put("8",lp.skillFireRate);
            o.put("9",lp.skillRange);
            o.put("10",lp.skillMoveSpeed);
            // Active skill
            o.put("11",lp.activeSkillType);
            // FIX Bug6: send ms (not seconds) — previously /1000 caused up to 999ms
            // of early expiry for stealth/shield on the host and other clients.
            long msRem=Math.max(0,lp.skillActiveUntil-System.currentTimeMillis());
            o.put("12",msRem);
            o.put("13",lp.shieldHp);
            // FIX Bug5: Heal event flag — host applies hp+40 on its authoritative copy.
            // Heal is instant (no skillActiveUntil) so host had no way to learn about it,
            // and overwrote the healed hp within 33ms via state update.
            o.put("hlt", pendingHealEvent ? 1 : 0);
            pendingHealEvent = false;
            // Dash position override (already folded into px/py above; flag kept for compat)
            o.put("14", pendingPositionSync ? 1 : 0);
            pendingPositionSync = false;
            // ── Pending bomb throw ─────────────────────────────────────────────
            if (pendingBombSend != null) {
                o.put("bt", 1);
                o.put("bvx", pendingBombSend[0]);
                o.put("bvy", pendingBombSend[1]);
                o.put("bmr", pendingBombSend[2]);
                pendingBombSend = null;
            } else {
                o.put("bt", 0);
            }
            // ── Pending Volt Chakram launch ────────────────────────────────────
            if (pendingVoltLaunch != null) {
                o.put("vcl", 1);
                o.put("vcax", pendingVoltLaunch[0]);
                o.put("vcay", pendingVoltLaunch[1]);
                o.put("vcc",  pendingVoltLaunch[2]);
                pendingVoltLaunch = null;
            } else {
                o.put("vcl", 0);
            }
            net.sendInput(o.toString());
        }catch(Exception e){ if(net!=null) e.printStackTrace(); }
    }

    // ═══ CALLBACKS ════════════════════════════════════════════════════════════
    @Override public void onHostDiscovered(String ip,String n){}
    @Override public void onJoined(int id){
        // Network thread — just assign (volatile reference, atomic)
        Player p=new Player(); p.id=id; p.name=savedName; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true;  // ← must be set or client stays "dead" forever
        localPlayer=p;
    }
    @Override public void onPlayerJoined(int id,String name){
        if(remote.containsKey(id)) return;
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true;
        remote.put(id,p); addFeed(name+" joined");
    }
    @Override public void onStateUpdate(String json){ pendingState=json; }
    @Override public void onDisconnected(){
        addFeed("⚠ Disconnected — reconnecting…");
    }
    @Override public void onInputReceived(int pid,String json){
        try{
            JSONObject o=new JSONObject(json);
            inputs.put(pid,new float[]{
                (float)o.getDouble("0"),(float)o.getDouble("1"),
                (float)o.getDouble("2"),(float)o.getDouble("3"),
                o.getBoolean("4")?1f:0f,(float)o.getInt("5"),o.getBoolean("6")?1f:0f,
                (float)o.optInt("7",0),(float)o.optInt("8",0),
                (float)o.optInt("9",0),(float)o.optInt("10",0),
                (float)o.optInt("11",0),(float)o.optLong("12",0),
                (float)o.optDouble("13",0),
                (float)o.optDouble("px",-1),   // [14] authoritative x (-1 = not provided)
                (float)o.optDouble("py",-1),   // [15] authoritative y
                (float)o.optInt("14",0),        // [16] dash flag (unused now, kept for compat)
                (float)o.optInt("hlt",0)        // [17] FIX Bug5: heal event flag
            });
            // FIX: Queue bomb/VC events instead of touching ArrayLists directly from the
            // network thread.  activeBombs and voltChakrams are plain ArrayLists; concurrent
            // modification from two threads causes ConcurrentModificationException crashes.
            // The game thread drains both queues inside drainNetEvents() each frame.
            if(o.optInt("bt",0)==1){
                Player p=remote.get(pid);
                if(p!=null&&p.alive&&p.bombs>0){
                    p.bombs--;
                    netBombQ.add(new float[]{pid, p.x, p.y,
                        (float)o.getDouble("bvx"),
                        (float)o.getDouble("bvy"),
                        (float)o.getDouble("bmr")});
                }
            }
            // ── Volt Chakram launch from client — queued for game thread ──────
            if(o.optInt("vcl",0)==1){
                Player p=remote.get(pid);
                if(p!=null&&p.alive&&isVoltChakram(p.currentGun())){
                    netVcQ.add(new float[]{pid,
                        (float)o.getDouble("vcax"),
                        (float)o.getDouble("vcay"),
                        (float)o.getDouble("vcc")});
                }
            }
        }catch(Exception e){ e.printStackTrace(); }
    }

    // ═══ UTIL ═════════════════════════════════════════════════════════════════
    private static float d2(float ax,float ay,float bx,float by){float dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private String nameOf(int id){
        Player lp=localPlayer; if(lp!=null&&id==lp.id) return lp.name;
        Player p=remote.get(id); return p!=null?p.name:"P"+id;
    }
    private void addFeed(String msg){
        synchronized(feed){feed.add(0,msg);if(feed.size()>4)feed.remove(feed.size()-1);}
    }

    /**
     * FIX: Drains bomb and Volt-Chakram creation events that were queued by the
     * network thread into game-thread-owned ArrayLists (activeBombs, voltChakrams).
     * Must only be called from the game thread (inside update()).
     */
    private void drainNetEvents() {
        float[] be;
        while ((be = netBombQ.poll()) != null) {
            int bpid = (int) be[0];
            Player bp = remote.get(bpid);
            if (bp != null && bp.alive) {
                // Duplicate check is now safe — we are on the game thread
                boolean hasBomb = false;
                for (Bomb b : activeBombs)
                    if (b.ownerId == bp.id && !b.isDone() && b.explodedAt < 0) { hasBomb = true; break; }
                if (!hasBomb) {
                    Bomb bomb = new Bomb(be[1], be[2], bpid);
                    bomb.vx = be[3]; bomb.vy = be[4]; bomb.maxRange = be[5];
                    activeBombs.add(bomb);
                }
            }
        }
        float[] ve;
        while ((ve = netVcQ.poll()) != null) {
            int vpid = (int) ve[0];
            Player vp = remote.get(vpid);
            if (vp != null && vp.alive && isVoltChakram(vp.currentGun()))
                launchVoltChakrams(vp, ve[1], ve[2], ve[3]);
        }
    }
}
