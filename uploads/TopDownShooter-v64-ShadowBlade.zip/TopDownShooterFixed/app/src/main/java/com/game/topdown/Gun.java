package com.game.topdown;

public class Gun {
    public String name;
    public int    maxAmmo, ammo;
    public float  fireRate, damage, bulletSpeed, spread, zoom, range;
    public int    pellets, color;
    public long   reloadMs;

    // runtime state
    public boolean reloading;
    public volatile long    reloadStart, lastFireTime;

    public boolean canFireNow() {
        if (ammo <= 0 || reloading) return false;
        return System.currentTimeMillis() - lastFireTime >= (long)(1000f / fireRate);
    }
    public void markFired() { lastFireTime = System.currentTimeMillis(); }

    public void startReload() {
        if (!reloading && ammo < maxAmmo) { reloading = true; reloadStart = System.currentTimeMillis(); }
    }
    public void tick() { tick(1.0f); }
    public void tick(float reloadMult) {
        if (reloading && System.currentTimeMillis() - reloadStart >= (long)(reloadMs * reloadMult)) {
            ammo = maxAmmo; reloading = false;
        }
    }

    // ── Special-mechanic flags (read by spawnBullets) ────────────────────────
    public int     bulletBounces;   // how many wall bounces each bullet gets
    public boolean bulletPiercing;  // bullet passes through enemies
    public boolean bulletExplosive; // bullet detonates on wall/range
    public boolean bulletHoming;    // bullet steers toward enemies
    public boolean bulletGhost;     // bullet ignores walls
    public boolean bulletHookSpear;  // chained spear: pull + stun on hit
    public boolean bulletAirStrike;  // triggers an air strike — no real bullet
    public boolean bulletShadowBlade; // hold-charge dash-slash (Benedetta style)

    // ── Paint Launcher: color applied to bullets ───────────────────────────────
    // 0 = normal, 1 = blue (slow), 2 = green (poison), 3 = per-shot alternating (poison first, then slow)
    public int paintBulletColor = 0;
    public int paintShotToggle  = 2;  // 2=poison first, flips to 1=slow each shot

    // ── Coin Gun: damage scales with carrier's coin wealth ─────────────────────
    public boolean coinScaling = false;

    // ── Soul Reaper: grows stronger with each kill ─────────────────────────────
    public int killCount    = 0;   // total kills scored while holding this gun
    public int lastSoulLevel= -1;  // last applied tier, so we upgrade exactly once per tier

    /** Returns 0-5 based on cumulative kills. */
    public int soulLevel() {
        if (killCount >= 15) return 5;
        if (killCount >= 10) return 4;
        if (killCount >=  6) return 3;
        if (killCount >=  3) return 2;
        if (killCount >=  1) return 1;
        return 0;
    }

    /** Next-tier kill threshold, or -1 if maxed. */
    public int soulNextThreshold() {
        int[] thresholds = {1, 3, 6, 10, 15};
        for (int t : thresholds) if (killCount < t) return t;
        return -1;
    }

    /**
     * Called each time a Soul Reaper bullet registers a kill.
     * Upgrades live gun stats to the new tier if the level increased.
     */
    public void applySoulLevel() {
        int lv = soulLevel();
        if (lv <= lastSoulLevel) return;
        lastSoulLevel = lv;
        // ── Tier stats ────────────────────────────────────────────────────────
        switch (lv) {
            case 1: damage=20f; fireRate=1.8f; maxAmmo= 8; bulletPiercing=false; bulletBounces=0; bulletHoming=false; bulletExplosive=false; break;
            case 2: damage=30f; fireRate=2.5f; maxAmmo=10; bulletPiercing=true;  bulletBounces=0; bulletHoming=false; bulletExplosive=false; break;
            case 3: damage=45f; fireRate=3.0f; maxAmmo=12; bulletPiercing=true;  bulletBounces=2; bulletHoming=false; bulletExplosive=false; break;
            case 4: damage=60f; fireRate=4.0f; maxAmmo=15; bulletPiercing=true;  bulletBounces=2; bulletHoming=true;  bulletExplosive=false; break;
            case 5: damage=80f; fireRate=5.0f; maxAmmo=18; bulletPiercing=true;  bulletBounces=2; bulletHoming=true;  bulletExplosive=true;  break;
        }
        // Refill ammo to new clip size on level-up (feels rewarding)
        ammo = maxAmmo;
    }

    // ── Per-gun status effect durations (set by GunConfig, used by spawnBullets) ─
    public long  slowMs        = StatusEffectConfig.SLOW_DURATION_MS;
    public float slowSpeedMult = StatusEffectConfig.SLOW_SPEED_MULT;   // 0.4 = 40% speed
    public long  poisonMs      = StatusEffectConfig.POISON_DURATION_MS;
    public float poisonDmg     = StatusEffectConfig.POISON_TICK_DAMAGE;
    public long  stunBonusMs   = StatusEffectConfig.HOOK_STUN_BONUS_MS;
    public float explosionDmg  = StatusEffectConfig.EXPLOSION_DAMAGE;  // AOE blast damage

    // ── Normalised stat accessors (0–1) for HUD stat bars ─────────────────────
    static final float MAX_DMG   = 95f;
    static final float MAX_SPD   = 1700f;
    static final float MAX_RANGE = 2100f;
    static final float MAX_RATE  = 22f;

    public float statDamage()   { return Math.min(1f, damage       / MAX_DMG);   }
    public float statSpeed()    { return Math.min(1f, bulletSpeed  / MAX_SPD);   }
    public float statRange()    { return Math.min(1f, range        / MAX_RANGE); }
    public float statFireRate() { return Math.min(1f, fireRate     / MAX_RATE);  }

    public static Gun[] createAll() {
        return new Gun[]{pistol(), smg(), shotgun(), assault(), sniper(), burst(), minigun(),
                         revolver(), lmg(), plasma(),
                         bouncer(), piercer(), seeker(), blaster(),
                         ghost(), paintLauncher(), coinGun(), voltChakram(), hookSpear(), airStrike(),
                         soulReaper(), shadowBlade()};
    }

    // ── Factory methods — stats come from GunConfig.STATS, edit there ─────────
    public static Gun pistol()       { return GunConfig.apply(new Gun(), 0);  }
    public static Gun smg()          { return GunConfig.apply(new Gun(), 1);  }
    public static Gun shotgun()      { return GunConfig.apply(new Gun(), 2);  }
    public static Gun assault()      { return GunConfig.apply(new Gun(), 3);  }
    public static Gun sniper()       { return GunConfig.apply(new Gun(), 4);  }
    public static Gun burst()        { return GunConfig.apply(new Gun(), 5);  }
    public static Gun minigun()      { return GunConfig.apply(new Gun(), 6);  }
    public static Gun revolver()     { return GunConfig.apply(new Gun(), 7);  }
    public static Gun lmg()          { return GunConfig.apply(new Gun(), 8);  }
    public static Gun plasma()       { return GunConfig.apply(new Gun(), 9);  }
    public static Gun bouncer()      { return GunConfig.apply(new Gun(), 10); }
    public static Gun piercer()      { return GunConfig.apply(new Gun(), 11); }
    public static Gun seeker()       { return GunConfig.apply(new Gun(), 12); }
    public static Gun blaster()      { return GunConfig.apply(new Gun(), 13); }
    public static Gun ghost()        { return GunConfig.apply(new Gun(), 14); }
    public static Gun paintLauncher(){ return GunConfig.apply(new Gun(), 15); }
    public static Gun coinGun()      { return GunConfig.apply(new Gun(), 16); }
    public static Gun voltChakram()  { return GunConfig.apply(new Gun(), 17); }
    public static Gun hookSpear()    { return GunConfig.apply(new Gun(), 18); }
    public static Gun airStrike()    { return GunConfig.apply(new Gun(), 19); }
    public static Gun soulReaper()   { return GunConfig.apply(new Gun(), 20); }
    public static Gun shadowBlade()  { return GunConfig.apply(new Gun(), 21); }
}
