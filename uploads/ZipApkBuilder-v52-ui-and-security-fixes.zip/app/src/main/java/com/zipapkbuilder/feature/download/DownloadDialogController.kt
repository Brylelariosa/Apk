package com.zipapkbuilder.feature.download

import android.app.AlertDialog
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.core.iconButton
import com.zipapkbuilder.core.pillButton
import com.zipapkbuilder.model.DownloadTask

/**
 * The Download Manager dialog: a live-refreshing list of every task in
 * [downloadQueue], each row showing progress/status and whichever of
 * Pause/Resume/Cancel/Retry/Remove currently applies. Split out of
 * [DownloadManager] as the one purely-UI piece — it only ever reads
 * [downloadQueue]'s state and forwards button taps back into it
 * ([DownloadQueue.retry], [DownloadQueue.resume], [DownloadQueue.remove],
 * [DownloadQueue.removeFinished]), never runs a transfer itself.
 */
class DownloadDialogController(
    private val activity: MainActivity,
    private val downloadQueue: DownloadQueue
) {
    /** Tracks whether the manager is currently on screen, so submitting a new
     *  download while it's already open updates it instead of stacking a
     *  second dialog on top. */
    private var downloadManagerShowing = false

    /** A cheap fingerprint of the last rendered [DownloadQueue] snapshot — see
     *  [renderDownloadRows]'s `force` parameter for how this is used to skip
     *  a full rebuild on refresh ticks where nothing actually changed. */
    private var lastRenderedFingerprint: String? = null

    /**
     * Shows every [DownloadTask] the app currently knows about — queued,
     * downloading, paused, completed, failed, or cancelled — with per-row
     * controls, and refreshes itself every 400ms while open so progress moves
     * live. Downloads keep running via [DownloadQueue] whether or not this
     * dialog is open; opening it just starts watching what's already
     * happening, and closing it doesn't pause or cancel anything.
     */
    fun showDownloadManagerDialog() {
        if (downloadManagerShowing) return
        val dp = activity.resources.displayMetrics.density

        val listContainer = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(activity).apply {
            addView(listContainer)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (420 * dp).toInt()
            )
        }

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF13162A.toInt())
            addView(scroll)
        }

        // refresh(true) is what actually makes row buttons feel responsive: every
        // Pause/Resume/Cancel/Retry/Remove tap (and Clear Finished, below) runs
        // through onChanged, which calls this immediately — instead of the old
        // no-op onChanged that left the dialog to catch up on whatever the next
        // 400ms tick happened to notice. buildDownloadTaskRow also renders an
        // optimistic in-flight state ("Pausing…"/"Resuming…"/"Cancelling…") the
        // instant a button is tapped, since the field it just set
        // (pauseRequested/cancelRequested) doesn't flip task.status by itself — a
        // download-worker thread still needs to notice it, which force-rendering
        // alone can't skip past. Together, the tap is reflected on screen
        // immediately even though the underlying transfer thread catches up a
        // beat later.
        lateinit var refresh: (Boolean) -> Unit
        refresh = { force -> renderDownloadRows(listContainer, dp, force) { refresh(true) } }

        // Declared up front so the close button built into titleBar below can
        // dismiss the same dialog instance the button row also uses.
        lateinit var dialog: AlertDialog

        val titleBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF1C2038.toInt())
            setPadding((18*dp).toInt(), (16*dp).toInt(), (10*dp).toInt(), (12*dp).toInt())
            addView(android.widget.ImageView(activity).apply {
                setImageResource(R.drawable.ic_download)
                imageTintList = android.content.res.ColorStateList.valueOf(0xFF4DA6FF.toInt())
                layoutParams = LinearLayout.LayoutParams((18*dp).toInt(), (18*dp).toInt()).also {
                    it.marginEnd = (10*dp).toInt()
                }
            })
            addView(TextView(activity).apply {
                text = "Download Manager"; textSize = 15f
                setTypeface(null, android.graphics.Typeface.BOLD)
                setTextColor(0xFFE8EAED.toInt())
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            val clearFinishedBtn = activity.pillButton(
                "Clear finished", ButtonTone.SURFACE, R.drawable.ic_delete,
                textSizeSp = 10.5f, iconSizeDp = 12, horizontalPaddingDp = 8, verticalPaddingDp = 6
            ) {
                downloadQueue.removeFinished()
                refresh(true)
            }
            clearFinishedBtn.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (8 * dp).toInt() }
            addView(clearFinishedBtn)
            addView(activity.iconButton(R.drawable.ic_close, 0xFF9AA0B8.toInt()) { dialog.dismiss() }.apply {
                contentDescription = "Close"
            })
        }

        val content = activity.dialogWithActions(
            root,
            DialogAction("Close", ButtonTone.SURFACE, R.drawable.ic_close) { dialog.dismiss() }
        )
        dialog = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(titleBar)
            .setView(content)
            .setCancelable(true)
            .create()

        lastRenderedFingerprint = null // force the very first render regardless of any stale value
        refresh(true)

        // Live refresh loop: reflects progress/status changes made by
        // download-worker threads without the user needing to reopen this
        // dialog. Cancels itself the moment the dialog is no longer showing —
        // this is the ONLY place that happens, so it can never leak/keep
        // running after the dialog is dismissed. Each tick is `force = false`:
        // renderDownloadRows itself skips rebuilding anything when nothing in
        // the snapshot actually changed since the last render (see its kdoc),
        // so an idle dialog (e.g. every task already terminal) does no
        // teardown/rebuild work at all on most ticks, not just a lighter one.
        val refreshHandler = Handler(Looper.getMainLooper())
        lateinit var refreshRunnable: Runnable
        refreshRunnable = Runnable {
            if (!downloadManagerShowing) return@Runnable
            refresh(false)
            refreshHandler.postDelayed(refreshRunnable, 400)
        }
        refreshHandler.postDelayed(refreshRunnable, 400)

        downloadManagerShowing = true
        dialog.setOnDismissListener { downloadManagerShowing = false }
        dialog.show()
    }

    /**
     * Rebuilds every row in [container] from the current [downloadQueue]
     * snapshot — unless [force] is false and nothing about the snapshot has
     * actually changed since the last render (compared via a cheap
     * fingerprint of every task's id/status/progress/speed/ETA/error), in
     * which case this returns immediately without touching a single View.
     * The periodic 400ms refresh tick always passes `force = false`, so a
     * dialog left open with every task already in a terminal state (or,
     * before that, simply between two progress ticks close enough together
     * that the displayed percentage wouldn't change) does no
     * teardown-then-rebuild work at all most of the time, rather than
     * rebuilding the same rows from scratch 2.5 times a second regardless.
     * [force] is true for the initial render and any explicit user action
     * (Clear Finished) that must be reflected immediately.
     *
     * Still rebuilds wholesale (rather than diffing row-by-row) when it does
     * decide to render — that part matches how every other list in this app
     * (build/download history) is already drawn, and is cheap enough at the
     * realistic scale of a handful of concurrent/queued downloads; the
     * fingerprint check above is what actually removes the redundant work,
     * not a finer-grained diff. [onChanged] runs after any button in a row
     * mutates task state, so the dialog can reflect it immediately rather
     * than waiting for the next tick.
     */
    private fun renderDownloadRows(container: LinearLayout, dp: Float, force: Boolean, onChanged: () -> Unit) {
        val snapshot = downloadQueue.snapshot()
        val fingerprint = snapshot.joinToString("|") { t ->
            "${t.id}:${t.status}:${t.downloadedBytes}:${t.totalBytes}:${t.speedBps}:${t.etaSeconds}:${t.errorMessage}"
        }
        if (!force && fingerprint == lastRenderedFingerprint) return
        lastRenderedFingerprint = fingerprint

        container.removeAllViews()

        if (snapshot.isEmpty()) {
            container.addView(TextView(activity).apply {
                text = "No downloads yet.\nArtifact and log downloads you start will appear here."
                textSize = 12f; setTextColor(0xFF50587A.toInt())
                gravity = android.view.Gravity.CENTER
                setPadding((24*dp).toInt(), (40*dp).toInt(), (24*dp).toInt(), (40*dp).toInt())
            })
            return
        }

        for (task in snapshot) {
            container.addView(buildDownloadTaskRow(task, dp, onChanged))
            container.addView(android.view.View(activity).apply {
                setBackgroundColor(0xFF232747.toInt())
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
            })
        }
    }

    /** Builds one row for [task]: name, status/progress, and whichever of
     *  Pause/Resume/Cancel/Retry currently apply to its status. */
    private fun buildDownloadTaskRow(task: DownloadTask, dp: Float, onChanged: () -> Unit): View {
        val statusColor = when (task.status) {
            DownloadTask.Status.COMPLETED -> 0xFF2ECC71.toInt()
            DownloadTask.Status.FAILED    -> 0xFFE74C3C.toInt()
            DownloadTask.Status.CANCELLED -> 0xFF9AA0B8.toInt()
            DownloadTask.Status.PAUSED, DownloadTask.Status.WAITING_FOR_NETWORK -> 0xFFF5A623.toInt()
            else        -> 0xFF5B8DEF.toInt()
        }

        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((18*dp).toInt(), (12*dp).toInt(), (18*dp).toInt(), (12*dp).toInt())
        }

        row.addView(TextView(activity).apply {
            text = task.displayName; textSize = 12.5f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFE8EAED.toInt())
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        })

        val pct = if (task.totalBytes > 0) (task.downloadedBytes * 1000L / task.totalBytes).toInt() else 0
        val statusLine = when {
            // These three all set a field the worker thread must still notice on its own
            // schedule (see DownloadEngine's copy loop) — task.status itself doesn't
            // change the instant the button is tapped. Checking the flag directly here,
            // ahead of the task.status switch below, is what makes the tap show *something*
            // different immediately rather than looking unchanged until the worker catches up.
            task.cancelRequested && !task.isTerminal -> "✗ Cancelling…"
            task.status == DownloadTask.Status.DOWNLOADING && task.pauseRequested -> "⏸ Pausing…"
            task.status == DownloadTask.Status.PAUSED && !task.pauseRequested -> "▶ Resuming…"
            else -> when (task.status) {
                DownloadTask.Status.QUEUED       -> "Queued…"
                DownloadTask.Status.CONNECTING   -> task.detailText.ifEmpty { "Connecting…" }
                DownloadTask.Status.DOWNLOADING  -> {
                    val sizeStr = if (task.totalBytes > 0)
                        "${Formatters.fmtBytes(task.downloadedBytes)} / ${Formatters.fmtBytes(task.totalBytes)}" else Formatters.fmtBytes(task.downloadedBytes)
                    val etaStr = if (task.etaSeconds >= 0) " · ETA ${Formatters.fmtDuration(task.etaSeconds * 1000)}" else ""
                    "$sizeStr · ${Formatters.fmtBytes(task.speedBps)}/s$etaStr"
                }
                DownloadTask.Status.PAUSED              -> "⏸ Paused — ${Formatters.fmtBytes(task.downloadedBytes)} so far"
                DownloadTask.Status.WAITING_FOR_NETWORK -> task.detailText
                DownloadTask.Status.RETRYING            -> task.detailText
                DownloadTask.Status.VERIFYING           -> "Verifying…"
                DownloadTask.Status.SAVING              -> "Saving…"
                DownloadTask.Status.COMPLETED           -> "✓ Saved to Downloads"
                DownloadTask.Status.FAILED              -> "✗ ${task.errorMessage ?: "Failed"}"
                DownloadTask.Status.CANCELLED           -> "Cancelled"
            }
        }
        row.addView(TextView(activity).apply {
            text = statusLine; textSize = 10.5f
            setTextColor(statusColor)
            maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, (3*dp).toInt(), 0, (6*dp).toInt())
        })

        // Progress bar only while there's real progress to show.
        if (task.status == DownloadTask.Status.DOWNLOADING || task.status == DownloadTask.Status.PAUSED || task.status == DownloadTask.Status.RETRYING) {
            row.addView(android.widget.ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 1000; progress = pct
                progressDrawable = android.graphics.drawable.LayerDrawable(arrayOf(
                    android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt()),
                    android.graphics.drawable.ClipDrawable(
                        android.graphics.drawable.ColorDrawable(statusColor),
                        android.view.Gravity.START, android.graphics.drawable.ClipDrawable.HORIZONTAL
                    )
                )).also { ld -> ld.setId(0, android.R.id.background); ld.setId(1, android.R.id.progress) }
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, (6*dp).toInt())
                    .also { it.bottomMargin = (8*dp).toInt() }
            })
        }

        val btnRow = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        fun smallBtn(label: String, tone: ButtonTone, iconRes: Int, onClick: () -> Unit) =
            activity.pillButton(label, tone, iconRes, textSizeSp = 10.5f, iconSizeDp = 13) {
                onClick(); onChanged()
            }.also { it.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { lp -> lp.marginEnd = (8*dp).toInt() } }

        when (task.status) {
            DownloadTask.Status.DOWNLOADING, DownloadTask.Status.CONNECTING, DownloadTask.Status.RETRYING, DownloadTask.Status.WAITING_FOR_NETWORK -> {
                btnRow.addView(smallBtn("Pause", ButtonTone.BLUE, R.drawable.ic_pause) { task.pauseRequested = true })
                btnRow.addView(smallBtn("Cancel", ButtonTone.RED, R.drawable.ic_close) { task.cancelRequested = true })
            }
            DownloadTask.Status.PAUSED -> {
                btnRow.addView(smallBtn("Resume", ButtonTone.GREEN, R.drawable.ic_play) { downloadQueue.resume(task) })
                btnRow.addView(smallBtn("Cancel", ButtonTone.RED, R.drawable.ic_close) { task.cancelRequested = true })
            }
            DownloadTask.Status.QUEUED -> {
                btnRow.addView(smallBtn("Cancel", ButtonTone.RED, R.drawable.ic_close) { task.cancelRequested = true })
            }
            DownloadTask.Status.FAILED, DownloadTask.Status.CANCELLED -> {
                btnRow.addView(smallBtn("Retry", ButtonTone.BLUE, R.drawable.ic_refresh) { downloadQueue.retry(task) })
                btnRow.addView(smallBtn("Remove", ButtonTone.SURFACE, R.drawable.ic_delete) { downloadQueue.remove(task) })
            }
            DownloadTask.Status.COMPLETED -> {
                btnRow.addView(smallBtn("Remove", ButtonTone.SURFACE, R.drawable.ic_delete) { downloadQueue.remove(task) })
            }
            DownloadTask.Status.VERIFYING, DownloadTask.Status.SAVING -> { /* brief terminal-adjacent states — no user action needed */ }
        }
        if (btnRow.childCount > 0) row.addView(btnRow)

        return row
    }
}
