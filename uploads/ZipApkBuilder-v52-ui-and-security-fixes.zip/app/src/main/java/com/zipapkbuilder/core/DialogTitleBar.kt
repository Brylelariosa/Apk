package com.zipapkbuilder.core

import android.content.Context
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.zipapkbuilder.R

/**
 * Builds a dialog's title row: the title text plus a real, tappable close
 * button on the end — the same circular, ripple-backed [iconButton] used
 * everywhere else in the app for an icon-only action, not a bare "✕"/"X"
 * glyph on a plain TextView. `AlertDialog.Builder.setTitle(String)` has no
 * way to add anything alongside the text at all, which is why every dialog
 * in the app previously had no way to close except tapping outside, the
 * back button, or (where one happened to exist) a "Cancel"/"Close" pill
 * down in the button row.
 *
 * Hand the result to `AlertDialog.Builder.setCustomTitle(...)` in place of
 * `.setTitle(...)`. [onClose] almost always just calls the dialog's own
 * `.dismiss()` — since that reference doesn't exist until `.show()` returns,
 * the usual pattern (matching [dialogWithActions]'s own kdoc) is:
 * ```
 * lateinit var dlg: AlertDialog
 * dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
 *     .setCustomTitle(activity.dialogTitleBar("Title") { dlg.dismiss() })
 *     .setView(content)
 *     .show()
 * ```
 *
 * The rounded corners every dialog now has come from [R.style.Theme_App_Dialog]'s
 * `android:windowBackground` instead — this function only owns the title row.
 */
fun Context.dialogTitleBar(title: String, onClose: () -> Unit): LinearLayout {
    val dp = resources.displayMetrics.density
    return LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding((20 * dp).toInt(), (16 * dp).toInt(), (12 * dp).toInt(), (6 * dp).toInt())

        addView(TextView(context).apply {
            text = title
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })

        addView(
            iconButton(
                iconRes = R.drawable.ic_close,
                tint = ContextCompat.getColor(context, R.color.text_secondary)
            ) { onClose() }.apply { contentDescription = "Close" }
        )
    }
}
