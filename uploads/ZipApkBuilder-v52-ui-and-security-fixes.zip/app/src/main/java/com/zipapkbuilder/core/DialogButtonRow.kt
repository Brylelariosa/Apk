package com.zipapkbuilder.core

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import androidx.annotation.DrawableRes

/** One action in a [dialogWithActions] button row. */
data class DialogAction(
    val label: String,
    val tone: ButtonTone,
    @DrawableRes val iconRes: Int,
    val onClick: () -> Unit
)

/**
 * Wraps [body] (a message TextView, an EditText, a custom form — whatever the dialog
 * needs, or `null` for none) together with a bottom row of [actions] rendered as
 * [pillButton]s, and returns the whole thing as one view to hand to
 * `AlertDialog.Builder.setView(...)`.
 *
 * Use this instead of `.setPositiveButton()`/`.setNegativeButton()`/`.setNeutralButton()`
 * for every dialog with real actions. The platform's built-in button bar
 * (`ButtonBarLayout`) has an OEM-dependent stacking threshold and its own baked-in
 * minWidth/minHeight/padding from the Material text-button style — fighting it via
 * `getButton(...)` post-styling (see [styleButton]) proved unreliable across devices:
 * first no styling at all, then full-width stacked bars once padding was added, then
 * still oversized/chunky pills even after trimming that padding down. A plain
 * `LinearLayout` we build and measure ourselves sidesteps all of that and matches the
 * sizing already proven to look right elsewhere in the app — the Switch/Trigger chips
 * and the download row's Pause/Resume/Cancel buttons use this exact same [pillButton],
 * just not inside a dialog's button bar, and nobody's flagged those as too big.
 *
 * Caller is responsible for dismissing the dialog inside each [DialogAction.onClick] —
 * see the usual pattern:
 * ```
 * lateinit var dlg: AlertDialog
 * val content = activity.dialogWithActions(
 *     messageBody,
 *     DialogAction("Create", ButtonTone.GREEN, R.drawable.ic_add) { ...; dlg.dismiss() },
 *     DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
 * )
 * dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
 *     .setCustomTitle(activity.dialogTitleBar("…") { dlg.dismiss() })
 *     .setView(content).show()
 * ```
 * (see [dialogTitleBar] — every dialog's title now goes through it, in place of the
 * plain-text `.setTitle(String)` this example used to show)
 */
fun Context.dialogWithActions(body: View?, vararg actions: DialogAction): LinearLayout {
    val dp = resources.displayMetrics.density
    val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    if (body != null) root.addView(body)

    val row = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.END
        setPadding((18 * dp).toInt(), (14 * dp).toInt(), (18 * dp).toInt(), (10 * dp).toInt())
    }
    actions.forEachIndexed { i, action ->
        val btn = pillButton(action.label, action.tone, action.iconRes) { action.onClick() }
        btn.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).also { if (i > 0) it.marginStart = (8 * dp).toInt() }
        row.addView(btn)
    }
    root.addView(row)
    return root
}

/** A message TextView styled to match the app's dialog theme, for use as [dialogWithActions]'s body. */
fun Context.dialogMessage(text: String): android.widget.TextView {
    val dp = resources.displayMetrics.density
    return android.widget.TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(0xFFC7CBDD.toInt())
        setPadding((20 * dp).toInt(), (4 * dp).toInt(), (20 * dp).toInt(), (12 * dp).toInt())
    }
}
