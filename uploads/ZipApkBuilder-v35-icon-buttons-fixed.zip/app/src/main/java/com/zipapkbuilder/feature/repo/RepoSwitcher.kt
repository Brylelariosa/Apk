package com.zipapkbuilder.feature.repo

import android.app.AlertDialog
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.IconMenuAdapter
import com.zipapkbuilder.core.IconMenuRow
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.core.styleButton
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONArray

/**
 * Lets the user switch which repo/branch the rest of the app targets, without
 * retyping it: [showSavedReposDialog] lists every repo the token can see (not
 * just ones used before — fetched live from GitHub, so it's never stale), and
 * [applySwitchRepo] resets every piece of per-repo session state (owner cache,
 * last build) so nothing from the previous repo leaks into the new one.
 */
class RepoSwitcher(private val activity: MainActivity) {

    /** Switches the active repo/branch and clears all stale per-repo state. */
    fun applySwitchRepo(repo: String, branch: String) {
        activity.etRepo.setText(repo)
        activity.etBranch.setText(branch)
        activity.prefs.edit().putString(PrefKeys.PREF_REPO, repo).putString(PrefKeys.PREF_BRANCH, branch).apply()
        activity.lastOwner           = ""
        activity.lastRemotePath      = ""
        activity.lastFileSha         = null
        activity.lastRunId           = -1L
        activity.artifactDownloadUrl = null
        activity.buildFlowController.clearBuildState()
        activity.mainHandler.post {
            activity.tvOwnerInfo.text = ""; activity.tvOwnerInfo.visibility = android.view.View.GONE
            activity.btnDownloadApk?.isEnabled = false
            activity.setStatus("Idle")
        }
        activity.appendLog("🔀 Switched to: $repo @ $branch")
    }

    /**
     * Fetches all repos for the authenticated user from GitHub and shows a
     * picker. Tapping a repo immediately switches to it.
     */
    fun showSavedReposDialog() {
        val token = activity.etToken.text.toString().trim()
        if (token.isEmpty()) {
            AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setTitle("No Token")
                .setMessage("Enter your GitHub token first so your repositories can be fetched.")
                .setPositiveButton("OK", null).show()
            return
        }

        // Show a loading dialog while we fetch
        val loadingDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("🔀 Switch Repository")
            .setMessage("Fetching your repositories…")
            .setCancelable(true)
            .show()

        activity.bgExecutor.execute {
            try {
                // Fetch up to 100 repos sorted by most recently updated
                val url = "https://api.github.com/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator"
                val (code, body) = GitHubApi.httpGet(token, url)
                if (code != 200) throw Exception("GitHub returned HTTP $code")

                val arr = JSONArray(body)
                if (arr.length() == 0) throw Exception("No repositories found for this token.")

                // Build display list
                data class RepoEntry(val fullName: String, val name: String, val defaultBranch: String, val private: Boolean)
                val repos = (0 until arr.length()).map { i ->
                    val obj = arr.getJSONObject(i)
                    RepoEntry(
                        fullName      = obj.getString("full_name"),
                        name          = obj.getString("name"),
                        defaultBranch = obj.optString("default_branch", "main"),
                        private       = obj.optBoolean("private", false)
                    )
                }
                val lockTint = 0xFFF5A623.toInt()
                val folderTint = 0xFF7C6BFF.toInt()
                val rows = repos.map { r ->
                    IconMenuRow(
                        label = r.name,
                        iconRes = if (r.private) R.drawable.ic_lock else R.drawable.ic_folder,
                        iconTint = if (r.private) lockTint else folderTint,
                        subtitle = r.defaultBranch
                    )
                }

                activity.mainHandler.post {
                    loadingDlg.dismiss()
                    val dlgRepo = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                        .setTitle("🔀 Switch Repository  (${repos.size})")
                        .setAdapter(IconMenuAdapter(activity, rows)) { _, which ->
                            val picked = repos[which]
                            applySwitchRepo(picked.name, picked.defaultBranch)
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                    dlgRepo.listView?.setBackgroundColor(0xFF13162A.toInt())
                    dlgRepo.styleButton(activity, AlertDialog.BUTTON_NEGATIVE, ButtonTone.SURFACE, R.drawable.ic_close)
                }
            } catch (e: Exception) {
                activity.mainHandler.post {
                    loadingDlg.dismiss()
                    AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                        .setTitle("Could not fetch repositories")
                        .setMessage(e.message ?: "Unknown error")
                        .setPositiveButton("OK", null).show()
                }
            }
        }
    }
}
