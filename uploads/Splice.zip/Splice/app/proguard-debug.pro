# Debug builds: shrink only, keep names readable in the in-app logs.
-dontobfuscate
