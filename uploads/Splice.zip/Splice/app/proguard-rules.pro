-keepattributes SourceFile,LineNumberTable,Signature,InnerClasses,EnclosingMethod,*Annotation*

# JNI
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }
-keep class dev.splice.player.core.Native { *; }

# WebView bridge
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }

# Called from the generated RGSS activity (Java)
-keep class dev.splice.player.engine.RgssSession { *; }
-keep class dev.splice.player.engine.RgssSession$Companion { *; }

# SDL / mkxp-z (only present when the engine module is built)
-keep class org.libsdl.app.** { *; }
-dontwarn org.libsdl.app.**

-dontwarn kotlin.**
-dontwarn javax.annotation.**
