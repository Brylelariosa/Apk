/*
 * Splice NW.js compatibility shim for RPG Maker MV / MZ.
 * Runs before the game's scripts. It provides the parts of NW.js/Node that the engines and common
 * plugins use (require('fs'/'path'/'nw.gui'/...), process, nw, Buffer) on top of Splice's native
 * bridge, so the games take their normal file-based save path, and adds speed / FPS controls.
 * window.__SPLICE_CFG is injected by the host: {speed, fpsCap, showFps, pixelated, disableTouch, customJs, engine}
 */
(function () {
  'use strict';
  var CFG = window.__SPLICE_CFG || {};
  var N = window.SpliceNative;
  var ROOT = '/game';

  function log(level, msg) { try { N.log(level, String(msg)); } catch (e) { /* ignore */ } }
  function noop() {}

  // ---- diagnostics -------------------------------------------------------------------------
  window.addEventListener('error', function (e) {
    log('E', 'JS error: ' + e.message + ' @ ' + (e.filename || '') + ':' + (e.lineno || 0) + ':' + (e.colno || 0));
  });
  window.addEventListener('unhandledrejection', function (e) {
    var r = e.reason;
    log('E', 'Unhandled promise rejection: ' + (r && r.stack ? r.stack : r));
  });

  // ---- base64 / Buffer ---------------------------------------------------------------------
  function b64ToBytes(b64) {
    var bin = atob(b64);
    var out = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function bytesToB64(u8) {
    var s = '';
    var CH = 0x8000;
    for (var i = 0; i < u8.length; i += CH) {
      s += String.fromCharCode.apply(null, u8.subarray(i, Math.min(i + CH, u8.length)));
    }
    return btoa(s);
  }

  function SBuffer(arg, enc) { return toBuf(arg, enc); }
  function toBuf(arg, enc) {
    var u8;
    if (typeof arg === 'number') {
      u8 = new Uint8Array(arg);
    } else if (typeof arg === 'string') {
      if (enc === 'base64') {
        u8 = b64ToBytes(arg);
      } else if (enc === 'hex') {
        u8 = new Uint8Array(arg.length >> 1);
        for (var i = 0; i < u8.length; i++) u8[i] = parseInt(arg.substr(i * 2, 2), 16);
      } else if (enc === 'binary' || enc === 'latin1') {
        u8 = new Uint8Array(arg.length);
        for (var j = 0; j < arg.length; j++) u8[j] = arg.charCodeAt(j) & 255;
      } else {
        u8 = new TextEncoder().encode(arg);
      }
    } else if (arg instanceof ArrayBuffer) {
      u8 = new Uint8Array(arg);
    } else {
      u8 = new Uint8Array(arg || 0);
    }
    Object.setPrototypeOf(u8, SBuffer.prototype);
    return u8;
  }
  SBuffer.prototype = Object.create(Uint8Array.prototype, { constructor: { value: SBuffer } });
  SBuffer.prototype.toString = function (enc) {
    enc = (enc || 'utf8').toLowerCase();
    if (enc === 'base64') return bytesToB64(this);
    if (enc === 'hex') {
      var h = '';
      for (var i = 0; i < this.length; i++) h += (this[i] < 16 ? '0' : '') + this[i].toString(16);
      return h;
    }
    if (enc === 'binary' || enc === 'latin1' || enc === 'ascii') {
      var s = '';
      for (var j = 0; j < this.length; j++) s += String.fromCharCode(this[j]);
      return s;
    }
    return new TextDecoder('utf-8').decode(this);
  };
  SBuffer.from = function (a, e) { return toBuf(a, e); };
  SBuffer.alloc = function (n) { return toBuf(n); };
  SBuffer.isBuffer = function (o) { return o instanceof SBuffer; };
  SBuffer.byteLength = function (s, e) { return toBuf(s, e).length; };
  SBuffer.concat = function (list) {
    var total = 0, i;
    for (i = 0; i < list.length; i++) total += list[i].length;
    var out = toBuf(total), off = 0;
    for (i = 0; i < list.length; i++) { out.set(list[i], off); off += list[i].length; }
    return out;
  };

  // ---- path (posix) ------------------------------------------------------------------------
  function normalizeParts(parts, absolute) {
    var out = [];
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      if (!p || p === '.') continue;
      if (p === '..') { if (out.length && out[out.length - 1] !== '..') out.pop(); else if (!absolute) out.push('..'); }
      else out.push(p);
    }
    return out;
  }
  var path = {
    sep: '/',
    delimiter: ':',
    normalize: function (p) {
      p = String(p).replace(/\\/g, '/');
      var abs = p.charAt(0) === '/';
      var trail = p.charAt(p.length - 1) === '/';
      var s = normalizeParts(p.split('/'), abs).join('/');
      if (!s && !abs) s = '.';
      if (s && trail) s += '/';
      return (abs ? '/' : '') + s;
    },
    join: function () {
      var parts = [];
      for (var i = 0; i < arguments.length; i++) if (arguments[i]) parts.push(String(arguments[i]));
      return parts.length ? path.normalize(parts.join('/')) : '.';
    },
    resolve: function () {
      var r = '';
      for (var i = arguments.length - 1; i >= 0; i--) {
        var a = String(arguments[i]).replace(/\\/g, '/');
        if (!a) continue;
        r = r ? a + '/' + r : a;
        if (a.charAt(0) === '/') break;
      }
      if (r.charAt(0) !== '/') r = ROOT + '/' + r;
      var out = path.normalize(r);
      return out.length > 1 && out.charAt(out.length - 1) === '/' ? out.slice(0, -1) : out;
    },
    isAbsolute: function (p) { return String(p).charAt(0) === '/'; },
    dirname: function (p) {
      p = String(p).replace(/\\/g, '/');
      var i = p.replace(/\/+$/, '').lastIndexOf('/');
      if (i < 0) return '.';
      if (i === 0) return '/';
      return p.slice(0, i);
    },
    basename: function (p, ext) {
      p = String(p).replace(/\\/g, '/').replace(/\/+$/, '');
      var b = p.slice(p.lastIndexOf('/') + 1);
      if (ext && b.slice(-ext.length) === ext) b = b.slice(0, -ext.length);
      return b;
    },
    extname: function (p) {
      var b = path.basename(p);
      var i = b.lastIndexOf('.');
      return i <= 0 ? '' : b.slice(i);
    },
    relative: function (from, to) {
      var f = path.resolve(from).split('/').filter(Boolean);
      var t = path.resolve(to).split('/').filter(Boolean);
      var i = 0;
      while (i < f.length && i < t.length && f[i] === t[i]) i++;
      var up = [];
      for (var k = i; k < f.length; k++) up.push('..');
      return up.concat(t.slice(i)).join('/');
    },
    parse: function (p) {
      var base = path.basename(p), ext = path.extname(p);
      return { root: p.charAt(0) === '/' ? '/' : '', dir: path.dirname(p), base: base, ext: ext, name: ext ? base.slice(0, -ext.length) : base };
    }
  };

  // ---- fs ----------------------------------------------------------------------------------
  function vp(p) { return String(p).replace(/\\/g, '/'); }
  function err(code, msg, p) {
    var e = new Error(code + ': ' + msg + (p ? ", '" + p + "'" : ''));
    e.code = code; e.path = p; e.errno = code === 'ENOENT' ? -2 : -13;
    return e;
  }
  function encOf(opt) { return typeof opt === 'string' ? opt : (opt && opt.encoding) || null; }
  function Stats(o) {
    this.size = o.size; this.mtimeMs = o.mtime; this.mtime = new Date(o.mtime);
    this.ctime = this.mtime; this.atime = this.mtime; this._f = o.isFile; this._d = o.isDir;
  }
  Stats.prototype.isFile = function () { return this._f; };
  Stats.prototype.isDirectory = function () { return this._d; };
  Stats.prototype.isSymbolicLink = function () { return false; };

  var fs = {
    existsSync: function (p) { return !!N.exists(vp(p)); },
    readFileSync: function (p, opt) {
      p = vp(p);
      var enc = encOf(opt);
      if (enc && /^(utf-?8|ascii)$/i.test(enc)) {
        var s = N.readText(p);
        if (s === null) throw err('ENOENT', 'no such file or directory, open', p);
        return s;
      }
      var b = N.readBase64(p);
      if (b === null) throw err('ENOENT', 'no such file or directory, open', p);
      var buf = toBuf(b, 'base64');
      return enc ? buf.toString(enc) : buf;
    },
    writeFileSync: function (p, data) {
      p = vp(p);
      var ok;
      if (typeof data === 'string') ok = N.writeText(p, data);
      else ok = N.writeBase64(p, bytesToB64(data instanceof Uint8Array ? data : new Uint8Array(data)));
      if (!ok) throw err('EACCES', 'permission denied, open', p);
    },
    appendFileSync: function (p, data) {
      var cur = fs.existsSync(p) ? fs.readFileSync(p, 'utf8') : '';
      fs.writeFileSync(p, cur + String(data));
    },
    mkdirSync: function (p) { if (!N.mkdir(vp(p))) throw err('EACCES', 'permission denied, mkdir', p); },
    unlinkSync: function (p) { if (!N.unlink(vp(p))) throw err('ENOENT', 'no such file or directory, unlink', p); },
    rmdirSync: function (p) { N.unlink(vp(p)); },
    renameSync: function (a, b) { if (!N.rename(vp(a), vp(b))) throw err('ENOENT', 'no such file or directory, rename', a); },
    readdirSync: function (p) {
      var r = JSON.parse(N.readdir(vp(p)));
      if (r === null) throw err('ENOENT', 'no such file or directory, scandir', p);
      return r;
    },
    statSync: function (p) {
      var r = JSON.parse(N.stat(vp(p)));
      if (r === null) throw err('ENOENT', 'no such file or directory, stat', p);
      return new Stats(r);
    },
    accessSync: function (p) { if (!N.exists(vp(p))) throw err('ENOENT', 'no such file or directory, access', p); }
  };
  fs.lstatSync = fs.statSync;
  // callback style wrappers
  ['readFile', 'writeFile', 'appendFile', 'mkdir', 'unlink', 'rmdir', 'rename', 'readdir', 'stat', 'lstat', 'access'].forEach(function (name) {
    fs[name] = function () {
      var args = Array.prototype.slice.call(arguments);
      var cb = typeof args[args.length - 1] === 'function' ? args.pop() : noop;
      var res, error = null;
      try { res = fs[name + 'Sync'].apply(fs, args); } catch (e) { error = e; }
      setTimeout(function () { error ? cb(error) : cb(null, res); }, 0);
    };
  });
  fs.exists = function (p, cb) { var r = fs.existsSync(p); setTimeout(function () { cb(r); }, 0); };
  fs.promises = {};
  ['readFile', 'writeFile', 'appendFile', 'mkdir', 'unlink', 'rmdir', 'rename', 'readdir', 'stat', 'lstat', 'access'].forEach(function (name) {
    fs.promises[name] = function () {
      var args = arguments;
      return new Promise(function (resolve, reject) {
        try { resolve(fs[name + 'Sync'].apply(fs, args)); } catch (e) { reject(e); }
      });
    };
  });

  // ---- process / nw / modules --------------------------------------------------------------
  var proc = {
    platform: 'linux', arch: 'arm64', pid: 1, title: 'nw', version: 'v18.0.0',
    env: {}, argv: ['nw'], execPath: '/nw', exitCode: 0,
    versions: { node: '18.0.0', nw: '0.80.0', chromium: '100.0.0.0' },
    mainModule: { filename: ROOT + '/index.html', exports: {} },
    cwd: function () { return ROOT; },
    nextTick: function (fn) {
      var a = Array.prototype.slice.call(arguments, 1);
      Promise.resolve().then(function () { fn.apply(null, a); });
    },
    exit: function () { N.quit(); },
    on: noop, once: noop, off: noop, emit: noop, removeListener: noop,
    hrtime: function () { var t = performance.now(); return [Math.floor(t / 1000), Math.floor((t % 1000) * 1e6)]; },
    memoryUsage: function () { return { rss: 0, heapTotal: 0, heapUsed: 0, external: 0 }; },
    uptime: function () { return performance.now() / 1000; }
  };

  var winStub = {
    window: window, x: 0, y: 0, width: window.innerWidth, height: window.innerHeight, title: document.title,
    zoomLevel: 0, menu: null, isFullscreen: true, isDevToolsOpen: false,
    showDevTools: noop, closeDevTools: noop, maximize: noop, minimize: noop, restore: noop, show: noop, hide: noop,
    focus: noop, blur: noop, resizeTo: noop, resizeBy: noop, moveTo: noop, moveBy: noop, setPosition: noop,
    enterFullscreen: noop, leaveFullscreen: noop, toggleFullscreen: noop, requestAttention: noop,
    setAlwaysOnTop: noop, setResizable: noop, setMinimumSize: noop, setMaximumSize: noop,
    on: noop, once: noop, off: noop, removeListener: noop, removeAllListeners: noop, capturePage: noop,
    close: function () { N.quit(); },
    eval: function (frame, code) { return (0, eval)(code); }
  };
  var nw = {
    Window: { get: function () { return winStub; }, open: function () { return winStub; } },
    App: { argv: [], fullArgv: [], dataPath: ROOT + '/save', manifest: { name: document.title }, quit: function () { N.quit(); },
           closeAllWindows: function () { N.quit(); }, clearCache: noop, registerGlobalHotKey: noop, unregisterGlobalHotKey: noop },
    Screen: { Init: noop, screens: [{ bounds: { x: 0, y: 0, width: screen.width, height: screen.height } }], on: noop },
    Shell: { openExternal: function (u) { try { window.open(u, '_blank'); } catch (e) { /* ignore */ } }, openItem: noop, showItemInFolder: noop },
    Clipboard: { get: function () { return { get: function () { return ''; }, set: noop, clear: noop }; } },
    Shortcut: function () { return { on: noop }; },
    Menu: function () { return { append: noop, items: [] }; },
    MenuItem: function () { return {}; }
  };
  var os = {
    platform: function () { return 'linux'; }, type: function () { return 'Linux'; }, arch: function () { return 'arm64'; },
    release: function () { return '5.10'; }, homedir: function () { return ROOT + '/save'; }, tmpdir: function () { return ROOT + '/save'; },
    cpus: function () { return [{ model: 'arm', speed: 2000 }]; }, totalmem: function () { return 4e9; }, freemem: function () { return 2e9; },
    EOL: '\n', hostname: function () { return 'splice'; }, endianness: function () { return 'LE'; }
  };
  var util = {
    inspect: function (o) { try { return JSON.stringify(o); } catch (e) { return String(o); } },
    format: function (f) { var a = Array.prototype.slice.call(arguments, 1); return String(f).replace(/%[sdj%]/g, function (m) { return m === '%%' ? '%' : String(a.shift()); }); },
    promisify: function (fn) { return function () { var a = Array.prototype.slice.call(arguments); return new Promise(function (res, rej) { a.push(function (e, v) { e ? rej(e) : res(v); }); fn.apply(null, a); }); }; },
    inherits: function (c, s) { c.super_ = s; Object.setPrototypeOf(c.prototype, s.prototype); },
    isDeepStrictEqual: function (a, b) { return JSON.stringify(a) === JSON.stringify(b); }
  };
  var nodeCrypto = {
    randomBytes: function (n) { var u = new Uint8Array(n); crypto.getRandomValues(u); return toBuf(u); },
    randomUUID: function () { return crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random(); }
  };
  var childProcess = {
    exec: function (c, o, cb) { cb = typeof o === 'function' ? o : cb; if (cb) setTimeout(function () { cb(new Error('child_process is not available')); }, 0); },
    execSync: function () { throw new Error('child_process is not available'); },
    spawn: function () { throw new Error('child_process is not available'); }
  };
  var modules = {
    fs: fs, path: path, os: os, util: util, crypto: nodeCrypto, child_process: childProcess,
    'nw.gui': nw, buffer: { Buffer: SBuffer }, process: proc
  };

  window.process = proc;
  window.nw = nw;
  window.Buffer = SBuffer;
  if (typeof window.global === 'undefined') window.global = window;
  window.require = function (name) {
    name = String(name);
    if (name.indexOf('node:') === 0) name = name.slice(5);
    var m = modules[name];
    if (m) return m;
    var e = new Error("Cannot find module '" + name + "'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
  };
  window.close = function () { N.quit(); };

  // ---- display / performance ---------------------------------------------------------------
  var style = document.createElement('style');
  var css = 'html,body{margin:0;background:#000;overflow:hidden;overscroll-behavior:none;touch-action:none;' +
    '-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}';
  if (CFG.pixelated) css += 'canvas{image-rendering:pixelated;image-rendering:crisp-edges}';
  style.textContent = css;
  (document.head || document.documentElement).appendChild(style);
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); });

  // frame counter + optional render cap (game logic keeps its own fixed time step)
  var fpsEl = null, frames = 0, lastFpsT = performance.now();
  var origRaf = window.requestAnimationFrame.bind(window);
  var capMs = CFG.fpsCap > 0 ? 1000 / CFG.fpsCap : 0;
  var lastFrame = 0;
  window.requestAnimationFrame = function (cb) {
    return origRaf(function wrap(ts) {
      if (capMs && ts - lastFrame < capMs - 2) { origRaf(wrap); return; }
      lastFrame = ts;
      frames++;
      var now = performance.now();
      if (fpsEl && now - lastFpsT >= 1000) {
        fpsEl.textContent = Math.round(frames * 1000 / (now - lastFpsT)) + ' fps';
        frames = 0; lastFpsT = now;
      }
      cb(ts);
    });
  };
  function ensureFpsEl() {
    if (fpsEl) return;
    fpsEl = document.createElement('div');
    fpsEl.style.cssText = 'position:fixed;left:8px;top:8px;z-index:99999;padding:2px 8px;border-radius:6px;' +
      'background:rgba(20,18,29,.75);color:#5BE3C4;font:600 12px sans-serif;pointer-events:none';
    fpsEl.textContent = '-- fps';
    document.documentElement.appendChild(fpsEl);
  }
  window.__spliceToggleFps = function () {
    if (fpsEl) { fpsEl.remove(); fpsEl = null; } else { ensureFpsEl(); frames = 0; lastFpsT = performance.now(); }
  };
  if (CFG.showFps) document.addEventListener('DOMContentLoaded', ensureFpsEl);

  // game speed: MV scales the fixed update step, MZ scales the PIXI ticker
  if (CFG.speed && CFG.speed !== 100) {
    var factor = CFG.speed / 100;
    var tries = 0;
    var timer = setInterval(function () {
      tries++;
      var done = false;
      try {
        if (window.SceneManager && typeof SceneManager._deltaTime === 'number') {
          SceneManager._deltaTime = 1 / (60 * factor);
          done = true;
        } else if (window.Graphics && Graphics.app && Graphics.app.ticker) {
          Graphics.app.ticker.speed = factor;
          done = true;
        }
      } catch (e) { /* engine not ready yet */ }
      if (done || tries > 600) clearInterval(timer);
    }, 50);
  }

  if (CFG.disableTouch) {
    ['touchstart', 'touchmove', 'touchend', 'mousedown', 'mousemove', 'mouseup', 'pointerdown', 'pointermove', 'pointerup'].forEach(function (t) {
      window.addEventListener(t, function (e) { e.stopImmediatePropagation(); }, true);
    });
  }

  if (CFG.customJs) {
    document.addEventListener('DOMContentLoaded', function () {
      try { (new Function(CFG.customJs))(); } catch (e) { log('E', 'custom script failed: ' + e); }
    });
  }

  log('I', 'NW.js shim ready (' + (CFG.engine || '?') + ', speed ' + (CFG.speed || 100) + '%)');
})();
