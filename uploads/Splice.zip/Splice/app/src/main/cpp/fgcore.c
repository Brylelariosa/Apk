/*
 * fgcore - tiny native helper used by Splice.
 *
 *  - nInstallCrashHandler: writes a readable native backtrace to a file when the process takes
 *    SIGSEGV/SIGABRT/SIGBUS/SIGFPE/SIGILL, then chains to the previous handler (so the system
 *    tombstone still happens). This is how engine crashes show up in the in-app log viewer.
 *  - nRedirectStdio: points stdout/stderr at a log file so engine output (Ruby errors, mkxp
 *    messages) can be read inside the app without logcat.
 *  - nAbi: ABI this library was built for.
 *
 * Everything here is plain C, no STL, so the library is a few KB per ABI and installs on every
 * supported CPU even when the RGSS engine itself is only available for arm64.
 */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <jni.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <unwind.h>
#include <android/log.h>

#define TAG "fgcore"

#if defined(__aarch64__)
#define FG_ABI "arm64-v8a"
#elif defined(__arm__)
#define FG_ABI "armeabi-v7a"
#elif defined(__x86_64__)
#define FG_ABI "x86_64"
#elif defined(__i386__)
#define FG_ABI "x86"
#else
#define FG_ABI "unknown"
#endif

static char g_crash_path[512];
static struct sigaction g_old[32];
static const int k_signals[] = { SIGSEGV, SIGABRT, SIGBUS, SIGFPE, SIGILL, SIGTRAP };
#define K_SIGCOUNT ((int)(sizeof(k_signals) / sizeof(k_signals[0])))
#define MAX_FRAMES 48

struct bt_state {
    void **cur;
    void **end;
};

static _Unwind_Reason_Code unwind_cb(struct _Unwind_Context *ctx, void *arg) {
    struct bt_state *s = (struct bt_state *)arg;
    uintptr_t pc = _Unwind_GetIP(ctx);
    if (pc) {
        if (s->cur == s->end) return _URC_END_OF_STACK;
        *s->cur++ = (void *)pc;
    }
    return _URC_NO_REASON;
}

static void wr(int fd, const char *s) {
    if (s) {
        ssize_t r = write(fd, s, strlen(s));
        (void)r;
    }
}

static void wr_num(int fd, uintptr_t v, int base) {
    char buf[40];
    int i = 39;
    buf[i] = 0;
    if (v == 0) buf[--i] = '0';
    while (v > 0 && i > 0) {
        unsigned d = (unsigned)(v % (uintptr_t)base);
        buf[--i] = (char)(d < 10 ? '0' + d : 'a' + (d - 10));
        v /= (uintptr_t)base;
    }
    wr(fd, buf + i);
}

static void crash_handler(int sig, siginfo_t *info, void *uctx) {
    int fd = open(g_crash_path, O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (fd >= 0) {
        void *frames[MAX_FRAMES];
        struct bt_state st;
        void **p;
        int n = 0;
        st.cur = frames;
        st.end = frames + MAX_FRAMES;

        wr(fd, "\n=== NATIVE CRASH ===\nsignal ");
        wr_num(fd, (uintptr_t)sig, 10);
        wr(fd, " code ");
        wr_num(fd, info ? (uintptr_t)info->si_code : 0, 10);
        wr(fd, " fault addr 0x");
        wr_num(fd, info ? (uintptr_t)info->si_addr : 0, 16);
        wr(fd, " pid ");
        wr_num(fd, (uintptr_t)getpid(), 10);
        wr(fd, " tid ");
        wr_num(fd, (uintptr_t)gettid(), 10);
        wr(fd, "\nabi " FG_ABI "\nbacktrace:\n");

        _Unwind_Backtrace(unwind_cb, &st);
        for (p = frames; p < st.cur; ++p, ++n) {
            Dl_info di;
            wr(fd, "  #");
            wr_num(fd, (uintptr_t)n, 10);
            wr(fd, " pc 0x");
            wr_num(fd, (uintptr_t)*p, 16);
            if (dladdr(*p, &di) && di.dli_fname) {
                wr(fd, " ");
                wr(fd, di.dli_fname);
                wr(fd, " +0x");
                wr_num(fd, (uintptr_t)*p - (uintptr_t)di.dli_fbase, 16);
                if (di.dli_sname) {
                    wr(fd, " (");
                    wr(fd, di.dli_sname);
                    wr(fd, ")");
                }
            }
            wr(fd, "\n");
        }
        wr(fd, "=== END NATIVE CRASH ===\n");
        close(fd);
    }

    if (sig > 0 && sig < 32) {
        struct sigaction *old = &g_old[sig];
        if ((old->sa_flags & SA_SIGINFO) && old->sa_sigaction) {
            old->sa_sigaction(sig, info, uctx);
            return;
        }
        if (!(old->sa_flags & SA_SIGINFO) && old->sa_handler != SIG_DFL &&
            old->sa_handler != SIG_IGN && old->sa_handler != NULL) {
            old->sa_handler(sig);
            return;
        }
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

JNIEXPORT jboolean JNICALL
Java_dev_splice_player_core_Native_nInstallCrashHandler(JNIEnv *env, jclass cls, jstring path) {
    const char *p;
    int i;
    (void)cls;
    if (!path) return JNI_FALSE;
    p = (*env)->GetStringUTFChars(env, path, NULL);
    if (!p) return JNI_FALSE;
    strncpy(g_crash_path, p, sizeof(g_crash_path) - 1);
    g_crash_path[sizeof(g_crash_path) - 1] = 0;
    (*env)->ReleaseStringUTFChars(env, path, p);

    for (i = 0; i < K_SIGCOUNT; i++) {
        struct sigaction sa;
        int sig = k_signals[i];
        memset(&sa, 0, sizeof(sa));
        sa.sa_sigaction = crash_handler;
        sa.sa_flags = SA_SIGINFO;
        sigemptyset(&sa.sa_mask);
        if (sig < 32) sigaction(sig, &sa, &g_old[sig]);
    }
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_dev_splice_player_core_Native_nRedirectStdio(JNIEnv *env, jclass cls, jstring path) {
    const char *p;
    int fd;
    (void)cls;
    if (!path) return JNI_FALSE;
    p = (*env)->GetStringUTFChars(env, path, NULL);
    if (!p) return JNI_FALSE;
    fd = open(p, O_WRONLY | O_CREAT | O_APPEND, 0644);
    (*env)->ReleaseStringUTFChars(env, path, p);
    if (fd < 0) return JNI_FALSE;
    dup2(fd, 1);
    dup2(fd, 2);
    if (fd > 2) close(fd);
    setvbuf(stdout, NULL, _IOLBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    __android_log_print(ANDROID_LOG_INFO, TAG, "stdio redirected");
    return JNI_TRUE;
}

JNIEXPORT jstring JNICALL
Java_dev_splice_player_core_Native_nAbi(JNIEnv *env, jclass cls) {
    (void)cls;
    return (*env)->NewStringUTF(env, FG_ABI);
}
