package dev.splice.player.ui

import android.os.Build
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import dev.splice.player.R
import dev.splice.player.core.Bg
import dev.splice.player.core.Files
import dev.splice.player.core.Native
import dev.splice.player.core.Paths
import dev.splice.player.data.CoverStore
import dev.splice.player.data.Detector
import dev.splice.player.data.Diagnostics
import dev.splice.player.data.Library
import dev.splice.player.engine.EngineInfo
import dev.splice.player.model.EngineKind
import dev.splice.player.model.Game
import dev.splice.player.model.Profile

/** Real checks of this game's files and device, plus one-tap compatibility presets. */
class TroubleshootView(private val act: MainActivity, private val game: Game) : Screen(act) {
    private val body: LinearLayout = act.vbox()

    init {
        val col = act.vbox()
        col.addView(act.topBar("Troubleshoot", { act.pop() }))
        body.setPadding(act.dp(16), act.dp(4), act.dp(16), act.dp(32))
        col.addView(body)
        addView(act.scroll(col), LayoutParams(MATCH, MATCH))
        refresh()
    }

    override fun onShow() {
        refresh()
    }

    private fun refresh() {
        body.removeAllViews()
        body.add(act.text(game.title, 15f, C.DIM, 1), MATCH, WRAP, 0f, 4, 0, 0, 10)

        val checks = Diagnostics.run(act, game)
        val worst = checks.maxOfOrNull { it.level } ?: Diagnostics.OK
        val summary = act.hbox()
        summary.setPadding(act.dp(16), act.dp(14), act.dp(16), act.dp(14))
        val (sColor, sText) = when (worst) {
            Diagnostics.ERROR -> Pair(C.DANGER, "Problems found that will stop the game from starting")
            Diagnostics.WARN -> Pair(C.WARN, "The game should start, but a few things may need attention")
            else -> Pair(C.MINT, "Everything needed to start this game looks fine")
        }
        summary.background = act.shape((sColor and 0x00FFFFFF) or 0x22000000, 14f, (sColor and 0x00FFFFFF) or 0x55000000, 1f)
        summary.addView(act.icon(if (worst == Diagnostics.OK) R.drawable.ic_check else R.drawable.ic_warning, sColor, 24))
        summary.add(act.text(sText, 14f, C.TEXT, 1), 0, WRAP, 1f, 12, 0, 0, 0)
        body.addView(summary)

        body.add(act.sectionTitle("Checks"), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val card = SettingsCard(act)
        for (c in checks) card.custom(checkRow(c))
        body.addView(card.view)

        body.add(act.sectionTitle("Quick fixes"), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val fixes = SettingsCard(act)
        if (game.format.engine == EngineKind.RGSS) {
            fixes.action("Fix black screen or missing tiles", "Sub-image fix on, framebuffer blitting off", R.drawable.ic_display) {
                applyFix("Applied: tile fix, blitting off") { subImageFix = true; blit = false }
            }
            fixes.action("Low memory mode", "Texture limit 2048, fewer sound channels, no path cache", R.drawable.ic_chip) {
                applyFix("Applied: low memory mode") { maxTexture = 2048; seSources = 4; pathCache = false }
            }
            fixes.action("Maximum compatibility", "Safe renderer options, VSync off, normal speed", R.drawable.ic_shield) {
                applyFix("Applied: maximum compatibility") { subImageFix = true; blit = false; solidFonts = true; pacing = 0; speed = 100; rgssOverride = 0 }
            }
            fixes.action("Stutter on a slow device", "Frame skip on, balanced pacing", R.drawable.ic_speed) {
                applyFix("Applied: frame skip on") { frameSkip = true; pacing = 0 }
            }
        } else {
            fixes.action("Black screen or glitches", "Switch to the Canvas renderer", R.drawable.ic_display) {
                applyFix("Applied: Canvas renderer") { forceCanvas = true }
            }
            fixes.action("Crisp pixel art", "Turn off smoothing", R.drawable.ic_image) {
                applyFix("Applied: crisp pixels") { smooth = false }
            }
            fixes.action("Touch conflicts with the controls", "Ignore touch in the game", R.drawable.ic_gamepad) {
                applyFix("Applied: touch input ignored") { disableTouch = true }
            }
            fixes.action("Choppy on a slow device", "Cap rendering to 30 fps", R.drawable.ic_speed) {
                applyFix("Applied: 30 fps render cap") { fpsCap = 30; speed = 100 }
            }
        }
        body.addView(fixes.view)

        body.add(act.sectionTitle("Tools"), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val tools = SettingsCard(act)
        tools.action("Detect format again", "Re-read the game folder", R.drawable.ic_search) {
            Bg.io.execute {
                val r = Detector.detect(game.dir)
                Bg.ui {
                    if (r == null) {
                        act.toast("No RPG Maker game found in the folder")
                    } else {
                        game.format = r.format
                        game.webRoot = r.webRoot?.absolutePath
                        game.execName = r.execName
                        game.tags = r.tags.toMutableSet()
                        Library.update(game)
                        act.toast("Detected ${r.format.label}")
                        refresh()
                    }
                }
            }
        }
        tools.action("Rebuild cover", "Look for artwork again", R.drawable.ic_image) {
            CoverStore.invalidate(game)
            act.toast("Cover will be rebuilt")
        }
        tools.action("Clear this game's logs", null, R.drawable.ic_trash, true) {
            Files.deleteRecursive(Paths.sessionDir(game.id))
            act.toast("Logs cleared")
            refresh()
        }
        body.addView(tools.view)

        body.add(act.sectionTitle("Device"), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val dev = SettingsCard(act)
        dev.info("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        dev.info("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
        dev.info("CPU ABI", Native.abi())
        dev.info("RGSS engine", if (EngineInfo.rgssReady()) "Ready" else "Not available")
        dev.info("System WebView", EngineInfo.webViewVersion(act) ?: "unknown")
        body.addView(dev.view)
    }

    private fun applyFix(message: String, change: Profile.() -> Unit) {
        val p = Library.profile(game.id)
        p.change()
        Library.saveProfile(game.id, p)
        act.toast(message)
    }

    private fun checkRow(c: Diagnostics.Check): View {
        val row = act.hbox(false)
        row.setPadding(act.dp(16), act.dp(13), act.dp(16), act.dp(13))
        val (icon, color) = when (c.level) {
            Diagnostics.OK -> Pair(R.drawable.ic_check, C.MINT)
            Diagnostics.INFO -> Pair(R.drawable.ic_info, C.DIM)
            Diagnostics.WARN -> Pair(R.drawable.ic_warning, C.WARN)
            else -> Pair(R.drawable.ic_warning, C.DANGER)
        }
        val ic = act.icon(icon, color, 20)
        row.add(ic, act.dp(20), act.dp(20), 0f, 0, 1, 14, 0)
        val col = act.vbox()
        col.addView(act.text(c.title, 14.5f, C.TEXT, 1))
        col.add(act.text(c.detail, 12.5f, C.DIM), MATCH, WRAP, 0f, 0, 3, 0, 0)
        row.add(col, 0, WRAP, 1f)
        row.gravity = Gravity.TOP
        return row
    }
}
