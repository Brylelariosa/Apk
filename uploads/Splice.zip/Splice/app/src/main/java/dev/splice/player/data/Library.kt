package dev.splice.player.data

import android.content.Context
import dev.splice.player.core.AppLog
import dev.splice.player.core.Bg
import dev.splice.player.core.Files
import dev.splice.player.core.Paths
import dev.splice.player.core.Prefs
import dev.splice.player.model.Game
import dev.splice.player.model.Profile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** The game library: one JSON file plus one profile file per game. */
object Library {
    private lateinit var file: File
    private val games = ArrayList<Game>()
    private val profiles = HashMap<String, Profile>()
    private val listeners = ArrayList<() -> Unit>()

    fun init(@Suppress("UNUSED_PARAMETER") ctx: Context) {
        file = File(Paths.root, "library.json")
        load()
    }

    @Synchronized
    fun load() {
        games.clear()
        profiles.clear()
        if (!file.exists()) return
        try {
            val root = JSONObject(file.readText())
            val arr = root.optJSONArray("games") ?: JSONArray()
            for (i in 0 until arr.length()) {
                Game.fromJson(arr.getJSONObject(i))?.let { games.add(it) }
            }
        } catch (t: Throwable) {
            AppLog.e("library", "library.json unreadable, keeping a copy", t)
            try {
                file.copyTo(File(Paths.root, "library.corrupt.json"), true)
            } catch (ignored: Throwable) {
            }
        }
    }

    @Synchronized
    private fun persist() {
        val arr = JSONArray()
        for (g in games) arr.put(g.toJson())
        val tmp = File(file.parentFile, "library.json.tmp")
        tmp.writeText(JSONObject().put("v", 1).put("games", arr).toString())
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }

    private fun notifyChanged() {
        val snapshot = synchronized(this) { ArrayList(listeners) }
        Bg.ui { snapshot.forEach { it() } }
    }

    fun addListener(l: () -> Unit) {
        synchronized(this) { listeners.add(l) }
    }

    fun removeListener(l: () -> Unit) {
        synchronized(this) { listeners.remove(l) }
    }

    @Synchronized
    fun all(): List<Game> = ArrayList(games)

    @Synchronized
    fun get(id: String): Game? = games.firstOrNull { it.id == id }

    @Synchronized
    fun findByPath(path: String): Game? = games.firstOrNull { it.path == path }

    fun newId(): String = UUID.randomUUID().toString().replace("-", "").substring(0, 12)

    // ---- profiles ----
    fun defaults(): Profile = Profile.parse(Prefs.defaultProfile)

    fun setDefaults(p: Profile) {
        Prefs.defaultProfile = p.toString()
    }

    private fun profileFile(id: String) = File(Paths.profiles, "$id.json")

    @Synchronized
    fun profile(id: String): Profile {
        profiles[id]?.let { return it }
        val f = profileFile(id)
        val p = if (f.exists()) {
            try {
                Profile(JSONObject(f.readText()))
            } catch (t: Throwable) {
                defaults()
            }
        } else {
            defaults()
        }
        profiles[id] = p
        return p
    }

    @Synchronized
    fun saveProfile(id: String, p: Profile) {
        profiles[id] = p
        try {
            profileFile(id).writeText(p.toString())
        } catch (t: Throwable) {
            AppLog.e("library", "saving profile failed", t)
        }
    }

    // ---- games ----
    fun add(g: Game, p: Profile) {
        synchronized(this) {
            games.removeAll { it.id == g.id }
            games.add(g)
            persist()
        }
        saveProfile(g.id, p)
        notifyChanged()
    }

    fun update(g: Game) {
        synchronized(this) { persist() }
        notifyChanged()
    }

    fun remove(id: String, deleteFiles: Boolean, deleteSaves: Boolean) {
        val g = get(id) ?: return
        synchronized(this) {
            games.removeAll { it.id == id }
            profiles.remove(id)
            persist()
        }
        profileFile(id).delete()
        File(Paths.covers, "$id.jpg").delete()
        Files.deleteRecursive(File(Paths.sessions, id))
        if (deleteSaves) {
            Files.deleteRecursive(File(Paths.saves, id))
            Files.deleteRecursive(File(Paths.backups, id))
            Files.deleteRecursive(File(Paths.slots, id))
        }
        if (deleteFiles && g.managed) Files.deleteRecursive(g.dir)
        notifyChanged()
    }

    fun addPlayTime(id: String, deltaMs: Long) {
        val g = get(id) ?: return
        g.playTimeMs += deltaMs.coerceAtLeast(0)
        g.lastPlayed = System.currentTimeMillis()
        update(g)
    }
}
