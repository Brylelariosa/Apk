package dev.splice.player.ui

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import dev.splice.player.R
import dev.splice.player.core.AppLog
import dev.splice.player.core.Bg
import dev.splice.player.core.Fmt
import dev.splice.player.core.Paths
import dev.splice.player.data.Diagnostics
import dev.splice.player.data.Found
import dev.splice.player.data.ImportTask
import dev.splice.player.data.Importer
import dev.splice.player.data.Library
import dev.splice.player.data.LogcatCapture
import dev.splice.player.data.SessionTracker
import dev.splice.player.data.StorageAccess
import dev.splice.player.engine.EngineInfo
import dev.splice.player.engine.RgssLauncher
import dev.splice.player.engine.WebGameActivity
import dev.splice.player.model.EngineKind
import dev.splice.player.model.Game
import java.io.File

/** Single activity hosting the four tabs and pushed pages (game page, editors, viewers). */
class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private lateinit var bar: LinearLayout
    private lateinit var tabs: Array<Screen>
    private val tabViews = ArrayList<LinearLayout>()
    private val stack = ArrayList<Screen>()
    private var tabIndex = 0
    private var nextCode = 100
    private val pending = HashMap<Int, (Intent?) -> Unit>()
    var currentImport: ImportTask? = null
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(C.BG)
        content = FrameLayout(this)
        root.add(content, MATCH, 0, 1f)

        tabs = arrayOf(LibraryView(this), SavesView(this), LogsView(this), SettingsView(this))
        bar = buildBar()
        root.add(bar, MATCH, WRAP)
        setContentView(root)
        showTab(0, false)
    }

    // ---------- tabs ----------

    private fun buildBar(): LinearLayout {
        val b = hbox(false)
        b.setBackgroundColor(C.SURFACE)
        b.setPadding(dp(8), dp(6), dp(8), dp(6))
        val items = listOf(
            Pair("Library", R.drawable.ic_library), Pair("Saves", R.drawable.ic_saves),
            Pair("Logs", R.drawable.ic_logs), Pair("Settings", R.drawable.ic_settings)
        )
        items.forEachIndexed { i, (label, iconRes) ->
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setPadding(0, dp(6), 0, dp(6))
            val pill = FrameLayout(this)
            val ic = icon(iconRes, C.DIM, 22)
            pill.addView(ic, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            col.add(pill, dp(56), dp(30))
            col.add(text(label, 11.5f, C.DIM, 1), WRAP, WRAP, 0f, 0, 3, 0, 0)
            col.background = ripple(null, 14f)
            col.isClickable = true
            col.setOnClickListener { if (stack.isNotEmpty()) clearStack(); showTab(i, true) }
            b.add(col, 0, WRAP, 1f)
            tabViews.add(col)
        }
        return b
    }

    private fun paintTabs() {
        tabViews.forEachIndexed { i, col ->
            val active = i == tabIndex
            val pill = col.getChildAt(0) as FrameLayout
            pill.background = if (active) shape(0x265BE3C4, 16f) else null
            (pill.getChildAt(0) as ImageView).setColorFilter(if (active) C.MINT else C.DIM)
            (col.getChildAt(1) as TextView).setTextColor(if (active) C.MINT else C.DIM)
        }
    }

    private fun showTab(i: Int, animate: Boolean) {
        val old = tabs[tabIndex]
        if (content.childCount > 0 && i != tabIndex) old.onHide()
        tabIndex = i
        val s = tabs[i]
        if (s.parent == null) content.addView(s, FrameLayout.LayoutParams(MATCH, MATCH))
        for (t in tabs) t.visibility = if (t === s) View.VISIBLE else View.GONE
        if (animate) {
            s.alpha = 0f
            s.animate().alpha(1f).setDuration(180).start()
        }
        paintTabs()
        s.onShow()
    }

    private fun current(): Screen = if (stack.isNotEmpty()) stack[stack.size - 1] else tabs[tabIndex]

    // ---------- pushed pages ----------

    fun push(s: Screen) {
        current().onHide()
        stack.add(s)
        content.addView(s, FrameLayout.LayoutParams(MATCH, MATCH))
        s.alpha = 0f
        s.translationX = dpf(36f)
        s.animate().alpha(1f).translationX(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        bar.visibility = View.GONE
        s.onShow()
    }

    fun pop() {
        if (stack.isEmpty()) return
        val s = stack.removeAt(stack.size - 1)
        s.onHide()
        s.animate().alpha(0f).translationX(dpf(28f)).setDuration(170).withEndAction {
            content.removeView(s)
            s.onDestroyScreen()
        }.start()
        if (stack.isEmpty()) bar.visibility = View.VISIBLE
        current().onShow()
    }

    private fun clearStack() {
        for (s in ArrayList(stack)) {
            content.removeView(s)
            s.onDestroyScreen()
        }
        stack.clear()
        bar.visibility = View.VISIBLE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val c = current()
        if (c.onBack()) return
        if (stack.isNotEmpty()) {
            pop()
        } else if (tabIndex != 0) {
            showTab(0, true)
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        for (t in tabs) t.requestLayout()
    }

    // ---------- results ----------

    fun launchForResult(intent: Intent, cb: (Intent?) -> Unit) {
        val code = nextCode++
        pending[code] = cb
        try {
            startActivityForResult(intent, code)
        } catch (t: Throwable) {
            pending.remove(code)
            toast("No app can handle this action on your device")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        pending.remove(requestCode)?.invoke(if (resultCode == RESULT_OK) data else null)
    }

    override fun onResume() {
        super.onResume()
        val outcome = SessionTracker.finalizeIfNeeded(this, WebGameActivity.alive)
        if (outcome != null) {
            // An RGSS game that closes within seconds of starting almost always failed to start.
            val quick = !outcome.crashed && outcome.engine == "rgss" && outcome.durationMs < 8000
            if (outcome.crashed || quick) reportEnded(outcome, quick)
        }
        current().onShow()
    }

    /** Tells the user a game died. For RGSS the engine's own logcat output is added to the session log first. */
    private fun reportEnded(outcome: SessionTracker.Outcome, quick: Boolean) {
        val logPath = outcome.log
        if (outcome.engine == "rgss" && logPath != null && File(logPath).exists()) {
            Bg.io.execute {
                LogcatCapture.appendTo(File(logPath), outcome.start)
                Bg.ui { endedSheet(outcome, quick) }
            }
        } else {
            endedSheet(outcome, quick)
        }
    }

    private fun endedSheet(outcome: SessionTracker.Outcome, quick: Boolean) {
        val s = Sheet(this, if (quick) "The game closed right after starting" else "That session ended unexpectedly", outcome.game?.title)
        s.add(
            text(
                if (quick) "The engine stopped after ${outcome.durationMs / 1000} s. The session log includes the engine's own messages, which usually say why."
                else "The game stopped without closing normally. The session log includes the engine's own messages, which usually say why. Troubleshoot can suggest compatibility fixes.",
                14f, C.DIM
            )
        )
        val row = hbox()
        row.add(button("Dismiss", 0, BTN_GHOST) { s.dismiss() }, 0, WRAP, 1f, 0, 0, 8, 0)
        val g = outcome.game
        val logPath = outcome.log
        row.add(button("View log", R.drawable.ic_logs, BTN_PRIMARY) {
            s.dismiss()
            if (logPath != null && File(logPath).exists()) push(LogViewerView(this, "Session log", File(logPath)))
        }, 0, WRAP, 1f, 8, 0, 0, 0)
        s.add(row, 18)
        if (g != null) s.add(button("Open Troubleshoot", R.drawable.ic_shield, BTN_TONAL) {
            s.dismiss()
            push(TroubleshootView(this, g))
        }, 10)
        s.show()
    }

    // ---------- play ----------

    fun openGame(g: Game) {
        push(GameDetailView(this, g.id))
    }

    private var lastPlayTap = 0L

    fun play(g: Game) {
        val now = System.currentTimeMillis()
        if (now - lastPlayTap < 2500L) return   // a second tap while the engine is still starting
        lastPlayTap = now
        val errors = Diagnostics.run(this, g).filter { it.level == Diagnostics.ERROR }
        if (errors.isNotEmpty()) {
            val s = Sheet(this, "Can't start yet", g.title)
            for (e in errors) {
                val col = vbox()
                col.setPadding(dp(14), dp(12), dp(14), dp(12))
                col.background = shape(0x22FF6B7A, 12f)
                col.addView(text(e.title, 14.5f, C.DANGER, 1))
                col.add(text(e.detail, 13f, C.DIM), MATCH, WRAP, 0f, 0, 4, 0, 0)
                s.add(col, 10)
            }
            val row = hbox()
            if (errors.any { it.title.startsWith("Storage access") }) {
                row.add(button("Grant access", R.drawable.ic_folder, BTN_PRIMARY) {
                    s.dismiss()
                    StorageAccess.request(this)
                }, 0, WRAP, 1f, 0, 0, 8, 0)
            }
            row.add(button("Troubleshoot", R.drawable.ic_shield, BTN_TONAL) {
                s.dismiss()
                push(TroubleshootView(this, g))
            }, 0, WRAP, 1f, 0, 0, 0, 0)
            s.add(row, 16)
            s.show()
            return
        }
        if (g.format.engine == EngineKind.RGSS && SessionTracker.rgssRunning(this)) {
            askAboutRunningEngine(g)
            return
        }
        val err = if (g.format.engine == EngineKind.RGSS) RgssLauncher.launch(this, g) else WebGameActivity.launch(this, g)
        if (err != null) {
            val s = Sheet(this, "Couldn't start the game", g.title)
            s.add(text(err, 14f, C.DIM))
            s.add(button("OK", 0, BTN_TONAL) { s.dismiss() }, 16)
            s.show()
        } else {
            toast("Starting ${g.title}…")
        }
    }

    /** An engine process from an earlier session is still alive (often a frozen one): starting again would only show that old screen. */
    private fun askAboutRunningEngine(g: Game) {
        val s = Sheet(this, "A game is still open", g.title)
        s.add(text("The game engine from your last session is still running in the background. It may be frozen.", 13.5f, C.DIM))
        s.action("Switch back to it", R.drawable.ic_play) { resumeEngine() }
        s.action("Close it and start again", R.drawable.ic_refresh, true) { closeEngineThenPlay(g) }
        s.show()
    }

    private fun resumeEngine() {
        try {
            val i = Intent()
            i.setClassName(packageName, EngineInfo.RGSS_ACTIVITY)
            startActivity(i)
        } catch (t: Throwable) {
            toast("Could not switch back to the game")
        }
    }

    private fun closeEngineThenPlay(g: Game) {
        Bg.io.execute {
            SessionTracker.killRgss(this)
            var n = 0
            while (SessionTracker.rgssRunning(this) && n < 30) {
                try {
                    Thread.sleep(100)
                } catch (ignored: InterruptedException) {
                }
                n++
            }
            Bg.ui {
                val old = SessionTracker.finalizeIfNeeded(this, WebGameActivity.alive)
                lastPlayTap = 0L
                val oldLog = old?.log
                if (old != null && old.engine == "rgss" && oldLog != null && File(oldLog).exists()) {
                    Bg.io.execute {
                        LogcatCapture.appendTo(File(oldLog), old.start)
                        Bg.ui { play(g) }
                    }
                } else {
                    play(g)
                }
            }
        }
    }

    // ---------- importing ----------

    fun importZip() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        launchForResult(i) { data ->
            val uri = data?.data
            if (uri != null) startImport(ImportTask("Archive")) { t -> Importer.importZip(this, uri, t) { onImportDone(it) } }
        }
    }

    /** Pick Game.exe (or any file inside the game folder): the game is played in place from that folder. */
    fun importExe() {
        val go = {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            launchForResult(i) { data ->
                val uri: Uri? = data?.data
                if (uri != null) startImport(ImportTask("Game")) { t -> Importer.importExe(this, uri, t) { onImportDone(it) } }
            }
        }
        if (StorageAccess.hasAllFiles(this)) {
            go()
        } else {
            val s = Sheet(this, "Pick Game.exe", "Splice plays the game from the folder Game.exe is in")
            s.add(text("Game.exe is a Windows program, so Splice can't run it. It plays the game's data files next to it instead, and needs \"All files access\" to read that folder.", 13.5f, C.DIM))
            s.add(button("Grant All files access", R.drawable.ic_folder, BTN_PRIMARY) {
                s.dismiss()
                StorageAccess.request(this)
            }, 14)
            s.show()
        }
    }

    fun importFolder() {
        val go = {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            launchForResult(i) { data ->
                val uri: Uri? = data?.data
                if (uri != null) startImport(ImportTask("Folder")) { t -> Importer.importTree(this, uri, t) { onImportDone(it) } }
            }
        }
        if (StorageAccess.hasAllFiles(this)) {
            go()
        } else {
            val s = Sheet(this, "Add a game folder", "Pick a game folder, or a folder that contains several games")
            s.add(text("Without \"All files access\" Splice has to copy the game into its own storage, which takes time and space. Granting access lets games stay where they are (recommended).", 13.5f, C.DIM))
            val col = vbox()
            col.add(button("Grant All files access", R.drawable.ic_folder, BTN_PRIMARY) {
                s.dismiss()
                StorageAccess.request(this)
            }, MATCH, WRAP, 0f, 0, 14, 0, 0)
            col.add(button("Continue and copy", R.drawable.ic_import, BTN_TONAL) {
                s.dismiss()
                go()
            }, MATCH, WRAP, 0f, 0, 8, 0, 0)
            s.add(col)
            s.show()
        }
    }

    private fun startImport(task: ImportTask, starter: (ImportTask) -> Unit) {
        if (currentImport?.finished == false) {
            toast("Another import is still running")
            return
        }
        currentImport = task
        (tabs[0] as LibraryView).trackImport(task)
        starter(task)
    }

    private fun onImportDone(task: ImportTask) {
        val err = task.error
        if (err != null) {
            AppLog.w("import", "import ended: $err")
            toast(err)
        } else if (task.found.isNotEmpty()) {
            chooseGames(task)
        } else {
            toast(if (task.added.size == 1) "Added ${task.added[0].title}" else "Added ${task.added.size} games")
        }
    }

    /** Several games were found, or one that looks like a copy of a game already in the library: let the user decide. */
    private fun chooseGames(task: ImportTask) {
        val list = task.found
        val work = task.work
        val s = Sheet(
            this,
            if (list.size == 1) "Add this game?" else "Found ${list.size} games",
            "Tap a game to add it to your library"
        )
        s.dialog.setCancelable(false)
        for (f in list) {
            val col = vbox()
            col.setPadding(dp(14), dp(12), dp(14), dp(12))
            col.background = ripple(shape(C.SURFACE2, 14f), 14f)
            col.isClickable = true
            col.addView(text(f.result.title, 15f, C.TEXT, 1, 2))
            val place = if (f.rel.isEmpty()) "top level" else f.rel
            val note = if (f.duplicate) " · already in your library" else ""
            col.add(text("${f.result.format.label} · ${Fmt.size(f.size)} · $place$note", 12.5f, C.DIM), MATCH, WRAP, 0f, 0, 3, 0, 0)
            col.setOnClickListener {
                s.dismiss()
                addChosen(task, listOf(f))
            }
            s.add(col, 8)
        }
        val row = hbox()
        row.add(button("Cancel", 0, BTN_GHOST) {
            s.dismiss()
            Importer.discard(work)
        }, 0, WRAP, 1f, 0, 0, 8, 0)
        if (list.size > 1) {
            row.add(button("Add all", R.drawable.ic_add, BTN_PRIMARY) {
                s.dismiss()
                addChosen(task, list)
            }, 0, WRAP, 1f, 8, 0, 0, 0)
        }
        s.add(row, 16)
        s.show()
    }

    private fun addChosen(task: ImportTask, chosen: List<Found>) {
        val work = task.work
        startImport(ImportTask("Games")) { t -> Importer.addFound(t, chosen, work) { onImportDone(it) } }
    }

    fun gamesDirInfo(): File = Paths.games

    fun libraryHasGames(): Boolean = Library.all().isNotEmpty()
}
