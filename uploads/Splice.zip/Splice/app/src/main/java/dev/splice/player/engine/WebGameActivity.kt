package dev.splice.player.engine

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import dev.splice.player.R
import dev.splice.player.core.AppLog
import dev.splice.player.core.Fmt
import dev.splice.player.core.Paths
import dev.splice.player.data.Library
import dev.splice.player.data.SaveVault
import dev.splice.player.data.SessionTracker
import dev.splice.player.data.StorageAccess
import dev.splice.player.model.Controls
import dev.splice.player.model.Game
import dev.splice.player.model.Profile
import dev.splice.player.ui.MATCH
import dev.splice.player.ui.Sheet
import dev.splice.player.ui.TouchOverlayView
import dev.splice.player.ui.toast
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * RPG Maker MV / MZ runtime: the game's own HTML5 engine runs in the system WebView, fed straight
 * from the game folder by [GameServer], with a NW.js shim ([NwBridge] + nwshim.js) so saves are
 * real files managed by Splice, plus speed/FPS options, touch controls and controller input.
 */
class WebGameActivity : Activity() {
    companion object {
        const val EXTRA_GAME_ID = "splice.game_id"
        const val EXTRA_LOG = "splice.session_log"

        @Volatile
        var alive = false

        /** Returns an error message to show the user, or null when the game was started. */
        fun launch(act: Activity, g: Game): String? {
            val web = g.webRoot?.let { File(it) }
            if (web == null || !web.isDirectory) return "The game folder no longer exists: ${g.path}"
            if (StorageAccess.needsPermission(act, web)) return "Splice needs \"All files access\" to read games outside its own folder. Enable it in Settings."
            return try {
                SaveVault.autoBackup(g, "before-play")
                val log = Paths.newSessionLog(g.id)
                log.writeText(
                    "== Splice session ${Fmt.date(System.currentTimeMillis())} ==\n" +
                        "game: ${g.title} (${g.format.label})\nfolder: ${g.path}\nwebview: ${EngineInfo.webViewVersion(act) ?: "unknown"}\n--- console ---\n"
                )
                Paths.sessionDir(g.id).listFiles { f -> f.name.endsWith(".log") }?.sortedByDescending { it.name }?.drop(12)?.forEach { it.delete() }
                g.lastPlayed = System.currentTimeMillis()
                Library.update(g)
                SessionTracker.begin(g.id, "web", log.absolutePath)
                val i = Intent(act, WebGameActivity::class.java)
                i.putExtra(EXTRA_GAME_ID, g.id)
                i.putExtra(EXTRA_LOG, log.absolutePath)
                act.startActivity(i)
                null
            } catch (t: Throwable) {
                AppLog.e("web", "launch failed", t)
                "Could not start the game: ${t.message ?: t.javaClass.simpleName}"
            }
        }
    }

    private lateinit var game: Game
    private lateinit var profile: Profile
    private lateinit var root: FrameLayout
    private var web: WebView? = null
    private var overlay: TouchOverlayView? = null
    private var server: GameServer? = null
    private var logFile: File? = null
    private var startUrl = ""
    private var controlsOn = true
    private val logLock = Any()

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val g = intent.getStringExtra(EXTRA_GAME_ID)?.let { Library.get(it) }
        if (g == null || g.webRoot == null) {
            finish()
            return
        }
        game = g
        profile = Library.profile(g.id)
        logFile = intent.getStringExtra(EXTRA_LOG)?.let { File(it) }
        alive = true
        controlsOn = profile.controlsVisible

        requestedOrientation = when (profile.orientation) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
        }
        if (profile.keepAwake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        setContentView(root)

        try {
            buildWeb()
        } catch (t: Throwable) {
            AppLog.e("web", "WebView failed", t)
            slog("E", "WebView could not start: $t")
            toast("This device's WebView could not start. Update Android System WebView.")
            finish()
            return
        }
        buildOverlay()
    }

    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    private fun buildWeb() {
        val webRoot = File(game.webRoot!!)
        val cfg = JSONObject()
            .put("speed", profile.speed)
            .put("fpsCap", profile.fpsCap)
            .put("showFps", profile.showFps)
            .put("pixelated", !profile.smooth)
            .put("disableTouch", profile.disableTouch)
            .put("customJs", profile.customJs)
            .put("engine", game.format.id)
        val shimText = assets.open("web/nwshim.js").bufferedReader().use { it.readText() }
        val srv = GameServer(webRoot, "window.__SPLICE_CFG=$cfg;\n$shimText")
        server = srv

        val wv = WebView(this)
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.cacheMode = WebSettings.LOAD_NO_CACHE
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.useWideViewPort = true
        s.loadWithOverviewMode = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.javaScriptCanOpenWindowsAutomatically = false
        s.textZoom = 100
        wv.setBackgroundColor(Color.BLACK)
        wv.isLongClickable = false
        wv.setOnLongClickListener { true }
        wv.isHapticFeedbackEnabled = false
        wv.isFocusable = true
        wv.isFocusableInTouchMode = true
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.isHorizontalScrollBarEnabled = false

        wv.addJavascriptInterface(
            NwBridge(webRoot, Paths.saveDir(game.id), { runOnUiThread { finish() } }, { lvl, msg -> slog(lvl, msg) }),
            "SpliceNative"
        )
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                server?.intercept(request)

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                slog("E", "WebView render process gone (crashed=${detail.didCrash()})")
                runOnUiThread {
                    toast("The WebView process stopped. Try again.")
                    finish()
                }
                return true
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                val lvl = when (m.messageLevel()) {
                    ConsoleMessage.MessageLevel.ERROR -> "E"
                    ConsoleMessage.MessageLevel.WARNING -> "W"
                    else -> "I"
                }
                if (lvl != "I" || profile.showFps) slog(lvl, "${m.message()} (${(m.sourceId() ?: "").substringAfterLast('/')}:${m.lineNumber()})")
                return true
            }
        }
        root.addView(wv, FrameLayout.LayoutParams(MATCH, MATCH))
        web = wv

        startUrl = GameServer.ORIGIN + "/index.html" + (if (profile.forceCanvas) "?canvas" else "")
        slog("I", "loading $startUrl (webRoot=${webRoot.absolutePath})")
        wv.loadUrl(startUrl)
        wv.requestFocus()
    }

    private fun isPortrait() = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT

    private fun buildOverlay() {
        val ov = TouchOverlayView(this)
        ov.opacity = profile.controlsOpacity / 100f
        ov.scale = profile.controlsScale / 100f
        ov.haptics = profile.haptics
        ov.onKey = { code, down -> sendKey(code, down) }
        ov.onMenu = { showMenu() }
        root.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
        overlay = ov
        applyLayout()
    }

    private fun applyLayout() {
        val ov = overlay ?: return
        val all = Controls.layoutFor(profile, isPortrait())
        ov.buttons = if (controlsOn) all else all.filter { it.type == Controls.TYPE_MENU }
        if (!controlsOn) ov.releaseAll()
    }

    private fun sendKey(code: Int, down: Boolean) {
        val now = SystemClock.uptimeMillis()
        web?.dispatchKeyEvent(KeyEvent(now, now, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0))
    }

    private fun slog(level: String, msg: String) {
        val f = logFile ?: return
        try {
            synchronized(logLock) {
                f.appendText(SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date()) + " " + level + " " + msg + "\n")
            }
        } catch (ignored: Throwable) {
        }
    }

    private fun showMenu() {
        val s = Sheet(this, game.title, "Paused menu")
        s.action("Resume", R.drawable.ic_play) { web?.requestFocus() }
        s.action(if (controlsOn) "Hide touch controls" else "Show touch controls", R.drawable.ic_gamepad) {
            controlsOn = !controlsOn
            applyLayout()
        }
        s.action("Toggle FPS counter", R.drawable.ic_speed) { web?.evaluateJavascript("window.__spliceToggleFps&&window.__spliceToggleFps()", null) }
        s.action("Back up saves now", R.drawable.ic_saves) {
            val f = SaveVault.backup(game, "manual")
            toast(if (f != null) "Backup created" else "No saves to back up yet")
        }
        s.action("Reload game", R.drawable.ic_refresh) { web?.loadUrl(startUrl) }
        s.action("Exit game", R.drawable.ic_close, true) { finish() }
        s.dialog.setOnDismissListener { web?.requestFocus() }
        s.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        showMenu()
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (profile.controlsAutoHide && (e.source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD && e.deviceId >= 0) {
            overlay?.faded = true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyLayout()
    }

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onPause() {
        super.onPause()
        overlay?.releaseAll()
        web?.onPause()
        web?.pauseTimers()
    }

    override fun onResume() {
        super.onResume()
        web?.onResume()
        web?.resumeTimers()
        hideSystemUi()
    }

    override fun onDestroy() {
        alive = false
        SessionTracker.end()
        overlay?.releaseAll()
        web?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.stopLoading()
            it.destroy()
        }
        web = null
        super.onDestroy()
    }
}
