package dev.splice.player.ui

import android.content.Intent
import android.widget.LinearLayout
import dev.splice.player.R
import dev.splice.player.core.Bg
import dev.splice.player.core.Paths
import dev.splice.player.data.Library
import dev.splice.player.engine.ControlsEditorActivity
import dev.splice.player.model.EngineKind
import dev.splice.player.model.Game
import dev.splice.player.model.Profile
import org.json.JSONObject
import java.io.File
import java.util.Locale

/** Per-game settings (or the default profile when [gameId] is null). Every change is saved immediately. */
class ProfileEditorView(
    private val act: MainActivity,
    private val title: String,
    private val kind: EngineKind?,
    private val gameId: String?,
    private val profile: Profile,
    private val onChange: (Profile) -> Unit
) : Screen(act) {

    companion object {
        fun forGame(act: MainActivity, g: Game): ProfileEditorView {
            val p = Library.profile(g.id)
            return ProfileEditorView(act, g.title, g.format.engine, g.id, p) { Library.saveProfile(g.id, it) }
        }

        fun forDefaults(act: MainActivity): ProfileEditorView {
            return ProfileEditorView(act, "Default profile", null, null, Library.defaults()) { Library.setDefaults(it) }
        }
    }

    private val rgss get() = kind == null || kind == EngineKind.RGSS
    private val web get() = kind == null || kind == EngineKind.WEB

    init {
        build()
    }

    private fun changed() {
        onChange(profile)
    }

    private fun build() {
        removeAllViews()
        val col = act.vbox()
        col.addView(act.topBar(title, { act.pop() }))
        val body = act.vbox()
        body.setPadding(act.dp(16), act.dp(4), act.dp(16), act.dp(32))

        if (gameId == null) {
            body.add(act.text("New games start with these settings. Existing games keep their own.", 13f, C.DIM), MATCH, WRAP, 0f, 4, 0, 4, 8)
        }

        section(body, "Display") { c ->
            c.choice("Orientation", listOf("Auto", "Landscape", "Portrait"), profile.orientation) { profile.orientation = it; changed() }
            if (rgss) c.choice("Scaling", listOf("Fit", "Stretch", "Pixel-perfect"), profile.scaleMode,
                "Fit keeps the game's aspect ratio. Pixel-perfect uses whole-number scale steps.") { profile.scaleMode = it; changed() }
            c.toggle(
                "Smooth scaling",
                if (web && !rgss) "Off gives crisp, blocky pixels" else "Linear filtering when the game is scaled up",
                profile.smooth
            ) { profile.smooth = it; changed() }
            c.toggle("Keep screen on", "Prevents the display from sleeping during play", profile.keepAwake) { profile.keepAwake = it; changed() }
        }

        section(body, "Performance") { c ->
            c.slider("Game speed", 50, 300, 25, profile.speed, { String.format(Locale.US, "%.2fx", it / 100f) }) {
                profile.speed = it
                changed()
            }
            c.note("Above 1x fast-forwards the game (useful for grinding); below 1x slows it down. It changes how fast the game logic runs, not just the frame rate.")
            if (web) c.choice("Render cap", listOf("Display rate", "30 fps", "45 fps", "60 fps"),
                when (profile.fpsCap) { 30 -> 1; 45 -> 2; 60 -> 3; else -> 0 }) {
                profile.fpsCap = when (it) { 1 -> 30; 2 -> 45; 3 -> 60; else -> 0 }
                changed()
            }
            if (rgss) {
                c.toggle("Frame skip", "Skip frames instead of slowing down when the device can't keep up", profile.frameSkip) { profile.frameSkip = it; changed() }
                c.choice("Frame pacing", listOf("Balanced", "VSync", "Match display"), profile.pacing,
                    "VSync removes tearing; Match display syncs to the screen's refresh rate.") { profile.pacing = it; changed() }
                c.choice("Texture size limit", listOf("Hardware", "1024", "2048", "4096"),
                    when (profile.maxTexture) { 1024 -> 1; 2048 -> 2; 4096 -> 3; else -> 0 },
                    "Lower limits save memory on weak GPUs but can cut very large images.") {
                    profile.maxTexture = when (it) { 1 -> 1024; 2 -> 2048; 3 -> 4096; else -> 0 }
                    changed()
                }
            }
            c.toggle(
                "Show FPS",
                if (rgss && !web) "Writes the frame rate to the session log" else "Shows an FPS counter (MV/MZ) or logs it (RGSS)",
                profile.showFps
            ) { profile.showFps = it; changed() }
        }

        section(body, "Controls") { c ->
            c.toggle("On-screen controls", "D-pad and buttons drawn over the game", profile.controlsVisible) { profile.controlsVisible = it; changed() }
            c.toggle("Hide when a controller is used", "Touch the screen to bring them back", profile.controlsAutoHide) { profile.controlsAutoHide = it; changed() }
            c.toggle("Haptic feedback", null, profile.haptics) { profile.haptics = it; changed() }
            c.slider("Opacity", 20, 100, 5, profile.controlsOpacity, { "$it%" }) { profile.controlsOpacity = it; changed() }
            c.slider("Button size", 60, 160, 5, profile.controlsScale, { "$it%" }) { profile.controlsScale = it; changed() }
            if (gameId != null) {
                c.action("Edit layout (landscape)", "Drag, resize, add or remove buttons", R.drawable.ic_gamepad) { editLayout(false) }
                c.action("Edit layout (portrait)", null, R.drawable.ic_gamepad) { editLayout(true) }
                c.action("Reset both layouts", null, R.drawable.ic_refresh) {
                    profile.layoutLand = ""
                    profile.layoutPort = ""
                    changed()
                    act.toast("Layouts reset")
                }
            }
            c.note("Controllers work too: Bluetooth and USB gamepads are handled by the engine itself.")
        }

        if (rgss) {
            section(body, "Audio (RGSS)") { c ->
                c.slider("Sound effect channels", 4, 32, 2, profile.seSources, { "$it" }) { profile.seSources = it; changed() }
                c.action(
                    "MIDI soundfont",
                    if (profile.midiFont.isBlank()) "None (the engine's default MIDI handling)" else File(profile.midiFont).name,
                    R.drawable.ic_sound
                ) { pickSoundfont() }
                if (profile.midiFont.isNotBlank()) {
                    c.toggle("MIDI reverb", null, profile.midiReverb) { profile.midiReverb = it; changed() }
                    c.toggle("MIDI chorus", null, profile.midiChorus) { profile.midiChorus = it; changed() }
                    c.action("Remove soundfont", null, R.drawable.ic_trash, true) {
                        profile.midiFont = ""
                        changed()
                        build()
                    }
                }
            }
        }

        section(body, "Compatibility") { c ->
            if (rgss) {
                c.choice("RGSS version", listOf("Auto", "XP (RGSS1)", "VX (RGSS2)", "Ace (RGSS3)"), profile.rgssOverride,
                    "Only change this if the game picks the wrong scripting version.") { profile.rgssOverride = it; changed() }
                c.toggle("Fix missing or glitched tiles", "Enables mkxp's sub-image fix", profile.subImageFix) { profile.subImageFix = it; changed() }
                c.toggle("Framebuffer blitting", "Turn off if you see graphical glitches", profile.blit) { profile.blit = it; changed() }
                c.toggle("Solid fonts", "Removes soft edges on text", profile.solidFonts) { profile.solidFonts = it; changed() }
                c.toggle("Asset path cache", "Faster loading of big games; turn off if files seem to be missing", profile.pathCache) { profile.pathCache = it; changed() }
                c.toggle("Script names in errors", "Readable error messages in the logs", profile.scriptNames) { profile.scriptNames = it; changed() }
                c.toggle("Keep saves in Splice's vault", "Required for slots, backups and export", profile.redirectSaves) { profile.redirectSaves = it; changed() }
                val res = listOf("Game default", "640 × 480", "800 × 600", "960 × 720", "1280 × 960")
                val sizes = listOf(Pair(0, 0), Pair(640, 480), Pair(800, 600), Pair(960, 720), Pair(1280, 960))
                val cur = sizes.indexOfFirst { it.first == profile.defW && it.second == profile.defH }.let { if (it < 0) 0 else it }
                c.choice("Internal resolution override", res, cur,
                    "Advanced: games built for other sizes may break. Leave on Game default if unsure.") {
                    profile.defW = sizes[it].first
                    profile.defH = sizes[it].second
                    changed()
                }
                c.action("Extra RTP folders", if (profile.rtpExtra.isBlank()) "None" else profile.rtpExtra.lines().filter { it.isNotBlank() }.size.toString() + " folder(s)", R.drawable.ic_folder) {
                    promptSheet(act, "Extra RTP folders", "One folder path per line", profile.rtpExtra, true) { v ->
                        profile.rtpExtra = v.trim()
                        changed()
                        build()
                    }
                }
                c.action("Custom mkxp.json overrides", if (profile.customJson.isBlank()) "None" else "Active", R.drawable.ic_layers) {
                    promptSheet(act, "Custom mkxp.json", "{ \"smoothScaling\": 0 }", profile.customJson, true) { v ->
                        val t = v.trim()
                        if (t.isEmpty() || validJson(t)) {
                            profile.customJson = t
                            changed()
                            build()
                        } else {
                            act.toast("That is not a valid JSON object")
                        }
                    }
                }
            }
            if (web) {
                c.toggle("Canvas renderer", "Use instead of WebGL if the screen stays black or glitches", profile.forceCanvas) { profile.forceCanvas = it; changed() }
                c.toggle("Ignore touch input in the game", "Use only the on-screen controls or a controller", profile.disableTouch) { profile.disableTouch = it; changed() }
                c.action("Custom JavaScript", if (profile.customJs.isBlank()) "None" else "Active", R.drawable.ic_layers) {
                    promptSheet(act, "Custom JavaScript", "Runs once the page has loaded", profile.customJs, true) { v ->
                        profile.customJs = v.trim()
                        changed()
                        build()
                    }
                }
            }
        }

        if (gameId != null) {
            body.add(act.button("Reset all settings to defaults", R.drawable.ic_refresh, BTN_GHOST) {
                confirmSheet(act, "Reset settings?", "This game's settings go back to your default profile. Saves are not touched.", "Reset", false) {
                    val d = Library.defaults()
                    val keys = ArrayList<String>()
                    val keyIt = profile.json.keys()
                    while (keyIt.hasNext()) keys.add(keyIt.next())
                    for (k in keys) profile.json.remove(k)
                    val dk = d.json.keys()
                    while (dk.hasNext()) {
                        val k = dk.next()
                        profile.json.put(k, d.json.get(k))
                    }
                    changed()
                    build()
                }
            }, MATCH, WRAP, 0f, 0, 22, 0, 0)
        }

        col.addView(body)
        addView(act.scroll(col), LayoutParams(MATCH, MATCH))
    }

    private fun validJson(t: String): Boolean = try {
        JSONObject(t)
        true
    } catch (e: Throwable) {
        false
    }

    private fun section(body: LinearLayout, name: String, fill: (SettingsCard) -> Unit) {
        body.add(act.sectionTitle(name), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val card = SettingsCard(act)
        fill(card)
        body.addView(card.view)
    }

    private fun editLayout(portrait: Boolean) {
        val id = gameId ?: return
        val i = Intent(act, ControlsEditorActivity::class.java)
        i.putExtra(ControlsEditorActivity.EXTRA_GAME_ID, id)
        i.putExtra(ControlsEditorActivity.EXTRA_PORTRAIT, portrait)
        act.startActivity(i)
    }

    private var first = true

    override fun onShow() {
        // The layout editor changes the stored profile from another activity; rebuild so the sliders match.
        if (first) {
            first = false
            return
        }
        build()
    }

    private fun pickSoundfont() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        act.launchForResult(i) { data ->
            val uri = data?.data
            if (uri != null) {
                act.toast("Importing soundfont")
                Bg.io.execute {
                    var ok = false
                    val dest = File(Paths.rgss, "soundfont-" + (gameId ?: "default") + ".sf2")
                    try {
                        act.contentResolver.openInputStream(uri)?.use { ins -> dest.outputStream().use { out -> ins.copyTo(out, 128 * 1024) } }
                        ok = dest.length() > 0
                    } catch (t: Throwable) {
                        dest.delete()
                    }
                    Bg.ui {
                        if (ok) {
                            profile.midiFont = dest.absolutePath
                            changed()
                            build()
                        } else {
                            act.toast("Could not import that file")
                        }
                    }
                }
            }
        }
    }
}
