package dev.splice.player.ui

import android.graphics.Bitmap
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import dev.splice.player.R
import dev.splice.player.core.Bg
import dev.splice.player.core.Fmt
import dev.splice.player.data.CoverStore
import dev.splice.player.data.Library
import dev.splice.player.data.SaveVault
import dev.splice.player.model.Game

/** Saves tab: every game that has saves or backups, with quick access to its save manager. */
class SavesView(private val act: MainActivity) : Screen(act) {
    private val list: LinearLayout = act.vbox()

    private class Row(val game: Game, val files: Int, val bytes: Long, val modified: Long, val backups: Int)

    init {
        val col = act.vbox()
        val head = act.vbox()
        head.setPadding(act.dp(20), act.dp(18), act.dp(20), act.dp(8))
        head.addView(act.text("Saves", 28f, C.TEXT, 2))
        head.add(act.text("Slots, backups and transfers for every game", 13f, C.DIM), MATCH, WRAP, 0f, 0, 4, 0, 0)
        col.addView(head)
        list.setPadding(act.dp(16), act.dp(8), act.dp(16), act.dp(24))
        col.addView(list)
        addView(act.scroll(col), LayoutParams(MATCH, MATCH))
    }

    override fun onShow() {
        Bg.io.execute {
            val rows = ArrayList<Row>()
            for (g in Library.all()) {
                val files = SaveVault.scan(g)
                val backups = SaveVault.backups(g)
                if (files.isNotEmpty() || backups.isNotEmpty()) {
                    val newest = maxOf(files.maxOfOrNull { it.modified } ?: 0L, backups.firstOrNull()?.created ?: 0L)
                    rows.add(Row(g, files.size, files.sumOf { it.size }, newest, backups.size))
                }
            }
            rows.sortByDescending { it.modified }
            Bg.ui { render(rows) }
        }
    }

    private fun render(rows: List<Row>) {
        list.removeAllViews()
        if (rows.isEmpty()) {
            val e = act.vbox()
            e.gravity = Gravity.CENTER_HORIZONTAL
            e.setPadding(act.dp(30), act.dp(56), act.dp(30), act.dp(30))
            e.add(act.icon(R.drawable.ic_saves, C.FAINT, 52), act.dp(52), act.dp(52))
            e.add(act.text("No saves yet", 19f, C.TEXT, 1), WRAP, WRAP, 0f, 0, 16, 0, 0)
            val d = act.text("Play a game and save in it. Saves show up here, and Splice backs them up automatically.", 14f, C.DIM)
            d.gravity = Gravity.CENTER
            e.add(d, MATCH, WRAP, 0f, 0, 8, 0, 0)
            list.addView(e)
            return
        }
        for (r in rows) list.add(row(r), MATCH, WRAP, 0f, 0, 0, 0, 10)
    }

    private fun row(r: Row): View {
        val c = act.hbox()
        c.setPadding(act.dp(12), act.dp(12), act.dp(14), act.dp(12))
        c.background = act.ripple(act.shape(C.SURFACE, 16f, C.OUTLINE, 1f), 16f)
        val thumb = ImageView(act)
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.background = act.shape(C.SURFACE2, 10f)
        thumb.clipToOutline = true
        thumb.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) {
                o.setRoundRect(0, 0, v.width, v.height, act.dpf(10f))
            }
        }
        c.add(thumb, act.dp(48), act.dp(64), 0f, 0, 0, 14, 0)
        CoverStore.load(r.game, 144, 192) { bmp: Bitmap -> thumb.setImageBitmap(bmp) }
        val col = act.vbox()
        col.addView(act.text(r.game.title, 15f, C.TEXT, 1, 1))
        val parts = ArrayList<String>()
        if (r.files > 0) parts.add("${r.files} files · ${Fmt.size(r.bytes)}")
        if (r.backups > 0) parts.add("${r.backups} backups")
        col.add(act.text(parts.joinToString(" · "), 12.5f, C.DIM, 0, 1), MATCH, WRAP, 0f, 0, 4, 0, 0)
        col.add(act.text("Updated " + Fmt.ago(r.modified), 12f, C.FAINT), MATCH, WRAP, 0f, 0, 2, 0, 0)
        c.add(col, 0, WRAP, 1f)
        c.addView(act.icon(R.drawable.ic_chevron_right, C.FAINT, 20))
        c.isClickable = true
        c.setOnClickListener { act.push(SaveManagerView(act, r.game.id)) }
        c.pressable(0.98f)
        return c
    }
}
