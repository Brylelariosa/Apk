package dev.splice.player.ui

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import dev.splice.player.R
import dev.splice.player.core.Bg
import dev.splice.player.core.Files
import dev.splice.player.core.Fmt
import dev.splice.player.core.Paths
import dev.splice.player.data.CoverStore
import dev.splice.player.data.Detector
import dev.splice.player.data.Library
import dev.splice.player.engine.EngineInfo
import dev.splice.player.model.EngineKind
import dev.splice.player.model.Game

/** One game: hero, Play, quick access to settings/saves/fixes/logs, info and management. */
class GameDetailView(private val act: MainActivity, private val gameId: String) : Screen(act) {
    private val listener: () -> Unit = { rebuild() }
    private var sizeValue: TextView? = null

    init {
        Library.addListener(listener)
        rebuild()
    }

    override fun onShow() {
        rebuild()
    }

    override fun onDestroyScreen() {
        Library.removeListener(listener)
    }

    private fun rebuild() {
        removeAllViews()
        val g = Library.get(gameId) ?: return
        build(g)
    }

    private fun build(g: Game) {
        val col = act.vbox()
        col.addView(hero(g))

        val body = act.vbox()
        body.setPadding(act.dp(18), act.dp(8), act.dp(18), act.dp(28))

        body.add(act.button("Play", R.drawable.ic_play, BTN_PRIMARY) { act.play(g) }.also {
            it.textSize = 16f
            it.setPadding(act.dp(18), act.dp(16), act.dp(18), act.dp(16))
        }, MATCH, WRAP, 0f, 0, 14, 0, 0)

        val engineLine = if (g.format.engine == EngineKind.RGSS)
            "Runs on mkxp-z (RGSS${g.format.rgssVersion}) in its own process"
        else
            "Runs on the system WebView with Splice's NW.js layer"
        body.add(act.text(engineLine, 12.5f, C.FAINT), MATCH, WRAP, 0f, 2, 8, 0, 0)

        if (g.format.engine == EngineKind.RGSS) {
            val problem = EngineInfo.rgssProblem(act)
            if (problem != null) {
                val row = act.hbox()
                row.setPadding(act.dp(14), act.dp(12), act.dp(14), act.dp(12))
                row.background = act.shape(0x22FF6B7A, 14f, 0x55FF6B7A, 1f)
                row.addView(act.icon(R.drawable.ic_warning, C.DANGER, 22))
                row.add(act.text(problem, 12.5f, C.TEXT), 0, WRAP, 1f, 12, 0, 0, 0)
                body.add(row, MATCH, WRAP, 0f, 0, 14, 0, 0)
            }
        }

        // quick access tiles
        val r1 = act.hbox(false)
        r1.add(tile(R.drawable.ic_settings, "Settings", "Display, speed, controls") { act.push(ProfileEditorView.forGame(act, g)) }, 0, WRAP, 1f, 0, 0, 6, 0)
        r1.add(tile(R.drawable.ic_saves, "Saves", "Slots and backups") { act.push(SaveManagerView(act, g.id)) }, 0, WRAP, 1f, 6, 0, 0, 0)
        body.add(r1, MATCH, WRAP, 0f, 0, 18, 0, 0)
        val r2 = act.hbox(false)
        r2.add(tile(R.drawable.ic_shield, "Troubleshoot", "Checks and fixes") { act.push(TroubleshootView(act, g)) }, 0, WRAP, 1f, 0, 0, 6, 0)
        r2.add(tile(R.drawable.ic_logs, "Logs", "Session output") { act.push(LogsView(act, g.id)) }, 0, WRAP, 1f, 6, 0, 0, 0)
        body.add(r2, MATCH, WRAP, 0f, 0, 12, 0, 0)

        // info
        body.add(act.sectionTitle("Details"), MATCH, WRAP, 0f, 4, 26, 0, 10)
        val info = SettingsCard(act)
        info.info("Format", g.format.label)
        info.info("Location", if (g.managed) "Imported copy" else "In place")
        info.info("Folder", g.path)
        val sizeRow = act.hbox()
        sizeRow.setPadding(act.dp(16), act.dp(13), act.dp(16), act.dp(13))
        sizeRow.add(act.text("Size on disk", 14f, C.TEXT, 1), WRAP, WRAP, 0f, 0, 0, 16, 0)
        val sv = act.text("Calculating", 13.5f, C.DIM)
        sv.gravity = Gravity.END
        sizeRow.add(sv, 0, WRAP, 1f)
        sizeValue = sv
        info.custom(sizeRow)
        info.info("Added", Fmt.date(g.addedAt))
        info.info("Last played", Fmt.ago(g.lastPlayed))
        info.info("Play time", if (g.playTimeMs <= 0) "None yet" else Fmt.duration(g.playTimeMs))
        body.addView(info.view)
        Bg.io.execute {
            val size = Files.dirSize(g.dir)
            Bg.ui { sizeValue?.text = Fmt.size(size) }
        }

        body.add(act.button("Remove from library", R.drawable.ic_trash, BTN_DANGER) { removeSheet(g) }, MATCH, WRAP, 0f, 0, 24, 0, 0)
        col.addView(body)
        addView(act.scroll(col), LayoutParams(MATCH, MATCH))
    }

    private fun hero(g: Game): View {
        val hero = FrameLayout(act)
        val bg = ImageView(act)
        bg.scaleType = ImageView.ScaleType.CENTER_CROP
        bg.alpha = 0.5f
        hero.addView(bg, FrameLayout.LayoutParams(MATCH, MATCH))
        val fade = View(act)
        fade.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x4D14121D, C.BG))
        hero.addView(fade, FrameLayout.LayoutParams(MATCH, MATCH))

        val top = act.hbox()
        top.setPadding(act.dp(8), act.dp(8), act.dp(8), act.dp(8))
        top.addView(act.iconButton(R.drawable.ic_back, C.TEXT, 44) { act.pop() })
        top.add(View(act), 0, 0, 1f)
        top.addView(act.iconButton(R.drawable.ic_more, C.TEXT, 44) { moreSheet(g) })
        hero.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        val row = act.hbox(false)
        row.gravity = Gravity.BOTTOM
        row.setPadding(act.dp(18), 0, act.dp(18), act.dp(10))
        val poster = ImageView(act)
        poster.scaleType = ImageView.ScaleType.CENTER_CROP
        poster.background = act.shape(C.SURFACE2, 16f)
        poster.clipToOutline = true
        poster.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, o: android.graphics.Outline) {
                o.setRoundRect(0, 0, v.width, v.height, act.dpf(16f))
            }
        }
        poster.elevation = act.dp(8).toFloat()
        row.add(poster, act.dp(112), act.dp(149), 0f, 0, 0, 16, 0)
        CoverStore.load(g, 336, 448) { bmp ->
            poster.setImageBitmap(bmp)
            bg.setImageBitmap(bmp)
        }
        val info = act.vbox()
        info.gravity = Gravity.BOTTOM
        info.addView(act.text(g.title, 22f, C.TEXT, 2, 3))
        val meta = act.hbox()
        meta.addView(act.badge(g.format.badge, C.MINT))
        if (g.isPokemon) meta.add(act.badge("PKMN", C.PEACH), WRAP, WRAP, 0f, 6, 0, 0, 0)
        if (g.favorite) meta.add(act.icon(R.drawable.ic_star_fill, C.PEACH, 16), act.dp(16), act.dp(16), 0f, 8, 0, 0, 0)
        info.add(meta, MATCH, WRAP, 0f, 0, 10, 0, 0)
        row.add(info, 0, WRAP, 1f)
        hero.addView(row, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        hero.layoutParams = LinearLayout.LayoutParams(MATCH, act.dp(270))
        return hero
    }

    private fun tile(icon: Int, title: String, sub: String, onClick: () -> Unit): View {
        val c = act.vbox()
        c.setPadding(act.dp(16), act.dp(16), act.dp(16), act.dp(16))
        c.background = act.ripple(act.shape(C.SURFACE, 18f, C.OUTLINE, 1f), 18f)
        c.addView(act.icon(icon, C.MINT, 26))
        c.add(act.text(title, 15f, C.TEXT, 1), MATCH, WRAP, 0f, 0, 12, 0, 0)
        c.add(act.text(sub, 12f, C.DIM, 0, 1), MATCH, WRAP, 0f, 0, 3, 0, 0)
        c.isClickable = true
        c.setOnClickListener { onClick() }
        c.pressable(0.97f)
        return c
    }

    private fun moreSheet(g: Game) {
        val s = Sheet(act, g.title)
        s.action(if (g.favorite) "Remove from favorites" else "Add to favorites", R.drawable.ic_star) {
            g.favorite = !g.favorite
            Library.update(g)
        }
        s.action("Rename", R.drawable.ic_pencil) {
            promptSheet(act, "Rename game", "Title", g.title, false) { v ->
                if (v.isNotBlank()) {
                    g.title = v.trim()
                    Library.update(g)
                }
            }
        }
        s.action("Choose cover image", R.drawable.ic_image) {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "image/*"
            act.launchForResult(i) { data ->
                val uri = data?.data
                if (uri != null) {
                    Bg.io.execute {
                        val ok = CoverStore.setCustom(act, g, uri)
                        Bg.ui { act.toast(if (ok) "Cover updated" else "Could not read that image") }
                    }
                }
            }
        }
        s.action("Reset cover", R.drawable.ic_refresh) {
            g.coverPath = null
            CoverStore.invalidate(g)
            Library.update(g)
        }
        s.action("Detect format again", R.drawable.ic_search) {
            Bg.io.execute {
                val r = Detector.detect(g.dir)
                Bg.ui {
                    if (r == null) {
                        act.toast("No RPG Maker game found in this folder")
                    } else {
                        g.format = r.format
                        g.webRoot = r.webRoot?.absolutePath
                        g.execName = r.execName
                        g.tags = r.tags.toMutableSet()
                        Library.update(g)
                        act.toast("Detected ${r.format.label}")
                    }
                }
            }
        }
        s.show()
    }

    private fun removeSheet(g: Game) {
        val s = Sheet(act, "Remove ${g.title}?")
        s.add(act.text("Saves and backups are kept unless you delete them below.", 14f, C.DIM))
        val col = act.vbox()
        col.add(act.button("Remove from library", 0, BTN_TONAL) {
            s.dismiss()
            Library.remove(g.id, deleteFiles = false, deleteSaves = false)
            act.pop()
        }, MATCH, WRAP, 0f, 0, 16, 0, 0)
        if (g.managed) {
            col.add(act.button("Remove and delete game files", R.drawable.ic_trash, BTN_DANGER) {
                s.dismiss()
                Library.remove(g.id, deleteFiles = true, deleteSaves = false)
                act.pop()
            }, MATCH, WRAP, 0f, 0, 10, 0, 0)
        }
        col.add(act.button("Remove everything, including saves", R.drawable.ic_trash, BTN_DANGER) {
            s.dismiss()
            confirmSheet(act, "Delete saves too?", "This permanently deletes this game's saves, slots and backups.", "Delete all", true) {
                Library.remove(g.id, deleteFiles = g.managed, deleteSaves = true)
                act.pop()
            }
        }, MATCH, WRAP, 0f, 0, 10, 0, 0)
        s.add(col)
        s.show()
    }

    @Suppress("unused")
    private fun pathsHint() = Paths.games
}
