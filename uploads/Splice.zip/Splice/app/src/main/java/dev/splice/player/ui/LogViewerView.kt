package dev.splice.player.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import dev.splice.player.R
import dev.splice.player.core.Bg
import dev.splice.player.core.Files
import java.io.File

/** Reads one log file with colour-coded lines, an errors-only filter, copy/share/save. */
class LogViewerView(private val act: MainActivity, private val title: String, private val file: File) : Screen(act) {
    private val textView = TextView(act)
    private val scroll: ScrollView
    private var raw = ""
    private var errorsOnly = false
    private val chipsHolder = act.hbox()

    init {
        val col = act.vbox()
        col.addView(act.topBar(title, { act.pop() }, act.iconButton(R.drawable.ic_more, C.TEXT, 44) { menu() }))

        chipsHolder.setPadding(act.dp(16), act.dp(2), act.dp(16), act.dp(8))
        col.addView(chipsHolder)
        paintChips()

        textView.typeface = Typeface.MONOSPACE
        textView.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11f)
        textView.setTextColor(C.DIM)
        textView.setTextIsSelectable(true)
        textView.setPadding(act.dp(14), act.dp(12), act.dp(14), act.dp(24))
        textView.background = act.shape(C.SURFACE, 14f, C.OUTLINE, 1f)
        scroll = ScrollView(act)
        scroll.isVerticalScrollBarEnabled = true
        scroll.addView(textView, LayoutParams(MATCH, WRAP))
        col.add(scroll, MATCH, 0, 1f, 12, 0, 12, 12)
        addView(col, LayoutParams(MATCH, MATCH))
        load()
    }

    private fun paintChips() {
        chipsHolder.removeAllViews()
        chipsHolder.add(act.chip("All lines", !errorsOnly) { errorsOnly = false; paintChips(); render() }, WRAP, WRAP, 0f, 0, 0, 8, 0)
        chipsHolder.add(act.chip("Errors and warnings", errorsOnly) { errorsOnly = true; paintChips(); render() }, WRAP, WRAP, 0f, 0, 0, 8, 0)
    }

    private fun load() {
        textView.text = "Loading"
        Bg.io.execute {
            val t = try {
                Files.tail(file, 300_000)
            } catch (e: Throwable) {
                "Could not read ${file.name}: ${e.message}"
            }
            Bg.ui {
                raw = t
                render()
            }
        }
    }

    private fun levelOf(line: String): Int {
        val l = line.lowercase()
        return when {
            line.contains("NATIVE CRASH") || line.startsWith("  #") && line.contains(" pc ") -> 3
            l.contains("fatal") || l.contains("exception") || l.contains(" e ") || l.contains("error") || l.contains("traceback") -> 3
            l.contains(" w ") || l.contains("warn") -> 2
            else -> 0
        }
    }

    private fun render() {
        if (raw.isBlank()) {
            textView.text = "This log is empty."
            return
        }
        val lines = raw.lines()
        val sb = SpannableStringBuilder()
        var shown = 0
        var i = maxOf(0, lines.size - 3000)
        while (i < lines.size) {
            val line = lines[i]
            val lv = levelOf(line)
            if (!errorsOnly || lv >= 2) {
                val start = sb.length
                sb.append(line).append('\n')
                val color = when (lv) {
                    3 -> C.DANGER
                    2 -> C.WARN
                    else -> C.DIM
                }
                if (lv > 0) sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                shown++
            }
            i++
        }
        if (shown == 0) sb.append("No errors or warnings in this log.")
        textView.text = sb
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun menu() {
        val s = Sheet(act, title, file.name)
        s.action("Copy to clipboard", R.drawable.ic_copy) {
            val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Splice log", raw.takeLast(100_000)))
            act.toast("Copied")
        }
        s.action("Share", R.drawable.ic_export) {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_SUBJECT, "Splice log: $title")
            i.putExtra(Intent.EXTRA_TEXT, raw.takeLast(100_000))
            act.startActivity(Intent.createChooser(i, "Share log"))
        }
        s.action("Save as file", R.drawable.ic_import) {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TITLE, file.name.replace(Regex("[^A-Za-z0-9._-]+"), "_"))
            act.launchForResult(i) { data ->
                val uri = data?.data
                if (uri != null) {
                    Bg.io.execute {
                        val ok = try {
                            act.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                            true
                        } catch (t: Throwable) {
                            false
                        }
                        Bg.ui { act.toast(if (ok) "Saved" else "Could not save the file") }
                    }
                }
            }
        }
        s.action("Reload", R.drawable.ic_refresh) { load() }
        s.action("Delete this log", R.drawable.ic_trash, true) {
            file.delete()
            act.pop()
        }
        s.show()
    }
}
