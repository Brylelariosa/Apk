package dev.splice.player.ui

import android.os.Build
import android.widget.LinearLayout
import android.widget.TextView
import dev.splice.player.BuildConfig
import dev.splice.player.R
import dev.splice.player.core.Bg
import dev.splice.player.core.Files
import dev.splice.player.core.Fmt
import dev.splice.player.core.Native
import dev.splice.player.core.Paths
import dev.splice.player.core.Prefs
import dev.splice.player.data.Detector
import dev.splice.player.data.Library
import dev.splice.player.data.StorageAccess
import dev.splice.player.engine.EngineInfo

/** App-wide options: storage access, engine status, default profile, backups, maintenance, about. */
class SettingsView(private val act: MainActivity) : Screen(act) {
    private val body: LinearLayout = act.vbox()
    private var gamesSize: TextView? = null
    private var gamesSizeText: String? = null
    private var gamesSizeRunning = false

    init {
        val col = act.vbox()
        val head = act.vbox()
        head.setPadding(act.dp(20), act.dp(18), act.dp(20), act.dp(8))
        head.addView(act.text("Settings", 28f, C.TEXT, 2))
        head.add(act.text("Storage, engines and defaults", 13f, C.DIM), MATCH, WRAP, 0f, 0, 4, 0, 0)
        col.addView(head)
        body.setPadding(act.dp(16), act.dp(4), act.dp(16), act.dp(32))
        col.addView(body)
        addView(act.scroll(col), LayoutParams(MATCH, MATCH))
    }

    override fun onShow() {
        build()
    }

    private fun build() {
        body.removeAllViews()

        // storage
        body.add(act.sectionTitle("Storage"), MATCH, WRAP, 0f, 6, 14, 0, 10)
        val st = SettingsCard(act)
        val granted = StorageAccess.hasAllFiles(act)
        st.action(
            "All files access",
            if (granted) "Allowed. Games can stay where they are." else "Not allowed. Needed to play games stored outside Splice's folder.",
            R.drawable.ic_folder
        ) { StorageAccess.request(act) }
        st.info("Imported games", Paths.games.absolutePath)
        val used = act.hbox()
        used.setPadding(act.dp(16), act.dp(13), act.dp(16), act.dp(13))
        used.add(act.text("Used by imported games", 14f, C.TEXT, 1), WRAP, WRAP, 0f, 0, 0, 16, 0)
        val uv = act.text("Calculating", 13.5f, C.DIM)
        uv.gravity = android.view.Gravity.END
        used.add(uv, 0, WRAP, 1f)
        gamesSize = uv
        st.custom(used)
        body.addView(st.view)
        gamesSizeText?.let { uv.text = it }
        if (!gamesSizeRunning) {
            gamesSizeRunning = true
            Bg.slow.execute {
                val size = try {
                    Files.dirSize(Paths.games)
                } catch (t: Throwable) {
                    -1L
                }
                Bg.ui {
                    val label = if (size >= 0L) Fmt.size(size) else "Unknown"
                    gamesSizeText = label
                    gamesSizeRunning = false
                    gamesSize?.text = label
                }
            }
        }

        // engines
        body.add(act.sectionTitle("Engines"), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val en = SettingsCard(act)
        val problem = EngineInfo.rgssProblem(act)
        en.info("RPG Maker XP / VX / VX Ace", if (problem == null) "mkxp-z ready" else "Unavailable", if (problem == null) C.MINT else C.DANGER)
        if (problem != null) en.note(problem, C.DIM)
        else en.note(EngineInfo.statusText(act), C.FAINT)
        en.info("RPG Maker MV / MZ", "System WebView", C.MINT)
        en.info("WebView", EngineInfo.webViewVersion(act) ?: "unknown")
        en.info("Device CPU", Native.abi())
        body.addView(en.view)

        // defaults
        body.add(act.sectionTitle("New games"), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val df = SettingsCard(act)
        df.action("Default profile", "Starting settings for games you add from now on", R.drawable.ic_settings) {
            act.push(ProfileEditorView.forDefaults(act))
        }
        body.addView(df.view)

        // saves
        body.add(act.sectionTitle("Saves"), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val sv = SettingsCard(act)
        sv.toggle("Automatic backups", "Before you play and after a session when saves changed", Prefs.autoBackup) { Prefs.autoBackup = it }
        val keepOptions = listOf(3, 5, 10, 20)
        sv.choice("Automatic backups to keep", keepOptions.map { it.toString() }, keepOptions.indexOf(Prefs.backupKeep).let { if (it < 0) 1 else it }) {
            Prefs.backupKeep = keepOptions[it]
        }
        body.addView(sv.view)

        // maintenance
        body.add(act.sectionTitle("Maintenance"), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val mt = SettingsCard(act)
        mt.action("Check all games again", "Re-detect formats and remove entries whose folders are gone", R.drawable.ic_refresh) { rescan() }
        mt.action("Clear cover cache", null, R.drawable.ic_image) {
            for (g in Library.all()) dev.splice.player.data.CoverStore.invalidate(g)
            act.toast("Covers will be rebuilt")
        }
        mt.action("Clear all logs", null, R.drawable.ic_trash, true) {
            Paths.sessions.listFiles()?.forEach { Files.deleteRecursive(it) }
            Paths.logs.listFiles { f -> f.name.startsWith("crash-") }?.forEach { it.delete() }
            act.toast("Logs cleared")
        }
        body.addView(mt.view)

        // about
        body.add(act.sectionTitle("About"), MATCH, WRAP, 0f, 6, 22, 0, 10)
        val ab = SettingsCard(act)
        ab.info("Splice", BuildConfig.VERSION_NAME)
        ab.info("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        ab.action("Open-source notices", "mkxp-z, SDL, Ruby and more", R.drawable.ic_info) { notices() }
        body.addView(ab.view)
    }

    private fun rescan() {
        Bg.io.execute {
            var removed = 0
            var updated = 0
            for (g in Library.all()) {
                if (!g.dir.isDirectory) {
                    if (!g.managed) continue   // external folder may just be unmounted; keep the entry
                    Library.remove(g.id, deleteFiles = false, deleteSaves = false)
                    removed++
                    continue
                }
                val r = Detector.detect(g.dir) ?: continue
                if (r.format != g.format || r.webRoot?.absolutePath != g.webRoot) {
                    g.format = r.format
                    g.webRoot = r.webRoot?.absolutePath
                    g.execName = r.execName
                    g.tags = r.tags.toMutableSet()
                    Library.update(g)
                    updated++
                }
            }
            Bg.ui { act.toast("Checked: $updated updated, $removed removed") }
        }
    }

    private fun notices() {
        val s = Sheet(act, "Open-source notices")
        val t = act.text(
            "Splice is free software released under the GNU GPL, version 2 or later.\n\n" +
                "RPG Maker XP / VX / VX Ace games run on mkxp-z (GPL-2.0-or-later), a free implementation of RGSS by " +
                "Ancurio and contributors, using SDL2 (zlib), Ruby (BSD-2-Clause), OpenAL Soft (LGPL-2.0), PhysFS (zlib), " +
                "Pixman (MIT), libsigc++ (LGPL) and other libraries, through the mkxp-z Android port by thehatkid and BookerRues9.\n\n" +
                "RPG Maker MV / MZ games run in the system WebView (Chromium). NW.js is emulated by Splice's own compatibility layer.\n\n" +
                "RPG Maker, RGSS and Pokémon are trademarks of their respective owners. Splice is not affiliated with them and " +
                "does not include any game content.",
            13.5f, C.DIM
        )
        t.setLineSpacing(0f, 1.2f)
        s.add(t)
        s.show()
    }
}
