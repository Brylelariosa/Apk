package dev.splice.player.data

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import dev.splice.player.core.AppLog
import dev.splice.player.core.Bg
import dev.splice.player.core.Files
import dev.splice.player.core.Paths
import dev.splice.player.model.Game
import dev.splice.player.model.Profile
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** Progress/result holder for one import, polled by the UI. */
class ImportTask(val label: String) {
    val cancel = AtomicBoolean(false)

    @Volatile var message: String = "Preparing"
    @Volatile var bytes: Long = 0
    @Volatile var total: Long = 0
    @Volatile var files: Int = 0
    @Volatile var finished: Boolean = false
    @Volatile var error: String? = null
    @Volatile var added: List<Game> = emptyList()

    /** Games found that need the user's decision (several games, or one that looks like a duplicate). */
    @Volatile var found: List<Found> = emptyList()

    /** Extracted archive kept until the user has chosen; null for games that stay where they are. */
    @Volatile var work: File? = null

    /** 0..1, or -1 when the total is unknown */
    val fraction: Float
        get() = if (total > 0) (bytes.toFloat() / total.toFloat()).coerceIn(0f, 1f) else -1f
}

/** One game detected inside an archive or folder. [rel] is its folder relative to what was scanned. */
class Found(val result: Detector.Result, val rel: String, val size: Long, val duplicate: Boolean)

object Importer {
    // ---------- public entry points ----------

    fun importZip(ctx: Context, uri: Uri, task: ImportTask, done: (ImportTask) -> Unit) {
        Bg.io.execute {
            val work = File(Paths.games, ".tmp-" + Library.newId())
            var keep = false
            try {
                val cr = ctx.contentResolver
                task.total = querySize(cr, uri)
                task.message = "Extracting archive"
                work.mkdirs()
                Zip.extract({ cr.openInputStream(uri) }, work, task.cancel) { bytes, name ->
                    if (bytes >= 0) {
                        task.bytes = bytes
                    } else {
                        task.files++
                        if (name.isNotEmpty()) task.message = name.substringAfterLast('/')
                    }
                }
                task.message = "Looking for games"
                keep = review(task, work, work)
                if (!keep && task.added.isEmpty() && task.error == null) task.error = "No RPG Maker game was found in this archive."
            } catch (c: ImportCancelled) {
                task.error = "Cancelled"
            } catch (t: Throwable) {
                AppLog.e("import", "zip import failed", t)
                task.error = t.message ?: t.javaClass.simpleName
            } finally {
                if (!keep) Files.deleteRecursive(work)
                task.finished = true
                Bg.ui { done(task) }
            }
        }
    }

    /** Folder picked through the system file picker (content:// tree). */
    fun importTree(ctx: Context, tree: Uri, task: ImportTask, done: (ImportTask) -> Unit) {
        Bg.io.execute {
            val work = File(Paths.games, ".tmp-" + Library.newId())
            var keep = false
            try {
                val real = StorageAccess.treeUriToPath(tree)
                if (real != null && StorageAccess.hasAllFiles(ctx)) {
                    task.message = "Scanning folder"
                    keep = review(task, real, null)
                } else {
                    task.message = "Copying files"
                    work.mkdirs()
                    copyTree(ctx, tree, work, task)
                    task.message = "Looking for games"
                    keep = review(task, work, work)
                }
                if (!keep && task.added.isEmpty() && task.error == null) task.error = "No RPG Maker game was found in this folder."
            } catch (c: ImportCancelled) {
                task.error = "Cancelled"
            } catch (t: Throwable) {
                AppLog.e("import", "folder import failed", t)
                task.error = t.message ?: t.javaClass.simpleName
            } finally {
                if (!keep) Files.deleteRecursive(work)
                task.finished = true
                Bg.ui { done(task) }
            }
        }
    }

    /** Folder we can read directly (needs All files access): the game stays where it is. */
    fun importPath(dir: File, task: ImportTask, done: (ImportTask) -> Unit) {
        Bg.io.execute {
            try {
                task.message = "Scanning folder"
                review(task, dir, null)
                if (task.added.isEmpty() && task.found.isEmpty() && task.error == null) task.error = "No RPG Maker game was found in this folder."
            } catch (t: Throwable) {
                AppLog.e("import", "scan failed", t)
                task.error = t.message ?: t.javaClass.simpleName
            } finally {
                task.finished = true
                Bg.ui { done(task) }
            }
        }
    }

    /**
     * A file picked inside a game folder (normally Game.exe). Splice cannot run the .exe itself, it is the
     * Windows launcher; the game is the data next to it, so the folder it sits in is added in place.
     */
    fun importExe(ctx: Context, uri: Uri, task: ImportTask, done: (ImportTask) -> Unit) {
        Bg.io.execute {
            try {
                task.message = "Finding the game folder"
                val file = StorageAccess.documentUriToPath(ctx, uri)
                val dir = if (file == null) null else if (file.isDirectory) file else file.parentFile
                if (dir == null) {
                    task.error = "Splice couldn't tell which folder that file is in. Use \"Add a game folder\" instead."
                } else if (StorageAccess.needsPermission(ctx, dir)) {
                    task.error = "Allow \"All files access\" first, so Splice can read the game files next to ${file?.name ?: "that file"}."
                } else {
                    val r = Detector.detect(dir) ?: Detector.scan(dir, 2).firstOrNull()
                    if (r == null) {
                        task.error = "No RPG Maker game found in \"${dir.name}\". Pick the Game.exe that sits in the game's folder."
                    } else if (Library.findByPath(r.root.absolutePath) != null) {
                        task.error = "${r.title} is already in your library."
                    } else {
                        task.message = "Adding ${r.title}"
                        task.added = commit(listOf(Found(r, "", 0L, false)), false)
                    }
                }
            } catch (t: Throwable) {
                AppLog.e("import", "exe import failed", t)
                task.error = t.message ?: t.javaClass.simpleName
            } finally {
                task.finished = true
                Bg.ui { done(task) }
            }
        }
    }

    /** Second step of an import that needed a decision: add the games the user picked, then clean up. */
    fun addFound(task: ImportTask, chosen: List<Found>, work: File?, done: (ImportTask) -> Unit) {
        Bg.io.execute {
            try {
                task.message = "Adding games"
                task.added = commit(chosen, work != null)
            } catch (t: Throwable) {
                AppLog.e("import", "adding games failed", t)
                task.error = t.message ?: t.javaClass.simpleName
            } finally {
                if (work != null) Files.deleteRecursive(work)
                task.finished = true
                Bg.ui { done(task) }
            }
        }
    }

    /** The user cancelled the "which games?" step: throw the extracted copy away. */
    fun discard(work: File?) {
        if (work == null) return
        Bg.io.execute { Files.deleteRecursive(work) }
    }

    /** Removes leftovers of imports that were interrupted (older than 12 hours). */
    fun sweepTemp() {
        try {
            val cutoff = System.currentTimeMillis() - 12L * 60 * 60 * 1000
            Paths.games.listFiles { f -> f.isDirectory && f.name.startsWith(".tmp-") && f.lastModified() < cutoff }
                ?.forEach { Files.deleteRecursive(it) }
        } catch (ignored: Throwable) {
        }
    }

    // ---------- internals ----------

    fun newProfileFor(@Suppress("UNUSED_PARAMETER") g: Game): Profile {
        val p = Library.defaults()
        if (!p.json.has("orientation")) p.orientation = 1
        return p
    }

    private fun querySize(cr: ContentResolver, uri: Uri): Long {
        return try {
            cr.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
            } ?: -1L
        } catch (t: Throwable) {
            -1L
        }
    }

    private fun slug(title: String): String {
        val s = title.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "-").trim('-')
        return if (s.isEmpty()) "game" else s.take(32)
    }

    /**
     * Looks for games in [base]. A single new game is added straight away. Several games, or one with the
     * same title and format as a game already in the library, are left in task.found for the user to choose.
     * Returns true when [work] must be kept until that choice is made.
     */
    private fun review(task: ImportTask, base: File, work: File?): Boolean {
        val results = Detector.scan(base, 3)
        val list = ArrayList<Found>()
        for (r in results) {
            // a game that stays in place and is already listed under the same folder
            if (work == null && Library.findByPath(r.root.absolutePath) != null) continue
            val rel = if (r.root == base) "" else r.root.relativeTo(base).path
            val dup = Library.all().any { it.format == r.format && it.title.equals(r.title, ignoreCase = true) }
            list.add(Found(r, rel, Files.dirSize(r.root), dup))
            AppLog.i("import", "found ${r.format.label} \"${r.title}\" at ${if (rel.isEmpty()) "(top level)" else rel}")
        }
        if (list.isEmpty()) {
            if (results.isNotEmpty() && task.error == null) task.error = "That game is already in your library."
            return false
        }
        if (list.size == 1 && !list[0].duplicate) {
            task.added = commit(list, work != null)
            return false
        }
        task.found = list
        task.work = work
        return true
    }

    private fun commit(list: List<Found>, managed: Boolean): List<Game> {
        val added = ArrayList<Game>()
        for (f in list) {
            val r = f.result
            if (managed) {
                added.add(adoptOne(r))
            } else {
                val path = r.root.absolutePath
                if (Library.findByPath(path) != null) continue
                val g = Game(
                    id = Library.newId(), title = r.title, path = path, format = r.format,
                    webRoot = r.webRoot?.absolutePath, managed = false,
                    tags = r.tags.toMutableSet(), execName = r.execName
                )
                Library.add(g, newProfileFor(g))
                added.add(g)
            }
        }
        return added
    }

    /** Moves one detected game from a temp folder into the managed games folder. */
    private fun adoptOne(r: Detector.Result): Game {
        val id = Library.newId()
        val finalDir = File(Paths.games, slug(r.title) + "-" + id.take(6))
        val rel = r.webRoot?.relativeTo(r.root)?.path
        if (!r.root.renameTo(finalDir)) {
            Files.copyRecursive(r.root, finalDir)
            Files.deleteRecursive(r.root)
        }
        val web = if (rel == null) null else (if (rel.isEmpty()) finalDir else File(finalDir, rel)).absolutePath
        val g = Game(
            id = id, title = r.title, path = finalDir.absolutePath, format = r.format,
            webRoot = web, managed = true, tags = r.tags.toMutableSet(), execName = r.execName
        )
        Library.add(g, newProfileFor(g))
        return g
    }

    private fun copyTree(ctx: Context, tree: Uri, dest: File, task: ImportTask) {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        copyDir(ctx, tree, rootId, dest, task)
    }

    private fun copyDir(ctx: Context, tree: Uri, docId: String, dest: File, task: ImportTask) {
        dest.mkdirs()
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val ids = ArrayList<String>()
        val names = ArrayList<String>()
        val dirs = ArrayList<Boolean>()
        ctx.contentResolver.query(childrenUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                ids.add(c.getString(0))
                names.add(c.getString(1) ?: "unnamed")
                dirs.add(DocumentsContract.Document.MIME_TYPE_DIR == c.getString(2))
            }
        }
        val buf = ByteArray(128 * 1024)
        for (i in ids.indices) {
            if (task.cancel.get()) throw ImportCancelled()
            val name = names[i].replace('/', '_').replace('\\', '_')
            if (name == "." || name == "..") continue
            if (dirs[i]) {
                copyDir(ctx, tree, ids[i], File(dest, name), task)
            } else {
                val uri = DocumentsContract.buildDocumentUriUsingTree(tree, ids[i])
                val input = ctx.contentResolver.openInputStream(uri) ?: continue
                input.use { ins ->
                    File(dest, name).outputStream().use { out ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            task.bytes += n
                            if (task.cancel.get()) throw ImportCancelled()
                        }
                    }
                }
                task.files++
                task.message = name
            }
        }
    }
}
