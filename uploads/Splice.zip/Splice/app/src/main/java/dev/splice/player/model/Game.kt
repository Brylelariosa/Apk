package dev.splice.player.model

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Game(
    val id: String,
    var title: String,
    var path: String,
    var format: Format,
    var webRoot: String?,
    var managed: Boolean,
    var favorite: Boolean = false,
    var addedAt: Long = System.currentTimeMillis(),
    var lastPlayed: Long = 0L,
    var playTimeMs: Long = 0L,
    var coverPath: String? = null,
    var tags: MutableSet<String> = linkedSetOf(),
    var execName: String? = null
) {
    val dir: File get() = File(path)
    val isPokemon: Boolean get() = tags.contains("pokemon")

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("title", title)
        o.put("path", path)
        o.put("format", format.id)
        o.put("webRoot", webRoot ?: JSONObject.NULL)
        o.put("managed", managed)
        o.put("favorite", favorite)
        o.put("addedAt", addedAt)
        o.put("lastPlayed", lastPlayed)
        o.put("playTimeMs", playTimeMs)
        o.put("coverPath", coverPath ?: JSONObject.NULL)
        o.put("tags", JSONArray(tags.toList()))
        o.put("execName", execName ?: JSONObject.NULL)
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Game? {
            val fmt = Format.fromId(o.optString("format")) ?: return null
            val id = o.optString("id")
            if (id.isEmpty()) return null
            val tags = linkedSetOf<String>()
            val ta = o.optJSONArray("tags")
            if (ta != null) for (i in 0 until ta.length()) tags.add(ta.optString(i))
            return Game(
                id = id,
                title = o.optString("title", "Untitled"),
                path = o.optString("path"),
                format = fmt,
                webRoot = if (o.isNull("webRoot")) null else o.optString("webRoot"),
                managed = o.optBoolean("managed", false),
                favorite = o.optBoolean("favorite", false),
                addedAt = o.optLong("addedAt", 0L),
                lastPlayed = o.optLong("lastPlayed", 0L),
                playTimeMs = o.optLong("playTimeMs", 0L),
                coverPath = if (o.isNull("coverPath")) null else o.optString("coverPath"),
                tags = tags,
                execName = if (o.isNull("execName")) null else o.optString("execName")
            )
        }
    }
}
