package dev.splice.player.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import dev.splice.player.model.ButtonSpec
import dev.splice.player.model.Controls

/**
 * On-screen gamepad drawn over a game. Emits Android key codes through [onKey]; the host turns them
 * into real KeyEvents for the WebView (MV/MZ) or SDL (RGSS). In edit mode buttons can be dragged.
 */
class TouchOverlayView(ctx: Context) : View(ctx) {
    var buttons: List<ButtonSpec> = emptyList()
        set(v) {
            field = v
            invalidate()
        }
    var opacity: Float = 0.6f
        set(v) {
            field = v
            invalidate()
        }
    var scale: Float = 1f
        set(v) {
            field = v
            invalidate()
        }
    var haptics: Boolean = true
    var editMode: Boolean = false

    /** Auto-hidden (e.g. a physical controller is in use). First touch brings it back. */
    var faded: Boolean = false
        set(v) {
            if (field == v) return
            field = v
            if (v) releaseAll()
            animate().alpha(if (v) 0f else 1f).setDuration(220).start()
        }
    var selected: ButtonSpec? = null
        set(v) {
            field = v
            invalidate()
        }

    var onKey: ((Int, Boolean) -> Unit)? = null
    var onMenu: (() -> Unit)? = null
    var onSelect: ((ButtonSpec?) -> Unit)? = null
    var onEdited: (() -> Unit)? = null

    private val down = HashSet<Int>()                 // key codes held (for drawing)
    private val pointerButton = HashMap<Int, String>() // pointer id -> button id
    private val pointerDpad = HashMap<Int, Set<Int>>()   // pointer id -> dpad keys it holds
    private var dragDx = 0f
    private var dragDy = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arrow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tmpPath = Path()

    init {
        stroke.style = Paint.Style.STROKE
        stroke.strokeWidth = context.dpf(2f)
        label.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        label.textAlign = Paint.Align.CENTER
    }

    private fun radius(b: ButtonSpec): Float = context.dpf(b.size * scale) / 2f

    private fun hit(x: Float, y: Float): ButtonSpec? {
        var best: ButtonSpec? = null
        var bestD = Float.MAX_VALUE
        for (b in buttons) {
            val cx = b.x * width
            val cy = b.y * height
            val d = Math.hypot((x - cx).toDouble(), (y - cy).toDouble()).toFloat()
            val r = radius(b) * (if (b.type == Controls.TYPE_DPAD) 1.1f else 1.15f)
            if (d <= r && d < bestD) {
                best = b
                bestD = d
            }
        }
        return best
    }

    private fun dpadKeys(b: ButtonSpec, x: Float, y: Float): Set<Int> {
        val dx = x - b.x * width
        val dy = y - b.y * height
        val r = radius(b)
        if (Math.hypot(dx.toDouble(), dy.toDouble()) < r * 0.2) return emptySet()
        val a = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble()))
        val keys = HashSet<Int>()
        if (a > -67.5 && a < 67.5) keys.add(KeyEvent.KEYCODE_DPAD_RIGHT)
        if (a > 112.5 || a < -112.5) keys.add(KeyEvent.KEYCODE_DPAD_LEFT)
        if (a > 22.5 && a < 157.5) keys.add(KeyEvent.KEYCODE_DPAD_DOWN)
        if (a < -22.5 && a > -157.5) keys.add(KeyEvent.KEYCODE_DPAD_UP)
        return keys
    }

    private fun setKey(code: Int, isDown: Boolean) {
        if (isDown) {
            if (down.add(code)) onKey?.invoke(code, true)
        } else {
            if (down.remove(code)) onKey?.invoke(code, false)
        }
        invalidate()
    }

    /** Releases everything that is currently held (call when the overlay is hidden or the game pauses). */
    fun releaseAll() {
        for (k in ArrayList(down)) setKey(k, false)
        pointerButton.clear()
        pointerDpad.clear()
    }

    private fun buzz() {
        if (haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (editMode) return editTouch(ev)
        if (faded) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) faded = false
            return false
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                val id = ev.getPointerId(i)
                val b = hit(ev.getX(i), ev.getY(i)) ?: return pointerButton.isNotEmpty()
                pointerButton[id] = b.id
                when (b.type) {
                    Controls.TYPE_DPAD -> {
                        val keys = dpadKeys(b, ev.getX(i), ev.getY(i))
                        pointerDpad[id] = keys
                        for (k in keys) setKey(k, true)
                    }
                    Controls.TYPE_MENU -> onMenu?.invoke()
                    else -> if (b.key != 0) setKey(b.key, true)
                }
                buzz()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until ev.pointerCount) {
                    val id = ev.getPointerId(i)
                    val bid = pointerButton[id] ?: continue
                    val b = buttons.firstOrNull { it.id == bid } ?: continue
                    if (b.type == Controls.TYPE_DPAD) {
                        val now = dpadKeys(b, ev.getX(i), ev.getY(i))
                        val before = pointerDpad[id] ?: emptySet()
                        for (k in before) if (!now.contains(k)) setKey(k, false)
                        for (k in now) if (!before.contains(k)) setKey(k, true)
                        pointerDpad[id] = now
                    }
                }
                return pointerButton.isNotEmpty()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val i = ev.actionIndex
                val id = ev.getPointerId(i)
                val cancel = ev.actionMasked == MotionEvent.ACTION_CANCEL
                val ids = if (cancel) ArrayList(pointerButton.keys) else listOf(id)
                for (pid in ids) {
                    val bid = pointerButton.remove(pid) ?: continue
                    val b = buttons.firstOrNull { it.id == bid } ?: continue
                    when (b.type) {
                        Controls.TYPE_DPAD -> {
                            for (k in pointerDpad.remove(pid) ?: emptySet()) setKey(k, false)
                        }
                        Controls.TYPE_MENU -> {}
                        else -> if (b.key != 0) setKey(b.key, false)
                    }
                }
                return true
            }
        }
        return false
    }

    private fun editTouch(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val b = hit(ev.x, ev.y)
                selected = b
                onSelect?.invoke(b)
                if (b != null) {
                    dragDx = ev.x - b.x * width
                    dragDy = ev.y - b.y * height
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val b = selected
                if (b != null && width > 0 && height > 0) {
                    b.x = ((ev.x - dragDx) / width).coerceIn(0.03f, 0.97f)
                    b.y = ((ev.y - dragDy) / height).coerceIn(0.04f, 0.96f)
                    invalidate()
                    onEdited?.invoke()
                }
            }
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val alpha = (opacity * 255f).toInt().coerceIn(30, 255)
        for (b in buttons) {
            val cx = b.x * w
            val cy = b.y * h
            val r = radius(b)
            val isSel = editMode && b === selected
            when (b.type) {
                Controls.TYPE_DPAD -> drawDpad(c, cx, cy, r, alpha, isSel)
                Controls.TYPE_MENU -> drawMenu(c, cx, cy, r, alpha, isSel)
                else -> drawButton(c, b, cx, cy, r, alpha, isSel)
            }
        }
    }

    private fun drawButton(c: Canvas, b: ButtonSpec, cx: Float, cy: Float, r: Float, alpha: Int, sel: Boolean) {
        val pressed = b.key != 0 && down.contains(b.key)
        fill.color = if (pressed) C.MINT else C.SURFACE2
        fill.alpha = if (pressed) (alpha + 60).coerceAtMost(255) else alpha
        c.drawCircle(cx, cy, r, fill)
        stroke.color = if (sel) C.PEACH else C.TEXT
        stroke.alpha = if (sel) 255 else (alpha * 0.55f).toInt()
        stroke.strokeWidth = context.dpf(if (sel) 3f else 1.5f)
        c.drawCircle(cx, cy, r, stroke)
        label.color = if (pressed) C.ON_MINT else C.TEXT
        label.alpha = 255
        label.textSize = r * (if (b.label.length > 2) 0.52f else 0.8f)
        val fm = label.fontMetrics
        c.drawText(b.label.ifEmpty { Controls.labelForKey(b.key) }, cx, cy - (fm.ascent + fm.descent) / 2f, label)
    }

    private fun drawMenu(c: Canvas, cx: Float, cy: Float, r: Float, alpha: Int, sel: Boolean) {
        fill.color = C.SURFACE2
        fill.alpha = alpha
        c.drawCircle(cx, cy, r, fill)
        stroke.color = if (sel) C.PEACH else C.TEXT
        stroke.alpha = if (sel) 255 else (alpha * 0.55f).toInt()
        stroke.strokeWidth = context.dpf(if (sel) 3f else 1.5f)
        c.drawCircle(cx, cy, r, stroke)
        arrow.color = C.TEXT
        arrow.alpha = 255
        arrow.style = Paint.Style.STROKE
        arrow.strokeCap = Paint.Cap.ROUND
        arrow.strokeWidth = context.dpf(2f)
        val half = r * 0.42f
        for (i in -1..1) {
            val y = cy + i * r * 0.32f
            c.drawLine(cx - half, y, cx + half, y, arrow)
        }
    }

    private fun drawDpad(c: Canvas, cx: Float, cy: Float, r: Float, alpha: Int, sel: Boolean) {
        fill.color = C.SURFACE2
        fill.alpha = (alpha * 0.8f).toInt()
        c.drawCircle(cx, cy, r, fill)
        stroke.color = if (sel) C.PEACH else C.TEXT
        stroke.alpha = if (sel) 255 else (alpha * 0.45f).toInt()
        stroke.strokeWidth = context.dpf(if (sel) 3f else 1.5f)
        c.drawCircle(cx, cy, r, stroke)
        arrow.style = Paint.Style.FILL
        val keys = intArrayOf(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT)
        for (n in 0 until 4) {
            val pressed = down.contains(keys[n])
            arrow.color = if (pressed) C.MINT else C.TEXT
            arrow.alpha = if (pressed) 255 else (alpha * 0.75f).toInt()
            c.save()
            c.rotate(90f * n, cx, cy)
            tmpPath.reset()
            val tip = cy - r * 0.72f
            val base = cy - r * 0.34f
            val half = r * 0.2f
            tmpPath.moveTo(cx, tip)
            tmpPath.lineTo(cx + half, base)
            tmpPath.lineTo(cx - half, base)
            tmpPath.close()
            c.drawPath(tmpPath, arrow)
            c.restore()
        }
        arrow.color = C.TEXT
        arrow.alpha = (alpha * 0.5f).toInt()
        c.drawCircle(cx, cy, r * 0.14f, arrow)
    }
}
