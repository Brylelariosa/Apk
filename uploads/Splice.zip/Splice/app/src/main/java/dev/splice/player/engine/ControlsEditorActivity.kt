package dev.splice.player.engine

import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import dev.splice.player.R
import dev.splice.player.data.Library
import dev.splice.player.model.ButtonSpec
import dev.splice.player.model.Controls
import dev.splice.player.model.Profile
import dev.splice.player.ui.BTN_GHOST
import dev.splice.player.ui.BTN_PRIMARY
import dev.splice.player.ui.C
import dev.splice.player.ui.MATCH
import dev.splice.player.ui.SettingsCard
import dev.splice.player.ui.Sheet
import dev.splice.player.ui.TouchOverlayView
import dev.splice.player.ui.WRAP
import dev.splice.player.ui.add
import dev.splice.player.ui.button
import dev.splice.player.ui.dp
import dev.splice.player.ui.dpf
import dev.splice.player.ui.hbox
import dev.splice.player.ui.shape
import dev.splice.player.ui.text
import dev.splice.player.ui.toast
import dev.splice.player.ui.vbox

/** Full-screen editor: drag buttons, resize them, change keys, add or remove buttons. */
class ControlsEditorActivity : Activity() {
    companion object {
        const val EXTRA_GAME_ID = "splice.game_id"
        const val EXTRA_PORTRAIT = "splice.portrait"
    }

    private lateinit var profile: Profile
    private lateinit var gameId: String
    private var portrait = false
    private lateinit var list: MutableList<ButtonSpec>
    private lateinit var overlay: TouchOverlayView
    private lateinit var info: TextView
    private lateinit var sizeBar: SeekBar
    private lateinit var sizeLabel: TextView

    private class GuideView(ctx: android.content.Context, private val portrait: Boolean) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        init {
            p.style = Paint.Style.STROKE
            p.color = 0x55FFFFFF
            p.strokeWidth = ctx.dpf(1.5f)
            p.pathEffect = DashPathEffect(floatArrayOf(ctx.dpf(8f), ctx.dpf(6f)), 0f)
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val r = if (portrait) {
                RectF(0f, 0f, w, w * 3f / 4f)
            } else {
                val gw = h * 4f / 3f
                RectF((w - gw) / 2f, 0f, (w + gw) / 2f, h)
            }
            c.drawRoundRect(r, 12f, 12f, p)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gameId = intent.getStringExtra(EXTRA_GAME_ID) ?: run { finish(); return }
        portrait = intent.getBooleanExtra(EXTRA_PORTRAIT, false)
        profile = Library.profile(gameId)
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        list = Controls.layoutFor(profile, portrait)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        root.addView(GuideView(this, portrait), FrameLayout.LayoutParams(MATCH, MATCH))

        overlay = TouchOverlayView(this)
        overlay.editMode = true
        overlay.opacity = profile.controlsOpacity / 100f
        overlay.scale = profile.controlsScale / 100f
        overlay.buttons = list
        overlay.onSelect = { b -> refreshSelection(b) }
        root.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))

        root.addView(buildPanel(), FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))
        setContentView(root)
        refreshSelection(null)
    }

    private fun buildPanel(): View {
        val card = vbox()
        card.background = shape(0xEE1C1A29.toInt(), 18f, C.OUTLINE, 1f)
        card.setPadding(dp(14), dp(10), dp(14), dp(10))
        val lp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
        lp.setMargins(dp(12), dp(12), dp(12), dp(12))

        info = text("Tap a button to select it, drag to move.", 12.5f, C.DIM)
        card.addView(info)

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = hbox()
        hs.addView(row, FrameLayout.LayoutParams(WRAP, WRAP))

        val sizeCol = vbox()
        sizeLabel = text("Size", 12f, C.DIM, 1)
        sizeCol.addView(sizeLabel)
        sizeBar = SeekBar(this)
        sizeBar.max = 200
        sizeBar.progressTintList = android.content.res.ColorStateList.valueOf(C.MINT)
        sizeBar.thumbTintList = android.content.res.ColorStateList.valueOf(C.MINT)
        sizeBar.progressBackgroundTintList = android.content.res.ColorStateList.valueOf(C.OUTLINE)
        sizeBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                overlay.selected?.let {
                    it.size = (30 + p).toFloat()
                    overlay.invalidate()
                    sizeLabel.text = "Size ${30 + p} dp"
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        sizeCol.add(sizeBar, dp(170), WRAP)
        row.add(sizeCol, WRAP, WRAP, 0f, 0, 0, 10, 0)

        row.add(button("Key", 0, BTN_GHOST) { pickKey() }, WRAP, WRAP, 0f, 0, 0, 8, 0)
        row.add(button("Add", R.drawable.ic_add, BTN_GHOST) { addButton() }, WRAP, WRAP, 0f, 0, 0, 8, 0)
        row.add(button("Remove", R.drawable.ic_trash, BTN_GHOST) { removeSelected() }, WRAP, WRAP, 0f, 0, 0, 8, 0)
        row.add(button("Look", R.drawable.ic_eye_off, BTN_GHOST) { lookSheet() }, WRAP, WRAP, 0f, 0, 0, 8, 0)
        row.add(button("Reset", R.drawable.ic_refresh, BTN_GHOST) { reset() }, WRAP, WRAP, 0f, 0, 0, 8, 0)
        row.add(button("Save", R.drawable.ic_check, BTN_PRIMARY) { save() }, WRAP, WRAP, 0f, 0, 0, 0, 0)
        card.add(hs, MATCH, WRAP, 0f, 0, 8, 0, 0)

        val wrapper = FrameLayout(this)
        wrapper.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
        wrapper.layoutParams = lp
        return wrapper
    }

    private fun refreshSelection(b: ButtonSpec?) {
        if (b == null) {
            info.text = "Tap a button to select it, drag to move."
            sizeBar.isEnabled = false
            sizeLabel.text = "Size"
            return
        }
        val kind = when (b.type) {
            Controls.TYPE_DPAD -> "D-pad"
            Controls.TYPE_MENU -> "Menu"
            else -> "Button " + b.label.ifEmpty { Controls.labelForKey(b.key) } + " -> " + Controls.labelForKey(b.key)
        }
        info.text = "$kind selected. Drag it to move."
        sizeBar.isEnabled = true
        sizeBar.progress = (b.size - 30f).toInt().coerceIn(0, 200)
        sizeLabel.text = "Size ${b.size.toInt()} dp"
    }

    private fun pickKey() {
        val b = overlay.selected
        if (b == null || b.type != Controls.TYPE_BUTTON) {
            toast("Select a round button first")
            return
        }
        val s = Sheet(this, "Key for this button", "Sent to the game when pressed")
        for (k in Controls.keyChoices) {
            s.action(k.label, R.drawable.ic_gamepad) {
                b.key = k.keyCode
                if (b.label.length <= 2 || Controls.keyChoices.any { it.label == b.label }) b.label = k.label
                overlay.invalidate()
                refreshSelection(b)
            }
        }
        s.show()
    }

    private fun addButton() {
        val s = Sheet(this, "Add a button", "Choose which key it presses")
        for (k in Controls.keyChoices) {
            s.action(k.label, R.drawable.ic_add) {
                val b = ButtonSpec("k" + System.currentTimeMillis(), Controls.TYPE_BUTTON, k.keyCode, k.label, 0.5f, 0.5f, 56f)
                list.add(b)
                overlay.buttons = list
                overlay.selected = b
                refreshSelection(b)
            }
        }
        s.show()
    }

    private fun removeSelected() {
        val b = overlay.selected
        if (b == null || b.type != Controls.TYPE_BUTTON) {
            toast("Only extra round buttons can be removed")
            return
        }
        list.remove(b)
        overlay.buttons = list
        overlay.selected = null
        refreshSelection(null)
    }

    private fun lookSheet() {
        val s = Sheet(this, "Appearance")
        val card = SettingsCard(this)
        card.slider("Opacity", 20, 100, 5, profile.controlsOpacity, { "$it%" }) {
            profile.controlsOpacity = it
            overlay.opacity = it / 100f
        }
        card.slider("Button scale", 60, 160, 5, profile.controlsScale, { "$it%" }) {
            profile.controlsScale = it
            overlay.scale = it / 100f
        }
        card.toggle("Haptic feedback", "Short vibration when a button is pressed", profile.haptics) { profile.haptics = it }
        s.add(card.view)
        s.show()
    }

    private fun reset() {
        list = Controls.defaults(portrait)
        overlay.buttons = list
        overlay.selected = null
        refreshSelection(null)
    }

    private fun save() {
        val text = Controls.serialize(list)
        if (portrait) profile.layoutPort = text else profile.layoutLand = text
        Library.saveProfile(gameId, profile)
        toast("Layout saved")
        finish()
    }
}
