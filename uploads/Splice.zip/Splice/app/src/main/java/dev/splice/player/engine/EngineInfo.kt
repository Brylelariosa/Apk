package dev.splice.player.engine

import android.content.Context
import android.os.Build
import android.webkit.WebView

/** What this build of the app can run. The RGSS engine is optional (built by tools/engine). */
object EngineInfo {
    const val RGSS_ACTIVITY = "dev.splice.player.engine.SpliceRgssActivity"

    fun rgssClassPresent(): Boolean = try {
        Class.forName(RGSS_ACTIVITY)
        true
    } catch (t: Throwable) {
        false
    }

    /** The bundled mkxp-z build only ships arm64-v8a. */
    fun deviceSupportsRgss(): Boolean = Build.SUPPORTED_ABIS.contains("arm64-v8a")

    fun rgssReady(): Boolean = rgssClassPresent() && deviceSupportsRgss()

    /** Human readable reason why RGSS games cannot start, or null if they can. */
    fun rgssProblem(ctx: Context): String? {
        if (!rgssClassPresent()) {
            return "RPG Maker XP / VX / VX Ace games need the RGSS engine (mkxp-z), and this build doesn't include it.\n" + statusText(ctx)
        }
        if (!deviceSupportsRgss()) return "The RGSS engine is only built for 64-bit ARM (arm64-v8a); this device is ${Build.SUPPORTED_ABIS.firstOrNull()}."
        return null
    }

    /** Text written by tools/engine/prepare_engine.sh at build time. */
    fun statusText(ctx: Context): String {
        return try {
            ctx.assets.open("engine_status.txt").bufferedReader().use { it.readText().trim() }
        } catch (t: Throwable) {
            "No engine build information (engine step was not run)."
        }
    }

    fun webViewVersion(ctx: Context): String? {
        return try {
            if (Build.VERSION.SDK_INT >= 26) {
                val pkg = WebView.getCurrentWebViewPackage()
                if (pkg != null) pkg.packageName + " " + pkg.versionName else null
            } else {
                null
            }
        } catch (t: Throwable) {
            null
        }
    }

    /** Major Chromium version of the system WebView, or 0 if unknown. */
    fun webViewMajor(ctx: Context): Int {
        val v = webViewVersion(ctx) ?: return 0
        val m = Regex("(\\d+)\\.").find(v.substringAfter(' '))
        return m?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }
}
