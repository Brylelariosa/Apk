package dev.splice.player.model

import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

/**
 * One on-screen control. x/y are the button centre as a fraction of the screen,
 * size is the diameter in dp (before the profile's global scale).
 */
class ButtonSpec(
    var id: String,
    var type: String,      // "dpad" | "button" | "menu"
    var key: Int,          // android KeyEvent.KEYCODE_*
    var label: String,
    var x: Float,
    var y: Float,
    var size: Float
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("type", type).put("key", key).put("label", label)
        .put("x", x.toDouble()).put("y", y.toDouble()).put("size", size.toDouble())
}

class KeyChoice(val label: String, val keyCode: Int)

object Controls {
    const val TYPE_DPAD = "dpad"
    const val TYPE_BUTTON = "button"
    const val TYPE_MENU = "menu"

    /** Keys a button can emit. RPG Maker defaults: Enter/Z/Space = OK, X/Esc = cancel, Shift = dash. */
    val keyChoices: List<KeyChoice> = listOf(
        KeyChoice("Enter", KeyEvent.KEYCODE_ENTER),
        KeyChoice("Z", KeyEvent.KEYCODE_Z),
        KeyChoice("X", KeyEvent.KEYCODE_X),
        KeyChoice("C", KeyEvent.KEYCODE_C),
        KeyChoice("Shift", KeyEvent.KEYCODE_SHIFT_LEFT),
        KeyChoice("Esc", KeyEvent.KEYCODE_ESCAPE),
        KeyChoice("Space", KeyEvent.KEYCODE_SPACE),
        KeyChoice("A", KeyEvent.KEYCODE_A),
        KeyChoice("S", KeyEvent.KEYCODE_S),
        KeyChoice("D", KeyEvent.KEYCODE_D),
        KeyChoice("Q", KeyEvent.KEYCODE_Q),
        KeyChoice("W", KeyEvent.KEYCODE_W),
        KeyChoice("PgUp", KeyEvent.KEYCODE_PAGE_UP),
        KeyChoice("PgDn", KeyEvent.KEYCODE_PAGE_DOWN),
        KeyChoice("Tab", KeyEvent.KEYCODE_TAB),
        KeyChoice("F12", KeyEvent.KEYCODE_F12)
    )

    fun labelForKey(key: Int): String = keyChoices.firstOrNull { it.keyCode == key }?.label ?: "?"

    fun defaults(portrait: Boolean): MutableList<ButtonSpec> {
        return if (portrait) {
            mutableListOf(
                ButtonSpec("dpad", TYPE_DPAD, 0, "", 0.24f, 0.84f, 150f),
                ButtonSpec("a", TYPE_BUTTON, KeyEvent.KEYCODE_ENTER, "A", 0.87f, 0.80f, 68f),
                ButtonSpec("b", TYPE_BUTTON, KeyEvent.KEYCODE_X, "B", 0.70f, 0.90f, 62f),
                ButtonSpec("run", TYPE_BUTTON, KeyEvent.KEYCODE_SHIFT_LEFT, "Run", 0.72f, 0.73f, 54f),
                ButtonSpec("menu", TYPE_MENU, KeyEvent.KEYCODE_ESCAPE, "", 0.92f, 0.05f, 40f)
            )
        } else {
            mutableListOf(
                ButtonSpec("dpad", TYPE_DPAD, 0, "", 0.14f, 0.68f, 150f),
                ButtonSpec("a", TYPE_BUTTON, KeyEvent.KEYCODE_ENTER, "A", 0.91f, 0.70f, 68f),
                ButtonSpec("b", TYPE_BUTTON, KeyEvent.KEYCODE_X, "B", 0.82f, 0.84f, 62f),
                ButtonSpec("run", TYPE_BUTTON, KeyEvent.KEYCODE_SHIFT_LEFT, "Run", 0.82f, 0.58f, 54f),
                ButtonSpec("menu", TYPE_MENU, KeyEvent.KEYCODE_ESCAPE, "", 0.94f, 0.10f, 40f)
            )
        }
    }

    fun parse(text: String, portrait: Boolean): MutableList<ButtonSpec> {
        if (text.isBlank()) return defaults(portrait)
        return try {
            val arr = JSONArray(text)
            val out = ArrayList<ButtonSpec>()
            for (n in 0 until arr.length()) {
                val o = arr.getJSONObject(n)
                out.add(
                    ButtonSpec(
                        o.getString("id"), o.getString("type"), o.optInt("key", 0), o.optString("label", ""),
                        o.optDouble("x", 0.5).toFloat(), o.optDouble("y", 0.5).toFloat(), o.optDouble("size", 60.0).toFloat()
                    )
                )
            }
            if (out.isEmpty()) defaults(portrait) else out
        } catch (t: Throwable) {
            defaults(portrait)
        }
    }

    fun serialize(list: List<ButtonSpec>): String {
        val arr = JSONArray()
        for (b in list) arr.put(b.toJson())
        return arr.toString()
    }

    fun layoutFor(p: Profile, portrait: Boolean): MutableList<ButtonSpec> =
        parse(if (portrait) p.layoutPort else p.layoutLand, portrait)
}
