package dev.splice.player.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Minimal .ico reader (PNG-in-ICO and 8/24/32-bit DIB frames); picks the largest image. */
object IcoDecoder {
    fun decode(bytes: ByteArray): Bitmap? {
        return try {
            val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            if (bytes.size < 22 || bb.getShort(0).toInt() != 0 || bb.getShort(2).toInt() != 1) return null
            val count = bb.getShort(4).toInt() and 0xFFFF
            var best = -1
            var bestArea = -1
            for (i in 0 until count) {
                val o = 6 + i * 16
                if (o + 16 > bytes.size) break
                var w = bb.get(o).toInt() and 0xFF
                var h = bb.get(o + 1).toInt() and 0xFF
                if (w == 0) w = 256
                if (h == 0) h = 256
                if (w * h > bestArea) {
                    bestArea = w * h
                    best = i
                }
            }
            if (best < 0) return null
            val o = 6 + best * 16
            val size = bb.getInt(o + 8)
            val off = bb.getInt(o + 12)
            if (off < 0 || size <= 0 || off + size > bytes.size) return null
            if ((bytes[off].toInt() and 0xFF) == 0x89 && bytes[off + 1].toInt() == 0x50) {
                BitmapFactory.decodeByteArray(bytes, off, size)
            } else {
                decodeDib(bb, off, size)
            }
        } catch (t: Throwable) {
            null
        }
    }

    private fun decodeDib(bb: ByteBuffer, off: Int, size: Int): Bitmap? {
        val headerSize = bb.getInt(off)
        val w = bb.getInt(off + 4)
        val hTotal = bb.getInt(off + 8)
        val bpp = bb.getShort(off + 14).toInt() and 0xFFFF
        val compression = bb.getInt(off + 16)
        if (compression != 0 || w <= 0 || w > 1024) return null
        val h = hTotal / 2
        if (h <= 0 || h > 1024) return null
        var colors = bb.getInt(off + 32)
        if (bpp <= 8 && colors == 0) colors = 1 shl bpp
        if (bpp > 8) colors = 0
        val palOff = off + headerSize
        val pixOff = palOff + colors * 4
        val rowBytes = ((w * bpp + 31) / 32) * 4
        val maskRow = ((w + 31) / 32) * 4
        val maskOff = pixOff + rowBytes * h
        val px = IntArray(w * h)
        var anyAlpha = false
        for (y in 0 until h) {
            val srcY = h - 1 - y
            val rowStart = pixOff + srcY * rowBytes
            for (x in 0 until w) {
                var argb: Int
                when (bpp) {
                    32 -> {
                        val p = rowStart + x * 4
                        val b = bb.get(p).toInt() and 0xFF
                        val g = bb.get(p + 1).toInt() and 0xFF
                        val r = bb.get(p + 2).toInt() and 0xFF
                        val a = bb.get(p + 3).toInt() and 0xFF
                        if (a != 0) anyAlpha = true
                        argb = (a shl 24) or (r shl 16) or (g shl 8) or b
                    }
                    24 -> {
                        val p = rowStart + x * 3
                        val b = bb.get(p).toInt() and 0xFF
                        val g = bb.get(p + 1).toInt() and 0xFF
                        val r = bb.get(p + 2).toInt() and 0xFF
                        argb = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                    8 -> {
                        val idx = bb.get(rowStart + x).toInt() and 0xFF
                        val p = palOff + idx * 4
                        val b = bb.get(p).toInt() and 0xFF
                        val g = bb.get(p + 1).toInt() and 0xFF
                        val r = bb.get(p + 2).toInt() and 0xFF
                        argb = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                    else -> return null
                }
                // AND mask (1 = transparent)
                val mByte = bb.get(maskOff + srcY * maskRow + (x shr 3)).toInt() and 0xFF
                if (((mByte shr (7 - (x and 7))) and 1) == 1 && bpp != 32) argb = argb and 0x00FFFFFF
                px[y * w + x] = argb
            }
        }
        if (bpp == 32 && !anyAlpha) {
            for (i in px.indices) px[i] = px[i] or (0xFF shl 24)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }
}
