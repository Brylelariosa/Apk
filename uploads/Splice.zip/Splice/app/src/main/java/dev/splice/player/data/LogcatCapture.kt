package dev.splice.player.data

import dev.splice.player.core.AppLog
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * The mkxp-z/SDL engine (and Android itself, for crashes and kills) report most failures to logcat,
 * not to stdout. This copies the lines written by the game process into its session log, so a log
 * pasted from Splice contains the real reason without needing adb.
 */
object LogcatCapture {
    private val LINE = Regex("^(\\d\\d-\\d\\d \\d\\d:\\d\\d:\\d\\d\\.\\d+)\\s+(\\d+)\\s+\\d+\\s+([VDIWEF])\\s")

    /** Appends every logcat line written since [sinceMs] by a process other than this one. Returns the line count, or -1. */
    fun appendTo(logFile: File, sinceMs: Long): Int {
        return try {
            val since = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US).format(Date(sinceMs - 2000L))
            val me = android.os.Process.myPid()
            val proc = ProcessBuilder("logcat", "-d", "-v", "threadtime", "-t", "8000").redirectErrorStream(true).start()
            val kept = ArrayDeque<String>()
            proc.inputStream.bufferedReader().use { r ->
                while (true) {
                    val line = r.readLine() ?: break
                    val m = LINE.find(line) ?: continue
                    if (m.groupValues[2].toIntOrNull() == me) continue
                    if (m.groupValues[1] < since) continue
                    kept.addLast(line)
                    if (kept.size > 500) kept.removeFirst()
                }
            }
            proc.destroy()
            val sb = StringBuilder()
            sb.append("\n--- logcat from the game process (since the session started) ---\n")
            if (kept.isEmpty()) sb.append("(nothing: Android kept no log lines from the game process)\n")
            for (l in kept) sb.append(l).append('\n')
            sb.append("--- end of logcat ---\n")
            logFile.appendText(sb.toString())
            kept.size
        } catch (t: Throwable) {
            AppLog.w("logcat", "could not read logcat: ${t.message}")
            -1
        }
    }
}
