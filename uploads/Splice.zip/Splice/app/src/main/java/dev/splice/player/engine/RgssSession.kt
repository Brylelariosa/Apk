package dev.splice.player.engine

import android.app.Activity
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.SystemClock
import android.view.InputDevice
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import dev.splice.player.R
import dev.splice.player.core.AppLog
import dev.splice.player.core.Native
import dev.splice.player.data.Library
import dev.splice.player.data.SaveVault
import dev.splice.player.data.SessionTracker
import dev.splice.player.model.Controls
import dev.splice.player.model.Profile
import dev.splice.player.ui.C
import dev.splice.player.ui.MATCH
import dev.splice.player.ui.Sheet
import dev.splice.player.ui.TouchOverlayView
import dev.splice.player.ui.text
import dev.splice.player.ui.toast

/**
 * Everything the generated SpliceRgssActivity (which extends the mkxp-z/SDL activity) delegates to:
 * log capture, crash handler, window flags, the touch overlay and the pause menu.
 */
class RgssSession private constructor(private val gameId: String, private val profile: Profile) {
    private var overlay: TouchOverlayView? = null
    private var controlsOn = true

    companion object {
        @JvmStatic
        fun begin(a: Activity, intent: android.content.Intent): RgssSession {
            val id = intent.getStringExtra(RgssLauncher.EXTRA_GAME_ID) ?: ""
            val logPath = intent.getStringExtra(RgssLauncher.EXTRA_LOG) ?: ""
            Library.load()
            val p = Library.profile(id)
            if (logPath.isNotEmpty()) {
                Native.redirectStdio(logPath)
                Native.installCrashHandler(logPath)
            }
            a.requestedOrientation = when (p.orientation) {
                1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                else -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
            }
            if (p.keepAwake) a.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (Build.VERSION.SDK_INT >= 28) {
                val lp = a.window.attributes
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                a.window.attributes = lp
            }
            SessionTracker.attach()
            AppLog.i("rgss", "session begin game=$id")
            return RgssSession(id, p)
        }
    }

    private fun isPortrait(a: Activity) = a.resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT

    fun attachOverlay(a: Activity) {
        try {
            val content = a.findViewById<ViewGroup>(android.R.id.content) ?: return
            val ov = TouchOverlayView(a)
            ov.opacity = profile.controlsOpacity / 100f
            ov.scale = profile.controlsScale / 100f
            ov.haptics = profile.haptics
            ov.onKey = { code, down -> sendKey(a, code, down) }
            ov.onMenu = { showMenu(a) }
            content.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
            overlay = ov
            controlsOn = profile.controlsVisible
            applyLayout(a)
        } catch (t: Throwable) {
            AppLog.e("rgss", "overlay failed", t)
        }
    }

    private fun applyLayout(a: Activity) {
        val ov = overlay ?: return
        val all = Controls.layoutFor(profile, isPortrait(a))
        ov.buttons = if (controlsOn) all else all.filter { it.type == Controls.TYPE_MENU }
        if (!controlsOn) ov.releaseAll()
    }

    fun onConfigChanged(a: Activity) {
        applyLayout(a)
    }

    private fun sendKey(a: Activity, code: Int, down: Boolean) {
        val now = SystemClock.uptimeMillis()
        a.dispatchKeyEvent(KeyEvent(now, now, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0))
    }

    /** Hide the touch controls while a physical controller is being used. */
    fun onKeyEvent(e: KeyEvent) {
        if (!profile.controlsAutoHide) return
        val src = e.source
        if ((src and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD && e.deviceId >= 0) overlay?.faded = true
    }

    fun onBack(a: Activity): Boolean {
        showMenu(a)
        return true
    }

    private fun showMenu(a: Activity) {
        val g = Library.get(gameId)
        val s = Sheet(a, g?.title ?: "Game", "Paused menu")
        s.action("Resume", R.drawable.ic_play) {}
        s.action(if (controlsOn) "Hide touch controls" else "Show touch controls", R.drawable.ic_gamepad) {
            controlsOn = !controlsOn
            applyLayout(a)
        }
        s.action("Soft reset (F12)", R.drawable.ic_refresh) {
            sendKey(a, KeyEvent.KEYCODE_F12, true)
            sendKey(a, KeyEvent.KEYCODE_F12, false)
        }
        if (g != null) {
            s.action("Back up saves now", R.drawable.ic_saves) {
                val f = SaveVault.backup(g, "manual")
                a.toast(if (f != null) "Backup created" else "No saves to back up yet")
            }
        }
        s.action("Exit game", R.drawable.ic_close, true) { a.finish() }
        s.show()
    }

    fun end(@Suppress("UNUSED_PARAMETER") a: Activity) {
        overlay?.releaseAll()
        SessionTracker.end()
        AppLog.i("rgss", "session end game=$gameId")
    }
}
