package dev.splice.player.model

import org.json.JSONObject

/**
 * Per-game settings, stored as JSON so new options never need a migration.
 * New games start from the user's default profile (Settings > Default profile).
 */
class Profile(val json: JSONObject = JSONObject()) {
    private fun i(k: String, d: Int) = json.optInt(k, d)
    private fun b(k: String, d: Boolean) = json.optBoolean(k, d)
    private fun s(k: String, d: String) = json.optString(k, d)

    // ---- display ----
    /** 0 auto, 1 landscape, 2 portrait */
    var orientation: Int
        get() = i("orientation", 0)
        set(v) { json.put("orientation", v) }

    /** RGSS: 0 fit (keep aspect), 1 stretch, 2 integer (pixel-perfect) */
    var scaleMode: Int
        get() = i("scaleMode", 0)
        set(v) { json.put("scaleMode", v) }

    /** RGSS: linear filtering when scaling. Web: false = crisp/pixelated canvas. */
    var smooth: Boolean
        get() = b("smooth", true)
        set(v) { json.put("smooth", v) }

    var keepAwake: Boolean
        get() = b("keepAwake", true)
        set(v) { json.put("keepAwake", v) }

    // ---- performance ----
    /** Game speed in percent (100 = normal). RGSS: scales the frame rate; MV/MZ: scales the update step. */
    var speed: Int
        get() = i("speed", 100)
        set(v) { json.put("speed", v) }

    /** Web only: render cap in fps, 0 = display rate */
    var fpsCap: Int
        get() = i("fpsCap", 0)
        set(v) { json.put("fpsCap", v) }

    /** RGSS: skip frames when the game runs slow */
    var frameSkip: Boolean
        get() = b("frameSkip", true)
        set(v) { json.put("frameSkip", v) }

    /** RGSS: 0 balanced, 1 vsync, 2 match display refresh rate */
    var pacing: Int
        get() = i("pacing", 0)
        set(v) { json.put("pacing", v) }

    /** Web: on-screen FPS counter. RGSS: print FPS to the session log. */
    var showFps: Boolean
        get() = b("showFps", false)
        set(v) { json.put("showFps", v) }

    /** RGSS: cap texture size (0 = hardware limit) */
    var maxTexture: Int
        get() = i("maxTexture", 0)
        set(v) { json.put("maxTexture", v) }

    // ---- controls ----
    var controlsVisible: Boolean
        get() = b("controlsVisible", true)
        set(v) { json.put("controlsVisible", v) }

    var controlsOpacity: Int
        get() = i("controlsOpacity", 60)
        set(v) { json.put("controlsOpacity", v) }

    var controlsScale: Int
        get() = i("controlsScale", 100)
        set(v) { json.put("controlsScale", v) }

    var controlsAutoHide: Boolean
        get() = b("controlsAutoHide", true)
        set(v) { json.put("controlsAutoHide", v) }

    var haptics: Boolean
        get() = b("haptics", true)
        set(v) { json.put("haptics", v) }

    var layoutLand: String
        get() = s("layoutLand", "")
        set(v) { json.put("layoutLand", v) }

    var layoutPort: String
        get() = s("layoutPort", "")
        set(v) { json.put("layoutPort", v) }

    // ---- audio (RGSS) ----
    var seSources: Int
        get() = i("seSources", 6)
        set(v) { json.put("seSources", v) }

    var midiFont: String
        get() = s("midiFont", "")
        set(v) { json.put("midiFont", v) }

    var midiReverb: Boolean
        get() = b("midiReverb", false)
        set(v) { json.put("midiReverb", v) }

    var midiChorus: Boolean
        get() = b("midiChorus", false)
        set(v) { json.put("midiChorus", v) }

    // ---- compatibility (RGSS / mkxp-z) ----
    /** 0 auto-detect, 1..3 force RGSS version */
    var rgssOverride: Int
        get() = i("rgssOverride", 0)
        set(v) { json.put("rgssOverride", v) }

    var subImageFix: Boolean
        get() = b("subImageFix", false)
        set(v) { json.put("subImageFix", v) }

    var blit: Boolean
        get() = b("blit", true)
        set(v) { json.put("blit", v) }

    var solidFonts: Boolean
        get() = b("solidFonts", false)
        set(v) { json.put("solidFonts", v) }

    var pathCache: Boolean
        get() = b("pathCache", true)
        set(v) { json.put("pathCache", v) }

    var scriptNames: Boolean
        get() = b("scriptNames", true)
        set(v) { json.put("scriptNames", v) }

    /** Keep this game's saves in Splice's save vault (per-game folder). */
    var redirectSaves: Boolean
        get() = b("redirectSaves", true)
        set(v) { json.put("redirectSaves", v) }

    var defW: Int
        get() = i("defW", 0)
        set(v) { json.put("defW", v) }

    var defH: Int
        get() = i("defH", 0)
        set(v) { json.put("defH", v) }

    /** Extra RTP folders, one absolute path per line */
    var rtpExtra: String
        get() = s("rtpExtra", "")
        set(v) { json.put("rtpExtra", v) }

    /** Raw JSON object merged into the generated mkxp.json (advanced) */
    var customJson: String
        get() = s("customJson", "")
        set(v) { json.put("customJson", v) }

    // ---- compatibility (MV / MZ) ----
    var forceCanvas: Boolean
        get() = b("forceCanvas", false)
        set(v) { json.put("forceCanvas", v) }

    var disableTouch: Boolean
        get() = b("disableTouch", false)
        set(v) { json.put("disableTouch", v) }

    var customJs: String
        get() = s("customJs", "")
        set(v) { json.put("customJs", v) }

    fun copy(): Profile = Profile(JSONObject(json.toString()))

    override fun toString(): String = json.toString()

    companion object {
        fun parse(text: String?): Profile {
            if (text.isNullOrBlank()) return Profile()
            return try {
                Profile(JSONObject(text))
            } catch (t: Throwable) {
                Profile()
            }
        }
    }
}
