package dev.splice.player.data

import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.Charset
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ImportCancelled : Exception("cancelled")

object Zip {
    private class CountingStream(input: InputStream, val onBytes: (Long) -> Unit) : FilterInputStream(input) {
        private var total = 0L
        override fun read(): Int {
            val r = super.read()
            if (r >= 0) {
                total++
                onBytes(total)
            }
            return r
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = super.read(b, off, len)
            if (r > 0) {
                total += r
                onBytes(total)
            }
            return r
        }
    }

    /** Resolves [name] inside [dest]; null if it would escape the folder (zip-slip). */
    fun safeChild(dest: File, name: String): File? {
        var n = name.replace('\\', '/')
        while (n.startsWith("/")) n = n.substring(1)
        if (n.isEmpty()) return null
        for (seg in n.split('/')) if (seg == "..") return null
        val f = File(dest, n)
        val destPath = dest.canonicalPath
        val fPath = f.canonicalPath
        return if (fPath == destPath || fPath.startsWith(destPath + File.separator)) f else null
    }

    /**
     * Extracts a ZIP stream into [dest]. [open] is called again with a fallback charset if the
     * archive uses legacy (non-UTF-8) file names.
     */
    fun extract(
        open: () -> InputStream?,
        dest: File,
        cancel: AtomicBoolean,
        onProgress: (compressedBytes: Long, name: String) -> Unit
    ): Int {
        var charset: Charset = Charsets.UTF_8
        for (attempt in 0..1) {
            try {
                val raw = open() ?: throw IllegalStateException("Cannot open archive")
                var count = 0
                raw.use { r ->
                    ZipInputStream(CountingStream(r.buffered(256 * 1024)) { onProgress(it, "") }, charset).use { zin ->
                        val buf = ByteArray(128 * 1024)
                        var e: ZipEntry? = zin.nextEntry
                        while (e != null) {
                            if (cancel.get()) throw ImportCancelled()
                            val target = safeChild(dest, e.name)
                            if (target != null) {
                                if (e.isDirectory) {
                                    target.mkdirs()
                                } else {
                                    target.parentFile?.mkdirs()
                                    target.outputStream().use { out ->
                                        while (true) {
                                            val n = zin.read(buf)
                                            if (n < 0) break
                                            out.write(buf, 0, n)
                                        }
                                    }
                                    count++
                                    onProgress(-1, e.name)
                                }
                            }
                            zin.closeEntry()
                            e = zin.nextEntry
                        }
                    }
                }
                return count
            } catch (iae: IllegalArgumentException) {
                // MALFORMED file name encoding: retry once as Latin-1
                if (attempt == 0) {
                    charset = Charsets.ISO_8859_1
                    dest.listFiles()?.forEach { dev.splice.player.core.Files.deleteRecursive(it) }
                } else {
                    throw iae
                }
            }
        }
        return 0
    }

    /** Writes [entries] (file, entry name) into a ZIP. */
    fun write(out: OutputStream, entries: List<Pair<File, String>>) {
        ZipOutputStream(out.buffered(128 * 1024)).use { zo ->
            zo.setLevel(6)
            for ((f, name) in entries) {
                if (!f.isFile) continue
                val ze = ZipEntry(name.replace('\\', '/'))
                ze.time = f.lastModified()
                zo.putNextEntry(ze)
                f.inputStream().use { it.copyTo(zo, 64 * 1024) }
                zo.closeEntry()
            }
        }
    }

    /** Lists a directory tree as (file, relative name) pairs. */
    fun listTree(base: File, prefix: String = ""): List<Pair<File, String>> {
        val out = ArrayList<Pair<File, String>>()
        fun walk(dir: File, rel: String) {
            val kids = dir.listFiles() ?: return
            for (k in kids) {
                val r = if (rel.isEmpty()) k.name else rel + "/" + k.name
                if (k.isDirectory) walk(k, r) else out.add(Pair(k, prefix + r))
            }
        }
        walk(base, "")
        return out
    }
}
