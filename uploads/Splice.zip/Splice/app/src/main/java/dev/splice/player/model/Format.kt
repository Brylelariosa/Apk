package dev.splice.player.model

enum class EngineKind { RGSS, WEB }

enum class Format(
    val id: String,
    val label: String,
    val badge: String,
    val engine: EngineKind,
    val rgssVersion: Int,
    val baseFps: Int
) {
    XP("xp", "RPG Maker XP", "XP", EngineKind.RGSS, 1, 40),
    VX("vx", "RPG Maker VX", "VX", EngineKind.RGSS, 2, 60),
    ACE("vxa", "RPG Maker VX Ace", "VXA", EngineKind.RGSS, 3, 60),
    MV("mv", "RPG Maker MV", "MV", EngineKind.WEB, 0, 60),
    MZ("mz", "RPG Maker MZ", "MZ", EngineKind.WEB, 0, 60);

    val isRgss: Boolean get() = engine == EngineKind.RGSS

    companion object {
        fun fromId(id: String?): Format? = values().firstOrNull { it.id == id }
    }
}
