package dev.splice.player.data

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.util.LruCache
import dev.splice.player.core.AppLog
import dev.splice.player.core.Bg
import dev.splice.player.core.Paths
import dev.splice.player.model.Game
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/** Finds, builds and caches cover art. Every game gets a cover: real art if found, otherwise a generated one. */
object CoverStore {
    private const val CW = 480
    private const val CH = 640
    private val IMG = setOf("png", "jpg", "jpeg", "webp", "bmp", "gif", "ico")

    private val cache = object : LruCache<String, Bitmap>(20 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private val PALETTES = arrayOf(
        intArrayOf(0xFF3B2F6B.toInt(), 0xFF1F8F8A.toInt()),
        intArrayOf(0xFF5B2A63.toInt(), 0xFFC8645A.toInt()),
        intArrayOf(0xFF1E3A5F.toInt(), 0xFF3DB4A5.toInt()),
        intArrayOf(0xFF4A2D55.toInt(), 0xFFE79A7E.toInt()),
        intArrayOf(0xFF2B3A67.toInt(), 0xFF8F5FD0.toInt()),
        intArrayOf(0xFF1D4E4B.toInt(), 0xFFE0B25A.toInt())
    )

    private fun isImage(f: File) = f.isFile && IMG.contains(f.extension.lowercase(Locale.ROOT))

    private fun candidates(game: Game): List<File> {
        val out = ArrayList<File>()
        game.coverPath?.let { File(it) }?.takeIf { it.exists() }?.let { out.add(it) }
        val root = game.dir
        val web = game.webRoot?.let { File(it) }
        if (web != null) {
            Detector.childPath(web, "icon", "icon.png")?.let { out.add(it) }
            Detector.childPath(web, "img", "titles1")?.listFiles()?.filter { isImage(it) }
                ?.minByOrNull { it.name }?.let { out.add(it) }
            Detector.childPath(web, "icon", "icon.ico")?.let { out.add(it) }
        } else {
            val titles = Detector.childPath(root, "Graphics", "Titles")?.listFiles()?.filter { isImage(it) }?.sortedBy { it.name }
            if (titles != null && titles.isNotEmpty()) {
                val pick = titles.firstOrNull { n ->
                    val l = n.name.lowercase(Locale.ROOT)
                    l.contains("logo") || l.contains("cover") || l.contains("title")
                } ?: titles.first()
                out.add(pick)
            }
            Detector.childPath(root, "Graphics", "Pictures")?.listFiles()?.filter {
                isImage(it) && Regex("(?i)(title|logo|cover)").containsMatchIn(it.name)
            }?.minByOrNull { it.name }?.let { out.add(it) }
            Detector.child(root, "Game.ico")?.let { out.add(it) }
            Detector.child(root, "icon.png")?.let { out.add(it) }
        }
        return out
    }

    private fun decode(f: File, maxDim: Int): Bitmap? {
        return try {
            if (f.extension.equals("ico", ignoreCase = true)) {
                IcoDecoder.decode(f.readBytes())
            } else {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeFile(f.absolutePath, o)
                if (o.outWidth <= 0 || o.outHeight <= 0) {
                    null
                } else {
                    var s = 1
                    while (o.outWidth / (s * 2) >= maxDim || o.outHeight / (s * 2) >= maxDim) s *= 2
                    val o2 = BitmapFactory.Options()
                    o2.inSampleSize = s
                    BitmapFactory.decodeFile(f.absolutePath, o2)
                }
            }
        } catch (t: Throwable) {
            null
        }
    }

    private fun drawGradient(c: Canvas, game: Game, w: Int, h: Int) {
        val pal = PALETTES[(game.id.hashCode() and 0x7fffffff) % PALETTES.size]
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w * 0.7f, h.toFloat(), pal[0], pal[1], Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        // the "splice" seam
        val s = Paint(Paint.ANTI_ALIAS_FLAG)
        s.color = 0x44FFFFFF
        s.strokeWidth = w * 0.012f
        s.strokeCap = Paint.Cap.ROUND
        c.drawLine(w * 0.12f, h * 0.97f, w * 0.88f, h * 0.03f, s)
    }

    private fun initials(title: String): String {
        val words = title.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val letters = words.take(2).mapNotNull { w -> w.firstOrNull { ch -> ch.isLetterOrDigit() } }
        return if (letters.isEmpty()) "?" else letters.joinToString("").uppercase(Locale.ROOT)
    }

    fun generated(game: Game, w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        drawGradient(c, game, w, h)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xCCFFFFFF.toInt()
        p.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        p.textSize = h * 0.26f
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        c.drawText(initials(game.title), w / 2f, h * 0.46f - (fm.ascent + fm.descent) / 2f, p)
        return bmp
    }

    private fun compose(src: Bitmap, game: Game): Bitmap {
        val out = Bitmap.createBitmap(CW, CH, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (minOf(src.width, src.height) < 200) {
            drawGradient(c, game, CW, CH)
            val w = CW * 0.52f
            val h = w * src.height / src.width
            val top = (CH - h) / 2f - 24f
            c.drawBitmap(src, null, RectF((CW - w) / 2f, top, (CW + w) / 2f, top + h), p)
        } else {
            val scale = maxOf(CW.toFloat() / src.width, CH.toFloat() / src.height)
            val dw = src.width * scale
            val dh = src.height * scale
            c.drawBitmap(src, null, RectF((CW - dw) / 2f, (CH - dh) / 2f, (CW + dw) / 2f, (CH + dh) / 2f), p)
        }
        return out
    }

    private fun coverFile(game: Game) = File(Paths.covers, game.id + ".jpg")

    /** Builds the cached cover file from the best candidate image; null if the game has none. */
    fun build(game: Game, force: Boolean = false): File? {
        val out = coverFile(game)
        if (out.exists() && !force) return out
        for (cand in candidates(game)) {
            val src = decode(cand, 768) ?: continue
            try {
                val cover = compose(src, game)
                FileOutputStream(out).use { cover.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                return out
            } catch (t: Throwable) {
                AppLog.w("cover", "cover build failed for ${game.title}", t)
            }
        }
        return null
    }

    fun invalidate(game: Game) {
        coverFile(game).delete()
        cache.evictAll()
    }

    fun setCustom(ctx: android.content.Context, game: Game, uri: Uri): Boolean {
        return try {
            val dest = File(Paths.covers, "custom-" + game.id + ".img")
            ctx.contentResolver.openInputStream(uri)?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } } ?: return false
            game.coverPath = dest.absolutePath
            invalidate(game)
            Library.update(game)
            true
        } catch (t: Throwable) {
            false
        }
    }

    /** Loads (building if needed) the cover for [game] sized about w x h and calls [cb] on the UI thread. */
    fun load(game: Game, w: Int, h: Int, cb: (Bitmap) -> Unit) {
        val key = game.id + "|" + w + "x" + h + "|" + (game.coverPath ?: "")
        val hit = cache.get(key)
        if (hit != null) {
            cb(hit)
            return
        }
        Bg.io.execute {
            var bmp: Bitmap? = null
            try {
                val f = build(game)
                if (f != null) bmp = decode(f, maxOf(w, h))
            } catch (t: Throwable) {
                AppLog.w("cover", "load failed", t)
            }
            val result = bmp ?: generated(game, w.coerceAtLeast(60), h.coerceAtLeast(80))
            cache.put(key, result)
            Bg.ui { cb(result) }
        }
    }
}
