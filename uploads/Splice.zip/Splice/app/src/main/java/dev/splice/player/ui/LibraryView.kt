package dev.splice.player.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.graphics.Outline
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher
import dev.splice.player.R
import dev.splice.player.core.Prefs
import dev.splice.player.data.CoverStore
import dev.splice.player.data.ImportTask
import dev.splice.player.data.Library
import dev.splice.player.data.StorageAccess
import dev.splice.player.model.Format
import dev.splice.player.model.Game
import java.util.Locale

/** The game library: cover-card grid with search, filters, sorting and import progress. */
class LibraryView(private val act: MainActivity) : Screen(act) {
    private val grid = GridView(act)
    private val subtitle: TextView
    private val search: EditText
    private val chipsRow: LinearLayout
    private val searchWrap: LinearLayout
    private val importHost: FrameLayout
    private val empty: LinearLayout
    private val banner: LinearLayout
    private var items: List<Game> = emptyList()
    private var query = ""
    private var colW = 0
    private var playIntro = true
    private val ui = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { refresh() }
    private val intro = HashSet<Int>()

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int): Any = items[p]
        override fun getItemId(p: Int) = items[p].id.hashCode().toLong()
        override fun getView(position: Int, convert: View?, parent: ViewGroup): View {
            val card = (convert as? CardView) ?: CardView(act)
            card.bind(items[position], colW)
            if (playIntro && colW > 0 && position < 12 && intro.add(position)) {
                card.alpha = 0f
                card.translationY = act.dp(28).toFloat()
                card.animate().alpha(1f).translationY(0f).setStartDelay(position * 45L).setDuration(320).start()
            } else {
                card.alpha = 1f
                card.translationY = 0f
            }
            return card
        }
    }

    init {
        val col = act.vbox()
        // header
        val head = act.hbox()
        head.setPadding(act.dp(20), act.dp(18), act.dp(10), act.dp(4))
        val titles = act.vbox()
        titles.addView(act.text("Library", 28f, C.TEXT, 2))
        subtitle = act.text("", 13f, C.DIM)
        titles.add(subtitle, MATCH, WRAP, 0f, 0, 4, 0, 0)
        head.add(titles, 0, WRAP, 1f)
        head.addView(act.iconButton(R.drawable.ic_search, C.TEXT, 44) { toggleSearch() })
        head.addView(act.iconButton(R.drawable.ic_filter, C.TEXT, 44) { sortSheet() })
        col.addView(head)

        searchWrap = act.hbox()
        searchWrap.setPadding(act.dp(20), act.dp(6), act.dp(20), act.dp(6))
        search = act.input("Search games")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim() ?: ""
                refresh()
            }
        })
        searchWrap.add(search, MATCH, WRAP, 1f)
        searchWrap.visibility = View.GONE
        col.addView(searchWrap)

        val hs = HorizontalScrollView(act)
        hs.isHorizontalScrollBarEnabled = false
        chipsRow = act.hbox()
        chipsRow.setPadding(act.dp(20), act.dp(10), act.dp(12), act.dp(10))
        hs.addView(chipsRow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(hs)

        banner = act.vbox()
        banner.visibility = View.GONE
        col.add(banner, MATCH, WRAP, 0f, 16, 0, 16, 8)

        importHost = FrameLayout(act)
        col.add(importHost, MATCH, WRAP, 0f, 16, 0, 16, 8)

        val gridWrap = FrameLayout(act)
        grid.selector = android.graphics.drawable.ColorDrawable(0)
        grid.isVerticalScrollBarEnabled = false
        grid.overScrollMode = View.OVER_SCROLL_NEVER
        grid.clipToPadding = false
        grid.setPadding(act.dp(16), act.dp(4), act.dp(16), act.dp(96))
        grid.verticalSpacing = act.dp(14)
        grid.horizontalSpacing = act.dp(14)
        grid.numColumns = 2
        grid.adapter = adapter
        gridWrap.addView(grid, FrameLayout.LayoutParams(MATCH, MATCH))

        empty = act.vbox()
        empty.gravity = Gravity.CENTER_HORIZONTAL
        empty.setPadding(act.dp(36), act.dp(40), act.dp(36), act.dp(40))
        val ico = act.icon(R.drawable.ic_library, C.FAINT, 56)
        empty.add(ico, act.dp(56), act.dp(56))
        empty.add(act.text("No games yet", 20f, C.TEXT, 1), WRAP, WRAP, 0f, 0, 18, 0, 0)
        val d = act.text("Add an RPG Maker game: XP, VX, VX Ace, MV or MZ. Pokémon fangames like Infinite Fusion are detected automatically.", 14f, C.DIM)
        d.gravity = Gravity.CENTER
        d.setLineSpacing(0f, 1.15f)
        empty.add(d, MATCH, WRAP, 0f, 0, 8, 0, 0)
        empty.add(act.button("Pick Game.exe", R.drawable.ic_gamepad, BTN_PRIMARY) { act.importExe() }, MATCH, WRAP, 0f, 0, 22, 0, 0)
        empty.add(act.button("Add a game folder", R.drawable.ic_folder, BTN_TONAL) { act.importFolder() }, MATCH, WRAP, 0f, 0, 10, 0, 0)
        empty.add(act.button("Import a ZIP", R.drawable.ic_zip, BTN_TONAL) { act.importZip() }, MATCH, WRAP, 0f, 0, 10, 0, 0)
        gridWrap.addView(empty, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.CENTER))
        col.add(gridWrap, MATCH, 0, 1f)

        addView(col, LayoutParams(MATCH, MATCH))

        // add button
        val fab = act.hbox()
        fab.gravity = Gravity.CENTER
        fab.setPadding(act.dp(20), act.dp(14), act.dp(22), act.dp(14))
        fab.background = act.ripple(act.shape(C.MINT, 18f), 18f, 0x33000000)
        fab.addView(act.icon(R.drawable.ic_add, C.ON_MINT, 22))
        fab.add(act.text("Add game", 15f, C.ON_MINT, 1), WRAP, WRAP, 0f, 8, 0, 0, 0)
        fab.elevation = act.dp(6).toFloat()
        fab.isClickable = true
        fab.setOnClickListener { addSheet() }
        fab.pressable(0.95f)
        val lp = LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END)
        lp.setMargins(0, 0, act.dp(18), act.dp(18))
        addView(fab, lp)

        Library.addListener(listener)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val usable = w - act.dp(32)
        val cols = (usable / act.dp(168)).coerceAtLeast(2)
        grid.numColumns = cols
        colW = (usable - act.dp(14) * (cols - 1)) / cols
        adapter.notifyDataSetChanged()
    }

    override fun onShow() {
        refresh()
        if (playIntro) ui.postDelayed({ playIntro = false }, 900)
        paintBanner()
    }

    override fun onDestroyScreen() {
        Library.removeListener(listener)
    }

    // ---------- data ----------

    private fun chipDefs(): List<Pair<String, String>> {
        val all = Library.all()
        val out = ArrayList<Pair<String, String>>()
        out.add(Pair("all", "All"))
        if (all.any { it.favorite }) out.add(Pair("fav", "Favorites"))
        if (all.any { it.isPokemon }) out.add(Pair("pokemon", "Pokémon"))
        for (f in Format.values()) if (all.any { it.format == f }) out.add(Pair(f.id, f.badge))
        return out
    }

    private fun matches(g: Game, filter: String): Boolean = when (filter) {
        "all" -> true
        "fav" -> g.favorite
        "pokemon" -> g.isPokemon
        else -> g.format.id == filter
    }

    fun refresh() {
        val all = Library.all()
        var filter = Prefs.filter
        val defs = chipDefs()
        if (defs.none { it.first == filter }) {
            filter = "all"
            Prefs.filter = "all"
        }
        val q = query.lowercase(Locale.getDefault())
        var list = all.filter { matches(it, filter) && (q.isEmpty() || it.title.lowercase(Locale.getDefault()).contains(q)) }
        list = when (Prefs.sort) {
            1 -> list.sortedBy { it.title.lowercase(Locale.getDefault()) }
            2 -> list.sortedByDescending { it.addedAt }
            3 -> list.sortedByDescending { it.playTimeMs }
            else -> list.sortedWith(compareByDescending<Game> { it.lastPlayed }.thenByDescending { it.addedAt })
        }
        items = list
        subtitle.text = when {
            all.isEmpty() -> "Your RPG Maker games"
            list.size == all.size -> "${all.size} ${if (all.size == 1) "game" else "games"}"
            else -> "${list.size} of ${all.size} games"
        }
        chipsRow.removeAllViews()
        if (all.isNotEmpty()) {
            for ((id, label) in defs) {
                chipsRow.add(act.chip(label, id == filter) {
                    Prefs.filter = id
                    intro.clear()
                    refresh()
                }, WRAP, WRAP, 0f, 0, 0, 8, 0)
            }
        }
        empty.visibility = if (all.isEmpty()) View.VISIBLE else View.GONE
        grid.visibility = if (all.isEmpty()) View.GONE else View.VISIBLE
        adapter.notifyDataSetChanged()
    }

    private fun paintBanner() {
        banner.removeAllViews()
        val needs = Library.all().any { !it.managed && StorageAccess.needsPermission(act, it.dir) }
        if (!needs) {
            banner.visibility = View.GONE
            return
        }
        banner.visibility = View.VISIBLE
        val row = act.hbox()
        row.setPadding(act.dp(14), act.dp(12), act.dp(10), act.dp(12))
        row.background = act.shape(0x22FFC857, 14f, 0x55FFC857, 1f)
        row.addView(act.icon(R.drawable.ic_warning, C.WARN, 22))
        row.add(act.text("Splice can't read games stored outside its own folder until you allow All files access.", 13f, C.TEXT), 0, WRAP, 1f, 12, 0, 8, 0)
        row.addView(act.button("Allow", 0, BTN_PRIMARY) { StorageAccess.request(act) })
        banner.addView(row)
    }

    // ---------- import progress ----------

    fun trackImport(task: ImportTask) {
        importHost.removeAllViews()
        val card = act.vbox()
        card.setPadding(act.dp(16), act.dp(14), act.dp(12), act.dp(14))
        card.background = act.shape(C.SURFACE, 16f, C.OUTLINE, 1f)
        val top = act.hbox()
        val label = act.text("Importing ${task.label.lowercase(Locale.getDefault())}", 14.5f, C.TEXT, 1)
        top.add(label, 0, WRAP, 1f)
        top.addView(act.button("Cancel", 0, BTN_GHOST) { task.cancel.set(true) })
        card.addView(top)
        val msg = act.text(task.message, 12.5f, C.DIM, 0, 1)
        card.add(msg, MATCH, WRAP, 0f, 0, 6, 0, 8)
        val bar = SweepBar(act)
        card.add(bar, MATCH, act.dp(6))
        importHost.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
        val tick = object : Runnable {
            override fun run() {
                if (task.finished) {
                    importHost.removeAllViews()
                    refresh()
                    return
                }
                bar.progress = task.fraction
                val parts = ArrayList<String>()
                if (task.files > 0) parts.add("${task.files} files")
                if (task.bytes > 0) parts.add(dev.splice.player.core.Fmt.size(task.bytes))
                msg.text = (if (parts.isEmpty()) "" else parts.joinToString(" · ") + " · ") + task.message
                ui.postDelayed(this, 250)
            }
        }
        ui.post(tick)
    }

    // ---------- UI actions ----------

    private fun toggleSearch() {
        if (searchWrap.visibility == View.VISIBLE) {
            search.setText("")
            searchWrap.visibility = View.GONE
        } else {
            searchWrap.visibility = View.VISIBLE
            search.requestFocus()
        }
    }

    private fun sortSheet() {
        val s = Sheet(act, "Sort games")
        val names = listOf("Recently played", "Title A to Z", "Recently added", "Most played")
        names.forEachIndexed { i, n ->
            s.action(n, if (Prefs.sort == i) R.drawable.ic_check else R.drawable.ic_filter) {
                Prefs.sort = i
                intro.clear()
                refresh()
            }
        }
        s.show()
    }

    private fun addSheet() {
        val s = Sheet(act, "Add a game", "Splice detects RPG Maker XP, VX, VX Ace, MV and MZ automatically")
        s.action("Pick Game.exe (play in place)", R.drawable.ic_gamepad) { act.importExe() }
        s.action("Add a game folder", R.drawable.ic_folder) { act.importFolder() }
        s.action("Import a ZIP (copies it into Splice)", R.drawable.ic_zip) { act.importZip() }
        s.show()
    }

    private fun quickSheet(g: Game) {
        val s = Sheet(act, g.title, g.format.label + " · " + g.path.substringAfterLast('/'))
        s.action("Play", R.drawable.ic_play) { act.play(g) }
        s.action(if (g.favorite) "Remove from favorites" else "Add to favorites", R.drawable.ic_star) {
            g.favorite = !g.favorite
            Library.update(g)
        }
        s.action("Game page", R.drawable.ic_info) { act.openGame(g) }
        s.action("Remove this game", R.drawable.ic_trash, true) { removeQuick(g) }
        s.show()
    }

    /** Removes one library entry without opening its page (useful for a duplicate). */
    private fun removeQuick(g: Game) {
        val s = Sheet(act, "Remove ${g.title}?", g.path)
        s.add(act.text("Saves and backups are kept.", 14f, C.DIM))
        s.add(act.button("Remove from library", 0, BTN_TONAL) {
            s.dismiss()
            Library.remove(g.id, deleteFiles = false, deleteSaves = false)
        }, 16)
        if (g.managed) {
            s.add(act.button("Remove and delete game files", R.drawable.ic_trash, BTN_DANGER) {
                s.dismiss()
                Library.remove(g.id, deleteFiles = true, deleteSaves = false)
            }, 10)
        }
        s.show()
    }

    // ---------- card ----------

    private inner class CardView(ctx: Context) : FrameLayout(ctx) {
        private val cover = ImageView(ctx)
        private val title = ctx.text("", 13.5f, C.TEXT, 1, 2)
        private val badges = ctx.hbox()
        private val star = ctx.icon(R.drawable.ic_star_fill, C.PEACH, 18)
        private val playBtn = FrameLayout(ctx)
        private var boundId: String? = null

        init {
            cover.scaleType = ImageView.ScaleType.CENTER_CROP
            addView(cover, LayoutParams(MATCH, MATCH))
            val shade = View(ctx)
            val g = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xE60C0A14.toInt()))
            shade.background = g
            addView(shade, LayoutParams(MATCH, ctx.dp(110), Gravity.BOTTOM))
            val tl = LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
            tl.setMargins(ctx.dp(11), 0, ctx.dp(58), ctx.dp(10))
            addView(title, tl)
            val bl = LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START)
            bl.setMargins(ctx.dp(8), ctx.dp(8), 0, 0)
            addView(badges, bl)
            val sl = LayoutParams(ctx.dp(18), ctx.dp(18), Gravity.TOP or Gravity.END)
            sl.setMargins(0, ctx.dp(8), ctx.dp(8), 0)
            addView(star, sl)
            // one tap on the round button starts the game; tapping the card opens the game page
            playBtn.background = ctx.ripple(ctx.shape(C.MINT, 20f), 20f, 0x33000000)
            playBtn.isClickable = true
            playBtn.elevation = ctx.dp(4).toFloat()
            playBtn.addView(ctx.icon(R.drawable.ic_play, C.ON_MINT, 20), LayoutParams(ctx.dp(20), ctx.dp(20), Gravity.CENTER))
            val pl = LayoutParams(ctx.dp(40), ctx.dp(40), Gravity.BOTTOM or Gravity.END)
            pl.setMargins(0, 0, ctx.dp(8), ctx.dp(8))
            addView(playBtn, pl)
            background = ctx.shape(C.SURFACE2, 18f)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, ctx.dpf(18f))
                }
            }
            clipToOutline = true
            isClickable = true
            foreground = ctx.ripple(null, 18f)
            pressable(0.96f)
        }

        fun bind(g: Game, w: Int) {
            val h = if (w > 0) w * 4 / 3 else act.dp(220)
            layoutParams = AbsListView.LayoutParams(if (w > 0) w else MATCH, h)
            title.text = g.title
            star.visibility = if (g.favorite) View.VISIBLE else View.GONE
            badges.removeAllViews()
            badges.addView(context.badge(g.format.badge, C.MINT))
            if (g.isPokemon) badges.add(context.badge("PKMN", C.PEACH), WRAP, WRAP, 0f, 4, 0, 0, 0)
            boundId = g.id
            cover.setImageDrawable(null)
            val id = g.id
            CoverStore.load(g, if (w > 0) w else 300, h) { bmp: Bitmap -> if (boundId == id) cover.setImageBitmap(bmp) }
            setOnClickListener { act.openGame(g) }
            playBtn.setOnClickListener { act.play(g) }
            setOnLongClickListener {
                quickSheet(g)
                true
            }
        }
    }
}
