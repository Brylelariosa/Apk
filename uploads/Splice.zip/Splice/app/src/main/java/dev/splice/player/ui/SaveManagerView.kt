package dev.splice.player.ui

import android.content.Intent
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import dev.splice.player.R
import dev.splice.player.core.Bg
import dev.splice.player.core.Fmt
import dev.splice.player.data.Library
import dev.splice.player.data.SaveVault
import dev.splice.player.data.SessionTracker
import dev.splice.player.model.Game

/** Saves for one game: live files, slots, backups, ZIP export/import. */
class SaveManagerView(private val act: MainActivity, private val gameId: String) : Screen(act) {
    private val body: LinearLayout = act.vbox()
    private var busy = false

    init {
        val col = act.vbox()
        col.addView(act.topBar("Saves", { act.pop() }))
        body.setPadding(act.dp(16), act.dp(4), act.dp(16), act.dp(32))
        col.addView(body)
        addView(act.scroll(col), LayoutParams(MATCH, MATCH))
        refresh()
    }

    override fun onShow() {
        refresh()
    }

    private fun game(): Game? = Library.get(gameId)

    private fun running(g: Game): Boolean {
        val s = SessionTracker.read()
        return s != null && s.end == 0L && s.gameId == g.id
    }

    private fun refresh() {
        val g = game() ?: return
        body.removeAllViews()
        body.add(act.text(g.title, 15f, C.DIM, 1), MATCH, WRAP, 0f, 4, 0, 0, 10)
        if (running(g)) {
            body.add(act.text("This game is running. Saves can be changed after you leave it.", 13f, C.WARN), MATCH, WRAP, 0f, 4, 0, 0, 10)
        }
        // heavy folder reads happen off the UI thread
        Bg.io.execute {
            val files = SaveVault.scan(g)
            val slots = SaveVault.slots(g)
            val backups = SaveVault.backups(g)
            Bg.ui { if (isAttachedToWindow || parent != null) render(g, files, slots, backups) }
        }
    }

    private fun render(g: Game, files: List<SaveVault.SaveFile>, slots: List<SaveVault.Slot>, backups: List<SaveVault.Backup>) {
        // keep the title (and running note) already added; remove anything below
        while (body.childCount > (if (running(g)) 2 else 1)) body.removeViewAt(body.childCount - 1)
        val locked = running(g)

        // current saves
        body.add(act.sectionTitle("Current saves"), MATCH, WRAP, 0f, 6, 14, 0, 10)
        val cur = SettingsCard(act)
        if (files.isEmpty()) {
            cur.note("No save files yet. They appear here after you save in the game.")
        } else {
            val total = files.sumOf { it.size }
            cur.info("Files", "${files.size} · ${Fmt.size(total)}")
            for (f in files.take(6)) {
                cur.info(f.name + if (f.legacy) "  (game folder)" else "", Fmt.ago(f.modified))
            }
            if (files.size > 6) cur.note("and ${files.size - 6} more")
        }
        body.addView(cur.view)

        // slots
        body.add(act.sectionTitle("Slots"), MATCH, WRAP, 0f, 6, 22, 0, 4)
        body.add(act.text("Each slot is a separate set of saves, handy for another playthrough or a Nuzlocke run.", 12.5f, C.DIM), MATCH, WRAP, 0f, 6, 0, 0, 10)
        val hs = HorizontalScrollView(act)
        hs.isHorizontalScrollBarEnabled = false
        val row = act.hbox(false)
        hs.addView(row, LayoutParams(WRAP, WRAP))
        for (s in slots) row.add(slotCard(g, s, locked), WRAP, WRAP, 0f, 0, 0, 10, 0)
        row.add(newSlotCard(g, locked), WRAP, WRAP, 0f, 0, 0, 0, 0)
        body.addView(hs)

        // backups
        body.add(act.sectionTitle("Backups"), MATCH, WRAP, 0f, 6, 24, 0, 10)
        val bc = SettingsCard(act)
        bc.action("Back up now", "Save a copy of the current saves", R.drawable.ic_saves) {
            if (locked) { act.toast("Leave the game first"); return@action }
            runBusy("Backing up") {
                val f = SaveVault.backup(g, "manual")
                Bg.ui { act.toast(if (f != null) "Backup created" else "Nothing to back up yet"); refresh() }
            }
        }
        if (backups.isEmpty()) {
            bc.note("No backups yet. Splice also makes automatic backups before and after you play.")
        }
        for (b in backups.take(12)) {
            bc.action(Fmt.date(b.created), b.label.replace('-', ' ') + " · " + Fmt.size(b.size), R.drawable.ic_clock) { backupSheet(g, b, locked) }
        }
        body.addView(bc.view)

        // import / export
        body.add(act.sectionTitle("Transfer"), MATCH, WRAP, 0f, 6, 24, 0, 10)
        val tc = SettingsCard(act)
        tc.action("Export saves as ZIP", "Share or keep a copy outside Splice", R.drawable.ic_export) { exportZip(g) }
        tc.action("Import saves from ZIP", "Adds the files to the current slot (a backup is made first)", R.drawable.ic_import) {
            if (locked) { act.toast("Leave the game first"); return@action }
            importZip(g)
        }
        body.addView(tc.view)
    }

    private fun runBusy(label: String, work: () -> Unit) {
        if (busy) return
        busy = true
        act.toast(label + "…")
        Bg.io.execute {
            try {
                work()
            } finally {
                busy = false
            }
        }
    }

    private fun slotCard(g: Game, s: SaveVault.Slot, locked: Boolean): View {
        val c = act.vbox()
        c.setPadding(act.dp(16), act.dp(14), act.dp(16), act.dp(14))
        c.background = act.ripple(
            if (s.active) act.shape(0x1F5BE3C4, 16f, C.MINT, 1.5f) else act.shape(C.SURFACE, 16f, C.OUTLINE, 1f), 16f
        )
        val head = act.hbox()
        head.addView(act.text(s.name, 15f, if (s.active) C.MINT else C.TEXT, 1, 1))
        if (s.active) head.add(act.badge("ACTIVE", C.MINT), WRAP, WRAP, 0f, 8, 0, 0, 0)
        c.addView(head)
        c.add(act.text("${s.files} files · ${Fmt.size(s.size)}", 12.5f, C.DIM), MATCH, WRAP, 0f, 0, 6, 0, 0)
        c.minimumWidth = act.dp(170)
        c.isClickable = true
        c.setOnClickListener {
            if (locked) { act.toast("Leave the game first"); return@setOnClickListener }
            slotSheet(g, s)
        }
        return c
    }

    private fun newSlotCard(g: Game, locked: Boolean): View {
        val c = act.vbox()
        c.gravity = android.view.Gravity.CENTER
        c.setPadding(act.dp(22), act.dp(14), act.dp(22), act.dp(14))
        c.background = act.ripple(act.shape(0, 16f, C.OUTLINE, 1f), 16f)
        c.addView(act.icon(R.drawable.ic_add, C.DIM, 24))
        c.add(act.text("New slot", 13f, C.DIM, 1), WRAP, WRAP, 0f, 0, 6, 0, 0)
        c.isClickable = true
        c.setOnClickListener {
            if (locked) { act.toast("Leave the game first"); return@setOnClickListener }
            val s = Sheet(act, "New slot")
            val et = act.input("Slot name", "Playthrough ${SaveVault.slots(g).size + 1}")
            s.add(et)
            s.add(act.button("Start empty (new game)", R.drawable.ic_add, BTN_PRIMARY) {
                s.dismiss()
                val name = et.text.toString()
                runBusy("Creating slot") {
                    val slot = SaveVault.createSlot(g, name, false)
                    SaveVault.switchSlot(g, slot.id)
                    Bg.ui { refresh() }
                }
            }, 16)
            s.add(act.button("Copy current saves", R.drawable.ic_copy, BTN_TONAL) {
                s.dismiss()
                val name = et.text.toString()
                runBusy("Creating slot") {
                    SaveVault.createSlot(g, name, true)
                    Bg.ui { refresh() }
                }
            }, 10)
            s.show()
        }
        return c
    }

    private fun slotSheet(g: Game, s: SaveVault.Slot) {
        val sh = Sheet(act, s.name, "${s.files} files · ${Fmt.size(s.size)}")
        if (!s.active) {
            sh.action("Switch to this slot", R.drawable.ic_play) {
                runBusy("Switching slot") {
                    val ok = SaveVault.switchSlot(g, s.id)
                    Bg.ui { if (!ok) act.toast("Could not switch slot"); refresh() }
                }
            }
        }
        sh.action("Rename", R.drawable.ic_pencil) {
            promptSheet(act, "Rename slot", "Slot name", s.name, false) { v ->
                SaveVault.renameSlot(g, s.id, v)
                refresh()
            }
        }
        if (!s.active) {
            sh.action("Delete slot", R.drawable.ic_trash, true) {
                confirmSheet(act, "Delete ${s.name}?", "The saves in this slot are removed permanently.", "Delete", true) {
                    SaveVault.deleteSlot(g, s.id)
                    refresh()
                }
            }
        }
        sh.show()
    }

    private fun backupSheet(g: Game, b: SaveVault.Backup, locked: Boolean) {
        val sh = Sheet(act, Fmt.date(b.created), b.label.replace('-', ' ') + " · " + Fmt.size(b.size))
        sh.action("Restore this backup", R.drawable.ic_refresh) {
            if (locked) { act.toast("Leave the game first"); return@action }
            confirmSheet(act, "Restore backup?", "Current saves are backed up first, then replaced by this backup.", "Restore", false) {
                runBusy("Restoring") {
                    val ok = SaveVault.restore(g, b.file)
                    Bg.ui { act.toast(if (ok) "Backup restored" else "Restore failed"); refresh() }
                }
            }
        }
        sh.action("Delete backup", R.drawable.ic_trash, true) {
            SaveVault.deleteBackup(b)
            refresh()
        }
        sh.show()
    }

    private fun exportZip(g: Game) {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/zip"
        i.putExtra(Intent.EXTRA_TITLE, g.title.replace(Regex("[^A-Za-z0-9._-]+"), "_") + "-saves-" + Fmt.stamp() + ".zip")
        act.launchForResult(i) { data ->
            val uri = data?.data
            if (uri != null) {
                runBusy("Exporting") {
                    var ok = false
                    try {
                        act.contentResolver.openOutputStream(uri)?.use { SaveVault.export(g, it) }
                        ok = true
                    } catch (t: Throwable) {
                        ok = false
                    }
                    Bg.ui { act.toast(if (ok) "Saves exported" else "Export failed") }
                }
            }
        }
    }

    private fun importZip(g: Game) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        act.launchForResult(i) { data ->
            val uri = data?.data
            if (uri != null) {
                runBusy("Importing") {
                    var n = 0
                    try {
                        act.contentResolver.openInputStream(uri)?.use { n = SaveVault.importArchive(g, it) }
                    } catch (t: Throwable) {
                        n = -1
                    }
                    Bg.ui {
                        act.toast(if (n > 0) "Imported $n file(s)" else if (n == 0) "No save files found in that ZIP" else "Import failed")
                        refresh()
                    }
                }
            }
        }
    }
}
