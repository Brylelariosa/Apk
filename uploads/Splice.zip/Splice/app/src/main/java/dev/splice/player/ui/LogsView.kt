package dev.splice.player.ui

import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import dev.splice.player.R
import dev.splice.player.core.Bg
import dev.splice.player.core.Files
import dev.splice.player.core.Fmt
import dev.splice.player.core.Paths
import dev.splice.player.data.Library
import java.io.File

/** Logs tab (all logs) or one game's session logs when [gameId] is set. */
class LogsView(private val act: MainActivity, private val gameId: String? = null) : Screen(act) {
    private val list: LinearLayout = act.vbox()

    private class Entry(val title: String, val sub: String, val file: File, val level: Int, val time: Long)

    init {
        val col = act.vbox()
        if (gameId == null) {
            val head = act.vbox()
            head.setPadding(act.dp(20), act.dp(18), act.dp(20), act.dp(8))
            head.addView(act.text("Logs", 28f, C.TEXT, 2))
            head.add(act.text("Engine output, errors and crash reports", 13f, C.DIM), MATCH, WRAP, 0f, 0, 4, 0, 0)
            col.addView(head)
        } else {
            col.addView(act.topBar("Logs", { act.pop() }))
        }
        list.setPadding(act.dp(16), act.dp(8), act.dp(16), act.dp(24))
        col.addView(list)
        addView(act.scroll(col), LayoutParams(MATCH, MATCH))
    }

    override fun onShow() {
        Bg.io.execute {
            val out = ArrayList<Entry>()
            if (gameId == null) {
                Paths.logs.listFiles { f -> f.name.startsWith("crash-") && f.name.endsWith(".txt") }?.forEach {
                    out.add(Entry("App crash", Fmt.date(it.lastModified()), it, 3, it.lastModified()))
                }
                val app = File(Paths.logs, "app.log")
                if (app.exists()) out.add(Entry("App log", Fmt.size(app.length()), app, 0, app.lastModified()))
            }
            val dirs = if (gameId != null) listOfNotNull(File(Paths.sessions, gameId).takeIf { it.isDirectory })
            else Paths.sessions.listFiles { f -> f.isDirectory }?.toList() ?: emptyList()
            for (d in dirs) {
                val title = Library.get(d.name)?.title ?: d.name
                d.listFiles { f -> f.name.endsWith(".log") }?.forEach { f ->
                    val tail = try {
                        Files.tail(f, 50_000)
                    } catch (t: Throwable) {
                        ""
                    }
                    val level = when {
                        tail.contains("NATIVE CRASH") -> 3
                        Regex("(?i)(fatal|exception|\\bE\\b .*|error)").containsMatchIn(tail) -> 2
                        else -> 0
                    }
                    out.add(Entry(title, Fmt.date(f.lastModified()) + " · " + Fmt.size(f.length()), f, level, f.lastModified()))
                }
            }
            out.sortByDescending { it.time }
            Bg.ui { render(out.take(60)) }
        }
    }

    private fun render(entries: List<Entry>) {
        list.removeAllViews()
        if (entries.isEmpty()) {
            val e = act.vbox()
            e.gravity = Gravity.CENTER_HORIZONTAL
            e.setPadding(act.dp(30), act.dp(56), act.dp(30), act.dp(30))
            e.add(act.icon(R.drawable.ic_logs, C.FAINT, 52), act.dp(52), act.dp(52))
            e.add(act.text("No logs yet", 19f, C.TEXT, 1), WRAP, WRAP, 0f, 0, 16, 0, 0)
            val d = act.text("Every play session writes a log with the engine's output. Crashes are recorded with a backtrace.", 14f, C.DIM)
            d.gravity = Gravity.CENTER
            e.add(d, MATCH, WRAP, 0f, 0, 8, 0, 0)
            list.addView(e)
            return
        }
        for (e in entries) list.add(row(e), MATCH, WRAP, 0f, 0, 0, 0, 10)
        list.add(act.button(if (gameId == null) "Clear all logs" else "Clear this game's logs", R.drawable.ic_trash, BTN_DANGER) {
            confirmSheet(act, "Clear logs?", "Session logs and crash reports are deleted.", "Clear", true) {
                if (gameId == null) {
                    Paths.sessions.listFiles()?.forEach { Files.deleteRecursive(it) }
                    Paths.logs.listFiles { f -> f.name.startsWith("crash-") || f.name.startsWith("app.log") }?.forEach { it.delete() }
                } else {
                    Files.deleteRecursive(File(Paths.sessions, gameId))
                }
                onShow()
            }
        }, MATCH, WRAP, 0f, 0, 14, 0, 0)
    }

    private fun row(e: Entry): View {
        val c = act.hbox()
        c.setPadding(act.dp(14), act.dp(14), act.dp(14), act.dp(14))
        c.background = act.ripple(act.shape(C.SURFACE, 16f, C.OUTLINE, 1f), 16f)
        val (icon, color) = when (e.level) {
            3 -> Pair(R.drawable.ic_bug, C.DANGER)
            2 -> Pair(R.drawable.ic_warning, C.WARN)
            else -> Pair(R.drawable.ic_logs, C.DIM)
        }
        c.add(act.icon(icon, color, 22), act.dp(22), act.dp(22), 0f, 0, 0, 14, 0)
        val col = act.vbox()
        col.addView(act.text(e.title, 15f, C.TEXT, 1, 1))
        col.add(act.text(e.sub, 12.5f, C.DIM, 0, 1), MATCH, WRAP, 0f, 0, 3, 0, 0)
        c.add(col, 0, WRAP, 1f)
        if (e.level >= 2) c.add(act.badge(if (e.level == 3) "CRASH" else "ERRORS", color), WRAP, WRAP, 0f, 8, 0, 8, 0)
        c.addView(act.icon(R.drawable.ic_chevron_right, C.FAINT, 20))
        c.isClickable = true
        c.setOnClickListener { act.push(LogViewerView(act, e.title, e.file)) }
        c.pressable(0.98f)
        return c
    }
}
