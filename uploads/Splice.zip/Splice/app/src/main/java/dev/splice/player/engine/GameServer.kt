package dev.splice.player.engine

import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import dev.splice.player.core.Files
import java.io.ByteArrayInputStream
import java.io.File
import java.io.InputStream
import java.io.RandomAccessFile
import java.util.Locale

/**
 * Serves an RPG Maker MV/MZ game folder to the WebView as https://splice.game/ without copying or
 * starting a socket server. Case-insensitive path lookup (Windows-made games), HTTP Range support
 * (audio/video seeking) and automatic injection of the NW.js compatibility shim into index.html.
 */
class GameServer(private val webRoot: File, private val shimJs: String) {
    companion object {
        const val HOST = "splice.game"
        const val ORIGIN = "https://splice.game"
        private const val SHIM_PATH = "/__splice/shim.js"
        private val HEAD = Regex("(?i)<head[^>]*>")

        fun mimeFor(name: String): String {
            return when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
                "html", "htm" -> "text/html"
                "js", "mjs" -> "application/javascript"
                "json", "map" -> "application/json"
                "css" -> "text/css"
                "png", "png_" -> "image/png"
                "jpg", "jpeg" -> "image/jpeg"
                "gif" -> "image/gif"
                "webp" -> "image/webp"
                "svg" -> "image/svg+xml"
                "ico" -> "image/x-icon"
                "ogg", "ogg_", "oga" -> "audio/ogg"
                "m4a", "m4a_", "aac" -> "audio/mp4"
                "mp3" -> "audio/mpeg"
                "wav" -> "audio/wav"
                "mp4", "m4v" -> "video/mp4"
                "webm" -> "video/webm"
                "ttf" -> "font/ttf"
                "otf" -> "font/otf"
                "woff" -> "font/woff"
                "woff2" -> "font/woff2"
                "txt" -> "text/plain"
                "xml" -> "application/xml"
                "wasm" -> "application/wasm"
                else -> "application/octet-stream"
            }
        }
    }

    private val dirIndex = HashMap<String, Map<String, String>>()

    private fun index(dir: File): Map<String, String> = synchronized(dirIndex) {
        dirIndex.getOrPut(dir.path) {
            val m = HashMap<String, String>()
            dir.list()?.forEach { m[it.lowercase(Locale.ROOT)] = it }
            m
        }
    }

    /** Resolves [rel] below the web root, ignoring letter case; null if missing or escaping. */
    fun resolve(rel: String): File? {
        var cur = webRoot
        for (seg in rel.split('/')) {
            if (seg.isEmpty() || seg == ".") continue
            if (seg == "..") return null
            val direct = File(cur, seg)
            cur = if (direct.exists()) {
                direct
            } else {
                val real = index(cur)[seg.lowercase(Locale.ROOT)] ?: return null
                File(cur, real)
            }
        }
        return cur
    }

    private val corsHeaders: Map<String, String> = mapOf(
        "Access-Control-Allow-Origin" to "*",
        "Cache-Control" to "no-cache"
    )

    private fun notFound(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", 404, "Not Found", corsHeaders, ByteArrayInputStream("Not found".toByteArray()))

    private fun textResponse(mime: String, body: String): WebResourceResponse =
        WebResourceResponse(mime, "utf-8", 200, "OK", corsHeaders, ByteArrayInputStream(body.toByteArray(Charsets.UTF_8)))

    fun intercept(req: WebResourceRequest): WebResourceResponse? {
        val url: Uri = req.url
        if (url.host != HOST) return null
        var path = Uri.decode(url.encodedPath ?: "/")
        if (path == SHIM_PATH) return textResponse("application/javascript", shimJs)
        if (path.endsWith("/")) path += "index.html"
        val f = resolve(path) ?: return notFound()
        if (!f.isFile) return notFound()
        val mime = mimeFor(f.name)

        if (path.equals("/index.html", ignoreCase = true)) {
            return try {
                val html = Files.readTextSmart(f)
                val tag = "<script src=\"$SHIM_PATH\"></script>"
                val m = HEAD.find(html)
                val patched = if (m != null) html.substring(0, m.range.last + 1) + tag + html.substring(m.range.last + 1) else tag + html
                textResponse("text/html", patched)
            } catch (t: Throwable) {
                notFound()
            }
        }

        val len = f.length()
        val range = req.requestHeaders["Range"] ?: req.requestHeaders["range"]
        if (range != null && range.startsWith("bytes=") && len > 0) {
            val parts = range.substring(6).split("-")
            var start = parts[0].toLongOrNull() ?: 0L
            var end = if (parts.size > 1 && parts[1].isNotEmpty()) (parts[1].toLongOrNull() ?: (len - 1)) else len - 1
            if (parts[0].isEmpty() && parts.size > 1) { // suffix range: last N bytes
                val n = parts[1].toLongOrNull() ?: 0L
                start = (len - n).coerceAtLeast(0L)
                end = len - 1
            }
            if (start >= len) {
                val h = HashMap(corsHeaders)
                h["Content-Range"] = "bytes */$len"
                return WebResourceResponse(mime, null, 416, "Range Not Satisfiable", h, ByteArrayInputStream(ByteArray(0)))
            }
            end = minOf(end, len - 1)
            val h = HashMap(corsHeaders)
            h["Accept-Ranges"] = "bytes"
            h["Content-Range"] = "bytes $start-$end/$len"
            h["Content-Length"] = (end - start + 1).toString()
            return WebResourceResponse(mime, null, 206, "Partial Content", h, RangeStream(f, start, end - start + 1))
        }

        val h = HashMap(corsHeaders)
        h["Accept-Ranges"] = "bytes"
        h["Content-Length"] = len.toString()
        val enc = if (mime.startsWith("text/") || mime == "application/javascript" || mime == "application/json") "utf-8" else null
        return WebResourceResponse(mime, enc, 200, "OK", h, f.inputStream())
    }

    private class RangeStream(file: File, start: Long, private var remaining: Long) : InputStream() {
        private val raf = RandomAccessFile(file, "r")

        init {
            raf.seek(start)
        }

        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = raf.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = raf.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }

        override fun available(): Int = minOf(remaining, Int.MAX_VALUE.toLong()).toInt()

        override fun close() {
            try {
                raf.close()
            } catch (ignored: Throwable) {
            }
        }
    }
}
