package dev.splice.player.data

import dev.splice.player.core.AppLog
import dev.splice.player.core.Files
import dev.splice.player.core.Fmt
import dev.splice.player.core.Paths
import dev.splice.player.core.Prefs
import dev.splice.player.model.Game
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipInputStream

/**
 * Save management. Every game has a private "live" save folder inside Splice (MV/MZ read and write
 * their save/ folder there through the NW.js shim; RGSS games are pointed at it through a preload
 * script). On top of that: rolling auto-backups, manual backups, ZIP export/import and named slots
 * (full snapshots of the live folder, e.g. one per playthrough).
 *
 * RGSS games that keep Game.rxdata next to the game files are handled too: those files are included
 * in backups/exports ("legacy" entries) and copied into the live folder on first launch.
 */
object SaveVault {
    class SaveFile(val name: String, val size: Long, val modified: Long, val legacy: Boolean)
    class Backup(val file: File, val label: String, val created: Long, val size: Long)
    class Slot(val id: String, val name: String, val created: Long, val active: Boolean, val files: Int, val size: Long)

    private const val LIVE = "live/"
    private const val LEGACY = "legacy/"

    fun liveDir(g: Game): File = Paths.saveDir(g.id)

    private fun isLegacySaveName(n: String): Boolean {
        val l = n.lowercase(Locale.ROOT)
        val ext = l.substringAfterLast('.', "")
        if (ext != "rxdata" && ext != "rvdata" && ext != "rvdata2") return false
        return l.startsWith("game") || l.startsWith("save")
    }

    fun legacyFiles(g: Game): List<File> {
        if (!g.format.isRgss) return emptyList()
        val list = g.dir.listFiles() ?: return emptyList()
        return list.filter { it.isFile && isLegacySaveName(it.name) }
    }

    fun scan(g: Game): List<SaveFile> {
        val out = ArrayList<SaveFile>()
        for ((f, rel) in Zip.listTree(liveDir(g))) {
            if (rel.startsWith(".")) continue
            out.add(SaveFile(rel, f.length(), f.lastModified(), false))
        }
        for (f in legacyFiles(g)) out.add(SaveFile(f.name, f.length(), f.lastModified(), true))
        return out.sortedByDescending { it.modified }
    }

    fun hasSaves(g: Game): Boolean = scan(g).isNotEmpty()

    private fun clearDir(d: File) {
        d.listFiles()?.forEach { Files.deleteRecursive(it) }
    }

    private fun entriesFor(g: Game): List<Pair<File, String>> {
        val list = ArrayList<Pair<File, String>>()
        for ((f, rel) in Zip.listTree(liveDir(g))) {
            if (!rel.startsWith(".")) list.add(Pair(f, LIVE + rel))
        }
        for (f in legacyFiles(g)) list.add(Pair(f, LEGACY + f.name))
        return list
    }

    // ---------- backups ----------

    @Synchronized
    fun backup(g: Game, label: String): File? {
        val entries = entriesFor(g)
        if (entries.isEmpty()) return null
        val safe = label.replace(Regex("[^A-Za-z0-9-]+"), "-").trim('-').ifEmpty { "backup" }
        val out = File(Paths.backupDir(g.id), Fmt.stamp() + "_" + safe + ".zip")
        return try {
            out.outputStream().use { Zip.write(it, entries) }
            if (safe.startsWith("auto")) prune(g)
            out
        } catch (t: Throwable) {
            AppLog.e("vault", "backup failed", t)
            out.delete()
            null
        }
    }

    private fun prune(g: Game) {
        val keep = Prefs.backupKeep.coerceAtLeast(1)
        val autos = backups(g).filter { it.label.startsWith("auto") }
        if (autos.size > keep) autos.drop(keep).forEach { it.file.delete() }
    }

    fun backups(g: Game): List<Backup> {
        val list = Paths.backupDir(g.id).listFiles { f -> f.isFile && f.name.endsWith(".zip") } ?: return emptyList()
        return list.map {
            val base = it.nameWithoutExtension
            val label = if (base.contains('_')) base.substringAfter('_') else base
            Backup(it, label, it.lastModified(), it.length())
        }.sortedByDescending { it.created }
    }

    fun deleteBackup(b: Backup) {
        b.file.delete()
    }

    /** Backs up when saves changed since the newest backup. Used before/after play sessions. */
    fun autoBackup(g: Game, reason: String) {
        if (!Prefs.autoBackup) return
        try {
            val newestSave = entriesFor(g).maxOfOrNull { it.first.lastModified() } ?: return
            val newestBackup = backups(g).firstOrNull()?.created ?: 0L
            if (newestSave > newestBackup) backup(g, "auto-$reason")
        } catch (t: Throwable) {
            AppLog.w("vault", "auto backup skipped", t)
        }
    }

    // ---------- restore / import / export ----------

    @Synchronized
    fun restore(g: Game, backup: File): Boolean {
        return try {
            backup(g, "auto-before-restore")
            backup.inputStream().use { applyArchive(g, it, clearLive = true) } > 0
        } catch (t: Throwable) {
            AppLog.e("vault", "restore failed", t)
            false
        }
    }

    fun export(g: Game, out: OutputStream) {
        Zip.write(out, entriesFor(g))
    }

    @Synchronized
    fun importArchive(g: Game, input: InputStream): Int {
        backup(g, "auto-before-import")
        return applyArchive(g, input, clearLive = false)
    }

    private fun applyArchive(g: Game, input: InputStream, clearLive: Boolean): Int {
        val live = liveDir(g)
        if (clearLive) clearDir(live)
        var n = 0
        ZipInputStream(input.buffered()).use { zin ->
            val buf = ByteArray(64 * 1024)
            var e = zin.nextEntry
            while (e != null) {
                if (!e.isDirectory) {
                    val name = e.name.replace('\\', '/')
                    var target: File? = null
                    if (name.startsWith(LIVE)) {
                        target = Zip.safeChild(live, name.substring(LIVE.length))
                    } else if (name.startsWith(LEGACY)) {
                        val leaf = name.substring(LEGACY.length)
                        if (g.format.isRgss && !leaf.contains('/') && isLegacySaveName(leaf)) target = Zip.safeChild(g.dir, leaf)
                    } else {
                        target = Zip.safeChild(live, name)
                    }
                    if (target != null) {
                        try {
                            target.parentFile?.mkdirs()
                            target.outputStream().use { out ->
                                while (true) {
                                    val r = zin.read(buf)
                                    if (r < 0) break
                                    out.write(buf, 0, r)
                                }
                            }
                            n++
                        } catch (t: Throwable) {
                            AppLog.w("vault", "could not write ${target.name}", t)
                        }
                    }
                }
                zin.closeEntry()
                e = zin.nextEntry
            }
        }
        return n
    }

    /** First launch with save redirection: copy saves that sit in the game folder into the live folder. */
    fun migrateLegacy(g: Game): Int {
        val live = liveDir(g)
        val marker = File(live, ".migrated")
        if (marker.exists()) return 0
        var n = 0
        val has = live.listFiles()?.any { !it.name.startsWith(".") } ?: false
        if (!has) {
            for (f in legacyFiles(g)) {
                try {
                    f.copyTo(File(live, f.name), true)
                    n++
                } catch (t: Throwable) {
                    AppLog.w("vault", "migrate ${f.name} failed", t)
                }
            }
        }
        try {
            marker.writeText(Fmt.stamp())
        } catch (ignored: Throwable) {
        }
        return n
    }

    // ---------- slots ----------

    private fun slotsFile(g: Game) = File(Paths.slotDir(g.id), "slots.json")

    private fun loadSlots(g: Game): Pair<String, MutableList<JSONObject>> {
        val f = slotsFile(g)
        try {
            if (f.exists()) {
                val root = JSONObject(f.readText())
                val arr = root.getJSONArray("slots")
                val list = ArrayList<JSONObject>()
                for (i in 0 until arr.length()) list.add(arr.getJSONObject(i))
                if (list.isNotEmpty()) return Pair(root.optString("active", "main"), list)
            }
        } catch (t: Throwable) {
            AppLog.w("vault", "slots.json unreadable", t)
        }
        val main = JSONObject().put("id", "main").put("name", "Main").put("created", System.currentTimeMillis())
        return Pair("main", arrayListOf(main))
    }

    private fun saveSlots(g: Game, active: String, list: List<JSONObject>) {
        val arr = JSONArray()
        for (o in list) arr.put(o)
        slotsFile(g).writeText(JSONObject().put("active", active).put("slots", arr).toString())
    }

    private fun slotData(g: Game, id: String) = File(Paths.slotDir(g.id), id)

    fun slots(g: Game): List<Slot> {
        val (active, list) = loadSlots(g)
        return list.map { o ->
            val id = o.getString("id")
            val dir = if (id == active) liveDir(g) else slotData(g, id)
            val tree = Zip.listTree(dir).filter { !it.second.startsWith(".") }
            Slot(id, o.optString("name", id), o.optLong("created"), id == active, tree.size, tree.sumOf { it.first.length() })
        }
    }

    @Synchronized
    fun createSlot(g: Game, name: String, copyCurrent: Boolean): Slot {
        val (active, list) = loadSlots(g)
        val id = "s" + UUID.randomUUID().toString().substring(0, 6)
        val dir = slotData(g, id)
        dir.mkdirs()
        if (copyCurrent) Files.copyRecursive(liveDir(g), dir)
        val now = System.currentTimeMillis()
        list.add(JSONObject().put("id", id).put("name", name.ifBlank { "Slot" }).put("created", now))
        saveSlots(g, active, list)
        return Slot(id, name, now, false, 0, 0)
    }

    @Synchronized
    fun switchSlot(g: Game, targetId: String): Boolean {
        val (active, list) = loadSlots(g)
        if (targetId == active || list.none { it.getString("id") == targetId }) return false
        return try {
            backup(g, "auto-before-switch")
            val live = liveDir(g)
            val outDir = slotData(g, active)
            Files.deleteRecursive(outDir)
            outDir.mkdirs()
            Files.copyRecursive(live, outDir)
            clearDir(live)
            val src = slotData(g, targetId)
            if (src.exists()) Files.copyRecursive(src, live)
            saveSlots(g, targetId, list)
            true
        } catch (t: Throwable) {
            AppLog.e("vault", "slot switch failed", t)
            false
        }
    }

    fun renameSlot(g: Game, id: String, name: String) {
        val (active, list) = loadSlots(g)
        list.firstOrNull { it.getString("id") == id }?.put("name", name.ifBlank { "Slot" })
        saveSlots(g, active, list)
    }

    @Synchronized
    fun deleteSlot(g: Game, id: String): Boolean {
        val (active, list) = loadSlots(g)
        if (id == active) return false
        list.removeAll { it.getString("id") == id }
        Files.deleteRecursive(slotData(g, id))
        saveSlots(g, active, list)
        return true
    }
}
