package dev.splice.player.engine

import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * Native side of the NW.js compatibility shim. JavaScript sees a virtual file system rooted at
 * /game: reads come from the game folder, and everything under /game/save/ is stored in Splice's
 * save vault for this game (so MV/MZ saves can be backed up, exported and switched).
 * Writes anywhere else are refused.
 */
class NwBridge(
    private val gameRoot: File,
    private val saveDir: File,
    private val onQuit: () -> Unit,
    private val onLog: (String, String) -> Unit
) {
    private val maxRead = 48L * 1024 * 1024

    private fun segments(path: String): List<String>? {
        val p = path.replace('\\', '/')
        if (p != "/game" && !p.startsWith("/game/")) return null
        val segs = ArrayList<String>()
        for (s in p.substring(5).split('/')) {
            when (s) {
                "", "." -> {}
                ".." -> {
                    if (segs.isEmpty()) return null
                    segs.removeAt(segs.size - 1)
                }
                else -> segs.add(s)
            }
        }
        return segs
    }

    private fun isSave(segs: List<String>) = segs.isNotEmpty() && segs[0].equals("save", ignoreCase = true)

    private fun child(dir: File, name: String): File? {
        val direct = File(dir, name)
        if (direct.exists()) return direct
        val list = dir.listFiles() ?: return null
        for (f in list) if (f.name.equals(name, ignoreCase = true)) return f
        return null
    }

    private fun resolve(path: String, write: Boolean): File? {
        val segs = segments(path) ?: return null
        if (isSave(segs)) {
            var cur = saveDir
            for (s in segs.drop(1)) cur = File(cur, s)
            return cur
        }
        if (write) return null
        var cur = gameRoot
        for (s in segs) cur = child(cur, s) ?: return null
        return cur
    }

    @JavascriptInterface
    fun exists(path: String): Boolean = try {
        resolve(path, false)?.exists() ?: false
    } catch (t: Throwable) {
        false
    }

    @JavascriptInterface
    fun readText(path: String): String? {
        return try {
            val f = resolve(path, false) ?: return null
            if (!f.isFile || f.length() > maxRead) null else String(f.readBytes(), Charsets.UTF_8)
        } catch (t: Throwable) {
            null
        }
    }

    @JavascriptInterface
    fun readBase64(path: String): String? {
        return try {
            val f = resolve(path, false) ?: return null
            if (!f.isFile || f.length() > maxRead) null else Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
        } catch (t: Throwable) {
            null
        }
    }

    private fun writeBytes(f: File, bytes: ByteArray): Boolean {
        return try {
            f.parentFile?.mkdirs()
            val tmp = File(f.path + ".tmp")
            tmp.writeBytes(bytes)
            if (!tmp.renameTo(f)) {
                f.delete()
                tmp.renameTo(f)
            }
            true
        } catch (t: Throwable) {
            onLog("E", "fs write failed: ${t.message}")
            false
        }
    }

    @JavascriptInterface
    fun writeText(path: String, data: String): Boolean {
        val f = resolve(path, true) ?: return false
        return writeBytes(f, data.toByteArray(Charsets.UTF_8))
    }

    @JavascriptInterface
    fun writeBase64(path: String, b64: String): Boolean {
        val f = resolve(path, true) ?: return false
        return try {
            writeBytes(f, Base64.decode(b64, Base64.DEFAULT))
        } catch (t: Throwable) {
            false
        }
    }

    @JavascriptInterface
    fun mkdir(path: String): Boolean = try {
        val f = resolve(path, true)
        f != null && (f.isDirectory || f.mkdirs())
    } catch (t: Throwable) {
        false
    }

    @JavascriptInterface
    fun unlink(path: String): Boolean = try {
        val f = resolve(path, true)
        f != null && f.exists() && f.delete()
    } catch (t: Throwable) {
        false
    }

    @JavascriptInterface
    fun rename(from: String, to: String): Boolean = try {
        val a = resolve(from, true)
        val b = resolve(to, true)
        if (a == null || b == null || !a.exists()) {
            false
        } else {
            b.parentFile?.mkdirs()
            if (b.exists()) b.delete()
            a.renameTo(b)
        }
    } catch (t: Throwable) {
        false
    }

    @JavascriptInterface
    fun readdir(path: String): String {
        return try {
            val f = resolve(path, false)
            val names = f?.list()
            if (names == null) "null" else JSONArray(names.sorted()).toString()
        } catch (t: Throwable) {
            "null"
        }
    }

    @JavascriptInterface
    fun stat(path: String): String {
        return try {
            val f = resolve(path, false)
            if (f == null || !f.exists()) {
                "null"
            } else {
                JSONObject().put("isFile", f.isFile).put("isDir", f.isDirectory)
                    .put("size", f.length()).put("mtime", f.lastModified()).toString()
            }
        } catch (t: Throwable) {
            "null"
        }
    }

    @JavascriptInterface
    fun log(level: String, msg: String) {
        onLog(level.uppercase(Locale.ROOT), msg)
    }

    @JavascriptInterface
    fun quit() {
        onQuit()
    }
}
