#!/usr/bin/env python3
"""Generates the Splice line-icon set (vector drawables) and the launcher icon.
Every icon is built from simple primitives on a 24x24 grid, 2px round stroke.
A small path validator checks the syntax so a typo can never reach aapt2."""
import os, re, sys

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app', 'src', 'main', 'res')
DRAW = os.path.join(OUT, 'drawable')
os.makedirs(DRAW, exist_ok=True)

ARITY = {'M': 2, 'L': 2, 'H': 1, 'V': 1, 'C': 6, 'S': 4, 'Q': 4, 'T': 2, 'A': 7, 'Z': 0}

def validate(d, name):
    toks = re.findall(r'[MLHVCSQTAZmlhvcsqtaz]|-?\d*\.?\d+(?:[eE][-+]?\d+)?', d)
    assert toks, name
    i = 0
    cmd = None
    while i < len(toks):
        t = toks[i]
        if re.match(r'[A-Za-z]', t):
            cmd = t
            i += 1
            if cmd.upper() == 'Z':
                continue
        else:
            assert cmd is not None, (name, 'number before command')
        n = ARITY[cmd.upper()]
        if n == 0:
            continue
        args = toks[i:i + n]
        assert len(args) == n and all(not re.match(r'[A-Za-z]', a) for a in args), (name, cmd, args)
        if cmd.upper() == 'A':
            assert args[3] in ('0', '1') and args[4] in ('0', '1'), (name, 'arc flags', args)
        i += n

def rrect(x, y, w, h, r):
    return (f'M{x+r},{y} H{x+w-r} A{r},{r} 0 0 1 {x+w},{y+r} V{y+h-r} A{r},{r} 0 0 1 {x+w-r},{y+h} '
            f'H{x+r} A{r},{r} 0 0 1 {x},{y+h-r} V{y+r} A{r},{r} 0 0 1 {x+r},{y} Z')

def circle(cx, cy, r):
    return f'M{cx+r},{cy} A{r},{r} 0 1 1 {cx-r},{cy} A{r},{r} 0 1 1 {cx+r},{cy} Z'

# name -> list of (pathData, filled?)  stroke icons unless filled
ICONS = {
    'library': [(rrect(3, 3, 7, 7, 2), 0), (rrect(14, 3, 7, 7, 2), 0), (rrect(3, 14, 7, 7, 2), 0), (rrect(14, 14, 7, 7, 2), 0)],
    'saves': [('M5,3 H16 L21,8 V19 A2,2 0 0 1 19,21 H5 A2,2 0 0 1 3,19 V5 A2,2 0 0 1 5,3 Z', 0),
              ('M7,3 V8 H15 V3', 0), ('M7,21 V14 H17 V21', 0)],
    'logs': [('M14,2 H6 A2,2 0 0 0 4,4 V20 A2,2 0 0 0 6,22 H18 A2,2 0 0 0 20,20 V8 Z', 0),
             ('M14,2 V8 H20', 0), ('M8,13 H16 M8,17 H16', 0)],
    'settings': [('M4,6 H7 M11,6 H20', 0), (circle(9, 6, 2), 0), ('M4,12 H13 M17,12 H20', 0), (circle(15, 12, 2), 0),
                 ('M4,18 H6 M10,18 H20', 0), (circle(8, 18, 2), 0)],
    'play': [('M7,4.5 L19,12 L7,19.5 Z', 1)],
    'add': [('M12,5 V19 M5,12 H19', 0)],
    'close': [('M6,6 L18,18 M18,6 L6,18', 0)],
    'back': [('M19,12 H5 M11,6 L5,12 L11,18', 0)],
    'search': [(circle(10.5, 10.5, 5.5), 0), ('M14.8,14.8 L20,20', 0)],
    'folder': [('M3,7 A2,2 0 0 1 5,5 H9 L11,7 H19 A2,2 0 0 1 21,9 V17 A2,2 0 0 1 19,19 H5 A2,2 0 0 1 3,17 Z', 0)],
    'zip': [('M3,5 H21 V9 H3 Z', 0), ('M5,9 V19 A1,1 0 0 0 6,20 H18 A1,1 0 0 0 19,19 V9', 0), ('M10,13 H14', 0)],
    'gamepad': [('M7,7 H17 A5,5 0 0 1 22,12 A5,5 0 0 1 17,17 H7 A5,5 0 0 1 2,12 A5,5 0 0 1 7,7 Z', 0),
                ('M7,10 V14 M5,12 H9', 0), ('M16,11 H16.01 M18.5,13 H18.51', 0)],
    'trash': [('M4,7 H20 M10,11 V17 M14,11 V17', 0), ('M5,7 L6,19 A2,2 0 0 0 8,21 H16 A2,2 0 0 0 18,19 L19,7', 0),
              ('M9,7 V4 A1,1 0 0 1 10,3 H14 A1,1 0 0 1 15,4 V7', 0)],
    'export': [('M12,15 V4 M7,9 L12,4 L17,9', 0), ('M5,15 V19 A1,1 0 0 0 6,20 H18 A1,1 0 0 0 19,19 V15', 0)],
    'import': [('M12,4 V15 M7,10 L12,15 L17,10', 0), ('M5,15 V19 A1,1 0 0 0 6,20 H18 A1,1 0 0 0 19,19 V15', 0)],
    'check': [('M5,12.5 L10,17.5 L19,7', 0)],
    'warning': [('M12,3.5 L22,20 H2 Z', 0), ('M12,10 V14 M12,17.2 V17.21', 0)],
    'bug': [('M9,9 V8 A3,3 0 0 1 15,8 V9', 0), ('M7,9 H17 V15 A5,5 0 0 1 7,15 Z', 0), ('M12,10 V20', 0),
            ('M3,13 H7 M17,13 H21 M4,6.5 L8,9.5 M20,6.5 L16,9.5 M4,19.5 L8.2,16.5 M20,19.5 L15.8,16.5', 0)],
    'speed': [('M4,17 A9,9 0 1 1 20,17', 0), ('M12,13 L16,8', 0), ('M12,13 H12.01', 0)],
    'display': [('M4,5 H20 A1,1 0 0 1 21,6 V15 A1,1 0 0 1 20,16 H4 A1,1 0 0 1 3,15 V6 A1,1 0 0 1 4,5 Z', 0),
                ('M9,20 H15 M12,16 V20', 0)],
    'sound': [('M4,10 V14 H8 L13,18 V6 L8,10 Z', 0), ('M16,9 A4,4 0 0 1 16,15', 0), ('M18.5,6.5 A8,8 0 0 1 18.5,17.5', 0)],
    'shield': [('M12,3 L20,6 V12 C20,16.5 16.5,20 12,21 C7.5,20 4,16.5 4,12 V6 Z', 0), ('M9,12 L11,14 L15,10', 0)],
    'star': [('M12,3 L14.6,9 L21,9.6 L16.2,13.8 L17.6,20.2 L12,16.9 L6.4,20.2 L7.8,13.8 L3,9.6 L9.4,9 Z', 0)],
    'star_fill': [('M12,3 L14.6,9 L21,9.6 L16.2,13.8 L17.6,20.2 L12,16.9 L6.4,20.2 L7.8,13.8 L3,9.6 L9.4,9 Z', 1)],
    'more': [('M12,6 H12.01 M12,12 H12.01 M12,18 H12.01', 0)],
    'refresh': [('M20,12 A8,8 0 1 1 17.66,6.34', 0), ('M20,4 V8.5 H15.5', 0)],
    'copy': [(rrect(9, 9, 11, 11, 2), 0), ('M5,15 V6 A2,2 0 0 1 7,4 H15', 0)],
    'info': [(circle(12, 12, 9), 0), ('M12,11 V16 M12,8 V8.01', 0)],
    'chip': [('M7,7 H17 V17 H7 Z', 0), ('M10,10 H14 V14 H10 Z', 0), ('M9,3 V7 M15,3 V7 M9,17 V21 M15,17 V21 M3,9 H7 M3,15 H7 M17,9 H21 M17,15 H21', 0)],
    'chevron_right': [('M9,6 L15,12 L9,18', 0)],
    'chevron_down': [('M6,9 L12,15 L18,9', 0)],
    'filter': [('M3,6 H21 M6,12 H18 M10,18 H14', 0)],
    'clock': [(circle(12, 12, 9), 0), ('M12,7 V12 L15.5,14', 0)],
    'layers': [('M12,3 L21,8 L12,13 L3,8 Z', 0), ('M3,12 L12,17 L21,12 M3,16 L12,21 L21,16', 0)],
    'menu': [('M4,7 H20 M4,12 H20 M4,17 H20', 0)],
    'pencil': [('M4,20 L5,15 L16,4 A2.1,2.1 0 0 1 20,8 L9,19 Z', 0), ('M14,6 L18,10', 0)],
    'image': [(rrect(3, 4, 18, 16, 2), 0), (circle(9, 10, 1.5), 0), ('M21,16 L16,11 L7,20', 0)],
    'eye_off': [('M3,3 L21,21', 0), ('M10.6,6.2 A9.5,9.5 0 0 1 12,6 C17,6 20.5,10.5 21.5,12 A15,15 0 0 1 19.3,14.7 M6.6,7.6 A15,15 0 0 0 2.5,12 C3.5,13.5 7,18 12,18 A9,9 0 0 0 14.6,17.6', 0)],
    'plug': [('M9,3 V8 M15,3 V8', 0), ('M6,8 H18 V12 A6,6 0 0 1 6,12 Z', 0), ('M12,18 V21', 0)],
}

def write_icon(name, shapes):
    parts = []
    for d, filled in shapes:
        validate(d, name)
        if filled:
            parts.append(f'    <path\n        android:fillColor="#FFFFFFFF"\n        android:pathData="{d}"/>')
        else:
            parts.append(f'    <path\n        android:fillColor="#00000000"\n        android:pathData="{d}"\n'
                         f'        android:strokeColor="#FFFFFFFF"\n        android:strokeWidth="2"\n'
                         f'        android:strokeLineCap="round"\n        android:strokeLineJoin="round"/>')
    xml = ('<?xml version="1.0" encoding="utf-8"?>\n'
           '<vector xmlns:android="http://schemas.android.com/apk/res/android"\n'
           '    android:width="24dp"\n    android:height="24dp"\n    android:viewportWidth="24"\n'
           '    android:viewportHeight="24">\n' + '\n'.join(parts) + '\n</vector>\n')
    with open(os.path.join(DRAW, f'ic_{name}.xml'), 'w') as f:
        f.write(xml)

for n, s in ICONS.items():
    write_icon(n, s)

# Launcher foreground: two offset triangles ("splice"), kept inside the adaptive-icon safe zone.
MINT, PEACH = '#FF5BE3C4', '#FFFFA98A'
fg = f'''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="{MINT}"
        android:pathData="M32,32 L68,32 L32,68 Z"/>
    <path
        android:fillColor="{PEACH}"
        android:pathData="M76,40 L76,76 L40,76 Z"/>
</vector>
'''
validate('M32,32 L68,32 L32,68 Z', 'fg1'); validate('M76,40 L76,76 L40,76 Z', 'fg2')
with open(os.path.join(DRAW, 'ic_launcher_fg.xml'), 'w') as f:
    f.write(fg)

# Themed (monochrome) layer for Android 13+
mono = '''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="#FF000000"
        android:pathData="M32,32 L68,32 L32,68 Z M76,40 L76,76 L40,76 Z"/>
</vector>
'''
with open(os.path.join(DRAW, 'ic_launcher_mono.xml'), 'w') as f:
    f.write(mono)

adaptive = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_bg"/>
    <foreground android:drawable="@drawable/ic_launcher_fg"/>
    <monochrome android:drawable="@drawable/ic_launcher_mono"/>
</adaptive-icon>
'''
os.makedirs(os.path.join(OUT, 'mipmap-anydpi-v26'), exist_ok=True)
for nm in ('ic_launcher', 'ic_launcher_round'):
    with open(os.path.join(OUT, 'mipmap-anydpi-v26', nm + '.xml'), 'w') as f:
        f.write(adaptive)

# Legacy PNG launcher icons (API 24/25)
from PIL import Image, ImageDraw
def make_png(size, round_):
    S = size * 4
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    bg = (0x14, 0x12, 0x1D, 255)
    if round_:
        dr.ellipse([0, 0, S - 1, S - 1], fill=bg)
    else:
        dr.rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * 0.22), fill=bg)
    k = S / 108.0
    dr.polygon([(32 * k, 32 * k), (68 * k, 32 * k), (32 * k, 68 * k)], fill=(0x5B, 0xE3, 0xC4, 255))
    dr.polygon([(76 * k, 40 * k), (76 * k, 76 * k), (40 * k, 76 * k)], fill=(0xFF, 0xA9, 0x8A, 255))
    return im.resize((size, size), Image.LANCZOS)

for dens, px in (('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)):
    d = os.path.join(OUT, 'mipmap-' + dens)
    os.makedirs(d, exist_ok=True)
    make_png(px, False).save(os.path.join(d, 'ic_launcher.png'), optimize=True)
    make_png(px, True).save(os.path.join(d, 'ic_launcher_round.png'), optimize=True)

print('icons:', len(ICONS), 'generated')
