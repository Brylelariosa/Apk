#!/usr/bin/env python3
"""Condenses a Gradle / make log into a few lines for the in-app engine status.

usage: gradle_summary.py LOG [--max-chars N] [--failed-task]

  (default)       print a short, human-readable summary of why the build failed
  --failed-task   print only the name of the first failing Gradle task

Never raises: a missing or unreadable log simply produces no output.
"""
import argparse
import re
import sys

MAX_LINE = 220
ANSI = re.compile(r'\x1b\[[0-9;?]*[A-Za-z]')
FAILED_TASK = re.compile(r"Execution failed for task '([^']+)'")
# Lines that usually name the real cause of a native / dependency / toolchain failure.
CAUSE = re.compile(
    r'(fatal error:|\berror:|undefined reference|undefined symbol|No rule to make target|'
    r'cannot find -l|ld(?:\.lld)?: error|Could not resolve|Could not find |'
    r'Unsupported class file|Unsupported Java|SDK location not found|No space left)',
    re.I,
)


def clean(line):
    """Strips colour codes and the machine-specific part of paths."""
    line = ANSI.sub('', line).strip()
    line = re.sub(r'(?:/[\w.+@~-]+)+/build-engine-work/engine/', 'engine/', line)
    line = re.sub(r'/home/runner/work/[^/\s]+/[^/\s]+/', './', line)
    return line


def read_lines(path):
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            return [clean(line) for line in f]
    except OSError:
        return []


def failed_task(lines):
    for line in lines:
        m = FAILED_TASK.search(line)
        if m:
            return m.group(1)
    return ''


def what_went_wrong(lines):
    """The body of Gradle's '* What went wrong:' block (first one only)."""
    for i, line in enumerate(lines):
        if line.startswith('* What went wrong:'):
            body = []
            for nxt in lines[i + 1:]:
                if nxt.startswith('* '):  # '* Try:', '* Exception is:', ...
                    break
                if nxt:
                    body.append(nxt)
            return body
    return []


def cause_lines(lines, exclude, limit):
    seen, found = set(), []
    for line in lines:
        if line and CAUSE.search(line) and line not in exclude and line not in seen:
            seen.add(line)
            found.append(line)
            if len(found) == limit:
                break
    return found


def shorten(line):
    return line if len(line) <= MAX_LINE else line[:MAX_LINE - 1] + '\u2026'


def summarize(lines, max_chars):
    task = failed_task(lines)
    wrong = [w for w in what_went_wrong(lines) if not FAILED_TASK.search(w)]
    parts = []
    if task:
        parts.append('Failed task: ' + task)
    parts.extend(cause_lines(lines, set(wrong), 3))   # root cause first
    parts.extend(wrong[:3])
    if not parts:                                    # nothing recognisable: show the tail
        parts = [line for line in lines if line][-4:]
    out, used = [], 0
    for line in dict.fromkeys(shorten(p) for p in parts):  # de-duplicate, keep order
        if used + len(line) + 1 > max_chars:
            out.append('\u2026')
            break
        out.append(line)
        used += len(line) + 1
    return '\n'.join(out)


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('log')
    ap.add_argument('--max-chars', type=int, default=900)
    ap.add_argument('--failed-task', action='store_true')
    args = ap.parse_args(argv)
    lines = read_lines(args.log)
    if not lines:
        return 0
    text = failed_task(lines) if args.failed_task else summarize(lines, args.max_chars)
    if text:
        print(text)
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except Exception:  # a summary must never be the reason something fails
        sys.exit(0)
