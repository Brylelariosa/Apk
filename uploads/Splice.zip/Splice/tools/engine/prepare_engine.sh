#!/usr/bin/env bash
# Optional RGSS engine (RPG Maker XP / VX / VX Ace) for Splice.
#
# Builds the open-source mkxp-z Android port (https://github.com/BookerRues9/mkxp-z-android-reworked)
# with the same recipe its own CI uses, then harvests the result into the Gradle library module
# ./rgss-engine and generates the activity that connects it to Splice's UI.
#
# Called from ./gradlew before Gradle starts. It NEVER fails the build: on any problem it records
# the reason (shown in Settings > Engines) and exits 0, so you still get an APK with MV/MZ support.
#
# Stages, one function each (see main at the bottom):
#   preconditions -> payload cache -> host tools -> Ruby -> NDK
#   -> engine sources + native dependencies (or the checkpoint of an earlier run)
#   -> adapt the engine build (one ABI) -> engine APK -> harvest -> cache
#
# Helpers in this folder:
#   patch_engine.py     makes the engine's own Gradle build target arm64-v8a only
#   engine-init.gradle  Gradle init script for the engine build (one ABI, no lint, optimised native code)
#   gradle_summary.py   turns a failed build log into the few lines shown in Settings > Engines
#   harvest.py          copies the native libraries, Java and resources into ./rgss-engine
#
# Environment:
#   SPLICE_SKIP_ENGINE=1           skip the engine entirely (or create a file named engine.disabled)
#   SPLICE_ENGINE_REF=<sha>        engine commit to build (default pinned below)
#   SPLICE_ENGINE_REPO=<url>       engine repository
#   SPLICE_ENGINE_NO_CHECKPOINT=1  do not keep the built dependencies for a retry (save_deps_checkpoint)
#
# Output is cached inside app/.cxx (which the CI workflow caches), so only the first run is slow.
set -uo pipefail

# ---- configuration -----------------------------------------------------------------------------
ROOT="${1:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
TOOLS="$ROOT/tools/engine"
ENGINE_DIR="$ROOT/rgss-engine"
GEN_DIR="$ROOT/app/src/rgss"
ASSETS_DIR="$ROOT/app/src/main/assets"
PRO_FILE="$ROOT/app/proguard-engine.pro"
CACHE_DIR="$ROOT/app/.cxx/splice-engine"
WORK="${SPLICE_ENGINE_WORK:-$ROOT/build-engine-work}"
ENG="$WORK/engine"
REPO="${SPLICE_ENGINE_REPO:-https://github.com/BookerRues9/mkxp-z-android-reworked.git}"
REF="${SPLICE_ENGINE_REF:-b668e08cb58edf661d56fd4d396036ac31cd8332}"
NDK_VER="${SPLICE_ENGINE_NDK:-23.2.8568313}"
# One ABI only. TARGET_HOST is the matching toolchain triple of the dependency build.
TARGET_ABI="arm64-v8a"
TARGET_HOST="aarch64-linux-android"
SCHEMA="2"
KEY="$SCHEMA|$REPO|$REF|$NDK_VER"
STARTED=$(date +%s)
SUDO=""
if [ "$(id -u)" != "0" ] && command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi

# State shared between the stages.
SDK=""; NDK=""
REV_ACTUAL="$REF"
ENGINE_VARIANT=""      # release | debug: which engine build the libraries came from
ENGINE_FAILURE=""      # short summary of the last failed Gradle build
LAST_LOG=""; LAST_RC=0
OPTIMIZE_NATIVE=0      # 1 = keep native code optimised even in a debug build

# ---- reporting ---------------------------------------------------------------------------------
log() { echo "[splice-engine] $*"; }
set_status() { mkdir -p "$ASSETS_DIR"; printf '%s\n' "$1" > "$ASSETS_DIR/engine_status.txt"; }
clean_outputs() { rm -rf "$ENGINE_DIR/READY" "$ENGINE_DIR/engine.properties" "$ENGINE_DIR/src" "$GEN_DIR" "$PRO_FILE"; }
elapsed() { echo $(( $(date +%s) - STARTED )); }
summarize() { python3 "$TOOLS/gradle_summary.py" "$@" 2>/dev/null || true; }

# fail "<reason>" ["<detail lines>"] - records why there is no engine (shown in Settings) and ends the step.
fail() {
    local reason="$1" detail="${2:-}" text
    log "FAILED: $reason"
    [ -n "$detail" ] && printf '%s\n' "$detail" | sed 's/^/[splice-engine]   /'
    clean_outputs
    text="RGSS engine was not built: $reason"
    [ -n "$detail" ] && text="$text"$'\n'"$detail"
    set_status "$text"
    exit 0
}
skip() { log "skipped: $*"; clean_outputs; set_status "RGSS engine skipped: $*"; exit 0; }

# ---- preconditions and cache -------------------------------------------------------------------
check_preconditions() {
    [ "${SPLICE_SKIP_ENGINE:-0}" = "1" ] && skip "SPLICE_SKIP_ENGINE=1"
    [ -f "$ROOT/engine.disabled" ] && skip "engine.disabled file present"
    if [ "$(uname -s)" != "Linux" ] || [ "$(uname -m)" != "x86_64" ]; then skip "needs a Linux x86_64 build host"; fi
    SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
    [ -n "$SDK" ] && [ -d "$SDK" ] || skip "Android SDK not found (ANDROID_HOME)"
}

# The finished engine (harvested libraries, Java, resources) from an earlier successful run. 0 = restored.
restore_payload_cache() {
    local payload="$CACHE_DIR/payload.tar"
    [ -f "$payload" ] && [ -f "$CACHE_DIR/KEY" ] && [ "$(cat "$CACHE_DIR/KEY")" = "$KEY" ] || return 1
    clean_outputs
    if tar -xf "$payload" -C "$ROOT" 2>/dev/null && [ -f "$ENGINE_DIR/READY" ]; then
        log "restored the RGSS engine from cache ($(du -sh "$payload" | cut -f1))"
        return 0
    fi
    log "cache payload unusable, rebuilding"
    clean_outputs
    return 1
}

cache_payload() {
    local payload="$CACHE_DIR/payload.tar"
    mkdir -p "$CACHE_DIR"
    if tar -cf "$payload" -C "$ROOT" rgss-engine/src rgss-engine/engine.properties rgss-engine/READY \
            app/src/rgss app/proguard-engine.pro app/src/main/assets/engine_status.txt 2>/dev/null; then
        printf '%s' "$KEY" > "$CACHE_DIR/KEY"
        log "cached engine payload ($(du -sh "$payload" | cut -f1))"
    fi
}

# The slow part (native dependencies) is kept so that a failure in the LATER Gradle step does not cost
# another full dependency build on the next run. It lives next to the payload (app/.cxx is cached by
# the CI workflow) and is deleted as soon as the engine has been built successfully.
deps_checkpoint_enabled() { [ "${SPLICE_ENGINE_NO_CHECKPOINT:-0}" != "1" ]; }

save_deps_checkpoint() {
    deps_checkpoint_enabled || return 0
    local archive="$CACHE_DIR/deps.tar"
    mkdir -p "$CACHE_DIR"
    rm -f "$archive" "$CACHE_DIR/DEPS_KEY"
    if tar --exclude=.git -cf "$archive" -C "$WORK" engine 2>/dev/null; then
        printf '%s' "$KEY" > "$CACHE_DIR/DEPS_KEY"
        log "kept the built dependencies for a retry ($(du -sh "$archive" | cut -f1))"
    else
        rm -f "$archive"
        log "could not keep the built dependencies (continuing)"
    fi
}

restore_deps_checkpoint() {   # 0 = $ENG now holds the sources with the dependencies already built
    deps_checkpoint_enabled || return 1
    local archive="$CACHE_DIR/deps.tar"
    [ -f "$archive" ] && [ -f "$CACHE_DIR/DEPS_KEY" ] && [ "$(cat "$CACHE_DIR/DEPS_KEY")" = "$KEY" ] || return 1
    rm -rf "$ENG"
    if tar -xf "$archive" -C "$WORK" 2>/dev/null && [ -d "$ENG/app/jni" ]; then
        REV_ACTUAL=$(cat "$ENG/.splice-revision" 2>/dev/null || echo "$REF")
        log "restored the built native dependencies from an earlier run"
        return 0
    fi
    rm -rf "$ENG"
    return 1
}

drop_deps_checkpoint() { rm -f "$CACHE_DIR/deps.tar" "$CACHE_DIR/DEPS_KEY"; }

# ---- host tools --------------------------------------------------------------------------------
install_host_tools() {
    if command -v apt-get >/dev/null 2>&1; then
        log "installing host build tools"
        $SUDO apt-get update -y >/dev/null 2>&1 || true
        $SUDO env DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
            build-essential cmake curl gpg xxd ruby-full autoconf automake libtool pkg-config \
            python3 git unzip gperf gettext autopoint nasm >/dev/null 2>&1 || log "apt-get reported problems (continuing)"
    fi
    local t
    for t in git make python3 curl unzip xxd; do
        command -v "$t" >/dev/null 2>&1 || fail "missing host tool: $t"
    done
}

# ---- Ruby --------------------------------------------------------------------------------------
# The engine's recipe uses a stock Ruby 3.1 as the build-time "baseruby" (its CI uses ruby/setup-ruby).
ruby_is_31() { "$1" -e 'exit(RUBY_VERSION.start_with?("3.1") ? 0 : 1)' >/dev/null 2>&1; }
use_ruby() { export PATH="$1/bin:$PATH"; log "using $(ruby -v 2>/dev/null)"; }

ensure_ruby31() {
    ruby_is_31 ruby && return 0
    local tool="${RUNNER_TOOL_CACHE:-/opt/hostedtoolcache}" r v osv url dest root
    # 1) a 3.1 that is already installed on the runner
    for r in "$tool"/Ruby/3.1.*/x64/bin/ruby; do
        if [ -x "$r" ] && ruby_is_31 "$r"; then use_ruby "${r%/bin/ruby}"; return 0; fi
    done
    # 2) the prebuilt toolcache build that ruby/setup-ruby downloads
    osv=$( . /etc/os-release 2>/dev/null; echo "${VERSION_ID:-22.04}" )
    for v in 3.1.7 3.1.6 3.1.4; do
        dest="$tool/Ruby/$v/x64"
        url="https://github.com/ruby/ruby-builder/releases/download/toolcache/ruby-$v-ubuntu-$osv.tar.gz"
        curl -fsSL --retry 2 --connect-timeout 20 "$url" -o "$WORK/ruby31.tgz" 2>/dev/null || continue
        # the archive may or may not carry the x64 folder itself
        tar -tzf "$WORK/ruby31.tgz" > "$WORK/ruby31.list" 2>/dev/null
        root="$dest"
        grep -qE '^(\./)?x64/' "$WORK/ruby31.list" && root="$(dirname "$dest")"
        mkdir -p "$root" 2>/dev/null || $SUDO mkdir -p "$root" || continue
        tar -xzf "$WORK/ruby31.tgz" -C "$root" 2>/dev/null || $SUDO tar -xzf "$WORK/ruby31.tgz" -C "$root" 2>/dev/null || continue
        if [ -x "$dest/bin/ruby" ] && ruby_is_31 "$dest/bin/ruby"; then use_ruby "$dest"; return 0; fi
    done
    log "Ruby 3.1 not available; using system Ruby: $(ruby -v 2>/dev/null || echo none)"
}

# Debian/Ubuntu patch RubyGems so that Gem.default_dir is /var/lib/gems/<ruby_version>. While the
# cross-compiled Ruby is installed, tool/rbinstall.rb then tries to write the *target's* default gems
# into the build host's /var/lib/gems and dies with Errno::EACCES. A stock Ruby (what the engine's CI
# has) writes them below the build prefix instead. The install runs with -I<ruby source>/lib in front of
# the host's own library path, so an empty operating_system.rb placed in the source tree shadows the
# distribution hook and restores the stock behaviour.
distro_rubygems_hook() {
    ruby -e 'begin; require "rubygems/defaults/operating_system"; rescue LoadError; exit 1; end' >/dev/null 2>&1
}
stock_rubygems() {   # $1 = Ruby source directory
    [ -d "$1/lib/rubygems" ] || return 0
    mkdir -p "$1/lib/rubygems/defaults" &&
        printf '# intentionally empty: bypasses the distribution RubyGems defaults while the engine is built\n' \
            > "$1/lib/rubygems/defaults/operating_system.rb"
}

# ---- NDK (the engine's recipe is pinned to r23) --------------------------------------------------
ensure_ndk() {
    NDK="$SDK/ndk/$NDK_VER"
    if [ ! -d "$NDK" ]; then
        local sm
        sm="$(command -v sdkmanager || true)"
        [ -z "$sm" ] && sm="$SDK/cmdline-tools/latest/bin/sdkmanager"
        [ -x "$sm" ] || fail "sdkmanager not found, cannot install NDK $NDK_VER"
        log "installing NDK $NDK_VER"
        yes 2>/dev/null | "$sm" --licenses >/dev/null 2>&1 || true
        "$sm" --install "ndk;$NDK_VER" >/dev/null 2>&1 || "$sm" --install "ndk;$NDK_VER" || fail "could not install NDK $NDK_VER"
    fi
    [ -d "$NDK" ] || fail "NDK $NDK_VER missing after install"
    export ANDROID_NDK_HOME="$NDK"
    export ARCH=linux-x86_64
    export PATH="$NDK/toolchains/llvm/prebuilt/$ARCH/bin:$PATH"
}

# ---- engine sources and native dependencies ----------------------------------------------------
fetch_engine() {
    rm -rf "$ENG"
    mkdir -p "$ENG"
    log "fetching $REPO @ ${REF:0:10}"
    (
        cd "$ENG" || exit 1
        git init -q . && git remote add origin "$REPO" || exit 1
        if ! git fetch -q --depth 1 origin "$REF" 2>/dev/null; then
            echo "[splice-engine] pinned revision not fetchable, using the default branch"
            git fetch -q --depth 1 origin HEAD || exit 1
        fi
        git checkout -q FETCH_HEAD || exit 1
        git submodule update --init --recursive --depth 1 -q || exit 1
    ) || return 1
    REV_ACTUAL=$(cd "$ENG" && git rev-parse HEAD 2>/dev/null || echo "$REF")
    printf '%s\n' "$REV_ACTUAL" > "$ENG/.splice-revision"
}

# The engine's own recipe (same as its CI): get_deps.sh, make_xxd.sh, then make for the target ABI.
build_native_deps() {
    log "building native dependencies for $TARGET_ABI (this is the slow part, once)"
    local rc
    (
        cd "$ENG/app/jni" || exit 1
        chmod +x get_deps.sh && ./get_deps.sh || exit 11
        ( cd mkxp-z && chmod +x make_xxd.sh && ./make_xxd.sh ) || exit 12
        if distro_rubygems_hook; then
            echo "[splice-engine] distribution RubyGems detected, using stock defaults for the Ruby install"
            stock_rubygems "$PWD/ruby"
        fi
        build_deps() {
            HOST="$TARGET_HOST" TARGET="$TARGET_HOST" ABI="$TARGET_ABI" \
                LDFLAGS="-Wl,-z,max-page-size=16384" timeout 30m make -j"$(nproc)"
        }
        if ! build_deps; then
            # Safety net: if rbinstall still asked for a folder below /var/lib/gems, create it for this user and retry
            # (make carries on from where it stopped).
            gemdir=$(grep -ao 'dir_s_mkdir - /var/lib/gems/[0-9.]*' "$WORK/deps.log" | tail -n 1 | sed 's/^dir_s_mkdir - //')
            [ -n "$gemdir" ] && $SUDO mkdir -p "$gemdir" && $SUDO chown -R "$(id -u):$(id -g)" "$gemdir" || exit 13
            echo "[splice-engine] retrying with a writable $gemdir"
            build_deps || exit 13
        fi
        if [ -d "build-$TARGET_ABI" ] && [ ! -e build-arm64 ]; then ln -s "build-$TARGET_ABI" build-arm64; fi
    ) > "$WORK/deps.log" 2>&1
    rc=$?
    if [ $rc -ne 0 ]; then
        tail -n 40 "$WORK/deps.log"
        fail "native dependency build failed (step code $rc)" "$(summarize "$WORK/deps.log")"
    fi
    log "dependencies built after $(elapsed)s"
}

# The engine app builds every ABI listed in its build.gradle; only $TARGET_ABI has dependencies here.
adapt_engine_build() {
    python3 "$TOOLS/patch_engine.py" "$ENG" "$TARGET_ABI" 2>&1 | sed 's/^/[splice-engine] /'
    return 0
}

# ---- engine APK (gives us the linked native libraries) -----------------------------------------
java_major() {   # $1 = java binary -> 8, 11, 17, 21 ...
    "$1" -version 2>&1 | awk -F'"' '/version/ { split($2, v, "."); n = (v[1] == "1") ? v[2] : v[1]; sub(/[^0-9].*/, "", n); print n; exit }'
}

# The engine's Android Gradle Plugin (7.x) works with JDK 11 and 17 but not with newer ones, so use the
# runner's JDK 17 when the default JDK is something else. Prints nothing to keep the current one.
engine_java_home() {
    local cur="${JAVA_HOME:-}" major=0 cand
    if [ -n "$cur" ] && [ -x "$cur/bin/java" ]; then
        major=$(java_major "$cur/bin/java")
    elif command -v java >/dev/null 2>&1; then
        major=$(java_major "$(command -v java)")
    fi
    case "$major" in 11|17) return 0 ;; esac
    for cand in "${JAVA_HOME_17_X64:-}" "${JAVA_HOME_11_X64:-}" /usr/lib/jvm/temurin-17-jdk-amd64 /usr/lib/jvm/java-17-openjdk-amd64; do
        if [ -n "$cand" ] && [ -x "$cand/bin/java" ]; then printf '%s' "$cand"; return 0; fi
    done
}

# run_engine_gradle <task> <logfile> [plain] - the engine's own Gradle wrapper; "plain" leaves out the init script.
run_engine_gradle() {
    local task="$1" logfile="$2" mode="${3:-}" jhome
    local -a args=(--no-daemon --stacktrace --console=plain "-Pandroid.suppressUnsupportedCompileSdk=34,35,36")
    [ "$mode" = "plain" ] || args+=(-I "$TOOLS/engine-init.gradle")
    jhome="$(engine_java_home)"
    (
        cd "$ENG" || exit 1
        chmod +x gradlew
        if [ -n "$jhome" ]; then export JAVA_HOME="$jhome"; export PATH="$jhome/bin:$PATH"; fi
        export SPLICE_ENGINE_ABI="$TARGET_ABI"
        [ "$OPTIMIZE_NATIVE" = "1" ] && export SPLICE_ENGINE_OPTIMIZE=1
        timeout 25m ./gradlew "$task" "${args[@]}"
    ) > "$logfile" 2>&1
}

# try_gradle_variant <Release|Debug> - 0 = built. LAST_LOG / LAST_RC describe the last attempt.
try_gradle_variant() {
    local variant="$1"
    LAST_LOG="$WORK/gradle-$variant.log"
    log "building the engine package (assemble$variant, $TARGET_ABI only)"
    run_engine_gradle "assemble$variant" "$LAST_LOG"; LAST_RC=$?
    grep -h '^\[splice-engine-init\]' "$LAST_LOG" 2>/dev/null
    if [ "$LAST_RC" -ne 0 ] && grep -qi "initialization script" "$LAST_LOG" 2>/dev/null; then
        tail -n 30 "$LAST_LOG"
        log "Gradle rejected the Splice init script; retrying assemble$variant without it"
        LAST_LOG="$WORK/gradle-$variant-plain.log"
        run_engine_gradle "assemble$variant" "$LAST_LOG" plain; LAST_RC=$?
    fi
    if [ "$LAST_RC" -ne 0 ]; then
        tail -n 60 "$LAST_LOG"
        return 1
    fi
    log "engine package built after $(elapsed)s (assemble$variant)"
    return 0
}

# True when a failed RELEASE build died in a step that does not exist in a debug build (lint, signing,
# shrinking, packaging). Native or Java compile errors would simply repeat, so they do not qualify.
release_only_failure() {   # $1 = log of the failed release build
    local task
    task="$(summarize "$1" --failed-task)"
    case "$task" in
        '') return 1 ;;
        *[Nn]dk*|*[Cc]make*|*[Cc]xx*|*[Ee]xternalNative*|*[Cc]ompile*) return 1 ;;
        *[Rr]elease*|:*lint*) return 0 ;;
    esac
    return 1
}

# Release first (optimised native code). On a release-only failure the debug variant is tried with the
# native code still optimised. Sets ENGINE_VARIANT on success, ENGINE_FAILURE and LAST_RC on failure.
build_engine_package() {
    local first_log first_rc
    OPTIMIZE_NATIVE=0
    if try_gradle_variant Release; then ENGINE_VARIANT=release; return 0; fi
    first_log="$LAST_LOG"; first_rc="$LAST_RC"
    ENGINE_FAILURE="$(summarize "$first_log")"
    if release_only_failure "$first_log"; then
        log "the failure is specific to release builds; trying a debug build (native code stays optimised)"
        OPTIMIZE_NATIVE=1
        if try_gradle_variant Debug; then ENGINE_VARIANT=debug; return 0; fi
        ENGINE_FAILURE="$ENGINE_FAILURE"$'\n'"The debug build failed too: $(summarize "$LAST_LOG" --max-chars 300 | head -n 2 | tr '\n' ' ')"
    fi
    LAST_RC="$first_rc"
    return 1
}

# ---- harvest -----------------------------------------------------------------------------------
harvest_engine() {
    SPLICE_ENGINE_ABI="$TARGET_ABI" python3 "$TOOLS/harvest.py" "$ENG" "$ROOT" "$REV_ACTUAL" \
        || fail "could not harvest the engine build (harvest.py code $?)"
    set_status "RGSS engine: mkxp-z Android port ${REV_ACTUAL:0:10}, $TARGET_ABI, $ENGINE_VARIANT build, built in $(elapsed)s"
}

# ---- main --------------------------------------------------------------------------------------
main() {
    check_preconditions
    restore_payload_cache && exit 0
    clean_outputs
    set_status "RGSS engine build in progress"
    mkdir -p "$WORK"

    install_host_tools
    ensure_ruby31
    command -v ruby >/dev/null 2>&1 || fail "no Ruby available on the build host"
    ensure_ndk

    if ! restore_deps_checkpoint; then
        fetch_engine || fail "could not fetch the engine sources"
        build_native_deps
        save_deps_checkpoint
    fi
    adapt_engine_build
    build_engine_package || fail "engine Gradle build failed (code $LAST_RC)" "$ENGINE_FAILURE"
    harvest_engine

    drop_deps_checkpoint
    cache_payload
    rm -rf "$WORK"
    log "RGSS engine ready (total $(elapsed)s)"
    exit 0
}

# Sourcing the file (tests) only defines the functions.
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    main
fi
