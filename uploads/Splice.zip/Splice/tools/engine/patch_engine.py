#!/usr/bin/env python3
"""Adapts a freshly fetched mkxp-z Android checkout so that it builds for one ABI only.

usage: patch_engine.py <engine-checkout> [abi]

Why: the engine app normally builds armeabi-v7a *and* arm64-v8a (ABI splits plus a universal APK).
Splice compiles the native dependencies for arm64-v8a only, so the 32-bit half of the engine's own
Gradle build has nothing to link against and fails. Restricting the build to one ABI fixes that and
also halves the compile time.

The edit is textual, idempotent and conservative: only ABI lists (strings that are known ABI names)
and `universalApk true` are touched. If nothing matches it says so and changes nothing; the Gradle
init script (engine-init.gradle) restricts the ABIs a second time while the build runs.
"""
import os
import re
import sys

KNOWN_ABIS = {'armeabi', 'armeabi-v7a', 'arm64-v8a', 'x86', 'x86_64'}
QUOTED = r'''(?:'[^']*'|"[^"]*")'''
ABI_LIST = r'%s(?:\s*,\s*%s)*' % (QUOTED, QUOTED)

# include 'a', 'b'   |   include('a', 'b')   |   abiFilters 'a', 'b'   |   abiFilters('a', 'b')
ABI_CALL = re.compile(r'(\b(?:include|abiFilters)\s*\(?\s*)(%s)(\s*\)?)' % ABI_LIST)
UNIVERSAL_APK = re.compile(r'(\buniversalApk\s*=?\s*)true\b')


def patch_text(text, abi):
    """Returns (new_text, number_of_edits)."""
    edits = 0

    def only_target(m):
        nonlocal edits
        names = [s[1:-1] for s in re.findall(QUOTED, m.group(2))]
        if not any(n in KNOWN_ABIS for n in names):
            return m.group(0)               # not an ABI list (e.g. include ':app')
        replacement = "'%s'" % abi
        if m.group(2) == replacement:
            return m.group(0)               # already patched
        edits += 1
        return m.group(1) + replacement + m.group(3)

    text = ABI_CALL.sub(only_target, text)
    text, n = UNIVERSAL_APK.subn(r'\1false', text)
    return text, edits + n


def main(argv):
    if len(argv) < 2:
        print('usage: patch_engine.py <engine-checkout> [abi]')
        return 2
    root = argv[1]
    abi = argv[2] if len(argv) > 2 else 'arm64-v8a'
    patched = False
    for name in ('app/build.gradle', 'app/build.gradle.kts'):
        path = os.path.join(root, name)
        if not os.path.isfile(path):
            continue
        if name.endswith('.kts'):
            print('[patch] %s is a Kotlin script; leaving it to the init script' % name)
            continue
        with open(path, encoding='utf-8', errors='replace') as f:
            old = f.read()
        new, edits = patch_text(old, abi)
        if edits:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(new)
            print('[patch] %s: %d edit(s), building %s only' % (name, edits, abi))
        else:
            print('[patch] %s: no other-ABI settings found (nothing to change)' % name)
        patched = True
    if not patched:
        print('[patch] no app/build.gradle in the engine checkout')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
