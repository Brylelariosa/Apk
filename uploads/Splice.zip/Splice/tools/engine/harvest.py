#!/usr/bin/env python3
"""Turns a built mkxp-z Android port checkout into the pieces Splice needs.

usage: harvest.py <engine-checkout> <splice-root> [revision]

Writes (all generated, git-ignored):
  rgss-engine/src/main/{jniLibs,java,res,assets,AndroidManifest.xml}   Gradle library module sources
  rgss-engine/engine.properties, rgss-engine/READY
  app/src/rgss/java/dev/splice/player/engine/SpliceRgssActivity.java    subclass of the engine's activity
  app/proguard-engine.pro
Exit codes: 0 ok, 2 no APK/native libs, 3 no namespace, 4 no activity, 5 unsupported sources.
"""
import copy
import glob
import os
import re
import shutil
import sys
import xml.etree.ElementTree as ET
import zipfile

src, root = sys.argv[1], sys.argv[2]
rev = sys.argv[3] if len(sys.argv) > 3 else 'unknown'

ANDROID = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android', ANDROID)
ET.register_namespace('tools', 'http://schemas.android.com/tools')


def A(n):
    return '{%s}%s' % (ANDROID, n)


def die(code, msg):
    print('[harvest] ' + msg)
    sys.exit(code)


app = os.path.join(src, 'app')
eng = os.path.join(root, 'rgss-engine')
gen = os.path.join(root, 'app', 'src', 'rgss', 'java', 'dev', 'splice', 'player', 'engine')
tools = os.path.join(root, 'tools', 'engine')
main = os.path.join(eng, 'src', 'main')

# 1. native libraries from the freshly built APK --------------------------------------------------
# Splice ships the engine for one ABI only (see tools/engine/patch_engine.py). With ABI splits the
# build can leave several APKs behind, so take the biggest one that really holds those libraries.
TARGET_ABI = os.environ.get('SPLICE_ENGINE_ABI', 'arm64-v8a')
LIB = re.compile(r'lib/([^/]+)/([^/]+\.so)$')


def apk_abis(path):
    try:
        with zipfile.ZipFile(path) as z:
            return {m.group(1) for m in map(LIB.match, z.namelist()) if m}
    except zipfile.BadZipFile:
        return set()


apks = glob.glob(os.path.join(app, 'build', 'outputs', 'apk', '**', '*.apk'), recursive=True)
if not apks:
    die(2, 'no APK found in app/build/outputs')
apk = next((p for p in sorted(apks, key=os.path.getsize, reverse=True) if TARGET_ABI in apk_abis(p)), None)
if apk is None:
    found = sorted(set().union(*(apk_abis(p) for p in apks)))
    die(2, 'no engine APK contains %s native libraries (found: %s)' % (TARGET_ABI, ', '.join(found) or 'none'))
shutil.rmtree(os.path.join(eng, 'src'), ignore_errors=True)
abis, libs = set(), []
with zipfile.ZipFile(apk) as z:
    for name in z.namelist():
        m = LIB.match(name)
        if not m or m.group(1) != TARGET_ABI:
            continue
        abi, so = m.group(1), m.group(2)
        dest = os.path.join(main, 'jniLibs', abi)
        os.makedirs(dest, exist_ok=True)
        with z.open(name) as f, open(os.path.join(dest, so), 'wb') as out:
            shutil.copyfileobj(f, out)
        abis.add(abi)
        if so not in libs:
            libs.append(so)
if not libs:
    die(2, 'the engine APK contains no %s native libraries' % TARGET_ABI)
print('[harvest] %s: native libs %s (%s)' % (os.path.basename(apk), ', '.join(sorted(libs)), ', '.join(sorted(abis))))

# 2. namespace / dependencies from the engine's Gradle file ---------------------------------------
gradle_text = ''
for cand in ('build.gradle', 'build.gradle.kts'):
    p = os.path.join(app, cand)
    if os.path.exists(p):
        gradle_text = open(p, encoding='utf-8', errors='replace').read()
        break
manifest_path = os.path.join(app, 'src', 'main', 'AndroidManifest.xml')
mtree = ET.parse(manifest_path)
mroot = mtree.getroot()
ns = None
m = re.search(r'namespace\s*[= ]\s*[\'"]([\w.]+)[\'"]', gradle_text)
if m:
    ns = m.group(1)
if not ns:
    ns = mroot.get('package')
if not ns:
    m = re.search(r'applicationId\s*[= ]\s*[\'"]([\w.]+)[\'"]', gradle_text)
    ns = m.group(1) if m else None
if not ns:
    die(3, 'could not determine the engine package/namespace')

deps = []
for m in re.finditer(r'^\s*(?:implementation|api|compileOnly|runtimeOnly)\s*\(?\s*[\'"]([^\'"]+:[^\'"]+:[^\'"]+)[\'"]',
                     gradle_text, re.M):
    if m.group(1) not in deps:
        deps.append(m.group(1))

# 3. launcher activity ----------------------------------------------------------------------------
application = mroot.find('application')
if application is None:
    die(4, 'engine manifest has no <application>')


def resolve(name):
    if name.startswith('.'):
        return ns + name
    if '.' not in name:
        return ns + '.' + name
    return name


main_activity = None
first_activity = None
for comp in application.findall('activity'):
    nm = comp.get(A('name'))
    if not nm:
        continue
    if first_activity is None:
        first_activity = resolve(nm)
    for f in comp.findall('intent-filter'):
        if any(a.get(A('name')) == 'android.intent.action.MAIN' for a in f.findall('action')):
            main_activity = resolve(nm)
if main_activity is None:
    main_activity = first_activity
if main_activity is None:
    die(4, 'engine manifest declares no activity')
print('[harvest] namespace %s, main activity %s' % (ns, main_activity))

# 4. sources / resources / assets -----------------------------------------------------------------
if os.path.isdir(os.path.join(app, 'src', 'main', 'kotlin')):
    die(5, 'the engine app uses Kotlin sources, which this module does not compile')
java_src = os.path.join(app, 'src', 'main', 'java')
os.makedirs(os.path.join(main, 'java'), exist_ok=True)
if os.path.isdir(java_src):
    shutil.copytree(java_src, os.path.join(main, 'java'), dirs_exist_ok=True)
sdl_present = os.path.exists(os.path.join(main, 'java', 'org', 'libsdl', 'app', 'SDLActivity.java'))
if not sdl_present:
    # SDL's Java side lives next to the native sources in the engine checkout
    found = None
    for dirpath, dirnames, filenames in os.walk(os.path.join(app, 'jni')):
        if 'SDLActivity.java' in filenames and dirpath.replace('\\', '/').endswith('org/libsdl/app'):
            found = dirpath
            break
    if found:
        shutil.copytree(found, os.path.join(main, 'java', 'org', 'libsdl', 'app'), dirs_exist_ok=True)
        print('[harvest] SDL java sources taken from ' + found)
for sub in ('res', 'assets'):
    p = os.path.join(app, 'src', 'main', sub)
    if os.path.isdir(p):
        shutil.copytree(p, os.path.join(main, sub), dirs_exist_ok=True)

# 5. library manifest: components only, never a launcher ------------------------------------------
out = ET.Element('manifest')
for el in mroot:
    if el.tag in ('uses-permission', 'uses-permission-sdk-23', 'uses-feature', 'queries', 'permission'):
        out.append(copy.deepcopy(el))
app_out = ET.SubElement(out, 'application')
for comp in application:
    c = copy.deepcopy(comp)
    if comp.tag in ('activity', 'activity-alias'):
        for f in list(c.findall('intent-filter')):
            acts = [a.get(A('name')) for a in f.findall('action')]
            cats = [x.get(A('name')) for x in f.findall('category')]
            if 'android.intent.action.MAIN' in acts or 'android.intent.category.LAUNCHER' in cats:
                c.remove(f)
        c.set(A('exported'), 'false')
    elif comp.tag in ('service', 'receiver', 'provider') and c.get(A('exported')) is None:
        c.set(A('exported'), 'false')
    app_out.append(c)
ET.ElementTree(out).write(os.path.join(main, 'AndroidManifest.xml'), encoding='utf-8', xml_declaration=True)

# 6. generated activity + keep rules --------------------------------------------------------------
os.makedirs(gen, exist_ok=True)
tpl = open(os.path.join(tools, 'SpliceRgssActivity.java.tpl'), encoding='utf-8').read()
open(os.path.join(gen, 'SpliceRgssActivity.java'), 'w', encoding='utf-8').write(tpl.replace('@PARENT@', main_activity))

with open(os.path.join(root, 'app', 'proguard-engine.pro'), 'w', encoding='utf-8') as f:
    f.write('# generated by tools/engine/harvest.py\n')
    f.write('-keep class org.libsdl.app.** { *; }\n')
    f.write('-keep class %s.** { *; }\n' % ns)
    f.write('-keep class %s { *; }\n' % main_activity)
    f.write('-dontwarn %s.**\n' % ns)
    f.write('-keepclasseswithmembernames class * { native <methods>; }\n')

# 7. module descriptor ----------------------------------------------------------------------------
with open(os.path.join(eng, 'engine.properties'), 'w', encoding='utf-8') as f:
    f.write('namespace=%s\n' % ns)
    f.write('mainActivity=%s\n' % main_activity)
    f.write('abis=%s\n' % ' '.join(sorted(abis)))
    f.write('libs=%s\n' % ' '.join(libs))
    f.write('deps=%s\n' % ';'.join(deps))
    f.write('revision=%s\n' % rev)
open(os.path.join(eng, 'READY'), 'w').write(rev + '\n')
print('[harvest] done')
