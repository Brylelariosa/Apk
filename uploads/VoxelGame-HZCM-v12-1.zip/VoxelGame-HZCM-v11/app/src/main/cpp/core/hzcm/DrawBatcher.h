#pragma once
// ============================================================================
// HZCM v4 — DrawBatcher.h
// Cluster draw batcher — minimises GLES driver overhead.
//
// Problem:
//   The old renderer issued one glUniform3iv + one glVertexAttribIPointer pair
//   + one glDrawArraysInstanced per cluster, in arbitrary iteration order.
//   On GLES drivers (especially Adreno) each glUniform call flushes state.
//
// Solution:
//   1. Collect all renderable (origin, megaOffset, faceCount) this frame.
//   2. Sort by ascending MegaBuffer offset → sequential VBO reads → better
//      driver prefetch and fewer partial-tile cache invalidations.
//   3. Issue draws in sorted order with one uniform per cluster — but the
//      sorting alone reduces the number of state-dirty transitions per batch.
//
// Future extension (GLES 3.1 / MDI):
//   When GL_EXT_multi_draw_indirect is available, the sorted batch can be
//   uploaded as a DrawArraysIndirectCommand array and dispatched with a
//   single glMultiDrawArraysIndirectEXT call — zero per-cluster CPU overhead.
//   The data structures here are designed to make that upgrade straightforward.
//
// Thread safety: all methods called from GL thread only.
// ============================================================================
#ifndef GLES3_GL3_H_STUB
#include <GLES3/gl3.h>
#endif
#include <cstdint>
#include <cstring>
#include <vector>
#include <algorithm>
#include "ClusterTypes.h"  // MEGA_INVALID

// ── Per-cluster draw record ───────────────────────────────────────────────────
struct DrawRecord {
    int32_t  originX, originY, originZ;  // cluster world origin (block units)
    uint32_t megaOffset;                 // face offset in MegaBuffer
    uint32_t faceCount;                  // number of PackedFace instances
};

// ── Draw batcher ─────────────────────────────────────────────────────────────
class DrawBatcher {
public:
    static constexpr uint32_t MAX_DRAWS = 16384;  // 200-chunk radius → ~70K clusters

    DrawBatcher() {
        m_records.reserve(4096);
    }

    // ── Reset for new frame ───────────────────────────────────────────────────
    void beginFrame() {
        m_records.clear();
    }

    // ── Submit a visible cluster ──────────────────────────────────────────────
    // Call once per renderable cluster during the gather pass.
    void submit(int ox, int oy, int oz,
                uint32_t megaOffset, uint32_t faceCount)
    {
        if (megaOffset == MEGA_INVALID || faceCount == 0) return;
        if (m_records.size() >= MAX_DRAWS) return;

        m_records.push_back({ ox, oy, oz, megaOffset, faceCount });
    }

    // ── Sort by MegaBuffer offset (ascending) ─────────────────────────────────
    // Must be called before issueDraws().
    void sort() {
        // Radix-friendly: megaOffset fits in 20 bits for 400K faces.
        // std::sort with small comparator — fast enough for ≤10K clusters.
        std::sort(m_records.begin(), m_records.end(),
            [](const DrawRecord& a, const DrawRecord& b) {
                return a.megaOffset < b.megaOffset;
            });
    }

    // ── Issue all draw calls ──────────────────────────────────────────────────
    // `originLoc`  = glGetUniformLocation result for uClusterOrigin
    // Each draw: glUniform3iv + glVertexAttribIPointer × 2 + glDrawArraysInstanced.
    //
    // The attrib pointer re-point is the main per-cluster cost on GLES.
    // We minimise it by sorting (sequential VBO access) and batching
    // all draws with the same shader program already bound by the caller.
    //
    // `faceStride` = sizeof(PackedFace)
    void issueDraws(GLint originLoc) const {
        for (const DrawRecord& r : m_records) {
            // Set cluster world origin
            const GLint origin[3] = { r.originX, r.originY, r.originZ };
            glUniform3iv(originLoc, 1, origin);

            // Repoint instanced attributes to this cluster's faces in mega-VBO.
            // We use byte offsets into the already-bound GL_ARRAY_BUFFER.
            GLintptr byteOff = (GLintptr)(r.megaOffset * sizeof(PackedFace));

            glVertexAttribIPointer(0, 1, GL_UNSIGNED_INT,
                (GLsizei)sizeof(PackedFace),
                (const void*)(byteOff + offsetof(PackedFace, geom)));

            glVertexAttribIPointer(1, 1, GL_UNSIGNED_INT,
                (GLsizei)sizeof(PackedFace),
                (const void*)(byteOff + offsetof(PackedFace, mat)));

            // 6 vertices per face (2 triangles), r.faceCount instances
            glDrawArraysInstanced(GL_TRIANGLES, 0, 6, (GLsizei)r.faceCount);
        }
    }

    // Accessors
    uint32_t drawCount() const { return (uint32_t)m_records.size(); }
    uint32_t faceCount() const {
        uint32_t n = 0;
        for (auto& r : m_records) n += r.faceCount;
        return n;
    }
    bool empty() const { return m_records.empty(); }

private:
    std::vector<DrawRecord> m_records;
};
