#include "Camera.h"
#include "World.h"
#include "Block.h"
#include "Chunk.h"
#include <cmath>
#include <algorithm>

static constexpr float PI      = 3.14159265f;
static constexpr float HALF_PI = PI * 0.5f;

static constexpr float EYE_H      = 1.62f;   // eye height above feet
static constexpr float PLAYER_W   = 0.30f;   // half-width; keeps camera ≥0.30 from wall faces
                                              // (far larger than nearPlane=0.05, so no clip-through)
static constexpr float FLY_SPEED  = 12.0f;
static constexpr float WALK_SPEED =  5.0f;
static constexpr float GRAVITY    = 28.0f;
static constexpr float JUMP_VEL   = 10.5f;
static constexpr float MAX_FALL   =  0.85f;  // max blocks fallen per frame (tunnelling guard)

// ── Camera direction helpers ──────────────────────────────────────────────────
Vec3 Camera::getForward() const {
    float cp = cosf(pitch);
    return Vec3(cosf(yaw)*cp, sinf(pitch), sinf(yaw)*cp).normalize();
}
Vec3 Camera::getRight() const { return getForward().cross({0,1,0}).normalize(); }
Mat4 Camera::getView()       const { return Mat4::lookAt(position, position+getForward(), {0,1,0}); }
Mat4 Camera::getProjection() const { return Mat4::perspective(fovY, aspect, nearPlane, farPlane); }
Mat4 Camera::getVP()         const { return getProjection() * getView(); }
Frustum Camera::getFrustum() const { Frustum f; f.extractFromVP(getVP()); return f; }

// ── Helpers ───────────────────────────────────────────────────────────────────

// Is the 1×PLAYER_H×1 column at (px,py,pz) blocked by any opaque block?
// py is the eye position (camera).
static bool columnBlocked(const World* w, float px, float py, float pz) {
    if (!w) return false;
    int bx = (int)floorf(px);
    int bz = (int)floorf(pz);
    int lo = (int)floorf(py - EYE_H + 0.05f);
    int hi = (int)floorf(py          - 0.05f);
    for (int by = lo; by <= hi; by++)
        if (blockIsOpaque((BlockType)w->getBlock(bx, by, bz))) return true;
    return false;
}

// Full AABB corner checks — tests all 4 corners of the player's square footprint.
// This guarantees the camera center stays >= PLAYER_W from any wall in every direction,
// which is larger than nearPlane (0.01), so the clip plane can never cut solid geometry.
// Bug fix: old code only added PLAYER_W in the *other* axis, so the player could slide
// right up to a face in the movement axis itself and clip through it.
static bool xMoveBlocked(const World* w, float nx, float py, float pz) {
    return columnBlocked(w, nx - PLAYER_W, py, pz - PLAYER_W) ||
           columnBlocked(w, nx - PLAYER_W, py, pz + PLAYER_W) ||
           columnBlocked(w, nx + PLAYER_W, py, pz - PLAYER_W) ||
           columnBlocked(w, nx + PLAYER_W, py, pz + PLAYER_W);
}
static bool zMoveBlocked(const World* w, float px, float py, float nz) {
    return columnBlocked(w, px - PLAYER_W, py, nz - PLAYER_W) ||
           columnBlocked(w, px - PLAYER_W, py, nz + PLAYER_W) ||
           columnBlocked(w, px + PLAYER_W, py, nz - PLAYER_W) ||
           columnBlocked(w, px + PLAYER_W, py, nz + PLAYER_W);
}

// Convert world X/Z to chunk CX/CZ (handles negative coords correctly)
static int worldToChunk(float v, int size) {
    return (int)floorf(v / (float)size);
}

// Try to find solid ground at (bx, bz) and snap player's Y to stand on it.
// Returns true if ground was found within the chunk's block data.
static bool snapToGround(Vec3& pos, const World* world) {
    if (!world) return false;
    int bx = (int)floorf(pos.x);
    int bz = (int)floorf(pos.z);
    // Search from current foot position downward
    int startBy = (int)(pos.y - EYE_H);
    for (int by = std::min(startBy, CHUNK_H - 1); by >= 0; by--) {
        if (blockIsOpaque((BlockType)world->getBlock(bx, by, bz))) {
            pos.y = (float)(by + 1) + EYE_H;
            return true;
        }
    }
    return false;
}

// ── Main update ───────────────────────────────────────────────────────────────
void Camera::update(float dt, const World* world) {

    // ── Look ──────────────────────────────────────────────────────────────────
    float dy = 0, dp = 0;
    { std::lock_guard<std::mutex> lk(lookMutex);
      dy = lookDyaw;   lookDyaw   = 0;
      dp = lookDpitch; lookDpitch = 0; }
    yaw   += dy;
    pitch -= dp;
    pitch  = std::max(-HALF_PI*0.99f, std::min(HALF_PI*0.99f, pitch));
    while (yaw >  PI*2.f) yaw -= PI*2.f;
    while (yaw < -PI*2.f) yaw += PI*2.f;

    // ── Fly / walk toggle ─────────────────────────────────────────────────────
    if (flyToggleRequested.exchange(false)) {
        flyMode = !flyMode;
        velY    = 0.f;
        onGround = false;

        if (!flyMode && world) {
            // Entering walk mode: snap feet to the nearest ground below.
            // If the chunk isn't loaded yet, snap will just keep current position
            // and the chunk-loaded guard below will keep us hovering safely.
            snapToGround(position, world);
        }
    }

    // ── Movement inputs ───────────────────────────────────────────────────────
    float fwd    = inputForward.load(std::memory_order_relaxed);
    float strafe = inputStrafe.load(std::memory_order_relaxed);
    Vec3 forward = getForward();
    Vec3 right   = getRight();

    // ── FLY MODE ─────────────────────────────────────────────────────────────
    if (flyMode) {
        // Pitch steers vertical — look up + push joystick forward = fly up
        position += forward * (fwd    * FLY_SPEED * dt);
        position += right   * (strafe * FLY_SPEED * dt);
        return;
    }

    // ── WALK MODE ─────────────────────────────────────────────────────────────

    // Safety: if the chunk at the player's position is not yet loaded,
    // hover in place so gravity can't drop the player through unloaded terrain.
    int pcx = worldToChunk(position.x, CHUNK_W);
    int pcz = worldToChunk(position.z, CHUNK_D);
    bool chunkLoaded = world && (world->getChunk(pcx, pcz) != nullptr);
    if (!chunkLoaded) {
        velY     = 0.f;
        onGround = false;
        // Still allow horizontal movement so the player can walk to loaded area
    }

    // ── Horizontal movement (slide along walls by testing X and Z separately) ─
    Vec3 flatFwd = {forward.x, 0.f, forward.z};
    float fl = flatFwd.length();
    if (fl > 1e-4f) flatFwd = flatFwd * (1.f / fl);

    float dx = (flatFwd.x * fwd + right.x * strafe) * WALK_SPEED * dt;
    float dz = (flatFwd.z * fwd + right.z * strafe) * WALK_SPEED * dt;

    float nx = position.x + dx;
    if (!xMoveBlocked(world, nx, position.y, position.z)) position.x = nx;
    float nz = position.z + dz;
    if (!zMoveBlocked(world, position.x, position.y, nz)) position.z = nz;

    if (!chunkLoaded) return; // skip vertical physics until chunk is ready

    // ── Block coordinates for the player's current column ────────────────────
    int bx = (int)floorf(position.x);
    int bz = (int)floorf(position.z);

    // ── Water check — is the player's mid-body submerged? ────────────────────
    int midY = (int)floorf(position.y - EYE_H * 0.5f);
    bool inWater = (world->getBlock(bx, midY, bz) == BLOCK_WATER);

    // ── Jump / swim ───────────────────────────────────────────────────────────
    bool jumpReq = jumpRequested.exchange(false);
    if (inWater) {
        if (jumpReq) velY = 3.5f;   // swim upward
    } else if (jumpReq && onGround) {
        velY     = JUMP_VEL;
        onGround = false;
    }

    // ── Gravity (dampened in water) ───────────────────────────────────────────
    if (inWater) {
        // Buoyancy: weak gravity + strong drag so the player slowly sinks
        velY -= GRAVITY * 0.15f * dt;
        velY *= (1.f - 4.f * dt);           // water drag
        velY  = std::max(velY, -2.0f);      // max sink speed in water
    } else {
        velY -= GRAVITY * dt;
        velY  = std::max(velY, -40.f);      // terminal velocity in air
    }

    // ── Vertical movement — clamped to MAX_FALL per frame to prevent tunnelling
    float yMove = velY * dt;
    if (yMove < -MAX_FALL) yMove = -MAX_FALL;
    if (yMove >  MAX_FALL) yMove =  MAX_FALL;
    position.y += yMove;

    // ── Hard minimum floor — never fall below the world ───────────────────────
    if (position.y < EYE_H) {
        position.y = EYE_H;
        velY       = 0.f;
        onGround   = true;
    }

    // ── Ground / ceiling collision ────────────────────────────────────────────
    float footY = position.y - EYE_H;

    // Ground — block the feet are currently inside or just above
    int groundBlock = (int)floorf(footY - 0.01f);
    if (blockIsOpaque((BlockType)world->getBlock(bx, groundBlock, bz)) && velY <= 0.f) {
        position.y = (float)(groundBlock + 1) + EYE_H;
        velY       = 0.f;
        onGround   = true;
    } else {
        // Are we resting on the very top surface of a block?
        int standBlock = (int)floorf(footY) - 1;
        onGround = blockIsOpaque((BlockType)world->getBlock(bx, standBlock, bz))
                   && (footY <= (float)(standBlock + 1) + 0.05f);
    }

    // Ceiling — block the head is currently inside
    int headBlock = (int)floorf(position.y + 0.1f);
    if (blockIsOpaque((BlockType)world->getBlock(bx, headBlock, bz)) && velY > 0.f) {
        position.y = (float)headBlock - 0.1f;
        velY       = 0.f;
    }
}

// ── Input setters (called from JNI / touch thread) ───────────────────────────
void Camera::setLookDelta(float dyaw, float dpitch) {
    std::lock_guard<std::mutex> lk(lookMutex);
    lookDyaw   += dyaw;
    lookDpitch += dpitch;
}
void Camera::setMovement(float forward, float strafe) {
    inputForward.store(forward, std::memory_order_relaxed);
    inputStrafe.store(strafe,  std::memory_order_relaxed);
}
