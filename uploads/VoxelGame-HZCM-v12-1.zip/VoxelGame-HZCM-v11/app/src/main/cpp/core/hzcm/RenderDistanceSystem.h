#pragma once
// ============================================================================
// HZCM v4 — RenderDistanceSystem.h
// Runtime hot-reload render distance system.
//
// Requirements:
//   • Range: [2 .. 200] chunks (Chebyshev radius)
//   • Thread-safe: any thread reads/writes
//   • No restart required — streaming updates take effect next frame
//   • Console command support: /renderdistance N  or  /rd N
//   • Debug HUD string
//   • Change generation counter (callers detect transitions cheaply)
//
// Streaming radii derived from render distance:
//   loadRadius   = render + 1   (keep neighbours loaded for seam meshing)
//   unloadRadius = render + 4   (hysteresis prevents thrashing at boundary)
//   priorityR    = render + 2   (streaming priority lookahead)
// ============================================================================
#include <atomic>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <android/log.h>

class RenderDistanceSystem {
public:
    static constexpr int MIN_DIST     = 2;
    static constexpr int MAX_DIST     = 200;
    static constexpr int DEFAULT_DIST = 7;

    // ── Derived streaming radii ───────────────────────────────────────────────
    struct Radii {
        int render;    // glDrawArraysInstanced radius
        int load;      // chunk generation trigger radius
        int unload;    // chunk eviction radius (hysteresis)
        int priority;  // StreamScheduler look-ahead radius
    };

    RenderDistanceSystem() {
        m_dist.store(DEFAULT_DIST, std::memory_order_relaxed);
        m_gen.store(0,            std::memory_order_relaxed);
    }

    // ── Read path (any thread, zero contention) ───────────────────────────────
    int  getDistance() const {
        return m_dist.load(std::memory_order_acquire);
    }

    Radii getRadii() const {
        int d = getDistance();
        return { d, d + 1, d + 4, d + 2 };
    }

    uint32_t changeGeneration() const {
        return m_gen.load(std::memory_order_acquire);
    }

    // ── Write path ────────────────────────────────────────────────────────────
    // Returns true if the distance actually changed.
    bool setDistance(int newDist) {
        newDist = std::max(MIN_DIST, std::min(MAX_DIST, newDist));
        int prev = m_dist.exchange(newDist, std::memory_order_release);
        if (prev == newDist) return false;

        m_gen.fetch_add(1, std::memory_order_release);

        __android_log_print(ANDROID_LOG_INFO, "RenderDist",
            "Distance %d → %d  (load=%d  unload=%d)",
            prev, newDist, newDist + 1, newDist + 4);
        return true;
    }

    // ── Console command parser ────────────────────────────────────────────────
    // Recognises: "/renderdistance N", "/rd N", "renderdistance N"
    // Returns true if command was consumed.
    bool parseCommand(const char* cmd) {
        if (!cmd) return false;
        // Skip leading slash if present
        const char* p = (cmd[0] == '/') ? cmd + 1 : cmd;

        int val = 0;
        if (sscanf(p, "renderdistance %d", &val) == 1 ||
            sscanf(p, "rd %d",             &val) == 1)
        {
            setDistance(val);
            return true;
        }
        return false;
    }

    // ── Debug string for HUD ──────────────────────────────────────────────────
    // Writes at most bufSize bytes including null terminator.
    void formatHUD(char* buf, size_t bufSize) const {
        Radii r = getRadii();
        snprintf(buf, bufSize,
            "RD:%d  L:%d  U:%d",
            r.render, r.load, r.unload);
    }

    // ── Change detection helper ───────────────────────────────────────────────
    // Pass the last seen generation; returns true if changed and updates it.
    bool pollChanged(uint32_t& lastGen) const {
        uint32_t cur = changeGeneration();
        if (cur == lastGen) return false;
        lastGen = cur;
        return true;
    }

private:
    alignas(64) std::atomic<int>      m_dist;
    alignas(64) std::atomic<uint32_t> m_gen;
};
