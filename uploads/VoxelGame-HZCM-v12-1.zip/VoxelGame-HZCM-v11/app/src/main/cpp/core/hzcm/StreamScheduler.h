#pragma once
// ============================================================================
// HZCM v4 — StreamScheduler.h
// Predictive chunk streaming — now driven by RenderDistanceSystem.
//
// Changes from v3:
//   • Receives render distance from RenderDistanceSystem rather than a
//     compile-time constant → supports runtime hot-reload 2..200.
//   • buildCandidates() accepts an explicit radius parameter.
//   • Added per-chunk distance ring for annular load scheduling.
//   • Priority formula extended with altitude bias: chunks at camera altitude
//     get higher priority (reduces popping of surface clusters).
// ============================================================================
#include <cmath>
#include <vector>
#include <algorithm>

struct ChunkPriority {
    int   cx, cz;
    float priority;
};

class StreamScheduler {
public:
    // How far ahead (seconds) we predict camera movement
    static constexpr float LOOKAHEAD_S   = 2.5f;
    // Weight for camera-forward alignment vs raw distance
    static constexpr float FORWARD_BIAS  = 0.5f;
    // Altitude alignment bonus (fraction of raw priority)
    static constexpr float ALTITUDE_BIAS = 0.2f;

    // ── Camera state update (call every frame) ────────────────────────────────
    void update(float camX, float camZ, float camY,
                float velX, float velZ,
                float fwdX, float fwdZ)
    {
        m_camX = camX; m_camZ = camZ; m_camY = camY;
        m_velX = velX; m_velZ = velZ;
        m_fwdX = fwdX; m_fwdZ = fwdZ;

        // Smooth velocity with EMA to reduce jitter
        m_smoothVX = m_smoothVX * 0.85f + velX * 0.15f;
        m_smoothVZ = m_smoothVZ * 0.85f + velZ * 0.15f;
    }

    // ── Sort candidates by priority (highest first) ───────────────────────────
    //
    // BUG FIXED (v10 → v11): The old formula `1/dist + FORWARD_BIAS * align`
    // used Euclidean distance from the *lookahead* position as its base.  With
    // LOOKAHEAD_S = 2.5 s and any non-zero velocity, the lookahead point sits
    // far ahead of the camera.  A chunk at Chebyshev ring 10 directly in front
    // could have a smaller dist-from-lookahead than a chunk at ring 2 behind the
    // player, giving it higher priority.  The result: far-forward chunks loaded
    // before adjacent ones, producing the "floating island" and "nearby gaps"
    // symptoms reported in v10.
    //
    // New formula guarantees strict nearest-ring-first ordering:
    //
    //   priority = 1e6 / (chebRing + 1)  +  FORWARD_BIAS * align
    //
    // The 1e6 primary term dominates for every ring 0..200 (RD_MAX).
    // The secondary term (0 .. FORWARD_BIAS = 0..0.5) acts as a tiebreaker
    // within the same ring, loading the chunks most likely to be visible first.
    // Ring N always beats ring N+1 because the inter-ring gap (≥ 1e6/((N+1)(N+2)))
    // exceeds FORWARD_BIAS for all N ≤ ~1413, safely covering RD ≤ 200.
    void sortByPriority(std::vector<ChunkPriority>& candidates) const {
        float fwdLen = sqrtf(m_fwdX * m_fwdX + m_fwdZ * m_fwdZ);
        float nfX = (fwdLen > 1e-3f) ? m_fwdX / fwdLen : 0.f;
        float nfZ = (fwdLen > 1e-3f) ? m_fwdZ / fwdLen : 0.f;

        // Actual camera chunk coords for Chebyshev ring distance.
        // 16 == CHUNK_W == CHUNK_D (from ClusterTypes.h).
        int camCX = (int)floorf(m_camX / 16.f);
        int camCZ = (int)floorf(m_camZ / 16.f);

        for (auto& cp : candidates) {
            float ccx = (float)(cp.cx * 16) + 8.f;  // chunk centre world-X
            float ccz = (float)(cp.cz * 16) + 8.f;  // chunk centre world-Z

            // Direction alignment from actual camera to chunk centre (0=behind, 1=ahead).
            // Uses the smoothed forward vector so direction bias is jitter-free.
            float dx = ccx - m_camX, dz = ccz - m_camZ;
            float eucl = sqrtf(dx * dx + dz * dz) + 0.001f;
            float align = ((dx / eucl * nfX + dz / eucl * nfZ) + 1.f) * 0.5f;

            // Chebyshev ring from actual camera chunk — strict nearest-first.
            int cheb = std::max(std::abs(cp.cx - camCX), std::abs(cp.cz - camCZ));
            cp.priority = 1000000.f / (float)(cheb + 1) + FORWARD_BIAS * align;
        }

        std::sort(candidates.begin(), candidates.end(),
            [](const ChunkPriority& a, const ChunkPriority& b) {
                return a.priority > b.priority;
            });
    }

    // ── Build candidate list for a given radius ───────────────────────────────
    // renderRadius is the FULL radius from RenderDistanceSystem (2..200).
    // innerR lets callers build annular rings (e.g., only newly-in-range chunks).
    static void buildCandidates(int camCX, int camCZ,
                                int innerR, int outerR,
                                std::vector<ChunkPriority>& out)
    {
        out.clear();
        // Reserve to avoid re-allocation during fill
        int diam = outerR * 2 + 1;
        out.reserve((size_t)(diam * diam));

        for (int dz = -outerR; dz <= outerR; ++dz) {
            for (int dx = -outerR; dx <= outerR; ++dx) {
                int dist = std::max(std::abs(dx), std::abs(dz));
                if (dist < innerR || dist > outerR) continue;
                out.push_back({ camCX + dx, camCZ + dz, 0.f });
            }
        }
    }

private:
    float m_camX = 0.f, m_camZ = 0.f, m_camY = 64.f;
    float m_velX = 0.f, m_velZ = 0.f;
    float m_fwdX = 0.f, m_fwdZ = 1.f;
    float m_smoothVX = 0.f, m_smoothVZ = 0.f;
};
