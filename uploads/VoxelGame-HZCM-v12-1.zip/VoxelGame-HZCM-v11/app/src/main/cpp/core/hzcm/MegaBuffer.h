#pragma once
// ============================================================================
// HZCM v4 — MegaBuffer.h
// Single large GL_ARRAY_BUFFER shared by ALL clusters.
//
// Changes from v3:
//   • PageAllocator replaces first-fit bitmap → zero fragmentation growth.
//   • RingUploadBuffer replaces bare glBufferSubData → no CPU/GPU sync stalls.
//   • Total capacity auto-sized from PageAllocator size classes.
//   • Thread safety: alloc/free on GL thread; stage() from GL thread after
//     worker pushes to upload queue.
//
// Call sequence per frame (GL thread):
//   1.  mega.beginFrame()          → primes ring slot, waits on old fence
//   2.  mega.upload(off,data,n)    → stages into CPU ring buffer
//   3.  mega.flushUploads()        → one glMapBufferRange → GPU
//   4.  mega.bind() + draw loop
// ============================================================================
#ifndef GLES3_GL3_H_STUB
#include <GLES3/gl3.h>
#endif
#include <cstdint>
#include <cstring>
#include <android/log.h>

#include "ClusterTypes.h"
#include "PageAllocator.h"
#include "RingUploadBuffer.h"

class MegaBuffer {
public:
    MegaBuffer() = default;
    ~MegaBuffer() { destroy(); }

    // ── Init (GL thread, called once after EGL context ready) ─────────────────
    void init() {
        // Let PageAllocator determine the total capacity it needs
        // by probing with a large upper bound.
        // We compute the exact byte size first.
        uint32_t totalFaces = computeTotalFaces();

        glGenBuffers(1, &m_vbo);
        glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
        glBufferData(GL_ARRAY_BUFFER,
                     (GLsizeiptr)(totalFaces * sizeof(PackedFace)),
                     nullptr,
                     GL_DYNAMIC_DRAW);
        glBindBuffer(GL_ARRAY_BUFFER, 0);

        uint32_t allocated = m_pageAlloc.init(totalFaces);
        m_totalFaces = allocated;

        __android_log_print(ANDROID_LOG_INFO, "MegaBuffer",
            "Init: %u faces = %.1f MB",
            m_totalFaces,
            (float)(m_totalFaces * sizeof(PackedFace)) / (1024.f * 1024.f));
    }

    void destroy() {
        if (m_vbo) { glDeleteBuffers(1, &m_vbo); m_vbo = 0; }
    }

    // ── Allocation (GL thread) ────────────────────────────────────────────────
    // Returns face offset into VBO, or MEGA_INVALID on failure.
    uint32_t alloc(uint32_t numFaces) {
        return m_pageAlloc.alloc(numFaces);
    }

    // Release. `numFaces` must match what was passed to alloc().
    void free(uint32_t offsetFaces, uint32_t numFaces) {
        m_pageAlloc.free(offsetFaces, numFaces);
    }

    // ── Streaming upload (GL thread) ──────────────────────────────────────────
    // Call beginFrame once per frame before any upload().
    void beginFrame() {
        m_ringUpload.beginFrame(m_vbo);
    }

    // Stage face data for upload. Returns false if ring is full (flush first).
    bool upload(uint32_t offsetFaces, const PackedFace* data, uint32_t numFaces) {
        return m_ringUpload.stage(offsetFaces, data, numFaces);
    }

    // Commit all staged uploads to GPU in one driver call.
    // Must be called before bind()+draw so GPU sees fresh data.
    void flushUploads() {
        m_ringUpload.flush();
    }

    // ── Render (GL thread) ────────────────────────────────────────────────────
    void bind() const { glBindBuffer(GL_ARRAY_BUFFER, m_vbo); }
    GLuint vbo() const { return m_vbo; }

    // ── Diagnostics ───────────────────────────────────────────────────────────
    uint32_t usedFaces()  const { return m_pageAlloc.totalUsedFaces(); }
    uint32_t totalFaces() const { return m_totalFaces; }

    uint32_t stagedFacesThisFrame() const {
        return m_ringUpload.stagedFacesThisFrame();
    }

private:
    GLuint          m_vbo       = 0;
    uint32_t        m_totalFaces = 0;
    PageAllocator   m_pageAlloc;
    RingUploadBuffer m_ringUpload;

    // Compute total faces needed from all size classes
    static uint32_t computeTotalFaces() {
        uint32_t total = 0;
        for (int c = 0; c < NUM_SIZE_CLASSES; ++c)
            total += SIZE_CLASSES[c].pageSize * SIZE_CLASSES[c].numPages;
        return total;
    }
};
