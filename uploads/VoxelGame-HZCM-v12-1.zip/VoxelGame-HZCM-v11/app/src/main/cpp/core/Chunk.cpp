// ============================================================================
// HZCM v4 — Chunk.cpp
// ============================================================================
#include "Chunk.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <algorithm>

#define TAG "HZCMChunk"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

// ── Constructor ────────────────────────────────────────────────────────────────
Chunk::Chunk(int cx, int cz) : cx(cx), cz(cz) {
    memset(blocks, BLOCK_AIR, sizeof(blocks));
    for (int i = 0; i < CLUSTER_STACK; ++i) {
        clusterState[i].store(ClusterState::EMPTY, std::memory_order_relaxed);
        clusterGPUOffset[i] = MEGA_INVALID;
        clusterFaceCount[i] = 0;
        clusterDirtyGen[i]  = 0;
    }
}

// ── Terrain generation ─────────────────────────────────────────────────────────
void Chunk::generate(const Noise& noise) {
    const float SCALE  = 0.035f;
    const int   BASE_H = 32;
    const int   RANGE  = 20;

    for (int lz = 0; lz < CHUNK_D; ++lz) {
        for (int lx = 0; lx < CHUNK_W; ++lx) {
            float wx = (float)(cx * CHUNK_W + lx);
            float wz = (float)(cz * CHUNK_D + lz);

            float n = noise.fbm(wx * SCALE, wz * SCALE, 5);
            int   h = BASE_H + (int)(n * (float)RANGE);
            h = std::max(1, std::min(CHUNK_H - 4, h));

            float biomeN = noise.noise2D(wx * 0.008f + 500.f, wz * 0.008f + 500.f);
            uint8_t surfBlock = BLOCK_GRASS;
            if      (biomeN >  0.35f) surfBlock = BLOCK_SNOW;
            else if (biomeN < -0.35f) surfBlock = BLOCK_SAND;

            for (int ly = 0; ly < CHUNK_H; ++ly) {
                uint8_t bt = BLOCK_AIR;
                if      (ly == 0)        bt = BLOCK_STONE;
                else if (ly <= h - 4)    bt = BLOCK_STONE;
                else if (ly <= h - 1)    bt = (surfBlock == BLOCK_SAND) ? BLOCK_SAND : BLOCK_DIRT;
                else if (ly == h)        bt = surfBlock;
                else if (ly <= 28 && h < 28 && surfBlock == BLOCK_SAND) bt = BLOCK_WATER;
                setBlock(lx, ly, lz, bt);
            }

            // Tree placement (~3% on grass)
            if (surfBlock == BLOCK_GRASS && h < CHUNK_H - 10) {
                unsigned seed = (unsigned)(cx*7919 + lx*131 + cz*4001 + lz*37);
                seed = seed * 1664525u + 1013904223u;
                if ((seed & 0xFFu) < 8u) {
                    int treeH = 4 + (int)((seed >> 8) & 3);
                    for (int ty = h+1; ty <= h+treeH; ++ty)
                        if (ty < CHUNK_H) setBlock(lx, ty, lz, BLOCK_WOOD);
                    int top = h + treeH;
                    for (int ly2 = top-1; ly2 <= top+1; ++ly2) {
                        int r = (ly2 >= top) ? 1 : 2;
                        for (int dx = -r; dx <= r; ++dx)
                            for (int dz2 = -r; dz2 <= r; ++dz2) {
                                int lx2 = lx+dx, lz2 = lz+dz2;
                                if (lx2>=0&&lx2<CHUNK_W&&lz2>=0&&lz2<CHUNK_D&&ly2<CHUNK_H)
                                    if (getBlock(lx2,ly2,lz2) == BLOCK_AIR)
                                        setBlock(lx2,ly2,lz2,BLOCK_LEAVES);
                            }
                    }
                }
            }

            // Gravel patches
            {
                unsigned seed2 = (unsigned)(cx*1231 + lx*53 + cz*9973 + lz*73);
                seed2 = seed2 * 1664525u + 1013904223u;
                if ((seed2 & 0xFFu) < 20u) {
                    int gy = 2 + (int)((seed2 >> 8) & 15);
                    if (gy < h-4) setBlock(lx, gy, lz, BLOCK_GRAVEL);
                }
            }
        }
    }

    generated.store(true, std::memory_order_release);
    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
        clusterState[ci].store(ClusterState::DIRTY, std::memory_order_release);
        clusterDirtyGen[ci]++;
    }
}

// ── Extract 16³ voxels for cluster ci ─────────────────────────────────────────
void Chunk::extractClusterVoxels(int ci, uint8_t out[CL_VOLUME]) const {
    const int baseY = ci * CL_SIZE;
    for (int z = 0; z < CL_SIZE; ++z) {
        for (int y = 0; y < CL_SIZE; ++y) {
            const uint8_t* src = &blocks[0 + CHUNK_W * ((baseY + y) + CHUNK_H * z)];
            uint8_t*       dst = &out[0 + CL_SIZE * (y + CL_SIZE * z)];
            memcpy(dst, src, CL_SIZE);
        }
    }
}

// ── Build cluster mesh ─────────────────────────────────────────────────────────
void Chunk::buildClusterMesh(int ci,
                               const Chunk* nxC, const Chunk* pxC,
                               const Chunk* nzC, const Chunk* pzC)
{
    static thread_local uint8_t selfVox[CL_VOLUME];
    static thread_local uint8_t nxVox[CL_VOLUME], pxVox[CL_VOLUME];
    static thread_local uint8_t nyVox[CL_VOLUME], pyVox[CL_VOLUME];
    static thread_local uint8_t nzVox[CL_VOLUME], pzVox[CL_VOLUME];

    extractClusterVoxels(ci, selfVox);

    NeighbourVoxels nb;
    if (nxC && nxC->generated.load(std::memory_order_acquire))
        { nxC->extractClusterVoxels(ci, nxVox); nb.nx = nxVox; }
    if (pxC && pxC->generated.load(std::memory_order_acquire))
        { pxC->extractClusterVoxels(ci, pxVox); nb.px = pxVox; }
    if (nzC && nzC->generated.load(std::memory_order_acquire))
        { nzC->extractClusterVoxels(ci, nzVox); nb.nz = nzVox; }
    if (pzC && pzC->generated.load(std::memory_order_acquire))
        { pzC->extractClusterVoxels(ci, pzVox); nb.pz = pzVox; }
    if (ci > 0)               { extractClusterVoxels(ci-1, nyVox); nb.ny = nyVox; }
    if (ci < CLUSTER_STACK-1) { extractClusterVoxels(ci+1, pyVox); nb.py = pyVox; }

    std::vector<PackedFace> localFaces;
    ClusterMesher::buildCluster(selfVox, nb, localFaces);

    {
        std::lock_guard<std::mutex> lock(clusterMutex[ci]);
        clusterFaces[ci] = std::move(localFaces);
    }
    clusterState[ci].store(ClusterState::MESHED, std::memory_order_release);
}

// ── AABB ───────────────────────────────────────────────────────────────────────
void Chunk::getAABB(float& mnX, float& mnY, float& mnZ,
                     float& mxX, float& mxY, float& mxZ) const {
    mnX = (float)(cx * CHUNK_W); mnY = 0.f;        mnZ = (float)(cz * CHUNK_D);
    mxX = mnX + CHUNK_W;         mxY = (float)CHUNK_H; mxZ = mnZ + CHUNK_D;
}
