#pragma once
// ============================================================================
// HZCM v4 — LockFreeJobQueue.h
// MPMC lock-free fixed-capacity job ring (Dmitry Vyukov pattern).
//
// Key properties:
//   • Zero per-enqueue heap allocation — jobs store typed args inline.
//   • No std::function (no heap alloc, no virtual dispatch overhead).
//   • False-sharing mitigated via 64-byte cell alignment.
//   • Blocking pop via condition_variable (avoids busy-spin on mobile).
//   • Work-stealing pattern: any worker can pop any job.
//
// Job kinds (tagged union — covers all World streaming patterns):
//   CHUNK_BUILD     : generate terrain + mesh all clusters
//   CLUSTER_REBUILD : remesh a single cluster after edit/neighbour-change
//   NEIGHBOUR_FLUSH : kick border cluster remeshes after chunk eviction
// ============================================================================
#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <android/log.h>

// ── Job descriptor ────────────────────────────────────────────────────────────
// Fits in one cache line together with the sequence counter in its Cell.
enum class JobKind : uint8_t {
    CHUNK_BUILD     = 0,
    CLUSTER_REBUILD = 1,
    NEIGHBOUR_FLUSH = 2,
};

// Forward declarations satisfied in World.h
class World;
class Chunk;

struct alignas(8) WorldJob {
    JobKind kind;
    uint8_t  _pad[3];
    int      ci;       // cluster index (CLUSTER_REBUILD only; -1 = all)
    World*   world;
    Chunk*   chunk;
    int      flushCX, flushCZ; // NEIGHBOUR_FLUSH coords
};
static_assert(sizeof(WorldJob) <= 32, "WorldJob must fit in 32 bytes");

// ── MPMC bounded ring ─────────────────────────────────────────────────────────
template<uint32_t N>  // N must be a power of two
class MpmcJobRing {
    static_assert((N & (N - 1)) == 0, "N must be power of 2");
    static_assert(N >= 64,            "Need at least 64 slots");

    // Each cell is exactly one cache line: 4-byte seq + 4-byte pad + 32-byte job
    // = 40 bytes → padded to 64 bytes.
    struct alignas(64) Cell {
        std::atomic<uint32_t> seq;
        WorldJob              job;
        uint8_t               _pad[64 - sizeof(std::atomic<uint32_t>) - sizeof(WorldJob)];
    };

    Cell                     m_ring[N];
    alignas(64) std::atomic<uint32_t> m_enq{0};   // producers
    alignas(64) std::atomic<uint32_t> m_deq{0};   // consumers

    // Sleepy path for workers — fired once per push
    std::mutex               m_wakeMtx;
    std::condition_variable  m_wakeCv;
    std::atomic<bool>        m_stopped{false};

public:
    MpmcJobRing() {
        for (uint32_t i = 0; i < N; ++i)
            m_ring[i].seq.store(i, std::memory_order_relaxed);
    }

    // ── Producers ─────────────────────────────────────────────────────────────
    // Returns false if the ring is full (rare; caller should log and retry).
    bool push(const WorldJob& job) {
        uint32_t pos = m_enq.load(std::memory_order_relaxed);
        for (;;) {
            Cell& cell = m_ring[pos & (N - 1)];
            uint32_t seq = cell.seq.load(std::memory_order_acquire);
            int32_t  diff = static_cast<int32_t>(seq) - static_cast<int32_t>(pos);
            if (diff == 0) {
                if (m_enq.compare_exchange_weak(pos, pos + 1,
                        std::memory_order_relaxed)) {
                    cell.job = job;
                    cell.seq.store(pos + 1, std::memory_order_release);
                    // Wake exactly one sleeping worker
                    m_wakeCv.notify_one();
                    return true;
                }
            } else if (diff < 0) {
                // Ring full
                return false;
            } else {
                pos = m_enq.load(std::memory_order_relaxed);
            }
        }
    }

    // ── Consumers ─────────────────────────────────────────────────────────────
    // Non-blocking pop. Returns false if queue is empty.
    bool tryPop(WorldJob& out) {
        uint32_t pos = m_deq.load(std::memory_order_relaxed);
        for (;;) {
            Cell& cell = m_ring[pos & (N - 1)];
            uint32_t seq = cell.seq.load(std::memory_order_acquire);
            int32_t  diff = static_cast<int32_t>(seq) - static_cast<int32_t>(pos + 1);
            if (diff == 0) {
                if (m_deq.compare_exchange_weak(pos, pos + 1,
                        std::memory_order_relaxed)) {
                    out = cell.job;
                    cell.seq.store(pos + N, std::memory_order_release);
                    return true;
                }
            } else if (diff < 0) {
                return false; // empty
            } else {
                pos = m_deq.load(std::memory_order_relaxed);
            }
        }
    }

    // Blocking pop — for worker thread main loops.
    // Returns false when stopped+empty (signal for worker to exit).
    bool popWait(WorldJob& out, int timeoutMs = 20) {
        if (tryPop(out)) return true;

        std::unique_lock<std::mutex> lk(m_wakeMtx);
        m_wakeCv.wait_for(lk, std::chrono::milliseconds(timeoutMs), [this] {
            return m_stopped.load(std::memory_order_acquire) || !empty();
        });

        if (tryPop(out)) return true;
        // Stopped and empty — signal worker to exit
        return !m_stopped.load(std::memory_order_acquire);
    }

    bool empty() const {
        return m_enq.load(std::memory_order_relaxed)
            == m_deq.load(std::memory_order_relaxed);
    }

    uint32_t approximateSize() const {
        uint32_t e = m_enq.load(std::memory_order_relaxed);
        uint32_t d = m_deq.load(std::memory_order_relaxed);
        return (e >= d) ? (e - d) : 0u;
    }

    void requestStop() {
        m_stopped.store(true, std::memory_order_release);
        m_wakeCv.notify_all();
    }

    bool isStopped() const {
        return m_stopped.load(std::memory_order_acquire);
    }
};

// ── Concrete queue type used by World ─────────────────────────────────────────
// 1024 slots @ 64 bytes each = 64 KB. Hot in L2 cache.
static constexpr uint32_t JOB_RING_CAPACITY = 1024;
using LockFreeJobQueue = MpmcJobRing<JOB_RING_CAPACITY>;
