#include <jni.h>
#include <GLES3/gl3.h>
#include <android/log.h>
#include <ctime>
#include <memory>
#include <cstring>
#include "core/Renderer.h"

#define TAG  "VoxelJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)

static std::unique_ptr<Renderer> g_renderer;

static long long getTimeNs() {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000LL + ts.tv_nsec;
}
static long long g_lastTimeNs = 0;
static float getDeltaTime() {
    long long now = getTimeNs();
    if (g_lastTimeNs == 0) { g_lastTimeNs = now; return 0.016f; }
    float dt = (float)((now - g_lastTimeNs) * 1e-9);
    g_lastTimeNs = now;
    return (dt > 0.1f) ? 0.1f : dt;
}

extern "C" {

JNIEXPORT void JNICALL
Java_com_voxelgame_GameRenderer_nativeInit(JNIEnv*, jobject) {
    LOGI("nativeInit"); g_lastTimeNs = 0;
    g_renderer = std::make_unique<Renderer>(); g_renderer->init();
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameRenderer_nativeResize(JNIEnv*, jobject, jint w, jint h) {
    if (g_renderer) g_renderer->resize(w, h);
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameRenderer_nativeRender(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->render(getDeltaTime());
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSetMovement(JNIEnv*, jobject, jfloat x, jfloat y) {
    if (g_renderer) g_renderer->camera.setMovement(x, y);
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSetLook(JNIEnv*, jobject, jfloat dx, jfloat dy) {
    if (g_renderer) g_renderer->camera.setLookDelta(dx, dy);
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeJump(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->camera.jumpRequested.store(true);
}
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeToggleFly(JNIEnv*, jobject) {
    if (g_renderer) g_renderer->camera.flyToggleRequested.store(true);
}

// Runtime render distance — console command path ("/rd 32", "/renderdistance 16", etc.)
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSendCommand(JNIEnv* env, jobject, jstring jcmd) {
    if (!g_renderer || !jcmd) return;
    const char* cmd = env->GetStringUTFChars(jcmd, nullptr);
    if (cmd) {
        bool ok = g_renderer->sendCommand(cmd);
        LOGI("Command \"%s\" -> %s", cmd, ok ? "OK" : "unrecognised");
        env->ReleaseStringUTFChars(jcmd, cmd);
    }
}

// Direct numeric set — Java SeekBar or EditText int field
JNIEXPORT void JNICALL
Java_com_voxelgame_GameSurfaceView_nativeSetRenderDistance(JNIEnv*, jobject, jint dist) {
    if (g_renderer) g_renderer->world.renderDistance().setDistance((int)dist);
}

// Query current value — Java UI read
JNIEXPORT jint JNICALL
Java_com_voxelgame_GameSurfaceView_nativeGetRenderDistance(JNIEnv*, jobject) {
    if (!g_renderer) return 7;
    return (jint)g_renderer->world.renderDistance().getDistance();
}

} // extern "C"
