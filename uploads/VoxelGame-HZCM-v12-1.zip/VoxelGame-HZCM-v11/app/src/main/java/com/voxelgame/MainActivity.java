package com.voxelgame;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {

    private GameSurfaceView surfaceView;

    // Render-distance HUD button — shows current value, opens settings on tap
    private Button  rdButton;
    private Handler rdHandler;
    private Runnable rdPoll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );

        FrameLayout root = new FrameLayout(this);

        // ── GL surface ────────────────────────────────────────────────────────
        surfaceView = new GameSurfaceView(this);
        root.addView(surfaceView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));

        // ── Joystick overlay ──────────────────────────────────────────────────
        JoystickOverlay joystick = new JoystickOverlay(this);
        root.addView(joystick, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        surfaceView.setJoystickOverlay(joystick);

        // ── Render-distance button (top-right corner) ─────────────────────────
        rdButton = makeRdButton();
        FrameLayout.LayoutParams rdParams = new FrameLayout.LayoutParams(
                dpToPx(88), dpToPx(36));
        rdParams.gravity  = Gravity.TOP | Gravity.END;
        rdParams.topMargin   = dpToPx(12);
        rdParams.rightMargin = dpToPx(12);
        root.addView(rdButton, rdParams);

        setContentView(root);

        // Poll the native side every second to keep the button label fresh
        rdHandler = new Handler(Looper.getMainLooper());
        rdPoll = new Runnable() {
            @Override public void run() {
                refreshRdLabel();
                rdHandler.postDelayed(this, 1000);
            }
        };
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    @Override protected void onResume() {
        super.onResume();
        surfaceView.onResume();
        rdHandler.postDelayed(rdPoll, 1000);
    }

    @Override protected void onPause() {
        super.onPause();
        surfaceView.onPause();
        rdHandler.removeCallbacks(rdPoll);
    }

    // ── Render-distance HUD button ────────────────────────────────────────────
    private Button makeRdButton() {
        Button btn = new Button(this);
        btn.setText("RD: 7");
        btn.setTextColor(Color.WHITE);
        btn.setTextSize(12f);
        btn.setTypeface(Typeface.MONOSPACE);
        btn.setBackgroundColor(0xCC000000);  // semi-transparent black
        btn.setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4));
        btn.setOnClickListener(v -> showRdDialog());
        return btn;
    }

    private void refreshRdLabel() {
        try {
            int cur = surfaceView.nativeGetRenderDistance();
            rdButton.setText("RD: " + cur);
        } catch (Exception ignored) {}
    }

    // ── Render-distance settings dialog ──────────────────────────────────────
    private void showRdDialog() {
        final int MIN = 2, MAX = 200;
        int current;
        try { current = surfaceView.nativeGetRenderDistance(); }
        catch (Exception e) { current = 7; }

        // Root layout
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dpToPx(24), dpToPx(16), dpToPx(24), dpToPx(8));

        // Title label
        TextView title = new TextView(this);
        title.setText("Render Distance");
        title.setTextSize(16f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        // Current value display
        TextView valueLabel = new TextView(this);
        valueLabel.setTextSize(28f);
        valueLabel.setGravity(Gravity.CENTER);
        valueLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        valueLabel.setText(String.valueOf(current));
        root.addView(valueLabel);

        // Range hint
        TextView rangeHint = new TextView(this);
        rangeHint.setText("Range: " + MIN + " – " + MAX + " chunks");
        rangeHint.setTextSize(11f);
        rangeHint.setGravity(Gravity.CENTER);
        rangeHint.setTextColor(Color.GRAY);
        root.addView(rangeHint);

        // SeekBar
        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(MAX - MIN);
        seekBar.setProgress(current - MIN);
        LinearLayout.LayoutParams seekParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        seekParams.topMargin = dpToPx(12);
        root.addView(seekBar, seekParams);

        // Performance hint
        TextView perfHint = new TextView(this);
        perfHint.setTextSize(11f);
        perfHint.setGravity(Gravity.CENTER);
        perfHint.setTextColor(0xFF888888);
        perfHint.setPadding(0, dpToPx(4), 0, 0);
        updatePerfHint(perfHint, current);
        root.addView(perfHint);

        // Numeric typed input row
        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setOrientation(LinearLayout.HORIZONTAL);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.topMargin = dpToPx(12);
        inputRow.setLayoutParams(rowParams);

        TextView inputLabel = new TextView(this);
        inputLabel.setText("Type exact value: ");
        inputLabel.setTextSize(13f);

        EditText editText = new EditText(this);
        editText.setInputType(InputType.TYPE_CLASS_NUMBER);
        editText.setHint("2–200");
        editText.setText(String.valueOf(current));
        editText.setSelectAllOnFocus(true);
        LinearLayout.LayoutParams etParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        editText.setLayoutParams(etParams);

        inputRow.addView(inputLabel);
        inputRow.addView(editText);
        root.addView(inputRow);

        // Wire SeekBar → valueLabel + editText + perfHint
        final int[] pending = {current};
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                int v = progress + MIN;
                pending[0] = v;
                valueLabel.setText(String.valueOf(v));
                editText.setText(String.valueOf(v));
                updatePerfHint(perfHint, v);
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });

        // Build dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(root);
        builder.setPositiveButton("Apply", (dialog, which) -> {
            // Prefer typed value if it changed
            String typed = editText.getText().toString().trim();
            int finalVal = pending[0];
            try {
                int parsed = Integer.parseInt(typed);
                finalVal = Math.max(MIN, Math.min(MAX, parsed));
            } catch (NumberFormatException ignored) {}

            surfaceView.nativeSetRenderDistance(finalVal);
            rdButton.setText("RD: " + finalVal);
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // Performance hint string based on the chosen distance
    private void updatePerfHint(TextView tv, int dist) {
        String hint;
        if      (dist <= 4)  hint = "⚡ Very fast — minimum detail";
        else if (dist <= 8)  hint = "✓ Balanced — recommended for most devices";
        else if (dist <= 16) hint = "◎ High quality — needs a fast device";
        else if (dist <= 32) hint = "⚠ Demanding — may cause thermal throttling";
        else                 hint = "🔥 Extreme — stress-test only";
        tv.setText(hint);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private int dpToPx(int dp) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(dp * density);
    }
}
