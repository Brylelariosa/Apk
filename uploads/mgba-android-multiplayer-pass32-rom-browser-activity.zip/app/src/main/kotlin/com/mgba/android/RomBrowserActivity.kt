package com.mgba.android

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import java.io.File

/** ROM selection — a free-roam local-storage file manager. Its own Activity
 *  (Thirty-second pass), not an overlay inside MainActivity the way it was
 *  through Thirty-first pass. That change exists for one reason: an actual
 *  forced orientation change for this screen, tried twice while it lived
 *  inside MainActivity's own window (once outright, once with the
 *  orientation change carefully spaced apart from other view work — the
 *  standard fix for exactly this class of race), caused a real native
 *  RenderThread SIGABRT — "drawRenderNode called on a context with no
 *  surface!" — on an actual device both times. The system's hardware
 *  renderer tried to draw a queued frame for a view whose window surface
 *  had been reconfigured out from under it by the orientation change; a
 *  native abort, not a JVM exception, so no try/catch in Kotlin could ever
 *  have caught it either time.
 *
 *  A separate Activity sidesteps the whole failure class rather than
 *  fighting it a third time: android:screenOrientation="portrait" in the
 *  manifest locks this screen's orientation statically, entirely at the
 *  platform level, with zero runtime requestedOrientation calls anywhere in
 *  this file — there is no "change" for RenderThread to race against.
 *  MainActivity's own game window is a genuinely separate window, paused
 *  while this one is in front, so there is also no shared window for a game
 *  frame and a browser frame to ever collide in. This is the platform's own
 *  intended mechanism for "this screen is always one orientation, that
 *  other one isn't" — most apps that need exactly this (a fixed-orientation
 *  utility screen inside an otherwise rotating app) reach for it before
 *  ever trying to flip requestedOrientation on a live, still-rendering
 *  window, which is what the two earlier attempts here did.
 *
 *  Talks to MainActivity purely through registerForActivityResult(): picking
 *  a ROM calls setResult(RESULT_OK, Intent().setData(uri)) and finish()s;
 *  backing out with nothing picked (permission denied, system Back at the
 *  root, ✕ Close) leaves the result RESULT_CANCELED. See MainActivity's
 *  romBrowserLauncher/changeRom(). */
class RomBrowserActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "mGBA"
        // Last folder browsed, a plain absolute path (not a SAF tree Uri —
        // this Activity doesn't use SAF for browsing at all, see the
        // class doc comment's sibling reasoning in
        // MainActivity.kt/AndroidManifest.xml for the ROM browser's own
        // permission choice). Just a starting point for convenience: an
        // invalid/vanished path here isn't an error, it's treated exactly
        // like "nothing remembered yet" and falls back to the device root
        // — see openAtRoot().
        private const val PREF_ROMS_LAST_FOLDER = "roms_last_folder"
    }

    private lateinit var listLayout: LinearLayout
    private lateinit var pathText: TextView
    private lateinit var backBtn: TextView

    // deviceRoot is the practical ceiling "Up" stops at — all of local
    // shared storage, not just one previously-picked folder. Computed once
    // since it never changes over the process lifetime.
    private val deviceRoot: File by lazy { Environment.getExternalStorageDirectory() }
    private val stack: MutableList<File> = mutableListOf()
    // Bumped on every folder navigation so a background zip-content scan
    // (see refreshList()) started for a folder the user has since left can
    // recognize its own result as stale and discard it instead of
    // overwriting whatever folder is actually on screen by the time it
    // finishes.
    @Volatile private var generation = 0
    @Volatile private var pickerLive = false

    private var pendingFileAccessAction: (() -> Unit)? = null

    private val legacyStoragePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val action = pendingFileAccessAction; pendingFileAccessAction = null
        if (granted) action?.invoke()
        else uiToast("Storage permission is needed to browse for ROMs")
    }

    // Android doesn't reliably report grant/deny in this screen's result
    // code across OEM skins, so this re-checks the real permission state
    // via hasBroadFileAccess() on return instead of trusting the callback
    // argument either way.
    private val allFilesAccessLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        val action = pendingFileAccessAction; pendingFileAccessAction = null
        if (hasBroadFileAccess()) action?.invoke()
        else uiToast("Storage access wasn't granted — can't browse the device for ROMs")
    }

    // Escape hatch: the classic single-file system picker, for anything
    // free-roam local browsing can't reach at all — a cloud-backed SAF
    // provider (Drive, Dropbox, ...) — or in case direct File access ever
    // misbehaves for someone's device. Needs no storage permission of its
    // own (that's the whole point of SAF), so this stays usable even if
    // broad file access above was denied.
    private val romPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        pickerLive = false
        uri ?: return@registerForActivityResult
        setResult(RESULT_OK, Intent().setData(uri))
        finish()
    }

    private fun hasBroadFileAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }

    /** Runs [action] immediately if broad file access is already granted,
     *  otherwise asks for it first — a normal runtime permission dialog on
     *  API < 30, or the dedicated "All files access" system Settings screen
     *  on API 30+, since that one *can't* be granted from an in-app dialog
     *  at all. Safe to call repeatedly: once granted, every later call just
     *  runs [action] straight away with no prompt. */
    private fun ensureBroadFileAccess(action: () -> Unit) {
        if (hasBroadFileAccess()) { action(); return }
        pendingFileAccessAction = action
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            uiToast("Pick \"Allow access to manage all files\" on the next screen")
            try {
                allFilesAccessLauncher.launch(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                // A handful of OEM skins don't ship the per-app variant of
                // this screen — fall back to the general all-apps list one,
                // which every API 30+ device has.
                Log.w(TAG, "per-app All files access screen unavailable, using general one", e)
                allFilesAccessLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            legacyStoragePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())

        // System Back navigates up a folder first, same as most real file
        // managers; only exits (cancelled, same as ✕ Close) once already at
        // the root. OnBackPressedCallback (the base androidx.activity API,
        // not the activity-ktx addCallback{} lambda extension — this
        // project's build.gradle.kts doesn't have that artifact declared,
        // only appcompat, which pulls in base androidx.activity
        // transitively) is the modern, predictive-back-gesture-aware way
        // to do this on this app's targetSdk.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (stack.size > 1) up() else { setResult(RESULT_CANCELED); finish() }
            }
        })

        ensureBroadFileAccess { openAtRoot() }
    }

    /** Builds the navigation stack from deviceRoot down to [target] — used
     *  to restore the browser to wherever it was last left (see
     *  PREF_ROMS_LAST_FOLDER) instead of always reopening at the device
     *  root. Falls back to just the root alone if [target] isn't actually
     *  inside deviceRoot at all (a stale remembered path whose folder has
     *  since moved or been deleted, most likely). */
    private fun buildBrowserStack(target: File): MutableList<File> {
        val chain = mutableListOf<File>()
        var f: File? = target
        while (f != null) {
            chain.add(f)
            if (f == deviceRoot) break
            f = f.parentFile
        }
        return if (chain.last() == deviceRoot) chain.asReversed().toMutableList() else mutableListOf(deviceRoot)
    }

    private fun openAtRoot() {
        val savedPath = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_ROMS_LAST_FOLDER, null)
        val start = savedPath?.let { File(it) }?.takeIf { it.isDirectory } ?: deviceRoot
        stack.clear()
        stack.addAll(buildBrowserStack(start))
        refreshList()
    }

    private fun up() {
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            refreshList()
        }
    }

    // .zip entries are not trusted by name alone. A folder's cheap parts —
    // subfolders and bare .gba files — render immediately below; any .zip
    // files found are content-checked in the background (see
    // RomZipUtils.zipContainsGba()) and folded into the list once that
    // finishes, rather than blocking folder navigation on a scan of every
    // archive up front. generation lets a scan that finishes after the
    // user has already navigated elsewhere recognize itself as stale and
    // discard its result instead of overwriting whatever folder is
    // actually on screen by then.
    private fun refreshList() {
        val myGeneration = ++generation
        val current = stack.last()
        pathText.text = stack.joinToString(" / ") {
            if (it == deviceRoot) "Internal storage" else it.name
        }
        backBtn.visibility = if (stack.size > 1) View.VISIBLE else View.INVISIBLE
        // Remembered so reopening the browser later starts back here
        // instead of the device root every time — see openAtRoot(). Written
        // on every navigation rather than only on close, so the app being
        // killed mid-browse doesn't lose it.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(PREF_ROMS_LAST_FOLDER, current.path)
            .apply()

        val all = (current.listFiles() ?: emptyArray()).toList()
        val immediate = all
            .filter { f -> f.isDirectory || f.name.endsWith(".gba", ignoreCase = true) }
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
        val zipCandidates = all.filter { f -> f.isFile && f.name.endsWith(".zip", ignoreCase = true) }

        renderList(immediate, stillScanning = zipCandidates.isNotEmpty())
        if (zipCandidates.isEmpty()) return

        // Each candidate still needs its own open-and-scan off the main
        // thread — real disk I/O, potentially many files in the folder.
        // Simple sequential Thread, matching this project's existing
        // choices elsewhere over a thread pool; see KNOWN_LIMITATIONS.md.
        Thread {
            val verifiedZips = zipCandidates.filter { f ->
                try {
                    RomZipUtils.zipContainsGba(contentResolver, Uri.fromFile(f))
                } catch (e: Throwable) {
                    Log.e(TAG, "zip content scan failed for ${f.name}", e)
                    false
                }
            }
            Handler(Looper.getMainLooper()).post zipScanDone@ {
                // Stale if the user has since navigated to a different
                // folder (or reopened this same one) or the activity is on
                // its way down — same guard shape MainActivity's own
                // loadRomFromUri() uses for its posted completion.
                if (generation != myGeneration) return@zipScanDone
                if (isFinishing || isDestroyed) return@zipScanDone
                val merged = (immediate + verifiedZips)
                    .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                renderList(merged, stillScanning = false)
            }
        }.apply { name = "mGBA-rom-zip-scan" }.start()
    }

    /** Renders one pass of the file list. [stillScanning] adds a trailing
     *  "Checking archives…" row and — importantly — suppresses the "No
     *  ROMs or folders here" empty state, since an empty [entries] here
     *  only means no folders/.gba files were found *yet*, not that the
     *  folder is actually empty; a background zip scan may still add
     *  entries (see refreshList()). */
    private fun renderList(entries: List<File>, stillScanning: Boolean) {
        listLayout.removeAllViews()
        if (entries.isEmpty() && !stillScanning) {
            listLayout.addView(messageRow("No ROMs or folders here"))
            return
        }
        entries.forEach { f -> listLayout.addView(row(f)) }
        if (stillScanning) {
            listLayout.addView(messageRow("Checking archives…"))
        }
    }

    /** Shared styling for the small status rows ("No ROMs or folders
     *  here", "Checking archives…") — one look, two call sites. */
    private fun messageRow(message: String): TextView = TextView(this).apply {
        text = message
        textSize = 13f
        setTextColor(Color.parseColor("#888892"))
        setPadding(dp(20), dp(20), dp(20), dp(20))
    }

    private fun row(file: File): View {
        val ctx = this
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            isClickable = true; isFocusable = true
            setBackgroundResource(ripple.resourceId)
            setPadding(dp(20), dp(14), dp(20), dp(14))
            addView(TextView(ctx).apply {
                text = if (file.isDirectory) "📁" else "🎮"
                textSize = 18f
                setTextColor(colorAccentLight)
            }, LinearLayout.LayoutParams(dp(40), LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(TextView(ctx).apply {
                text = file.name
                textSize = 15f
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            setOnClickListener {
                if (file.isDirectory) {
                    stack.add(file)
                    refreshList()
                } else {
                    setResult(RESULT_OK, Intent().setData(Uri.fromFile(file)))
                    finish()
                }
            }
        }
    }

    private fun buildUi(): View {
        val ctx = this

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(16), dp(14))
            addView(TextView(ctx).apply {
                text = "Load game"; textSize = 22f; typeface = Typeface.DEFAULT_BOLD
                setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(TextView(ctx).apply {
                text = "✕ Close"; textSize = 13f
                setTextColor(colorAccentLight)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                isClickable = true; isFocusable = true
                background = iconChipBackground()
                setOnClickListener { setResult(RESULT_CANCELED); finish() }
            })
        }

        val pathRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(4), dp(20), dp(10))
            backBtn = TextView(ctx).apply {
                text = "⟵"; textSize = 16f
                setTextColor(Color.WHITE)
                setPadding(dp(4), dp(4), dp(14), dp(4))
                isClickable = true; isFocusable = true
                setOnClickListener { up() }
            }
            addView(backBtn)
            pathText = TextView(ctx).apply {
                textSize = 13f
                setTextColor(colorAccentLight)
            }
            addView(pathText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }

        listLayout = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        val fallbackRow = TextView(ctx).apply {
            text = "Use system file picker instead"
            textSize = 12f
            setTextColor(Color.parseColor("#888892"))
            setPadding(dp(20), dp(10), dp(20), dp(16))
            isClickable = true; isFocusable = true
            setOnClickListener {
                if (!pickerLive) { pickerLive = true; romPicker.launch(arrayOf("*/*")) }
            }
        }

        // Full screen, edge to edge — unlike Thirty-first pass's version of
        // this screen (an overlay inside MainActivity, back when it needed
        // a centered, width-capped "panel" to fake a portrait look inside
        // an actually-landscape window), this Activity's whole window
        // really is portrait now, so there's nothing to fake and nothing
        // to center against.
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#FF17171B"))
            addView(header)
            addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1).coerceAtLeast(1)))
            addView(pathRow)
            addView(ScrollView(ctx).apply { addView(listLayout) },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(fallbackRow)
        }
    }
}
