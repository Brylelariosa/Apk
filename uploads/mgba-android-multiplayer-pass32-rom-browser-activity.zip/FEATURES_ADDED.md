# FEATURES_ADDED — Thirty-second pass

The ROM browser, a third time. User feedback on Thirty-first pass's
version: remove the Root button (the ⟵ back arrow already covers it —
agreed, done), and pushed back on the no-rotation panel compromise,
citing My Boy's own file manager as an existing example of exactly what
was wanted: Portrait for ROM selection, a different rotation for
gameplay, changeable in Settings. That's a fair example — this pass
found an approach that gets the real thing without the crash risk the
last two attempts carried.

## Root button removed

**Description:** The "🏠 Root" quick-jump button (Thirty-first pass) is
gone from the header. The ⟵ back arrow already reaches anywhere, one
folder at a time, and a second button doing an overlapping job wasn't
worth the space.
**Files modified:** `RomBrowserActivity.kt` (did not exist as a separate
file yet when this was first added — see below).

## Real Portrait rotation for ROM selection, via a separate Activity

**Description:** ROM selection is now its own Activity
(`RomBrowserActivity.kt`), launched from `MainActivity.changeRom()` and
returning its pick through `registerForActivityResult()`, rather than an
overlay drawn inside MainActivity's own window. Its manifest entry
declares `android:screenOrientation="portrait"` — a static, per-Activity
orientation lock, set once, entirely at the platform level. No
`requestedOrientation` call exists anywhere in `RomBrowserActivity.kt`.

**Why this actually solves it, not just hides it:** the previous two
attempts at Portrait for this screen both changed orientation *at
runtime* on a *live window* — first outright, then with the change
carefully spaced apart from other view work, which is the standard fix
for exactly this class of race and still weren't enough; both caused a
real native RenderThread SIGABRT on an actual device
("drawRenderNode called on a context with no surface!"). A statically
declared per-Activity orientation goes through a completely different
path at the platform level — there's no runtime "change" for
RenderThread to race against, because the orientation was never anything
but Portrait for this Activity's whole lifetime. And since
`RomBrowserActivity` is a genuinely separate window, MainActivity's game
surface is fully paused while it's in front — no shared window for a
game frame and a browser frame to ever collide in either, which was
arguably the bigger risk given mGBA's own render thread is continuously
active during gameplay in a way most apps' UI isn't.

**User benefit:** The actual behavior asked for and demonstrated by My
Boy — Portrait file manager, a separately configurable rotation for
gameplay (Settings → Video → Screen orientation, unchanged, still
defaults to Landscape) — without reintroducing a crash this project has
now hit twice.

**Back button now navigates folders:** since this is a real Activity
with its own back-stack participation, system Back (button or gesture)
now goes up one folder at a time, same as most real file managers, and
only exits ROM selection once already at the root — a natural
improvement free-roam browsing enables that wasn't really coherent to
add while this was an overlay with no back-stack presence of its own.

**Files modified:** `AndroidManifest.xml` (new `RomBrowserActivity`
entry); `MainActivity.kt` (all ROM-browser-specific code removed — see
FILE_CHANGES.md for the full list — replaced with a single
`romBrowserLauncher` that starts the new Activity and hands its result to
the existing, unchanged `loadRomFromUri()`); two new shared files,
`RomZipUtils.kt` (the zip-signature/content-check logic, needed by both
`MainActivity.stageRomFile()` and the new Activity's listing) and
`SharedUi.kt` (the small UI helpers — `dp()`, `uiToast()`,
`colorAccentLight`, `iconChipBackground()` — both need, as `Context`/
`Activity` extension functions rather than a shared base class, so
`MainActivity`'s own class hierarchy didn't need touching at all for
this); `RomBrowserActivity.kt` (new — everything that used to be
`buildRomBrowser()`/`refreshRomBrowserList()`/etc. inside MainActivity,
adapted to standalone-Activity shape).

**Note:** this is the platform's own recommended pattern for "one screen
in an otherwise-rotating app needs a fixed orientation" — most apps that
need this reach for a separate, statically-locked Activity before ever
touching `requestedOrientation` on a live window, which is what both
earlier attempts here did instead. Still unconfirmed on a real device —
see KNOWN_LIMITATIONS.md — but it avoids the *specific* failure mode
both previous attempts hit, by construction rather than by tuning.

---

# FEATURES_ADDED — Thirty-first pass

Two related changes from one request, both about the ROM browser again —
this revises part of what Thirtieth pass shipped rather than sitting
alongside it unchanged. Thirtieth pass's own feature (content-verified zip
filtering) carries forward as-is; what changes here is the browsing model
underneath it and the screen's shape.

## 1. Free-roam file manager (was: one SAF-picked folder tree)

**Description:** The ROM browser no longer depends on Storage Access
Framework's `OpenDocumentTree` picker for a single, pre-granted folder.
It now reads `java.io.File` directly against the whole of local shared
storage, gated by a new `ensureBroadFileAccess()` permission flow: the
"All files access" system Settings screen on Android 11+
(`MANAGE_EXTERNAL_STORAGE`), or a normal runtime permission dialog below
that (`READ_EXTERNAL_STORAGE`). The "📂 Change folder" button is gone —
there's no separate folder concept left to change — replaced with a
"🏠 Root" button that jumps straight back to the device root from
anywhere. The last folder browsed is remembered (`PREF_ROMS_LAST_FOLDER`,
a plain path string now, not a SAF tree Uri) and restored on reopen.

**User benefit:** Genuine free navigation anywhere in local storage, not
just inside one folder granted up front — matching what "its own file
manager" actually implied. Should also read as noticeably less laggy:
opening a folder is now a direct local read instead of a cross-process
call into Android's storage provider, which the pre-existing code already
flagged as a possible source of a "brief hitch" — see KNOWN_LIMITATIONS.md.

**Files modified:** `AndroidManifest.xml` (new `READ_EXTERNAL_STORAGE` /
`MANAGE_EXTERNAL_STORAGE` permissions, `requestLegacyExternalStorage`);
`MainActivity.kt` (`romTreePicker`/`romTreeUri`/`PREF_ROMS_TREE_URI`
removed; new `ensureBroadFileAccess()`/`hasBroadFileAccess()` and their
two launchers; `romBrowserStack` now `MutableList<File>`; new
`romBrowserDeviceRoot`/`buildBrowserStack()`; `openRomBrowserAtRoot()`,
`refreshRomBrowserList()`, `romBrowserRow()` all rewritten for `File`
instead of `DocumentFile`). `stageRomFile()`/`zipContainsGba()`/
`loadRomFromUri()` — Thirtieth pass's zip-filtering work — needed *no*
changes at all: every ROM load already went through a plain absolute
path (`EmulatorEngine.nativeLoadROM(tmp.absolutePath, ...)`), so the
browser just hands a `Uri.fromFile(file)` to the same `loadRomFromUri()`
it always called, unchanged.

**Note:** this deliberately reverses an earlier, well-reasoned decision
(see the block comment above `openRomBrowserAtRoot()`) to keep ROM
browsing permission-free by staying on SAF. That reasoning was correct
for what it optimized for; it stops being correct once free navigation
without a folder-picking step is the actual goal, which is what was
asked for here. Made knowingly, not overlooked.

## 2. Portrait-styled file manager panel (no device rotation)

**Description:** The browser now renders as a rounded, width-capped panel
(max 420dp, or 94% of screen width if narrower) centered over a dimmed
backdrop, instead of one edge-to-edge column filling the whole screen —
tall and narrow like a portrait phone screen, regardless of the app's
actual current orientation. No `requestedOrientation` call anywhere in
this screen's code, on open, close, or load.

**User benefit:** The portrait-list look originally wanted for this
screen, without the crash a real forced rotation caused here two passes
ago (native RenderThread SIGABRT — see BUGS_FIXED.md/CHANGELOG.md, and
the block comment above `openRomBrowserAtRoot()`, which had already
floated this exact panel approach as the safer alternative back then).

**Files modified:** `MainActivity.kt` (`buildRomBrowser()` returns
`FrameLayout` now, not `LinearLayout`; `romBrowserOverlay`'s declared type
updated to match; existing header/pathRow/list/fallback content unchanged
internally, just wrapped in a new rounded `panel` inside a dimmed
backdrop `FrameLayout`).

---

# FEATURES_ADDED — Thirtieth pass

One feature, closing a real gap in the Fourteenth pass's ROM browser: it
has always listed every `.zip` in a folder by extension alone, trusting
the name rather than looking inside — so a save-data backup, a screenshot
batch, or any other archive kept next to ROMs showed up in the list
exactly as if it were a game.

## Content-verified zip filtering in the ROM browser

**Description:** The ROM browser (`refreshRomBrowserList()`) now opens
each `.zip` it finds and checks for a real `.gba` entry inside — via the
same magic-bytes-first approach the Fourteenth pass's transparent zip
loading already used, now shared through a new `isZipSignature()` helper
— before showing it in the list at all. Folders and bare `.gba` files
still render immediately, exactly as before; `.zip` files are verified in
the background and folded into the list once that finishes, so opening a
folder never blocks on scanning every archive in it up front. A new
`romBrowserGeneration` counter discards a scan's result if the user has
already navigated to a different folder by the time it completes.

**User benefit:** The "Load game" list only ever shows `.zip` files that
are actually GBA ROMs — no more picking through an archive that turns out
to be something else once tapped. Directories and `.gba` entries appear
with no added delay; only `.zip` files wait on the (typically sub-second)
content check, with a "Checking archives…" row shown while that's still
in flight.

**Files modified:** `MainActivity.kt` — `refreshRomBrowserList()`
rewritten to split immediate entries from zip candidates and run the zip
check on a background `Thread`; new `zipContainsGba()`,
`renderRomBrowserList()`, `romBrowserMessageRow()`, and
`romBrowserGeneration` field; `stageRomFile()`'s magic-bytes check
extracted into shared `isZipSignature()` so the browser's check and the
actual load-time extraction can't drift apart from each other over a
future pass; the now-redundant `romRelevantExtensions` list removed.

**Note:** deliberately still uses `ContentResolver.openInputStream()` +
`ZipInputStream` (streaming, one entry at a time) rather than
`ZipFile`'s random-access central-directory read, which would be faster
per archive but needs real seekable file access that an arbitrary SAF
provider isn't guaranteed to support. See KNOWN_LIMITATIONS.md for the
full reasoning, including why the project's existing `/proc/self/fd/<N>`
shortcut (tried elsewhere, found unreliable on a real device) wasn't
reused here either.

---

# FEATURES_ADDED — Twentieth pass

**Storage folder** (Settings → Storage): pick a folder anywhere visible in
a file manager, and every battery save, save-state (+ thumbnail),
quicksave, and screenshot goes there from then on, organized into `save`/
`cheat`/`screenshot` subfolders, instead of this app's own internal
storage. `cheat` sits ready for whenever a cheat-file feature exists — not
added this pass. Opt-in: nothing changes for anyone who doesn't visit
Settings → Storage. No migration of existing saves — see
KNOWN_LIMITATIONS.md and CHANGELOG.md for the full reasoning.

---

# FEATURES_ADDED — Seventeenth pass

One feature, prompted by hitting a real limitation of Twelfth pass's
original debug-log tool: it depended on OS logcat access, which turns out
not to work on every phone.

## Durable, logcat-independent link debug logging

**Description:** The "Copy link log" tool (quick game menu) no longer
shells out to `logcat`. `mgba_jni.c`'s `LOGI`/`LOGW`/`LOGE` calls, plus
`LinkMultiplayer.kt`'s own connection-lifecycle log lines, now also write
to a plain private file this app owns outright (`filesDir/
link_debug.log`) — no permission needed, no dependency on OS logcat access
of any kind, on any OEM build. The file resets fresh at the start of every
link connection attempt (`nativeLinkStart()`), so a capture reflects one
attempt rather than accumulating across a whole app session, with an 8MB
backstop cap for the rare session that runs long before anyone reads it.

**User benefit:** The debug-log tool now works the same way on every
phone, including the one where the old logcat-based version returned
nothing at all — confirmed by W's own side-by-side test (real output on
one phone, empty on the other, same build, same tool). This specifically
unblocks getting a synchronized capture from *both* phones during the same
connection attempt, which every pass investigating the multiplayer issue
since the Twelfth has needed and not been able to get.

**Files modified:** `mgba_jni.c` (the actual file-writing logic and the
new `nativeSetLinkLogPath()` entry point), `EmulatorEngine.kt` (JNI
declaration), `MainActivity.kt` (calls it once from `onCreate()`;
`copyLinkDebugLog()` reads the file instead of invoking `logcat`),
`LinkMultiplayer.kt` (mirrors its own 7 log lines into the same file via a
new `linkLog()` helper, so one file has everything the old combined
3-tag logcat filter used to).

---

# FEATURES_ADDED — Fourteenth pass

Three related changes from one request, all in `changeRom()`'s neighborhood:
transparent zip loading, an in-app file-manager-style ROM browser to
replace the raw system picker, and a Screen orientation setting. Requested
against a reference screenshot of another emulator's Video settings and
"Load game" screen — matched the general shape (file-manager layout,
five-way orientation dialog) rather than that app's exact code, which
this project has no access to and wouldn't want to depend on anyway (see
storage-permission note below for why the underlying approach couldn't be
identical even if it were available).

## 1. Transparent zip ROM loading

**Description:** Any ROM entry point (system picker or the new browser
below) now accepts a `.zip` containing a `.gba` directly — no separate
extraction step. Detected by the real zip magic bytes ("PK\x03\x04"), not
the file's name, so a misnamed archive still works and a same-named non-zip
file is correctly rejected rather than handed to the core as garbage. See
`stageRomFile()` in `MainActivity.kt`.

**User benefit:** Most GBA ROM distributions are a `.zip` with one `.gba`
inside it (see the reference screenshot's own "Load game" list — almost
every entry is a `.zip`); previously each one had to be extracted by hand
before this app could open it.

**Files modified:** `MainActivity.kt` (new `stageRomFile()`; `romPicker`'s
callback and the new browser's file-tap both route through it now via the
shared `loadRomFromUri()` — see Feature 2).

## 2. In-app ROM folder browser

**Description:** `changeRom()` now opens a custom "Load game" screen
(`romBrowserOverlay`/`buildRomBrowser()`) instead of launching the system
document picker directly: a path readout, an up button, and a plain
scrollable list of subfolders and `.zip`/`.gba` files, styled to match this
app's existing Settings screen rather than the reference screenshot's
Material dialog chrome specifically. Backed by SAF's `OpenDocumentTree` +
`DocumentFile`, asked for once and persisted (`PREF_ROMS_TREE_URI`) —
**not** raw `java.io.File` against a hardcoded path like
`/storage/emulated/0/Download/Roms`.

**Reason for the SAF-tree approach instead of a literal hardcoded-path
file manager:** this app deliberately removed `READ_EXTERNAL_STORAGE`
already (see `AndroidManifest.xml`) so ROM loading needs no storage
permission at all. A literal file-manager rooted at an absolute path would
need that permission at minimum, and on this app's targetSdk 34 (API 30+
scoped storage) realistically `MANAGE_EXTERNAL_STORAGE` ("All files
access") to reach an arbitrary folder like `Download/Roms` — a real
regression from "asks for nothing but the ROM itself." Whatever the
reference app is doing to show a raw path like that, this app matches the
*look* (folders, path, up button) without taking on that permission.

**User benefit:** Browsing for a ROM now looks and works like a file
manager instead of the bare-bones system document picker (which, on many
devices/launchers, defaults to an unhelpful "Recent" view rather than the
ROMs folder).

**Files modified:** `MainActivity.kt` (new `romTreePicker`,
`openRomBrowserAtRoot()`, `refreshRomBrowserList()`, `romBrowserRow()`,
`romBrowserUp()`, `buildRomBrowser()`; `changeRom()` rewritten;
`romPicker`'s callback slimmed down, its body extracted into the new
shared `loadRomFromUri()`). `build.gradle.kts` (added the
`androidx.documentfile` dependency this needs).

**Note:** the classic system picker isn't removed — it's one tap away as
"Use system file picker instead" at the bottom of the new browser, in case
tree-based browsing ever misbehaves for someone's device or storage
provider.

## 3. Screen orientation setting

**Description:** Video settings gained a five-way "Screen orientation"
choice (Auto rotate / Landscape / Reverse landscape / Portrait / System
default), matching the reference screenshot's dialog. Was previously fixed
to landscape both in code (`requestedOrientation` set once in `onCreate`)
and in the manifest (`android:screenOrientation="landscape"`); both are now
driven by a persisted preference instead (`PREF_ORIENTATION`, applied via
the new `applyScreenOrientationPref()`), defaulting to landscape so
existing installs behave identically until this is actually changed.

**Files modified:** `MainActivity.kt` (new `applyScreenOrientationPref()`;
`showVideoSettings()` gained the radio group and its Save handling;
`onCreate()`'s hardcoded orientation line replaced). `AndroidManifest.xml`
(`android:screenOrientation` changed from `"landscape"` to `"unspecified"`
— the existing `android:configChanges` entry already keeps the activity,
and the running core, alive across the resulting orientation change
without a restart, exactly as it did for the old hardcoded value).

---

# FEATURES_ADDED — Earlier passes (summary)

Full entries trimmed for length — all unrelated to multiplayer/link.

- **Thirteenth** — Save-state thumbnails in the slot picker.
- **Tenth** — Screenshot, Reset, and Close added to the quick game menu
  (matching a reference screenshot's full item list).
- **Fifth** — Auto save-file backup (`.bak` before overwrite) and an
  optional performance overlay (core FPS + audio underrun count), off by
  default.
