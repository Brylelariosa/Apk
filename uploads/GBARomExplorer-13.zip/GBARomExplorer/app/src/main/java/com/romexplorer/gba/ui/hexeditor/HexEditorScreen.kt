@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.hexeditor

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBackIosNew
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EditOff
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.romexplorer.gba.ui.common.SectionHeader
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HexEditorScreen(navController: NavHostController, viewModel: HexEditorViewModel = koinViewModel()) {
    val session by viewModel.session.collectAsState()
    val rows by viewModel.rows.collectAsState()
    val editMode by viewModel.editMode.collectAsState()
    val status by viewModel.statusMessage.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val pageStart by viewModel.pageStart.collectAsState()

    var jumpText by remember { mutableStateOf("") }
    var searchText by remember { mutableStateOf("") }
    var searchAsHex by remember { mutableStateOf(true) }
    var showSearch by remember { mutableStateOf(false) }
    var editingByte by remember { mutableStateOf<Pair<Long, Int>?>(null) } // offset, currentValue
    var showBookmarkDialog by remember { mutableStateOf(false) }

    val saveLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri -> if (uri != null) viewModel.saveAs(uri) { } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hex Editor") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showSearch = !showSearch }) {
                        Icon(Icons.Filled.Search, contentDescription = "Search")
                    }
                    IconButton(onClick = { viewModel.undo() }, enabled = viewModel.canUndo()) {
                        Icon(Icons.Filled.Undo, contentDescription = "Undo")
                    }
                    IconButton(onClick = { viewModel.redo() }, enabled = viewModel.canRedo()) {
                        Icon(Icons.Filled.Redo, contentDescription = "Redo")
                    }
                    IconButton(onClick = { viewModel.toggleEditMode() }) {
                        Icon(
                            imageVector = if (editMode) Icons.Filled.EditOff else Icons.Filled.Edit,
                            contentDescription = "Toggle edit mode",
                        )
                    }
                    IconButton(onClick = {
                        saveLauncher.launch("${session?.displayName ?: "rom"}_edited.gba")
                    }) {
                        Icon(Icons.Filled.Save, contentDescription = "Save As")
                    }
                },
            )
        },
    ) { padding ->
        if (session == null) {
            Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                Text("No ROM is currently open.")
            }
            return@Scaffold
        }

        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp)) {

            if (editMode) {
                Text("Edit mode is ON — tap a byte to change it.", modifier = Modifier.padding(top = 4.dp))
            }
            status?.let { Text(it, modifier = Modifier.padding(top = 4.dp)) }

            if (showSearch) {
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    OutlinedTextField(
                        value = searchText,
                        onValueChange = { searchText = it },
                        label = { Text(if (searchAsHex) "Hex bytes (e.g. 10 4A FF)" else "ASCII text") },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                    )
                    IconButton(onClick = { searchAsHex = !searchAsHex }) {
                        Text(if (searchAsHex) "Hex" else "Txt")
                    }
                    IconButton(onClick = { viewModel.search(searchText, searchAsHex) }) {
                        Icon(Icons.Filled.Search, contentDescription = "Run search")
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
            ) {
                IconButton(onClick = { viewModel.previousPage() }) {
                    Icon(Icons.Filled.ArrowBackIosNew, contentDescription = "Previous page")
                }
                OutlinedTextField(
                    value = jumpText,
                    onValueChange = { jumpText = it },
                    label = { Text("Jump to offset (hex)") },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                )
                TextButton(onClick = {
                    val offset = jumpText.removePrefix("0x").toLongOrNull(16)
                    if (offset != null) viewModel.jumpToOffset(offset)
                }) { Text("Go") }
                IconButton(onClick = { viewModel.nextPage() }) {
                    Icon(Icons.Filled.ArrowForwardIos, contentDescription = "Next page")
                }
            }

            Text(
                text = "Offset 0x${pageStart.toString(16).uppercase().padStart(8, '0')}",
                modifier = Modifier.padding(bottom = 4.dp),
            )

            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f).horizontalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                items(rows, key = { it.offset }) { row ->
                    HexRowView(
                        row = row,
                        editable = editMode,
                        onByteTap = { offset, value -> editingByte = offset to value },
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                TextButton(onClick = { showBookmarkDialog = true }) {
                    Icon(Icons.Filled.Bookmark, contentDescription = null)
                    Text(" Bookmark this page")
                }
            }

            if (bookmarks.isNotEmpty()) {
                SectionHeader("Bookmarks")
                bookmarks.take(5).forEach { bm ->
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        onClick = { viewModel.jumpToOffset(bm.offset) },
                    ) {
                        Row(modifier = Modifier.padding(8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${bm.label} — 0x${bm.offset.toString(16)}", modifier = Modifier.weight(1f))
                            TextButton(onClick = { viewModel.removeBookmark(bm.offset) }) { Text("Remove") }
                        }
                    }
                }
            }
        }
    }

    editingByte?.let { (offset, currentValue) ->
        var text by remember(offset) { mutableStateOf(currentValue.toString(16).uppercase().padStart(2, '0')) }
        AlertDialog(
            onDismissRequest = { editingByte = null },
            title = { Text("Edit byte at 0x${offset.toString(16)}") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { if (it.length <= 2) text = it },
                    label = { Text("Hex value (00-FF)") },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    text.toIntOrNull(16)?.let { viewModel.editByte(offset, it) }
                    editingByte = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editingByte = null }) { Text("Cancel") } },
        )
    }

    if (showBookmarkDialog) {
        var label by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showBookmarkDialog = false },
            title = { Text("Add bookmark") },
            text = {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("Label") },
                    singleLine = true,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.addBookmark(pageStart, label.ifBlank { "Bookmark" })
                    showBookmarkDialog = false
                }) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showBookmarkDialog = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun HexRowView(row: HexRow, editable: Boolean, onByteTap: (Long, Int) -> Unit) {
    Row(modifier = Modifier.padding(vertical = 1.dp)) {
        Text(
            text = row.offset.toString(16).uppercase().padStart(8, '0'),
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            modifier = Modifier.width(74.dp),
        )
        row.bytes.forEachIndexed { i, value ->
            val edited = row.editedMask.getOrElse(i) { false }
            Text(
                text = value.toString(16).uppercase().padStart(2, '0'),
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp,
                modifier = Modifier
                    .width(24.dp)
                    .background(if (edited) androidx.compose.ui.graphics.Color(0xFFFFF59D) else androidx.compose.ui.graphics.Color.Transparent)
                    .clickable(enabled = editable) { onByteTap(row.offset + i, value) },
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = row.bytes.map { b -> if (b in 0x20..0x7E) b.toChar() else '.' }.joinToString(""),
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
        )
    }
}
