package com.volumetile.app

import android.content.Intent
import android.media.AudioManager
import android.provider.Settings
import android.service.quicksettings.Tile
import androidx.annotation.StringRes

/**
 * A tile that fires one [SystemAction] through [SystemActionService].
 *
 * Look: highlighted when ready; greyed with a hint subtitle when the accessibility
 * service still needs switching on, when it is paused (for GCash, say) or the Android
 * version is too old for the action. Tapping a greyed tile switches the service back on
 * when the one-time permission is in place ([ServiceSwitch]), and otherwise jumps to
 * Accessibility settings.
 *
 * If the service is switched on but the system has stopped running it, a tap revives it the
 * same way, or says so and jumps to the same Settings page, where flipping the switch off
 * and on revives it.
 */
abstract class ActionTileService(
    private val action: SystemAction,
    private val readySubtitleRes: Int = 0
) : BaseTileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        if (!action.isSupported) {
            toast(R.string.toast_unsupported)
            return
        }
        if (!SystemActionService.isEnabled(this)) {
            // Paused, or never switched on. With the one-time permission one tap switches it on;
            // the tile then has to be tapped again once the system has bound the service.
            if (ServiceSwitch.setEnabled(this, true)) {
                toast(R.string.toast_service_resuming)
            } else {
                val message =
                    if (ProtectedApps.isPaused(this)) R.string.toast_resume_service
                    else R.string.toast_enable_service
                openAccessibilitySettings(message)
            }
            return
        }
        if (SystemActionService.dispatch(action)) return

        // Switched on but not connected. Right after a process restart the system is about to
        // bind the service, so give it a moment; if it still hasn't, the system has dropped it
        // and only switching it off and on brings it back.
        if (SystemActionService.isStalled(this)) {
            if (ServiceSwitch.restart(this)) {
                toast(R.string.toast_service_resuming)
            } else {
                openAccessibilitySettings(R.string.toast_restart_service)
            }
        } else {
            toast(R.string.toast_service_starting)
        }
    }

    private fun refreshTile() {
        val label = getString(action.labelRes)
        when {
            !action.isSupported ->
                renderTile(Tile.STATE_INACTIVE, label, getString(R.string.tile_subtitle_unsupported))
            !SystemActionService.isEnabled(this) -> {
                val subtitle =
                    if (ProtectedApps.isPaused(this)) R.string.tile_subtitle_paused
                    else R.string.tile_subtitle_enable
                renderTile(Tile.STATE_INACTIVE, label, getString(subtitle))
            }
            SystemActionService.isStalled(this) ->
                renderTile(Tile.STATE_INACTIVE, label, getString(R.string.tile_subtitle_restart))
            else -> {
                val subtitle = if (readySubtitleRes != 0) getString(readySubtitleRes) else null
                renderTile(Tile.STATE_ACTIVE, label, subtitle)
            }
        }
    }

    private fun openAccessibilitySettings(@StringRes message: Int) {
        toast(message)
        startActivityAndCollapseCompat(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
}

/** Collapses the shade, then screenshots the app underneath. */
class ScreenshotTileService : ActionTileService(SystemAction.SCREENSHOT)

/** Screenshots with the shade still open, i.e. captures the notification area. Never scrolls. */
class ShadeScreenshotTileService : ActionTileService(
    SystemAction.SHADE_SCREENSHOT,
    R.string.tile_shade_screenshot_subtitle
)

/** Opens the system power menu, same as holding the power button. */
class PowerMenuTileService : ActionTileService(SystemAction.POWER_MENU)

/**
 * Pauses and resumes the accessibility service from the shade. GCash refuses to run while the
 * service is on ([ProtectedApps]), so this is the tile to tap first: it works whatever the
 * service is doing, because a tile is not part of the service.
 *
 *  - On (highlighted): tap to pause. The service switches itself off.
 *  - Paused or off: tap to switch it back on - in place when the one-time permission is in
 *    place ([ServiceSwitch]), otherwise by jumping to Accessibility settings.
 *  - Stopped by Android: tap to revive it, the same two ways.
 */
class ServiceTileService : BaseTileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        val label = getString(R.string.tile_service_short)
        when {
            // Running: pause it. The tile is redrawn by hand, because the system takes a moment
            // to unbind the service and it would still look connected for that moment.
            SystemActionService.isConnected() -> {
                SystemActionService.pauseNow()
                renderTile(Tile.STATE_INACTIVE, label, getString(R.string.tile_subtitle_paused))
            }
            !SystemActionService.isEnabled(this) -> {
                if (ServiceSwitch.setEnabled(this, true)) {
                    toast(R.string.toast_service_resuming)
                    renderTile(Tile.STATE_INACTIVE, label, getString(R.string.tile_subtitle_starting))
                } else {
                    val message =
                        if (ProtectedApps.isPaused(this)) R.string.toast_resume_service
                        else R.string.toast_enable_service
                    toast(message)
                    startActivityAndCollapseCompat(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            SystemActionService.isStalled(this) -> {
                if (ServiceSwitch.restart(this)) {
                    toast(R.string.toast_service_resuming)
                } else {
                    toast(R.string.toast_restart_service)
                    startActivityAndCollapseCompat(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            }
            else -> toast(R.string.toast_service_starting)
        }
    }

    private fun refreshTile() {
        val label = getString(R.string.tile_service_short)
        when {
            SystemActionService.isConnected() ->
                renderTile(Tile.STATE_ACTIVE, label, getString(R.string.tile_subtitle_pause))
            !SystemActionService.isEnabled(this) -> {
                val subtitle =
                    if (ProtectedApps.isPaused(this)) R.string.tile_subtitle_paused
                    else R.string.tile_subtitle_enable
                renderTile(Tile.STATE_INACTIVE, label, getString(subtitle))
            }
            SystemActionService.isStalled(this) ->
                renderTile(Tile.STATE_INACTIVE, label, getString(R.string.tile_subtitle_restart))
            // Switched on, and the system is about to bind it.
            else -> renderTile(Tile.STATE_INACTIVE, label, getString(R.string.tile_subtitle_starting))
        }
    }
}

/**
 * A tile for one of the volume actions: Louder, Quieter or Mute. The point of the app is to
 * stand in for a broken volume button, and one tile per button is the closest thing - tap it
 * again and again to keep going, with the system volume panel showing the level.
 *
 * Unlike the tiles above they never go through the accessibility service, so they keep
 * working while it is paused for GCash, or switched off.
 */
abstract class VolumeActionTileService(private val action: SystemAction) : BaseTileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        try {
            when (action) {
                SystemAction.VOLUME_UP -> stepMediaVolume(up = true)
                SystemAction.VOLUME_DOWN -> stepMediaVolume(up = false)
                SystemAction.VOLUME_MUTE -> toggleMediaMute()
                else -> showSystemVolumePanel()
            }
        } catch (e: RuntimeException) {
            toast(R.string.toast_action_failed)
        }
        refreshTile()
    }

    private fun refreshTile() {
        val label = getString(action.labelRes)
        if (action != SystemAction.VOLUME_MUTE) {
            renderTile(Tile.STATE_ACTIVE, label, "${mediaVolumePercent()}%")
            return
        }
        // Mute lights up while the media volume is muted.
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        if (audioManager.isStreamMute(AudioManager.STREAM_MUSIC)) {
            renderTile(Tile.STATE_ACTIVE, label, getString(R.string.tile_subtitle_muted))
        } else {
            renderTile(Tile.STATE_INACTIVE, label, "${mediaVolumePercent()}%")
        }
    }
}

/** One step louder on the media volume (or the level set in the app). */
class VolumeUpTileService : VolumeActionTileService(SystemAction.VOLUME_UP)

/** One step quieter on the media volume (or the level set in the app). */
class VolumeDownTileService : VolumeActionTileService(SystemAction.VOLUME_DOWN)

/** Mutes the media volume, or brings it back. */
class VolumeMuteTileService : VolumeActionTileService(SystemAction.VOLUME_MUTE)
