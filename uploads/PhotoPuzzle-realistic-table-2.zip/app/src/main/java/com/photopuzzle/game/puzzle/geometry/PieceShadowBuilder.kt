package com.photopuzzle.game.puzzle.geometry

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * A soft, alpha-only image covering [worldWidth] x [worldHeight] table units, kept as raw bytes
 * (one per pixel, rows packed tight) so it can go to the GPU exactly as it is. [width] and
 * [height] are always multiples of four, which keeps every row aligned however the upload is
 * done.
 */
internal class SoftMask(
    val pixels: ByteArray,
    val width: Int,
    val height: Int,
    val worldWidth: Float,
    val worldHeight: Float
)

/**
 * Pre-blurred silhouettes: one per piece, for its shadow. Pure CPU work, so it is done on the
 * builder's worker thread along with the rest of the cutting.
 */
internal object PieceShadowBuilder {

    private const val MAX_SIDE_PX = 160f
    private const val MAX_PX_PER_UNIT = 1.2f

    /**
     * The piece's outline, filled and blurred, with [pad] table units of margin all round so the
     * blur has room to fade out. [polygon] is x / z pairs relative to the piece's own centre.
     * Null if the platform refuses (the piece then simply has no shadow).
     */
    fun build(
        polygon: FloatArray,
        minX: Float,
        maxX: Float,
        minZ: Float,
        maxZ: Float,
        pad: Float,
        blur: Float
    ): SoftMask? {
        return try {
            val worldW = maxX - minX + 2f * pad
            val worldH = maxZ - minZ + 2f * pad
            val pxPerUnit = min(MAX_SIDE_PX / max(worldW, worldH), MAX_PX_PER_UNIT)
            val w = alignUp(max(8, ceil(worldW * pxPerUnit).toInt()))
            val h = alignUp(max(8, ceil(worldH * pxPerUnit).toInt()))
            val sx = w / worldW
            val sy = h / worldH

            val path = Path()
            val n = polygon.size / 2
            for (i in 0 until n) {
                val x = (polygon[i * 2] - minX + pad) * sx
                val y = (polygon[i * 2 + 1] - minZ + pad) * sy
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()

            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.color = Color.BLACK
            paint.maskFilter = BlurMaskFilter(max(1.5f, blur * sx), BlurMaskFilter.Blur.NORMAL)
            Canvas(bitmap).drawPath(path, paint)

            // Read the pixels back as ARGB (alpha only, so alpha is the whole story) instead of
            // trusting the bitmap's row stride: the bytes handed to the GPU are packed w x h.
            val argb = IntArray(w * h)
            bitmap.getPixels(argb, 0, w, 0, 0, w, h)
            bitmap.recycle()
            val bytes = ByteArray(w * h)
            for (i in bytes.indices) bytes[i] = (argb[i] ushr 24).toByte()
            SoftMask(bytes, w, h, worldW, worldH)
        } catch (error: Throwable) {
            null
        }
    }

    private fun alignUp(value: Int): Int = (value + 3) and 3.inv()
}
