package com.photopuzzle.game.puzzle.render3d

import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import com.photopuzzle.game.R
import com.photopuzzle.game.puzzle.engine.PuzzleEngine
import com.photopuzzle.game.puzzle.geometry.MeshLayout
import com.photopuzzle.game.puzzle.geometry.SoftMask
import com.photopuzzle.game.puzzle.model.PieceGroup
import com.photopuzzle.game.puzzle.model.PuzzleGame
import com.photopuzzle.game.puzzle.model.PuzzlePiece
import java.nio.Buffer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Draws the table: a lit wooden surface, then every group of pieces from the bottom of the pile
 * to the top, each preceded by its soft shadow. Reads everything from [PuzzleEngine]; owns only
 * GL resources. Runs on the GL thread, like the engine.
 *
 * Groups are painted back to front with the depth buffer reset between overlapping ones -- that
 * is what guarantees a piece dropped on another always lands visibly on top, while the pieces
 * inside one group still sort correctly against each other. The reset covers only the part of
 * the screen the group occupies, and groups wholly off screen are skipped, so the cost follows
 * what is on screen rather than the size of the puzzle.
 *
 * Frames are drawn on demand: after each one the renderer asks for another only while something
 * is still moving ([requestFrame]), so a table at rest costs nothing.
 */
internal class PuzzleRenderer(
    private val resources: Resources,
    private val engine: PuzzleEngine,
    private val requestFrame: () -> Unit
) : GLSurfaceView.Renderer {

    private class GpuPiece(
        val vertexBuffer: Int,
        val indexBuffer: Int,
        val indexCount: Int,
        val shadowTexture: Int,
        val shadowHalfW: Float,
        val shadowHalfH: Float,
        /** Centre of the shadow image in the piece's own frame. */
        val shadowCenterX: Float,
        val shadowCenterZ: Float
    )

    private var tableProgram: GlProgram? = null
    private var pieceProgram: GlProgram? = null
    private var decalProgram: GlProgram? = null

    // Cached locations: table
    private var tCorner = 0
    private var tWood = 0
    private var tScreenToTable = 0
    private var tTileSize = 0
    private var tDetail = 0

    // piece
    private var pPosition = 0
    private var pNormal = 0
    private var pTexCoord = 0
    private var pFace = 0
    private var pViewProj = 0
    private var pRot = 0
    private var pTrans = 0
    private var pPhoto = 0
    private var pLightDir = 0
    private var pEyePos = 0
    private var pSolved = 0
    private var pThickness = 0
    private var pFlatten = 0

    // decal
    private var dCorner = 0
    private var dViewProj = 0
    private var dCenter = 0
    private var dRot = 0
    private var dHalf = 0
    private var dMask = 0
    private var dColor = 0

    private var quadBuffer = 0
    private var woodTexture = 0
    private var ringTexture = 0
    private var dotTexture = 0
    private var photoTexture = 0

    private var gpuPieces: Array<GpuPiece?> = arrayOfNulls(0)
    private var uploadedGeneration = -1

    private var lastFrameNanos = 0L

    private val groundMatrix = FloatArray(9)

    // Where the group being drawn lies on screen (pixels: minX, minY, maxX, maxY), and the same
    // for the groups already drawn this frame -- see [clearDepthWhereNeeded].
    private val box = FloatArray(4)
    private val corner = FloatArray(2)
    private var drawn = FloatArray(64)
    private var drawnCount = 0

    // ---- GLSurfaceView.Renderer ----------------------------------------------------------

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.10f, 0.07f, 0.05f, 1f)
        // Every upload below is tightly packed, whatever its width.
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)

        val table = GlProgram(PuzzleShaders.TABLE_VERTEX, PuzzleShaders.TABLE_FRAGMENT)
        tCorner = table.attrib("aCorner")
        tWood = table.uniform("uWood")
        tScreenToTable = table.uniform("uScreenToTable")
        tTileSize = table.uniform("uTileSize")
        tDetail = table.uniform("uDetail")
        tableProgram = table

        val piece = GlProgram(PuzzleShaders.PIECE_VERTEX, PuzzleShaders.PIECE_FRAGMENT)
        pPosition = piece.attrib("aPosition")
        pNormal = piece.attrib("aNormal")
        pTexCoord = piece.attrib("aTexCoord")
        pFace = piece.attrib("aFace")
        pViewProj = piece.uniform("uViewProj")
        pRot = piece.uniform("uRot")
        pTrans = piece.uniform("uTrans")
        pPhoto = piece.uniform("uPhoto")
        pLightDir = piece.uniform("uLightDir")
        pEyePos = piece.uniform("uEyePos")
        pSolved = piece.uniform("uSolved")
        pThickness = piece.uniform("uThickness")
        pFlatten = piece.uniform("uFlatten")
        pieceProgram = piece

        val decal = GlProgram(PuzzleShaders.DECAL_VERTEX, PuzzleShaders.DECAL_FRAGMENT)
        dCorner = decal.attrib("aCorner")
        dViewProj = decal.uniform("uViewProj")
        dCenter = decal.uniform("uCenter")
        dRot = decal.uniform("uRot")
        dHalf = decal.uniform("uHalf")
        dMask = decal.uniform("uMask")
        dColor = decal.uniform("uColor")
        decalProgram = decal

        quadBuffer = createBuffer(
            GLES20.GL_ARRAY_BUFFER,
            floatBufferOf(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)),
            8 * 4
        )

        val wood = loadWood()
        woodTexture = uploadTexture(wood, repeat = true, mipmaps = true)
        wood.recycle()
        val ring = ShadowMasks.ring()
        ringTexture = uploadTexture(ring, repeat = false, mipmaps = false)
        ring.recycle()
        val dot = ShadowMasks.dot()
        dotTexture = uploadTexture(dot, repeat = false, mipmaps = false)
        dot.recycle()

        // A new context knows nothing of the old one's pieces: rebuild them on the next frame.
        photoTexture = 0
        gpuPieces = arrayOfNulls(0)
        uploadedGeneration = -1
        lastFrameNanos = 0L
        requestFrame()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        engine.resizeSurface(width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val elapsed = if (lastFrameNanos == 0L) 0f else (now - lastFrameNanos) / 1.0e9f
        lastFrameNanos = now
        // After a spell of not drawing (the table was at rest) the clock must not leap ahead.
        val dt = if (elapsed > IDLE_GAP_SECONDS) FRAME_SECONDS else elapsed.coerceIn(0f, MAX_STEP_SECONDS)

        engine.update(dt)
        syncPieceResources()

        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
        GLES20.glDepthMask(true)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        drawTable()
        val game = engine.game
        if (game != null && photoTexture != 0) drawPieces(game)
        drawTurnRing(game)

        if (engine.isAnimating()) requestFrame()
    }

    // ---- scene ---------------------------------------------------------------------------

    private fun drawTable() {
        val program = tableProgram ?: return
        val camera = engine.camera
        if (!camera.screenToPlane(TABLE_Y, groundMatrix)) return
        program.use()
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glUniformMatrix3fv(tScreenToTable, 1, false, groundMatrix, 0)
        GLES20.glUniform1f(tTileSize, WOOD_TILE_UNITS)
        // Close up, the wood gets a layer of finer grain so it never looks stretched or soft.
        GLES20.glUniform1f(tDetail, smoothstep(DETAIL_FROM_ZOOM, DETAIL_FULL_ZOOM, camera.zoom))
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, woodTexture)
        GLES20.glUniform1i(tWood, 0)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, quadBuffer)
        GLES20.glEnableVertexAttribArray(tCorner)
        GLES20.glVertexAttribPointer(tCorner, 2, GLES20.GL_FLOAT, false, 8, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(tCorner)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    private fun drawPieces(game: PuzzleGame) {
        val camera = engine.camera
        val piece = pieceProgram ?: return
        val decal = decalProgram ?: return

        // Per-frame uniforms stay set on each program until changed, so set them once.
        piece.use()
        GLES20.glUniformMatrix4fv(pViewProj, 1, false, camera.viewProj, 0)
        GLES20.glUniform3f(pLightDir, LIGHT_X, LIGHT_Y, LIGHT_Z)
        GLES20.glUniform3f(pEyePos, camera.eyeX, camera.eyeY, camera.eyeZ)
        GLES20.glUniform1f(pSolved, engine.solvedMix)
        GLES20.glUniform1f(pFlatten, engine.solvedMix)
        GLES20.glUniform1f(pThickness, game.thickness)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, photoTexture)
        GLES20.glUniform1i(pPhoto, 0)

        decal.use()
        GLES20.glUniformMatrix4fv(dViewProj, 1, false, camera.viewProj, 0)
        GLES20.glUniform1i(dMask, 0)

        drawnCount = 0
        val groups = game.groups
        for (gi in 0 until groups.size) {
            val group = groups[gi]
            if (!measureGroup(group, game)) continue
            drawGroupShadows(group, game)
            drawGroup(group)
        }
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
    }

    /**
     * Works out the rectangle of the screen the group and its shadow can touch (into [box], in
     * pixels, clamped to the screen). False if it lies wholly off screen and need not be drawn.
     * If part of it is behind the camera the whole screen is assumed.
     */
    private fun measureGroup(group: PieceGroup, game: PuzzleGame): Boolean {
        val camera = engine.camera
        val screenW = camera.viewWidth.toFloat()
        val screenH = camera.viewHeight.toFloat()
        val margin = SHADOW_REACH * game.minCell + group.lift
        val top = group.lift + game.thickness
        var minX = Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (i in 0 until group.pieces.size) {
            val piece = group.pieces[i]
            val r = piece.shape.boundingRadius + margin
            for (c in 0 until 8) {
                val x = piece.visualX + (if ((c and 1) == 0) -r else r)
                val z = piece.visualZ + (if ((c and 2) == 0) -r else r)
                val y = if ((c and 4) == 0) 0f else top
                if (!camera.project(x, y, z, corner)) {
                    box[0] = 0f
                    box[1] = 0f
                    box[2] = screenW
                    box[3] = screenH
                    return true
                }
                if (corner[0] < minX) minX = corner[0]
                if (corner[0] > maxX) maxX = corner[0]
                if (corner[1] < minY) minY = corner[1]
                if (corner[1] > maxY) maxY = corner[1]
            }
        }
        if (minX >= screenW || maxX <= 0f || minY >= screenH || maxY <= 0f) return false
        box[0] = max(minX, 0f)
        box[1] = max(minY, 0f)
        box[2] = min(maxX, screenW)
        box[3] = min(maxY, screenH)
        return true
    }

    /**
     * A group must land on top of everything drawn before it, so wherever an earlier group left
     * depth behind it is wiped -- but only inside the group's own rectangle. Wiping the whole
     * screen for every group, as this once did, made the cost grow with the piece count and was
     * the main thing slowing the game down.
     */
    private fun clearDepthWhereNeeded() {
        var overlaps = false
        for (i in 0 until drawnCount) {
            val o = i * 4
            if (box[0] < drawn[o + 2] && box[2] > drawn[o] && box[1] < drawn[o + 3] && box[3] > drawn[o + 1]) {
                overlaps = true
                break
            }
        }
        if (overlaps) {
            val x = floor(box[0]).toInt()
            val y = floor(box[1]).toInt()
            val w = max(1, ceil(box[2]).toInt() - x)
            val h = max(1, ceil(box[3]).toInt() - y)
            GLES20.glEnable(GLES20.GL_SCISSOR_TEST)
            GLES20.glScissor(x, y, w, h)
            GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)
            GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
        }
        if ((drawnCount + 1) * 4 > drawn.size) drawn = drawn.copyOf(drawn.size * 2)
        val o = drawnCount * 4
        drawn[o] = box[0]
        drawn[o + 1] = box[1]
        drawn[o + 2] = box[2]
        drawn[o + 3] = box[3]
        drawnCount++
    }

    private fun smoothstep(edge0: Float, edge1: Float, x: Float): Float {
        val t = ((x - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun drawGroupShadows(group: PieceGroup, game: PuzzleGame) {
        val decal = decalProgram ?: return
        decal.use()
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, quadBuffer)
        GLES20.glEnableVertexAttribArray(dCorner)
        GLES20.glVertexAttribPointer(dCorner, 2, GLES20.GL_FLOAT, false, 8, 0)

        val m = game.minCell
        // A piece high above the table casts a big, faint shadow; past a point it just stays so.
        val lift = min(group.lift, SHADOW_MAX_LIFT * m)
        val liftRatio = lift / m
        val tightOffset = 0.025f * m
        val wideOffset = 0.07f * m + lift * 0.9f
        val wideScale = 1.10f + liftRatio * 0.5f
        val wideAlpha = 0.26f - min(0.12f, liftRatio * 0.4f)

        for (i in 0 until group.pieces.size) {
            val piece = group.pieces[i]
            val gpu = gpuPieces.getOrNull(piece.id) ?: continue
            if (gpu.shadowTexture == 0) continue
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, gpu.shadowTexture)
            drawShadowQuad(piece, gpu, wideOffset, wideScale, wideAlpha)
            drawShadowQuad(piece, gpu, tightOffset, 1.0f, 0.34f)
        }

        GLES20.glDisableVertexAttribArray(dCorner)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    private fun drawShadowQuad(piece: PuzzlePiece, gpu: GpuPiece, offset: Float, scale: Float, alpha: Float) {
        val a = piece.visualAngle
        val c = cos(a)
        val s = sin(a)
        val cx = piece.visualX + gpu.shadowCenterX * c - gpu.shadowCenterZ * s + SHADOW_DIR_X * offset
        val cz = piece.visualZ + gpu.shadowCenterX * s + gpu.shadowCenterZ * c + SHADOW_DIR_Z * offset
        GLES20.glUniform3f(dCenter, cx, SHADOW_Y, cz)
        GLES20.glUniform2f(dRot, c, s)
        GLES20.glUniform2f(dHalf, gpu.shadowHalfW * scale, gpu.shadowHalfH * scale)
        GLES20.glUniform4f(dColor, 0.03f, 0.015f, 0.005f, alpha)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    private fun drawGroup(group: PieceGroup) {
        val program = pieceProgram ?: return
        program.use()
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(true)
        // A group always lands on top of everything drawn before it.
        clearDepthWhereNeeded()
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, photoTexture)

        GLES20.glEnableVertexAttribArray(pPosition)
        GLES20.glEnableVertexAttribArray(pNormal)
        GLES20.glEnableVertexAttribArray(pTexCoord)
        GLES20.glEnableVertexAttribArray(pFace)

        for (i in 0 until group.pieces.size) {
            val piece = group.pieces[i]
            val gpu = gpuPieces.getOrNull(piece.id) ?: continue
            val a = piece.visualAngle
            GLES20.glUniform2f(pRot, cos(a), sin(a))
            GLES20.glUniform3f(pTrans, piece.visualX, group.lift, piece.visualZ)

            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gpu.vertexBuffer)
            GLES20.glVertexAttribPointer(pPosition, 3, GLES20.GL_FLOAT, false, MeshLayout.STRIDE_BYTES, 0)
            GLES20.glVertexAttribPointer(pNormal, 3, GLES20.GL_FLOAT, false, MeshLayout.STRIDE_BYTES, MeshLayout.NORMAL_OFFSET_BYTES)
            GLES20.glVertexAttribPointer(pTexCoord, 2, GLES20.GL_FLOAT, false, MeshLayout.STRIDE_BYTES, MeshLayout.UV_OFFSET_BYTES)
            GLES20.glVertexAttribPointer(pFace, 1, GLES20.GL_FLOAT, false, MeshLayout.STRIDE_BYTES, MeshLayout.FACE_OFFSET_BYTES)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, gpu.indexBuffer)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, gpu.indexCount, GLES20.GL_UNSIGNED_SHORT, 0)
        }

        GLES20.glDisableVertexAttribArray(pPosition)
        GLES20.glDisableVertexAttribArray(pNormal)
        GLES20.glDisableVertexAttribArray(pTexCoord)
        GLES20.glDisableVertexAttribArray(pFace)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
    }

    /** A thin ring around whatever is being turned, with a dot where the finger is. */
    private fun drawTurnRing(game: PuzzleGame?) {
        val alpha = engine.ringAlpha
        if (alpha < 0.01f) return
        val decal = decalProgram ?: return
        decal.use()
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glUniformMatrix4fv(dViewProj, 1, false, engine.camera.viewProj, 0)
        GLES20.glUniform1i(dMask, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, quadBuffer)
        GLES20.glEnableVertexAttribArray(dCorner)
        GLES20.glVertexAttribPointer(dCorner, 2, GLES20.GL_FLOAT, false, 8, 0)

        val radius = engine.ringRadius
        val half = radius / ShadowMasks.RING_RADIUS
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ringTexture)
        GLES20.glUniform3f(dCenter, engine.ringX, RING_Y, engine.ringZ)
        GLES20.glUniform2f(dRot, 1f, 0f)
        GLES20.glUniform2f(dHalf, half, half)
        GLES20.glUniform4f(dColor, 1.0f, 0.80f, 0.42f, 0.9f * alpha)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        val dotHalf = 0.14f * (game?.minCell ?: 60f)
        val a = engine.ringAngle
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, dotTexture)
        GLES20.glUniform3f(dCenter, engine.ringX + cos(a) * radius, RING_Y, engine.ringZ + sin(a) * radius)
        GLES20.glUniform2f(dHalf, dotHalf, dotHalf)
        GLES20.glUniform4f(dColor, 1.0f, 0.97f, 0.88f, alpha)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(dCorner)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
    }

    // ---- GPU resources -------------------------------------------------------------------

    /** Uploads the photo and every piece's mesh and shadow when a new puzzle has been installed. */
    private fun syncPieceResources() {
        val game = engine.game ?: return
        if (uploadedGeneration == engine.generation) return
        val atlas = engine.atlas ?: return
        val shadows = engine.shadows

        releasePieceResources()
        photoTexture = uploadTexture(atlas, repeat = false, mipmaps = true)

        val n = game.pieces.size
        val array = arrayOfNulls<GpuPiece>(n)
        for (i in 0 until n) {
            val shape = game.pieces[i].shape
            val mesh = shape.mesh
            val vertexBuffer = createBuffer(
                GLES20.GL_ARRAY_BUFFER, floatBufferOf(mesh.vertices), mesh.vertices.size * 4
            )
            val indexBuffer = createBuffer(
                GLES20.GL_ELEMENT_ARRAY_BUFFER, shortBufferOf(mesh.indices), mesh.indices.size * 2
            )
            var texture = 0
            var halfW = 0f
            var halfH = 0f
            val mask = shadows?.getOrNull(i)
            if (mask != null) {
                texture = uploadMask(mask)
                halfW = mask.worldWidth / 2f
                halfH = mask.worldHeight / 2f
            }
            array[i] = GpuPiece(
                vertexBuffer, indexBuffer, mesh.indexCount,
                texture, halfW, halfH,
                (shape.minX + shape.maxX) / 2f, (shape.minZ + shape.maxZ) / 2f
            )
        }
        gpuPieces = array
        uploadedGeneration = engine.generation
    }

    /** Frees what the previous puzzle left on the GPU. */
    private fun releasePieceResources() {
        for (gpu in gpuPieces) {
            if (gpu == null) continue
            GLES20.glDeleteBuffers(2, intArrayOf(gpu.vertexBuffer, gpu.indexBuffer), 0)
            if (gpu.shadowTexture != 0) GLES20.glDeleteTextures(1, intArrayOf(gpu.shadowTexture), 0)
        }
        gpuPieces = arrayOfNulls(0)
        if (photoTexture != 0) {
            GLES20.glDeleteTextures(1, intArrayOf(photoTexture), 0)
            photoTexture = 0
        }
    }

    private fun loadWood(): Bitmap {
        val options = BitmapFactory.Options()
        options.inScaled = false
        // The grain is busy enough to hide 16-bit colour entirely, and it halves the texture.
        options.inPreferredConfig = Bitmap.Config.RGB_565
        return BitmapFactory.decodeResource(resources, R.drawable.table_wood, options)
    }

    /**
     * Uploads a piece's shadow silhouette as an alpha texture straight from its bytes. (Going
     * through a Bitmap and GLUtils instead skews any image whose width is not a multiple of
     * four: each row starts in the wrong place, and the shadow turns into diagonal streaks.)
     */
    private fun uploadMask(mask: SoftMask): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        val buffer = ByteBuffer.allocateDirect(mask.pixels.size)
        buffer.put(mask.pixels)
        buffer.position(0)
        GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D, 0, GLES20.GL_ALPHA, mask.width, mask.height, 0,
            GLES20.GL_ALPHA, GLES20.GL_UNSIGNED_BYTE, buffer
        )
        return ids[0]
    }

    private fun uploadTexture(bitmap: Bitmap, repeat: Boolean, mipmaps: Boolean): Int {
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLES20.glTexParameteri(
            GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER,
            if (mipmaps) GLES20.GL_LINEAR_MIPMAP_LINEAR else GLES20.GL_LINEAR
        )
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        val wrap = if (repeat) GLES20.GL_REPEAT else GLES20.GL_CLAMP_TO_EDGE
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, wrap)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, wrap)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        if (mipmaps) GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        return ids[0]
    }

    private fun createBuffer(target: Int, data: Buffer, sizeBytes: Int): Int {
        val ids = IntArray(1)
        GLES20.glGenBuffers(1, ids, 0)
        GLES20.glBindBuffer(target, ids[0])
        GLES20.glBufferData(target, sizeBytes, data, GLES20.GL_STATIC_DRAW)
        GLES20.glBindBuffer(target, 0)
        return ids[0]
    }

    private fun floatBufferOf(values: FloatArray): FloatBuffer {
        val buffer = ByteBuffer.allocateDirect(values.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        buffer.put(values)
        buffer.position(0)
        return buffer
    }

    private fun shortBufferOf(values: ShortArray): ShortBuffer {
        val buffer = ByteBuffer.allocateDirect(values.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer()
        buffer.put(values)
        buffer.position(0)
        return buffer
    }

    private companion object {
        const val TABLE_Y = -0.5f

        /** Table units covered by one copy of the wood picture (four planks wide). */
        const val WOOD_TILE_UNITS = 2200f

        /** Between these zooms the extra close-up grain fades in on the table. */
        const val DETAIL_FROM_ZOOM = 1.3f
        const val DETAIL_FULL_ZOOM = 2.4f

        // Key light from the upper left of the screen, well above the table (unit length).
        const val LIGHT_X = -0.4494f
        const val LIGHT_Y = 0.7990f
        const val LIGHT_Z = -0.3995f

        // Shadows fall away from the light: down and to the right.
        const val SHADOW_DIR_X = 0.62f
        const val SHADOW_DIR_Z = 0.78f
        const val SHADOW_Y = 0.2f
        const val RING_Y = 0.4f

        /** How far a piece's visible shadow reaches past it, in piece sizes (plus its lift). */
        const val SHADOW_REACH = 0.45f

        /** Lift beyond which a shadow stops growing, in piece sizes. */
        const val SHADOW_MAX_LIFT = 1.5f

        // Frame timing. A gap this long means drawing paused, so time must not jump.
        const val IDLE_GAP_SECONDS = 0.1f
        const val FRAME_SECONDS = 1f / 60f
        const val MAX_STEP_SECONDS = 0.05f
    }
}
