package com.photopuzzle.game.puzzle.geometry

import kotlin.math.abs

/**
 * Ear-clipping triangulation of a simple polygon with positive signed area (as produced by
 * [GridOutlines]). Double precision throughout, so the tiny steps along a knob's curve never
 * confuse the convexity tests.
 */
internal object Triangulator {

    private const val EPS = 1e-12

    /**
     * [points] holds [count] interleaved x/y pairs. Returns triangles as index triples into
     * those points (three ints per triangle).
     */
    fun triangulate(points: DoubleArray, count: Int): IntArray {
        if (count < 3) return IntArray(0)

        val prev = IntArray(count) { (it + count - 1) % count }
        val next = IntArray(count) { (it + 1) % count }
        val out = IntArray((count - 2) * 3)
        var written = 0
        var remaining = count
        var current = 0
        var guard = 0
        val limit = 4 * count * count

        while (remaining > 3 && guard < limit) {
            guard++
            val p = prev[current]
            val q = next[current]
            val cr = cross(points, p, current, q)
            var ear = false
            if (cr > EPS) {
                ear = true
                var v = next[q]
                while (v != p) {
                    if (cross(points, prev[v], v, next[v]) < -EPS && inside(points, v, p, current, q)) {
                        ear = false
                        break
                    }
                    v = next[v]
                }
            }
            if (ear || abs(cr) <= EPS) {
                // A collinear vertex is dropped without a triangle: it adds no area.
                if (ear) {
                    out[written++] = p
                    out[written++] = current
                    out[written++] = q
                }
                next[p] = q
                prev[q] = p
                remaining--
                current = q
            } else {
                current = q
            }
        }

        if (remaining == 3) {
            val a = current
            val b = next[a]
            val c = next[b]
            if (cross(points, a, b, c) > EPS) {
                out[written++] = a
                out[written++] = b
                out[written++] = c
            }
        } else if (remaining > 3) {
            // Never expected for a valid outline; fan the rest so there is no hole.
            val a = current
            var b = next[a]
            while (next[b] != a) {
                out[written++] = a
                out[written++] = b
                out[written++] = next[b]
                b = next[b]
            }
        }
        return out.copyOf(written)
    }

    /** Twice the signed area of triangle (a, b, c); positive for counter-clockwise (y-up) order. */
    fun cross(points: DoubleArray, a: Int, b: Int, c: Int): Double {
        val ax = points[a * 2]
        val ay = points[a * 2 + 1]
        return (points[b * 2] - ax) * (points[c * 2 + 1] - ay) - (points[b * 2 + 1] - ay) * (points[c * 2] - ax)
    }

    private fun inside(points: DoubleArray, p: Int, a: Int, b: Int, c: Int): Boolean =
        cross(points, a, b, p) >= -EPS && cross(points, b, c, p) >= -EPS && cross(points, c, a, p) >= -EPS
}
