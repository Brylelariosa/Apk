package com.photopuzzle.game.puzzle

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import com.photopuzzle.game.R
import kotlin.random.Random

/**
 * A transparent overlay that throws a few bursts of confetti when [celebrate] is called.
 * It never takes touches, so whatever is underneath stays usable.
 */
class ConfettiView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val colors = intArrayOf(
        context.getColor(R.color.colorConfettiGold),
        context.getColor(R.color.colorConfettiCoral),
        context.getColor(R.color.colorConfettiMint),
        context.getColor(R.color.colorConfettiSky),
        context.getColor(R.color.colorConfettiCream)
    )

    private val bursts = listOf(ConfettiBurst(colors), ConfettiBurst(colors), ConfettiBurst(colors))
    private var animator: ValueAnimator? = null
    private var elapsedSeconds = 0f
    private var lifeFraction = 1f

    fun celebrate() {
        if (width == 0 || height == 0) return
        animator?.cancel()
        val random = Random(System.nanoTime())
        val spread = width * 0.9f
        val top = height * 0.74f
        bursts[0].start(width * 0.22f, top, spread, random)
        bursts[1].start(width * 0.50f, top * 1.04f, spread, random)
        bursts[2].start(width * 0.78f, top, spread, random)

        val next = ValueAnimator.ofFloat(0f, DURATION_SECONDS)
        next.duration = (DURATION_SECONDS * 1000).toLong()
        next.interpolator = LinearInterpolator()
        next.addUpdateListener { animation ->
            elapsedSeconds = animation.animatedValue as Float
            lifeFraction = elapsedSeconds / DURATION_SECONDS
            invalidate()
        }
        next.start()
        animator = next
    }

    override fun onDraw(canvas: Canvas) {
        if (animator?.isRunning != true) return
        for (burst in bursts) burst.draw(canvas, elapsedSeconds, lifeFraction)
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    private companion object {
        const val DURATION_SECONDS = 2.6f
    }
}
