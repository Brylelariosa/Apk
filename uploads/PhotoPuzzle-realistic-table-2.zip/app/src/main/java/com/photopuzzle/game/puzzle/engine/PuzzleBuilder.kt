package com.photopuzzle.game.puzzle.engine

import android.graphics.Bitmap
import com.photopuzzle.game.puzzle.EdgeGeneratorProvider
import com.photopuzzle.game.puzzle.EdgeSmoothing
import com.photopuzzle.game.puzzle.geometry.GridOutlines
import com.photopuzzle.game.puzzle.geometry.PieceMeshBuilder
import com.photopuzzle.game.puzzle.geometry.PieceShadowBuilder
import com.photopuzzle.game.puzzle.geometry.SoftMask
import com.photopuzzle.game.puzzle.model.PieceShape
import com.photopuzzle.game.puzzle.model.PuzzleGame
import com.photopuzzle.game.puzzle.model.PuzzlePiece
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min

/** Where on the table the pieces are poured out, plus the window they must fly in from. */
internal class ScatterBounds(
    val left: Float,
    val right: Float,
    val top: Float,
    val bottom: Float,
    val windowTop: Float
)

/** Everything needed to start playing, produced off the UI thread. */
internal class BuiltPuzzle(
    val game: PuzzleGame,
    /** The photo as a power-of-two texture image. */
    val atlas: Bitmap,
    /** One soft shadow silhouette per piece, by piece id (null where one could not be made). */
    val shadows: Array<SoftMask?>,
    val rotatePieces: Boolean,
    val viewWidth: Int,
    val viewHeight: Int,
    val scatter: ScatterBounds,
    val seed: Long
)

/** Cuts a photo into a [PuzzleGame]. All the heavy geometry work lives here. */
internal object PuzzleBuilder {

    private const val MAX_ATLAS = 2048
    private const val MIN_ATLAS = 256

    /** Margin around a piece's shadow image, and how soft its edge is, in smaller-cell units. */
    private const val SHADOW_PAD = 0.30f
    private const val SHADOW_BLUR = 0.085f

    /**
     * The view size decides how big the picture is on the table, so pieces come out a
     * comfortable size for the number of pieces and the screen.
     */
    fun build(
        photo: Bitmap,
        rows: Int,
        cols: Int,
        viewWidth: Int,
        viewHeight: Int,
        rotatePieces: Boolean,
        seed: Long
    ): BuiltPuzzle {
        val windowW = viewWidth.toFloat()
        val windowD = viewHeight.toFloat() / cos(TableCamera.TILT_RADIANS)

        val count = rows * cols
        val fracW: Float
        val fracD: Float
        when {
            count <= 12 -> { fracW = 0.50f; fracD = 0.34f }
            count <= 30 -> { fracW = 0.62f; fracD = 0.40f }
            count <= 60 -> { fracW = 0.74f; fracD = 0.46f }
            else -> { fracW = 0.88f; fracD = 0.54f }
        }

        val fit = min(fracW * windowW / photo.width, fracD * windowD / photo.height)
        val pictureW = photo.width * fit
        val pictureH = photo.height * fit
        val cellW = pictureW / cols
        val cellH = pictureH / rows
        val minCell = min(cellW, cellH)

        val edgeData = EdgeGeneratorProvider.get().generate(rows, cols, seed)
        EdgeSmoothing.apply(edgeData, rows, cols)
        val outlines = GridOutlines(rows, cols, cellW.toDouble(), cellH.toDouble(), edgeData, seed)

        val thickness = 0.11 * minCell
        val bevel = (0.011 * minCell).coerceIn(0.8, 3.0)

        val pieces = Array(rows * cols) { index ->
            val r = index / cols
            val c = index % cols
            val outline = outlines.outline(r, c)
            val cx = (c + 0.5) * cellW
            val cy = (r + 0.5) * cellH
            val mesh = PieceMeshBuilder.build(
                outline, cx, cy, pictureW.toDouble(), pictureH.toDouble(), thickness, bevel
            )
            val polygon = PieceMeshBuilder.localPolygon(outline, cx, cy)
            PuzzlePiece(
                index, r, c,
                (cx - pictureW / 2.0).toFloat(), (cy - pictureH / 2.0).toFloat(),
                PieceShape(polygon, mesh)
            )
        }

        val game = PuzzleGame(
            rows, cols, pieces, cellW, cellH,
            thickness = thickness.toFloat(),
            tableHalfWidth = 0.85f * windowW,
            tableHalfDepth = 0.85f * windowD
        )

        val shadows = Array(pieces.size) { index ->
            val shape = pieces[index].shape
            PieceShadowBuilder.build(
                shape.polygon, shape.minX, shape.maxX, shape.minZ, shape.maxZ,
                SHADOW_PAD * minCell, SHADOW_BLUR * minCell
            )
        }

        val bounds = scatterBounds(viewWidth, viewHeight, 0.5f * max(cellW, cellH), windowW, windowD)

        val atlasW = powerOfTwoAtLeast(photo.width)
        val atlasH = powerOfTwoAtLeast(photo.height)
        val atlas = if (photo.width == atlasW && photo.height == atlasH) {
            photo
        } else {
            Bitmap.createScaledBitmap(photo, atlasW, atlasH, true)
        }

        return BuiltPuzzle(
            game, atlas, shadows, rotatePieces, viewWidth, viewHeight, bounds, seed
        )
    }

    /**
     * The part of the table where the pieces are poured out: what the camera sees at its starting
     * position, minus the strips under the top bar and the bottom buttons and a margin of half a
     * piece, so nothing starts hidden or half off-screen.
     */
    private fun scatterBounds(
        viewWidth: Int,
        viewHeight: Int,
        margin: Float,
        windowW: Float,
        windowD: Float
    ): ScatterBounds {
        val camera = TableCamera()
        camera.resize(viewWidth, viewHeight)
        val w = viewWidth.toFloat()
        val topPx = 0.085f * viewHeight
        val bottomPx = 0.90f * viewHeight
        val p = FloatArray(2)

        var left = -windowW / 2f
        var right = windowW / 2f
        var top = -windowD / 2f + 0.08f * windowD
        var bottom = windowD / 2f - 0.10f * windowD
        var windowTop = -windowD / 2f

        if (camera.screenToTable(0f, topPx, 0f, p)) {
            left = p[0]
            top = p[1]
        }
        if (camera.screenToTable(w, topPx, 0f, p)) {
            right = p[0]
            top = min(top, p[1])
        }
        if (camera.screenToTable(0f, bottomPx, 0f, p)) {
            left = max(left, p[0])
            bottom = p[1]
        }
        if (camera.screenToTable(w, bottomPx, 0f, p)) {
            right = min(right, p[0])
            bottom = max(bottom, p[1])
        }
        if (camera.screenToTable(w / 2f, 0f, 0f, p)) windowTop = p[1]

        left += margin
        right -= margin
        top += margin * 0.6f
        bottom -= margin * 0.6f
        if (right <= left) {
            left = -windowW * 0.3f
            right = windowW * 0.3f
        }
        if (bottom <= top) {
            top = -windowD * 0.3f
            bottom = windowD * 0.3f
        }
        return ScatterBounds(left, right, top, bottom, windowTop)
    }

    private fun powerOfTwoAtLeast(value: Int): Int {
        var p = MIN_ATLAS
        while (p < value && p < MAX_ATLAS) p *= 2
        return p
    }
}
