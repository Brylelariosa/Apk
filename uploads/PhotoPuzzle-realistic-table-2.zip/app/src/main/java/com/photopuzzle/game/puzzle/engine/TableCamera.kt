package com.photopuzzle.game.puzzle.engine

import android.opengl.Matrix
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.tan

/**
 * A camera looking down at the table from a little in front of it, with a mild perspective.
 *
 * Table units are chosen so that at zoom 1 one unit is about one screen pixel at the point the
 * camera is aimed at. The table lies in the x/z plane with y up; x grows to the right and z
 * down the screen. All picking goes through [screenToTable], which intersects the touch ray
 * with the table, so panning, zooming and the tilt need no special cases anywhere else.
 */
internal class TableCamera {

    var viewWidth: Int = 1
        private set
    var viewHeight: Int = 1
        private set

    var focusX = 0f
        private set
    var focusZ = 0f
        private set
    var zoom = 1f
        private set

    /** How far the aimed-at point may stray from the middle of the table. */
    var limitX = 1e6f
    var limitZ = 1e6f

    val viewProj = FloatArray(16)

    var eyeX = 0f
        private set
    var eyeY = 0f
        private set
    var eyeZ = 0f
        private set

    private val view = FloatArray(16)
    private val projection = FloatArray(16)
    private val inverse = FloatArray(16)
    private val vecIn = FloatArray(4)
    private val near = FloatArray(4)
    private val far = FloatArray(4)
    private val probe = FloatArray(2)
    private val anchor = FloatArray(2)

    private var animating = false

    /** True while the view is gliding to a new position (the renderer must keep drawing). */
    val isAnimating: Boolean get() = animating

    private var targetX = 0f
    private var targetZ = 0f
    private var targetZoom = 1f

    fun resize(width: Int, height: Int) {
        viewWidth = max(1, width)
        viewHeight = max(1, height)
        computeMatrices()
    }

    /** Jumps straight to a view. */
    fun snapTo(x: Float, z: Float, zoomLevel: Float) {
        animating = false
        focusX = x
        focusZ = z
        zoom = zoomLevel.coerceIn(MIN_ZOOM, MAX_ZOOM)
        clampFocus()
        computeMatrices()
    }

    /** Glides to a view over the next moments. */
    fun animateTo(x: Float, z: Float, zoomLevel: Float) {
        targetX = x.coerceIn(-limitX, limitX)
        targetZ = z.coerceIn(-limitZ, limitZ)
        targetZoom = zoomLevel.coerceIn(MIN_ZOOM, MAX_ZOOM)
        animating = true
    }

    fun cancelAnimation() {
        animating = false
    }

    fun update(dt: Float) {
        if (!animating) return
        val k = 1f - exp(-dt * ANIMATION_RATE)
        focusX += (targetX - focusX) * k
        focusZ += (targetZ - focusZ) * k
        zoom += (targetZoom - zoom) * k
        if (abs(targetX - focusX) < 0.2f && abs(targetZ - focusZ) < 0.2f && abs(targetZoom - zoom) < 0.002f) {
            focusX = targetX
            focusZ = targetZ
            zoom = targetZoom
            animating = false
        }
        computeMatrices()
    }

    /** Slides the view by a distance in table units. */
    fun panBy(dx: Float, dz: Float) {
        focusX += dx
        focusZ += dz
        clampFocus()
        computeMatrices()
    }

    /** Remembers the table point under a screen position; [applyPinch] keeps it there. */
    fun beginAnchor(sx: Float, sy: Float): Boolean = screenToTable(sx, sy, 0f, anchor)

    /**
     * Multiplies the zoom by [scaleFactor] and slides the view so the anchored table point stays
     * under the screen position ([sx], [sy]) -- which also follows two fingers panning.
     */
    fun applyPinch(scaleFactor: Float, sx: Float, sy: Float) {
        zoom = (zoom * scaleFactor).coerceIn(MIN_ZOOM, MAX_ZOOM)
        computeMatrices()
        if (screenToTable(sx, sy, 0f, probe)) {
            focusX += anchor[0] - probe[0]
            focusZ += anchor[1] - probe[1]
        }
        clampFocus()
        computeMatrices()
    }

    /**
     * Intersects the ray through screen pixel ([sx], [sy]) with the horizontal plane at height
     * [planeY]; the hit's x / z go to out[0], out[1]. False if the ray is parallel to the plane.
     */
    fun screenToTable(sx: Float, sy: Float, planeY: Float, out: FloatArray): Boolean {
        vecIn[0] = 2f * sx / viewWidth - 1f
        vecIn[1] = 1f - 2f * sy / viewHeight
        vecIn[2] = -1f
        vecIn[3] = 1f
        Matrix.multiplyMV(near, 0, inverse, 0, vecIn, 0)
        vecIn[2] = 1f
        Matrix.multiplyMV(far, 0, inverse, 0, vecIn, 0)
        val nw = near[3]
        val fw = far[3]
        if (abs(nw) < 1e-9f || abs(fw) < 1e-9f) return false
        val ax = near[0] / nw
        val ay = near[1] / nw
        val az = near[2] / nw
        val bx = far[0] / fw
        val by = far[1] / fw
        val bz = far[2] / fw
        val dy = by - ay
        if (abs(dy) < 1e-6f) return false
        val t = (planeY - ay) / dy
        out[0] = ax + (bx - ax) * t
        out[1] = az + (bz - az) * t
        return true
    }

    /**
     * Projects a table-space point to pixels in GL window coordinates (origin bottom-left).
     * False if the point is behind the camera.
     */
    fun project(x: Float, y: Float, z: Float, out: FloatArray): Boolean {
        val m = viewProj
        val w = m[3] * x + m[7] * y + m[11] * z + m[15]
        if (w < 1e-3f) return false
        val nx = (m[0] * x + m[4] * y + m[8] * z + m[12]) / w
        val ny = (m[1] * x + m[5] * y + m[9] * z + m[13]) / w
        out[0] = (nx * 0.5f + 0.5f) * viewWidth
        out[1] = (ny * 0.5f + 0.5f) * viewHeight
        return true
    }

    /**
     * Fills [out] (a column-major 3x3, ready for a GLSL mat3) with the matrix that turns a screen
     * position (ndcX, ndcY, 1) into the homogeneous table point (x * s, z * s, s) on the plane at
     * [planeY]. The fragment shader divides by s to get the exact table position under each
     * pixel, so the table can be drawn as one screen-sized quad instead of a vast triangle pair
     * that has to be clipped by the GPU. False if the view is degenerate.
     */
    fun screenToPlane(planeY: Float, out: FloatArray): Boolean {
        val m = viewProj
        // The matrix taking a table point (x, z, 1) to clip x, clip y and clip w.
        val a = m[0].toDouble()
        val b = m[8].toDouble()
        val c = m[4] * planeY.toDouble() + m[12]
        val d = m[1].toDouble()
        val e = m[9].toDouble()
        val f = m[5] * planeY.toDouble() + m[13]
        val g = m[3].toDouble()
        val h = m[11].toDouble()
        val i = m[7] * planeY.toDouble() + m[15]

        val c00 = e * i - f * h
        val c01 = f * g - d * i
        val c02 = d * h - e * g
        val det = a * c00 + b * c01 + c * c02
        if (abs(det) < 1e-9) return false
        val inv = 1.0 / det

        // Inverse = adjugate / determinant; written out column-major.
        out[0] = (c00 * inv).toFloat()
        out[1] = (c01 * inv).toFloat()
        out[2] = (c02 * inv).toFloat()
        out[3] = ((c * h - b * i) * inv).toFloat()
        out[4] = ((a * i - c * g) * inv).toFloat()
        out[5] = ((b * g - a * h) * inv).toFloat()
        out[6] = ((b * f - c * e) * inv).toFloat()
        out[7] = ((c * d - a * f) * inv).toFloat()
        out[8] = ((a * e - b * d) * inv).toFloat()
        return true
    }

    private fun clampFocus() {
        focusX = focusX.coerceIn(-limitX, limitX)
        focusZ = focusZ.coerceIn(-limitZ, limitZ)
    }

    private fun computeMatrices() {
        val aspect = viewWidth.toFloat() / viewHeight.toFloat()
        val baseDistance = viewHeight / (2f * tan(Math.toRadians(FOV_Y_DEGREES / 2.0)).toFloat())
        val distance = baseDistance / zoom
        eyeX = focusX
        eyeY = distance * cos(TILT_RADIANS)
        eyeZ = focusZ + distance * sin(TILT_RADIANS)
        Matrix.setLookAtM(view, 0, eyeX, eyeY, eyeZ, focusX, 0f, focusZ, 0f, 0f, -1f)
        Matrix.perspectiveM(projection, 0, FOV_Y_DEGREES, aspect, distance * NEAR_FACTOR, distance * FAR_FACTOR)
        Matrix.multiplyMM(viewProj, 0, projection, 0, view, 0)
        Matrix.invertM(inverse, 0, viewProj, 0)
    }

    companion object {
        const val FOV_Y_DEGREES = 24f

        /** Tilt from straight down, in radians (28 degrees). */
        const val TILT_RADIANS = 0.489f

        const val MIN_ZOOM = 0.7f
        const val MAX_ZOOM = 4f
        private const val ANIMATION_RATE = 4.5f

        // Everything visible (table, pieces, a piece held up) lies between about 0.9 and 1.15
        // eye-distances from the camera, so the depth range can hug it. A tight range gives the
        // depth buffer several times the precision of a loose one.
        private const val NEAR_FACTOR = 0.4f
        private const val FAR_FACTOR = 2.5f
    }
}
