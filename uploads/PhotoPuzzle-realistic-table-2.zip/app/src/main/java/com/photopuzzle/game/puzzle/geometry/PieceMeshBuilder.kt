package com.photopuzzle.game.puzzle.geometry

import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sqrt

/** Vertex format shared by the mesh builder and the renderer. */
internal object MeshLayout {
    /** position (3) + normal (3) + uv (2) + face id (1). */
    const val FLOATS_PER_VERTEX = 9
    const val STRIDE_BYTES = FLOATS_PER_VERTEX * 4
    const val NORMAL_OFFSET_BYTES = 12
    const val UV_OFFSET_BYTES = 24
    const val FACE_OFFSET_BYTES = 32

    const val FACE_TOP = 0f
    const val FACE_BEVEL = 1f
    const val FACE_WALL = 2f
}

/** CPU-side triangle mesh of one piece, ready to upload. */
internal class PieceMeshData(val vertices: FloatArray, val indices: ShortArray) {
    val indexCount: Int get() = indices.size
}

/**
 * Builds a piece as a thin solid lying on the table: y = 0 is the table, y = thickness the
 * printed top. Local x / z follow the picture (x right, z down) and are relative to the
 * piece's cell centre, so the piece can be placed and rotated about it.
 *
 * Three surfaces: the flat printed top (inset a hair from the cut), a narrow chamfer where
 * the die cut rounds the paper over, and the chipboard wall. There is no bottom: pieces never
 * turn over, so it can never be seen.
 */
internal object PieceMeshBuilder {

    private const val SMOOTH_DOT = 0.82
    private const val BEVEL_TILT = 0.70710678
    private const val BEVEL_DROP = 0.7

    private class Cap(val ring: DoubleArray, val triangles: IntArray, val bevel: Double)

    private class VertexWriter(vertexCapacity: Int) {
        val data = FloatArray(vertexCapacity * MeshLayout.FLOATS_PER_VERTEX)

        var count: Int = 0
            private set

        fun put(
            px: Double, py: Double, pz: Double,
            nx: Double, ny: Double, nz: Double,
            u: Double, v: Double,
            face: Float
        ): Int {
            val o = count * MeshLayout.FLOATS_PER_VERTEX
            data[o] = px.toFloat()
            data[o + 1] = py.toFloat()
            data[o + 2] = pz.toFloat()
            data[o + 3] = nx.toFloat()
            data[o + 4] = ny.toFloat()
            data[o + 5] = nz.toFloat()
            data[o + 6] = u.toFloat()
            data[o + 7] = v.toFloat()
            data[o + 8] = face
            return count++
        }
    }

    /**
     * [outline] is the closed picture-space polygon (interleaved x/y, positive area).
     * ([centerX], [centerY]) is the cell centre it is made relative to; [pictureWidth] x
     * [pictureHeight] map picture space onto the photo's 0..1 texture coordinates.
     */
    fun build(
        outline: DoubleArray,
        centerX: Double,
        centerY: Double,
        pictureWidth: Double,
        pictureHeight: Double,
        thickness: Double,
        bevel: Double
    ): PieceMeshData {
        val n = outline.size / 2
        val cap = buildCap(outline, bevel)
        val drop = cap.bevel * BEVEL_DROP
        val wallTop = thickness - drop

        val segNx = DoubleArray(n)
        val segNz = DoubleArray(n)
        segmentNormals(outline, segNx, segNz)

        val writer = VertexWriter(n * 9)
        val indices = ShortArray(cap.triangles.size + n * 12)
        var ii = 0

        // Printed top: the inset ring, flat.
        for (i in 0 until n) {
            val rx = cap.ring[i * 2]
            val ry = cap.ring[i * 2 + 1]
            writer.put(
                rx - centerX, thickness, ry - centerY,
                0.0, 1.0, 0.0,
                rx / pictureWidth, ry / pictureHeight,
                MeshLayout.FACE_TOP
            )
        }
        for (t in cap.triangles) indices[ii++] = t.toShort()

        for (i in 0 until n) {
            val j = (i + 1) % n
            val prevSeg = (i + n - 1) % n
            val nextSeg = j

            // Normal at this segment's start and end: smoothed along curves, kept hard at corners.
            val sx: Double
            val sz: Double
            if (segNx[prevSeg] * segNx[i] + segNz[prevSeg] * segNz[i] > SMOOTH_DOT) {
                val ax = segNx[prevSeg] + segNx[i]
                val az = segNz[prevSeg] + segNz[i]
                val l = hypot(ax, az)
                sx = ax / l
                sz = az / l
            } else {
                sx = segNx[i]
                sz = segNz[i]
            }
            val ex: Double
            val ez: Double
            if (segNx[i] * segNx[nextSeg] + segNz[i] * segNz[nextSeg] > SMOOTH_DOT) {
                val ax = segNx[i] + segNx[nextSeg]
                val az = segNz[i] + segNz[nextSeg]
                val l = hypot(ax, az)
                ex = ax / l
                ez = az / l
            } else {
                ex = segNx[i]
                ez = segNz[i]
            }

            val ox0 = outline[i * 2]
            val oy0 = outline[i * 2 + 1]
            val ox1 = outline[j * 2]
            val oy1 = outline[j * 2 + 1]
            val rx0 = cap.ring[i * 2]
            val ry0 = cap.ring[i * 2 + 1]
            val rx1 = cap.ring[j * 2]
            val ry1 = cap.ring[j * 2 + 1]

            // Chamfer: from the top's inset edge down and out to the cut.
            val a = writer.put(
                rx0 - centerX, thickness, ry0 - centerY,
                sx * BEVEL_TILT, BEVEL_TILT, sz * BEVEL_TILT,
                rx0 / pictureWidth, ry0 / pictureHeight, MeshLayout.FACE_BEVEL
            )
            val b = writer.put(
                rx1 - centerX, thickness, ry1 - centerY,
                ex * BEVEL_TILT, BEVEL_TILT, ez * BEVEL_TILT,
                rx1 / pictureWidth, ry1 / pictureHeight, MeshLayout.FACE_BEVEL
            )
            val c = writer.put(
                ox0 - centerX, wallTop, oy0 - centerY,
                sx * BEVEL_TILT, BEVEL_TILT, sz * BEVEL_TILT,
                ox0 / pictureWidth, oy0 / pictureHeight, MeshLayout.FACE_BEVEL
            )
            val d = writer.put(
                ox1 - centerX, wallTop, oy1 - centerY,
                ex * BEVEL_TILT, BEVEL_TILT, ez * BEVEL_TILT,
                ox1 / pictureWidth, oy1 / pictureHeight, MeshLayout.FACE_BEVEL
            )
            indices[ii++] = a.toShort()
            indices[ii++] = b.toShort()
            indices[ii++] = d.toShort()
            indices[ii++] = a.toShort()
            indices[ii++] = d.toShort()
            indices[ii++] = c.toShort()

            // Wall: v = 1 at the top (printed paper line), 0 at the table.
            val e = writer.put(
                ox0 - centerX, wallTop, oy0 - centerY,
                sx, 0.0, sz, 0.0, 1.0, MeshLayout.FACE_WALL
            )
            val f = writer.put(
                ox1 - centerX, wallTop, oy1 - centerY,
                ex, 0.0, ez, 0.0, 1.0, MeshLayout.FACE_WALL
            )
            val g = writer.put(
                ox0 - centerX, 0.0, oy0 - centerY,
                sx, 0.0, sz, 0.0, 0.0, MeshLayout.FACE_WALL
            )
            val h = writer.put(
                ox1 - centerX, 0.0, oy1 - centerY,
                ex, 0.0, ez, 0.0, 0.0, MeshLayout.FACE_WALL
            )
            indices[ii++] = e.toShort()
            indices[ii++] = f.toShort()
            indices[ii++] = h.toShort()
            indices[ii++] = e.toShort()
            indices[ii++] = h.toShort()
            indices[ii++] = g.toShort()
        }

        return PieceMeshData(writer.data.copyOf(writer.count * MeshLayout.FLOATS_PER_VERTEX), indices.copyOf(ii))
    }

    /** The outline relative to the cell centre, as float x/z pairs (for hit testing and shadows). */
    fun localPolygon(outline: DoubleArray, centerX: Double, centerY: Double): FloatArray {
        val out = FloatArray(outline.size)
        for (i in 0 until outline.size / 2) {
            out[i * 2] = (outline[i * 2] - centerX).toFloat()
            out[i * 2 + 1] = (outline[i * 2 + 1] - centerY).toFloat()
        }
        return out
    }

    /**
     * Insets the outline by [bevel] for the printed top. If the ring would fold over itself in a
     * tight bend, retries with a thinner chamfer, and finally with none.
     */
    private fun buildCap(outline: DoubleArray, bevel: Double): Cap {
        val n = outline.size / 2
        val factors = doubleArrayOf(1.0, 0.5, 0.25)
        for (f in factors) {
            val b = bevel * f
            val ring = insetRing(outline, b)
            if (!isSimple(ring)) continue
            val triangles = Triangulator.triangulate(ring, n)
            if (coversPolygon(ring, triangles)) return Cap(ring, triangles, b)
        }
        return Cap(outline.copyOf(), Triangulator.triangulate(outline, n), 0.0)
    }

    private fun insetRing(outline: DoubleArray, b: Double): DoubleArray {
        val n = outline.size / 2
        val nx = DoubleArray(n)
        val nz = DoubleArray(n)
        segmentNormals(outline, nx, nz)
        val ring = DoubleArray(n * 2)
        for (i in 0 until n) {
            val p = (i + n - 1) % n
            val d = max(1.0 + nx[p] * nx[i] + nz[p] * nz[i], 0.4)
            var mx = (nx[p] + nx[i]) / d
            var mz = (nz[p] + nz[i]) / d
            val l = hypot(mx, mz)
            if (l > 2.4) {
                mx *= 2.4 / l
                mz *= 2.4 / l
            }
            ring[i * 2] = outline[i * 2] - mx * b
            ring[i * 2 + 1] = outline[i * 2 + 1] - mz * b
        }
        return ring
    }

    /** Outward unit normal of every segment (point i to point i + 1) of a positive-area polygon. */
    private fun segmentNormals(points: DoubleArray, nx: DoubleArray, nz: DoubleArray) {
        val n = points.size / 2
        for (i in 0 until n) {
            val j = (i + 1) % n
            val dx = points[j * 2] - points[i * 2]
            val dy = points[j * 2 + 1] - points[i * 2 + 1]
            var l = sqrt(dx * dx + dy * dy)
            if (l == 0.0) l = 1.0
            nx[i] = dy / l
            nz[i] = -dx / l
        }
    }

    private fun coversPolygon(points: DoubleArray, triangles: IntArray): Boolean {
        val n = points.size / 2
        var polygonArea = 0.0
        for (i in 0 until n) {
            val j = (i + 1) % n
            polygonArea += points[i * 2] * points[j * 2 + 1] - points[j * 2] * points[i * 2 + 1]
        }
        polygonArea *= 0.5
        if (polygonArea <= 0.0) return false
        var covered = 0.0
        var t = 0
        while (t < triangles.size) {
            covered += 0.5 * Triangulator.cross(points, triangles[t], triangles[t + 1], triangles[t + 2])
            t += 3
        }
        return kotlin.math.abs(covered - polygonArea) <= 1e-6 * polygonArea
    }

    private fun isSimple(points: DoubleArray): Boolean {
        val n = points.size / 2
        for (i in 0 until n) {
            val ax = points[i * 2]
            val ay = points[i * 2 + 1]
            val bi = (i + 1) % n
            val bx = points[bi * 2]
            val by = points[bi * 2 + 1]
            for (j in i + 2 until n) {
                if (i == 0 && j == n - 1) continue
                val cx = points[j * 2]
                val cy = points[j * 2 + 1]
                val di = (j + 1) % n
                val dx = points[di * 2]
                val dy = points[di * 2 + 1]
                val d1 = orient(ax, ay, bx, by, cx, cy)
                val d2 = orient(ax, ay, bx, by, dx, dy)
                val d3 = orient(cx, cy, dx, dy, ax, ay)
                val d4 = orient(cx, cy, dx, dy, bx, by)
                if (d1 * d2 < 0.0 && d3 * d4 < 0.0) return false
            }
        }
        return true
    }

    private fun orient(ox: Double, oy: Double, ax: Double, ay: Double, bx: Double, by: Double): Double =
        (ax - ox) * (by - oy) - (ay - oy) * (bx - ox)
}
