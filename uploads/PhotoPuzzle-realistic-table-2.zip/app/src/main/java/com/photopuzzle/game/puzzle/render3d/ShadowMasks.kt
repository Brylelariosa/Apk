package com.photopuzzle.game.puzzle.render3d

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

/** Small shared images for the turn ring (the per-piece shadows are built with the puzzle). */
internal object ShadowMasks {

    /** A thin glowing circle, filling its image edge to edge (radius 0.92 of the half size). */
    fun ring(): Bitmap {
        val size = 256
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ALPHA_8)
        val canvas = Canvas(bitmap)
        val c = size / 2f
        val glow = Paint(Paint.ANTI_ALIAS_FLAG)
        glow.style = Paint.Style.STROKE
        glow.strokeWidth = 14f
        glow.color = Color.BLACK
        glow.alpha = 140
        try {
            glow.maskFilter = BlurMaskFilter(8f, BlurMaskFilter.Blur.NORMAL)
        } catch (error: Throwable) {
            // Glow is a nicety; the crisp ring below is enough.
        }
        canvas.drawCircle(c, c, c * RING_RADIUS, glow)
        val line = Paint(Paint.ANTI_ALIAS_FLAG)
        line.style = Paint.Style.STROKE
        line.strokeWidth = 4f
        line.color = Color.BLACK
        canvas.drawCircle(c, c, c * RING_RADIUS, line)
        return bitmap
    }

    /** A soft round dot, used to mark where the finger is on the ring. */
    fun dot(): Bitmap {
        val size = 64
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ALPHA_8)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = Color.BLACK
        try {
            paint.maskFilter = BlurMaskFilter(5f, BlurMaskFilter.Blur.NORMAL)
        } catch (error: Throwable) {
            // Fall back to a hard-edged dot.
        }
        Canvas(bitmap).drawCircle(size / 2f, size / 2f, 16f, paint)
        return bitmap
    }

    /** Radius of the ring's circle as a fraction of half the image. */
    const val RING_RADIUS = 0.92f
}
