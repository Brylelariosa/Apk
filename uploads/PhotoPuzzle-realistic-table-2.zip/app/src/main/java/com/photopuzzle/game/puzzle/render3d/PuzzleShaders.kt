package com.photopuzzle.game.puzzle.render3d

/** GLSL ES 1.00 sources. One program each for the table, the pieces, and flat soft decals (shadows, the turn ring). */
internal object PuzzleShaders {

    /**
     * The table is one quad covering the whole screen. The fragment shader works out which
     * point of the table lies under each pixel (see TableCamera.screenToPlane), so there is no
     * vast ground polygon to clip and its texture can never smear or swim.
     */
    const val TABLE_VERTEX = """
attribute vec2 aCorner;
varying vec2 vNdc;
void main() {
    vNdc = aCorner;
    gl_Position = vec4(aCorner, 0.0, 1.0);
}
"""

    const val TABLE_FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uWood;
uniform mat3 uScreenToTable;
uniform float uTileSize;
uniform float uDetail;
varying vec2 vNdc;
void main() {
    // The point of the table under this pixel, perspective and all.
    vec3 h = uScreenToTable * vec3(vNdc, 1.0);
    vec2 uv = (h.xy / h.z) / uTileSize;
    vec3 wood = texture2D(uWood, uv).rgb;

    // Zoomed in close, the texture alone turns soft. Finer grain taken from the same picture
    // (just its small detail, not its large shapes) is laid over it.
    if (uDetail > 0.01) {
        vec2 uv2 = uv * 4.7 + vec2(0.37, 0.61);
        float fine = texture2D(uWood, uv2).g - texture2D(uWood, uv2, 3.0).g;
        wood *= 1.0 + fine * 2.4 * uDetail;
    }

    // A lamp over the table: bright in the middle of the screen, falling off to the corners.
    vec2 q = vec2(vNdc.x * 0.5, vNdc.y * 0.5 - 0.02) * vec2(1.0, 0.82);
    float d = length(q);
    float lamp = 1.0 - smoothstep(0.18, 0.78, d);
    vec3 color = wood * mix(0.46, 1.08, lamp);

    // A faint varnish sheen where the lamp is brightest.
    color += vec3(1.0, 0.9, 0.75) * pow(max(0.0, 1.0 - d * 1.7), 2.5) * 0.07;
    gl_FragColor = vec4(color, 1.0);
}
"""

    const val PIECE_VERTEX = """
uniform mat4 uViewProj;
uniform vec2 uRot;
uniform vec3 uTrans;
uniform float uThickness;
uniform float uFlatten;
attribute vec3 aPosition;
attribute vec3 aNormal;
attribute vec2 aTexCoord;
attribute float aFace;
varying vec3 vNormal;
varying vec3 vWorld;
varying vec2 vUv;
varying float vFace;
void main() {
    // Once the puzzle is solved the chamfer and wall tops rise to the printed surface,
    // so the finished picture is one unbroken sheet.
    float y = aPosition.y;
    if (aFace > 0.5 && y > 0.5 * uThickness) {
        y = mix(y, uThickness, uFlatten);
    }
    vec3 p = vec3(aPosition.x * uRot.x - aPosition.z * uRot.y,
                  y,
                  aPosition.x * uRot.y + aPosition.z * uRot.x) + uTrans;
    vNormal = vec3(aNormal.x * uRot.x - aNormal.z * uRot.y,
                   aNormal.y,
                   aNormal.x * uRot.y + aNormal.z * uRot.x);
    vWorld = p;
    vUv = aTexCoord;
    vFace = aFace;
    gl_Position = uViewProj * vec4(p, 1.0);
}
"""

    const val PIECE_FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uPhoto;
uniform vec3 uLightDir;
uniform vec3 uEyePos;
uniform float uSolved;
varying vec3 vNormal;
varying vec3 vWorld;
varying vec2 vUv;
varying float vFace;

// Soft fill light from the front (unit length), and how much of it a surface facing straight up gets.
const vec3 FILL_DIR = vec3(0.1474, 0.4423, 0.8847);
const float FILL_UP = 0.0973;

void main() {
    vec3 l = uLightDir; // unit length, set by the renderer
    vec3 v = normalize(uEyePos - vWorld);
    vec3 h = normalize(l + v);
    vec3 photo = texture2D(uPhoto, vUv).rgb;
    float topShade = 0.60 + 0.47 * l.y + 0.4 * FILL_UP;

    vec3 color;
    if (vFace < 0.5) {
        // Printed top: lies flat, so its normal is straight up and needs no maths. The photo's
        // own colours, a soft key light, a whisper of gloss.
        float spec = pow(max(h.y, 0.0), 36.0);
        color = photo * topShade + vec3(spec * 0.055);
    } else {
        vec3 n = normalize(vNormal);
        float key = max(dot(n, l), 0.0);
        float fill = max(dot(n, FILL_DIR), 0.0) * 0.22;
        float spec = pow(max(dot(n, h), 0.0), 36.0);
        if (vFace < 1.5) {
            // Chamfered cut: paper catching the light. Fades away once the puzzle is solved.
            vec3 edge = mix(photo, vec3(0.93, 0.90, 0.85), 0.30);
            vec3 bevel = edge * (0.50 + 0.62 * key + fill) + vec3(spec * 0.20);
            color = mix(bevel, photo * topShade, uSolved);
        } else {
            // Wall: grey chipboard core with a thin line of printed paper at the very top.
            float paper = smoothstep(0.80, 0.90, vUv.y);
            vec3 base = mix(vec3(0.60, 0.55, 0.47), vec3(0.93, 0.91, 0.86), paper);
            color = base * (0.42 + 0.55 * key + fill * 1.2);
        }
    }
    gl_FragColor = vec4(color, 1.0);
}
"""

    const val DECAL_VERTEX = """
uniform mat4 uViewProj;
uniform vec3 uCenter;
uniform vec2 uRot;
uniform vec2 uHalf;
attribute vec2 aCorner;
varying vec2 vUv;
void main() {
    vec2 local = aCorner * uHalf;
    vec3 p = vec3(local.x * uRot.x - local.y * uRot.y,
                  0.0,
                  local.x * uRot.y + local.y * uRot.x) + uCenter;
    vUv = aCorner * 0.5 + 0.5;
    gl_Position = uViewProj * vec4(p, 1.0);
}
"""

    const val DECAL_FRAGMENT = """
precision mediump float;
uniform sampler2D uMask;
uniform vec4 uColor;
varying vec2 vUv;
void main() {
    float a = texture2D(uMask, vUv).a * uColor.a;
    gl_FragColor = vec4(uColor.rgb, a);
}
"""
}
