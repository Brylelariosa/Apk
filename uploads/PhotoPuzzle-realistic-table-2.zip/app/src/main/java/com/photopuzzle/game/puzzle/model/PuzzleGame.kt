package com.photopuzzle.game.puzzle.model

import com.photopuzzle.game.puzzle.PieceSide
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * The rules of the table: where pieces are, which are joined, and when two pieces fit.
 *
 * Pure bookkeeping -- no drawing, no touch handling -- so it can be reasoned about (and tested)
 * on its own. All positions are table units; the table's z axis points down the screen.
 */
internal class PuzzleGame(
    val rows: Int,
    val cols: Int,
    val pieces: Array<PuzzlePiece>,
    val cellWidth: Float,
    val cellHeight: Float,
    /** How thick every piece is (the printed top sits this far above the table). */
    val thickness: Float,
    val tableHalfWidth: Float,
    val tableHalfDepth: Float
) {
    val minCell: Float = min(cellWidth, cellHeight)

    /** How closely a piece must sit to its true place beside a neighbour to click in. */
    val snapDistance: Float = SNAP_FRACTION * minCell

    /** Groups from the bottom of the pile to the top. */
    val groups = ArrayList<PieceGroup>()

    val isSolved: Boolean get() = groups.size == 1

    private val sides = PieceSide.values()
    private var candidateMine: PuzzlePiece? = null
    private var candidateOther: PuzzlePiece? = null

    init {
        resetGroups()
    }

    /** Every piece becomes its own group again (new round). */
    fun resetGroups() {
        groups.clear()
        for (piece in pieces) groups.add(PieceGroup(piece))
    }

    /** Number of pieces that are joined to at least one other piece. */
    fun joinedPieces(): Int {
        var count = 0
        for (group in groups) if (group.pieces.size > 1) count += group.pieces.size
        return count
    }

    fun neighbor(piece: PuzzlePiece, side: PieceSide): PuzzlePiece? {
        val r = piece.row + side.rowDelta
        val c = piece.col + side.colDelta
        if (r < 0 || r >= rows || c < 0 || c >= cols) return null
        return pieces[r * cols + c]
    }

    // ---- picking -------------------------------------------------------------------------

    /** Top-most piece under the table point, as the player sees it. */
    fun findTopPieceAt(wx: Float, wz: Float): PuzzlePiece? {
        for (g in groups.size - 1 downTo 0) {
            val group = groups[g]
            for (i in group.pieces.size - 1 downTo 0) {
                val piece = group.pieces[i]
                if (hit(piece, wx, wz)) return piece
            }
        }
        return null
    }

    /** The table point expressed in [piece]'s own (unrotated) frame, into out[0], out[1]. */
    fun toLocal(piece: PuzzlePiece, wx: Float, wz: Float, out: FloatArray) {
        val dx = wx - piece.visualX
        val dz = wz - piece.visualZ
        val a = piece.visualAngle
        val c = cos(a)
        val s = sin(a)
        out[0] = dx * c + dz * s
        out[1] = -dx * s + dz * c
    }

    private val scratch = FloatArray(2)

    private fun hit(piece: PuzzlePiece, wx: Float, wz: Float): Boolean {
        val dx = wx - piece.visualX
        val dz = wz - piece.visualZ
        val r = piece.shape.boundingRadius
        if (dx * dx + dz * dz > r * r) return false
        toLocal(piece, wx, wz, scratch)
        return piece.shape.contains(scratch[0], scratch[1])
    }

    // ---- moving --------------------------------------------------------------------------

    fun bringToFront(group: PieceGroup) {
        if (groups.isNotEmpty() && groups[groups.size - 1] === group) return
        groups.remove(group)
        groups.add(group)
    }

    fun translate(group: PieceGroup, dx: Float, dz: Float) {
        for (i in 0 until group.pieces.size) {
            val p = group.pieces[i]
            p.x += dx
            p.z += dz
        }
    }

    /** Turns the whole group by [da] about the table point ([px], [pz]). */
    fun rotate(group: PieceGroup, da: Float, px: Float, pz: Float) {
        val c = cos(da)
        val s = sin(da)
        for (i in 0 until group.pieces.size) {
            val p = group.pieces[i]
            val dx = p.x - px
            val dz = p.z - pz
            p.x = px + dx * c - dz * s
            p.z = pz + dx * s + dz * c
            p.angle = AngleMath.wrap(p.angle + da)
        }
    }

    /** Centre of the group (mean of its pieces' centres) into out[0], out[1]. */
    fun centroid(group: PieceGroup, out: FloatArray) {
        var sx = 0f
        var sz = 0f
        val n = group.pieces.size
        for (i in 0 until n) {
            sx += group.pieces[i].x
            sz += group.pieces[i].z
        }
        out[0] = sx / n
        out[1] = sz / n
    }

    /** Largest distance from ([px], [pz]) to any piece centre of the group. */
    fun extentFrom(group: PieceGroup, px: Float, pz: Float): Float {
        var best = 0f
        for (i in 0 until group.pieces.size) {
            val p = group.pieces[i]
            val d = hypot(p.x - px, p.z - pz)
            if (d > best) best = d
        }
        return best
    }

    /** Nudges the group back inside the table if any piece has strayed over its edge. */
    fun keepOnTable(group: PieceGroup) {
        var lowX = Float.MAX_VALUE
        var highX = -Float.MAX_VALUE
        var lowZ = Float.MAX_VALUE
        var highZ = -Float.MAX_VALUE
        for (i in 0 until group.pieces.size) {
            val p = group.pieces[i]
            val r = p.shape.boundingRadius * 0.7f
            if (p.x - r < lowX) lowX = p.x - r
            if (p.x + r > highX) highX = p.x + r
            if (p.z - r < lowZ) lowZ = p.z - r
            if (p.z + r > highZ) highZ = p.z + r
        }
        var shiftX = 0f
        var shiftZ = 0f
        if (lowX < -tableHalfWidth) shiftX = -tableHalfWidth - lowX
        else if (highX > tableHalfWidth) shiftX = tableHalfWidth - highX
        if (lowZ < -tableHalfDepth) shiftZ = -tableHalfDepth - lowZ
        else if (highZ > tableHalfDepth) shiftZ = tableHalfDepth - highZ
        if (shiftX != 0f || shiftZ != 0f) translate(group, shiftX, shiftZ)
    }

    // ---- joining -------------------------------------------------------------------------

    /**
     * Called when [moving] has been let go. Joins it to every neighbouring group it now fits
     * against -- right place beside the neighbour, turned the same way, both within a small
     * tolerance -- and returns how many groups were merged in. The dropped group settles
     * exactly into place against the first neighbour; any further group it bridges to is
     * then moved to meet it, so nothing is left a hair out of line.
     */
    fun tryConnect(moving: PieceGroup): Int {
        var merges = 0
        var first = true
        var safety = 0
        while (safety < pieces.size) {
            safety++
            if (!findBestCandidate(moving)) break
            val mine = candidateMine ?: break
            val other = candidateOther ?: break
            val otherGroup = other.group
            if (first) {
                alignGroup(moving, mine, other)
            } else {
                alignGroup(otherGroup, other, mine)
            }
            merge(moving, otherGroup)
            merges++
            first = false
        }
        return merges
    }

    /** Sets candidateMine / candidateOther to the best-fitting pair, if any pair fits at all. */
    private fun findBestCandidate(group: PieceGroup): Boolean {
        var best = Float.MAX_VALUE
        candidateMine = null
        candidateOther = null
        for (i in 0 until group.pieces.size) {
            val m = group.pieces[i]
            for (side in sides) {
                val n = neighbor(m, side) ?: continue
                if (n.group === group) continue
                val angleError = abs(AngleMath.wrap(n.angle - m.angle))
                if (angleError > ROTATION_TOLERANCE) continue

                // Where m would have to be if it sat correctly beside n.
                val dxh = m.homeX - n.homeX
                val dzh = m.homeZ - n.homeZ
                val ca = cos(n.angle)
                val sa = sin(n.angle)
                val expectedX = n.x + dxh * ca - dzh * sa
                val expectedZ = n.z + dxh * sa + dzh * ca
                val distance = hypot(m.x - expectedX, m.z - expectedZ)
                if (distance > snapDistance) continue

                val score = distance / snapDistance + angleError / ROTATION_TOLERANCE
                if (score < best) {
                    best = score
                    candidateMine = m
                    candidateOther = n
                }
            }
        }
        return candidateMine != null
    }

    /**
     * Moves [group] rigidly so that [piece] sits exactly where it belongs beside [anchor]
     * (same turn, correct offset). The visual offsets keep the motion smooth.
     */
    private fun alignGroup(group: PieceGroup, piece: PuzzlePiece, anchor: PuzzlePiece) {
        val list = group.pieces
        val count = list.size
        val oldX = FloatArray(count)
        val oldZ = FloatArray(count)
        val oldA = FloatArray(count)
        for (i in 0 until count) {
            val p = list[i]
            oldX[i] = p.visualX
            oldZ[i] = p.visualZ
            oldA[i] = p.visualAngle
        }

        rotate(group, AngleMath.wrap(anchor.angle - piece.angle), piece.x, piece.z)

        val dxh = piece.homeX - anchor.homeX
        val dzh = piece.homeZ - anchor.homeZ
        val ca = cos(anchor.angle)
        val sa = sin(anchor.angle)
        val targetX = anchor.x + dxh * ca - dzh * sa
        val targetZ = anchor.z + dxh * sa + dzh * ca
        translate(group, targetX - piece.x, targetZ - piece.z)

        for (i in 0 until count) {
            val p = list[i]
            p.animX = oldX[i] - p.x
            p.animZ = oldZ[i] - p.z
            p.animAngle = AngleMath.wrap(oldA[i] - p.angle)
            p.animDelay = 0f
        }
    }

    private fun merge(into: PieceGroup, from: PieceGroup) {
        for (i in 0 until from.pieces.size) {
            val p = from.pieces[i]
            p.group = into
            into.pieces.add(p)
        }
        from.pieces.clear()
        groups.remove(from)
    }

    /** Lays the finished picture upright with its centre at ([centerX], [centerZ]). */
    fun settleSolved(centerX: Float, centerZ: Float) {
        for (p in pieces) {
            val oldX = p.visualX
            val oldZ = p.visualZ
            val oldA = p.visualAngle
            p.angle = 0f
            p.x = centerX + p.homeX
            p.z = centerZ + p.homeZ
            p.animX = oldX - p.x
            p.animZ = oldZ - p.z
            p.animAngle = AngleMath.wrap(oldA)
            p.animDelay = 0f
        }
    }

    companion object {
        /** Distance tolerance, as a fraction of the smaller cell side. */
        const val SNAP_FRACTION = 0.18f

        /** How far off the two pieces' turn may be (9 degrees), in radians. */
        const val ROTATION_TOLERANCE = 0.157f
    }
}
