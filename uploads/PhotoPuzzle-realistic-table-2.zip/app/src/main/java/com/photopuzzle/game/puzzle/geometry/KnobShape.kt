package com.photopuzzle.game.puzzle.geometry

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/**
 * Proportions of one jigsaw tab, all in units of the length of the edge it sits on:
 * a flat edge turns into a short concave "shoulder", pinches into a narrow neck, flares
 * out and closes around a round head -- the classic mushroom knob of a die-cut puzzle.
 */
internal class KnobParams(
    /** Where along the edge (0..1) the knob is centred. */
    val center: Double,
    /** Half-width of the knob's base, measured on the flat edge. */
    val shoulder: Double,
    val neckWidth: Double,
    val neckHeight: Double,
    val headRadius: Double,
    /** Distance of the head circle's centre from the edge. */
    val headCenter: Double,
    /** Angle (radians, from straight down the neck) at which the flare meets the head circle. */
    val flareRadians: Double,
    /** Sideways shift of the head relative to the neck, so no two knobs are identical. */
    val skew: Double
) {
    companion object {
        /**
         * A slightly different knob for every edge, like a hand-cut puzzle. [jitter] is the
         * per-edge value the native/Kotlin edge generator already produces; it shifts the
         * knob off the exact middle of its edge.
         */
        fun random(random: Random, jitter: Float): KnobParams {
            val offset = (jitter * 0.55 + random.range(-0.012, 0.012)).coerceIn(-0.045, 0.045)
            return KnobParams(
                center = 0.5 + offset,
                shoulder = 0.120 * random.range(0.95, 1.05),
                neckWidth = 0.048 * random.range(0.92, 1.10),
                neckHeight = 0.058 * random.range(0.92, 1.12),
                headRadius = 0.122 * random.range(0.94, 1.06),
                headCenter = 0.168 * random.range(0.97, 1.03),
                flareRadians = Math.toRadians(52.0 * random.range(0.94, 1.06)),
                skew = random.range(-0.010, 0.010)
            )
        }

        private fun Random.range(low: Double, high: Double): Double = low + nextDouble() * (high - low)
    }
}

/** Turns [KnobParams] into a polyline. */
internal object KnobShape {

    private const val SHOULDER_STEPS = 7
    private const val FLARE_STEPS = 8
    private const val ARC_STEPS = 11

    /**
     * The knob as interleaved (t, d) pairs: t runs along the edge from 0 to 1 and d is how far
     * the outline sits off the flat edge (positive = towards the tab). Starts on the flat edge
     * at the knob's left shoulder and ends on it at the right shoulder.
     */
    fun profile(params: KnobParams): DoubleArray {
        val left = PointList(32)
        val right = PointList(32)
        half(params, -1.0, left)
        half(params, 1.0, right)

        val out = PointList(64)
        for (i in 0 until left.size) out.add(left.x(i), left.y(i))
        // The right half ends on the head's very top, which the left half already contains.
        for (i in right.size - 2 downTo 0) out.add(right.x(i), right.y(i))
        return out.toArray()
    }

    /** One side of the knob, from its shoulder on the flat edge up to the top of the head. */
    private fun half(p: KnobParams, side: Double, out: PointList) {
        val headX = p.center + p.skew
        val a1 = p.flareRadians
        val sx = p.center + side * p.shoulder
        val nx = p.center + side * p.neckWidth
        val ny = p.neckHeight
        val qx = headX + side * p.headRadius * sin(a1)
        val qy = p.headCenter - p.headRadius * cos(a1)
        val tx = side * cos(a1)
        val ty = sin(a1)

        out.add(sx, 0.0)

        // Shoulder: leaves the flat edge horizontally, arrives at the neck vertically.
        val k1 = abs(sx - nx) * 0.85
        val k2 = p.neckHeight * 0.55
        cubic(out, sx, 0.0, sx - side * k1, 0.0, nx, ny - k2, nx, ny, SHOULDER_STEPS)

        // Flare: neck (vertical) into the head circle, tangent-continuous with it.
        val m = hypot(qx - nx, qy - ny) * 0.45
        cubic(out, nx, ny, nx, ny + m, qx - tx * m, qy - ty * m, qx, qy, FLARE_STEPS)

        // Head: arc over the top.
        for (i in 1..ARC_STEPS) {
            val a = a1 + (PI - a1) * i / ARC_STEPS
            out.add(headX + side * p.headRadius * sin(a), p.headCenter - p.headRadius * cos(a))
        }
    }

    private fun cubic(
        out: PointList,
        x0: Double, y0: Double,
        x1: Double, y1: Double,
        x2: Double, y2: Double,
        x3: Double, y3: Double,
        steps: Int
    ) {
        for (i in 1..steps) {
            val t = i.toDouble() / steps
            val m = 1.0 - t
            val b0 = m * m * m
            val b1 = 3.0 * m * m * t
            val b2 = 3.0 * m * t * t
            val b3 = t * t * t
            out.add(b0 * x0 + b1 * x1 + b2 * x2 + b3 * x3, b0 * y0 + b1 * y1 + b2 * y2 + b3 * y3)
        }
    }
}
