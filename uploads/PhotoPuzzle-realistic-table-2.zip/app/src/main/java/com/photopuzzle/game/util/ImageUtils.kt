package com.photopuzzle.game.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import java.io.FileInputStream
import java.io.IOException
import kotlin.math.max

/**
 * Loading helpers kept separate from any Activity/View so they're easy to
 * reuse (and reason about) independent of the UI. Uses the platform
 * `android.media.ExifInterface` rather than the AndroidX one: minSdk 24
 * already supports the InputStream constructor we need, so pulling in the
 * androidx artifact would only add size for no benefit here.
 */
internal object ImageUtils {

    /**
     * Decodes the JPEG/PNG/etc. at [path], downsampled to roughly [maxDimension]
     * on its longer side (memory safety against very large camera
     * photos), and rotated upright according to its EXIF orientation tag.
     * Returns null if the file can't be decoded as an image at all.
     */
    fun loadOrientedBitmap(path: String, maxDimension: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        // Halve while the longer side stays close to (or above) the wanted size, so a 12 MP camera
        // photo decodes at ~2000 px instead of its full 48 MB.
        val longSide = max(bounds.outWidth, bounds.outHeight)
        var sampleSize = 1
        while (longSide / (sampleSize * 2) >= maxDimension * 0.85f) {
            sampleSize *= 2
        }

        val decoded = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply {
            inSampleSize = sampleSize
        }) ?: return null

        val rotationDegrees = readExifRotationDegrees(path)
        if (rotationDegrees == 0) return decoded

        val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded) decoded.recycle()
        return rotated
    }

    private fun readExifRotationDegrees(path: String): Int = try {
        FileInputStream(path).use { stream ->
            val orientation = ExifInterface(stream).getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90
                ExifInterface.ORIENTATION_ROTATE_180 -> 180
                ExifInterface.ORIENTATION_ROTATE_270 -> 270
                else -> 0
            }
        }
    } catch (error: IOException) {
        0
    }
}
