package com.photopuzzle.game.puzzle.engine

import com.photopuzzle.game.puzzle.PieceSide
import com.photopuzzle.game.puzzle.model.AngleMath
import com.photopuzzle.game.puzzle.model.PieceGroup
import com.photopuzzle.game.puzzle.model.PuzzleGame
import com.photopuzzle.game.puzzle.model.PuzzlePiece
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max

/**
 * Turns finger input into what a hand does at a real puzzle table.
 *
 *  - Touch the middle of a piece and drag: the piece (with everything joined to it) slides.
 *  - Hold a piece by its edge and swipe around it: the piece turns, following your finger
 *    around its centre, like pushing the rim of a real piece round on the table.
 *  - Touch bare table and drag: the view pans. Pinch: zoom.
 *
 * The mode is decided once, when the finger lands, so a gesture never changes character
 * half-way. Moves only record where the finger is; the work is done once per frame in [update],
 * which also copes with the view moving under a stationary finger (edge auto-pan).
 *
 * Everything runs on the GL thread.
 */
internal class TouchInteraction(private val engine: PuzzleEngine) {

    private enum class Mode { IDLE, DRAG, ROTATE, PAN, ZOOM }

    private var mode = Mode.IDLE
    private var group: PieceGroup? = null

    /** A finger is on the table doing something, so every frame matters. */
    val isActive: Boolean get() = mode != Mode.IDLE

    private var fingerX = 0f
    private var fingerY = 0f
    private var lastTableX = 0f
    private var lastTableZ = 0f
    private var pivotX = 0f
    private var pivotZ = 0f
    private var lastAngle = 0f
    private var anchorX = 0f
    private var anchorZ = 0f

    private val point = FloatArray(2)
    private val local = FloatArray(2)

    fun reset() {
        mode = Mode.IDLE
        group = null
    }

    fun pointerDown(sx: Float, sy: Float) {
        val game = engine.game
        if (game == null || engine.isCelebrating) {
            mode = Mode.IDLE
            return
        }
        fingerX = sx
        fingerY = sy
        engine.camera.cancelAnimation()
        if (!engine.camera.screenToTable(sx, sy, 0f, point)) {
            mode = Mode.IDLE
            return
        }
        val tx = point[0]
        val tz = point[1]

        val piece = game.findTopPieceAt(tx, tz)
        if (piece == null) {
            mode = Mode.PAN
            anchorX = tx
            anchorZ = tz
            return
        }

        val g = piece.group
        group = g
        game.bringToFront(g)
        g.liftTarget = engine.liftHeight
        game.toLocal(piece, tx, tz, local)

        if (engine.rotationEnabled && isTurnHandle(game, piece, local[0], local[1])) {
            game.centroid(g, point)
            pivotX = point[0]
            pivotZ = point[1]
            lastAngle = atan2(tz - pivotZ, tx - pivotX)
            mode = Mode.ROTATE
            engine.notifyTurnStarted()
        } else {
            lastTableX = tx
            lastTableZ = tz
            mode = Mode.DRAG
        }
        engine.notifyPieceLifted()
    }

    fun pointerMove(sx: Float, sy: Float) {
        fingerX = sx
        fingerY = sy
    }

    fun pointerUp() {
        val g = group
        val previous = mode
        mode = Mode.IDLE
        group = null
        engine.hideRing()
        if ((previous == Mode.DRAG || previous == Mode.ROTATE) && g != null) {
            g.liftTarget = 0f
            engine.onGroupReleased(g)
        }
    }

    /** One finger of a pinch stayed down: carry on by panning with it. */
    fun pointerRebase(sx: Float, sy: Float) {
        if (mode != Mode.IDLE && mode != Mode.ZOOM && mode != Mode.PAN) return
        fingerX = sx
        fingerY = sy
        if (engine.camera.screenToTable(sx, sy, 0f, point)) {
            anchorX = point[0]
            anchorZ = point[1]
            mode = Mode.PAN
        }
    }

    fun pinchBegin(fx: Float, fy: Float) {
        if (mode == Mode.PAN || mode == Mode.IDLE) {
            mode = Mode.ZOOM
            engine.camera.cancelAnimation()
            engine.camera.beginAnchor(fx, fy)
        }
    }

    fun pinch(scaleFactor: Float, fx: Float, fy: Float) {
        if (mode == Mode.ZOOM) engine.camera.applyPinch(scaleFactor, fx, fy)
    }

    fun pinchEnd() {
        if (mode == Mode.ZOOM) mode = Mode.IDLE
    }

    fun update(dt: Float) {
        val game = engine.game ?: return
        val camera = engine.camera
        when (mode) {
            Mode.DRAG -> {
                val g = group ?: return
                if (camera.screenToTable(fingerX, fingerY, 0f, point)) {
                    game.translate(g, point[0] - lastTableX, point[1] - lastTableZ)
                    game.keepOnTable(g)
                    lastTableX = point[0]
                    lastTableZ = point[1]
                }
                autoPan(dt)
            }
            Mode.ROTATE -> {
                val g = group ?: return
                if (camera.screenToTable(fingerX, fingerY, 0f, point)) {
                    val dx = point[0] - pivotX
                    val dz = point[1] - pivotZ
                    // Too close to the pivot the angle is meaningless noise.
                    if (hypot(dx, dz) > game.minCell * 0.08f) {
                        val a = atan2(dz, dx)
                        val da = AngleMath.wrap(a - lastAngle)
                        if (da != 0f) game.rotate(g, da, pivotX, pivotZ)
                        lastAngle = a
                    }
                }
                engine.showRing(pivotX, pivotZ, game.extentFrom(g, pivotX, pivotZ) + 0.62f * game.minCell, lastAngle)
            }
            Mode.PAN -> {
                if (camera.screenToTable(fingerX, fingerY, 0f, point)) {
                    camera.panBy(anchorX - point[0], anchorZ - point[1])
                }
            }
            else -> {
            }
        }
    }

    /**
     * Is this touch on an exposed edge of the piece? Not the middle (that is for dragging), and
     * not a side already joined to a neighbour in the same group (an interior seam is not
     * something you can take hold of). The middle is never smaller than a fingertip, so tiny
     * pieces can still be dragged; zoom in to turn them.
     */
    private fun isTurnHandle(game: PuzzleGame, piece: PuzzlePiece, lx: Float, lz: Float): Boolean {
        val core = max(
            CORE_FRACTION * game.minCell,
            CORE_MIN_DP * engine.density / engine.camera.zoom
        )
        if (hypot(lx, lz) <= core) return false

        val side = if (abs(lx) * game.cellHeight >= abs(lz) * game.cellWidth) {
            if (lx > 0f) PieceSide.RIGHT else PieceSide.LEFT
        } else {
            if (lz > 0f) PieceSide.BOTTOM else PieceSide.TOP
        }
        val neighbor = game.neighbor(piece, side)
        return neighbor == null || neighbor.group !== piece.group
    }

    /** Drags near the screen edge scroll the table along so a held piece can go further. */
    private fun autoPan(dt: Float) {
        val camera = engine.camera
        val margin = AUTO_PAN_MARGIN_DP * engine.density
        val right = camera.viewWidth - margin
        val bottom = camera.viewHeight - margin
        var vx = 0f
        var vy = 0f
        if (fingerX < margin) vx = -(margin - fingerX) / margin
        else if (fingerX > right) vx = (fingerX - right) / margin
        if (fingerY < margin) vy = -(margin - fingerY) / margin
        else if (fingerY > bottom) vy = (fingerY - bottom) / margin
        if (vx != 0f || vy != 0f) {
            val speed = AUTO_PAN_SPEED * dt / camera.zoom
            camera.panBy(vx.coerceIn(-1f, 1f) * speed, vy.coerceIn(-1f, 1f) * speed)
        }
    }

    private companion object {
        /** Radius of the "grab to drag" middle, as a fraction of the smaller cell side. */
        const val CORE_FRACTION = 0.33f

        /** ...but never smaller than this on screen. */
        const val CORE_MIN_DP = 14f

        const val AUTO_PAN_MARGIN_DP = 52f
        const val AUTO_PAN_SPEED = 750f
    }
}
