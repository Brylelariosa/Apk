package com.photopuzzle.game.puzzle.render3d

import android.content.Context
import android.graphics.Bitmap
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.core.view.doOnLayout
import com.photopuzzle.game.puzzle.engine.PuzzleBuilder
import com.photopuzzle.game.puzzle.engine.PuzzleEngine
import com.photopuzzle.game.puzzle.engine.PuzzleListener
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay

/**
 * The puzzle table as a view: a GL surface plus the finger handling that feeds [PuzzleEngine].
 *
 * Touches arrive on the main thread; each is reduced to plain numbers and handed to the GL
 * thread, where the engine lives. Events from the engine come back the other way, hopping to
 * the main thread before reaching [puzzleListener].
 *
 * The surface draws on demand, not continuously: every hand-off to the GL thread asks for a
 * frame, and the renderer keeps asking only while something is moving. A table at rest uses no
 * GPU at all, which keeps the phone from heating up and throttling.
 */
class PuzzleBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    /** Receives game events on the main thread. */
    var puzzleListener: PuzzleListener? = null

    private val engine = PuzzleEngine(
        object : PuzzleListener {
            override fun onReady() { post { puzzleListener?.onReady() } }
            override fun onProgress(joined: Int, total: Int) { post { puzzleListener?.onProgress(joined, total) } }
            override fun onPieceLifted() { post { puzzleListener?.onPieceLifted() } }
            override fun onPieceJoined() { post { puzzleListener?.onPieceJoined() } }
            override fun onTurnStarted() { post { puzzleListener?.onTurnStarted() } }
            override fun onCelebrationStarted() { post { puzzleListener?.onCelebrationStarted() } }
            override fun onSolved() { post { puzzleListener?.onSolved() } }
            override fun onFailed() { post { puzzleListener?.onFailed() } }
        },
        resources.displayMetrics.density
    )

    private var primaryPointerId = -1

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                val fx = detector.focusX
                val fy = detector.focusY
                onGlThread { engine.pinchBegin(fx, fy) }
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val factor = detector.scaleFactor
                val fx = detector.focusX
                val fy = detector.focusY
                onGlThread { engine.pinch(factor, fx, fy) }
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                onGlThread { engine.pinchEnd() }
            }
        }
    )

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(MsaaConfigChooser())
        setRenderer(PuzzleRenderer(context.applicationContext.resources, engine) { requestRender() })
        renderMode = RENDERMODE_WHEN_DIRTY
        preserveEGLContextOnPause = true
    }

    /** Runs [action] on the GL thread, then draws a frame so its effect shows. */
    private fun onGlThread(action: () -> Unit) {
        queueEvent { action() }
        requestRender()
    }

    /**
     * Cuts [photo] into a [rows] x [cols] puzzle and pours it onto the table. Takes ownership
     * of the bitmap. The cutting runs on a worker thread; [PuzzleListener.onReady] says when
     * the table is set.
     */
    fun start(photo: Bitmap, rows: Int, cols: Int, rotatePieces: Boolean) {
        doOnLayout { laidOut ->
            val width = laidOut.width
            val height = laidOut.height
            val seed = System.nanoTime()
            Thread {
                try {
                    val built = PuzzleBuilder.build(photo, rows, cols, width, height, rotatePieces, seed)
                    onGlThread { engine.install(built) }
                } catch (error: Throwable) {
                    post { puzzleListener?.onFailed() }
                }
            }.start()
        }
    }

    /** Scoops the pieces up and pours them out again. */
    fun shuffle() {
        onGlThread { engine.shuffle() }
    }

    /** Glides the view back to show the whole table. */
    fun fitView() {
        onGlThread { engine.fitView() }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                primaryPointerId = event.getPointerId(0)
                val x = event.x
                val y = event.y
                onGlThread { engine.pointerDown(x, y) }
            }
            MotionEvent.ACTION_MOVE -> {
                val index = event.findPointerIndex(primaryPointerId)
                if (index >= 0) {
                    val x = event.getX(index)
                    val y = event.getY(index)
                    onGlThread { engine.pointerMove(x, y) }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val liftedIndex = event.actionIndex
                if (event.getPointerId(liftedIndex) == primaryPointerId) {
                    // The finger that was working the table came off while another stays down:
                    // let go of whatever it held, then carry on panning with the other finger.
                    val remaining = if (liftedIndex == 0) 1 else 0
                    primaryPointerId = event.getPointerId(remaining)
                    val x = event.getX(remaining)
                    val y = event.getY(remaining)
                    onGlThread {
                        engine.pointerUp()
                        engine.pointerRebase(x, y)
                    }
                } else {
                    // A second finger came off while the first stays down (a pinch ended): the
                    // first carries on, so let it pan the table if it is not holding a piece.
                    val index = event.findPointerIndex(primaryPointerId)
                    if (index >= 0) {
                        val x = event.getX(index)
                        val y = event.getY(index)
                        onGlThread { engine.pointerRebase(x, y) }
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                primaryPointerId = -1
                onGlThread { engine.pointerUp() }
            }
        }
        return true
    }

    /**
     * Asks for a multisampled surface where the device offers one, so piece edges are smooth,
     * and a 24-bit depth buffer where there is one, so the seams between joined pieces stay
     * clean. Falls back step by step to what the device has.
     */
    private class MsaaConfigChooser : GLSurfaceView.EGLConfigChooser {
        override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
            for (samples in intArrayOf(4, 2, 0)) {
                for (depth in intArrayOf(24, 16)) {
                    val attributes = if (samples > 0) {
                        intArrayOf(
                            EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
                            EGL_DEPTH_SIZE, depth, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
                            EGL_SAMPLE_BUFFERS, 1, EGL_SAMPLES, samples, EGL_NONE
                        )
                    } else {
                        intArrayOf(
                            EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
                            EGL_DEPTH_SIZE, depth, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL_NONE
                        )
                    }
                    val count = IntArray(1)
                    if (!egl.eglChooseConfig(display, attributes, null, 0, count) || count[0] <= 0) continue
                    val configs = arrayOfNulls<EGLConfig>(count[0])
                    if (!egl.eglChooseConfig(display, attributes, configs, count[0], count)) continue
                    val chosen = configs[0]
                    if (chosen != null) return chosen
                }
            }
            throw IllegalStateException("No suitable EGL configuration")
        }

        private companion object {
            const val EGL_ALPHA_SIZE = 0x3021
            const val EGL_BLUE_SIZE = 0x3022
            const val EGL_GREEN_SIZE = 0x3023
            const val EGL_RED_SIZE = 0x3024
            const val EGL_DEPTH_SIZE = 0x3025
            const val EGL_SAMPLES = 0x3031
            const val EGL_SAMPLE_BUFFERS = 0x3032
            const val EGL_NONE = 0x3038
            const val EGL_RENDERABLE_TYPE = 0x3040
            const val EGL_OPENGL_ES2_BIT = 4
        }
    }
}
