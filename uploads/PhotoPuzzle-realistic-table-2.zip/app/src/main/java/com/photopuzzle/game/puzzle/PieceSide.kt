package com.photopuzzle.game.puzzle

/**
 * The four sides of a grid piece, and the (row, col) step to the
 * neighboring cell across each one.
 *
 * One shared definition of "which side is which", used by the edge
 * helpers (which edge belongs to which side of a piece), the game rules
 * (grid adjacency when joining pieces) and the touch handling (is the
 * touched edge already joined to a neighbour?), so grid geometry and piece
 * geometry always talk about sides the same way.
 */
internal enum class PieceSide(val rowDelta: Int, val colDelta: Int) {
    TOP(-1, 0), RIGHT(0, 1), BOTTOM(1, 0), LEFT(0, -1)
}
