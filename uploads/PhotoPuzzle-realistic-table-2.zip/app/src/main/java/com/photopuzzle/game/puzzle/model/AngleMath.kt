package com.photopuzzle.game.puzzle.model

/** Small angle helpers. Angles are radians, positive = clockwise on screen (the table's z axis points down). */
internal object AngleMath {
    const val PI_F = 3.1415927f
    const val TWO_PI_F = 6.2831855f

    /** Maps [angle] into (-PI, PI]. */
    fun wrap(angle: Float): Float {
        if (angle.isNaN() || angle.isInfinite()) return 0f
        var a = angle
        while (a > PI_F) a -= TWO_PI_F
        while (a <= -PI_F) a += TWO_PI_F
        return a
    }
}
