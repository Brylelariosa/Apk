package com.photopuzzle.game.puzzle.model

import com.photopuzzle.game.puzzle.geometry.PieceMeshData

/**
 * Immutable geometry of one piece: its outline relative to its own cell centre (x / z pairs,
 * z pointing down the screen), plus the 3D mesh built from that outline.
 */
internal class PieceShape(val polygon: FloatArray, val mesh: PieceMeshData) {

    val boundingRadius: Float
    val minX: Float
    val maxX: Float
    val minZ: Float
    val maxZ: Float

    init {
        var lowX = Float.MAX_VALUE
        var highX = -Float.MAX_VALUE
        var lowZ = Float.MAX_VALUE
        var highZ = -Float.MAX_VALUE
        var radiusSquared = 0f
        for (i in 0 until polygon.size / 2) {
            val x = polygon[i * 2]
            val z = polygon[i * 2 + 1]
            if (x < lowX) lowX = x
            if (x > highX) highX = x
            if (z < lowZ) lowZ = z
            if (z > highZ) highZ = z
            val d = x * x + z * z
            if (d > radiusSquared) radiusSquared = d
        }
        minX = lowX
        maxX = highX
        minZ = lowZ
        maxZ = highZ
        boundingRadius = kotlin.math.sqrt(radiusSquared)
    }

    /** Even-odd point-in-polygon test in the piece's own frame. */
    fun contains(lx: Float, lz: Float): Boolean {
        var inside = false
        val n = polygon.size / 2
        var j = n - 1
        for (i in 0 until n) {
            val xi = polygon[i * 2]
            val zi = polygon[i * 2 + 1]
            val xj = polygon[j * 2]
            val zj = polygon[j * 2 + 1]
            if ((zi > lz) != (zj > lz) && lx < (xj - xi) * (lz - zi) / (zj - zi) + xi) {
                inside = !inside
            }
            j = i
        }
        return inside
    }
}

/**
 * One piece on the table. (x, z) is where its cell centre lies, [angle] how far it is turned
 * (clockwise-positive, radians). The anim* fields are a purely visual offset that eases back
 * to zero, so a logical change of pose (snapping into place, the opening pour, the final
 * straightening) glides instead of jumping.
 */
internal class PuzzlePiece(
    val id: Int,
    val row: Int,
    val col: Int,
    /** Cell centre in the assembled picture, relative to the picture's centre. */
    val homeX: Float,
    val homeZ: Float,
    val shape: PieceShape
) {
    var x = 0f
    var z = 0f
    var angle = 0f

    var animX = 0f
    var animZ = 0f
    var animAngle = 0f

    /** Seconds before the visual offset starts easing out (staggers the opening pour). */
    var animDelay = 0f

    lateinit var group: PieceGroup

    val visualX: Float get() = x + animX
    val visualZ: Float get() = z + animZ
    val visualAngle: Float get() = angle + animAngle
}

/** Pieces joined together; they move and turn as one rigid body. */
internal class PieceGroup(first: PuzzlePiece) {
    val pieces = ArrayList<PuzzlePiece>()

    /** Current and wanted height above the table (a held group is lifted). */
    var lift = 0f
    var liftTarget = 0f

    init {
        pieces.add(first)
        first.group = this
    }
}
