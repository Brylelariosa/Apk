package com.photopuzzle.game.puzzle.geometry

/**
 * Growable list of 2D points kept as interleaved doubles (x0, y0, x1, y1, ...),
 * so the geometry code can build outlines without boxing every coordinate.
 */
internal class PointList(initialCapacity: Int = 64) {

    private var data = DoubleArray(initialCapacity * 2)

    var size: Int = 0
        private set

    fun add(x: Double, y: Double) {
        val needed = size * 2 + 2
        if (needed > data.size) data = data.copyOf(maxOf(needed, data.size * 2))
        data[size * 2] = x
        data[size * 2 + 1] = y
        size++
    }

    fun x(index: Int): Double = data[index * 2]

    fun y(index: Int): Double = data[index * 2 + 1]

    /** Tight copy of the points added so far, interleaved x/y. */
    fun toArray(): DoubleArray = data.copyOf(size * 2)
}
