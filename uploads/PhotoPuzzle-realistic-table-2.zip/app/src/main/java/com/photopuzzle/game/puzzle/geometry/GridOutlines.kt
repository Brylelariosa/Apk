package com.photopuzzle.game.puzzle.geometry

import com.photopuzzle.game.puzzle.EdgeGeometry
import kotlin.random.Random

/**
 * Builds the cut lines of a whole puzzle once, then hands out each piece's closed outline.
 *
 * Every internal edge is generated a single time as a polyline in picture coordinates;
 * the two pieces that share it read the same points (one forwards, one backwards), so a
 * tab always fits its blank exactly and the assembled picture has no gaps or overlaps.
 */
internal class GridOutlines(
    private val rows: Int,
    private val cols: Int,
    private val cellWidth: Double,
    private val cellHeight: Double,
    edgeData: FloatArray,
    seed: Long
) {
    /** Edge between (r, c) and (r + 1, c), running left to right. Index r * cols + c. */
    private val horizontal = arrayOfNulls<DoubleArray>(maxOf(0, (rows - 1) * cols))

    /** Edge between (r, c) and (r, c + 1), running top to bottom. Index r * (cols - 1) + c. */
    private val vertical = arrayOfNulls<DoubleArray>(maxOf(0, rows * (cols - 1)))

    init {
        for (r in 0 until rows - 1) {
            for (c in 0 until cols) {
                val index = EdgeGeometry.horizontalIndex(cols, r, c)
                val knob = knobFor(seed, index, edgeData[index * 2 + 1])
                val sign = if (edgeData[index * 2] >= 0f) 1.0 else -1.0
                horizontal[r * cols + c] = horizontalEdge(r, c, sign, knob)
            }
        }
        for (r in 0 until rows) {
            for (c in 0 until cols - 1) {
                val index = EdgeGeometry.verticalIndex(rows, cols, r, c)
                val knob = knobFor(seed, index, edgeData[index * 2 + 1])
                val sign = if (edgeData[index * 2] >= 0f) 1.0 else -1.0
                vertical[r * (cols - 1) + c] = verticalEdge(r, c, sign, knob)
            }
        }
    }

    /**
     * Closed outline of piece ([row], [col]) in picture coordinates, interleaved x/y, running
     * clockwise on screen (y grows downwards) -- i.e. positive signed area in (x, y).
     */
    fun outline(row: Int, col: Int): DoubleArray {
        val x0 = col * cellWidth
        val y0 = row * cellHeight
        val x1 = x0 + cellWidth
        val y1 = y0 + cellHeight
        val out = PointList(256)

        // Top, left to right.
        if (row > 0) {
            appendForward(out, horizontal[(row - 1) * cols + col]!!, false)
        } else {
            out.add(x0, y0)
            out.add(x1, y0)
        }
        // Right, top to bottom.
        if (col < cols - 1) {
            appendForward(out, vertical[row * (cols - 1) + col]!!, true)
        } else {
            out.add(x1, y1)
        }
        // Bottom, right to left.
        if (row < rows - 1) {
            appendReversed(out, horizontal[row * cols + col]!!, true, false)
        } else {
            out.add(x0, y1)
        }
        // Left, bottom to top; its last point is this outline's first.
        if (col > 0) {
            appendReversed(out, vertical[row * (cols - 1) + (col - 1)]!!, true, true)
        }
        return out.toArray()
    }

    private fun knobFor(seed: Long, edgeIndex: Int, jitter: Float): KnobParams =
        KnobParams.random(Random(seed * 31L + edgeIndex * 7919L + 17L), jitter)

    private fun horizontalEdge(r: Int, c: Int, sign: Double, knob: KnobParams): DoubleArray {
        val x0 = c * cellWidth
        val yBase = (r + 1) * cellHeight
        val profile = KnobShape.profile(knob)
        val out = PointList(profile.size / 2 + 2)
        out.add(x0, yBase)
        for (i in 0 until profile.size / 2) {
            out.add(x0 + profile[i * 2] * cellWidth, yBase + sign * profile[i * 2 + 1] * cellWidth)
        }
        out.add(x0 + cellWidth, yBase)
        return out.toArray()
    }

    private fun verticalEdge(r: Int, c: Int, sign: Double, knob: KnobParams): DoubleArray {
        val y0 = r * cellHeight
        val xBase = (c + 1) * cellWidth
        val profile = KnobShape.profile(knob)
        val out = PointList(profile.size / 2 + 2)
        out.add(xBase, y0)
        for (i in 0 until profile.size / 2) {
            out.add(xBase + sign * profile[i * 2 + 1] * cellHeight, y0 + profile[i * 2] * cellHeight)
        }
        out.add(xBase, y0 + cellHeight)
        return out.toArray()
    }

    private fun appendForward(out: PointList, curve: DoubleArray, skipFirst: Boolean) {
        val count = curve.size / 2
        val start = if (skipFirst) 1 else 0
        for (i in start until count) out.add(curve[i * 2], curve[i * 2 + 1])
    }

    private fun appendReversed(out: PointList, curve: DoubleArray, skipFirst: Boolean, skipLast: Boolean) {
        val count = curve.size / 2
        val from = count - 1 - (if (skipFirst) 1 else 0)
        val to = if (skipLast) 1 else 0
        for (i in from downTo to) out.add(curve[i * 2], curve[i * 2 + 1])
    }
}
