package app.claudefilebridge

import kotlinx.coroutines.CompletableDeferred
import org.json.JSONObject
import java.util.Locale

/** What Claude may do. Destructive ones are OFF by default. */
enum class Perm(val key: String, val label: String, val defaultOn: Boolean) {
    READ("read", "Read files", true),
    CREATE("create", "Create files", true),
    MODIFY("modify", "Modify files", true),
    CREATE_FOLDERS("create_folders", "Create folders", true),
    CREATE_ZIP("create_zip", "Create ZIP", true),
    EXTRACT_ZIP("extract_zip", "Extract ZIP", true),
    MOVE("move", "Move files", false),
    DELETE("delete", "Delete files", false),
    UPLOAD("upload", "Upload files", false)
}

enum class Conn { STOPPED, CONNECTING, CONNECTED, POLLING, OFFLINE, UNPAIRED }

class Command(
    val id: String,
    val tool: String,
    val args: JSONObject,
    val destructive: Boolean,
    val nonce: String,
    val iat: Long,
    val exp: Long
)

/** Expected, user-presentable failure with a machine code. */
class OpError(val code: String, message: String, val extra: JSONObject? = null) : Exception(message)

/** Per-operation hooks: ask the user, report progress. */
class OpCtx(
    val confirm: suspend (String, String) -> Boolean,
    val progress: (Float?, String) -> Unit
)

data class OpInfo(val tool: String, val note: String, val progress: Float?)

class Pending(val id: String, val title: String, val detail: String, val deferred: CompletableDeferred<Boolean>)

data class Act(
    val time: Long,
    val tool: String,
    val ok: Boolean,
    val status: String,
    val bytes: Long,
    val ms: Long,
    val detail: String,
    val remote: Boolean
)

fun fmtBytes(b: Long): String {
    if (b < 0) return "?"
    val u = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < u.size - 1) {
        v /= 1024
        i++
    }
    return if (i == 0) "$b B" else String.format(Locale.US, "%.1f %s", v, u[i])
}

fun jsonOf(vararg p: Pair<String, Any?>): JSONObject {
    val o = JSONObject()
    for ((k, v) in p) o.put(k, v ?: JSONObject.NULL)
    return o
}

/** String value or null for missing / JSON null. */
fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k)
