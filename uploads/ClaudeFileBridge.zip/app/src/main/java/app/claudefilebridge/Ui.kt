package app.claudefilebridge

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Screen { HOME, SETUP, FILES, ZIP, BUILD, APKS, ACTIVITY, SETTINGS }

// ---------------------------------------------------------------- small helpers

private fun startBridge(ctx: Context) {
    Prefs.bridgeOn = true
    ContextCompat.startForegroundService(ctx, Intent(ctx, BridgeService::class.java))
}

private fun stopBridge(ctx: Context) {
    Bridge.stop()
    ctx.stopService(Intent(ctx, BridgeService::class.java))
}

private fun copyText(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(ClipboardManager::class.java)
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
}

private fun savePairing(b: JSONObject) {
    Prefs.deviceToken = b.optString("device_token")
    Prefs.channelKey = b.optString("channel_key")
    Prefs.channelTopic = b.optString("channel_topic")
    Prefs.realtimeUrl = b.optString("realtime_url")
    Prefs.realtimeKey = b.optString("realtime_apikey")
    val st = b.optLong("server_time_ms", 0L)
    if (st > 0L) Prefs.skewMs = st - System.currentTimeMillis()
    Prefs.paired = true
}

private fun batteryUnrestricted(ctx: Context): Boolean =
    try {
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    } catch (e: Exception) {
        false
    }

@Composable
private fun Title(t: String) {
    Text(t, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
}

@Composable
private fun Small(t: String) {
    Text(t, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

@Composable
private fun Btn(t: String, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled) { Text(t) }
}

@Composable
private fun Toggle(label: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label)
            if (sub != null) Small(sub)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun Header(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = onBack) { Text("< Back") }
        Text(title, style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
private fun Field(label: String, value: String, secret: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
    )
}

@Composable
private fun rememberFolderPicker(role: String, onPicked: () -> Unit): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (e: Exception) {
            }
            Prefs.setTreeUri(role, uri.toString())
            onPicked()
        }
    }
    return { launcher.launch(null) }
}

// ---------------------------------------------------------------- root

@Composable
fun AppRoot() {
    var screen by remember { mutableStateOf(if (Prefs.paired && Workspace.hasWorkspace()) Screen.HOME else Screen.SETUP) }
    BackHandler(enabled = screen != Screen.HOME && screen != Screen.SETUP) { screen = Screen.HOME }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (screen) {
                Screen.HOME -> HomeScreen(go = { screen = it })
                Screen.SETUP -> SetupScreen(onDone = { screen = Screen.HOME })
                Screen.FILES -> Column(Modifier.fillMaxSize()) {
                    Header("Files") { screen = Screen.HOME }
                    Browser(Modifier.weight(1f), null)
                }
                Screen.ZIP -> ZipScreen { screen = Screen.HOME }
                Screen.BUILD -> BuildScreen { screen = Screen.HOME }
                Screen.APKS -> ApksScreen { screen = Screen.HOME }
                Screen.ACTIVITY -> ActivityScreen { screen = Screen.HOME }
                Screen.SETTINGS -> SettingsScreen(onBack = { screen = Screen.HOME }, onRepair = { screen = Screen.SETUP })
            }
        }
        ConfirmDialog()
    }
}

@Composable
private fun ConfirmDialog() {
    val p by BridgeState.pending.collectAsState()
    val cur = p ?: return
    AlertDialog(
        onDismissRequest = { Confirm.resolve(cur.id, false) },
        title = { Text(cur.title) },
        text = { Text(cur.detail) },
        confirmButton = { TextButton(onClick = { Confirm.resolve(cur.id, true) }) { Text("Allow") } },
        dismissButton = { TextButton(onClick = { Confirm.resolve(cur.id, false) }) { Text("Cancel") } }
    )
}

// ---------------------------------------------------------------- home

@Composable
private fun HomeScreen(go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val conn by BridgeState.conn.collectAsState()
    val detail by BridgeState.detail.collectAsState()
    val op by BridgeState.op.collectAsState()
    val usage by BridgeState.usage.collectAsState()
    val emergency by BridgeState.emergency.collectAsState()
    val enabled by BridgeState.claudeEnabled.collectAsState()
    val diag by BridgeState.diag.collectAsState()
    var askDisconnect by remember { mutableStateOf(false) }
    val running = conn != Conn.STOPPED && conn != Conn.UNPAIRED

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { startBridge(ctx) }

    val status = when {
        emergency -> Pair("⛔", "Emergency stop active")
        !enabled -> Pair("⏸", "Claude disabled")
        conn == Conn.CONNECTED -> Pair("🟢", "Claude Connected")
        conn == Conn.POLLING -> Pair("🟢", "Connected (polling)")
        conn == Conn.CONNECTING -> Pair("🟡", "Connecting...")
        conn == Conn.OFFLINE -> Pair("🔴", "Offline")
        conn == Conn.UNPAIRED -> Pair("⚪", "Not paired")
        else -> Pair("⚪", "Bridge stopped")
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Claude FileBridge", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text(status.first + " " + status.second, style = MaterialTheme.typography.titleMedium)
                if (detail.isNotEmpty()) Small(detail)
                Spacer(Modifier.height(8.dp))
                Text("Device ID: " + Prefs.deviceId, modifier = Modifier.clickable { copyText(ctx, "Device ID", Prefs.deviceId) })
                Text("Workspace: " + treeLabel(Prefs.treeUri("workspace")))
                val o = op
                if (o != null) {
                    Spacer(Modifier.height(8.dp))
                    Text("Working: " + o.tool + (if (o.note.isNotEmpty()) " - " + o.note else ""))
                    val pr = o.progress
                    if (pr != null) LinearProgressIndicator(progress = { pr }, modifier = Modifier.fillMaxWidth()) else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
            }
        }

        Title("Controls")
        Toggle(
            label = "Run in background",
            sub = "Keeps working while you use your phone. Stop it here or from the notification.",
            checked = running,
            onChange = { on ->
                if (!on) {
                    stopBridge(ctx)
                } else if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    startBridge(ctx)
                }
            }
        )
        Toggle(label = "Disable Claude", sub = "Claude's commands are refused until you switch this off", checked = !enabled, onChange = { Bridge.setClaudeEnabled(!it) })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { Bridge.emergencyStop() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))) { Text("Emergency Stop") }
            if (emergency) OutlinedButton(onClick = { Bridge.resume() }) { Text("Resume") }
        }
        Spacer(Modifier.height(6.dp))
        OutlinedButton(onClick = { askDisconnect = true }) { Text("Disconnect Device") }
        Small("Emergency Stop cancels ZIPs, uploads and pending operations and pauses Claude. It never deletes files.")

        Title("Quick Actions")
        val actions = listOf(
            "📁 Files" to Screen.FILES, "📦 Create ZIP" to Screen.ZIP, "🔨 Build Project" to Screen.BUILD,
            "📱 APKs" to Screen.APKS, "📊 Activity" to Screen.ACTIVITY, "⚙ Settings" to Screen.SETTINGS
        )
        for (row in actions.chunked(2)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (a in row) OutlinedButton(onClick = { go(a.second) }, modifier = Modifier.weight(1f)) { Text(a.first) }
            }
            Spacer(Modifier.height(8.dp))
        }

        Title("Resources")
        Text("Data today: up " + fmtBytes(usage.first) + " / down " + fmtBytes(usage.second))
        Small("Idle = no scanning, no indexing, no screenshots, no polling. One tiny keep-alive about every 25 s.")
        Small(if (batteryUnrestricted(ctx)) "Battery: unrestricted, so it can stay connected with the screen off." else "Battery: Android may put the app to sleep with the screen off. See Settings > Background.")

        Title("Diagnostics")
        Text(
            if (diag.isEmpty()) "No events yet." else diag.takeLast(10).joinToString("\n"),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp
        )
        OutlinedButton(onClick = { copyText(ctx, "FileBridge log", diag.joinToString("\n")) }) { Text("Copy log") }
        Small("Same lines in logcat: adb logcat -s FileBridge")
    }

    if (askDisconnect) {
        AlertDialog(
            onDismissRequest = { askDisconnect = false },
            title = { Text("Disconnect this phone?") },
            text = { Text("Claude loses access to this phone until you pair it again. No files are touched.") },
            confirmButton = {
                TextButton(onClick = {
                    askDisconnect = false
                    Bridge.disconnect { ctx.stopService(Intent(ctx, BridgeService::class.java)); go(Screen.SETUP) }
                }) { Text("Disconnect") }
            },
            dismissButton = { TextButton(onClick = { askDisconnect = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- setup

@Composable
private fun SetupScreen(onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var paired by remember { mutableStateOf(Prefs.paired) }
    var backend by remember { mutableStateOf(Prefs.backendUrl) }
    var code by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    val hasWs = remember(tick) { Workspace.hasWorkspace() }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Set up Claude FileBridge", style = MaterialTheme.typography.headlineSmall)
        Small("Device ID: " + Prefs.deviceId)

        Title("1. Pair with your backend")
        if (paired) {
            Text("✅ Paired as " + Prefs.deviceId)
        } else {
            Field("Backend URL", backend) { backend = it }
            Field("Pairing code", code) { code = it }
            Btn(if (busy) "Pairing..." else "Pair this phone", enabled = !busy && code.isNotBlank()) {
                busy = true
                msg = ""
                Prefs.backendUrl = backend
                scope.launch {
                    val r = try {
                        withContext(Dispatchers.IO) { Backend.pair(code.trim(), Build.MODEL ?: "Android") }
                    } catch (e: Exception) {
                        null
                    }
                    busy = false
                    val b = r?.body
                    if (r != null && r.code == 200 && b != null && b.optBoolean("ok")) {
                        savePairing(b)
                        paired = true
                        msg = ""
                    } else {
                        msg = when (r?.code) {
                            null, 0 -> "Cannot reach the backend. Check the URL and your connection."
                            403 -> "That code is wrong or has expired."
                            429 -> "Too many attempts. Wait 10 minutes."
                            else -> "Pairing failed (" + r?.code + ")."
                        }
                    }
                }
            }
            if (msg.isNotEmpty()) Text(msg, color = MaterialTheme.colorScheme.error)
        }

        Title("2. Claude Workspace (required)")
        val pickWs = rememberFolderPicker("workspace") { tick++ }
        Text(if (hasWs) "✅ " + treeLabel(Prefs.treeUri("workspace")) else "Pick a folder such as Download/Claude. Claude can only work inside it.")
        OutlinedButton(onClick = pickWs) { Text(if (hasWs) "Change folder" else "Select Folder") }

        Title("3. Output folders (optional)")
        Small("Skip these to use ZIP/, APK/ and BuildWorkspace/ sub-folders inside the workspace.")
        for (r in listOf("zip" to "ZIP Output", "apk" to "APK Output", "build" to "Build Workspace")) {
            FolderRow(r.first, r.second, tick) { tick++ }
        }

        Title("4. Background")
        Small("Android needs to allow notifications and, for reliability with the screen off, unrestricted battery use.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }) { Text("Allow notifications") }
            OutlinedButton(onClick = {
                try {
                    ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
            }) { Text("Battery settings") }
        }

        Spacer(Modifier.height(20.dp))
        Btn("Start FileBridge", enabled = paired && hasWs) {
            startBridge(ctx)
            onDone()
        }
        if (paired && hasWs) {
            Spacer(Modifier.height(6.dp))
            TextButton(onClick = onDone) { Text("Skip, don't start yet") }
        }
    }
}

@Composable
private fun FolderRow(role: String, label: String, tick: Int, changed: () -> Unit) {
    val pick = rememberFolderPicker(role, changed)
    val uri = remember(tick) { Prefs.treeUri(role) }
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(label)
        Small(if (uri == null) (if (role == "workspace") "Not selected" else "Not set (uses a sub-folder of the workspace)") else treeLabel(uri))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = pick) { Text(if (uri == null) "Select folder" else "Change") }
            if (uri != null && role != "workspace") {
                TextButton(onClick = {
                    Prefs.setTreeUri(role, null)
                    changed()
                }) { Text("Use sub-folder") }
            }
        }
    }
}

// ---------------------------------------------------------------- file browser (also folder picker)

@Composable
private fun Browser(modifier: Modifier, onPick: ((String) -> Unit)?) {
    var path by remember { mutableStateOf(listOf<String>()) }
    var rows by remember { mutableStateOf<List<Node>>(emptyList()) }
    var virtual by remember { mutableStateOf<List<String>>(emptyList()) }
    var error by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    var toDelete by remember { mutableStateOf<Node?>(null) }
    var newFolder by remember { mutableStateOf(false) }
    var folderName by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    LaunchedEffect(path, refresh) {
        error = ""
        try {
            val res = withContext(Dispatchers.IO) {
                val l = Workspace.loc(PathUtil.join(path))
                val n = FileOps.requireNode(l)
                l.tree.children(n).sortedWith(compareBy<Node>({ !it.isDir }, { it.name.lowercase() }))
            }
            rows = res
            virtual = if (path.isEmpty()) {
                listOf("ZIP" to "zip", "APK" to "apk", "BuildWorkspace" to "build").filter { Prefs.treeUri(it.second) != null }.map { it.first }
            } else emptyList()
        } catch (e: Exception) {
            rows = emptyList()
            error = if (e is OpError) (e.message ?: "") else "Cannot read this folder: " + e.message
        }
    }

    Column(modifier) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("/" + PathUtil.join(path), modifier = Modifier.weight(1f), fontFamily = FontFamily.Monospace, fontSize = 13.sp)
            if (path.isNotEmpty()) TextButton(onClick = { path = path.dropLast(1) }) { Text("Up") }
            TextButton(onClick = { newFolder = true; folderName = "" }) { Text("New folder") }
        }
        if (onPick != null) {
            Button(onClick = { onPick(PathUtil.join(path)) }, modifier = Modifier.padding(horizontal = 12.dp)) { Text("Use this folder") }
        }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(12.dp))
        if (note.isNotEmpty()) Small(note)
        LazyColumn(Modifier.weight(1f)) {
            items(virtual) { v ->
                Row(Modifier.fillMaxWidth().clickable { path = path + v }.padding(horizontal = 14.dp, vertical = 10.dp)) { Text("🔗 $v/") }
            }
            items(rows) { n ->
                Row(
                    Modifier.fillMaxWidth().clickable { if (n.isDir) path = path + n.name }.padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(if (n.isDir) "📁 " + n.name else n.name)
                        if (!n.isDir) Small(fmtBytes(n.size))
                    }
                    TextButton(onClick = { toDelete = n }) { Text("🗑") }
                }
                HorizontalDivider()
            }
        }
    }

    val d = toDelete
    if (d != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete " + d.name + "?") },
            text = { Text(if (d.isDir) "The folder and everything in it will be deleted." else "This file will be deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    toDelete = null
                    val target = PathUtil.join(path + d.name)
                    Ops.runLocal("delete", { ctx -> FileOps.delete(target, true, ctx) }) { txt ->
                        note = if (txt.startsWith("{")) "Deleted." else txt
                        refresh++
                    }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
    if (newFolder) {
        AlertDialog(
            onDismissRequest = { newFolder = false },
            title = { Text("New folder") },
            text = { Field("Name", folderName) { folderName = it } },
            confirmButton = {
                TextButton(onClick = {
                    newFolder = false
                    val target = PathUtil.join(path + folderName.trim())
                    if (folderName.isNotBlank()) {
                        Ops.runLocal("create_folder", { _ -> FileOps.createFolder(target) }) { txt ->
                            note = if (txt.startsWith("{")) "Folder created." else txt
                            refresh++
                        }
                    }
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { newFolder = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- ZIP

@Composable
private fun ZipScreen(onBack: () -> Unit) {
    var picked by remember { mutableStateOf<String?>(null) }
    var out by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val op by BridgeState.op.collectAsState()
    val src = picked
    Column(Modifier.fillMaxSize()) {
        Header("Create ZIP") { if (src != null) picked = null else onBack() }
        if (src == null) {
            Small("  Choose the folder to ZIP")
            Browser(Modifier.weight(1f)) {
                picked = it
                out = "ZIP/" + it.substringAfterLast('/').ifEmpty { "workspace" } + ".zip"
                result = ""
            }
        } else {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp)) {
                Text("Source: /$src", fontFamily = FontFamily.Monospace)
                Field("Output (relative path)", out) { out = it }
                Small("Streamed locally: written as .tmp, renamed when complete, never overwrites (adds ' (1)').")
                Spacer(Modifier.height(8.dp))
                Btn(if (busy) "Working..." else "Create ZIP", enabled = !busy && out.isNotBlank()) {
                    busy = true
                    result = ""
                    Ops.runLocal("create_zip", { ctx -> ZipEngine.create(src, out, emptyList(), emptyList(), false, false, ctx) }) {
                        result = it
                        busy = false
                    }
                }
                val o = op
                if (busy && o != null) {
                    val pr = o.progress
                    if (pr != null) LinearProgressIndicator(progress = { pr }, modifier = Modifier.fillMaxWidth()) else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Small(o.note)
                    OutlinedButton(onClick = { Ops.current?.cancel() }) { Text("Cancel") }
                }
                if (result.isNotEmpty()) Text(result, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        }
    }
}

// ---------------------------------------------------------------- build

@Composable
private fun BuildScreen(onBack: () -> Unit) {
    var project by remember { mutableStateOf<String?>(null) }
    val p = project
    Column(Modifier.fillMaxSize()) {
        Header("Build Project") { if (p != null) project = null else onBack() }
        if (p == null) {
            Small("  Choose the project folder")
            Browser(Modifier.weight(1f)) { project = it }
        } else {
            BuildPanel(p, Modifier.weight(1f))
        }
    }
}

@Composable
private fun BuildPanel(project: String, modifier: Modifier) {
    val name = project.substringAfterLast('/').ifEmpty { "project" }
    val zipPath = "ZIP/$name-build.zip"
    var result by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var askUpload by remember { mutableStateOf(false) }
    var optimizeGradle by remember { mutableStateOf(false) }
    val op by BridgeState.op.collectAsState()

    fun exec(label: String, block: suspend (OpCtx) -> JSONObject, pretty: Boolean = false) {
        busy = true
        result = ""
        Ops.runLocal(label, block) { txt ->
            result = if (pretty) (try {
                JSONObject(txt).optString("optimization_report").ifEmpty { txt }
            } catch (e: Exception) {
                txt
            }) else txt
            busy = false
        }
    }

    Column(modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Project: /$project", fontFamily = FontFamily.Monospace)
        Small("Prepare = filtered staging copy in BuildWorkspace (original untouched) + ZIP. Always a universal APK; ABI splits are removed in the copy.")
        Toggle(label = "Enable R8 / resource shrinking in the copy", sub = "Skipped automatically for native (NDK) projects", checked = optimizeGradle, onChange = { optimizeGradle = it })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = !busy, onClick = { exec("analyze", { ctx -> ProjectPreparer.prepare(project, zipPath, true, optimizeGradle, true, false, emptyList(), false, ctx) }, true) }) { Text("Analyze") }
            Button(enabled = !busy, onClick = { exec("prepare_project_zip", { ctx -> ProjectPreparer.prepare(project, zipPath, true, optimizeGradle, false, false, emptyList(), false, ctx) }) }) { Text("Prepare ZIP") }
        }
        Spacer(Modifier.height(8.dp))
        Button(enabled = !busy, onClick = { askUpload = true }) { Text("Upload & build (GitHub)") }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = !busy, onClick = { exec("build status", { _ -> GitHub.status("") }) }) { Text("Status") }
            OutlinedButton(enabled = !busy, onClick = { exec("build logs", { _ -> GitHub.logs("", 120, "") }) }) { Text("Logs") }
            OutlinedButton(enabled = !busy, onClick = { exec("cancel build", { _ -> GitHub.cancel("") }) }) { Text("Cancel") }
        }
        OutlinedButton(enabled = !busy, onClick = { exec("download APK", { ctx -> GitHub.download("", "APK", ctx) }) }) { Text("Download APK") }
        val o = op
        if (busy && o != null) {
            val pr = o.progress
            if (pr != null) LinearProgressIndicator(progress = { pr }, modifier = Modifier.fillMaxWidth()) else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Small(o.tool + " " + o.note)
            OutlinedButton(onClick = { Ops.current?.cancel() }) { Text("Cancel operation") }
        }
        if (result.isNotEmpty()) Text(result, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
    }

    if (askUpload) {
        AlertDialog(
            onDismissRequest = { askUpload = false },
            title = { Text("Prepare and upload?") },
            text = { Text("Stages $name, creates $zipPath, uploads it to your configured GitHub repository and starts the build.") },
            confirmButton = {
                TextButton(onClick = {
                    askUpload = false
                    exec("start_build", { ctx ->
                        val prep = ProjectPreparer.prepare(project, zipPath, true, optimizeGradle, false, false, emptyList(), true, ctx)
                        val l = Workspace.loc(prep.optString("output").ifEmpty { zipPath })
                        GitHub.start(l.tree, FileOps.requireNode(l), l.display, "", ctx)
                    })
                }) { Text("Upload") }
            },
            dismissButton = { TextButton(onClick = { askUpload = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- APKs

private fun installApk(ctx: Context, tree: Tree, n: Node, scope: CoroutineScope, onMsg: (String) -> Unit) {
    scope.launch {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
                onMsg("Allow installs from FileBridge, then tap the APK again.")
                ctx.startActivity(
                    Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return@launch
            }
            val f = withContext(Dispatchers.IO) {
                val dir = File(ctx.cacheDir, "apk")
                dir.mkdirs()
                val out = File(dir, n.name.replace('/', '_'))
                tree.openIn(n).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                out
            }
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            onMsg("")
        } catch (e: Exception) {
            onMsg("Could not open the installer: " + e.message)
        }
    }
}

@Composable
private fun ApksScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<Node>>(emptyList()) }
    var tree by remember { mutableStateOf<Tree?>(null) }
    var msg by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    var toDelete by remember { mutableStateOf<Node?>(null) }

    LaunchedEffect(refresh) {
        try {
            val res = withContext(Dispatchers.IO) {
                val l = Workspace.loc("APK")
                val dir = l.tree.ensureDir(l.segs)
                Pair(l.tree, l.tree.children(dir).filter { !it.isDir && it.name.lowercase().endsWith(".apk") }.sortedByDescending { it.modified })
            }
            tree = res.first
            list = res.second
            msg = ""
        } catch (e: Exception) {
            msg = if (e is OpError) (e.message ?: "") else "Cannot read the APK folder: " + e.message
        }
    }

    Column(Modifier.fillMaxSize()) {
        Header("APKs", onBack)
        if (msg.isNotEmpty()) Text(msg, modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.error)
        if (list.isEmpty() && msg.isEmpty()) Small("  No APKs yet. Downloaded builds appear here (APK/).")
        LazyColumn(Modifier.weight(1f)) {
            items(list) { n ->
                Row(
                    Modifier.fillMaxWidth().clickable { tree?.let { t -> installApk(ctx, t, n, scope) { msg = it } } }.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("📱 " + n.name)
                        Small(fmtBytes(n.size) + "  -  tap to install")
                    }
                    TextButton(onClick = { toDelete = n }) { Text("🗑") }
                }
                HorizontalDivider()
            }
        }
    }
    val d = toDelete
    val t = tree
    if (d != null && t != null) {
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete " + d.name + "?") },
            confirmButton = {
                TextButton(onClick = {
                    toDelete = null
                    scope.launch {
                        withContext(Dispatchers.IO) { t.delete(d) }
                        refresh++
                    }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- activity

@Composable
private fun ActivityScreen(onBack: () -> Unit) {
    val list by BridgeState.activity.collectAsState()
    val usage by BridgeState.usage.collectAsState()
    val fmt = remember { SimpleDateFormat("MMM d HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize()) {
        Header("Activity", onBack)
        Text("Data today: up " + fmtBytes(usage.first) + " / down " + fmtBytes(usage.second), modifier = Modifier.padding(horizontal = 16.dp))
        Small("  Only metadata is kept (no file contents).")
        LazyColumn(Modifier.weight(1f)) {
            items(list) { a ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text((if (a.ok) "✓ " else "✗ ") + a.tool + (if (a.remote) "  (Claude)" else "  (you)"))
                    val extra = (if (a.bytes > 0) fmtBytes(a.bytes) + "  " else "") + (a.ms / 1000).toString() + " s  " + fmt.format(Date(a.time)) + (if (a.detail.isNotEmpty()) "  " + a.detail else "")
                    Small(extra)
                }
                HorizontalDivider()
            }
        }
    }
}

// ---------------------------------------------------------------- settings

@Composable
private fun SettingsScreen(onBack: () -> Unit, onRepair: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val enabled by BridgeState.claudeEnabled.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    var perms by remember { mutableStateOf(Perm.values().associateWith { Prefs.perm(it) }) }
    var cfOver by remember { mutableStateOf(Prefs.confirmOverwrite) }
    var cfUp by remember { mutableStateOf(Prefs.confirmUpload) }
    var cfMove by remember { mutableStateOf(Prefs.confirmMove) }
    var cfStore by remember { mutableIntStateOf(Prefs.confirmLargeStorageMb) }
    var cfNet by remember { mutableIntStateOf(Prefs.confirmLargeNetworkMb) }
    var backend by remember { mutableStateOf(Prefs.backendUrl) }
    var connUrl by remember { mutableStateOf("") }
    var ghOwner by remember { mutableStateOf(Prefs.ghOwner) }
    var ghRepo by remember { mutableStateOf(Prefs.ghRepo) }
    var ghBranch by remember { mutableStateOf(Prefs.ghBranch) }
    var ghWorkflow by remember { mutableStateOf(Prefs.ghWorkflow) }
    var ghZip by remember { mutableStateOf(Prefs.ghZipPath) }
    var ghArtifact by remember { mutableStateOf(Prefs.ghArtifact) }
    var ghToken by remember { mutableStateOf("") }
    var askDisconnect by remember { mutableStateOf(false) }
    var pollOnly by remember { mutableStateOf(Prefs.pollingOnly) }

    Column(Modifier.fillMaxSize()) {
        Header("Settings", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            Title("Storage")
            Small("Change Claude Workspace here at any time. Claude can only reach inside the folders you pick.")
            for (r in listOf("workspace" to "Claude Workspace", "zip" to "ZIP Output", "apk" to "APK Output", "build" to "Build Workspace")) {
                FolderRow(r.first, r.second, tick) { tick++ }
            }

            Title("Claude Permissions")
            for (p in Perm.values()) {
                Toggle(label = p.label, checked = perms[p] == true, onChange = { v ->
                    Prefs.setPerm(p, v)
                    perms = perms + Pair(p, v)
                    Bridge.pushState()
                })
            }
            Toggle(label = "Disable Claude", sub = "Refuse every command from Claude", checked = !enabled, onChange = { Bridge.setClaudeEnabled(!it) })

            Title("Confirmations")
            Small("Deleting always asks. Everything else is up to you.")
            Toggle(label = "Confirm overwrites", checked = cfOver, onChange = { cfOver = it; Prefs.confirmOverwrite = it })
            Toggle(label = "Confirm uploads", checked = cfUp, onChange = { cfUp = it; Prefs.confirmUpload = it })
            Toggle(label = "Confirm moves", checked = cfMove, onChange = { cfMove = it; Prefs.confirmMove = it })
            OutlinedButton(onClick = {
                val o = listOf(0, 100, 500, 1000, 2000)
                cfStore = o[(o.indexOf(cfStore) + 1).mod(o.size)]
                Prefs.confirmLargeStorageMb = cfStore
            }) { Text(if (cfStore == 0) "Large storage use: never ask" else "Large storage use: ask above $cfStore MB") }
            OutlinedButton(onClick = {
                val o = listOf(0, 10, 50, 200, 1000)
                cfNet = o[(o.indexOf(cfNet) + 1).mod(o.size)]
                Prefs.confirmLargeNetworkMb = cfNet
            }) { Text(if (cfNet == 0) "Large network use: never ask" else "Large network use: ask above $cfNet MB") }

            Title("Connection")
            Toggle(
                label = "Reliable mode (polling)",
                sub = "Ignore Realtime pings and long-poll the backend instead. Uses a little more data and battery, but works even when pings are blocked.",
                checked = pollOnly,
                onChange = { pollOnly = it; Prefs.pollingOnly = it; Bridge.restartConnection() }
            )
            Field("Backend URL", backend) { backend = it; Prefs.backendUrl = it }
            Text("Device ID: " + Prefs.deviceId, modifier = Modifier.clickable { copyText(ctx, "Device ID", Prefs.deviceId) })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRepair) { Text("Re-pair") }
                OutlinedButton(onClick = { askDisconnect = true }) { Text("Disconnect Device") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(enabled = Prefs.paired, onClick = {
                scope.launch {
                    val r = try {
                        withContext(Dispatchers.IO) { Backend.rotate() }
                    } catch (e: Exception) {
                        null
                    }
                    connUrl = if (r != null && r.code == 200) (r.body?.optString("connector_url") ?: "") else "Failed (" + (r?.code ?: "no connection") + ")"
                }
            }) { Text("Create new Claude connector URL") }
            if (connUrl.isNotEmpty()) {
                Text(connUrl, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                Btn("Copy URL") { copyText(ctx, "Claude connector URL", connUrl) }
                Small("Replaces the old URL. Paste it in Claude: Settings > Connectors > Add custom connector. Treat it like a password.")
            }

            Title("Build provider (GitHub Actions)")
            Small("Uploads go from this phone straight to your repository using your token (stored encrypted here, never sent to the backend).")
            Field("Owner", ghOwner) { ghOwner = it; Prefs.ghOwner = it }
            Field("Repository", ghRepo) { ghRepo = it; Prefs.ghRepo = it }
            Field("Branch", ghBranch) { ghBranch = it; Prefs.ghBranch = it }
            Field("Workflow file (for dispatch)", ghWorkflow) { ghWorkflow = it; Prefs.ghWorkflow = it }
            Field("ZIP path in repo", ghZip) { ghZip = it; Prefs.ghZipPath = it }
            Field("Artifact name (optional)", ghArtifact) { ghArtifact = it; Prefs.ghArtifact = it }
            Field(if (Prefs.ghToken.isNullOrEmpty()) "Access token" else "Access token (saved, type to replace)", ghToken, true) { ghToken = it; Prefs.ghToken = it }

            Title("Background")
            Small("FileBridge runs as a foreground service so you can keep using your phone. Stop it from the notification or the home screen.")
            Small(if (batteryUnrestricted(ctx)) "Battery: unrestricted" else "Battery: optimised by Android. For reliability with the screen off choose 'Unrestricted' / 'No restrictions'. Some phones (for example Infinix XOS) also need Auto-start allowed and battery cleaning off for this app.")
            OutlinedButton(onClick = {
                try {
                    ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                }
            }) { Text("Battery settings") }
            Spacer(Modifier.height(32.dp))
        }
    }

    if (askDisconnect) {
        AlertDialog(
            onDismissRequest = { askDisconnect = false },
            title = { Text("Disconnect this phone?") },
            text = { Text("Claude loses access until you pair again. No files are touched.") },
            confirmButton = {
                TextButton(onClick = {
                    askDisconnect = false
                    Bridge.disconnect { ctx.stopService(Intent(ctx, BridgeService::class.java)); onRepair() }
                }) { Text("Disconnect") }
            },
            dismissButton = { TextButton(onClick = { askDisconnect = false }) { Text("Cancel") } }
        )
    }
}
