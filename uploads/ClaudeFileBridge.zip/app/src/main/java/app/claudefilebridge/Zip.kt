package app.claudefilebridge

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ZipFilter(include: List<String>, exclude: List<String>, private val exact: Set<String> = emptySet()) {
    private val inc = include.filter { it.isNotBlank() }.map { Glob(it) }
    private val exc = exclude.filter { it.isNotBlank() }.map { Glob(it) }

    fun dirExcluded(rel: String): Boolean = rel in exact || exc.any { it.matches(rel, true) }

    fun fileIncluded(rel: String): Boolean =
        rel !in exact && (inc.isEmpty() || inc.any { it.matches(rel, false) }) && exc.none { it.matches(rel, false) }
}

object ZipEngine {
    private val STORED_EXT = setOf(
        "zip", "jar", "apk", "aab", "png", "jpg", "jpeg", "webp", "gif", "heic", "mp3", "ogg", "m4a", "aac", "opus", "flac",
        "mp4", "mkv", "webm", "7z", "gz", "xz", "bz2", "zst", "woff2"
    )

    private suspend fun walk(
        t: Tree, dir: Node, rel: String, f: ZipFilter,
        onDir: suspend (String) -> Unit, onFile: suspend (Node, String) -> Unit
    ) {
        for (c in t.children(dir).sortedBy { it.name }) {
            currentCoroutineContext().ensureActive()
            val r = if (rel.isEmpty()) c.name else "$rel/${c.name}"
            if (c.isDir) {
                if (f.dirExcluded(r)) continue
                onDir(r)
                walk(t, c, r, f, onDir, onFile)
            } else if (f.fileIncluded(r)) {
                onFile(c, r)
            }
        }
    }

    suspend fun create(
        srcPath: String, outPath: String, include: List<String>, exclude: List<String>,
        overwrite: Boolean, rootFolder: Boolean, ctx: OpCtx
    ): JSONObject {
        val a = Workspace.loc(srcPath)
        val o = Workspace.loc(outPath)
        val sn = FileOps.requireNode(a)
        return createFrom(a.tree, sn, a.segs, o, include, exclude, overwrite, rootFolder, ctx, Deflater.DEFAULT_COMPRESSION, a.segs.lastOrNull() ?: "workspace")
    }

    /** Streams [sn] into a ZIP at [o]: written as NAME.zip.tmp, renamed only after success, never overwrites unless asked. */
    suspend fun createFrom(
        st: Tree, sn: Node, srcSegs: List<String>, o: Loc, include: List<String>, exclude: List<String>,
        overwrite: Boolean, rootFolder: Boolean, ctx: OpCtx, level: Int, rootName: String
    ): JSONObject {
        val t0 = System.currentTimeMillis()
        if (o.segs.isEmpty()) throw OpError("invalid_path", "Give an output path like ZIP/Name.zip")
        val outParent = o.tree.ensureDir(o.segs.dropLast(1))
        val wanted = o.segs.last()
        val existing = o.tree.child(outParent, wanted)
        var finalName = wanted
        if (existing != null) {
            if (existing.isDir) throw OpError("exists", "A folder with that name exists")
            if (overwrite) {
                if (Prefs.confirmOverwrite && !ctx.confirm("Replace existing ZIP?", "Claude wants to replace ${o.display}.")) {
                    throw OpError("declined", "The user declined the overwrite. Nothing was changed.")
                }
            } else {
                finalName = FileOps.uniqueName(o.tree, outParent, wanted)
            }
        }
        val tmpName = "$finalName.tmp"

        // never zip the archive into itself
        val exact = HashSet<String>()
        if (st.treeUri == o.tree.treeUri && o.segs.size > srcSegs.size && o.segs.subList(0, srcSegs.size) == srcSegs) {
            val relParent = o.segs.drop(srcSegs.size).dropLast(1)
            for (nm in listOf(wanted, finalName, tmpName)) exact.add((relParent + nm).joinToString("/"))
        }
        val flt = ZipFilter(include, exclude, exact)

        // 1) scan: totals for the storage check and for progress
        ctx.progress(null, "Scanning...")
        var files = 0
        var bytes = 0L
        if (sn.isDir) {
            walk(st, sn, "", flt, {}, { n, _ ->
                files++
                bytes += maxOf(n.size, 0L)
            })
        } else {
            files = 1
            bytes = maxOf(sn.size, 0L)
        }
        if (files == 0) throw OpError("empty", "Nothing to archive: no files matched.")
        Space.guard(o.tree, bytes + bytes / 20, ctx, "Creating ${o.display}")

        // 2) stream into a temporary file
        o.tree.child(outParent, tmpName)?.let { o.tree.delete(it) }
        val tmp = o.tree.createFile(outParent, tmpName)
        var written = 0L
        var count = 0
        var dirs = 0
        val prefix = if (rootFolder && sn.isDir) "$rootName/" else ""
        try {
            o.tree.openOut(tmp).use { raw ->
                ZipOutputStream(BufferedOutputStream(raw, 128 * 1024)).use { zos ->
                    zos.setLevel(level)
                    val buf = ByteArray(64 * 1024)
                    val addDir: suspend (String) -> Unit = { rel ->
                        zos.putNextEntry(ZipEntry("$prefix$rel/"))
                        zos.closeEntry()
                        dirs++
                    }
                    val addFile: suspend (Node, String) -> Unit = { n, rel ->
                        val ext = n.name.substringAfterLast('.', "").lowercase()
                        zos.setLevel(if (ext in STORED_EXT) Deflater.NO_COMPRESSION else level)
                        val e = ZipEntry(prefix + rel)
                        if (n.modified > 0) e.time = n.modified
                        zos.putNextEntry(e)
                        st.openIn(n).use { i ->
                            while (true) {
                                val r = i.read(buf)
                                if (r < 0) break
                                zos.write(buf, 0, r)
                                written += r
                                currentCoroutineContext().ensureActive()
                                ctx.progress((written.toFloat() / maxOf(bytes, 1L)).coerceIn(0f, 1f), n.name)
                            }
                        }
                        zos.closeEntry()
                        count++
                    }
                    if (sn.isDir) walk(st, sn, "", flt, addDir, addFile) else addFile(sn, sn.name)
                }
            }
        } catch (e: Throwable) {
            withContext(NonCancellable) { o.tree.delete(tmp) }
            throw if (e is CancellationException) e else if (e is OpError) e else OpError("zip_failed", "ZIP creation failed: ${e.message}. The temporary file was removed and your files are untouched.")
        }

        // 3) promote the finished archive
        if (existing != null && overwrite && !o.tree.delete(existing)) {
            o.tree.delete(tmp)
            throw OpError("storage_error", "Could not replace the existing ZIP")
        }
        val fin = o.tree.rename(tmp, finalName) ?: throw OpError("storage_error", "ZIP was written as $tmpName but renaming failed")
        val disp = if (o.display.contains('/')) o.display.substringBeforeLast('/') + "/" + fin.name else fin.name
        return jsonOf(
            "success" to true,
            "output" to disp,
            "files" to count,
            "folders" to dirs,
            "size" to fin.size,
            "uncompressed_bytes" to written,
            "renamed_to_avoid_overwrite" to (finalName != wanted),
            "verified" to verify(fin, count + dirs),
            "seconds" to (System.currentTimeMillis() - t0) / 1000
        )
    }

    /** Cheap integrity check: the central directory must be readable and complete. null = could not check. */
    private fun verify(n: Node, expected: Int): Boolean? = try {
        Prefs.appCtx.contentResolver.openFileDescriptor(n.uri, "r")?.use { pfd ->
            ZipFile("/proc/self/fd/${pfd.fd}").use { z -> z.size() >= expected }
        }
    } catch (e: Exception) {
        null
    }

    private fun cleanEntry(raw: String): String {
        val segs = raw.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
        for (s in segs) {
            if (s == ".." || s.contains('\u0000') || (s.length >= 2 && s[1] == ':' && s[0].isLetter())) {
                throw OpError("zip_path_traversal", "Blocked an unsafe ZIP entry (${raw.take(80)}). Nothing was extracted.")
            }
        }
        return segs.joinToString("/")
    }

    /** Extracts with path-traversal protection; failures roll back everything this run created. */
    suspend fun extract(zipPath: String, destPath: String, onConflict: String, ctx: OpCtx): JSONObject {
        val z = Workspace.loc(zipPath)
        val d = Workspace.loc(destPath)
        val zn = FileOps.requireNode(z)
        if (zn.isDir) throw OpError("is_directory", "That is a folder, not a ZIP file")
        Space.guard(d.tree, maxOf(zn.size, 0L) * 3, ctx, "Extracting ${z.display}")

        var firstMissing = -1
        run {
            var cur: Node? = d.tree.root()
            for ((idx, s) in d.segs.withIndex()) {
                val c = cur?.let { d.tree.child(it, s) }
                if (c == null) {
                    firstMissing = idx
                    break
                }
                cur = c
            }
        }
        val destNode = d.tree.ensureDir(d.segs)
        val createdTop: Node? = if (firstMissing >= 0) d.tree.find(d.segs.subList(0, firstMissing + 1)) else null
        val created = ArrayList<Node>()
        val dirCache = HashMap<String, Node>()
        dirCache[""] = destNode
        val nameCache = HashMap<String, HashSet<String>>()

        fun names(rel: String, n: Node): HashSet<String> =
            nameCache.getOrPut(rel) { d.tree.children(n).map { it.name }.toHashSet() }

        fun dirFor(rel: String): Node {
            dirCache[rel]?.let { return it }
            val parentRel = rel.substringBeforeLast('/', "")
            val name = rel.substringAfterLast('/')
            val parent = dirFor(parentRel)
            val node: Node
            if (name in names(parentRel, parent)) {
                val ex = d.tree.child(parent, name) ?: throw OpError("conflict", "Cannot create folder '$rel'")
                if (!ex.isDir) throw OpError("conflict", "'$rel' already exists as a file")
                node = ex
            } else {
                node = d.tree.mkdir(parent, name)
                created.add(node)
                names(parentRel, parent).add(name)
            }
            dirCache[rel] = node
            return node
        }

        var files = 0
        var skipped = 0
        var renamed = 0
        var total = 0L
        var entries = 0
        try {
            z.tree.openIn(zn).use { raw ->
                ZipInputStream(BufferedInputStream(raw, 128 * 1024)).use { zin ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val e = zin.nextEntry ?: break
                        entries++
                        if (entries > 200_000) throw OpError("zip_too_many_entries", "The ZIP has too many entries")
                        val rel = cleanEntry(e.name)
                        if (rel.isEmpty()) continue
                        if (e.isDirectory) {
                            dirFor(rel)
                            continue
                        }
                        val parentRel = rel.substringBeforeLast('/', "")
                        val name = rel.substringAfterLast('/')
                        val parent = dirFor(parentRel)
                        val taken = names(parentRel, parent)
                        var target = name
                        if (name in taken) {
                            when (onConflict) {
                                "skip" -> {
                                    skipped++
                                    continue
                                }
                                "rename" -> {
                                    target = FileOps.uniqueName(d.tree, parent, name)
                                    renamed++
                                }
                                "overwrite" -> {
                                    val ex = d.tree.child(parent, name)
                                    if (ex == null || ex.isDir || !d.tree.delete(ex)) throw OpError("conflict", "Cannot overwrite $rel")
                                }
                                else -> throw OpError("conflict", "Already exists: $rel. Nothing was extracted (use on_conflict=skip, rename or overwrite).")
                            }
                        }
                        val f = d.tree.createFile(parent, target)
                        created.add(f)
                        taken.add(target)
                        d.tree.openOut(f).use { out ->
                            while (true) {
                                val n = zin.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                total += n
                                currentCoroutineContext().ensureActive()
                                ctx.progress(null, rel)
                            }
                        }
                        files++
                        if (files % 64 == 0 && d.tree.freeBytes() < 64L * 1024 * 1024) {
                            throw OpError("insufficient_storage", "Storage is almost full. Extraction was cancelled and rolled back.")
                        }
                        if (total > 20L * 1024 * 1024 * 1024) throw OpError("zip_too_large", "Extraction would exceed 20 GB")
                    }
                }
            }
        } catch (t: Throwable) {
            withContext(NonCancellable) {
                if (onConflict != "overwrite") {
                    for (n in created.asReversed()) d.tree.delete(n)
                    createdTop?.let { d.tree.delete(it) }
                }
            }
            throw if (t is CancellationException) t else if (t is OpError) t else OpError("extract_failed", "Extraction failed and was rolled back: ${t.message}")
        }
        return jsonOf(
            "success" to true,
            "destination" to d.display,
            "files" to files,
            "skipped" to skipped,
            "renamed" to renamed,
            "bytes" to total,
            "size" to total
        )
    }
}
