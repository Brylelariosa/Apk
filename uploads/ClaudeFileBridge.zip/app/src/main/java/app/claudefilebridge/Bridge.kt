package app.claudefilebridge

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** One heavy operation at a time, whether it comes from Claude or from the user's own taps. */
object Ops {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    val lock = Mutex()

    @Volatile
    var current: Job? = null

    fun localCtx(label: String): OpCtx {
        var last = 0L
        return OpCtx(
            confirm = { _, _ -> true },
            progress = { f, note ->
                val n = System.currentTimeMillis()
                if (n - last > 250L) {
                    last = n
                    BridgeState.op.value = OpInfo(label, note, f)
                }
            }
        )
    }

    fun remoteCtx(cmd: Command): OpCtx {
        var last = 0L
        var lastRemote = 0L
        return OpCtx(
            confirm = { title, detail ->
                scope.launch { Backend.progressQuiet(cmd.id, "awaiting_confirmation", jsonOf("waiting_for" to title)) }
                BridgeState.op.value = OpInfo(cmd.tool, "Waiting for your approval", null)
                val ok = Confirm.ask(title, detail)
                scope.launch { Backend.progressQuiet(cmd.id, "running", null) }
                ok
            },
            progress = { f, note ->
                val n = System.currentTimeMillis()
                if (n - last > 250L) {
                    last = n
                    BridgeState.op.value = OpInfo(cmd.tool, note, f)
                }
                if (n - lastRemote > 4000L) {
                    lastRemote = n
                    scope.launch { Backend.progressQuiet(cmd.id, "running", jsonOf("progress" to f, "note" to note)) }
                }
            }
        )
    }

    /** Runs a user-initiated operation (screens). [done] is called on the main thread with a readable result. */
    fun runLocal(label: String, block: suspend (OpCtx) -> JSONObject, done: (String) -> Unit) {
        val job = scope.launch {
            val t0 = System.currentTimeMillis()
            var text = ""
            var ok = false
            try {
                text = lock.withLock {
                    BridgeState.op.value = OpInfo(label, "", null)
                    block(localCtx(label)).toString(2)
                }
                ok = true
            } catch (e: CancellationException) {
                text = "Cancelled."
            } catch (e: OpError) {
                text = e.code + ": " + e.message
            } catch (e: Exception) {
                text = "Error: " + e.message
            } finally {
                BridgeState.op.value = null
            }
            ActivityLog.add(Act(System.currentTimeMillis(), label, ok, if (ok) "ok" else "failed", 0L, System.currentTimeMillis() - t0, if (ok) "" else text.take(80), false))
            withContext(NonCancellable + Dispatchers.Main) { done(text) }
        }
        current = job
    }
}

/** Asks the user (dialog in the app + notification actions). No answer within the timeout = No. */
object Confirm {
    suspend fun ask(title: String, detail: String, timeoutMs: Long = 120_000L): Boolean {
        val d = CompletableDeferred<Boolean>()
        val p = Pending(UUID.randomUUID().toString(), title, detail, d)
        BridgeState.pending.value = p
        Notifier.confirm(p)
        try {
            return withTimeoutOrNull(timeoutMs) { d.await() } ?: false
        } finally {
            if (BridgeState.pending.value?.id == p.id) BridgeState.pending.value = null
            Notifier.clearConfirm()
        }
    }

    fun resolve(id: String, allow: Boolean) {
        val p = BridgeState.pending.value
        if (p != null && p.id == id) p.deferred.complete(allow)
    }

    fun denyAll() {
        BridgeState.pending.value?.deferred?.complete(false)
    }
}

/** Maps the narrow MCP tool set to local operations. There is deliberately no shell / exec tool. */
object Executor {
    private fun need(p: Perm) {
        if (!Prefs.perm(p)) {
            throw OpError("permission_denied", "'${p.label}' is turned off on the phone. Ask the user to enable it in Claude Permissions.", jsonOf("permission" to p.key))
        }
    }

    private fun strList(a: JSONObject, k: String): List<String> {
        val arr = a.optJSONArray(k) ?: return emptyList()
        val out = ArrayList<String>()
        for (i in 0 until minOf(arr.length(), 50)) out.add(arr.optString(i))
        return out
    }

    suspend fun run(cmd: Command, ctx: OpCtx): JSONObject {
        val a = cmd.args
        return when (cmd.tool) {
            "list_files" -> {
                need(Perm.READ)
                FileOps.list(a.optString("path"), a.optBoolean("recursive"), a.optInt("limit", 100).coerceIn(1, 500), a.optString("cursor"))
            }
            "read_file" -> {
                need(Perm.READ)
                FileOps.read(a.optString("path"), a.optInt("start_line", 1).coerceAtLeast(1), a.optInt("max_lines", 200).coerceIn(1, 2000))
            }
            "get_file_info" -> {
                need(Perm.READ)
                FileOps.info(a.optString("path"))
            }
            "write_file" -> {
                need(Perm.CREATE)
                val ow = a.optBoolean("overwrite")
                if (ow) need(Perm.MODIFY)
                FileOps.write(a.optString("path"), a.optString("content"), ow, a.optBoolean("create_parents", true), ctx)
            }
            "create_folder" -> {
                need(Perm.CREATE_FOLDERS)
                FileOps.createFolder(a.optString("path"))
            }
            "copy_file" -> {
                need(Perm.CREATE)
                val ow = a.optBoolean("overwrite")
                if (ow) need(Perm.MODIFY)
                FileOps.copy(a.optString("source"), a.optString("destination"), ow, ctx)
            }
            "move_file" -> {
                need(Perm.MOVE)
                val ow = a.optBoolean("overwrite")
                if (ow) need(Perm.MODIFY)
                FileOps.move(a.optString("source"), a.optString("destination"), ow, ctx)
            }
            "delete_file" -> {
                need(Perm.DELETE)
                FileOps.delete(a.optString("path"), a.optBoolean("recursive"), ctx)
            }
            "create_zip" -> {
                need(Perm.CREATE_ZIP)
                val ow = a.optBoolean("overwrite")
                if (ow) need(Perm.MODIFY)
                ZipEngine.create(a.optString("source"), a.optString("output"), strList(a, "include_patterns"), strList(a, "exclude_patterns"), ow, a.optBoolean("include_root_folder"), ctx)
            }
            "extract_zip" -> {
                need(Perm.EXTRACT_ZIP)
                val oc = a.optString("on_conflict", "fail")
                if (oc == "overwrite") need(Perm.MODIFY)
                ZipEngine.extract(a.optString("zip"), a.optString("destination"), oc, ctx)
            }
            "prepare_project_zip" -> {
                need(Perm.CREATE_ZIP)
                val ow = a.optBoolean("overwrite")
                if (ow) need(Perm.MODIFY)
                ProjectPreparer.prepare(
                    a.optString("project"), a.optString("output"), a.optBoolean("optimize", true), a.optBoolean("optimize_gradle"),
                    a.optBoolean("dry_run"), a.optBoolean("keep_staging"), strList(a, "exclude_patterns"), ow, ctx
                )
            }
            "start_build" -> {
                need(Perm.UPLOAD)
                if (a.optString("provider", "github_actions") != "github_actions") throw OpError("unsupported_provider", "Only github_actions is available")
                var zipPath = a.optString("zip")
                if (zipPath.isEmpty()) {
                    need(Perm.CREATE_ZIP)
                    val proj = a.optString("project")
                    if (proj.isEmpty()) throw OpError("invalid_argument", "Provide zip or project")
                    val name = proj.trimEnd('/').substringAfterLast('/')
                    zipPath = ProjectPreparer.prepare(proj, "ZIP/$name-build.zip", true, false, false, false, emptyList(), false, ctx).optString("output")
                }
                val l = Workspace.loc(zipPath)
                val node = FileOps.requireNode(l)
                if (node.isDir) throw OpError("is_directory", "That is a folder, not a ZIP")
                GitHub.start(l.tree, node, l.display, a.optString("note"), ctx)
            }
            "get_build_status" -> {
                need(Perm.READ)
                GitHub.status(a.optString("build_id"))
            }
            "get_build_logs" -> {
                need(Perm.READ)
                GitHub.logs(a.optString("build_id"), a.optInt("tail_lines", 200).coerceIn(1, 2000), a.optString("job"))
            }
            "cancel_build" -> {
                need(Perm.UPLOAD)
                GitHub.cancel(a.optString("build_id"))
            }
            "download_build" -> {
                need(Perm.CREATE)
                GitHub.download(a.optString("build_id"), a.optString("output").ifEmpty { "APK" }, ctx)
            }
            else -> throw OpError("unknown_tool", "Unknown tool: ${cmd.tool}")
        }
    }
}

/**
 * Connection manager: one idle Realtime socket (tiny signed wake pings), commands fetched over authenticated HTTPS,
 * executed one at a time. Reconnects with exponential backoff and never replays stale commands.
 */
object Bridge {
    private var scope: CoroutineScope? = null
    private val wakeCh = Channel<Unit>(Channel.CONFLATED)
    private val netCh = Channel<Unit>(Channel.CONFLATED)
    private val execQ = Channel<JSONObject>(10)
    private val active: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val running = ConcurrentHashMap<String, Job>()
    private val cancelled: MutableSet<String> = ConcurrentHashMap.newKeySet()

    @Volatile
    private var netUp = true

    @Volatile
    private var polling = false
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private val rt = Realtime { onWake(it) }

    fun stateJson(): JSONObject = jsonOf(
        "permissions" to Prefs.permsJson(),
        "claude_enabled" to Prefs.claudeEnabled,
        "emergency_stop" to Prefs.emergency,
        "workspace" to treeLabel(Prefs.treeUri("workspace")),
        "app" to BuildConfig.VERSION_NAME
    )

    fun pushState() {
        if (!Prefs.paired) return
        Ops.scope.launch {
            try {
                Backend.state()
            } catch (e: Exception) {
            }
        }
    }

    @Synchronized
    fun start(ctx: Context) {
        if (scope != null) return
        Prefs.bridgeOn = true
        if (!Prefs.paired) {
            BridgeState.conn.value = Conn.UNPAIRED
            return
        }
        val s = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope = s
        polling = false
        BridgeState.emergency.value = Prefs.emergency
        BridgeState.claudeEnabled.value = Prefs.claudeEnabled
        registerNet(ctx)
        s.launch { for (u in wakeCh) pullAll() }
        s.launch { for (j in execQ) execute(j) }
        s.launch { connectLoop() }
    }

    @Synchronized
    fun stop() {
        Prefs.bridgeOn = false
        for (jb in running.values) jb.cancel()
        scope?.cancel()
        scope = null
        Confirm.denyAll()
        unregisterNet()
        while (execQ.tryReceive().isSuccess) { }
        active.clear()
        running.clear()
        cancelled.clear()
        BridgeState.conn.value = Conn.STOPPED
        BridgeState.detail.value = ""
        BridgeState.op.value = null
    }

    /** Cancels everything running or waiting and pauses remote execution. Deletes nothing. */
    fun emergencyStop() {
        Prefs.emergency = true
        BridgeState.emergency.value = true
        Confirm.denyAll()
        for (jb in running.values) jb.cancel()
        Ops.current?.cancel()
        while (execQ.tryReceive().isSuccess) { }
        pushState()
    }

    fun resume() {
        Prefs.emergency = false
        BridgeState.emergency.value = false
        pushState()
    }

    fun setClaudeEnabled(v: Boolean) {
        Prefs.claudeEnabled = v
        BridgeState.claudeEnabled.value = v
        pushState()
    }

    fun disconnect(done: () -> Unit) {
        Ops.scope.launch {
            try {
                Backend.unpair()
            } catch (e: Exception) {
            }
            stop()
            Prefs.clearPairing()
            BridgeState.conn.value = Conn.UNPAIRED
            withContext(Dispatchers.Main) { done() }
        }
    }

    // ---------------- network awareness ----------------
    private fun registerNet(ctx: Context) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        netUp = cm.activeNetwork != null
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                netUp = true
                netCh.trySend(Unit)
            }

            override fun onLost(network: Network) {
                netUp = cm.activeNetwork != null
            }
        }
        netCb = cb
        try {
            cm.registerDefaultNetworkCallback(cb)
        } catch (e: Exception) {
        }
    }

    private fun unregisterNet() {
        val cb = netCb ?: return
        try {
            Prefs.appCtx.getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb)
        } catch (e: Exception) {
        }
        netCb = null
    }

    // ---------------- connection loop ----------------
    private suspend fun backoff(attempt: Int) {
        val base = minOf(300_000L, 2_000L shl minOf(attempt, 8))
        val wait = (base * (0.8 + Math.random() * 0.4)).toLong()
        BridgeState.detail.value = "Retrying in ${wait / 1000}s"
        delay(wait)
    }

    private fun unpairLocal(msg: String) {
        Prefs.clearPairing()
        Prefs.bridgeOn = false
        BridgeState.detail.value = msg
        BridgeState.conn.value = Conn.UNPAIRED
    }

    private suspend fun connectLoop() {
        var attempt = 0
        while (currentCoroutineContext().isActive) {
            if (!netUp) {
                BridgeState.conn.value = Conn.OFFLINE
                BridgeState.detail.value = "Waiting for network"
                withTimeoutOrNull(60_000L) { netCh.receive() }
                continue
            }
            BridgeState.conn.value = Conn.CONNECTING
            BridgeState.detail.value = ""
            val hello = try {
                Backend.hello(active.toList())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (hello == null || hello.code >= 500) {
                backoff(attempt++)
                continue
            }
            if (hello.code == 401) {
                unpairLocal("This phone was disconnected from the backend. Pair it again.")
                return
            }
            if (hello.code != 200) {
                backoff(attempt++)
                continue
            }
            val st = hello.body?.optLong("server_time_ms", 0L) ?: 0L
            if (st > 0L) Prefs.skewMs = st - System.currentTimeMillis()
            if (polling) {
                BridgeState.conn.value = Conn.POLLING
                BridgeState.detail.value = "Polling mode"
                attempt = 0
                pollLoop()
                continue
            }
            var joined = false
            val end = rt.run(Prefs.realtimeUrl, Prefs.realtimeKey, Prefs.channelTopic) {
                joined = true
                attempt = 0
                BridgeState.conn.value = Conn.CONNECTED
                BridgeState.detail.value = "Idle"
                wakeCh.trySend(Unit)
            }
            if (end is Realtime.End.Rejected) {
                polling = true
                BridgeState.detail.value = "Realtime unavailable; using polling"
            }
            if (BridgeState.conn.value == Conn.CONNECTED) BridgeState.conn.value = Conn.CONNECTING
            if (joined) delay(1500L) else backoff(attempt++)
        }
    }

    /** Fallback when Realtime is unavailable: long-poll the relay (one request per ~25 s). */
    private suspend fun pollLoop() {
        var fails = 0
        while (currentCoroutineContext().isActive && netUp) {
            val r = try {
                Backend.poll(25)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (r == null || r.code != 200) {
                fails++
                if (fails >= 3) return
                delay(5000L)
                continue
            }
            fails = 0
            accept(r.body)
        }
    }

    // ---------------- receiving commands ----------------
    private fun onWake(p: JSONObject) {
        val key = Prefs.channelKey ?: return
        val did = p.optString("did")
        val cid = p.optString("cid")
        val ts = p.optLong("ts")
        val exp = p.optLong("exp")
        if (did != Prefs.deviceId) return
        if (!Crypto.eq(Crypto.hmacHex(key, "$did.$cid.$ts.$exp"), p.optString("sig"))) return
        val now = (System.currentTimeMillis() + Prefs.skewMs) / 1000L
        if (now > exp + 5L || Math.abs(now - ts) > 300L) return
        wakeCh.trySend(Unit)
    }

    private suspend fun pullAll() {
        while (true) {
            val r = try {
                Backend.poll(0)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                return
            }
            if (r.code != 200) return
            if (!accept(r.body)) return
        }
    }

    private fun accept(b: JSONObject?): Boolean {
        if (b == null) return false
        val canc = b.optJSONArray("cancel")
        if (canc != null) {
            for (i in 0 until canc.length()) {
                val id = canc.optString(i)
                cancelled.add(id)
                running[id]?.cancel()
            }
        }
        val cmds = b.optJSONArray("commands") ?: return false
        var any = false
        for (i in 0 until cmds.length()) {
            val j = cmds.getJSONObject(i)
            val id = j.optString("id")
            active.add(id)
            if (execQ.trySend(j).isSuccess) {
                any = true
            } else {
                active.remove(id)
                Ops.scope.launch { reportResult(id, false, "rejected", null, "The phone's queue is full", "busy", 0L, 0L) }
            }
        }
        return any
    }

    /** Signature, expiry, freshness and replay checks. Returns an error code or null when the command is trusted. */
    private fun verify(j: JSONObject): String? {
        val key = Prefs.channelKey ?: return "no_key"
        val id = j.optString("id")
        val tool = j.optString("tool")
        val nonce = j.optString("nonce")
        val iat = j.optLong("iat")
        val exp = j.optLong("exp")
        val destructive = j.optBoolean("destructive")
        val argsJson = j.optString("args_json")
        if (j.optString("device_id") != Prefs.deviceId) return "wrong_device"
        val sig = Crypto.hmacHex(key, "$id|${Prefs.deviceId}|$tool|$nonce|$iat|$exp|${if (destructive) 1 else 0}|$argsJson")
        if (!Crypto.eq(sig, j.optString("sig"))) return "bad_signature"
        val now = (System.currentTimeMillis() + Prefs.skewMs) / 1000L
        if (now > exp + 5L) return "expired"
        if (destructive && now - iat > 90L) return "stale_destructive"
        if (Prefs.seen(id)) return "replay"
        return null
    }

    private suspend fun execute(j: JSONObject) {
        val id = j.optString("id")
        try {
            val bad = verify(j)
            if (bad != null) {
                reportResult(id, false, "rejected", null, "Command refused by the phone: $bad", bad, 0L, 0L)
                return
            }
            Prefs.markSeen(id)
            if (cancelled.remove(id)) {
                reportResult(id, false, "cancelled", null, "Cancelled before it started", "cancelled", 0L, 0L)
                return
            }
            if (Prefs.emergency) {
                reportResult(id, false, "rejected", null, "Emergency stop is active on the phone", "emergency_stop", 0L, 0L)
                return
            }
            if (!Prefs.claudeEnabled) {
                reportResult(id, false, "rejected", null, "Claude is disabled on the phone", "claude_disabled", 0L, 0L)
                return
            }
            val cmd = Command(id, j.getString("tool"), JSONObject(j.getString("args_json")), j.optBoolean("destructive"), j.optString("nonce"), j.optLong("iat"), j.optLong("exp"))
            coroutineScope {
                val job = launch { runCommand(cmd) }
                running[id] = job
                job.join()
            }
            running.remove(id)
        } finally {
            active.remove(id)
        }
    }

    private suspend fun runCommand(cmd: Command) {
        val t0 = System.currentTimeMillis()
        var ok = false
        var status: String? = null
        var result: JSONObject? = null
        var err: String? = null
        var code: String? = null
        try {
            val ctx = Ops.remoteCtx(cmd)
            result = Ops.lock.withLock {
                BridgeState.op.value = OpInfo(cmd.tool, "", null)
                Executor.run(cmd, ctx)
            }
            ok = true
        } catch (e: CancellationException) {
            status = "cancelled"
            err = "The operation was cancelled on the phone. Nothing was deleted."
            code = "cancelled"
        } catch (e: OpError) {
            err = e.message
            code = e.code
            result = e.extra
            if (e.code == "declined" || e.code == "permission_denied") status = "rejected"
        } catch (e: Exception) {
            err = e.message ?: "failed"
            code = "internal"
        } finally {
            BridgeState.op.value = null
        }
        val ms = System.currentTimeMillis() - t0
        val bytes = result?.optLong("size", 0L) ?: 0L
        ActivityLog.add(Act(System.currentTimeMillis(), cmd.tool, ok, status ?: (if (ok) "ok" else "failed"), bytes, ms, code ?: "", true))
        withContext(NonCancellable) { reportResult(cmd.id, ok, status, result, err, code, bytes, ms) }
    }

    private suspend fun reportResult(id: String, ok: Boolean, status: String?, result: JSONObject?, err: String?, code: String?, bytes: Long, ms: Long) {
        var tries = 0
        while (tries < 4) {
            try {
                val r = Backend.result(id, ok, status, result, err, code, bytes, ms)
                if (r.code in 200..299 || r.code == 400 || r.code == 401) return
            } catch (e: Exception) {
            }
            tries++
            delay(1500L * tries)
        }
    }
}
