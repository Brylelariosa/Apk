package app.claudefilebridge

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object Net {
    /** Shared client; counts (approximate) bytes for the "data usage today" display. HTTPS only. */
    val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(120, TimeUnit.SECONDS)
            .addInterceptor(Interceptor { chain ->
                val r = chain.request()
                Usage.up((r.body?.contentLength() ?: 0L).coerceAtLeast(0L) + 300L)
                val resp = chain.proceed(r)
                Usage.down((resp.body?.contentLength() ?: 0L).coerceAtLeast(0L) + 300L)
                resp
            })
            .build()
    }

    val wsHttp: OkHttpClient by lazy { http.newBuilder().readTimeout(0, TimeUnit.MILLISECONDS).build() }
}

suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    cont.invokeOnCancellation { cancel() }
    enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (!cont.isCancelled) cont.resumeWithException(e)
        }

        override fun onResponse(call: Call, response: Response) {
            if (cont.isCancelled) response.close() else cont.resume(response)
        }
    })
}

object Crypto {
    fun hmacHex(key: String, msg: String): String {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return m.doFinal(msg.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    fun eq(a: String, b: String): Boolean = MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))
}

class ApiResult(val code: Int, val body: JSONObject?)

/** The phone's side of the secure relay. Every call carries the per-device bearer token over HTTPS. */
object Backend {
    private val JSON = "application/json".toMediaType()

    private suspend fun post(path: String, body: JSONObject, auth: Boolean = true, timeoutSec: Long = 30L): ApiResult {
        val url = Prefs.backendUrl.trimEnd('/') + path
        val b = Request.Builder().url(url).post(body.toString().toRequestBody(JSON))
        if (auth) b.header("Authorization", "Bearer " + (Prefs.deviceToken ?: ""))
        val client = if (timeoutSec > 30L) Net.http.newBuilder().readTimeout(timeoutSec, TimeUnit.SECONDS).build() else Net.http
        return client.newCall(b.build()).await().use { r ->
            val txt = r.body?.string() ?: ""
            val j = try {
                JSONObject(txt)
            } catch (e: Exception) {
                null
            }
            ApiResult(r.code, j)
        }
    }

    suspend fun pair(code: String, name: String): ApiResult = post(
        "/device/pair",
        jsonOf("pairing_code" to code, "device_id" to Prefs.deviceId, "name" to name, "app_version" to BuildConfig.VERSION_NAME),
        auth = false
    )

    suspend fun hello(inflight: List<String>): ApiResult = post(
        "/device/hello",
        jsonOf("inflight" to JSONArray(inflight), "app_version" to BuildConfig.VERSION_NAME, "state" to Bridge.stateJson())
    )

    suspend fun poll(wait: Int): ApiResult = post("/device/poll?wait=$wait", JSONObject(), timeoutSec = (wait + 15).toLong())

    suspend fun progressQuiet(id: String, status: String, progress: JSONObject?) {
        try {
            post("/device/progress", jsonOf("command_id" to id, "status" to status, "progress" to progress))
        } catch (e: Exception) {
        }
    }

    suspend fun result(id: String, ok: Boolean, status: String?, result: JSONObject?, error: String?, code: String?, bytes: Long, ms: Long): ApiResult =
        post(
            "/device/result",
            jsonOf("command_id" to id, "ok" to ok, "status" to status, "result" to result, "error" to error, "error_code" to code, "bytes" to bytes, "duration_ms" to ms)
        )

    suspend fun state(): ApiResult = post("/device/state", jsonOf("state" to Bridge.stateJson()))
    suspend fun unpair(): ApiResult = post("/device/unpair", JSONObject())
    suspend fun selftest(): ApiResult = post("/device/selftest", JSONObject())

    // connected AIs
    suspend fun clientsList(): ApiResult = post("/device/clients/list", JSONObject())
    suspend fun clientsCreate(name: String, scopes: List<String>): ApiResult = post("/device/clients/create", jsonOf("name" to name, "scopes" to JSONArray(scopes)))
    suspend fun clientsRevoke(id: String): ApiResult = post("/device/clients/revoke", jsonOf("id" to id))

    // shared memory (manager view for the phone's owner)
    suspend fun memoryList(query: String, project: String, archived: Boolean): ApiResult =
        post("/device/memory/list", jsonOf("query" to query, "project" to project, "include_archived" to archived))

    suspend fun memoryGet(id: String): ApiResult = post("/device/memory/get", jsonOf("id" to id))
    suspend fun memoryUpdate(id: String, pinned: Boolean?, archived: Boolean?, status: String?): ApiResult =
        post("/device/memory/update", jsonOf("id" to id, "pinned" to pinned, "archived" to archived, "status" to status))

    suspend fun memoryDelete(id: String): ApiResult = post("/device/memory/delete", jsonOf("id" to id))
    suspend fun memoryExport(): ApiResult = post("/device/memory/export", JSONObject())
    suspend fun rotate(): ApiResult = post("/device/connector/rotate", JSONObject())
}

/**
 * Minimal Phoenix client for Supabase Realtime. The channel only carries tiny signed "wake" pings;
 * commands themselves are fetched over authenticated HTTPS.
 */
class Realtime(private val onWake: (JSONObject) -> Unit) {
    sealed class End {
        object Closed : End()
        object Rejected : End()
        class Failed(val msg: String) : End()
    }

    @Volatile
    private var current: WebSocket? = null
    private val hbRef = AtomicLong(100L)

    /** Drops the current socket; the connect loop then reconnects or switches mode. */
    fun close() {
        try {
            current?.cancel()
        } catch (e: Exception) {
        }
    }

    private fun send(w: WebSocket, topic: String, event: String, payload: JSONObject, ref: String?) {
        val o = JSONObject().put("topic", topic).put("event", event).put("payload", payload).put("ref", ref ?: JSONObject.NULL)
        if (event == "phx_join") o.put("join_ref", ref)
        val s = o.toString()
        Usage.up(s.length.toLong())
        w.send(s)
    }

    /** Connects, joins and suspends until the socket ends. [onJoined] fires once the channel join is accepted. */
    suspend fun run(url: String, apikey: String, topic: String, onJoined: () -> Unit): End = coroutineScope {
        val done = CompletableDeferred<End>()
        val rtTopic = "realtime:$topic"
        val lastRx = AtomicLong(System.currentTimeMillis())
        val req = Request.Builder().url("$url?apikey=$apikey&vsn=1.0.0").build()
        val socket = Net.wsHttp.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Dbg.log("realtime: socket open, joining channel")
                val cfg = JSONObject()
                    .put("broadcast", JSONObject().put("ack", false).put("self", false))
                    .put("presence", JSONObject().put("key", ""))
                    .put("postgres_changes", JSONArray())
                    .put("private", false)
                send(webSocket, rtTopic, "phx_join", JSONObject().put("config", cfg).put("access_token", apikey), "1")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                lastRx.set(System.currentTimeMillis())
                Usage.down(text.length.toLong())
                try {
                    val m = JSONObject(text)
                    when (m.optString("event")) {
                        "phx_reply" -> {
                            if (m.optString("ref") == "1") {
                                if (m.optJSONObject("payload")?.optString("status") == "ok") {
                                    Dbg.log("realtime: joined channel")
                                    onJoined()
                                } else {
                                    Dbg.log("realtime: join rejected: " + text.take(200), true)
                                    done.complete(End.Rejected)
                                }
                            }
                        }
                        "broadcast" -> {
                            val p = m.optJSONObject("payload")
                            if (p?.optString("event") == "wake") p.optJSONObject("payload")?.let { onWake(it) }
                        }
                        "phx_error", "phx_close" -> {
                            Dbg.log("realtime: channel " + m.optString("event"), true)
                            done.complete(End.Closed)
                        }
                    }
                } catch (e: Exception) {
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                Dbg.log("realtime: server is closing the socket ($code $reason)", true)
                webSocket.close(1000, null)
                done.complete(End.Closed)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Dbg.log("realtime: socket closed ($code)")
                done.complete(End.Closed)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val http = if (response != null) " (HTTP " + response.code + ")" else ""
                Dbg.log("realtime: socket failed: " + t.javaClass.simpleName + " " + (t.message ?: "") + http, true)
                done.complete(End.Failed(t.message ?: "network error"))
            }
        })
        current = socket
        val hb = launch {
            while (isActive) {
                delay(15_000L)
                val sentAt = System.currentTimeMillis()
                send(socket, "phoenix", "heartbeat", JSONObject(), hbRef.incrementAndGet().toString())
                delay(10_000L)
                if (lastRx.get() < sentAt) {
                    Dbg.log("realtime: heartbeat timeout", true)
                    done.complete(End.Failed("heartbeat timeout"))
                    break
                }
            }
        }
        try {
            done.await()
        } finally {
            hb.cancel()
            socket.cancel()
            if (current === socket) current = null
        }
    }
}
