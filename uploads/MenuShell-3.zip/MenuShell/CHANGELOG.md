# Changelog

## Pass 4 — pocket size + table polish fix
- Pockets were sized way off a real table: corner/side radius fractions
  were roughly double what they should be (~23%/19% of table width in
  diameter, vs. a regulation table's ~11.5%/10% for 5"/4.5" pocket mouths
  on a 44" bed) — halved both
- Pocket gradient's rim tone was a near-black gray barely distinguishable
  from the black core, so the "hole" read as a flat disc; swapped it for
  the rail's lighter brown and pushed the gradient into the outer ~28% of
  the radius so the rim actually shows
- Felt is now a soft radial gradient (lighter center, darker edge) instead
  of a flat fill
- Dropped the now-unused `billiards_pocket_rim` color — the pocket rim
  reuses `billiards_rail_light` instead

## Pass 3 — billiards table screen
- `Play` now opens a new `GameActivity` instead of showing a placeholder
  Toast; `Settings` is unchanged for now
- Added a `billiards` package: `TableGeometry` builds the standard 6-pocket
  layout (4 corner + 2 side, sized off the felt rect) with 6 cushion
  segments that stop short of each pocket mouth. `Cushion.reflect()` and
  `Pocket.captures()` are real collision/sink checks — just not called by
  anything yet, since there's no ball or cue in this pass
- `BilliardsTableView` draws the table (wood rail, felt, cushions, rail
  diamonds, pockets) fit to a 2:1 aspect ratio, centered, at whatever size
  it's given; gradients and stroke widths are rebuilt only on size change,
  not per frame
- Menu: title and Play/Settings are now horizontally centered instead of
  pinned to a left-side guideline

## Pass 2 — release build fix + APK size pass
- Fixed release build failure: `activity_main.xml` declared the `app`
  namespace as `res/app` instead of `res-auto`, so aapt2 couldn't
  resolve any `app:layout_constraint*`/MaterialButton attribute and
  failed resource linking for every one of them
- Release build now runs R8 (`isMinifyEnabled = true`, full mode by
  default under AGP 8.4.2) with `isShrinkResources = true`; no new
  keep rules needed — nothing reflection-based in the dependency graph
- Release build now restricts bundled locales to English
  (`resConfigs("en")`), dropping the other-language string tables
  AppCompat/Material ship for their own widgets — language resources
  only, no ABI split

## Pass 1 — initial menu shell
- Landscape/reverse-landscape only (`sensorLandscape`), no portrait
- Immersive fullscreen, system bars hidden, cutout excluded from layout
  (`LAYOUT_IN_DISPLAY_CUTOUT_MODE_NEVER`) so nothing sits behind the camera
- Black background throughout, matching the cutout exclusion so the
  excluded area reads as an intentional margin, not a gap
- `ImmersiveActivity` base class holding the window/orientation setup,
  so future screens reuse it instead of duplicating window flags
- Main menu: title + Play/Settings, both currently placeholder actions
