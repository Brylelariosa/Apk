package com.screenshottile

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class ScreenshotTileService : TileService() {

    // Cached on first use; PendingIntent is immutable so safe to reuse
    private var triggerPendingIntent: PendingIntent? = null

    override fun onStartListening() {
        super.onStartListening()
        val newState = if (ScreenshotAccessibilityService.instance != null)
            Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        qsTile?.apply {
            if (state != newState) {   // skip redundant Binder IPC
                state = newState
                updateTile()
            }
        }
    }

    override fun onClick() {
        super.onClick()
        if (ScreenshotAccessibilityService.instance == null) {
            launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } else {
            launch(Intent(this, TriggerActivity::class.java))
        }
    }

    private fun launch(intent: Intent) {
        intent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or
            Intent.FLAG_ACTIVITY_CLEAR_TASK or
            Intent.FLAG_ACTIVITY_NO_ANIMATION or
            Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            // Reuse cached PendingIntent for TriggerActivity; always recreate for Settings
            val pi = if (intent.component?.className == TriggerActivity::class.java.name) {
                triggerPendingIntent ?: PendingIntent.getActivity(
                    this, 0, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                ).also { triggerPendingIntent = it }
            } else {
                PendingIntent.getActivity(
                    this, 1, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
            }
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}
