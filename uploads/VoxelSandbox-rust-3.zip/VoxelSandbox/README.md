# Voxel Sandbox — Rust edition

A from-scratch Rust rewrite of the Kotlin/OpenGL ES voxel sandbox (v15). The game is one native library
(`libvoxelsandbox.so`) running inside Android's `NativeActivity`; there is no Java or Kotlin code. Gradle only
wraps the library into an APK.

See [`docs/RUST-PORT.md`](docs/RUST-PORT.md) for the architecture, what is ported and what is not yet.

## What is new in 0.3.0

* **Real full-screen.** The navigation bar and the status bar are hidden (immersive mode). Swiping in from the
  edge shows them for a moment and they hide again by themselves. The game draws behind the camera cut-out.
* **Render distance up to 1000 chunks** (16,000 blocks). Settings → Graphics has a slider, `-` / `+` buttons that
  repeat while you hold them (and speed up), and a **MAX** button. Only the *detail distance* (4–24 chunks, default 10)
  is built from real blocks; everything beyond it is **far terrain**: the same world drawn as big blocky
  columns in 6 coarser levels, so it still looks like a voxel game and costs very little.
* **Optimisations**, all of them switchable or automatic:
  * greedy meshing (chunks away from the player are built from merged quads: about a quarter fewer triangles),
  * frustum culling (chunks and 16-block sections outside the view are not drawn),
  * occlusion culling (sections that are shut off by rock, such as caves, are not drawn; about 13 % fewer triangles),
  * far-terrain LOD (see above), time-sliced mesh uploads, a render-resolution setting.
* **A debug log in the Download folder** that says what the game was doing every second (below).

## The debug log (send me this when the game lags)

Settings → Debug → *DEBUG LOG FILE* (on by default). The file is `VoxelSandbox-log_<date>_<time>.txt`, for example
`VoxelSandbox-log_2026-11-09_1.20pm.txt`.

* **Where:** the phone's **Download** folder (Android 10 and newer: created through MediaStore, no permission needed).
  On Android 7–9 it is written to Download only if you allow *Storage* for the app in the system settings; otherwise it
  goes to `Android/data/com.voxelsandbox.game/files/`. The Settings → Debug screen always shows where the file is.
* **Format:** one line every second, starting with the phone's clock in 12-hour style (`1:20:05pm`), then fps, the
  milliseconds the game thread spent in *input / update (calculation) / render (drawing work) / swap-wait (waiting for the
  GPU)*, CPU use, world and queue sizes, GPU uploads, draw calls and triangles, and at the end the verdict:
  `=> smooth`, `=> LAG: CALCULATION`, `=> LAG: RENDERING (CPU side)`, `=> LAG: GPU/DISPLAY` or `=> LAG: CPU STARVED`,
  with the part that cost the most. Single slow frames get their own `HITCH` line, and every minute ends with a
  `---- 1:20pm summary ----` block. The top of the file explains every column and lists the phone, the GPU and the settings.
* **It does not cost frames.** The game thread only adds a few numbers to counters (a relaxed atomic add) and hands one
  small record per second to a separate lowest-priority thread that formats and writes the text. If that thread is busy
  the record is dropped, never waited for. The file stops growing at 16 MB. Turn the switch off and nothing is measured.
* **To send it:** open a file manager → Download → share the `VoxelSandbox-log_….txt` file (or open it and copy the part
  around the time it lagged).

## Build (GitHub Actions, as before)

Upload the ZIP to `uploads/` like every other project. The workflow finds `Cargo.toml`, installs Rust + cargo-ndk,
runs the unit tests (non-blocking), builds the library for the ABIs in `gradle.properties` (`rustAbis=`),
then runs Gradle to package the APK. The APK appears as a workflow artifact.

The Android crates are `android-activity` 0.6.1 or newer 0.6.x and `jni` 0.21.x; cargo fetches them.

If "Build APK" fails with `Downloading ... gradle-8.6-bin.zip failed: timeout`, it is the network, not the code: re-run
the failed job. (The Gradle wrapper waits up to 2 minutes for its download; see `networkTimeout` in
`gradle/wrapper/gradle-wrapper.properties`. The default of 10 seconds is too short on a slow day.)

## Build locally

```
rustup target add aarch64-linux-android
cargo install cargo-ndk
cargo test --lib                      # the logic tests run on any computer
./gradlew assembleDebug               # builds the Rust library through cargo-ndk, then the APK
```
