package com.kartracer.world;

/** Data describing one track: layout (harmonic loop), theme, objects and look. */
public final class TrackDef {
    public int id;
    public String name, tagline;
    /** 0 beach, 1 jungle, 2 volcano, 3 desert */
    public int theme;
    public int seed;
    public int difficulty = 2; // 1..3 stars
    public float rx, rz, width, yBase;
    public float[] harm = new float[0];   // radius harmonics: k, amp, phase
    public float[] yharm = new float[0];  // height harmonics: k, amp(m), phase
    public int nCtrl = 32;
    public int roadSurface = Surf.ROAD;
    public float cell = 3f, margin = 150f, blend = 26f, shoulder = 3f;
    public float waterLevel = -100f;
    public boolean lava;
    public float[] boxRows = new float[0], pads = new float[0], ramps = new float[0], crates = new float[0];
    /** {type(0=boulder,1=geyser), frac, latA, latB, period, phase} */
    public float[][] hazards = new float[0][];
    /** {frac0, frac1, width, bulge} */
    public float[][] shortcuts = new float[0][];
    // look
    public int skyTop, skyHorizon, fogColor, sunColor, ambSky, ambGround, waterShallow, waterDeep;
    public float fogDensity = 0.0025f;
    public float sunAz = 40f, sunEl = 55f;

    /** Radial multiplier of the base loop at angle th. */
    public float radial(float th) {
        float r = 1f;
        for (int i = 0; i + 2 < harm.length; i += 3) r += harm[i + 1] * (float) Math.cos(harm[i] * th + harm[i + 2]);
        return r;
    }

    public float heightAtAngle(float th) {
        float y = yBase;
        for (int i = 0; i + 2 < yharm.length; i += 3) y += yharm[i + 1] * (float) Math.cos(yharm[i] * th + yharm[i + 2]);
        return y;
    }

    public float[][] controlPoints() {
        float[][] c = new float[nCtrl][4];
        for (int i = 0; i < nCtrl; i++) {
            float th = (float) (Math.PI * 2.0 * i / nCtrl);
            float r = radial(th);
            c[i][0] = rx * r * (float) Math.cos(th);
            c[i][1] = rz * r * (float) Math.sin(th);
            c[i][2] = heightAtAngle(th);
            c[i][3] = width * (1f + 0.10f * (float) Math.cos(3f * th + 1f));
        }
        return c;
    }
}
