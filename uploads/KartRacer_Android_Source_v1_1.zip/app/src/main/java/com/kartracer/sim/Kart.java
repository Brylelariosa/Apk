package com.kartracer.sim;

import com.kartracer.util.MathX;
import com.kartracer.world.Surf;
import com.kartracer.world.TrackData;

/** One kart: arcade physics, status effects, race progress and network interpolation state. */
public final class Kart {
    public static final int CTRL_LOCAL = 0, CTRL_AI = 1, CTRL_REMOTE = 2;
    public static final int HIT_SPIN = 1, HIT_OIL = 2, HIT_BURN = 3, HIT_BUMP = 4, HIT_FLIP = 5;
    public static final int F_GROUNDED = 1, F_DRIFT = 2, F_BOOST = 4, F_SHIELD = 8, F_SPIN = 16, F_FINISHED = 32,
            F_DRIFT_RIGHT = 64, F_LVL1 = 128, F_LVL2 = 256, F_INVULN = 512;
    public static final float RADIUS = 1.05f, WB = 0.95f, WT = 0.80f, GRAV = 26f;

    // identity
    public int slot, ctrl, kartType, color, driver, aiSkill;
    public String name = "";
    public KartStats st = KartStats.get(0);

    // transform / velocity
    public float x, y, z, yaw, vx, vy, vz, yawRate;
    public float ox, oy, oz, oyaw;
    public boolean grounded = true;
    public float gF, gR, nx, ny = 1f, nz;
    public int surface;
    public float waterDepth;
    public final float[] wheelOff = new float[4];

    public final KartInput in = new KartInput();
    public float steerSm;

    // drift / boost
    public boolean drifting;
    public int driftDir, driftLevel;
    public float driftTime, hopTimer, boostTime, boostPower, nitro;
    private boolean driftPrev, wantDrift;
    private float airTime;

    // status
    public float spinTime, spinDir, stunTime, slowTime, invuln, shield, respawnTimer;
    public boolean needRespawn;

    // items
    public int item;
    public float itemUseDelay;

    // race progress
    public int idx, crossings, lap, place;
    public float s, furthest, total, wrongWayTime;
    public boolean finished, wrongWay;
    public float finishTime;
    public float stuckTime;

    // visuals
    public float wheelSpin, steerVis, pitchVis, rollVis, suspY, suspV, driftVisSlide;
    private float lastVy, lastVF;

    // remote interpolation
    private static final int HN = 16;
    private boolean snapRemote = true;
    private final int[] hT = new int[HN];
    private final float[] hD = new float[HN * 8];
    private int hN;
    public int remoteFlags;
    public int remoteStamp;

    private final int[] tmpIds = new int[24];
    /** Pending bump strength, picked up by the race to emit an effect. */
    public float bumpPending;

    public Kart(int slot, int ctrl) { this.slot = slot; this.ctrl = ctrl; }

    public float speed() { return MathX.len2(vx, vz); }
    public float forwardSpeed() { return vx * (float) Math.sin(yaw) - vz * (float) Math.cos(yaw); }

    public void place(float px, float py, float pz, float pyaw) {
        x = ox = px; y = oy = py; z = oz = pz; yaw = oyaw = pyaw;
        vx = vy = vz = 0f; yawRate = 0f; grounded = true;
    }

    public void resetState() {
        drifting = false; driftTime = 0f; driftLevel = 0; hopTimer = 0f; boostTime = 0f; boostPower = 0f;
        spinTime = 0f; stunTime = 0f; slowTime = 0f; respawnTimer = 0f; needRespawn = false; wantDrift = false;
        steerSm = 0f; yawRate = 0f; stuckTime = 0f;
    }

    public int flags() {
        int f = 0;
        if (grounded) f |= F_GROUNDED;
        if (drifting) { f |= F_DRIFT; if (driftDir > 0) f |= F_DRIFT_RIGHT; if (driftLevel >= 1) f |= F_LVL1; if (driftLevel >= 2) f |= F_LVL2; }
        if (boostTime > 0.05f) f |= F_BOOST;
        if (shield > 0f) f |= F_SHIELD;
        if (spinTime > 0f) f |= F_SPIN;
        if (finished) f |= F_FINISHED;
        if (invuln > 0f) f |= F_INVULN;
        return f;
    }

    public void applyFlags(int f) {
        remoteFlags = f;
        grounded = (f & F_GROUNDED) != 0;
        drifting = (f & F_DRIFT) != 0;
        driftDir = (f & F_DRIFT_RIGHT) != 0 ? 1 : -1;
        driftLevel = (f & F_LVL2) != 0 ? 2 : ((f & F_LVL1) != 0 ? 1 : 0);
        boostTime = (f & F_BOOST) != 0 ? 0.3f : 0f;
        shield = (f & F_SHIELD) != 0 ? 1f : 0f;
        spinTime = (f & F_SPIN) != 0 ? 0.3f : 0f;
        invuln = (f & F_INVULN) != 0 ? 0.5f : 0f;
    }

    // ------------------------------------------------------------------ status

    public void addBoost(float power, float dur) {
        if (power >= boostPower || boostTime <= 0f) boostPower = Math.max(power, boostTime > 0f ? boostPower : 0f);
        boostTime = Math.max(boostTime, dur);
    }

    private void scaleSpeed(float f) { vx *= f; vz *= f; }

    /** Returns true if the hit had an effect. */
    public boolean applyHit(int kind, FxEvents fx) {
        if (invuln > 0f || respawnTimer > 0f) return false;
        if (spinTime > 0f && kind != HIT_BURN) return false;
        if (shield > 0f && kind != HIT_BURN) {
            shield = 0f;
            fx.add(FxEvents.SHIELD_POP, x, y + 0.8f, z, slot);
            return false;
        }
        float dur = st.durability;
        spinDir = ((int) (x * 13f + z * 7f) & 1) == 0 ? 1f : -1f;
        switch (kind) {
            case HIT_SPIN: spinTime = 1.25f * (1.3f - 0.6f * dur); scaleSpeed(0.35f); vy = 5f; grounded = false; break;
            case HIT_OIL: spinTime = 0.95f * (1.3f - 0.6f * dur); scaleSpeed(0.6f); break;
            case HIT_FLIP: spinTime = 1.7f; scaleSpeed(0.4f); vy = 13f; grounded = false; break;
            case HIT_BUMP: stunTime = 0.4f; scaleSpeed(0.72f); break;
            case HIT_BURN: respawnTimer = 0.9f; scaleSpeed(0.3f); break;
            default: break;
        }
        if (kind != HIT_BUMP) { endDriftSilently(); boostTime = 0f; boostPower = 0f; }
        fx.add(FxEvents.HIT, x, y + 0.6f, z, kind);
        return true;
    }

    private void endDriftSilently() { drifting = false; driftTime = 0f; driftLevel = 0; wantDrift = false; }

    private void endDrift(FxEvents fx) {
        if (!drifting) return;
        drifting = false;
        if (driftLevel >= 1) {
            float[] dur = {0f, 0.8f, 1.3f, 1.9f};
            float[] pow = {0f, 0.30f, 0.42f, 0.55f};
            addBoost(pow[driftLevel], dur[driftLevel]);
            fx.add(FxEvents.BOOST, x, y, z, slot);
        }
        driftTime = 0f; driftLevel = 0;
    }

    private void tickTimers(float dt) {
        if (boostTime > 0f) { boostTime -= dt; if (boostTime <= 0f) { boostTime = 0f; boostPower = 0f; } }
        if (spinTime > 0f) { spinTime -= dt; if (spinTime <= 0f) { spinTime = 0f; invuln = Math.max(invuln, 1.2f); } }
        if (stunTime > 0f) stunTime -= dt;
        if (slowTime > 0f) slowTime -= dt;
        if (invuln > 0f) invuln -= dt;
        if (shield > 0f) shield -= dt;
        if (hopTimer > 0f) hopTimer -= dt;
        if (respawnTimer > 0f) { respawnTimer -= dt; if (respawnTimer <= 0f) { respawnTimer = 0f; needRespawn = true; } }
    }

    // ------------------------------------------------------------------ physics

    private void sampleGround(TrackData w) {
        float sy = (float) Math.sin(yaw), cy = (float) Math.cos(yaw);
        float fx = sy, fz = -cy, rx = cy, rz = sy;
        float ffx = x + fx * WB, ffz = z + fz * WB, rfx = x - fx * WB, rfz = z - fz * WB;
        float h0 = w.groundHeight(ffx - rx * WT, ffz - rz * WT);
        float h1 = w.groundHeight(ffx + rx * WT, ffz + rz * WT);
        float h2 = w.groundHeight(rfx - rx * WT, rfz - rz * WT);
        float h3 = w.groundHeight(rfx + rx * WT, rfz + rz * WT);
        gF = MathX.clamp(((h0 + h1) - (h2 + h3)) * 0.5f / (2f * WB), -1.2f, 1.2f);
        gR = MathX.clamp(((h1 + h3) - (h0 + h2)) * 0.5f / (2f * WT), -1.2f, 1.2f);
        float hc = (h0 + h1 + h2 + h3) * 0.25f;
        wheelOff[0] = MathX.clamp(h0 - (hc + gF * WB - gR * WT), -0.25f, 0.25f);
        wheelOff[1] = MathX.clamp(h1 - (hc + gF * WB + gR * WT), -0.25f, 0.25f);
        wheelOff[2] = MathX.clamp(h2 - (hc - gF * WB - gR * WT), -0.25f, 0.25f);
        wheelOff[3] = MathX.clamp(h3 - (hc - gF * WB + gR * WT), -0.25f, 0.25f);
        float px = -gF * fx - gR * rx, pz = -gF * fz - gR * rz;
        float l = (float) Math.sqrt(px * px + 1f + pz * pz);
        nx = px / l; ny = 1f / l; nz = pz / l;
    }

    public void step(TrackData w, FxEvents fx, float dt) {
        ox = x; oy = y; oz = z; oyaw = yaw;
        tickTimers(dt);

        float gc = w.groundHeight(x, z);
        sampleGround(w);
        surface = w.surfaceAt(x, z, gc);
        waterDepth = Math.max(0f, w.waterLevel - gc);

        float sy = (float) Math.sin(yaw), cy = (float) Math.cos(yaw);
        float fx0 = sy, fz0 = -cy, rx0 = cy, rz0 = sy;
        float vF = vx * fx0 + vz * fz0;
        float speed = MathX.len2(vx, vz);

        boolean controllable = spinTime <= 0f && respawnTimer <= 0f;
        float steerIn = controllable ? in.steer : 0f;
        float thr = controllable ? in.throttle : 0f;
        float brk = controllable ? in.brake : 0f;
        if (stunTime > 0f) thr *= 0.3f;
        steerSm += (steerIn - steerSm) * Math.min(1f, 14f * dt);

        // hop + drift state machine
        boolean driftBtn = in.drift && controllable;
        if (driftBtn && !driftPrev && grounded && speed > 9f && !drifting) {
            vy = 4.6f; grounded = false; hopTimer = 0.3f; wantDrift = true; airTime = 0f;
        }
        driftPrev = driftBtn;
        if (!driftBtn) { wantDrift = false; if (drifting) endDrift(fx); }
        if (wantDrift && grounded && hopTimer <= 0f) {
            wantDrift = false;
            if (Math.abs(steerSm) > 0.2f && speed > 8f) {
                drifting = true; driftDir = steerSm > 0f ? 1 : -1; driftTime = 0f; driftLevel = 0;
            }
        }
        if (drifting) {
            if (speed < 7f || airTime > 0.6f) endDriftSilently();
            else if (grounded) {
                driftTime += dt;
                int lv = driftTime > 2.8f ? 3 : (driftTime > 1.8f ? 2 : (driftTime > 0.9f ? 1 : 0));
                if (lv != driftLevel) { driftLevel = lv; fx.add(FxEvents.DRIFT_SPARK, x, y, z, lv); }
                nitro = Math.min(1f, nitro + 0.20f * dt);
            }
        }
        // manual nitro
        if (in.boost && controllable && nitro > 0.02f) {
            nitro = Math.max(0f, nitro - 0.38f * dt);
            addBoost(0.32f, 0.12f);
        }

        // steering -> yaw rate
        float spd = Math.abs(vF);
        float base = 2.2f * st.handling;
        float sk = Math.min(1f, spd / 5f) * (1f - 0.5f * MathX.smooth(14f, 42f, spd));
        float dirSign = vF < -0.5f ? -1f : 1f;
        float tgt;
        if (spinTime > 0f) tgt = spinDir * 10f * Math.min(1f, spinTime * 2f);
        else if (!grounded) tgt = steerSm * 1.1f * Math.min(1f, spd / 10f);
        else if (drifting) tgt = driftDir * (0.72f + 0.28f * steerSm * driftDir) * 1.75f * st.handling * Math.min(1f, spd / 5f) * (1f - 0.15f * MathX.smooth(20f, 46f, spd));
        else tgt = steerSm * base * sk * dirSign;
        yawRate += (tgt - yawRate) * Math.min(1f, 16f * dt);
        yaw += yawRate * dt;
        sy = (float) Math.sin(yaw); cy = (float) Math.cos(yaw);
        float fwx = sy, fwz = -cy, rx = cy, rz = sy;
        vF = vx * fwx + vz * fwz;
        float vR = vx * rx + vz * rz;

        if (grounded) {
            float sSpeed = Surf.SPEED[surface], sAcc = Surf.ACCEL[surface];
            if (Surf.offRoad(surface)) {
                sSpeed = 1f - (1f - sSpeed) * (1f - 0.65f * st.offRoad);
                sAcc = 1f - (1f - sAcc) * (1f - 0.65f * st.offRoad);
            }
            float maxV = st.maxSpeed * sSpeed * (boostTime > 0f ? 1f + boostPower : 1f) * (slowTime > 0f ? 0.6f : 1f);
            if (thr > 0f) {
                float ratio = MathX.sat(vF / maxV);
                float a = st.accel * sAcc * (1f - (float) Math.pow(ratio, 1.6f));
                if (boostTime > 0f) a += 26f;
                vF += a * thr * dt;
            }
            if (vF > maxV) vF -= (vF - maxV) * 1.8f * dt;
            if (brk > 0f) {
                if (vF > 0.8f) vF = Math.max(0f, vF - 34f * brk * dt);
                else vF = Math.max(-9f, vF - 12f * brk * dt);
            }
            if (thr <= 0f && brk <= 0f) vF -= vF * 0.28f * dt;
            vF -= vF * 0.04f * dt;
            vF -= 9.8f * 0.6f * gF * dt;
            float gripRate = (drifting ? 3.8f : 10.5f) * st.grip * Surf.GRIP[surface];
            if (spinTime > 0f) gripRate = 0.5f;
            float gdt = Math.min(1f, gripRate * dt);
            if (vF > 1f) {
                // rotate the velocity toward the heading (keeps most speed while sliding)
                float sp = (float) Math.sqrt(vF * vF + vR * vR);
                float slip = (float) Math.atan2(vR, vF);
                sp *= 1f - 0.10f * gdt * Math.abs((float) Math.sin(slip));
                float ns = slip * (1f - gdt);
                vF = sp * (float) Math.cos(ns);
                vR = sp * (float) Math.sin(ns);
            } else vR -= vR * gdt;
            vR -= 9.8f * 0.6f * gR * dt;
            if (surface == Surf.WATER) vF -= vF * 0.5f * dt;
            vx = fwx * vF + rx * vR;
            vz = fwz * vF + rz * vR;
            airTime = 0f;
        } else {
            vy -= GRAV * dt;
            vx -= vx * 0.03f * dt; vz -= vz * 0.03f * dt;
            airTime += dt;
        }

        // integrate
        x += vx * dt; z += vz * dt;
        if (!grounded) y += vy * dt;
        collideWorld(w);

        // ground contact
        float gh = w.groundHeight(x, z);
        float newSpeed = MathX.len2(vx, vz);
        if (grounded) {
            float ballistic = y + vy * dt;
            if (ballistic - gh > 0.3f + 0.004f * newSpeed && !wantDrift) {
                grounded = false; y = ballistic; vy -= GRAV * dt;
            } else {
                float nvy = (gh - y) / dt;
                vy = MathX.clamp(nvy, -25f, 25f);
                y = gh;
            }
        } else if (y <= gh) {
            float impact = -vy;
            y = gh; grounded = true; vy = 0f;
            if (impact > 6f) {
                suspV -= impact * 0.05f;
                fx.add(FxEvents.LAND, x, y, z, impact);
                if (impact > 16f) scaleSpeed(0.93f);
            }
        }
        if (waterDepth > 2.3f && grounded && respawnTimer <= 0f) respawnTimer = 0.8f;
        if (surface == Surf.LAVA && grounded) applyHit(HIT_BURN, fx);
        if (surface == Surf.WATER && grounded && newSpeed > 6f && ((int) (x * 3f + z * 3f) & 3) == 0) fx.add(FxEvents.SPLASH, x, y, z, newSpeed);
    }

    private void collideWorld(TrackData w) {
        int cnt = w.queryColliders(x, z, RADIUS, tmpIds);
        for (int k = 0; k < cnt; k++) {
            int id = tmpIds[k];
            float dx = x - w.colX[id], dz = z - w.colZ[id];
            float rr = RADIUS + w.colR[id];
            float d2 = dx * dx + dz * dz;
            if (d2 >= rr * rr) continue;
            float d = (float) Math.sqrt(d2);
            if (d < 1e-4f) { dx = 1f; dz = 0f; d = 1f; }
            float cx = dx / d, cz = dz / d;
            float pen = rr - d;
            x += cx * pen; z += cz * pen;
            float vn = vx * cx + vz * cz;
            if (vn < 0f) {
                vx -= 1.4f * vn * cx; vz -= 1.4f * vn * cz;
                vx *= 0.92f; vz *= 0.92f;
                float imp = -vn;
                if (imp > 5f) {
                    stunTime = Math.max(stunTime, 0.25f);
                    bumpPending = Math.max(bumpPending, imp);
                }
            }
        }
        float bx = w.minX, bX = w.maxX, bz = w.minZ, bZ = w.maxZ;
        if (x < bx) { x = bx; vx = Math.abs(vx) * 0.3f; }
        if (x > bX) { x = bX; vx = -Math.abs(vx) * 0.3f; }
        if (z < bz) { z = bz; vz = Math.abs(vz) * 0.3f; }
        if (z > bZ) { z = bZ; vz = -Math.abs(vz) * 0.3f; }
    }

    // ------------------------------------------------------------------ visuals

    public void updateVisuals(TrackData w, float dt) {
        float sy = (float) Math.sin(yaw), cy = (float) Math.cos(yaw);
        float vF = vx * sy - vz * cy;
        wheelSpin += vF / 0.42f * dt;
        if (ctrl == CTRL_REMOTE) {
            yawRate = MathX.angleDiff(yaw, oyaw) / Math.max(dt, 1e-3f);
            sampleGround(w);
        }
        float steerTarget = ctrl == CTRL_REMOTE ? MathX.clamp(yawRate * 0.18f, -0.5f, 0.5f) : steerSm * 0.5f;
        steerVis = MathX.damp(steerVis, steerTarget, 18f, dt);
        float pT = grounded ? (float) Math.atan(gF) : (float) Math.atan2(vy, Math.max(4f, MathX.len2(vx, vz))) * 0.7f;
        float rT = grounded ? (float) Math.atan(gR) : 0f;
        float spdN = MathX.sat(Math.abs(vF) / 25f);
        rT += (drifting ? driftDir * 0.12f : 0f) + steerVis * 0.18f * spdN;
        pT -= MathX.clamp((vF - lastVF) / Math.max(dt, 1e-3f) * 0.0035f, -0.07f, 0.07f);
        pitchVis = MathX.damp(pitchVis, pT, 10f, dt);
        rollVis = MathX.damp(rollVis, rT, 10f, dt);
        if (grounded) suspV -= MathX.clamp(vy - lastVy, -12f, 12f) * 0.25f;
        suspV += (-160f * suspY - 13f * suspV) * dt;
        suspY = MathX.clamp(suspY + suspV * dt, -0.3f, 0.3f);
        lastVy = vy; lastVF = vF;
        driftVisSlide = MathX.damp(driftVisSlide, drifting ? driftDir * 0.28f : 0f, 8f, dt);
    }

    // ------------------------------------------------------------------ remote interpolation

    public void pushRemote(int stampMs, float px, float py, float pz, float pyaw, float pvx, float pvy, float pvz, int fl) {
        if (hN > 0 && stampMs <= hT[hN - 1]) return;
        if (hN > 0) {
            float dx = px - hD[(hN - 1) * 8], dz = pz - hD[(hN - 1) * 8 + 2];
            if (dx * dx + dz * dz > 400f) { hN = 0; snapRemote = true; }
        }
        if (hN == HN) {
            System.arraycopy(hT, 1, hT, 0, HN - 1);
            System.arraycopy(hD, 8, hD, 0, (HN - 1) * 8);
            hN--;
        }
        hT[hN] = stampMs;
        int o = hN * 8;
        hD[o] = px; hD[o + 1] = py; hD[o + 2] = pz; hD[o + 3] = pyaw; hD[o + 4] = pvx; hD[o + 5] = pvy; hD[o + 6] = pvz;
        hD[o + 7] = Float.intBitsToFloat(fl);
        hN++;
        remoteStamp = stampMs;
    }

    public boolean hasRemote() { return hN > 0; }

    public void sampleRemote(int renderMs) { sampleRemote(renderMs, 1f / 60f); }

    /**
     * Pose of a remote kart at `renderMs` (host clock). Between two received states the path is a cubic Hermite curve
     * that follows both velocities, if the newest state is older than the render time the kart is extrapolated along
     * its velocity (at most 120 ms), and the shown position eases toward the result so that a late or corrected packet
     * never makes the kart jump.
     */
    public void sampleRemote(int renderMs, float dt) {
        if (hN == 0) return;
        ox = x; oy = y; oz = z; oyaw = yaw;
        float tx, ty, tz, tyaw, tvx, tvy, tvz;
        int flagBits;
        int last = (hN - 1) * 8;
        if (renderMs >= hT[hN - 1]) {
            float g = Math.min(0.12f, (renderMs - hT[hN - 1]) / 1000f);
            tx = hD[last] + hD[last + 4] * g; ty = hD[last + 1] + hD[last + 5] * g * 0.5f; tz = hD[last + 2] + hD[last + 6] * g;
            tyaw = hD[last + 3];
            tvx = hD[last + 4]; tvy = hD[last + 5]; tvz = hD[last + 6];
            flagBits = Float.floatToRawIntBits(hD[last + 7]);
        } else if (renderMs <= hT[0]) {
            tx = hD[0]; ty = hD[1]; tz = hD[2]; tyaw = hD[3]; tvx = hD[4]; tvy = hD[5]; tvz = hD[6];
            flagBits = Float.floatToRawIntBits(hD[7]);
        } else {
            int i = 0;
            while (i < hN - 2 && hT[i + 1] <= renderMs) i++;
            int a = i * 8, b = (i + 1) * 8;
            int spanMs = Math.max(1, hT[i + 1] - hT[i]);
            float t = (renderMs - hT[i]) / (float) spanMs;
            if (spanMs <= 120) {
                float h = spanMs / 1000f, t2 = t * t, t3 = t2 * t;
                float h00 = 2f * t3 - 3f * t2 + 1f, h10 = t3 - 2f * t2 + t, h01 = -2f * t3 + 3f * t2, h11 = t3 - t2;
                tx = h00 * hD[a] + h10 * h * hD[a + 4] + h01 * hD[b] + h11 * h * hD[b + 4];
                tz = h00 * hD[a + 2] + h10 * h * hD[a + 6] + h01 * hD[b + 2] + h11 * h * hD[b + 6];
            } else {
                tx = MathX.lerp(hD[a], hD[b], t); tz = MathX.lerp(hD[a + 2], hD[b + 2], t);
            }
            ty = MathX.lerp(hD[a + 1], hD[b + 1], t);
            tyaw = hD[a + 3] + MathX.angleDiff(hD[b + 3], hD[a + 3]) * t;
            tvx = MathX.lerp(hD[a + 4], hD[b + 4], t); tvy = MathX.lerp(hD[a + 5], hD[b + 5], t); tvz = MathX.lerp(hD[a + 6], hD[b + 6], t);
            flagBits = Float.floatToRawIntBits(hD[b + 7]);
        }
        float ex = tx - x, ez = tz - z;
        if (snapRemote || dt <= 0f || ex * ex + ez * ez > 25f) {
            x = tx; y = ty; z = tz;
            snapRemote = false;
        } else {
            // advance by the velocity, then close a part of the remaining gap: no lag on steady motion, no pops on corrections
            float k = 1f - (float) Math.exp(-dt * 24f);
            float px = x + tvx * dt, pz = z + tvz * dt;
            x = px + (tx - px) * k;
            z = pz + (tz - pz) * k;
            y += (ty - y) * Math.min(1f, dt * 24f);
        }
        yaw = tyaw;
        vx = tvx; vy = tvy; vz = tvz;
        applyFlags(flagBits);
    }

    public void clearRemote() { hN = 0; snapRemote = true; }
}
