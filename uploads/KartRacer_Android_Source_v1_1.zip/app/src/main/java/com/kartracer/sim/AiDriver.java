package com.kartracer.sim;

import com.kartracer.util.MathX;
import com.kartracer.util.Rng;
import com.kartracer.world.Road;
import com.kartracer.world.TrackData;

/** Computes driver input for AI karts (and the autopilot of finished players). */
public final class AiDriver {
    private static final float[] LEVEL_SPEED = {0.87f, 0.95f, 1.0f};

    private final Rng rng;
    private final int level;
    private final float lineOffset;
    private float mistakeTime, mistakeSteer, nextMistake;
    private int lastItem;
    private float itemTimer;
    public boolean cruise;

    public AiDriver(long seed, int level, int skillClass) {
        rng = new Rng(seed * 31L + 7);
        this.level = MathX.clamp(level, 0, 2);
        lineOffset = rng.range(-0.8f, 0.8f);
        nextMistake = rng.range(4f, 12f);
    }

    public void drive(Race r, Kart k, float dt) {
        TrackData t = r.track;
        Road m = t.main;
        int n = m.n;
        KartInput in = k.in;
        in.clear();
        float spacing = t.length / n;
        float speed = k.forwardSpeed();
        int ahead = Math.max(3, Math.round(MathX.clamp(9f + speed * 0.42f, 10f, 38f) / spacing));
        int i = k.idx, j = m.wrap(i + ahead);

        float kLook = 0f;
        int scan = Math.round((12f + speed * 1.1f) / spacing);
        for (int q = 1; q <= scan; q += 2) kLook = Math.max(kLook, Math.abs(m.curv[m.wrap(i + q)]));
        float kSign = m.curv[m.wrap(i + ahead)];

        float half = m.w[j] * 0.5f;
        float off = lineOffset * half * 0.45f + MathX.clamp(kSign * 70f, -1f, 1f) * half * 0.35f;

        // avoid karts in front
        float sy = (float) Math.sin(k.yaw), cy = (float) Math.cos(k.yaw);
        float fwx = sy, fwz = -cy, rgx = cy, rgz = sy;
        float avoid = 0f;
        for (int q = 0; q < r.nKarts; q++) {
            Kart o = r.karts[q];
            if (o == k) continue;
            float dx = o.x - k.x, dz = o.z - k.z;
            float f = dx * fwx + dz * fwz, l = dx * rgx + dz * rgz;
            if (f > 1f && f < 16f && Math.abs(l) < 2.8f) avoid += (l > 0f ? -1f : 1f) * 3.4f * (1f - f / 16f);
        }
        off = MathX.clamp(off + avoid, -half + 1.6f, half - 1.6f);
        float tx = m.x[j] + (-m.tz[j]) * off, tz = m.z[j] + m.tx[j] * off;
        float desired = (float) Math.atan2(tx - k.x, -(tz - k.z));
        float err = MathX.angleDiff(desired, k.yaw);
        float steer = MathX.clamp(err * 2.3f, -1f, 1f);

        // occasional mistakes
        nextMistake -= dt;
        if (nextMistake <= 0f && !cruise) {
            mistakeTime = rng.range(0.3f, 0.7f);
            mistakeSteer = rng.range(-1f, 1f) * (level == 0 ? 0.5f : (level == 1 ? 0.3f : 0.12f));
            nextMistake = rng.range(6f, 16f) * (1f + level * 0.6f);
        }
        if (mistakeTime > 0f) { mistakeTime -= dt; steer = MathX.clamp(steer + mistakeSteer, -1f, 1f); }
        in.steer = steer;

        float vMax = k.st.maxSpeed * LEVEL_SPEED[level];
        float gap = r.leaderTotal - k.total;
        float rb = MathX.clamp(gap / 300f, -0.5f, 1f);
        vMax *= 1f + 0.05f * rb * (0.6f + level * 0.4f);
        if (cruise) vMax *= 0.55f;
        float vCurve = kLook > 1e-4f ? (float) Math.sqrt(24f / kLook) : 99f;
        float vT = Math.min(vMax, vCurve * (1f + 0.06f * level));
        if (speed < vT) in.throttle = 1f;
        else {
            in.throttle = speed < vT + 1.5f ? 0.3f : 0f;
            in.brake = MathX.clamp((speed - vT - 2f) / 10f, 0f, 1f);
        }
        if (Math.abs(err) > 0.9f && speed > 8f) in.throttle *= 0.5f;

        // items
        if (k.item != lastItem) {
            lastItem = k.item;
            itemTimer = k.item == 0 ? 0f : rng.range(0.8f, 3.0f);
        }
        if (k.item != 0 && !cruise) {
            itemTimer -= dt;
            if (itemTimer <= 0f && wantsToUse(r, k, kLook, fwx, fwz, rgx, rgz)) { in.item = true; itemTimer = 1f; }
        }
    }

    private boolean wantsToUse(Race r, Kart k, float kLook, float fwx, float fwz, float rgx, float rgz) {
        float bestAhead = 1e9f, bestBehind = 1e9f, latAhead = 0f;
        for (int q = 0; q < r.nKarts; q++) {
            Kart o = r.karts[q];
            if (o == k) continue;
            float dx = o.x - k.x, dz = o.z - k.z;
            float f = dx * fwx + dz * fwz, l = dx * rgx + dz * rgz;
            if (f > 0f && f < bestAhead) { bestAhead = f; latAhead = l; }
            if (f < 0f && -f < bestBehind) bestBehind = -f;
        }
        switch (k.item) {
            case Race.I_NITRO: return kLook < 0.008f;
            case Race.I_SHIELD: return true;
            case Race.I_ROCKET: return bestAhead < 130f || itemTimer < -8f;
            case Race.I_COCONUT: return (bestAhead < 45f && Math.abs(latAhead) < 6f) || itemTimer < -10f;
            case Race.I_SLICK: return bestBehind < 26f || itemTimer < -12f;
            default: return true;
        }
    }
}
