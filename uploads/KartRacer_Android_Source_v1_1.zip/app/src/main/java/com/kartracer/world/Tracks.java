package com.kartracer.world;

/** The built-in track list. */
public final class Tracks {
    private Tracks() {}

    public static final int COUNT = 4;
    private static TrackDef[] defs;

    public static TrackDef get(int i) {
        if (defs == null) defs = build();
        return defs[Math.floorMod(i, COUNT)];
    }

    private static TrackDef[] build() {
        TrackDef[] d = new TrackDef[COUNT];

        TrackDef t = new TrackDef();
        t.id = 0; t.name = "Sunny Shores"; t.tagline = "Palm beaches, a lagoon causeway and shallow surf";
        t.theme = 0; t.seed = 11; t.difficulty = 1;
        t.rx = 250; t.rz = 185; t.width = 13; t.yBase = 1.5f;
        t.harm = new float[]{2, 0.12f, 0.6f, 3, 0.12f, 2.0f, 4, 0.06f, 0.3f, 6, 0.035f, 1.1f};
        t.yharm = new float[]{2, 0.5f, 0.0f, 3, 0.3f, 1.0f};
        t.waterLevel = 0f;
        t.boxRows = new float[]{0.08f, 0.30f, 0.52f, 0.74f, 0.92f};
        t.pads = new float[]{0.18f, 0.62f};
        t.ramps = new float[]{0.42f};
        t.crates = new float[]{0.14f, 0.37f, 0.66f, 0.83f};
        t.hazards = new float[][]{{0, 0.57f, -5.5f, 5.5f, 5.0f, 0f}};
        t.shortcuts = new float[][]{{-1f, 0.13f, 9f, 0f}};
        t.skyTop = 0x2f86e8; t.skyHorizon = 0xbfe3ff; t.fogColor = 0xcde9f7; t.sunColor = 0xfff1d0;
        t.ambSky = 0xa9c8f0; t.ambGround = 0x9a8a68; t.waterShallow = 0x3fd6d0; t.waterDeep = 0x0b6fa8;
        t.fogDensity = 0.0022f; t.sunAz = 40f; t.sunEl = 52f;
        d[0] = t;

        t = new TrackDef();
        t.id = 1; t.name = "Jungle Run"; t.tagline = "Twisting dirt trails under giant trees";
        t.theme = 1; t.seed = 23; t.difficulty = 2;
        t.rx = 235; t.rz = 195; t.width = 11.5f; t.yBase = 6f; t.roadSurface = Surf.DIRT;
        t.harm = new float[]{2, 0.08f, 1.9f, 3, 0.15f, 0.4f, 5, 0.07f, 2.6f, 7, 0.04f, 0.9f, 9, 0.018f, 2.0f};
        t.yharm = new float[]{2, 1.6f, 0.4f, 3, 1.1f, 2.0f, 5, 0.6f, 1.0f};
        t.waterLevel = 2.0f;
        t.boxRows = new float[]{0.06f, 0.27f, 0.50f, 0.71f, 0.90f};
        t.pads = new float[]{0.15f, 0.47f, 0.80f};
        t.ramps = new float[]{0.36f, 0.76f};
        t.crates = new float[]{0.12f, 0.33f, 0.58f, 0.85f};
        t.hazards = new float[][]{{0, 0.24f, -5f, 5f, 4.4f, 0f}, {0, 0.66f, -5f, 5f, 5.2f, 0.4f}};
        t.shortcuts = new float[][]{{-1f, 0.12f, 8f, 0f}};
        t.skyTop = 0x4a9ee0; t.skyHorizon = 0xd4efd0; t.fogColor = 0xb4d8b0; t.sunColor = 0xffecc0;
        t.ambSky = 0x9cc8a0; t.ambGround = 0x5a4a30; t.waterShallow = 0x6fae7c; t.waterDeep = 0x2a5d4c;
        t.fogDensity = 0.0042f; t.sunAz = 120f; t.sunEl = 58f;
        d[1] = t;

        t = new TrackDef();
        t.id = 2; t.name = "Magma Peak"; t.tagline = "Circle an active volcano, mind the geysers";
        t.theme = 2; t.seed = 37; t.difficulty = 3;
        t.rx = 255; t.rz = 215; t.width = 12; t.yBase = 6f; t.roadSurface = Surf.ROCK;
        t.harm = new float[]{2, 0.08f, 0.2f, 3, 0.11f, 1.0f, 4, 0.07f, 2.4f, 6, 0.045f, 0.5f, 9, 0.02f, 1.3f};
        t.yharm = new float[]{1, 3.0f, 0.3f, 2, 2.0f, 1.2f, 4, 0.8f, 0.0f};
        t.waterLevel = 0.8f; t.lava = true; t.blend = 14f;
        t.boxRows = new float[]{0.07f, 0.29f, 0.51f, 0.73f, 0.93f};
        t.pads = new float[]{0.20f, 0.55f, 0.85f};
        t.ramps = new float[]{0.40f};
        t.crates = new float[]{0.10f, 0.35f, 0.62f, 0.80f};
        t.hazards = new float[][]{{1, 0.17f, -3.5f, 3.5f, 6f, 0f}, {1, 0.46f, 3f, 3f, 6.5f, 2f},
                {1, 0.69f, -3f, -3f, 5.5f, 3.5f}, {0, 0.88f, -5f, 5f, 4.8f, 0.2f}};
        t.shortcuts = new float[][]{{-1f, 0.12f, 8f, 0f}};
        t.skyTop = 0x2a1a3e; t.skyHorizon = 0xe0713a; t.fogColor = 0x7a3c34; t.sunColor = 0xff9a62;
        t.ambSky = 0x9a5a50; t.ambGround = 0x3a2420; t.waterShallow = 0xff8a1c; t.waterDeep = 0xd02a05;
        t.fogDensity = 0.0034f; t.sunAz = 200f; t.sunEl = 24f;
        d[2] = t;

        t = new TrackDef();
        t.id = 3; t.name = "Dusty Canyon"; t.tagline = "Long straights, big jumps and sandstone mesas";
        t.theme = 3; t.seed = 53; t.difficulty = 2;
        t.rx = 270; t.rz = 175; t.width = 13.5f; t.yBase = 5f;
        t.harm = new float[]{2, 0.13f, 2.8f, 3, 0.13f, 0.9f, 4, 0.06f, 1.7f, 5, 0.05f, 0.1f, 8, 0.025f, 0.6f};
        t.yharm = new float[]{2, 1.2f, 1.0f, 3, 0.9f, 0.2f};
        t.waterLevel = -100f;
        t.boxRows = new float[]{0.09f, 0.31f, 0.53f, 0.75f, 0.94f};
        t.pads = new float[]{0.16f, 0.45f, 0.82f};
        t.ramps = new float[]{0.27f, 0.68f};
        t.crates = new float[]{0.12f, 0.39f, 0.60f, 0.88f};
        t.hazards = new float[][]{{0, 0.35f, -6f, 6f, 4.2f, 0f}, {0, 0.78f, -6f, 6f, 4.8f, 0.5f}};
        t.shortcuts = new float[][]{{-1f, 0.12f, 9f, 0f}};
        t.skyTop = 0x5aa8f0; t.skyHorizon = 0xf7e1b5; t.fogColor = 0xefd2a0; t.sunColor = 0xfff0d0;
        t.ambSky = 0xc8d4e8; t.ambGround = 0x9a7448; t.waterShallow = 0x4fc7c0; t.waterDeep = 0x1a7a9a;
        t.fogDensity = 0.0030f; t.sunAz = 300f; t.sunEl = 60f;
        d[3] = t;
        return d;
    }
}
