package com.kartracer.gfx;

import com.kartracer.util.Col;
import com.kartracer.util.Mat4;
import com.kartracer.util.MathX;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;

/** Builds MeshData from primitives. A transform stack (rotation, translation, uniform scale) applies to everything added. */
public final class MeshBuilder {
    private float[] pos = new float[3 * 512], nrm = new float[3 * 512], uv = new float[2 * 512];
    private int[] col = new int[512];
    private int[] idx = new int[3 * 768];
    private int vn, in;
    private final float[][] stack = new float[16][16];
    private int sp;
    private final float[] tmp = new float[16];

    public MeshBuilder() { Mat4.identity(stack[0]); }

    private float[] m() { return stack[sp]; }

    public MeshBuilder push() { System.arraycopy(stack[sp], 0, stack[sp + 1], 0, 16); sp++; return this; }
    public MeshBuilder pop() { sp--; return this; }
    public MeshBuilder translate(float x, float y, float z) { Mat4.translation(tmp, x, y, z); Mat4.mul(m(), m(), tmp); return this; }
    public MeshBuilder rotX(float a) { Mat4.rotationX(tmp, a); Mat4.mul(m(), m(), tmp); return this; }
    public MeshBuilder rotY(float a) { Mat4.rotationY(tmp, a); Mat4.mul(m(), m(), tmp); return this; }
    public MeshBuilder rotZ(float a) { Mat4.rotationZ(tmp, a); Mat4.mul(m(), m(), tmp); return this; }
    public MeshBuilder scale(float s) { Mat4.scaling(tmp, s, s, s); Mat4.mul(m(), m(), tmp); return this; }
    public MeshBuilder identity() { Mat4.identity(m()); return this; }

    public int vertexCount() { return vn; }

    /** Marks every vertex colour as fixed (alpha 0) so the kart paint colour does not tint this mesh. */
    public MeshBuilder fixedColors() {
        for (int i = 0; i < vn; i++) col[i] &= 0x00FFFFFF;
        return this;
    }

    private void grow() {
        int c = col.length * 2;
        pos = Arrays.copyOf(pos, c * 3); nrm = Arrays.copyOf(nrm, c * 3); uv = Arrays.copyOf(uv, c * 2); col = Arrays.copyOf(col, c);
    }

    public int vert(float x, float y, float z, float nx, float ny, float nz, int color, float u, float v) {
        if (vn == col.length) grow();
        float[] t = m();
        int o = vn * 3;
        pos[o] = t[0] * x + t[4] * y + t[8] * z + t[12];
        pos[o + 1] = t[1] * x + t[5] * y + t[9] * z + t[13];
        pos[o + 2] = t[2] * x + t[6] * y + t[10] * z + t[14];
        float ax = t[0] * nx + t[4] * ny + t[8] * nz, ay = t[1] * nx + t[5] * ny + t[9] * nz, az = t[2] * nx + t[6] * ny + t[10] * nz;
        float l = (float) Math.sqrt(ax * ax + ay * ay + az * az);
        if (l < 1e-9f) { ax = 0f; ay = 1f; az = 0f; l = 1f; }
        nrm[o] = ax / l; nrm[o + 1] = ay / l; nrm[o + 2] = az / l;
        uv[vn * 2] = u; uv[vn * 2 + 1] = v;
        col[vn] = color;
        return vn++;
    }

    public int vert(float x, float y, float z, float nx, float ny, float nz, int color) { return vert(x, y, z, nx, ny, nz, color, 0f, 0f); }

    public void tri(int a, int b, int c) {
        if (in + 3 > idx.length) idx = Arrays.copyOf(idx, idx.length * 2);
        idx[in++] = a; idx[in++] = b; idx[in++] = c;
    }

    /** a,b,c,d counter clockwise seen from the front. */
    public void quad(int a, int b, int c, int d) { tri(a, b, c); tri(a, c, d); }

    // ---------------------------------------------------------------- primitives

    private static final float[][] FACE_N = {{0, 1, 0}, {0, -1, 0}, {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}};
    private static final float[][] FACE_U = {{1, 0, 0}, {1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {1, 0, 0}, {0, 1, 0}};
    private static final float[][] FACE_V = {{0, 0, -1}, {0, 0, 1}, {0, 0, 1}, {0, 1, 0}, {0, 1, 0}, {1, 0, 0}};
    private static final float[] FACE_SHADE = {1.0f, 0.55f, 0.82f, 0.72f, 0.9f, 0.66f};

    /** Axis aligned box with half extents; faces are shaded for a baked look. */
    public MeshBuilder box(float cx, float cy, float cz, float hx, float hy, float hz, int color) {
        float[] h = {hx, hy, hz};
        for (int f = 0; f < 6; f++) {
            float[] n = FACE_N[f], u = FACE_U[f], v = FACE_V[f];
            float hn = Math.abs(n[0]) * hx + Math.abs(n[1]) * hy + Math.abs(n[2]) * hz;
            float hu = Math.abs(u[0]) * hx + Math.abs(u[1]) * hy + Math.abs(u[2]) * hz;
            float hv = Math.abs(v[0]) * hx + Math.abs(v[1]) * hy + Math.abs(v[2]) * hz;
            int c = Col.scale(color, FACE_SHADE[f]);
            float px = cx + n[0] * hn, py = cy + n[1] * hn, pz = cz + n[2] * hn;
            int a = vert(px - u[0] * hu - v[0] * hv, py - u[1] * hu - v[1] * hv, pz - u[2] * hu - v[2] * hv, n[0], n[1], n[2], c, 0f, 0f);
            int b = vert(px + u[0] * hu - v[0] * hv, py + u[1] * hu - v[1] * hv, pz + u[2] * hu - v[2] * hv, n[0], n[1], n[2], c, 1f, 0f);
            int cc = vert(px + u[0] * hu + v[0] * hv, py + u[1] * hu + v[1] * hv, pz + u[2] * hu + v[2] * hv, n[0], n[1], n[2], c, 1f, 1f);
            int d = vert(px - u[0] * hu + v[0] * hv, py - u[1] * hu + v[1] * hv, pz - u[2] * hu + v[2] * hv, n[0], n[1], n[2], c, 0f, 1f);
            quad(a, b, cc, d);
        }
        return this;
    }

    /** Vertical cylinder / cone frustum from y=cy (radius r0) to y=cy+h (radius r1). */
    public MeshBuilder cyl(float cx, float cy, float cz, float r0, float r1, float h, int segs, int colBot, int colTop, boolean capBot, boolean capTop) {
        float slope = h > 1e-6f ? (r0 - r1) / h : 0f;
        int[] b = new int[segs + 1], t = new int[segs + 1];
        for (int i = 0; i <= segs; i++) {
            float th = MathX.TAU * i / segs;
            float c = (float) Math.cos(th), s = (float) Math.sin(th);
            b[i] = vert(cx + r0 * c, cy, cz + r0 * s, c, slope, s, colBot, i / (float) segs, 0f);
            t[i] = vert(cx + r1 * c, cy + h, cz + r1 * s, c, slope, s, colTop, i / (float) segs, 1f);
        }
        for (int i = 0; i < segs; i++) { tri(b[i], t[i], b[i + 1]); if (r1 > 1e-5f) tri(b[i + 1], t[i], t[i + 1]); }
        if (capTop && r1 > 1e-5f) {
            int c0 = vert(cx, cy + h, cz, 0, 1, 0, colTop);
            int[] r = new int[segs + 1];
            for (int i = 0; i <= segs; i++) { float th = MathX.TAU * i / segs; r[i] = vert(cx + r1 * (float) Math.cos(th), cy + h, cz + r1 * (float) Math.sin(th), 0, 1, 0, colTop); }
            for (int i = 0; i < segs; i++) tri(c0, r[i + 1], r[i]);
        }
        if (capBot && r0 > 1e-5f) {
            int c0 = vert(cx, cy, cz, 0, -1, 0, colBot);
            int[] r = new int[segs + 1];
            for (int i = 0; i <= segs; i++) { float th = MathX.TAU * i / segs; r[i] = vert(cx + r0 * (float) Math.cos(th), cy, cz + r0 * (float) Math.sin(th), 0, -1, 0, colBot); }
            for (int i = 0; i < segs; i++) tri(c0, r[i], r[i + 1]);
        }
        return this;
    }

    /** Tapered tube between two points. */
    public MeshBuilder tube(float x0, float y0, float z0, float x1, float y1, float z1, float r0, float r1, int segs, int c0, int c1, boolean caps) {
        float dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return this;
        dx /= len; dy /= len; dz /= len;
        float ax = Math.abs(dy) < 0.9f ? 0f : 1f, ay = Math.abs(dy) < 0.9f ? 1f : 0f;
        float ux = ay * dz - 0f * dy, uy = 0f * dx - ax * dz, uz = ax * dy - ay * dx; // a x d with a=(ax,ay,0)
        float ul = (float) Math.sqrt(ux * ux + uy * uy + uz * uz);
        ux /= ul; uy /= ul; uz /= ul;
        float vx = uy * dz - uz * dy, vy = uz * dx - ux * dz, vz = ux * dy - uy * dx; // u x d
        float slope = len > 1e-6f ? (r0 - r1) / len : 0f;
        int[] b = new int[segs + 1], t = new int[segs + 1];
        for (int i = 0; i <= segs; i++) {
            float th = MathX.TAU * i / segs;
            float c = (float) Math.cos(th), s = (float) Math.sin(th);
            float ox = ux * c + vx * s, oy = uy * c + vy * s, oz = uz * c + vz * s;
            float nx = ox + dx * slope, ny = oy + dy * slope, nz = oz + dz * slope;
            b[i] = vert(x0 + ox * r0, y0 + oy * r0, z0 + oz * r0, nx, ny, nz, c0, i / (float) segs, 0f);
            t[i] = vert(x1 + ox * r1, y1 + oy * r1, z1 + oz * r1, nx, ny, nz, c1, i / (float) segs, 1f);
        }
        for (int i = 0; i < segs; i++) { tri(b[i], t[i], b[i + 1]); if (r1 > 1e-5f) tri(b[i + 1], t[i], t[i + 1]); }
        if (caps) {
            cap(x1, y1, z1, dx, dy, dz, ux, uy, uz, vx, vy, vz, r1, segs, c1, true);
            cap(x0, y0, z0, -dx, -dy, -dz, ux, uy, uz, vx, vy, vz, r0, segs, c0, false);
        }
        return this;
    }

    private void cap(float x, float y, float z, float nx, float ny, float nz, float ux, float uy, float uz, float vx, float vy, float vz,
                     float r, int segs, int color, boolean top) {
        if (r < 1e-5f) return;
        int c0 = vert(x, y, z, nx, ny, nz, color);
        int[] ring = new int[segs + 1];
        for (int i = 0; i <= segs; i++) {
            float th = MathX.TAU * i / segs;
            float c = (float) Math.cos(th), s = (float) Math.sin(th);
            ring[i] = vert(x + (ux * c + vx * s) * r, y + (uy * c + vy * s) * r, z + (uz * c + vz * s) * r, nx, ny, nz, color);
        }
        for (int i = 0; i < segs; i++) { if (top) tri(c0, ring[i + 1], ring[i]); else tri(c0, ring[i], ring[i + 1]); }
    }

    /** Ellipsoid with vertical color gradient. */
    public MeshBuilder sphere(float cx, float cy, float cz, float rx, float ry, float rz, int segs, int rings, int colBot, int colTop) {
        int[][] g = new int[rings + 1][segs + 1];
        for (int k = 0; k <= rings; k++) {
            float ph = -MathX.PI / 2f + MathX.PI * k / rings;
            float cp = (float) Math.cos(ph), sp2 = (float) Math.sin(ph);
            int c = Col.mix(colBot, colTop, (sp2 + 1f) * 0.5f);
            for (int i = 0; i <= segs; i++) {
                float th = MathX.TAU * i / segs;
                float ct = (float) Math.cos(th), st = (float) Math.sin(th);
                g[k][i] = vert(cx + rx * cp * ct, cy + ry * sp2, cz + rz * cp * st, cp * ct / rx, sp2 / ry, cp * st / rz, c, i / (float) segs, k / (float) rings);
            }
        }
        for (int k = 0; k < rings; k++) for (int i = 0; i < segs; i++) {
            int a = g[k][i], b = g[k][i + 1], c = g[k + 1][i], d = g[k + 1][i + 1];
            tri(a, c, b);
            tri(b, c, d);
        }
        return this;
    }

    public MeshBuilder sphere(float cx, float cy, float cz, float r, int segs, int rings, int color) { return sphere(cx, cy, cz, r, r, r, segs, rings, color, color); }

    /** Flat shaded triangle with its own normal. */
    public MeshBuilder flatTri(float x0, float y0, float z0, float x1, float y1, float z1, float x2, float y2, float z2, int color) {
        float ax = x1 - x0, ay = y1 - y0, az = z1 - z0, bx = x2 - x0, by = y2 - y0, bz = z2 - z0;
        float nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
        int a = vert(x0, y0, z0, nx, ny, nz, color), b = vert(x1, y1, z1, nx, ny, nz, color), c = vert(x2, y2, z2, nx, ny, nz, color);
        tri(a, b, c);
        return this;
    }

    /** Double sided ribbon along a polyline. width direction (wx,wy,wz); per point half widths; color gradient c0 -> c1. */
    public MeshBuilder ribbon(float[] px, float[] py, float[] pz, float[] hw, float wx, float wy, float wz, int c0, int c1) {
        int n = px.length;
        int[] l = new int[n], r = new int[n], l2 = new int[n], r2 = new int[n];
        for (int i = 0; i < n; i++) {
            int a = Math.max(0, i - 1), b = Math.min(n - 1, i + 1);
            float tx = px[b] - px[a], ty = py[b] - py[a], tz = pz[b] - pz[a];
            float nx = ty * wz - tz * wy, ny = tz * wx - tx * wz, nz = tx * wy - ty * wx;
            int c = Col.mix(c0, c1, i / (float) Math.max(1, n - 1));
            l[i] = vert(px[i] - wx * hw[i], py[i] - wy * hw[i], pz[i] - wz * hw[i], nx, ny, nz, c);
            r[i] = vert(px[i] + wx * hw[i], py[i] + wy * hw[i], pz[i] + wz * hw[i], nx, ny, nz, c);
            l2[i] = vert(px[i] - wx * hw[i], py[i] - wy * hw[i], pz[i] - wz * hw[i], -nx, -ny, -nz, c);
            r2[i] = vert(px[i] + wx * hw[i], py[i] + wy * hw[i], pz[i] + wz * hw[i], -nx, -ny, -nz, c);
        }
        for (int i = 0; i + 1 < n; i++) {
            quad(l[i], r[i], r[i + 1], l[i + 1]);
            quad(r2[i], l2[i], l2[i + 1], r2[i + 1]);
        }
        return this;
    }

    public MeshBuilder ribbon(float[] px, float[] py, float[] pz, float[] hw, float wx, float wy, float wz, int c0, int c1, int alpha0, int alpha1) {
        ribbon(px, py, pz, hw, wx, wy, wz, Col.withAlpha(c0, alpha0), Col.withAlpha(c1, alpha1));
        return this;
    }

    // ---------------------------------------------------------------- build

    public MeshData build() {
        if (vn >= 65536) throw new IllegalStateException("mesh too large: " + vn);
        ByteBuffer b = ByteBuffer.allocate(vn * MeshData.STRIDE).order(ByteOrder.LITTLE_ENDIAN);
        float minx = 1e9f, miny = 1e9f, minz = 1e9f, maxx = -1e9f, maxy = -1e9f, maxz = -1e9f;
        for (int i = 0; i < vn; i++) {
            float x = pos[i * 3], y = pos[i * 3 + 1], z = pos[i * 3 + 2];
            b.putFloat(x); b.putFloat(y); b.putFloat(z);
            b.put((byte) Math.round(nrm[i * 3] * 127f)); b.put((byte) Math.round(nrm[i * 3 + 1] * 127f)); b.put((byte) Math.round(nrm[i * 3 + 2] * 127f)); b.put((byte) 0);
            b.putInt(col[i]);
            b.putFloat(uv[i * 2]); b.putFloat(uv[i * 2 + 1]);
            minx = Math.min(minx, x); maxx = Math.max(maxx, x); miny = Math.min(miny, y); maxy = Math.max(maxy, y); minz = Math.min(minz, z); maxz = Math.max(maxz, z);
        }
        short[] si = new short[in];
        for (int i = 0; i < in; i++) si[i] = (short) idx[i];
        MeshData m = new MeshData(vn, b.array(), si);
        m.cx = (minx + maxx) * 0.5f; m.cy = (miny + maxy) * 0.5f; m.cz = (minz + maxz) * 0.5f;
        float dx = maxx - minx, dy = maxy - miny, dz = maxz - minz;
        m.radius = vn == 0 ? 0f : 0.5f * (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        return m;
    }
}
