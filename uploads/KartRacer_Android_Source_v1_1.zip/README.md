# Kart Racer (Android)

An original 3D arcade kart racer with real local-network multiplayer.
Pure Java + OpenGL ES 3.0 (no game engine, no native code, no third-party libraries), so the APK is small and runs on every CPU type.
Everything (karts, drivers, tracks, textures, particles, and now all sound effects) is generated in code, there are no art or audio files to go missing. Textures are compressed to ETC2 on the fly (falls back to plain RGBA if a driver refuses).

## Get the APK (phone only, GitHub Actions)

1. Open your GitHub repository (browser or GitHub app) and go to the `uploads` folder.
2. Tap **Add file > Upload files**, pick `KartRacer_Android_Source.zip`, then **Commit changes**.
3. Open the **Actions** tab. The **Build APK** run starts by itself and takes about 5-10 minutes.
4. When it turns green, open the run and scroll to **Artifacts**. Download `KartRacer_Android_Source-debug-vN`, unzip it and install `app-debug.apk`
   (allow "install unknown apps" for your file manager or browser if Android asks).
5. If the run turns red, open it, tap the failed step and copy the red error text (or download the `...build-reports` artifact) and send it over.

The workflow in `.github/workflows/build-apk.yml` finds the newest ZIP in the repository, unzips it, finds `settings.gradle` and runs `./gradlew assembleDebug`
(Gradle 8.6, JDK 17, Android Gradle Plugin 8.2.2, compileSdk 34, minSdk 24). If you add the `KEYSTORE_BASE64`, `STORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`
secrets it builds a signed release APK instead.

Requirements on the phone: Android 7.0 or newer with OpenGL ES 3.0 (almost every phone from 2015 on).

## Playing

* **Quick Race**: pick one of 4 tracks, laps, opponents (0-7), difficulty and power-ups.
* **Garage**: 6 karts with different speed / acceleration / handling / toughness, 8 paint colors, 6 drivers.
* **Sound**: engine that follows your speed, tyre squeal, countdown, power-ups, hits, crashes, lap and finish jingles, all synthesised at start-up (`audio/`). Settings > Sound has an on/off switch and a volume slider.
* **Controls** (landscape): left thumb steers, right thumb has Gas, Brake, Drift (hop + slide, release for a mini-turbo), Nitro (spends the meter filled by drifting)
  and the Item button. Every button is labelled, the Item button shows the power-up you hold (name, picture and a short hint when you pick it up) and a shield timer bar appears while a shield is active. Settings offer Buttons / Tilt / Slide steering, auto-accelerate, left-handed layout, button size/opacity and a drag-to-place layout editor.
* **Power-ups**: Turbo (instant boost), Rocket (homing), Coconut (straight shot), Oil slick (drop behind you), Shield. Smash crates, hit boost pads, use ramps and shortcuts, avoid the
  hazards (swinging boulders, geysers, lava, deep water). Start boost: press gas just before GO.

## Multiplayer over Wi-Fi or hotspot (no internet needed)

1. Put the phones on the same Wi-Fi network, or turn on a mobile hotspot on one phone and connect the others to it.
2. One player: **Multiplayer > Host game**. The lobby shows the IP address(es) of the host.
3. Everyone else: **Multiplayer > Join game**. Hosts show up automatically (UDP broadcast discovery). If your router blocks broadcasts, type the host IP manually.
4. The host sets track, laps, AI count and difficulty. Others press **Ready**, the host presses **Start**. Up to 8 racers total (humans + AI).

How it works: TCP (port 47231) for the lobby and race events, UDP (47232) for kart state at 40 Hz with TCP fallback, UDP broadcast on 47233 for discovery.
Every device simulates its own kart, the host runs the AI, items and projectiles. Remote karts are drawn with a smooth (cubic Hermite) path and an adaptive delay of
about 50-170 ms that follows the measured age of incoming packets (typically 60-80 ms on a good Wi-Fi), the shared clock glides instead of jumping, and the
Wi-Fi chip is kept in its low-latency mode while a session is running. Own power-up shots give instant feedback while the host spawns the real projectile. A dropped player is replaced by AI and can reconnect during the race.

## If something goes wrong

**Settings > Diagnostics** shows an in-app log (graphics driver info, shader errors, crashes, network events).
Use *Save to Downloads* (writes `Download/KartRacer/kartracer-log-*.txt`), *Copy* or *Share* and send that text. After a crash the game offers to open the log on the next start.
Graphics: Settings > Graphics has Low / Medium / High presets, shadows, resolution scale, 30/60 FPS cap and automatic resolution lowering when the frame rate drops.

## Project layout

```
app/src/main/java/com/kartracer/
  util/   math, matrices, noise, deterministic RNG, diagnostics log
  audio/  procedural sound synthesizer and SoundPool player
  world/  track definitions, spline roads, terrain generation, scenery, world queries
  sim/    kart physics, AI drivers, race rules, items, hazards, network hooks
  net/    wire protocol, host server, client link, LAN discovery
  gfx/    procedural meshes (karts, props, terrain), textures, particles, camera
  gl/     OpenGL ES 3 renderer (shadow map, instancing, water, sky, particles)
  app/    activity, menus, HUD / touch controls, settings, engine glue
```
