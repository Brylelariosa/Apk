package com.example.gamebooster

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.CheckBox
import android.widget.TextView

class ProcessAdapter(
    private val context: Context,
    private val processes: List<AppProcess>
) : BaseAdapter() {

    private val selectedPackages = mutableSetOf<String>()

    fun getSelectedProcesses(): Set<String> = selectedPackages

    override fun getCount() = processes.size

    override fun getItem(position: Int) = processes[position]

    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val holder: ViewHolder
        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item_process, parent, false)
            holder = ViewHolder(view)
            view.tag = holder
        } else {
            view = convertView
            holder = view.tag as ViewHolder
        }

        val process = processes[position]
        holder.appName.text = process.label
        holder.packageName.text = process.packageName
        holder.checkBox.isChecked = selectedPackages.contains(process.packageName)

        holder.checkBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) selectedPackages.add(process.packageName)
            else selectedPackages.remove(process.packageName)
        }

        // allow tapping the whole row to toggle
        view.setOnClickListener {
            holder.checkBox.isChecked = !holder.checkBox.isChecked
        }

        return view
    }

    class ViewHolder(view: View) {
        val appName: TextView = view.findViewById(R.id.app_name)
        val packageName: TextView = view.findViewById(R.id.package_name)
        val checkBox: CheckBox = view.findViewById(R.id.checkbox)
    }
}