package com.example.gamebooster

import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var ramInfo: TextView
    private lateinit var processList: ListView
    private lateinit var boostButton: Button
    private lateinit var adapter: ProcessAdapter
    private val runningProcesses = mutableListOf<AppProcess>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ramInfo = findViewById(R.id.ram_info)
        processList = findViewById(R.id.process_list)
        boostButton = findViewById(R.id.boost_button)

        adapter = ProcessAdapter(this, runningProcesses)
        processList.adapter = adapter

        refreshData()

        boostButton.setOnClickListener {
            val selected = adapter.getSelectedProcesses()
            if (selected.isEmpty()) {
                Toast.makeText(this, "No processes selected", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            var killed = 0
            for (pkg in selected) {
                try {
                    am.killBackgroundProcesses(pkg)
                    // Remove from list
                    runningProcesses.removeAll { it.packageName == pkg }
                    killed++
                } catch (e: Exception) {
                    // ignore
                }
            }
            adapter.notifyDataSetChanged()
            Toast.makeText(this, "Killed $killed processes", Toast.LENGTH_SHORT).show()
            refreshRamInfo()
        }
    }

    private fun refreshData() {
        refreshRamInfo()
        refreshProcessList()
    }

    private fun refreshRamInfo() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val totalMB = memInfo.totalMem / (1024 * 1024)
        val availMB = memInfo.availMem / (1024 * 1024)

        ramInfo.text = "RAM: %d MB free / %d MB total".format(availMB, totalMB)
    }

    private fun refreshProcessList() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = packageManager

        runningProcesses.clear()
        val list = am.runningAppProcesses ?: return
        for (processInfo in list) {
            // Skip system and our own process
            if (processInfo.processName == packageName) continue
            if (processInfo.importance >= ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) continue

            val pkgName = processInfo.pkgList.firstOrNull() ?: continue
            var label = pkgName
            try {
                val appInfo = pm.getApplicationInfo(pkgName, 0)
                label = pm.getApplicationLabel(appInfo).toString()
            } catch (_: PackageManager.NameNotFoundException) {}
            runningProcesses.add(AppProcess(label, pkgName))
        }
        adapter.notifyDataSetChanged()
    }
}

data class AppProcess(val label: String, val packageName: String)