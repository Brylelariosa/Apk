package com.zipapkbuilder.core

/**
 * Says which piece of long-running work the current thread is carrying out, so feedback that is
 * produced deep inside shared helpers (an upload's progress text, a log line) can be routed by the
 * owner of that work instead of always landing on the screen.
 *
 * Today the only owner is a build ([com.zipapkbuilder.feature.build.BuildSession]): its log lines
 * and status text are shown while the repo it belongs to is the one on screen, and held back while
 * the user looks at another repo. Code that reports feedback asks [sink] first; with no work in
 * scope (a task started from the screen itself) it reports straight to the screen, as before.
 *
 * Thread-local on purpose: a build runs top to bottom on one worker thread, so every helper it
 * calls on that thread is covered without passing a parameter through each of them. Work that
 * hops to another thread is not covered there, and its feedback reaches the screen directly.
 */
object WorkScope {

    /** Where the feedback of the work in scope goes. */
    interface Sink {
        fun log(line: String)
        fun status(text: String)
    }

    private val current = ThreadLocal<Sink?>()

    /** The work the calling thread is carrying out, or null when it isn't carrying out any. */
    fun sink(): Sink? = current.get()

    /** Runs [block] with [sink] in scope for the calling thread, then restores whatever was in scope before. */
    fun <T> within(sink: Sink, block: () -> T): T {
        val previous = current.get()
        current.set(sink)
        try {
            return block()
        } finally {
            current.set(previous)
        }
    }
}
