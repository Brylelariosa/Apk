package com.example.chatbot

import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.chatbot.databinding.ItemMessageBinding

class MessageAdapter(private val messages: List<Message>) :
    RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

    inner class MessageViewHolder(val binding: ItemMessageBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
        val binding = ItemMessageBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return MessageViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
        val msg = messages[position]
        with(holder.binding) {
            tvMessage.text = msg.text

            if (msg.sender == Sender.USER) {
                tvMessage.setBackgroundResource(R.drawable.bg_bubble_user)
                tvMessage.setTextColor(root.context.getColor(R.color.white))
                messageContainer.gravity = Gravity.END
            } else {
                tvMessage.setBackgroundResource(R.drawable.bg_bubble_bot)
                tvMessage.setTextColor(root.context.getColor(R.color.text_primary))
                messageContainer.gravity = Gravity.START
            }
        }
    }

    override fun getItemCount() = messages.size
}
