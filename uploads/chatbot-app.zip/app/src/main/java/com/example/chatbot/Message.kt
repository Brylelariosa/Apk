package com.example.chatbot

enum class Sender { USER, BOT }

data class Message(
    val text: String,
    val sender: Sender
)
