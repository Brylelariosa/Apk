package com.example.chatbot

import android.os.Bundle
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.chatbot.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: MessageAdapter
    private val messages = mutableListOf<Message>()

    // ── Bot reply logic ──────────────────────────────────────────────────────
    // Replace this function body with an AI API call when you're ready.
    private fun getBotReply(userText: String): String {
        val lower = userText.lowercase()
        return when {
            lower.contains("hello") || lower.contains("hi") ->
                "Hey there! 👋 How can I help you?"
            lower.contains("how are you") ->
                "I'm just a placeholder bot, but doing great!"
            lower.contains("bye") || lower.contains("exit") ->
                "Goodbye! 👋"
            lower.contains("help") ->
                "I'm here to help — ask me anything!"
            lower.contains("name") ->
                "I'm ChatBot, your simple assistant."
            else -> {
                val fallbacks = listOf(
                    "Interesting! Tell me more.",
                    "Got it — what else?",
                    "I see. Go on.",
                    "Noted! Anything else on your mind?",
                    "Hmm, let me think about that."
                )
                fallbacks.random()
            }
        }
    }
    // ────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupInput()

        // Opening greeting
        addBotMessage("Hello! 👋 Type a message to get started.")
    }

    private fun setupRecyclerView() {
        adapter = MessageAdapter(messages)
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@MainActivity).also {
                it.stackFromEnd = true          // newest messages at the bottom
            }
            adapter = this@MainActivity.adapter
        }
    }

    private fun setupInput() {
        // Send on button tap
        binding.btnSend.setOnClickListener { sendMessage() }

        // Send on keyboard "Done" / Enter
        binding.etInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else false
        }
    }

    private fun sendMessage() {
        val text = binding.etInput.text.toString().trim()
        if (text.isEmpty()) return

        binding.etInput.setText("")

        // 1. Show user message
        addUserMessage(text)

        // 2. Get and show bot reply
        val reply = getBotReply(text)
        binding.recyclerView.postDelayed({ addBotMessage(reply) }, 500)
    }

    private fun addUserMessage(text: String) {
        messages.add(Message(text, sender = Sender.USER))
        adapter.notifyItemInserted(messages.lastIndex)
        binding.recyclerView.scrollToPosition(messages.lastIndex)
    }

    private fun addBotMessage(text: String) {
        messages.add(Message(text, sender = Sender.BOT))
        adapter.notifyItemInserted(messages.lastIndex)
        binding.recyclerView.scrollToPosition(messages.lastIndex)
    }
}
