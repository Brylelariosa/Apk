# Dependencies

Versions are what the project declares. Rust dependency versions float inside their semver range until you
commit the `Cargo.lock` produced by the first CI run (see README).

## Why librqbit

The brief rules out a simulated engine and asks to investigate libtorrent-rasterbar and native Rust options.

| Option | Verdict |
| --- | --- |
| **librqbit** (Rust, Apache-2.0) | Chosen. Real BitTorrent client library: DHT, magnet metadata, trackers, selective files, piece verification, fast resume, rate limits, persistence; maintained, with a documented API. Builds without OpenSSL (`rust-tls`). |
| libtorrent-rasterbar through bindings | Mature, but needs Boost and a C++ cross-compile (C++ runtime, binding layer) that could not be tested here, and a much larger binary. |
| cratetorrent | No magnet links, no DHT. |
| A new engine written for this project | Thousands of lines of protocol code that could not be run against real swarms in the authoring environment; far riskier than a mature library. |

**Version 8.1.1, not 9.x.** 9.x depends on `reqwest 0.13`, whose rustls setup verifies certificates through the
operating system (`rustls-platform-verifier`). On Android that needs extra Java-side setup that cannot be
tested here, and HTTPS (https trackers, `.torrent` over HTTPS) would fail without it. 8.1.1 uses `reqwest 0.12`
with bundled root certificates. Upgrading later is possible but needs that work.

## Rust (workspace)

| Crate | Version | Used for | Licence |
| --- | --- | --- | --- |
| librqbit | 8.1.1 (`default-features = false`, `rust-tls`) | BitTorrent engine | Apache-2.0 |
| tokio | 1 (`rt-multi-thread`, `time`, `sync`, `macros`, `net`) | async runtime | MIT |
| serde, serde_json | 1 | JSON bridge, settings, state | MIT / Apache-2.0 |
| jni | 0.21 | JNI bindings (one function) | MIT / Apache-2.0 |
| sha1 | 0.10 | independent info-hash and piece verification in `torrent.rs` | MIT / Apache-2.0 |
| reqwest | 0.12 (`rustls-tls`, `json`, no default features) | search providers, `.torrent` downloads | MIT / Apache-2.0 |
| async-trait | 0.1 | `SearchProvider` trait objects | MIT / Apache-2.0 |
| roxmltree | 0.20 | Torznab XML | MIT / Apache-2.0 |
| log, tracing | 0.1 / 0.1 (`log`, `release_max_level_warn`) | in-app engine log; compile-time log filtering | MIT |
| libc | 0.2 (unix only) | `statvfs` free-space lookup | MIT / Apache-2.0 |

Transitive crypto: the `rust-tls` feature makes librqbit use `aws-lc-rs` for SHA-1 and `reqwest 0.12` uses
`ring` with bundled `webpki-roots` for TLS, so no OpenSSL is needed anywhere.

Every one of these APIs was used from documentation and from published crates that compile against
them; none has been compiled in this project yet.

## Android

| Library / tool | Version |
| --- | --- |
| Android Gradle Plugin | 8.5.2 |
| Gradle (wrapper `android/gradle/wrapper/gradle-wrapper.properties`; AGP 8.5 needs at least 8.7) | 8.7 |
| Kotlin | 1.9.24 |
| Compose BOM, compiler extension | 2024.06.00, 1.5.14 (Material 3 1.2.x, `material-icons-core`) |
| activity-compose | 1.9.0 |
| lifecycle-viewmodel-compose, lifecycle-runtime-compose | 2.8.2 |
| core-ktx | 1.13.1 |
| documentfile | 1.0.1 (Storage Access Framework) |
| kotlinx-coroutines-android | 1.8.1 |
| compileSdk / targetSdk / minSdk | 34 / 34 / 30 (Android 11) |
| NDK | r25c (25.2.9519653) |
| JDK | 17 (Temurin) |

All AndroidX libraries are Apache-2.0. JSON handling uses Android's built-in `org.json`; there are no other runtime libraries.

## Build tooling

`cargo-ndk` (cross-compilation driver), `dtolnay/rust-toolchain`, `Swatinem/rust-cache`,
`actions/checkout`, `actions/setup-java`, `actions/upload-artifact`, `gradle/actions/setup-gradle`
(major-version pins). `cmake`, `ninja` and `libclang` are installed on the runner for the C code inside `aws-lc-sys`.
