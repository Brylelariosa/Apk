# Architecture

## Layers

```
Compose UI (ui/*)              Home  Search  Downloads  Completed  Settings, add-torrent sheet
   |  StateFlow                 
MainViewModel                  add flow state, search state, user actions
   |
EngineController               one per process: boots the engine, polls snapshots, applies
   |                           settings and network changes, saves finished downloads (Exporter)
   |   DownloadService         foreground service: keeps the process alive, notification, wake lock
   |   NetworkMonitor          Wi-Fi / mobile / offline
   v
NativeBridge.nativeCall(method, json) -> json        the ONLY JNI function
   v
rust-engine  lib.rs            RPC dispatcher (panic-safe), runtime (2 worker threads)
   |-- engine.rs               Core: librqbit Session + Api, add-torrent flow, scheduler loop
   |-- download_manager.rs     plan(): queue/hold/network/seeding rules; parse_list(): view model
   |-- magnet.rs torrent.rs    validate input and metadata, verify pieces
   |-- storage.rs settings.rs state.rs logging.rs
   +-- torrix-search           providers, SearchManager
librqbit 8.1.1                 peer wire protocol, trackers, DHT, magnet metadata (BEP 9),
                               piece download + SHA-1 verification, resume, rate limits, persistence
```

The Kotlin side never touches protocol details; the Rust side never touches Android APIs. They
exchange JSON envelopes `{"ok":true,"data":...}` / `{"ok":false,"error":"..."}`, so the contract
is one function and a list of method names (see `dispatch` in `android/rust/rust-engine/src/lib.rs`).

## Mapping to the module list in the brief

| Brief | Here |
| --- | --- |
| `engine.rs`, `download_manager.rs`, `settings.rs`, `state.rs`, `storage.rs`, `magnet.rs`, `torrent.rs`, `ffi.rs`, `lib.rs` | same names |
| `peer.rs`, `tracker.rs`, `dht.rs` | provided by librqbit (`librqbit-peer-protocol`, `librqbit-tracker-comms`, `librqbit-dht`); Torrix adds tracker URL validation (`magnet.rs`), DHT configuration and persistence (`engine.rs::session_options`) |
| `search/src/{providers, search_manager.rs, models.rs}` | same, under `android/rust/search/` |

## Flow: adding a magnet link

1. UI calls `validate` (cheap, parses the input) then `add_start`. Rust creates a request id and spawns a task.
2. The task asks the engine for the torrent **without adding it** (`list_only`). Peers and DHT are
   contacted, the metadata is fetched (BEP 9) and hash-checked by the engine; a timeout (default 120 s) applies.
   The magnet is first extended with a short list of public trackers (`magnet::PUBLIC_TRACKERS`), so a link
   with no (working) tracker does not depend on the DHT alone. A lookup that has not answered after 25 s is
   dropped and a fresh one is started (then 35 s, then the rest of the timeout; `engine.rs::run_with_restarts`),
   because a lookup either answers within seconds or can sit idle until the timeout. `add_status` reports
   `elapsed_ms` and `attempt`, which the add sheet shows. Each lookup also writes one log line with the DHT's routing-table size
   (`add: lookup started (dht ...)`), so a log file shows whether the DHT was reachable when no peer answered.
3. Every file path in the metadata is validated (`storage::is_safe_relative_path`): absolute paths, `..`,
   empty components and backslashes reject the whole torrent. Sizes are summed with overflow checks.
4. UI polls `add_status` and shows the file list. The user picks files; free space is checked in
   Kotlin (`StatFs`) and again in Rust (`statvfs`).
5. `add_confirm` adds the torrent with `only_files` and `overwrite` to the staging directory. A user
   record (`state.json`) is created. For a magnet link the engine needs the metadata from peers once more
   here, so this step uses the same public trackers and fresh-lookup treatment as step 2. If the sheet is
   closed meanwhile, Kotlin keeps watching `add_status` and reports the outcome. `.torrent` URLs and imported
   files skip step 2: Torrix downloads (size capped) and parses them itself with `torrent.rs`.

## Flow: download lifecycle

* Every second (3 s in the background) the Rust loop reads the engine's torrent list with stats,
  builds the snapshot JSON the UI polls, and calls `plan()`.
* `plan()` is a pure function: oldest torrents get the free download slots; user-paused torrents ("hold")
  stay paused and use no slot; with the network gate closed nothing runs; finished torrents seed only
  if the setting says so; torrents that are still checking files are never interrupted.
* Speed limits are applied to the live session (`ratelimits`); DHT and port are session-creation options.
* ETA uses an exponential moving average and is only shown after five samples and a non-trivial speed.

## Flow: finished download

`EngineController` sees `finished` once per info hash (remembered in `torrix_handled`), asks the engine
for the file list, and `Exporter` streams each file (256 KiB blocks, cancellable) into
MediaStore `Download/Torrix/...` or the chosen SAF tree. Names are re-validated and the source path must
stay inside the staging directory. On success the torrent is removed from the engine with its files
(unless seeding), and a record is added to `completed.json`. On failure nothing is deleted.

## Persistence and crash safety

| What | Where | How |
| --- | --- | --- |
| Torrents, selected files, paused flag, piece bitfield | `files/engine/session/` | librqbit JSON persistence + fastresume |
| DHT routing table | `files/engine/dht.json` | librqbit, dumped every 5 min |
| User holds, added / completed times | `files/engine/state.json` | atomic write (temp file + fsync + rename); corrupt file is kept as `*.corrupt` |
| Engine settings | `files/engine/settings.json` | atomic write |
| UI settings, handled hashes | SharedPreferences | |
| Completed list | `files/completed.json` | temp file + rename |

Data goes to disk as pieces arrive (the engine writes at offsets; nothing is buffered in RAM beyond
in-flight pieces). A verified piece is on disk before it is marked as had, so killing the process loses at most
the pieces in flight.

## Threading and memory

* One Tokio runtime, 2 worker threads, at most 16 blocking threads (disk, hashing).
* JNI calls are short; `add_*` and `search` run in the background and are polled, `search` blocks its
  Kotlin IO thread for at most about 15 s.
* No file contents are held in memory by Torrix. The exporter uses one 256 KiB buffer.

## Failure handling

| Case | Behaviour |
| --- | --- |
| Malformed magnet / metadata | rejected with a message; no panic paths (`magnet.rs`, `torrent.rs` are tested against truncations and hostile input) |
| Panic inside the engine | caught at the JNI boundary, reported as an error; a panic in a background task ends only that task |
| Tracker down / peers drop | handled by the engine (retries, other trackers, DHT) |
| Provider down or slow | isolated per provider, shown in the search results, others still answer |
| Not enough space | checked before adding; errors from the engine show on the torrent; save failures keep the working copy |
| Network lost or metered | the network gate pauses torrents (debounced); they resume automatically |
| Process killed | service restarts, engine reloads its session, torrents resume |
| Hostile `.torrent` URLs | scheme check, size cap, no redirects onto local addresses, local-address URLs blocked |

The engine log (last 300 warnings/errors, no magnet links, keys or file names) is available in Settings, About.
