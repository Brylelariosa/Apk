# Torrix

A standalone Android BitTorrent client. The engine is Rust, the app is a thin Kotlin/Compose shell,
and **GitHub Actions builds the APK for you, so you never need a PC**.

* Real BitTorrent: magnet links, DHT, trackers, peer connections, piece download and SHA-1
  verification, resume, multi-file torrents, selective file download (engine: [librqbit](docs/DEPENDENCIES.md)).
* Built-in search over sources that publish legal torrents (Linux distributions, Internet Archive,
  and any Torznab indexer you add yourself) plus manual magnet / `.torrent` input.
* Download manager: queue, pause / resume / cancel, speed limits, per-torrent progress, peers, ETA,
  foreground service, Wi-Fi-only option, automatic resume after the app or phone restarts.
* Saves finished downloads without any storage permission (Downloads folder or a folder you pick).
* Home / Search / Downloads / Completed / Settings, light and dark themes.

> ## Read this first: status
>
> This project was written in an environment with **no Rust toolchain, no Android SDK and no
> internet access**, so **nothing in it has been compiled or run yet**. The first GitHub Actions run is
> the first real compile, and a first build with one or two small compile errors is realistic for
> ~8,000 lines of new code. If that happens, open the failed job, copy the error from the log and
> fix it (or send it to me): the code is split into small modules so fixes stay local.
>
> What *was* checked here: the librqbit API surface used by `engine.rs` was cross-checked against
> docs.rs and against two published crates that compile against it; the `.torrent` and base32
> test fixtures were generated independently with Python's `hashlib`/`base64`; all XML and the
> workflow YAML parse; all Rust and Kotlin files were checked for balanced delimiters.
>
> What was *not* checked: that the code compiles, that the 99 unit tests pass, that a download
> works on a device, how big the APK ends up, and behaviour on Android 11 or newer. Nothing
> in this README claims otherwise; see [Testing](#testing) for the manual device checklist.

## Build the APK (no PC)

1. Create a GitHub repository and put the contents of this folder in it (the `.github` folder must
   be at the top level). Pushing from any git client, GitHub Codespaces, or the web uploader all work.
2. Open **Actions → Build APK → Run workflow**. (It also runs on every push.)
3. Wait for the run (first run about 15 to 25 minutes, later runs are much faster because of caching).
4. Open the finished run and download the artifact **Torrix-arm64-v8a-apk**; unzip it and install the `.apk`.
   Allow "install unknown apps" for your browser or file manager when Android asks.
5. The same run also has **build-logs** (Rust and Gradle output) and **Cargo.lock**. The job
   summary shows the APK size, package info, signature, and the largest files inside the APK.

After the first successful run, **commit the `Cargo.lock` artifact** as `android/rust/Cargo.lock`. The
workflow then builds with `--locked`, which pins every Rust dependency and makes builds reproducible.
Everything else is already pinned (Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24, Compose BOM 2024.06.00,
NDK r25c, JDK 17). To pin Rust itself, replace `dtolnay/rust-toolchain@stable` with a version.

Two jobs run independently: **Rust tests (host)** runs `cargo test --workspace` (in `android/rust`), and
**Build APK** cross-compiles the engine with `cargo-ndk` for `arm64-v8a`, then runs Gradle.

### Building through a ZIP-to-APK workflow

Some workflows unzip a project from `uploads/`, find the Gradle project, build any Rust crate that
sits next to it with `cargo-ndk`, then run `./gradlew`. This project is laid out for that:

* The Gradle project is `android/` and contains `gradlew`, `gradlew.bat` and
  `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.7, which AGP 8.5 requires). The binary
  `gradle-wrapper.jar` is not stored here; such workflows download it, or run `gradle wrapper` once.
* The Rust workspace lives in `android/rust/`, so a `Cargo.toml` is found within two levels of the
  Gradle project. The native library must end up in `android/app/src/main/jniLibs/arm64-v8a/`.
* `ndkVersion` in `android/app/build.gradle.kts` is r25c (25.2.9519653); change it together with the
  NDK your build machine installs.
* Gradle does not build Rust. If `libtorrix_engine.so` is missing, the `checkEngineLib` task stops the
  build with a message instead of producing an APK that crashes on start.

## If the app crashes at start (no root, no PC)

Torrix writes its own log, so a crash can be found without `adb`, root or Shizuku. Every launch
creates `Download/Torrix-log-<date>-<time>.txt` (no storage permission is needed; the newest 10
files are kept; Settings, Log file turns this off). It holds device info, step-by-step start-up notes, the full stack trace of a
Kotlin/Java crash and, for a crash in native code, Android's own record of how the last run ended
plus this app's logcat. After a crash, open the app once more and send the newest file. Release
builds keep readable class names (`-dontobfuscate` in `proguard-rules.pro`) so the traces make sense.

## Using the app

* **Home**: live speeds, number of active torrents, quick magnet input, "Open .torrent file".
* **Search**: type a word; results come from the enabled sources. Tap a result for details, copy
  its magnet link, or download it. Unavailable sources are listed instead of failing the search.
* **Adding a torrent**: Torrix first fetches the file list (for magnet links this needs peers; most
  take a few seconds, and a lookup that gets no answer is restarted), shows it with checkboxes and the
  space needed, and only then downloads.
* **Magnet links and `.torrent` files from other apps** open Torrix directly.
* **Downloads / Completed**: pause, resume, remove (keep or delete files), and see where each
  finished torrent was saved.

### Where files go

Torrent data is downloaded into Torrix's private storage (fast, no permission needed). When a torrent
finishes, Torrix **copies it in 256 KiB blocks** to the place you chose in Settings and then frees the
working copy (unless "keep seeding" is on):

| Setting | Result | Permission |
| --- | --- | --- |
| Downloads folder (default) | `Downloads/Torrix/...` through MediaStore | none |
| Folder I choose | any folder picked with the Storage Access Framework (also SD cards) | none (the picker grants access) |
| Keep in app storage | stays private; use *Save to Downloads* on a finished torrent whenever you like | none |

Consequence to know about: while a torrent is being saved, its data exists twice for a moment, so very
large torrents on a nearly full phone can fail at the save step. The working copy is kept in that case and
**Try again** is offered. Android 11 and newer do not allow choosing the top-level `Download` folder in the
folder picker, which is why the Downloads folder is its own option.

### Search sources

| Source | What | Notes |
| --- | --- | --- |
| Linux distributions | Arch Linux release feed (JSON) and Debian `bt-cd` listings (amd64, arm64) | large, long-lived swarms |
| Internet Archive | public-domain and openly licensed media via the documented `advancedsearch` JSON API | many items are served mostly by *web seeds*, which the engine does not support, so they can be slow or stall |
| Torznab indexer | any Torznab-compatible indexer you configure (URL and API key in Settings) | Torrix ships no indexer; you are responsible for what you search for |

Nothing scrapes sites that forbid it. Each source is a separate module in `android/rust/search/src/providers/`; adding
another means implementing one trait. A manual magnet / `.torrent` URL input always works regardless of search.

### Background downloads and battery

* A foreground service (type `dataSync`) with a progress notification keeps downloads running while the app is minimised, and stops itself 20 s after there is nothing left to do.
* If Android kills the process, the service is restarted and the engine resumes from its on-disk state (session database plus piece bitfield). Verified pieces are never lost; at worst the piece that was in flight is fetched again.
* **Download on mobile data** (off by default) pauses everything on metered networks and resumes on Wi-Fi; switches are debounced.
* Optional wake lock while downloading; a shortcut to Android's battery optimisation settings. UI polling slows down when the app is in the background; the engine uses 2 worker threads.
* No storage, location, contacts or background-start permissions are requested. Permissions: internet, network state, foreground service (data sync), notifications, wake lock.

## APK size (single APK, no ABI splits)

There is deliberately **no `splits { abi { ... } }`**: CI produces one APK. It contains only `arm64-v8a`
(`ndk.abiFilters`), which is the requested first target; add ABIs to that filter later if you need them.

| Lever | Where |
| --- | --- |
| One ABI in the APK | `android/app/build.gradle.kts` |
| R8 shrink + optimise + obfuscate, resource shrinking | `isMinifyEnabled`, `isShrinkResources`, `proguard-android-optimize.txt` |
| Native library compressed inside the APK | `packaging.jniLibs.useLegacyPackaging = true` (about half the size in the APK; it is extracted on install, so installed size is larger) |
| Rust: `opt-level = "z"`, fat LTO, 1 codegen unit, stripped symbols | `android/rust/Cargo.toml` |
| Rust: log call sites below *warn* removed from every dependency | `tracing` feature `release_max_level_warn` |
| Rust: no OpenSSL, no HTTP server / web UI / database in the engine | `librqbit` with `default-features = false, features = ["rust-tls"]` |
| Only English strings from AndroidX libraries | `resourceConfigurations` |
| Own 4 vector icons instead of `material-icons-extended`; vector launcher icon, no PNGs, no font files | `ui/Icons.kt`, `res/` |
| No licence/`kotlin_module` files, no dependency-metadata block, no Kotlin null-check intrinsics | `packaging.resources.excludes`, `dependenciesInfo`, `-Xno-*-assertions` |
| No analytics, ads or third-party SDKs | |

I could not measure the result here; the workflow prints the exact size and the biggest entries in every
run's summary so you can see where the bytes are. If you want it smaller still: `panic = "abort"` in
`android/rust/Cargo.toml` saves a few percent but turns any panic inside one background task into an app crash
(it is off on purpose), and `opt-level = "s"` trades size for speed.

## Signing

Every build is signed with `android/app/torrix-debug.keystore`, a **public throw-away development key**
(password `torrix-dev`) so each CI build is installable and can update the previous one. Do not publish
apps signed with it. To use your own key, add repository secrets `TORRIX_KEYSTORE_BASE64`
(`base64 -w0 my.keystore`), `TORRIX_KEYSTORE_PASSWORD`, `TORRIX_KEY_ALIAS`, `TORRIX_KEY_PASSWORD`.
A PKCS12 keystore (the `keytool` default) is expected; set the `TORRIX_KEYSTORE_TYPE` environment
variable in the workflow for another type.

## Repository layout

```
android/                   Gradle project (gradlew, gradle/wrapper, settings.gradle.kts)
android/app/               Kotlin + Compose app (engine controller, foreground service, exporter, UI)
android/rust/Cargo.toml    Rust workspace + size-first release profile
android/rust/rust-engine/src/   engine (cdylib libtorrix_engine.so)
  lib.rs                   JSON RPC dispatcher, runtime, panic-safe entry point
  ffi.rs                   the single JNI function
  engine.rs                librqbit session wrapper, add-torrent flow, scheduler loop
  download_manager.rs      queue rules + snapshot building (pure, unit-tested)
  magnet.rs  torrent.rs    magnet and .torrent parsing / validation / piece verification
  storage.rs settings.rs state.rs logging.rs
android/rust/search/src/   search crate: models, search_manager, providers/{internet_archive,linux_distros,torznab}
.github/workflows/         build-apk.yml
docs/                      ARCHITECTURE.md, DEPENDENCIES.md
```

The layout suggested in the brief (`peer.rs`, `tracker.rs`, `dht.rs`, ...) assumed a hand-written
protocol stack; those parts are provided by librqbit's crates instead, and the mapping is in
[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md). Writing a new BitTorrent implementation from scratch,
unverifiable here, would have been far riskier than using a mature one.

## Testing

`cd android/rust && cargo test --workspace` runs 99 unit tests (written, **not yet executed**). They cover:

| Area | Tests |
| --- | --- |
| Magnet parsing | `magnet.rs`: hex and base32 hashes (checked against Python), encoded colons, v2-only links, tracker filtering and caps, name cleaning, round trip, input classification, SSRF-style host checks |
| Torrent metadata | `torrent.rs`: single and multi-file fixtures with an independently computed info hash, every truncation, path traversal, bad piece counts, bencode edge cases |
| Piece verification | `torrent.rs`: every piece of the fixtures verifies; flipped bits, short data, wrong piece and bad index fail; SHA-1 vectors |
| State persistence | `state.rs`, `settings.rs`: round trip, missing / corrupt / older files, atomic writes |
| Pause and resume, queueing | `download_manager.rs`: limit and ordering, user holds, network gate, seeding rules, checking torrents, failed torrents |
| Storage | `storage.rs`: path sanitising and traversal, free space, atomic writes |
| Peer discovery | tracker URL filtering and peer-count parsing are unit-tested; the DHT and tracker protocols themselves belong to librqbit and need a network to test |
| Search provider failures | `search_manager.rs`: failing, hanging and panicking providers are isolated; bad queries; ordering; each provider's parser against sample payloads |
| Large files | `torrent.rs`: 9 GiB and 2 TiB torrents, u64 overflow rejection; `storage.rs`: sizes above 4 GiB |

**Android 11+ device checklist (not done yet):** install on an Android 11 phone; add a Debian netinst
`.torrent` from Search; check the file list sheet, progress, pause / resume, notification buttons;
turn on Airplane mode and back; force-stop the app mid-download and reopen it; finish a download and
confirm the file in Files under Downloads/Torrix; pick a folder in Settings and repeat; add a magnet link by tapping one in a browser.

## Known limitations

* **Seeder counts**: a swarm does not report how many peers are seeds without asking trackers, so the UI shows peers *connected / seen*. Search results show seeders when the source provides them (Torznab).
* The pinned engine (librqbit 8.1.1) speaks TCP; it has no uTP, WebRTC or web-seed support.
* DHT on/off and the listening port apply at the next start; speed limits, queue size and the Wi-Fi rule apply immediately.
* IPv4/IPv6 behaviour, carrier NAT and tracker availability decide how fast a swarm connects; Torrix cannot change that.
* There is **no connection-limit setting**: the pinned engine API surface used here does not expose a per-torrent peer cap, so parallelism is limited through the queue size instead.
* Torrix does **not** auto-pause on low battery or Battery Saver. It pauses on its network rule, respects Android's background limits through the foreground service, and shows disk-full errors on the torrent.
* `.torrent` files are limited to 8 MiB; links that point at local-network addresses are blocked (except your own indexer's host).

## Legal

Torrix is a general-purpose BitTorrent client. It does not circumvent DRM or bundle a piracy index.
Only download and share content you have the right to, such as open-source software, public-domain
works and files you have permission to use.

MIT licensed (see `LICENSE`); third-party licences are listed in `docs/DEPENDENCIES.md`.
