plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.torrix.app"
    compileSdk = 34
    // Must be an NDK the build machine actually has: the CI installs r25c and exports
    // ANDROID_NDK_HOME for cargo-ndk. Gradle compiles nothing with it (the Rust library is
    // prebuilt, AGP only strips/packages it), but a version that is not installed makes AGP
    // try to download a ~1 GB NDK.
    ndkVersion = "25.2.9519653"

    defaultConfig {
        applicationId = "com.torrix.app"
        minSdk = 30            // Android 11: scoped storage is always enforced
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"

        // One APK containing one ABI. There are deliberately NO `splits { abi { } }`:
        // the CI produces a single installable file. arm64-v8a first, as requested.
        ndk { abiFilters += "arm64-v8a" }

        // The UI is English only; drop the translations that AndroidX libraries ship.
        resourceConfigurations += setOf("en")
    }

    signingConfigs {
        // Defaults to the throw-away dev key committed next to this file so every
        // CI build is installable and can update the previous one. Provide your own
        // key through the TORRIX_* environment variables (see README) for real use.
        fun env(name: String, default: String): String =
            System.getenv(name)?.takeIf { it.isNotBlank() } ?: default

        create("torrix") {
            storeFile = file(env("TORRIX_KEYSTORE", "torrix-debug.keystore"))
            storeType = env("TORRIX_KEYSTORE_TYPE", "pkcs12")
            storePassword = env("TORRIX_KEYSTORE_PASSWORD", "torrix-dev")
            keyAlias = env("TORRIX_KEY_ALIAS", "torrix")
            keyPassword = env("TORRIX_KEY_PASSWORD", "torrix-dev")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true        // R8: shrink, optimize, obfuscate
            isShrinkResources = true      // drop unused resources
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
            signingConfig = signingConfigs.getByName("torrix")
        }
        debug {
            signingConfig = signingConfigs.getByName("torrix")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-Xno-param-assertions",
            "-Xno-call-assertions",
            "-Xno-receiver-assertions",
        )
    }

    buildFeatures {
        compose = true
        buildConfig = false
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"   // matches Kotlin 1.9.24
    }

    packaging {
        // Compress the native library inside the APK. The APK is roughly half the
        // size; the library is extracted on install (a bit more storage once installed).
        jniLibs { useLegacyPackaging = true }
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*",
                "/META-INF/DEPENDENCIES",
                "/META-INF/*.kotlin_module",
                "/kotlin/**",
                "DebugProbesKt.bin",
                "kotlin-tooling-metadata.json",
            )
        }
    }

    // Dependency metadata blob inside the APK: not needed for sideloading.
    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

// ---------------------------------------------------------------------------------------
// The native engine (libtorrix_engine.so) is NOT built by Gradle. cargo-ndk builds it from
// android/rust before Gradle runs and puts it in src/main/jniLibs (see README, "Build").
// Without it the APK installs fine but crashes the moment the app starts, so stop the
// build with a clear message instead of producing that APK.
// ---------------------------------------------------------------------------------------
val engineLib = layout.projectDirectory.file("src/main/jniLibs/arm64-v8a/libtorrix_engine.so").asFile
val checkEngineLib = tasks.register("checkEngineLib") {
    val lib = engineLib
    doLast {
        if (!lib.isFile) {
            throw GradleException(
                "Native engine missing: $lib does not exist.\n" +
                    "libtorrix_engine.so must be built from android/rust with cargo-ndk before Gradle runs, e.g.\n" +
                    "  cd android/rust && cargo ndk --target arm64-v8a --platform 30 " +
                    "--output-dir ../app/src/main/jniLibs build --release\n" +
                    "In CI that is the workflow's Rust step - look at that step's log.",
            )
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(checkEngineLib) }

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    implementation("androidx.activity:activity-compose:1.9.0")
    // NOTE: lifecycle 2.8.x needs Compose UI 1.7+ (BOM 2024.09+). With BOM 2024.06 the call
    // collectAsStateWithLifecycle() crashes at start ("CompositionLocal LocalLifecycleOwner not
    // present"), so the UI uses collectAsState() instead. Move the BOM and lifecycle together.
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
