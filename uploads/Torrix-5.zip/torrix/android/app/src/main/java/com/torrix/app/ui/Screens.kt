package com.torrix.app.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.collectAsState
import com.torrix.app.engine.Fmt
import com.torrix.app.engine.Snapshot
import com.torrix.app.engine.TorrentItem
import com.torrix.app.storage.CompletedItem
import java.text.DateFormat
import java.util.Date

// ------------------------------------------------------------------- Home

@Composable
fun HomeScreen(vm: MainViewModel, onPickTorrent: () -> Unit, modifier: Modifier = Modifier) {
    val snap by vm.engine.snapshot.collectAsState()
    var input by rememberSaveable { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    val focus = LocalFocusManager.current
    val active = snap.torrents.filter { !it.finished }

    fun submit() {
        focus.clearFocus()
        vm.beginAdd(input)
        input = ""
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item(key = "hero") { Hero(snap) }
        item(key = "add") {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Magnet link or .torrent address") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { submit() }),
                    trailingIcon = {
                        IconButton(onClick = { submit() }) {
                            Icon(Icons.Filled.Add, contentDescription = "Add")
                        }
                    },
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = {
                        val text = clipboard.getText()?.text
                        if (text.isNullOrBlank()) vm.say("The clipboard is empty.") else input = text
                    }) { Text("Paste") }
                    TextButton(onClick = onPickTorrent) { Text("Open .torrent file") }
                }
            }
        }
        item(key = "title") { SectionTitle("Active downloads") }
        if (active.isEmpty()) {
            item(key = "empty") {
                EmptyState(
                    "Nothing downloading",
                    "Paste a magnet link above, or use Search to find something you are allowed to download.",
                )
            }
        } else {
            items(active.take(6), key = { it.hash }) { t ->
                TorrentCard(
                    t,
                    onTogglePause = { if (t.hold) vm.resume(t.hash) else vm.pause(t.hash) },
                    onClick = { vm.tab.value = Tab.DOWNLOADS },
                )
            }
            if (active.size > 6) {
                item(key = "more") {
                    TextButton(onClick = { vm.tab.value = Tab.DOWNLOADS }) { Text("Show all ${active.size}") }
                }
            }
        }
    }
}

@Composable
private fun Hero(s: Snapshot) {
    val on = MaterialTheme.colorScheme.onPrimaryContainer
    Card(
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Column {
                Text("Download speed", style = MaterialTheme.typography.labelLarge, color = on.copy(alpha = 0.75f))
                Text(
                    Fmt.speed(s.totals.downBps),
                    style = MaterialTheme.typography.headlineMedium.merge(NumberStyle).copy(fontSize = 34.sp),
                    color = on,
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                HeroStat("Upload speed", Fmt.speed(s.totals.upBps))
                HeroStat("Active torrents", "${s.totals.downloading}")
                HeroStat("Queued", "${s.totals.queued}")
            }
        }
    }
}

@Composable
private fun HeroStat(label: String, value: String) {
    val on = MaterialTheme.colorScheme.onPrimaryContainer
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = on.copy(alpha = 0.75f))
        Text(value, style = MaterialTheme.typography.titleMedium.merge(NumberStyle), color = on)
    }
}

// -------------------------------------------------------------- Downloads

@Composable
fun DownloadsScreen(vm: MainViewModel, modifier: Modifier = Modifier) {
    val snap by vm.engine.snapshot.collectAsState()
    val unfinished = snap.torrents.filter { !it.finished }
    var removing by remember { mutableStateOf<TorrentItem?>(null) }
    val anyRunning = unfinished.any { !it.hold }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, top = 16.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Downloads", style = MaterialTheme.typography.titleLarge)
                Text(
                    "${unfinished.size} in progress",
                    style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            if (unfinished.isNotEmpty()) {
                TextButton(onClick = { if (anyRunning) vm.pauseAll() else vm.resumeAll() }) {
                    Text(if (anyRunning) "Pause all" else "Resume all")
                }
            }
        }
        if (!snap.networkAllowed && unfinished.isNotEmpty()) {
            Card(
                modifier = Modifier.padding(start = 16.dp, top = 12.dp, end = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            ) {
                Text(
                    "Downloads are waiting for a usable connection. To download on mobile data, turn it on in Settings.",
                    modifier = Modifier.padding(14.dp),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                )
            }
        }
        if (unfinished.isEmpty()) {
            EmptyState(
                "No active downloads",
                "Finished downloads are in the Completed tab.",
                Modifier.padding(horizontal = 4.dp),
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(unfinished, key = { it.hash }) { t ->
                    TorrentCard(
                        t,
                        onTogglePause = { if (t.hold) vm.resume(t.hash) else vm.pause(t.hash) },
                        onRemove = { removing = t },
                    )
                }
            }
        }
    }

    removing?.let { t ->
        RemoveDialog(
            name = t.name,
            onKeep = { vm.remove(t.hash, false); removing = null },
            onDelete = { vm.remove(t.hash, true); removing = null },
            onCancel = { removing = null },
        )
    }
}

@Composable
fun RemoveDialog(name: String, onKeep: () -> Unit, onDelete: () -> Unit, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Remove this torrent?") },
        text = {
            Text(
                "$name\n\nKeep the downloaded data if you may want it again, or delete it to free space.",
                style = MaterialTheme.typography.bodyMedium,
            )
        },
        confirmButton = {
            TextButton(onClick = onDelete) {
                Text("Delete files", color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onCancel) { Text("Cancel") }
                TextButton(onClick = onKeep) { Text("Keep files") }
            }
        },
    )
}

// -------------------------------------------------------------- Completed

private data class DoneRow(
    val hash: String,
    val name: String,
    val size: Long,
    val whenMs: Long,
    val where: String,
    val staged: TorrentItem?,
    val saved: CompletedItem?,
)

private fun formatWhen(ms: Long): String =
    if (ms <= 0L) "" else DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))

@Composable
fun CompletedScreen(vm: MainViewModel, modifier: Modifier = Modifier) {
    val snap by vm.engine.snapshot.collectAsState()
    val saved by vm.engine.completed.items.collectAsState()
    val exports by vm.engine.exports.collectAsState()
    val ctx = LocalContext.current
    var removing by remember { mutableStateOf<TorrentItem?>(null) }

    val savedByHash = saved.associateBy { it.hash }
    val liveHashes = snap.torrents.map { it.hash }.toSet()
    val rows = buildList<DoneRow> {
        for (t in snap.torrents.filter { it.finished }) {
            val s = savedByHash[t.hash]
            add(DoneRow(t.hash, t.name, t.totalBytes, t.completedMs ?: 0L, s?.location ?: "App storage", t, s))
        }
        for (s in saved) {
            if (s.hash !in liveHashes) add(DoneRow(s.hash, s.name, s.sizeBytes, s.completedMs, s.location, null, s))
        }
    }.sortedByDescending { it.whenMs }

    Column(modifier.fillMaxSize()) {
        Column(Modifier.padding(start = 16.dp, top = 16.dp, end = 16.dp)) {
            Text("Completed", style = MaterialTheme.typography.titleLarge)
            Text(
                "${rows.size} finished",
                style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (rows.isEmpty()) {
            EmptyState("Nothing here yet", "Finished downloads show up here, with where they were saved.", Modifier.padding(horizontal = 4.dp))
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(rows, key = { it.hash }) { row ->
                    val export = exports[row.hash]
                    Card(
                        modifier = Modifier.fillMaxWidth().animateContentSize(),
                        shape = MaterialTheme.shapes.medium,
                        colors = flatCardColors(),
                        border = flatBorder(),
                    ) {
                        Column(Modifier.padding(start = 14.dp, top = 12.dp, end = 8.dp, bottom = 6.dp)) {
                            Text(row.name, style = MaterialTheme.typography.titleMedium, maxLines = 2)
                            Text(
                                "${Fmt.bytes(row.size)} · ${row.where}",
                                style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
                                color = MaterialTheme.colorScheme.tertiary,
                            )
                            val whenText = formatWhen(row.whenMs)
                            if (whenText.isNotEmpty()) {
                                Text(
                                    whenText,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            if (export != null && export.running) {
                                val p = if (export.totalBytes > 0) export.copiedBytes.toFloat() / export.totalBytes else 0f
                                Text(
                                    "Saving ${Fmt.percent(p)}",
                                    style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
                                    color = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.padding(top = 6.dp),
                                )
                                PieceBar(p, Modifier.padding(top = 4.dp, end = 6.dp), active = true)
                            }
                            if (export != null && !export.running && export.error != null) {
                                Text(
                                    export.error,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.padding(top = 6.dp, end = 6.dp),
                                )
                            }
                            Row {
                                val canOpen = row.saved?.uri != null || row.staged != null
                                if (canOpen) {
                                    TextButton(onClick = {
                                        val s = row.saved
                                        if (s != null && s.uri != null) vm.openCompleted(ctx, s)
                                        else if (row.staged != null) vm.openStaged(ctx, row.staged)
                                    }) { Text("Open") }
                                }
                                val saving = export?.running == true
                                if (row.staged != null && row.saved == null && !saving) {
                                    if (export?.error != null) {
                                        TextButton(onClick = { vm.saveFinished(row.hash) }) { Text("Try again") }
                                    }
                                    TextButton(onClick = { vm.saveToDownloads(row.hash) }) { Text("Save to Downloads") }
                                }
                                if (row.staged != null && row.saved != null) {
                                    TextButton(onClick = { vm.remove(row.hash, true) }) { Text("Stop seeding") }
                                } else if (row.staged != null) {
                                    TextButton(onClick = { removing = row.staged }) { Text("Remove") }
                                } else {
                                    TextButton(onClick = { vm.removeCompleted(row.hash) }) { Text("Remove from list") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    removing?.let { t ->
        RemoveDialog(
            name = t.name,
            onKeep = { vm.remove(t.hash, false); removing = null },
            onDelete = { vm.remove(t.hash, true); removing = null },
            onCancel = { removing = null },
        )
    }
}
