package com.torrix.app.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * The few icons that are not in material-icons-core, drawn as plain polygons.
 * (The extended icon set would add megabytes of classes for a handful of shapes.)
 */
object TorrixIcons {

    private fun icon(
        name: String,
        fillType: PathFillType = PathFillType.NonZero,
        build: PathBuilder.() -> Unit,
    ): ImageVector = ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
    ).path(fill = SolidColor(Color.Black), pathFillType = fillType, pathBuilder = build).build()

    val Pause: ImageVector by lazy {
        icon("Pause") {
            moveTo(6f, 5f); horizontalLineTo(10f); verticalLineTo(19f); horizontalLineTo(6f); close()
            moveTo(14f, 5f); horizontalLineTo(18f); verticalLineTo(19f); horizontalLineTo(14f); close()
        }
    }

    val Download: ImageVector by lazy {
        icon("Download") {
            moveTo(11f, 4f); horizontalLineTo(13f); verticalLineTo(13f); horizontalLineTo(11f); close()
            moveTo(6.5f, 11.5f); lineTo(17.5f, 11.5f); lineTo(12f, 17.5f); close()
            moveTo(5f, 19f); horizontalLineTo(19f); verticalLineTo(21f); horizontalLineTo(5f); close()
        }
    }

    val Folder: ImageVector by lazy {
        icon("Folder") {
            moveTo(3f, 6f); horizontalLineTo(10f); lineTo(12f, 8f); horizontalLineTo(21f)
            verticalLineTo(19f); horizontalLineTo(3f); close()
        }
    }

    /** Two overlapping sheets, drawn as outlines with the even-odd rule. */
    val Copy: ImageVector by lazy {
        icon("Copy", PathFillType.EvenOdd) {
            moveTo(8f, 3f); horizontalLineTo(20f); verticalLineTo(17f); horizontalLineTo(8f); close()
            moveTo(10f, 5f); verticalLineTo(15f); horizontalLineTo(18f); verticalLineTo(5f); close()
            moveTo(4f, 7f); horizontalLineTo(6f); verticalLineTo(19f); horizontalLineTo(16f)
            verticalLineTo(21f); horizontalLineTo(4f); close()
        }
    }
}
