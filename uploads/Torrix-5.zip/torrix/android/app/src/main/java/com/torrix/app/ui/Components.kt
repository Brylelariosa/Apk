package com.torrix.app.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.torrix.app.engine.Fmt
import com.torrix.app.engine.TorrentItem

/**
 * Progress drawn as a row of pieces: cobalt = verified, amber = the piece that
 * is still arriving, green = finished. Fills with a short animation.
 */
@Composable
fun PieceBar(
    progress: Float,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    complete: Boolean = false,
    segments: Int = 36,
    height: Dp = 8.dp,
) {
    val colors = LocalPieceColors.current
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "pieces",
    )
    Canvas(modifier = modifier.fillMaxWidth().height(height)) {
        val gap = 2.dp.toPx()
        val segW = (size.width - gap * (segments - 1)) / segments
        val radius = CornerRadius(2.dp.toPx())
        val filled = animated * segments
        for (i in 0 until segments) {
            val x = i * (segW + gap)
            drawRoundRect(
                color = colors.track,
                topLeft = Offset(x, 0f),
                size = Size(segW, size.height),
                cornerRadius = radius,
            )
            val frac = (filled - i).coerceIn(0f, 1f)
            if (frac > 0f) {
                val c: Color = when {
                    complete -> colors.done
                    frac < 1f && active -> colors.inflight
                    else -> colors.verified
                }
                drawRoundRect(
                    color = c,
                    topLeft = Offset(x, 0f),
                    size = Size(segW * frac, size.height),
                    cornerRadius = radius,
                )
            }
        }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onBackground,
    )
}

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 28.dp, horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(value, style = MaterialTheme.typography.titleMedium.merge(NumberStyle))
    }
}

@Composable
fun flatCardColors() = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)

@Composable
fun flatBorder() = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)

fun statusLine(t: TorrentItem): String {
    val pct = Fmt.percent(t.progress)
    return when (t.state) {
        "checking" -> "Checking files · $pct"
        "downloading" -> "Downloading · $pct · ${Fmt.bytes(t.doneBytes)} of ${Fmt.bytes(t.totalBytes)}"
        "queued" -> "Queued · $pct of ${Fmt.bytes(t.totalBytes)}"
        "waiting_network" -> "Waiting for network · $pct"
        "paused" -> "Paused · $pct · ${Fmt.bytes(t.doneBytes)} of ${Fmt.bytes(t.totalBytes)}"
        "seeding" -> "Seeding · ${Fmt.bytes(t.totalBytes)}"
        "complete" -> "Complete · ${Fmt.bytes(t.totalBytes)}"
        "error" -> t.error ?: "Something went wrong"
        else -> t.state
    }
}

@Composable
private fun statusColor(t: TorrentItem): Color = when (t.state) {
    "error" -> MaterialTheme.colorScheme.error
    "downloading", "checking" -> MaterialTheme.colorScheme.primary
    "seeding", "complete" -> MaterialTheme.colorScheme.tertiary
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}

/**
 * One torrent: name, state, piece bar, and the numbers that matter. Seeder
 * counts are not available from a BitTorrent swarm without asking trackers,
 * so peers are shown as "connected / seen".
 */
@Composable
fun TorrentCard(
    t: TorrentItem,
    modifier: Modifier = Modifier,
    onTogglePause: (() -> Unit)? = null,
    onRemove: (() -> Unit)? = null,
    onClick: (() -> Unit)? = null,
) {
    val shape = MaterialTheme.shapes.medium
    val clickMod = if (onClick != null) Modifier.clip(shape).clickable(onClick = onClick) else Modifier
    Card(
        modifier = modifier.then(clickMod).animateContentSize(),
        shape = shape,
        colors = flatCardColors(),
        border = flatBorder(),
    ) {
        Column(Modifier.padding(start = 14.dp, top = 12.dp, end = 6.dp, bottom = 14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f).padding(top = 4.dp, end = 8.dp)) {
                    Text(
                        t.name,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        statusLine(t),
                        style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
                        color = statusColor(t),
                    )
                }
                if (onTogglePause != null && !t.finished) {
                    IconButton(onClick = onTogglePause) {
                        Icon(
                            if (t.hold) Icons.Filled.PlayArrow else TorrixIcons.Pause,
                            contentDescription = if (t.hold) "Resume" else "Pause",
                        )
                    }
                }
                if (onRemove != null) {
                    IconButton(onClick = onRemove) {
                        Icon(Icons.Filled.Close, contentDescription = "Remove")
                    }
                }
            }
            Column(Modifier.padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PieceBar(
                    progress = t.progress,
                    active = t.state == "downloading",
                    complete = t.finished,
                )
                if (t.state == "downloading" || t.state == "seeding" || t.state == "checking") {
                    Text(
                        "Down ${Fmt.speed(t.downBps)}   Up ${Fmt.speed(t.upBps)}",
                        style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    val eta = Fmt.eta(t.etaSecs)
                    val peers = "Peers ${t.peersLive} connected, ${t.peersSeen} seen"
                    Text(
                        if (eta != null) "$peers   About $eta left" else peers,
                        style = MaterialTheme.typography.bodySmall.merge(NumberStyle),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
