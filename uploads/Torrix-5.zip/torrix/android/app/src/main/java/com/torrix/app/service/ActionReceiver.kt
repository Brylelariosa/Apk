package com.torrix.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.torrix.app.TorrixApp
import kotlinx.coroutines.launch

/** Handles the "Pause all" / "Resume all" buttons of the download notification. */
class ActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val engine = (context.applicationContext as TorrixApp).engine
        when (intent.action) {
            Notifier.ACTION_PAUSE_ALL -> engine.scope.launch { runCatching { engine.pauseAll() } }
            Notifier.ACTION_RESUME_ALL -> engine.scope.launch { runCatching { engine.resumeAll() } }
        }
    }
}
