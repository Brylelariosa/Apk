package com.torrix.app.diag

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.app.Application
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.system.Os
import android.system.OsConstants
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/**
 * A log that needs no root, no Shizuku and no PC.
 *
 * Every launch creates `Download/Torrix-log-<date>-<time>.txt` through MediaStore (no storage
 * permission is needed). The newest [KEEP_FILES] files are kept. A file holds:
 *  - device and app info,
 *  - what Android recorded about how the previous runs ended (this is the only way to see a
 *    native crash, which no Java handler can catch),
 *  - the notes the previous run wrote before it died,
 *  - this app's logcat (it includes the previous run),
 *  - the notes of this run, and the full stack trace of an uncaught Kotlin/Java exception.
 *
 * Saving the file to Download can be turned off in Settings ([setPublicLogEnabled]). Then no file
 * is created there; the small private log in the app's own storage (replaced on every launch,
 * unreadable for other apps) is always kept.
 *
 * Everything here is best effort and swallows its own errors: the logger must never be the
 * reason the app crashes. Never put magnet links, keys or file names in a note.
 */
object CrashLog {

    private const val TAG = "Torrix"
    private const val FILE_PREFIX = "Torrix-log-"
    private const val KEEP_FILES = 10
    private const val PRIVATE_NAME = "torrix-last-run.log"
    private const val MAX_PREVIOUS_RUN_BYTES = 120_000
    private const val MAX_LOGCAT_CHARS = 250_000
    private const val MAX_TRACE_BYTES = 60_000

    /** Same preferences file as the app settings; the switch is read before any settings object exists. */
    private const val PREFS = "torrix_settings"
    private const val PREF_PUBLIC_LOG = "saveLogToDownloads"
    private const val OFF_LOCATION = "not saved (turned off in Settings)"

    /** ApplicationExitInfo reasons that mean "the last run did not end normally". */
    private val ABNORMAL_EXITS = setOf(0, 2, 3, 4, 5, 6, 7, 9, 12)

    private val lock = Any()
    private val clock = DateTimeFormatter.ofPattern("HH:mm:ss.SSS", Locale.US)
    private val fileClock = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss", Locale.US)
    private val startupDone = CountDownLatch(1)
    private val switchLock = Any()

    @Volatile
    private var installed = false

    @Volatile
    private var latestExitReason = -1

    private var publicOut: OutputStream? = null
    private var privateOut: OutputStream? = null
    private var location = "nowhere (no log file could be created)"

    // ------------------------------------------------------------------ public API

    /** Call once, as early as possible (Application.attachBaseContext). Never throws. */
    fun install(app: Application) {
        if (installed) return
        installed = true
        var previousRun = ""
        try {
            previousRun = readPrivateLog(app)
            privateOut = openPrivateStream(app)
            if (isPublicLogEnabled(app)) openPublicStream(app) else location = OFF_LOCATION
            write(header(app))
            write("\n==================== HOW EARLIER RUNS ENDED (recorded by Android) ====================\n", false)
            write(exitReport(app), false)
            if (previousRun.isNotBlank()) {
                write("\n==================== NOTES WRITTEN BY THE PREVIOUS RUN ====================\n", false)
                write(previousRun, false)
                write("\n==================== END OF THE PREVIOUS RUN ====================\n", false)
            }
            write("\n==================== THIS RUN ====================\n")
        } catch (t: Throwable) {
            Log.e(TAG, "log setup failed", t)
        }
        installHandler()
        startLogcatThread(app)
    }

    /** One short line: what is happening now. Goes to the file and to logcat. */
    fun note(message: String) {
        try {
            Log.i(TAG, message)
            write(stamp() + " [" + Thread.currentThread().name + "] " + message + "\n")
        } catch (_: Throwable) {
        }
    }

    /** Same, with the stack trace of [error]. */
    fun note(message: String, error: Throwable) {
        try {
            Log.e(TAG, message, error)
            write(stamp() + " [" + Thread.currentThread().name + "] " + message + "\n" + Log.getStackTraceString(error) + "\n")
        } catch (_: Throwable) {
        }
    }

    /** Wait (at most [timeoutMs]) until the start-up report has been written. */
    fun awaitStartup(timeoutMs: Long) {
        if (!installed) return
        try {
            startupDone.await(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
        }
    }

    /** Whether a copy of the log is saved in the public Download folder. On unless turned off. */
    fun isPublicLogEnabled(context: Context): Boolean {
        return try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(PREF_PUBLIC_LOG, true)
        } catch (_: Throwable) {
            true
        }
    }

    /**
     * Turns the Download-folder copy on or off right away and remembers the choice for the next
     * launches. Off: the current file is closed and no new one is created. On: a new file is
     * created and starts with the notes of this run so far.
     */
    fun setPublicLogEnabled(app: Application, enabled: Boolean) {
        try {
            app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(PREF_PUBLIC_LOG, enabled)
                .apply()
        } catch (_: Throwable) {
        }
        if (!installed) return
        try {
            // File work stays off the main thread. The stored choice is read again inside, so
            // quick flips of the switch always end in the state the person left it in.
            val worker = Thread({
                try {
                    synchronized(switchLock) {
                        if (isPublicLogEnabled(app)) startPublicCopy(app) else stopPublicCopy()
                    }
                } catch (t: Throwable) {
                    Log.e(TAG, "could not switch the Download log", t)
                }
            }, "torrix-log-switch")
            worker.isDaemon = true
            worker.start()
        } catch (_: Throwable) {
        }
    }

    private fun stopPublicCopy() {
        if (synchronized(lock) { publicOut == null }) return
        note("saving the log to the Download folder was turned off in Settings")
        synchronized(lock) {
            try {
                publicOut?.flush()
                publicOut?.close()
            } catch (_: Throwable) {
            }
            publicOut = null
            location = OFF_LOCATION
        }
    }

    private fun startPublicCopy(app: Application) {
        val opened = synchronized(lock) {
            if (publicOut != null) {
                false
            } else {
                openPublicStream(app)
                publicOut != null
            }
        }
        if (!opened) return
        write(header(app), false)
        write("\n==================== LOG TURNED ON IN SETTINGS: THE NOTES OF THIS RUN SO FAR ====================\n", false)
        write(readPrivateLog(app), false)
        write("\n==================== THIS RUN (continued) ====================\n", false)
        pruneOldLogs(app)
    }

    // ------------------------------------------------------------------ crash handler

    private fun installHandler() {
        try {
            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, error ->
                try {
                    reportCrash(thread, error)
                } catch (_: Throwable) {
                }
                if (previous != null) {
                    previous.uncaughtException(thread, error)
                } else {
                    android.os.Process.killProcess(android.os.Process.myPid())
                    exitProcess(10)
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "could not install the crash handler", t)
        }
    }

    private fun reportCrash(thread: Thread, error: Throwable) {
        // Let a still-running start-up report finish so the file is complete.
        try {
            startupDone.await(2500, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
        }
        val rt = Runtime.getRuntime()
        val usedMb = (rt.totalMemory() - rt.freeMemory()) / 1_048_576
        val maxMb = rt.maxMemory() / 1_048_576
        val sb = StringBuilder()
        sb.append("\n==================== UNCAUGHT EXCEPTION ====================\n")
        sb.append("time:   ").append(stamp()).append('\n')
        sb.append("thread: ").append(thread.name).append('\n')
        sb.append("heap:   ").append(usedMb).append(" MB used of ").append(maxMb).append(" MB\n\n")
        sb.append(Log.getStackTraceString(error))
        sb.append("\n==================== END OF THE CRASH REPORT ====================\n")
        write(sb.toString())
    }

    // ------------------------------------------------------------------ files

    private fun stamp(): String = LocalDateTime.now().format(clock)

    private fun write(text: String, toPrivate: Boolean = true) {
        val bytes = text.toByteArray(Charsets.UTF_8)
        synchronized(lock) {
            try {
                publicOut?.write(bytes)
                publicOut?.flush()
            } catch (_: Throwable) {
            }
            if (toPrivate) {
                try {
                    privateOut?.write(bytes)
                    privateOut?.flush()
                } catch (_: Throwable) {
                }
            }
        }
    }

    private fun readPrivateLog(app: Application): String {
        return try {
            val f = File(app.filesDir, PRIVATE_NAME)
            if (!f.isFile) {
                ""
            } else {
                val skip = if (f.length() > MAX_PREVIOUS_RUN_BYTES) f.length() - MAX_PREVIOUS_RUN_BYTES else 0L
                f.inputStream().use { input ->
                    if (skip > 0L) input.skip(skip)
                    String(input.readBytes(), Charsets.UTF_8)
                }
            }
        } catch (_: Throwable) {
            ""
        }
    }

    private fun openPrivateStream(app: Application): OutputStream? {
        return try {
            FileOutputStream(File(app.filesDir, PRIVATE_NAME), false)
        } catch (_: Throwable) {
            null
        }
    }

    /** Creates the file in the public Download folder; falls back to the app's external folder. */
    private fun openPublicStream(app: Application) {
        val name = FILE_PREFIX + LocalDateTime.now().format(fileClock) + ".txt"
        try {
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            values.put(MediaStore.MediaColumns.MIME_TYPE, "text/plain")
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            val out = if (uri != null) app.contentResolver.openOutputStream(uri) else null
            if (out != null) {
                publicOut = out
                location = "Download/$name"
                return
            }
        } catch (t: Throwable) {
            Log.e(TAG, "could not create the log in the Download folder", t)
        }
        try {
            val dir = app.getExternalFilesDir(null)
            if (dir != null) {
                dir.mkdirs()
                val f = File(dir, name)
                publicOut = FileOutputStream(f, false)
                location = f.absolutePath + " (the Download folder was not available)"
            }
        } catch (t: Throwable) {
            Log.e(TAG, "could not create the fallback log", t)
        }
    }

    /** Keeps only the newest [KEEP_FILES] log files this app created in Download. */
    private fun pruneOldLogs(app: Application) {
        try {
            val stale = ArrayList<Long>()
            app.contentResolver.query(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.MediaColumns._ID),
                MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?",
                arrayOf("$FILE_PREFIX%"),
                MediaStore.MediaColumns.DISPLAY_NAME + " DESC",
            )?.use { cursor ->
                var seen = 0
                while (cursor.moveToNext()) {
                    seen++
                    if (seen > KEEP_FILES) stale.add(cursor.getLong(0))
                }
            }
            for (id in stale) {
                app.contentResolver.delete(
                    ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id),
                    null,
                    null,
                )
            }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ report sections

    private fun header(app: Application): String {
        val sb = StringBuilder()
        sb.append("==================== TORRIX LOG ====================\n")
        sb.append("started:     ").append(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)).append('\n')
        sb.append("saved as:    ").append(location).append('\n')
        try {
            val info = app.packageManager.getPackageInfo(app.packageName, 0)
            sb.append("app:         ").append(app.packageName).append(' ')
                .append(info.versionName).append(" (code ").append(info.longVersionCode).append(")\n")
        } catch (_: Throwable) {
            sb.append("app:         ").append(app.packageName).append('\n')
        }
        sb.append("device:      ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
            .append(", Android ").append(Build.VERSION.RELEASE)
            .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n")
        sb.append("cpu abis:    ").append(Build.SUPPORTED_ABIS.joinToString()).append('\n')
        try {
            sb.append("page size:   ").append(Os.sysconf(OsConstants._SC_PAGESIZE)).append(" bytes\n")
        } catch (_: Throwable) {
        }
        sb.append("process id:  ").append(android.os.Process.myPid()).append('\n')
        try {
            val dir = File(app.applicationInfo.nativeLibraryDir)
            val names = dir.list()
            sb.append("native dir:  ").append(dir.path).append('\n')
            sb.append("native libs: ")
                .append(if (names == null || names.isEmpty()) "(none found)" else names.sorted().joinToString())
                .append('\n')
        } catch (_: Throwable) {
        }
        return sb.toString()
    }

    private fun exitReport(app: Application): String {
        return try {
            val am = app.getSystemService(ActivityManager::class.java)
                ?: return "(ActivityManager is not available)\n"
            val exits = am.getHistoricalProcessExitReasons(app.packageName, 0, 6)
            if (exits.isEmpty()) {
                return "(Android has no earlier exit of Torrix on record, so this is the first run after install)\n"
            }
            latestExitReason = exits[0].reason
            val sb = StringBuilder()
            for ((i, e) in exits.withIndex()) {
                sb.append("--- exit ").append(i + 1).append(if (i == 0) " (the most recent) ---\n" else " ---\n")
                val whenText = LocalDateTime
                    .ofInstant(Instant.ofEpochMilli(e.timestamp), ZoneId.systemDefault())
                    .format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                sb.append("time:        ").append(whenText).append('\n')
                sb.append("reason:      ").append(reasonName(e.reason)).append(" (").append(e.reason).append(")\n")
                sb.append("status:      ").append(e.status).append("   pid ").append(e.pid)
                    .append("   process ").append(e.processName).append('\n')
                sb.append("memory:      rss ").append(e.rss).append(" KB, pss ").append(e.pss).append(" KB\n")
                val d = e.description
                if (!d.isNullOrBlank()) sb.append("description: ").append(d).append('\n')
                if (e.reason == 5 || e.reason == 6 || e.reason == 7) sb.append(readTrace(e))
            }
            sb.toString()
        } catch (t: Throwable) {
            "(could not read the exit reasons: $t)\n"
        }
    }

    private fun reasonName(reason: Int): String = when (reason) {
        0 -> "UNKNOWN"
        1 -> "EXIT_SELF"
        2 -> "SIGNALED"
        3 -> "LOW_MEMORY"
        4 -> "CRASH (Kotlin/Java exception)"
        5 -> "CRASH_NATIVE (native code crashed)"
        6 -> "ANR (app not responding)"
        7 -> "INITIALIZATION_FAILURE"
        8 -> "PERMISSION_CHANGE"
        9 -> "EXCESSIVE_RESOURCE_USAGE"
        10 -> "USER_REQUESTED"
        11 -> "USER_STOPPED"
        12 -> "DEPENDENCY_DIED"
        13 -> "OTHER"
        14 -> "FREEZER"
        15 -> "PACKAGE_STATE_CHANGE"
        16 -> "PACKAGE_UPDATED"
        else -> "REASON_$reason"
    }

    /** The trace Android kept for a native crash (a binary tombstone) or an ANR (text). */
    private fun readTrace(e: ApplicationExitInfo): String {
        return try {
            val input = e.traceInputStream ?: return "trace:       (Android kept none)\n"
            val buffer = ByteArray(MAX_TRACE_BYTES)
            var used = 0
            input.use { stream ->
                while (used < buffer.size) {
                    val n = stream.read(buffer, used, buffer.size - used)
                    if (n < 0) break
                    used += n
                }
            }
            "trace (readable text pulled out of it; the first character of a line can be noise):\n" +
                printableRuns(buffer, used) + "\n"
        } catch (t: Throwable) {
            "trace:       (could not be read: $t)\n"
        }
    }

    private fun printableRuns(bytes: ByteArray, length: Int): String {
        val out = StringBuilder()
        val run = StringBuilder()
        fun flush() {
            if (run.length >= 5) out.append(run.toString().trim()).append('\n')
            run.setLength(0)
        }
        for (i in 0 until length) {
            val b = bytes[i].toInt() and 0xFF
            if ((b in 0x20..0x7E) || b == 0x0A || b == 0x09) run.append(b.toChar()) else flush()
        }
        flush()
        return out.toString()
    }

    // ------------------------------------------------------------------ logcat

    private fun startLogcatThread(app: Application) {
        try {
            val worker = Thread({
                try {
                    // With the Download copy turned off there is nothing to write the dump to.
                    val saving = synchronized(lock) { publicOut != null }
                    if (saving) {
                        val lines = if (latestExitReason in ABNORMAL_EXITS) 1500 else 300
                        val text = ownLogcat(lines)
                        write(
                            "\n==================== LOGCAT OF THIS APP (last $lines lines, includes the previous run) ====================\n" +
                                text + "\n==================== END OF LOGCAT ====================\n",
                            false,
                        )
                        pruneOldLogs(app)
                    }
                } catch (t: Throwable) {
                    Log.e(TAG, "logcat dump failed", t)
                } finally {
                    startupDone.countDown()
                }
            }, "torrix-log-startup")
            worker.isDaemon = true
            worker.start()
        } catch (_: Throwable) {
            startupDone.countDown()
        }
    }

    /** An app may read its own log lines (and only those) without any permission. */
    private fun ownLogcat(lines: Int): String {
        val result = StringBuilder()
        val worker = Thread({
            var process: Process? = null
            try {
                val started = ProcessBuilder("logcat", "-d", "-v", "threadtime", "-t", lines.toString())
                    .redirectErrorStream(true)
                    .start()
                process = started
                started.inputStream.bufferedReader().use { reader ->
                    val buf = CharArray(8192)
                    while (true) {
                        val n = reader.read(buf)
                        if (n < 0) break
                        synchronized(result) {
                            if (result.length < MAX_LOGCAT_CHARS) result.append(buf, 0, n)
                        }
                    }
                }
            } catch (t: Throwable) {
                synchronized(result) { result.append("(logcat failed: ").append(t.toString()).append(")\n") }
            } finally {
                try {
                    process?.destroy()
                } catch (_: Throwable) {
                }
            }
        }, "torrix-logcat")
        worker.isDaemon = true
        worker.start()
        worker.join(4000)
        val text = synchronized(result) { result.toString() }
        return text
    }
}
