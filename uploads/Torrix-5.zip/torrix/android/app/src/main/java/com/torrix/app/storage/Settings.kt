package com.torrix.app.storage

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Where finished downloads are saved. Torrent data is always downloaded into app storage first. */
enum class SaveMode { PUBLIC_DOWNLOADS, CUSTOM_FOLDER, APP_ONLY }

data class AppSettings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val saveMode: SaveMode = SaveMode.PUBLIC_DOWNLOADS,
    val customTreeUri: String? = null,
    val maxActive: Int = 3,
    val downKiB: Int = 0,
    val upKiB: Int = 0,
    val dhtEnabled: Boolean = true,
    val allowMobileData: Boolean = false,
    val keepAwake: Boolean = false,
    val seedAfterComplete: Boolean = false,
    val iaEnabled: Boolean = true,
    val distrosEnabled: Boolean = true,
    val torznabUrl: String = "",
    val torznabKey: String = "",
) {
    /** The part of the settings the native engine needs (see android/rust/rust-engine/src/settings.rs). */
    fun toEngineJson(): JSONObject = JSONObject()
        .put("max_active_downloads", maxActive)
        .put("download_limit_kib", downKiB)
        .put("upload_limit_kib", upKiB)
        .put("dht_enabled", dhtEnabled)
        .put("seed_after_complete", seedAfterComplete)
        .put("internet_archive_enabled", iaEnabled)
        .put("linux_distros_enabled", distrosEnabled)
        .put("torznab_url", torznabUrl)
        .put("torznab_api_key", torznabKey)
}

class SettingsStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("torrix_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    @Synchronized
    fun update(transform: (AppSettings) -> AppSettings) {
        val next = transform(_state.value)
        _state.value = next
        save(next)
    }

    private inline fun <reified E : Enum<E>> enumOf(key: String, default: E): E =
        runCatching { enumValueOf<E>(prefs.getString(key, default.name) ?: default.name) }
            .getOrDefault(default)

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            theme = enumOf("theme", d.theme),
            saveMode = enumOf("saveMode", d.saveMode),
            customTreeUri = prefs.getString("customTreeUri", null),
            maxActive = prefs.getInt("maxActive", d.maxActive).coerceIn(1, 10),
            downKiB = prefs.getInt("downKiB", d.downKiB).coerceAtLeast(0),
            upKiB = prefs.getInt("upKiB", d.upKiB).coerceAtLeast(0),
            dhtEnabled = prefs.getBoolean("dhtEnabled", d.dhtEnabled),
            allowMobileData = prefs.getBoolean("allowMobileData", d.allowMobileData),
            keepAwake = prefs.getBoolean("keepAwake", d.keepAwake),
            seedAfterComplete = prefs.getBoolean("seedAfterComplete", d.seedAfterComplete),
            iaEnabled = prefs.getBoolean("iaEnabled", d.iaEnabled),
            distrosEnabled = prefs.getBoolean("distrosEnabled", d.distrosEnabled),
            torznabUrl = prefs.getString("torznabUrl", "") ?: "",
            torznabKey = prefs.getString("torznabKey", "") ?: "",
        )
    }

    private fun save(s: AppSettings) {
        prefs.edit()
            .putString("theme", s.theme.name)
            .putString("saveMode", s.saveMode.name)
            .putString("customTreeUri", s.customTreeUri)
            .putInt("maxActive", s.maxActive)
            .putInt("downKiB", s.downKiB)
            .putInt("upKiB", s.upKiB)
            .putBoolean("dhtEnabled", s.dhtEnabled)
            .putBoolean("allowMobileData", s.allowMobileData)
            .putBoolean("keepAwake", s.keepAwake)
            .putBoolean("seedAfterComplete", s.seedAfterComplete)
            .putBoolean("iaEnabled", s.iaEnabled)
            .putBoolean("distrosEnabled", s.distrosEnabled)
            .putString("torznabUrl", s.torznabUrl)
            .putString("torznabKey", s.torznabKey)
            .apply()
    }
}

/** A finished download that has been saved to its final location. */
data class CompletedItem(
    val hash: String,
    val name: String,
    val sizeBytes: Long,
    val completedMs: Long,
    val location: String,
    val uri: String?,
    val mime: String?,
)

class CompletedStore(private val file: File) {
    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<CompletedItem>> = _items.asStateFlow()

    @Synchronized
    fun add(item: CompletedItem) {
        _items.value = (listOf(item) + _items.value.filter { it.hash != item.hash }).take(300)
        save()
    }

    @Synchronized
    fun remove(hash: String) {
        _items.value = _items.value.filter { it.hash != hash }
        save()
    }

    private fun load(): List<CompletedItem> = try {
        if (!file.exists()) {
            emptyList()
        } else {
            val arr = JSONArray(file.readText())
            val out = ArrayList<CompletedItem>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                out.add(
                    CompletedItem(
                        hash = o.optString("hash"),
                        name = o.optString("name"),
                        sizeBytes = o.optLong("sizeBytes"),
                        completedMs = o.optLong("completedMs"),
                        location = o.optString("location"),
                        uri = if (o.isNull("uri")) null else o.optString("uri"),
                        mime = if (o.isNull("mime")) null else o.optString("mime"),
                    )
                )
            }
            out
        }
    } catch (_: Exception) {
        emptyList()
    }

    private fun save() {
        try {
            val arr = JSONArray()
            for (item in _items.value) {
                arr.put(
                    JSONObject()
                        .put("hash", item.hash)
                        .put("name", item.name)
                        .put("sizeBytes", item.sizeBytes)
                        .put("completedMs", item.completedMs)
                        .put("location", item.location)
                        .put("uri", item.uri ?: JSONObject.NULL)
                        .put("mime", item.mime ?: JSONObject.NULL)
                )
            }
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(arr.toString())
                tmp.delete()
            }
        } catch (_: Exception) {
            // Losing the history list is annoying but never fatal.
        }
    }
}

/** Info hashes whose completion has already been handled, so it happens once. */
class HandledStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("torrix_handled", Context.MODE_PRIVATE)
    private val set: MutableSet<String> =
        (prefs.getStringSet("hashes", emptySet()) ?: emptySet()).toMutableSet()

    @Synchronized
    fun contains(hash: String) = hash in set

    @Synchronized
    fun add(hash: String) {
        if (set.add(hash)) {
            // Keep the set bounded.
            while (set.size > 500) set.remove(set.first())
            prefs.edit().putStringSet("hashes", HashSet(set)).apply()
        }
    }
}
