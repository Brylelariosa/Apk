package com.torrix.app.engine

import org.json.JSONArray
import org.json.JSONObject

class EngineException(message: String) : Exception(message)

sealed interface EngineStatus {
    data object Starting : EngineStatus
    data object Ready : EngineStatus
    data class Failed(val message: String) : EngineStatus
}

internal fun JSONObject.optLongOrNull(key: String): Long? =
    if (has(key) && !isNull(key)) optLong(key) else null

internal fun JSONObject.optIntOrNull(key: String): Int? =
    if (has(key) && !isNull(key)) optInt(key) else null

internal fun JSONObject.optStringOrNull(key: String): String? =
    if (has(key) && !isNull(key)) optString(key).takeIf { it.isNotEmpty() } else null

data class TorrentItem(
    val hash: String,
    val name: String,
    /** checking | downloading | queued | waiting_network | paused | seeding | complete | error */
    val state: String,
    val finished: Boolean,
    val hold: Boolean,
    val progress: Float,
    val totalBytes: Long,
    val doneBytes: Long,
    val uploadedBytes: Long,
    val downBps: Long,
    val upBps: Long,
    val peersLive: Int,
    val peersSeen: Int,
    val peersConnecting: Int,
    val etaSecs: Long?,
    val error: String?,
    val outputFolder: String,
    val addedMs: Long,
    val completedMs: Long?,
) {
    val isDownloading get() = state == "downloading" || state == "checking"
    val isQueued get() = state == "queued" || state == "waiting_network"
}

data class Totals(
    val downBps: Long,
    val upBps: Long,
    val downloading: Int,
    val seeding: Int,
    val queued: Int,
    val total: Int,
)

data class Snapshot(
    val tsMs: Long,
    val torrents: List<TorrentItem>,
    val totals: Totals,
    val networkAllowed: Boolean,
) {
    companion object {
        val EMPTY = Snapshot(0L, emptyList(), Totals(0, 0, 0, 0, 0, 0), true)
    }
}

internal fun parseTorrent(o: JSONObject) = TorrentItem(
    hash = o.optString("hash"),
    name = o.optString("name"),
    state = o.optString("state"),
    finished = o.optBoolean("finished"),
    hold = o.optBoolean("hold"),
    progress = o.optDouble("progress", 0.0).toFloat(),
    totalBytes = o.optLong("total_bytes"),
    doneBytes = o.optLong("done_bytes"),
    uploadedBytes = o.optLong("uploaded_bytes"),
    downBps = o.optLong("down_bps"),
    upBps = o.optLong("up_bps"),
    peersLive = o.optInt("peers_live"),
    peersSeen = o.optInt("peers_seen"),
    peersConnecting = o.optInt("peers_connecting"),
    etaSecs = o.optLongOrNull("eta_secs"),
    error = o.optStringOrNull("error"),
    outputFolder = o.optString("output_folder"),
    addedMs = o.optLong("added_ms"),
    completedMs = o.optLongOrNull("completed_ms"),
)

internal fun parseSnapshot(data: JSONObject): Snapshot {
    val arr = data.optJSONArray("torrents") ?: JSONArray()
    val list = ArrayList<TorrentItem>(arr.length())
    for (i in 0 until arr.length()) {
        arr.optJSONObject(i)?.let { list.add(parseTorrent(it)) }
    }
    val t = data.optJSONObject("totals")
    val totals = Totals(
        downBps = t?.optLong("down_bps") ?: 0L,
        upBps = t?.optLong("up_bps") ?: 0L,
        downloading = t?.optInt("downloading") ?: 0,
        seeding = t?.optInt("seeding") ?: 0,
        queued = t?.optInt("queued") ?: 0,
        total = t?.optInt("total") ?: list.size,
    )
    return Snapshot(
        tsMs = data.optLong("ts_ms"),
        torrents = list,
        totals = totals,
        networkAllowed = data.optBoolean("network_allowed", true),
    )
}

// ---- add-torrent flow -------------------------------------------------------

data class PreviewFile(val index: Int, val path: String, val length: Long)

data class PreviewInfo(
    val hash: String,
    val name: String,
    val totalBytes: Long,
    val files: List<PreviewFile>,
)

internal fun parsePreview(o: JSONObject): PreviewInfo {
    val arr = o.optJSONArray("files") ?: JSONArray()
    val files = ArrayList<PreviewFile>(arr.length())
    for (i in 0 until arr.length()) {
        val f = arr.optJSONObject(i) ?: continue
        files.add(PreviewFile(f.optInt("index", i), f.optString("path"), f.optLong("length")))
    }
    return PreviewInfo(
        hash = o.optString("hash"),
        name = o.optString("name"),
        totalBytes = o.optLong("total_bytes"),
        files = files,
    )
}

// ---- search -----------------------------------------------------------------

data class SearchResultItem(
    val provider: String,
    val title: String,
    val sizeBytes: Long?,
    val category: String?,
    val seeders: Int?,
    val leechers: Int?,
    val magnet: String?,
    val torrentUrl: String?,
    val infoHash: String?,
    val detailsUrl: String?,
    val published: String?,
    /** What to hand to the download manager: a magnet link or a .torrent address. */
    val source: String?,
)

data class ProviderInfo(
    val id: String,
    val name: String,
    val ok: Boolean,
    val count: Int,
    val error: String?,
    val elapsedMs: Long,
)

data class SearchOutcome(val results: List<SearchResultItem>, val providers: List<ProviderInfo>)

internal fun parseSearch(o: JSONObject): SearchOutcome {
    val ra = o.optJSONArray("results") ?: JSONArray()
    val results = ArrayList<SearchResultItem>(ra.length())
    for (i in 0 until ra.length()) {
        val r = ra.optJSONObject(i) ?: continue
        results.add(
            SearchResultItem(
                provider = r.optString("provider"),
                title = r.optString("title"),
                sizeBytes = r.optLongOrNull("size_bytes"),
                category = r.optStringOrNull("category"),
                seeders = r.optIntOrNull("seeders"),
                leechers = r.optIntOrNull("leechers"),
                magnet = r.optStringOrNull("magnet"),
                torrentUrl = r.optStringOrNull("torrent_url"),
                infoHash = r.optStringOrNull("info_hash"),
                detailsUrl = r.optStringOrNull("details_url"),
                published = r.optStringOrNull("published"),
                source = r.optStringOrNull("source"),
            )
        )
    }
    val pa = o.optJSONArray("providers") ?: JSONArray()
    val providers = ArrayList<ProviderInfo>(pa.length())
    for (i in 0 until pa.length()) {
        val p = pa.optJSONObject(i) ?: continue
        providers.add(
            ProviderInfo(
                id = p.optString("id"),
                name = p.optString("name"),
                ok = p.optBoolean("ok"),
                count = p.optInt("count"),
                error = p.optStringOrNull("error"),
                elapsedMs = p.optLong("elapsed_ms"),
            )
        )
    }
    return SearchOutcome(results, providers)
}

/** Progress of saving a finished torrent to the user's chosen location. */
data class ExportState(
    val running: Boolean,
    val copiedBytes: Long,
    val totalBytes: Long,
    val error: String?,
)
