package com.torrix.app.service

import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.torrix.app.TorrixApp
import com.torrix.app.engine.EngineController
import com.torrix.app.engine.Snapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground service that keeps the process (and so the native engine) alive
 * while there is work to do, and stops itself when there is not. The native
 * engine keeps all state on disk, so if Android kills the process the service
 * is restarted (START_STICKY) and the downloads resume where they were.
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var collector: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wakeAcquiredAt = 0L
    private var idleSince = 0L
    private var lastNotify = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val engine = (application as TorrixApp).engine
        startForeground(
            Notifier.ID_ONGOING,
            Notifier.ongoing(this, engine.snapshot.value),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )
        if (collector == null) {
            collector = scope.launch {
                engine.snapshot.collect { onSnapshot(engine, it) }
            }
        }
        return START_STICKY
    }

    private fun onSnapshot(engine: EngineController, s: Snapshot) {
        val now = SystemClock.elapsedRealtime()
        val busy = engine.needsService(s)
        if (busy) {
            idleSince = 0L
        } else if (idleSince == 0L) {
            idleSince = now
        }
        if (!busy && idleSince != 0L && now - idleSince > IDLE_STOP_MS) {
            releaseWakeLock()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        if (now - lastNotify >= NOTIFY_EVERY_MS) {
            lastNotify = now
            getSystemService(NotificationManager::class.java)
                .notify(Notifier.ID_ONGOING, Notifier.ongoing(this, s))
        }
        updateWakeLock(engine, s, now)
    }

    private fun updateWakeLock(engine: EngineController, s: Snapshot, now: Long) {
        val want = engine.settings.state.value.keepAwake && s.torrents.any { it.isDownloading }
        val held = wakeLock?.isHeld == true
        if (want && (!held || now - wakeAcquiredAt > 8 * 60_000L)) {
            val lock = wakeLock ?: getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Torrix:downloads")
                .also {
                    it.setReferenceCounted(false)
                    wakeLock = it
                }
            lock.acquire(10 * 60_000L) // re-acquired while still needed; never held forever
            wakeAcquiredAt = now
        } else if (!want && held) {
            releaseWakeLock()
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: RuntimeException) {
        }
    }

    override fun onDestroy() {
        releaseWakeLock()
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val IDLE_STOP_MS = 20_000L
        private const val NOTIFY_EVERY_MS = 1_500L

        /** Safe to call at any time; does nothing if Android refuses a background start. */
        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
