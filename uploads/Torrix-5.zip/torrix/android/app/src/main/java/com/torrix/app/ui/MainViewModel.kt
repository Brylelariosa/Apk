package com.torrix.app.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.torrix.app.TorrixApp
import com.torrix.app.diag.CrashLog
import com.torrix.app.engine.EngineController
import com.torrix.app.engine.PreviewInfo
import com.torrix.app.engine.ProviderInfo
import com.torrix.app.engine.SearchResultItem
import com.torrix.app.engine.TorrentItem
import com.torrix.app.engine.parsePreview
import com.torrix.app.storage.CompletedItem
import com.torrix.app.storage.SaveMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException

enum class Tab(val title: String) {
    HOME("Home"),
    SEARCH("Search"),
    DOWNLOADS("Downloads"),
    COMPLETED("Completed"),
    SETTINGS("Settings"),
}

sealed interface AddUi {
    data object Idle : AddUi
    data class Resolving(
        val requestId: Long,
        val label: String,
        /** Seconds the lookup has been running and which lookup it is on, for the progress text. */
        val elapsedSecs: Int = 0,
        val attempt: Int = 1,
    ) : AddUi
    data class Ready(val requestId: Long, val preview: PreviewInfo, val selected: Set<Int>) : AddUi
    data class Adding(
        val requestId: Long,
        val name: String,
        val elapsedSecs: Int = 0,
        val attempt: Int = 1,
    ) : AddUi
    data class Failed(val message: String) : AddUi
}

data class SearchUi(
    val query: String = "",
    val loading: Boolean = false,
    val searched: Boolean = false,
    val results: List<SearchResultItem> = emptyList(),
    val providers: List<ProviderInfo> = emptyList(),
    val error: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val engine: EngineController = (app as TorrixApp).engine

    val tab = MutableStateFlow(Tab.HOME)
    val add = MutableStateFlow<AddUi>(AddUi.Idle)
    val search = MutableStateFlow(SearchUi())
    val selectedResult = MutableStateFlow<SearchResultItem?>(null)
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 8)

    private var addJob: Job? = null
    private var searchJob: Job? = null
    private var currentRequest: Long? = null

    fun say(text: String) {
        messages.tryEmit(text)
    }

    private fun act(block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say(e.message ?: "Something went wrong.")
            }
        }
    }

    // ----------------------------------------------------------- add torrent

    fun beginAdd(input: String) {
        val text = input.trim()
        if (text.isEmpty()) {
            say("Paste a magnet link first.")
            return
        }
        cancelAddJob()
        addJob = viewModelScope.launch {
            try {
                val v = engine.rpc("validate", JSONObject().put("input", text))
                val id = engine.rpc("add_start", JSONObject().put("input", text)).getLong("request_id")
                currentRequest = id
                add.value = AddUi.Resolving(id, v.optString("label", "torrent"))
                pollResolve(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                add.value = AddUi.Failed(e.message ?: "Could not add that.")
            }
        }
    }

    fun beginAddFile(uri: Uri) {
        cancelAddJob()
        add.value = AddUi.Resolving(0L, "torrent file")
        addJob = viewModelScope.launch {
            try {
                val tmp = withContext(Dispatchers.IO) { copyToCache(uri) }
                val id = engine.rpc("add_start_file", JSONObject().put("path", tmp.absolutePath))
                    .getLong("request_id")
                currentRequest = id
                pollResolve(id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                add.value = AddUi.Failed(e.message ?: "Could not read that file.")
            }
        }
    }

    private fun copyToCache(uri: Uri): File {
        val ctx = getApplication<Application>()
        val out = File(ctx.cacheDir, "incoming-${System.nanoTime()}.torrent")
        val input = ctx.contentResolver.openInputStream(uri)
            ?: throw IOException("Could not open the .torrent file.")
        input.use { i ->
            out.outputStream().use { o ->
                val buf = ByteArray(64 * 1024)
                var total = 0L
                while (true) {
                    val n = i.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > 8L * 1024 * 1024) throw IOException("The .torrent file is too large.")
                    o.write(buf, 0, n)
                }
            }
        }
        return out
    }

    private suspend fun pollResolve(id: Long) {
        val began = System.nanoTime()
        while (true) {
            delay(300)
            val st = engine.rpc("add_status", JSONObject().put("request_id", id))
            when (st.optString("state")) {
                "ready" -> {
                    val p = parsePreview(st)
                    CrashLog.note("add: details ready after ${secondsSince(began)} s")
                    add.value = AddUi.Ready(id, p, p.files.map { it.index }.toSet())
                    return
                }
                "failed" -> {
                    val why = st.optString("error", "Could not read that torrent.")
                    CrashLog.note("add: details failed after ${secondsSince(began)} s: ${forLog(why)}")
                    engine.noteEngineLog(40)
                    add.value = AddUi.Failed(why)
                    return
                }
                "resolving" -> {
                    val secs = (st.optLong("elapsed_ms") / 1000L).toInt()
                    val attempt = st.optInt("attempt", 1)
                    add.update { cur ->
                        if (cur is AddUi.Resolving) cur.copy(elapsedSecs = secs, attempt = attempt) else cur
                    }
                }
            }
        }
    }

    private fun secondsSince(startNanos: Long): Long = (System.nanoTime() - startNanos) / 1_000_000_000L

    /** A line for the log file: no links and no info hashes, and not too long. */
    private fun forLog(text: String): String =
        text.replace(Regex("(magnet:|https?://|udp://)\\S+"), "<link>")
            .replace(Regex("[0-9a-fA-F]{40}"), "<hash>")
            .take(160)

    fun toggleFile(index: Int) {
        add.update { cur ->
            if (cur is AddUi.Ready) {
                val next = if (index in cur.selected) cur.selected - index else cur.selected + index
                cur.copy(selected = next)
            } else cur
        }
    }

    fun selectAllFiles(all: Boolean) {
        add.update { cur ->
            if (cur is AddUi.Ready) {
                cur.copy(selected = if (all) cur.preview.files.map { it.index }.toSet() else emptySet())
            } else cur
        }
    }

    fun confirmAdd() {
        val cur = add.value as? AddUi.Ready ?: return
        if (cur.selected.isEmpty()) return
        cancelAddJob()
        add.value = AddUi.Adding(cur.requestId, cur.preview.name)
        addJob = viewModelScope.launch {
            try {
                val args = JSONObject().put("request_id", cur.requestId)
                if (cur.selected.size != cur.preview.files.size) {
                    args.put("only_files", JSONArray(cur.selected.sorted()))
                }
                engine.rpc("add_confirm", args)
                val began = System.nanoTime()
                while (true) {
                    delay(300)
                    val st = engine.rpc("add_status", JSONObject().put("request_id", cur.requestId))
                    when (st.optString("state")) {
                        "done" -> {
                            CrashLog.note("add: download started after ${secondsSince(began)} s")
                            add.value = AddUi.Idle
                            currentRequest = null
                            say("Added \"${cur.preview.name}\"")
                            engine.onTorrentAdded()
                            return@launch
                        }
                        "failed" -> {
                            val why = st.optString("error", "Could not start the download.")
                            CrashLog.note("add: start failed after ${secondsSince(began)} s: ${forLog(why)}")
                            engine.noteEngineLog(40)
                            add.value = AddUi.Failed(why)
                            return@launch
                        }
                        "adding" -> {
                            val secs = (st.optLong("elapsed_ms") / 1000L).toInt()
                            val attempt = st.optInt("attempt", 1)
                            add.update { c ->
                                if (c is AddUi.Adding) c.copy(elapsedSecs = secs, attempt = attempt) else c
                            }
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                add.value = AddUi.Failed(e.message ?: "Could not start the download.")
            }
        }
    }

    fun dismissAdd() {
        val id = currentRequest
        val phase = add.value
        cancelAddJob()
        add.value = AddUi.Idle
        currentRequest = null
        if (id == null) return
        if (phase is AddUi.Adding) {
            // The engine keeps adding. Keep watching so the person still hears how it went.
            watchAddInBackground(id, phase.name)
            return
        }
        viewModelScope.launch {
            try {
                if (phase is AddUi.Resolving) {
                    CrashLog.note("add: cancelled after ${phase.elapsedSecs} s (lookup ${phase.attempt})")
                    engine.noteEngineLog(40)
                }
                engine.rpc("add_cancel", JSONObject().put("request_id", id))
            } catch (_: Exception) {
            }
        }
    }

    /** The sheet was closed while the engine was still adding: report the outcome when it is known. */
    private fun watchAddInBackground(id: Long, name: String) {
        viewModelScope.launch {
            try {
                while (true) {
                    delay(1000)
                    val st = engine.rpc("add_status", JSONObject().put("request_id", id))
                    when (st.optString("state")) {
                        "done" -> {
                            say("Added \"$name\"")
                            engine.onTorrentAdded()
                            return@launch
                        }
                        "failed" -> {
                            say(st.optString("error", "Could not start the download."))
                            return@launch
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
    }

    private fun cancelAddJob() {
        addJob?.cancel()
        addJob = null
    }

    // ---------------------------------------------------------------- search

    fun runSearch(query: String) {
        val q = query.trim()
        search.update { it.copy(query = query) }
        if (q.length < 2) {
            search.update { it.copy(error = "Type at least two characters.") }
            return
        }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            search.update { it.copy(loading = true, error = null) }
            try {
                val out = engine.search(q)
                search.update {
                    it.copy(loading = false, searched = true, results = out.results, providers = out.providers, error = null)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                search.update {
                    it.copy(loading = false, searched = true, results = emptyList(), providers = emptyList(), error = e.message)
                }
            }
        }
    }

    fun downloadResult(r: SearchResultItem) {
        selectedResult.value = null
        val src = r.source
        if (src == null) say("This result has no download link.") else beginAdd(src)
    }

    // --------------------------------------------------------------- actions

    fun pause(hash: String) = act { engine.pause(hash) }
    fun resume(hash: String) = act { engine.resume(hash) }
    fun pauseAll() = act { engine.pauseAll() }
    fun resumeAll() = act { engine.resumeAll() }
    fun remove(hash: String, deleteFiles: Boolean) = act { engine.remove(hash, deleteFiles) }
    fun removeCompleted(hash: String) = engine.completed.remove(hash)
    fun saveFinished(hash: String) = engine.saveFinished(hash, forcePublicDownloads = false)
    fun saveToDownloads(hash: String) = engine.saveFinished(hash, forcePublicDownloads = true)

    fun onTreePicked(uri: Uri) {
        val ctx = getApplication<Application>()
        try {
            ctx.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        } catch (_: SecurityException) {
            say("Android did not allow access to that folder. Choose another one.")
            return
        }
        engine.settings.update { it.copy(saveMode = SaveMode.CUSTOM_FOLDER, customTreeUri = uri.toString()) }
        say("Downloads will be saved to the chosen folder.")
    }

    fun loadDiagnostics(onLoaded: (String) -> Unit) {
        viewModelScope.launch {
            val text = try {
                engine.diagnostics().joinToString("\n").ifBlank { "No warnings or errors recorded." }
            } catch (e: Exception) {
                "Could not read the engine log: ${e.message}"
            }
            onLoaded(text)
        }
    }

    // ----------------------------------------------------------- open files

    fun openCompleted(ctx: Context, item: CompletedItem) {
        val uri = item.uri?.let { Uri.parse(it) }
        if (uri == null) {
            say("Saved in ${item.location}. Open it from your file manager.")
            return
        }
        launchView(ctx, uri, item.mime)
    }

    fun openStaged(ctx: Context, t: TorrentItem) {
        val file = File(t.outputFolder, t.name)
        if (!file.isFile) {
            say("This download has several files. Save it to Downloads to open them.")
            return
        }
        try {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
            launchView(ctx, uri, com.torrix.app.storage.Exporter.mimeOf(file.name))
        } catch (_: IllegalArgumentException) {
            say("Could not open that file.")
        }
    }

    private fun launchView(ctx: Context, uri: Uri, mime: String?) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mime ?: "*/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
        } catch (_: Exception) {
            say("No app can open this kind of file.")
        }
    }
}
