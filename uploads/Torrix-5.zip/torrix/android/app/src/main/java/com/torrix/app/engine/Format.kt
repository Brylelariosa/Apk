package com.torrix.app.engine

import java.util.Locale

object Fmt {
    private val units = arrayOf("B", "KB", "MB", "GB", "TB")

    fun bytes(b: Long): String {
        if (b < 0) return "-"
        var v = b.toDouble()
        var i = 0
        while (v >= 1024.0 && i < units.size - 1) {
            v /= 1024.0
            i++
        }
        return when {
            i == 0 -> "$b B"
            v >= 100 -> String.format(Locale.US, "%.0f %s", v, units[i])
            else -> String.format(Locale.US, "%.1f %s", v, units[i])
        }
    }

    fun speed(bps: Long): String = bytes(bps) + "/s"

    fun eta(secs: Long?): String? {
        if (secs == null) return null
        val h = secs / 3600
        val m = (secs % 3600) / 60
        val s = secs % 60
        return when {
            h >= 24 -> "${h / 24}d ${h % 24}h"
            h > 0 -> "${h}h ${m}m"
            m > 0 -> "${m}m ${s}s"
            else -> "${s}s"
        }
    }

    fun percent(p: Float): String = "${(p * 100f).toInt().coerceIn(0, 100)}%"
}
