package com.torrix.app.engine

import com.torrix.app.diag.CrashLog

/**
 * The only native entry point. Every request is `method` + JSON arguments and
 * every answer is a JSON envelope, see android/rust/rust-engine/src/lib.rs (`call`).
 */
object NativeBridge {
    init {
        try {
            CrashLog.note("loading libtorrix_engine.so")
            System.loadLibrary("torrix_engine")
            CrashLog.note("libtorrix_engine.so loaded")
        } catch (t: Throwable) {
            CrashLog.note("loading libtorrix_engine.so FAILED", t)
            throw t
        }
    }

    @JvmStatic
    external fun nativeCall(method: String, argsJson: String): String?
}
