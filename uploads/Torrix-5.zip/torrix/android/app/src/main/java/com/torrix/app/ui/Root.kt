package com.torrix.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.collectAsState
import com.torrix.app.engine.EngineStatus

private fun Tab.icon(): ImageVector = when (this) {
    Tab.HOME -> Icons.Filled.Home
    Tab.SEARCH -> Icons.Filled.Search
    Tab.DOWNLOADS -> TorrixIcons.Download
    Tab.COMPLETED -> Icons.Filled.CheckCircle
    Tab.SETTINGS -> Icons.Filled.Settings
}

@Composable
fun TorrixRoot(
    vm: MainViewModel,
    onPickFolder: () -> Unit,
    onPickTorrent: () -> Unit,
    onBatterySettings: () -> Unit,
) {
    val settings by vm.engine.settings.state.collectAsState()
    TorrixTheme(settings.theme) {
        val tab by vm.tab.collectAsState()
        val status by vm.engine.status.collectAsState()
        val addUi by vm.add.collectAsState()
        val snackbar = remember { SnackbarHostState() }
        LaunchedEffect(vm) { vm.messages.collect { snackbar.showSnackbar(it) } }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snackbar) },
            bottomBar = {
                NavigationBar {
                    for (t in Tab.entries) {
                        NavigationBarItem(
                            selected = tab == t,
                            onClick = { vm.tab.value = t },
                            icon = { Icon(t.icon(), contentDescription = null) },
                            label = { Text(t.title) },
                        )
                    }
                }
            },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (val st = status) {
                    EngineStatus.Starting -> Column(
                        Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        CircularProgressIndicator()
                        Text("Starting the torrent engine", Modifier.padding(top = 16.dp), style = MaterialTheme.typography.bodyMedium)
                    }
                    is EngineStatus.Failed -> Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Text("The torrent engine could not start", style = MaterialTheme.typography.titleLarge)
                        Text(
                            st.message,
                            Modifier.padding(top = 8.dp, bottom = 16.dp),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.error,
                        )
                        Button(onClick = { vm.loadDiagnostics { vm.say(it.takeLast(300)) } }) { Text("Show engine log") }
                    }
                    EngineStatus.Ready -> Crossfade(targetState = tab, label = "tabs") { current ->
                        when (current) {
                            Tab.HOME -> HomeScreen(vm, onPickTorrent)
                            Tab.SEARCH -> SearchScreen(vm)
                            Tab.DOWNLOADS -> DownloadsScreen(vm)
                            Tab.COMPLETED -> CompletedScreen(vm)
                            Tab.SETTINGS -> SettingsScreen(vm, onPickFolder, onBatterySettings)
                        }
                    }
                }
            }
        }
        if (addUi !is AddUi.Idle) AddSheet(vm, addUi)
    }
}
