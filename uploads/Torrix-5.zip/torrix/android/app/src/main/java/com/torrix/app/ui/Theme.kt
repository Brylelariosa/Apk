package com.torrix.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.torrix.app.storage.ThemeMode

/*
 * Design notes
 * - A torrent is a set of small, individually verified pieces, so progress is drawn
 *   as a row of pieces rather than a smooth bar: cobalt = verified, amber = a piece
 *   still arriving, green = done. That is the one distinctive element; the rest is quiet.
 * - Numbers that change every second (speeds, percentages, ETA) use tabular figures
 *   so the layout does not jitter.
 */

@Immutable
class PieceColors(val verified: Color, val inflight: Color, val done: Color, val track: Color)

private val LightPieces = PieceColors(
    verified = Color(0xFF1F4FD8),
    inflight = Color(0xFFE8A21A),
    done = Color(0xFF1E8E5A),
    track = Color(0xFFDDE2EC),
)
private val DarkPieces = PieceColors(
    verified = Color(0xFF8FB0FF),
    inflight = Color(0xFFF2B94B),
    done = Color(0xFF5ED3A0),
    track = Color(0xFF2A3446),
)

val LocalPieceColors = staticCompositionLocalOf { LightPieces }

private val LightScheme = lightColorScheme(
    primary = Color(0xFF1F4FD8),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE5FF),
    onPrimaryContainer = Color(0xFF0A1F66),
    secondary = Color(0xFF8A5A00),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE2A8),
    onSecondaryContainer = Color(0xFF2B1A00),
    tertiary = Color(0xFF1E7A4F),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFC3F0D9),
    onTertiaryContainer = Color(0xFF00210F),
    background = Color(0xFFF3F5F8),
    onBackground = Color(0xFF101828),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF101828),
    surfaceVariant = Color(0xFFE6EAF2),
    onSurfaceVariant = Color(0xFF475467),
    outline = Color(0xFF98A2B3),
    outlineVariant = Color(0xFFD5DAE4),
    error = Color(0xFFC93B3B),
    onError = Color.White,
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002),
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF8FB0FF),
    onPrimary = Color(0xFF0A1F66),
    primaryContainer = Color(0xFF1B3A9C),
    onPrimaryContainer = Color(0xFFDDE5FF),
    secondary = Color(0xFFF2B94B),
    onSecondary = Color(0xFF3F2A00),
    secondaryContainer = Color(0xFF5E4100),
    onSecondaryContainer = Color(0xFFFFE2A8),
    tertiary = Color(0xFF5ED3A0),
    onTertiary = Color(0xFF00391F),
    tertiaryContainer = Color(0xFF0F5A37),
    onTertiaryContainer = Color(0xFFC3F0D9),
    background = Color(0xFF0E131B),
    onBackground = Color(0xFFE6EAF2),
    surface = Color(0xFF171E29),
    onSurface = Color(0xFFE6EAF2),
    surfaceVariant = Color(0xFF263041),
    onSurfaceVariant = Color(0xFFB4BDCC),
    outline = Color(0xFF6B7588),
    outlineVariant = Color(0xFF2E394B),
    error = Color(0xFFFF8A80),
    onError = Color(0xFF4A0A07),
    errorContainer = Color(0xFF7A1F1B),
    onErrorContainer = Color(0xFFFFDAD6),
)

private val base = Typography()
private val TorrixTypography = base.copy(
    headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
    titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    labelLarge = base.labelLarge.copy(fontWeight = FontWeight.Medium),
)

private val TorrixShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

/** Tabular figures: digits keep their width while numbers change. */
val NumberStyle = TextStyle(fontFeatureSettings = "tnum")

private fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun TorrixTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = view.context.findActivity()?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }
    CompositionLocalProvider(LocalPieceColors provides if (dark) DarkPieces else LightPieces) {
        MaterialTheme(
            colorScheme = if (dark) DarkScheme else LightScheme,
            typography = TorrixTypography,
            shapes = TorrixShapes,
            content = content,
        )
    }
}
