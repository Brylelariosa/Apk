package com.torrix.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.torrix.app.MainActivity
import com.torrix.app.R
import com.torrix.app.engine.Fmt
import com.torrix.app.engine.Snapshot

object Notifier {
    const val CH_ONGOING = "downloads_ongoing"
    const val CH_DONE = "downloads_done"
    const val ID_ONGOING = 1001

    const val ACTION_PAUSE_ALL = "com.torrix.app.PAUSE_ALL"
    const val ACTION_RESUME_ALL = "com.torrix.app.RESUME_ALL"

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val ongoing = NotificationChannel(
            CH_ONGOING, "Downloads in progress", NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = "Shows while torrents are downloading"
            setShowBadge(false)
        }
        val done = NotificationChannel(
            CH_DONE, "Finished downloads", NotificationManager.IMPORTANCE_DEFAULT,
        ).apply { description = "Tells you when a download has finished" }
        nm.createNotificationChannel(ongoing)
        nm.createNotificationChannel(done)
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx,
        0,
        Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun action(ctx: Context, action: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx,
            code,
            Intent(ctx, ActionReceiver::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    fun ongoing(ctx: Context, s: Snapshot): Notification {
        val active = s.torrents.filter { it.isDownloading }
        val waiting = s.torrents.count { it.state == "waiting_network" }
        val queued = s.torrents.count { it.state == "queued" }
        val title = when {
            active.isNotEmpty() -> "${active.size} downloading"
            waiting > 0 -> "Waiting for a usable connection"
            queued > 0 -> "$queued queued"
            s.totals.seeding > 0 -> "Seeding"
            else -> "Torrix"
        }
        val text = "Down ${Fmt.speed(s.totals.downBps)}   Up ${Fmt.speed(s.totals.upBps)}"

        val unfinished = s.torrents.filter { !it.finished && !it.hold && it.state != "error" }
        val total = unfinished.sumOf { it.totalBytes }
        val done = unfinished.sumOf { it.doneBytes }
        val pct = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else 0

        val hasRunning = s.torrents.any { !it.finished && !it.hold }
        val b = NotificationCompat.Builder(ctx, CH_ONGOING)
            .setSmallIcon(R.drawable.ic_stat_torrix)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openApp(ctx))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        if (unfinished.isNotEmpty() && total > 0) b.setProgress(100, pct, false)
        if (hasRunning) {
            b.addAction(0, "Pause all", action(ctx, ACTION_PAUSE_ALL, 1))
        } else if (s.torrents.any { !it.finished && it.hold }) {
            b.addAction(0, "Resume all", action(ctx, ACTION_RESUME_ALL, 2))
        }
        return b.build()
    }

    fun finished(ctx: Context, title: String, text: String, id: Int) {
        try {
            val nm = NotificationManagerCompat.from(ctx)
            if (!nm.areNotificationsEnabled()) return
            val n = NotificationCompat.Builder(ctx, CH_DONE)
                .setSmallIcon(R.drawable.ic_stat_torrix)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(openApp(ctx))
                .setAutoCancel(true)
                .build()
            nm.notify(id, n)
        } catch (_: SecurityException) {
            // Notification permission not granted: nothing to show.
        }
    }
}
