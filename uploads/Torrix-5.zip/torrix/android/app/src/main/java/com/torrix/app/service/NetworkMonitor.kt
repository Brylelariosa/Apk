package com.torrix.app.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Watches the default network so downloads can follow Wi-Fi / mobile data changes. */
class NetworkMonitor(ctx: Context) {

    data class NetState(val connected: Boolean, val unmetered: Boolean, val transport: String = "")

    private val cm = ctx.getSystemService(ConnectivityManager::class.java)
    private val _state = MutableStateFlow(current())
    val state: StateFlow<NetState> = _state.asStateFlow()

    init {
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    _state.value = current()
                }

                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    _state.value = from(caps)
                }

                override fun onLost(network: Network) {
                    _state.value = NetState(connected = false, unmetered = false)
                }
            })
        } catch (_: Exception) {
            // Without callbacks we keep the initial state: downloads simply keep running.
        }
    }

    private fun current(): NetState {
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        return if (caps == null) NetState(connected = false, unmetered = false) else from(caps)
    }

    private fun from(c: NetworkCapabilities) = NetState(
        connected = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
        unmetered = c.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED),
        transport = when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            else -> "other"
        },
    )
}
