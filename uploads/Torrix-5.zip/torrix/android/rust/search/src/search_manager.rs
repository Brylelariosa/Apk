//! Runs every enabled provider concurrently. A failing, slow or crashing
//! provider never affects the others: each gets its own task and timeout and
//! reports its own status.

use std::cmp::Reverse;
use std::sync::Arc;
use std::time::{Duration, Instant};

use crate::http;
use crate::models::{ProviderStatus, SearchConfig, SearchResponse, SearchResult};
use crate::providers::internet_archive::InternetArchive;
use crate::providers::linux_distros::LinuxDistros;
use crate::providers::torznab::Torznab;
use crate::providers::SearchProvider;

pub struct SearchManager {
    providers: Vec<Arc<dyn SearchProvider>>,
}

impl SearchManager {
    pub fn from_config(cfg: &SearchConfig) -> Result<Self, String> {
        let client = http::client()?;
        let mut providers: Vec<Arc<dyn SearchProvider>> = Vec::new();
        if cfg.linux_distros {
            providers.push(Arc::new(LinuxDistros::new(client.clone())));
        }
        if cfg.internet_archive {
            providers.push(Arc::new(InternetArchive::new(client.clone())));
        }
        if let Some(t) = &cfg.torznab {
            if !t.url.trim().is_empty() {
                providers.push(Arc::new(Torznab::new(client.clone(), t.clone())));
            }
        }
        Ok(Self { providers })
    }

    pub fn with_providers(providers: Vec<Arc<dyn SearchProvider>>) -> Self {
        Self { providers }
    }

    pub fn provider_count(&self) -> usize {
        self.providers.len()
    }

    pub async fn search(
        &self,
        query: &str,
        per_provider_limit: usize,
        timeout: Duration,
    ) -> Result<SearchResponse, String> {
        let q = query.trim().to_string();
        let chars = q.chars().count();
        if chars < 2 {
            return Err("Type at least two characters to search.".to_string());
        }
        if chars > 120 {
            return Err("The search text is too long.".to_string());
        }
        if self.providers.is_empty() {
            return Err("No search providers are enabled. Turn one on in Settings.".to_string());
        }

        let mut meta: Vec<(String, String)> = Vec::new();
        let mut handles = Vec::new();
        for p in &self.providers {
            meta.push((p.id().to_string(), p.name().to_string()));
            let p = p.clone();
            let q = q.clone();
            handles.push(tokio::spawn(async move {
                let started = Instant::now();
                let outcome = tokio::time::timeout(timeout, p.search(&q, per_provider_limit)).await;
                let elapsed_ms = started.elapsed().as_millis() as u64;
                match outcome {
                    Ok(Ok(results)) => (results, None, elapsed_ms),
                    Ok(Err(e)) => (Vec::new(), Some(e), elapsed_ms),
                    Err(_) => (Vec::new(), Some("timed out".to_string()), elapsed_ms),
                }
            }));
        }

        let mut results: Vec<SearchResult> = Vec::new();
        let mut statuses: Vec<ProviderStatus> = Vec::new();
        for ((id, name), handle) in meta.into_iter().zip(handles) {
            match handle.await {
                Ok((found, error, elapsed_ms)) => {
                    statuses.push(ProviderStatus {
                        id,
                        name,
                        ok: error.is_none(),
                        count: found.len(),
                        error,
                        elapsed_ms,
                    });
                    results.extend(found);
                }
                Err(_) => statuses.push(ProviderStatus {
                    id,
                    name,
                    ok: false,
                    count: 0,
                    error: Some("the provider stopped unexpectedly".to_string()),
                    elapsed_ms: 0,
                }),
            }
        }
        // Stable sort: results with more seeders first, provider order otherwise.
        results.sort_by_key(|r| Reverse(r.seeders.unwrap_or(0)));
        Ok(SearchResponse {
            query: q,
            results,
            providers: statuses,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use async_trait::async_trait;

    enum Behaviour {
        Titles(Vec<&'static str>),
        Fail(&'static str),
        Hang,
        Panic,
    }

    struct Mock {
        id: &'static str,
        behaviour: Behaviour,
    }

    #[async_trait]
    impl SearchProvider for Mock {
        fn id(&self) -> &'static str {
            self.id
        }
        fn name(&self) -> &'static str {
            self.id
        }
        async fn search(&self, _q: &str, _limit: usize) -> Result<Vec<SearchResult>, String> {
            match &self.behaviour {
                Behaviour::Titles(t) => Ok(t
                    .iter()
                    .enumerate()
                    .map(|(i, title)| SearchResult {
                        provider: self.id.to_string(),
                        title: title.to_string(),
                        seeders: Some(10 - i as u32),
                        ..Default::default()
                    })
                    .collect()),
                Behaviour::Fail(msg) => Err(msg.to_string()),
                Behaviour::Hang => {
                    tokio::time::sleep(Duration::from_secs(30)).await;
                    Ok(Vec::new())
                }
                Behaviour::Panic => panic!("boom"),
            }
        }
    }

    fn mgr(list: Vec<Mock>) -> SearchManager {
        SearchManager::with_providers(
            list.into_iter()
                .map(|m| Arc::new(m) as Arc<dyn SearchProvider>)
                .collect(),
        )
    }

    #[tokio::test]
    async fn one_failing_provider_does_not_hide_the_others() {
        let m = mgr(vec![
            Mock { id: "good", behaviour: Behaviour::Titles(vec!["a", "b"]) },
            Mock { id: "bad", behaviour: Behaviour::Fail("HTTP 503") },
        ]);
        let r = m.search("linux", 10, Duration::from_secs(2)).await.unwrap();
        assert_eq!(r.results.len(), 2);
        assert_eq!(r.providers.len(), 2);
        assert!(r.providers[0].ok);
        assert!(!r.providers[1].ok);
        assert_eq!(r.providers[1].error.as_deref(), Some("HTTP 503"));
    }

    #[tokio::test]
    async fn slow_providers_time_out() {
        let m = mgr(vec![
            Mock { id: "slow", behaviour: Behaviour::Hang },
            Mock { id: "fast", behaviour: Behaviour::Titles(vec!["x"]) },
        ]);
        let r = m.search("linux", 10, Duration::from_millis(100)).await.unwrap();
        assert_eq!(r.results.len(), 1);
        assert_eq!(r.providers[0].error.as_deref(), Some("timed out"));
        assert!(r.providers[1].ok);
    }

    #[tokio::test]
    async fn a_panicking_provider_is_contained() {
        let m = mgr(vec![
            Mock { id: "crash", behaviour: Behaviour::Panic },
            Mock { id: "fine", behaviour: Behaviour::Titles(vec!["ok"]) },
        ]);
        let r = m.search("linux", 10, Duration::from_secs(2)).await.unwrap();
        assert_eq!(r.results.len(), 1);
        assert!(!r.providers[0].ok);
        assert!(r.providers[1].ok);
    }

    #[tokio::test]
    async fn all_providers_failing_is_reported_per_provider() {
        let m = mgr(vec![
            Mock { id: "a", behaviour: Behaviour::Fail("offline") },
            Mock { id: "b", behaviour: Behaviour::Fail("offline") },
        ]);
        let r = m.search("linux", 10, Duration::from_secs(2)).await.unwrap();
        assert!(r.results.is_empty());
        assert!(r.providers.iter().all(|p| !p.ok));
    }

    #[tokio::test]
    async fn bad_queries_and_empty_provider_lists_are_rejected() {
        let m = mgr(vec![Mock { id: "a", behaviour: Behaviour::Titles(vec!["x"]) }]);
        assert!(m.search("a", 10, Duration::from_secs(1)).await.is_err());
        assert!(m.search("   ", 10, Duration::from_secs(1)).await.is_err());
        let long = "x".repeat(200);
        assert!(m.search(&long, 10, Duration::from_secs(1)).await.is_err());
        let empty = SearchManager::with_providers(Vec::new());
        assert!(empty.search("linux", 10, Duration::from_secs(1)).await.is_err());
    }

    #[tokio::test]
    async fn results_are_ordered_by_seeders_keeping_provider_order_on_ties() {
        let m = mgr(vec![
            Mock { id: "p1", behaviour: Behaviour::Titles(vec!["p1-top", "p1-second"]) },
            Mock { id: "p2", behaviour: Behaviour::Titles(vec!["p2-top"]) },
        ]);
        let r = m.search("linux", 10, Duration::from_secs(1)).await.unwrap();
        let titles: Vec<&str> = r.results.iter().map(|x| x.title.as_str()).collect();
        assert_eq!(titles, vec!["p1-top", "p2-top", "p1-second"]);
    }
}
