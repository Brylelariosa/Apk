//! Torznab provider: talks to any indexer (Prowlarr, Jackett, ...) that the
//! user configures in Settings. Torrix ships no indexer of its own; what the
//! user searches for there is their responsibility.

use async_trait::async_trait;
use reqwest::Client;

use super::SearchProvider;
use crate::http;
use crate::models::{SearchResult, TorznabConfig};

pub struct Torznab {
    client: Client,
    cfg: TorznabConfig,
}

impl Torznab {
    pub fn new(client: Client, cfg: TorznabConfig) -> Self {
        Self { client, cfg }
    }
}

fn category_name(value: &str) -> String {
    match value.trim().parse::<u32>() {
        Ok(id) => {
            let name = match id / 1000 {
                1 => "Console",
                2 => "Movies",
                3 => "Audio",
                4 => "PC",
                5 => "TV",
                6 => "Adult",
                7 => "Books",
                _ => "Other",
            };
            name.to_string()
        }
        Err(_) => value.trim().to_string(),
    }
}

fn is_http(url: &str) -> bool {
    let l = url.trim().to_ascii_lowercase();
    l.starts_with("http://") || l.starts_with("https://")
}

pub(crate) fn parse_torznab(body: &str, limit: usize) -> Result<Vec<SearchResult>, String> {
    let doc = roxmltree::Document::parse(body)
        .map_err(|_| "the indexer did not return valid XML".to_string())?;
    let root = doc.root_element();
    if root.tag_name().name() == "error" {
        let desc = root
            .attribute("description")
            .unwrap_or("the indexer reported an error");
        return Err(desc.to_string());
    }
    let mut out = Vec::new();
    for item in doc
        .descendants()
        .filter(|n| n.is_element() && n.tag_name().name() == "item")
    {
        let mut title = String::new();
        let mut link: Option<String> = None;
        let mut enclosure: Option<String> = None;
        let mut size: Option<u64> = None;
        let mut seeders: Option<u32> = None;
        let mut peers: Option<u32> = None;
        let mut magnet: Option<String> = None;
        let mut infohash: Option<String> = None;
        let mut category: Option<String> = None;
        let mut published: Option<String> = None;
        let mut details: Option<String> = None;

        for c in item.children().filter(|n| n.is_element()) {
            let text = c.text().map(|t| t.trim().to_string());
            match c.tag_name().name() {
                "title" => title = text.unwrap_or_default(),
                "link" => link = text,
                "comments" => details = text,
                "pubDate" => published = text,
                "size" => {
                    if let Some(s) = text.and_then(|t| t.parse::<u64>().ok()) {
                        size = Some(s);
                    }
                }
                "category" => {
                    if category.is_none() {
                        category = text;
                    }
                }
                "enclosure" => {
                    if let Some(u) = c.attribute("url") {
                        enclosure = Some(u.to_string());
                    }
                    if size.is_none() {
                        size = c.attribute("length").and_then(|l| l.parse::<u64>().ok());
                    }
                }
                "attr" => match (c.attribute("name"), c.attribute("value")) {
                    (Some("seeders"), Some(v)) => seeders = v.parse::<u32>().ok(),
                    (Some("peers"), Some(v)) => peers = v.parse::<u32>().ok(),
                    (Some("magneturl"), Some(v)) => magnet = Some(v.to_string()),
                    (Some("infohash"), Some(v)) => infohash = Some(v.to_ascii_lowercase()),
                    (Some("size"), Some(v)) => {
                        if let Ok(s) = v.parse::<u64>() {
                            size = Some(s);
                        }
                    }
                    (Some("category"), Some(v)) => {
                        if category.is_none() {
                            category = Some(category_name(v));
                        }
                    }
                    _ => {}
                },
                _ => {}
            }
        }
        if title.is_empty() {
            continue;
        }
        for candidate in [&link, &enclosure] {
            if magnet.is_none() {
                if let Some(c) = candidate {
                    if c.to_ascii_lowercase().starts_with("magnet:") {
                        magnet = Some(c.clone());
                    }
                }
            }
        }
        let torrent_url = enclosure
            .clone()
            .filter(|u| is_http(u))
            .or_else(|| link.clone().filter(|u| is_http(u)));
        if magnet.is_none() && torrent_url.is_none() {
            continue;
        }
        let leechers = match (peers, seeders) {
            (Some(p), Some(s)) => Some(p.saturating_sub(s)),
            _ => None,
        };
        out.push(
            SearchResult {
                provider: "Torznab indexer".to_string(),
                title,
                size_bytes: size,
                category: category.map(|c| category_name(&c)),
                seeders,
                leechers,
                magnet,
                torrent_url,
                info_hash: infohash.filter(|h| h.len() == 40),
                details_url: details.filter(|u| is_http(u)),
                published,
                ..Default::default()
            }
            .with_source(false),
        );
        if out.len() >= limit {
            break;
        }
    }
    Ok(out)
}

#[async_trait]
impl SearchProvider for Torznab {
    fn id(&self) -> &'static str {
        "torznab"
    }

    fn name(&self) -> &'static str {
        "Torznab indexer"
    }

    async fn search(&self, query: &str, limit: usize) -> Result<Vec<SearchResult>, String> {
        let url = self.cfg.url.trim();
        if !is_http(url) {
            return Err("the indexer address must start with http:// or https://".to_string());
        }
        let limit_s = limit.clamp(1, 100).to_string();
        let mut params: Vec<(&str, &str)> =
            vec![("t", "search"), ("q", query), ("limit", limit_s.as_str())];
        if !self.cfg.api_key.is_empty() {
            params.push(("apikey", self.cfg.api_key.as_str()));
        }
        let body = http::fetch_text_query(&self.client, url, &params, 4 * 1024 * 1024).await?;
        parse_torznab(&body, limit)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const FEED: &str = r#"<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:torznab="http://torznab.com/schemas/2015/feed">
 <channel>
  <title>Indexer</title>
  <item>
   <title>Example Linux ISO</title>
   <link>http://192.168.1.10:9696/dl/1/file.torrent</link>
   <pubDate>Mon, 01 Jan 2024 00:00:00 +0000</pubDate>
   <enclosure url="http://192.168.1.10:9696/dl/1/file.torrent" length="1073741824" type="application/x-bittorrent"/>
   <torznab:attr name="seeders" value="40"/>
   <torznab:attr name="peers" value="55"/>
   <torznab:attr name="category" value="4000"/>
   <torznab:attr name="magneturl" value="magnet:?xt=urn:btih:0123456789abcdef0123456789abcdef01234567"/>
   <torznab:attr name="infohash" value="0123456789ABCDEF0123456789ABCDEF01234567"/>
  </item>
  <item>
   <title></title>
   <link>http://x/y.torrent</link>
  </item>
  <item>
   <title>No links at all</title>
  </item>
 </channel>
</rss>"#;

    #[test]
    fn parses_items_and_attributes() {
        let r = parse_torznab(FEED, 10).unwrap();
        assert_eq!(r.len(), 1);
        let x = &r[0];
        assert_eq!(x.title, "Example Linux ISO");
        assert_eq!(x.size_bytes, Some(1_073_741_824));
        assert_eq!(x.seeders, Some(40));
        assert_eq!(x.leechers, Some(15));
        assert_eq!(x.category.as_deref(), Some("PC"));
        assert_eq!(x.info_hash.as_deref(), Some("0123456789abcdef0123456789abcdef01234567"));
        // magnet is preferred for Torznab results
        assert!(x.source.as_deref().unwrap().starts_with("magnet:"));
        assert!(x.torrent_url.as_deref().unwrap().starts_with("http://192.168.1.10"));
    }

    #[test]
    fn error_documents_become_errors() {
        let e = parse_torznab(r#"<error code="100" description="Incorrect user credentials"/>"#, 5)
            .unwrap_err();
        assert!(e.contains("credentials"));
    }

    #[test]
    fn invalid_xml_is_rejected() {
        assert!(parse_torznab("<rss><item>", 5).is_err());
        assert!(parse_torznab("", 5).is_err());
    }

    #[test]
    fn category_ids_map_to_names() {
        assert_eq!(category_name("2040"), "Movies");
        assert_eq!(category_name("5000"), "TV");
        assert_eq!(category_name("Games"), "Games");
    }
}
