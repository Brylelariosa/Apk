//! Linux distribution provider: official release torrents with large,
//! long-lived swarms. Arch Linux publishes a JSON feed, Debian publishes
//! .torrent files in a plain directory listing.

use std::collections::HashSet;

use async_trait::async_trait;
use reqwest::Client;
use serde_json::Value;

use super::{loose_u64, SearchProvider};
use crate::http;
use crate::models::SearchResult;

const PROVIDER_NAME: &str = "Linux distributions";
const CATEGORY: &str = "Linux distribution";

pub struct LinuxDistros {
    client: Client,
}

impl LinuxDistros {
    pub fn new(client: Client) -> Self {
        Self { client }
    }

    async fn arch(&self) -> Result<Vec<SearchResult>, String> {
        let body = http::fetch_text(
            &self.client,
            "https://archlinux.org/releng/releases/json/",
            4 * 1024 * 1024,
        )
        .await?;
        parse_arch(&body)
    }

    async fn debian(&self) -> Result<Vec<SearchResult>, String> {
        let mut out = Vec::new();
        let mut last_err: Option<String> = None;
        for arch in ["amd64", "arm64"] {
            let base = format!("https://cdimage.debian.org/debian-cd/current/{arch}/bt-cd/");
            match http::fetch_text(&self.client, &base, 512 * 1024).await {
                Ok(html) => out.extend(parse_debian(&html, &base)),
                Err(e) => last_err = Some(e),
            }
        }
        if out.is_empty() {
            Err(last_err.unwrap_or_else(|| "no torrents listed".to_string()))
        } else {
            Ok(out)
        }
    }
}

fn is_hex40(s: &str) -> bool {
    s.len() == 40 && s.bytes().all(|b| b.is_ascii_hexdigit())
}

pub(crate) fn parse_arch(body: &str) -> Result<Vec<SearchResult>, String> {
    let unexpected = || "unexpected response from archlinux.org".to_string();
    let v: Value = serde_json::from_str(body).map_err(|_| unexpected())?;
    let releases = v
        .get("releases")
        .and_then(Value::as_array)
        .ok_or_else(unexpected)?;
    let mut out = Vec::new();
    for r in releases {
        let version = match r.get("version").and_then(Value::as_str) {
            Some(v) => v,
            None => continue,
        };
        // Releases flagged unavailable may no longer have web seeds; skip them.
        if !r.get("available").and_then(Value::as_bool).unwrap_or(false) {
            continue;
        }
        let torrent = r.get("torrent");
        let info_hash = torrent
            .and_then(|t| t.get("info_hash"))
            .and_then(Value::as_str)
            .map(|s| s.to_ascii_lowercase())
            .filter(|s| is_hex40(s));
        let magnet = r
            .get("magnet_uri")
            .and_then(Value::as_str)
            .filter(|m| m.to_ascii_lowercase().contains("btih:"))
            .map(str::to_string)
            .or_else(|| {
                info_hash
                    .as_ref()
                    .map(|h| format!("magnet:?xt=urn:btih:{h}&dn=archlinux-{version}-x86_64.iso"))
            });
        let torrent_url = r
            .get("torrent_url")
            .and_then(Value::as_str)
            .map(|p| {
                if p.starts_with("http") {
                    p.to_string()
                } else {
                    format!("https://archlinux.org{p}")
                }
            });
        if magnet.is_none() && torrent_url.is_none() {
            continue;
        }
        out.push(
            SearchResult {
                provider: PROVIDER_NAME.to_string(),
                title: format!("Arch Linux {version} (x86_64 ISO)"),
                size_bytes: torrent.and_then(|t| t.get("file_length")).and_then(loose_u64),
                category: Some(CATEGORY.to_string()),
                magnet,
                torrent_url,
                info_hash,
                details_url: Some(format!("https://archlinux.org/releng/releases/{version}/")),
                published: r
                    .get("release_date")
                    .and_then(Value::as_str)
                    .map(str::to_string),
                ..Default::default()
            }
            .with_source(true),
        );
    }
    out.sort_by(|a, b| b.published.cmp(&a.published));
    Ok(out)
}

/// Every value of an `href="..."` / `href='...'` attribute in the page.
pub(crate) fn extract_hrefs(html: &str) -> Vec<String> {
    let lower = html.to_ascii_lowercase(); // same byte offsets as `html`
    let mut out = Vec::new();
    let mut from = 0usize;
    while let Some(pos) = lower[from..].find("href=") {
        let start = from + pos + 5;
        let rest = &html[start..];
        match rest.chars().next() {
            Some(q) if q == '"' || q == '\'' => match rest[1..].find(q) {
                Some(end) => {
                    out.push(rest[1..1 + end].to_string());
                    from = start + 1 + end + 1;
                }
                None => break,
            },
            _ => from = start,
        }
    }
    out
}

pub(crate) fn parse_debian(html: &str, base: &str) -> Vec<SearchResult> {
    let mut seen = HashSet::new();
    let mut out = Vec::new();
    for href in extract_hrefs(html) {
        let lower = href.to_ascii_lowercase();
        if !lower.ends_with(".torrent") || href.contains('/') || href.contains("..") {
            continue;
        }
        if !seen.insert(href.clone()) {
            continue;
        }
        let title = href[..href.len() - ".torrent".len()].to_string();
        out.push(
            SearchResult {
                provider: PROVIDER_NAME.to_string(),
                title,
                category: Some(CATEGORY.to_string()),
                torrent_url: Some(format!("{base}{href}")),
                details_url: Some(base.to_string()),
                ..Default::default()
            }
            .with_source(true),
        );
    }
    out
}

fn matches_tokens(r: &SearchResult, tokens: &[String]) -> bool {
    let hay = format!("{} linux distribution iso", r.title).to_lowercase();
    tokens.iter().all(|t| hay.contains(t.as_str()))
}

#[async_trait]
impl SearchProvider for LinuxDistros {
    fn id(&self) -> &'static str {
        "linux_distros"
    }

    fn name(&self) -> &'static str {
        PROVIDER_NAME
    }

    async fn search(&self, query: &str, limit: usize) -> Result<Vec<SearchResult>, String> {
        let (arch, debian) = tokio::join!(self.arch(), self.debian());
        let mut all: Vec<SearchResult> = Vec::new();
        let mut errors: Vec<String> = Vec::new();
        match arch {
            Ok(mut v) => all.append(&mut v),
            Err(e) => errors.push(format!("Arch Linux: {e}")),
        }
        match debian {
            Ok(mut v) => all.append(&mut v),
            Err(e) => errors.push(format!("Debian: {e}")),
        }
        if all.is_empty() && !errors.is_empty() {
            return Err(errors.join("; "));
        }
        let tokens: Vec<String> = query.split_whitespace().map(|t| t.to_lowercase()).collect();
        let mut out: Vec<SearchResult> = all
            .into_iter()
            .filter(|r| matches_tokens(r, &tokens))
            .collect();
        out.truncate(limit);
        Ok(out)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn hrefs_are_extracted_with_both_quote_styles() {
        let html = r#"<a HREF="debian-13.5.0-amd64-netinst.iso.torrent">x</a> <a href='SHA256SUMS'>y</a> <a href=bare>z</a>"#;
        let hrefs = extract_hrefs(html);
        assert_eq!(hrefs, vec!["debian-13.5.0-amd64-netinst.iso.torrent", "SHA256SUMS"]);
    }

    #[test]
    fn unterminated_attribute_does_not_loop() {
        assert!(extract_hrefs("<a href=\"never-ends").is_empty());
        assert!(extract_hrefs("href=").is_empty());
    }

    #[test]
    fn debian_listing_yields_only_torrent_files() {
        let html = r#"<a href="../">Parent</a>
            <a href="debian-13.5.0-amd64-netinst.iso.torrent">a</a>
            <a href="debian-edu-13.5.0-amd64-netinst.iso.torrent">b</a>
            <a href="debian-13.5.0-amd64-netinst.iso.torrent">dup</a>
            <a href="SHA256SUMS">c</a>
            <a href="sub/evil.torrent">d</a>"#;
        let r = parse_debian(html, "https://cdimage.debian.org/debian-cd/current/amd64/bt-cd/");
        assert_eq!(r.len(), 2);
        assert_eq!(r[0].title, "debian-13.5.0-amd64-netinst.iso");
        assert_eq!(
            r[0].source.as_deref(),
            Some("https://cdimage.debian.org/debian-cd/current/amd64/bt-cd/debian-13.5.0-amd64-netinst.iso.torrent")
        );
    }

    #[test]
    fn arch_feed_is_parsed_and_unavailable_releases_are_skipped() {
        let body = r#"{"version":1,"releases":[
          {"version":"2026.10.01","release_date":"2026-10-01","available":true,
           "magnet_uri":"magnet:?xt=urn:btih:9b521219bc48550140a666f74a29048ed78e933b&dn=archlinux-2026.10.01-x86_64.iso",
           "torrent_url":"/releng/releases/2026.10.01/torrent/",
           "torrent":{"info_hash":"9b521219bc48550140a666f74a29048ed78e933b","file_length":1610612736}},
          {"version":"2020.01.01","release_date":"2020-01-01","available":false,"magnet_uri":"magnet:?xt=urn:btih:aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"},
          {"release_date":"2025-01-01","available":true}
        ]}"#;
        let r = parse_arch(body).unwrap();
        assert_eq!(r.len(), 1);
        assert_eq!(r[0].title, "Arch Linux 2026.10.01 (x86_64 ISO)");
        assert_eq!(r[0].size_bytes, Some(1_610_612_736));
        assert_eq!(
            r[0].source.as_deref(),
            Some("https://archlinux.org/releng/releases/2026.10.01/torrent/")
        );
        assert!(r[0].magnet.as_deref().unwrap().contains("btih:9b52"));
    }

    #[test]
    fn arch_feed_garbage_is_an_error() {
        assert!(parse_arch("<html>").is_err());
        assert!(parse_arch("{}").is_err());
    }

    #[test]
    fn token_filter_requires_all_words() {
        let r = SearchResult { title: "debian-13.5.0-amd64-netinst.iso".into(), ..Default::default() };
        assert!(matches_tokens(&r, &["debian".into(), "netinst".into()]));
        assert!(!matches_tokens(&r, &["debian".into(), "arch".into()]));
        assert!(matches_tokens(&r, &["linux".into()]));
    }
}
