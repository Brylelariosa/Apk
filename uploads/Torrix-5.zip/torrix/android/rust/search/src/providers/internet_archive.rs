//! Internet Archive provider (public-domain and openly licensed media).
//! Uses the documented advancedsearch JSON endpoint; each item exposes a
//! derived `<identifier>_archive.torrent` file.

use async_trait::async_trait;
use reqwest::Client;
use serde_json::Value;

use super::{first_string, loose_u64, SearchProvider};
use crate::http;
use crate::models::SearchResult;

pub struct InternetArchive {
    client: Client,
}

impl InternetArchive {
    pub fn new(client: Client) -> Self {
        Self { client }
    }
}

/// Keep only plain words so user input cannot inject query syntax.
fn clean_query(q: &str) -> String {
    let cleaned: String = q
        .chars()
        .map(|c| {
            if c.is_alphanumeric() || c == '-' || c == '_' || c == '.' {
                c
            } else {
                ' '
            }
        })
        .collect();
    cleaned.split_whitespace().collect::<Vec<_>>().join(" ")
}

fn identifier_ok(id: &str) -> bool {
    !id.is_empty()
        && id.len() <= 200
        && id
            .chars()
            .all(|c| c.is_ascii_alphanumeric() || matches!(c, '_' | '-' | '.'))
}

pub(crate) fn parse_results(body: &str, limit: usize) -> Result<Vec<SearchResult>, String> {
    let unexpected = || "unexpected response from the Internet Archive".to_string();
    let v: Value = serde_json::from_str(body).map_err(|_| unexpected())?;
    if let Some(err) = v.get("error").and_then(Value::as_str) {
        return Err(format!("Internet Archive: {err}"));
    }
    let docs = v
        .pointer("/response/docs")
        .and_then(Value::as_array)
        .ok_or_else(unexpected)?;
    let mut out = Vec::new();
    for d in docs {
        let id = match d.get("identifier").and_then(Value::as_str) {
            Some(i) if identifier_ok(i) => i,
            _ => continue,
        };
        let title = d
            .get("title")
            .and_then(first_string)
            .unwrap_or_else(|| id.to_string());
        let result = SearchResult {
            provider: "Internet Archive".to_string(),
            title,
            size_bytes: d.get("item_size").and_then(loose_u64),
            category: d.get("mediatype").and_then(first_string),
            torrent_url: Some(format!(
                "https://archive.org/download/{id}/{id}_archive.torrent"
            )),
            details_url: Some(format!("https://archive.org/details/{id}")),
            published: d.get("publicdate").and_then(first_string),
            ..Default::default()
        }
        .with_source(true);
        out.push(result);
        if out.len() >= limit {
            break;
        }
    }
    Ok(out)
}

#[async_trait]
impl SearchProvider for InternetArchive {
    fn id(&self) -> &'static str {
        "internet_archive"
    }

    fn name(&self) -> &'static str {
        "Internet Archive"
    }

    async fn search(&self, query: &str, limit: usize) -> Result<Vec<SearchResult>, String> {
        let clean = clean_query(query);
        if clean.is_empty() {
            return Err("the search has no usable words".to_string());
        }
        let q = format!("({clean}) AND NOT mediatype:collection");
        let rows = limit.clamp(1, 50).to_string();
        let params = [
            ("q", q.as_str()),
            ("fl[]", "identifier"),
            ("fl[]", "title"),
            ("fl[]", "mediatype"),
            ("fl[]", "item_size"),
            ("fl[]", "publicdate"),
            ("sort[]", "downloads desc"),
            ("rows", rows.as_str()),
            ("page", "1"),
            ("output", "json"),
        ];
        let body = http::fetch_text_query(
            &self.client,
            "https://archive.org/advancedsearch.php",
            &params,
            2 * 1024 * 1024,
        )
        .await?;
        parse_results(&body, limit)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn query_is_reduced_to_plain_words() {
        assert_eq!(clean_query("  night of the (living) dead  "), "night of the living dead");
        assert_eq!(clean_query("a:b OR c"), "a b OR c");
        assert_eq!(clean_query("()[]{}\"\\"), "");
    }

    #[test]
    fn parses_documents_and_builds_torrent_links() {
        let body = r#"{"responseHeader":{"status":0},"response":{"numFound":2,"start":0,"docs":[
            {"identifier":"night_of_the_living_dead","title":"Night of the Living Dead","mediatype":"movies","item_size":1234567890,"publicdate":"2008-01-01T00:00:00Z"},
            {"identifier":"bad id with spaces","title":"x"},
            {"identifier":"plain-text_1","title":["First","Second"],"mediatype":"texts","item_size":"2048"}
        ]}}"#;
        let r = parse_results(body, 10).unwrap();
        assert_eq!(r.len(), 2);
        assert_eq!(r[0].title, "Night of the Living Dead");
        assert_eq!(r[0].size_bytes, Some(1_234_567_890));
        assert_eq!(
            r[0].source.as_deref(),
            Some("https://archive.org/download/night_of_the_living_dead/night_of_the_living_dead_archive.torrent")
        );
        assert_eq!(r[1].title, "First");
        assert_eq!(r[1].size_bytes, Some(2048));
    }

    #[test]
    fn limit_is_respected() {
        let body = r#"{"response":{"docs":[{"identifier":"a"},{"identifier":"b"},{"identifier":"c"}]}}"#;
        assert_eq!(parse_results(body, 2).unwrap().len(), 2);
    }

    #[test]
    fn malformed_and_error_bodies_fail_cleanly() {
        assert!(parse_results("not json", 5).is_err());
        assert!(parse_results("{}", 5).is_err());
        let e = parse_results(r#"{"error":"bad query"}"#, 5).unwrap_err();
        assert!(e.contains("bad query"));
    }
}
