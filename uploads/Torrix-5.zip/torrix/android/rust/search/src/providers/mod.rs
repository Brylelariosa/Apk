use async_trait::async_trait;
use serde_json::Value;

use crate::models::SearchResult;

pub mod internet_archive;
pub mod linux_distros;
pub mod torznab;

/// A source of torrent search results. Implementations must never panic on
/// unexpected input: return `Err` with a short, user-readable message.
#[async_trait]
pub trait SearchProvider: Send + Sync {
    fn id(&self) -> &'static str;
    fn name(&self) -> &'static str;
    async fn search(&self, query: &str, limit: usize) -> Result<Vec<SearchResult>, String>;
}

/// Numbers show up as JSON numbers or strings depending on the source.
pub(crate) fn loose_u64(v: &Value) -> Option<u64> {
    match v {
        Value::Number(n) => n
            .as_u64()
            .or_else(|| n.as_f64().filter(|f| *f >= 0.0).map(|f| f as u64)),
        Value::String(s) => s.trim().parse::<u64>().ok(),
        _ => None,
    }
}

/// First non-empty string of a value that may be a string or an array of strings.
pub(crate) fn first_string(v: &Value) -> Option<String> {
    match v {
        Value::String(s) => {
            let t = s.trim();
            if t.is_empty() {
                None
            } else {
                Some(t.to_string())
            }
        }
        Value::Array(a) => a.iter().find_map(first_string),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn loose_numbers() {
        assert_eq!(loose_u64(&json!(42)), Some(42));
        assert_eq!(loose_u64(&json!("42")), Some(42));
        assert_eq!(loose_u64(&json!(1.0e3)), Some(1000));
        assert_eq!(loose_u64(&json!(-1)), None);
        assert_eq!(loose_u64(&json!("abc")), None);
        assert_eq!(loose_u64(&json!(null)), None);
    }

    #[test]
    fn first_string_handles_arrays() {
        assert_eq!(first_string(&json!("  hi ")), Some("hi".to_string()));
        assert_eq!(first_string(&json!(["", "second"])), Some("second".to_string()));
        assert_eq!(first_string(&json!([])), None);
        assert_eq!(first_string(&json!(7)), None);
    }
}
