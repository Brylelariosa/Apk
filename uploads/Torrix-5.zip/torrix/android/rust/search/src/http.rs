//! Small HTTP helpers shared by the search providers and the engine.
//! Responses are size-capped and read in chunks so a hostile server cannot
//! make the app buffer an unbounded amount of data.

use std::net::IpAddr;
use std::time::Duration;

use reqwest::{Client, RequestBuilder};

pub const USER_AGENT: &str = concat!("Torrix/", env!("CARGO_PKG_VERSION"));

/// True for loopback / private / link-local literal addresses and local names.
pub fn is_private_host(host: &str) -> bool {
    let host = host.trim_start_matches('[').trim_end_matches(']');
    if host == "localhost" || host.ends_with(".localhost") || host.ends_with(".local") {
        return true;
    }
    match host.parse::<IpAddr>() {
        Ok(IpAddr::V4(v4)) => {
            let o = v4.octets();
            v4.is_private()
                || v4.is_loopback()
                || v4.is_link_local()
                || v4.is_unspecified()
                || (o[0] == 100 && (o[1] & 0xC0) == 64) // 100.64.0.0/10 carrier-grade NAT
        }
        Ok(IpAddr::V6(v6)) => {
            let seg = v6.segments();
            v6.is_loopback()
                || v6.is_unspecified()
                || (seg[0] & 0xfe00) == 0xfc00 // unique local
                || (seg[0] & 0xffc0) == 0xfe80 // link local
        }
        Err(_) => false,
    }
}

pub fn client() -> Result<Client, String> {
    // A public server must not be able to bounce us onto the user's local
    // network with a redirect. (Servers that are already local may redirect.)
    let policy = reqwest::redirect::Policy::custom(|attempt| {
        if attempt.previous().len() >= 5 {
            return attempt.error("too many redirects");
        }
        let target_private = attempt.url().host_str().map(is_private_host).unwrap_or(false);
        let origin_private = attempt
            .previous()
            .first()
            .and_then(|u| u.host_str())
            .map(is_private_host)
            .unwrap_or(false);
        if target_private && !origin_private {
            attempt.stop()
        } else {
            attempt.follow()
        }
    });
    Client::builder()
        .user_agent(USER_AGENT)
        .connect_timeout(Duration::from_secs(8))
        .timeout(Duration::from_secs(20))
        .redirect(policy)
        .build()
        .map_err(|e| format!("could not create HTTP client: {}", describe(e)))
}

/// Error text without the request URL: URLs can carry API keys.
fn describe(e: reqwest::Error) -> String {
    let e = e.without_url();
    if e.is_timeout() {
        "timed out".to_string()
    } else if e.is_connect() {
        "could not connect".to_string()
    } else {
        e.to_string()
    }
}

fn check_scheme(url: &str) -> Result<(), String> {
    let lower = url.trim().to_ascii_lowercase();
    if lower.starts_with("http://") || lower.starts_with("https://") {
        Ok(())
    } else {
        Err("only http and https addresses are supported".to_string())
    }
}

async fn read_response(req: RequestBuilder, max_bytes: usize) -> Result<Vec<u8>, String> {
    let mut resp = req.send().await.map_err(describe)?;
    let status = resp.status();
    if !status.is_success() {
        return Err(format!("server answered HTTP {}", status.as_u16()));
    }
    if let Some(len) = resp.content_length() {
        if len > max_bytes as u64 {
            return Err("response is too large".to_string());
        }
    }
    let mut out: Vec<u8> = Vec::new();
    while let Some(chunk) = resp.chunk().await.map_err(describe)? {
        if out.len() + chunk.len() > max_bytes {
            return Err("response is too large".to_string());
        }
        out.extend_from_slice(&chunk);
    }
    Ok(out)
}

pub async fn fetch_bytes(client: &Client, url: &str, max_bytes: usize) -> Result<Vec<u8>, String> {
    check_scheme(url)?;
    read_response(client.get(url.trim()), max_bytes).await
}

pub async fn fetch_text(client: &Client, url: &str, max_bytes: usize) -> Result<String, String> {
    let bytes = fetch_bytes(client, url, max_bytes).await?;
    Ok(String::from_utf8_lossy(&bytes).into_owned())
}

pub async fn fetch_text_query(
    client: &Client,
    url: &str,
    query: &[(&str, &str)],
    max_bytes: usize,
) -> Result<String, String> {
    check_scheme(url)?;
    let bytes = read_response(client.get(url.trim()).query(query), max_bytes).await?;
    Ok(String::from_utf8_lossy(&bytes).into_owned())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn private_hosts_include_bracketed_ipv6() {
        for h in ["localhost", "nas.local", "127.0.0.1", "10.0.0.2", "192.168.1.1", "[::1]", "[fd12::1]", "169.254.0.5", "100.64.1.1"] {
            assert!(is_private_host(h), "{h}");
        }
        for h in ["archive.org", "93.184.216.34", "[2001:4860:4860::8888]", "100.128.0.1"] {
            assert!(!is_private_host(h), "{h}");
        }
    }

    #[test]
    fn only_http_schemes_pass() {
        assert!(check_scheme("https://example.org/a").is_ok());
        assert!(check_scheme("  HTTP://example.org").is_ok());
        assert!(check_scheme("file:///etc/passwd").is_err());
        assert!(check_scheme("ftp://example.org").is_err());
        assert!(check_scheme("magnet:?xt=urn:btih:abc").is_err());
    }
}
