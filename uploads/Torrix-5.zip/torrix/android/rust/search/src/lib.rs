//! Pluggable torrent search for Torrix.
//!
//! Every provider lives in its own module under `providers/` and implements
//! [`providers::SearchProvider`]. [`SearchManager`] runs all enabled providers
//! concurrently, isolates their failures and merges the results.

pub mod http;
pub mod models;
pub mod providers;
pub mod search_manager;

pub use models::{ProviderStatus, SearchConfig, SearchResponse, SearchResult, TorznabConfig};
pub use search_manager::SearchManager;
