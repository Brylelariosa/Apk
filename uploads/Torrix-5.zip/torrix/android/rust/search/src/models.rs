use serde::Serialize;

/// One search hit. `source` is what the download manager should be given
/// (a magnet link or an http(s) URL of a .torrent file).
#[derive(Debug, Clone, Serialize, Default, PartialEq)]
pub struct SearchResult {
    pub provider: String,
    pub title: String,
    pub size_bytes: Option<u64>,
    pub category: Option<String>,
    pub seeders: Option<u32>,
    pub leechers: Option<u32>,
    pub magnet: Option<String>,
    pub torrent_url: Option<String>,
    pub info_hash: Option<String>,
    pub details_url: Option<String>,
    pub published: Option<String>,
    pub source: Option<String>,
}

impl SearchResult {
    /// Fill `source` from the magnet / torrent URL, preferring one of them.
    pub fn with_source(mut self, prefer_torrent_url: bool) -> Self {
        self.source = if prefer_torrent_url {
            self.torrent_url.clone().or_else(|| self.magnet.clone())
        } else {
            self.magnet.clone().or_else(|| self.torrent_url.clone())
        };
        self
    }
}

#[derive(Debug, Clone, Serialize)]
pub struct ProviderStatus {
    pub id: String,
    pub name: String,
    pub ok: bool,
    pub count: usize,
    pub error: Option<String>,
    pub elapsed_ms: u64,
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct SearchResponse {
    pub query: String,
    pub results: Vec<SearchResult>,
    pub providers: Vec<ProviderStatus>,
}

#[derive(Debug, Clone)]
pub struct TorznabConfig {
    pub url: String,
    pub api_key: String,
}

#[derive(Debug, Clone, Default)]
pub struct SearchConfig {
    pub internet_archive: bool,
    pub linux_distros: bool,
    pub torznab: Option<TorznabConfig>,
}
