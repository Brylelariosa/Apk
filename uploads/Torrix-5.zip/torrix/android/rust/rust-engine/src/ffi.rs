//! JNI bridge. Exactly one native method is exposed to Kotlin
//! (`NativeBridge.nativeCall`); everything else is JSON over that call, which
//! keeps the unsafe surface tiny and the Kotlin <-> Rust contract in one place.

use jni::objects::{JClass, JString};
use jni::sys::jstring;
use jni::JNIEnv;

#[no_mangle]
pub extern "system" fn Java_com_torrix_app_engine_NativeBridge_nativeCall<'local>(
    mut env: JNIEnv<'local>,
    _class: JClass<'local>,
    method: JString<'local>,
    args: JString<'local>,
) -> jstring {
    let method: String = match env.get_string(&method) {
        Ok(s) => s.into(),
        Err(_) => String::new(),
    };
    let args: String = match env.get_string(&args) {
        Ok(s) => s.into(),
        Err(_) => String::new(),
    };
    let answer = crate::call(&method, &args);
    match env.new_string(answer) {
        Ok(s) => s.into_raw(),
        Err(_) => std::ptr::null_mut(),
    }
}
