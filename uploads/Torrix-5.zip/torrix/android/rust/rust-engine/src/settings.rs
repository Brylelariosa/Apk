//! Engine settings. Kotlin owns the UI and sends the full settings object;
//! values are clamped here so a bad value can never reach the engine.

use std::io;
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::{magnet, storage};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    /// Torrents that may download at the same time (1..=10).
    pub max_active_downloads: u32,
    /// 0 = unlimited.
    pub download_limit_kib: u32,
    /// 0 = unlimited.
    pub upload_limit_kib: u32,
    pub dht_enabled: bool,
    /// First TCP port to listen on (a range of 10 is tried). 0 = do not listen.
    pub listen_port: u16,
    pub seed_after_complete: bool,
    /// How long to wait for a magnet link's metadata.
    pub resolve_timeout_secs: u32,
    pub internet_archive_enabled: bool,
    pub linux_distros_enabled: bool,
    pub torznab_url: String,
    pub torznab_api_key: String,
}

impl Default for Settings {
    fn default() -> Self {
        Settings {
            max_active_downloads: 3,
            download_limit_kib: 0,
            upload_limit_kib: 0,
            dht_enabled: true,
            listen_port: 6881,
            seed_after_complete: false,
            resolve_timeout_secs: 120,
            internet_archive_enabled: true,
            linux_distros_enabled: true,
            torznab_url: String::new(),
            torznab_api_key: String::new(),
        }
    }
}

impl Settings {
    pub fn sanitized(mut self) -> Self {
        self.max_active_downloads = self.max_active_downloads.clamp(1, 10);
        self.download_limit_kib = self.download_limit_kib.min(1_000_000);
        self.upload_limit_kib = self.upload_limit_kib.min(1_000_000);
        if self.listen_port != 0 && !(1024..=65_000).contains(&self.listen_port) {
            self.listen_port = 6881;
        }
        self.resolve_timeout_secs = self.resolve_timeout_secs.clamp(15, 600);
        self.torznab_url = self.torznab_url.trim().to_string();
        self.torznab_api_key = self.torznab_api_key.trim().to_string();
        if self.torznab_url.len() > 1024 {
            self.torznab_url.clear();
        }
        if self.torznab_api_key.len() > 256 {
            self.torznab_api_key.clear();
        }
        self
    }

    /// Host of the user's own indexer: allowed to be on the local network.
    pub fn torznab_host(&self) -> Option<String> {
        magnet::url_host(&self.torznab_url)
    }

    pub fn load(path: &Path) -> Option<Settings> {
        let data = std::fs::read(path).ok()?;
        serde_json::from_slice::<Settings>(&data)
            .ok()
            .map(Settings::sanitized)
    }

    pub fn save(&self, path: &Path) -> io::Result<()> {
        let data = serde_json::to_vec_pretty(self).map_err(io::Error::other)?;
        storage::atomic_write(path, &data)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_file(tag: &str) -> std::path::PathBuf {
        let d = std::env::temp_dir().join(format!("torrix-settings-{}-{}", std::process::id(), tag));
        let _ = std::fs::remove_dir_all(&d);
        std::fs::create_dir_all(&d).unwrap();
        d.join("settings.json")
    }

    #[test]
    fn defaults_are_conservative() {
        let s = Settings::default();
        assert_eq!(s.max_active_downloads, 3);
        assert_eq!(s.download_limit_kib, 0);
        assert!(s.dht_enabled);
        assert!(!s.seed_after_complete);
        assert_eq!(s, s.clone().sanitized());
    }

    #[test]
    fn out_of_range_values_are_clamped() {
        let s = Settings {
            max_active_downloads: 0,
            download_limit_kib: u32::MAX,
            upload_limit_kib: 5_000_000,
            listen_port: 80,
            resolve_timeout_secs: 1,
            torznab_url: "  http://nas:9696/api  ".into(),
            torznab_api_key: "  key ".into(),
            ..Settings::default()
        }
        .sanitized();
        assert_eq!(s.max_active_downloads, 1);
        assert_eq!(s.download_limit_kib, 1_000_000);
        assert_eq!(s.upload_limit_kib, 1_000_000);
        assert_eq!(s.listen_port, 6881);
        assert_eq!(s.resolve_timeout_secs, 15);
        assert_eq!(s.torznab_url, "http://nas:9696/api");
        assert_eq!(s.torznab_api_key, "key");
        let s2 = Settings { max_active_downloads: 99, listen_port: 0, resolve_timeout_secs: 9999, ..Settings::default() }.sanitized();
        assert_eq!(s2.max_active_downloads, 10);
        assert_eq!(s2.listen_port, 0, "0 means do not listen");
        assert_eq!(s2.resolve_timeout_secs, 600);
    }

    #[test]
    fn partial_json_falls_back_to_defaults_and_ignores_unknown_keys() {
        let s: Settings = serde_json::from_str(r#"{"max_active_downloads":5,"something_new":true}"#).unwrap();
        assert_eq!(s.max_active_downloads, 5);
        assert_eq!(s.upload_limit_kib, 0);
        assert!(s.linux_distros_enabled);
    }

    #[test]
    fn save_and_load_round_trip() {
        let f = temp_file("roundtrip");
        let s = Settings { max_active_downloads: 7, upload_limit_kib: 250, torznab_url: "https://idx.example/api".into(), ..Settings::default() };
        s.save(&f).unwrap();
        assert_eq!(Settings::load(&f), Some(s));
        let _ = std::fs::remove_dir_all(f.parent().unwrap());
    }

    #[test]
    fn corrupt_or_missing_files_load_as_none() {
        let f = temp_file("corrupt");
        assert_eq!(Settings::load(&f), None);
        std::fs::write(&f, b"{ not json").unwrap();
        assert_eq!(Settings::load(&f), None);
        let _ = std::fs::remove_dir_all(f.parent().unwrap());
    }

    #[test]
    fn torznab_host_is_extracted() {
        let s = Settings { torznab_url: "http://192.168.1.10:9696/api".into(), ..Settings::default() };
        assert_eq!(s.torznab_host().as_deref(), Some("192.168.1.10"));
        assert_eq!(Settings::default().torznab_host(), None);
    }
}
