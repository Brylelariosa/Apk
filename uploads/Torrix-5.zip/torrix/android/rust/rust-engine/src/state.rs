//! App-level torrent state that survives restarts.
//!
//! librqbit persists the torrents themselves (info hash, selected files,
//! output folder, piece bitfield through "fastresume"). This file adds what
//! the engine cannot know: whether the *user* paused a torrent (as opposed to
//! the queue pausing it), and when it was added / completed.

use std::collections::BTreeMap;
use std::io;
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::storage;

pub const STATE_VERSION: u32 = 1;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(default)]
pub struct TorrentRecord {
    /// The user asked for this torrent to stay paused.
    pub hold: bool,
    pub added_ms: u64,
    pub completed_ms: Option<u64>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
pub struct AppState {
    pub version: u32,
    /// Keyed by lowercase info hash.
    pub torrents: BTreeMap<String, TorrentRecord>,
}

impl Default for AppState {
    fn default() -> Self {
        AppState {
            version: STATE_VERSION,
            torrents: BTreeMap::new(),
        }
    }
}

impl AppState {
    /// Missing file -> empty state. Corrupt file -> kept as `*.corrupt` and an
    /// empty state is used, so one bad write can never block startup.
    pub fn load(path: &Path) -> AppState {
        match std::fs::read(path) {
            Ok(data) => match serde_json::from_slice::<AppState>(&data) {
                Ok(s) => s,
                Err(_) => {
                    let _ = std::fs::rename(path, path.with_extension("corrupt"));
                    AppState::default()
                }
            },
            Err(_) => AppState::default(),
        }
    }

    pub fn save(&self, path: &Path) -> io::Result<()> {
        let data = serde_json::to_vec(self).map_err(io::Error::other)?;
        storage::atomic_write(path, &data)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_dir(tag: &str) -> std::path::PathBuf {
        let d = std::env::temp_dir().join(format!("torrix-state-{}-{}", std::process::id(), tag));
        let _ = std::fs::remove_dir_all(&d);
        std::fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn state_survives_a_restart() {
        let d = temp_dir("restart");
        let f = d.join("state.json");
        let mut s = AppState::default();
        s.torrents.insert(
            "da39a3ee5e6b4b0d3255bfef95601890afd80709".into(),
            TorrentRecord { hold: true, added_ms: 1_700_000_000_000, completed_ms: Some(1_700_000_900_000) },
        );
        s.torrents.insert("0123456789abcdef0123456789abcdef01234567".into(), TorrentRecord::default());
        s.save(&f).unwrap();
        let loaded = AppState::load(&f);
        assert_eq!(loaded, s);
        assert!(loaded.torrents["da39a3ee5e6b4b0d3255bfef95601890afd80709"].hold);
        let _ = std::fs::remove_dir_all(&d);
    }

    #[test]
    fn missing_file_gives_empty_state() {
        let d = temp_dir("missing");
        let s = AppState::load(&d.join("nope.json"));
        assert!(s.torrents.is_empty());
        assert_eq!(s.version, STATE_VERSION);
        let _ = std::fs::remove_dir_all(&d);
    }

    #[test]
    fn corrupt_file_is_preserved_and_replaced_by_empty_state() {
        let d = temp_dir("corrupt");
        let f = d.join("state.json");
        std::fs::write(&f, b"{\"torrents\": [oops").unwrap();
        let s = AppState::load(&f);
        assert!(s.torrents.is_empty());
        assert!(f.with_extension("corrupt").exists());
        let _ = std::fs::remove_dir_all(&d);
    }

    #[test]
    fn older_files_with_missing_fields_still_load() {
        let d = temp_dir("older");
        let f = d.join("state.json");
        std::fs::write(&f, br#"{"torrents":{"aa":{"hold":true}}}"#).unwrap();
        let s = AppState::load(&f);
        assert!(s.torrents["aa"].hold);
        assert_eq!(s.torrents["aa"].added_ms, 0);
        assert_eq!(s.version, STATE_VERSION);
        let _ = std::fs::remove_dir_all(&d);
    }

    #[test]
    fn saves_are_atomic_and_leave_no_temp_file() {
        let d = temp_dir("atomic");
        let f = d.join("state.json");
        AppState::default().save(&f).unwrap();
        AppState::default().save(&f).unwrap();
        assert!(!f.with_extension("tmp").exists());
        let _ = std::fs::remove_dir_all(&d);
    }
}
