//! Tiny in-memory log. Android users usually cannot read logcat, so the last
//! few hundred warnings/errors are kept here and shown in Settings ->
//! Diagnostics. Nothing sensitive is ever logged (no magnet links, keys or
//! file names): callers pass short generic messages only.
//!
//! Every line is also sent to Android's logcat (tag `TorrixEngine`). After a
//! crash in native code this in-memory buffer is gone, but the app copies its
//! own logcat into the Download-folder log on the next start, so the lines
//! written just before the crash are not lost.

use std::collections::VecDeque;
use std::sync::Mutex;

const MAX_LINES: usize = 300;

static LINES: Mutex<VecDeque<String>> = Mutex::new(VecDeque::new());

/// Mirror to logcat on Android; does nothing elsewhere (host unit tests).
#[cfg(target_os = "android")]
mod android {
    use std::ffi::CString;
    use std::os::raw::{c_char, c_int};

    #[link(name = "log")]
    extern "C" {
        fn __android_log_write(prio: c_int, tag: *const c_char, text: *const c_char) -> c_int;
    }

    /// `prio`: 4 = info, 5 = warn, 6 = error.
    pub fn write(prio: i32, msg: &str) {
        let clean: String = msg.chars().filter(|c| *c != '\0').collect();
        if let (Ok(tag), Ok(text)) = (CString::new("TorrixEngine"), CString::new(clean)) {
            // SAFETY: both pointers come from live, NUL-terminated CStrings.
            unsafe {
                __android_log_write(prio as c_int, tag.as_ptr(), text.as_ptr());
            }
        }
    }
}

#[cfg(not(target_os = "android"))]
mod android {
    pub fn write(_prio: i32, _msg: &str) {}
}

pub fn push(line: String) {
    if let Ok(mut g) = LINES.lock() {
        if g.len() >= MAX_LINES {
            g.pop_front();
        }
        g.push_back(line);
    }
}

/// Store a line and mirror it to logcat with the given Android priority.
fn push_p(prio: i32, line: String) {
    android::write(prio, &line);
    push(line);
}

pub fn lines() -> Vec<String> {
    LINES
        .lock()
        .map(|g| g.iter().cloned().collect())
        .unwrap_or_default()
}

pub fn info(msg: impl AsRef<str>) {
    push_p(4, format!("{} I {}", crate::now_ms(), msg.as_ref()));
}

pub fn warn(msg: impl AsRef<str>) {
    push_p(5, format!("{} W {}", crate::now_ms(), msg.as_ref()));
}

pub fn error(msg: impl AsRef<str>) {
    push_p(6, format!("{} E {}", crate::now_ms(), msg.as_ref()));
}

struct RingLogger;

impl log::Log for RingLogger {
    fn enabled(&self, metadata: &log::Metadata) -> bool {
        metadata.level() <= log::Level::Warn
    }

    fn log(&self, record: &log::Record) {
        if self.enabled(record.metadata()) {
            let prio = match record.level() {
                log::Level::Error => 6,
                log::Level::Warn => 5,
                _ => 4,
            };
            push_p(
                prio,
                format!(
                    "{} {} {}: {}",
                    crate::now_ms(),
                    record.level(),
                    record.target(),
                    record.args()
                ),
            );
        }
    }

    fn flush(&self) {}
}

static LOGGER: RingLogger = RingLogger;

/// Route `log` records (and librqbit's tracing events, through tracing's `log`
/// feature) into the ring buffer, and keep panic messages.
pub fn init() {
    let _ = log::set_logger(&LOGGER);
    log::set_max_level(log::LevelFilter::Warn);
    std::panic::set_hook(Box::new(|info| {
        push_p(6, format!("{} PANIC {}", crate::now_ms(), info));
    }));
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ring_buffer_is_bounded() {
        for i in 0..(MAX_LINES + 50) {
            push(format!("line {i}"));
        }
        let l = lines();
        assert!(l.len() <= MAX_LINES);
        assert!(l.last().unwrap().contains("line"));
    }
}
