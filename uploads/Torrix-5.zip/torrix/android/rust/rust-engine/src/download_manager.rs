//! Queue rules and snapshot building. Everything here is a pure function of
//! its inputs (no I/O, no engine handles) so the rules can be unit-tested:
//!
//! * [`plan`] decides which torrents must be started or paused to respect
//!   "max simultaneous downloads", the user's own pauses, the network gate
//!   (Wi-Fi only / offline) and the "seed after completion" setting.
//! * [`parse_list`] turns the engine's torrent list (JSON) into the compact
//!   view model the UI reads: state label, progress, speeds, peers, ETA.

use std::collections::{BTreeMap, HashMap};

use serde::Serialize;
use serde_json::Value;

use crate::state::TorrentRecord;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RunState {
    Checking,
    Live,
    Paused,
    Error,
}

#[derive(Debug, Clone)]
pub struct Slot {
    pub hash: String,
    pub added_ms: u64,
    pub run: RunState,
    pub finished: bool,
    /// The user paused it and wants it to stay paused.
    pub hold: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Order {
    Start(String),
    Pause(String),
}

#[derive(Debug, Clone, Copy)]
pub struct Policy {
    pub max_active: usize,
    pub seed_after_complete: bool,
    pub network_allowed: bool,
}

/// Orders needed to bring the engine in line with the policy. Oldest torrents
/// get the free download slots first. Torrents that are still checking their
/// files count as active but are never interrupted.
pub fn plan(slots: &[Slot], policy: &Policy) -> Vec<Order> {
    let mut sorted: Vec<&Slot> = slots.iter().collect();
    sorted.sort_by(|a, b| a.added_ms.cmp(&b.added_ms).then_with(|| a.hash.cmp(&b.hash)));

    let mut orders = Vec::new();
    let mut active = 0usize;
    for s in sorted {
        if s.run == RunState::Error {
            continue;
        }
        if s.hold {
            if s.run == RunState::Live {
                orders.push(Order::Pause(s.hash.clone()));
            }
            continue;
        }
        if s.finished {
            let want_running = policy.seed_after_complete && policy.network_allowed;
            match (want_running, s.run) {
                (true, RunState::Paused) => orders.push(Order::Start(s.hash.clone())),
                (false, RunState::Live) => orders.push(Order::Pause(s.hash.clone())),
                _ => {}
            }
            continue;
        }
        let allowed = policy.network_allowed && active < policy.max_active;
        if allowed {
            active += 1;
        }
        match (allowed, s.run) {
            (true, RunState::Paused) => orders.push(Order::Start(s.hash.clone())),
            (false, RunState::Live) => orders.push(Order::Pause(s.hash.clone())),
            _ => {}
        }
    }
    orders
}

/// Stable vocabulary shared with the Kotlin UI.
pub fn label(run: RunState, finished: bool, hold: bool, network_allowed: bool) -> &'static str {
    if run == RunState::Error {
        return "error";
    }
    if run == RunState::Checking {
        return "checking";
    }
    if finished {
        return if run == RunState::Live && !hold { "seeding" } else { "complete" };
    }
    if hold {
        return "paused";
    }
    match run {
        RunState::Live => "downloading",
        _ => {
            if network_allowed {
                "queued"
            } else {
                "waiting_network"
            }
        }
    }
}

/// Exponential moving average of the download speed, for a calmer ETA.
#[derive(Debug, Clone, Default)]
pub struct Ema {
    value: f64,
    samples: u32,
}

impl Ema {
    pub fn update(&mut self, sample: f64) {
        if self.samples == 0 {
            self.value = sample;
        } else {
            self.value = self.value * 0.7 + sample * 0.3;
        }
        self.samples = self.samples.saturating_add(1);
    }
}

/// Seconds left, or `None` when the estimate would not be reliable (fewer than
/// five samples, practically no speed, or more than 100 days).
pub fn eta_secs(remaining: u64, ema: &Ema) -> Option<u64> {
    if remaining == 0 || ema.samples < 5 || ema.value < 1024.0 {
        return None;
    }
    let secs = remaining as f64 / ema.value;
    if secs.is_finite() && secs <= 8_640_000.0 {
        Some(secs.ceil() as u64)
    } else {
        None
    }
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct TorrentView {
    pub hash: String,
    pub name: String,
    pub state: &'static str,
    pub finished: bool,
    pub hold: bool,
    pub progress: f64,
    pub total_bytes: u64,
    pub done_bytes: u64,
    pub uploaded_bytes: u64,
    pub down_bps: u64,
    pub up_bps: u64,
    pub peers_live: u32,
    pub peers_seen: u32,
    pub peers_connecting: u32,
    pub eta_secs: Option<u64>,
    pub error: Option<String>,
    pub output_folder: String,
    pub added_ms: u64,
    pub completed_ms: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct Totals {
    pub down_bps: u64,
    pub up_bps: u64,
    pub downloading: u32,
    pub seeding: u32,
    pub queued: u32,
    pub total: u32,
}

#[derive(Debug, Clone, Serialize, Default)]
pub struct Snapshot {
    pub ts_ms: u64,
    pub torrents: Vec<TorrentView>,
    pub totals: Totals,
    pub network_allowed: bool,
}

pub struct Parsed {
    pub views: Vec<TorrentView>,
    pub slots: Vec<Slot>,
    pub records_changed: bool,
}

fn at<'a>(v: Option<&'a Value>, ptr: &str) -> Option<&'a Value> {
    v.and_then(|x| x.pointer(ptr))
}

fn u64_at(v: Option<&Value>, ptr: &str) -> u64 {
    at(v, ptr).and_then(Value::as_u64).unwrap_or(0)
}

fn u32_at(v: Option<&Value>, ptr: &str) -> u32 {
    u64_at(v, ptr).min(u32::MAX as u64) as u32
}

fn f64_at(v: Option<&Value>, ptr: &str) -> f64 {
    at(v, ptr).and_then(Value::as_f64).unwrap_or(0.0)
}

fn str_at(v: Option<&Value>, ptr: &str) -> Option<String> {
    at(v, ptr).and_then(Value::as_str).map(str::to_string)
}

/// Convert the engine's torrent list (`{"torrents":[{info_hash,name,
/// output_folder,stats:{...}}]}`) into views and scheduler slots. Unknown
/// torrents get a record; finished ones get a completion time.
pub fn parse_list(
    list: &Value,
    records: &mut BTreeMap<String, TorrentRecord>,
    emas: &mut HashMap<String, Ema>,
    policy: &Policy,
    now_ms: u64,
) -> Parsed {
    let mut views: Vec<TorrentView> = Vec::new();
    let mut slots: Vec<Slot> = Vec::new();
    let mut changed = false;
    let empty: Vec<Value> = Vec::new();
    let items = list
        .get("torrents")
        .and_then(Value::as_array)
        .unwrap_or(&empty);

    for t in items {
        let hash = t
            .get("info_hash")
            .and_then(Value::as_str)
            .unwrap_or("")
            .to_ascii_lowercase();
        if hash.len() != 40 || !hash.bytes().all(|b| b.is_ascii_hexdigit()) {
            continue;
        }
        let stats = t.get("stats").filter(|s| !s.is_null());
        let state_str = str_at(stats, "/state").unwrap_or_default();
        let run = match state_str.as_str() {
            "initializing" => RunState::Checking,
            "live" => RunState::Live,
            "paused" => RunState::Paused,
            "error" => RunState::Error,
            _ => {
                if stats.is_none() {
                    RunState::Checking
                } else {
                    RunState::Paused
                }
            }
        };
        let finished = at(stats, "/finished")
            .and_then(Value::as_bool)
            .unwrap_or(false);
        let total = u64_at(stats, "/total_bytes");
        let mut done = u64_at(stats, "/progress_bytes");
        if total > 0 {
            done = done.min(total);
        }
        if finished {
            done = total;
        }
        let progress = if finished {
            1.0
        } else if total > 0 {
            (done as f64 / total as f64).clamp(0.0, 1.0)
        } else {
            0.0
        };
        let mib = 1_048_576.0_f64;
        let down_bps = (f64_at(stats, "/live/download_speed/mbps").max(0.0) * mib) as u64;
        let up_bps = (f64_at(stats, "/live/upload_speed/mbps").max(0.0) * mib) as u64;

        let record = records.entry(hash.clone()).or_insert_with(|| {
            changed = true;
            TorrentRecord {
                hold: run == RunState::Paused,
                added_ms: now_ms,
                completed_ms: None,
            }
        });
        if finished && record.completed_ms.is_none() {
            record.completed_ms = Some(now_ms);
            changed = true;
        }
        let hold = record.hold;
        let added_ms = record.added_ms;
        let completed_ms = record.completed_ms;

        if run == RunState::Live && !finished {
            emas.entry(hash.clone()).or_default().update(down_bps as f64);
        } else if run != RunState::Checking {
            emas.remove(&hash);
        }
        let eta = if run == RunState::Live && !finished {
            emas.get(&hash)
                .and_then(|e| eta_secs(total.saturating_sub(done), e))
        } else {
            None
        };

        let name = t
            .get("name")
            .and_then(Value::as_str)
            .filter(|n| !n.trim().is_empty())
            .map(str::to_string)
            .unwrap_or_else(|| hash[..8].to_string());

        views.push(TorrentView {
            hash: hash.clone(),
            name,
            state: label(run, finished, hold, policy.network_allowed),
            finished,
            hold,
            progress,
            total_bytes: total,
            done_bytes: done,
            uploaded_bytes: u64_at(stats, "/uploaded_bytes"),
            down_bps,
            up_bps,
            peers_live: u32_at(stats, "/live/snapshot/peer_stats/live"),
            peers_seen: u32_at(stats, "/live/snapshot/peer_stats/seen"),
            peers_connecting: u32_at(stats, "/live/snapshot/peer_stats/connecting"),
            eta_secs: eta,
            error: str_at(stats, "/error"),
            output_folder: t
                .get("output_folder")
                .and_then(Value::as_str)
                .unwrap_or("")
                .to_string(),
            added_ms,
            completed_ms,
        });
        slots.push(Slot {
            hash,
            added_ms,
            run,
            finished,
            hold,
        });
    }

    views.sort_by(|a, b| a.added_ms.cmp(&b.added_ms).then_with(|| a.hash.cmp(&b.hash)));
    Parsed {
        views,
        slots,
        records_changed: changed,
    }
}

pub fn build_snapshot(views: Vec<TorrentView>, network_allowed: bool, now_ms: u64) -> Snapshot {
    let mut totals = Totals::default();
    for v in &views {
        totals.total += 1;
        totals.down_bps += v.down_bps;
        totals.up_bps += v.up_bps;
        match v.state {
            "downloading" | "checking" => totals.downloading += 1,
            "seeding" => totals.seeding += 1,
            "queued" | "waiting_network" => totals.queued += 1,
            _ => {}
        }
    }
    Snapshot {
        ts_ms: now_ms,
        torrents: views,
        totals,
        network_allowed,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn slot(hash: &str, added: u64, run: RunState, finished: bool, hold: bool) -> Slot {
        Slot { hash: hash.into(), added_ms: added, run, finished, hold }
    }

    fn policy(max: usize, seed: bool, net: bool) -> Policy {
        Policy { max_active: max, seed_after_complete: seed, network_allowed: net }
    }

    fn starts(o: &[Order]) -> Vec<&str> {
        o.iter().filter_map(|x| if let Order::Start(h) = x { Some(h.as_str()) } else { None }).collect()
    }
    fn pauses(o: &[Order]) -> Vec<&str> {
        o.iter().filter_map(|x| if let Order::Pause(h) = x { Some(h.as_str()) } else { None }).collect()
    }

    #[test]
    fn only_max_active_torrents_may_download_oldest_first() {
        let slots = vec![
            slot("d", 4, RunState::Live, false, false),
            slot("a", 1, RunState::Live, false, false),
            slot("c", 3, RunState::Live, false, false),
            slot("b", 2, RunState::Live, false, false),
        ];
        let o = plan(&slots, &policy(2, false, true));
        assert_eq!(pauses(&o), vec!["c", "d"]);
        assert!(starts(&o).is_empty());
    }

    #[test]
    fn queued_torrents_start_when_slots_free_up() {
        let slots = vec![
            slot("a", 1, RunState::Live, false, false),
            slot("b", 2, RunState::Paused, false, false),
            slot("c", 3, RunState::Paused, false, false),
        ];
        let o = plan(&slots, &policy(2, false, true));
        assert_eq!(starts(&o), vec!["b"]);
        assert!(pauses(&o).is_empty());
        // a finishes -> both queued torrents can run
        let slots = vec![
            slot("a", 1, RunState::Paused, true, false),
            slot("b", 2, RunState::Paused, false, false),
            slot("c", 3, RunState::Paused, false, false),
        ];
        assert_eq!(starts(&plan(&slots, &policy(2, false, true))), vec!["b", "c"]);
    }

    #[test]
    fn pause_and_resume_follow_the_users_hold() {
        let paused_by_user = vec![slot("a", 1, RunState::Live, false, true)];
        assert_eq!(pauses(&plan(&paused_by_user, &policy(3, false, true))), vec!["a"]);
        let already_paused = vec![slot("a", 1, RunState::Paused, false, true)];
        assert!(plan(&already_paused, &policy(3, false, true)).is_empty());
        // user resumes: hold cleared -> it is started
        let resumed = vec![slot("a", 1, RunState::Paused, false, false)];
        assert_eq!(starts(&plan(&resumed, &policy(3, false, true))), vec!["a"]);
    }

    #[test]
    fn held_torrents_do_not_use_a_download_slot() {
        let slots = vec![
            slot("a", 1, RunState::Paused, false, true),
            slot("b", 2, RunState::Paused, false, false),
        ];
        assert_eq!(starts(&plan(&slots, &policy(1, false, true))), vec!["b"]);
    }

    #[test]
    fn nothing_runs_without_an_allowed_network() {
        let slots = vec![
            slot("a", 1, RunState::Live, false, false),
            slot("s", 2, RunState::Live, true, false),
            slot("p", 3, RunState::Paused, false, false),
        ];
        let o = plan(&slots, &policy(3, true, false));
        assert_eq!(pauses(&o), vec!["a", "s"]);
        assert!(starts(&o).is_empty());
        // network returns: they are started again
        let slots = vec![
            slot("a", 1, RunState::Paused, false, false),
            slot("s", 2, RunState::Paused, true, false),
        ];
        let o = plan(&slots, &policy(3, true, true));
        assert_eq!(starts(&o), vec!["a", "s"]);
    }

    #[test]
    fn seeding_follows_the_setting() {
        let seeding = vec![slot("s", 1, RunState::Live, true, false)];
        assert_eq!(pauses(&plan(&seeding, &policy(3, false, true))), vec!["s"]);
        assert!(plan(&seeding, &policy(3, true, true)).is_empty());
        let stopped = vec![slot("s", 1, RunState::Paused, true, false)];
        assert!(plan(&stopped, &policy(3, false, true)).is_empty());
        assert_eq!(starts(&plan(&stopped, &policy(3, true, true))), vec!["s"]);
        // a finished torrent the user stopped stays stopped even when seeding is on
        let held = vec![slot("s", 1, RunState::Paused, true, true)];
        assert!(plan(&held, &policy(3, true, true)).is_empty());
    }

    #[test]
    fn checking_torrents_count_but_are_never_interrupted() {
        let slots = vec![
            slot("a", 1, RunState::Checking, false, false),
            slot("b", 2, RunState::Live, false, false),
        ];
        let o = plan(&slots, &policy(1, false, true));
        assert_eq!(pauses(&o), vec!["b"]);
        assert!(!o.contains(&Order::Pause("a".into())));
    }

    #[test]
    fn failed_torrents_are_left_alone() {
        let slots = vec![slot("e", 1, RunState::Error, false, false), slot("a", 2, RunState::Paused, false, false)];
        assert_eq!(starts(&plan(&slots, &policy(1, false, true))), vec!["a"]);
    }

    #[test]
    fn labels_cover_every_state() {
        assert_eq!(label(RunState::Error, false, false, true), "error");
        assert_eq!(label(RunState::Checking, true, false, true), "checking");
        assert_eq!(label(RunState::Live, true, false, true), "seeding");
        assert_eq!(label(RunState::Paused, true, false, true), "complete");
        assert_eq!(label(RunState::Live, true, true, true), "complete");
        assert_eq!(label(RunState::Live, false, false, true), "downloading");
        assert_eq!(label(RunState::Paused, false, true, true), "paused");
        assert_eq!(label(RunState::Paused, false, false, true), "queued");
        assert_eq!(label(RunState::Paused, false, false, false), "waiting_network");
    }

    #[test]
    fn eta_is_only_shown_when_reliable() {
        let mut e = Ema::default();
        for _ in 0..4 {
            e.update(1_000_000.0);
        }
        assert_eq!(eta_secs(10_000_000, &e), None, "needs five samples");
        e.update(1_000_000.0);
        assert_eq!(eta_secs(10_000_000, &e), Some(10));
        assert_eq!(eta_secs(0, &e), None);
        let mut slow = Ema::default();
        for _ in 0..10 {
            slow.update(100.0);
        }
        assert_eq!(eta_secs(1_000, &slow), None, "practically stalled");
        let mut tiny = Ema::default();
        for _ in 0..10 {
            tiny.update(2_000.0);
        }
        assert_eq!(eta_secs(u64::MAX / 2, &tiny), None, "more than 100 days");
    }

    #[test]
    fn ema_smooths_spikes() {
        let mut e = Ema::default();
        e.update(1000.0);
        e.update(2000.0);
        assert!((e.value - 1300.0).abs() < 1e-9);
    }

    fn sample_list(state: &str, finished: bool, progress: u64) -> Value {
        json!({"torrents": [
            {"id": 0, "info_hash": "DA39A3EE5E6B4B0D3255BFEF95601890AFD80709", "name": "Example ISO", "output_folder": "/data/torrents",
             "stats": {"state": state, "file_progress": [progress], "error": null,
                       "progress_bytes": progress, "uploaded_bytes": 10, "total_bytes": 1000, "finished": finished,
                       "live": {"snapshot": {"peer_stats": {"queued": 1, "connecting": 2, "live": 3, "seen": 9, "dead": 0, "not_needed": 0}},
                                "download_speed": {"mbps": 1.0, "human_readable": "1.00 MiB/s"},
                                "upload_speed": {"mbps": 0.5, "human_readable": "0.50 MiB/s"}}}},
            {"id": 1, "info_hash": "not-a-hash", "name": "skipped"}
        ]})
    }

    #[test]
    fn list_is_converted_to_views_peer_counts_and_speeds() {
        let mut records = BTreeMap::new();
        let mut emas = HashMap::new();
        let p = parse_list(&sample_list("live", false, 500), &mut records, &mut emas, &policy(3, false, true), 5_000);
        assert_eq!(p.views.len(), 1, "invalid hashes are skipped");
        let v = &p.views[0];
        assert_eq!(v.hash, "da39a3ee5e6b4b0d3255bfef95601890afd80709");
        assert_eq!(v.name, "Example ISO");
        assert_eq!(v.state, "downloading");
        assert!((v.progress - 0.5).abs() < 1e-9);
        assert_eq!(v.down_bps, 1_048_576);
        assert_eq!(v.up_bps, 524_288);
        assert_eq!((v.peers_live, v.peers_seen, v.peers_connecting), (3, 9, 2));
        assert_eq!(v.output_folder, "/data/torrents");
        assert_eq!(v.eta_secs, None, "first sample is not reliable yet");
        assert_eq!(p.slots.len(), 1);
        assert!(p.records_changed);
        assert!(!records["da39a3ee5e6b4b0d3255bfef95601890afd80709"].hold);
    }

    #[test]
    fn eta_appears_after_enough_samples() {
        let mut records = BTreeMap::new();
        let mut emas = HashMap::new();
        let list = sample_list("live", false, 500);
        let mut last = None;
        for _ in 0..6 {
            let p = parse_list(&list, &mut records, &mut emas, &policy(3, false, true), 1);
            last = p.views[0].eta_secs;
        }
        // 500 bytes left at 1 MiB/s
        assert_eq!(last, Some(1));
    }

    #[test]
    fn unknown_paused_torrents_are_treated_as_user_paused() {
        let mut records = BTreeMap::new();
        let mut emas = HashMap::new();
        let p = parse_list(&sample_list("paused", false, 100), &mut records, &mut emas, &policy(3, false, true), 1);
        assert_eq!(p.views[0].state, "paused");
        assert!(p.slots[0].hold);
    }

    #[test]
    fn finished_torrents_get_a_completion_time_once() {
        let mut records = BTreeMap::new();
        let mut emas = HashMap::new();
        let pol = policy(3, false, true);
        let p1 = parse_list(&sample_list("live", true, 1000), &mut records, &mut emas, &pol, 111);
        assert_eq!(p1.views[0].completed_ms, Some(111));
        assert_eq!(p1.views[0].progress, 1.0);
        assert_eq!(p1.views[0].state, "seeding");
        let p2 = parse_list(&sample_list("live", true, 1000), &mut records, &mut emas, &pol, 222);
        assert_eq!(p2.views[0].completed_ms, Some(111));
        assert!(!p2.records_changed);
    }

    #[test]
    fn torrents_without_stats_are_checking_and_errors_are_reported() {
        let mut records = BTreeMap::new();
        let mut emas = HashMap::new();
        let pol = policy(3, false, true);
        let no_stats = json!({"torrents": [{"id": 0, "info_hash": "da39a3ee5e6b4b0d3255bfef95601890afd80709", "name": null}]});
        let p = parse_list(&no_stats, &mut records, &mut emas, &pol, 1);
        assert_eq!(p.views[0].state, "checking");
        assert_eq!(p.views[0].name, "da39a3ee");
        let failing = json!({"torrents": [{"id": 0, "info_hash": "da39a3ee5e6b4b0d3255bfef95601890afd80709", "name": "x",
            "stats": {"state": "error", "error": "No space left on device", "progress_bytes": 0, "uploaded_bytes": 0, "total_bytes": 10, "finished": false, "live": null}}]});
        let p = parse_list(&failing, &mut records, &mut emas, &pol, 2);
        assert_eq!(p.views[0].state, "error");
        assert_eq!(p.views[0].error.as_deref(), Some("No space left on device"));
        assert_eq!(p.views[0].down_bps, 0);
    }

    #[test]
    fn malformed_lists_yield_no_views() {
        let mut records = BTreeMap::new();
        let mut emas = HashMap::new();
        let pol = policy(3, false, true);
        for bad in [json!(null), json!({}), json!({"torrents": 5}), json!({"torrents": [null, 7, {}]})] {
            let p = parse_list(&bad, &mut records, &mut emas, &pol, 1);
            assert!(p.views.is_empty());
        }
    }

    #[test]
    fn totals_count_by_state() {
        let mk = |state: &'static str, down: u64| TorrentView { state, down_bps: down, up_bps: 1, ..Default::default() };
        let s = build_snapshot(
            vec![mk("downloading", 100), mk("checking", 0), mk("seeding", 0), mk("queued", 0), mk("waiting_network", 0), mk("paused", 0), mk("complete", 0)],
            true,
            9,
        );
        assert_eq!(s.totals.total, 7);
        assert_eq!(s.totals.downloading, 2);
        assert_eq!(s.totals.seeding, 1);
        assert_eq!(s.totals.queued, 2);
        assert_eq!(s.totals.down_bps, 100);
        assert_eq!(s.totals.up_bps, 7);
        assert_eq!(s.ts_ms, 9);
    }
}
