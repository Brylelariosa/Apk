//! Torrix native engine.
//!
//! Layers, top to bottom:
//!   `ffi`              JNI entry point: one JSON-in / JSON-out function
//!   `lib` (this file)  RPC dispatcher and process-wide state
//!   `engine`           librqbit session wrapper, add-torrent flow, scheduler loop
//!   `download_manager` queue rules and snapshot building (pure, unit-tested)
//!   `magnet`, `torrent`, `storage`, `settings`, `state`   validation and persistence
//!
//! The BitTorrent protocol (peers, trackers, DHT, piece download and
//! verification) is implemented by librqbit; see docs/ARCHITECTURE.md.

pub mod download_manager;
pub mod engine;
pub mod ffi;
pub mod logging;
pub mod magnet;
pub mod settings;
pub mod state;
pub mod storage;
pub mod torrent;

use std::path::PathBuf;
use std::sync::{Arc, Mutex, OnceLock};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{json, Value};
use tokio::runtime::Runtime;

use engine::{Core, Paths};
use settings::Settings;

pub const VERSION: &str = env!("CARGO_PKG_VERSION");

static RUNTIME: OnceLock<Runtime> = OnceLock::new();
static CORE: Mutex<Option<Arc<Core>>> = Mutex::new(None);
static INIT_LOCK: Mutex<()> = Mutex::new(());

pub fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

/// One small runtime for everything: two worker threads keep memory and
/// background CPU low; blocking work (disk, hashing) uses a bounded pool.
pub fn runtime() -> &'static Runtime {
    RUNTIME.get_or_init(|| {
        tokio::runtime::Builder::new_multi_thread()
            .worker_threads(2)
            .max_blocking_threads(16)
            .thread_name("torrix-rt")
            .enable_all()
            .build()
            .expect("could not start the async runtime")
    })
}

fn core() -> Result<Arc<Core>, String> {
    CORE.lock()
        .unwrap_or_else(|e| e.into_inner())
        .clone()
        .ok_or_else(|| "The torrent engine is not running.".to_string())
}

fn str_arg(args: &Value, key: &str) -> Result<String, String> {
    args.get(key)
        .and_then(Value::as_str)
        .map(str::to_string)
        .ok_or_else(|| format!("missing argument: {key}"))
}

fn u64_arg(args: &Value, key: &str) -> Result<u64, String> {
    args.get(key)
        .and_then(Value::as_u64)
        .ok_or_else(|| format!("missing argument: {key}"))
}

fn bool_arg(args: &Value, key: &str, default: bool) -> bool {
    args.get(key).and_then(Value::as_bool).unwrap_or(default)
}

/// Single entry point used by JNI. `method` and `args_json` come from Kotlin;
/// the result is always a JSON envelope: `{"ok":true,"data":...}` or
/// `{"ok":false,"error":"..."}`. Panics are caught and reported as errors.
pub fn call(method: &str, args_json: &str) -> String {
    let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(
        || -> Result<String, String> {
            let args: Value = if args_json.trim().is_empty() {
                Value::Null
            } else {
                serde_json::from_str(args_json).map_err(|e| format!("bad arguments: {e}"))?
            };
            if method == "snapshot" {
                // Hot path: the engine keeps the JSON ready, just wrap it.
                let c = core()?;
                return Ok(format!("{{\"ok\":true,\"data\":{}}}", c.snapshot_json()));
            }
            let data = dispatch(method, &args)?;
            Ok(json!({"ok": true, "data": data}).to_string())
        },
    ));
    match outcome {
        Ok(Ok(s)) => s,
        Ok(Err(e)) => json!({"ok": false, "error": e}).to_string(),
        Err(_) => json!({"ok": false, "error": "Internal error in the torrent engine."}).to_string(),
    }
}

fn init(args: &Value) -> Result<Value, String> {
    let _guard = INIT_LOCK.lock().unwrap_or_else(|e| e.into_inner());
    if core().is_ok() {
        return Ok(json!({"version": VERSION, "already_running": true}));
    }
    let engine_dir = PathBuf::from(str_arg(args, "engine_dir")?);
    let staging_dir = PathBuf::from(str_arg(args, "staging_dir")?);
    let cache_dir = PathBuf::from(str_arg(args, "cache_dir")?);
    logging::init();
    logging::info("init: begin");
    // Android does not set $HOME or $TMPDIR for apps; point them at private storage.
    std::env::set_var("HOME", &engine_dir);
    std::env::set_var("TMPDIR", &cache_dir);
    let settings = args
        .get("settings")
        .cloned()
        .and_then(|v| serde_json::from_value::<Settings>(v).ok())
        .unwrap_or_default()
        .sanitized();
    let paths = Paths {
        engine_dir,
        staging_dir,
        cache_dir,
    };
    let net_allowed = bool_arg(args, "net_allowed", true);
    logging::info(format!("init: engine {} is starting the async runtime", VERSION));
    let rt = runtime();
    logging::info("init: runtime ready, opening the torrent session");
    let started = rt.block_on(Core::start(paths.clone(), settings, net_allowed))?;
    logging::info("init: torrent session ready");
    *CORE.lock().unwrap_or_else(|e| e.into_inner()) = Some(started);
    Ok(json!({
        "version": VERSION,
        "staging_dir": paths.staging_dir.to_string_lossy(),
    }))
}

fn dispatch(method: &str, args: &Value) -> Result<Value, String> {
    match method {
        "init" => init(args),
        "version" => Ok(json!({"version": VERSION})),
        "logs" => Ok(json!({"lines": logging::lines()})),
        "shutdown" => {
            let taken = CORE.lock().unwrap_or_else(|e| e.into_inner()).take();
            if let Some(c) = taken {
                c.shutdown();
            }
            Ok(json!({}))
        }
        "validate" => {
            let input = str_arg(args, "input")?;
            let src = magnet::classify(&input)?;
            let label = src.label();
            match src {
                magnet::Source::Magnet(m) => Ok(json!({
                    "kind": "magnet",
                    "info_hash": m.info_hash,
                    "label": label,
                })),
                magnet::Source::TorrentUrl(_) => Ok(json!({"kind": "url", "label": label})),
            }
        }
        "set_settings" => {
            let c = core()?;
            let raw = args.get("settings").cloned().unwrap_or(Value::Null);
            let s: Settings =
                serde_json::from_value(raw).map_err(|e| format!("invalid settings: {e}"))?;
            Ok(json!({"restart_required": c.set_settings(s)}))
        }
        "set_net_allowed" => {
            core()?.set_net_allowed(bool_arg(args, "allowed", true));
            Ok(json!({}))
        }
        "set_poll_ms" => {
            core()?.set_poll_ms(u64_arg(args, "ms")?);
            Ok(json!({}))
        }
        "add_start" => {
            let id = core()?.add_start(&str_arg(args, "input")?)?;
            Ok(json!({"request_id": id}))
        }
        "add_start_file" => {
            let id = core()?.add_start_file(&str_arg(args, "path")?)?;
            Ok(json!({"request_id": id}))
        }
        "add_status" => core()?.add_status(u64_arg(args, "request_id")?),
        "add_confirm" => {
            let only = args.get("only_files").and_then(Value::as_array).map(|a| {
                a.iter()
                    .filter_map(Value::as_u64)
                    .map(|x| x as usize)
                    .collect::<Vec<usize>>()
            });
            core()?.add_confirm(u64_arg(args, "request_id")?, only)?;
            Ok(json!({}))
        }
        "add_cancel" => {
            core()?.add_cancel(u64_arg(args, "request_id")?);
            Ok(json!({}))
        }
        "pause" => {
            core()?.set_hold(&str_arg(args, "hash")?, true)?;
            Ok(json!({}))
        }
        "resume" => {
            core()?.set_hold(&str_arg(args, "hash")?, false)?;
            Ok(json!({}))
        }
        "pause_all" => {
            core()?.set_hold_all(true);
            Ok(json!({}))
        }
        "resume_all" => {
            core()?.set_hold_all(false);
            Ok(json!({}))
        }
        "remove" => {
            let c = core()?;
            let hash = str_arg(args, "hash")?;
            let delete_files = bool_arg(args, "delete_files", false);
            runtime().block_on(c.remove(&hash, delete_files))?;
            Ok(json!({}))
        }
        "details" => core()?.details(&str_arg(args, "hash")?),
        "search" => {
            let c = core()?;
            let q = str_arg(args, "query")?;
            runtime().block_on(c.search(&q))
        }
        _ => Err(format!("unknown method: {method}")),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn parse(s: &str) -> Value {
        serde_json::from_str(s).expect("the engine must always answer with valid JSON")
    }

    #[test]
    fn answers_are_always_valid_json_envelopes() {
        let r = parse(&call("version", ""));
        assert_eq!(r["ok"], true);
        assert_eq!(r["data"]["version"], VERSION);
    }

    #[test]
    fn bad_input_becomes_an_error_not_a_crash() {
        assert_eq!(parse(&call("nope", "{}"))["ok"], false);
        assert_eq!(parse(&call("version", "{ not json"))["ok"], false);
        // everything that needs the engine fails cleanly before init
        for m in ["snapshot", "pause_all", "add_status", "details", "remove", "search"] {
            let r = parse(&call(m, "{\"request_id\":1,\"hash\":\"x\",\"query\":\"abc\"}"));
            assert_eq!(r["ok"], false, "{m}");
        }
    }

    #[test]
    fn validate_classifies_input_without_the_engine() {
        let r = parse(&call("validate", r#"{"input":"magnet:?xt=urn:btih:da39a3ee5e6b4b0d3255bfef95601890afd80709&dn=Test"}"#));
        // validate does not need the engine
        assert_eq!(r["ok"], true);
        assert_eq!(r["data"]["kind"], "magnet");
        assert_eq!(r["data"]["label"], "Test");
        let u = parse(&call("validate", r#"{"input":"https://example.org/a.torrent"}"#));
        assert_eq!(u["data"]["kind"], "url");
        let bad = parse(&call("validate", r#"{"input":"hello"}"#));
        assert_eq!(bad["ok"], false);
        assert!(bad["error"].as_str().unwrap().contains("magnet"));
    }

    #[test]
    fn missing_arguments_are_reported() {
        let r = parse(&call("validate", "{}"));
        assert_eq!(r["ok"], false);
        assert!(r["error"].as_str().unwrap().contains("input"));
    }
}
