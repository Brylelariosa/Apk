//! .torrent metadata parsing and piece verification.
//!
//! The engine (librqbit) does the real downloading and verifies every piece
//! while downloading. This module is Torrix's own *defensive* layer: it parses
//! .torrent files that come from search results or the user before they reach
//! the engine, rejects malformed or hostile metadata (path traversal, size
//! overflow, bencode bombs) and computes the info hash independently.

use std::collections::BTreeMap;
use std::fmt;

use sha1::{Digest, Sha1};

use crate::storage::sanitize_component;

pub const MAX_TORRENT_BYTES: usize = 8 * 1024 * 1024;
const MAX_DEPTH: usize = 24;
const MAX_NODES: usize = 1_500_000;
const MAX_FILES: usize = 100_000;
const MAX_PIECE_LENGTH: u64 = 256 * 1024 * 1024;
const MAX_TRACKERS: usize = 64;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum TorrentError {
    Bencode(&'static str),
    Missing(&'static str),
    Invalid(&'static str),
    TooLarge,
}

impl fmt::Display for TorrentError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            TorrentError::Bencode(m) => write!(f, "malformed metadata ({m})"),
            TorrentError::Missing(k) => write!(f, "missing field \"{k}\""),
            TorrentError::Invalid(m) => write!(f, "{m}"),
            TorrentError::TooLarge => write!(f, "the file is too large"),
        }
    }
}

impl std::error::Error for TorrentError {}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Value {
    Int(i64),
    Bytes(Vec<u8>),
    List(Vec<Value>),
    Dict(BTreeMap<Vec<u8>, Value>),
}

impl Value {
    pub fn as_int(&self) -> Option<i64> {
        if let Value::Int(i) = self {
            Some(*i)
        } else {
            None
        }
    }

    pub fn as_bytes(&self) -> Option<&[u8]> {
        if let Value::Bytes(b) = self {
            Some(b.as_slice())
        } else {
            None
        }
    }

    pub fn as_list(&self) -> Option<&[Value]> {
        if let Value::List(l) = self {
            Some(l.as_slice())
        } else {
            None
        }
    }

    pub fn as_dict(&self) -> Option<&BTreeMap<Vec<u8>, Value>> {
        if let Value::Dict(d) = self {
            Some(d)
        } else {
            None
        }
    }

    pub fn get(&self, key: &str) -> Option<&Value> {
        self.as_dict()?.get(key.as_bytes())
    }
}

struct Parser<'a> {
    data: &'a [u8],
    pos: usize,
    nodes: usize,
    info_span: Option<(usize, usize)>,
}

impl<'a> Parser<'a> {
    fn peek(&self) -> Option<u8> {
        self.data.get(self.pos).copied()
    }

    fn value(&mut self, depth: usize) -> Result<Value, TorrentError> {
        if depth > MAX_DEPTH {
            return Err(TorrentError::Bencode("nesting too deep"));
        }
        self.nodes += 1;
        if self.nodes > MAX_NODES {
            return Err(TorrentError::TooLarge);
        }
        match self.peek() {
            Some(b'i') => Ok(Value::Int(self.int()?)),
            Some(b'l') => {
                self.pos += 1;
                let mut items = Vec::new();
                loop {
                    match self.peek() {
                        Some(b'e') => {
                            self.pos += 1;
                            break;
                        }
                        Some(_) => items.push(self.value(depth + 1)?),
                        None => return Err(TorrentError::Bencode("unterminated list")),
                    }
                }
                Ok(Value::List(items))
            }
            Some(b'd') => {
                self.pos += 1;
                let mut map: BTreeMap<Vec<u8>, Value> = BTreeMap::new();
                loop {
                    match self.peek() {
                        Some(b'e') => {
                            self.pos += 1;
                            break;
                        }
                        Some(b'0'..=b'9') => {
                            let key = self.bytes()?;
                            let start = self.pos;
                            let val = self.value(depth + 1)?;
                            let end = self.pos;
                            if depth == 0 && key == b"info" {
                                self.info_span = Some((start, end));
                            }
                            if map.insert(key, val).is_some() {
                                return Err(TorrentError::Bencode("duplicate key"));
                            }
                        }
                        Some(_) => return Err(TorrentError::Bencode("dictionary key is not a string")),
                        None => return Err(TorrentError::Bencode("unterminated dictionary")),
                    }
                }
                Ok(Value::Dict(map))
            }
            Some(b'0'..=b'9') => Ok(Value::Bytes(self.bytes()?)),
            _ => Err(TorrentError::Bencode("unexpected byte")),
        }
    }

    fn int(&mut self) -> Result<i64, TorrentError> {
        self.pos += 1; // 'i'
        let start = self.pos;
        while let Some(c) = self.peek() {
            if c == b'e' {
                break;
            }
            self.pos += 1;
            if self.pos - start > 21 {
                return Err(TorrentError::Bencode("integer too long"));
            }
        }
        if self.peek() != Some(b'e') {
            return Err(TorrentError::Bencode("unterminated integer"));
        }
        let text = std::str::from_utf8(&self.data[start..self.pos])
            .map_err(|_| TorrentError::Bencode("bad integer"))?;
        self.pos += 1; // 'e'
        let body = text.strip_prefix('-').unwrap_or(text);
        if body.is_empty() || !body.bytes().all(|b| b.is_ascii_digit()) {
            return Err(TorrentError::Bencode("bad integer"));
        }
        if body.len() > 1 && body.starts_with('0') {
            return Err(TorrentError::Bencode("integer has leading zeros"));
        }
        if text == "-0" {
            return Err(TorrentError::Bencode("negative zero"));
        }
        text.parse::<i64>()
            .map_err(|_| TorrentError::Bencode("integer out of range"))
    }

    fn bytes(&mut self) -> Result<Vec<u8>, TorrentError> {
        let start = self.pos;
        while let Some(c) = self.peek() {
            if c == b':' {
                break;
            }
            if !c.is_ascii_digit() || self.pos - start >= 10 {
                return Err(TorrentError::Bencode("bad string length"));
            }
            self.pos += 1;
        }
        if self.peek() != Some(b':') || self.pos == start {
            return Err(TorrentError::Bencode("bad string length"));
        }
        let digits = std::str::from_utf8(&self.data[start..self.pos])
            .map_err(|_| TorrentError::Bencode("bad string length"))?;
        if digits.len() > 1 && digits.starts_with('0') {
            return Err(TorrentError::Bencode("string length has leading zeros"));
        }
        let len: usize = digits
            .parse()
            .map_err(|_| TorrentError::Bencode("bad string length"))?;
        self.pos += 1; // ':'
        let end = self
            .pos
            .checked_add(len)
            .ok_or(TorrentError::Bencode("string too long"))?;
        if end > self.data.len() {
            return Err(TorrentError::Bencode("string runs past the end of the file"));
        }
        let out = self.data[self.pos..end].to_vec();
        self.pos = end;
        Ok(out)
    }
}

/// Decode one bencoded value. Returns the value and, when the top level is a
/// dictionary with an `info` key, the byte range of that key's raw value.
pub fn decode(data: &[u8]) -> Result<(Value, Option<(usize, usize)>), TorrentError> {
    let mut p = Parser {
        data,
        pos: 0,
        nodes: 0,
        info_span: None,
    };
    let v = p.value(0)?;
    Ok((v, p.info_span))
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TorrentFile {
    /// Forward-slash path relative to the download folder. For multi-file
    /// torrents it starts with the torrent name, like the engine reports it.
    pub path: String,
    pub length: u64,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TorrentMeta {
    pub name: String,
    pub info_hash: String,
    pub piece_length: u64,
    pub total_size: u64,
    pub files: Vec<TorrentFile>,
    pub trackers: Vec<String>,
    pub private: bool,
    pieces: Vec<u8>,
}

impl TorrentMeta {
    pub fn piece_count(&self) -> usize {
        self.pieces.len() / 20
    }

    pub fn piece_hash(&self, index: usize) -> Option<&[u8]> {
        let start = index.checked_mul(20)?;
        let end = start.checked_add(20)?;
        self.pieces.get(start..end)
    }

    /// Expected length of a piece (the last one is usually shorter).
    pub fn piece_len(&self, index: usize) -> Option<u64> {
        if index >= self.piece_count() {
            return None;
        }
        let start = (index as u64).checked_mul(self.piece_length)?;
        let remaining = self.total_size.checked_sub(start)?;
        Some(remaining.min(self.piece_length))
    }

    /// Check downloaded piece data against the hash in the metadata.
    pub fn verify_piece(&self, index: usize, data: &[u8]) -> bool {
        match (self.piece_hash(index), self.piece_len(index)) {
            (Some(hash), Some(len)) => data.len() as u64 == len && verify_piece(data, hash),
            _ => false,
        }
    }
}

pub fn sha1_hex(data: &[u8]) -> String {
    Sha1::digest(data)
        .iter()
        .map(|b| format!("{:02x}", b))
        .collect()
}

/// True when SHA-1(data) equals the 20-byte `expected` hash.
pub fn verify_piece(data: &[u8], expected: &[u8]) -> bool {
    expected.len() == 20 && Sha1::digest(data).as_slice() == expected
}

fn add_tracker(out: &mut Vec<String>, raw: &[u8]) {
    if out.len() >= MAX_TRACKERS {
        return;
    }
    if let Ok(s) = std::str::from_utf8(raw) {
        let s = s.trim();
        let l = s.to_ascii_lowercase();
        let scheme_ok = l.starts_with("http://") || l.starts_with("https://") || l.starts_with("udp://");
        if scheme_ok && s.len() <= 512 && !out.iter().any(|x| x == s) {
            out.push(s.to_string());
        }
    }
}

fn collect_trackers(root: &Value) -> Vec<String> {
    let mut out = Vec::new();
    if let Some(a) = root.get("announce").and_then(Value::as_bytes) {
        add_tracker(&mut out, a);
    }
    if let Some(tiers) = root.get("announce-list").and_then(Value::as_list) {
        for tier in tiers {
            if let Some(list) = tier.as_list() {
                for t in list {
                    if let Some(b) = t.as_bytes() {
                        add_tracker(&mut out, b);
                    }
                }
            }
        }
    }
    out
}

fn non_negative(v: Option<&Value>, what: &'static str) -> Result<u64, TorrentError> {
    let i = v
        .and_then(Value::as_int)
        .ok_or(TorrentError::Missing(what))?;
    u64::try_from(i).map_err(|_| TorrentError::Invalid("negative size in metadata"))
}

pub fn parse_torrent(bytes: &[u8]) -> Result<TorrentMeta, TorrentError> {
    if bytes.is_empty() {
        return Err(TorrentError::Bencode("empty file"));
    }
    if bytes.len() > MAX_TORRENT_BYTES {
        return Err(TorrentError::TooLarge);
    }
    let (root, span) = decode(bytes)?;
    if root.as_dict().is_none() {
        return Err(TorrentError::Invalid("not a torrent file"));
    }
    let info = root.get("info").ok_or(TorrentError::Missing("info"))?;
    if info.as_dict().is_none() {
        return Err(TorrentError::Invalid("the info section is not a dictionary"));
    }
    let (s, e) = span.ok_or(TorrentError::Missing("info"))?;
    let info_hash = sha1_hex(&bytes[s..e]);

    let name_raw = info
        .get("name")
        .and_then(Value::as_bytes)
        .ok_or(TorrentError::Missing("name"))?;
    let name = sanitize_component(&String::from_utf8_lossy(name_raw))
        .ok_or(TorrentError::Invalid("the torrent name is empty or unsafe"))?;

    let piece_length = non_negative(info.get("piece length"), "piece length")?;
    if piece_length == 0 || piece_length > MAX_PIECE_LENGTH {
        return Err(TorrentError::Invalid("unsupported piece length"));
    }
    let pieces = info
        .get("pieces")
        .and_then(Value::as_bytes)
        .ok_or(TorrentError::Missing("pieces"))?
        .to_vec();
    if pieces.is_empty() || pieces.len() % 20 != 0 {
        return Err(TorrentError::Invalid("the piece hash list is malformed"));
    }

    let mut files: Vec<TorrentFile> = Vec::new();
    let mut total: u64 = 0;
    if let Some(list) = info.get("files").and_then(Value::as_list) {
        if list.is_empty() || list.len() > MAX_FILES {
            return Err(TorrentError::Invalid("unsupported number of files"));
        }
        for f in list {
            let length = non_negative(f.get("length"), "file length")?;
            let comps = f
                .get("path")
                .and_then(Value::as_list)
                .ok_or(TorrentError::Missing("file path"))?;
            if comps.is_empty() {
                return Err(TorrentError::Invalid("a file has an empty path"));
            }
            let mut parts: Vec<String> = Vec::with_capacity(comps.len());
            for c in comps {
                let raw = c
                    .as_bytes()
                    .ok_or(TorrentError::Invalid("a path component is not a string"))?;
                let text = String::from_utf8_lossy(raw);
                if text.is_empty()
                    || text == "."
                    || text == ".."
                    || text.contains('/')
                    || text.contains('\\')
                    || text.contains('\0')
                {
                    return Err(TorrentError::Invalid("a file path is unsafe"));
                }
                parts.push(
                    sanitize_component(&text)
                        .ok_or(TorrentError::Invalid("a file path is unsafe"))?,
                );
            }
            total = total
                .checked_add(length)
                .ok_or(TorrentError::Invalid("the total size overflows"))?;
            files.push(TorrentFile {
                path: format!("{}/{}", name, parts.join("/")),
                length,
            });
        }
    } else {
        let length = non_negative(info.get("length"), "length")?;
        total = length;
        files.push(TorrentFile {
            path: name.clone(),
            length,
        });
    }
    if total == 0 {
        return Err(TorrentError::Invalid("the torrent has no data"));
    }
    if total.div_ceil(piece_length) != (pieces.len() / 20) as u64 {
        return Err(TorrentError::Invalid(
            "the number of piece hashes does not match the total size",
        ));
    }

    Ok(TorrentMeta {
        name,
        info_hash,
        piece_length,
        total_size: total,
        files,
        trackers: collect_trackers(&root),
        private: info.get("private").and_then(Value::as_int) == Some(1),
        pieces,
    })
}

#[cfg(test)]
pub(crate) mod fixtures {
    pub const SINGLE_CONTENT: &[u8] = b"0123456789abcdefghijklmnopqrstuvwxyzABCD";
    pub const SINGLE_TORRENT: &[u8] = b"d8:announce39:udp://tracker.example.org:6969/announce13:announce-listll39:udp://tracker.example.org:6969/announceel31:https://t2.example.net/announce23:ftp://ignored.example/xee7:comment19:Torrix test fixture4:infod6:lengthi40e4:name9:hello.txt12:piece lengthi16e6:pieces60:\xfeUg\xe8\xd7iU\x08R\x18,\xdfi\xd7K\xb1m\xff\x8e)\x16\x09@\xa8\xec\x96\xc1a\xdf7Yn\xd2\x12\xc6&o\x9b\xc5\xc9.P\x86\xa6\xc0\x01`>\xb2\x02\xd1Z\x7fT\xc4\x90<\x98\xdb\x9cee";
    pub const SINGLE_INFO_HASH: &str = "2f2573defa2a120cb141ba3ac202bb11a2d6a1a6";
    pub const MULTI_CONTENT: &[u8] = b"aaaaabbbbbbb";
    pub const MULTI_TORRENT: &[u8] = b"d8:announce35:http://tracker.example.com/announce4:infod5:filesld6:lengthi5e4:pathl3:cd16:a.flaceed6:lengthi7e4:pathl5:b.txteee4:name5:album12:piece lengthi4e6:pieces60:p\xc8\x81\xd4\xa2i\x84\xdd\xcey_oq\x81|\x9c\xf4H\x0ey\xd7\xbf\xa4/\xc6+i{\xf6\xcf\x1c\xda\x9a\xf1\xfb\x7f@\xa2x\x17\x8a\xed\x13\x22\xe5E\x0b\xad\xb0x\xe1\xfb`\xa8\x17\xa1\xdf%\xa2\xca7:privatei1eee";
    pub const MULTI_INFO_HASH: &str = "0de8c8b08f645cf3ed59931b0d79e7a132098ecd";
}

#[cfg(test)]
mod tests {
    use super::fixtures::*;
    use super::*;

    // ---- tiny encoder used to build hostile / large test torrents ----
    fn enc(v: &Value, out: &mut Vec<u8>) {
        match v {
            Value::Int(i) => out.extend(format!("i{i}e").bytes()),
            Value::Bytes(b) => {
                out.extend(b.len().to_string().bytes());
                out.push(b':');
                out.extend(b);
            }
            Value::List(l) => {
                out.push(b'l');
                for x in l {
                    enc(x, out);
                }
                out.push(b'e');
            }
            Value::Dict(d) => {
                out.push(b'd');
                for (k, v) in d {
                    enc(&Value::Bytes(k.clone()), out);
                    enc(v, out);
                }
                out.push(b'e');
            }
        }
    }

    fn s(x: &str) -> Value {
        Value::Bytes(x.as_bytes().to_vec())
    }
    fn i(x: i64) -> Value {
        Value::Int(x)
    }
    fn d(pairs: Vec<(&str, Value)>) -> Value {
        Value::Dict(pairs.into_iter().map(|(k, v)| (k.as_bytes().to_vec(), v)).collect())
    }
    fn torrent(info: Value) -> Vec<u8> {
        let mut out = Vec::new();
        enc(&d(vec![("info", info)]), &mut out);
        out
    }
    fn zero_pieces(n: usize) -> Value {
        Value::Bytes(vec![0u8; n * 20])
    }

    #[test]
    fn sha1_known_vectors() {
        assert_eq!(sha1_hex(b"abc"), "a9993e364706816aba3e25717850c26c9cd0d89d");
        assert_eq!(sha1_hex(b""), "da39a3ee5e6b4b0d3255bfef95601890afd80709");
    }

    #[test]
    fn single_file_torrent_matches_the_python_reference() {
        let m = parse_torrent(SINGLE_TORRENT).unwrap();
        assert_eq!(m.name, "hello.txt");
        assert_eq!(m.info_hash, SINGLE_INFO_HASH);
        assert_eq!(m.total_size, 40);
        assert_eq!(m.piece_length, 16);
        assert_eq!(m.piece_count(), 3);
        assert_eq!(m.files, vec![TorrentFile { path: "hello.txt".into(), length: 40 }]);
        assert!(!m.private);
        // ftp:// is dropped, duplicates are removed
        assert_eq!(
            m.trackers,
            vec!["udp://tracker.example.org:6969/announce", "https://t2.example.net/announce"]
        );
    }

    #[test]
    fn multi_file_torrent_paths_include_the_root_name() {
        let m = parse_torrent(MULTI_TORRENT).unwrap();
        assert_eq!(m.info_hash, MULTI_INFO_HASH);
        assert_eq!(m.name, "album");
        assert_eq!(m.total_size, 12);
        assert_eq!(m.files[0].path, "album/cd1/a.flac");
        assert_eq!(m.files[1].path, "album/b.txt");
        assert!(m.private);
    }

    #[test]
    fn pieces_verify_and_corruption_is_detected() {
        let m = parse_torrent(SINGLE_TORRENT).unwrap();
        assert_eq!(m.piece_len(0), Some(16));
        assert_eq!(m.piece_len(2), Some(8));
        assert_eq!(m.piece_len(3), None);
        for idx in 0..3 {
            let start = idx * 16;
            let end = (start + 16).min(SINGLE_CONTENT.len());
            assert!(m.verify_piece(idx, &SINGLE_CONTENT[start..end]), "piece {idx}");
        }
        let mut bad = SINGLE_CONTENT[0..16].to_vec();
        bad[3] ^= 0x01;
        assert!(!m.verify_piece(0, &bad));
        assert!(!m.verify_piece(0, &SINGLE_CONTENT[0..15]), "short data");
        assert!(!m.verify_piece(0, &SINGLE_CONTENT[16..32]), "wrong piece");
        assert!(!m.verify_piece(99, b""), "index out of range");
        assert!(!verify_piece(b"abc", &[0u8; 19]), "hash of wrong length");
    }

    #[test]
    fn multi_file_pieces_span_file_boundaries() {
        let m = parse_torrent(MULTI_TORRENT).unwrap();
        for idx in 0..3 {
            let start = idx * 4;
            assert!(m.verify_piece(idx, &MULTI_CONTENT[start..start + 4]));
        }
    }

    #[test]
    fn trailing_bytes_after_the_torrent_are_ignored() {
        let mut data = SINGLE_TORRENT.to_vec();
        data.extend_from_slice(b"\n\n");
        assert_eq!(parse_torrent(&data).unwrap().info_hash, SINGLE_INFO_HASH);
    }

    #[test]
    fn every_truncation_fails_cleanly() {
        for len in 0..SINGLE_TORRENT.len() {
            assert!(parse_torrent(&SINGLE_TORRENT[..len]).is_err(), "len {len}");
        }
    }

    #[test]
    fn path_traversal_in_file_paths_is_rejected() {
        for evil in ["..", ".", "", "a/b", "a\\b"] {
            let info = d(vec![
                ("files", Value::List(vec![d(vec![("length", i(8)), ("path", Value::List(vec![s("ok"), s(evil)]))])])),
                ("name", s("t")),
                ("piece length", i(8)),
                ("pieces", zero_pieces(1)),
            ]);
            assert_eq!(
                parse_torrent(&torrent(info)),
                Err(TorrentError::Invalid("a file path is unsafe")),
                "component {evil:?}"
            );
        }
    }

    #[test]
    fn unsafe_torrent_names_are_rejected_and_odd_ones_cleaned() {
        let mk = |name: &str| {
            torrent(d(vec![
                ("length", i(8)),
                ("name", s(name)),
                ("piece length", i(8)),
                ("pieces", zero_pieces(1)),
            ]))
        };
        assert!(parse_torrent(&mk("..")).is_err());
        assert!(parse_torrent(&mk("")).is_err());
        assert_eq!(parse_torrent(&mk("a/b")).unwrap().name, "a_b");
        assert_eq!(parse_torrent(&mk("x:y?")).unwrap().name, "x_y_");
    }

    #[test]
    fn inconsistent_metadata_is_rejected() {
        // wrong number of piece hashes for the size
        let info = d(vec![("length", i(100)), ("name", s("n")), ("piece length", i(16)), ("pieces", zero_pieces(2))]);
        assert!(parse_torrent(&torrent(info)).is_err());
        // negative length
        let info = d(vec![("length", i(-5)), ("name", s("n")), ("piece length", i(16)), ("pieces", zero_pieces(1))]);
        assert!(parse_torrent(&torrent(info)).is_err());
        // zero piece length
        let info = d(vec![("length", i(5)), ("name", s("n")), ("piece length", i(0)), ("pieces", zero_pieces(1))]);
        assert!(parse_torrent(&torrent(info)).is_err());
        // pieces not a multiple of 20
        let info = d(vec![("length", i(5)), ("name", s("n")), ("piece length", i(16)), ("pieces", Value::Bytes(vec![0u8; 19]))]);
        assert!(parse_torrent(&torrent(info)).is_err());
        // zero total size
        let info = d(vec![("length", i(0)), ("name", s("n")), ("piece length", i(16)), ("pieces", zero_pieces(1))]);
        assert!(parse_torrent(&torrent(info)).is_err());
        // missing info / not a dictionary / empty files list
        assert_eq!(parse_torrent(b"de"), Err(TorrentError::Missing("info")));
        assert!(parse_torrent(b"i5e").is_err());
        assert!(parse_torrent(b"le").is_err());
        let info = d(vec![("files", Value::List(vec![])), ("name", s("n")), ("piece length", i(16)), ("pieces", zero_pieces(1))]);
        assert!(parse_torrent(&torrent(info)).is_err());
    }

    #[test]
    fn bencode_edge_cases() {
        assert!(decode(b"i03e").is_err(), "leading zero");
        assert!(decode(b"i-0e").is_err(), "negative zero");
        assert_eq!(decode(b"i-3e").unwrap().0, Value::Int(-3));
        assert_eq!(decode(b"i0e").unwrap().0, Value::Int(0));
        assert!(decode(b"ie").is_err());
        assert!(decode(b"i1").is_err());
        assert!(decode(b"i99999999999999999999e").is_err(), "overflow");
        assert!(decode(b"3:ab").is_err(), "short string");
        assert!(decode(b"03:abc").is_err(), "leading zero length");
        assert!(decode(b"99999999999:a").is_err(), "absurd length");
        assert_eq!(decode(b"0:").unwrap().0, Value::Bytes(vec![]));
        assert!(decode(b"d1:ai1e1:ai2ee").is_err(), "duplicate key");
        assert!(decode(b"di1ei2ee").is_err(), "non-string key");
        assert!(decode(b"l").is_err());
        assert!(decode(b"d").is_err());
        assert!(decode(b"x").is_err());
        assert!(decode(b"").is_err());
        assert_eq!(decode(b"le").unwrap().0, Value::List(vec![]));
        let deep = [vec![b'l'; 200], vec![b'e'; 200]].concat();
        assert_eq!(decode(&deep), Err(TorrentError::Bencode("nesting too deep")));
    }

    #[test]
    fn oversized_input_is_refused() {
        let big = vec![b'x'; MAX_TORRENT_BYTES + 1];
        assert_eq!(parse_torrent(&big), Err(TorrentError::TooLarge));
    }

    #[test]
    fn files_over_four_gib_and_terabyte_torrents_parse_without_overflow() {
        // three 3 GiB files = 9 GiB total, 4 MiB pieces
        let gib3 = 3i64 << 30;
        let files: Vec<Value> = (0..3)
            .map(|n| d(vec![("length", i(gib3)), ("path", Value::List(vec![s(&format!("part{n}.bin"))]))]))
            .collect();
        let piece = 4i64 << 20;
        let total = 3 * gib3;
        let count = (total / piece) as usize;
        let info = d(vec![("files", Value::List(files)), ("name", s("big")), ("piece length", i(piece)), ("pieces", zero_pieces(count))]);
        let m = parse_torrent(&torrent(info)).unwrap();
        assert_eq!(m.total_size, 9 * (1u64 << 30));
        assert!(m.total_size > u32::MAX as u64);
        assert_eq!(m.piece_count(), 2304);
        assert_eq!(m.piece_len(2303), Some(piece as u64));

        // a single 2 TiB file with 16 MiB pieces
        let tib2 = 2i64 << 40;
        let piece = 16i64 << 20;
        let info = d(vec![("length", i(tib2)), ("name", s("huge.img")), ("piece length", i(piece)), ("pieces", zero_pieces((tib2 / piece) as usize))]);
        let m = parse_torrent(&torrent(info)).unwrap();
        assert_eq!(m.total_size, tib2 as u64);
        assert_eq!(m.piece_count(), 131_072);
    }

    #[test]
    fn size_sums_that_overflow_are_rejected() {
        let huge = i64::MAX;
        let files: Vec<Value> = (0..3)
            .map(|n| d(vec![("length", i(huge)), ("path", Value::List(vec![s(&format!("f{n}"))]))]))
            .collect();
        let info = d(vec![("files", Value::List(files)), ("name", s("x")), ("piece length", i(1 << 20)), ("pieces", zero_pieces(1))]);
        assert_eq!(
            parse_torrent(&torrent(info)),
            Err(TorrentError::Invalid("the total size overflows"))
        );
    }
}
