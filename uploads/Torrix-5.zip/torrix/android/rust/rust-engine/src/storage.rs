//! Filesystem helpers: path safety for names that come from torrent metadata
//! (never trusted), free-space lookup and crash-safe file writes.

use std::io::{self, Write};
use std::path::{Path, PathBuf};

pub const MAX_COMPONENT_BYTES: usize = 255;
pub const MAX_PATH_BYTES: usize = 4096;

/// Make one path component safe to use as a file or directory name.
/// Returns `None` for names that cannot be made safe (empty, `.`, `..`).
pub fn sanitize_component(raw: &str) -> Option<String> {
    let mut out = String::with_capacity(raw.len());
    for c in raw.chars() {
        let bad = c.is_control()
            || matches!(c, '/' | '\\' | '<' | '>' | ':' | '"' | '|' | '?' | '*');
        out.push(if bad { '_' } else { c });
    }
    let trimmed = out.trim();
    if trimmed.is_empty() || trimmed == "." || trimmed == ".." {
        return None;
    }
    let mut s = trimmed.to_string();
    while s.len() > MAX_COMPONENT_BYTES {
        s.pop();
    }
    Some(s)
}

/// True when `p` ("a/b/c", forward slashes) stays inside its base directory:
/// not absolute, no empty / `.` / `..` components, no backslashes or NULs.
pub fn is_safe_relative_path(p: &str) -> bool {
    if p.is_empty()
        || p.len() > MAX_PATH_BYTES
        || p.starts_with('/')
        || p.contains('\0')
        || p.contains('\\')
    {
        return false;
    }
    p.split('/').all(|c| !c.is_empty() && c != "." && c != "..")
}

/// Join a validated relative path onto `base`.
pub fn join_safe(base: &Path, rel: &str) -> Option<PathBuf> {
    if !is_safe_relative_path(rel) {
        return None;
    }
    let mut out = base.to_path_buf();
    for part in rel.split('/') {
        out.push(part);
    }
    Some(out)
}

/// Bytes available to this app on the volume that holds `path`.
#[cfg(unix)]
pub fn free_bytes(path: &Path) -> Option<u64> {
    use std::ffi::CString;
    use std::os::unix::ffi::OsStrExt;
    let c = CString::new(path.as_os_str().as_bytes()).ok()?;
    let mut st: libc::statvfs = unsafe { std::mem::zeroed() };
    let rc = unsafe { libc::statvfs(c.as_ptr(), &mut st) };
    if rc != 0 {
        return None;
    }
    Some((st.f_bavail as u64).saturating_mul(st.f_frsize as u64))
}

#[cfg(not(unix))]
pub fn free_bytes(_path: &Path) -> Option<u64> {
    None
}

/// Write `data` to `path` so that a crash leaves either the old or the new
/// content, never a half-written file.
pub fn atomic_write(path: &Path, data: &[u8]) -> io::Result<()> {
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let tmp = path.with_extension("tmp");
    {
        let mut f = std::fs::File::create(&tmp)?;
        f.write_all(data)?;
        f.sync_all()?;
    }
    std::fs::rename(&tmp, path)
}

pub fn human_bytes(b: u64) -> String {
    const UNITS: [&str; 5] = ["B", "KB", "MB", "GB", "TB"];
    let mut v = b as f64;
    let mut i = 0;
    while v >= 1024.0 && i < UNITS.len() - 1 {
        v /= 1024.0;
        i += 1;
    }
    if i == 0 {
        format!("{b} B")
    } else {
        format!("{:.1} {}", v, UNITS[i])
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp_dir(tag: &str) -> PathBuf {
        let d = std::env::temp_dir().join(format!("torrix-test-{}-{}", std::process::id(), tag));
        let _ = std::fs::remove_dir_all(&d);
        std::fs::create_dir_all(&d).unwrap();
        d
    }

    #[test]
    fn components_are_sanitised() {
        assert_eq!(sanitize_component("movie.mkv").as_deref(), Some("movie.mkv"));
        assert_eq!(sanitize_component("a/b\\c").as_deref(), Some("a_b_c"));
        assert_eq!(sanitize_component("bad:name?.txt").as_deref(), Some("bad_name_.txt"));
        assert_eq!(sanitize_component("  spaced  ").as_deref(), Some("spaced"));
        assert_eq!(sanitize_component("tab\there").as_deref(), Some("tab_here"));
        assert_eq!(sanitize_component(".."), None);
        assert_eq!(sanitize_component("."), None);
        assert_eq!(sanitize_component("   "), None);
        assert_eq!(sanitize_component(""), None);
    }

    #[test]
    fn long_names_are_truncated_on_char_boundaries() {
        let long = "é".repeat(400); // 2 bytes each
        let s = sanitize_component(&long).unwrap();
        assert!(s.len() <= MAX_COMPONENT_BYTES);
        assert!(s.chars().all(|c| c == 'é'));
    }

    #[test]
    fn traversal_is_rejected() {
        assert!(is_safe_relative_path("Album/01 Track.flac"));
        assert!(is_safe_relative_path("single.iso"));
        assert!(!is_safe_relative_path("../evil"));
        assert!(!is_safe_relative_path("a/../../evil"));
        assert!(!is_safe_relative_path("/etc/passwd"));
        assert!(!is_safe_relative_path("a//b"));
        assert!(!is_safe_relative_path("a/./b"));
        assert!(!is_safe_relative_path("a\\b"));
        assert!(!is_safe_relative_path("nul\0byte"));
        assert!(!is_safe_relative_path(""));
        assert!(!is_safe_relative_path(&"a/".repeat(3000)));
    }

    #[test]
    fn join_safe_stays_under_base() {
        let base = Path::new("/data/torrents");
        assert_eq!(
            join_safe(base, "Show/S01/e01.mkv").unwrap(),
            PathBuf::from("/data/torrents/Show/S01/e01.mkv")
        );
        assert!(join_safe(base, "../x").is_none());
    }

    #[test]
    fn atomic_write_round_trips_and_overwrites() {
        let d = temp_dir("atomic");
        let f = d.join("nested").join("state.json");
        atomic_write(&f, b"one").unwrap();
        assert_eq!(std::fs::read(&f).unwrap(), b"one");
        atomic_write(&f, b"two-longer").unwrap();
        assert_eq!(std::fs::read(&f).unwrap(), b"two-longer");
        assert!(!f.with_extension("tmp").exists());
        let _ = std::fs::remove_dir_all(&d);
    }

    #[cfg(unix)]
    #[test]
    fn free_space_is_reported() {
        let d = temp_dir("free");
        let free = free_bytes(&d).expect("statvfs should work on a temp dir");
        assert!(free > 0);
        assert!(free_bytes(Path::new("/definitely/not/here")).is_none());
        let _ = std::fs::remove_dir_all(&d);
    }

    #[test]
    fn sizes_above_four_gib_format_correctly() {
        assert_eq!(human_bytes(512), "512 B");
        assert_eq!(human_bytes(1536), "1.5 KB");
        assert_eq!(human_bytes(5 * 1024 * 1024 * 1024), "5.0 GB");
        assert_eq!(human_bytes(3 * 1024u64.pow(4)), "3.0 TB");
    }
}
