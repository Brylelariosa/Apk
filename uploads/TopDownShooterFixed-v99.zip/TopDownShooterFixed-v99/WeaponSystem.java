package com.game.topdown;

import android.graphics.*;
import java.util.*;
import java.util.concurrent.*;
import org.json.*;
import static com.game.topdown.MapData.*;
import static com.game.topdown.PhysicsSystem.*;
import static com.game.topdown.GameConstants.*;

/** Bullets, chakrams, hooks, slashes, explosions. Receives GameState. */
public class WeaponSystem {

void spawnBullets(GameState state, Player p){
    Gun g=p.guns[p.gunIndex];
    if(g.ammo<=0) return;

    // ── Air Strike: queue strikes at ring-aimed position ──────────────────
    if (g.bulletAirStrike) {
        if (Float.isNaN(state.asAimAngle)) return; // no target selected yet
        g.ammo--;
        if(p.isStealthed()) p.skillActiveUntil = 0;
        long now = System.currentTimeMillis();
        // Target world position: joystick magnitude maps 0→player, 1→ring edge
        float targetDist = state.asAimMag * AS_RING_R;
        float cx = p.x + (float)Math.cos(state.asAimAngle) * targetDist;
        float cy = p.y + (float)Math.sin(state.asAimAngle) * targetDist;
        cx = Math.max(0, Math.min(MAP_W, cx));
        cy = Math.max(0, Math.min(MAP_H, cy));
        // Triple explosion: fires 3 times with stagger after warning
        long triggerMs = now + AS_WARNING_MS;
        state.airStrikes.add(new double[]{cx, cy, (double)triggerMs, (double)p.id, 0.0, 2.0});
        state.asAimAngle = Float.NaN; state.asAimMag = 0f;
        return;
    }

    // FIX: Shadow Blade is purely melee — launchShadowBlade handles all its logic.
    // Without this guard, applyClientInputs was spawning real travelling state.bullets
    // for the Shadow Blade gun whenever fire-input was high, causing phantom
    // damage that had nothing to do with the dash-slash mechanic.
    if (g.bulletShadowBlade) return;

    g.ammo--;
    // Firing breaks stealth immediately
    if(p.isStealthed()) p.skillActiveUntil = 0;
    // Coin Gun: scale damage with wealth  (20 @ 0 coins → 120 @ 600 coins)
    float coinDmg = g.coinScaling ? 20f + Math.min(p.coins, 600) * 0.167f : g.damage;
    for(int i=0;i<g.pellets;i++){
        float s=(float)(Math.random()-0.5)*g.spread*2, a=p.angle+s;
        float spd=g.bulletSpeed*(0.96f+(float)Math.random()*0.08f);
        float rangeVal = g.range * p.rangeMult();
        float dmg = g.coinScaling ? coinDmg : g.damage;
        Bullet bl = new Bullet(p.x,p.y,(float)Math.cos(a)*spd,(float)Math.sin(a)*spd,p.id,dmg,state.bulletId++,rangeVal);
        bl.bouncesLeft  = g.bulletBounces;
        bl.piercing     = g.bulletPiercing;
        bl.explosive    = g.bulletExplosive;
        bl.homing       = g.bulletHoming;
        bl.ghost        = g.bulletGhost;
        bl.hookSpear    = g.bulletHookSpear;
        bl.isSoulReaper = (p.gunIndex == 20);
        bl.soulTier     = (p.gunIndex == 20) ? p.guns[20].soulLevel() : 0;
        bl.isShadowBlade = (p.gunIndex == 21);
        // Paint color: 1=blue(slow), 2=green(poison), 3=per-shot alternating (toggle each shot)
        if(g.paintBulletColor==3) {
            if (g.paintMode == 1) { bl.paintColor = 1; }       // SLOW mode — always blue
            else if (g.paintMode == 2) { bl.paintColor = 2; }  // POISON mode — always green
            else { bl.paintColor = g.paintShotToggle; }         // ALT mode — toggling
        }
        else bl.paintColor = g.paintBulletColor;
        bl.slowDurationMs   = g.slowMs;
        bl.slowSpeedMult    = g.slowSpeedMult;
        bl.poisonDurationMs = g.poisonMs;
        bl.poisonTickDamage = g.poisonDmg;
        bl.stunBonusMs      = g.stunBonusMs;
        bl.explosionDmg     = g.explosionDmg;
        if(bl.piercing) bl.hitIds = new HashSet<>();
        state.bullets.add(bl);
    }
    // Per-shot paint toggle: flip between poison(2) and slow(1) after each shot (ALT mode only)
    if(g.paintBulletColor==3 && g.paintMode==0) g.paintShotToggle = (g.paintShotToggle == 2) ? 1 : 2;
}

boolean isVoltChakram(Gun g) {
    return g != null && "Volt Chakram".equals(g.name);
}

boolean isShadowBlade(Gun g) {
    return g != null && "Shadow Blade".equals(g.name);
}

void launchQuickSlash(GameState state, Player lp, float nx, float ny) {
    if (!state.isHost) return;   // clients only queue; host executes authoritatively
    Gun g = lp.currentGun();
    if (g.ammo <= 0 || g.reloading) return;

    float launchAngle = (float) Math.atan2(ny, nx);
    float slashRange  = 150f;   // shorter than the full charged slash (280f dash + 160f static)
    float damage      = 40f;    // lighter than the full 50f charged slash
    float hitWidth    = 32f;

    // Small lunge — step the player forward so the slash feels aggressive
    float lungeAmount = 35f;
    float[] lungeEnd  = dashWithWallStop(lp.x, lp.y, launchAngle, lungeAmount);
    lp.x = lungeEnd[0];
    lp.y = lungeEnd[1];

    float startX = lp.x, startY = lp.y;
    float endX   = startX + nx * slashRange;
    float endY   = startY + ny * slashRange;

    if (lp.isStealthed()) lp.skillActiveUntil = 0;

    // Hit detection along the slash segment
    float ldx = endX - startX, ldy = endY - startY;
    float lenSq = ldx*ldx + ldy*ldy;
    Bullet proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
    proxy.isShadowBlade = true;

    for (Player rp : state.remote.values()) {
        if (!rp.alive || rp.id == lp.id) continue;
        if (pointToSegDist(rp.x, rp.y, startX, startY, endX, endY, lenSq) <= hitWidth) {
            applyBulletDamage(state, proxy, state.localPlayer != null ? state.localPlayer : lp, rp, state.localPlayer != null ? state.localPlayer : lp);
            proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
            proxy.isShadowBlade = true;
        }
    }
    if (state.localPlayer != null && state.localPlayer.alive && state.localPlayer.id != lp.id) {
        if (pointToSegDist(state.localPlayer.x, state.localPlayer.y, startX, startY, endX, endY, lenSq) <= hitWidth)
            applyBulletDamage(state, proxy, state.localPlayer, null, state.localPlayer);
    }

    // Crescent arc — slightly larger radius so it looks distinct from the full slash
    float fxScale = 0.85f;
    long now = System.currentTimeMillis();
    // Anchor FX at midpoint so the arc appears right in front of the player
    float fxX = (startX + endX) * 0.5f;
    float fxY = (startY + endY) * 0.5f;
    state.effects.slashTrails.add(new float[]{fxX, fxY, 55f * fxScale, now - EffectsManager.FX_EPOCH, launchAngle, 0});
    state.effects.slashTrails.add(new float[]{fxX, fxY, 47f * fxScale, now - EffectsManager.FX_EPOCH, launchAngle, 1});
    state.effects.slashTrails.add(new float[]{fxX, fxY, 60f * fxScale, now - EffectsManager.FX_EPOCH, launchAngle, 2});
    state.effects.crescentFx.add(new float[]{fxX, fxY, launchAngle, (float)(now - EffectsManager.FX_EPOCH)});

    g.ammo--;
    g.markFired();
}

void launchShadowBlade(GameState state, Player lp, float ax, float ay) {
    // FIX: removed "if (!state.isHost) return" — the host now runs this for state.remote players
    // too (via state.netSbQ). Clients that fire locally just reset their charge and return;
    // the actual damage/dash/trail is applied authoritatively on the host.
    if (!state.isHost) { state.shadowBladeCharge = 0f; return; }
    Gun g = lp.currentGun();
    if (g.ammo <= 0 || g.reloading) return;
    float mag = (float) Math.sqrt(ax * ax + ay * ay);
    if (mag < 0.05f) return;

    float charge = state.shadowBladeCharge;
    // Minimum charge to do anything — below this it fizzles
    if (charge < 0.05f) { state.shadowBladeCharge = 0f; return; }
    float launchAngle = (float) Math.atan2(ay / mag, ax / mag);
    long fxNow = System.currentTimeMillis();

    if (lp.isStealthed()) lp.skillActiveUntil = 0;

    float startX = lp.x, startY = lp.y;
    float endX, endY;

    // ════════════════════════════════════════════════════════════════════
    // Tier 1 — Light Slash  (charge < 0.40)
    // Quick forward poke with a short lunge.
    // ════════════════════════════════════════════════════════════════════
    if (charge < 0.40f) {
        float damage   = 35f;
        float hitWidth = 28f;
        float slashRange = 140f;

        float[] lungeEnd = dashWithWallStop(startX, startY, launchAngle, 40f);
        lp.x = lungeEnd[0]; lp.y = lungeEnd[1];
        startX = lp.x; startY = lp.y;
        endX = startX + (float)Math.cos(launchAngle) * slashRange;
        endY = startY + (float)Math.sin(launchAngle) * slashRange;

        float ldx = endX - startX, ldy = endY - startY;
        float lenSq = ldx*ldx + ldy*ldy;
        Bullet proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
        proxy.isShadowBlade = true;
        for (Player rp : state.remote.values()) {
            if (!rp.alive || rp.id == lp.id) continue;
            if (pointToSegDist(rp.x, rp.y, startX, startY, endX, endY, lenSq) <= hitWidth) {
                applyBulletDamage(state, proxy, state.localPlayer != null ? state.localPlayer : lp, rp, state.localPlayer != null ? state.localPlayer : lp);
                proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
                proxy.isShadowBlade = true;
            }
        }
        if (state.localPlayer != null && state.localPlayer.alive && state.localPlayer.id != lp.id)
            if (pointToSegDist(state.localPlayer.x, state.localPlayer.y, startX, startY, endX, endY, lenSq) <= hitWidth)
                applyBulletDamage(state, proxy, state.localPlayer, null, state.localPlayer);

        // FX — tight crescent at mid-point
        float fxX = (startX + endX) * 0.5f, fxY = (startY + endY) * 0.5f;
        float fxTs = (float)(fxNow - EffectsManager.FX_EPOCH);
        float fxSc = 0.6f;
        state.effects.slashTrails.add(new float[]{fxX, fxY, 48f*fxSc, fxTs, launchAngle, 0});
        state.effects.slashTrails.add(new float[]{fxX, fxY, 40f*fxSc, fxTs, launchAngle, 1});
        state.effects.crescentFx.add(new float[]{fxX, fxY, launchAngle, fxTs});

    // ════════════════════════════════════════════════════════════════════
    // Tier 2 — Heavy Slash  (0.40 ≤ charge < 0.85)
    // Strong lunge + wide sweep, no full dash.
    // ════════════════════════════════════════════════════════════════════
    } else if (charge < 0.85f) {
        float damage   = 65f;
        float hitWidth = 36f;
        float slashRange = 200f;

        float[] lungeEnd = dashWithWallStop(startX, startY, launchAngle, 85f);
        lp.x = lungeEnd[0]; lp.y = lungeEnd[1];
        startX = lp.x; startY = lp.y;
        endX = startX + (float)Math.cos(launchAngle) * slashRange;
        endY = startY + (float)Math.sin(launchAngle) * slashRange;

        float ldx = endX - startX, ldy = endY - startY;
        float lenSq = ldx*ldx + ldy*ldy;
        Bullet proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
        proxy.isShadowBlade = true;
        for (Player rp : state.remote.values()) {
            if (!rp.alive || rp.id == lp.id) continue;
            if (pointToSegDist(rp.x, rp.y, startX, startY, endX, endY, lenSq) <= hitWidth) {
                applyBulletDamage(state, proxy, state.localPlayer != null ? state.localPlayer : lp, rp, state.localPlayer != null ? state.localPlayer : lp);
                proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
                proxy.isShadowBlade = true;
            }
        }
        if (state.localPlayer != null && state.localPlayer.alive && state.localPlayer.id != lp.id)
            if (pointToSegDist(state.localPlayer.x, state.localPlayer.y, startX, startY, endX, endY, lenSq) <= hitWidth)
                applyBulletDamage(state, proxy, state.localPlayer, null, state.localPlayer);

        // FX — two crescents at 1/3 and 2/3 of slash
        float fxTs = (float)(fxNow - EffectsManager.FX_EPOCH);
        float fxSc = 0.88f;
        float fx1x = startX + (float)Math.cos(launchAngle) * slashRange * 0.35f;
        float fx1y = startY + (float)Math.sin(launchAngle) * slashRange * 0.35f;
        float fx2x = startX + (float)Math.cos(launchAngle) * slashRange * 0.70f;
        float fx2y = startY + (float)Math.sin(launchAngle) * slashRange * 0.70f;
        state.effects.slashTrails.add(new float[]{fx1x, fx1y, 55f*fxSc, fxTs, launchAngle, 0});
        state.effects.slashTrails.add(new float[]{fx1x, fx1y, 46f*fxSc, fxTs, launchAngle, 1});
        state.effects.slashTrails.add(new float[]{fx2x, fx2y, 58f*fxSc, fxTs+60f, launchAngle, 0});
        state.effects.slashTrails.add(new float[]{fx2x, fx2y, 49f*fxSc, fxTs+60f, launchAngle, 2});
        state.effects.crescentFx.add(new float[]{fx1x, fx1y, launchAngle, fxTs});
        state.effects.crescentFx.add(new float[]{fx2x, fx2y, launchAngle, fxTs + 80f});

    // ════════════════════════════════════════════════════════════════════
    // Tier 3 — Phantom Dash  (charge ≥ 0.85)
    // Full dash + devastating long slash. Maximum damage.
    // ════════════════════════════════════════════════════════════════════
    } else {
        float damage   = 90f;
        float hitWidth = 44f;
        float dashDist = 300f;
        float slashExt = 220f; // extra reach beyond the dash end

        float[] dashEnd = dashWithWallStop(startX, startY, launchAngle, dashDist);
        endX = dashEnd[0] + (float)Math.cos(launchAngle) * slashExt;
        endY = dashEnd[1] + (float)Math.sin(launchAngle) * slashExt;

        // Animate dash for local player — use beginPhantomDash for dark-gold FX
        if (lp == state.localPlayer) {
            state.effects.beginPhantomDash(startX, startY, dashEnd[0], dashEnd[1]);
            lp.x = dashEnd[0]; lp.y = dashEnd[1];
        } else {
            lp.x = dashEnd[0]; lp.y = dashEnd[1];
        }

        float ldx = endX - startX, ldy = endY - startY;
        float lenSq = ldx*ldx + ldy*ldy;
        Bullet proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
        proxy.isShadowBlade = true;
        for (Player rp : state.remote.values()) {
            if (!rp.alive || rp.id == lp.id) continue;
            if (pointToSegDist(rp.x, rp.y, startX, startY, endX, endY, lenSq) <= hitWidth) {
                applyBulletDamage(state, proxy, state.localPlayer != null ? state.localPlayer : lp, rp, state.localPlayer != null ? state.localPlayer : lp);
                proxy = new Bullet(startX, startY, 0, 0, lp.id, damage, -1, 999f);
                proxy.isShadowBlade = true;
            }
        }
        if (state.localPlayer != null && state.localPlayer.alive && state.localPlayer.id != lp.id)
            if (pointToSegDist(state.localPlayer.x, state.localPlayer.y, startX, startY, endX, endY, lenSq) <= hitWidth)
                applyBulletDamage(state, proxy, state.localPlayer, null, state.localPlayer);

        // FX — three crescents along the full path + large outer trail
        float fxTs = (float)(fxNow - EffectsManager.FX_EPOCH);
        float fxSc = 1.15f;
        float totalLen = (float)Math.sqrt((endX-startX)*(endX-startX)+(endY-startY)*(endY-startY));
        for (int i = 1; i <= 3; i++) {
            float frac = i * 0.28f;
            float fxX = startX + (float)Math.cos(launchAngle) * totalLen * frac;
            float fxY = startY + (float)Math.sin(launchAngle) * totalLen * frac;
            float delay = i * 55f;
            state.effects.slashTrails.add(new float[]{fxX, fxY, 55f*fxSc, fxTs+delay, launchAngle, 0});
            state.effects.slashTrails.add(new float[]{fxX, fxY, 47f*fxSc, fxTs+delay, launchAngle, 1});
            state.effects.slashTrails.add(new float[]{fxX, fxY, 62f*fxSc, fxTs+delay, launchAngle, 2});
            state.effects.crescentFx.add(new float[]{fxX, fxY, launchAngle, fxTs + delay});
        }
    }

    g.ammo--;
    g.markFired();
    state.shadowBladeCharge = 0f;
}

private void ensureVoltChakrams(GameState state, Player lp) {
    boolean vcSelected = isVoltChakram(lp.currentGun());
    if (!vcSelected) {
        // Remove only ORBITING discs — launched/returning ones keep flying
        state.voltChakrams.removeIf(vc -> vc.ownerId == lp.id && vc.state == VoltChakram.ORBITING);
        return;
    }
    // Which of the 3 orbit slots already have a disc (any state)?
    boolean[] hasIdx = {false, false, false};
    for (VoltChakram vc : state.voltChakrams)
        if (vc.ownerId == lp.id && vc.orbitIdx >= 0 && vc.orbitIdx < 3)
            hasIdx[vc.orbitIdx] = true;
    for (int i = 0; i < 3; i++)
        if (!hasIdx[i]) state.voltChakrams.add(new VoltChakram(lp.id, i));
}

void launchVoltChakrams(GameState state, Player lp, float ax, float ay) {
    launchVoltChakrams(state, lp, ax, ay, state.voltCharge);
}

void launchVoltChakrams(GameState state, Player lp, float ax, float ay, float charge) {
    float mag = (float) Math.sqrt(ax * ax + ay * ay);
    if (mag < 0.05f) return;          // no direction — don't launch
    float launchAngle = (float) Math.atan2(ay / mag, ax / mag);
    float speed  = 820f + charge * 680f;   // 820–1500 px/s (faster with charge)
    float damage = 18f  + charge * 24f;    // 18–42 per disc
    float range  = 660f + charge * 640f;   // 660–1300 px (longer with charge)
    // Three discs fan out — spread CONDENSES as charge builds (0.21→0.06 rad)
    float spreadAmt = 0.21f - charge * 0.15f;
    float[] spreads = {-spreadAmt, 0f, spreadAmt};
    int slot = 0;
    for (VoltChakram vc : state.voltChakrams) {
        if (vc.ownerId == lp.id && vc.state == VoltChakram.ORBITING && slot < 3) {
            float a = launchAngle + spreads[slot];
            vc.vx = (float) Math.cos(a) * speed;
            vc.vy = (float) Math.sin(a) * speed;
            vc.damage = damage;
            vc.distTraveled = 0f;
            vc.maxRange = range;
            vc.hitIds.clear();
            vc.state = VoltChakram.LAUNCHED;
            slot++;
        }
    }
    state.voltCharge = 0f;
}

void updateVoltChakrams(GameState state, Player lp, float dt) {
    ensureVoltChakrams(state, lp);

    // Self-spin of each disc graphic (always rotating for visual life)
    for (VoltChakram vc : state.voltChakrams) vc.spinAngle += dt * 4.5f;

    int orbiting = 0;
    Iterator<VoltChakram> it = state.voltChakrams.iterator();
    while (it.hasNext()) {
        VoltChakram vc = it.next();

        // Skip discs that belong to a different player — their positions
        // come from the host's authoritative broadcast, not from this update.
        if (vc.ownerId != lp.id) continue;

        // ── ORBITING ──────────────────────────────────────────────────────
        if (vc.state == VoltChakram.ORBITING) {
            float orbitA = state.voltOrbitAngle + vc.orbitIdx * (float)(Math.PI * 2 / 3);
            vc.x = lp.x + VoltChakram.ORBIT_RADIUS * (float) Math.cos(orbitA);
            vc.y = lp.y + VoltChakram.ORBIT_RADIUS * (float) Math.sin(orbitA);
            // Damage enemies that walk into orbit range (18 dmg every 700ms per disc)
            if (state.isHost) {
                long now = System.currentTimeMillis();
                if (now >= vc.nextOrbitHitMs) {
                    boolean hit = false;
                    // FIX Bug3: was `vc.ownerId != lp.id` which is always false here
                    // (non-owner VCs are skipped above). Check state.localPlayer explicitly
                    // so bot chakrams can correctly orbit-damage the human player.
                    Player hlp = state.localPlayer;
                    if (hlp != null && hlp.alive && vc.ownerId != hlp.id) {
                        float dx = hlp.x - vc.x, dy = hlp.y - vc.y;
                        if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                            Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, 18f, -1, 999f);
                            applyBulletDamage(state, proxy, hlp, null, hlp);
                            hit = true;
                        }
                    }
                    for (Player rp : state.remote.values()) {
                        if (!rp.alive || vc.ownerId == rp.id) continue;
                        float dx = rp.x - vc.x, dy = rp.y - vc.y;
                        if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
                            Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, 18f, -1, 999f);
                            Player hlp2 = state.localPlayer;
                            applyBulletDamage(state, proxy, hlp2 != null ? hlp2 : lp, rp, hlp2 != null ? hlp2 : lp);
                            hit = true;
                        }
                    }
                    if (hit) vc.nextOrbitHitMs = now + 700L;
                }
            }
            orbiting++;
            continue;
        }

        // ── LAUNCHED ──────────────────────────────────────────────────────
        if (vc.state == VoltChakram.LAUNCHED) {
            float nx = vc.x + vc.vx * dt;
            float ny = vc.y + vc.vy * dt;

            // Wall check → reverse to RETURNING
            boolean hitWall = false;
            for (float[] w : WALLS) {
                if (nx >= w[0]-6 && nx <= w[2]+6 && ny >= w[1]-6 && ny <= w[3]+6) {
                    hitWall = true; break;
                }
            }
            vc.distTraveled += (float) Math.sqrt((nx-vc.x)*(nx-vc.x)+(ny-vc.y)*(ny-vc.y));

            if (hitWall || vc.distTraveled >= vc.maxRange) {
                vc.state = VoltChakram.RETURNING;
                vc.hitIds.clear();  // can re-hit on the way back
                continue;
            }
            vc.x = nx; vc.y = ny;

            // Hit detection (host only)
            if (state.isHost) applyChakramHits(state, vc, lp);
            continue;
        }

        // ── RETURNING ─────────────────────────────────────────────────────
        if (vc.state == VoltChakram.RETURNING) {
            float dx = lp.x - vc.x, dy = lp.y - vc.y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);

            if (dist < 24f) {
                // Disc caught by player — back to orbit
                vc.state = VoltChakram.ORBITING;
                vc.hitIds.clear();
                orbiting++;
                continue;
            }
            float spd = VoltChakram.RETURN_SPEED;
            // Keep vx/vy in sync with actual movement so the trail renders correctly
            vc.vx = (dx / dist) * spd;
            vc.vy = (dy / dist) * spd;
            vc.x += vc.vx * dt;
            vc.y += vc.vy * dt;

            if (state.isHost) applyChakramHits(state, vc, lp);
        }
    }

    // Keep gun ammo in sync with orbiting count for the HUD
    Gun g = lp.currentGun();
    if (isVoltChakram(g)) g.ammo = orbiting;
}

private void applyChakramHits(GameState state, VoltChakram vc, Player lp) {
    // Local player
    if (lp.alive && vc.ownerId != lp.id && !vc.hitIds.contains(lp.id)) {
        float dx = lp.x - vc.x, dy = lp.y - vc.y;
        if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
            vc.hitIds.add(lp.id);
            // Re-use applyBulletDamage by creating a thin proxy bullet
            Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, vc.damage, -1, 999f);
            applyBulletDamage(state, proxy, lp, null, lp);
        }
    }
    // Remote players
    for (Player rp : state.remote.values()) {
        if (!rp.alive || vc.ownerId == rp.id || vc.hitIds.contains(rp.id)) continue;
        float dx = rp.x - vc.x, dy = rp.y - vc.y;
        if (dx*dx + dy*dy < VoltChakram.HIT_RADIUS * VoltChakram.HIT_RADIUS) {
            vc.hitIds.add(rp.id);
            Bullet proxy = new Bullet(vc.x, vc.y, 0, 0, vc.ownerId, vc.damage, -1, 999f);
            applyBulletDamage(state, proxy, lp, rp, lp);
        }
    }
}

void updateBullets(GameState state, Player lp, float dt){
    Iterator<Bullet> it=state.bullets.iterator();
    while(it.hasNext()){
        Bullet b=it.next();

        // ── Homing: steer toward nearest enemy ONLY if within 160px and in front 120° cone ──
        if(b.homing){
            float tx=Float.MAX_VALUE, ty=0; float bestDist=Float.MAX_VALUE;
            float curA=(float)Math.atan2(b.dy,b.dx);
            float coneHalf = (float)(Math.PI / 3); // 60 deg each side
            float seekRangeSq = 160f * 160f;       // only home within 160px
            if(lp.alive&&b.ownerId!=lp.id){
                float d=d2(b.x,b.y,lp.x,lp.y);
                float ang=(float)Math.atan2(lp.y-b.y,lp.x-b.x);
                float diff=ang-curA; while(diff>Math.PI)diff-=2*(float)Math.PI; while(diff<-Math.PI)diff+=2*(float)Math.PI;
                if(d<seekRangeSq&&Math.abs(diff)<coneHalf&&d<bestDist){bestDist=d;tx=lp.x;ty=lp.y;}
            }
            for(Player rp:state.remote.values()){
                if(b.ownerId==rp.id||!rp.alive) continue;
                float d=d2(b.x,b.y,rp.x,rp.y);
                float ang=(float)Math.atan2(rp.y-b.y,rp.x-b.x);
                float diff=ang-curA; while(diff>Math.PI)diff-=2*(float)Math.PI; while(diff<-Math.PI)diff+=2*(float)Math.PI;
                if(d<seekRangeSq&&Math.abs(diff)<coneHalf&&d<bestDist){bestDist=d;tx=rp.x;ty=rp.y;}
            }
            if(tx!=Float.MAX_VALUE){
                float tgtA=(float)Math.atan2(ty-b.y,tx-b.x);
                float diff=tgtA-curA; while(diff>Math.PI)diff-=2*(float)Math.PI; while(diff<-Math.PI)diff+=2*(float)Math.PI;
                // Weak 1.2 rad/s turn — curves toward enemy but still missable
                float turn=Math.signum(diff)*Math.min(Math.abs(diff),1.2f*dt);
                float na=curA+turn; float spd=(float)Math.sqrt(b.dx*b.dx+b.dy*b.dy);
                b.dx=(float)Math.cos(na)*spd; b.dy=(float)Math.sin(na)*spd;
            }
        }

        // ── Move ─────────────────────────────────────────────────────────
        float nx=b.x+b.dx*dt, ny=b.y+b.dy*dt;
        boolean rm=false;

        // ── Boundary ─────────────────────────────────────────────────────
        boolean xOut=nx<0||nx>MAP_W, yOut=ny<0||ny>MAP_H;
        if(xOut||yOut){
            if(b.bouncesLeft>0){
                if(xOut){b.dx=-b.dx;nx=Math.max(0,Math.min(MAP_W,nx));}
                if(yOut){b.dy=-b.dy;ny=Math.max(0,Math.min(MAP_H,ny));}
                b.bouncesLeft--; b.spawnX=nx; b.spawnY=ny;
            } else { if(b.explosive) doExplosion(state, b,lp); rm=true; }
        }

        // ── Walls ─────────────────────────────────────────────────────────
        if(!rm&&!b.ghost){
            boolean xB=false,yB=false;
            for(float[] w:WALLS){
                if(!xB&&nx>=w[0]&&nx<=w[2]&&b.y>=w[1]&&b.y<=w[3]) xB=true;
                if(!yB&&b.x>=w[0]&&b.x<=w[2]&&ny>=w[1]&&ny<=w[3]) yB=true;
            }
            if(!xB&&!yB) for(float[] w:WALLS) if(nx>=w[0]&&nx<=w[2]&&ny>=w[1]&&ny<=w[3]){xB=true;yB=true;break;}
            if(xB||yB){
                if(b.bouncesLeft>0){
                    if(xB) b.dx=-b.dx; if(yB) b.dy=-b.dy;
                    if(!xB&&!yB){b.dx=-b.dx;b.dy=-b.dy;}
                    b.bouncesLeft--; b.spawnX=b.x; b.spawnY=b.y; nx=b.x; ny=b.y;
                } else { if(b.explosive) doExplosion(state, b,lp); rm=true; }
            }
        }

        b.x=nx; b.y=ny;

        // ── Range culling ─────────────────────────────────────────────────
        if(!rm){float rdx=b.x-b.spawnX,rdy=b.y-b.spawnY;
            if(rdx*rdx+rdy*rdy>b.range*b.range){if(b.explosive)doExplosion(state, b,lp);rm=true;}}
        if(!rm&&System.currentTimeMillis()-b.spawnTime>5000) rm=true;

        // ── Hit detection ─────────────────────────────────────────────────
        if(!rm&&state.isHost){
            if(lp.alive&&b.ownerId!=lp.id&&d2(b.x,b.y,lp.x,lp.y)<PR*PR){
                if(b.piercing){
                    if(b.hitIds!=null&&!b.hitIds.contains(lp.id)){b.hitIds.add(lp.id);applyBulletDamage(state, b,lp,null,lp);}
                } else { rm=true; if(b.explosive) doExplosion(state, b,lp); else applyBulletDamage(state, b,lp,null,lp); }
            }
            if((!rm||b.piercing)) for(Player rp:state.remote.values()){
                if(b.ownerId==rp.id||!rp.alive) continue;
                if(d2(b.x,b.y,rp.x,rp.y)<PR*PR){
                    if(b.piercing){
                        if(b.hitIds!=null&&!b.hitIds.contains(rp.id)){b.hitIds.add(rp.id);applyBulletDamage(state, b,lp,rp,lp);}
                    } else { rm=true; if(b.explosive) doExplosion(state, b,lp); else applyBulletDamage(state, b,lp,rp,lp); break; }
                }
            }
        }
        // ── Client-side hit prediction: instant visual feedback ───────────
        // On the client (not host), when a LOCAL bullet overlaps a state.remote player,
        // flash a hit marker immediately without waiting for server confirmation.
        if(!rm && !state.isHost && b.ownerId==lp.id){
            for(Player rp:state.remote.values()){
                if(!rp.alive) continue;
                if(d2(b.x,b.y,rp.x,rp.y)<(PR*1.4f)*(PR*1.4f)){
                    // Only flash once per bullet-player pair (check hitIds)
                    if(b.hitIds==null) b.hitIds=new java.util.HashSet<>();
                    if(!b.hitIds.contains(rp.id)){
                        b.hitIds.add(rp.id);
                        state.effects.predictedHitFx.add(new long[]{(long)b.x,(long)b.y,System.currentTimeMillis()});
                    }
                }
            }
        }
        if(rm) it.remove();
    }
}

private void applyBulletDamage(GameState state, Bullet b, Player lp, Player rp, Player localP){
    Player t=(rp!=null)?rp:lp;
    if(t.isProtected()) return;
    // Being hit breaks stealth
    if(t.isStealthed()) t.skillActiveUntil = 0;
    float dmg=b.damage;
    if(t.isShielded()){float reduced=dmg*0.5f;float abs=Math.min(reduced,t.shieldHp);t.shieldHp-=abs;dmg-=abs;if(t.shieldHp<=0)t.skillActiveUntil=0;}
    t.hp=Math.max(0,t.hp-dmg);
    // ── Apply paint status state.effects ─────────────────────────────────────────
    long now=System.currentTimeMillis();
    if(b.paintColor==1){ // blue = slow
        t.slowUntil     = Math.max(t.slowUntil, now+b.slowDurationMs);
        t.slowSpeedMult = b.slowSpeedMult;  // per-gun speed mult (was always ignored before)
    } else if(b.paintColor==2){ // green = poison
        t.poisonUntil = Math.max(t.poisonUntil, now+b.poisonDurationMs);
        t.poisonOwnerId    = b.ownerId;
        t.poisonTickDamage = b.poisonTickDamage;
    }
    if (b.hookSpear) {
        t.hookPullFromX  = b.spawnX;
        t.hookPullFromY  = b.spawnY;
        t.hookPullOwnerId = b.ownerId;
        float hdx = t.x - b.spawnX, hdy = t.y - b.spawnY;
        float hitDist = (float)Math.sqrt(hdx*hdx + hdy*hdy);
        long pullDuration = Math.max(600L, (long)(hitDist / StatusEffectConfig.HOOK_PULL_SPEED * 1000f) + 500L);
        t.hookPullUntil  = now + pullDuration;
        t.stunUntil      = now + pullDuration + b.stunBonusMs;
    }
    if(t.hp==0){
        if(rp==null){
            // Remote bullet killed the host's local player
            t.alive=false;state.deathTime=System.currentTimeMillis();state.throwingBomb=false;
            state.addFeed(state.nameOf(b.ownerId)+" ➜ "+t.name);
            Player k=state.remote.get(b.ownerId);
            state.onKill(k, t);
            if(k!=null && b.isSoulReaper){
                int prevLv = k.guns[20].soulLevel();
                k.guns[20].killCount++; k.guns[20].applySoulLevel();
                if(k.guns[20].soulLevel() > prevLv) state.addFeed("☠ " + k.name + " Soul Surge TIER UP → Tier " + k.guns[20].soulLevel());
                if(b.soulTier >= 6) doElectricBurst(state, t.x, t.y, b.ownerId, b.soulTier,
                        b.soulTier >= 8 ? ECHAIN_MAX_HOPS : 0, lp);
            }
        } else {
            // A bullet killed a state.remote player
            t.alive=false;state.deadAtMs.put(t.id,System.currentTimeMillis());
            state.addFeed(state.nameOf(b.ownerId)+" ➜ "+t.name);
            if(b.ownerId==localP.id){
                state.onKill(localP, t);
                if(b.isSoulReaper){
                    int prevLv = localP.guns[20].soulLevel();
                    localP.guns[20].killCount++; localP.guns[20].applySoulLevel();
                    if(localP.guns[20].soulLevel() > prevLv) state.addFeed("☠ Soul Surge TIER UP! → Tier " + localP.guns[20].soulLevel());
                    if(b.soulTier >= 6) doElectricBurst(state, t.x, t.y, b.ownerId, b.soulTier,
                            b.soulTier >= 8 ? ECHAIN_MAX_HOPS : 0, lp);
                }
            } else {
                Player k=state.remote.get(b.ownerId);
                if(k!=null){
                    state.onKill(k, t);
                    if(b.isSoulReaper){
                        int prevLv = k.guns[20].soulLevel();
                        k.guns[20].killCount++; k.guns[20].applySoulLevel();
                        if(k.guns[20].soulLevel() > prevLv) state.addFeed("☠ " + k.name + " Soul Surge TIER UP → Tier " + k.guns[20].soulLevel());
                        if(b.soulTier >= 6) doElectricBurst(state, t.x, t.y, b.ownerId, b.soulTier,
                                b.soulTier >= 8 ? ECHAIN_MAX_HOPS : 0, lp);
                    }
                }
            }
        }
    }
}

void updateHookPulls(GameState state, float dt) {
    if (!state.isHost) return;
    applyHookPull(state, state.localPlayer, dt);
    for (Player rp : state.remote.values()) applyHookPull(state, rp, dt);
}

private void applyHookPull(GameState state, Player p, float dt) {
    if (p == null || !p.alive || !p.isBeingPulled()) return;
    // Keep pull origin locked to caster's current position so target is dragged all the way to them
    Player caster = (state.localPlayer != null && p.hookPullOwnerId == state.localPlayer.id)
            ? state.localPlayer : state.remote.get(p.hookPullOwnerId);
    if (caster != null) { p.hookPullFromX = caster.x; p.hookPullFromY = caster.y; }
    float dx = p.hookPullFromX - p.x, dy = p.hookPullFromY - p.y;
    float dist = (float) Math.sqrt(dx*dx + dy*dy);
    // Stop pulling when very close to caster (within 2*PR)
    if (dist < PR * 2f) { p.hookPullUntil = 0; return; }
    float pullSpd = StatusEffectConfig.HOOK_PULL_SPEED;
    float nx = p.x + (dx/dist) * pullSpd * dt;
    float ny = p.y + (dy/dist) * pullSpd * dt;
    nx = clamp(nx, PR, MAP_W-PR); ny = clamp(ny, PR, MAP_H-PR);
    float[] pos = walls(p.x, p.y, nx, ny); p.x = pos[0]; p.y = pos[1];
}

private void doExplosion(GameState state, Bullet b, Player lp){
    // Visual FX — stored as {x, y, spawnMs} drawn by all clients
    state.effects.explosionFx.add(new long[]{(long)b.x, (long)b.y, System.currentTimeMillis()});
    if(!state.isHost) return;
    float R=150f;
    // Swap in explosion damage so applyBulletDamage uses AOE value, not bullet base damage
    float savedDmg = b.damage;
    b.damage = b.explosionDmg;
    if(lp.alive&&b.ownerId!=lp.id&&d2(b.x,b.y,lp.x,lp.y)<R*R) applyBulletDamage(state, b,lp,null,lp);
    for(Player rp:state.remote.values()){
        if(b.ownerId==rp.id||!rp.alive) continue;
        if(d2(b.x,b.y,rp.x,rp.y)<R*R) applyBulletDamage(state, b,lp,rp,lp);
    }
    b.damage = savedDmg;
}

private void doElectricBurst(GameState state, float cx, float cy, int ownerId, int tier,
                             int hopsLeft, Player lp) {
    if (!state.isHost) return;

    // Visual fx — cyan electric ring (index 0=x,1=y,2=spawnMs,3=chain depth)
    state.effects.electricBurstFx.add(new long[]{(long)cx, (long)cy,
            System.currentTimeMillis(), (long)(ECHAIN_MAX_HOPS - hopsLeft)});

    float R2 = EBURST_RADIUS * EBURST_RADIUS;
    float dmg = EBURST_DAMAGE;

    // Damage local player if in radius and not the killer
    if (lp != null && lp.alive && lp.id != ownerId
            && d2(cx, cy, lp.x, lp.y) < R2) {
        if (!lp.isProtected()) {
            lp.hp = Math.max(0, lp.hp - dmg);
            if (lp.hp == 0) {
                lp.alive = false; state.deathTime = System.currentTimeMillis();
                state.addFeed("⚡ " + state.nameOf(ownerId) + " (Soul Surge chain) → " + lp.name);
                state.onKill(ownerId == (lp != null ? lp.id : -1) ? lp : state.remote.get(ownerId), lp);
                if (hopsLeft > 0)
                    doElectricBurst(state, lp.x, lp.y, ownerId, tier, hopsLeft - 1, lp);
            }
        }
    }

    // Damage state.remote players in radius
    for (Player rp : state.remote.values()) {
        if (!rp.alive || rp.id == ownerId) continue;
        if (d2(cx, cy, rp.x, rp.y) < R2) {
            if (!rp.isProtected()) {
                rp.hp = Math.max(0, rp.hp - dmg);
                if (rp.hp == 0) {
                    rp.alive = false;
                    state.deadAtMs.put(rp.id, System.currentTimeMillis());
                    if (!state.dummyIds.contains(rp.id)) {
                        state.addFeed("⚡ " + state.nameOf(ownerId) + " (Soul Surge chain) → " + rp.name);
                        Player killer = (lp != null && lp.id == ownerId)
                                ? lp : state.remote.get(ownerId);
                        state.onKill(killer, rp);
                        if (hopsLeft > 0)
                            doElectricBurst(state, rp.x, rp.y, ownerId, tier, hopsLeft - 1, lp);
                    }
                }
            }
        }
    }
}

/** Applies poison damage (8 dmg every 600 ms) to local + state.remote players. */


/** Shortest distance from point (px,py) to segment (ax,ay)→(bx,by). lenSq = |b-a|². */
private float pointToSegDist(float px, float py,
                              float ax, float ay, float bx, float by, float lenSq) {
    if (lenSq == 0f) return (float) Math.sqrt((px-ax)*(px-ax)+(py-ay)*(py-ay));
    float t = ((px-ax)*(bx-ax)+(py-ay)*(by-ay)) / lenSq;
    t = Math.max(0f, Math.min(1f, t));
    float cx = ax + t*(bx-ax), cy = ay + t*(by-ay);
    return (float) Math.sqrt((px-cx)*(px-cx)+(py-cy)*(py-cy));
}
}
