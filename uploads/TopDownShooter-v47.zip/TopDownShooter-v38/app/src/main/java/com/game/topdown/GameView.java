package com.game.topdown;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import org.json.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GameView extends SurfaceView
        implements SurfaceHolder.Callback, Runnable, NetworkManager.Callback {

    // ═══ WORLD ════════════════════════════════════════════════════════════════
    static final float MAP_W = 2400, MAP_H = 2400;
    static final int   PR    = 24;
    static final long  RESPAWN_MS = 5000;

    static final float[][] WALLS = {
        {400,310,760,350}, {880,120,920,560}, {280,660,315,980},
        {560,540,920,580}, {1100,370,1460,410}, {1530,210,1570,670},
        {680,960,720,1310}, {960,840,1320,880}, {180,1160,540,1200},
        {1430,960,1470,1320}, {540,1520,1060,1560}, {1250,1360,1570,1400},
        {1700,480,1740,920}, {300,1480,340,1920}, {820,1780,1220,1820},
        {1600,1580,1640,2020},
    };
    static final float[][] SPAWNS = {
        {120,120},{2280,120},{120,2280},{2280,2280},
        {1200,120},{120,1200},{2280,1200},{1200,2280},
    };

    // ═══ STATE ════════════════════════════════════════════════════════════════
    private volatile Player   localPlayer;   // volatile: written by net thread (client join)
    private final String      savedName;
    private final Map<Integer,Player> remote   = new ConcurrentHashMap<>();
    private final Map<Integer,Long>   deadAtMs = new ConcurrentHashMap<>();
    private final List<Bullet>        bullets  = new ArrayList<>();
    private int bulletId;

    // ═══ NETWORK ══════════════════════════════════════════════════════════════
    private final NetworkManager          net;
    private final boolean                 isHost;
    private final boolean                 singlePlayer;
    private final Set<Integer>            botIds = new HashSet<>();
    private volatile String               pendingState;
    private final Map<Integer,float[]>    inputs = new ConcurrentHashMap<>();
    private long lastBroadcast;
    private String hostIpDisplay = "";  // shown in HUD

    // ═══ INPUT ════════════════════════════════════════════════════════════════
    private Joystick moveStick, aimStick;
    private RectF    switchRect, reloadRect, bombRect, dropRect;

    // ═══ BOMBS ════════════════════════════════════════════════════════════════
    private final List<Bomb> activeBombs = new ArrayList<>();
    private volatile boolean throwingBomb = false;  // true while player is aiming a throw

    // ═══ CONTROL SETTINGS ════════════════════════════════════════════════════
    private static final String PREFS = "shooter_ctrl";
    private volatile boolean settingsOpen = false;
    private RectF   gearRect, settingsPanel, closeSettingsRect;
    private final RectF[] jsSizeOpts  = new RectF[3];
    private final RectF[] swapOpts    = new RectF[2];
    private final RectF[] btnSizeOpts = new RectF[3];
    private final RectF[] opacityOpts   = new RectF[3];
    private final RectF[] aimSensOpts   = new RectF[3];
    private final RectF[] gunStatOpts   = new RectF[2]; // ON/OFF gun stat bars
    private final RectF[] aimLineOpts   = new RectF[2]; // ON/OFF aim line
    private RectF moveBtnsRect;          // "MOVE BUTTONS" button in settings

    // ═══ SHOP ════════════════════════════════════════════════════════════════
    private volatile boolean shopOpen = false;
    private RectF   shopBtn, shopCloseRect;
    private final RectF[] shopBuyRects = new RectF[7];
    static final int[] GUN_PRICES = {0, 50, 60, 80, 120, 90, 150};

    // ═══ SKILL SHOP ══════════════════════════════════════════════════════════
    private int   shopTab = 0;   // 0 = guns, 1 = skills
    private RectF shopTabGuns, shopTabSkills;
    private RectF skillRect;                         // active-skill use button
    private final RectF[] passiveBuyRects = new RectF[4];
    private final RectF[] activeBuyRects  = new RectF[4];
    static final int[] PASSIVE_SKILL_COSTS = {40, 70, 100};   // per level
    static final int[] ACTIVE_SKILL_COSTS  = {80, 100, 80, 90}; // dash/stealth/heal/shield

    // ═══ SECRET NAME CHEATS ══════════════════════════════════════════════════
    // "kjm" → infinite ammo (no reload ever)
    // "khm" → zero skill cooldown (skills fire instantly, back-to-back)
    private boolean cheatInfiniteAmmo = false;
    private boolean cheatNoSkillCd    = false;
    private void detectCheats(String name) {
        if (name == null) return;
        String n = name.trim().toLowerCase();
        if (n.equals("kjm")) { cheatInfiniteAmmo = true; }
        if (n.equals("khm")) { cheatNoSkillCd    = true; }
    }
    private volatile boolean pendingPositionSync = false;  // send pos after dash
    private volatile float[] pendingBombSend     = null;   // [vx,vy,maxRange] from client bomb throw

    // ═══ DASH ANIMATION ══════════════════════════════════════════════════════
    private boolean dashAnimating  = false;
    private float   dashAnimStartX, dashAnimStartY;
    private float   dashAnimEndX,   dashAnimEndY;
    private long    dashAnimBegin;
    private static final long DASH_ANIM_MS = 160;

    // ═══ DASH AFTEREFFECTS ═══════════════════════════════════════════════════
    // Each ghost: [worldX, worldY, spawnTimeMs]
    private final List<float[]> dashGhosts      = new ArrayList<>();
    // Bot dash ghosts: [worldX, worldY, spawnTimeMs]  (drawn in orange/red)
    private final List<float[]> botDashGhosts   = new ArrayList<>();
    private static final long   GHOST_LIFE_MS   = 420;
    private long                lastGhostTimeMs = 0;

    // ═══ DIFFICULTY (0=Easy 1=Normal 2=Hard) ══════════════════════════════
    private int difficulty = 1;

    // ═══ AI VELOCITY TRACKING (predictive aiming) ═════════════════════════
    private float lpVelX = 0f, lpVelY = 0f;
    private float lpPrevX = -1f, lpPrevY = -1f;

    // ═══ BUTTON DRAG ══════════════════════════════════════════════════════════
    private boolean btnMoveMode  = false; // drag-to-reposition mode
    private int     draggingBtn  = -1;    // 0=switch, 1=reload, -1=none
    private float   dragOffX, dragOffY;
    private RectF   confirmMoveRect;      // ✓ button to exit move mode

    // ═══ CAMERA ZOOM ══════════════════════════════════════════════════════════
    private float currentZoom = 1.0f;    // smoothly interpolated per-gun zoom
    private Paint settingsBgP, settingsLabelP, optBtnP, optBtnSelP, optTxtP, settingsTitleP, closeBtnP;

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    private volatile boolean  gameRunning;
    private Thread            gameThread;
    private float             screenW, screenH, camX, camY;
    private float             camPanX, camPanY;   // aim-pan offset (smoothly lerped)
    private int               tick;
    private long              deathTime;

    private Paint bgP,gridP,wallP,bdrP,remP,locP,shP,hpBgP,
                  bulletP,nameP,hudP,hudBgP,btnP,btnTxtP,
                  deathBgP,deathTxtP,gunTxtP,ipPaint;

    private final List<String> feed = new ArrayList<>();

    // ═══ CTOR ═════════════════════════════════════════════════════════════════

    /** Single-player constructor — no networking, with bot enemies. */
    public GameView(Context ctx, String name, int botCount, int difficulty) {
        super(ctx);
        savedName    = name;
        isHost       = true;
        singlePlayer = true;
        net          = null;
        this.difficulty = difficulty;
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();
        spawnLocal(0, name);
        // Spawn bots — IDs 10, 11, 12 … well away from real player IDs
        for (int i = 0; i < botCount; i++) {
            int botId = 10 + i;
            Player bot = new Player();
            bot.id = botId; bot.name = "Bot " + (i + 1); bot.guns = Gun.createAll();
            float[] sp = SPAWNS[botId % SPAWNS.length];
            bot.x = sp[0]; bot.y = sp[1]; bot.hp = 100; bot.alive = true;

            // Give each bot a DIFFERENT starting gun so they're varied
            // 0=Pistol 1=SMG 2=Shotgun 3=Assault 4=Sniper 5=Burst 6=Minigun
            int[] startGuns = {3, 1, 2, 5, 4, 0, 6}; // assault, smg, shotgun, burst, sniper, pistol, minigun
            int startGun = startGuns[i % startGuns.length];
            bot.gunIndex = startGun;
            bot.unlockedGuns[startGun] = true;

            // Give each bot a starting active skill — they'll never earn
            // enough coins fast enough otherwise, so they never use skills
            int[] startSkills = {Player.ACTIVE_HEAL, Player.ACTIVE_DASH,
                                 Player.ACTIVE_SHIELD, Player.ACTIVE_STEALTH};
            bot.activeSkillType = startSkills[i % startSkills.length];

            // Starting coins so Normal bots can buy upgrades after a few kills
            if (difficulty == 1) bot.coins = 40;
            if (difficulty == 2) bot.coins = 200;
            remote.put(botId, bot);
            botIds.add(botId);
        }
    }

    /** Multiplayer constructor — host or client. */
    public GameView(Context ctx, String name, boolean host, String hostIp) {
        super(ctx);
        savedName    = name;
        isHost       = host;
        singlePlayer = false;
        net          = new NetworkManager(this);
        detectCheats(name);
        getHolder().addCallback(this);
        setFocusable(true);
        initPaints();

        if (host) hostIpDisplay = detectLocalIp();

        try {
            if (host) { net.startHost(name); spawnLocal(0, name); }
            else        net.joinGame(hostIp, name);
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ═══ PAINTS ═══════════════════════════════════════════════════════════════
    private void initPaints() {
        bgP     = fill(Color.rgb(12,25,18));
        gridP   = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridP.setColor(Color.argb(22,255,255,255));
        gridP.setStyle(Paint.Style.STROKE); gridP.setStrokeWidth(1f);
        wallP   = fill(Color.rgb(68,72,112));
        bdrP    = new Paint(Paint.ANTI_ALIAS_FLAG);
        bdrP.setColor(Color.rgb(100,108,170)); bdrP.setStyle(Paint.Style.STROKE); bdrP.setStrokeWidth(6f);
        remP    = fill(Color.rgb(240,88,88));
        locP    = fill(Color.rgb(80,190,255));
        shP     = fill(Color.argb(65,0,0,0));
        hpBgP   = fill(Color.rgb(38,38,38));
        bulletP = fill(Color.rgb(255,218,0));
        nameP   = fill(Color.WHITE); nameP.setTextSize(21f); nameP.setTextAlign(Paint.Align.CENTER);
        nameP.setShadowLayer(3f,1f,1f,Color.BLACK);
        hudP    = fill(Color.WHITE); hudP.setTextSize(28f);
        hudBgP  = fill(Color.argb(145,0,0,0));
        btnP    = fill(Color.argb(205,195,55,85));
        btnTxtP = fill(Color.WHITE); btnTxtP.setTextSize(22f);
        btnTxtP.setTextAlign(Paint.Align.CENTER); btnTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        deathBgP  = fill(Color.argb(165,0,0,0));
        deathTxtP = fill(Color.rgb(255,55,55)); deathTxtP.setTextSize(58f);
        deathTxtP.setTextAlign(Paint.Align.CENTER);
        gunTxtP = fill(Color.WHITE); gunTxtP.setTextSize(25f); gunTxtP.setTextAlign(Paint.Align.CENTER);
        // IP display paint – large, high contrast
        ipPaint = fill(Color.rgb(255,230,80)); ipPaint.setTextSize(28f);
        ipPaint.setTextAlign(Paint.Align.CENTER); ipPaint.setTypeface(Typeface.DEFAULT_BOLD);
        ipPaint.setShadowLayer(4f,0,2f,Color.BLACK);
        // Settings overlay paints
        settingsBgP   = fill(Color.argb(235,10,15,30));
        settingsTitleP= fill(Color.WHITE); settingsTitleP.setTextSize(26f);
        settingsTitleP.setTextAlign(Paint.Align.LEFT); settingsTitleP.setTypeface(Typeface.DEFAULT_BOLD);
        settingsLabelP= fill(Color.argb(210,200,210,230)); settingsLabelP.setTextSize(20f);
        settingsLabelP.setTextAlign(Paint.Align.LEFT);
        optBtnP   = fill(Color.argb(180,40,50,80));
        optBtnSelP= fill(Color.argb(230,80,130,220));
        optTxtP   = fill(Color.WHITE); optTxtP.setTextSize(17f);
        optTxtP.setTextAlign(Paint.Align.CENTER); optTxtP.setTypeface(Typeface.DEFAULT_BOLD);
        closeBtnP = fill(Color.argb(200,180,50,60));
    }
    private Paint fill(int c){Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(c);p.setStyle(Paint.Style.FILL);return p;}

    /** Finds this device's best local IP — works for regular WiFi AND hotspot AP mode. */
    private static String detectLocalIp() {
        String best = "???.???.???.???";
        try {
            Enumeration<NetworkInterface> ifaces = NetworkInterface.getNetworkInterfaces();
            if (ifaces == null) return best;
            while (ifaces.hasMoreElements()) {
                NetworkInterface ni = ifaces.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress addr = addrs.nextElement();
                    if (addr.isLoopbackAddress() || !(addr instanceof Inet4Address)) continue;
                    String ip = addr.getHostAddress();
                    if (ip == null || ip.isEmpty()) continue;
                    best = ip; // keep last found
                    // Hotspot default range — prefer this immediately
                    if (ip.startsWith("192.168.43.") || ip.startsWith("192.168.1.")
                            || ip.startsWith("10.")) return ip;
                }
            }
        } catch (Exception ignored) {}
        return best;
    }

    // ═══ SURFACE ══════════════════════════════════════════════════════════════
    @Override public void surfaceCreated(SurfaceHolder h)  { /* Wait for surfaceChanged which always provides real dimensions */ }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int hh) { screenW=w; screenH=hh; initControls(); resume(); }
    @Override public void surfaceDestroyed(SurfaceHolder h) { pause(); }

    private void initControls() {
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, 0);
        int  jsSize  = prefs.getInt    ("js_size",  1);   // 0=S 1=M 2=L
        boolean swap = prefs.getBoolean("swap",     false);
        int  btnSize = prefs.getInt    ("btn_size", 1);   // 0=S 1=M 2=L
        int  opacity = prefs.getInt    ("opacity",  1);   // 0=lo 1=med 2=hi

        // Joysticks – use saved base positions if available
        float[] muls = {0.10f, 0.145f, 0.19f};
        float r = Math.min(screenW, screenH) * muls[Math.max(0, Math.min(2, jsSize))];
        float m = r + 18f;
        float lx = swap ? screenW - m : m;
        float rx = swap ? m           : screenW - m;
        float defLy = screenH - m;
        moveStick = new Joystick(
            clamp(prefs.getFloat("js_lx", lx),  r, screenW - r),
            clamp(prefs.getFloat("js_ly", defLy), r, screenH - r), r);
        aimStick  = new Joystick(
            clamp(prefs.getFloat("js_rx", rx),  r, screenW - r),
            clamp(prefs.getFloat("js_ry", defLy), r, screenH - r), r);
        int[] alphas = {90, 160, 225};
        int alpha = alphas[Math.max(0, Math.min(2, opacity))];
        moveStick.setAlpha(alpha);
        aimStick .setAlpha(alpha);

        // Action buttons with saved position + size
        float[] bws = {120f, 160f, 210f};
        float[] bhs = { 46f,  58f,  72f};
        float bw = bws[Math.max(0, Math.min(2, btnSize))];
        float bh = bhs[Math.max(0, Math.min(2, btnSize))];
        float defBx = screenW - bw - 14f;
        float bx = prefs.getFloat("btn_x", defBx);
        float by = prefs.getFloat("btn_y", 14f);
        bx = Math.max(0, Math.min(screenW - bw,     bx));
        by = Math.max(0, Math.min(screenH - bh*2-8, by));
        switchRect = new RectF(bx,     by,        bx+bw, by+bh);
        reloadRect = new RectF(bx,     by+bh+8f,  bx+bw, by+bh*2+8f);
        bombRect   = new RectF(bx,     by+bh*2+16f, bx+bw, by+bh*3+16f);
        dropRect   = new RectF(bx,     by+bh*3+24f, bx+bw, by+bh*4+24f);

        // Skill button — circle, independently movable
        float skillD = bw * 0.88f;  // diameter (roughly matches button width)
        float defSklX = prefs.getFloat("skill_x", bx + (bw - skillD) / 2f);
        float defSklY = prefs.getFloat("skill_y", by + bh * 4 + 32f);
        defSklX = Math.max(0, Math.min(screenW - skillD, defSklX));
        defSklY = Math.max(0, Math.min(screenH - skillD, defSklY));
        skillRect = new RectF(defSklX, defSklY, defSklX + skillD, defSklY + skillD);

        // Gear button
        gearRect = new RectF(12, screenH-72, 72, screenH-12);

        // Confirm-move button (shown only in btnMoveMode)
        confirmMoveRect = new RectF(screenW/2-70, screenH-90, screenW/2+70, screenH-30);

        // Settings panel — 7 option rows + MOVE BUTTONS
        float pw = Math.min(520f, screenW - 48f);
        float ph = 570f;
        float px = (screenW - pw) / 2f;
        float py = (screenH - ph) / 2f;
        settingsPanel     = new RectF(px, py, px+pw, py+ph);
        closeSettingsRect = new RectF(px+pw-54, py+8, px+pw-8, py+52);

        float optX = px + pw * 0.47f;
        float obw=72f, obh=40f, og=7f;
        // 7 rows, 62px apart
        float[] rowY = {py+66f, py+128f, py+190f, py+252f, py+314f, py+376f, py+438f};
        for(int i=0;i<3;i++) jsSizeOpts[i]  = new RectF(optX+i*(obw+og), rowY[0], optX+i*(obw+og)+obw, rowY[0]+obh);
        for(int i=0;i<2;i++) swapOpts[i]    = new RectF(optX+i*(obw+og), rowY[1], optX+i*(obw+og)+obw, rowY[1]+obh);
        for(int i=0;i<3;i++) btnSizeOpts[i] = new RectF(optX+i*(obw+og), rowY[2], optX+i*(obw+og)+obw, rowY[2]+obh);
        for(int i=0;i<3;i++) aimSensOpts[i] = new RectF(optX+i*(obw+og), rowY[3], optX+i*(obw+og)+obw, rowY[3]+obh);
        for(int i=0;i<3;i++) opacityOpts[i] = new RectF(optX+i*(obw+og), rowY[4], optX+i*(obw+og)+obw, rowY[4]+obh);
        for(int i=0;i<2;i++) gunStatOpts[i] = new RectF(optX+i*(obw+og), rowY[5], optX+i*(obw+og)+obw, rowY[5]+obh);
        for(int i=0;i<2;i++) aimLineOpts[i] = new RectF(optX+i*(obw+og), rowY[6], optX+i*(obw+og)+obw, rowY[6]+obh);
        float mbY = py + 492f;
        moveBtnsRect = new RectF(px+20, mbY, px+pw-20, mbY+48f);

        // Shop button — position saved, defaults to right of gear
        float defSbx = 82f, defSby = screenH - 72f;
        float sbx = prefs.getFloat("shop_x", defSbx);
        float sby = prefs.getFloat("shop_y", defSby);
        sbx = Math.max(0, Math.min(screenW - 70f, sbx));
        sby = Math.max(0, Math.min(screenH - 60f, sby));
        shopBtn = new RectF(sbx, sby, sbx + 70f, sby + 60f);

        // Shop panel rects
        float spw = Math.min(580f, screenW - 40f);
        float sph = 670f;   // taller for skill tab
        float spx = (screenW - spw) / 2f;
        float spy = (screenH - sph) / 2f;
        shopCloseRect = new RectF(spx+spw-54, spy+8, spx+spw-8, spy+52);

        // Shop tab buttons
        float tabW = (spw - 24f) / 2f;
        shopTabGuns   = new RectF(spx+12,       spy+58, spx+12+tabW,  spy+98);
        shopTabSkills = new RectF(spx+14+tabW,  spy+58, spx+spw-12,   spy+98);

        // Gun buy rects (shifted down for tab bar)
        float buyW = 90f, buyH = 40f, firstRowY = spy + 110f, rowH = 68f, rowGap = 4f;
        for (int i = 0; i < 7; i++) {
            float ry = firstRowY + i*(rowH+rowGap);
            shopBuyRects[i] = new RectF(spx+spw-buyW-16, ry+14, spx+spw-16, ry+14+buyH);
        }

        // Passive skill buy rects
        float skillBuyW = 86f, skillBuyH = 34f;
        float passiveRowY = spy + 132f, skillRowH = 54f, skillRowGap = 4f;
        for (int i = 0; i < 4; i++) {
            float ry = passiveRowY + i*(skillRowH + skillRowGap);
            passiveBuyRects[i] = new RectF(spx+spw-skillBuyW-16, ry+10, spx+spw-16, ry+10+skillBuyH);
        }
        // Active skill buy rects
        float activeRowY = spy + 392f;
        for (int i = 0; i < 4; i++) {
            float ry = activeRowY + i*(skillRowH + skillRowGap);
            activeBuyRects[i] = new RectF(spx+spw-skillBuyW-16, ry+10, spx+spw-16, ry+10+skillBuyH);
        }
    }

    // ═══ TOUCH ════════════════════════════════════════════════════════════════
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act=e.getActionMasked(), idx=e.getActionIndex(), pid=e.getPointerId(idx);
        float x=e.getX(idx), y=e.getY(idx);

        // Settings overlay absorbs all input when open
        if (settingsOpen) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                if (closeSettingsRect != null && closeSettingsRect.contains(x, y)) {
                    settingsOpen = false; return true;
                }
                handleSettingsTap(x, y);
            }
            return true;
        }

        // Shop overlay absorbs all input when open
        if (shopOpen) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                if (shopCloseRect != null && shopCloseRect.contains(x, y)) {
                    shopOpen = false; return true;
                }
                handleShopTap(x, y);
            }
            return true;
        }

        // Button-move mode: drag switch/reload buttons AND joysticks, tap ✓ to save
        if (btnMoveMode) {
            switch(act) {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_POINTER_DOWN:
                    if (confirmMoveRect != null && confirmMoveRect.contains(x, y)) {
                        // Save position and exit move mode
                        SharedPreferences.Editor ed = getContext().getSharedPreferences(PREFS, 0).edit();
                        if (switchRect != null) { ed.putFloat("btn_x", switchRect.left); ed.putFloat("btn_y", switchRect.top); }
                        if (skillRect  != null) { ed.putFloat("skill_x", skillRect.left); ed.putFloat("skill_y", skillRect.top); }
                        if (moveStick != null)  { ed.putFloat("js_lx", moveStick.getBaseX()); ed.putFloat("js_ly", moveStick.getBaseY()); }
                        if (aimStick  != null)  { ed.putFloat("js_rx", aimStick.getBaseX());  ed.putFloat("js_ry", aimStick.getBaseY());  }
                        if (shopBtn   != null)  { ed.putFloat("shop_x", shopBtn.left);        ed.putFloat("shop_y", shopBtn.top);          }
                        ed.apply();
                        btnMoveMode = false; draggingBtn = -1; break;
                    }
                    if (switchRect != null && switchRect.contains(x, y)) {
                        draggingBtn=0; dragOffX=x-switchRect.left; dragOffY=y-switchRect.top;
                    } else if (reloadRect != null && reloadRect.contains(x, y)) {
                        draggingBtn=1; dragOffX=x-reloadRect.left; dragOffY=y-reloadRect.top;
                    } else if (moveStick != null) {
                        float dx=x-moveStick.getBaseX(), dy=y-moveStick.getBaseY();
                        float rr=moveStick.getRadius()*2f;
                        if(dx*dx+dy*dy<=rr*rr){ draggingBtn=2; dragOffX=dx; dragOffY=dy; }
                    }
                    if (draggingBtn==-1 && aimStick != null) {
                        float dx=x-aimStick.getBaseX(), dy=y-aimStick.getBaseY();
                        float rr=aimStick.getRadius()*2f;
                        if(dx*dx+dy*dy<=rr*rr){ draggingBtn=3; dragOffX=dx; dragOffY=dy; }
                    }
                    if (draggingBtn==-1 && shopBtn != null && shopBtn.contains(x, y)) {
                        draggingBtn=4; dragOffX=x-shopBtn.left; dragOffY=y-shopBtn.top;
                    }
                    if (draggingBtn==-1 && skillRect != null) {
                        float _sdx=x-skillRect.centerX(), _sdy=y-skillRect.centerY();
                        float _sr=skillRect.width()/2f*1.4f;
                        if(_sdx*_sdx+_sdy*_sdy<=_sr*_sr){
                            draggingBtn=5; dragOffX=x-skillRect.left; dragOffY=y-skillRect.top;
                        }
                    }
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (draggingBtn == 0 || draggingBtn == 1) {
                        if (switchRect != null && reloadRect != null) {
                            float bw = switchRect.width(), bh = switchRect.height();
                            float nx = Math.max(0, Math.min(screenW - bw, x - dragOffX));
                            float ny = Math.max(0, Math.min(screenH - bh*2 - 8, y - dragOffY));
                            switchRect.offsetTo(nx, ny);
                            reloadRect.offsetTo(nx, ny + bh + 8f);
                            if (bombRect  != null) bombRect .offsetTo(nx, ny + bh*2 + 16f);
                            if (dropRect  != null) dropRect .offsetTo(nx, ny + bh*3 + 24f);
                            // skillRect stays at its own position (independent)
                        }
                    } else if (draggingBtn == 2 && moveStick != null) {
                        float r2=moveStick.getRadius();
                        moveStick.updateBase(clamp(x-dragOffX,r2,screenW-r2), clamp(y-dragOffY,r2,screenH-r2));
                    } else if (draggingBtn == 3 && aimStick != null) {
                        float r2=aimStick.getRadius();
                        aimStick.updateBase(clamp(x-dragOffX,r2,screenW-r2), clamp(y-dragOffY,r2,screenH-r2));
                    } else if (draggingBtn == 4 && shopBtn != null) {
                        float sw=shopBtn.width(), sh=shopBtn.height();
                        float nx=Math.max(0,Math.min(screenW-sw, x-dragOffX));
                        float ny=Math.max(0,Math.min(screenH-sh, y-dragOffY));
                        shopBtn.offsetTo(nx, ny);
                    } else if (draggingBtn == 5 && skillRect != null) {
                        float sd = skillRect.width();
                        float nx = Math.max(0, Math.min(screenW - sd, x - dragOffX));
                        float ny = Math.max(0, Math.min(screenH - sd, y - dragOffY));
                        skillRect.offsetTo(nx, ny);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_POINTER_UP:
                    draggingBtn = -1; break;
            }
            return true;
        }

        switch(act){
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                if(gearRect!=null&&gearRect.contains(x,y)){settingsOpen=true;break;}
                if(shopBtn!=null&&shopBtn.contains(x,y)){shopOpen=true;break;}
                if(switchRect!=null&&switchRect.contains(x,y)){switchGun();break;}
                if(reloadRect!=null&&reloadRect.contains(x,y)){reload();break;}
                if(bombRect!=null&&bombRect.contains(x,y)){startBombThrow();break;}
                if(dropRect!=null&&dropRect.contains(x,y)){dropWeapon();break;}
                if(skillRect!=null){
                    float _sdx=x-skillRect.centerX(),_sdy=y-skillRect.centerY(),_sr=skillRect.width()/2f;
                    if(_sdx*_sdx+_sdy*_sdy<=_sr*_sr){useActiveSkill();break;}
                }
                if(!moveStick.onTouchDown(pid,x,y)) aimStick.onTouchDown(pid,x,y);
                break;
            case MotionEvent.ACTION_MOVE:
                for(int i=0;i<e.getPointerCount();i++){
                    int p2=e.getPointerId(i);
                    moveStick.onTouchMove(p2,e.getX(i),e.getY(i));
                    aimStick.onTouchMove(p2,e.getX(i),e.getY(i));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                float savedAX = aimStick != null ? aimStick.getX() : 0f;
                float savedAY = aimStick != null ? aimStick.getY() : 0f;
                boolean aimWasActive = aimStick != null && aimStick.isActive();
                moveStick.onTouchUp(pid);
                aimStick.onTouchUp(pid);
                if (throwingBomb && aimWasActive && (aimStick == null || !aimStick.isActive())) {
                    executeThrow(savedAX, savedAY);
                }
                break;
        }
        return true;
    }

    private void handleSettingsTap(float x, float y) {
        SharedPreferences.Editor ed = getContext().getSharedPreferences(PREFS, 0).edit();
        for(int i=0;i<3;i++) if(jsSizeOpts[i]!=null&&jsSizeOpts[i].contains(x,y)){ed.putInt("js_size",i);ed.apply();initControls();return;}
        for(int i=0;i<2;i++) if(swapOpts[i]!=null&&swapOpts[i].contains(x,y)){ed.putBoolean("swap",i==1);ed.apply();initControls();return;}
        for(int i=0;i<3;i++) if(btnSizeOpts[i]!=null&&btnSizeOpts[i].contains(x,y)){ed.putInt("btn_size",i);ed.apply();initControls();return;}
        for(int i=0;i<3;i++) if(aimSensOpts[i]!=null&&aimSensOpts[i].contains(x,y)){ed.putInt("aim_sens",i);ed.apply();return;}
        for(int i=0;i<3;i++) if(opacityOpts[i]!=null&&opacityOpts[i].contains(x,y)){ed.putInt("opacity",i);ed.apply();initControls();return;}
        for(int i=0;i<2;i++) if(gunStatOpts[i]!=null&&gunStatOpts[i].contains(x,y)){ed.putBoolean("gun_stats",i==0);ed.apply();return;}
        for(int i=0;i<2;i++) if(aimLineOpts[i]!=null&&aimLineOpts[i].contains(x,y)){ed.putBoolean("aim_line",i==0);ed.apply();return;}
        if(moveBtnsRect!=null&&moveBtnsRect.contains(x,y)){settingsOpen=false;btnMoveMode=true;return;}
    }

    private void switchGun(){
        if(localPlayer==null||!localPlayer.alive) return;
        Player p=localPlayer;
        int next=(p.gunIndex+1)%p.guns.length;
        for(int tries=0;tries<p.guns.length;tries++){
            if(p.unlockedGuns[next]){ p.gunIndex=next; return; }
            next=(next+1)%p.guns.length;
        }
    }
    private void reload()   {if(localPlayer!=null&&localPlayer.alive) localPlayer.currentGun().startReload();}

    private void dropWeapon() {
        Player lp = localPlayer;
        if (lp == null || !lp.alive) return;
        int unlockedCount = 0;
        for (boolean u : lp.unlockedGuns) if (u) unlockedCount++;
        if (unlockedCount <= 1) return;
        lp.unlockedGuns[lp.gunIndex] = false;
        int next = (lp.gunIndex + 1) % lp.guns.length;
        for (int tries = 0; tries < lp.guns.length; tries++) {
            if (lp.unlockedGuns[next]) { lp.gunIndex = next; return; }
            next = (next + 1) % lp.guns.length;
        }
    }

    private void useActiveSkill() {
        Player lp = localPlayer;
        if (lp == null || !lp.alive) return;
        if (lp.activeSkillType == Player.ACTIVE_NONE) return;
        if (lp.skillOnCooldown()) return;
        long now = System.currentTimeMillis();
        switch (lp.activeSkillType) {
            case Player.ACTIVE_DASH:
                // Dash in the MOVE joystick direction (where you're walking)
                float dashAngle = (moveStick!=null&&moveStick.isActive())
                    ? (float)Math.atan2(moveStick.getY(),moveStick.getX()) : lp.angle;
                float dashDist = 260f;
                // Step along the dash path and stop at the last wall-free position
                float[] dashEnd = dashWithWallStop(lp.x, lp.y, dashAngle, dashDist);
                float nx = dashEnd[0], ny = dashEnd[1];
                // Animate the dash smoothly instead of snapping
                dashAnimStartX = lp.x; dashAnimStartY = lp.y;
                dashAnimEndX   = nx;   dashAnimEndY   = ny;
                dashAnimBegin  = now;  dashAnimating  = true;
                lp.skillCooldownEnd = now + 6000;
                pendingPositionSync = true;
                break;
            case Player.ACTIVE_STEALTH:
                lp.skillActiveUntil = now + 4000;
                lp.skillCooldownEnd = now + 10000;
                break;
            case Player.ACTIVE_HEAL:
                lp.hp = Math.min(100, lp.hp + 40);
                lp.skillCooldownEnd = now + 12000;
                break;
            case Player.ACTIVE_SHIELD:
                lp.shieldHp = 60f;
                lp.skillActiveUntil = now + 6000;
                lp.skillCooldownEnd = now + 14000;
                break;
        }
    }

    /** Enter throw-aiming mode — bomb is actually thrown when aim stick is released. */
    private void startBombThrow() {
        Player lp = localPlayer;
        if (lp == null || !lp.alive || lp.bombs <= 0) return;
        // Only one active bomb allowed at a time
        for (Bomb b : activeBombs) { if (b.ownerId == lp.id && !b.isDone() && b.explodedAt < 0) return; }
        if (throwingBomb) { throwingBomb = false; return; }  // tap again to cancel
        throwingBomb = true;
    }

    /** Called when the aim stick is released while throwingBomb is true. */
    private void executeThrow(float ax, float ay) {
        throwingBomb = false;
        Player lp = localPlayer;
        if (lp == null || !lp.alive || lp.bombs <= 0) return;
        float mag = (float) Math.sqrt(ax * ax + ay * ay);
        if (mag < 0.08f) return;
        for (Bomb b : activeBombs) { if (b.ownerId == lp.id && !b.isDone() && b.explodedAt < 0) return; }
        lp.bombs--;
        float vx = ax * Bomb.THROW_SPEED;
        float vy = ay * Bomb.THROW_SPEED;
        float maxRange = mag * Bomb.THROW_RANGE;
        if (isHost) {
            // Host owns all bombs — create directly
            Bomb bomb = new Bomb(lp.x, lp.y, lp.id);
            bomb.vx = vx; bomb.vy = vy; bomb.maxRange = maxRange;
            activeBombs.add(bomb);
        } else {
            // Client: queue for next sendInput so host creates the authoritative bomb
            pendingBombSend = new float[]{vx, vy, maxRange};
        }
    }

    // ═══ LOOP ═════════════════════════════════════════════════════════════════
    public synchronized void resume(){
        if(gameRunning) return;
        gameRunning=true;
        gameThread=new Thread(this,"GameLoop"); gameThread.start();
    }
    public synchronized void pause(){
        gameRunning=false;
        if(gameThread!=null) try{gameThread.join(700);}catch(InterruptedException ignored){}
        gameThread=null;
    }
    public void stopGame(){ pause(); if(net!=null) net.stop(); }

    @Override public void run(){
        long prev=System.nanoTime();
        while(gameRunning){
            long now=System.nanoTime();
            float dt=Math.min((now-prev)/1e9f,0.08f); prev=now;
            update(dt); render();
            long sleep=16_666_000L-(System.nanoTime()-now);
            if(sleep>0) try{Thread.sleep(sleep/1_000_000,(int)(sleep%1_000_000));}catch(InterruptedException ig){}
        }
    }

    // ═══ UPDATE ═══════════════════════════════════════════════════════════════
    private void update(float dt){
        tick++;
        if(!isHost && pendingState!=null){ applyState(pendingState); pendingState=null; }

        Player lp = localPlayer;  // snapshot reference — safe
        if(lp==null) return;

        if(lp.alive) {
            float rm = lp.reloadMult();
            for(Gun g:lp.guns) g.tick(rm);
        }

        if(isHost&&!lp.alive&&System.currentTimeMillis()-deathTime>=RESPAWN_MS)
            respawn(lp);

        if(lp.alive) moveAndAim(lp, dt);

        // Smooth dash animation — override position while active
        if (dashAnimating) {
            long elapsed = System.currentTimeMillis() - dashAnimBegin;
            float t = Math.min(1f, (float)elapsed / DASH_ANIM_MS);
            // Ease-out cubic: fast start, gentle stop — feels like a real dash
            float ease = 1f - (1f - t) * (1f - t) * (1f - t);
            lp.x = dashAnimStartX + (dashAnimEndX - dashAnimStartX) * ease;
            lp.y = dashAnimStartY + (dashAnimEndY - dashAnimStartY) * ease;
            if (t >= 1f) { lp.x = dashAnimEndX; lp.y = dashAnimEndY; dashAnimating = false; }

            // ── Emit aftereffect ghost at current position ─────────────────
            long nowGhost = System.currentTimeMillis();
            if (nowGhost - lastGhostTimeMs >= 16) {   // ~60fps cap
                dashGhosts.add(new float[]{lp.x, lp.y, nowGhost});
                lastGhostTimeMs = nowGhost;
            }
        }

        // Track player velocity for AI predictive aiming (px / update)
        if (lpPrevX >= 0f) {
            lpVelX = lp.x - lpPrevX;
            lpVelY = lp.y - lpPrevY;
        }
        lpPrevX = lp.x;
        lpPrevY = lp.y;

        updateBullets(lp, dt);
        updateBombs(lp, dt);

        if(isHost){
            applyClientInputs(dt);
            if(!botIds.isEmpty()) updateBots(dt);
            checkRemoteRespawns();
            if(!singlePlayer && System.currentTimeMillis()-lastBroadcast>20){ broadcast(); lastBroadcast=System.currentTimeMillis(); }
        } else {
            if(tick%2==0) sendInput(lp);
        }

        // Smooth per-weapon zoom
        float targetZoom = (lp.alive) ? lp.currentGun().zoom : 1.0f;
        currentZoom += (targetZoom - currentZoom) * 0.07f;

        // Aim pan — shift camera toward aim stick so the player sees further ahead.
        // Vertical pan is stronger so top/bottom aiming reveals more of the map.
        final float PAN_X = 200f;
        final float PAN_Y = 340f;
        float aimPanTargetX = 0f, aimPanTargetY = 0f;
        if (!throwingBomb && aimStick != null && aimStick.isActive()) {
            aimPanTargetX = aimStick.getX() * PAN_X;
            aimPanTargetY = aimStick.getY() * PAN_Y;
        }
        camPanX += (aimPanTargetX - camPanX) * 0.09f;
        camPanY += (aimPanTargetY - camPanY) * 0.09f;

        camX = lp.x + camPanX - screenW / (2f * currentZoom);
        camY = lp.y + camPanY - screenH / (2f * currentZoom);
    }

    private void moveAndAim(Player lp, float dt){
        if(moveStick==null||aimStick==null) return;
        float spd = 280f * lp.moveSpeedMult();
        float nx=lp.x+moveStick.getX()*spd*dt;
        float ny=lp.y+moveStick.getY()*spd*dt;
        nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
        float[] pos=walls(lp.x,lp.y,nx,ny);
        lp.x=pos[0]; lp.y=pos[1];

        float ax=aimStick.getX(), ay=aimStick.getY();
        if(ax*ax+ay*ay>0.01f){
            float targetAngle=(float)Math.atan2(ay,ax);
            // Aim sensitivity: 0=slow(0.10) 1=norm(0.35) 2=fast(1.0)
            int aimSensPref = getContext().getSharedPreferences(PREFS,0).getInt("aim_sens",1);
            float[] sensVals = {0.10f, 0.35f, 1.0f};
            float sens = sensVals[Math.max(0,Math.min(2,aimSensPref))];
            lp.angle = lerpAngle(lp.angle, targetAngle, sens);
        }

        Gun g=lp.currentGun();
        // ── Cheat: infinite ammo — keep every gun topped up, never reload ────
        if (cheatInfiniteAmmo) {
            for (Gun cg : lp.guns) { cg.ammo = cg.maxAmmo; cg.reloading = false; }
        }
        // ── Cheat: no skill cooldown — reset CD every frame ──────────────────
        if (cheatNoSkillCd) { lp.skillCooldownEnd = 0; }
        // Auto-reload when clip is empty
        if(g.ammo<=0 && !g.reloading) g.startReload();

        // Fire with passive fire-rate bonus applied
        float aimMag2 = ax*ax + ay*ay;
        if(!throwingBomb && aimStick.isActive() && aimMag2 > 0.85f*0.85f){
            float frMult = lp.fireRateMult();
            long fireCooldown = (long)(1000f / (g.fireRate * frMult));
            boolean canFire = g.ammo > 0 && !g.reloading
                    && System.currentTimeMillis() - g.lastFireTime >= fireCooldown;
            if(canFire){ spawnBullets(lp); g.markFired(); }
        }
    }

    private float[] walls(float ox,float oy,float nx,float ny){
        for(float[] w:WALLS){
            float cx=clamp(nx,w[0],w[2]), cy=clamp(ny,w[1],w[3]);
            if(d2(nx,ny,cx,cy)<PR*PR){
                float cx2=clamp(nx,w[0],w[2]), cy2=clamp(oy,w[1],w[3]);
                if(d2(nx,oy,cx2,cy2)<PR*PR) nx=ox;
                float cx3=clamp(ox,w[0],w[2]), cy3=clamp(ny,w[1],w[3]);
                if(d2(ox,ny,cx3,cy3)<PR*PR) ny=oy;
            }
        }
        return new float[]{nx,ny};
    }

    /** Shortest-path angle lerp accounting for ±π wrap. */
    private float lerpAngle(float from, float to, float t){
        float d=to-from;
        while(d>(float)Math.PI) d-=(float)(Math.PI*2);
        while(d<-(float)Math.PI) d+=(float)(Math.PI*2);
        return from+d*t;
    }

    private void spawnBullets(Player p){
        Gun g=p.guns[p.gunIndex];
        if(g.ammo<=0) return;
        g.ammo--;
        for(int i=0;i<g.pellets;i++){
            float s=(float)(Math.random()-0.5)*g.spread*2, a=p.angle+s;
            float spd=g.bulletSpeed*(0.96f+(float)Math.random()*0.08f);
            float rangeVal = g.range * p.rangeMult();
            bullets.add(new Bullet(p.x,p.y,(float)Math.cos(a)*spd,(float)Math.sin(a)*spd,p.id,g.damage,bulletId++,rangeVal));
        }
    }

    private void updateBombs(Player lp, float dt) {
        if (!isHost) return;
        long now = System.currentTimeMillis();
        Iterator<Bomb> it = activeBombs.iterator();
        while (it.hasNext()) {
            Bomb b = it.next();
            if (b.isDone()) { it.remove(); continue; }

            // ── Move the bomb while in flight ─────────────────────────────────
            if (!b.hasLanded) {
                float nx = b.x + b.vx * dt;
                float ny = b.y + b.vy * dt;
                boolean outOfRange = b.traveledSq() >= b.maxRange * b.maxRange;
                boolean outOfMap   = nx < 0 || nx > MAP_W || ny < 0 || ny > MAP_H;

                if (outOfRange || outOfMap) {
                    // Clamp to map and land with a roll in current travel direction
                    nx = Math.max(0, Math.min(MAP_W, nx));
                    ny = Math.max(0, Math.min(MAP_H, ny));
                    b.x = nx; b.y = ny;
                    b.rollVx = b.vx * Bomb.LAND_ROLL_FACTOR;
                    b.rollVy = b.vy * Bomb.LAND_ROLL_FACTOR;
                    b.hasLanded = true; b.vx = 0; b.vy = 0;
                } else {
                    // Axis-separated wall bounce so the reflection axis is correct
                    boolean xBlocked = false, yBlocked = false;
                    for (float[] w : WALLS) {
                        if (!xBlocked && nx >= w[0] && nx <= w[2] && b.y >= w[1] && b.y <= w[3]) xBlocked = true;
                        if (!yBlocked && b.x >= w[0] && b.x <= w[2] && ny >= w[1] && ny <= w[3]) yBlocked = true;
                    }
                    if (xBlocked) b.vx = -b.vx * Bomb.BOUNCE_RESTITUTION;
                    if (yBlocked) b.vy = -b.vy * Bomb.BOUNCE_RESTITUTION;
                    if (xBlocked || yBlocked) {
                        // Bounced off a wall — land and give roll velocity in reflected direction
                        b.rollVx = b.vx * Bomb.LAND_ROLL_FACTOR;
                        b.rollVy = b.vy * Bomb.LAND_ROLL_FACTOR;
                        b.hasLanded = true; b.vx = 0; b.vy = 0;
                    } else {
                        b.x = nx; b.y = ny;
                    }
                }
            }

            // ── Roll the bomb along the ground with friction ───────────────────
            if (b.hasLanded && (b.rollVx != 0 || b.rollVy != 0)) {
                float speed = (float) Math.sqrt(b.rollVx * b.rollVx + b.rollVy * b.rollVy);
                float decel = Bomb.ROLL_FRICTION * dt;
                if (decel >= speed) {
                    b.rollVx = 0; b.rollVy = 0;
                } else {
                    float factor = (speed - decel) / speed;
                    b.rollVx *= factor;
                    b.rollVy *= factor;
                    float rnx = b.x + b.rollVx * dt;
                    float rny = b.y + b.rollVy * dt;
                    // Axis-separated wall bounce while rolling (damped)
                    boolean rxBlocked = false, ryBlocked = false;
                    for (float[] w : WALLS) {
                        if (!rxBlocked && rnx >= w[0] && rnx <= w[2] && b.y >= w[1] && b.y <= w[3]) rxBlocked = true;
                        if (!ryBlocked && b.x >= w[0] && b.x <= w[2] && rny >= w[1] && rny <= w[3]) ryBlocked = true;
                    }
                    if (rxBlocked) b.rollVx = -b.rollVx * Bomb.BOUNCE_RESTITUTION;
                    if (ryBlocked) b.rollVy = -b.rollVy * Bomb.BOUNCE_RESTITUTION;
                    // Apply map boundary bounce
                    if (rnx < 0 || rnx > MAP_W) { b.rollVx = -b.rollVx * Bomb.BOUNCE_RESTITUTION; rnx = Math.max(0, Math.min(MAP_W, rnx)); }
                    if (rny < 0 || rny > MAP_H) { b.rollVy = -b.rollVy * Bomb.BOUNCE_RESTITUTION; rny = Math.max(0, Math.min(MAP_H, rny)); }
                    if (!rxBlocked) b.x = rnx;
                    if (!ryBlocked) b.y = rny;
                    // Kill negligible roll after bouncing
                    float newSpeed = (float) Math.sqrt(b.rollVx * b.rollVx + b.rollVy * b.rollVy);
                    if (newSpeed < Bomb.MIN_ROLL_SPEED) { b.rollVx = 0; b.rollVy = 0; }
                }
            }

            // ── Explode when fuse burns out ───────────────────────────────────
            if (b.shouldExplode()) {
                b.explodedAt = now;
                // Damage local player (no friendly fire)
                if (lp.alive && b.ownerId != lp.id
                        && d2(b.x, b.y, lp.x, lp.y) < Bomb.RADIUS * Bomb.RADIUS) {
                    if(!lp.isProtected() && !lp.isStealthed()){
                        float dmg = Bomb.DAMAGE;
                        if(lp.isShielded()){
                            float abs=Math.min(dmg,lp.shieldHp); lp.shieldHp-=abs; dmg-=abs;
                            if(lp.shieldHp<=0) lp.skillActiveUntil=0;
                        }
                        lp.hp = Math.max(0, lp.hp - dmg);
                        if (lp.hp == 0) {
                            lp.alive = false; deathTime = now;
                            addFeed(nameOf(b.ownerId) + " \uD83D\uDCA3 " + lp.name);
                        }
                    }
                }
                // Damage remote players
                for (Player rp : remote.values()) {
                    if (!rp.alive || b.ownerId == rp.id) continue;
                    if (d2(b.x, b.y, rp.x, rp.y) < Bomb.RADIUS * Bomb.RADIUS) {
                        if(!rp.isProtected() && !rp.isStealthed()){
                            float dmg = Bomb.DAMAGE;
                            if(rp.isShielded()){
                                float abs=Math.min(dmg,rp.shieldHp); rp.shieldHp-=abs; dmg-=abs;
                                if(rp.shieldHp<=0) rp.skillActiveUntil=0;
                            }
                            rp.hp = Math.max(0, rp.hp - dmg);
                            if (rp.hp == 0) {
                                rp.alive = false; deadAtMs.put(rp.id, now);
                                addFeed(nameOf(b.ownerId) + " \uD83D\uDCA3 " + rp.name);
                                if (b.ownerId == lp.id) lp.coins += 25;
                                else { Player killer = remote.get(b.ownerId); if (killer != null) killer.coins += 25; }
                            }
                        }
                    }
                }
            }
        }
    }

    private void updateBullets(Player lp, float dt){
        Iterator<Bullet> it=bullets.iterator();
        while(it.hasNext()){
            Bullet b=it.next();
            b.x+=b.dx*dt; b.y+=b.dy*dt;
            boolean rm=false;
            if(b.x<0||b.x>MAP_W||b.y<0||b.y>MAP_H) rm=true;
            if(!rm) for(float[] w:WALLS)
                if(b.x>=w[0]&&b.x<=w[2]&&b.y>=w[1]&&b.y<=w[3]){rm=true;break;}
            // Range-based culling (each gun has a different max range)
            if(!rm){ float rdx=b.x-b.spawnX,rdy=b.y-b.spawnY; if(rdx*rdx+rdy*rdy>b.range*b.range) rm=true; }
            // Safety lifetime cap
            if(!rm&&System.currentTimeMillis()-b.spawnTime>3000) rm=true;
            if(!rm&&isHost){
                if(lp.alive&&b.ownerId!=lp.id&&d2(b.x,b.y,lp.x,lp.y)<PR*PR){
                    rm=true;
                    if(!lp.isProtected() && !lp.isStealthed()){
                        float dmg = b.damage;
                        if(lp.isShielded()){
                            float abs=Math.min(dmg,lp.shieldHp); lp.shieldHp-=abs; dmg-=abs;
                            if(lp.shieldHp<=0) lp.skillActiveUntil=0;
                        }
                        lp.hp=Math.max(0,lp.hp-dmg);
                        if(lp.hp==0){
                            lp.alive=false;deathTime=System.currentTimeMillis();
                            throwingBomb=false;
                            addFeed(nameOf(b.ownerId)+" ➜ "+lp.name);
                            Player killer=remote.get(b.ownerId);
                            if(killer!=null) killer.coins+=25;
                        }
                    }
                }
                if(!rm) for(Player rp:remote.values()){
                    if(b.ownerId==rp.id||!rp.alive) continue;
                    if(d2(b.x,b.y,rp.x,rp.y)<PR*PR){
                        rm=true;
                        if(!rp.isProtected() && !rp.isStealthed()){
                            float dmg = b.damage;
                            if(rp.isShielded()){
                                float abs=Math.min(dmg,rp.shieldHp); rp.shieldHp-=abs; dmg-=abs;
                                if(rp.shieldHp<=0) rp.skillActiveUntil=0;
                            }
                            rp.hp=Math.max(0,rp.hp-dmg);
                            if(rp.hp==0){
                                rp.alive=false;deadAtMs.put(rp.id,System.currentTimeMillis());
                                addFeed(nameOf(b.ownerId)+" ➜ "+rp.name);
                                if(b.ownerId==lp.id) lp.coins+=25;
                                else { Player killer=remote.get(b.ownerId); if(killer!=null) killer.coins+=25; }
                            }
                        }
                        break;
                    }
                }
            }
            if(rm) it.remove();
        }
    }

    private void applyClientInputs(float dt){
        for(Map.Entry<Integer,float[]> e:inputs.entrySet()){
            Player p=remote.get(e.getKey()); if(p==null||!p.alive) continue;
            float[] inp=e.getValue();
            // Sync skill levels from client input
            if(inp.length>13){
                p.skillReload    =Math.max(0,Math.min(3,(int)inp[7]));
                p.skillFireRate  =Math.max(0,Math.min(3,(int)inp[8]));
                p.skillRange     =Math.max(0,Math.min(3,(int)inp[9]));
                p.skillMoveSpeed =Math.max(0,Math.min(3,(int)inp[10]));
                p.activeSkillType=(int)inp[11];
                long secsRem=(long)inp[12]; p.skillActiveUntil= secsRem>0?System.currentTimeMillis()+secsRem*1000L:0;
                p.shieldHp=inp[13];
            }
            // ── Use client's authoritative position if provided ─────────────────
            // inp[14]=px, inp[15]=py (−1 means not provided, fall back to delta)
            float clientX = inp.length>14 ? inp[14] : -1f;
            float clientY = inp.length>15 ? inp[15] : -1f;
            if(clientX >= 0 && clientY >= 0){
                // FIX: lerp toward client position to smooth network jitter.
                // Snap instantly if far away (respawn/teleport), otherwise ease in.
                float tX = clamp(clientX, PR, MAP_W-PR);
                float tY = clamp(clientY, PR, MAP_H-PR);
                float snapDist2 = 120f*120f;
                if ((tX-p.x)*(tX-p.x)+(tY-p.y)*(tY-p.y) > snapDist2) {
                    p.x = tX; p.y = tY; // far away: snap immediately
                } else {
                    p.x += (tX - p.x) * 0.3f; // close: smooth interpolation
                    p.y += (tY - p.y) * 0.3f;
                }
            } else {
                // Fallback: dead-reckon from joystick (should rarely happen)
                float nx=p.x+inp[0]*280f*p.moveSpeedMult()*dt, ny=p.y+inp[1]*280f*p.moveSpeedMult()*dt;
                nx=clamp(nx,PR,MAP_W-PR); ny=clamp(ny,PR,MAP_H-PR);
                float[] pos=walls(p.x,p.y,nx,ny); p.x=pos[0]; p.y=pos[1];
            }
            // Aim angle from joystick
            if(inp[2]*inp[2]+inp[3]*inp[3]>0.01f) p.angle=(float)Math.atan2(inp[3],inp[2]);
            p.gunIndex=Math.max(0,Math.min((int)inp[5], p.guns.length-1));
            if(inp[6]>0.5f) p.guns[p.gunIndex].startReload();
            float rm=p.reloadMult();
            for(Gun g:p.guns) g.tick(rm);
            { Gun g=p.currentGun(); if(g.ammo<=0&&!g.reloading) g.startReload(); }
            if(inp[4]>0.5f){
                Gun g=p.currentGun();
                float frMult=p.fireRateMult();
                long fireCd=(long)(1000f/(g.fireRate*frMult));
                if(g.ammo>0&&!g.reloading&&System.currentTimeMillis()-g.lastFireTime>=fireCd){
                    spawnBullets(p); g.markFired();
                }
            }
        }
    }

    private void checkRemoteRespawns(){
        long now=System.currentTimeMillis();
        for(Player p:remote.values())
            if(!p.alive&&deadAtMs.containsKey(p.id)&&now-deadAtMs.get(p.id)>=RESPAWN_MS){
                respawn(p); deadAtMs.remove(p.id);
            }
    }

    private void respawn(Player p){
        float[] sp=SPAWNS[p.id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true; p.guns=Gun.createAll();
        p.bombs = 2;
        p.spawnProtectionUntil = System.currentTimeMillis() + 3000;
        p.shieldHp = 0; p.skillActiveUntil = 0;  // clear active effects on respawn
        // Keep coins, skill levels, active skill type, and unlocked guns
        if(!p.unlockedGuns[p.gunIndex]) p.gunIndex=0;
    }
    private void spawnLocal(int id, String name){
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.spawnProtectionUntil = System.currentTimeMillis() + 3000;
        localPlayer=p;
    }

    // ══ BOT AI ════════════════════════════════════════════════════════════════

    /** Per-bot persistent AI state. */
    private static class BotState {
        float   lastX, lastY;   // position last frame (for stuck detection)
        int     stuckTicks;     // consecutive ticks with tiny movement
        float   forcedAngle;    // emergency escape direction when truly stuck
        int     forcedTicks;    // ticks remaining on forced escape override
        float   wpX, wpY;       // current navigation waypoint position
        boolean wpActive;       // true while routing through a waypoint
        int     dodgeCooldown;  // ticks until next dodge reaction is allowed
    }
    private final Map<Integer, BotState> botState = new ConcurrentHashMap<>();

    /** Pre-built wall-corner waypoints used for around-wall routing. */
    private float[][] navWaypoints;

    /**
     * Builds waypoints at every wall corner (plus map corners) with a margin so
     * bots always stand outside the wall geometry.  Call once after WALLS is set.
     */
    private void buildNavWaypoints() {
        final float PAD = 52f;
        List<float[]> pts = new ArrayList<>();
        // Map corners
        pts.add(new float[]{PAD, PAD});
        pts.add(new float[]{MAP_W - PAD, PAD});
        pts.add(new float[]{PAD, MAP_H - PAD});
        pts.add(new float[]{MAP_W - PAD, MAP_H - PAD});
        // For every wall: 4 outer corners + 4 edge midpoints
        for (float[] w : WALLS) {
            float mx = (w[0] + w[2]) * 0.5f, my = (w[1] + w[3]) * 0.5f;
            pts.add(new float[]{w[0] - PAD, w[1] - PAD});
            pts.add(new float[]{w[2] + PAD, w[1] - PAD});
            pts.add(new float[]{w[0] - PAD, w[3] + PAD});
            pts.add(new float[]{w[2] + PAD, w[3] + PAD});
            pts.add(new float[]{mx,          w[1] - PAD});
            pts.add(new float[]{mx,          w[3] + PAD});
            pts.add(new float[]{w[0] - PAD,  my});
            pts.add(new float[]{w[2] + PAD,  my});
        }
        // Keep only points that are inside the map and not inside any wall
        List<float[]> valid = new ArrayList<>();
        for (float[] p : pts) {
            if (p[0] < PAD || p[0] > MAP_W - PAD || p[1] < PAD || p[1] > MAP_H - PAD) continue;
            boolean blocked = false;
            for (float[] w : WALLS) {
                if (p[0] > w[0] && p[0] < w[2] && p[1] > w[1] && p[1] < w[3]) { blocked = true; break; }
            }
            if (!blocked) valid.add(p);
        }
        navWaypoints = valid.toArray(new float[0][]);
    }

    /**
     * Finds the cheapest 1-hop waypoint such that: bot→wp has clear LOS AND
     * wp→target has clear LOS.  Returns null if no waypoint is needed / found.
     */
    private float[] findNavWaypoint(float bx, float by, float tx, float ty) {
        float bestCost = Float.MAX_VALUE;
        float[] best   = null;
        if (navWaypoints == null) return null;
        for (float[] wp : navWaypoints) {
            if (!hasLos(bx, by, wp[0], wp[1])) continue;
            if (!hasLos(wp[0], wp[1], tx, ty))  continue;
            float d1x = wp[0] - bx, d1y = wp[1] - by;
            float d2x = tx - wp[0], d2y = ty - wp[1];
            float cost = (float)(Math.sqrt(d1x*d1x + d1y*d1y) + Math.sqrt(d2x*d2x + d2y*d2y));
            if (cost < bestCost) { bestCost = cost; best = wp; }
        }
        return best;
    }

    /** Move bot by (moveX, moveY)*speed*dt with axis-separated wall sliding. */
    private void moveBotWithCollision(Player bot, float moveX, float moveY, float speed, float dt) {
        float nx = clamp(bot.x + moveX * speed * dt, PR, MAP_W - PR);
        float ny = clamp(bot.y + moveY * speed * dt, PR, MAP_H - PR);
        // Test each axis separately so the bot slides along wall faces
        boolean xOk = true, yOk = true;
        for (float[] w : WALLS) {
            if (xOk && nx + PR > w[0] && nx - PR < w[2] && bot.y + PR > w[1] && bot.y - PR < w[3]) xOk = false;
            if (yOk && bot.x + PR > w[0] && bot.x - PR < w[2] && ny + PR > w[1] && ny - PR < w[3]) yOk = false;
        }
        if (xOk) bot.x = nx;
        if (yOk) bot.y = ny;
    }

    private void updateBots(float dt) {
        Player lp = localPlayer; if (lp == null) return;
        // Build waypoints on first call (WALLS is a static initialiser so it's ready)
        if (navWaypoints == null) buildNavWaypoints();

        for (Player bot : remote.values()) {
            if (!botIds.contains(bot.id) || !bot.alive) continue;
            for (Gun g : bot.guns) g.tick();
            if (!lp.alive) continue;

            float dx = lp.x - bot.x, dy = lp.y - bot.y;
            float dist = (float) Math.sqrt(dx * dx + dy * dy);
            if (dist < 1f) continue;

            // ── Per-bot persistent state ───────────────────────────────────────
            BotState bs = botState.get(bot.id);
            if (bs == null) { bs = new BotState(); bs.lastX = bot.x; bs.lastY = bot.y; botState.put(bot.id, bs); }

            float moved = (bot.x - bs.lastX)*(bot.x - bs.lastX) + (bot.y - bs.lastY)*(bot.y - bs.lastY);
            bs.stuckTicks = (moved < 1.5f) ? bs.stuckTicks + 1 : 0;
            bs.lastX = bot.x; bs.lastY = bot.y;

            // Hard-stuck fallback: force a random escape burst
            if (bs.stuckTicks > 45) {
                bs.stuckTicks = 0;
                bs.wpActive   = false;
                bs.forcedAngle = (float)(Math.random() * Math.PI * 2);
                bs.forcedTicks = 55;
            }

            // ── Normal + Hard: use active skill when helpful ──────────────────
            if (difficulty >= 1) {
                doBotUseSkill(bot, lp, dist);
            }

            // ── Normal + Hard: periodic bot shopping ──────────────────────────
            if (difficulty >= 1 && tick % 300 == (bot.id * 37) % 300) {
                doBotShopping(bot);
            }

            // ── Hard mode: dodge incoming player bullets ───────────────────────
            boolean dodging = false;
            float dodgeMoveX = 0f, dodgeMoveY = 0f;
            if (difficulty == 2) {
                // Tick down the cooldown every frame
                if (bs.dodgeCooldown > 0) bs.dodgeCooldown--;

                // Only react to a bullet when cooldown has expired
                if (bs.dodgeCooldown == 0) {
                    for (Bullet bullet : bullets) {
                        if (bullet.ownerId != lp.id) continue;
                        float bdx = bot.x - bullet.x;
                        float bdy = bot.y - bullet.y;
                        float distSq = bdx * bdx + bdy * bdy;
                        if (distSq > 220f * 220f) continue;
                        float bspd = (float) Math.sqrt(bullet.dx * bullet.dx + bullet.dy * bullet.dy);
                        if (bspd < 1f) continue;
                        float bnx = bullet.dx / bspd;
                        float bny = bullet.dy / bspd;
                        float dot = bdx * (-bnx) + bdy * (-bny);
                        if (dot > 0.55f * (float) Math.sqrt(distSq)) {
                            float perpX1 = -bny, perpY1 = bnx;
                            float perpX2 =  bny, perpY2 = -bnx;
                            float dp1 = perpX1 * (bot.x - lp.x) + perpY1 * (bot.y - lp.y);
                            float dp2 = perpX2 * (bot.x - lp.x) + perpY2 * (bot.y - lp.y);
                            if (dp1 >= dp2) { dodgeMoveX = perpX1; dodgeMoveY = perpY1; }
                            else             { dodgeMoveX = perpX2; dodgeMoveY = perpY2; }
                            dodging = true;
                            // ~42 ticks ≈ 0.7 s before the bot can dodge again
                            bs.dodgeCooldown = 42;
                            break;
                        }
                    }
                }
            }

            // ── Determine movement target ──────────────────────────────────────
            // Resolve gun stats up front so movement can use effectiveRange
            Gun g = bot.currentGun();
            if (g.ammo <= 0 && !g.reloading) g.startReload();
            float effectiveRange = g.range * bot.rangeMult();

            float speed = 165f;
            float moveX, moveY;

            if (dodging) {
                // Override movement to dodge the bullet
                moveX = dodgeMoveX; moveY = dodgeMoveY;
            } else if (bs.forcedTicks > 0) {
                bs.forcedTicks--;
                moveX = (float) Math.cos(bs.forcedAngle);
                moveY = (float) Math.sin(bs.forcedAngle);
            } else if (hasLos(bot.x, bot.y, lp.x, lp.y)) {
                float preferredDist = Math.max(160f, effectiveRange * 0.70f);
                float deadband      = 70f;

                if (dist > effectiveRange + 80f) {
                    // Out of range with LOS -- don't sprint across open ground.
                    // Look for a wall-corner that hides us from the player.
                    float bestWpDist = Float.MAX_VALUE;
                    float[] coverWp  = null;
                    if (navWaypoints != null) {
                        for (float[] wp : navWaypoints) {
                            if (!hasLos(bot.x, bot.y, wp[0], wp[1])) continue; // unreachable
                            if ( hasLos(lp.x,  lp.y,  wp[0], wp[1])) continue; // player can see it
                            float wpDist = (float) Math.sqrt((wp[0]-lp.x)*(wp[0]-lp.x)+(wp[1]-lp.y)*(wp[1]-lp.y));
                            if (wpDist < dist && wpDist < bestWpDist) { bestWpDist = wpDist; coverWp = wp; }
                        }
                    }
                    if (coverWp != null) {
                        // Move to that piece of cover
                        bs.wpX = coverWp[0]; bs.wpY = coverWp[1]; bs.wpActive = true;
                        float tdx = bs.wpX - bot.x, tdy = bs.wpY - bot.y;
                        float td  = (float) Math.sqrt(tdx*tdx + tdy*tdy);
                        moveX = (td > 1f) ? tdx/td : 0f;
                        moveY = (td > 1f) ? tdy/td : 0f;
                    } else {
                        // No cover nearby -- zigzag toward player to be harder to hit
                        bs.wpActive = false;
                        float perpX = -dy / dist, perpY = dx / dist;
                        float sign  = ((tick / 28) % 2 == 0) ? 1f : -1f;
                        moveX = dx/dist * 0.75f + perpX * sign * 0.75f;
                        moveY = dy/dist * 0.75f + perpY * sign * 0.75f;
                        float mlen = (float) Math.sqrt(moveX*moveX + moveY*moveY);
                        if (mlen > 0.01f) { moveX /= mlen; moveY /= mlen; }
                    }
                } else if (dist > preferredDist + deadband) {
                    // Within shooting range but not yet at preferred distance
                    bs.wpActive = false;
                    moveX = dx / dist; moveY = dy / dist;
                } else if (dist < preferredDist - deadband && effectiveRange < 520f) {
                    // Too close for a short-range gun -- back off
                    bs.wpActive = false;
                    moveX = -dx / dist; moveY = -dy / dist;
                } else {
                    // At ideal range -- strafe so we're not a standing target
                    bs.wpActive = false;
                    float perpX = -dy / dist, perpY = dx / dist;
                    float sign  = ((tick / 80) % 2 == 0) ? 1f : -1f;
                    moveX = perpX * sign;
                    moveY = perpY * sign;
                }
            } else {
                boolean needNew = !bs.wpActive;
                if (bs.wpActive) {
                    float wdx = bs.wpX - bot.x, wdy = bs.wpY - bot.y;
                    boolean reached    = (wdx*wdx + wdy*wdy) < 70f*70f;
                    boolean wpLosGone  = !hasLos(bot.x, bot.y, bs.wpX, bs.wpY);
                    if (reached || wpLosGone) needNew = true;
                }
                if (needNew) {
                    float[] wp = findNavWaypoint(bot.x, bot.y, lp.x, lp.y);
                    if (wp != null) { bs.wpX = wp[0]; bs.wpY = wp[1]; bs.wpActive = true; }
                    else              bs.wpActive = false;
                }
                float tx = bs.wpActive ? bs.wpX : lp.x;
                float ty = bs.wpActive ? bs.wpY : lp.y;
                float tdx = tx - bot.x, tdy = ty - bot.y;
                float td  = (float) Math.sqrt(tdx*tdx + tdy*tdy);
                moveX = (td > 1f) ? tdx/td : 0f;
                moveY = (td > 1f) ? tdy/td : 0f;
            }

            // Move whenever: not yet at preferred range, strafing, or dodging
            float preferredStop = Math.max(100f, effectiveRange * 0.70f) - 70f;
            if (dist > preferredStop || dodging) moveBotWithCollision(bot, moveX, moveY, speed, dt);

            // ── Aim: difficulty-dependent ──────────────────────────────────────
            if (difficulty == 0) {
                // EASY: aim directly at player, no prediction
                bot.angle = (float) Math.atan2(dy, dx);
            } else {
                // NORMAL / HARD: lead shot (predict where player is walking)
                float velSq = lpVelX * lpVelX + lpVelY * lpVelY;
                if (velSq > 0.25f) {
                    float bulletSpd = bot.currentGun().bulletSpeed;
                    float travelSec = dist / Math.max(bulletSpd, 1f);
                    float predX = clamp(lp.x + lpVelX * 60f * travelSec, 0f, MAP_W);
                    float predY = clamp(lp.y + lpVelY * 60f * travelSec, 0f, MAP_H);
                    float pdx = predX - bot.x, pdy = predY - bot.y;
                    bot.angle = (float) Math.atan2(pdy, pdx);
                } else {
                    bot.angle = (float) Math.atan2(dy, dx);
                }
            }

            // ── Shoot only when player is within this gun's actual range ──────
            if (dist < effectiveRange && hasLos(bot.x, bot.y, lp.x, lp.y)
                    && !lp.isStealthed() && !lp.isProtected()) {
                if (g.canFireNow()) { spawnBullets(bot); g.markFired(); }
            }
        }
    }

    /** Hard mode: bot spends coins on guns then skills. */
    private void doBotShopping(Player bot) {
        // ── Priority 1: buy the best gun this bot can afford ──────────────────
        // Iterate from most-expensive to cheapest
        // Bots prefer guns with long range first: Sniper(2100) > Assault(900) > Burst(720) > SMG(620) > Shotgun(220) > Minigun(420)
        int[] gunPriority = {4, 3, 5, 1, 2, 6};
        for (int i : gunPriority) {
            if (!bot.unlockedGuns[i] && bot.coins >= GUN_PRICES[i]) {
                bot.coins -= GUN_PRICES[i];
                // Drop any previously unlocked non-default gun to stay at 1 extra
                for (int j = 1; j < 7; j++) {
                    if (j != i && bot.unlockedGuns[j]) { bot.unlockedGuns[j] = false; break; }
                }
                bot.unlockedGuns[i] = true;
                bot.gunIndex = i;
                return;
            }
        }
        // ── Priority 2: passive fire rate upgrade ─────────────────────────────
        // (bots already have a starting active skill, so skip buying another)
        // ── Priority 3: upgrade passive fire rate then move speed ──────────────
        if (bot.skillFireRate < 3 && bot.coins >= PASSIVE_SKILL_COSTS[bot.skillFireRate]) {
            bot.coins -= PASSIVE_SKILL_COSTS[bot.skillFireRate];
            bot.skillFireRate++;
            return;
        }
        if (bot.skillMoveSpeed < 3 && bot.coins >= PASSIVE_SKILL_COSTS[bot.skillMoveSpeed]) {
            bot.coins -= PASSIVE_SKILL_COSTS[bot.skillMoveSpeed];
            bot.skillMoveSpeed++;
        }
    }

    /** Bot activates its skill when conditions are right. */
    private void doBotUseSkill(Player bot, Player lp, float dist) {
        if (bot.activeSkillType == Player.ACTIVE_NONE) return;
        if (bot.skillOnCooldown()) return;
        long now = System.currentTimeMillis();
        Gun bg = bot.currentGun();
        float botRange = bg.range * bot.rangeMult();
        switch (bot.activeSkillType) {
            case Player.ACTIVE_HEAL:
                // Heal at 60 HP (not 45) so it's proactive, not last-resort
                if (bot.hp < 60) {
                    bot.hp = Math.min(100, bot.hp + 40);
                    bot.skillCooldownEnd = now + 12000;
                }
                break;
            case Player.ACTIVE_SHIELD:
                // Pop shield whenever health is moderate or player is in range
                if (bot.hp < 80 && !bot.isShielded()) {
                    bot.shieldHp = 60f;
                    bot.skillActiveUntil = now + 6000;
                    bot.skillCooldownEnd = now + 14000;
                }
                break;
            case Player.ACTIVE_STEALTH:
                // Go stealth whenever player has LOS on the bot
                if (hasLos(bot.x, bot.y, lp.x, lp.y)) {
                    bot.skillActiveUntil = now + 4000;
                    bot.skillCooldownEnd = now + 10000;
                }
                break;
            case Player.ACTIVE_DASH:
                float dashAngleBot = Float.NaN;
                if (bot.hp < 35) {
                    // Critically low HP -- dash away from player
                    dashAngleBot = (float) Math.atan2(bot.y - lp.y, bot.x - lp.x);
                } else if (dist > botRange * 1.6f && dist < botRange * 4f) {
                    // Out of range -- dash toward player to close the gap
                    dashAngleBot = (float) Math.atan2(lp.y - bot.y, lp.x - bot.x);
                }
                if (!Float.isNaN(dashAngleBot)) {
                    // Step along path — stop at walls (same logic as player)
                    float[] botDashEnd = dashWithWallStop(bot.x, bot.y, dashAngleBot, 280f);
                    // Spawn afterimage ghosts evenly along the path
                    long ghostNow = System.currentTimeMillis();
                    float ghostDx = botDashEnd[0] - bot.x, ghostDy = botDashEnd[1] - bot.y;
                    float ghostLen = (float)Math.sqrt(ghostDx*ghostDx + ghostDy*ghostDy);
                    int numGhosts = Math.max(2, (int)(ghostLen / 32f));
                    for (int gi = 0; gi <= numGhosts; gi++) {
                        float t2 = (float)gi / numGhosts;
                        botDashGhosts.add(new float[]{
                            bot.x + ghostDx * t2,
                            bot.y + ghostDy * t2,
                            ghostNow - (long)(t2 * 60f)   // stagger spawn times slightly
                        });
                    }
                    bot.x = botDashEnd[0];
                    bot.y = botDashEnd[1];
                    bot.skillCooldownEnd = now + 6000;
                }
                break;
        }
    }

    /**
     * Steps along a dash from (startX,startY) in the given angle and returns the
     * last valid position before hitting a wall or the map boundary.
     * Uses the player radius (PR) so the circle never overlaps a wall.
     */
    private float[] dashWithWallStop(float startX, float startY, float angle, float maxDist) {
        // FIX: if player already clips a wall, nudge start clear so dash doesn't dead-stop
        for (float[] w : WALLS) {
            float csx = clamp(startX, w[0], w[2]);
            float csy = clamp(startY, w[1], w[3]);
            float dx = startX - csx, dy = startY - csy;
            if (dx*dx + dy*dy < (float)(PR*PR)) {
                startX = clamp(startX + (float)Math.cos(angle) * PR, PR, MAP_W - PR);
                startY = clamp(startY + (float)Math.sin(angle) * PR, PR, MAP_H - PR);
                break;
            }
        }
        final float STEP = 6f; // smaller step so thin walls (35px) are never tunnelled
        int steps = Math.max(1, (int)(maxDist / STEP));
        float lastX = startX, lastY = startY;
        for (int i = 1; i <= steps; i++) {
            float testX = startX + (float)Math.cos(angle) * STEP * i;
            float testY = startY + (float)Math.sin(angle) * STEP * i;
            testX = clamp(testX, PR, MAP_W - PR);
            testY = clamp(testY, PR, MAP_H - PR);
            // FIX: correct circle-vs-AABB check (same method as walls() movement function)
            boolean hit = false;
            for (float[] w : WALLS) {
                float cx = clamp(testX, w[0], w[2]);
                float cy = clamp(testY, w[1], w[3]);
                float ddx = testX - cx, ddy = testY - cy;
                if (ddx*ddx + ddy*ddy < (float)(PR*PR)) { hit = true; break; }
            }
            if (hit) break;
            lastX = testX; lastY = testY;
        }
        return new float[]{lastX, lastY};
    }

    /**
     * Checks line-of-sight by stepping along the segment in 25px increments.
     * Returns true if no wall blocks the path.
     */
    private boolean hasLos(float x1,float y1,float x2,float y2){
        float ddx=x2-x1, ddy=y2-y1;
        float dist=(float)Math.sqrt(ddx*ddx+ddy*ddy);
        int steps=Math.max(1,(int)(dist/25));
        float sx=ddx/steps, sy=ddy/steps;
        for(int i=1;i<steps;i++){
            float px=x1+sx*i, py=y1+sy*i;
            for(float[] w:WALLS)
                if(px>=w[0]&&px<=w[2]&&py>=w[1]&&py<=w[3]) return false;
        }
        return true;
    }

    /** Returns true if (x,y) is inside any wall (with player-radius margin). */
    private boolean inWall(float x,float y){
        for(float[] w:WALLS) if(x>=w[0]-PR&&x<=w[2]+PR&&y>=w[1]-PR&&y<=w[3]+PR) return true;
        return false;
    }

    // ═══ RENDER ═══════════════════════════════════════════════════════════════
    private void render(){
        Canvas c=getHolder().lockCanvas(); if(c==null) return;
        try{ doDraw(c); }finally{ getHolder().unlockCanvasAndPost(c); }
    }

    private void doDraw(Canvas c){
        c.drawRect(0,0,c.getWidth(),c.getHeight(),bgP);
        c.save();
        c.scale(currentZoom, currentZoom);   // per-weapon camera zoom
        c.translate(-camX,-camY);

        for(float x=0;x<=MAP_W;x+=120) c.drawLine(x,0,x,MAP_H,gridP);
        for(float y=0;y<=MAP_H;y+=120) c.drawLine(0,y,MAP_W,y,gridP);
        c.drawRect(0,0,MAP_W,MAP_H,bdrP);

        for(float[] w:WALLS) c.drawRect(w[0],w[1],w[2],w[3],wallP);
        for(Bullet b:bullets) c.drawCircle(b.x,b.y,5f,bulletP);

        // ── Dash aftereffect ghosts (drawn below the player) ──────────────────
        long nowGhostDraw = System.currentTimeMillis();
        {
            Iterator<float[]> git = dashGhosts.iterator();
            while (git.hasNext()) {
                float[] ghost = git.next();
                long age = nowGhostDraw - (long) ghost[2];
                if (age < 0 || age > GHOST_LIFE_MS) { git.remove(); continue; }
                float frac  = (float) age / GHOST_LIFE_MS;
                float alpha = 1f - frac;              // 1 → 0 as ghost ages
                float scale = 1f - frac * 0.35f;     // shrinks slightly

                // Inner glow fill
                Paint gFill = new Paint(Paint.ANTI_ALIAS_FLAG);
                gFill.setStyle(Paint.Style.FILL);
                gFill.setColor(Color.argb((int)(100 * alpha), 80, 200, 255));
                c.drawCircle(ghost[0], ghost[1], PR * scale, gFill);

                // Bright cyan ring
                Paint gRing = new Paint(Paint.ANTI_ALIAS_FLAG);
                gRing.setStyle(Paint.Style.STROKE);
                gRing.setStrokeWidth(3.5f * alpha);
                gRing.setColor(Color.argb((int)(230 * alpha), 140, 230, 255));
                c.drawCircle(ghost[0], ghost[1], PR * scale, gRing);

                // Speed-streak line from ghost toward dash end point (first ghost only)
                if (frac < 0.15f && dashGhosts.size() > 1) {
                    Paint streak = new Paint(Paint.ANTI_ALIAS_FLAG);
                    streak.setStyle(Paint.Style.STROKE);
                    streak.setStrokeWidth(2f * alpha);
                    streak.setColor(Color.argb((int)(160 * alpha), 100, 210, 255));
                    streak.setPathEffect(new android.graphics.DashPathEffect(new float[]{10f, 6f}, 0f));
                    c.drawLine(ghost[0], ghost[1], dashAnimEndX, dashAnimEndY, streak);
                }
            }
        }
        // ── Bot dash afterimage ghosts (orange/red, drawn below bots) ──────────
        {
            long nowBotGhost = System.currentTimeMillis();
            Iterator<float[]> bgit = botDashGhosts.iterator();
            while (bgit.hasNext()) {
                float[] ghost = bgit.next();
                long age = nowBotGhost - (long) ghost[2];
                if (age < 0 || age > GHOST_LIFE_MS) { bgit.remove(); continue; }
                float frac  = (float) age / GHOST_LIFE_MS;
                float alpha = 1f - frac;
                float scale = 1f - frac * 0.35f;

                // Inner orange glow
                Paint bgFill = new Paint(Paint.ANTI_ALIAS_FLAG);
                bgFill.setStyle(Paint.Style.FILL);
                bgFill.setColor(Color.argb((int)(110 * alpha), 255, 120, 30));
                c.drawCircle(ghost[0], ghost[1], PR * scale, bgFill);

                // Bright orange-red ring
                Paint bgRing = new Paint(Paint.ANTI_ALIAS_FLAG);
                bgRing.setStyle(Paint.Style.STROKE);
                bgRing.setStrokeWidth(3.5f * alpha);
                bgRing.setColor(Color.argb((int)(230 * alpha), 255, 80, 0));
                c.drawCircle(ghost[0], ghost[1], PR * scale, bgRing);
            }
        }
        for(Player p:remote.values()) drawPlayer(c,p,false);
        Player lp=localPlayer;
        if(lp!=null) drawPlayer(c,lp,true);

        // Aim line (world-space dashed line)
        if(lp!=null && lp.alive && getContext().getSharedPreferences(PREFS,0).getBoolean("aim_line",false)){
            float lineLen = 350f;
            float ex = lp.x + (float)Math.cos(lp.angle) * lineLen;
            float ey = lp.y + (float)Math.sin(lp.angle) * lineLen;
            Paint aimLineP = new Paint(Paint.ANTI_ALIAS_FLAG);
            aimLineP.setColor(Color.argb(160,255,255,255));
            aimLineP.setStyle(Paint.Style.STROKE);
            aimLineP.setStrokeWidth(2.5f);
            aimLineP.setPathEffect(new android.graphics.DashPathEffect(new float[]{18f,10f},0f));
            c.drawLine(lp.x,lp.y,ex,ey,aimLineP);
        }

        // Draw active bombs (world space)
        long nowDraw = System.currentTimeMillis();
        for (Bomb bomb : activeBombs) {
            if (bomb.isFlashing()) {
                // (explosion circle removed)
            } else if (bomb.explodedAt < 0) {
                float fuse = (nowDraw - bomb.deployTime) / (float) Bomb.FUSE_MS;
                if (!bomb.hasLanded) {
                    // ── Flying: draw a shadow + emoji to indicate arc ─────────
                    // Shadow grows as bomb approaches max range (shows distance)
                    float travel = (float)Math.sqrt(bomb.traveledSq()) / Bomb.THROW_RANGE;
                    float shadowR = 8f + 22f * travel;
                    Paint shadowP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    shadowP.setStyle(Paint.Style.FILL);
                    shadowP.setColor(Color.argb((int)(120 * (1f - travel * 0.5f)), 0, 0, 0));
                    c.drawCircle(bomb.x, bomb.y, shadowR, shadowP);
                    // Emoji slightly offset upward to simulate height
                    Paint flyP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    flyP.setTextSize(34f); flyP.setTextAlign(Paint.Align.CENTER);
                    float bounce = -(float)Math.sin(travel * Math.PI) * 40f;
                    c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + bounce + 12f, flyP);
                } else {
                    // ── Landed: emoji only (danger ring removed) ────────────────────
                    Paint bombEmojiP = new Paint(Paint.ANTI_ALIAS_FLAG);
                    bombEmojiP.setTextSize(32f); bombEmojiP.setTextAlign(Paint.Align.CENTER);
                    c.drawText("\uD83D\uDCA3", bomb.x, bomb.y + 12f, bombEmojiP);
                }
            }
        }

        // ── Throw preview arc (world space) ──────────────────────────────────
        if (throwingBomb && lp != null && lp.alive && aimStick != null) {
            float tax = aimStick.getX(), tay = aimStick.getY();
            float tmag = (float) Math.sqrt(tax * tax + tay * tay);
            if (tmag > 0.08f) {
                float landX = lp.x + tax * Bomb.THROW_RANGE;
                float landY = lp.y + tay * Bomb.THROW_RANGE;
                // Dashed trajectory line
                Paint arcP = new Paint(Paint.ANTI_ALIAS_FLAG);
                arcP.setColor(Color.argb(210, 255, 210, 0));
                arcP.setStyle(Paint.Style.STROKE);
                arcP.setStrokeWidth(3.5f);
                arcP.setPathEffect(new android.graphics.DashPathEffect(new float[]{16f, 10f}, 0f));
                c.drawLine(lp.x, lp.y, landX, landY, arcP);
                // (blast radius preview circles removed)
                // Landing bullseye
                Paint dotP = new Paint(Paint.ANTI_ALIAS_FLAG);
                dotP.setColor(Color.argb(230, 255, 220, 0));
                dotP.setStyle(Paint.Style.FILL);
                c.drawCircle(landX, landY, 10f, dotP);
            }
        }

        c.restore();

        drawHUD(c);
    }

    private void drawPlayer(Canvas c, Player p, boolean local){
        if(!p.alive){
            Paint xp=new Paint(Paint.ANTI_ALIAS_FLAG);
            xp.setColor(Color.argb(160,230,50,50)); xp.setStyle(Paint.Style.STROKE); xp.setStrokeWidth(4f);
            c.drawLine(p.x-13,p.y-13,p.x+13,p.y+13,xp);
            c.drawLine(p.x+13,p.y-13,p.x-13,p.y+13,xp); return;
        }
        // Stealth: remote players are invisible (skip draw); local is translucent
        if (!local && p.isStealthed()) return;
        int stealthAlpha = (local && p.isStealthed()) ? 100 : 255;
        float r=PR;
        Paint shadowP2 = new Paint(shP); shadowP2.setAlpha(stealthAlpha*65/255);
        c.drawCircle(p.x+4,p.y+4,r,shadowP2);
        Paint bodyP = local ? new Paint(locP) : new Paint(remP);
        bodyP.setAlpha(stealthAlpha);
        c.drawCircle(p.x,p.y,r,bodyP);
        float gl=r+20f;
        Paint gp=new Paint(Paint.ANTI_ALIAS_FLAG);
        int barrelCol = local ? p.currentGun().color : Color.rgb(255,135,135);
        gp.setColor(barrelCol); gp.setAlpha(stealthAlpha);
        gp.setStyle(Paint.Style.STROKE); gp.setStrokeWidth(7f); gp.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(p.x,p.y,p.x+(float)Math.cos(p.angle)*gl,p.y+(float)Math.sin(p.angle)*gl,gp);
        float bw=50f,bh=6f,bx=p.x-25f,by=p.y-r-14f;
        c.drawRoundRect(bx,by,bx+bw,by+bh,3,3,hpBgP);
        float fr=Math.max(0,p.hp/100f);
        Paint hpP=new Paint(Paint.ANTI_ALIAS_FLAG); hpP.setStyle(Paint.Style.FILL);
        hpP.setColor(fr>0.5f?Color.rgb(50,220,50):fr>0.25f?Color.rgb(240,175,0):Color.rgb(230,50,50));
        c.drawRoundRect(bx,by,bx+bw*fr,by+bh,3,3,hpP);
        Paint nameP2 = new Paint(nameP); nameP2.setAlpha(stealthAlpha);
        c.drawText(p.name,p.x,p.y-r-17f,nameP2);
        // Spawn protection ring
        if (p.isProtected()) {
            long rem = p.spawnProtectionUntil - System.currentTimeMillis();
            float pulse = 0.7f+0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
            Paint protP = new Paint(Paint.ANTI_ALIAS_FLAG);
            protP.setStyle(Paint.Style.STROKE); protP.setStrokeWidth(4f*pulse);
            protP.setColor(Color.argb(Math.min(255,(int)(200*rem/800f)),100,200,255));
            c.drawCircle(p.x,p.y,(r+10)*pulse,protP);
        }
        // Shield ring
        if (p.isShielded()) {
            float pulse2 = 0.8f+0.2f*(float)Math.abs(Math.sin(System.currentTimeMillis()/150.0));
            Paint shP2 = new Paint(Paint.ANTI_ALIAS_FLAG);
            shP2.setStyle(Paint.Style.STROKE); shP2.setStrokeWidth(5f);
            shP2.setColor(Color.argb(200,255,200,0));
            c.drawCircle(p.x,p.y,(r+14)*pulse2,shP2);
        }

    }

    private void drawHUD(Canvas c){
        Player lp=localPlayer;
        // Show connecting screen while waiting for server response (client only)
        if(lp==null){
            if(!isHost){
                float w=screenW, h=screenH;
                c.drawRect(0,0,w,h,fill(Color.argb(180,0,0,0)));
                Paint tp=fill(Color.WHITE); tp.setTextSize(32f); tp.setTextAlign(Paint.Align.CENTER);
                tp.setTypeface(Typeface.DEFAULT_BOLD); tp.setShadowLayer(4f,0,2f,Color.BLACK);
                c.drawText("Connecting to host…", w/2, h/2-20, tp);
                Paint tp2=fill(Color.argb(200,180,210,255)); tp2.setTextSize(18f); tp2.setTextAlign(Paint.Align.CENTER);
                c.drawText("Make sure you're on the host's hotspot", w/2, h/2+24, tp2);
            }
            return;
        }
        float w=screenW, h=screenH;

        // ── HP ────────────────────────────────────────────────────────────────
        c.drawRoundRect(10,10,215,56,8,8,hudBgP);
        hudP.setColor(Color.rgb(255,75,75)); hudP.setTextSize(27f); hudP.setTextAlign(Paint.Align.LEFT);
        c.drawText("♥ "+(int)Math.ceil(lp.hp), 22, 46, hudP);

        // ── Coins ─────────────────────────────────────────────────────────────
        c.drawRoundRect(222,10,355,56,8,8,hudBgP);
        Paint coinP2=fill(Color.rgb(255,210,50)); coinP2.setTextSize(22f);
        coinP2.setTextAlign(Paint.Align.LEFT); coinP2.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("\uD83D\uDCB0 "+lp.coins, 234, 44, coinP2);

        // ── Difficulty badge ───────────────────────────────────────────────────
        if (singlePlayer) {
            String[] diffLabels = {"EASY", "NORMAL", "HARD"};
            int[]    diffColors = {0xFF2ecc71, 0xFFe94560, 0xFF8855ee};
            String dlbl = diffLabels[Math.max(0, Math.min(2, difficulty))];
            int    dcol = diffColors[Math.max(0, Math.min(2, difficulty))];
            Paint diffP = fill(dcol); diffP.setTextSize(17f);
            diffP.setTextAlign(Paint.Align.LEFT); diffP.setTypeface(Typeface.DEFAULT_BOLD);
            diffP.setShadowLayer(3f,1f,1f,Color.BLACK);
            float dlblW = diffP.measureText(dlbl);
            c.drawRoundRect(362, 14, 362 + dlblW + 18, 52, 8, 8, fill(Color.argb(140,0,0,0)));
            c.drawText(dlbl, 371, 43, diffP);
        }

        // ── Gun + ammo ────────────────────────────────────────────────────────
        if(lp.alive){
            Gun g=lp.currentGun();
            String ammoStr = g.reloading ? "RELOADING…" : (g.ammo+"/"+g.maxAmmo);
            // Background panel – taller to fit stat bars when shown
            boolean showGunStats = getContext().getSharedPreferences(PREFS,0).getBoolean("gun_stats",true);
            c.drawRoundRect(w/2-195,6,w/2+195,showGunStats?106:52,10,10,hudBgP);
            // Gun name + ammo
            gunTxtP.setColor(g.color);
            c.drawText(g.name+"   "+ammoStr, w/2, 36, gunTxtP);
            // Stat bars: DMG | SPD | RANGE | RATE
            if(showGunStats){
            String[] statNames = {"DMG","SPD","RANGE","RATE"};
            float[]  statVals  = {g.statDamage(), g.statSpeed(), g.statRange(), g.statFireRate()};
            int[]    statColors= {0xFFFF5252, 0xFF64B5F6, 0xFF81C784, 0xFFFFD54F};
            float barW=68f, barH=9f, gap=10f;
            float totalW = statNames.length*(barW+gap)-gap;
            float barX = w/2 - totalW/2;
            float barY = 55f;
            Paint statLblP = new Paint(Paint.ANTI_ALIAS_FLAG);
            statLblP.setTextSize(13f); statLblP.setTextAlign(Paint.Align.LEFT);
            statLblP.setColor(Color.argb(180,200,220,255));
            Paint statBgP  = fill(Color.argb(80,255,255,255));
            for(int si=0;si<statNames.length;si++){
                float sx = barX + si*(barW+gap);
                c.drawRoundRect(sx,barY, sx+barW,barY+barH, 4,4, statBgP);
                Paint fp=fill(statColors[si]);
                c.drawRoundRect(sx,barY, sx+barW*statVals[si],barY+barH, 4,4, fp);
                c.drawText(statNames[si], sx, barY+barH+14f, statLblP);
            }
            }
        }

        // ── HOST: show IP so others can join ──────────────────────────────────
        if(isHost && !hostIpDisplay.isEmpty()){
            int count=remote.size()+1;
            String ipLine="Your IP: "+hostIpDisplay+"   Players: "+count;
            float bgW=ipPaint.measureText(ipLine)+24f;
            c.drawRoundRect(w/2-bgW/2,h-52,w/2+bgW/2,h-4,10,10,hudBgP);
            c.drawText(ipLine, w/2, h-14, ipPaint);
        }

        // ── Kill feed ─────────────────────────────────────────────────────────
        hudP.setColor(Color.rgb(255,210,70)); hudP.setTextSize(18f); hudP.setTextAlign(Paint.Align.LEFT);
        synchronized(feed){ for(int i=0;i<feed.size();i++) c.drawText(feed.get(i),12,72+i*24,hudP); }

        // ── Death overlay ─────────────────────────────────────────────────────
        if(!lp.alive){
            c.drawRect(0,0,w,h,deathBgP);
            c.drawText("YOU DIED",w/2,h/2-18,deathTxtP);
            long rem=RESPAWN_MS-(System.currentTimeMillis()-deathTime);
            if(rem>0){
                Paint t2=new Paint(deathTxtP); t2.setTextSize(28f); t2.setColor(Color.WHITE);
                t2.setTextAlign(Paint.Align.CENTER);
                c.drawText("Respawning in "+(rem/1000+1)+"s",w/2,h/2+38,t2);
            }
        }

        // ── Buttons ───────────────────────────────────────────────────────────
        c.drawRoundRect(switchRect,10,10,btnP);
        c.drawText("SWITCH GUN",switchRect.centerX(),switchRect.centerY()+8,btnTxtP);
        c.drawRoundRect(reloadRect,10,10,btnP);
        c.drawText("RELOAD",reloadRect.centerX(),reloadRect.centerY()+8,btnTxtP);
        // Bomb button
        if (bombRect != null && lp != null) {
            boolean hasBombs = lp.bombs > 0;
            Paint bombBtnP;
            String bombLabel;
            if (throwingBomb) {
                bombBtnP = fill(Color.argb(230, 220, 160, 0));  // glowing amber = aiming
                bombLabel = "CANCEL";
            } else {
                bombBtnP = fill(hasBombs ? Color.argb(210,160,60,0) : Color.argb(120,60,60,60));
                bombLabel = "\uD83D\uDCA3 " + lp.bombs;
            }
            c.drawRoundRect(bombRect, 10, 10, bombBtnP);
            c.drawText(bombLabel, bombRect.centerX(), bombRect.centerY() + 8, btnTxtP);
            // "AIM & RELEASE" hint while in throw mode
            if (throwingBomb) {
                Paint hintP = fill(Color.argb(200, 255, 230, 100));
                hintP.setTextSize(16f); hintP.setTextAlign(Paint.Align.CENTER);
                hintP.setShadowLayer(3f, 0, 1f, Color.BLACK);
                c.drawText("aim joystick \u2192 release", bombRect.centerX(), bombRect.top - 8f, hintP);
            }
        }
        // Drop weapon button
        if (dropRect != null && lp != null) {
            int unlockedCount = 0;
            for (boolean u : lp.unlockedGuns) if (u) unlockedCount++;
            boolean canDrop = unlockedCount > 1;
            Paint dropBtnP = fill(canDrop ? Color.argb(200,140,40,40) : Color.argb(80,60,60,60));
            c.drawRoundRect(dropRect, 10, 10, dropBtnP);
            c.drawText("DROP GUN", dropRect.centerX(), dropRect.centerY() + 8, btnTxtP);
        }

        // Active skill button
        if (skillRect != null && lp != null) {
            drawSkillButton(c, lp);
        }

        // Spawn protection pulsing shield ring (screen-space around player circle)
        if (lp != null && lp.alive && lp.isProtected()) {
            long rem = lp.spawnProtectionUntil - System.currentTimeMillis();
            float pulse = 0.7f + 0.3f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
            float alpha = Math.min(1f, rem/800f);
            // Draw in screen centre (player is always at centre of screen)
            float cx2 = screenW/2f, cy2 = screenH/2f;
            Paint protP = new Paint(Paint.ANTI_ALIAS_FLAG);
            protP.setStyle(Paint.Style.STROKE); protP.setStrokeWidth(5f*pulse);
            protP.setColor(Color.argb((int)(200*alpha),100,200,255));
            c.drawCircle(cx2, cy2, (PR*currentZoom+18)*pulse, protP);
            // Timer text
            Paint protTxt = fill(Color.argb((int)(230*alpha),120,220,255));
            protTxt.setTextSize(16f); protTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("🛡 "+(rem/1000+1)+"s", cx2, cy2-(PR*currentZoom+32), protTxt);
        }

        // ── Gear button ───────────────────────────────────────────────────────
        if(gearRect!=null){
            Paint gearBg=fill(Color.argb(settingsOpen?210:140,40,50,80));
            c.drawRoundRect(gearRect,10,10,gearBg);
            Paint gearTxt=new Paint(Paint.ANTI_ALIAS_FLAG);
            gearTxt.setColor(Color.WHITE); gearTxt.setTextSize(26f);
            gearTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("⚙",gearRect.centerX(),gearRect.centerY()+10,gearTxt);
        }

        // ── Shop button ───────────────────────────────────────────────────────
        if(shopBtn!=null){
            Paint sbP=fill(Color.argb(shopOpen?210:150,160,120,10));
            c.drawRoundRect(shopBtn,10,10,sbP);
            Paint sTxt=new Paint(Paint.ANTI_ALIAS_FLAG);
            sTxt.setColor(Color.WHITE); sTxt.setTextSize(22f); sTxt.setTextAlign(Paint.Align.CENTER);
            c.drawText("\uD83D\uDED2",shopBtn.centerX(),shopBtn.centerY()+9,sTxt);
        }

        // ── Joysticks ─────────────────────────────────────────────────────────
        if(moveStick!=null) moveStick.draw(c);
        if(aimStick!=null)  aimStick.draw(c);

        // ── Button-move mode overlay ───────────────────────────────────────────
        if(btnMoveMode){
            Paint dimP = fill(Color.argb(120,0,0,0));
            c.drawRect(0,0,w,h,dimP);
            // Redraw buttons with highlight
            Paint hlP = fill(Color.argb(220,80,160,255));
            if(switchRect!=null){ c.drawRoundRect(switchRect,10,10,hlP); c.drawText("SWITCH GUN",switchRect.centerX(),switchRect.centerY()+8,btnTxtP); }
            if(reloadRect!=null){ c.drawRoundRect(reloadRect,10,10,hlP); c.drawText("RELOAD",reloadRect.centerX(),reloadRect.centerY()+8,btnTxtP); }
            if(bombRect!=null)  { c.drawRoundRect(bombRect,10,10,hlP);   c.drawText("\uD83D\uDCA3",bombRect.centerX(),bombRect.centerY()+8,btnTxtP); }
            if(dropRect!=null)  { c.drawRoundRect(dropRect,10,10,hlP);   c.drawText("DROP GUN",dropRect.centerX(),dropRect.centerY()+8,btnTxtP); }
            if(skillRect!=null) {
                float _scx=skillRect.centerX(),_scy=skillRect.centerY(),_sr=skillRect.width()/2f;
                c.drawCircle(_scx, _scy, _sr, hlP);
                Paint _st = new Paint(btnTxtP); _st.setTextSize(_sr*0.38f);
                c.drawText("SKILL", _scx, _scy+8, _st);
            }
            if(shopBtn!=null){
                c.drawRoundRect(shopBtn,10,10,hlP);
                Paint sTmp=new Paint(Paint.ANTI_ALIAS_FLAG); sTmp.setColor(Color.WHITE); sTmp.setTextSize(22f); sTmp.setTextAlign(Paint.Align.CENTER);
                c.drawText("\uD83D\uDED2",shopBtn.centerX(),shopBtn.centerY()+9,sTmp);
            }
            // Instruction label
            Paint infoP = fill(Color.WHITE); infoP.setTextSize(20f); infoP.setTextAlign(Paint.Align.CENTER);
            infoP.setShadowLayer(3f,0,2f,Color.BLACK);
            c.drawText("Drag buttons to reposition", w/2, h/2 - 20, infoP);
            // Confirm button
            if(confirmMoveRect!=null){
                Paint confP = fill(Color.argb(230,50,190,90));
                c.drawRoundRect(confirmMoveRect,12,12,confP);
                Paint confTxt = new Paint(btnTxtP); confTxt.setTextSize(24f);
                c.drawText("✓  DONE", confirmMoveRect.centerX(), confirmMoveRect.centerY()+9, confTxt);
            }
        }

        // ── Settings overlay ──────────────────────────────────────────────────
        if(settingsOpen) drawSettings(c);

        // ── Shop overlay ──────────────────────────────────────────────────────
        if(shopOpen) drawShop(c);
    }

    // ═══ SKILL BUTTON ════════════════════════════════════════════════════════
    private void drawSkillButton(Canvas c, Player lp) {
        if (skillRect == null) return;
        String[] skillIcons  = {"", "💨", "👁", "💊", "🛡"};
        String[] skillNames  = {"NO SKILL", "DASH", "STEALTH", "HEAL", "SHIELD"};
        int t = lp.activeSkillType;

        boolean onCd    = lp.skillOnCooldown();
        boolean active  = lp.skillIsActive();
        boolean noSkill = (t == Player.ACTIVE_NONE);

        float cx = skillRect.centerX(), cy = skillRect.centerY(), r = skillRect.width() / 2f;

        // Button colour
        int btnColor;
        if (noSkill)      btnColor = Color.argb(100,50,50,50);
        else if (onCd)    btnColor = Color.argb(150,60,60,60);
        else if (active)  btnColor = Color.argb(220,50,200,160);
        else              btnColor = Color.argb(210,60,100,200);

        c.drawCircle(cx, cy, r, fill(btnColor));

        // Circle border
        Paint borderP = new Paint(Paint.ANTI_ALIAS_FLAG);
        borderP.setStyle(Paint.Style.STROKE);
        borderP.setStrokeWidth(3f);
        borderP.setColor(noSkill ? Color.argb(60,150,150,150) : Color.argb(160,150,200,255));
        c.drawCircle(cx, cy, r, borderP);

        // Cooldown sweep overlay (arc over circle)
        if (onCd && !noSkill) {
            long total = skillCooldownTotal(t);
            long rem   = lp.skillCooldownEnd - System.currentTimeMillis();
            float frac = Math.max(0f, Math.min(1f, (float)rem / total));
            // Dark fill
            c.drawCircle(cx, cy, r, fill(Color.argb(140,0,0,0)));
            // Sweep arc to show progress
            Paint arcP = new Paint(Paint.ANTI_ALIAS_FLAG);
            arcP.setColor(Color.argb(180,60,100,200));
            arcP.setStyle(Paint.Style.FILL);
            RectF arcRect = new RectF(cx-r, cy-r, cx+r, cy+r);
            c.drawArc(arcRect, -90f, 360f * (1f - frac), true, arcP);
            // Re-draw border on top
            c.drawCircle(cx, cy, r, borderP);
            // Cooldown text
            Paint cdTxt = fill(Color.argb(220,255,200,0));
            cdTxt.setTextSize(r * 0.45f); cdTxt.setTextAlign(Paint.Align.CENTER);
            cdTxt.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText((rem/1000+1)+"s", cx, cy + r*0.17f, cdTxt);
        }

        // Label + icon (only when not on cooldown)
        if (!onCd || noSkill) {
            String icon  = noSkill ? "❌" : skillIcons[t];
            String label = noSkill ? "SKILL" : skillNames[t];
            Paint iconP = new Paint(Paint.ANTI_ALIAS_FLAG);
            iconP.setTextSize(r * 0.70f); iconP.setTextAlign(Paint.Align.CENTER);
            c.drawText(icon, cx, cy - r * 0.05f, iconP);
            Paint lbP = new Paint(btnTxtP); lbP.setTextSize(r * 0.30f);
            lbP.setColor(Color.argb(200,220,230,255));
            c.drawText(label, cx, cy + r * 0.62f, lbP);
        }

        // Active glow ring
        if (active) {
            Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
            glow.setStyle(Paint.Style.STROKE); glow.setStrokeWidth(4f);
            glow.setColor(Color.argb(200,80,255,180));
            float pulse = 0.5f+0.5f*(float)Math.abs(Math.sin(System.currentTimeMillis()/200.0));
            glow.setAlpha((int)(200*pulse));
            c.drawCircle(cx, cy, r + 5f * pulse, glow);
        }
    }

    private long skillCooldownTotal(int type) {
        switch(type){
            case Player.ACTIVE_DASH:    return 6000;
            case Player.ACTIVE_STEALTH: return 10000;
            case Player.ACTIVE_HEAL:    return 12000;
            case Player.ACTIVE_SHIELD:  return 14000;
            default: return 1;
        }
    }

    // ═══ SETTINGS OVERLAY ════════════════════════════════════════════════════
    private void drawSettings(Canvas c) {
        if(settingsPanel==null) return;
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS, 0);
        int  jsSize  = prefs.getInt    ("js_size",  1);
        boolean swap = prefs.getBoolean("swap",     false);
        int  btnSize = prefs.getInt    ("btn_size", 1);
        int  opacity = prefs.getInt    ("opacity",  1);

        // Panel background + border
        c.drawRoundRect(settingsPanel, 16, 16, settingsBgP);
        Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setColor(Color.argb(160,80,120,200)); border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
        c.drawRoundRect(settingsPanel, 16, 16, border);

        float px = settingsPanel.left, py = settingsPanel.top;
        float pw = settingsPanel.width();

        c.drawText("⚙  CONTROLS", px+20, py+42, settingsTitleP);

        c.drawRoundRect(closeSettingsRect, 8, 8, closeBtnP);
        Paint cTxt = new Paint(optTxtP); cTxt.setTextSize(20f);
        c.drawText("✕", closeSettingsRect.centerX(), closeSettingsRect.centerY()+7, cTxt);

        Paint div = fill(Color.argb(60,255,255,255));
        c.drawRect(px+16, py+58, px+pw-16, py+60, div);

        int aimSens = prefs.getInt("aim_sens", 1);
        boolean showGunStats = prefs.getBoolean("gun_stats", true);
        boolean showAimLine  = prefs.getBoolean("aim_line",  false);

        // Row labels
        String[] labels = {"JOYSTICK SIZE","SWAP SIDES","BUTTON SIZE","AIM SPEED","OPACITY","GUN STATS","AIM LINE"};
        float[] rowY = {py+66f, py+128f, py+190f, py+252f, py+314f, py+376f, py+438f};
        for(int r=0;r<7;r++) c.drawText(labels[r], px+20, rowY[r]+26, settingsLabelP);

        String[] jsLabels = {"S","M","L"};
        for(int i=0;i<3;i++) drawOpt(c, jsSizeOpts[i],  jsLabels[i], i==jsSize);
        String[] swLabels = {"OFF","ON"};
        for(int i=0;i<2;i++) drawOpt(c, swapOpts[i],    swLabels[i], i==(swap?1:0));
        String[] bsLabels = {"S","M","L"};
        for(int i=0;i<3;i++) drawOpt(c, btnSizeOpts[i], bsLabels[i], i==btnSize);
        String[] asLabels = {"SLOW","NORM","FAST"};
        for(int i=0;i<3;i++) drawOpt(c, aimSensOpts[i], asLabels[i], i==aimSens);
        String[] opLabels = {"LO","MED","HI"};
        for(int i=0;i<3;i++) drawOpt(c, opacityOpts[i], opLabels[i], i==opacity);
        String[] gsLabels = {"ON","OFF"};
        for(int i=0;i<2;i++) drawOpt(c, gunStatOpts[i], gsLabels[i], i==(showGunStats?0:1));
        String[] alLabels = {"ON","OFF"};
        for(int i=0;i<2;i++) drawOpt(c, aimLineOpts[i], alLabels[i], i==(showAimLine?0:1));

        // MOVE BUTTONS button
        if(moveBtnsRect!=null){
            Paint mbP = fill(Color.argb(210,60,110,190));
            c.drawRoundRect(moveBtnsRect, 10, 10, mbP);
            Paint mbTxt = new Paint(optTxtP); mbTxt.setTextSize(19f); mbTxt.setColor(Color.WHITE);
            c.drawText("✥  MOVE BUTTONS", moveBtnsRect.centerX(), moveBtnsRect.centerY()+7, mbTxt);
        }
    }

    private void drawOpt(Canvas c, RectF r, String label, boolean selected) {
        if(r==null) return;
        c.drawRoundRect(r, 8, 8, selected ? optBtnSelP : optBtnP);
        Paint t = new Paint(optTxtP);
        if(selected) { t.setColor(Color.WHITE); } else { t.setColor(Color.argb(180,200,210,230)); }
        c.drawText(label, r.centerX(), r.centerY()+7, t);
    }

    // ═══ SHOP OVERLAY ════════════════════════════════════════════════════════
    private void drawShop(Canvas c) {
        Player lp = localPlayer;
        float spw = Math.min(580f, screenW - 40f);
        float sph = 670f;
        float spx = (screenW - spw) / 2f;
        float spy = (screenH - sph) / 2f;

        // Panel background + border
        c.drawRoundRect(new RectF(spx,spy,spx+spw,spy+sph),18,18,settingsBgP);
        Paint border=new Paint(Paint.ANTI_ALIAS_FLAG);
        border.setColor(Color.argb(180,80,120,200));
        border.setStyle(Paint.Style.STROKE); border.setStrokeWidth(2f);
        c.drawRoundRect(new RectF(spx,spy,spx+spw,spy+sph),18,18,border);

        // Title
        c.drawText("\uD83D\uDED2  SHOP", spx+20, spy+44, settingsTitleP);

        // Coins
        Paint cpP=fill(Color.rgb(255,210,50)); cpP.setTextSize(22f);
        cpP.setTextAlign(Paint.Align.RIGHT); cpP.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("\uD83D\uDCB0 "+(lp!=null?lp.coins:0), spx+spw-20, spy+44, cpP);

        // Close button
        if(shopCloseRect!=null){
            c.drawRoundRect(shopCloseRect,8,8,closeBtnP);
            Paint cTxt=new Paint(optTxtP); cTxt.setTextSize(20f);
            c.drawText("✕",shopCloseRect.centerX(),shopCloseRect.centerY()+7,cTxt);
        }

        // Tab buttons
        if (shopTabGuns != null && shopTabSkills != null) {
            Paint tabActive   = fill(Color.argb(220,60,100,200));
            Paint tabInactive = fill(Color.argb(100,40,40,70));
            Paint tabTxt = fill(Color.WHITE); tabTxt.setTextSize(17f); tabTxt.setTextAlign(Paint.Align.CENTER); tabTxt.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawRoundRect(shopTabGuns,   10,10, shopTab==0?tabActive:tabInactive);
            c.drawRoundRect(shopTabSkills, 10,10, shopTab==1?tabActive:tabInactive);
            c.drawText("\uD83D\uDD2B Weapons", shopTabGuns.centerX(),   shopTabGuns.centerY()+7,   tabTxt);
            c.drawText("\u26A1 Skills",         shopTabSkills.centerX(), shopTabSkills.centerY()+7, tabTxt);
        }

        if (shopTab == 0) drawShopGuns(c, lp, spx, spy, spw);
        else              drawShopSkills(c, lp, spx, spy, spw);
    }

    private void drawShopGuns(Canvas c, Player lp, float spx, float spy, float spw) {
        Gun[] allGuns = Gun.createAll();
        float rowH=68f, rowGap=4f, firstRowY=spy+110f;
        Paint sbgP=fill(Color.argb(60,255,255,255));
        Paint slblP=fill(Color.argb(180,200,220,255)); slblP.setTextSize(10f);
        for(int i=0;i<7;i++){
            float ry = firstRowY + i*(rowH+rowGap);
            Gun g = allGuns[i];
            boolean owned = (lp==null)||lp.unlockedGuns[i];
            Paint rowBg=fill(owned?Color.argb(55,60,140,70):Color.argb(40,40,40,80));
            c.drawRoundRect(new RectF(spx+10,ry,spx+spw-10,ry+rowH),8,8,rowBg);
            c.drawCircle(spx+28,ry+rowH/2,10,fill(g.color));
            Paint gnP=fill(g.color); gnP.setTextSize(18f); gnP.setTypeface(Typeface.DEFAULT_BOLD); gnP.setTextAlign(Paint.Align.LEFT);
            c.drawText(g.name, spx+46, ry+21, gnP);
            String[] sn={"DMG","SPD","RNG","RATE"};
            float[] sv={g.statDamage(),g.statSpeed(),g.statRange(),g.statFireRate()};
            int[]   sc={0xFFFF5252,0xFF64B5F6,0xFF81C784,0xFFFFD54F};
            float bw2=50f, bh2=6f, bgap=6f, barsX=spx+46f, barsY=ry+30f;
            for(int si=0;si<4;si++){
                float bx2=barsX+si*(bw2+bgap);
                c.drawRoundRect(bx2,barsY,bx2+bw2,barsY+bh2,3,3,sbgP);
                c.drawRoundRect(bx2,barsY,bx2+bw2*sv[si],barsY+bh2,3,3,fill(sc[si]));
                slblP.setTextAlign(Paint.Align.LEFT);
                c.drawText(sn[si],bx2,barsY+bh2+11f,slblP);
            }
            if(shopBuyRects[i]!=null){
                if(owned){
                    c.drawRoundRect(shopBuyRects[i],8,8,fill(Color.argb(180,50,180,80)));
                    Paint otP=fill(Color.WHITE); otP.setTextSize(14f); otP.setTextAlign(Paint.Align.CENTER); otP.setTypeface(Typeface.DEFAULT_BOLD);
                    c.drawText("✓ OWNED",shopBuyRects[i].centerX(),shopBuyRects[i].centerY()+6,otP);
                } else {
                    int price=GUN_PRICES[i];
                    boolean afford=(lp!=null&&lp.coins>=price);
                    c.drawRoundRect(shopBuyRects[i],8,8,fill(afford?Color.argb(220,180,130,0):Color.argb(120,70,70,80)));
                    Paint btP=fill(afford?Color.WHITE:Color.argb(120,200,200,200)); btP.setTextSize(14f); btP.setTextAlign(Paint.Align.CENTER); btP.setTypeface(Typeface.DEFAULT_BOLD);
                    c.drawText("\uD83D\uDCB0 "+price,shopBuyRects[i].centerX(),shopBuyRects[i].centerY()+6,btP);
                }
            }
        }
    }

    private void drawShopSkills(Canvas c, Player lp, float spx, float spy, float spw) {
        // ── Passive section header ──
        Paint secP=fill(Color.argb(220,180,180,255)); secP.setTextSize(17f); secP.setTextAlign(Paint.Align.LEFT); secP.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("● PASSIVE SKILLS", spx+18, spy+126, secP);

        String[] passNames={"⚡ Fast Reload","🔥 Fire Rate","🎯 Bullet Range","👟 Move Speed"};
        String[] passDesc ={"−20% reload per level","+20% fire rate per level","+25% range per level","+12% speed per level"};
        int[]    passLevels=(lp==null)?new int[4]:new int[]{lp.skillReload,lp.skillFireRate,lp.skillRange,lp.skillMoveSpeed};
        float rowH=54f,rowGap=4f,firstY=spy+132f;
        for(int i=0;i<4;i++){
            float ry=firstY+i*(rowH+rowGap);
            int lv=passLevels[i];
            c.drawRoundRect(new RectF(spx+12,ry,spx+spw-12,ry+rowH),10,10,fill(Color.argb(80,30,30,70)));
            Paint nameP2=fill(Color.WHITE); nameP2.setTextSize(16f); nameP2.setTextAlign(Paint.Align.LEFT); nameP2.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(passNames[i],spx+18,ry+22,nameP2);
            Paint descP=fill(Color.argb(150,190,190,190)); descP.setTextSize(12f); descP.setTextAlign(Paint.Align.LEFT);
            c.drawText(passDesc[i],spx+18,ry+40,descP);
            for(int d=0;d<3;d++){
                Paint pip=fill(d<lv?Color.rgb(80,200,255):Color.argb(80,80,80,80));
                c.drawCircle(spx+spw-140+d*24,ry+rowH/2f,9,pip);
            }
            if(passiveBuyRects[i]!=null){
                if(lv>=3){
                    c.drawRoundRect(passiveBuyRects[i],8,8,fill(Color.argb(100,40,120,40)));
                    Paint ot=fill(Color.argb(200,150,255,150)); ot.setTextSize(13f); ot.setTextAlign(Paint.Align.CENTER);
                    c.drawText("MAX",passiveBuyRects[i].centerX(),passiveBuyRects[i].centerY()+5,ot);
                } else {
                    int cost=PASSIVE_SKILL_COSTS[lv];
                    boolean canBuy=lp!=null&&lp.coins>=cost;
                    c.drawRoundRect(passiveBuyRects[i],8,8,fill(canBuy?Color.argb(210,60,100,200):Color.argb(80,60,60,60)));
                    Paint bt=fill(canBuy?Color.WHITE:Color.argb(120,180,180,180)); bt.setTextSize(13f); bt.setTextAlign(Paint.Align.CENTER);
                    c.drawText("\uD83D\uDCB0"+cost,passiveBuyRects[i].centerX(),passiveBuyRects[i].centerY()+5,bt);
                }
            }
        }

        // ── Active section header ──
        Paint secP2=fill(Color.argb(220,255,210,80)); secP2.setTextSize(17f); secP2.setTextAlign(Paint.Align.LEFT); secP2.setTypeface(Typeface.DEFAULT_BOLD);
        c.drawText("● ACTIVE SKILL  (equip one)", spx+18, spy+388, secP2);
        Paint noteP=fill(Color.argb(130,180,180,180)); noteP.setTextSize(12f); noteP.setTextAlign(Paint.Align.LEFT);
        c.drawText("Tap [SKILL] button in-game to activate", spx+18, spy+407, noteP);

        String[] actNames={"💨 Dash","👁 Stealth","💊 Heal","🛡 Shield"};
        String[] actDesc ={"Teleport 260px  •  6s cooldown","Invisible 4s  •  10s cooldown","+40 HP  •  12s cooldown","60-HP barrier 6s  •  14s cooldown"};
        int[]    actTypes={Player.ACTIVE_DASH,Player.ACTIVE_STEALTH,Player.ACTIVE_HEAL,Player.ACTIVE_SHIELD};
        float activeFirstY=spy+412f;
        for(int i=0;i<4;i++){
            float ry=activeFirstY+i*(rowH+rowGap);
            boolean owned=(lp!=null&&lp.activeSkillType==actTypes[i]);
            c.drawRoundRect(new RectF(spx+12,ry,spx+spw-12,ry+rowH),10,10,fill(owned?Color.argb(100,50,80,30):Color.argb(80,30,30,60)));
            Paint nameP2=fill(Color.WHITE); nameP2.setTextSize(16f); nameP2.setTextAlign(Paint.Align.LEFT); nameP2.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(actNames[i],spx+18,ry+22,nameP2);
            Paint descP=fill(Color.argb(150,190,190,190)); descP.setTextSize(12f); descP.setTextAlign(Paint.Align.LEFT);
            c.drawText(actDesc[i],spx+18,ry+40,descP);
            if(activeBuyRects[i]!=null){
                if(owned){
                    c.drawRoundRect(activeBuyRects[i],8,8,fill(Color.argb(100,40,120,40)));
                    Paint ot=fill(Color.argb(200,150,255,150)); ot.setTextSize(12f); ot.setTextAlign(Paint.Align.CENTER);
                    c.drawText("EQUIPPED",activeBuyRects[i].centerX(),activeBuyRects[i].centerY()+5,ot);
                } else {
                    int cost=ACTIVE_SKILL_COSTS[i];
                    boolean canBuy=lp!=null&&lp.coins>=cost;
                    c.drawRoundRect(activeBuyRects[i],8,8,fill(canBuy?Color.argb(210,100,60,200):Color.argb(80,60,60,60)));
                    Paint bt=fill(canBuy?Color.WHITE:Color.argb(120,180,180,180)); bt.setTextSize(12f); bt.setTextAlign(Paint.Align.CENTER);
                    c.drawText("\uD83D\uDCB0"+cost,activeBuyRects[i].centerX(),activeBuyRects[i].centerY()+5,bt);
                }
            }
        }
    }
    private void handleShopTap(float x, float y) {
        Player lp=localPlayer; if(lp==null) return;

        // Tab switch
        if(shopTabGuns!=null   && shopTabGuns.contains(x,y))   { shopTab=0; return; }
        if(shopTabSkills!=null && shopTabSkills.contains(x,y)) { shopTab=1; return; }

        if(shopTab==0){
            // Weapon purchases
            for(int i=0;i<7;i++){
                if(shopBuyRects[i]!=null&&shopBuyRects[i].contains(x,y)){
                    if(!lp.unlockedGuns[i]&&lp.coins>=GUN_PRICES[i]){
                        lp.coins-=GUN_PRICES[i];
                        int unlockedCount=0;
                        for(boolean u:lp.unlockedGuns) if(u) unlockedCount++;
                        if(unlockedCount>=2){
                            for(int j=0;j<7;j++){
                                if(lp.unlockedGuns[j]&&j!=lp.gunIndex){ lp.unlockedGuns[j]=false; break; }
                            }
                        }
                        lp.unlockedGuns[i]=true;
                    }
                    return;
                }
            }
        } else {
            // Passive skill purchases
            int[] passLevels ={lp.skillReload,lp.skillFireRate,lp.skillRange,lp.skillMoveSpeed};
            for(int i=0;i<4;i++){
                if(passiveBuyRects[i]!=null&&passiveBuyRects[i].contains(x,y)){
                    int lv=passLevels[i];
                    if(lv<3){
                        int cost=PASSIVE_SKILL_COSTS[lv];
                        if(lp.coins>=cost){
                            lp.coins-=cost;
                            if(i==0) lp.skillReload++;
                            else if(i==1) lp.skillFireRate++;
                            else if(i==2) lp.skillRange++;
                            else          lp.skillMoveSpeed++;
                        }
                    }
                    return;
                }
            }
            // Active skill purchases (buy = equip, replaces current)
            int[] actTypes={Player.ACTIVE_DASH,Player.ACTIVE_STEALTH,Player.ACTIVE_HEAL,Player.ACTIVE_SHIELD};
            for(int i=0;i<4;i++){
                if(activeBuyRects[i]!=null&&activeBuyRects[i].contains(x,y)){
                    if(lp.activeSkillType!=actTypes[i]){
                        int cost=ACTIVE_SKILL_COSTS[i];
                        if(lp.coins>=cost){
                            lp.coins-=cost;
                            lp.activeSkillType=actTypes[i];
                            lp.skillCooldownEnd=0; lp.skillActiveUntil=0; lp.shieldHp=0;
                        }
                    }
                    return;
                }
            }
        }
    }

    // ═══ NETWORK SERIALIZE ════════════════════════════════════════════════════
    private void broadcast(){
        try{
            JSONObject root=new JSONObject();
            JSONArray pa=new JSONArray();
            Player lp=localPlayer; if(lp!=null) pa.put(pj(lp));
            for(Player p:remote.values()) pa.put(pj(p));
            root.put("p",pa);
            // Bullets
            JSONArray ba=new JSONArray();
            for(Bullet b:bullets){
                JSONObject bj=new JSONObject();
                bj.put("x",(int)b.x); bj.put("y",(int)b.y);
                bj.put("u",(int)b.dx); bj.put("v",(int)b.dy);
                bj.put("o",b.ownerId); bj.put("d",(int)b.damage); bj.put("i",b.id);
                ba.put(bj);
            }
            root.put("b",ba);
            // Bombs — full physics state so clients render them correctly
            JSONArray bma=new JSONArray();
            for(Bomb b:activeBombs){
                JSONObject bj=new JSONObject();
                bj.put("x",b.x); bj.put("y",b.y); bj.put("o",b.ownerId);
                bj.put("vx",b.vx); bj.put("vy",b.vy);
                bj.put("rx",b.rollVx); bj.put("ry",b.rollVy);
                bj.put("mr",b.maxRange);
                bj.put("ln",b.hasLanded); bj.put("ea",b.explodedAt);
                bj.put("dt",b.deployTime);
                bma.put(bj);
            }
            root.put("bm",bma);
            net.broadcastState(root.toString());
        }catch(Exception e){ e.printStackTrace(); }
    }
    private JSONObject pj(Player p) throws Exception {
        JSONObject o=new JSONObject();
        o.put("i",p.id); o.put("n",p.name);
        o.put("x",(int)p.x); o.put("y",(int)p.y);
        o.put("a",(double)p.angle);
        o.put("h",(int)p.hp); o.put("g",p.gunIndex); o.put("v",p.alive);
        o.put("c",p.coins);
        o.put("sr",p.skillReload); o.put("sf",p.skillFireRate);
        o.put("sg",p.skillRange);  o.put("sm",p.skillMoveSpeed);
        o.put("sa",p.activeSkillType);
        o.put("ss",(int)p.shieldHp);
        long rem=Math.max(0,p.spawnProtectionUntil-System.currentTimeMillis());
        o.put("sp",(int)rem);
        long aRem=Math.max(0,p.skillActiveUntil-System.currentTimeMillis());
        o.put("se",(int)aRem);
        return o;
    }
    private void applyState(String json){
        try{
            JSONObject root=new JSONObject(json);
            JSONArray pa=root.getJSONArray("p");
            for(int i=0;i<pa.length();i++){
                JSONObject o=pa.getJSONObject(i);
                int id=o.getInt("i"); boolean alive=o.getBoolean("v");
                float hx=o.getInt("x"), hy=o.getInt("y");
                Player lp=localPlayer;
                if(lp!=null&&id==lp.id){
                    boolean was=lp.alive;
                    lp.hp=o.getInt("h"); lp.alive=alive;
                    lp.coins=o.optInt("c", lp.coins);
                    int spMs=o.optInt("sp",0);
                    if(spMs>0) lp.spawnProtectionUntil=System.currentTimeMillis()+spMs;
                    if(was&&!alive) deathTime=System.currentTimeMillis();
                    // Always reconcile position from host — on LAN ~1ms lag, prevents drift
                    float dx=lp.x-hx, dy=lp.y-hy;
                    if(dx*dx+dy*dy > 40*40){
                        // Only snap if significantly off (>40px) to avoid fighting local prediction
                        lp.x=hx; lp.y=hy;
                    }
                    continue;
                }
                Player p=remote.get(id);
                if(p==null){p=new Player();p.id=id;p.guns=Gun.createAll();remote.put(id,p);}
                p.name=o.getString("n"); p.x=hx; p.y=hy;
                p.angle=(float)o.getDouble("a"); p.hp=o.getInt("h");
                p.gunIndex=o.getInt("g"); p.alive=alive;
                p.skillReload   =o.optInt("sr",p.skillReload);
                p.skillFireRate =o.optInt("sf",p.skillFireRate);
                p.skillRange    =o.optInt("sg",p.skillRange);
                p.skillMoveSpeed=o.optInt("sm",p.skillMoveSpeed);
                p.activeSkillType=o.optInt("sa",p.activeSkillType);
                p.shieldHp      =(float)o.optInt("ss",0);
                int spMs=o.optInt("sp",0);
                if(spMs>0) p.spawnProtectionUntil=System.currentTimeMillis()+spMs;
                int aRem=o.optInt("se",0);
                if(aRem>0) p.skillActiveUntil=System.currentTimeMillis()+aRem;
            }
            // ── Bullets ──────────────────────────────────────────────────────
            JSONArray ba=root.getJSONArray("b");
            bullets.clear();
            for(int i=0;i<ba.length();i++){
                JSONObject bj=ba.getJSONObject(i);
                bullets.add(new Bullet(bj.getInt("x"),bj.getInt("y"),
                    bj.getInt("u"),bj.getInt("v"),
                    bj.getInt("o"),bj.getInt("d"),bj.getInt("i"),Float.MAX_VALUE));
            }
            // ── Bombs ─────────────────────────────────────────────────────────
            JSONArray bma=root.optJSONArray("bm");
            if(bma!=null){
                activeBombs.clear();
                for(int i=0;i<bma.length();i++){
                    JSONObject bj=bma.getJSONObject(i);
                    Bomb b=new Bomb((float)bj.getDouble("x"),(float)bj.getDouble("y"),bj.getInt("o"));
                    b.vx=(float)bj.getDouble("vx"); b.vy=(float)bj.getDouble("vy");
                    b.rollVx=(float)bj.getDouble("rx"); b.rollVy=(float)bj.getDouble("ry");
                    b.maxRange=(float)bj.getDouble("mr");
                    b.hasLanded=bj.getBoolean("ln");
                    b.explodedAt=bj.getLong("ea");
                    b.deployTime=bj.getLong("dt");
                    activeBombs.add(b);
                }
            }
        }catch(Exception e){ e.printStackTrace(); }
    }
    private void sendInput(Player lp){
        try{
            JSONObject o=new JSONObject();
            // Joystick (kept for host-side angle/aim logic)
            o.put("0",moveStick.getX()); o.put("1",moveStick.getY());
            o.put("2",aimStick.getX());  o.put("3",aimStick.getY());
            float _ax=aimStick.getX(), _ay=aimStick.getY();
            o.put("4", aimStick.isActive() && (_ax*_ax+_ay*_ay) > 0.85f*0.85f);
            o.put("5",lp.gunIndex);
            o.put("6",lp.currentGun().reloading);
            // ── Authoritative client position (avoids dual-simulation drift) ──
            o.put("px", lp.x); o.put("py", lp.y);
            // Passive skill levels
            o.put("7",lp.skillReload);
            o.put("8",lp.skillFireRate);
            o.put("9",lp.skillRange);
            o.put("10",lp.skillMoveSpeed);
            // Active skill
            o.put("11",lp.activeSkillType);
            long secsRem=Math.max(0,(lp.skillActiveUntil-System.currentTimeMillis())/1000);
            o.put("12",secsRem);
            o.put("13",lp.shieldHp);
            // Dash position override (already folded into px/py above; flag kept for compat)
            o.put("14", pendingPositionSync ? 1 : 0);
            pendingPositionSync = false;
            // ── Pending bomb throw ─────────────────────────────────────────────
            if (pendingBombSend != null) {
                o.put("bt", 1);
                o.put("bvx", pendingBombSend[0]);
                o.put("bvy", pendingBombSend[1]);
                o.put("bmr", pendingBombSend[2]);
                pendingBombSend = null;
            } else {
                o.put("bt", 0);
            }
            net.sendInput(o.toString());
        }catch(Exception e){ if(net!=null) e.printStackTrace(); }
    }

    // ═══ CALLBACKS ════════════════════════════════════════════════════════════
    @Override public void onHostDiscovered(String ip,String n){}
    @Override public void onJoined(int id){
        // Network thread — just assign (volatile reference, atomic)
        Player p=new Player(); p.id=id; p.name=savedName; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true;  // ← must be set or client stays "dead" forever
        localPlayer=p;
    }
    @Override public void onPlayerJoined(int id,String name){
        if(remote.containsKey(id)) return;
        Player p=new Player(); p.id=id; p.name=name; p.guns=Gun.createAll();
        float[] sp=SPAWNS[id%SPAWNS.length]; p.x=sp[0]; p.y=sp[1];
        p.hp=100; p.alive=true;
        remote.put(id,p); addFeed(name+" joined");
    }
    @Override public void onStateUpdate(String json){ pendingState=json; }
    @Override public void onInputReceived(int pid,String json){
        try{
            JSONObject o=new JSONObject(json);
            inputs.put(pid,new float[]{
                (float)o.getDouble("0"),(float)o.getDouble("1"),
                (float)o.getDouble("2"),(float)o.getDouble("3"),
                o.getBoolean("4")?1f:0f,(float)o.getInt("5"),o.getBoolean("6")?1f:0f,
                (float)o.optInt("7",0),(float)o.optInt("8",0),
                (float)o.optInt("9",0),(float)o.optInt("10",0),
                (float)o.optInt("11",0),(float)o.optLong("12",0),
                (float)o.optDouble("13",0),
                (float)o.optDouble("px",-1),   // [14] authoritative x (-1 = not provided)
                (float)o.optDouble("py",-1),   // [15] authoritative y
                (float)o.optInt("14",0)        // [16] dash flag (unused now, kept for compat)
            });
            // Bomb throw event — host creates it immediately so it's in sync
            if(o.optInt("bt",0)==1){
                Player p=remote.get(pid);
                if(p!=null&&p.alive&&p.bombs>0){
                    boolean hasBomb=false;
                    for(Bomb b:activeBombs) if(b.ownerId==p.id&&!b.isDone()&&b.explodedAt<0){hasBomb=true;break;}
                    if(!hasBomb){
                        p.bombs--;
                        Bomb bomb=new Bomb(p.x,p.y,p.id);
                        bomb.vx=(float)o.getDouble("bvx");
                        bomb.vy=(float)o.getDouble("bvy");
                        bomb.maxRange=(float)o.getDouble("bmr");
                        activeBombs.add(bomb);
                    }
                }
            }
        }catch(Exception e){ e.printStackTrace(); }
    }

    // ═══ UTIL ═════════════════════════════════════════════════════════════════
    private static float d2(float ax,float ay,float bx,float by){float dx=ax-bx,dy=ay-by;return dx*dx+dy*dy;}
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}
    private String nameOf(int id){
        Player lp=localPlayer; if(lp!=null&&id==lp.id) return lp.name;
        Player p=remote.get(id); return p!=null?p.name:"P"+id;
    }
    private void addFeed(String msg){
        synchronized(feed){feed.add(0,msg);if(feed.size()>4)feed.remove(feed.size()-1);}
    }
}
