// ============================================================================
// HZCM v3 — World.cpp
// ============================================================================
#include "World.h"
#include <android/log.h>
#include <algorithm>
#include <condition_variable>
#include <cmath>
#include <climits>

#define TAG  "HZCMWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ─────────────────────────────────────────────────────────────────────────────
World::World() : m_noise(0) {}

World::~World() {
    {
        std::unique_lock<std::mutex> lock(m_pool.mtx);
        m_pool.stop = true;
    }
    m_pool.cv.notify_all();
    for (auto& t : m_workers)
        if (t.joinable()) t.join();
}

// ── Worker thread pool ────────────────────────────────────────────────────────
void World::workerLoop() {
    while (true) {
        std::function<void()> task;
        {
            std::unique_lock<std::mutex> lock(m_pool.mtx);
            m_pool.cv.wait(lock, [&]{ return m_pool.stop || !m_pool.q.empty(); });
            if (m_pool.stop && m_pool.q.empty()) return;
            task = std::move(m_pool.q.front());
            m_pool.q.pop();
        }
        task();
    }
}

void World::enqueueTask(std::function<void()> fn) {
    { std::unique_lock<std::mutex> lk(m_pool.mtx); m_pool.q.push(std::move(fn)); }
    m_pool.cv.notify_one();
}

// ── Init ──────────────────────────────────────────────────────────────────────
void World::init(int seed) {
    m_noise = Noise(seed);

    // Reset pool
    { std::unique_lock<std::mutex> lk(m_pool.mtx); m_pool.stop = false; while (!m_pool.q.empty()) m_pool.q.pop(); }
    { std::unique_lock<std::shared_mutex> lk(m_chunksMtx); m_chunks.clear(); }
    m_submitted.clear();
    m_lastCamCX = INT_MIN; m_lastCamCZ = INT_MIN;

    // Worker threads: 2..4, capped at 3 on mobile to leave one core for GL
    int hw = (int)std::thread::hardware_concurrency();
    int nThreads = std::max(2, std::min(3, hw - 1));
    LOGI("Starting %d worker threads (hw=%d)", nThreads, hw);
    for (int i = 0; i < nThreads; ++i)
        m_workers.emplace_back([this]{ workerLoop(); });

    // MegaBuffer init happens on GL thread (Renderer::init calls world.init
    // then immediately calls mega.init via renderer)
    // Seed initial area
    update(0.f, 0.f, 0.f, 0.f, 0.f, 1.f, 0.016f);
    LOGI("World init done");
}

// ── Per-frame streaming update ────────────────────────────────────────────────
void World::update(float camX, float camZ,
                    float velX, float velZ,
                    float fwdX, float fwdZ,
                    float dt)
{
    // Update thermal + scheduler every frame (cheap)
    m_thermal.update(dt);
    m_scheduler.update(camX, camZ, velX, velZ, fwdX, fwdZ);

    int camCX = (int)floorf(camX / (float)CHUNK_W);
    int camCZ = (int)floorf(camZ / (float)CHUNK_D);

    // ── Unload (GL thread only, safe to write m_chunks) ──────────────────────
    if (camCX != m_lastCamCX || camCZ != m_lastCamCZ) {
        std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
        auto it = m_chunks.begin();
        while (it != m_chunks.end()) {
            int dx = it->first.cx - camCX;
            int dz = it->first.cz - camCZ;
            if (std::abs(dx) > UNLOAD_RADIUS || std::abs(dz) > UNLOAD_RADIUS) {
                // Evict GPU allocations for all clusters
                evictChunk(it->second.get());
                m_submitted.erase({it->first.cx, it->first.cz});
                it = m_chunks.erase(it);
            } else {
                ++it;
            }
        }
    }

    // ── Submit new chunks (sorted by streaming priority) ─────────────────────
    if (camCX != m_lastCamCX || camCZ != m_lastCamCZ) {
        m_lastCamCX = camCX; m_lastCamCZ = camCZ;

        // Build and sort candidate list
        std::vector<ChunkPriority> candidates;
        StreamScheduler::buildCandidates(camCX, camCZ, 0, RENDER_RADIUS, candidates);
        m_scheduler.sortByPriority(candidates);

        for (auto& cp : candidates) {
            ChunkKey key{cp.cx, cp.cz};
            if (m_submitted.count(key)) continue;
            m_submitted.insert(key);

            Chunk* ptr;
            {
                std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
                auto ch = std::make_unique<Chunk>(cp.cx, cp.cz);
                ptr = ch.get();
                m_chunks[key] = std::move(ch);
            }

            // Generate + mesh all 4 clusters on a worker thread
            enqueueTask([this, ptr]() {
                ptr->generate(m_noise);
                // Mesh all clusters for this new chunk
                int cx = ptr->cx, cz = ptr->cz;
                const Chunk *nx, *px, *nz, *pz;
                {
                    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
                    nx = getChunk(cx-1, cz); px = getChunk(cx+1, cz);
                    nz = getChunk(cx, cz-1); pz = getChunk(cx, cz+1);
                }
                for (int ci = 0; ci < CLUSTER_STACK; ++ci)
                    ptr->buildClusterMesh(ci, nx, px, nz, pz);

                // Push all meshed clusters to upload queue
                {
                    std::unique_lock<std::mutex> ulk(m_uploadMtx);
                    for (int ci = 0; ci < CLUSTER_STACK; ++ci)
                        m_uploadQueue.push_back({ ptr, ci });
                }

                // Re-mesh border clusters of existing neighbours
                triggerNeighbourRemesh(cx, cz, -1); // -1 = all clusters
            });
        }
    }
}

// ── Rebuild a single cluster on a worker thread ───────────────────────────────
void World::rebuildCluster(Chunk* chunk, int ci) {
    int cx = chunk->cx, cz = chunk->cz;
    const Chunk *nx, *px, *nz, *pz;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        nx = getChunk(cx-1,cz); px = getChunk(cx+1,cz);
        nz = getChunk(cx,cz-1); pz = getChunk(cx,cz+1);
    }
    chunk->buildClusterMesh(ci, nx, px, nz, pz);
    {
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        m_uploadQueue.push_back({ chunk, ci });
    }
}

// ── Trigger re-mesh on neighbouring chunks' border clusters ──────────────────
// ci == -1 means all clusters; otherwise only the cluster that borders this one
void World::triggerNeighbourRemesh(int cx, int cz, int /*ci*/) {
    static const int dirs[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
    std::vector<std::pair<Chunk*,int>> work;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        for (auto& d : dirs) {
            Chunk* nb = getChunk(cx+d[0], cz+d[1]);
            if (!nb || !nb->generated.load(std::memory_order_acquire)) continue;
            // Only remesh if currently READY (not mid-mesh)
            for (int c2 = 0; c2 < CLUSTER_STACK; ++c2) {
                if (nb->clusterState[c2].load(std::memory_order_acquire) == ClusterState::READY)
                    work.push_back({ nb, c2 });
            }
        }
    }
    // C++17: structured binding variables can't be captured directly in lambdas.
    // Copy each pair into plain local variables first.
    for (auto& [nb, c2] : work) {
        Chunk* nb_copy = nb;
        int    c2_copy = c2;
        enqueueTask([this, nb_copy, c2_copy]{ rebuildCluster(nb_copy, c2_copy); });
    }
}

// ── GPU upload (GL thread): drain upload queue into MegaBuffer ────────────────
void World::updateGPU() {
    int budget = m_thermal.maxUploadBudget();

    std::vector<UploadTask> tasks;
    {
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        int n = std::min(budget, (int)m_uploadQueue.size());
        tasks.assign(m_uploadQueue.end() - n, m_uploadQueue.end());
        m_uploadQueue.resize(m_uploadQueue.size() - n);
    }

    for (auto& task : tasks) {
        Chunk* ch = task.chunk;
        int    ci = task.ci;

        // Only process if still MESHED
        if (ch->clusterState[ci].load(std::memory_order_acquire) != ClusterState::MESHED)
            continue;

        std::lock_guard<std::mutex> lk(ch->clusterMutex[ci]);
        auto& faces = ch->clusterFaces[ci];

        // Free old GPU allocation if any
        // (GPU slot tracked inline in Chunk — extend Chunk to hold GPUSlots)
        // For simplicity we store the offset in a parallel array here.
        // We embed it directly in the UploadTask by checking clusterGPUOffset.
        // (See Renderer for the actual draw-time offset retrieval.)

        // Allocate space in mega-buffer
        uint32_t nFaces = (uint32_t)faces.size();

        // Upload to MegaBuffer (glBufferSubData)
        if (nFaces > 0) {
            uint32_t offset = m_mega.alloc(nFaces);
            if (offset != MEGA_INVALID) {
                m_mega.upload(offset, faces.data(), nFaces);
                // Store GPU slot back in chunk (we need per-cluster GPU tracking)
                // The Renderer queries this via getClusterGPUOffset()
                ch->clusterGPUOffset[ci] = offset;
                ch->clusterFaceCount[ci] = nFaces;
            } else {
                LOGE("MegaBuffer full! Used %u / %u faces",
                     m_mega.usedFaces(), m_mega.totalFaces());
                ch->clusterGPUOffset[ci] = MEGA_INVALID;
                ch->clusterFaceCount[ci] = 0;
            }
        } else {
            ch->clusterGPUOffset[ci] = MEGA_INVALID;
            ch->clusterFaceCount[ci] = 0;
        }

        // Free CPU memory
        faces.clear();
        faces.shrink_to_fit();

        ch->clusterState[ci].store(ClusterState::READY, std::memory_order_release);
    }
}

// ── Evict all GPU allocations for a chunk ─────────────────────────────────────
void World::evictChunk(Chunk* chunk) {
    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
        if (chunk->clusterGPUOffset[ci] != MEGA_INVALID) {
            m_mega.free(chunk->clusterGPUOffset[ci], chunk->clusterFaceCount[ci]);
            chunk->clusterGPUOffset[ci] = MEGA_INVALID;
            chunk->clusterFaceCount[ci] = 0;
        }
    }
}

// ── Render ────────────────────────────────────────────────────────────────────
void World::render(const Frustum& frustum) {
    int visible = 0;
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    for (auto& kv : m_chunks) {
        Chunk* ch = kv.second.get();

        // Chunk-level frustum cull
        float mnX,mnY,mnZ,mxX,mxY,mxZ;
        ch->getAABB(mnX,mnY,mnZ,mxX,mxY,mxZ);
        if (!frustum.testAABB({mnX,mnY,mnZ},{mxX,mxY,mxZ})) continue;

        // Per-cluster render
        for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
            if (ch->clusterState[ci].load(std::memory_order_acquire) != ClusterState::READY)
                continue;
            uint32_t offset = ch->clusterGPUOffset[ci];
            uint32_t count  = ch->clusterFaceCount[ci];
            if (offset == MEGA_INVALID || count == 0) continue;

            // World origin for this cluster (passed as uniform or vertex attrib)
            // Renderer sets uClusterOrigin per cluster before issuing the draw.
            // This call is just the per-cluster draw; Renderer drives the loop.
            // We expose the data via a callback pattern — Renderer calls
            // world.renderClusters(frustum, drawFn) in Renderer.cpp.
            // For the refactored design, Renderer iterates this same loop.
            // Placeholder: emitting one instanced draw per cluster.
            // Actual instancing is done in Renderer::render().
            ++visible;
            (void)offset; (void)count;
        }
    }
    m_lastVisible = visible;
}

// ── Accessors ─────────────────────────────────────────────────────────────────
Chunk* World::getChunk(int cx, int cz) const {
    auto it = m_chunks.find({cx,cz});
    return it != m_chunks.end() ? it->second.get() : nullptr;
}

uint8_t World::getBlock(int wx, int wy, int wz) const {
    if (wy<0 || wy>=CHUNK_H) return BLOCK_AIR;
    int cx = (int)floorf((float)wx / CHUNK_W);
    int cz = (int)floorf((float)wz / CHUNK_D);
    int lx = wx - cx*CHUNK_W, lz = wz - cz*CHUNK_D;
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    const Chunk* ch = getChunk(cx,cz);
    return ch ? ch->getBlock(lx,wy,lz) : BLOCK_AIR;
}

int World::getChunkCount() const {
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    return (int)m_chunks.size();
}
