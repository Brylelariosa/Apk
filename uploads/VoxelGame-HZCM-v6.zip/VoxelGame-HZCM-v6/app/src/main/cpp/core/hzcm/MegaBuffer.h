#pragma once
// ============================================================================
// HZCM v3 — MegaBuffer.h
// Single large GL_ARRAY_BUFFER shared by ALL clusters.
//
// Design goals (Android / tile-based GPU):
//   • Zero per-chunk VBO bind overhead: one VBO, offset-based draw
//   • GL_DYNAMIC_DRAW + glBufferSubData for streaming uploads
//   • Simple power-of-2 free-list allocator; O(1) alloc / free
//   • No heap allocation after init — all metadata is inline arrays
//
// Capacity: MEGA_FACE_CAPACITY PackedFaces (8 bytes each)
//   Default 400 000 faces = 3.2 MB — comfortably fits in device VRAM.
//   At 6 faces/chunk × 169 chunks (render r=6) each with ~500 avg faces
//   → ~507 000 worst-case visible faces; 400 K is a conservative working set.
// ============================================================================
#ifndef GLES3_GL3_H_STUB
#include <GLES3/gl3.h>
#endif
#include <cstdint>
#include <cstring>
#include <android/log.h>
#include "ClusterTypes.h"

// Tune these at build time via CMake if needed
#ifndef MEGA_FACE_CAPACITY
#define MEGA_FACE_CAPACITY 400000
#endif

// Allocation granularity: all allocations are rounded up to this many faces.
// 64 faces × 8 bytes = 512 bytes → 1 cache-line on ARM.
static constexpr uint32_t MEGA_BLOCK_FACES = 64u;
static constexpr uint32_t MEGA_TOTAL_BLOCKS =
    (MEGA_FACE_CAPACITY + MEGA_BLOCK_FACES - 1) / MEGA_BLOCK_FACES;

class MegaBuffer {
public:
    MegaBuffer() = default;
    ~MegaBuffer() { destroy(); }

    // Call once on GL thread after EGL context creation
    void init();
    void destroy();

    // Allocate `numFaces` faces. Returns MEGA_INVALID on failure.
    // Returned offset is in PackedFace units.
    uint32_t alloc(uint32_t numFaces);

    // Release a previous allocation.
    void free(uint32_t offsetFaces, uint32_t numFaces);

    // Upload CPU face data into the buffer. Must own an alloc at offsetFaces.
    void upload(uint32_t offsetFaces, const PackedFace* data, uint32_t numFaces);

    // Bind for rendering (call once before the draw loop)
    void bind() const { glBindBuffer(GL_ARRAY_BUFFER, m_vbo); }

    GLuint vbo() const { return m_vbo; }

    // Diagnostics
    uint32_t usedFaces()  const { return m_usedBlocks  * MEGA_BLOCK_FACES; }
    uint32_t totalFaces() const { return MEGA_TOTAL_BLOCKS * MEGA_BLOCK_FACES; }

private:
    GLuint   m_vbo        = 0;

    // Flat free bitmap: 1 bit per block, bit=1 → free
    // MEGA_TOTAL_BLOCKS / 32 uint32_t words
    static constexpr uint32_t BM_WORDS = (MEGA_TOTAL_BLOCKS + 31) / 32;
    uint32_t m_freeBits[BM_WORDS] = {};

    uint32_t m_usedBlocks = 0;

    // Find a contiguous run of `nBlocks` free blocks. Returns block index or
    // MEGA_TOTAL_BLOCKS on failure. Simple first-fit scan — clusters are small
    // enough that fragmentation is not a concern at runtime.
    uint32_t findFree(uint32_t nBlocks) const;

    void markUsed(uint32_t blockStart, uint32_t nBlocks);
    void markFree(uint32_t blockStart, uint32_t nBlocks);
};

// ── Inline implementation (header-only for simplicity; one TU) ───────────────
inline void MegaBuffer::init() {
    glGenBuffers(1, &m_vbo);
    glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
    glBufferData(GL_ARRAY_BUFFER,
                 (GLsizeiptr)(MEGA_TOTAL_BLOCKS * MEGA_BLOCK_FACES * sizeof(PackedFace)),
                 nullptr,
                 GL_DYNAMIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    // Mark all blocks free
    memset(m_freeBits, 0xFF, sizeof(m_freeBits));
    m_usedBlocks = 0;

    __android_log_print(ANDROID_LOG_INFO, "MegaBuffer",
        "Init: %u blocks × %u faces = %u faces (%.1f MB)",
        MEGA_TOTAL_BLOCKS, MEGA_BLOCK_FACES,
        MEGA_TOTAL_BLOCKS * MEGA_BLOCK_FACES,
        (float)(MEGA_TOTAL_BLOCKS * MEGA_BLOCK_FACES * sizeof(PackedFace)) / (1024.f*1024.f));
}

inline void MegaBuffer::destroy() {
    if (m_vbo) { glDeleteBuffers(1, &m_vbo); m_vbo = 0; }
}

inline uint32_t MegaBuffer::findFree(uint32_t nBlocks) const {
    uint32_t run = 0, runStart = 0;
    for (uint32_t w = 0; w < BM_WORDS; ++w) {
        uint32_t bits = m_freeBits[w];
        if (bits == 0u) { run = 0; continue; }
        for (int b = 0; b < 32; ++b) {
            uint32_t idx = w * 32 + (uint32_t)b;
            if (idx >= MEGA_TOTAL_BLOCKS) goto done;
            if (bits & (1u << b)) {
                if (run == 0) runStart = idx;
                ++run;
                if (run >= nBlocks) return runStart;
            } else {
                run = 0;
            }
        }
    }
done:
    return MEGA_TOTAL_BLOCKS; // failure
}

inline void MegaBuffer::markUsed(uint32_t blockStart, uint32_t nBlocks) {
    for (uint32_t i = blockStart; i < blockStart + nBlocks; ++i)
        m_freeBits[i / 32] &= ~(1u << (i % 32));
    m_usedBlocks += nBlocks;
}

inline void MegaBuffer::markFree(uint32_t blockStart, uint32_t nBlocks) {
    for (uint32_t i = blockStart; i < blockStart + nBlocks; ++i)
        m_freeBits[i / 32] |= (1u << (i % 32));
    m_usedBlocks -= nBlocks;
}

inline uint32_t MegaBuffer::alloc(uint32_t numFaces) {
    uint32_t nBlocks = (numFaces + MEGA_BLOCK_FACES - 1) / MEGA_BLOCK_FACES;
    if (nBlocks == 0) nBlocks = 1;
    uint32_t blockIdx = findFree(nBlocks);
    if (blockIdx >= MEGA_TOTAL_BLOCKS) return MEGA_INVALID;
    markUsed(blockIdx, nBlocks);
    return blockIdx * MEGA_BLOCK_FACES;
}

inline void MegaBuffer::free(uint32_t offsetFaces, uint32_t numFaces) {
    if (offsetFaces == MEGA_INVALID) return;
    uint32_t blockStart = offsetFaces / MEGA_BLOCK_FACES;
    uint32_t nBlocks    = (numFaces + MEGA_BLOCK_FACES - 1) / MEGA_BLOCK_FACES;
    if (nBlocks == 0) nBlocks = 1;
    markFree(blockStart, nBlocks);
}

inline void MegaBuffer::upload(uint32_t offsetFaces,
                                const PackedFace* data, uint32_t numFaces) {
    glBindBuffer(GL_ARRAY_BUFFER, m_vbo);
    glBufferSubData(GL_ARRAY_BUFFER,
                    (GLintptr)(offsetFaces * sizeof(PackedFace)),
                    (GLsizeiptr)(numFaces  * sizeof(PackedFace)),
                    data);
}
