#pragma once
// ============================================================================
// HZCM v3 — ThermalManager.h
// Adaptive rebuild throttling for Android thermal / battery constraints.
//
// Strategy:
//   • Tracks a 16-sample exponential moving average of frame-time.
//   • Maps thermal "pressure" to a cluster rebuild budget per frame.
//   • Under sustained load, reduces budget → fewer rebuilds → less CPU heat.
//   • Recovers budget gradually when frame times drop.
//
// No OS thermal API needed — frame-time is a proxy good enough for mobile.
// ============================================================================
#include <cstdint>
#include <algorithm>
#include <cmath>

class ThermalManager {
public:
    // ── Configuration ────────────────────────────────────────────────────────
    static constexpr float TARGET_FPS        = 60.f;
    static constexpr float TARGET_FRAME_MS   = 1000.f / TARGET_FPS; // 16.67 ms
    static constexpr float WARM_THRESHOLD_MS = 20.f;   // 50 fps → "warm"
    static constexpr float HOT_THRESHOLD_MS  = 28.f;   // 35 fps → "hot"
    static constexpr float COOL_THRESHOLD_MS = 17.5f;  // 57 fps → back to normal

    static constexpr int   MAX_REBUILDS_COOL = 8;   // clusters/frame when cool
    static constexpr int   MAX_REBUILDS_WARM = 4;   // warm
    static constexpr int   MAX_REBUILDS_HOT  = 2;   // hot
    static constexpr int   MAX_UPLOADS_COOL  = 6;   // GPU uploads/frame
    static constexpr int   MAX_UPLOADS_WARM  = 3;
    static constexpr int   MAX_UPLOADS_HOT   = 2;

    // ── EMA alpha (higher → more responsive, lower → more stable) ────────────
    static constexpr float EMA_ALPHA = 0.125f;  // 8-sample effective window

    // ─────────────────────────────────────────────────────────────────────────
    void update(float dt_seconds) {
        float ms = dt_seconds * 1000.f;
        if (m_ema < 0.f) {
            m_ema = ms;
        } else {
            m_ema = m_ema + EMA_ALPHA * (ms - m_ema);
        }

        // Thermal state machine with hysteresis
        switch (m_state) {
            case COOL:
                if (m_ema > WARM_THRESHOLD_MS) m_state = WARM;
                break;
            case WARM:
                if (m_ema > HOT_THRESHOLD_MS)  m_state = HOT;
                if (m_ema < COOL_THRESHOLD_MS) m_state = COOL;
                break;
            case HOT:
                if (m_ema < COOL_THRESHOLD_MS) m_state = WARM;
                break;
        }
    }

    // Max cluster remeshes allowed this frame (CPU work budget)
    int maxRebuildBudget() const {
        switch (m_state) {
            case HOT:  return MAX_REBUILDS_HOT;
            case WARM: return MAX_REBUILDS_WARM;
            default:   return MAX_REBUILDS_COOL;
        }
    }

    // Max GL uploads (glBufferSubData calls) allowed this frame
    int maxUploadBudget() const {
        switch (m_state) {
            case HOT:  return MAX_UPLOADS_HOT;
            case WARM: return MAX_UPLOADS_WARM;
            default:   return MAX_UPLOADS_COOL;
        }
    }

    // [0.0 = cool .. 1.0 = critically hot] — for debug HUD / render scaling
    float thermalPressure() const {
        float t = (m_ema - TARGET_FRAME_MS) / (HOT_THRESHOLD_MS - TARGET_FRAME_MS);
        return std::max(0.f, std::min(1.f, t));
    }

    float frameEmaMs() const { return m_ema; }

    enum State { COOL = 0, WARM = 1, HOT = 2 };
    State thermalState() const { return m_state; }

private:
    float m_ema   = -1.f;   // negative = uninitialised
    State m_state = COOL;
};
