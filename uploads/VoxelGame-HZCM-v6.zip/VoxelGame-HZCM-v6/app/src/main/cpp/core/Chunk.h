#pragma once
// ============================================================================
// HZCM v3 — Chunk.h
// A 16×64×16 block column divided into 4 × 16³ vertical clusters.
//
// Voxel layout: XYZ order  index(x,y,z) = x + 16*(y + 64*z)
// (XYZ is optimal for the greedy mesher's Y sweeps; it keeps all Y voxels
//  for a given (x,z) column contiguous in memory → good cache behavior.)
//
// Per-cluster CPU face buffers are filled by ClusterMesher.
// Per-cluster GPU allocations live in the MegaBuffer (owned by Renderer).
// ============================================================================
#include <cstdint>
#include <vector>
#include <atomic>
#include <mutex>
#include <cstring>
#include "Block.h"
#include "Noise.h"
#include "hzcm/ClusterTypes.h"
#include "hzcm/ClusterMesher.h"

class Chunk {
public:
    // ── Identity ──────────────────────────────────────────────────────────────
    int cx = 0, cz = 0;   // chunk grid coordinates (block coords = cx*16, cz*16)

    // ── Block storage — XYZ flat, uint8_t ────────────────────────────────────
    // Total: 16×64×16 = 16 384 bytes per chunk
    uint8_t blocks[CHUNK_W * CHUNK_H * CHUNK_D];

    // ── Per-cluster CPU face buffers ──────────────────────────────────────────
    std::vector<PackedFace> clusterFaces[CLUSTER_STACK];
    std::mutex              clusterMutex[CLUSTER_STACK];  // protects clusterFaces

    // ── Per-cluster states ────────────────────────────────────────────────────
    std::atomic<ClusterState> clusterState[CLUSTER_STACK];

    // GPU residency: written and read on GL thread only
    uint32_t clusterGPUOffset[CLUSTER_STACK];
    uint32_t clusterFaceCount[CLUSTER_STACK];

    // ── Whole-chunk generation state ─────────────────────────────────────────
    // true once generate() has completed (block data valid)
    std::atomic<bool> generated{false};

    // ─────────────────────────────────────────────────────────────────────────
    Chunk(int cx, int cz);
    ~Chunk() = default;

    // ── Block access (bounds-checked, thread-safe by data layout) ────────────
    inline uint8_t getBlock(int x, int y, int z) const {
        if ((unsigned)x >= (unsigned)CHUNK_W ||
            (unsigned)y >= (unsigned)CHUNK_H ||
            (unsigned)z >= (unsigned)CHUNK_D)
            return BLOCK_AIR;
        return blocks[x + CHUNK_W * (y + CHUNK_H * z)];
    }
    inline void setBlock(int x, int y, int z, uint8_t t) {
        if ((unsigned)x >= (unsigned)CHUNK_W ||
            (unsigned)y >= (unsigned)CHUNK_H ||
            (unsigned)z >= (unsigned)CHUNK_D) return;
        blocks[x + CHUNK_W * (y + CHUNK_H * z)] = t;
    }

    // ── Terrain generation (worker thread) ───────────────────────────────────
    void generate(const Noise& noise);

    // ── Cluster voxel accessor ────────────────────────────────────────────────
    // Returns pointer to the start of cluster `ci`'s voxel slice (64×16 voxels
    // in XY, 16 in Z).  Used by ClusterMesher to reference adjacent cluster
    // data without copying.
    // Layout: blocks[x + 16*(y + 64*z)], cluster ci covers y = ci*16 .. ci*16+15
    // We build a 16³ copy into a local temp buffer for ClusterMesher.
    void extractClusterVoxels(int ci, uint8_t out[CL_VOLUME]) const;

    // ── Cluster meshing (worker thread) ──────────────────────────────────────
    void buildClusterMesh(int ci,
                          const Chunk* nx, const Chunk* px,
                          const Chunk* nz, const Chunk* pz);

    // ── AABB ──────────────────────────────────────────────────────────────────
    void getAABB(float& mnX, float& mnY, float& mnZ,
                 float& mxX, float& mxY, float& mxZ) const;

    // ── Cluster world origin ───────────────────────────────────────────────────
    inline int clusterWorldX(int /*ci*/) const { return cx * CHUNK_W; }
    inline int clusterWorldY(int ci)     const { return ci * CL_SIZE;  }
    inline int clusterWorldZ(int /*ci*/) const { return cz * CHUNK_D; }
};
