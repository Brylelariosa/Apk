#pragma once
// ============================================================================
// HZCM v3 — ClusterTypes.h
// Hierarchical Zoned Cluster Meshing — core data types
//
// Android / GLES 3.0 / ARM-only
// ============================================================================
#include <cstdint>
#include <cstddef>
#include <atomic>

// ── Dimensions ───────────────────────────────────────────────────────────────
static constexpr int CHUNK_W       = 16;
static constexpr int CHUNK_H       = 64;
static constexpr int CHUNK_D       = 16;
static constexpr int CL_SIZE       = 16;                       // cluster side
static constexpr int CL_VOLUME     = CL_SIZE * CL_SIZE * CL_SIZE; // 4096
static constexpr int CLUSTER_STACK = CHUNK_H / CL_SIZE;        // 4 clusters/chunk

// ── PackedFace — 8 bytes per greedy-merged visible face ──────────────────────
//
// GPU reads this as a uvec2 per-instance in the vertex shader.
// The vertex shader expands 1 PackedFace → 4 quad corners (6 vertices).
//
// Word 0  [geom]
//  bits  2:0   face direction   (0=+X 1=-X 2=+Y 3=-Y 4=+Z 5=-Z)
//  bits  6:3   ox  cluster-local X of greedy quad origin (0–15)
//  bits 10:7   oy  cluster-local Y of greedy quad origin (0–15)
//  bits 14:11  oz  cluster-local Z of greedy quad origin (0–15)
//  bits 18:15  span0-1  extent in 1st tangent axis (0→1 .. 15→16)
//  bits 22:19  span1-1  extent in 2nd tangent axis (0→1 .. 15→16)
//  bits 31:23  [free — AO bitmask in future versions]
//
// Word 1  [material]
//  bits  7:0   block type (0–255)
//  bits 15:8   AO corners (4 × 2-bit: 0=dark .. 3=full)
//              corner 0 = bits 9:8, corner 1 = 11:10, etc.
//  bits 31:16  [free]
// ─────────────────────────────────────────────────────────────────────────────
struct PackedFace {
    uint32_t geom;
    uint32_t mat;
};
static_assert(sizeof(PackedFace) == 8, "PackedFace size");

// Tangent axes per face direction (used by both CPU mesher and GPU shader doc)
// face  axis  u=(axis+1)%3  v=(axis+2)%3
//  0+X   0       1(Y)          2(Z)
//  1-X   0       1(Y)          2(Z)
//  2+Y   1       2(Z)          0(X)
//  3-Y   1       2(Z)          0(X)
//  4+Z   2       0(X)          1(Y)
//  5-Z   2       0(X)          1(Y)

inline PackedFace makeFace(int faceDir,
                            int ox, int oy, int oz,
                            int span0, int span1,
                            int blockType,
                            uint8_t ao0=3, uint8_t ao1=3,
                            uint8_t ao2=3, uint8_t ao3=3)
{
    PackedFace f;
    f.geom = static_cast<uint32_t>(
        (faceDir         &  7u)        |
        ((ox             & 15u) <<  3u) |
        ((oy             & 15u) <<  7u) |
        ((oz             & 15u) << 11u) |
        (((span0 - 1)    & 15u) << 15u) |
        (((span1 - 1)    & 15u) << 19u) );

    f.mat = static_cast<uint32_t>(
        (blockType       & 255u)        |
        ((ao0            &   3u) <<  8u) |
        ((ao1            &   3u) << 10u) |
        ((ao2            &   3u) << 12u) |
        ((ao3            &   3u) << 14u) );
    return f;
}

// ── MegaBuffer slot address ───────────────────────────────────────────────────
static constexpr uint32_t MEGA_INVALID = 0xFFFF'FFFFu;

// ── ClusterGPUSlot — GPU residency record for one 16³ cluster ────────────────
struct ClusterGPUSlot {
    uint32_t megaOffset = MEGA_INVALID;   // index into mega-VBO (units: PackedFace)
    uint32_t faceCount  = 0;
    bool     resident   = false;
};

// ── Cluster lifecycle states ──────────────────────────────────────────────────
enum class ClusterState : uint8_t {
    EMPTY    = 0,   // no block data
    DIRTY    = 1,   // block data ready, needs meshing
    MESHED   = 2,   // CPU face buffer ready, needs GPU upload
    READY    = 3,   // GPU-resident, renderable
};

// ── Cluster descriptor (SoA-friendly, cache-line aligned) ────────────────────
// One per 16³ cluster (4 per Chunk)
struct alignas(64) ClusterDesc {
    std::atomic<ClusterState> state{ClusterState::EMPTY};
    ClusterGPUSlot            gpu;
    uint32_t                  dirtyGeneration = 0;  // bump to force rebuild
    int                       worldX = 0;           // cluster world origin X
    int                       worldY = 0;           // cluster world origin Y
    int                       worldZ = 0;           // cluster world origin Z
    uint8_t                   pad[64 - sizeof(std::atomic<ClusterState>)
                                    - sizeof(ClusterGPUSlot)
                                    - sizeof(uint32_t)
                                    - 3*sizeof(int)];
};
// Relax size constraint — struct is padded to 64 for cache alignment
