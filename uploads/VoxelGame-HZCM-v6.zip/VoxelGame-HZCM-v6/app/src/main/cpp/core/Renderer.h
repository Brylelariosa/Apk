#pragma once
// ============================================================================
// HZCM v3 — Renderer.h
// GPU face-expansion renderer.  The vertex shader reconstructs all geometry
// from compact 8-byte PackedFace descriptors stored in the MegaBuffer.
//
// Draw call model:
//   For each resident cluster:
//     glUniform3iv(uClusterOrigin, 1, origin);
//     glDrawArrays(GL_TRIANGLES, offset*6, faceCount*6);
//
// 6 vertices per face (2 triangles, no index buffer needed).
// The vertex shader uses gl_VertexID % 6 to select the corner.
// ============================================================================
#ifndef GLES3_GL3_H_STUB
#include <GLES3/gl3.h>
#endif
#include "Camera.h"
#include "World.h"

class Renderer {
public:
    Camera camera;
    World  world;
    bool   initialized = false;

    void init();
    void resize(int width, int height);
    void render(float dt);
    ~Renderer();

private:
    // ── Main cluster shader ───────────────────────────────────────────────────
    GLuint m_prog      = 0;
    GLint  m_uMVP      = -1;
    GLint  m_uCamPos   = -1;
    GLint  m_uOrigin   = -1;    // cluster world origin (ivec3)

    // ── HUD shader ───────────────────────────────────────────────────────────
    GLuint m_hudProg   = 0;
    GLuint m_hudVao    = 0;
    GLuint m_hudVbo    = 0;

    // ── Dummy VAO for attribute-less draws ────────────────────────────────────
    // GLES 3.0 requires a VAO bound. We use one global VAO for all cluster
    // draws; the actual geometry data is fetched via texelFetch / VBO offset.
    GLuint m_clusterVao = 0;

    static constexpr float SKY_R = 0.52f, SKY_G = 0.77f, SKY_B = 0.95f;

    GLuint compileShader(GLenum type, const char* src);
    GLuint linkProgram(GLuint vert, GLuint frag);
    void   initHUD();
    void   renderHUD();
    void   renderClusters(const Frustum& frustum);
};
