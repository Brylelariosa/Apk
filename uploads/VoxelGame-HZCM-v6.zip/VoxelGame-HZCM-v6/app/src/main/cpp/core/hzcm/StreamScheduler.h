#pragma once
// ============================================================================
// HZCM v3 — StreamScheduler.h
// Predictive chunk streaming — prioritise chunks in the direction of travel.
//
// Design:
//   • Each frame, integrate camera velocity into a "look-ahead" position.
//   • Chunks closer to the look-ahead position get higher priority.
//   • Priority also weighs camera-forward dot product so side chunks are
//     de-prioritised relative to forward chunks.
//   • Output: a sorted list of (cx,cz) coords for the world to schedule.
//
// Entirely CPU-side, no GL calls. Header-only.
// ============================================================================
#include <cmath>
#include <vector>
#include <algorithm>

struct ChunkPriority {
    int   cx, cz;
    float priority;   // higher = load sooner
};

class StreamScheduler {
public:
    // ── Tuning ───────────────────────────────────────────────────────────────
    // Look-ahead distance: how many seconds ahead we predict
    static constexpr float LOOKAHEAD_SECONDS = 2.5f;

    // Weight for camera-forward alignment (vs. raw distance)
    static constexpr float FORWARD_BIAS = 0.5f;

    // ─────────────────────────────────────────────────────────────────────────
    // Call every frame to feed current camera state
    void update(float camX, float camZ,
                float velX, float velZ,
                float fwdX, float fwdZ)
    {
        m_camX = camX;  m_camZ = camZ;
        m_velX = velX;  m_velZ = velZ;
        m_fwdX = fwdX;  m_fwdZ = fwdZ;

        // Smooth velocity with EMA to reduce jitter
        m_smoothVelX = m_smoothVelX * 0.85f + velX * 0.15f;
        m_smoothVelZ = m_smoothVelZ * 0.85f + velZ * 0.15f;
    }

    // Sort a list of candidate (cx,cz) by priority. Highest first.
    void sortByPriority(std::vector<ChunkPriority>& candidates) const {
        float lookX = m_camX + m_smoothVelX * LOOKAHEAD_SECONDS;
        float lookZ = m_camZ + m_smoothVelZ * LOOKAHEAD_SECONDS;

        // Normalise forward vector for dot product
        float fwdLen = sqrtf(m_fwdX*m_fwdX + m_fwdZ*m_fwdZ);
        float nfX = (fwdLen > 0.001f) ? m_fwdX / fwdLen : 0.f;
        float nfZ = (fwdLen > 0.001f) ? m_fwdZ / fwdLen : 0.f;

        for (auto& cp : candidates) {
            // World-space centre of this chunk
            float cx = (float)(cp.cx * 16) + 8.f;
            float cz = (float)(cp.cz * 16) + 8.f;

            // Distance to look-ahead point (lower → higher priority)
            float dx = cx - lookX, dz = cz - lookZ;
            float dist = sqrtf(dx*dx + dz*dz) + 0.001f;

            // Direction to chunk, dot with camera forward
            float toCx = dx / dist, toCz = dz / dist;
            float dot  = toCx * nfX + toCz * nfZ;   // [-1,1]
            float align = (dot + 1.f) * 0.5f;         // [0,1]

            // Priority: inverse distance + forward alignment bias
            cp.priority = (1.f / dist) + FORWARD_BIAS * align;
        }

        std::sort(candidates.begin(), candidates.end(),
                  [](const ChunkPriority& a, const ChunkPriority& b){
                      return a.priority > b.priority;
                  });
    }

    // Simple helper: given camera chunk position, build candidate list in ring
    // from innerRadius..outerRadius (Chebyshev distance)
    static void buildCandidates(int camCX, int camCZ,
                                  int innerR, int outerR,
                                  std::vector<ChunkPriority>& out)
    {
        out.clear();
        for (int dz = -outerR; dz <= outerR; ++dz) {
            for (int dx = -outerR; dx <= outerR; ++dx) {
                int dist = std::max(std::abs(dx), std::abs(dz));
                if (dist < innerR || dist > outerR) continue;
                out.push_back({ camCX + dx, camCZ + dz, 0.f });
            }
        }
    }

private:
    float m_camX = 0.f, m_camZ = 0.f;
    float m_velX = 0.f, m_velZ = 0.f;
    float m_fwdX = 0.f, m_fwdZ = 1.f;
    float m_smoothVelX = 0.f, m_smoothVelZ = 0.f;
};
