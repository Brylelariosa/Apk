// ============================================================================
// HZCM v3 — Renderer.cpp
// GPU face-expansion renderer.
//
// CRITICAL ANDROID / TILE-GPU DECISIONS
// ──────────────────────────────────────
// 1. ONE VBO (MegaBuffer). Eliminates per-chunk buffer bind overhead.
//    Tile-based GPUs (Adreno/Mali) pay a real cost for each new buffer bind.
//
// 2. GL_TRIANGLES, no index buffer.  6 vertices per face, reconstructed
//    by gl_VertexID in the vertex shader.  Strips index-buffer bandwidth
//    and removes the separate EBO entirely.
//
// 3. No per-vertex float attributes.  The VBO contains PackedFace (8 bytes).
//    The shader decodes position, normal, UV, AO from two uint32_t words.
//    This cuts per-face bandwidth from ~96 bytes (6×16-byte verts) to 8 bytes
//    — a 12× reduction.  On bandwidth-limited mobile this is enormous.
//
// 4. Per-cluster origin uniform.  Cluster world origin is a 3-int uniform
//    (12 bytes), set once per cluster draw.  All vertex positions are 4-bit
//    integers expanded in the shader → no floating-point position storage.
//
// 5. Face colours encoded as block-type lookup in the shader.  No per-face
//    colour storage; the shader reads block type (8 bits) and face direction
//    (3 bits) and returns a hardcoded colour.  Zero memory vs. float RGB.
//
// ============================================================================
#include "Renderer.h"
#include <android/log.h>
#include <cstring>
#include <cmath>
#include <shared_mutex>

#define TAG  "HZCMRenderer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ============================================================================
// Vertex shader — GPU face expansion (GLES 3.0 compatible)
//
// Each face is one INSTANCE. The two PackedFace uint32 words arrive as
// instanced vertex attributes (divisor=1), set up by renderClusters().
// gl_VertexID (0-5) selects the quad corner; gl_InstanceID is the face.
//
// This replaces the original TBO / isamplerBuffer approach which requires
// GL_EXT_texture_buffer — unavailable on most GLES 3.0 devices.
// ============================================================================
static const char* VERT_SRC = R"(#version 300 es
precision highp float;
precision highp int;

// ── PackedFace words — one per instance (face) ───────────────────────────────
layout(location = 0) in uint aGeom;  // geometry word
layout(location = 1) in uint aMat;   // material word

// Cluster world origin (block units)
uniform ivec3 uClusterOrigin;

// MVP matrix
uniform mat4 uMVP;

// Camera world position (for fog)
uniform vec3 uCamPos;

out vec3  vColor;
out float vFog;

// ── Corner index table ────────────────────────────────────────────────────────
// Two triangles per quad.
// Front faces (even faceDir, positive normal): CCW = [0,1,2] [0,2,3]
// Back  faces (odd  faceDir, negative normal): reversed CCW = [0,2,1] [0,3,2]
const int CORNER_MAP_F[6] = int[6](0,1,2, 0,2,3);
const int CORNER_MAP_B[6] = int[6](0,2,1, 0,3,2);

// s/t/n axis indices per face direction (0=X,1=Y,2=Z)
// +X=0  -X=1  +Y=2  -Y=3  +Z=4  -Z=5
const int S_AXIS[6] = int[6](1,1, 2,2, 0,0);
const int T_AXIS[6] = int[6](2,2, 0,0, 1,1);
const int N_AXIS[6] = int[6](0,0, 1,1, 2,2);

// +1 = face visible from + direction; -1 from – direction
const float N_SIGN[6] = float[6](1.,-1., 1.,-1., 1.,-1.);

// Per-face directional light multipliers
const float FACE_LIGHT[6] = float[6](0.65, 0.65, 1.0, 0.35, 0.80, 0.80);

// ── Block colour lookup ───────────────────────────────────────────────────────
vec3 blockColor(int btype, int fdir) {
    int fg = (fdir == 2) ? 1 : (fdir == 3) ? 2 : 0;
    if (btype == 1) { // GRASS
        if (fg==1) return vec3(0.29,0.68,0.18);
        return vec3(0.55,0.38,0.22);
    }
    if (btype == 2) return vec3(0.55,0.38,0.22); // DIRT
    if (btype == 3) return vec3(0.50,0.50,0.50); // STONE
    if (btype == 4) return vec3(0.89,0.82,0.56); // SAND
    if (btype == 5) { // SNOW
        if (fg==1) return vec3(0.96,0.96,1.00);
        return vec3(0.82,0.82,0.82);
    }
    if (btype == 6) { // WOOD
        if (fg>=1) return vec3(0.52,0.39,0.25);
        return vec3(0.45,0.32,0.18);
    }
    if (btype == 7) return vec3(0.20,0.52,0.12); // LEAVES
    if (btype == 8) return vec3(0.18,0.45,0.78); // WATER
    if (btype == 9) return vec3(0.55,0.52,0.50); // GRAVEL
    return vec3(1.0, 0.0, 1.0);                  // unknown → magenta
}

void main() {
    // ── Decode packed words from instanced attributes ─────────────────────────
    // faceDir must be decoded first so we can pick the correct winding order.
    int geom = int(aGeom);
    int mat  = int(aMat);

    int faceDir = geom & 7;

    // ── Corner index ──────────────────────────────────────────────────────────
    // Even faceDir = positive normal (+X/+Y/+Z) → standard CCW winding.
    // Odd  faceDir = negative normal (-X/-Y/-Z) → reversed winding so the
    // reconstructed normal still faces outward and passes back-face culling.
    int vi = gl_VertexID % 6;
    int cornerIdx = ((faceDir & 1) == 0) ? CORNER_MAP_F[vi] : CORNER_MAP_B[vi];
    int ox      = (geom >>  3) & 15;
    int oy      = (geom >>  7) & 15;
    int oz      = (geom >> 11) & 15;
    int span0   = ((geom >> 15) & 15) + 1;
    int span1   = ((geom >> 19) & 15) + 1;

    int btype = mat & 255;
    int ao0   = (mat >>  8) & 3;
    int ao1   = (mat >> 10) & 3;
    int ao2   = (mat >> 12) & 3;
    int ao3   = (mat >> 14) & 3;

    // ── Reconstruct corner world position ─────────────────────────────────────
    int sAxis = S_AXIS[faceDir];
    int tAxis = T_AXIS[faceDir];
    int nAxis = N_AXIS[faceDir];

    // Corner (s,t) span offsets
    float cs = float((cornerIdx == 1 || cornerIdx == 2) ? span0 : 0);
    float ct = float((cornerIdx == 2 || cornerIdx == 3) ? span1 : 0);

    vec3 lpos = vec3(float(ox), float(oy), float(oz));
    if      (sAxis == 0) lpos.x += cs;
    else if (sAxis == 1) lpos.y += cs;
    else                 lpos.z += cs;
    if      (tAxis == 0) lpos.x += ct;
    else if (tAxis == 1) lpos.y += ct;
    else                 lpos.z += ct;

    // Push the face one block in the normal direction for front faces
    if (N_SIGN[faceDir] > 0.0) {
        if      (nAxis == 0) lpos.x += 1.0;
        else if (nAxis == 1) lpos.y += 1.0;
        else                 lpos.z += 1.0;
    }

    vec3 wpos = lpos + vec3(float(uClusterOrigin.x),
                             float(uClusterOrigin.y),
                             float(uClusterOrigin.z));

    // ── AO interpolation across the quad ─────────────────────────────────────
    float aof0 = 0.35 + float(ao0) * 0.2167;
    float aof1 = 0.35 + float(ao1) * 0.2167;
    float aof2 = 0.35 + float(ao2) * 0.2167;
    float aof3 = 0.35 + float(ao3) * 0.2167;
    float su = (span0 > 0) ? cs / float(span0) : 0.0;
    float sv = (span1 > 0) ? ct / float(span1) : 0.0;
    float ao = mix(mix(aof0, aof1, su), mix(aof3, aof2, su), sv);

    // ── Final colour ──────────────────────────────────────────────────────────
    vec3 baseCol = blockColor(btype, faceDir);
    vColor = baseCol * (FACE_LIGHT[faceDir] * ao);

    // ── Fog ───────────────────────────────────────────────────────────────────
    float dist = length(wpos - uCamPos);
    vFog = clamp((dist - 90.0) / 90.0, 0.0, 1.0);

    gl_Position = uMVP * vec4(wpos, 1.0);
}
)";

static const char* FRAG_SRC = R"(#version 300 es
precision mediump float;
in  vec3  vColor;
in  float vFog;
out vec4  fragColor;
const vec3 SKY = vec3(0.52, 0.77, 0.95);
void main() {
    vec3 col = mix(vColor, SKY, vFog);
    fragColor = vec4(col, 1.0);
}
)";

// ── HUD shaders ───────────────────────────────────────────────────────────────
static const char* HUD_VERT = R"(#version 300 es
layout(location=0) in vec2 aPos;
void main() { gl_Position = vec4(aPos, 0.0, 1.0); }
)";
static const char* HUD_FRAG = R"(#version 300 es
precision mediump float;
out vec4 o; void main() { o = vec4(1.0,1.0,1.0,0.8); }
)";

// ─────────────────────────────────────────────────────────────────────────────
GLuint Renderer::compileShader(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[512]; glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        LOGE("Shader error: %s", log);
        glDeleteShader(s); return 0;
    }
    return s;
}

GLuint Renderer::linkProgram(GLuint v, GLuint f) {
    GLuint p = glCreateProgram();
    glAttachShader(p, v); glAttachShader(p, f); glLinkProgram(p);
    GLint ok; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[512]; glGetProgramInfoLog(p, sizeof(log), nullptr, log);
        LOGE("Link error: %s", log); glDeleteProgram(p); return 0;
    }
    glDeleteShader(v); glDeleteShader(f);
    return p;
}

// ── Init ──────────────────────────────────────────────────────────────────────
void Renderer::init() {
    LOGI("Renderer::init()");

    // Compile main face-expansion shader
    m_prog   = linkProgram(compileShader(GL_VERTEX_SHADER,   VERT_SRC),
                            compileShader(GL_FRAGMENT_SHADER, FRAG_SRC));
    m_uMVP    = glGetUniformLocation(m_prog, "uMVP");
    m_uCamPos = glGetUniformLocation(m_prog, "uCamPos");
    m_uOrigin = glGetUniformLocation(m_prog, "uClusterOrigin");
    // uFaceBuffer uniform removed — shader now uses instanced vertex attributes.

    // Dummy VAO for cluster draws
    glGenVertexArrays(1, &m_clusterVao);

    // MegaBuffer init
    world.megaBuffer().init();

    // HUD
    initHUD();

    // GL state — optimised for tile-based GPU
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);
    glDepthFunc(GL_LEQUAL);
    glClearColor(SKY_R, SKY_G, SKY_B, 1.f);

    // World
    world.init(42);
    initialized = true;
    LOGI("Renderer initialized. MegaBuffer: %.1f MB",
         (float)(world.megaBuffer().totalFaces() * sizeof(PackedFace)) / (1024.f*1024.f));
}

void Renderer::initHUD() {
    m_hudProg = linkProgram(compileShader(GL_VERTEX_SHADER, HUD_VERT),
                              compileShader(GL_FRAGMENT_SHADER, HUD_FRAG));
    float s=0.02f, t=0.002f;
    float verts[] = {
        -s,-t, s,-t, s,t,  -s,-t, s,t, -s,t,
        -t,-s, t,-s, t,s,  -t,-s, t,s, -t,s,
    };
    glGenVertexArrays(1, &m_hudVao);
    glGenBuffers(1, &m_hudVbo);
    glBindVertexArray(m_hudVao);
    glBindBuffer(GL_ARRAY_BUFFER, m_hudVbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, nullptr);
    glBindVertexArray(0);
}

// ── Resize ────────────────────────────────────────────────────────────────────
void Renderer::resize(int w, int h) {
    glViewport(0, 0, w, h);
    camera.aspect = (float)w / (float)h;
    LOGI("Resize %d×%d", w, h);
}

// ── Render clusters ───────────────────────────────────────────────────────────
// Iterates all resident clusters and issues one draw call per cluster.
// Key optimisations vs. original:
//   • Single VBO bind (MegaBuffer) — zero per-chunk VBO overhead.
//   • No index buffer — GL_TRIANGLES from VBO offset, 6 verts per face.
//   • PackedFace data decoded in vertex shader — no float vertex attributes.
//   • Per-cluster uniform origin (ivec3) replaces per-vertex world position.
//
// GLES 3.0 compatibility path:
//   The VBO is bound as GL_ARRAY_BUFFER.  We set up two uint attribute
//   slots (geom word, mat word) with GL_UNSIGNED_INT and divisor=0, so
//   each vertex gets its own PackedFace word.  Since we emit 6 vertices/face
//   and 1 PackedFace spans 6 verts, we actually need to stride differently.
//
//   Better GLES3.0 approach: use instanced drawing with divisor=1 per face,
//   6 verts per instance (gl_InstanceID=faceIdx, gl_VertexID=cornerIdx).
//   This is cleaner and avoids the 6× attribute fetch issue.
//
void Renderer::renderClusters(const Frustum& frustum) {
    // Bind mega-buffer once
    world.megaBuffer().bind();

    // Set up 2 uint32 attribute slots from the VBO (GLES 3.0 path)
    // Attribute 0: geom word (uint)
    // Attribute 1: mat  word (uint)
    // Each PackedFace (8 bytes) feeds one instance (divisor=1).
    // Vertex count: 6 per instance.  gl_VertexID=corner, gl_InstanceID=face.
    glBindVertexArray(m_clusterVao);

    // Enable instanced attribute layout for PackedFace
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glVertexAttribIPointer(0, 1, GL_UNSIGNED_INT, sizeof(PackedFace),
                            (void*)offsetof(PackedFace, geom));
    glVertexAttribIPointer(1, 1, GL_UNSIGNED_INT, sizeof(PackedFace),
                            (void*)offsetof(PackedFace, mat));
    glVertexAttribDivisor(0, 1);   // advance once per instance (face)
    glVertexAttribDivisor(1, 1);

    // Iterate chunks (shared lock — render is GL-only but worker may read)
    std::shared_lock<std::shared_mutex> rlk(world.chunksMutex());
    auto& chunks = world.chunksSnapshot();

    // ── Instanced draw loop ───────────────────────────────────────────────────
    for (auto& kv : chunks) {
        Chunk* ch = kv.second.get();

        // Chunk frustum cull
        float mnX,mnY,mnZ,mxX,mxY,mxZ;
        ch->getAABB(mnX,mnY,mnZ,mxX,mxY,mxZ);
        if (!frustum.testAABB({mnX,mnY,mnZ},{mxX,mxY,mxZ})) continue;

        for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
            if (ch->clusterState[ci].load(std::memory_order_acquire) != ClusterState::READY)
                continue;
            uint32_t offset = ch->clusterGPUOffset[ci];
            uint32_t count  = ch->clusterFaceCount[ci];
            if (offset == MEGA_INVALID || count == 0) continue;

            // Set cluster world origin uniform
            int32_t origin[3] = {
                ch->clusterWorldX(ci),
                ch->clusterWorldY(ci),
                ch->clusterWorldZ(ci)
            };
            glUniform3iv(m_uOrigin, 1, (const GLint*)(const void*)origin);

            // Point attribute base to the start of this cluster's faces in mega VBO
            // We repoint the attrib pointer with a new offset (byte offset into VBO).
            // This is the ONLY "bind" we do per cluster — a cheap uniform + attrib offset.
            GLintptr byteOffset = (GLintptr)(offset * sizeof(PackedFace));
            glVertexAttribIPointer(0, 1, GL_UNSIGNED_INT, sizeof(PackedFace),
                                    (void*)(byteOffset + offsetof(PackedFace, geom)));
            glVertexAttribIPointer(1, 1, GL_UNSIGNED_INT, sizeof(PackedFace),
                                    (void*)(byteOffset + offsetof(PackedFace, mat)));

            // Draw: 6 vertices per face, `count` faces = `count` instances
            glDrawArraysInstanced(GL_TRIANGLES, 0, 6, (GLsizei)count);
        }
    }

    // Restore divisors
    glVertexAttribDivisor(0, 0);
    glVertexAttribDivisor(1, 0);
    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
    glBindVertexArray(0);
}

// ── Main render ───────────────────────────────────────────────────────────────
void Renderer::render(float dt) {
    if (!initialized) return;

    // Camera update
    camera.update(dt, reinterpret_cast<World*>(&world));

    // Stream + thermal update
    float vx=0.f, vz=0.f;
    // Extract camera velocity (forward-only approximation from yaw)
    float yaw = camera.yaw;
    // Use camera speed member if exposed; otherwise approximate
    world.update(camera.position.x, camera.position.z,
                  vx, vz,
                  sinf(yaw), cosf(yaw),
                  dt);

    // GPU uploads (thermally budgeted)
    world.updateGPU();

    // Clear
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    Mat4    vp      = camera.getVP();
    Frustum frustum = camera.getFrustum();

    // World clusters
    glUseProgram(m_prog);
    glUniformMatrix4fv(m_uMVP, 1, GL_FALSE, vp.m);
    glUniform3fv(m_uCamPos, 1, &camera.position.x);
    renderClusters(frustum);

    // HUD
    renderHUD();
}

void Renderer::renderHUD() {
    glDisable(GL_DEPTH_TEST);
    glUseProgram(m_hudProg);
    glBindVertexArray(m_hudVao);
    glDrawArrays(GL_TRIANGLES, 0, 12);
    glBindVertexArray(0);
    glEnable(GL_DEPTH_TEST);
}

// ── Destructor ────────────────────────────────────────────────────────────────
Renderer::~Renderer() {
    if (m_prog)       glDeleteProgram(m_prog);
    if (m_hudProg)    glDeleteProgram(m_hudProg);
    if (m_hudVao)     glDeleteVertexArrays(1, &m_hudVao);
    if (m_hudVbo)     glDeleteBuffers(1, &m_hudVbo);
    if (m_clusterVao) glDeleteVertexArrays(1, &m_clusterVao);
}
