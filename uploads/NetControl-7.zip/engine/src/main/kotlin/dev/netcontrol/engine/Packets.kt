package dev.netcontrol.engine

object Proto {
    const val ICMP = 1
    const val TCP = 6
    const val UDP = 17
    const val ICMP6 = 58
}

object TcpFlags {
    const val FIN = 0x01
    const val SYN = 0x02
    const val RST = 0x04
    const val PSH = 0x08
    const val ACK = 0x10
}

/** A parsed IPv4/IPv6 packet. [headerLen] is the number of bytes before the upper-layer header. */
class IpPacket(
    val data: ByteArray,
    val length: Int,
    val version: Int,
    val src: Addr,
    val dst: Addr,
    val protocol: Int,
    val headerLen: Int,
    val fragId: Long,
    val fragOff: Int,
    val moreFrags: Boolean,
    val hopLimit: Int
) {
    val l4Off: Int get() = headerLen
    val l4Len: Int get() = length - headerLen
    val isFragment: Boolean get() = fragOff != 0 || moreFrags
}

object IpParser {
    fun parse(d: ByteArray, len: Int): IpPacket? {
        if (len < 20 || len > d.size) return null
        return when ((d[0].toInt() and 0xF0) ushr 4) {
            4 -> parse4(d, len)
            6 -> parse6(d, len)
            else -> null
        }
    }

    private fun parse4(d: ByteArray, len: Int): IpPacket? {
        val ihl = (d[0].toInt() and 0x0F) * 4
        if (ihl < 20 || len < ihl) return null
        val total = Bytes.u16(d, 2)
        if (total < ihl || total > len) return null
        val ff = Bytes.u16(d, 6)
        return IpPacket(
            d, total, 4,
            Addr.from(d, 12, 4), Addr.from(d, 16, 4),
            Bytes.u8(d, 9), ihl,
            Bytes.u16(d, 4).toLong(), (ff and 0x1FFF) * 8, (ff and 0x2000) != 0,
            Bytes.u8(d, 8)
        )
    }

    private fun parse6(d: ByteArray, len: Int): IpPacket? {
        if (len < 40) return null
        val total = 40 + Bytes.u16(d, 4)
        if (total > len) return null
        var next = Bytes.u8(d, 6)
        var off = 40
        var fragOff = 0
        var more = false
        var fragId = 0L
        var guard = 0
        var walking = true
        while (walking && guard < 8) {
            guard++
            when (next) {
                0, 43, 60 -> {
                    if (off + 8 > total) return null
                    val hl = (Bytes.u8(d, off + 1) + 1) * 8
                    next = Bytes.u8(d, off)
                    off += hl
                }
                44 -> {
                    if (off + 8 > total) return null
                    val fo = Bytes.u16(d, off + 2)
                    fragOff = fo and 0xFFF8
                    more = (fo and 1) != 0
                    fragId = Bytes.u32(d, off + 4)
                    next = Bytes.u8(d, off)
                    off += 8
                }
                else -> walking = false
            }
            if (off > total) return null
        }
        return IpPacket(
            d, total, 6,
            Addr.from(d, 8, 16), Addr.from(d, 24, 16),
            next, off, fragId, fragOff, more, Bytes.u8(d, 7)
        )
    }
}

class TcpSeg private constructor(
    val srcPort: Int,
    val dstPort: Int,
    val seq: Int,
    val ack: Int,
    val flags: Int,
    val window: Int,
    val payloadOff: Int,
    val payloadLen: Int,
    val mss: Int,
    val wscale: Int
) {
    val syn: Boolean get() = (flags and TcpFlags.SYN) != 0
    val fin: Boolean get() = (flags and TcpFlags.FIN) != 0
    val rst: Boolean get() = (flags and TcpFlags.RST) != 0
    val hasAck: Boolean get() = (flags and TcpFlags.ACK) != 0

    companion object {
        fun parse(p: IpPacket): TcpSeg? {
            if (p.protocol != Proto.TCP || p.l4Len < 20) return null
            val d = p.data
            val o = p.l4Off
            val hl = (d[o + 12].toInt() and 0xF0) ushr 2
            if (hl < 20 || hl > p.l4Len) return null
            var mss = 0
            var ws = -1
            var i = o + 20
            val end = o + hl
            while (i < end) {
                val kind = d[i].toInt() and 0xFF
                if (kind == 0) break
                if (kind == 1) {
                    i++
                    continue
                }
                if (i + 1 >= end) break
                val l = d[i + 1].toInt() and 0xFF
                if (l < 2 || i + l > end) break
                if (kind == 2 && l == 4) mss = Bytes.u16(d, i + 2)
                if (kind == 3 && l == 3) ws = minOf(14, d[i + 2].toInt() and 0xFF)
                i += l
            }
            return TcpSeg(
                Bytes.u16(d, o), Bytes.u16(d, o + 2),
                Bytes.u32(d, o + 4).toInt(), Bytes.u32(d, o + 8).toInt(),
                d[o + 13].toInt() and 0x3F, Bytes.u16(d, o + 14),
                o + hl, p.l4Len - hl, mss, ws
            )
        }
    }
}

class UdpDgram private constructor(
    val srcPort: Int,
    val dstPort: Int,
    val payloadOff: Int,
    val payloadLen: Int
) {
    companion object {
        fun parse(p: IpPacket): UdpDgram? {
            if (p.protocol != Proto.UDP || p.l4Len < 8) return null
            val o = p.l4Off
            val len = Bytes.u16(p.data, o + 4)
            if (len < 8) return null
            val used = minOf(len, p.l4Len)
            return UdpDgram(Bytes.u16(p.data, o), Bytes.u16(p.data, o + 2), o + 8, used - 8)
        }
    }
}

/** Builds complete IP packets (no IPv4 options, no IPv6 extension headers). */
object PacketBuilder {
    private var id4 = 0
    private var id6 = 0

    internal fun nextId4(): Int {
        id4 = (id4 + 1) and 0xFFFF
        return id4
    }

    internal fun nextId6(): Int {
        id6 += 1
        return id6
    }

    internal fun pseudo(src: Addr, dst: Addr, proto: Int, len: Int): Long {
        var s = 0L
        var i = 0
        while (i < src.size) {
            s += ((src.byteAt(i) shl 8) or src.byteAt(i + 1)).toLong()
            i += 2
        }
        i = 0
        while (i < dst.size) {
            s += ((dst.byteAt(i) shl 8) or dst.byteAt(i + 1)).toLong()
            i += 2
        }
        s += proto.toLong()
        s += len.toLong()
        return s
    }

    /**
     * Writes the IP header of a packet that carries [payloadLen] more bytes at the start of [out] and returns
     * its length. Every header byte is written explicitly, so [out] may be a reused buffer that still holds an
     * earlier packet.
     */
    private fun writeIp(out: ByteArray, src: Addr, dst: Addr, proto: Int, payloadLen: Int, df: Boolean): Int {
        if (!src.isV6) {
            out[0] = 0x45
            out[1] = 0
            Bytes.put16(out, 2, 20 + payloadLen)
            Bytes.put16(out, 4, nextId4())
            Bytes.put16(out, 6, if (df) 0x4000 else 0)
            out[8] = 64
            out[9] = proto.toByte()
            Bytes.put16(out, 10, 0)
            src.copyInto(out, 12)
            dst.copyInto(out, 16)
            Bytes.put16(out, 10, Checksum.compute(out, 0, 20))
            return 20
        }
        out[0] = 0x60
        out[1] = 0
        out[2] = 0
        out[3] = 0
        Bytes.put16(out, 4, payloadLen)
        out[6] = proto.toByte()
        out[7] = 64
        src.copyInto(out, 8)
        dst.copyInto(out, 24)
        return 40
    }

    /**
     * Builds a TCP segment at the start of [out], which may be a reused buffer, and returns the packet length.
     * The hot send path builds into one buffer this way instead of allocating an array per packet.
     */
    fun tcpInto(
        out: ByteArray, src: Addr, dst: Addr, sport: Int, dport: Int, seq: Int, ack: Int, flags: Int, window: Int,
        options: ByteArray?, payload: ByteArray?, pOff: Int, pLen: Int
    ): Int {
        val optLen = options?.size ?: 0
        val tcpLen = 20 + optLen + pLen
        val ipLen = writeIp(out, src, dst, Proto.TCP, tcpLen, true)
        val o = ipLen
        Bytes.put16(out, o, sport)
        Bytes.put16(out, o + 2, dport)
        Bytes.put32(out, o + 4, seq)
        Bytes.put32(out, o + 8, ack)
        out[o + 12] = (((20 + optLen) / 4) shl 4).toByte()
        out[o + 13] = flags.toByte()
        Bytes.put16(out, o + 14, window)
        Bytes.put16(out, o + 16, 0)
        Bytes.put16(out, o + 18, 0)
        if (options != null) System.arraycopy(options, 0, out, o + 20, optLen)
        if (payload != null && pLen > 0) System.arraycopy(payload, pOff, out, o + 20 + optLen, pLen)
        val sum = Checksum.add(pseudo(src, dst, Proto.TCP, tcpLen), out, o, tcpLen)
        Bytes.put16(out, o + 16, Checksum.finish(sum))
        return ipLen + tcpLen
    }

    fun tcp(
        src: Addr, dst: Addr, sport: Int, dport: Int, seq: Int, ack: Int, flags: Int, window: Int,
        options: ByteArray?, payload: ByteArray?, pOff: Int, pLen: Int
    ): ByteArray {
        val optLen = options?.size ?: 0
        val out = ByteArray((if (src.isV6) 40 else 20) + 20 + optLen + pLen)
        tcpInto(out, src, dst, sport, dport, seq, ack, flags, window, options, payload, pOff, pLen)
        return out
    }

    /** Builds a UDP datagram at the start of [out], which may be a reused buffer, and returns the packet length. */
    fun udpInto(
        out: ByteArray, src: Addr, dst: Addr, sport: Int, dport: Int, payload: ByteArray, pOff: Int, pLen: Int
    ): Int {
        val udpLen = 8 + pLen
        val ipLen = writeIp(out, src, dst, Proto.UDP, udpLen, false)
        val o = ipLen
        Bytes.put16(out, o, sport)
        Bytes.put16(out, o + 2, dport)
        Bytes.put16(out, o + 4, udpLen)
        Bytes.put16(out, o + 6, 0)
        if (pLen > 0) System.arraycopy(payload, pOff, out, o + 8, pLen)
        var c = Checksum.finish(Checksum.add(pseudo(src, dst, Proto.UDP, udpLen), out, o, udpLen))
        if (c == 0) c = 0xFFFF
        Bytes.put16(out, o + 6, c)
        return ipLen + udpLen
    }

    fun udp(src: Addr, dst: Addr, sport: Int, dport: Int, payload: ByteArray, pOff: Int, pLen: Int): ByteArray {
        val out = ByteArray((if (src.isV6) 40 else 20) + 8 + pLen)
        udpInto(out, src, dst, sport, dport, payload, pOff, pLen)
        return out
    }

    /** ICMP/ICMPv6 "port unreachable" answering [orig]; makes blocked UDP fail fast instead of timing out. */
    fun icmpUnreachable(orig: IpPacket): ByteArray {
        val src = orig.dst
        val dst = orig.src
        if (!orig.src.isV6) {
            val quote = minOf(orig.length, orig.headerLen + 8)
            val icmpLen = 8 + quote
            val out = ByteArray(20 + icmpLen)
            writeIp(out, src, dst, Proto.ICMP, icmpLen, false)
            out[20] = 3
            out[21] = 3
            System.arraycopy(orig.data, 0, out, 28, quote)
            Bytes.put16(out, 22, Checksum.compute(out, 20, icmpLen))
            return out
        }
        val quote = minOf(orig.length, 512)
        val icmpLen = 8 + quote
        val out = ByteArray(40 + icmpLen)
        writeIp(out, src, dst, Proto.ICMP6, icmpLen, false)
        out[40] = 1
        out[41] = 4
        System.arraycopy(orig.data, 0, out, 48, quote)
        val sum = Checksum.add(pseudo(src, dst, Proto.ICMP6, icmpLen), out, 40, icmpLen)
        Bytes.put16(out, 42, Checksum.finish(sum))
        return out
    }
}

/** Splits oversized packets we generate (UDP replies) into fragments that fit the tunnel MTU. */
object Fragmenter {
    fun split(packet: ByteArray, mtu: Int): List<ByteArray> {
        if (packet.size <= mtu) return listOf(packet)
        return if ((packet[0].toInt() and 0xF0) == 0x60) split6(packet, mtu) else split4(packet, mtu)
    }

    private fun split4(p: ByteArray, mtu: Int): List<ByteArray> {
        val ihl = (p[0].toInt() and 0x0F) * 4
        val payloadLen = p.size - ihl
        val chunk = ((mtu - ihl) / 8) * 8
        val out = ArrayList<ByteArray>()
        var off = 0
        while (off < payloadLen) {
            val n = minOf(chunk, payloadLen - off)
            val last = off + n >= payloadLen
            val f = ByteArray(ihl + n)
            System.arraycopy(p, 0, f, 0, ihl)
            System.arraycopy(p, ihl + off, f, ihl, n)
            Bytes.put16(f, 2, ihl + n)
            Bytes.put16(f, 6, (off / 8) or (if (last) 0 else 0x2000))
            Bytes.put16(f, 10, 0)
            Bytes.put16(f, 10, Checksum.compute(f, 0, ihl))
            out.add(f)
            off += n
        }
        return out
    }

    private fun split6(p: ByteArray, mtu: Int): List<ByteArray> {
        val payloadLen = p.size - 40
        val chunk = ((mtu - 48) / 8) * 8
        val next = p[6]
        val id = PacketBuilder.nextId6()
        val out = ArrayList<ByteArray>()
        var off = 0
        while (off < payloadLen) {
            val n = minOf(chunk, payloadLen - off)
            val last = off + n >= payloadLen
            val f = ByteArray(48 + n)
            System.arraycopy(p, 0, f, 0, 40)
            f[6] = 44
            Bytes.put16(f, 4, 8 + n)
            f[40] = next
            f[41] = 0
            Bytes.put16(f, 42, off or (if (last) 0 else 1))
            Bytes.put32(f, 44, id)
            System.arraycopy(p, 40 + off, f, 48, n)
            out.add(f)
            off += n
        }
        return out
    }
}

/** Reassembles fragmented IPv4/IPv6 datagrams (used for UDP). Not thread safe. */
class Reassembler {
    private class Entry(val createdMs: Long) {
        var buf: ByteArray? = null
        val got = BooleanArray(8192)
        var total = -1
        var firstHdr: ByteArray? = null
        var hdrLen = 0
    }

    private val map = HashMap<String, Entry>()

    fun offer(p: IpPacket, nowMs: Long): IpPacket? {
        val key = p.version.toString() + "|" + p.src + "|" + p.dst + "|" + p.fragId + "|" + p.protocol
        var e = map[key]
        if (e == null) {
            if (map.size >= MAX_ENTRIES) evictOldest()
            e = Entry(nowMs)
            map[key] = e
        }
        val off = p.fragOff
        val n = p.l4Len
        if (n <= 0 || off + n > 65535) {
            map.remove(key)
            return null
        }
        var buf = e.buf
        if (buf == null) {
            buf = ByteArray(65536)
            e.buf = buf
        }
        System.arraycopy(p.data, p.l4Off, buf, off, n)
        for (b in (off / 8) until ((off + n + 7) / 8)) e.got[b] = true
        if (off == 0) {
            e.firstHdr = p.data.copyOfRange(0, p.headerLen)
            e.hdrLen = p.headerLen
        }
        if (!p.moreFrags) e.total = off + n
        val hdr = e.firstHdr
        if (e.total >= 0 && hdr != null) {
            val blocks = (e.total + 7) / 8
            var complete = true
            for (b in 0 until blocks) {
                if (!e.got[b]) {
                    complete = false
                    break
                }
            }
            if (complete) {
                map.remove(key)
                return rebuild(p.version, p.protocol, hdr, e.hdrLen, buf, e.total)
            }
        }
        return null
    }

    fun expire(nowMs: Long) {
        if (map.isEmpty()) return
        val it = map.values.iterator()
        while (it.hasNext()) {
            if (nowMs - it.next().createdMs > TIMEOUT_MS) it.remove()
        }
    }

    private fun evictOldest() {
        var oldestKey: String? = null
        var oldest = Long.MAX_VALUE
        for ((k, v) in map) {
            if (v.createdMs < oldest) {
                oldest = v.createdMs
                oldestKey = k
            }
        }
        if (oldestKey != null) map.remove(oldestKey)
    }

    private fun rebuild(version: Int, proto: Int, hdr: ByteArray, hdrLen: Int, buf: ByteArray, total: Int): IpPacket? {
        if (version == 4) {
            val len = hdrLen + total
            val out = ByteArray(len)
            System.arraycopy(hdr, 0, out, 0, hdrLen)
            System.arraycopy(buf, 0, out, hdrLen, total)
            Bytes.put16(out, 2, len)
            Bytes.put16(out, 6, 0)
            Bytes.put16(out, 10, 0)
            Bytes.put16(out, 10, Checksum.compute(out, 0, hdrLen))
            return IpParser.parse(out, len)
        }
        val len = 40 + total
        val out = ByteArray(len)
        System.arraycopy(hdr, 0, out, 0, 40)
        out[6] = proto.toByte()
        Bytes.put16(out, 4, total)
        System.arraycopy(buf, 0, out, 40, total)
        return IpParser.parse(out, len)
    }

    private companion object {
        const val MAX_ENTRIES = 64
        const val TIMEOUT_MS = 5000L
    }
}
