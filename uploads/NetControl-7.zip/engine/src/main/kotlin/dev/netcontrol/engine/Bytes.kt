package dev.netcontrol.engine

internal object Bytes {
    fun u8(b: ByteArray, i: Int): Int = b[i].toInt() and 0xFF

    fun u16(b: ByteArray, i: Int): Int =
        ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

    fun u32(b: ByteArray, i: Int): Long =
        (u16(b, i).toLong() shl 16) or u16(b, i + 2).toLong()

    fun put16(b: ByteArray, i: Int, v: Int) {
        b[i] = (v ushr 8).toByte()
        b[i + 1] = v.toByte()
    }

    fun put32(b: ByteArray, i: Int, v: Int) {
        b[i] = (v ushr 24).toByte()
        b[i + 1] = (v ushr 16).toByte()
        b[i + 2] = (v ushr 8).toByte()
        b[i + 3] = v.toByte()
    }
}

/** RFC 1071 internet checksum helpers. */
object Checksum {
    fun add(sum: Long, d: ByteArray, off: Int, len: Int): Long {
        var s = sum
        var i = off
        val end = off + len
        // Eight bytes (four 16-bit words) per step: every packet is checksummed, so fewer loop branches per
        // packet add up. The four words together stay below 2^18, so they are summed as an Int first.
        val blockEnd = end - 7
        while (i < blockEnd) {
            val w = (((d[i].toInt() and 0xFF) shl 8) or (d[i + 1].toInt() and 0xFF)) +
                (((d[i + 2].toInt() and 0xFF) shl 8) or (d[i + 3].toInt() and 0xFF)) +
                (((d[i + 4].toInt() and 0xFF) shl 8) or (d[i + 5].toInt() and 0xFF)) +
                (((d[i + 6].toInt() and 0xFF) shl 8) or (d[i + 7].toInt() and 0xFF))
            s += w.toLong()
            i += 8
        }
        while (i + 1 < end) {
            s += (((d[i].toInt() and 0xFF) shl 8) or (d[i + 1].toInt() and 0xFF)).toLong()
            i += 2
        }
        if (i < end) s += ((d[i].toInt() and 0xFF) shl 8).toLong()
        return s
    }

    fun finish(sum: Long): Int {
        var s = sum
        while ((s ushr 16) != 0L) {
            s = (s and 0xFFFFL) + (s ushr 16)
        }
        return (s.inv() and 0xFFFFL).toInt()
    }

    fun compute(d: ByteArray, off: Int, len: Int): Int = finish(add(0L, d, off, len))
}

/** Growable FIFO byte buffer with random-access peek. Not thread safe. */
internal class ByteQueue {
    private var buf: ByteArray = EMPTY
    private var start = 0
    private var end = 0

    val size: Int get() = end - start

    fun append(src: ByteArray, off: Int, len: Int) {
        if (len <= 0) return
        if (end + len > buf.size) {
            val live = end - start
            if (live + len <= buf.size && start >= live) {
                System.arraycopy(buf, start, buf, 0, live)
                start = 0
                end = live
            } else {
                var cap = if (buf.size < 2048) 2048 else buf.size
                while (cap < live + len) cap *= 2
                val nb = ByteArray(cap)
                System.arraycopy(buf, start, nb, 0, live)
                buf = nb
                start = 0
                end = live
            }
        }
        System.arraycopy(src, off, buf, end, len)
        end += len
    }

    fun peek(offset: Int, dst: ByteArray, dstOff: Int, len: Int) {
        System.arraycopy(buf, start + offset, dst, dstOff, len)
    }

    fun discard(n: Int) {
        start += minOf(n, size)
        if (start >= end) {
            // The array stays: dropping it here made a busy flow allocate and free a large array for
            // every burst of data. A flow that has gone quiet gives it back through trim().
            start = 0
            end = 0
        }
    }

    /** Releases the backing array of an empty queue; does nothing while data is queued. */
    fun trim() {
        if (start >= end && buf.size > 0) {
            start = 0
            end = 0
            buf = EMPTY
        }
    }

    fun clear() {
        start = 0
        end = 0
        buf = EMPTY
    }

    private companion object {
        val EMPTY = ByteArray(0)
    }
}
