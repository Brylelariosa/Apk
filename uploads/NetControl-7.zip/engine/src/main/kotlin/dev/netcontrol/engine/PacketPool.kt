package dev.netcontrol.engine

import java.util.concurrent.ArrayBlockingQueue

/** One packet read from the tunnel: the first [len] bytes of [data] are valid. Recycled through [PacketPool]. */
internal class PacketBuf(val data: ByteArray) {
    var len: Int = 0
}

/**
 * Hands out the arrays that carry packets from the tunnel reader thread to the engine thread and takes them
 * back once the packet has been handled. Before this existed every single packet cost a fresh array, and the
 * garbage collector worked non-stop behind a busy tunnel.
 *
 * Two sizes are pooled: small arrays for the many ACKs and requests, and arrays that fit a full tunnel packet.
 * The pool is bounded so a burst cannot pin memory for good. Thread safe.
 */
internal class PacketPool(private val largeSize: Int) {
    private val small = ArrayBlockingQueue<PacketBuf>(SMALL_KEEP)
    private val large = ArrayBlockingQueue<PacketBuf>(LARGE_KEEP)

    /** A buffer with room for at least [needed] bytes whose [PacketBuf.len] is 0. */
    fun take(needed: Int): PacketBuf {
        if (needed <= SMALL_SIZE) return small.poll() ?: PacketBuf(ByteArray(SMALL_SIZE))
        if (needed <= largeSize) return large.poll() ?: PacketBuf(ByteArray(largeSize))
        return PacketBuf(ByteArray(needed))
    }

    /** Returns a buffer after its packet was handled. Odd-sized or surplus buffers are left to the collector. */
    fun give(p: PacketBuf) {
        p.len = 0
        val size = p.data.size
        if (size == SMALL_SIZE) {
            small.offer(p)
        } else if (size == largeSize) {
            large.offer(p)
        }
    }

    private companion object {
        const val SMALL_SIZE = 2048
        const val SMALL_KEEP = 1024
        const val LARGE_KEEP = 64
    }
}
