package dev.netcontrol.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PacketCodecTest {
    private val a4 = Addr.v4(10, 0, 0, 1)
    private val b4 = Addr.v4(93, 184, 216, 34)

    private fun v6(last: Int): Addr {
        val raw = ByteArray(16)
        raw[0] = 0xfd.toByte()
        raw[15] = last.toByte()
        return Addr(raw)
    }

    private fun checksumOk(pkt: ByteArray, ip: IpPacket): Boolean {
        val sum = Checksum.add(PacketBuilder.pseudo(ip.src, ip.dst, ip.protocol, ip.l4Len), pkt, ip.l4Off, ip.l4Len)
        return Checksum.finish(sum) == 0
    }

    @Test
    fun tcpV4RoundTrip() {
        val payload = "hello".toByteArray()
        val pkt = PacketBuilder.tcp(
            a4, b4, 1234, 80, 1000, 2000, TcpFlags.ACK or TcpFlags.PSH, 500, null, payload, 0, payload.size
        )
        val ip = IpParser.parse(pkt, pkt.size)
        assertNotNull(ip)
        ip!!
        assertEquals(4, ip.version)
        assertEquals(Proto.TCP, ip.protocol)
        assertEquals(a4, ip.src)
        assertEquals(b4, ip.dst)
        assertEquals(0, Checksum.compute(pkt, 0, 20))
        assertTrue(checksumOk(pkt, ip))
        val seg = TcpSeg.parse(ip)
        assertNotNull(seg)
        seg!!
        assertEquals(1234, seg.srcPort)
        assertEquals(80, seg.dstPort)
        assertEquals(1000, seg.seq)
        assertEquals(2000, seg.ack)
        assertEquals(500, seg.window)
        assertEquals(5, seg.payloadLen)
        assertEquals("hello", String(pkt, seg.payloadOff, seg.payloadLen))
    }

    @Test
    fun synWithOptionsIsParsed() {
        val opts = byteArrayOf(2, 4, 0x05, 0xB4.toByte(), 1, 3, 3, 7)
        val pkt = PacketBuilder.tcp(a4, b4, 40000, 443, 5, 0, TcpFlags.SYN, 65535, opts, null, 0, 0)
        val ip = IpParser.parse(pkt, pkt.size)!!
        val seg = TcpSeg.parse(ip)!!
        assertTrue(seg.syn)
        assertEquals(1460, seg.mss)
        assertEquals(7, seg.wscale)
        assertEquals(0, seg.payloadLen)
        assertTrue(checksumOk(pkt, ip))
    }

    @Test
    fun tcpV6AndUdpV6RoundTrip() {
        val src = v6(1)
        val dst = v6(2)
        val tcp = PacketBuilder.tcp(src, dst, 5000, 443, 7, 9, TcpFlags.ACK, 100, null, null, 0, 0)
        val ipT = IpParser.parse(tcp, tcp.size)!!
        assertEquals(6, ipT.version)
        assertEquals(Proto.TCP, ipT.protocol)
        assertTrue(checksumOk(tcp, ipT))

        val data = ByteArray(100) { it.toByte() }
        val udp = PacketBuilder.udp(src, dst, 5353, 53, data, 0, data.size)
        val ipU = IpParser.parse(udp, udp.size)!!
        val d = UdpDgram.parse(ipU)!!
        assertEquals(100, d.payloadLen)
        assertEquals(53, d.dstPort)
        assertTrue(checksumOk(udp, ipU))
    }

    @Test
    fun malformedPacketsAreRejected() {
        assertNull(IpParser.parse(ByteArray(10), 10))
        val bad = ByteArray(40)
        bad[0] = 0x45
        assertNull(IpParser.parse(bad, 40))
    }

    @Test
    fun udpV4FragmentsReassemble() {
        val payload = ByteArray(3000) { (it * 7).toByte() }
        val pkt = PacketBuilder.udp(a4, b4, 4000, 5000, payload, 0, payload.size)
        val frags = Fragmenter.split(pkt, 1500)
        assertEquals(3, frags.size)
        val r = Reassembler()
        var whole: IpPacket? = null
        for (i in intArrayOf(2, 0, 1)) {
            val ip = IpParser.parse(frags[i], frags[i].size)!!
            assertTrue(ip.isFragment)
            val res = r.offer(ip, 0L)
            if (i != 1) assertNull(res) else whole = res
        }
        assertNotNull(whole)
        val u = UdpDgram.parse(whole!!)!!
        assertEquals(3000, u.payloadLen)
        for (i in 0 until 3000) assertEquals(payload[i], whole.data[u.payloadOff + i])
    }

    @Test
    fun udpV6FragmentsReassemble() {
        val src = v6(1)
        val dst = v6(2)
        val payload = ByteArray(3000) { (it * 3).toByte() }
        val pkt = PacketBuilder.udp(src, dst, 4000, 5000, payload, 0, payload.size)
        val frags = Fragmenter.split(pkt, 1280)
        assertEquals(3, frags.size)
        val r = Reassembler()
        var whole: IpPacket? = null
        for (f in frags) {
            val ip = IpParser.parse(f, f.size)!!
            assertTrue(ip.isFragment)
            val res = r.offer(ip, 0L)
            if (res != null) whole = res
        }
        assertNotNull(whole)
        val u = UdpDgram.parse(whole!!)!!
        assertEquals(3000, u.payloadLen)
        for (i in 0 until 3000) assertEquals(payload[i], whole.data[u.payloadOff + i])
    }

    @Test
    fun icmpUnreachableSwapsEndpointsAndChecksums() {
        val data = ByteArray(10)
        val udp = PacketBuilder.udp(a4, b4, 4000, 5000, data, 0, data.size)
        val orig = IpParser.parse(udp, udp.size)!!
        val icmp = PacketBuilder.icmpUnreachable(orig)
        val ip = IpParser.parse(icmp, icmp.size)!!
        assertEquals(Proto.ICMP, ip.protocol)
        assertEquals(b4, ip.src)
        assertEquals(a4, ip.dst)
        assertEquals(3, icmp[ip.l4Off].toInt())
        assertEquals(3, icmp[ip.l4Off + 1].toInt())
        assertEquals(0, Checksum.compute(icmp, ip.l4Off, ip.l4Len))
    }

    @Test
    fun segmentsBuiltIntoAReusedBufferAreValid() {
        val scratch = ByteArray(2000)
        val payload = ByteArray(1200) { (it * 7).toByte() }
        val opts = byteArrayOf(2, 4, 0x05, 0xB4.toByte(), 1, 3, 3, 7)
        for (src in listOf(a4, v6(1))) {
            val dst = if (src.isV6) v6(2) else b4
            // The buffer still holds an earlier packet: every header byte has to be written afresh.
            scratch.fill(0xAB.toByte())
            val n = PacketBuilder.tcpInto(
                scratch, src, dst, 443, 50000, 11, 22, TcpFlags.ACK or TcpFlags.PSH, 300, null, payload, 0, payload.size
            )
            val pkt = scratch.copyOf(n)
            val ip = IpParser.parse(pkt, pkt.size)!!
            assertEquals(payload.size + 20, ip.l4Len)
            assertTrue(checksumOk(pkt, ip))
            if (!src.isV6) assertEquals(0, Checksum.compute(pkt, 0, 20))
            val seg = TcpSeg.parse(ip)!!
            assertEquals(443, seg.srcPort)
            assertEquals(50000, seg.dstPort)
            assertEquals(11, seg.seq)
            assertEquals(22, seg.ack)
            assertEquals(300, seg.window)
            assertEquals(payload.size, seg.payloadLen)
            for (i in payload.indices) assertEquals(payload[i], pkt[seg.payloadOff + i])

            scratch.fill(0xAB.toByte())
            val m = PacketBuilder.tcpInto(scratch, src, dst, 443, 50000, 5, 6, TcpFlags.SYN or TcpFlags.ACK, 65535, opts, null, 0, 0)
            val syn = scratch.copyOf(m)
            val ipS = IpParser.parse(syn, syn.size)!!
            assertTrue(checksumOk(syn, ipS))
            val segS = TcpSeg.parse(ipS)!!
            assertEquals(1460, segS.mss)
            assertEquals(7, segS.wscale)
            assertEquals(0, segS.payloadLen)
        }
    }

    @Test
    fun datagramsBuiltIntoAReusedBufferAreValid() {
        val scratch = ByteArray(2000)
        val data = ByteArray(333) { (it * 3).toByte() }
        for (src in listOf(a4, v6(1))) {
            val dst = if (src.isV6) v6(2) else b4
            scratch.fill(0xAB.toByte())
            val n = PacketBuilder.udpInto(scratch, src, dst, 53, 40000, data, 0, data.size)
            val pkt = scratch.copyOf(n)
            val ip = IpParser.parse(pkt, pkt.size)!!
            assertTrue(checksumOk(pkt, ip))
            if (!src.isV6) assertEquals(0, Checksum.compute(pkt, 0, 20))
            val d = UdpDgram.parse(ip)!!
            assertEquals(53, d.srcPort)
            assertEquals(40000, d.dstPort)
            assertEquals(data.size, d.payloadLen)
            for (i in data.indices) assertEquals(data[i], pkt[d.payloadOff + i])
        }
    }

    @Test
    fun packetsAreParsedFromTheStartOfALargerArray() {
        // Packets from the tunnel arrive in pooled arrays that are longer than the packet.
        val payload = "ping".toByteArray()
        val pkt = PacketBuilder.tcp(a4, b4, 1, 2, 3, 4, TcpFlags.ACK, 5, null, payload, 0, payload.size)
        val big = ByteArray(2048)
        big.fill(0x77)
        System.arraycopy(pkt, 0, big, 0, pkt.size)
        val ip = IpParser.parse(big, pkt.size)!!
        assertEquals(pkt.size, ip.length)
        val seg = TcpSeg.parse(ip)!!
        assertEquals(4, seg.payloadLen)
        assertEquals("ping", String(big, seg.payloadOff, seg.payloadLen))
    }
}
