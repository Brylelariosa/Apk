package dev.netcontrol.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class PacketPoolTest {
    @Test
    fun buffersAreBigEnoughForTheRequestedPacket() {
        val pool = PacketPool(9064)
        assertTrue(pool.take(60).data.size >= 60)
        assertTrue(pool.take(1500).data.size >= 1500)
        assertTrue(pool.take(9000).data.size >= 9000)
        assertTrue(pool.take(20000).data.size >= 20000)
    }

    @Test
    fun givenBuffersAreReusedAndComeBackEmpty() {
        val pool = PacketPool(9064)
        val a = pool.take(100)
        a.len = 100
        pool.give(a)
        val b = pool.take(40)
        assertSame(a, b)
        assertEquals(0, b.len)

        val big = pool.take(9000)
        pool.give(big)
        assertSame(big, pool.take(5000))
    }
}
