package dev.netcontrol.engine

import org.junit.Assert.assertEquals
import org.junit.Test

class ChecksumTest {
    @Test
    fun ipv4HeaderKnownVector() {
        val h = intArrayOf(
            0x45, 0x00, 0x00, 0x73, 0x00, 0x00, 0x40, 0x00, 0x40, 0x11, 0x00, 0x00,
            0xc0, 0xa8, 0x00, 0x01, 0xc0, 0xa8, 0x00, 0xc7
        )
        val b = ByteArray(h.size) { h[it].toByte() }
        assertEquals(0xB861, Checksum.compute(b, 0, b.size))
        Bytes.put16(b, 10, 0xB861)
        assertEquals(0, Checksum.compute(b, 0, b.size))
    }

    @Test
    fun oddLengthIsPaddedWithZero() {
        val b = byteArrayOf(0x01, 0x02, 0x03)
        // words: 0x0102 + 0x0300 = 0x0402 -> complement 0xFBFD
        assertEquals(0xFBFD, Checksum.compute(b, 0, 3))
    }

    @Test
    fun byteQueueKeepsOrderAcrossGrowthAndDiscard() {
        val q = ByteQueue()
        val a = ByteArray(5000) { (it % 251).toByte() }
        q.append(a, 0, a.size)
        q.discard(1000)
        q.append(a, 0, 3000)
        assertEquals(7000, q.size)
        val out = ByteArray(7000)
        q.peek(0, out, 0, 7000)
        for (i in 0 until 4000) assertEquals(a[1000 + i], out[i])
        for (i in 0 until 3000) assertEquals(a[i], out[4000 + i])
    }

    @Test
    fun blockedLoopMatchesTheWordByWordSumForEveryLengthAndOffset() {
        val rnd = java.util.Random(7)
        for (len in 0..70) {
            for (off in 0..3) {
                val b = ByteArray(off + len + 2)
                rnd.nextBytes(b)
                var s = 0L
                var i = off
                while (i + 1 < off + len) {
                    s += (((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)).toLong()
                    i += 2
                }
                if (i < off + len) s += ((b[i].toInt() and 0xFF) shl 8).toLong()
                assertEquals(Checksum.finish(s), Checksum.compute(b, off, len))
            }
        }
    }

    @Test
    fun byteQueueWorksAfterBeingEmptiedAndTrimmed() {
        val q = ByteQueue()
        val a = ByteArray(200000) { (it % 253).toByte() }
        q.append(a, 0, a.size)
        q.discard(a.size)
        assertEquals(0, q.size)
        q.trim()
        q.append(a, 0, 10)
        q.trim() // must not drop data that is still queued
        assertEquals(10, q.size)
        val out = ByteArray(10)
        q.peek(0, out, 0, 10)
        for (i in 0 until 10) assertEquals(a[i], out[i])
        q.discard(10)
        q.append(a, 5, 20)
        assertEquals(20, q.size)
    }
}
