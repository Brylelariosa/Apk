# Test report

Apart from "Findings from device runs" at the end, nothing below is a result that was measured on a device.
This file lists what was actually done when the project was written and what still has to be run. Update the
"Result" column after each run.

## Performed while writing the project (no compiler, no device available)

| Check | Result |
|---|---|
| Brace/parenthesis/bracket balance of all Kotlin files | passed (scripted) |
| Package declarations match directories | passed (scripted) |
| Project-internal imports resolve to declarations | passed (scripted) |
| Every `R.string`, `R.plurals`, `R.drawable` reference has a resource | passed (scripted) |
| All XML (manifest, resources, vector drawables) is well formed | passed (xmllint) |
| No non-ASCII characters (so no emoji) in any source or resource file | passed (scripted) |
| No `splits`, `abiFilters`, NDK or native library configuration | passed (grep) |
| Manual read-through of engine, service and UI for type/nullability errors | done once, not a compiler |

## Not performed (must be run)

| ID | Test | How | Expected | Result |
|---|---|---|---|---|
| H1 | Release build compiles | `gradle :app:assembleRelease` | success, APK present | not run |
| H2 | Unit tests (includes `CapturePlannerTest`, `CoreUidsTest` and the core UID tests in `RoutingTableTest`) | `gradle :engine:test :app:testDebugUnitTest` | all pass | not run |
| H3 | APK size | read `NETCONTROL_APK_REPORT` in the log | measured MB | not run |
| H4 | R8 / resource shrinking sanity | install release APK, open every screen | no crash, no missing resource | not run |
| H5 | One universal APK, no ABI splits | log line `lib/ entries = 0`, single file | 0 native entries | not run |
| A | Wi-Fi Only | Wi-Fi + data on, Opera = Wi-Fi Only, start, browse, turn Wi-Fi off, turn Wi-Fi on | works on Wi-Fi, no internet when Wi-Fi is off (never mobile data), returns with Wi-Fi | not run |
| B | Mobile Data Only | test app = Mobile Data Only, start, use it, turn mobile data off, on | works on mobile, no internet when data is off (never Wi-Fi), returns | not run |
| C | Block Internet | app = Block, try browsing and DoH, then Automatic | no connectivity while blocked, returns afterwards | not run |
| D | Automatic | app = Automatic | not in the tunnel (Diagnostics: apps inside tunnel does not count it) | not run |
| E | DNS | resolve names for apps of each mode, switch networks, disable the chosen network | lookups use the chosen network, fail when it is missing; check attributed/unattributed counters | not run |
| F | IPv4 / IPv6 | IPv6-capable network, toggle Settings > IPv6 | no bypass in either case | not run |
| G | Stability | Wi-Fi/mobile on-off, switch default network, restart app, stop/start service, reboot, revoke VPN consent | rules persist, state labels stay truthful, no crash | not run |
| I1 | System apps listed | open Apps | Download Manager and other system apps appear with a `System` tag; `User apps` / `System apps` chips hide each group; core entries (Android System, ...) carry `Core system` | not run |
| I2 | Download Manager rule | Download Manager = Wi-Fi Only, start protection, download a large file from the browser, turn Wi-Fi off and on | download uses Wi-Fi only and pauses without Wi-Fi; Diagnostics shows flows for its UID (confirms its sockets enter the tunnel) | not run |
| I3 | Core entry | set a core entry (for example Phone and telephony services) to Block | confirmation dialog first; after Apply its flows are blocked; Automatic restores them | not run |
| I4 | Upgrade baseline | install over version 1.0.0 with the default policy for new apps set to Block, open the app | no system app receives a rule; apps installed later still get the default | not run |
| J1 | Speed A/B | same app, same speed test: Automatic, then Wi-Fi Only, then Wi-Fi Only with another app set to Mobile Data Only | Wi-Fi Only close to Automatic; mixed rules no slower than Wi-Fi Only; note the Mbps and the Diagnostics counters (Blocked connections, Lookups with unknown owner, Dropped packets) | not run |
| J2 | Heat and CPU A/B (version 1.1.1) | many apps with rules, protection on, same 10 minutes of use (video plus background sync), Settings > Large packets on, then off; compare the battery usage screen (NetControl share) and how warm the phone gets | on: clearly less CPU and heat than off; every protected app behaves the same in both modes; no app fails to load with the setting on | not run |
| J3 | Large-packet compatibility | with Large packets on: browser, video app, messenger with a photo upload, a speed test, a DNS lookup of a large TXT record | all work as with the setting off; if an app fails only with it on, note the app | not run |

Things worth checking first on the first real run, because they depend on platform behavior that could not be
confirmed here:

1. `Network.bindSocket()` on NIO socket channels works on the target Android version (if it does not, flows fail
   with "Socket could not be bound to the network" and are blocked, never leaked).
2. `getConnectionOwnerUid()` returns the app UID for TCP and UDP flows and, ideally, DNS lookups
   (Diagnostics > DNS shows attributed vs unattributed counts).
3. Throughput of video streaming through the tunnel on the Infinix Hot 11 (user-space TCP in Kotlin).

## Findings from device runs

| Date | Device | What happened | Cause | Change | Verified |
|---|---|---|---|---|---|
| 2026-10-15 | Android 11 (API 30), Infinix X675 | The release build ended right after start. The in-app crash report named `IllegalStateException: CompositionLocal LocalLifecycleOwner not present`, thrown by the first `collectAsStateWithLifecycle()` call. | Lifecycle 2.8 finds the lifecycle owner by looking up a getter of Compose UI 1.6 by name (reflection). R8 removed that getter from the release build. | Keep rule in `app/proguard-rules.pro`. | Not yet: needs the next release build installed on the phone. |
| 2026-10-19 | Infinix X675 (user report, not measured) | The internet feels slow when Wi-Fi Only and Mobile Data Only rules are used together. | Not measured. Found by reading the code: (1) all captured flows are handled by one engine thread and every new connection or DNS lookup makes three blocking calls on it (owner lookup, bindSocket, protect); (2) with both rule types the tunnel listed Wi-Fi and cellular as underlying networks, so Android flagged it metered and some apps then lower quality; (3) a 300 ms retransmit timeout made short engine stalls resend whole windows; (4) a DNS query was lost when the send to the first server failed. | Mixed rules: the tunnel follows the default network. Initial retransmit timeout 1000 ms. DNS send fails over to the next server. The one-thread design is unchanged. | Not yet: needs the next build on the phone (test J1). |
| 2026-10-21 | Infinix X675 (user report, not measured) | The phone gets hot when many apps have rules; the app seems badly optimized. | Not measured, no profiler or compiler was available. Found by reading the code: (1) every packet cost several fresh arrays, so the garbage collector ran constantly behind a busy tunnel; (2) tunnel MTU 1500 means about six times more packets than necessary for bulk transfers, and each packet costs system calls and a kernel pass; (3) the reader thread issued a selector wake-up for packets that arrived while the engine was busy; (4) a window update counted as a duplicate ACK and could make a flow resend its whole window; (5) a flow dropped and re-allocated its large buffer after every burst. | See section 13 of ARCHITECTURE.md: MTU 9000 with a setting to go back, pooled and reused buffers, wake-up only when the engine sleeps, RFC 5681 duplicate ACKs, faster checksum. | Not yet: needs the next build on the phone (tests J2 and J3). |
