package dev.netcontrol.app.ui.screens

import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.netcontrol.app.R
import dev.netcontrol.app.data.ThemeMode
import dev.netcontrol.app.ui.MainViewModel
import dev.netcontrol.app.ui.ProtectionControl
import dev.netcontrol.app.ui.Routes
import dev.netcontrol.app.ui.components.InfoRow
import dev.netcontrol.app.ui.components.PolicyMenu
import dev.netcontrol.app.ui.components.ScreenHeader
import dev.netcontrol.app.ui.components.SectionCard
import dev.netcontrol.app.ui.theme.LocalStatusColors
import dev.netcontrol.app.vpn.Phase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, control: ProtectionControl, onNavigate: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val status by vm.status.collectAsStateWithLifecycle()
    val net by vm.net.collectAsStateWithLifecycle()
    val rules by vm.rules.collectAsStateWithLifecycle()
    val sc = LocalStatusColors.current
    var confirmReset by remember { mutableStateOf(false) }
    val running = status.phase == Phase.RUNNING

    val consentGranted = remember(status.phase) { VpnService.prepare(ctx) == null }
    val notificationsOn = remember(status.phase, settings.persistentNotification) {
        NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }
    val batteryExempt = remember(status.phase) {
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    }
    val version = remember {
        try {
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
            (pi.versionName ?: "?") + " (" + pi.longVersionCode + ")"
        } catch (e: Exception) {
            "?"
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) {
            val text = vm.buildReport()
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray()) }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                Toast.makeText(ctx, if (ok) R.string.diag_saved else R.string.diag_save_failed, Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        ScreenHeader(stringResource(R.string.nav_settings), null)
        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            SectionCard(stringResource(R.string.dash_protection)) {
                SwitchRow(
                    stringResource(R.string.set_protection),
                    stringResource(R.string.set_protection_desc),
                    running
                ) { on -> if (on) control.requestStart() else control.stop() }
                OutlinedButton(onClick = { vm.reapplyRules() }, enabled = running, modifier = Modifier.fillMaxWidth()) {
                    Icon(painterResource(R.drawable.ic_refresh), null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.set_restore))
                }
                Text(
                    stringResource(R.string.set_restore_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            SectionCard(stringResource(R.string.set_notification)) {
                SwitchRow(
                    stringResource(R.string.set_notification),
                    stringResource(R.string.set_notification_desc),
                    settings.persistentNotification
                ) { vm.setPersistentNotification(it) }
            }

            SectionCard(stringResource(R.string.set_default_title)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.set_default_desc),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    PolicyMenu(settings.defaultPolicy) { vm.setDefaultPolicy(it) }
                }
            }

            SectionCard(stringResource(R.string.set_ipv6)) {
                SwitchRow(
                    stringResource(R.string.set_ipv6),
                    stringResource(R.string.set_ipv6_desc),
                    settings.ipv6
                ) { vm.setIpv6(it) }
            }

            SectionCard(stringResource(R.string.set_large_packets)) {
                SwitchRow(
                    stringResource(R.string.set_large_packets),
                    stringResource(R.string.set_large_packets_desc),
                    settings.largePackets
                ) { vm.setLargePackets(it) }
            }

            SectionCard(stringResource(R.string.set_theme)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = settings.theme == ThemeMode.DARK,
                        onClick = { vm.setTheme(ThemeMode.DARK) },
                        label = { Text(stringResource(R.string.theme_dark)) }
                    )
                    FilterChip(
                        selected = settings.theme == ThemeMode.LIGHT,
                        onClick = { vm.setTheme(ThemeMode.LIGHT) },
                        label = { Text(stringResource(R.string.theme_light)) }
                    )
                    FilterChip(
                        selected = settings.theme == ThemeMode.SYSTEM,
                        onClick = { vm.setTheme(ThemeMode.SYSTEM) },
                        label = { Text(stringResource(R.string.theme_system)) }
                    )
                }
            }

            SectionCard(stringResource(R.string.set_permissions)) {
                InfoRow(
                    stringResource(R.string.perm_vpn),
                    stringResource(if (consentGranted) R.string.perm_granted else R.string.perm_vpn_needed),
                    if (consentGranted) sc.ok else sc.warn
                )
                InfoRow(
                    stringResource(R.string.perm_notif),
                    stringResource(if (notificationsOn) R.string.perm_granted else R.string.perm_denied),
                    if (notificationsOn) sc.ok else sc.warn
                )
                InfoRow(
                    stringResource(R.string.perm_battery),
                    stringResource(if (batteryExempt) R.string.perm_battery_exempt else R.string.perm_battery_optimized)
                )
                InfoRow(stringResource(R.string.perm_packages), stringResource(R.string.perm_packages_value))
                OutlinedButton(
                    onClick = { openSettings(ctx, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.perm_battery_open)) }
            }

            SectionCard(stringResource(R.string.set_vpn_status)) {
                InfoRow(
                    stringResource(R.string.diag_service_status),
                    stringResource(if (running) R.string.status_running else R.string.status_stopped),
                    if (running) sc.ok else sc.warn
                )
                InfoRow(
                    stringResource(R.string.dash_vpn),
                    stringResource(
                        when {
                            net.otherVpnActive -> R.string.vpn_other
                            running -> R.string.vpn_ours
                            else -> R.string.vpn_none
                        }
                    ),
                    if (net.otherVpnActive) sc.warn else Color.Unspecified
                )
                Text(
                    stringResource(R.string.set_always_on_desc),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(
                    onClick = { openSettings(ctx, Intent(Settings.ACTION_VPN_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.set_always_on)) }
            }

            SectionCard(stringResource(R.string.set_data)) {
                OutlinedButton(
                    onClick = { saveLauncher.launch("netcontrol-report.txt") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(painterResource(R.drawable.ic_save), null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.set_export))
                }
                OutlinedButton(
                    onClick = { confirmReset = true },
                    enabled = rules.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(painterResource(R.drawable.ic_delete), null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(stringResource(R.string.set_reset))
                }
            }

            SectionCard(stringResource(R.string.nav_about)) {
                InfoRow(stringResource(R.string.set_version), version)
                Row(
                    Modifier.fillMaxWidth().clickable { onNavigate(Routes.PRIVACY) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.set_privacy), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    Icon(painterResource(R.drawable.ic_chevron), null, Modifier.size(20.dp))
                }
                Row(
                    Modifier.fillMaxWidth().clickable { onNavigate(Routes.ABOUT) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(stringResource(R.string.nav_about), style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                    Icon(painterResource(R.drawable.ic_chevron), null, Modifier.size(20.dp))
                }
            }
            Spacer(Modifier.size(8.dp))
        }
    }

    if (confirmReset) {
        ResetDialog(onConfirm = {
            confirmReset = false
            vm.resetAllRules()
        }, onDismiss = { confirmReset = false })
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun openSettings(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent)
    } catch (e: Exception) {
        // no handler for this settings page on this device
    }
}
