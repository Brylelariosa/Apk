package com.circuitsandbox.app.render

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import com.circuitsandbox.app.model.ComponentInstance
import com.circuitsandbox.app.model.ComponentType
import com.circuitsandbox.app.simulation.CircuitPinStates
import kotlin.math.sin

/**
 * Draws every component as a procedural vector shape (Path / Canvas
 * primitives only — never a bitmap), so components stay crisp at any zoom
 * level and the APK never has to ship per-density PNG assets for them.
 *
 * All Paint objects are held as reusable fields and mutated per draw call
 * rather than allocated fresh, since this runs once per visible component
 * every frame.
 */
object GateRenderer {

    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pinStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val pinDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val pinWarnPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        textSize = 22f
    }
    private val pinLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 16f
    }
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val badgeStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f }
    private val reusableRect = RectF()

    fun draw(
        canvas: Canvas,
        component: ComponentInstance,
        theme: CircuitTheme,
        pins: CircuitPinStates,
        isSelected: Boolean,
        hasError: Boolean,
        animationPhase: Float = 0f,
        /** Only meaningful (and only ever non-null) when [hasError] is true:
         * the set of input-pin indices that currently have a wire attached,
         * so the renderer can put a warning marker on the ones that don't —
         * i.e. actually floating pins — rather than mislabeling the whole
         * component. */
        connectedInputPins: Set<Int>? = null
    ) {
        canvas.save()
        canvas.translate(component.x, component.y)
        canvas.rotate(component.rotationDegrees.toFloat())
        if (component.mirrored) canvas.scale(-1f, 1f)

        outlinePaint.color = when {
            isSelected -> theme.selectionHighlight
            hasError -> theme.wireError
            else -> theme.componentOutline
        }
        fillPaint.color = theme.componentFill
        textPaint.color = theme.textColor

        val halfW = component.width / 2f
        val halfH = component.height / 2f
        val primaryHigh = pins.primaryState(component)

        when (component.type) {
            ComponentType.AND -> drawAndShape(canvas, halfW, halfH)
            ComponentType.OR -> drawOrShape(canvas, halfW, halfH, withExtraCurve = false)
            ComponentType.XOR -> drawOrShape(canvas, halfW, halfH, withExtraCurve = true)
            ComponentType.NAND -> { drawAndShape(canvas, halfW, halfH); drawBubble(canvas, halfW) }
            ComponentType.NOR -> { drawOrShape(canvas, halfW, halfH, false); drawBubble(canvas, halfW) }
            ComponentType.XNOR -> { drawOrShape(canvas, halfW, halfH, true); drawBubble(canvas, halfW) }
            ComponentType.NOT -> { drawTriangle(canvas, halfW, halfH); drawBubble(canvas, halfW) }
            ComponentType.BUFFER -> drawTriangle(canvas, halfW, halfH)
            ComponentType.INPUT_SWITCH, ComponentType.PUSH_BUTTON ->
                drawSwitch(canvas, halfW, halfH, primaryHigh, theme)
            ComponentType.POWER -> drawRail(canvas, halfW, halfH, theme, isPower = true, label = component.label)
            ComponentType.GROUND -> drawRail(canvas, halfW, halfH, theme, isPower = false, label = component.label)
            ComponentType.CLOCK -> drawClock(canvas, halfW, halfH, primaryHigh, theme)
            ComponentType.OUTPUT_LED -> drawLed(canvas, halfW, halfH, primaryHigh, theme, animationPhase)
            ComponentType.SEVEN_SEG_DISPLAY -> drawSevenSegment(canvas, halfW, halfH, component, pins, theme)
            // Every sequential/arithmetic type (latches, flip-flops, mux,
            // decoder, adder) plus any future type not explicitly cased
            // above shares this generic labeled block — see drawIcBlock().
            // (Kotlin's exhaustiveness checker doesn't accept "in aSetOf(...)"
            // as covering specific enum branches, so this has to be `else`
            // rather than a set-membership check, even though the set of
            // types it actually applies to is fixed and known.)
            else -> drawIcBlock(canvas, halfW, halfH)
        }

        val showsOwnLabel = component.type == ComponentType.POWER || component.type == ComponentType.GROUND ||
            component.type == ComponentType.SEVEN_SEG_DISPLAY
        // An LED with no custom label stays a bare, unlabeled circle — the
        // way every beginner example (LED Switch, AND Gate, ...) intends
        // it to look — but an example that *does* label its LEDs (Sum,
        // Carry, DISPENSE, Q, ...) needs that text to actually be
        // meaningful, since that label is often the only thing telling
        // two otherwise-identical LEDs apart.
        val skipLabel = component.type == ComponentType.OUTPUT_LED && component.label == null
        if (!showsOwnLabel && !skipLabel) {
            canvas.drawText(component.label ?: component.type.displayName, 0f, halfH + 26f, textPaint)
        }

        drawPins(canvas, component, halfW, theme, pins, hasError, connectedInputPins)

        if (component.locked) drawLockBadge(canvas, halfW, halfH, theme)
        if (component.groupId != null) drawGroupBadge(canvas, halfW, halfH, theme)

        canvas.restore()
    }

    /** Classic ANSI "D" shape: flat left/top/bottom edges, semicircular right bulge. */
    private fun drawAndShape(canvas: Canvas, halfW: Float, halfH: Float) {
        val path = Path()
        path.moveTo(-halfW, -halfH)
        path.lineTo(0f, -halfH)
        reusableRect.set(-halfH, -halfH, halfH, halfH)
        path.arcTo(reusableRect, -90f, 180f, false)
        path.lineTo(-halfW, halfH)
        path.close()
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, outlinePaint)
    }

    /** Curved "shield" OR-gate shape; XOR adds the extra leading curve. */
    private fun drawOrShape(canvas: Canvas, halfW: Float, halfH: Float, withExtraCurve: Boolean) {
        val path = Path()
        path.moveTo(-halfW, -halfH)
        path.quadTo(-halfW * 0.2f, -halfH, halfW, 0f)
        path.quadTo(-halfW * 0.2f, halfH, -halfW, halfH)
        path.quadTo(-halfW * 0.5f, 0f, -halfW, -halfH)
        path.close()
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, outlinePaint)
        if (withExtraCurve) {
            val extra = Path()
            extra.moveTo(-halfW * 1.25f, -halfH)
            extra.quadTo(-halfW * 0.75f, 0f, -halfW * 1.25f, halfH)
            canvas.drawPath(extra, outlinePaint)
        }
    }

    /** NOT/Buffer triangle, point facing right. */
    private fun drawTriangle(canvas: Canvas, halfW: Float, halfH: Float) {
        val path = Path()
        path.moveTo(-halfW, -halfH)
        path.lineTo(-halfW, halfH)
        path.lineTo(halfW * 0.8f, 0f)
        path.close()
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, outlinePaint)
    }

    /** Small inversion bubble used by NAND/NOR/XNOR/NOT. */
    private fun drawBubble(canvas: Canvas, halfW: Float) {
        val r = halfW * 0.12f
        canvas.drawCircle(halfW * 0.95f, 0f, r, fillPaint)
        canvas.drawCircle(halfW * 0.95f, 0f, r, outlinePaint)
    }

    /** Generic labeled rounded-rectangle body shared by every sequential
     * and arithmetic "IC-style" component — a deliberately neutral shape,
     * since these are distinguished from each other by their pin labels
     * and displayed name rather than a bespoke silhouette per type. */
    private fun drawIcBlock(canvas: Canvas, halfW: Float, halfH: Float) {
        reusableRect.set(-halfW, -halfH, halfW, halfH)
        canvas.drawRoundRect(reusableRect, 8f, 8f, fillPaint)
        canvas.drawRoundRect(reusableRect, 8f, 8f, outlinePaint)
    }

    private fun drawSwitch(canvas: Canvas, halfW: Float, halfH: Float, on: Boolean, theme: CircuitTheme) {
        reusableRect.set(-halfW, -halfH, halfW, halfH)
        canvas.drawRoundRect(reusableRect, 10f, 10f, fillPaint)
        canvas.drawRoundRect(reusableRect, 10f, 10f, outlinePaint)
        accentPaint.style = Paint.Style.FILL
        accentPaint.color = if (on) theme.wireHigh else theme.wireLow
        canvas.drawCircle(if (on) halfW * 0.4f else -halfW * 0.4f, 0f, halfH * 0.5f, accentPaint)
    }

    private fun drawRail(canvas: Canvas, halfW: Float, halfH: Float, theme: CircuitTheme, isPower: Boolean, label: String?) {
        accentPaint.style = Paint.Style.STROKE
        accentPaint.strokeWidth = 4f
        accentPaint.color = theme.componentOutline
        if (isPower) {
            canvas.drawLine(0f, -halfH, 0f, 0f, accentPaint)
            canvas.drawLine(-halfW * 0.6f, 0f, halfW * 0.6f, 0f, accentPaint)
        } else {
            canvas.drawLine(0f, -halfH, 0f, 0f, accentPaint)
            canvas.drawLine(-halfW * 0.7f, 0f, halfW * 0.7f, 0f, accentPaint)
            canvas.drawLine(-halfW * 0.45f, halfH * 0.3f, halfW * 0.45f, halfH * 0.3f, accentPaint)
            canvas.drawLine(-halfW * 0.2f, halfH * 0.6f, halfW * 0.2f, halfH * 0.6f, accentPaint)
        }
        canvas.drawText(label ?: (if (isPower) "1" else "GND"), 0f, halfH + 26f, textPaint)
    }

    private fun drawClock(canvas: Canvas, halfW: Float, halfH: Float, high: Boolean, theme: CircuitTheme) {
        reusableRect.set(-halfW, -halfH, halfW, halfH)
        canvas.drawRoundRect(reusableRect, 10f, 10f, fillPaint)
        canvas.drawRoundRect(reusableRect, 10f, 10f, outlinePaint)

        val w = halfW * 0.6f
        val h = halfH * 0.4f
        val wave = Path()
        wave.moveTo(-w, h)
        wave.lineTo(-w / 2, h)
        wave.lineTo(-w / 2, -h)
        wave.lineTo(w / 2, -h)
        wave.lineTo(w / 2, h)
        wave.lineTo(w, h)

        accentPaint.style = Paint.Style.STROKE
        accentPaint.strokeWidth = 3f
        accentPaint.color = if (high) theme.wireHigh else theme.wireLow
        canvas.drawPath(wave, accentPaint)
    }

    private fun drawLed(canvas: Canvas, halfW: Float, halfH: Float, on: Boolean, theme: CircuitTheme, animationPhase: Float) {
        val radius = minOf(halfW, halfH) * 0.85f
        if (on) {
            // Subtle pulsing glow rather than a static radius — small
            // amplitude so it reads as "alive" without being distracting.
            val pulse = 1f + 0.12f * sin(animationPhase * 2f * Math.PI).toFloat()
            val glowRadius = radius * 2.6f * pulse
            glowPaint.shader = RadialGradient(
                0f, 0f, glowRadius,
                theme.ledOnColor, 0x00000000, Shader.TileMode.CLAMP
            )
            canvas.drawCircle(0f, 0f, glowRadius, glowPaint)
        }
        fillPaint.color = if (on) theme.ledOnColor else theme.ledOffColor
        canvas.drawCircle(0f, 0f, radius, fillPaint)
        canvas.drawCircle(0f, 0f, radius, outlinePaint)
    }

    /** Standard 7-segment glyph. Segments are lettered a (top) through g
     * (middle) going clockwise, matching every textbook diagram, decoded
     * from the 4-bit binary value currently on the component's input pins. */
    private fun drawSevenSegment(
        canvas: Canvas, halfW: Float, halfH: Float,
        component: ComponentInstance, pins: CircuitPinStates, theme: CircuitTheme
    ) {
        reusableRect.set(-halfW, -halfH, halfW, halfH)
        fillPaint.color = theme.componentFill
        canvas.drawRoundRect(reusableRect, 6f, 6f, fillPaint)
        canvas.drawRoundRect(reusableRect, 6f, 6f, outlinePaint)

        var value = 0
        for (bit in 0 until component.type.inputCount) {
            if (pins.inputAt(component.id, bit)) value = value or (1 shl bit)
        }
        val pattern = SEVEN_SEG_PATTERNS.getOrElse(value) { SEVEN_SEG_PATTERNS[0] }

        val w = halfW * 0.5f
        val h = halfH * 0.35f
        val t = halfH * 0.12f // segment thickness

        accentPaint.style = Paint.Style.FILL
        fun seg(on: Boolean, path: Path) {
            accentPaint.color = if (on) theme.ledOnColor else theme.ledOffColor
            canvas.drawPath(path, accentPaint)
        }
        // a: top, b: upper-right, c: lower-right, d: bottom, e: lower-left,
        // f: upper-left, g: middle.
        seg(pattern[0], hSegment(0f, -h, w, t))
        seg(pattern[1], vSegment(w, -h / 2, h, t))
        seg(pattern[2], vSegment(w, h / 2, h, t))
        seg(pattern[3], hSegment(0f, h, w, t))
        seg(pattern[4], vSegment(-w, h / 2, h, t))
        seg(pattern[5], vSegment(-w, -h / 2, h, t))
        seg(pattern[6], hSegment(0f, 0f, w, t))

        canvas.drawText(value.toString(16).uppercase(), 0f, halfH + 26f, textPaint)
    }

    private fun hSegment(cx: Float, cy: Float, halfLen: Float, thickness: Float): Path {
        val path = Path()
        val hw = halfLen - thickness * 0.5f
        val ht = thickness / 2f
        path.moveTo(cx - hw, cy - ht); path.lineTo(cx + hw, cy - ht)
        path.lineTo(cx + hw + ht, cy); path.lineTo(cx + hw, cy + ht)
        path.lineTo(cx - hw, cy + ht); path.lineTo(cx - hw - ht, cy)
        path.close()
        return path
    }

    private fun vSegment(cx: Float, cy: Float, halfLen: Float, thickness: Float): Path {
        val path = Path()
        val hh = halfLen - thickness * 0.5f
        val ht = thickness / 2f
        path.moveTo(cx - ht, cy - hh); path.lineTo(cx + ht, cy - hh)
        path.lineTo(cx + ht, cy + hh); path.lineTo(cx, cy + hh + ht)
        path.lineTo(cx - ht, cy + hh)
        path.close()
        return path
    }

    private fun drawLockBadge(canvas: Canvas, halfW: Float, halfH: Float, theme: CircuitTheme) {
        val cx = halfW - 10f
        val cy = -halfH + 10f
        badgePaint.color = theme.canvasBackground
        canvas.drawCircle(cx, cy, 9f, badgePaint)
        badgeStrokePaint.color = theme.selectionHighlight
        canvas.drawCircle(cx, cy, 9f, badgeStrokePaint)
        val body = RectF(cx - 4f, cy - 1f, cx + 4f, cy + 5f)
        badgePaint.color = theme.selectionHighlight
        canvas.drawRoundRect(body, 1.5f, 1.5f, badgePaint)
        val shackle = RectF(cx - 2.5f, cy - 5f, cx + 2.5f, cy + 1f)
        badgeStrokePaint.strokeWidth = 1.6f
        canvas.drawArc(shackle, 180f, 180f, false, badgeStrokePaint)
        badgeStrokePaint.strokeWidth = 2.5f
    }

    private fun drawGroupBadge(canvas: Canvas, halfW: Float, halfH: Float, theme: CircuitTheme) {
        val cx = -halfW + 10f
        val cy = -halfH + 10f
        badgePaint.color = theme.canvasBackground
        canvas.drawCircle(cx, cy, 9f, badgePaint)
        badgeStrokePaint.color = theme.wireHigh
        canvas.drawCircle(cx, cy, 9f, badgeStrokePaint)
        badgeStrokePaint.strokeWidth = 1.6f
        canvas.drawCircle(cx - 2.5f, cy, 3f, badgeStrokePaint)
        canvas.drawCircle(cx + 2.5f, cy, 3f, badgeStrokePaint)
        badgeStrokePaint.strokeWidth = 2.5f
    }

    private fun drawPins(
        canvas: Canvas,
        component: ComponentInstance,
        halfW: Float,
        theme: CircuitTheme,
        pins: CircuitPinStates,
        hasError: Boolean,
        connectedInputPins: Set<Int>?
    ) {
        val inputLabels = component.type.inputLabels
        for (i in 0 until component.type.inputCount) {
            val localY = pinLocalY(i, component.type.inputCount)
            val high = pins.inputAt(component.id, i)
            val color = if (high) theme.wireHigh else theme.wireLow
            pinStrokePaint.color = color
            pinDotPaint.color = color
            canvas.drawLine(-halfW, localY, -halfW - 14f, localY, pinStrokePaint)
            canvas.drawCircle(-halfW - 14f, localY, 5f, pinDotPaint)

            val isFloatingPin = hasError && connectedInputPins != null && i !in connectedInputPins
            if (isFloatingPin) {
                pinWarnPaint.color = theme.wireError
                canvas.drawCircle(-halfW - 14f, localY, 9f, pinWarnPaint)
            }
            if (i < inputLabels.size && inputLabels[i].isNotEmpty()) {
                pinLabelPaint.color = theme.textColor
                pinLabelPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText(inputLabels[i], -halfW - 18f, localY - 6f, pinLabelPaint)
            }
        }

        val outputLabels = component.type.outputLabels
        for (i in 0 until component.type.outputCount) {
            val localY = pinLocalY(i, component.type.outputCount)
            val high = pins.outputAt(component.id, i)
            val color = if (high) theme.wireHigh else theme.wireLow
            pinStrokePaint.color = color
            pinDotPaint.color = color
            canvas.drawLine(halfW, localY, halfW + 14f, localY, pinStrokePaint)
            canvas.drawCircle(halfW + 14f, localY, 5f, pinDotPaint)
            if (i < outputLabels.size && outputLabels[i].isNotEmpty()) {
                pinLabelPaint.color = theme.textColor
                pinLabelPaint.textAlign = Paint.Align.LEFT
                canvas.drawText(outputLabels[i], halfW + 18f, localY - 6f, pinLabelPaint)
            }
        }
    }

    private fun pinLocalY(index: Int, count: Int): Float {
        val spacing = ComponentInstance.PIN_SPACING
        val totalSpan = (count - 1).coerceAtLeast(0) * spacing
        return -totalSpan / 2f + index * spacing
    }

    // Segment pattern table indexed 0-15 (hex digit), each entry is
    // [a, b, c, d, e, f, g] — true means that segment is lit.
    private val SEVEN_SEG_PATTERNS = arrayOf(
        booleanArrayOf(true, true, true, true, true, true, false),   // 0
        booleanArrayOf(false, true, true, false, false, false, false), // 1
        booleanArrayOf(true, true, false, true, true, false, true),   // 2
        booleanArrayOf(true, true, true, true, false, false, true),   // 3
        booleanArrayOf(false, true, true, false, false, true, true),  // 4
        booleanArrayOf(true, false, true, true, false, true, true),   // 5
        booleanArrayOf(true, false, true, true, true, true, true),    // 6
        booleanArrayOf(true, true, true, false, false, false, false), // 7
        booleanArrayOf(true, true, true, true, true, true, true),     // 8
        booleanArrayOf(true, true, true, true, false, true, true),    // 9
        booleanArrayOf(true, true, true, false, true, true, true),    // A
        booleanArrayOf(false, false, true, true, true, true, true),   // b
        booleanArrayOf(true, false, false, true, true, true, false),  // C
        booleanArrayOf(false, true, true, true, true, false, true),   // d
        booleanArrayOf(true, false, false, true, true, true, true),   // E
        booleanArrayOf(true, false, false, false, true, true, true)   // F
    )
}
