# Digital Circuit Sandbox

A native Android digital-logic circuit editor and simulator. 100% offline —
no network permission is requested anywhere in the manifest, and the
project has zero ad/analytics/account dependencies.

## Status

This build extends the `0.1.0-foundation` release with sequential logic,
a fully rebuilt canvas/interaction layer, and a much larger example
library. It's still an honest, incremental step rather than a claim of
"fully complete, every possible feature" — see **Known limitations**
below for exactly what's still rough or out of scope.

**I still cannot compile or run this inside the sandbox I build it in**
(no network access, no Android SDK/NDK installed there). Every change in
this round was written and cross-checked by hand — component-by-component
truth tables for every sequential/FSM example were derived and verified
against the wiring before being committed to code — but a real build is
still the first real test. Please treat build failures as expected-until-
proven-otherwise and send back the log if you hit one; that's the fastest
way for the next round to fix it correctly instead of guessing.

**Implemented**
- Native C++ simulation engine (event-driven propagation, oscillation
  detection, floating-input detection, per-pin short-circuit detection),
  reached from Kotlin over a real JNI bridge.
- 24 component types: the original 14 (Switch, Push Button, Power, Ground,
  Clock, LED, AND/OR/XOR/XNOR/NAND/NOR/NOT/Buffer) plus 10 new ones —
  SR Latch, D Latch, D/JK/T Flip-Flop, 2:1 and 4:1 Multiplexer, 2-to-4
  Decoder, Full Adder, and a 7-Segment Display.
- Infinite pan/zoom canvas backed by a spatial grid index (hit-testing and
  viewport culling touch only nearby components, not the whole circuit),
  correct two-finger pan + pinch-zoom in one gesture, box and lasso
  multi-select, a live minimap with tap-to-navigate, lock and group tools,
  align/distribute (6 alignments + 2 distribute modes).
- Play / Pause / **Step** (single-tick advance) / **Speed** (2–240
  ticks/sec) — pausing and resuming now preserves every flip-flop/latch/
  counter's state instead of silently resetting the circuit.
- 27 example circuits (was 10, several of which were placeholders): the
  original beginner/intermediate/advanced set plus SR Latch, D/JK Flip-
  Flop, 4-bit Binary Counter, Seven-Segment Counter, Traffic Light
  Controller, 4:1 Multiplexer, 2-to-4 Decoder, 4-bit Register, 1-Bit
  Memory Cell, Digital Safe, 4-bit Adder, Simple 1-Bit ALU, a hand-
  verified "1011" Sequence Detector, an Elevator Door Controller, a 15¢
  Vending Machine FSM, and a CPU Building Blocks demo. Every example now
  shows its "How it works" explanation (previously stored but never
  displayed anywhere in the UI).
- Named multi-project Save/Load with a delete-capable picker, plus
  autosave-on-background with a restore-on-launch prompt.
- Undo/redo via command pattern, now also covering lock/group/align/
  distribute.
- Three canvas themes (Dark/Light/Blueprint) independent of system
  day/night, which controls the app chrome via Material 3.

**Still not implemented / explicitly out of scope for this round** —
custom reusable sub-circuit modules, full obstacle-avoiding wire auto-
routing (see Known limitations), gate-level timing/power analysis, a
screen-reader-accessible representation of the freeform canvas itself
(buttons/dialogs have content descriptions; the canvas is still a single
opaque custom `View` to TalkBack), component/wire inline tooltips.

## Changelog (this round)

**Fixed from your CI run:**
`:app:compileReleaseKotlin` failed with `'when' expression must be
exhaustive` in `GateRenderer.kt`. Cause: the `when (component.type)`
block used `in icBlockTypes -> ...` (a runtime set-membership check) to
cover the 9 sequential/arithmetic component types, but Kotlin's
exhaustiveness checker can't statically prove a `Set<ComponentType>`
value's contents at compile time — so even though every type actually
was handled, the compiler couldn't see that and demanded explicit
branches or an `else`. Everything else in that run — CMake configure and
build for all three ABIs (arm64-v8a, armeabi-v7a, x86_64), resource
merging/compilation, manifest processing — succeeded before hitting this,
which is a good sign for the rest of the native/build changes below.
Fixed by replacing that branch with `else -> drawIcBlock(...)`, which
also makes it the sensible default for any future component type that
isn't explicitly cased.

**Simulation engine**
- Extended `GateType`/`ComponentType` with 10 new component types,
  appended after the original 14 so saved `.dcs.json` files with the old
  ordinals still decode correctly.
- `Gate::evaluate()` rewritten to compute *every* output pin (previously
  only pin 0), which is what made multi-output components — flip-flops'
  Q/Q', the decoder's four outputs, the adder's Sum/Carry — possible at
  all without silently truncating to one bit.
- Added rising-edge detection (`prevClockInput_`) for the 5 sequential
  gate types; verified it can't double-trigger within a tick even though
  the propagation loop may call `evaluate()` on the same gate more than
  once while settling (see the comment on `Gate::evaluate`).
- Short-circuit detection now reports the specific `(gateId, pinIndex)`
  pairs involved, not just a boolean — the UI can now highlight exactly
  which wires are conflicting instead of only a generic warning.

**Real bugs fixed**
- **Two-finger pan silently did nothing.** The pinch-zoom math only used
  the current frame's focus point in both halves of its formula, which
  mathematically cancels out any panning component — only zoom-in-place
  ever worked. Rewrote it to track the focus point across frames so one
  formula now correctly handles pan, zoom, and simultaneous pan+zoom.
- **A second finger touching down mid-drag could teleport a component.**
  `ACTION_POINTER_DOWN` wasn't handled at all, so an in-progress single-
  finger component/wire drag kept consuming move events (always from
  pointer index 0) while a pinch gesture also started — now any single-
  pointer gesture is cleanly cancelled the instant a second pointer joins.
- **Pausing and resuming the simulation reset all state.** `rebuild()`
  was called on every Play tap, discarding every latch/flip-flop/counter
  value. It's now only called when the circuit topology actually changed
  (tracked via a `simulationDirty` flag set on every topology-changing
  edit, undo, and redo).
- **Input pins never showed their live value** — only output pins were
  colored by signal state; input pins were always drawn in a fixed
  neutral color.
- **A floating-input warning had no way to show *which* pin was
  floating** — wires can't represent "floating" (floating means *no*
  wire), so that indication was moved to the actual unconnected pin.
- **Per-component labels were invisible.** `ComponentInstance.label`
  existed and was being set (e.g. by earlier example circuits) but
  `GateRenderer` always drew the generic type name instead — meaningless
  for any example that needs to distinguish two otherwise-identical
  switches (e.g. Vending Machine's NICKEL/DIME).
- **`MoveComponentCommand` didn't update the spatial index**, which would
  have left stale hit-test/culling entries after any undo/redo of a drag
  once the index was introduced this round.
- Save/load silently crashed the whole load on encountering any component
  type it didn't recognize (e.g. a newer save opened by an older build);
  now skips just that one component.
- "Load Project" only ever loaded the single most recent save and
  "Save" always overwrote one hardcoded file — despite `ProjectRepository`
  already supporting multiple named projects. Replaced with a real
  Save-As dialog and a Load picker with per-project delete.

**New tools**
- Lock / unlock components (protects position + deletion, still
  simulates).
- Group / ungroup (grouped components select, move, rotate, and mirror
  together).
- Align (left/right/top/bottom/horizontal-centers/vertical-centers) and
  Distribute (horizontal/vertical) for multi-selections.
- Minimap with tap/drag-to-navigate, toggleable from the overflow menu.
- Step (single simulation tick) and an adjustable speed control
  (2–240 ticks/sec).
- Reset Simulation (forces every flip-flop/latch back to its initial
  state without needing a topology edit).
- A small persistent warning banner explaining *what* is wrong
  (floating input / oscillation / short circuit) instead of only a
  colored outline with no explanation.

**Performance**
- `CircuitModel` gained a uniform-grid spatial index (component add/
  remove/move are O(1) amortized); hit-testing (`componentAt`) and
  viewport culling now only scan nearby grid cells instead of every
  component in the circuit, which is the main lever for the "large
  circuits at 60fps" goal.
- Pin/wire touch targets scale with zoom level in physical (dp) units
  instead of fixed world-space units, so they don't become harder to hit
  when zoomed out.
- Native build: added `-ffunction-sections -fdata-sections` +
  `--gc-sections` (strips unused code at link time) and switched
  `ANDROID_STL` from `c++_shared` to `c++_static` — this app links
  exactly one native library, so static linking avoids bundling a
  separate `libc++_shared.so` per ABI, which is the recommended NDK
  practice for single-library apps and should reduce total APK size.
  `-O2` (not `-Os`) was kept deliberately — this is a real-time
  interactive simulator, so trading a little binary size for simulation
  speed is the right call here.

**UI**
- Contextual action bar now scrolls horizontally (8 actions no longer
  clip or shrink on narrow phones) and gained Lock, Group, and an
  Align/Distribute popup menu.
- Component inspector rewritten: now scrollable, shows each component's
  pin layout (S/R, D/CLK, Q/Q', etc.) and, for components with no static
  truth table (anything with memory), an explanation of why instead of
  silently showing an empty table.
- Example browser now displays each example's "How it works" text.

## Architecture

```
app/src/main/
  cpp/                     # native simulation engine (C++17, JNI)
    CMakeLists.txt
    jni_bridge.cpp
    core/
      gate_types.h          # GateType enum — ordinal must mirror ComponentType.kt
      gate.h / gate.cpp      # single-gate evaluation logic
      simulation_engine.h/.cpp  # graph, propagation, error detection
  java/com/circuitsandbox/app/
    model/        # CircuitModel (+ spatial index), ComponentInstance, WireInstance,
                  # AlignmentTypes, ExampleLibrary/ExampleCircuit — pure data
    simulation/   # NativeSimulation (JNI wrapper), SimulationController (loop + CircuitPinStates)
    render/       # GateRenderer, WireRenderer, GridRenderer, CircuitTheme
    ui/           # CircuitCanvasView (gestures + drawing + minimap), MainActivity
    undo/         # Command pattern + CommandHistory (incl. Lock/Group/Align/Distribute)
    persistence/  # CircuitSerializer (org.json), ProjectRepository
```

## Known limitations / rough edges to expect

- Wire routing is still a Manhattan (orthogonal, single-bend) path with a
  size-aware minimum stub length — it avoids cutting through its own two
  endpoint components but does **not** route around a third component
  sitting in the way. Full obstacle-avoiding pathfinding (A* or similar)
  is a meaningfully larger, separate piece of work.
- The minimap redraws every circuit component as a dot every frame it's
  visible — cheap per-component, but on genuinely huge circuits (many
  thousands of components) this is worth profiling; it can be turned off
  from the overflow menu if it's ever a bottleneck.
- The canvas is one custom `View`; screen-reader users get content
  descriptions on every button/dialog but not a navigable representation
  of individual components on the canvas itself.
- `gradlew`/`gradlew.bat` are streamlined rewrites of the standard Gradle
  wrapper scripts, not byte-identical to the official ones (unchanged
  from the previous round — regenerate with
  `gradle wrapper --gradle-version 8.6` if CI ever complains).
- ABI filters keep `x86_64` (useful for emulator testing); drop it from
  `defaultConfig.ndk.abiFilters` in `app/build.gradle.kts` if you want the
  smallest possible Play Store upload and don't need emulator builds.

## Build

```
./gradlew assembleDebug
```

requires Android SDK + NDK 25.2.9519653 + CMake 3.22.1 installed.

## Roadmap (suggested next steps)

1. **A real build + your CI run** — first priority, as always.
2. **Obstacle-avoiding wire routing** — the biggest remaining item from
   the original "Editing Tools" wishlist.
3. **Custom reusable modules** ("save this sub-circuit as a component") —
   architecturally this slots in as a new `ComponentType`-like entity
   backed by a nested `CircuitModel` rather than a native `GateType`,
   which is a bigger design decision worth discussing before building.
4. **Canvas accessibility** — a real screen-reader story for the
   component graph, not just the surrounding chrome.
5. **Timing/power analysis panels** — mostly UI on top of data the
   engine could be extended to compute.

Happy to keep building any of these next — just say which phase.
