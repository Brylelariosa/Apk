package com.voxelsandbox.game.world.streaming

import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.mesh.MeshData
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * One draw layer of a region (opaque/cut-out terrain, or water) as it goes to the GPU: the
 * vertex bytes and the index bytes of every sub-chunk of every column of the region,
 * concatenated, in direct buffers ready for glBufferData. The indices are ordered group by group
 * (all opaque triangles, then all cut-out, then all double-sided), see [MeshData.opaqueEnd].
 */
class PackedLayer(
    @JvmField val vertices: ByteBuffer,
    @JvmField val vertexBytes: Int,
    @JvmField val indices: ByteBuffer,
    @JvmField val indexBytes: Int,
    @JvmField val indexCount: Int,
    @JvmField val opaqueEnd: Int,
    @JvmField val cutoutEnd: Int,
    @JvmField val minY: Float,
    @JvmField val maxY: Float
) {
    val totalBytes: Int get() = vertexBytes + indexBytes
}

/**
 * A whole region, packed and waiting for the GL thread. [columns] lists the columns that were
 * present in the snapshot (including ones with nothing to draw): once this is uploaded exactly
 * those columns are on screen. A region whose layers are both null is empty (its columns were
 * unloaded), which tells the renderer to free its buffers.
 */
class PackedRegion(
    @JvmField val key: Long,
    @JvmField val solid: PackedLayer?,
    @JvmField val water: PackedLayer?,
    @JvmField val columns: LongArray,
    isUrgent: Boolean
) {
    /** A player edit: uploaded the frame it arrives, whatever the upload budget says. */
    @Volatile @JvmField var urgent: Boolean = isUrgent

    val totalBytes: Int get() = (solid?.totalBytes ?: 0) + (water?.totalBytes ?: 0)

    /** Hands the buffers back to [pool]; call once the data has been uploaded or dropped. */
    fun recycle(pool: DirectBufferPool) {
        solid?.let { pool.release(it.vertices); pool.release(it.indices) }
        water?.let { pool.release(it.vertices); pool.release(it.indices) }
    }
}

/**
 * Concatenates the meshes of one region's columns into upload buffers. Runs on the streaming
 * worker threads: the loops that shift indices and copy vertex floats used to run on the GL
 * thread, where they were a large share of the 4-9 ms a frame's mesh uploads cost. What is left
 * for the GL thread is one glBufferData per buffer.
 */
class RegionPacker(private val pool: DirectBufferPool) {
    private class Scratch {
        val solidParts = arrayOfNulls<MeshData>(PARTS)
        val waterParts = arrayOfNulls<MeshData>(PARTS)
        val offsets = IntArray(PARTS)
        var stage = IntArray(1 shl 16)
        val columns = LongArray(ColumnKeys.REGION_SIZE * ColumnKeys.REGION_SIZE)

        fun stage(count: Int): IntArray {
            if (stage.size < count) stage = IntArray(maxOf(count, stage.size * 3 / 2))
            return stage
        }
    }

    private val scratch = object : ThreadLocal<Scratch>() {
        override fun initialValue(): Scratch = Scratch()
    }

    fun pack(regionKey: Long, store: MeshStore, urgent: Boolean): PackedRegion {
        val s = scratch.get()!!
        val rx = ColumnKeys.regionX(regionKey)
        val rz = ColumnKeys.regionZ(regionKey)
        var present = 0
        var k = 0
        for (dz in 0 until ColumnKeys.REGION_SIZE) {
            for (dx in 0 until ColumnKeys.REGION_SIZE) {
                val key = ColumnKeys.column(rx * ColumnKeys.REGION_SIZE + dx, rz * ColumnKeys.REGION_SIZE + dz)
                val col = store.get(key)
                if (col == null) {
                    for (i in 0 until SUBS) {
                        s.solidParts[k + i] = null
                        s.waterParts[k + i] = null
                    }
                } else {
                    s.columns[present++] = key
                    for (i in 0 until SUBS) {
                        s.solidParts[k + i] = col.solid[i]
                        s.waterParts[k + i] = col.water[i]
                    }
                }
                k += SUBS
            }
        }
        val solid = packLayer(s.solidParts, s)
        val water = packLayer(s.waterParts, s)
        // Do not keep the meshes of this region reachable from the scratch arrays.
        java.util.Arrays.fill(s.solidParts, null)
        java.util.Arrays.fill(s.waterParts, null)
        return PackedRegion(regionKey, solid, water, s.columns.copyOf(present), urgent)
    }

    private fun packLayer(parts: Array<MeshData?>, s: Scratch): PackedLayer? {
        var totalFloats = 0
        var totalIndices = 0
        var lo = Float.MAX_VALUE
        var hi = -Float.MAX_VALUE
        for (p in parts) {
            if (p == null || p.vertexCount == 0) continue
            totalFloats += p.vertexData.size
            totalIndices += p.indices.size
            if (p.minY < lo) lo = p.minY
            if (p.maxY > hi) hi = p.maxY
        }
        if (totalFloats == 0 || totalIndices == 0) return null

        val vertexBytes = totalFloats * 4
        val indexBytes = totalIndices * 4
        val vbuf = pool.acquire(vertexBytes)
        val ibuf = pool.acquire(indexBytes)

        val fb = vbuf.asFloatBuffer()
        val offsets = s.offsets
        var vertOffset = 0
        for (i in parts.indices) {
            val p = parts[i]
            if (p == null || p.vertexCount == 0) {
                offsets[i] = -1
                continue
            }
            fb.put(p.vertexData, 0, p.vertexData.size)
            offsets[i] = vertOffset
            vertOffset += p.vertexCount
        }

        val stage = s.stage(totalIndices)
        var idx = 0
        var opaqueCount = 0
        var cutoutCount = 0
        for (group in 0 until 3) {
            for (i in parts.indices) {
                val p = parts[i]
                if (p == null || offsets[i] < 0) continue
                val from = if (group == 0) 0 else if (group == 1) p.opaqueEnd else p.cutoutEnd
                val to = if (group == 0) p.opaqueEnd else if (group == 1) p.cutoutEnd else p.indices.size
                val src = p.indices
                val shift = offsets[i]
                for (j in from until to) {
                    stage[idx++] = src[j] + shift
                }
            }
            if (group == 0) opaqueCount = idx else if (group == 1) cutoutCount = idx
        }
        ibuf.asIntBuffer().put(stage, 0, totalIndices)

        vbuf.position(0)
        vbuf.limit(vertexBytes)
        ibuf.position(0)
        ibuf.limit(indexBytes)
        return PackedLayer(vbuf, vertexBytes, ibuf, indexBytes, totalIndices, opaqueCount, cutoutCount, lo, hi)
    }

    private companion object {
        const val SUBS = WorldConfig.SUBCHUNKS_PER_CHUNK
        const val PARTS = ColumnKeys.REGION_SIZE * ColumnKeys.REGION_SIZE * SUBS
    }
}

/**
 * Packed regions waiting for the GL thread: the newest pack of each region (an older one that
 * was never uploaded is simply replaced, and its buffers recycled). Any thread may [put]; the
 * GL thread [take]s.
 */
class ReadyRegions(private val pool: DirectBufferPool) {
    private val map = ConcurrentHashMap<Long, PackedRegion>()
    private val bytes = AtomicLong()

    /** Bytes of packed data waiting to be uploaded (the packers pause when this gets large). */
    val pendingBytes: Long get() = bytes.get()

    val count: Int get() = map.size

    fun put(region: PackedRegion) {
        val old = map.put(region.key, region)
        bytes.addAndGet(region.totalBytes.toLong())
        if (old != null) {
            if (old.urgent) region.urgent = true
            bytes.addAndGet(-old.totalBytes.toLong())
            old.recycle(pool)
        }
    }

    fun keys(): LongArray {
        val out = LongArray(map.size)
        var i = 0
        for (k in map.keys) {
            if (i == out.size) return out.copyOf(i) // grew while copying: the next frame sees the rest
            out[i++] = k
        }
        return if (i == out.size) out else out.copyOf(i)
    }

    fun peek(key: Long): PackedRegion? = map[key]

    fun take(key: Long): PackedRegion? {
        val r = map.remove(key)
        if (r != null) bytes.addAndGet(-r.totalBytes.toLong())
        return r
    }

    fun clear() {
        for (k in map.keys) take(k)?.recycle(pool)
    }
}
