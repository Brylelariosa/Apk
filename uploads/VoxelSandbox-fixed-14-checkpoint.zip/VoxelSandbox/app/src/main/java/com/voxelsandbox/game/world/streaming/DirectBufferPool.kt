package com.voxelsandbox.game.world.streaming

import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Reusable direct (native-memory) buffers for the region data that is handed to the GL thread.
 *
 * Packing a region needs a few megabytes of direct buffer; allocating one per pack costs a
 * zero-fill of that size and leaves the memory to the garbage collector to free at some later
 * point, which with the amount of data streaming through is a steady source of both frame hitches
 * and native-heap growth. A buffer goes back here once the GL thread has uploaded it. Any thread
 * may [acquire] and [release].
 */
class DirectBufferPool(private val maxPooledBytes: Long = 48L shl 20) {
    private val free = ArrayList<ByteBuffer>()
    private var pooledBytes = 0L

    /** A cleared buffer, native byte order, with at least [minBytes] of capacity. */
    fun acquire(minBytes: Int): ByteBuffer {
        val need = if (minBytes < 1) 1 else minBytes
        synchronized(this) {
            var best = -1
            for (i in free.indices) {
                val c = free[i].capacity()
                // Reuse a buffer that is big enough but not wastefully so.
                if (c >= need && c <= need * 2L + SLACK && (best < 0 || c < free[best].capacity())) best = i
            }
            if (best >= 0) {
                val b = free.removeAt(best)
                pooledBytes -= b.capacity()
                b.clear()
                return b
            }
        }
        val capacity = roundUp(need)
        return ByteBuffer.allocateDirect(capacity).order(ByteOrder.nativeOrder())
    }

    fun release(buffer: ByteBuffer) {
        val cap = buffer.capacity()
        synchronized(this) {
            // Keep the pool bounded: drop the smallest buffers first (the big ones are the
            // expensive ones to allocate again).
            while (pooledBytes + cap > maxPooledBytes && free.isNotEmpty()) {
                var smallest = 0
                for (i in 1 until free.size) if (free[i].capacity() < free[smallest].capacity()) smallest = i
                pooledBytes -= free.removeAt(smallest).capacity()
            }
            if (pooledBytes + cap <= maxPooledBytes) {
                free.add(buffer)
                pooledBytes += cap
            }
        }
    }

    private fun roundUp(bytes: Int): Int {
        val unit = 64 * 1024
        val rounded = ((bytes.toLong() + unit - 1) / unit) * unit
        return if (rounded > Int.MAX_VALUE) Int.MAX_VALUE else rounded.toInt()
    }

    private companion object {
        const val SLACK = 128 * 1024
    }
}
