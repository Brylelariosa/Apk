package com.voxelsandbox.game

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.voxelsandbox.game.crash.CrashReporter
import com.voxelsandbox.game.diag.DiagLog
import com.voxelsandbox.game.diag.DiagShare
import com.voxelsandbox.game.engine.GameEngine
import com.voxelsandbox.game.gl.DepthConfigChooser
import com.voxelsandbox.game.gl.GameRenderer
import com.voxelsandbox.game.save.LoadedSave
import com.voxelsandbox.game.save.SaveManager
import com.voxelsandbox.game.settings.GameSettings
import com.voxelsandbox.game.settings.GraphicsQuality
import com.voxelsandbox.game.ui.HudController
import com.voxelsandbox.game.world.WorldConfig
import com.voxelsandbox.game.world.WorldManager
import java.util.concurrent.Executors

/**
 * The app's only Activity. Gameplay screens (main menu / loading / playing / paused /
 * settings) are overlay Views toggled on one root layout rather than separate
 * Activities, so the GL context and world state never need to survive an Activity
 * transition — only a much simpler show/hide of a few FrameLayouts.
 */
class GameActivity : Activity() {

    private enum class Screen { MAIN_MENU, LOADING, PLAYING, PAUSED, SETTINGS }

    private lateinit var settings: GameSettings
    private lateinit var saveManager: SaveManager
    private val ioExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private var glSurfaceView: GLSurfaceView? = null
    private var renderer: GameRenderer? = null
    private var engine: GameEngine? = null
    private var hud: HudController? = null

    private var currentScreen = Screen.MAIN_MENU
    private var settingsOpenedFrom = Screen.MAIN_MENU

    private lateinit var glContainer: FrameLayout
    private lateinit var mainMenuOverlay: View
    private lateinit var pauseOverlay: View
    private lateinit var settingsOverlay: View
    private lateinit var loadingOverlay: View
    private lateinit var hudOverlay: View

    private lateinit var seekRenderDistance: SeekBar
    private lateinit var seekDetailDistance: SeekBar
    private lateinit var textRenderDistance: TextView
    private lateinit var textDetailDistance: TextView
    private lateinit var switchFarTerrain: Switch
    private lateinit var spinnerGraphicsQuality: Spinner
    private lateinit var seekTouchSensitivity: SeekBar
    private lateinit var seekLookSensitivity: SeekBar
    private lateinit var switchFps: Switch
    private lateinit var switchBobbing: Switch
    private lateinit var switchClouds: Switch
    private lateinit var switchParticles: Switch
    private lateinit var switchAutoJump: Switch
    private lateinit var switchAutoDistance: Switch
    private lateinit var textAutoDistanceHint: TextView
    private lateinit var textAutoDistanceStatus: TextView
    private lateinit var switchCreative: Switch
    private lateinit var spinnerDiagMode: Spinner
    private lateinit var switchDiagPanel: Switch
    private lateinit var seekFlySpeed: SeekBar
    private lateinit var textFlySpeed: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        CrashReporter.install(this) // first line, deliberately before super.onCreate — see CrashReporter kdoc
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        settings = GameSettings(this)
        saveManager = SaveManager(this)
        // Starts the diagnostic logger if the player left it on (a no-op when it is off).
        DiagLog.init(this, settings.diagMode)
        DiagLog.setSettingsSnapshot(describeSettings())

        glContainer = findViewById(R.id.gl_container)
        mainMenuOverlay = findViewById(R.id.main_menu_overlay)
        pauseOverlay = findViewById(R.id.pause_overlay)
        settingsOverlay = findViewById(R.id.settings_overlay)
        loadingOverlay = findViewById(R.id.loading_overlay)
        hudOverlay = findViewById(R.id.hud_overlay)

        findViewById<Button>(R.id.btn_new_world).setOnClickListener { startNewWorld() }
        findViewById<Button>(R.id.btn_continue_world).setOnClickListener { continueWorld() }
        findViewById<Button>(R.id.btn_menu_settings).setOnClickListener { openSettings(Screen.MAIN_MENU) }
        findViewById<Button>(R.id.btn_exit).setOnClickListener { finish() }
        setUpCrashReportButton()

        findViewById<Button>(R.id.btn_resume).setOnClickListener { resumeFromPause() }
        findViewById<Button>(R.id.btn_pause_settings).setOnClickListener { openSettings(Screen.PAUSED) }
        findViewById<Button>(R.id.btn_customize_hud).setOnClickListener { customizeHud() }
        findViewById<Button>(R.id.btn_diagnostics).setOnClickListener { showDiagnosticsDialog() }
        findViewById<Button>(R.id.btn_save_quit).setOnClickListener { saveAndQuitToMenu() }

        findViewById<Button>(R.id.btn_settings_back).setOnClickListener { closeSettings() }
        findViewById<Button>(R.id.btn_settings_apply).setOnClickListener { applySettings(); closeSettings() }

        setupSettingsControls()
        showScreen(Screen.MAIN_MENU)
    }

    /** Shows the (normally hidden) "View Last Crash Report" button on the main menu
     *  only when CrashReporter found a report from the previous run, and wires it to
     *  a dialog with the report as selectable text plus a Copy button — there's no
     *  ADB on this workflow, so a way to get the text onto the clipboard and out of
     *  the phone (into a chat message, a note, etc.) is the whole point. */
    private fun setUpCrashReportButton() {
        val report = CrashReporter.readPendingCrash(this) ?: return
        val button = findViewById<Button>(R.id.btn_crash_report)
        button.visibility = View.VISIBLE
        button.setOnClickListener {
            val textView = TextView(this).apply {
                text = report
                setTextIsSelectable(true) // NOT a Kotlin property: getter/setter names
                // are asymmetric (isTextSelectable()/setTextIsSelectable()), so
                // Kotlin can't synthesize "textIsSelectable" — this exact mismatch
                // is what broke the last build (compileReleaseKotlin: "Unresolved
                // reference: textIsSelectable").
                setPadding(40, 32, 40, 32)
            }
            AlertDialog.Builder(this)
                .setTitle(R.string.view_crash_report)
                .setView(ScrollView(this).apply { addView(textView) })
                .setPositiveButton("Copy") { _, _ ->
                    val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                    clipboard.setPrimaryClip(ClipData.newPlainText("Crash report", report))
                }
                .setNegativeButton("Dismiss") { _, _ ->
                    CrashReporter.clearPendingCrash(this)
                    button.visibility = View.GONE
                }
                .setCancelable(true)
                .show()
        }
    }

    // ---- Screen management ------------------------------------------------------

    private fun showScreen(screen: Screen) {
        currentScreen = screen
        mainMenuOverlay.visibility = if (screen == Screen.MAIN_MENU) View.VISIBLE else View.GONE
        loadingOverlay.visibility = if (screen == Screen.LOADING) View.VISIBLE else View.GONE
        pauseOverlay.visibility = if (screen == Screen.PAUSED) View.VISIBLE else View.GONE
        settingsOverlay.visibility = if (screen == Screen.SETTINGS) View.VISIBLE else View.GONE
        hudOverlay.visibility = if (screen == Screen.PLAYING) View.VISIBLE else View.GONE
        renderer?.paused = (screen != Screen.PLAYING)

        if (screen == Screen.MAIN_MENU) {
            findViewById<Button>(R.id.btn_continue_world).isEnabled = saveManager.hasSave()
        }
    }

    private fun startNewWorld() {
        createEngineAndPlay(null)
    }

    private fun continueWorld() {
        showScreen(Screen.LOADING)
        ioExecutor.execute {
            val loaded = saveManager.load()
            mainHandler.post { createEngineAndPlay(loaded) }
        }
    }

    private fun createEngineAndPlay(loaded: LoadedSave?) {
        teardownEngine()

        val newEngine = GameEngine(settings, loaded)
        engine = newEngine

        val gl = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3)
            setEGLConfigChooser(DepthConfigChooser()) // must precede setRenderer
            preserveEGLContextOnPause = true
        }
        applyResolutionScale(gl, settings.graphicsQuality)
        val newRenderer = GameRenderer(newEngine) { statsText -> onPeriodicTick(statsText) }
        gl.setRenderer(newRenderer)
        renderer = newRenderer
        glContainer.removeAllViews()
        glContainer.addView(gl)
        glSurfaceView = gl

        hud = HudController(
            hudOverlay, newEngine.input, newEngine.inventory,
            onPause = { pauseGame() },
            onCreativeToggle = { toggleCreative() }
        )
        hud?.setCreativeUi(settings.creativeMode, settings.creativeMode)
        showScreen(Screen.PLAYING)
    }

    private fun onPeriodicTick(statsText: String?) {
        val h = hud ?: return
        if (statsText != null) {
            h.debugText.visibility = View.VISIBLE
            h.debugText.text = statsText
        } else {
            h.debugText.visibility = View.GONE
        }
        h.refreshHotbar()
        val e = engine
        if (e != null) {
            h.statusText.text = e.statusLine()
            h.statusText.visibility = View.VISIBLE
            h.setCreativeUi(settings.creativeMode, e.player.flying)
        }
    }

    /** The star button on the HUD: switches creative mode on (flight starts) or off. */
    private fun toggleCreative() {
        settings.creativeMode = !settings.creativeMode
        settings.persist()
        hud?.setCreativeUi(settings.creativeMode, settings.creativeMode)
    }

    private fun pauseGame() {
        hud?.releaseAllInputs()
        hud?.exitCustomizeMode() // safety net: never carry a frozen edit session into the pause menu
        showScreen(Screen.PAUSED)
    }

    private fun resumeFromPause() {
        showScreen(Screen.PLAYING)
    }

    private fun customizeHud() {
        resumeFromPause() // same transition Resume uses; edit mode overlays live gameplay
        hud?.enterCustomizeMode()
    }

    private fun openSettings(from: Screen) {
        settingsOpenedFrom = from
        loadSettingsIntoControls()
        showScreen(Screen.SETTINGS)
    }

    private fun closeSettings() {
        showScreen(settingsOpenedFrom)
    }

    private fun saveAndQuitToMenu() {
        val eng = engine ?: return
        showScreen(Screen.LOADING)
        eng.worldManager.shutdown() // stop background gen/mesh so the save snapshot is stable
        ioExecutor.execute {
            try {
                saveManager.save(eng.seed, eng.player, eng.inventory, eng.world)
            } catch (t: Throwable) {
                // Best-effort: failing to save shouldn't trap the player outside the menu.
            }
            mainHandler.post {
                teardownEngine()
                showScreen(Screen.MAIN_MENU)
            }
        }
    }

    private fun teardownEngine() {
        glSurfaceView?.onPause()
        engine?.shutdown()
        glContainer.removeAllViews()
        glSurfaceView = null
        renderer = null
        engine = null
        hud = null
    }

    /** Graphics Quality's main lever: renders into a smaller GL surface buffer than
     *  the physical screen and lets the compositor upscale it, trading a little
     *  sharpness for a roughly quadratic drop in fragment/fill-rate GPU cost — see
     *  GraphicsQuality.resolutionScale. setFixedSize can be called on an existing,
     *  already-visible surface too (triggering a fresh onSurfaceChanged with the new
     *  size), so this also covers changing the setting mid-game via applySettings,
     *  not just the initial size at surface creation. */
    private fun applyResolutionScale(gl: GLSurfaceView, quality: GraphicsQuality) {
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * quality.resolutionScale).toInt().coerceAtLeast(1)
        val h = (dm.heightPixels * quality.resolutionScale).toInt().coerceAtLeast(1)
        gl.holder.setFixedSize(w, h)
    }

    /** The OS is asking apps to give memory back: the world manager unloads the farthest chunks for a
     *  while (it restores the budget by itself afterwards). */
    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        engine?.worldManager?.onMemoryPressure(level)
    }

    // ---- Settings screen ----------------------------------------------------------

    private fun setupSettingsControls() {
        seekRenderDistance = findViewById(R.id.seek_render_distance)
        seekDetailDistance = findViewById(R.id.seek_detail_distance)
        textRenderDistance = findViewById(R.id.text_render_distance)
        textDetailDistance = findViewById(R.id.text_detail_distance)
        switchFarTerrain = findViewById(R.id.switch_far_terrain)
        spinnerGraphicsQuality = findViewById(R.id.spinner_graphics_quality)
        seekTouchSensitivity = findViewById(R.id.seek_touch_sensitivity)
        seekLookSensitivity = findViewById(R.id.seek_look_sensitivity)
        switchFps = findViewById(R.id.switch_fps)
        switchBobbing = findViewById(R.id.switch_bobbing)
        switchClouds = findViewById(R.id.switch_clouds)
        switchParticles = findViewById(R.id.switch_particles)
        switchAutoJump = findViewById(R.id.switch_auto_jump)
        switchAutoDistance = findViewById(R.id.switch_auto_distance)
        textAutoDistanceHint = findViewById(R.id.text_auto_distance_hint)
        textAutoDistanceStatus = findViewById(R.id.text_auto_distance_status)
        switchCreative = findViewById(R.id.switch_creative)
        spinnerDiagMode = findViewById(R.id.spinner_diag_mode)
        switchDiagPanel = findViewById(R.id.switch_diag_panel)
        seekFlySpeed = findViewById(R.id.seek_fly_speed)
        textFlySpeed = findViewById(R.id.text_fly_speed)
        seekFlySpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateFlySpeedLabel()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        seekRenderDistance.max = GameSettings.DISTANCE_SLIDER_STEPS
        seekDetailDistance.max = GameSettings.DISTANCE_SLIDER_STEPS
        val labelUpdater = object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                updateDistanceLabels()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
        seekRenderDistance.setOnSeekBarChangeListener(labelUpdater)
        seekDetailDistance.setOnSeekBarChangeListener(labelUpdater)
        // With the distant terrain off, the voxel chunks must cover the whole render
        // distance themselves, so a separate detail distance no longer means anything.
        switchFarTerrain.setOnCheckedChangeListener { _, checked ->
            seekDetailDistance.isEnabled = checked
            updateDistanceLabels()
        }
        switchAutoDistance.setOnCheckedChangeListener { _, _ -> updateAutoDistanceViews() }
        spinnerGraphicsQuality.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            GraphicsQuality.values().map { it.label }
        )
        spinnerDiagMode.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf(DiagLog.modeName(DiagLog.MODE_OFF), DiagLog.modeName(DiagLog.MODE_LIGHT), DiagLog.modeName(DiagLog.MODE_DETAILED))
        )
    }

    /** Fly speed on the settings slider: 0..100 maps exponentially onto MIN..MAX blocks/s. */
    private fun flySpeedFromProgress(progress: Int): Float =
        GameSettings.MIN_FLY_SPEED *
            Math.pow((GameSettings.MAX_FLY_SPEED / GameSettings.MIN_FLY_SPEED).toDouble(), progress / 100.0).toFloat()

    private fun progressFromFlySpeed(speed: Float): Int =
        (Math.log((speed / GameSettings.MIN_FLY_SPEED).toDouble()) /
            Math.log((GameSettings.MAX_FLY_SPEED / GameSettings.MIN_FLY_SPEED).toDouble()) * 100.0).toInt().coerceIn(0, 100)

    private fun updateFlySpeedLabel() {
        textFlySpeed.text = getString(R.string.fly_speed_value, flySpeedFromProgress(seekFlySpeed.progress).toInt())
    }

    private fun updateDistanceLabels() {
        val render = GameSettings.renderFromSlider(seekRenderDistance.progress)
        val detail = GameSettings.detailFromSlider(seekDetailDistance.progress)
        // Full-detail chunks cost memory: this device holds only so many around the player, however
        // high the setting. Say so instead of letting a bigger number silently change nothing.
        val holdable = holdableChunkRadius()
        textRenderDistance.text = if (!switchFarTerrain.isChecked && render > holdable) {
            getString(R.string.render_distance_value_no_far, render, render * WorldConfig.CHUNK_SIZE, holdable)
        } else {
            getString(R.string.render_distance_value, render, render * WorldConfig.CHUNK_SIZE)
        }
        textDetailDistance.text = if (detail <= holdable) {
            getString(R.string.detail_distance_value, detail)
        } else {
            getString(R.string.detail_distance_value_capped, detail, holdable)
        }
        updateAutoDistanceViews()
    }

    /** Radius (chunks) of full-detail terrain this device keeps loaded (see WorldManager.computeChunkBudget). */
    private fun holdableChunkRadius(): Int = Math.sqrt(WorldManager.chunkBudgetForThisDevice() / Math.PI).toInt()

    /** The hint under the Automatic Render Distance switch, and (while it is on) the selected and the
     *  effective distance. The effective figure comes from the running game, so it is only shown for
     *  what is already applied; a pending change says so instead of guessing. */
    private fun updateAutoDistanceViews() {
        val on = switchAutoDistance.isChecked
        textAutoDistanceHint.setText(if (on) R.string.auto_distance_hint_on else R.string.auto_distance_hint_off)
        if (!on) {
            textAutoDistanceStatus.visibility = View.GONE
            return
        }
        textAutoDistanceStatus.visibility = View.VISIBLE
        val selected = GameSettings.renderFromSlider(seekRenderDistance.progress)
        val running = engine
        if (running != null && settings.autoRenderDistance && selected == settings.renderDistanceChunks) {
            val effective = Math.round(running.distanceGovernor.effectiveChunks(selected, WorldConfig.CHUNK_SIZE))
            val percent = Math.round(effective * 100f / selected)
            textAutoDistanceStatus.text = getString(R.string.auto_distance_status, selected, effective, percent)
        } else {
            textAutoDistanceStatus.text = getString(R.string.auto_distance_status_pending, selected)
        }
    }

    private fun loadSettingsIntoControls() {
        seekRenderDistance.progress = GameSettings.renderToSlider(settings.renderDistanceChunks)
        seekDetailDistance.progress = GameSettings.detailToSlider(settings.detailDistanceChunks)
        switchFarTerrain.isChecked = settings.farTerrain
        seekDetailDistance.isEnabled = settings.farTerrain
        updateDistanceLabels()
        spinnerGraphicsQuality.setSelection(settings.graphicsQuality.ordinal)
        seekTouchSensitivity.progress = (settings.touchSensitivity * 100).toInt()
        seekLookSensitivity.progress = (settings.lookSensitivity * 100).toInt()
        switchFps.isChecked = settings.showFps
        switchBobbing.isChecked = settings.viewBobbing
        switchClouds.isChecked = settings.cloudsEnabled
        switchParticles.isChecked = settings.particlesEnabled
        switchAutoJump.isChecked = settings.autoJump
        switchAutoDistance.isChecked = settings.autoRenderDistance
        switchCreative.isChecked = settings.creativeMode
        spinnerDiagMode.setSelection(settings.diagMode)
        switchDiagPanel.isChecked = settings.diagPanel
        seekFlySpeed.progress = progressFromFlySpeed(settings.flySpeed)
        updateFlySpeedLabel()
    }

    private fun applySettings() {
        settings.renderDistanceChunks = GameSettings.renderFromSlider(seekRenderDistance.progress)
        settings.detailDistanceChunks = GameSettings.detailFromSlider(seekDetailDistance.progress)
        settings.farTerrain = switchFarTerrain.isChecked
        val newQuality = GraphicsQuality.fromOrdinalSafe(spinnerGraphicsQuality.selectedItemPosition)
        val qualityChanged = newQuality != settings.graphicsQuality
        settings.graphicsQuality = newQuality
        settings.touchSensitivity = seekTouchSensitivity.progress / 100f
        settings.lookSensitivity = seekLookSensitivity.progress / 100f
        settings.showFps = switchFps.isChecked
        settings.viewBobbing = switchBobbing.isChecked
        settings.cloudsEnabled = switchClouds.isChecked
        settings.particlesEnabled = switchParticles.isChecked
        settings.autoJump = switchAutoJump.isChecked
        settings.autoRenderDistance = switchAutoDistance.isChecked
        settings.creativeMode = switchCreative.isChecked
        settings.flySpeed = flySpeedFromProgress(seekFlySpeed.progress)
        settings.diagMode = spinnerDiagMode.selectedItemPosition.coerceIn(0, 2)
        settings.diagPanel = switchDiagPanel.isChecked
        settings.persist()
        DiagLog.setMode(settings.diagMode)
        DiagLog.setSettingsSnapshot(describeSettings())
        hud?.setCreativeUi(settings.creativeMode, settings.creativeMode && (engine?.player?.flying ?: true))
        if (!settings.showFps && !(settings.diagPanel && settings.diagMode != DiagLog.MODE_OFF)) hud?.debugText?.visibility = View.GONE
        if (qualityChanged) glSurfaceView?.let { applyResolutionScale(it, newQuality) }
    }

    // ---- Diagnostics ----------------------------------------------------------

    private fun describeSettings(): String =
        "render " + settings.renderDistanceChunks + " chunks, voxel detail " + settings.detailDistanceChunks +
            " chunks, distant terrain " + (if (settings.farTerrain) "on" else "off") +
            ", quality " + settings.graphicsQuality.label +
            ", automatic render distance " + (if (settings.autoRenderDistance) "on" else "off") +
            ", clouds " + (if (settings.cloudsEnabled) "on" else "off") +
            ", particles " + (if (settings.particlesEnabled) "on" else "off")

    /** Pause-menu "Diagnostics": capture an incident, save the full log, or share a report through
     *  Android's share sheet. Everything slow (building the report, writing files) runs on the I/O
     *  thread, never on the render thread. */
    private fun showDiagnosticsDialog() {
        val builder = AlertDialog.Builder(this)
            .setTitle(R.string.diagnostics)
            .setMessage(DiagLog.statusText())
        if (!DiagLog.isActive()) {
            builder.setPositiveButton("Turn on (Lightweight)") { _, _ ->
                settings.diagMode = DiagLog.MODE_LIGHT
                settings.persist()
                DiagLog.setMode(DiagLog.MODE_LIGHT)
                DiagLog.setSettingsSnapshot(describeSettings())
                Toast.makeText(this, "Diagnostics are on (Lightweight)", Toast.LENGTH_SHORT).show()
            }
            builder.setNeutralButton("Share last session") { _, _ -> exportAndShareDiagnostics() }
            builder.setNegativeButton(android.R.string.cancel, null)
        } else {
            builder.setPositiveButton("Share report") { _, _ -> exportAndShareDiagnostics() }
            builder.setNeutralButton("Capture incident") { _, _ ->
                DiagLog.captureIncident()
                Toast.makeText(this, "Incident captured (the last 10 seconds are kept)", Toast.LENGTH_SHORT).show()
            }
            builder.setNegativeButton("Save full log") { _, _ -> saveDiagnosticLog() }
        }
        builder.show()
    }

    private fun exportAndShareDiagnostics() {
        Toast.makeText(this, "Preparing the diagnostic report...", Toast.LENGTH_SHORT).show()
        ioExecutor.execute {
            val files = try {
                DiagLog.exportFiles(applicationContext)
            } catch (t: Throwable) {
                null
            }
            runOnUiThread {
                if (files == null || files.isEmpty()) {
                    Toast.makeText(this, "There is no diagnostic data to share yet", Toast.LENGTH_LONG).show()
                } else {
                    try {
                        DiagShare.shareFiles(this, files)
                    } catch (t: Throwable) {
                        Toast.makeText(this, "Could not open the share sheet: " + t.message, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun saveDiagnosticLog() {
        ioExecutor.execute {
            val dir = try {
                DiagLog.saveNow(applicationContext)
            } catch (t: Throwable) {
                null
            }
            runOnUiThread {
                val message = if (dir != null) {
                    "Full log saved in the app's diagnostics folder. Use Share report to send it."
                } else {
                    "Nothing to save: diagnostics are off."
                }
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---- Lifecycle ------------------------------------------------------------

    override fun onResume() {
        super.onResume()
        glSurfaceView?.onResume()
        hideSystemBars()
        DiagLog.lifecycle("activity resumed")
    }

    override fun onPause() {
        super.onPause()
        DiagLog.lifecycle("activity paused")
        glSurfaceView?.onPause()
        if (currentScreen == Screen.PLAYING) {
            hud?.releaseAllInputs()
            hud?.exitCustomizeMode()
            showScreen(Screen.PAUSED)
        }
        autoSaveIfActive()
    }

    override fun onDestroy() {
        super.onDestroy()
        engine?.shutdown()
        ioExecutor.shutdown()
        DiagLog.shutdown(isFinishing)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when (currentScreen) {
            Screen.PLAYING -> pauseGame()
            Screen.PAUSED -> resumeFromPause()
            Screen.SETTINGS -> closeSettings()
            Screen.LOADING -> { /* ignore back while a load/save is in flight */ }
            Screen.MAIN_MENU -> super.onBackPressed()
        }
    }

    private fun autoSaveIfActive() {
        val eng = engine ?: return
        ioExecutor.execute {
            try {
                saveManager.save(eng.seed, eng.player, eng.inventory, eng.world)
            } catch (t: Throwable) {
                // Best-effort autosave on backgrounding; never let this crash the app.
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            )
    }
}
