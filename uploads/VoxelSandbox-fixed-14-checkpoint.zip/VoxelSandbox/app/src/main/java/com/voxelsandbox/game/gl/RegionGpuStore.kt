package com.voxelsandbox.game.gl

import com.voxelsandbox.game.world.streaming.ColumnKeys
import com.voxelsandbox.game.world.streaming.DirectBufferPool
import com.voxelsandbox.game.world.streaming.PackedRegion
import com.voxelsandbox.game.world.streaming.ReadyRegions
import com.voxelsandbox.game.world.streaming.RegionUploadScheduler

/**
 * The GPU side of the voxel terrain: one buffer per REGION of columns (one draw call for up to
 * sixteen columns), plus the set of columns that are actually on screen.
 *
 * The data arrives already packed (see RegionPacker): the streaming threads do the concatenating
 * and index shifting, so what is left for the GL thread is one glBufferData per buffer. How much of
 * that to do in one frame is the caller's budget; regions are taken in order of how soon they are
 * needed (see [drain]).
 *
 * GL thread only, like everything that owns GL objects.
 */
class RegionGpuStore {
    /** Opaque / cut-out / double-sided terrain of each region that has any, by region key. */
    val solid = HashMap<Long, ChunkGpuMesh>()

    /** The translucent water layer of each region that has any. */
    val water = HashMap<Long, ChunkGpuMesh>()

    /** Columns (packed, see [ColumnKeys.column]) whose terrain is on the GPU, including columns
     *  that have nothing to draw (open ocean): "accounted for", which is what the fog coverage
     *  scan needs. */
    private val covered = HashSet<Long>()

    private val scheduler = RegionUploadScheduler()

    /** Bytes and regions handed to the driver by the last [drain] (for the stats overlay). */
    val lastBytes: Int get() = scheduler.lastBytes
    val lastRegions: Int get() = scheduler.lastRegions

    fun isColumnCovered(column: Long): Boolean = covered.contains(column)

    fun forgetColumn(column: Long) {
        covered.remove(column)
    }

    /** The GL context was lost: every handle is meaningless, so drop them without deleting. */
    fun invalidateForContextLoss() {
        for (m in solid.values) m.invalidateForContextLoss()
        for (m in water.values) m.invalidateForContextLoss()
        solid.clear()
        water.clear()
        covered.clear()
    }

    /**
     * Uploads packed regions from [ready] within this frame's budget, in the order
     * [RegionUploadScheduler] picks (edits first, then the ones needed soonest).
     * Returns the number of regions uploaded.
     */
    fun drain(
        ready: ReadyRegions,
        pool: DirectBufferPool,
        eyeX: Float,
        eyeZ: Float,
        lookX: Float,
        lookZ: Float,
        byteBudget: Int,
        nanoBudget: Long,
        startNs: Long
    ): Int = scheduler.drain(
        ready, { solid.containsKey(it) }, eyeX, eyeZ, lookX, lookZ, byteBudget, nanoBudget, startNs
    ) { apply(it, pool) }

    private fun apply(pack: PackedRegion, pool: DirectBufferPool) {
        val key = pack.key
        val rx = ColumnKeys.regionX(key)
        val rz = ColumnKeys.regionZ(key)
        for (dz in 0 until ColumnKeys.REGION_SIZE) {
            for (dx in 0 until ColumnKeys.REGION_SIZE) {
                covered.remove(ColumnKeys.column(rx * ColumnKeys.REGION_SIZE + dx, rz * ColumnKeys.REGION_SIZE + dz))
            }
        }
        for (c in pack.columns) covered.add(c)

        val s = pack.solid
        if (s != null) solid.getOrPut(key) { ChunkGpuMesh() }.uploadPacked(s) else solid.remove(key)?.dispose()
        val w = pack.water
        if (w != null) water.getOrPut(key) { ChunkGpuMesh() }.uploadPacked(w) else water.remove(key)?.dispose()

        pack.recycle(pool)
    }
}
