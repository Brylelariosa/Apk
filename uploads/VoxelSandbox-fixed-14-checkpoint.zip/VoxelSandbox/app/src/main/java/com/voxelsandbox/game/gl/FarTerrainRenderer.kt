package com.voxelsandbox.game.gl

import android.opengl.GLES30
import com.voxelsandbox.game.world.far.FarEvent
import com.voxelsandbox.game.world.far.FarTerrain
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * The GPU side of the distant terrain (see [FarTerrain] for how tiles are built): holds the
 * uploaded tile meshes and draws them, level by level, as an opaque land pass and a
 * translucent water pass. Everything here is GL-thread only.
 *
 * Every level is drawn inside its own ring around the player (the shader discards what lies
 * outside it); the columns of a level slide to the next level's heights as its ring ends (see
 * FarTerrain), so the rings meet with no overlap, no sinking and no step. The one place two
 * levels can claim the same ground is the thin finest ring (level 0) over level 1: level 1 is
 * the ground that is always built, level 0 only improves a ring of it, so each level-1 tile
 * hands that ring over to level 0 only once *all* the level-0 tiles it needs are on the GPU
 * (see [updateFineCoverage]), and takes it back otherwise. Never a hole, never two surfaces.
 */
class FarTerrainRenderer {
    private class GpuTile(
        val key: Long,
        val land: ChunkGpuMesh?,
        val water: ChunkGpuMesh?,
        val level: Int,
        val x0: Float,
        val z0: Float,
        val size: Float,
        val minY: Float,
        val maxY: Float
    ) {
        fun dispose() {
            land?.dispose()
            water?.dispose()
        }
    }

    private val tiles = HashMap<Long, GpuTile>()

    private lateinit var program: ShaderProgram
    private val noise = FarNoiseTexture()
    private var uViewProj = 0
    private var uTexture = 0
    private var uNoise = 0
    private var uFogColor = 0
    private var uFogStart = 0
    private var uFogEnd = 0
    private var uClip = 0
    private var uCenter = 0
    private var uBand = 0

    // Which level-1 tiles currently hand the finest ring over to level 0 (see the class note).
    private var fineActive = false
    private var coveredKeys = LongArray(64)
    private var coveredCount = 0
    private var coverageDirty = true
    private var coverageEyeX = 0f
    private var coverageEyeZ = 0f
    private var coverageFineIn = -1f
    private var coverageFineOut = -1f

    // Stats for the FPS overlay and the diagnostic log.
    var drawnTiles = 0
        private set
    var totalTiles = 0
        private set
    var drawnTriangles = 0
        private set

    /** Land triangles drawn last frame, per level (level 0 = LOD 1 ... level 7 = far256). */
    val levelTriangles = IntArray(FarTerrain.LEVELS)

    /** Tiles drawn last frame, per level. */
    val levelTiles = IntArray(FarTerrain.LEVELS)

    /** Zeroes the overlay statistics (used on frames where distant terrain is not drawn). */
    fun clearStats() {
        drawnTiles = 0
        totalTiles = 0
        drawnTriangles = 0
        for (i in levelTriangles.indices) {
            levelTriangles[i] = 0
            levelTiles[i] = 0
        }
    }

    fun init() {
        program = ShaderProgram(Shaders.FAR_VERTEX, Shaders.FAR_FRAGMENT)
        uViewProj = program.uniform("uViewProj")
        uTexture = program.uniform("uTexture")
        uNoise = program.uniform("uNoise")
        uFogColor = program.uniform("uFogColor")
        uFogStart = program.uniform("uFogStart")
        uFogEnd = program.uniform("uFogEnd")
        uClip = program.uniform("uClip")
        uCenter = program.uniform("uCenter")
        uBand = program.uniform("uBand")
        noise.upload()
        coverageDirty = true
    }

    /** The GL context was recreated: every handle is dead, forget them (no GL calls). */
    fun invalidateForContextLoss() {
        for (tile in tiles.values) {
            tile.land?.invalidateForContextLoss()
            tile.water?.invalidateForContextLoss()
        }
        tiles.clear()
        coveredCount = 0
        coverageDirty = true
    }

    /** Applies tile adds/removals in the order the builder produced them. Removals are cheap
     *  and always processed; uploads are limited to [maxUploads] per call. Returns how many
     *  tiles were uploaded. */
    fun drain(events: LinkedBlockingQueue<FarEvent>, maxUploads: Int): Int {
        var uploads = 0
        while (uploads < maxUploads) {
            val event = events.poll() ?: break
            tiles.remove(event.key)?.dispose()
            coverageDirty = true
            val tile = event.tile ?: continue

            var land: ChunkGpuMesh? = null
            if (!tile.land.isEmpty()) {
                land = ChunkGpuMesh(FarTerrain.LAND_FLOATS)
                land.upload(tile.land)
            }
            var water: ChunkGpuMesh? = null
            if (!tile.water.isEmpty()) {
                water = ChunkGpuMesh()
                water.upload(tile.water)
            }
            tiles[event.key] = GpuTile(event.key, land, water, tile.level, tile.x0, tile.z0, tile.size, tile.minY, tile.maxY)
            uploads++
        }
        return uploads
    }

    // ---- the finest ring ------------------------------------------------------------------

    /**
     * Decides which level-1 tiles give the finest ring (level 0) their ground this frame. The
     * ring is only used once the voxel area is proven to reach it (before that, level 1 must
     * cover the middle ground), and per level-1 tile only when every level-0 tile of the ring
     * inside it has been uploaded. The answer only changes when tiles arrive or leave or the
     * player has moved a few blocks, so it is cached.
     */
    private fun updateFineCoverage(frame: FrameState) {
        val fineIn = FarTerrain.fineInner()
        val fineOut = FarTerrain.fineOuter()
        if (fineOut <= 0f) {
            fineActive = false
            coveredCount = 0
            return
        }
        if (fineActive) {
            if (frame.coverRadius < fineIn - 72f) fineActive = false
        } else if (frame.coverRadius >= fineIn - 16f) {
            fineActive = true
            coverageDirty = true
        }
        if (!fineActive) {
            coveredCount = 0
            return
        }
        val moved = abs(frame.eyeX - coverageEyeX) + abs(frame.eyeZ - coverageEyeZ)
        if (!coverageDirty && moved < 6f && coverageFineIn == fineIn && coverageFineOut == fineOut) return
        coverageDirty = false
        coverageEyeX = frame.eyeX
        coverageEyeZ = frame.eyeZ
        coverageFineIn = fineIn
        coverageFineOut = fineOut

        coveredCount = 0
        val sizeFine = FarTerrain.tileBlocks(0)
        val ratio = FarTerrain.tileBlocks(1) / sizeFine
        for (tile in tiles.values) {
            if (tile.level != 1) continue
            val tx1 = FarTerrain.tileX(tile.key)
            val tz1 = FarTerrain.tileZ(tile.key)
            var covered = true
            var needed = 0
            for (b in 0 until ratio) {
                for (a in 0 until ratio) {
                    val cx = tx1 * ratio + a
                    val cz = tz1 * ratio + b
                    val x0 = (cx * sizeFine).toFloat()
                    val z0 = (cz * sizeFine).toFloat()
                    val near = distanceNear(x0, z0, sizeFine.toFloat(), frame.eyeX, frame.eyeZ)
                    if (near >= fineOut) continue
                    val far = distanceFar(x0, z0, sizeFine.toFloat(), frame.eyeX, frame.eyeZ)
                    if (far <= fineIn) continue
                    needed++
                    if (!tiles.containsKey(FarTerrain.tileKey(0, cx, cz))) covered = false
                }
            }
            if (covered && needed > 0) {
                if (coveredCount == coveredKeys.size) coveredKeys = coveredKeys.copyOf(coveredCount * 2)
                coveredKeys[coveredCount++] = tile.key
            }
        }
    }

    private fun isCovered(level1Key: Long): Boolean {
        for (i in 0 until coveredCount) {
            if (coveredKeys[i] == level1Key) return true
        }
        return false
    }

    /** Key of the level-1 tile that contains a level-0 tile (tiles are aligned). */
    private fun parentKeyOf(tile: GpuTile): Long {
        val ratio = FarTerrain.tileBlocks(1) / FarTerrain.tileBlocks(0)
        return FarTerrain.tileKey(
            1,
            Math.floorDiv(FarTerrain.tileX(tile.key), ratio),
            Math.floorDiv(FarTerrain.tileZ(tile.key), ratio)
        )
    }

    // ---- drawing --------------------------------------------------------------------------

    /** Opaque ground. Each level draws only inside its own ring (enforced in the shader). */
    fun drawLand(frame: FrameState, frustum: Frustum) {
        drawnTiles = 0
        drawnTriangles = 0
        totalTiles = tiles.size
        for (i in levelTriangles.indices) {
            levelTriangles[i] = 0
            levelTiles[i] = 0
        }
        updateFineCoverage(frame)
        if (tiles.isEmpty()) return

        program.use()
        GLES30.glUniformMatrix4fv(uViewProj, 1, false, frame.viewProj, 0)
        GLES30.glUniform3f(uFogColor, frame.fogR, frame.fogG, frame.fogB)
        GLES30.glUniform1f(uFogStart, frame.fogStart)
        GLES30.glUniform1f(uFogEnd, frame.fogEnd)
        GLES30.glUniform1i(uTexture, 0)
        noise.bind(NOISE_UNIT)
        GLES30.glUniform1i(uNoise, NOISE_UNIT)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        // Everything inside this circle is drawn by real voxel chunks: discard it so the two
        // never overlap. The radius is the proven coverage minus the width of the dissolve
        // band, so this mesh is already in place behind the voxel terrain as it fades out.
        GLES30.glUniform3f(uClip, frame.coverX, frame.coverZ, frame.landClipRadius * frame.landClipRadius)
        GLES30.glUniform2f(uCenter, frame.eyeX, frame.eyeZ)

        for (level in 0 until FarTerrain.LEVELS) {
            if (level == 0 && !fineActive) continue
            val outer = FarTerrain.drawOuter(level)
            if (outer <= 0f) continue
            // The coarsest level has nothing to slide to: park the slide range far out of reach
            // (smoothstep needs edge0 < edge1, and 1e9 + 1 is not representable).
            val last = level == FarTerrain.LEVELS - 1
            val mStart = if (last) 2.0e9f else FarTerrain.morphStart(level)
            val mEnd = if (last) 3.0e9f else max(outer, mStart + 1f)
            var lastInner = -1f
            for (tile in tiles.values) {
                if (tile.level != level) continue
                val land = tile.land ?: continue
                val inner: Float
                if (level == 0) {
                    if (!isCovered(parentKeyOf(tile))) continue
                    inner = FarTerrain.drawInner(0, true)
                } else if (level == 1) {
                    inner = FarTerrain.drawInner(1, fineActive && isCovered(tile.key))
                } else {
                    inner = FarTerrain.drawInner(level, false)
                }
                if (!isVisible(tile, frame, frustum, inner, outer, frame.landClipRadius)) continue
                if (inner != lastInner) {
                    GLES30.glUniform4f(uBand, inner, outer, mStart, mEnd)
                    lastInner = inner
                }
                land.draw()
                drawnTiles++
                drawnTriangles += land.triangleCount
                levelTiles[level]++
                levelTriangles[level] += land.triangleCount
            }
        }
    }

    /** Translucent sea / lake surfaces, to be drawn between [WaterRenderer.begin] and
     *  [WaterRenderer.end] after [drawLand]. */
    fun drawWater(frame: FrameState, frustum: Frustum, water: WaterRenderer) {
        if (tiles.isEmpty()) return
        water.useFarArea(frame)
        // The rings of flat water overlap by a sliver (FarTerrain.WATER_OVERLAP): a hairline gap
        // would show the dark ground under the sea as a ring, and the sliver is invisible
        // because far water is drawn all but solid.
        for (level in FarTerrain.LEVELS - 1 downTo 0) {
            if (level == 0 && !fineActive) continue
            val outer = FarTerrain.drawOuter(level)
            if (outer <= 0f) continue
            var lastInner = -1f
            for (tile in tiles.values) {
                if (tile.level != level) continue
                val mesh = tile.water ?: continue
                val inner: Float
                if (level == 0) {
                    if (!isCovered(parentKeyOf(tile))) continue
                    inner = FarTerrain.drawInner(0, true)
                } else if (level == 1) {
                    inner = FarTerrain.drawInner(1, fineActive && isCovered(tile.key))
                } else {
                    inner = FarTerrain.drawInner(level, false)
                }
                val outerDrawn = if (level == FarTerrain.LEVELS - 1) outer else outer + FarTerrain.WATER_OVERLAP
                if (!isVisible(tile, frame, frustum, inner, outerDrawn, frame.coverRadius)) continue
                if (inner != lastInner) {
                    water.setBand(inner, outerDrawn)
                    lastInner = inner
                }
                mesh.draw()
                drawnTriangles += mesh.triangleCount
            }
        }
    }

    /** True if some part of the tile can be on screen: inside the ring, outside the circle
     *  of radius [clipRadius] around the cover centre (where voxel chunks draw instead) and
     *  inside the view frustum. */
    private fun isVisible(tile: GpuTile, frame: FrameState, frustum: Frustum, inner: Float, outer: Float, clipRadius: Float): Boolean {
        val x1 = tile.x0 + tile.size
        val z1 = tile.z0 + tile.size

        // distance from the player to the nearest / farthest point of the tile
        val near = distanceNear(tile.x0, tile.z0, tile.size, frame.eyeX, frame.eyeZ)
        if (near > outer) return false
        // A tile that starts beyond the fog's end is pure fog colour (which is also what the
        // sky is at and below the horizon), so drawing it would only cost triangles.
        if (near > frame.fogEnd + 2f) return false
        if (distanceFar(tile.x0, tile.z0, tile.size, frame.eyeX, frame.eyeZ) < inner) return false

        // entirely inside the circle real chunks cover?
        val cx = max(abs(frame.coverX - tile.x0), abs(frame.coverX - x1))
        val cz = max(abs(frame.coverZ - tile.z0), abs(frame.coverZ - z1))
        if (cx * cx + cz * cz < clipRadius * clipRadius) return false

        return frustum.isBoxVisible(tile.x0, tile.minY - 2f, tile.z0, x1, tile.maxY + 2f, z1)
    }

    private fun distanceNear(x0: Float, z0: Float, size: Float, px: Float, pz: Float): Float {
        val x1 = x0 + size
        val z1 = z0 + size
        val nx = if (px < x0) x0 else if (px > x1) x1 else px
        val nz = if (pz < z0) z0 else if (pz > z1) z1 else pz
        return sqrt((px - nx) * (px - nx) + (pz - nz) * (pz - nz))
    }

    private fun distanceFar(x0: Float, z0: Float, size: Float, px: Float, pz: Float): Float {
        val fx = max(abs(px - x0), abs(px - (x0 + size)))
        val fz = max(abs(pz - z0), abs(pz - (z0 + size)))
        return sqrt(fx * fx + fz * fz)
    }

    private companion object {
        /** Texture unit of the far-terrain noise (0 = block atlas, 1 = water tile). */
        const val NOISE_UNIT = 2
    }
}
