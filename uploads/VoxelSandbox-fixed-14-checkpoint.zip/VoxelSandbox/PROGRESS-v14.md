# VoxelSandbox v14 work log (kept current so work is never lost)

Project root: /home/claude/work/project/VoxelSandbox
Deliverables go to: /mnt/user-data/outputs/  (symlink to /mnt/attach/outputs)

## Done (verified by compile + JVM simulation, not on a device)
- Streaming core: re-rankable job queue, direction-aware priorities, column-level meshing with neighbour gating,
  incremental boundary-only remesh, off-thread region packing, budgeted prioritised GPU uploads, failure counter
  with retry (a column that cannot be built is accounted for instead of leaving a permanent hole).
  Files: world/WorldManager.kt, world/streaming/*, gl/RegionGpuStore.kt, gl/ChunkGpuMesh.kt (uploadPacked), gl/GameRenderer.kt.
- Automatic Render Distance switch (persisted, default OFF) in the graphics settings, with the selected and the
  effective distance shown when it is ON. Files: settings/GameSettings.kt, GameActivity.kt, res/layout/overlay_settings.xml,
  res/values/strings.xml, res/values/styles.xml.
- Maximum render distance and detail distance 1000 chunks (settings, sliders, validation, streaming radius, far terrain).
- engine/DistanceGovernor.kt: evidence-based automatic distance (probe, measure, keep or revert, both directions, dead zone,
  back-off, floor 0.40 / 560 blocks). OFF means exactly the selected distance, always.
- Extreme-distance safety: far-terrain ladder extended to 8 levels, byte ceiling on resident far tiles (96..192 MB by device),
  radius clamps, nearest-first ring capped, chunk budget cut under memory pressure (onTrimMemory / OutOfMemoryError) and restored
  step by step, unloading by wanted set with hysteresis.
- world/ChunkMap.kt: lock-free open-addressing chunk table (the old ConcurrentHashMap<Long, Chunk> boxed every key and its hash
  collapsed to cx xor cz, so ~1100 chunks shared a few dozen buckets).
- Terrain generator re-profiled: output verified bit-identical to the original (SHA-256 over 4 seeds x 6 sites x 169 chunks),
  see harness `GenHash`.
- JVM harnesses (scratchpad, not shipped yet): queue tests, streaming simulation (old v13b vs new), per-stage bench, governor
  behaviour tests, slider mapping test, far-terrain bench, memory bench, chunk-map test, generator hash + profile.

## In progress / to do (in this order)
- [ ] Generator micro-optimisations that keep the output bit-identical (ore noise = 29% of generation, height noise = 34%)
- [ ] Stable texture sampling + camera-relative rendering (float32 jitter at large coordinates, water uv, view bob)
- [ ] Greedy meshing (merge identical faces; AO stays per cell where it varies)
- [ ] Texture pre-warm / upload hygiene
- [ ] Measurements (CPU meshing time, frame times, memory, upload volume) on the final code vs v13b
- [ ] Final docs, ZIP, APK attempt

## Honest limits
- No Android device and no Gradle/AGP in this sandbox: results are JVM simulations on a 2-core Linux machine.
- The whole app compiles with kotlinc 1.9.22 against the android-34 stubs (a stub R); that proves the Kotlin is valid,
  not that the Gradle build, the manifest or the resources link. GitHub Actions remains the real build.
