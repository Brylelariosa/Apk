package com.tom.novashare.di

import android.content.Context
import com.tom.novashare.data.local.NovaShareDatabase
import com.tom.novashare.data.local.TransferDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): NovaShareDatabase =
        NovaShareDatabase.getInstance(context)

    @Provides
    fun provideTransferDao(db: NovaShareDatabase): TransferDao = db.transferDao()
}
