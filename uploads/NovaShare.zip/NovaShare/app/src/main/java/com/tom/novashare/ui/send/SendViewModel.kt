package com.tom.novashare.ui.send

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tom.novashare.data.model.SessionManifest
import com.tom.novashare.data.model.TransferItem
import com.tom.novashare.data.model.TransferItemType
import com.tom.novashare.data.model.TransferProgress
import com.tom.novashare.data.network.HotspotManager
import com.tom.novashare.data.repository.AppListRepository
import com.tom.novashare.data.repository.InstalledApp
import com.tom.novashare.di.TransferStateHolder
import com.tom.novashare.service.TransferService
import com.tom.novashare.util.QrCodeGenerator
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

sealed interface SendStage {
    data object PickingItems : SendStage
    data object StartingHotspot : SendStage
    data class WaitingForReceiver(val qrBitmap: Bitmap, val ssid: String, val password: String) : SendStage
    data class Sending(val progress: TransferProgress) : SendStage
    data object Done : SendStage
    data class Error(val message: String) : SendStage
}

data class PickedItem(val uri: Uri, val name: String, val size: Long, val mime: String)

data class SendUiState(
    val selectedFiles: List<PickedItem> = emptyList(),
    val selectedApps: List<InstalledApp> = emptyList(),
    val installedApps: List<InstalledApp> = emptyList(),
    val loadingApps: Boolean = false,
    val stage: SendStage = SendStage.PickingItems
)

@HiltViewModel
class SendViewModel @Inject constructor(
    application: Application,
    private val appListRepository: AppListRepository,
    private val stateHolder: TransferStateHolder
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(SendUiState())
    val uiState: StateFlow<SendUiState> = _uiState.asStateFlow()

    private val hotspotManager = HotspotManager(application)

    fun onFilesPicked(uris: List<Uri>) {
        val resolver = getApplication<Application>().contentResolver
        val items = uris.mapNotNull { uri ->
            runCatching {
                // Persist read access — the actual byte transfer happens later,
                // from the foreground service, possibly after this screen is gone.
                resolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    cursor.moveToFirst()
                    val name = if (nameIdx >= 0) cursor.getString(nameIdx) else uri.lastPathSegment ?: "file"
                    val size = if (sizeIdx >= 0) cursor.getLong(sizeIdx) else 0L
                    val mime = resolver.getType(uri) ?: "application/octet-stream"
                    PickedItem(uri, name, size, mime)
                }
            }.getOrNull()
        }
        _uiState.value = _uiState.value.copy(selectedFiles = _uiState.value.selectedFiles + items)
    }

    fun loadInstalledApps() {
        if (_uiState.value.installedApps.isNotEmpty()) return
        _uiState.value = _uiState.value.copy(loadingApps = true)
        viewModelScope.launch {
            val apps = appListRepository.getSharableApps()
            _uiState.value = _uiState.value.copy(installedApps = apps, loadingApps = false)
        }
    }

    fun toggleApp(app: InstalledApp) {
        val current = _uiState.value.selectedApps
        _uiState.value = _uiState.value.copy(
            selectedApps = if (current.contains(app)) current - app else current + app
        )
    }

    fun removeFile(item: PickedItem) {
        _uiState.value = _uiState.value.copy(selectedFiles = _uiState.value.selectedFiles - item)
    }

    fun startSending(deviceName: String) {
        val state = _uiState.value
        _uiState.value = state.copy(stage = SendStage.StartingHotspot)

        viewModelScope.launch {
            runCatching {
                val hotspot = hotspotManager.start()

                val sourceUris = mutableMapOf<String, Uri>()
                val items = mutableListOf<TransferItem>()

                state.selectedFiles.forEach { picked ->
                    val id = UUID.randomUUID().toString()
                    items += TransferItem(id, picked.name, picked.size, picked.mime, TransferItemType.FILE)
                    sourceUris[id] = picked.uri
                }
                state.selectedApps.forEach { app ->
                    val (item, uri) = appListRepository.toTransferItem(app)
                    items += item
                    sourceUris[item.id] = uri
                }

                val manifest = SessionManifest(senderName = deviceName, items = items)
                val qrContent = QrCodeGenerator.wifiQrPayload(hotspot.ssid, hotspot.password)
                val qrBitmap = QrCodeGenerator.generate(qrContent)

                _uiState.value = _uiState.value.copy(
                    stage = SendStage.WaitingForReceiver(qrBitmap, hotspot.ssid, hotspot.password)
                )

                TransferService.startSend(getApplication(), manifest, sourceUris)
                observeProgress()
            }.onFailure { e ->
                _uiState.value = _uiState.value.copy(stage = SendStage.Error(e.message ?: "Failed to start hotspot"))
            }
        }
    }

    private fun observeProgress() {
        viewModelScope.launch {
            stateHolder.progress.collect { progress ->
                if (progress.error != null) {
                    _uiState.value = _uiState.value.copy(stage = SendStage.Error(progress.error))
                    hotspotManager.stop()
                    return@collect
                }
                if (progress.isComplete) {
                    _uiState.value = _uiState.value.copy(stage = SendStage.Done)
                    hotspotManager.stop()
                } else if (progress.sessionActive || progress.bytesTransferredTotal > 0) {
                    _uiState.value = _uiState.value.copy(stage = SendStage.Sending(progress))
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        hotspotManager.stop()
    }
}
