package com.tom.novashare.ui.receive

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tom.novashare.data.model.TransferProgress
import com.tom.novashare.di.TransferStateHolder
import com.tom.novashare.service.TransferService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed interface ReceiveStage {
    data object WaitingToConnect : ReceiveStage
    data class Receiving(val progress: TransferProgress) : ReceiveStage
    data object Done : ReceiveStage
    data class Error(val message: String) : ReceiveStage
}

@HiltViewModel
class ReceiveViewModel @Inject constructor(
    application: Application,
    private val stateHolder: TransferStateHolder
) : AndroidViewModel(application) {

    private val _stage = MutableStateFlow<ReceiveStage>(ReceiveStage.WaitingToConnect)
    val stage: StateFlow<ReceiveStage> = _stage.asStateFlow()

    fun startReceiving() {
        stateHolder.reset()
        TransferService.startReceive(getApplication())
        viewModelScope.launch {
            stateHolder.progress.collect { progress ->
                when {
                    progress.error != null -> _stage.value = ReceiveStage.Error(progress.error)
                    progress.isComplete -> _stage.value = ReceiveStage.Done
                    progress.sessionActive || progress.bytesTransferredTotal > 0 ->
                        _stage.value = ReceiveStage.Receiving(progress)
                }
            }
        }
    }
}
