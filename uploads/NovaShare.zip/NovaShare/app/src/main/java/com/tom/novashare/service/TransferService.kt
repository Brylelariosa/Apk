package com.tom.novashare.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.tom.novashare.MainActivity
import com.tom.novashare.R
import com.tom.novashare.data.model.SessionManifest
import com.tom.novashare.data.model.TransferDirection
import com.tom.novashare.data.model.TransferProgress
import com.tom.novashare.data.network.TransferClient
import com.tom.novashare.data.network.TransferServer
import com.tom.novashare.data.repository.TransferHistoryRepository
import com.tom.novashare.di.TransferStateHolder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Runs one send or receive session at a time in the foreground so the OS
 * doesn't throttle the socket while the app is backgrounded, and reflects
 * live progress both as a notification and via [TransferStateHolder] for
 * the UI to observe.
 */
@AndroidEntryPoint
class TransferService : LifecycleService() {

    @Inject lateinit var stateHolder: TransferStateHolder
    @Inject lateinit var historyRepository: TransferHistoryRepository

    private var server: TransferServer? = null
    private var client: TransferClient? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        startForeground(NOTIFICATION_ID, buildNotification("Starting transfer\u2026", 0))

        when (intent?.action) {
            ACTION_SEND -> startSend()
            ACTION_RECEIVE -> startReceive()
            ACTION_CANCEL -> {
                server?.cancel()
                client?.cancel()
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startSend() {
        val payload = pendingSendPayload ?: run { stopSelf(); return }
        pendingSendPayload = null

        lifecycleScope.launch {
            val srv = TransferServer(contentResolver).also { server = it }
            val collectJob = lifecycleScope.launch {
                srv.progress.collect { p ->
                    stateHolder.update(p)
                    updateNotification(p)
                    if (!p.sessionActive && (p.isComplete || p.error != null)) {
                        historyRepository.record(TransferDirection.SENT, "Receiver", payload.manifest, p.isComplete)
                    }
                }
            }
            lifecycleScope.launch(Dispatchers.IO) {
                srv.sendSession(payload.manifest, payload.sourceUris)
                collectJob.cancel()
                stopSelf()
            }
        }
    }

    private fun startReceive() {
        lifecycleScope.launch {
            val cl = TransferClient(contentResolver).also { client = it }
            val collectJob = lifecycleScope.launch {
                cl.progress.collect { p ->
                    stateHolder.update(p)
                    updateNotification(p)
                }
            }
            lifecycleScope.launch(Dispatchers.IO) {
                val result = cl.receiveSession()
                if (result != null) {
                    historyRepository.record(TransferDirection.RECEIVED, result.manifest.senderName, result.manifest, true)
                }
                collectJob.cancel()
                stopSelf()
            }
        }
    }

    private fun updateNotification(progress: TransferProgress) {
        val percent = if (progress.totalSize > 0) {
            ((progress.bytesTransferredTotal * 100) / progress.totalSize).toInt()
        } else 0
        val text = when {
            progress.error != null -> "Transfer failed: ${progress.error}"
            progress.isComplete -> "Transfer complete"
            else -> "${progress.currentItemName} \u00b7 $percent%"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(text, percent))
    }

    private fun buildNotification(text: String, progressPercent: Int): Notification {
        ensureChannel()
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NovaShare")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_transfer)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setProgress(100, progressPercent, false)
            .build()
    }

    private fun ensureChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        if (manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Transfers", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    companion object {
        const val ACTION_SEND = "com.tom.novashare.action.SEND"
        const val ACTION_RECEIVE = "com.tom.novashare.action.RECEIVE"
        const val ACTION_CANCEL = "com.tom.novashare.action.CANCEL"
        private const val CHANNEL_ID = "transfer_channel"
        private const val NOTIFICATION_ID = 42

        // Set immediately before starting the service for ACTION_SEND. Kept
        // in-memory rather than as Intent extras: sender URIs and the
        // manifest live entirely within this process, so there's nothing to
        // gain from forcing them through Parcelable/Intent serialization.
        @Volatile var pendingSendPayload: SendPayload? = null
            private set

        fun startSend(context: Context, manifest: SessionManifest, sourceUris: Map<String, Uri>) {
            pendingSendPayload = SendPayload(manifest, sourceUris)
            context.startForegroundService(Intent(context, TransferService::class.java).setAction(ACTION_SEND))
        }

        fun startReceive(context: Context) {
            context.startForegroundService(Intent(context, TransferService::class.java).setAction(ACTION_RECEIVE))
        }

        fun cancel(context: Context) {
            context.startService(Intent(context, TransferService::class.java).setAction(ACTION_CANCEL))
        }
    }

    data class SendPayload(val manifest: SessionManifest, val sourceUris: Map<String, Uri>)
}
