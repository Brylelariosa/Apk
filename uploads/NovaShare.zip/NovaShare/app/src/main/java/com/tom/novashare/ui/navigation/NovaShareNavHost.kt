package com.tom.novashare.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tom.novashare.ui.history.HistoryScreen
import com.tom.novashare.ui.home.HomeScreen
import com.tom.novashare.ui.receive.ReceiveScreen
import com.tom.novashare.ui.send.SendScreen

object Routes {
    const val HOME = "home"
    const val SEND = "send"
    const val RECEIVE = "receive"
    const val HISTORY = "history"
}

@Composable
fun NovaShareNavHost() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) {
            HomeScreen(
                onSendClick = { navController.navigate(Routes.SEND) },
                onReceiveClick = { navController.navigate(Routes.RECEIVE) },
                onHistoryClick = { navController.navigate(Routes.HISTORY) }
            )
        }
        composable(Routes.SEND) { SendScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.RECEIVE) { ReceiveScreen(onBack = { navController.popBackStack() }) }
        composable(Routes.HISTORY) { HistoryScreen(onBack = { navController.popBackStack() }) }
    }
}
