package com.tom.novashare.di

import com.tom.novashare.data.model.TransferProgress
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single source of truth for in-flight transfer progress, shared between
 * TransferService (producer, runs the actual socket IO) and the Compose UI
 * (consumer) without either needing a direct reference to the other.
 */
@Singleton
class TransferStateHolder @Inject constructor() {
    private val _progress = MutableStateFlow(TransferProgress())
    val progress: StateFlow<TransferProgress> = _progress.asStateFlow()

    fun update(progress: TransferProgress) {
        _progress.value = progress
    }

    fun reset() {
        _progress.value = TransferProgress()
    }
}
