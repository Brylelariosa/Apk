package com.tom.novashare.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Denormalized on purpose: this app only ever needs to list past sessions,
 * never query into individual items, so a joined summary string avoids a
 * second table + join for no real benefit.
 */
@Entity(tableName = "transfer_sessions")
data class TransferSessionEntity(
    @PrimaryKey val id: String,
    val direction: String,
    val peerName: String,
    val itemCount: Int,
    val totalSizeBytes: Long,
    val timestamp: Long,
    val status: String,
    val itemNamesJoined: String
)
