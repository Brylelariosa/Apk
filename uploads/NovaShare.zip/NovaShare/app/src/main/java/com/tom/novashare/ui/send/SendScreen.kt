package com.tom.novashare.ui.send

import androidx.compose.ui.res.painterResource
import com.tom.novashare.R
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawable.toBitmap
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.tom.novashare.data.repository.InstalledApp
import com.tom.novashare.ui.components.DoneContent
import com.tom.novashare.ui.components.ErrorContent
import com.tom.novashare.ui.components.LoadingContent
import com.tom.novashare.ui.components.TransferProgressContent
import com.tom.novashare.ui.home.formatSize

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SendScreen(onBack: () -> Unit, viewModel: SendViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsState()
    var tab by remember { mutableStateOf(0) }

    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> viewModel.onFilesPicked(uris) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Send") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(painterResource(R.drawable.ic_arrow_back), contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (val stage = uiState.stage) {
                is SendStage.PickingItems -> PickingItemsContent(
                    uiState = uiState,
                    tab = tab,
                    onTabChange = { tab = it },
                    onPickFiles = { filePicker.launch(arrayOf("*/*")) },
                    onLoadApps = viewModel::loadInstalledApps,
                    onToggleApp = viewModel::toggleApp,
                    onRemoveFile = viewModel::removeFile,
                    onStart = { viewModel.startSending("My Device") }
                )
                is SendStage.StartingHotspot -> LoadingContent("Starting local hotspot\u2026")
                is SendStage.WaitingForReceiver -> WaitingForReceiverContent(stage)
                is SendStage.Sending -> TransferProgressContent(stage.progress, title = "Sending\u2026")
                is SendStage.Done -> DoneContent(onBack)
                is SendStage.Error -> ErrorContent(stage.message, onBack)
            }
        }
    }
}

@Composable
private fun PickingItemsContent(
    uiState: SendUiState,
    tab: Int,
    onTabChange: (Int) -> Unit,
    onPickFiles: () -> Unit,
    onLoadApps: () -> Unit,
    onToggleApp: (InstalledApp) -> Unit,
    onRemoveFile: (PickedItem) -> Unit,
    onStart: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { onTabChange(0) }, text = { Text("Files") })
            Tab(selected = tab == 1, onClick = { onTabChange(1); onLoadApps() }, text = { Text("Apps") })
        }

        Box(Modifier.weight(1f)) {
            if (tab == 0) {
                Column(Modifier.fillMaxSize()) {
                    Button(onClick = onPickFiles, modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                        Icon(painterResource(R.drawable.ic_add), contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Choose files")
                    }
                    LazyColumn {
                        items(uiState.selectedFiles) { item ->
                            ListItem(
                                headlineContent = { Text(item.name) },
                                supportingContent = { Text(formatSize(item.size)) },
                                trailingContent = {
                                    IconButton(onClick = { onRemoveFile(item) }) {
                                        Icon(painterResource(R.drawable.ic_delete), contentDescription = "Remove")
                                    }
                                }
                            )
                        }
                    }
                }
            } else {
                if (uiState.loadingApps) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                } else {
                    LazyColumn {
                        items(uiState.installedApps) { app ->
                            val checked = uiState.selectedApps.contains(app)
                            ListItem(
                                modifier = Modifier.clickable { onToggleApp(app) },
                                headlineContent = { Text(app.label) },
                                supportingContent = { Text(formatSize(app.apkSize)) },
                                leadingContent = {
                                    Image(
                                        bitmap = remember(app.packageName) { app.icon.toBitmap().asImageBitmap() },
                                        contentDescription = null,
                                        modifier = Modifier.size(40.dp)
                                    )
                                },
                                trailingContent = { Checkbox(checked = checked, onCheckedChange = { onToggleApp(app) }) }
                            )
                        }
                    }
                }
            }
        }

        val count = uiState.selectedFiles.size + uiState.selectedApps.size
        Button(onClick = onStart, enabled = count > 0, modifier = Modifier.padding(16.dp).fillMaxWidth()) {
            Text(if (count > 0) "Send $count item(s)" else "Select items to send")
        }
    }
}

@Composable
private fun WaitingForReceiverContent(stage: SendStage.WaitingForReceiver) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Text(
            "Ask the receiver to scan this code",
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Image(
            bitmap = stage.qrBitmap.asImageBitmap(),
            contentDescription = "WiFi QR code",
            modifier = Modifier.size(240.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text("Scanning with any camera app joins their phone to your hotspot automatically.", textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Or connect manually:", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(4.dp))
                Text("Network: ${stage.ssid}")
                Text("Password: ${stage.password}")
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Then open NovaShare on their phone and tap Receive",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}
