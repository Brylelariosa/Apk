package com.tom.novashare.data.repository

import com.tom.novashare.data.local.TransferDao
import com.tom.novashare.data.local.TransferSessionEntity
import com.tom.novashare.data.model.SessionManifest
import com.tom.novashare.data.model.TransferDirection
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TransferHistoryRepository @Inject constructor(private val dao: TransferDao) {

    fun observeHistory(): Flow<List<TransferSessionEntity>> = dao.observeHistory()

    suspend fun record(direction: TransferDirection, peerName: String, manifest: SessionManifest, succeeded: Boolean) {
        dao.insert(
            TransferSessionEntity(
                id = UUID.randomUUID().toString(),
                direction = direction.name,
                peerName = peerName,
                itemCount = manifest.items.size,
                totalSizeBytes = manifest.items.sumOf { it.size },
                timestamp = System.currentTimeMillis(),
                status = if (succeeded) "COMPLETED" else "FAILED",
                itemNamesJoined = manifest.items.joinToString(", ") { it.name }.take(500)
            )
        )
    }

    suspend fun clear() = dao.clearAll()
}
