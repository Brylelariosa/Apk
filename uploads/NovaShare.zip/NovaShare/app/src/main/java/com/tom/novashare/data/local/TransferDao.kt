package com.tom.novashare.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TransferDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: TransferSessionEntity)

    @Query("SELECT * FROM transfer_sessions ORDER BY timestamp DESC")
    fun observeHistory(): Flow<List<TransferSessionEntity>>

    @Query("DELETE FROM transfer_sessions")
    suspend fun clearAll()
}
