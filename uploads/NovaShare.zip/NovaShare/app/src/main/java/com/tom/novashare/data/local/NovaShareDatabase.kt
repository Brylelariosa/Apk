package com.tom.novashare.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [TransferSessionEntity::class], version = 1, exportSchema = false)
abstract class NovaShareDatabase : RoomDatabase() {
    abstract fun transferDao(): TransferDao

    companion object {
        @Volatile private var INSTANCE: NovaShareDatabase? = null

        fun getInstance(context: Context): NovaShareDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    NovaShareDatabase::class.java,
                    "novashare.db"
                ).build().also { INSTANCE = it }
            }
    }
}
