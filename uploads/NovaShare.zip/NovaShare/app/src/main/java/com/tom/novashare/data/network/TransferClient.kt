package com.tom.novashare.data.network

import android.content.ContentResolver
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.tom.novashare.data.model.SessionManifest
import com.tom.novashare.data.model.TransferProgress
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.BufferedInputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Receiver side: connects to the sender's socket and streams items straight into MediaStore. */
class TransferClient(private val contentResolver: ContentResolver) {

    private val _progress = MutableStateFlow(TransferProgress())
    val progress: StateFlow<TransferProgress> = _progress.asStateFlow()

    @Volatile private var cancelled = false
    private var socket: Socket? = null

    /** Call from an IO dispatcher. */
    fun receiveSession(
        host: String = HotspotManager.GATEWAY_ADDRESS,
        port: Int = HotspotManager.TRANSFER_PORT
    ): ReceivedSession? {
        cancelled = false
        val sock = Socket().also { socket = it }

        return runCatching {
            sock.connect(InetSocketAddress(host, port), CONNECT_TIMEOUT_MS)
            sock.use { s ->
                val input = BufferedInputStream(s.getInputStream())
                val manifest = TransferProtocol.readManifest(input)
                val totalSize = manifest.items.sumOf { it.size }
                _progress.value = TransferProgress(sessionActive = true, totalItems = manifest.items.size, totalSize = totalSize)

                val savedUris = mutableListOf<String>()
                var totalReceived = 0L
                var lastTick = System.currentTimeMillis()
                var bytesSinceTick = 0L

                manifest.items.forEachIndexed { index, item ->
                    if (cancelled) return@forEachIndexed
                    val uri = createOutputTarget(item.name, item.mimeType)
                    var itemReceived = 0L
                    contentResolver.openOutputStream(uri)?.use { output ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        var remaining = item.size
                        while (remaining > 0 && !cancelled) {
                            val toRead = minOf(buffer.size.toLong(), remaining).toInt()
                            val read = input.read(buffer, 0, toRead)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            remaining -= read
                            itemReceived += read
                            totalReceived += read
                            bytesSinceTick += read

                            val now = System.currentTimeMillis()
                            if (now - lastTick >= TICK_MS) {
                                val speed = (bytesSinceTick * 1000L) / (now - lastTick).coerceAtLeast(1)
                                _progress.value = _progress.value.copy(
                                    currentItemIndex = index,
                                    currentItemName = item.name,
                                    currentItemSize = item.size,
                                    bytesTransferredCurrentItem = itemReceived,
                                    bytesTransferredTotal = totalReceived,
                                    speedBytesPerSec = speed
                                )
                                lastTick = now
                                bytesSinceTick = 0
                            }
                        }
                    }
                    savedUris += uri.toString()
                }
                _progress.value = _progress.value.copy(
                    bytesTransferredTotal = totalReceived,
                    isComplete = !cancelled,
                    sessionActive = false
                )
                ReceivedSession(manifest, savedUris)
            }
        }.onFailure { e ->
            _progress.value = _progress.value.copy(sessionActive = false, error = e.message ?: "Transfer failed")
        }.getOrNull()
    }

    private fun createOutputTarget(name: String, mime: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/NovaShare")
            }
        }
        val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Downloads.EXTERNAL_CONTENT_URI
        } else {
            MediaStore.Files.getContentUri("external")
        }
        return contentResolver.insert(collection, values)
            ?: error("Unable to create MediaStore entry for $name")
    }

    fun cancel() {
        cancelled = true
        runCatching { socket?.close() }
    }

    data class ReceivedSession(val manifest: SessionManifest, val savedUris: List<String>)

    companion object {
        private const val BUFFER_SIZE = 64 * 1024
        private const val TICK_MS = 400L
        private const val CONNECT_TIMEOUT_MS = 15_000
    }
}
