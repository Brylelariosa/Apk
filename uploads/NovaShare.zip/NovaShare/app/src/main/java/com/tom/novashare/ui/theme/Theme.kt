package com.tom.novashare.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = NovaPurple,
    secondary = NovaAccent,
    background = NovaBackground,
    surface = NovaSurface
)

private val LightColors = lightColorScheme(
    primary = NovaPurple,
    secondary = NovaAccent
)

@Composable
fun NovaShareTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colorScheme, content = content)
}
