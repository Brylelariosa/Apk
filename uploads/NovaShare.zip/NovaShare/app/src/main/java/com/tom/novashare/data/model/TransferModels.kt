package com.tom.novashare.data.model

enum class TransferItemType { FILE, APK }
enum class TransferDirection { SENT, RECEIVED }

/** A single file or app to move in one transfer session. */
data class TransferItem(
    val id: String,
    val name: String,
    val size: Long,
    val mimeType: String,
    val type: TransferItemType,
    val packageName: String? = null
)

/** Sent as the first message over the socket so the receiver knows what's coming. */
data class SessionManifest(
    val senderName: String,
    val items: List<TransferItem>
)

/** Live progress for whichever session is currently active — sender or receiver side. */
data class TransferProgress(
    val sessionActive: Boolean = false,
    val currentItemIndex: Int = 0,
    val totalItems: Int = 0,
    val currentItemName: String = "",
    val bytesTransferredCurrentItem: Long = 0,
    val currentItemSize: Long = 0,
    val bytesTransferredTotal: Long = 0,
    val totalSize: Long = 0,
    val speedBytesPerSec: Long = 0,
    val isComplete: Boolean = false,
    val error: String? = null
)

data class HotspotCredentials(
    val ssid: String,
    val password: String
)
