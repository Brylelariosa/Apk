package com.tom.novashare.ui.receive

import androidx.compose.ui.res.painterResource
import com.tom.novashare.R
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.tom.novashare.ui.components.DoneContent
import com.tom.novashare.ui.components.ErrorContent
import com.tom.novashare.ui.components.TransferProgressContent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReceiveScreen(onBack: () -> Unit, viewModel: ReceiveViewModel = hiltViewModel()) {
    val stage by viewModel.stage.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Receive") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(painterResource(R.drawable.ic_arrow_back), contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            when (val current = stage) {
                is ReceiveStage.WaitingToConnect -> Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
                ) {
                    Icon(painterResource(R.drawable.ic_wifi), contentDescription = null, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "First, join the sender's WiFi network \u2014 scan their QR code with your camera, or connect manually in WiFi settings.",
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(24.dp))
                    Button(onClick = { viewModel.startReceiving() }) {
                        Text("I'm connected \u2014 start receiving")
                    }
                }
                is ReceiveStage.Receiving -> TransferProgressContent(current.progress, title = "Receiving\u2026")
                is ReceiveStage.Done -> DoneContent(onBack)
                is ReceiveStage.Error -> ErrorContent(current.message, onBack)
            }
        }
    }
}
