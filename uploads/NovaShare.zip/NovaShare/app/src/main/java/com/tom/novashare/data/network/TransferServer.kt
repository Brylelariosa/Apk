package com.tom.novashare.data.network

import android.content.ContentResolver
import android.net.Uri
import com.tom.novashare.data.model.SessionManifest
import com.tom.novashare.data.model.TransferProgress
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.BufferedOutputStream
import java.net.ServerSocket
import java.net.Socket

/** Sender side: hosts a single-shot TCP server on top of the local hotspot. */
class TransferServer(
    private val contentResolver: ContentResolver,
    private val port: Int = HotspotManager.TRANSFER_PORT
) {
    private val _progress = MutableStateFlow(TransferProgress())
    val progress: StateFlow<TransferProgress> = _progress.asStateFlow()

    private var serverSocket: ServerSocket? = null
    @Volatile private var cancelled = false

    /** Blocks until a receiver connects and the whole session finishes. Call from an IO dispatcher. */
    fun sendSession(manifest: SessionManifest, sourceUris: Map<String, Uri>) {
        cancelled = false
        val totalSize = manifest.items.sumOf { it.size }
        _progress.value = TransferProgress(sessionActive = true, totalItems = manifest.items.size, totalSize = totalSize)

        val server = ServerSocket(port).also { serverSocket = it }
        server.soTimeout = CONNECT_TIMEOUT_MS

        runCatching {
            server.accept().use { socket ->
                val out = BufferedOutputStream(socket.getOutputStream())
                TransferProtocol.writeManifest(out, manifest)

                var totalSent = 0L
                var lastTick = System.currentTimeMillis()
                var bytesSinceTick = 0L

                manifest.items.forEachIndexed { index, item ->
                    if (cancelled) return@forEachIndexed
                    val uri = sourceUris[item.id] ?: return@forEachIndexed
                    contentResolver.openInputStream(uri)?.use { input ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        var itemSent = 0L
                        while (!cancelled) {
                            val read = input.read(buffer)
                            if (read == -1) break
                            out.write(buffer, 0, read)
                            itemSent += read
                            totalSent += read
                            bytesSinceTick += read

                            val now = System.currentTimeMillis()
                            if (now - lastTick >= TICK_MS) {
                                val speed = (bytesSinceTick * 1000L) / (now - lastTick).coerceAtLeast(1)
                                _progress.value = _progress.value.copy(
                                    currentItemIndex = index,
                                    currentItemName = item.name,
                                    currentItemSize = item.size,
                                    bytesTransferredCurrentItem = itemSent,
                                    bytesTransferredTotal = totalSent,
                                    speedBytesPerSec = speed
                                )
                                lastTick = now
                                bytesSinceTick = 0
                            }
                        }
                    }
                }
                out.flush()
                _progress.value = _progress.value.copy(
                    bytesTransferredTotal = totalSent,
                    isComplete = !cancelled,
                    sessionActive = false
                )
            }
        }.onFailure { e ->
            _progress.value = _progress.value.copy(sessionActive = false, error = e.message ?: "Transfer failed")
        }
    }

    fun cancel() {
        cancelled = true
        runCatching { serverSocket?.close() }
    }

    companion object {
        private const val BUFFER_SIZE = 64 * 1024
        private const val TICK_MS = 400L
        private const val CONNECT_TIMEOUT_MS = 5 * 60 * 1000
    }
}
