package com.tom.novashare.ui.theme

import androidx.compose.ui.graphics.Color

val NovaPurple = Color(0xFF7C4DFF)
val NovaBackground = Color(0xFF121225)
val NovaSurface = Color(0xFF1B1B3A)
val NovaAccent = Color(0xFF00E5B0)
