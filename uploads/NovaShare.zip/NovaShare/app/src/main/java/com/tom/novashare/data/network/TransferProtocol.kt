package com.tom.novashare.data.network

import com.tom.novashare.data.model.SessionManifest
import com.tom.novashare.data.model.TransferItem
import com.tom.novashare.data.model.TransferItemType
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * Wire format: a 4-byte big-endian length prefix followed by UTF-8 JSON
 * describing the whole session, then the raw bytes of every item back to
 * back in manifest order. No per-file framing needed beyond the size each
 * item already declares in the manifest — one fewer thing that can drift
 * out of sync between sender and receiver.
 */
object TransferProtocol {

    fun writeManifest(out: OutputStream, manifest: SessionManifest) {
        val json = JSONObject().apply {
            put("senderName", manifest.senderName)
            put("items", JSONArray().apply {
                manifest.items.forEach { item ->
                    put(JSONObject().apply {
                        put("id", item.id)
                        put("name", item.name)
                        put("size", item.size)
                        put("mime", item.mimeType)
                        put("type", item.type.name)
                        item.packageName?.let { put("packageName", it) }
                    })
                }
            })
        }
        val bytes = json.toString().toByteArray(Charsets.UTF_8)
        val dataOut = DataOutputStream(out)
        dataOut.writeInt(bytes.size)
        dataOut.write(bytes)
        dataOut.flush()
    }

    fun readManifest(input: InputStream): SessionManifest {
        val dataIn = DataInputStream(input)
        val length = dataIn.readInt()
        require(length in 1..MAX_MANIFEST_BYTES) { "Manifest length out of bounds: $length" }
        val buffer = ByteArray(length)
        dataIn.readFully(buffer)
        val json = JSONObject(String(buffer, Charsets.UTF_8))
        val items = mutableListOf<TransferItem>()
        val itemsJson = json.getJSONArray("items")
        for (i in 0 until itemsJson.length()) {
            val itemJson = itemsJson.getJSONObject(i)
            items.add(
                TransferItem(
                    id = itemJson.getString("id"),
                    name = itemJson.getString("name"),
                    size = itemJson.getLong("size"),
                    mimeType = itemJson.getString("mime"),
                    type = TransferItemType.valueOf(itemJson.getString("type")),
                    packageName = itemJson.optString("packageName", null)
                )
            )
        }
        return SessionManifest(senderName = json.getString("senderName"), items = items)
    }

    private const val MAX_MANIFEST_BYTES = 5 * 1024 * 1024
}
