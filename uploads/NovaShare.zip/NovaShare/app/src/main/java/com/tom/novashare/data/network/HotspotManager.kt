package com.tom.novashare.data.network

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import com.tom.novashare.data.model.HotspotCredentials
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Wraps WifiManager.LocalOnlyHotspotReservation.
 *
 * Deliberately not WifiP2p/Wifi Direct — that API needs a peer discovery and
 * connection handshake on both sides that's fiddly and inconsistent across
 * OEMs. A local-only hotspot is one-directional and dead simple: one phone
 * hosts a private network, the other joins it like any other WiFi network.
 */
class HotspotManager(private val context: Context) {

    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null

    suspend fun start(): HotspotCredentials = suspendCancellableCoroutine { cont ->
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager

        wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
            override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation) {
                reservation = res
                val ssid: String
                val password: String
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val softApConfig = res.softApConfiguration
                    ssid = softApConfig.ssid ?: "NovaShare"
                    password = softApConfig.passphrase ?: ""
                } else {
                    @Suppress("DEPRECATION")
                    val config = res.wifiConfiguration
                    @Suppress("DEPRECATION")
                    ssid = config?.SSID ?: "NovaShare"
                    @Suppress("DEPRECATION")
                    password = config?.preSharedKey ?: ""
                }
                if (cont.isActive) cont.resume(HotspotCredentials(ssid, password))
            }

            override fun onStopped() {
                Log.d(TAG, "Local hotspot stopped")
                reservation = null
            }

            override fun onFailed(reason: Int) {
                if (cont.isActive) {
                    cont.resumeWithException(IllegalStateException("Hotspot failed to start (reason=$reason)"))
                }
            }
        }, null)

        cont.invokeOnCancellation { stop() }
    }

    fun stop() {
        reservation?.close()
        reservation = null
    }

    companion object {
        private const val TAG = "HotspotManager"
        // A LocalOnlyHotspot on Android always gateways connected clients at this address.
        const val GATEWAY_ADDRESS = "192.168.49.1"
        const val TRANSFER_PORT = 8988
    }
}
