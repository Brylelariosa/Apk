package com.tom.novashare.util

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

object QrCodeGenerator {

    /**
     * Standard WIFI: QR payload — any stock camera app can already scan this
     * to join the network directly, so the receiver never needs a custom
     * in-app scanner for this step.
     */
    fun wifiQrPayload(ssid: String, password: String): String =
        "WIFI:T:WPA;S:${escape(ssid)};P:${escape(password)};;"

    private fun escape(value: String) = value
        .replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace(":", "\\:")

    fun generate(content: String, size: Int = 512): Bitmap {
        val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bitmap.setPixel(x, y, if (bitMatrix[x, y]) Color.BLACK else Color.WHITE)
            }
        }
        return bitmap
    }
}
