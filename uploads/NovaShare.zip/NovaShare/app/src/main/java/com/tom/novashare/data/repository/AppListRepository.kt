package com.tom.novashare.data.repository

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import androidx.core.content.FileProvider
import com.tom.novashare.data.model.TransferItem
import com.tom.novashare.data.model.TransferItemType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

data class InstalledApp(
    val label: String,
    val packageName: String,
    val versionName: String?,
    val icon: Drawable,
    val apkSize: Long,
    val sourcePath: String
)

/** Lists installed apps and packages their APKs up for sending, like any other file. */
@Singleton
class AppListRepository @Inject constructor(
    @dagger.hilt.android.qualifiers.ApplicationContext private val context: Context
) {

    suspend fun getSharableApps(includeSystem: Boolean = false): List<InstalledApp> =
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
                .asSequence()
                .filter { includeSystem || it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
                .mapNotNull { appInfo ->
                    runCatching {
                        val packageInfo = pm.getPackageInfo(appInfo.packageName, 0)
                        val apkFile = File(appInfo.sourceDir)
                        InstalledApp(
                            label = pm.getApplicationLabel(appInfo).toString(),
                            packageName = appInfo.packageName,
                            versionName = packageInfo.versionName,
                            icon = pm.getApplicationIcon(appInfo),
                            apkSize = apkFile.length(),
                            sourcePath = appInfo.sourceDir
                        )
                    }.getOrNull()
                }
                .sortedBy { it.label.lowercase() }
                .toList()
        }

    /** Copies the APK into our own cache dir so it's exposable via FileProvider for the transfer. */
    fun toTransferItem(app: InstalledApp): Pair<TransferItem, Uri> {
        val apkFile = File(app.sourcePath)
        val cacheDir = File(context.cacheDir, "apk_export").apply { mkdirs() }
        val exported = File(cacheDir, "${app.packageName}.apk")
        if (!exported.exists() || exported.length() != apkFile.length()) {
            apkFile.copyTo(exported, overwrite = true)
        }
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", exported)
        val item = TransferItem(
            id = UUID.randomUUID().toString(),
            name = "${app.label.replace(Regex("[^A-Za-z0-9]"), "_")}.apk",
            size = exported.length(),
            mimeType = "application/vnd.android.package-archive",
            type = TransferItemType.APK,
            packageName = app.packageName
        )
        return item to uri
    }
}
