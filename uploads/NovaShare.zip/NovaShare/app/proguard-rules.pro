# Debug builds only for now (release minify disabled) — kept for when signing is added later.
