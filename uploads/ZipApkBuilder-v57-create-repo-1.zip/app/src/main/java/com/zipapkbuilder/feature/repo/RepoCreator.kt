package com.zipapkbuilder.feature.repo

import android.app.AlertDialog
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.material.textfield.TextInputLayout
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.dialogTitleBar
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.feature.build.BuildRetryManager
import com.zipapkbuilder.net.GitHubRepos

/**
 * Creates a new GitHub repository from inside the app and makes it the active one: the
 * "New repository" popup ([showCreateRepoDialog]), then the create request, a wait until the
 * repo is usable, and a hand-over to [RepoSwitcher.applySwitchRepo] so every piece of per-repo
 * session state is reset exactly as it is for a normal switch.
 *
 * The request itself, the name rules and the error wording all live in [GitHubRepos], which the
 * build flow's silent create-on-first-build shares; this class owns only the form and what
 * happens after. It is reachable from Settings and from the "Switch repository" list (which
 * File manager and Artifacts open too), so it is one tap away wherever the repo can be changed.
 *
 * The popup stays open while the request runs, so a taken name or a missing token scope shows up
 * right where it can be fixed instead of after the popup has gone. If the popup was dismissed
 * mid-request the repo is still created, and a success is still adopted — it exists on GitHub
 * either way — while a failure goes to the console log instead.
 */
class RepoCreator(private val activity: MainActivity) {

    private val retry = BuildRetryManager()

    fun showCreateRepoDialog() {
        val token = activity.requireToken("Enter your GitHub token first so the repository can be created.")
            ?: return

        val form = activity.layoutInflater.inflate(R.layout.dialog_new_repo, null)
        val tilName       = form.findViewById<TextInputLayout>(R.id.tilNewRepoName)
        val etName        = form.findViewById<EditText>(R.id.etNewRepoName)
        val etDescription = form.findViewById<EditText>(R.id.etNewRepoDescription)
        val switchPrivate = form.findViewById<CompoundButton>(R.id.switchNewRepoPrivate)
        val statusRow     = form.findViewById<View>(R.id.rowNewRepoStatus)
        val statusSpinner = form.findViewById<ProgressBar>(R.id.pbNewRepo)
        val statusText    = form.findViewById<TextView>(R.id.tvNewRepoStatus)

        lateinit var dlg: AlertDialog
        var inFlight = false

        fun setFormEnabled(enabled: Boolean) {
            etName.isEnabled = enabled
            etDescription.isEnabled = enabled
            switchPrivate.isEnabled = enabled
        }

        fun showStatus(message: String?, working: Boolean = false, isError: Boolean = false) {
            statusRow.visibility = if (message.isNullOrEmpty()) View.GONE else View.VISIBLE
            statusSpinner.visibility = if (working) View.VISIBLE else View.GONE
            statusText.text = message.orEmpty()
            statusText.setTextColor(activity.getColor(if (isError) R.color.text_error else R.color.text_secondary))
        }

        // Live feedback on the name. An empty field is not an error yet (the helper text is
        // showing); that is only reported when Create is tapped.
        etName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val typed = s?.toString().orEmpty()
                tilName.error = if (typed.isBlank()) null else GitHubRepos.nameProblem(typed)
                if (!inFlight) showStatus(null)
            }
        })

        fun dialogIsUp() = !activity.isFinishing && !activity.isDestroyed && dlg.isShowing

        fun finish(result: GitHubRepos.CreateResult) {
            inFlight = false
            when (result) {
                is GitHubRepos.CreateResult.Created -> {
                    if (dialogIsUp()) dlg.dismiss()
                    adopt(result.repo)
                }
                is GitHubRepos.CreateResult.Refused -> {
                    if (dialogIsUp()) {
                        setFormEnabled(true)
                        if (result.isNameProblem) {
                            showStatus(null)
                            tilName.error = result.message
                            etName.requestFocus()
                        } else {
                            showStatus(result.message, isError = true)
                        }
                    } else {
                        activity.appendLog("[error] Could not create the repository: ${result.message}")
                    }
                }
            }
        }

        fun submit() {
            if (inFlight) return
            val name = etName.text.toString().trim()
            GitHubRepos.nameProblem(name)?.let { problem ->
                tilName.error = problem
                etName.requestFocus()
                return
            }
            val request = GitHubRepos.NewRepo(
                name = name,
                description = etDescription.text.toString(),
                isPrivate = switchPrivate.isChecked
            )

            inFlight = true
            tilName.error = null
            setFormEnabled(false)
            showStatus("Creating $name…", working = true)
            (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(form.windowToken, 0)

            activity.bgExecutor.execute {
                val result = try {
                    GitHubRepos.create(token, request).also { created ->
                        if (created is GitHubRepos.CreateResult.Created) waitUntilReady(token, created.repo)
                    }
                } catch (e: Exception) {
                    GitHubRepos.CreateResult.Refused(Formatters.friendlyError(e), isNameProblem = false)
                }
                activity.mainHandler.post { finish(result) }
            }
        }

        etDescription.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { submit(); true } else false
        }

        val content = activity.dialogWithActions(
            form,
            DialogAction("Create", ButtonTone.GREEN, R.drawable.ic_add) { submit() },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(
                activity.dialogTitleBar(
                    "New repository", R.drawable.ic_add, ButtonTone.GREEN,
                    subtitle = "Created on your GitHub account"
                ) { dlg.dismiss() }
            )
            .setView(content)
            .show()

        // Straight into typing: focus the name and bring the keyboard up with the popup.
        dlg.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE or
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        etName.requestFocus()
    }

    /**
     * Polls until the new repo's default branch exists (see [GitHubRepos.isReady]) — at most
     * [READY_TIMEOUT_MS]. Runs on a background thread. Never throws and never fails the create:
     * the repo exists either way, so a timeout is only a warning in the log.
     */
    private fun waitUntilReady(token: String, repo: GitHubRepos.CreatedRepo) {
        var ready = false
        try {
            retry.poll(timeoutMs = READY_TIMEOUT_MS, intervalMs = READY_INTERVAL_MS) {
                ready = GitHubRepos.isReady(token, repo)
                ready
            }
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        if (!ready) {
            activity.appendLog("[warn] ${repo.fullName} was created, but GitHub hasn't finished setting it up yet — give it a few seconds before uploading.")
        }
    }

    /** Makes [repo] the active repository, on the branch GitHub says is its default. Main thread. */
    private fun adopt(repo: GitHubRepos.CreatedRepo) {
        val visibility = if (repo.isPrivate) "private" else "public"
        activity.appendLog("[ok] Created ${repo.fullName} ($visibility)" + if (repo.htmlUrl.isNotEmpty()) " — ${repo.htmlUrl}" else "")
        activity.repoSwitcher.applySwitchRepo(repo.name, repo.defaultBranch)
    }

    private companion object {
        const val READY_TIMEOUT_MS = 20_000L
        const val READY_INTERVAL_MS = 1_500L
    }
}
