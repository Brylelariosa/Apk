package com.browser.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.util.TypedValue
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.webkit.JavascriptInterface
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// ── Per-tab state ──────────────────────────────────────────────────────
data class BrowserTab(
    val id: Int,
    val webView: ScrollAwareWebView,
    var url: String   = "",
    var title: String = "New Tab"
)

class MainActivity : AppCompatActivity() {

    // ── Static views (not per-tab) ─────────────────────────────────────
    private lateinit var webViewContainer: FrameLayout
    private lateinit var urlBar:           LinearLayout
    private lateinit var urlInput:         EditText
    private lateinit var btnBack:          ImageButton
    private lateinit var btnForward:       ImageButton
    private lateinit var btnRefresh:       ImageButton
    private lateinit var btnSettings:      ImageButton
    private lateinit var btnAddSpeedDial:  ImageButton
    private lateinit var btnTabCount:      TextView
    private lateinit var btnToggle:        ImageButton
    private lateinit var pageProgress:     ProgressBar
    private lateinit var tapZoneIndicator: View

    // ── Tab management ─────────────────────────────────────────────────
    private val tabs = mutableListOf<BrowserTab>()
    private var activeTabIndex = 0
    private var tabIdCounter = 0

    /** Always points to the active tab's WebView. */
    private val webView: ScrollAwareWebView get() = tabs[activeTabIndex].webView

    // ── Gesture detector ───────────────────────────────────────────────
    private var gestureDetector: GestureDetector? = null

    // ── Shared prefs ───────────────────────────────────────────────────
    private val prefs by lazy { getSharedPreferences("browser", MODE_PRIVATE) }

    // ── State ──────────────────────────────────────────────────────────
    private var urlBarVisible    = false
    private var toggleVisible    = true
    private var isOnHomePage     = false
    private var isImeVisible     = false
    private var webInputFocused  = false
    private var debugOverlayVisible = false

    @Volatile private var currentHost: String? = null
    @Volatile private var adBlockEnabled  = true
    @Volatile private var dataSaverLevel  = 0
    @Volatile private var fabBehavior     = 0
    @Volatile private var tapZone         = 2
    @Volatile private var swipeNavEnabled = false

    private lateinit var debugOverlayView: TextView

    private val resetWebInputFocusedRunnable = Runnable {
        if (!isImeVisible) { webInputFocused = false }
    }

    // ── Scroll throttle ────────────────────────────────────────────────
    private var lastScrollMs = 0L

    companion object {
        private const val MOBILE_UA =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

        private val DATA_SAVER_LABELS = arrayOf(
            "Off",
            "High Quality  (~20% saved)",
            "Medium Quality (~40% saved)",
            "Low Quality    (~65% saved)",
            "No Images      (~80% saved)"
        )
        private val FAB_BEHAVIOR_LABELS = arrayOf(
            "Auto-hide on scroll",
            "Tap page to hide",
            "Always visible",
            "Hidden – tap zone"
        )
        private val TAP_ZONE_LABELS = arrayOf(
            "Top of screen", "Bottom-left", "Bottom-center", "Bottom-right"
        )
        private val TAP_ZONE_SHORT = arrayOf("Top", "Btm-L", "Btm-C", "Btm-R")

        private val DEFAULT_SPEED_DIAL = """[
{"url":"https://www.google.com","name":"Google"},
{"url":"https://www.youtube.com","name":"YouTube"},
{"url":"https://www.facebook.com","name":"Facebook"},
{"url":"https://www.reddit.com","name":"Reddit"},
{"url":"https://x.com","name":"X"},
{"url":"https://www.wikipedia.org","name":"Wikipedia"},
{"url":"https://github.com","name":"GitHub"},
{"url":"https://gmail.com","name":"Gmail"}]""".trimIndent()
    }

    // ══════════════════════════════════════════════════════════════════
    // HOME_HTML — defined after companion so string is not too crowded
    // ══════════════════════════════════════════════════════════════════

    private val HOME_HTML get() = buildHomeHtml()

    private fun buildHomeHtml(): String = """
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{
  background:#0a0a0a;color:#fff;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  min-height:100vh;display:flex;flex-direction:column;
  align-items:center;padding:52px 18px 30px;
}
.clock{font-size:68px;font-weight:200;letter-spacing:-3px;line-height:1;
  background:linear-gradient(135deg,#fff 40%,#4FC3F7);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.date{font-size:13px;color:#666;margin-top:6px;margin-bottom:36px;letter-spacing:.5px}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;width:100%;max-width:400px}
a{text-decoration:none;color:inherit}
.card{
  display:flex;flex-direction:column;align-items:center;gap:7px;
  padding:14px 6px 11px;border-radius:16px;background:#161616;
  border:1px solid #1e1e1e;transition:background .12s,transform .1s;
  position:relative;user-select:none;-webkit-user-select:none;
}
.card:active{background:#222;transform:scale(.95)}
.card.editing{border-color:#2a2a2a;animation:wobble .35s infinite alternate}
@keyframes wobble{from{transform:rotate(-1.8deg)}to{transform:rotate(1.8deg)}}
.icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;
  justify-content:center;overflow:hidden;background:#1e1e1e;flex-shrink:0}
.icon img{width:32px;height:32px;object-fit:contain;display:block}
.fallback{width:46px;height:46px;border-radius:12px;display:none;
  align-items:center;justify-content:center;font-size:20px;font-weight:800;color:#fff}
.label{font-size:10px;color:#777;text-align:center;letter-spacing:.3px;
  width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.del-btn{position:absolute;top:-7px;right:-7px;width:22px;height:22px;border-radius:50%;
  background:#FF4444;display:none;align-items:center;justify-content:center;
  font-size:14px;line-height:1;color:#fff;z-index:20;font-weight:700}
.card.editing .del-btn{display:flex}
.add-card{cursor:pointer;border-style:dashed;border-color:#252525;background:#0e0e0e}
.add-card:active{background:#1a1a1a}
.done-bar{grid-column:1/-1;display:flex;align-items:center;justify-content:center;
  padding:11px;border-radius:12px;background:#0d1a22;border:1px solid #4FC3F7;
  color:#4FC3F7;font-size:13px;font-weight:600;cursor:pointer;margin-top:2px}
/* Modal — repositioned by visualViewport JS to stay above keyboard */
.overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.82);
  z-index:200;align-items:flex-end;justify-content:center}
.overlay.open{display:flex}
.sheet{background:#1c1c1e;border-radius:20px 20px 0 0;
  padding:22px 20px 36px;width:100%;max-width:480px}
.sheet h3{font-size:16px;font-weight:600;margin-bottom:16px;color:#fff}
.sheet input{width:100%;background:#0a0a0a;border:1px solid #2a2a2a;
  border-radius:10px;padding:12px 14px;color:#fff;font-size:15px;
  outline:none;margin-bottom:10px;-webkit-appearance:none}
.sheet input::placeholder{color:#3a3a3a}
.sheet input:focus{border-color:#4FC3F7}
.row{display:flex;gap:10px;margin-top:4px}
.btn{flex:1;padding:13px;border-radius:10px;border:none;font-size:15px;cursor:pointer;font-weight:500}
.btn-cancel{background:#2a2a2a;color:#888}
.btn-add{background:#4FC3F7;color:#000;font-weight:700}
</style>
</head>
<body>
<div class="clock" id="clk"></div>
<div class="date"  id="dt"></div>
<div class="grid"  id="grid"></div>

<div class="overlay" id="overlay" onclick="if(event.target===this)closeSheet()">
  <div class="sheet">
    <h3>Add to Speed Dial</h3>
    <input id="iUrl"  type="url"  placeholder="https://example.com" autocomplete="off" spellcheck="false">
    <input id="iName" type="text" placeholder="Name  (auto-filled)" autocomplete="off">
    <div class="row">
      <button class="btn btn-cancel" onclick="closeSheet()">Cancel</button>
      <button class="btn btn-add"    onclick="confirmAdd()">Add</button>
    </div>
  </div>
</div>

<script>
var DEFAULTS=${DEFAULT_SPEED_DIAL};
var editing=false;

/* ── Storage: native bridge first, localStorage fallback ── */
function sdLoad(){
  try{
    if(typeof SpeedDial!=='undefined'){
      var d=SpeedDial.get();
      if(d&&d.length>2)return JSON.parse(d);
    }
    var s=localStorage.getItem('sd');
    return s?JSON.parse(s):DEFAULTS.slice();
  }catch(e){return DEFAULTS.slice();}
}
function sdSave(a){
  try{
    var j=JSON.stringify(a);
    if(typeof SpeedDial!=='undefined')SpeedDial.save(j);
    else localStorage.setItem('sd',j);
  }catch(e){}
}

/* ── Native callbacks ── */
window.addToSpeedDial=function(url,name){
  var items=sdLoad();
  for(var i=0;i<items.length;i++){if(items[i].url===url)return;}
  items.push({url:url,name:name});
  sdSave(items);render();
};
window.refreshSpeedDial=function(){render();};

/* ── Favicon ── */
function fav(url){
  try{var h=new URL(url).hostname;return'https://www.google.com/s2/favicons?domain='+h+'&sz=64';}
  catch(e){return'';}
}

/* ── Render ── */
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function render(){
  var items=sdLoad(),g=document.getElementById('grid');
  g.innerHTML='';
  items.forEach(function(it,i){
    var w=document.createElement('div');w.style.position='relative';
    var fi=fav(it.url),ini=it.name.charAt(0).toUpperCase();
    w.innerHTML='<a href="'+(editing?'javascript:void(0)':it.url)+'" class="sl" data-i="'+i+'">'
      +'<div class="card'+(editing?' editing':'')+'"><div class="del-btn" data-del="'+i+'">&#10005;</div>'
      +'<div class="icon"><img src="'+fi+'" width="32" height="32" '
        +'onerror="this.style.display=\'none\';this.nextSibling.style.display=\'flex\'">'
      +'<div class="fallback" style="background:#2a2a2a">'+ini+'</div></div>'
      +'<span class="label">'+esc(it.name)+'</span></div></a>';
    var pt,pl=w.querySelector('.sl');
    pl.addEventListener('touchstart',function(){pt=setTimeout(function(){editing=true;render();},600);},{passive:true});
    pl.addEventListener('touchend',function(){clearTimeout(pt);});
    pl.addEventListener('touchmove',function(){clearTimeout(pt);});
    var db=w.querySelector('.del-btn');
    db.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();
      var a=sdLoad();a.splice(parseInt(this.dataset.del),1);sdSave(a);render();});
    g.appendChild(w);
  });
  /* Add card */
  var aw=document.createElement('div');aw.style.position='relative';
  aw.innerHTML='<div class="card add-card"><div class="icon" style="background:transparent;font-size:26px;color:#444">+</div><span class="label">Add</span></div>';
  aw.addEventListener('click',function(){editing=false;render();openSheet();});
  g.appendChild(aw);
  /* Done bar */
  if(editing){
    var db=document.createElement('div');db.className='done-bar';db.textContent='&#10003;  Done';
    db.addEventListener('click',function(){editing=false;render();});
    g.appendChild(db);
  }
}

/* ── Sheet ── */
function openSheet(){
  document.getElementById('iUrl').value='';
  document.getElementById('iName').value='';
  document.getElementById('iName').dataset.af='0';
  var ov=document.getElementById('overlay');
  ov.classList.add('open');
  syncViewport();
  setTimeout(function(){document.getElementById('iUrl').focus();},80);
}
function closeSheet(){document.getElementById('overlay').classList.remove('open');}
function confirmAdd(){
  var url=document.getElementById('iUrl').value.trim();
  var name=document.getElementById('iName').value.trim();
  if(!url)return;
  if(!/^https?:\/\//i.test(url))url='https://'+url;
  if(!name){try{name=new URL(url).hostname.replace(/^www\./,'').split('.')[0];
    name=name.charAt(0).toUpperCase()+name.slice(1);}catch(e){name=url;}}
  var arr=sdLoad();arr.push({url:url,name:name});sdSave(arr);
  closeSheet();render();
}
document.getElementById('iUrl').addEventListener('input',function(){
  var nf=document.getElementById('iName');
  if(nf.dataset.af==='1'||!nf.value){
    try{var u=this.value;if(!/^https?:\/\//i.test(u))u='https://'+u;
      var h=new URL(u).hostname.replace(/^www\./,'').split('.')[0];
      nf.value=h.charAt(0).toUpperCase()+h.slice(1);nf.dataset.af='1';}catch(e){}
  }
});
document.getElementById('iName').addEventListener('input',function(){this.dataset.af='0';});
document.getElementById('iUrl').addEventListener('keydown',function(e){if(e.key==='Enter')document.getElementById('iName').focus();});
document.getElementById('iName').addEventListener('keydown',function(e){if(e.key==='Enter')confirmAdd();});

/* ── Keyboard / visualViewport fix ── */
function syncViewport(){
  if(!window.visualViewport)return;
  var vv=window.visualViewport;
  var ov=document.getElementById('overlay');
  ov.style.position='fixed';
  ov.style.left=vv.offsetLeft+'px';
  ov.style.top=vv.offsetTop+'px';
  ov.style.width=vv.width+'px';
  ov.style.height=vv.height+'px';
}
if(window.visualViewport){
  window.visualViewport.addEventListener('resize',syncViewport);
  window.visualViewport.addEventListener('scroll',syncViewport);
}

/* ── Clock ── */
function tick(){
  var n=new Date(),h=n.getHours().toString().padStart(2,'0'),m=n.getMinutes().toString().padStart(2,'0'),
      days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
      months=['January','February','March','April','May','June','July','August','September','October','November','December'];
  document.getElementById('clk').textContent=h+':'+m;
  document.getElementById('dt').textContent=days[n.getDay()]+', '+months[n.getMonth()]+' '+n.getDate();
}
tick();setInterval(tick,5000);
render();
</script>
</body>
</html>""".trimIndent()

    // ══════════════════════════════════════════════════════════════════
    // Lifecycle
    // ══════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Global cookies — must enable before creating WebViews
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
        }

        ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { view, insets ->
            val wasVisible = isImeVisible
            isImeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            when {
                !wasVisible && isImeVisible -> {
                    webView.removeCallbacks(resetWebInputFocusedRunnable)
                    webInputFocused = true
                }
                wasVisible && !isImeVisible -> {
                    webInputFocused = false
                    applyImmersiveMode()
                }
            }
            ViewCompat.onApplyWindowInsets(view, insets)
        }

        bindStaticViews()
        applyImmersiveMode()

        // Create first tab
        val firstTab = createTab()
        switchToTab(0, animate = false)
        loadHomePage(firstTab.webView)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()    // persist cookies on every pause
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && !isImeVisible && !webInputFocused) {
            window.decorView.postDelayed({
                if (!isImeVisible && !webInputFocused) applyImmersiveMode()
            }, 350)
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Tab management
    // ══════════════════════════════════════════════════════════════════

    private fun createTab(url: String? = null): BrowserTab {
        val wv = ScrollAwareWebView(this)
        configureWebViewInstance(wv)
        val tab = BrowserTab(tabIdCounter++, wv, url ?: "")
        tabs.add(tab)
        return tab
    }

    private fun switchToTab(index: Int, animate: Boolean = true) {
        if (tabs.isEmpty()) return
        val newIndex = index.coerceIn(0, tabs.lastIndex)

        // Remove old WebView from container
        if (activeTabIndex < tabs.size) {
            val old = tabs[activeTabIndex].webView
            if (old.parent != null) {
                if (animate) {
                    old.animate().alpha(0f).translationX(-60f * resources.displayMetrics.density)
                        .setDuration(160).setInterpolator(AccelerateInterpolator())
                        .withEndAction { webViewContainer.removeView(old) }
                        .start()
                } else {
                    webViewContainer.removeView(old)
                }
            }
        }

        activeTabIndex = newIndex
        val newWv = tabs[activeTabIndex].webView
        val lp = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        if (newWv.parent == null) webViewContainer.addView(newWv, 0, lp)

        if (animate) {
            newWv.alpha = 0f; newWv.translationX = 60f * resources.displayMetrics.density
            newWv.animate().alpha(1f).translationX(0f)
                .setDuration(180).setInterpolator(DecelerateInterpolator()).start()
        } else {
            newWv.alpha = 1f; newWv.translationX = 0f
        }

        // Sync insets for new WebView
        ViewCompat.setOnApplyWindowInsetsListener(newWv) { v, ins ->
            val imeBottom = ins.getInsets(WindowInsetsCompat.Type.ime()).bottom
            v.setPadding(0, 0, 0, imeBottom)
            ins
        }

        updateTabCount()
        // Rebuild gesture detector for active webview
        buildGestureDetector()
        syncNavButtons()
    }

    private fun closeTab(index: Int) {
        if (tabs.size == 1) {
            // Replace with new blank tab instead of leaving app empty
            tabs[0].webView.let { wv ->
                webViewContainer.removeView(wv)
                wv.destroy()
            }
            tabs.clear()
            activeTabIndex = 0
            val t = createTab(); switchToTab(0, false); loadHomePage(t.webView)
            return
        }
        val tab = tabs.removeAt(index)
        webViewContainer.removeView(tab.webView)
        tab.webView.destroy()
        val newIdx = if (activeTabIndex >= tabs.size) tabs.lastIndex else activeTabIndex
        activeTabIndex = newIdx  // already adjusted
        switchToTab(newIdx, false)
    }

    private fun openNewTab(url: String? = null) {
        val tab = createTab(url)
        switchToTab(tabs.lastIndex, animate = true)
        if (url != null) tab.webView.loadUrl(url)
        else loadHomePage(tab.webView)
    }

    private fun updateTabCount() {
        btnTabCount.text = tabs.size.toString()
    }

    private fun showTabSwitcher() {
        val dp = resources.displayMetrics.density
        val scroller = ScrollView(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, (4 * dp).toInt(), 0, (8 * dp).toInt())
        }

        // "New Tab" row
        container.addView(TextView(this).apply {
            text = "+ New Tab"
            setTextColor(Color.parseColor("#4FC3F7"))
            textSize = 15f
            setPadding((20 * dp).toInt(), (14 * dp).toInt(), (20 * dp).toInt(), (14 * dp).toInt())
        }.also { tv ->
            tv.setOnClickListener { openNewTab(); dismissTabDialog() }
        })

        tabs.forEachIndexed { i, tab ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding((20 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt())
                if (i == activeTabIndex) setBackgroundColor(Color.parseColor("#1A4FC3F7"))
                isClickable = true; isFocusable = true
            }
            val textBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            textBox.addView(TextView(this).apply {
                text = tab.title.ifBlank { "New Tab" }
                setTextColor(if (i == activeTabIndex) Color.parseColor("#4FC3F7") else Color.WHITE)
                textSize = 13f; maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            textBox.addView(TextView(this).apply {
                text = tab.url.ifBlank { "Home" }
                setTextColor(Color.parseColor("#55FFFFFF"))
                textSize = 10f; maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, (2 * dp).toInt(), 0, 0)
            })
            val closeBtn = TextView(this).apply {
                text = "✕"; textSize = 15f
                setTextColor(Color.parseColor("#55FFFFFF"))
                setPadding((16 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt(), (8 * dp).toInt())
            }
            row.addView(textBox); row.addView(closeBtn)
            val capturedI = i
            row.setOnClickListener { switchToTab(capturedI); dismissTabDialog() }
            closeBtn.setOnClickListener { closeTab(capturedI); dismissTabDialog() }
            container.addView(row)
            // divider
            container.addView(View(this).apply {
                setBackgroundColor(Color.parseColor("#22FFFFFF"))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 1)
            })
        }
        scroller.addView(container)
        tabDialog = AlertDialog.Builder(this)
            .setTitle("Tabs  (${tabs.size})")
            .setView(scroller)
            .setNegativeButton("Close", null)
            .show().also { it.styleDialog() }
    }

    private var tabDialog: AlertDialog? = null
    private fun dismissTabDialog() { tabDialog?.dismiss(); tabDialog = null }

    // ══════════════════════════════════════════════════════════════════
    // Immersive mode
    // ══════════════════════════════════════════════════════════════════

    private fun applyImmersiveMode() {
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ══════════════════════════════════════════════════════════════════
    // Keyboard
    // ══════════════════════════════════════════════════════════════════

    private fun showKeyboardForWebView() {
        val wv = webView
        webInputFocused = true
        wv.removeCallbacks(resetWebInputFocusedRunnable)
        if (!wv.hasFocus()) wv.requestFocusFromTouch()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val shown = imm.showSoftInput(wv, InputMethodManager.SHOW_IMPLICIT)
        if (!shown) wv.postDelayed({
            val s2 = imm.showSoftInput(wv, InputMethodManager.SHOW_FORCED)
            if (!s2) WindowInsetsControllerCompat(window, wv).show(WindowInsetsCompat.Type.ime())
        }, 150)
    }

    // ══════════════════════════════════════════════════════════════════
    // Static view binding
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    private fun bindStaticViews() {
        webViewContainer  = findViewById(R.id.webViewContainer)
        urlBar            = findViewById(R.id.urlBar)
        urlInput          = findViewById(R.id.urlInput)
        btnBack           = findViewById(R.id.btnBack)
        btnForward        = findViewById(R.id.btnForward)
        btnRefresh        = findViewById(R.id.btnRefresh)
        btnSettings       = findViewById(R.id.btnSettings)
        btnAddSpeedDial   = findViewById(R.id.btnAddSpeedDial)
        btnTabCount       = findViewById(R.id.btnTabCount)
        btnToggle         = findViewById(R.id.btnToggleUrlBar)
        pageProgress      = findViewById(R.id.pageProgress)
        tapZoneIndicator  = findViewById(R.id.tapZoneIndicator)
        tapZoneIndicator.visibility = View.GONE

        // Debug overlay
        debugOverlayView = TextView(this).apply {
            textSize = 9f; setTextColor(0xFFFFFF00.toInt())
            setBackgroundColor(0xCC000000.toInt()); setPadding(8,8,8,8); elevation = 50f
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.BOTTOM)
            visibility = View.GONE
        }
        (findViewById<FrameLayout>(android.R.id.content)).addView(debugOverlayView)

        urlBar.post { urlBar.translationY = -urlBar.height.toFloat() }

        btnToggle.setOnClickListener         { toggleUrlBar() }
        btnBack.setOnClickListener           { if (webView.canGoBack())    webView.goBack() }
        btnForward.setOnClickListener        { if (webView.canGoForward()) webView.goForward() }
        btnRefresh.setOnClickListener        { if (isOnHomePage) loadHomePage(webView) else webView.reload() }
        btnSettings.setOnClickListener       { showSettingsDialog() }
        btnTabCount.setOnClickListener       { showTabSwitcher() }

        // Add current page to speed dial
        btnAddSpeedDial.setOnClickListener {
            if (isOnHomePage) { Toast.makeText(this, "Already on home", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val url   = webView.url ?: return@setOnClickListener
            val raw   = webView.title?.trim() ?: ""
            val name  = (if (raw.isBlank()) try { java.net.URI(url).host?.removePrefix("www.") } catch(_:Exception){null} else raw)
                ?.take(24) ?: url
            addToSpeedDial(url, name)
        }

        // URL input actions
        urlInput.setOnEditorActionListener { _, actionId, event ->
            val isAction = actionId in listOf(EditorInfo.IME_ACTION_GO, EditorInfo.IME_ACTION_SEARCH,
                EditorInfo.IME_ACTION_DONE, EditorInfo.IME_ACTION_UNSPECIFIED)
            val isEnter  = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (isAction || isEnter) { navigateTo(urlInput.text.toString()); true } else false
        }
        urlInput.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN) {
                navigateTo(urlInput.text.toString()); true
            } else false
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Gesture detector (rebuilt on tab switch so it targets active WV)
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    private fun buildGestureDetector() {
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (urlBarVisible) { hideUrlBar(); return true }
                return false
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (fabBehavior == 1 && toggleVisible && !urlBarVisible) { hideToggleFab(); return true }
                if (fabBehavior == 3 && !urlBarVisible && isTapInZone(e.x, e.y)) { showUrlBar(); return true }
                return false
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vX: Float, vY: Float): Boolean {
                if (!swipeNavEnabled || urlBarVisible) return false
                val startX = e1?.x ?: return false

                // Must be a clearly horizontal fling
                val aX = if (vX > 0) vX else -vX
                val aY = if (vY > 0) vY else -vY
                if (aX < 500f || aX < aY * 1.2f) return false

                val edgePx = 64 * resources.displayMetrics.density   // 64 dp edge zone
                val goBack = vX > 0   // swipe right = go back

                // Enforce edge-start zones
                if (goBack  && startX > edgePx) return false                      // must start from left edge
                if (!goBack && startX < webView.width - edgePx) return false      // must start from right edge

                if (goBack  && !webView.canGoBack())    return false
                if (!goBack && !webView.canGoForward()) return false
                animateNavigation(goBack)
                return true
            }
        })
        gestureDetector = gd

        webView.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    webInputFocused = true
                    webView.removeCallbacks(resetWebInputFocusedRunnable)
                    webView.postDelayed(resetWebInputFocusedRunnable, 600)
                }
            }
            gd.onTouchEvent(event)
            false
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Swipe navigation animation
    // ══════════════════════════════════════════════════════════════════

    private fun animateNavigation(goBack: Boolean) {
        val wv = webView
        val dx = wv.width * 0.22f * (if (goBack) 1f else -1f)
        wv.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        wv.animate()
            .translationX(dx).alpha(0.75f)
            .setDuration(110).setInterpolator(AccelerateInterpolator())
            .withEndAction {
                if (goBack) wv.goBack() else wv.goForward()
                wv.translationX = -dx * 0.5f
                wv.animate()
                    .translationX(0f).alpha(1f)
                    .setDuration(160).setInterpolator(DecelerateInterpolator())
                    .withEndAction { wv.setLayerType(View.LAYER_TYPE_NONE, null) }
                    .start()
            }.start()
    }

    // ══════════════════════════════════════════════════════════════════
    // WebView per-instance configuration
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebViewInstance(wv: ScrollAwareWebView) {
        wv.isFocusable = true
        wv.isFocusableInTouchMode = true
        wv.setLayerType(View.LAYER_TYPE_HARDWARE, null)   // smooth rendering

        wv.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
            userAgentString = MOBILE_UA; loadWithOverviewMode = true; useWideViewPort = true
            allowFileAccess = false
            @Suppress("DEPRECATION")
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
        }

        // Cookies per-webview
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)

        // JS bridges
        wv.addJavascriptInterface(WebKeyboardBridge(wv), "Android")
        wv.addJavascriptInterface(SpeedDialBridge(), "SpeedDial")

        wv.onWebInputFocused = { showKeyboardForWebView() }
        wv.onDebugEvent = { msg -> dbg(msg) }

        // Scroll callback — throttled
        wv.onScrollCallback = { dy ->
            val now = System.currentTimeMillis()
            if (now - lastScrollMs > 40) {
                lastScrollMs = now
                if (!urlBarVisible && fabBehavior == 0) {
                    if (dy > 8) hideToggleFab() else if (dy < -8) showToggleFab(true)
                }
            }
        }

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, url: String?, fav: android.graphics.Bitmap?) {
                pageProgress.visibility = View.VISIBLE; pageProgress.progress = 0
                val tab = tabs.find { it.webView === v }
                if (url == null || url.startsWith("data:")) {
                    isOnHomePage = true; urlInput.setText("Home")
                    tab?.url = ""; tab?.title = "Home"
                } else {
                    isOnHomePage = false
                    currentHost = try { java.net.URI(url).host?.removePrefix("www.") } catch(_:Exception){null}
                    urlInput.setText(url)
                    tab?.url = url
                }
                syncNavButtons()
            }

            override fun onPageFinished(v: WebView, url: String?) {
                pageProgress.visibility = View.GONE
                val tab = tabs.find { it.webView === v }
                tab?.title = v.title ?: ""
                tab?.url   = url ?: ""

                // Inject keyboard listener into every page
                v.evaluateJavascript("""
                (function(){if(window.__kbl)return;window.__kbl=true;
                  function isEd(el){if(!el||!el.tagName)return false;var t=el.tagName.toUpperCase();
                    if(t==='INPUT'){var ty=(el.getAttribute('type')||'text').toLowerCase();
                      return['checkbox','radio','submit','button','file','image','reset','hidden','range','color'].indexOf(ty)<0;}
                    if(t==='TEXTAREA')return true;
                    var r=(el.getAttribute('role')||'').toLowerCase();
                    if(r==='textbox'||r==='searchbox'||r==='combobox')return true;
                    var c=el.getAttribute('contenteditable');
                    return c!==null&&c!=='false'||el.isContentEditable;}
                  function chk(e){var el=e.target;for(var i=0;i<5&&el;i++,el=el.parentElement){
                    if(isEd(el)){if(typeof Android!=='undefined')Android.onInputFocused();return;}}}
                  document.addEventListener('focusin',chk,true);})();
                """.trimIndent(), null)

                if (url == null || url.startsWith("data:")) {
                    isOnHomePage = true; urlInput.setText("Home")
                } else {
                    isOnHomePage = false; urlInput.setText(url)
                }
                syncNavButtons()
            }

            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = false

            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): android.webkit.WebResourceResponse? {
                if (adBlockEnabled && AdBlocker.shouldBlock(r, currentHost)) return AdBlocker.emptyResponse()
                if (dataSaverLevel > 0 && AdBlocker.shouldBlockForDataSaver(r, currentHost, dataSaverLevel)) return AdBlocker.emptyResponse()
                return null
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (p < 100) { pageProgress.visibility = View.VISIBLE; pageProgress.progress = p }
                else pageProgress.postDelayed({ pageProgress.visibility = View.GONE }, 200)
            }
            override fun onReceivedTitle(v: WebView, t: String?) {
                tabs.find { it.webView === v }?.title = t ?: ""
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // JS Bridges
    // ══════════════════════════════════════════════════════════════════

    inner class WebKeyboardBridge(private val wv: ScrollAwareWebView) {
        @JavascriptInterface
        fun onInputFocused() = runOnUiThread {
            webInputFocused = true
            wv.removeCallbacks(resetWebInputFocusedRunnable)
            wv.postDelayed({ showKeyboardForWebView() }, 200)
        }
    }

    inner class SpeedDialBridge {
        @JavascriptInterface
        fun get(): String = prefs.getString("speed_dial", null) ?: DEFAULT_SPEED_DIAL

        @JavascriptInterface
        fun save(json: String) = prefs.edit().putString("speed_dial", json).apply()
    }

    // ══════════════════════════════════════════════════════════════════
    // Speed dial
    // ══════════════════════════════════════════════════════════════════

    private fun addToSpeedDial(url: String, name: String) {
        val arr = try { JSONArray(prefs.getString("speed_dial", null) ?: DEFAULT_SPEED_DIAL) }
                  catch (_: Exception) { JSONArray() }
        // Dedup
        for (i in 0 until arr.length()) {
            if ((arr.getJSONObject(i).optString("url")) == url) {
                Toast.makeText(this, "Already in Speed Dial", Toast.LENGTH_SHORT).show(); return
            }
        }
        arr.put(JSONObject().put("url", url).put("name", name))
        prefs.edit().putString("speed_dial", arr.toString()).apply()
        Toast.makeText(this, "Added: $name", Toast.LENGTH_SHORT).show()
        // Refresh any home page tabs
        tabs.forEach { tab ->
            val u = tab.webView.url ?: ""
            if (u.startsWith("data:") || u.startsWith("https://home.local"))
                tab.webView.evaluateJavascript("if(typeof refreshSpeedDial==='function')refreshSpeedDial()", null)
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Offline save (MHTML)
    // ══════════════════════════════════════════════════════════════════

    private fun savePageOffline() {
        val dir = File(filesDir, "offline").also { it.mkdirs() }
        val safeTitle = (webView.title ?: "page")
            .replace(Regex("[^a-zA-Z0-9 _-]"), "").trim().take(30).ifBlank { "page" }
        val file = File(dir, "${System.currentTimeMillis()}_$safeTitle.mht")
        @Suppress("DEPRECATION")
        webView.saveWebArchive(file.absolutePath, false) { path ->
            runOnUiThread {
                if (path != null) Toast.makeText(this, "Saved offline: $safeTitle", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this, "Save failed (try a simpler page)", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showSavedPages() {
        val dir = File(filesDir, "offline")
        val files = dir.listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (files.isEmpty()) {
            Toast.makeText(this, "No saved pages yet", Toast.LENGTH_SHORT).show(); return
        }
        val names = files.map { it.name.substringAfter("_").removeSuffix(".mht") }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Saved Pages")
            .setItems(names) { _, i ->
                val f = files[i]
                webView.loadUrl("file://${f.absolutePath}")
                hideUrlBar()
            }
            .setNegativeButton("Close", null)
            .show().styleDialog()
    }

    // ══════════════════════════════════════════════════════════════════
    // Home page
    // ══════════════════════════════════════════════════════════════════

    private fun loadHomePage(wv: ScrollAwareWebView = webView) {
        isOnHomePage = true
        urlInput.setText("Home")
        wv.loadDataWithBaseURL("https://home.local/", buildHomeHtml(), "text/html", "UTF-8", null)
    }

    private fun applyDataSaverSettings() {
        webView.settings.apply {
            cacheMode = if (dataSaverLevel >= 3) WebSettings.LOAD_CACHE_ELSE_NETWORK else WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = dataSaverLevel < 4
        }
    }

    private fun syncNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1f else 0.32f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.32f
    }

    // ══════════════════════════════════════════════════════════════════
    // URL bar
    // ══════════════════════════════════════════════════════════════════

    private fun toggleUrlBar() { if (urlBarVisible) hideUrlBar() else showUrlBar() }

    private fun showUrlBar() {
        if (urlBarVisible) return
        urlBarVisible = true
        if (fabBehavior != 3) showToggleFab(false)
        urlBar.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        urlBar.visibility = View.VISIBLE
        urlBar.animate().translationY(0f).setDuration(240)
            .setInterpolator(DecelerateInterpolator())
            .withEndAction { urlBar.setLayerType(View.LAYER_TYPE_NONE, null) }
            .start()
        if (isOnHomePage) urlInput.setText("")
        urlInput.post {
            urlInput.isFocusable = true; urlInput.isFocusableInTouchMode = true
            urlInput.requestFocus(); urlInput.selectAll()
        }
    }

    private fun hideUrlBar() {
        if (!urlBarVisible) return
        urlBarVisible = false
        dismissKeyboard()
        urlInput.clearFocus()
        urlInput.isFocusable = false; urlInput.isFocusableInTouchMode = false
        webView.requestFocus()
        if (isOnHomePage) urlInput.setText("Home")
        urlBar.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        urlBar.animate()
            .translationY(-urlBar.height.toFloat())
            .setDuration(200).setInterpolator(AccelerateInterpolator())
            .withEndAction {
                urlBar.visibility = View.INVISIBLE
                urlBar.setLayerType(View.LAYER_TYPE_NONE, null)
            }.start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Globe FAB
    // ══════════════════════════════════════════════════════════════════

    private fun showToggleFab(animate: Boolean) {
        if (toggleVisible || fabBehavior == 3) return
        toggleVisible = true
        if (animate) btnToggle.animate().alpha(1f).translationY(0f).setDuration(200).start()
        else { btnToggle.alpha = 1f; btnToggle.translationY = 0f }
    }

    private fun hideToggleFab() {
        if (!toggleVisible || fabBehavior == 2) return
        toggleVisible = false
        btnToggle.animate().alpha(0f)
            .translationY(24f * resources.displayMetrics.density)
            .setDuration(180).start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Tap zone
    // ══════════════════════════════════════════════════════════════════

    private fun isTapInZone(x: Float, y: Float): Boolean {
        val w = webView.width.toFloat(); val h = webView.height.toFloat()
        return when (tapZone) {
            0 -> y < h * 0.13f
            1 -> y > h * 0.78f && x < w * 0.40f
            2 -> y > h * 0.78f && x > w * 0.28f && x < w * 0.72f
            3 -> y > h * 0.78f && x > w * 0.60f
            else -> false
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Navigation
    // ══════════════════════════════════════════════════════════════════

    private fun navigateTo(raw: String) {
        val s = raw.trim()
        if (s.isEmpty() || s == "Home") return
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(".") && !s.contains(" ")                 -> "https://$s"
            else -> "https://www.google.com/search?q=${android.net.Uri.encode(s)}"
        }
        webView.loadUrl(url)
        hideUrlBar()
    }

    private fun dismissKeyboard() {
        WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.ime())
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            urlBarVisible       -> hideUrlBar()
            webView.canGoBack() -> webView.goBack()
            !isOnHomePage       -> loadHomePage()
            else                -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Settings dialog
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private fun showSettingsDialog() {
        val dp = resources.displayMetrics.density
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (12*dp).toInt(), (20*dp).toInt(), (8*dp).toInt())
        }
        fun div() = View(this).apply {
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        }
        fun addToggle(label: String, desc: String, checked: Boolean, fn: (Boolean)->Unit) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0,(10*dp).toInt(),0,(10*dp).toInt()) }
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f) }
            box.addView(TextView(this).apply { text=label;textSize=15f;setTextColor(Color.WHITE) })
            box.addView(TextView(this).apply { text=desc;textSize=12f;setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding(0,(2*dp).toInt(),0,0) })
            val sw = Switch(this).apply { isChecked=checked; setOnCheckedChangeListener{_,on->fn(on)} }
            row.addView(box); row.addView(sw); container.addView(row); container.addView(div())
        }
        fun addChevron(label: String, value: ()->String, click: (TextView)->Unit) {
            val rv = TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground,rv,true)
            val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL
                gravity=android.view.Gravity.CENTER_VERTICAL
                setPadding(0,(10*dp).toInt(),0,(10*dp).toInt())
                isClickable=true;isFocusable=true
                if(rv.resourceId!=0)setBackgroundResource(rv.resourceId) }
            val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL
                layoutParams=LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f);isClickable=false }
            box.addView(TextView(this).apply { text=label;textSize=15f;setTextColor(Color.WHITE) })
            val vl = TextView(this).apply { text=value();textSize=12f;setTextColor(Color.parseColor("#4FC3F7"))
                setPadding(0,(2*dp).toInt(),0,0) }
            box.addView(vl); row.addView(box)
            row.addView(TextView(this).apply { text="›";textSize=22f;setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding((8*dp).toInt(),0,0,0) })
            row.setOnClickListener { click(vl) }; container.addView(row); container.addView(div())
        }
        fun addAction(label: String, desc: String, fn: ()->Unit) {
            val rv = TypedValue(); theme.resolveAttribute(android.R.attr.selectableItemBackground,rv,true)
            val row = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL
                setPadding(0,(10*dp).toInt(),0,(10*dp).toInt())
                isClickable=true;isFocusable=true
                if(rv.resourceId!=0)setBackgroundResource(rv.resourceId) }
            row.addView(TextView(this).apply { text=label;textSize=15f;setTextColor(Color.parseColor("#4FC3F7")) })
            row.addView(TextView(this).apply { text=desc;textSize=12f;setTextColor(Color.parseColor("#66FFFFFF"))
                setPadding(0,(2*dp).toInt(),0,0) })
            row.setOnClickListener { fn() }; container.addView(row); container.addView(div())
        }

        addToggle("Ad Blocker","Block ads and trackers",adBlockEnabled) { on->adBlockEnabled=on;if(!isOnHomePage)webView.reload() }

        val dsShort = arrayOf("Off","High","Medium","Low","No Images")
        addChevron("Data Saver",{dsShort[dataSaverLevel]}) { vl->
            val ci=intArrayOf(dataSaverLevel)
            AlertDialog.Builder(this).setTitle("Data Saver")
                .setSingleChoiceItems(DATA_SAVER_LABELS,dataSaverLevel){_,w->ci[0]=w}
                .setPositiveButton("Apply"){_,_->dataSaverLevel=ci[0];vl.text=dsShort[dataSaverLevel]
                    applyDataSaverSettings();if(!isOnHomePage)webView.reload()}
                .setNegativeButton("Cancel",null).show().styleDialog()
        }

        addChevron("URL Bar Access",{FAB_BEHAVIOR_LABELS[fabBehavior]}) { vl->
            val ci=intArrayOf(fabBehavior)
            AlertDialog.Builder(this).setTitle("URL Bar Access")
                .setSingleChoiceItems(FAB_BEHAVIOR_LABELS,fabBehavior){_,w->ci[0]=w}
                .setPositiveButton("Apply"){_,_->fabBehavior=ci[0];vl.text=FAB_BEHAVIOR_LABELS[fabBehavior]
                    when(fabBehavior){2->showToggleFab(true);3->hideToggleFab()}}
                .setNegativeButton("Cancel",null).show().styleDialog()
        }

        if (fabBehavior == 3) {
            addChevron("  Tap Zone",{TAP_ZONE_SHORT[tapZone]}) { vl->
                val ci=intArrayOf(tapZone)
                AlertDialog.Builder(this).setTitle("Tap Zone")
                    .setSingleChoiceItems(TAP_ZONE_LABELS,tapZone){_,w->ci[0]=w}
                    .setPositiveButton("Apply"){_,_->tapZone=ci[0];vl.text=TAP_ZONE_SHORT[tapZone]}
                    .setNegativeButton("Cancel",null).show().styleDialog()
            }
        }

        addToggle("Swipe to Navigate","Swipe right=back  •  swipe left=forward",swipeNavEnabled) { on->swipeNavEnabled=on }

        if (!isOnHomePage) {
            addAction("Save Page Offline","Save as MHTML to open without internet") { savePageOffline() }
        }
        addAction("Saved Pages","Open previously saved offline pages") { showSavedPages() }

        addToggle("Debug Overlay","Live event log (long-press to copy)",debugOverlayVisible) { on->
            debugOverlayVisible=on; debugOverlayView.visibility=if(on)View.VISIBLE else View.GONE }

        val sv = ScrollView(this).also { it.addView(container) }
        AlertDialog.Builder(this).setTitle("Settings").setView(sv)
            .setPositiveButton("Done",null).show().styleDialog()
    }

    // ══════════════════════════════════════════════════════════════════
    // Debug
    // ══════════════════════════════════════════════════════════════════

    private val debugLog = ArrayDeque<String>()
    private fun dbg(msg: String) {
        android.util.Log.d("BrowserApp", msg)
        if (!debugOverlayVisible) return
        val ts = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US).format(java.util.Date())
        runOnUiThread {
            debugLog.addFirst("$ts  $msg"); if (debugLog.size > 8) debugLog.removeLast()
            debugOverlayView.text = debugLog.joinToString("\n")
        }
    }

    private fun AlertDialog.styleDialog(): AlertDialog {
        window?.setBackgroundDrawableResource(android.R.color.background_dark)
        getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.parseColor("#4FC3F7"))
        getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.parseColor("#99FFFFFF"))
        return this
    }
}
