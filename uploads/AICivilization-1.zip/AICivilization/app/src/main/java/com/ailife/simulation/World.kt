package com.ailife.simulation

import kotlin.math.abs
import kotlin.random.Random

enum class TerrainType(
    val moveCost: Float,    // 0 = impassable
    val foodPotential: Float
) {
    DEEP_WATER   (0.00f, 0.05f),
    SHALLOW_WATER(0.18f, 0.30f),
    BEACH        (0.75f, 0.15f),
    PLAINS       (1.00f, 0.80f),
    GRASSLAND    (0.90f, 0.70f),
    FOREST       (0.55f, 0.55f),
    MOUNTAIN     (0.28f, 0.08f),
    SNOW         (0.38f, 0.04f),
    DESERT       (0.48f, 0.08f),
    SWAMP        (0.38f, 0.38f)
}

data class ResourceTile(
    var food: Int  = 0,
    var wood: Int  = 0,
    var stone: Int = 0,
    var iron: Int  = 0,
    var water: Int = 0
)

data class WorldStats(
    val year: Int,
    val population: Int,
    val civilizations: Int,
    val avgAge: Float,
    val avgIntelligence: Float,
    val avgAggression: Float,
    val totalBorn: Int,
    val totalDied: Int,
    val knowledgeTypeCount: Int,
    val advancedEra: String
)

class World(
    val width:  Int = 100,
    val height: Int = 100
) {
    // ── Terrain & resources ───────────────────────────────────────────────
    val terrain:     Array<Array<TerrainType>>  = Array(width) { Array(height) { TerrainType.PLAINS } }
    val moisture:    Array<FloatArray>          = Array(width) { FloatArray(height) }
    val temperature: Array<FloatArray>          = Array(width) { FloatArray(height) }
    val resources:   Array<Array<ResourceTile>> = Array(width) { Array(height) { ResourceTile() } }

    // ── Entities & civilizations ─────────────────────────────────────────
    val entities:      java.util.concurrent.CopyOnWriteArrayList<Entity>      = java.util.concurrent.CopyOnWriteArrayList()
    val civilizations: java.util.concurrent.CopyOnWriteArrayList<Civilization> = java.util.concurrent.CopyOnWriteArrayList()

    // ── World time ────────────────────────────────────────────────────────
    var tick: Long = 0L
    val year:  Int get() = (tick / 52).toInt()

    // ── Systems ───────────────────────────────────────────────────────────
    val history: HistoryLog    = HistoryLog()
    val weather: WeatherSystem = WeatherSystem(this)
    val disease: DiseaseSystem = DiseaseSystem(this)
    val economy: EconomySystem = EconomySystem()

    // ── Fast counters (maintained to avoid linear scans) ─────────────────
    var populationCount: Int = 0
    var totalBorn:       Int = 0
    var totalDied:       Int = 0

    // ── ID sequences ─────────────────────────────────────────────────────
    private var nextEntityId: Int = 0
    private var nextCivId:    Int = 0

    // ── Spatial grid ─────────────────────────────────────────────────────
    private val cellSize = 10
    private val gridW    = (width  + cellSize - 1) / cellSize
    private val gridH    = (height + cellSize - 1) / cellSize
    private val spatialGrid: Array<Array<MutableList<Entity>>> =
        Array(gridW) { Array(gridH) { mutableListOf<Entity>() } }

    // ─────────────────────────────────────────────────────────────────────
    // Spatial grid
    // ─────────────────────────────────────────────────────────────────────

    fun rebuildSpatialGrid() {
        for (col in spatialGrid) for (cell in col) cell.clear()
        for (e in entities) {
            if (!e.isAlive) continue
            val gx = (e.x / cellSize).toInt().coerceIn(0, gridW - 1)
            val gy = (e.y / cellSize).toInt().coerceIn(0, gridH - 1)
            spatialGrid[gx][gy].add(e)
        }
    }

    fun getNearby(x: Float, y: Float, radius: Float): List<Entity> {
        val gx    = (x / cellSize).toInt().coerceIn(0, gridW - 1)
        val gy    = (y / cellSize).toInt().coerceIn(0, gridH - 1)
        val cells = (radius / cellSize).toInt() + 1
        val r2    = radius * radius
        val result = mutableListOf<Entity>()
        for (cx in (gx - cells).coerceAtLeast(0)..(gx + cells).coerceAtMost(gridW - 1)) {
            for (cy in (gy - cells).coerceAtLeast(0)..(gy + cells).coerceAtMost(gridH - 1)) {
                for (e in spatialGrid[cx][cy]) {
                    val dx = e.x - x; val dy = e.y - y
                    if (dx * dx + dy * dy <= r2) result.add(e)
                }
            }
        }
        return result
    }

    // ─────────────────────────────────────────────────────────────────────
    // Terrain queries
    // ─────────────────────────────────────────────────────────────────────

    fun isWater(x: Int, y: Int): Boolean {
        if (x < 0 || y < 0 || x >= width || y >= height) return true
        val t = terrain[x][y]
        return t == TerrainType.DEEP_WATER || t == TerrainType.SHALLOW_WATER
    }

    fun moveCost(x: Float, y: Float): Float {
        val tx = x.toInt().coerceIn(0, width  - 1)
        val ty = y.toInt().coerceIn(0, height - 1)
        return terrain[tx][ty].moveCost.coerceAtLeast(0.01f)
    }

    // ─────────────────────────────────────────────────────────────────────
    // Resource searches  (spiral scan, cheap)
    // ─────────────────────────────────────────────────────────────────────

    fun nearestWater(x: Float, y: Float, maxR: Int): Pair<Int, Int>? = spiralSearch(x, y, maxR) { tx, ty ->
        terrain[tx][ty] == TerrainType.SHALLOW_WATER || resources[tx][ty].water > 0
    }

    fun nearestFood(x: Float, y: Float, maxR: Int): Pair<Int, Int>? = spiralSearch(x, y, maxR) { tx, ty ->
        resources[tx][ty].food > 0
    }

    fun nearestResource(x: Float, y: Float, maxR: Int): Pair<Int, Int>? = spiralSearch(x, y, maxR) { tx, ty ->
        val r = resources[tx][ty]; r.food > 0 || r.wood > 0 || r.stone > 0
    }

    private inline fun spiralSearch(x: Float, y: Float, maxR: Int, predicate: (Int, Int) -> Boolean): Pair<Int, Int>? {
        val sx = x.toInt(); val sy = y.toInt()
        for (r in 1..maxR) {
            for (dx in -r..r) {
                for (sign in intArrayOf(-1, 1)) {
                    val dy = sign * r
                    val tx = (sx + dx).coerceIn(0, width  - 1)
                    val ty = (sy + dy).coerceIn(0, height - 1)
                    if (!isWater(tx, ty) && predicate(tx, ty)) return tx to ty
                }
            }
            for (dy in -r + 1 until r) {
                for (sign in intArrayOf(-1, 1)) {
                    val dx = sign * r
                    val tx = (sx + dx).coerceIn(0, width  - 1)
                    val ty = (sy + dy).coerceIn(0, height - 1)
                    if (!isWater(tx, ty) && predicate(tx, ty)) return tx to ty
                }
            }
        }
        return null
    }

    // ─────────────────────────────────────────────────────────────────────
    // Entity factory
    // ─────────────────────────────────────────────────────────────────────

    fun spawnEntity(
        x: Float, y: Float,
        gender: Gender = if (Random.nextBoolean()) Gender.MALE else Gender.FEMALE,
        dna: DNA = DNA.random(),
        civId: Int = -1
    ): Entity {
        val e = Entity(nextEntityId++, x, y, gender, dna, tick, civId)
        entities.add(e)
        populationCount++
        totalBorn++
        return e
    }

    // ─────────────────────────────────────────────────────────────────────
    // Civilization factory
    // ─────────────────────────────────────────────────────────────────────

    fun spawnCivilization(name: String, color: Int, x: Float, y: Float): Civilization {
        val civ = Civilization(nextCivId++, tick, name, color, x, y)
        civilizations.add(civ)
        return civ
    }

    fun civById(id: Int): Civilization? = civilizations.firstOrNull { it.id == id }

    fun entitiesForCiv(civId: Int): List<Entity> =
        entities.filter { it.isAlive && it.civId == civId }

    // ─────────────────────────────────────────────────────────────────────
    // Resource interaction
    // ─────────────────────────────────────────────────────────────────────

    fun harvest(tx: Int, ty: Int, e: Entity) {
        if (tx < 0 || ty < 0 || tx >= width || ty >= height) return
        val r = resources[tx][ty]
        if (r.food  > 0 && e.food  < 8) { val a = minOf(r.food,  2); r.food  -= a; e.food  += a; e.hunger = (e.hunger - 0.28f).coerceAtLeast(0f) }
        if (r.water > 0 && e.water < 8) { val a = minOf(r.water, 2); r.water -= a; e.water += a; e.thirst = (e.thirst - 0.28f).coerceAtLeast(0f) }
        if (r.wood  > 0 && e.wood  < 5) { r.wood--;  e.wood++  }
        if (r.stone > 0 && e.stone < 5) { r.stone--; e.stone++ }
        if (r.iron  > 0 && e.iron  < 5) { r.iron--;  e.iron++  }
    }

    fun regenerateResources() {
        for (x in 0 until width) {
            for (y in 0 until height) {
                val t = terrain[x][y]; val r = resources[x][y]
                if (r.food < 6 && Random.nextFloat() < t.foodPotential * 0.12f) r.food++
                if (t == TerrainType.FOREST && r.wood < 9 && Random.nextFloat() < 0.06f) r.wood++
                if (adjacentToWater(x, y) && r.water < 6 && Random.nextFloat() < 0.35f) r.water = 6
            }
        }
    }

    private fun adjacentToWater(x: Int, y: Int): Boolean {
        for (dx in -1..1) for (dy in -1..1) {
            if (dx == 0 && dy == 0) continue
            val nx = x + dx; val ny = y + dy
            if (nx in 0 until width && ny in 0 until height && isWater(nx, ny)) return true
        }
        return false
    }

    // ─────────────────────────────────────────────────────────────────────
    // Statistics snapshot (called rarely)
    // ─────────────────────────────────────────────────────────────────────

    fun statistics(): WorldStats {
        val alive = entities.filter { it.isAlive }
        val avgAge   = if (alive.isEmpty()) 0f else alive.sumOf { it.age.toDouble() }.toFloat() / alive.size
        val avgIntel = if (alive.isEmpty()) 0f else alive.sumOf { it.dna.intelligence.toDouble() }.toFloat() / alive.size
        val avgAggr  = if (alive.isEmpty()) 0f else alive.sumOf { it.dna.aggression.toDouble() }.toFloat() / alive.size
        val kCount   = alive.flatMap { it.knowledge }.toSet().size
        val activeCivs = civilizations.filter { !it.isExtinct }
        val bestEra  = activeCivs.maxByOrNull { it.knowledge.size }?.getEraName() ?: "None"
        return WorldStats(
            year                = year,
            population          = populationCount,
            civilizations       = activeCivs.size,
            avgAge              = avgAge,
            avgIntelligence     = avgIntel,
            avgAggression       = avgAggr,
            totalBorn           = totalBorn,
            totalDied           = totalDied,
            knowledgeTypeCount  = kCount,
            advancedEra         = bestEra
        )
    }
}
