package com.ailife

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ailife.simulation.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SimViewModel : ViewModel() {

    private val engine = WorldEngine()

    val simState: StateFlow<SimState?> = engine.state

    private val _selected = MutableStateFlow<Entity?>(null)
    val selected: StateFlow<Entity?> = _selected.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.Default) {
            engine.initialize()
            engine.setSpeed(SimSpeed.NORMAL)
        }
    }

    fun setSpeed(s: SimSpeed) {
        viewModelScope.launch(Dispatchers.Default) { engine.setSpeed(s) }
    }

    fun selectAt(worldX: Float, worldY: Float) {
        viewModelScope.launch(Dispatchers.Default) {
            _selected.value = engine.selectAt(worldX, worldY)
        }
    }

    fun clearSelection() { _selected.value = null }

    fun getWorld() = engine.getWorld()

    override fun onCleared() {
        engine.destroy()
        super.onCleared()
    }
}
