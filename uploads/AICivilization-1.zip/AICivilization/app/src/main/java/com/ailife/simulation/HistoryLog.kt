package com.ailife.simulation

enum class EventType {
    DISCOVERY, CIVILIZATION_FORMED, WAR, PEACE, DISEASE, EXTINCTION,
    INVENTION, MIGRATION, DISASTER, ECONOMIC, POLITICAL, DEATH, BIRTH
}

data class HistoryEvent(
    val year: Int,
    val type: EventType,
    val title: String,
    val description: String,
    val entityId: Int = -1,
    val civId: Int = -1
)

class HistoryLog {
    private val _events = ArrayDeque<HistoryEvent>(2000)

    val events: List<HistoryEvent> get() = _events

    fun record(event: HistoryEvent) {
        _events.addLast(event)
        // Cap at 2 000 events to prevent memory bloat
        while (_events.size > 2000) _events.removeFirst()
    }

    fun getRecentEvents(count: Int = 20): List<HistoryEvent> =
        _events.takeLast(count).reversed()

    fun getMajorEvents(): List<HistoryEvent> = _events.filter {
        it.type in setOf(
            EventType.DISCOVERY, EventType.CIVILIZATION_FORMED, EventType.WAR,
            EventType.EXTINCTION, EventType.INVENTION, EventType.DISEASE, EventType.DISASTER
        )
    }
}
