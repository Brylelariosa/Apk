package com.ailife.simulation

import kotlin.math.*
import kotlin.random.Random

object WorldGenerator {

    fun generate(world: World, seed: Long = Random.nextLong()) {
        val rng     = Random(seed)
        val rawH    = noiseMap(world.width, world.height, seed,      6, 0.50f, 2f, 0.007f)
        val moistMap= noiseMap(world.width, world.height, seed + 1L, 4, 0.50f, 2f, 0.009f)
        val tempMap = temperatureMap(world.width, world.height, seed + 2L)

        // Apply continent shape: land in centre, ocean at edges
        val cx = world.width / 2f; val cy = world.height / 2f
        val maxD = sqrt(cx * cx + cy * cy)
        for (x in 0 until world.width) for (y in 0 until world.height) {
            val d = sqrt((x - cx) * (x - cx) + (y - cy) * (y - cy))
            val continent = 1f - (d / maxD) * 0.72f   // centre = 1.0, corners ≈ 0.28
            rawH[x][y] = (rawH[x][y] * continent)
        }
        normalise(rawH, world.width, world.height)

        for (x in 0 until world.width) for (y in 0 until world.height) {
            val h = rawH[x][y]; val m = moistMap[x][y]; val t = tempMap[x][y]
            world.moisture[x][y]    = m
            world.temperature[x][y] = t

            world.terrain[x][y] = when {
                h < 0.18f                     -> TerrainType.DEEP_WATER
                h < 0.26f                     -> TerrainType.SHALLOW_WATER
                h < 0.30f                     -> TerrainType.BEACH
                t < 0.16f                     -> TerrainType.SNOW
                h > 0.78f                     -> TerrainType.MOUNTAIN
                m < 0.22f && t > 0.56f        -> TerrainType.DESERT
                m < 0.34f                     -> TerrainType.PLAINS
                m > 0.68f && h < 0.52f        -> TerrainType.SWAMP
                m > 0.46f                     -> TerrainType.FOREST
                else                          -> TerrainType.GRASSLAND
            }

            val res = world.resources[x][y]
            when (world.terrain[x][y]) {
                TerrainType.PLAINS, TerrainType.GRASSLAND -> {
                    res.food  = rng.nextInt(3) + 1
                    res.water = if (m > 0.55f) rng.nextInt(3) else 0
                }
                TerrainType.FOREST -> {
                    res.food = rng.nextInt(2) + 1
                    res.wood = rng.nextInt(6) + 3
                }
                TerrainType.MOUNTAIN -> {
                    res.stone = rng.nextInt(5) + 2
                    res.iron  = if (rng.nextFloat() < 0.30f) rng.nextInt(3) + 1 else 0
                }
                TerrainType.SHALLOW_WATER -> { res.food = rng.nextInt(2) + 1; res.water = 5 }
                TerrainType.DESERT        -> res.stone = rng.nextInt(2)
                TerrainType.SWAMP         -> { res.food = 1; res.water = 3 }
                else -> {}
            }
            if (!world.isWater(x, y) && rng.nextFloat() < 0.022f) res.water = 5
        }
    }

    /** Spread 48 starting entities across hospitable land */
    fun placeStartingEntities(world: World, count: Int) {
        val good = mutableListOf<Pair<Int, Int>>()
        for (x in 0 until world.width) for (y in 0 until world.height) {
            val t = world.terrain[x][y]
            if (t == TerrainType.PLAINS || t == TerrainType.GRASSLAND || t == TerrainType.FOREST)
                good.add(x to y)
        }
        good.shuffle()
        val baseKnowledge = setOf(KnowledgeType.STONE_TOOLS, KnowledgeType.LANGUAGE)
        var placed = 0
        for ((x, y) in good) {
            if (placed >= count) break
            val gender = if (placed % 2 == 0) Gender.MALE else Gender.FEMALE
            val e = world.spawnEntity(x + Random.nextFloat(), y + Random.nextFloat(), gender)
            e.knowledge.addAll(baseKnowledge)
            if (Random.nextFloat() < 0.35f) e.knowledge.add(KnowledgeType.FIRE)
            placed++
        }
    }

    /** Populate the world with wildlife */
    fun placeAnimals(world: World) {
        fun goodTiles(filter: (TerrainType) -> Boolean) = buildList {
            for (x in 0 until world.width) for (y in 0 until world.height)
                if (filter(world.terrain[x][y])) add(x to y)
        }.shuffled()

        val land  = goodTiles { t -> t == TerrainType.PLAINS || t == TerrainType.GRASSLAND || t == TerrainType.FOREST }
        val forest= goodTiles { t -> t == TerrainType.FOREST }
        val water = goodTiles { t -> t == TerrainType.SHALLOW_WATER }
        val plain = goodTiles { t -> t == TerrainType.PLAINS || t == TerrainType.GRASSLAND }

        fun spawn(tiles: List<Pair<Int,Int>>, type: AnimalType, count: Int) {
            tiles.take(count).forEach { (x, y) ->
                world.animals.add(Animal(world.nextAnimalId++,
                    x + Random.nextFloat(), y + Random.nextFloat(), type))
            }
        }
        spawn(land,   AnimalType.DEER,   70)
        spawn(plain,  AnimalType.RABBIT, 50)
        spawn(forest, AnimalType.WOLF,   25)
        spawn(water,  AnimalType.FISH,   90)
    }

    // ── Noise helpers ─────────────────────────────────────────────────────────

    private fun noiseMap(w: Int, h: Int, seed: Long, octaves: Int,
                         persistence: Float, lacunarity: Float, scale: Float): Array<FloatArray> {
        val rng     = Random(seed)
        val offsets = Array(octaves) { rng.nextInt(-9999, 9999) to rng.nextInt(-9999, 9999) }
        val map     = Array(w) { FloatArray(h) }
        for (x in 0 until w) for (y in 0 until h) {
            var amp = 1f; var freq = 1f; var v = 0f
            for (i in 0 until octaves) {
                v   += perlin((x + offsets[i].first) * scale * freq,
                              (y + offsets[i].second) * scale * freq) * amp
                amp *= persistence; freq *= lacunarity
            }
            map[x][y] = v
        }
        normalise(map, w, h)
        return map
    }

    private fun normalise(map: Array<FloatArray>, w: Int, h: Int) {
        var mx = Float.MIN_VALUE; var mn = Float.MAX_VALUE
        for (x in 0 until w) for (y in 0 until h) {
            if (map[x][y] > mx) mx = map[x][y]; if (map[x][y] < mn) mn = map[x][y]
        }
        val r = (mx - mn).coerceAtLeast(1e-6f)
        for (x in 0 until w) for (y in 0 until h) map[x][y] = (map[x][y] - mn) / r
    }

    private fun temperatureMap(w: Int, h: Int, seed: Long): Array<FloatArray> {
        val noise = noiseMap(w, h, seed, 2, 0.5f, 2f, 0.010f)
        return Array(w) { x -> FloatArray(h) { y ->
            val lat = 1f - 2f * abs(y - h / 2f) / h
            (lat * 0.72f + noise[x][y] * 0.28f).coerceIn(0f, 1f)
        }}
    }

    private fun perlin(x: Float, y: Float): Float {
        val xi = x.toInt(); val yi = y.toInt()
        val xf = x - xi;   val yf = y - yi
        val u  = fade(xf); val v  = fade(yf)
        return lerp(lerp(grad(hash(xi,yi),xf,yf), grad(hash(xi+1,yi),xf-1f,yf), u),
                    lerp(grad(hash(xi,yi+1),xf,yf-1f), grad(hash(xi+1,yi+1),xf-1f,yf-1f), u), v)
    }
    private fun fade(t: Float) = t*t*t*(t*(t*6f-15f)+10f)
    private fun lerp(a: Float, b: Float, t: Float) = a + t*(b-a)
    private fun grad(h: Int, x: Float, y: Float) = when (h and 3) { 0->x+y; 1->-x+y; 2->x-y; else->-x-y }
    private fun hash(x: Int, y: Int): Int {
        var h = x*1619 + y*31337 + 1013904223
        h = h xor (h ushr 16); h *= -0x7a143595; h = h xor (h ushr 16)
        return h and 0xFF
    }
}
