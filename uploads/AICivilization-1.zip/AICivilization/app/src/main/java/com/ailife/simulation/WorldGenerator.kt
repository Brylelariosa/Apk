package com.ailife.simulation

import kotlin.math.abs
import kotlin.random.Random

object WorldGenerator {

    fun generate(world: World, seed: Long = Random.nextLong()) {
        val heightMap   = noiseMap(world.width, world.height, seed,      octaves = 6, scale = 0.006f)
        val moistureMap = noiseMap(world.width, world.height, seed + 1L, octaves = 4, scale = 0.008f)
        val tempMap     = tempMap (world.width, world.height, seed + 2L)

        val rng = Random(seed)

        for (x in 0 until world.width) {
            for (y in 0 until world.height) {
                val h = heightMap[x][y]
                val m = moistureMap[x][y]
                val t = tempMap[x][y]
                world.moisture[x][y]    = m
                world.temperature[x][y] = t

                world.terrain[x][y] = when {
                    h < 0.28f                        -> TerrainType.DEEP_WATER
                    h < 0.36f                        -> TerrainType.SHALLOW_WATER
                    h < 0.40f                        -> TerrainType.BEACH
                    t < 0.18f                        -> TerrainType.SNOW
                    h > 0.78f                        -> TerrainType.MOUNTAIN
                    m < 0.22f && t > 0.58f           -> TerrainType.DESERT
                    m < 0.34f                        -> TerrainType.PLAINS
                    m > 0.68f && h < 0.52f           -> TerrainType.SWAMP
                    m > 0.48f                        -> TerrainType.FOREST
                    else                             -> TerrainType.GRASSLAND
                }

                val res = world.resources[x][y]
                when (world.terrain[x][y]) {
                    TerrainType.PLAINS, TerrainType.GRASSLAND -> {
                        res.food  = rng.nextInt(3) + 1
                        res.water = if (m > 0.55f) rng.nextInt(3) else 0
                    }
                    TerrainType.FOREST -> {
                        res.food = rng.nextInt(2) + 1
                        res.wood = rng.nextInt(5) + 3
                    }
                    TerrainType.MOUNTAIN -> {
                        res.stone = rng.nextInt(5) + 2
                        res.iron  = if (rng.nextFloat() < 0.28f) rng.nextInt(3) + 1 else 0
                    }
                    TerrainType.SHALLOW_WATER -> {
                        res.food  = rng.nextInt(2) + 1
                        res.water = 5
                    }
                    TerrainType.DESERT -> res.stone = rng.nextInt(2)
                    TerrainType.SWAMP  -> { res.food = 1; res.water = 3 }
                    else -> {}
                }
                // Scattered springs / river pools
                if (!world.isWater(x, y) && rng.nextFloat() < 0.025f) res.water = 5
            }
        }
    }

    /** Place the initial population on hospitable land */
    fun placeStartingEntities(world: World, count: Int) {
        val goodTiles = mutableListOf<Pair<Int, Int>>()
        for (x in 0 until world.width) for (y in 0 until world.height) {
            val t = world.terrain[x][y]
            if (t == TerrainType.PLAINS || t == TerrainType.GRASSLAND || t == TerrainType.FOREST)
                goodTiles.add(x to y)
        }
        goodTiles.shuffle()

        val startKnowledge = setOf(KnowledgeType.STONE_TOOLS, KnowledgeType.LANGUAGE)
        var placed = 0
        for ((x, y) in goodTiles) {
            if (placed >= count) break
            val gender = if (placed % 2 == 0) Gender.MALE else Gender.FEMALE
            val e = world.spawnEntity(
                x + Random.nextFloat(), y + Random.nextFloat(), gender
            )
            e.knowledge.addAll(startKnowledge)
            // Some lucky starters already know fire
            if (Random.nextFloat() < 0.3f) e.knowledge.add(KnowledgeType.FIRE)
            placed++
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Noise
    // ─────────────────────────────────────────────────────────────────────

    private fun noiseMap(
        w: Int, h: Int, seed: Long,
        octaves: Int = 6, persistence: Float = 0.5f, lacunarity: Float = 2f, scale: Float = 0.006f
    ): Array<FloatArray> {
        val rng     = Random(seed)
        val offsets = Array(octaves) { rng.nextInt(-9999, 9999) to rng.nextInt(-9999, 9999) }
        val map     = Array(w) { FloatArray(h) }
        var maxV    = Float.MIN_VALUE
        var minV    = Float.MAX_VALUE

        for (x in 0 until w) for (y in 0 until h) {
            var amp   = 1f; var freq = 1f; var v = 0f
            for (i in 0 until octaves) {
                v    += perlin((x + offsets[i].first) * scale * freq,
                               (y + offsets[i].second) * scale * freq) * amp
                amp  *= persistence; freq *= lacunarity
            }
            map[x][y] = v
            if (v > maxV) maxV = v
            if (v < minV) minV = v
        }
        val range = (maxV - minV).coerceAtLeast(1e-6f)
        for (x in 0 until w) for (y in 0 until h) map[x][y] = (map[x][y] - minV) / range
        return map
    }

    private fun tempMap(w: Int, h: Int, seed: Long): Array<FloatArray> {
        val noise = noiseMap(w, h, seed, octaves = 2, scale = 0.010f)
        val t     = Array(w) { FloatArray(h) }
        for (x in 0 until w) for (y in 0 until h) {
            val lat = 1f - 2f * abs(y - h / 2f) / h   // 1 at equator, 0 at poles
            t[x][y] = (lat * 0.72f + noise[x][y] * 0.28f).coerceIn(0f, 1f)
        }
        return t
    }

    // ── Perlin-gradient noise (value range ≈ -1..1) ──────────────────────
    private fun perlin(x: Float, y: Float): Float {
        val xi = x.toInt(); val yi = y.toInt()
        val xf = x - xi;   val yf = y - yi
        val u  = fade(xf); val v  = fade(yf)
        val a  = grad(hash(xi, yi),     xf,      yf     )
        val b  = grad(hash(xi + 1, yi), xf - 1f, yf     )
        val c  = grad(hash(xi, yi + 1), xf,      yf - 1f)
        val d  = grad(hash(xi + 1, yi + 1), xf - 1f, yf - 1f)
        return lerp(lerp(a, b, u), lerp(c, d, u), v)
    }

    private fun fade(t: Float)           = t * t * t * (t * (t * 6f - 15f) + 10f)
    private fun lerp(a: Float, b: Float, t: Float) = a + t * (b - a)
    private fun grad(h: Int, x: Float, y: Float) = when (h and 3) {
        0 -> x + y; 1 -> -x + y; 2 -> x - y; else -> -x - y
    }
    private fun hash(x: Int, y: Int): Int {
        var h = x * 1619 + y * 31337 + 1013904223
        h = h xor (h ushr 16); h *= -0x7a143595; h = h xor (h ushr 16)
        return h and 0xFF
    }
}
