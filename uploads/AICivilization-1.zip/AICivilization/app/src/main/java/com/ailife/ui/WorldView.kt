package com.ailife.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.*
import com.ailife.simulation.*

class WorldView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    // ── State ────────────────────────────────────────────────────────────────
    private var world: World? = null
    private var hudLine1: String = ""
    private var hudLine2: String = ""
    private var hudAlert: String = ""
    private var selectedId: Int = -1

    var onTileClick: ((worldX: Float, worldY: Float) -> Unit)? = null

    // ── Camera ───────────────────────────────────────────────────────────────
    private var scale = 1f
    private var offX  = 0f
    private var offY  = 0f

    // ── Terrain bitmap cache ─────────────────────────────────────────────────
    private var terrainBmp: Bitmap? = null
    private var terrainDirty = true

    // ── Paints ───────────────────────────────────────────────────────────────
    private val entityPaint  = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint    = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style       = Paint.Style.STROKE
        color       = Color.WHITE
        strokeWidth = 2f
    }
    private val labelPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color     = Color.WHITE
        textAlign = Paint.Align.CENTER
        setShadowLayer(2.5f, 1f, 1f, Color.BLACK)
    }
    private val hudBgPaint   = Paint().apply { color = Color.argb(185, 10, 10, 24) }
    private val hudTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color    = Color.WHITE
        textSize = 11f * resources.displayMetrics.scaledDensity
    }
    private val alertPaint   = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color    = 0xFFFF6B6B.toInt()
        textSize = 10f * resources.displayMetrics.scaledDensity
    }

    private val terrainColors = mapOf(
        TerrainType.DEEP_WATER    to 0xFF0B2E5E.toInt(),
        TerrainType.SHALLOW_WATER to 0xFF1A6099.toInt(),
        TerrainType.BEACH         to 0xFFF5E08A.toInt(),
        TerrainType.PLAINS        to 0xFF7BC44A.toInt(),
        TerrainType.GRASSLAND     to 0xFF4B9E2E.toInt(),
        TerrainType.FOREST        to 0xFF1B5220.toInt(),
        TerrainType.MOUNTAIN      to 0xFF8A8A8A.toInt(),
        TerrainType.SNOW          to 0xFFEEEEEE.toInt(),
        TerrainType.DESERT        to 0xFFE8C97A.toInt(),
        TerrainType.SWAMP         to 0xFF4A5D42.toInt()
    )

    // ── Gesture detectors ────────────────────────────────────────────────────
    private var lastTX = 0f; private var lastTY = 0f; private var didDrag = false

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val prev = scale
                scale = (scale * d.scaleFactor).coerceIn(0.4f, 18f)
                offX  = d.focusX - (d.focusX - offX) * (scale / prev)
                offY  = d.focusY - (d.focusY - offY) * (scale / prev)
                invalidate(); return true
            }
        })

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lastTX = ev.x; lastTY = ev.y; didDrag = false }
            MotionEvent.ACTION_MOVE -> if (!scaleDetector.isInProgress) {
                val dx = ev.x - lastTX; val dy = ev.y - lastTY
                if (didDrag || dx * dx + dy * dy > 25) {
                    offX += dx; offY += dy; didDrag = true; invalidate()
                }
                lastTX = ev.x; lastTY = ev.y
            }
            MotionEvent.ACTION_UP -> if (!didDrag && !scaleDetector.isInProgress) {
                val wx = (ev.x - offX) / scale / TSIZE
                val wy = (ev.y - offY) / scale / TSIZE
                onTileClick?.invoke(wx, wy)
            }
        }
        return true
    }

    // ── Public API ───────────────────────────────────────────────────────────

    fun setWorld(w: World, line1: String, line2: String, alert: String) {
        world = w; hudLine1 = line1; hudLine2 = line2; hudAlert = alert
        invalidate()
    }

    fun markTerrainDirty() { terrainDirty = true }

    fun setSelected(id: Int) { selectedId = id; invalidate() }

    fun centerOnWorld(w: World) {
        val bmpW = w.width  * TSIZE
        val bmpH = w.height * TSIZE
        scale = minOf(width.toFloat() / bmpW, height.toFloat() / bmpH) * 0.92f
        offX  = (width  - bmpW * scale) / 2f
        offY  = (height - bmpH * scale) / 2f
        invalidate()
    }

    // ── Drawing ───────────────────────────────────────────────────────────────

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = world ?: return
        canvas.drawColor(Color.BLACK)

        canvas.save()
        canvas.translate(offX, offY)
        canvas.scale(scale, scale)

        drawTerrain(canvas, w)
        drawEntities(canvas, w)

        canvas.restore()
        drawHUD(canvas)
    }

    private fun drawTerrain(canvas: Canvas, w: World) {
        val bw = w.width * TSIZE_I; val bh = w.height * TSIZE_I
        if (terrainDirty || terrainBmp == null ||
            terrainBmp!!.width != bw || terrainBmp!!.height != bh) {
            terrainBmp?.recycle()
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.RGB_565)
            val bc  = Canvas(bmp)
            val p   = Paint(); p.isAntiAlias = false
            for (x in 0 until w.width) for (y in 0 until w.height) {
                p.color = terrainColors[w.terrain[x][y]] ?: Color.GRAY
                bc.drawRect((x * TSIZE_I).toFloat(), (y * TSIZE_I).toFloat(),
                            ((x + 1) * TSIZE_I).toFloat(), ((y + 1) * TSIZE_I).toFloat(), p)
            }
            terrainBmp   = bmp
            terrainDirty = false
        }
        val bp = Paint(); bp.isFilterBitmap = false
        canvas.drawBitmap(terrainBmp!!, 0f, 0f, bp)
    }

    private fun drawEntities(canvas: Canvas, w: World) {
        val baseR = ERAD / scale.coerceAtLeast(1f)
        val r     = baseR.coerceIn(1.2f, ERAD)

        val snapshot = w.entities   // CopyOnWriteArrayList — safe to iterate
        for (e in snapshot) {
            if (!e.isAlive) continue
            val ex = e.x * TSIZE; val ey = e.y * TSIZE

            // Base colour from civilisation or neutral grey
            val basCol = if (e.civId >= 0) {
                w.civById(e.civId)?.color ?: 0xFFAAAAAA.toInt()
            } else 0xFFAAAAAA.toInt()

            // Tint if sick or starving
            val col = when {
                e.diseaseId >= 0  -> blendColor(basCol, 0xFF8B0000.toInt(), 0.55f)
                e.hunger > 0.70f  -> blendColor(basCol, 0xFFFFAA00.toInt(), 0.45f)
                else              -> basCol
            }

            // Size by life stage
            val er = when (e.lifeStage) {
                LifeStage.CHILD -> r * 0.58f
                LifeStage.ELDER -> r * 0.82f
                else            -> r
            }

            entityPaint.color = col
            entityPaint.alpha = (e.health * 230).toInt().coerceIn(70, 230)
            canvas.drawCircle(ex, ey, er, entityPaint)

            if (e.id == selectedId) {
                ringPaint.strokeWidth = 2.2f / scale
                canvas.drawCircle(ex, ey, er + 2.2f / scale, ringPaint)
            }
        }

        // Civilisation name labels (only when zoomed out enough)
        if (scale < 6f) {
            labelPaint.textSize = (14f / scale).coerceIn(8f, 22f)
            for (civ in w.civilizations) {
                if (civ.isExtinct || civ.population < 6) continue
                canvas.drawText(civ.name, civ.centerX * TSIZE, civ.centerY * TSIZE - 8f / scale, labelPaint)
            }
        }
    }

    private fun drawHUD(canvas: Canvas) {
        val barH  = hudTextPaint.textSize * 3.4f
        canvas.drawRect(0f, 0f, width.toFloat(), barH, hudBgPaint)

        val lineH = hudTextPaint.textSize * 1.28f
        canvas.drawText(hudLine1, 10f, lineH,          hudTextPaint)
        canvas.drawText(hudLine2, 10f, lineH * 2.1f,   hudTextPaint)
        if (hudAlert.isNotEmpty()) canvas.drawText(hudAlert, 10f, lineH * 3.0f, alertPaint)
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun blendColor(base: Int, tint: Int, t: Float): Int {
        val s = 1f - t
        return Color.argb(
            255,
            (Color.red(base)   * s + Color.red(tint)   * t).toInt().coerceIn(0, 255),
            (Color.green(base) * s + Color.green(tint) * t).toInt().coerceIn(0, 255),
            (Color.blue(base)  * s + Color.blue(tint)  * t).toInt().coerceIn(0, 255)
        )
    }

    companion object {
        const val TSIZE   = 7f    // tile width in bitmap pixels
        const val TSIZE_I = 7     // integer version
        const val ERAD    = 4.5f  // entity base radius in tile-pixel space
    }
}
