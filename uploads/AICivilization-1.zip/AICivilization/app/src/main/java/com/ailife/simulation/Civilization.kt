package com.ailife.simulation

import kotlin.math.abs
import kotlin.random.Random

enum class GovType(val label: String) {
    TRIBAL("Tribe"), CHIEFDOM("Chiefdom"), MONARCHY("Monarchy"),
    REPUBLIC("Republic"), EMPIRE("Empire")
}

class Civilization(
    val id: Int,
    val foundedTick: Long,
    var name: String,
    val color: Int,       // Android packed ARGB int
    var centerX: Float,
    var centerY: Float
) {
    // ── Members ───────────────────────────────────────────────────────────
    var population: Int = 0
    var leaderId: Int   = -1

    // ── Knowledge ─────────────────────────────────────────────────────────
    /** Union of all member knowledge; individual members may know less */
    val knowledge: MutableSet<KnowledgeType> = mutableSetOf()

    // ── Government ────────────────────────────────────────────────────────
    var government: GovType = GovType.TRIBAL

    // ── Language ──────────────────────────────────────────────────────────
    /** Drift from original language — increases each generation */
    var languageDrift: Float = 0f
    val languageSeed: Long   = Random.nextLong()

    // ── Diplomacy ─────────────────────────────────────────────────────────
    /** civId → relation score in [-1, 1]. Decays toward 0 over time. */
    val relations: HashMap<Int, Float> = HashMap()

    // ── Fate ──────────────────────────────────────────────────────────────
    var isExtinct: Boolean   = false
    var extinctionTick: Long = -1L

    // ── Methods ───────────────────────────────────────────────────────────

    fun addKnowledge(type: KnowledgeType) { knowledge.add(type) }

    /** 1 = mutually intelligible, 0 = completely alien */
    fun languageCompatibility(other: Civilization): Float {
        val driftDiff = abs(languageDrift - other.languageDrift)
        val seedDiff  = (abs(languageSeed - other.languageSeed) % 1000L).toFloat() / 1000f
        return (1f - driftDiff * 1.5f - seedDiff * 0.4f).coerceIn(0f, 1f)
    }

    fun canCommunicate(other: Civilization): Boolean =
        languageCompatibility(other) > 0.38f

    fun updateGovernment() {
        government = when {
            population < 15               -> GovType.TRIBAL
            population < 80               -> GovType.CHIEFDOM
            KnowledgeType.WRITING in knowledge && population < 400 -> GovType.MONARCHY
            KnowledgeType.MATHEMATICS in knowledge && population >= 400 -> GovType.REPUBLIC
            population > 800              -> GovType.EMPIRE
            else                          -> government   // no downgrade mid-game
        }
    }

    fun getEraName(): String = when {
        KnowledgeType.COMPUTERS    in knowledge -> "Digital Age"
        KnowledgeType.ELECTRICITY  in knowledge -> "Industrial Age"
        KnowledgeType.PRINTING     in knowledge -> "Renaissance"
        KnowledgeType.METALLURGY   in knowledge -> "Iron Age"
        KnowledgeType.FARMING      in knowledge -> "Agricultural Age"
        KnowledgeType.FIRE         in knowledge -> "Neolithic"
        else                                    -> "Stone Age"
    }

    fun getRelation(otherId: Int): Float = relations[otherId] ?: 0f

    fun setRelation(otherId: Int, value: Float) {
        relations[otherId] = value.coerceIn(-1f, 1f)
    }

    fun decayRelations() {
        for (k in relations.keys.toList()) {
            relations[k] = relations[k]!! * 0.98f
            if (abs(relations[k]!!) < 0.01f) relations.remove(k)
        }
    }
}
