package com.ailife.simulation

import kotlin.math.sqrt

enum class Gender { MALE, FEMALE }
enum class LifeStage { CHILD, ADULT, ELDER }
enum class Goal {
    IDLE, SEEK_FOOD, SEEK_WATER, REST, SEEK_MATE,
    SOCIALIZE, EXPLORE, FLEE, ATTACK, TEACH, GATHER
}

class Entity(
    val id: Int,
    var x: Float,
    var y: Float,
    val gender: Gender,
    val dna: DNA,
    val birthTick: Long,
    var civId: Int = -1,
    var parentAId: Int = -1,
    var parentBId: Int = -1
) {
    // ── Vitals ───────────────────────────────────────────────────────────────
    var health: Float    = 1.0f
    var hunger: Float    = 0.0f   // 0 = full,      1 = starving
    var thirst: Float    = 0.0f   // 0 = hydrated,  1 = dying of thirst
    var energy: Float    = 1.0f   // 0 = exhausted, 1 = rested

    // ── Life ──────────────────────────────────────────────────────────────
    var age: Int         = 0       // in simulation-years (updated each 52 ticks)
    var isAlive: Boolean = true
    var deathCause: String? = null

    // ── Reproduction ──────────────────────────────────────────────────────
    var childCount: Int  = 0
    var ticksSinceMating: Long = -200L   // negative so first mating isn't gated

    // ── Knowledge ─────────────────────────────────────────────────────────
    val knowledge: MutableSet<KnowledgeType> = mutableSetOf(
        KnowledgeType.STONE_TOOLS, KnowledgeType.LANGUAGE
    )

    // ── Inventory ─────────────────────────────────────────────────────────
    var food: Int  = 3
    var water: Int = 3
    var wood: Int  = 0
    var stone: Int = 0
    var iron: Int  = 0

    // ── Behaviour ─────────────────────────────────────────────────────────
    var currentGoal: Goal = Goal.IDLE
    var targetX: Float    = x
    var targetY: Float    = y
    var targetEntityId: Int = -1
    var idleTicksLeft: Int  = 0    // used by Brain to keep idle entities calm

    // ── Relationships ─────────────────────────────────────────────────────
    /** entityId → affinity in [-1, 1] */
    val relationships: HashMap<Int, Float> = HashMap(8)

    // ── Disease ───────────────────────────────────────────────────────────
    var diseaseId: Int = -1        // -1 = healthy
    val immunities: MutableSet<Int> = mutableSetOf()

    // ── Derived ───────────────────────────────────────────────────────────
    val lifeStage: LifeStage get() = when {
        age < 14                      -> LifeStage.CHILD
        age > dna.maxAge * 0.78f      -> LifeStage.ELDER
        else                          -> LifeStage.ADULT
    }
    val isAdult:      Boolean get() = lifeStage != LifeStage.CHILD
    val isCurious:    Boolean get() = dna.curiosity    > 0.58f
    val isAggressive: Boolean get() = dna.aggression   > 0.65f
    val isSocial:     Boolean get() = dna.socialBehavior > 0.52f
    val isCreative:   Boolean get() = dna.creativity   > 0.68f

    fun distanceTo(other: Entity): Float {
        val dx = x - other.x; val dy = y - other.y
        return sqrt(dx * dx + dy * dy)
    }

    fun distanceTo(tx: Float, ty: Float): Float {
        val dx = x - tx; val dy = y - ty
        return sqrt(dx * dx + dy * dy)
    }

    fun canReproduce(currentTick: Long): Boolean =
        isAdult && isAlive &&
        childCount < dna.maxChildren &&
        hunger < 0.55f && thirst < 0.55f && health > 0.40f &&
        (currentTick - ticksSinceMating) > 100L  // ~2 in-game years

    fun acquireKnowledge(type: KnowledgeType): Boolean {
        if (type in knowledge || !type.canLearn(knowledge)) return false
        knowledge.add(type)
        return true
    }

    fun updateRelationship(otherId: Int, delta: Float) {
        relationships[otherId] = ((relationships[otherId] ?: 0f) + delta).coerceIn(-1f, 1f)
    }

    fun summarize(): String = buildString {
        append(if (gender == Gender.MALE) "♂" else "♀")
        append(" Age $age · ${dna.describe()}")
        if (diseaseId >= 0) append(" · ⚕ Ill")
    }
}
