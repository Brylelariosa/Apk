package com.ailife.simulation

import kotlin.math.sqrt

enum class Gender { MALE, FEMALE }
enum class LifeStage { CHILD, ADULT, ELDER }
enum class Goal {
    IDLE, SEEK_FOOD, SEEK_WATER, REST, SEEK_MATE,
    SOCIALIZE, EXPLORE, FLEE, ATTACK, TEACH, GATHER,
    // ── new activity goals ──────────────────────────────────────────────
    HUNT, FISH, CHOP_WOOD, BUILD
}

class Entity(
    val id: Int,
    var x: Float, var y: Float,
    val gender: Gender,
    val dna: DNA,
    val birthTick: Long,
    var civId: Int = -1,
    var parentAId: Int = -1,
    var parentBId: Int = -1
) {
    var health: Float = 1f
    var hunger: Float = 0f
    var thirst: Float = 0f
    var energy: Float = 1f

    var age: Int = 0
    var isAlive: Boolean = true
    var deathCause: String? = null

    var childCount: Int = 0
    var ticksSinceMating: Long = -200L

    val knowledge: MutableSet<KnowledgeType> = mutableSetOf(
        KnowledgeType.STONE_TOOLS, KnowledgeType.LANGUAGE
    )

    var food: Int = 3; var water: Int = 3; var wood: Int = 0; var stone: Int = 0; var iron: Int = 0

    var currentGoal: Goal = Goal.IDLE
    var targetX: Float = x; var targetY: Float = y
    var targetEntityId: Int = -1
    var idleTicksLeft: Int = 0

    val relationships: HashMap<Int, Float> = HashMap(8)

    var diseaseId: Int = -1
    val immunities: MutableSet<Int> = mutableSetOf()

    // ── Derived ────────────────────────────────────────────────────────────
    val lifeStage: LifeStage get() = when {
        age < 14                 -> LifeStage.CHILD
        age > dna.maxAge * 0.78f -> LifeStage.ELDER
        else                     -> LifeStage.ADULT
    }
    val isAdult:      Boolean get() = lifeStage != LifeStage.CHILD
    val isCurious:    Boolean get() = dna.curiosity    > 0.58f
    val isAggressive: Boolean get() = dna.aggression   > 0.65f
    val isSocial:     Boolean get() = dna.socialBehavior > 0.52f
    val isCreative:   Boolean get() = dna.creativity   > 0.68f

    fun distanceTo(other: Entity) = distanceTo(other.x, other.y)
    fun distanceTo(tx: Float, ty: Float): Float {
        val dx = x-tx; val dy = y-ty; return sqrt(dx*dx+dy*dy)
    }

    fun canReproduce(tick: Long) =
        isAdult && isAlive && childCount < dna.maxChildren &&
        hunger < 0.55f && thirst < 0.55f && health > 0.40f &&
        (tick - ticksSinceMating) > 100L

    fun acquireKnowledge(type: KnowledgeType): Boolean {
        if (type in knowledge || !type.canLearn(knowledge)) return false
        knowledge.add(type); return true
    }

    fun updateRelationship(otherId: Int, delta: Float) {
        relationships[otherId] = ((relationships[otherId] ?: 0f) + delta).coerceIn(-1f, 1f)
    }

    fun summarize() = buildString {
        append(if (gender == Gender.MALE) "♂" else "♀")
        append(" Age $age · ${dna.describe()}")
        if (diseaseId >= 0) append(" · ⚕ Ill")
    }
}
