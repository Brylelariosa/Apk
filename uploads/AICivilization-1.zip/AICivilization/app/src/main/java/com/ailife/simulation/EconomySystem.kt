package com.ailife.simulation

class EconomySystem {

    data class Commodity(
        val key: String,
        val basePriceGold: Float,
        var price: Float,
        var totalSupply: Int = 0
    )

    val commodities = listOf(
        Commodity("Food",  1.0f, 1.0f),
        Commodity("Water", 0.8f, 0.8f),
        Commodity("Wood",  1.2f, 1.2f),
        Commodity("Stone", 1.6f, 1.6f),
        Commodity("Iron",  3.2f, 3.2f)
    )

    fun update(world: World) {
        // Count world + inventory supply
        var food = 0; var water = 0; var wood = 0; var stone = 0; var iron = 0
        for (x in 0 until world.width) for (y in 0 until world.height) {
            val r = world.resources[x][y]
            food += r.food; wood += r.wood; stone += r.stone; iron += r.iron
        }
        for (e in world.entities) {
            if (!e.isAlive) continue
            food += e.food; water += e.water; wood += e.wood; stone += e.stone; iron += e.iron
        }

        val pop = world.populationCount.coerceAtLeast(1)

        fun recalc(c: Commodity, supply: Int, demand: Int) {
            c.totalSupply = supply
            val ratio = demand.toFloat() / supply.coerceAtLeast(1).toFloat()
            c.price = (c.basePriceGold * Math.sqrt(ratio.toDouble()).toFloat()).coerceIn(0.1f, 25f)
        }

        recalc(commodities[0], food,  pop)
        recalc(commodities[1], water, pop)
        recalc(commodities[2], wood,  pop / 2 + 1)
        recalc(commodities[3], stone, pop / 3 + 1)
        recalc(commodities[4], iron,  pop / 6 + 1)
    }

    fun priceDisplay(): String = commodities.joinToString("  ") {
        "${it.key}: ${"%.2f".format(it.price)}g"
    }

    fun getPrice(key: String): Float = commodities.firstOrNull { it.key == key }?.price ?: 1f
}
