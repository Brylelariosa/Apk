package com.ailife.simulation

import kotlin.random.Random

data class Disease(
    val id: Int,
    val name: String,
    var infectiousness: Float,   // chance/contact to spread (0–1)
    var severity: Float,         // health damage per tick (0–1 scaled)
    val mutationRate: Float,     // chance of stat drift each tick
    var ticksActive: Long = 0L,
    var totalInfected: Int = 0
)

class DiseaseSystem(private val world: World) {

    val active: MutableList<Disease> = mutableListOf()
    private var nextId: Int = 0

    private val names = listOf(
        "Red Fever", "Gray Plague", "Bone Wasting", "Sky Sickness",
        "Black Sweat", "Wailing Pox", "River Rot", "Mountain Fever",
        "Silent Death", "Crimson Tremor", "Jade Cough", "Iron Lung",
        "Ashen Blight", "Hollow Ache", "Marrow Rot", "Veil Sickness"
    )

    fun update() {
        // Spontaneous emergence
        if (world.populationCount > 28 && Random.nextFloat() < 0.0004f) spawnDisease()

        val toEradicate = mutableListOf<Disease>()
        for (disease in active) {
            disease.ticksActive++

            val carriers = world.entities.filter { it.isAlive && it.diseaseId == disease.id }
            if (carriers.isEmpty()) { toEradicate.add(disease); continue }

            for (carrier in carriers) {
                // Damage — reduced by resistance
                val dmg = disease.severity * 0.008f * (1f - carrier.dna.diseaseResistance * 0.55f)
                carrier.health -= dmg

                // Chance of recovery
                val recoverChance = 0.012f + carrier.dna.diseaseResistance * 0.025f +
                    (if (KnowledgeType.MEDICINE   in carrier.knowledge) 0.015f else 0f) +
                    (if (KnowledgeType.GERM_THEORY in carrier.knowledge) 0.018f else 0f) +
                    (if (KnowledgeType.VACCINES    in carrier.knowledge) 0.030f else 0f)

                if (Random.nextFloat() < recoverChance) {
                    carrier.diseaseId = -1
                    carrier.immunities.add(disease.id)
                    continue
                }

                // Spread to nearby
                val nearby = world.getNearby(carrier.x, carrier.y, 3.5f)
                for (other in nearby) {
                    if (!other.isAlive || other.diseaseId != -1 || disease.id in other.immunities) continue
                    val baseSpread = disease.infectiousness * (1f - other.dna.diseaseResistance * 0.60f)
                    if (Random.nextFloat() < baseSpread * 0.08f) {
                        other.diseaseId = disease.id
                        disease.totalInfected++
                    }
                }
            }

            // Mutation
            if (Random.nextFloat() < disease.mutationRate) {
                disease.infectiousness = (disease.infectiousness + (Random.nextFloat() - 0.5f) * 0.18f).coerceIn(0.02f, 0.95f)
                disease.severity       = (disease.severity       + (Random.nextFloat() - 0.5f) * 0.18f).coerceIn(0.02f, 0.90f)
            }
        }

        for (d in toEradicate) {
            active.remove(d)
            world.history.record(HistoryEvent(
                world.year, EventType.DISEASE,
                "Eradicated: ${d.name}",
                "${d.name} has been eliminated after infecting ${d.totalInfected} individuals."
            ))
        }
    }

    private fun spawnDisease() {
        val disease = Disease(
            id            = nextId++,
            name          = names.random(),
            infectiousness= 0.10f + Random.nextFloat() * 0.55f,
            severity      = 0.08f + Random.nextFloat() * 0.48f,
            mutationRate  = 0.002f + Random.nextFloat() * 0.040f
        )
        val victim = world.entities.filter { it.isAlive && it.diseaseId == -1 }.randomOrNull() ?: return
        victim.diseaseId = disease.id
        disease.totalInfected = 1
        active.add(disease)
        world.history.record(HistoryEvent(
            world.year, EventType.DISEASE,
            "Outbreak: ${disease.name}",
            "${disease.name} has emerged (infectiousness ${(disease.infectiousness * 100).toInt()}%, severity ${(disease.severity * 100).toInt()}%).",
            victim.id
        ))
    }
}
