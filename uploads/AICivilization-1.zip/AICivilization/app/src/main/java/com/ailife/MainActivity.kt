package com.ailife

import android.os.Bundle
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ailife.databinding.ActivityMainBinding
import com.ailife.simulation.*
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val vm: SimViewModel by viewModels()

    private var currentTab  = 0
    private var worldCentered = false
    private var latestState: SimState? = null
    private var selectedEntity: Entity? = null

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupSpeedButtons()
        setupTabs()
        setupWorldView()
        observeState()
        observeSelection()
    }

    override fun onStop()  { super.onStop();  vm.setSpeed(SimSpeed.PAUSED) }
    override fun onStart() { super.onStart(); vm.setSpeed(SimSpeed.NORMAL) }

    // ── Setup ─────────────────────────────────────────────────────────────────

    private fun setupSpeedButtons() {
        binding.btnPause.setOnClickListener  { applySpeed(SimSpeed.PAUSED) }
        binding.btnSlow .setOnClickListener  { applySpeed(SimSpeed.SLOW)   }
        binding.btnNormal.setOnClickListener { applySpeed(SimSpeed.NORMAL) }
        binding.btnFast .setOnClickListener  { applySpeed(SimSpeed.FAST)   }
        binding.btnUltra.setOnClickListener  { applySpeed(SimSpeed.ULTRA)  }
        highlightSpeed(SimSpeed.NORMAL)
    }

    private fun applySpeed(s: SimSpeed) { vm.setSpeed(s); highlightSpeed(s) }

    private fun highlightSpeed(s: SimSpeed) {
        val btns = listOf(binding.btnPause, binding.btnSlow, binding.btnNormal, binding.btnFast, binding.btnUltra)
        val speeds = SimSpeed.values()
        btns.forEachIndexed { i, btn ->
            btn.alpha = if (speeds[i] == s) 1f else 0.38f
        }
    }

    private fun setupTabs() {
        listOf("World", "Civs", "History", "Entity").forEach {
            binding.tabLayout.addTab(binding.tabLayout.newTab().setText(it))
        }
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab) { currentTab = t.position; refreshInfo() }
            override fun onTabUnselected(t: TabLayout.Tab) {}
            override fun onTabReselected(t: TabLayout.Tab) {}
        })
    }

    private fun setupWorldView() {
        binding.worldView.onTileClick = { wx, wy -> vm.selectAt(wx, wy) }
    }

    // ── Observation ───────────────────────────────────────────────────────────

    private fun observeState() {
        lifecycleScope.launch {
            vm.simState.filterNotNull().collect { state ->
                latestState = state

                // HUD strings (built on background thread data, set on main)
                val hud1  = buildHud1(state)
                val hud2  = buildHud2(state)
                val alert = buildAlert(state)

                binding.worldView.setWorld(state.world, hud1, hud2, alert)
                binding.tvYear.text = "Year ${state.stats.year}"

                if (!worldCentered) {
                    worldCentered = true
                    binding.worldView.post { binding.worldView.centerOnWorld(state.world) }
                }

                refreshInfo()
            }
        }
    }

    private fun observeSelection() {
        lifecycleScope.launch {
            vm.selected.collect { entity ->
                selectedEntity = entity
                binding.worldView.setSelected(entity?.id ?: -1)
                if (entity != null) binding.tabLayout.getTabAt(3)?.select()
                refreshInfo()
            }
        }
    }

    // ── Info panel ────────────────────────────────────────────────────────────

    private fun refreshInfo() {
        val state = latestState ?: return
        binding.tvInfo.text = when (currentTab) {
            0 -> worldTab(state)
            1 -> civsTab(state)
            2 -> historyTab(state)
            3 -> entityTab(state)
            else -> ""
        }
    }

    private fun worldTab(s: SimState) = buildString {
        val st = s.stats
        appendLine("Population : ${st.population}   Deaths : ${st.totalDied}   Born : ${st.totalBorn}")
        appendLine("Avg age    : ${"%.1f".format(st.avgAge)}   Avg intelligence : ${"%.2f".format(st.avgIntelligence)}")
        appendLine("Civilisations : ${st.civilizations}   Knowledge types known : ${st.knowledgeTypeCount}")
        appendLine("Most advanced era : ${st.advancedEra}")
        appendLine("Season : ${s.world.weather.seasonName}   ${s.world.weather.description()}")
        val econ = s.world.economy.priceDisplay()
        appendLine()
        appendLine("Prices  $econ")
    }

    private fun civsTab(s: SimState) = buildString {
        val live = s.world.civilizations.filter { !it.isExtinct }.sortedByDescending { it.population }
        if (live.isEmpty()) {
            appendLine("No civilisations yet.")
            appendLine("Entities cluster and bond to form tribes.")
        } else {
            for (civ in live.take(7)) {
                appendLine("▶ ${civ.name}  [${civ.getEraName()}]  ${civ.government.label}")
                appendLine("  Pop: ${civ.population}  Knowledge: ${civ.knowledge.size}  Lang drift: ${"%.1f".format(civ.languageDrift * 100)}%")
            }
        }
        val dead = s.world.civilizations.count { it.isExtinct }
        if (dead > 0) appendLine("\n⚰ Extinct: $dead civilisation(s)")
    }

    private fun historyTab(s: SimState) = buildString {
        val events = s.world.history.getRecentEvents(18)
        if (events.isEmpty()) appendLine("History is being written…")
        else events.forEach { appendLine("[${it.year}] ${it.title}") }
    }

    private fun entityTab(s: SimState) = buildString {
        val e = selectedEntity
        if (e == null || !e.isAlive) {
            appendLine("Tap a dot on the map to inspect an entity.")
            appendLine()
            appendLine("Dot colour = civilisation")
            appendLine("Dot size   = life stage (child / adult / elder)")
            appendLine("Red tint   = disease")
            appendLine("Gold tint  = hunger")
        } else {
            appendLine(e.summarize())
            appendLine("Stage : ${e.lifeStage.name}   Goal : ${e.currentGoal.name}")
            appendLine()
            appendLine("Health ${"%.0f".format(e.health*100)}%  Hunger ${"%.0f".format(e.hunger*100)}%  Thirst ${"%.0f".format(e.thirst*100)}%  Energy ${"%.0f".format(e.energy*100)}%")
            appendLine()
            appendLine("Genes")
            appendLine("  Speed ${"%.2f".format(e.dna.speed)}  Intel ${"%.2f".format(e.dna.intelligence)}  Social ${"%.2f".format(e.dna.socialBehavior)}")
            appendLine("  Aggr ${"%.2f".format(e.dna.aggression)}  Create ${"%.2f".format(e.dna.creativity)}  Risk ${"%.2f".format(e.dna.riskTaking)}")
            appendLine("  Lifespan ${"%.2f".format(e.dna.lifespan)} (max age ${e.dna.maxAge})  Disease resist ${"%.2f".format(e.dna.diseaseResistance)}")
            appendLine()
            val kList = e.knowledge.toList()
            appendLine("Knowledge (${kList.size}) : ${kList.take(5).joinToString { it.displayName }}")
            if (kList.size > 5) appendLine("  …and ${kList.size - 5} more")
            val civ = s.world.civById(e.civId)
            if (civ != null) {
                appendLine()
                appendLine("Civilisation : ${civ.name}  (${civ.getEraName()}  ${civ.government.label})")
            }
            if (e.diseaseId >= 0) {
                val d = s.world.disease.active.firstOrNull { it.id == e.diseaseId }
                appendLine("⚕ Afflicted by : ${d?.name ?: "unknown disease"}")
            }
        }
    }

    // ── HUD helpers ───────────────────────────────────────────────────────────

    private fun buildHud1(s: SimState) =
        "Year ${s.stats.year}  ·  Pop: ${s.stats.population}  ·  Civs: ${s.stats.civilizations}  ·  ${s.world.weather.seasonName}"

    private fun buildHud2(s: SimState) =
        "Era: ${s.stats.advancedEra}  ·  Knowledge: ${s.stats.knowledgeTypeCount}  ·  ${s.world.weather.description()}"

    private fun buildAlert(s: SimState): String {
        val d = s.world.disease.active.firstOrNull()
        return if (d != null) "⚕ OUTBREAK: ${d.name}  (${s.world.entities.count { it.diseaseId == d.id }} infected)" else ""
    }
}
