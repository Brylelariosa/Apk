package com.ailife.simulation

import kotlin.random.Random

enum class WeatherEvent { NONE, DROUGHT, FLOOD, BLIZZARD, HEATWAVE, STORM }

class WeatherSystem(private val world: World) {

    var currentEvent: WeatherEvent = WeatherEvent.NONE
        private set
    var eventTicksLeft: Int = 0
        private set

    // Season: 0 Spring · 1 Summer · 2 Autumn · 3 Winter
    val season: Int get() = ((world.tick / 13L) % 4L).toInt()

    val seasonName: String get() = arrayOf("Spring", "Summer", "Autumn", "Winter")[season]

    var temperatureOffset: Float = 0f
        private set

    fun update() {
        // Season temperature offset
        temperatureOffset = when (season) {
            1 -> +0.18f   // Summer — hot
            3 -> -0.22f   // Winter — cold
            else -> 0f
        }

        // Tick down ongoing event
        if (eventTicksLeft > 0) {
            eventTicksLeft--
            if (eventTicksLeft == 0) {
                endEvent()
            }
        }

        // Randomly start a new event
        if (currentEvent == WeatherEvent.NONE && Random.nextFloat() < 0.0018f) {
            startEvent()
        }
    }

    private fun startEvent() {
        val r = Random.nextFloat()
        val candidate = when {
            r < 0.28f -> WeatherEvent.DROUGHT
            r < 0.46f -> WeatherEvent.FLOOD
            r < 0.60f -> WeatherEvent.STORM
            r < 0.72f && season == 3 -> WeatherEvent.BLIZZARD
            r < 0.84f && season == 1 -> WeatherEvent.HEATWAVE
            else -> WeatherEvent.NONE
        }
        if (candidate == WeatherEvent.NONE) return

        currentEvent   = candidate
        eventTicksLeft = 8 + Random.nextInt(18)
        applyEventStart()

        world.history.record(HistoryEvent(
            world.year, EventType.DISASTER,
            "Weather: ${candidate.name.lowercase().replaceFirstChar { it.uppercase() }}",
            "A ${candidate.name.lowercase()} is sweeping the land (${eventTicksLeft} weeks)."
        ))
    }

    private fun applyEventStart() {
        when (currentEvent) {
            WeatherEvent.DROUGHT -> {
                for (x in 0 until world.width) for (y in 0 until world.height) {
                    world.resources[x][y].food  = (world.resources[x][y].food  * 0.45f).toInt()
                    world.resources[x][y].water = (world.resources[x][y].water * 0.30f).toInt()
                }
            }
            WeatherEvent.FLOOD -> {
                for (x in 0 until world.width) for (y in 0 until world.height) {
                    val t = world.terrain[x][y]
                    if (t == TerrainType.PLAINS || t == TerrainType.GRASSLAND) {
                        world.resources[x][y].water += 4
                        if (Random.nextFloat() < 0.22f) world.resources[x][y].food = 0
                    }
                }
            }
            WeatherEvent.HEATWAVE -> {
                for (x in 0 until world.width) for (y in 0 until world.height)
                    world.resources[x][y].water = (world.resources[x][y].water * 0.5f).toInt()
            }
            else -> {}
        }
    }

    private fun endEvent() {
        currentEvent = WeatherEvent.NONE
    }

    fun effectiveTemp(x: Int, y: Int): Float =
        (world.temperature[x][y] + temperatureOffset).coerceIn(0f, 1f)

    fun description(): String = when {
        currentEvent != WeatherEvent.NONE ->
            "${currentEvent.name.lowercase().replaceFirstChar { it.uppercase() }} (${eventTicksLeft}w left)"
        else -> "$seasonName — clear"
    }
}
