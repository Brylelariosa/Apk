package com.ailife.simulation

import kotlin.math.sqrt

enum class BuildingType(
    val displayName: String,
    val mapColor: Int,
    val requiredKnowledge: KnowledgeType? = null,
    val woodCost: Int = 0,
    val stoneCost: Int = 0
) {
    HUT         ("Hut",           0xFFBB8844.toInt(), null,                         woodCost = 3),
    CAMPFIRE    ("Campfire",      0xFFFF7722.toInt(), KnowledgeType.FIRE,            woodCost = 2),
    FARM        ("Farm",          0xFF77CC33.toInt(), KnowledgeType.FARMING,         woodCost = 2, stoneCost = 1),
    FISHING_HUT ("Fishing Hut",   0xFF3388CC.toInt(), null,                          woodCost = 3),
    MINE        ("Mine",          0xFF888888.toInt(), KnowledgeType.STONE_TOOLS,     woodCost = 2),
    FORGE       ("Forge",         0xFFCC5511.toInt(), KnowledgeType.METALLURGY,      woodCost = 2, stoneCost = 4),
    WATCHTOWER  ("Watchtower",    0xFFAA9966.toInt(), KnowledgeType.ARCHITECTURE,    woodCost = 3, stoneCost = 5),
    MARKET      ("Market",        0xFFFFCC22.toInt(), KnowledgeType.WRITING,         woodCost = 4, stoneCost = 3),
    LIBRARY     ("Library",       0xFF9944CC.toInt(), KnowledgeType.PRINTING,        woodCost = 5, stoneCost = 5),
}

class Building(
    val id: Int,
    val type: BuildingType,
    val tileX: Int,
    val tileY: Int,
    val civId: Int,
    var progress: Float = 0f,   // 0..1
    var health: Float = 1f
) {
    val isComplete: Boolean get() = progress >= 1f
    val worldX: Float get() = tileX + 0.5f
    val worldY: Float get() = tileY + 0.5f

    fun distanceTo(ex: Float, ey: Float): Float {
        val dx = worldX - ex; val dy = worldY - ey
        return sqrt(dx * dx + dy * dy)
    }
}
