package com.ailife.simulation

import kotlin.math.sqrt
import kotlin.random.Random

enum class AnimalType(
    val displayColor: Int,
    val speed: Float,
    val foodValue: Int,
    val isDangerous: Boolean,
    val livesInWater: Boolean = false
) {
    DEER  (0xFFCC9955.toInt(), 0.55f, 4, false),
    RABBIT(0xFFDDBB99.toInt(), 0.70f, 2, false),
    WOLF  (0xFF775544.toInt(), 0.68f, 1, true),
    FISH  (0xFF3377BB.toInt(), 0.40f, 3, false, livesInWater = true),
}

class Animal(
    val id: Int,
    var x: Float,
    var y: Float,
    val type: AnimalType,
    var health: Float = 1f,
    var isAlive: Boolean = true
) {
    var targetX: Float = x
    var targetY: Float = y
    var wanderCooldown: Int = 0

    fun distanceTo(ex: Float, ey: Float): Float {
        val dx = x - ex; val dy = y - ey
        return sqrt(dx * dx + dy * dy)
    }
}
