# Stability, Reliability & Performance Pass (v39)

Implements the 15-item audit follow-up ("Comprehensive Stability, Reliability,
and Performance Fixes — Final Architecture Pass"). No user-facing behavior
was intentionally changed except where the item explicitly called for a bug
fix. Plus one new feature requested alongside this pass: **choosing which
run's build log to download**, not just the latest.

Every item below was implemented, not just discussed. Balance-checked
(brace/paren/bracket parity) across all 49 Kotlin files after every edit —
see the bottom of this file for what that does and doesn't guarantee.

---

## 1. Persisted download queue (highest priority)

New: `DownloadPersistence`, `DownloadRestoreInfo` (sealed: `Artifact` / `Log`).
Changed: `DownloadTask`, `DownloadEngine`, `DownloadQueue`, `DownloadManager`,
`DownloadDialogController`, `MainActivity.onCreate`.

- Every non-completed task (queued/downloading/paused/retrying/waiting-for-
  network/failed/cancelled) is snapshotted to SharedPreferences as JSON —
  on every status transition, plus a 1s-throttled tick while bytes are
  actively moving (not per-byte — that would be I/O-wasteful for no benefit,
  since resume correctness comes from the partial file's actual on-disk
  length, not the persisted byte count).
- `DownloadTask.resolveUrl`/`onSuccess` are closures and can't be serialized
  — `DownloadRestoreInfo` is the small data "recipe" that lets
  `DownloadManager` rebuild an equivalent task via the *same* factory
  (`buildArtifactTask`/`buildLogTask`) a fresh download uses, not a second,
  parallel "restored task" implementation.
- On restart (`MainActivity.onCreate`, after the token field is populated):
  `DownloadManager.restorePersistedDownloads()` reconstructs every saved
  task and hands them to `DownloadQueue.restoreTasks`. Non-paused tasks
  resume transferring immediately; a task the user had explicitly paused
  stays paused (no live worker survives a restart to reattach to, so a
  fresh one is started, but `pauseRequested` is preserved — it re-pauses
  itself before any bytes move, at the top of the copy loop). Terminal
  (failed/cancelled) tasks reappear with Retry/Remove intact.
- New `DownloadTask.etag`/`lastModified`, captured on every connect. On a
  resume attempt, if the server's current ETag differs from the one
  recorded when the partial download started, the partial is discarded and
  restarted once — otherwise a changed remote file (e.g. a re-run
  overwriting an artifact) would silently splice old and new bytes together
  into a corrupt file.
- `DownloadTask.retryCount` — informational only (see kdoc): the retry
  *budget* correctly still resets per worker run, restored or not.
- Fixed a genuine race this feature could otherwise introduce: the existing
  cold-start stale-cache sweep (`cleanupStaleCacheFiles`, 7-day threshold
  for partial downloads) could have deleted a long-paused download's
  partial file out from under a task `restorePersistedDownloads` had just
  resubmitted. Fixed by excluding every file backing a currently-tracked
  task from the sweep, regardless of age, and ensuring restore always runs
  before the sweep is scheduled.

## 2. Centralized GitHub URL/path encoding

`GitHubApi` gained `encodeContentPath`/`encodeRefPath`/`encodeQueryValue`/
`encodeOwnerOrRepo` plus ~20 dedicated builder functions (`apiContents`,
`apiRefHeads`, `apiRunsForBranch`, `apiWorkflowDispatches`, `apiJobLogs`,
etc.), replacing hand-built `"https://api.github.com/repos/$owner/$repo/..."`
strings everywhere. Fixes real breakage for branch names like `feature/test`
or `release/v2`, file paths with spaces/`#`/`?`/`%`/Unicode, swept across
`BuildFlowController`, `BuildRunMonitor`, `BuildLogViewer`, `BuildLogStreamer`,
`ArtifactMonitor`, `ArtifactBrowser`, `KeystoreController`, `WorkflowDispatcher`,
`RepoSwitcher`, `FileBrowserController`, `DownloadManager`. Zero raw
`api.github.com` string interpolation remains outside `GitHubApi.kt` itself
(verified by a project-wide grep).

## 3. Owner-cache invalidation on token change

`MainActivity` only cleared the cached owner (`lastOwner`) when the *repo*
field changed — not when the *token* changed, so pasting a different
account's token while keeping the same repo name silently kept using the
old account's resolved owner. Added a matching `TextWatcher` on `etToken`
that clears `lastOwner` and the token-scoped `lastFileSha` cache.

## 4. Unified upload pipeline

`FileUploadController` (Manage Files → Upload File) called
`GitHubApi.uploadStreamingBase64` directly with retry/progress/cancellation
all hardwired off — the one upload path in the app with none of the three.
Now routed through the same `UploadCoordinator.withUploadRetry` +
`uploadFileViaContentsApi` the build-ZIP upload already uses: same
exponential-backoff retry, same floating progress bubble, same
cancellation. Strict improvement — it had zero of these before.

## 5. Poll instead of blind sleep for repo readiness

`BuildFlowController.ensureRepo` waited a flat `Thread.sleep(4_000)` after
creating a repo. Now polls the repo's own existence endpoint (`BuildRetryManager`,
2s interval, 30s timeout) and only proceeds once GitHub actually reports it
reachable — faster when it's ready sooner, more reliable when it isn't ready
by 4s. `FileBrowserController.promptCreateRepo` had its own working version
of this same pattern already; it now shares the same `BuildRetryManager`
utility instead of a hand-rolled `for`-loop.

## 6. Concurrent download network-callback fix

`NetworkReliability` stored exactly one `ConnectivityManager.NetworkCallback`
in a single field. Two downloads pausing for connectivity at the same time
would silently overwrite each other's callback reference — the second
`waitForNetwork` call's completion would null out the field while the first
call's callback was still registered, leaking it and breaking `onDestroy`
cleanup for it. Replaced with a synchronized set tracking every concurrently
active callback independently.

## 7. Streaming build logs

`BuildLogViewer.fetchLogForRun` and `BuildLogStreamer.fetchAndLogFullLog`
both used to `.readText()` the entire raw log into one String before doing
anything with it — for a large multi-job Actions log (tens of MB), that's
held in memory for as long as the dialog stays open, on top of a second
cleaned/filtered copy for display. Both now stream line-by-line
(`Reader.useLines`, which closes the underlying stream). `BuildLogViewer`
keeps only a bounded ring buffer (last 1,500 cleaned lines — unchanged cap)
in memory and streams the full raw text straight to a small cache file
instead; "Copy All" reads that file back on demand rather than holding it
for the dialog's entire lifetime. The cache file is deleted the moment the
dialog closes via any path (Copy All / Tail Console / Close / back button),
with the cold-start sweep as a defensive fallback for a process kill
mid-view.

## 8. Better build-run matching

`BuildRunMonitor.waitForRun` matched by branch + a 15s creation-time grace
window — could attach to the wrong run if two builds were triggered close
together. `UploadCoordinator.uploadViaGitDataApi`/`uploadFileViaContentsApi`
now also return the new commit's SHA; `waitForRun` uses it as the primary
signal via GitHub's `head_sha` run filter (an exact match, not a heuristic),
falling back to the old timestamp/branch/status matching only when no
commit SHA is available (e.g. `KeystoreController`'s `workflow_dispatch` run,
which has no commit — `waitForRun` gained an `event` filter for this, reused
rather than duplicated).

## 9. ZIP validation logging

`DownloadIntegrity.verifyZipIntegrity` and `BuildUploadCoordinator.validateProjectZip`
silently returned false/null on any failure. Both now log a specific,
differentiated reason (corrupted/malformed ZIP vs. an unreadable source vs.
a generic I/O error vs. missing/empty file) before returning — still never
crashes, still handled gracefully, just no longer silent.

## 10. Download lifecycle

Covered by #1 (process-death survival) plus the pre-existing
`configChanges` manifest entry (Activity isn't recreated on rotation) and
the existing `hasActiveTask` dedup guard, which the restore path also
respects — verified rather than re-implemented.

## 11. Download Manager UI refresh overhead

The manager dialog rebuilt every row from scratch on a 400ms timer
regardless of whether anything changed. `renderDownloadRows` now compares a
cheap fingerprint (id/status/progress/speed/ETA/error per task) against the
last render and skips the rebuild entirely when nothing changed — an idle
dialog (e.g. every task already terminal) does no teardown/rebuild work on
most ticks. Explicit user actions (Clear Finished, initial open) always
force a render regardless.

## 12. Remaining `Thread.sleep` loops

- `DownloadEngine`'s pause-wait loop (`while (pauseRequested) Thread.sleep(150)`)
  now uses the shared `NetworkReliability.sleepCancellable` primitive instead
  of a bespoke spin loop — same responsiveness, one fewer hand-rolled wait.
- `KeystoreController`'s three separate loops (dispatch-retry, wait-for-run,
  poll-until-complete — the last one nearly a verbatim duplicate of
  `BuildRunMonitor.pollUntilComplete`, including a latent bug: it could
  break out on `status == "completed"` before `conclusion` was populated,
  producing an empty-conclusion error message) now reuse `BuildRetryManager`
  and `BuildRunMonitor` instead of three private copies. Two one-shot fixed
  delays (not loops) in `BuildFlowController` were left as-is — see
  `KNOWN_LIMITATIONS.md` note below.

## 13. Token expiration / rate limit detection

`GitHubApi.describeHttpError(code, body)` distinguishes an invalid/expired
token (401), an exhausted API rate limit (403 with GitHub's own "rate
limit" message text), a generic permissions problem (403), and "not found"
(404) instead of a bare status code. Wired into `BuildFlowController.fetchOwner`
— the single function every "is this token valid" check in the app already
funnels through — so every caller gets the improved message for free.

## 14. Memory cleanup

Covered throughout #1/#7/#9: every new stream uses `.use{}`/`useLines`
(which closes on every path including an exception), the log-streaming
rewrite in #7 is the main memory-usage win, and DownloadPersistence writes
are small and bounded (capped at 20 entries).

## 15. Code cleanup

- New `core/JsonPrefsList.kt` replaces two near-identical hand-rolled
  "capped JSON list in SharedPreferences" implementations in
  `DownloadHistory` and `BuildHistory`.
- `KeystoreController`'s ~90 lines of duplicated dispatch/poll logic now
  reuse `BuildRetryManager`/`BuildRunMonitor` (see #12).
- `GitHubApi`'s new builder functions remove duplicated URL-construction
  logic from ~10 files (see #2).

---

## New feature: choose which run's log to download

Previously "Download log ZIP" always fetched the *latest* run's log — no
way to grab an older one. `DownloadManager` gained `downloadRunLogs(token,
owner, repo, runId, runNum, status)`, sharing its actual submit logic with
the existing latest-run path via a new private `enqueueRunLogDownload`
helper (`downloadLatestRunLogs` now just resolves "the latest run" and
calls the same shared step). `BuildLogViewer`'s run-picker list (already
built for "View Log") gained a small per-row download icon button —
deliberately *not* a 4th button in the dialog's bottom action row, which
already has three and risks overflowing on narrower phones; a per-row icon
keeps the existing row layout and adds one small, independently-tappable
target instead. The original "Download latest log ZIP" quick-choice
untouched behaviorally, just relabeled for clarity now that there's a
second way to get there.

---

## Known limitations / deliberately out of scope

- `BuildFlowController.runFlow`'s two fixed delays (2s after committing the
  workflow file, 6s after a push before the first run-lookup poll) were left
  as one-shot delays, not converted to polling — they're not loops, and
  nothing in this app's build flow is cancellable while running, so there
  was no responsiveness/battery case being made worse by them.
- FileManager uploads and the build-ZIP upload still share one
  `UploadCoordinator.uploadCancelled` flag rather than a per-upload one — a
  narrow, pre-existing characteristic (not introduced by this pass) where a
  cancel tap during two simultaneous uploads could affect both. Unifying
  the pipeline (#4) makes this no worse than before — FileManager uploads
  previously had *no* cancellation at all. A true per-upload cancellation
  flag would be a reasonable follow-up but is a larger change than this
  pass's "not a feature redesign" mandate.

## Verification method

No local Android SDK/compiler is available in this environment. Every
edited/new file was checked for brace/paren/bracket balance after each
change (stripping strings and comments first) and cross-referenced for
signature consistency at every call site (constructor params, function
signatures, renamed/added arguments) — this catches the most common classes
of copy-paste and refactor errors, but is **not a substitute for actually
building the project**. Run a real Gradle build via ZipApkBuilder before
relying on this.
