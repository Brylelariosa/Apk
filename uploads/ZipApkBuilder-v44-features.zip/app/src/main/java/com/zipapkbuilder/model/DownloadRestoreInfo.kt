package com.zipapkbuilder.model

/**
 * The small, purely-data "recipe" for rebuilding a [DownloadTask]'s
 * `resolveUrl`/`onSuccess` closures after a process restart.
 *
 * A [DownloadTask] itself can't be serialized directly — its two most
 * important fields are behavior (lambdas: how to re-resolve a short-lived
 * signed URL, what to do with the finished file), not data. This is the
 * data half of that behavior: exactly what
 * [com.zipapkbuilder.feature.download.DownloadManager] needs to rebuild the
 * same lambdas it would have built if the download were starting fresh.
 * [com.zipapkbuilder.feature.download.DownloadPersistence] serializes this
 * (plus the task's progress/status) to SharedPreferences; on the next
 * app start, [com.zipapkbuilder.feature.download.DownloadManager] reads it
 * back and calls the exact same factory function
 * ([com.zipapkbuilder.feature.download.DownloadManager]'s
 * `buildArtifactTask`/`buildLogTask`) that a brand-new download of the same
 * kind would use — so there is exactly one place that knows how to build an
 * artifact or log [DownloadTask], not two (a "fresh" path and a "restored"
 * path).
 */
sealed class DownloadRestoreInfo {

    /** Restores an artifact-ZIP download. [downloadUrl] is the GitHub Actions
     *  artifact API URL (itself resolved to a short-lived signed URL fresh on
     *  every connection attempt — see [com.zipapkbuilder.feature.download.DownloadEngine]),
     *  not the signed URL itself, which would already have expired by restart. */
    data class Artifact(
        val downloadUrl: String,
        val zipFileName: String
    ) : DownloadRestoreInfo()

    /** Restores a build-log-ZIP download for a specific run. [runNum] is the
     *  human-readable run number (shown in messages) — kept distinct from
     *  [runId] (the internal id the API endpoints actually key on), same
     *  distinction GitHub itself draws between the two. */
    data class Log(
        val runId: Long,
        val runNum: Long,
        val owner: String,
        val repo: String,
        val zipFileName: String
    ) : DownloadRestoreInfo()
}
