package com.zipapkbuilder.feature.buildlog

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.LogText
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.core.iconButton
import com.zipapkbuilder.core.pillButton
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * In-app viewer for a GitHub Actions run's full log — [fetchAndShowWorkflowLog]
 * is the entry point (lists recent runs), [showLogDialog] renders whichever
 * one gets picked with error/warning highlighting and in-log search. This
 * fetches full logs on demand and holds nothing in memory afterward, unlike
 * [com.zipapkbuilder.feature.build.BuildFlowController]'s live streaming during
 * an active build.
 */
class BuildLogViewer(private val activity: MainActivity) {

    companion object {
        /** Cap on how many cleaned lines are kept in memory / shown at once —
         *  see [fetchLogForRun]'s kdoc. Full text remains available via "Copy All". */
        private const val MAX_TAIL_LINES = 1_500
    }

    /** Entry point — fetches all runs and shows a picker dialog. */
    fun fetchAndShowWorkflowLog() {
        val token = activity.etToken.text.toString().trim()
        val repo  = activity.etRepo.text.toString().trim()
        if (token.isEmpty()) { activity.appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { activity.appendLog("⚠ Enter a repository name first."); return }

        activity.setBusy(true)
        activity.appendLog("Fetching workflow runs from GitHub…")

        activity.bgExecutor.execute {
            try {
                // Resolve owner — use cached value or fetch from token (same pattern as
                // browseAllArtifacts / downloadLatestRunLogs)
                val owner = activity.lastOwner.ifEmpty {
                    (activity.buildFlowController.fetchOwner(token) ?: throw Exception(
                        "Could not verify token — check it has 'repo' scope."
                    )).also {
                        activity.lastOwner = it
                        activity.mainHandler.post { activity.tvOwnerInfo.text = "✓  @$it / $repo"; activity.tvOwnerInfo.visibility = android.view.View.VISIBLE }
                    }
                }

                val allRuns = mutableListOf<JSONObject>()
                // Fetch up to 3 pages × 30 = 90 runs (covers all recent history)
                for (page in 1..3) {
                    val url = "${GitHubApi.apiRuns(owner, repo)}?per_page=30&page=$page"
                    val (code, body) = GitHubApi.httpGet(token, url)
                    if (code != 200) break
                    val arr = JSONObject(body).getJSONArray("workflow_runs")
                    if (arr.length() == 0) break
                    for (i in 0 until arr.length()) allRuns.add(arr.getJSONObject(i))
                    if (arr.length() < 30) break
                }
                if (allRuns.isEmpty()) {
                    activity.appendLog("No workflow runs found in github.com/$owner/$repo")
                    activity.mainHandler.post { activity.setBusy(false) }
                    return@execute
                }
                activity.appendLog("Found ${allRuns.size} run(s) ✓")
                activity.mainHandler.post {
                    activity.setBusy(false)
                    if (activity.isFinishing || activity.isDestroyed) return@post
                    showRunPickerDialog(token, owner, repo, allRuns)
                }
            } catch (e: Exception) {
                activity.appendLog("✗ ${e.message}")
                activity.mainHandler.post { activity.setBusy(false) }
            }
        }
    }

    /**
     * Shows workflow runs with custom adapter for correct colors, + Trigger button.
     */
    private fun showRunPickerDialog(
        token: String, owner: String, repo: String,
        runs: List<JSONObject>
    ) {
        val dp    = activity.resources.displayMetrics.density
        val fmt   = SimpleDateFormat("MMM d, HH:mm", Locale.US)
        val fmtIn = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
        val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }

        // ── Custom title ──────────────────────────────────────────────────
        val titleRoot = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1C2038.toInt())
        }
        val topBar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((16*dp).toInt(), (12*dp).toInt(), (8*dp).toInt(), (8*dp).toInt())
        }
        val titleTv = TextView(activity).apply {
            text = "$owner / $repo"
            textSize = 14f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(0xFFE8EAED.toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val countBadge = TextView(activity).apply {
            text = " ${runs.size} runs "
            textSize = 10f
            setTextColor(0xFF00D4AA.toInt())
            setBackgroundColor(0xFF00251F.toInt())
            setPadding((8*dp).toInt(), (3*dp).toInt(), (8*dp).toInt(), (3*dp).toInt())
        }
        topBar.addView(titleTv); topBar.addView(countBadge)
        titleRoot.addView(topBar)

        titleRoot.addView(TextView(activity).apply {
            text = "Tap a run to select it, or ⬇ to download its log directly"
            textSize = 10f
            setTextColor(0xFF6B7195.toInt())
            setPadding((16*dp).toInt(), 0, (16*dp).toInt(), (6*dp).toInt())
        })

        // ── Status filter chips ────────────────────────────────────────────
        // Declared here (needs runInfos/filteredIndices/adapter, all built below) —
        // filled in and attached after those exist; see the block right after the
        // adapter is defined.
        val filterRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding((14*dp).toInt(), 0, (14*dp).toInt(), (8*dp).toInt())
        }
        titleRoot.addView(filterRow)

        titleRoot.addView(android.view.View(activity).apply {
            setBackgroundColor(0xFF232747.toInt())
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1)
        })

        // ── Custom adapter ────────────────────────────────────────────────
        data class RunInfo(val runNum: Long, val name: String, val icon: String,
                           val dateStr: String, val statusStr: String, val conclusion: String)
        val runInfos = runs.map { run ->
            val runNum     = run.optLong("run_number", 0L)
            val name       = run.optString("name", "build")
            val status     = run.optString("status", "")
            val conc       = run.optString("conclusion", "")
            val createdRaw = run.optString("created_at", "")
            val dateStr    = if (createdRaw.isNotEmpty()) {
                try { fmt.format(fmtIn.parse(createdRaw)!!) } catch (_: Exception) { "" }
            } else ""
            val icon = when (conc) {
                "success"   -> "✓"
                "failure"   -> "✗"
                "cancelled" -> "✗"
                "skipped"   -> "–"
                else        -> if (status == "in_progress") "●" else "○"
            }
            val statusStr = if (conc.isNotEmpty()) conc else status
            RunInfo(runNum, name, icon, dateStr, statusStr, conc)
        }

        var selectedIndex = -1
        // Indices into runInfos/runs that are currently shown — separate from
        // position-in-the-list once the status filter chips (below) can hide some
        // entries, the same reasoning as the File Manager's search filteredItems.
        val filteredIndices = runInfos.indices.toMutableList()
        val listView = android.widget.ListView(activity).apply {
            setBackgroundColor(0xFF13162A.toInt())
            divider = android.graphics.drawable.ColorDrawable(0xFF1C2038.toInt())
            dividerHeight = 1
        }
        val adapter = object : android.widget.BaseAdapter() {
            override fun getCount() = filteredIndices.size
            override fun getItem(pos: Int) = runInfos[filteredIndices[pos]]
            override fun getItemId(pos: Int) = pos.toLong()
            override fun getView(pos: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val info = runInfos[filteredIndices[pos]]
                val isSelected = (pos == selectedIndex)
                val bgColor = when {
                    isSelected               -> 0xFF221F4A.toInt()
                    info.conclusion == "failure" -> 0xFF1A0000.toInt()
                    info.conclusion == "success" -> 0xFF001A0D.toInt()
                    else -> 0xFF13162A.toInt()
                }
                val row = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setBackgroundColor(bgColor)
                    setPadding((14*dp).toInt(), (12*dp).toInt(), (12*dp).toInt(), (12*dp).toInt())
                }
                val iconTv = TextView(parent.context).apply {
                    text = info.icon
                    textSize = 18f
                    setTypeface(null, android.graphics.Typeface.BOLD)
                    setTextColor(when (info.conclusion) {
                        "success"            -> 0xFF2ECC71.toInt()
                        "failure", "cancelled" -> 0xFFFF6B6B.toInt()
                        else -> if (info.statusStr == "in_progress") 0xFFF5A623.toInt() else 0xFF50587A.toInt()
                    })
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).also { it.marginEnd = (12*dp).toInt() }
                }
                val col = LinearLayout(parent.context).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                }
                val runNumTv = TextView(parent.context).apply {
                    text = "Run #${info.runNum}  ·  ${info.name}"
                    textSize = 13f
                    setTextColor(0xFFE8EAED.toInt())
                    setTypeface(null, android.graphics.Typeface.BOLD)
                }
                val metaTv = TextView(parent.context).apply {
                    text = buildString {
                        if (info.dateStr.isNotEmpty()) append(info.dateStr)
                        if (info.statusStr.isNotEmpty()) append("  ·  ${info.statusStr}")
                    }
                    textSize = 10.5f
                    setTextColor(when (info.conclusion) {
                        "success"  -> 0xFF2ECC71.toInt()
                        "failure"  -> 0xFFFF6B6B.toInt()
                        else       -> 0xFF50587A.toInt()
                    })
                }
                col.addView(runNumTv); col.addView(metaTv)
                row.addView(iconTv); row.addView(col)
                // Direct per-row "download this run's log" action — lets the user grab
                // any run's log ZIP straight from the list without first selecting it
                // and going through "View Log", and without crowding the dialog's
                // bottom action row (which already has View Log/Trigger/Refresh) with
                // a fourth button that risks overflowing on narrower phone screens.
                row.addView(parent.context.iconButton(R.drawable.ic_download, 0xFF2ECC71.toInt(), sizeDp = 16, paddingDp = 8) {
                    val run    = runs[filteredIndices[pos]]
                    val runId  = run.getLong("id")
                    val runNum = run.optLong("run_number", runId)
                    val status = run.optString("status", "")
                    activity.withStoragePermission {
                        activity.downloadManager.downloadRunLogs(token, owner, repo, runId, runNum, status, Formatters.extractZipNameFromRun(run))
                    }
                })
                return row
            }
        }
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, pos, _ ->
            selectedIndex = pos
            adapter.notifyDataSetChanged()
        }

        fun applyRunFilter(conclusion: String?) {
            filteredIndices.clear()
            filteredIndices.addAll(
                runInfos.indices.filter { conclusion == null || runInfos[it].conclusion == conclusion }
            )
            selectedIndex = -1 // positions shift under a new filter — no longer meaningful
            adapter.notifyDataSetChanged()
        }
        fun filterChip(label: String, conclusion: String?, tone: ButtonTone, iconRes: Int? = null) =
            activity.pillButton(label, tone, iconRes, textSizeSp = 10.5f, iconSizeDp = 12,
                horizontalPaddingDp = 10, verticalPaddingDp = 6) { applyRunFilter(conclusion) }
        val chipAll     = filterChip("All", null, ButtonTone.SURFACE)
        val chipSuccess = filterChip("Success", "success", ButtonTone.GREEN, R.drawable.ic_check)
        val chipFailed  = filterChip("Failed", "failure", ButtonTone.RED, R.drawable.ic_close)
        for (chip in listOf(chipAll, chipSuccess)) {
            chip.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = (6*dp).toInt() }
        }
        filterRow.addView(chipAll); filterRow.addView(chipSuccess); filterRow.addView(chipFailed)

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF13162A.toInt())
        }
        // titleRoot is passed to setCustomTitle below — do NOT also addView it here
        val maxH = (activity.resources.displayMetrics.heightPixels * 0.58f).toInt()
        root.addView(android.widget.FrameLayout(activity).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, maxH)
            addView(listView)
        })

        lateinit var dlg: AlertDialog
        val content = activity.dialogWithActions(
            root,
            DialogAction("View Log", ButtonTone.BLUE, R.drawable.ic_log) {
                if (selectedIndex < 0) {
                    activity.appendLog("⚠ Tap a run to select it first.")
                } else {
                    val run    = runs[filteredIndices[selectedIndex]]
                    val runId  = run.getLong("id")
                    val runNum = run.optLong("run_number", runId)
                    dlg.dismiss()
                    activity.setBusy(true)
                    activity.appendLog("Fetching log for run #$runNum…")
                    activity.bgExecutor.execute { fetchLogForRun(token, owner, repo, runId, runNum) }
                }
            },
            DialogAction("Trigger", ButtonTone.ORANGE, R.drawable.ic_flash) {
                dlg.dismiss()
                activity.buildFlowController.triggerWorkflowDispatch(token, owner, repo, branch)
            },
            DialogAction("Refresh", ButtonTone.SURFACE, R.drawable.ic_refresh) {
                dlg.dismiss(); fetchAndShowWorkflowLog()
            }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setCustomTitle(titleRoot)
            .setView(content)
            .show()
    }

    /**
     * Fetches the log text for a specific run and shows it in [showLogDialog].
     *
     * Streams each job's log line-by-line ([streamJobLogLines]) instead of
     * reading the whole thing into one String first — a large multi-job
     * GitHub Actions log can run tens of MB, and the old `readText()`
     * approach held the complete raw text in memory for as long as the log
     * dialog stayed open, on top of the cleaned/filtered copy built for
     * display. Here, only a bounded ring buffer of the most recent
     * [MAX_TAIL_LINES] cleaned lines is kept in memory (exactly what the
     * dialog can show anyway); the full raw text is streamed straight to a
     * small cache file instead, which "Copy All" reads back on demand — so
     * memory use stays flat regardless of how large the actual log is, and
     * "Copy All" still returns the complete, untruncated log.
     */
    private fun fetchLogForRun(token: String, owner: String, repo: String, runId: Long, runNum: Long) {
        val cacheFile = File(activity.cacheDir, "viewlog_${runId}.txt")
        var totalBytes = 0L
        var cleanedLineCount = 0
        val tailBuffer = ArrayDeque<String>(MAX_TAIL_LINES + 1)

        fun appendTail(line: String) {
            cleanedLineCount++
            if (tailBuffer.size >= MAX_TAIL_LINES) tailBuffer.removeFirst()
            tailBuffer.addLast(line)
        }

        try {
            val (jobsCode, jobsBody) = GitHubApi.httpGet(token, GitHubApi.apiRunJobs(owner, repo, runId))
            if (jobsCode != 200) throw Exception("Could not fetch jobs — ${GitHubApi.describeHttpError(jobsCode, jobsBody)}")
            val jobsArr = JSONObject(jobsBody).optJSONArray("jobs")
                ?: throw Exception("No jobs array for run #$runNum")
            if (jobsArr.length() == 0) throw Exception("No jobs found for run #$runNum")

            cacheFile.bufferedWriter().use { cacheOut ->
                fun writeLine(line: String) {
                    cacheOut.write(line); cacheOut.write("\n")
                    totalBytes += line.length + 1
                }
                // Show all jobs in the run, not just the first one
                for (ji in 0 until jobsArr.length()) {
                    val job     = jobsArr.getJSONObject(ji)
                    val jobId   = job.getLong("id")
                    val jobName = job.optString("name", "job-$ji")
                    activity.appendLog("Loading log for job '$jobName'…")

                    if (jobsArr.length() > 1) {
                        val header = "══════ JOB: $jobName ══════"
                        writeLine(header)
                        appendTail(header)
                    }

                    val error = streamJobLogLines(token, owner, repo, jobId) { rawLine ->
                        writeLine(rawLine)
                        val cleaned = LogText.cleanLine(rawLine)
                        if (!LogText.isGroupMarker(cleaned)) appendTail(cleaned)
                    }
                    if (error != null) {
                        writeLine(error)
                        appendTail(error)
                    }
                }
            }

            activity.appendLog("✓ Log: ${Formatters.fmtBytes(totalBytes)}, $cleanedLineCount lines")
            activity.mainHandler.post {
                if (activity.isFinishing || activity.isDestroyed) { cacheFile.delete(); return@post }
                showLogDialog(cacheFile, totalBytes, cleanedLineCount, tailBuffer.toList(), runNum)
            }
        } catch (e: Exception) {
            activity.appendLog("✗ Log error: ${e.message}")
            cacheFile.delete()
        } finally {
            activity.setBusy(false)
        }
    }

    /**
     * Streams one job's raw log line-by-line via [onLine] rather than reading
     * it into one String first (see [fetchLogForRun]'s kdoc). Follows at most
     * one redirect hop, matching GitHub's actual "redirect to blob storage"
     * pattern for job logs. Every stream opened here — the reader itself
     * (via [kotlin.text.useLines], which closes it) and the connection — is
     * released before returning, on every path including an exception.
     * Returns null on success, or a short message to show in place of the
     * log if it couldn't be fetched (expired, run still in progress, etc.).
     */
    private fun streamJobLogLines(token: String, owner: String, repo: String, jobId: Long, onLine: (String) -> Unit): String? {
        val conn1 = (URL(GitHubApi.apiJobLogs(owner, repo, jobId)).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            instanceFollowRedirects = false
            connectTimeout = 30_000; readTimeout = 120_000
        }
        return try {
            when (val code = conn1.responseCode) {
                in 301..308 -> {
                    val loc = conn1.getHeaderField("Location")
                    conn1.disconnect()
                    if (loc == null) return "⚠ Log not available (no redirect target)."
                    val c2 = (URL(loc).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"; connectTimeout = 30_000; readTimeout = 120_000
                    }
                    try {
                        if (c2.responseCode == 200) {
                            c2.inputStream.reader().useLines { lines -> lines.forEach(onLine) }
                            null
                        } else {
                            "⚠ HTTP ${c2.responseCode} — log not available."
                        }
                    } finally { c2.disconnect() }
                }
                200 -> {
                    try {
                        conn1.inputStream.reader().useLines { lines -> lines.forEach(onLine) }
                        null
                    } finally { conn1.disconnect() }
                }
                410 -> { conn1.disconnect(); "⚠ Log expired or unavailable for this run." }
                else -> { conn1.disconnect(); "⚠ HTTP $code — log not available." }
            }
        } catch (e: Exception) {
            try { conn1.disconnect() } catch (_: Exception) {}
            "⚠ ${Formatters.friendlyError(e)}"
        }
    }

    /**
     * Renders the log. [tailLines] is already the bounded, cleaned tail
     * [fetchLogForRun] built (≤[MAX_TAIL_LINES] lines) — this no longer
     * re-derives it from a full in-memory string. [cacheFile] holds the
     * complete raw log on disk for "Copy All"; it's read back into memory
     * only at the moment the user actually taps that button, and deleted
     * once this dialog is done with it either way (Copy All, Tail Console,
     * or Close) so it never lingers past this one viewing session.
     */
    private fun showLogDialog(cacheFile: File, totalBytes: Long, cleanedLineCount: Int, tailLines: List<String>, runId: Long) {
        val truncated = cleanedLineCount > tailLines.size
        val sizeStr = Formatters.fmtBytes(totalBytes)

        val header = buildString {
            append("Run #$runId   •   $sizeStr   •   $cleanedLineCount lines\n")
            if (truncated) append("Showing last ${tailLines.size} lines — tap Copy All for full log\n")
            append("─────────────────────────────────────\n")
        }

        val errorRx = Regex("""(?i)\b(error|failed|failure|exception)\b|##\[error]""")
        val warnRx  = Regex("""(?i)\bwarning\b|##\[warning]|\bdeprecated\b""")

        // Build display the same way Browse Artifacts does — styled TextView in a dark card,
        // but as a SpannableStringBuilder so error/warning lines and search hits can both be
        // colored — a plain String (the old approach) can't carry spans at all.
        val ctx = activity
        val body = android.text.SpannableStringBuilder()
        body.append(header)
        val lineErrorOffsets = mutableListOf<Int>() // start offset of each error line, for "jump to first error"
        tailLines.forEach { line ->
            val start = body.length
            body.append(line).append("\n")
            val color = when {
                errorRx.containsMatchIn(line) -> 0xFFFF6B6B.toInt().also { lineErrorOffsets.add(start) }
                warnRx.containsMatchIn(line)  -> 0xFFF5A623.toInt()
                else -> null
            }
            if (color != null) {
                body.setSpan(android.text.style.ForegroundColorSpan(color), start, body.length,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }

        val sv  = ScrollView(ctx)
        sv.setBackgroundColor(0xFF0D0D0D.toInt())
        val tv = TextView(ctx).apply {
            setText(body, TextView.BufferType.SPANNABLE)
            textSize = 9.5f
            setTextColor(0xFF00E676.toInt())   // same green as console log — default for uncolored lines
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(24, 24, 24, 24)
            setLineSpacing(0f, 1.25f)
        }
        sv.addView(tv)
        sv.post { sv.fullScroll(ScrollView.FOCUS_DOWN) }

        // ── Search bar: find in log, next/prev match, jump to first error ──
        // Search runs over the same bounded tail already on screen, exactly as
        // before — it was never searching the full untruncated text even when
        // that was held in memory, since body.toString() was always built from
        // the truncated `cleaned` list either way.
        val dp = activity.resources.displayMetrics.density
        val searchMatches = mutableListOf<Int>()
        var currentMatch = -1
        var searchSpans: List<Any> = emptyList()

        fun clearSearchHighlights() {
            val editable = tv.text as? android.text.Spannable ?: return
            for (span in searchSpans) editable.removeSpan(span)
            searchSpans = emptyList()
        }
        fun scrollToOffset(offset: Int) {
            val layout = tv.layout ?: return
            val line = layout.getLineForOffset(offset)
            sv.post { sv.scrollTo(0, layout.getLineTop(line)) }
        }
        val tvMatchCount = TextView(ctx).apply {
            text = ""; textSize = 10.5f; setTextColor(0xFF9AA0B8.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8*dp).toInt(), 0, (8*dp).toInt(), 0)
        }
        fun runSearch(query: String) {
            clearSearchHighlights()
            searchMatches.clear(); currentMatch = -1
            if (query.isEmpty()) { tvMatchCount.text = ""; return }
            val text = body.toString()
            var idx = text.indexOf(query, 0, ignoreCase = true)
            while (idx >= 0) { searchMatches.add(idx); idx = text.indexOf(query, idx + 1, ignoreCase = true) }
            if (searchMatches.isEmpty()) { tvMatchCount.text = "0/0"; return }
            val editable = tv.text as android.text.Spannable
            searchSpans = searchMatches.map { pos ->
                android.text.style.BackgroundColorSpan(0xFF5A4E1F.toInt()).also {
                    editable.setSpan(it, pos, pos + query.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            }
            currentMatch = 0
            tvMatchCount.text = "1/${searchMatches.size}"
            scrollToOffset(searchMatches[0])
        }
        val etSearch = EditText(ctx).apply {
            hint = "Find in log…"; textSize = 11f; isSingleLine = true
            setTextColor(0xFFE8EAED.toInt()); setHintTextColor(0xFF50587A.toInt())
            setBackgroundColor(0xFF161B22.toInt())
            setPadding((10*dp).toInt(), (6*dp).toInt(), (10*dp).toInt(), (6*dp).toInt())
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: android.text.Editable?) { runSearch(s?.toString() ?: "") }
            })
        }
        val searchBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0xFF161B22.toInt())
            addView(etSearch); addView(tvMatchCount)
            addView(ctx.iconButton(R.drawable.ic_chevron_left, 0xFF9AA0B8.toInt(), sizeDp = 16, paddingDp = 6) {
                if (searchMatches.isEmpty()) return@iconButton
                currentMatch = (currentMatch - 1 + searchMatches.size) % searchMatches.size
                tvMatchCount.text = "${currentMatch + 1}/${searchMatches.size}"
                scrollToOffset(searchMatches[currentMatch])
            })
            addView(ctx.iconButton(R.drawable.ic_chevron_right, 0xFF9AA0B8.toInt(), sizeDp = 16, paddingDp = 6) {
                if (searchMatches.isEmpty()) return@iconButton
                currentMatch = (currentMatch + 1) % searchMatches.size
                tvMatchCount.text = "${currentMatch + 1}/${searchMatches.size}"
                scrollToOffset(searchMatches[currentMatch])
            })
            addView(ctx.iconButton(R.drawable.ic_warning, 0xFFFF6B6B.toInt(), sizeDp = 16, paddingDp = 6) {
                if (lineErrorOffsets.isEmpty()) { activity.appendLog("ℹ No error-looking lines found in this log."); return@iconButton }
                scrollToOffset(lineErrorOffsets.first())
            })
        }

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(searchBar)
            addView(sv)
        }

        lateinit var dlg: AlertDialog
        val content = activity.dialogWithActions(
            root,
            DialogAction("Copy All", ButtonTone.BLUE, R.drawable.ic_copy) {
                dlg.dismiss()
                try {
                    val fullText = cacheFile.readText()
                    (activity.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("Build Log", fullText))
                    activity.appendLog("✓ Full log copied ($sizeStr).")
                } catch (e: Exception) {
                    activity.appendLog("✗ Could not read full log for copy: ${e.message}")
                } finally {
                    cacheFile.delete()
                }
            },
            DialogAction("Tail Console", ButtonTone.SURFACE, R.drawable.ic_terminal) {
                dlg.dismiss()
                activity.appendLog("=== Log Run #$runId ===")
                tailLines.takeLast(60).forEach { activity.appendLog(it) }
                activity.appendLog("=== End ===")
                cacheFile.delete()
            },
            DialogAction("Close", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss(); cacheFile.delete() }
        )
        dlg = AlertDialog.Builder(ctx, R.style.Theme_App_Dialog)
            .setTitle("Build Log — Run #$runId")
            .setView(content)
            .setOnCancelListener { cacheFile.delete() } // dismissed via back button/outside tap
            .show()
    }
}
