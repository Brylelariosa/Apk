package com.zipapkbuilder.feature.filemanager

import android.app.AlertDialog
import android.widget.EditText
import android.widget.LinearLayout
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.IconMenuAdapter
import com.zipapkbuilder.core.IconMenuRow
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.core.styleButton
import com.zipapkbuilder.model.RepoItem
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONArray
import org.json.JSONObject

/**
 * Every mutating repo-file operation — create file/folder, rename/move,
 * delete (single or multi-select, including recursive folder delete) — and
 * the dialogs that prompt for them. Split out of [FileManagerController] to
 * isolate "make a change to the repo" from browsing and editing.
 *
 * [refreshBrowser] re-opens the browser dialog at a given path once an
 * operation completes — passed in rather than depending on
 * [FileBrowserController] directly, since that class in turn depends on this
 * one for its "New"/"Delete" actions and per-item Move/Delete menu entries; a
 * plain callback avoids a circular class reference between the two.
 */
class FileOperationController(
    private val activity: MainActivity,
    private val refreshBrowser: (token: String, owner: String, repo: String, branch: String, path: String) -> Unit
) {

    // ── Create ───────────────────────────────────────────────────────────────

    /** Sub-menu: create a folder or a file, or upload a local one. */
    fun showNewItemDialog(token: String, owner: String, repo: String, branch: String, currentPath: String) {
        val newItemRows = listOf(
            IconMenuRow("New Folder",  R.drawable.ic_folder, 0xFFFF9F43.toInt()),
            IconMenuRow("New File",    R.drawable.ic_file,   0xFF2ECC71.toInt()),
            IconMenuRow("Upload File", R.drawable.ic_upload, 0xFF4DA6FF.toInt())
        )
        AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("Create New…")
            .setAdapter(IconMenuAdapter(activity, newItemRows)) { _, which ->
                when (which) {
                    0 -> promptCreateFolder(token, owner, repo, branch, currentPath)
                    1 -> promptCreateFile(token, owner, repo, branch, currentPath)
                    2 -> {
                        // Store context so the activity-result callback knows where to upload
                        activity.pendingUploadToken  = token
                        activity.pendingUploadOwner  = owner
                        activity.pendingUploadRepo   = repo
                        activity.pendingUploadBranch = branch
                        activity.pendingUploadPath   = currentPath
                        activity.pickUploadFile.launch(arrayOf("*/*"))
                    }
                }
            }
            .show()
    }

    private fun promptCreateFolder(token: String, owner: String, repo: String, branch: String, parentPath: String) {
        val input = EditText(activity).apply {
            hint = "folder-name"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(64, 24, 64, 24)
        }
        lateinit var dlg: AlertDialog
        val body = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(activity.dialogMessage("A .gitkeep file will be placed inside\n(GitHub doesn't allow empty folders)."))
            addView(input)
        }
        val content = activity.dialogWithActions(
            body,
            DialogAction("Create", ButtonTone.GREEN, R.drawable.ic_add) {
                val name = input.text.toString().trim()
                if (name.isEmpty()) {
                    activity.appendLog("⚠ Folder name cannot be empty.")
                } else {
                    dlg.dismiss()
                    val filePath = if (parentPath.isEmpty()) "$name/.gitkeep" else "$parentPath/$name/.gitkeep"
                    activity.setBusy(true)
                    activity.bgExecutor.execute { createRepoFile(token, owner, repo, branch, filePath, "", parentPath) }
                }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("📁 New Folder")
            .setView(content)
            .show()
    }

    private fun promptCreateFile(token: String, owner: String, repo: String, branch: String, parentPath: String) {
        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 16, 64, 8)
        }
        val etName = EditText(activity).apply {
            hint = "filename.txt"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        val etContent = EditText(activity).apply {
            hint = "File content (optional)"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
        container.addView(etName)
        container.addView(etContent)

        lateinit var dlg: AlertDialog
        val content = activity.dialogWithActions(
            container,
            DialogAction("Create", ButtonTone.GREEN, R.drawable.ic_add) {
                val name    = etName.text.toString().trim()
                val fileContent = etContent.text.toString()
                if (name.isEmpty()) {
                    activity.appendLog("⚠ File name cannot be empty.")
                } else {
                    dlg.dismiss()
                    val filePath = if (parentPath.isEmpty()) name else "$parentPath/$name"
                    activity.setBusy(true)
                    activity.bgExecutor.execute { createRepoFile(token, owner, repo, branch, filePath, fileContent, parentPath) }
                }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("📄 New File")
            .setView(content)
            .show()
    }

    private fun createRepoFile(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, content: String, refreshPath: String
    ) {
        try {
            val encoded = android.util.Base64.encodeToString(content.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
            val payload = JSONObject().apply {
                put("message", "chore: create $filePath via ZipApkBuilder [skip ci]")
                put("content", encoded)
                put("branch",  branch)
            }.toString()
            val (code, body) = GitHubApi.httpPut(token, GitHubApi.apiContents(owner, repo, filePath), payload)
            if (code in 200..201) {
                activity.appendLog("✓ Created: $filePath")
                activity.mainHandler.post { refreshBrowser(token, owner, repo, branch, refreshPath) }
            } else {
                activity.appendLog("✗ Create failed ($code): ${body.take(150)}")
                activity.setBusy(false)
            }
        } catch (e: Exception) {
            activity.appendLog("✗ ${e.message}")
            activity.setBusy(false)
        }
    }

    // ── Move / Rename ────────────────────────────────────────────────────────

    /** Prompts for a new path for [item] (the "Move / Rename" entry in the
     *  per-item action menu) and performs the move on confirm. */
    fun promptMoveFile(token: String, owner: String, repo: String, branch: String, item: RepoItem, currentPath: String) {
        val input = EditText(activity).apply {
            setText(item.path)
            hint = "new/path/filename.ext"
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            setPadding(64, 24, 64, 24)
            setSelection(text.length)
        }
        lateinit var moveDlg: AlertDialog
        val moveBody = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(activity.dialogMessage("Enter the new path for this file:"))
            addView(input)
        }
        val moveContent = activity.dialogWithActions(
            moveBody,
            DialogAction("Move", ButtonTone.TEAL, R.drawable.ic_edit) {
                val newPath = input.text.toString().trim().trimStart('/')
                if (newPath.isEmpty() || newPath == item.path) {
                    activity.appendLog("⚠ Path unchanged.")
                } else {
                    moveDlg.dismiss()
                    activity.setBusy(true)
                    activity.bgExecutor.execute { moveRepoFile(token, owner, repo, branch, item, newPath, currentPath) }
                }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { moveDlg.dismiss() }
        )
        moveDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("Move / Rename").setView(moveContent).show()
    }

    /**
     * Moves/renames a file by reading its content, creating it at [newPath],
     * then deleting the original. Refreshes the browser at [refreshPath] when done.
     */
    private fun moveRepoFile(
        token: String, owner: String, repo: String, branch: String,
        item: RepoItem, newPath: String, refreshPath: String
    ) {
        try {
            activity.appendLog("Moving ${item.name} → $newPath …")

            // 1. Read current file content (base64) from GitHub
            val (getCode, getBody) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path))
            if (getCode != 200) throw Exception("Could not read file ($getCode)")
            val encodedContent = JSONObject(getBody).getString("content")
                .replace("\n", "").replace("\r", "") // GitHub wraps base64 at 60 chars

            // 2. Create file at new path
            val createPayload = JSONObject().apply {
                put("message", "chore: move ${item.path} → $newPath via ZipApkBuilder [skip ci]")
                put("content", encodedContent)
                put("branch",  branch)
            }.toString()
            val (putCode, putBody) = GitHubApi.httpPut(token, GitHubApi.apiContents(owner, repo, newPath), createPayload)
            if (putCode !in 200..201) throw Exception("Could not create at $newPath ($putCode): ${putBody.take(150)}")

            // 3. Delete original
            val deletePayload = JSONObject().apply {
                put("message", "chore: remove ${item.path} after move [skip ci]")
                put("sha",     item.sha)
                put("branch",  branch)
            }.toString()
            val (delCode, delBody) = GitHubApi.httpDelete(token, GitHubApi.apiContents(owner, repo, item.path), deletePayload)
            if (delCode !in 200..204) throw Exception("Moved but failed to delete original ($delCode): ${delBody.take(150)}")

            activity.appendLog("✓ Moved to: $newPath")
            if (item.path == activity.lastRemotePath) activity.lastRemotePath = newPath

            activity.mainHandler.post { refreshBrowser(token, owner, repo, branch, refreshPath) }
        } catch (e: Exception) {
            activity.appendLog("✗ Move failed: ${e.message}")
        } finally {
            activity.setBusy(false)
        }
    }

    // ── Delete ───────────────────────────────────────────────────────────────

    /** Confirms and deletes a single [item] (the "Delete" entry in the
     *  per-item action menu). For multi-select delete, see [showDeleteDialog]. */
    fun promptDeleteFile(token: String, owner: String, repo: String, branch: String, item: RepoItem, currentPath: String) {
        lateinit var delDlg: AlertDialog
        val delContent = activity.dialogWithActions(
            activity.dialogMessage("Delete from repo?\n\n• ${item.name}"),
            DialogAction("Delete", ButtonTone.RED, R.drawable.ic_delete) {
                delDlg.dismiss()
                activity.setBusy(true)
                activity.bgExecutor.execute {
                    deleteRepoFile(token, owner, repo, branch, item.path, item.sha, item.name)
                    activity.setBusy(false)
                    activity.mainHandler.post { refreshBrowser(token, owner, repo, branch, currentPath) }
                }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { delDlg.dismiss() }
        )
        delDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("Confirm Delete").setView(delContent).show()
    }

    /** Multi-select delete dialog. `setMultiChoiceItems` can't be combined with a custom
     *  `setView()` body, so this outer picker keeps the platform button bar (styleButton) —
     *  the nested confirm step below uses the newer dialogWithActions like everything else. */
    fun showDeleteDialog(
        token: String, owner: String, repo: String, branch: String,
        currentPath: String, items: List<RepoItem>
    ) {
        val names   = items.map { if (it.type == "dir") "📁  ${it.name}" else "📄  ${it.name}" }.toTypedArray()
        val checked = BooleanArray(items.size)
        var allSelected = false
        lateinit var listDlg: AlertDialog
        listDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("🗑️  Select to Delete")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Delete Selected") { _, _ ->
                val toDelete = items.filterIndexed { i, _ -> checked[i] }
                if (toDelete.isEmpty()) { activity.appendLog("Nothing selected."); return@setPositiveButton }
                val hasFolders = toDelete.any { it.type == "dir" }
                val list = toDelete.joinToString("\n• ", prefix = "• ") {
                    "${if (it.type == "dir") "📁" else "📄"} ${it.name}"
                }
                val warning = if (hasFolders) "\n\n⚠ Folders will be deleted recursively." else ""
                lateinit var confirmDlg: AlertDialog
                val confirmContent = activity.dialogWithActions(
                    activity.dialogMessage("Delete ${toDelete.size} item(s)?$warning\n\n$list"),
                    DialogAction("Delete", ButtonTone.RED, R.drawable.ic_delete) {
                        confirmDlg.dismiss()
                        activity.setBusy(true)
                        activity.bgExecutor.execute { deleteItemsRecursive(token, owner, repo, branch, toDelete, currentPath) }
                    },
                    DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { confirmDlg.dismiss() }
                )
                confirmDlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                    .setTitle("Confirm Deletion").setView(confirmContent).show()
            }
            .setNegativeButton("Cancel", null)
            // Overridden below (not left as the default null/dismiss action) so tapping it
            // toggles selection without closing the list — a plain setNeutralButton listener
            // dismisses the dialog on tap same as positive/negative, which isn't what a
            // Select All toggle should do.
            .setNeutralButton("Select All", null)
            .show()
        listDlg.styleButton(activity, AlertDialog.BUTTON_POSITIVE, ButtonTone.RED, R.drawable.ic_delete)
        listDlg.styleButton(activity, AlertDialog.BUTTON_NEGATIVE, ButtonTone.SURFACE, R.drawable.ic_close)
        listDlg.styleButton(activity, AlertDialog.BUTTON_NEUTRAL, ButtonTone.SURFACE, R.drawable.ic_check)
        listDlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            allSelected = !allSelected
            for (i in checked.indices) {
                checked[i] = allSelected
                listDlg.listView.setItemChecked(i, allSelected)
            }
            listDlg.getButton(AlertDialog.BUTTON_NEUTRAL).text = if (allSelected) "Deselect All" else "Select All"
        }
    }

    private fun deleteItemsRecursive(
        token: String, owner: String, repo: String, branch: String,
        items: List<RepoItem>, refreshPath: String
    ) {
        // Each item is attempted independently — one folder failing to list (or any
        // other error) used to abort the whole batch via a shared try/catch, silently
        // skipping every remaining selected item with no indication of what happened.
        var failed = 0
        for (item in items) {
            try {
                if (item.type == "file") {
                    deleteRepoFile(token, owner, repo, branch, item.path, item.sha, item.name)
                } else {
                    deleteFolderRecursive(token, owner, repo, branch, item.path)
                }
            } catch (e: Exception) {
                failed++
                activity.appendLog("✗ ${item.name}: ${e.message}")
            }
        }
        if (items.size > 1) {
            val ok = items.size - failed
            activity.appendLog(if (failed == 0) "✓ Deleted all $ok item(s)." else "⚠ Deleted $ok item(s), $failed failed.")
        }
        activity.mainHandler.post { refreshBrowser(token, owner, repo, branch, refreshPath) }
    }

    /** Recursively lists and deletes every file inside a folder. */
    private fun deleteFolderRecursive(token: String, owner: String, repo: String, branch: String, path: String) {
        activity.appendLog("📁 Deleting folder: $path …")
        val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, path))
        if (code == 404) { activity.appendLog("  (already gone)"); return }
        if (code != 200) throw Exception("HTTP $code listing $path")
        val arr = JSONArray(body)
        for (i in 0 until arr.length()) {
            val obj  = arr.getJSONObject(i)
            val type = obj.getString("type")
            val childPath = obj.getString("path")
            val childSha  = obj.optString("sha", "")
            val childName = obj.getString("name")
            if (type == "dir") deleteFolderRecursive(token, owner, repo, branch, childPath)
            else deleteRepoFile(token, owner, repo, branch, childPath, childSha, childName)
        }
    }

    private fun deleteRepoFile(
        token: String, owner: String, repo: String, branch: String,
        path: String, sha: String, name: String
    ) {
        val payload = JSONObject().apply {
            put("message", "chore: delete $path via ZipApkBuilder [skip ci]")
            put("sha",     sha)
            put("branch",  branch)
        }.toString()
        val (code, resp) = GitHubApi.httpDelete(token, GitHubApi.apiContents(owner, repo, path), payload)
        if (code in 200..204) {
            activity.appendLog("✓ Deleted: $name")
            if (path == activity.lastRemotePath) activity.lastFileSha = null
        } else {
            activity.appendLog("✗ Failed to delete $name ($code): ${resp.take(120)}")
        }
    }
}
