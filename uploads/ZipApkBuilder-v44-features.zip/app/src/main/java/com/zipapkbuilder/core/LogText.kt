package com.zipapkbuilder.core

/**
 * Shared GitHub Actions log-line cleaning — GitHub's raw job logs prefix every
 * line with an ISO-8601 timestamp and sprinkle in ANSI color codes and
 * `##[group]`/`##[endgroup]` fold markers. Compiled once here (rather than per
 * call, or duplicated per call site) since both the live build streamer
 * ([com.zipapkbuilder.feature.build.BuildLogStreamer.fetchAndLogFullLog]) and the
 * saved-run log viewer ([com.zipapkbuilder.feature.buildlog.BuildLogViewer.showLogDialog])
 * need the exact same cleanup.
 */
object LogText {
    private val timestampRegex = Regex("""^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s""")
    private val ansiRegex      = Regex("""\x1B\[[0-9;]*[A-Za-z]""")
    private val groupRegex     = Regex("""^##\[(?:group|endgroup)\]""")

    /** Strips a raw GitHub Actions log line's timestamp prefix and ANSI color codes. */
    fun cleanLine(raw: String): String = ansiRegex.replace(timestampRegex.replace(raw, ""), "")

    /** True for GitHub's `##[group]` / `##[endgroup]` fold markers, which aren't real log content. */
    fun isGroupMarker(line: String): Boolean = groupRegex.containsMatchIn(line)
}
