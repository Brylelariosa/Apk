package com.zipapkbuilder.core

import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/**
 * Small, stateless formatting helpers shared by every feature — human-readable
 * byte counts/durations, a friendlier spin on common network exceptions, and
 * GitHub's `created_at`-style timestamp parsing. Kept as pure functions with no
 * Activity/Context dependency so any feature controller can call them directly.
 */
object Formatters {

    fun fmtBytes(b: Long) = when {
        b < 1024L               -> "${b} B"
        b < 1024L * 1024        -> "${"%.1f".format(b / 1024.0)} KB"
        b < 1024L * 1024 * 1024 -> "${"%.1f".format(b / (1024.0 * 1024))} MB"
        else                    -> "${"%.2f".format(b / (1024.0 * 1024 * 1024))} GB"
    }

    fun fmtDuration(ms: Long): String {
        val totalSec = ms / 1000
        val m = totalSec / 60
        val s = totalSec % 60
        return if (m > 0) "${m}m ${s}s" else "${s}s"
    }

    /**
     * Maps common low-level exception types to a short, human hint appended after
     * the raw message — "No internet connection" reads better than a bare
     * UnknownHostException, especially since spotty mobile data is the single
     * most common reason this app's network calls fail.
     */
    fun friendlyError(e: Exception): String {
        val hint = when (e) {
            is java.net.UnknownHostException -> "No internet connection."
            is java.net.SocketTimeoutException -> "Request timed out — check your connection."
            is javax.net.ssl.SSLException -> "Secure connection failed — check your connection or device date/time."
            is java.net.ConnectException -> "Could not reach GitHub — check your connection."
            else -> null
        }
        val msg = e.message ?: e.javaClass.simpleName
        return if (hint != null) "$msg ($hint)" else msg
    }

    fun parseIso8601(s: String): Long = try {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .parse(s)?.time ?: 0L
    } catch (_: Exception) { 0L }

    /**
     * Formats an epoch-millis timestamp (download/build history entries) as a
     * short local date+time, e.g. `"Jul 27, 2:12 PM"` — 12-hour with AM/PM,
     * matching how the phone's own status bar/clock shows time, not the
     * 24-hour format this used before. Pinned to Philippines time
     * (`Asia/Manila`, UTC+8, no DST) rather than reading the device's own
     * timezone setting — the two should normally agree, but pinning
     * explicitly means history timestamps stay correct even if a device's
     * system timezone is ever misconfigured (some lower-cost devices'
     * network-based auto time zone detection gets this wrong), rather than
     * silently inheriting whatever the OS-level setting happens to be.
     */
    fun fmtLocalTime(millis: Long): String =
        SimpleDateFormat("MMM d, h:mm a", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("Asia/Manila") }
            .format(java.util.Date(millis))

    /**
     * Best-effort extraction of the actual project ZIP name a given
     * workflow run [run] was built from, by parsing GitHub's own record of
     * the triggering commit — either the run's `display_title` (GitHub's
     * own commit-summary field) or, if that's missing, `head_commit.message`
     * — against the exact `"ci: upload <name>.zip [run ...]"` pattern
     * [com.zipapkbuilder.feature.build.BuildUploadCoordinator] writes for
     * every upload.
     *
     * This exists because [com.zipapkbuilder.MainActivity.selectedZipName]
     * only reflects whichever ZIP is *currently* picked in the main UI —
     * correct for the run that was just built, but wrong for any older run
     * a user might browse to afterward and download the log for (the
     * filename would end up named after today's ZIP, not whatever that
     * specific historical run actually used). Every caller that names a
     * downloaded log file should prefer this over `selectedZipName`, falling
     * back to it only when this returns null (e.g. a manually dispatched run
     * with no upload commit to read a name from at all).
     */
    fun extractZipNameFromRun(run: org.json.JSONObject): String? {
        val message = run.optString("display_title", "").ifEmpty {
            run.optJSONObject("head_commit")?.optString("message", "") ?: ""
        }
        return Regex("""ci: upload (\S+\.zip)""", RegexOption.IGNORE_CASE)
            .find(message)?.groupValues?.get(1)
    }
}
