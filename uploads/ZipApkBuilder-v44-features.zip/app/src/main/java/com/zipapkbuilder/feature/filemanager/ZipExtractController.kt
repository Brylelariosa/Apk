package com.zipapkbuilder.feature.filemanager

import android.app.AlertDialog
import android.util.Base64
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.ButtonTone
import com.zipapkbuilder.core.DialogAction
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.dialogMessage
import com.zipapkbuilder.core.dialogWithActions
import com.zipapkbuilder.model.RepoItem
import com.zipapkbuilder.net.GitHubApi
import org.json.JSONArray
import org.json.JSONObject
import java.util.zip.ZipInputStream

/**
 * Extracts a ZIP file already in the repo into real files and folders at the
 * same location, preserving the archive's own internal structure — instead
 * of a ZIP just sitting there as one opaque file, "Extract" recreates every
 * folder and file it contains as actual repo content, the way a desktop
 * "Extract Here" would.
 *
 * Builds one single commit for the *whole* extraction via the Git Data API
 * (one blob per file, one shared tree, one commit, one ref update) rather
 * than a separate Contents-API commit per extracted file — for a ZIP with
 * many entries, that's the difference between one clean commit and dozens of
 * noisy ones, and roughly half the API round trips besides (no per-file
 * existing-sha lookup needed the way a Contents API update would require).
 *
 * The original ZIP is never touched — extraction only adds files. If it's
 * not needed anymore, delete it afterward via the browser's own Delete
 * action, same as any other file.
 */
class ZipExtractController(
    private val activity: MainActivity,
    private val refreshBrowser: (String, String, String, String, String) -> Unit
) {
    /** One file this extraction will create: its final repo path and the
     *  blob sha already uploaded for its content. */
    private data class ExtractedFile(val path: String, val blobSha: String)

    fun promptExtract(token: String, owner: String, repo: String, branch: String, item: RepoItem, currentPath: String) {
        lateinit var dlg: AlertDialog
        val content = activity.dialogWithActions(
            activity.dialogMessage(
                "Extract \"${item.name}\" here? Every file and folder inside the ZIP will be added " +
                    "to this location, preserving its structure.\n\nThe ZIP itself won't be deleted — " +
                    "remove it afterward from this same menu if you don't need it anymore."
            ),
            DialogAction("Extract", ButtonTone.GREEN, R.drawable.ic_check) {
                dlg.dismiss()
                activity.setBusy(true)
                activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
                activity.bgExecutor.execute { extract(token, owner, repo, branch, item, currentPath) }
            },
            DialogAction("Cancel", ButtonTone.SURFACE, R.drawable.ic_close) { dlg.dismiss() }
        )
        dlg = AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
            .setTitle("📦 Extract ZIP")
            .setView(content)
            .show()
    }

    private fun extract(token: String, owner: String, repo: String, branch: String, item: RepoItem, currentPath: String) {
        try {
            activity.appendLog("📦 Extracting ${item.name} …")

            val zipBytes = fetchFileBytes(token, owner, repo, item)
                ?: throw Exception("Could not read ${item.name} — it may be unavailable or an unexpected format.")

            // Stream-parse the ZIP, creating one blob per file entry as we go — only one
            // entry's decompressed bytes are ever held in memory at a time, never the
            // whole archive's uncompressed content at once.
            val extractedFiles = mutableListOf<ExtractedFile>()
            val dirsSeen = linkedSetOf<String>()          // every folder path the ZIP itself declares
            val dirsWithContent = mutableSetOf<String>()  // folders that ended up containing a real file
            val targetBase = if (currentPath.isEmpty()) "" else "$currentPath/"
            var fileCount = 0

            ZipInputStream(zipBytes.inputStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val entryName = entry.name.trim('/')
                    // Skip the archive's own root-level junk: an empty name (shouldn't
                    // happen but be defensive) or, rarely, an entry matching the ZIP's
                    // own filename (some tools zip a single top-level file oddly).
                    if (entryName.isEmpty()) { zis.closeEntry(); entry = zis.nextEntry; continue }
                    val targetPath = "$targetBase$entryName"

                    if (entry.isDirectory) {
                        dirsSeen.add(targetPath.trimEnd('/'))
                    } else {
                        val bytes = zis.readBytes()
                        fileCount++
                        activity.appendLog("  [$fileCount] $entryName (${Formatters.fmtBytes(bytes.size.toLong())})")
                        val blobSha = createBlob(token, owner, repo, bytes)
                        extractedFiles.add(ExtractedFile(targetPath, blobSha))
                        // Mark every ancestor folder of this file as "has real content" so the
                        // empty-folder pass below doesn't also add a redundant .gitkeep next to it.
                        var parent = targetPath.substringBeforeLast('/', "")
                        while (parent.isNotEmpty()) {
                            dirsWithContent.add(parent)
                            parent = parent.substringBeforeLast('/', "")
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            if (extractedFiles.isEmpty()) {
                activity.appendLog("⚠ No files found inside ${item.name} — nothing to extract.")
                return
            }

            // Preserve folders the ZIP declared but which ended up with no file inside them —
            // git itself never tracks empty directories at all, so without an explicit
            // placeholder, an empty folder from the ZIP would just silently disappear on
            // extraction instead of being recreated.
            val emptyDirs = dirsSeen - dirsWithContent
            for (dir in emptyDirs) {
                extractedFiles.add(ExtractedFile("$dir/.gitkeep", createBlob(token, owner, repo, ByteArray(0))))
            }

            activity.appendLog("Building tree (${extractedFiles.size} entries)…")
            commitExtractedTree(token, owner, repo, branch, item.name, extractedFiles)

            activity.appendLog(
                "✓ Extracted $fileCount file(s)" +
                    (if (emptyDirs.isNotEmpty()) " and ${emptyDirs.size} empty folder(s)" else "") +
                    " from ${item.name}"
            )
        } catch (e: Exception) {
            activity.appendLog("✗ Extract failed: ${Formatters.friendlyError(e)}")
        } finally {
            activity.mainHandler.post {
                activity.setBusy(false)
                refreshBrowser(token, owner, repo, branch, currentPath)
            }
        }
    }

    /** Uploads raw [bytes] as a git blob and returns its sha. */
    private fun createBlob(token: String, owner: String, repo: String, bytes: ByteArray): String {
        val body = JSONObject().apply {
            put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
            put("encoding", "base64")
        }.toString()
        val (code, resp) = GitHubApi.httpPost(token, GitHubApi.apiBlobs(owner, repo), body)
        if (code !in 200..201) throw Exception("Blob creation failed ($code): ${resp.take(200)}")
        return JSONObject(resp).getString("sha")
    }

    /**
     * Fetches a repo file's raw bytes regardless of size. The Contents API's
     * inline `content` field is only populated for files under 1MB; for
     * anything larger (a real risk here — ZIPs are exactly the kind of file
     * that commonly exceeds that), this falls back to the Git Data API's
     * blob-by-sha endpoint instead, which has no such limit.
     */
    private fun fetchFileBytes(token: String, owner: String, repo: String, item: RepoItem): ByteArray? {
        if (item.size in 1 until (1024 * 1024)) {
            val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiContents(owner, repo, item.path))
            if (code == 200) {
                val content = JSONObject(body).optString("content", "")
                if (content.isNotEmpty()) return Base64.decode(content.replace("\n", ""), Base64.DEFAULT)
            }
        }
        if (item.sha.isEmpty()) return null
        val (code, body) = GitHubApi.httpGet(token, GitHubApi.apiBlob(owner, repo, item.sha))
        if (code != 200) return null
        val content = JSONObject(body).optString("content", "")
        if (content.isEmpty()) return null
        return Base64.decode(content.replace("\n", ""), Base64.DEFAULT)
    }

    /** Blob → tree → commit → ref-update for every file in [files] at once — see the
     *  class kdoc for why this is one commit instead of one per extracted file. */
    private fun commitExtractedTree(token: String, owner: String, repo: String, branch: String, zipName: String, files: List<ExtractedFile>) {
        val (refCode, refBody) = GitHubApi.httpGet(token, GitHubApi.apiRefHeads(owner, repo, branch))
        if (refCode != 200) throw Exception("Could not read branch ref ($refCode)")
        val tipSha = JSONObject(refBody).getJSONObject("object").getString("sha")

        val (commitCode, commitBody) = GitHubApi.httpGet(token, GitHubApi.apiCommit(owner, repo, tipSha))
        if (commitCode != 200) throw Exception("Could not read tip commit ($commitCode)")
        val baseTreeSha = JSONObject(commitBody).getJSONObject("tree").getString("sha")

        val treeArr = JSONArray()
        for (f in files) {
            treeArr.put(JSONObject().apply {
                put("path", f.path)
                put("mode", "100644")
                put("type", "blob")
                put("sha", f.blobSha)
            })
        }
        val treeReqBody = JSONObject().apply { put("base_tree", baseTreeSha); put("tree", treeArr) }.toString()
        val (treeCode, treeResp) = GitHubApi.httpPost(token, GitHubApi.apiTrees(owner, repo), treeReqBody)
        if (treeCode !in 200..201) throw Exception("Tree creation failed ($treeCode): ${treeResp.take(300)}")
        val newTreeSha = JSONObject(treeResp).getString("sha")

        val newCommitBody = JSONObject().apply {
            put("message", "chore: extract $zipName [skip ci]")
            put("tree", newTreeSha)
            put("parents", JSONArray().put(tipSha))
        }.toString()
        val (newCommitCode, newCommitResp) = GitHubApi.httpPost(token, GitHubApi.apiCommits(owner, repo), newCommitBody)
        if (newCommitCode !in 200..201) throw Exception("Commit failed ($newCommitCode): ${newCommitResp.take(300)}")
        val newCommitSha = JSONObject(newCommitResp).getString("sha")

        val refPatchBody = JSONObject().apply { put("sha", newCommitSha); put("force", false) }.toString()
        val (patchCode, patchResp) = GitHubApi.httpPatch(token, GitHubApi.apiRefsHeads(owner, repo, branch), refPatchBody)
        if (patchCode !in 200..201) throw Exception("Ref update failed ($patchCode): ${patchResp.take(300)}")
    }
}
