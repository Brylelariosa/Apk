package com.zipapkbuilder.core

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Shared "capped, newest-first JSON list in a single SharedPreferences string"
 * pattern — [com.zipapkbuilder.feature.download.DownloadHistory] and
 * [com.zipapkbuilder.feature.build.BuildHistory] each used to hand-roll their
 * own copy of exactly this (parse-or-empty, prepend, truncate at a cap,
 * re-save); centralized here so there's one implementation instead of two
 * near-identical ones that could quietly drift apart.
 */
object JsonPrefsList {

    /** Parses the JSON array stored at [key], or an empty array if missing/corrupt. */
    fun load(prefs: SharedPreferences, key: String): JSONArray = try {
        JSONArray(prefs.getString(key, "[]") ?: "[]")
    } catch (_: Exception) {
        JSONArray()
    }

    /** [load] mapped to a plain `List<JSONObject>`, the shape every caller actually wants. */
    fun loadList(prefs: SharedPreferences, key: String): List<JSONObject> {
        val arr = load(prefs, key)
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }

    /**
     * Prepends [entry] to the list stored at [key] (newest first) and re-saves it,
     * keeping at most [cap] entries total — the oldest are dropped once the cap is
     * exceeded. Used for small, bounded, purely-local history logs (download
     * history, build history) where unbounded growth would otherwise slowly bloat
     * SharedPreferences forever.
     */
    fun prepend(prefs: SharedPreferences, key: String, entry: JSONObject, cap: Int = 30) {
        val existing = load(prefs, key)
        val updated = JSONArray()
        updated.put(entry)
        for (i in 0 until minOf(existing.length(), cap - 1)) updated.put(existing.getJSONObject(i))
        prefs.edit().putString(key, updated.toString()).apply()
    }
}
