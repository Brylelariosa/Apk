package com.zipapkbuilder.feature.filemanager

import android.net.Uri
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.net.GitHubApi
import com.zipapkbuilder.net.NetworkReliability

/**
 * Uploads a single local file (picked from the device, not a project ZIP —
 * see [com.zipapkbuilder.feature.build.BuildFlowController] for that) into the
 * repo via the Contents API. Split out of [FileManagerController] since it's
 * a self-contained, independently-triggerable feature (reached from the file
 * manager's "New → Upload File" entry, via [FileOperationController.showNewItemDialog])
 * with no dependency on browsing, editing, or the other file operations.
 *
 * Shares [com.zipapkbuilder.feature.upload.UploadCoordinator] — the same
 * retry/progress/cancellation machinery
 * [com.zipapkbuilder.feature.build.BuildUploadCoordinator]'s small-file path
 * uses for the build ZIP — rather than calling
 * [GitHubApi.uploadStreamingBase64] directly with retry/progress/cancellation
 * all hardwired off, which was the one upload path in the app that had none
 * of the three.
 *
 * Also cleans up after itself: a successful upload triggers
 * [removeGitkeepIfPresent], which deletes a `.gitkeep` placeholder from the
 * destination folder if one's there — see its own kdoc.
 */
class FileUploadController(private val activity: MainActivity) {

    /**
     * Uploads [uri] into the repo — via the Contents API directly for files
     * up to 1MB, the Git Data API for anything larger (up to ~99MB), exactly
     * the same size-based branch
     * [com.zipapkbuilder.feature.build.BuildUploadCoordinator.executeUpload]
     * uses for the build ZIP. Before this, File Manager uploads only ever
     * used the Contents API and hard-rejected anything over 50MB outright —
     * so a 60MB file failed here even though the exact same file would have
     * succeeded as a build ZIP. Binary files (images, zips, APKs…) are
     * handled the same way as text either way — GitHub's upload endpoints
     * accept any base-64 payload regardless of MIME type.
     *
     * Both paths run through [com.zipapkbuilder.feature.upload.UploadCoordinator.withUploadRetry]
     * (exponential-backoff retry on transient/network failures, automatic
     * offline pause-and-resume) and report progress via the same floating
     * upload bubble the build-ZIP upload uses, so a file picked from Manage
     * Files behaves identically to one uploaded as part of a build —
     * cancellable from that bubble, retried automatically on a flaky
     * connection, instead of failing outright on the first hiccup.
     */
    fun uploadFileToRepo(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, uri: Uri, refreshPath: String
    ) {
        val uploadCoordinator = activity.uploadCoordinator
        try {
            val rawLength = UriUtils.resolveFileSize(activity.contentResolver, uri)
            activity.appendLog("  Size: ${rawLength / 1024} KB")
            uploadCoordinator.uploadCancelled = false
            val displayName = filePath.substringAfterLast('/')

            if (rawLength > 1 * 1024 * 1024) {
                activity.appendLog("  Large file — using Git Data API…")
                val handle = uploadCoordinator.beginUpload(displayName, GitHubApi.base64EncodedLength(rawLength))
                var ok = false
                try {
                    uploadCoordinator.withUploadRetry(handle) {
                        uploadCoordinator.uploadViaGitDataApi(
                            token, owner, repo, branch, filePath, uri, rawLength, displayName,
                            // [skip ci] here (unlike the build flow's own Git Data API upload,
                            // which deliberately omits it) — a File Manager upload isn't a build
                            // trigger, so it shouldn't kick off a workflow run even on the rare
                            // chance it lands inside the uploads/ path the workflow watches.
                            commitMessage = "upload: $filePath via ZipApkBuilder [skip ci]"
                        ) { written, total -> handle.onProgress(written, total) }
                    }
                    ok = true
                } finally {
                    handle.finish(ok)
                }
                if (uploadCoordinator.uploadCancelled) { activity.appendLog("⚠ Upload cancelled: $filePath"); return }
                activity.appendLog("✓ Uploaded: $filePath")
                removeGitkeepIfPresent(token, owner, repo, branch, filePath)
                return
            }

            val existingSha = activity.buildFlowController.fetchFileSha(token, owner, repo, filePath)
            val handle = uploadCoordinator.beginUpload(displayName, GitHubApi.base64EncodedLength(rawLength))
            var ok = false
            val (code, body) = try {
                uploadCoordinator.withUploadRetry(handle) {
                    uploadCoordinator.uploadFileViaContentsApi(
                        token, owner, repo, branch, filePath,
                        message = "upload: $filePath via ZipApkBuilder [skip ci]",
                        sourceUri = uri, rawLength = rawLength, existingSha = existingSha
                    ) { written, total -> handle.onProgress(written, total) }
                        .also { (c, b) ->
                            // Treat a retryable-but-returned (not thrown) HTTP code as a
                            // failure withUploadRetry can see and retry, same as the
                            // build-ZIP upload path does.
                            if (c in NetworkReliability.RETRYABLE_HTTP_CODES) throw Exception("Upload failed ($c): ${b.take(200)}")
                        }
                }.also { (c, _) -> ok = c in 200..201 }
            } finally {
                handle.finish(ok)
            }
            if (uploadCoordinator.uploadCancelled) { activity.appendLog("⚠ Upload cancelled: $filePath"); return }
            if (code in 200..201) {
                activity.appendLog("✓ Uploaded: $filePath")
                removeGitkeepIfPresent(token, owner, repo, branch, filePath)
            } else {
                activity.appendLog("✗ Upload failed ($code): ${body.take(200)}")
            }
        } catch (e: Exception) {
            activity.appendLog("✗ ${e.message}")
        }
    }

    /**
     * Removes a `.gitkeep` placeholder from the folder [uploadedFilePath] was
     * just uploaded into, if one exists there. `.gitkeep` files exist purely
     * to keep an otherwise-empty directory tracked by git (git doesn't track
     * empty directories at all); once the folder has a real file in it, the
     * placeholder no longer serves that purpose and just clutters the
     * listing. Skips the repo-root case implicitly (an empty `folder` still
     * resolves to a root-level `.gitkeep`, which this treats the same way —
     * there's nothing special about the root here) and skips entirely if the
     * file that was *just* uploaded is itself named `.gitkeep` (re-uploading
     * one on purpose shouldn't immediately delete itself).
     *
     * Best-effort and silent on any failure (no `.gitkeep` present, a
     * transient API error, a race with something else touching the same
     * file) — this is a courtesy cleanup, never something worth surfacing an
     * error for or, more importantly, retrying and risking a duplicate
     * delete attempt on the same sha.
     */
    private fun removeGitkeepIfPresent(token: String, owner: String, repo: String, branch: String, uploadedFilePath: String) {
        val uploadedName = uploadedFilePath.substringAfterLast('/')
        if (uploadedName.equals(".gitkeep", ignoreCase = true)) return
        val folder = uploadedFilePath.substringBeforeLast('/', "")
        val gitkeepPath = if (folder.isEmpty()) ".gitkeep" else "$folder/.gitkeep"
        try {
            val sha = activity.buildFlowController.fetchFileSha(token, owner, repo, gitkeepPath) ?: return
            val payload = org.json.JSONObject().apply {
                put("message", "chore: remove .gitkeep — $folder is no longer empty [skip ci]")
                put("sha", sha)
                put("branch", branch)
            }.toString()
            val (code, _) = GitHubApi.httpDelete(token, GitHubApi.apiContents(owner, repo, gitkeepPath), payload)
            if (code in 200..204) {
                activity.appendLog("🧹 Removed .gitkeep from ${folder.ifEmpty { "repo root" }} (no longer empty)")
            }
            // A non-2xx here (404, a race with something else already removing it, etc.)
            // is fine to ignore silently — worst case the .gitkeep just stays, which is
            // harmless either way.
        } catch (_: Exception) {
            // Best-effort — never worth surfacing an error for this.
        }
    }
}
