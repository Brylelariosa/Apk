package com.zipapkbuilder.feature.upload

import android.app.AlertDialog
import android.net.Uri
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.R
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.FloatingTransferIndicator
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.net.GitHubApi
import com.zipapkbuilder.net.NetworkReliability
import org.json.JSONArray
import org.json.JSONObject

/**
 * Drives a single reliable, progress-tracked upload to GitHub: the upload
 * progress dialog, retry-with-backoff policy, and the large-file Git Data API
 * path (blob → tree → commit → ref update) that [BuildFlowController][com.zipapkbuilder.feature.build.BuildFlowController]
 * uses for anything too big for a single Contents API PUT.
 */
class UploadCoordinator(
    private val activity: MainActivity,
    private val networkReliability: NetworkReliability
) {
    /** Set by the upload dialog's Cancel button; polled by every chunked write and retry loop. */
    @Volatile var uploadCancelled = false

    /**
     * Drives the shared [com.zipapkbuilder.core.FloatingTransferIndicator]
     * bubble for one upload instead of the old screen-covering, non-cancelable
     * "Uploading" [AlertDialog] — the whole point of the floating bubble is
     * that it never forces itself in front of the app, so uploading no longer
     * blocks the user from doing anything else while it runs.
     *
     * Cancellation moves from an always-visible "✕ Cancel" button (which the
     * old modal needed since it blocked everything else) to a confirmation
     * prompt shown only when the user deliberately taps the bubble — the
     * upload keeps running silently in the background otherwise.
     */
    inner class UploadProgressHandle(private val fileName: String, private val totalBytes: Long) {
        private var lastSpeedTime  = System.currentTimeMillis()
        private var lastSpeedBytes = 0L

        init {
            activity.mainHandler.post {
                activity.floatingTransferIndicator.show(FloatingTransferIndicator.Mode.UPLOAD) { confirmCancel() }
                activity.floatingTransferIndicator.updateProgress(if (totalBytes > 0) 0 else -1)
                activity.setStatus("Uploading $fileName…")
            }
        }

        private fun confirmCancel() {
            AlertDialog.Builder(activity, R.style.Theme_App_Dialog)
                .setTitle("Cancel upload?")
                .setMessage("Stop uploading \"$fileName\"?")
                .setPositiveButton("Cancel Upload") { _, _ ->
                    uploadCancelled = true
                    activity.appendLog("⚠ Cancelling upload…")
                }
                .setNegativeButton("Keep Uploading", null)
                .show()
        }

        /** Reports transfer progress; safe to call from a background thread. */
        val onProgress: (written: Long, total: Long) -> Unit = { written, total ->
            val now     = System.currentTimeMillis()
            val elapsed = now - lastSpeedTime
            if (elapsed >= 200) {
                val speedBps = (written - lastSpeedBytes) * 1000L / elapsed.coerceAtLeast(1)
                lastSpeedTime  = now; lastSpeedBytes = written
                val pct    = if (total > 0) (written * 100L / total).toInt() else -1
                val pctStr = if (total > 0) "${"%.0f".format(written * 100.0 / total)}%" else "…"
                activity.mainHandler.post {
                    activity.floatingTransferIndicator.updateProgress(pct)
                    activity.setStatus("Uploading… $pctStr (${Formatters.fmtBytes(speedBps)}/s)")
                }
            }
        }

        /** Surfaces a status line (retry/backoff/offline messages) without a popup. */
        fun setStatus(text: String) {
            activity.mainHandler.post { activity.setStatus(text) }
        }

        /** Call once the upload attempt is fully done (success, failure, or
         *  cancellation) so the bubble reflects the outcome and fades itself out. */
        fun finish(success: Boolean) {
            activity.mainHandler.post {
                if (success) {
                    activity.floatingTransferIndicator.complete(FloatingTransferIndicator.Mode.UPLOAD) { }
                } else {
                    activity.floatingTransferIndicator.hide()
                }
            }
        }
    }

    /** Starts tracking one upload's progress via the floating bubble. Safe to
     *  call from a background thread. */
    fun beginUpload(fileName: String, totalBytes: Long): UploadProgressHandle =
        UploadProgressHandle(fileName, totalBytes)

    /**
     * Applies the same network-reliability policy downloads get from the
     * download engine to a single upload attempt — without byte-level
     * resume, since none of GitHub's upload endpoints (Contents API PUT, or
     * the blob/tree/commit sequence in [uploadViaGitDataApi]) support
     * resuming a partial request the way a download's Range header does.
     * Instead, a failed attempt is retried *from scratch*, which is safe here
     * because every step involved is naturally idempotent or cheap to redo:
     * Git blobs and trees are content-addressed (recreating one with the same
     * bytes just returns the same SHA, at negligible cost), and a retried
     * commit/ref-update simply produces one small additional commit rather
     * than corrupting anything.
     *
     * - A dropped connection while genuinely offline pauses (shown via
     *   [UploadProgressHandle.setStatus]) and resumes automatically the instant
     *   connectivity returns — this never counts against [maxRetries].
     * - A transient HTTP failure (429/500/502/503/504, recognized via
     *   [NetworkReliability.retryableHttpCodeIn] since these arrive as thrown
     *   messages, not return codes) or an I/O error while the network still
     *   tests as reachable retries with exponential backoff, up to
     *   [maxRetries] times.
     * - Anything else (auth failure, payload too large, cancellation) is
     *   fatal immediately.
     *
     * Must be called from a background thread.
     */
    fun <T> withUploadRetry(
        dlUi: UploadProgressHandle,
        maxRetries: Int = NetworkReliability.MAX_DOWNLOAD_RETRIES,
        attempt: () -> T
    ): T {
        var retryAttempt = 0
        var backoffMs = NetworkReliability.INITIAL_RETRY_BACKOFF_MS
        while (true) {
            if (uploadCancelled) throw Exception("Cancelled by user")
            try {
                return attempt()
            } catch (e: Exception) {
                if (e.message == "Cancelled by user" || uploadCancelled) throw e

                val retryableCode = networkReliability.retryableHttpCodeIn(e.message)
                val isIoIssue = e is java.io.IOException

                if (isIoIssue && !networkReliability.isNetworkAvailable()) {
                    dlUi.setStatus("⚠ Paused (No Internet) — will resume automatically")
                    val reconnected = networkReliability.waitForNetwork { uploadCancelled }
                    if (!reconnected) throw Exception("Cancelled by user")
                    activity.appendLog("↻ Back online — retrying upload…")
                    continue
                }

                if (isIoIssue || retryableCode != null) {
                    retryAttempt++
                    if (retryAttempt > maxRetries) {
                        throw Exception("${Formatters.friendlyError(e)} — gave up after $maxRetries retries.")
                    }
                    dlUi.setStatus("Retrying in ${backoffMs / 1000}s… (attempt $retryAttempt/$maxRetries)")
                    networkReliability.sleepCancellable(backoffMs) { uploadCancelled }
                    backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
                    continue
                }

                throw e // not network/transient-server-related — fatal
            }
        }
    }

    /**
     * Uploads [sourceUri]'s content to [filePath] using the Git Data API.
     * This path bypasses the Contents API's 50 MB file limit and supports up
     * to ~99 MB raw.
     *
     * The file is streamed straight from [sourceUri] and base64-encoded on
     * the fly (see [GitHubApi.uploadStreamingBase64]) rather than being read
     * into a byte array and re-encoded into a full base64 string first — the
     * old approach held the raw bytes, the base64 string, and the JSON body
     * as separate full-size copies at once. A fresh stream is opened here on
     * every call, since a retried attempt (see [withUploadRetry], which redoes
     * a failed attempt from scratch) can't resume a partially-consumed one.
     *
     * Steps: create blob → get branch tip → get base tree →
     *        create tree → create commit → advance ref.
     *
     * Returns the blob SHA (stored as lastFileSha for later ops) and the new
     * commit's SHA — the latter lets a caller match the exact workflow run
     * this push triggers via GitHub's `head_sha` run filter instead of a
     * timestamp heuristic (see [com.zipapkbuilder.feature.build.BuildRunMonitor.waitForRun]).
     */
    data class GitDataUploadResult(val blobSha: String, val commitSha: String)

    fun uploadViaGitDataApi(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, sourceUri: Uri, rawLength: Long, displayName: String,
        /** Defaults to the build-flow's own message when null — callers outside the
         *  build flow (e.g. [com.zipapkbuilder.feature.filemanager.FileUploadController]
         *  for a large File Manager upload) pass their own so it reads correctly and,
         *  importantly, so they can include `[skip ci]` where the build flow's default
         *  deliberately does not — a build-flow upload is *meant* to trigger the
         *  workflow, so it must never accidentally carry `[skip ci]`. */
        commitMessage: String? = null,
        onProgress: (Long, Long) -> Unit
    ): GitDataUploadResult {
        // 1. Create blob (largest network call — drives the progress bar)
        activity.appendLog("  Uploading blob…")
        val (blobCode, blobResp) = GitHubApi.uploadStreamingBase64(
            token, GitHubApi.apiBlobs(owner, repo), "POST",
            jsonPrefix = "{\"content\":\"",
            source = UriUtils.openInputStreamOrThrow(activity.contentResolver, sourceUri),
            rawLength = rawLength,
            jsonSuffix = "\",\"encoding\":\"base64\"}",
            isCancelled = { uploadCancelled }, onProgress = onProgress
        )
        if (blobCode !in 200..201)
            throw Exception("Blob upload failed ($blobCode): ${blobResp.take(300)}")
        val blobSha = JSONObject(blobResp).getString("sha")
        activity.appendLog("  Blob created ✓ (${blobSha.take(12)}…)")

        // 2. Get the current branch tip commit SHA
        val (refCode, refBody) = GitHubApi.httpGet(token, GitHubApi.apiRefHeads(owner, repo, branch))
        if (refCode != 200) throw Exception("Could not read branch ref ($refCode)")
        val tipSha = JSONObject(refBody).getJSONObject("object").getString("sha")

        // 3. Get base tree SHA from tip commit
        val (commitCode, commitBody) = GitHubApi.httpGet(token, GitHubApi.apiCommit(owner, repo, tipSha))
        if (commitCode != 200) throw Exception("Could not read tip commit ($commitCode)")
        val baseSha = JSONObject(commitBody).getJSONObject("tree").getString("sha")

        // 4. Create a new tree with the file
        activity.appendLog("  Creating tree…")
        val treeBody = JSONObject().apply {
            put("base_tree", baseSha)
            put("tree", JSONArray().put(JSONObject().apply {
                put("path", filePath)
                put("mode", "100644")
                put("type", "blob")
                put("sha",  blobSha)
            }))
        }.toString()
        val (treeCode, treeResp) = GitHubApi.httpPost(token, GitHubApi.apiTrees(owner, repo), treeBody)
        if (treeCode !in 200..201)
            throw Exception("Tree creation failed ($treeCode): ${treeResp.take(300)}")
        val newTreeSha = JSONObject(treeResp).getString("sha")

        // 5. Create new commit
        activity.appendLog("  Committing…")
        val newCommitBody = JSONObject().apply {
            put("message", commitMessage ?: "ci: upload $displayName [run ${System.currentTimeMillis()}]")
            put("tree",    newTreeSha)
            put("parents", JSONArray().put(tipSha))
        }.toString()
        val (newCommitCode, newCommitResp) = GitHubApi.httpPost(token, GitHubApi.apiCommits(owner, repo), newCommitBody)
        if (newCommitCode !in 200..201)
            throw Exception("Commit failed ($newCommitCode): ${newCommitResp.take(300)}")
        val newCommitSha = JSONObject(newCommitResp).getString("sha")

        // 6. Advance branch ref
        activity.appendLog("  Advancing branch ref…")
        val refPatchBody = JSONObject().apply {
            put("sha",   newCommitSha)
            put("force", false)
        }.toString()
        val (patchCode, patchResp) = GitHubApi.httpPatch(token, GitHubApi.apiRefsHeads(owner, repo, branch), refPatchBody)
        if (patchCode !in 200..201)
            throw Exception("Ref update failed ($patchCode): ${patchResp.take(300)}")

        return GitDataUploadResult(blobSha, newCommitSha)
    }

    /**
     * PUTs [sourceUri]'s content to [filePath] via the Contents API — the
     * path [BuildFlowController][com.zipapkbuilder.feature.build.BuildFlowController]
     * uses for ZIPs small enough to skip the Git Data API — streaming the
     * base64 encoding straight into the request body via
     * [GitHubApi.uploadStreamingBase64] instead of building the whole JSON
     * payload as one String first. [FileManagerController][com.zipapkbuilder.feature.filemanager.FileManagerController]'s
     * own file-upload feature shares the same envelope via
     * [GitHubApi.contentsApiEnvelope] rather than duplicating this JSON
     * construction. A fresh stream is opened on every call so a retried
     * attempt always starts from the beginning of the file.
     */
    fun uploadFileViaContentsApi(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, message: String, sourceUri: Uri, rawLength: Long,
        existingSha: String?, onProgress: (Long, Long) -> Unit
    ): Pair<Int, String> {
        val (prefix, suffix) = GitHubApi.contentsApiEnvelope(message, branch, existingSha)
        return GitHubApi.uploadStreamingBase64(
            token, GitHubApi.apiContents(owner, repo, filePath), "PUT",
            jsonPrefix = prefix,
            source = UriUtils.openInputStreamOrThrow(activity.contentResolver, sourceUri),
            rawLength = rawLength,
            jsonSuffix = suffix,
            isCancelled = { uploadCancelled }, onProgress = onProgress
        )
    }
}
