package com.zipapkbuilder.core

import android.animation.ValueAnimator
import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import com.zipapkbuilder.R

/**
 * A small floating circular progress bubble — the non-blocking replacement for
 * the old screen-covering "Uploading…" dialog and the old auto-opened Download
 * Manager popup. Lives directly in the Activity window's content frame
 * (`android.R.id.content`, the FrameLayout every Activity's decor view wraps
 * `setContentView` in) rather than the app's own scrolling layout, so it stays
 * pinned to the bottom-end corner of the screen no matter how far the rest of
 * the UI is scrolled.
 *
 * The whole point is that the user can keep using the app while a transfer
 * runs — the way Opera's download bubble works: a small ring shows progress,
 * and tapping it (while transferring, or for a few seconds after it finishes)
 * jumps to wherever the caller wants — [com.zipapkbuilder.feature.download.DownloadManager.showDownloadManagerDialog]
 * for downloads, a cancel confirmation for uploads. It never forces itself in
 * front of anything the way a modal dialog does, and it never needs to be
 * dismissed by hand — it fades itself out a few seconds after [complete] or
 * [fail].
 *
 * One shared instance is used for both uploads and downloads (see
 * [com.zipapkbuilder.MainActivity.floatingTransferIndicator]) since the two
 * essentially never run at the same time in this app; whichever call is most
 * recent simply owns the bubble.
 */
class FloatingTransferIndicator(private val activity: Activity) {

    enum class Mode { UPLOAD, DOWNLOAD }

    companion object {
        private const val AUTO_HIDE_DELAY_MS = 3500L
        private const val START_FLASH_DELAY_MS = 2200L
    }

    // NOTE: computed lazily, not read at construction time — this object is
    // built as an eager field on MainActivity (`= FloatingTransferIndicator(this)`),
    // which runs before the Activity is attached to its Context. Reading
    // activity.resources that early throws immediately (same reason
    // MainActivity's own `prefs` field uses `by lazy`), so this must not touch
    // `activity.resources` until ensureCreated() is actually called.
    private val dp: Float by lazy { activity.resources.displayMetrics.density }
    private val mainHandler = Handler(Looper.getMainLooper())

    /** The bubble's three views, always created and torn down together — see
     *  [ensureCreated]. Bundled into one nullable holder instead of three
     *  separately-nullable fields so "these are always set together" is
     *  something the type system enforces, not just a convention every
     *  reader has to notice and preserve by hand. */
    private data class Views(val container: FrameLayout, val ring: TransferRingView, val icon: ImageView)

    private var views: Views? = null
    private var autoHideRunnable: Runnable? = null

    private fun ensureCreated(): Views {
        views?.let { return it }

        val decor = activity.findViewById<FrameLayout>(android.R.id.content)
        val size = (56 * dp).toInt()

        val c = FrameLayout(activity).apply {
            layoutParams = FrameLayout.LayoutParams(size, size).also {
                it.gravity = Gravity.BOTTOM or Gravity.END
                it.marginEnd = (18 * dp).toInt()
                it.bottomMargin = (28 * dp).toInt()
            }
            elevation = 12 * dp
            alpha = 0f
            scaleX = 0.6f; scaleY = 0.6f
            visibility = View.GONE
            isClickable = true
            isFocusable = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    if (view.width > 0 && view.height > 0) outline.setOval(0, 0, view.width, view.height)
                }
            }
        }

        val r = TransferRingView(activity)
        c.addView(r, FrameLayout.LayoutParams(size, size))

        val iconSize = (22 * dp).toInt()
        val i = ImageView(activity).apply {
            layoutParams = FrameLayout.LayoutParams(iconSize, iconSize).also { it.gravity = Gravity.CENTER }
            imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
        }
        c.addView(i)

        decor.addView(c)
        val v = Views(c, r, i)
        views = v
        return v
    }

    private fun cancelAutoHide() {
        autoHideRunnable?.let { mainHandler.removeCallbacks(it) }
        autoHideRunnable = null
    }

    private fun animateIn(view: View) {
        if (view.visibility == View.VISIBLE && view.alpha > 0.9f) return
        view.visibility = View.VISIBLE
        view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
    }

    private fun animateOutThenGone(view: View) {
        view.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(220)
            .withEndAction { view.visibility = View.GONE }.start()
    }

    /** Shows (creating the bubble if this is the first use) the active-transfer
     *  state and wires [onTap] as its click target. Safe to call repeatedly —
     *  e.g. once per progress tick — it's a no-op re-show if already visible. */
    fun show(mode: Mode, onTap: () -> Unit) {
        mainHandler.post {
            cancelAutoHide()
            val (c, r, i) = ensureCreated()
            r.showRing = true
            i.setImageResource(if (mode == Mode.DOWNLOAD) R.drawable.ic_download else R.drawable.ic_upload)
            r.setFillGradient(0xFF7C6BFF.toInt(), 0xFF5B4DE8.toInt())
            c.setOnClickListener { onTap() }
            animateIn(c)
        }
    }

    /** A brief, no-progress "something just started" flash — e.g. a download
     *  being queued. No ring, no percentage, just the bubble appearing for a
     *  couple of seconds and fading itself back out. Stays tappable (wired to
     *  [onTap]) the whole time it's visible. */
    fun flashStart(mode: Mode, onTap: () -> Unit) {
        mainHandler.post {
            val (c, r, i) = ensureCreated()
            r.stopSpin()
            r.showRing = false
            i.setImageResource(if (mode == Mode.DOWNLOAD) R.drawable.ic_download else R.drawable.ic_upload)
            r.setFillGradient(0xFF7C6BFF.toInt(), 0xFF5B4DE8.toInt())
            c.setOnClickListener { onTap() }
            animateIn(c)
            scheduleAutoHide(START_FLASH_DELAY_MS)
        }
    }

    /** Updates the ring on the currently-shown bubble. Pass a negative value for
     *  an indeterminate spinning arc (used until the transfer's total size is
     *  known), or 0..100 for a determinate sweep. */
    fun updateProgress(percent: Int) {
        mainHandler.post {
            val r = views?.ring ?: return@post
            r.showRing = true
            if (percent < 0) {
                r.startSpin()
            } else {
                r.stopSpin()
                r.progress = percent.coerceIn(0, 100)
            }
        }
    }

    /** Switches to a success checkmark and starts the auto-hide countdown — the
     *  bubble stays tappable (re-wired to [onTap]) for the whole countdown,
     *  exactly like Opera's download-finished pill. Pass [showRing] = false for
     *  a plain flash with no progress ring at all. */
    fun complete(mode: Mode, showRing: Boolean = true, onTap: () -> Unit) {
        mainHandler.post {
            val (c, r, i) = ensureCreated()
            r.stopSpin()
            r.showRing = showRing
            r.progress = 100
            r.setFillGradient(0xFF2ECC71.toInt(), 0xFF27AE60.toInt())
            i.setImageResource(R.drawable.ic_check)
            c.setOnClickListener { onTap() }
            animateIn(c)
            scheduleAutoHide()
        }
    }

    /** Same as [complete] but for a failed transfer — warning glyph, red tint. */
    fun fail(mode: Mode, showRing: Boolean = true, onTap: () -> Unit) {
        mainHandler.post {
            val (c, r, i) = ensureCreated()
            r.stopSpin()
            r.showRing = showRing
            r.progress = 100
            r.setFillGradient(0xFFFF6B6B.toInt(), 0xFFE85555.toInt())
            i.setImageResource(R.drawable.ic_warning)
            c.setOnClickListener { onTap() }
            animateIn(c)
            scheduleAutoHide()
        }
    }

    private fun scheduleAutoHide(delayMs: Long = AUTO_HIDE_DELAY_MS) {
        cancelAutoHide()
        val run = Runnable { views?.container?.let { animateOutThenGone(it) } }
        autoHideRunnable = run
        mainHandler.postDelayed(run, delayMs)
    }

    /** Hides immediately with no lingering "done" state — used when there's
     *  nothing worth showing the user afterwards (e.g. a cancelled transfer). */
    fun hide() {
        mainHandler.post {
            cancelAutoHide()
            views?.ring?.stopSpin()
            views?.container?.let { animateOutThenGone(it) }
        }
    }
}

/**
 * The bubble's circular track + progress arc + gradient fill, hand-drawn on a
 * [Canvas] rather than composed from drawables so the arc can sweep smoothly
 * to any percentage (determinate) or spin continuously (indeterminate, before
 * a transfer's total size is known) without needing a stack of pre-baked
 * frames.
 */
private class TransferRingView(activity: Activity) : View(activity) {
    private val dp = resources.displayMetrics.density
    private val ringStrokeWidth = 3f * dp

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ringStrokeWidth
        color = 0x33FFFFFF
    }
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = ringStrokeWidth
        color = 0xFFFFFFFF.toInt()
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val bounds = RectF()

    private var fillStart = 0xFF7C6BFF.toInt()
    private var fillEnd = 0xFF5B4DE8.toInt()

    /** -1 = indeterminate (spinning arc); 0..100 = determinate sweep. */
    var progress: Int = -1
        set(value) { field = value; invalidate() }

    /** When false, draws only the filled circle behind the icon — no track,
     *  no arc. Used for the plain start/done flashes that intentionally show
     *  no progress at all. */
    var showRing: Boolean = true
        set(value) { field = value; invalidate() }

    private var spinAngle = 0f
    private var spinAnimator: ValueAnimator? = null

    fun setFillGradient(start: Int, end: Int) {
        fillStart = start; fillEnd = end
        rebuildShader()
        invalidate()
    }

    private fun rebuildShader() {
        if (width == 0 || height == 0) return
        fillPaint.shader = android.graphics.LinearGradient(
            0f, 0f, width.toFloat(), height.toFloat(),
            fillStart, fillEnd, Shader.TileMode.CLAMP
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val inset = ringStrokeWidth
        bounds.set(inset, inset, w - inset, h - inset)
        rebuildShader()
    }

    fun startSpin() {
        if (spinAnimator != null) return
        progress = -1
        spinAnimator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1100
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { spinAngle = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun stopSpin() {
        spinAnimator?.cancel()
        spinAnimator = null
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawOval(bounds, fillPaint)
        if (!showRing) return
        canvas.drawOval(bounds, trackPaint)
        if (progress in 0..100) {
            canvas.drawArc(bounds, -90f, 360f * (progress / 100f), false, progressPaint)
        } else {
            canvas.drawArc(bounds, spinAngle, 90f, false, progressPaint)
        }
    }
}
