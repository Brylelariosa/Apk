package com.zipapkbuilder.model

import java.io.File

/**
 * One download the Download Manager knows about — everything the manager UI
 * needs to render a row and everything the download engine needs to run it,
 * bundled together so multiple downloads can each have their own independent
 * pause/cancel/progress state instead of sharing one set of flags (only one
 * download could be tracked at a time before this existed). Every field is
 * `@Volatile`: written from whichever download-worker thread is running this
 * task, read from the main thread by the Download Manager dialog's periodic
 * refresh — `@Volatile` is sufficient for that single-writer/single-reader-role
 * pattern without needing a lock.
 *
 * [resolveUrl] is a lambda rather than a fixed URL because GitHub's
 * artifact/log redirect URLs are short-lived signed links, so it needs to be
 * re-resolved on every connection attempt, not just once when the task is
 * created.
 *
 * [onSuccess] runs on the download-worker thread once the raw transfer and
 * integrity check both succeed — this is where the "save to Downloads, log
 * the result" logic for each of the two download kinds (artifact ZIP,
 * build-log ZIP) plugs in.
 *
 * [restoreInfo], if non-null, is the data "recipe" ([DownloadRestoreInfo])
 * that produced [resolveUrl]/[onSuccess] — see its own kdoc. It's what lets
 * [com.zipapkbuilder.feature.download.DownloadPersistence] persist this task
 * and rebuild an equivalent one after a process restart, since the lambdas
 * themselves can't be serialized.
 */
class DownloadTask(
    val id: String,
    val displayName: String,
    val destFile: File,
    val resolveUrl: () -> String,
    val onSuccess: (DownloadTask) -> Unit,
    val restoreInfo: DownloadRestoreInfo? = null,
    val createdAtMs: Long = System.currentTimeMillis()
) {
    enum class Status { QUEUED, CONNECTING, DOWNLOADING, PAUSED, RETRYING, WAITING_FOR_NETWORK, VERIFYING, SAVING, COMPLETED, FAILED, CANCELLED }

    @Volatile var status: Status = Status.QUEUED
    @Volatile var downloadedBytes: Long = 0L
    @Volatile var totalBytes: Long = -1L
    @Volatile var speedBps: Long = 0L
    @Volatile var etaSeconds: Long = -1L
    @Volatile var detailText: String = "Queued…"
    @Volatile var errorMessage: String? = null
    @Volatile var savedPath: String? = null

    // ETag / Last-Modified captured from the most recent successful connect —
    // see DownloadPersistence and DownloadEngine's resume-validation kdoc.
    // GitHub's artifact/log endpoints don't expose a pre-download content hash
    // (unlike a fixed-content CDN object), so there is no "sha" field here to
    // pre-verify against; post-download integrity is instead verified via a
    // full ZIP CRC-32 check (see DownloadIntegrity) once the transfer completes.
    @Volatile var etag: String? = null
    @Volatile var lastModified: String? = null

    // Informational only — persisted so a restored task's row can show how many
    // retries it had accumulated before an interruption. The actual retry *budget*
    // is always a fresh local counter inside performResumableDownload for any given
    // worker run, restored or not: resetting the retry budget on every fresh worker
    // (including one started by a restore) is the correct behavior, not a bug — a
    // device that happened to get killed after 4 retries shouldn't immediately hit
    // "gave up after 5" on its very first attempt post-restart.
    @Volatile var retryCount: Int = 0

    @Volatile var lastProgressAtMs: Long = System.currentTimeMillis()

    // Read by the download engine's loop; set by the manager UI's
    // per-row Pause/Resume/Cancel buttons.
    @Volatile var pauseRequested: Boolean = false
    @Volatile var cancelRequested: Boolean = false

    /**
     * True while a [com.zipapkbuilder.feature.download.DownloadQueue] worker
     * thread currently owns this task (claimed for execution through to a
     * terminal state) — as opposed to a task that's merely sitting in the
     * in-memory list with no live worker behind it, which happens for every
     * task restored from [com.zipapkbuilder.feature.download.DownloadPersistence]
     * after a process restart (there is, by definition, no surviving worker
     * thread to reattach to). [com.zipapkbuilder.feature.download.DownloadQueue.resume]
     * checks this to decide whether un-pausing a task just needs to flip
     * [pauseRequested] (a live worker is already blocked waiting on exactly
     * that) or needs to submit a fresh worker (nothing is currently running it).
     */
    @Volatile var workerActive: Boolean = false

    val isTerminal: Boolean
        get() = status == Status.COMPLETED || status == Status.FAILED || status == Status.CANCELLED
}
