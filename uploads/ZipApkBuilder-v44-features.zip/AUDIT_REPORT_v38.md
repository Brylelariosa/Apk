# Audit Report — v38

Prompted by a launch crash in the new floating upload/download indicator. That
crash is fixed (see below), and the fix prompted a full pass over the rest of
the app for the same class of bug, plus a general threading/leak/lifecycle
sweep. This picks up where `REVIEW_REPORT.md` (v28) left off — v29 through
v37 had not been through a dedicated review pass before this one.

## The crash that triggered this audit

**Symptom:** app crashed immediately on launch, every time, after the v38
floating progress bubble was added.

**Root cause:** `FloatingTransferIndicator` read `activity.resources` in its
constructor. It's built as an eager field on `MainActivity`
(`= FloatingTransferIndicator(this)`), and *all* of MainActivity's eager
fields are initialized before Android attaches the Activity to its Context —
so `resources` isn't available yet at that point, and reading it throws
immediately. `MainActivity` already had one field (`prefs`) using `by lazy`
to sidestep exactly this; the new field didn't follow that precedent.

**Fix:** the density read is now `by lazy`, deferred until the bubble is
actually first shown (well after `onCreate`). Confirmed no other class in the
app has an eager field that touches `activity.resources`, `findViewById`, or
any other attach-dependent call — this was isolated to the one new file.

## Main finding: dialogs shown after the Activity may already be gone

**The pattern:** background thread finishes a fetch → posts to
`mainHandler` → builds and shows a new `AlertDialog` on whatever the main
thread happens to be doing by then. If the user backs out of the app while
that fetch is in flight, the post can run *after* the Activity is
finishing/destroyed, and calling `.show()` on a brand-new dialog at that
point throws `WindowManager.BadTokenException`.

This isn't hypothetical — `BuildFlowController.kt` already had this exact
fix in place for the workflow-trigger picker, with a comment describing the
crash it was written for. That fix just hadn't been applied anywhere else
the same pattern occurs. Note the distinction that made this worth doing
broadly: touching an *existing* view (a TextView's text, this new floating
bubble's own child view) after the Activity is gone is harmless — it's
specifically creating a *new* window via `AlertDialog.show()` that throws.
That distinction is also why the new floating bubble itself needed no
change here: every dialog it opens is gated behind the user actually tapping
it, and a dead Activity's views don't receive taps.

**Fixed** (same one-line guard as the existing precedent,
`if (activity.isFinishing || activity.isDestroyed) return@post`, placed
right before the dialog gets built):

| File | Entry point(s) guarded |
|---|---|
| `ArtifactBrowser.kt` | `browseAllArtifacts()` result dialog |
| `RepoSwitcher.kt` | `showSavedReposDialog()` — both the success and error paths |
| `KeystoreController.kt` | keystore-exists/generate decision dialog |
| `FileManagerController.kt` | `fetchAndBrowse()` → `showBrowserDialog()` (covers most of the file's dialogs in one place), and the file-editor load path |
| `BuildLogViewer.kt` | the run-picker dialog, and the log-viewer dialog |

Verified via a full sweep of every `mainHandler.post` in the codebase
(cross-checked by hand, not just grep — the automated pass threw a couple of
false positives on unrelated later braces) that nothing reachable from a
background thread still builds a dialog unguarded.

## Also checked, no issues found

- **Threading:** both executors (`bgExecutor`, `downloadExecutor`) are
  bounded pools with proper daemon `ThreadFactory`s; no ad-hoc `Thread{}` or
  `thread{}` calls anywhere else. `DownloadTask`'s shared fields are all
  `@Volatile` with a documented single-writer/single-reader design — no race
  conditions.
- **Resource handling:** every stream/connection in `GitHubApi.kt` and
  `DownloadManager.kt` closes via `.use{}` or a `finally { conn.disconnect() }`.
- **The v37 dialog-button refactor:** sampled across all 14
  `dialogWithActions(...)` call sites (File Manager's browser/move/rename/
  delete dialogs, the code editor, Build Log, Artifact Browser, Download
  Manager) — the `lateinit var dlg` + dismiss-inside-each-action contract is
  followed correctly everywhere checked.
- **`BuildTrackingService`:** correct API-level guards for the notification
  channel and `POST_NOTIFICATIONS`, correct manifest declaration.
- **Find-in-file / find-in-log (v31):** both already guard against
  divide-by-zero when cycling matches with zero results — no bug.
- **`!!` usage:** four total in the whole app; the three pre-existing ones
  are all inside a `try/catch(Exception)` so a null would just be swallowed,
  not crash. The one in the new `FloatingTransferIndicator` is safe by
  construction (three fields always set together) but not by the type
  system — left as a minor follow-up, not fixed this pass.
- **Permission gating** (`withStoragePermission`, `withNotificationPermission`):
  correct API-level branching, no logic errors.

## Not covered this pass

Being upfront about scope, matching `KNOWN_LIMITATIONS.md`'s existing style:

- No compiler or emulator is available in this environment — everything
  above is manual review, not a verified build. Please run this through CI
  before trusting it.
- `WorkflowTemplates.kt` and `SettingsDialogController.kt` were checked only
  for the background-dialog pattern (neither uses `mainHandler.post` at all,
  so neither was exposed to it) — not given a full independent read.
- This pass was scoped to crash-class bugs (the two above) rather than a
  ground-up re-read of all ~7,200 lines; v28's `REVIEW_REPORT.md` covers the
  performance/memory-leak angle for everything through v28 and that ground
  wasn't repeated here.
