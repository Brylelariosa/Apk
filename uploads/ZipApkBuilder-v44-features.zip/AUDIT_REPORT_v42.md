# Full Code Audit (v42)

**Status: every item below marked 🐛/🔧/💡/🎨 has been fixed, except where
noted.** This file is kept as the original audit record; see the "Fixed"
notes inline rather than a separate report, so the finding and its
resolution stay next to each other.

A fresh read-through of the whole app as it stood at the time — not a
re-hash of previous reports. Organized by severity/category; each item says
how confident I was and roughly how much it mattered.

---

## 🐛 Bugs

### 1. Pause is silently ignored during RETRYING / WAITING_FOR_NETWORK — likely the real reason pause "takes a while" on a bad connection
**File:** `DownloadEngine.kt` · **Confidence: high — read the code path directly**
**✅ Fixed** — added a shared `awaitUnpauseIfRequested` helper and wired it
into both retry backoffs and the offline wait (previously only the copy
loop checked `pauseRequested`; the other two only checked `cancelRequested`).
Also used to de-duplicate the copy loop's own inline pause handling.

The Pause button is shown (and settable) while a task is `RETRYING` (waiting
out a backoff after a transient error) or `WAITING_FOR_NETWORK` (offline).
Tapping it sets `task.pauseRequested = true`, same as always. But:

- The retry backoff wait — `networkReliability.sleepCancellable(backoffMs) { task.cancelRequested }` —
  only checks `cancelRequested`.
- The offline wait — `networkReliability.waitForNetwork { task.cancelRequested }` —
  only checks `cancelRequested` too.

Neither checks `pauseRequested`. So if you tap Pause while a download happens
to be mid-backoff or mid-offline-wait, **nothing happens** until that phase
ends on its own (backoff caps at 30s; offline wait could be indefinite) —
only then does the loop reach a point that actually checks the flag. Cancel
works instantly in both cases (it *is* checked); only Pause has this gap.

This is a real, reproducible explanation for "pause takes a while" beyond the
UI-responsiveness issue already fixed — on a flaky mobile connection, a
download is disproportionately likely to be sitting in RETRYING right when
you reach for Pause.

**Fix shape:** add `|| task.pauseRequested` (or a small "should stop
waiting" predicate) to both checks, and have the retry/offline-wait exit
paths honor a pause the same way the copy loop does.

### 2. Console-fills-remaining-space layout has no fallback for landscape / small screens
**File:** `activity_main.xml` · **Confidence: high — verified the app isn't orientation-locked**
**✅ Fixed** — reintroduced a `NestedScrollView` wrapper with
`app:fillViewport="true"`, with the direct child at `match_parent` height
(not `wrap_content`) so weight distribution still works when there's room.
Portrait behavior is unchanged (console still fills remaining space,
no visible scroll needed); landscape/small screens now scroll to reach
anything that doesn't fit instead of it being clipped with no way back.

The root was changed from a scrolling `NestedScrollView` to a plain
`LinearLayout`, with the console card taking `layout_weight="1"` to fill
whatever's left below the fixed header/cards/buttons. That's correct and
looks right in portrait. But the manifest has no
`android:screenOrientation="portrait"` lock (only
`configChanges="orientation|screenSize|keyboardHidden"`, which prevents
Activity recreation on rotate but doesn't prevent rotation itself) — so
landscape is reachable.

In landscape, the fixed chrome above the console (header + Pick ZIP card +
Status card + Browse/Build Log row + File Manager button + console's own
header row) adds up to something like 300–340dp, which can easily exceed
total available height in landscape on a phone. Before, everything just
scrolled. Now, with no scrolling container at all, there's a real risk of UI
elements getting compressed/clipped with **no way to reach them** — worse
than the original "have to scroll" complaint this was fixing.

**Fix shape:** wrap the root back in a `NestedScrollView` with
`app:fillViewport="true"`, and give the *scroll view's direct child*
`layout_height="match_parent"` (not `wrap_content`) instead of the plain
`LinearLayout` root. This is the standard Android pattern that gets both
properties at once: fills remaining space when there's room (portrait, the
common case), scrolls when there isn't (landscape, small screens, large
accessibility font scaling).

### 3. Multi-file upload's Cancel only stops the current file, then silently continues with the rest
**Files:** `MainActivity.kt` (`pickUploadFile`) + `FileUploadController.kt` · **Confidence: high**
**✅ Fixed** — the batch loop now checks `uploadCoordinator.uploadCancelled`
before starting each file and `break`s if set, with a fresh reset of that
flag before the batch begins (so a stale `true` left over from some earlier,
unrelated cancelled upload can't block a brand new batch before it even
starts).

`FileUploadController.uploadFileToRepo` resets
`uploadCoordinator.uploadCancelled = false` at the start of every call — and
`pickUploadFile`'s multi-select handler calls it once per selected file, in
a loop, sequentially. If you multi-select 5 files and tap "Cancel Upload" on
the bubble during file 2, that upload correctly aborts — but the loop then
moves on to files 3, 4, 5 and uploads them anyway, since the shared
cancellation flag gets reset back to `false` for each new file. A user
tapping Cancel almost certainly expects the *whole batch* to stop.

This is a direct side effect of unifying FileManager uploads onto the shared
`UploadCoordinator` (previously FileManager uploads couldn't be cancelled at
all, so this specific failure mode didn't exist yet either — it's new, not
worse than before in the sense that cancellation exists now where it didn't,
but it doesn't do what a user would expect from a "Cancel" button).

**Fix shape:** check `uploadCoordinator.uploadCancelled` at the top of each
loop iteration in `pickUploadFile` and `break` if true, rather than relying
on each call to reset it.

### 4. Large-file strategy differs between the two upload paths — File Manager rejects what Build accepts
**Files:** `FileUploadController.kt` vs `BuildUploadCoordinator.kt` · **Confidence: high**
**✅ Fixed** — `FileUploadController` now branches on size exactly like
`BuildUploadCoordinator.executeUpload` does: Contents API up to 1MB, Git
Data API above that (up to ~99MB). Also added an optional `commitMessage`
parameter to `UploadCoordinator.uploadViaGitDataApi` (defaulting to the
existing build-flow message) so the File Manager path's large-file commits
correctly carry `[skip ci]` — the build flow's large-file commits must
never carry it (that's the one that's supposed to trigger the workflow),
which is why this needed to be a parameter rather than just changing the
hardcoded string.

Original finding, for reference: Build ZIP upload switched to the Git Data
API automatically for anything over 1MB (up to ~99MB), while File Manager
upload hard-rejected anything over 50MB outright and never used the Git
Data API path at all — so a 60MB file failed from File Manager but the same
60MB file, as the build ZIP, would have succeeded. Leftover gap from
unifying the *retry/progress/cancellation* machinery without also unifying
the *large-file strategy* between the two paths.

### 5. (minor) No size guard before syntax-highlighting a file in the editor
**File:** `FileEditorController.kt` · **Confidence: medium — theoretical until tested on a genuinely large file**
**❌ False positive — already handled.** On closer inspection while
implementing the fix, found the guard already exists
(`if (!isBinary && content.length < 200_000)` before calling
`applySyntaxHighlighting`) — I simply hadn't read far enough into the file
during the original audit pass to see it. No change needed; noting this
here rather than silently dropping it, since claiming a fix for something
that was never broken would be its own kind of inaccuracy.

---

## 🔧 Code improvements

### `hasEnoughStorage` only checks the cache directory, not the final Downloads destination
**File:** `DownloadEngine.kt`
**✅ Fixed** — now also checks `Environment.getExternalStoragePublicDirectory(DIRECTORY_DOWNLOADS)`'s
free space, not just the internal cache dir.

### Shared `uploadCancelled` flag remains instance-wide, not per-upload
**File:** `UploadCoordinator.kt`
**↔️ Not changed — the concrete symptom (bug #3) is fixed, the underlying
design isn't.** Giving each upload its own cancellation flag instead of one
shared instance-wide flag would be a real architecture change (touching
`UploadProgressHandle`, `withUploadRetry`, and every `isCancelled` callback
threaded through `GitHubApi.uploadStreamingBase64`), bigger than this pass's
scope. Still worth doing eventually; left as a known limitation.

### `FloatingTransferIndicator`'s three-field invariant relies on `!!`, not the type system
**File:** `FloatingTransferIndicator.kt`
**✅ Fixed** — `container`/`ring`/`icon` (three separately-nullable fields)
replaced with one nullable `Views` data class holding all three, so
"always set/unset together" is now structural rather than conventional. All
call sites were unaffected — they only ever destructured the return value
(`val (c, r, i) = ensureCreated()`), which works identically against a data
class as it did against the old `Triple`.

---

## 💡 Feature ideas

- **"Select All" in the multi-select Delete dialog** (`FileOperationController.showDeleteDialog`) —
  **✅ Added.** A neutral "Select All" button that toggles to "Deselect All"
  and checks/unchecks every row in the list.
- **A moved/renamed file's editor session doesn't follow it** — **not
  investigated this pass** (flagged as needing a deliberate test, not a
  known bug — leaving it as an open question rather than guessing at a fix
  for something unconfirmed).
- **Warn before opening a very large file in the editor** — **not added.**
  Turned out to be unnecessary: bug #5 above was a false positive — the
  200KB syntax-highlighting guard already exists and already degrades
  gracefully (still opens and is still editable, just without coloring)
  without needing a separate warning prompt on top.

---

## 🎨 UI notes

- **Owner chip text (9sp)** — **✅ Bumped back to 10sp** (its pre-compaction
  size) as a safe, low-cost legibility restore.
- **Landscape safety net** — **✅ Fixed**, see bug #2.
- Everything else UI-wise (spacing, button sizing, console fill behavior in
  portrait) looked consistent and correct on inspection — no other visual
  issues found without an actual device/emulator to check against.

---

## What I did *not* find

Worth stating explicitly rather than leaving implicit: no new issues in
`DownloadPersistence`/`DownloadQueue`'s restore-after-restart logic, no
new URL-encoding gaps (the centralized builders in `GitHubApi` still cover
every call site), no threading/race issues beyond what's already discussed
above, and no balance/structural errors in any of the 49 Kotlin files
(all still brace/paren-balanced). The last real compile error found (the
`downloadEngine`/`downloadQueue` recursive type-inference issue) was fixed
and hasn't recurred anywhere else with the same shape.

## Confidence & method

This was a manual read-through — no compiler, no emulator, no static
analyzer available in this environment. "High confidence" items above were
traced through the actual code path by hand (I can point to the exact lines
that cause each one). Everything is worth double-checking against a real
build/device regardless.
