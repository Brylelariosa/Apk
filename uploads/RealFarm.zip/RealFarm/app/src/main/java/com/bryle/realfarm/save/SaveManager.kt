package com.bryle.realfarm.save

import android.content.Context
import android.util.Log
import com.bryle.realfarm.core.GameState
import com.bryle.realfarm.economy.Bill
import com.bryle.realfarm.economy.BillingSaveState
import com.bryle.realfarm.economy.UtilityType
import com.bryle.realfarm.core.Direction
import com.bryle.realfarm.farming.PlantedCrop
import com.bryle.realfarm.farming.Tool
import com.bryle.realfarm.world.TileType
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Serializes/restores [GameState] to a single JSON file in app-internal storage. Uses org.json
 * (bundled with Android) rather than pulling in a JSON library dependency for what is a small,
 * flat save format.
 */
object SaveManager {

    private const val FILE_NAME = "realfarm_save.json"
    private const val TAG = "SaveManager"

    fun save(context: Context, state: GameState) {
        try {
            val root = JSONObject()

            root.put("day", state.clock.day)
            root.put("minuteOfDay", state.clock.minuteOfDay)
            root.put("money", state.wallet.balance)
            root.put("stamina", state.stamina.toSaveValue())
            root.put("hunger", state.hunger.toSaveValue())
            root.put("missedMeals", state.hunger.missedMealsStreak)
            root.put("isSick", state.health.isSick)
            root.put("sickDays", state.health.sickDaysRemaining)
            root.put("waterCharges", state.farming.waterCharges)

            root.put("playerX", state.player.position.x)
            root.put("playerY", state.player.position.y)
            root.put("facing", state.player.facing.name)
            root.put("selectedTool", state.player.selectedTool.name)
            root.put("selectedCropId", state.player.selectedCropId)

            val quickSlotsJson = JSONArray()
            state.player.quickSlotItemIds.forEach { quickSlotsJson.put(it ?: JSONObject.NULL) }
            root.put("quickSlots", quickSlotsJson)

            val inventoryJson = JSONObject()
            state.inventory.toSaveMap().forEach { (id, qty) -> inventoryJson.put(id, qty) }
            root.put("inventory", inventoryJson)

            val marketJson = JSONObject()
            state.market.toSaveMap().forEach { (id, mult) -> marketJson.put(id, mult.toDouble()) }
            root.put("market", marketJson)

            root.put("billing", billingToJson(state.billing.toSaveState()))
            root.put("world", worldToJson(state))

            context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE).use { stream ->
                stream.write(root.toString().toByteArray())
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save game", e)
        }
    }

    /** Returns true if a save file existed and was applied to [state]. */
    fun load(context: Context, state: GameState): Boolean {
        val file = File(context.filesDir, FILE_NAME)
        if (!file.exists()) return false

        return try {
            val text = file.readText()
            val root = JSONObject(text)

            state.clock.restore(root.getInt("day"), root.getInt("minuteOfDay"))
            state.wallet.restoreFromSave(root.getInt("money"))
            state.stamina.restoreFromSave(root.getDouble("stamina").toFloat())
            state.hunger.restoreFromSave(root.getDouble("hunger").toFloat(), root.getInt("missedMeals"))
            state.health.restoreFromSave(root.getBoolean("isSick"), root.getInt("sickDays"))
            state.farming.restoreWaterCharges(root.getInt("waterCharges"))

            state.player.restorePosition(root.getDouble("playerX").toFloat(), root.getDouble("playerY").toFloat())
            state.player.facing = Direction.valueOf(root.getString("facing"))
            state.player.selectedTool = Tool.valueOf(root.getString("selectedTool"))
            state.player.selectedCropId = root.getString("selectedCropId")

            if (root.has("quickSlots")) {
                val quickSlotsJson = root.getJSONArray("quickSlots")
                for (i in 0 until quickSlotsJson.length()) {
                    val value = quickSlotsJson.get(i)
                    state.player.assignQuickSlot(i, if (value == JSONObject.NULL) null else value as String)
                }
            }

            val inventoryJson = root.getJSONObject("inventory")
            val inventoryMap = mutableMapOf<String, Int>()
            val invKeys = inventoryJson.keys()
            while (invKeys.hasNext()) {
                val key = invKeys.next()
                inventoryMap[key] = inventoryJson.getInt(key)
            }
            state.inventory.restore(inventoryMap)

            val marketJson = root.getJSONObject("market")
            val marketMap = mutableMapOf<String, Float>()
            val marketKeys = marketJson.keys()
            while (marketKeys.hasNext()) {
                val key = marketKeys.next()
                marketMap[key] = marketJson.getDouble(key).toFloat()
            }
            state.market.restore(marketMap)

            state.billing.restore(billingFromJson(root.getJSONObject("billing")))
            worldFromJson(root.getJSONArray("world"), state)

            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load game", e)
            false
        }
    }

    fun hasSave(context: Context): Boolean = File(context.filesDir, FILE_NAME).exists()

    private fun billingToJson(saveState: BillingSaveState): JSONObject {
        val json = JSONObject()
        json.put("waterUsage", saveState.waterUsageUnits.toDouble())
        json.put("electricityUsage", saveState.electricityUsageUnits.toDouble())
        json.put("lastBillingDay", saveState.lastBillingDay)
        json.put("nextBillId", saveState.nextBillId)
        val billsArray = JSONArray()
        for (bill in saveState.bills) {
            val b = JSONObject()
            b.put("id", bill.id)
            b.put("type", bill.type.name)
            b.put("amount", bill.amount)
            b.put("issuedDay", bill.issuedDay)
            b.put("dueDay", bill.dueDay)
            b.put("paid", bill.paid)
            b.put("lateFeeApplied", bill.lateFeeApplied)
            billsArray.put(b)
        }
        json.put("bills", billsArray)
        return json
    }

    private fun billingFromJson(json: JSONObject): BillingSaveState {
        val billsArray = json.getJSONArray("bills")
        val bills = mutableListOf<Bill>()
        for (i in 0 until billsArray.length()) {
            val b = billsArray.getJSONObject(i)
            bills.add(
                Bill(
                    id = b.getInt("id"),
                    type = UtilityType.valueOf(b.getString("type")),
                    amount = b.getInt("amount"),
                    issuedDay = b.getInt("issuedDay"),
                    dueDay = b.getInt("dueDay"),
                    paid = b.getBoolean("paid"),
                    lateFeeApplied = b.getBoolean("lateFeeApplied")
                )
            )
        }
        return BillingSaveState(
            waterUsageUnits = json.getDouble("waterUsage").toFloat(),
            electricityUsageUnits = json.getDouble("electricityUsage").toFloat(),
            lastBillingDay = json.getInt("lastBillingDay"),
            nextBillId = json.getInt("nextBillId"),
            bills = bills
        )
    }

    private fun worldToJson(state: GameState): JSONArray {
        val array = JSONArray()
        state.world.forEachTile { x, y, tile ->
            val t = JSONObject()
            t.put("x", x)
            t.put("y", y)
            t.put("type", tile.type.name)
            val crop = tile.plantedCrop
            if (crop != null) {
                val c = JSONObject()
                c.put("cropId", crop.cropId)
                c.put("growthDays", crop.growthDaysAccumulated)
                c.put("wateredToday", crop.wateredToday)
                c.put("unwateredStreak", crop.daysUnwateredStreak)
                c.put("wilted", crop.wilted)
                t.put("crop", c)
            }
            array.put(t)
        }
        return array
    }

    private fun worldFromJson(array: JSONArray, state: GameState) {
        for (i in 0 until array.length()) {
            val t = array.getJSONObject(i)
            val x = t.getInt("x")
            val y = t.getInt("y")
            val tile = state.world.getTile(x, y) ?: continue
            tile.type = TileType.valueOf(t.getString("type"))
            if (t.has("crop")) {
                val c = t.getJSONObject("crop")
                tile.plantedCrop = PlantedCrop(
                    cropId = c.getString("cropId"),
                    growthDaysAccumulated = c.getInt("growthDays"),
                    wateredToday = c.getBoolean("wateredToday"),
                    daysUnwateredStreak = c.getInt("unwateredStreak"),
                    wilted = c.getBoolean("wilted")
                )
            } else {
                tile.plantedCrop = null
            }
        }
    }
}
