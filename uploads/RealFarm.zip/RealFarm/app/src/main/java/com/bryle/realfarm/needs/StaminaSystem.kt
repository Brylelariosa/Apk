package com.bryle.realfarm.needs

/**
 * Stamina gates how much physical work the player can do in a day, and low stamina is one of
 * the inputs [HealthSystem] uses to decide sickness risk. Restored by sleeping.
 */
class StaminaSystem {

    var stamina: Float = 100f
        private set

    val isExhausted: Boolean get() = stamina <= 15f

    fun drain(amount: Float) {
        stamina = (stamina - amount).coerceIn(0f, 100f)
    }

    fun restore(amount: Float) {
        stamina = (stamina + amount).coerceIn(0f, 100f)
    }

    /** Called once per in-game day from passive hunger/health pressure. */
    fun applyDailyPassiveDrain(hungerCritical: Boolean, isSick: Boolean) {
        var drain = 4f
        if (hungerCritical) drain += 10f
        if (isSick) drain += 8f
        drain(drain)
    }

    /** Sleeping restores most stamina; [fullRestore] is false when electricity is shut off (poor rest). */
    fun sleep(fullRestore: Boolean) {
        restore(if (fullRestore) 70f else 35f)
    }

    fun toSaveValue(): Float = stamina

    fun restoreFromSave(value: Float) {
        stamina = value.coerceIn(0f, 100f)
    }
}
