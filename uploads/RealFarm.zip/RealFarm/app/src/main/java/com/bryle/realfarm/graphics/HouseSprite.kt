package com.bryle.realfarm.graphics

import android.graphics.Color

/**
 * The farmhouse: a single cohesive pixel-art image spanning the whole house footprint (see
 * [com.bryle.realfarm.world.WorldMap.houseWidthTiles]/[com.bryle.realfarm.world.WorldMap.houseHeightTiles]),
 * rather than one small texture repeated per tile — a repeated tile doesn't read as "a building"
 * the way one continuous roof/wall/door image does.
 */
object HouseSprite {

    /** Where the chimney opening sits, as a fraction of the sprite's width/height, so
     *  [com.bryle.realfarm.engine.ActionEffectRenderer]-style particle code can spawn smoke there. */
    const val CHIMNEY_X_FRACTION = 25.5f / 36f
    const val CHIMNEY_TOP_Y_FRACTION = 0f

    private val palette = mapOf(
        'R' to Color.rgb(0x9C, 0x3B, 0x2E), // roof
        'D' to Color.rgb(0x6E, 0x26, 0x1C), // roof shadow / eave trim
        'C' to Color.rgb(0x8A, 0x8A, 0x8A), // chimney
        'W' to Color.rgb(0xD8, 0xC0, 0x9E), // wall
        'S' to Color.rgb(0xC2, 0xA8, 0x84), // wall plank shading
        'K' to Color.rgb(0x5B, 0x38, 0x22), // door
        'N' to Color.rgb(0xE8, 0xC7, 0x4A), // door knob
        'F' to Color.rgb(0x4A, 0x33, 0x22), // window/door frame
        'L' to Color.rgb(0xBF, 0xE3, 0xF2), // window glass
        'M' to Color.rgb(0x4A, 0x33, 0x22)  // window mullions
    )

    private val ROWS = arrayOf(
        "                 DRD    CCC         ",
        "                DRRRD   CCC         ",
        "              DRRRRRRRD CCC         ",
        "            DRRRRRRRRRRRCCC         ",
        "           DRRRRRRRRRRRRCCC         ",
        "         DRRRRRRRRRRRRRRCCCD        ",
        "       DRRRRRRRRRRRRRRRRRRRRRD      ",
        "      DRRRRRRRRRRRRRRRRRRRRRRRD     ",
        "    DRRRRRRRRRRRRRRRRRRRRRRRRRRRD   ",
        "  DRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRD ",
        "RDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDR",
        " DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD ",
        "  SWWWSWWWSWWWSWWWSWWWSWWWSWWWSWWW  ",
        "  SWWWSWWWSWWWSWWWSWWWSWWWSWWWSWWW  ",
        "  SWWWSWWWSWWWSWWWSWWWSWWWSWWWSWWW  ",
        "  SWWFFFFFFFWWFFFFFFFFSWFFFFFFFWWW  ",
        "  SWWFLLMLLFWWFKKKKKKFSWFLLMLLFWWW  ",
        "  SWWFLLMLLFWWFKKKKKKFSWFLLMLLFWWW  ",
        "  SWWFMMMMMFWWFKKKKKKFSWFMMMMMFWWW  ",
        "  SWWFLLMLLFWWFKKKKKKFSWFLLMLLFWWW  ",
        "  SWWFLLMLLFWWFKKKKNKFSWFLLMLLFWWW  ",
        "  SWWFFFFFFFWWFKKKKKKFSWFFFFFFFWWW  ",
        "  SWWWSWWWSWWWFKKKKKKFSWWWSWWWSWWW  ",
        "  SWWWSWWWSWWWFKKKKKKFSWWWSWWWSWWW  "
    )

    val sprite by lazy { PixelSprite(PixelArt.fromRows(ROWS, palette)) }
}
