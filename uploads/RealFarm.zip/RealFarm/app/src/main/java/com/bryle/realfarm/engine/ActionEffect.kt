package com.bryle.realfarm.engine

import com.bryle.realfarm.farming.Tool

/** Records that [tool] was just successfully used on tile ([tileX], [tileY]) at [startMs], so the
 *  renderers can show a brief particle burst + player lunge without the simulation (GameState)
 *  knowing anything about presentation. */
data class ActionEffect(val tool: Tool, val tileX: Int, val tileY: Int, val startMs: Long) {
    companion object {
        const val DURATION_MS = 420L
    }
}

/** 0f at the start of an effect, 1f once it's finished; null if there's no effect playing. */
fun ActionEffect?.progress(nowMs: Long): Float? {
    if (this == null) return null
    val elapsed = nowMs - startMs
    if (elapsed !in 0..ActionEffect.DURATION_MS) return null
    return elapsed.toFloat() / ActionEffect.DURATION_MS
}
