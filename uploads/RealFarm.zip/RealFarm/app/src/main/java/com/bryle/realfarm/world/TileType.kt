package com.bryle.realfarm.world

enum class TileType {
    GRASS,
    TILLED,
    PATH,
    WATER_SOURCE,
    HOUSE
}
