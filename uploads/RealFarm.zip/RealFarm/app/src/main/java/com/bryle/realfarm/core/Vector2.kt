package com.bryle.realfarm.core

import kotlin.math.sqrt

/**
 * Minimal 2D vector used for world positions and movement.
 * Kept dependency-free so it can be reused by any subsystem (rendering, physics, AI).
 */
data class Vector2(val x: Float, val y: Float) {

    operator fun plus(other: Vector2) = Vector2(x + other.x, y + other.y)
    operator fun minus(other: Vector2) = Vector2(x - other.x, y - other.y)
    operator fun times(scalar: Float) = Vector2(x * scalar, y * scalar)

    fun length(): Float = sqrt(x * x + y * y)

    fun normalized(): Vector2 {
        val len = length()
        return if (len < 0.0001f) Vector2(0f, 0f) else Vector2(x / len, y / len)
    }

    companion object {
        val ZERO = Vector2(0f, 0f)
    }
}
