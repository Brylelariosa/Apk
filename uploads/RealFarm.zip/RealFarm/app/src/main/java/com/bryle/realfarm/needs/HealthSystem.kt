package com.bryle.realfarm.needs

import kotlin.random.Random

/**
 * Tracks whether the player is sick. Sickness is not scripted — each new day, risk factors
 * (critical hunger, missed meals, exhaustion, unpaid utility bills) are summed into a probability
 * and rolled against. Being sick slows movement and makes work less efficient until it clears,
 * which recovery is sped up by rest (sleep) or medicine.
 */
class HealthSystem(private val random: Random = Random.Default) {

    companion object {
        private const val BASE_DAILY_RISK = 0.03f
        private const val HUNGER_CRITICAL_RISK = 0.18f
        private const val MISSED_MEAL_RISK_PER = 0.08f
        private const val EXHAUSTION_RISK = 0.15f
        private const val UNPAID_BILL_RISK = 0.12f
    }

    var isSick: Boolean = false
        private set

    var sickDaysRemaining: Int = 0
        private set

    /** Multiplier applied to player movement speed. */
    val speedMultiplier: Float get() = if (isSick) 0.6f else 1f

    /** Multiplier applied to stamina cost of work actions while sick (work is more tiring). */
    val workStaminaCostMultiplier: Float get() = if (isSick) 1.5f else 1f

    data class RiskFactors(
        val hungerCritical: Boolean,
        val missedMealsStreak: Int,
        val exhausted: Boolean,
        val hasUnpaidOverdueBill: Boolean
    )

    /** Call once per new in-game day. Returns true if the player just fell ill. */
    fun evaluateNewDay(factors: RiskFactors): Boolean {
        if (isSick) {
            sickDaysRemaining -= 1
            if (sickDaysRemaining <= 0) {
                isSick = false
                sickDaysRemaining = 0
            }
            return false
        }

        var risk = BASE_DAILY_RISK
        if (factors.hungerCritical) risk += HUNGER_CRITICAL_RISK
        risk += MISSED_MEAL_RISK_PER * factors.missedMealsStreak.coerceAtMost(3)
        if (factors.exhausted) risk += EXHAUSTION_RISK
        if (factors.hasUnpaidOverdueBill) risk += UNPAID_BILL_RISK
        risk = risk.coerceAtMost(0.85f)

        return if (random.nextFloat() < risk) {
            isSick = true
            sickDaysRemaining = 2 + random.nextInt(3) // 2..4 days
            true
        } else {
            false
        }
    }

    /** Resting extra (beyond normal sleep) shaves a day off recovery. */
    fun restExtra() {
        if (isSick) {
            sickDaysRemaining = (sickDaysRemaining - 1).coerceAtLeast(0)
            if (sickDaysRemaining == 0) isSick = false
        }
    }

    /** Returns true if the medicine successfully cured the illness. */
    fun useMedicine(healPower: Float): Boolean {
        if (!isSick) return false
        if (random.nextFloat() < healPower) {
            isSick = false
            sickDaysRemaining = 0
            return true
        }
        // Partial effect even on a "failed" roll — medicine still helps.
        sickDaysRemaining = (sickDaysRemaining - 1).coerceAtLeast(1)
        return false
    }

    fun restoreFromSave(sick: Boolean, daysRemaining: Int) {
        isSick = sick
        sickDaysRemaining = daysRemaining
    }
}
