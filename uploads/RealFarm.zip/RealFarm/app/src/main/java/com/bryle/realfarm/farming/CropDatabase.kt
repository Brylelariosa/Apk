package com.bryle.realfarm.farming

import android.graphics.Color

/** Central, single source of truth for every crop's design values. */
object CropDatabase {

    val ALL: List<CropDefinition> = listOf(
        CropDefinition(
            id = "wheat",
            displayName = "Wheat",
            growDays = 3,
            seedCost = 8,
            basePrice = 14,
            maxUnwateredDays = 2,
            yieldPerHarvest = 3,
            color = Color.rgb(0xE0, 0xC1, 0x4A),
            foodRestoreAmount = 8
        ),
        CropDefinition(
            id = "potato",
            displayName = "Potato",
            growDays = 4,
            seedCost = 12,
            basePrice = 20,
            maxUnwateredDays = 3,
            yieldPerHarvest = 3,
            color = Color.rgb(0xC7, 0x9A, 0x5B),
            foodRestoreAmount = 12
        ),
        CropDefinition(
            id = "corn",
            displayName = "Corn",
            growDays = 5,
            seedCost = 16,
            basePrice = 28,
            maxUnwateredDays = 2,
            yieldPerHarvest = 2,
            color = Color.rgb(0xF4, 0xD0, 0x3F),
            foodRestoreAmount = 14
        ),
        CropDefinition(
            id = "tomato",
            displayName = "Tomato",
            growDays = 6,
            seedCost = 20,
            basePrice = 34,
            maxUnwateredDays = 2,
            yieldPerHarvest = 3,
            color = Color.rgb(0xD3, 0x2F, 0x2F),
            foodRestoreAmount = 10
        ),
        CropDefinition(
            id = "pumpkin",
            displayName = "Pumpkin",
            growDays = 9,
            seedCost = 30,
            basePrice = 55,
            maxUnwateredDays = 3,
            yieldPerHarvest = 1,
            color = Color.rgb(0xE8, 0x7A, 0x1E),
            foodRestoreAmount = 20
        )
    )

    private val byId = ALL.associateBy { it.id }

    fun get(id: String): CropDefinition =
        byId[id] ?: throw IllegalArgumentException("Unknown crop id: $id")

    fun tryGet(id: String): CropDefinition? = byId[id]
}
