package com.bryle.realfarm.economy

enum class UtilityType { WATER, ELECTRICITY }

data class Bill(
    val id: Int,
    val type: UtilityType,
    val amount: Int,
    val issuedDay: Int,
    val dueDay: Int,
    var paid: Boolean = false,
    var lateFeeApplied: Boolean = false
) {
    fun isOverdue(currentDay: Int): Boolean = !paid && currentDay > dueDay
}
