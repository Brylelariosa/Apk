package com.bryle.realfarm.farming

/**
 * Design-time definition of a crop type. One instance per crop exists for the whole game
 * (see [CropDatabase]); per-tile growth state lives separately in [PlantedCrop].
 */
data class CropDefinition(
    val id: String,
    val displayName: String,
    val growDays: Int,
    val seedCost: Int,
    val basePrice: Int,
    val maxUnwateredDays: Int,
    val yieldPerHarvest: Int,
    val color: Int,
    val foodRestoreAmount: Int
)
