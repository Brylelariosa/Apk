package com.bryle.realfarm.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.bryle.realfarm.core.GameEngine
import com.bryle.realfarm.economy.UtilityType
import com.bryle.realfarm.engine.GameView

object BillsDialog {

    fun show(context: Context, engine: GameEngine, gameView: GameView) {
        val dialog = AlertDialog.Builder(context)
            .setTitle("Bills")
            .setPositiveButton("Close", null)
            .create()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 24)
        }
        val scroll = ScrollView(context)
        scroll.addView(container)
        dialog.setView(scroll)

        fun refresh() {
            container.removeAllViews()

            val moneyView = TextView(context).apply {
                text = "Money: \$${engine.state.wallet.balance}"
                setTextColor(Color.WHITE)
                textSize = 16f
            }
            container.addView(moneyView)

            val unpaid = engine.state.billing.unpaidBills()
            if (unpaid.isEmpty()) {
                container.addView(TextView(context).apply {
                    text = "\nNo unpaid bills right now."
                    setTextColor(Color.LTGRAY)
                })
                return
            }

            val currentDay = engine.state.clock.day
            for (bill in unpaid) {
                val label = if (bill.type == UtilityType.WATER) "Water Bill" else "Electricity Bill"
                val overdue = bill.isOverdue(currentDay)
                val displayAmount = if (bill.lateFeeApplied) (bill.amount * 1.2f).toInt() else bill.amount
                val subtitle = when {
                    overdue -> "OVERDUE — service shut off, late fee added (was due day ${bill.dueDay})"
                    else -> "Due by day ${bill.dueDay} (today is day $currentDay)"
                }
                addRow(
                    context, container,
                    title = "$label — \$$displayAmount",
                    subtitle = subtitle,
                    buttonLabel = "Pay",
                    enabled = engine.state.wallet.balance >= displayAmount
                ) {
                    toastResult(context, engine.payBill(bill.id))
                    refresh()
                }
            }
        }

        refresh()
        dialog.setOnDismissListener { gameView.syncSelectedTool() }
        dialog.show()
    }
}
