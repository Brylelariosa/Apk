package com.bryle.realfarm.graphics

import android.graphics.Color
import com.bryle.realfarm.world.TileType

/** Pixel-art ground textures, one per [TileType]. Water animates between two shimmer frames. */
object TileSprites {

    private val grassPalette = mapOf(
        'g' to Color.rgb(0x6B, 0xA5, 0x3A),
        'd' to Color.rgb(0x54, 0x86, 0x2C),
        'l' to Color.rgb(0x86, 0xC1, 0x52)
    )
    private val tilledPalette = mapOf(
        'b' to Color.rgb(0x8A, 0x5A, 0x35),
        'f' to Color.rgb(0x6B, 0x43, 0x26)
    )
    private val pathPalette = mapOf(
        't' to Color.rgb(0xC2, 0xA9, 0x77),
        's' to Color.rgb(0x9E, 0x8A, 0x60)
    )
    private val waterPalette = mapOf(
        'w' to Color.rgb(0x2E, 0x86, 0xC1),
        'h' to Color.rgb(0x6B, 0xB8, 0xE8)
    )
    private val housePalette = mapOf(
        'r' to Color.rgb(0x7A, 0x2E, 0x2E),
        'w' to Color.rgb(0xA1, 0x88, 0x7C),
        'l' to Color.rgb(0xBF, 0xE3, 0xF2),
        'd' to Color.rgb(0x4A, 0x33, 0x22)
    )

    private val GRASS_ROWS = arrayOf(
        "gggggggggggg",
        "gggdgggggggg",
        "ggggggglgggg",
        "gggggggggggg",
        "ggggdggggggg",
        "gggggggggggl",
        "gggggggggggg",
        "gdggggggggdg",
        "gggggggggggg",
        "ggglgggggggg",
        "gggggggdgggg",
        "gggggggggggg"
    )
    private val TILLED_ROWS = arrayOf(
        "bbbbbbbbbbbb",
        "ffffffffffff",
        "bbbbbbbbbbbb",
        "bbbbbbbbbbbb",
        "ffffffffffff",
        "bbbbbbbbbbbb",
        "bbbbbbbbbbbb",
        "ffffffffffff",
        "bbbbbbbbbbbb",
        "bbbbbbbbbbbb",
        "ffffffffffff",
        "bbbbbbbbbbbb"
    )
    private val PATH_ROWS = arrayOf(
        "tttttttttttt",
        "ttsttttttttt",
        "ttttttttsttt",
        "tttttttttttt",
        "ttttsttttttt",
        "tttttttttttt",
        "tttttttsttts",
        "tttttttttttt",
        "tstttttttttt",
        "tttttttttttt",
        "ttttttsttttt",
        "tttttttttttt"
    )
    private val WATER_0_ROWS = arrayOf(
        "wwwwwwwwwwww",
        "wwhhwwwwhhww",
        "wwwwwwwwwwww",
        "wwwwhhwwwwww",
        "wwwwwwwwwwww",
        "wwwwwwwwhhww",
        "wwhhwwwwwwww",
        "wwwwwwwwwwww",
        "wwwwwhhwwwww",
        "wwwwwwwwwwww",
        "wwwwwwwwhhww",
        "wwwwwwwwwwww"
    )
    private val WATER_1_ROWS = arrayOf(
        "wwwwwwwwwwww",
        "wwwwhhwwwwww",
        "wwwwwwwwhhww",
        "wwwwwwwwwwww",
        "wwhhwwwwwwww",
        "wwwwwwwwwwww",
        "wwwwwwhhwwww",
        "wwwwwwwwwwww",
        "wwhhwwwwwwww",
        "wwwwwwwwhhww",
        "wwwwwwwwwwww",
        "wwwwwhhwwwww"
    )
    private val HOUSE_ROWS = arrayOf(
        "rrrrrrrrrrrr",
        "rrrrrrrrrrrr",
        "wrrrrrrrrrrw",
        "wwwwwwwwwwww",
        "wwwlllwwwwww",
        "wwwlllwwwwww",
        "wwwwwwwwwwww",
        "wwwwwwwwwwww",
        "wwwwddddwwww",
        "wwwwddddwwww",
        "wwwwddddwwww",
        "wwwwddddwwww"
    )

    private val grass by lazy { PixelSprite(PixelArt.fromRows(GRASS_ROWS, grassPalette)) }
    private val tilled by lazy { PixelSprite(PixelArt.fromRows(TILLED_ROWS, tilledPalette)) }
    private val path by lazy { PixelSprite(PixelArt.fromRows(PATH_ROWS, pathPalette)) }
    private val water0 by lazy { PixelSprite(PixelArt.fromRows(WATER_0_ROWS, waterPalette)) }
    private val water1 by lazy { PixelSprite(PixelArt.fromRows(WATER_1_ROWS, waterPalette)) }
    private val house by lazy { PixelSprite(PixelArt.fromRows(HOUSE_ROWS, housePalette)) }

    fun spriteFor(type: TileType, waterFrame: Int): PixelSprite = when (type) {
        TileType.GRASS -> grass
        TileType.TILLED -> tilled
        TileType.PATH -> path
        TileType.WATER_SOURCE -> if (waterFrame == 0) water0 else water1
        TileType.HOUSE -> house
    }
}
