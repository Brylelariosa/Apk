package com.bryle.realfarm.economy

/**
 * Meters water and electricity usage and turns it into periodic bills, mirroring a real utility
 * account: usage accrues silently, gets invoiced on a cycle, and ignoring the invoice past its
 * due date causes a service shutoff plus a late fee rather than being a no-op.
 */
class BillingSystem {

    companion object {
        const val BILLING_PERIOD_DAYS = 7
        const val GRACE_PERIOD_DAYS = 3
        const val WATER_RATE_PER_UNIT = 2
        const val ELECTRICITY_RATE_PER_UNIT = 3
        const val DAILY_ELECTRICITY_BASELINE_UNITS = 3f
        const val LATE_FEE_MULTIPLIER = 1.2f
    }

    private var waterUsageUnits = 0f
    private var electricityUsageUnits = 0f
    private var lastBillingDay = 0
    private var nextBillId = 1

    private val _bills = mutableListOf<Bill>()
    val bills: List<Bill> get() = _bills

    val isWaterShutOff: Boolean get() = _bills.any { it.type == UtilityType.WATER && it.paid.not() && it.lateFeeApplied }
    val isElectricityShutOff: Boolean get() = _bills.any { it.type == UtilityType.ELECTRICITY && it.paid.not() && it.lateFeeApplied }
    val hasAnyOverdueUnpaidBill: Boolean get() = isWaterShutOff || isElectricityShutOff

    fun recordWaterUsage(units: Float) {
        waterUsageUnits += units
    }

    fun recordDailyElectricityBaseline() {
        electricityUsageUnits += DAILY_ELECTRICITY_BASELINE_UNITS
    }

    /** Call once per new in-game day: issues bills on the cycle boundary and applies late fees to overdue ones. */
    fun onNewDay(currentDay: Int) {
        if (currentDay - lastBillingDay >= BILLING_PERIOD_DAYS) {
            issueBill(UtilityType.WATER, waterUsageUnits, WATER_RATE_PER_UNIT, currentDay)
            issueBill(UtilityType.ELECTRICITY, electricityUsageUnits, ELECTRICITY_RATE_PER_UNIT, currentDay)
            waterUsageUnits = 0f
            electricityUsageUnits = 0f
            lastBillingDay = currentDay
        }

        for (bill in _bills) {
            if (bill.isOverdue(currentDay) && !bill.lateFeeApplied) {
                bill.lateFeeApplied = true
            }
        }
    }

    private fun issueBill(type: UtilityType, usageUnits: Float, ratePerUnit: Int, currentDay: Int) {
        val amount = (usageUnits * ratePerUnit).let { kotlin.math.ceil(it).toInt() }.coerceAtLeast(0)
        if (amount == 0) return
        _bills.add(
            Bill(
                id = nextBillId++,
                type = type,
                amount = amount,
                issuedDay = currentDay,
                dueDay = currentDay + GRACE_PERIOD_DAYS
            )
        )
    }

    fun unpaidBills(): List<Bill> = _bills.filter { !it.paid }

    /** Returns the amount actually charged (includes late fee if applicable), or null if the wallet couldn't cover it / bill missing. */
    fun payBill(billId: Int, wallet: Wallet): Int? {
        val bill = _bills.find { it.id == billId && !it.paid } ?: return null
        val finalAmount = if (bill.lateFeeApplied) (bill.amount * LATE_FEE_MULTIPLIER).toInt() else bill.amount
        if (!wallet.trySpend(finalAmount)) return null
        bill.paid = true
        return finalAmount
    }

    fun toSaveState(): BillingSaveState = BillingSaveState(
        waterUsageUnits, electricityUsageUnits, lastBillingDay, nextBillId,
        _bills.map { it.copy() }
    )

    fun restore(state: BillingSaveState) {
        waterUsageUnits = state.waterUsageUnits
        electricityUsageUnits = state.electricityUsageUnits
        lastBillingDay = state.lastBillingDay
        nextBillId = state.nextBillId
        _bills.clear()
        _bills.addAll(state.bills)
    }
}

data class BillingSaveState(
    val waterUsageUnits: Float,
    val electricityUsageUnits: Float,
    val lastBillingDay: Int,
    val nextBillId: Int,
    val bills: List<Bill>
)
