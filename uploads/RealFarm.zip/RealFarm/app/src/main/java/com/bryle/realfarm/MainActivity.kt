package com.bryle.realfarm

import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.bryle.realfarm.engine.GameView
import com.bryle.realfarm.save.SaveManager
import com.bryle.realfarm.ui.BillsDialog
import com.bryle.realfarm.ui.InventoryDialog
import com.bryle.realfarm.ui.ShopDialog

class MainActivity : AppCompatActivity() {

    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        enableImmersiveMode()

        gameView = findViewById(R.id.gameView)
        val menuButton = findViewById<View>(R.id.menuButton)
        menuButton.setOnClickListener { showMenu() }

        if (SaveManager.hasSave(this)) {
            val loaded = SaveManager.load(this, gameView.engine.state)
            if (loaded) {
                gameView.syncSelectedTool()
                Toast.makeText(this, "Save loaded", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // The system nav/status bars can reappear after a swipe or when returning from another
        // app; re-hiding them here (the standard sticky-immersive pattern) keeps the game
        // fullscreen without the player having to do anything.
        if (hasFocus) enableImmersiveMode()
    }

    /** Hides the status bar and on-screen navigation bar so the game uses the full screen,
     *  matching how a dedicated game (rather than a regular app) behaves. A swipe from the
     *  screen edge still reveals them temporarily if the player needs to. */
    private fun enableImmersiveMode() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    override fun onResume() {
        super.onResume()
        gameView.resume()
    }

    override fun onPause() {
        super.onPause()
        gameView.pause()
        SaveManager.save(this, gameView.engine.state)
    }

    private fun showMenu() {
        val options = arrayOf("Shop", "Inventory", "Bills", "Sleep until morning", "Save game")
        AlertDialog.Builder(this)
            .setTitle("Menu")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> ShopDialog.show(this, gameView.engine, gameView)
                    1 -> InventoryDialog.show(this, gameView.engine, gameView)
                    2 -> BillsDialog.show(this, gameView.engine, gameView)
                    3 -> {
                        gameView.engine.sleep()
                        Toast.makeText(this, "You wake up the next morning", Toast.LENGTH_SHORT).show()
                    }
                    4 -> {
                        SaveManager.save(this, gameView.engine.state)
                        Toast.makeText(this, "Game saved", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }
}
