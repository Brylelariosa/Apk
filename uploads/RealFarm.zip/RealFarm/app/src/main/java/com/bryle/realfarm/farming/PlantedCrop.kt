package com.bryle.realfarm.farming

/**
 * Mutable runtime state for a crop growing on a single tile.
 * [growthDaysAccumulated] only advances on days the tile was watered, which is what
 * ties watering (and therefore the water bill) directly to farm output.
 */
data class PlantedCrop(
    val cropId: String,
    var growthDaysAccumulated: Int = 0,
    var wateredToday: Boolean = false,
    var daysUnwateredStreak: Int = 0,
    var wilted: Boolean = false
) {
    fun isReadyToHarvest(definition: CropDefinition): Boolean =
        !wilted && growthDaysAccumulated >= definition.growDays

    fun growthFraction(definition: CropDefinition): Float =
        (growthDaysAccumulated.toFloat() / definition.growDays.toFloat()).coerceIn(0f, 1f)
}
