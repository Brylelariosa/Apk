package com.bryle.realfarm.graphics

/**
 * Tracks elapsed wall-clock time so renderers can pick animation frames (walk cycles, water
 * shimmer, idle sway). This is deliberately separate from [com.bryle.realfarm.time.GameClock],
 * which tracks in-game day/time on its own scale and drives simulation logic. Keeping this here
 * — owned by [com.bryle.realfarm.engine.GameView] alongside its other presentation-only state
 * like the toast timer — means [com.bryle.realfarm.core.GameState] stays free of rendering
 * concerns.
 */
class AnimationClock {

    var elapsedMs: Float = 0f
        private set

    fun tick(deltaSeconds: Float) {
        elapsedMs += deltaSeconds * 1000f
    }

    /** Index in `0 until frameCount`, advancing one step every [msPerFrame] milliseconds. */
    fun frame(frameCount: Int, msPerFrame: Int): Int {
        if (frameCount <= 1) return 0
        return (elapsedMs / msPerFrame).toInt() % frameCount
    }
}
