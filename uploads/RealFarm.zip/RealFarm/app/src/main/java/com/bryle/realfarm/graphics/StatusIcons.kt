package com.bryle.realfarm.graphics

import android.graphics.Color

/** Small pixel-art badges drawn over world objects to show status (e.g. a crop was watered today). */
object StatusIcons {

    private val dropletPalette = mapOf(
        'w' to Color.rgb(0x5B, 0x9C, 0xD6),
        'h' to Color.rgb(0xA6, 0xD3, 0xF5)
    )

    private val DROPLET_ROWS = arrayOf(
        "  w  ",
        " www ",
        " wwh ",
        " www ",
        "  w  "
    )

    val droplet by lazy { PixelSprite(PixelArt.fromRows(DROPLET_ROWS, dropletPalette)) }
}
