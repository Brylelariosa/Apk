package com.bryle.realfarm.farming

enum class Tool(val label: String) {
    HAND("Hand"),
    HOE("Hoe"),
    WATERING_CAN("Water"),
    SEED_BAG("Seeds")
}
