package com.bryle.realfarm.inventory

enum class ItemCategory { SEED, CROP, FOOD, MEDICINE }

/**
 * Every ownable item in the game. Seeds and crops are generated per crop id in [CropDatabase]
 * so this class stays generic rather than hard-coding one enum entry per crop.
 */
data class ItemType(
    val id: String,
    val displayName: String,
    val category: ItemCategory,
    /** Hunger restored when eaten; 0 for non-food items. */
    val hungerRestore: Int = 0,
    /** Only relevant for MEDICINE: chance (0..1) it shortens/cures sickness when used. */
    val healPower: Float = 0f,
    val buyPrice: Int = 0
) {
    companion object {
        fun seedFor(cropId: String, cost: Int) =
            ItemType(id = "seed_$cropId", displayName = "Seed", category = ItemCategory.SEED, buyPrice = cost)

        fun cropFor(cropId: String, hungerRestore: Int) =
            ItemType(id = "crop_$cropId", displayName = "Crop", category = ItemCategory.CROP, hungerRestore = hungerRestore)

        val BREAD = ItemType("food_bread", "Bread", ItemCategory.FOOD, hungerRestore = 30, buyPrice = 6)
        val CHEESE = ItemType("food_cheese", "Cheese", ItemCategory.FOOD, hungerRestore = 22, buyPrice = 10)
        val MEDICINE = ItemType("medicine", "Medicine", ItemCategory.MEDICINE, healPower = 0.9f, buyPrice = 25)

        val SHOP_FOOD = listOf(BREAD, CHEESE)
        val SHOP_MEDICINE = listOf(MEDICINE)
    }
}
