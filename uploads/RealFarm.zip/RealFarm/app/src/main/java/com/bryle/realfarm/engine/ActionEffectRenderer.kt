package com.bryle.realfarm.engine

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.bryle.realfarm.farming.Tool
import com.bryle.realfarm.world.WorldMap
import kotlin.math.cos
import kotlin.math.sin

/**
 * Draws the brief particle burst that plays when a tool is used — dirt clods for the hoe,
 * droplets for the watering can, a sparkle for planting, a leaf burst for harvesting. Deliberately
 * NOT anti-aliased (chunky squares) so it matches the rest of the pixel-art rendering instead of
 * looking like a smooth vector effect. Pure rendering: takes the current [ActionEffect] (if any)
 * and draws it; owns no state itself.
 */
class ActionEffectRenderer {

    private val dirtPaint = Paint().apply { color = Color.rgb(0x6B, 0x43, 0x26) }
    private val waterPaint = Paint().apply { color = Color.rgb(0x5B, 0x9C, 0xD6) }
    private val sparklePaint = Paint().apply { color = Color.rgb(0xF4, 0xD0, 0x3F) }
    private val leafPaint = Paint().apply { color = Color.rgb(0x6B, 0xA5, 0x3A) }

    fun draw(canvas: Canvas, effect: ActionEffect?, camera: Camera2D, nowMs: Long) {
        if (effect == null) return
        val progress = effect.progress(nowMs) ?: return
        val tileSize = WorldMap.TILE_SIZE
        val cx = camera.worldToScreenX(effect.tileX * tileSize + tileSize / 2f)
        val cy = camera.worldToScreenY(effect.tileY * tileSize + tileSize / 2f)
        val paint = when (effect.tool) {
            Tool.HOE -> dirtPaint
            Tool.WATERING_CAN -> waterPaint
            Tool.SEED_BAG -> sparklePaint
            Tool.HAND -> leafPaint
        }
        paint.alpha = (255 * (1f - progress)).toInt().coerceIn(0, 255)

        val particleCount = 6
        val spread = tileSize * 0.4f * progress
        val particleSize = 8f * (1f - progress * 0.5f)
        for (i in 0 until particleCount) {
            val angle = (i.toFloat() / particleCount) * (2f * Math.PI.toFloat())
            val px = cx + cos(angle) * spread
            val py = cy + sin(angle) * spread - spread * 0.3f // slight upward arc
            canvas.drawRect(
                px - particleSize / 2f, py - particleSize / 2f,
                px + particleSize / 2f, py + particleSize / 2f,
                paint
            )
        }
    }
}
