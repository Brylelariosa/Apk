package com.bryle.realfarm.engine

import com.bryle.realfarm.core.Vector2
import com.bryle.realfarm.world.WorldMap

/**
 * Converts world-space coordinates to screen-space for rendering. Centers on a target
 * (the player) but clamps so the camera never shows past the edge of the map.
 */
class Camera2D {

    var viewportWidth: Float = 0f
        private set
    var viewportHeight: Float = 0f
        private set

    private var offsetX = 0f
    private var offsetY = 0f

    fun setViewportSize(width: Float, height: Float) {
        viewportWidth = width
        viewportHeight = height
    }

    fun follow(target: Vector2, world: WorldMap) {
        var camX = target.x - viewportWidth / 2f
        var camY = target.y - viewportHeight / 2f

        val maxX = (world.worldPixelWidth() - viewportWidth).coerceAtLeast(0f)
        val maxY = (world.worldPixelHeight() - viewportHeight).coerceAtLeast(0f)

        camX = camX.coerceIn(0f, maxX)
        camY = camY.coerceIn(0f, maxY)

        offsetX = camX
        offsetY = camY
    }

    fun worldToScreenX(worldX: Float): Float = worldX - offsetX
    fun worldToScreenY(worldY: Float): Float = worldY - offsetY
}
