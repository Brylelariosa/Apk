package com.bryle.realfarm.graphics

import android.graphics.Color

/**
 * Procedural pixel-art growth-stage sprites for planted crops. Early growth stages are a plain
 * green sprout shared by every crop; only the final stage gets a colored "fruit" blob using each
 * crop's own [com.bryle.realfarm.farming.CropDefinition.color]. That means adding a new crop to
 * [com.bryle.realfarm.farming.CropDatabase] never requires drawing new art — it automatically
 * gets this shape in its own color.
 */
object CropSprites {

    private val basePalette = mapOf('g' to Color.rgb(0x4C, 0x8A, 0x35))
    private val wiltedPalette = mapOf('d' to Color.rgb(0x6B, 0x5B, 0x3E))

    private val STAGE_0_ROWS = arrayOf(
        "         ",
        "         ",
        "         ",
        "         ",
        "         ",
        "  g   g  ",
        "   g g   ",
        "    g    ",
        "    g    "
    )
    private val STAGE_1_ROWS = arrayOf(
        "         ",
        "         ",
        "         ",
        "         ",
        "         ",
        "  g   g  ",
        "  gg ggg ",
        "   ggg   ",
        "  ggggg  "
    )
    private val STAGE_2_ROWS = arrayOf(
        "         ",
        "         ",
        "  g   g  ",
        " gg   gg ",
        "  g g g  ",
        " gg g gg ",
        "   ggg   ",
        "  ggggg  ",
        "  ggggg  "
    )
    private val STAGE_3_ROWS = arrayOf(
        "   ccc   ",
        "  ccccc  ",
        "  ccccc  ",
        " g ccc g ",
        " gg g gg ",
        "  g g g  ",
        " gg g gg ",
        "   ggg   ",
        "  ggggg  "
    )
    private val WILTED_ROWS = arrayOf(
        "         ",
        "         ",
        "         ",
        "  d   d  ",
        "   d d   ",
        "  d d d  ",
        "   d d   ",
        "   ddd   ",
        "  ddddd  "
    )

    private val stage0 by lazy { PixelSprite(PixelArt.fromRows(STAGE_0_ROWS, basePalette)) }
    private val stage1 by lazy { PixelSprite(PixelArt.fromRows(STAGE_1_ROWS, basePalette)) }
    private val stage2 by lazy { PixelSprite(PixelArt.fromRows(STAGE_2_ROWS, basePalette)) }
    private val wilted by lazy { PixelSprite(PixelArt.fromRows(WILTED_ROWS, wiltedPalette)) }

    /** Stage-3 sprites are cached per accent color since every crop's "fruit" color differs. */
    private val stage3Cache = HashMap<Int, PixelSprite>()

    private fun stage3For(color: Int): PixelSprite = stage3Cache.getOrPut(color) {
        PixelSprite(PixelArt.fromRows(STAGE_3_ROWS, basePalette + ('c' to color)))
    }

    /**
     * @param growthFraction 0f (just planted) .. 1f (fully mature); ignored when [isWilted].
     * @param color the crop's [com.bryle.realfarm.farming.CropDefinition.color], used only once
     *   the plant is far enough along to show its "fruit".
     */
    fun spriteFor(growthFraction: Float, color: Int, isWilted: Boolean): PixelSprite {
        if (isWilted) return wilted
        return when {
            growthFraction >= 0.75f -> stage3For(color)
            growthFraction >= 0.45f -> stage2
            growthFraction >= 0.15f -> stage1
            else -> stage0
        }
    }
}
