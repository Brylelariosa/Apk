package com.bryle.realfarm.graphics

import android.graphics.Bitmap

/**
 * Builds small, crisp pixel-art bitmaps from plain-text row grids. Every sprite in the game is
 * defined this way — one character per logical pixel — instead of as PNG assets, since the build
 * pipeline is a headless GitHub Actions job with no image-asset step. A space is always fully
 * transparent; every other character is looked up in [palette].
 */
object PixelArt {

    fun fromRows(rows: Array<String>, palette: Map<Char, Int>): Bitmap {
        val height = rows.size
        val width = rows.maxOf { it.length }
        val pixels = IntArray(width * height)
        for (y in rows.indices) {
            val row = rows[y]
            for (x in 0 until width) {
                val c = if (x < row.length) row[x] else ' '
                pixels[y * width + x] = if (c == ' ') 0x00000000 else (palette[c] ?: 0x00000000)
            }
        }
        return Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
    }
}
