package com.bryle.realfarm.engine

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.bryle.realfarm.core.HudSnapshot
import com.bryle.realfarm.farming.Tool

/** Pure rendering of the HUD overlay; takes an immutable snapshot each frame. */
class HudRenderer {

    private val panelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(190, 20, 20, 20) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 26f
    }
    private val smallTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 20f
    }
    private val warningTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(0xFF, 0x6B, 0x6B)
        textSize = 20f
    }
    private val barBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(160, 60, 60, 60) }
    private val hungerBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0xE8, 0x9B, 0x2E) }
    private val staminaBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x4F, 0xA8, 0xE0) }
    private val toastPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 24f
        textAlign = Paint.Align.CENTER
    }
    private val toastBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 20, 20, 20) }

    fun draw(canvas: Canvas, snapshot: HudSnapshot, viewportWidth: Float, toastMessage: String?) {
        val panelHeight = 150f
        canvas.drawRect(RectF(0f, 0f, viewportWidth, panelHeight), panelPaint)

        val leftX = 24f
        canvas.drawText("Day ${snapshot.day}  •  ${snapshot.timeLabel} ${if (snapshot.isNight) "\u263D" else "\u2600"}", leftX, 40f, textPaint)
        canvas.drawText("$${snapshot.money}", leftX, 74f, textPaint)

        drawLabeledBar(canvas, "Hunger", snapshot.hunger / 100f, leftX, 90f, 220f, hungerBarPaint)
        drawLabeledBar(canvas, "Stamina", snapshot.stamina / 100f, leftX, 118f, 220f, staminaBarPaint)

        val midX = 280f
        val mealsText = "Meals today: ${snapshot.mealsEatenToday}/3"
        canvas.drawText(mealsText, midX, 40f, smallTextPaint)

        val waterText = "Water: ${snapshot.waterCharges}/${snapshot.maxWaterCharges}"
        canvas.drawText(waterText, midX, 66f, smallTextPaint)

        if (snapshot.isSick) {
            canvas.drawText("SICK (${snapshot.sickDaysRemaining}d)", midX, 92f, warningTextPaint)
        }

        val rightX = viewportWidth - 260f
        if (snapshot.unpaidBillCount > 0) {
            canvas.drawText("Unpaid bills: ${snapshot.unpaidBillCount}", rightX, 40f, warningTextPaint)
        }
        if (snapshot.isWaterShutOff) {
            canvas.drawText("WATER SHUT OFF", rightX, 66f, warningTextPaint)
        }
        if (snapshot.isElectricityShutOff) {
            canvas.drawText("POWER SHUT OFF", rightX, 92f, warningTextPaint)
        }

        canvas.drawText(
            "Selected: ${snapshot.selectedTool.label}" +
                if (snapshot.selectedTool == Tool.SEED_BAG) " (${snapshot.selectedCropName})" else "",
            leftX, 140f, smallTextPaint
        )

        if (toastMessage != null) {
            val toastY = panelHeight + 50f
            val textWidth = toastPaint.measureText(toastMessage)
            val pad = 20f
            canvas.drawRoundRect(
                RectF(viewportWidth / 2f - textWidth / 2f - pad, toastY - 30f, viewportWidth / 2f + textWidth / 2f + pad, toastY + 12f),
                12f, 12f, toastBgPaint
            )
            canvas.drawText(toastMessage, viewportWidth / 2f, toastY, toastPaint)
        }
    }

    private fun drawLabeledBar(canvas: Canvas, label: String, fraction: Float, x: Float, y: Float, width: Float, fillPaint: Paint) {
        canvas.drawText(label, x, y, smallTextPaint)
        val barX = x + 80f
        val barWidth = width - 80f
        val barHeight = 16f
        canvas.drawRect(RectF(barX, y - 14f, barX + barWidth, y - 14f + barHeight), barBgPaint)
        canvas.drawRect(RectF(barX, y - 14f, barX + barWidth * fraction.coerceIn(0f, 1f), y - 14f + barHeight), fillPaint)
    }
}
