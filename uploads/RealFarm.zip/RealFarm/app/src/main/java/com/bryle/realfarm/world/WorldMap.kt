package com.bryle.realfarm.world

/**
 * Fixed-size grid representing the farm. Tile (0,0) is the top-left corner.
 * Layout is generated once in [generateDefault]: a house block, an adjacent pond
 * (the water source used to refill the watering can) and open grass everywhere else.
 */
class WorldMap private constructor(
    val widthTiles: Int,
    val heightTiles: Int,
    private val tiles: Array<Array<FarmTile>>
) {
    companion object {
        const val TILE_SIZE = 96f

        fun generateDefault(width: Int = 16, height: Int = 12): WorldMap {
            val grid = Array(height) { Array(width) { FarmTile(TileType.GRASS) } }

            // House block, top-left.
            for (y in 0..1) {
                for (x in 0..1) {
                    grid[y][x] = FarmTile(TileType.HOUSE)
                }
            }

            // Pond, top-right — the water source tiles.
            for (y in 0..1) {
                for (x in width - 2 until width) {
                    grid[y][x] = FarmTile(TileType.WATER_SOURCE)
                }
            }

            return WorldMap(width, height, grid)
        }
    }

    fun isInBounds(x: Int, y: Int): Boolean = x in 0 until widthTiles && y in 0 until heightTiles

    fun getTile(x: Int, y: Int): FarmTile? = if (isInBounds(x, y)) tiles[y][x] else null

    fun forEachTile(action: (x: Int, y: Int, tile: FarmTile) -> Unit) {
        for (y in 0 until heightTiles) {
            for (x in 0 until widthTiles) {
                action(x, y, tiles[y][x])
            }
        }
    }

    fun isAdjacentToWaterSource(x: Int, y: Int): Boolean {
        val neighbors = listOf(x - 1 to y, x + 1 to y, x to y - 1, x to y + 1, x to y)
        return neighbors.any { (nx, ny) -> getTile(nx, ny)?.type == TileType.WATER_SOURCE }
    }

    fun worldPixelWidth(): Float = widthTiles * TILE_SIZE
    fun worldPixelHeight(): Float = heightTiles * TILE_SIZE
}
