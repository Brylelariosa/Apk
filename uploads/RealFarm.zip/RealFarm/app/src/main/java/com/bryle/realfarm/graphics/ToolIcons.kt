package com.bryle.realfarm.graphics

import android.graphics.Color
import com.bryle.realfarm.farming.Tool

/** Small pixel-art icons for the on-screen tool belt buttons. */
object ToolIcons {

    private val handPalette = mapOf('s' to Color.rgb(0xE8, 0xB9, 0x8C))
    private val hoePalette = mapOf(
        'm' to Color.rgb(0xB0, 0xB0, 0xB0),
        'w' to Color.rgb(0x8A, 0x5A, 0x35)
    )
    private val canPalette = mapOf('m' to Color.rgb(0xA8, 0xB6, 0xC2))
    private val bagPalette = mapOf(
        't' to Color.rgb(0x6B, 0x43, 0x26),
        'p' to Color.rgb(0x8A, 0x5A, 0x35)
    )

    private val HAND_ROWS = arrayOf(
        "         ",
        "  s s s  ",
        "  s s s  ",
        "  sssss  ",
        " sssssss ",
        " sssssss ",
        "  sssss  ",
        "   sss   ",
        "         "
    )
    private val HOE_ROWS = arrayOf(
        "      mm ",
        "     mm  ",
        "    mm   ",
        "   ww    ",
        "  ww     ",
        " ww      ",
        "ww       ",
        "w        ",
        "         "
    )
    private val WATERING_CAN_ROWS = arrayOf(
        "         ",
        "  mmmm  m",
        " m    mmm",
        " m mmm  m",
        " m mmmmm ",
        " mmmmmm  ",
        "  mmmmm  ",
        "   mmm   ",
        "         "
    )
    private val SEED_BAG_ROWS = arrayOf(
        "         ",
        "   ttt   ",
        "  pppp   ",
        " pppppp  ",
        " pppppp  ",
        " pppppp  ",
        " pppppp  ",
        "  pppp   ",
        "         "
    )

    private val hand by lazy { PixelSprite(PixelArt.fromRows(HAND_ROWS, handPalette)) }
    private val hoe by lazy { PixelSprite(PixelArt.fromRows(HOE_ROWS, hoePalette)) }
    private val wateringCan by lazy { PixelSprite(PixelArt.fromRows(WATERING_CAN_ROWS, canPalette)) }
    private val seedBag by lazy { PixelSprite(PixelArt.fromRows(SEED_BAG_ROWS, bagPalette)) }

    fun iconFor(tool: Tool): PixelSprite = when (tool) {
        Tool.HAND -> hand
        Tool.HOE -> hoe
        Tool.WATERING_CAN -> wateringCan
        Tool.SEED_BAG -> seedBag
    }
}
