package com.bryle.realfarm.engine

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import com.bryle.realfarm.entity.Player
import com.bryle.realfarm.farming.Tool
import com.bryle.realfarm.graphics.PixelSprite
import com.bryle.realfarm.graphics.ToolIcons

/** What a single HUD quick-slot button should currently show; null means the slot is empty. */
data class QuickSlotDisplay(val icon: PixelSprite, val quantity: Int)

/**
 * Owns every on-canvas touch control (movement joystick, tool belt, quick-use item slots, seed
 * cycler, action button). [GameView] forwards raw [MotionEvent]s here and reads back the
 * resulting intents each frame; this keeps touch-region math out of the view class entirely.
 */
class InputController(
    private val onToolSelected: (Tool) -> Unit,
    private val onSeedCycle: () -> Unit,
    private val onActionButton: () -> Unit,
    private val onQuickSlotTapped: (Int) -> Unit
) {
    val joystick = VirtualJoystick()

    private val toolOrder = listOf(Tool.HAND, Tool.HOE, Tool.WATERING_CAN, Tool.SEED_BAG)
    private var toolButtonRects: List<Pair<Tool, RectF>> = emptyList()
    private var quickSlotRects: List<RectF> = emptyList()
    private var quickSlotDisplays: List<QuickSlotDisplay?> = List(Player.QUICK_SLOT_COUNT) { null }
    private var actionButtonRect = RectF()
    private var actionButtonRadius = 0f
    private var selectedTool: Tool = Tool.HAND

    private val toolBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 30, 30, 30) }
    private val toolBgSelectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 76, 140, 74) }
    private val toolTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 18f
        textAlign = Paint.Align.CENTER
    }
    private val actionBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(190, 200, 90, 40) }
    private val actionTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 22f
        textAlign = Paint.Align.CENTER
    }
    private val quickSlotBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 30, 30, 30) }
    private val quickSlotBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 230, 230, 230)
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val quickSlotQtyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 18f
        textAlign = Paint.Align.RIGHT
    }

    fun updateSelectedTool(tool: Tool) {
        selectedTool = tool
    }

    /** Called every frame with what each quick slot currently holds, so icons/quantities stay live. */
    fun updateQuickSlots(displays: List<QuickSlotDisplay?>) {
        quickSlotDisplays = displays
    }

    /** Recomputes control positions/sizes whenever the view size changes. */
    fun layout(width: Int, height: Int) {
        joystick.setBaseCenter(160f, height - 160f)

        val buttonSize = 90f
        val spacing = 16f
        val startX = width / 2f - (toolOrder.size * (buttonSize + spacing)) / 2f
        val y = height - buttonSize - 24f
        toolButtonRects = toolOrder.mapIndexed { index, tool ->
            val left = startX + index * (buttonSize + spacing)
            tool to RectF(left, y, left + buttonSize, y + buttonSize)
        }

        actionButtonRadius = 70f
        actionButtonRect = RectF(
            width - 200f, height - 200f,
            width - 200f + actionButtonRadius * 2f, height - 200f + actionButtonRadius * 2f
        )

        val quickSlotSize = 64f
        val quickSlotSpacing = 14f
        val qx = actionButtonRect.centerX() - quickSlotSize / 2f
        var qy = actionButtonRect.top - quickSlotSize - 20f
        quickSlotRects = (0 until Player.QUICK_SLOT_COUNT).map {
            val rect = RectF(qx, qy, qx + quickSlotSize, qy + quickSlotSize)
            qy -= quickSlotSize + quickSlotSpacing
            rect
        }
    }

    fun onTouchEvent(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val index = event.actionIndex
                val pointerId = event.getPointerId(index)
                val x = event.getX(index)
                val y = event.getY(index)
                if (!handleButtonTap(x, y)) {
                    joystick.tryActivate(pointerId, x, y)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val pointerId = event.getPointerId(i)
                    joystick.updateIfActive(pointerId, event.getX(i), event.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val index = event.actionIndex
                joystick.releaseIfActive(event.getPointerId(index))
            }
            MotionEvent.ACTION_CANCEL -> {
                joystick.releaseIfActive(joystick.activePointerId)
            }
        }
    }

    private fun handleButtonTap(x: Float, y: Float): Boolean {
        for ((tool, rect) in toolButtonRects) {
            if (rect.contains(x, y)) {
                if (tool == Tool.SEED_BAG && selectedTool == Tool.SEED_BAG) {
                    onSeedCycle()
                } else {
                    onToolSelected(tool)
                }
                return true
            }
        }
        for ((index, rect) in quickSlotRects.withIndex()) {
            if (rect.contains(x, y)) {
                onQuickSlotTapped(index)
                return true
            }
        }
        val dx = x - actionButtonRect.centerX()
        val dy = y - actionButtonRect.centerY()
        if (dx * dx + dy * dy <= actionButtonRadius * actionButtonRadius) {
            onActionButton()
            return true
        }
        return false
    }

    fun draw(canvas: Canvas) {
        joystick.draw(canvas)

        for ((tool, rect) in toolButtonRects) {
            val paint = if (tool == selectedTool) toolBgSelectedPaint else toolBgPaint
            canvas.drawRoundRect(rect, 16f, 16f, paint)
            ToolIcons.iconFor(tool).drawCentered(canvas, rect.centerX(), rect.centerY() - 12f, 44f)
            canvas.drawText(tool.label, rect.centerX(), rect.bottom - 10f, toolTextPaint)
        }

        for ((index, rect) in quickSlotRects.withIndex()) {
            canvas.drawRoundRect(rect, 12f, 12f, quickSlotBgPaint)
            canvas.drawRoundRect(rect, 12f, 12f, quickSlotBorderPaint)
            val display = quickSlotDisplays.getOrNull(index)
            if (display != null) {
                display.icon.drawCentered(canvas, rect.centerX(), rect.centerY(), rect.height() * 0.68f)
                canvas.drawText("x${display.quantity}", rect.right - 6f, rect.bottom - 8f, quickSlotQtyPaint)
            }
        }

        canvas.drawCircle(actionButtonRect.centerX(), actionButtonRect.centerY(), actionButtonRadius, actionBgPaint)
        canvas.drawText("Use", actionButtonRect.centerX(), actionButtonRect.centerY() + 8f, actionTextPaint)
    }
}
