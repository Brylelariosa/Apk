package com.bryle.realfarm.engine

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import com.bryle.realfarm.farming.Tool

/**
 * Owns every on-canvas touch control (movement joystick, tool belt, seed cycler, action button).
 * [GameView] forwards raw [MotionEvent]s here and reads back the resulting intents each frame;
 * this keeps touch-region math out of the view class entirely.
 */
class InputController(
    private val onToolSelected: (Tool) -> Unit,
    private val onSeedCycle: () -> Unit,
    private val onActionButton: () -> Unit
) {
    val joystick = VirtualJoystick()

    private val toolOrder = listOf(Tool.HAND, Tool.HOE, Tool.WATERING_CAN, Tool.SEED_BAG)
    private var toolButtonRects: List<Pair<Tool, RectF>> = emptyList()
    private var actionButtonRect = RectF()
    private var actionButtonRadius = 0f
    private var selectedTool: Tool = Tool.HAND

    private val toolBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 30, 30, 30) }
    private val toolBgSelectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 76, 140, 74) }
    private val toolTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 24f
        textAlign = Paint.Align.CENTER
    }
    private val actionBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(190, 200, 90, 40) }
    private val actionTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 22f
        textAlign = Paint.Align.CENTER
    }

    fun updateSelectedTool(tool: Tool) {
        selectedTool = tool
    }

    /** Recomputes control positions/sizes whenever the view size changes. */
    fun layout(width: Int, height: Int) {
        joystick.setBaseCenter(160f, height - 160f)

        val buttonSize = 90f
        val spacing = 16f
        val startX = width / 2f - (toolOrder.size * (buttonSize + spacing)) / 2f
        val y = height - buttonSize - 24f
        toolButtonRects = toolOrder.mapIndexed { index, tool ->
            val left = startX + index * (buttonSize + spacing)
            tool to RectF(left, y, left + buttonSize, y + buttonSize)
        }

        actionButtonRadius = 70f
        actionButtonRect = RectF(
            width - 200f, height - 200f,
            width - 200f + actionButtonRadius * 2f, height - 200f + actionButtonRadius * 2f
        )
    }

    fun onTouchEvent(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val index = event.actionIndex
                val pointerId = event.getPointerId(index)
                val x = event.getX(index)
                val y = event.getY(index)
                if (!handleButtonTap(x, y)) {
                    joystick.tryActivate(pointerId, x, y)
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val pointerId = event.getPointerId(i)
                    joystick.updateIfActive(pointerId, event.getX(i), event.getY(i))
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val index = event.actionIndex
                joystick.releaseIfActive(event.getPointerId(index))
            }
            MotionEvent.ACTION_CANCEL -> {
                joystick.releaseIfActive(joystick.activePointerId)
            }
        }
    }

    private fun handleButtonTap(x: Float, y: Float): Boolean {
        for ((tool, rect) in toolButtonRects) {
            if (rect.contains(x, y)) {
                if (tool == Tool.SEED_BAG && selectedTool == Tool.SEED_BAG) {
                    onSeedCycle()
                } else {
                    onToolSelected(tool)
                }
                return true
            }
        }
        val dx = x - actionButtonRect.centerX()
        val dy = y - actionButtonRect.centerY()
        if (dx * dx + dy * dy <= actionButtonRadius * actionButtonRadius) {
            onActionButton()
            return true
        }
        return false
    }

    fun draw(canvas: Canvas) {
        joystick.draw(canvas)

        for ((tool, rect) in toolButtonRects) {
            val paint = if (tool == selectedTool) toolBgSelectedPaint else toolBgPaint
            canvas.drawRoundRect(rect, 16f, 16f, paint)
            canvas.drawText(tool.label, rect.centerX(), rect.centerY() + 8f, toolTextPaint)
        }

        canvas.drawCircle(actionButtonRect.centerX(), actionButtonRect.centerY(), actionButtonRadius, actionBgPaint)
        canvas.drawText("Use", actionButtonRect.centerX(), actionButtonRect.centerY() + 8f, actionTextPaint)
    }
}
