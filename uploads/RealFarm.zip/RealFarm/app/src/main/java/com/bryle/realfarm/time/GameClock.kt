package com.bryle.realfarm.time

/**
 * Drives the in-game calendar. One real second advances [MINUTES_PER_REAL_SECOND] in-game minutes,
 * so a full 24h in-game day takes [DAY_LENGTH_SECONDS] real seconds.
 *
 * Everything else that cares about "a new day happened" (billing, hunger reset, crop growth)
 * reads [consumeNewDayFlag] once per frame rather than polling the raw minute counter, so the
 * rollover is only ever processed exactly once per day.
 */
class GameClock {

    companion object {
        const val DAY_LENGTH_SECONDS = 18 * 60 // 18 real minutes per in-game day
        const val MINUTES_PER_DAY = 24 * 60
        const val MINUTES_PER_REAL_SECOND = MINUTES_PER_DAY / DAY_LENGTH_SECONDS

        const val BREAKFAST_START = 6 * 60
        const val BREAKFAST_END = 10 * 60
        const val LUNCH_START = 11 * 60 + 30
        const val LUNCH_END = 14 * 60
        const val DINNER_START = 17 * 60 + 30
        const val DINNER_END = 21 * 60
    }

    var day: Int = 1
        private set

    /** Minutes since midnight, 0..1439. */
    var minuteOfDay: Int = BREAKFAST_START
        private set

    private var newDayPending = false

    fun tick(deltaSeconds: Float) {
        val minutesToAdd = deltaSeconds * MINUTES_PER_REAL_SECOND
        var accumulated = minuteOfDay + minutesToAdd
        while (accumulated >= MINUTES_PER_DAY) {
            accumulated -= MINUTES_PER_DAY
            day += 1
            newDayPending = true
        }
        minuteOfDay = accumulated.toInt().coerceIn(0, MINUTES_PER_DAY - 1)
    }

    /** Returns true exactly once when a new day has begun since the last call. */
    fun consumeNewDayFlag(): Boolean {
        if (newDayPending) {
            newDayPending = false
            return true
        }
        return false
    }

    fun hour(): Int = minuteOfDay / 60
    fun minute(): Int = minuteOfDay % 60

    fun isNight(): Boolean = minuteOfDay < 5 * 60 || minuteOfDay >= 20 * 60

    fun formattedTime(): String {
        val h24 = hour()
        val m = minute()
        val suffix = if (h24 < 12) "AM" else "PM"
        var h12 = h24 % 12
        if (h12 == 0) h12 = 12
        return String.format("%d:%02d %s", h12, m, suffix)
    }

    enum class MealWindow { BREAKFAST, LUNCH, DINNER, NONE }

    fun currentMealWindow(): MealWindow = when (minuteOfDay) {
        in BREAKFAST_START until BREAKFAST_END -> MealWindow.BREAKFAST
        in LUNCH_START until LUNCH_END -> MealWindow.LUNCH
        in DINNER_START until DINNER_END -> MealWindow.DINNER
        else -> MealWindow.NONE
    }

    /** Force-advance to the next morning (used when the player sleeps). */
    fun sleepToMorning() {
        day += 1
        minuteOfDay = BREAKFAST_START
        newDayPending = true
    }

    fun toSaveState(): IntArray = intArrayOf(day, minuteOfDay)

    fun restore(dayIn: Int, minuteIn: Int) {
        day = dayIn
        minuteOfDay = minuteIn.coerceIn(0, MINUTES_PER_DAY - 1)
    }
}
