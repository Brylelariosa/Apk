package com.bryle.realfarm.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.bryle.realfarm.core.GameEngine
import com.bryle.realfarm.engine.GameView
import com.bryle.realfarm.farming.CropDatabase
import com.bryle.realfarm.inventory.ItemType

object ShopDialog {

    fun show(context: Context, engine: GameEngine, gameView: GameView) {
        val dialog = AlertDialog.Builder(context)
            .setTitle("Shop")
            .setPositiveButton("Close", null)
            .create()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 24)
        }
        val scroll = ScrollView(context)
        scroll.addView(container)
        dialog.setView(scroll)

        fun refresh() {
            container.removeAllViews()

            val moneyView = TextView(context).apply {
                text = "Money: \$${engine.state.wallet.balance}"
                setTextColor(Color.WHITE)
                textSize = 16f
            }
            container.addView(moneyView)

            addSectionHeader(context, container, "Seeds")
            for (crop in CropDatabase.ALL) {
                addRow(
                    context, container,
                    title = crop.displayName,
                    subtitle = "\$${crop.seedCost} • grows in ${crop.growDays} days",
                    buttonLabel = "Buy",
                    enabled = engine.state.wallet.balance >= crop.seedCost
                ) {
                    toastResult(context, engine.buySeed(crop.id, 1))
                    refresh()
                }
            }

            addSectionHeader(context, container, "Food")
            for (item in ItemType.SHOP_FOOD) {
                addRow(
                    context, container,
                    title = item.displayName,
                    subtitle = "\$${item.buyPrice} • restores ${item.hungerRestore} hunger",
                    buttonLabel = "Buy",
                    enabled = engine.state.wallet.balance >= item.buyPrice
                ) {
                    toastResult(context, engine.buyItem(item, 1))
                    refresh()
                }
            }

            addSectionHeader(context, container, "Medicine")
            for (item in ItemType.SHOP_MEDICINE) {
                addRow(
                    context, container,
                    title = item.displayName,
                    subtitle = "\$${item.buyPrice} • helps cure sickness",
                    buttonLabel = "Buy",
                    enabled = engine.state.wallet.balance >= item.buyPrice
                ) {
                    toastResult(context, engine.buyItem(item, 1))
                    refresh()
                }
            }

            addSectionHeader(context, container, "Sell Crops")
            for (crop in CropDatabase.ALL) {
                val owned = engine.state.inventory.quantityOf(ItemType.cropFor(crop.id, 0).id)
                val price = engine.state.market.currentPrice(crop.id)
                val ratio = (engine.state.market.priceRatio(crop.id) * 100).toInt()
                addRowWithTwoButtons(
                    context, container,
                    title = "${crop.displayName} — you have $owned",
                    subtitle = "\$$price each ($ratio% of base — sell more and it drops further)",
                    button1Label = "Sell 1",
                    button1Enabled = owned > 0,
                    onClick1 = {
                        toastResult(context, engine.sellCrop(crop.id, 1))
                        refresh()
                    },
                    button2Label = "Sell All",
                    button2Enabled = owned > 0,
                    onClick2 = {
                        toastResult(context, engine.sellCrop(crop.id, owned))
                        refresh()
                    }
                )
            }
        }

        refresh()
        dialog.setOnDismissListener { gameView.syncSelectedTool() }
        dialog.show()
    }
}
