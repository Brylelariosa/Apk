package com.bryle.realfarm.core

import com.bryle.realfarm.farming.ActionResult
import com.bryle.realfarm.farming.CropDatabase
import com.bryle.realfarm.farming.Tool
import com.bryle.realfarm.inventory.ItemType
import com.bryle.realfarm.needs.HealthSystem
import com.bryle.realfarm.world.TileType
import java.util.ArrayDeque

/**
 * The only class allowed to reach into [GameState] and coordinate multiple systems in one call.
 * [GameView]/input code drives this via [update] and the `perform*` action methods; nothing else
 * in the codebase needs to know how the systems wire together.
 */
class GameEngine(val state: GameState = GameState()) {

    private val events = ArrayDeque<String>()

    fun update(deltaSeconds: Float, moveX: Float, moveY: Float) {
        state.clock.tick(deltaSeconds)
        state.player.move(moveX, moveY, deltaSeconds, state.health.speedMultiplier, state.world)
        state.hunger.tick(deltaSeconds, state.clock.currentMealWindow())

        if (state.clock.consumeNewDayFlag()) {
            onNewDay()
        }
    }

    private fun onNewDay() {
        state.farming.advanceDailyGrowth()
        state.market.onNewDay()
        state.billing.recordDailyElectricityBaseline()
        state.billing.onNewDay(state.clock.day)
        state.hunger.onNewDay()

        val fellIll = state.health.evaluateNewDay(
            HealthSystem.RiskFactors(
                hungerCritical = state.hunger.isCritical,
                missedMealsStreak = state.hunger.missedMealsStreak,
                exhausted = state.stamina.isExhausted,
                hasUnpaidOverdueBill = state.billing.hasAnyOverdueUnpaidBill
            )
        )
        state.stamina.applyDailyPassiveDrain(state.hunger.isCritical, state.health.isSick)

        pushEvent("Day ${state.clock.day}")
        if (fellIll) pushEvent("You woke up feeling sick")
        val freshBills = state.billing.unpaidBills().filter { it.issuedDay == state.clock.day }
        if (freshBills.isNotEmpty()) {
            val total = freshBills.sumOf { it.amount }
            pushEvent("New bills totaling \$$total")
        }
    }

    // ---- Farming actions, dispatched by the currently selected tool ----

    fun performAction(): ActionResult {
        val (tx, ty) = state.player.targetTile()
        val multiplier = state.health.workStaminaCostMultiplier
        val result = when (state.player.selectedTool) {
            Tool.HOE -> state.farming.till(tx, ty, multiplier)
            Tool.WATERING_CAN -> {
                val targetTile = state.farming.tileAt(tx, ty)
                if (targetTile?.type == TileType.WATER_SOURCE) {
                    state.farming.refillWateringCan(state.player.tileX(), state.player.tileY())
                } else {
                    state.farming.water(tx, ty, multiplier)
                }
            }
            Tool.SEED_BAG -> state.farming.plant(tx, ty, state.player.selectedCropId, multiplier)
            Tool.HAND -> state.farming.harvest(tx, ty, multiplier)
        }
        if (result is ActionResult.Success && result.message != null) pushEvent(result.message)
        if (result is ActionResult.Failure) pushEvent(result.reason)
        return result
    }

    fun selectTool(tool: Tool) {
        state.player.selectedTool = tool
    }

    fun cycleSeed() {
        val ids = CropDatabase.ALL.map { it.id }
        val currentIndex = ids.indexOf(state.player.selectedCropId).coerceAtLeast(0)
        state.player.selectedCropId = ids[(currentIndex + 1) % ids.size]
        pushEvent("Seed: ${CropDatabase.get(state.player.selectedCropId).displayName}")
    }

    // ---- Economy ----

    fun buyItem(item: ItemType, quantity: Int = 1): ActionResult {
        val cost = item.buyPrice * quantity
        if (!state.wallet.trySpend(cost)) return ActionResult.Failure("Not enough money")
        state.inventory.add(item.id, quantity)
        return ActionResult.Success("Bought $quantity ${item.displayName}")
    }

    fun buySeed(cropId: String, quantity: Int = 1): ActionResult {
        val def = CropDatabase.get(cropId)
        val item = ItemType.seedFor(cropId, def.seedCost)
        val cost = def.seedCost * quantity
        if (!state.wallet.trySpend(cost)) return ActionResult.Failure("Not enough money")
        state.inventory.add(item.id, quantity)
        return ActionResult.Success("Bought $quantity ${def.displayName} seeds")
    }

    fun sellCrop(cropId: String, quantity: Int): ActionResult {
        val def = CropDatabase.get(cropId)
        val itemId = ItemType.cropFor(cropId, 0).id
        if (!state.inventory.has(itemId, quantity)) return ActionResult.Failure("You don't have that many ${def.displayName}")
        state.inventory.tryRemove(itemId, quantity)
        val revenue = state.market.sell(cropId, quantity)
        state.wallet.deposit(revenue)
        return ActionResult.Success("Sold $quantity ${def.displayName} for \$$revenue")
    }

    fun eatItem(itemId: String, hungerRestore: Int): ActionResult {
        if (!state.inventory.tryRemove(itemId, 1)) return ActionResult.Failure("You don't have that")
        state.hunger.eat(hungerRestore, state.clock.currentMealWindow())
        return ActionResult.Success("Ate — hunger restored")
    }

    fun useMedicine(): ActionResult {
        if (!state.inventory.tryRemove(ItemType.MEDICINE.id, 1)) return ActionResult.Failure("No medicine")
        val cured = state.health.useMedicine(ItemType.MEDICINE.healPower)
        return ActionResult.Success(if (cured) "You feel better!" else "The medicine helped a little")
    }

    fun payBill(billId: Int): ActionResult {
        val paid = state.billing.payBill(billId, state.wallet) ?: return ActionResult.Failure("Can't pay that bill")
        return ActionResult.Success("Paid \$$paid")
    }

    fun sleep() {
        val fullRestore = !state.billing.isElectricityShutOff
        state.clock.sleepToMorning()
        state.stamina.sleep(fullRestore)
        pushEvent(if (fullRestore) "Slept through the night" else "Poor sleep — no electricity")
    }

    // ---- Events / HUD ----

    private fun pushEvent(message: String) {
        events.addLast(message)
        while (events.size > 5) events.removeFirst()
    }

    fun pollEvent(): String? = if (events.isEmpty()) null else events.removeFirst()

    fun hudSnapshot(): HudSnapshot = HudSnapshot(
        day = state.clock.day,
        timeLabel = state.clock.formattedTime(),
        isNight = state.clock.isNight(),
        money = state.wallet.balance,
        hunger = state.hunger.hunger,
        stamina = state.stamina.stamina,
        isSick = state.health.isSick,
        sickDaysRemaining = state.health.sickDaysRemaining,
        waterCharges = state.farming.waterCharges,
        maxWaterCharges = com.bryle.realfarm.farming.FarmingSystem.MAX_WATER_CHARGES,
        selectedTool = state.player.selectedTool,
        selectedCropName = CropDatabase.get(state.player.selectedCropId).displayName,
        mealsEatenToday = state.hunger.mealsEatenToday(),
        unpaidBillCount = state.billing.unpaidBills().size,
        isWaterShutOff = state.billing.isWaterShutOff,
        isElectricityShutOff = state.billing.isElectricityShutOff
    )
}
