package com.bryle.realfarm.graphics

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/**
 * A small pixel-art bitmap rendered crisp (nearest-neighbor, no smoothing) and scaled up to
 * whatever on-screen size is needed. Wrapping the bitmap + a shared non-filtering [Paint] here
 * means every renderer draws pixel art the same way instead of each one having to remember to
 * disable bitmap filtering.
 */
class PixelSprite(private val bitmap: Bitmap) {

    private val aspect: Float = bitmap.width.toFloat() / bitmap.height.toFloat()

    companion object {
        private val paint = Paint().apply {
            isFilterBitmap = false
            isDither = false
        }
    }

    /**
     * Draws the sprite centered at ([centerX], [centerY]), scaled so its height equals
     * [targetHeight]. Pass [flipHorizontal] to mirror left/right — used to derive a LEFT-facing
     * pose from a RIGHT-facing one without authoring a duplicate sprite.
     */
    fun drawCentered(canvas: Canvas, centerX: Float, centerY: Float, targetHeight: Float, flipHorizontal: Boolean = false) {
        val h = targetHeight
        val w = targetHeight * aspect
        val dest = RectF(centerX - w / 2f, centerY - h / 2f, centerX + w / 2f, centerY + h / 2f)
        if (!flipHorizontal) {
            drawFill(canvas, dest)
            return
        }
        canvas.save()
        canvas.scale(-1f, 1f, centerX, centerY)
        drawFill(canvas, dest)
        canvas.restore()
    }

    /** Draws the sprite stretched to exactly fill [dest] — used for tiles and icon squares. */
    fun drawFill(canvas: Canvas, dest: RectF) {
        canvas.drawBitmap(bitmap, null, dest, paint)
    }

    fun toBitmap(): Bitmap = bitmap
}
