package com.bryle.realfarm.inventory

/** Simple unbounded stack-based inventory keyed by item id. No slot limit — this is a farming
 *  sim, not a survival-crafting game, so artificially capping storage would only add friction
 *  without serving any of the requested mechanics. */
class Inventory {

    private val stacks = LinkedHashMap<String, ItemStack>()

    fun add(itemId: String, quantity: Int) {
        if (quantity <= 0) return
        val existing = stacks[itemId]
        if (existing != null) {
            existing.quantity += quantity
        } else {
            stacks[itemId] = ItemStack(itemId, quantity)
        }
    }

    fun has(itemId: String, quantity: Int = 1): Boolean =
        (stacks[itemId]?.quantity ?: 0) >= quantity

    /** Returns true and removes the quantity if available, otherwise leaves inventory untouched. */
    fun tryRemove(itemId: String, quantity: Int = 1): Boolean {
        val existing = stacks[itemId] ?: return false
        if (existing.quantity < quantity) return false
        existing.quantity -= quantity
        if (existing.quantity <= 0) stacks.remove(itemId)
        return true
    }

    fun quantityOf(itemId: String): Int = stacks[itemId]?.quantity ?: 0

    fun allStacks(): List<ItemStack> = stacks.values.toList()

    fun toSaveMap(): Map<String, Int> = stacks.mapValues { it.value.quantity }

    fun restore(map: Map<String, Int>) {
        stacks.clear()
        map.forEach { (id, qty) -> if (qty > 0) stacks[id] = ItemStack(id, qty) }
    }
}
