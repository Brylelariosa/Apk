package com.bryle.realfarm.world

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.bryle.realfarm.engine.Camera2D
import com.bryle.realfarm.farming.CropDatabase

/** Pure rendering: takes a world + camera and draws tiles/crops. Holds no game state of its own. */
class WorldRenderer {

    private val tilePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(40, 0, 0, 0)
        strokeWidth = 1f
    }
    private val cropPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wiltedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x6B, 0x5B, 0x3E) }
    private val waterMarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(120, 0x29, 0x6E, 0xB6)
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    fun draw(canvas: Canvas, world: WorldMap, camera: Camera2D) {
        val tileSize = WorldMap.TILE_SIZE
        world.forEachTile { x, y, tile ->
            val screenX = camera.worldToScreenX(x * tileSize)
            val screenY = camera.worldToScreenY(y * tileSize)

            // Cull tiles fully outside the viewport.
            if (screenX + tileSize < 0 || screenY + tileSize < 0 ||
                screenX > camera.viewportWidth || screenY > camera.viewportHeight
            ) return@forEachTile

            tilePaint.color = colorFor(tile.type)
            val rect = RectF(screenX, screenY, screenX + tileSize, screenY + tileSize)
            canvas.drawRect(rect, tilePaint)
            canvas.drawRect(rect, gridPaint)

            val crop = tile.plantedCrop
            if (crop != null) {
                val def = CropDatabase.tryGet(crop.cropId)
                if (def != null) {
                    val fraction = if (crop.wilted) 1f else crop.growthFraction(def)
                    val size = tileSize * (0.25f + 0.55f * fraction)
                    val cx = screenX + tileSize / 2f
                    val cy = screenY + tileSize / 2f
                    cropPaint.color = if (crop.wilted) wiltedPaint.color else def.color
                    canvas.drawCircle(cx, cy, size / 2f, cropPaint)
                    if (crop.wateredToday) {
                        canvas.drawCircle(cx, cy, size / 2f + 4f, waterMarkPaint)
                    }
                }
            }
        }
    }

    private fun colorFor(type: TileType): Int = when (type) {
        TileType.GRASS -> Color.rgb(0x6B, 0xA5, 0x3A)
        TileType.TILLED -> Color.rgb(0x8A, 0x5A, 0x35)
        TileType.PATH -> Color.rgb(0xC2, 0xA9, 0x77)
        TileType.WATER_SOURCE -> Color.rgb(0x2E, 0x86, 0xC1)
        TileType.HOUSE -> Color.rgb(0xA1, 0x88, 0x7C)
    }
}
