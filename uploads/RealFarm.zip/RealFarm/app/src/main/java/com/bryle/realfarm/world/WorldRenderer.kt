package com.bryle.realfarm.world

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.bryle.realfarm.engine.Camera2D
import com.bryle.realfarm.farming.CropDatabase
import com.bryle.realfarm.graphics.AnimationClock
import com.bryle.realfarm.graphics.CropSprites
import com.bryle.realfarm.graphics.HouseSprite
import com.bryle.realfarm.graphics.StatusIcons
import com.bryle.realfarm.graphics.TileSprites

/** Pure rendering: takes a world + camera and draws tiles/crops. Holds no game state of its own. */
class WorldRenderer {

    companion object {
        private const val WATER_MS_PER_FRAME = 500
        private const val SWAY_MS_PER_FRAME = 650
        private const val SMOKE_CYCLE_MS = 2400
    }

    private val smokePaint = Paint().apply { color = Color.argb(160, 210, 210, 210) }

    fun draw(canvas: Canvas, world: WorldMap, camera: Camera2D, animClock: AnimationClock) {
        val tileSize = WorldMap.TILE_SIZE
        val waterFrame = animClock.frame(2, WATER_MS_PER_FRAME)
        // Discrete left/right sway so the farm doesn't feel static; cheap since it only ever
        // shifts the draw position by a pixel, never re-renders the sprite itself.
        val swayOffset = if (animClock.frame(2, SWAY_MS_PER_FRAME) == 0) -1f else 1f

        world.forEachTile { x, y, tile ->
            val screenX = camera.worldToScreenX(x * tileSize)
            val screenY = camera.worldToScreenY(y * tileSize)

            // Cull tiles fully outside the viewport.
            if (screenX + tileSize < 0 || screenY + tileSize < 0 ||
                screenX > camera.viewportWidth || screenY > camera.viewportHeight
            ) return@forEachTile

            // The house footprint is drawn as one cohesive image after this loop, so its tiles
            // get plain grass underneath rather than a repeating wall/roof texture per tile.
            val groundType = if (tile.type == TileType.HOUSE) TileType.GRASS else tile.type
            val tileRect = RectF(screenX, screenY, screenX + tileSize, screenY + tileSize)
            TileSprites.spriteFor(groundType, waterFrame).drawFill(canvas, tileRect)

            val crop = tile.plantedCrop
            if (crop != null) {
                val def = CropDatabase.tryGet(crop.cropId)
                if (def != null) {
                    val fraction = crop.growthFraction(def)
                    val cx = screenX + tileSize / 2f + (if (!crop.wilted) swayOffset else 0f)
                    val cy = screenY + tileSize / 2f
                    val spriteSize = tileSize * (0.45f + 0.5f * fraction)
                    CropSprites.spriteFor(fraction, def.color, crop.wilted).drawCentered(canvas, cx, cy, spriteSize)
                    if (crop.wateredToday) {
                        StatusIcons.droplet.drawCentered(
                            canvas, cx + spriteSize * 0.4f, cy - spriteSize * 0.6f, tileSize * 0.26f
                        )
                    }
                }
            }
        }

        drawHouse(canvas, world, camera, animClock)
    }

    private fun drawHouse(canvas: Canvas, world: WorldMap, camera: Camera2D, animClock: AnimationClock) {
        val tileSize = WorldMap.TILE_SIZE
        val houseLeft = camera.worldToScreenX(world.houseOriginXTiles * tileSize)
        val houseTop = camera.worldToScreenY(world.houseOriginYTiles * tileSize)
        val houseWidthPx = world.houseWidthTiles * tileSize
        val houseHeightPx = world.houseHeightTiles * tileSize

        if (houseLeft + houseWidthPx < 0 || houseTop + houseHeightPx < 0 ||
            houseLeft > camera.viewportWidth || houseTop > camera.viewportHeight
        ) return

        HouseSprite.sprite.drawFill(canvas, RectF(houseLeft, houseTop, houseLeft + houseWidthPx, houseTop + houseHeightPx))

        // A couple of small puffs drifting up from the chimney — cheap, looping, and gives the
        // house some life instead of sitting there as a static painting.
        val chimneyX = houseLeft + houseWidthPx * HouseSprite.CHIMNEY_X_FRACTION
        val chimneyTop = houseTop + houseHeightPx * HouseSprite.CHIMNEY_TOP_Y_FRACTION
        for (puff in 0 until 2) {
            val phase = ((animClock.elapsedMs + puff * (SMOKE_CYCLE_MS / 2f)) % SMOKE_CYCLE_MS) / SMOKE_CYCLE_MS
            val riseY = chimneyTop - phase * 46f
            val drift = phase * 10f
            val size = 10f + phase * 10f
            smokePaint.alpha = (150 * (1f - phase)).toInt().coerceIn(0, 150)
            canvas.drawRect(chimneyX + drift - size / 2f, riseY - size / 2f, chimneyX + drift + size / 2f, riseY + size / 2f, smokePaint)
        }
    }
}
