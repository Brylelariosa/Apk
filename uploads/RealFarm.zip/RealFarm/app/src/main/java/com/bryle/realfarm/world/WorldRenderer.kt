package com.bryle.realfarm.world

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.bryle.realfarm.engine.Camera2D
import com.bryle.realfarm.farming.CropDatabase
import com.bryle.realfarm.graphics.AnimationClock
import com.bryle.realfarm.graphics.CropSprites
import com.bryle.realfarm.graphics.TileSprites

/** Pure rendering: takes a world + camera and draws tiles/crops. Holds no game state of its own. */
class WorldRenderer {

    companion object {
        private const val WATER_MS_PER_FRAME = 500
        private const val SWAY_MS_PER_FRAME = 650
    }

    private val waterMarkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(140, 0xBF, 0xE3, 0xF2)
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    fun draw(canvas: Canvas, world: WorldMap, camera: Camera2D, animClock: AnimationClock) {
        val tileSize = WorldMap.TILE_SIZE
        val waterFrame = animClock.frame(2, WATER_MS_PER_FRAME)
        // Discrete left/right sway on mature crops so the farm doesn't feel static; cheap since
        // it only ever shifts the draw position by a pixel, never re-renders the sprite itself.
        val swayOffset = if (animClock.frame(2, SWAY_MS_PER_FRAME) == 0) -1f else 1f

        world.forEachTile { x, y, tile ->
            val screenX = camera.worldToScreenX(x * tileSize)
            val screenY = camera.worldToScreenY(y * tileSize)

            // Cull tiles fully outside the viewport.
            if (screenX + tileSize < 0 || screenY + tileSize < 0 ||
                screenX > camera.viewportWidth || screenY > camera.viewportHeight
            ) return@forEachTile

            val tileRect = RectF(screenX, screenY, screenX + tileSize, screenY + tileSize)
            TileSprites.spriteFor(tile.type, waterFrame).drawFill(canvas, tileRect)

            val crop = tile.plantedCrop
            if (crop != null) {
                val def = CropDatabase.tryGet(crop.cropId)
                if (def != null) {
                    val fraction = crop.growthFraction(def)
                    val cx = screenX + tileSize / 2f + (if (fraction >= 0.75f && !crop.wilted) swayOffset else 0f)
                    val cy = screenY + tileSize / 2f
                    val spriteSize = tileSize * (0.45f + 0.5f * fraction)
                    CropSprites.spriteFor(fraction, def.color, crop.wilted).drawCentered(canvas, cx, cy, spriteSize)
                    if (crop.wateredToday) {
                        canvas.drawCircle(cx, cy, spriteSize / 2f + 6f, waterMarkPaint)
                    }
                }
            }
        }
    }
}
