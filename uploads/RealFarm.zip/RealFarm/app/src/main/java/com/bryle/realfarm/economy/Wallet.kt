package com.bryle.realfarm.economy

class Wallet(startingBalance: Int = 120) {

    var balance: Int = startingBalance
        private set

    fun deposit(amount: Int) {
        if (amount > 0) balance += amount
    }

    fun trySpend(amount: Int): Boolean {
        if (amount <= 0) return true
        if (balance < amount) return false
        balance -= amount
        return true
    }

    fun restoreFromSave(value: Int) {
        balance = value
    }
}
