package com.bryle.realfarm.world

import com.bryle.realfarm.farming.PlantedCrop

data class FarmTile(
    var type: TileType = TileType.GRASS,
    var plantedCrop: PlantedCrop? = null
)
