package com.bryle.realfarm.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.bryle.realfarm.core.GameEngine
import com.bryle.realfarm.engine.GameView
import com.bryle.realfarm.farming.CropDatabase
import com.bryle.realfarm.inventory.ItemType

object InventoryDialog {

    fun show(context: Context, engine: GameEngine, gameView: GameView) {
        val dialog = AlertDialog.Builder(context)
            .setTitle("Inventory")
            .setPositiveButton("Close", null)
            .create()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 24)
        }
        val scroll = ScrollView(context)
        scroll.addView(container)
        dialog.setView(scroll)

        fun refresh() {
            container.removeAllViews()
            val stacks = engine.state.inventory.allStacks()

            if (stacks.isEmpty()) {
                container.addView(TextView(context).apply {
                    text = "Empty. Visit the shop to buy seeds, food or medicine."
                    setTextColor(Color.LTGRAY)
                })
                return
            }

            for (stack in stacks) {
                val id = stack.itemId
                when {
                    id.startsWith("seed_") -> {
                        val def = CropDatabase.tryGet(id.removePrefix("seed_")) ?: continue
                        addRow(
                            context, container,
                            title = "${def.displayName} Seeds x${stack.quantity}",
                            subtitle = "Select the Seeds tool on the farm to plant",
                            buttonLabel = "—",
                            enabled = false
                        ) {}
                    }
                    id.startsWith("crop_") -> {
                        val def = CropDatabase.tryGet(id.removePrefix("crop_")) ?: continue
                        addRow(
                            context, container,
                            title = "${def.displayName} x${stack.quantity}",
                            subtitle = "Eat for +${def.foodRestoreAmount} hunger, or sell at the shop",
                            buttonLabel = "Eat",
                            enabled = stack.quantity > 0
                        ) {
                            toastResult(context, engine.eatItem(id, def.foodRestoreAmount))
                            refresh()
                        }
                    }
                    id == ItemType.MEDICINE.id -> {
                        addRow(
                            context, container,
                            title = "Medicine x${stack.quantity}",
                            subtitle = "Speeds up recovery from sickness",
                            buttonLabel = "Use",
                            enabled = stack.quantity > 0
                        ) {
                            toastResult(context, engine.useMedicine())
                            refresh()
                        }
                    }
                    else -> {
                        val food = ItemType.SHOP_FOOD.find { it.id == id } ?: continue
                        addRow(
                            context, container,
                            title = "${food.displayName} x${stack.quantity}",
                            subtitle = "Eat for +${food.hungerRestore} hunger",
                            buttonLabel = "Eat",
                            enabled = stack.quantity > 0
                        ) {
                            toastResult(context, engine.eatItem(id, food.hungerRestore))
                            refresh()
                        }
                    }
                }
            }
        }

        refresh()
        dialog.setOnDismissListener { gameView.syncSelectedTool() }
        dialog.show()
    }
}
