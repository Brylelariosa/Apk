package com.bryle.realfarm.ui

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.bryle.realfarm.core.GameEngine
import com.bryle.realfarm.engine.GameView
import com.bryle.realfarm.entity.Player
import com.bryle.realfarm.farming.CropDatabase
import com.bryle.realfarm.graphics.ItemIcons
import com.bryle.realfarm.inventory.ItemType

/**
 * A visual slot grid (pixel-art icon + quantity per item) instead of a plain text list. Tapping
 * a usable item opens a small action sheet to eat/use it immediately or assign it to one of the
 * HUD quick-use slots, which is how items get "placed into a slot" for fast in-world use.
 */
object InventoryDialog {

    fun show(context: Context, engine: GameEngine, gameView: GameView) {
        val dialog = AlertDialog.Builder(context)
            .setTitle("Inventory")
            .setPositiveButton("Close", null)
            .create()

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 24)
        }
        val scroll = ScrollView(context)
        scroll.addView(container)
        dialog.setView(scroll)

        fun refresh() {
            container.removeAllViews()
            val stacks = engine.state.inventory.allStacks()

            if (stacks.isEmpty()) {
                container.addView(TextView(context).apply {
                    text = "Empty. Visit the shop to buy seeds, food or medicine."
                    setTextColor(Color.LTGRAY)
                })
                return
            }

            val seedIds = mutableListOf<String>()
            val usableIds = mutableListOf<String>()
            for (stack in stacks) {
                if (labelFor(stack.itemId) == null) continue
                if (stack.itemId.startsWith("seed_")) seedIds.add(stack.itemId) else usableIds.add(stack.itemId)
            }

            if (seedIds.isNotEmpty()) {
                addSectionHeader(context, container, "Seeds \u2014 select the Seeds tool on the farm to plant")
                val slots = seedIds.map { id ->
                    val qty = engine.state.inventory.quantityOf(id)
                    SlotItem(ItemIcons.iconFor(id), qty, "${labelFor(id)} x$qty")
                }
                addSlotGrid(context, container, slots) {
                    Toast.makeText(context, "Select the Seeds tool on the farm to plant this", Toast.LENGTH_SHORT).show()
                }
            }

            if (usableIds.isNotEmpty()) {
                addSectionHeader(context, container, "Tap an item to eat/use it or assign it to a quick slot")
                val slots = usableIds.map { id ->
                    val qty = engine.state.inventory.quantityOf(id)
                    SlotItem(ItemIcons.iconFor(id), qty, "${labelFor(id)} x$qty")
                }
                addSlotGrid(context, container, slots) { index ->
                    val itemId = usableIds[index]
                    val qty = engine.state.inventory.quantityOf(itemId)
                    showItemActions(context, engine, gameView, itemId, "${labelFor(itemId)} x$qty") { refresh() }
                }
            }
        }

        refresh()
        dialog.setOnDismissListener { gameView.syncSelectedTool() }
        dialog.show()
    }

    private fun labelFor(itemId: String): String? = when {
        itemId.startsWith("seed_") -> CropDatabase.tryGet(itemId.removePrefix("seed_"))?.let { "${it.displayName} Seeds" }
        itemId.startsWith("crop_") -> CropDatabase.tryGet(itemId.removePrefix("crop_"))?.displayName
        itemId == ItemType.MEDICINE.id -> "Medicine"
        else -> ItemType.SHOP_FOOD.find { it.id == itemId }?.displayName
    }

    private fun showItemActions(
        context: Context,
        engine: GameEngine,
        gameView: GameView,
        itemId: String,
        title: String,
        onChanged: () -> Unit
    ) {
        val quickSlotLabels = (0 until Player.QUICK_SLOT_COUNT).map { "Assign to Slot ${it + 1}" }
        val actions = (listOf("Use now") + quickSlotLabels).toTypedArray()

        AlertDialog.Builder(context)
            .setTitle(title)
            .setItems(actions) { _, which ->
                if (which == 0) {
                    toastResult(context, engine.useItem(itemId))
                    onChanged()
                } else {
                    val slotIndex = which - 1
                    engine.assignQuickSlot(slotIndex, itemId)
                    Toast.makeText(context, "$title assigned to quick slot ${slotIndex + 1}", Toast.LENGTH_SHORT).show()
                    gameView.syncSelectedTool()
                }
            }
            .show()
    }
}
