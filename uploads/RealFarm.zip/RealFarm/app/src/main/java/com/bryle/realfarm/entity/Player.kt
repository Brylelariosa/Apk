package com.bryle.realfarm.entity

import com.bryle.realfarm.core.Direction
import com.bryle.realfarm.core.Vector2
import com.bryle.realfarm.farming.Tool
import com.bryle.realfarm.world.WorldMap

/** Player position is in world pixels; tile coordinates are derived by dividing by [WorldMap.TILE_SIZE]. */
class Player(startX: Float, startY: Float) {

    companion object {
        const val BASE_SPEED = 220f // pixels per second
        const val RADIUS = 22f
    }

    var position: Vector2 = Vector2(startX, startY)
        private set

    var facing: Direction = Direction.DOWN
    var selectedTool: Tool = Tool.HAND
    var selectedCropId: String = "wheat"

    fun move(inputX: Float, inputY: Float, deltaSeconds: Float, speedMultiplier: Float, world: WorldMap) {
        val input = Vector2(inputX, inputY)
        if (input.length() < 0.05f) return
        facing = Direction.fromVector(inputX, inputY, facing)
        val normalized = input.normalized()
        val distance = BASE_SPEED * speedMultiplier * deltaSeconds
        var newX = position.x + normalized.x * distance
        var newY = position.y + normalized.y * distance

        newX = newX.coerceIn(RADIUS, world.worldPixelWidth() - RADIUS)
        newY = newY.coerceIn(RADIUS, world.worldPixelHeight() - RADIUS)

        position = Vector2(newX, newY)
    }

    fun tileX(): Int = (position.x / WorldMap.TILE_SIZE).toInt()
    fun tileY(): Int = (position.y / WorldMap.TILE_SIZE).toInt()

    /** The tile the player is currently facing — the target of hoe/water/plant/harvest actions. */
    fun targetTile(): Pair<Int, Int> = Pair(tileX() + facing.dx, tileY() + facing.dy)

    fun restorePosition(x: Float, y: Float) {
        position = Vector2(x, y)
    }
}
