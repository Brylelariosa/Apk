package com.bryle.realfarm.engine

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.hypot

/**
 * A draggable on-screen joystick. Owns its own active pointer id so it can be driven
 * independently of other simultaneous touches (tool belt / action button).
 */
class VirtualJoystick {

    companion object {
        private const val BASE_RADIUS = 95f
        private const val KNOB_RADIUS = 45f
        private const val ACTIVATION_RADIUS = 140f // slightly larger than base so nearby taps still grab it
    }

    private var baseCx = 0f
    private var baseCy = 0f
    private var knobCx = 0f
    private var knobCy = 0f

    var activePointerId: Int = -1
        private set

    var inputX: Float = 0f
        private set
    var inputY: Float = 0f
        private set

    private val baseFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(70, 255, 255, 255) }
    private val baseStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(140, 255, 255, 255)
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val knobFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 255, 255, 255) }

    fun setBaseCenter(x: Float, y: Float) {
        baseCx = x
        baseCy = y
        knobCx = x
        knobCy = y
    }

    fun tryActivate(pointerId: Int, x: Float, y: Float): Boolean {
        if (activePointerId != -1) return false
        if (hypot(x - baseCx, y - baseCy) > ACTIVATION_RADIUS) return false
        activePointerId = pointerId
        updateKnob(x, y)
        return true
    }

    fun updateIfActive(pointerId: Int, x: Float, y: Float) {
        if (pointerId != activePointerId) return
        updateKnob(x, y)
    }

    fun releaseIfActive(pointerId: Int) {
        if (pointerId != activePointerId) return
        activePointerId = -1
        knobCx = baseCx
        knobCy = baseCy
        inputX = 0f
        inputY = 0f
    }

    private fun updateKnob(x: Float, y: Float) {
        val dx = x - baseCx
        val dy = y - baseCy
        val dist = hypot(dx, dy)
        if (dist <= BASE_RADIUS) {
            knobCx = x
            knobCy = y
        } else {
            val scale = BASE_RADIUS / dist
            knobCx = baseCx + dx * scale
            knobCy = baseCy + dy * scale
        }
        inputX = ((knobCx - baseCx) / BASE_RADIUS).coerceIn(-1f, 1f)
        inputY = ((knobCy - baseCy) / BASE_RADIUS).coerceIn(-1f, 1f)
    }

    fun draw(canvas: Canvas) {
        canvas.drawCircle(baseCx, baseCy, BASE_RADIUS, baseFill)
        canvas.drawCircle(baseCx, baseCy, BASE_RADIUS, baseStroke)
        canvas.drawCircle(knobCx, knobCy, KNOB_RADIUS, knobFill)
    }
}
