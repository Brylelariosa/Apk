package com.bryle.realfarm.farming

sealed class ActionResult {
    data class Success(val message: String? = null) : ActionResult()
    data class Failure(val reason: String) : ActionResult()
}
