package com.bryle.realfarm.ui

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.bryle.realfarm.farming.ActionResult
import com.bryle.realfarm.graphics.PixelSprite

internal fun addSectionHeader(context: Context, container: LinearLayout, text: String) {
    val tv = TextView(context)
    tv.text = text
    tv.setTextColor(Color.rgb(0xFF, 0xD5, 0x4F))
    tv.textSize = 17f
    tv.setPadding(0, 28, 0, 8)
    container.addView(tv)
}

private fun buildTextBlock(context: Context, title: String, subtitle: String): LinearLayout {
    val textContainer = LinearLayout(context)
    textContainer.orientation = LinearLayout.VERTICAL
    textContainer.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    val titleView = TextView(context)
    titleView.text = title
    titleView.setTextColor(Color.WHITE)
    titleView.textSize = 15f
    textContainer.addView(titleView)

    val subtitleView = TextView(context)
    subtitleView.text = subtitle
    subtitleView.setTextColor(Color.LTGRAY)
    subtitleView.textSize = 12f
    textContainer.addView(subtitleView)

    return textContainer
}

internal fun addRow(
    context: Context,
    container: LinearLayout,
    title: String,
    subtitle: String,
    buttonLabel: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val row = LinearLayout(context)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, 12, 0, 12)
    row.addView(buildTextBlock(context, title, subtitle))

    val button = Button(context)
    button.text = buttonLabel
    button.isEnabled = enabled
    button.setOnClickListener { onClick() }
    row.addView(button)

    container.addView(row)
}

internal fun addRowWithTwoButtons(
    context: Context,
    container: LinearLayout,
    title: String,
    subtitle: String,
    button1Label: String,
    button1Enabled: Boolean,
    onClick1: () -> Unit,
    button2Label: String,
    button2Enabled: Boolean,
    onClick2: () -> Unit
) {
    val row = LinearLayout(context)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, 12, 0, 12)
    row.addView(buildTextBlock(context, title, subtitle))

    val button1 = Button(context)
    button1.text = button1Label
    button1.isEnabled = button1Enabled
    button1.setOnClickListener { onClick1() }
    row.addView(button1)

    val button2 = Button(context)
    button2.text = button2Label
    button2.isEnabled = button2Enabled
    button2.setOnClickListener { onClick2() }
    row.addView(button2)

    container.addView(row)
}

internal fun toastResult(context: Context, result: ActionResult) {
    val msg = when (result) {
        is ActionResult.Success -> result.message ?: "Done"
        is ActionResult.Failure -> result.reason
    }
    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
}

/** One tappable square in a [addSlotGrid] — an item's icon, its owned quantity, and a
 *  description used both for accessibility and as the label of the tap action sheet. */
internal data class SlotItem(val icon: PixelSprite, val quantity: Int, val description: String)

private const val SLOT_SIZE_DP = 64

/** Lays [items] out as a wrapping grid of pixel-icon slots (like a real inventory grid) instead
 *  of a plain list. Tapping a slot invokes [onSlotTapped] with that item's index in [items]. */
internal fun addSlotGrid(
    context: Context,
    container: LinearLayout,
    items: List<SlotItem>,
    columns: Int = 4,
    onSlotTapped: (Int) -> Unit
) {
    val density = context.resources.displayMetrics.density
    val slotSizePx = (SLOT_SIZE_DP * density).toInt()
    val spacingPx = (10 * density).toInt()

    items.chunked(columns).forEachIndexed { rowIndex, rowItems ->
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(0, if (rowIndex == 0) spacingPx else spacingPx / 2, 0, spacingPx / 2)
        for ((colIndex, item) in rowItems.withIndex()) {
            val globalIndex = rowIndex * columns + colIndex
            row.addView(
                buildSlotView(context, item, slotSizePx, spacingPx, colIndex > 0) { onSlotTapped(globalIndex) }
            )
        }
        container.addView(row)
    }
}

private fun buildSlotView(
    context: Context,
    item: SlotItem,
    sizePx: Int,
    spacingPx: Int,
    addStartMargin: Boolean,
    onClick: () -> Unit
): FrameLayout {
    val density = context.resources.displayMetrics.density
    val frame = FrameLayout(context)
    val frameParams = LinearLayout.LayoutParams(sizePx, sizePx)
    if (addStartMargin) frameParams.marginStart = spacingPx
    frame.layoutParams = frameParams
    frame.background = GradientDrawable().apply {
        setColor(Color.argb(160, 40, 40, 40))
        setCornerRadius(10f * density)
        setStroke((1.5f * density).toInt(), Color.argb(140, 200, 200, 200))
    }
    frame.isClickable = true
    frame.isFocusable = true
    frame.contentDescription = item.description
    frame.setOnClickListener { onClick() }

    val iconPad = (sizePx * 0.16f).toInt()
    val iconView = ImageView(context)
    iconView.layoutParams = FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
    ).apply { setMargins(iconPad, iconPad, iconPad, iconPad) }
    iconView.scaleType = ImageView.ScaleType.FIT_CENTER
    iconView.setImageDrawable(BitmapDrawable(context.resources, item.icon.toBitmap()).apply { isFilterBitmap = false })
    frame.addView(iconView)

    val qtyView = TextView(context)
    qtyView.text = "x${item.quantity}"
    qtyView.setTextColor(Color.WHITE)
    qtyView.textSize = 11f
    qtyView.setPadding((4 * density).toInt(), (1 * density).toInt(), (4 * density).toInt(), (1 * density).toInt())
    qtyView.background = GradientDrawable().apply {
        setColor(Color.argb(210, 0, 0, 0))
        setCornerRadius(6f * density)
    }
    qtyView.layoutParams = FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.END
        setMargins(0, 0, (3 * density).toInt(), (3 * density).toInt())
    }
    frame.addView(qtyView)

    return frame
}
