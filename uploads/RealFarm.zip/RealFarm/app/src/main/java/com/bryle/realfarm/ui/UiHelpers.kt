package com.bryle.realfarm.ui

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.bryle.realfarm.farming.ActionResult

internal fun addSectionHeader(context: Context, container: LinearLayout, text: String) {
    val tv = TextView(context)
    tv.text = text
    tv.setTextColor(Color.rgb(0xFF, 0xD5, 0x4F))
    tv.textSize = 17f
    tv.setPadding(0, 28, 0, 8)
    container.addView(tv)
}

private fun buildTextBlock(context: Context, title: String, subtitle: String): LinearLayout {
    val textContainer = LinearLayout(context)
    textContainer.orientation = LinearLayout.VERTICAL
    textContainer.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)

    val titleView = TextView(context)
    titleView.text = title
    titleView.setTextColor(Color.WHITE)
    titleView.textSize = 15f
    textContainer.addView(titleView)

    val subtitleView = TextView(context)
    subtitleView.text = subtitle
    subtitleView.setTextColor(Color.LTGRAY)
    subtitleView.textSize = 12f
    textContainer.addView(subtitleView)

    return textContainer
}

internal fun addRow(
    context: Context,
    container: LinearLayout,
    title: String,
    subtitle: String,
    buttonLabel: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val row = LinearLayout(context)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, 12, 0, 12)
    row.addView(buildTextBlock(context, title, subtitle))

    val button = Button(context)
    button.text = buttonLabel
    button.isEnabled = enabled
    button.setOnClickListener { onClick() }
    row.addView(button)

    container.addView(row)
}

internal fun addRowWithTwoButtons(
    context: Context,
    container: LinearLayout,
    title: String,
    subtitle: String,
    button1Label: String,
    button1Enabled: Boolean,
    onClick1: () -> Unit,
    button2Label: String,
    button2Enabled: Boolean,
    onClick2: () -> Unit
) {
    val row = LinearLayout(context)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.setPadding(0, 12, 0, 12)
    row.addView(buildTextBlock(context, title, subtitle))

    val button1 = Button(context)
    button1.text = button1Label
    button1.isEnabled = button1Enabled
    button1.setOnClickListener { onClick1() }
    row.addView(button1)

    val button2 = Button(context)
    button2.text = button2Label
    button2.isEnabled = button2Enabled
    button2.setOnClickListener { onClick2() }
    row.addView(button2)

    container.addView(row)
}

internal fun toastResult(context: Context, result: ActionResult) {
    val msg = when (result) {
        is ActionResult.Success -> result.message ?: "Done"
        is ActionResult.Failure -> result.reason
    }
    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
}
