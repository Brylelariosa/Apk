package com.bryle.realfarm.needs

import com.bryle.realfarm.time.GameClock

/**
 * Models the "eat three times a day" requirement. Hunger drains continuously and also takes a
 * direct hit whenever a meal window (breakfast/lunch/dinner) closes without the player eating.
 * [missedMealsStreak] is read by [HealthSystem] to raise sickness risk.
 */
class HungerSystem {

    companion object {
        private const val PASSIVE_DRAIN_PER_SECOND = 0.07f
        private const val MISSED_MEAL_PENALTY = 15f
        const val CRITICAL_THRESHOLD = 20f
    }

    var hunger: Float = 80f
        private set

    var missedMealsStreak: Int = 0
        private set

    private var eatenBreakfast = false
    private var eatenLunch = false
    private var eatenDinner = false
    private var lastWindow: GameClock.MealWindow = GameClock.MealWindow.NONE

    val isCritical: Boolean get() = hunger <= CRITICAL_THRESHOLD

    /** Call every frame with the clock's current meal window. */
    fun tick(deltaSeconds: Float, currentWindow: GameClock.MealWindow) {
        hunger = (hunger - PASSIVE_DRAIN_PER_SECOND * deltaSeconds).coerceIn(0f, 100f)

        if (currentWindow != lastWindow) {
            // A window just closed — penalize if it wasn't fulfilled.
            when (lastWindow) {
                GameClock.MealWindow.BREAKFAST -> if (!eatenBreakfast) missMeal()
                GameClock.MealWindow.LUNCH -> if (!eatenLunch) missMeal()
                GameClock.MealWindow.DINNER -> if (!eatenDinner) missMeal()
                GameClock.MealWindow.NONE -> {}
            }
            lastWindow = currentWindow
        }
    }

    private fun missMeal() {
        hunger = (hunger - MISSED_MEAL_PENALTY).coerceIn(0f, 100f)
        missedMealsStreak += 1
    }

    /** Records that the player ate during the given window and restores hunger. */
    fun eat(restoreAmount: Int, currentWindow: GameClock.MealWindow) {
        hunger = (hunger + restoreAmount).coerceIn(0f, 100f)
        missedMealsStreak = 0
        when (currentWindow) {
            GameClock.MealWindow.BREAKFAST -> eatenBreakfast = true
            GameClock.MealWindow.LUNCH -> eatenLunch = true
            GameClock.MealWindow.DINNER -> eatenDinner = true
            GameClock.MealWindow.NONE -> {} // snacking outside a window still restores hunger, just doesn't satisfy that meal
        }
    }

    fun onNewDay() {
        eatenBreakfast = false
        eatenLunch = false
        eatenDinner = false
        lastWindow = GameClock.MealWindow.NONE
    }

    fun mealsEatenToday(): Int = listOf(eatenBreakfast, eatenLunch, eatenDinner).count { it }

    fun toSaveValue(): Float = hunger

    fun restoreFromSave(value: Float, missed: Int) {
        hunger = value.coerceIn(0f, 100f)
        missedMealsStreak = missed
    }
}
