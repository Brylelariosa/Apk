package com.bryle.realfarm.core

import com.bryle.realfarm.economy.BillingSystem
import com.bryle.realfarm.economy.MarketSystem
import com.bryle.realfarm.economy.Wallet
import com.bryle.realfarm.entity.Player
import com.bryle.realfarm.farming.FarmingSystem
import com.bryle.realfarm.inventory.Inventory
import com.bryle.realfarm.needs.HealthSystem
import com.bryle.realfarm.needs.HungerSystem
import com.bryle.realfarm.needs.StaminaSystem
import com.bryle.realfarm.time.GameClock
import com.bryle.realfarm.world.WorldMap

/**
 * Owns every subsystem. This is intentionally just wiring/composition — behaviour lives in the
 * individual systems, and [com.bryle.realfarm.core.GameEngine] is the only thing that reaches
 * into here to orchestrate them. Keeping this dumb makes save/load and testing straightforward.
 */
class GameState {
    val world: WorldMap = WorldMap.generateDefault()
    val clock: GameClock = GameClock()
    val wallet: Wallet = Wallet()
    val inventory: Inventory = Inventory()
    val market: MarketSystem = MarketSystem()
    val billing: BillingSystem = BillingSystem()
    val stamina: StaminaSystem = StaminaSystem()
    val hunger: HungerSystem = HungerSystem()
    val health: HealthSystem = HealthSystem()
    val player: Player = Player(
        startX = WorldMap.TILE_SIZE * 3f,
        startY = WorldMap.TILE_SIZE * 3f
    )
    val farming: FarmingSystem = FarmingSystem(world, inventory, stamina, billing)
}
