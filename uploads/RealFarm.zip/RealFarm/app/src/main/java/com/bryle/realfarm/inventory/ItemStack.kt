package com.bryle.realfarm.inventory

data class ItemStack(val itemId: String, var quantity: Int)
