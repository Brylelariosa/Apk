package com.bryle.realfarm.entity

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.bryle.realfarm.engine.Camera2D
import com.bryle.realfarm.graphics.AnimationClock
import com.bryle.realfarm.graphics.PlayerSprites

class PlayerRenderer {

    companion object {
        /** On-screen sprite height in pixels; roughly matches the old circle's diameter. */
        private const val SPRITE_HEIGHT = 52f
        private const val WALK_MS_PER_FRAME = 140
    }

    private val sickTintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(90, 0x8B, 0xC3, 0x4A) }

    fun draw(canvas: Canvas, player: Player, camera: Camera2D, isSick: Boolean, isMoving: Boolean, animClock: AnimationClock) {
        val sx = camera.worldToScreenX(player.position.x)
        val sy = camera.worldToScreenY(player.position.y)

        // Idle players still get a slow 2-frame breathing sway; walking players cycle faster.
        val msPerFrame = if (isMoving) WALK_MS_PER_FRAME else WALK_MS_PER_FRAME * 4
        val frame = animClock.frame(2, msPerFrame)
        val (sprite, flip) = PlayerSprites.spriteFor(player.facing, frame)

        // A slight vertical bob on the "off" walk frame sells the step without needing more art.
        val bob = if (isMoving && frame == 1) -3f else 0f
        sprite.drawCentered(canvas, sx, sy + bob, SPRITE_HEIGHT, flip)

        if (isSick) {
            canvas.drawCircle(sx, sy, Player.RADIUS * 0.9f, sickTintPaint)
        }
    }
}
