package com.bryle.realfarm.entity

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.bryle.realfarm.engine.Camera2D

class PlayerRenderer {

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x3E, 0x2B, 0x1F) }
    private val shirtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0xD9, 0x4A, 0x3A) }
    private val sickPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x8B, 0xC3, 0x4A) }
    private val facingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0xFF, 0xE0, 0x82) }

    fun draw(canvas: Canvas, player: Player, camera: Camera2D, isSick: Boolean) {
        val sx = camera.worldToScreenX(player.position.x)
        val sy = camera.worldToScreenY(player.position.y)

        canvas.drawCircle(sx, sy, Player.RADIUS, bodyPaint)
        canvas.drawCircle(sx, sy, Player.RADIUS * 0.7f, if (isSick) sickPaint else shirtPaint)

        val indicatorOffset = Player.RADIUS * 1.3f
        val fx = sx + player.facing.dx * indicatorOffset
        val fy = sy + player.facing.dy * indicatorOffset
        canvas.drawCircle(fx, fy, 6f, facingPaint)
    }
}
