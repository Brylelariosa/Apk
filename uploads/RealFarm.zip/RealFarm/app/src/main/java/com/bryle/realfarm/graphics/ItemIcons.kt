package com.bryle.realfarm.graphics

import android.graphics.Color
import com.bryle.realfarm.farming.CropDatabase
import com.bryle.realfarm.inventory.ItemType

/**
 * Resolves any inventory item id to a small pixel-art icon, used by the inventory slot grid and
 * the HUD quick-slot buttons. Icons are built once per id and cached: item ids are a small fixed
 * set for the process lifetime, so there's no reason to rebuild a bitmap on every dialog refresh.
 */
object ItemIcons {

    private val seedPalette = mapOf(
        't' to Color.rgb(0x6B, 0x43, 0x26),
        'p' to Color.rgb(0x8A, 0x5A, 0x35)
    )
    private val breadPalette = mapOf(
        'b' to Color.rgb(0xC7, 0x9A, 0x5B),
        'l' to Color.rgb(0xE8, 0xC3, 0x8E),
        'd' to Color.rgb(0x9A, 0x6B, 0x3C)
    )
    private val cheesePalette = mapOf(
        'y' to Color.rgb(0xF4, 0xD0, 0x3F),
        'o' to Color.rgb(0xC7, 0x9A, 0x1E)
    )
    private val medicinePalette = mapOf(
        'k' to Color.rgb(0x4A, 0x4A, 0x4A),
        'w' to Color.rgb(0xF2, 0xF2, 0xF2),
        'c' to Color.rgb(0xD3, 0x2F, 0x2F)
    )

    private val SEED_POUCH_ROWS = arrayOf(
        "         ",
        "   ttt   ",
        "  pppp   ",
        " pppppp  ",
        " pp c pp ",
        " ppc cpp ",
        " pppppp  ",
        "  pppp   ",
        "         "
    )
    private val BREAD_ROWS = arrayOf(
        "         ",
        "         ",
        "  lbbbl  ",
        " lbdbdbl ",
        "bbdbdbdbb",
        "bdbdbdbdb",
        " bbbbbbb ",
        "         ",
        "         "
    )
    private val CHEESE_ROWS = arrayOf(
        "         ",
        "  yyyyy  ",
        " yyoyyyy ",
        "yyyyyoyyy",
        "yoyyyyyy ",
        "yyyyoyyy ",
        " yyyyyyy ",
        "  yyyyy  ",
        "         "
    )
    private val MEDICINE_ROWS = arrayOf(
        "         ",
        "  kkkkk  ",
        "  wwwww  ",
        " wwwwwww ",
        " wwcccww ",
        " wwcccww ",
        " wwwwwww ",
        "  wwwww  ",
        "         "
    )

    private val bread by lazy { PixelSprite(PixelArt.fromRows(BREAD_ROWS, breadPalette)) }
    private val cheese by lazy { PixelSprite(PixelArt.fromRows(CHEESE_ROWS, cheesePalette)) }
    private val medicine by lazy { PixelSprite(PixelArt.fromRows(MEDICINE_ROWS, medicinePalette)) }

    private val seedPouchCache = HashMap<Int, PixelSprite>()
    private fun seedPouchFor(color: Int): PixelSprite = seedPouchCache.getOrPut(color) {
        PixelSprite(PixelArt.fromRows(SEED_POUCH_ROWS, seedPalette + ('c' to color)))
    }

    /** Resolves any item id that can appear in [com.bryle.realfarm.inventory.Inventory] to an icon. */
    fun iconFor(itemId: String): PixelSprite = when {
        itemId.startsWith("seed_") -> {
            val def = CropDatabase.tryGet(itemId.removePrefix("seed_"))
            seedPouchFor(def?.color ?: Color.rgb(0xC2, 0xA9, 0x77))
        }
        itemId.startsWith("crop_") -> {
            val def = CropDatabase.tryGet(itemId.removePrefix("crop_"))
            CropSprites.spriteFor(growthFraction = 1f, color = def?.color ?: Color.WHITE, isWilted = false)
        }
        itemId == ItemType.MEDICINE.id -> medicine
        itemId == ItemType.CHEESE.id -> cheese
        else -> bread // Covers ItemType.BREAD and is a safe fallback for any other food id.
    }
}
