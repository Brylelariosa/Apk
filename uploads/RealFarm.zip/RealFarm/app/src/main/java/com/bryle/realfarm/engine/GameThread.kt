package com.bryle.realfarm.engine

import android.graphics.Canvas
import android.view.SurfaceHolder

/**
 * Runs the update/draw loop on a background thread. Delta time is clamped so a long pause
 * (e.g. a debugger breakpoint, or the app being backgrounded without the surface being torn
 * down) can't cause a single huge simulation step.
 */
class GameThread(
    private val surfaceHolder: SurfaceHolder,
    private val onUpdate: (deltaSeconds: Float) -> Unit,
    private val onDraw: (Canvas) -> Unit
) : Thread("RealFarm-GameThread") {

    companion object {
        private const val MAX_DELTA_SECONDS = 0.05f
    }

    @Volatile
    var running = false

    override fun run() {
        var lastTimeNanos = System.nanoTime()
        while (running) {
            val now = System.nanoTime()
            val rawDelta = (now - lastTimeNanos) / 1_000_000_000f
            lastTimeNanos = now
            val deltaSeconds = rawDelta.coerceIn(0f, MAX_DELTA_SECONDS)

            onUpdate(deltaSeconds)

            var canvas: Canvas? = null
            try {
                canvas = surfaceHolder.lockCanvas()
                if (canvas != null) {
                    onDraw(canvas)
                }
            } finally {
                if (canvas != null) {
                    try {
                        surfaceHolder.unlockCanvasAndPost(canvas)
                    } catch (e: IllegalStateException) {
                        // Surface was torn down mid-frame; safe to ignore.
                    }
                }
            }
        }
    }
}
