package com.bryle.realfarm.core

/** Grid-aligned facing direction. Used to pick which tile a player action targets. */
enum class Direction(val dx: Int, val dy: Int) {
    UP(0, -1),
    DOWN(0, 1),
    LEFT(-1, 0),
    RIGHT(1, 0);

    companion object {
        /** Picks the dominant direction from a raw movement vector, keeping the previous facing if input is ~zero. */
        fun fromVector(x: Float, y: Float, fallback: Direction): Direction {
            if (kotlin.math.abs(x) < 0.15f && kotlin.math.abs(y) < 0.15f) return fallback
            return if (kotlin.math.abs(x) > kotlin.math.abs(y)) {
                if (x > 0) RIGHT else LEFT
            } else {
                if (y > 0) DOWN else UP
            }
        }
    }
}
