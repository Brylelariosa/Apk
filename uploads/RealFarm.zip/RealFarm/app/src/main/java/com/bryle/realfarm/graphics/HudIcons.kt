package com.bryle.realfarm.graphics

import android.graphics.Color

/** Tiny pixel-art sun/moon icons for the HUD day/night indicator. */
object HudIcons {

    private val sunPalette = mapOf('s' to Color.rgb(0xF4, 0xD0, 0x3F))
    private val moonPalette = mapOf('m' to Color.rgb(0xC9, 0xD6, 0xE8))

    private val SUN_ROWS = arrayOf(
        "    s    ",
        " s     s ",
        "   sss   ",
        "  sssss  ",
        "s sssss s",
        "  sssss  ",
        "   sss   ",
        " s     s ",
        "    s    "
    )
    private val MOON_ROWS = arrayOf(
        "         ",
        "   mmm   ",
        "  mmm    ",
        " mmm     ",
        " mmm     ",
        " mmm     ",
        "  mmm    ",
        "   mmm   ",
        "         "
    )

    val sun by lazy { PixelSprite(PixelArt.fromRows(SUN_ROWS, sunPalette)) }
    val moon by lazy { PixelSprite(PixelArt.fromRows(MOON_ROWS, moonPalette)) }
}
