package com.bryle.realfarm.farming

import com.bryle.realfarm.economy.BillingSystem
import com.bryle.realfarm.inventory.Inventory
import com.bryle.realfarm.inventory.ItemType
import com.bryle.realfarm.needs.StaminaSystem
import com.bryle.realfarm.world.FarmTile
import com.bryle.realfarm.world.TileType
import com.bryle.realfarm.world.WorldMap

/**
 * All player-initiated farming actions live here, kept independent of rendering and input.
 * Stamina and water-bill effects are applied as side effects of the actions that cause them,
 * which is what makes "watering costs money later" and "working while exhausted is costly" felt
 * mechanics instead of separate, disconnected systems.
 */
class FarmingSystem(
    private val world: WorldMap,
    private val inventory: Inventory,
    private val stamina: StaminaSystem,
    private val billing: BillingSystem
) {
    companion object {
        const val MAX_WATER_CHARGES = 15
        private const val TILL_STAMINA_COST = 5f
        private const val WATER_STAMINA_COST = 2f
        private const val PLANT_STAMINA_COST = 2f
        private const val HARVEST_STAMINA_COST = 3f
        private const val MIN_STAMINA_TO_WORK = 3f
    }

    var waterCharges: Int = MAX_WATER_CHARGES
        private set

    fun till(x: Int, y: Int, workStaminaCostMultiplier: Float): ActionResult {
        val tile = world.getTile(x, y) ?: return ActionResult.Failure("Out of bounds")
        if (stamina.stamina < MIN_STAMINA_TO_WORK) return ActionResult.Failure("Too exhausted to work")
        if (tile.type != TileType.GRASS) return ActionResult.Failure("Can't till that")
        tile.type = TileType.TILLED
        stamina.drain(TILL_STAMINA_COST * workStaminaCostMultiplier)
        return ActionResult.Success("Tilled soil")
    }

    fun plant(x: Int, y: Int, cropId: String, workStaminaCostMultiplier: Float): ActionResult {
        val tile = world.getTile(x, y) ?: return ActionResult.Failure("Out of bounds")
        if (stamina.stamina < MIN_STAMINA_TO_WORK) return ActionResult.Failure("Too exhausted to work")
        if (tile.type != TileType.TILLED) return ActionResult.Failure("Needs tilled soil")
        if (tile.plantedCrop != null) return ActionResult.Failure("Already planted")
        val seedId = ItemType.seedFor(cropId, 0).id
        if (!inventory.tryRemove(seedId, 1)) return ActionResult.Failure("No seeds — buy some at the shop")
        tile.plantedCrop = PlantedCrop(cropId)
        stamina.drain(PLANT_STAMINA_COST * workStaminaCostMultiplier)
        return ActionResult.Success("Planted ${CropDatabase.get(cropId).displayName}")
    }

    fun water(x: Int, y: Int, workStaminaCostMultiplier: Float): ActionResult {
        val tile = world.getTile(x, y) ?: return ActionResult.Failure("Out of bounds")
        val crop = tile.plantedCrop ?: return ActionResult.Failure("Nothing planted there")
        if (billing.isWaterShutOff) return ActionResult.Failure("Water is shut off — pay your bill")
        if (waterCharges <= 0) return ActionResult.Failure("Watering can is empty")
        if (crop.wateredToday) return ActionResult.Failure("Already watered today")
        waterCharges -= 1
        crop.wateredToday = true
        billing.recordWaterUsage(1f)
        stamina.drain(WATER_STAMINA_COST * workStaminaCostMultiplier)
        return ActionResult.Success("Watered")
    }

    fun refillWateringCan(playerTileX: Int, playerTileY: Int): ActionResult {
        if (!world.isAdjacentToWaterSource(playerTileX, playerTileY)) {
            return ActionResult.Failure("Walk up to the pond to refill")
        }
        if (billing.isWaterShutOff) return ActionResult.Failure("Water is shut off — pay your bill")
        waterCharges = MAX_WATER_CHARGES
        return ActionResult.Success("Watering can refilled")
    }

    fun harvest(x: Int, y: Int, workStaminaCostMultiplier: Float): ActionResult {
        val tile = world.getTile(x, y) ?: return ActionResult.Failure("Out of bounds")
        val crop = tile.plantedCrop ?: return ActionResult.Failure("Nothing to harvest")
        if (stamina.stamina < MIN_STAMINA_TO_WORK) return ActionResult.Failure("Too exhausted to work")
        if (crop.wilted) {
            tile.plantedCrop = null
            return ActionResult.Failure("That crop wilted from lack of water")
        }
        val def = CropDatabase.get(crop.cropId)
        if (!crop.isReadyToHarvest(def)) return ActionResult.Failure("Not ready yet")
        inventory.add(ItemType.cropFor(crop.cropId, 0).id, def.yieldPerHarvest)
        tile.plantedCrop = null
        stamina.drain(HARVEST_STAMINA_COST * workStaminaCostMultiplier)
        return ActionResult.Success("Harvested ${def.yieldPerHarvest}x ${def.displayName}")
    }

    /** Advances every planted crop's growth by one day and handles wilting. Call once per new day. */
    fun advanceDailyGrowth() {
        world.forEachTile { _, _, tile ->
            val crop = tile.plantedCrop ?: return@forEachTile
            val def = CropDatabase.tryGet(crop.cropId) ?: return@forEachTile
            if (crop.wateredToday) {
                crop.growthDaysAccumulated += 1
                crop.daysUnwateredStreak = 0
            } else {
                crop.daysUnwateredStreak += 1
                if (crop.daysUnwateredStreak > def.maxUnwateredDays) {
                    crop.wilted = true
                }
            }
            crop.wateredToday = false
        }
    }

    fun tileAt(x: Int, y: Int): FarmTile? = world.getTile(x, y)

    fun restoreWaterCharges(value: Int) {
        waterCharges = value.coerceIn(0, MAX_WATER_CHARGES)
    }
}
