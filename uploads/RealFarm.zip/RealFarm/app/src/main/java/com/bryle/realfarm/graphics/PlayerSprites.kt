package com.bryle.realfarm.graphics

import android.graphics.Color
import com.bryle.realfarm.core.Direction

/**
 * The farmer's pixel-art sprites: one idle pose and one alternate walk-cycle pose per facing
 * direction. [PlayerRenderer] flips the RIGHT-facing frames horizontally to get LEFT, so only
 * three distinct silhouettes (down/up/side) need to be authored here.
 *
 * All bitmaps are built once and cached — sprites never change at runtime, so there's no reason
 * to re-render pixel data every frame.
 */
object PlayerSprites {

    private val palette = mapOf(
        'h' to Color.rgb(0xD9, 0xA4, 0x41), // straw hat
        'b' to Color.rgb(0x8A, 0x5A, 0x35), // hat band
        's' to Color.rgb(0xE8, 0xB9, 0x8C), // skin
        'e' to Color.rgb(0x2B, 0x2B, 0x2B), // eye
        'r' to Color.rgb(0xD9, 0x4A, 0x3A), // shirt
        'p' to Color.rgb(0x3E, 0x2B, 0x1F), // pants
        'o' to Color.rgb(0x1A, 0x1A, 0x1A)  // boots
    )

    private val DOWN_0 = arrayOf(
        "  hhhhh  ",
        " hhhhhhh ",
        "hhhhhhhhh",
        " bbbbbbb ",
        " sssssss ",
        " ssesess ",
        "  sssss  ",
        " rrrrrrr ",
        "rrrrrrrrr",
        "rrr r rrr",
        " pp p pp ",
        " pp p pp ",
        " oo   oo "
    )
    private val DOWN_1 = arrayOf(
        "  hhhhh  ",
        " hhhhhhh ",
        "hhhhhhhhh",
        " bbbbbbb ",
        " sssssss ",
        " ssesess ",
        "  sssss  ",
        " rrrrrrr ",
        "rrrrrrrrr",
        "rrr r rrr",
        " p pp p  ",
        " p pp p  ",
        " oo   oo "
    )
    private val UP_0 = arrayOf(
        "  hhhhh  ",
        " hhhhhhh ",
        "hhhhhhhhh",
        " bbbbbbb ",
        " hhhhhhh ",
        " hhhhhhh ",
        "  hhhhh  ",
        " rrrrrrr ",
        "rrrrrrrrr",
        "rrr r rrr",
        " pp p pp ",
        " pp p pp ",
        " oo   oo "
    )
    private val UP_1 = arrayOf(
        "  hhhhh  ",
        " hhhhhhh ",
        "hhhhhhhhh",
        " bbbbbbb ",
        " hhhhhhh ",
        " hhhhhhh ",
        "  hhhhh  ",
        " rrrrrrr ",
        "rrrrrrrrr",
        "rrr r rrr",
        " p pp p  ",
        " p pp p  ",
        " oo   oo "
    )
    private val SIDE_0 = arrayOf(
        "   hhhh  ",
        "  hhhhhh ",
        " hhhhhhhh",
        "  bbbbbb ",
        "  ssssss ",
        "  sse ss ",
        "   ssss  ",
        "  rrrrr  ",
        " rrrrrrr ",
        " rrr rrr ",
        "  pp pp  ",
        "  pp  pp ",
        "  oo  oo "
    )
    private val SIDE_1 = arrayOf(
        "   hhhh  ",
        "  hhhhhh ",
        " hhhhhhhh",
        "  bbbbbb ",
        "  ssssss ",
        "  sse ss ",
        "   ssss  ",
        "  rrrrr  ",
        " rrrrrrr ",
        " rrr rrr ",
        "  p pp   ",
        " p  pp   ",
        " o  oo   "
    )

    private val down0 by lazy { PixelSprite(PixelArt.fromRows(DOWN_0, palette)) }
    private val down1 by lazy { PixelSprite(PixelArt.fromRows(DOWN_1, palette)) }
    private val up0 by lazy { PixelSprite(PixelArt.fromRows(UP_0, palette)) }
    private val up1 by lazy { PixelSprite(PixelArt.fromRows(UP_1, palette)) }
    private val side0 by lazy { PixelSprite(PixelArt.fromRows(SIDE_0, palette)) }
    private val side1 by lazy { PixelSprite(PixelArt.fromRows(SIDE_1, palette)) }

    /** Returns the sprite to draw plus whether it should be mirrored horizontally (for LEFT). */
    fun spriteFor(facing: Direction, walkFrame: Int): Pair<PixelSprite, Boolean> {
        val frame = walkFrame % 2
        return when (facing) {
            Direction.DOWN -> (if (frame == 0) down0 else down1) to false
            Direction.UP -> (if (frame == 0) up0 else up1) to false
            Direction.RIGHT -> (if (frame == 0) side0 else side1) to false
            Direction.LEFT -> (if (frame == 0) side0 else side1) to true
        }
    }
}
