package com.bryle.realfarm.core

import com.bryle.realfarm.farming.Tool

data class HudSnapshot(
    val day: Int,
    val timeLabel: String,
    val isNight: Boolean,
    val money: Int,
    val hunger: Float,
    val stamina: Float,
    val isSick: Boolean,
    val sickDaysRemaining: Int,
    val waterCharges: Int,
    val maxWaterCharges: Int,
    val selectedTool: Tool,
    val selectedCropName: String,
    val mealsEatenToday: Int,
    val unpaidBillCount: Int,
    val isWaterShutOff: Boolean,
    val isElectricityShutOff: Boolean
)
