package com.bryle.realfarm.economy

import com.bryle.realfarm.farming.CropDatabase
import kotlin.math.roundToInt
import kotlin.random.Random

/**
 * Per-crop sell price expressed as a multiplier of that crop's base price. Selling a unit nudges
 * its multiplier down (you flooded the local market); every new day the multiplier drifts back
 * toward 1.0 and gets a small random shock, so prices are never perfectly static even if you
 * never sell anything — this is what makes "crop price go down" a real, felt mechanic rather
 * than a one-off penalty.
 */
class MarketSystem(private val random: Random = Random.Default) {

    companion object {
        private const val PRICE_DROP_PER_UNIT = 0.035f
        private const val MIN_MULTIPLIER = 0.4f
        private const val MAX_MULTIPLIER = 1.15f
        private const val DAILY_RECOVERY = 0.05f
        private const val DAILY_SHOCK_RANGE = 0.03f
    }

    private val multipliers: MutableMap<String, Float> =
        CropDatabase.ALL.associate { it.id to 1f }.toMutableMap()

    fun currentPrice(cropId: String): Int {
        val def = CropDatabase.get(cropId)
        val mult = multipliers[cropId] ?: 1f
        return (def.basePrice * mult).roundToInt().coerceAtLeast(1)
    }

    fun priceRatio(cropId: String): Float = multipliers[cropId] ?: 1f

    /** Sells [quantity] units of [cropId] one at a time so the price drop compounds realistically. Returns total revenue. */
    fun sell(cropId: String, quantity: Int): Int {
        if (quantity <= 0) return 0
        val def = CropDatabase.get(cropId)
        var mult = multipliers[cropId] ?: 1f
        var total = 0
        repeat(quantity) {
            total += (def.basePrice * mult).roundToInt().coerceAtLeast(1)
            mult = (mult - PRICE_DROP_PER_UNIT).coerceAtLeast(MIN_MULTIPLIER)
        }
        multipliers[cropId] = mult
        return total
    }

    /** Call once per new in-game day: prices recover toward baseline plus a small random shock. */
    fun onNewDay() {
        for (cropId in multipliers.keys.toList()) {
            var mult = multipliers[cropId] ?: 1f
            mult += DAILY_RECOVERY
            mult += (random.nextFloat() * 2f - 1f) * DAILY_SHOCK_RANGE
            multipliers[cropId] = mult.coerceIn(MIN_MULTIPLIER, MAX_MULTIPLIER)
        }
    }

    fun toSaveMap(): Map<String, Float> = multipliers.toMap()

    fun restore(map: Map<String, Float>) {
        map.forEach { (id, mult) -> multipliers[id] = mult }
    }
}
