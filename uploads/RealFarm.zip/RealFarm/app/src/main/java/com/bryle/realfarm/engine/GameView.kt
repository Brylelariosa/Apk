package com.bryle.realfarm.engine

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.bryle.realfarm.core.GameEngine
import com.bryle.realfarm.entity.PlayerRenderer
import com.bryle.realfarm.world.WorldRenderer

class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback {

    companion object {
        private const val TOAST_DURATION_MS = 2200L
    }

    val engine = GameEngine()

    private var gameThread: GameThread? = null
    private val camera = Camera2D()
    private val worldRenderer = WorldRenderer()
    private val playerRenderer = PlayerRenderer()
    private val hudRenderer = HudRenderer()

    private val inputController: InputController = InputController(
        onToolSelected = { tool -> onToolSelected(tool) },
        onSeedCycle = { engine.cycleSeed() },
        onActionButton = { engine.performAction() }
    )

    private var toastMessage: String? = null
    private var toastExpiresAtMs: Long = 0L

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    private fun onToolSelected(tool: com.bryle.realfarm.farming.Tool) {
        engine.selectTool(tool)
        inputController.updateSelectedTool(tool)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        camera.setViewportSize(width.toFloat(), height.toFloat())
        inputController.layout(width, height)
        resume()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        camera.setViewportSize(w.toFloat(), h.toFloat())
        inputController.layout(w, h)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        pause()
    }

    /** Idempotent — safe to call even if already running or the surface isn't ready yet. */
    fun resume() {
        if (gameThread != null) return
        if (!holder.surface.isValid) return
        gameThread = GameThread(holder, ::update, ::draw).also {
            it.running = true
            it.start()
        }
    }

    /** Idempotent — safe to call even if already paused. Blocks briefly until the loop stops. */
    fun pause() {
        val thread = gameThread ?: return
        thread.running = false
        try {
            thread.join()
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        gameThread = null
    }

    private fun update(deltaSeconds: Float) {
        engine.update(deltaSeconds, inputController.joystick.inputX, inputController.joystick.inputY)
        var event = engine.pollEvent()
        while (event != null) {
            toastMessage = event
            toastExpiresAtMs = System.currentTimeMillis() + TOAST_DURATION_MS
            event = engine.pollEvent()
        }
    }

    private fun draw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)

        camera.follow(engine.state.player.position, engine.state.world)
        worldRenderer.draw(canvas, engine.state.world, camera)
        playerRenderer.draw(canvas, engine.state.player, camera, engine.state.health.isSick)

        if (engine.state.clock.isNight()) {
            canvas.drawColor(Color.argb(90, 10, 15, 60))
        }

        if (System.currentTimeMillis() > toastExpiresAtMs) toastMessage = null
        hudRenderer.draw(canvas, engine.hudSnapshot(), width.toFloat(), toastMessage)
        inputController.draw(canvas)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        inputController.onTouchEvent(event)
        return true
    }

    /** Called by the host Activity right after a dialog mutates state (buy/sell/pay/eat) so the
     *  tool-belt highlight stays in sync with engine state. */
    fun syncSelectedTool() {
        inputController.updateSelectedTool(engine.state.player.selectedTool)
    }
}
