package com.bryle.realfarm.engine

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.bryle.realfarm.core.GameEngine
import com.bryle.realfarm.entity.PlayerRenderer
import com.bryle.realfarm.farming.ActionResult
import com.bryle.realfarm.graphics.AnimationClock
import com.bryle.realfarm.graphics.ItemIcons
import com.bryle.realfarm.world.WorldRenderer
import kotlin.math.hypot

class GameView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : SurfaceView(context, attrs), SurfaceHolder.Callback {

    companion object {
        private const val TOAST_DURATION_MS = 2200L
        private const val MOVE_INPUT_THRESHOLD = 0.05f
    }

    val engine = GameEngine()

    private var gameThread: GameThread? = null
    private val camera = Camera2D()
    private val worldRenderer = WorldRenderer()
    private val playerRenderer = PlayerRenderer()
    private val hudRenderer = HudRenderer()
    private val actionEffectRenderer = ActionEffectRenderer()
    private val animClock = AnimationClock()

    private val inputController: InputController = InputController(
        onToolSelected = { tool -> onToolSelected(tool) },
        onSeedCycle = { engine.cycleSeed() },
        onActionButton = { handleActionButton() },
        onQuickSlotTapped = { index -> engine.useQuickSlot(index) }
    )

    private var toastMessage: String? = null
    private var toastExpiresAtMs: Long = 0L
    private var actionEffect: ActionEffect? = null

    init {
        holder.addCallback(this)
        isFocusable = true
    }

    private fun onToolSelected(tool: com.bryle.realfarm.farming.Tool) {
        engine.selectTool(tool)
        inputController.updateSelectedTool(tool)
    }

    /** Performs whatever the currently selected tool does, and — only on success — starts the
     *  brief lunge + particle effect so the player gets clear visual feedback that it worked. */
    private fun handleActionButton() {
        val tool = engine.state.player.selectedTool
        val (targetTileX, targetTileY) = engine.state.player.targetTile()
        val result = engine.performAction()
        if (result is ActionResult.Success) {
            actionEffect = ActionEffect(tool, targetTileX, targetTileY, System.currentTimeMillis())
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        camera.setViewportSize(width.toFloat(), height.toFloat())
        inputController.layout(width, height)
        resume()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        camera.setViewportSize(w.toFloat(), h.toFloat())
        inputController.layout(w, h)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        pause()
    }

    /** Idempotent — safe to call even if already running or the surface isn't ready yet. */
    fun resume() {
        if (gameThread != null) return
        if (!holder.surface.isValid) return
        gameThread = GameThread(holder, ::update, ::renderFrame).also {
            it.running = true
            it.start()
        }
    }

    /** Idempotent — safe to call even if already paused. Blocks briefly until the loop stops. */
    fun pause() {
        val thread = gameThread ?: return
        thread.running = false
        try {
            thread.join()
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        gameThread = null
    }

    private fun update(deltaSeconds: Float) {
        animClock.tick(deltaSeconds)
        engine.update(deltaSeconds, inputController.joystick.inputX, inputController.joystick.inputY)
        inputController.updateQuickSlots(buildQuickSlotDisplays())
        var event = engine.pollEvent()
        while (event != null) {
            toastMessage = event
            toastExpiresAtMs = System.currentTimeMillis() + TOAST_DURATION_MS
            event = engine.pollEvent()
        }
    }

    private fun buildQuickSlotDisplays(): List<QuickSlotDisplay?> =
        engine.state.player.quickSlotItemIds.map { itemId ->
            if (itemId == null) return@map null
            val quantity = engine.state.inventory.quantityOf(itemId)
            if (quantity <= 0) null else QuickSlotDisplay(ItemIcons.iconFor(itemId), quantity)
        }

    private fun renderFrame(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)

        camera.follow(engine.state.player.position, engine.state.world)
        worldRenderer.draw(canvas, engine.state.world, camera, animClock)

        val nowMs = System.currentTimeMillis()
        val actionProgress = actionEffect.progress(nowMs)
        val isMoving = hypot(inputController.joystick.inputX, inputController.joystick.inputY) > MOVE_INPUT_THRESHOLD
        playerRenderer.draw(canvas, engine.state.player, camera, engine.state.health.isSick, isMoving, animClock, actionProgress)
        actionEffectRenderer.draw(canvas, actionEffect, camera, nowMs)

        if (engine.state.clock.isNight()) {
            canvas.drawColor(Color.argb(90, 10, 15, 60))
        }

        if (System.currentTimeMillis() > toastExpiresAtMs) toastMessage = null
        hudRenderer.draw(canvas, engine.hudSnapshot(), width.toFloat(), toastMessage)
        inputController.draw(canvas)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        inputController.onTouchEvent(event)
        return true
    }

    /** Called by the host Activity right after a dialog mutates state (buy/sell/pay/eat/assign)
     *  so the tool-belt highlight and quick-slot icons stay in sync with engine state. */
    fun syncSelectedTool() {
        inputController.updateSelectedTool(engine.state.player.selectedTool)
        inputController.updateQuickSlots(buildQuickSlotDisplays())
    }
}
