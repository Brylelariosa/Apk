package com.quickshare

import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.DecimalFormat
import kotlin.math.log10
import kotlin.math.pow

data class SelectedFile(val uri: Uri, val name: String, val size: Long)

class SelectedFilesAdapter(
    private val files: MutableList<SelectedFile>,
    private val onRemove: (Int) -> Unit
) : RecyclerView.Adapter<SelectedFilesAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvFileName)
        val tvSize: TextView = view.findViewById(R.id.tvFileSize)
        val btnRemove: View = view.findViewById(R.id.btnRemoveFile)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_selected_file, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val file = files[position]
        holder.tvName.text = file.name
        holder.tvSize.text = formatSize(file.size)
        holder.btnRemove.setOnClickListener { onRemove(holder.adapterPosition) }
    }

    override fun getItemCount() = files.size

    private fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB")
        val i = (log10(bytes.toDouble()) / log10(1024.0)).toInt().coerceAtMost(3)
        return "${DecimalFormat("#,##0.#").format(bytes / 1024.0.pow(i.toDouble()))} ${units[i]}"
    }
}
