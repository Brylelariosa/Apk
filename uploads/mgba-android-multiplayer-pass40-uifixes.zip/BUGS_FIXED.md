# BUGS_FIXED — Fortieth pass

**Editor alignment grid drawing rectangular cells instead of square
ones, reported directly ("grid not really box") and visible in the
attached landscape edit-mode screenshot.** Root cause: `drawGrid()` and
`snapScaleToGrid()` each divided the screen's width and height by the
same N independently — `w/N` by `h/N` — which is a square only on a
square screen, and no phone has one. Fixed at the root with a new
`gridCellPx()`, the single shared cell size (based on whichever of
width/height is shorter), so both drawing and snapping now always
produce true squares in either orientation. Also extended the size
options from a 32 cap up to 64 (asked for directly — "add more like 60
not just 30"), and fixed the preset labels, which had read "N×N" even
though the cells were never actually square. See CHANGELOG.md item 1.

**The Control Size and Control Opacity "-"/"+" chips being very hard to
tap, reported directly, and visible in both attached per-item-popup
screenshots (D-Pad, A Button).** Root cause: the shared `editChip()`
button builder passed its padding as raw pixel numbers instead of
through this file's own `dp()` density conversion, used everywhere else
a size is set — on a real phone that's a few actual pixels, not the
handful of dp it reads as in the source. Mostly hidden on chips with real
words in them (the text itself provides most of the tappable width
either way), but it was nearly the *entire* size of a bare `"-"`/`"+"`
glyph. Fixed the padding to go through `dp()`, and gave just those four
stepper chips a guaranteed 48dp minimum touch target (Android's own
guideline) on top of that. See CHANGELOG.md item 2.

**A semi-transparent dark band drawn behind the on-screen controls every
frame, reported as unwanted ("black transparent... i don't really like
it") and visible in the attached portrait edit-mode screenshot.**
Removed outright — the fill (`colorControlsBg`, a dark navy at ~80%
opacity) had no purpose beyond decoration, and the canvas is already
cleared to solid black immediately before it would have been drawn, so
removing it just leaves that area plain black, seamless with the rest of
the screen. See CHANGELOG.md item 3.

**The ROM browser flashing landscape before settling into its locked
portrait orientation, reported directly.** The screen is manifest-locked
to portrait, but opening it from gameplay (normally landscape) is a real
display reconfiguration, and the default slide/fade transition between
activities gave that reconfiguration a couple of animated frames to
show through in. Both the launch (`MainActivity`) and every exit path
out of the ROM browser now suppress that transition entirely, so the
switch is an instant cut instead. Doesn't touch how the orientation lock
itself works — see CHANGELOG.md item 4 for why that specifically was
avoided.

**The ROM browser's status bar staying hidden, leaving a large dead
black strip at the top of the screen where the clock/notifications/
signal icons would normally show, reported directly and visible in the
attached screenshot.** The whole app shares one fullscreen theme, which
is correct for actual gameplay but was also silently applying to this
plain file-picking screen. It now gets its own theme that turns
fullscreen back off just for itself; gameplay is completely unaffected.
See CHANGELOG.md item 5.

**The ROM browser showing just one file while a folder with several
`.zip` archives was still being checked in the background, with only a
plain, easy-to-miss text row to say so — reported directly against a
real folder with a dozen archives shown in the attached screenshot.**
Two fixes together: the archive scan itself now runs on a small pool of
threads instead of one file at a time (already flagged as a known cost
of the simpler sequential version — see KNOWN_LIMITATIONS.md, Thirtieth
pass — and this is exactly that cost showing up), and the "still
working" state is now a real spinner instead of a line of gray text that
could look like the list was just... done. See CHANGELOG.md item 6.

---

# BUGS_FIXED — Thirty-ninth pass

**"Game Screen Size" visibly resizing a big black area instead of just
the image, reported with edit-mode screenshots showing exactly that.**
Root cause traced to `updateGameMatrix()`: the editable `"gamescreen"`
box (added Thirty-seventh pass to make the screen resizable at all) was
built as full screen width by a fraction of the height — an area with no
relationship to the GBA's actual 3:2 image aspect ratio. The real bitmap
was then aspect-fit *inside* that oversized box, so the box the editor
actually let you drag/resize was mostly dead pillarboxed space; the
small visible image just sat somewhere inside it. Fixed at the root: the
box's default geometry is now itself built from the live framebuffer's
own aspect ratio (clamped to available width on a screen too narrow for
it), so the editable box *is* the image with nothing extra baked in —
`scale` (one uniform float, shared with every button's own resize) can
then only ever resize the actual picture. A new `clampRectToScreen()`
additionally caps the box to the screen's own bounds every frame, so no
resize — up to the existing 8x cap — can push it past the display's own
edges either. Stretch to Fit, which shared the same oversized box, is
now its own fixed computation (full available width, the same reserved
height gameScreenFraction always used) completely independent of
`customLayout`, which is also what stops it from growing the reserved
height or affecting anything else on screen when toggled. See
CHANGELOG.md items 1–2 for the full before/after and the one save-data
side effect (a previously-saved `"gamescreen"` `scale` value now applies
to the corrected base box, not the old inflated one — Reset fixes it in
one tap if it looks off).

**A leftover top-left fast-forward speed indicator, separate from the
on-button text Thirty-seventh pass already removed for the same
complaint.** `drawFfOverlay()` drew `"⏩ Nx"` at a fixed canvas position
independent of any button — Thirty-seventh pass's fix only touched the
»-button's own face text, so this standalone HUD element kept running
unnoticed until this pass's screenshots caught it. Deleted the function,
its paint, and the call site. See CHANGELOG.md item 3.

**Found and fixed a bug in this project's own verification tooling
while checking the two fixes above.** The comment-aware balance scanner
written to check brace/paren/bracket counts (in the spirit of
Thirty-eighth pass's comment-aware fix, after the plain-count method
proved blind to a swallowed-file bug that pass) had its own bug: Kotlin
string-template expressions (`"...${expr}..."`) weren't correctly
switching the scanner back into "real code" parsing for the content
between `${` and its matching `}`, so that `}` got miscounted as string
text instead of a real closing brace whenever a template appeared,
corrupting the running depth count for the rest of the file. Caught by
running the (buggy) scanner against the *original, unmodified* input zip
first, as a control — it reported the identical class of false positive
there too, which a genuinely broken brace count in already-building code
would not do, so the scanner itself was the suspect, not the source.
Fixed and reconfirmed clean (0 remaining depth, empty string stack) on
both the original file and this pass's edited one. One-off diagnostic
only, not added as a standing part of this project, matching
Thirty-eighth pass's own precedent.

Not confirmed by an actual rebuild this pass — no Android toolchain in
this sandbox, as every pass.

---



**A real, more serious compile error this time, again caught by an
attached CI build log (run 1575) — a duplicated comment-opener that
swallowed roughly a fifth of the file.** Editing `applyLayoutSettings()`'s
doc comment last pass, the `old_str` matched starting from
`* Rebuild control layout...` — one line *after* the existing `/**` —
but `new_str` added a fresh `/**` of its own on top, never noticing the
original was sitting right there, untouched, immediately above. Kotlin
block comments nest (`/* /* */ still open */` is valid, unlike C/Java),
so the single `*/` that was already there closed only the inner
nesting level, leaving the outer one open for the rest of the file —
every function defined after that point (`applyLayoutSettings` itself,
`stopLink`, `drawLinkStatus`, `drawFpsOverlay`, `showLinkRemoteDialog`,
`showLinkLocalDialog`, `showSaveStateSlotDialog`, and whatever else
follows) effectively stopped existing from the parser's point of view,
and the class's own closing brace went missing with it — hence both
`e: ... Missing '}'` and `e: ... Unclosed comment`, plus a cascade of
`Unresolved reference` errors at every earlier call site for a function
whose definition had been swallowed.

This project's own verification method — comparing raw `{`/`}` counts
across the whole file — could not have caught this and didn't: adding a
second `/**` doesn't add or remove any `{`/`}` characters, so that count
stayed perfectly balanced (721/721) the entire time, "correctly"
according to a check that has no concept of comments at all. Fixed
properly this pass: wrote an actual comment-aware scanner (tracks
`/* */` nesting depth, skips `//` lines and string contents, run once as
a one-off diagnostic, not added as a standing part of this project) to
find exactly where the phantom comment started, rather than guessing.
Confirmed 0 final nesting depth after the fix, and confirmed all seven
previously-"missing" functions have exactly one real definition each.
See CHANGELOG.md.

Not confirmed by an actual rebuild this pass — no Android toolchain in
this sandbox, as every pass.

# BUGS_FIXED — Thirty-seventh pass

**Max frame skips flickering and flashing white screen, reported
immediately after the feature that added it (two passes ago).** Root
cause: a skipped frame's buffer-publish step ran unconditionally, same
as a real frame's — `readyIdx` claimed whatever buffer `writeIdx`
pointed at even though `nativeRunFrame(null)` never wrote a single pixel
into it that iteration. Early on, or after several skips in a row, that
buffer can be one none of the 3 have ever actually been rendered into
yet — publishing it hands the renderer genuinely uninitialized bitmap
contents to draw, which reads exactly as "a flash of garbage," commonly
white. Fast-forward's own sub-frame skipping never had this problem —
every batch's *last* sub-frame still always writes real pixels into the
one buffer used for that whole batch before the one publish at the end;
only Max frame skips' new normal-speed path shared the unconditional
publish without sharing that guarantee. Fixed by moving the publish
inside the "a real render actually happened" branch: a skipped frame now
claims no buffer and changes nothing about `readyIdx`/`displayIdx` at
all, so the renderer just keeps showing whatever it was already
showing — the correct, safe meaning of "skip this frame's visual
update." See CHANGELOG.md.

Not confirmed by an actual rebuild or device this pass — no Android
toolchain in this sandbox, as every pass. Traced by hand against the
triple-buffer scheme's own stated invariant (`writeIdx` always picks
whichever of the 3 indices is neither `readyIdx` nor `displayIdx`) rather
than assumed; whole-file brace/paren balance checked after the edit.

# BUGS_FIXED — Thirty-sixth pass

**A real compile error, caught by the CI build log the user attached
(run 1565) — `assembleRelease` failed outright, nothing installable came
out of Thirty-fifth pass.** `linearFilterEnabled` was referenced in four
places (the pref-load line, `updateLinearFilterPaint()`, and the new
Video settings checkbox's read/write) but never actually declared as a
field — `stretchToFit` and `maxFrameSkips` right next to it in that same
pass's write-up *are* real, and the assumption that this one matched them
went unchecked against an actual declaration line, only against uses of
the name. `e: ... Unresolved reference: linearFilterEnabled` ×4, exactly
where the compiler says it is. Fixed by adding the missing
`@Volatile private var linearFilterEnabled = false` alongside
`stretchToFit`/`maxFrameSkips`; no other change needed since every use
site already assumed the right type and default. See CHANGELOG.md.

Not confirmed by an actual rebuild this pass — no Android toolchain in
this sandbox, as every pass; re-checked by re-deriving what the compiler
would see (the same four line numbers it originally flagged, read fresh
after the fix), not by re-running anything.

# BUGS_FIXED — Twenty-ninth pass

**Two real bugs fixed, neither one the multiplayer issue.** A code audit
(then a deeper one) found: (1) `g_link_obj`/`g_link_xchg_mid`/
`g_link_is_host` in `mgba_jni.c` were written outside `g_core_mutex` in
`nativeLinkStart()`/`nativeLinkStop()` despite being read under it
everywhere else — a genuine data race, low practical severity given
naturally-atomic pointer/bool writes on ARM, present since FIX 7/8 and not
introduced by any recent pass. (2) `MainActivity.kt`'s save-state
slot-picker dialog had the exact same unsynchronized-Thread race that an
earlier pass already fixed once for Quick Save/Quick Load, just never
extended to this second call site. Both fixed this pass — see
CHANGELOG.md for the details.

Not confirmed on a real device this pass — no Android toolchain here, as
every pass before it.

# BUGS_FIXED — Twenty-seventh pass

**Not a fix — a diagnostic aimed at a newly-reframed theory.** A Dragon
Ball Z: Supersonic Warriors capture confirmed the same stall shape as the
Twenty-sixth pass's test (FIX 21 didn't change it, ruling out pacing), and
the user confirmed directly that the communication error appears *during*
the quiet stretch, before this file's own retry gives up. GBATEK documents
that a child signals "not ready" by leaving Multi-Player mode entirely —
which this driver, registered for `SIO_MULTI` only, would never see or log
at all. This pass adds a direct read of the core's own `sio.rcnt`/
`sio.siocnt` in `nativeRunFrame()` (FIX 22 in `mgba_jni.c`) to check this
cheaply, without guessing a new driver-callback signature blind. See
CHANGELOG.md.

Not confirmed on a real device this pass — no Android toolchain here, as
every pass before it.

# BUGS_FIXED — Twenty-sixth pass

**Multiplayer still doesn't connect, but FIX 20's pacing experiment
produced real movement for the first time.** A fresh device capture shows
the child's own link code writing genuinely varying data instead of being
stuck on two placeholder values, and the ~200ms restart loop is gone —
replaced by a new stall (~15-17s per attempt) that's now visible for the
first time. Separately, Dragon Ball Z: Supersonic Warriors — a real-time
fighting game — got an instant "communication error" and visible lag,
consistent with FIX 20's pacing being an unconditional whole-session cost.
This pass bounds pacing to a short 3-second window per negotiation attempt
(FIX 21 in `mgba_jni.c`) instead of removing or keeping it as-is — not a
fix, a refinement of the experiment. See CHANGELOG.md.

Not confirmed on a real device this pass — no Android toolchain here, as
every pass before it.

# BUGS_FIXED — Twenty-fifth pass

**Multiplayer still doesn't connect — not fixed this pass either.** A fresh
matched host+child capture shows the exact same unresolved symptom as FIX
18/19: the child's own SIOMLT_SEND is still only ever `0x0000`/`0xFEFE`, and
its own link setup restarts every ~200ms, even though the host's own data is
still demonstrably arriving at the child correctly. New this pass: the user
confirmed the same ROM's multiplayer works outside this app, ruling out "the
ROM's own code is just unusual" for the first time. That points at this
app's own link timing/architecture rather than anything ROM-specific, but
this pass adds a toggleable experiment (FIX 20 in `mgba_jni.c` — see
CHANGELOG.md), not a confirmed fix. Needs a real device test to know whether
it helps.

Not confirmed on a real device this pass — no Android toolchain here, as
every pass before it.

# BUGS_FIXED — Twenty-fourth pass

**Menu Save State/Load State feeling slow (both the dialog appearing and
picking a slot).** Two separate causes, both perf, not correctness bugs:
(1) `showSaveStateSlotDialog()` re-decoded every slot's PNG thumbnail
from disk on every single open, even when nothing had changed — fixed
with an in-memory cache (`slotInfoCache`) keyed by ROM name + slot,
invalidated only when a slot's `exists`/`lastModified()` actually differ
from what's cached. (2) `backupIfExists()` — run right before every save,
by Quick Save and the menu alike — copied an existing slot's full bytes
to its `.bak` sibling right before `nativeSaveState()` overwrote that
same file anyway, up to 2x a save-state's disk I/O per save, all before
the toast could fire. Fixed with `SaveEntry.moveInto()`: a plain
`File.renameTo()` on the common (no Storage folder) path instead of a
byte-for-byte copy, falling back to the old copy behavior otherwise.

Not confirmed on a real device this pass — no Android toolchain here —
but both are straightforward reductions in redundant I/O with a
correctness fallback in each case (cache miss still re-decodes; rename
failure still falls back to copy).

---

# BUGS_FIXED — Twenty-third pass

**Quick Save/Quick Load racing each other when used fast.** Reported from
fast save/load testing: saves landing on an unexpected frame, and taps
that appeared not to save at all. Root cause: `quickSaveState()` and
`quickLoadState()` each spawned an unsynchronized `Thread` per tap, with
no lock or debounce between them. `g_core_mutex` (native side) serializes
the actual file write/read against the running game thread, but not the
*order* in which two Kotlin threads reach it — a fast second tap could
win that race and run before the first tap's operation finished,
producing an out-of-order save/load. Fixed with a shared `AtomicBoolean`
busy-guard: a tap while one is already in flight is now ignored (with its
own toast) instead of racing. Separately confirmed `nativeSaveState()`
uses `O_TRUNC`, so a slot is always fully replaced on save — that part
was never the problem.

Not confirmed on a real device this pass — no Android toolchain here —
but the race itself is unambiguous from the code (two independent
Threads, no synchronization, touching the same file and native calls).

---

# BUGS_FIXED — Twenty-second pass

**Floating "Load ROM" button rendering on top of the ROM browser.**
Reported with a screenshot: the purple "▶ Load ROM" button was visible
hovering over the "Load game" file browser's list, even though it was
added to the layout underneath that browser. Root cause: a stock Material
`Button` carries a small default elevation, and Android draws
higher-elevation children above lower-elevation ones regardless of add
order — so the button drew on top of the opaque overlay meant to cover
it. Fixed by removing the button entirely; `changeRom()` already
auto-opens the ROM browser on launch and on Close, and a tap on the idle
surface now covers the one case the button still served (folder picker
cancelled, or a ROM load failed, with nothing else on screen).

**Save State feeling slow ("doesn't save instantly").** The slot-save
confirmation toast waited on `captureStateThumbnail()` — up to a 500ms
`PixelCopy` wait plus bitmap scale/PNG encode — before showing, even
though the actual state write had already finished and was safe on disk.
Fixed by firing the confirmation immediately after the real save/load
call returns, with thumbnail capture still happening afterward in the
background rather than gating the toast. Quicksave (the one-tap 💾
button) was never affected — it doesn't capture a thumbnail.

Neither fix confirmed on a real device this pass — no Android toolchain
here — but both are backed by specific mechanisms in the code (Android's
own elevation/Z-order rule; the `PixelCopy` call's own literal 500ms
timeout), not guesses.

---

# BUGS_FIXED — Twenty-first pass

**Save/load broken by the Storage folder feature (Twentieth pass), reported
from an actual device.** The Twentieth pass's `/proc/self/fd/<N>` bridge —
used so native `VFileOpen()` could operate on a SAF document as if it were
a plain local path — was flagged in that pass's own KNOWN_LIMITATIONS.md as
unconfirmed on real hardware. This pass confirms it doesn't hold up: a real
device test showed exactly the reported symptom, saves and loads silently
not working once a Storage folder was chosen. Fixed by removing native
code's dependency on SAF entirely — it always operates on a plain internal-
storage file now, with Kotlin copying bytes to/from the chosen folder via
`ContentResolver` streams instead of a re-opened file descriptor. Full
detail in CHANGELOG.md; still not verified against a real device in this
project's own testing (no Android toolchain here either), but the design no
longer depends on the specific provider behavior that broke.

---

# BUGS_FIXED — Nineteenth pass

No bug fixed this pass — Eighteenth pass's SIOCNT-mirroring change was
re-tested against a real matched capture and showed no observed change
(child's `childData` still only ever `0x0000`/`0xFEFE`). Left in place;
not the fix, but still correct on its own terms.

One real fix, unrelated to the link protocol itself: two phones' log
captures in this test covered different real-world spans, which had no
quick explanation before now. Root cause: the host's code logs ~3 lines
per SIO exchange against the child's ~1, so the same 40,000-character
export cap holds less real time on the host side — not a phone problem.
`copyLinkDebugLog()` now appends the exact copy timestamp to the exported
text so this is visible at a glance next time, instead of needing to be
worked out after the fact.

---

# BUGS_FIXED — Eighteenth pass

Real bug fix, not a diagnostic pass — the first one aimed at a gap found
through a real matched two-phone capture instead of a code re-read alone.

- **Fixed: the child device's own SIOCNT never reflected transfer
  completion.** The new matched capture (see CHANGELOG.md/
  KNOWN_LIMITATIONS.md) confirmed both directions of the network exchange
  are correct — real evidence, for the first time, from both phones during
  the same attempt. That narrowed things to the child ROM's own code, and
  reading `nativeLinkChildExchange()` end to end turned up a gap the
  function's own comment already admitted: it wrote the data registers and
  raised the IRQ, but never touched SIOCNT bit 7 (Busy), which GBATEK
  documents as a hardware-mirrored parent-clock reflection on every
  connected unit — a normal thing for a child ROM to poll instead of, or
  alongside, the IRQ. `nativeLinkChildExchange()` now refreshes SIOCNT
  bits 2/3/4-5/7 on the child's device after every exchange, preserving
  every other bit exactly as the ROM last set it.

Not confirmed on a real device — same caveat as every pass before it. See
KNOWN_LIMITATIONS.md for what would actually settle it.

---

# BUGS_FIXED — Seventeenth pass

Not a bug-fix pass, same as Sixteenth — nothing here changes multiplayer
behavior. Included for completeness: one real infrastructure gap closed
(logging that no longer depends on OS logcat access, which W's own device
split this pass confirmed is a real, current blocker, not a hypothetical
one), plus a deeper read of Sixteenth pass's own evidence that ruled out
one leading candidate explanation without confirming any other.

- **Fixed: the debug-log tool depended entirely on OS logcat access,
  which doesn't work on every phone.** Sixteenth pass flagged this
  (screenshotted empty capture on one of W's two phones) but explicitly
  didn't attempt a fix, since one working phone was enough to make
  progress at the time. This pass, W hit the same wall again while trying
  to get a synchronized two-phone capture — which needs *both* phones'
  logs, so "one working phone" isn't enough for that specific, repeatedly-
  requested next step. `copyLinkDebugLog()` now reads a private file this
  app owns outright instead of shelling out to `logcat`; see CHANGELOG.md
  items 1-3 and FILE_CHANGES.md for the mechanics.
- **Checked, not fixed: FIX 9's bit2/bit3 SIOCNT reflection, against the
  specific theory that the child ROM never sees bit3 (all-ready) and that
  being why its own negotiation never progresses.** Re-read this pass
  against the child-side evidence in Sixteenth pass's new logging (see
  KNOWN_LIMITATIONS.md). The code already applies the bit3/bit2 OR
  unconditionally on every SIOCNT write while `g_link_active` is true,
  regardless of host/child role — this was the single most likely
  candidate explanation going in, and reading the code turned up no bug in
  it. Listed here rather than silently dropped, since ruling out a
  plausible cause is itself useful information for whoever continues this.

Neither of these touches the actual reported bug (multiplayer still
doesn't work). See CHANGELOG.md and KNOWN_LIMITATIONS.md for the new
evidence from this pass's logs (strong, still-unconfirmed indication the
child ROM's own negotiation never advances past writing placeholder
values, independent of the network layer, which looks solid) and an
updated theory (timing/synchronization, grounded in how mGBA's own real
multiplayer implementation handles this — not confirmed against this
codebase specifically) for what a real device test should check next.

---

# BUGS_FIXED — Sixteenth pass

Not a bug-fix pass in the usual sense — nothing here changes multiplayer
behavior. Included for completeness: two diagnostic gaps closed after
reading W's first genuinely useful evidence (three real logcat captures,
following Fifteenth pass's logging fix actually working).

- **Fixed: the SIO exchange's own result was never logged, only the write
  that triggers it.** `wifi_host.text` this pass showed 1124 Start-bit
  writes in 1.67 seconds on the host — too fast to be timing out on most
  of them (that would take 30+ seconds at `WIFI_XCHG_MS=30` each) — which
  strongly suggested the network side is basically working, but nothing
  confirmed it or showed what was actually coming back. `link_exchange()`'s
  return value and timeout flag are now logged for every host exchange.
- **Fixed: the entire child-side receive path had no logging.**
  `nativeLinkChildExchange()` — the only function that updates a child
  device's own link registers — logged nothing, in either its early-exit
  or success path, across all sixteen passes so far. `wifi_join.text` and
  `bluetoth__1_.text` both show the child ROM restarting its own link setup
  roughly every 200ms without ever stabilizing, but whether that's because
  this function never ran, ran with unhelpful data, or ran fine and the ROM
  didn't react to it, was unanswerable without this. Now logs every call.

Neither of these touches the actual reported bug. See CHANGELOG.md and
KNOWN_LIMITATIONS.md for what the new evidence actually suggests (a
possible mutual-reset livelock between the two ROMs' own negotiation state
machines — not confirmed) and what the next capture needs to look like to
confirm or rule it out.

---

# BUGS_FIXED — Fifteenth pass

This pass fixed one clearly demonstrated bug (item 1 — the evidence is the
two logcat files W attached), one diagnostic gap that made every disconnect
report hard to read (item 2), and applied one hardening whose actual effect
is genuinely unconfirmed (item 3, included here anyway in the interest of
not burying it — see its own honesty note). **None of the three symptoms
reported this pass — ROM detection on either transport, Wi-Fi disconnect
propagation, Bluetooth lag — are confirmed fixed.** See
KNOWN_LIMITATIONS.md.

- **Fixed: the multiplayer debug-log capture tool was capturing nothing
  useful.** `jni_log()` in `mgba_jni.c` forwarded every mGBA core log line,
  at every level, to logcat under the same tag `copyLinkDebugLog()` greps
  — including `"Starting DMA ..."` and `"Read from write-only I/O
  register: ..."` chatter that fires dozens of times per frame for any
  ROM, unrelated to link. Both logs W attached this pass are direct proof:
  2000 lines each, tag-filtered correctly, but covering barely 200ms of
  real time — pure boot noise, nothing from anywhere near an actual
  multiplayer attempt. Fixed by dropping `mLOG_DEBUG`/`mLOG_STUB`/
  `mLOG_GAME_ERROR` at the source (mirrors mGBA's own libretro frontend
  under `NDEBUG`, which this project also builds with), plus a
  belt-and-suspenders check on the two exact message prefixes observed.
  Also bumped the capture window from 2000 to 8000 lines as extra
  headroom. This doesn't fix any of the three reported symptoms by
  itself — it fixes why nothing gathered about them so far has been
  readable.
- **Fixed: disconnect/peer-lost events were logged with no distinguishing
  detail.** `disconnect()`'s BYE send had a silent `catch (_: Exception)
  {}` — no record of whether it sent, was skipped, or failed. Every one of
  `handlePeerLost()`'s 8 call sites logged the exact same generic line
  regardless of which of 6 listener locations fired or why. A captured log
  could not have told "peer's BYE never arrived" apart from "arrived but
  something else consumed it" apart from "neither side ever sent one, the
  8s watchdog just gave up" — three different bugs, all invisible from the
  old logging. Every disconnect/peer-lost path now logs specifically what
  happened. Purely additive; no protocol or timing logic changed.
- **Hardened, not confirmed as a fix: native SIO exchange trigger was not
  gated to the host role.** `link_sio_write_register()`'s exchange branch
  ran on *any* device's own Start-bit SIOCNT write — FIX 9's original
  comment already claimed a child device's write "correctly never" reaches
  it, but nothing enforced that; it depended entirely on the assumption
  that a child ROM's own code never performs that write. Now explicitly
  gated on `g_link_is_host`. If either test ROM's link code doesn't
  actually respect that split (plausible if parent/child share one code
  path), this would have let a child device fire a second, spurious
  exchange alongside the correct network-triggered one, potentially
  stealing the host's real reply out from under it — a mechanism that
  would explain identical ROM-detection failure on both transports plus
  worse Bluetooth lag specifically (longer timeout there). Genuinely don't
  know if this was happening. Cheap and safe regardless: host behavior is
  completely unchanged.

---

# BUGS_FIXED — Earlier passes (summary)

Full entries trimmed for length. Link/multiplayer-relevant ones are noted;
the rest are unrelated app bugs, fixed and not revisited since.

- **Fourteenth** — Compile error: a `showLinkDebugLogDialog()` parameter
  named `text` shadowed the `TextView.text` property it was meant to set.
  Renamed the parameter; no link logic touched.
- **Twelfth** — Added the (logcat-based, later superseded) "Copy link log"
  diagnostic. Not a fix on its own.
- **Eleventh** — Quick game menu rows were all silently unresponsive
  (`isClickable`/`isFocusable` stealing the tap from the `ListView`'s own
  dispatch) — a regression from the Tenth pass's restyle.
- **Tenth** — Immersive mode not sticking across dialogs; black bar in the
  camera-cutout area on landscape.
- **Ninth** — Wi-Fi host's liveness watchdog could fire on a healthy
  connection, because the host (unlike the child) had no code path that
  kept reading the socket while waiting for the ROM to reach its own link
  screen. Fixed with a dedicated host-side keepalive drain.
- **Eighth** — No fix; added trace logging after a real fix (Seventh)
  produced zero observed change, to stop guessing blind.
- **Seventh** — SIO IRQ was never raised at all, so any interrupt-driven
  ROM (the standard IntrWait pattern) never woke up on a completed
  transfer, even though the byte exchange itself (Sixth) was correct.
- **Sixth** — Root cause of the original "Connected but ROM never
  reacts" report: a child device never answered the host's requests at
  all (Start/Busy is hardware read-only for slaves per GBATEK, so the
  child's own exchange code path never fired) — fixed with the passive
  `nativeLinkChildExchange()` responder. Also: SIOCNT parent/child + all-
  ready bits were never set; ID/Error bits never set after a transfer;
  peer disconnects were never detected; Bluetooth never ran the keepalive
  loop at all.
- **Fifth** — First multiplayer-focused pass. Missing `@Volatile` on six
  connection-state fields; untracked discovery socket made disconnect a
  no-op for it; non-functional stale-packet sequence check; unblocked
  concurrent connection attempts could clobber each other; uncancellable
  in-progress Bluetooth connect; ROM-swap could leave link UI stuck on
  "Connected" after the native driver was already gone; a rare
  post-teardown resource leak in the ROM-load callback; two unused
  permissions removed.
