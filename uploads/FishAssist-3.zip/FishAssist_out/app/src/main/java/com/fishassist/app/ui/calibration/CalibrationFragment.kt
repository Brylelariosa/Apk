package com.fishassist.app.ui.calibration

import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.fishassist.app.databinding.FragmentCalibrationBinding
import com.fishassist.app.util.collectFlow
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class CalibrationFragment : Fragment() {

    private val vm: CalibrationViewModel by viewModels()
    private var _b: FragmentCalibrationBinding? = null
    private val b get() = _b!!

    // Image picker — launches gallery/files app, result is a content URI
    private val pickImage = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            vm.loadScreenshot(uri, requireContext().contentResolver)
        }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentCalibrationBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        collectFlow(vm.step) { step ->
            b.tvStepTitle.text = "Step: ${step.name.replace('_', ' ')}"
            b.btnFinish.visibility = if (step == CalibrationStep.DONE || step == CalibrationStep.SET_BOUNDS)
                View.VISIBLE else View.GONE
            b.btnNext.visibility = if (step == CalibrationStep.DONE)
                View.GONE else View.VISIBLE
        }

        collectFlow(vm.message) { b.tvInstruction.text = it }

        collectFlow(vm.previewFrame) { frame ->
            if (frame != null) b.ivPreview.setImageBitmap(frame)
        }

        // Update source label when source changes
        collectFlow(vm.source) { source ->
            b.tvSourceLabel.text = when (source) {
                CalibrationSource.LIVE       -> "Source: Live"
                CalibrationSource.SCREENSHOT -> "Source: Screenshot"
            }
        }

        // Forward taps on the preview image to the ViewModel
        b.ivPreview.setOnTouchListener { v, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                // Scale tap coords from view space → bitmap space
                val scaleX = (vm.previewFrame.value?.width  ?: v.width).toFloat()  / v.width
                val scaleY = (vm.previewFrame.value?.height ?: v.height).toFloat() / v.height
                vm.onTap((event.x * scaleX).toInt(), (event.y * scaleY).toInt())
            }
            true
        }

        // Pick a screenshot from gallery / files
        b.btnPickScreenshot.setOnClickListener {
            pickImage.launch("image/*")
        }

        b.btnNext.setOnClickListener   { vm.advance() }
        b.btnFinish.setOnClickListener { vm.advance() }
        b.btnReset.setOnClickListener  { vm.reset() }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
