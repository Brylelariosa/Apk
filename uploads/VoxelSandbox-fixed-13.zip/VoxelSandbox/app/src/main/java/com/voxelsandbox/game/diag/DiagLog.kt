package com.voxelsandbox.game.diag

import android.app.ActivityManager
import android.content.Context
import android.opengl.GLES30
import android.os.Build
import android.os.Debug
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.ArrayList
import java.util.Arrays
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max
import kotlin.math.min

/**
 * Runtime diagnostic logger: a flight recorder for gameplay.
 *
 * Three modes. OFF does nothing at all: every hook below starts with one volatile read and
 * returns, no thread runs and no memory is held. LIGHTWEIGHT keeps per-second frame statistics,
 * memory samples, and only the *slow* chunk / mesh / upload / far-tile jobs. DETAILED also keeps
 * every stutter, finer thresholds, per-second coverage and level-of-detail statistics, and
 * checks for GL errors more often.
 *
 * How it stays out of the way:
 *  - Events go into a preallocated ring buffer (no allocation per event, one short lock), which
 *    is also the bounded in-memory history that lets an incident show what led up to it.
 *  - A single low-priority background thread does everything slow: it formats events to JSONL
 *    and appends them to the session file in batches, samples memory, writes incident files and
 *    builds reports. **No file I/O ever happens on the render thread** (or any game thread).
 *  - When the writer falls behind, or the logger's own cost on the render thread grows, the
 *    low-priority events are shed (and counted) so the logger never becomes the source of lag.
 *    Everything dropped, shed, truncated or cut short is reported in the exported report.
 *
 * Time. Every event carries the monotonic clock ([System.nanoTime]); the wall-clock time shown is
 * derived from the session's start (wall time + monotonic offset), in the device's local time zone
 * with millisecond precision, so a clock change during play cannot reorder or skew the log.
 *
 * Incidents. A lag spike, freeze, GL error, memory pressure or stretch of missing terrain opens
 * an incident: the last seconds of history (before) are kept, and the next few seconds (after)
 * are collected; both are written to their own file and included in the exported report. A manual
 * capture does the same on demand.
 *
 * Crashes. Events reach the session file within about two seconds (one second in DETAILED) and
 * the crash handler flushes what is left, so the file survives a crash, and the next launch notes
 * that the previous session ended abnormally.
 */
object DiagLog {
    const val MODE_OFF = 0
    const val MODE_LIGHT = 1
    const val MODE_DETAILED = 2

    fun modeName(mode: Int): String = when (mode) {
        MODE_LIGHT -> "Lightweight"
        MODE_DETAILED -> "Detailed"
        else -> "Off"
    }

    // ---- event kinds ----------------------------------------------------------------------
    private const val T_SESSION = 1
    private const val T_FRAMES = 2
    private const val T_STUTTER = 3
    private const val T_MEM = 4
    private const val T_WORK = 5
    private const val T_WORKMS = 6
    private const val T_GEN = 7
    private const val T_MESH = 8
    private const val T_UPLOAD = 9
    private const val T_FARTILE = 10
    private const val T_GLERR = 11
    private const val T_ERROR = 12
    private const val T_MISSING = 13
    private const val T_INCIDENT = 14
    private const val T_GOV = 15
    private const val T_LIFE = 16
    private const val T_COVER = 17
    private const val T_CRASH = 18
    private const val T_LOD = 19
    private const val T_NOTE = 20

    private val TYPE_NAMES = arrayOf(
        "?", "session", "frames", "stutter", "memory", "work", "work_ms", "chunk_gen", "mesh", "upload",
        "far_tile", "gl_error", "error", "missing_terrain", "incident", "governor", "lifecycle",
        "coverage", "crash", "lod", "note"
    )

    /** Upload kinds for [upload]. */
    const val UP_CHUNK = 0
    const val UP_FAR = 1

    // Sizes and limits.
    private const val RING_CAPACITY = 12288
    private const val BEFORE_NS = 10_000_000_000L
    private const val AFTER_NS = 5_000_000_000L
    private const val MIN_INCIDENT_GAP_NS = 15_000_000_000L
    private const val MAX_INCIDENTS = 16
    private const val SESSION_CAP_LIGHT = 6L * 1024 * 1024
    private const val SESSION_CAP_DETAILED = 12L * 1024 * 1024
    private const val STORAGE_CAP = 32L * 1024 * 1024
    private const val KEEP_SESSIONS = 6

    @Volatile private var mode = MODE_OFF
    @Volatile private var ring: Ring? = null
    @Volatile private var running = false
    @Volatile private var generation = 0
    private var thread: Thread? = null
    private var appContext: Context? = null
    private val startStopLock = Any()
    private val lock = Any() // ring writes / reads
    private val flushLock = Any() // flushedSeq and the session file
    private val statsLock = Any() // session aggregates

    // Session identity and files.
    private var sessionId = ""
    private var sessionWallMs = 0L
    private var sessionNs = 0L
    private var dir: File? = null
    private var jsonlFile: File? = null
    private var jsonlOut: BufferedOutputStream? = null
    private var jsonlBytes = 0L
    private var previousAbnormal = false
    @Volatile private var settingsSnapshot = ""
    @Volatile private var lastReportFile: File? = null

    // Health counters (everything that was lost or shed).
    @Volatile private var droppedRing = 0L
    @Volatile private var shedLowPriority = 0L
    @Volatile private var droppedForSize = 0L
    @Volatile private var writeFailures = 0
    @Volatile private var suppressedIncidents = 0
    @Volatile private var lowPrioSuppressed = false
    private var flushedSeq = 0L

    // Render-thread frame window (touched only by the GL thread).
    private var lastFrameNs = 0L
    private var secStartNs = 0L
    private var secFrames = 0
    private var secSumMs = 0f
    private var secMaxMs = 0f
    private var secStutterEvents = 0
    private val frameRing = FloatArray(512)
    private var frameRingPos = 0
    private var frameRingCount = 0
    private val sortScratch = FloatArray(512)
    private var emaMs = 16f
    private var glCheckCounter = 0
    private var coverageNs = 0L
    private var missingSinceNs = 0L
    private var lastMissingEventNs = 0L

    // Published for the panel / status (written by the GL thread, read anywhere).
    @Volatile private var panelFps = 0f
    @Volatile private var panelP95 = 0f
    @Volatile private var panelMax = 0f
    @Volatile private var panelText = ""
    @Volatile private var glOverheadNs = 0L
    @Volatile private var glFrames = 0L
    @Volatile private var bgBusyNs = 0L

    // Session aggregates (under statsLock).
    private var totalFrames = 0L
    private var totalFrameMs = 0.0
    private var secondsSampled = 0
    private var fpsMin = Float.MAX_VALUE
    private var fpsMax = 0f
    private var fpsSum = 0.0
    private var p95Max = 0f
    private var stutters = 0
    private var freezes = 0
    private var worstFrameMs = 0f
    private var memUsedMin = Float.MAX_VALUE
    private var memUsedMax = 0f
    private var memUsedSum = 0.0
    private var memSamples = 0
    private var memLimitMb = 0f
    private var nativeMaxMb = 0f
    private var lowMemoryEvents = 0
    private var glErrors = 0
    private var errorsLogged = 0
    private var missingEvents = 0
    private var govChanges = 0
    private val errorTexts = ArrayList<String>()
    private var genN = 0L
    private var genMsSum = 0.0
    private var genMsMax = 0f
    private var meshN = 0L
    private var meshMsSum = 0.0
    private var meshMsMax = 0f
    private var upN = LongArray(2)
    private var upMsSum = DoubleArray(2)
    private var upMsMax = FloatArray(2)
    private val farN = LongArray(8)
    private val farMsSum = DoubleArray(8)
    private val farMsMax = FloatArray(8)
    private val farTriSum = LongArray(8)

    // Per-second counters (under statsLock), drained by the writer thread's once-a-second tick.
    private var secGen = 0
    private var secGenMs = 0f
    private var secMesh = 0
    private var secMeshMs = 0f
    private var secUp = 0
    private var secUpMs = 0f
    private var secFar = 0
    private var secFarMs = 0f

    // Incidents.
    private class Pending(val id: Int, val reason: String, val triggerNs: Long, val untilNs: Long)
    private class IncidentInfo(val id: Int, val wallMs: Long, val elapsedMs: Long, val reason: String, val text: String)
    @Volatile private var pending: Pending? = null
    private val incidentLock = Any()
    private var incidentCount = 0
    private var lastIncidentNs = 0L
    private val incidents = ArrayList<IncidentInfo>()

    // ---- the ring ---------------------------------------------------------------------------

    private class Ring(val capacity: Int) {
        val tNs = LongArray(capacity)
        val type = ByteArray(capacity)
        val prio = ByteArray(capacity)
        val a = FloatArray(capacity)
        val b = FloatArray(capacity)
        val c = FloatArray(capacity)
        val d = FloatArray(capacity)
        val msg = arrayOfNulls<String>(capacity)
        var head = 0L

        fun at(seq: Long): Ev {
            val i = (seq % capacity).toInt()
            return Ev(seq, tNs[i], type[i].toInt(), prio[i].toInt(), a[i], b[i], c[i], d[i], msg[i])
        }
    }

    private class Ev(
        val seq: Long, val tNs: Long, val type: Int, val prio: Int,
        val a: Float, val b: Float, val c: Float, val d: Float, val msg: String?
    )

    /** prio: 0 = low (shed under pressure), 1 = normal, 2 = important, 3 = critical. */
    private fun record(type: Int, prio: Int, a: Float, b: Float, c: Float, d: Float, msg: String?) {
        val r = ring ?: return
        if (prio == 0 && lowPrioSuppressed) {
            shedLowPriority++
            return
        }
        val now = System.nanoTime()
        synchronized(lock) {
            val i = (r.head % r.capacity).toInt()
            r.tNs[i] = now
            r.type[i] = type.toByte()
            r.prio[i] = prio.toByte()
            r.a[i] = a
            r.b[i] = b
            r.c[i] = c
            r.d[i] = d
            r.msg[i] = msg
            r.head++
        }
    }

    // ---- control ----------------------------------------------------------------------------

    fun isActive(): Boolean = mode != MODE_OFF

    fun currentMode(): Int = mode

    /** Remembers the application context; call once at start-up. Starts logging if [initialMode]
     *  is not OFF. */
    fun init(context: Context, initialMode: Int) {
        appContext = context.applicationContext
        setMode(initialMode)
    }

    /** Free-text description of the game settings, included in every report. */
    fun setSettingsSnapshot(text: String) {
        settingsSnapshot = text
        if (mode != MODE_OFF) record(T_NOTE, 1, 0f, 0f, 0f, 0f, "settings: $text")
    }

    fun setMode(newMode: Int) {
        val m = newMode.coerceIn(MODE_OFF, MODE_DETAILED)
        synchronized(startStopLock) {
            val old = mode
            if (m == old) return
            if (m == MODE_OFF) {
                mode = MODE_OFF
                stopThread()
                return
            }
            if (old == MODE_OFF) {
                startSession(m)
            } else {
                mode = m
                record(T_NOTE, 2, 0f, 0f, 0f, 0f, "mode changed to ${modeName(m)}")
            }
        }
    }

    /** Called when the activity goes away. [clean] = the user (or the app) is closing it for good,
     *  as opposed to the system tearing it down. */
    fun shutdown(clean: Boolean) {
        synchronized(startStopLock) {
            if (mode == MODE_OFF) return
            if (clean) record(T_LIFE, 2, 0f, 0f, 0f, 0f, "clean shutdown")
            mode = MODE_OFF
            stopThread(clean)
        }
    }

    private fun startSession(m: Int) {
        resetState()
        sessionNs = System.nanoTime()
        sessionWallMs = System.currentTimeMillis()
        sessionId = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(sessionWallMs))
        ring = Ring(RING_CAPACITY)
        generation++
        running = true
        mode = m
        record(T_SESSION, 3, 0f, 0f, 0f, 0f, "session $sessionId started in ${modeName(m)} mode")
        val myGeneration = generation
        thread = Thread({ writerLoop(myGeneration) }, "voxel-diag").apply {
            isDaemon = true
            start()
        }
    }

    private var stopCleanFlag = true

    private fun stopThread(clean: Boolean = true) {
        stopCleanFlag = clean
        running = false
        thread?.interrupt()
        thread = null
    }

    private fun resetState() {
        flushedSeq = 0L
        jsonlBytes = 0L
        droppedRing = 0L
        shedLowPriority = 0L
        droppedForSize = 0L
        writeFailures = 0
        suppressedIncidents = 0
        lowPrioSuppressed = false
        lastFrameNs = 0L
        secStartNs = 0L
        secFrames = 0
        secSumMs = 0f
        secMaxMs = 0f
        secStutterEvents = 0
        frameRingPos = 0
        frameRingCount = 0
        emaMs = 16f
        glCheckCounter = 0
        coverageNs = 0L
        missingSinceNs = 0L
        lastMissingEventNs = 0L
        glOverheadNs = 0L
        glFrames = 0L
        bgBusyNs = 0L
        panelText = ""
        pending = null
        previousAbnormal = false
        synchronized(incidentLock) {
            incidentCount = 0
            lastIncidentNs = 0L
            incidents.clear()
        }
        synchronized(statsLock) {
            totalFrames = 0L
            totalFrameMs = 0.0
            secondsSampled = 0
            fpsMin = Float.MAX_VALUE
            fpsMax = 0f
            fpsSum = 0.0
            p95Max = 0f
            stutters = 0
            freezes = 0
            worstFrameMs = 0f
            memUsedMin = Float.MAX_VALUE
            memUsedMax = 0f
            memUsedSum = 0.0
            memSamples = 0
            memLimitMb = 0f
            nativeMaxMb = 0f
            lowMemoryEvents = 0
            glErrors = 0
            errorsLogged = 0
            missingEvents = 0
            govChanges = 0
            errorTexts.clear()
            genN = 0L; genMsSum = 0.0; genMsMax = 0f
            meshN = 0L; meshMsSum = 0.0; meshMsMax = 0f
            upN = LongArray(2); upMsSum = DoubleArray(2); upMsMax = FloatArray(2)
            Arrays.fill(farN, 0L); Arrays.fill(farMsSum, 0.0); Arrays.fill(farMsMax, 0f); Arrays.fill(farTriSum, 0L)
            secGen = 0; secGenMs = 0f; secMesh = 0; secMeshMs = 0f
            secUp = 0; secUpMs = 0f; secFar = 0; secFarMs = 0f
        }
    }

    // ---- hooks (cheap when off) -------------------------------------------------------------

    /** Once per rendered frame, first thing in onDrawFrame. */
    fun frame() {
        val m = mode
        if (m == MODE_OFF) return
        val t0 = System.nanoTime()
        val last = lastFrameNs
        lastFrameNs = t0
        if (last != 0L) onFrameTime((t0 - last) / 1_000_000f, t0, m)
        glOverheadNs += System.nanoTime() - t0
        glFrames++
    }

    private fun onFrameTime(dtMs: Float, nowNs: Long, m: Int) {
        if (dtMs > 2500f) {
            // Back from the background / a very long pause: not a performance problem of the game.
            secStartNs = nowNs
            secFrames = 0
            secSumMs = 0f
            secMaxMs = 0f
            return
        }
        if (secStartNs == 0L) secStartNs = nowNs
        frameRing[frameRingPos] = dtMs
        frameRingPos = (frameRingPos + 1) and 511
        if (frameRingCount < 512) frameRingCount++
        secFrames++
        secSumMs += dtMs
        if (dtMs > secMaxMs) secMaxMs = dtMs

        val thr = if (m == MODE_DETAILED) max(34f, emaMs * 1.8f) else max(50f, emaMs * 2.4f)
        if (dtMs > thr) {
            var freeze = false
            synchronized(statsLock) {
                stutters++
                if (dtMs >= 500f) {
                    freezes++
                    freeze = true
                }
                if (dtMs > worstFrameMs) worstFrameMs = dtMs
            }
            if (secStutterEvents < 8) {
                secStutterEvents++
                record(T_STUTTER, 1, dtMs, emaMs, 0f, 0f, null)
            }
            val incidentMs = if (m == MODE_DETAILED) 120f else 200f
            if (dtMs >= incidentMs) {
                trigger(
                    if (freeze) String.format(Locale.US, "freeze: one frame took %.0f ms", dtMs)
                    else String.format(Locale.US, "lag spike: one frame took %.0f ms (typical %.0f ms)", dtMs, emaMs),
                    false
                )
            }
        } else {
            emaMs += (dtMs - emaMs) * 0.05f
        }

        if (nowNs - secStartNs >= 1_000_000_000L) {
            val seconds = (nowNs - secStartNs) / 1.0e9f
            val fps = secFrames / seconds
            val avg = secSumMs / max(1, secFrames)
            val p95 = percentile95()
            panelFps = fps
            panelP95 = p95
            panelMax = secMaxMs
            synchronized(statsLock) {
                totalFrames += secFrames
                totalFrameMs += secSumMs
                secondsSampled++
                if (fps < fpsMin) fpsMin = fps
                if (fps > fpsMax) fpsMax = fps
                fpsSum += fps
                if (p95 > p95Max) p95Max = p95
            }
            record(T_FRAMES, 1, fps, avg, p95, secMaxMs, null)
            secStartNs = nowNs
            secFrames = 0
            secSumMs = 0f
            secMaxMs = 0f
            secStutterEvents = 0
        }
    }

    private fun percentile95(): Float {
        val n = frameRingCount
        if (n == 0) return 0f
        // The most recent frames (up to one second's worth, at most the whole ring).
        val take = min(n, max(30, secFrames))
        for (k in 0 until take) {
            sortScratch[k] = frameRing[(frameRingPos - 1 - k) and 511]
        }
        Arrays.sort(sortScratch, 0, take)
        return sortScratch[min(take - 1, (take * 95) / 100)]
    }

    /** GL error check. Cheap on most drivers but not free, so it only runs every few frames. */
    fun glCheck(where: String) {
        val m = mode
        if (m == MODE_OFF) return
        glCheckCounter++
        val every = if (m == MODE_DETAILED) 4 else 30
        if (glCheckCounter % every != 0) return
        val t0 = System.nanoTime()
        val e = GLES30.glGetError()
        if (e != GLES30.GL_NO_ERROR) {
            var count = 0
            synchronized(statsLock) {
                glErrors++
                count = glErrors
                if (errorTexts.size < 12) errorTexts.add("GL error 0x" + Integer.toHexString(e) + " in " + where)
            }
            record(T_GLERR, 2, e.toFloat(), 0f, 0f, 0f, where)
            if (count <= 6) trigger("GL error 0x" + Integer.toHexString(e) + " in " + where, false)
        }
        glOverheadNs += System.nanoTime() - t0
    }

    /** A chunk finished generating (any thread). */
    fun chunkGen(ms: Float) {
        val m = mode
        if (m == MODE_OFF) return
        synchronized(statsLock) {
            genN++
            genMsSum += ms
            if (ms > genMsMax) genMsMax = ms
            secGen++
            secGenMs += ms
        }
        if (ms >= (if (m == MODE_DETAILED) 15f else 60f)) record(T_GEN, 0, ms, 0f, 0f, 0f, null)
    }

    /** A sub-chunk finished meshing (any thread). */
    fun meshBuild(ms: Float, triangles: Int) {
        val m = mode
        if (m == MODE_OFF) return
        synchronized(statsLock) {
            meshN++
            meshMsSum += ms
            if (ms > meshMsMax) meshMsMax = ms
            secMesh++
            secMeshMs += ms
        }
        if (ms >= (if (m == MODE_DETAILED) 12f else 50f)) record(T_MESH, 0, ms, triangles.toFloat(), 0f, 0f, null)
    }

    /** One frame's GPU uploads of [kind] ([UP_CHUNK], [UP_FAR]) took [ms] (GL thread). */
    fun upload(kind: Int, count: Int, ms: Float) {
        val m = mode
        if (m == MODE_OFF || count <= 0 || kind < 0 || kind > 1) return
        synchronized(statsLock) {
            upN[kind] += count.toLong()
            upMsSum[kind] += ms
            if (ms > upMsMax[kind]) upMsMax[kind] = ms
            secUp += count
            secUpMs += ms
        }
        if (ms >= (if (m == MODE_DETAILED) 4f else 10f)) record(T_UPLOAD, 0, kind.toFloat(), count.toFloat(), ms, 0f, null)
    }

    /** A far-terrain tile was built (builder thread). */
    fun farTile(level: Int, ms: Float, landTris: Int, waterTris: Int) {
        val m = mode
        if (m == MODE_OFF) return
        val l = level.coerceIn(0, 7)
        synchronized(statsLock) {
            farN[l]++
            farMsSum[l] += ms
            if (ms > farMsMax[l]) farMsMax[l] = ms
            farTriSum[l] += (landTris + waterTris).toLong()
            secFar++
            secFarMs += ms
        }
        if (m == MODE_DETAILED || ms >= 120f) record(T_FARTILE, 0, level.toFloat(), ms, landTris.toFloat(), waterTris.toFloat(), null)
    }

    /** Something went wrong in [source]. */
    fun error(source: String, text: String) {
        if (mode == MODE_OFF) return
        val full = "$source: $text"
        synchronized(statsLock) {
            errorsLogged++
            if (errorTexts.size < 12) errorTexts.add(full)
        }
        record(T_ERROR, 3, 0f, 0f, 0f, 0f, full)
        trigger("error in $source", false)
    }

    fun governor(scale: Float) {
        if (mode == MODE_OFF) return
        synchronized(statsLock) { govChanges++ }
        record(T_GOV, 1, scale, 0f, 0f, 0f, null)
    }

    fun lifecycle(name: String) {
        if (mode == MODE_OFF) return
        record(T_LIFE, 2, 0f, 0f, 0f, 0f, name)
    }

    fun note(text: String) {
        if (mode == MODE_OFF) return
        record(T_NOTE, 1, 0f, 0f, 0f, 0f, text)
    }

    /** Per-level-of-detail statistics of the frame just drawn (GL thread; DETAILED only). */
    fun lodStats(nearTris: Int, lodTris: Int, veryFarTris: Int, waterTris: Int) {
        if (mode != MODE_DETAILED) return
        record(T_LOD, 0, nearTris / 1000f, lodTris / 1000f, veryFarTris / 1000f, waterTris / 1000f, null)
    }

    /**
     * Terrain coverage, called a few times a second by the renderer. Raises "missing terrain" if
     * the voxel area stays far smaller than wanted, or the distant terrain stays absent, for
     * several seconds while the player is actually playing.
     */
    fun coverage(
        nearCovered: Float, nearWanted: Float, farCoveredBlocks: Float, farDrawn: Int, farTotal: Int,
        expectFar: Boolean, waiting: Boolean
    ) {
        val m = mode
        if (m == MODE_OFF) return
        val now = System.nanoTime()
        if (now - coverageNs < 1_000_000_000L) return
        coverageNs = now
        if (m == MODE_DETAILED) record(T_COVER, 0, nearCovered, nearWanted, farCoveredBlocks, farDrawn.toFloat(), null)
        if (waiting) {
            missingSinceNs = 0L
            return
        }
        val nearMissing = nearWanted >= 4f && nearCovered < nearWanted * 0.5f
        val farMissing = expectFar && farCoveredBlocks < 64f && farTotal == 0
        if (nearMissing || farMissing) {
            if (missingSinceNs == 0L) missingSinceNs = now
            val secs = (now - missingSinceNs) / 1.0e9f
            if (secs >= 4f && now - lastMissingEventNs > 20_000_000_000L) {
                lastMissingEventNs = now
                synchronized(statsLock) { missingEvents++ }
                record(T_MISSING, 2, nearCovered, nearWanted, farCoveredBlocks, secs, if (nearMissing) "voxel area" else "distant terrain")
                trigger(
                    String.format(
                        Locale.US, "missing terrain (%s): %.0f of %.0f chunks covered for %.0f s, distant terrain reaches %.0f blocks",
                        if (nearMissing) "voxel area" else "distant terrain", nearCovered, nearWanted, secs, farCoveredBlocks
                    ),
                    false
                )
            }
        } else {
            missingSinceNs = 0L
        }
    }

    // ---- incidents --------------------------------------------------------------------------

    /** The "Capture incident" button. */
    fun captureIncident() {
        if (mode == MODE_OFF) return
        trigger("manual capture", true)
    }

    private fun trigger(reason: String, manual: Boolean) {
        val now = System.nanoTime()
        var id = 0
        synchronized(incidentLock) {
            if (pending != null) return
            if (!manual && (incidentCount >= MAX_INCIDENTS || now - lastIncidentNs < MIN_INCIDENT_GAP_NS)) {
                suppressedIncidents++
                return
            }
            lastIncidentNs = now
            incidentCount++
            id = incidentCount
            pending = Pending(id, reason, now, now + (if (manual) 700_000_000L else AFTER_NS))
        }
        record(T_INCIDENT, 3, id.toFloat(), 0f, 0f, 0f, reason)
    }

    private fun finishIncidentIfDue(nowNs: Long) {
        val p = pending ?: return
        if (nowNs < p.untilNs) return
        pending = null
        val events = snapshot(p.triggerNs - BEFORE_NS, p.untilNs)
        val sdf = newFormat("HH:mm:ss.SSS")
        val sb = StringBuilder(events.size * 80 + 512)
        sb.append("Incident #").append(p.id).append(": ").append(p.reason).append('\n')
        sb.append("At ").append(wallString(p.triggerNs, newFormat("yyyy-MM-dd HH:mm:ss.SSS")))
            .append("   (+").append(String.format(Locale.US, "%.3f", (p.triggerNs - sessionNs) / 1.0e9)).append(" s into the session)\n")
        sb.append("Shown: ").append((BEFORE_NS / 1_000_000_000L).toInt()).append(" s before the trigger and ")
            .append(((p.untilNs - p.triggerNs) / 1_000_000L)).append(" ms after it. '>>' marks the trigger.\n\n")
        for (ev in events) {
            sb.append(if (ev.tNs >= p.triggerNs && ev.type == T_INCIDENT && ev.a.toInt() == p.id) ">> " else "   ")
            appendEventLine(sb, ev, sdf)
        }
        val text = sb.toString()
        synchronized(incidentLock) {
            if (incidents.size >= MAX_INCIDENTS) incidents.removeAt(0)
            incidents.add(IncidentInfo(p.id, wallMsOf(p.triggerNs), (p.triggerNs - sessionNs) / 1_000_000L, p.reason, text))
        }
        val d = dir ?: return
        try {
            val f = File(d, "incident-" + sessionId + "-" + p.id + ".txt")
            FileOutputStream(f).use { out ->
                out.write(text.toByteArray(Charsets.UTF_8))
                out.fd.sync()
            }
        } catch (t: Throwable) {
            writeFailures++
        }
    }

    // ---- crash ------------------------------------------------------------------------------

    /** Called by the crash handler (any thread): saves everything that is still in memory. */
    fun onCrash(thread: Thread, throwable: Throwable) {
        if (mode == MODE_OFF) return
        try {
            record(T_CRASH, 3, 0f, 0f, 0f, 0f, "uncaught " + throwable + " on thread " + thread.name)
            flushToFile(true)
            val now = System.nanoTime()
            val events = snapshot(now - 30_000_000_000L, now)
            val sdf = newFormat("HH:mm:ss.SSS")
            val sb = StringBuilder(events.size * 80 + 256)
            sb.append("Crash: ").append(throwable).append(" on thread ").append(thread.name).append('\n')
            sb.append("The last 30 s of events before it:\n\n")
            for (ev in events) appendEventLine(sb, ev, sdf)
            val d = dir ?: return
            FileOutputStream(File(d, "crash-$sessionId.txt")).use { out ->
                out.write(sb.toString().toByteArray(Charsets.UTF_8))
                out.fd.sync()
            }
        } catch (ignored: Throwable) {
            // never let diagnostics get in the way of the real crash handling
        }
    }

    // ---- the writer thread ------------------------------------------------------------------

    private fun writerLoop(myGeneration: Int) {
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
        } catch (t: Throwable) {
            // best effort
        }
        try {
            openSession()
        } catch (t: Throwable) {
            writeFailures++
        }
        var nextSecond = System.nanoTime() + 1_000_000_000L
        var nextFlush = System.nanoTime() + 1_000_000_000L
        var nextMem = System.nanoTime() + 500_000_000L
        var nextStorage = System.nanoTime() + 5_000_000_000L
        while (running && generation == myGeneration) {
            val t0 = System.nanoTime()
            try {
                if (t0 >= nextMem) {
                    sampleMemory()
                    nextMem = t0 + (if (mode == MODE_DETAILED) 1_000_000_000L else 2_000_000_000L)
                }
                if (t0 >= nextSecond) {
                    secondTick()
                    nextSecond = t0 + 1_000_000_000L
                }
                finishIncidentIfDue(t0)
                if (t0 >= nextFlush) {
                    flushToFile(false)
                    nextFlush = t0 + (if (mode == MODE_DETAILED) 1_000_000_000L else 2_000_000_000L)
                }
                if (t0 >= nextStorage) {
                    enforceStorageLimits()
                    nextStorage = t0 + 60_000_000_000L
                }
            } catch (t: Throwable) {
                writeFailures++
            }
            bgBusyNs += System.nanoTime() - t0
            try {
                Thread.sleep(200)
            } catch (e: InterruptedException) {
                break
            }
        }
        // Final flush, a last incident (if one was open), the report, then let go of everything.
        try {
            val p = pending
            if (p != null) {
                pending = null
                val nowNs = System.nanoTime()
                // finish it right away with what exists
                pending = Pending(p.id, p.reason, p.triggerNs, nowNs)
                finishIncidentIfDue(nowNs)
            }
            flushToFile(true)
            writeSessionReport()
            closeSession()
        } catch (t: Throwable) {
            // nothing more to do
        }
        if (generation == myGeneration) {
            // This was the current session's thread and nobody replaced it: release everything.
            ring = null
            val d = dir
            if (d != null && stopCleanFlag) {
                val flag = File(d, "running.flag")
                if (flag.exists()) flag.delete()
            }
        }
    }

    private fun openSession() {
        val ctx = appContext ?: return
        val d = File(ctx.noBackupFilesDir, "diag")
        d.mkdirs()
        dir = d
        val flag = File(d, "running.flag")
        if (flag.exists()) previousAbnormal = true
        flag.writeText(sessionId)
        val f = File(d, "events-$sessionId.jsonl")
        jsonlFile = f
        synchronized(flushLock) {
            jsonlOut = BufferedOutputStream(FileOutputStream(f, true), 32 * 1024)
        }
        record(T_NOTE, 2, 0f, 0f, 0f, 0f, deviceLine())
        if (previousAbnormal) {
            record(T_ERROR, 3, 0f, 0f, 0f, 0f, "the previous session ended without a clean shutdown (crash, out-of-memory kill or force stop); its files were kept")
        }
        enforceStorageLimits()
    }

    private fun closeSession() {
        synchronized(flushLock) {
            try {
                jsonlOut?.flush()
                jsonlOut?.close()
            } catch (t: Throwable) {
                writeFailures++
            }
            jsonlOut = null
        }
    }

    private fun deviceLine(): String {
        val rt = Runtime.getRuntime()
        return "device: " + Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE +
            " (SDK " + Build.VERSION.SDK_INT + "), " + rt.availableProcessors() + " cores, heap limit " +
            (rt.maxMemory() / (1024 * 1024)) + " MB"
    }

    private fun sampleMemory() {
        val ctx = appContext ?: return
        val rt = Runtime.getRuntime()
        val usedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576f
        val maxMb = rt.maxMemory() / 1048576f
        val nativeMb = Debug.getNativeHeapAllocatedSize() / 1048576f
        var availMb = -1f
        var low = false
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            availMb = info.availMem / 1048576f
            low = info.lowMemory
        } catch (t: Throwable) {
            // not essential
        }
        synchronized(statsLock) {
            memSamples++
            memUsedSum += usedMb
            if (usedMb < memUsedMin) memUsedMin = usedMb
            if (usedMb > memUsedMax) memUsedMax = usedMb
            memLimitMb = maxMb
            if (nativeMb > nativeMaxMb) nativeMaxMb = nativeMb
            if (low) lowMemoryEvents++
        }
        record(T_MEM, 1, usedMb, maxMb, nativeMb, availMb, if (low) "system low-memory flag set" else null)
        if (usedMb > maxMb * 0.92f) trigger(String.format(Locale.US, "heap nearly full: %.0f of %.0f MB", usedMb, maxMb), false)
        if (low) trigger("the system reports low memory", false)
    }

    private fun secondTick() {
        var gen = 0
        var genMs = 0f
        var mesh = 0
        var meshMs = 0f
        var up = 0
        var upMs = 0f
        var far = 0
        var farMs = 0f
        synchronized(statsLock) {
            gen = secGen; genMs = secGenMs; mesh = secMesh; meshMs = secMeshMs
            up = secUp; upMs = secUpMs; far = secFar; farMs = secFarMs
            secGen = 0; secGenMs = 0f; secMesh = 0; secMeshMs = 0f; secUp = 0; secUpMs = 0f; secFar = 0; secFarMs = 0f
        }
        record(T_WORK, 1, gen.toFloat(), mesh.toFloat(), up.toFloat(), far.toFloat(), null)
        record(T_WORKMS, 1, if (gen > 0) genMs / gen else 0f, if (mesh > 0) meshMs / mesh else 0f, upMs, if (far > 0) farMs / far else 0f, null)

        // Shed low-priority events when the writer is behind or the logger itself is costing frame time.
        val r = ring
        if (r != null) {
            val backlog = r.head - flushedSeq
            val overheadPct = overheadPercent()
            val shed = backlog > r.capacity * 3L / 4L || overheadPct > 1.5f
            if (shed != lowPrioSuppressed) {
                lowPrioSuppressed = shed
                record(T_NOTE, 2, 0f, 0f, 0f, 0f, if (shed) "reducing low-priority logging (backlog $backlog, overhead ${"%.2f".format(Locale.US, overheadPct)}%)" else "low-priority logging restored")
            }
        }

        val sb = StringBuilder(160)
        sb.append("DIAG ").append(modeName(mode).substring(0, 1)).append("  ")
            .append(String.format(Locale.US, "fps %.0f  p95 %.0f ms  max %.0f ms", panelFps, panelP95, panelMax)).append('\n')
        val rt = Runtime.getRuntime()
        val usedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576L
        sb.append(String.format(Locale.US, "stutters %d  heap %d/%d MB  gen %d/s  mesh %d/s  up %d/s  far %d/s", stuttersNow(), usedMb, rt.maxMemory() / 1048576L, gen, mesh, up, far)).append('\n')
        sb.append(String.format(Locale.US, "dropped %d  shed %d  incidents %d  overhead %.2f%%", droppedRing + droppedForSize, shedLowPriority, incidentCount, overheadPercent()))
        panelText = sb.toString()
    }

    private fun stuttersNow(): Int = synchronized(statsLock) { stutters }

    private fun overheadPercent(): Float {
        val frames = glFrames
        if (frames <= 0L) return 0f
        val elapsedNs = max(1L, System.nanoTime() - sessionNs)
        return (glOverheadNs * 100.0 / elapsedNs).toFloat()
    }

    // ---- file output ------------------------------------------------------------------------

    private fun flushToFile(isFinal: Boolean) {
        val r = ring ?: return
        synchronized(flushLock) {
            val out = jsonlOut
            val batch = ArrayList<Ev>()
            synchronized(lock) {
                val head = r.head
                val oldest = max(0L, head - r.capacity)
                if (flushedSeq < oldest) {
                    droppedRing += oldest - flushedSeq
                    flushedSeq = oldest
                }
                var s = flushedSeq
                while (s < head) {
                    batch.add(r.at(s))
                    s++
                }
                flushedSeq = head
            }
            if (out == null || batch.isEmpty()) return
            val cap = if (mode == MODE_DETAILED) SESSION_CAP_DETAILED else SESSION_CAP_LIGHT
            val sdf = newFormat("yyyy-MM-dd HH:mm:ss.SSS")
            val sb = StringBuilder(batch.size * 110)
            for (ev in batch) {
                if (jsonlBytes + sb.length > cap && ev.prio < 3) {
                    droppedForSize++
                    continue
                }
                appendJson(sb, ev, sdf)
            }
            if (sb.isEmpty()) return
            try {
                val bytes = sb.toString().toByteArray(Charsets.UTF_8)
                out.write(bytes)
                out.flush()
                jsonlBytes += bytes.size.toLong()
            } catch (t: Throwable) {
                writeFailures++
            }
        }
    }

    /** Keeps the diag folder bounded: the newest [KEEP_SESSIONS] sessions' files, and at most
     *  [STORAGE_CAP] bytes in total (oldest first). The current session is never touched. */
    private fun enforceStorageLimits() {
        val d = dir ?: return
        val files = d.listFiles() ?: return
        val keepIds = HashSet<String>()
        val sessions = ArrayList<String>()
        for (f in files) {
            val n = f.name
            if (n.startsWith("events-") && n.endsWith(".jsonl")) sessions.add(n.substring(7, n.length - 6))
        }
        sessions.sort()
        for (k in sessions.indices.reversed()) {
            if (keepIds.size < KEEP_SESSIONS) keepIds.add(sessions[k])
        }
        keepIds.add(sessionId)
        for (f in files) {
            val n = f.name
            if (n == "running.flag" || n == "share" || !f.isFile) continue
            var owner: String? = null
            for (id in sessions) if (n.contains(id)) owner = id
            if (owner == null) for (id in keepIds) if (n.contains(id)) owner = id
            if (owner != null && !keepIds.contains(owner)) f.delete()
        }
        var total = 0L
        val left = d.listFiles()?.filter { it.isFile && it.name != "running.flag" }?.sortedBy { it.lastModified() } ?: return
        for (f in left) total += f.length()
        for (f in left) {
            if (total <= STORAGE_CAP) break
            if (f == jsonlFile || f.name.contains(sessionId)) continue
            total -= f.length()
            f.delete()
        }
    }

    // ---- snapshots and formatting -----------------------------------------------------------

    private fun snapshot(fromNs: Long, toNs: Long): ArrayList<Ev> {
        val out = ArrayList<Ev>()
        val r = ring ?: return out
        synchronized(lock) {
            val head = r.head
            var s = max(0L, head - r.capacity)
            while (s < head) {
                val ev = r.at(s)
                if (ev.tNs in fromNs..toNs) out.add(ev)
                s++
            }
        }
        return out
    }

    private fun newFormat(pattern: String): SimpleDateFormat {
        val f = SimpleDateFormat(pattern, Locale.US)
        f.timeZone = TimeZone.getDefault()
        return f
    }

    private fun wallMsOf(tNs: Long): Long = sessionWallMs + (tNs - sessionNs) / 1_000_000L

    private fun wallString(tNs: Long, sdf: SimpleDateFormat): String = sdf.format(Date(wallMsOf(tNs)))

    private fun jsonEscape(sb: StringBuilder, s: String) {
        sb.append('"')
        for (ch in s) {
            when {
                ch == '"' -> sb.append("\\\"")
                ch == '\\' -> sb.append("\\\\")
                ch == '\n' -> sb.append("\\n")
                ch == '\r' -> sb.append("\\r")
                ch == '\t' -> sb.append("\\t")
                ch < ' ' -> sb.append(' ')
                else -> sb.append(ch)
            }
        }
        sb.append('"')
    }

    private fun num(sb: StringBuilder, v: Float) {
        if (v.isNaN() || v.isInfinite()) sb.append('0') else sb.append(String.format(Locale.US, "%.2f", v))
    }

    /** One JSON object per line: readable keys per kind of event. */
    private fun appendJson(sb: StringBuilder, ev: Ev, sdf: SimpleDateFormat) {
        sb.append("{\"seq\":").append(ev.seq)
        sb.append(",\"t_ms\":").append(String.format(Locale.US, "%.3f", (ev.tNs - sessionNs) / 1.0e6))
        sb.append(",\"local\":\"").append(wallString(ev.tNs, sdf)).append('"')
        sb.append(",\"type\":\"").append(TYPE_NAMES[if (ev.type in TYPE_NAMES.indices) ev.type else 0]).append('"')
        sb.append(",\"prio\":").append(ev.prio)
        fun f(key: String, v: Float) {
            sb.append(",\"").append(key).append("\":")
            num(sb, v)
        }
        when (ev.type) {
            T_FRAMES -> { f("fps", ev.a); f("avg_ms", ev.b); f("p95_ms", ev.c); f("max_ms", ev.d) }
            T_STUTTER -> { f("frame_ms", ev.a); f("typical_ms", ev.b) }
            T_MEM -> { f("heap_used_mb", ev.a); f("heap_max_mb", ev.b); f("native_mb", ev.c); f("system_free_mb", ev.d) }
            T_WORK -> { f("chunks_generated", ev.a); f("meshes_built", ev.b); f("uploads", ev.c); f("far_tiles_built", ev.d) }
            T_WORKMS -> { f("gen_avg_ms", ev.a); f("mesh_avg_ms", ev.b); f("upload_ms_total", ev.c); f("far_tile_avg_ms", ev.d) }
            T_GEN -> f("ms", ev.a)
            T_MESH -> { f("ms", ev.a); f("triangles", ev.b) }
            T_UPLOAD -> { sb.append(",\"kind\":\"").append(if (ev.a.toInt() == UP_FAR) "far" else "chunk").append('"'); f("count", ev.b); f("ms", ev.c) }
            T_FARTILE -> { f("level", ev.a); f("ms", ev.b); f("land_tris", ev.c); f("water_tris", ev.d) }
            T_GLERR -> f("code", ev.a)
            T_MISSING -> { f("chunks_covered", ev.a); f("chunks_wanted", ev.b); f("far_covered_blocks", ev.c); f("seconds", ev.d) }
            T_INCIDENT -> f("id", ev.a)
            T_GOV -> f("dist_scale", ev.a)
            T_COVER -> { f("chunks_covered", ev.a); f("chunks_wanted", ev.b); f("far_covered_blocks", ev.c); f("far_tiles_drawn", ev.d) }
            T_LOD -> { f("voxel_ktris", ev.a); f("lod123_ktris", ev.b); f("very_far_ktris", ev.c); f("water_ktris", ev.d) }
            else -> {}
        }
        if (ev.msg != null) {
            sb.append(",\"msg\":")
            jsonEscape(sb, ev.msg)
        }
        sb.append("}\n")
    }

    /** One readable line: "14:03:22.123 (+142.331s) frames ..." */
    private fun appendEventLine(sb: StringBuilder, ev: Ev, sdf: SimpleDateFormat) {
        sb.append(wallString(ev.tNs, sdf)).append(" (+").append(String.format(Locale.US, "%.3f", (ev.tNs - sessionNs) / 1.0e9)).append("s)  ")
        sb.append(TYPE_NAMES[if (ev.type in TYPE_NAMES.indices) ev.type else 0]).append("  ")
        val a = ev.a
        val b = ev.b
        val c = ev.c
        val d = ev.d
        when (ev.type) {
            T_FRAMES -> sb.append(String.format(Locale.US, "fps %.1f  avg %.1f ms  p95 %.1f ms  max %.1f ms", a, b, c, d))
            T_STUTTER -> sb.append(String.format(Locale.US, "frame %.1f ms (typical %.1f ms)", a, b))
            T_MEM -> sb.append(String.format(Locale.US, "heap %.0f/%.0f MB  native %.0f MB  system free %.0f MB", a, b, c, d))
            T_WORK -> sb.append(String.format(Locale.US, "last second: %d chunks generated, %d meshes, %d uploads, %d far tiles", a.toInt(), b.toInt(), c.toInt(), d.toInt()))
            T_WORKMS -> sb.append(String.format(Locale.US, "avg gen %.1f ms, mesh %.1f ms, upload total %.1f ms, far tile %.1f ms", a, b, c, d))
            T_GEN -> sb.append(String.format(Locale.US, "slow chunk generation: %.1f ms", a))
            T_MESH -> sb.append(String.format(Locale.US, "slow mesh build: %.1f ms (%d triangles)", a, b.toInt()))
            T_UPLOAD -> sb.append(String.format(Locale.US, "%s upload: %d items in %.1f ms", if (a.toInt() == UP_FAR) "far-tile" else "chunk-mesh", b.toInt(), c))
            T_FARTILE -> sb.append(String.format(Locale.US, "far tile level %d built in %.1f ms (%d land + %d water triangles)", a.toInt(), b, c.toInt(), d.toInt()))
            T_GLERR -> sb.append(String.format(Locale.US, "GL error 0x%x", a.toInt()))
            T_MISSING -> sb.append(String.format(Locale.US, "missing terrain: %.0f/%.0f chunks, distant terrain %.0f blocks, for %.0f s", a, b, c, d))
            T_INCIDENT -> sb.append("incident #").append(a.toInt()).append(" opened")
            T_GOV -> sb.append(String.format(Locale.US, "adaptive distance scale %.0f%%", a * 100f))
            T_COVER -> sb.append(String.format(Locale.US, "coverage: %.0f/%.0f chunks, distant %.0f blocks, %d far tiles drawn", a, b, c, d.toInt()))
            T_LOD -> sb.append(String.format(Locale.US, "triangles (k): voxel %.0f, LOD1-3 %.0f, very far %.0f, water %.0f", a, b, c, d))
            else -> {}
        }
        if (ev.msg != null) {
            if (ev.type != T_INCIDENT && ev.type != T_NOTE && ev.type != T_ERROR && ev.type != T_SESSION && ev.type != T_LIFE && ev.type != T_CRASH) sb.append("  ")
            sb.append(ev.msg)
        }
        sb.append('\n')
    }

    // ---- reports ----------------------------------------------------------------------------

    /** Text for the diagnostics dialog. */
    fun statusText(): String {
        if (mode == MODE_OFF) {
            return "Diagnostics are OFF (nothing is recorded and nothing runs). Turn them on under Settings > Diagnostics."
        }
        val r = ring
        val sb = StringBuilder()
        sb.append("Mode: ").append(modeName(mode)).append('\n')
        sb.append("Session ").append(sessionId).append(", ").append(String.format(Locale.US, "%.0f", (System.nanoTime() - sessionNs) / 1.0e9)).append(" s\n")
        sb.append("Events recorded: ").append(r?.head ?: 0L).append('\n')
        sb.append("Incidents: ").append(incidentCount).append(" (").append(suppressedIncidents).append(" suppressed)\n")
        sb.append("Dropped: ").append(droppedRing + droppedForSize).append("   shed: ").append(shedLowPriority).append('\n')
        sb.append(String.format(Locale.US, "Overhead: %.3f%% of frame time on the render thread", overheadPercent()))
        return sb.toString()
    }

    /** Compact text for the in-game panel (rebuilt once a second). */
    fun panelText(): String = if (mode == MODE_OFF) "" else panelText

    /**
     * Writes the readable report and a copy of the structured event log to the share folder and
     * returns them (the report first). Blocking, with file I/O: call from a background thread,
     * never from the render thread. With logging off, the files of the latest session on disk are
     * returned instead (null if there are none).
     */
    fun exportFiles(context: Context): List<File>? {
        val base = File(context.noBackupFilesDir, "diag")
        val share = File(base, "share")
        share.mkdirs()
        share.listFiles()?.forEach { it.delete() }
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val result = ArrayList<File>()
        if (mode != MODE_OFF && ring != null) {
            flushToFile(true)
            val report = File(share, "voxelsandbox-report-$stamp.txt")
            report.writeText(buildReport(context), Charsets.UTF_8)
            result.add(report)
            val src = jsonlFile
            if (src != null && src.exists()) {
                val dst = File(share, "voxelsandbox-events-$stamp.jsonl")
                synchronized(flushLock) {
                    FileInputStream(src).use { input -> FileOutputStream(dst).use { out -> input.copyTo(out) } }
                }
                result.add(dst)
            }
            return result
        }
        // Logging is off: share the newest saved session.
        val files = base.listFiles() ?: return null
        val newest = files.filter { it.name.startsWith("events-") && it.name.endsWith(".jsonl") }.maxByOrNull { it.name } ?: return null
        val id = newest.name.substring(7, newest.name.length - 6)
        val savedReport = File(base, "report-$id.txt")
        if (savedReport.exists()) {
            val dst = File(share, "voxelsandbox-report-$id.txt")
            savedReport.copyTo(dst, true)
            result.add(dst)
        }
        val dstEvents = File(share, "voxelsandbox-events-$id.jsonl")
        newest.copyTo(dstEvents, true)
        result.add(dstEvents)
        return result
    }

    /** The folder shared files are served from (see [DiagFileProvider]). */
    fun shareDir(context: Context): File = File(File(context.noBackupFilesDir, "diag"), "share")

    /** Saves the full log now (flushes and writes the report) and returns the files' folder. */
    fun saveNow(context: Context): File? {
        if (mode == MODE_OFF || ring == null) return null
        flushToFile(true)
        val d = dir ?: return null
        writeSessionReport()
        return d
    }

    private fun writeSessionReport() {
        val ctx = appContext ?: return
        val d = dir ?: return
        try {
            val f = File(d, "report-$sessionId.txt")
            f.writeText(buildReport(ctx), Charsets.UTF_8)
            lastReportFile = f
        } catch (t: Throwable) {
            writeFailures++
        }
    }

    private fun buildReport(context: Context): String {
        val nowNs = System.nanoTime()
        val full = newFormat("yyyy-MM-dd HH:mm:ss.SSS")
        val tz = TimeZone.getDefault()
        val offsetMin = tz.getOffset(System.currentTimeMillis()) / 60000
        val offsetText = String.format(Locale.US, "UTC%+03d:%02d", offsetMin / 60, Math.abs(offsetMin % 60))
        val sb = StringBuilder(16 * 1024)
        sb.append("VoxelSandbox diagnostic report\n")
        sb.append("==============================\n")
        sb.append("Generated:  ").append(full.format(Date())).append("  (local time, ").append(offsetText).append(")\n")
        sb.append("Session:    ").append(sessionId).append(", started ").append(full.format(Date(sessionWallMs)))
            .append(", running ").append(String.format(Locale.US, "%.1f", (nowNs - sessionNs) / 1.0e9)).append(" s (monotonic clock)\n")
        sb.append("Mode:       ").append(modeName(mode)).append('\n')
        try {
            val pi = context.packageManager.getPackageInfo(context.packageName, 0)
            sb.append("App:        ").append(context.packageName).append(' ').append(pi.versionName).append('\n')
        } catch (t: Throwable) {
            // not essential
        }
        sb.append("Device:     ").append(deviceLine().removePrefix("device: ")).append('\n')
        sb.append("Settings:   ").append(if (settingsSnapshot.isEmpty()) "(not recorded)" else settingsSnapshot).append('\n')
        sb.append("Previous session: ").append(if (previousAbnormal) "ENDED ABNORMALLY (crash, out-of-memory kill or force stop)" else "ended normally (or this is the first)").append("\n\n")

        sb.append("== Summary ==\n")
        synchronized(statsLock) {
            val seconds = max(1, secondsSampled)
            sb.append(String.format(Locale.US, "Frames: %d over %d s sampled. FPS avg %.1f, min %.1f, max %.1f. Worst 95th-percentile frame time in any second: %.1f ms.\n",
                totalFrames, secondsSampled, (fpsSum / seconds).toFloat(), if (fpsMin == Float.MAX_VALUE) 0f else fpsMin, fpsMax, p95Max))
            sb.append(String.format(Locale.US, "Stutters: %d (frames much slower than the recent typical frame), freezes (frame of 500 ms or more): %d, worst single frame: %.0f ms.\n", stutters, freezes, worstFrameMs))
            if (memSamples > 0) {
                sb.append(String.format(Locale.US, "Java heap used: min %.0f, avg %.0f, max %.0f MB of a %.0f MB limit. Native heap peak: %.0f MB. System low-memory flag seen %d times.\n",
                    memUsedMin, (memUsedSum / memSamples).toFloat(), memUsedMax, memLimitMb, nativeMaxMb, lowMemoryEvents))
            }
            sb.append(String.format(Locale.US, "Chunk generation: %d chunks, avg %.1f ms, max %.1f ms.\n", genN, if (genN > 0) (genMsSum / genN).toFloat() else 0f, genMsMax))
            sb.append(String.format(Locale.US, "Mesh building: %d sub-chunks, avg %.1f ms, max %.1f ms.\n", meshN, if (meshN > 0) (meshMsSum / meshN).toFloat() else 0f, meshMsMax))
            sb.append(String.format(Locale.US, "GPU uploads (per frame, render thread): chunk meshes %d items, avg %.2f ms, worst frame %.1f ms; far tiles %d items, avg %.2f ms, worst frame %.1f ms.\n",
                upN[0], if (upN[0] > 0) (upMsSum[0] / upN[0]).toFloat() else 0f, upMsMax[0], upN[1], if (upN[1] > 0) (upMsSum[1] / upN[1]).toFloat() else 0f, upMsMax[1]))
            sb.append("Far-terrain tiles built (level: count, avg ms, max ms, avg triangles):")
            var any = false
            for (l in 0 until 8) {
                if (farN[l] == 0L) continue
                any = true
                sb.append(String.format(Locale.US, "  [%d] %d, %.1f, %.1f, %d;", l, farN[l], (farMsSum[l] / farN[l]).toFloat(), farMsMax[l], farTriSum[l] / farN[l]))
            }
            if (!any) sb.append("  none")
            sb.append('\n')
            sb.append("Adaptive-distance changes: ").append(govChanges).append("   GL errors: ").append(glErrors)
                .append("   other errors: ").append(errorsLogged).append("   missing-terrain episodes: ").append(missingEvents).append('\n')
            for (e in errorTexts) sb.append("  - ").append(e).append('\n')
        }

        sb.append("\n== Diagnostics health ==\n")
        val dropped = droppedRing
        val problems = ArrayList<String>()
        if (dropped > 0) problems.add("$dropped events were overwritten before they could be written (the writer fell behind)")
        if (droppedForSize > 0) problems.add("$droppedForSize events were not written because the session file reached its size limit")
        if (writeFailures > 0) problems.add("$writeFailures file operations failed")
        if (shedLowPriority > 0) problems.add("$shedLowPriority low-priority events were skipped on purpose to keep logging cheap")
        if (suppressedIncidents > 0) problems.add("$suppressedIncidents incidents were not captured (rate limit)")
        if (previousAbnormal) problems.add("the previous session did not end cleanly, so its log may be cut short")
        val complete = dropped == 0L && droppedForSize == 0L && writeFailures == 0
        sb.append("Log completeness: ").append(if (complete) "COMPLETE for the recorded priorities" else "INCOMPLETE").append('\n')
        for (p in problems) sb.append("  - ").append(p).append('\n')
        val bgPct = bgBusyNs * 100.0 / max(1L, nowNs - sessionNs)
        val perFrameUs = if (glFrames > 0) glOverheadNs / 1000.0 / glFrames else 0.0
        sb.append(String.format(Locale.US, "Overhead: render thread %.1f microseconds per frame (%.3f%% of wall time); background writer busy %.2f%% of one core. Event file: %.1f KB.\n",
            perFrameUs, overheadPercent(), bgPct, jsonlBytes / 1024.0))

        val list = synchronized(incidentLock) { ArrayList(incidents) }
        sb.append("\n== Incidents (").append(list.size).append(") ==\n")
        if (list.isEmpty()) sb.append("none captured\n")
        for (i in list) {
            sb.append(String.format(Locale.US, "#%d  %s  (+%.3f s)  %s\n", i.id, full.format(Date(i.wallMs)), i.elapsedMs / 1000.0, i.reason))
        }
        // The latest few incidents in full.
        val from = max(0, list.size - 4)
        for (k in from until list.size) {
            sb.append("\n-------- ").append("Incident #").append(list[k].id).append(" in detail --------\n")
            sb.append(list[k].text)
        }

        sb.append("\n== Most recent events (oldest first) ==\n")
        val events = snapshot(nowNs - 120_000_000_000L, nowNs)
        val shortFormat = newFormat("HH:mm:ss.SSS")
        val start = max(0, events.size - 300)
        for (k in start until events.size) appendEventLine(sb, events[k], shortFormat)
        sb.append("\n(The complete structured log is in the .jsonl file: one JSON object per line.)\n")
        return sb.toString()
    }
}
