# GBA ROM Explorer

Offline Android toolkit for exploring, analyzing, and hacking Game Boy
Advance ROMs. Not an emulator — a ROM analysis/hacking toolkit.

## Architecture

Kotlin, single `:app` module, MVVM + Repository pattern, Compose Material 3,
Kotlin Coroutines/Flow throughout. Package layout:

```
core/           Pure Kotlin business logic — no Android framework
                dependencies except where reading files requires it.
                Unit-testable in isolation (see app/src/test).
  rom/          RomAccessor (lazy random access), header parsing,
                checksums (CRC32/MD5/SHA-1), save-type detection.
  analysis/     RegionAnalyzer interface + concrete analyzers
                (header/free-space/LZ77/pointer-table/text), the
                AnalysisEngine that merges their output, and the
                plugin extension point (AnalyzerRegistry /
                GameAnalyzerPlugin) for future game-specific modules.
  compression/  Real GBA LZ77 (LZSS) codec — decompress + compress.
  patch/        PatchFormat interface + full IPS implementation.
  hex/          Hex editor engine: sparse edit overlay with
                undo/redo, streaming byte/text search.

data/repository/  RomSessionManager (single source of truth for the
                   currently-open ROM), plus DataStore-backed
                   recents/favorites/bookmarks repositories.

domain/usecase/    Orchestration that spans core + data + Android I/O:
                   report export (JSON/CSV/HTML/Markdown), IPS
                   create/apply/verify via SAF.

ui/             Compose screens + ViewModels, one package per screen.
                theme/ holds Material 3 theming and region-color
                mapping shared between the ROM Map and Analyzer screens.

di/             Single Koin module wiring the graph above.
```

### Why these choices

- **Koin over Hilt**: no annotation processing, so nothing to debug
  from a phone-only, no-ADB workflow if DI wiring goes wrong — a
  Koin `single {}` that references the wrong type fails at app
  startup with a plain stack trace, not a build-time codegen error.
- **DataStore + kotlinx.serialization over Room**: recents/
  favorites/bookmarks are small lists; JSON-in-DataStore avoids a
  second annotation-processing dependency (Room/KSP) for data that
  doesn't need SQL.
- **SAF (Storage Access Framework) only, no storage permissions**:
  `ACTION_OPEN_DOCUMENT` / `ACTION_CREATE_DOCUMENT` need no runtime
  permission grant and work the same on Android 8 through 15+,
  including the Android 11 (API 30) test device this app targets.
- **Release minification is off** (see `app/build.gradle.kts`): with
  no attached device to smoke-test an R8-stripped build, a minified
  release could break silently. Worth revisiting once release builds
  can be tested.
- **`gradlew` is a minimal custom script**, not the full stock Gradle
  wrapper boilerplate — it only needs to work on the `ubuntu-latest`
  CI runner your workflow already targets, so the Cygwin/MSYS/Darwin
  path-handling in the stock script is dead weight here and one more
  thing to transcribe wrong by hand.

## What's implemented (Phase 1)

Every feature below is fully implemented — no stub functions, no fake
UI:

- **Home**: open a ROM via SAF, recents, favorites, quick actions.
- **ROM Info**: title/game code/maker code/version, fixed-byte and
  header-checksum validation, logo-region presence check, boot-mode
  heuristic, CRC32/MD5/SHA-1 (streamed), save-type detection
  (SRAM/EEPROM/FLASH signature scan), warnings for anything invalid.
- **Hex Editor**: paginated hex+ASCII view (never loads the whole
  ROM), edit mode with a sparse overlay and full undo/redo, streaming
  byte/text search, bookmarks, jump-to-offset, save-as via SAF.
- **ROM Map**: pinch-to-zoom / pan / tap visual map of the ROM
  address space, color-coded by detected region type, tap-to-open
  the Hex Editor.
- **ROM Analyzer**: header / free-space / LZ77-compressed / pointer-
  table / ASCII-text detection, each region carries a confidence
  score; filterable by type; results are cached to disk by ROM hash.
- **Reports**: export the analysis as JSON, CSV, HTML, or Markdown.
- **Patch Tool**: create / apply / verify IPS patches end-to-end.
- **Plugin architecture**: `RegionAnalyzer`, `GameAnalyzerPlugin`,
  `AnalyzerRegistry`, and `PatchFormat` are all designed so a new
  game-specific analyzer or patch format (UPS/BPS, then a Pokémon
  data plugin) is a new class + one registration line — nothing in
  `AnalysisEngine` or existing analyzers needs to change.

## Roadmap (not yet built — no placeholder screens for these)

Graphics/Palette/Text-explorer viewers, Pointer Explorer cross-
reference navigation, File Comparison, UPS/BPS patch formats,
ARM/Thumb code disassembly-based detection, and the Pokémon data
plugin are all designed for (interfaces exist) but not implemented.
The Tools screen lists them as "Coming soon" rather than linking to
half-built screens.

## Building

Push a zip of this project to wherever your existing `uploads/**`
build workflow watches for it — the workflow finds `settings.gradle.kts`
inside the archive automatically. No changes to that workflow are
needed; this project only needed a `gradlew`/`gradle-wrapper.properties`
that match what it already expects.
