# GBA ROM Explorer

Offline Android toolkit for exploring, analyzing, and hacking Game Boy
Advance ROMs. Not an emulator — a ROM analysis/hacking toolkit.

## Architecture

Kotlin, single `:app` module, MVVM + Repository pattern, Compose Material 3,
Kotlin Coroutines/Flow throughout. Package layout:

```
core/           Pure Kotlin business logic — no Android framework
                dependencies except where reading files requires it.
                Unit-testable in isolation (see app/src/test).
  rom/          RomAccessor (lazy random access), header parsing,
                checksums (CRC32/MD5/SHA-1), save-type detection.
  analysis/     RegionAnalyzer interface + concrete analyzers
                (header/free-space/LZ77/pointer-table/text), the
                AnalysisEngine that merges their output, and the
                plugin extension point (AnalyzerRegistry /
                GameAnalyzerPlugin) for future game-specific modules.
  compression/  Real GBA LZ77 (LZSS) codec — decompress + compress.
  patch/        PatchFormat interface + full IPS implementation.
  hex/          Hex editor engine: sparse edit overlay with
                undo/redo, streaming byte/text search.
  common/       FreeSpaceAllocator — the free-space scan-and-claim
                logic shared by every writer that can grow ROM data
                (pokescript, worldmap events, trainer parties), so
                there's one implementation instead of three.
  pokemon/      FireRed's species/move/item/trainer tables, plus
                real per-move battle-animation script reading.
  worldmap/     FireRed's map bank table, map headers/layouts/
                tilesets/events, and real tile-graphics rendering.
                Named `worldmap`, not `rommap`, specifically to not
                collide in name with the unrelated existing
                `ui.rommap` package (the byte-address-space map).
  pokescript/   FireRed's field-script engine: the verified opcode
                table, a linear disassembler, and the text
                assembler/writer that round-trips edits back to ROM.

data/repository/  RomSessionManager (single source of truth for the
                   currently-open ROM), plus DataStore-backed
                   recents/favorites/bookmarks repositories.

domain/usecase/    Orchestration that spans core + data + Android I/O:
                   report export (JSON/CSV/HTML/Markdown), IPS
                   create/apply/verify via SAF, ROM expansion via SAF.

ui/             Compose screens + ViewModels, one package per screen.
                theme/ holds Material 3 theming and region-color
                mapping shared between the ROM Map and Analyzer screens.
                common/ holds small shared composables (SectionHeader,
                ErrorBanner, ConfirmDialog) and the one DecodedImage ->
                ImageBitmap conversion every icon/tile-rendering screen
                uses.

di/             Single Koin module wiring the graph above.
```

### Why these choices

- **Koin over Hilt**: no annotation processing, so nothing to debug
  from a phone-only, no-ADB workflow if DI wiring goes wrong — a
  Koin `single {}` that references the wrong type fails at app
  startup with a plain stack trace, not a build-time codegen error.
- **DataStore + kotlinx.serialization over Room**: recents/
  favorites/bookmarks are small lists; JSON-in-DataStore avoids a
  second annotation-processing dependency (Room/KSP) for data that
  doesn't need SQL.
- **SAF (Storage Access Framework) only, no storage permissions**:
  `ACTION_OPEN_DOCUMENT` / `ACTION_CREATE_DOCUMENT` need no runtime
  permission grant and work the same on Android 8 through 15+,
  including the Android 11 (API 30) test device this app targets.
- **Release minification is on** (see `app/build.gradle.kts` and
  `app/proguard-rules.pro`): keep rules are in place for Koin and
  kotlinx.serialization, the two reflection-sensitive libraries this
  app uses, but with no attached device in CI, a release build has
  not actually been installed and smoke-tested yet. Do that before
  shipping - a missing keep rule shows up as a runtime crash, not a
  build failure.
- **`gradlew` is a minimal custom script**, not the full stock Gradle
  wrapper boilerplate — it only needs to work on the `ubuntu-latest`
  CI runner your workflow already targets, so the Cygwin/MSYS/Darwin
  path-handling in the stock script is dead weight here and one more
  thing to transcribe wrong by hand.

## What's implemented (Phase 1)

Every feature below is fully implemented — no stub functions, no fake
UI:

- **Home**: open a ROM via SAF, recents, favorites, quick actions.
- **ROM Info**: title/game code/maker code/version, fixed-byte and
  header-checksum validation, logo-region presence check, boot-mode
  heuristic, CRC32/MD5/SHA-1 (streamed), save-type detection
  (SRAM/EEPROM/FLASH signature scan), warnings for anything invalid.
- **Hex Editor**: paginated hex+ASCII view (never loads the whole
  ROM), edit mode with a sparse overlay and full undo/redo, streaming
  byte/text search, bookmarks, jump-to-offset, save-as via SAF.
- **ROM Map**: pinch-to-zoom / pan / tap visual map of the ROM
  address space, color-coded by detected region type, tap-to-open
  the Hex Editor.
- **ROM Analyzer**: header / free-space / LZ77-compressed / pointer-
  table / ASCII-text detection, each region carries a confidence
  score; filterable by type; results are cached to disk by ROM hash.
- **Reports**: export the analysis as JSON, CSV, HTML, or Markdown.
- **Patch Tool**: create / apply / verify IPS patches end-to-end.
- **Pokémon Tables** (FireRed only): species base stats, moves, items,
  and trainers — including each trainer's full party, editable, not
  just displayed: species/level/item/moves edit in place, and adding
  or removing a Pokémon relocates the whole party to free space and
  repoints the trainer's own "Party Pointer"/"Party Size" fields (see
  `TrainerPartyWriter`). Item/Type/species/move fields edit through a
  searchable name picker rather than a raw ID. Search-by-name-or-#
  across every table. "Add new" claims one of a table's own
  genuinely-unused reserved slots for a new item/Pokémon/move — see
  `UnusedSlotDetector` — rather than attempting to expand or relocate
  the table. A move-animation preview driven by that move's real,
  ROM-read battle animation script (`BattleAnimationReader`) — real
  pointer, real bytes, a deterministic visualization derived from
  them (`MoveAnimationVisualizer`), and a raw hex view of the actual
  script; not a semantic decode of the animation bytecode itself,
  which this app doesn't have a verified opcode table for (see that
  class's doc for why, and pokescript's below for the different,
  fully-verified engine it's not to be confused with). Edits are
  saved via the same overlay/save-as mechanism as the Hex Editor
  (reachable from this screen too, not hex-editor-only), and persist
  as a draft (`EditDraftRepository`) across navigating away,
  backgrounding, or the process being killed, until exported or
  explicitly discarded.
- **Map Explorer** (FireRed only): every map in the ROM, found by
  walking the real map bank/group pointer table (`MapListReader`) —
  no hardcoded map count, because FireRed doesn't store one anywhere
  to hardcode. Each map renders from its own real tile graphics,
  palettes, and metatile layout (`MetatileRenderer`, built on the
  same GBA tile/palette decode the icon readers use), not a
  placeholder grid. Object (NPC/scripted-object), warp, trigger, and
  sign/hidden-item events all read from the ROM (`MapHeaderReader`);
  object and warp events are editable in place today (position,
  elevation, graphics, movement type, warp destination) — trigger and
  sign events are view-only for now (see Roadmap). Any object event
  with a real script pointer links straight into the Pokéscript
  viewer below.
- **Pokéscript**: a real disassembler/assembler for FireRed's field-
  script engine — the language every NPC/trigger/sign script in the
  game is written in. The opcode table (`ScriptCommandTable`) is
  copied from `pret/pokefirered`'s own compiled jump table, not a
  community transcription of it; argument layouts are only decoded
  for commands this app could independently verify (see that class's
  doc), and disassembly stops honestly rather than guess at the rest.
  Edited scripts reassemble back to bytes and write to a fresh block
  of free space, repointing whichever map event referenced them
  (`ScriptWriter`) — reached by tapping a script link in Map
  Explorer; opened without that context, the viewer is read-only.
- **ROM Expansion**: grows the ROM's file size, padded with 0xFF —
  free space every allocator in this app (pokescript, map events,
  trainer parties) can claim from immediately. Writes a new, larger
  file and switches to it; the original file is left untouched, same
  as every other "save" in this app.
- **Plugin architecture**: `RegionAnalyzer`, `GameAnalyzerPlugin`,
  `AnalyzerRegistry`, and `PatchFormat` are all designed so a new
  game-specific analyzer or patch format (UPS/BPS) is a new class +
  one registration line — nothing in `AnalysisEngine` or existing
  analyzers needs to change.

## Roadmap (not yet built — no placeholder screens for these)

Graphics/Palette/Text-explorer viewers, Pointer Explorer cross-
reference navigation, File Comparison, UPS/BPS patch formats, and
ARM/Thumb code disassembly-based detection are all designed for
(interfaces exist) but not implemented. The Tools screen lists them
as "Coming soon" rather than linking to half-built screens.

Also not yet built, all in service of the same "verified, not
guessed" bar as everything above:

- **Map Explorer**: adding/removing an object, warp, trigger, or
  sign event (as opposed to editing an existing one) — needs
  relocating the event array to free space and repointing the map's
  MapEvents struct, across four different event-struct shapes rather
  than the one `TrainerPartyWriter.resize` already handles. Trigger
  and sign events are readable today but not field-editable.
- **Pokéscript**: this app's disassembler is linear from one entry
  point (see `ScriptDisassembler`'s class doc) rather than following
  `goto`/`call` into the scripts they jump to; and a meaningful
  minority of real commands (`givemon`, most of `trainerbattle`'s
  less-common battle types, several decoration/contest/mart-specific
  commands) don't have a verified argument layout yet, so disassembly
  stops rather than guesses one — see `ScriptCommandTable`'s class
  doc for exactly which, and why.
- **Battle animation bytecode**: `MoveAnimationPreview` reads a
  move's real animation script pointer and bytes, but doesn't decode
  what the bytecode itself does — that's a different, much less
  publicly documented instruction set from the field-script engine
  Pokéscript decodes, and this app doesn't have a verified opcode
  table for it (see `BattleAnimationReader`'s class doc).

## Building

Push a zip of this project to wherever your existing `uploads/**`
build workflow watches for it — the workflow finds `settings.gradle.kts`
inside the archive automatically. No changes to that workflow are
needed; this project only needed a `gradlew`/`gradle-wrapper.properties`
that match what it already expects.
