package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.ByteArrayRomAccessor
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrainerPartyWriterTest {

    @Test
    fun `entrySize grows with held-item and custom-moveset flags`() {
        assertEquals(6, TrainerPartyWriter.entrySize(partyFlags = 0))
        assertEquals(8, TrainerPartyWriter.entrySize(partyFlags = 0x2)) // + held item
        assertEquals(14, TrainerPartyWriter.entrySize(partyFlags = 0x1)) // + custom moves
        assertEquals(16, TrainerPartyWriter.entrySize(partyFlags = 0x3)) // both
    }

    @Test
    fun `writeMember round trips through TrainerPartyReader for a full-shape party`() = runTest {
        val partyFlags = 0x3 // held item + custom moves
        val entrySize = TrainerPartyWriter.entrySize(partyFlags)
        val partyPointer = 0x100L
        val rom = ByteArrayRomAccessor(ByteArray((partyPointer + entrySize * 2).toInt()) { 0xFF.toByte() })
        val overlay = EditOverlay()

        val member = TrainerPartyMember(species = 25, level = 50, heldItem = 13, moves = listOf(1, 2, 3, 4))
        val ok = TrainerPartyWriter.writeMember(rom, overlay, partyPointer, partyFlags, memberIndex = 1, member)
        assertTrue(ok)

        val patchedBytes = overlay.applyTo(rom.read(0, rom.sizeBytes.toInt()))
        val readBack = TrainerPartyReader.read(ByteArrayRomAccessor(patchedBytes), partyFlags, partyPointer, partySize = 2)

        assertEquals(2, readBack.size)
        assertEquals(member, readBack[1])
    }

    @Test
    fun `writeMember leaves other slots untouched`() = runTest {
        val partyFlags = 0 // plain shape, 6 bytes/entry
        val entrySize = TrainerPartyWriter.entrySize(partyFlags)
        val partyPointer = 0L
        val rom = ByteArrayRomAccessor(ByteArray(entrySize * 3) { 0xFF.toByte() })
        val overlay = EditOverlay()

        TrainerPartyWriter.writeMember(rom, overlay, partyPointer, partyFlags, memberIndex = 0, TrainerPartyMember(1, 5, null, null))
        TrainerPartyWriter.writeMember(rom, overlay, partyPointer, partyFlags, memberIndex = 2, TrainerPartyMember(3, 15, null, null))

        val patchedBytes = overlay.applyTo(rom.read(0, rom.sizeBytes.toInt()))
        val readBack = TrainerPartyReader.read(ByteArrayRomAccessor(patchedBytes), partyFlags, partyPointer, partySize = 3)

        assertEquals(1, readBack[0].species)
        assertEquals(0xFFFF, readBack[1].species) // untouched slot still reads back as its original (unwritten) bytes
        assertEquals(3, readBack[2].species)
    }
}
