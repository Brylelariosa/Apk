package com.romexplorer.gba.ui.pokemontables

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.pokemon.FireRedTables
import com.romexplorer.gba.core.pokemon.PokemonTableReader
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.PokemonTable
import com.romexplorer.gba.data.repository.RomSession
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class PokemonTablesState {
    data object NotFireRed : PokemonTablesState()
    data object NoRomOpen : PokemonTablesState()
    data class Ready(val availableTables: List<KnownTableSchema>) : PokemonTablesState()
}

class PokemonTableViewModel(
    private val sessionManager: RomSessionManager,
) : ViewModel() {

    val uiState: StateFlow<PokemonTablesState> = sessionManager.session
        .map { toState(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), toState(sessionManager.session.value))

    private val _selectedTable = MutableStateFlow<PokemonTable?>(null)
    val selectedTable: StateFlow<PokemonTable?> = _selectedTable.asStateFlow()

    private val _isLoadingTable = MutableStateFlow(false)
    val isLoadingTable: StateFlow<Boolean> = _isLoadingTable.asStateFlow()

    private fun toState(session: RomSession?): PokemonTablesState = when {
        session == null -> PokemonTablesState.NoRomOpen
        session.header.gameCode != FireRedTables.EXPECTED_GAME_CODE -> PokemonTablesState.NotFireRed
        else -> PokemonTablesState.Ready(FireRedTables.all)
    }

    fun selectTable(schema: KnownTableSchema) {
        val accessor = sessionManager.session.value?.accessor ?: return
        viewModelScope.launch {
            _isLoadingTable.value = true
            _selectedTable.value = PokemonTableReader.read(accessor, schema)
            _isLoadingTable.value = false
        }
    }

    fun clearSelection() {
        _selectedTable.value = null
    }
}
