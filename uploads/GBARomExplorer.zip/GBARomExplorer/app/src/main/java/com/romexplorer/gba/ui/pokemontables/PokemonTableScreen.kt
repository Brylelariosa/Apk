@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.pokemontables

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.PokemonTable
import org.koin.androidx.compose.koinViewModel

@Composable
fun PokemonTableScreen(
    navController: NavHostController,
    viewModel: PokemonTableViewModel = koinViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    val selectedTable by viewModel.selectedTable.collectAsState()
    val isLoading by viewModel.isLoadingTable.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(selectedTable?.schema?.displayName ?: "Pokémon Tables") },
                navigationIcon = {
                    IconButton(onClick = {
                        if (selectedTable != null) viewModel.clearSelection() else navController.popBackStack()
                    }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when {
                isLoading -> CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                selectedTable != null -> TableGrid(selectedTable!!)
                uiState is PokemonTablesState.NoRomOpen -> CenteredMessage("Open a ROM first.")
                uiState is PokemonTablesState.NotFireRed -> CenteredMessage(
                    "These known tables are specific to Pokémon FireRed — this ROM isn't recognized as FireRed.",
                )
                uiState is PokemonTablesState.Ready -> TableList(
                    tables = (uiState as PokemonTablesState.Ready).availableTables,
                    onSelect = viewModel::selectTable,
                )
            }
        }
    }
}

@Composable
private fun CenteredMessage(text: String) {
    Box(modifier = Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text)
    }
}

@Composable
private fun TableList(tables: List<KnownTableSchema>, onSelect: (KnownTableSchema) -> Unit) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        items(tables) { schema ->
            Card(onClick = { onSelect(schema) }, modifier = Modifier.padding(vertical = 4.dp)) {
                ListItem(
                    headlineContent = { Text(schema.displayName) },
                    supportingContent = { Text("${schema.entryCount} entries · ${schema.fields.size} fields") },
                )
            }
        }
    }
}

/**
 * A basic spreadsheet-style grid: header row and body rows share one
 * horizontal scroll state so columns stay aligned while scrolling, and the
 * body scrolls vertically via LazyColumn for the (up to ~750) rows.
 */
@Composable
private fun TableGrid(table: PokemonTable) {
    val horizontalScroll = rememberScrollState()
    val columnWidth = 130.dp
    val indexColumnWidth = 56.dp

    Column(modifier = Modifier.fillMaxSize()) {
        Row(modifier = Modifier.horizontalScroll(horizontalScroll).padding(horizontal = 8.dp, vertical = 8.dp)) {
            HeaderCell("#", indexColumnWidth)
            table.schema.fields.forEach { field -> HeaderCell(field.name, columnWidth) }
        }
        HorizontalDivider()
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(table.rows) { row ->
                Row(modifier = Modifier.horizontalScroll(horizontalScroll).padding(horizontal = 8.dp, vertical = 6.dp)) {
                    BodyCell(row.index.toString(), indexColumnWidth)
                    table.schema.fields.forEach { field ->
                        BodyCell(row.values[field.name]?.toString() ?: "", columnWidth)
                    }
                }
                HorizontalDivider()
            }
        }
    }
}

@Composable
private fun HeaderCell(text: String, width: androidx.compose.ui.unit.Dp) {
    Text(text, modifier = Modifier.width(width).padding(horizontal = 4.dp), fontWeight = FontWeight.Bold)
}

@Composable
private fun BodyCell(text: String, width: androidx.compose.ui.unit.Dp) {
    Text(text, modifier = Modifier.width(width).padding(horizontal = 4.dp))
}
