package com.romexplorer.gba.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.romexplorer.gba.ui.analyzer.AnalyzerScreen
import com.romexplorer.gba.ui.hexeditor.HexEditorScreen
import com.romexplorer.gba.ui.home.HomeScreen
import com.romexplorer.gba.ui.home.ToolsScreen
import com.romexplorer.gba.ui.patch.PatchScreen
import com.romexplorer.gba.ui.rominfo.RomInfoScreen
import com.romexplorer.gba.ui.rommap.RomMapScreen

@Composable
fun GbaRomExplorerNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) {
            HomeScreen(navController)
        }
        composable(Screen.Tools.route) {
            ToolsScreen(navController)
        }
        composable(Screen.RomInfo.route) {
            RomInfoScreen(navController)
        }
        composable(Screen.HexEditor.route) {
            HexEditorScreen(navController)
        }
        composable(Screen.RomMap.route) {
            RomMapScreen(navController)
        }
        composable(Screen.Analyzer.route) {
            AnalyzerScreen(navController)
        }
        composable(Screen.Patch.route) {
            PatchScreen(navController)
        }
    }
}
