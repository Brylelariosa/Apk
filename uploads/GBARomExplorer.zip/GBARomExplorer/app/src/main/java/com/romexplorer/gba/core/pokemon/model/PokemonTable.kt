package com.romexplorer.gba.core.pokemon.model

import kotlinx.serialization.Serializable

/** How a [TableField]'s raw bytes should be interpreted. */
enum class FieldKind {
    UINT8,
    INT8, // two's-complement, e.g. move priority
    UINT16,
    UINT24, // e.g. LZ77-style 3-byte size fields
    UINT32,
    POINTER32, // u32 that's a ROM pointer (0x08000000-based); shown as a file offset
    POKEMON_STRING, // Gen III proprietary text encoding, terminated by 0xFF
}

/** One named field within a table entry's fixed-size struct. */
data class TableField(
    val name: String,
    val byteOffset: Int,
    val byteLength: Int,
    val kind: FieldKind,
)

/**
 * Describes a known, fixed-layout array of structs somewhere in the ROM —
 * e.g. Pokémon FireRed's species base stats table. [romOffset] and every
 * [TableField] here must come from a verified source (see FireRedTables.kt);
 * this schema is what turns a byte range into named columns instead of a
 * raw hex dump.
 */
data class KnownTableSchema(
    val id: String,
    val displayName: String,
    val romOffset: Long,
    val entrySize: Int,
    val entryCount: Int,
    val fields: List<TableField>,
) {
    val totalSizeBytes: Long get() = entrySize.toLong() * entryCount
}

/** One parsed row: field name -> decoded value (Long for numeric kinds, String for text). */
data class TableRow(
    val index: Int,
    val values: Map<String, Any>,
)

@Serializable
data class PokemonTableSummary(
    val tableId: String,
    val displayName: String,
    val romOffset: Long,
    val entryCount: Int,
)

data class PokemonTable(
    val schema: KnownTableSchema,
    val rows: List<TableRow>,
)
