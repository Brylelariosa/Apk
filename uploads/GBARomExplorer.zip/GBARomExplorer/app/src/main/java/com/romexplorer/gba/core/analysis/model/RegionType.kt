package com.romexplorer.gba.core.analysis.model

/**
 * Coarse classification for a byte range of the ROM. ARM_CODE, THUMB_CODE,
 * GRAPHICS, PALETTE, TILEMAP, and MUSIC are modeled now so the ROM map and
 * plugin system have stable types to target, but Phase 1 only ships
 * analyzers that populate HEADER, FREE_SPACE, COMPRESSED, POINTER_TABLE,
 * TEXT, and UNKNOWN — see AnalysisEngine roadmap notes.
 */
enum class RegionType(val displayName: String) {
    HEADER("Header"),
    ARM_CODE("ARM Code"),
    THUMB_CODE("Thumb Code"),
    GRAPHICS("Graphics"),
    PALETTE("Palette"),
    TILEMAP("Tilemap"),
    MUSIC("Music"),
    TEXT("Text"),
    POINTER_TABLE("Pointer Table"),
    COMPRESSED("Compressed Data"),
    FREE_SPACE("Free Space"),
    UNKNOWN("Unknown"),
}
