package com.romexplorer.gba.core.common

import com.romexplorer.gba.core.hex.EditOverlay
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Finds a run of free space — bytes already 0xFF, the conventional GBA
 * "unused ROM space" fill value (see
 * [com.romexplorer.gba.core.analysis.analyzers.FreeSpaceAnalyzer], which
 * treats the same value the same way) — large enough to hold newly-grown
 * data, so something that outgrows its original byte range (an edited
 * script, a resized event array, a trainer's resized party) can be
 * relocated instead of overflowing into whatever happens to sit right
 * after it in the ROM.
 *
 * Shared by every feature in this app that can grow ROM data —
 * [com.romexplorer.gba.core.pokescript], [com.romexplorer.gba.core.worldmap],
 * and [com.romexplorer.gba.core.pokemon.TrainerPartyWriter] — rather than
 * each reimplementing its own scan.
 *
 * Deliberately independent of [com.romexplorer.gba.core.analysis.AnalysisEngine]'s
 * full ROM-wide analysis, which is comparatively expensive (and analyzes
 * far more than free space) — this does a narrow, on-demand scan instead,
 * since these allocations happen one at a time as part of an interactive
 * edit, not as a batch analysis pass.
 */
object FreeSpaceAllocator {
    private const val FILL_BYTE = 0xFF
    private const val CHUNK_SIZE = 1 shl 14 // 16 KB per read, to bound memory use while scanning a large ROM

    /**
     * Scans from [searchStart] to the end of the ROM for the first run of
     * at least [length] consecutive free bytes, honoring [overlay] (a byte
     * already overwritten by a pending edit — even to another 0xFF — isn't
     * free) and [reservedRanges] (offsets a caller has already claimed
     * earlier in the same operation, before actually writing them via
     * [write]). Returns null if no run is found before the end of the ROM.
     */
    suspend fun findFreeRun(
        rom: RomAccessor,
        overlay: EditOverlay,
        length: Int,
        searchStart: Long = 0L,
        reservedRanges: List<LongRange> = emptyList(),
    ): Long? {
        if (length <= 0) return null
        var runStart = -1L
        var offset = searchStart.coerceAtLeast(0L)

        while (offset < rom.sizeBytes) {
            val readLen = minOf(CHUNK_SIZE.toLong(), rom.sizeBytes - offset).toInt()
            val chunk = rom.read(offset, readLen)
            if (chunk.isEmpty()) break
            for (i in chunk.indices) {
                val globalPos = offset + i
                val byteValue = overlay.get(globalPos) ?: (chunk[i].toInt() and 0xFF)
                val isFree = byteValue == FILL_BYTE && reservedRanges.none { globalPos in it }
                if (isFree) {
                    if (runStart == -1L) runStart = globalPos
                    if (globalPos - runStart + 1 >= length) return runStart
                } else {
                    runStart = -1L
                }
            }
            offset += readLen
        }
        return null
    }

    /**
     * Writes [bytes] into the overlay starting at [destination] — the
     * actual "claim" step after [findFreeRun]. Also the general-purpose way
     * every writer in this app touches more than one field at once: pass
     * any raw byte range, not just ones [findFreeRun] found.
     */
    suspend fun write(rom: RomAccessor, overlay: EditOverlay, destination: Long, bytes: ByteArray): Boolean {
        if (destination < 0 || destination + bytes.size > rom.sizeBytes) return false
        for (i in bytes.indices) {
            val byteOffset = destination + i
            val originalByte = rom.readByte(byteOffset)
            if (originalByte < 0) return false
            overlay.setByte(byteOffset, bytes[i].toInt() and 0xFF, originalByte)
        }
        return true
    }

    /** Little-endian encodes [value] into [length] bytes — the layout every pointer/number field in this ROM uses. */
    fun leBytes(value: Long, length: Int): ByteArray = ByteArray(length) { i -> ((value shr (8 * i)) and 0xFF).toByte() }

    /** Encodes a file offset as a raw 0x08000000-based GBA ROM pointer, the inverse of [com.romexplorer.gba.core.graphics.GbaGraphics.readPointer32]. */
    fun toRomPointer(fileOffset: Long): Long = fileOffset or 0x08000000L
}
