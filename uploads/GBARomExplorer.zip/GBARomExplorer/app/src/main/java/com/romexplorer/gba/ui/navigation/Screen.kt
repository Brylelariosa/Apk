package com.romexplorer.gba.ui.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object RomInfo : Screen("rom_info")
    data object HexEditor : Screen("hex_editor")
    data object RomMap : Screen("rom_map")
    data object Analyzer : Screen("analyzer")
    data object Patch : Screen("patch")
    data object Tools : Screen("tools")
}
