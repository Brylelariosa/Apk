package com.romexplorer.gba.ui.mapexplorer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.romexplorer.gba.core.graphics.DecodedImage
import com.romexplorer.gba.core.rom.RomAccessor
import com.romexplorer.gba.core.worldmap.MapEventWriter
import com.romexplorer.gba.core.worldmap.MapHeaderData
import com.romexplorer.gba.core.worldmap.MapHeaderReader
import com.romexplorer.gba.core.worldmap.MapListEntry
import com.romexplorer.gba.core.worldmap.MapListReader
import com.romexplorer.gba.core.worldmap.MetatileRenderer
import com.romexplorer.gba.core.worldmap.ObjectEventData
import com.romexplorer.gba.core.worldmap.WarpEventData
import com.romexplorer.gba.data.repository.RomSessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class MapListState {
    data object Loading : MapListState()
    data class Loaded(val maps: List<MapListEntry>) : MapListState()
    data class Failed(val message: String) : MapListState()
}

data class MapDetailState(
    val entry: MapListEntry,
    val header: MapHeaderData?,
    val image: DecodedImage?,
    val isLoading: Boolean,
)

/**
 * Backs [MapExplorerScreen] — the real map list ([MapListReader]), a
 * selected map's real header/events/rendered tiles ([MapHeaderReader],
 * [MetatileRenderer]), and the two event edits this app currently supports
 * ([MapEventWriter]).
 */
class MapExplorerViewModel(private val sessionManager: RomSessionManager) : ViewModel() {
    private val _mapList = MutableStateFlow<MapListState>(MapListState.Loading)
    val mapList: StateFlow<MapListState> = _mapList.asStateFlow()

    private val _detail = MutableStateFlow<MapDetailState?>(null)
    val detail: StateFlow<MapDetailState?> = _detail.asStateFlow()

    // Scanning the bank table is real work (up to MAX_MAP_GROUPS *
    // MAX_MAPS_PER_GROUP header-plausibility reads) - remember it per ROM
    // rather than rescanning every time the screen is reopened.
    private var listedForAccessor: RomAccessor? = null

    fun loadMapListIfNeeded() {
        val session = sessionManager.session.value ?: return
        if (listedForAccessor === session.accessor && _mapList.value is MapListState.Loaded) return
        _mapList.value = MapListState.Loading
        viewModelScope.launch {
            runCatching { MapListReader.listMaps(session.accessor) }
                .onSuccess {
                    listedForAccessor = session.accessor
                    _mapList.value = MapListState.Loaded(it)
                }
                .onFailure { _mapList.value = MapListState.Failed(it.message ?: "Couldn't read this ROM's map list") }
        }
    }

    fun selectMap(entry: MapListEntry) {
        val session = sessionManager.session.value ?: return
        _detail.value = MapDetailState(entry, header = null, image = null, isLoading = true)
        viewModelScope.launch {
            val header = MapHeaderReader.read(session.accessor, entry.id, entry.headerOffset)
            val image = header?.layout?.let { MetatileRenderer.renderMap(session.accessor, it) }
            // Only replace the state if the user hasn't already navigated
            // elsewhere while this map's tiles were still decoding.
            if (_detail.value?.entry == entry) _detail.value = MapDetailState(entry, header, image, isLoading = false)
        }
    }

    fun clearSelection() {
        _detail.value = null
    }

    fun editObjectEvent(event: ObjectEventData, x: Int, y: Int, elevation: Int, graphicsId: Int, movementType: Int) {
        val session = sessionManager.session.value ?: return
        val current = _detail.value ?: return
        viewModelScope.launch {
            val ok = MapEventWriter.writeObjectEvent(session.accessor, session.editOverlay, event, x, y, elevation, graphicsId, movementType)
            if (ok) {
                sessionManager.persistDraft()
                selectMap(current.entry)
            }
        }
    }

    fun editWarpEvent(
        event: WarpEventData,
        x: Int,
        y: Int,
        elevation: Int,
        warpId: Int,
        destinationMapNum: Int,
        destinationMapGroup: Int,
    ) {
        val session = sessionManager.session.value ?: return
        val current = _detail.value ?: return
        viewModelScope.launch {
            val ok = MapEventWriter.writeWarpEvent(
                session.accessor,
                session.editOverlay,
                event,
                x,
                y,
                elevation,
                warpId,
                destinationMapNum,
                destinationMapGroup,
            )
            if (ok) {
                sessionManager.persistDraft()
                selectMap(current.entry)
            }
        }
    }
}
