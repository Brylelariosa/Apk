package com.romexplorer.gba.core.analysis.analyzers

import com.romexplorer.gba.core.analysis.RegionAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.compression.Lz77Codec
import com.romexplorer.gba.core.compression.Lz77FormatException
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Scans for GBA LZ77 compressed blocks. Every word-aligned 0x10 byte is a
 * *candidate*; it's only promoted to a COMPRESSED region if the bytes that
 * follow actually decode as a complete, in-bounds LZ77 stream — this real
 * decode-and-verify step (rather than just checking the marker byte) is
 * what gives these detections a high confidence score.
 *
 * The word-aligned scan for that marker byte is done in memory, against a
 * reused chunk buffer filled via [RomAccessor.readInto] (the same pattern
 * [PointerTableAnalyzer] and [FreeSpaceAnalyzer] use), instead of calling
 * [RomAccessor.readByte] once per 4-byte step. A positional read per word
 * means a dispatcher hop plus a fresh allocation for every single word in
 * the ROM — millions of suspensions that dominate runtime long before any
 * candidate is ever found, since real LZ77 headers are rare. Only an actual
 * 0x10 hit triggers the real, larger ROM read needed for decode
 * verification, exactly as before.
 */
class Lz77BlockAnalyzer(
    private val maxDeclaredSize: Int = 8 * 1024 * 1024,
    private val chunkSize: Int = 1 shl 16, // 64KB, matches the other core analyzers
) : RegionAnalyzer {
    override val id: String = "lz77_blocks"

    override suspend fun analyze(rom: RomAccessor, onProgress: suspend (Float) -> Unit): List<RomRegion> {
        val regions = mutableListOf<RomRegion>()
        val romSize = rom.sizeBytes
        var lastClaimedEnd = -1L

        val buffer = ByteArray(chunkSize)
        var offset = 0L
        while (offset + 4 <= romSize) {
            // Word-align the chunk length so a marker byte and its 3-byte
            // size field are never split across two reads.
            val length = minOf(chunkSize.toLong(), romSize - offset).toInt().let { it - (it % 4) }
            if (length <= 0) break
            val available = rom.readInto(buffer, offset, length)
            if (available < 4) break

            var i = 0
            while (i + 4 <= available) {
                val globalOffset = offset + i
                if ((buffer[i].toInt() and 0xFF) == Lz77Codec.FORMAT_TAG && globalOffset >= lastClaimedEnd) {
                    val declaredSize = (buffer[i + 1].toInt() and 0xFF) or
                        ((buffer[i + 2].toInt() and 0xFF) shl 8) or
                        ((buffer[i + 3].toInt() and 0xFF) shl 16)

                    if (declaredSize in 1..maxDeclaredSize) {
                        // Compressed data is typically <= declared decompressed size;
                        // read a generous upper-bound window to attempt a decode.
                        val readLen = minOf((declaredSize + 4L), romSize - globalOffset).toInt()
                        val candidate = rom.read(globalOffset, readLen)
                        val result = runCatching { Lz77Codec.decompress(candidate) }
                        if (result.isSuccess && result.getOrNull()?.size == declaredSize) {
                            val end = globalOffset + estimateCompressedLength(candidate, declaredSize)
                            regions += RomRegion(
                                startOffset = globalOffset,
                                endOffsetExclusive = end,
                                type = RegionType.COMPRESSED,
                                confidence = 0.9f,
                                label = "LZ77 (${declaredSize} bytes decompressed)",
                            )
                            lastClaimedEnd = end
                        }
                    }
                }
                i += 4
            }

            offset += length
            onProgress((offset.toFloat() / romSize.toFloat()).coerceIn(0f, 1f))
        }
        return regions
    }

    /** Re-walks the flag/data stream just to find where the compressed bytes end,
     * without re-decoding output (we already know it's valid). */
    private fun estimateCompressedLength(candidate: ByteArray, declaredSize: Int): Long {
        var outPos = 0
        var inPos = 4
        try {
            while (outPos < declaredSize && inPos < candidate.size) {
                val flags = candidate[inPos++].toInt() and 0xFF
                for (bit in 7 downTo 0) {
                    if (outPos >= declaredSize) break
                    val isBackref = (flags shr bit) and 1 == 1
                    if (!isBackref) {
                        inPos += 1
                        outPos += 1
                    } else {
                        val b0 = candidate[inPos].toInt() and 0xFF
                        val length = ((b0 ushr 4) and 0x0F) + 3
                        inPos += 2
                        outPos += length
                    }
                }
            }
        } catch (_: Lz77FormatException) {
            // Shouldn't happen since decompress() already validated the stream.
        } catch (_: IndexOutOfBoundsException) {
            // Defensive: fall through and return what we have so far.
        }
        return inPos.toLong()
    }
}
