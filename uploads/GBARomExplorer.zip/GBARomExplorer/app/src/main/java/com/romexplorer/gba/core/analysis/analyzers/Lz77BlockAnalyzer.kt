package com.romexplorer.gba.core.analysis.analyzers

import com.romexplorer.gba.core.analysis.RegionAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.compression.Lz77Codec
import com.romexplorer.gba.core.compression.Lz77FormatException
import com.romexplorer.gba.core.rom.RomAccessor

/**
 * Scans for GBA LZ77 compressed blocks. Every word-aligned 0x10 byte is a
 * *candidate*; it's only promoted to a COMPRESSED region if the bytes that
 * follow actually decode as a complete, in-bounds LZ77 stream — this real
 * decode-and-verify step (rather than just checking the marker byte) is
 * what gives these detections a high confidence score.
 */
class Lz77BlockAnalyzer(
    private val maxDeclaredSize: Int = 8 * 1024 * 1024,
) : RegionAnalyzer {
    override val id: String = "lz77_blocks"

    override suspend fun analyze(rom: RomAccessor, onProgress: suspend (Float) -> Unit): List<RomRegion> {
        val regions = mutableListOf<RomRegion>()
        var offset = 0L
        var lastClaimedEnd = -1L

        while (offset + 4 <= rom.sizeBytes) {
            val marker = rom.readByte(offset)
            if (marker == Lz77Codec.FORMAT_TAG && offset >= lastClaimedEnd) {
                val header = rom.read(offset, 4)
                val declaredSize = (header[1].toInt() and 0xFF) or
                    ((header[2].toInt() and 0xFF) shl 8) or
                    ((header[3].toInt() and 0xFF) shl 16)

                if (declaredSize in 1..maxDeclaredSize) {
                    // Compressed data is typically <= declared decompressed size;
                    // read a generous upper-bound window to attempt a decode.
                    val readLen = minOf((declaredSize + 4L), rom.sizeBytes - offset).toInt()
                    val candidate = rom.read(offset, readLen)
                    val result = runCatching { Lz77Codec.decompress(candidate) }
                    if (result.isSuccess && result.getOrNull()?.size == declaredSize) {
                        val end = offset + estimateCompressedLength(candidate, declaredSize)
                        regions += RomRegion(
                            startOffset = offset,
                            endOffsetExclusive = end,
                            type = RegionType.COMPRESSED,
                            confidence = 0.9f,
                            label = "LZ77 (${declaredSize} bytes decompressed)",
                        )
                        lastClaimedEnd = end
                    }
                }
            }
            offset += 4
            if (offset % (1 shl 16) == 0L) {
                onProgress((offset.toFloat() / rom.sizeBytes.toFloat()).coerceIn(0f, 1f))
            }
        }
        return regions
    }

    /** Re-walks the flag/data stream just to find where the compressed bytes end,
     * without re-decoding output (we already know it's valid). */
    private fun estimateCompressedLength(candidate: ByteArray, declaredSize: Int): Long {
        var outPos = 0
        var inPos = 4
        try {
            while (outPos < declaredSize && inPos < candidate.size) {
                val flags = candidate[inPos++].toInt() and 0xFF
                for (bit in 7 downTo 0) {
                    if (outPos >= declaredSize) break
                    val isBackref = (flags shr bit) and 1 == 1
                    if (!isBackref) {
                        inPos += 1
                        outPos += 1
                    } else {
                        val b0 = candidate[inPos].toInt() and 0xFF
                        val length = ((b0 ushr 4) and 0x0F) + 3
                        inPos += 2
                        outPos += length
                    }
                }
            }
        } catch (_: Lz77FormatException) {
            // Shouldn't happen since decompress() already validated the stream.
        } catch (_: IndexOutOfBoundsException) {
            // Defensive: fall through and return what we have so far.
        }
        return inPos.toLong()
    }
}
