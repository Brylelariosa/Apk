@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.romexplorer.gba.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.romexplorer.gba.ui.navigation.Screen

private data class ToolEntry(
    val title: String,
    val subtitle: String,
    val route: String?, // null = not implemented yet
)

private val tools = listOf(
    ToolEntry("Hex Editor", "View and edit raw ROM bytes", Screen.HexEditor.route),
    ToolEntry("ROM Map", "Visual overview of ROM contents", Screen.RomMap.route),
    ToolEntry("ROM Analyzer", "Detect regions, free space, tables", Screen.Analyzer.route),
    ToolEntry("Patch Tool", "Create, apply, and verify IPS patches", Screen.Patch.route),
    ToolEntry("Graphics Viewer", "Coming soon", null),
    ToolEntry("Palette Viewer", "Coming soon", null),
    ToolEntry("Text Explorer", "Coming soon", null),
    ToolEntry("Pointer Explorer", "Coming soon", null),
    ToolEntry("File Comparison", "Coming soon", null),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsScreen(navController: NavHostController) {
    Scaffold(topBar = { TopAppBar(title = { Text("Tools") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(tools) { tool ->
                val implemented = tool.route != null
                Card(
                    modifier = Modifier,
                    enabled = implemented,
                    onClick = { tool.route?.let { navController.navigate(it) } },
                ) {
                    ListItem(
                        headlineContent = { Text(tool.title) },
                        supportingContent = {
                            Text(if (implemented) tool.subtitle else "Coming soon")
                        },
                    )
                }
            }
        }
    }
}
