package com.romexplorer.gba.core.analysis

import com.romexplorer.gba.core.analysis.analyzers.FreeSpaceAnalyzer
import com.romexplorer.gba.core.analysis.analyzers.HeaderRegionAnalyzer
import com.romexplorer.gba.core.analysis.analyzers.Lz77BlockAnalyzer
import com.romexplorer.gba.core.analysis.analyzers.PointerTableAnalyzer
import com.romexplorer.gba.core.analysis.analyzers.TextRegionAnalyzer
import com.romexplorer.gba.core.analysis.model.RegionType
import com.romexplorer.gba.core.analysis.model.RomMap
import com.romexplorer.gba.core.analysis.model.RomRegion
import com.romexplorer.gba.core.rom.RomAccessor
import kotlinx.coroutines.flow.flow

sealed class AnalysisProgress {
    data class InProgress(val fraction: Float, val currentAnalyzer: String) : AnalysisProgress()
    data class Done(val map: RomMap) : AnalysisProgress()
}

/**
 * Orchestrates every registered [RegionAnalyzer] over a ROM, merges their
 * output into one non-overlapping [RomMap], and fills any remaining gaps
 * with UNKNOWN regions. Adding a new analyzer (core or plugin-contributed)
 * never requires changing this class — it only depends on the
 * [RegionAnalyzer] interface.
 *
 * Overlap resolution: when two analyzers claim overlapping bytes, the
 * earlier entry in [priorityOrder] wins for the overlapping portion. This
 * matters because, e.g., the header analyzer and a coincidental pointer-table
 * false-positive could both claim the same bytes — HEADER should always win.
 */
class AnalysisEngine(
    private val registry: AnalyzerRegistry = AnalyzerRegistry(),
    private val coreAnalyzers: List<RegionAnalyzer> = listOf(
        HeaderRegionAnalyzer(),
        PointerTableAnalyzer(),
        Lz77BlockAnalyzer(),
        TextRegionAnalyzer(),
        FreeSpaceAnalyzer(),
    ),
) {
    private val priorityOrder = listOf(
        RegionType.HEADER,
        RegionType.POINTER_TABLE,
        RegionType.COMPRESSED,
        RegionType.TEXT,
        RegionType.FREE_SPACE,
        RegionType.GRAPHICS,
        RegionType.PALETTE,
        RegionType.TILEMAP,
        RegionType.MUSIC,
        RegionType.ARM_CODE,
        RegionType.THUMB_CODE,
        RegionType.UNKNOWN,
    )

    fun analyze(rom: RomAccessor, gameCode: String) = flow {
        val analyzers = coreAnalyzers + registry.analyzersForGameCode(gameCode)
        val allRegions = mutableListOf<RomRegion>()

        analyzers.forEachIndexed { index, analyzer ->
            val regions = analyzer.analyze(rom) { fraction ->
                val overall = (index + fraction) / analyzers.size
                emit(AnalysisProgress.InProgress(overall, analyzer.id))
            }
            allRegions += regions
        }

        val merged = mergeAndFillGaps(allRegions, rom.sizeBytes)
        emit(AnalysisProgress.Done(RomMap(rom.sizeBytes, merged)))
    }

    private fun mergeAndFillGaps(regions: List<RomRegion>, romSize: Long): List<RomRegion> {
        if (romSize <= 0) return emptyList()

        // Byte-ownership array would be too costly for 64MB; instead resolve
        // overlaps by sorting candidate regions by priority then sweeping to
        // claim non-overlapping spans in priority order.
        val sorted = regions.sortedBy { priorityOrder.indexOf(it.type) }
        val claimed = sortedSetOfRanges()

        val result = mutableListOf<RomRegion>()
        for (region in sorted) {
            val free = claimed.subtractFrom(region.startOffset, region.endOffsetExclusive)
            for ((start, end) in free) {
                if (end > start) {
                    result += region.copy(startOffset = start, endOffsetExclusive = end)
                    claimed.add(start, end)
                }
            }
        }

        // Fill any bytes nothing claimed as UNKNOWN.
        result += claimed.gapsIn(0L, romSize).map { (start, end) ->
            RomRegion(start, end, RegionType.UNKNOWN, confidence = 0f)
        }

        return result.sortedBy { it.startOffset }
    }

    /** Minimal non-overlapping interval tracker used only during merge. */
    private fun sortedSetOfRanges() = ClaimedRanges()

    private class ClaimedRanges {
        // Kept sorted by start offset; invariant: no two entries overlap or touch.
        private val ranges = mutableListOf<LongRange>()

        fun add(start: Long, end: Long) {
            ranges += start until end
            ranges.sortBy { it.first }
        }

        /** Returns the sub-spans of [start, end) not yet claimed. */
        fun subtractFrom(start: Long, end: Long): List<Pair<Long, Long>> {
            var cursor = start
            val gaps = mutableListOf<Pair<Long, Long>>()
            for (r in ranges) {
                if (r.last < cursor) continue
                if (r.first >= end) break
                if (r.first > cursor) gaps += cursor to minOf(r.first.toLong(), end)
                cursor = maxOf(cursor, r.last + 1)
                if (cursor >= end) break
            }
            if (cursor < end) gaps += cursor to end
            return gaps
        }

        fun gapsIn(start: Long, end: Long): List<Pair<Long, Long>> = subtractFrom(start, end)
    }
}
