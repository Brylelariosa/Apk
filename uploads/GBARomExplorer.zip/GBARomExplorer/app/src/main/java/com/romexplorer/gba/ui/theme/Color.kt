package com.romexplorer.gba.ui.theme

import androidx.compose.ui.graphics.Color

// Core brand hues used across both light and dark schemes.
val Purple40 = Color(0xFF6A4FC0)
val Purple80 = Color(0xFFCFC2F0)
val PurpleGrey40 = Color(0xFF5F5768)
val PurpleGrey80 = Color(0xFFD2C6DE)
val Accent40 = Color(0xFF7C4DFF)
val Accent80 = Color(0xFFB388FF)

// Region-type colors used consistently across the ROM Map and Analyzer screens.
val RegionHeader = Color(0xFF4CAF50)
val RegionArmCode = Color(0xFFEF5350)
val RegionThumbCode = Color(0xFFFF8A65)
val RegionGraphics = Color(0xFF29B6F6)
val RegionPalette = Color(0xFF26C6DA)
val RegionTilemap = Color(0xFF5C6BC0)
val RegionMusic = Color(0xFFAB47BC)
val RegionText = Color(0xFFFFCA28)
val RegionPointerTable = Color(0xFF7C4DFF)
val RegionCompressed = Color(0xFFEC407A)
val RegionFreeSpace = Color(0xFF757575)
val RegionUnknown = Color(0xFF37474F)
