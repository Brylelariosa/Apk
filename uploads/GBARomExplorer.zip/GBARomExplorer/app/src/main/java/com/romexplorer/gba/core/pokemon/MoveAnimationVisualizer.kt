package com.romexplorer.gba.core.pokemon

/**
 * Visual parameters for [com.romexplorer.gba.ui.pokemontables.MoveAnimationDialog]'s
 * stylized preview — every value here is a pure function of a specific
 * move's real, ROM-read [BattleAnimationScript] bytes, not a random or
 * generic effect. Two moves with different real scripts get different
 * previews; the same ROM always produces the same preview for the same
 * move. Pure and Android-free by design, so it's unit-testable without a
 * ROM — same idea as [TrainerPartyFormatter].
 *
 * This is explicitly NOT a decode of what the script's bytecode *means* —
 * see [BattleAnimationReader]'s class doc for why that's out of scope for
 * this app. Think of it more like a deterministic fingerprint: real bytes
 * in, real (reproducible, non-random) visuals out — a genuine improvement
 * over a preview with no connection to the ROM at all, short of a full
 * bytecode interpreter this app can't verify it has right.
 */
data class AnimationVisualParams(
    val particleCount: Int,
    val durationMs: Int,
    val angleSeedsDegrees: List<Int>,
    val scriptByteCount: Int,
)

object MoveAnimationVisualizer {
    private const val MIN_PARTICLES = 6
    private const val MAX_PARTICLES = 20
    private const val BASE_DURATION_MS = 700
    private const val DURATION_JITTER_MS = 900

    fun derive(script: BattleAnimationScript?, movePower: Int): AnimationVisualParams {
        val bytes = script?.bytes
        if (bytes.isNullOrEmpty()) {
            // No readable script for this move in this ROM — a plain,
            // minimal pulse rather than inventing script data that isn't
            // actually there.
            return AnimationVisualParams(
                particleCount = MIN_PARTICLES,
                durationMs = BASE_DURATION_MS + 200,
                angleSeedsDegrees = List(MIN_PARTICLES) { it * (360 / MIN_PARTICLES) },
                scriptByteCount = 0,
            )
        }

        val distinctBytes = bytes.toSet().size
        val particleCount = (MIN_PARTICLES + distinctBytes / 3).coerceIn(MIN_PARTICLES, MAX_PARTICLES)
        val checksum = bytes.fold(0) { acc, b -> (acc * 31 + (b.toInt() and 0xFF)) and 0xFFFF }
        val durationMs = BASE_DURATION_MS + (checksum % DURATION_JITTER_MS) + movePower.coerceIn(0, 250)
        val angleSeeds = (0 until particleCount).map { i ->
            val byte = bytes[i % bytes.size].toInt() and 0xFF
            (byte * 360 / 256 + i * (360 / particleCount)) % 360
        }
        return AnimationVisualParams(particleCount, durationMs, angleSeeds, bytes.size)
    }
}
