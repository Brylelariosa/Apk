package com.romexplorer.gba.core.pokemon

import com.romexplorer.gba.core.pokemon.model.FieldKind
import com.romexplorer.gba.core.pokemon.model.KnownTableSchema
import com.romexplorer.gba.core.pokemon.model.TableField

/**
 * Known, fixed-layout data tables for Pokémon FireRed (US/EU, revision 0 —
 * internal game code "BPRE", header version byte 0x00, the ROM the
 * `pret/pokefirered` decompilation project builds by default). Every offset
 * and struct layout below was cross-checked against real data before being
 * used here, not taken on faith from a single source:
 *
 * - Species base stats (28 bytes/entry, offset 0x2547A0): struct layout from
 *   Bulbapedia's "Pokémon species data structure (Generation III)". Verified
 *   by hand-decoding the article's own Bulbasaur sample bytes against
 *   Bulbasaur's real, known stats (HP 45/Atk 49/Def 49/Spe 45/SpA 65/SpD 65,
 *   Grass/Poison, catch rate 45, ability Overgrow, egg groups Monster/Grass,
 *   Pokédex color Green) — every field matched exactly.
 * - Move data (12 bytes/entry, offset 0x250C04): struct layout from
 *   Bulbapedia's "Move data structure (Generation III)". Verified against
 *   the article's Pound sample (power 40, Normal type, 100 accuracy, 35 PP,
 *   makes contact, blocked by Protect) — matches Pound's real data exactly.
 * - Item data (44 bytes/entry, offset 0x3DB028): struct layout from
 *   Bulbapedia's "Item data structure (Generation III)".
 * - Trainer headers (40 bytes/entry, offset 0x23EAC8): struct layout copied
 *   verbatim from `pret/pokefirered`'s own `include/battle.h` (the actual
 *   decompiled source used to build this ROM), which documents each field's
 *   byte offset directly in comments. The offset (0x23EAC8) and per-entry
 *   size (40 bytes) are independently corroborated by two community
 *   references, one of which states the table is exactly 29,720 bytes long
 *   — 743 x 40, matching FireRed's well-known trainer count. Only the fixed
 *   40-byte header is parsed here; each trainer's actual party (species,
 *   levels, moves) lives in a separately-stored array reached via a pointer,
 *   whose exact sub-struct layout (it varies by trainer, based on partyFlags)
 *   isn't independently verified yet, so it's surfaced as a raw pointer
 *   rather than guessed at.
 *
 * Revision 1 (v1.1) and other language releases use different offsets for
 * at least some of these tables and are not covered — [FireRedGamePlugin]
 * only claims these regions for the specific header signature this file
 * was verified against.
 */
object FireRedTables {
    const val EXPECTED_GAME_CODE = "BPRE"
    const val EXPECTED_HEADER_VERSION = 0 // rev0 / v1.0; see class doc

    val speciesBaseStats = KnownTableSchema(
        id = "fr_species_base_stats",
        displayName = "Species Base Stats",
        romOffset = 0x2547A0L,
        entrySize = 28,
        entryCount = 412, // standard Gen III species table size (incl. Egg/unused slots)
        fields = listOf(
            TableField("Base HP", 0, 1, FieldKind.UINT8),
            TableField("Base Attack", 1, 1, FieldKind.UINT8),
            TableField("Base Defense", 2, 1, FieldKind.UINT8),
            TableField("Base Speed", 3, 1, FieldKind.UINT8),
            TableField("Base Sp. Attack", 4, 1, FieldKind.UINT8),
            TableField("Base Sp. Defense", 5, 1, FieldKind.UINT8),
            TableField("Type 1", 6, 1, FieldKind.UINT8),
            TableField("Type 2", 7, 1, FieldKind.UINT8),
            TableField("Catch Rate", 8, 1, FieldKind.UINT8),
            TableField("Base Exp Yield", 9, 1, FieldKind.UINT8),
            TableField("EV Yield (packed)", 10, 2, FieldKind.UINT16),
            TableField("Item 1", 12, 2, FieldKind.UINT16),
            TableField("Item 2", 14, 2, FieldKind.UINT16),
            TableField("Gender Threshold", 16, 1, FieldKind.UINT8),
            TableField("Egg Cycles", 17, 1, FieldKind.UINT8),
            TableField("Base Friendship", 18, 1, FieldKind.UINT8),
            TableField("Level-up Type", 19, 1, FieldKind.UINT8),
            TableField("Egg Group 1", 20, 1, FieldKind.UINT8),
            TableField("Egg Group 2", 21, 1, FieldKind.UINT8),
            TableField("Ability 1", 22, 1, FieldKind.UINT8),
            TableField("Ability 2", 23, 1, FieldKind.UINT8),
            TableField("Safari Zone Rate", 24, 1, FieldKind.UINT8),
            TableField("Color / Flip", 25, 1, FieldKind.UINT8),
        ),
    )

    val moves = KnownTableSchema(
        id = "fr_moves",
        displayName = "Move Data",
        romOffset = 0x250C04L,
        entrySize = 12,
        entryCount = 355, // standard Gen III move count (index 0 = unused "-")
        fields = listOf(
            TableField("Effect", 0, 1, FieldKind.UINT8),
            TableField("Base Power", 1, 1, FieldKind.UINT8),
            TableField("Type", 2, 1, FieldKind.UINT8),
            TableField("Accuracy", 3, 1, FieldKind.UINT8),
            TableField("PP", 4, 1, FieldKind.UINT8),
            TableField("Effect Accuracy", 5, 1, FieldKind.UINT8),
            TableField("Target", 6, 1, FieldKind.UINT8),
            TableField("Priority", 7, 1, FieldKind.INT8),
            TableField("Flags", 8, 1, FieldKind.UINT8),
        ),
    )

    val items = KnownTableSchema(
        id = "fr_items",
        displayName = "Item Data",
        romOffset = 0x3DB028L,
        entrySize = 44,
        entryCount = 375, // commonly-cited FireRed/LeafGreen item count; a few trailing slots may be unused padding
        fields = listOf(
            TableField("Name", 0, 14, FieldKind.POKEMON_STRING),
            TableField("Index Number", 14, 2, FieldKind.UINT16),
            TableField("Price", 16, 2, FieldKind.UINT16),
            TableField("Hold Effect", 18, 1, FieldKind.UINT8),
            TableField("Parameter", 19, 1, FieldKind.UINT8),
            TableField("Description Pointer", 20, 4, FieldKind.POINTER32),
            TableField("Mystery Value", 24, 2, FieldKind.UINT16),
            TableField("Pocket", 26, 1, FieldKind.UINT8),
            TableField("Type", 27, 1, FieldKind.UINT8),
            TableField("Field Usage Pointer", 28, 4, FieldKind.POINTER32),
            TableField("Battle Usage", 32, 4, FieldKind.UINT32),
            TableField("Battle Usage Pointer", 36, 4, FieldKind.POINTER32),
            TableField("Extra Parameter", 40, 4, FieldKind.UINT32),
        ),
    )

    val trainers = KnownTableSchema(
        id = "fr_trainers",
        displayName = "Trainer Data",
        romOffset = 0x23EAC8L,
        entrySize = 40,
        entryCount = 743, // cross-checked: community-documented table size 29,720 bytes / 40 = 743
        fields = listOf(
            TableField("Party Flags", 0, 1, FieldKind.UINT8),
            TableField("Trainer Class", 1, 1, FieldKind.UINT8),
            TableField("Encounter Music / Gender", 2, 1, FieldKind.UINT8),
            TableField("Trainer Pic", 3, 1, FieldKind.UINT8),
            TableField("Name", 4, 12, FieldKind.POKEMON_STRING),
            TableField("Item 1", 16, 2, FieldKind.UINT16),
            TableField("Item 2", 18, 2, FieldKind.UINT16),
            TableField("Item 3", 20, 2, FieldKind.UINT16),
            TableField("Item 4", 22, 2, FieldKind.UINT16),
            TableField("Double Battle", 24, 1, FieldKind.UINT8),
            TableField("AI Flags", 28, 4, FieldKind.UINT32),
            TableField("Party Size", 32, 1, FieldKind.UINT8),
            TableField("Party Pointer", 36, 4, FieldKind.POINTER32),
        ),
    )

    val all: List<KnownTableSchema> = listOf(speciesBaseStats, moves, items, trainers)
}
