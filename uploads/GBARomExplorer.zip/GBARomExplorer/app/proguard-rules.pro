# Kept minimal: release builds run with minification disabled for now
# (see build.gradle.kts) since this project is built and shipped entirely
# via CI without an attached device to verify R8-stripped release builds.
# Re-enable isMinifyEnabled once release builds can be smoke-tested.
