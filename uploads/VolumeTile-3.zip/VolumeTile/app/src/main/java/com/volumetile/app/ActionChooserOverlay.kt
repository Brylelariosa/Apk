package com.volumetile.app

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView

/**
 * The "what do you want to do?" panel opened by the navigation-bar accessibility button
 * and by a tap on the floating bubble. It is kept small - a narrow card with one compact
 * row per action - so it hides as little of the app underneath as possible.
 *
 * It is a window of type TYPE_ACCESSIBILITY_OVERLAY, not an activity, on purpose: an
 * activity would take over the screen and push the foreground app (a game, say) into
 * the background, while an overlay leaves it running underneath. Only an accessibility
 * service may add that window type, and it needs no extra permission.
 *
 * The window is not focusable, so a game keeps its input focus - which also means there
 * is no Back key for the panel. It closes on a tap outside the card, on Cancel, on a
 * pick, and by itself after [AUTO_DISMISS_MS] in case the screen was switched off. It
 * fades and scales in; it goes away at once, so whatever is picked can act on a clean screen.
 *
 * @param service the accessibility service. Its own WindowManager must be used: only that
 *   one carries the token allowed to add overlay windows.
 * @param isActive whether an action is switched on right now, for the entries that are
 *   toggles (Floating): those rows show an "On" tag.
 * @param onPick called after the panel has been removed, with the action that was chosen.
 */
class ActionChooserOverlay(
    private val service: Context,
    private val isActive: (SystemAction) -> Boolean,
    private val onPick: (SystemAction) -> Unit
) {

    private val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val autoDismiss = Runnable { dismiss() }

    private var panel: View? = null

    val isShowing: Boolean
        get() = panel != null

    fun toggle(actions: List<SystemAction>) {
        if (isShowing) dismiss() else show(actions)
    }

    fun show(actions: List<SystemAction>) {
        if (isShowing || actions.isEmpty()) return
        val view = try {
            buildPanel(actions).also { windowManager.addView(it, windowParams()) }
        } catch (e: RuntimeException) {
            // Either the layout couldn't be inflated, or the system refused the window
            // (BadTokenException, e.g. while the service is being torn down). Nothing was
            // added, so nothing to clean up - and nothing may escape: this runs inside the
            // accessibility service's process.
            service.toast(R.string.toast_action_failed)
            return
        }
        panel = view
        animateIn(view)
        handler.postDelayed(autoDismiss, AUTO_DISMISS_MS)
    }

    fun dismiss() {
        val view = panel ?: return
        panel = null
        handler.removeCallbacks(autoDismiss)
        try {
            windowManager.removeView(view)
        } catch (e: RuntimeException) {
            // Already gone - the system drops overlay windows when a service stops.
        }
    }

    private fun buildPanel(actions: List<SystemAction>): View {
        // A service context carries no app theme. Borrow the app's so CardView and the text
        // colours follow light/dark mode like the rest of the app.
        val themed = ContextThemeWrapper(service, R.style.Theme_VolumeApp)
        val inflater = LayoutInflater.from(themed)

        val root = inflater.inflate(R.layout.overlay_action_chooser, null)
        // Start invisible and a little small; animateIn() brings the panel up once it is on screen.
        root.alpha = 0f
        root.findViewById<View>(R.id.chooserCard).apply {
            scaleX = ENTER_SCALE
            scaleY = ENTER_SCALE
        }
        root.setOnClickListener { dismiss() } // the dimmed backdrop: a tap outside the card
        root.findViewById<View>(R.id.chooserCancel).setOnClickListener { dismiss() }

        val list = root.findViewById<ViewGroup>(R.id.chooserList)
        actions.forEach { action -> list.addView(buildRow(inflater, list, action)) }
        return root
    }

    private fun buildRow(inflater: LayoutInflater, parent: ViewGroup, action: SystemAction): View {
        val row = inflater.inflate(R.layout.item_action_choice, parent, false)
        row.findViewById<ImageView>(R.id.actionIcon).setImageResource(action.iconRes)
        row.findViewById<TextView>(R.id.actionLabel).setText(action.labelRes)
        val active = isActive(action)
        row.findViewById<View>(R.id.actionState).visibility = if (active) View.VISIBLE else View.GONE
        // The rows are compact, so the one-line hint isn't drawn; screen readers still get it.
        row.contentDescription = buildString {
            append(service.getString(action.labelRes))
            if (active) append(", ").append(service.getString(R.string.state_on))
            append(", ").append(service.getString(action.hintRes))
        }
        row.setOnClickListener {
            dismiss()
            onPick(action)
        }
        return row
    }

    /** The backdrop fades up while the card grows into place. */
    private fun animateIn(root: View) {
        root.animate().alpha(1f).setDuration(ENTER_MS).start()
        root.findViewById<View>(R.id.chooserCard).animate()
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(ENTER_MS)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }

    private fun windowParams() = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        // Without this the backdrop stops short of a notch/punch-hole in landscape.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private companion object {
        /** Safety net so a forgotten panel doesn't sit over the next app for ever. */
        const val AUTO_DISMISS_MS = 15_000L

        /** The panel's entrance: how long it takes, and how small the card starts. */
        const val ENTER_MS = 170L
        const val ENTER_SCALE = 0.9f
    }
}
