package com.volumetile.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log

/**
 * Stops Android from cleaning up the accessibility service while the phone sits idle.
 *
 * A background process is fair game for the system's memory killer and for the phone
 * maker's "battery saver" / "memory cleaner" - and when one of them takes the process
 * out, the accessibility service can be left switched on in Settings but no longer
 * running: the nav-bar button and the tiles then do nothing until the switch is flipped
 * off and on again. A process that hosts a foreground service is left alone by all of
 * them.
 *
 * This costs next to nothing: no timers, no wake-ups, no polling, no wake lock. The only
 * thing it adds is one silent, lock-screen-hidden notification (minimum importance, so no
 * status-bar icon, no sound). The service takes itself into the foreground - there is no
 * second service - and the person can switch it off with a checkbox in the app.
 */
object KeepAlive {

    private const val TAG = "KeepAlive"
    private const val PREFS = "keep_alive"
    private const val KEY_ENABLED = "enabled"
    private const val CHANNEL_ID = "keep_alive"
    private const val NOTIFICATION_ID = 1

    /** On by default: the whole point is that the person never has to think about it. */
    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }

    /** Puts [service] in the foreground, or takes it out again, to match the saved setting. */
    fun sync(service: Service) {
        if (isEnabled(service)) start(service) else stop(service)
    }

    fun stop(service: Service) {
        try {
            service.stopForeground(Service.STOP_FOREGROUND_REMOVE)
        } catch (e: RuntimeException) {
            Log.w(TAG, "Could not leave the foreground", e)
        }
    }

    private fun start(service: Service) {
        try {
            // The channel has to exist before startForeground(): a notification on an
            // unknown channel is rejected after the call returns, and that rejection is a
            // crash of the whole process, which is exactly what this class exists to avoid.
            createChannel(service)
            val notification = buildNotification(service)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                service.startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                service.startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: RuntimeException) {
            // Newer Android versions can refuse a foreground start. Not fatal: the service
            // simply runs as before, without the extra protection.
            Log.w(TAG, "Could not enter the foreground", e)
        }
    }

    private fun createChannel(context: Context) {
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.keep_alive_channel),
            NotificationManager.IMPORTANCE_MIN
        ).apply {
            setShowBadge(false)
        }
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(context: Context): Notification {
        val openApp = PendingIntent.getActivity(
            context,
            0,
            Intent(context, VolumeControlActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_volume)
            .setContentTitle(context.getString(R.string.keep_alive_title))
            .setContentText(context.getString(R.string.keep_alive_text))
            .setContentIntent(openApp)
            .setOngoing(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setVisibility(Notification.VISIBILITY_SECRET)
            .build()
    }
}
