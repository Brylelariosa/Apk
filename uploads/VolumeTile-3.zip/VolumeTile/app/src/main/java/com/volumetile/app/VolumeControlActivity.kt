package com.volumetile.app

import android.annotation.SuppressLint
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/**
 * Shows adjustable sliders for Media, Ring, Notification and Alarm volume.
 * Reused two ways (see AndroidManifest): as the full-screen launcher activity,
 * and as a small floating dialog opened from the Quick Settings tile.
 *
 * Also the place that keeps the accessibility service healthy: it shows when the service
 * is off or has been stopped by the system, offers the battery-optimisation exemption, and
 * holds the checkbox for [KeepAlive] and the switch (plus the pickers for the icons of its
 * arc) for the floating bubble.
 */
class VolumeControlActivity : AppCompatActivity() {

    private lateinit var audioManager: AudioManager
    private lateinit var rows: List<StreamRow>
    private lateinit var bubbleSwitch: SwitchCompat
    private lateinit var bubbleOptions: View

    private val bubbleToggleListener = CompoundButton.OnCheckedChangeListener { _, checked ->
        onBubbleToggled(checked)
    }

    private val handler = Handler(Looper.getMainLooper())

    /**
     * Re-checks the service while it is switched on but not yet connected, so the banner
     * appears if it never comes up and vanishes as soon as it does. Stops by itself once
     * the answer can no longer change, and while the screen isn't showing.
     */
    private val watchService = object : Runnable {
        override fun run() {
            if (updateAccessibilityBanner()) handler.postDelayed(this, SERVICE_RECHECK_MS)
        }
    }

    private data class StreamRow(
        val stream: Int,
        val seekBar: SeekBar,
        val valueText: TextView
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_volume_control)

        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager

        rows = listOf(
            StreamRow(AudioManager.STREAM_MUSIC, findViewById(R.id.seekMedia), findViewById(R.id.valueMedia)),
            StreamRow(AudioManager.STREAM_RING, findViewById(R.id.seekRing), findViewById(R.id.valueRing)),
            StreamRow(
                AudioManager.STREAM_NOTIFICATION,
                findViewById(R.id.seekNotification),
                findViewById(R.id.valueNotification)
            ),
            StreamRow(AudioManager.STREAM_ALARM, findViewById(R.id.seekAlarm), findViewById(R.id.valueAlarm))
        )

        rows.forEach(::setupRow)

        findViewById<View>(R.id.btnGrantDnd).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        findViewById<View>(R.id.btnEnableAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<View>(R.id.btnBatteryUnrestricted).setOnClickListener {
            requestUnrestrictedBattery()
        }
        findViewById<CheckBox>(R.id.checkKeepAlive).apply {
            isChecked = KeepAlive.isEnabled(this@VolumeControlActivity)
            setOnCheckedChangeListener { _, checked ->
                KeepAlive.setEnabled(this@VolumeControlActivity, checked)
                SystemActionService.refreshKeepAlive()
            }
        }
        setupBubbleSection()
        findViewById<View>(R.id.btnDone).setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        // Re-sync sliders in case volume changed elsewhere (e.g. an incoming call)
        rows.forEach { row ->
            val current = audioManager.getStreamVolume(row.stream)
            row.seekBar.progress = current
            row.valueText.text = current.toString()
        }
        updateDndBannerVisibility()
        updateBatteryBannerVisibility()
        syncBubbleSwitch()
        handler.removeCallbacks(watchService)
        watchService.run()
    }

    override fun onPause() {
        handler.removeCallbacks(watchService)
        super.onPause()
    }

    private fun setupRow(row: StreamRow) {
        val max = audioManager.getStreamMaxVolume(row.stream)
        val current = audioManager.getStreamVolume(row.stream)
        row.seekBar.max = max
        row.seekBar.progress = current
        row.valueText.text = current.toString()

        row.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                row.valueText.text = progress.toString()
                if (!fromUser) return
                try {
                    audioManager.setStreamVolume(row.stream, progress, 0)
                } catch (e: SecurityException) {
                    Toast.makeText(
                        this@VolumeControlActivity,
                        getString(R.string.dnd_needed_toast),
                        Toast.LENGTH_SHORT
                    ).show()
                    updateDndBannerVisibility()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
    }

    /**
     * The floating bubble: a switch for it and, while it is on, a picker for what each icon
     * of its arc does. The accessibility service does the actual showing; it is told right
     * away through [SystemActionService.refreshBubble] and reads the saved settings itself
     * whenever it starts.
     */
    private fun setupBubbleSection() {
        bubbleOptions = findViewById(R.id.bubbleOptions)
        bubbleSwitch = findViewById(R.id.switchBubble)

        val actions = SystemAction.forArc()
        val labels = listOf(getString(R.string.action_none)) + actions.map { getString(it.labelRes) }
        val pickers = listOf(
            ArcSlot.FIRST to findViewById<Spinner>(R.id.spinnerSlot1),
            ArcSlot.SECOND to findViewById<Spinner>(R.id.spinnerSlot2),
            ArcSlot.THIRD to findViewById<Spinner>(R.id.spinnerSlot3),
            ArcSlot.FOURTH to findViewById<Spinner>(R.id.spinnerSlot4),
            ArcSlot.FIFTH to findViewById<Spinner>(R.id.spinnerSlot5)
        )
        for ((slot, picker) in pickers) {
            picker.adapter = ArrayAdapter(this, R.layout.item_spinner_compact, labels).apply {
                setDropDownViewResource(R.layout.item_spinner_compact)
            }
            // Entry 0 is "Nothing"; the actions follow in the order of [labels].
            val current = BubblePrefs.actionFor(this, slot)
            picker.setSelection(if (current == null) 0 else actions.indexOf(current) + 1)
            picker.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    val chosen = if (position == 0) null else actions.getOrNull(position - 1)
                    // This also fires once when the picker is first laid out: only save a real change.
                    if (chosen != BubblePrefs.actionFor(this@VolumeControlActivity, slot)) {
                        BubblePrefs.setAction(this@VolumeControlActivity, slot, chosen)
                    }
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
        syncBubbleSwitch()
    }

    /**
     * Shows the saved state of the bubble. The chooser's Floating entry changes it too, so
     * this also runs whenever the screen comes back, without that counting as a tap on the switch.
     */
    private fun syncBubbleSwitch() {
        val enabled = BubblePrefs.isEnabled(this)
        bubbleSwitch.setOnCheckedChangeListener(null)
        bubbleSwitch.isChecked = enabled
        bubbleSwitch.setOnCheckedChangeListener(bubbleToggleListener)
        bubbleOptions.visibility = if (enabled) View.VISIBLE else View.GONE
    }

    private fun onBubbleToggled(checked: Boolean) {
        BubblePrefs.setEnabled(this, checked)
        bubbleOptions.visibility = if (checked) View.VISIBLE else View.GONE
        SystemActionService.refreshBubble()
        if (!checked) return

        // The bubble is a window of the accessibility service, so it needs the service. The
        // switch stays on either way: the bubble appears by itself once the service runs.
        when {
            !SystemActionService.isEnabled(this) -> {
                Toast.makeText(this, R.string.toast_bubble_needs_service, Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            SystemActionService.isStalled(this) -> {
                Toast.makeText(this, R.string.toast_restart_service, Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }

    private fun updateDndBannerVisibility() {
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val needsAccess = !notificationManager.isNotificationPolicyAccessGranted
        findViewById<View>(R.id.btnGrantDnd).visibility = if (needsAccess) View.VISIBLE else View.GONE
    }

    /**
     * The Screenshot / Shade shot / Power menu tiles and the nav-bar button need the
     * accessibility service running. The banner covers both ways that can be missing:
     * switched off (never enabled, or an app update turned it off), or switched on but
     * stopped by the system - the case where the button just does nothing. Either way the
     * tap leads to Accessibility settings; for the second, flip Volume Tile off and on.
     *
     * @return true while the service is on but not connected yet, i.e. worth checking again.
     */
    private fun updateAccessibilityBanner(): Boolean {
        val button = findViewById<Button>(R.id.btnEnableAccessibility)
        val enabled = SystemActionService.isEnabled(this)
        val connected = SystemActionService.isConnected()
        when {
            !enabled -> {
                button.setText(R.string.enable_accessibility_access)
                button.visibility = View.VISIBLE
            }
            connected -> button.visibility = View.GONE
            SystemActionService.isStalled(this) -> {
                button.setText(R.string.restart_accessibility_service)
                button.visibility = View.VISIBLE
            }
            // Just (re)started: the system is about to bind the service. Say nothing yet.
            else -> button.visibility = View.GONE
        }
        return enabled && !connected
    }

    /** Offered until the app is exempt from battery optimisation; vanishes once it is. */
    private fun updateBatteryBannerVisibility() {
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        val restricted = !powerManager.isIgnoringBatteryOptimizations(packageName)
        findViewById<View>(R.id.btnBatteryUnrestricted).visibility =
            if (restricted) View.VISIBLE else View.GONE
    }

    /**
     * Asks to be left out of battery optimisation. The first intent shows a one-tap system
     * dialog; if a phone lacks it, fall back to the full list, then to this app's info page.
     */
    @SuppressLint("BatteryLife")
    private fun requestUnrestrictedBattery() {
        val packageUri = Uri.parse("package:$packageName")
        val attempts = listOf(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, packageUri),
            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, packageUri)
        )
        for (intent in attempts) {
            try {
                startActivity(intent)
                return
            } catch (e: ActivityNotFoundException) {
                // This phone doesn't have that screen; try the next one.
            }
        }
    }

    private companion object {
        const val SERVICE_RECHECK_MS = 2_000L
    }
}
