package com.volumetile.app

import android.content.Context
import android.widget.Toast

/** Short toast from any Context - services included. */
fun Context.toast(resId: Int) {
    Toast.makeText(this, resId, Toast.LENGTH_SHORT).show()
}
