package com.volumetile.app

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.TileService

/** Plumbing shared by every Quick Settings tile in this app. */
abstract class BaseTileService : TileService() {

    /** Pushes state, label and optional subtitle to the tile in a single updateTile() call. */
    protected fun renderTile(state: Int, label: CharSequence, subtitle: CharSequence? = null) {
        val tile = qsTile ?: return
        tile.state = state
        tile.label = label
        // Tile.setSubtitle() only exists from API 29; older versions just show the label.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) tile.subtitle = subtitle
        tile.updateTile()
    }

    /**
     * Opens [intent] and collapses the shade. API 34 deprecated the Intent overload
     * of startActivityAndCollapse() in favour of a PendingIntent.
     */
    @Suppress("DEPRECATION")
    protected fun startActivityAndCollapseCompat(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val pending = PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            startActivityAndCollapse(pending)
        } else {
            startActivityAndCollapse(intent)
        }
    }
}
