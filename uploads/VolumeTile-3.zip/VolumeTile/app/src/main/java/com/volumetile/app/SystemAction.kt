package com.volumetile.app

import android.os.Build

/**
 * What the extra Quick Settings tiles can ask [SystemActionService] to do.
 *
 * To add a tile: add an entry here, handle it in SystemActionService.perform(),
 * then add a one-line subclass in ActionTiles.kt and a <service> in the manifest.
 */
enum class SystemAction(private val minSdk: Int) {

    /** Collapses the shade, then takes a normal screenshot of whatever is underneath. */
    SCREENSHOT(Build.VERSION_CODES.P),

    /** Takes a screenshot with the shade left open, so the notification area is what gets captured. */
    SHADE_SCREENSHOT(Build.VERSION_CODES.P),

    /** Opens the system power menu - what holding the power button does. */
    POWER_MENU(Build.VERSION_CODES.O);

    /** False on Android versions that lack the underlying global action. */
    val isSupported: Boolean
        get() = Build.VERSION.SDK_INT >= minSdk
}
