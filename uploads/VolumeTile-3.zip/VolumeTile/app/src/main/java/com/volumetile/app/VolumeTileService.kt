package com.volumetile.app

import android.media.AudioManager
import android.service.quicksettings.Tile

/**
 * Quick Settings tile. Tapping it does NOT open the app - that would kick
 * the user out of whatever they're doing (e.g. a game). Instead it nudges
 * the media stream with ADJUST_SAME + FLAG_SHOW_UI, which pops up the same
 * system volume panel you get from the hardware volume buttons. That panel
 * is a high-priority system overlay, so it's visible above the Quick
 * Settings shade even if the shade stays open - there's no public API to
 * force-collapse the shade without also launching an activity.
 */
class VolumeTileService : BaseTileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        showSystemVolumePanel()
    }

    private fun updateTile() {
        val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val percent = if (max > 0) (current * 100 / max) else 0

        renderTile(Tile.STATE_ACTIVE, getString(R.string.tile_label), "$percent%")
    }
}
