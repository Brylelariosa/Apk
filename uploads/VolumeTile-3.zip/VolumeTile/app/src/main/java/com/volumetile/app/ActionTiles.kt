package com.volumetile.app

import android.content.Intent
import android.provider.Settings
import android.service.quicksettings.Tile
import androidx.annotation.StringRes

/**
 * A tile that fires one [SystemAction] through [SystemActionService].
 *
 * Look: highlighted when ready; greyed with a hint subtitle when the accessibility
 * service still needs switching on (tapping then jumps to Accessibility settings)
 * or the Android version is too old for the action.
 *
 * If the service is switched on but the system has stopped running it, a tap says so
 * and jumps to the same Settings page, where flipping the switch off and on revives it.
 */
abstract class ActionTileService(
    private val action: SystemAction,
    private val readySubtitleRes: Int = 0
) : BaseTileService() {

    override fun onStartListening() {
        super.onStartListening()
        refreshTile()
    }

    override fun onClick() {
        super.onClick()
        if (!action.isSupported) {
            toast(R.string.toast_unsupported)
            return
        }
        if (!SystemActionService.isEnabled(this)) {
            openAccessibilitySettings(R.string.toast_enable_service)
            return
        }
        if (SystemActionService.dispatch(action)) return

        // Switched on but not connected. Right after a process restart the system is about
        // to bind the service, so give it a moment; if it still hasn't, the system has
        // dropped it and only flipping the switch brings it back.
        if (SystemActionService.isStalled(this)) {
            openAccessibilitySettings(R.string.toast_restart_service)
        } else {
            toast(R.string.toast_service_starting)
        }
    }

    private fun refreshTile() {
        val label = getString(action.labelRes)
        when {
            !action.isSupported ->
                renderTile(Tile.STATE_INACTIVE, label, getString(R.string.tile_subtitle_unsupported))
            !SystemActionService.isEnabled(this) ->
                renderTile(Tile.STATE_INACTIVE, label, getString(R.string.tile_subtitle_enable))
            SystemActionService.isStalled(this) ->
                renderTile(Tile.STATE_INACTIVE, label, getString(R.string.tile_subtitle_restart))
            else -> {
                val subtitle = if (readySubtitleRes != 0) getString(readySubtitleRes) else null
                renderTile(Tile.STATE_ACTIVE, label, subtitle)
            }
        }
    }

    private fun openAccessibilitySettings(@StringRes message: Int) {
        toast(message)
        startActivityAndCollapseCompat(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }
}

/** Collapses the shade, then screenshots the app underneath. */
class ScreenshotTileService : ActionTileService(SystemAction.SCREENSHOT)

/** Screenshots with the shade still open, i.e. captures the notification area. Never scrolls. */
class ShadeScreenshotTileService : ActionTileService(
    SystemAction.SHADE_SCREENSHOT,
    R.string.tile_shade_screenshot_subtitle
)

/** Opens the system power menu, same as holding the power button. */
class PowerMenuTileService : ActionTileService(SystemAction.POWER_MENU)
