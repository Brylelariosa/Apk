package com.volumetile.app

import android.accessibilityservice.AccessibilityService
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/**
 * Presses system buttons on behalf of the Quick Settings tiles.
 *
 * Apps can't take screenshots or open the power menu directly; without root the
 * only route is an AccessibilityService, whose performGlobalAction() hands the
 * request to the system. This one subscribes to no events and can't read window
 * content (see res/xml/system_action_service.xml) - it only runs what a tile asks.
 *
 * Tiles live in the same process, so they reach the running instance through
 * [dispatch] instead of binding to it.
 */
class SystemActionService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    private val screenshotTask = Runnable {
        if (!performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)) {
            toast(R.string.toast_action_failed)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() = Unit

    override fun onUnbind(intent: Intent?): Boolean {
        release()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        release()
        super.onDestroy()
    }

    private fun release() {
        handler.removeCallbacksAndMessages(null)
        if (instance === this) instance = null
    }

    private fun perform(action: SystemAction) {
        when (action) {
            SystemAction.SCREENSHOT -> {
                collapseShade()
                scheduleScreenshot(SHADE_COLLAPSE_SETTLE_MS)
            }
            // Shade stays open on purpose, so it is part of the capture.
            SystemAction.SHADE_SCREENSHOT -> scheduleScreenshot(TILE_PRESS_SETTLE_MS)
            SystemAction.POWER_MENU -> {
                if (!performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)) {
                    toast(R.string.toast_action_failed)
                }
            }
        }
    }

    private fun scheduleScreenshot(delayMs: Long) {
        // Cancel any pending capture first so a double tap still yields one screenshot.
        handler.removeCallbacks(screenshotTask)
        handler.postDelayed(screenshotTask, delayMs)
    }

    /**
     * Closes the notification shade without launching an activity, so a game in
     * the foreground isn't paused. API 31 added a proper global action for this;
     * before that, the close-system-dialogs broadcast does the same job.
     */
    @Suppress("DEPRECATION")
    private fun collapseShade() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        } else {
            sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS))
        }
    }

    companion object {
        /** Time for the shade's collapse animation to finish before we capture. */
        private const val SHADE_COLLAPSE_SETTLE_MS = 500L

        /** Lets the tapped tile's press feedback fade so it isn't in the capture. */
        private const val TILE_PRESS_SETTLE_MS = 250L

        // Cleared in release(), so it never outlives the service.
        @SuppressLint("StaticFieldLeak")
        @Volatile
        private var instance: SystemActionService? = null

        /** True when the user has switched the service on in Accessibility settings. */
        fun isEnabled(context: Context): Boolean {
            val resolver = context.contentResolver
            if (Settings.Secure.getInt(resolver, Settings.Secure.ACCESSIBILITY_ENABLED, 0) != 1) {
                return false
            }
            val enabled = Settings.Secure.getString(
                resolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val self = ComponentName(context, SystemActionService::class.java)
            return enabled.split(':').any { ComponentName.unflattenFromString(it) == self }
        }

        /**
         * Runs [action] if the service is connected. Returns false when it isn't -
         * e.g. just after a process restart, before the system has rebound it.
         */
        fun dispatch(action: SystemAction): Boolean {
            val service = instance ?: return false
            service.perform(action)
            return true
        }
    }
}
