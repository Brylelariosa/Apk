package com.volumetile.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Log
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.hypot
import kotlin.math.max

/**
 * A small floating bubble that sits on top of every app.
 *
 *  - Tap it: opens the action menu ([onTap]).
 *  - Hold it: a "C" of icons fans out around it ([ArcMenu]), one per action set in the app
 *    ([ArcSlot]). Without lifting the finger, slide towards one - it swells and shows its
 *    name - and let go to run it ([onPick]). Letting go anywhere else, or sliding back to
 *    the bubble, calls it off.
 *  - Drag it: moves it. It settles against the nearest side of the screen and remembers
 *    where it was left.
 *
 * It grows a little under the finger and pops in and out when it is switched on or off.
 *
 * Like [ActionChooserOverlay] it is a TYPE_ACCESSIBILITY_OVERLAY window: only an
 * accessibility service may add one, it needs no extra permission, and because it is not
 * focusable a game in the foreground keeps its input focus. The window is only as big as
 * the bubble, so touches anywhere else go straight to the app underneath.
 *
 * @param service the accessibility service. Its own WindowManager must be used: only that
 *   one carries the token allowed to add overlay windows.
 * @param onTap called when the bubble is tapped.
 * @param onPick called with the action the finger was on when it let go of the arc menu.
 */
class FloatingBubble(
    private val service: Context,
    private val onTap: () -> Unit,
    private val onPick: (SystemAction) -> Unit
) {

    private enum class Touch { IDLE, PRESSED, MENU, MOVING }

    private val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val arcMenu = ArcMenu(service)
    private val sizePx = service.dpToPx(SIZE_DP)

    // True while the person has the bubble switched on. The window may still be absent
    // for a moment, see [suppressed], or still on its way out, see [hide].
    private var wanted = false

    // Out of sight for a moment (a screenshot is about to be taken) without being switched off.
    private var suppressed = false

    // The window's content. Non-null exactly while the window exists.
    private var view: BubbleView? = null
    private var params: WindowManager.LayoutParams? = null
    private var snapAnimator: ValueAnimator? = null

    // Where the bubble rests: on which side of the screen, and how far down (0 = top, 1 = bottom).
    private var onRight = true
    private var yFraction = 0.35f

    /** True while the bubble is switched on, whether or not it is hidden for a screenshot. */
    val isShowing: Boolean
        get() = wanted

    fun show() {
        if (wanted) return
        wanted = true
        suppressed = false
        onRight = BubblePrefs.isOnRight(service)
        yFraction = BubblePrefs.yFraction(service)
        params = createParams().also { applyRestingPosition(it) }
        val leaving = view
        if (leaving != null) {
            // Switched back on while it was still shrinking away: bring that same window back.
            pushLayout()
            leaving.popIn()
        } else {
            attach(animate = true)
        }
    }

    /**
     * Switches the bubble off. With [animated] it shrinks away first (it is gone for good
     * once that is over); without, it is removed at once, which is what a service shutting
     * down needs.
     */
    fun hide(animated: Boolean = false) {
        val leaving = view
        wanted = false
        suppressed = false
        params = null
        if (animated && leaving != null) {
            leaving.popOut { if (!wanted) detach() }
        } else {
            detach()
        }
    }

    /**
     * Takes the bubble off the screen (or puts it back) without switching it off. A
     * screenshot would otherwise photograph it, so the service hides it around a capture.
     */
    fun setSuppressed(value: Boolean) {
        if (!wanted || suppressed == value) return
        suppressed = value
        if (value) detach() else attach(animate = false)
    }

    /** Puts the bubble back where it belongs after the screen size or rotation changed. */
    fun relayout() {
        val lp = params ?: return
        applyRestingPosition(lp)
        pushLayout()
    }

    private fun attach(animate: Boolean) {
        if (!wanted || suppressed || view != null) return
        val lp = params ?: return
        val created = BubbleView(service, startScale = if (animate) 0f else 1f)
        try {
            windowManager.addView(created, lp)
            view = created
        } catch (e: RuntimeException) {
            // The system refused the window (BadTokenException, e.g. while the service is
            // being torn down). Nothing was added, and nothing may escape from here: this
            // runs inside the accessibility service's process.
            Log.w(TAG, "Could not show the bubble", e)
            wanted = false
            params = null
            service.toast(R.string.toast_bubble_failed)
            return
        }
        if (animate) created.popIn()
    }

    private fun detach() {
        val current = view ?: return
        view = null
        snapAnimator?.cancel()
        snapAnimator = null
        // A pick that is still popping away is left to finish; anything else goes at once.
        if (!arcMenu.isClosing) arcMenu.dismissNow()
        try {
            windowManager.removeView(current)
        } catch (e: RuntimeException) {
            // Already gone - the system drops overlay windows when a service stops.
        }
    }

    private fun createParams() = WindowManager.LayoutParams(
        sizePx,
        sizePx,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        // Not focusable, so the app underneath keeps its keyboard/controller focus. Not
        // touch-modal, so a touch outside this small window reaches the app underneath too.
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        // Without this the bubble can't sit in the strip beside a notch/punch-hole in landscape.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    private fun screenWidth(): Int = service.resources.displayMetrics.widthPixels

    private fun screenHeight(): Int = service.resources.displayMetrics.heightPixels

    /** Highest the bubble may sit: clear of the status bar. */
    private fun topLimit(): Int = service.dpToPx(TOP_SAFE_DP)

    /** Lowest the bubble may sit: clear of the navigation bar / gesture area. */
    private fun bottomLimit(): Int =
        max(topLimit(), screenHeight() - sizePx - service.dpToPx(BOTTOM_SAFE_DP))

    private fun restingX(right: Boolean): Int {
        val margin = service.dpToPx(EDGE_MARGIN_DP)
        return if (right) screenWidth() - sizePx - margin else margin
    }

    private fun applyRestingPosition(lp: WindowManager.LayoutParams) {
        lp.x = restingX(onRight)
        lp.y = (topLimit() + yFraction * (bottomLimit() - topLimit())).toInt()
    }

    private fun pushLayout() {
        val current = view ?: return
        val lp = params ?: return
        try {
            windowManager.updateViewLayout(current, lp)
        } catch (e: RuntimeException) {
            Log.w(TAG, "Could not move the bubble", e)
        }
    }

    /** Follows the finger while the bubble is being carried. */
    private fun dragTo(x: Int, y: Int) {
        val lp = params ?: return
        lp.x = x.coerceIn(0, max(0, screenWidth() - sizePx))
        lp.y = y.coerceIn(topLimit(), bottomLimit())
        pushLayout()
    }

    /** Lets go of a carried bubble: slides it to the nearest side and remembers the spot. */
    private fun settle() {
        val lp = params ?: return
        onRight = lp.x + sizePx / 2 > screenWidth() / 2
        val span = bottomLimit() - topLimit()
        val toY = lp.y.coerceIn(topLimit(), bottomLimit())
        yFraction = if (span > 0) (toY - topLimit()).toFloat() / span else 0.5f
        BubblePrefs.savePosition(service, onRight, yFraction)

        val fromX = lp.x
        val fromY = lp.y
        val toX = restingX(onRight)
        snapAnimator?.cancel()
        snapAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = SNAP_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener { animator ->
                val t = animator.animatedValue as Float
                lp.x = fromX + ((toX - fromX) * t).toInt()
                lp.y = fromY + ((toY - fromY) * t).toInt()
                pushLayout()
            }
            start()
        }
    }

    private inner class BubbleView(context: Context, startScale: Float) : View(context) {

        private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = context.dpToPx(1.5f).toFloat()
            color = Color.WHITE
        }
        private val accent = context.getColor(R.color.purple_500)
        private val baseRadius = context.dpToPx(RADIUS_DP).toFloat()

        // A little wobble of a held finger is not a drag; twice the usual slop forgives it.
        private val moveSlop = ViewConfiguration.get(context).scaledTouchSlop * MOVE_SLOP_FACTOR
        private val glyph: Drawable? = context.getDrawable(R.drawable.ic_bubble)

        private var touch = Touch.IDLE

        // Raw (screen) coordinates, so they stay valid while the window itself moves.
        private var downX = 0f
        private var downY = 0f
        private var lastX = 0f
        private var lastY = 0f

        // Where the window was when it was picked up to be carried.
        private var startWinX = 0
        private var startWinY = 0

        // What is on the arc while it is open, and which of those the finger points at now.
        private var items: List<SystemAction> = emptyList()
        private var armed: Int? = null

        // How big the disc is drawn: [grow] eases between resting, touched and carried size,
        // [popScale] runs 0..1 (a little over on the way in) as the bubble appears or goes.
        private var grow = 1f
        private var popScale = startScale
        private var growAnimator: ValueAnimator? = null
        private var popAnimator: ValueAnimator? = null

        // Held long enough without moving: fan the arc out.
        private val openMenu = Runnable {
            if (touch != Touch.PRESSED) return@Runnable
            items = ArcSlot.values()
                .mapNotNull { BubblePrefs.actionFor(context, it) }
                .filter { it.isSupported && it.onBubbleArc }
            // Nothing set on the arc: stay a plain press, and letting go counts as a tap.
            if (items.isEmpty()) return@Runnable
            touch = Touch.MENU
            armed = null
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            val spot = IntArray(2)
            getLocationOnScreen(spot)
            arcMenu.show(items, spot[0] + width / 2f, spot[1] + height / 2f)
            invalidate()
        }

        init {
            contentDescription = context.getString(R.string.bubble_description)
            isSoundEffectsEnabled = false
        }

        fun popIn() {
            popAnimator?.cancel()
            popAnimator = ValueAnimator.ofFloat(popScale, 1f).apply {
                duration = POP_IN_MS
                interpolator = OvershootInterpolator(POP_OVERSHOOT)
                addUpdateListener {
                    popScale = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }

        /** Shrinks the bubble away, then calls [done]. [popIn] on the way cancels it. */
        fun popOut(done: () -> Unit) {
            popAnimator?.cancel()
            popAnimator = ValueAnimator.ofFloat(popScale, 0f).apply {
                duration = POP_OUT_MS
                interpolator = AccelerateInterpolator()
                addUpdateListener {
                    popScale = it.animatedValue as Float
                    invalidate()
                }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        done()
                    }
                })
                start()
            }
        }

        private fun growTo(target: Float) {
            growAnimator?.cancel()
            growAnimator = ValueAnimator.ofFloat(grow, target).apply {
                duration = GROW_MS
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    grow = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val radius = baseRadius * grow * popScale
            if (radius <= 0f) return

            disc.color = accent
            disc.alpha = if (touch == Touch.IDLE) IDLE_ALPHA else 255
            canvas.drawCircle(cx, cy, radius, disc)
            ring.alpha = if (armed != null) 255 else 110
            canvas.drawCircle(cx, cy, radius - ring.strokeWidth / 2f, ring)

            val half = (radius * 0.55f).toInt()
            glyph?.let { icon ->
                icon.setBounds(cx.toInt() - half, cy.toInt() - half, cx.toInt() + half, cy.toInt() + half)
                icon.draw(canvas)
            }
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            // Keep the system's edge "back" swipe from stealing a gesture that starts on the
            // bubble. Best effort: it only exists from Android 10 and the system may ignore it.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                systemGestureExclusionRects = listOf(Rect(0, 0, w, h))
            }
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    touch = Touch.PRESSED
                    downX = event.rawX
                    downY = event.rawY
                    lastX = downX
                    lastY = downY
                    armed = null
                    // Respect the phone's own "touch and hold" delay, but never go below the minimum.
                    postDelayed(
                        openMenu,
                        max(ViewConfiguration.getLongPressTimeout(), MIN_HOLD_MS).toLong()
                    )
                    growTo(PRESSED_GROW)
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    when (touch) {
                        Touch.PRESSED -> if (hypot(lastX - downX, lastY - downY) > moveSlop) beginMove()
                        Touch.MENU -> updateSelection()
                        Touch.MOVING -> dragTo(
                            startWinX + (lastX - downX).toInt(),
                            startWinY + (lastY - downY).toInt()
                        )
                        Touch.IDLE -> Unit
                    }
                }
                MotionEvent.ACTION_UP -> {
                    lastX = event.rawX
                    lastY = event.rawY
                    // Judge the pick by where the finger actually let go.
                    if (touch == Touch.MENU) updateSelection()
                    finish(cancelled = false)
                }
                MotionEvent.ACTION_CANCEL -> finish(cancelled = true)
            }
            return true
        }

        override fun performClick(): Boolean {
            super.performClick()
            onTap()
            return true
        }

        override fun onDetachedFromWindow() {
            removeCallbacks(openMenu)
            growAnimator?.cancel()
            popAnimator?.cancel()
            super.onDetachedFromWindow()
        }

        /** The finger moved before the hold was over: it is carrying the bubble, not asking for the arc. */
        private fun beginMove() {
            removeCallbacks(openMenu)
            touch = Touch.MOVING
            startWinX = params?.x ?: 0
            startWinY = params?.y ?: 0
            // Carry on from here, so the bubble doesn't jump by the distance already travelled.
            downX = lastX
            downY = lastY
            growTo(MOVE_GROW)
            invalidate()
        }

        /** Works out which icon the finger points at now and tells the arc, with a tick when it changes. */
        private fun updateSelection() {
            val index = arcMenu.indexAt(lastX - downX, lastY - downY)
            if (index == armed) return
            armed = index
            if (index != null) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            arcMenu.highlight(index)
            invalidate()
        }

        /** The finger went up or the system took the touch away. */
        private fun finish(cancelled: Boolean) {
            removeCallbacks(openMenu)
            val was = touch
            val pickedIndex = if (was == Touch.MENU && !cancelled) armed else null
            val picked = pickedIndex?.let { items.getOrNull(it) }
            if (was == Touch.MENU) arcMenu.close(pickedIndex)
            touch = Touch.IDLE
            armed = null
            growTo(1f)
            invalidate()
            when (was) {
                Touch.PRESSED -> if (!cancelled) performClick()
                Touch.MOVING -> settle()
                Touch.MENU, Touch.IDLE -> Unit
            }
            // Last, so everything above is finished even if the action hides the bubble.
            if (picked != null) onPick(picked)
        }
    }

    private companion object {
        const val TAG = "FloatingBubble"

        /** The bubble's window and touch target. The visible disc is smaller, leaving room to grow. */
        const val SIZE_DP = 48f
        const val RADIUS_DP = 18f

        /** Gap between the bubble and the screen edge it rests against. */
        const val EDGE_MARGIN_DP = 12f
        const val TOP_SAFE_DP = 24f
        const val BOTTOM_SAFE_DP = 56f

        const val SNAP_MS = 180L

        /** Shortest hold that fans the arc out, however quick the phone's own "touch and hold" is set. */
        const val MIN_HOLD_MS = 250

        /** How much further than the system's touch slop a finger may wander and still count as holding. */
        const val MOVE_SLOP_FACTOR = 2

        const val IDLE_ALPHA = 200

        /** Disc size while touched and while carried, relative to resting size. */
        const val PRESSED_GROW = 1.12f
        const val MOVE_GROW = 1.3f
        const val GROW_MS = 110L

        const val POP_IN_MS = 300L
        const val POP_OUT_MS = 160L
        const val POP_OVERSHOOT = 2f
    }
}
