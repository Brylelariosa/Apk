package com.volumetile.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Log
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The menu that fans out around the [FloatingBubble] while it is held: a row of round icons
 * in a "C" shape on a dark curved track, one per action, close to the bubble.
 *
 * Animation, all of it drawn here:
 *  - Opening: the icons swing out of the bubble along the curve, the middle ones first, and
 *    spring a little past their place before settling.
 *  - Sliding the finger: the icon it points at springs up in size, turns purple, sends a
 *    ring rippling out and gets a name tag; its neighbours slide aside to make room and the
 *    rest step back. Moving on to another icon hands all of that over to the next one.
 *  - Letting go: the others fold back into the bubble while the picked one pops.
 *
 * Where the icons go, and which one a finger movement points at, is decided by [ArcLayout].
 * This class owns the overlay window and the drawing and animation.
 *
 * Like the chooser it is a TYPE_ACCESSIBILITY_OVERLAY window of the accessibility service, so
 * it needs no permission. It cannot be touched (the finger that opened it stays on the
 * bubble's own window, which keeps receiving the movement), and it is only as big as the arc
 * so a game underneath is barely disturbed.
 *
 * @param service the accessibility service; its own WindowManager must be used (see
 *   [ActionChooserOverlay]).
 */
class ArcMenu(private val service: Context) {

    private val windowManager = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val minSelectPx = service.dpToPx(SELECT_MIN_DP).toFloat()

    private var arc: ArcView? = null

    /** True while the menu is folding away after [close]. */
    val isClosing: Boolean
        get() = arc?.isClosing == true

    /**
     * Fans [actions] out around the point ([centerX], [centerY]), the bubble's centre in
     * screen pixels. The first action is the top icon.
     */
    fun show(actions: List<SystemAction>, centerX: Float, centerY: Float) {
        dismissNow()
        if (actions.isEmpty()) return
        val metrics = service.resources.displayMetrics
        val discRadius = service.dpToPx(ITEM_DP / 2f).toFloat()
        val layout = ArcLayout.create(
            count = actions.size,
            centerX = centerX,
            centerY = centerY,
            screenWidth = metrics.widthPixels.toFloat(),
            screenHeight = metrics.heightPixels.toFloat(),
            radius = service.dpToPx(RADIUS_DP).toFloat(),
            margin = service.dpToPx(EDGE_MARGIN_DP).toFloat() + discRadius * HOVER_SCALE,
            minSpacing = discRadius * 2f * MIN_SPACING_FACTOR
        )
        val created = ArcView(service, actions, layout)
        try {
            windowManager.addView(created, windowParams(created.bounds))
        } catch (e: RuntimeException) {
            // The system refused the window (BadTokenException, e.g. while the service is being
            // torn down). The menu is only an aid and nothing may escape: this runs inside the
            // accessibility service's process.
            Log.w(TAG, "Could not show the arc menu", e)
            return
        }
        arc = created
        created.animateOpen()
    }

    /**
     * Which icon a finger that moved ([dx], [dy]) pixels from where it touched down points at,
     * as an index into the list given to [show], or null for none.
     */
    fun indexAt(dx: Float, dy: Float): Int? = arc?.layout?.indexAt(dx, dy, minSelectPx)

    /** Swells and names the icon at [index], or none of them when it is null. */
    fun highlight(index: Int?) {
        arc?.highlight(index)
    }

    /**
     * Folds the menu away and removes its window when that is done. [pickedIndex] is the icon
     * that was chosen, which pops instead of folding; null when the menu was just called off.
     */
    fun close(pickedIndex: Int?) {
        val closing = arc ?: return
        closing.close(pickedIndex) { remove(closing) }
    }

    /** Removes the menu at once, mid-animation if need be. */
    fun dismissNow() {
        val current = arc ?: return
        arc = null
        current.release()
        removeWindow(current)
    }

    private fun remove(view: ArcView) {
        if (arc === view) arc = null
        removeWindow(view)
    }

    private fun removeWindow(view: View) {
        try {
            windowManager.removeView(view)
        } catch (e: RuntimeException) {
            // Already gone - the system drops overlay windows when a service stops.
        }
    }

    private fun windowParams(bounds: Rect) = WindowManager.LayoutParams(
        bounds.width(),
        bounds.height(),
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = bounds.left
        y = bounds.top
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    /**
     * Draws the arc. Everything is kept in screen coordinates (the same ones the touch events
     * use) and the canvas is shifted to the window's own origin when drawing.
     */
    private class ArcView(
        context: Context,
        private val actions: List<SystemAction>,
        val layout: ArcLayout
    ) : View(context) {

        private val discRadius = context.dpToPx(ITEM_DP / 2f).toFloat()
        private val accent = context.getColor(R.color.purple_500)
        private val labels = actions.map { context.getString(it.labelRes) }
        private val icons: List<Drawable?> = actions.map { context.getDrawable(it.iconRes)?.mutate() }

        private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeWidth = discRadius * 2f + context.dpToPx(TRACK_EXTRA_DP)
            color = TRACK_COLOR
        }
        private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = context.dpToPx(RING_DP).toFloat()
            color = Color.WHITE
        }
        private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = context.dpToPx(PULSE_STROKE_DP).toFloat()
            color = accent
        }
        private val chipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP,
                CHIP_TEXT_SP,
                context.resources.displayMetrics
            )
        }

        private val trackBox = RectF(
            layout.centerX - layout.radius,
            layout.centerY - layout.radius,
            layout.centerX + layout.radius,
            layout.centerY + layout.radius
        )
        private val shadowOffset = context.dpToPx(SHADOW_OFFSET_DP).toFloat()

        // Name tags, one per icon, in screen coordinates. Only the pointed-at one is shown.
        private val chips: List<RectF> = buildChips()

        /** The window this view needs: everything it can ever draw, in screen pixels. */
        val bounds: Rect = buildBounds()

        // How far the icons have fanned out (0..1, linear; each icon eases it differently).
        private var openFraction = 0f

        // How far the menu has folded away again (0..1) once closing has started.
        private var collapseFraction = 0f

        // The icon the finger points at, and how strongly each icon is shown as pointed at.
        // Runs 0..1, but springs a little past 1 on the way in (and below 0 on the way out).
        private var highlighted: Int? = null
        private val hover = FloatArray(actions.size)

        // The ring that ripples out of the icon the finger has just arrived on. 1 = finished.
        private var pulseIndex = -1
        private var pulse = 1f

        // The icon that was picked, once closing has started.
        private var chosen: Int? = null

        private var openTween: Tween? = null
        private var hoverTween: Tween? = null
        private var pulseTween: Tween? = null
        private var closeTween: Tween? = null
        private var finished: (() -> Unit)? = null

        private val overshoot = OvershootInterpolator(OVERSHOOT_TENSION)
        private val spring = OvershootInterpolator(HOVER_TENSION)
        private val sweepEase = DecelerateInterpolator(SWEEP_EASE)
        private val trackEase = DecelerateInterpolator()
        private val rippleEase = DecelerateInterpolator()
        private val foldEase = AccelerateInterpolator()
        private val origin = IntArray(2)

        // Icon i waits |i - middle| * STAGGER before it starts: the middle ones go first.
        private val middle = (actions.size - 1) / 2f

        val isClosing: Boolean
            get() = closeTween != null

        init {
            // Purely decoration: screen readers have nothing to say about it.
            importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        }

        fun animateOpen() {
            openTween = Tween(OPEN_MS, onFrame = { time ->
                openFraction = time
                invalidate()
            }).also { it.start() }
        }

        /**
         * Points at icon [index] (or at none): it springs up while the one that had it settles
         * back, and a ring ripples out of the new one.
         */
        fun highlight(index: Int?) {
            if (index == highlighted || closeTween != null) return
            highlighted = index
            hoverTween?.cancel()
            val from = hover.copyOf()
            hoverTween = Tween(HOVER_MS, onFrame = { time ->
                val fraction = spring.getInterpolation(time)
                for (i in hover.indices) {
                    val target = if (i == highlighted) 1f else 0f
                    hover[i] = from[i] + (target - from[i]) * fraction
                }
                invalidate()
            }).also { it.start() }
            if (index != null) startRipple(index)
        }

        private fun startRipple(index: Int) {
            pulseTween?.cancel()
            pulseIndex = index
            pulse = 0f
            pulseTween = Tween(PULSE_MS, onFrame = { time ->
                pulse = rippleEase.getInterpolation(time)
                invalidate()
            }).also { it.start() }
        }

        /** Folds the menu away, then calls [done]. [pickedIndex] pops instead of folding. */
        fun close(pickedIndex: Int?, done: () -> Unit) {
            if (closeTween != null) return
            chosen = pickedIndex
            finished = done
            openTween?.cancel()
            closeTween = Tween(
                if (pickedIndex != null) PICK_MS else CLOSE_MS,
                onFrame = { time ->
                    collapseFraction = foldEase.getInterpolation(time)
                    invalidate()
                },
                onEnd = { finished?.invoke() }
            ).also { it.start() }
        }

        /** Stops every animation without calling back, ahead of the window being removed. */
        fun release() {
            finished = null
            openTween?.cancel()
            hoverTween?.cancel()
            pulseTween?.cancel()
            closeTween?.cancel()
        }

        override fun onDetachedFromWindow() {
            release()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            // Everything below is in screen coordinates; the window starts somewhere else.
            getLocationOnScreen(origin)
            canvas.translate(-origin[0].toFloat(), -origin[1].toFloat())

            val fade = 1f - collapseFraction
            drawTrack(canvas, fade)

            // While one icon is pointed at, the others step back a little.
            var focus = 0f
            for (strength in hover) focus = max(focus, strength.coerceIn(0f, 1f))

            // The pointed-at icon last, so it swells over its neighbours rather than under them.
            val top = highlighted
            for (i in actions.indices) if (i != top) drawItem(canvas, i, fade, focus)
            if (top != null) drawItem(canvas, top, fade, focus)
            drawRipple(canvas, fade)
            for (i in actions.indices) drawChip(canvas, i, fade)
        }

        /** The curved band behind the icons; it draws itself outwards from the middle. */
        private fun drawTrack(canvas: Canvas, fade: Float) {
            if (actions.size < 2) return
            val progress = trackEase.getInterpolation(openFraction.coerceIn(0f, 1f))
            val alpha = min(1f, openFraction * 3f) * fade
            if (progress <= 0f || alpha <= 0f) return
            val half = layout.halfSpan * progress
            trackPaint.alpha = (Color.alpha(TRACK_COLOR) * alpha).toInt()
            // Canvas angles run clockwise, ours counter-clockwise, hence the minus.
            canvas.drawArc(trackBox, -(layout.midAngle + half), 2f * half, false, trackPaint)
        }

        /** Icon [i]'s own clock while opening, 0..1. The icons at the ends of the arc start last. */
        private fun itemTime(i: Int): Float {
            val total = 1f + STAGGER * middle
            return (openFraction * total - abs(i - middle) * STAGGER).coerceIn(0f, 1f)
        }

        /** How far icon [i] has sprung out: 0 before it starts, 1 when settled, a little over on the way. */
        private fun itemProgress(i: Int): Float = overshoot.getInterpolation(itemTime(i))

        /**
         * The direction icon [i] is in right now. Opening, it swings out from the middle of
         * the arc to its place; once a neighbour is pointed at, it slides a little aside.
         */
        private fun itemAngle(i: Int): Float =
            layout.midAngle + layout.offsetOf(i) * sweepEase.getInterpolation(itemTime(i)) + pushOf(i)

        /**
         * How many degrees icon [i] is pushed along the arc, away from the icons that are
         * pointed at, to leave room for them to swell. Nearer neighbours give way more.
         */
        private fun pushOf(i: Int): Float {
            var push = 0f
            for (j in actions.indices) {
                if (j == i) continue
                val strength = hover[j].coerceAtLeast(0f)
                if (strength <= 0f) continue
                val away = if (layout.offsetOf(i) > layout.offsetOf(j)) 1f else -1f
                push += away * PUSH_DEG * strength / abs(i - j)
            }
            return push
        }

        private fun drawItem(canvas: Canvas, i: Int, fade: Float, focus: Float) {
            val progress = itemProgress(i)
            if (progress <= 0f) return
            val picked = i == chosen
            val angle = itemAngle(i)

            // Folding away pulls the others back into the bubble; the picked one stays and pops.
            val x = layout.pointX(angle, if (picked) progress else progress * fade)
            val y = layout.pointY(angle, if (picked) progress else progress * fade)

            // The swell is allowed to run a little past 1: that overshoot is the spring.
            val swell = hover[i]
            val pointedAt = swell.coerceIn(0f, 1f)
            var radius = discRadius * progress * (1f + (HOVER_SCALE - 1f) * swell)
            radius *= if (picked) 1f + (BURST_SCALE - 1f) * collapseFraction else fade
            val stepBack = 1f - DIM_OTHERS * focus * (1f - pointedAt)
            val alpha = min(1f, progress * 2f) * fade * stepBack
            if (radius <= 0f || alpha <= 0f) return

            shadowPaint.color = Color.argb((SHADOW_ALPHA * alpha).toInt(), 0, 0, 0)
            canvas.drawCircle(x, y + shadowOffset, radius, shadowPaint)

            val fill = blend(DISC_COLOR, accent, pointedAt)
            discPaint.color = fill
            discPaint.alpha = (Color.alpha(fill) * alpha).toInt()
            canvas.drawCircle(x, y, radius, discPaint)

            ringPaint.alpha = ((RING_ALPHA_IDLE + (255 - RING_ALPHA_IDLE) * pointedAt) * alpha).toInt()
            canvas.drawCircle(x, y, radius - ringPaint.strokeWidth / 2f, ringPaint)

            icons[i]?.let { icon ->
                val half = (radius * ICON_FRACTION).toInt()
                icon.setBounds((x - half).toInt(), (y - half).toInt(), (x + half).toInt(), (y + half).toInt())
                icon.alpha = (255 * alpha).toInt()
                icon.draw(canvas)
            }
        }

        /** The ring that ripples out of the icon the finger has just arrived on, fading as it grows. */
        private fun drawRipple(canvas: Canvas, fade: Float) {
            val index = pulseIndex
            if (index < 0 || pulse <= 0f || pulse >= 1f) return
            val progress = itemProgress(index)
            if (progress <= 0f) return
            val angle = itemAngle(index)
            val x = layout.pointX(angle, if (index == chosen) progress else progress * fade)
            val y = layout.pointY(angle, if (index == chosen) progress else progress * fade)
            val radius = discRadius * progress * (HOVER_SCALE + PULSE_GROW * pulse)
            pulsePaint.alpha = (PULSE_ALPHA * (1f - pulse) * fade).toInt().coerceIn(0, 255)
            canvas.drawCircle(x, y, radius, pulsePaint)
        }

        /** The name tag of icon [i], faded in and out with how much it is pointed at. */
        private fun drawChip(canvas: Canvas, i: Int, fade: Float) {
            val visible = hover[i].coerceIn(0f, 1f) * fade
            if (visible <= 0.02f) return
            val box = chips[i]
            chipPaint.color = CHIP_COLOR
            chipPaint.alpha = (Color.alpha(CHIP_COLOR) * visible).toInt()
            canvas.drawRoundRect(box, box.height() / 2f, box.height() / 2f, chipPaint)
            textPaint.alpha = (255 * visible).toInt()
            val baseline = box.centerY() - (textPaint.ascent() + textPaint.descent()) / 2f
            canvas.drawText(labels[i], box.centerX(), baseline, textPaint)
        }

        /**
         * Name tags sit just beyond their icon, further from the bubble, and are nudged back
         * onto the screen if that would put them off it.
         */
        private fun buildChips(): List<RectF> {
            val metrics = resources.displayMetrics
            val height = dp(CHIP_HEIGHT_DP)
            val padding = dp(CHIP_PADDING_DP)
            val gap = dp(CHIP_GAP_DP)
            val edge = dp(EDGE_MARGIN_DP)
            return actions.indices.map { i ->
                val width = textPaint.measureText(labels[i]) + padding * 2f
                val angle = layout.angles[i]
                val awayX = layout.directionX(angle)
                val awayY = layout.directionY(angle)
                val reach = discRadius * HOVER_SCALE + gap + width / 2f * abs(awayX) + height / 2f * abs(awayY)
                val centerX = layout.pointX(angle) + awayX * reach
                val centerY = layout.pointY(angle) + awayY * reach
                val left = (centerX - width / 2f).coerceAtLeast(edge)
                    .coerceAtMost(metrics.widthPixels - edge - width)
                val top = (centerY - height / 2f).coerceAtLeast(edge)
                    .coerceAtMost(metrics.heightPixels - edge - height)
                RectF(left, top, left + width, top + height)
            }
        }

        /** The smallest window that holds every frame of the animation, name tags included. */
        private fun buildBounds(): Rect {
            val metrics = resources.displayMetrics
            val area = RectF()
            fun cover(centerX: Float, centerY: Float, half: Float) {
                area.union(centerX - half, centerY - half, centerX + half, centerY + half)
            }

            // The picked icon swells and pops, and a ring ripples out of the pointed-at one:
            // those are the biggest things drawn.
            val biggest = max(
                discRadius * HOVER_SCALE * BURST_SCALE,
                discRadius * (HOVER_SCALE + PULSE_GROW)
            ) + shadowOffset
            for (angle in layout.angles) cover(layout.pointX(angle), layout.pointY(angle), biggest)
            // The icons start out at the bubble, so the window must reach it too.
            cover(layout.centerX, layout.centerY, discRadius)

            if (actions.size > 1) {
                val trackHalf = trackPaint.strokeWidth / 2f
                var offset = -layout.halfSpan
                while (offset < layout.halfSpan) {
                    val angle = layout.midAngle + offset
                    cover(layout.pointX(angle), layout.pointY(angle), trackHalf)
                    offset += BOUNDS_STEP_DEG
                }
                val last = layout.midAngle + layout.halfSpan
                cover(layout.pointX(last), layout.pointY(last), trackHalf)
            }
            for (chip in chips) area.union(chip)

            // Room for the icons' overshoot as they spring out.
            val spare = dp(BOUNDS_MARGIN_DP) + layout.radius * OVERSHOOT_ROOM
            area.inset(-spare, -spare)
            area.intersect(0f, 0f, metrics.widthPixels.toFloat(), metrics.heightPixels.toFloat())
            val whole = Rect()
            area.roundOut(whole)
            return whole
        }

        private fun dp(value: Float): Float = context.dpToPx(value).toFloat()

        private fun blend(from: Int, to: Int, fraction: Float): Int = Color.argb(
            mix(Color.alpha(from), Color.alpha(to), fraction),
            mix(Color.red(from), Color.red(to), fraction),
            mix(Color.green(from), Color.green(to), fraction),
            mix(Color.blue(from), Color.blue(to), fraction)
        )

        private fun mix(from: Int, to: Int, fraction: Float): Int =
            (from + (to - from) * fraction).toInt().coerceIn(0, 255)
    }

    private companion object {
        const val TAG = "ArcMenu"

        /** Diameter of an icon's disc. */
        const val ITEM_DP = 42f

        /**
         * Distance from the bubble's centre to the centre of each icon, when there is room.
         * The bubble itself is 36 dp across, so this leaves the icons a hand's breadth from
         * it rather than a thumb's length (it used to be 88).
         */
        const val RADIUS_DP = 60f

        /** Room kept between the (enlarged) icons and the screen edge. */
        const val EDGE_MARGIN_DP = 6f

        /** Neighbouring icons keep at least this many disc widths between their centres. */
        const val MIN_SPACING_FACTOR = 1.08f

        /** How far the finger must move before an icon counts as pointed at. Roughly 4 mm. */
        const val SELECT_MIN_DP = 28f

        /** Size of the pointed-at icon, and the extra swell of the picked one as it pops. */
        const val HOVER_SCALE = 1.25f
        const val BURST_SCALE = 1.45f

        /** The glyph is this fraction of the disc's radius either side of its centre. */
        const val ICON_FRACTION = 0.52f

        const val TRACK_EXTRA_DP = 10f
        const val SHADOW_OFFSET_DP = 2f
        const val RING_DP = 1.5f
        const val RING_ALPHA_IDLE = 90
        const val SHADOW_ALPHA = 70

        const val CHIP_HEIGHT_DP = 28f
        const val CHIP_PADDING_DP = 12f
        const val CHIP_GAP_DP = 8f
        const val CHIP_TEXT_SP = 13f

        const val BOUNDS_MARGIN_DP = 12f
        const val BOUNDS_STEP_DEG = 10f
        const val OVERSHOOT_ROOM = 0.1f

        /** Delay between one icon starting to spring out and the next, as a fraction of the opening. */
        const val STAGGER = 0.10f
        const val OVERSHOOT_TENSION = 1.6f

        /** How sharply the icons slow down as they swing into place along the arc. */
        const val SWEEP_EASE = 1.4f

        /** How springy the pointed-at icon's swell is. */
        const val HOVER_TENSION = 3.0f

        /** How far (degrees) the neighbour of a pointed-at icon slides aside, and how far the rest step back. */
        const val PUSH_DEG = 6f
        const val DIM_OTHERS = 0.4f

        /** The ripple: how much bigger than the swollen icon it grows, its line and its strength. */
        const val PULSE_GROW = 0.7f
        const val PULSE_STROKE_DP = 2.5f
        const val PULSE_ALPHA = 200

        const val OPEN_MS = 340L
        const val HOVER_MS = 220L
        const val PULSE_MS = 340L

        // The picked icon's pop must be over well before a screenshot is taken (the service
        // waits 250 ms), or the menu would be in the picture.
        const val PICK_MS = 140L
        const val CLOSE_MS = 120L

        val DISC_COLOR = Color.argb(235, 33, 33, 33)
        val TRACK_COLOR = Color.argb(96, 24, 24, 28)
        val CHIP_COLOR = Color.argb(240, 33, 33, 33)
    }
}

/**
 * Calls [onFrame] once per display frame with the time elapsed, from 0 to 1 over
 * [durationMs], and then [onEnd]. Main thread only.
 *
 * It keeps its own clock instead of using a ValueAnimator, so the arc moves at the speed
 * it was designed for even where the phone's animation scale (Developer options) is off or
 * stretched, or battery saver has switched animations off. Cancelling it calls nothing.
 */
private class Tween(
    private val durationMs: Long,
    private val onFrame: (Float) -> Unit,
    private val onEnd: (() -> Unit)? = null
) : Choreographer.FrameCallback {

    private var startNanos = -1L
    private var running = false

    fun start() {
        cancel()
        running = true
        startNanos = -1L
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun cancel() {
        if (!running) return
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        if (startNanos < 0L) startNanos = frameTimeNanos
        val elapsedMs = (frameTimeNanos - startNanos) / NANOS_PER_MS
        val time = (elapsedMs.toFloat() / durationMs).coerceIn(0f, 1f)
        onFrame(time)
        // The frame's own callback may have cancelled or restarted this tween.
        if (!running) return
        if (time >= 1f) {
            running = false
            onEnd?.invoke()
        } else {
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private companion object {
        const val NANOS_PER_MS = 1_000_000L
    }
}
