# Volume Tile

A Quick Settings tile that opens a small volume-control panel — built as a
workaround for a broken physical volume button.

## What it does

- Adds a **Volume** tile to the Quick Settings shade (pull down notifications,
  tap edit/pencil icon, drag the tile in).
- Tapping the tile opens a floating panel with sliders for **Media, Ring,
  Notification, and Alarm** volume — no physical buttons needed.
- The app icon on your home screen opens the same panel full-screen, so it
  also works as a standalone volume app.
- The tile subtitle shows the current media volume as a percentage.

## Extra tiles: Screenshot, Shade shot, Power menu

Built for the same reason as the Volume tile: no working hardware buttons
needed.

| Tile | What it does |
|------|--------------|
| **Screenshot** | Collapses the shade, then takes a normal screenshot of whatever is underneath. Nothing is launched, so a game in the foreground keeps running. |
| **Shade shot** | Takes the screenshot with the notification shade left open, so the notification area is what gets captured. Single frame only, it never scrolls. |
| **Power menu** | Opens the system power menu (Power off / Restart), same as holding the power button. |

Android only lets an app do this through an accessibility service, so there is
a one-time setup:

1. Add the tiles: pull down the shade, tap the edit/pencil icon, drag them in.
2. Tap any of them (or the **Enable accessibility** button in the app). It
   opens Settings > Accessibility; turn on **Volume Tile**.
3. On Android 13+, a sideloaded APK may have that toggle greyed out. Fix: App
   info > ⋮ > **Allow restricted settings**, then try again.

The service subscribes to no events and cannot read window content; it only
performs the action behind the tile you tapped. Screenshot and Shade shot need
Android 9+. Power menu works on every supported version. Until the service is
on, these tiles show greyed out with a "Tap to enable" hint.

## Ring volume note

Android requires "Do Not Disturb access" before an app can move Ring volume
to/through silent. If you drag the Ring slider to 0 and it's blocked, a
**Grant Do Not Disturb access** button appears — tap it once, allow access in
Settings, and it won't ask again.

## Building

Your build log shows this is actually built through your existing
zip-upload pipeline (the `Apk` repo / ZipApkBuilder), not the
`.github/workflows/build.yml` included here — that workflow is just a
ready-to-go alternative if you ever push this as its own standalone repo.

The pipeline's "Fetch gradle-wrapper.jar" step has been reliably producing
a jar with no `MANIFEST.MF` Main-Class entry (`no main manifest attribute`
when `gradlew` tries `-jar` on it) — reproduced twice with the identical
byte count, so it's not a one-off. `gradlew` here uses `-classpath
gradle-wrapper.jar org.gradle.wrapper.GradleWrapperMain` instead of `-jar`,
which specifies the main class directly and doesn't need a manifest at
all — the same technique your `FloatNote` project's `gradlew` already
uses against this same pipeline. The real, robust fix is still to change
the pipeline's "Build APK" step to call the already-provisioned `gradle`
directly instead of `./gradlew` (see below); this is a workaround for
until that's changed, or if you'd rather not touch the pipeline.

## Known pipeline issue

In the `Brylelariosa/Apk` repo's workflow, the "Build APK" step runs
`./gradlew assembleRelease`/`assembleDebug`. The earlier "Setup Gradle"
step already provisions a working `gradle` binary and puts it on `PATH`
(`gradle/actions/setup-gradle@v3`), so swapping `./gradlew` for `gradle`
in that step removes the dependency on the broken jar-fetch entirely, and
the "Fetch gradle-wrapper.jar" and "Make gradlew executable" steps become
unnecessary.

## Project layout

```
app/src/main/java/com/volumetile/app/
  VolumeTileService.kt      — the Volume Quick Settings tile (name must not
                               change, or its place in the shade is lost)
  VolumeControlActivity.kt  — the slider panel (used both full-screen and as
                               the tile's floating dialog)
  BaseTileService.kt        — shared tile plumbing (state render, collapse+launch)
  ActionTiles.kt            — ActionTileService base + Screenshot / Shade shot /
                               Power menu tiles (one line each)
  SystemAction.kt           — the actions a tile can fire
  SystemActionService.kt    — accessibility service that performs them
  ContextExt.kt             — Context.toast() helper
app/src/main/res/           — layout, strings, icons, xml/ (accessibility config)
gradlew                     — classpath-style wrapper script (see Building)
gradlew.bat, gradle/wrapper/ — rest of the standard Gradle wrapper, pinned to
                               Gradle 8.9
.github/workflows/build.yml — alternate CI build, only used if pushed as its
                               own repo with Actions enabled
```

## Size optimizations

The release build (what CI produces) is shrunk without dropping any
functionality:

- R8 minification + resource shrinking enabled (was off)
- Removed two dependencies that were pulled in but never actually used
  in the code (Material Components, core-ktx)
- Bundled resources restricted to English, dropping ~70 unused translated
  string sets that AppCompat/CardView ship internally
- Signed by your pipeline's real release keystore (it injects one via
  `-Pandroid.injected.signing.*` properties when the `KEYSTORE_B64` secret is
  set) — the build no longer overrides that with the debug key, so future
  updates install over each other normally instead of needing a reinstall

Stack traces from a release-build crash still show real file/line info
(kept explicitly in `proguard-rules.pro`) despite the obfuscation.

Your pipeline builds `assembleDebug` automatically when no keystore secret
is configured, and `assembleRelease` when one is — nothing to trigger
manually.

