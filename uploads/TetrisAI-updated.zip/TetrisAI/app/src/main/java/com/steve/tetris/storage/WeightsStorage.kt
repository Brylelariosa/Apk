package com.steve.tetris.storage

import android.content.Context
import com.steve.tetris.ai.HeuristicWeights

object WeightsStorage {
    private const val PREFS = "tetris_ai_prefs"
    private const val KEY_WEIGHTS = "trained_weights"

    fun save(context: Context, weights: HeuristicWeights) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_WEIGHTS, weights.serialize()).apply()
    }

    fun load(context: Context): HeuristicWeights {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val serialized = prefs.getString(KEY_WEIGHTS, null) ?: return HeuristicWeights()
        return HeuristicWeights.deserialize(serialized) ?: HeuristicWeights()
    }
}
