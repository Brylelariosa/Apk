package com.steve.tetris.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.steve.tetris.ai.GenerationResult
import com.steve.tetris.ai.GeneticTrainer
import com.steve.tetris.ai.HeuristicWeights
import com.steve.tetris.ai.TetrisAI
import com.steve.tetris.game.BOARD_COLS
import com.steve.tetris.storage.WeightsStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val SHOWCASE_COUNT = 4

@Composable
fun TrainScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val results = remember { mutableStateListOf<GenerationResult>() }
    var isTraining by remember { mutableStateOf(false) }
    var totalGenerations by remember { mutableStateOf(20) }
    val boards = remember { List(SHOWCASE_COUNT) { GameController() } }
    var showcaseLabel by remember { mutableStateOf("Untrained AI (x$SHOWCASE_COUNT) - watch it struggle") }
    var speedMs by remember { mutableStateOf(18L) }

    // AI/training-quality controls added in this pass. populationSize and
    // mutationRate feed GeneticTrainer's constructor directly; useLookahead
    // and fastTraining are explained where they're used below.
    var populationSize by remember { mutableStateOf(16) }
    var mutationRate by remember { mutableStateOf(0.15f) }
    var useLookahead by remember { mutableStateOf(false) }
    var fastTraining by remember { mutableStateOf(false) }
    var trainingStartMs by remember { mutableStateOf(0L) }
    var aiActionFeedback by remember { mutableStateOf<String?>(null) }

    DisposableEffect(Unit) {
        onDispose { boards.forEach { it.dispose() } }
    }

    LaunchedEffect(aiActionFeedback) {
        if (aiActionFeedback != null) {
            delay(2000L)
            aiActionFeedback = null
        }
    }

    // Idle demo loop: before training starts (or after it finishes), keep
    // replaying the current best-known weights on all boards so there's
    // always something playing - never a dead, empty screen.
    LaunchedEffect(isTraining) {
        if (!isTraining) {
            val last = results.lastOrNull()
            val weights = last?.bestEverWeights ?: HeuristicWeights()
            showcaseLabel = if (last == null) {
                "Untrained AI (x$SHOWCASE_COUNT) - watch it struggle"
            } else {
                "Trained AI (x$SHOWCASE_COUNT) - gen ${last.generation} best"
            }
            while (true) {
                boards.forEach { it.restart() }
                playShowcaseAll(boards, List(SHOWCASE_COUNT) { weights }, speedMs)
                delay(500L)
            }
        }
    }

    val etaSuffix = if (isTraining && results.isNotEmpty()) {
        val elapsedMs = System.currentTimeMillis() - trainingStartMs
        val perGenMs = elapsedMs / results.size
        val remaining = (totalGenerations - results.size).coerceAtLeast(0)
        val etaSeconds = (perGenMs * remaining) / 1000
        if (etaSeconds > 0) "  ~${formatEta(etaSeconds)} left" else ""
    } else ""

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(screenBackground)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("‹ Back", color = accentColor) }
            Text("Train AI", style = MaterialTheme.typography.titleMedium, color = Color(0xFFE6E9EF))
        }

        Spacer(Modifier.height(6.dp))
        Text(showcaseLabel, style = MaterialTheme.typography.bodySmall, color = Color(0xFF8A93A3))
        Spacer(Modifier.height(6.dp))

        Box(modifier = Modifier.weight(3f).fillMaxWidth()) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    MiniBoard(boards[0], Modifier.weight(1f).fillMaxHeight())
                    Spacer(Modifier.width(6.dp))
                    MiniBoard(boards[1], Modifier.weight(1f).fillMaxHeight())
                }
                Spacer(Modifier.height(6.dp))
                Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    MiniBoard(boards[2], Modifier.weight(1f).fillMaxHeight())
                    Spacer(Modifier.width(6.dp))
                    MiniBoard(boards[3], Modifier.weight(1f).fillMaxHeight())
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("Generations: $totalGenerations", color = Color(0xFF8A93A3), style = MaterialTheme.typography.bodySmall)
        Slider(
            value = totalGenerations.toFloat(),
            onValueChange = { totalGenerations = it.toInt().coerceIn(5, 60) },
            valueRange = 5f..60f,
            enabled = !isTraining
        )
        Text("Playback speed", color = Color(0xFF8A93A3), style = MaterialTheme.typography.bodySmall)
        Slider(
            value = (150L - speedMs).toFloat(),
            onValueChange = { speedMs = (150L - it.toLong()).coerceIn(3L, 140L) },
            valueRange = 0f..147f
        )
        Text(
            "Population: $populationSize",
            color = Color(0xFF8A93A3),
            style = MaterialTheme.typography.bodySmall
        )
        Slider(
            value = populationSize.toFloat(),
            onValueChange = { populationSize = it.toInt().coerceIn(8, 32) },
            valueRange = 8f..32f,
            enabled = !isTraining
        )
        val mutationPercent = "%.0f".format(mutationRate * 100)
        Text(
            "Mutation rate: $mutationPercent%",
            color = Color(0xFF8A93A3),
            style = MaterialTheme.typography.bodySmall
        )
        Slider(
            value = mutationRate,
            onValueChange = { mutationRate = it.coerceIn(0.05f, 0.5f) },
            valueRange = 0.05f..0.5f,
            enabled = !isTraining
        )

        Spacer(Modifier.height(4.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            LabeledSwitch(
                label = "Deep eval",
                checked = useLookahead,
                onCheckedChange = { useLookahead = it },
                enabled = !isTraining
            )
            LabeledSwitch(
                label = "Fast mode",
                checked = fastTraining,
                onCheckedChange = { fastTraining = it },
                enabled = true
            )
        }
        Spacer(Modifier.height(4.dp))

        Button(
            enabled = !isTraining,
            onClick = {
                results.clear()
                isTraining = true
                trainingStartMs = System.currentTimeMillis()
                scope.launch {
                    val trainer = GeneticTrainer(
                        populationSize = populationSize,
                        mutationRate = mutationRate.toDouble(),
                        showcaseCount = SHOWCASE_COUNT,
                        useLookahead = useLookahead
                    )
                    var finalWeights = HeuristicWeights()
                    for (gen in 1..totalGenerations) {
                        val result = withContext(Dispatchers.Default) { trainer.runGeneration(gen) }
                        results.add(result)
                        finalWeights = result.bestEverWeights
                        // Persist after every generation, not just at the end,
                        // so progress survives the app being backgrounded or
                        // killed mid-run instead of only surviving a full,
                        // uninterrupted training session.
                        withContext(Dispatchers.Default) {
                            WeightsStorage.save(context, finalWeights)
                        }
                        if (fastTraining) {
                            val bestFitnessText = "%.0f".format(result.bestFitness)
                            showcaseLabel = "Gen $gen - best fitness $bestFitnessText"
                        } else {
                            showcaseLabel = "Gen $gen - top $SHOWCASE_COUNT of the population playing now"
                            boards.forEach { it.restart() }
                            playShowcaseAll(boards, result.topWeights, speedMs)
                        }
                    }
                    isTraining = false
                }
            },
            modifier = Modifier.fillMaxWidth().height(46.dp)
        ) {
            Text(if (isTraining) "Training… (${results.size}/$totalGenerations)$etaSuffix" else "Start Training")
        }

        Spacer(Modifier.height(8.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TextButton(
                onClick = {
                    val toExport = results.lastOrNull()?.bestEverWeights ?: WeightsStorage.load(context)
                    clipboard.setText(AnnotatedString(toExport.serialize()))
                    aiActionFeedback = "Copied trained weights to clipboard"
                },
                modifier = Modifier.weight(1f)
            ) { Text("Export AI", color = accentColor) }
            TextButton(
                onClick = {
                    val parsed = clipboard.getText()?.text?.let { HeuristicWeights.deserialize(it) }
                    if (parsed != null) {
                        WeightsStorage.save(context, parsed)
                        aiActionFeedback = "Imported - Watch AI Play will use it"
                    } else {
                        aiActionFeedback = "Clipboard doesn't contain valid AI weights"
                    }
                },
                modifier = Modifier.weight(1f)
            ) { Text("Import AI", color = accentColor) }
        }
        aiActionFeedback?.let {
            Text(it, style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A3))
        }

        Spacer(Modifier.height(6.dp))
        Text("Generation log", style = MaterialTheme.typography.labelSmall, color = Color(0xFF8A93A3))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(results.reversed()) { r ->
                GenerationRow(result = r, maxFitness = results.maxOfOrNull { it.bestFitness } ?: 0.0)
            }
        }
    }
}

private fun formatEta(totalSeconds: Long): String {
    val m = totalSeconds / 60
    val s = totalSeconds % 60
    return if (m > 0) "${m}m ${s}s" else "${s}s"
}

@Composable
private fun LabeledSwitch(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit, enabled: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = Color(0xFF8A93A3))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            modifier = Modifier.padding(start = 6.dp)
        )
    }
}

@Composable
private fun MiniBoard(controller: GameController, modifier: Modifier = Modifier) {
    val state = controller.snapshot
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        BoardView(
            board = state.board,
            current = state.current,
            flashingRows = state.flashingRows,
            modifier = Modifier.fillMaxHeight().clip(RoundedCornerShape(8.dp))
        )
    }
}

/** Runs [weightsList] on [controllers] (same length) all at once, waiting for every board to finish. */
private suspend fun playShowcaseAll(controllers: List<GameController>, weightsList: List<HeuristicWeights>, stepDelay: Long) {
    coroutineScope {
        controllers.zip(weightsList).map { (controller, weights) ->
            async { playShowcase(controller, weights, stepDelay = stepDelay) }
        }.awaitAll()
    }
}

/**
 * Plays one game with [weights], one placement at a time, until a REAL game
 * over. [maxPieces] is a generous safety ceiling, not a normal stopping
 * point - it should essentially never be hit in practice.
 */
private suspend fun playShowcase(controller: GameController, weights: HeuristicWeights, maxPieces: Int = 200, stepDelay: Long = 35L) {
    var pieces = 0
    while (!controller.snapshot.isGameOver && pieces < maxPieces) {
        val snap = controller.snapshot
        val piece = snap.current ?: break
        val move = TetrisAI.bestMove(controller.currentBoard(), piece.type, weights, snap.next)
        if (move != null) {
            var rotAttempts = 0
            while (controller.snapshot.current?.rotation != move.rotation && rotAttempts < 4) {
                controller.rotate(); rotAttempts++
            }
            var guard = 0
            while ((controller.snapshot.current?.col ?: move.col) < move.col && guard < BOARD_COLS) {
                controller.moveRight(); guard++
            }
            guard = 0
            while ((controller.snapshot.current?.col ?: move.col) > move.col && guard < BOARD_COLS) {
                controller.moveLeft(); guard++
            }
        }
        controller.hardDrop()
        pieces++
        delay(stepDelay)
    }
}

@Composable
private fun GenerationRow(result: GenerationResult, maxFitness: Double) {
    val fraction = if (maxFitness > 0) (result.bestFitness / maxFitness).toFloat().coerceIn(0f, 1f) else 0f
    val avgText = "%.0f".format(result.averageFitness)
    val worstText = "%.0f".format(result.worstFitness)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "#${result.generation}",
                modifier = Modifier.width(34.dp),
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFF8A93A3)
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(14.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF262C38))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(fraction)
                        .clip(RoundedCornerShape(4.dp))
                        .background(accentColor)
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                "%.0f".format(result.bestFitness),
                style = MaterialTheme.typography.labelSmall,
                color = Color(0xFFE6E9EF),
                modifier = Modifier.width(46.dp)
            )
        }
        Text(
            "avg $avgText · worst $worstText",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF60697A),
            modifier = Modifier.padding(start = 34.dp)
        )
    }
}
