# Changelog

All notable changes to this project. Newest first.

## Pass 1 — AI & training

### Fixed
- `GeneticTrainer` fitness was computed without the 2-piece lookahead that
  live play ("Watch AI Play", training showcase) already used — training
  was evolving weights for a dumber policy than the one actually deployed.
  Now optional via a "Deep eval" toggle (off by default, since lookahead
  costs roughly 40x more per placement and the default keeps training fast
  on low-end hardware).
- Trained weights only persisted once, after the *entire* training run
  finished — an interrupted session (backgrounded app, low-memory kill,
  etc.) lost all progress. Now saves after every generation.

### Added
- Population size and mutation rate are adjustable sliders on the Train AI
  screen (previously fixed compile-time constants).
- "Fast mode" toggle skips the mandatory on-screen showcase playback each
  generation, for maximum training throughput.
- Average and worst fitness shown per generation alongside best (average
  was already computed but never displayed; worst wasn't computed at all).
- ETA estimate on the training button, based on a rolling per-generation
  average.
- Export/Import AI: copies trained weights to/from the clipboard as a
  compact text checkpoint you can keep or share.
- `HeuristicWeights.serialize()` / `.deserialize()` — shared by
  `WeightsStorage` and the new Export/Import feature instead of each
  re-implementing the same parsing.

### Docs
- README's Train AI section and training-defaults note updated to match
  the above.

## Pass 0 — Initial audit

### Fixed
- **`WeightsStorage.load()` checked `values.size == 4`, but
  `HeuristicWeights` has 6 fields.** Every trained AI's weights saved
  correctly but silently failed to load back — every app restart reverted
  "Watch AI Play" to the untrained default weights with no error shown.
  This is almost certainly why training never seemed to "stick."
- README claimed a population of 12 and 250 max pieces/game;
  `GeneticTrainer`'s actual defaults are 16 and 300. Numbers corrected to
  match the code.

### Found, not yet fixed
- `TetrisGame.lockPiece()` can write some cells to the board before it
  detects a top-out, if a piece's cells straddle row 0 unevenly (partial
  board mutation before the game-over check catches it). Needs a
  validate-then-commit reorder.
- Light-parent XML theme (`Theme.TetrisAI` extends
  `android:Theme.Material.Light.NoActionBar`) sitting under a Dark Compose
  theme — risk of a white flash on cold launch; status bar icon contrast
  may be wrong outside Play/Watch AI's immersive mode.
- No settings screen; no score/stat persistence beyond AI weights; no
  7-bag randomizer (pure uniform random); no hold piece; no ghost piece
  rendering; no lock delay/lock reset; kicks are 4 fixed offsets, not full
  SRS; no DAS/ARR or swipe gestures; soft drop is a single nudge, not
  hold-to-accelerate; no soft/hard-drop, back-to-back, or perfect-clear
  scoring; no volume/mute/vibration.
