# Tetris AI

A from-scratch Android Tetris built in Kotlin + Jetpack Compose, with three modes:

- **Play** — normal Tetris with on-screen controls (move, rotate, soft/hard drop),
  gravity that speeds up with level.
- **Watch AI Play** — an AI plays live using a heuristic board evaluator
  (aggregate height, holes, bumpiness, complete lines). It searches every
  rotation × column for the current piece, simulates the drop, and picks the
  best-scoring placement.
- **Train AI** — a genetic algorithm evolves the AI's own evaluation weights.
  Population size and mutation rate are adjustable in-app; "Deep eval" makes
  training score placements with the same 2-piece lookahead "Watch AI Play"
  uses (slower, more faithful to how the AI actually plays), and "Fast mode"
  skips the on-screen playback each generation for maximum training
  throughput. Progress (best, average, and worst fitness per generation)
  shows live, weights save after every generation rather than only at the
  end, and "Watch AI Play" always uses the most recently trained weights.
  Export/Import AI copies trained weights to/from the clipboard as a
  checkpoint you can keep or share.

## Project layout

```
app/src/main/java/com/steve/tetris/
  game/     TetrisGame.kt, Tetromino.kt      — engine, framework-free
  ai/       TetrisAI.kt, GeneticTrainer.kt,
            HeuristicWeights.kt              — move search + evolution
  storage/  WeightsStorage.kt                — persists trained weights
  ui/       AppRoot.kt, HomeScreen.kt,
            PlayScreen.kt, AIScreen.kt,
            TrainScreen.kt, BoardView.kt     — Compose UI
```

## Building

Push this zip to the `uploads/` folder of your Build-APK-workflow repo — the
existing CI pipeline unzips it, finds `settings.gradle`, and builds a debug
APK (no signing secrets required).

## Notes / possible follow-ups

- No custom app icon or edge-to-edge/cutout handling yet — kept out of scope
  for this first version. Easy to add later the same way it was done for the
  emulator app.
- Training defaults (16 individuals, 2 games each, up to 300 pieces/game) are
  tuned for a reasonably quick generation on mid-range hardware. Population
  and mutation rate are adjustable from the Train AI screen; games/individual
  and max pieces/game still require editing `GeneticTrainer`'s constructor
  defaults directly.
- Rotation uses simple left/right wall-kicks, not full SRS — good enough for
  solid play, not tournament-accurate.
