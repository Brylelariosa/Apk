package com.gyrofix.app.boost

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class BoostState(
    val running: Boolean = false,
    val profile: BoostProfile = BoostProfile.FULL_MOTION,
    val sinceElapsedMs: Long = 0L
)

/** Process-wide handle: the UI starts/stops the service here and observes whether it is running. */
object BoostController {

    private val mutableState = MutableStateFlow(BoostState())
    val state: StateFlow<BoostState> = mutableState.asStateFlow()

    fun start(context: Context, profile: BoostProfile) {
        val intent = Intent(context, BoostService::class.java)
            .setAction(BoostService.ACTION_START)
            .putExtra(BoostService.EXTRA_PROFILE, profile.name)
        context.startForegroundService(intent)
    }

    fun stop(context: Context) {
        context.stopService(Intent(context, BoostService::class.java))
    }

    internal fun markRunning(profile: BoostProfile) {
        mutableState.value = BoostState(
            running = true,
            profile = profile,
            sinceElapsedMs = SystemClock.elapsedRealtime()
        )
    }

    internal fun markStopped() {
        mutableState.update { it.copy(running = false) }
    }
}
