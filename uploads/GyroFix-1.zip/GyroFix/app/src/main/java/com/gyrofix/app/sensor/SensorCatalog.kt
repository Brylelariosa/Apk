package com.gyrofix.app.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager

enum class GyroKind { MISSING, HARDWARE, SOFTWARE, UNCLEAR }

data class SensorInfo(
    val label: String,
    val present: Boolean,
    val name: String,
    /** Fastest rate the sensor supports, or 0 when it only reports on change. */
    val maxHz: Int
)

data class SensorReport(
    val sensors: List<SensorInfo>,
    val gyroKind: GyroKind
)

/** Reads what the phone says it has, and guesses whether the gyroscope is real hardware. */
class SensorCatalog(context: Context) {

    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    val hasGyroscope: Boolean
        get() = manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null

    fun report(): SensorReport {
        val gyro = manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        val compass = manager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        return SensorReport(
            sensors = listOf(
                describe("Gyroscope", gyro),
                describe("Accelerometer", manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)),
                describe("Compass", compass),
                describe("Game rotation", manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR))
            ),
            gyroKind = classify(gyro, compass != null)
        )
    }

    private fun describe(label: String, sensor: Sensor?): SensorInfo {
        if (sensor == null) return SensorInfo(label, false, "", 0)
        val hz = if (sensor.minDelay > 0) 1_000_000 / sensor.minDelay else 0
        return SensorInfo(label, true, sensor.name ?: "", hz)
    }

    /**
     * Heuristic only: virtual gyros usually say so in their name, report zero power draw,
     * have no hardware FIFO, and show up on phones that also lack a compass.
     */
    private fun classify(gyro: Sensor?, hasCompass: Boolean): GyroKind {
        if (gyro == null) return GyroKind.MISSING
        val text = "${gyro.name} ${gyro.vendor}".lowercase()
        var score = 0
        if (SOFTWARE_HINTS.any { text.contains(it) }) score += 3
        if (gyro.power <= 0f) score += 1
        if (gyro.fifoMaxEventCount == 0) score += 1
        if (!hasCompass) score += 1
        return when {
            score >= 3 -> GyroKind.SOFTWARE
            score <= 1 -> GyroKind.HARDWARE
            else -> GyroKind.UNCLEAR
        }
    }

    private companion object {
        val SOFTWARE_HINTS = listOf("virtual", "software", "emulat", "fusion", "derived", "(sw)")
    }
}
