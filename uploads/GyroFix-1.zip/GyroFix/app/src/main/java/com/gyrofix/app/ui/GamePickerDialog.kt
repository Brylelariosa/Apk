package com.gyrofix.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gyrofix.app.game.AppEntry
import com.gyrofix.app.ui.theme.GyroPalette
import com.gyrofix.app.ui.theme.GyroType

@Composable
fun GamePickerDialog(
    apps: List<AppEntry>,
    onPick: (AppEntry) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = GyroPalette.Slate,
        title = { Text("Choose your game", style = GyroType.Section) },
        text = {
            if (apps.isEmpty()) {
                Text("Loading apps\u2026", style = GyroType.Quiet)
            } else {
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    items(apps, key = { it.packageName }) { app ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onPick(app) }
                                .padding(vertical = 10.dp)
                        ) {
                            Text(app.label, style = GyroType.Body)
                            Text(app.packageName, style = GyroType.Quiet)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", style = GyroType.Body.copy(color = GyroPalette.Amber))
            }
        }
    )
}
