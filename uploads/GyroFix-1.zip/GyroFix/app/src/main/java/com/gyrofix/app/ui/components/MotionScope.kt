package com.gyrofix.app.ui.components

import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.gyrofix.app.sensor.SampleRing
import com.gyrofix.app.ui.theme.GyroPalette
import com.gyrofix.app.ui.theme.GyroType
import java.util.Locale
import kotlin.math.abs

private const val WINDOW_NS = 2_000_000_000L
private const val DOT_LIMIT = 160

private val RANGE_STEPS = floatArrayOf(0.5f, 1f, 2f, 4f, 8f, 16f, 32f)

/** Scratch arrays for the samples currently on screen; reused every frame. */
private class ScopeBuffers {
    val times = LongArray(SampleRing.CAPACITY)
    val xs = FloatArray(SampleRing.CAPACITY)
    val ys = FloatArray(SampleRing.CAPACITY)
    val zs = FloatArray(SampleRing.CAPACITY)
    var count = 0
    var nowNs = 0L

    fun peak(): Float {
        var peak = 0f
        for (i in 0 until count) {
            val a = abs(xs[i])
            val b = abs(ys[i])
            val c = abs(zs[i])
            if (a > peak) peak = a
            if (b > peak) peak = b
            if (c > peak) peak = c
        }
        return peak
    }
}

private fun niceRange(peak: Float): Float =
    RANGE_STEPS.firstOrNull { it >= peak * 1.1f } ?: RANGE_STEPS.last()

private fun rangeLabel(range: Float): String =
    if (range < 1f) String.format(Locale.US, "%.1f", range) else range.toInt().toString()

/**
 * Two seconds of raw gyro rate, one trace per axis, positioned by arrival time.
 * At a low sample rate the X trace shows its individual samples as dots, so the rate is visible by eye.
 */
@Composable
fun MotionScope(ring: SampleRing, modifier: Modifier = Modifier) {
    val buffers = remember { ScopeBuffers() }
    val path = remember { Path() }
    var frame by remember { mutableLongStateOf(0L) }
    var range by remember { mutableFloatStateOf(2f) }

    LaunchedEffect(ring) {
        while (true) {
            withFrameNanos { frameTime ->
                val now = SystemClock.elapsedRealtimeNanos()
                buffers.nowNs = now
                buffers.count = ring.readSince(
                    now - WINDOW_NS,
                    buffers.times,
                    buffers.xs,
                    buffers.ys,
                    buffers.zs
                )
                val target = niceRange(buffers.peak())
                if (target != range) range = target
                frame = frameTime
            }
        }
    }

    val shape = RoundedCornerShape(10.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(GyroPalette.Inset)
            .border(1.dp, GyroPalette.Rule, shape)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE")
            val redrawOnFrame = frame
            drawGrid()
            drawTrace(path, buffers, buffers.zs, GyroPalette.Rose, range, false)
            drawTrace(path, buffers, buffers.ys, GyroPalette.Sky, range, false)
            drawTrace(path, buffers, buffers.xs, GyroPalette.Amber, range, true)
        }
        Text(
            text = "\u00B1${rangeLabel(range)} rad/s",
            style = GyroType.Quiet,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(8.dp)
        )
    }
}

private fun DrawScope.drawGrid() {
    val w = size.width
    val h = size.height
    val hair = 1.dp.toPx()
    val faint = GyroPalette.Rule.copy(alpha = 0.55f)
    drawLine(GyroPalette.Rule, Offset(0f, h / 2f), Offset(w, h / 2f), strokeWidth = hair)
    drawLine(faint, Offset(0f, h * 0.25f), Offset(w, h * 0.25f), strokeWidth = hair)
    drawLine(faint, Offset(0f, h * 0.75f), Offset(w, h * 0.75f), strokeWidth = hair)
    for (k in 1..3) {
        val x = w * k / 4f
        drawLine(faint, Offset(x, 0f), Offset(x, h), strokeWidth = hair)
    }
}

private fun xFor(buffers: ScopeBuffers, index: Int, width: Float): Float =
    width * (1f - (buffers.nowNs - buffers.times[index]).toFloat() / WINDOW_NS.toFloat())

private fun DrawScope.drawTrace(
    path: Path,
    buffers: ScopeBuffers,
    values: FloatArray,
    color: Color,
    range: Float,
    withDots: Boolean
) {
    val n = buffers.count
    if (n < 2) return
    val w = size.width
    val mid = size.height / 2f
    val scale = (mid - 6.dp.toPx()) / range
    val stride = maxOf(1, n / 360)

    path.reset()
    var i = 0
    var started = false
    while (i < n) {
        val x = xFor(buffers, i, w)
        val y = mid - values[i].coerceIn(-range, range) * scale
        if (started) {
            path.lineTo(x, y)
        } else {
            path.moveTo(x, y)
            started = true
        }
        i += stride
    }
    drawPath(
        path,
        color,
        style = Stroke(width = 1.6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
    )

    if (withDots && n <= DOT_LIMIT) {
        for (j in 0 until n) {
            val y = mid - values[j].coerceIn(-range, range) * scale
            drawCircle(color, radius = 2.4.dp.toPx(), center = Offset(xFor(buffers, j, w), y))
        }
    }
}
