package com.gyrofix.app.boost

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import com.gyrofix.app.sensor.RateSnapshot
import com.gyrofix.app.sensor.SensorChannel
import com.gyrofix.app.sensor.SensorLooper

data class ChannelReport(val sensorType: Int, val snapshot: RateSnapshot)

/**
 * Keeps the chosen sensors registered at their fastest rate with no batching.
 * The sensor hub runs at the fastest rate any app asks for, so other apps benefit too.
 */
object BoostEngine {

    private var channels: List<SensorChannel> = emptyList()

    /** Returns true when at least the gyroscope is running. */
    @Synchronized
    fun start(context: Context, profile: BoostProfile): Boolean {
        stopLocked()
        val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val running = profile.sensorTypes
            .map { type ->
                SensorChannel(
                    manager = manager,
                    sensorType = type,
                    samplingPeriod = SensorManager.SENSOR_DELAY_FASTEST,
                    handler = SensorLooper.handler
                )
            }
            .filter { it.start() }
        channels = running
        return running.any { it.sensorType == Sensor.TYPE_GYROSCOPE }
    }

    @Synchronized
    fun stop() {
        stopLocked()
    }

    @Synchronized
    fun reports(): List<ChannelReport> =
        channels.map { ChannelReport(it.sensorType, it.meter.snapshot) }

    private fun stopLocked() {
        channels.forEach { it.stop() }
        channels = emptyList()
    }
}
