package com.gyrofix.app.game

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

data class AppEntry(val label: String, val packageName: String)

/** Finds and opens the game. Needs the MAIN/LAUNCHER <queries> entry in the manifest to see other apps. */
class GameLauncher(private val context: Context) {

    private val packageManager: PackageManager = context.packageManager

    fun launchableApps(): List<AppEntry> {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(query, 0)
            .map { AppEntry(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .sortedWith(
                compareByDescending<AppEntry> { looksLikeBloodStrike(it) }
                    .thenBy { it.label.lowercase() }
            )
    }

    fun isInstalled(packageName: String): Boolean =
        packageManager.getLaunchIntentForPackage(packageName) != null

    fun labelOf(packageName: String): String? =
        try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 0)).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }

    /** Finds Blood Strike by its known package id first, then by app name. */
    fun detectBloodStrike(): String? {
        if (isInstalled(BLOOD_STRIKE_PACKAGE)) return BLOOD_STRIKE_PACKAGE
        return launchableApps().firstOrNull { looksLikeBloodStrike(it) }?.packageName
    }

    fun launch(packageName: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            true
        } catch (e: RuntimeException) {
            false
        }
    }

    private fun looksLikeBloodStrike(app: AppEntry): Boolean {
        val label = app.label.lowercase()
        return app.packageName == BLOOD_STRIKE_PACKAGE ||
            label.contains("blood strike") ||
            label.contains("bloodstrike")
    }

    companion object {
        const val BLOOD_STRIKE_PACKAGE = "com.netease.newspike"
    }
}
