package com.gyrofix.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** Instrument-panel palette: blue slate, chalk markings, one amber signal color. */
object GyroPalette {
    val Slate = Color(0xFF141B2D)
    val Inset = Color(0xFF0E1423)
    val Rule = Color(0xFF2C3856)
    val Chalk = Color(0xFFE9EDF5)
    val Fog = Color(0xFF8D98B0)
    val Amber = Color(0xFFFFB224)
    val OnAmber = Color(0xFF1A1200)
    val Sky = Color(0xFF6CB6FF)
    val Rose = Color(0xFFFF7A90)
    val Ok = Color(0xFF6FE3A0)
    val Bad = Color(0xFFFF6B6B)
}

/** Serif for the readout and headings, sans for everything you press or read in a sentence. */
object GyroType {
    val Hero = TextStyle(
        fontFamily = FontFamily.Serif,
        fontSize = 68.sp,
        fontWeight = FontWeight.Medium,
        letterSpacing = (-1.5).sp,
        color = GyroPalette.Chalk
    )
    val Title = TextStyle(
        fontFamily = FontFamily.Serif,
        fontSize = 28.sp,
        fontWeight = FontWeight.Medium,
        color = GyroPalette.Chalk
    )
    val Section = TextStyle(
        fontFamily = FontFamily.Serif,
        fontSize = 19.sp,
        fontWeight = FontWeight.Medium,
        color = GyroPalette.Chalk
    )
    val Body = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 15.sp,
        lineHeight = 21.sp,
        color = GyroPalette.Chalk
    )
    val Quiet = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        color = GyroPalette.Fog
    )
    val Value = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 15.sp,
        fontWeight = FontWeight.Medium,
        color = GyroPalette.Chalk
    )
    val Button = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
        color = GyroPalette.Chalk
    )
}

@Composable
fun GyroFixTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GyroPalette.Amber,
            onPrimary = GyroPalette.OnAmber,
            background = GyroPalette.Slate,
            onBackground = GyroPalette.Chalk,
            surface = GyroPalette.Slate,
            onSurface = GyroPalette.Chalk
        ),
        content = content
    )
}
