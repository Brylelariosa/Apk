package com.gyrofix.app.boost

import android.app.Notification
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import com.gyrofix.app.R
import java.util.Locale

/**
 * Foreground service that owns the boost. A foreground service is what keeps Android from
 * silencing sensor listeners once the game is on screen and this app is in the background.
 */
class BoostService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var profile = BoostProfile.FULL_MOTION

    private val notificationTicker = object : Runnable {
        override fun run() {
            refreshNotification()
            mainHandler.postDelayed(this, NOTIFICATION_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        profile = BoostProfile.fromName(intent?.getStringExtra(EXTRA_PROFILE))
        enterForeground(BoostNotifications.build(this, getString(R.string.notif_starting)))

        if (!BoostEngine.start(this, profile)) {
            Toast.makeText(this, R.string.gyro_unavailable, Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }

        BoostController.markRunning(profile)
        mainHandler.removeCallbacks(notificationTicker)
        mainHandler.postDelayed(notificationTicker, FIRST_NOTIFICATION_DELAY_MS)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        BoostEngine.stop()
        BoostController.markStopped()
        super.onDestroy()
    }

    private fun enterForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                BoostNotifications.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(BoostNotifications.NOTIFICATION_ID, notification)
        }
    }

    private fun refreshNotification() {
        val gyro = BoostEngine.reports()
            .firstOrNull { it.sensorType == Sensor.TYPE_GYROSCOPE }
            ?.snapshot
        val text = if (gyro != null && gyro.hz > 0f) {
            val delay = if (gyro.hasDelay) String.format(Locale.US, ", %.1f ms delay", gyro.delayMs) else ""
            "Gyro ${gyro.hz.toInt()} Hz$delay, ${profile.label}"
        } else {
            getString(R.string.notif_starting)
        }
        getSystemService(NotificationManager::class.java)
            .notify(BoostNotifications.NOTIFICATION_ID, BoostNotifications.build(this, text))
    }

    companion object {
        const val ACTION_START = "com.gyrofix.app.action.START"
        const val ACTION_STOP = "com.gyrofix.app.action.STOP"
        const val EXTRA_PROFILE = "profile"
        private const val NOTIFICATION_INTERVAL_MS = 2_000L
        private const val FIRST_NOTIFICATION_DELAY_MS = 1_000L
    }
}
