package com.gyrofix.app.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.gyrofix.app.ui.theme.GyroFixTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private var askedForNotifications = false
    private var afterNotificationPrompt: (() -> Unit)? = null

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // The boost runs with or without the notification; only its status line depends on it.
            afterNotificationPrompt?.invoke()
            afterNotificationPrompt = null
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GyroFixTheme {
                val state by viewModel.state.collectAsState()
                val apps by viewModel.apps.collectAsState()
                var picking by remember { mutableStateOf(false) }
                val actions = remember {
                    MainActions(
                        onToggleBoost = { toggleBoost() },
                        onProfile = { viewModel.selectProfile(it) },
                        onBoostAndLaunch = { boostAndLaunch() },
                        onPickGame = {
                            viewModel.loadApps()
                            picking = true
                        },
                        onFixBackground = { openBackgroundSettings() },
                        onResetPeaks = { viewModel.resetPeaks() }
                    )
                }

                MainScreen(state = state, ring = viewModel.ring, actions = actions)

                if (picking) {
                    GamePickerDialog(
                        apps = apps,
                        onPick = {
                            viewModel.selectGame(it)
                            picking = false
                        },
                        onDismiss = { picking = false }
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.onForeground()
    }

    override fun onPause() {
        viewModel.onBackground()
        super.onPause()
    }

    private fun toggleBoost() {
        if (viewModel.state.value.boost.running) {
            viewModel.stopBoost()
        } else {
            withNotificationPermission { viewModel.startBoost() }
        }
    }

    private fun boostAndLaunch() {
        withNotificationPermission {
            viewModel.startBoost()
            if (!viewModel.launchGame()) {
                Toast.makeText(this, "Pick your game first.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun withNotificationPermission(action: () -> Unit) {
        val needsPrompt = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !askedForNotifications &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needsPrompt) {
            askedForNotifications = true
            afterNotificationPrompt = action
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            action()
        }
    }

    private fun openBackgroundSettings() {
        val direct = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            .setData(Uri.parse("package:$packageName"))
        try {
            startActivity(direct)
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: ActivityNotFoundException) {
                Toast.makeText(
                    this,
                    "Open Settings, then Battery, and let GyroFix run in the background.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}
