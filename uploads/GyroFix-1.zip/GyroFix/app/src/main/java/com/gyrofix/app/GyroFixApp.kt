package com.gyrofix.app

import android.app.Application
import com.gyrofix.app.boost.BoostNotifications

class GyroFixApp : Application() {

    override fun onCreate() {
        super.onCreate()
        BoostNotifications.ensureChannel(this)
    }
}
