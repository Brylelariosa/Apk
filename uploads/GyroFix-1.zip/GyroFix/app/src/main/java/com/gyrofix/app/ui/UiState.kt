package com.gyrofix.app.ui

import com.gyrofix.app.boost.BoostProfile
import com.gyrofix.app.boost.BoostState
import com.gyrofix.app.sensor.GyroKind
import com.gyrofix.app.sensor.SensorInfo
import com.gyrofix.app.system.Conditions

/** What the probe says about boost: is it changing what a game receives? */
enum class Verdict { BOOST_OFF, MEASURING, EFFECTIVE, NO_EFFECT }

data class GameUi(
    val packageName: String? = null,
    val label: String? = null
)

data class UiState(
    val boost: BoostState = BoostState(),
    val profile: BoostProfile = BoostProfile.FULL_MOTION,
    val gyroPresent: Boolean = true,
    val gyroKind: GyroKind = GyroKind.UNCLEAR,
    val sensors: List<SensorInfo> = emptyList(),
    val probeHz: Float = 0f,
    val probeDelayMs: Float = -1f,
    val probeJitterMs: Float = 0f,
    /** Rate a game gets with boost off (measured), or the nominal game rate when not yet measured. */
    val baselineHz: Float = 0f,
    val verdict: Verdict = Verdict.BOOST_OFF,
    val peakX: Float = 0f,
    val peakY: Float = 0f,
    val peakZ: Float = 0f,
    val game: GameUi = GameUi(),
    val conditions: Conditions = Conditions()
)
