package com.gyrofix.app.data

import android.content.Context
import com.gyrofix.app.boost.BoostProfile

class Prefs(context: Context) {

    private val store = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    var profile: BoostProfile
        get() = BoostProfile.fromName(store.getString(KEY_PROFILE, null))
        set(value) {
            store.edit().putString(KEY_PROFILE, value.name).apply()
        }

    var gamePackage: String?
        get() = store.getString(KEY_GAME, null)
        set(value) {
            store.edit().putString(KEY_GAME, value).apply()
        }

    private companion object {
        const val FILE = "gyrofix"
        const val KEY_PROFILE = "profile"
        const val KEY_GAME = "game_package"
    }
}
