package com.gyrofix.app.sensor

import kotlin.math.sqrt

/** Result of one measuring window. */
data class RateSnapshot(
    val hz: Float,
    val jitterMs: Float,
    val maxGapMs: Float,
    /** Mean sensor-to-app delivery delay in ms, or a negative value when the phone's timestamps are unusable. */
    val delayMs: Float,
    val publishedAtNs: Long
) {
    val hasDelay: Boolean get() = delayMs >= 0f

    companion object {
        val EMPTY = RateSnapshot(0f, 0f, 0f, -1f, 0L)
    }
}

/**
 * Turns raw sensor callbacks into a [RateSnapshot] every [windowNs].
 * [onSample] is called from the sensor thread only; [snapshot] can be read from any thread.
 */
class RateMeter(private val windowNs: Long = 500_000_000L) {

    @Volatile
    var snapshot: RateSnapshot = RateSnapshot.EMPTY
        private set

    private var windowStartNs = 0L
    private var lastArrivalNs = 0L
    private var count = 0
    private var sumGap = 0.0
    private var sumGapSq = 0.0
    private var maxGap = 0L
    private var sumDelay = 0.0
    private var delayCount = 0

    fun onSample(arrivalNs: Long, eventNs: Long) {
        if (windowStartNs == 0L) {
            windowStartNs = arrivalNs
            lastArrivalNs = arrivalNs
            return
        }
        val gap = arrivalNs - lastArrivalNs
        lastArrivalNs = arrivalNs
        count++
        sumGap += gap.toDouble()
        sumGapSq += gap.toDouble() * gap.toDouble()
        if (gap > maxGap) maxGap = gap

        val delay = arrivalNs - eventNs
        if (delay in 0L..MAX_VALID_DELAY_NS) {
            sumDelay += delay.toDouble()
            delayCount++
        }

        val elapsed = arrivalNs - windowStartNs
        if (elapsed >= windowNs) publish(arrivalNs, elapsed)
    }

    private fun publish(nowNs: Long, elapsedNs: Long) {
        val n = count
        val meanGap = sumGap / n
        val variance = (sumGapSq / n - meanGap * meanGap).coerceAtLeast(0.0)
        snapshot = RateSnapshot(
            hz = (n * 1e9 / elapsedNs).toFloat(),
            jitterMs = (sqrt(variance) / 1e6).toFloat(),
            maxGapMs = (maxGap / 1e6).toFloat(),
            delayMs = if (delayCount > 0) (sumDelay / delayCount / 1e6).toFloat() else -1f,
            publishedAtNs = nowNs
        )
        windowStartNs = nowNs
        count = 0
        sumGap = 0.0
        sumGapSq = 0.0
        maxGap = 0L
        sumDelay = 0.0
        delayCount = 0
    }

    private companion object {
        const val MAX_VALID_DELAY_NS = 1_000_000_000L
    }
}
