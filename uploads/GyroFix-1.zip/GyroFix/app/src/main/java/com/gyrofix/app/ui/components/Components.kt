package com.gyrofix.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gyrofix.app.ui.theme.GyroPalette
import com.gyrofix.app.ui.theme.GyroType
import java.util.Locale

fun formatOne(value: Float): String = String.format(Locale.US, "%.1f", value)

fun formatTwo(value: Float): String = String.format(Locale.US, "%.2f", value)

/** A hairline plus a serif title; the hairline is what separates sections, not boxes. */
@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(GyroPalette.Rule)
        )
        Spacer(Modifier.height(14.dp))
        Text(title, style = GyroType.Section)
    }
}

/** A small labelled measurement. */
@Composable
fun Figure(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, style = GyroType.Quiet)
        Text(value, style = GyroType.Value)
    }
}

enum class Level { Ok, Warn, Bad, Quiet }

@Composable
fun StatusRow(
    label: String,
    value: String,
    level: Level,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    val dot = when (level) {
        Level.Ok -> GyroPalette.Ok
        Level.Warn -> GyroPalette.Amber
        Level.Bad -> GyroPalette.Bad
        Level.Quiet -> GyroPalette.Fog
    }
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(dot)
        )
        Spacer(Modifier.width(12.dp))
        Text(label, style = GyroType.Body, modifier = Modifier.weight(1f))
        Text(value, style = GyroType.Value)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.width(14.dp))
            Text(
                text = actionLabel,
                style = GyroType.Body.copy(color = GyroPalette.Amber, fontWeight = FontWeight.SemiBold),
                modifier = Modifier
                    .clickable(onClick = onAction)
                    .padding(vertical = 4.dp)
            )
        }
    }
}

@Composable
fun OutlineButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    val shape = RoundedCornerShape(28.dp)
    val tone = if (enabled) GyroPalette.Chalk else GyroPalette.Fog
    Box(
        modifier = modifier
            .height(52.dp)
            .clip(shape)
            .border(1.5.dp, tone, shape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = GyroType.Button.copy(color = tone))
    }
}

@Composable
fun TextAction(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Text(
        text = text,
        style = GyroType.Button.copy(color = GyroPalette.Amber),
        modifier = modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp)
    )
}

/** Text tab with an amber underline when selected. */
@Composable
fun ProfileTab(text: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp)
    ) {
        Text(
            text = text,
            style = GyroType.Body.copy(
                color = if (selected) GyroPalette.Chalk else GyroPalette.Fog,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
            )
        )
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .height(2.dp)
                .width(28.dp)
                .background(if (selected) GyroPalette.Amber else Color.Transparent)
        )
    }
}

/** Legend entry for one scope trace, with that axis's peak reading. */
@Composable
fun AxisKey(axis: String, color: Color, peak: Float) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(6.dp))
        Text("$axis ${formatTwo(peak)}", style = GyroType.Value)
    }
}
