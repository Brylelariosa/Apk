package com.gyrofix.app.system

import android.content.Context
import android.os.Build
import android.os.PowerManager

data class Conditions(
    val batterySaver: Boolean = false,
    /** PowerManager.THERMAL_STATUS_* value, or -1 when the phone does not report it. */
    val thermalStatus: Int = -1,
    val backgroundUnrestricted: Boolean = true
)

/** Things that make a game feel laggy no matter how fast the sensors run. */
class DeviceConditions(private val context: Context) {

    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager

    fun read(): Conditions = Conditions(
        batterySaver = powerManager.isPowerSaveMode,
        thermalStatus = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            powerManager.currentThermalStatus
        } else {
            -1
        },
        backgroundUnrestricted = powerManager.isIgnoringBatteryOptimizations(context.packageName)
    )
}
