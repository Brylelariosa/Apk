package com.gyrofix.app.boost

import android.hardware.Sensor

/** Which sensors the boost keeps at full speed. */
enum class BoostProfile(
    val label: String,
    val hint: String,
    val sensorTypes: List<Int>
) {
    GYRO_ONLY(
        label = "Gyro only",
        hint = "Locks just the gyroscope. Lowest battery use.",
        sensorTypes = listOf(Sensor.TYPE_GYROSCOPE)
    ),
    FULL_MOTION(
        label = "Full motion",
        hint = "Also locks accelerometer, compass and fusion sensors. Try this first: a software gyro is built from them.",
        sensorTypes = listOf(
            Sensor.TYPE_GYROSCOPE,
            Sensor.TYPE_ACCELEROMETER,
            Sensor.TYPE_MAGNETIC_FIELD,
            Sensor.TYPE_GAME_ROTATION_VECTOR,
            Sensor.TYPE_ROTATION_VECTOR
        )
    );

    companion object {
        fun fromName(name: String?): BoostProfile =
            values().firstOrNull { it.name == name } ?: FULL_MOTION
    }
}
