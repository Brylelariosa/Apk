package com.gyrofix.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gyrofix.app.boost.BoostProfile
import com.gyrofix.app.sensor.GyroKind
import com.gyrofix.app.sensor.SampleRing
import com.gyrofix.app.ui.components.AxisKey
import com.gyrofix.app.ui.components.Figure
import com.gyrofix.app.ui.components.Level
import com.gyrofix.app.ui.components.MotionScope
import com.gyrofix.app.ui.components.OutlineButton
import com.gyrofix.app.ui.components.ProfileTab
import com.gyrofix.app.ui.components.SectionHeader
import com.gyrofix.app.ui.components.StatusRow
import com.gyrofix.app.ui.components.TextAction
import com.gyrofix.app.ui.components.formatOne
import com.gyrofix.app.ui.theme.GyroPalette
import com.gyrofix.app.ui.theme.GyroType
import kotlin.math.roundToInt

/** Everything the screen can ask the activity to do. */
class MainActions(
    val onToggleBoost: () -> Unit,
    val onProfile: (BoostProfile) -> Unit,
    val onBoostAndLaunch: () -> Unit,
    val onPickGame: () -> Unit,
    val onFixBackground: () -> Unit,
    val onResetPeaks: () -> Unit
)

@Composable
fun MainScreen(state: UiState, ring: SampleRing, actions: MainActions) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GyroPalette.Slate)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 28.dp, bottom = 40.dp)
    ) {
        Header()
        Spacer(Modifier.height(28.dp))
        Readout(state)
        Spacer(Modifier.height(24.dp))
        BoostButton(state, actions)
        Spacer(Modifier.height(10.dp))
        ProfileTabs(state, actions)
        Spacer(Modifier.height(30.dp))
        LiveGyro(state, ring, actions)
        Spacer(Modifier.height(30.dp))
        GameSection(state, actions)
        Spacer(Modifier.height(30.dp))
        ConditionsSection(state, actions)
        Spacer(Modifier.height(30.dp))
        SensorsSection(state)
        Spacer(Modifier.height(28.dp))
        Text(
            "GyroFix only reads the motion sensors. It never touches or changes the game.",
            style = GyroType.Quiet
        )
    }
}

@Composable
private fun Header() {
    Column {
        Text("GyroFix", style = GyroType.Title)
        Spacer(Modifier.height(2.dp))
        Text(
            "Keeps the gyro at full speed and shows what games actually receive.",
            style = GyroType.Quiet
        )
    }
}

@Composable
private fun Readout(state: UiState) {
    val current = if (state.probeHz > 0f) state.probeHz.roundToInt().toString() else "\u2013"
    val heroColor = if (state.verdict == Verdict.EFFECTIVE) GyroPalette.Amber else GyroPalette.Chalk
    val delay = if (state.probeDelayMs >= 0f) "${formatOne(state.probeDelayMs)} ms" else "n/a"
    val jitter = if (state.probeHz > 0f) "${formatOne(state.probeJitterMs)} ms" else "n/a"

    Column {
        Text("Gyro readings per second reaching games", style = GyroType.Quiet)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(current, style = GyroType.Hero.copy(color = heroColor))
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Hz",
                style = GyroType.Section.copy(color = GyroPalette.Fog),
                modifier = Modifier.padding(bottom = 14.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
        VerdictText(state)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(32.dp)) {
            Figure("Delivery delay", delay)
            Figure("Jitter", jitter)
        }
    }
}

@Composable
private fun VerdictText(state: UiState) {
    val base = state.baselineHz.roundToInt()
    val now = state.probeHz.roundToInt()
    val (color, text) = when (state.verdict) {
        Verdict.BOOST_OFF ->
            GyroPalette.Fog to "Boost is off. This is the normal game-rate stream."
        Verdict.MEASURING ->
            GyroPalette.Fog to "Measuring\u2026"
        Verdict.EFFECTIVE ->
            GyroPalette.Ok to "Boost works. Games now get $now Hz instead of $base Hz."
        Verdict.NO_EFFECT ->
            GyroPalette.Amber to "No change with boost on. Sensor rate is not what slows your aim. " +
                "A software gyro or in-game smoothing is the likely cause."
    }
    Text(text, style = GyroType.Body.copy(color = color))
}

@Composable
private fun BoostButton(state: UiState, actions: MainActions) {
    val on = state.boost.running
    val shape = RoundedCornerShape(32.dp)
    val edge = if (on) GyroPalette.Amber else GyroPalette.Chalk
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(shape)
            .background(if (on) GyroPalette.Amber else Color.Transparent)
            .border(2.dp, edge, shape)
            .clickable(enabled = state.gyroPresent, onClick = actions.onToggleBoost),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (on) "Boost is on. Tap to stop" else "Lock sensors at full speed",
            style = GyroType.Button.copy(color = if (on) GyroPalette.OnAmber else GyroPalette.Chalk)
        )
    }
}

@Composable
private fun ProfileTabs(state: UiState, actions: MainActions) {
    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            BoostProfile.values().forEach { profile ->
                ProfileTab(
                    text = profile.label,
                    selected = profile == state.profile,
                    onClick = { actions.onProfile(profile) }
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(state.profile.hint, style = GyroType.Quiet)
    }
}

@Composable
private fun LiveGyro(state: UiState, ring: SampleRing, actions: MainActions) {
    Column {
        SectionHeader("Live gyro")
        Spacer(Modifier.height(12.dp))
        MotionScope(
            ring = ring,
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            AxisKey("X", GyroPalette.Amber, state.peakX)
            Spacer(Modifier.width(18.dp))
            AxisKey("Y", GyroPalette.Sky, state.peakY)
            Spacer(Modifier.width(18.dp))
            AxisKey("Z", GyroPalette.Rose, state.peakZ)
            Spacer(Modifier.weight(1f))
            TextAction("Reset", actions.onResetPeaks)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Peak speed in rad/s. Tilt forward and back moves X, tilt sideways moves Y, " +
                "spin the phone flat on a table moves Z. An axis that stays near 0 while you " +
                "rotate means this gyro cannot measure that rotation.",
            style = GyroType.Quiet
        )
    }
}

@Composable
private fun GameSection(state: UiState, actions: MainActions) {
    val game = state.game
    Column {
        SectionHeader("Game")
        Spacer(Modifier.height(10.dp))
        Text(
            text = game.label ?: "No game selected",
            style = GyroType.Body.copy(fontWeight = FontWeight.SemiBold)
        )
        Text(
            text = game.packageName ?: "Pick Blood Strike from your installed apps.",
            style = GyroType.Quiet
        )
        Spacer(Modifier.height(14.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlineButton(
                text = "Boost and open",
                onClick = actions.onBoostAndLaunch,
                modifier = Modifier.weight(1f),
                enabled = game.packageName != null && state.gyroPresent
            )
            TextAction("Change", actions.onPickGame)
        }
    }
}

@Composable
private fun ConditionsSection(state: UiState, actions: MainActions) {
    val c = state.conditions
    Column {
        SectionHeader("Before you play")
        Spacer(Modifier.height(6.dp))
        StatusRow(
            label = "Battery saver",
            value = if (c.batterySaver) "On" else "Off",
            level = if (c.batterySaver) Level.Warn else Level.Ok
        )
        StatusRow(
            label = "Heat",
            value = thermalLabel(c.thermalStatus),
            level = thermalLevel(c.thermalStatus)
        )
        StatusRow(
            label = "Background limits",
            value = if (c.backgroundUnrestricted) "None" else "Restricted",
            level = if (c.backgroundUnrestricted) Level.Ok else Level.Warn,
            actionLabel = if (c.backgroundUnrestricted) null else "Fix",
            onAction = actions.onFixBackground
        )
    }
}

@Composable
private fun SensorsSection(state: UiState) {
    val gyroName = state.sensors.firstOrNull()?.takeIf { it.present }?.name
    Column {
        SectionHeader("What this phone reports")
        Spacer(Modifier.height(6.dp))
        state.sensors.forEach { sensor ->
            val value = when {
                !sensor.present -> "Missing"
                sensor.maxHz > 0 -> "Up to ${sensor.maxHz} Hz"
                else -> "Present"
            }
            StatusRow(
                label = sensor.label,
                value = value,
                level = if (sensor.present) Level.Ok else Level.Bad
            )
        }
        Spacer(Modifier.height(10.dp))
        GyroKindNote(state.gyroKind, gyroName)
    }
}

@Composable
private fun GyroKindNote(kind: GyroKind, name: String?) {
    val (color, text) = when (kind) {
        GyroKind.MISSING ->
            GyroPalette.Bad to "Android reports no gyroscope. Games cannot use gyro aiming on this phone."
        GyroKind.HARDWARE ->
            GyroPalette.Ok to "This looks like a real hardware gyro."
        GyroKind.SOFTWARE ->
            GyroPalette.Amber to "This looks like a software gyro, calculated from other sensors. " +
                "It lags by design. Boost can only speed up its inputs."
        GyroKind.UNCLEAR ->
            GyroPalette.Fog to "Could not tell whether the gyro is hardware or software. " +
                "The peak readings above settle it."
    }
    Text(text, style = GyroType.Body.copy(color = color))
    if (!name.isNullOrBlank()) {
        Spacer(Modifier.height(4.dp))
        Text("Reported as $name", style = GyroType.Quiet)
    }
}

private fun thermalLabel(status: Int): String = when (status) {
    -1 -> "Not reported"
    0 -> "Normal"
    1 -> "Warm"
    2 -> "Hot"
    3 -> "Very hot"
    else -> "Critical"
}

private fun thermalLevel(status: Int): Level = when {
    status < 0 -> Level.Quiet
    status == 0 -> Level.Ok
    status == 1 -> Level.Warn
    else -> Level.Bad
}
