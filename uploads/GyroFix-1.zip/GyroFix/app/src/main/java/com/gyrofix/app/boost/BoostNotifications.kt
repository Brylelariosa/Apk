package com.gyrofix.app.boost

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import com.gyrofix.app.R

object BoostNotifications {

    const val CHANNEL_ID = "gyrofix_boost"
    const val NOTIFICATION_ID = 1001

    fun ensureChannel(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.channel_boost),
            NotificationManager.IMPORTANCE_LOW
        )
        channel.description = context.getString(R.string.channel_boost_desc)
        channel.setShowBadge(false)
        manager.createNotificationChannel(channel)
    }

    fun build(context: Context, text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val openIntent = context.packageManager.getLaunchIntentForPackage(context.packageName) ?: Intent()
        val openPending = PendingIntent.getActivity(context, 0, openIntent, flags)

        val stopIntent = Intent(context, BoostService::class.java).setAction(BoostService.ACTION_STOP)
        val stopPending = PendingIntent.getService(context, 1, stopIntent, flags)

        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(context, R.drawable.ic_stat_gyro),
            context.getString(R.string.notif_stop),
            stopPending
        ).build()

        val builder = Notification.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_gyro)
            .setContentTitle(context.getString(R.string.notif_title))
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setCategory(Notification.CATEGORY_SERVICE)
            .setContentIntent(openPending)
            .addAction(stopAction)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return builder.build()
    }
}
