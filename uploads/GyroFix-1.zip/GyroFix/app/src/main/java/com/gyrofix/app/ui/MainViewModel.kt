package com.gyrofix.app.ui

import android.app.Application
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gyrofix.app.boost.BoostController
import com.gyrofix.app.boost.BoostProfile
import com.gyrofix.app.data.Prefs
import com.gyrofix.app.game.AppEntry
import com.gyrofix.app.game.GameLauncher
import com.gyrofix.app.sensor.SampleRing
import com.gyrofix.app.sensor.SensorCatalog
import com.gyrofix.app.sensor.SensorChannel
import com.gyrofix.app.sensor.SensorLooper
import com.gyrofix.app.system.DeviceConditions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context = application.applicationContext
    private val prefs = Prefs(context)
    private val launcher = GameLauncher(context)
    private val catalog = SensorCatalog(context)
    private val conditionsReader = DeviceConditions(context)

    /** Receives the probe's samples; the live scope draws from it. */
    val ring = SampleRing()

    /** Behaves like a typical game: asks for the gyroscope at the normal game rate, nothing faster. */
    private val probe = SensorChannel(
        manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager,
        sensorType = Sensor.TYPE_GYROSCOPE,
        samplingPeriod = SensorManager.SENSOR_DELAY_GAME,
        handler = SensorLooper.handler,
        ring = ring
    )

    private val mutableState = MutableStateFlow(buildInitialState())
    val state: StateFlow<UiState> = mutableState.asStateFlow()

    private val mutableApps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps: StateFlow<List<AppEntry>> = mutableApps.asStateFlow()

    private var ticker: Job? = null
    private var baselineHz = 0f
    private var lastRunningMs = 0L

    fun onForeground() {
        probe.start()
        if (ticker?.isActive == true) return
        ticker = viewModelScope.launch {
            while (isActive) {
                refresh()
                delay(TICK_MS)
            }
        }
    }

    fun onBackground() {
        ticker?.cancel()
        ticker = null
        probe.stop()
    }

    fun startBoost() {
        if (!BoostController.state.value.running) {
            BoostController.start(context, prefs.profile)
        }
    }

    fun stopBoost() {
        BoostController.stop(context)
    }

    fun selectProfile(profile: BoostProfile) {
        prefs.profile = profile
        mutableState.value = mutableState.value.copy(profile = profile)
        if (BoostController.state.value.running) {
            BoostController.start(context, profile)
        }
    }

    fun selectGame(app: AppEntry) {
        prefs.gamePackage = app.packageName
        mutableState.value = mutableState.value.copy(game = GameUi(app.packageName, app.label))
    }

    fun launchGame(): Boolean {
        val packageName = mutableState.value.game.packageName ?: return false
        return launcher.launch(packageName)
    }

    fun loadApps() {
        viewModelScope.launch(Dispatchers.Default) {
            mutableApps.value = launcher.launchableApps()
        }
    }

    fun resetPeaks() {
        ring.resetPeaks()
    }

    override fun onCleared() {
        probe.stop()
        super.onCleared()
    }

    private fun refresh() {
        val boost = BoostController.state.value
        val nowMs = SystemClock.elapsedRealtime()
        val snapshot = probe.meter.snapshot
        val fresh = snapshot.publishedAtNs != 0L &&
            SystemClock.elapsedRealtimeNanos() - snapshot.publishedAtNs < STALE_NS
        val hz = if (fresh) snapshot.hz else 0f

        // The baseline is only trusted once boost has been off long enough for the sensor hub to settle.
        if (boost.running) lastRunningMs = nowMs
        val resting = !boost.running && nowMs - lastRunningMs > RESTING_MS
        if (resting && fresh) baselineHz = snapshot.hz

        val reference = if (baselineHz > 0f) baselineHz else NOMINAL_GAME_HZ
        val verdict = when {
            !boost.running -> Verdict.BOOST_OFF
            !fresh || nowMs - boost.sinceElapsedMs < SETTLE_MS -> Verdict.MEASURING
            hz >= reference * EFFECTIVE_RATIO -> Verdict.EFFECTIVE
            else -> Verdict.NO_EFFECT
        }

        mutableState.value = mutableState.value.copy(
            boost = boost,
            probeHz = hz,
            probeDelayMs = if (fresh) snapshot.delayMs else -1f,
            probeJitterMs = if (fresh) snapshot.jitterMs else 0f,
            baselineHz = reference,
            verdict = verdict,
            peakX = ring.peakX,
            peakY = ring.peakY,
            peakZ = ring.peakZ,
            conditions = conditionsReader.read()
        )
    }

    private fun buildInitialState(): UiState {
        val report = catalog.report()
        return UiState(
            boost = BoostController.state.value,
            profile = prefs.profile,
            gyroPresent = catalog.hasGyroscope,
            gyroKind = report.gyroKind,
            sensors = report.sensors,
            game = resolveGame(),
            conditions = conditionsReader.read()
        )
    }

    private fun resolveGame(): GameUi {
        var packageName = prefs.gamePackage
        if (packageName == null || !launcher.isInstalled(packageName)) {
            packageName = launcher.detectBloodStrike()
            prefs.gamePackage = packageName
        }
        val label = if (packageName != null) launcher.labelOf(packageName) else null
        return GameUi(packageName, label)
    }

    private companion object {
        const val TICK_MS = 250L
        const val STALE_NS = 2_000_000_000L
        const val SETTLE_MS = 2_500L
        const val RESTING_MS = 1_500L
        const val NOMINAL_GAME_HZ = 50f
        const val EFFECTIVE_RATIO = 1.5f
    }
}
