package com.gyrofix.app.sensor

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.SystemClock

/**
 * One registered listener on one sensor.
 * Always asks for zero batching, so the sensor hub delivers every sample immediately.
 * When [ring] is given, the raw x/y/z values are recorded for drawing.
 */
class SensorChannel(
    private val manager: SensorManager,
    val sensorType: Int,
    private val samplingPeriod: Int,
    private val handler: Handler,
    private val ring: SampleRing? = null
) : SensorEventListener {

    val sensor: Sensor? = manager.getDefaultSensor(sensorType)

    /** Replaced with a fresh meter on every [start]. */
    @Volatile
    var meter: RateMeter = RateMeter()
        private set

    @Volatile
    var isStarted: Boolean = false
        private set

    @Synchronized
    fun start(): Boolean {
        val target = sensor ?: return false
        if (isStarted) return true
        meter = RateMeter()
        isStarted = try {
            manager.registerListener(this, target, samplingPeriod, 0, handler)
        } catch (e: RuntimeException) {
            false
        }
        return isStarted
    }

    @Synchronized
    fun stop() {
        if (!isStarted) return
        manager.unregisterListener(this)
        isStarted = false
    }

    override fun onSensorChanged(event: SensorEvent) {
        val now = SystemClock.elapsedRealtimeNanos()
        meter.onSample(now, event.timestamp)
        val recorder = ring
        if (recorder != null) {
            val v = event.values
            recorder.write(now, v[0], v[1], v[2])
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
