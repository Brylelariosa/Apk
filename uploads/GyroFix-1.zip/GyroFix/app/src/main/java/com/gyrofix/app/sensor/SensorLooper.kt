package com.gyrofix.app.sensor

import android.os.Handler
import android.os.HandlerThread
import android.os.Process

/** One shared high-priority thread that receives every sensor callback in the app. */
object SensorLooper {

    val handler: Handler by lazy {
        val thread = object : HandlerThread("gyrofix-sensors") {
            override fun onLooperPrepared() {
                runCatching { Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY) }
            }
        }
        thread.start()
        Handler(thread.looper)
    }
}
