package com.gyrofix.app.sensor

import kotlin.math.abs

/**
 * Lock-free single-writer ring of timestamped 3-axis samples.
 * The sensor thread writes; the UI thread copies out what it wants to draw.
 * A torn read can at worst glitch one pixel at the oldest edge of the scope.
 */
class SampleRing {

    @Volatile
    private var written = 0L

    private val times = LongArray(CAPACITY)
    private val xs = FloatArray(CAPACITY)
    private val ys = FloatArray(CAPACITY)
    private val zs = FloatArray(CAPACITY)

    /** Largest absolute reading per axis since the last [resetPeaks]. */
    @Volatile
    var peakX = 0f
        private set

    @Volatile
    var peakY = 0f
        private set

    @Volatile
    var peakZ = 0f
        private set

    fun write(timeNs: Long, x: Float, y: Float, z: Float) {
        val n = written
        val i = (n and MASK).toInt()
        times[i] = timeNs
        xs[i] = x
        ys[i] = y
        zs[i] = z

        val ax = abs(x)
        val ay = abs(y)
        val az = abs(z)
        if (ax > peakX) peakX = ax
        if (ay > peakY) peakY = ay
        if (az > peakZ) peakZ = az

        written = n + 1
    }

    fun resetPeaks() {
        peakX = 0f
        peakY = 0f
        peakZ = 0f
    }

    /** Copies samples recorded at or after [sinceNs], oldest first, and returns how many were copied. */
    fun readSince(
        sinceNs: Long,
        outT: LongArray,
        outX: FloatArray,
        outY: FloatArray,
        outZ: FloatArray
    ): Int {
        val end = written
        val limit = minOf(end, CAPACITY.toLong(), outT.size.toLong()).toInt()
        var count = 0
        while (count < limit) {
            val i = ((end - 1 - count) and MASK).toInt()
            if (times[i] < sinceNs) break
            count++
        }
        val first = end - count
        for (k in 0 until count) {
            val i = ((first + k) and MASK).toInt()
            outT[k] = times[i]
            outX[k] = xs[i]
            outY[k] = ys[i]
            outZ[k] = zs[i]
        }
        return count
    }

    companion object {
        const val CAPACITY = 4096
        private const val MASK = 4095L
    }
}
