package com.zipapkbuilder.feature.download

import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.Formatters
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/**
 * Verifies a freshly-downloaded ZIP is actually intact, and — for artifact
 * ZIPs specifically — that the APK inside it is a valid, parseable package.
 * Split out of [DownloadManager] as the "is what we downloaded actually
 * good?" concern, used by [DownloadManager]'s two download entry points
 * right after a transfer finishes and before it's saved to Downloads or
 * reported as successful.
 */
class DownloadIntegrity(private val activity: MainActivity) {

    /**
     * Verifies a downloaded ZIP is structurally intact: every entry's data can
     * be fully read and its CRC-32 (stored in the ZIP itself) matches what
     * [ZipInputStream] recomputes while decompressing — the standard signal
     * a ZIP was truncated or corrupted in transit. This is deliberately a full
     * read of every entry's bytes (discarded, not held in memory) rather than
     * just opening the central directory, since a truncated download can
     * still have a readable entry listing but fail partway through the actual
     * data.
     *
     * Used right after a download finishes and before it's saved to Downloads
     * or reported as successful, so a corrupted result is caught immediately
     * instead of silently handing the user a broken file. An empty ZIP (zero
     * entries) is treated as invalid too: a real artifact or log archive
     * always contains at least one entry.
     *
     * Runs on the calling (background) thread; never touches the UI.
     */
    fun verifyZipIntegrity(file: File): Boolean {
        if (!file.exists() || file.length() == 0L) return false
        return try {
            var entryCount = 0
            ZipInputStream(file.inputStream().buffered()).use { zis ->
                val sink = ByteArray(64 * 1024)
                var entry = zis.nextEntry
                while (entry != null) {
                    // Fully drain the entry so ZipInputStream verifies its CRC-32
                    // against the value stored in the ZIP — a mismatch throws.
                    while (zis.read(sink) >= 0) { /* discard */ }
                    zis.closeEntry()
                    entryCount++
                    entry = zis.nextEntry
                }
            }
            entryCount > 0
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Throws if [file] fails [verifyZipIntegrity], after deleting it. This is
     * the one case where deleting a download is correct instead of preserving
     * it for a future resume — the brief's own rule is "never delete partial
     * downloads unless they are corrupted," and a failed CRC check is exactly
     * that determination, not a guess. The thrown message is picked up by the
     * caller's existing catch block, which already offers a manual Retry.
     */
    fun requireZipIntegrity(file: File, label: String) {
        if (!verifyZipIntegrity(file)) {
            file.delete()
            throw Exception("$label failed integrity verification (corrupted or truncated) — please retry.")
        }
    }

    /**
     * Peeks inside a downloaded artifact ZIP for the first `.apk` entry, verifies
     * it as a real APK (via `PackageManager.getPackageArchiveInfo`), and logs its
     * package name, version, and min/target SDK — a quick sanity check of what
     * actually got built, without installing it first. This is the APK-level
     * complement to [verifyZipIntegrity]'s ZIP-level (CRC) check: the ZIP check
     * confirms the bytes arrived intact, this confirms those bytes actually
     * parse as a valid APK. Best-effort: any failure here is logged as a soft
     * note and never interrupts the download flow, since it's a nice-to-have
     * layered on top of the save-to-Downloads path.
     */
    fun logApkInfoFromZip(zipFile: File) {
        var tempApk: File? = null
        try {
            ZipInputStream(zipFile.inputStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".apk", ignoreCase = true)) {
                        val dest = File(activity.cacheDir, "apkinfo_${System.currentTimeMillis()}.apk")
                        FileOutputStream(dest).use { out -> zis.copyTo(out) }
                        tempApk = dest
                        break
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            val apkFile = tempApk ?: return // no .apk inside (e.g. a logs-only artifact)
            @Suppress("DEPRECATION")
            val pkgInfo = activity.packageManager.getPackageArchiveInfo(apkFile.absolutePath, 0)
            if (pkgInfo == null) {
                // The containing ZIP already passed a full CRC-32 check (see
                // verifyZipIntegrity/requireZipIntegrity), so the .apk's bytes
                // themselves arrived intact — but PackageManager still couldn't
                // parse it as a valid APK (e.g. a malformed manifest). Surface
                // that distinctly rather than silently saying nothing, since
                // it's a real (if rare) signal the build output itself is broken.
                activity.appendLog("⚠ APK integrity check failed — the file could not be parsed as a valid APK.")
                return
            }
            val appInfo = pkgInfo.applicationInfo
            activity.appendLog("─────────────────────────────────────")
            activity.appendLog("📦 APK Info")
            activity.appendLog("  ✓ Integrity verified (manifest parsed OK)")
            activity.appendLog("  Package  : ${pkgInfo.packageName}")
            @Suppress("DEPRECATION")
            activity.appendLog("  Version  : ${pkgInfo.versionName ?: "?"} (code ${pkgInfo.versionCode})")
            if (appInfo != null) {
                activity.appendLog("  SDK      : min ${appInfo.minSdkVersion} · target ${appInfo.targetSdkVersion}")
            }
            activity.appendLog("  APK size : ${Formatters.fmtBytes(apkFile.length())}")
        } catch (e: Exception) {
            activity.appendLog("ℹ Could not read APK info: ${e.message}")
        } finally {
            tempApk?.delete()
        }
    }
}
