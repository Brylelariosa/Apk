package com.zipapkbuilder.feature.filemanager

import android.net.Uri
import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.UriUtils
import com.zipapkbuilder.net.GitHubApi

/**
 * Uploads a single local file (picked from the device, not a project ZIP —
 * see [com.zipapkbuilder.feature.build.BuildFlowController] for that) into the
 * repo via the Contents API. Split out of [FileManagerController] since it's
 * a self-contained, independently-triggerable feature (reached from the file
 * manager's "New → Upload File" entry, via [FileOperationController.showNewItemDialog])
 * with no dependency on browsing, editing, or the other file operations.
 */
class FileUploadController(private val activity: MainActivity) {

    /**
     * Streams [uri] from the device straight into a base64-encoded Contents
     * API PUT (see [GitHubApi.uploadStreamingBase64]) — the raw file, its
     * base64 form, and the JSON body are never all held in memory at once,
     * same as [com.zipapkbuilder.feature.build.BuildFlowController]'s ZIP
     * upload, which shares this envelope via [GitHubApi.contentsApiEnvelope].
     * Binary files (images, zips, APKs…) are handled the same way as text —
     * the GitHub Contents API accepts any base-64 payload regardless of MIME
     * type. Files > ~50 MB will be rejected by the API; we warn early.
     */
    fun uploadFileToRepo(
        token: String, owner: String, repo: String, branch: String,
        filePath: String, uri: Uri, refreshPath: String
    ) {
        try {
            val rawLength = UriUtils.resolveFileSize(activity.contentResolver, uri)
            if (rawLength > 50 * 1024 * 1024) {
                activity.appendLog("✗ File too large for GitHub Contents API (> 50 MB)."); return
            }
            activity.appendLog("  Size: ${rawLength / 1024} KB")

            val existingSha = activity.buildFlowController.fetchFileSha(token, owner, repo, filePath)
            val (prefix, suffix) = GitHubApi.contentsApiEnvelope(
                message = "upload: $filePath via ZipApkBuilder [skip ci]", branch = branch, existingSha = existingSha
            )
            val (code, body) = GitHubApi.uploadStreamingBase64(
                token, GitHubApi.apiContents(owner, repo, filePath), "PUT",
                jsonPrefix = prefix,
                source = UriUtils.openInputStreamOrThrow(activity.contentResolver, uri),
                rawLength = rawLength,
                jsonSuffix = suffix,
                isCancelled = { false }, onProgress = { _, _ -> }
            )
            if (code in 200..201) {
                activity.appendLog("✓ Uploaded: $filePath")
            } else {
                activity.appendLog("✗ Upload failed ($code): ${body.take(200)}")
            }
        } catch (e: Exception) {
            activity.appendLog("✗ ${e.message}")
        }
    }
}
