package com.zipapkbuilder.feature.download

import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.model.DownloadTask
import com.zipapkbuilder.net.NetworkReliability
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * The actual byte-transfer mechanics: resumable HTTP GET with Range support,
 * pause/cancel polling, exponential-backoff retry, and offline wait-and-resume.
 * Split out of [DownloadManager] as the one piece that's pure network I/O —
 * no dialog, no queueing, no persistence. [DownloadQueue] calls
 * [performResumableDownload] once per task on one of its worker threads;
 * everything this class needs to report back (progress, status, speed) goes
 * through [DownloadTask]'s own fields rather than any callback, so multiple
 * downloads can run through this at once without fighting over shared state.
 */
class DownloadEngine(
    private val activity: MainActivity,
    private val networkReliability: NetworkReliability
) {

    /**
     * Resolves a GitHub API URL that responds with a redirect (301-308) to its
     * real, time-limited download location, following exactly one hop. Called
     * fresh before every connection attempt by [performResumableDownload]
     * rather than cached, since GitHub's own artifact redirect URL expires
     * after 1 minute — reusing an old one after a long pause or a backoff
     * wait would fail with an auth error even though the artifact is fine.
     */
    fun resolveGithubRedirect(apiUrl: String, token: String): String {
        val conn = (URL(apiUrl).openConnection() as HttpURLConnection).apply {
            setRequestProperty("Authorization", "token $token")
            setRequestProperty("Accept", "application/vnd.github.v3+json")
            instanceFollowRedirects = false
            connectTimeout = 30_000; readTimeout = 30_000
        }
        conn.connect()
        return if (conn.responseCode in 301..308) {
            val loc = conn.getHeaderField("Location")
            conn.disconnect()
            loc ?: apiUrl
        } else {
            conn.disconnect()
            apiUrl
        }
    }

    /**
     * Downloads from whatever URL [task]'s `resolveUrl` returns into
     * [task].destFile, resuming from any bytes already on disk via an HTTP Range
     * request when the server honors it. Reports all progress and status purely
     * through [task]'s own fields — this function never touches a View or posts
     * to [activity.mainHandler] — so it behaves identically whether or not the Download
     * Manager is currently on screen to show it, and so multiple instances of
     * this function (one per worker) can run at once without fighting over
     * shared state the way the single-download version did.
     *
     * `resolveUrl` is called again before every connection attempt — not just
     * once — because the GitHub endpoints this feeds from redirect to a
     * short-lived signed URL, so a stale cached URL would fail after any real
     * pause.
     *
     * - [task].pauseRequested / [task].cancelRequested are checked continuously
     *   and are driven by the manager UI's per-row buttons, which work whether
     *   or not that UI is currently open.
     * - A dropped connection while the device is genuinely offline pauses
     *   automatically (status `WAITING_FOR_NETWORK`) and resumes the instant
     *   connectivity returns (see [NetworkReliability.waitForNetwork]) — this
     *   never counts against [maxRetries]; it's a wait, not a failure.
     * - A transient server-side error (HTTP 429/500/502/503/504) or an I/O
     *   error that occurs while the network still tests as reachable retries
     *   with exponential backoff (2s, 4s, 8s… capped at 30s) up to [maxRetries]
     *   times.
     * - A resume the server rejects (HTTP 416 — the local partial no longer
     *   matches what the server has) is discarded and restarted from 0% once;
     *   a repeat 416 on that fresh attempt is fatal rather than looping forever.
     * - Anything else (storage full, HTTP 401/403/404, cancellation) is fatal
     *   immediately.
     *
     * Must be called from a background thread. [task].destFile's bytes on
     * disk are preserved across every failure path, so resubmitting the same
     * task later resumes instead of restarting.
     */
    fun performResumableDownload(task: DownloadTask, maxRetries: Int = NetworkReliability.MAX_DOWNLOAD_RETRIES) {
        val destFile = task.destFile
        var retryAttempt = 0
        var backoffMs = NetworkReliability.INITIAL_RETRY_BACKOFF_MS
        var rangeRestartUsed = false

        while (true) {
            if (task.cancelRequested) throw Exception("Cancelled by user")
            val existingBytes = if (destFile.exists()) destFile.length() else 0L
            var conn: HttpURLConnection? = null

            try {
                task.status = DownloadTask.Status.CONNECTING
                task.detailText = if (existingBytes > 0) "Resuming…" else "Connecting…"
                val c = (URL(task.resolveUrl()).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    if (existingBytes > 0) setRequestProperty("Range", "bytes=$existingBytes-")
                    connectTimeout = 60_000
                    readTimeout    = 300_000
                }
                conn = c
                c.connect()
                val code = c.responseCode

                if (code != HttpURLConnection.HTTP_OK && code != HttpURLConnection.HTTP_PARTIAL) {
                    c.disconnect()
                    if (code == 416) {
                        if (rangeRestartUsed) {
                            throw Exception("Server rejected the download range even after restarting from 0% (HTTP 416).")
                        }
                        rangeRestartUsed = true
                        task.detailText = "Server rejected resume — restarting from 0%…"
                        destFile.delete()
                        continue
                    }
                    if (code in NetworkReliability.RETRYABLE_HTTP_CODES) {
                        retryAttempt++
                        if (retryAttempt > maxRetries) {
                            throw Exception("Server returned HTTP $code — gave up after $maxRetries retries.")
                        }
                        notifyRetrying(task, retryAttempt, maxRetries, backoffMs)
                        networkReliability.sleepCancellable(backoffMs) { task.cancelRequested }
                        backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
                        continue
                    }
                    throw Exception("Download failed (HTTP $code).")
                }

                // A server that ignores our Range header sends the whole file
                // again from byte 0 — discard the stale partial bytes rather
                // than corrupt the file by appending fresh content onto it.
                val serverIgnoredRange = existingBytes > 0 && code == HttpURLConnection.HTTP_OK
                if (serverIgnoredRange) destFile.delete()
                val effectiveExisting = if (serverIgnoredRange) 0L else existingBytes

                val contentLen = c.contentLengthLong
                val total = when {
                    code == HttpURLConnection.HTTP_PARTIAL ->
                        c.getHeaderField("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
                            ?: (if (contentLen >= 0) contentLen + effectiveExisting else -1L)
                    contentLen >= 0 -> contentLen + effectiveExisting
                    else -> -1L
                }

                val remainingNeeded = if (total > 0) (total - effectiveExisting).coerceAtLeast(0L) else 0L
                if (!hasEnoughStorage(destFile.parentFile ?: activity.cacheDir, remainingNeeded)) {
                    c.disconnect()
                    throw Exception("Not enough free storage for this download (need ~${Formatters.fmtBytes(remainingNeeded)} more).")
                }

                var downloaded = effectiveExisting
                task.totalBytes      = total
                task.downloadedBytes = downloaded
                task.status          = DownloadTask.Status.DOWNLOADING
                task.detailText       = ""

                val buf = ByteArray(32 * 1024)
                var speedStartTime  = System.currentTimeMillis()
                var speedStartBytes = downloaded

                c.inputStream.use { inp ->
                    FileOutputStream(destFile, effectiveExisting > 0).use { out ->
                        while (true) {
                            if (task.cancelRequested) throw Exception("Cancelled by user")
                            if (task.pauseRequested) {
                                task.status = DownloadTask.Status.PAUSED
                                while (task.pauseRequested) {
                                    if (task.cancelRequested) throw Exception("Cancelled by user")
                                    Thread.sleep(150)
                                }
                                task.status = DownloadTask.Status.DOWNLOADING
                            }

                            val n = inp.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            downloaded += n
                            task.downloadedBytes = downloaded

                            val now     = System.currentTimeMillis()
                            val elapsed = now - speedStartTime
                            if (elapsed >= 200) {
                                val speedBps = (downloaded - speedStartBytes) * 1000L / elapsed.coerceAtLeast(1)
                                speedStartTime  = now; speedStartBytes = downloaded
                                task.speedBps = speedBps
                                val remaining = if (total > 0) (total - downloaded).coerceAtLeast(0) else -1L
                                task.etaSeconds = if (total > 0 && speedBps > 0) remaining / speedBps else -1L
                            }
                        }
                    }
                }
                c.disconnect()
                if (task.cancelRequested) throw Exception("Cancelled by user")

                task.downloadedBytes = downloaded
                task.status = DownloadTask.Status.VERIFYING
                task.detailText = "Verifying…"
                return

            } catch (e: Exception) {
                conn?.disconnect()
                if (e.message == "Cancelled by user") throw e
                // Only an I/O-ish failure is eligible for the automatic paths
                // below — e.g. the storage-full Exception thrown above is
                // fatal regardless of connectivity.
                if (e !is java.io.IOException) throw e

                if (!networkReliability.isNetworkAvailable()) {
                    task.status = DownloadTask.Status.WAITING_FOR_NETWORK
                    task.detailText = "⚠ Paused (No Internet) — will resume automatically"
                    val reconnected = networkReliability.waitForNetwork { task.cancelRequested }
                    if (!reconnected) throw Exception("Cancelled by user")
                    task.status = DownloadTask.Status.DOWNLOADING
                    task.detailText = ""
                    continue
                }

                retryAttempt++
                if (retryAttempt > maxRetries) {
                    throw Exception("${Formatters.friendlyError(e)} — gave up after $maxRetries retries.")
                }
                notifyRetrying(task, retryAttempt, maxRetries, backoffMs)
                networkReliability.sleepCancellable(backoffMs) { task.cancelRequested }
                backoffMs = (backoffMs * 2).coerceAtMost(NetworkReliability.MAX_RETRY_BACKOFF_MS)
            }
        }
    }

    /** Sets a "retrying in Ns… (attempt X/Y)" status on [task]. */
    private fun notifyRetrying(task: DownloadTask, attempt: Int, max: Int, backoffMs: Long) {
        task.status = DownloadTask.Status.RETRYING
        task.detailText = "Retrying in ${backoffMs / 1000}s… (attempt $attempt/$max)"
    }

    /**
     * Checks the target directory's filesystem for enough free space before
     * starting a download, so a large artifact fails fast with a clear message
     * instead of partway through with a confusing IOException. Content-length
     * of 0 or less (GitHub didn't report a size) skips the check rather than
     * blocking a legitimate download over a number we don't actually have.
     */
    private fun hasEnoughStorage(dir: java.io.File, requiredBytes: Long): Boolean {
        if (requiredBytes <= 0) return true
        return try {
            dir.usableSpace > requiredBytes + 10 * 1024 * 1024 // +10 MB safety margin
        } catch (_: Exception) {
            true // if we can't tell, don't block the download over it
        }
    }
}
