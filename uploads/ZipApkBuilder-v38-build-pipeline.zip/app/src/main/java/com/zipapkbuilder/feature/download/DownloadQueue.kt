package com.zipapkbuilder.feature.download

import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.FloatingTransferIndicator
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.model.DownloadTask
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Owns every [DownloadTask] the app currently knows about and the worker
 * pool that runs them — queueing, starting, and retrying tasks, and the
 * small per-task bookkeeping ([hasActiveTask], [snapshot], [remove],
 * [removeFinished]) [DownloadDialogController] and [DownloadManager] read
 * and act on. Split out of [DownloadManager] as the scheduling layer between
 * "here's a task to run" ([DownloadManager]'s two entry points) and "here's
 * how to actually transfer its bytes" ([DownloadEngine]).
 *
 * [showManagerDialog] opens the Download Manager dialog — passed in as a
 * callback rather than a direct [DownloadDialogController] reference so this
 * class doesn't need to depend on that concrete class; [DownloadManager]
 * wires the two together.
 */
class DownloadQueue(
    private val activity: MainActivity,
    private val downloadEngine: DownloadEngine,
    private val showManagerDialog: () -> Unit
) {
    /** Every download the manager knows about, newest first. Synchronized since
     *  [downloadExecutor] threads and the main thread both touch it. */
    private val downloadTasks = java.util.Collections.synchronizedList(mutableListOf<DownloadTask>())

    /**
     * Separate from [MainActivity.bgExecutor] on purpose: downloads can be numerous and
     * long-running (paused for minutes waiting on connectivity), and shouldn't be
     * able to starve build/API calls — or vice versa — by sharing one pool. 2
     * workers means up to 2 downloads actually transfer at once; more just queue
     * (shown as status QUEUED) until a slot frees up, which keeps a burst of
     * downloads from saturating a mobile connection.
     */
    private val downloadExecutor: ExecutorService = Executors.newFixedThreadPool(2) { r ->
        Thread(r, "download-worker").apply { isDaemon = true }
    }

    /** Stops accepting new downloads; call from `onDestroy`. This only stops
     *  accepting *new* downloads, it doesn't interrupt ones already running. */
    fun shutdown() = downloadExecutor.shutdown()

    /** True if a non-terminal task with this id is already queued or running —
     *  used to avoid spawning a second copy of the same download. */
    fun hasActiveTask(id: String): Boolean =
        synchronized(downloadTasks) { downloadTasks.any { it.id == id && !it.isTerminal } }

    /** A snapshot of every known task, for the dialog to render without holding the lock. */
    fun snapshot(): List<DownloadTask> = synchronized(downloadTasks) { downloadTasks.toList() }

    /** Drops every task in a terminal state (the "Clear finished" button). */
    fun removeFinished() {
        synchronized(downloadTasks) { downloadTasks.removeAll { it.isTerminal } }
    }

    /** Drops a single terminal task (a row's "Remove" button). */
    fun remove(task: DownloadTask) {
        synchronized(downloadTasks) { downloadTasks.remove(task) }
    }

    /**
     * Best-effort stable id for [downloadUrl], used to name the resumable temp
     * file so a retry reuses the same partial bytes instead of starting over.
     * GitHub's artifact download URL embeds the numeric artifact id
     * (".../actions/artifacts/{id}/zip"); anything else falls back to a hash
     * of the full URL so this can never throw.
     */
    fun stableIdFor(downloadUrl: String): String =
        Regex("artifacts/(\\d+)").find(downloadUrl)?.groupValues?.get(1)
            ?: downloadUrl.hashCode().toString()

    /** Registers [task] with the manager (newest first) and starts it running. */
    fun submit(task: DownloadTask) {
        downloadTasks.add(0, task)
        downloadExecutor.execute { runDownloadTask(task) }
        activity.floatingTransferIndicator.flashStart(FloatingTransferIndicator.Mode.DOWNLOAD) { showManagerDialog() }
    }

    /**
     * Resubmits a FAILED or CANCELLED task from scratch. Safe to call any time
     * after [runDownloadTask] has left it in a terminal state — any bytes already
     * on [DownloadTask.destFile] are untouched, so this resumes rather than
     * restarting, exactly like the automatic retry path does.
     */
    fun retry(task: DownloadTask) {
        if (!task.isTerminal) return
        task.cancelRequested = false
        task.pauseRequested  = false
        task.errorMessage    = null
        task.status = DownloadTask.Status.QUEUED
        task.detailText = "Queued…"
        downloadExecutor.execute { runDownloadTask(task) }
        activity.floatingTransferIndicator.flashStart(FloatingTransferIndicator.Mode.DOWNLOAD) { showManagerDialog() }
    }

    // ── Floating download bubble ────────────────────────────────────────────
    // Replaces the old behavior of force-opening the manager dialog every time
    // a download started. Instead of tracking live progress on the bubble, it
    // just flashes briefly when a download is queued and again (a bit
    // differently — checkmark/warning instead of the plain download icon)
    // once it finishes; the running percentage/speed detail stays exclusively
    // inside the Download Manager dialog, which the bubble opens on tap. See
    // FloatingTransferIndicator's kdoc for the full rationale.

    /**
     * Runs [task] end-to-end on the calling thread: the byte transfer via
     * [DownloadEngine.performResumableDownload], then — on success —
     * [DownloadTask.onSuccess] (which does the save-to-Downloads/integrity-report
     * work specific to each download kind). Leaves [task].status in a terminal
     * state (COMPLETED / FAILED / CANCELLED) no matter how it ends, so the
     * manager UI never has to guess. Must be called from a [downloadExecutor]
     * thread, never the main one.
     */
    private fun runDownloadTask(task: DownloadTask) {
        try {
            downloadEngine.performResumableDownload(task)
            task.onSuccess(task)
            task.status = DownloadTask.Status.COMPLETED
            task.detailText = "Done"
            activity.floatingTransferIndicator.complete(FloatingTransferIndicator.Mode.DOWNLOAD, showRing = false) {
                showManagerDialog()
            }
        } catch (e: Exception) {
            if (e.message == "Cancelled by user") {
                task.status = DownloadTask.Status.CANCELLED
                task.detailText = "Cancelled"
                activity.appendLog("⚠ Download cancelled: ${task.displayName}")
            } else {
                task.status = DownloadTask.Status.FAILED
                task.errorMessage = Formatters.friendlyError(e)
                task.detailText = "Failed"
                activity.appendLog("✗ Download failed: ${task.displayName} — ${Formatters.friendlyError(e)}")
                activity.floatingTransferIndicator.fail(FloatingTransferIndicator.Mode.DOWNLOAD, showRing = false) {
                    showManagerDialog()
                }
            }
        }
    }
}
