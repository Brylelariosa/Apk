package com.zipapkbuilder.feature.download

import com.zipapkbuilder.MainActivity
import com.zipapkbuilder.core.Formatters
import com.zipapkbuilder.core.PrefKeys
import com.zipapkbuilder.model.DownloadTask
import com.zipapkbuilder.net.GitHubApi
import com.zipapkbuilder.net.NetworkReliability
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Coordinator for every downloaded-artifact concern: the resumable, pausable,
 * multi-task download engine; the Download Manager dialog that watches it;
 * ZIP/APK integrity verification; saving into the public Downloads folder;
 * and download history. The actual work is split across four focused,
 * single-responsibility components — this class constructs them (wiring each
 * one's dependencies) and owns the two real "features" ([downloadArtifact],
 * [downloadLatestRunLogs]) that tie GitHub-specific URLs and save/report
 * logic to that generic machinery:
 *
 * - [DownloadEngine] — the resumable HTTP transfer itself
 * - [DownloadQueue] — task list, worker pool, submit/retry/shutdown
 * - [DownloadDialogController] — the Download Manager dialog UI
 * - [DownloadIntegrity] — ZIP/APK verification after a transfer completes
 * - [DownloadHistory] — saving to Downloads + persisted history
 *
 * [downloadQueue] needs to open [downloadDialogController] when a task starts
 * or finishes (the floating bubble's tap target), and [downloadDialogController]
 * needs to read/act on [downloadQueue]'s tasks — [downloadDialogController] is
 * `lateinit` so the queue's callback can capture it by reference before it
 * exists yet, safe here because that callback is never invoked until well
 * after both are fully constructed.
 */
class DownloadManager(
    private val activity: MainActivity,
    private val networkReliability: NetworkReliability
) {
    companion object {
        // How long a resumable partial download (artifact_*/logs_tmp_*) is kept
        // in cache before the cold-start sweep treats it as abandoned. Deliberately
        // long — see cleanupStaleCacheFiles() — so closing the app and coming back
        // later never loses download progress.
        private const val STALE_PARTIAL_DOWNLOAD_MS = 7L * 24 * 60 * 60 * 1000
    }

    private val downloadEngine    = DownloadEngine(activity, networkReliability)
    private val downloadIntegrity = DownloadIntegrity(activity)
    private val downloadHistory   = DownloadHistory(activity)

    private lateinit var downloadDialogController: DownloadDialogController
    private val downloadQueue = DownloadQueue(activity, downloadEngine) { downloadDialogController.showDownloadManagerDialog() }

    init {
        downloadDialogController = DownloadDialogController(activity, downloadQueue)
    }

    /** Stops accepting new downloads; call from `onDestroy`. Same reasoning as the
     *  Activity's own executor shutdown — this only stops accepting *new* downloads,
     *  it doesn't interrupt ones already running. */
    fun shutdown() = downloadQueue.shutdown()

    fun downloadLatestRunLogs() {
        val token  = activity.etToken.text.toString().trim()
        val repo   = activity.etRepo.text.toString().trim()
        val branch = activity.etBranch.text.toString().trim().ifEmpty { "main" }

        if (token.isEmpty()) { activity.appendLog("⚠ Enter your GitHub token first."); return }
        if (repo.isEmpty())  { activity.appendLog("⚠ Enter a repository name first."); return }

        activity.setBusy(true)
        activity.setStatus("Fetching latest run…")
        activity.appendLog("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        activity.appendLog("📥 Looking up the latest run to download its log…")

        // Only the quick metadata lookup below runs under activity.setBusy — once the
        // DownloadTask is handed to downloadQueue.submit(), the actual transfer runs
        // independently on its own worker pool (see DownloadQueue's kdoc), tracked by
        // the Download Manager rather than the global busy flag, so it no longer
        // blocks starting a build or another download while it's in progress.
        activity.bgExecutor.execute {
            try {
                val owner = activity.lastOwner.ifEmpty {
                    (activity.buildFlowController.fetchOwner(token) ?: run {
                        activity.appendLog("✗ Could not verify token.")
                        activity.setStatus("Failed"); activity.setBusy(false); return@execute
                    }).also { activity.lastOwner = it }
                }

                val runsUrl = "${GitHubApi.apiRuns(owner, repo)}?branch=$branch&per_page=1"
                val (code, body) = GitHubApi.httpGet(token, runsUrl)
                if (code != 200) {
                    activity.appendLog("✗ Could not fetch runs (HTTP $code)")
                    activity.setStatus("Failed"); activity.setBusy(false); return@execute
                }
                val runs = JSONObject(body).getJSONArray("workflow_runs")
                if (runs.length() == 0) {
                    activity.appendLog("⚠ No runs found on branch '$branch'")
                    activity.setStatus("No runs"); activity.setBusy(false); return@execute
                }
                val run           = runs.getJSONObject(0)
                val runId         = run.getLong("id")
                val runNum        = run.getInt("run_number")
                val status        = run.optString("status", "")
                val conclusion    = run.optString("conclusion", "")
                val conclusionStr = conclusion.ifEmpty { "in_progress" }
                activity.appendLog("  Run #$runNum  status=$status  conclusion=$conclusionStr")

                // The redirect to the real log ZIP URL is resolved fresh on every
                // attempt inside performResumableDownload rather than just once
                // here — see its doc comment for why a cached redirect isn't safe
                // to reuse across a real pause.
                val logsUrl = "https://api.github.com/repos/$owner/$repo/actions/runs/$runId/logs"
                val baseName = if (activity.selectedZipName.isNotEmpty())
                    activity.selectedZipName.removeSuffix(".zip").removeSuffix(".ZIP") else "logs"
                val fileName = "${baseName}_build_log.zip"
                // Deterministic name (keyed by runId) so a retry — automatic,
                // manual, or after restarting the app — resumes the same partial
                // file instead of starting over from 0%.
                val tmpFile = File(activity.cacheDir, "logs_tmp_${runId}.zip")

                val task = DownloadTask(
                    id = "log_$runId",
                    displayName = fileName,
                    destFile = tmpFile,
                    resolveUrl = {
                        val conn0 = (URL(logsUrl).openConnection() as HttpURLConnection).apply {
                            requestMethod = "GET"
                            setRequestProperty("Authorization", "token $token")
                            setRequestProperty("Accept", "application/vnd.github+json")
                            instanceFollowRedirects = false
                            connectTimeout = 20_000; readTimeout = 60_000
                        }
                        conn0.connect()
                        val respCode = conn0.responseCode
                        when {
                            respCode in 301..308 -> {
                                val loc = conn0.getHeaderField("Location"); conn0.disconnect(); loc ?: logsUrl
                            }
                            respCode == 200 -> { conn0.disconnect(); logsUrl }
                            else -> {
                                conn0.disconnect()
                                throw Exception(if (status == "completed")
                                    "Logs unavailable for run #$runNum (HTTP $respCode) — GitHub deletes logs after 90 days"
                                else
                                    "Logs not ready yet (HTTP $respCode) — run is still in progress, try again shortly")
                            }
                        }
                    },
                    onSuccess = { t ->
                        downloadIntegrity.requireZipIntegrity(t.destFile, "Build log ZIP")
                        val savedPath = downloadHistory.saveZipToDownloads(t.destFile, fileName)
                        t.destFile.delete()
                        t.savedPath = savedPath
                        activity.appendLog("✓ Build log saved to Downloads!")
                        activity.appendLog("  File : $fileName")
                        activity.appendLog("  Path : $savedPath")
                    }
                )
                downloadQueue.submit(task)
                activity.appendLog("↻ Downloading — watch the floating icon, or tap 📥 in the header for details.")
                activity.setStatus("Ready ✓")

            } catch (e: Exception) {
                activity.appendLog("✗ Error: ${Formatters.friendlyError(e)}")
                activity.setStatus("Failed")
            } finally {
                activity.setBusy(false)
            }
        }
    }

    /**
     * Starts (or resumes) downloading the given artifact via the Download
     * Manager. Unlike the old single-download flow, this no longer blocks on
     * or sets the global busy flag — the transfer itself runs independently on
     * [DownloadQueue]'s worker pool, tracked as a [DownloadTask] the user can
     * watch, pause, or cancel from [showDownloadManagerDialog] at any time,
     * whether or not this specific call is what started it.
     */
    fun downloadArtifact(downloadUrl: String) {
        val token = activity.etToken.text.toString().trim()
        val rawName = activity.prefs.getString(PrefKeys.PREF_ARTIFACT_NAME, "artifact") ?: "artifact"
        val zipFileName = if (rawName.endsWith(".zip", ignoreCase = true)) rawName else "$rawName.zip"

        // Deterministic per-artifact id (not a timestamp) so both the file on disk
        // and the task's identity survive a retry — automatic, manual, or after
        // restarting the app — instead of orphaning progress and starting at 0%.
        val artifactId = downloadQueue.stableIdFor(downloadUrl)
        val taskId = "artifact_$artifactId"

        // Tapping the button twice (or once from here and once from a saved
        // build's restore path) shouldn't spawn a second copy of the same
        // download — just surface the one already running.
        if (downloadQueue.hasActiveTask(taskId)) {
            activity.appendLog("ℹ Already downloading '$zipFileName' — see the Download Manager.")
            showDownloadManagerDialog()
            return
        }

        val artifactZip = File(activity.cacheDir, "artifact_$artifactId.zip")
        val task = DownloadTask(
            id = taskId,
            displayName = zipFileName,
            destFile = artifactZip,
            // GitHub's artifact redirect URL expires 1 minute after it's issued
            // (per GitHub's REST API docs), so it's re-resolved fresh on every
            // connection attempt inside performResumableDownload rather than
            // resolved once up front.
            resolveUrl = { downloadEngine.resolveGithubRedirect(downloadUrl, token) },
            onSuccess = { t ->
                downloadIntegrity.requireZipIntegrity(t.destFile, "Artifact ZIP")
                val savedPath = downloadHistory.saveZipToDownloads(t.destFile, zipFileName)
                t.savedPath = savedPath
                activity.appendLog("✓ Artifact saved to Downloads!")
                activity.appendLog("  File : $zipFileName")
                activity.appendLog("  Path : $savedPath")
                activity.appendLog("  Open your Downloads app to find it anytime.")
                downloadIntegrity.logApkInfoFromZip(t.destFile)
                t.destFile.delete() // the cache copy is no longer needed — it's saved to Downloads now
            }
        )
        downloadQueue.submit(task)
        activity.appendLog("📥 Downloading — watch the floating icon, or tap 📥 in the header for details.")
    }

    fun showDownloadManagerDialog() = downloadDialogController.showDownloadManagerDialog()

    fun loadDownloadHistory(): List<JSONObject> = downloadHistory.loadDownloadHistory()

    fun cleanupStaleCacheFiles() {
        val shortLived  = setOf("apkinfo_")
        val longLived   = setOf("artifact_", "logs_tmp_")
        val now = System.currentTimeMillis()
        val staleShortBefore = now - 2 * 60_000L
        val stalePartialBefore = now - STALE_PARTIAL_DOWNLOAD_MS
        try {
            var freedBytes = 0L
            var deletedCount = 0
            activity.cacheDir.listFiles()?.forEach { f ->
                val threshold = when {
                    shortLived.any { f.name.startsWith(it) } -> staleShortBefore
                    longLived.any  { f.name.startsWith(it) } -> stalePartialBefore
                    else -> return@forEach
                }
                if (f.lastModified() < threshold) {
                    val len = f.length()
                    if (f.delete()) { deletedCount++; freedBytes += len }
                }
            }
            if (deletedCount > 0) {
                activity.appendLog("🧹 Cleaned up $deletedCount leftover temp file(s) (${Formatters.fmtBytes(freedBytes)}) from a previous session.")
            }
        } catch (_: Exception) {
            // Cache cleanup is a hygiene nice-to-have — never worth surfacing an error for.
        }
    }
}
