package com.mangatool.app.adapter

import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.mangatool.app.R
import java.io.File
import java.text.DecimalFormat

data class FileEntry(val file: File, val isParent: Boolean = false)

class FileManagerAdapter(
    private val onFolderClick: (File) -> Unit,
    private val onSelectionChanged: (Set<File>) -> Unit
) : RecyclerView.Adapter<FileManagerAdapter.VH>() {

    companion object {
        // Payload for selection-only partial rebind — avoids re-setting icon/name/info.
        private const val PAYLOAD_SELECTION = "sel"
    }

    private var entries: List<FileEntry> = emptyList()
    private val selected = mutableSetOf<File>()

    fun setEntries(list: List<FileEntry>) {
        val oldEntries = entries
        entries = list
        selected.clear()
        DiffUtil.calculateDiff(object : DiffUtil.Callback() {
            override fun getOldListSize() = oldEntries.size
            override fun getNewListSize() = entries.size
            override fun areItemsTheSame(o: Int, n: Int) =
                oldEntries[o].file.absolutePath == entries[n].file.absolutePath &&
                oldEntries[o].isParent == entries[n].isParent
            override fun areContentsTheSame(o: Int, n: Int) = areItemsTheSame(o, n)
        }).dispatchUpdatesTo(this)
        onSelectionChanged(selected)
    }

    fun selectAll() {
        selected.clear()
        entries.filter { !it.isParent && !it.file.isDirectory }.forEach { selected.add(it.file) }
        // Payload-only rebind: only updates check/background, skips icon+name+info.
        notifyItemRangeChanged(0, entries.size, PAYLOAD_SELECTION)
        onSelectionChanged(selected)
    }

    fun clearSelection() {
        selected.clear()
        notifyItemRangeChanged(0, entries.size, PAYLOAD_SELECTION)
        onSelectionChanged(selected)
    }

    fun getSelected(): Set<File> = selected.toSet()

    /**
     * Long-press "select this and everything of the same type above it" —
     * e.g. hold an .mhtml row and every .mhtml file listed above it (closer
     * to the top of the current folder) gets selected too in one gesture,
     * instead of tapping each one individually.
     *
     * "Above" is scoped to the current folder listing only (not recursive
     * into subfolders) since entries is a flat, already-sorted list of the
     * folder the user is currently looking at.
     */
    private fun selectRangeAbove(position: Int, view: View) {
        val target = entries.getOrNull(position) ?: return
        if (target.isParent || target.file.isDirectory) return
        val ext = target.file.extension.lowercase()

        var added = 0
        for (i in 0..position) {
            val e = entries[i]
            if (e.isParent || e.file.isDirectory) continue
            if (e.file.extension.lowercase() == ext && selected.add(e.file)) added++
        }
        if (added == 0) return // target itself was already selected — nothing new to do

        view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        notifyItemRangeChanged(0, position + 1, PAYLOAD_SELECTION)
        onSelectionChanged(selected)
        val label = if (ext.isEmpty()) "matching" else ".$ext"
        Toast.makeText(
            view.context,
            "Selected $added $label file${if (added == 1) "" else "s"} above",
            Toast.LENGTH_SHORT
        ).show()
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.ivFileIcon)
        val name: TextView  = v.findViewById(R.id.tvFileName)
        val info: TextView  = v.findViewById(R.id.tvFileInfo)
        val check: View     = v.findViewById(R.id.vCheck)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false))

    override fun getItemCount() = entries.size

    /** Payload-aware partial rebind — only updates selection visuals. */
    override fun onBindViewHolder(holder: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_SELECTION }) {
            val entry = entries.getOrNull(position) ?: return
            if (!entry.isParent && !entry.file.isDirectory) {
                val isSelected = selected.contains(entry.file)
                holder.check.visibility = if (isSelected) View.VISIBLE else View.INVISIBLE
                holder.itemView.setBackgroundResource(
                    if (isSelected) R.drawable.bg_file_item_selected else R.drawable.bg_file_item
                )
            }
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val entry = entries[position]
        val file  = entry.file

        if (entry.isParent) {
            holder.name.text = "↑  Parent folder"
            holder.info.text = ""
            holder.icon.setImageResource(android.R.drawable.ic_menu_revert)
            holder.check.visibility = View.GONE
            holder.itemView.setBackgroundResource(R.drawable.bg_file_item_parent)
            holder.itemView.setOnClickListener { onFolderClick(file) }
            holder.itemView.setOnLongClickListener(null)
            return
        }

        if (file.isDirectory) {
            val count = file.listFiles()?.size ?: 0
            holder.name.text = file.name
            holder.info.text = "$count item${if (count != 1) "s" else ""}"
            holder.icon.setImageResource(android.R.drawable.ic_menu_agenda)
            holder.check.visibility = View.GONE
            holder.itemView.setBackgroundResource(R.drawable.bg_file_item)
            holder.itemView.setOnClickListener { onFolderClick(file) }
            holder.itemView.setOnLongClickListener(null)
        } else {
            val ext = file.extension.lowercase()
            holder.name.text = file.name
            holder.info.text = formatSize(file.length())
            holder.icon.setImageResource(
                if (ext == "mhtml" || ext == "mht") android.R.drawable.ic_menu_save
                else android.R.drawable.ic_menu_gallery
            )
            val isSelected = selected.contains(file)
            holder.check.visibility = if (isSelected) View.VISIBLE else View.INVISIBLE
            holder.itemView.setBackgroundResource(
                if (isSelected) R.drawable.bg_file_item_selected else R.drawable.bg_file_item
            )
            holder.itemView.setOnClickListener {
                val livePos = holder.bindingAdapterPosition.takeIf { it >= 0 } ?: position
                val liveFile = entries.getOrNull(livePos)?.file ?: return@setOnClickListener
                if (selected.contains(liveFile)) selected.remove(liveFile) else selected.add(liveFile)
                notifyItemChanged(livePos, PAYLOAD_SELECTION)
                onSelectionChanged(selected)
            }
            holder.itemView.setOnLongClickListener {
                val livePos = holder.bindingAdapterPosition.takeIf { it >= 0 } ?: position
                selectRangeAbove(livePos, holder.itemView)
                true
            }
        }
    }

    private fun formatSize(bytes: Long): String = when {
        bytes < 1_024L     -> "$bytes B"
        bytes < 1_048_576L -> "${bytes / 1_024} KB"
        else               -> DecimalFormat("#.#").format(bytes.toDouble() / 1_048_576.0) + " MB"
    }
}

