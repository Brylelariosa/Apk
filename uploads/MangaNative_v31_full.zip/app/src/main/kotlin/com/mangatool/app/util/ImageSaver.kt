package com.mangatool.app.util

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.core.content.FileProvider
import com.mangatool.app.model.ImageGroup
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

object ImageSaver {

    data class Progress(val message: String, val percent: Int)
    data class SaveResult(val uris: List<Uri>, val folderName: String)

    // ── Concurrency cap for merge encode ──────────────────────────────────────
    // Each merge holds ~20–32 MB in RAM:
    //   2 × full-res source Bitmaps  (e.g. 2 × ~8 MB for 1200×1800 ARGB_8888)
    //   + 1 composite result Bitmap  (~16 MB for the joined canvas)
    // Semaphore(2) caps peak heap at ~64 MB regardless of library size,
    // preventing OOM on devices with ≤ 2 GB RAM.
    private val mergeSemaphore = Semaphore(2)

    // ── Cache hygiene ─────────────────────────────────────────────────────────
    /**
     * Delete the entire share_temp cache. Call:
     *  - on app start (onCreate)
     *  - after the share intent is sent
     *  - when the user resets
     * This prevents the cache from growing indefinitely across sessions.
     */
    fun clearShareCache(context: Context) {
        File(context.cacheDir, "share_temp").deleteRecursively()
    }

    // ── Build share URIs (temp cache, no gallery save) ────────────────────────
    /**
     * Writes images to cache/share_temp and returns FileProvider URIs for sharing.
     *
     * Extract mode (isMerge = false):
     *   ALL formats — JPEG, PNG, WebP, GIF — are losslessly byte-copied.
     *   Zero decoding, zero re-encoding, zero quality loss.
     *   Format and extension are preserved exactly:
     *     JPEG → .jpg, PNG → .png, WebP → .webp, GIF → .gif
     *
     * Merge mode (isMerge = true):
     *   Pairs are merged (full ARGB_8888 quality) then PNG-compressed via
     *   Bitmap.compress() streamed DIRECTLY into a FileOutputStream.
     *   No intermediate ByteArray is ever allocated — the compressed bytes
     *   flow from the codec straight to disk.
     *   Bounded by mergeSemaphore(2) to prevent OOM on large libraries.
     */
    suspend fun buildShareUris(
        context: Context,
        groups: List<ImageGroup>,
        isMerge: Boolean,
        onProgress: (Progress) -> Unit
    ): List<Uri> = coroutineScope {
        val sessionDir = File(context.cacheDir, "share_temp/${System.currentTimeMillis()}")
            .also { it.mkdirs() }
        val authority = "${context.packageName}.fileprovider"

        val uris: List<Uri> = if (isMerge) {

            // ── Merge path ────────────────────────────────────────────────────
            data class PairTask(
                val groupRef: com.mangatool.app.model.ImageGroup,
                val pairIdx:  Int,
                val pair:     List<com.mangatool.app.model.ImageItem>
            )
            val tasks = mutableListOf<PairTask>()
            groups.forEach { group ->
                ImageMerger.pairImages(group.displayImages)
                    .forEachIndexed { i, pair -> tasks.add(PairTask(group, i, pair)) }
            }
            val total = tasks.size.coerceAtLeast(1)
            onProgress(Progress("Preparing 0/$total…", 0))

            tasks.mapIndexed { idx, task ->
                async(Dispatchers.IO) {
                    // Only 2 full-res merges live in RAM at any time
                    mergeSemaphore.withPermit {
                        val swapped = task.groupRef.pairSwaps.contains(task.pairIdx)
                        val bm = ImageMerger.merge(task.pair, swapped)
                            ?: return@withPermit null

                        val file = File(
                            sessionDir,
                            "${(idx + 1).toString().padStart(4, '0')}.png"
                        )
                        // Direct stream: Bitmap.compress() writes into FileOutputStream.
                        // No ByteArray is allocated — codec output flows straight to disk.
                        FileOutputStream(file).buffered(65_536).use { out ->
                            bm.compress(Bitmap.CompressFormat.PNG, 0, out)
                        }
                        bm.recycle()

                        onProgress(Progress(
                            "Preparing ${idx + 1}/$total…",
                            ((idx + 1) * 100) / total
                        ))
                        file
                    }
                }
            }.awaitAll()
                .filterNotNull()
                .map { FileProvider.getUriForFile(context, authority, it) }

        } else {

            // ── Extract path ──────────────────────────────────────────────────
            val allImages = groups.flatMap { it.displayImages }
            val total     = allImages.size.coerceAtLeast(1)
            onProgress(Progress("Preparing 0/$total…", 0))

            allImages.mapIndexed { idx, img ->
                async(Dispatchers.IO) {
                    // Preserve original extension exactly.
                    // Normalise "jpeg" → "jpg" for consistency; blank falls back to "png".
                    val outExt = when (img.ext.lowercase()) {
                        "jpeg" -> "jpg"
                        ""     -> "png"
                        else   -> img.ext.lowercase()
                    }
                    val file = File(
                        sessionDir,
                        "${(idx + 1).toString().padStart(4, '0')}.$outExt"
                    )
                    // Lossless byte copy — no decode, no re-encode, no quality loss.
                    // JPEG→JPEG, PNG→PNG, WebP→WebP, GIF→GIF.
                    File(img.filePath).inputStream().buffered(65_536).use { src ->
                        file.outputStream().buffered(65_536).use { dst -> src.copyTo(dst) }
                    }

                    onProgress(Progress(
                        "Preparing ${idx + 1}/$total…",
                        ((idx + 1) * 100) / total
                    ))
                    file
                }
            }.awaitAll()
                .map { FileProvider.getUriForFile(context, authority, it) }
        }

        onProgress(Progress("Ready", 100))
        uris
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    @Suppress("unused")   // available for callers building explicit Intent MIME types
    private fun mimeForExt(ext: String) = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png"         -> "image/png"
        "webp"        -> "image/webp"
        "gif"         -> "image/gif"
        else          -> "image/*"
    }

    private fun String.sanitize() =
        replace(Regex("""[\\/:"*?<>|]"""), "_").trim().ifBlank { "MIE_Export" }
}

// NOTE: toPngBytes() has been removed.
// FolderSaver.saveMergeToTree() and ImageSaver.buildShareUris() now stream
// Bitmap.compress() directly into the target OutputStream, eliminating the
// intermediate ByteArray allocation that toPngBytes() caused.
