// Top-level build file: plugin versions only. The module configuration lives in app/build.gradle.kts.
plugins {
    id("com.android.application") version "8.3.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
