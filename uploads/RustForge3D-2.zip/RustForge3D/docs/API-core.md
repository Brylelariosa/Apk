# Core API digest (forge-math, forge-json, forge-mesh) — signatures only; read the source file named in each heading only if you need details


## forge-math/src/lib.rs
  pub use mat::
  pub use quat::
  pub use shapes::
  pub use vec::
  pub const PI: f32 = std::f32::consts::PI
  pub const TAU: f32 = std::f32::consts::TAU
  pub fn radians(deg: f32) -> f32
  pub fn degrees(rad: f32) -> f32
  pub fn lerp(a: f32, b: f32, t: f32) -> f32
  pub fn smoothstep(e0: f32, e1: f32, x: f32) -> f32
  pub fn snap(v: f32, step: f32) -> f32   // Round `v` to the nearest multiple of `step` (no-op for non-positive steps).

## forge-math/src/mat.rs
  pub struct Mat3 {…}
  pub struct Mat4 {…}
  impl Default for Mat3 {
  impl Default for Mat4 {
  impl Mat3 {
    pub const IDENTITY: Mat3 = Mat3
    pub const ZERO: Mat3 = Mat3
    pub const fn from_cols(x: Vec3, y: Vec3, z: Vec3) -> Mat3
    pub fn from_diagonal(d: Vec3) -> Mat3
    pub fn from_quat(q: Quat) -> Mat3
    pub fn from_rotation_x(a: f32) -> Mat3
    pub fn from_rotation_y(a: f32) -> Mat3
    pub fn from_rotation_z(a: f32) -> Mat3
    pub fn at(&self, row: usize, col: usize) -> f32   // Element at (row, col).
    pub fn row(&self, r: usize) -> Vec3
    pub fn transpose(&self) -> Mat3
    pub fn determinant(&self) -> f32
    pub fn try_inverse(&self) -> Option<Mat3>
    pub fn inverse(&self) -> Mat3   // Inverse, or identity when singular (never NaN).
    pub fn mul_vec3(&self, v: Vec3) -> Vec3
    pub fn mul_mat3(&self, o: &Mat3) -> Mat3
    pub fn to_cols_array(&self) -> [f32; 9]
  impl Mul for Mat3 {
  impl Mul<Vec3> for Mat3 {
  impl Mat4 {
    pub const IDENTITY: Mat4 = Mat4
    pub const ZERO: Mat4 = Mat4
    pub const fn from_cols(x: Vec4, y: Vec4, z: Vec4, w: Vec4) -> Mat4
    pub fn from_cols_array(a: &[f32; 16]) -> Mat4
    pub fn to_cols_array(&self) -> [f32; 16]
    pub fn from_translation(t: Vec3) -> Mat4
    pub fn from_scale(s: Vec3) -> Mat4
    pub fn from_mat3(m: Mat3) -> Mat4
    pub fn from_quat(q: Quat) -> Mat4
    pub fn from_scale_rotation_translation(scale: Vec3, rot: Quat, trans: Vec3) -> Mat4   // T * R * S
    pub fn from_trs_mat3(scale: Vec3, rot: &Mat3, trans: Vec3) -> Mat4   // T * R3 * S where R3 is an arbitrary rotation matrix.
    pub fn perspective_rh(fov_y: f32, aspect: f32, near: f32, far: f32) -> Mat4   // Right-handed perspective, depth 0..1, vertical field of view in radians.
    pub fn orthographic_rh(left: f32, right: f32, bottom: f32, top: f32, near: f32, far: f32) -> Mat4   // Right-handed orthographic, depth 0..1.
    pub fn look_at_rh(eye: Vec3, center: Vec3, up: Vec3) -> Mat4   // View matrix looking from `eye` towards `center` (right-handed, camera looks down -Z).
    pub fn col(&self, i: usize) -> Vec4
    pub fn at(&self, row: usize, col: usize) -> f32   // Element at (row, col).
    pub fn translation(&self) -> Vec3
    pub fn set_translation(&mut self, t: Vec3)
    pub fn mat3(&self) -> Mat3
    pub fn transpose(&self) -> Mat4
    pub fn determinant(&self) -> f32
    pub fn try_inverse(&self) -> Option<Mat4>
    pub fn inverse(&self) -> Mat4   // Inverse, or identity when singular (never NaN).
    pub fn mul_vec4(&self, v: Vec4) -> Vec4
    pub fn mul_mat4(&self, o: &Mat4) -> Mat4
    pub fn transform_point3(&self, p: Vec3) -> Vec3
    pub fn transform_vector3(&self, v: Vec3) -> Vec3
    pub fn project_point3(&self, p: Vec3) -> Option<Vec3>   // Full projective transform with perspective divide. Returns None when w is ~0.
    pub fn normal_matrix(&self) -> Mat3   // Inverse-transpose of the upper 3x3: use for transforming normals.
    pub fn to_scale_rotation_translation(&self) -> (Vec3, Quat, Vec3)   // Decompose a T*R*S matrix. A negative determinant is folded into a negative X scale.
  impl Mul for Mat4 {
  impl Mul<Vec4> for Mat4 {

## forge-math/src/quat.rs
  pub enum EulerOrder {…}   // Rotation order of an Euler triple. `XYZ` means: rotate about X first, then Y, then Z
  impl EulerOrder {
    pub fn axes(self) -> [usize; 3]   // Axis indices in application order (first applied first).
    pub fn name(self) -> &'static str
    pub fn from_name(s: &str) -> Option<EulerOrder>
  pub struct Quat {…}
  impl Default for Quat {
  impl Quat {
    pub const IDENTITY: Quat = Quat
    pub const fn from_xyzw(x: f32, y: f32, z: f32, w: f32) -> Quat
    pub fn from_axis_angle(axis: Vec3, angle: f32) -> Quat
    pub fn from_rotation_x(a: f32) -> Quat
    pub fn from_rotation_y(a: f32) -> Quat
    pub fn from_rotation_z(a: f32) -> Quat
    pub fn dot(self, o: Quat) -> f32
    pub fn length(self) -> f32
    pub fn normalize(self) -> Quat
    pub fn conjugate(self) -> Quat
    pub fn inverse(self) -> Quat
    pub fn mul_quat(self, o: Quat) -> Quat
    pub fn mul_vec3(self, v: Vec3) -> Vec3
    pub fn slerp(self, mut b: Quat, t: f32) -> Quat
    pub fn from_rotation_arc(from: Vec3, to: Vec3) -> Quat   // Shortest rotation taking unit vector `from` to unit vector `to`.
    pub fn to_axis_angle(self) -> (Vec3, f32)
    pub fn from_mat3(m: &Mat3) -> Quat
    pub fn to_mat3(self) -> Mat3
    pub fn from_euler(order: EulerOrder, e: Vec3) -> Quat   // Blender-style Euler: angles `e = (about X, about Y, about Z)` applied in `order`.
    pub fn to_euler(self, order: EulerOrder) -> Vec3
  impl Mul for Quat {
  impl Mul<Vec3> for Quat {
  pub fn euler_to_mat3(order: EulerOrder, e: Vec3) -> Mat3   // Rotation matrix for Euler angles `e` in `order` (first axis applied first).
  pub fn euler_from_mat3(order: EulerOrder, m: &Mat3, compat: Option<Vec3>) -> Vec3   // Euler angles `(about X, about Y, about Z)` reproducing rotation matrix `m` in `order`.

## forge-math/src/shapes.rs
  pub struct Aabb {…}
  impl Default for Aabb {
  impl Aabb {
    pub const EMPTY: Aabb = Aabb   // Inverted box that any `expand_*` call turns into a valid one.
    pub fn new(min: Vec3, max: Vec3) -> Aabb
    pub fn from_points<I: IntoIterator<Item = Vec3>>(pts: I) -> Aabb
    pub fn is_empty(&self) -> bool
    pub fn expand_point(&mut self, p: Vec3)
    pub fn expand_aabb(&mut self, o: &Aabb)
    pub fn union(&self, o: &Aabb) -> Aabb
    pub fn center(&self) -> Vec3
    pub fn size(&self) -> Vec3
    pub fn half_extents(&self) -> Vec3
    pub fn radius(&self) -> f32   // Radius of the bounding sphere around `center()`.
    pub fn surface_area(&self) -> f32
    pub fn contains_point(&self, p: Vec3) -> bool
    pub fn intersects(&self, o: &Aabb) -> bool
    pub fn inflate(&self, d: f32) -> Aabb
    pub fn distance_squared_to_point(&self, p: Vec3) -> f32
    pub fn transformed(&self, m: &Mat4) -> Aabb   // Bounds of the 8 transformed corners.
    pub fn ray_intersect(&self, ray: &Ray, t_min: f32, t_max: f32) -> Option<(f32, f32)>   // Slab test. Returns (t_near, t_far) clipped to [t_min, t_max] when the ray hits.
  pub struct Ray {…}
  pub struct TriHit {…}
  impl Ray {
    pub fn new(origin: Vec3, dir: Vec3) -> Ray
    pub fn at(&self, t: f32) -> Vec3
    pub fn intersect_triangle(&self, a: Vec3, b: Vec3, c: Vec3) -> Option<TriHit>   // Moller-Trumbore, double sided.
    pub fn intersect_plane(&self, plane: &Plane) -> Option<f32>
    pub fn distance_to_point(&self, p: Vec3) -> f32
    pub fn closest_to_line(&self, p: Vec3, d: Vec3) -> Option<(f32, f32, f32)>   // Closest approach between this ray and the infinite line `(p, d)`.
    pub fn closest_to_segment(&self, a: Vec3, b: Vec3) -> (f32, f32, f32)   // Closest approach to the finite segment a..b: (t on the ray, param 0..1 on the segment, distance).
  pub struct Plane {…}
  impl Plane {
    pub fn from_point_normal(p: Vec3, n: Vec3) -> Plane
    pub fn signed_distance(&self, p: Vec3) -> f32

## forge-math/src/vec.rs
  pub struct Vec2 {…}
  pub struct Vec3 {…}
  pub struct Vec4 {…}
  impl Vec2 {
    pub const ZERO: Vec2 = Vec2
    pub const ONE: Vec2 = Vec2
    pub const fn new(x: f32, y: f32) -> Vec2
    pub const fn splat(v: f32) -> Vec2
    pub fn dot(self, o: Vec2) -> f32
    pub fn perp_dot(self, o: Vec2) -> f32   // 2D cross product (z of the 3D cross).
    pub fn length_squared(self) -> f32
    pub fn length(self) -> f32
    pub fn distance(self, o: Vec2) -> f32
    pub fn normalize(self) -> Vec2
    pub fn lerp(self, o: Vec2, t: f32) -> Vec2
    pub fn min(self, o: Vec2) -> Vec2
    pub fn max(self, o: Vec2) -> Vec2
    pub fn abs(self) -> Vec2
    pub fn perp(self) -> Vec2
    pub fn extend(self, z: f32) -> Vec3
    pub fn to_array(self) -> [f32; 2]
    pub fn from_array(a: [f32; 2]) -> Vec2
    pub fn is_finite(self) -> bool
  impl Index<usize> for Vec2 {
  impl IndexMut<usize> for Vec2 {
  impl From<[f32; 2]> for Vec2 {
  impl Vec3 {
    pub const ZERO: Vec3 = Vec3
    pub const ONE: Vec3 = Vec3
    pub const X: Vec3 = Vec3
    pub const Y: Vec3 = Vec3
    pub const Z: Vec3 = Vec3
    pub const NEG_X: Vec3 = Vec3
    pub const NEG_Y: Vec3 = Vec3
    pub const NEG_Z: Vec3 = Vec3
    pub const AXES: [Vec3; 3] = [Vec3::X, Vec3::Y, Vec3::Z]
    pub const fn new(x: f32, y: f32, z: f32) -> Vec3
    pub const fn splat(v: f32) -> Vec3
    pub fn dot(self, o: Vec3) -> f32
    pub fn cross(self, o: Vec3) -> Vec3
    pub fn length_squared(self) -> f32
    pub fn length(self) -> f32
    pub fn distance(self, o: Vec3) -> f32
    pub fn distance_squared(self, o: Vec3) -> f32
    pub fn normalize(self) -> Vec3   // Normalised copy; the zero vector (or anything shorter than 1e-20) maps to zero. Never NaN.
    pub fn try_normalize(self) -> Option<Vec3>
    pub fn lerp(self, o: Vec3, t: f32) -> Vec3
    pub fn min(self, o: Vec3) -> Vec3
    pub fn max(self, o: Vec3) -> Vec3
    pub fn abs(self) -> Vec3
    pub fn clamp(self, lo: Vec3, hi: Vec3) -> Vec3
    pub fn min_element(self) -> f32
    pub fn max_element(self) -> f32
    pub fn max_abs_axis(self) -> usize   // Index (0..3) of the component with the largest absolute value.
    pub fn floor(self) -> Vec3
    pub fn round(self) -> Vec3
    pub fn is_finite(self) -> bool
    pub fn extend(self, w: f32) -> Vec4
    pub fn xy(self) -> Vec2
    pub fn project_onto(self, o: Vec3) -> Vec3
    pub fn reflect(self, n: Vec3) -> Vec3
    pub fn angle_between(self, o: Vec3) -> f32
    pub fn any_orthogonal(self) -> Vec3   // Some unit vector perpendicular to `self` (self need not be normalised).
    pub fn to_array(self) -> [f32; 3]
    pub fn from_array(a: [f32; 3]) -> Vec3
    pub fn abs_diff_eq(self, o: Vec3, eps: f32) -> bool   // Component-wise approximate equality.
  impl Index<usize> for Vec3 {
  impl IndexMut<usize> for Vec3 {
  impl From<[f32; 3]> for Vec3 {
  impl From<Vec3> for [f32; 3] {
  impl From<(f32, f32, f32)> for Vec3 {
  impl Vec4 {
    pub const ZERO: Vec4 = Vec4
    pub const fn new(x: f32, y: f32, z: f32, w: f32) -> Vec4
    pub const fn splat(v: f32) -> Vec4
    pub fn dot(self, o: Vec4) -> f32
    pub fn truncate(self) -> Vec3
    pub fn to_array(self) -> [f32; 4]
    pub fn from_array(a: [f32; 4]) -> Vec4
  impl Index<usize> for Vec4 {
  impl IndexMut<usize> for Vec4 {

## forge-json/src/lib.rs
  pub enum Json {…}
  pub struct JsonError {…}
  impl fmt::Display for JsonError {
  impl std::error::Error for JsonError {} {
  impl Json {
    pub fn obj() -> Json
    pub fn arr() -> Json
    pub fn num32(v: f32) -> Json   // f32 stored via its shortest decimal form so `0.1f32` prints as `0.1`.
    pub fn vec3(v: [f32; 3]) -> Json
    pub fn f32s(v: &[f32]) -> Json
    pub fn set(mut self, key: &str, value: impl Into<Json>) -> Json   // Builder: set (or replace) a key on an object. No-op on non-objects.
    pub fn insert(&mut self, key: &str, value: impl Into<Json>)
    pub fn push(&mut self, value: impl Into<Json>)
    pub fn get(&self, key: &str) -> Option<&Json>
    pub fn at(&self, i: usize) -> Option<&Json>
    pub fn as_str(&self) -> Option<&str>
    pub fn as_f64(&self) -> Option<f64>
    pub fn as_f32(&self) -> Option<f32>
    pub fn as_i64(&self) -> Option<i64>
    pub fn as_u32(&self) -> Option<u32>
    pub fn as_bool(&self) -> Option<bool>
    pub fn as_arr(&self) -> Option<&[Json]>
    pub fn as_obj(&self) -> Option<&[(String, Json)]>
    pub fn is_null(&self) -> bool
    pub fn as_vec3(&self) -> Option<[f32; 3]>   // Array of exactly three numbers.
    pub fn as_f32_array<const N: usize>(&self) -> Option<[f32; N]>   // Array of exactly `N` numbers.
    pub fn get_str(&self, key: &str) -> Option<&str>
    pub fn get_f32(&self, key: &str) -> Option<f32>
    pub fn get_i64(&self, key: &str) -> Option<i64>
    pub fn get_u32(&self, key: &str) -> Option<u32>
    pub fn get_bool(&self, key: &str) -> Option<bool>
    pub fn parse(src: &str) -> Result<Json, JsonError>
    pub fn to_pretty(&self) -> String
  impl fmt::Display for Json {
  impl From<f32> for Json {
  impl From<bool> for Json {
  impl From<&str> for Json {
  impl From<String> for Json {
  impl<T: Into<Json>> From<Vec<T>> for Json {
  impl<T: Into<Json>> From<Option<T>> for Json {
  impl From<[f32; 3]> for Json {
  impl From<[f32; 4]> for Json {
  impl<'a> Parser<'a> {

## forge-mesh/src/ctx.rs
  pub struct CancelToken(Arc<AtomicBool>)   // Cooperative cancellation flag shared between the UI thread and long-running geometry work.
  impl CancelToken {
    pub fn new() -> CancelToken
    pub fn cancel(&self)
    pub fn reset(&self)
    pub fn is_cancelled(&self) -> bool
    pub fn check(&self) -> GeomResult<()>
    pub fn flag(&self) -> Arc<AtomicBool>   // The underlying flag, for embedding in other cancellation schemes (e.g. the interpreter).
  pub struct OpLimits {…}   // Upper bounds an operation must respect *before* allocating its output.
  impl Default for OpLimits {
  pub struct OpCtx {…}   // Context passed to every potentially expensive operation.
  impl OpCtx {
    pub fn new() -> OpCtx
    pub fn with_cancel(cancel: CancelToken) -> OpCtx
    pub fn check(&self) -> GeomResult<()>
    pub fn poll(&self, i: usize) -> GeomResult<()>   // Cheap poll for hot loops: only touches the atomic every 1024 iterations.
    pub fn ensure_capacity(&self, verts: usize, faces: usize) -> GeomResult<()>   // Fail if producing `verts`/`faces` elements would exceed the configured limits.
  pub enum GeomError {…}
  pub type GeomResult<T> = Result<T, GeomError>
  impl fmt::Display for GeomError {
  impl std::error::Error for GeomError {} {
  pub struct OpOutput {…}   // Result of a topology-changing operation (see docs/ARCHITECTURE.md "Op result convention").
  impl OpOutput {
    pub fn with_selection(selection: Selection) -> OpOutput
    pub fn map_vert(&self, v: u32) -> Option<u32>
    pub fn map_face(&self, f: u32) -> Option<u32>

## forge-mesh/src/lib.rs
  pub mod par
  pub mod tri
  pub use ctx::
  pub use mesh::Mesh
  pub use render::
  pub use selection::Selection
  pub use topology::
  pub use validate::
  pub use weld::

## forge-mesh/src/mesh.rs
  pub struct Mesh {…}   // Indexed polygon mesh.
  impl Default for Mesh {
  impl Mesh {
    pub fn new() -> Mesh
    pub fn from_polygons(positions: Vec<Vec3>, faces: &[Vec<u32>]) -> Mesh   // Build from trusted data (internal generators). Faces with fewer than 3 vertices are skipped.
    pub fn from_triangles(positions: Vec<Vec3>, tris: &[[u32; 3]]) -> Mesh
    pub fn try_from_pydata(positions: Vec<Vec3>, edges: &[[u32; 2]], faces: &[Vec<u32>]) -> GeomResult<Mesh>   // Validating constructor for untrusted input (scripts, importers): checks index ranges, face sizes and
    pub fn vert_count(&self) -> usize
    pub fn face_count(&self) -> usize
    pub fn corner_count(&self) -> usize
    pub fn is_empty(&self) -> bool
    pub fn face_range(&self, f: usize) -> Range<usize>
    pub fn face_len(&self, f: usize) -> usize
    pub fn face_verts(&self, f: usize) -> &[u32]   // Vertex indices of face `f` in winding order.
    pub fn face_positions(&self, f: usize) -> impl Iterator<Item = Vec3> + '_
    pub fn triangle_count(&self) -> usize   // Number of triangles after triangulation (sum of `n - 2` over faces).
    pub fn edge_count(&self) -> usize   // Number of unique edges (faces + loose). Builds a topology; use `Topology` directly if you need more.
    pub fn bounds(&self) -> Aabb
    pub fn add_vertex(&mut self, p: Vec3) -> u32
    pub fn add_face(&mut self, verts: &[u32]) -> u32
    pub fn add_face_ex(&mut self, verts: &[u32], material: u16, smooth: bool) -> u32
    pub fn add_loose_edge(&mut self, a: u32, b: u32)
    pub fn ensure_uvs(&mut self)   // Make `uvs` valid (one per corner, zero filled) if it is not.
    pub fn push_mesh(&mut self, other: &Mesh) -> u32   // Append `other`; returns the index offset applied to its vertices.
    pub fn clear(&mut self)
    pub fn face_area_vector(&self, f: usize) -> Vec3   // Unnormalised Newell normal of face `f` (its length is twice the polygon area).
    pub fn face_normal(&self, f: usize) -> Vec3
    pub fn face_area(&self, f: usize) -> f32
    pub fn face_center(&self, f: usize) -> Vec3
    pub fn face_normals(&self) -> Vec<Vec3>
    pub fn corner_angle(&self, f: usize, i: usize) -> f32   // Angle of the polygon corner at local position `i` of face `f`.
    pub fn vertex_normals(&self) -> Vec<Vec3>   // Angle-weighted vertex normals from **all** faces (ignores smooth flags). Unused vertices get zero.
    pub fn corner_normals(&self) -> Vec<Vec3>   // Per-corner shading normals: smooth faces use angle-weighted vertex normals accumulated over the *smooth*
    pub fn triangulate_face(&self, f: usize, out: &mut Vec<[u32; 3]>)   // Triangulate face `f`, appending triples of **global corner indices** (`corners[c]` is the vertex).
    pub fn triangles(&self) -> Vec<[u32; 3]>   // All triangles of the mesh as vertex-index triples (parallel for big meshes is not needed: it is cheap).
    pub fn to_triangle_mesh(&self) -> Mesh   // A copy where every face is a triangle (materials/smooth flags/UVs are carried over).
    pub fn transform(&mut self, m: &Mat4)   // Transform all positions. A mirroring matrix (negative determinant) also reverses face winding so
    pub fn translate(&mut self, d: Vec3)
    pub fn flip_faces(&mut self, mask: Option<&[bool]>)   // Reverse the winding of the selected faces (`None` = all); UV order follows.
    pub fn flip_all_faces(&mut self)
    pub fn check_structure(&self) -> Result<(), String>   // Cheap structural check; everything else in the workspace assumes this holds.
    pub fn memory_bytes(&self) -> usize   // Approximate heap footprint in bytes (for memory budgets).

## forge-mesh/src/par.rs
  pub fn set_max_threads(n: usize)   // Cap the number of worker threads (0 = automatic: `min(cores, 4)`, tuned for phones).
  pub fn max_threads() -> usize
  pub fn parallel_for<F: Fn(Range<usize>) + Sync>(len: usize, min_chunk: usize, f: F)   // Run `f(range)` over disjoint sub-ranges of `0..len` in parallel (sequentially when small).
  pub fn parallel_map<T: Send, F: Fn(usize) -> T + Sync>(len: usize, min_chunk: usize, f: F) -> Vec<T>   // Map `0..len` through `f`, preserving order.
  pub fn parallel_chunks_mut<T: Send, F: Fn(usize, &mut [T]) + Sync>(data: &mut [T], min_chunk: usize, f: F)   // Process disjoint mutable chunks of `data`; `f(first_index, chunk)`.

## forge-mesh/src/render.rs
  pub struct RenderVertex {…}   // 32-byte interleaved vertex (`#[repr(C)]` so the platform layer can upload it as bytes).
  pub struct SubMesh {…}
  pub struct RenderBuffers {…}
  pub struct VertexCorners {…}   // Vertex -> corners adjacency, needed for incremental patching. Rebuild when topology changes.
  impl VertexCorners {
    pub fn build(mesh: &Mesh) -> VertexCorners
    pub fn corners_of(&self, v: u32) -> &[u32]
  impl RenderBuffers {
    pub fn build(mesh: &Mesh) -> RenderBuffers
    pub fn build_with(mesh: &Mesh, topo: &Topology) -> RenderBuffers
    pub fn update_positions(&mut self, mesh: &Mesh, vc: &VertexCorners, dirty: &[u32]) -> Option<Range<u32>>   // Patch positions and shading normals after the given vertices moved (topology unchanged).
    pub fn triangle_count(&self) -> usize
    pub fn memory_bytes(&self) -> usize

## forge-mesh/src/selection.rs
  pub struct Selection {…}
  impl Selection {
    pub fn none(n: usize) -> Selection
    pub fn all(n: usize) -> Selection
    pub fn from_indices(n: usize, idx: impl IntoIterator<Item = u32>) -> Selection
    pub fn len(&self) -> usize
    pub fn is_empty(&self) -> bool
    pub fn count(&self) -> usize   // Number of selected vertices.
    pub fn any(&self) -> bool
    pub fn is_selected(&self, v: u32) -> bool
    pub fn set(&mut self, v: u32, on: bool)
    pub fn select_all(&mut self)
    pub fn clear(&mut self)
    pub fn invert(&mut self)
    pub fn resize(&mut self, n: usize)   // Resize after a topology change; new vertices are unselected.
    pub fn indices(&self) -> Vec<u32>
    pub fn face_mask(&self, mesh: &Mesh) -> Vec<bool>   // Faces whose every vertex is selected.
    pub fn faces(&self, mesh: &Mesh) -> Vec<u32>
    pub fn count_faces(&self, mesh: &Mesh) -> usize
    pub fn edge_mask(&self, topo: &Topology) -> Vec<bool>   // Edges whose two end vertices are selected.
    pub fn edges(&self, topo: &Topology) -> Vec<u32>
    pub fn count_edges(&self, topo: &Topology) -> usize
    pub fn select_faces(&mut self, mesh: &Mesh, faces: &[u32])
    pub fn grow(&mut self, topo: &Topology)   // "Select more": add every vertex connected by an edge to a selected vertex.
    pub fn shrink(&mut self, topo: &Topology)   // "Select less": deselect every vertex that has an unselected neighbour.
    pub fn select_linked(&mut self, topo: &Topology)   // Flood-fill the selection across edges ("select linked").
    pub fn remap(&self, vert_map: &[u32], new_len: usize) -> Selection   // Carry the selection through an old->new vertex map (`u32::MAX` = deleted).

## forge-mesh/src/topology.rs
  pub const NONE: u32 = u32::MAX   // "No element" marker used in index arrays.
  pub struct Csr {…}   // Compressed sparse rows: `items[start[i]..start[i+1]]` belong to row `i`.
  impl Csr {
    pub fn from_pairs(rows: usize, pairs: &[(u32, u32)]) -> Csr
    pub fn get(&self, row: usize) -> &[u32]
    pub fn rows(&self) -> usize
  pub struct Topology {…}
  impl Topology {
    pub fn build(mesh: &Mesh) -> Topology   // Build for a structurally valid mesh (`Mesh::check_structure` ok).
    pub fn edge_between(&self, a: u32, b: u32) -> Option<u32>
    pub fn is_loose(&self, e: u32) -> bool
    pub fn is_boundary(&self, e: u32) -> bool
    pub fn is_manifold_edge(&self, e: u32) -> bool
    pub fn other_face(&self, e: u32, f: u32) -> Option<u32>
    pub fn other_vertex(&self, e: u32, v: u32) -> u32
    pub fn face_edges<'a>(&'a self, mesh: &Mesh, f: usize) -> &'a [u32]   // Edges of face `f` in winding order (edge from corner i to corner i+1).
    pub fn vert_neighbors(&self, v: u32) -> impl Iterator<Item = u32> + '_
    pub fn boundary_edge_count(&self) -> usize   // Number of edges that have exactly one / more than two faces.
    pub fn non_manifold_edge_count(&self) -> usize

## forge-mesh/src/tri.rs
  pub fn triangulate_polygon(pts: &[Vec3], out: &mut Vec<[u32; 3]>)   // Triangulate a polygon given by its positions; appends **local** index triples (0..pts.len()).

## forge-mesh/src/validate.rs
  pub struct ValidationReport {…}
  impl ValidationReport {
    pub fn is_structurally_valid(&self) -> bool   // Safe to render / transform / export (indices and numbers are sane).
    pub fn is_closed(&self) -> bool
    pub fn is_manifold(&self) -> bool
    pub fn is_watertight(&self) -> bool   // Closed, manifold, consistently wound: a proper solid (required for booleans).
    pub fn summary(&self) -> String
  pub fn validate(mesh: &Mesh) -> ValidationReport

## forge-mesh/src/weld.rs
  pub struct CleanupMap {…}   // Result of a clean-up: `vert_map[old] = new` (or `u32::MAX`), `face_map[old] = new` (or `u32::MAX`).
  pub fn retain_faces(mesh: &mut Mesh, keep: &[bool]) -> Vec<u32>   // Keep only faces with `keep[f] == true` (vertices are untouched). Returns old->new face map.
  pub fn compact_unused(mesh: &mut Mesh) -> Vec<u32>   // Remove vertices that no face and no loose edge uses. Returns old->new vertex map.
  pub fn weld_vertices(mesh: &mut Mesh, eps: f32) -> CleanupMap   // Merge vertices closer than `eps` ("merge by distance"). The lowest-index vertex of a cluster survives (its
  pub fn remove_degenerate_faces(mesh: &mut Mesh, min_area: f32) -> Vec<u32>   // Drop faces that repeat a vertex or whose area is below `min_area`. Returns old->new face map.
