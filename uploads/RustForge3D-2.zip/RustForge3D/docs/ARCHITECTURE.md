# RustForge 3D — architecture contract

Authoritative product specs (read them first, they are the acceptance criteria):
* `/mnt/user-data/uploads/attachment-a71d2f63.txt`  – RustForge 3D app spec (touch controls, modeling tools, UI, IO, performance)
* `/mnt/user-data/uploads/attachment.txt`            – Blender-style Python (`bpy`) scripting spec
* `/mnt/user-data/uploads/attachment-8f312eb8.txt`   – the user's GitHub Actions build workflow (zip in -> APK out)

Where the specs conflict, the Python/`bpy` spec wins: **scripts are Python**, not Rust source (a phone cannot
compile Rust). Everything else in the first spec still applies.

## Hard rules (every crate, every worker)

1. **No network, no package installs.** The sandbox is offline. Core crates have **zero external dependencies**
   (only `path` deps on sibling crates). Standard library only. `rayon`/`glam`/`serde` are replaced by in-tree
   equivalents (`forge-math`, `forge_mesh::par`, `forge-json`).
2. `#![forbid(unsafe_code)]` in every crate under `rust/crates/`. Unsafe exists only in the Android platform crate.
3. **Never panic on bad input** (scripts and imported files are untrusted). Return `Result`. Use checked arithmetic /
   size pre-checks before allocating from untrusted sizes. A panic is a bug.
4. **Sandbox/limits/cancellation are first class**: long loops poll a `CancelToken` and size limits are checked
   *before* allocating (see `forge_mesh::OpCtx`).
5. Right-handed **Z-up** world (like Blender), CCW-outward winding, f32 geometry, radians in APIs.
   glTF/OBJ are Y-up files: IO converts at the boundary (`(x,y,z)_zup -> (x,z,-y)_yup`).
6. Tests are **unit tests inside `src/`** (`#[cfg(test)]`) so the CI step `cargo test --lib` runs them. Put big
   fixtures under `crates/<name>/testdata/` and `include_str!` them.
7. Keep files focused (< ~1500 lines each), public items documented, no dead code, no `todo!()`/`unimplemented!()`
   reachable from the public API. Every public operation listed in the spec must really work.
8. Code quality bar: clean module boundaries, reusable pieces, no copy-paste, performance-aware (avoid per-element
   allocation in hot loops, reuse buffers, parallelise only large jobs with `forge_mesh::par`).

## Tooling

* Run cargo only through `tools/cargo-offline.sh` (resolves the workspace offline using stubs for the Android-only
  crates): `tools/cargo-offline.sh test -p forge-py --lib`.
* **Use your own target dir** to avoid lock contention with other workers:
  `CARGO_TARGET_DIR=/tmp/claude-0/target-<yourcrate> tools/cargo-offline.sh test -p <crate>`.
* `python3` (3.13) is available for differential testing of the Python interpreter.
* Do not edit files outside the crate(s) you own. If you need a change elsewhere, say so in your final report.
* Never leave a crate in a non-compiling state at the end of your work; other crates depend on yours.

## Crate map

```
forge-math   Vec/Mat/Quat/Euler/Aabb/Ray                          (done; frozen)
forge-json   JSON value, parser, writer                            (done; frozen)
forge-mesh   Mesh, Topology, Selection, validation, par, OpCtx/CancelToken/Limits, RenderBuffers  (done; frozen)
forge-geom   primitives, mesh edit ops, Catmull-Clark subdivision, mirror                       (worker G)
forge-bvh    BVH (ray/closest point/frustum/overlap), spatial hash for brushes          (worker V)
forge-bevel  bevel of edges/vertices (profile, segments, width modes, clamping)          (worker V)
forge-csg    boolean union / difference / intersection on triangle soups -> clean meshes (worker C)
forge-io     OBJ / STL / glTF / GLB import+export, base64, deflate-free                (worker C)
forge-input  camera model, gesture recogniser, gizmos (hit-test + draw lists + drag math), snapping   (worker I)
forge-sculpt sculpt brushes (draw/smooth/grab/inflate/pinch/flatten/clay/crease), symmetry, dirty tracking (worker I)
forge-py     ForgePy: embedded Python interpreter + native/pure-python stdlib           (worker P1, later P2)
forge-scene  scene graph, datablocks, materials, modifier *schemas*, ParamDef/ParamSet, undo, .rforge file   (worker S)
forge-mods   modifier evaluation (mirror, array, subsurf, solidify, bevel, boolean, ...) + evaluated-mesh cache  (worker M)
forge-ops    operator registry (Blender-style ids): object ops + edit-mode ops over the scene; used by UI *and* bpy   (worker O)
forge-bpy    bpy / bmesh / mathutils on forge-py + forge-scene + forge-ops, linter, API docs, AI prompt   (worker B)
forge-engine command API (JSON, docs/PROTOCOL.md), tools, picking, interaction, state JSON, script runner, frame assembly  (worker E1, E2)
rustforge    cdylib: JNI + wgpu renderer                                                (worker R)
app/         Kotlin + Jetpack Compose UI, Gradle project                                (worker K)
```
Dependency edges are declared in each `Cargo.toml` (already created, do not add dependencies without telling the
orchestrator): mesh->math; geom/bvh/bevel/csg->math,mesh; io->math,mesh,json; input->math; sculpt->math,mesh; py->(none);
scene->math,mesh,json; mods->scene,geom,bevel,csg; ops->scene,geom,bevel,csg,bvh,io,mods; bpy->py,scene,ops,mods,...;
engine->everything. Kotlin side: `docs/PROTOCOL.md`.

Phases: (1) P1,G,V,C,I,S,K,R in parallel; (2) M,O,P2,E1,B in parallel (they read the finished phase-1 crates);
(3) E2 + integration + fixes; (4) packaging and cross-checks.

Kotlin tooling (offline): `tools/kotlinc.sh <out> <srcs...>` compiles pure-Kotlin code with the compiler bundled in
Gradle (`java -cp <out>:/opt/gradle/lib/kotlin-stdlib-2.0.21.jar MainKt` runs it); `tools/kotlinc.sh --check <srcs...>`
type-checks everything but ignores "unresolved reference" errors that merely come from Android/Compose/AndroidX libs
that are not available offline (so: explicit imports, no wildcard imports from external packages).

## Op result convention (forge-geom / forge-csg / forge-scene)

Every topology-changing mesh operation returns `forge_mesh::OpOutput`:

* `selection`  – vertex selection after the op (usually the new geometry),
* `new_verts` / `new_faces` – indices (in the *output* mesh) of created elements,
* `vert_map` / `face_map` – old index -> new index (`u32::MAX` = deleted); empty vec = identity.

bmesh (`forge-bpy`) relies on this to keep Python-held element handles valid. Be exact.

## Selection model

`forge_mesh::Selection` stores per-vertex flags only. Faces are "selected" when all their vertices are, edges when
both end vertices are (and the edge exists). Select modes (vertex/edge/face) only change *how picking sets
vertex flags*. Document corner cases; do not invent a second representation.

## Materials / UVs

`Mesh.face_material[f]` is a slot index into the owning mesh datablock's material list. UVs are optional per-corner.

## Script safety model

Scripts run in ForgePy (our own interpreter): there is no way to reach the filesystem, network, processes or
environment because the interpreter simply has no such primitives. `open`, `os`, `sys.modules` tricks etc. either
do not exist or raise. Time/step/memory/recursion limits and a cancel flag are enforced inside the interpreter.
Scripts run on a worker thread against a *cloned* scene (cheap: meshes are `Arc` copy-on-write) and are
committed atomically, so a failed or cancelled script never corrupts the user's scene.

## Reporting

When you finish, reply with: what exists (public API entry points), test counts/results, known gaps, and anything
other crates must know. Keep it under 40 lines. Do not paste code.
