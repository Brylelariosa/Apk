# API items written from memory — check these first if CI fails

The sandbox that produced this project has no network, no Android SDK, no crates.io. Everything below compiled only
against hand-written stand-ins, so the first CI run is the first compile against the real libraries. If a build step
fails, the log names the exact item; this list says where it is and what the likely fix is.

## Rust (step "Build Rust library (cargo-ndk)")

wgpu 22.1 (`rust/src/render/`):
* `gpu.rs`: `Instance::create_surface_unsafe(SurfaceTargetUnsafe::RawHandle { raw_display_handle, raw_window_handle })`,
  `request_adapter(&RequestAdapterOptions)`, `adapter.request_device(&desc, None)` (two arguments in 22.x),
  `SurfaceConfiguration { desired_maximum_frame_latency, .. }`, `SurfaceError` variants (`Lost`, `Outdated`, `Timeout`,
  `OutOfMemory`), backend selection `Backends::VULKAN` then `Backends::GL`.
* `pipelines.rs`: `RenderPipelineDescriptor { cache: None, multiview: None, compilation_options: .. }`,
  `PipelineCompilationOptions::default()`, `VertexBufferLayout`/`VertexAttribute` shapes, `PrimitiveState` fields.
* `plan.rs` / `targets.rs`: `RenderPassDescriptor { timestamp_writes, occlusion_query_set }`,
  `RenderPassColorAttachment { ops: Operations { load, store: StoreOp::Store } }`, depth attachment fields.
* `shaders/*.wgsl`: validated by naga at pipeline creation on the device, not before. A WGSL error appears as the red
  "The 3D view is not available" card with naga's message.

jni 0.21 / raw-window-handle 0.6 (`rust/src/jni_api.rs`, `android.rs`):
* `JNIEnv::{new_string, get_string, convert_byte_array, byte_array_from_slice, get_array_length,
  get_float_array_region, get_int_array_region}`; `AndroidNdkWindowHandle`, `AndroidDisplayHandle` constructors.
* `ANativeWindow_fromSurface` / `ANativeWindow_release` are declared by hand with `#[link(name = "android")]`.

## Kotlin (step "Build APK")

Compose / AndroidX (versions pinned in `app/build.gradle.kts`: Compose BOM 2024.06.00, Material3 1.2.x,
activity-compose 1.9.0, Kotlin 1.9.24, compiler extension 1.5.14):
* `ui/common/Pressable.kt`: `detectTapGestures(onPress, onLongPress, onTap)`, `Modifier.semantics { onClick { true } }`,
  `Popup(popupPositionProvider = ..)` with a custom `PopupPositionProvider` (tooltips).
* `ui/common/Buttons.kt`: `DropdownMenuItem(text, onClick, leadingIcon, trailingIcon, enabled)`.
* `ui/common/Dialogs.kt`: `Dialog(properties = DialogProperties(usePlatformDefaultWidth = false))`.
* `ui/common/Fields.kt`: `BasicTextField` with `onFocusChanged` commit logic, `Slider(valueRange, onValueChangeFinished)`.
* `ui/viewport/ViewportSurface.kt`: `AndroidView` hosting a `SurfaceView`; touches must reach it under the passive HUD
  (HUD uses no `Surface`/clickable) and must NOT reach it under panels (panels use `Modifier.blockTouches()`).
* `ui/AppRoot.kt`: `rememberLauncherForActivityResult(OpenDocument / CreateDocument(mime))`, `BackHandler`.
* Compose-compiler rules (composable invocation context, stability) were not checked by a real compiler.

Likely behaviour to check on a device first: panels swallowing touches over the viewport, rotation without the 3D view
being recreated, keyboard (IME) resizing with numeric fields, first-frame time on slow GPUs (surface creation runs on the
main thread and waits up to 20 s for the render thread).
