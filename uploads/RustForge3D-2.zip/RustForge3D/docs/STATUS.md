# RustForge 3D — build status (zip 1)

This is the first deliverable: a complete vertical slice (Rust engine -> wgpu renderer -> JNI -> Kotlin/Compose UI)
meant to be compiled by the CI workflow so the integration can be verified on real tooling. Later zips extend it.

## Included and working in the engine (unit-tested natively, 131 Rust tests)

* Scene: objects, collections, lights (point/sun/spot), empties, materials with slots, visibility/lock, rename.
* Primitives: cube, UV sphere, ico sphere, cylinder, cone, torus, plane, grid, circle.
* Object operators: duplicate, delete, join, shade smooth/flat, apply transforms, origin to geometry, hide/show.
* Edit mode (vertex / edge / face): select (click, box, all/none/invert/grow/shrink/linked), extrude (region, faces
  individual, edges, vertices), inset, loop cut and slide, subdivide, merge, dissolve, remove doubles, symmetrize,
  smooth, flip normals, recalculate normals, fill, triangulate, separate, duplicate.
* Modifiers: Mirror and Subdivision Surface (non-destructive, reorder, show/hide, apply, remove).
* Transform tools with gizmos, numeric input with expressions and units (`2*3`, `50cm`, `90deg`), grid/angle/scale snapping.
* Touch input interpreted entirely in Rust: orbit / pan / zoom, double-tap focus, tool drags, stylus pressure, box select.
* Undo / redo (labelled), "adjust last operation" (operator redo with live parameters), projects (`.rforge`), autosave.
* Settings (touch sensitivity, gestures, gizmo size, snapping, selection, viewport quality / MSAA / resolution scale / fps cap).
* Renderer: wgpu with Vulkan, falling back to OpenGL ES; solid, wireframe and material preview; grid, axes, selection
  overlays, x-ray, statistics; automatic quality adaptation for low-end devices.

## Included in the Android app

Adaptive layout (phone portrait: bottom tool rail and overlay sheet; phone landscape / small tablet: side rail and
side card; wide tablet: permanent right dock), vector icons (no emoji), tooltips, top bar (project menu, undo/redo,
view menu, panels, workspace switch), bottom bar (Object/Edit, vertex/edge/face, selection, Add, operator menus),
scene list (multi-select, eye / lock / rename / duplicate / delete), object properties (name, location, rotation,
scale, dimensions, numeric transform dialog, light settings), modifier stack editor, material editor (slots, assign,
new, colour picker, metallic / roughness / alpha / emission), info tab, settings dialog, help dialog, open/save
through the system file picker, last-session restore.

## Not in this zip (the UI says so where it matters; nothing is simulated)

| Feature | State |
| --- | --- |
| Python / `bpy`-style scripting (ForgePy interpreter, code editor, console, Run/Stop/Preview, API reference) | crates `forge-py`, `forge-bpy` are empty placeholders; the Code workspace shows a "not in this build" notice. `script.*` commands return that error. |
| Bevel, boolean (union/difference/intersect) | crates `forge-bevel`, `forge-csg` are empty placeholders. |
| Mesh import / export (OBJ, STL, glTF, GLB) | crate `forge-io` is an empty placeholder; the menu entries are shown disabled. |
| Sculpt mode | crate `forge-sculpt` is an empty placeholder; `Capabilities.SCULPT = false`. |
| Cameras as objects, parenting and collections UI | engine data exists; no UI yet. |
| Three-finger undo/redo gesture, vertex snapping | setting exists in the protocol; not wired in the input layer. |
| Incremental GPU patching of huge meshes | whole mesh buffers are re-uploaded on change. |

## Verification done offline (no network, no Android SDK in the sandbox)

* Rust core crates: `cargo test --lib` — 131 tests, all passing, plus the native layer (20 tests) against local stubs of
  `wgpu`, `jni`, `raw-window-handle`, `log`.
* Kotlin pure packages (`core`, JSON/state/params/expressions/icons/commands/HUD/layout): 58 tests with the real compiler.
* Kotlin UI / bridge / state / storage: type-checked against hand-written API stubs (`tools/typecheck.sh`, not shipped).

## Not verified (first CI run is the real test) — see `ANDROID-API-NOTES.md`

* The renderer against the real wgpu 22.1 API and the JNI layer against the real jni 0.21 API.
* WGSL shaders (naga validates them when the app starts on a device).
* The Compose UI against the real Compose compiler, and everything on a real device (touch feel, performance, GPU drivers).
