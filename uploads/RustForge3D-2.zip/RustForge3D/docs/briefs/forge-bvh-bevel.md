# Worker V — `forge-bvh` (spatial queries + picking) and `forge-bevel` (bevel)

Read `docs/ARCHITECTURE.md`, then the source of `rust/crates/forge-mesh/src/` and `forge-math`. You own
`rust/crates/forge-bvh/` and `rust/crates/forge-bevel/` only. `#![forbid(unsafe_code)]`, no external dependencies.
Never panic on odd meshes. Use `forge_mesh::par` for large builds, `OpCtx` for cancellation/limits.

## Part 1 — forge-bvh

### BVH (`bvh.rs`)
* `Bvh::build(positions: &[Vec3], tris: &[[u32;3]])` and `Bvh::from_mesh(&Mesh)` (triangulates faces with
  `Mesh::triangulate_face`, keeps `tri_face: Vec<u32>` so hits report the polygon face). Binned SAH build (16 bins), leaves
  of <= 4 triangles, flattened node array (cache friendly), parallel build above ~50k triangles, no recursion deeper than a
  guarded limit (explicit stack), handles empty / degenerate input. `refit(&mut self, positions)` after vertices move
  (sculpt / transforms) without a rebuild; `needs_rebuild(quality)` heuristic (SAH cost drift).
* Queries: `raycast(&Ray, t_max, double_sided) -> Option<Hit { t, tri, face, bary: [f32;3], point, normal }>`,
  `raycast_any(&Ray, t_max) -> bool` (occlusion), `raycast_all`, `closest_point(p) -> Option<ClosestHit { dist2, tri, face, point }>`,
  `query_sphere(center, r, &mut Vec<u32>)`, `query_aabb`, `query_frustum(&[Plane;6], &mut Vec<u32>)`, `bounds()`.
  Use Möller–Trumbore from `forge_math::Ray` or a watertight variant; results must be deterministic (ties -> lowest index).
* `SpatialHash` (uniform grid) over points: `build(points, cell)`, `query_radius(p, r, &mut Vec<u32>)`, `nearest(p)`,
  incremental `update(index, new_pos)`. Used by sculpt/weld/snapping.
* `SceneBvh` helper for object-level picking: holds per-object world AABB + `Arc<Bvh>` + model matrix;
  `pick(&Ray) -> Option<(object_index, Hit in world space)>` (ray transformed into object space, hit distance converted back),
  `box_candidates(rect_planes)`.

### Picking in screen space (`pick.rs`) — the UI relies on this for edit mode and object selection
All functions take `view_proj: &Mat4`, a viewport `(w, h)` in pixels, and an optional model matrix; screen origin top-left, y down.
* `nearest_vertex(mesh, bvh_for_occlusion: Option<&Bvh>, ..., screen_pos, radius_px, xray) -> Option<u32>`
  (candidate = projected vertices within radius, closest wins, back/occluded ones rejected unless `xray`; occlusion by a
  BVH ray from the camera `eye` with epsilon),
* `nearest_edge(...)` (point-to-segment distance in screen space, occlusion by edge midpoint), `pick_face(...)` (BVH ray;
  returns face + hit point), `pick_element(mode, ...)` convenience for vertex/edge/face select modes with a *generous*
  `radius_px` (touch hit boxes) and nearest-wins tie breaking that prefers vertices over edges over faces when within radius,
* `box_select_vertices(mesh, bvh, view_proj, rect, xray) -> Vec<u32>` (frustum-culls fast; without xray only visible verts),
  `box_select_edges/faces` (edge: both end points inside or segment crosses; face: centroid or all verts inside),
* `lasso` optional. All parallelised for >100k verts.
Tests: unit cube picked from several cameras, occlusion (vertex behind a face is not picked without xray), box select counts.

### Tests for part 1
Ray vs brute force on random triangle soups (thousands of rays, exact agreement), closest point vs brute force,
frustum/sphere/aabb queries vs brute force, refit correctness after random vertex motion, build time smoke test
(`#[ignore]`: 1M triangles).

## Part 2 — forge-bevel

`bevel(mesh: &Mesh, target: &BevelTarget, opts: &BevelOpts, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)>` where
`BevelTarget` = `Edges(Vec<u32> /* edge ids of Topology::build(mesh) order */)` or `Vertices(Vec<u32>)`.
`BevelOpts`: `offset` (>=0), `offset_type` (`Offset` | `Width` | `Depth` | `Percent`), `segments` (>=1), `profile` (0..1, 0.5 =
circular arc, superellipse family like Blender), `clamp_overlap` (default true), `loop_slide` (default true), `affect`
implied by target, `harden_normals` (ignore), `face_strength` (ignore), `miter` (simple: Sharp only), `use_smooth`
(new faces smooth-shaded when segments > 1, Blender default), `material` (-1 = inherit from the adjacent face).
Behaviour must match Blender's *topology* for the common cases:
* bevelling all 12 edges of a cube: 1 segment -> 24 verts / 48 edges / 26 faces (6 shrunken originals, 12 edge quads,
  8 corner triangles); 2 segments -> 8 corner patches with the Blender pattern; N segments generally.
* single edge, a loop of edges, boundary edges (open meshes), edges meeting at valence 3, 4, 5+ vertices (corner patch or
  polygon cap), non-planar and obtuse/acute dihedrals (offset distance measured on the adjacent faces so the bevel width is
  uniform), edges of triangle fans, vertex-only bevel (`Vertices`), edges shared by >2 faces are skipped with a warning
  carried in `OpOutput`-adjacent `BevelReport { skipped_edges, clamped }` (return it next to `OpOutput`).
* Result stays manifold/watertight when the input was; normals consistent; materials inherited from the adjacent
  original face (edge quads: from the face with the lower index), UVs left linear-interpolated or zero.
* `OpOutput.selection` = the vertices of the new bevel faces (like Blender's selection after bevel), `new_faces` = bevel
  faces, `vert_map`/`face_map` exact (original vertices that are replaced map to `u32::MAX`).
* Clamp overlap: offsets reduced so neighbouring bevels never cross; `offset` huge must not blow up.
Hard parts to get right (budget time for them): vertex meshes at valence >= 3 junctions, profile curve with `segments > 1`
at corners, consistent winding, bevels on edges next to other bevelled edges.

### Tests for part 2
Counts for the cube cases above (1, 2, 3 segments, single edge, edge loop), watertight/volume checks (volume decreases and
matches the analytic value for a cube with a 1-segment bevel width w: `V = s^3 - ...` compute it exactly in the test),
sphere/cylinder/torus bevel smoke tests, valence 5 vertex, open plane boundary, offset types, clamping with absurd offsets,
a seeded fuzz test (random edge subsets on random closed meshes: no panic, `check_structure()` ok, no NaN, watertight preserved).

Everything must pass with `CARGO_TARGET_DIR=/tmp/claude-0/target-bvh tools/cargo-offline.sh test -p forge-bvh -p forge-bevel`
and be warning-free.

## Report
Public API summary, test counts, bevel feature coverage and known gaps (be honest), notes for engine/ops authors (< 40 lines).
