# Worker G — `forge-geom`: primitives and mesh editing operations

Read `docs/ARCHITECTURE.md` first, then the source of `rust/crates/forge-mesh/src/` (`lib.rs`, `mesh.rs`, `ctx.rs`,
`selection.rs`, `topology.rs`, `weld.rs`, `validate.rs`) — your data model and helpers. You own `rust/crates/forge-geom/` only
(`#![forbid(unsafe_code)]`, no external deps; dependencies: forge-math, forge-mesh). The result is used by the UI
(tools) **and** by Python scripts (`bpy.ops.mesh.*`, `bmesh.ops.*`), so every operation must be robust on arbitrary
input meshes (n-gons, loose edges, non-manifold, degenerate faces) and must never panic.

## Style (all operations)
* Functional: `fn op(mesh: &Mesh, sel: &Selection, opts: &OpOpts, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)>`
  (primitives return `Mesh`). Plain `*Opts` structs with `Default` + public fields; no builder noise.
* `OpOutput` must be exact (`selection` = what Blender selects afterwards, `new_verts`, `new_faces`, `vert_map`,
  `face_map`; see ARCHITECTURE.md): the bmesh layer relies on it to keep Python element handles valid.
* Call `ctx.poll(i)` in long loops, `ctx.ensure_capacity(..)` **before** allocating (untrusted sizes: a script may ask for
  `segments=10**9`). Parallelise only large jobs with `forge_mesh::par`.
* Inherit attributes like Blender: new faces take material/smooth flag of the neighbouring source face; UVs are
  interpolated/copied where cheap, otherwise left at zero (`mesh.uvs` empty or per-corner).
* Selection semantics: see ARCHITECTURE.md "Selection model" (vertex flags; face selected = all verts selected).
  Where that is ambiguous (e.g. two selected verts with an edge between them that is *not* selected in Blender), document
  the rule you chose in rustdoc and be consistent.

## Deliverables

### 1. Primitives (`primitives.rs`) — Blender-exact counts and conventions (Z up, CCW outward, radians)
`cube(size=2.0)`, `uv_sphere(segments=32, rings=16, radius=1.0)` (pole fans are triangles; verts = `segments*(rings-1)+2`),
`ico_sphere(subdivisions=2, radius=1.0)` (`subdivisions=1` is the icosahedron: 12 verts/20 faces; 2 -> 42/80; 3 -> 162/320),
`cylinder(vertices=32, radius=1.0, depth=2.0, cap: NGON|TRIFAN|NOTHING)`, `cone(vertices=32, radius1=1.0, radius2=0.0, depth=2.0, cap)`,
`torus(major_segments=48, minor_segments=12, major_radius=1.0, minor_radius=0.25)`, `plane(size=2.0)`,
`circle(vertices=32, radius=1.0, fill: NOTHING|NGON|TRIFAN)`, `grid(x_subdivisions=10, y_subdivisions=10, size=2.0)`,
all with `calc_uvs: bool` (sane UV layouts: cube = cross layout, sphere = equirectangular, cylinder/cone = side strip + cap discs,
torus = rectangle, plane/grid = unit square). Argument validation returns `GeomError` (zero/negative counts, > limits).
Vertex/face **counts must equal Blender's** (add tests with the known numbers). Match Blender's vertex order where you are
certain of it (cube, plane); otherwise any deterministic order.

### 2. Edit operations (each in its own module, each with `OpOutput`)
extrude: `extrude_region` (faces fully selected -> region; remaining selected edges -> edge extrusion; lone verts -> loose
edges; like Blender's extrude_region), `extrude_individual_faces`, `extrude_edges`, `extrude_verts`, plus helper
`translate_selection(mesh, sel, delta)`; `inset` (individual / region, thickness, depth, `use_boundary`, `use_even_offset`,
`use_relative_offset`, `use_outset`, `use_select_inset`); `loop_cut` (ring walk over quads from an edge, `number_cuts`, `factor`/slide,
`smoothness`; fails cleanly when the ring hits n-gons/triangles and reports how far it went); `subdivide` (edge subdivision of
selected edges/faces with `number_cuts`, `smoothness`, quad/tri/n-gon fan patterns like Blender's subdivide);
`subsurf` (Catmull-Clark `levels`, creases ignored, boundary rule `smooth/sharp`, keeps materials/UV (linear UV interpolation),
parallel for big meshes, memory guard) — this is also used by the Subdivision Surface modifier, so make it fast
(1 000-face mesh at level 4 well under a second in release);
`delete` (verts / edges / faces / only-faces / edges&faces, with loose-geometry cleanup like Blender),
`merge` (at center / first / last / collapse), `remove_doubles(distance, only_selected)` (use `weld_vertices`),
`dissolve_verts` / `dissolve_edges` / `dissolve_faces` (use_verts, angle limit variant `dissolve_limited(angle)`),
`flip_normals`, `recalc_normals(inside: bool)` (consistent outward orientation per connected component using signed volume),
`set_smooth(sel, bool)`, `triangulate(quad_method, ngon_method)`, `tris_to_quads(face_angle, shape_angle)`,
`fill` (selected boundary loops -> n-gon or triangle fan), `grid_fill` optional, `bridge_edge_loops` (two loops, `twist`, `cuts`),
`duplicate` (selected geometry -> copy in place, new selection), `separate` (selection -> second mesh),
`join(meshes + matrices)`, `spin(axis, center, angle, steps, dupli)`, `symmetrize(axis, direction)` /
`mirror(mesh, axes, merge_threshold, bisect, flip)` (shared with the Mirror modifier; centered on origin of the mesh's local
space or a given pivot matrix), `smooth_vertices(factor, repeat, axes)` (Laplacian), `transform_selection(matrix, pivot)`.
Every op must keep the mesh structurally valid (`mesh.check_structure()`).

### 3. Utilities other crates need
* `selection_ops`: select by `verts/edges/faces` indices, `select_more/less/linked` (already partly in `Selection`; add what is
  missing: select by normal/flat/random(seed)/boundary/non-manifold/loose, `edge_loop_of(edge)`, `edge_ring_of(edge)`,
  `face_loop`), converting selection between vertex/edge/face modes (`convert_select_mode`).
* `normals`: `smooth_by_angle(mesh, angle)` marks faces smooth/flat (no split normals required).
* `uv`: `box_project`, `cube_project(size)`, `planar_project(axis)`, `smart_project(angle_limit)` (simple island splitter ok) —
  `reset_uvs` default per-face unwrap; keep small and tested.

## Tests (mandatory, unit tests in `src/`)
* Counts for every primitive against the numbers Blender produces (cube 8/12/6, uv sphere 32x16 = 482 verts/512 faces, ico
  levels, cylinder 64/96/34 for 32 verts with ngon caps, torus 48x12 = 576/1152/576, ...).
* After every topology op on closed meshes: `forge_mesh::validate(&m).is_watertight()` unless the op legitimately opens it.
  Euler characteristic checks (`V-E+F`) where applicable. Volume/area sanity (signed volume via divergence theorem) for
  extrude/inset/subsurf/mirror.
* `OpOutput` correctness: for every op, check `vert_map`/`face_map`/`new_*`/selection on small hand-checked meshes.
* Robustness: a seeded pseudo-random fuzz test applying random op sequences with random selections to several base meshes
  (cube, sphere, plane with holes, n-gon prism, mesh with loose edges, non-manifold "butterfly") and asserting: no panic,
  `check_structure()` ok, no NaN/inf. Plus size-limit tests (`segments = u32::MAX` -> `Err`, not OOM).
* Performance smoke tests (`#[ignore]`d): subsurf level 4 of a 1k-face mesh, extrude of 100k faces.
Everything must pass with `CARGO_TARGET_DIR=/tmp/claude-0/target-geom tools/cargo-offline.sh test -p forge-geom` and be
warning-free. Keep files < ~1500 lines; split by module (`primitives`, `extrude`, `inset`, `loopcut`, `subdivide`, `subsurf`,
`delete`, `merge`, `dissolve`, `normals`, `fill`, `bridge`, `mirror`, `spin`, `uv`, `selection_ops`, ...).

## Report
Public API summary (module + function names + option structs), test counts, known gaps, semantic decisions the ops/bmesh
authors must know (selection rules, what `OpOutput.selection` contains per op). < 40 lines.
