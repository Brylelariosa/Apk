# Worker R — `rustforge` (root crate `rust/`): JNI layer + wgpu renderer

Read `docs/ARCHITECTURE.md`, `docs/PROTOCOL.md` (section 1: the JNI surface you export; section 9: render frame) and
`rust/crates/forge-engine/src/{lib.rs,render_types.rs,redraw.rs}` (the frozen engine <-> renderer contract). You own the root
crate: `rust/Cargo.toml` (only the `[dependencies]`, `[lib]` and profile sections for your needs — keep the `[workspace]` table
as is), `rust/src/**`, and the stub crates under `tools/offline-stubs/**`. Everything else is read-only for you.
Spec essentials (see `/mnt/user-data/uploads/attachment-a71d2f63.txt` sections 1, 2, 6, 9): **wgpu** renderer, **Vulkan preferred, OpenGL ES fallback**,
smooth on low-RAM phones, no Unity/Unreal/Godot/WebView.

## The big constraint: you cannot compile against the real crates
The sandbox is offline. `wgpu 22.1`, `jni 0.21`, `raw-window-handle 0.6`, `log 0.4` are replaced locally by *empty* stub crates
(`tools/offline-stubs/*`, injected by `tools/cargo-offline.sh` through `patch.crates-io`). CI builds the real thing with `cargo ndk`
(NDK r27, `aarch64-linux-android`), so a single wrong field name or signature breaks the whole APK. Therefore:
1. **Write faithful API stubs first** (inside `tools/offline-stubs/{wgpu,jni,raw-window-handle,log}/src/lib.rs`): declare exactly the types, enums,
   descriptor structs (all fields, correct names), trait bounds, lifetimes, `Option`/`Result` return types and method signatures of **wgpu 22.1.0**
   (the version where `request_adapter` returns `Option<Adapter>`, `request_device(&desc, None)`, `RenderPipelineDescriptor` has `compilation_options` and
   `cache: None`, `VertexState`/`FragmentState` have `entry_point: &str` + `compilation_options`, `DeviceDescriptor` has `memory_hints`, `SurfaceConfiguration` has
   `desired_maximum_frame_latency`, `Surface<'static>` via `create_surface_unsafe(SurfaceTargetUnsafe::RawHandle{..})`, `RenderPass<'encoder>`, `StoreOp`/`LoadOp`,
   `ShaderSource::Wgsl(Cow<str>)`, `util::DeviceExt::create_buffer_init`, ...), **jni 0.21** (`JNIEnv`, `JClass`, `JObject`, `JString`, `JByteArray`, `JIntArray`,
   `JFloatArray`, `sys::{jlong,jint,jboolean,jstring,jbyteArray}`, `get_string`, `new_string`, `convert_byte_array`, `byte_array_from_slice`, `get_array_region`, `get_raw`, ...),
   `raw-window-handle 0.6` (`RawWindowHandle::AndroidNdk(AndroidNdkWindowHandle::new(NonNull<c_void>))`, `RawDisplayHandle::Android(AndroidDisplayHandle::new())`) and `log`.
   Stub bodies may be `unimplemented!()`; only signatures matter. Put a header comment "mirrors <crate> <version>; signatures from memory — verify" and **keep a list of every item you were not sure about**.
2. Then write the real code against these stubs and make `CARGO_TARGET_DIR=/tmp/claude-0/target-rustforge tools/cargo-offline.sh check -p rustforge` pass with zero errors/warnings.
   (Type checking against your own stubs catches borrow-checker errors, typos, wrong field names inside *your* code, wrong argument counts and logic errors; it cannot catch
   deviations of the stub from the real API — so be paranoid about the real API and prefer the long-stable subset of wgpu: avoid anything you are not sure existed in 22.1.)
3. Design for **host linkability**: CI also runs `cargo test --lib` for the whole workspace on a Linux host, which links this crate's tests. Everything that needs Android system
   libraries (`ANativeWindow_*`, `__android_log_write`, `libandroid`/`liblog` `#[link]`s) must be under `#[cfg(target_os = "android")]` (with a no-op host fallback). Unit tests must not need a GPU.

## Cargo.toml (root crate)
Keep: `[lib] name = "rustforge"`, `crate-type = ["cdylib", "rlib"]`, dependencies on the forge crates by path, `wgpu = "22.1"` (default features: they already include the
Vulkan and GLES backends on Android; do **not** invent feature names), `jni = "0.21"`, `raw-window-handle = "0.6"`, `log = "0.4"`. No other external crates (hand-written `block_on`, hand-written Android
logger over `__android_log_write`, hand-written byte casting helper with one audited `unsafe` fn for `#[repr(C)]` plain data).

## JNI layer (`rust/src/jni_api.rs` + helpers)
* Export every function of PROTOCOL.md section 1 as `#[no_mangle] pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_<name>` (2nd parameter `JClass`; the Kotlin methods are `@JvmStatic`).
  `JNI_OnLoad` initialises logging + a panic hook (log the message and location).
* Handle = `Box::into_raw(Box<Native>)` as `jlong`; keep a global registry of live handles so a stale/double-destroyed/zero handle is rejected (returns the documented failure value) instead of crashing.
* Every entry point is wrapped in `catch_unwind(AssertUnwindSafe(..))`; failures become `{"ok":false,"error":"internal error: ..."}` / `null` / `false` and set `nativeLastError`. Never unwind into the JVM, never hold a JNI local ref across
  a blocking call, delete big local refs promptly. All string/array conversions are fallible and handled.
* `nativeTouch` converts the arrays into `forge_engine::TouchBatch` (bounds-check `count` against array lengths) and calls `Engine::touch` — it must not block on the render thread (take the engine lock briefly).
* The engine lives in `Arc<Mutex<Engine>>`; poison is recovered (`into_inner`) rather than propagated.
* `nativeImport/Export/SaveProject/LoadProject/Call/Poll/LastError/BackendName/SetPaused` map 1:1 to `Engine` methods (see `forge-engine/src/lib.rs`).

## Render thread (`rust/src/render/`)
Rust owns one render thread per `Native`. Commands over `std::sync::mpsc`: `Attach{window, w, h, reply}`, `Resize{w,h}`, `Detach{reply}`, `Pause(bool)`, `Shutdown`.
`nativeSurfaceCreated` obtains the `ANativeWindow*` (`ANativeWindow_fromSurface`, released with `ANativeWindow_release` after the GPU surface is dropped), sends `Attach` and **waits for the reply**
(returns false + `nativeLastError` on failure). `nativeSurfaceDestroyed` sends `Detach` and **waits until the thread no longer touches the window** (Android frees it right after the callback). Loop: when attached and not paused, wait on the
engine's `RedrawSignal` (timeout ~250 ms so surface errors are noticed), lock the engine only for `build_frame()`, draw **without** the lock, present, count frames, every ~1 s call `Engine::report_render_stats`.
Idle app = no GPU work (battery).
* Instance/adapter: try `Backends::VULKAN` first (`compatible_surface` set); if no adapter or device creation fails, retry with `Backends::GL`; remember the chosen backend name (`"Vulkan"`/`"OpenGL ES"`). Request limits
  `Limits::downlevel_defaults().using_resolution(adapter.limits())` with `max_buffer_size` raised to `min(adapter limit, 1 GiB)` (big meshes), no optional features. Prefer an sRGB surface format
  (`Bgra8UnormSrgb`/`Rgba8UnormSrgb`; otherwise a non-sRGB one and do the encoding in the shader — keep one switch), `PresentMode::Fifo`, `alpha_mode` from capabilities, `desired_maximum_frame_latency: 2`.
* Surface errors: `Lost`/`Outdated` -> reconfigure and retry next frame; `Timeout` -> skip; `OutOfMemory` -> log, detach and stop drawing (don't crash).
* Resolution scale `< 1.0`: render to an offscreen colour target of `scale*size` and blit to the swapchain with a fullscreen-triangle pass (linear filter); `== 1.0` renders straight to the swapchain.
  MSAA (`RenderFrame.msaa_samples` 1 or 4): check `adapter.get_texture_format_features(format).flags.sample_count_supported(4)` for colour **and** depth, fall back to 1; resolve into the swapchain/offscreen target.
  Recreate size-dependent targets only when size/scale/msaa change.
* GPU mesh cache `HashMap<u64, GpuMesh>`: `MeshUpdate::Upload` creates vertex/index/edge-index buffers (index format `Uint32`), `Patch` does `queue.write_buffer` of the patched vertex range, `Remove` drops (free memory promptly);
  track total GPU bytes for `gpu_mb`. Avoid per-frame allocations: reuse staging `Vec`s, grow-only dynamic buffers for lines/points/overlays (`COPY_DST | VERTEX`).
* Per-draw data through **one dynamic-offset uniform buffer** with 256-byte aligned slots (respect `min_uniform_buffer_offset_alignment`): `model`, normal matrix, material (base colour, metallic, roughness, emissive),
  flags (selected/active/xray/shading). Per-frame uniform: `view_proj`, eye, ambient, up to 8 lights (sun/point/spot), viewport size, shading mode, sRGB switch. All packing code is pure and unit-tested (sizes, offsets, alignment with
  `std::mem::size_of`/explicit offsets; WGSL struct layout rules for `vec3`/`mat3` padding are a classic bug — use only `vec4`/`mat4` members to dodge them).
* WGSL shaders (strings in `rust/src/render/shaders/*.wgsl` via `include_str!`): (1) **mesh**: Solid mode = studio lighting (headlight + hemisphere + subtle rim, object colour = material base colour), Material mode = hemisphere ambient + all
  lights with Lambert diffuse and a cheap GGX/Blinn specular driven by metallic/roughness, emissive added, alpha from `base_color.a`; selected objects get a subtle tint, no per-fragment branching beyond uniform flags;
  (2) **lines** (world space, depth tested, per-vertex colour, small depth bias) used for the grid/axes/edit-mode edges and for the **wire overlay** of `WireMode::Overlay/Only` items (edge index buffers, orange for selected/active, grey otherwise);
  (3) **points** (instanced camera-facing squares, `size_px`, per-instance colour, depth tested); (4) **overlay** lines and alpha-blended triangles drawn **without depth test** on top (gizmos); (5) **screen** lines in pixel coordinates (rubber band, brush circle);
  (6) **blit** for resolution scaling. Keep the shaders short, validated by reading them twice (naga is strict: types must match, no implicit conversions, `@location`/`@builtin` rules, uniform struct alignment, `textureSample` only in
  uniform control flow, no reserved words as identifiers such as `filter`, `target`, `sample`, `texture` in some positions).
* Draw order: opaque items (front to back is optional) -> wire overlays -> transparent / x-ray items sorted back to front (no depth write) -> depth-tested lines -> points -> overlay triangles -> overlay lines -> screen lines. Items whose `mesh_key`
  is not uploaded yet are skipped silently. `ShadingMode::Wireframe` draws edges only.
* Robustness: zero-sized surface (minimised) -> skip drawing; device lost -> log, mark detached; shader/pipeline creation errors must not panic (log + disable that pass); empty frames still clear.
* **Pure, testable layer** (`rust/src/render/plan.rs`): convert a `RenderFrame` into a `FramePlan` (sorted draw list, uniform bytes, vertex byte slices) without touching wgpu. Unit-test sorting/ordering, packing sizes, light packing,
  slot alignment, MSAA/scale decision functions (`choose_msaa(requested, supported)`, `target_size(w,h,scale)`), `RedrawSignal` wake-up behaviour with the engine type, JNI argument validation helpers (pure parts).

## Android specifics (all under `#[cfg(target_os = "android")]`)
`extern "C"` bindings: `ANativeWindow_fromSurface(env, surface)`, `ANativeWindow_release`, `ANativeWindow_getWidth/Height` (`#[link(name = "android")]`), `__android_log_write` (`#[link(name = "log")]`).
Raw handles: `AndroidNdkWindowHandle::new(NonNull::new(window).ok_or(..)?)` + `AndroidDisplayHandle::new()`, `create_surface_unsafe(SurfaceTargetUnsafe::RawHandle{..})`.
On non-Android hosts, `nativeSurfaceCreated` returns false with a clear message (so host-side tests never crash).

## Done when
`tools/cargo-offline.sh check -p rustforge` (against your stubs) and `tools/cargo-offline.sh test -p rustforge --lib` pass warning-free; code is split into small modules (`jni_api`, `handle`, `android`, `render/{mod,device,targets,mesh_cache,pipelines,uniforms,plan,shaders}`) with no dead code.

## Report (< 40 lines)
Module map, test counts, **the explicit list of wgpu/jni/raw-window-handle items whose real signatures you were unsure about** (so the integrator can double-check them against docs), shader features used, known gaps, and
anything the engine author must know (e.g. expectations about `RenderFrame` contents).
