# Worker C — `forge-csg` (boolean operations) and `forge-io` (OBJ / STL / glTF / GLB)

Read `docs/ARCHITECTURE.md`, then the source of `rust/crates/forge-mesh/src/` and `forge-math`, `forge-json`. You own
`rust/crates/forge-csg/` and `rust/crates/forge-io/` only. `#![forbid(unsafe_code)]`, no external dependencies.
Both process **untrusted** input (scripts / files): never panic, bound every allocation by limits, poll `OpCtx`.

## Part 1 — forge-csg

`boolean(a: &Mesh, b: &Mesh, op: BooleanOp, opts: &BooleanOpts, ctx: &OpCtx) -> GeomResult<(Mesh, BooleanReport)>` with
`BooleanOp::{Union, Difference, Intersection}` (Difference = A minus B). Both meshes are given in the **same space** (the
caller transforms B into A's space); the result is in that space. Also `boolean_many(a, &[b...], op, ..)` (sequential fold).

Why this matters: AI-written Blender scripts cut windows, doors and holes into walls with boolean modifiers/ops all the time
(cube minus cube, cube minus cylinder, coplanar/flush cutters, cutters that only touch, nested cutters, many cutters in a
row). It must be *robust first*, fast second.

Suggested approach (you may choose another if you can justify it): triangulate both inputs, compute exact-enough
triangle/triangle intersection segments in f64 (with an epsilon policy documented in rustdoc), split triangles along them
(constrained triangulation of each split face), classify every fragment as inside/outside/coplanar-same/coplanar-opposite
of the other mesh (ray parity with a BVH-like grid, majority/centroid tests that survive coplanar cases), keep fragments
per operation table, flip B's fragments for difference, weld coincident vertices (tolerance relative to model size) and
repair T-junctions so a watertight input pair gives a **watertight** output. A polygon-BSP (csg.js style) implementation in
f64 with an epsilon plane test plus the same clean-up pipeline is also acceptable if it passes the tests below.
Post-process: merge coplanar adjacent fragments back into larger polygons where it does not create non-convex/degenerate
faces (keeps face counts sane: cube minus cube should give ~6+4 quads, not hundreds of triangles), drop degenerate/zero-area
faces, keep normals outward, inherit `face_material`/`face_smooth` from the source face of each fragment (B's faces keep
B's material slot index offset by nothing — the caller remaps via `BooleanReport::b_face_source`), UVs: copy per-corner UVs
from the source polygon where available else leave empty.
Input handling: flip inside-out closed inputs (negative volume) automatically; open meshes are processed best-effort and
reported in `BooleanReport { warnings: Vec<String>, result_is_watertight: bool, a_face_source: Vec<u32>, b_face_source: Vec<u32> }`.
Limits: `BooleanOpts { max_triangles (default 2_000_000), eps_rel (1e-6), merge_coplanar: bool, ..}`; cancel via `ctx`.
Performance target: two 5k-triangle meshes in well under 1 s release; sphere(32x16) minus cylinder fast.

Tests (unit, in `src/`): union/difference/intersection of cube-cube (offset, fully overlapping, touching face, flush
coplanar faces, one inside the other, disjoint), cube-cylinder (window cut), sphere-cube, torus-cube, cylinder-cylinder
(perpendicular), cube-sphere with coplanar poles, 10 sequential cutters in a wall; each checks watertightness, signed volume
against the analytic/inclusion–exclusion value (`vol(A∪B) = vol(A)+vol(B)-vol(A∩B)`), no NaN, `check_structure()`.
A seeded random test (random rotated/translated boxes and spheres) asserting the volume identity within tolerance and no panic.
Inputs with duplicate vertices, degenerate triangles, open boundaries must not panic.

## Part 2 — forge-io

Neutral exchange model (no dependency on the scene crate; the ops/engine layer converts):
```
ModelData { objects: Vec<ModelObject>, materials: Vec<ModelMaterial>, warnings: Vec<String> }
ModelObject { name, mesh: Mesh, slot_materials: Vec<usize> /* per material slot -> materials index */, local: Mat4, parent: Option<usize> }
ModelMaterial { name, base_color: [f32;4], metallic, roughness, emissive: [f32;3] }
ImportLimits { max_bytes, max_verts, max_faces, max_objects }   // with sane Default; checked BEFORE allocating
```
All coordinates inside `ModelData` are **Z-up** (like the rest of RustForge); the readers/writers convert from/to the
Y-up file conventions (`(x,y,z)_zup = (x,-z,y)_yup`, i.e. file `(x,y,z) -> (x,-z,y)`; the inverse on export; also rotate
normals and node matrices; winding is preserved). Export options `ExportOptions { y_up: bool (default true), selection... }`
are handled by the caller choosing which objects to put into the `ModelData`.

* **OBJ**: `import_obj(text_or_bytes, mtl: Option<&str>, &ImportLimits)`: `v` (with optional vertex colours ignored), `vt`,
  `vn` (used to detect smooth vs flat via `s` groups and normals), `f` with all index forms incl. negative/relative indices and
  polygons (n-gons kept), `o`/`g` start new objects (group names), `usemtl` -> per-face material slot, `s off/0/1/N` ->
  per-face smooth flag, `mtllib`/`.mtl` (`newmtl`, `Kd`, `d`/`Tr`, `Ns`->roughness, `Ke`, `Pm`, `Pr`; texture maps ignored with a
  warning), `l` lines -> loose edges, comments, `\` continuation, CRLF, huge files streaming-friendly (no quadratic string
  handling). `export_obj(&ModelData, &ObjExportOptions) -> String` (v/vt/vn/f with `o`, `usemtl`, `s`; indices global across
  objects; **no** `mtllib` line unless `write_mtl` is requested, then `export_mtl` returns the .mtl text).
* **STL**: `import_stl(bytes)` auto-detects binary vs ASCII (binary files can start with "solid"; use the size formula),
  welds identical vertices (exact + tiny epsilon) into an indexed mesh, recomputes nothing but keeps facet order, tolerates
  trailing garbage/zero normals; `export_stl_binary(&ModelData)` / `export_stl_ascii` (all objects merged with transforms applied).
* **glTF 2.0 / GLB**: `import_gltf(bytes, &ImportLimits)` accepts `.glb` (magic `glTF`, JSON + BIN chunks) and `.gltf` JSON with
  `data:` URI buffers (external `uri` files -> clear `IoError::ExternalResource` message); reads `scenes/nodes` (TRS or
  matrix, children -> `parent`), `meshes/primitives` (modes 4 TRIANGLES, 5 STRIP, 6 FAN; others skipped with a warning;
  indices u8/u16/u32 or none; attributes POSITION, NORMAL, TEXCOORD_0 (V flipped: glTF origin is top-left), skip others),
  accessors with `byteStride`, sparse accessors (support or clear error), normalized integer accessors, materials
  (`pbrMetallicRoughness.baseColorFactor/metallicFactor/roughnessFactor`, `emissiveFactor`, `alphaMode`/`alphaCutoff`/
  `doubleSided` (ignored), `KHR_materials_emissive_strength`), multiple primitives of a mesh = material slots of one object,
  unsupported required extensions (Draco, meshopt, KTX) -> clear error. `export_glb(&ModelData) -> Vec<u8>` and
  `export_gltf(&ModelData) -> String` (single buffer as base64 data URI): positions (with min/max), normals, uv0, u16/u32
  indices chosen by vertex count, materials as PBR, nodes with TRS decomposed from `local`, hierarchy via `parent`;
  flat-shaded faces export duplicated verts with face normals, smooth faces share normals; triangulate n-gons.
* `base64::{encode, decode}` (tolerant of whitespace and missing padding) as a public module.
* Errors: `IoError` enum with `Display` giving user-readable messages ("OBJ line 12: face index 99 out of range (only 8
  vertices)"); warnings accumulate in `ModelData.warnings` (cap the list length).
* Everything bounded: reject files whose declared counts exceed the limits *before* allocating; guard against
  index/offset overflow (checked arithmetic), recursion (glTF node cycles), NaN/inf coordinates (-> error or sanitised + warning).

Tests (unit, in `src/`, fixtures under `testdata/` via `include_str!`/`include_bytes!`): hand-written reference files
(cube/pyramid/n-gon OBJ with all index forms, MTL, ASCII+binary STL, a glTF with data URI, a GLB built by your own exporter
plus a hand-assembled one), round trips OBJ/STL/glTF/GLB (export -> import -> same vertex count/bounds/materials/
transforms/hierarchy), Y-up/Z-up conversion (a +Z-up point exports as +Y and returns), UV flip, smooth/flat preservation,
large synthetic meshes (200k triangles) performance smoke, and a **fuzz** test (truncate/bit-flip valid files with a seeded
RNG: only `Err` or `Ok`, never panic or huge allocation).

Everything must pass with `CARGO_TARGET_DIR=/tmp/claude-0/target-csgio tools/cargo-offline.sh test -p forge-csg -p forge-io`
and be warning-free.

## Report
Public API summary, test counts, boolean robustness notes + known gaps (honest), IO feature coverage, conventions the
ops/engine authors must know (< 40 lines).
