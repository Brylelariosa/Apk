# Worker S — `forge-scene`: scene model, parameters/schemas, undo history, project file

Read `docs/ARCHITECTURE.md`, `docs/PROTOCOL.md` (sections 3-4: the UI shows exactly this data) and the source of
`forge-mesh` (`Mesh`, `Selection`, `OpCtx`) and `forge-json`. You own `rust/crates/forge-scene/` only
(`#![forbid(unsafe_code)]`, no external deps; dependencies: forge-math, forge-mesh, forge-json). This crate is **pure data +
bookkeeping** (no geometry algorithms, no modifier evaluation — that is `forge-mods`, no operators — that is `forge-ops`).
Its API is what the operator layer, the Python bindings (`bpy.data.*`) and the engine are written against, so keep it
small, orthogonal, well documented and hard to misuse. It mirrors **Blender's datablock model** closely enough that
`bpy.data.objects / meshes / materials / collections / cameras / lights` can be thin wrappers.

## Model
* Typed ids (`ObjectId`, `MeshId`, `MaterialId`, `CollectionId`, newtypes over `u32`, `Copy/Eq/Ord/Hash/Debug`), one
  monotonically increasing counter per scene, ids never reused (also not after delete/undo).
* **Cheap clone is a hard requirement**: `Scene::clone()` is used for every undo snapshot and for every script run. Store
  datablocks as `BTreeMap<u32, Arc<T>>` (deterministic order = creation order) and meshes as `Arc<Mesh>` inside `Arc<MeshData>`;
  mutate through `Arc::make_mut` (copy-on-write). A scene with 1000 objects of 100k-vertex meshes must clone in microseconds
  and *not* copy mesh buffers (test with `Arc::ptr_eq`). Keep name indices (`HashMap<String, id>`) for O(1) `find_*` lookups.
* `Scene { name, world: World, ... }` with private storage and a public query/mutation API:
  - **Objects**: `Object { name, data: ObjectData, location: Vec3, rotation_mode (Euler(order) | Quaternion), rotation_euler (radians),
    rotation_quat, scale, parent: Option<ObjectId>, parent_inverse: Mat4, hide_viewport (the eye), hide_render, hide_select (lock),
    display_type (Textured|Solid|Wire|Bounds), show_wire, show_in_front (x-ray), modifiers: Vec<Modifier>, props: BTreeMap<String, PropValue>
    (custom properties) }`, `ObjectData::{Mesh(MeshId), Empty{display, size}, Camera(CameraData), Light(LightData)}`.
    `Object::local_matrix()`, `Scene::world_matrix(id)` (parent chain with `parent_inverse`, cycle-safe, cached per call chain),
    `set_world_matrix(id, m)` (decompose relative to the parent), `set_parent(child, parent, keep_transform)` (cycle check),
    `clear_parent(child, keep_transform)`, `children(id)`, `descendants(id)`, `roots()`.
  - **MeshData** (`bpy.data.meshes`): `{ name, mesh: Arc<Mesh>, materials: Vec<Option<MaterialId>> (slots, at data level),
    edit_selection: Selection (vertex flags, may be empty), select_mode: Vertex|Edge|Face }`. Several objects may share one
    MeshData (linked duplicates). `Scene::mesh_mut(id) -> &mut Mesh` (copy-on-write). `users(mesh_id)`.
  - **Material**: `{ name, base_color: [f32;3], alpha, metallic, roughness, emission: [f32;3], emission_strength, ior,
    transmission, specular, blend_mode (Opaque|Blend|Clip), backface_culling, use_nodes (flag), extra: BTreeMap<String,f32>
    (any other Principled input a script set: preserved, flagged "no viewport effect") }` with Blender's defaults
    (base colour 0.8 grey, metallic 0, roughness 0.5, ior 1.45, alpha 1). Viewport/diffuse colour = base colour.
  - **Collections**: tree `Collection { name, parent, children, objects, hide_viewport, hide_select }` with a root
    ("Scene Collection"); an object may be linked into several collections. `link/unlink/move_to_collection`,
    `collection_objects(id, recursive)`, delete with/without objects, visibility inheritance (`is_visible(obj)` honours the
    eye of every collection it lives in), cycle checks.
  - **CameraData** `{ lens, sensor_width, sensor_fit, clip_start, clip_end, ortho: bool, ortho_scale, shift_x/y }`
    (Blender defaults: 50 mm, 36 mm, 0.1, 1000), **LightData** `{ kind: Point|Sun|Spot|Area, color, energy, spot_size, spot_blend,
    radius (shadow_soft_size), area_shape/size }` (Blender defaults: point 1000 W, sun 1.0, spot 1000 W/45°/0.15, area 100 W).
  - **World**: `{ color: [f32;3], ambient_strength }`, scene `unit_scale` (1.0).
  - **Selection**: ordered `selected: Vec<ObjectId>` + `active: Option<ObjectId>` with `select/deselect/select_only/clear_selection/
    invert/select_all(visible & selectable only)/set_active`, kept consistent on delete/hide/undo.
  - Names: `unique_name(kind, wanted)` with Blender's rules (`Cube`, `Cube.001`, `Cube.002`; a trailing `.NNN` is incremented;
    63-byte limit on a char boundary; separate namespaces for objects/meshes/materials/collections/...), rename API.
  - Creation/deletion helpers: `add_mesh(name, Mesh) -> MeshId`, `add_object(name, ObjectData, collection) -> ObjectId`,
    `add_mesh_object(name, mesh, collection)`, `add_material(..)`, `delete_object(id)` (children are un-parented keeping their world
    transform, selection/active updated, orphaned meshes are kept like Blender until `purge_orphans()`), `duplicate_object(id, linked)`
    (names via `unique_name`, modifiers cloned, materials shared), `purge_orphans()`.
  - Queries: `objects()` iterator in creation order, `objects_sorted_by_name()` (Blender's `bpy.data.objects` order), `selected_objects()`,
    `object_bounds_world(id)` (base mesh bounds, `Aabb`), `scene_bounds()`, `stats()` (objects/verts/edges/faces/tris/memory bytes),
    `validate() -> Vec<String>` (dangling refs, parent cycles, bad slot/material indices, selection of dead ids).
* `Scene::revision()` counter bumped by every mutating method (the engine uses it for change detection; make sure *all*
  mutators bump it, including `mesh_mut`).

## `params.rs` — one parameter system for modifiers, operators and the UI
`ParamDef { name, label, kind, default, min, max, soft_min, soft_max, step, unit (None|Length|Angle), options (enum: id + label),
help, visible_if }`, `ParamKind::{Float, Int, Bool, BVec3, Enum, Vec2, Vec3, Color, String, Object, Material}`, `ParamValue`
(matching variants; `Object`/`Material` hold optional ids), `ParamSet` (ordered name -> value map with typed getters
`get_f32/get_i32/get_bool/get_vec3/get_enum/...` and defaults taken from a schema), `Schema = Vec<ParamDef>` helpers:
`schema.defaults() -> ParamSet`, `schema.coerce(name, value) -> Result<ParamValue, ParamError>` (range clamping with a *report*,
enum membership, int<->float coercion, tuple/list -> vec3), `schema.validate(&ParamSet)`. **Angles are stored in radians**
(Blender/Python convention); `to_json`/`from_json` (PROTOCOL.md section 3 `<ParamDef>` format incl. `"visible_if"`, a new `"bvec3"`
type of three booleans, and enum `options` as `[id,label]` pairs) convert `unit: Angle` values to/from **degrees** at the JSON boundary.

## `modifier.rs` — schemas only
`ModifierKind` (`MIRROR, ARRAY, SUBSURF, SOLIDIFY, BEVEL, BOOLEAN, DECIMATE, TRIANGULATE, SMOOTH, DISPLACE, SIMPLE_DEFORM,
EDGE_SPLIT, WELD`) with `from_blender_name("SUBSURF")`/`blender_name()`/`default_name()` ("Subdivision", "Mirror", "Bevel"...),
`Modifier { kind, name, show_viewport, show_render, show_in_editmode, params: ParamSet }`, `Modifier::new(kind, name)` with defaults,
`schema(kind) -> Schema` using **Blender's RNA property names and defaults** (this is what Python scripts set), e.g.
Mirror: `use_axis` (bvec3, default X only), `use_bisect_axis`, `use_bisect_flip_axis`, `use_clip`, `use_mirror_merge`(true),
`merge_threshold`(0.001), `mirror_object`; Array: `count`(2), `fit_type`, `use_relative_offset`(true), `relative_offset_displace`
((1,0,0)), `use_constant_offset`, `constant_offset_displace`((1,0,0)), `use_merge_vertices`, `merge_threshold`, `use_object_offset`,
`offset_object`; Subsurf: `levels`(1), `render_levels`(2), `subdivision_type`, `quality`, `use_creases`; Solidify: `thickness`(0.01),
`offset`(-1), `use_even_offset`, `use_rim`, `use_rim_only`, `use_flip_normals`; Bevel: `width`(0.1), `segments`(1), `limit_method`
(ANGLE), `angle_limit`(30°), `offset_type`, `profile`(0.5), `affect`, `use_clamp_overlap`, `loop_slide`, `harden_normals`, `miter_outer`;
Boolean: `operation`(DIFFERENCE), `operand_type`, `object`, `collection`, `solver`(EXACT), `use_self`, `double_threshold`;
Decimate: `decimate_type`, `ratio`(1.0), `iterations`, `angle_limit`, `use_collapse_triangulate`; Triangulate: `quad_method`, `ngon_method`,
`min_vertices`(4); Smooth: `factor`(0.5), `iterations`(1), `use_x/y/z`; Displace: `strength`(1), `mid_level`(0.5), `direction`(NORMAL);
SimpleDeform: `deform_method`(TWIST), `angle`(45°), `factor`(0.35), `deform_axis`(Z), `limits`, `origin`, `lock_x/y`;
EdgeSplit: `split_angle`(30°), `use_edge_angle`, `use_edge_sharp`; Weld: `merge_threshold`(0.001), `mode`(ALL).
Every param has label/help/ranges so the Kotlin UI renders a decent panel generically. Unknown kinds -> `None` (the bindings
raise a clear "modifier type X is not supported" error).

## `history.rs` — undo/redo
`History` of whole-scene snapshots (cheap thanks to `Arc` sharing): `History::new(&Scene)`, `push(label, &Scene)` (drops redo
branch), `undo() -> Option<Scene>` / `redo()` (return the scene to install), `replace_last(label, &Scene)` (redo-panel re-run),
`can_undo/can_redo/undo_label/redo_label/labels`, `clear(&Scene)`, limits by count (default 128) and by estimated bytes
(count each distinct `Arc<Mesh>` once via pointer identity; default 512 MiB), oldest entries dropped first,
`memory_bytes()`. Pure bookkeeping; the engine decides when to push.

## `project.rs` — `.rforge` file (docs/PROTOCOL.md section 8)
`save_project(&Scene) -> Vec<u8>` / `load_project(&[u8], &ProjectLimits) -> Result<Scene, ProjectError>`; magic `RFORGE01`, version
field, a JSON header (all datablocks except mesh buffers; ids preserved, counters restored) plus compact little-endian binary
mesh blobs (positions f32, face starts, corners, uvs, materials u16, smooth bits, loose edges, edit selection bits),
per-blob and whole-file checksums (CRC32/Adler written by you), forward-compat (unknown JSON fields ignored, newer minor
versions load, newer major versions give a clear error). Loading is **hardened**: every count/offset validated against the
data length and `ProjectLimits` before allocating, indices range-checked (`Mesh::check_structure`), no panic on truncated or
fuzzed input. Shared meshes stay shared (one blob per MeshData). Keep memory peak ~ file size + mesh size.

## Tests (mandatory, unit tests in `src/`)
Hierarchy math (nested parents, parent_inverse, keep_transform on re-parent, cycles rejected), world matrix after
`set_world_matrix`, unique naming sequences incl. `.001` rollover and 63-byte truncation with multi-byte chars, delete/duplicate
semantics (children, selection, linked mesh, modifiers, collections), collection tree ops + visibility inheritance, selection
consistency, clone cost/COW (`Arc::ptr_eq` before/after `mesh_mut`), revision bumps for every mutator (macro/test table),
`ParamSet`/schema coercion + JSON round trips (angles degrees<->radians), every `ModifierKind` has a schema whose defaults
validate and round-trip through JSON, history semantics (branching, replace_last, limits, memory accounting with shared Arcs),
project round trip of a rich scene (all object kinds, shared meshes, materials, modifiers, collections, selection) producing an
identical `Scene` (compare via a dump function), **fuzz** (seeded truncation/bit flips of valid project bytes: only Err/Ok).
Everything must pass with `CARGO_TARGET_DIR=/tmp/claude-0/target-scene tools/cargo-offline.sh test -p forge-scene`, warning-free.

## Report
Public API summary (types + key methods, anything the ops/bpy/engine authors would otherwise guess), conventions
(radians vs degrees, id rules, slot semantics, selection semantics), test counts, known gaps (< 40 lines).
