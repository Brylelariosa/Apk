# Workers K1 and K2 — the Android app (Kotlin + Jetpack Compose + Gradle)

Read `docs/ARCHITECTURE.md`, `docs/PROTOCOL.md` (the Kotlin <-> Rust contract; you implement the Kotlin side exactly),
and the product specs under `/mnt/user-data/uploads/` (`attachment-a71d2f63.txt` sections 2, 3, 5, 7, 9 — touch UX, code editor,
tools, layout, performance; `attachment.txt` section 3 — Python editor; `attachment-8f312eb8.txt` — the CI that builds this project).
Two workers run **in parallel** with a strict directory split. Do not edit the other worker's files. The native library is
built elsewhere (`rust/`, crate `rustforge`, `librustforge.so`); you only talk to it through `NativeBridge` (PROTOCOL.md section 1).

## Shared contract

Package root `com.rustforge.studio`, application id `com.rustforge.studio`, app name "RustForge 3D", Kotlin 1.9.24, Compose
compiler extension 1.5.14, AGP 8.3.2, Gradle 8.6 (wrapper), JDK 17, `compileSdk = targetSdk = 34`, `minSdk = 26`, Compose BOM
`2024.06.00` (Material3 1.2.x), `androidx.activity:activity-compose:1.9.0`, `androidx.core:core-ktx:1.13.1`,
`androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2`, `lifecycle-runtime-compose:2.8.2`, `kotlinx-coroutines-android:1.8.1`.
**No other dependencies** (no material-icons-extended, no serialization plugin, no Hilt/Room/Navigation): JSON, icons, state
and editor logic are written by us. Use only stable Compose APIs where possible; wrap experimental ones in `@OptIn(...)`
(Material3 `ExperimentalMaterial3Api`, foundation `ExperimentalFoundationApi`, ...). You cannot compile Compose/Android code here,
so write conservative, idiomatic code, **explicit imports only** (no `import androidx.*.*`), and re-read every file once for
unresolved names, missing imports, wrong parameter names and `@Composable` context mistakes.

### Verification available offline (use it constantly)
* `tools/run-kotlin-tests.sh` — compiles every directory named `core` or `logic` under `app/src/main/kotlin/` plus
  `app/src/test/kotlin/` and runs all `object <Name>Tests { fun run() { T.test("name") { ... } } }` using the mini harness
  `com.rustforge.studio.testing.T` (`app/src/test/kotlin/.../testing/MiniTest.kt`; no JUnit). **Code in `core`/`logic` directories must be
  pure Kotlin/JVM**: no `android.*`, `androidx.*`, `kotlinx.*` imports.
* `tools/kotlinc.sh --check app/src/main/kotlin` — type-checks *everything* (Compose and Android code too) and prints only
  diagnostics that are not merely "this Android/Compose symbol is unavailable offline" (syntax errors, unknown members of our
  own classes, wrong argument counts to our own functions, ...). The final output must be `0 suspicious diagnostics`.
  Note: because of the filter, imports of external symbols must be explicit.
Neither replaces review: Compose API mistakes will only show up in CI, so double-check every Compose/Material3 call you write.

### Directory split
* **K1** owns: root Gradle files, `app/build.gradle.kts`, manifest, resources, `MainActivity.kt`, `bridge/`, `core/`, `state/`,
  `ui/` (theme, icons, viewport, modeling screens, panels, dialogs, settings, help), `storage/`, and tests under `core/`, `state/`.
* **K2** owns: `app/src/main/kotlin/com/rustforge/studio/code/**` (Code mode) and tests under `.../test/kotlin/.../code/**`.
  Pure-logic classes of K2 live in `code/logic/` (compiled by the offline test runner), UI in `code/ui/`.

### The seam between K1 and K2 (K2 writes this file first thing: `code/CodeContract.kt`; K1 implements/consumes it exactly)
```kotlin
package com.rustforge.studio.code

enum class RunMode { REPLACE, ADD }
enum class ScriptStatus { IDLE, RUNNING, PREVIEW, DONE, ERROR, CANCELLED }
enum class ConsoleKind { OUT, ERR, INFO, WARN }
data class Diagnostic(val line: Int, val col: Int, val endCol: Int, val message: String, val kind: String) // 1-based; kind: SyntaxError|IndentationError|Warning
data class ConsoleLine(val seq: Long, val kind: ConsoleKind, val text: String)
data class ScriptError(val line: Int, val col: Int, val endCol: Int, val message: String, val traceback: String)
data class ScriptState(val status: ScriptStatus, val runMode: RunMode, val elapsedMs: Long, val consoleSeq: Long,
                       val created: Int, val error: ScriptError?)
data class ExampleScript(val name: String, val source: String)

/** Everything the Code workspace needs from the app. Implemented by K1 (JSON/engine calls, file pickers, clipboard). */
interface CodeHost {
    val scriptState: kotlinx.coroutines.flow.StateFlow<ScriptState>   // updated from engine polling
    suspend fun check(source: String): List<Diagnostic>               // script.check
    fun run(source: String, mode: RunMode, preview: Boolean)          // script.run (returns immediately)
    fun stop()                                                        // script.stop
    fun commit()                                                      // script.commit (preview)
    fun discard()                                                     // script.discard (preview)
    suspend fun consoleSince(seq: Long): List<ConsoleLine>            // script.console
    fun clearConsole()                                                // script.clear_console
    suspend fun apiMarkdown(): String                                 // script.api_markdown
    suspend fun aiPrompt(): String                                    // script.ai_prompt
    suspend fun examples(): List<ExampleScript>                       // script.examples
    fun copyToClipboard(label: String, text: String)
    fun pasteFromClipboard(): String?
    fun toast(message: String)
    suspend fun pickScriptToLoad(): Pair<String, String>?             // (file name, text) via the system picker, null if cancelled
    suspend fun saveScriptAs(suggestedName: String, text: String): Boolean
    val filesDir: java.io.File                                        // app-private dir (K2 stores `scripts/` and history here)
}
```
K2's entry points for K1: `class CodeSession(filesDir: File)` (editor text, cursor/selection, editor undo/redo, search state, saved scripts,
history; **lives in K1's ViewModel so switching workspaces or rotating loses nothing**; autosaves the current text to
`filesDir/scripts/current.py` debounced) and
```kotlin
@Composable fun CodeScreen(session: CodeSession, host: CodeHost, viewport: @Composable (Modifier) -> Unit, modifier: Modifier = Modifier)
```
which fills the whole screen below the app's top bar (K1 draws the top bar and the workspace switch). `viewport` is a slot
K1 fills with the live 3D `SurfaceView` (the Code workspace shows the preview next to / above the editor; K2 decides the
split for phone-portrait / phone-landscape / tablet from the available size; K1 draws nothing else in that area).
K1 also needs from K2 only: `CodeSession`, `CodeScreen`, and the types above.

## K1 — app shell, bridge, state, Modeling workspace

### Gradle project (zip root = project root; see the CI workflow)
Files: `settings.gradle.kts` (plugin management + `dependencyResolutionManagement` with `google()`/`mavenCentral()`, `include(":app")`),
root `build.gradle.kts`, `gradle.properties` (`org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8`, `android.useAndroidX=true`,
`android.nonTransitiveRClass=true`, `kotlin.code.style=official`, **`rustAbis=arm64-v8a`** — the CI reads this line to decide which
ABIs to build and `abiFilters` must follow it), `gradlew` (+ `gradlew.bat`, standard Gradle 8.6 wrapper scripts, **LF endings**; the CI
downloads `gradle-wrapper.jar` itself, but `gradle/wrapper/gradle-wrapper.properties` with `distributionUrl=.../gradle-8.6-bin.zip`
must exist), `app/build.gradle.kts`, `app/proguard-rules.pro`.
`app/build.gradle.kts`: Android application, Kotlin, compose enabled (`buildFeatures { compose = true }`, `composeOptions {
kotlinCompilerExtensionVersion = "1.5.14" }`), Java/Kotlin target 17, `ndk { abiFilters += rustAbis }` from the property,
`sourceSets["main"].jniLibs.srcDirs("src/main/jniLibs")` (the CI puts `lib<name>.so` per ABI there),
`packaging { jniLibs { useLegacyPackaging = false } }`, release build type with `isMinifyEnabled = false` (signing is injected by the CI via
`-Pandroid.injected.signing.*`; do not hard-code a signing config), debug build type default.
**`rustPrebuilt`**: the CI passes `-PrustPrebuilt=true` after building the native library itself. When the property is *not* `true`, register an optional
`Exec` task `cargoNdkBuild` (`cargo ndk -t <abi> -o app/src/main/jniLibs build --release` run in `../rust`) that `preBuild` depends on, so local builds
work too; when it is `true`, nothing Rust-related may run. Must be **configuration-cache compatible** (no `project` access at execution time, no
`Task.project` in actions; use `providers`/`layout` APIs) and work with `--parallel --build-cache`.
Manifest: one `MainActivity` (exported, launcher), landscape+portrait, `android:configChanges="orientation|screenSize|smallestScreenSize|screenLayout|keyboardHidden|keyboard|navigation|uiMode|density"`
(never recreated), `android:windowSoftInputMode="adjustResize"`, `uses-feature android:glEsVersion="0x00030000"`, optional
`android.hardware.vulkan.version` feature `required="false"`, `largeHeap="true"`, hardware accelerated, no storage permissions (use SAF pickers), theme
without action bar, dark system bars. Resources: strings, themes, adaptive launcher icon from **vector drawables** (no PNGs), `data_extraction_rules`/backup off.

### Bridge and state (`bridge/`, `core/`, `state/`)
* `bridge/NativeBridge.kt` (exact declarations from PROTOCOL.md section 1), `bridge/EngineClient.kt`: owns the handle, a single-thread command executor
  (`nativeCall` can take 100+ ms for heavy operators; never on the main thread), `suspend fun call(method, args: JsonObject): JsonResult`, a 100 ms poll loop
  while resumed (a coroutine that calls `nativePoll`, parses non-null snapshots on a background thread and publishes `StateFlow<EngineState>`),
  surface lifecycle plumbing, `nativeSetPaused` on stop/start, autosave of the project to `filesDir/autosave.rforge` on stop and restore on start (setting).
  A *fake engine* (`FakeEngine` implementing the same interface, used by `core` tests and by the Compose previews) is strongly recommended.
* `core/Json.kt`: tiny pure-Kotlin JSON (`JsonValue` sealed hierarchy, parser with precise errors, writer with correct escaping/number formatting, typed accessors
  like `obj.str("name")`, `obj.f("x")`, `arr.floats()`), fully unit-tested (unicode escapes, surrogate pairs, exponents, nested depth, malformed input).
* `state/EngineState.kt` + parsers for the **entire** snapshot in PROTOCOL.md section 3 (all keys; tolerate missing/extra fields), `ParamDef` model (all kinds,
  `visible_if`, enum options, units) with value editing helpers that produce the `params` JSON for `op.redo` / `modifier.set`, `Settings` model with dotted-path setters
  (`settings.set`), colour helpers (linear <-> sRGB, HSV), numeric-input parser (`NumericExpr.eval("2*1.5+0.25")`, unit suffixes `m cm mm deg`), all unit-tested against sample JSON
  taken from PROTOCOL.md.

### UI (`ui/`) — professional, touch-first, adaptive, **no emoji, consistent vector icons**
* Theme: dark, restrained, high contrast (Blender-like greys with one accent colour), Material3 `darkColorScheme`, typography tuned for small screens; large touch
  targets (>= 48 dp, bigger hit slop for gizmo-adjacent buttons); light theme optional. `ui/icons/Icons.kt`: own `ImageVector` icon set built with `ImageVector.Builder`
  (24x24, stroke style, one consistent line weight) — at least: undo redo menu settings eye eye-off lock unlock grid axes wire solid material xray perspective ortho
  camera-reset focus view-front/back/left/right/top/bottom select box-select move rotate scale extrude inset bevel loop-cut subdivide delete merge mirror boolean-union/
  difference/intersect add cube sphere cylinder cone torus plane circle light camera empty object-mode edit-mode sculpt-mode vertex-select edge-select face-select
  brush-draw/smooth/grab/inflate/pinch/flatten/clay/crease code run stop preview clear copy paste save open search replace format history import export new folder chevron-left/right/up/down
  close check warning error info help duplicate join parent link wrench mesh hierarchy sliders more invert select-all deselect grow shrink shade-smooth shade-flat. A helper DSL (`icon("name") { line(..); arc(..); rect(..) }`) keeps this compact.
* `ui/viewport/ViewportSurface.kt`: `AndroidView` hosting a `SurfaceView`; `SurfaceHolder.Callback` -> `nativeSurfaceCreated/Changed/Destroyed`; an `OnTouchListener`
  forwarding **every** event unchanged to `nativeTouch` (copy pointer arrays into reused buffers; return true); `performClick` accessibility handled; overlay slot for HUD text
  (tool_state hint/value, stats, FPS, mode/select-mode chips, "view" label, axis hints). The Surface is created once per workspace composition; switching workspaces recreates it (the engine keeps all state).
* **Modeling workspace** (`ui/modeling/`): top bar (project: new/open/save/save as/import/export (OBJ, STL, GLB, glTF with option sheets)/settings/help; scene: workspace switch Modeling|Code,
  undo/redo buttons **always visible**, camera/view menu: front/back/left/right/top/bottom, reset (camera-reset button always visible), perspective/ortho toggle, shading mode, grid/axes/wire/x-ray toggles), left tool panel
  (context-sensitive per mode from PROTOCOL.md section 6: navigate, select, box select, move, rotate, scale; edit: extrude, inset, bevel, loop cut; sculpt: brushes with radius/strength/falloff/symmetry sliders), bottom
  modeling toolbar (mode switch object/edit/sculpt, vertex/edge/face select mode, select all/none/invert/grow/shrink/linked/hierarchy children+parent, add menu (all primitives + empty/camera/light), edit operators
  (subdivide, delete, merge, dissolve, flip normals, smooth/flat shading, mirror, boolean union/difference/intersect (`forge.boolean`), duplicate, join, separate...) each running `op.run` with sensible defaults),
  the **redo panel** (generic `ParamDef` editor for `last_op`, live `op.redo` with debounce, numeric keyboard entry for every number), collapsible **hierarchy** panel (collections tree + objects, visibility/lock toggles,
  rename, drag-free reparent via menu, select/multi-select, long-press menu: duplicate/delete/rename/move to collection/parent), **properties panel** (tabs: Object transform with numeric fields via `object.set` + a
  "Numeric transform" dialog (`transform.numeric`), Modifiers (add menu from the 13 kinds, list with enable/disable/move/apply/remove, each modifier's generic ParamDef editor via `modifier.set`), Material (slot list, create/assign,
  colour picker (HSV + hex, linear/sRGB handled), metallic/roughness/alpha/emission sliders), Mesh info (counts, validity issues), Light/Camera properties), settings dialog bound to PROTOCOL.md section 5
  (touch sensitivity, gesture mapping, hit radius, gizmo size, snapping (grid size, angle step), stylus, viewport quality/polygon limit/MSAA, script limits; "About" with backend name from `nativeBackendName`), help overlay
  explaining every gesture/tool + **tooltips on every toolbar button** (long-press tooltip via Material3 `TooltipBox`, wrapped in `@OptIn`).
* **Adaptive layout**: phone portrait (viewport on top, toolbars as compact rails/bottom sheets, panels as bottom sheets), phone landscape (tool rail left, properties/hierarchy as slide-over drawers), tablet / large widths
  (docked left tool panel + right dock with hierarchy above properties). Decide from `LocalConfiguration` / `BoxWithConstraints` (`smallestScreenWidthDp >= 600` = tablet) and recompute on rotation without losing state (ViewModel).
* `AppViewModel` (`androidx.lifecycle.ViewModel`) owns `EngineClient`, `CodeSession` (from K2), workspace selection, dialogs, and implements `CodeHost`. Switching workspaces never loses editor text, scene or undo history.
* `storage/`: Storage Access Framework (`ActivityResultContracts.OpenDocument`, `CreateDocument`, mime types for obj/stl/glb/gltf/rforge/py), export through `nativeExport` bytes, import through `nativeImport`, project save/load,
  recent files list; errors become snackbars.
* Performance: only recompose what changed (`StateFlow` + `derivedStateOf`, stable data classes, `key`s in lazy lists), no per-frame allocations in the touch path, no work on the main thread for engine calls.

### K1 tests (pure Kotlin, `core/`, `state/` — run with the offline runner)
Json (round trips, errors, escapes, big numbers), snapshot parsing of the full PROTOCOL.md sample + partial/garbled snapshots, ParamDef edit -> params JSON, `visible_if`, settings paths, `NumericExpr`, colour conversions
(round trip within epsilon), FakeEngine protocol behaviour, version/ABI property parsing helpers if any.

## K2 — Code workspace (`code/`)

Dark professional code editor + console + run controls. **Everything is custom Compose** (no WebView, no external editor lib).
* `code/logic/` (pure Kotlin, heavily unit-tested):
  - `PyTokenizer`: fast incremental-friendly Python tokenizer for highlighting (keywords, builtins, `bpy`/`bmesh`/`mathutils` names highlighted as API, strings incl. triple-quoted/raw/f-strings with nested `{}`, numbers with
    underscores/hex/exp/complex, comments, decorators, operators, line continuations); tolerant of broken code; per-line state so only changed lines are re-tokenized.
  - `PyFormatter`: **semantics-preserving** formatter (no AST needed): tabs -> spaces, indentation normalized to 4 spaces per block level (detect the file's indent unit), continuation lines inside brackets keep relative alignment,
    trailing whitespace removed, max 2 consecutive blank lines, single trailing newline, `\r\n` -> `\n`; never touches string/comment contents; **idempotent**; tested on tricky inputs (multi-line strings, backslash continuation, nested
    brackets, decorators, `if x: y`, mixed indentation) plus a property test that tokens (minus whitespace) are unchanged.
  - `AutoIndent`: indentation after Enter (copy previous indent, +4 after a line ending in `:` ignoring comments/strings, dedent after `return/pass/break/continue/raise`), smart Backspace (delete one indent unit), Tab/Shift-Tab on selections, auto-closing of brackets/quotes with overtype, toggle comment (`Ctrl+/`).
  - `SearchEngine`: find all/next/previous with case-sensitive + whole-word + regex options (compile errors reported, never crash), replace one/all with `$1` groups (regex mode), match counting; works on 100k-line strings fast.
  - `DiagnosticsMapper`: engine `Diagnostic`/`ScriptError` (1-based line/col) -> text offsets; merging/deduplication; gutter marks.
  - `EditorBuffer` (text + selection + undo/redo with grouping of typing, max memory), `ScriptHistory` (ring of executed scripts with timestamps/hashes, dedupe consecutive identical), `ScriptLibrary` (saved scripts directory, names sanitised, metadata file).
* `code/ui/`: `CodeEditor` — `BasicTextField` + `VisualTransformation` highlighting, line-number gutter synced with scrolling, current-line highlight, error/warning underline + gutter icons with message on tap, matching-bracket
  highlight, pinch-to-zoom font size (persisted), horizontal+vertical scroll, **extra key row** above the soft keyboard (Tab, Shift-Tab, `( ) [ ] { } : = " ' _ # , . + - * / % ` and undo/redo) because phone keyboards are poor for code,
  hardware keyboard shortcuts (Ctrl+Enter run, Ctrl+S save, Ctrl+F find, Ctrl+Z/Y, Ctrl+/, Tab), selection handles and copy/paste/select-all via the platform toolbar, large-script performance (5 000 lines scroll smoothly: highlight only
  visible lines or memoize per-line `AnnotatedString`s). Search/replace bar (find, next/prev, replace, replace all, options, match counter). Auto-validate: debounced `host.check()` while typing (300 ms, cancelled by new input) marks errors live.
  `ConsolePanel` (colour by kind, selectable text, auto-scroll, tap an error line -> jump to editor line, copy all, clear; fed by `host.consoleSince` whenever `scriptState.consoleSeq` changes), `RunBar` (Run, Stop (enabled while running), Preview,
  Clear console, **Replace scene / Add to scene** segmented toggle, status chip with elapsed time and created-object count, progress indicator while running; when `PREVIEW`: Commit / Discard buttons),
  **Copy API Reference** and **Copy AI Prompt** buttons (prominent: top of the workspace; also in the overflow) with a confirmation snackbar, script menu (New, Open (picker), Save (`saveScriptAs`), Saved scripts list (library), History, Examples list
  (`host.examples()`), Format, Search), responsive layouts: phone portrait = editor above console with a collapsible preview strip; phone landscape = editor | (preview over console); tablet = editor | preview with console below the editor.
* Tests: tokenizer on many snippets (Blender scripts incl. f-strings with nested quotes), formatter idempotence + token preservation (property tests with a seeded generator of messy code), auto-indent cases, search engine
  (regex errors, replace-all offsets with overlapping/empty matches), diagnostics mapping edge cases (line beyond end, tabs, CRLF, unicode/emoji in strings), buffer undo grouping, history ring, library name sanitisation.

## Both
Keep files focused (< ~800 lines), document public classes briefly, no dead code, no TODO stubs. Final report (< 40 lines): file tree summary, what is tested
(counts from `tools/run-kotlin-tests.sh`), `tools/kotlinc.sh --check` result, known risks (list the Compose/Material3 APIs you were least sure about so the integrator can double check them), deviations from PROTOCOL.md.
