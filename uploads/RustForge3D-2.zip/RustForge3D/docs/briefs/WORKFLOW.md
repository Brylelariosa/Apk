# Worker workflow rules (read first; the usage budget of this project is limited)

Tokens are scarce: every tool call re-sends your whole context, so keep the context small and the calls few.
1. Read `docs/ARCHITECTURE.md`, then `docs/API-core.md` (signature digest of forge-math/json/mesh) instead of the full sources of the
   frozen crates; open a source file (with `offset`/`limit`) only for details you actually need. Read your brief once.
2. Write each module with **one `Write` call** (complete file, ~200-800 lines). Do not re-read files you just wrote; do not `cat`/`Read` big files
   to "check" them — the compiler and your tests are the check. Prefer `Edit` for fixes.
3. Compile/test quietly and narrowly: `CARGO_TARGET_DIR=<yours> tools/cargo-offline.sh test -p <crate> 2>&1 | tail -40` (run from the project root);
   first `check` the whole crate, then run tests; fix errors in batches (read the first ~5 errors, fix all you can see, rebuild).
4. Tests are mandatory but proportionate: a few high-value tests per module (exact expected numbers, invariants such as watertight/Euler/volume),
   plus the one seeded fuzz/robustness test the brief names. No giant generated test tables, no long-running benchmarks (mark any `#[ignore]`).
5. Never ask questions, never wait: decide, document the decision in rustdoc, continue. Stay inside the files you own.
6. Finish with the short report the brief asks for (public API summary with module/function names, test counts, known gaps). No code in the report.
