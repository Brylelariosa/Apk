# Worker I — `forge-input` (camera, gestures, gizmos, snapping) and `forge-sculpt` (sculpt brushes)

Read `docs/ARCHITECTURE.md`, `docs/PROTOCOL.md` (sections 2, 5, 6: touch conventions, settings, tools) and the source of
`forge-math` and `forge-mesh`. You own `rust/crates/forge-input/` and `rust/crates/forge-sculpt/` only.
`#![forbid(unsafe_code)]`, no external dependencies (forge-input -> forge-math; forge-sculpt -> forge-math, forge-mesh).
Everything is **deterministic and unit-testable**: no clocks, no threads; time comes in with the events.
This is what makes the app feel professional on a phone: precision, predictability, no accidental camera moves.

## Part 1 — forge-input

### camera.rs
`Camera` (orbit camera around a target: `target`, `yaw`, `pitch`, `distance`, `fov_y`, `ortho: bool`, `near/far` derived from
distance and scene radius, viewport size). Z-up, right-handed. Methods: `orbit(dx_px, dy_px, sensitivity)` (pitch clamped,
no gimbal flips, optional "turntable" behaviour), `pan(dx_px, dy_px)` (screen-aligned, speed scaled so the point under the
finger follows the finger at the target depth, both projections), `zoom(factor)` / `zoom_at(factor, screen_point)`
(zoom towards the finger like maps), `view_matrix/proj_matrix/view_proj` (`Mat4`, depth 0..1), `eye()`,
`unproject(screen_px) -> Ray`, `project(world) -> Option<Vec2 px>`, `pixel_size_at(world_point)` (world units per pixel),
`frame_bounds(Aabb, margin)`, `snap_view(ViewPreset::{Front,Back,Left,Right,Top,Bottom,Reset})` with `CameraAnim`
(eased interpolation of target/yaw/pitch/distance, `update(dt)`, `is_animating()`), perspective <-> orthographic switch that
keeps the apparent size (ortho scale derived from distance and fov), `view_label()` ("User", "Front"...), JSON-friendly
`CameraState` struct for the engine's state snapshot. Blender conventions: Front = looking along +Y (from -Y), Top = from +Z.

### gestures.rs — raw pointers -> intent
`GestureRecognizer::feed(&PointerEvent{ action, id, x, y, time_ms, pressure, tool_type }, &GestureConfig) -> Vec<Gesture>`
with a small `push_touch_batch(...)` helper that mirrors Android `MotionEvent` batches
(`action` 0 down, 1 up, 2 move, 3 cancel, 5 pointer-down, 6 pointer-up; all pointers listed each time).
Emits: `Tap{pos,count}` (1 tap, 2 = double tap; tolerant timing/distance scaled by `drag_threshold_dp`/density),
`LongPress{pos}`, `OneFingerDragStart/Move{pos,delta,total}/End`, `TwoFinger{pan_delta, pinch_scale, twist_rad, center}`
(pan + pinch + twist simultaneously, jitter-filtered, starts only after clear intent so a slightly uneven two-finger tap
does not move the camera), `ThreeFingerSwipe{dir: Left|Right|Up|Down}` and `ThreeFingerTap`, `Cancel`.
Stylus (`tool_type` 2) and mouse (3) are precise pointers: smaller drag threshold, pressure passed through; finger touches are
ignored for drawing while a stylus is active only if `touch.stylus` palm rejection says so (document). Eraser (4) = `Tap`
with `eraser: true`.
**Claiming**: `claim(pointer_id)` lets the engine tell the recognizer a gizmo / modal tool owns that pointer — the recognizer
then emits `ClaimedMove{id,pos,delta}` / `ClaimedUp` for it and never any camera gesture ("prevent camera movement when
interacting with modeling tools"); a second finger touching down during a claimed drag is ignored (or reported as
`SecondFingerDuringClaim` so the engine can toggle a modifier like additive-select). Config: `GestureConfig` mirrors
PROTOCOL.md `settings.touch` + `settings.gestures` (sensitivity, thresholds in dp with density, drag/tap timings).
Tests: scripted event sequences (timestamps) for tap, double tap, long press, drag, pinch-zoom, two-finger pan, twist,
tap-vs-drag threshold, two-finger tap that must not zoom, three-finger swipes, claimed drag with camera lockout, stylus
precision, event reordering/dropped pointers (never panic, never get stuck: `reset()` and automatic recovery after cancel/up
of unknown ids).

### nav.rs
`NavController::apply(&mut Camera, &Gesture, &GestureConfig, tool_context) -> NavResult` maps gestures to camera motion per
the settings (`one_finger`: orbit|pan|none; `two_finger`: pan|orbit; `pinch`: zoom|none; `double_tap`: focus -> returns
`NavResult::FocusRequested`; invert-Y; per-axis speeds) and inertia (optional fling with decay, `update(dt)`), always
cancelling inertia on a new touch.

### gizmo.rs — transform gizmos with great touch ergonomics
`TransformGizmo { mode: Move|Rotate|Scale, space: Global|Local, pivot: Vec3, orientation: Quat, size_px }`:
* geometry scales to a constant on-screen size (`size_px` * settings.gizmo.size, dp-aware, caller passes px), correct in
  perspective and orthographic cameras;
* `hit_test(&Camera, pointer_px, hit_radius_px) -> Option<Handle>` with generous touch radii; handles: Move = axis arrows
  X/Y/Z, plane squares XY/YZ/XZ, centre (free/screen-plane move); Rotate = three rings X/Y/Z (+ outer free-rotation trackball
  ring); Scale = axis cubes X/Y/Z and centre (uniform); nearest-wins with priority rules documented; handles facing away
  are still grabbable but visually faded;
* `begin_drag(handle, &Camera, pointer_px)`, `drag(&Camera, pointer_px, &SnapSettings) -> GizmoDelta` where `GizmoDelta` is
  `Translate(Vec3) | Rotate{axis: Vec3, angle: f32} | RotateFree(Quat) | Scale(Vec3)` + a `display: String` for the HUD
  ("D 1.250 m  X", "45.0°", "1.35x"). Math: closest point between pointer ray and axis line (clamped against grazing
  angles), ray-plane intersection for plane handles, angle-around-axis from pointer vectors in the ring plane (with a
  screen-space tangent fallback when the ring is edge-on), uniform scale from screen distance ratio; all stable when the
  pointer leaves the object, no jumps at drag start (delta relative to the grab point); `cancel_drag()`;
* snapping (`SnapSettings` mirrors PROTOCOL.md `settings.snap`): grid translation snap per axis, angle snap (15° default),
  scale step; snapping visible in the returned delta; `vertex` snapping helper `snap_to_points(candidates, ...)`;
* drawing: `draw(&Camera, &mut GizmoGeometry)` pushes plain data (`lines: Vec<ColoredLine>`, `triangles: Vec<ColoredTri>`,
  `colors RGBA f32`, X red / Y green / Z blue / active handle highlighted / hovered handle brighter, ring segments as
  polylines with depth-fade for the back half, arrow cones as triangles, plane squares semi-transparent); the engine converts
  it to its overlay vertex format (no dependency on engine types here).
Tests: hit-test priorities, constant screen size (project geometry and measure), drag math on every handle against analytic
expectations in perspective and ortho, snapping, no NaN with degenerate cameras (zero-size viewport, pivot at the eye,
axis parallel to the view direction), draw output sanity (counts, colour per axis).

### rubber.rs / snap.rs
`RubberBand` (two pointers -> normalized rect, add/subtract/replace mode, min size), `snap` helpers (`snap_value`,
`snap_vec3_grid`, `snap_angle`) reused by gizmos and numeric input.

## Part 2 — forge-sculpt

`Brush { kind: Draw|Smooth|Grab|Inflate|Pinch|Flatten|Clay|Crease, radius, strength (0..1), falloff: Smooth|Sphere|Linear|
Constant|Sharp, invert: bool, symmetry: [bool;3] }` (matches PROTOCOL.md `sculpt`), radius in **local mesh units** (the
engine converts world/screen radius using the object scale).
`SculptSession::begin(&Mesh) -> SculptSession`: builds adjacency (neighbour lists from `Topology`), a vertex spatial grid
(`SpatialGrid`, cell ~ radius), cached vertex normals; `stroke_begin(brush)`, `dab(&mut Mesh, hit: Vec3, normal: Vec3,
view_dir: Vec3, pressure) -> &DirtyVerts` (applies the brush to vertices within `radius` with falloff weights, mirrored dabs
for each enabled symmetry axis, updates cached normals only for affected verts + neighbours and returns the sorted list of
moved vertex indices for `RenderBuffers::update_positions`), `grab_begin(hit)` / `grab_move(&mut Mesh, delta)` (weights and
vertex set frozen at stroke start, Blender-style), `stroke_end()` (returns the aggregate dirty set); `rebuild_if_topology_changed`.
Brush behaviour (Blender-like): Draw = displace along averaged normal (invert = dig), Smooth = Laplacian relaxation toward
neighbour mean (weights by falloff*strength, iterative substeps for high strength), Inflate = along each vertex normal,
Pinch = toward the brush centre in the tangent plane, Flatten = toward the area plane (fit plane from verts in radius: area
normal + centre), Clay = flatten + build up, Crease = pinch + displace into the surface. Strength scaled so a typical stroke
at 0.5 moves about 5-10% of radius per dab; spacing is the engine's job (provide `suggested_spacing(brush)`).
Performance: touch only vertices in the radius (grid query), allocation-free dabs (reuse buffers in the session),
parallelise only above ~50k affected verts; a dab on a 1M-vertex mesh must cost O(verts in radius), not O(mesh).
Tests: each brush's analytic effect on a plane/sphere grid, symmetry (mirrored result equals mirror image), grab keeps
continuity and returns to the start when moved back, smooth reduces roughness (variance of heights), no NaN/inf for
degenerate normals or zero radius/strength, dirty list == vertices whose position actually changed, **incremental
`RenderBuffers::update_positions` after a dab equals a full rebuild** (compare buffers), dab cost scales with radius
(not mesh size) on a 250k-vertex grid (`#[ignore]` benchmark printing times).

Everything must pass with `CARGO_TARGET_DIR=/tmp/claude-0/target-input tools/cargo-offline.sh test -p forge-input -p forge-sculpt`
and be warning-free. Split files by module (< ~1500 lines each).

## Report
Public API summary (types + key methods), conventions (Blender view directions, gizmo handle ids, gesture semantics),
test counts, known gaps (< 40 lines).
