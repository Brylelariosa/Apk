# RustForge 3D — Kotlin <-> Rust protocol (frozen contract)

Producer of state / consumer of commands: `forge-engine` (Rust). Consumer of state / producer of commands: the Kotlin app.
The JNI glue (`rustforge` crate, worker R) is a dumb pipe: it never interprets the JSON. Both sides implement exactly this
document. If something is missing, the side that needs it adds it **here** (small, additive, backwards compatible) and
mentions it in its report.

> **Implemented subset (zip 1).** Everything below is implemented except: all `script.*` commands (they answer
> `{"ok":false,"error":"..."}` stating scripting is not part of this build and `snapshot.script.available` is `false`),
> `file.import` / `file.export` mesh formats, sculpt mode (`sculpt.*`), cameras as scene objects, the `three_finger`
> gesture and `snap.vertex`. The Kotlin app reads `script.available` and mesh IO / sculpt through
> `core/Capabilities.kt`. See `STATUS.md`.

## 1. JNI surface

Kotlin: `package com.rustforge.studio.bridge`, `object NativeBridge` with `System.loadLibrary("rustforge")` in `init`.
Every function is `@JvmStatic external`. Rust exports `Java_com_rustforge_studio_bridge_NativeBridge_<name>` (no
underscores anywhere in package/class/method names, so no JNI escaping is needed; the 2nd argument is a `JClass`).

| Kotlin signature | Meaning |
|---|---|
| `nativeCreate(filesDir: String, density: Float): Long` | create engine + renderer shell; returns an opaque non-zero handle, `0` on failure |
| `nativeDestroy(handle: Long)` | stop render thread, release everything |
| `nativeSurfaceCreated(handle: Long, surface: Surface, width: Int, height: Int): Boolean` | start rendering into the `android.view.Surface`; false = no Vulkan/GL adapter (reason in `nativeLastError`) |
| `nativeSurfaceChanged(handle: Long, width: Int, height: Int)` | surface resized |
| `nativeSurfaceDestroyed(handle: Long)` | drop the GPU surface, keep the engine |
| `nativeSetPaused(handle: Long, paused: Boolean)` | activity stopped/started: pause the render loop |
| `nativeTouch(handle: Long, action: Int, actionIndex: Int, timeMs: Long, count: Int, ids: IntArray, xs: FloatArray, ys: FloatArray, pressures: FloatArray, toolTypes: IntArray)` | raw `MotionEvent` snapshot (arrays hold >= `count` entries) |
| `nativeCall(handle: Long, method: String, argsJson: String): String` | synchronous command, returns a JSON object (section 4) |
| `nativePoll(handle: Long): String?` | full state snapshot JSON (section 3) if anything changed since the last poll, else `null` |
| `nativeImport(handle: Long, fileName: String, data: ByteArray): String` | import `.obj .stl .glb .gltf .rforge`; JSON result (section 8) |
| `nativeExport(handle: Long, format: String, optsJson: String): ByteArray?` | `format` = `obj`/`stl`/`glb`/`gltf`; null on error (`nativeLastError`) |
| `nativeSaveProject(handle: Long): ByteArray?` | `.rforge` project bytes |
| `nativeLoadProject(handle: Long, data: ByteArray): String` | JSON result |
| `nativeLastError(handle: Long): String` | last error text (empty if none) |
| `nativeBackendName(handle: Long): String` | `"Vulkan"`, `"OpenGL ES"` or `""` (no surface yet); shown in Settings > About |

Rules: any thread may call any function; the engine is behind one mutex and every call returns quickly (long work such
as script execution runs on engine-owned threads). A Rust panic never crosses JNI: it becomes
`{"ok":false,"error":"internal error: ..."}` / `null` / `false` and is logged. The render thread is owned by Rust.
Kotlin polls state about every 100 ms while the app is visible (a coroutine; `nativePoll` is cheap when nothing changed).

## 2. Conventions

* Touch coordinates: pixels, origin top-left of the `SurfaceView`. Kotlin forwards **every** `MotionEvent` of the
  SurfaceView untouched (`action = event.actionMasked`, `actionIndex = event.actionIndex`, `toolTypes` =
  `MotionEvent.TOOL_TYPE_*`); all gesture logic lives in Rust. Compose overlays (toolbars, panels) consume their own
  touches; the SurfaceView only sees touches that land on the viewport.
* World: right-handed, **Z-up**, metres. JSON rotations are **degrees** (Euler `XYZ`, Blender order); the engine stores
  radians. Colours are **linear** RGBA floats 0..1 (Kotlin converts to/from sRGB for pickers).
* IDs: objects, collections, materials, lights/cameras use `u32` ids, unique for the session, never reused, stable
  across undo/redo. `0` means "none / root".
* Every `call` result is an object with `"ok": true|false`; failures add `"error"` (human text) and optional `"code"`.
* Unknown JSON fields are ignored by both sides (forward compatible). Missing optional args take documented defaults.

## 3. State snapshot (`nativePoll`)

One JSON object; every key is always present unless noted. `rev` increases on every visible change.

```
{
 "rev": 41,
 "mode": "object" | "edit" | "sculpt",
 "select_mode": "vertex" | "edge" | "face",        // edit mode element mode
 "tool": "<tool id>",                              // section 6
 "tool_state": null | {"kind":"extrude","label":"Extrude","value":0.5,"unit":"m","hint":"Drag along the normal"},
 "camera": {"projection":"persp"|"ortho","view":"user"|"front"|"back"|"left"|"right"|"top"|"bottom","fov_deg":50},
 "view": {"shading":"solid"|"wire"|"material","grid":true,"axes":true,"wire_overlay":false,"xray":false,"stats":false},
 "scene": {
   "name": "Scene",
   "collections": [{"id":1,"name":"Collection","parent":0,"visible":true,"locked":false}],
   "objects": [{"id":5,"name":"Cube","kind":"mesh"|"empty"|"camera"|"light","parent":0,"collection":1,
                "visible":true,"locked":false,"selected":true,"active":true,
                "verts":8,"faces":6,"modifiers":1,"material":"Material"|null}],
   "active": 5,                                    // 0 = none
   "selected_count": 1
 },
 "active": null | {                                // details of the active object
   "id":5,"name":"Cube","kind":"mesh","parent":0,"collection":1,
   "transform":{"location":[0,0,0],"rotation":[0,0,0],"scale":[1,1,1]},
   "dimensions":[2,2,2],
   "mesh": {"verts":8,"edges":12,"faces":6,"tris":12,"data_name":"Cube","valid":true,"issues":[]} | null,
   "modifiers":[{"index":0,"type":"MIRROR","name":"Mirror","show_viewport":true,"show_render":true,"params":[<ParamDef>...]}],
   "slots":[{"slot":0,"material":3,"name":"Material"}],
   "light": null | {"type":"POINT"|"SUN"|"SPOT","color":[1,1,1],"energy":1000,"spot_size_deg":45,"spot_blend":0.15},
   "camera": null | {"lens_mm":50,"sensor_mm":36,"clip_start":0.1,"clip_end":1000,"ortho":false,"ortho_scale":6}
 },
 "materials": [{"id":3,"name":"Material","base_color":[0.8,0.8,0.8,1],"metallic":0,"roughness":0.5,"alpha":1,
                "emission":[0,0,0],"emission_strength":0,"users":2}],
 "edit": null | {"verts":{"total":8,"selected":2},"edges":{"total":12,"selected":1},"faces":{"total":6,"selected":0},
                 "median":[0,0,0]},               // median of the selected vertices (local space)
 "last_op": null | {"id":"mesh.extrude_region_move","label":"Extrude","params":[<ParamDef>...]},   // redo panel
 "undo": {"can_undo":true,"can_redo":false,"undo_label":"Add Cube","redo_label":"","depth":4},
 "sculpt": {"brush":"draw","radius":0.35,"strength":0.5,"falloff":"smooth","invert":false,"symmetry":[false,false,false],
            "radius_unit":"world"},
 "settings": { ...section 5... },
 "script": {"status":"idle"|"running"|"preview"|"done"|"error"|"cancelled","run_mode":"replace"|"add",
            "elapsed_ms":0,"console_seq":0,"created":0,
            "error": null | {"line":3,"col":1,"end_col":9,"message":"NameError: name 'x' is not defined","traceback":"..."}},
 "stats": {"objects":3,"verts":500,"faces":420,"tris":840,"gpu_mb":1.2,"fps":60,"quality":"high"},
 "toast": null | {"seq":7,"level":"info"|"warn"|"error","text":"Mesh has 2 non-manifold edges"}
}
```

`<ParamDef>` (used by modifiers, `last_op` and `op.list`):

```
{"name":"offset","label":"Offset","type":"float"|"int"|"bool"|"bvec3"|"enum"|"vec2"|"vec3"|"color"|"string"|"object"|"material",
 "value":0.1,                       // current value (vec2/vec3/color/bvec3: array, object/material: id, enum: option id)
 "default":0.1,"min":0,"max":100,"soft_max":10,"step":0.01,"unit":"length"|"angle"|"none",   // angle values are DEGREES
 "options":[["EDGES","Edges"],["VERTICES","Vertices"]],     // enum only
 "help":"Distance of the bevel",
 "visible_if": null | {"name":"affect","equals":"EDGES"}}   // optional: only show when another param has a value
```

Kotlin renders any ParamDef list generically (sliders/steppers for numbers with numeric keyboard entry, switches,
dropdowns, vector fields, colour picker, object pickers fed from `scene.objects`). Changing a value:
`op.redo` (for `last_op`) or `modifier.set` (for modifiers) — both take `{"params":{"name":value,...}}`.

Console lines are not part of the snapshot (they can be many): fetch with `script.console` (section 7). A change of
`script.console_seq` tells Kotlin new lines exist.

## 4. Commands (`nativeCall`)

`nativeCall(handle, "<method>", "<args json object or {}>")` -> `{"ok":true, ...result fields}`.
Ids are the `u32` ids from the snapshot. "Undo step" = the call pushes exactly one undo entry (label given).

### 4.1 Session / view / selection (no undo steps unless stated)
| method | args | result / notes |
|---|---|---|
| `mode.set` | `{"mode":"object"\|"edit"\|"sculpt"}` | enter/leave edit or sculpt on the active mesh object (error if none) |
| `select.mode` | `{"mode":"vertex"\|"edge"\|"face"}` | converts the current selection like Blender |
| `select.all` / `select.none` / `select.invert` | `{}` | object mode: objects; edit mode: elements |
| `select.set` | `{"ids":[5,6],"extend":false}` | object mode only; last id becomes active |
| `select.more` / `select.less` / `select.linked` | `{}` | edit mode |
| `select.hierarchy` | `{"action":"children"\|"parent"\|"all_children","extend":false}` | object mode ("selection through hierarchy") |
| `select.box` | `{"x0":..,"y0":..,"x1":..,"y1":..,"op":"set"\|"add"\|"sub","xray":false}` | programmatic box select in pixels (touch box select goes through `nativeTouch`) |
| `view.preset` | `{"view":"front"\|"back"\|"left"\|"right"\|"top"\|"bottom"\|"reset"}` | animated camera snap (`reset` = default 3/4 view, frames the scene) |
| `view.projection` | `{"projection":"persp"\|"ortho"\|"toggle"}` | |
| `view.focus` | `{"target":"selection"\|"all"}` | frame selection / everything |
| `view.set` | `{"shading":..,"grid":..,"axes":..,"wire_overlay":..,"xray":..,"stats":..}` | any subset |
| `tool.set` | `{"tool":"<id>"}` | section 6 |
| `tool.cancel` | `{}` | abort a running modal tool (drag) |
| `sculpt.set` | `{"brush":..,"radius":..,"strength":..,"falloff":"smooth"\|"sphere"\|"linear"\|"constant"\|"sharp","invert":..,"symmetry":[x,y,z]}` | any subset |
| `settings.get` / `settings.set` | `{}` / `{"path":"touch.sensitivity","value":1.2}` or `{"values":{path:value,...}}` | persisted to `<filesDir>/settings.json`; `settings.get` returns `{"settings":{...}}`; unknown path -> error |
| `project.new` | `{}` | empty scene (one undo-less reset, clears history) |
| `debug.memory` | `{}` | `{"rss_mb":..,"scene_mb":..,"gpu_mb":..}` |

### 4.2 Undo
`undo`, `redo` (`{}`), `undo.history` -> `{"undo":["Add Cube","Extrude"],"redo":[...]}` (most recent first).

### 4.3 Operators (everything that edits the scene and is undoable)
Both the UI and Python (`bpy.ops.*`) run the *same* operator registry (crate `forge-ops`); operator ids are
Blender-style `category.name` strings.

| method | args | result |
|---|---|---|
| `op.list` | `{"context":"object"\|"edit"\|"all"}` | `{"ops":[{"id","label","category","context":"object"\|"edit"\|"both","params":[<ParamDef>...]}]}` |
| `op.run` | `{"id":"mesh.primitive_cube_add","params":{"size":2,"location":[0,0,0]}}` | `{"report":"FINISHED"\|"CANCELLED","message":"...","created":[ids]}`; pushes one undo step; becomes `last_op` |
| `op.redo` | `{"params":{...}}` | re-runs `last_op` from the pre-op state with the changed params (replaces the undo entry) |

Operator ids the **UI** relies on (all must exist; params use Blender names/semantics, angles in degrees through
`op.run`, radians through Python):
* add: `mesh.primitive_cube_add`, `..._uv_sphere_add`, `..._ico_sphere_add`, `..._cylinder_add`, `..._cone_add`,
  `..._torus_add`, `..._plane_add`, `..._circle_add`, `..._grid_add`, `object.empty_add`, `object.camera_add`, `object.light_add`
* object: `object.delete`, `object.duplicate_move`, `object.join`, `object.shade_smooth`, `object.shade_flat`,
  `object.parent_set`, `object.parent_clear`, `object.origin_set`, `object.transform_apply`, `object.modifier_add`,
  `object.modifier_remove`, `object.modifier_apply`, `object.hide_view_set`, `object.move_to_collection`,
  `object.select_all`, `forge.boolean` (RustForge extension: active object `-` / `+` / `&` the other selected objects;
  param `operation`: `UNION`|`DIFFERENCE`|`INTERSECT`, `delete_operands`)
* edit: `mesh.extrude_region_move`, `mesh.extrude_faces_indiv`, `mesh.extrude_edges_move`, `mesh.extrude_vertices_move`,
  `mesh.inset`, `mesh.bevel`, `mesh.loopcut_slide` (params `edge` (edge index or -1), `number_cuts`, `factor`),
  `mesh.subdivide`, `mesh.delete`, `mesh.merge`, `mesh.remove_doubles`, `mesh.dissolve_verts`, `mesh.dissolve_edges`,
  `mesh.dissolve_faces`, `mesh.flip_normals`, `mesh.normals_make_consistent`, `mesh.faces_shade_smooth`,
  `mesh.faces_shade_flat`, `mesh.quads_convert_to_tris`, `mesh.tris_convert_to_quads`, `mesh.fill`,
  `mesh.bridge_edge_loops`, `mesh.duplicate_move`, `mesh.separate`, `mesh.vertices_smooth`, `mesh.symmetrize`,
  `mesh.spin`, `mesh.edge_face_add`, `mesh.select_all`
* transform: `transform.translate`, `transform.rotate`, `transform.resize` (object mode: selected objects; edit mode:
  selected vertices; `value`, `orient_axis`, `orient_type`, `constraint_axis`, `center_override`)

### 4.4 Direct property setters (undo step each, label given)
| method | args |
|---|---|
| `object.set` | `{"id":5,"name":"Tower","location":[..],"rotation":[..deg],"scale":[..],"visible":true,"locked":false,"collection":1,"parent":0}` any subset ("Edit Object") |
| `transform.numeric` | `{"mode":"move"\|"rotate"\|"scale","values":[x,y,z],"space":"global"\|"local","relative":true}` on the selection; in edit mode `relative:false` + `mode:"move"` sets the median position |
| `object.rename` | `{"id":5,"name":"Tower"}` (names are made unique like Blender: `Tower.001`) |
| `collection.create` | `{"name":"Walls","parent":0}` -> `{"id":..}` |
| `collection.set` | `{"id":..,"name":..,"visible":..,"locked":..,"parent":..}` any subset |
| `collection.delete` | `{"id":..,"delete_objects":false}` |
| `modifier.set` | `{"object":5,"index":0,"name":"Mirror","show_viewport":true,"show_render":true,"params":{"use_axis_x":true}}` any subset |
| `modifier.move` | `{"object":5,"index":0,"to":1}` |
| `material.create` | `{"name":"Stone","base_color":[..],"metallic":0,"roughness":0.8,"alpha":1}` -> `{"id":..}` |
| `material.set` | `{"id":3,"name":..,"base_color":[r,g,b,a],"metallic":..,"roughness":..,"alpha":..,"emission":[..],"emission_strength":..}` any subset |
| `material.assign` | `{"object":5,"material":3,"slot":0}`; in edit mode with `"selection":true` assigns the material to the selected faces (adds a slot when needed) |
| `material.slot_add` / `material.slot_remove` | `{"object":5}` / `{"object":5,"slot":1}` |
| `light.set` | `{"id":5,"type":..,"color":..,"energy":..,"spot_size_deg":..,"spot_blend":..}` |
| `camera.set` | `{"id":5,"lens_mm":..,"clip_start":..,"clip_end":..,"ortho":..,"ortho_scale":..}`; `camera.view_from_object` `{"id":5}` aligns the viewport |

## 5. Settings (`snapshot.settings`, `settings.set` paths use dots)

```
"touch":   {"sensitivity":1.0,"orbit_speed":1.0,"pan_speed":1.0,"zoom_speed":1.0,"invert_y":false,
            "hit_radius_dp":28,"drag_threshold_dp":8,"stylus":true},
"gestures":{"one_finger":"orbit"|"pan"|"none",        // one-finger drag on empty space / in navigate tool
            "select_drag":"orbit"|"box",               // one-finger drag on empty space in the select tool
            "two_finger":"pan"|"orbit","pinch":"zoom"|"none","double_tap":"focus"|"none","three_finger":"undo_redo"|"none",
            "lock_camera_in_tools":true},              // never move the camera from a drag that starts on a gizmo/tool
"gizmo":   {"size":1.0,"visible":true},
"snap":    {"grid":false,"grid_size":0.25,"angle":false,"angle_step_deg":15,"scale":false,"scale_step":0.1,"vertex":false},
"select":  {"additive":false,"xray_box":true,"through_hierarchy":false},
"viewport":{"quality":"auto"|"low"|"medium"|"high","msaa":4,"resolution_scale":1.0,"polygon_limit":3000000,
            "max_fps":60,"smooth_shading":true},
"script":  {"time_limit_s":30,"memory_limit_mb":256,"step_limit":200000000,"geometry_limit_verts":2000000}
```
`quality` presets set `msaa`/`resolution_scale`/`polygon_limit` (low: 1/0.7/300k, medium: 4/0.85/1M, high: 4/1.0/3M,
auto: adapts to measured frame time). Objects beyond `polygon_limit` are drawn as bounding boxes and a toast says so.

## 6. Tools

`tool.set` ids and the modes they exist in (the engine ignores a tool not valid for the mode and replies `ok:false`):
* all modes: `navigate` (one-finger drag navigates per `gestures.one_finger`), `select` (tap selects; drag per
  `gestures.select_drag`), `box_select` (drag draws a rubber band; additive/subtractive via `select.additive` or a second finger)
* object + edit: `move`, `rotate`, `scale` (transform gizmo at the selection pivot: axis handles, plane handles, free
  move / free rotate, uniform scale; snapping from `settings.snap`)
* edit only: `extrude`, `inset`, `bevel`, `loop_cut` (modal: drag to adjust, release commits one undo step, the
  result stays editable through `last_op`; `tool_state` carries the live value for the HUD)
* sculpt only: `sculpt_draw`, `sculpt_smooth`, `sculpt_grab`, `sculpt_inflate`, `sculpt_pinch`, `sculpt_flatten`,
  `sculpt_clay`, `sculpt_crease`
Two-finger drag (pan) and pinch (zoom) work in **every** tool except while a one-finger gizmo/modal drag is active.
Camera never moves because of a drag that started on a gizmo handle or on the mesh with a sculpt/edit tool.
Double tap focuses the selection; three-finger swipe left/right = undo/redo (when enabled).

## 7. Scripts (Python)

| method | args | result |
|---|---|---|
| `script.check` | `{"source":"..."}` | `{"diagnostics":[{"line":1,"col":5,"end_col":9,"message":"...","kind":"SyntaxError"\|"IndentationError"\|"Warning"}]}` (1-based; warnings come from the API linter, e.g. unknown `bpy.ops` names) |
| `script.run` | `{"source":"...","mode":"replace"\|"add","preview":false}` | returns immediately `{"started":true}`; error `{"ok":false,"error":"a script is already running"}` |
| `script.stop` | `{}` | cooperative cancel (guaranteed within ~100 ms inside the interpreter) |
| `script.commit` | `{}` | preview only: apply the previewed result as one undo step ("Run Script") |
| `script.discard` | `{}` | preview only: drop it |
| `script.console` | `{"since":0}` | `{"lines":[{"seq":1,"kind":"out"\|"err"\|"info"\|"warn","text":"..."}],"seq":42}` (ring buffer, last 2000 lines) |
| `script.clear_console` | `{}` | |
| `script.api_markdown` | `{}` | `{"markdown":"..."}` full API reference ("Copy API Reference") |
| `script.ai_prompt` | `{}` | `{"prompt":"..."}` ready-to-copy AI prompt incl. rules + complete example |
| `script.examples` | `{}` | `{"examples":[{"name":"Castle","source":"..."}]}` built-in sample scripts |

Semantics. `replace`: the script starts in an **empty** scene (Blender-style `bpy.ops.object.select_all/delete` at the
top still works); `add`: it starts from the current scene. The script runs on an engine-owned thread against a
**cloned** scene; nothing is visible until it finishes. On success: `preview:false` commits atomically (one undo step
"Run Script") and `status` becomes `done`; `preview:true` keeps the result as a pending preview that is *drawn instead of*
the real scene (`status:"preview"`) until `script.commit`/`script.discard` (starting another run or editing the scene
discards a pending preview). On error/cancel/limit the user's scene is untouched, `status` is `error`/`cancelled`, the
console shows a CPython-style traceback and `script.error` carries line/col for editor highlighting. The console also
receives `print` output while the script runs and a final line like `Finished in 0.31 s - 14 objects, 5 632 vertices`.
Limits come from `settings.script`. The UI stays responsive; geometry created is validated (non-finite coordinates,
degenerate faces, size limits) and reported as console warnings/errors.

## 8. Files

* `nativeImport` result: `{"ok":true,"objects":[ids],"warnings":["..."],"verts":N,"faces":N}`; imported meshes become new
  selected objects (undo step "Import <name>"); OBJ `usemtl` / glTF materials become materials. `.gltf` must embed its
  buffers (data URIs) — external `.bin` files are not reachable from Android's picker and give a clear error.
  `.rforge` replaces the whole project.
* `nativeExport` options (JSON): `{"selection_only":false,"apply_modifiers":true,"y_up":true,"binary":true}` (`binary`: STL
  only). OBJ/STL/glTF are exported Y-up by default (the engine converts from Z-up), materials as glTF PBR / OBJ `usemtl` names.
* `.rforge` project file: container defined by `forge-scene` (versioned, magic `RFORGE01`); it stores the whole scene,
  materials, modifiers and settings-independent data. Kotlin stores/loads bytes only (Storage Access Framework).

## 9. Render frame (engine -> renderer)

Not JSON: `forge_engine::RenderFrame` (see `rust/crates/forge-engine/src/render_types.rs`). The render thread locks the
engine only to call `build_frame()`, then draws without the lock.
