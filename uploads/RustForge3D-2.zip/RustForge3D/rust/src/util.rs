//! Small dependency-free helpers: a `block_on` for wgpu's setup futures and byte views of plain data.
use std::future::Future;
use std::pin::pin;
use std::sync::Arc;
use std::task::{Context, Poll, Wake, Waker};
use std::thread::{self, Thread};

struct ThreadWaker(Thread);

impl Wake for ThreadWaker {
    fn wake(self: Arc<Self>) {
        self.0.unpark();
    }
}

/// Runs a future to completion on the calling thread.
pub fn block_on<F: Future>(fut: F) -> F::Output {
    let mut fut = pin!(fut);
    let waker = Waker::from(Arc::new(ThreadWaker(thread::current())));
    let mut cx = Context::from_waker(&waker);
    loop {
        match fut.as_mut().poll(&mut cx) {
            Poll::Ready(v) => return v,
            Poll::Pending => thread::park(),
        }
    }
}

/// Marker for `#[repr(C)]` types that consist only of `f32` fields and have no padding bytes
/// (checked by the size assertions in the tests of the modules that implement it).
///
/// # Safety
/// Implementors must be `#[repr(C)]`, contain no padding and no pointers.
pub unsafe trait Plain: Copy {}

/// The bytes of one plain value.
pub fn bytes_of<T: Plain>(v: &T) -> &[u8] {
    // SAFETY: `T: Plain` guarantees every byte of the value is initialised (no padding).
    unsafe { std::slice::from_raw_parts((v as *const T).cast::<u8>(), std::mem::size_of::<T>()) }
}

/// The bytes of a slice of plain values.
pub fn slice_bytes<T: Plain>(v: &[T]) -> &[u8] {
    // SAFETY: as for `bytes_of`; the slice is contiguous.
    unsafe { std::slice::from_raw_parts(v.as_ptr().cast::<u8>(), std::mem::size_of_val(v)) }
}

pub fn align_up(v: u64, align: u64) -> u64 {
    if align <= 1 {
        v
    } else {
        v.div_ceil(align) * align
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn block_on_resolves_ready_and_pending_futures() {
        assert_eq!(block_on(async { 7 }), 7);
        struct YieldOnce(bool);
        impl Future for YieldOnce {
            type Output = u32;
            fn poll(mut self: std::pin::Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<u32> {
                if self.0 {
                    Poll::Ready(42)
                } else {
                    self.0 = true;
                    cx.waker().wake_by_ref();
                    Poll::Pending
                }
            }
        }
        assert_eq!(block_on(YieldOnce(false)), 42);
    }

    #[test]
    fn align_up_rounds_to_multiples() {
        assert_eq!(align_up(176, 256), 256);
        assert_eq!(align_up(256, 256), 256);
        assert_eq!(align_up(257, 256), 512);
        assert_eq!(align_up(5, 1), 5);
    }
}
