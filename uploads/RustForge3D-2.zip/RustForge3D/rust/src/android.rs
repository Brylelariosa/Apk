//! Platform glue: the Android window handle and logcat logging. Everything that needs Android system
//! libraries sits behind `cfg(target_os = "android")`; on the host these are inert so unit tests link.
use std::ffi::c_void;
use std::sync::Once;

/// A raw `ANativeWindow*`; it is handed to the render thread, which owns it until it releases it.
#[derive(Clone, Copy)]
pub struct WindowPtr(pub *mut c_void);

// SAFETY: an ANativeWindow may be used from any thread; only one thread (the render thread) touches it.
unsafe impl Send for WindowPtr {}

#[cfg(target_os = "android")]
mod ffi {
    use std::ffi::{c_char, c_int, c_void};

    #[link(name = "android")]
    extern "C" {
        pub fn ANativeWindow_fromSurface(env: *mut c_void, surface: *mut c_void) -> *mut c_void;
        pub fn ANativeWindow_release(window: *mut c_void);
    }

    #[link(name = "log")]
    extern "C" {
        pub fn __android_log_write(prio: c_int, tag: *const c_char, text: *const c_char) -> c_int;
    }
}

/// Acquires the native window behind a `android.view.Surface` (null if unavailable).
#[cfg(target_os = "android")]
pub fn window_from_surface(env: *mut c_void, surface: *mut c_void) -> WindowPtr {
    // SAFETY: `env` and `surface` come straight from the JNI call that is currently executing.
    WindowPtr(unsafe { ffi::ANativeWindow_fromSurface(env, surface) })
}

#[cfg(not(target_os = "android"))]
pub fn window_from_surface(_env: *mut c_void, _surface: *mut c_void) -> WindowPtr {
    WindowPtr(std::ptr::null_mut())
}

/// Releases a window obtained from [`window_from_surface`]; only call after the GPU surface is gone.
#[cfg(target_os = "android")]
pub fn release_window(w: WindowPtr) {
    if !w.0.is_null() {
        // SAFETY: the pointer came from ANativeWindow_fromSurface and is released exactly once.
        unsafe { ffi::ANativeWindow_release(w.0) }
    }
}

#[cfg(not(target_os = "android"))]
pub fn release_window(_w: WindowPtr) {}

#[cfg(target_os = "android")]
fn write_line(level: log::Level, text: &str) {
    use std::ffi::CString;
    let prio = match level {
        log::Level::Error => 6,
        log::Level::Warn => 5,
        log::Level::Info => 4,
        log::Level::Debug => 3,
        log::Level::Trace => 2,
    };
    let tag = CString::new("RustForge").unwrap_or_default();
    // logcat truncates long lines; split so panic messages and wgpu errors stay readable
    for chunk in text.as_bytes().chunks(3500) {
        let s = String::from_utf8_lossy(chunk).replace('\0', " ");
        if let Ok(c) = CString::new(s) {
            // SAFETY: both strings are valid NUL-terminated C strings for the duration of the call.
            unsafe {
                ffi::__android_log_write(prio, tag.as_ptr(), c.as_ptr());
            }
        }
    }
}

#[cfg(not(target_os = "android"))]
fn write_line(level: log::Level, text: &str) {
    eprintln!("[{level}] {text}");
}

struct Logger;

impl log::Log for Logger {
    fn enabled(&self, metadata: &log::Metadata) -> bool {
        metadata.level() <= log::Level::Info
    }
    fn log(&self, record: &log::Record) {
        if self.enabled(record.metadata()) {
            write_line(record.level(), &format!("{}: {}", record.target(), record.args()));
        }
    }
    fn flush(&self) {}
}

static LOGGER: Logger = Logger;
static INIT: Once = Once::new();

/// Installs the logcat logger and a panic hook (idempotent).
pub fn init_logging() {
    INIT.call_once(|| {
        let _ = log::set_logger(&LOGGER);
        log::set_max_level(log::LevelFilter::Info);
        std::panic::set_hook(Box::new(|info| {
            let loc = info.location().map(|l| format!("{}:{}", l.file(), l.line())).unwrap_or_default();
            let msg = if let Some(s) = info.payload().downcast_ref::<&str>() {
                (*s).to_string()
            } else if let Some(s) = info.payload().downcast_ref::<String>() {
                s.clone()
            } else {
                "panic".to_string()
            };
            write_line(log::Level::Error, &format!("panic at {loc}: {msg}"));
        }));
    });
}
