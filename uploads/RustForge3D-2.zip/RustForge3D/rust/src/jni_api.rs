//! Exported JNI entry points of `com.rustforge.studio.bridge.NativeBridge` (docs/PROTOCOL.md section 1).
//! Thin on purpose: arguments are converted and forwarded to the engine or the render thread; the JSON is never
//! interpreted here. Every entry point catches panics, so nothing unwinds into the JVM.
#![allow(non_snake_case)]

use crate::android;
use crate::handle::{self, Native};
use crate::render::panic_message;
use forge_engine::{TouchBatch, TouchPointer};
use jni::objects::{JByteArray, JClass, JFloatArray, JIntArray, JObject, JString};
use jni::sys::{jboolean, jbyteArray, jfloat, jint, jlong, jstring, JNI_FALSE, JNI_TRUE};
use jni::JNIEnv;
use std::ffi::c_void;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::ptr::null_mut;

/// Most simultaneous pointers forwarded to the gesture recogniser.
const MAX_POINTERS: usize = 16;

fn guarded<T>(fallback: T, f: impl FnOnce() -> T) -> T {
    match catch_unwind(AssertUnwindSafe(f)) {
        Ok(v) => v,
        Err(p) => {
            log::error!("panic in a JNI call: {}", panic_message(&*p));
            fallback
        }
    }
}

fn error_json(msg: &str) -> String {
    forge_json::Json::obj().set("ok", false).set("error", msg).to_string()
}

fn read_string(env: &mut JNIEnv, s: &JString) -> Option<String> {
    env.get_string(s).ok().map(String::from)
}

fn make_string(env: &mut JNIEnv, s: &str) -> jstring {
    env.new_string(s).map(|j| j.into_raw()).unwrap_or(null_mut())
}

fn make_bytes(env: &mut JNIEnv, b: &[u8]) -> jbyteArray {
    env.byte_array_from_slice(b).map(|a| a.into_raw()).unwrap_or(null_mut())
}

fn array_len(env: &mut JNIEnv, a: &JIntArray) -> usize {
    env.get_array_length(a).unwrap_or(0).max(0) as usize
}

fn float_array_len(env: &mut JNIEnv, a: &JFloatArray) -> usize {
    env.get_array_length(a).unwrap_or(0).max(0) as usize
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeCreate<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, files_dir: JString<'l>, density: jfloat) -> jlong {
    guarded(0, || {
        android::init_logging();
        match read_string(&mut env, &files_dir) {
            Some(dir) => handle::register(Native::new(&dir, density)),
            None => 0,
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeDestroy<'l>(_env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) {
    guarded((), || {
        if let Some(n) = handle::remove(handle) {
            n.render.detach();
            drop(n);
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeSurfaceCreated<'l>(env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong, surface: JObject<'l>, width: jint, height: jint) -> jboolean {
    guarded(JNI_FALSE, || {
        let Some(n) = handle::get(handle) else { return JNI_FALSE };
        let window = android::window_from_surface(env.get_raw() as *mut c_void, surface.as_raw() as *mut c_void);
        if window.0.is_null() {
            n.set_error("The surface has no native window");
            return JNI_FALSE;
        }
        match n.attach(window, width.max(1) as u32, height.max(1) as u32) {
            Ok(()) => JNI_TRUE,
            Err(e) => {
                n.set_error(e);
                JNI_FALSE
            }
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeSurfaceChanged<'l>(_env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong, width: jint, height: jint) {
    guarded((), || {
        if let Some(n) = handle::get(handle) {
            n.engine().set_viewport(width.max(1) as u32, height.max(1) as u32);
            n.render.resize(width.max(0) as u32, height.max(0) as u32);
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeSurfaceDestroyed<'l>(_env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) {
    guarded((), || {
        if let Some(n) = handle::get(handle) {
            n.render.detach();
        }
    })
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeSetPaused<'l>(_env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong, paused: jboolean) {
    guarded((), || {
        if let Some(n) = handle::get(handle) {
            let paused = paused != JNI_FALSE;
            n.render.set_paused(paused);
            let mut e = n.engine();
            if paused {
                e.on_pause();
            } else {
                e.on_resume();
            }
        }
    })
}

#[no_mangle]
#[allow(clippy::too_many_arguments)]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeTouch<'l>(
    mut env: JNIEnv<'l>,
    _class: JClass<'l>,
    handle: jlong,
    action: jint,
    action_index: jint,
    time_ms: jlong,
    count: jint,
    ids: JIntArray<'l>,
    xs: JFloatArray<'l>,
    ys: JFloatArray<'l>,
    pressures: JFloatArray<'l>,
    tool_types: JIntArray<'l>,
) {
    guarded((), || {
        let Some(n) = handle::get(handle) else { return };
        let count = (count.max(0) as usize)
            .min(MAX_POINTERS)
            .min(array_len(&mut env, &ids))
            .min(float_array_len(&mut env, &xs))
            .min(float_array_len(&mut env, &ys))
            .min(float_array_len(&mut env, &pressures))
            .min(array_len(&mut env, &tool_types));
        let (mut id, mut tool) = ([0i32; MAX_POINTERS], [0i32; MAX_POINTERS]);
        let (mut x, mut y, mut p) = ([0f32; MAX_POINTERS], [0f32; MAX_POINTERS], [0f32; MAX_POINTERS]);
        let read_ok = env.get_int_array_region(&ids, 0, &mut id[..count]).is_ok()
            && env.get_float_array_region(&xs, 0, &mut x[..count]).is_ok()
            && env.get_float_array_region(&ys, 0, &mut y[..count]).is_ok()
            && env.get_float_array_region(&pressures, 0, &mut p[..count]).is_ok()
            && env.get_int_array_region(&tool_types, 0, &mut tool[..count]).is_ok();
        if !read_ok {
            return;
        }
        let pointers = (0..count).map(|i| TouchPointer { id: id[i], x: x[i], y: y[i], pressure: p[i], tool_type: tool[i] }).collect();
        n.engine().touch(&TouchBatch { action, action_index, time_ms: time_ms.max(0) as u64, pointers });
    })
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeCall<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong, method: JString<'l>, args_json: JString<'l>) -> jstring {
    let out = guarded(error_json("internal error"), || {
        let Some(n) = handle::get(handle) else { return error_json("invalid handle") };
        let (Some(m), Some(a)) = (read_string(&mut env, &method), read_string(&mut env, &args_json)) else { return error_json("invalid arguments") };
        let result = n.engine().call(&m, &a);
        result
    });
    make_string(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativePoll<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) -> jstring {
    let out = guarded(None, || {
        let n = handle::get(handle)?;
        let polled = n.engine().poll();
        polled
    });
    match out {
        Some(s) => make_string(&mut env, &s),
        None => null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeImport<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong, file_name: JString<'l>, data: JByteArray<'l>) -> jstring {
    let out = guarded(error_json("internal error"), || {
        let Some(n) = handle::get(handle) else { return error_json("invalid handle") };
        let Some(name) = read_string(&mut env, &file_name) else { return error_json("invalid file name") };
        let Ok(bytes) = env.convert_byte_array(&data) else { return error_json("could not read the file data") };
        let result = n.engine().import_bytes(&name, &bytes);
        result
    });
    make_string(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeExport<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong, format: JString<'l>, opts_json: JString<'l>) -> jbyteArray {
    let out: Option<Vec<u8>> = guarded(None, || {
        let n = handle::get(handle)?;
        let (fmt, opts) = (read_string(&mut env, &format)?, read_string(&mut env, &opts_json)?);
        let result = n.engine().export_bytes(&fmt, &opts);
        match result {
            Ok(b) => Some(b),
            Err(e) => {
                n.set_error(e);
                None
            }
        }
    });
    match out {
        Some(b) => make_bytes(&mut env, &b),
        None => null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeSaveProject<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) -> jbyteArray {
    let out: Option<Vec<u8>> = guarded(None, || {
        let n = handle::get(handle)?;
        let result = n.engine().save_project();
        match result {
            Ok(b) => Some(b),
            Err(e) => {
                n.set_error(e);
                None
            }
        }
    });
    match out {
        Some(b) => make_bytes(&mut env, &b),
        None => null_mut(),
    }
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeLoadProject<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong, data: JByteArray<'l>) -> jstring {
    let out = guarded(error_json("internal error"), || {
        let Some(n) = handle::get(handle) else { return error_json("invalid handle") };
        let Ok(bytes) = env.convert_byte_array(&data) else { return error_json("could not read the project data") };
        let result = n.engine().load_project(&bytes);
        result
    });
    make_string(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeLastError<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) -> jstring {
    let out = guarded(String::new(), || handle::get(handle).map(|n| n.last_error()).unwrap_or_default());
    make_string(&mut env, &out)
}

#[no_mangle]
pub extern "system" fn Java_com_rustforge_studio_bridge_NativeBridge_nativeBackendName<'l>(mut env: JNIEnv<'l>, _class: JClass<'l>, handle: jlong) -> jstring {
    let out = guarded(String::new(), || handle::get(handle).map(|n| n.render.backend()).unwrap_or_default());
    make_string(&mut env, &out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn guarded_turns_panics_into_the_fallback() {
        assert_eq!(guarded(7, || panic!("boom")), 7);
        assert_eq!(guarded(7, || 9), 9);
    }

    #[test]
    fn error_json_is_valid_json() {
        let j = forge_json::Json::parse(&error_json("bad \"quote\"\n")).unwrap();
        assert_eq!(j.get_bool("ok"), Some(false));
        assert_eq!(j.get_str("error"), Some("bad \"quote\"\n"));
    }
}
