//! RustForge 3D native library: the JNI front-end (`jni_api`) and the wgpu renderer (`render`) around the
//! platform-independent `forge-engine`. The Android specific parts are isolated in `android`.
mod android;
mod handle;
pub mod jni_api;
mod render;
mod util;
