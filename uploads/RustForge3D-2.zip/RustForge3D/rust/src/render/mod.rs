//! The render thread: owns the GPU context, waits for redraw requests and locks the engine only to build a frame.
mod buffers;
mod gpu;
mod pipelines;
pub mod plan;
mod targets;

use crate::android::{self, WindowPtr};
use forge_engine::{Engine, RedrawSignal, RenderStats};
use gpu::{Gpu, Outcome};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::sync::{Arc, Mutex};
use std::thread::JoinHandle;
use std::time::{Duration, Instant};

/// Panic payload as text (for logging and error replies).
pub fn panic_message(p: &(dyn std::any::Any + Send)) -> String {
    if let Some(s) = p.downcast_ref::<&str>() {
        (*s).to_string()
    } else if let Some(s) = p.downcast_ref::<String>() {
        s.clone()
    } else {
        "unknown panic".to_string()
    }
}

enum Cmd {
    Attach { window: WindowPtr, width: u32, height: u32, reply: Sender<Result<String, String>> },
    Resize(u32, u32),
    Detach(Sender<()>),
    Pause(bool),
    Shutdown,
}

pub struct RenderThread {
    tx: Sender<Cmd>,
    redraw: Arc<RedrawSignal>,
    join: Option<JoinHandle<()>>,
    backend: Arc<Mutex<String>>,
}

impl RenderThread {
    pub fn spawn(engine: Arc<Mutex<Engine>>, redraw: Arc<RedrawSignal>) -> RenderThread {
        let (tx, rx) = channel();
        let backend = Arc::new(Mutex::new(String::new()));
        let thread_backend = backend.clone();
        let thread_redraw = redraw.clone();
        let join = std::thread::Builder::new().name("rf-render".to_string()).spawn(move || thread_main(rx, engine, thread_redraw, thread_backend)).ok();
        RenderThread { tx, redraw, join, backend }
    }

    fn send(&self, cmd: Cmd) -> bool {
        let ok = self.tx.send(cmd).is_ok();
        self.redraw.request();
        ok
    }

    /// Starts rendering into `window`; waits until the GPU is ready. Returns the backend name.
    pub fn attach(&self, window: WindowPtr, width: u32, height: u32) -> Result<String, String> {
        let (reply, answer) = channel();
        if !self.send(Cmd::Attach { window, width, height, reply }) {
            android::release_window(window);
            return Err("the render thread is not running".to_string());
        }
        answer.recv_timeout(Duration::from_secs(20)).unwrap_or_else(|_| Err("timed out while starting the renderer".to_string()))
    }

    pub fn resize(&self, width: u32, height: u32) {
        self.send(Cmd::Resize(width, height));
    }

    /// Drops the GPU surface and returns once the render thread no longer touches the window.
    pub fn detach(&self) {
        let (reply, answer) = channel();
        if self.send(Cmd::Detach(reply)) {
            let _ = answer.recv_timeout(Duration::from_secs(5));
        }
    }

    pub fn set_paused(&self, paused: bool) {
        self.send(Cmd::Pause(paused));
    }

    pub fn backend(&self) -> String {
        self.backend.lock().unwrap_or_else(|e| e.into_inner()).clone()
    }
}

impl Drop for RenderThread {
    fn drop(&mut self) {
        let _ = self.tx.send(Cmd::Shutdown);
        self.redraw.request();
        if let Some(j) = self.join.take() {
            let _ = j.join();
        }
    }
}

/// Frame rate measured only while drawing continuously (an idle app must not look slow).
#[derive(Default)]
struct Meter {
    last: Option<Instant>,
    sum: Duration,
    frames: u32,
}

impl Meter {
    /// Records a presented frame; returns (fps, frame_ms) once enough continuous frames were seen.
    fn frame(&mut self) -> Option<(f32, f32)> {
        let now = Instant::now();
        let dt = self.last.map(|l| now - l);
        self.last = Some(now);
        match dt {
            Some(d) if d < Duration::from_millis(100) => {
                self.sum += d;
                self.frames += 1;
            }
            _ => {
                self.sum = Duration::ZERO;
                self.frames = 0;
            }
        }
        if self.frames >= 30 {
            let secs = self.sum.as_secs_f32().max(1e-4);
            let out = (self.frames as f32 / secs, secs * 1000.0 / self.frames as f32);
            self.sum = Duration::ZERO;
            self.frames = 0;
            Some(out)
        } else {
            None
        }
    }
}

struct State {
    gpu: Option<Gpu>,
    window: Option<WindowPtr>,
    paused: bool,
    need_draw: bool,
    panics: u32,
    meter: Meter,
}

impl State {
    fn drop_gpu(&mut self) {
        self.gpu = None;
        if let Some(w) = self.window.take() {
            android::release_window(w);
        }
    }

    fn report(&self, engine: &Mutex<Engine>, fps: f32, frame_ms: f32) {
        if let Some(g) = &self.gpu {
            let stats = RenderStats { backend: g.backend().to_string(), fps, frame_ms, gpu_mb: g.gpu_mb(), msaa: g.msaa() };
            engine.lock().unwrap_or_else(|e| e.into_inner()).report_render_stats(stats);
        }
    }

    /// Returns false when the thread must exit.
    fn handle(&mut self, cmd: Cmd, engine: &Mutex<Engine>, backend: &Mutex<String>) -> bool {
        match cmd {
            Cmd::Attach { window, width, height, reply } => {
                self.drop_gpu();
                match catch_unwind(AssertUnwindSafe(|| Gpu::new(window, width, height))) {
                    Ok(Ok(gpu)) => {
                        let name = gpu.backend().to_string();
                        *backend.lock().unwrap_or_else(|e| e.into_inner()) = name.clone();
                        self.gpu = Some(gpu);
                        self.window = Some(window);
                        self.need_draw = true;
                        self.panics = 0;
                        // every mesh has to be uploaded to the new context
                        engine.lock().unwrap_or_else(|e| e.into_inner()).gpu_lost();
                        self.report(engine, 0.0, 0.0);
                        let _ = reply.send(Ok(name));
                    }
                    Ok(Err(e)) => {
                        android::release_window(window);
                        let _ = reply.send(Err(e));
                    }
                    Err(p) => {
                        android::release_window(window);
                        let _ = reply.send(Err(format!("internal error: {}", panic_message(&*p))));
                    }
                }
            }
            Cmd::Resize(w, h) => {
                if let Some(g) = self.gpu.as_mut() {
                    g.resize(w, h);
                    self.need_draw = true;
                }
            }
            Cmd::Detach(reply) => {
                self.drop_gpu();
                let _ = reply.send(());
            }
            Cmd::Pause(p) => {
                self.paused = p;
                self.need_draw |= !p;
            }
            Cmd::Shutdown => {
                self.drop_gpu();
                return false;
            }
        }
        true
    }

    fn draw_frame(&mut self, engine: &Mutex<Engine>, redraw: &RedrawSignal) {
        let built = catch_unwind(AssertUnwindSafe(|| engine.lock().unwrap_or_else(|e| e.into_inner()).build_frame()));
        let frame = match built {
            Ok(f) => f,
            Err(p) => {
                log::error!("building a frame panicked: {}", panic_message(&*p));
                return;
            }
        };
        let Some(gpu) = self.gpu.as_mut() else { return };
        match catch_unwind(AssertUnwindSafe(|| gpu.render(&frame))) {
            Ok(Outcome::Drawn) => {
                self.panics = 0;
                if let Some((fps, ms)) = self.meter.frame() {
                    self.report(engine, fps, ms);
                }
            }
            Ok(Outcome::Retry) => {
                std::thread::sleep(Duration::from_millis(8));
                redraw.request();
            }
            Ok(Outcome::Fatal(msg)) => {
                log::error!("renderer stopped: {msg}");
                self.drop_gpu();
            }
            Err(p) => {
                log::error!("rendering panicked: {}", panic_message(&*p));
                self.panics += 1;
                if self.panics >= 3 {
                    self.drop_gpu();
                } else {
                    redraw.request();
                }
            }
        }
    }
}

fn thread_main(rx: Receiver<Cmd>, engine: Arc<Mutex<Engine>>, redraw: Arc<RedrawSignal>, backend: Arc<Mutex<String>>) {
    let mut state = State { gpu: None, window: None, paused: false, need_draw: false, panics: 0, meter: Meter::default() };
    loop {
        let requested = redraw.wait(Duration::from_millis(250));
        while let Ok(cmd) = rx.try_recv() {
            if !state.handle(cmd, &engine, &backend) {
                return;
            }
        }
        if (requested || state.need_draw) && !state.paused && state.gpu.is_some() {
            state.need_draw = false;
            state.draw_frame(&engine, &redraw);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn meter_reports_only_continuous_frames() {
        let mut m = Meter::default();
        let mut got = None;
        for _ in 0..40 {
            std::thread::sleep(Duration::from_millis(2));
            if let Some(r) = m.frame() {
                got = Some(r);
            }
        }
        let (fps, ms) = got.expect("a report after 30 continuous frames");
        assert!(fps > 20.0 && ms > 0.5, "fps {fps} ms {ms}");
        let mut idle = Meter::default();
        for _ in 0..5 {
            assert!(idle.frame().is_none());
            std::thread::sleep(Duration::from_millis(120));
        }
        assert_eq!(idle.frames, 0, "gaps reset the window");
    }

    #[test]
    fn panic_messages_are_extracted() {
        let p = catch_unwind(|| panic!("boom {}", 1)).unwrap_err();
        assert_eq!(panic_message(&*p), "boom 1");
        let p = catch_unwind(|| panic!("plain")).unwrap_err();
        assert_eq!(panic_message(&*p), "plain");
    }
}
