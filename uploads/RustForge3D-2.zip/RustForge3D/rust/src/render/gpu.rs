//! wgpu device and surface lifecycle plus the per-frame draw.
use super::buffers::{DynBuf, GpuMesh, ObjectStore};
use super::pipelines::{Layouts, Pipelines, Shaders, DEPTH_FORMAT};
use super::plan::{self, FramePlan, MeshInfo, MeshTable, PlanParams, FRAME_UNIFORM_SIZE};
use super::targets::Targets;
use crate::android::WindowPtr;
use crate::util::{block_on, bytes_of, slice_bytes};
use forge_engine::{LineVertex, MeshUpdate, PointInstance, RenderBuffers, RenderFrame, RenderVertex, ScreenVertex};
use raw_window_handle::{AndroidDisplayHandle, AndroidNdkWindowHandle, RawDisplayHandle, RawWindowHandle};
use std::collections::HashMap;
use std::ffi::c_void;
use std::mem::size_of;
use std::ptr::NonNull;

/// Upper bound for per-frame draw calls (object uniform slots).
const MAX_SLOTS: usize = 16_384;

pub enum Outcome {
    Drawn,
    /// Nothing was drawn (surface timeout / reconfigured); ask for another frame.
    Retry,
    /// The GPU context is unusable; the render thread drops it.
    Fatal(String),
}

#[derive(Default)]
struct Counts {
    lines: u32,
    tris: u32,
    points: u32,
    overlay_lines: u32,
    overlay_tris: u32,
    screen: u32,
}

pub struct Gpu {
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    format: wgpu::TextureFormat,
    srgb_encode: bool,
    supports_msaa4: bool,
    visible: bool,
    backend: &'static str,
    max_buffer: u64,
    shaders: Shaders,
    layouts: Layouts,
    sampler: wgpu::Sampler,
    /// Pipelines with the MSAA sample count they were built for.
    pipelines: Option<(Pipelines, u32)>,
    targets: Option<Targets>,
    frame_buffer: wgpu::Buffer,
    frame_bind_group: wgpu::BindGroup,
    objects: ObjectStore,
    lines: DynBuf,
    tris: DynBuf,
    points: DynBuf,
    overlay_lines: DynBuf,
    overlay_tris: DynBuf,
    screen: DynBuf,
    meshes: HashMap<u64, GpuMesh>,
    table: MeshTable,
    // Kept last so it is dropped after everything created from it.
    _instance: wgpu::Instance,
}

fn dyn_count(buf: &mut DynBuf, device: &wgpu::Device, queue: &wgpu::Queue, data: &[u8], stride: usize, max: u64) -> u32 {
    if buf.write(device, queue, data, max) {
        (data.len() / stride) as u32
    } else {
        0
    }
}

impl Gpu {
    /// Vulkan first, OpenGL ES as fallback.
    pub fn new(window: WindowPtr, width: u32, height: u32) -> Result<Gpu, String> {
        let window = NonNull::new(window.0).ok_or_else(|| "no native window".to_string())?;
        let mut errors = Vec::new();
        for (backends, name) in [(wgpu::Backends::VULKAN, "Vulkan"), (wgpu::Backends::GL, "OpenGL ES")] {
            match Gpu::init(window, width, height, backends, name) {
                Ok(g) => return Ok(g),
                Err(e) => {
                    log::warn!("{name} is not usable: {e}");
                    errors.push(format!("{name}: {e}"));
                }
            }
        }
        Err(format!("No usable graphics backend ({})", errors.join("; ")))
    }

    fn init(window: NonNull<c_void>, width: u32, height: u32, backends: wgpu::Backends, backend: &'static str) -> Result<Gpu, String> {
        let instance = wgpu::Instance::new(wgpu::InstanceDescriptor { backends, ..Default::default() });
        let target = wgpu::SurfaceTargetUnsafe::RawHandle {
            raw_display_handle: RawDisplayHandle::Android(AndroidDisplayHandle::new()),
            raw_window_handle: RawWindowHandle::AndroidNdk(AndroidNdkWindowHandle::new(window)),
        };
        // SAFETY: the window outlives the surface because the render thread drops the `Gpu` before it releases the window.
        let surface = unsafe { instance.create_surface_unsafe(target) }.map_err(|e| e.to_string())?;
        let adapter = block_on(instance.request_adapter(&wgpu::RequestAdapterOptions {
            power_preference: wgpu::PowerPreference::default(),
            force_fallback_adapter: false,
            compatible_surface: Some(&surface),
        }))
        .ok_or_else(|| "no compatible adapter".to_string())?;
        let info = adapter.get_info();
        log::info!("{backend}: adapter {} ({:?})", info.name, info.backend);

        let adapter_limits = adapter.limits();
        let mut limits = wgpu::Limits::downlevel_defaults().using_resolution(adapter_limits.clone());
        limits.max_buffer_size = adapter_limits.max_buffer_size.min(1 << 30);
        let descriptor = |required_limits: wgpu::Limits| wgpu::DeviceDescriptor { label: Some("rustforge"), required_features: wgpu::Features::empty(), required_limits, memory_hints: wgpu::MemoryHints::default() };
        let (device, queue) = match block_on(adapter.request_device(&descriptor(limits), None)) {
            Ok(dq) => dq,
            Err(e) => {
                log::warn!("device with reduced limits failed ({e}); retrying with the adapter limits");
                block_on(adapter.request_device(&descriptor(adapter_limits.clone()), None)).map_err(|e| e.to_string())?
            }
        };
        device.on_uncaptured_error(Box::new(|e: wgpu::Error| log::error!("wgpu error: {e}")));

        let caps = surface.get_capabilities(&adapter);
        let format = caps.formats.iter().copied().find(|f| f.is_srgb()).or_else(|| caps.formats.first().copied()).ok_or_else(|| "the surface reports no formats".to_string())?;
        let alpha_mode = caps.alpha_modes.first().copied().unwrap_or(wgpu::CompositeAlphaMode::Auto);
        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format,
            width: width.max(1),
            height: height.max(1),
            present_mode: wgpu::PresentMode::Fifo,
            desired_maximum_frame_latency: 2,
            alpha_mode,
            view_formats: Vec::new(),
        };
        surface.configure(&device, &config);
        let supports_msaa4 = adapter.get_texture_format_features(format).flags.sample_count_supported(4) && adapter.get_texture_format_features(DEPTH_FORMAT).flags.sample_count_supported(4);

        let layouts = Layouts::new(&device);
        let shaders = Shaders::new(&device);
        let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("blit"),
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            ..Default::default()
        });
        let frame_buffer = device.create_buffer(&wgpu::BufferDescriptor { label: Some("frame uniforms"), size: FRAME_UNIFORM_SIZE, usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST, mapped_at_creation: false });
        let frame_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("frame uniforms"),
            layout: &layouts.frame,
            entries: &[wgpu::BindGroupEntry { binding: 0, resource: frame_buffer.as_entire_binding() }],
        });
        let objects = ObjectStore::new(&device, &layouts.object, device.limits().min_uniform_buffer_offset_alignment);
        let max_buffer = device.limits().max_buffer_size;

        Ok(Gpu {
            surface,
            device,
            queue,
            config,
            format,
            srgb_encode: !format.is_srgb(),
            supports_msaa4,
            visible: true,
            backend,
            max_buffer,
            shaders,
            layouts,
            sampler,
            pipelines: None,
            targets: None,
            frame_buffer,
            frame_bind_group,
            objects,
            lines: DynBuf::default(),
            tris: DynBuf::default(),
            points: DynBuf::default(),
            overlay_lines: DynBuf::default(),
            overlay_tris: DynBuf::default(),
            screen: DynBuf::default(),
            meshes: HashMap::new(),
            table: MeshTable::default(),
            _instance: instance,
        })
    }

    pub fn backend(&self) -> &'static str {
        self.backend
    }

    pub fn msaa(&self) -> u32 {
        self.targets.as_ref().map_or(1, |t| t.samples)
    }

    pub fn gpu_mb(&self) -> f32 {
        let meshes: u64 = self.meshes.values().map(|m| m.bytes).sum();
        let dynamic = self.lines.bytes() + self.tris.bytes() + self.points.bytes() + self.overlay_lines.bytes() + self.overlay_tris.bytes() + self.screen.bytes();
        let targets = self.targets.as_ref().map_or(0, |t| t.bytes);
        (meshes + dynamic + targets + self.objects.bytes() + FRAME_UNIFORM_SIZE) as f32 / (1024.0 * 1024.0)
    }

    pub fn resize(&mut self, width: u32, height: u32) {
        if width == 0 || height == 0 {
            self.visible = false;
            return;
        }
        self.visible = true;
        if (width, height) != (self.config.width, self.config.height) {
            self.config.width = width;
            self.config.height = height;
            self.surface.configure(&self.device, &self.config);
        }
    }

    fn upload_mesh(&mut self, key: u64, b: &RenderBuffers) {
        self.meshes.remove(&key);
        self.table.remove(key);
        let vertex_bytes = (b.vertices.len() * size_of::<RenderVertex>()) as u64;
        if b.vertices.is_empty() || vertex_bytes > self.max_buffer || (b.indices.len() * 4) as u64 > self.max_buffer {
            if vertex_bytes > self.max_buffer {
                log::error!("mesh {key} ({} MB) exceeds the GPU buffer limit and is not drawn", vertex_bytes >> 20);
            }
            return;
        }
        self.meshes.insert(key, GpuMesh::upload(&self.device, b));
        self.table.insert(key, MeshInfo::from_buffers(b));
    }

    fn apply_updates(&mut self, updates: &[MeshUpdate]) {
        for u in updates {
            match u {
                MeshUpdate::Upload { key, buffers } => self.upload_mesh(*key, buffers),
                MeshUpdate::Patch { key, first, vertices } => {
                    if let Some(m) = self.meshes.get(key) {
                        self.queue.write_buffer(&m.vertex, *first as u64 * size_of::<RenderVertex>() as u64, slice_bytes(vertices));
                    }
                }
                MeshUpdate::Remove { key } => {
                    self.meshes.remove(key);
                    self.table.remove(*key);
                }
            }
        }
    }

    fn ensure_pipelines(&mut self, samples: u32) {
        if self.pipelines.as_ref().map(|p| p.1) != Some(samples) {
            self.pipelines = None;
            let p = Pipelines::new(&self.device, &self.shaders, &self.layouts, self.format, samples);
            self.pipelines = Some((p, samples));
        }
    }

    fn ensure_targets(&mut self, size: (u32, u32), samples: u32, scaled: bool) {
        if self.targets.as_ref().map_or(true, |t| !t.matches(size, samples, scaled)) {
            // free the old targets first: peak memory matters on low-RAM devices
            self.targets = None;
            self.targets = Some(Targets::new(&self.device, self.format, size, samples, scaled, &self.layouts.blit, &self.sampler));
        }
    }

    pub fn render(&mut self, frame: &RenderFrame) -> Outcome {
        self.apply_updates(&frame.mesh_updates);
        if !self.visible {
            return Outcome::Drawn;
        }
        let size = plan::target_size(self.config.width, self.config.height, frame.resolution_scale);
        let scaled = size != (self.config.width, self.config.height);
        let samples = plan::choose_msaa(frame.msaa_samples, self.supports_msaa4);
        self.ensure_pipelines(samples);
        self.ensure_targets(size, samples, scaled);

        let plan = plan::build_plan(frame, &self.table, &PlanParams { srgb_encode: self.srgb_encode, max_slots: MAX_SLOTS });
        self.queue.write_buffer(&self.frame_buffer, 0, bytes_of(&plan.frame));
        self.objects.upload(&self.device, &self.layouts.object, &self.queue, &plan.objects);
        let max = self.max_buffer;
        let (device, queue) = (&self.device, &self.queue);
        let counts = Counts {
            lines: dyn_count(&mut self.lines, device, queue, slice_bytes(&frame.lines), size_of::<LineVertex>(), max),
            tris: dyn_count(&mut self.tris, device, queue, slice_bytes(&frame.tris), size_of::<LineVertex>(), max),
            points: dyn_count(&mut self.points, device, queue, slice_bytes(&frame.points), size_of::<PointInstance>(), max),
            overlay_lines: dyn_count(&mut self.overlay_lines, device, queue, slice_bytes(&frame.overlay_lines), size_of::<LineVertex>(), max),
            overlay_tris: dyn_count(&mut self.overlay_tris, device, queue, slice_bytes(&frame.overlay_triangles), size_of::<LineVertex>(), max),
            screen: dyn_count(&mut self.screen, device, queue, slice_bytes(&frame.screen_lines), size_of::<ScreenVertex>(), max),
        };
        self.draw(frame, &plan, &counts, scaled)
    }

    fn draw(&self, frame: &RenderFrame, plan: &FramePlan, counts: &Counts, scaled: bool) -> Outcome {
        let (Some(targets), Some((pipes, _))) = (self.targets.as_ref(), self.pipelines.as_ref()) else { return Outcome::Retry };
        let st = match self.surface.get_current_texture() {
            Ok(t) => t,
            Err(wgpu::SurfaceError::OutOfMemory) => return Outcome::Fatal("the GPU ran out of memory".to_string()),
            Err(wgpu::SurfaceError::Timeout) => return Outcome::Retry,
            Err(_) => {
                self.surface.configure(&self.device, &self.config);
                return Outcome::Retry;
            }
        };
        let surface_view = st.texture.create_view(&wgpu::TextureViewDescriptor::default());
        let clear = plan::clear_color(frame, self.srgb_encode);
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor { label: Some("frame") });
        {
            let final_view: &wgpu::TextureView = if scaled {
                match &targets.offscreen_view {
                    Some(v) => v,
                    None => return Outcome::Retry,
                }
            } else {
                &surface_view
            };
            let (color_view, resolve) = match &targets.ms_view {
                Some(ms) => (ms, Some(final_view)),
                None => (final_view, None),
            };
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("scene"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: color_view,
                    resolve_target: resolve,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color { r: clear[0], g: clear[1], b: clear[2], a: clear[3] }),
                        store: if resolve.is_some() { wgpu::StoreOp::Discard } else { wgpu::StoreOp::Store },
                    },
                })],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &targets.depth_view,
                    depth_ops: Some(wgpu::Operations { load: wgpu::LoadOp::Clear(1.0), store: wgpu::StoreOp::Discard }),
                    stencil_ops: None,
                }),
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_bind_group(0, &self.frame_bind_group, &[]);

            if !plan.opaque.is_empty() {
                pass.set_pipeline(&pipes.mesh_opaque);
                for d in &plan.opaque {
                    let Some(m) = self.meshes.get(&d.mesh_key) else { continue };
                    let Some(index) = &m.index else { continue };
                    pass.set_bind_group(1, self.objects.bind_group(), &[self.objects.offset(d.slot)]);
                    pass.set_vertex_buffer(0, m.vertex.slice(..));
                    pass.set_index_buffer(index.slice(..), wgpu::IndexFormat::Uint32);
                    pass.draw_indexed(d.first_index..d.first_index + d.index_count, 0, 0..1);
                }
            }
            if !plan.wires.is_empty() {
                pass.set_pipeline(&pipes.wire);
                for w in &plan.wires {
                    let Some(m) = self.meshes.get(&w.mesh_key) else { continue };
                    let Some(edges) = &m.edges else { continue };
                    pass.set_bind_group(1, self.objects.bind_group(), &[self.objects.offset(w.slot)]);
                    pass.set_vertex_buffer(0, m.vertex.slice(..));
                    pass.set_index_buffer(edges.slice(..), wgpu::IndexFormat::Uint32);
                    pass.draw_indexed(0..w.index_count, 0, 0..1);
                }
            }
            if !plan.blended.is_empty() {
                pass.set_pipeline(&pipes.mesh_blend);
                for d in &plan.blended {
                    let Some(m) = self.meshes.get(&d.mesh_key) else { continue };
                    let Some(index) = &m.index else { continue };
                    pass.set_bind_group(1, self.objects.bind_group(), &[self.objects.offset(d.slot)]);
                    pass.set_vertex_buffer(0, m.vertex.slice(..));
                    pass.set_index_buffer(index.slice(..), wgpu::IndexFormat::Uint32);
                    pass.draw_indexed(d.first_index..d.first_index + d.index_count, 0, 0..1);
                }
            }
            if let (Some(b), true) = (self.lines.buffer(), counts.lines > 0) {
                pass.set_pipeline(&pipes.lines_depth);
                pass.set_vertex_buffer(0, b.slice(..));
                pass.draw(0..counts.lines, 0..1);
            }
            if let (Some(b), true) = (self.tris.buffer(), counts.tris > 0) {
                pass.set_pipeline(&pipes.tris_depth);
                pass.set_vertex_buffer(0, b.slice(..));
                pass.draw(0..counts.tris, 0..1);
            }
            if let (Some(b), true) = (self.points.buffer(), counts.points > 0) {
                pass.set_pipeline(&pipes.points);
                pass.set_vertex_buffer(0, b.slice(..));
                pass.draw(0..4, 0..counts.points);
            }
            if let (Some(b), true) = (self.overlay_tris.buffer(), counts.overlay_tris > 0) {
                pass.set_pipeline(&pipes.tris_overlay);
                pass.set_vertex_buffer(0, b.slice(..));
                pass.draw(0..counts.overlay_tris, 0..1);
            }
            if let (Some(b), true) = (self.overlay_lines.buffer(), counts.overlay_lines > 0) {
                pass.set_pipeline(&pipes.lines_overlay);
                pass.set_vertex_buffer(0, b.slice(..));
                pass.draw(0..counts.overlay_lines, 0..1);
            }
            if let (Some(b), true) = (self.screen.buffer(), counts.screen > 0) {
                pass.set_pipeline(&pipes.screen);
                pass.set_vertex_buffer(0, b.slice(..));
                pass.draw(0..counts.screen, 0..1);
            }
        }
        if scaled {
            let Some(bind_group) = &targets.blit_bind_group else { return Outcome::Retry };
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("blit"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &surface_view,
                    resolve_target: None,
                    ops: wgpu::Operations { load: wgpu::LoadOp::Clear(wgpu::Color::BLACK), store: wgpu::StoreOp::Store },
                })],
                depth_stencil_attachment: None,
                timestamp_writes: None,
                occlusion_query_set: None,
            });
            pass.set_pipeline(&pipes.blit);
            pass.set_bind_group(0, bind_group, &[]);
            pass.draw(0..3, 0..1);
        }
        self.queue.submit(std::iter::once(encoder.finish()));
        st.present();
        Outcome::Drawn
    }
}
