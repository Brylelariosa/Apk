//! GPU buffers: uploaded meshes, grow-only dynamic vertex buffers and the dynamic-offset object uniform store.
use super::plan::{ObjectUniform, OBJECT_UNIFORM_SIZE};
use crate::util::{align_up, bytes_of, slice_bytes, Plain};
use forge_engine::RenderBuffers;
use std::num::NonZeroU64;
use wgpu::util::DeviceExt;

// SAFETY: u32 has no padding.
unsafe impl Plain for u32 {}

pub struct GpuMesh {
    pub vertex: wgpu::Buffer,
    pub index: Option<wgpu::Buffer>,
    pub edges: Option<wgpu::Buffer>,
    pub bytes: u64,
}

impl GpuMesh {
    pub fn upload(device: &wgpu::Device, b: &RenderBuffers) -> GpuMesh {
        let make = |label: &str, bytes: &[u8], usage: wgpu::BufferUsages| device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some(label), contents: bytes, usage });
        let vertex = make("mesh vertices", slice_bytes(&b.vertices), wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST);
        let index = (!b.indices.is_empty()).then(|| make("mesh indices", slice_bytes(&b.indices), wgpu::BufferUsages::INDEX));
        let edges = (!b.edge_indices.is_empty()).then(|| make("mesh edges", slice_bytes(&b.edge_indices), wgpu::BufferUsages::INDEX));
        GpuMesh { vertex, index, edges, bytes: b.memory_bytes() as u64 }
    }
}

/// A vertex buffer rewritten every frame; grows (power of two) and shrinks again when far too large.
#[derive(Default)]
pub struct DynBuf {
    buffer: Option<wgpu::Buffer>,
    capacity: u64,
}

impl DynBuf {
    /// Writes `data`; returns false when there is nothing to draw (empty or larger than `max_size`).
    pub fn write(&mut self, device: &wgpu::Device, queue: &wgpu::Queue, data: &[u8], max_size: u64) -> bool {
        let need = data.len() as u64;
        if need == 0 || need > max_size {
            return false;
        }
        let too_big = self.capacity > (1 << 20) && need * 8 < self.capacity;
        if self.buffer.is_none() || self.capacity < need || too_big {
            let cap = align_up(need.next_power_of_two().max(4096).min(max_size), 4);
            self.buffer = Some(device.create_buffer(&wgpu::BufferDescriptor { label: Some("dynamic vertices"), size: cap, usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST, mapped_at_creation: false }));
            self.capacity = cap;
        }
        if let Some(b) = &self.buffer {
            queue.write_buffer(b, 0, data);
        }
        true
    }

    pub fn buffer(&self) -> Option<&wgpu::Buffer> {
        self.buffer.as_ref()
    }

    pub fn bytes(&self) -> u64 {
        self.capacity
    }
}

/// One big uniform buffer with a 256-byte aligned slot per draw call, bound with dynamic offsets.
pub struct ObjectStore {
    buffer: wgpu::Buffer,
    bind_group: wgpu::BindGroup,
    slots: u32,
    stride: u32,
    staging: Vec<u8>,
}

fn object_bind_group(device: &wgpu::Device, layout: &wgpu::BindGroupLayout, buffer: &wgpu::Buffer) -> wgpu::BindGroup {
    device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("object uniforms"),
        layout,
        entries: &[wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding { buffer, offset: 0, size: NonZeroU64::new(OBJECT_UNIFORM_SIZE) }) }],
    })
}

fn object_buffer(device: &wgpu::Device, slots: u32, stride: u32) -> wgpu::Buffer {
    device.create_buffer(&wgpu::BufferDescriptor { label: Some("object uniforms"), size: slots as u64 * stride as u64, usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST, mapped_at_creation: false })
}

impl ObjectStore {
    /// `alignment` is the device's `min_uniform_buffer_offset_alignment`.
    pub fn new(device: &wgpu::Device, layout: &wgpu::BindGroupLayout, alignment: u32) -> ObjectStore {
        let stride = align_up(OBJECT_UNIFORM_SIZE.max(256), alignment.max(1) as u64) as u32;
        let slots = 256;
        let buffer = object_buffer(device, slots, stride);
        let bind_group = object_bind_group(device, layout, &buffer);
        ObjectStore { buffer, bind_group, slots, stride, staging: Vec::new() }
    }

    /// Writes every object uniform into its slot, growing the store when needed.
    pub fn upload(&mut self, device: &wgpu::Device, layout: &wgpu::BindGroupLayout, queue: &wgpu::Queue, objects: &[ObjectUniform]) {
        if objects.is_empty() {
            return;
        }
        let needed = objects.len() as u32;
        if needed > self.slots {
            self.slots = needed.next_power_of_two();
            self.buffer = object_buffer(device, self.slots, self.stride);
            self.bind_group = object_bind_group(device, layout, &self.buffer);
        }
        let stride = self.stride as usize;
        self.staging.clear();
        self.staging.resize(objects.len() * stride, 0);
        for (i, o) in objects.iter().enumerate() {
            let b = bytes_of(o);
            self.staging[i * stride..i * stride + b.len()].copy_from_slice(b);
        }
        queue.write_buffer(&self.buffer, 0, &self.staging);
    }

    pub fn bind_group(&self) -> &wgpu::BindGroup {
        &self.bind_group
    }

    pub fn offset(&self, slot: u32) -> u32 {
        slot * self.stride
    }

    pub fn bytes(&self) -> u64 {
        self.slots as u64 * self.stride as u64
    }
}
