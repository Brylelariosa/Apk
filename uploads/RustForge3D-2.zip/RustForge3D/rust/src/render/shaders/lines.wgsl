// World space lines and triangles with per-vertex colour. vs_depth is biased towards the camera,
// vs_overlay is used with depth testing disabled (gizmos).
struct LineOut {
    @builtin(position) clip: vec4<f32>,
    @location(0) color: vec4<f32>,
};

@vertex
fn vs_depth(@location(0) position: vec3<f32>, @location(1) color: vec4<f32>) -> LineOut {
    var o: LineOut;
    o.clip = frame.view_proj * vec4<f32>(position, 1.0);
    o.clip.z = o.clip.z - 0.0003 * o.clip.w;
    o.color = color;
    return o;
}

@vertex
fn vs_overlay(@location(0) position: vec3<f32>, @location(1) color: vec4<f32>) -> LineOut {
    var o: LineOut;
    o.clip = frame.view_proj * vec4<f32>(position, 1.0);
    o.color = color;
    return o;
}

@fragment
fn fs_main(fin: LineOut) -> @location(0) vec4<f32> {
    return vec4<f32>(encode_out(fin.color.rgb), fin.color.a);
}
