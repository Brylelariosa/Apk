// Mesh edges (edge index buffer) in the object's flat colour (base_color), pulled slightly towards the camera.
@vertex
fn vs_main(@location(0) position: vec3<f32>) -> @builtin(position) vec4<f32> {
    var c = frame.view_proj * (obj.model * vec4<f32>(position, 1.0));
    c.z = c.z - 0.0003 * c.w;
    return c;
}

@fragment
fn fs_main() -> @location(0) vec4<f32> {
    return vec4<f32>(encode_out(obj.base_color.rgb), obj.base_color.a);
}
