// Shared prelude: per-frame uniform block (group 0) and output encoding.
struct Light {
    position_kind: vec4<f32>,
    direction: vec4<f32>,
    color_intensity: vec4<f32>,
    spot: vec4<f32>,
};

struct Frame {
    view_proj: mat4x4<f32>,
    eye: vec4<f32>,
    viewport: vec4<f32>,
    flags: vec4<f32>,
    ambient: vec4<f32>,
    lights: array<Light, 8>,
};

@group(0) @binding(0) var<uniform> frame: Frame;

// flags.z > 0.5 means the swapchain is not an sRGB format and the shader must encode.
fn encode_out(c: vec3<f32>) -> vec3<f32> {
    if (frame.flags.z > 0.5) {
        return pow(max(c, vec3<f32>(0.0)), vec3<f32>(1.0 / 2.2));
    }
    return c;
}
