// Lit surfaces. params = (metallic, roughness, state 0/1/2, mirror +1/-1).
struct MeshOut {
    @builtin(position) clip: vec4<f32>,
    @location(0) world: vec3<f32>,
    @location(1) normal: vec3<f32>,
};

@vertex
fn vs_main(@location(0) position: vec3<f32>, @location(1) normal: vec3<f32>) -> MeshOut {
    let w = obj.model * vec4<f32>(position, 1.0);
    var o: MeshOut;
    o.clip = frame.view_proj * w;
    o.world = w.xyz;
    o.normal = (obj.normal * vec4<f32>(normal, 0.0)).xyz;
    return o;
}

fn light_term(l: Light, p: vec3<f32>, n: vec3<f32>, v: vec3<f32>, diffuse_col: vec3<f32>, spec_col: vec3<f32>, shininess: f32) -> vec3<f32> {
    var ldir = -normalize(l.direction.xyz);
    var atten = 1.0;
    if (l.position_kind.w > 0.5) {
        let d = l.position_kind.xyz - p;
        let dist2 = max(dot(d, d), 0.0001);
        ldir = d * inverseSqrt(dist2);
        atten = 1.0 / dist2;
        if (l.position_kind.w > 1.5) {
            let c = dot(-ldir, normalize(l.direction.xyz));
            let t = clamp((c - l.spot.y) / max(l.spot.x - l.spot.y, 0.0001), 0.0, 1.0);
            atten = atten * t * t * (3.0 - 2.0 * t);
        }
    }
    let ndl = max(dot(n, ldir), 0.0);
    let h = normalize(ldir + v);
    let ndh = max(dot(n, h), 0.0);
    let spec = pow(ndh, shininess) * ndl;
    let radiance = l.color_intensity.rgb * (l.color_intensity.w * atten);
    return (diffuse_col * ndl + spec_col * spec) * radiance;
}

@fragment
fn fs_main(fin: MeshOut, @builtin(front_facing) front: bool) -> @location(0) vec4<f32> {
    var n = normalize(fin.normal);
    let facing = select(-1.0, 1.0, front);
    n = n * facing * obj.params.w;
    let v = normalize(frame.eye.xyz - fin.world);
    let metallic = obj.params.x;
    let rough = clamp(obj.params.y, 0.04, 1.0);
    let base = obj.base_color.rgb;
    let diffuse_col = base * (1.0 - metallic);
    let spec_col = mix(vec3<f32>(0.04), base, metallic) * (1.0 - rough * 0.6);
    let shininess = mix(6.0, 220.0, (1.0 - rough) * (1.0 - rough));
    let up = n.z * 0.5 + 0.5;
    let amb = mix(frame.ambient.rgb * 0.45, frame.ambient.rgb, up);
    var col = diffuse_col * amb + obj.emissive.rgb;
    let count = i32(frame.flags.y);
    for (var i = 0; i < count; i = i + 1) {
        col = col + light_term(frame.lights[i], fin.world, n, v, diffuse_col, spec_col, shininess);
    }
    if (obj.params.z > 0.5) {
        col = mix(col, vec3<f32>(1.0, 0.6, 0.2), 0.06);
    }
    return vec4<f32>(encode_out(col), obj.base_color.a);
}
