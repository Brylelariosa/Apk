// 2D lines in pixels (origin top-left), e.g. the box selection rubber band.
struct ScreenOut {
    @builtin(position) clip: vec4<f32>,
    @location(0) color: vec4<f32>,
};

@vertex
fn vs_main(@location(0) position: vec2<f32>, @location(1) color: vec4<f32>) -> ScreenOut {
    var o: ScreenOut;
    o.clip = vec4<f32>(position.x * frame.viewport.z * 2.0 - 1.0, 1.0 - position.y * frame.viewport.w * 2.0, 0.0, 1.0);
    o.color = color;
    return o;
}

@fragment
fn fs_main(fin: ScreenOut) -> @location(0) vec4<f32> {
    return vec4<f32>(encode_out(fin.color.rgb), fin.color.a);
}
