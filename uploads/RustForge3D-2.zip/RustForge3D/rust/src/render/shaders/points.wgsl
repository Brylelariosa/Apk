// Camera facing round markers: one instance per point, a 4 vertex triangle strip per instance.
struct PointOut {
    @builtin(position) clip: vec4<f32>,
    @location(0) color: vec4<f32>,
    @location(1) local: vec2<f32>,
};

@vertex
fn vs_main(@builtin(vertex_index) vi: u32, @location(0) position: vec3<f32>, @location(1) size_px: f32, @location(2) color: vec4<f32>) -> PointOut {
    let corner = vec2<f32>(f32(vi & 1u), f32((vi >> 1u) & 1u)) * 2.0 - vec2<f32>(1.0, 1.0);
    var c = frame.view_proj * vec4<f32>(position, 1.0);
    c.z = c.z - 0.0006 * c.w;
    c.x = c.x + corner.x * size_px * frame.viewport.z * c.w;
    c.y = c.y + corner.y * size_px * frame.viewport.w * c.w;
    var o: PointOut;
    o.clip = c;
    o.color = color;
    o.local = corner;
    return o;
}

@fragment
fn fs_main(fin: PointOut) -> @location(0) vec4<f32> {
    let d = length(fin.local);
    let edge = 1.0 - smoothstep(0.7, 1.0, d);
    return vec4<f32>(encode_out(fin.color.rgb), fin.color.a * edge);
}
