// Per-draw uniform block (group 1, dynamic offset).
struct Object {
    model: mat4x4<f32>,
    normal: mat4x4<f32>,
    base_color: vec4<f32>,
    params: vec4<f32>,
    emissive: vec4<f32>,
};

@group(1) @binding(0) var<uniform> obj: Object;
