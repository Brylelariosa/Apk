//! Size dependent render targets: depth, optional MSAA colour and the optional scaled offscreen colour.
use super::pipelines::DEPTH_FORMAT;

pub struct Targets {
    pub width: u32,
    pub height: u32,
    pub samples: u32,
    pub scaled: bool,
    _depth: wgpu::Texture,
    pub depth_view: wgpu::TextureView,
    _ms: Option<wgpu::Texture>,
    pub ms_view: Option<wgpu::TextureView>,
    _offscreen: Option<wgpu::Texture>,
    pub offscreen_view: Option<wgpu::TextureView>,
    pub blit_bind_group: Option<wgpu::BindGroup>,
    pub bytes: u64,
}

fn texture(device: &wgpu::Device, label: &str, size: (u32, u32), samples: u32, format: wgpu::TextureFormat, usage: wgpu::TextureUsages) -> wgpu::Texture {
    device.create_texture(&wgpu::TextureDescriptor {
        label: Some(label),
        size: wgpu::Extent3d { width: size.0, height: size.1, depth_or_array_layers: 1 },
        mip_level_count: 1,
        sample_count: samples,
        dimension: wgpu::TextureDimension::D2,
        format,
        usage,
        view_formats: &[],
    })
}

impl Targets {
    /// `size` is the internal render resolution; `scaled` renders into an offscreen texture that is blitted afterwards.
    pub fn new(device: &wgpu::Device, format: wgpu::TextureFormat, size: (u32, u32), samples: u32, scaled: bool, blit_layout: &wgpu::BindGroupLayout, sampler: &wgpu::Sampler) -> Targets {
        let px = size.0 as u64 * size.1 as u64;
        let attachment = wgpu::TextureUsages::RENDER_ATTACHMENT;
        let depth = texture(device, "depth", size, samples, DEPTH_FORMAT, attachment);
        let depth_view = depth.create_view(&wgpu::TextureViewDescriptor::default());
        let mut bytes = px * 4 * samples as u64;
        let (ms, ms_view) = if samples > 1 {
            let t = texture(device, "msaa colour", size, samples, format, attachment);
            let v = t.create_view(&wgpu::TextureViewDescriptor::default());
            bytes += px * 4 * samples as u64;
            (Some(t), Some(v))
        } else {
            (None, None)
        };
        let (off, off_view, blit_bind_group) = if scaled {
            let t = texture(device, "scaled colour", size, 1, format, attachment | wgpu::TextureUsages::TEXTURE_BINDING);
            let v = t.create_view(&wgpu::TextureViewDescriptor::default());
            let bg = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some("blit"),
                layout: blit_layout,
                entries: &[wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&v) }, wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(sampler) }],
            });
            bytes += px * 4;
            (Some(t), Some(v), Some(bg))
        } else {
            (None, None, None)
        };
        Targets { width: size.0, height: size.1, samples, scaled, _depth: depth, depth_view, _ms: ms, ms_view, _offscreen: off, offscreen_view: off_view, blit_bind_group, bytes }
    }

    pub fn matches(&self, size: (u32, u32), samples: u32, scaled: bool) -> bool {
        self.width == size.0 && self.height == size.1 && self.samples == samples && self.scaled == scaled
    }
}
