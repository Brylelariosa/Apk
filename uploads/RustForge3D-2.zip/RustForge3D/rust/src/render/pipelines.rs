//! WGSL modules, bind group layouts and render pipelines.
use super::plan::{FRAME_UNIFORM_SIZE, OBJECT_UNIFORM_SIZE};
use forge_engine::{LineVertex, PointInstance, RenderVertex, ScreenVertex};
use std::borrow::Cow;
use std::mem::size_of;
use std::num::NonZeroU64;

pub const DEPTH_FORMAT: wgpu::TextureFormat = wgpu::TextureFormat::Depth32Float;

const COMMON: &str = include_str!("shaders/common.wgsl");
const OBJECT: &str = include_str!("shaders/object.wgsl");
const MESH: &str = include_str!("shaders/mesh.wgsl");
const WIRE: &str = include_str!("shaders/wire.wgsl");
const LINES: &str = include_str!("shaders/lines.wgsl");
const POINTS: &str = include_str!("shaders/points.wgsl");
const SCREEN: &str = include_str!("shaders/screen.wgsl");
const BLIT: &str = include_str!("shaders/blit.wgsl");

const MESH_ATTRS: [wgpu::VertexAttribute; 2] = [
    wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32x3, offset: 0, shader_location: 0 },
    wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32x3, offset: 12, shader_location: 1 },
];
const POSITION_ATTRS: [wgpu::VertexAttribute; 1] = [wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32x3, offset: 0, shader_location: 0 }];
const LINE_ATTRS: [wgpu::VertexAttribute; 2] = [
    wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32x3, offset: 0, shader_location: 0 },
    wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32x4, offset: 12, shader_location: 1 },
];
const POINT_ATTRS: [wgpu::VertexAttribute; 3] = [
    wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32x3, offset: 0, shader_location: 0 },
    wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32, offset: 12, shader_location: 1 },
    wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32x4, offset: 16, shader_location: 2 },
];
const SCREEN_ATTRS: [wgpu::VertexAttribute; 2] = [
    wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32x2, offset: 0, shader_location: 0 },
    wgpu::VertexAttribute { format: wgpu::VertexFormat::Float32x4, offset: 8, shader_location: 1 },
];

pub struct Layouts {
    pub frame: wgpu::BindGroupLayout,
    pub object: wgpu::BindGroupLayout,
    pub blit: wgpu::BindGroupLayout,
    frame_only: wgpu::PipelineLayout,
    frame_object: wgpu::PipelineLayout,
    blit_only: wgpu::PipelineLayout,
}

impl Layouts {
    pub fn new(device: &wgpu::Device) -> Layouts {
        let uniform = |size: u64, dynamic: bool| wgpu::BindGroupLayoutEntry {
            binding: 0,
            visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
            ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: dynamic, min_binding_size: NonZeroU64::new(size) },
            count: None,
        };
        let frame = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor { label: Some("frame uniforms"), entries: &[uniform(FRAME_UNIFORM_SIZE, false)] });
        let object = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor { label: Some("object uniforms"), entries: &[uniform(OBJECT_UNIFORM_SIZE, true)] });
        let blit = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("blit"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, view_dimension: wgpu::TextureViewDimension::D2, multisampled: false },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
            ],
        });
        let make = |label: &str, groups: &[&wgpu::BindGroupLayout]| {
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor { label: Some(label), bind_group_layouts: groups, push_constant_ranges: &[] })
        };
        let frame_only = make("frame only", &[&frame]);
        let frame_object = make("frame + object", &[&frame, &object]);
        let blit_only = make("blit", &[&blit]);
        Layouts { frame, object, blit, frame_only, frame_object, blit_only }
    }
}

pub struct Shaders {
    mesh: wgpu::ShaderModule,
    wire: wgpu::ShaderModule,
    lines: wgpu::ShaderModule,
    points: wgpu::ShaderModule,
    screen: wgpu::ShaderModule,
    blit: wgpu::ShaderModule,
}

fn module(device: &wgpu::Device, label: &str, parts: &[&str]) -> wgpu::ShaderModule {
    device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some(label), source: wgpu::ShaderSource::Wgsl(Cow::Owned(parts.concat())) })
}

impl Shaders {
    pub fn new(device: &wgpu::Device) -> Shaders {
        Shaders {
            mesh: module(device, "mesh", &[COMMON, OBJECT, MESH]),
            wire: module(device, "wire", &[COMMON, OBJECT, WIRE]),
            lines: module(device, "lines", &[COMMON, LINES]),
            points: module(device, "points", &[COMMON, POINTS]),
            screen: module(device, "screen", &[COMMON, SCREEN]),
            blit: module(device, "blit", &[BLIT]),
        }
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum Depth {
    /// Depth test and write (opaque surfaces).
    Write,
    /// Depth test only.
    Test,
    /// Always passes, never writes (overlays).
    Always,
    /// The pass has no depth attachment.
    Off,
}

struct Spec<'a> {
    label: &'a str,
    module: &'a wgpu::ShaderModule,
    vs: &'a str,
    fs: &'a str,
    layout: &'a wgpu::PipelineLayout,
    buffers: &'a [wgpu::VertexBufferLayout<'a>],
    topology: wgpu::PrimitiveTopology,
    depth: Depth,
    blend: Option<wgpu::BlendState>,
    samples: u32,
}

fn make_pipeline(device: &wgpu::Device, format: wgpu::TextureFormat, s: &Spec) -> wgpu::RenderPipeline {
    let depth_stencil = if s.depth == Depth::Off {
        None
    } else {
        Some(wgpu::DepthStencilState {
            format: DEPTH_FORMAT,
            depth_write_enabled: s.depth == Depth::Write,
            depth_compare: match s.depth {
                Depth::Write => wgpu::CompareFunction::Less,
                Depth::Test => wgpu::CompareFunction::LessEqual,
                _ => wgpu::CompareFunction::Always,
            },
            stencil: wgpu::StencilState::default(),
            bias: wgpu::DepthBiasState::default(),
        })
    };
    device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
        label: Some(s.label),
        layout: Some(s.layout),
        vertex: wgpu::VertexState { module: s.module, entry_point: s.vs, compilation_options: wgpu::PipelineCompilationOptions::default(), buffers: s.buffers },
        primitive: wgpu::PrimitiveState { topology: s.topology, ..Default::default() },
        depth_stencil,
        multisample: wgpu::MultisampleState { count: s.samples, ..Default::default() },
        fragment: Some(wgpu::FragmentState {
            module: s.module,
            entry_point: s.fs,
            compilation_options: wgpu::PipelineCompilationOptions::default(),
            targets: &[Some(wgpu::ColorTargetState { format, blend: s.blend, write_mask: wgpu::ColorWrites::ALL })],
        }),
        multiview: None,
        cache: None,
    })
}

pub struct Pipelines {
    pub mesh_opaque: wgpu::RenderPipeline,
    pub mesh_blend: wgpu::RenderPipeline,
    pub wire: wgpu::RenderPipeline,
    pub lines_depth: wgpu::RenderPipeline,
    pub lines_overlay: wgpu::RenderPipeline,
    pub tris_depth: wgpu::RenderPipeline,
    pub tris_overlay: wgpu::RenderPipeline,
    pub points: wgpu::RenderPipeline,
    pub screen: wgpu::RenderPipeline,
    pub blit: wgpu::RenderPipeline,
}

impl Pipelines {
    /// All pipelines for a colour format and MSAA sample count (the blit pipeline always renders 1x).
    pub fn new(device: &wgpu::Device, shaders: &Shaders, layouts: &Layouts, format: wgpu::TextureFormat, samples: u32) -> Pipelines {
        let vertex_layout = |stride: usize, attrs: &'static [wgpu::VertexAttribute]| wgpu::VertexBufferLayout { array_stride: stride as u64, step_mode: wgpu::VertexStepMode::Vertex, attributes: attrs };
        let mesh = [vertex_layout(size_of::<RenderVertex>(), &MESH_ATTRS)];
        let position_only = [vertex_layout(size_of::<RenderVertex>(), &POSITION_ATTRS)];
        let line = [vertex_layout(size_of::<LineVertex>(), &LINE_ATTRS)];
        let screen = [vertex_layout(size_of::<ScreenVertex>(), &SCREEN_ATTRS)];
        let point = [wgpu::VertexBufferLayout { array_stride: size_of::<PointInstance>() as u64, step_mode: wgpu::VertexStepMode::Instance, attributes: &POINT_ATTRS }];
        let alpha = Some(wgpu::BlendState::ALPHA_BLENDING);
        let tri = wgpu::PrimitiveTopology::TriangleList;
        let lin = wgpu::PrimitiveTopology::LineList;
        let make = |s: Spec| make_pipeline(device, format, &s);
        Pipelines {
            mesh_opaque: make(Spec { label: "mesh", module: &shaders.mesh, vs: "vs_main", fs: "fs_main", layout: &layouts.frame_object, buffers: &mesh, topology: tri, depth: Depth::Write, blend: None, samples }),
            mesh_blend: make(Spec { label: "mesh blended", module: &shaders.mesh, vs: "vs_main", fs: "fs_main", layout: &layouts.frame_object, buffers: &mesh, topology: tri, depth: Depth::Test, blend: alpha, samples }),
            wire: make(Spec { label: "wire", module: &shaders.wire, vs: "vs_main", fs: "fs_main", layout: &layouts.frame_object, buffers: &position_only, topology: lin, depth: Depth::Test, blend: alpha, samples }),
            lines_depth: make(Spec { label: "lines", module: &shaders.lines, vs: "vs_depth", fs: "fs_main", layout: &layouts.frame_only, buffers: &line, topology: lin, depth: Depth::Test, blend: alpha, samples }),
            lines_overlay: make(Spec { label: "overlay lines", module: &shaders.lines, vs: "vs_overlay", fs: "fs_main", layout: &layouts.frame_only, buffers: &line, topology: lin, depth: Depth::Always, blend: alpha, samples }),
            tris_depth: make(Spec { label: "triangles", module: &shaders.lines, vs: "vs_depth", fs: "fs_main", layout: &layouts.frame_only, buffers: &line, topology: tri, depth: Depth::Test, blend: alpha, samples }),
            tris_overlay: make(Spec { label: "overlay triangles", module: &shaders.lines, vs: "vs_overlay", fs: "fs_main", layout: &layouts.frame_only, buffers: &line, topology: tri, depth: Depth::Always, blend: alpha, samples }),
            points: make(Spec { label: "points", module: &shaders.points, vs: "vs_main", fs: "fs_main", layout: &layouts.frame_only, buffers: &point, topology: wgpu::PrimitiveTopology::TriangleStrip, depth: Depth::Test, blend: alpha, samples }),
            screen: make(Spec { label: "screen lines", module: &shaders.screen, vs: "vs_main", fs: "fs_main", layout: &layouts.frame_only, buffers: &screen, topology: lin, depth: Depth::Always, blend: alpha, samples }),
            blit: make(Spec { label: "blit", module: &shaders.blit, vs: "vs_main", fs: "fs_main", layout: &layouts.blit_only, buffers: &[], topology: tri, depth: Depth::Off, blend: None, samples: 1 }),
        }
    }
}
