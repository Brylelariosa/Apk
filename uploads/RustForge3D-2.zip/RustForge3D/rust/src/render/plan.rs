//! Pure conversion of a `RenderFrame` into GPU-ready packets (uniform blocks, ordered draw lists).
//! No wgpu types here, so everything is unit-testable on the host.
use crate::util::Plain;
use forge_engine::{LightData, LightKind, MaterialData, RenderBuffers, RenderFrame, RenderVertex, ShadingMode, SubMesh, WireMode};
use forge_engine::{LineVertex, PointInstance, ScreenVertex};
use std::collections::HashMap;

pub const MAX_LIGHTS: usize = 8;

/// Selection / wire colours (linear RGBA).
pub const WIRE_ACTIVE: [f32; 4] = [1.0, 0.8, 0.3, 1.0];
pub const WIRE_SELECTED: [f32; 4] = [1.0, 0.55, 0.1, 1.0];
pub const WIRE_OVERLAY: [f32; 4] = [0.0, 0.0, 0.0, 0.45];
pub const WIRE_ONLY: [f32; 4] = [0.75, 0.75, 0.78, 1.0];
/// Objects with more edge-index entries than this get only the tint, not an orange edge outline.
const OUTLINE_INDEX_LIMIT: u32 = 400_000;
const XRAY_ALPHA: f32 = 0.35;

#[repr(C)]
#[derive(Clone, Copy, Default, Debug, PartialEq)]
pub struct LightUniform {
    /// xyz position, w kind (0 sun, 1 point, 2 spot)
    pub position_kind: [f32; 4],
    pub direction: [f32; 4],
    /// rgb colour, w intensity
    pub color_intensity: [f32; 4],
    /// x cos(inner), y cos(outer)
    pub spot: [f32; 4],
}

#[repr(C)]
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct FrameUniform {
    pub view_proj: [f32; 16],
    pub eye: [f32; 4],
    /// width, height, 1/width, 1/height (pixels of the engine viewport)
    pub viewport: [f32; 4],
    /// x shading mode (0 solid, 1 wire, 2 material), y light count, z "encode sRGB in shader"
    pub flags: [f32; 4],
    pub ambient: [f32; 4],
    pub lights: [LightUniform; MAX_LIGHTS],
}

#[repr(C)]
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ObjectUniform {
    pub model: [f32; 16],
    pub normal: [f32; 16],
    pub base_color: [f32; 4],
    /// metallic, roughness, state (0 none / 1 selected / 2 active), mirror (+1 / -1)
    pub params: [f32; 4],
    pub emissive: [f32; 4],
}

// SAFETY: all of these are repr(C) structs of f32 only; the tests assert their exact sizes (no padding).
unsafe impl Plain for LightUniform {}
unsafe impl Plain for FrameUniform {}
unsafe impl Plain for ObjectUniform {}
unsafe impl Plain for RenderVertex {}
unsafe impl Plain for LineVertex {}
unsafe impl Plain for PointInstance {}
unsafe impl Plain for ScreenVertex {}

pub const FRAME_UNIFORM_SIZE: u64 = std::mem::size_of::<FrameUniform>() as u64;
pub const OBJECT_UNIFORM_SIZE: u64 = std::mem::size_of::<ObjectUniform>() as u64;

/// What the renderer needs to know about an uploaded mesh to build draw calls.
#[derive(Clone, Debug, PartialEq)]
pub struct MeshInfo {
    pub submeshes: Vec<SubMesh>,
    pub edge_index_count: u32,
}

impl MeshInfo {
    pub fn from_buffers(b: &RenderBuffers) -> MeshInfo {
        MeshInfo { submeshes: b.submeshes.clone(), edge_index_count: b.edge_indices.len() as u32 }
    }
}

#[derive(Default)]
pub struct MeshTable {
    map: HashMap<u64, MeshInfo>,
}

impl MeshTable {
    pub fn insert(&mut self, key: u64, info: MeshInfo) {
        self.map.insert(key, info);
    }
    pub fn remove(&mut self, key: u64) {
        self.map.remove(&key);
    }
    pub fn get(&self, key: u64) -> Option<&MeshInfo> {
        self.map.get(&key)
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct MeshDraw {
    pub mesh_key: u64,
    /// Slot in the object uniform buffer.
    pub slot: u32,
    pub first_index: u32,
    pub index_count: u32,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct WireDraw {
    pub mesh_key: u64,
    pub slot: u32,
    pub index_count: u32,
}

pub struct FramePlan {
    pub frame: FrameUniform,
    /// One entry per uniform slot (`MeshDraw::slot` / `WireDraw::slot` index into this).
    pub objects: Vec<ObjectUniform>,
    pub opaque: Vec<MeshDraw>,
    pub wires: Vec<WireDraw>,
    /// Alpha blended surfaces, back to front.
    pub blended: Vec<MeshDraw>,
    /// Draw calls dropped because the slot budget was exhausted.
    pub dropped: u32,
}

pub struct PlanParams {
    /// The swapchain is not an sRGB format: shaders encode the output.
    pub srgb_encode: bool,
    pub max_slots: usize,
}

/// Column-major `a * b`.
pub fn mul4(a: &[f32; 16], b: &[f32; 16]) -> [f32; 16] {
    let mut out = [0.0f32; 16];
    for c in 0..4 {
        for r in 0..4 {
            let mut s = 0.0;
            for k in 0..4 {
                s += a[k * 4 + r] * b[c * 4 + k];
            }
            out[c * 4 + r] = s;
        }
    }
    out
}

fn cross(a: [f32; 3], b: [f32; 3]) -> [f32; 3] {
    [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
}

/// Normal matrix of a model matrix as a column-major 4x4, plus the mirror factor (-1 for negative determinants).
/// It is the cofactor matrix (inverse transpose up to scale), flipped back for mirrored transforms; the shader normalises.
pub fn normal_matrix(m: &[f32; 16]) -> ([f32; 16], f32) {
    let c0 = [m[0], m[1], m[2]];
    let c1 = [m[4], m[5], m[6]];
    let c2 = [m[8], m[9], m[10]];
    let n0 = cross(c1, c2);
    let det = c0[0] * n0[0] + c0[1] * n0[1] + c0[2] * n0[2];
    let s = if det < 0.0 { -1.0 } else { 1.0 };
    let n1 = cross(c2, c0);
    let n2 = cross(c0, c1);
    let out = [n0[0] * s, n0[1] * s, n0[2] * s, 0.0, n1[0] * s, n1[1] * s, n1[2] * s, 0.0, n2[0] * s, n2[1] * s, n2[2] * s, 0.0, 0.0, 0.0, 0.0, 1.0];
    (out, s)
}

fn pack_lights(lights: &[LightData]) -> ([LightUniform; MAX_LIGHTS], usize) {
    let mut out = [LightUniform::default(); MAX_LIGHTS];
    let n = lights.len().min(MAX_LIGHTS);
    for (u, l) in out.iter_mut().zip(lights.iter()) {
        let kind = match l.kind {
            LightKind::Sun => 0.0,
            LightKind::Point => 1.0,
            LightKind::Spot => 2.0,
        };
        u.position_kind = [l.position[0], l.position[1], l.position[2], kind];
        u.direction = [l.direction[0], l.direction[1], l.direction[2], 0.0];
        u.color_intensity = [l.color[0], l.color[1], l.color[2], l.intensity];
        u.spot = [l.spot_cos[0], l.spot_cos[1], 0.0, 0.0];
    }
    (out, n)
}

pub fn frame_uniform(frame: &RenderFrame, srgb_encode: bool) -> FrameUniform {
    let (lights, count) = pack_lights(&frame.lights);
    let w = frame.width.max(1) as f32;
    let h = frame.height.max(1) as f32;
    let mode = match frame.shading {
        ShadingMode::Solid => 0.0,
        ShadingMode::Wireframe => 1.0,
        ShadingMode::Material => 2.0,
    };
    FrameUniform {
        view_proj: mul4(&frame.proj, &frame.view),
        eye: [frame.eye[0], frame.eye[1], frame.eye[2], 1.0],
        viewport: [w, h, 1.0 / w, 1.0 / h],
        flags: [mode, count as f32, if srgb_encode { 1.0 } else { 0.0 }, 0.0],
        ambient: [frame.ambient[0], frame.ambient[1], frame.ambient[2], 0.0],
        lights,
    }
}

/// Clear colour for the target (encoded when the swapchain is not sRGB).
pub fn clear_color(frame: &RenderFrame, srgb_encode: bool) -> [f64; 4] {
    let c = frame.clear_color;
    let f = |v: f32| -> f64 {
        let v = v.clamp(0.0, 1.0) as f64;
        if srgb_encode {
            v.powf(1.0 / 2.2)
        } else {
            v
        }
    };
    [f(c[0]), f(c[1]), f(c[2]), c[3].clamp(0.0, 1.0) as f64]
}

fn material_of(materials: &[MaterialData], index: u32) -> MaterialData {
    materials.get(index as usize).cloned().unwrap_or_default()
}

fn wire_object(model: [f32; 16], color: [f32; 4]) -> ObjectUniform {
    ObjectUniform { model, normal: [0.0; 16], base_color: color, params: [0.0, 0.0, 0.0, 1.0], emissive: [0.0; 4] }
}

/// Turns a frame into ordered draw lists. Items whose mesh is not uploaded yet are skipped.
pub fn build_plan(frame: &RenderFrame, table: &MeshTable, p: &PlanParams) -> FramePlan {
    let mut plan = FramePlan { frame: frame_uniform(frame, p.srgb_encode), objects: Vec::new(), opaque: Vec::new(), wires: Vec::new(), blended: Vec::new(), dropped: 0 };
    let wire_shading = frame.shading == ShadingMode::Wireframe;
    let mut blended: Vec<(f32, MeshDraw)> = Vec::new();

    for item in &frame.items {
        let Some(info) = table.get(item.mesh_key) else { continue };
        let (normal, mirror) = normal_matrix(&item.model);
        let state = if item.active {
            2.0
        } else if item.selected {
            1.0
        } else {
            0.0
        };
        let d = [item.model[12] - frame.eye[0], item.model[13] - frame.eye[1], item.model[14] - frame.eye[2]];
        let dist2 = d[0] * d[0] + d[1] * d[1] + d[2] * d[2];

        if !wire_shading && item.wire != WireMode::Only {
            for sm in &info.submeshes {
                if plan.objects.len() >= p.max_slots {
                    plan.dropped += 1;
                    continue;
                }
                let mat = material_of(&item.materials, sm.material);
                let blend = item.xray || mat.base_color[3] < 0.999;
                let alpha = if item.xray { mat.base_color[3].min(XRAY_ALPHA) } else { mat.base_color[3] };
                let slot = plan.objects.len() as u32;
                plan.objects.push(ObjectUniform {
                    model: item.model,
                    normal,
                    base_color: [mat.base_color[0], mat.base_color[1], mat.base_color[2], alpha],
                    params: [mat.metallic, mat.roughness, state, mirror],
                    emissive: [mat.emissive[0], mat.emissive[1], mat.emissive[2], 0.0],
                });
                let draw = MeshDraw { mesh_key: item.mesh_key, slot, first_index: sm.first_index, index_count: sm.index_count };
                if blend {
                    blended.push((dist2, draw));
                } else {
                    plan.opaque.push(draw);
                }
            }
        }

        let edge_only = wire_shading || item.wire == WireMode::Only;
        let color = if item.active && (edge_only || info.edge_index_count <= OUTLINE_INDEX_LIMIT) {
            Some(WIRE_ACTIVE)
        } else if item.selected && (edge_only || info.edge_index_count <= OUTLINE_INDEX_LIMIT) {
            Some(WIRE_SELECTED)
        } else if edge_only {
            Some(WIRE_ONLY)
        } else if item.wire == WireMode::Overlay {
            Some(WIRE_OVERLAY)
        } else {
            None
        };
        if let (Some(color), true) = (color, info.edge_index_count > 0) {
            if plan.objects.len() >= p.max_slots {
                plan.dropped += 1;
            } else {
                let slot = plan.objects.len() as u32;
                plan.objects.push(wire_object(item.model, color));
                plan.wires.push(WireDraw { mesh_key: item.mesh_key, slot, index_count: info.edge_index_count });
            }
        }
    }
    blended.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
    plan.blended = blended.into_iter().map(|(_, d)| d).collect();
    plan
}

/// 4x MSAA only when both colour and depth formats support it.
pub fn choose_msaa(requested: u32, supports_4x: bool) -> u32 {
    if requested >= 4 && supports_4x {
        4
    } else {
        1
    }
}

/// Internal render resolution for a surface size and scale factor.
pub fn target_size(width: u32, height: u32, scale: f32) -> (u32, u32) {
    let s = if scale.is_finite() { scale.clamp(0.25, 1.0) } else { 1.0 };
    (((width as f32 * s).round() as u32).max(1), ((height as f32 * s).round() as u32).max(1))
}

#[cfg(test)]
mod tests {
    use super::*;
    use forge_engine::{DrawItem, SubMesh};

    const ID: [f32; 16] = [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0];

    fn table_with(key: u64, submeshes: Vec<SubMesh>, edges: u32) -> MeshTable {
        let mut t = MeshTable::default();
        t.insert(key, MeshInfo { submeshes, edge_index_count: edges });
        t
    }

    fn item(key: u64, tz: f32) -> DrawItem {
        let mut model = ID;
        model[14] = tz;
        DrawItem { mesh_key: key, model, materials: vec![MaterialData::default()], selected: false, active: false, wire: WireMode::None, xray: false }
    }

    fn params() -> PlanParams {
        PlanParams { srgb_encode: false, max_slots: 1000 }
    }

    #[test]
    fn uniform_layouts_match_wgsl() {
        assert_eq!(std::mem::size_of::<LightUniform>(), 64);
        assert_eq!(std::mem::size_of::<FrameUniform>(), 64 + 16 * 4 + 64 * MAX_LIGHTS);
        assert_eq!(OBJECT_UNIFORM_SIZE, 176);
        assert_eq!(std::mem::size_of::<RenderVertex>(), 32);
        assert_eq!(std::mem::size_of::<LineVertex>(), 28);
        assert_eq!(std::mem::size_of::<PointInstance>(), 32);
        assert_eq!(std::mem::size_of::<ScreenVertex>(), 24);
        assert_eq!(std::mem::align_of::<FrameUniform>(), 4);
    }

    #[test]
    fn matrix_multiplication_and_normal_matrix() {
        let t = [1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 5.0, 6.0, 7.0, 1.0];
        assert_eq!(mul4(&ID, &t), t);
        assert_eq!(mul4(&t, &ID), t);
        let scale = [2.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0];
        let (n, mirror) = normal_matrix(&scale);
        assert_eq!(mirror, 1.0);
        assert_eq!((n[0], n[5], n[10]), (1.0, 2.0, 2.0), "inverse transpose of diag(2,1,1), up to scale");
        let flip = [-1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0];
        let (n, mirror) = normal_matrix(&flip);
        assert_eq!(mirror, -1.0);
        assert_eq!(n[0], -1.0, "mirrored x axis keeps pointing outwards after the sign fix");
    }

    #[test]
    fn opaque_submeshes_get_one_slot_each() {
        let t = table_with(1, vec![SubMesh { first_index: 0, index_count: 30, material: 0 }, SubMesh { first_index: 30, index_count: 6, material: 1 }], 24);
        let mut f = RenderFrame::empty(100, 50);
        let mut it = item(1, 0.0);
        it.materials = vec![MaterialData::default(), MaterialData { base_color: [1.0, 0.0, 0.0, 1.0], metallic: 0.5, roughness: 0.25, emissive: [0.1, 0.2, 0.3] }];
        f.items.push(it);
        let plan = build_plan(&f, &t, &params());
        assert_eq!(plan.opaque.len(), 2);
        assert_eq!(plan.objects.len(), 2);
        assert_eq!((plan.opaque[1].slot, plan.opaque[1].first_index, plan.opaque[1].index_count), (1, 30, 6));
        assert_eq!(plan.objects[1].base_color, [1.0, 0.0, 0.0, 1.0]);
        assert_eq!(plan.objects[1].params[..2], [0.5, 0.25]);
        assert_eq!(plan.objects[1].emissive[..3], [0.1, 0.2, 0.3]);
        assert!(plan.wires.is_empty() && plan.blended.is_empty());
    }

    #[test]
    fn unknown_meshes_are_skipped() {
        let t = table_with(1, vec![SubMesh { first_index: 0, index_count: 3, material: 0 }], 0);
        let mut f = RenderFrame::empty(10, 10);
        f.items.push(item(99, 0.0));
        let plan = build_plan(&f, &t, &params());
        assert!(plan.opaque.is_empty() && plan.objects.is_empty());
    }

    #[test]
    fn transparent_items_sort_back_to_front() {
        let t = table_with(1, vec![SubMesh { first_index: 0, index_count: 3, material: 0 }], 0);
        let mut f = RenderFrame::empty(10, 10);
        f.eye = [0.0, 0.0, 0.0];
        for (i, z) in [2.0f32, 9.0, 5.0].into_iter().enumerate() {
            let mut it = item(1, z);
            it.xray = true;
            it.materials[0].base_color[0] = i as f32 * 0.1;
            f.items.push(it);
        }
        let plan = build_plan(&f, &t, &params());
        assert!(plan.opaque.is_empty());
        let order: Vec<f32> = plan.blended.iter().map(|d| plan.objects[d.slot as usize].model[14]).collect();
        assert_eq!(order, vec![9.0, 5.0, 2.0]);
        assert!(plan.objects.iter().all(|o| o.base_color[3] <= XRAY_ALPHA + 1e-6));
    }

    #[test]
    fn alpha_materials_are_blended_without_xray() {
        let t = table_with(1, vec![SubMesh { first_index: 0, index_count: 3, material: 0 }], 0);
        let mut f = RenderFrame::empty(10, 10);
        let mut it = item(1, 0.0);
        it.materials[0].base_color[3] = 0.5;
        f.items.push(it);
        let plan = build_plan(&f, &t, &params());
        assert_eq!((plan.opaque.len(), plan.blended.len()), (0, 1));
        assert_eq!(plan.objects[0].base_color[3], 0.5);
    }

    #[test]
    fn selection_outline_and_wire_overlay_colours() {
        let t = table_with(1, vec![SubMesh { first_index: 0, index_count: 3, material: 0 }], 24);
        let mut f = RenderFrame::empty(10, 10);
        let mut a = item(1, 0.0);
        a.selected = true;
        a.active = true;
        let mut s = item(1, 1.0);
        s.selected = true;
        let mut o = item(1, 2.0);
        o.wire = WireMode::Overlay;
        let plain = item(1, 3.0);
        f.items.extend([a, s, o, plain]);
        let plan = build_plan(&f, &t, &params());
        assert_eq!(plan.wires.len(), 3);
        let colors: Vec<[f32; 4]> = plan.wires.iter().map(|w| plan.objects[w.slot as usize].base_color).collect();
        assert_eq!(colors, vec![WIRE_ACTIVE, WIRE_SELECTED, WIRE_OVERLAY]);
        assert_eq!(plan.objects[0].params[2], 2.0, "active state flag");
        assert_eq!(plan.objects[2].params[2], 1.0, "selected (not active) state flag");
    }

    #[test]
    fn dense_meshes_skip_the_edge_outline_but_keep_the_tint() {
        let t = table_with(1, vec![SubMesh { first_index: 0, index_count: 3, material: 0 }], 2_000_000);
        let mut f = RenderFrame::empty(10, 10);
        let mut a = item(1, 0.0);
        a.selected = true;
        f.items.push(a);
        let plan = build_plan(&f, &t, &params());
        assert!(plan.wires.is_empty());
        assert_eq!(plan.objects[0].params[2], 1.0);
    }

    #[test]
    fn wireframe_shading_draws_only_edges() {
        let t = table_with(1, vec![SubMesh { first_index: 0, index_count: 3, material: 0 }], 12);
        let mut f = RenderFrame::empty(10, 10);
        f.shading = ShadingMode::Wireframe;
        f.items.push(item(1, 0.0));
        let plan = build_plan(&f, &t, &params());
        assert!(plan.opaque.is_empty() && plan.blended.is_empty());
        assert_eq!(plan.wires.len(), 1);
        assert_eq!(plan.objects[0].base_color, WIRE_ONLY);
        assert_eq!(plan.frame.flags[0], 1.0);
    }

    #[test]
    fn slot_budget_is_respected() {
        let t = table_with(1, vec![SubMesh { first_index: 0, index_count: 3, material: 0 }], 0);
        let mut f = RenderFrame::empty(10, 10);
        for i in 0..10 {
            f.items.push(item(1, i as f32));
        }
        let plan = build_plan(&f, &t, &PlanParams { srgb_encode: false, max_slots: 4 });
        assert_eq!((plan.objects.len(), plan.opaque.len(), plan.dropped), (4, 4, 6));
    }

    #[test]
    fn lights_and_flags_are_packed() {
        let mut f = RenderFrame::empty(200, 100);
        f.shading = ShadingMode::Material;
        for i in 0..12 {
            f.lights.push(LightData { kind: if i == 0 { LightKind::Sun } else { LightKind::Spot }, position: [1.0, 2.0, 3.0], direction: [0.0, 0.0, -1.0], color: [1.0, 0.5, 0.25], intensity: 2.0, spot_cos: [0.9, 0.8] });
        }
        let u = frame_uniform(&f, true);
        assert_eq!(u.flags, [2.0, MAX_LIGHTS as f32, 1.0, 0.0]);
        assert_eq!(u.lights[0].position_kind, [1.0, 2.0, 3.0, 0.0]);
        assert_eq!(u.lights[1].position_kind[3], 2.0);
        assert_eq!(u.lights[1].color_intensity, [1.0, 0.5, 0.25, 2.0]);
        assert_eq!(u.lights[1].spot[..2], [0.9, 0.8]);
        assert_eq!(u.viewport, [200.0, 100.0, 0.005, 0.01]);
        let c = clear_color(&f, true);
        assert!(c[0] > f.clear_color[0] as f64, "encoded when the swapchain is linear");
        assert_eq!(clear_color(&f, false)[0], f.clear_color[0] as f64);
    }

    #[test]
    fn msaa_and_target_size_decisions() {
        assert_eq!(choose_msaa(4, true), 4);
        assert_eq!(choose_msaa(4, false), 1);
        assert_eq!(choose_msaa(1, true), 1);
        assert_eq!(target_size(1080, 2400, 1.0), (1080, 2400));
        assert_eq!(target_size(1080, 2400, 0.5), (540, 1200));
        assert_eq!(target_size(1, 1, 0.5), (1, 1));
        assert_eq!(target_size(100, 100, f32::NAN), (100, 100));
        assert_eq!(target_size(100, 100, 0.01), (25, 25));
    }
}
