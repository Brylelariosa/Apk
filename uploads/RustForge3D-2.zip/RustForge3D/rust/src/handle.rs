//! The native handle given to Kotlin: an id into a registry of live instances. A stale, zero or
//! double-destroyed handle is simply not found, so it can never dereference freed memory.
use crate::render::RenderThread;
use forge_engine::Engine;
use std::collections::HashMap;
use std::sync::atomic::{AtomicI64, Ordering};
use std::sync::{Arc, Mutex, MutexGuard, OnceLock};

pub struct Native {
    engine: Arc<Mutex<Engine>>,
    pub render: RenderThread,
    last_error: Mutex<String>,
}

impl Native {
    pub fn new(files_dir: &str, density: f32) -> Native {
        let engine = Engine::new(files_dir, density);
        let redraw = engine.redraw_signal();
        let engine = Arc::new(Mutex::new(engine));
        let render = RenderThread::spawn(engine.clone(), redraw);
        Native { engine, render, last_error: Mutex::new(String::new()) }
    }

    /// The engine, recovering from a poisoned lock (a panic inside a call must not brick the app).
    pub fn engine(&self) -> MutexGuard<'_, Engine> {
        self.engine.lock().unwrap_or_else(|e| e.into_inner())
    }

    pub fn set_error(&self, msg: impl Into<String>) {
        *self.last_error.lock().unwrap_or_else(|e| e.into_inner()) = msg.into();
    }

    pub fn last_error(&self) -> String {
        let own = self.last_error.lock().unwrap_or_else(|e| e.into_inner()).clone();
        if own.is_empty() {
            self.engine().last_error().to_string()
        } else {
            own
        }
    }

    /// Starts rendering into a window and tells the engine the viewport size.
    pub fn attach(&self, window: crate::android::WindowPtr, width: u32, height: u32) -> Result<(), String> {
        self.engine().set_viewport(width, height);
        let backend = self.render.attach(window, width, height)?;
        log::info!("rendering with {backend}");
        self.set_error(String::new());
        Ok(())
    }
}

fn registry() -> &'static Mutex<HashMap<i64, Arc<Native>>> {
    static REG: OnceLock<Mutex<HashMap<i64, Arc<Native>>>> = OnceLock::new();
    REG.get_or_init(|| Mutex::new(HashMap::new()))
}

static NEXT_HANDLE: AtomicI64 = AtomicI64::new(1);

pub fn register(native: Native) -> i64 {
    let id = NEXT_HANDLE.fetch_add(1, Ordering::Relaxed);
    registry().lock().unwrap_or_else(|e| e.into_inner()).insert(id, Arc::new(native));
    id
}

pub fn get(handle: i64) -> Option<Arc<Native>> {
    registry().lock().unwrap_or_else(|e| e.into_inner()).get(&handle).cloned()
}

pub fn remove(handle: i64) -> Option<Arc<Native>> {
    registry().lock().unwrap_or_else(|e| e.into_inner()).remove(&handle)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp() -> String {
        let n = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
        std::env::temp_dir().join(format!("rf-handle-{n}")).to_string_lossy().to_string()
    }

    #[test]
    fn handles_are_validated_and_single_use() {
        assert!(get(0).is_none());
        assert!(get(-5).is_none());
        let h = register(Native::new(&temp(), 2.0));
        assert!(h > 0);
        let n = get(h).expect("registered");
        let r = n.engine().call("view.set", r#"{"grid":false}"#);
        assert!(r.contains("\"ok\":true"), "{r}");
        assert!(remove(h).is_some());
        assert!(get(h).is_none());
        assert!(remove(h).is_none(), "double destroy is harmless");
        drop(n);
    }

    #[test]
    fn attach_without_a_window_fails_cleanly() {
        let native = Native::new(&temp(), 1.0);
        let err = native.attach(crate::android::window_from_surface(std::ptr::null_mut(), std::ptr::null_mut()), 100, 100);
        assert!(err.is_err());
    }
}
