//! Extrude and inset. All variants share one core that duplicates the vertices on the outline of the selected
//! faces, repoints the faces to the duplicates (the "cap") and joins old and new outline with side quads.
use crate::poly::Work;
use forge_math::{Vec2, Vec3};
use forge_mesh::{GeomError, GeomResult, Mesh, OpCtx, OpOutput, Selection, Topology, NONE};
use std::collections::HashMap;

fn invalid<T>(msg: &str) -> GeomResult<T> {
    Err(GeomError::InvalidInput(msg.to_string()))
}

#[derive(Clone, Copy, Debug)]
pub struct InsetOpts {
    /// Width of the border ring (negative = outset).
    pub thickness: f32,
    /// Raise (+) or lower (-) the inset faces along their normals.
    pub depth: f32,
    /// Inset every selected face on its own instead of the outline of the whole region.
    pub individual: bool,
    /// Also inset along the open boundary of the mesh.
    pub boundary: bool,
    /// Keep the border width constant around corners.
    pub even_offset: bool,
}

impl Default for InsetOpts {
    fn default() -> Self {
        InsetOpts { thickness: 0.1, depth: 0.0, individual: false, boundary: true, even_offset: true }
    }
}

struct Core {
    w: Work,
    dups: Vec<u32>,
    sides: Vec<u32>,
    /// (duplicated vertex, inward direction in the plane of the face) per outline edge end.
    inward: Vec<(u32, Vec3)>,
    /// (cap vertex, face normal) per cap corner.
    normals: Vec<(u32, Vec3)>,
    cap_verts: Vec<u32>,
}

fn dup_vertex(w: &mut Work, dup_of: &mut [u32], created: &mut Vec<u32>, v: u32) -> u32 {
    if dup_of[v as usize] == NONE {
        let d = w.vert(w.pos[v as usize]);
        dup_of[v as usize] = d;
        created.push(d);
    }
    dup_of[v as usize]
}

fn extrude_faces_core(mesh: &Mesh, fm: &[bool], individual: bool, boundary: bool, track: bool, ctx: &OpCtx) -> GeomResult<Core> {
    ctx.check()?;
    let topo = Topology::build(mesh);
    let (nv, nf) = (mesh.vert_count(), mesh.face_count());
    let mut sc = vec![0u32; topo.edges.len()];
    let mut sel_corners = 0usize;
    for f in 0..nf {
        if !fm[f] {
            continue;
        }
        sel_corners += mesh.face_len(f);
        for &e in topo.face_edges(mesh, f) {
            if e != NONE {
                sc[e as usize] += 1;
            }
        }
    }
    if sel_corners == 0 {
        return invalid("no faces selected");
    }
    ctx.ensure_capacity(nv + sel_corners, nf + sel_corners)?;
    let bound = |e: u32| -> bool {
        if e == NONE {
            return false;
        }
        let (s, c) = (sc[e as usize], topo.edge_face_count[e as usize]);
        s > 0 && (individual || s < c || (c == 1 && boundary))
    };
    let mut w = Work::from_mesh(mesh);
    let has_uv = w.has_uv;
    let mut dup_of = vec![NONE; nv];
    let mut created: Vec<u32> = Vec::new();
    let mut dups: Vec<u32> = Vec::new();
    if !individual {
        for f in 0..nf {
            if !fm[f] {
                continue;
            }
            let vs = mesh.face_verts(f);
            let es = topo.face_edges(mesh, f);
            for i in 0..vs.len() {
                if bound(es[i]) {
                    for v in [vs[i], vs[(i + 1) % vs.len()]] {
                        dup_vertex(&mut w, &mut dup_of, &mut created, v);
                    }
                }
            }
        }
        dups.extend_from_slice(&created);
    }
    let mut sides = Vec::new();
    let mut inward = Vec::new();
    let mut normals = Vec::new();
    let mut cap_verts: Vec<u32> = Vec::new();
    for f in 0..nf {
        ctx.poll(f)?;
        if !fm[f] {
            continue;
        }
        let vs: Vec<u32> = mesh.face_verts(f).to_vec();
        let es: Vec<u32> = topo.face_edges(mesh, f).to_vec();
        let n = vs.len();
        let nrm = mesh.face_normal(f);
        let cap: Vec<u32> = if individual {
            (0..n)
                .map(|k| {
                    let d = w.vert(mesh.positions[vs[k] as usize]);
                    dups.push(d);
                    d
                })
                .collect()
        } else {
            vs.iter().map(|&v| if dup_of[v as usize] != NONE { dup_of[v as usize] } else { v }).collect()
        };
        let (mat, smooth) = (w.polys[f].mat, w.polys[f].smooth);
        for i in 0..n {
            if !bound(es[i]) {
                continue;
            }
            let j = (i + 1) % n;
            let (a, b) = (vs[i], vs[j]);
            let (ad, bd) = (cap[i], cap[j]);
            let uv = if has_uv {
                let u = &w.polys[f].uv;
                vec![u[j], u[i], u[i], u[j]]
            } else {
                Vec::new()
            };
            sides.push(w.push(vec![bd, ad, a, b], mat, smooth, uv));
            if track {
                let d = (mesh.positions[b as usize] - mesh.positions[a as usize]).normalize();
                let inw = nrm.cross(d).normalize();
                inward.push((ad, inw));
                inward.push((bd, inw));
            }
        }
        if track {
            for &c in &cap {
                normals.push((c, nrm));
            }
        }
        cap_verts.extend_from_slice(&cap);
        w.polys[f].v = cap;
    }
    Ok(Core { w, dups, sides, inward, normals, cap_verts })
}

fn finish(core: Core) -> (Mesh, OpOutput) {
    let Core { w, dups, sides, cap_verts, .. } = core;
    let mesh = w.into_mesh();
    let mut selection = Selection::none(mesh.vert_count());
    for &v in &cap_verts {
        selection.set(v, true);
    }
    let out = OpOutput { selection, new_verts: dups, new_faces: sides, ..Default::default() };
    (mesh, out)
}

/// Extrude the selected faces as one region (interior edges stay, the outline gets side walls).
pub fn extrude_faces(mesh: &Mesh, sel: &Selection, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    let fm = sel.face_mask(mesh);
    Ok(finish(extrude_faces_core(mesh, &fm, false, true, false, ctx)?))
}

/// Extrude every selected face on its own.
pub fn extrude_individual_faces(mesh: &Mesh, sel: &Selection, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    let fm = sel.face_mask(mesh);
    Ok(finish(extrude_faces_core(mesh, &fm, true, true, false, ctx)?))
}

/// Extrude selected edges into new quads (a single edge becomes a flap, a loose edge a loose quad).
pub fn extrude_edges(mesh: &Mesh, sel: &Selection, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    let topo = Topology::build(mesh);
    let em = sel.edge_mask(&topo);
    let chosen: Vec<usize> = (0..topo.edges.len()).filter(|&e| em[e]).collect();
    if chosen.is_empty() {
        return invalid("no edges selected");
    }
    let nv = mesh.vert_count();
    ctx.ensure_capacity(nv + 2 * chosen.len(), mesh.face_count() + chosen.len())?;
    let mut w = Work::from_mesh(mesh);
    let has_uv = w.has_uv;
    let mut dup_of = vec![NONE; nv];
    let mut new_verts = Vec::new();
    let mut new_faces = Vec::new();
    for &e in &chosen {
        ctx.poll(e)?;
        let [lo, hi] = topo.edges[e];
        let c = topo.edge_corner[e];
        let (a, b, attrs) = if c != NONE {
            let f = topo.face_of_corner[c as usize] as usize;
            let r = mesh.face_range(f);
            let k = c as usize - r.start;
            (mesh.corners[c as usize], mesh.corners[r.start + (k + 1) % r.len()], Some((mesh.face_material[f], mesh.face_smooth[f])))
        } else {
            (lo, hi, None)
        };
        let ad = dup_vertex(&mut w, &mut dup_of, &mut new_verts, a);
        let bd = dup_vertex(&mut w, &mut dup_of, &mut new_verts, b);
        let (mat, smooth) = attrs.unwrap_or((0, false));
        let verts = if attrs.is_some() { vec![b, a, ad, bd] } else { vec![a, b, bd, ad] };
        let uv = if has_uv { vec![Vec2::ZERO; 4] } else { Vec::new() };
        new_faces.push(w.push(verts, mat, smooth, uv));
    }
    w.drop_covered_loose();
    let out_mesh = w.into_mesh();
    let mut selection = Selection::none(out_mesh.vert_count());
    for &v in &new_verts {
        selection.set(v, true);
    }
    Ok((out_mesh, OpOutput { selection, new_verts, new_faces, ..Default::default() }))
}

/// Extrude selected vertices into new vertices joined by a loose edge.
pub fn extrude_verts(mesh: &Mesh, sel: &Selection, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    let picked = sel.indices();
    if picked.is_empty() {
        return invalid("no vertices selected");
    }
    ctx.ensure_capacity(mesh.vert_count() + picked.len(), mesh.face_count())?;
    let mut w = Work::from_mesh(mesh);
    let mut new_verts = Vec::with_capacity(picked.len());
    for &v in &picked {
        let d = w.vert(mesh.positions[v as usize]);
        w.loose.push([v, d]);
        new_verts.push(d);
    }
    let out_mesh = w.into_mesh();
    let mut selection = Selection::none(out_mesh.vert_count());
    for &v in &new_verts {
        selection.set(v, true);
    }
    Ok((out_mesh, OpOutput { selection, new_verts, ..Default::default() }))
}

/// "Extrude region": faces if any are selected, otherwise edges, otherwise vertices.
pub fn extrude_region(mesh: &Mesh, sel: &Selection, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    if sel.face_mask(mesh).iter().any(|&b| b) {
        return extrude_faces(mesh, sel, ctx);
    }
    let topo = Topology::build(mesh);
    if sel.edge_mask(&topo).iter().any(|&b| b) {
        return extrude_edges(mesh, sel, ctx);
    }
    extrude_verts(mesh, sel, ctx)
}

fn miter(dirs: &[Vec3], t: f32, even: bool) -> Vec3 {
    match dirs.len() {
        0 => Vec3::ZERO,
        1 => dirs[0] * t,
        2 => {
            let s = dirs[0] + dirs[1];
            if even {
                s * (t / (1.0 + dirs[0].dot(dirs[1])).max(0.1))
            } else {
                s.normalize() * t
            }
        }
        _ => dirs.iter().fold(Vec3::ZERO, |a, d| a + *d).normalize() * t,
    }
}

/// Inset the selected faces: a ring of new faces of width `thickness` is created along the outline.
pub fn inset(mesh: &Mesh, sel: &Selection, opts: &InsetOpts, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    if !opts.thickness.is_finite() || !opts.depth.is_finite() {
        return invalid("inset values must be finite");
    }
    let fm = sel.face_mask(mesh);
    let mut core = extrude_faces_core(mesh, &fm, opts.individual, opts.boundary, true, ctx)?;
    let mut inward = std::mem::take(&mut core.inward);
    inward.sort_by_key(|x| x.0);
    let mut i = 0;
    while i < inward.len() {
        let v = inward[i].0;
        let mut dirs: Vec<Vec3> = Vec::new();
        let mut j = i;
        while j < inward.len() && inward[j].0 == v {
            dirs.push(inward[j].1);
            j += 1;
        }
        let off = miter(&dirs, opts.thickness, opts.even_offset);
        core.w.pos[v as usize] = core.w.pos[v as usize] + off;
        i = j;
    }
    if opts.depth != 0.0 {
        let mut acc: HashMap<u32, Vec3> = HashMap::new();
        for &(v, n) in &core.normals {
            let e = acc.entry(v).or_insert(Vec3::ZERO);
            *e = *e + n;
        }
        for (v, n) in acc {
            core.w.pos[v as usize] = core.w.pos[v as usize] + n.normalize() * opts.depth;
        }
    }
    Ok(finish(core))
}
