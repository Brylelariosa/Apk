//! forge-geom: primitives and mesh editing operations on `forge_mesh::Mesh`.
//!
//! Every operation is functional (`&Mesh` in, new `Mesh` out) and reports what it did through
//! [`forge_mesh::OpOutput`] (new selection, created elements, index maps) so that callers (UI tools, Python
//! `bmesh`) can keep handles valid. All operations are bounded by `OpCtx` limits and never panic on odd meshes.
//!
//! Selection semantics: vertex flags only (see `forge_mesh::Selection`): a face is selected when all its vertices
//! are, an edge when both end vertices are.
#![forbid(unsafe_code)]

pub mod editing;
pub mod extrude;
pub mod misc;
pub mod primitives;
pub mod subdivide;

mod poly;

#[cfg(test)]
mod tests;

pub use editing::{delete, dissolve_edges, dissolve_faces, dissolve_verts, duplicate, fill, join, merge, remove_doubles, separate, DeleteMode, MergeMode};
pub use extrude::{extrude_edges, extrude_faces, extrude_individual_faces, extrude_region, extrude_verts, inset, InsetOpts};
pub use misc::{
    edge_loop, edge_ring, flip_normals, mirror, recalc_normals, select_boundary, select_loose, select_non_manifold, select_random, set_smooth,
    smooth_vertices, transform_selection, triangulate, MirrorOpts,
};
pub use primitives::{circle, cone, cube, cylinder, grid, ico_sphere, plane, torus, uv_sphere, CapFill};
pub use subdivide::{loop_cut, subdivide, subsurf};
