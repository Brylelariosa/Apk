//! Mesh primitives with Blender's conventions: Z up, counter-clockwise outward faces, flat shaded.
//! Vertex/edge/face counts equal Blender's for the same parameters.
use forge_math::{Vec2, Vec3};
use forge_mesh::{GeomError, GeomResult, Mesh, OpCtx};
use std::collections::HashMap;
use std::f32::consts::{PI, TAU};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CapFill {
    NGon,
    TriFan,
    Nothing,
}

struct B {
    m: Mesh,
    uv: bool,
}

impl B {
    fn new(uv: bool) -> B {
        B { m: Mesh::new(), uv }
    }
    fn v(&mut self, x: f32, y: f32, z: f32) -> u32 {
        self.m.add_vertex(Vec3::new(x, y, z))
    }
    fn f(&mut self, verts: &[u32], uvs: &[[f32; 2]]) {
        self.m.corners.extend_from_slice(verts);
        self.m.face_starts.push(self.m.corners.len() as u32);
        self.m.face_material.push(0);
        self.m.face_smooth.push(false);
        if self.uv {
            self.m.uvs.extend(uvs.iter().map(|u| Vec2::new(u[0], u[1])));
        }
    }
}

fn need(cond: bool, msg: &str) -> GeomResult<()> {
    if cond {
        Ok(())
    } else {
        Err(GeomError::InvalidInput(msg.to_string()))
    }
}

/// Cube with edge length `size` (Blender default 2). Cross-layout UVs.
pub fn cube(size: f32, uvs: bool) -> Mesh {
    let h = size * 0.5;
    let mut b = B::new(uvs);
    for i in 0..8u32 {
        b.v(if i & 1 != 0 { h } else { -h }, if i & 2 != 0 { h } else { -h }, if i & 4 != 0 { h } else { -h });
    }
    // (face verts, uv cell column, uv cell row) in a 4x3 cross layout
    let faces: [([u32; 4], f32, f32); 6] = [
        ([1, 3, 7, 5], 2.0, 1.0),
        ([0, 4, 6, 2], 0.0, 1.0),
        ([2, 6, 7, 3], 3.0, 1.0),
        ([0, 1, 5, 4], 1.0, 1.0),
        ([4, 5, 7, 6], 1.0, 2.0),
        ([0, 2, 3, 1], 1.0, 0.0),
    ];
    for (v, cx, cy) in faces {
        let (u0, v0) = (cx / 4.0, cy / 3.0);
        let (u1, v1) = (u0 + 0.25, v0 + 1.0 / 3.0);
        b.f(&v, &[[u0, v0], [u1, v0], [u1, v1], [u0, v1]]);
    }
    b.m
}

/// Square in the XY plane with edge length `size` (Blender default 2).
pub fn plane(size: f32, uvs: bool) -> Mesh {
    let h = size * 0.5;
    let mut b = B::new(uvs);
    for (x, y) in [(-h, -h), (h, -h), (h, h), (-h, h)] {
        b.v(x, y, 0.0);
    }
    b.f(&[0, 1, 2, 3], &[[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]);
    b.m
}

/// Flat grid of `x_div` x `y_div` quads spanning `size` x `size`.
pub fn grid(x_div: u32, y_div: u32, size: f32, uvs: bool, ctx: &OpCtx) -> GeomResult<Mesh> {
    need(x_div >= 1 && y_div >= 1, "grid needs at least 1 subdivision per axis")?;
    let (nx, ny) = (x_div as usize, y_div as usize);
    ctx.ensure_capacity((nx + 1) * (ny + 1), nx * ny)?;
    let mut b = B::new(uvs);
    for j in 0..=ny {
        for i in 0..=nx {
            b.v((i as f32 / nx as f32 - 0.5) * size, (j as f32 / ny as f32 - 0.5) * size, 0.0);
        }
    }
    let at = |i: usize, j: usize| (j * (nx + 1) + i) as u32;
    for j in 0..ny {
        ctx.poll(j)?;
        for i in 0..nx {
            let (u0, u1, v0, v1) = (i as f32 / nx as f32, (i + 1) as f32 / nx as f32, j as f32 / ny as f32, (j + 1) as f32 / ny as f32);
            b.f(&[at(i, j), at(i + 1, j), at(i + 1, j + 1), at(i, j + 1)], &[[u0, v0], [u1, v0], [u1, v1], [u0, v1]]);
        }
    }
    Ok(b.m)
}

/// Circle in the XY plane. `Nothing` produces loose edges only.
pub fn circle(vertices: u32, radius: f32, fill: CapFill, uvs: bool, ctx: &OpCtx) -> GeomResult<Mesh> {
    need(vertices >= 3, "circle needs at least 3 vertices")?;
    let n = vertices as usize;
    ctx.ensure_capacity(n + 1, n)?;
    let mut b = B::new(uvs);
    let uv = |j: usize| [0.5 + 0.5 * (TAU * j as f32 / n as f32).cos(), 0.5 + 0.5 * (TAU * j as f32 / n as f32).sin()];
    for j in 0..n {
        let a = TAU * j as f32 / n as f32;
        b.v(radius * a.cos(), radius * a.sin(), 0.0);
    }
    match fill {
        CapFill::Nothing => {
            for j in 0..n {
                b.m.add_loose_edge(j as u32, ((j + 1) % n) as u32);
            }
        }
        CapFill::NGon => {
            let ids: Vec<u32> = (0..n as u32).collect();
            let uvl: Vec<[f32; 2]> = (0..n).map(uv).collect();
            b.f(&ids, &uvl);
        }
        CapFill::TriFan => {
            let c = b.v(0.0, 0.0, 0.0);
            for j in 0..n {
                let k = (j + 1) % n;
                b.f(&[c, j as u32, k as u32], &[[0.5, 0.5], uv(j), uv(k)]);
            }
        }
    }
    Ok(b.m)
}

/// UV sphere: `segments` around Z, `rings` from pole to pole; poles are triangle fans.
pub fn uv_sphere(segments: u32, rings: u32, radius: f32, uvs: bool, ctx: &OpCtx) -> GeomResult<Mesh> {
    need(segments >= 3 && rings >= 2, "uv sphere needs segments >= 3 and rings >= 2")?;
    let (s, r) = (segments as usize, rings as usize);
    ctx.ensure_capacity(s * (r - 1) + 2, s * r)?;
    let mut b = B::new(uvs);
    let top = b.v(0.0, 0.0, radius);
    for i in 1..r {
        ctx.poll(i)?;
        let phi = PI * i as f32 / r as f32;
        let (z, rr) = (radius * phi.cos(), radius * phi.sin());
        for j in 0..s {
            let t = TAU * j as f32 / s as f32;
            b.v(rr * t.cos(), rr * t.sin(), z);
        }
    }
    let bottom = b.v(0.0, 0.0, -radius);
    let at = |i: usize, j: usize| (1 + (i - 1) * s + j % s) as u32;
    let (fu, fv) = (|j: usize| j as f32 / s as f32, |i: usize| 1.0 - i as f32 / r as f32);
    for j in 0..s {
        b.f(&[top, at(1, j), at(1, j + 1)], &[[(j as f32 + 0.5) / s as f32, 1.0], [fu(j), fv(1)], [fu(j + 1), fv(1)]]);
    }
    for i in 1..r - 1 {
        for j in 0..s {
            b.f(&[at(i, j), at(i + 1, j), at(i + 1, j + 1), at(i, j + 1)], &[[fu(j), fv(i)], [fu(j), fv(i + 1)], [fu(j + 1), fv(i + 1)], [fu(j + 1), fv(i)]]);
        }
    }
    for j in 0..s {
        b.f(&[bottom, at(r - 1, j + 1), at(r - 1, j)], &[[(j as f32 + 0.5) / s as f32, 0.0], [fu(j + 1), fv(r - 1)], [fu(j), fv(r - 1)]]);
    }
    Ok(b.m)
}

/// Icosphere: `subdivisions = 1` is the icosahedron (12 verts / 20 faces), each further level quadruples the faces.
pub fn ico_sphere(subdivisions: u32, radius: f32, uvs: bool, ctx: &OpCtx) -> GeomResult<Mesh> {
    need((1..=10).contains(&subdivisions), "ico sphere subdivisions must be between 1 and 10")?;
    let faces_out = 20usize << (2 * (subdivisions as usize - 1));
    ctx.ensure_capacity(faces_out / 2 + 2, faces_out)?;
    let mut pos: Vec<Vec3> = vec![Vec3::new(0.0, 0.0, 1.0)];
    let (zr, rr) = (1.0 / 5f32.sqrt(), 2.0 / 5f32.sqrt());
    for k in 0..5 {
        let a = TAU * k as f32 / 5.0;
        pos.push(Vec3::new(rr * a.cos(), rr * a.sin(), zr));
    }
    for k in 0..5 {
        let a = TAU * k as f32 / 5.0 + PI / 5.0;
        pos.push(Vec3::new(rr * a.cos(), rr * a.sin(), -zr));
    }
    pos.push(Vec3::new(0.0, 0.0, -1.0));
    let mut tris: Vec<[u32; 3]> = Vec::new();
    for k in 0..5u32 {
        let k2 = (k + 1) % 5;
        tris.push([0, 1 + k, 1 + k2]);
        tris.push([1 + k, 6 + k, 1 + k2]);
        tris.push([6 + k, 6 + k2, 1 + k2]);
        tris.push([11, 6 + k2, 6 + k]);
    }
    for _ in 1..subdivisions {
        ctx.check()?;
        let mut cache: HashMap<(u32, u32), u32> = HashMap::new();
        let mut mid = |a: u32, c: u32, pos: &mut Vec<Vec3>| -> u32 {
            let key = (a.min(c), a.max(c));
            *cache.entry(key).or_insert_with(|| {
                pos.push(((pos[a as usize] + pos[c as usize]) * 0.5).normalize());
                (pos.len() - 1) as u32
            })
        };
        let mut next = Vec::with_capacity(tris.len() * 4);
        for t in &tris {
            let (a, c, d) = (mid(t[0], t[1], &mut pos), mid(t[1], t[2], &mut pos), mid(t[2], t[0], &mut pos));
            next.extend_from_slice(&[[t[0], a, d], [a, t[1], c], [d, c, t[2]], [a, c, d]]);
        }
        tris = next;
    }
    let mut b = B::new(uvs);
    for p in &pos {
        b.v(p.x * radius, p.y * radius, p.z * radius);
    }
    for t in &tris {
        let uv: Vec<[f32; 2]> = t
            .iter()
            .map(|&i| {
                let p = pos[i as usize];
                [0.5 + p.y.atan2(p.x) / TAU, 0.5 + p.z.clamp(-1.0, 1.0).asin() / PI]
            })
            .collect();
        let mut uv = uv;
        let (lo, hi) = (uv.iter().map(|u| u[0]).fold(f32::MAX, f32::min), uv.iter().map(|u| u[0]).fold(f32::MIN, f32::max));
        if hi - lo > 0.5 {
            for u in uv.iter_mut().filter(|u| u[0] < 0.5) {
                u[0] += 1.0;
            }
        }
        b.f(t, &uv);
    }
    Ok(b.m)
}

/// Cone / cylinder frustum along Z: `radius1` at the bottom (`-depth/2`), `radius2` at the top. A zero radius
/// collapses that end to a single apex vertex.
pub fn cone(vertices: u32, radius1: f32, radius2: f32, depth: f32, cap: CapFill, uvs: bool, ctx: &OpCtx) -> GeomResult<Mesh> {
    need(vertices >= 3, "cone/cylinder needs at least 3 vertices")?;
    let n = vertices as usize;
    ctx.ensure_capacity(2 * n + 2, 3 * n + 2)?;
    let mut b = B::new(uvs);
    let h = depth * 0.5;
    let ring = |b: &mut B, r: f32, z: f32| -> Vec<u32> { (0..n).map(|j| b.v(r * (TAU * j as f32 / n as f32).cos(), r * (TAU * j as f32 / n as f32).sin(), z)).collect() };
    let apex_b = radius1 == 0.0;
    let apex_t = radius2 == 0.0;
    let bot = if apex_b { vec![b.v(0.0, 0.0, -h)] } else { ring(&mut b, radius1, -h) };
    let top = if apex_t { vec![b.v(0.0, 0.0, h)] } else { ring(&mut b, radius2, h) };
    let (bi, ti) = (|j: usize| bot[if apex_b { 0 } else { j % n }], |j: usize| top[if apex_t { 0 } else { j % n }]);
    let u = |j: usize| j as f32 / n as f32;
    for j in 0..n {
        let (a, c, d, e) = (bi(j), bi(j + 1), ti(j + 1), ti(j));
        if apex_b && apex_t {
            continue;
        } else if apex_t {
            b.f(&[a, c, e], &[[u(j), 0.0], [u(j + 1), 0.0], [u(j) + 0.5 / n as f32, 1.0]]);
        } else if apex_b {
            b.f(&[a, d, e], &[[u(j) + 0.5 / n as f32, 0.0], [u(j + 1), 1.0], [u(j), 1.0]]);
        } else {
            b.f(&[a, c, d, e], &[[u(j), 0.0], [u(j + 1), 0.0], [u(j + 1), 1.0], [u(j), 1.0]]);
        }
    }
    let disc = |j: usize, flip: f32| [0.5 + 0.5 * (TAU * j as f32 / n as f32).cos(), 0.5 + 0.5 * flip * (TAU * j as f32 / n as f32).sin()];
    let cap_end = |b: &mut B, ids: &Vec<u32>, apex: bool, z: f32, up: bool| {
        if apex || cap == CapFill::Nothing {
            return;
        }
        match cap {
            CapFill::NGon => {
                let order: Vec<usize> = if up { (0..n).collect() } else { (0..n).rev().collect() };
                let v: Vec<u32> = order.iter().map(|&j| ids[j]).collect();
                let uv: Vec<[f32; 2]> = order.iter().map(|&j| disc(j, 1.0)).collect();
                b.f(&v, &uv);
            }
            _ => {
                let c = b.v(0.0, 0.0, z);
                for j in 0..n {
                    let k = (j + 1) % n;
                    if up {
                        b.f(&[c, ids[j], ids[k]], &[[0.5, 0.5], disc(j, 1.0), disc(k, 1.0)]);
                    } else {
                        b.f(&[c, ids[k], ids[j]], &[[0.5, 0.5], disc(k, 1.0), disc(j, 1.0)]);
                    }
                }
            }
        }
    };
    cap_end(&mut b, &bot, apex_b, -h, false);
    cap_end(&mut b, &top, apex_t, h, true);
    Ok(b.m)
}

/// Cylinder along Z (`cone` with equal radii).
pub fn cylinder(vertices: u32, radius: f32, depth: f32, cap: CapFill, uvs: bool, ctx: &OpCtx) -> GeomResult<Mesh> {
    cone(vertices, radius, radius, depth, cap, uvs, ctx)
}

/// Torus around Z.
pub fn torus(major_segments: u32, minor_segments: u32, major_radius: f32, minor_radius: f32, uvs: bool, ctx: &OpCtx) -> GeomResult<Mesh> {
    need(major_segments >= 3 && minor_segments >= 3, "torus needs at least 3 segments in both directions")?;
    let (m, n) = (major_segments as usize, minor_segments as usize);
    ctx.ensure_capacity(m * n, m * n)?;
    let mut b = B::new(uvs);
    for i in 0..m {
        let a = TAU * i as f32 / m as f32;
        for j in 0..n {
            let t = TAU * j as f32 / n as f32;
            let r = major_radius + minor_radius * t.cos();
            b.v(r * a.cos(), r * a.sin(), minor_radius * t.sin());
        }
    }
    let at = |i: usize, j: usize| ((i % m) * n + j % n) as u32;
    for i in 0..m {
        ctx.poll(i)?;
        for j in 0..n {
            let (u0, u1, v0, v1) = (i as f32 / m as f32, (i + 1) as f32 / m as f32, j as f32 / n as f32, (j + 1) as f32 / n as f32);
            b.f(&[at(i, j), at(i + 1, j), at(i + 1, j + 1), at(i, j + 1)], &[[u0, v0], [u1, v0], [u1, v1], [u0, v1]]);
        }
    }
    Ok(b.m)
}

#[cfg(test)]
mod tests {
    use super::*;
    use forge_mesh::validate;

    fn counts(m: &Mesh) -> (usize, usize, usize) {
        (m.vert_count(), m.edge_count(), m.face_count())
    }

    #[test]
    fn blender_counts() {
        let c = OpCtx::new();
        assert_eq!(counts(&cube(2.0, true)), (8, 12, 6));
        assert_eq!(counts(&plane(2.0, true)), (4, 4, 1));
        assert_eq!(counts(&uv_sphere(32, 16, 1.0, true, &c).unwrap()), (482, 992, 512));
        assert_eq!(counts(&ico_sphere(1, 1.0, true, &c).unwrap()), (12, 30, 20));
        assert_eq!(counts(&ico_sphere(2, 1.0, true, &c).unwrap()), (42, 120, 80));
        assert_eq!(counts(&ico_sphere(3, 1.0, true, &c).unwrap()), (162, 480, 320));
        assert_eq!(counts(&cylinder(32, 1.0, 2.0, CapFill::NGon, true, &c).unwrap()), (64, 96, 34));
        assert_eq!(counts(&cylinder(32, 1.0, 2.0, CapFill::TriFan, true, &c).unwrap()), (66, 160, 96));
        assert_eq!(counts(&cone(32, 1.0, 0.0, 2.0, CapFill::NGon, true, &c).unwrap()), (33, 64, 33));
        assert_eq!(counts(&torus(48, 12, 1.0, 0.25, true, &c).unwrap()), (576, 1152, 576));
        assert_eq!(counts(&grid(10, 10, 2.0, true, &c).unwrap()), (121, 220, 100));
        assert_eq!(counts(&circle(32, 1.0, CapFill::NGon, true, &c).unwrap()), (32, 32, 1));
    }

    #[test]
    fn closed_and_outward() {
        let c = OpCtx::new();
        let list = vec![
            cube(2.0, true),
            uv_sphere(16, 8, 1.0, true, &c).unwrap(),
            ico_sphere(3, 1.0, true, &c).unwrap(),
            cylinder(12, 1.0, 2.0, CapFill::NGon, true, &c).unwrap(),
            cylinder(12, 1.0, 2.0, CapFill::TriFan, false, &c).unwrap(),
            cone(12, 1.0, 0.0, 2.0, CapFill::NGon, true, &c).unwrap(),
            torus(16, 8, 1.0, 0.25, true, &c).unwrap(),
        ];
        for m in list {
            m.check_structure().unwrap();
            assert!(validate(&m).is_watertight(), "{}", validate(&m).summary());
            // outward: signed volume positive
            let mut vol = 0.0;
            for t in m.triangles() {
                let (a, b, c) = (m.positions[t[0] as usize], m.positions[t[1] as usize], m.positions[t[2] as usize]);
                vol += a.dot(b.cross(c)) / 6.0;
            }
            assert!(vol > 0.0, "volume {vol}");
            if !m.uvs.is_empty() {
                assert_eq!(m.uvs.len(), m.corner_count());
            }
        }
    }

    #[test]
    fn limits_and_validation() {
        let c = OpCtx::new();
        assert!(uv_sphere(u32::MAX, 16, 1.0, false, &c).is_err());
        assert!(uv_sphere(2, 16, 1.0, false, &c).is_err());
        assert!(ico_sphere(0, 1.0, false, &c).is_err());
        assert!(torus(100_000, 100_000, 1.0, 0.1, false, &c).is_err());
    }
}
