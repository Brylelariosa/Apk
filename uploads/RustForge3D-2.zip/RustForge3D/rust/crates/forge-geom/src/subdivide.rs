//! Subdivision: edge cuts ("subdivide"), loop cuts and Catmull-Clark surfaces.
use forge_math::{Vec2, Vec3};
use forge_mesh::{GeomError, GeomResult, Mesh, OpCtx, OpOutput, Selection, Topology, NONE};
use std::collections::HashSet;

type Piece = (Vec<u32>, Vec<Vec2>);

fn invalid<T>(msg: &str) -> GeomResult<T> {
    Err(GeomError::InvalidInput(msg.to_string()))
}

fn has_uv(m: &Mesh) -> bool {
    !m.uvs.is_empty() && m.uvs.len() == m.corners.len()
}

/// Bookkeeping of the vertices inserted into cut edges. The vertices of edge `e` are consecutive, ordered from the
/// lower to the higher end vertex of the edge.
struct Cuts {
    count: usize,
    first: Vec<u32>,
    t_lo: Vec<f32>,
}

impl Cuts {
    fn new(edges: usize, count: usize) -> Cuts {
        Cuts { count, first: vec![NONE; edges], t_lo: vec![0.5; edges] }
    }
    fn is_cut(&self, e: u32) -> bool {
        e != NONE && self.first[e as usize] != NONE
    }
    /// The `k`-th new vertex of edge `e` when walking away from vertex `from`.
    fn mid(&self, topo: &Topology, e: u32, from: u32, k: usize) -> u32 {
        let base = self.first[e as usize];
        if from == topo.edges[e as usize][0] {
            base + k as u32
        } else {
            base + (self.count - 1 - k) as u32
        }
    }
    /// Parameter (0..1 from `from`) of that vertex along the edge.
    fn t(&self, topo: &Topology, e: u32, from: u32, k: usize) -> f32 {
        if self.count == 1 {
            let t = self.t_lo[e as usize];
            if from == topo.edges[e as usize][0] {
                t
            } else {
                1.0 - t
            }
        } else {
            (k + 1) as f32 / (self.count + 1) as f32
        }
    }
    fn create(&mut self, topo: &Topology, pos: &mut Vec<Vec3>, e: usize, t_lo: f32) {
        let [a, b] = topo.edges[e];
        self.first[e] = pos.len() as u32;
        self.t_lo[e] = t_lo;
        for k in 0..self.count {
            let t = if self.count == 1 { t_lo } else { (k + 1) as f32 / (self.count + 1) as f32 };
            let p = pos[a as usize].lerp(pos[b as usize], t);
            pos.push(p);
        }
    }
}

/// The outline of face `f` with the new vertices of its cut edges inserted.
fn outline(mesh: &Mesh, topo: &Topology, cuts: &Cuts, f: usize, uvs: bool) -> Piece {
    let vs = mesh.face_verts(f);
    let r = mesh.face_range(f);
    let es = topo.face_edges(mesh, f);
    let n = vs.len();
    let mut ov = Vec::with_capacity(n * 2);
    let mut ouv = Vec::new();
    for i in 0..n {
        let j = (i + 1) % n;
        ov.push(vs[i]);
        if uvs {
            ouv.push(mesh.uvs[r.start + i]);
        }
        if cuts.is_cut(es[i]) {
            for k in 0..cuts.count {
                ov.push(cuts.mid(topo, es[i], vs[i], k));
                if uvs {
                    ouv.push(mesh.uvs[r.start + i].lerp(mesh.uvs[r.start + j], cuts.t(topo, es[i], vs[i], k)));
                }
            }
        }
    }
    (ov, ouv)
}

/// Split a face whose edges are all cut: grid for quads, triangle lattice for triangles, centre fan otherwise.
fn grid_pieces(mesh: &Mesh, topo: &Topology, cuts: &Cuts, pos: &mut Vec<Vec3>, f: usize, uvs: bool) -> Vec<Piece> {
    let vs = mesh.face_verts(f);
    let es = topo.face_edges(mesh, f);
    let r = mesh.face_range(f);
    let n = vs.len();
    let m = cuts.count + 1;
    let side = |i: usize, k: usize| cuts.mid(topo, es[i], vs[i], k);
    let uv = |i: usize| if uvs { mesh.uvs[r.start + i] } else { Vec2::ZERO };
    let at = |i: usize, j: usize| i * (m + 1) + j;
    let mut g = vec![NONE; (m + 1) * (m + 1)];
    let mut out: Vec<Piece> = Vec::new();
    match n {
        4 => {
            let p = [pos[vs[0] as usize], pos[vs[1] as usize], pos[vs[2] as usize], pos[vs[3] as usize]];
            let q = [uv(0), uv(1), uv(2), uv(3)];
            g[at(0, 0)] = vs[0];
            g[at(m, 0)] = vs[1];
            g[at(m, m)] = vs[2];
            g[at(0, m)] = vs[3];
            for k in 0..cuts.count {
                g[at(k + 1, 0)] = side(0, k);
                g[at(m, k + 1)] = side(1, k);
                g[at(m - 1 - k, m)] = side(2, k);
                g[at(0, m - 1 - k)] = side(3, k);
            }
            for i in 1..m {
                for j in 1..m {
                    let (s, t) = (i as f32 / m as f32, j as f32 / m as f32);
                    pos.push(p[0].lerp(p[1], s).lerp(p[3].lerp(p[2], s), t));
                    g[at(i, j)] = (pos.len() - 1) as u32;
                }
            }
            let uvat = |i: usize, j: usize| {
                let (s, t) = (i as f32 / m as f32, j as f32 / m as f32);
                q[0].lerp(q[1], s).lerp(q[3].lerp(q[2], s), t)
            };
            for i in 0..m {
                for j in 0..m {
                    let cells = [(i, j), (i + 1, j), (i + 1, j + 1), (i, j + 1)];
                    let ids: Vec<u32> = cells.iter().map(|&(a, b)| g[at(a, b)]).collect();
                    let uu: Vec<Vec2> = if uvs { cells.iter().map(|&(a, b)| uvat(a, b)).collect() } else { Vec::new() };
                    out.push((ids, uu));
                }
            }
        }
        3 => {
            let p = [pos[vs[0] as usize], pos[vs[1] as usize], pos[vs[2] as usize]];
            let q = [uv(0), uv(1), uv(2)];
            g[at(0, 0)] = vs[0];
            g[at(m, 0)] = vs[1];
            g[at(0, m)] = vs[2];
            for k in 0..cuts.count {
                g[at(k + 1, 0)] = side(0, k);
                g[at(m - 1 - k, k + 1)] = side(1, k);
                g[at(0, m - 1 - k)] = side(2, k);
            }
            for i in 1..m {
                for j in 1..(m - i) {
                    pos.push(p[0] + (p[1] - p[0]) * (i as f32 / m as f32) + (p[2] - p[0]) * (j as f32 / m as f32));
                    g[at(i, j)] = (pos.len() - 1) as u32;
                }
            }
            let uvat = |i: usize, j: usize| q[0] + (q[1] - q[0]) * (i as f32 / m as f32) + (q[2] - q[0]) * (j as f32 / m as f32);
            let tri = |cells: [(usize, usize); 3], out: &mut Vec<Piece>| {
                let ids: Vec<u32> = cells.iter().map(|&(a, b)| g[at(a, b)]).collect();
                let uu: Vec<Vec2> = if uvs { cells.iter().map(|&(a, b)| uvat(a, b)).collect() } else { Vec::new() };
                out.push((ids, uu));
            };
            for i in 0..m {
                for j in 0..(m - i) {
                    tri([(i, j), (i + 1, j), (i, j + 1)], &mut out);
                    if j + 1 < m - i {
                        tri([(i + 1, j), (i + 1, j + 1), (i, j + 1)], &mut out);
                    }
                }
            }
        }
        _ => {
            let mut c = Vec3::ZERO;
            for &v in vs {
                c = c + pos[v as usize];
            }
            c = c * (1.0 / n as f32);
            pos.push(c);
            let cid = (pos.len() - 1) as u32;
            let mut cuv = Vec2::ZERO;
            if uvs {
                for i in 0..n {
                    cuv = cuv + uv(i);
                }
                cuv = cuv * (1.0 / n as f32);
            }
            if cuts.count == 1 {
                let mid = |a: usize| uv(a).lerp(uv((a + 1) % n), cuts.t(topo, es[a], vs[a], 0));
                for i in 0..n {
                    let pm = (i + n - 1) % n;
                    let uu = if uvs { vec![cuv, mid(pm), uv(i), mid(i)] } else { Vec::new() };
                    out.push((vec![cid, side(pm, 0), vs[i], side(i, 0)], uu));
                }
            } else {
                let (ov, ouv) = outline(mesh, topo, cuts, f, uvs);
                let l = ov.len();
                for j in 0..l {
                    let k = (j + 1) % l;
                    let uu = if uvs { vec![cuv, ouv[j], ouv[k]] } else { Vec::new() };
                    out.push((vec![cid, ov[j], ov[k]], uu));
                }
            }
        }
    }
    out
}

fn push_face(m: &mut Mesh, v: &[u32], uv: Option<&[Vec2]>, mat: u16, smooth: bool, uvs: bool) {
    m.corners.extend_from_slice(v);
    m.face_starts.push(m.corners.len() as u32);
    m.face_material.push(mat);
    m.face_smooth.push(smooth);
    if uvs {
        match uv {
            Some(u) if u.len() == v.len() => m.uvs.extend_from_slice(u),
            _ => m.uvs.extend(std::iter::repeat(Vec2::ZERO).take(v.len())),
        }
    }
}

/// Rebuild the mesh with `pos` (original vertices first, new ones appended) and the faces produced by `split`
/// (`None` = keep the face). Loose edges that were cut are split as well.
fn assemble<F>(mesh: &Mesh, topo: &Topology, pos: Vec<Vec3>, cuts: &Cuts, base: &Selection, ctx: &OpCtx, mut split: F) -> GeomResult<(Mesh, OpOutput)>
where
    F: FnMut(&mut Vec<Vec3>, usize) -> Option<Vec<Piece>>,
{
    let mut pos = pos;
    let (nv0, nf) = (mesh.vert_count(), mesh.face_count());
    let uvs = has_uv(mesh);
    let mut m = Mesh::new();
    let mut face_map = vec![NONE; nf];
    let mut new_faces = Vec::new();
    for f in 0..nf {
        ctx.poll(f)?;
        face_map[f] = m.face_count() as u32;
        let (mat, smooth) = (mesh.face_material[f], mesh.face_smooth[f]);
        match split(&mut pos, f) {
            None => {
                let r = mesh.face_range(f);
                push_face(&mut m, &mesh.corners[r.clone()], if uvs { Some(&mesh.uvs[r]) } else { None }, mat, smooth, uvs);
            }
            Some(pieces) => {
                for (k, (v, uv)) in pieces.iter().enumerate() {
                    if k > 0 {
                        new_faces.push(m.face_count() as u32);
                    }
                    push_face(&mut m, v, Some(uv), mat, smooth, uvs);
                }
            }
        }
    }
    for l in &mesh.loose_edges {
        match topo.edge_between(l[0], l[1]) {
            Some(e) if cuts.is_cut(e) => {
                let mut prev = l[0];
                for k in 0..cuts.count {
                    let v = cuts.mid(topo, e, l[0], k);
                    m.loose_edges.push([prev, v]);
                    prev = v;
                }
                m.loose_edges.push([prev, l[1]]);
            }
            _ => m.loose_edges.push(*l),
        }
    }
    m.positions = pos;
    let n = m.vert_count();
    let mut selection = Selection::none(n);
    for v in 0..nv0.min(base.verts.len()) {
        selection.verts[v] = base.verts[v];
    }
    let new_verts: Vec<u32> = (nv0 as u32..n as u32).collect();
    for &v in &new_verts {
        selection.verts[v as usize] = true;
    }
    Ok((m, OpOutput { selection, new_verts, new_faces, vert_map: Vec::new(), face_map }))
}

/// Subdivide the selected edges and faces: every edge of a selected face (and every selected edge) is cut `cuts_n`
/// times; faces whose edges are all cut become a grid (quads), a lattice (triangles) or a fan/quads around a centre
/// vertex (n-gons). Faces with only some cut edges just receive the new vertices.
pub fn subdivide(mesh: &Mesh, sel: &Selection, cuts_n: u32, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    if cuts_n == 0 || cuts_n > 32 {
        return invalid("number of cuts must be between 1 and 32");
    }
    ctx.check()?;
    let topo = Topology::build(mesh);
    let (nv, nf, ne) = (mesh.vert_count(), mesh.face_count(), topo.edges.len());
    let fm = sel.face_mask(mesh);
    let mut cut = sel.edge_mask(&topo);
    for f in 0..nf {
        if fm[f] {
            for &e in topo.face_edges(mesh, f) {
                if e != NONE {
                    cut[e as usize] = true;
                }
            }
        }
    }
    let count = cuts_n as usize;
    let n_cut = cut.iter().filter(|&&c| c).count();
    if n_cut == 0 {
        return invalid("nothing selected to subdivide");
    }
    let (mut est_v, mut est_f) = (nv + n_cut * count, nf);
    for f in 0..nf {
        if topo.face_edges(mesh, f).iter().any(|&e| e != NONE && cut[e as usize]) {
            est_v += count * count + 1;
            est_f += (count + 1) * (count + 1) * mesh.face_len(f).saturating_sub(2).max(1);
        }
    }
    ctx.ensure_capacity(est_v, est_f)?;
    let mut pos = mesh.positions.clone();
    let mut cuts = Cuts::new(ne, count);
    for e in 0..ne {
        if cut[e] {
            cuts.create(&topo, &mut pos, e, 0.5);
        }
    }
    let uvs = has_uv(mesh);
    assemble(mesh, &topo, pos, &cuts, sel, ctx, |pos, f| {
        let es = topo.face_edges(mesh, f);
        if !es.iter().any(|&e| cuts.is_cut(e)) {
            return None;
        }
        if es.iter().all(|&e| cuts.is_cut(e)) {
            Some(grid_pieces(mesh, &topo, &cuts, pos, f, uvs))
        } else {
            Some(vec![outline(mesh, &topo, &cuts, f, uvs)])
        }
    })
}

/// The ring of quads crossed by an edge: the parallel edges (with the end vertex their cut measures from) and the
/// quads between them.
pub(crate) struct Ring {
    pub edges: Vec<(u32, u32)>,
    pub quads: Vec<u32>,
    pub closed: bool,
}

pub(crate) fn walk_ring(mesh: &Mesh, topo: &Topology, start: u32) -> Ring {
    let from0 = topo.edges[start as usize][0];
    let mut ring = Ring { edges: vec![(start, from0)], quads: Vec::new(), closed: false };
    let mut seen_e: HashSet<u32> = HashSet::new();
    seen_e.insert(start);
    let mut seen_f: HashSet<u32> = HashSet::new();
    for dir in 0..2 {
        let (mut e, mut from) = (start, from0);
        let mut f = topo.edge_faces[start as usize][dir];
        loop {
            if f == NONE || mesh.face_len(f as usize) != 4 || seen_f.contains(&f) {
                break;
            }
            let es = topo.face_edges(mesh, f as usize);
            let vs = mesh.face_verts(f as usize);
            let Some(p) = es.iter().position(|&x| x == e) else { break };
            let opp = es[(p + 2) % 4];
            if opp == NONE {
                break;
            }
            let next_from = if from == vs[p] { vs[(p + 3) % 4] } else { vs[(p + 2) % 4] };
            seen_f.insert(f);
            ring.quads.push(f);
            if opp == start {
                ring.closed = true;
                break;
            }
            if !seen_e.insert(opp) {
                break;
            }
            ring.edges.push((opp, next_from));
            let of = topo.edge_faces[opp as usize];
            f = if of[0] == f { of[1] } else { of[0] };
            e = opp;
            from = next_from;
        }
        if ring.closed {
            break;
        }
    }
    ring
}

/// Split a quad of a loop-cut ring into `count + 1` strips.
fn strips(mesh: &Mesh, topo: &Topology, cuts: &Cuts, f: usize, uvs: bool) -> Option<Vec<Piece>> {
    let es = topo.face_edges(mesh, f);
    let vs = mesh.face_verts(f);
    if vs.len() != 4 {
        return None;
    }
    let r = mesh.face_range(f);
    let p = (0..2).find(|&p| cuts.is_cut(es[p]) && cuts.is_cut(es[p + 2]))?;
    let (e1, e2) = (es[p], es[p + 2]);
    let (v0, v1, v2, v3) = (vs[p], vs[(p + 1) % 4], vs[(p + 2) % 4], vs[(p + 3) % 4]);
    let uv = |i: usize| if uvs { mesh.uvs[r.start + i % 4] } else { Vec2::ZERO };
    let uvat = |s: f32, t: f32| uv(p).lerp(uv(p + 1), s).lerp(uv(p + 3).lerp(uv(p + 2), s), t);
    let c = cuts.count;
    let mut out = Vec::with_capacity(c + 1);
    for k in 0..=c {
        let (bl, tl, sl) = if k == 0 { (v0, v3, 0.0) } else { (cuts.mid(topo, e1, v0, k - 1), cuts.mid(topo, e2, v3, k - 1), cuts.t(topo, e1, v0, k - 1)) };
        let (br, tr, sr) = if k == c { (v1, v2, 1.0) } else { (cuts.mid(topo, e1, v0, k), cuts.mid(topo, e2, v3, k), cuts.t(topo, e1, v0, k)) };
        let uu = if uvs { vec![uvat(sl, 0.0), uvat(sr, 0.0), uvat(sr, 1.0), uvat(sl, 1.0)] } else { Vec::new() };
        out.push((vec![bl, br, tr, tl], uu));
    }
    Some(out)
}

/// Cut the ring of quads that contains the edge `edge` (given by its two vertices) `cuts_n` times. With a single
/// cut `factor` (0..1) shifts the cut towards one side (0.5 = middle).
pub fn loop_cut(mesh: &Mesh, edge: [u32; 2], cuts_n: u32, factor: f32, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    if cuts_n == 0 || cuts_n > 64 {
        return invalid("number of cuts must be between 1 and 64");
    }
    ctx.check()?;
    let topo = Topology::build(mesh);
    let Some(start) = topo.edge_between(edge[0], edge[1]) else {
        return invalid("the two vertices are not joined by an edge");
    };
    let ring = walk_ring(mesh, &topo, start);
    if ring.quads.is_empty() {
        return invalid("the edge is not part of a loop of quads");
    }
    let count = cuts_n as usize;
    ctx.ensure_capacity(mesh.vert_count() + ring.edges.len() * count, mesh.face_count() + ring.quads.len() * count)?;
    let factor = if factor.is_finite() { factor.clamp(0.001, 0.999) } else { 0.5 };
    let mut pos = mesh.positions.clone();
    let mut cuts = Cuts::new(topo.edges.len(), count);
    for &(e, from) in &ring.edges {
        let t_lo = if from == topo.edges[e as usize][0] { factor } else { 1.0 - factor };
        cuts.create(&topo, &mut pos, e as usize, t_lo);
    }
    let mut in_ring = vec![false; mesh.face_count()];
    for &f in &ring.quads {
        in_ring[f as usize] = true;
    }
    let uvs = has_uv(mesh);
    let base = Selection::none(mesh.vert_count());
    assemble(mesh, &topo, pos, &cuts, &base, ctx, |_pos, f| {
        let es = topo.face_edges(mesh, f);
        if !es.iter().any(|&e| cuts.is_cut(e)) {
            return None;
        }
        if in_ring[f] {
            if let Some(p) = strips(mesh, &topo, &cuts, f, uvs) {
                return Some(p);
            }
        }
        Some(vec![outline(mesh, &topo, &cuts, f, uvs)])
    })
}

/// Catmull-Clark subdivision surface (`levels` 0..=6). Boundaries use the standard boundary rule; loose edges are
/// split in two. Original vertex indices are preserved (vertices first, then edge points, then face points).
pub fn subsurf(mesh: &Mesh, levels: u32, ctx: &OpCtx) -> GeomResult<Mesh> {
    if levels > 6 {
        return invalid("subdivision levels must be between 0 and 6");
    }
    let mut cur = mesh.clone();
    for _ in 0..levels {
        cur = subsurf_once(&cur, ctx)?;
    }
    Ok(cur)
}

fn subsurf_once(m: &Mesh, ctx: &OpCtx) -> GeomResult<Mesh> {
    ctx.check()?;
    let topo = Topology::build(m);
    let (nv, nf, ne) = (m.vert_count(), m.face_count(), topo.edges.len());
    ctx.ensure_capacity(nv + ne + nf, m.corners.len())?;
    let uvs = has_uv(m);
    let fp: Vec<Vec3> = (0..nf)
        .map(|f| {
            let vs = m.face_verts(f);
            let mut c = Vec3::ZERO;
            for &v in vs {
                c = c + m.positions[v as usize];
            }
            c * (1.0 / vs.len().max(1) as f32)
        })
        .collect();
    let mid = |e: usize| (m.positions[topo.edges[e][0] as usize] + m.positions[topo.edges[e][1] as usize]) * 0.5;
    let ep: Vec<Vec3> = (0..ne)
        .map(|e| {
            let [f1, f2] = topo.edge_faces[e];
            if topo.edge_face_count[e] == 2 && f1 != NONE && f2 != NONE {
                let [a, b] = topo.edges[e];
                (m.positions[a as usize] + m.positions[b as usize] + fp[f1 as usize] + fp[f2 as usize]) * 0.25
            } else {
                mid(e)
            }
        })
        .collect();
    let mut vp = m.positions.clone();
    for v in 0..nv {
        ctx.poll(v)?;
        let around = topo.vert_edges.get(v);
        if around.is_empty() {
            continue;
        }
        let open: Vec<u32> = around.iter().copied().filter(|&e| topo.edge_face_count[e as usize] != 2).collect();
        let p = m.positions[v];
        if open.is_empty() {
            let n = around.len() as f32;
            let faces = topo.vert_faces.get(v);
            let mut f_avg = Vec3::ZERO;
            for &f in faces {
                f_avg = f_avg + fp[f as usize];
            }
            f_avg = f_avg * (1.0 / faces.len().max(1) as f32);
            let mut r_avg = Vec3::ZERO;
            for &e in around {
                r_avg = r_avg + mid(e as usize);
            }
            r_avg = r_avg * (1.0 / n);
            vp[v] = (f_avg + r_avg * 2.0 + p * (n - 3.0)) * (1.0 / n);
        } else if open.len() == 2 {
            let o1 = topo.other_vertex(open[0], v as u32);
            let o2 = topo.other_vertex(open[1], v as u32);
            vp[v] = (p * 6.0 + m.positions[o1 as usize] + m.positions[o2 as usize]) * (1.0 / 8.0);
        }
    }
    let mut out = Mesh::new();
    out.positions = vp;
    out.positions.extend(ep);
    out.positions.extend(fp.iter().copied());
    let (eo, fo) = (nv as u32, (nv + ne) as u32);
    for f in 0..nf {
        ctx.poll(f)?;
        let vs = m.face_verts(f);
        let es = topo.face_edges(m, f);
        let r = m.face_range(f);
        let n = vs.len();
        if es.iter().any(|&e| e == NONE) {
            continue;
        }
        let (mat, smooth) = (m.face_material[f], m.face_smooth[f]);
        let mut uc = Vec2::ZERO;
        if uvs {
            for i in 0..n {
                uc = uc + m.uvs[r.start + i];
            }
            uc = uc * (1.0 / n as f32);
        }
        for i in 0..n {
            let pi = (i + n - 1) % n;
            out.corners.extend_from_slice(&[vs[i], eo + es[i], fo + f as u32, eo + es[pi]]);
            out.face_starts.push(out.corners.len() as u32);
            out.face_material.push(mat);
            out.face_smooth.push(smooth);
            if uvs {
                let (u0, u1, up) = (m.uvs[r.start + i], m.uvs[r.start + (i + 1) % n], m.uvs[r.start + pi]);
                out.uvs.extend_from_slice(&[u0, (u0 + u1) * 0.5, uc, (up + u0) * 0.5]);
            }
        }
    }
    for l in &m.loose_edges {
        match topo.edge_between(l[0], l[1]) {
            Some(e) => {
                out.loose_edges.push([l[0], eo + e]);
                out.loose_edges.push([eo + e, l[1]]);
            }
            None => out.loose_edges.push(*l),
        }
    }
    Ok(out)
}
