//! Delete, dissolve, merge, fill, duplicate, separate and join.
use crate::poly::{key, Poly, Work};
use forge_math::{Vec2, Vec3};
use forge_mesh::{tri::triangulate_polygon, GeomError, GeomResult, Mesh, OpCtx, OpOutput, Selection, Topology, NONE};
use std::collections::{BTreeMap, HashMap, HashSet};

fn invalid<T>(msg: &str) -> GeomResult<T> {
    Err(GeomError::InvalidInput(msg.to_string()))
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DeleteMode {
    /// Remove the vertices and everything attached to them.
    Vertices,
    /// Remove the edges and the faces using them (the other edges of those faces survive as wire edges).
    Edges,
    /// Remove faces together with edges and vertices that nothing else uses.
    Faces,
    /// Remove faces only; their edges and vertices stay.
    OnlyFaces,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum MergeMode {
    /// All selected vertices to their centre.
    Center,
    /// All to the position of the lowest-index selected vertex.
    First,
    /// All to the position of the highest-index selected vertex.
    Last,
    /// All to the given point.
    Cursor(Vec3),
    /// Every group of edge-connected selected vertices to its own centre.
    Collapse,
}

struct Dsu(Vec<u32>);

impl Dsu {
    fn new(n: usize) -> Dsu {
        Dsu((0..n as u32).collect())
    }
    fn find(&mut self, mut x: u32) -> u32 {
        while self.0[x as usize] != x {
            let p = self.0[x as usize];
            self.0[x as usize] = self.0[p as usize];
            x = self.0[x as usize];
        }
        x
    }
    /// The lower index always becomes the root.
    fn union(&mut self, a: u32, b: u32) {
        let (ra, rb) = (self.find(a), self.find(b));
        if ra != rb {
            self.0[ra.max(rb) as usize] = ra.min(rb);
        }
    }
}

fn finish(w: Work, vert_map: Vec<u32>, face_map: Vec<u32>) -> (Mesh, OpOutput) {
    let m = w.into_mesh();
    let selection = Selection::none(m.vert_count());
    (m, OpOutput { selection, vert_map, face_map, ..Default::default() })
}

/// Edges of faces that are not kept and are not used by a kept face, as vertex pairs.
fn orphan_edges(mesh: &Mesh, keep: &[bool], pass: impl Fn(u32, u32) -> bool) -> Vec<[u32; 2]> {
    let nf = mesh.face_count();
    let mut used: HashSet<(u32, u32)> = HashSet::new();
    for f in 0..nf {
        if keep[f] {
            let vs = mesh.face_verts(f);
            for i in 0..vs.len() {
                used.insert(key(vs[i], vs[(i + 1) % vs.len()]));
            }
        }
    }
    let mut out = Vec::new();
    for f in 0..nf {
        if keep[f] {
            continue;
        }
        let vs = mesh.face_verts(f);
        for i in 0..vs.len() {
            let (a, b) = (vs[i], vs[(i + 1) % vs.len()]);
            let k = key(a, b);
            if a != b && !used.contains(&k) && pass(a, b) {
                used.insert(k);
                out.push([k.0, k.1]);
            }
        }
    }
    out
}

pub fn delete(mesh: &Mesh, sel: &Selection, mode: DeleteMode, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    if !sel.any() {
        return invalid("nothing selected");
    }
    let (nv, nf) = (mesh.vert_count(), mesh.face_count());
    let mut w = Work::from_mesh(mesh);
    let mut keep = vec![true; nf];
    let mut cand = vec![false; nv];
    let mut survivors: Vec<[u32; 2]> = Vec::new();
    match mode {
        DeleteMode::Vertices => {
            for f in 0..nf {
                if mesh.face_verts(f).iter().any(|&v| sel.is_selected(v)) {
                    keep[f] = false;
                }
            }
            w.loose.retain(|e| !sel.is_selected(e[0]) && !sel.is_selected(e[1]));
        }
        DeleteMode::Faces | DeleteMode::OnlyFaces => {
            let fm = sel.face_mask(mesh);
            if !fm.iter().any(|&b| b) {
                return invalid("no faces selected");
            }
            for f in 0..nf {
                if fm[f] {
                    keep[f] = false;
                    for &v in mesh.face_verts(f) {
                        cand[v as usize] = true;
                    }
                }
            }
            if mode == DeleteMode::OnlyFaces {
                survivors = orphan_edges(mesh, &keep, |_, _| true);
            }
        }
        DeleteMode::Edges => {
            let topo = Topology::build(mesh);
            let em = sel.edge_mask(&topo);
            if !em.iter().any(|&b| b) {
                return invalid("no edges selected");
            }
            for f in 0..nf {
                if topo.face_edges(mesh, f).iter().any(|&e| e != NONE && em[e as usize]) {
                    keep[f] = false;
                }
            }
            let mut picked: HashSet<(u32, u32)> = HashSet::new();
            for e in 0..topo.edges.len() {
                if em[e] {
                    picked.insert((topo.edges[e][0], topo.edges[e][1]));
                    for &v in &topo.edges[e] {
                        cand[v as usize] = true;
                    }
                }
            }
            w.loose.retain(|e| !picked.contains(&key(e[0], e[1])));
            survivors = orphan_edges(mesh, &keep, |a, b| !picked.contains(&key(a, b)));
        }
    }
    let face_map = w.retain_polys(&keep);
    w.loose.extend(survivors);
    let vert_map = match mode {
        DeleteMode::Vertices => {
            let rm: Vec<bool> = (0..nv).map(|v| sel.is_selected(v as u32)).collect();
            w.remove_verts(&rm)
        }
        DeleteMode::OnlyFaces => Vec::new(),
        _ => w.compact(Some(&cand)),
    };
    Ok(finish(w, vert_map, face_map))
}

/// Merge faces into one polygon along their common outline; `None` unless the outline is one simple loop.
fn merge_group(w: &Work, faces: &[usize]) -> Option<Poly> {
    let mut dir: HashMap<(u32, u32), (usize, usize)> = HashMap::new();
    for &f in faces {
        let p = &w.polys[f];
        let n = p.v.len();
        for i in 0..n {
            if dir.insert((p.v[i], p.v[(i + 1) % n]), (f, i)).is_some() {
                return None;
            }
        }
    }
    let mut next: HashMap<u32, (u32, usize, usize)> = HashMap::new();
    for (&(a, b), &(f, i)) in &dir {
        if !dir.contains_key(&(b, a)) && next.insert(a, (b, f, i)).is_some() {
            return None;
        }
    }
    let total = next.len();
    if total < 3 {
        return None;
    }
    let start = next.iter().min_by_key(|e| (e.1 .1, e.1 .2)).map(|e| *e.0)?;
    let mut verts = Vec::with_capacity(total);
    let mut uvs = Vec::new();
    let mut cur = start;
    loop {
        let &(b, f, i) = next.get(&cur)?;
        verts.push(cur);
        if w.has_uv {
            uvs.push(*w.polys[f].uv.get(i)?);
        }
        cur = b;
        if cur == start {
            break;
        }
        if verts.len() >= total {
            return None;
        }
    }
    if verts.len() != total {
        return None;
    }
    let first = *faces.iter().min()?;
    let p0 = &w.polys[first];
    Some(Poly { v: verts, mat: p0.mat, smooth: p0.smooth, uv: uvs })
}

/// Drop candidate vertices that sit between exactly two neighbours from the polygons that use them.
fn remove_degree2(w: &mut Work, cand: &[bool]) {
    let nv = w.pos.len();
    let mut nb: Vec<[u32; 2]> = vec![[NONE; 2]; nv];
    let mut bad = vec![false; nv];
    for l in &w.loose {
        bad[l[0] as usize] = true;
        bad[l[1] as usize] = true;
    }
    for p in &w.polys {
        let n = p.v.len();
        for i in 0..n {
            let v = p.v[i] as usize;
            if !cand[v] || bad[v] {
                continue;
            }
            if n <= 3 {
                bad[v] = true;
                continue;
            }
            for u in [p.v[(i + n - 1) % n], p.v[(i + 1) % n]] {
                if nb[v][0] == u || nb[v][1] == u {
                    continue;
                }
                if nb[v][0] == NONE {
                    nb[v][0] = u;
                } else if nb[v][1] == NONE {
                    nb[v][1] = u;
                } else {
                    bad[v] = true;
                }
            }
        }
    }
    let mut rm: Vec<bool> = (0..nv).map(|v| cand[v] && !bad[v] && nb[v][0] != NONE && nb[v][1] != NONE).collect();
    loop {
        let mut changed = false;
        for p in &w.polys {
            let removable = p.v.iter().filter(|&&v| rm[v as usize]).count();
            if removable > 0 && p.v.len() - removable < 3 {
                for &v in &p.v {
                    if rm[v as usize] {
                        rm[v as usize] = false;
                        changed = true;
                    }
                }
            }
        }
        if !changed {
            break;
        }
    }
    if !rm.iter().any(|&b| b) {
        return;
    }
    for p in &mut w.polys {
        if p.v.iter().any(|&v| rm[v as usize]) {
            let mut nv2 = Vec::with_capacity(p.v.len());
            let mut nuv = Vec::new();
            for (k, &v) in p.v.iter().enumerate() {
                if !rm[v as usize] {
                    nv2.push(v);
                    if k < p.uv.len() {
                        nuv.push(p.uv[k]);
                    }
                }
            }
            p.v = nv2;
            p.uv = nuv;
        }
    }
}

fn dissolve_groups(mesh: &Mesh, member: &[bool], dsu: &mut Dsu, use_verts: bool, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    let nf = mesh.face_count();
    let mut groups: BTreeMap<u32, Vec<usize>> = BTreeMap::new();
    for f in 0..nf {
        if member[f] {
            groups.entry(dsu.find(f as u32)).or_default().push(f);
        }
    }
    let mut w = Work::from_mesh(mesh);
    let mut keep = vec![true; nf];
    let mut cand = vec![false; mesh.vert_count()];
    let mut heads: Vec<usize> = Vec::new();
    for fs in groups.values() {
        if fs.len() < 2 {
            continue;
        }
        ctx.check()?;
        if let Some(poly) = merge_group(&w, fs) {
            for &f in fs {
                for &v in &w.polys[f].v {
                    cand[v as usize] = true;
                }
                keep[f] = false;
            }
            keep[fs[0]] = true;
            heads.push(fs[0]);
            w.polys[fs[0]] = poly;
        }
    }
    if heads.is_empty() {
        return invalid("nothing could be dissolved (the faces must form one connected patch without holes)");
    }
    let face_map = w.retain_polys(&keep);
    if use_verts {
        remove_degree2(&mut w, &cand);
    }
    let vert_map = w.compact(Some(&cand));
    let m = w.into_mesh();
    let mut selection = Selection::none(m.vert_count());
    for &h in &heads {
        let nf2 = face_map[h];
        if nf2 != NONE {
            for &v in m.face_verts(nf2 as usize) {
                selection.set(v, true);
            }
        }
    }
    Ok((m, OpOutput { selection, vert_map, face_map, ..Default::default() }))
}

/// Merge each connected patch of selected faces into a single polygon.
pub fn dissolve_faces(mesh: &Mesh, sel: &Selection, use_verts: bool, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    let fm = sel.face_mask(mesh);
    if !fm.iter().any(|&b| b) {
        return invalid("no faces selected");
    }
    let topo = Topology::build(mesh);
    let mut dsu = Dsu::new(mesh.face_count());
    for e in 0..topo.edges.len() {
        let [a, b] = topo.edge_faces[e];
        if topo.edge_face_count[e] == 2 && a != NONE && b != NONE && fm[a as usize] && fm[b as usize] {
            dsu.union(a, b);
        }
    }
    dissolve_groups(mesh, &fm, &mut dsu, use_verts, ctx)
}

/// Remove the selected edges by merging the two faces that share each of them.
pub fn dissolve_edges(mesh: &Mesh, sel: &Selection, use_verts: bool, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    let topo = Topology::build(mesh);
    let em = sel.edge_mask(&topo);
    let mut dsu = Dsu::new(mesh.face_count());
    let mut member = vec![false; mesh.face_count()];
    let mut cand_edges: Vec<[u32; 2]> = Vec::new();
    for e in 0..topo.edges.len() {
        let [a, b] = topo.edge_faces[e];
        if em[e] && topo.edge_face_count[e] == 2 && a != NONE && b != NONE {
            dsu.union(a, b);
            member[a as usize] = true;
            member[b as usize] = true;
            cand_edges.push(topo.edges[e]);
        }
    }
    if cand_edges.is_empty() {
        return invalid("no dissolvable edges selected (an edge must be shared by exactly two faces)");
    }
    dissolve_groups(mesh, &member, &mut dsu, use_verts, ctx)
}

/// Dissolve vertices: the faces around a vertex become one polygon; a vertex between two edges is just removed.
pub fn dissolve_verts(mesh: &Mesh, sel: &Selection, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    let picked = sel.indices();
    if picked.is_empty() {
        return invalid("no vertices selected");
    }
    let nv = mesh.vert_count();
    let nf = mesh.face_count();
    let mut w = Work::from_mesh(mesh);
    let mut vf: Vec<Vec<usize>> = vec![Vec::new(); nv];
    for (fi, p) in w.polys.iter().enumerate() {
        for &v in &p.v {
            vf[v as usize].push(fi);
        }
    }
    let mut loose_deg = vec![0u32; nv];
    for e in &w.loose {
        loose_deg[e[0] as usize] += 1;
        loose_deg[e[1] as usize] += 1;
    }
    let mut dead = vec![false; nf];
    let mut cand = vec![false; nv];
    for (k, &v) in picked.iter().enumerate() {
        ctx.poll(k)?;
        cand[v as usize] = true;
        if loose_deg[v as usize] > 0 {
            continue;
        }
        let mut fs: Vec<usize> = vf[v as usize].iter().copied().filter(|&f| !dead[f]).collect();
        fs.sort_unstable();
        fs.dedup();
        if fs.is_empty() {
            continue;
        }
        let mut nbrs: Vec<u32> = Vec::new();
        for &f in &fs {
            let p = &w.polys[f];
            let n = p.v.len();
            for i in 0..n {
                if p.v[i] == v {
                    for u in [p.v[(i + n - 1) % n], p.v[(i + 1) % n]] {
                        if !nbrs.contains(&u) {
                            nbrs.push(u);
                        }
                    }
                }
            }
        }
        if nbrs.len() <= 2 {
            for &f in &fs {
                let p = &mut w.polys[f];
                if p.v.len() > 3 {
                    if let Some(i) = p.v.iter().position(|&x| x == v) {
                        p.v.remove(i);
                        if i < p.uv.len() {
                            p.uv.remove(i);
                        }
                    }
                }
            }
        } else if let Some(mut poly) = merge_group(&w, &fs) {
            if poly.v.len() > 3 {
                if let Some(i) = poly.v.iter().position(|&x| x == v) {
                    poly.v.remove(i);
                    if i < poly.uv.len() {
                        poly.uv.remove(i);
                    }
                }
            }
            let np = w.polys.len();
            for &u in &poly.v {
                vf[u as usize].push(np);
            }
            for &f in &fs {
                dead[f] = true;
                for &u in &w.polys[f].v {
                    cand[u as usize] = true;
                }
            }
            w.polys.push(poly);
            dead.push(false);
        }
    }
    let keep: Vec<bool> = dead.iter().map(|&d| !d).collect();
    let face_map = w.retain_polys(&keep);
    let vert_map = w.compact(Some(&cand));
    let m = w.into_mesh();
    let new_faces: Vec<u32> = (nf..face_map.len()).filter_map(|i| (face_map[i] != NONE).then_some(face_map[i])).collect();
    let selection = Selection::none(m.vert_count());
    Ok((m, OpOutput { selection, new_faces, vert_map, face_map: face_map[..nf].to_vec(), ..Default::default() }))
}

fn no_repeats(v: &[u32]) -> bool {
    if v.len() <= 8 {
        for i in 0..v.len() {
            for j in i + 1..v.len() {
                if v[i] == v[j] {
                    return false;
                }
            }
        }
        true
    } else {
        let mut s = v.to_vec();
        s.sort_unstable();
        s.windows(2).all(|p| p[0] != p[1])
    }
}

/// Apply "vertex v becomes rep[v]": polygons shrink, degenerate ones vanish, absorbed vertices are removed.
/// Returns (vertex map where absorbed vertices map to their survivor, face map).
fn collapse(w: &mut Work, rep: &[u32]) -> (Vec<u32>, Vec<u32>) {
    let has_uv = w.has_uv;
    for p in &mut w.polys {
        let mut nvv: Vec<u32> = Vec::with_capacity(p.v.len());
        let mut nuv: Vec<Vec2> = Vec::new();
        for (k, &v) in p.v.iter().enumerate() {
            let r = rep[v as usize];
            if nvv.last() != Some(&r) {
                nvv.push(r);
                if has_uv && k < p.uv.len() {
                    nuv.push(p.uv[k]);
                }
            }
        }
        if nvv.len() > 1 && nvv.first() == nvv.last() {
            nvv.pop();
            nuv.pop();
        }
        p.v = nvv;
        p.uv = nuv;
    }
    let keep: Vec<bool> = w.polys.iter().map(|p| p.v.len() >= 3 && no_repeats(&p.v)).collect();
    let face_map = w.retain_polys(&keep);
    for e in &mut w.loose {
        *e = [rep[e[0] as usize], rep[e[1] as usize]];
    }
    w.loose.retain(|e| e[0] != e[1]);
    let remove: Vec<bool> = (0..rep.len()).map(|v| rep[v] as usize != v).collect();
    let m = w.remove_verts(&remove);
    let vert_map = (0..rep.len()).map(|v| m[rep[v] as usize]).collect();
    (vert_map, face_map)
}

/// Merge selected vertices (see [`MergeMode`]).
pub fn merge(mesh: &Mesh, sel: &Selection, mode: MergeMode, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    let nv = mesh.vert_count();
    let picked = sel.indices();
    if picked.is_empty() {
        return invalid("no vertices selected");
    }
    let mut dsu = Dsu::new(nv);
    if mode == MergeMode::Collapse {
        let topo = Topology::build(mesh);
        for e in &topo.edges {
            if sel.is_selected(e[0]) && sel.is_selected(e[1]) {
                dsu.union(e[0], e[1]);
            }
        }
    } else {
        for &v in &picked[1..] {
            dsu.union(picked[0], v);
        }
    }
    let mut groups: BTreeMap<u32, Vec<u32>> = BTreeMap::new();
    for &v in &picked {
        groups.entry(dsu.find(v)).or_default().push(v);
    }
    let mut w = Work::from_mesh(mesh);
    let mut rep: Vec<u32> = (0..nv as u32).collect();
    for members in groups.values() {
        let survivor = *members.iter().min().unwrap_or(&0);
        let target = match mode {
            MergeMode::First => w.pos[survivor as usize],
            MergeMode::Last => w.pos[*members.iter().max().unwrap_or(&survivor) as usize],
            MergeMode::Cursor(p) => p,
            _ => {
                let mut c = Vec3::ZERO;
                for &m in members {
                    c = c + w.pos[m as usize];
                }
                c * (1.0 / members.len() as f32)
            }
        };
        w.pos[survivor as usize] = target;
        for &m in members {
            rep[m as usize] = survivor;
        }
    }
    let (vert_map, face_map) = collapse(&mut w, &rep);
    let m = w.into_mesh();
    let selection = Selection::from_indices(m.vert_count(), picked.iter().map(|&v| vert_map[v as usize]).filter(|&x| x != NONE));
    Ok((m, OpOutput { selection, vert_map, face_map, ..Default::default() }))
}

/// Merge vertices closer than `eps` (to the lowest-index vertex of each cluster). `sel = None` considers all vertices.
pub fn remove_doubles(mesh: &Mesh, sel: Option<&Selection>, eps: f32, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    if !eps.is_finite() || eps < 0.0 {
        return invalid("merge distance must be a non-negative number");
    }
    let nv = mesh.vert_count();
    let cell = eps.max(1e-6);
    let cell_of = |p: Vec3| ((p.x / cell).floor() as i64, (p.y / cell).floor() as i64, (p.z / cell).floor() as i64);
    let mut grid: HashMap<(i64, i64, i64), Vec<u32>> = HashMap::new();
    let mut dsu = Dsu::new(nv);
    for v in 0..nv {
        ctx.poll(v)?;
        if let Some(s) = sel {
            if !s.is_selected(v as u32) {
                continue;
            }
        }
        let p = mesh.positions[v];
        let (cx, cy, cz) = cell_of(p);
        for dx in -1..=1 {
            for dy in -1..=1 {
                for dz in -1..=1 {
                    if let Some(list) = grid.get(&(cx + dx, cy + dy, cz + dz)) {
                        for &u in list {
                            if mesh.positions[u as usize].distance(p) <= eps {
                                dsu.union(u, v as u32);
                            }
                        }
                    }
                }
            }
        }
        grid.entry((cx, cy, cz)).or_default().push(v as u32);
    }
    let rep: Vec<u32> = (0..nv as u32).map(|v| dsu.find(v)).collect();
    let mut w = Work::from_mesh(mesh);
    let (vert_map, face_map) = collapse(&mut w, &rep);
    let m = w.into_mesh();
    let selection = match sel {
        Some(s) => s.remap(&vert_map, m.vert_count()),
        None => Selection::none(m.vert_count()),
    };
    Ok((m, OpOutput { selection, vert_map, face_map, ..Default::default() }))
}

/// Copy the selected geometry (faces, edges, vertices); the copy is appended and selected.
pub fn duplicate(mesh: &Mesh, sel: &Selection, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    let picked = sel.indices();
    if picked.is_empty() {
        return invalid("nothing selected");
    }
    let topo = Topology::build(mesh);
    let fm = sel.face_mask(mesh);
    let em = sel.edge_mask(&topo);
    let nf_sel = fm.iter().filter(|&&b| b).count();
    ctx.ensure_capacity(mesh.vert_count() + picked.len(), mesh.face_count() + nf_sel)?;
    let mut w = Work::from_mesh(mesh);
    let mut map = vec![NONE; mesh.vert_count()];
    let mut new_verts = Vec::with_capacity(picked.len());
    for &v in &picked {
        let d = w.vert(mesh.positions[v as usize]);
        map[v as usize] = d;
        new_verts.push(d);
    }
    let mut new_faces = Vec::new();
    let mut covered: HashSet<(u32, u32)> = HashSet::new();
    for f in 0..mesh.face_count() {
        if !fm[f] {
            continue;
        }
        let mut p = w.polys[f].clone();
        for v in &mut p.v {
            *v = map[*v as usize];
        }
        let n = p.v.len();
        for i in 0..n {
            covered.insert(key(p.v[i], p.v[(i + 1) % n]));
        }
        w.polys.push(p);
        new_faces.push((w.polys.len() - 1) as u32);
    }
    for (e, &on) in em.iter().enumerate() {
        if on {
            let [a, b] = topo.edges[e];
            let (da, db) = (map[a as usize], map[b as usize]);
            if !covered.contains(&key(da, db)) {
                w.loose.push([da, db]);
            }
        }
    }
    let m = w.into_mesh();
    let mut selection = Selection::none(m.vert_count());
    for &v in &new_verts {
        selection.set(v, true);
    }
    Ok((m, OpOutput { selection, new_verts, new_faces, ..Default::default() }))
}

/// Split the selection off: returns `(remaining mesh, separated mesh)`.
pub fn separate(mesh: &Mesh, sel: &Selection) -> GeomResult<(Mesh, Mesh)> {
    if !sel.any() {
        return invalid("nothing selected");
    }
    let nv = mesh.vert_count();
    let fm = sel.face_mask(mesh);
    let picked: Vec<bool> = (0..nv).map(|v| sel.is_selected(v as u32)).collect();
    let others: Vec<bool> = picked.iter().map(|&b| !b).collect();
    let both = |e: &[u32; 2]| picked[e[0] as usize] && picked[e[1] as usize];
    let mut a = Work::from_mesh(mesh);
    a.retain_polys(&fm);
    a.loose.retain(|e| both(e));
    a.compact(Some(&others));
    let mut b = Work::from_mesh(mesh);
    let rest: Vec<bool> = fm.iter().map(|&x| !x).collect();
    b.retain_polys(&rest);
    b.loose.retain(|e| !both(e));
    b.compact(Some(&picked));
    Ok((b.into_mesh(), a.into_mesh()))
}

/// Concatenate meshes (vertex indices of later meshes are offset).
pub fn join(meshes: &[&Mesh]) -> Mesh {
    let mut m = Mesh::new();
    for x in meshes {
        m.push_mesh(x);
    }
    m
}

/// Create faces from closed loops of selected boundary edges (or selected wire edges). With `triangulate` the
/// new polygons are split into triangles.
pub fn fill(mesh: &Mesh, sel: &Selection, triangulate: bool, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    let topo = Topology::build(mesh);
    let em = sel.edge_mask(&topo);
    let mut next: HashMap<u32, Vec<(u32, u32)>> = HashMap::new();
    let mut wire: HashMap<u32, Vec<u32>> = HashMap::new();
    for e in 0..topo.edges.len() {
        if !em[e] {
            continue;
        }
        match topo.edge_face_count[e] {
            1 => {
                let c = topo.edge_corner[e];
                if c == NONE {
                    continue;
                }
                let f = topo.face_of_corner[c as usize];
                let r = mesh.face_range(f as usize);
                let k = c as usize - r.start;
                let (a, b) = (mesh.corners[c as usize], mesh.corners[r.start + (k + 1) % r.len()]);
                next.entry(b).or_default().push((a, f));
            }
            0 => {
                let [a, b] = topo.edges[e];
                wire.entry(a).or_default().push(b);
                wire.entry(b).or_default().push(a);
            }
            _ => {}
        }
    }
    let mut loops: Vec<(Vec<u32>, u32)> = Vec::new();
    let mut seen: HashSet<u32> = HashSet::new();
    let mut starts: Vec<u32> = next.keys().copied().collect();
    starts.sort_unstable();
    for s in starts {
        if seen.contains(&s) {
            continue;
        }
        let (mut cur, mut vs, mut ok, mut face0) = (s, Vec::new(), true, NONE);
        loop {
            let Some(t) = next.get(&cur) else {
                ok = false;
                break;
            };
            if t.len() != 1 || seen.contains(&cur) {
                ok = false;
                break;
            }
            seen.insert(cur);
            vs.push(cur);
            if face0 == NONE {
                face0 = t[0].1;
            }
            cur = t[0].0;
            if cur == s {
                break;
            }
        }
        if ok && vs.len() >= 3 {
            loops.push((vs, face0));
        }
    }
    let mut wstarts: Vec<u32> = wire.keys().copied().collect();
    wstarts.sort_unstable();
    let mut wseen: HashSet<u32> = HashSet::new();
    for s in wstarts {
        if wseen.contains(&s) {
            continue;
        }
        let (mut prev, mut cur, mut vs, mut ok) = (NONE, s, Vec::new(), true);
        loop {
            let nb = &wire[&cur];
            if nb.len() != 2 || nb[0] == nb[1] || wseen.contains(&cur) {
                ok = false;
                break;
            }
            wseen.insert(cur);
            vs.push(cur);
            let nxt = if nb[0] != prev { nb[0] } else { nb[1] };
            prev = cur;
            cur = nxt;
            if cur == s {
                break;
            }
        }
        if ok && vs.len() >= 3 {
            let mut nrm = Vec3::ZERO;
            for i in 0..vs.len() {
                let (a, b) = (mesh.positions[vs[i] as usize], mesh.positions[vs[(i + 1) % vs.len()] as usize]);
                nrm = nrm + Vec3::new((a.y - b.y) * (a.z + b.z), (a.z - b.z) * (a.x + b.x), (a.x - b.x) * (a.y + b.y));
            }
            if nrm[nrm.max_abs_axis()] < 0.0 {
                vs.reverse();
            }
            loops.push((vs, NONE));
        }
    }
    if loops.is_empty() {
        return invalid("the selected edges do not form a closed loop that can be filled");
    }
    ctx.ensure_capacity(mesh.vert_count(), mesh.face_count() + loops.iter().map(|l| l.0.len()).sum::<usize>())?;
    let mut w = Work::from_mesh(mesh);
    let has_uv = w.has_uv;
    let uvz = |n: usize| if has_uv { vec![Vec2::ZERO; n] } else { Vec::new() };
    let mut new_faces = Vec::new();
    let mut sel_verts: Vec<u32> = Vec::new();
    for (vs, face0) in loops {
        let (mat, smooth) = if face0 != NONE { (w.polys[face0 as usize].mat, w.polys[face0 as usize].smooth) } else { (0, false) };
        sel_verts.extend_from_slice(&vs);
        if triangulate {
            let pts: Vec<Vec3> = vs.iter().map(|&v| w.pos[v as usize]).collect();
            let mut tris: Vec<[u32; 3]> = Vec::new();
            triangulate_polygon(&pts, &mut tris);
            for t in tris {
                new_faces.push(w.push(vec![vs[t[0] as usize], vs[t[1] as usize], vs[t[2] as usize]], mat, smooth, uvz(3)));
            }
        } else {
            new_faces.push(w.push(vs.clone(), mat, smooth, uvz(vs.len())));
        }
    }
    w.drop_covered_loose();
    let m = w.into_mesh();
    let mut selection = Selection::none(m.vert_count());
    for &v in &sel_verts {
        selection.set(v, true);
    }
    Ok((m, OpOutput { selection, new_faces, ..Default::default() }))
}
