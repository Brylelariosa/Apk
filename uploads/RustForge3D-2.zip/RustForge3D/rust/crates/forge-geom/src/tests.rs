use crate::*;
use forge_math::{Mat4, Vec3};
use forge_mesh::{validate, GeomResult, Mesh, OpCtx, OpOutput, Selection};

fn ctx() -> OpCtx {
    OpCtx::new()
}

fn volume(m: &Mesh) -> f32 {
    let mut v = 0.0;
    for t in m.triangles() {
        let (a, b, c) = (m.positions[t[0] as usize], m.positions[t[1] as usize], m.positions[t[2] as usize]);
        v += a.dot(b.cross(c)) / 6.0;
    }
    v
}

fn solid(m: &Mesh) {
    m.check_structure().unwrap();
    let r = validate(m);
    assert!(r.is_watertight(), "{}", r.summary());
    assert!(volume(m) > 0.0, "volume {}", volume(m));
}

fn face_sel(m: &Mesh, f: usize) -> Selection {
    Selection::from_indices(m.vert_count(), m.face_verts(f).iter().copied())
}

// cube faces: 0 +X, 1 -X, 2 +Y, 3 -Y, 4 +Z, 5 -Z

#[test]
fn extrude_faces_of_cube() {
    let c = cube(2.0, true);
    let (m, out) = extrude_region(&c, &face_sel(&c, 4), &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (12, 10));
    assert_eq!(out.new_verts.len(), 4);
    assert_eq!(out.selection.count(), 4);
    solid(&m);
    let mut up = m.clone();
    for v in out.selection.indices() {
        up.positions[v as usize].z += 1.0;
    }
    solid(&up);
    assert!((volume(&up) - 12.0).abs() < 1e-3, "{}", volume(&up));
    // two adjacent faces extruded as one region share their interior edge
    let two = Selection::from_indices(8, c.face_verts(4).iter().chain(c.face_verts(0).iter()).copied());
    let (m2, _) = extrude_faces(&c, &two, &ctx()).unwrap();
    solid(&m2);
    assert_eq!(m2.face_count(), 6 + 6);
    // individually: no shared walls
    let (m3, _) = extrude_individual_faces(&c, &two, &ctx()).unwrap();
    m3.check_structure().unwrap();
    assert_eq!(m3.face_count(), 6 + 8);
}

#[test]
fn extrude_edges_and_verts() {
    let p = plane(2.0, false);
    let s = Selection::from_indices(4, [0, 1]);
    let (m, out) = extrude_region(&p, &s, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (6, 2));
    assert_eq!(out.new_verts.len(), 2);
    m.check_structure().unwrap();
    let (m, out) = extrude_region(&p, &Selection::from_indices(4, [2]), &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.loose_edges.len()), (5, 1));
    assert_eq!(out.selection.indices(), vec![4]);
}

#[test]
fn inset_keeps_border_width() {
    let c = cube(2.0, true);
    let opts = InsetOpts { thickness: 0.25, ..Default::default() };
    let (m, out) = inset(&c, &face_sel(&c, 4), &opts, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (12, 10));
    for &v in &out.new_verts {
        let p = m.positions[v as usize];
        assert!((p.x.abs() - 0.75).abs() < 1e-4 && (p.y.abs() - 0.75).abs() < 1e-4 && (p.z - 1.0).abs() < 1e-5, "{p:?}");
    }
    solid(&m);
    let deep = InsetOpts { thickness: 0.25, depth: -0.5, ..Default::default() };
    let (m, _) = inset(&c, &face_sel(&c, 4), &deep, &ctx()).unwrap();
    solid(&m);
    assert!((volume(&m) - (8.0 - 9.25 * 0.5 / 3.0)).abs() < 1e-3, "{}", volume(&m));
}

#[test]
fn delete_modes() {
    let c = cube(2.0, false);
    let (m, _) = delete(&c, &face_sel(&c, 4), DeleteMode::Faces, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (8, 5));
    let (m, _) = delete(&c, &face_sel(&c, 4), DeleteMode::OnlyFaces, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (8, 5));
    let (m, out) = delete(&c, &Selection::from_indices(8, [0]), DeleteMode::Vertices, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (7, 3));
    assert_eq!(out.map_vert(0), None);
    m.check_structure().unwrap();
    let (m, _) = delete(&c, &Selection::from_indices(8, [0, 1]), DeleteMode::Edges, &ctx()).unwrap();
    assert_eq!(m.face_count(), 4);
    m.check_structure().unwrap();
    // a lone triangle loses its face but keeps the wire
    let t = Mesh::from_polygons(vec![Vec3::ZERO, Vec3::X, Vec3::Y], &[vec![0, 1, 2]]);
    let (m, _) = delete(&t, &Selection::all(3), DeleteMode::OnlyFaces, &ctx()).unwrap();
    assert_eq!((m.face_count(), m.loose_edges.len()), (0, 3));
}

#[test]
fn dissolving() {
    let c = cube(2.0, false);
    let (m, _) = dissolve_edges(&c, &Selection::from_indices(8, [0, 1]), false, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (8, 5));
    assert_eq!(validate(&m).is_watertight(), true);
    let both = Selection::from_indices(8, c.face_verts(4).iter().chain(c.face_verts(0).iter()).copied());
    let (m, _) = dissolve_faces(&c, &both, false, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (8, 5));
    assert!(m.face_len(0) == 6 || (0..m.face_count()).any(|f| m.face_len(f) == 6));
    // face centres of a subdivided cube have four faces around them
    let (s, _) = subdivide(&c, &Selection::all(8), 1, &ctx()).unwrap();
    assert_eq!((s.vert_count(), s.face_count()), (26, 24));
    let centre = (0..s.vert_count()).find(|&v| s.positions[v].abs().max_element() > 0.99 && (s.positions[v].abs().x == 0.0 || s.positions[v].length() < 1.01) && s.positions[v].length() > 0.99 && s.positions[v].length() < 1.01 && (s.positions[v].x.abs() + s.positions[v].y.abs() + s.positions[v].z.abs()) < 1.01).unwrap();
    let (m, _) = dissolve_verts(&s, &Selection::from_indices(26, [centre as u32]), &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (25, 21));
    m.check_structure().unwrap();
}

#[test]
fn merging() {
    let c = cube(2.0, false);
    let (m, out) = merge(&c, &Selection::from_indices(8, [0, 1]), MergeMode::Center, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (7, 6));
    assert!(m.positions[0].abs_diff_eq(Vec3::new(0.0, -1.0, -1.0), 1e-5));
    assert_eq!(out.map_vert(1), out.map_vert(0));
    solid(&m);
    let j = join(&[&c, &c]);
    let (m, _) = remove_doubles(&j, None, 1e-4, &ctx()).unwrap();
    assert_eq!(m.vert_count(), 8);
    let (m, _) = merge(&c, &Selection::all(8), MergeMode::Collapse, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (1, 0));
}

#[test]
fn duplicate_separate_join_fill() {
    let c = cube(2.0, true);
    let (m, out) = duplicate(&c, &face_sel(&c, 4), &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (12, 7));
    assert_eq!(out.new_verts.len(), 4);
    let (rest, part) = separate(&m, &out.selection).unwrap();
    assert_eq!((part.vert_count(), part.face_count()), (4, 1));
    assert_eq!((rest.vert_count(), rest.face_count()), (8, 6));
    let (open, _) = delete(&c, &face_sel(&c, 4), DeleteMode::Faces, &ctx()).unwrap();
    let (closed, out) = fill(&open, &face_sel(&c, 4), false, &ctx()).unwrap();
    solid(&closed);
    assert_eq!(out.new_faces.len(), 1);
    let (tri, out) = fill(&open, &face_sel(&c, 4), true, &ctx()).unwrap();
    assert_eq!(out.new_faces.len(), 2);
    solid(&tri);
    let ring = circle(8, 1.0, CapFill::Nothing, false, &ctx()).unwrap();
    let (disc, _) = fill(&ring, &Selection::all(8), false, &ctx()).unwrap();
    assert_eq!(disc.face_count(), 1);
    assert!(disc.face_normal(0).z > 0.0);
    assert_eq!(disc.loose_edges.len(), 0);
}

#[test]
fn subdivide_counts() {
    let c = ctx();
    let cube = cube(2.0, true);
    for (cuts, v, f) in [(1u32, 26usize, 24usize), (2, 56, 54), (3, 98, 96)] {
        let (m, out) = subdivide(&cube, &Selection::all(8), cuts, &c).unwrap();
        assert_eq!((m.vert_count(), m.face_count()), (v, f), "cuts {cuts}");
        solid(&m);
        assert_eq!(out.selection.count(), v);
    }
    let ico = ico_sphere(1, 1.0, true, &c).unwrap();
    let (m, _) = subdivide(&ico, &Selection::all(12), 1, &c).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (42, 80));
    solid(&m);
    let (m, _) = subdivide(&ico, &Selection::all(12), 2, &c).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (92, 180));
    solid(&m);
    let ngon = circle(5, 1.0, CapFill::NGon, true, &c).unwrap();
    let (m, _) = subdivide(&ngon, &Selection::all(5), 1, &c).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (11, 5));
    m.check_structure().unwrap();
    // one selected face: its neighbours receive the new edge vertices as n-gons, no T-junctions
    let (m, _) = subdivide(&cube, &face_sel(&cube, 4), 1, &c).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (8 + 4 + 1, 6 - 1 + 4));
    solid(&m);
}

#[test]
fn loop_cut_cube() {
    let c = cube(2.0, true);
    let (m, out) = loop_cut(&c, [0, 1], 1, 0.5, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (12, 10));
    assert_eq!(out.new_verts.len(), 4);
    for &v in &out.new_verts {
        assert!(m.positions[v as usize].x.abs() < 1e-5);
    }
    solid(&m);
    let (m, _) = loop_cut(&c, [0, 1], 3, 0.5, &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (8 + 12, 2 + 16));
    solid(&m);
    let (m, out) = loop_cut(&c, [0, 1], 1, 0.25, &ctx()).unwrap();
    let xs: Vec<f32> = out.new_verts.iter().map(|&v| m.positions[v as usize].x).collect();
    assert!(xs.iter().all(|x| (x - xs[0]).abs() < 1e-5), "{xs:?}");
    solid(&m);
    assert!(loop_cut(&c, [0, 7], 1, 0.5, &ctx()).is_err());
}

#[test]
fn catmull_clark() {
    let c = cube(2.0, true);
    let m1 = subsurf(&c, 1, &ctx()).unwrap();
    assert_eq!((m1.vert_count(), m1.face_count()), (26, 24));
    assert!((m1.positions[7].x - 5.0 / 9.0).abs() < 1e-5);
    solid(&m1);
    let m2 = subsurf(&c, 2, &ctx()).unwrap();
    assert_eq!((m2.vert_count(), m2.face_count()), (98, 96));
    solid(&m2);
    assert!(volume(&m2) < 8.0 && volume(&m2) > 1.5 && volume(&m2) < volume(&m1), "{} {}", volume(&m1), volume(&m2));
    let p = subsurf(&plane(2.0, true), 1, &ctx()).unwrap();
    p.check_structure().unwrap();
    assert_eq!((p.vert_count(), p.face_count()), (9, 4));
}

#[test]
fn mirror_half_box() {
    let mut half = cube(2.0, true);
    half.translate(Vec3::new(1.0, 0.0, 0.0));
    let (open, _) = delete(&half, &face_sel(&half, 1), DeleteMode::Faces, &ctx()).unwrap();
    let (m, out) = mirror(&open, &MirrorOpts::default(), &ctx()).unwrap();
    assert_eq!((m.vert_count(), m.face_count()), (12, 10));
    assert_eq!(out.new_verts.len(), 4);
    solid(&m);
    let (m, _) = mirror(&cube(2.0, false), &MirrorOpts { axes: [true, true, true], merge: false, merge_distance: 0.0 }, &ctx()).unwrap();
    assert_eq!(m.face_count(), 48);
    m.check_structure().unwrap();
}

#[test]
fn normals_and_triangulation() {
    let mut c = cube(2.0, false);
    c.flip_faces(Some(&[true, false, false, true, false, false]));
    assert!(!validate(&c).is_watertight());
    let fixed = recalc_normals(&c, false, &ctx()).unwrap();
    solid(&fixed);
    let inner = recalc_normals(&c, true, &ctx()).unwrap();
    assert!(volume(&inner) < 0.0 && validate(&inner).is_closed());
    let f = flip_normals(&cube(2.0, false), &Selection::all(8));
    assert!(volume(&f) < 0.0);
    let (t, out) = triangulate(&cube(2.0, true), &Selection::all(8), &ctx()).unwrap();
    assert_eq!((t.vert_count(), t.face_count()), (8, 12));
    assert_eq!(out.new_faces.len(), 6);
    solid(&t);
    let s = set_smooth(&cube(2.0, false), &Selection::all(8), true);
    assert!(s.face_smooth.iter().all(|&b| b));
}

#[test]
fn smoothing_and_transform() {
    let c = ctx();
    let ico = ico_sphere(2, 1.0, false, &c).unwrap();
    let sm = smooth_vertices(&ico, &Selection::all(ico.vert_count()), 3, 0.5, &c).unwrap();
    let r = |m: &Mesh| m.positions.iter().map(|p| p.length()).fold(0.0, f32::max);
    assert!(r(&sm) < r(&ico));
    let t = transform_selection(&ico, &Selection::from_indices(ico.vert_count(), [0]), &Mat4::from_translation(Vec3::new(0.0, 0.0, 1.0)));
    assert!((t.positions[0].z - (ico.positions[0].z + 1.0)).abs() < 1e-5);
    assert!((t.positions[1].z - ico.positions[1].z).abs() < 1e-6);
}

#[test]
fn selection_helpers_and_loops() {
    let c = ctx();
    assert_eq!(select_boundary(&plane(2.0, false)).count(), 4);
    assert_eq!(select_boundary(&cube(2.0, false)).count(), 0);
    assert_eq!(select_random(&cube(2.0, false), 1.0, 7).count(), 8);
    assert_eq!(select_random(&cube(2.0, false), 0.0, 7).count(), 0);
    let mut stray = cube(2.0, false);
    stray.add_vertex(Vec3::ZERO);
    assert_eq!(select_loose(&stray).indices(), vec![8]);
    let t = torus(8, 6, 1.0, 0.3, false, &c).unwrap();
    assert_eq!(edge_loop(&t, [0, 1]).unwrap().len(), 6);
    assert_eq!(edge_loop(&t, [0, 6]).unwrap().len(), 8);
    assert_eq!(edge_ring(&t, [0, 1]).unwrap().len(), 8);
    assert!(edge_loop(&t, [0, 20]).is_err());
}

fn lcg(s: &mut u64) -> u64 {
    *s = s.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
    *s >> 33
}

#[test]
fn fuzz_ops_keep_meshes_valid() {
    let c = ctx();
    let bases = vec![
        cube(2.0, true),
        uv_sphere(8, 5, 1.0, true, &c).unwrap(),
        ico_sphere(2, 1.0, false, &c).unwrap(),
        grid(4, 4, 2.0, true, &c).unwrap(),
        torus(8, 5, 1.0, 0.3, false, &c).unwrap(),
        circle(7, 1.0, CapFill::NGon, true, &c).unwrap(),
        cone(6, 1.0, 0.0, 2.0, CapFill::NGon, false, &c).unwrap(),
    ];
    let mut seed = 12345u64;
    for base in &bases {
        for _ in 0..40 {
            let n = base.vert_count();
            let pick = 2 + lcg(&mut seed) % 4;
            let sel = Selection::from_indices(n, (0..n as u32).filter(|_| lcg(&mut seed) % pick == 0));
            let results: Vec<GeomResult<(Mesh, OpOutput)>> = vec![
                extrude_region(base, &sel, &c),
                extrude_individual_faces(base, &sel, &c),
                inset(base, &sel, &InsetOpts::default(), &c),
                inset(base, &sel, &InsetOpts { individual: true, boundary: false, ..Default::default() }, &c),
                delete(base, &sel, DeleteMode::Vertices, &c),
                delete(base, &sel, DeleteMode::Edges, &c),
                delete(base, &sel, DeleteMode::Faces, &c),
                delete(base, &sel, DeleteMode::OnlyFaces, &c),
                dissolve_verts(base, &sel, &c),
                dissolve_edges(base, &sel, true, &c),
                dissolve_faces(base, &sel, true, &c),
                merge(base, &sel, MergeMode::Center, &c),
                merge(base, &sel, MergeMode::Collapse, &c),
                remove_doubles(base, Some(&sel), 0.5, &c),
                duplicate(base, &sel, &c),
                subdivide(base, &sel, 2, &c),
                fill(base, &sel, false, &c),
                fill(base, &sel, true, &c),
                triangulate(base, &sel, &c),
            ];
            for (i, r) in results.into_iter().enumerate() {
                if let Ok((m, out)) = r {
                    m.check_structure().unwrap_or_else(|e| panic!("op #{i}: {e}"));
                    assert_eq!(out.selection.len(), m.vert_count(), "op #{i}");
                }
            }
            let e = base.edge_count();
            assert!(e > 0);
            let m = subsurf(base, 1, &c).unwrap();
            m.check_structure().unwrap();
            let _ = recalc_normals(base, false, &c).unwrap().check_structure().unwrap();
        }
    }
}
