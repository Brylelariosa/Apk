//! Polygon-list working representation shared by the topology operations: easy to edit (push faces, repoint
//! vertices) and converted back to a `Mesh` at the end.
use forge_math::{Vec2, Vec3};
use forge_mesh::{Mesh, NONE};
use std::collections::HashSet;

pub(crate) fn key(a: u32, b: u32) -> (u32, u32) {
    if a < b {
        (a, b)
    } else {
        (b, a)
    }
}

#[derive(Clone, Debug)]
pub(crate) struct Poly {
    pub v: Vec<u32>,
    pub mat: u16,
    pub smooth: bool,
    /// One UV per corner, or empty when the mesh has no UVs.
    pub uv: Vec<Vec2>,
}

pub(crate) struct Work {
    pub pos: Vec<Vec3>,
    pub polys: Vec<Poly>,
    pub loose: Vec<[u32; 2]>,
    pub has_uv: bool,
}

impl Work {
    pub fn from_mesh(m: &Mesh) -> Work {
        let has_uv = !m.corners.is_empty() && m.uvs.len() == m.corners.len();
        let polys = (0..m.face_count())
            .map(|f| {
                let r = m.face_range(f);
                Poly { v: m.corners[r.clone()].to_vec(), mat: m.face_material[f], smooth: m.face_smooth[f], uv: if has_uv { m.uvs[r].to_vec() } else { Vec::new() } }
            })
            .collect();
        Work { pos: m.positions.clone(), polys, loose: m.loose_edges.clone(), has_uv }
    }

    pub fn into_mesh(self) -> Mesh {
        let mut m = Mesh::new();
        m.positions = self.pos;
        for p in self.polys {
            m.corners.extend_from_slice(&p.v);
            m.face_starts.push(m.corners.len() as u32);
            m.face_material.push(p.mat);
            m.face_smooth.push(p.smooth);
            if self.has_uv {
                if p.uv.len() == p.v.len() {
                    m.uvs.extend_from_slice(&p.uv);
                } else {
                    m.uvs.extend(std::iter::repeat(Vec2::ZERO).take(p.v.len()));
                }
            }
        }
        m.loose_edges = self.loose;
        m
    }

    pub fn vert(&mut self, p: Vec3) -> u32 {
        self.pos.push(p);
        (self.pos.len() - 1) as u32
    }

    pub fn push(&mut self, v: Vec<u32>, mat: u16, smooth: bool, uv: Vec<Vec2>) -> u32 {
        self.polys.push(Poly { v, mat, smooth, uv });
        (self.polys.len() - 1) as u32
    }

    /// Drop polygons whose `keep` flag is false; returns the old -> new face map (`NONE` = dropped).
    pub fn retain_polys(&mut self, keep: &[bool]) -> Vec<u32> {
        let mut map = vec![NONE; self.polys.len()];
        let mut out = Vec::with_capacity(self.polys.len());
        for (i, p) in std::mem::take(&mut self.polys).into_iter().enumerate() {
            if keep[i] {
                map[i] = out.len() as u32;
                out.push(p);
            }
        }
        self.polys = out;
        map
    }

    /// Remove vertices that nothing uses. With `candidates`, only flagged vertices may be removed. Returns old -> new.
    pub fn compact(&mut self, candidates: Option<&[bool]>) -> Vec<u32> {
        let n = self.pos.len();
        let mut used = vec![false; n];
        for p in &self.polys {
            for &v in &p.v {
                used[v as usize] = true;
            }
        }
        for e in &self.loose {
            used[e[0] as usize] = true;
            used[e[1] as usize] = true;
        }
        let remove: Vec<bool> = (0..n).map(|v| !used[v] && candidates.map_or(true, |c| c[v])).collect();
        self.remove_verts(&remove)
    }

    /// Remove flagged vertices (which must be unused) and remap everything. Returns old -> new.
    pub fn remove_verts(&mut self, remove: &[bool]) -> Vec<u32> {
        let mut map = vec![NONE; self.pos.len()];
        let mut pos = Vec::with_capacity(self.pos.len());
        for (i, p) in self.pos.iter().enumerate() {
            if !remove[i] {
                map[i] = pos.len() as u32;
                pos.push(*p);
            }
        }
        self.pos = pos;
        for p in &mut self.polys {
            for v in &mut p.v {
                *v = map[*v as usize];
            }
        }
        self.loose.retain(|e| map[e[0] as usize] != NONE && map[e[1] as usize] != NONE);
        for e in &mut self.loose {
            *e = [map[e[0] as usize], map[e[1] as usize]];
        }
        map
    }
}

impl Work {
    /// Loose edges that have become an edge of a polygon stop being loose.
    pub fn drop_covered_loose(&mut self) {
        if self.loose.is_empty() {
            return;
        }
        let mut set: HashSet<(u32, u32)> = HashSet::new();
        for p in &self.polys {
            let n = p.v.len();
            for i in 0..n {
                set.insert(key(p.v[i], p.v[(i + 1) % n]));
            }
        }
        self.loose.retain(|e| !set.contains(&key(e[0], e[1])));
    }
}
