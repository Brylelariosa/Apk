//! Mirror, normals, smoothing, triangulation and selection helpers.
use crate::subdivide::walk_ring;
use forge_math::{Mat4, Vec3};
use forge_mesh::{GeomError, GeomResult, Mesh, OpCtx, OpOutput, Selection, Topology, NONE};
use std::collections::HashSet;

fn invalid<T>(msg: &str) -> GeomResult<T> {
    Err(GeomError::InvalidInput(msg.to_string()))
}

#[derive(Clone, Copy, Debug)]
pub struct MirrorOpts {
    /// Mirror across the local YZ / XZ / XY plane through the origin.
    pub axes: [bool; 3],
    /// Weld vertices within `merge_distance` of the mirror plane to their mirror image (and snap them to the plane).
    pub merge: bool,
    pub merge_distance: f32,
}

impl Default for MirrorOpts {
    fn default() -> Self {
        MirrorOpts { axes: [true, false, false], merge: true, merge_distance: 0.001 }
    }
}

/// Mirror modifier / operator: appends a mirrored copy (with flipped winding) for each enabled axis.
pub fn mirror(mesh: &Mesh, opts: &MirrorOpts, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    if !opts.merge_distance.is_finite() || opts.merge_distance < 0.0 {
        return invalid("merge distance must be a non-negative number");
    }
    let (nv0, nf0) = (mesh.vert_count(), mesh.face_count());
    let mut cur = mesh.clone();
    for axis in 0..3 {
        if !opts.axes[axis] {
            continue;
        }
        ctx.check()?;
        let n = cur.vert_count();
        ctx.ensure_capacity(n * 2, cur.face_count() * 2)?;
        let mut copy = cur.clone();
        for p in &mut copy.positions {
            p[axis] = -p[axis];
        }
        copy.flip_all_faces();
        let mut map: Vec<u32> = Vec::with_capacity(n);
        let mut extra: Vec<Vec3> = Vec::new();
        let mut next = n as u32;
        for v in 0..n {
            if opts.merge && cur.positions[v][axis].abs() <= opts.merge_distance {
                cur.positions[v][axis] = 0.0;
                map.push(v as u32);
            } else {
                map.push(next);
                next += 1;
                extra.push(copy.positions[v]);
            }
        }
        let base = *cur.face_starts.last().unwrap_or(&0);
        cur.positions.extend(extra);
        cur.corners.extend(copy.corners.iter().map(|&v| map[v as usize]));
        cur.face_starts.extend(copy.face_starts.iter().skip(1).map(|s| s + base));
        cur.face_material.extend_from_slice(&copy.face_material);
        cur.face_smooth.extend_from_slice(&copy.face_smooth);
        cur.loose_edges.extend(copy.loose_edges.iter().map(|e| [map[e[0] as usize], map[e[1] as usize]]));
        if !copy.uvs.is_empty() {
            cur.uvs.extend_from_slice(&copy.uvs);
        }
    }
    let out = OpOutput {
        selection: Selection::none(cur.vert_count()),
        new_verts: (nv0 as u32..cur.vert_count() as u32).collect(),
        new_faces: (nf0 as u32..cur.face_count() as u32).collect(),
        ..Default::default()
    };
    Ok((cur, out))
}

/// Reverse the winding of the selected faces.
pub fn flip_normals(mesh: &Mesh, sel: &Selection) -> Mesh {
    let mut m = mesh.clone();
    let fm = sel.face_mask(mesh);
    m.flip_faces(Some(fm.as_slice()));
    m
}

/// Make the winding consistent in every connected component and point it outwards (`inside` = inwards).
/// Open components without a meaningful volume only get a consistent winding.
pub fn recalc_normals(mesh: &Mesh, inside: bool, ctx: &OpCtx) -> GeomResult<Mesh> {
    ctx.check()?;
    let nf = mesh.face_count();
    if nf == 0 {
        return Ok(mesh.clone());
    }
    let topo = Topology::build(mesh);
    let mut flip = vec![false; nf];
    let mut comp = vec![NONE; nf];
    let mut ncomp = 0u32;
    let mut stack: Vec<usize> = Vec::new();
    for s in 0..nf {
        if comp[s] != NONE {
            continue;
        }
        comp[s] = ncomp;
        stack.push(s);
        while let Some(f) = stack.pop() {
            ctx.poll(f)?;
            for &e in topo.face_edges(mesh, f) {
                if e == NONE || topo.edge_face_count[e as usize] != 2 {
                    continue;
                }
                let ef = topo.edge_faces[e as usize];
                let g = if ef[0] as usize == f { ef[1] } else { ef[0] };
                if g == NONE || comp[g as usize] != NONE {
                    continue;
                }
                comp[g as usize] = ncomp;
                flip[g as usize] = flip[f] ^ topo.winding_conflict[e as usize];
                stack.push(g as usize);
            }
        }
        ncomp += 1;
    }
    let nc = ncomp as usize;
    let mut centroid = vec![Vec3::ZERO; nc];
    let mut count = vec![0f32; nc];
    for f in 0..nf {
        let c = comp[f] as usize;
        for &v in mesh.face_verts(f) {
            centroid[c] = centroid[c] + mesh.positions[v as usize];
            count[c] += 1.0;
        }
    }
    for c in 0..nc {
        centroid[c] = centroid[c] * (1.0 / count[c].max(1.0));
    }
    let mut vol = vec![0f32; nc];
    let mut area = vec![0f32; nc];
    let mut tris: Vec<[u32; 3]> = Vec::new();
    for f in 0..nf {
        tris.clear();
        mesh.triangulate_face(f, &mut tris);
        let c = comp[f] as usize;
        let s = if flip[f] { -1.0 } else { 1.0 };
        for t in &tris {
            let p = |k: usize| mesh.positions[mesh.corners[t[k] as usize] as usize] - centroid[c];
            vol[c] += s * p(0).dot(p(1).cross(p(2))) / 6.0;
        }
        area[c] += mesh.face_area(f);
    }
    let mut mask = flip;
    for f in 0..nf {
        let c = comp[f] as usize;
        let eps = 1e-6 * area[c].max(1e-12).powf(1.5);
        let wrong = if inside { vol[c] > eps } else { vol[c] < -eps };
        if wrong {
            mask[f] = !mask[f];
        }
    }
    let mut out = mesh.clone();
    out.flip_faces(Some(mask.as_slice()));
    Ok(out)
}

/// Set the smooth-shading flag of every selected face.
pub fn set_smooth(mesh: &Mesh, sel: &Selection, smooth: bool) -> Mesh {
    let mut m = mesh.clone();
    let fm = sel.face_mask(mesh);
    for f in 0..m.face_count() {
        if fm[f] {
            m.face_smooth[f] = smooth;
        }
    }
    m
}

/// Laplacian smoothing of the selected vertices. Border vertices only slide along the border.
pub fn smooth_vertices(mesh: &Mesh, sel: &Selection, iterations: u32, factor: f32, ctx: &OpCtx) -> GeomResult<Mesh> {
    if iterations > 1000 {
        return invalid("too many smoothing iterations (max 1000)");
    }
    let topo = Topology::build(mesh);
    let nv = mesh.vert_count();
    let mut border = vec![false; nv];
    for e in 0..topo.edges.len() {
        if topo.edge_face_count[e] != 2 {
            for &v in &topo.edges[e] {
                border[v as usize] = true;
            }
        }
    }
    let picked = sel.indices();
    let mut out = mesh.clone();
    for _ in 0..iterations {
        ctx.check()?;
        let src = out.positions.clone();
        for &v in &picked {
            let v = v as usize;
            let (mut sum, mut n) = (Vec3::ZERO, 0.0f32);
            for &e in topo.vert_edges.get(v) {
                if border[v] && topo.edge_face_count[e as usize] == 2 {
                    continue;
                }
                sum = sum + src[topo.other_vertex(e, v as u32) as usize];
                n += 1.0;
            }
            if n > 0.0 {
                out.positions[v] = src[v].lerp(sum * (1.0 / n), factor);
            }
        }
    }
    Ok(out)
}

/// Apply a matrix to the selected vertices (compose pivot / orientation into `m` beforehand).
pub fn transform_selection(mesh: &Mesh, sel: &Selection, m: &Mat4) -> Mesh {
    let mut out = mesh.clone();
    for v in sel.indices() {
        let p = out.positions[v as usize];
        out.positions[v as usize] = m.transform_point3(p);
    }
    out
}

/// Split the selected faces into triangles (the first triangle keeps the face index).
pub fn triangulate(mesh: &Mesh, sel: &Selection, ctx: &OpCtx) -> GeomResult<(Mesh, OpOutput)> {
    ctx.check()?;
    let fm = sel.face_mask(mesh);
    let nf = mesh.face_count();
    let uvs = !mesh.uvs.is_empty() && mesh.uvs.len() == mesh.corners.len();
    let mut m = Mesh::new();
    m.positions = mesh.positions.clone();
    m.loose_edges = mesh.loose_edges.clone();
    let mut face_map = vec![NONE; nf];
    let mut new_faces = Vec::new();
    let mut tris: Vec<[u32; 3]> = Vec::new();
    for f in 0..nf {
        ctx.poll(f)?;
        face_map[f] = m.face_count() as u32;
        let r = mesh.face_range(f);
        let (mat, smooth) = (mesh.face_material[f], mesh.face_smooth[f]);
        tris.clear();
        if fm[f] && r.len() > 3 {
            mesh.triangulate_face(f, &mut tris);
        }
        if tris.is_empty() {
            m.corners.extend_from_slice(&mesh.corners[r.clone()]);
            if uvs {
                m.uvs.extend_from_slice(&mesh.uvs[r]);
            }
            m.face_starts.push(m.corners.len() as u32);
            m.face_material.push(mat);
            m.face_smooth.push(smooth);
            continue;
        }
        for (k, t) in tris.iter().enumerate() {
            if k > 0 {
                new_faces.push(m.face_count() as u32);
            }
            for &c in t {
                m.corners.push(mesh.corners[c as usize]);
                if uvs {
                    m.uvs.push(mesh.uvs[c as usize]);
                }
            }
            m.face_starts.push(m.corners.len() as u32);
            m.face_material.push(mat);
            m.face_smooth.push(smooth);
        }
    }
    Ok((m, OpOutput { selection: sel.clone(), new_faces, face_map, ..Default::default() }))
}

/// Vertices on open boundaries.
pub fn select_boundary(mesh: &Mesh) -> Selection {
    let topo = Topology::build(mesh);
    let mut s = Selection::none(mesh.vert_count());
    for e in 0..topo.edges.len() {
        if topo.edge_face_count[e] == 1 {
            for &v in &topo.edges[e] {
                s.set(v, true);
            }
        }
    }
    s
}

/// Vertices on edges shared by more than two faces.
pub fn select_non_manifold(mesh: &Mesh) -> Selection {
    let topo = Topology::build(mesh);
    let mut s = Selection::none(mesh.vert_count());
    for e in 0..topo.edges.len() {
        if topo.edge_face_count[e] > 2 {
            for &v in &topo.edges[e] {
                s.set(v, true);
            }
        }
    }
    s
}

/// Vertices that belong to no face.
pub fn select_loose(mesh: &Mesh) -> Selection {
    let topo = Topology::build(mesh);
    let mut s = Selection::none(mesh.vert_count());
    for v in 0..mesh.vert_count() {
        if topo.vert_faces.get(v).is_empty() {
            s.set(v as u32, true);
        }
    }
    s
}

/// Select roughly `ratio` of the vertices pseudo-randomly (deterministic for a seed).
pub fn select_random(mesh: &Mesh, ratio: f32, seed: u64) -> Selection {
    let mut s = Selection::none(mesh.vert_count());
    let mut x = seed.wrapping_mul(0x9E37_79B9_7F4A_7C15) | 1;
    for v in 0..mesh.vert_count() {
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        if ((x >> 11) as f64 / (1u64 << 53) as f64) < ratio as f64 {
            s.set(v as u32, true);
        }
    }
    s
}

fn edge_id(topo: &Topology, edge: [u32; 2]) -> GeomResult<u32> {
    topo.edge_between(edge[0], edge[1]).ok_or_else(|| GeomError::InvalidInput("the two vertices are not joined by an edge".into()))
}

fn next_loop_edge(topo: &Topology, e: u32, v: u32) -> Option<u32> {
    let around = topo.vert_edges.get(v as usize);
    if topo.edge_face_count[e as usize] == 1 {
        let mut it = around.iter().copied().filter(|&c| c != e && topo.edge_face_count[c as usize] == 1);
        let n = it.next()?;
        return if it.next().is_none() { Some(n) } else { None };
    }
    if around.len() != 4 || around.iter().any(|&c| topo.edge_face_count[c as usize] != 2) {
        return None;
    }
    let faces = topo.edge_faces[e as usize];
    let mut cand = around.iter().copied().filter(|&c| {
        let cf = topo.edge_faces[c as usize];
        c != e && !faces.iter().any(|f| *f != NONE && cf.contains(f))
    });
    let n = cand.next()?;
    if cand.next().is_none() {
        Some(n)
    } else {
        None
    }
}

/// The edge loop through an edge (continues straight through 4-valent vertices and along open borders).
pub fn edge_loop(mesh: &Mesh, edge: [u32; 2]) -> GeomResult<Vec<[u32; 2]>> {
    let topo = Topology::build(mesh);
    let e0 = edge_id(&topo, edge)?;
    let mut seen: HashSet<u32> = HashSet::new();
    seen.insert(e0);
    let mut out = vec![e0];
    for end in [topo.edges[e0 as usize][1], topo.edges[e0 as usize][0]] {
        let (mut e, mut v) = (e0, end);
        while let Some(n) = next_loop_edge(&topo, e, v) {
            if !seen.insert(n) {
                break;
            }
            out.push(n);
            v = topo.other_vertex(n, v);
            e = n;
        }
    }
    Ok(out.iter().map(|&e| topo.edges[e as usize]).collect())
}

/// The edge ring through an edge: the parallel edges of the quads it crosses.
pub fn edge_ring(mesh: &Mesh, edge: [u32; 2]) -> GeomResult<Vec<[u32; 2]>> {
    let topo = Topology::build(mesh);
    let e0 = edge_id(&topo, edge)?;
    let ring = walk_ring(mesh, &topo, e0);
    Ok(ring.edges.iter().map(|&(e, _)| topo.edges[e as usize]).collect())
}
