//! Modifier evaluation and schemas. Modifiers are non-destructive: the object keeps its base mesh and the
//! viewport shows `evaluate(base, modifiers)`.
#![forbid(unsafe_code)]

use forge_geom::{mirror, subsurf, MirrorOpts};
use forge_json::Json;
use forge_mesh::{GeomResult, Mesh, OpCtx};
use forge_scene::{merge_values, ModKind, Modifier, ParamDef, Params};
use std::borrow::Cow;

pub const TYPES: &[(&str, &str)] = &[("MIRROR", "Mirror"), ("SUBSURF", "Subdivision Surface")];

/// Apply one modifier.
pub fn apply(mesh: &Mesh, kind: &ModKind, ctx: &OpCtx) -> GeomResult<Mesh> {
    match kind {
        ModKind::Mirror { axes, merge, merge_distance } => Ok(mirror(mesh, &MirrorOpts { axes: *axes, merge: *merge, merge_distance: *merge_distance }, ctx)?.0),
        ModKind::Subsurf { levels } => {
            let mut m = subsurf(mesh, *levels, ctx)?;
            for s in &mut m.face_smooth {
                *s = true;
            }
            Ok(m)
        }
    }
}

/// The whole stack. With `viewport` only modifiers that are enabled in the viewport are applied.
pub fn evaluate<'a>(mesh: &'a Mesh, mods: &[Modifier], viewport: bool, ctx: &OpCtx) -> GeomResult<Cow<'a, Mesh>> {
    let mut cur: Cow<'a, Mesh> = Cow::Borrowed(mesh);
    for m in mods {
        if viewport && !m.show_viewport {
            continue;
        }
        cur = Cow::Owned(apply(&cur, &m.kind, ctx)?);
    }
    Ok(cur)
}

pub fn defs(type_name: &str) -> Vec<ParamDef> {
    match type_name {
        "MIRROR" => vec![
            ParamDef::boolean("use_axis_x", "X", true),
            ParamDef::boolean("use_axis_y", "Y", false),
            ParamDef::boolean("use_axis_z", "Z", false),
            ParamDef::boolean("use_mirror_merge", "Merge", true),
            ParamDef::float("merge_threshold", "Merge Distance", 0.001).range(0.0, 1.0).step(0.001).length().visible_if("use_mirror_merge", true),
        ],
        "SUBSURF" => vec![ParamDef::int("levels", "Levels", 1).range(0.0, 6.0)],
        _ => Vec::new(),
    }
}

/// Current parameter values of a modifier as a protocol object.
pub fn values(kind: &ModKind) -> Json {
    match kind {
        ModKind::Mirror { axes, merge, merge_distance } => Json::obj()
            .set("use_axis_x", axes[0])
            .set("use_axis_y", axes[1])
            .set("use_axis_z", axes[2])
            .set("use_mirror_merge", *merge)
            .set("merge_threshold", *merge_distance),
        ModKind::Subsurf { levels } => Json::obj().set("levels", *levels),
    }
}

/// Apply a `{"name": value}` patch to a modifier.
pub fn set_params(kind: &mut ModKind, patch: &Json) {
    let d = defs(kind.type_name());
    let merged = merge_values(&d, &values(kind), patch);
    let p = Params::new(&d, &merged);
    match kind {
        ModKind::Mirror { axes, merge, merge_distance } => {
            *axes = [p.b("use_axis_x"), p.b("use_axis_y"), p.b("use_axis_z")];
            *merge = p.b("use_mirror_merge");
            *merge_distance = p.f("merge_threshold") as f32;
        }
        ModKind::Subsurf { levels } => *levels = p.i("levels") as u32,
    }
}

/// A new modifier of the given type with a name that is unique within `existing`.
pub fn new_modifier(type_name: &str, existing: &[Modifier]) -> Option<Modifier> {
    let (kind, base) = match type_name {
        "MIRROR" => (ModKind::Mirror { axes: [true, false, false], merge: true, merge_distance: 0.001 }, "Mirror"),
        "SUBSURF" => (ModKind::Subsurf { levels: 1 }, "Subdivision"),
        _ => return None,
    };
    let mut name = base.to_string();
    let mut i = 1;
    while existing.iter().any(|m| m.name == name) {
        name = format!("{base}.{i:03}");
        i += 1;
    }
    Some(Modifier { name, show_viewport: true, kind })
}

#[cfg(test)]
mod tests {
    use super::*;
    use forge_geom::{cube, plane};

    #[test]
    fn stack_evaluates_in_order() {
        let c = OpCtx::new();
        let mut half = plane(2.0, false);
        half.translate(forge_math::Vec3::new(1.0, 0.0, 0.0));
        let mods = vec![new_modifier("MIRROR", &[]).unwrap(), new_modifier("SUBSURF", &[]).unwrap()];
        let out = evaluate(&half, &mods, true, &c).unwrap();
        assert!(out.face_count() > 4 && out.face_smooth.iter().all(|&s| s));
        let none = evaluate(&half, &[], true, &c).unwrap();
        assert!(matches!(none, Cow::Borrowed(_)));
        let mut hidden = mods.clone();
        hidden[1].show_viewport = false;
        assert_eq!(evaluate(&half, &hidden, true, &c).unwrap().face_count(), 2);
        assert_eq!(evaluate(&half, &hidden, false, &c).unwrap().face_count() > 2, true);
        assert_eq!(evaluate(&cube(2.0, false), &mods[1..], true, &c).unwrap().face_count(), 24);
    }

    #[test]
    fn params_roundtrip_and_clamp() {
        let mut k = ModKind::Subsurf { levels: 1 };
        set_params(&mut k, &Json::parse(r#"{"levels": 99}"#).unwrap());
        assert_eq!(k, ModKind::Subsurf { levels: 6 });
        let mut m = ModKind::Mirror { axes: [true, false, false], merge: true, merge_distance: 0.001 };
        set_params(&mut m, &Json::parse(r#"{"use_axis_y": true, "use_axis_x": false, "merge_threshold": 0.5}"#).unwrap());
        assert_eq!(m, ModKind::Mirror { axes: [false, true, false], merge: true, merge_distance: 0.5 });
        assert_eq!(new_modifier("MIRROR", &[Modifier { name: "Mirror".into(), show_viewport: true, kind: m }]).unwrap().name, "Mirror.001");
    }
}
