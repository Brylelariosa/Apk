//! Data handed from the engine to the platform renderer once per frame. Plain data, no GPU types.
//! Frozen contract between `forge-engine` (producer) and `rustforge` (wgpu consumer).
use std::sync::Arc;

pub use forge_mesh::{RenderBuffers, RenderVertex, SubMesh};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ShadingMode {
    Solid,
    Wireframe,
    Material,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WireMode {
    None,
    /// Solid surface with its edges drawn on top.
    Overlay,
    /// Edges only.
    Only,
}

#[derive(Clone, Debug, PartialEq)]
pub struct MaterialData {
    /// Linear RGBA; `a < 1` means alpha blended.
    pub base_color: [f32; 4],
    pub metallic: f32,
    pub roughness: f32,
    /// Linear RGB, already multiplied by the emission strength.
    pub emissive: [f32; 3],
}
impl Default for MaterialData {
    fn default() -> Self {
        MaterialData { base_color: [0.8, 0.8, 0.8, 1.0], metallic: 0.0, roughness: 0.5, emissive: [0.0; 3] }
    }
}

/// GPU buffer maintenance, applied in order before drawing.
#[derive(Clone, Debug)]
pub enum MeshUpdate {
    /// (Re)create the GPU buffers of `key` from scratch. Drop the `Arc` after uploading.
    Upload { key: u64, buffers: Arc<RenderBuffers> },
    /// Overwrite render vertices `first..first+vertices.len()` of an existing mesh (position/normal edits).
    Patch { key: u64, first: u32, vertices: Vec<RenderVertex> },
    Remove { key: u64 },
}

#[derive(Clone, Debug)]
pub struct DrawItem {
    pub mesh_key: u64,
    /// Column-major model matrix.
    pub model: [f32; 16],
    /// Indexed by `SubMesh::material` (missing entries -> `MaterialData::default()`).
    pub materials: Vec<MaterialData>,
    pub selected: bool,
    pub active: bool,
    pub wire: WireMode,
    /// Draw semi-transparent without depth write (x-ray display).
    pub xray: bool,
}

/// Depth-tested / overlay line or triangle vertex (28 bytes).
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct LineVertex {
    pub position: [f32; 3],
    pub color: [f32; 4],
}

/// Camera-facing square marker (e.g. mesh vertices in edit mode), 32 bytes.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct PointInstance {
    pub position: [f32; 3],
    pub size_px: f32,
    pub color: [f32; 4],
}

/// 2D overlay vertex in pixels (origin top-left), 24 bytes.
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct ScreenVertex {
    pub position: [f32; 2],
    pub color: [f32; 4],
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LightKind {
    Sun,
    Point,
    Spot,
}

#[derive(Clone, Debug, PartialEq)]
pub struct LightData {
    pub kind: LightKind,
    pub position: [f32; 3],
    /// Direction the light travels (sun / spot).
    pub direction: [f32; 3],
    pub color: [f32; 3],
    /// Renderer-ready intensity (engine converts from Blender watts / strength).
    pub intensity: f32,
    /// Spot cone half-angle cosines (inner, outer); ignored for other kinds.
    pub spot_cos: [f32; 2],
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct FrameStats {
    pub objects: u32,
    pub triangles: u64,
}

/// Measured by the render thread and reported back to the engine (`Engine::report_render_stats`), e.g. for the
/// stats overlay and the "auto" viewport quality.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct RenderStats {
    /// "Vulkan" or "OpenGL ES".
    pub backend: String,
    pub fps: f32,
    pub frame_ms: f32,
    pub gpu_mb: f32,
    /// MSAA sample count actually in use.
    pub msaa: u32,
}

#[derive(Clone, Debug)]
pub struct RenderFrame {
    pub width: u32,
    pub height: u32,
    /// Column-major, right-handed, depth 0..1, world is Z-up.
    pub view: [f32; 16],
    pub proj: [f32; 16],
    pub eye: [f32; 3],
    pub clear_color: [f32; 4],
    pub ambient: [f32; 3],
    /// At most 8 are used by the renderer.
    pub lights: Vec<LightData>,
    pub shading: ShadingMode,
    /// Requested MSAA sample count (1 or 4); the renderer falls back if unsupported.
    pub msaa_samples: u32,
    /// Internal render resolution factor (0.5..=1.0).
    pub resolution_scale: f32,
    pub mesh_updates: Vec<MeshUpdate>,
    pub items: Vec<DrawItem>,
    /// Depth-tested line list (pairs): grid, axes, edit-mode edges, selection outlines.
    pub lines: Vec<LineVertex>,
    /// Always-on-top line list (pairs): transform gizmo.
    pub overlay_lines: Vec<LineVertex>,
    /// Always-on-top alpha-blended triangle list: gizmo fills.
    pub overlay_triangles: Vec<LineVertex>,
    /// Depth-tested alpha-blended triangle list (selected faces in edit mode); the renderer applies a depth bias.
    pub tris: Vec<LineVertex>,
    /// Depth-tested point markers.
    pub points: Vec<PointInstance>,
    /// 2D line list in pixels (rubber band selection, brush circle).
    pub screen_lines: Vec<ScreenVertex>,
    pub stats: FrameStats,
}

impl RenderFrame {
    /// Empty frame with sane defaults (identity camera is *not* sane; callers set view/proj).
    pub fn empty(width: u32, height: u32) -> RenderFrame {
        let id = forge_math::Mat4::IDENTITY.to_cols_array();
        RenderFrame {
            width,
            height,
            view: id,
            proj: id,
            eye: [0.0; 3],
            clear_color: [0.23, 0.23, 0.25, 1.0],
            ambient: [0.25, 0.25, 0.28],
            lights: Vec::new(),
            shading: ShadingMode::Solid,
            msaa_samples: 1,
            resolution_scale: 1.0,
            mesh_updates: Vec::new(),
            items: Vec::new(),
            lines: Vec::new(),
            overlay_lines: Vec::new(),
            overlay_triangles: Vec::new(),
            tris: Vec::new(),
            points: Vec::new(),
            screen_lines: Vec::new(),
            stats: FrameStats::default(),
        }
    }
}
