//! End-to-end host tests: the same entry points the Android layer uses (touch, call, poll, build_frame).
use super::*;
use forge_math::Vec3;

fn temp_dir(tag: &str) -> String {
    let n = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
    let p = std::env::temp_dir().join(format!("rforge-test-{tag}-{n}"));
    p.to_string_lossy().to_string()
}

fn engine() -> Engine {
    let mut e = Engine::new(&temp_dir("e"), 2.0);
    e.set_viewport(1000, 700);
    e
}

fn path<'a>(j: &'a Json, p: &str) -> &'a Json {
    let mut cur = j;
    for part in p.split('.') {
        cur = match part.parse::<usize>() {
            Ok(i) => cur.at(i).unwrap_or_else(|| panic!("no index {i} in '{p}'")),
            Err(_) => cur.get(part).unwrap_or_else(|| panic!("no key '{part}' in '{p}'")),
        };
    }
    cur
}

fn call(e: &mut Engine, method: &str, args: &str) -> Json {
    let r = Json::parse(&e.call(method, args)).expect("call returns json");
    assert_eq!(r.get_bool("ok"), Some(true), "{method} {args} failed: {r}");
    r
}

fn call_err(e: &mut Engine, method: &str, args: &str) -> String {
    let r = Json::parse(&e.call(method, args)).expect("call returns json");
    assert_eq!(r.get_bool("ok"), Some(false), "{method} {args} unexpectedly succeeded: {r}");
    r.get_str("error").unwrap_or("").to_string()
}

fn snap(e: &Engine) -> Json {
    e.snapshot()
}

fn touch(e: &mut Engine, action: i32, index: i32, ptrs: &[(i32, f32, f32)]) {
    let pointers = ptrs.iter().map(|&(id, x, y)| TouchPointer::finger(id, x, y)).collect();
    e.touch(&TouchBatch::new(action, index, pointers));
}

fn tap(e: &mut Engine, p: [f32; 2]) {
    touch(e, 0, 0, &[(0, p[0], p[1])]);
    touch(e, 1, 0, &[(0, p[0], p[1])]);
}

fn drag(e: &mut Engine, from: [f32; 2], to: [f32; 2]) {
    touch(e, 0, 0, &[(0, from[0], from[1])]);
    let steps = 12;
    for i in 1..=steps {
        let t = i as f32 / steps as f32;
        touch(e, 2, 0, &[(0, from[0] + (to[0] - from[0]) * t, from[1] + (to[1] - from[1]) * t)]);
    }
    touch(e, 1, 0, &[(0, to[0], to[1])]);
}

fn f32s(j: &Json) -> Vec<f32> {
    j.as_arr().unwrap().iter().map(|v| v.as_f32().unwrap()).collect()
}

#[test]
fn first_snapshot_describes_the_default_scene() {
    let mut e = engine();
    let s = Json::parse(&e.poll().expect("first poll returns a snapshot")).unwrap();
    assert_eq!(path(&s, "mode").as_str(), Some("object"));
    assert_eq!(path(&s, "tool").as_str(), Some("select"));
    assert_eq!(path(&s, "scene.objects").as_arr().unwrap().len(), 1);
    assert_eq!(path(&s, "scene.objects.0.kind").as_str(), Some("mesh"));
    assert_eq!(path(&s, "stats.tris").as_i64(), Some(12));
    assert_eq!(path(&s, "active.mesh.verts").as_i64(), Some(8));
    assert_eq!(path(&s, "script.available").as_bool(), Some(false));
    assert!(e.poll().is_none(), "nothing changed since the last poll");
    call(&mut e, "view.set", r#"{"grid":false}"#);
    assert!(e.poll().is_some());
}

#[test]
fn bad_calls_report_errors_instead_of_panicking() {
    let mut e = engine();
    assert!(call_err(&mut e, "no.such.method", "{}").contains("unknown method"));
    assert!(call_err(&mut e, "select.mode", r#"{"mode":"sphere"}"#).contains("vertex"));
    assert!(call_err(&mut e, "view.set", "{not json").contains("invalid arguments"));
    assert!(call_err(&mut e, "mode.set", r#"{"mode":"sculpt"}"#).to_lowercase().contains("sculpt"));
    assert!(call_err(&mut e, "tool.set", r#"{"tool":"extrude"}"#).contains("Edit Mode"));
    assert!(call_err(&mut e, "undo", "").contains("Nothing to undo"));
    assert!(call_err(&mut e, "script.run", r#"{"code":"print(1)"}"#).contains("not part of this build"));
}

#[test]
fn edit_mode_extrude_undo_redo() {
    let mut e = engine();
    call(&mut e, "mode.set", r#"{"mode":"edit"}"#);
    call(&mut e, "select.mode", r#"{"mode":"face"}"#);
    // tap the top face of the cube
    let top = e.m.camera.project_px(Vec3::new(0.0, 0.0, 1.0)).unwrap();
    tap(&mut e, top);
    let s = snap(&e);
    assert_eq!(path(&s, "edit.faces.selected").as_i64(), Some(1), "tap picks the face under the finger");
    call(&mut e, "tool.set", r#"{"tool":"extrude"}"#);
    let s = snap(&e);
    assert_eq!(path(&s, "tool").as_str(), Some("move"), "extrude hands over to the move gizmo");
    assert_eq!(path(&s, "active.mesh.verts").as_i64(), Some(12));
    assert_eq!(path(&s, "undo.can_undo").as_bool(), Some(true));
    call(&mut e, "undo", "");
    assert_eq!(path(&snap(&e), "active.mesh.verts").as_i64(), Some(8));
    call(&mut e, "redo", "");
    assert_eq!(path(&snap(&e), "active.mesh.verts").as_i64(), Some(12));
    call(&mut e, "mode.set", r#"{"mode":"object"}"#);
    assert_eq!(path(&snap(&e), "mode").as_str(), Some("object"));
}

#[test]
fn extruding_every_face_of_a_closed_mesh_keeps_it_closed() {
    // like Blender: with no boundary there is nothing to bridge, the region just moves
    let mut e = engine();
    call(&mut e, "mode.set", r#"{"mode":"edit"}"#);
    call(&mut e, "select.mode", r#"{"mode":"face"}"#);
    call(&mut e, "select.all", "");
    call(&mut e, "tool.set", r#"{"tool":"extrude"}"#);
    let s = snap(&e);
    assert_eq!(path(&s, "active.mesh.valid").as_bool(), Some(true));
    assert_eq!(path(&s, "active.mesh.faces").as_i64(), Some(6));
}

#[test]
fn op_redo_adjusts_the_last_operator_in_place() {
    let mut e = engine();
    let depth_before = path(&snap(&e), "undo.depth").as_i64().unwrap();
    call(&mut e, "op.run", r#"{"id":"mesh.primitive_cube_add","params":{"size":1}}"#);
    let s = snap(&e);
    assert_eq!(path(&s, "scene.objects").as_arr().unwrap().len(), 2);
    assert_eq!(path(&s, "last_op.id").as_str(), Some("mesh.primitive_cube_add"));
    assert!((f32s(path(&s, "active.dimensions"))[0] - 1.0).abs() < 1e-4);
    let depth = path(&s, "undo.depth").as_i64().unwrap();
    assert_eq!(depth, depth_before + 1);

    call(&mut e, "op.redo", r#"{"params":{"size":4}}"#);
    let s = snap(&e);
    assert_eq!(path(&s, "scene.objects").as_arr().unwrap().len(), 2, "no second cube");
    assert!((f32s(path(&s, "active.dimensions"))[0] - 4.0).abs() < 1e-4);
    assert_eq!(path(&s, "undo.depth").as_i64(), Some(depth), "still a single undo step");

    call(&mut e, "undo", "");
    assert_eq!(path(&snap(&e), "scene.objects").as_arr().unwrap().len(), 1);
}

#[test]
fn tap_selects_and_empty_tap_deselects() {
    let mut e = engine();
    call(&mut e, "select.none", "");
    assert_eq!(path(&snap(&e), "scene.selected_count").as_i64(), Some(0));
    let center = e.m.camera.project_px(Vec3::ZERO).unwrap();
    tap(&mut e, center);
    assert_eq!(path(&snap(&e), "scene.selected_count").as_i64(), Some(1));
    tap(&mut e, [20.0, 20.0]);
    assert_eq!(path(&snap(&e), "scene.selected_count").as_i64(), Some(0));
}

#[test]
fn one_finger_drag_on_empty_space_orbits_the_camera() {
    let mut e = engine();
    let yaw = path(&snap(&e), "camera.yaw_deg").as_f32().unwrap();
    drag(&mut e, [60.0, 600.0], [260.0, 600.0]);
    let after = path(&snap(&e), "camera.yaw_deg").as_f32().unwrap();
    assert!((after - yaw).abs() > 5.0, "yaw {yaw} -> {after}");
    assert_eq!(path(&snap(&e), "camera.view").as_str(), Some("user"));
    call(&mut e, "view.preset", r#"{"view":"top"}"#);
    let s = snap(&e);
    assert_eq!(path(&s, "camera.view").as_str(), Some("top"));
    assert_eq!(path(&s, "camera.projection").as_str(), Some("ortho"));
}

#[test]
fn two_finger_pinch_zooms() {
    let mut e = engine();
    let d0 = e.m.camera.distance;
    touch(&mut e, 0, 0, &[(0, 400.0, 350.0)]);
    touch(&mut e, 5, 1, &[(0, 400.0, 350.0), (1, 600.0, 350.0)]);
    for i in 1..=10 {
        let spread = 100.0 + i as f32 * 20.0;
        touch(&mut e, 2, 0, &[(0, 500.0 - spread, 350.0), (1, 500.0 + spread, 350.0)]);
    }
    touch(&mut e, 6, 1, &[(0, 300.0, 350.0), (1, 700.0, 350.0)]);
    touch(&mut e, 1, 0, &[(0, 300.0, 350.0)]);
    assert!(e.m.camera.distance < d0 * 0.8, "pinch out moves the camera closer: {} -> {}", d0, e.m.camera.distance);
}

#[test]
fn gizmo_drag_moves_the_object_as_one_undo_step() {
    let mut e = engine();
    call(&mut e, "tool.set", r#"{"tool":"move"}"#);
    let frame = e.gizmo_frame().expect("gizmo frame for the selected cube");
    let style = e.gizmo_style();
    let cam = e.m.camera.clone();
    let origin_px = cam.project_px(frame.origin).unwrap();
    let len_world = style.size_px * cam.pixel_scale_at(frame.origin);
    let tip_px = cam.project_px(frame.origin + Vec3::X * len_world).unwrap();
    let dir = [tip_px[0] - origin_px[0], tip_px[1] - origin_px[1]];
    let n = (dir[0] * dir[0] + dir[1] * dir[1]).sqrt();
    let dir = [dir[0] / n, dir[1] / n];
    let grab = [origin_px[0] + (tip_px[0] - origin_px[0]) * 0.65, origin_px[1] + (tip_px[1] - origin_px[1]) * 0.65];
    let depth = path(&snap(&e), "undo.depth").as_i64().unwrap();

    drag(&mut e, grab, [grab[0] + dir[0] * 90.0, grab[1] + dir[1] * 90.0]);

    let s = snap(&e);
    let loc = f32s(path(&s, "active.transform.location"));
    assert!(loc[0] > 0.2, "moved along +X: {loc:?}");
    assert!(loc[1].abs() < 1e-3 && loc[2].abs() < 1e-3, "constrained to the X axis: {loc:?}");
    assert_eq!(path(&s, "undo.depth").as_i64(), Some(depth + 1), "one history step for the whole drag");
    assert_eq!(path(&s, "undo.undo_label").as_str(), Some("Move"));
    assert!(path(&s, "tool_state").is_null(), "numeric readout is gone after release");

    call(&mut e, "undo", "");
    let loc = f32s(path(&snap(&e), "active.transform.location"));
    assert!(loc.iter().all(|v| v.abs() < 1e-5), "undo restores the start: {loc:?}");
}

#[test]
fn cancelled_gizmo_drag_restores_the_scene() {
    let mut e = engine();
    call(&mut e, "tool.set", r#"{"tool":"scale"}"#);
    let frame = e.gizmo_frame().unwrap();
    let style = e.gizmo_style();
    let cam = e.m.camera.clone();
    let o = cam.project_px(frame.origin).unwrap();
    let tip = cam.project_px(frame.origin + Vec3::Z * (style.size_px * cam.pixel_scale_at(frame.origin))).unwrap();
    let grab = [o[0] + (tip[0] - o[0]) * 0.7, o[1] + (tip[1] - o[1]) * 0.7];
    touch(&mut e, 0, 0, &[(0, grab[0], grab[1])]);
    for i in 1..=8 {
        touch(&mut e, 2, 0, &[(0, grab[0], grab[1] - 12.0 * i as f32)]);
    }
    let during = f32s(path(&snap(&e), "active.transform.scale"));
    assert!(during[2] > 1.05, "scaling is live: {during:?}");
    call(&mut e, "tool.cancel", "");
    let after = f32s(path(&snap(&e), "active.transform.scale"));
    assert_eq!(after, vec![1.0, 1.0, 1.0]);
    assert_eq!(path(&snap(&e), "undo.can_undo").as_bool(), Some(false));
}

#[test]
fn numeric_transform_and_object_edit() {
    let mut e = engine();
    call(&mut e, "transform.numeric", r#"{"mode":"move","values":[1,2,3]}"#);
    assert_eq!(f32s(path(&snap(&e), "active.transform.location")), vec![1.0, 2.0, 3.0]);
    call(&mut e, "transform.numeric", r#"{"mode":"move","values":[0,0,0],"relative":false}"#);
    assert_eq!(f32s(path(&snap(&e), "active.transform.location")), vec![0.0, 0.0, 0.0]);
    call(&mut e, "transform.numeric", r#"{"mode":"scale","values":[2,2,2]}"#);
    assert!((f32s(path(&snap(&e), "active.dimensions"))[0] - 4.0).abs() < 1e-4);
    let id = path(&snap(&e), "active.id").as_i64().unwrap();
    call(&mut e, "object.set", &format!(r#"{{"id":{id},"name":"Crate","rotation":[0,0,90]}}"#));
    let s = snap(&e);
    assert_eq!(path(&s, "active.name").as_str(), Some("Crate"));
    assert!((f32s(path(&s, "active.transform.rotation"))[2] - 90.0).abs() < 1e-3);
    call(&mut e, "undo", "");
    assert_eq!(path(&snap(&e), "active.name").as_str(), Some("Cube"));
}

#[test]
fn edit_mode_numeric_move_and_box_select() {
    let mut e = engine();
    call(&mut e, "mode.set", r#"{"mode":"edit"}"#);
    assert_eq!(path(&snap(&e), "edit.verts.selected").as_i64(), Some(0));
    // x-ray box select (default) over the whole viewport selects every vertex
    call(&mut e, "select.box", r#"{"x0":0,"y0":0,"x1":1000,"y1":700}"#);
    assert_eq!(path(&snap(&e), "edit.verts.selected").as_i64(), Some(8));
    call(&mut e, "transform.numeric", r#"{"mode":"move","values":[0,0,2]}"#);
    let s = snap(&e);
    let med = f32s(path(&s, "edit.median"));
    assert!((med[2] - 2.0).abs() < 1e-4, "median moved up: {med:?}");
    call(&mut e, "select.invert", "");
    assert_eq!(path(&snap(&e), "edit.verts.selected").as_i64(), Some(0));
}

#[test]
fn materials_slots_and_modifiers() {
    let mut e = engine();
    let r = call(&mut e, "material.create", r#"{"name":"Red","base_color":[1,0,0,1],"roughness":0.2}"#);
    let mid = r.get_u32("id").unwrap();
    call(&mut e, "material.assign", &format!(r#"{{"material":{mid}}}"#));
    let s = snap(&e);
    assert_eq!(path(&s, "active.slots.0.material").as_i64(), Some(mid as i64));
    assert_eq!(path(&s, "materials").as_arr().unwrap().iter().filter(|m| m.get_str("name") == Some("Red")).count(), 1);
    call(&mut e, "material.set", &format!(r#"{{"id":{mid},"metallic":1.0}}"#));
    call(&mut e, "view.set", r#"{"shading":"material"}"#);
    let f = e.build_frame();
    assert_eq!(f.items.len(), 1);
    assert_eq!(f.items[0].materials[0].base_color, [1.0, 0.0, 0.0, 1.0]);
    assert_eq!(f.items[0].materials[0].metallic, 1.0);

    call(&mut e, "op.run", r#"{"id":"object.modifier_add","params":{"type":"SUBSURF"}}"#);
    let s = snap(&e);
    assert_eq!(path(&s, "active.modifiers").as_arr().unwrap().len(), 1);
    call(&mut e, "modifier.set", r#"{"index":0,"params":{"levels":2}}"#);
    let tris = e.build_frame();
    let _ = tris;
    let s = snap(&e);
    assert_eq!(path(&s, "active.modifiers.0.type").as_str(), Some("SUBSURF"));
}

#[test]
fn frame_has_items_grid_and_edit_overlay() {
    let mut e = engine();
    let f = e.build_frame();
    assert_eq!(f.items.len(), 1);
    assert_eq!(f.mesh_updates.len(), 1, "first frame uploads the cube");
    assert!(matches!(f.mesh_updates[0], MeshUpdate::Upload { .. }));
    assert!(!f.lines.is_empty(), "grid and axis lines");
    assert_eq!(f.stats.triangles, 12);
    assert_eq!(f.lights.len(), 2, "studio lights for solid shading");
    assert!(f.items[0].selected && f.items[0].active);
    let again = e.build_frame();
    assert!(again.mesh_updates.is_empty(), "unchanged meshes are not re-uploaded");

    e.gpu_lost();
    assert_eq!(e.build_frame().mesh_updates.len(), 1, "a new GPU context needs every mesh again");

    call(&mut e, "mode.set", r#"{"mode":"edit"}"#);
    let f = e.build_frame();
    assert!(!f.items[0].selected, "edited object is drawn without the object outline");
    assert_eq!(f.points.len(), 8, "vertex dots");
    assert!(f.tris.is_empty());
    call(&mut e, "select.mode", r#"{"mode":"face"}"#);
    call(&mut e, "select.all", "");
    let f = e.build_frame();
    assert_eq!(f.points.len(), 6, "face dots");
    assert_eq!(f.tris.len(), 36, "selected faces are filled");
    call(&mut e, "tool.set", r#"{"tool":"rotate"}"#);
    let f = e.build_frame();
    assert!(!f.overlay_lines.is_empty() || !f.overlay_triangles.is_empty(), "gizmo geometry");
}

#[test]
fn rubber_band_is_drawn_while_box_selecting() {
    let mut e = engine();
    call(&mut e, "tool.set", r#"{"tool":"box_select"}"#);
    touch(&mut e, 0, 0, &[(0, 100.0, 100.0)]);
    for i in 1..=6 {
        touch(&mut e, 2, 0, &[(0, 100.0 + 40.0 * i as f32, 100.0 + 30.0 * i as f32)]);
    }
    let f = e.build_frame();
    assert_eq!(f.screen_lines.len(), 8);
    touch(&mut e, 1, 0, &[(0, 340.0, 280.0)]);
    assert!(e.build_frame().screen_lines.is_empty());
}

#[test]
fn settings_persist_between_sessions() {
    let dir = temp_dir("settings");
    {
        let mut e = Engine::new(&dir, 2.0);
        call(&mut e, "settings.set", r#"{"path":"touch.sensitivity","value":1.75}"#);
        call(&mut e, "settings.set", r#"{"values":{"gestures.one_finger":"pan","snap.grid":true}}"#);
        assert!(call_err(&mut e, "settings.set", r#"{"path":"gestures.one_finger","value":"spin"}"#).contains("spin"));
    }
    let mut e = Engine::new(&dir, 2.0);
    let s = call(&mut e, "settings.get", "");
    assert_eq!(path(&s, "settings.touch.sensitivity").as_f32(), Some(1.75));
    assert_eq!(path(&s, "settings.gestures.one_finger").as_str(), Some("pan"));
    assert_eq!(path(&s, "settings.snap.grid").as_bool(), Some(true));
    let _ = std::fs::remove_dir_all(&dir);
}

#[test]
fn project_save_and_load_round_trip() {
    let mut a = engine();
    call(&mut a, "op.run", r#"{"id":"mesh.primitive_uv_sphere_add","params":{"segments":12,"ring_count":6}}"#);
    let ball_id = path(&snap(&a), "active.id").as_i64().unwrap();
    call(&mut a, "object.set", &format!(r#"{{"id":{ball_id},"name":"Ball","location":[3,0,0]}}"#));
    let bytes = a.save_project().unwrap();
    assert!(bytes.starts_with(b"RFORGE01"));

    let mut b = engine();
    let r = Json::parse(&b.load_project(&bytes)).unwrap();
    assert_eq!(r.get_bool("ok"), Some(true));
    let s = snap(&b);
    assert_eq!(path(&s, "scene.objects").as_arr().unwrap().len(), 2);
    let ball = path(&s, "scene.objects").as_arr().unwrap().iter().find(|o| o.get_str("name") == Some("Ball")).unwrap();
    assert_eq!(ball.get_u32("verts"), Some(12 * 5 + 2));
    assert_eq!(path(&s, "undo.can_undo").as_bool(), Some(false), "loading starts a fresh history");

    let bad = Json::parse(&b.load_project(b"not a project")).unwrap();
    assert_eq!(bad.get_bool("ok"), Some(false));
    assert_eq!(path(&snap(&b), "scene.objects").as_arr().unwrap().len(), 2, "a failed load keeps the current scene");

    let imp = Json::parse(&b.import_bytes("model.obj", b"v 0 0 0")).unwrap();
    assert_eq!(imp.get_bool("ok"), Some(false));
    assert!(b.export_bytes("obj", "{}").is_err());
    let rf = Json::parse(&b.import_bytes("scene.RFORGE", &bytes)).unwrap();
    assert_eq!(rf.get_bool("ok"), Some(true));
}

#[test]
fn light_object_and_delete() {
    let mut e = engine();
    call(&mut e, "op.run", r#"{"id":"object.light_add","params":{"type":"SUN"}}"#);
    let s = snap(&e);
    assert_eq!(path(&s, "active.kind").as_str(), Some("light"));
    let id = path(&s, "active.id").as_i64().unwrap();
    call(&mut e, "light.set", &format!(r#"{{"id":{id},"energy":5,"color":[1,0.5,0.5]}}"#));
    assert_eq!(path(&snap(&e), "active.light.energy").as_f32(), Some(5.0));
    call(&mut e, "view.set", r#"{"shading":"material"}"#);
    let f = e.build_frame();
    assert_eq!(f.lights.len(), 1, "scene lights replace the studio rig in material shading");
    assert!((f.lights[0].intensity - 5.0 * 0.35).abs() < 1e-5);
    call(&mut e, "op.run", r#"{"id":"object.delete"}"#);
    assert_eq!(path(&snap(&e), "scene.objects").as_arr().unwrap().len(), 1);
    let f = e.build_frame();
    assert!(f.mesh_updates.iter().all(|u| !matches!(u, MeshUpdate::Remove { .. })), "deleting a light removes no mesh");
}

#[test]
fn deleting_a_mesh_removes_its_gpu_buffers() {
    let mut e = engine();
    let _ = e.build_frame();
    call(&mut e, "op.run", r#"{"id":"object.delete"}"#);
    let f = e.build_frame();
    assert!(f.mesh_updates.iter().any(|u| matches!(u, MeshUpdate::Remove { .. })));
    assert!(f.items.is_empty());
}

#[test]
fn auto_quality_steps_down_under_load_and_back_up() {
    let mut e = engine();
    let stats = |fps: f32, ms: f32| RenderStats { fps, frame_ms: ms, ..RenderStats::default() };
    e.last_adapt = Instant::now() - std::time::Duration::from_secs(10);
    e.report_render_stats(stats(15.0, 66.0));
    assert_eq!(path(&snap(&e), "stats.quality").as_str(), Some("medium"));
    e.last_adapt = Instant::now() - std::time::Duration::from_secs(10);
    e.report_render_stats(stats(59.0, 8.0));
    assert_eq!(path(&snap(&e), "stats.quality").as_str(), Some("high"));
    call(&mut e, "settings.set", r#"{"path":"viewport.quality","value":"low"}"#);
    let f = e.build_frame();
    assert_eq!(f.msaa_samples, 1);
    assert!(f.resolution_scale < 1.0);
}

#[test]
fn undo_history_lists_labels() {
    let mut e = engine();
    call(&mut e, "op.run", r#"{"id":"mesh.primitive_plane_add"}"#);
    call(&mut e, "transform.numeric", r#"{"mode":"move","values":[0,0,1]}"#);
    let h = call(&mut e, "undo.history", "");
    let undo = path(&h, "undo").as_arr().unwrap().iter().map(|j| j.as_str().unwrap().to_string()).collect::<Vec<_>>();
    assert_eq!(undo.first().map(String::as_str), Some("Move"));
    assert_eq!(undo.len(), 2);
}

/// Writes real snapshots to $RF_DUMP_DIR so the Kotlin parser tests can use them as fixtures. No-op without the variable.
#[test]
fn dump_snapshots_for_kotlin_fixtures() {
    let Ok(dir) = std::env::var("RF_DUMP_DIR") else { return };
    let mut e = engine();
    let write = |name: &str, e: &Engine| std::fs::write(format!("{dir}/{name}.json"), snap(e).to_string()).unwrap();
    write("object", &e);
    call(&mut e, "op.run", r#"{"id":"object.light_add","params":{"type":"SPOT"}}"#);
    call(&mut e, "op.run", r#"{"id":"mesh.primitive_uv_sphere_add","params":{"segments":8,"ring_count":4}}"#);
    call(&mut e, "op.run", r#"{"id":"object.modifier_add","params":{"type":"MIRROR"}}"#);
    call(&mut e, "material.create", r#"{"name":"Stone","base_color":[0.5,0.4,0.3,1],"roughness":0.8}"#);
    call(&mut e, "material.assign", r#"{"material":1}"#);
    write("scene", &e);
    call(&mut e, "mode.set", r#"{"mode":"edit"}"#);
    call(&mut e, "select.mode", r#"{"mode":"face"}"#);
    call(&mut e, "select.all", "{}");
    call(&mut e, "op.run", r#"{"id":"mesh.inset","params":{}}"#);
    write("edit", &e);
}

/// Prints the operator list (used while writing the Kotlin menus). No-op without $RF_DUMP_DIR.
#[test]
fn dump_op_list_for_kotlin() {
    let Ok(dir) = std::env::var("RF_DUMP_DIR") else { return };
    let mut e = engine();
    let r = call(&mut e, "op.list", r#"{"context":"all"}"#);
    std::fs::write(format!("{dir}/ops.json"), r.to_string()).unwrap();
}
