//! RenderFrame assembly: draw items, helper geometry, edit-mode overlays, grid and gizmo.
use crate::render_types::*;
use crate::Engine;
use forge_input::gizmo;
use forge_math::{euler_to_mat3, EulerOrder, Vec3};
use forge_scene::{Data, Object, Scene};

const SELECTED: [f32; 4] = [1.0, 0.55, 0.1, 1.0];
const ACTIVE: [f32; 4] = [1.0, 0.8, 0.3, 1.0];
const IDLE: [f32; 4] = [0.72, 0.72, 0.76, 1.0];

fn lv(p: Vec3, c: [f32; 4]) -> LineVertex {
    LineVertex { position: p.to_array(), color: c }
}

fn line(out: &mut Vec<LineVertex>, a: Vec3, b: Vec3, c: [f32; 4]) {
    out.push(lv(a, c));
    out.push(lv(b, c));
}

fn grid_lines(distance: f32, grid: bool, axes: bool, out: &mut Vec<LineVertex>) {
    let step = 10f32.powf((distance / 6.0).log10().floor()).clamp(0.001, 1000.0);
    let n = 20i32;
    let half = step * n as f32;
    if grid {
        for i in -n..=n {
            if i == 0 && axes {
                continue;
            }
            let t = i as f32 * step;
            let c = if i % 10 == 0 { [0.46, 0.46, 0.5, 0.75] } else { [0.34, 0.34, 0.38, 0.55] };
            line(out, Vec3::new(t, -half, 0.0), Vec3::new(t, half, 0.0), c);
            line(out, Vec3::new(-half, t, 0.0), Vec3::new(half, t, 0.0), c);
        }
    }
    if axes {
        line(out, Vec3::new(-half, 0.0, 0.0), Vec3::new(half, 0.0, 0.0), [0.85, 0.25, 0.3, 0.9]);
        line(out, Vec3::new(0.0, -half, 0.0), Vec3::new(0.0, half, 0.0), [0.5, 0.8, 0.25, 0.9]);
    }
}

/// Cross (and direction line for suns and spots) for lights and empties.
fn helper_lines(o: &Object, color: [f32; 4], out: &mut Vec<LineVertex>) {
    let r = euler_to_mat3(EulerOrder::XYZ, o.transform.rotation);
    let c = o.transform.location;
    let s = 0.3;
    for axis in [r.cols[0], r.cols[1], r.cols[2]] {
        line(out, c - axis * s, c + axis * s, color);
    }
    if let Data::Light(l) = &o.data {
        if l.kind != forge_scene::LightKind::Point {
            line(out, c, c + r.cols[2] * -1.5, color);
        }
    }
}

fn bbox_lines(b: &forge_math::Aabb, w: &forge_math::Mat4, color: [f32; 4], out: &mut Vec<LineVertex>) {
    let p = |i: usize| w.transform_point3(Vec3::new(if i & 1 == 0 { b.min.x } else { b.max.x }, if i & 2 == 0 { b.min.y } else { b.max.y }, if i & 4 == 0 { b.min.z } else { b.max.z }));
    for i in 0..8usize {
        for bit in [1usize, 2, 4] {
            if i & bit == 0 {
                line(out, p(i), p(i | bit), color);
            }
        }
    }
}

fn material_list(scene: &Scene, o: &Object) -> Vec<MaterialData> {
    o.materials
        .iter()
        .map(|&id| match scene.material(id) {
            Some(m) => MaterialData {
                base_color: m.base_color,
                metallic: m.metallic,
                roughness: m.roughness,
                emissive: [m.emission[0] * m.emission_strength, m.emission[1] * m.emission_strength, m.emission[2] * m.emission_strength],
            },
            None => MaterialData::default(),
        })
        .collect()
}

impl Engine {
    pub(crate) fn make_frame(&mut self) -> RenderFrame {
        let (w, h) = self.viewport;
        let gizmo_pair = self.gizmo_kind().zip(self.gizmo_frame());
        let style = self.gizmo_style();
        let density = self.density;
        let Engine { m, cache, input, .. } = self;
        let mut f = RenderFrame::empty(w, h);
        m.camera.set_viewport(w as f32, h as f32);
        let cam = m.camera.clone();
        f.view = cam.view().to_cols_array();
        f.proj = cam.proj().to_cols_array();
        f.eye = cam.eye().to_array();
        let (msaa, scale, poly_limit) = m.quality();
        f.msaa_samples = msaa;
        f.resolution_scale = scale;
        f.shading = match m.shading {
            "wire" => ShadingMode::Wireframe,
            "material" => ShadingMode::Material,
            _ => ShadingMode::Solid,
        };
        let editing = m.edit.as_ref().map(|e| e.object);
        f.mesh_updates = cache.sync(&m.scene, editing, &m.ctx);
        if let Some(err) = cache.error.take() {
            m.toast("warn", err);
        }

        // lights: the studio rig for solid shading (or a scene without lights), the scene's lights otherwise
        let scene_lights = m.scene.objects.iter().any(|o| o.visible && matches!(o.data, Data::Light(_)));
        if m.shading == "material" && scene_lights {
            for o in m.scene.objects.iter().filter(|o| o.visible) {
                if let Data::Light(l) = &o.data {
                    let r = euler_to_mat3(EulerOrder::XYZ, o.transform.rotation);
                    let (kind, intensity) = match l.kind {
                        forge_scene::LightKind::Sun => (LightKind::Sun, l.energy * 0.35),
                        forge_scene::LightKind::Point => (LightKind::Point, l.energy * 0.01),
                        forge_scene::LightKind::Spot => (LightKind::Spot, l.energy * 0.01),
                    };
                    let half = l.spot_size * 0.5;
                    f.lights.push(LightData {
                        kind,
                        position: o.transform.location.to_array(),
                        direction: (r.cols[2] * -1.0).to_array(),
                        color: l.color,
                        intensity,
                        spot_cos: [(half * (1.0 - l.spot_blend)).cos(), half.cos()],
                    });
                }
            }
        } else {
            let (fw, up, rt) = (cam.forward(), cam.up(), cam.right());
            let sun = |dir: Vec3, intensity: f32| LightData { kind: LightKind::Sun, position: [0.0; 3], direction: dir.normalize().to_array(), color: [1.0, 1.0, 1.0], intensity, spot_cos: [1.0, 1.0] };
            f.lights.push(sun(fw + up * -0.8 + rt * 0.5, 0.95));
            f.lights.push(sun(fw + up * 0.5 + rt * -0.8, 0.35));
        }

        // objects
        let mut tris = 0u64;
        let mut drawn = 0u32;
        for o in m.scene.objects.iter().filter(|o| o.visible) {
            let is_sel = m.scene.is_selected(o.id);
            let is_active = m.scene.active == Some(o.id);
            match &o.data {
                Data::Mesh(_) => {
                    let editing_this = editing == Some(o.id);
                    let Some(mesh) = cache.display(o, editing_this, &m.ctx) else { continue };
                    let n = mesh.triangle_count() as u64;
                    let model = o.transform.matrix();
                    if tris + n > poly_limit {
                        bbox_lines(&mesh.bounds(), &model, if is_sel { SELECTED } else { IDLE }, &mut f.lines);
                        continue;
                    }
                    tris += n;
                    drawn += 1;
                    f.items.push(DrawItem {
                        mesh_key: o.id as u64,
                        model: model.to_cols_array(),
                        materials: material_list(&m.scene, o),
                        selected: is_sel && !editing_this,
                        active: is_active && !editing_this,
                        wire: if m.wire_overlay && !editing_this { WireMode::Overlay } else { WireMode::None },
                        xray: m.xray,
                    });
                }
                _ => helper_lines(o, if is_active { ACTIVE } else if is_sel { SELECTED } else { IDLE }, &mut f.lines),
            }
        }
        f.stats = FrameStats { objects: drawn, triangles: tris };

        grid_lines(cam.distance, m.grid, m.axes, &mut f.lines);

        // edit mode overlay
        if let Some(e) = &m.edit {
            if let (Some(o), true) = (m.scene.get(e.object), true) {
                if let (Some(mesh), Some(topo)) = (cache.display(o, true, &m.ctx), cache.topo(o, true, &m.ctx)) {
                    let world = o.transform.matrix();
                    let wp: Vec<Vec3> = mesh.positions.iter().map(|p| world.transform_point3(*p)).collect();
                    let sel = &e.sel;
                    let mut tmp = Vec::new();
                    for fi in sel.faces(&mesh) {
                        tmp.clear();
                        mesh.triangulate_face(fi as usize, &mut tmp);
                        for t in &tmp {
                            for &c in t {
                                f.tris.push(lv(wp[mesh.corners[c as usize] as usize], [1.0, 0.55, 0.1, 0.33]));
                            }
                        }
                    }
                    for ed in &topo.edges {
                        let on = sel.is_selected(ed[0]) && sel.is_selected(ed[1]);
                        let c = if on { SELECTED } else { [0.0, 0.0, 0.0, 0.85] };
                        line(&mut f.lines, wp[ed[0] as usize], wp[ed[1] as usize], c);
                    }
                    if wp.len() <= 200_000 {
                        let (small, big) = (5.0 * density, 8.0 * density);
                        match e.mode {
                            forge_ops::SelectMode::Face => {
                                for fi in 0..mesh.face_count() {
                                    let on = mesh.face_verts(fi).iter().all(|&v| sel.is_selected(v));
                                    let c = world.transform_point3(mesh.face_center(fi));
                                    f.points.push(PointInstance { position: c.to_array(), size_px: if on { big } else { small * 0.8 }, color: if on { SELECTED } else { [0.0, 0.0, 0.0, 0.8] } });
                                }
                            }
                            mode => {
                                for (i, p) in wp.iter().enumerate() {
                                    let on = sel.is_selected(i as u32);
                                    if mode == forge_ops::SelectMode::Edge && !on {
                                        continue;
                                    }
                                    f.points.push(PointInstance { position: p.to_array(), size_px: if on { big } else { small }, color: if on { SELECTED } else { [0.05, 0.05, 0.05, 0.9] } });
                                }
                            }
                        }
                    }
                }
            }
        }

        // gizmo (always on top)
        if let Some((kind, frame)) = gizmo_pair {
            let mut d = gizmo::GizmoDraw::default();
            gizmo::draw(kind, &frame, &cam, &style, input.active_handle, &mut d);
            f.overlay_triangles = d.tris.iter().map(|v| LineVertex { position: v.pos, color: v.color }).collect();
            f.overlay_lines = d.lines.iter().map(|v| LineVertex { position: v.pos, color: v.color }).collect();
        }

        // rubber band
        if let Some(r) = input.rubber {
            let c = [1.0, 1.0, 1.0, 0.9];
            let pts = [[r[0], r[1]], [r[2], r[1]], [r[2], r[3]], [r[0], r[3]]];
            for i in 0..4 {
                f.screen_lines.push(ScreenVertex { position: pts[i], color: c });
                f.screen_lines.push(ScreenVertex { position: pts[(i + 1) % 4], color: c });
            }
        }
        f
    }
}
