//! Screen-space picking of objects and mesh elements, box selection.
use crate::gpu::MeshCache;
use crate::model::Model;
use forge_bvh::Bvh;
use forge_input::Camera;
use forge_math::{Mat4, Ray, Vec3};
use forge_mesh::{Mesh, Selection, Topology};
use forge_ops::SelectMode;
use forge_scene::{Data, ObjId};

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Hit {
    Vert(u32),
    Edge([u32; 2]),
    Face(u32),
}

fn dist(a: [f32; 2], b: [f32; 2]) -> f32 {
    ((a[0] - b[0]).powi(2) + (a[1] - b[1]).powi(2)).sqrt()
}

fn dist_seg(p: [f32; 2], a: [f32; 2], b: [f32; 2]) -> f32 {
    let (abx, aby) = (b[0] - a[0], b[1] - a[1]);
    let l2 = abx * abx + aby * aby;
    let t = if l2 < 1e-9 { 0.0 } else { (((p[0] - a[0]) * abx + (p[1] - a[1]) * aby) / l2).clamp(0.0, 1.0) };
    dist(p, [a[0] + abx * t, a[1] + aby * t])
}

fn inside(p: [f32; 2], r: [f32; 4]) -> bool {
    p[0] >= r[0] && p[0] <= r[2] && p[1] >= r[1] && p[1] <= r[3]
}

pub fn normalize_rect(a: [f32; 2], b: [f32; 2]) -> [f32; 4] {
    [a[0].min(b[0]), a[1].min(b[1]), a[0].max(b[0]), a[1].max(b[1])]
}

/// Nearest object under a screen position. Lights and empties are picked by their origin.
pub fn pick_object(m: &Model, cache: &mut MeshCache, pos: [f32; 2], hit_r: f32) -> Option<ObjId> {
    let cam = &m.camera;
    let ray = cam.ray(pos[0], pos[1]);
    let mut best: Option<(f32, ObjId)> = None;
    for o in &m.scene.objects {
        if !o.visible {
            continue;
        }
        let w = o.transform.matrix();
        let t = match &o.data {
            Data::Mesh(_) => {
                let Some(bvh) = cache.bvh(o, false, &m.ctx) else { continue };
                let inv = w.inverse();
                let Some(dir) = inv.transform_vector3(ray.dir).try_normalize() else { continue };
                match bvh.raycast(&Ray::new(inv.transform_point3(ray.origin), dir), f32::MAX) {
                    Some(h) => (w.transform_point3(h.point) - ray.origin).dot(ray.dir),
                    None => continue,
                }
            }
            _ => match cam.project_px(o.transform.location) {
                Some(p) if dist(p, pos) <= hit_r * 0.8 => (o.transform.location - ray.origin).dot(ray.dir),
                _ => continue,
            },
        };
        if best.map_or(true, |(b, _)| t < b) {
            best = Some((t, o.id));
        }
    }
    best.map(|(_, id)| id)
}

/// Objects whose bounding box centre lies inside the rectangle.
pub fn box_select_objects(m: &Model, rect: [f32; 4]) -> Vec<ObjId> {
    m.scene
        .objects
        .iter()
        .filter(|o| o.visible)
        .filter(|o| m.scene.world_bounds(o.id).and_then(|b| m.camera.project_px(b.center())).map_or(false, |p| inside(p, rect)))
        .map(|o| o.id)
        .collect()
}

struct EditView {
    mesh: std::sync::Arc<Mesh>,
    bvh: std::sync::Arc<Bvh>,
    topo: std::sync::Arc<Topology>,
    w: Mat4,
    inv: Mat4,
}

fn edit_view(m: &Model, cache: &mut MeshCache) -> Option<EditView> {
    let e = m.edit.as_ref()?;
    let o = m.scene.get(e.object)?;
    let mesh = cache.display(o, true, &m.ctx)?;
    let bvh = cache.bvh(o, true, &m.ctx)?;
    let topo = cache.topo(o, true, &m.ctx)?;
    let w = o.transform.matrix();
    Some(EditView { mesh, bvh, topo, inv: w.inverse(), w })
}

impl EditView {
    fn px(&self, cam: &Camera, v: u32) -> Option<[f32; 2]> {
        cam.project_px(self.w.transform_point3(self.mesh.positions[v as usize]))
    }
    /// Is the local-space point hidden behind the surface as seen from the camera?
    fn occluded(&self, cam: &Camera, p_local: Vec3) -> bool {
        if self.bvh.is_empty() {
            return false;
        }
        let from = if cam.ortho {
            self.inv.transform_point3(self.w.transform_point3(p_local) - cam.forward() * (cam.distance * 50.0))
        } else {
            self.inv.transform_point3(cam.eye())
        };
        let eps = (p_local - from).length() * 1e-3 + 1e-5;
        self.bvh.occluded(from, p_local, eps)
    }
    fn vert_visible(&self, cam: &Camera, v: u32, xray: bool) -> bool {
        xray || !self.occluded(cam, self.mesh.positions[v as usize])
    }
}

fn nearest_edge(v: &EditView, cam: &Camera, pos: [f32; 2], hit_r: f32, xray: bool) -> Option<[u32; 2]> {
    let mut best: Option<(f32, [u32; 2])> = None;
    for e in &v.topo.edges {
        let (Some(a), Some(b)) = (v.px(cam, e[0]), v.px(cam, e[1])) else { continue };
        let d = dist_seg(pos, a, b);
        if d <= hit_r && best.map_or(true, |(bd, _)| d < bd) {
            best = Some((d, *e));
        }
    }
    let (_, e) = best?;
    let mid = (v.mesh.positions[e[0] as usize] + v.mesh.positions[e[1] as usize]) * 0.5;
    if xray || !v.occluded(cam, mid) {
        Some(e)
    } else {
        None
    }
}

/// The edge nearest to a screen position (for the loop cut tool).
pub fn pick_edge(m: &Model, cache: &mut MeshCache, pos: [f32; 2], hit_r: f32) -> Option<(u32, [u32; 2])> {
    let v = edit_view(m, cache)?;
    let e = nearest_edge(&v, &m.camera, pos, hit_r, true)?;
    let idx = v.topo.edges[..v.topo.loose_start].iter().position(|x| *x == e)?;
    Some((idx as u32, e))
}

/// Element under a screen position in the current select mode.
pub fn pick_element(m: &Model, cache: &mut MeshCache, pos: [f32; 2], hit_r: f32) -> Option<Hit> {
    let v = edit_view(m, cache)?;
    let cam = &m.camera;
    match m.select_mode {
        SelectMode::Vertex => {
            let mut best: Option<(f32, u32)> = None;
            for i in 0..v.mesh.vert_count() as u32 {
                if let Some(p) = v.px(cam, i) {
                    let d = dist(p, pos);
                    if d <= hit_r && best.map_or(true, |(bd, _)| d < bd) && v.vert_visible(cam, i, m.xray) {
                        best = Some((d, i));
                    }
                }
            }
            best.map(|(_, i)| Hit::Vert(i))
        }
        SelectMode::Edge => nearest_edge(&v, cam, pos, hit_r, m.xray).map(Hit::Edge),
        SelectMode::Face => {
            let ray = cam.ray(pos[0], pos[1]);
            let dir = v.inv.transform_vector3(ray.dir).try_normalize()?;
            v.bvh.raycast(&Ray::new(v.inv.transform_point3(ray.origin), dir), f32::MAX).map(|h| Hit::Face(h.face))
        }
    }
}

/// Apply a tap on `hit` to the selection (replace, or toggle when `additive`).
pub fn select_hit(sel: &mut Selection, mesh: &Mesh, hit: Hit, additive: bool) {
    let verts: Vec<u32> = match hit {
        Hit::Vert(v) => vec![v],
        Hit::Edge(e) => e.to_vec(),
        Hit::Face(f) => mesh.face_verts(f as usize).to_vec(),
    };
    let all_on = verts.iter().all(|&v| sel.is_selected(v));
    if !additive {
        sel.clear();
    }
    for v in verts {
        sel.set(v, !(additive && all_on));
    }
}

/// Vertices selected by a rubber band in the current select mode.
pub fn box_select_elements(m: &Model, cache: &mut MeshCache, rect: [f32; 4], xray: bool) -> Option<Selection> {
    let v = edit_view(m, cache)?;
    let cam = &m.camera;
    let n = v.mesh.vert_count();
    let mut sel = Selection::none(n);
    let inside_vert = |i: u32| v.px(cam, i).map_or(false, |p| inside(p, rect)) && v.vert_visible(cam, i, xray);
    match m.select_mode {
        SelectMode::Vertex => {
            for i in 0..n as u32 {
                if inside_vert(i) {
                    sel.set(i, true);
                }
            }
        }
        SelectMode::Edge => {
            let hit: Vec<bool> = (0..n as u32).map(|i| inside_vert(i)).collect();
            for e in &v.topo.edges {
                if hit[e[0] as usize] && hit[e[1] as usize] {
                    sel.set(e[0], true);
                    sel.set(e[1], true);
                }
            }
        }
        SelectMode::Face => {
            for f in 0..v.mesh.face_count() {
                let c = v.mesh.face_center(f);
                let ok = cam.project_px(v.w.transform_point3(c)).map_or(false, |p| inside(p, rect)) && (xray || !v.occluded(cam, c));
                if ok {
                    for &i in v.mesh.face_verts(f) {
                        sel.set(i, true);
                    }
                }
            }
        }
    }
    Some(sel)
}
