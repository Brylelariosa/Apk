//! forge-engine: the platform-independent application core of RustForge 3D.
//!
//! The Android layer (`rustforge`) owns exactly one [`Engine`] behind a mutex and only ever calls the methods
//! below: touch events in, JSON commands in/out, a state snapshot poll, and one [`RenderFrame`] per drawn frame.
//! Everything else (scene, tools, undo, operators, IO) lives behind it.
#![forbid(unsafe_code)]

mod commands;
mod frame;
mod gpu;
mod model;
mod picking;
mod redraw;
pub mod render_types;
mod settings;
mod snapshot;
mod tools;

pub use forge_input::{TouchBatch, TouchPointer};
pub use redraw::RedrawSignal;
pub use render_types::*;

use forge_json::Json;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Instant;

pub struct Engine {
    pub(crate) redraw: Arc<RedrawSignal>,
    pub(crate) m: model::Model,
    pub(crate) input: tools::Input,
    pub(crate) cache: gpu::MeshCache,
    pub(crate) files_dir: PathBuf,
    pub(crate) density: f32,
    pub(crate) clock: Instant,
    pub(crate) last_error: String,
    pub(crate) polled_rev: u64,
    pub(crate) viewport: (u32, u32),
    last_adapt: Instant,
}

fn error_json(msg: &str) -> String {
    Json::obj().set("ok", false).set("error", msg).to_string()
}

impl Engine {
    /// `files_dir`: app-private directory (settings are persisted there). `density`: screen density (dp -> px).
    pub fn new(files_dir: &str, density: f32) -> Engine {
        let density = if density.is_finite() && density > 0.25 { density } else { 1.0 };
        let mut settings = settings::Settings::new();
        let path = PathBuf::from(files_dir).join("settings.json");
        if let Ok(text) = std::fs::read_to_string(&path) {
            if let Ok(j) = Json::parse(&text) {
                settings.load(&j);
            }
        }
        Engine {
            redraw: RedrawSignal::new(),
            m: model::Model::new(settings),
            input: tools::Input::new(density),
            cache: gpu::MeshCache::default(),
            files_dir: PathBuf::from(files_dir),
            density,
            clock: Instant::now(),
            last_error: String::new(),
            polled_rev: 0,
            viewport: (1, 1),
            last_adapt: Instant::now(),
        }
    }

    pub(crate) fn save_settings(&self) {
        let _ = std::fs::create_dir_all(&self.files_dir);
        let _ = std::fs::write(self.files_dir.join("settings.json"), self.m.settings.to_json().to_pretty());
    }

    /// The render thread waits on this; the engine requests a redraw whenever anything visible changed.
    pub fn redraw_signal(&self) -> Arc<RedrawSignal> {
        self.redraw.clone()
    }

    pub fn set_viewport(&mut self, width_px: u32, height_px: u32) {
        self.viewport = (width_px.max(1), height_px.max(1));
        self.m.camera.set_viewport(self.viewport.0 as f32, self.viewport.1 as f32);
        self.redraw.request();
    }

    pub fn touch(&mut self, batch: &TouchBatch) {
        self.handle_touch(batch);
    }

    /// Synchronous JSON command (see docs/PROTOCOL.md). Always returns a JSON object string.
    pub fn call(&mut self, method: &str, args_json: &str) -> String {
        let args = if args_json.trim().is_empty() {
            Json::obj()
        } else {
            match Json::parse(args_json) {
                Ok(j) => j,
                Err(e) => return error_json(&format!("invalid arguments: {e}")),
            }
        };
        let res = self.dispatch(method, &args);
        self.redraw.request();
        match res {
            Ok(fields) => {
                let mut out = Json::obj().set("ok", true);
                if let Some(o) = fields.as_obj() {
                    for (k, v) in o {
                        out.insert(k, v.clone());
                    }
                }
                self.last_error.clear();
                out.to_string()
            }
            Err(e) => {
                self.last_error = e.clone();
                error_json(&e)
            }
        }
    }

    /// Full JSON state snapshot if anything changed since the last poll. Also drives time based gestures.
    pub fn poll(&mut self) -> Option<String> {
        self.tick_gestures();
        if self.m.rev != self.polled_rev {
            self.polled_rev = self.m.rev;
            Some(self.snapshot().to_string())
        } else {
            None
        }
    }

    /// Consume pending changes and produce the next frame. Called on the render thread (engine is locked).
    pub fn build_frame(&mut self) -> RenderFrame {
        self.make_frame()
    }

    /// The GPU lost its resources (new surface or device): every mesh is uploaded again with the next frame.
    pub fn gpu_lost(&mut self) {
        self.cache.invalidate_gpu();
        self.redraw.request();
    }

    /// Called by the render thread after each frame batch (about once per second while drawing).
    pub fn report_render_stats(&mut self, stats: RenderStats) {
        let (fps, ms) = (stats.fps, stats.frame_ms);
        self.m.stats = stats;
        if self.m.show_stats {
            self.m.bump();
        }
        if self.m.settings.s("viewport.quality") == "auto" && fps > 0.0 && self.last_adapt.elapsed().as_secs() >= 3 {
            self.last_adapt = Instant::now();
            let lvl = self.m.auto_level;
            if (fps < 24.0 || ms > 40.0) && lvl > 0 {
                self.m.auto_level -= 1;
            } else if fps > 50.0 && ms < 12.0 && lvl < 2 {
                self.m.auto_level += 1;
            }
            if lvl != self.m.auto_level {
                self.m.bump();
                self.redraw.request();
            }
        }
    }

    /// Import a model/project file; returns a JSON result object.
    pub fn import_bytes(&mut self, file_name: &str, data: &[u8]) -> String {
        if file_name.to_ascii_lowercase().ends_with(".rforge") {
            return self.load_project(data);
        }
        let msg = format!("Importing '{file_name}' is not available in this version yet (only .rforge projects)");
        self.last_error = msg.clone();
        error_json(&msg)
    }

    /// Export the scene (`format`: "obj" | "stl" | "glb" | "gltf"); `opts_json` e.g. `{"selection_only":true}`.
    pub fn export_bytes(&mut self, format: &str, opts_json: &str) -> Result<Vec<u8>, String> {
        let _ = opts_json;
        self.last_error = format!("Exporting to '{format}' is not available in this version yet");
        Err(self.last_error.clone())
    }

    pub fn save_project(&mut self) -> Result<Vec<u8>, String> {
        Ok(forge_scene::save_bytes(&self.m.scene))
    }

    pub fn load_project(&mut self, data: &[u8]) -> String {
        match forge_scene::load_bytes(data) {
            Ok(scene) => {
                self.cancel_drag();
                let n = scene.objects.len();
                self.m.replace_scene(scene);
                self.focus(true);
                self.redraw.request();
                Json::obj().set("ok", true).set("objects", n).to_string()
            }
            Err(e) => {
                self.last_error = e.clone();
                error_json(&e)
            }
        }
    }

    pub fn last_error(&self) -> &str {
        &self.last_error
    }

    pub fn on_pause(&mut self) {
        self.cancel_drag();
    }

    pub fn on_resume(&mut self) {
        self.redraw.request();
    }
}

#[cfg(test)]
mod tests;
