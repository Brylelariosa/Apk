//! Wake-up channel between the engine (any thread) and the render thread.
use std::sync::{Arc, Condvar, Mutex};
use std::time::Duration;

#[derive(Debug, Default)]
pub struct RedrawSignal {
    flag: Mutex<bool>,
    cv: Condvar,
}

impl RedrawSignal {
    pub fn new() -> Arc<RedrawSignal> {
        Arc::new(RedrawSignal::default())
    }
    /// Ask for another frame.
    pub fn request(&self) {
        if let Ok(mut f) = self.flag.lock() {
            *f = true;
            self.cv.notify_all();
        }
    }
    /// Block until a redraw is requested or `timeout` elapses. Returns whether one was requested
    /// (and clears the request).
    pub fn wait(&self, timeout: Duration) -> bool {
        let Ok(mut f) = self.flag.lock() else { return true };
        if !*f {
            match self.cv.wait_timeout(f, timeout) {
                Ok((g, _)) => f = g,
                Err(_) => return true,
            }
        }
        let was = *f;
        *f = false;
        was
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn request_wakes_waiter_and_clears() {
        let s = RedrawSignal::new();
        assert!(!s.wait(Duration::from_millis(5)));
        let s2 = s.clone();
        let h = std::thread::spawn(move || s2.wait(Duration::from_secs(5)));
        std::thread::sleep(Duration::from_millis(20));
        s.request();
        assert!(h.join().unwrap());
        assert!(!s.wait(Duration::from_millis(1)));
    }
}
