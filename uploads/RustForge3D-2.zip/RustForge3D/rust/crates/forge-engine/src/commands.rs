//! JSON command dispatch (docs/PROTOCOL.md section 4).
use crate::model::Tool;
use crate::picking;
use crate::Engine;
use forge_input::Camera;
use forge_json::Json;
use forge_math::Vec3;
use forge_mesh::{Mesh, Topology};
use forge_ops::{apply_xform, selection_pivot, SelectMode, Xform};
use forge_scene::{next_rev, LightKind, ObjId, Scene};

fn need_u32(a: &Json, k: &str) -> Result<u32, String> {
    a.get_u32(k).ok_or_else(|| format!("missing '{k}'"))
}
fn vec3_of(j: &Json) -> Option<Vec3> {
    j.as_vec3().map(|a| Vec3::new(a[0], a[1], a[2]))
}
fn deg_of(j: &Json) -> Option<Vec3> {
    vec3_of(j).map(|v| v * (std::f32::consts::PI / 180.0))
}
fn id_list(ids: &[ObjId]) -> Json {
    Json::Arr(ids.iter().map(|&i| Json::from(i)).collect())
}

fn set_material_fields(scene: &mut Scene, id: u32, a: &Json) -> Result<(), String> {
    let unique = a.get_str("name").map(|n| {
        if scene.materials.iter().any(|m| m.id != id && m.name == n) {
            format!("{n}.{id:03}")
        } else {
            n.to_string()
        }
    });
    let m = scene.material_mut(id).ok_or("No such material")?;
    if let Some(n) = unique {
        m.name = n;
    }
    if let Some(c) = a.get("base_color").and_then(|j| j.as_f32_array::<4>()) {
        m.base_color = c;
    }
    if let Some(v) = a.get_f32("alpha") {
        m.base_color[3] = v.clamp(0.0, 1.0);
    }
    if let Some(v) = a.get_f32("metallic") {
        m.metallic = v.clamp(0.0, 1.0);
    }
    if let Some(v) = a.get_f32("roughness") {
        m.roughness = v.clamp(0.0, 1.0);
    }
    if let Some(c) = a.get("emission").and_then(|j| j.as_vec3()) {
        m.emission = c;
    }
    if let Some(v) = a.get_f32("emission_strength") {
        m.emission_strength = v.max(0.0);
    }
    Ok(())
}

fn rss_mb() -> f32 {
    std::fs::read_to_string("/proc/self/status")
        .ok()
        .and_then(|s| s.lines().find(|l| l.starts_with("VmRSS:")).and_then(|l| l.split_whitespace().nth(1)).and_then(|kb| kb.parse::<f32>().ok()))
        .map_or(0.0, |kb| kb / 1024.0)
}

impl Engine {
    fn target_object(&self, a: &Json, key: &str) -> Result<ObjId, String> {
        a.get_u32(key).or(self.m.scene.active).ok_or_else(|| "There is no active object".to_string())
    }

    pub(crate) fn dispatch(&mut self, method: &str, a: &Json) -> Result<Json, String> {
        let ok = Json::obj();
        match method {
            // ---- session -------------------------------------------------------------------------------------
            "mode.set" => {
                match a.get_str("mode") {
                    Some("object") => self.m.exit_edit(),
                    Some("edit") => self.m.enter_edit()?,
                    Some("sculpt") => return Err("Sculpt mode is not available in this version yet".into()),
                    _ => return Err("mode must be \"object\", \"edit\" or \"sculpt\"".into()),
                }
                self.cancel_drag();
                Ok(ok)
            }
            "select.mode" => {
                let mode = a.get_str("mode").and_then(SelectMode::from_name).ok_or("mode must be vertex, edge or face")?;
                self.m.set_select_mode(mode);
                Ok(ok)
            }
            "select.all" | "select.none" | "select.invert" => {
                if let Some(e) = &mut self.m.edit {
                    match method {
                        "select.all" => e.sel.select_all(),
                        "select.none" => e.sel.clear(),
                        _ => e.sel.invert(),
                    }
                } else {
                    match method {
                        "select.all" => self.m.scene.select_all(),
                        "select.none" => self.m.scene.select_only(None),
                        _ => self.m.scene.invert_selection(),
                    }
                }
                self.m.selection_changed();
                Ok(ok)
            }
            "select.set" => {
                if self.m.edit.is_some() {
                    return Err("Leave Edit Mode to select objects".into());
                }
                let ids: Vec<ObjId> = a.get("ids").and_then(|j| j.as_arr()).ok_or("missing 'ids'")?.iter().filter_map(|j| j.as_u32()).collect();
                self.m.select_objects(&ids, a.get_bool("extend").unwrap_or(false));
                Ok(ok)
            }
            "select.more" | "select.less" | "select.linked" => {
                let e = self.m.edit.as_mut().ok_or("This needs Edit Mode")?;
                let mesh = self.m.scene.get(e.object).and_then(|o| o.mesh()).ok_or("Not a mesh")?.clone();
                let topo = Topology::build(&mesh);
                match method {
                    "select.more" => e.sel.grow(&topo),
                    "select.less" => e.sel.shrink(&topo),
                    _ => e.sel.select_linked(&topo),
                }
                self.m.selection_changed();
                Ok(ok)
            }
            "select.box" => {
                let f = |k: &str| a.get_f32(k).unwrap_or(0.0);
                let rect = picking::normalize_rect([f("x0"), f("y0")], [f("x1"), f("y1")]);
                self.box_select(rect, a.get_str("op") == Some("add"));
                Ok(ok)
            }
            // ---- view ----------------------------------------------------------------------------------------
            "view.preset" => {
                match a.get_str("view") {
                    Some("reset") => {
                        let (w, h) = self.viewport;
                        self.m.camera = Camera::default();
                        self.m.camera.set_viewport(w as f32, h as f32);
                        self.m.view_name = "user";
                        self.focus(true);
                    }
                    Some(v) => {
                        if !self.m.preset(v) {
                            return Err(format!("unknown view '{v}'"));
                        }
                    }
                    None => return Err("missing 'view'".into()),
                }
                self.m.bump();
                Ok(ok)
            }
            "view.projection" => {
                match a.get_str("projection") {
                    Some("persp") => self.m.camera.ortho = false,
                    Some("ortho") => self.m.camera.ortho = true,
                    Some("toggle") => self.m.camera.ortho = !self.m.camera.ortho,
                    _ => return Err("projection must be persp, ortho or toggle".into()),
                }
                self.m.bump();
                Ok(ok)
            }
            "view.focus" => {
                self.focus(a.get_str("target") == Some("all"));
                Ok(ok)
            }
            "view.set" => {
                if let Some(s) = a.get_str("shading") {
                    self.m.shading = match s {
                        "solid" => "solid",
                        "wire" => "wire",
                        "material" => "material",
                        _ => return Err("shading must be solid, wire or material".into()),
                    };
                }
                let m = &mut self.m;
                for (k, slot) in [("grid", &mut m.grid), ("axes", &mut m.axes), ("wire_overlay", &mut m.wire_overlay), ("xray", &mut m.xray), ("stats", &mut m.show_stats)] {
                    if let Some(b) = a.get_bool(k) {
                        *slot = b;
                    }
                }
                self.m.bump();
                Ok(ok)
            }
            "tool.set" => {
                let t = a.get_str("tool").and_then(Tool::from_id).ok_or("unknown tool")?;
                if t.edit_only() && self.m.edit.is_none() {
                    return Err("This tool needs Edit Mode".into());
                }
                self.cancel_drag();
                match t {
                    Tool::Extrude => {
                        self.m.run_op("mesh.extrude_region_move", &Json::obj())?;
                        self.m.tool = Tool::Move;
                        self.m.toast("info", "Extruded - drag the arrows to move the new geometry");
                    }
                    Tool::Inset => {
                        self.m.run_op("mesh.inset", &Json::obj())?;
                        self.m.toast("info", "Adjust the inset in the operator panel");
                    }
                    Tool::LoopCut => {
                        self.m.tool = t;
                        self.m.toast("info", "Tap an edge to cut its ring");
                    }
                    other => self.m.tool = other,
                }
                self.m.tool_state = None;
                self.m.bump();
                Ok(ok)
            }
            "tool.cancel" => {
                self.cancel_drag();
                Ok(ok)
            }
            "settings.get" => Ok(Json::obj().set("settings", self.m.settings.to_json())),
            "settings.set" => {
                if let Some(path) = a.get_str("path") {
                    self.m.settings.set(path, a.get("value").unwrap_or(&Json::Null))?;
                }
                if let Some(vals) = a.get("values").and_then(|j| j.as_obj()) {
                    for (k, v) in vals {
                        self.m.settings.set(k, v)?;
                    }
                }
                self.save_settings();
                self.m.bump();
                Ok(ok)
            }
            "project.new" => {
                self.cancel_drag();
                self.m.new_project();
                Ok(ok)
            }
            "debug.memory" => {
                let scene_mb: f32 = self.m.scene.objects.iter().filter_map(|o| o.mesh()).map(|m| m.memory_bytes() as f32).sum::<f32>() / 1048576.0;
                Ok(Json::obj().set("rss_mb", rss_mb()).set("scene_mb", scene_mb).set("gpu_mb", self.m.stats.gpu_mb))
            }
            // ---- undo ----------------------------------------------------------------------------------------
            "undo" => {
                self.cancel_drag();
                if self.m.undo() {
                    Ok(ok)
                } else {
                    Err("Nothing to undo".into())
                }
            }
            "redo" => {
                if self.m.redo() {
                    Ok(ok)
                } else {
                    Err("Nothing to redo".into())
                }
            }
            "undo.history" => {
                let list = |v: Vec<String>| Json::Arr(v.into_iter().map(Json::from).collect());
                Ok(Json::obj().set("undo", list(self.m.history.undo_labels())).set("redo", list(self.m.history.redo_labels())))
            }
            // ---- operators -----------------------------------------------------------------------------------
            "op.list" => Ok(Json::obj().set("ops", forge_ops::list_json(a.get_str("context").unwrap_or("all")))),
            "op.run" => {
                let id = a.get_str("id").ok_or("missing 'id'")?;
                let params = a.get("params").cloned().unwrap_or_else(Json::obj);
                let o = self.m.run_op(id, &params)?;
                Ok(Json::obj().set("report", "FINISHED").set("message", o.message).set("created", id_list(&o.created)))
            }
            "op.redo" => {
                let params = a.get("params").cloned().unwrap_or_else(Json::obj);
                let o = self.m.redo_last(&params)?;
                Ok(Json::obj().set("report", "FINISHED").set("message", o.message).set("created", id_list(&o.created)))
            }
            // ---- property setters ----------------------------------------------------------------------------
            "object.set" | "object.rename" => {
                let id = need_u32(a, "id")?;
                let label = if method == "object.rename" { "Rename" } else { "Edit Object" };
                self.m.checkpoint(label, |scene, _| {
                    let name = a.get_str("name").map(|n| if scene.objects.iter().any(|o| o.id != id && o.name == n) { scene.unique_name(n) } else { n.to_string() });
                    let o = scene.get_mut(id).ok_or("No such object")?;
                    if let Some(n) = name {
                        o.name = n;
                    }
                    if let Some(v) = a.get("location").and_then(vec3_of) {
                        o.transform.location = v;
                    }
                    if let Some(v) = a.get("rotation").and_then(deg_of) {
                        o.transform.rotation = v;
                    }
                    if let Some(v) = a.get("scale").and_then(vec3_of) {
                        o.transform.scale = v;
                    }
                    if let Some(b) = a.get_bool("visible") {
                        o.visible = b;
                    }
                    if let Some(b) = a.get_bool("locked") {
                        o.locked = b;
                    }
                    Ok(())
                })?;
                Ok(ok)
            }
            "transform.numeric" => {
                let mode = a.get_str("mode").unwrap_or("move").to_string();
                let vals = a.get("values").and_then(|j| j.as_vec3()).ok_or("values must be [x, y, z]")?;
                let relative = a.get_bool("relative").unwrap_or(true);
                let local = a.get_str("space") == Some("local");
                let label = match mode.as_str() {
                    "rotate" => "Rotate",
                    "scale" => "Scale",
                    _ => "Move",
                };
                self.m.checkpoint(label, |scene, edit| {
                    let pivot = selection_pivot(scene, edit.as_ref()).ok_or("Nothing is selected")?;
                    let mut axes = [Vec3::X, Vec3::Y, Vec3::Z];
                    if local {
                        if let Some(o) = scene.active_object() {
                            let r = forge_math::euler_to_mat3(forge_math::EulerOrder::XYZ, o.transform.rotation);
                            axes = [r.cols[0], r.cols[1], r.cols[2]];
                        }
                    }
                    let v = Vec3::new(vals[0], vals[1], vals[2]);
                    match mode.as_str() {
                        "rotate" => {
                            for (i, ax) in axes.iter().enumerate() {
                                if vals[i] != 0.0 {
                                    apply_xform(scene, edit.as_ref(), &Xform::Rotate { axis: *ax, angle: vals[i].to_radians() }, pivot)?;
                                }
                            }
                            Ok(())
                        }
                        "scale" => apply_xform(scene, edit.as_ref(), &Xform::Scale { axes, factors: v }, pivot),
                        _ => {
                            let d = if relative { axes[0] * v.x + axes[1] * v.y + axes[2] * v.z } else { v - pivot };
                            apply_xform(scene, edit.as_ref(), &Xform::Translate(d), pivot)
                        }
                    }
                })?;
                Ok(ok)
            }
            "modifier.set" => {
                let oid = self.target_object(a, "object")?;
                let idx = a.get_u32("index").unwrap_or(0) as usize;
                self.m.checkpoint("Edit Modifier", |scene, _| {
                    let o = scene.get_mut(oid).ok_or("No such object")?;
                    let m = o.modifiers.get_mut(idx).ok_or("No such modifier")?;
                    if let Some(n) = a.get_str("name") {
                        m.name = n.to_string();
                    }
                    if let Some(b) = a.get_bool("show_viewport") {
                        m.show_viewport = b;
                    }
                    if let Some(p) = a.get("params") {
                        forge_mods::set_params(&mut m.kind, p);
                    }
                    o.rev = next_rev();
                    Ok(())
                })?;
                Ok(ok)
            }
            "modifier.move" => {
                let oid = self.target_object(a, "object")?;
                let (from, to) = (need_u32(a, "index")? as usize, need_u32(a, "to")? as usize);
                self.m.checkpoint("Move Modifier", |scene, _| {
                    let o = scene.get_mut(oid).ok_or("No such object")?;
                    if from >= o.modifiers.len() || to >= o.modifiers.len() {
                        return Err("Modifier index out of range".to_string());
                    }
                    let m = o.modifiers.remove(from);
                    o.modifiers.insert(to, m);
                    o.rev = next_rev();
                    Ok(())
                })?;
                Ok(ok)
            }
            "material.create" => {
                let mut new_id = 0;
                self.m.checkpoint("Add Material", |scene, _| {
                    let id = scene.add_material(a.get_str("name").unwrap_or("Material"));
                    new_id = id;
                    set_material_fields(scene, id, a)
                })?;
                Ok(Json::obj().set("id", new_id))
            }
            "material.set" => {
                let id = need_u32(a, "id")?;
                self.m.checkpoint("Edit Material", |scene, _| set_material_fields(scene, id, a))?;
                Ok(ok)
            }
            "material.assign" => {
                let oid = self.target_object(a, "object")?;
                let mat = need_u32(a, "material")?;
                let slot = a.get_u32("slot").unwrap_or(0) as usize;
                let selection = a.get_bool("selection").unwrap_or(false);
                self.m.checkpoint("Assign Material", |scene, edit| {
                    scene.material(mat).ok_or("No such material")?;
                    if let (true, Some(e)) = (selection, edit.as_ref()) {
                        let (eid, sel) = (e.object, e.sel.clone());
                        let (idx, mesh) = {
                            let o = scene.get_mut(eid).ok_or("No such object")?;
                            let idx = match o.materials.iter().position(|&m| m == mat) {
                                Some(i) => i,
                                None => {
                                    o.materials.push(mat);
                                    o.materials.len() - 1
                                }
                            };
                            (idx, Mesh::clone(o.mesh().ok_or("Not a mesh")?))
                        };
                        let mut mesh = mesh;
                        for f in sel.faces(&mesh) {
                            mesh.face_material[f as usize] = idx as u16;
                        }
                        scene.set_mesh(eid, mesh);
                    } else {
                        let o = scene.get_mut(oid).ok_or("No such object")?;
                        while o.materials.len() <= slot {
                            o.materials.push(0);
                        }
                        o.materials[slot] = mat;
                        o.rev = next_rev();
                    }
                    Ok(())
                })?;
                Ok(ok)
            }
            "material.slot_add" => {
                let oid = self.target_object(a, "object")?;
                self.m.checkpoint("Add Material Slot", |scene, _| {
                    let o = scene.get_mut(oid).ok_or("No such object")?;
                    o.materials.push(0);
                    o.rev = next_rev();
                    Ok(())
                })?;
                Ok(ok)
            }
            "material.slot_remove" => {
                let oid = self.target_object(a, "object")?;
                let slot = a.get_u32("slot").unwrap_or(0) as usize;
                self.m.checkpoint("Remove Material Slot", |scene, _| {
                    let mesh = {
                        let o = scene.get_mut(oid).ok_or("No such object")?;
                        if slot >= o.materials.len() {
                            return Err("No such slot".to_string());
                        }
                        o.materials.remove(slot);
                        o.rev = next_rev();
                        o.mesh().map(|m| Mesh::clone(m))
                    };
                    if let Some(mut m) = mesh {
                        for fm in &mut m.face_material {
                            let s = *fm as usize;
                            *fm = if s == slot { 0 } else if s > slot { (s - 1) as u16 } else { *fm };
                        }
                        scene.set_mesh(oid, m);
                    }
                    Ok(())
                })?;
                Ok(ok)
            }
            "light.set" => {
                let id = need_u32(a, "id")?;
                self.m.checkpoint("Edit Light", |scene, _| {
                    let o = scene.get_mut(id).ok_or("No such object")?;
                    let forge_scene::Data::Light(l) = &mut o.data else { return Err("The object is not a light".to_string()) };
                    if let Some(k) = a.get_str("type").and_then(LightKind::from_name) {
                        l.kind = k;
                    }
                    if let Some(c) = a.get("color").and_then(|j| j.as_vec3()) {
                        l.color = c;
                    }
                    if let Some(v) = a.get_f32("energy") {
                        l.energy = v.max(0.0);
                    }
                    if let Some(v) = a.get_f32("spot_size_deg") {
                        l.spot_size = v.clamp(1.0, 180.0).to_radians();
                    }
                    if let Some(v) = a.get_f32("spot_blend") {
                        l.spot_blend = v.clamp(0.0, 1.0);
                    }
                    Ok(())
                })?;
                Ok(ok)
            }
            // ---- scripting (arrives with the Python engine) ----------------------------------------------------
            "script.check" => Ok(Json::obj().set("diagnostics", Json::arr())),
            "script.run" | "script.commit" | "script.discard" => Err("The Python scripting engine is not part of this build yet".into()),
            "script.stop" | "script.clear_console" => Ok(ok),
            "script.console" => Ok(Json::obj().set("lines", Json::arr()).set("seq", 0)),
            "script.api_markdown" => Ok(Json::obj().set("markdown", "# RustForge 3D scripting\n\nThe Python scripting engine and its Blender-style `bpy` API are not part of this build yet.\n")),
            "script.ai_prompt" => Ok(Json::obj().set("prompt", "The Python scripting engine is not part of this build yet.")),
            "script.examples" => Ok(Json::obj().set("examples", Json::arr())),
            _ => Err(format!("unknown method '{method}'")),
        }
    }
}
