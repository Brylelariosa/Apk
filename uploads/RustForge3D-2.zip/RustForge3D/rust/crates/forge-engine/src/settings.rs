//! Typed, validated settings addressed by dotted paths (docs/PROTOCOL.md section 5). Persisted as JSON.
use forge_json::Json;

struct Spec {
    path: &'static str,
    default: Json,
    choices: &'static [&'static str],
    min: f64,
    max: f64,
}

fn num(path: &'static str, default: f64, min: f64, max: f64) -> Spec {
    Spec { path, default: Json::Num(default), choices: &[], min, max }
}
fn flag(path: &'static str, default: bool) -> Spec {
    Spec { path, default: Json::Bool(default), choices: &[], min: 0.0, max: 0.0 }
}
fn choice(path: &'static str, default: &'static str, choices: &'static [&'static str]) -> Spec {
    Spec { path, default: Json::from(default), choices, min: 0.0, max: 0.0 }
}

fn specs() -> Vec<Spec> {
    vec![
        num("touch.sensitivity", 1.0, 0.2, 4.0),
        num("touch.orbit_speed", 1.0, 0.2, 4.0),
        num("touch.pan_speed", 1.0, 0.2, 4.0),
        num("touch.zoom_speed", 1.0, 0.2, 4.0),
        flag("touch.invert_y", false),
        num("touch.hit_radius_dp", 28.0, 8.0, 80.0),
        num("touch.drag_threshold_dp", 8.0, 2.0, 40.0),
        flag("touch.stylus", true),
        choice("gestures.one_finger", "orbit", &["orbit", "pan", "none"]),
        choice("gestures.select_drag", "orbit", &["orbit", "box"]),
        choice("gestures.two_finger", "pan", &["pan", "orbit"]),
        choice("gestures.pinch", "zoom", &["zoom", "none"]),
        choice("gestures.double_tap", "focus", &["focus", "none"]),
        choice("gestures.three_finger", "undo_redo", &["undo_redo", "none"]),
        flag("gestures.lock_camera_in_tools", true),
        num("gizmo.size", 1.0, 0.5, 2.5),
        flag("gizmo.visible", true),
        choice("gizmo.orientation", "global", &["global", "local"]),
        flag("snap.grid", false),
        num("snap.grid_size", 0.25, 0.001, 100.0),
        flag("snap.angle", false),
        num("snap.angle_step_deg", 15.0, 1.0, 90.0),
        flag("snap.scale", false),
        num("snap.scale_step", 0.1, 0.01, 1.0),
        flag("snap.vertex", false),
        flag("select.additive", false),
        flag("select.xray_box", true),
        flag("select.through_hierarchy", false),
        choice("viewport.quality", "auto", &["auto", "low", "medium", "high"]),
        num("viewport.msaa", 4.0, 1.0, 4.0),
        num("viewport.resolution_scale", 1.0, 0.5, 1.0),
        num("viewport.polygon_limit", 3_000_000.0, 10_000.0, 50_000_000.0),
        num("viewport.max_fps", 60.0, 15.0, 120.0),
        flag("viewport.smooth_shading", true),
        num("script.time_limit_s", 30.0, 1.0, 600.0),
        num("script.memory_limit_mb", 256.0, 32.0, 4096.0),
        num("script.step_limit", 200_000_000.0, 1_000.0, 4_000_000_000.0),
        num("script.geometry_limit_verts", 2_000_000.0, 1_000.0, 50_000_000.0),
    ]
}

pub struct Settings {
    specs: Vec<Spec>,
    values: Vec<Json>,
}

impl Default for Settings {
    fn default() -> Self {
        Settings::new()
    }
}

impl Settings {
    pub fn new() -> Settings {
        let specs = specs();
        let values = specs.iter().map(|s| s.default.clone()).collect();
        Settings { specs, values }
    }

    fn idx(&self, path: &str) -> Option<usize> {
        self.specs.iter().position(|s| s.path == path)
    }

    pub fn get(&self, path: &str) -> Option<&Json> {
        self.idx(path).map(|i| &self.values[i])
    }
    pub fn f(&self, path: &str) -> f32 {
        self.get(path).and_then(|j| j.as_f32()).unwrap_or(0.0)
    }
    pub fn b(&self, path: &str) -> bool {
        self.get(path).and_then(|j| j.as_bool()).unwrap_or(false)
    }
    pub fn s(&self, path: &str) -> &str {
        self.get(path).and_then(|j| j.as_str()).unwrap_or("")
    }

    /// Validate and store one value (numbers are clamped).
    pub fn set(&mut self, path: &str, v: &Json) -> Result<(), String> {
        let i = self.idx(path).ok_or_else(|| format!("Unknown setting '{path}'"))?;
        let spec = &self.specs[i];
        let bad = || format!("Invalid value for '{path}'");
        let nv = match &spec.default {
            Json::Bool(_) => Json::Bool(v.as_bool().or_else(|| v.as_f64().map(|x| x != 0.0)).ok_or_else(bad)?),
            Json::Num(_) => {
                let x = v.as_f64().filter(|x| x.is_finite()).ok_or_else(bad)?;
                Json::Num(x.clamp(spec.min, spec.max))
            }
            _ => {
                let s = v.as_str().ok_or_else(bad)?;
                if !spec.choices.contains(&s) {
                    return Err(format!("'{s}' is not valid for '{path}' (use {})", spec.choices.join(", ")));
                }
                Json::from(s)
            }
        };
        self.values[i] = nv;
        Ok(())
    }

    /// Apply a nested settings object leniently (unknown or invalid entries are skipped).
    pub fn load(&mut self, j: &Json) {
        let paths: Vec<&'static str> = self.specs.iter().map(|s| s.path).collect();
        for path in paths {
            let mut cur = Some(j);
            for part in path.split('.') {
                cur = cur.and_then(|c| c.get(part));
            }
            if let Some(v) = cur {
                let _ = self.set(path, v);
            }
        }
    }

    /// Nested object in specification order.
    pub fn to_json(&self) -> Json {
        let mut root = Json::obj();
        let mut group = String::new();
        let mut cur = Json::obj();
        for (s, v) in self.specs.iter().zip(&self.values) {
            let (g, k) = s.path.split_once('.').unwrap_or(("", s.path));
            if g != group {
                if !group.is_empty() {
                    root.insert(&group, std::mem::replace(&mut cur, Json::obj()));
                }
                group = g.to_string();
            }
            cur.insert(k, v.clone());
        }
        if !group.is_empty() {
            root.insert(&group, cur);
        }
        root
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn set_validates_clamps_and_roundtrips() {
        let mut s = Settings::new();
        assert!(s.set("touch.sensitivity", &Json::Num(99.0)).is_ok());
        assert_eq!(s.f("touch.sensitivity"), 4.0);
        assert!(s.set("gestures.one_finger", &Json::from("pan")).is_ok());
        assert!(s.set("gestures.one_finger", &Json::from("spin")).is_err());
        assert!(s.set("nope.nothing", &Json::Num(1.0)).is_err());
        assert!(s.set("snap.grid", &Json::Num(1.0)).is_ok() && s.b("snap.grid"));
        let text = s.to_json().to_string();
        let mut t = Settings::new();
        t.load(&Json::parse(&text).unwrap());
        assert_eq!(t.s("gestures.one_finger"), "pan");
        assert_eq!(t.f("touch.sensitivity"), 4.0);
        assert!(s.to_json().get("viewport").and_then(|v| v.get("quality")).is_some());
    }
}
