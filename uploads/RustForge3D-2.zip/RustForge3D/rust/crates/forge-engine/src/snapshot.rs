//! Model -> the JSON state snapshot of docs/PROTOCOL.md section 3.
use crate::Engine;
use forge_json::Json;
use forge_mesh::{validate, Topology};
use forge_scene::{defs_to_json, Data, Object};

fn deg(v: forge_math::Vec3) -> Json {
    Json::vec3([v.x.to_degrees(), v.y.to_degrees(), v.z.to_degrees()])
}

fn active_json(e: &Engine, o: &Object) -> Json {
    let scene = &e.m.scene;
    let mut j = Json::obj()
        .set("id", o.id)
        .set("name", o.name.as_str())
        .set("kind", o.data.kind_name())
        .set("parent", 0)
        .set("collection", 1)
        .set(
            "transform",
            Json::obj().set("location", Json::vec3(o.transform.location.to_array())).set("rotation", deg(o.transform.rotation)).set("scale", Json::vec3(o.transform.scale.to_array())),
        );
    let mut dims = [0.0f32; 3];
    let mut mesh_j = Json::Null;
    if let Data::Mesh(m) = &o.data {
        let b = m.bounds();
        if m.vert_count() > 0 {
            let s = b.size();
            dims = [s.x * o.transform.scale.x.abs(), s.y * o.transform.scale.y.abs(), s.z * o.transform.scale.z.abs()];
        }
        let mut issues = Json::arr();
        if m.face_count() <= 20_000 {
            let r = validate(m);
            if !r.is_structurally_valid() || !r.is_manifold() {
                issues.push(r.summary());
            }
        }
        mesh_j = Json::obj()
            .set("verts", m.vert_count())
            .set("edges", m.edge_count())
            .set("faces", m.face_count())
            .set("tris", m.triangle_count())
            .set("data_name", o.name.as_str())
            .set("valid", issues.as_arr().map_or(true, |a| a.is_empty()))
            .set("issues", issues);
    }
    j.insert("dimensions", Json::vec3(dims));
    j.insert("mesh", mesh_j);
    let mut mods = Json::arr();
    for (i, m) in o.modifiers.iter().enumerate() {
        let defs = forge_mods::defs(m.kind.type_name());
        mods.push(
            Json::obj()
                .set("index", i)
                .set("type", m.kind.type_name())
                .set("name", m.name.as_str())
                .set("show_viewport", m.show_viewport)
                .set("show_render", true)
                .set("params", defs_to_json(&defs, &forge_mods::values(&m.kind))),
        );
    }
    j.insert("modifiers", mods);
    let mut slots = Json::arr();
    for (i, &mid) in o.materials.iter().enumerate() {
        let name = scene.material(mid).map(|m| m.name.clone());
        slots.push(Json::obj().set("slot", i).set("material", mid).set("name", name));
    }
    j.insert("slots", slots);
    let light = match &o.data {
        Data::Light(l) => Json::obj()
            .set("type", l.kind.name())
            .set("color", Json::vec3(l.color))
            .set("energy", l.energy)
            .set("spot_size_deg", l.spot_size.to_degrees())
            .set("spot_blend", l.spot_blend),
        _ => Json::Null,
    };
    j.insert("light", light);
    j.insert("camera", Json::Null);
    j
}

impl Engine {
    pub(crate) fn snapshot(&self) -> Json {
        let m = &self.m;
        let scene = &m.scene;
        let mut objects = Json::arr();
        for o in &scene.objects {
            let (verts, faces) = match &o.data {
                Data::Mesh(me) => (me.vert_count(), me.face_count()),
                _ => (0, 0),
            };
            let mat = o.materials.iter().find_map(|&id| scene.material(id)).map(|mm| mm.name.clone());
            objects.push(
                Json::obj()
                    .set("id", o.id)
                    .set("name", o.name.as_str())
                    .set("kind", o.data.kind_name())
                    .set("parent", 0)
                    .set("collection", 1)
                    .set("visible", o.visible)
                    .set("locked", o.locked)
                    .set("selected", scene.is_selected(o.id))
                    .set("active", scene.active == Some(o.id))
                    .set("verts", verts)
                    .set("faces", faces)
                    .set("modifiers", o.modifiers.len())
                    .set("material", mat),
            );
        }
        let mut collections = Json::arr();
        collections.push(Json::obj().set("id", 1).set("name", "Collection").set("parent", 0).set("visible", true).set("locked", false));
        let scene_j = Json::obj()
            .set("name", scene.name.as_str())
            .set("collections", collections)
            .set("objects", objects)
            .set("active", scene.active.unwrap_or(0))
            .set("selected_count", scene.selected.len());

        let active = scene.active_object().map(|o| active_json(self, o)).unwrap_or(Json::Null);

        let mut materials = Json::arr();
        for mt in &scene.materials {
            let users = scene.objects.iter().filter(|o| o.materials.contains(&mt.id)).count();
            materials.push(
                Json::obj()
                    .set("id", mt.id)
                    .set("name", mt.name.as_str())
                    .set("base_color", Json::from(mt.base_color))
                    .set("metallic", mt.metallic)
                    .set("roughness", mt.roughness)
                    .set("alpha", mt.base_color[3])
                    .set("emission", Json::vec3(mt.emission))
                    .set("emission_strength", mt.emission_strength)
                    .set("users", users),
            );
        }

        let edit = match &m.edit {
            Some(e) => match scene.get(e.object).and_then(|o| o.mesh()) {
                Some(mesh) => {
                    let sel = &e.sel;
                    let mut edges_sel = 0usize;
                    if mesh.face_count() <= 50_000 {
                        edges_sel = sel.count_edges(&Topology::build(mesh));
                    }
                    let idx = sel.indices();
                    let mut med = [0.0f32; 3];
                    if !idx.is_empty() {
                        let mut s = forge_math::Vec3::ZERO;
                        for &v in &idx {
                            if let Some(p) = mesh.positions.get(v as usize) {
                                s = s + *p;
                            }
                        }
                        s = s * (1.0 / idx.len() as f32);
                        med = s.to_array();
                    }
                    Json::obj()
                        .set("verts", Json::obj().set("total", mesh.vert_count()).set("selected", sel.count()))
                        .set("edges", Json::obj().set("total", mesh.edge_count()).set("selected", edges_sel))
                        .set("faces", Json::obj().set("total", mesh.face_count()).set("selected", sel.count_faces(mesh)))
                        .set("median", Json::vec3(med))
                }
                None => Json::Null,
            },
            None => Json::Null,
        };

        let last_op = match &m.last_op {
            Some(l) => {
                let defs = forge_ops::find(&l.id).map(|d| (d.params)()).unwrap_or_default();
                Json::obj().set("id", l.id.as_str()).set("label", l.label.as_str()).set("params", defs_to_json(&defs, &l.values))
            }
            None => Json::Null,
        };

        let (verts, faces, tris) = scene.totals();
        let tool_state = match &m.tool_state {
            Some(t) => Json::obj().set("kind", t.kind).set("label", t.label.as_str()).set("value", t.value).set("unit", t.unit).set("hint", t.hint.as_str()),
            None => Json::Null,
        };
        let toast = match &m.toast {
            Some(t) => Json::obj().set("seq", t.seq).set("level", t.level).set("text", t.text.as_str()),
            None => Json::Null,
        };
        Json::obj()
            .set("rev", m.rev)
            .set("mode", m.mode_name())
            .set("select_mode", m.select_mode.name())
            .set("tool", m.tool.id())
            .set("tool_state", tool_state)
            .set(
                "camera",
                Json::obj()
                    .set("projection", if m.camera.ortho { "ortho" } else { "persp" })
                    .set("view", m.view_name)
                    .set("fov_deg", m.camera.fov_y.to_degrees())
                    .set("yaw_deg", m.camera.yaw.to_degrees())
                    .set("pitch_deg", m.camera.pitch.to_degrees()),
            )
            .set(
                "view",
                Json::obj().set("shading", m.shading).set("grid", m.grid).set("axes", m.axes).set("wire_overlay", m.wire_overlay).set("xray", m.xray).set("stats", m.show_stats),
            )
            .set("scene", scene_j)
            .set("active", active)
            .set("materials", materials)
            .set("edit", edit)
            .set("last_op", last_op)
            .set(
                "undo",
                Json::obj()
                    .set("can_undo", m.history.can_undo())
                    .set("can_redo", m.history.can_redo())
                    .set("undo_label", m.history.undo_label())
                    .set("redo_label", m.history.redo_label())
                    .set("depth", m.history.depth()),
            )
            .set(
                "sculpt",
                Json::obj()
                    .set("brush", "draw")
                    .set("radius", 0.35)
                    .set("strength", 0.5)
                    .set("falloff", "smooth")
                    .set("invert", false)
                    .set("symmetry", Json::Arr(vec![Json::Bool(false), Json::Bool(false), Json::Bool(false)]))
                    .set("radius_unit", "world"),
            )
            .set("settings", m.settings.to_json())
            .set(
                "script",
                Json::obj().set("status", "idle").set("run_mode", "replace").set("elapsed_ms", 0).set("console_seq", 0).set("created", 0).set("error", Json::Null).set("available", false),
            )
            .set(
                "stats",
                Json::obj()
                    .set("objects", scene.objects.len())
                    .set("verts", verts)
                    .set("faces", faces)
                    .set("tris", tris)
                    .set("gpu_mb", m.stats.gpu_mb)
                    .set("fps", m.stats.fps)
                    .set("quality", m.quality_name())
                    .set("backend", m.stats.backend.as_str()),
            )
            .set("toast", toast)
    }
}
