//! Per-object display meshes (modifiers applied), render buffers and acceleration structures, keyed by the object's
//! revision. Shared by drawing (uploads) and picking (BVH, topology).
use crate::render_types::MeshUpdate;
use forge_bvh::Bvh;
use forge_mesh::{Mesh, OpCtx, RenderBuffers, Topology};
use forge_scene::{Data, ObjId, Object, Scene};
use std::collections::HashMap;
use std::sync::Arc;

struct Entry {
    rev: u64,
    editing: bool,
    display: Arc<Mesh>,
    buffers: Option<Arc<RenderBuffers>>,
    uploaded: bool,
    bvh: Option<Arc<Bvh>>,
    topo: Option<Arc<Topology>>,
}

#[derive(Default)]
pub struct MeshCache {
    entries: HashMap<ObjId, Entry>,
    /// Set when a modifier stack failed; the engine turns it into a toast.
    pub error: Option<String>,
}

impl MeshCache {
    fn ensure(&mut self, o: &Object, editing: bool, ctx: &OpCtx) -> Option<&mut Entry> {
        let Data::Mesh(base) = &o.data else { return None };
        let fresh = matches!(self.entries.get(&o.id), Some(e) if e.rev == o.rev && e.editing == editing);
        if !fresh {
            let display = if editing || !o.modifiers.iter().any(|m| m.show_viewport) {
                base.clone()
            } else {
                match forge_mods::evaluate(base, &o.modifiers, true, ctx) {
                    Ok(m) => Arc::new(m.into_owned()),
                    Err(e) => {
                        self.error = Some(format!("Modifier failed on {}: {e}", o.name));
                        base.clone()
                    }
                }
            };
            self.entries.insert(o.id, Entry { rev: o.rev, editing, display, buffers: None, uploaded: false, bvh: None, topo: None });
        }
        self.entries.get_mut(&o.id)
    }

    /// The mesh as displayed: base mesh while editing it, otherwise with the viewport modifiers applied.
    pub fn display(&mut self, o: &Object, editing: bool, ctx: &OpCtx) -> Option<Arc<Mesh>> {
        self.ensure(o, editing, ctx).map(|e| e.display.clone())
    }

    pub fn bvh(&mut self, o: &Object, editing: bool, ctx: &OpCtx) -> Option<Arc<Bvh>> {
        let e = self.ensure(o, editing, ctx)?;
        if e.bvh.is_none() {
            e.bvh = Some(Arc::new(Bvh::build(&e.display)));
        }
        e.bvh.clone()
    }

    pub fn topo(&mut self, o: &Object, editing: bool, ctx: &OpCtx) -> Option<Arc<Topology>> {
        let e = self.ensure(o, editing, ctx)?;
        if e.topo.is_none() {
            e.topo = Some(Arc::new(Topology::build(&e.display)));
        }
        e.topo.clone()
    }

    /// Uploads for new or changed visible meshes and removals for deleted objects.
    pub fn sync(&mut self, scene: &Scene, editing: Option<ObjId>, ctx: &OpCtx) -> Vec<MeshUpdate> {
        let mut out = Vec::new();
        let gone: Vec<ObjId> = self.entries.keys().copied().filter(|id| !scene.objects.iter().any(|o| o.id == *id && matches!(o.data, Data::Mesh(_)))).collect();
        for id in gone {
            self.entries.remove(&id);
            out.push(MeshUpdate::Remove { key: id as u64 });
        }
        for o in &scene.objects {
            if !o.visible {
                continue;
            }
            let editing_this = editing == Some(o.id);
            let Some(e) = self.ensure(o, editing_this, ctx) else { continue };
            if !e.uploaded {
                let b = Arc::new(RenderBuffers::build(&e.display));
                e.buffers = None;
                e.uploaded = true;
                out.push(MeshUpdate::Upload { key: o.id as u64, buffers: b });
            }
        }
        out
    }

    /// The GPU lost its buffers (new device or surface): upload everything again.
    pub fn invalidate_gpu(&mut self) {
        for e in self.entries.values_mut() {
            e.uploaded = false;
            e.buffers = None;
        }
    }
}
