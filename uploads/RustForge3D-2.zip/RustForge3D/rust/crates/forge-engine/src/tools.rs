//! Touch input -> tools: navigation, selection, box select and gizmo drags.
use crate::model::{Tool, ToolState};
use crate::picking;
use crate::Engine;
use forge_input::gizmo;
use forge_input::{Delta, DragSession, Event, Gestures, GizmoFrame, GizmoKind, Handle, PointerKind, Snap, Style, TouchBatch};
use forge_json::Json;
use forge_math::{euler_to_mat3, EulerOrder, Vec3};
use forge_ops::{apply_xform, selection_pivot, EditState, Xform};
use forge_scene::Scene;

pub struct GizmoDrag {
    session: DragSession,
    kind: GizmoKind,
    start_scene: Scene,
    start_edit: Option<EditState>,
    frame: GizmoFrame,
    changed: bool,
}

pub enum Drag {
    None,
    Orbit,
    Pan,
    Box { start: [f32; 2], additive: bool },
    Gizmo(Box<GizmoDrag>),
}

pub struct Input {
    pub gestures: Gestures,
    pub drag: Drag,
    /// Rubber band rectangle in pixels while box selecting.
    pub rubber: Option<[f32; 4]>,
    /// Gizmo handle being dragged (highlighted).
    pub active_handle: Option<Handle>,
}

impl Input {
    pub fn new(density: f32) -> Input {
        Input { gestures: Gestures::new(density), drag: Drag::None, rubber: None, active_handle: None }
    }
}

impl Engine {
    pub(crate) fn now_ms(&self) -> u64 {
        self.clock.elapsed().as_millis() as u64
    }

    pub(crate) fn handle_touch(&mut self, b: &TouchBatch) {
        let now = self.now_ms();
        for e in self.input.gestures.feed(b, now) {
            self.on_gesture(e);
        }
        self.redraw.request();
    }

    pub(crate) fn tick_gestures(&mut self) {
        let now = self.now_ms();
        for e in self.input.gestures.tick(now) {
            self.on_gesture(e);
        }
    }

    /// Abort whatever the pointer is doing (tool change, pause).
    pub(crate) fn cancel_drag(&mut self) {
        let _ = self.input.gestures.reset();
        self.on_drag_cancel();
    }

    pub(crate) fn gizmo_style(&self) -> Style {
        let mut s = Style::for_density(self.density);
        s.size_px *= self.m.settings.f("gizmo.size");
        s.pick_px = (self.m.settings.f("touch.hit_radius_dp") * self.density).max(s.pick_px);
        s
    }

    pub(crate) fn gizmo_kind(&self) -> Option<GizmoKind> {
        match self.m.tool {
            Tool::Move => Some(GizmoKind::Move),
            Tool::Rotate => Some(GizmoKind::Rotate),
            Tool::Scale => Some(GizmoKind::Scale),
            _ => None,
        }
    }

    pub(crate) fn gizmo_frame(&self) -> Option<GizmoFrame> {
        if !self.m.settings.b("gizmo.visible") {
            return None;
        }
        let origin = selection_pivot(&self.m.scene, self.m.edit.as_ref())?;
        let mut axes = [Vec3::X, Vec3::Y, Vec3::Z];
        if self.m.settings.s("gizmo.orientation") == "local" {
            if let Some(o) = self.m.scene.active_object() {
                let r = euler_to_mat3(EulerOrder::XYZ, o.transform.rotation);
                axes = [r.cols[0], r.cols[1], r.cols[2]];
            }
        }
        Some(GizmoFrame { origin, axes })
    }

    fn snap(&self) -> Snap {
        let s = &self.m.settings;
        Snap {
            enabled: true,
            translate: if s.b("snap.grid") { s.f("snap.grid_size") } else { 0.0 },
            rotate: if s.b("snap.angle") { s.f("snap.angle_step_deg").to_radians() } else { 0.0 },
            scale: if s.b("snap.scale") { s.f("snap.scale_step") } else { 0.0 },
        }
    }

    pub(crate) fn hit_radius(&self) -> f32 {
        self.m.settings.f("touch.hit_radius_dp") * self.density
    }

    fn on_gesture(&mut self, e: Event) {
        match e {
            Event::Down { pos, .. } => self.on_down(pos),
            Event::DragBegin { start, pos, kind, .. } => self.on_drag_begin(start, pos, kind),
            Event::Drag { pos, delta, .. } => self.on_drag(pos, delta),
            Event::DragEnd { pos, .. } => self.on_drag_end(pos),
            Event::DragCancel => self.on_drag_cancel(),
            Event::Tap { pos, .. } => self.on_tap(pos),
            Event::DoubleTap { .. } => {
                if self.m.settings.s("gestures.double_tap") == "focus" {
                    self.focus(false);
                }
            }
            Event::LongPress { pos, .. } => self.select_at(pos, true),
            Event::Multi { delta, scale, .. } => self.on_multi(delta, scale),
            Event::MultiBegin { .. } | Event::MultiEnd => {}
        }
    }

    fn on_down(&mut self, pos: [f32; 2]) {
        self.input.drag = Drag::None;
        self.input.rubber = None;
        self.input.active_handle = None;
        let (Some(kind), Some(frame)) = (self.gizmo_kind(), self.gizmo_frame()) else { return };
        let style = self.gizmo_style();
        let cam = &self.m.camera;
        let Some(h) = gizmo::pick(kind, &frame, cam, &style, pos) else { return };
        let Some(session) = DragSession::begin(kind, h, &frame, cam, &style, pos) else { return };
        self.input.drag = Drag::Gizmo(Box::new(GizmoDrag { session, kind, start_scene: self.m.scene.clone(), start_edit: self.m.edit.clone(), frame, changed: false }));
        self.input.active_handle = Some(h);
    }

    fn on_drag_begin(&mut self, start: [f32; 2], pos: [f32; 2], kind: PointerKind) {
        if !matches!(self.input.drag, Drag::None) {
            return;
        }
        let s = &self.m.settings;
        let pen = kind.is_pen() && s.b("touch.stylus");
        let action = match self.m.tool {
            Tool::BoxSelect => "box",
            Tool::Navigate if pen => "box",
            Tool::Navigate => s.s("gestures.one_finger"),
            Tool::Select if pen || s.s("gestures.select_drag") == "box" => "box",
            _ if pen => "none",
            _ => "orbit",
        };
        let additive = s.b("select.additive");
        match action {
            "box" => {
                self.input.drag = Drag::Box { start, additive };
                self.input.rubber = Some(picking::normalize_rect(start, pos));
            }
            "pan" => self.input.drag = Drag::Pan,
            "orbit" => self.input.drag = Drag::Orbit,
            _ => {}
        }
    }

    fn on_drag(&mut self, pos: [f32; 2], delta: [f32; 2]) {
        let s = &self.m.settings;
        let sens = s.f("touch.sensitivity");
        match &self.input.drag {
            Drag::Orbit => {
                let k = 0.0125 / self.density * s.f("touch.orbit_speed") * sens;
                let dy = if s.b("touch.invert_y") { -delta[1] } else { delta[1] };
                self.m.camera.orbit(delta[0], dy, k);
                self.m.view_name = "user";
                self.m.bump();
            }
            Drag::Pan => {
                let k = s.f("touch.pan_speed") * sens;
                self.m.camera.pan(delta[0] * k, delta[1] * k);
                self.m.bump();
            }
            Drag::Box { start, .. } => self.input.rubber = Some(picking::normalize_rect(*start, pos)),
            Drag::Gizmo(_) => self.update_gizmo(pos),
            Drag::None => {}
        }
        self.redraw.request();
    }

    fn update_gizmo(&mut self, pos: [f32; 2]) {
        let snap = self.snap();
        let Engine { input, m, .. } = self;
        let Drag::Gizmo(g) = &mut input.drag else { return };
        let d = g.session.update(pos, &snap);
        let (x, label, value, unit) = match d {
            Delta::Translate(v) => (Xform::Translate(v), "Move", v.length(), "m"),
            Delta::Rotate { axis, angle } => (Xform::Rotate { axis, angle }, "Rotate", angle.to_degrees(), "deg"),
            Delta::Scale(f) => (Xform::Scale { axes: g.frame.axes, factors: f }, "Scale", f.x, "x"),
        };
        let mut scene = g.start_scene.clone();
        if apply_xform(&mut scene, g.start_edit.as_ref(), &x, g.frame.origin).is_ok() {
            m.scene = scene;
            g.changed = true;
        }
        m.tool_state = Some(ToolState { kind: "transform", label: label.to_string(), value, unit, hint: "Release to apply".to_string() });
        m.bump();
    }

    fn on_drag_end(&mut self, pos: [f32; 2]) {
        match std::mem::replace(&mut self.input.drag, Drag::None) {
            Drag::Gizmo(g) => {
                let label = match g.kind {
                    GizmoKind::Move => "Move",
                    GizmoKind::Rotate => "Rotate",
                    GizmoKind::Scale => "Scale",
                };
                if g.changed {
                    self.m.history.push(label, &g.start_scene);
                    self.m.last_op = None;
                }
                self.m.tool_state = None;
                self.m.selection_changed();
            }
            Drag::Box { start, additive } => {
                self.input.rubber = None;
                self.box_select(picking::normalize_rect(start, pos), additive);
            }
            _ => {}
        }
        self.input.active_handle = None;
        self.redraw.request();
    }

    fn on_drag_cancel(&mut self) {
        if let Drag::Gizmo(g) = std::mem::replace(&mut self.input.drag, Drag::None) {
            self.m.scene = g.start_scene;
            self.m.edit = g.start_edit;
            self.m.tool_state = None;
            self.m.selection_changed();
        }
        self.input.drag = Drag::None;
        self.input.rubber = None;
        self.input.active_handle = None;
        self.redraw.request();
    }

    fn on_tap(&mut self, pos: [f32; 2]) {
        if matches!(self.input.drag, Drag::Gizmo(_)) {
            // the touch started on a handle and never moved: nothing to do
            self.input.drag = Drag::None;
            self.input.active_handle = None;
            return;
        }
        if self.m.tool == Tool::LoopCut {
            self.loop_cut_at(pos);
        } else {
            self.select_at(pos, false);
        }
    }

    fn on_multi(&mut self, delta: [f32; 2], scale: f32) {
        let s = &self.m.settings;
        let sens = s.f("touch.sensitivity");
        if s.s("gestures.two_finger") == "orbit" {
            let k = 0.0125 / self.density * s.f("touch.orbit_speed") * sens;
            self.m.camera.orbit(delta[0], delta[1], k);
            self.m.view_name = "user";
        } else {
            let k = s.f("touch.pan_speed") * sens;
            self.m.camera.pan(delta[0] * k, delta[1] * k);
        }
        if s.s("gestures.pinch") == "zoom" && scale > 0.0 {
            let z = s.f("touch.zoom_speed");
            self.m.camera.zoom(1.0 / scale.powf(z));
        }
        self.m.bump();
        self.redraw.request();
    }

    /// Tap selection (replace, or toggle when `additive`).
    pub(crate) fn select_at(&mut self, pos: [f32; 2], additive: bool) {
        let additive = additive || self.m.settings.b("select.additive");
        let r = self.hit_radius();
        if self.m.edit.is_some() {
            let hit = picking::pick_element(&self.m, &mut self.cache, pos, r);
            if let Some(e) = &mut self.m.edit {
                match hit {
                    Some(h) => {
                        if let Some(mesh) = self.m.scene.get(e.object).and_then(|o| o.mesh()) {
                            picking::select_hit(&mut e.sel, mesh, h, additive);
                        }
                    }
                    None if !additive => e.sel.clear(),
                    None => {}
                }
            }
        } else {
            match picking::pick_object(&self.m, &mut self.cache, pos, r) {
                Some(id) if additive => self.m.scene.toggle_select(id),
                Some(id) => self.m.scene.select_only(Some(id)),
                None if !additive => self.m.scene.select_only(None),
                None => {}
            }
        }
        self.m.selection_changed();
        self.redraw.request();
    }

    pub(crate) fn box_select(&mut self, rect: [f32; 4], additive: bool) {
        let additive = additive || self.m.settings.b("select.additive");
        let xray = self.m.settings.b("select.xray_box") || self.m.xray;
        if self.m.edit.is_some() {
            if let Some(found) = picking::box_select_elements(&self.m, &mut self.cache, rect, xray) {
                if let Some(e) = &mut self.m.edit {
                    if !additive {
                        e.sel.clear();
                    }
                    e.sel.resize(found.len());
                    for v in found.indices() {
                        e.sel.set(v, true);
                    }
                }
            }
        } else {
            let ids = picking::box_select_objects(&self.m, rect);
            if ids.is_empty() && !additive {
                self.m.scene.select_only(None);
            } else {
                self.m.select_objects(&ids, additive);
            }
        }
        self.m.selection_changed();
    }

    fn loop_cut_at(&mut self, pos: [f32; 2]) {
        if self.m.edit.is_none() {
            return;
        }
        let r = self.hit_radius();
        match picking::pick_edge(&self.m, &mut self.cache, pos, r) {
            Some((idx, _)) => {
                let args = Json::obj().set("edge", idx).set("number_cuts", 1);
                if let Err(e) = self.m.run_op("mesh.loopcut_slide", &args) {
                    self.m.toast("warn", e);
                }
            }
            None => self.m.toast("info", "Tap an edge of a quad ring to cut it"),
        }
        self.redraw.request();
    }

    /// Frame the selection (or everything when `all` or nothing is selected).
    pub(crate) fn focus(&mut self, all: bool) {
        let mut bounds = None;
        if !all {
            if let Some(e) = &self.m.edit {
                if let Some(o) = self.m.scene.get(e.object) {
                    if let (Some(mesh), true) = (o.mesh(), e.sel.any()) {
                        let w = o.transform.matrix();
                        let pts = e.sel.indices().into_iter().filter_map(|v| mesh.positions.get(v as usize)).map(|p| w.transform_point3(*p));
                        bounds = Some(forge_math::Aabb::from_points(pts));
                    }
                }
            } else if !self.m.scene.selected.is_empty() {
                bounds = self.m.scene.bounds(true);
            }
        }
        if bounds.is_none() {
            bounds = self.m.scene.bounds(false);
        }
        if let Some(b) = bounds {
            self.m.camera.frame(&b);
            self.m.bump();
        }
        self.redraw.request();
    }
}
