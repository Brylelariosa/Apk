//! The document and view state of the application: scene, undo history, edit mode, camera, tool, view options.
//! Pure state transitions; no touch handling and no GPU.
use crate::render_types::RenderStats;
use crate::settings::Settings;
use forge_input::{Camera, ViewPreset};
use forge_json::Json;
use forge_mesh::{OpCtx, Selection, Topology};
use forge_ops::{EditState, OpEnv, OpOutcome, SelectMode};
use forge_scene::{History, ObjId, Scene};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Tool {
    Navigate,
    Select,
    BoxSelect,
    Move,
    Rotate,
    Scale,
    Extrude,
    Inset,
    LoopCut,
}

impl Tool {
    pub fn id(self) -> &'static str {
        match self {
            Tool::Navigate => "navigate",
            Tool::Select => "select",
            Tool::BoxSelect => "box_select",
            Tool::Move => "move",
            Tool::Rotate => "rotate",
            Tool::Scale => "scale",
            Tool::Extrude => "extrude",
            Tool::Inset => "inset",
            Tool::LoopCut => "loop_cut",
        }
    }
    pub fn from_id(s: &str) -> Option<Tool> {
        [Tool::Navigate, Tool::Select, Tool::BoxSelect, Tool::Move, Tool::Rotate, Tool::Scale, Tool::Extrude, Tool::Inset, Tool::LoopCut].into_iter().find(|t| t.id() == s)
    }
    pub fn edit_only(self) -> bool {
        matches!(self, Tool::Extrude | Tool::Inset | Tool::LoopCut)
    }
}

pub struct Toast {
    pub seq: u32,
    pub level: &'static str,
    pub text: String,
}

pub struct ToolState {
    pub kind: &'static str,
    pub label: String,
    pub value: f32,
    pub unit: &'static str,
    pub hint: String,
}

/// The operator that can still be adjusted from the redo panel.
pub struct LastOp {
    pub id: String,
    pub label: String,
    pub values: Json,
    before: Scene,
    before_edit: Option<EditState>,
}

pub struct Model {
    pub scene: Scene,
    pub history: History,
    pub edit: Option<EditState>,
    pub select_mode: SelectMode,
    pub last_op: Option<LastOp>,
    pub camera: Camera,
    pub view_name: &'static str,
    pub tool: Tool,
    pub shading: &'static str,
    pub grid: bool,
    pub axes: bool,
    pub wire_overlay: bool,
    pub xray: bool,
    pub show_stats: bool,
    pub settings: Settings,
    pub toast: Option<Toast>,
    toast_seq: u32,
    pub rev: u64,
    /// Changes whenever the object or element selection changes (overlays depend on it).
    pub sel_rev: u64,
    pub ctx: OpCtx,
    pub stats: RenderStats,
    pub auto_level: u8,
    pub tool_state: Option<ToolState>,
}

pub fn default_scene() -> Scene {
    let mut s = Scene::new();
    let id = s.add_mesh("Cube", forge_geom::cube(2.0, true));
    s.set_selection(&[id], Some(id));
    s
}

impl Model {
    pub fn new(settings: Settings) -> Model {
        Model {
            scene: default_scene(),
            history: History::new(100),
            edit: None,
            select_mode: SelectMode::Vertex,
            last_op: None,
            camera: Camera::default(),
            view_name: "user",
            tool: Tool::Select,
            shading: "solid",
            grid: true,
            axes: true,
            wire_overlay: false,
            xray: false,
            show_stats: false,
            settings,
            toast: None,
            toast_seq: 0,
            rev: 1,
            sel_rev: 1,
            ctx: OpCtx::new(),
            stats: RenderStats::default(),
            auto_level: 2,
            tool_state: None,
        }
    }

    pub fn bump(&mut self) {
        self.rev += 1;
    }
    pub fn selection_changed(&mut self) {
        self.sel_rev += 1;
        self.rev += 1;
    }

    pub fn toast(&mut self, level: &'static str, text: impl Into<String>) {
        self.toast_seq += 1;
        self.toast = Some(Toast { seq: self.toast_seq, level, text: text.into() });
        self.bump();
    }

    pub fn mode_name(&self) -> &'static str {
        if self.edit.is_some() {
            "edit"
        } else {
            "object"
        }
    }

    // ---- undoable changes ------------------------------------------------------------------------------------

    /// Run `f` on the scene as one undo step. On error the scene is restored and nothing is recorded.
    pub fn checkpoint<T>(&mut self, label: &str, f: impl FnOnce(&mut Scene, &mut Option<EditState>) -> Result<T, String>) -> Result<T, String> {
        let before = self.scene.clone();
        let before_edit = self.edit.clone();
        match f(&mut self.scene, &mut self.edit) {
            Ok(v) => {
                self.history.push(label, &before);
                self.last_op = None;
                self.selection_changed();
                Ok(v)
            }
            Err(e) => {
                self.scene = before;
                self.edit = before_edit;
                Err(e)
            }
        }
    }

    pub fn run_op(&mut self, id: &str, values: &Json) -> Result<OpOutcome, String> {
        let label = forge_ops::find(id).map(|d| d.label).ok_or_else(|| format!("Unknown operator '{id}'"))?;
        let before = self.scene.clone();
        let before_edit = self.edit.clone();
        let res = {
            let mut env = OpEnv { scene: &mut self.scene, edit: &mut self.edit, ctx: &self.ctx };
            forge_ops::run(id, &mut env, values)
        };
        match res {
            Ok(r) => {
                self.history.push(label, &before);
                self.last_op = Some(LastOp { id: id.to_string(), label: label.to_string(), values: r.values, before, before_edit });
                self.selection_changed();
                Ok(r.outcome)
            }
            Err(e) => {
                self.scene = before;
                self.edit = before_edit;
                Err(e)
            }
        }
    }

    /// Re-run the last operator from its pre-operation state with changed parameters.
    pub fn redo_last(&mut self, patch: &Json) -> Result<OpOutcome, String> {
        let last = self.last_op.take().ok_or("There is no operation to adjust")?;
        let post_scene = self.scene.clone();
        let post_edit = self.edit.clone();
        self.history.pop_last();
        self.scene = last.before.clone();
        self.edit = last.before_edit.clone();
        let mut values = last.values.clone();
        if let Some(o) = patch.as_obj() {
            for (k, v) in o {
                values.insert(k, v.clone());
            }
        }
        match self.run_op(&last.id, &values) {
            Ok(o) => Ok(o),
            Err(e) => {
                self.scene = post_scene;
                self.edit = post_edit;
                self.history.push(&last.label, &last.before);
                self.last_op = Some(last);
                Err(e)
            }
        }
    }

    fn fix_edit_after_history(&mut self) {
        let valid = match &mut self.edit {
            Some(e) => match self.scene.get(e.object).and_then(|o| o.mesh()) {
                Some(m) => {
                    e.sel.resize(m.vert_count());
                    true
                }
                None => false,
            },
            None => true,
        };
        if !valid {
            self.edit = None;
        }
        if self.edit.is_none() && self.tool.edit_only() {
            self.tool = Tool::Select;
        }
    }

    pub fn undo(&mut self) -> bool {
        match self.history.undo(&self.scene) {
            Some(s) => {
                self.scene = s;
                self.last_op = None;
                self.fix_edit_after_history();
                self.selection_changed();
                true
            }
            None => false,
        }
    }

    pub fn redo(&mut self) -> bool {
        match self.history.redo(&self.scene) {
            Some(s) => {
                self.scene = s;
                self.last_op = None;
                self.fix_edit_after_history();
                self.selection_changed();
                true
            }
            None => false,
        }
    }

    pub fn new_project(&mut self) {
        self.replace_scene(default_scene());
        self.camera = Camera::default();
        self.view_name = "user";
    }

    /// Replace the whole document (project load / new): clears history and edit mode.
    pub fn replace_scene(&mut self, scene: Scene) {
        self.scene = scene;
        self.history.clear();
        self.edit = None;
        self.last_op = None;
        self.tool_state = None;
        if self.tool.edit_only() {
            self.tool = Tool::Select;
        }
        self.selection_changed();
    }

    // ---- modes and selection ---------------------------------------------------------------------------------

    pub fn enter_edit(&mut self) -> Result<(), String> {
        if self.edit.is_some() {
            return Ok(());
        }
        let id = self.scene.active.ok_or("Select a mesh object first")?;
        let n = self.scene.get(id).and_then(|o| o.mesh()).ok_or("Only mesh objects can be edited")?.vert_count();
        self.edit = Some(EditState { object: id, mode: self.select_mode, sel: Selection::none(n) });
        self.last_op = None;
        self.selection_changed();
        Ok(())
    }

    pub fn exit_edit(&mut self) {
        if self.edit.take().is_some() {
            self.last_op = None;
            self.tool_state = None;
            if self.tool.edit_only() {
                self.tool = Tool::Select;
            }
            self.selection_changed();
        }
    }

    /// Switch the element mode, converting the selection like Blender does when it gets more specific.
    pub fn set_select_mode(&mut self, mode: SelectMode) {
        self.select_mode = mode;
        if let Some(e) = &mut self.edit {
            e.mode = mode;
            if let Some(mesh) = self.scene.get(e.object).and_then(|o| o.mesh()) {
                let mut keep = vec![false; mesh.vert_count()];
                match mode {
                    SelectMode::Vertex => keep.clone_from(&e.sel.verts),
                    SelectMode::Face => {
                        for f in e.sel.faces(mesh) {
                            for &v in mesh.face_verts(f as usize) {
                                keep[v as usize] = true;
                            }
                        }
                    }
                    SelectMode::Edge => {
                        let topo = Topology::build(mesh);
                        for ed in e.sel.edges(&topo) {
                            for v in topo.edges[ed as usize] {
                                keep[v as usize] = true;
                            }
                        }
                    }
                }
                e.sel.verts = keep;
            }
        }
        self.selection_changed();
    }

    pub fn select_objects(&mut self, ids: &[ObjId], extend: bool) {
        let mut all: Vec<ObjId> = if extend { self.scene.selected.clone() } else { Vec::new() };
        for &i in ids {
            if !all.contains(&i) {
                all.push(i);
            }
        }
        let active = ids.last().copied();
        self.scene.set_selection(&all, active);
        self.selection_changed();
    }

    // ---- quality ---------------------------------------------------------------------------------------------

    /// (msaa samples, resolution scale, polygon limit) after resolving the "auto" preset.
    pub fn quality(&self) -> (u32, f32, u64) {
        let level = match self.settings.s("viewport.quality") {
            "low" => 0,
            "medium" => 1,
            "high" => 2,
            _ => self.auto_level,
        };
        match level {
            0 => (1, 0.7, 300_000),
            1 => (4, 0.85, 1_000_000),
            _ => (4, 1.0, 3_000_000),
        }
    }
    pub fn quality_name(&self) -> &'static str {
        match self.settings.s("viewport.quality") {
            "low" => "low",
            "medium" => "medium",
            "high" => "high",
            _ => ["low", "medium", "high"][self.auto_level.min(2) as usize],
        }
    }

    pub fn preset(&mut self, name: &str) -> bool {
        let p = match name {
            "front" => ViewPreset::Front,
            "back" => ViewPreset::Back,
            "left" => ViewPreset::Left,
            "right" => ViewPreset::Right,
            "top" => ViewPreset::Top,
            "bottom" => ViewPreset::Bottom,
            _ => return false,
        };
        self.camera.set_preset(p);
        self.camera.ortho = true;
        self.view_name = match p {
            ViewPreset::Front => "front",
            ViewPreset::Back => "back",
            ViewPreset::Left => "left",
            ViewPreset::Right => "right",
            ViewPreset::Top => "top",
            ViewPreset::Bottom => "bottom",
        };
        true
    }
}
