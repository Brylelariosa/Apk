//! `.rforge` project files: magic `RFORGE01`, a newline, then the scene as JSON.
use crate::*;
use forge_json::Json;
use forge_math::{Vec2, Vec3};
use forge_mesh::Mesh;
use std::sync::Arc;

pub const PROJECT_MAGIC: &[u8] = b"RFORGE01\n";

fn mesh_to_json(m: &Mesh) -> Json {
    let pos: Vec<f32> = m.positions.iter().flat_map(|p| [p.x, p.y, p.z]).collect();
    let loose: Vec<u32> = m.loose_edges.iter().flat_map(|e| [e[0], e[1]]).collect();
    let uvs: Vec<f32> = m.uvs.iter().flat_map(|u| [u.x, u.y]).collect();
    let mats: Vec<u32> = m.face_material.iter().map(|&x| x as u32).collect();
    Json::obj()
        .set("positions", Json::f32s(&pos))
        .set("face_starts", m.face_starts.clone())
        .set("corners", m.corners.clone())
        .set("face_material", mats)
        .set("face_smooth", m.face_smooth.clone())
        .set("loose", loose)
        .set("uvs", Json::f32s(&uvs))
}

fn u32s(j: Option<&Json>) -> Result<Vec<u32>, String> {
    let a = j.and_then(|j| j.as_arr()).ok_or("expected an array")?;
    a.iter().map(|x| x.as_u32().ok_or_else(|| "expected an unsigned integer".to_string())).collect()
}

fn f32s(j: Option<&Json>) -> Result<Vec<f32>, String> {
    let a = j.and_then(|j| j.as_arr()).ok_or("expected an array")?;
    a.iter().map(|x| x.as_f32().ok_or_else(|| "expected a number".to_string())).collect()
}

fn mesh_from_json(j: &Json) -> Result<Mesh, String> {
    let pos = f32s(j.get("positions"))?;
    if pos.len() % 3 != 0 {
        return Err("positions length is not a multiple of 3".into());
    }
    let mut m = Mesh::new();
    m.positions = pos.chunks(3).map(|c| Vec3::new(c[0], c[1], c[2])).collect();
    m.face_starts = u32s(j.get("face_starts"))?;
    m.corners = u32s(j.get("corners"))?;
    m.face_material = u32s(j.get("face_material"))?.into_iter().map(|x| x.min(u16::MAX as u32) as u16).collect();
    m.face_smooth = j.get("face_smooth").and_then(|a| a.as_arr()).ok_or("face_smooth missing")?.iter().map(|b| b.as_bool().unwrap_or(false)).collect();
    m.loose_edges = u32s(j.get("loose"))?.chunks(2).filter(|c| c.len() == 2).map(|c| [c[0], c[1]]).collect();
    m.uvs = f32s(j.get("uvs"))?.chunks(2).filter(|c| c.len() == 2).map(|c| Vec2::new(c[0], c[1])).collect();
    m.check_structure()?;
    Ok(m)
}

fn object_to_json(o: &Object) -> Json {
    let t = &o.transform;
    let mut j = Json::obj()
        .set("id", o.id)
        .set("name", o.name.as_str())
        .set("kind", o.data.kind_name())
        .set("location", Json::vec3(t.location.to_array()))
        .set("rotation", Json::vec3(t.rotation.to_array()))
        .set("scale", Json::vec3(t.scale.to_array()))
        .set("visible", o.visible)
        .set("locked", o.locked)
        .set("materials", o.materials.clone());
    match &o.data {
        Data::Mesh(m) => j.insert("mesh", mesh_to_json(m)),
        Data::Light(l) => j.insert(
            "light",
            Json::obj().set("type", l.kind.name()).set("color", l.color).set("energy", l.energy).set("spot_size", l.spot_size).set("spot_blend", l.spot_blend),
        ),
        Data::Empty => {}
    }
    let mut mods = Json::arr();
    for m in &o.modifiers {
        let mut mj = Json::obj().set("name", m.name.as_str()).set("show_viewport", m.show_viewport).set("type", m.kind.type_name());
        match &m.kind {
            ModKind::Mirror { axes, merge, merge_distance } => {
                mj.insert("axes", vec![axes[0], axes[1], axes[2]]);
                mj.insert("merge", *merge);
                mj.insert("merge_distance", *merge_distance);
            }
            ModKind::Subsurf { levels } => mj.insert("levels", *levels),
        }
        mods.push(mj);
    }
    j.insert("modifiers", mods);
    j
}

fn vec3_of(j: Option<&Json>, default: Vec3) -> Vec3 {
    j.and_then(|j| j.as_vec3()).map(Vec3::from_array).unwrap_or(default)
}

fn object_from_json(j: &Json) -> Result<Object, String> {
    let id = j.get_u32("id").ok_or("object without id")?;
    let data = match j.get_str("kind").unwrap_or("empty") {
        "mesh" => Data::Mesh(Arc::new(mesh_from_json(j.get("mesh").ok_or("mesh object without mesh data")?)?)),
        "light" => {
            let l = j.get("light").ok_or("light object without light data")?;
            let mut light = Light::new(LightKind::from_name(l.get_str("type").unwrap_or("POINT")).unwrap_or(LightKind::Point));
            light.color = l.get("color").and_then(|c| c.as_f32_array::<3>()).unwrap_or([1.0; 3]);
            light.energy = l.get_f32("energy").unwrap_or(light.energy);
            light.spot_size = l.get_f32("spot_size").unwrap_or(light.spot_size);
            light.spot_blend = l.get_f32("spot_blend").unwrap_or(light.spot_blend);
            Data::Light(light)
        }
        _ => Data::Empty,
    };
    let mut modifiers = Vec::new();
    for m in j.get("modifiers").and_then(|m| m.as_arr()).unwrap_or(&[]) {
        let name = m.get_str("name").unwrap_or("Modifier").to_string();
        let show_viewport = m.get_bool("show_viewport").unwrap_or(true);
        let kind = match m.get_str("type") {
            Some("MIRROR") => {
                let a = m.get("axes").and_then(|a| a.as_arr()).unwrap_or(&[]);
                let axis = |i: usize| a.get(i).and_then(|b| b.as_bool()).unwrap_or(i == 0);
                ModKind::Mirror { axes: [axis(0), axis(1), axis(2)], merge: m.get_bool("merge").unwrap_or(true), merge_distance: m.get_f32("merge_distance").unwrap_or(0.001) }
            }
            Some("SUBSURF") => ModKind::Subsurf { levels: m.get_u32("levels").unwrap_or(1) },
            other => return Err(format!("unknown modifier type {other:?}")),
        };
        modifiers.push(Modifier { name, show_viewport, kind });
    }
    Ok(Object {
        id,
        name: j.get_str("name").unwrap_or("Object").to_string(),
        data,
        transform: Transform {
            location: vec3_of(j.get("location"), Vec3::ZERO),
            rotation: vec3_of(j.get("rotation"), Vec3::ZERO),
            scale: vec3_of(j.get("scale"), Vec3::ONE),
        },
        materials: u32s(j.get("materials")).unwrap_or_default(),
        modifiers,
        visible: j.get_bool("visible").unwrap_or(true),
        locked: j.get_bool("locked").unwrap_or(false),
        rev: next_rev(),
    })
}

pub fn scene_to_json(s: &Scene) -> Json {
    let mut mats = Json::arr();
    for m in &s.materials {
        mats.push(
            Json::obj()
                .set("id", m.id)
                .set("name", m.name.as_str())
                .set("base_color", m.base_color)
                .set("metallic", m.metallic)
                .set("roughness", m.roughness)
                .set("emission", m.emission)
                .set("emission_strength", m.emission_strength),
        );
    }
    let mut objs = Json::arr();
    for o in &s.objects {
        objs.push(object_to_json(o));
    }
    Json::obj()
        .set("format", "rustforge")
        .set("version", 1u32)
        .set("name", s.name.as_str())
        .set("next_obj", s.next_obj)
        .set("next_mat", s.next_mat)
        .set("active", s.active.unwrap_or(0))
        .set("selected", s.selected.clone())
        .set("materials", mats)
        .set("objects", objs)
}

pub fn scene_from_json(j: &Json) -> Result<Scene, String> {
    if j.get_str("format") != Some("rustforge") {
        return Err("not a RustForge project".into());
    }
    let mut s = Scene::new();
    s.name = j.get_str("name").unwrap_or("Scene").to_string();
    for m in j.get("materials").and_then(|m| m.as_arr()).unwrap_or(&[]) {
        let mut mat = Material::new(m.get_u32("id").ok_or("material without id")?, m.get_str("name").unwrap_or("Material"));
        mat.base_color = m.get("base_color").and_then(|c| c.as_f32_array::<4>()).unwrap_or(mat.base_color);
        mat.metallic = m.get_f32("metallic").unwrap_or(0.0);
        mat.roughness = m.get_f32("roughness").unwrap_or(0.5);
        mat.emission = m.get("emission").and_then(|c| c.as_f32_array::<3>()).unwrap_or([0.0; 3]);
        mat.emission_strength = m.get_f32("emission_strength").unwrap_or(0.0);
        s.materials.push(mat);
    }
    for o in j.get("objects").and_then(|o| o.as_arr()).unwrap_or(&[]) {
        s.objects.push(object_from_json(o)?);
    }
    s.next_obj = j.get_u32("next_obj").unwrap_or(1).max(s.objects.iter().map(|o| o.id + 1).max().unwrap_or(1));
    s.next_mat = j.get_u32("next_mat").unwrap_or(1).max(s.materials.iter().map(|m| m.id + 1).max().unwrap_or(1));
    let sel = u32s(j.get("selected")).unwrap_or_default();
    let active = j.get_u32("active").filter(|&a| a != 0);
    s.set_selection(&sel, active);
    Ok(s)
}

pub fn save_bytes(s: &Scene) -> Vec<u8> {
    let mut out = PROJECT_MAGIC.to_vec();
    out.extend_from_slice(scene_to_json(s).to_string().as_bytes());
    out
}

pub fn load_bytes(data: &[u8]) -> Result<Scene, String> {
    let body = data.strip_prefix(PROJECT_MAGIC).ok_or("not a RustForge project (bad header)")?;
    let text = std::str::from_utf8(body).map_err(|_| "project is not valid UTF-8".to_string())?;
    let j = Json::parse(text).map_err(|e| format!("project JSON error: {e}"))?;
    scene_from_json(&j)
}
