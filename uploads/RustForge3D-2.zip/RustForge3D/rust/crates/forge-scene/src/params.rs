//! Parameter schemas shared by operators and modifiers (rendered generically by the UI, see docs/PROTOCOL.md).
use forge_json::Json;

#[derive(Clone, Debug)]
pub enum ParamKind {
    Float,
    Int,
    Bool,
    BVec3,
    Vec3,
    Color,
    Enum(Vec<(String, String)>),
    Text,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Unit {
    None,
    Length,
    /// Values are exchanged in degrees.
    Angle,
}

#[derive(Clone, Debug)]
pub struct ParamDef {
    pub name: String,
    pub label: String,
    pub kind: ParamKind,
    pub default: Json,
    pub min: Option<f64>,
    pub max: Option<f64>,
    pub soft_max: Option<f64>,
    pub step: Option<f64>,
    pub unit: Unit,
    pub help: String,
    pub visible_if: Option<(String, Json)>,
}

impl ParamDef {
    fn base(name: &str, label: &str, kind: ParamKind, default: Json) -> ParamDef {
        ParamDef { name: name.into(), label: label.into(), kind, default, min: None, max: None, soft_max: None, step: None, unit: Unit::None, help: String::new(), visible_if: None }
    }
    pub fn float(name: &str, label: &str, default: f64) -> ParamDef {
        ParamDef::base(name, label, ParamKind::Float, Json::Num(default))
    }
    pub fn int(name: &str, label: &str, default: i64) -> ParamDef {
        ParamDef { step: Some(1.0), ..ParamDef::base(name, label, ParamKind::Int, Json::Num(default as f64)) }
    }
    pub fn boolean(name: &str, label: &str, default: bool) -> ParamDef {
        ParamDef::base(name, label, ParamKind::Bool, Json::Bool(default))
    }
    pub fn bvec3(name: &str, label: &str, default: [bool; 3]) -> ParamDef {
        ParamDef::base(name, label, ParamKind::BVec3, Json::Arr(default.iter().map(|&b| Json::Bool(b)).collect()))
    }
    pub fn vec3(name: &str, label: &str, default: [f32; 3]) -> ParamDef {
        ParamDef::base(name, label, ParamKind::Vec3, Json::vec3(default))
    }
    pub fn color(name: &str, label: &str, default: [f32; 4]) -> ParamDef {
        ParamDef::base(name, label, ParamKind::Color, Json::from(default))
    }
    pub fn text(name: &str, label: &str) -> ParamDef {
        ParamDef::base(name, label, ParamKind::Text, Json::from(""))
    }
    pub fn choice(name: &str, label: &str, default: &str, options: &[(&str, &str)]) -> ParamDef {
        let opts = options.iter().map(|(a, b)| (a.to_string(), b.to_string())).collect();
        ParamDef::base(name, label, ParamKind::Enum(opts), Json::from(default))
    }
    pub fn range(mut self, min: f64, max: f64) -> ParamDef {
        self.min = Some(min);
        self.max = Some(max);
        self
    }
    pub fn min(mut self, min: f64) -> ParamDef {
        self.min = Some(min);
        self
    }
    pub fn soft_max(mut self, v: f64) -> ParamDef {
        self.soft_max = Some(v);
        self
    }
    pub fn step(mut self, v: f64) -> ParamDef {
        self.step = Some(v);
        self
    }
    pub fn length(mut self) -> ParamDef {
        self.unit = Unit::Length;
        self
    }
    pub fn angle(mut self) -> ParamDef {
        self.unit = Unit::Angle;
        self
    }
    pub fn help(mut self, text: &str) -> ParamDef {
        self.help = text.into();
        self
    }
    pub fn visible_if(mut self, name: &str, equals: impl Into<Json>) -> ParamDef {
        self.visible_if = Some((name.into(), equals.into()));
        self
    }

    fn type_name(&self) -> &'static str {
        match self.kind {
            ParamKind::Float => "float",
            ParamKind::Int => "int",
            ParamKind::Bool => "bool",
            ParamKind::BVec3 => "bvec3",
            ParamKind::Vec3 => "vec3",
            ParamKind::Color => "color",
            ParamKind::Enum(_) => "enum",
            ParamKind::Text => "string",
        }
    }

    /// The protocol `ParamDef` object including the current value.
    pub fn to_json(&self, value: Option<&Json>) -> Json {
        let mut j = Json::obj()
            .set("name", self.name.as_str())
            .set("label", self.label.as_str())
            .set("type", self.type_name())
            .set("value", value.cloned().unwrap_or_else(|| self.default.clone()))
            .set("default", self.default.clone());
        if let Some(v) = self.min {
            j.insert("min", Json::Num(v));
        }
        if let Some(v) = self.max {
            j.insert("max", Json::Num(v));
        }
        if let Some(v) = self.soft_max {
            j.insert("soft_max", Json::Num(v));
        }
        if let Some(v) = self.step {
            j.insert("step", Json::Num(v));
        }
        j.insert("unit", match self.unit {
            Unit::None => "none",
            Unit::Length => "length",
            Unit::Angle => "angle",
        });
        if let ParamKind::Enum(opts) = &self.kind {
            let mut a = Json::arr();
            for (id, label) in opts {
                a.push(Json::Arr(vec![Json::from(id.as_str()), Json::from(label.as_str())]));
            }
            j.insert("options", a);
        }
        if !self.help.is_empty() {
            j.insert("help", self.help.as_str());
        }
        if let Some((n, v)) = &self.visible_if {
            j.insert("visible_if", Json::obj().set("name", n.as_str()).set("equals", v.clone()));
        }
        j
    }
}

/// Typed access to a parameter object with schema defaults and clamping.
pub struct Params<'a> {
    pub defs: &'a [ParamDef],
    pub values: &'a Json,
}

impl<'a> Params<'a> {
    pub fn new(defs: &'a [ParamDef], values: &'a Json) -> Params<'a> {
        Params { defs, values }
    }
    fn def(&self, name: &str) -> Option<&ParamDef> {
        self.defs.iter().find(|d| d.name == name)
    }
    fn raw(&self, name: &str) -> Option<&Json> {
        self.values.get(name).filter(|j| !j.is_null()).or_else(|| self.def(name).map(|d| &d.default))
    }
    pub fn f(&self, name: &str) -> f64 {
        let v = self.raw(name).and_then(|j| j.as_f64()).unwrap_or(0.0);
        match self.def(name) {
            Some(d) => v.max(d.min.unwrap_or(f64::MIN)).min(d.max.unwrap_or(f64::MAX)),
            None => v,
        }
    }
    pub fn i(&self, name: &str) -> i64 {
        self.f(name).round() as i64
    }
    pub fn b(&self, name: &str) -> bool {
        self.raw(name).map(|j| j.as_bool().unwrap_or_else(|| j.as_f64().map_or(false, |x| x != 0.0))).unwrap_or(false)
    }
    pub fn s(&self, name: &str) -> String {
        self.raw(name).and_then(|j| j.as_str()).unwrap_or("").to_string()
    }
    pub fn v3(&self, name: &str) -> [f32; 3] {
        self.raw(name).and_then(|j| j.as_vec3()).unwrap_or([0.0; 3])
    }
    pub fn bv3(&self, name: &str) -> [bool; 3] {
        let a = self.raw(name).and_then(|j| j.as_arr()).unwrap_or(&[]);
        let g = |i: usize| a.get(i).and_then(|b| b.as_bool()).unwrap_or(false);
        [g(0), g(1), g(2)]
    }
}

/// Full value object for a schema: patch over base over defaults (unknown keys are dropped).
pub fn merge_values(defs: &[ParamDef], base: &Json, patch: &Json) -> Json {
    let mut out = Json::obj();
    for d in defs {
        let v = patch.get(&d.name).filter(|j| !j.is_null()).or_else(|| base.get(&d.name).filter(|j| !j.is_null())).cloned().unwrap_or_else(|| d.default.clone());
        out.insert(&d.name, v);
    }
    out
}

/// The `[<ParamDef>...]` array for a schema with the given values.
pub fn defs_to_json(defs: &[ParamDef], values: &Json) -> Json {
    let mut a = Json::arr();
    for d in defs {
        a.push(d.to_json(values.get(&d.name)));
    }
    a
}
