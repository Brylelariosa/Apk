//! forge-scene: the scene data model (Blender-like datablocks, copy-on-write meshes), undo history and the
//! `.rforge` project file. No rendering, no UI, no operators: pure data.
#![forbid(unsafe_code)]

mod history;
pub mod params;
mod project;
mod scene;
mod types;

pub use history::History;
pub use params::{defs_to_json, merge_values, ParamDef, ParamKind, Params, Unit};
pub use project::{load_bytes, save_bytes, scene_from_json, scene_to_json, PROJECT_MAGIC};
pub use scene::Scene;
pub use types::*;

#[cfg(test)]
mod tests;
