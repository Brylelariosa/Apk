use crate::Scene;

struct Entry {
    label: String,
    scene: Scene,
}

/// Snapshot undo stack. Scenes share their meshes through `Arc`, so a snapshot only costs the object list.
pub struct History {
    undo: Vec<Entry>,
    redo: Vec<Entry>,
    limit: usize,
}

impl History {
    pub fn new(limit: usize) -> History {
        History { undo: Vec::new(), redo: Vec::new(), limit: limit.max(1) }
    }
    /// Record the state *before* an edit. Clears the redo stack.
    pub fn push(&mut self, label: &str, before: &Scene) {
        self.undo.push(Entry { label: label.to_string(), scene: before.clone() });
        self.redo.clear();
        if self.undo.len() > self.limit {
            self.undo.remove(0);
        }
    }
    /// Drop the most recent entry (used when an operation is redone from its pre-state).
    pub fn pop_last(&mut self) -> Option<Scene> {
        self.undo.pop().map(|e| e.scene)
    }
    pub fn undo(&mut self, current: &Scene) -> Option<Scene> {
        let e = self.undo.pop()?;
        self.redo.push(Entry { label: e.label.clone(), scene: current.clone() });
        Some(e.scene)
    }
    pub fn redo(&mut self, current: &Scene) -> Option<Scene> {
        let e = self.redo.pop()?;
        self.undo.push(Entry { label: e.label.clone(), scene: current.clone() });
        Some(e.scene)
    }
    pub fn can_undo(&self) -> bool {
        !self.undo.is_empty()
    }
    pub fn can_redo(&self) -> bool {
        !self.redo.is_empty()
    }
    pub fn undo_label(&self) -> &str {
        self.undo.last().map(|e| e.label.as_str()).unwrap_or("")
    }
    pub fn redo_label(&self) -> &str {
        self.redo.last().map(|e| e.label.as_str()).unwrap_or("")
    }
    pub fn depth(&self) -> usize {
        self.undo.len()
    }
    pub fn undo_labels(&self) -> Vec<String> {
        self.undo.iter().rev().map(|e| e.label.clone()).collect()
    }
    pub fn redo_labels(&self) -> Vec<String> {
        self.redo.iter().rev().map(|e| e.label.clone()).collect()
    }
    pub fn clear(&mut self) {
        self.undo.clear();
        self.redo.clear();
    }
}
