use crate::types::*;
use forge_math::{Aabb, Mat4, Vec3};
use forge_mesh::Mesh;
use std::sync::Arc;

#[derive(Clone, Debug)]
pub struct Scene {
    pub name: String,
    pub objects: Vec<Object>,
    pub materials: Vec<Material>,
    pub next_obj: ObjId,
    pub next_mat: u32,
    pub active: Option<ObjId>,
    /// Selected objects in selection order.
    pub selected: Vec<ObjId>,
}

impl Default for Scene {
    fn default() -> Self {
        Scene::new()
    }
}

fn split_suffix(name: &str) -> &str {
    if let Some(p) = name.rfind('.') {
        let tail = &name[p + 1..];
        if tail.len() == 3 && tail.bytes().all(|b| b.is_ascii_digit()) {
            return &name[..p];
        }
    }
    name
}

impl Scene {
    pub fn new() -> Scene {
        Scene { name: "Scene".into(), objects: Vec::new(), materials: Vec::new(), next_obj: 1, next_mat: 1, active: None, selected: Vec::new() }
    }

    pub fn unique_name(&self, base: &str) -> String {
        let base = if base.is_empty() { "Object" } else { base };
        if !self.objects.iter().any(|o| o.name == base) {
            return base.to_string();
        }
        let stem = split_suffix(base);
        (1u32..)
            .map(|i| format!("{stem}.{i:03}"))
            .find(|n| !self.objects.iter().any(|o| &o.name == n))
            .unwrap_or_else(|| base.to_string())
    }

    pub fn add_object(&mut self, name: &str, data: Data) -> ObjId {
        let id = self.next_obj;
        self.next_obj += 1;
        let name = self.unique_name(name);
        self.objects.push(Object { id, name, data, transform: Transform::default(), materials: Vec::new(), modifiers: Vec::new(), visible: true, locked: false, rev: next_rev() });
        id
    }

    pub fn add_mesh(&mut self, name: &str, mesh: Mesh) -> ObjId {
        self.add_object(name, Data::Mesh(Arc::new(mesh)))
    }

    pub fn index_of(&self, id: ObjId) -> Option<usize> {
        self.objects.iter().position(|o| o.id == id)
    }
    pub fn get(&self, id: ObjId) -> Option<&Object> {
        self.objects.iter().find(|o| o.id == id)
    }
    pub fn get_mut(&mut self, id: ObjId) -> Option<&mut Object> {
        self.objects.iter_mut().find(|o| o.id == id)
    }
    pub fn active_object(&self) -> Option<&Object> {
        self.active.and_then(|id| self.get(id))
    }

    pub fn remove(&mut self, id: ObjId) -> bool {
        let before = self.objects.len();
        self.objects.retain(|o| o.id != id);
        self.selected.retain(|&s| s != id);
        if self.active == Some(id) {
            self.active = self.selected.last().copied();
        }
        self.objects.len() != before
    }

    pub fn is_selected(&self, id: ObjId) -> bool {
        self.selected.contains(&id)
    }

    /// Select exactly the given objects; `active` becomes the last one unless given.
    pub fn set_selection(&mut self, ids: &[ObjId], active: Option<ObjId>) {
        self.selected = ids.iter().copied().filter(|&i| self.get(i).is_some()).collect();
        self.selected.dedup();
        self.active = active.filter(|a| self.selected.contains(a)).or_else(|| self.selected.last().copied());
    }

    pub fn select_only(&mut self, id: Option<ObjId>) {
        match id {
            Some(i) => self.set_selection(&[i], Some(i)),
            None => {
                self.selected.clear();
            }
        }
    }

    pub fn toggle_select(&mut self, id: ObjId) {
        if let Some(p) = self.selected.iter().position(|&s| s == id) {
            self.selected.remove(p);
            if self.active == Some(id) {
                self.active = self.selected.last().copied();
            }
        } else if self.get(id).is_some() {
            self.selected.push(id);
            self.active = Some(id);
        }
    }

    pub fn select_all(&mut self) {
        let ids: Vec<ObjId> = self.objects.iter().filter(|o| o.visible && !o.locked).map(|o| o.id).collect();
        let keep = self.active;
        self.set_selection(&ids, keep);
    }

    pub fn invert_selection(&mut self) {
        let ids: Vec<ObjId> = self.objects.iter().filter(|o| o.visible && !o.locked && !self.selected.contains(&o.id)).map(|o| o.id).collect();
        self.set_selection(&ids, None);
    }

    pub fn world_matrix(&self, id: ObjId) -> Mat4 {
        self.get(id).map(|o| o.transform.matrix()).unwrap_or(Mat4::IDENTITY)
    }

    /// Replace the mesh of an object (bumps its revision).
    pub fn set_mesh(&mut self, id: ObjId, mesh: Mesh) -> bool {
        match self.get_mut(id) {
            Some(o) => {
                o.data = Data::Mesh(Arc::new(mesh));
                o.rev = next_rev();
                true
            }
            None => false,
        }
    }

    pub fn touch(&mut self, id: ObjId) {
        if let Some(o) = self.get_mut(id) {
            o.rev = next_rev();
        }
    }

    pub fn add_material(&mut self, name: &str) -> u32 {
        let id = self.next_mat;
        self.next_mat += 1;
        let unique = {
            let mut n = name.to_string();
            let mut i = 1;
            while self.materials.iter().any(|m| m.name == n) {
                n = format!("{}.{:03}", split_suffix(name), i);
                i += 1;
            }
            n
        };
        self.materials.push(Material::new(id, &unique));
        id
    }
    pub fn material(&self, id: u32) -> Option<&Material> {
        self.materials.iter().find(|m| m.id == id)
    }
    pub fn material_mut(&mut self, id: u32) -> Option<&mut Material> {
        self.materials.iter_mut().find(|m| m.id == id)
    }

    /// World-space bounds of one object (mesh bounds transformed; lights/empties are small boxes).
    pub fn world_bounds(&self, id: ObjId) -> Option<Aabb> {
        let o = self.get(id)?;
        let m = o.transform.matrix();
        match &o.data {
            Data::Mesh(mesh) if !mesh.positions.is_empty() => Some(mesh.bounds().transformed(&m)),
            _ => {
                let c = o.transform.location;
                Some(Aabb::new(c - Vec3::splat(0.25), c + Vec3::splat(0.25)))
            }
        }
    }

    pub fn bounds(&self, only_selected: bool) -> Option<Aabb> {
        let mut acc: Option<Aabb> = None;
        for o in &self.objects {
            if !o.visible || (only_selected && !self.selected.contains(&o.id)) {
                continue;
            }
            if let Some(b) = self.world_bounds(o.id) {
                acc = Some(match acc {
                    Some(a) => a.union(&b),
                    None => b,
                });
            }
        }
        acc
    }

    /// (vertices, faces, triangles) of all meshes (base meshes, no modifiers).
    pub fn totals(&self) -> (usize, usize, usize) {
        let mut t = (0, 0, 0);
        for o in &self.objects {
            if let Data::Mesh(m) = &o.data {
                t.0 += m.vert_count();
                t.1 += m.face_count();
                t.2 += m.triangle_count();
            }
        }
        t
    }
}
