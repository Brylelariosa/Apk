use crate::*;
use forge_math::Vec3;
use forge_mesh::Mesh;

fn tri() -> Mesh {
    Mesh::from_polygons(vec![Vec3::ZERO, Vec3::X, Vec3::Y], &[vec![0, 1, 2]])
}

#[test]
fn names_are_unique_like_blender() {
    let mut s = Scene::new();
    let a = s.add_mesh("Cube", tri());
    let b = s.add_mesh("Cube", tri());
    let c = s.add_mesh("Cube.001", tri());
    assert_eq!(s.get(a).unwrap().name, "Cube");
    assert_eq!(s.get(b).unwrap().name, "Cube.001");
    assert_eq!(s.get(c).unwrap().name, "Cube.002");
}

#[test]
fn selection_rules() {
    let mut s = Scene::new();
    let a = s.add_mesh("A", tri());
    let b = s.add_mesh("B", tri());
    s.select_only(Some(a));
    s.toggle_select(b);
    assert_eq!((s.selected.clone(), s.active), (vec![a, b], Some(b)));
    s.toggle_select(b);
    assert_eq!(s.active, Some(a));
    s.remove(a);
    assert!(s.selected.is_empty() && s.active.is_none());
    s.select_all();
    assert_eq!(s.selected, vec![b]);
}

#[test]
fn transform_roundtrip() {
    let t = Transform { location: Vec3::new(1.0, 2.0, 3.0), rotation: Vec3::new(0.3, -0.4, 0.5), scale: Vec3::new(1.0, 2.0, 0.5) };
    let back = Transform::from_matrix(&t.matrix(), Some(t.rotation));
    assert!(back.location.abs_diff_eq(t.location, 1e-5));
    assert!(back.rotation.abs_diff_eq(t.rotation, 1e-4), "{:?}", back.rotation);
    assert!(back.scale.abs_diff_eq(t.scale, 1e-4));
}

#[test]
fn history_shares_meshes_and_orders_steps() {
    let mut s = Scene::new();
    let a = s.add_mesh("A", tri());
    let mut h = History::new(3);
    h.push("Add A", &Scene::new());
    let before = s.clone();
    h.push("Move", &before);
    s.get_mut(a).unwrap().transform.location.x = 5.0;
    assert!(std::sync::Arc::ptr_eq(before.get(a).unwrap().mesh().unwrap(), s.get(a).unwrap().mesh().unwrap()));
    assert_eq!(h.undo_label(), "Move");
    let prev = h.undo(&s).unwrap();
    assert_eq!(prev.get(a).unwrap().transform.location.x, 0.0);
    assert_eq!(h.redo_label(), "Move");
    let again = h.redo(&prev).unwrap();
    assert_eq!(again.get(a).unwrap().transform.location.x, 5.0);
    for i in 0..5 {
        h.push(&format!("s{i}"), &s);
    }
    assert_eq!(h.depth(), 3);
    assert!(!h.can_redo());
}

#[test]
fn project_roundtrip() {
    let mut s = Scene::new();
    let m = s.add_material("Stone");
    s.material_mut(m).unwrap().roughness = 0.9;
    let a = s.add_mesh("Tri", tri());
    {
        let o = s.get_mut(a).unwrap();
        o.transform.location = Vec3::new(1.5, 0.0, -2.0);
        o.materials.push(m);
        o.modifiers.push(Modifier { name: "Mirror".into(), show_viewport: true, kind: ModKind::Mirror { axes: [true, false, true], merge: true, merge_distance: 0.01 } });
        o.modifiers.push(Modifier { name: "Subsurf".into(), show_viewport: false, kind: ModKind::Subsurf { levels: 2 } });
    }
    let l = s.add_object("Sun", Data::Light(Light::new(LightKind::Sun)));
    s.set_selection(&[a, l], Some(l));
    let back = load_bytes(&save_bytes(&s)).unwrap();
    assert_eq!(back.objects.len(), 2);
    assert_eq!(back.active, Some(l));
    assert_eq!(back.selected, vec![a, l]);
    let o = back.get(a).unwrap();
    assert_eq!(o.mesh().unwrap().corners, vec![0, 1, 2]);
    assert_eq!(o.modifiers, s.get(a).unwrap().modifiers);
    assert!((back.material(m).unwrap().roughness - 0.9).abs() < 1e-6);
    assert_eq!(back.next_obj, s.next_obj);
    assert!(load_bytes(b"garbage").is_err());
    assert!(load_bytes(b"RFORGE01\n{\"format\":\"other\"}").is_err());
}
