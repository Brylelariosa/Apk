use forge_math::{euler_from_mat3, euler_to_mat3, EulerOrder, Mat4, Vec3};
use forge_mesh::Mesh;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

pub type ObjId = u32;

static REV: AtomicU64 = AtomicU64::new(1);

/// Process-wide unique revision number. Used to detect changed geometry (GPU caches); unlike a per-scene counter it
/// can never repeat after undo/redo.
pub fn next_rev() -> u64 {
    REV.fetch_add(1, Ordering::Relaxed)
}

#[derive(Clone, Debug, PartialEq)]
pub struct Transform {
    pub location: Vec3,
    /// Euler XYZ in radians.
    pub rotation: Vec3,
    pub scale: Vec3,
}

impl Default for Transform {
    fn default() -> Self {
        Transform { location: Vec3::ZERO, rotation: Vec3::ZERO, scale: Vec3::ONE }
    }
}

impl Transform {
    pub fn matrix(&self) -> Mat4 {
        let r = euler_to_mat3(EulerOrder::XYZ, self.rotation);
        Mat4::from_trs_mat3(self.scale, &r, self.location)
    }
    pub fn from_matrix(m: &Mat4, compat: Option<Vec3>) -> Transform {
        let (s, q, t) = m.to_scale_rotation_translation();
        Transform { location: t, rotation: euler_from_mat3(EulerOrder::XYZ, &q.to_mat3(), compat), scale: s }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct Material {
    pub id: u32,
    pub name: String,
    /// Linear RGBA.
    pub base_color: [f32; 4],
    pub metallic: f32,
    pub roughness: f32,
    pub emission: [f32; 3],
    pub emission_strength: f32,
}

impl Material {
    pub fn new(id: u32, name: &str) -> Material {
        Material { id, name: name.to_string(), base_color: [0.8, 0.8, 0.8, 1.0], metallic: 0.0, roughness: 0.5, emission: [0.0; 3], emission_strength: 0.0 }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum LightKind {
    Point,
    Sun,
    Spot,
}

impl LightKind {
    pub fn name(self) -> &'static str {
        match self {
            LightKind::Point => "POINT",
            LightKind::Sun => "SUN",
            LightKind::Spot => "SPOT",
        }
    }
    pub fn from_name(s: &str) -> Option<LightKind> {
        match s.to_ascii_uppercase().as_str() {
            "POINT" => Some(LightKind::Point),
            "SUN" => Some(LightKind::Sun),
            "SPOT" => Some(LightKind::Spot),
            _ => None,
        }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct Light {
    pub kind: LightKind,
    pub color: [f32; 3],
    /// Watts for point/spot, strength for sun (Blender conventions).
    pub energy: f32,
    /// Spot cone angle (radians) and blend.
    pub spot_size: f32,
    pub spot_blend: f32,
}

impl Light {
    pub fn new(kind: LightKind) -> Light {
        Light { kind, color: [1.0; 3], energy: if kind == LightKind::Sun { 3.0 } else { 1000.0 }, spot_size: 45f32.to_radians(), spot_blend: 0.15 }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub enum ModKind {
    Mirror { axes: [bool; 3], merge: bool, merge_distance: f32 },
    Subsurf { levels: u32 },
}

impl ModKind {
    pub fn type_name(&self) -> &'static str {
        match self {
            ModKind::Mirror { .. } => "MIRROR",
            ModKind::Subsurf { .. } => "SUBSURF",
        }
    }
}

#[derive(Clone, Debug, PartialEq)]
pub struct Modifier {
    pub name: String,
    pub show_viewport: bool,
    pub kind: ModKind,
}

#[derive(Clone, Debug)]
pub enum Data {
    Mesh(Arc<Mesh>),
    Light(Light),
    Empty,
}

impl Data {
    pub fn kind_name(&self) -> &'static str {
        match self {
            Data::Mesh(_) => "mesh",
            Data::Light(_) => "light",
            Data::Empty => "empty",
        }
    }
}

#[derive(Clone, Debug)]
pub struct Object {
    pub id: ObjId,
    pub name: String,
    pub data: Data,
    pub transform: Transform,
    /// Material ids per slot.
    pub materials: Vec<u32>,
    pub modifiers: Vec<Modifier>,
    pub visible: bool,
    pub locked: bool,
    /// Changes whenever geometry or modifiers change (see [`next_rev`]).
    pub rev: u64,
}

impl Object {
    pub fn mesh(&self) -> Option<&Arc<Mesh>> {
        match &self.data {
            Data::Mesh(m) => Some(m),
            _ => None,
        }
    }
}
