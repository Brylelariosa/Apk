//! forge-json: tiny dependency-free JSON value, parser and writer (replaces serde_json).
//!
//! Objects keep insertion order. Numbers are `f64`; integral values are written without a fraction.
//! Parsing is depth-limited so hostile input cannot overflow the stack.
#![forbid(unsafe_code)]

use std::fmt;

#[derive(Clone, Debug, PartialEq)]
pub enum Json {
    Null,
    Bool(bool),
    Num(f64),
    Str(String),
    Arr(Vec<Json>),
    Obj(Vec<(String, Json)>),
}

#[derive(Clone, Debug, PartialEq)]
pub struct JsonError {
    pub message: String,
    pub offset: usize,
}
impl fmt::Display for JsonError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "JSON error at byte {}: {}", self.offset, self.message)
    }
}
impl std::error::Error for JsonError {}

const MAX_DEPTH: usize = 128;

impl Json {
    pub fn obj() -> Json {
        Json::Obj(Vec::new())
    }
    pub fn arr() -> Json {
        Json::Arr(Vec::new())
    }
    /// f32 stored via its shortest decimal form so `0.1f32` prints as `0.1`.
    pub fn num32(v: f32) -> Json {
        if v.is_finite() {
            Json::Num(v.to_string().parse::<f64>().unwrap_or(v as f64))
        } else {
            Json::Null
        }
    }
    pub fn vec3(v: [f32; 3]) -> Json {
        Json::Arr(v.iter().map(|x| Json::num32(*x)).collect())
    }
    pub fn f32s(v: &[f32]) -> Json {
        Json::Arr(v.iter().map(|x| Json::num32(*x)).collect())
    }

    /// Builder: set (or replace) a key on an object. No-op on non-objects.
    pub fn set(mut self, key: &str, value: impl Into<Json>) -> Json {
        self.insert(key, value);
        self
    }
    pub fn insert(&mut self, key: &str, value: impl Into<Json>) {
        if let Json::Obj(items) = self {
            let value = value.into();
            if let Some(slot) = items.iter_mut().find(|(k, _)| k == key) {
                slot.1 = value;
            } else {
                items.push((key.to_string(), value));
            }
        }
    }
    pub fn push(&mut self, value: impl Into<Json>) {
        if let Json::Arr(items) = self {
            items.push(value.into());
        }
    }

    pub fn get(&self, key: &str) -> Option<&Json> {
        match self {
            Json::Obj(items) => items.iter().find(|(k, _)| k == key).map(|(_, v)| v),
            _ => None,
        }
    }
    pub fn at(&self, i: usize) -> Option<&Json> {
        match self {
            Json::Arr(items) => items.get(i),
            _ => None,
        }
    }
    pub fn as_str(&self) -> Option<&str> {
        match self {
            Json::Str(s) => Some(s),
            _ => None,
        }
    }
    pub fn as_f64(&self) -> Option<f64> {
        match self {
            Json::Num(n) => Some(*n),
            _ => None,
        }
    }
    pub fn as_f32(&self) -> Option<f32> {
        self.as_f64().map(|v| v as f32)
    }
    pub fn as_i64(&self) -> Option<i64> {
        match self {
            Json::Num(n) if n.is_finite() => Some(*n as i64),
            _ => None,
        }
    }
    pub fn as_u32(&self) -> Option<u32> {
        match self {
            Json::Num(n) if n.is_finite() && *n >= 0.0 && *n <= u32::MAX as f64 => Some(*n as u32),
            _ => None,
        }
    }
    pub fn as_bool(&self) -> Option<bool> {
        match self {
            Json::Bool(b) => Some(*b),
            _ => None,
        }
    }
    pub fn as_arr(&self) -> Option<&[Json]> {
        match self {
            Json::Arr(a) => Some(a),
            _ => None,
        }
    }
    pub fn as_obj(&self) -> Option<&[(String, Json)]> {
        match self {
            Json::Obj(o) => Some(o),
            _ => None,
        }
    }
    pub fn is_null(&self) -> bool {
        matches!(self, Json::Null)
    }
    /// Array of exactly three numbers.
    pub fn as_vec3(&self) -> Option<[f32; 3]> {
        let a = self.as_arr()?;
        if a.len() != 3 {
            return None;
        }
        Some([a[0].as_f32()?, a[1].as_f32()?, a[2].as_f32()?])
    }
    /// Array of exactly `N` numbers.
    pub fn as_f32_array<const N: usize>(&self) -> Option<[f32; N]> {
        let a = self.as_arr()?;
        if a.len() != N {
            return None;
        }
        let mut out = [0f32; N];
        for (i, v) in a.iter().enumerate() {
            out[i] = v.as_f32()?;
        }
        Some(out)
    }
    // typed lookups with defaults (convenient for command argument parsing)
    pub fn get_str(&self, key: &str) -> Option<&str> {
        self.get(key).and_then(Json::as_str)
    }
    pub fn get_f32(&self, key: &str) -> Option<f32> {
        self.get(key).and_then(Json::as_f32)
    }
    pub fn get_i64(&self, key: &str) -> Option<i64> {
        self.get(key).and_then(Json::as_i64)
    }
    pub fn get_u32(&self, key: &str) -> Option<u32> {
        self.get(key).and_then(Json::as_u32)
    }
    pub fn get_bool(&self, key: &str) -> Option<bool> {
        self.get(key).and_then(Json::as_bool)
    }

    pub fn parse(src: &str) -> Result<Json, JsonError> {
        let mut p = Parser { s: src.as_bytes(), i: 0 };
        p.ws();
        let v = p.value(0)?;
        p.ws();
        if p.i != p.s.len() {
            return Err(p.err("trailing characters"));
        }
        Ok(v)
    }
    pub fn to_pretty(&self) -> String {
        let mut out = String::new();
        write_json(self, &mut out, Some(0));
        out
    }
}

impl fmt::Display for Json {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let mut s = String::new();
        write_json(self, &mut s, None);
        f.write_str(&s)
    }
}

macro_rules! from_num {
    ($($t:ty),*) => { $(impl From<$t> for Json { fn from(v: $t) -> Json { Json::Num(v as f64) } })* };
}
from_num!(i32, i64, u32, u64, usize, f64);
impl From<f32> for Json {
    fn from(v: f32) -> Json {
        Json::num32(v)
    }
}
impl From<bool> for Json {
    fn from(v: bool) -> Json {
        Json::Bool(v)
    }
}
impl From<&str> for Json {
    fn from(v: &str) -> Json {
        Json::Str(v.to_string())
    }
}
impl From<String> for Json {
    fn from(v: String) -> Json {
        Json::Str(v)
    }
}
impl<T: Into<Json>> From<Vec<T>> for Json {
    fn from(v: Vec<T>) -> Json {
        Json::Arr(v.into_iter().map(Into::into).collect())
    }
}
impl<T: Into<Json>> From<Option<T>> for Json {
    fn from(v: Option<T>) -> Json {
        match v {
            Some(x) => x.into(),
            None => Json::Null,
        }
    }
}
impl From<[f32; 3]> for Json {
    fn from(v: [f32; 3]) -> Json {
        Json::vec3(v)
    }
}
impl From<[f32; 4]> for Json {
    fn from(v: [f32; 4]) -> Json {
        Json::f32s(&v)
    }
}

fn write_str(s: &str, out: &mut String) {
    out.push('"');
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if (c as u32) < 0x20 => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
}

fn write_num(n: f64, out: &mut String) {
    if !n.is_finite() {
        out.push_str("null");
    } else if n == n.trunc() && n.abs() < 1e15 {
        out.push_str(&format!("{}", n as i64));
    } else {
        out.push_str(&format!("{}", n));
    }
}

fn indent(out: &mut String, level: usize) {
    out.push('\n');
    for _ in 0..level {
        out.push_str("  ");
    }
}

fn write_json(v: &Json, out: &mut String, pretty: Option<usize>) {
    match v {
        Json::Null => out.push_str("null"),
        Json::Bool(b) => out.push_str(if *b { "true" } else { "false" }),
        Json::Num(n) => write_num(*n, out),
        Json::Str(s) => write_str(s, out),
        Json::Arr(a) => {
            if a.is_empty() {
                out.push_str("[]");
                return;
            }
            out.push('[');
            for (i, x) in a.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                if let Some(l) = pretty {
                    indent(out, l + 1);
                }
                write_json(x, out, pretty.map(|l| l + 1));
            }
            if let Some(l) = pretty {
                indent(out, l);
            }
            out.push(']');
        }
        Json::Obj(o) => {
            if o.is_empty() {
                out.push_str("{}");
                return;
            }
            out.push('{');
            for (i, (k, x)) in o.iter().enumerate() {
                if i > 0 {
                    out.push(',');
                }
                if let Some(l) = pretty {
                    indent(out, l + 1);
                }
                write_str(k, out);
                out.push(':');
                if pretty.is_some() {
                    out.push(' ');
                }
                write_json(x, out, pretty.map(|l| l + 1));
            }
            if let Some(l) = pretty {
                indent(out, l);
            }
            out.push('}');
        }
    }
}

struct Parser<'a> {
    s: &'a [u8],
    i: usize,
}

impl<'a> Parser<'a> {
    fn err(&self, m: &str) -> JsonError {
        JsonError { message: m.to_string(), offset: self.i }
    }
    fn ws(&mut self) {
        while self.i < self.s.len() && matches!(self.s[self.i], b' ' | b'\t' | b'\n' | b'\r') {
            self.i += 1;
        }
    }
    fn eat(&mut self, c: u8) -> Result<(), JsonError> {
        if self.s.get(self.i) == Some(&c) {
            self.i += 1;
            Ok(())
        } else {
            Err(self.err(&format!("expected '{}'", c as char)))
        }
    }
    fn lit(&mut self, word: &str, v: Json) -> Result<Json, JsonError> {
        if self.s[self.i..].starts_with(word.as_bytes()) {
            self.i += word.len();
            Ok(v)
        } else {
            Err(self.err("invalid literal"))
        }
    }
    fn value(&mut self, depth: usize) -> Result<Json, JsonError> {
        if depth > MAX_DEPTH {
            return Err(self.err("nesting too deep"));
        }
        match self.s.get(self.i) {
            None => Err(self.err("unexpected end of input")),
            Some(b'n') => self.lit("null", Json::Null),
            Some(b't') => self.lit("true", Json::Bool(true)),
            Some(b'f') => self.lit("false", Json::Bool(false)),
            Some(b'"') => Ok(Json::Str(self.string()?)),
            Some(b'[') => {
                self.i += 1;
                let mut items = Vec::new();
                self.ws();
                if self.s.get(self.i) == Some(&b']') {
                    self.i += 1;
                    return Ok(Json::Arr(items));
                }
                loop {
                    self.ws();
                    items.push(self.value(depth + 1)?);
                    self.ws();
                    match self.s.get(self.i) {
                        Some(b',') => self.i += 1,
                        Some(b']') => {
                            self.i += 1;
                            return Ok(Json::Arr(items));
                        }
                        _ => return Err(self.err("expected ',' or ']'")),
                    }
                }
            }
            Some(b'{') => {
                self.i += 1;
                let mut items: Vec<(String, Json)> = Vec::new();
                self.ws();
                if self.s.get(self.i) == Some(&b'}') {
                    self.i += 1;
                    return Ok(Json::Obj(items));
                }
                loop {
                    self.ws();
                    let k = self.string()?;
                    self.ws();
                    self.eat(b':')?;
                    self.ws();
                    let v = self.value(depth + 1)?;
                    if let Some(slot) = items.iter_mut().find(|(kk, _)| *kk == k) {
                        slot.1 = v;
                    } else {
                        items.push((k, v));
                    }
                    self.ws();
                    match self.s.get(self.i) {
                        Some(b',') => self.i += 1,
                        Some(b'}') => {
                            self.i += 1;
                            return Ok(Json::Obj(items));
                        }
                        _ => return Err(self.err("expected ',' or '}'")),
                    }
                }
            }
            Some(c) if *c == b'-' || c.is_ascii_digit() => self.number(),
            Some(_) => Err(self.err("unexpected character")),
        }
    }
    fn number(&mut self) -> Result<Json, JsonError> {
        let start = self.i;
        if self.s[self.i] == b'-' {
            self.i += 1;
        }
        while self.i < self.s.len() && matches!(self.s[self.i], b'0'..=b'9' | b'.' | b'e' | b'E' | b'+' | b'-') {
            self.i += 1;
        }
        let txt = std::str::from_utf8(&self.s[start..self.i]).map_err(|_| self.err("bad number"))?;
        txt.parse::<f64>().map(Json::Num).map_err(|_| JsonError { message: "invalid number".into(), offset: start })
    }
    fn hex4(&mut self) -> Result<u32, JsonError> {
        if self.i + 4 > self.s.len() {
            return Err(self.err("truncated \\u escape"));
        }
        let t = std::str::from_utf8(&self.s[self.i..self.i + 4]).map_err(|_| self.err("bad \\u escape"))?;
        let v = u32::from_str_radix(t, 16).map_err(|_| self.err("bad \\u escape"))?;
        self.i += 4;
        Ok(v)
    }
    fn string(&mut self) -> Result<String, JsonError> {
        self.eat(b'"')?;
        let mut out = String::new();
        loop {
            // copy a run of plain bytes at once (keeps UTF-8 intact)
            let run_start = self.i;
            while self.i < self.s.len() && self.s[self.i] != b'"' && self.s[self.i] != b'\\' && self.s[self.i] >= 0x20 {
                self.i += 1;
            }
            if self.i > run_start {
                out.push_str(std::str::from_utf8(&self.s[run_start..self.i]).map_err(|_| self.err("invalid UTF-8"))?);
            }
            match self.s.get(self.i) {
                None => return Err(self.err("unterminated string")),
                Some(b'"') => {
                    self.i += 1;
                    return Ok(out);
                }
                Some(b'\\') => {
                    self.i += 1;
                    let c = *self.s.get(self.i).ok_or_else(|| self.err("truncated escape"))?;
                    self.i += 1;
                    match c {
                        b'"' => out.push('"'),
                        b'\\' => out.push('\\'),
                        b'/' => out.push('/'),
                        b'b' => out.push('\u{8}'),
                        b'f' => out.push('\u{c}'),
                        b'n' => out.push('\n'),
                        b'r' => out.push('\r'),
                        b't' => out.push('\t'),
                        b'u' => {
                            let hi = self.hex4()?;
                            let cp = if (0xD800..0xDC00).contains(&hi) {
                                if self.s.get(self.i) == Some(&b'\\') && self.s.get(self.i + 1) == Some(&b'u') {
                                    self.i += 2;
                                    let lo = self.hex4()?;
                                    if !(0xDC00..0xE000).contains(&lo) {
                                        return Err(self.err("invalid surrogate pair"));
                                    }
                                    0x10000 + ((hi - 0xD800) << 10) + (lo - 0xDC00)
                                } else {
                                    return Err(self.err("lone surrogate"));
                                }
                            } else {
                                hi
                            };
                            out.push(char::from_u32(cp).ok_or_else(|| self.err("invalid code point"))?);
                        }
                        _ => return Err(self.err("invalid escape")),
                    }
                }
                Some(_) => return Err(self.err("control character in string")),
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn roundtrip_and_access() {
        let src = r#"{"a":1,"b":[true,null,"x\n\u00e9\ud83d\ude00"],"c":{"d":-2.5e1}}"#;
        let j = Json::parse(src).unwrap();
        assert_eq!(j.get("a").and_then(Json::as_i64), Some(1));
        assert_eq!(j.get("b").and_then(|b| b.at(2)).and_then(Json::as_str), Some("x\né😀"));
        assert_eq!(j.get("c").and_then(|c| c.get("d")).and_then(Json::as_f64), Some(-25.0));
        let again = Json::parse(&j.to_string()).unwrap();
        assert_eq!(j, again);
        assert_eq!(Json::parse(&j.to_pretty()).unwrap(), j);
    }

    #[test]
    fn writer_formats_numbers() {
        assert_eq!(Json::from(3).to_string(), "3");
        assert_eq!(Json::num32(0.1).to_string(), "0.1");
        assert_eq!(Json::Num(f64::NAN).to_string(), "null");
        assert_eq!(Json::vec3([1.0, 2.5, -3.0]).to_string(), "[1,2.5,-3]");
        let o = Json::obj().set("k", "v\"").set("n", 1).set("n", 2);
        assert_eq!(o.to_string(), r#"{"k":"v\"","n":2}"#);
    }

    #[test]
    fn rejects_garbage() {
        for bad in ["", "{", "[1,]", "{\"a\"}", "tru", "\"abc", "[1 2]", "{\"a\":1,}", "01x", "\"\\ud800\""] {
            assert!(Json::parse(bad).is_err(), "should reject {bad:?}");
        }
        let deep = "[".repeat(1000);
        assert!(Json::parse(&deep).is_err());
    }
}
