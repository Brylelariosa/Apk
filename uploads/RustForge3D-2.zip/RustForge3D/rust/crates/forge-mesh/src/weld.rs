//! Vertex/face clean-up primitives shared by operations, importers and the boolean.
use crate::mesh::Mesh;
use crate::topology::NONE;
use forge_math::Vec3;
use std::collections::HashMap;

/// Result of a clean-up: `vert_map[old] = new` (or `u32::MAX`), `face_map[old] = new` (or `u32::MAX`).
#[derive(Clone, Debug, Default, PartialEq)]
pub struct CleanupMap {
    pub vert_map: Vec<u32>,
    pub face_map: Vec<u32>,
}

/// Keep only faces with `keep[f] == true` (vertices are untouched). Returns old->new face map.
pub fn retain_faces(mesh: &mut Mesh, keep: &[bool]) -> Vec<u32> {
    let nf = mesh.face_count();
    let has_uv = !mesh.uvs.is_empty();
    let mut map = vec![NONE; nf];
    let mut corners = Vec::with_capacity(mesh.corners.len());
    let mut starts = vec![0u32];
    let mut mats = Vec::new();
    let mut smooth = Vec::new();
    let mut uvs = Vec::new();
    for f in 0..nf {
        if !keep.get(f).copied().unwrap_or(false) {
            continue;
        }
        map[f] = mats.len() as u32;
        let r = mesh.face_range(f);
        corners.extend_from_slice(&mesh.corners[r.clone()]);
        if has_uv {
            uvs.extend_from_slice(&mesh.uvs[r]);
        }
        starts.push(corners.len() as u32);
        mats.push(mesh.face_material[f]);
        smooth.push(mesh.face_smooth[f]);
    }
    mesh.corners = corners;
    mesh.face_starts = starts;
    mesh.face_material = mats;
    mesh.face_smooth = smooth;
    mesh.uvs = uvs;
    map
}

/// Remove vertices that no face and no loose edge uses. Returns old->new vertex map.
pub fn compact_unused(mesh: &mut Mesh) -> Vec<u32> {
    let n = mesh.vert_count();
    let mut used = vec![false; n];
    for &c in &mesh.corners {
        if let Some(u) = used.get_mut(c as usize) {
            *u = true;
        }
    }
    for e in &mesh.loose_edges {
        for &v in e {
            if let Some(u) = used.get_mut(v as usize) {
                *u = true;
            }
        }
    }
    let mut map = vec![NONE; n];
    let mut next = 0u32;
    for v in 0..n {
        if used[v] {
            map[v] = next;
            next += 1;
        }
    }
    if next as usize == n {
        return (0..n as u32).collect();
    }
    let mut positions = Vec::with_capacity(next as usize);
    for v in 0..n {
        if used[v] {
            positions.push(mesh.positions[v]);
        }
    }
    mesh.positions = positions;
    for c in &mut mesh.corners {
        *c = map[*c as usize];
    }
    for e in &mut mesh.loose_edges {
        e[0] = map[e[0] as usize];
        e[1] = map[e[1] as usize];
    }
    map
}

fn cell_hash(c: (i64, i64, i64)) -> u64 {
    (c.0 as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15) ^ (c.1 as u64).wrapping_mul(0xC2B2_AE3D_27D4_EB4F) ^ (c.2 as u64).wrapping_mul(0x1656_67B1_9E37_79F9)
}

/// Merge vertices closer than `eps` ("merge by distance"). The lowest-index vertex of a cluster survives (its
/// position is kept). Faces lose repeated consecutive vertices and are dropped when fewer than 3 remain; loose
/// edges that collapse or duplicate are dropped. Every old vertex maps to a surviving one.
pub fn weld_vertices(mesh: &mut Mesh, eps: f32) -> CleanupMap {
    let n = mesh.vert_count();
    let eps = if eps.is_finite() { eps.max(0.0) } else { 0.0 };
    let eps2 = eps * eps;
    let cell = eps.max(1e-6);
    let inv = 1.0 / cell;
    let cell_of = |p: Vec3| ((p.x * inv).floor() as i64, (p.y * inv).floor() as i64, (p.z * inv).floor() as i64);

    let mut heads: HashMap<u64, u32> = HashMap::with_capacity(n);
    let mut next = vec![NONE; n];
    let mut rep = vec![0u32; n];
    for v in 0..n {
        let p = mesh.positions[v];
        let c = cell_of(p);
        let mut target = NONE;
        'search: for dx in -1..=1i64 {
            for dy in -1..=1i64 {
                for dz in -1..=1i64 {
                    let mut cur = heads.get(&cell_hash((c.0 + dx, c.1 + dy, c.2 + dz))).copied().unwrap_or(NONE);
                    while cur != NONE {
                        if mesh.positions[cur as usize].distance_squared(p) <= eps2 {
                            target = cur;
                            break 'search;
                        }
                        cur = next[cur as usize];
                    }
                }
            }
        }
        if target == NONE {
            rep[v] = v as u32;
            next[v] = heads.insert(cell_hash(c), v as u32).unwrap_or(NONE);
        } else {
            rep[v] = target;
        }
    }
    let mut vert_map = vec![0u32; n];
    let mut kept = 0u32;
    let mut positions = Vec::new();
    for v in 0..n {
        if rep[v] == v as u32 {
            vert_map[v] = kept;
            kept += 1;
            positions.push(mesh.positions[v]);
        } else {
            vert_map[v] = vert_map[rep[v] as usize];
        }
    }

    let nf = mesh.face_count();
    let has_uv = !mesh.uvs.is_empty();
    let mut face_map = vec![NONE; nf];
    let mut corners = Vec::with_capacity(mesh.corners.len());
    let mut starts = vec![0u32];
    let mut mats = Vec::new();
    let mut smooth = Vec::new();
    let mut uvs = Vec::new();
    let mut tmp: Vec<(u32, usize)> = Vec::new();
    for f in 0..nf {
        tmp.clear();
        let r = mesh.face_range(f);
        for c in r.clone() {
            let v = vert_map[mesh.corners[c] as usize];
            if tmp.last().map_or(true, |l| l.0 != v) {
                tmp.push((v, c));
            }
        }
        while tmp.len() > 1 && tmp[0].0 == tmp[tmp.len() - 1].0 {
            tmp.pop();
        }
        if tmp.len() < 3 {
            continue;
        }
        face_map[f] = mats.len() as u32;
        for &(v, c) in &tmp {
            corners.push(v);
            if has_uv {
                uvs.push(mesh.uvs[c]);
            }
        }
        starts.push(corners.len() as u32);
        mats.push(mesh.face_material[f]);
        smooth.push(mesh.face_smooth[f]);
    }
    let mut loose: Vec<[u32; 2]> = mesh
        .loose_edges
        .iter()
        .map(|e| [vert_map[e[0] as usize], vert_map[e[1] as usize]])
        .filter(|e| e[0] != e[1])
        .map(|e| if e[0] < e[1] { e } else { [e[1], e[0]] })
        .collect();
    loose.sort_unstable();
    loose.dedup();

    mesh.positions = positions;
    mesh.corners = corners;
    mesh.face_starts = starts;
    mesh.face_material = mats;
    mesh.face_smooth = smooth;
    mesh.uvs = uvs;
    mesh.loose_edges = loose;
    CleanupMap { vert_map, face_map }
}

/// Drop faces that repeat a vertex or whose area is below `min_area`. Returns old->new face map.
pub fn remove_degenerate_faces(mesh: &mut Mesh, min_area: f32) -> Vec<u32> {
    let keep: Vec<bool> = (0..mesh.face_count())
        .map(|f| {
            let vs = mesh.face_verts(f);
            let dup = (0..vs.len()).any(|i| (i + 1..vs.len()).any(|j| vs[i] == vs[j]));
            !dup && mesh.face_area(f) > min_area
        })
        .collect();
    retain_faces(mesh, &keep)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mesh::tests_support::unit_cube;
    use crate::validate::validate;

    #[test]
    fn weld_merges_duplicate_vertices() {
        // two quads sharing an edge, each with its own copy of the shared vertices
        let p = |x: f32, y: f32| Vec3::new(x, y, 0.0);
        let mut m = Mesh::from_polygons(
            vec![p(0., 0.), p(1., 0.), p(1., 1.), p(0., 1.), p(1., 0.), p(2., 0.), p(2., 1.), p(1., 1.)],
            &[vec![0, 1, 2, 3], vec![4, 5, 6, 7]],
        );
        let r = weld_vertices(&mut m, 1e-4);
        assert_eq!(m.vert_count(), 6);
        assert_eq!(m.face_count(), 2);
        assert_eq!(r.vert_map[4], r.vert_map[1]);
        assert_eq!(validate(&m).boundary_edges, 6);
    }

    #[test]
    fn weld_drops_collapsed_faces_and_keeps_cube_intact() {
        let mut c = unit_cube();
        weld_vertices(&mut c, 1e-4);
        assert_eq!((c.vert_count(), c.face_count()), (8, 6));
        let mut small = unit_cube();
        small.positions.iter_mut().for_each(|p| *p = *p * 0.001);
        let r = weld_vertices(&mut small, 0.1);
        assert_eq!((small.vert_count(), small.face_count()), (1, 0));
        assert!(r.face_map.iter().all(|&f| f == NONE));
    }

    #[test]
    fn compact_and_retain() {
        let mut m = unit_cube();
        let map = retain_faces(&mut m, &[true, true, false, false, false, false]);
        assert_eq!(map, vec![0, 1, NONE, NONE, NONE, NONE]);
        let vmap = compact_unused(&mut m);
        assert_eq!(m.vert_count(), 8);
        assert_eq!(vmap.len(), 8);
        let mut m = unit_cube();
        retain_faces(&mut m, &[true, false, false, false, false, false]);
        compact_unused(&mut m);
        assert_eq!((m.vert_count(), m.face_count()), (4, 1));
        assert!(m.check_structure().is_ok());
        let mut d = unit_cube();
        d.corners[0] = d.corners[1];
        let fm = remove_degenerate_faces(&mut d, 1e-9);
        assert_eq!(fm[0], NONE);
        assert_eq!(d.face_count(), 5);
    }
}
