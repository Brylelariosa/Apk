//! The core polygon mesh. Indexed, n-gon capable, CSR face storage, per-corner UVs.
use crate::ctx::{GeomError, GeomResult};
use crate::tri;
use forge_math::{Aabb, Mat4, Vec2, Vec3};
use std::ops::Range;

/// Indexed polygon mesh.
///
/// * Face `f` owns corners `face_starts[f]..face_starts[f+1]`; `corners[c]` is the vertex index of corner `c`.
/// * Faces are wound **counter-clockwise when seen from outside** (right-hand rule gives the outward normal).
/// * `face_material` / `face_smooth` have one entry per face; `uvs` is empty or has one entry per corner.
/// * `loose_edges` are edges that belong to no face (wire geometry from `from_pydata`).
///
/// All fields are public for speed; use [`Mesh::check_structure`] on untrusted data.
#[derive(Clone, Debug, PartialEq)]
pub struct Mesh {
    pub positions: Vec<Vec3>,
    pub face_starts: Vec<u32>,
    pub corners: Vec<u32>,
    pub face_material: Vec<u16>,
    pub face_smooth: Vec<bool>,
    pub loose_edges: Vec<[u32; 2]>,
    pub uvs: Vec<Vec2>,
}

impl Default for Mesh {
    fn default() -> Self {
        Mesh::new()
    }
}

impl Mesh {
    pub fn new() -> Mesh {
        Mesh {
            positions: Vec::new(),
            face_starts: vec![0],
            corners: Vec::new(),
            face_material: Vec::new(),
            face_smooth: Vec::new(),
            loose_edges: Vec::new(),
            uvs: Vec::new(),
        }
    }

    /// Build from trusted data (internal generators). Faces with fewer than 3 vertices are skipped.
    pub fn from_polygons(positions: Vec<Vec3>, faces: &[Vec<u32>]) -> Mesh {
        let mut m = Mesh::new();
        m.positions = positions;
        for f in faces {
            if f.len() >= 3 {
                m.add_face(f);
            }
        }
        m
    }

    pub fn from_triangles(positions: Vec<Vec3>, tris: &[[u32; 3]]) -> Mesh {
        let mut m = Mesh::new();
        m.positions = positions;
        m.corners.reserve(tris.len() * 3);
        for t in tris {
            m.add_face(t);
        }
        m
    }

    /// Validating constructor for untrusted input (scripts, importers): checks index ranges, face sizes and
    /// finiteness. `edges` that are already covered by a face are dropped, the rest become loose edges.
    pub fn try_from_pydata(positions: Vec<Vec3>, edges: &[[u32; 2]], faces: &[Vec<u32>]) -> GeomResult<Mesh> {
        let n = positions.len();
        if n > u32::MAX as usize / 2 {
            return Err(GeomError::InvalidInput("too many vertices".into()));
        }
        if let Some(i) = positions.iter().position(|p| !p.is_finite()) {
            return Err(GeomError::InvalidInput(format!("vertex {i} has a non-finite coordinate")));
        }
        let mut m = Mesh::new();
        m.positions = positions;
        for (fi, f) in faces.iter().enumerate() {
            if f.len() < 3 {
                return Err(GeomError::InvalidInput(format!("face {fi} has fewer than 3 vertices")));
            }
            if let Some(v) = f.iter().find(|v| **v as usize >= n) {
                return Err(GeomError::InvalidInput(format!("face {fi} references vertex {v} but the mesh has {n} vertices")));
            }
            m.add_face(f);
        }
        for (ei, e) in edges.iter().enumerate() {
            if e[0] as usize >= n || e[1] as usize >= n {
                return Err(GeomError::InvalidInput(format!("edge {ei} references a vertex out of range")));
            }
            if e[0] != e[1] {
                m.loose_edges.push(*e);
            }
        }
        if !m.loose_edges.is_empty() {
            let topo = crate::topology::Topology::build(&m);
            let keep: Vec<[u32; 2]> = topo.edges[topo.loose_start..].to_vec();
            m.loose_edges = keep;
        }
        Ok(m)
    }

    // ------------------------------------------------------------------ counts & access
    #[inline]
    pub fn vert_count(&self) -> usize {
        self.positions.len()
    }
    #[inline]
    pub fn face_count(&self) -> usize {
        self.face_starts.len().saturating_sub(1)
    }
    #[inline]
    pub fn corner_count(&self) -> usize {
        self.corners.len()
    }
    pub fn is_empty(&self) -> bool {
        self.positions.is_empty()
    }
    #[inline]
    pub fn face_range(&self, f: usize) -> Range<usize> {
        self.face_starts[f] as usize..self.face_starts[f + 1] as usize
    }
    #[inline]
    pub fn face_len(&self, f: usize) -> usize {
        (self.face_starts[f + 1] - self.face_starts[f]) as usize
    }
    /// Vertex indices of face `f` in winding order.
    #[inline]
    pub fn face_verts(&self, f: usize) -> &[u32] {
        &self.corners[self.face_range(f)]
    }
    pub fn face_positions(&self, f: usize) -> impl Iterator<Item = Vec3> + '_ {
        self.face_verts(f).iter().map(move |&v| self.positions[v as usize])
    }
    /// Number of triangles after triangulation (sum of `n - 2` over faces).
    pub fn triangle_count(&self) -> usize {
        (0..self.face_count()).map(|f| self.face_len(f).saturating_sub(2)).sum()
    }
    /// Number of unique edges (faces + loose). Builds a topology; use `Topology` directly if you need more.
    pub fn edge_count(&self) -> usize {
        crate::topology::Topology::build(self).edges.len()
    }
    pub fn bounds(&self) -> Aabb {
        Aabb::from_points(self.positions.iter().copied())
    }

    // ------------------------------------------------------------------ building
    pub fn add_vertex(&mut self, p: Vec3) -> u32 {
        self.positions.push(p);
        (self.positions.len() - 1) as u32
    }
    pub fn add_face(&mut self, verts: &[u32]) -> u32 {
        self.add_face_ex(verts, 0, false)
    }
    pub fn add_face_ex(&mut self, verts: &[u32], material: u16, smooth: bool) -> u32 {
        self.corners.extend_from_slice(verts);
        self.face_starts.push(self.corners.len() as u32);
        self.face_material.push(material);
        self.face_smooth.push(smooth);
        if !self.uvs.is_empty() {
            self.uvs.extend(std::iter::repeat(Vec2::ZERO).take(verts.len()));
        }
        (self.face_count() - 1) as u32
    }
    pub fn add_loose_edge(&mut self, a: u32, b: u32) {
        if a != b {
            self.loose_edges.push([a, b]);
        }
    }
    /// Make `uvs` valid (one per corner, zero filled) if it is not.
    pub fn ensure_uvs(&mut self) {
        if self.uvs.len() != self.corners.len() {
            self.uvs = vec![Vec2::ZERO; self.corners.len()];
        }
    }
    /// Append `other`; returns the index offset applied to its vertices.
    pub fn push_mesh(&mut self, other: &Mesh) -> u32 {
        let off = self.positions.len() as u32;
        let had_uv = !self.uvs.is_empty();
        let other_uv = !other.uvs.is_empty();
        if other_uv && !had_uv && !self.corners.is_empty() {
            self.uvs = vec![Vec2::ZERO; self.corners.len()];
        }
        self.positions.extend_from_slice(&other.positions);
        self.corners.extend(other.corners.iter().map(|c| c + off));
        let base = *self.face_starts.last().unwrap_or(&0);
        self.face_starts.extend(other.face_starts.iter().skip(1).map(|s| s + base));
        self.face_material.extend_from_slice(&other.face_material);
        self.face_smooth.extend_from_slice(&other.face_smooth);
        self.loose_edges.extend(other.loose_edges.iter().map(|e| [e[0] + off, e[1] + off]));
        if other_uv {
            self.uvs.extend_from_slice(&other.uvs);
        } else if !self.uvs.is_empty() {
            self.uvs.extend(std::iter::repeat(Vec2::ZERO).take(other.corners.len()));
        }
        off
    }
    pub fn clear(&mut self) {
        *self = Mesh::new();
    }

    // ------------------------------------------------------------------ face geometry
    /// Unnormalised Newell normal of face `f` (its length is twice the polygon area).
    pub fn face_area_vector(&self, f: usize) -> Vec3 {
        let vs = self.face_verts(f);
        let n = vs.len();
        let mut s = Vec3::ZERO;
        for i in 0..n {
            let a = self.positions[vs[i] as usize];
            let b = self.positions[vs[(i + 1) % n] as usize];
            s.x += (a.y - b.y) * (a.z + b.z);
            s.y += (a.z - b.z) * (a.x + b.x);
            s.z += (a.x - b.x) * (a.y + b.y);
        }
        s
    }
    pub fn face_normal(&self, f: usize) -> Vec3 {
        self.face_area_vector(f).normalize()
    }
    pub fn face_area(&self, f: usize) -> f32 {
        self.face_area_vector(f).length() * 0.5
    }
    pub fn face_center(&self, f: usize) -> Vec3 {
        let vs = self.face_verts(f);
        let mut c = Vec3::ZERO;
        for &v in vs {
            c += self.positions[v as usize];
        }
        c / vs.len().max(1) as f32
    }
    pub fn face_normals(&self) -> Vec<Vec3> {
        crate::par::parallel_map(self.face_count(), 8192, |f| self.face_normal(f))
    }
    /// Angle of the polygon corner at local position `i` of face `f`.
    pub fn corner_angle(&self, f: usize, i: usize) -> f32 {
        let vs = self.face_verts(f);
        let n = vs.len();
        let p = self.positions[vs[i] as usize];
        let a = (self.positions[vs[(i + n - 1) % n] as usize] - p).normalize();
        let b = (self.positions[vs[(i + 1) % n] as usize] - p).normalize();
        a.dot(b).clamp(-1.0, 1.0).acos()
    }
    /// Angle-weighted vertex normals from **all** faces (ignores smooth flags). Unused vertices get zero.
    pub fn vertex_normals(&self) -> Vec<Vec3> {
        let mut acc = vec![Vec3::ZERO; self.vert_count()];
        for f in 0..self.face_count() {
            let n = self.face_normal(f);
            if n == Vec3::ZERO {
                continue;
            }
            for (i, &v) in self.face_verts(f).iter().enumerate() {
                acc[v as usize] += n * self.corner_angle(f, i);
            }
        }
        acc.iter().map(|v| v.normalize()).collect()
    }
    /// Per-corner shading normals: smooth faces use angle-weighted vertex normals accumulated over the *smooth*
    /// faces around the vertex, flat faces use their face normal.
    pub fn corner_normals(&self) -> Vec<Vec3> {
        let fnorm = self.face_normals();
        let mut acc = vec![Vec3::ZERO; self.vert_count()];
        for f in 0..self.face_count() {
            if !self.face_smooth[f] || fnorm[f] == Vec3::ZERO {
                continue;
            }
            for (i, &v) in self.face_verts(f).iter().enumerate() {
                acc[v as usize] += fnorm[f] * self.corner_angle(f, i);
            }
        }
        let mut out = vec![Vec3::Z; self.corners.len()];
        for f in 0..self.face_count() {
            let fallback = if fnorm[f] == Vec3::ZERO { Vec3::Z } else { fnorm[f] };
            for c in self.face_range(f) {
                out[c] = if self.face_smooth[f] {
                    let n = acc[self.corners[c] as usize].normalize();
                    if n == Vec3::ZERO {
                        fallback
                    } else {
                        n
                    }
                } else {
                    fallback
                };
            }
        }
        out
    }

    // ------------------------------------------------------------------ triangulation
    /// Triangulate face `f`, appending triples of **global corner indices** (`corners[c]` is the vertex).
    pub fn triangulate_face(&self, f: usize, out: &mut Vec<[u32; 3]>) {
        let r = self.face_range(f);
        let base = r.start as u32;
        match r.len() {
            0..=2 => {}
            3 => out.push([base, base + 1, base + 2]),
            n => {
                let pts: Vec<Vec3> = self.corners[r].iter().map(|&v| self.positions[v as usize]).collect();
                let start = out.len();
                tri::triangulate_polygon(&pts, out);
                for t in &mut out[start..] {
                    t[0] += base;
                    t[1] += base;
                    t[2] += base;
                }
                debug_assert!(n >= 4);
            }
        }
    }
    /// All triangles of the mesh as vertex-index triples (parallel for big meshes is not needed: it is cheap).
    pub fn triangles(&self) -> Vec<[u32; 3]> {
        let mut out = Vec::with_capacity(self.triangle_count());
        for f in 0..self.face_count() {
            self.triangulate_face(f, &mut out);
        }
        for t in &mut out {
            for i in 0..3 {
                t[i] = self.corners[t[i] as usize];
            }
        }
        out
    }
    /// A copy where every face is a triangle (materials/smooth flags/UVs are carried over).
    pub fn to_triangle_mesh(&self) -> Mesh {
        let mut out = Mesh::new();
        out.positions = self.positions.clone();
        out.loose_edges = self.loose_edges.clone();
        let has_uv = self.uvs.len() == self.corners.len() && !self.uvs.is_empty();
        let mut tris = Vec::new();
        for f in 0..self.face_count() {
            tris.clear();
            self.triangulate_face(f, &mut tris);
            for t in &tris {
                out.corners.extend(t.iter().map(|&c| self.corners[c as usize]));
                out.face_starts.push(out.corners.len() as u32);
                out.face_material.push(self.face_material[f]);
                out.face_smooth.push(self.face_smooth[f]);
                if has_uv {
                    out.uvs.extend(t.iter().map(|&c| self.uvs[c as usize]));
                }
            }
        }
        out
    }

    // ------------------------------------------------------------------ transforms
    /// Transform all positions. A mirroring matrix (negative determinant) also reverses face winding so
    /// normals keep pointing outwards.
    pub fn transform(&mut self, m: &Mat4) {
        for p in &mut self.positions {
            *p = m.transform_point3(*p);
        }
        if m.mat3().determinant() < 0.0 {
            self.flip_all_faces();
        }
    }
    pub fn translate(&mut self, d: Vec3) {
        for p in &mut self.positions {
            *p += d;
        }
    }
    /// Reverse the winding of the selected faces (`None` = all); UV order follows.
    pub fn flip_faces(&mut self, mask: Option<&[bool]>) {
        for f in 0..self.face_count() {
            if mask.map_or(true, |m| m.get(f).copied().unwrap_or(false)) {
                let r = self.face_range(f);
                self.corners[r.clone()].reverse();
                if self.uvs.len() == self.corners.len() {
                    self.uvs[r].reverse();
                }
            }
        }
    }
    pub fn flip_all_faces(&mut self) {
        self.flip_faces(None);
    }

    // ------------------------------------------------------------------ validation helpers
    /// Cheap structural check; everything else in the workspace assumes this holds.
    pub fn check_structure(&self) -> Result<(), String> {
        let nf = self.face_count();
        if self.face_starts.first() != Some(&0) {
            return Err("face_starts must start with 0".into());
        }
        if self.face_starts.windows(2).any(|w| w[1] < w[0]) {
            return Err("face_starts is not monotonic".into());
        }
        if *self.face_starts.last().unwrap_or(&0) as usize != self.corners.len() {
            return Err("face_starts does not cover all corners".into());
        }
        if self.face_material.len() != nf || self.face_smooth.len() != nf {
            return Err("per-face arrays have the wrong length".into());
        }
        if !self.uvs.is_empty() && self.uvs.len() != self.corners.len() {
            return Err("uvs must be empty or one per corner".into());
        }
        let n = self.positions.len();
        if self.corners.iter().any(|&c| c as usize >= n) {
            return Err("a corner references a vertex out of range".into());
        }
        if self.loose_edges.iter().any(|e| e[0] as usize >= n || e[1] as usize >= n) {
            return Err("a loose edge references a vertex out of range".into());
        }
        Ok(())
    }
    /// Approximate heap footprint in bytes (for memory budgets).
    pub fn memory_bytes(&self) -> usize {
        self.positions.len() * 12
            + self.face_starts.len() * 4
            + self.corners.len() * 4
            + self.face_material.len() * 2
            + self.face_smooth.len()
            + self.loose_edges.len() * 8
            + self.uvs.len() * 8
    }
}

#[cfg(test)]
pub(crate) mod tests_support {
    use super::*;

    pub fn unit_cube() -> Mesh {
        let p = |x: f32, y: f32, z: f32| Vec3::new(x, y, z);
        let pos = vec![p(-1., -1., -1.), p(1., -1., -1.), p(1., 1., -1.), p(-1., 1., -1.), p(-1., -1., 1.), p(1., -1., 1.), p(1., 1., 1.), p(-1., 1., 1.)];
        let faces = vec![
            vec![0, 3, 2, 1], // bottom (-z)
            vec![4, 5, 6, 7], // top (+z)
            vec![0, 1, 5, 4], // -y
            vec![2, 3, 7, 6], // +y
            vec![1, 2, 6, 5], // +x
            vec![3, 0, 4, 7], // -x
        ];
        Mesh::from_polygons(pos, &faces)
    }

}

#[cfg(test)]
mod tests {
    use super::*;
    use super::tests_support::unit_cube;

    #[test]
    fn cube_basics() {
        let m = unit_cube();
        assert_eq!((m.vert_count(), m.face_count(), m.corner_count(), m.triangle_count()), (8, 6, 24, 12));
        assert!(m.check_structure().is_ok());
        for f in 0..6 {
            // every normal must point away from the centre
            assert!(m.face_normal(f).dot(m.face_center(f)) > 0.99, "face {f}");
            assert!((m.face_area(f) - 4.0).abs() < 1e-5);
        }
        assert!(m.bounds().size().abs_diff_eq(Vec3::splat(2.0), 1e-6));
        let t = m.to_triangle_mesh();
        assert_eq!(t.face_count(), 12);
        assert!(t.check_structure().is_ok());
        assert_eq!(m.triangles().len(), 12);
    }

    #[test]
    fn normals_flat_and_smooth() {
        let mut m = unit_cube();
        let n = m.corner_normals();
        assert!(n[0].dot(m.face_normal(0)) > 0.999);
        m.face_smooth.iter_mut().for_each(|s| *s = true);
        let n = m.corner_normals();
        // smooth cube corner normal points along the diagonal
        let v = m.corners[0] as usize;
        assert!(n[0].dot(m.positions[v].normalize()) > 0.999);
        assert!(m.vertex_normals().iter().all(|v| (v.length() - 1.0).abs() < 1e-5));
    }

    #[test]
    fn mirror_transform_keeps_normals_outward() {
        let mut m = unit_cube();
        m.transform(&Mat4::from_scale(Vec3::new(-1.0, 1.0, 1.0)));
        for f in 0..6 {
            assert!(m.face_normal(f).dot(m.face_center(f)) > 0.99, "face {f}");
        }
    }

    #[test]
    fn pydata_validation() {
        let pos = vec![Vec3::ZERO, Vec3::X, Vec3::Y];
        assert!(Mesh::try_from_pydata(pos.clone(), &[], &[vec![0, 1, 3]]).is_err());
        assert!(Mesh::try_from_pydata(pos.clone(), &[], &[vec![0, 1]]).is_err());
        assert!(Mesh::try_from_pydata(vec![Vec3::new(f32::NAN, 0.0, 0.0)], &[], &[]).is_err());
        // edge (0,1) is covered by the face, (1,2) too, loose (0,2) is also a face edge -> all dropped
        let m = Mesh::try_from_pydata(pos, &[[0, 1], [1, 2], [2, 0]], &[vec![0, 1, 2]]).unwrap();
        assert!(m.loose_edges.is_empty());
        let w = Mesh::try_from_pydata(vec![Vec3::ZERO, Vec3::X, Vec3::Y, Vec3::Z], &[[0, 3]], &[vec![0, 1, 2]]).unwrap();
        assert_eq!(w.loose_edges, vec![[0, 3]]);
    }

    #[test]
    fn push_mesh_merges_attributes() {
        let mut a = unit_cube();
        let mut b = unit_cube();
        b.ensure_uvs();
        let off = a.push_mesh(&b);
        assert_eq!(off, 8);
        assert_eq!(a.face_count(), 12);
        assert!(a.check_structure().is_ok());
        assert_eq!(a.uvs.len(), a.corners.len());
    }
}
