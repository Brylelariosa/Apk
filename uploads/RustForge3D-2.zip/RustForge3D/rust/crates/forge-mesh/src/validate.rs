//! Mesh validation used for "validate generated geometry" (scripts, imports, op results).
use crate::mesh::Mesh;
use crate::topology::Topology;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct ValidationReport {
    pub vertices: usize,
    pub faces: usize,
    pub edges: usize,
    pub non_finite_positions: usize,
    pub out_of_range_corners: usize,
    /// Structural problems that make the other counters meaningless (bad CSR layout, array lengths...).
    pub structure_error: Option<String>,
    pub bad_face_sizes: usize,
    /// Faces that repeat a vertex or have (almost) zero area.
    pub degenerate_faces: usize,
    /// Vertices used by no face and no loose edge.
    pub unused_vertices: usize,
    pub boundary_edges: usize,
    pub non_manifold_edges: usize,
    pub inconsistent_winding_edges: usize,
    pub loose_edges: usize,
    pub euler_characteristic: i64,
}

impl ValidationReport {
    /// Safe to render / transform / export (indices and numbers are sane).
    pub fn is_structurally_valid(&self) -> bool {
        self.structure_error.is_none() && self.non_finite_positions == 0 && self.out_of_range_corners == 0 && self.bad_face_sizes == 0
    }
    pub fn is_closed(&self) -> bool {
        self.faces > 0 && self.boundary_edges == 0
    }
    pub fn is_manifold(&self) -> bool {
        self.non_manifold_edges == 0
    }
    /// Closed, manifold, consistently wound: a proper solid (required for booleans).
    pub fn is_watertight(&self) -> bool {
        self.is_structurally_valid() && self.is_closed() && self.is_manifold() && self.inconsistent_winding_edges == 0
    }
    pub fn summary(&self) -> String {
        if let Some(e) = &self.structure_error {
            return format!("invalid mesh structure: {e}");
        }
        let mut issues = Vec::new();
        if self.non_finite_positions > 0 {
            issues.push(format!("{} non-finite vertices", self.non_finite_positions));
        }
        if self.out_of_range_corners > 0 {
            issues.push(format!("{} out-of-range indices", self.out_of_range_corners));
        }
        if self.bad_face_sizes > 0 {
            issues.push(format!("{} faces with <3 vertices", self.bad_face_sizes));
        }
        if self.degenerate_faces > 0 {
            issues.push(format!("{} degenerate faces", self.degenerate_faces));
        }
        if self.non_manifold_edges > 0 {
            issues.push(format!("{} non-manifold edges", self.non_manifold_edges));
        }
        if self.inconsistent_winding_edges > 0 {
            issues.push(format!("{} edges with inconsistent winding", self.inconsistent_winding_edges));
        }
        let head = format!("{} verts, {} edges, {} faces", self.vertices, self.edges, self.faces);
        if issues.is_empty() {
            format!("{head}; {}", if self.is_closed() { "closed manifold" } else { "open surface" })
        } else {
            format!("{head}; {}", issues.join(", "))
        }
    }
}

pub fn validate(mesh: &Mesh) -> ValidationReport {
    let mut r = ValidationReport { vertices: mesh.vert_count(), faces: mesh.face_count(), ..Default::default() };
    r.non_finite_positions = mesh.positions.iter().filter(|p| !p.is_finite()).count();
    if let Err(e) = mesh.check_structure() {
        r.structure_error = Some(e);
        r.out_of_range_corners = mesh.corners.iter().filter(|&&c| c as usize >= mesh.vert_count()).count();
        return r;
    }
    r.bad_face_sizes = (0..mesh.face_count()).filter(|&f| mesh.face_len(f) < 3).count();
    let topo = Topology::build(mesh);
    r.edges = topo.edges.len();
    r.boundary_edges = topo.boundary_edge_count();
    r.non_manifold_edges = topo.non_manifold_edge_count();
    r.inconsistent_winding_edges = topo.winding_conflict.iter().filter(|&&c| c).count();
    r.loose_edges = topo.edges.len() - topo.loose_start;
    let mut used = vec![false; mesh.vert_count()];
    for &c in &mesh.corners {
        used[c as usize] = true;
    }
    for e in &mesh.loose_edges {
        used[e[0] as usize] = true;
        used[e[1] as usize] = true;
    }
    r.unused_vertices = used.iter().filter(|&&u| !u).count();
    for f in 0..mesh.face_count() {
        let vs = mesh.face_verts(f);
        let mut dup = false;
        for i in 0..vs.len() {
            for j in i + 1..vs.len() {
                dup |= vs[i] == vs[j];
            }
            if dup {
                break;
            }
        }
        if dup || mesh.face_area(f) < 1e-12 {
            r.degenerate_faces += 1;
        }
    }
    let face_edges = topo.loose_start as i64;
    r.euler_characteristic = r.vertices as i64 - r.unused_vertices as i64 - face_edges + r.faces as i64;
    r
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mesh::tests_support::unit_cube;
    use forge_math::Vec3;

    #[test]
    fn cube_is_watertight_with_euler_2() {
        let r = validate(&unit_cube());
        assert!(r.is_watertight(), "{}", r.summary());
        assert_eq!(r.euler_characteristic, 2);
        assert_eq!((r.edges, r.degenerate_faces, r.unused_vertices), (12, 0, 0));
    }

    #[test]
    fn detects_problems() {
        let mut m = unit_cube();
        m.flip_faces(Some(&[true, false, false, false, false, false]));
        let r = validate(&m);
        assert!(!r.is_watertight() && r.inconsistent_winding_edges == 4);
        let mut open = unit_cube();
        open.positions.push(Vec3::new(f32::NAN, 0.0, 0.0));
        assert_eq!(validate(&open).non_finite_positions, 1);
        assert!(!validate(&open).is_structurally_valid());
        let mut bad = unit_cube();
        bad.corners[3] = 99;
        let r = validate(&bad);
        assert!(r.structure_error.is_some() && r.out_of_range_corners == 1 && !r.is_structurally_valid());
        let tri = Mesh::from_triangles(vec![Vec3::ZERO, Vec3::X, Vec3::Y, Vec3::Z], &[[0, 1, 2]]);
        let r = validate(&tri);
        assert!(!r.is_closed() && r.boundary_edges == 3 && r.unused_vertices == 1);
        let degenerate = Mesh::from_polygons(vec![Vec3::ZERO, Vec3::X, Vec3::X * 2.0], &[vec![0, 1, 2]]);
        assert_eq!(validate(&degenerate).degenerate_faces, 1);
    }
}
