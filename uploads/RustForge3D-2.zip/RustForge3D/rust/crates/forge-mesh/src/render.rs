//! CPU-side GPU buffers: one render vertex per mesh corner (so flat/smooth shading and UV seams need no
//! duplication logic) plus material-grouped triangle indices and an edge line list.
//! Position-only edits (move, sculpt) patch the buffers incrementally via [`RenderBuffers::update_positions`].
use crate::mesh::Mesh;
use crate::topology::{Topology, NONE};
use forge_math::Vec3;
use std::ops::Range;

/// 32-byte interleaved vertex (`#[repr(C)]` so the platform layer can upload it as bytes).
#[repr(C)]
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct RenderVertex {
    pub position: [f32; 3],
    pub normal: [f32; 3],
    pub uv: [f32; 2],
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SubMesh {
    pub first_index: u32,
    pub index_count: u32,
    /// Material slot of the faces in this range.
    pub material: u32,
}

#[derive(Clone, Debug, Default)]
pub struct RenderBuffers {
    /// `vertices[c]` belongs to mesh corner `c`; loose-edge end points are appended after the corners.
    pub vertices: Vec<RenderVertex>,
    /// Triangle list over corner vertices, grouped by material (see `submeshes`).
    pub indices: Vec<u32>,
    /// Line list (pairs) over `vertices`: every unique edge once, plus loose edges.
    pub edge_indices: Vec<u32>,
    pub submeshes: Vec<SubMesh>,
    corner_count: usize,
    /// Mesh vertex behind each appended loose-edge render vertex (kept for incremental patching).
    loose_verts: Vec<u32>,
}

/// Vertex -> corners adjacency, needed for incremental patching. Rebuild when topology changes.
#[derive(Clone, Debug, Default)]
pub struct VertexCorners {
    pub start: Vec<u32>,
    pub corners: Vec<u32>,
    pub face_of_corner: Vec<u32>,
}

impl VertexCorners {
    pub fn build(mesh: &Mesh) -> VertexCorners {
        let nv = mesh.vert_count();
        let mut face_of_corner = vec![0u32; mesh.corner_count()];
        let mut start = vec![0u32; nv + 1];
        for f in 0..mesh.face_count() {
            for c in mesh.face_range(f) {
                face_of_corner[c] = f as u32;
                start[mesh.corners[c] as usize + 1] += 1;
            }
        }
        for v in 0..nv {
            start[v + 1] += start[v];
        }
        let mut cursor = start.clone();
        let mut corners = vec![0u32; mesh.corner_count()];
        for (c, &v) in mesh.corners.iter().enumerate() {
            corners[cursor[v as usize] as usize] = c as u32;
            cursor[v as usize] += 1;
        }
        VertexCorners { start, corners, face_of_corner }
    }
    #[inline]
    pub fn corners_of(&self, v: u32) -> &[u32] {
        &self.corners[self.start[v as usize] as usize..self.start[v as usize + 1] as usize]
    }
}

impl RenderBuffers {
    pub fn build(mesh: &Mesh) -> RenderBuffers {
        let topo = Topology::build(mesh);
        RenderBuffers::build_with(mesh, &topo)
    }

    pub fn build_with(mesh: &Mesh, topo: &Topology) -> RenderBuffers {
        let nc = mesh.corner_count();
        let normals = mesh.corner_normals();
        let has_uv = mesh.uvs.len() == nc && nc > 0;
        let mut vertices: Vec<RenderVertex> = Vec::with_capacity(nc + mesh.loose_edges.len() * 2);
        for c in 0..nc {
            vertices.push(RenderVertex {
                position: mesh.positions[mesh.corners[c] as usize].to_array(),
                normal: normals[c].to_array(),
                uv: if has_uv { mesh.uvs[c].to_array() } else { [0.0, 0.0] },
            });
        }

        // triangles grouped by material slot
        let max_mat = mesh.face_material.iter().copied().max().unwrap_or(0) as usize;
        let mut per_mat: Vec<Vec<u32>> = vec![Vec::new(); max_mat + 1];
        let mut tris: Vec<[u32; 3]> = Vec::new();
        for f in 0..mesh.face_count() {
            tris.clear();
            mesh.triangulate_face(f, &mut tris);
            let bucket = &mut per_mat[mesh.face_material[f] as usize];
            for t in &tris {
                bucket.extend_from_slice(t);
            }
        }
        let mut indices = Vec::with_capacity(per_mat.iter().map(Vec::len).sum());
        let mut submeshes = Vec::new();
        for (m, list) in per_mat.iter().enumerate() {
            if !list.is_empty() {
                submeshes.push(SubMesh { first_index: indices.len() as u32, index_count: list.len() as u32, material: m as u32 });
                indices.extend_from_slice(list);
            }
        }

        // edge line list
        let mut edge_indices = Vec::with_capacity(topo.edges.len() * 2);
        for e in 0..topo.loose_start {
            let c = topo.edge_corner[e];
            if c == NONE {
                continue;
            }
            let f = topo.face_of_corner[c as usize] as usize;
            let r = mesh.face_range(f);
            let next = if c as usize + 1 == r.end { r.start as u32 } else { c + 1 };
            edge_indices.push(c);
            edge_indices.push(next);
        }
        let mut loose_verts = Vec::new();
        for e in &topo.edges[topo.loose_start..] {
            let base = vertices.len() as u32;
            for &v in e {
                vertices.push(RenderVertex { position: mesh.positions[v as usize].to_array(), normal: [0.0, 0.0, 1.0], uv: [0.0, 0.0] });
                loose_verts.push(v);
            }
            edge_indices.push(base);
            edge_indices.push(base + 1);
        }
        RenderBuffers { vertices, indices, edge_indices, submeshes, corner_count: nc, loose_verts }
    }

    /// Patch positions and shading normals after the given vertices moved (topology unchanged).
    /// Returns the touched render-vertex range, or `None` if the caller must rebuild from scratch.
    pub fn update_positions(&mut self, mesh: &Mesh, vc: &VertexCorners, dirty: &[u32]) -> Option<Range<u32>> {
        if self.corner_count != mesh.corner_count() || vc.start.len() != mesh.vert_count() + 1 || vc.face_of_corner.len() != self.corner_count {
            return None;
        }
        let (mut lo, mut hi) = (u32::MAX, 0u32);
        let mut touch = |c: u32| {
            lo = lo.min(c);
            hi = hi.max(c + 1);
        };
        let mut faces: Vec<u32> = Vec::new();
        for &v in dirty {
            if v as usize >= mesh.vert_count() {
                return None;
            }
            let p = mesh.positions[v as usize].to_array();
            for &c in vc.corners_of(v) {
                self.vertices[c as usize].position = p;
                faces.push(vc.face_of_corner[c as usize]);
                touch(c);
            }
        }
        faces.sort_unstable();
        faces.dedup();
        let mut verts: Vec<u32> = Vec::new();
        for &f in &faces {
            let f = f as usize;
            verts.extend_from_slice(mesh.face_verts(f));
            if !mesh.face_smooth[f] {
                let n = mesh.face_normal(f);
                let n = if n == Vec3::ZERO { Vec3::Z } else { n }.to_array();
                for c in mesh.face_range(f) {
                    self.vertices[c].normal = n;
                    touch(c as u32);
                }
            }
        }
        verts.sort_unstable();
        verts.dedup();
        for &v in &verts {
            let mut acc = Vec3::ZERO;
            for &c in vc.corners_of(v) {
                let f = vc.face_of_corner[c as usize] as usize;
                if !mesh.face_smooth[f] {
                    continue;
                }
                let fnrm = mesh.face_normal(f);
                if fnrm == Vec3::ZERO {
                    continue;
                }
                let local = c as usize - mesh.face_starts[f] as usize;
                acc += fnrm * mesh.corner_angle(f, local);
            }
            let n = acc.normalize();
            for &c in vc.corners_of(v) {
                let f = vc.face_of_corner[c as usize] as usize;
                if mesh.face_smooth[f] {
                    let fallback = mesh.face_normal(f);
                    let out = if n != Vec3::ZERO {
                        n
                    } else if fallback != Vec3::ZERO {
                        fallback
                    } else {
                        Vec3::Z
                    };
                    self.vertices[c as usize].normal = out.to_array();
                    touch(c);
                }
            }
        }
        // loose-edge end points live after the corner vertices
        if !self.loose_verts.is_empty() {
            let dirty_set: std::collections::HashSet<u32> = dirty.iter().copied().collect();
            for (k, &v) in self.loose_verts.iter().enumerate() {
                if dirty_set.contains(&v) {
                    let idx = self.corner_count + k;
                    self.vertices[idx].position = mesh.positions[v as usize].to_array();
                    touch(idx as u32);
                }
            }
        }
        if lo == u32::MAX {
            Some(0..0)
        } else {
            Some(lo..hi)
        }
    }

    pub fn triangle_count(&self) -> usize {
        self.indices.len() / 3
    }
    pub fn memory_bytes(&self) -> usize {
        self.vertices.len() * std::mem::size_of::<RenderVertex>() + (self.indices.len() + self.edge_indices.len()) * 4
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mesh::tests_support::unit_cube;
    use forge_math::Vec3;

    #[test]
    fn cube_buffers() {
        let m = unit_cube();
        let b = RenderBuffers::build(&m);
        assert_eq!(b.vertices.len(), 24);
        assert_eq!(b.indices.len(), 36);
        assert_eq!(b.edge_indices.len(), 24);
        assert_eq!(b.submeshes, vec![SubMesh { first_index: 0, index_count: 36, material: 0 }]);
        assert_eq!(std::mem::size_of::<RenderVertex>(), 32);
        // flat shading: corner normal equals face normal
        assert!(Vec3::from_array(b.vertices[0].normal).dot(m.face_normal(0)) > 0.999);
        assert!(b.indices.iter().all(|&i| (i as usize) < b.vertices.len()));
        assert!(b.edge_indices.iter().all(|&i| (i as usize) < b.vertices.len()));
    }

    #[test]
    fn materials_split_into_submeshes() {
        let mut m = unit_cube();
        m.face_material = vec![0, 1, 1, 0, 2, 0];
        let b = RenderBuffers::build(&m);
        assert_eq!(b.submeshes.iter().map(|s| s.material).collect::<Vec<_>>(), vec![0, 1, 2]);
        assert_eq!(b.submeshes.iter().map(|s| s.index_count).sum::<u32>(), 36);
        assert_eq!(b.submeshes[1].index_count, 12);
    }

    fn assert_buffers_match(a: &RenderBuffers, b: &RenderBuffers) {
        assert_eq!(a.vertices.len(), b.vertices.len());
        for (i, (x, y)) in a.vertices.iter().zip(&b.vertices).enumerate() {
            for k in 0..3 {
                assert!((x.position[k] - y.position[k]).abs() < 1e-5, "pos {i}");
                assert!((x.normal[k] - y.normal[k]).abs() < 1e-4, "normal {i}: {:?} vs {:?}", x.normal, y.normal);
            }
        }
    }

    #[test]
    fn incremental_update_equals_rebuild_flat_and_smooth() {
        for smooth in [false, true] {
            let mut m = unit_cube();
            m.face_smooth.iter_mut().for_each(|s| *s = smooth);
            let mut b = RenderBuffers::build(&m);
            let vc = VertexCorners::build(&m);
            m.positions[6] = Vec3::new(2.0, 1.5, 3.0);
            m.positions[2] = Vec3::new(1.2, 1.0, -0.5);
            let range = b.update_positions(&m, &vc, &[6, 2]).unwrap();
            assert!(range.end > range.start && (range.end as usize) <= b.vertices.len());
            assert_buffers_match(&b, &RenderBuffers::build(&m));
        }
    }

    #[test]
    fn update_rejects_stale_topology() {
        let m = unit_cube();
        let mut b = RenderBuffers::build(&m);
        let vc = VertexCorners::build(&m);
        let mut bigger = m.clone();
        bigger.add_face(&[0, 1, 2]);
        assert!(b.update_positions(&bigger, &vc, &[0]).is_none());
        assert!(b.update_positions(&m, &vc, &[99]).is_none());
    }
}
