//! Edge and adjacency topology derived from a [`Mesh`] (rebuild after topology changes).
use crate::mesh::Mesh;

/// "No element" marker used in index arrays.
pub const NONE: u32 = u32::MAX;

/// Compressed sparse rows: `items[start[i]..start[i+1]]` belong to row `i`.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Csr {
    pub start: Vec<u32>,
    pub items: Vec<u32>,
}

impl Csr {
    pub fn from_pairs(rows: usize, pairs: &[(u32, u32)]) -> Csr {
        let mut start = vec![0u32; rows + 1];
        for &(r, _) in pairs {
            start[r as usize + 1] += 1;
        }
        for i in 0..rows {
            start[i + 1] += start[i];
        }
        let mut cursor = start.clone();
        let mut items = vec![0u32; pairs.len()];
        for &(r, it) in pairs {
            items[cursor[r as usize] as usize] = it;
            cursor[r as usize] += 1;
        }
        Csr { start, items }
    }
    #[inline]
    pub fn get(&self, row: usize) -> &[u32] {
        &self.items[self.start[row] as usize..self.start[row + 1] as usize]
    }
    pub fn rows(&self) -> usize {
        self.start.len().saturating_sub(1)
    }
}

#[derive(Clone, Debug, Default)]
pub struct Topology {
    /// Unique edges `[lo, hi]` sorted lexicographically; face edges first, then loose edges (`loose_start..`).
    pub edges: Vec<[u32; 2]>,
    /// Up to two incident faces per edge (`NONE` when absent).
    pub edge_faces: Vec<[u32; 2]>,
    /// Number of face-corner uses of the edge (1 = boundary, 2 = manifold, >2 = non-manifold, 0 = loose).
    pub edge_face_count: Vec<u32>,
    /// A corner `c` whose edge `c -> next corner of the face` is this edge (`NONE` for loose edges).
    pub edge_corner: Vec<u32>,
    /// Manifold edge whose two faces traverse it in the same direction (inconsistent winding).
    pub winding_conflict: Vec<bool>,
    /// Edge of corner `c` towards the next corner of its face (`NONE` for degenerate repeated vertices).
    pub corner_edge: Vec<u32>,
    pub face_of_corner: Vec<u32>,
    pub vert_edges: Csr,
    pub vert_faces: Csr,
    pub loose_start: usize,
}

impl Topology {
    /// Build for a structurally valid mesh (`Mesh::check_structure` ok).
    pub fn build(mesh: &Mesh) -> Topology {
        let nc = mesh.corners.len();
        let nf = mesh.face_count();
        let nv = mesh.vert_count();
        let mut face_of_corner = vec![0u32; nc];
        let mut keyed: Vec<(u64, u32)> = Vec::with_capacity(nc);
        for f in 0..nf {
            let r = mesh.face_range(f);
            let n = r.len();
            for k in 0..n {
                let c = r.start + k;
                face_of_corner[c] = f as u32;
                let a = mesh.corners[c];
                let b = mesh.corners[r.start + (k + 1) % n];
                if a != b {
                    let (lo, hi) = if a < b { (a, b) } else { (b, a) };
                    keyed.push((((lo as u64) << 32) | hi as u64, c as u32));
                }
            }
        }
        keyed.sort_unstable();

        let mut corner_edge = vec![NONE; nc];
        let mut edges: Vec<[u32; 2]> = Vec::new();
        let mut edge_faces = Vec::new();
        let mut edge_face_count = Vec::new();
        let mut edge_corner = Vec::new();
        let mut winding_conflict = Vec::new();
        let mut i = 0;
        while i < keyed.len() {
            let key = keyed[i].0;
            let lo = (key >> 32) as u32;
            let hi = (key & 0xffff_ffff) as u32;
            let e = edges.len() as u32;
            let mut faces = [NONE; 2];
            let mut dirs = [false; 2];
            let mut count = 0usize;
            let mut j = i;
            while j < keyed.len() && keyed[j].0 == key {
                let c = keyed[j].1 as usize;
                corner_edge[c] = e;
                if count < 2 {
                    faces[count] = face_of_corner[c];
                    dirs[count] = mesh.corners[c] == lo;
                }
                count += 1;
                j += 1;
            }
            edges.push([lo, hi]);
            edge_faces.push(faces);
            edge_face_count.push(count as u32);
            edge_corner.push(keyed[i].1);
            winding_conflict.push(count == 2 && dirs[0] == dirs[1]);
            i = j;
        }

        let loose_start = edges.len();
        let mut loose: Vec<(u32, u32)> = Vec::new();
        for e in &mesh.loose_edges {
            if e[0] == e[1] {
                continue;
            }
            let (lo, hi) = if e[0] < e[1] { (e[0], e[1]) } else { (e[1], e[0]) };
            if edges[..loose_start].binary_search_by(|x| (x[0], x[1]).cmp(&(lo, hi))).is_err() {
                loose.push((lo, hi));
            }
        }
        loose.sort_unstable();
        loose.dedup();
        for (lo, hi) in loose {
            edges.push([lo, hi]);
            edge_faces.push([NONE; 2]);
            edge_face_count.push(0);
            edge_corner.push(NONE);
            winding_conflict.push(false);
        }

        let mut ve: Vec<(u32, u32)> = Vec::with_capacity(edges.len() * 2);
        for (e, ed) in edges.iter().enumerate() {
            ve.push((ed[0], e as u32));
            ve.push((ed[1], e as u32));
        }
        let vf: Vec<(u32, u32)> = (0..nc).map(|c| (mesh.corners[c], face_of_corner[c])).collect();
        Topology {
            vert_edges: Csr::from_pairs(nv, &ve),
            vert_faces: Csr::from_pairs(nv, &vf),
            edges,
            edge_faces,
            edge_face_count,
            edge_corner,
            winding_conflict,
            corner_edge,
            face_of_corner,
            loose_start,
        }
    }

    pub fn edge_between(&self, a: u32, b: u32) -> Option<u32> {
        if a as usize >= self.vert_edges.rows() {
            return None;
        }
        self.vert_edges.get(a as usize).iter().copied().find(|&e| {
            let ed = self.edges[e as usize];
            (ed[0] == a && ed[1] == b) || (ed[0] == b && ed[1] == a)
        })
    }
    pub fn is_loose(&self, e: u32) -> bool {
        e as usize >= self.loose_start
    }
    pub fn is_boundary(&self, e: u32) -> bool {
        self.edge_face_count[e as usize] == 1
    }
    pub fn is_manifold_edge(&self, e: u32) -> bool {
        self.edge_face_count[e as usize] == 2
    }
    pub fn other_face(&self, e: u32, f: u32) -> Option<u32> {
        let fs = self.edge_faces[e as usize];
        if self.edge_face_count[e as usize] != 2 {
            return None;
        }
        if fs[0] == f {
            Some(fs[1])
        } else if fs[1] == f {
            Some(fs[0])
        } else {
            None
        }
    }
    pub fn other_vertex(&self, e: u32, v: u32) -> u32 {
        let ed = self.edges[e as usize];
        if ed[0] == v {
            ed[1]
        } else {
            ed[0]
        }
    }
    /// Edges of face `f` in winding order (edge from corner i to corner i+1).
    pub fn face_edges<'a>(&'a self, mesh: &Mesh, f: usize) -> &'a [u32] {
        &self.corner_edge[mesh.face_range(f)]
    }
    pub fn vert_neighbors(&self, v: u32) -> impl Iterator<Item = u32> + '_ {
        self.vert_edges.get(v as usize).iter().map(move |&e| self.other_vertex(e, v))
    }
    /// Number of edges that have exactly one / more than two faces.
    pub fn boundary_edge_count(&self) -> usize {
        self.edge_face_count.iter().filter(|&&c| c == 1).count()
    }
    pub fn non_manifold_edge_count(&self) -> usize {
        self.edge_face_count.iter().filter(|&&c| c > 2).count()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mesh::tests_support::unit_cube;

    #[test]
    fn cube_topology() {
        let m = unit_cube();
        let t = Topology::build(&m);
        assert_eq!(t.edges.len(), 12);
        assert!(t.edge_face_count.iter().all(|&c| c == 2));
        assert!(t.winding_conflict.iter().all(|&c| !c));
        assert_eq!(t.loose_start, 12);
        assert!(t.vert_edges.rows() == 8 && (0..8).all(|v| t.vert_edges.get(v).len() == 3));
        assert!((0..8).all(|v| t.vert_faces.get(v).len() == 3));
        assert!(t.edge_between(0, 1).is_some() && t.edge_between(0, 6).is_none());
        let e = t.edge_between(0, 1).unwrap();
        let fs = t.edge_faces[e as usize];
        assert_eq!(t.other_face(e, fs[0]), Some(fs[1]));
        assert_eq!(t.face_edges(&m, 0).len(), 4);
        assert_eq!(t.vert_neighbors(0).count(), 3);
    }

    #[test]
    fn flipped_face_is_a_winding_conflict() {
        let mut m = unit_cube();
        m.flip_faces(Some(&[true, false, false, false, false, false]));
        let t = Topology::build(&m);
        assert_eq!(t.winding_conflict.iter().filter(|&&c| c).count(), 4);
    }

    #[test]
    fn loose_edges_and_open_edges() {
        use forge_math::Vec3;
        let m = Mesh::try_from_pydata(
            vec![Vec3::ZERO, Vec3::X, Vec3::Y, Vec3::Z],
            &[[0, 3], [3, 0], [1, 2]],
            &[vec![0, 1, 2]],
        )
        .unwrap();
        let t = Topology::build(&m);
        assert_eq!(t.edges.len(), 4);
        assert_eq!(t.loose_start, 3);
        assert!(t.is_loose(3) && t.edge_face_count[3] == 0);
        assert_eq!(t.boundary_edge_count(), 3);
    }
}
