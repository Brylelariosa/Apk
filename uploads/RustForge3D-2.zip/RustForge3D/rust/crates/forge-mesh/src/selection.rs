//! Per-vertex selection flags (faces/edges are derived). See docs/ARCHITECTURE.md "Selection model".
use crate::mesh::Mesh;
use crate::topology::Topology;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Selection {
    pub verts: Vec<bool>,
}

impl Selection {
    pub fn none(n: usize) -> Selection {
        Selection { verts: vec![false; n] }
    }
    pub fn all(n: usize) -> Selection {
        Selection { verts: vec![true; n] }
    }
    pub fn from_indices(n: usize, idx: impl IntoIterator<Item = u32>) -> Selection {
        let mut s = Selection::none(n);
        for v in idx {
            s.set(v, true);
        }
        s
    }
    pub fn len(&self) -> usize {
        self.verts.len()
    }
    pub fn is_empty(&self) -> bool {
        self.verts.is_empty()
    }
    /// Number of selected vertices.
    pub fn count(&self) -> usize {
        self.verts.iter().filter(|&&b| b).count()
    }
    pub fn any(&self) -> bool {
        self.verts.iter().any(|&b| b)
    }
    #[inline]
    pub fn is_selected(&self, v: u32) -> bool {
        self.verts.get(v as usize).copied().unwrap_or(false)
    }
    pub fn set(&mut self, v: u32, on: bool) {
        if let Some(s) = self.verts.get_mut(v as usize) {
            *s = on;
        }
    }
    pub fn select_all(&mut self) {
        self.verts.iter_mut().for_each(|b| *b = true);
    }
    pub fn clear(&mut self) {
        self.verts.iter_mut().for_each(|b| *b = false);
    }
    pub fn invert(&mut self) {
        self.verts.iter_mut().for_each(|b| *b = !*b);
    }
    /// Resize after a topology change; new vertices are unselected.
    pub fn resize(&mut self, n: usize) {
        self.verts.resize(n, false);
    }
    pub fn indices(&self) -> Vec<u32> {
        self.verts.iter().enumerate().filter(|(_, &b)| b).map(|(i, _)| i as u32).collect()
    }

    /// Faces whose every vertex is selected.
    pub fn face_mask(&self, mesh: &Mesh) -> Vec<bool> {
        (0..mesh.face_count()).map(|f| mesh.face_verts(f).iter().all(|&v| self.is_selected(v))).collect()
    }
    pub fn faces(&self, mesh: &Mesh) -> Vec<u32> {
        self.face_mask(mesh).iter().enumerate().filter(|(_, &b)| b).map(|(i, _)| i as u32).collect()
    }
    pub fn count_faces(&self, mesh: &Mesh) -> usize {
        self.face_mask(mesh).iter().filter(|&&b| b).count()
    }
    /// Edges whose two end vertices are selected.
    pub fn edge_mask(&self, topo: &Topology) -> Vec<bool> {
        topo.edges.iter().map(|e| self.is_selected(e[0]) && self.is_selected(e[1])).collect()
    }
    pub fn edges(&self, topo: &Topology) -> Vec<u32> {
        self.edge_mask(topo).iter().enumerate().filter(|(_, &b)| b).map(|(i, _)| i as u32).collect()
    }
    pub fn count_edges(&self, topo: &Topology) -> usize {
        self.edge_mask(topo).iter().filter(|&&b| b).count()
    }
    pub fn select_faces(&mut self, mesh: &Mesh, faces: &[u32]) {
        for &f in faces {
            if (f as usize) < mesh.face_count() {
                for &v in mesh.face_verts(f as usize) {
                    self.set(v, true);
                }
            }
        }
    }
    /// "Select more": add every vertex connected by an edge to a selected vertex.
    pub fn grow(&mut self, topo: &Topology) {
        let old = self.verts.clone();
        for e in &topo.edges {
            if old.get(e[0] as usize).copied().unwrap_or(false) || old.get(e[1] as usize).copied().unwrap_or(false) {
                self.set(e[0], true);
                self.set(e[1], true);
            }
        }
    }
    /// "Select less": deselect every vertex that has an unselected neighbour.
    pub fn shrink(&mut self, topo: &Topology) {
        let old = self.verts.clone();
        for e in &topo.edges {
            let (a, b) = (old.get(e[0] as usize).copied().unwrap_or(false), old.get(e[1] as usize).copied().unwrap_or(false));
            if a != b {
                self.set(e[0], false);
                self.set(e[1], false);
            }
        }
    }
    /// Flood-fill the selection across edges ("select linked").
    pub fn select_linked(&mut self, topo: &Topology) {
        let mut stack: Vec<u32> = self.indices();
        while let Some(v) = stack.pop() {
            for n in topo.vert_neighbors(v) {
                if !self.is_selected(n) {
                    self.set(n, true);
                    stack.push(n);
                }
            }
        }
    }
    /// Carry the selection through an old->new vertex map (`u32::MAX` = deleted).
    pub fn remap(&self, vert_map: &[u32], new_len: usize) -> Selection {
        if vert_map.is_empty() {
            let mut s = self.clone();
            s.resize(new_len);
            return s;
        }
        let mut out = Selection::none(new_len);
        for (old, &new) in vert_map.iter().enumerate() {
            if new != u32::MAX && self.is_selected(old as u32) {
                out.set(new, true);
            }
        }
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::mesh::tests_support::unit_cube;

    #[test]
    fn faces_and_edges_are_derived() {
        let m = unit_cube();
        let t = Topology::build(&m);
        let s = Selection::from_indices(8, [4, 5, 6, 7]); // the top face
        assert_eq!(s.faces(&m), vec![1]);
        assert_eq!(s.count_edges(&t), 4);
        assert_eq!(s.count(), 4);
        let mut g = s.clone();
        g.grow(&t);
        assert_eq!(g.count(), 8);
        g.shrink(&t);
        assert_eq!(g.count(), 8); // every edge has both ends selected -> nothing to shrink
        let mut l = Selection::from_indices(8, [0]);
        l.select_linked(&t);
        assert_eq!(l.count(), 8);
    }

    #[test]
    fn remap_and_invert() {
        let mut s = Selection::from_indices(4, [1, 3]);
        s.invert();
        assert_eq!(s.indices(), vec![0, 2]);
        let r = s.remap(&[0, u32::MAX, 1, 2], 3);
        assert_eq!(r.indices(), vec![0, 1]);
        assert!(!s.is_selected(99));
    }
}
