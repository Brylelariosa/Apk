//! forge-mesh: the shared polygon-mesh kernel of RustForge (data structure, topology, selection,
//! validation, clean-up, render buffers, cancellation/limits and small parallel helpers).
//!
//! Every geometry crate (`forge-geom`, `forge-csg`, `forge-io`, `forge-scene`, ...) builds on these types.
//! See docs/ARCHITECTURE.md for the conventions (Z-up, CCW outward, op results).
#![forbid(unsafe_code)]

mod ctx;
mod mesh;
pub mod par;
mod render;
mod selection;
mod topology;
pub mod tri;
mod validate;
mod weld;

pub use ctx::{CancelToken, GeomError, GeomResult, OpCtx, OpLimits, OpOutput};
pub use mesh::Mesh;
pub use render::{RenderBuffers, RenderVertex, SubMesh, VertexCorners};
pub use selection::Selection;
pub use topology::{Csr, Topology, NONE};
pub use validate::{validate, ValidationReport};
pub use weld::{compact_unused, remove_degenerate_faces, retain_faces, weld_vertices, CleanupMap};
