//! Polygon triangulation (quads: best diagonal; n-gons: convex fan or ear clipping).
use forge_math::{Vec2, Vec3};

/// Triangulate a polygon given by its positions; appends **local** index triples (0..pts.len()).
/// Preserves the winding of the input. Never loops forever and falls back to a fan on degenerate input.
pub fn triangulate_polygon(pts: &[Vec3], out: &mut Vec<[u32; 3]>) {
    let n = pts.len();
    match n {
        0..=2 => return,
        3 => {
            out.push([0, 1, 2]);
            return;
        }
        4 => {
            quad(pts, out);
            return;
        }
        _ => {}
    }
    // Newell normal and projection to the dominant plane
    let mut nrm = Vec3::ZERO;
    for i in 0..n {
        let a = pts[i];
        let b = pts[(i + 1) % n];
        nrm.x += (a.y - b.y) * (a.z + b.z);
        nrm.y += (a.z - b.z) * (a.x + b.x);
        nrm.z += (a.x - b.x) * (a.y + b.y);
    }
    if nrm.length_squared() < 1e-30 {
        fan(n, out);
        return;
    }
    let axis = nrm.max_abs_axis();
    let (iu, iv) = match axis {
        0 => (1, 2),
        1 => (2, 0),
        _ => (0, 1),
    };
    let flip = nrm[axis] < 0.0;
    let p2: Vec<Vec2> = pts
        .iter()
        .map(|p| {
            let u = p[iu];
            Vec2::new(if flip { -u } else { u }, p[iv])
        })
        .collect();

    // Convex polygons (circles, caps) are a plain fan: O(n).
    let mut convex = true;
    for i in 0..n {
        let (a, b, c) = (p2[i], p2[(i + 1) % n], p2[(i + 2) % n]);
        if (b - a).perp_dot(c - b) < -1e-9 {
            convex = false;
            break;
        }
    }
    if convex || n > 2000 {
        fan(n, out);
        return;
    }

    let mut idx: Vec<usize> = (0..n).collect();
    let mut guard = 0usize;
    while idx.len() > 3 && guard < n * n + 16 {
        guard += 1;
        let m = idx.len();
        let mut clipped = false;
        for k in 0..m {
            let (i0, i1, i2) = (idx[(k + m - 1) % m], idx[k], idx[(k + 1) % m]);
            let (a, b, c) = (p2[i0], p2[i1], p2[i2]);
            let area2 = (b - a).perp_dot(c - a);
            if area2 <= 1e-12 {
                continue;
            }
            let mut blocked = false;
            for &j in &idx {
                if j == i0 || j == i1 || j == i2 {
                    continue;
                }
                let p = p2[j];
                if p == a || p == b || p == c {
                    continue;
                }
                if in_triangle(p, a, b, c) {
                    blocked = true;
                    break;
                }
            }
            if blocked {
                continue;
            }
            out.push([i0 as u32, i1 as u32, i2 as u32]);
            idx.remove(k);
            clipped = true;
            break;
        }
        if !clipped {
            // degenerate polygon (collinear runs / self touching): fan the remainder
            for k in 1..idx.len() - 1 {
                out.push([idx[0] as u32, idx[k] as u32, idx[k + 1] as u32]);
            }
            return;
        }
    }
    if idx.len() == 3 {
        out.push([idx[0] as u32, idx[1] as u32, idx[2] as u32]);
    } else if idx.len() > 3 {
        for k in 1..idx.len() - 1 {
            out.push([idx[0] as u32, idx[k] as u32, idx[k + 1] as u32]);
        }
    }
}

fn fan(n: usize, out: &mut Vec<[u32; 3]>) {
    for k in 1..n - 1 {
        out.push([0, k as u32, k as u32 + 1]);
    }
}

fn in_triangle(p: Vec2, a: Vec2, b: Vec2, c: Vec2) -> bool {
    let d1 = (b - a).perp_dot(p - a);
    let d2 = (c - b).perp_dot(p - b);
    let d3 = (a - c).perp_dot(p - c);
    d1 >= -1e-12 && d2 >= -1e-12 && d3 >= -1e-12
}

fn quad(p: &[Vec3], out: &mut Vec<[u32; 3]>) {
    let n = (p[2] - p[0]).cross(p[3] - p[1]);
    let good = |a: Vec3, b: Vec3, c: Vec3| (b - a).cross(c - a).dot(n) > 0.0;
    let a_ok = good(p[0], p[1], p[2]) && good(p[0], p[2], p[3]);
    let b_ok = good(p[0], p[1], p[3]) && good(p[1], p[2], p[3]);
    let use_a = match (a_ok, b_ok) {
        (true, true) => (p[2] - p[0]).length_squared() <= (p[3] - p[1]).length_squared(),
        (true, false) => true,
        (false, true) => false,
        (false, false) => true,
    };
    if use_a {
        out.push([0, 1, 2]);
        out.push([0, 2, 3]);
    } else {
        out.push([0, 1, 3]);
        out.push([1, 2, 3]);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn area(pts: &[Vec3], tris: &[[u32; 3]]) -> f32 {
        tris.iter().map(|t| (pts[t[1] as usize] - pts[t[0] as usize]).cross(pts[t[2] as usize] - pts[t[0] as usize]).z * 0.5).sum()
    }

    #[test]
    fn concave_l_shape_area_is_preserved() {
        let l = [(0., 0.), (2., 0.), (2., 1.), (1., 1.), (1., 2.), (0., 2.)];
        let pts: Vec<Vec3> = l.iter().map(|&(x, y)| Vec3::new(x, y, 0.0)).collect();
        let mut t = Vec::new();
        triangulate_polygon(&pts, &mut t);
        assert_eq!(t.len(), 4);
        assert!((area(&pts, &t) - 3.0).abs() < 1e-5);
        // every triangle keeps CCW orientation
        assert!(t.iter().all(|t| (pts[t[1] as usize] - pts[t[0] as usize]).cross(pts[t[2] as usize] - pts[t[0] as usize]).z > 0.0));
    }

    #[test]
    fn clockwise_input_keeps_its_winding() {
        let l = [(0., 0.), (0., 2.), (1., 2.), (1., 1.), (2., 1.), (2., 0.)];
        let pts: Vec<Vec3> = l.iter().map(|&(x, y)| Vec3::new(x, y, 0.0)).collect();
        let mut t = Vec::new();
        triangulate_polygon(&pts, &mut t);
        assert_eq!(t.len(), 4);
        assert!((area(&pts, &t) + 3.0).abs() < 1e-5);
    }

    #[test]
    fn big_convex_cap_is_a_fan_and_degenerate_terminates() {
        let n = 3000;
        let pts: Vec<Vec3> = (0..n).map(|i| { let a = i as f32 / n as f32 * std::f32::consts::TAU; Vec3::new(a.cos(), a.sin(), 0.0) }).collect();
        let mut t = Vec::new();
        triangulate_polygon(&pts, &mut t);
        assert_eq!(t.len(), n - 2);
        // all points collinear
        let line: Vec<Vec3> = (0..8).map(|i| Vec3::new(i as f32, 0.0, 0.0)).collect();
        let mut t = Vec::new();
        triangulate_polygon(&line, &mut t);
        assert_eq!(t.len(), 6);
    }

    #[test]
    fn nonplanar_quad_uses_valid_diagonal() {
        let pts = [Vec3::new(0., 0., 0.), Vec3::new(1., 0., 0.), Vec3::new(1., 1., 0.), Vec3::new(0.5, 0.2, 0.0)];
        let mut t = Vec::new();
        triangulate_polygon(&pts, &mut t);
        assert_eq!(t.len(), 2);
        assert!(area(&pts, &t) > 0.0);
    }
}
