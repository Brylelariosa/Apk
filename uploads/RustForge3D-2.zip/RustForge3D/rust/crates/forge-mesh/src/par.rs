//! Minimal safe data-parallel helpers on `std::thread::scope` (stands in for rayon).
//! Use only for large jobs: every call spawns scoped threads.
use std::ops::Range;
use std::sync::atomic::{AtomicUsize, Ordering};

static MAX_THREADS: AtomicUsize = AtomicUsize::new(0);

/// Cap the number of worker threads (0 = automatic: `min(cores, 4)`, tuned for phones).
pub fn set_max_threads(n: usize) {
    MAX_THREADS.store(n, Ordering::Relaxed);
}
pub fn max_threads() -> usize {
    let n = MAX_THREADS.load(Ordering::Relaxed);
    if n > 0 {
        n
    } else {
        std::thread::available_parallelism().map(|v| v.get()).unwrap_or(1).min(4)
    }
}

fn plan(len: usize, min_chunk: usize) -> Option<usize> {
    let threads = max_threads();
    let min_chunk = min_chunk.max(1);
    if threads <= 1 || len < min_chunk * 2 {
        return None;
    }
    Some(len.div_ceil(threads).max(min_chunk))
}

/// Run `f(range)` over disjoint sub-ranges of `0..len` in parallel (sequentially when small).
pub fn parallel_for<F: Fn(Range<usize>) + Sync>(len: usize, min_chunk: usize, f: F) {
    match plan(len, min_chunk) {
        None => f(0..len),
        Some(chunk) => std::thread::scope(|s| {
            let f = &f;
            for start in (0..len).step_by(chunk) {
                let end = (start + chunk).min(len);
                s.spawn(move || f(start..end));
            }
        }),
    }
}

/// Map `0..len` through `f`, preserving order.
pub fn parallel_map<T: Send, F: Fn(usize) -> T + Sync>(len: usize, min_chunk: usize, f: F) -> Vec<T> {
    match plan(len, min_chunk) {
        None => (0..len).map(f).collect(),
        Some(chunk) => {
            let parts: Vec<Vec<T>> = std::thread::scope(|s| {
                let f = &f;
                let handles: Vec<_> = (0..len)
                    .step_by(chunk)
                    .map(|start| {
                        let end = (start + chunk).min(len);
                        s.spawn(move || (start..end).map(f).collect::<Vec<T>>())
                    })
                    .collect();
                handles.into_iter().map(|h| h.join().unwrap_or_else(|e| std::panic::resume_unwind(e))).collect()
            });
            let mut out = Vec::with_capacity(len);
            for p in parts {
                out.extend(p);
            }
            out
        }
    }
}

/// Process disjoint mutable chunks of `data`; `f(first_index, chunk)`.
pub fn parallel_chunks_mut<T: Send, F: Fn(usize, &mut [T]) + Sync>(data: &mut [T], min_chunk: usize, f: F) {
    match plan(data.len(), min_chunk) {
        None => f(0, data),
        Some(chunk) => std::thread::scope(|s| {
            let f = &f;
            for (i, part) in data.chunks_mut(chunk).enumerate() {
                s.spawn(move || f(i * chunk, part));
            }
        }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::atomic::AtomicU64;

    #[test]
    fn map_preserves_order_and_covers_all() {
        let v = parallel_map(100_000, 1000, |i| i * 2);
        assert_eq!(v.len(), 100_000);
        assert!(v.iter().enumerate().all(|(i, x)| *x == i * 2));
        assert_eq!(parallel_map(3, 1000, |i| i), vec![0, 1, 2]);
    }
    #[test]
    fn for_and_chunks() {
        let sum = AtomicU64::new(0);
        parallel_for(50_000, 100, |r| {
            sum.fetch_add(r.map(|i| i as u64).sum::<u64>(), Ordering::Relaxed);
        });
        assert_eq!(sum.load(Ordering::Relaxed), (0..50_000u64).sum());
        let mut data = vec![0u32; 20_000];
        parallel_chunks_mut(&mut data, 100, |first, part| {
            for (k, x) in part.iter_mut().enumerate() {
                *x = (first + k) as u32;
            }
        });
        assert!(data.iter().enumerate().all(|(i, x)| *x == i as u32));
    }
}
