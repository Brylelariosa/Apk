//! Cancellation, size limits, errors and the common operation result.
use crate::selection::Selection;
use std::fmt;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

/// Cooperative cancellation flag shared between the UI thread and long-running geometry work.
#[derive(Clone, Debug, Default)]
pub struct CancelToken(Arc<AtomicBool>);

impl CancelToken {
    pub fn new() -> CancelToken {
        CancelToken(Arc::new(AtomicBool::new(false)))
    }
    pub fn cancel(&self) {
        self.0.store(true, Ordering::Relaxed);
    }
    pub fn reset(&self) {
        self.0.store(false, Ordering::Relaxed);
    }
    #[inline]
    pub fn is_cancelled(&self) -> bool {
        self.0.load(Ordering::Relaxed)
    }
    #[inline]
    pub fn check(&self) -> GeomResult<()> {
        if self.is_cancelled() {
            Err(GeomError::Cancelled)
        } else {
            Ok(())
        }
    }
    /// The underlying flag, for embedding in other cancellation schemes (e.g. the interpreter).
    pub fn flag(&self) -> Arc<AtomicBool> {
        self.0.clone()
    }
}

/// Upper bounds an operation must respect *before* allocating its output.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct OpLimits {
    pub max_vertices: usize,
    pub max_faces: usize,
}
impl Default for OpLimits {
    fn default() -> Self {
        OpLimits { max_vertices: 2_000_000, max_faces: 2_000_000 }
    }
}

/// Context passed to every potentially expensive operation.
#[derive(Clone, Debug, Default)]
pub struct OpCtx {
    pub cancel: CancelToken,
    pub limits: OpLimits,
}

impl OpCtx {
    pub fn new() -> OpCtx {
        OpCtx::default()
    }
    pub fn with_cancel(cancel: CancelToken) -> OpCtx {
        OpCtx { cancel, limits: OpLimits::default() }
    }
    #[inline]
    pub fn check(&self) -> GeomResult<()> {
        self.cancel.check()
    }
    /// Cheap poll for hot loops: only touches the atomic every 1024 iterations.
    #[inline]
    pub fn poll(&self, i: usize) -> GeomResult<()> {
        if i & 0x3ff == 0 {
            self.cancel.check()
        } else {
            Ok(())
        }
    }
    /// Fail if producing `verts`/`faces` elements would exceed the configured limits.
    pub fn ensure_capacity(&self, verts: usize, faces: usize) -> GeomResult<()> {
        if verts > self.limits.max_vertices {
            return Err(GeomError::LimitExceeded { what: "vertices", requested: verts, limit: self.limits.max_vertices });
        }
        if faces > self.limits.max_faces {
            return Err(GeomError::LimitExceeded { what: "faces", requested: faces, limit: self.limits.max_faces });
        }
        Ok(())
    }
}

#[derive(Clone, Debug, PartialEq)]
pub enum GeomError {
    Cancelled,
    LimitExceeded { what: &'static str, requested: usize, limit: usize },
    InvalidInput(String),
    Unsupported(String),
    Degenerate(String),
}
pub type GeomResult<T> = Result<T, GeomError>;

impl fmt::Display for GeomError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            GeomError::Cancelled => write!(f, "operation cancelled"),
            GeomError::LimitExceeded { what, requested, limit } => {
                write!(f, "too many {what}: operation would create {requested} (limit {limit})")
            }
            GeomError::InvalidInput(m) => write!(f, "invalid input: {m}"),
            GeomError::Unsupported(m) => write!(f, "unsupported: {m}"),
            GeomError::Degenerate(m) => write!(f, "degenerate geometry: {m}"),
        }
    }
}
impl std::error::Error for GeomError {}

/// Result of a topology-changing operation (see docs/ARCHITECTURE.md "Op result convention").
#[derive(Clone, Debug, Default, PartialEq)]
pub struct OpOutput {
    /// Vertex selection after the operation (normally the newly created geometry).
    pub selection: Selection,
    /// Indices (in the output mesh) of created vertices / faces.
    pub new_verts: Vec<u32>,
    pub new_faces: Vec<u32>,
    /// Old index -> new index, `u32::MAX` when deleted. Empty = identity mapping.
    pub vert_map: Vec<u32>,
    pub face_map: Vec<u32>,
}

impl OpOutput {
    pub fn with_selection(selection: Selection) -> OpOutput {
        OpOutput { selection, ..Default::default() }
    }
    pub fn map_vert(&self, v: u32) -> Option<u32> {
        if self.vert_map.is_empty() {
            Some(v)
        } else {
            self.vert_map.get(v as usize).copied().filter(|n| *n != u32::MAX)
        }
    }
    pub fn map_face(&self, f: u32) -> Option<u32> {
        if self.face_map.is_empty() {
            Some(f)
        } else {
            self.face_map.get(f as usize).copied().filter(|n| *n != u32::MAX)
        }
    }
}
