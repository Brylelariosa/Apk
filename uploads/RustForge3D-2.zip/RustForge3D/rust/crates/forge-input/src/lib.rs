//! forge-input: touch/stylus handling for the 3D viewport. Pure logic, no platform types.
//!
//! * [`Camera`]: turntable camera (Z-up), projection, picking rays, view presets.
//! * [`Gestures`]: raw pointer batches -> taps, drags, long presses, two-finger navigation.
//! * [`gizmo`]: move / rotate / scale handles: drawing, hit testing and drag sessions.
#![forbid(unsafe_code)]

pub mod camera;
pub mod gestures;
pub mod gizmo;
mod touch;

pub use camera::{Camera, ViewPreset};
pub use gestures::{Event, Gestures, PointerKind};
pub use gizmo::{Delta, DragSession, GizmoDraw, GizmoFrame, GizmoKind, GizmoVertex, Handle, Snap, Style};
pub use touch::{TouchBatch, TouchPointer, TOOL_ERASER, TOOL_FINGER, TOOL_MOUSE, TOOL_STYLUS};
