//! Transform gizmo: drawing, hit testing and drag sessions for move / rotate / scale handles.
//!
//! The gizmo keeps a constant size on screen. Drag sessions work in screen space for axis handles (stable even when
//! an axis points almost at the camera) and with ray/plane intersections for plane and free moves. All results are
//! *totals since the drag began*, so the caller applies them to the snapshot taken at `begin`.
use crate::camera::Camera;
use forge_math::{Plane, Vec3};
use std::f32::consts::{PI, TAU};

const AXIS_COLORS: [[f32; 4]; 3] = [[0.93, 0.27, 0.32, 1.0], [0.55, 0.82, 0.22, 1.0], [0.28, 0.52, 0.98, 1.0]];
const HOT: [f32; 4] = [1.0, 0.86, 0.25, 1.0];
const NEUTRAL: [f32; 4] = [0.88, 0.88, 0.92, 1.0];
const RING_N: usize = 72;
const PLANE_LO: f32 = 0.28;
const PLANE_HI: f32 = 0.6;
const RING_R: f32 = 0.85;
const VIEW_R: f32 = 1.12;
const EDGE_ON_PLANE: f32 = 0.25;
const EDGE_ON_RING: f32 = 0.12;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GizmoKind {
    Move,
    Rotate,
    Scale,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Handle {
    /// Axis `0..3` of the gizmo frame (move/scale: the arrow; rotate: the ring around it).
    Axis(u8),
    /// Move only: the plane whose *normal* is the given axis.
    Plane(u8),
    /// Move: free move in the screen plane. Scale: uniform scale.
    Center,
    /// Rotate: the outer ring that rotates about the view axis.
    View,
}

impl Handle {
    /// Which frame axes the handle affects (for numeric input and display).
    pub fn constraint(self) -> [bool; 3] {
        match self {
            Handle::Axis(i) => {
                let mut c = [false; 3];
                c[i as usize % 3] = true;
                c
            }
            Handle::Plane(i) => {
                let mut c = [true; 3];
                c[i as usize % 3] = false;
                c
            }
            _ => [true; 3],
        }
    }
}

/// Placement and orientation (orthonormal `axes` in world space).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct GizmoFrame {
    pub origin: Vec3,
    pub axes: [Vec3; 3],
}

impl GizmoFrame {
    pub fn world(origin: Vec3) -> GizmoFrame {
        GizmoFrame { origin, axes: [Vec3::X, Vec3::Y, Vec3::Z] }
    }
}

/// Sizes in pixels.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Style {
    pub size_px: f32,
    pub pick_px: f32,
    pub line_px: f32,
    pub head_px: f32,
}

impl Style {
    pub fn for_density(density: f32) -> Style {
        let d = density.max(0.5);
        Style { size_px: 88.0 * d, pick_px: 22.0 * d, line_px: 2.5 * d, head_px: 13.0 * d }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct GizmoVertex {
    pub pos: [f32; 3],
    pub color: [f32; 4],
}

/// Geometry to draw on top of the scene: `tris` is a triangle list (thick lines are ribbons), `lines` a 1 px line list.
#[derive(Clone, Debug, Default)]
pub struct GizmoDraw {
    pub lines: Vec<GizmoVertex>,
    pub tris: Vec<GizmoVertex>,
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Snap {
    pub enabled: bool,
    /// World units.
    pub translate: f32,
    /// Radians.
    pub rotate: f32,
    /// Factor increment.
    pub scale: f32,
}

/// Total transform since the drag began.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Delta {
    Translate(Vec3),
    /// Rotation about a unit world axis through the gizmo origin.
    Rotate { axis: Vec3, angle: f32 },
    /// Scale factors along the frame axes, about the gizmo origin.
    Scale(Vec3),
}

struct Layout {
    o: [f32; 2],
    scale: f32,
    len: f32,
    /// Unit vector from the eye through the gizmo origin.
    view: Vec3,
}

fn layout(f: &GizmoFrame, cam: &Camera, st: &Style) -> Option<Layout> {
    let o = cam.project_px(f.origin)?;
    let scale = cam.pixel_scale_at(f.origin);
    let view = if cam.ortho { cam.forward() } else { (f.origin - cam.eye()).normalize() };
    Some(Layout { o, scale, len: scale * st.size_px, view })
}

fn dist(a: [f32; 2], b: [f32; 2]) -> f32 {
    ((a[0] - b[0]).powi(2) + (a[1] - b[1]).powi(2)).sqrt()
}

fn dist_seg(p: [f32; 2], a: [f32; 2], b: [f32; 2]) -> f32 {
    let (abx, aby) = (b[0] - a[0], b[1] - a[1]);
    let l2 = abx * abx + aby * aby;
    let t = if l2 < 1e-9 { 0.0 } else { (((p[0] - a[0]) * abx + (p[1] - a[1]) * aby) / l2).clamp(0.0, 1.0) };
    dist(p, [a[0] + abx * t, a[1] + aby * t])
}

fn in_quad(p: [f32; 2], q: &[[f32; 2]; 4]) -> bool {
    let (mut pos, mut neg) = (false, false);
    for i in 0..4 {
        let (a, b) = (q[i], q[(i + 1) % 4]);
        let c = (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0]);
        if c > 0.0 {
            pos = true;
        } else if c < 0.0 {
            neg = true;
        }
    }
    !(pos && neg)
}

fn wrap(a: f32) -> f32 {
    a - TAU * ((a + PI) / TAU).floor()
}

fn snapv(v: f32, step: f32, enabled: bool) -> f32 {
    if enabled && step > 0.0 {
        (v / step).round() * step
    } else {
        v
    }
}

fn ring_basis(f: &GizmoFrame, i: usize) -> (Vec3, Vec3) {
    (f.axes[(i + 1) % 3], f.axes[(i + 2) % 3])
}

fn plane_corners(f: &GizmoFrame, lay: &Layout, i: usize) -> [Vec3; 4] {
    let (u, v) = ring_basis(f, i);
    let (lo, hi) = (PLANE_LO * lay.len, PLANE_HI * lay.len);
    [f.origin + u * lo + v * lo, f.origin + u * hi + v * lo, f.origin + u * hi + v * hi, f.origin + u * lo + v * hi]
}

/// Screen position of the arrow tip when it is long enough on screen to be usable.
fn axis_tip(f: &GizmoFrame, cam: &Camera, st: &Style, lay: &Layout, i: usize) -> Option<[f32; 2]> {
    let tip = cam.project_px(f.origin + f.axes[i] * lay.len)?;
    if dist(tip, lay.o) >= st.pick_px * 0.6 {
        Some(tip)
    } else {
        None
    }
}

// ---------------------------------------------------------------------------------------------------------------
// drawing

fn tint(base: [f32; 4], h: Handle, active: Option<Handle>) -> [f32; 4] {
    match active {
        Some(a) if a == h => HOT,
        Some(_) => [base[0], base[1], base[2], base[3] * 0.3],
        None => base,
    }
}

fn push_quad(out: &mut Vec<GizmoVertex>, p: [Vec3; 4], color: [f32; 4]) {
    for i in [0usize, 1, 2, 0, 2, 3] {
        out.push(GizmoVertex { pos: p[i].to_array(), color });
    }
}

/// Constant pixel width line as a camera-facing quad.
fn ribbon(cam: &Camera, a: Vec3, b: Vec3, width_px: f32, color: [f32; 4], out: &mut Vec<GizmoVertex>) {
    let va = if cam.ortho { cam.forward() } else { (a - cam.eye()).normalize() };
    let n = (b - a).cross(va);
    if n.length_squared() < 1e-14 {
        return;
    }
    let n = n.normalize();
    let (wa, wb) = (cam.pixel_scale_at(a) * width_px * 0.5, cam.pixel_scale_at(b) * width_px * 0.5);
    push_quad(out, [a + n * wa, a - n * wa, b - n * wb, b + n * wb], color);
}

fn billboard(cam: &Camera, c: Vec3, half_px: f32, color: [f32; 4], out: &mut Vec<GizmoVertex>) {
    let h = cam.pixel_scale_at(c) * half_px;
    let (r, u) = (cam.right() * h, cam.up() * h);
    push_quad(out, [c - r - u, c + r - u, c + r + u, c - r + u], color);
}

fn cone(base: Vec3, apex: Vec3, radius: f32, color: [f32; 4], out: &mut Vec<GizmoVertex>) {
    let axis = (apex - base).normalize();
    let u = axis.any_orthogonal().normalize();
    let v = axis.cross(u);
    let n = 12;
    let mut prev = base + u * radius;
    for k in 1..=n {
        let th = k as f32 / n as f32 * TAU;
        let p = base + (u * th.cos() + v * th.sin()) * radius;
        for q in [apex, prev, p] {
            out.push(GizmoVertex { pos: q.to_array(), color });
        }
        prev = p;
    }
}

pub fn draw(kind: GizmoKind, f: &GizmoFrame, cam: &Camera, st: &Style, active: Option<Handle>, out: &mut GizmoDraw) {
    let Some(lay) = layout(f, cam, st) else { return };
    match kind {
        GizmoKind::Move | GizmoKind::Scale => {
            let moving = kind == GizmoKind::Move;
            let head_len = lay.scale * st.head_px * 1.9;
            let head_r = lay.scale * st.head_px * 0.55;
            for i in 0..3 {
                if axis_tip(f, cam, st, &lay, i).is_none() {
                    continue;
                }
                let col = tint(AXIS_COLORS[i], Handle::Axis(i as u8), active);
                let tip = f.origin + f.axes[i] * lay.len;
                if moving {
                    let neck = tip - f.axes[i] * head_len;
                    ribbon(cam, f.origin, neck, st.line_px, col, &mut out.tris);
                    cone(neck, tip, head_r, col, &mut out.tris);
                } else {
                    ribbon(cam, f.origin, tip, st.line_px, col, &mut out.tris);
                    billboard(cam, tip, st.head_px * 0.55, col, &mut out.tris);
                }
            }
            if moving {
                for i in 0..3 {
                    if f.axes[i].dot(lay.view).abs() < EDGE_ON_PLANE {
                        continue;
                    }
                    let c = plane_corners(f, &lay, i);
                    let col = tint(AXIS_COLORS[i], Handle::Plane(i as u8), active);
                    push_quad(&mut out.tris, c, [col[0], col[1], col[2], col[3] * 0.4]);
                    for k in 0..4 {
                        ribbon(cam, c[k], c[(k + 1) % 4], st.line_px * 0.5, col, &mut out.tris);
                    }
                }
            }
            let half = if moving { st.head_px * 0.5 } else { st.head_px * 0.8 };
            billboard(cam, f.origin, half, tint(NEUTRAL, Handle::Center, active), &mut out.tris);
        }
        GizmoKind::Rotate => {
            let r = lay.len * RING_R;
            for i in 0..3 {
                if f.axes[i].dot(lay.view).abs() < EDGE_ON_RING {
                    continue;
                }
                let (u, v) = ring_basis(f, i);
                let col = tint(AXIS_COLORS[i], Handle::Axis(i as u8), active);
                let at = |k: usize| {
                    let th = k as f32 / RING_N as f32 * TAU;
                    (u * th.cos() + v * th.sin()) * r
                };
                for k in 0..RING_N {
                    let (a, b) = (at(k), at(k + 1));
                    let front = (a + b).dot(lay.view) < 0.3 * r;
                    if front {
                        ribbon(cam, f.origin + a, f.origin + b, st.line_px, col, &mut out.tris);
                    } else {
                        let dim = [col[0], col[1], col[2], col[3] * 0.25];
                        out.lines.push(GizmoVertex { pos: (f.origin + a).to_array(), color: dim });
                        out.lines.push(GizmoVertex { pos: (f.origin + b).to_array(), color: dim });
                    }
                }
            }
            let (rv, uv) = (cam.right(), cam.up());
            let rr = lay.len * VIEW_R;
            let col = tint(NEUTRAL, Handle::View, active);
            let at = |k: usize| {
                let th = k as f32 / RING_N as f32 * TAU;
                f.origin + (rv * th.cos() + uv * th.sin()) * rr
            };
            for k in 0..RING_N {
                ribbon(cam, at(k), at(k + 1), st.line_px * 0.8, col, &mut out.tris);
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// hit testing

/// Handle under a screen position, if any.
pub fn pick(kind: GizmoKind, f: &GizmoFrame, cam: &Camera, st: &Style, pos: [f32; 2]) -> Option<Handle> {
    let lay = layout(f, cam, st)?;
    match kind {
        GizmoKind::Move | GizmoKind::Scale => {
            if dist(pos, lay.o) <= st.pick_px * 0.65 {
                return Some(Handle::Center);
            }
            if kind == GizmoKind::Move {
                for i in 0..3 {
                    if f.axes[i].dot(lay.view).abs() < EDGE_ON_PLANE {
                        continue;
                    }
                    let c = plane_corners(f, &lay, i);
                    let mut q = [[0.0f32; 2]; 4];
                    let mut ok = true;
                    for k in 0..4 {
                        match cam.project_px(c[k]) {
                            Some(p) => q[k] = p,
                            None => ok = false,
                        }
                    }
                    if ok && in_quad(pos, &q) {
                        return Some(Handle::Plane(i as u8));
                    }
                }
            }
            let mut best: Option<(f32, Handle)> = None;
            for i in 0..3 {
                if let Some(tip) = axis_tip(f, cam, st, &lay, i) {
                    let d = dist_seg(pos, lay.o, tip);
                    if d <= st.pick_px && best.map_or(true, |(b, _)| d < b) {
                        best = Some((d, Handle::Axis(i as u8)));
                    }
                }
            }
            best.map(|(_, h)| h)
        }
        GizmoKind::Rotate => {
            let r = lay.len * RING_R;
            let mut best: Option<(f32, Handle)> = None;
            for i in 0..3 {
                if f.axes[i].dot(lay.view).abs() < EDGE_ON_RING {
                    continue;
                }
                let (u, v) = ring_basis(f, i);
                let mut prev: Option<[f32; 2]> = None;
                for k in 0..=RING_N {
                    let th = k as f32 / RING_N as f32 * TAU;
                    let w = (u * th.cos() + v * th.sin()) * r;
                    let front = w.dot(lay.view) < 0.15 * r;
                    let cur = if front { cam.project_px(f.origin + w) } else { None };
                    if let (Some(a), Some(b)) = (prev, cur) {
                        let d = dist_seg(pos, a, b);
                        if d <= st.pick_px && best.map_or(true, |(bd, _)| d < bd) {
                            best = Some((d, Handle::Axis(i as u8)));
                        }
                    }
                    prev = cur;
                }
            }
            let dv = (dist(pos, lay.o) - st.size_px * VIEW_R).abs();
            if dv <= st.pick_px && best.map_or(true, |(bd, _)| dv < bd) {
                best = Some((dv, Handle::View));
            }
            best.map(|(_, h)| h)
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------
// drag sessions

#[derive(Clone, Debug)]
pub struct DragSession {
    pub kind: GizmoKind,
    pub handle: Handle,
    pub frame: GizmoFrame,
    cam: Camera,
    start: [f32; 2],
    len: f32,
    size_px: f32,
    axis_px: [f32; 2],
    normal: Vec3,
    start_hit: Vec3,
    tangent: [f32; 2],
    rad_per_px: f32,
    origin_px: [f32; 2],
    last_angle: f32,
    accum: f32,
}

impl DragSession {
    pub fn begin(kind: GizmoKind, handle: Handle, frame: &GizmoFrame, cam: &Camera, st: &Style, start: [f32; 2]) -> Option<DragSession> {
        let lay = layout(frame, cam, st)?;
        let mut s = DragSession {
            kind,
            handle,
            frame: *frame,
            cam: cam.clone(),
            start,
            len: lay.len,
            size_px: st.size_px,
            axis_px: [0.0; 2],
            normal: Vec3::Z,
            start_hit: frame.origin,
            tangent: [0.0; 2],
            rad_per_px: 0.0,
            origin_px: lay.o,
            last_angle: 0.0,
            accum: 0.0,
        };
        match (kind, handle) {
            (GizmoKind::Move | GizmoKind::Scale, Handle::Axis(i)) => {
                let tip = cam.project_px(frame.origin + frame.axes[i as usize % 3] * lay.len)?;
                s.axis_px = [tip[0] - lay.o[0], tip[1] - lay.o[1]];
            }
            (GizmoKind::Move, Handle::Plane(i)) => {
                s.normal = frame.axes[i as usize % 3];
                s.start_hit = s.hit(start)?;
            }
            (GizmoKind::Move, Handle::Center) => {
                s.normal = cam.forward();
                s.start_hit = s.hit(start)?;
            }
            (GizmoKind::Scale, Handle::Center) => {}
            (GizmoKind::Rotate, Handle::Axis(i)) => {
                let (u, v) = ring_basis(frame, i as usize % 3);
                let r = lay.len * RING_R;
                let mut best = (f32::MAX, 0.0f32);
                for k in 0..RING_N {
                    let th = k as f32 / RING_N as f32 * TAU;
                    if let Some(q) = cam.project_px(frame.origin + (u * th.cos() + v * th.sin()) * r) {
                        let d = dist(q, start);
                        if d < best.0 {
                            best = (d, th);
                        }
                    }
                }
                let th = best.1;
                let p0 = frame.origin + (u * th.cos() + v * th.sin()) * r;
                let t = u * -th.sin() + v * th.cos();
                let eps = r * 0.05;
                let (a, b) = (cam.project_px(p0)?, cam.project_px(p0 + t * eps)?);
                let d = [b[0] - a[0], b[1] - a[1]];
                let sl = (d[0] * d[0] + d[1] * d[1]).sqrt();
                if sl > 1e-4 {
                    s.tangent = [d[0] / sl, d[1] / sl];
                    s.rad_per_px = ((eps / r) / sl).min(3.0 / (st.size_px * RING_R));
                }
            }
            (GizmoKind::Rotate, Handle::View) => {
                s.last_angle = (start[1] - lay.o[1]).atan2(start[0] - lay.o[0]);
            }
            _ => return None,
        }
        Some(s)
    }

    fn hit(&self, px: [f32; 2]) -> Option<Vec3> {
        let plane = Plane::from_point_normal(self.frame.origin, self.normal);
        let ray = self.cam.ray(px[0], px[1]);
        let t = ray.intersect_plane(&plane)?;
        Some(ray.at(t))
    }

    /// World distance along the axis handle that the pointer movement `d` corresponds to.
    fn along(&self, d: [f32; 2]) -> f32 {
        let l2 = self.axis_px[0] * self.axis_px[0] + self.axis_px[1] * self.axis_px[1];
        if l2 < 1.0 {
            0.0
        } else {
            (d[0] * self.axis_px[0] + d[1] * self.axis_px[1]) / l2 * self.len
        }
    }

    fn snap_vec(&self, d: Vec3, snap: &Snap) -> Vec3 {
        if !snap.enabled || snap.translate <= 0.0 {
            return d;
        }
        let mut out = Vec3::ZERO;
        for a in self.frame.axes {
            out = out + a * snapv(d.dot(a), snap.translate, true);
        }
        out
    }

    pub fn update(&mut self, pos: [f32; 2], snap: &Snap) -> Delta {
        let d = [pos[0] - self.start[0], pos[1] - self.start[1]];
        match (self.kind, self.handle) {
            (GizmoKind::Move, Handle::Axis(i)) => {
                let t = snapv(self.along(d), snap.translate, snap.enabled);
                Delta::Translate(self.frame.axes[i as usize % 3] * t)
            }
            (GizmoKind::Move, _) => {
                let delta = self.hit(pos).map_or(Vec3::ZERO, |h| h - self.start_hit);
                Delta::Translate(self.snap_vec(delta, snap))
            }
            (GizmoKind::Scale, Handle::Axis(i)) => {
                let f = nonzero(snapv(1.0 + self.along(d) / self.len, snap.scale, snap.enabled));
                let mut s = [1.0f32; 3];
                s[i as usize % 3] = f;
                Delta::Scale(Vec3::new(s[0], s[1], s[2]))
            }
            (GizmoKind::Scale, _) => {
                let f = nonzero(snapv(1.0 + (d[0] - d[1]) * 0.5 / self.size_px, snap.scale, snap.enabled));
                Delta::Scale(Vec3::new(f, f, f))
            }
            (GizmoKind::Rotate, Handle::View) => {
                let now = (pos[1] - self.origin_px[1]).atan2(pos[0] - self.origin_px[0]);
                self.accum += wrap(now - self.last_angle);
                self.last_angle = now;
                // screen y points down, so a clockwise screen angle is a negative turn about the axis towards the viewer
                Delta::Rotate { axis: self.cam.forward() * -1.0, angle: snapv(-self.accum, snap.rotate, snap.enabled) }
            }
            (GizmoKind::Rotate, h) => {
                let i = if let Handle::Axis(i) = h { i as usize % 3 } else { 2 };
                let a = (d[0] * self.tangent[0] + d[1] * self.tangent[1]) * self.rad_per_px;
                Delta::Rotate { axis: self.frame.axes[i], angle: snapv(a, snap.rotate, snap.enabled) }
            }
        }
    }
}

fn nonzero(f: f32) -> f32 {
    if f.abs() < 1e-4 {
        1e-4f32.copysign(if f == 0.0 { 1.0 } else { f })
    } else {
        f
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::camera::ViewPreset;

    fn cam(preset: ViewPreset) -> Camera {
        let mut c = Camera { target: Vec3::ZERO, distance: 10.0, ortho: true, ..Camera::default() };
        c.set_viewport(1000.0, 1000.0);
        c.set_preset(preset);
        c
    }
    fn style() -> Style {
        Style { size_px: 100.0, pick_px: 20.0, line_px: 3.0, head_px: 12.0 }
    }
    fn px_scale(c: &Camera) -> f32 {
        c.ortho_height() / c.height
    }
    const SNAP_OFF: Snap = Snap { enabled: false, translate: 0.0, rotate: 0.0, scale: 0.0 };

    #[test]
    fn move_handles_are_picked_where_they_are_drawn() {
        let (c, f, st) = (cam(ViewPreset::Front), GizmoFrame::world(Vec3::ZERO), style());
        let p = |x: f32, y: f32| pick(GizmoKind::Move, &f, &c, &st, [x, y]);
        assert_eq!(p(560.0, 500.0), Some(Handle::Axis(0)));
        assert_eq!(p(500.0, 440.0), Some(Handle::Axis(2)));
        assert_eq!(p(545.0, 455.0), Some(Handle::Plane(1)));
        assert_eq!(p(505.0, 497.0), Some(Handle::Center));
        assert_eq!(p(800.0, 800.0), None);
        // the Y arrow points into the screen and cannot be grabbed
        assert!(!matches!(p(500.0, 500.0 + 40.0), Some(Handle::Axis(1))));
        assert_eq!(pick(GizmoKind::Scale, &f, &c, &st, [560.0, 500.0]), Some(Handle::Axis(0)));
    }

    #[test]
    fn axis_move_follows_the_finger_and_snaps() {
        let (c, f, st) = (cam(ViewPreset::Front), GizmoFrame::world(Vec3::ZERO), style());
        let mut s = DragSession::begin(GizmoKind::Move, Handle::Axis(0), &f, &c, &st, [560.0, 500.0]).unwrap();
        let want = 100.0 * px_scale(&c);
        match s.update([660.0, 530.0], &SNAP_OFF) {
            Delta::Translate(t) => assert!((t.x - want).abs() < 1e-4 && t.y.abs() < 1e-6 && t.z.abs() < 1e-6, "{t:?}"),
            d => panic!("{d:?}"),
        }
        let snap = Snap { enabled: true, translate: 0.25, rotate: 0.0, scale: 0.0 };
        match s.update([660.0, 500.0], &snap) {
            Delta::Translate(t) => assert!((t.x - 0.75).abs() < 1e-5, "{t:?}"),
            d => panic!("{d:?}"),
        }
    }

    #[test]
    fn plane_move_stays_in_the_plane() {
        let (c, f, st) = (cam(ViewPreset::Top), GizmoFrame::world(Vec3::ZERO), style());
        let mut s = DragSession::begin(GizmoKind::Move, Handle::Plane(2), &f, &c, &st, [545.0, 455.0]).unwrap();
        let k = px_scale(&c);
        match s.update([595.0, 485.0], &SNAP_OFF) {
            Delta::Translate(t) => assert!((t.x - 50.0 * k).abs() < 1e-3 && (t.y + 30.0 * k).abs() < 1e-3 && t.z.abs() < 1e-4, "{t:?}"),
            d => panic!("{d:?}"),
        }
        let mut free = DragSession::begin(GizmoKind::Move, Handle::Center, &f, &c, &st, [500.0, 500.0]).unwrap();
        match free.update([520.0, 500.0], &SNAP_OFF) {
            Delta::Translate(t) => assert!((t.x - 20.0 * k).abs() < 1e-3),
            d => panic!("{d:?}"),
        }
        // perspective: the plane point under the finger is followed exactly
        let mut pc = Camera { target: Vec3::ZERO, distance: 10.0, ..Camera::default() };
        pc.set_viewport(1000.0, 1000.0);
        pc.set_preset(ViewPreset::Top);
        let mut ps = DragSession::begin(GizmoKind::Move, Handle::Center, &f, &pc, &st, [500.0, 500.0]).unwrap();
        if let Delta::Translate(t) = ps.update([600.0, 500.0], &SNAP_OFF) {
            let want = 0.2 * (0.5 * pc.fov_y).tan() * 10.0; // pixel 600 is 0.2 NDC right of centre, plane is 10 units away
            assert!((t.x - want).abs() < 1e-3 && t.y.abs() < 1e-4 && t.z.abs() < 1e-4, "{t:?} {want}");
        }
    }

    #[test]
    fn rotation_rings_and_view_ring() {
        let (c, f, st) = (cam(ViewPreset::Top), GizmoFrame::world(Vec3::ZERO), style());
        assert_eq!(pick(GizmoKind::Rotate, &f, &c, &st, [585.0, 500.0]), Some(Handle::Axis(2)));
        assert_eq!(pick(GizmoKind::Rotate, &f, &c, &st, [612.0, 500.0]), Some(Handle::View));
        let mut s = DragSession::begin(GizmoKind::Rotate, Handle::Axis(2), &f, &c, &st, [585.0, 500.0]).unwrap();
        match s.update([585.0, 440.0], &SNAP_OFF) {
            Delta::Rotate { axis, angle } => assert!((axis - Vec3::Z).length() < 1e-5 && (angle - 60.0 / 85.0).abs() < 0.01, "{angle}"),
            d => panic!("{d:?}"),
        }
        let snap = Snap { enabled: true, translate: 0.0, rotate: 15f32.to_radians(), scale: 0.0 };
        if let Delta::Rotate { angle, .. } = s.update([585.0, 440.0], &snap) {
            assert!((angle - 45f32.to_radians()).abs() < 1e-4, "{}", angle.to_degrees());
        }
        let mut v = DragSession::begin(GizmoKind::Rotate, Handle::View, &f, &c, &st, [612.0, 500.0]).unwrap();
        match v.update([500.0, 388.0], &SNAP_OFF) {
            Delta::Rotate { axis, angle } => assert!((axis - Vec3::Z).length() < 1e-5 && (angle - PI / 2.0).abs() < 1e-4),
            d => panic!("{d:?}"),
        }
        match v.update([388.0, 500.0], &SNAP_OFF) {
            Delta::Rotate { angle, .. } => assert!((angle - PI).abs() < 1e-4, "continuous past 90 degrees: {angle}"),
            d => panic!("{d:?}"),
        }
        match v.update([500.0, 612.0], &SNAP_OFF) {
            Delta::Rotate { angle, .. } => assert!((angle - 1.5 * PI).abs() < 1e-4, "continuous past 180 degrees: {angle}"),
            d => panic!("{d:?}"),
        }
    }

    #[test]
    fn scale_handles() {
        let (c, f, st) = (cam(ViewPreset::Front), GizmoFrame::world(Vec3::ZERO), style());
        let mut s = DragSession::begin(GizmoKind::Scale, Handle::Axis(0), &f, &c, &st, [560.0, 500.0]).unwrap();
        match s.update([660.0, 500.0], &SNAP_OFF) {
            Delta::Scale(v) => assert!((v.x - 2.0).abs() < 1e-4 && v.y == 1.0 && v.z == 1.0),
            d => panic!("{d:?}"),
        }
        let mut u = DragSession::begin(GizmoKind::Scale, Handle::Center, &f, &c, &st, [500.0, 500.0]).unwrap();
        match u.update([550.0, 450.0], &SNAP_OFF) {
            Delta::Scale(v) => assert!((v.x - 1.5).abs() < 1e-4 && v.x == v.y && v.y == v.z),
            d => panic!("{d:?}"),
        }
        match u.update([0.0, 500.0], &SNAP_OFF) {
            Delta::Scale(v) => assert!(v.x.abs() >= 1e-4 || v.x != 0.0),
            d => panic!("{d:?}"),
        }
        assert!(DragSession::begin(GizmoKind::Move, Handle::View, &f, &c, &st, [0.0, 0.0]).is_none());
    }

    #[test]
    fn drawing_is_finite_for_every_kind() {
        let mut pc = Camera::default();
        pc.set_viewport(1080.0, 1920.0);
        let st = Style::for_density(2.6);
        let f = GizmoFrame::world(Vec3::new(0.5, 0.0, 0.2));
        for kind in [GizmoKind::Move, GizmoKind::Rotate, GizmoKind::Scale] {
            for active in [None, Some(Handle::Axis(1))] {
                let mut out = GizmoDraw::default();
                draw(kind, &f, &pc, &st, active, &mut out);
                assert!(!out.tris.is_empty() && out.tris.len() % 3 == 0);
                assert!(out.tris.iter().chain(out.lines.iter()).all(|v| v.pos.iter().chain(v.color.iter()).all(|x| x.is_finite())));
            }
        }
        // behind the camera: nothing to draw
        let mut out = GizmoDraw::default();
        draw(GizmoKind::Move, &GizmoFrame::world(pc.eye() - pc.forward() * 5.0), &pc, &st, None, &mut out);
        assert!(out.tris.is_empty());
        assert_eq!(Handle::Plane(2).constraint(), [true, true, false]);
        assert_eq!(Handle::Axis(1).constraint(), [false, true, false]);
    }
}
