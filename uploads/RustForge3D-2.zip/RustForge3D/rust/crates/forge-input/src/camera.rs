//! Turntable camera. World is right-handed Z-up; `yaw = 0, pitch = 0` looks along +Y (Blender "Front").
use forge_math::{Aabb, Mat4, Ray, Vec3};
use std::f32::consts::{FRAC_PI_2, PI};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ViewPreset {
    Front,
    Back,
    Right,
    Left,
    Top,
    Bottom,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Camera {
    pub target: Vec3,
    pub distance: f32,
    /// Rotation about +Z (counter-clockwise seen from above), radians.
    pub yaw: f32,
    /// Elevation above the XY plane, radians in `[-pi/2, pi/2]`.
    pub pitch: f32,
    pub fov_y: f32,
    pub ortho: bool,
    /// Viewport in pixels.
    pub width: f32,
    pub height: f32,
}

impl Default for Camera {
    fn default() -> Camera {
        // Blender's startup view: eye near (7.4, -6.9, 5.0) looking at the origin.
        Camera { target: Vec3::ZERO, distance: 11.26, yaw: 0.815, pitch: 0.456, fov_y: 40f32.to_radians(), ortho: false, width: 1.0, height: 1.0 }
    }
}

const MIN_DISTANCE: f32 = 0.02;
const MAX_DISTANCE: f32 = 5000.0;

impl Camera {
    pub fn set_viewport(&mut self, width: f32, height: f32) {
        self.width = width.max(1.0);
        self.height = height.max(1.0);
    }
    pub fn aspect(&self) -> f32 {
        (self.width / self.height).max(1e-3)
    }
    /// Unit vector from the target towards the eye.
    pub fn offset_dir(&self) -> Vec3 {
        let (sy, cy) = self.yaw.sin_cos();
        let (sp, cp) = self.pitch.sin_cos();
        Vec3::new(sy * cp, -cy * cp, sp)
    }
    pub fn eye(&self) -> Vec3 {
        self.target + self.offset_dir() * self.distance
    }
    pub fn forward(&self) -> Vec3 {
        self.offset_dir() * -1.0
    }
    pub fn right(&self) -> Vec3 {
        Vec3::new(self.yaw.cos(), self.yaw.sin(), 0.0)
    }
    pub fn up(&self) -> Vec3 {
        self.right().cross(self.forward())
    }
    /// Orthographic frustum height in world units at the current distance.
    pub fn ortho_height(&self) -> f32 {
        2.0 * self.distance * (0.5 * self.fov_y).tan()
    }
    pub fn clip_planes(&self) -> (f32, f32) {
        if self.ortho {
            let far = (self.distance * 100.0).max(1000.0);
            (-far, far)
        } else {
            ((self.distance * 0.02).clamp(0.001, 50.0), (self.distance * 400.0).max(1000.0))
        }
    }
    pub fn view(&self) -> Mat4 {
        Mat4::look_at_rh(self.eye(), self.target, self.up())
    }
    pub fn proj(&self) -> Mat4 {
        let (near, far) = self.clip_planes();
        if self.ortho {
            let h = self.ortho_height() * 0.5;
            let w = h * self.aspect();
            Mat4::orthographic_rh(-w, w, -h, h, near, far)
        } else {
            Mat4::perspective_rh(self.fov_y, self.aspect(), near, far)
        }
    }
    pub fn view_proj(&self) -> Mat4 {
        self.proj().mul_mat4(&self.view())
    }

    /// Picking ray through a viewport pixel (origin top-left).
    pub fn ray(&self, x: f32, y: f32) -> Ray {
        let nx = x / self.width * 2.0 - 1.0;
        let ny = 1.0 - y / self.height * 2.0;
        let inv = self.view_proj().inverse();
        let near = inv.project_point3(Vec3::new(nx, ny, 0.0));
        let far = inv.project_point3(Vec3::new(nx, ny, 1.0));
        match (near, far) {
            (Some(n), Some(f)) if (f - n).length_squared() > 1e-12 => {
                let dir = (f - n).normalize();
                Ray::new(if self.ortho { n } else { self.eye() }, dir)
            }
            _ => Ray::new(self.eye(), self.forward()),
        }
    }

    /// World point -> `[x_px, y_px]` (origin top-left). `None` when behind the camera.
    pub fn project_px(&self, p: Vec3) -> Option<[f32; 2]> {
        self.project(p).map(|v| [v[0], v[1]])
    }
    /// World point -> `[x_px, y_px, depth 0..1]`.
    pub fn project(&self, p: Vec3) -> Option<[f32; 3]> {
        if !self.ortho && (p - self.eye()).dot(self.forward()) <= 1e-6 {
            return None;
        }
        let n = self.view_proj().project_point3(p)?;
        Some([(n.x * 0.5 + 0.5) * self.width, (1.0 - (n.y * 0.5 + 0.5)) * self.height, n.z])
    }
    /// World units covered by one pixel at `p` (for constant-size handles and panning).
    pub fn pixel_scale_at(&self, p: Vec3) -> f32 {
        if self.ortho {
            self.ortho_height() / self.height
        } else {
            let depth = (p - self.eye()).dot(self.forward()).max(1e-4);
            2.0 * (0.5 * self.fov_y).tan() * depth / self.height
        }
    }

    /// Turntable orbit; `rad_per_px` converts pointer movement to rotation.
    pub fn orbit(&mut self, dx_px: f32, dy_px: f32, rad_per_px: f32) {
        self.yaw = wrap_pi(self.yaw - dx_px * rad_per_px);
        self.pitch = (self.pitch + dy_px * rad_per_px).clamp(-FRAC_PI_2, FRAC_PI_2);
    }
    /// Move the target so the scene follows the pointer.
    pub fn pan(&mut self, dx_px: f32, dy_px: f32) {
        let s = self.pixel_scale_at(self.target);
        self.target = self.target - self.right() * (dx_px * s) + self.up() * (dy_px * s);
    }
    /// `factor > 1` moves away from the target.
    pub fn zoom(&mut self, factor: f32) {
        if factor.is_finite() && factor > 0.0 {
            self.distance = (self.distance * factor).clamp(MIN_DISTANCE, MAX_DISTANCE);
        }
    }
    /// Centre on a bounding box and back off until it fits.
    pub fn frame(&mut self, b: &Aabb) {
        if !(b.min.x <= b.max.x && b.min.y <= b.max.y && b.min.z <= b.max.z) {
            return;
        }
        let radius = ((b.max - b.min).length() * 0.5).max(0.05);
        let half_y = 0.5 * self.fov_y;
        let half_x = (half_y.tan() * self.aspect()).atan();
        self.target = b.center();
        self.distance = (radius / half_y.min(half_x).sin() * 1.1).clamp(MIN_DISTANCE, MAX_DISTANCE);
    }
    pub fn set_preset(&mut self, p: ViewPreset) {
        let (yaw, pitch) = match p {
            ViewPreset::Front => (0.0, 0.0),
            ViewPreset::Back => (PI, 0.0),
            ViewPreset::Right => (FRAC_PI_2, 0.0),
            ViewPreset::Left => (-FRAC_PI_2, 0.0),
            ViewPreset::Top => (0.0, FRAC_PI_2),
            ViewPreset::Bottom => (0.0, -FRAC_PI_2),
        };
        self.yaw = yaw;
        self.pitch = pitch;
    }
}

fn wrap_pi(a: f32) -> f32 {
    a - 2.0 * PI * ((a + PI) / (2.0 * PI)).floor()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn cam() -> Camera {
        let mut c = Camera::default();
        c.set_viewport(1000.0, 800.0);
        c
    }

    #[test]
    fn rays_and_projection_agree() {
        for ortho in [false, true] {
            let mut c = cam();
            c.ortho = ortho;
            for &(x, y) in &[(500.0, 400.0), (120.0, 60.0), (930.0, 700.0)] {
                let ray = c.ray(x, y);
                let p = ray.at(7.0);
                let q = c.project_px(p).unwrap();
                assert!((q[0] - x).abs() < 0.05 && (q[1] - y).abs() < 0.05, "{ortho}: {q:?} vs {x},{y}");
            }
            let centre = c.project_px(c.target).unwrap();
            assert!((centre[0] - 500.0).abs() < 1e-2 && (centre[1] - 400.0).abs() < 1e-2);
        }
        let c = cam();
        assert!(c.project_px(c.eye() + c.forward() * -2.0).is_none());
    }

    #[test]
    fn presets_look_along_the_right_axes() {
        let mut c = cam();
        c.set_preset(ViewPreset::Front);
        assert!((c.forward() - Vec3::Y).length() < 1e-5 && (c.right() - Vec3::X).length() < 1e-5 && (c.up() - Vec3::Z).length() < 1e-5);
        c.set_preset(ViewPreset::Right);
        assert!((c.forward() - Vec3::new(-1.0, 0.0, 0.0)).length() < 1e-5 && (c.right() - Vec3::Y).length() < 1e-5);
        c.set_preset(ViewPreset::Top);
        assert!((c.forward() - Vec3::new(0.0, 0.0, -1.0)).length() < 1e-5 && (c.up() - Vec3::Y).length() < 1e-5);
        c.set_preset(ViewPreset::Bottom);
        assert!((c.up() - Vec3::new(0.0, -1.0, 0.0)).length() < 1e-5);
    }

    #[test]
    fn navigation_behaves() {
        let mut c = cam();
        c.orbit(0.0, 100000.0, 0.01);
        assert!((c.pitch - FRAC_PI_2).abs() < 1e-6);
        let (yaw0, t0) = (c.yaw, c.target);
        c.orbit(50.0, 0.0, 0.01);
        assert!(c.yaw < yaw0);
        c.pan(100.0, 0.0);
        assert!((c.target - t0).dot(c.right()) < 0.0);
        let d = c.distance;
        c.zoom(0.5);
        assert!((c.distance - d * 0.5).abs() < 1e-5);
        c.zoom(1e-9);
        assert!(c.distance >= MIN_DISTANCE);
        let mut f = cam();
        f.frame(&Aabb::new(Vec3::new(-1.0, -1.0, -1.0), Vec3::new(3.0, 1.0, 1.0)));
        assert!((f.target - Vec3::new(1.0, 0.0, 0.0)).length() < 1e-5);
        let half = (0.5f32 * f.fov_y).min(((0.5 * f.fov_y).tan() * f.aspect()).atan());
        assert!(f.distance * half.sin() >= (24.0f32).sqrt() * 0.5);
    }
}
