//! Pointer batches -> high level gesture events.
//!
//! One pointer: `Down`, then either `Tap` / `DoubleTap` / `LongPress` or `DragBegin` + `Drag`* + `DragEnd`.
//! Two fingers: `MultiBegin`, `Multi`* (incremental centre shift, scale ratio, twist), `MultiEnd`.
//! A stylus that touches down while fingers are down takes over; the fingers are treated as a resting palm.
use crate::touch::*;

const LONG_PRESS_MS: u64 = 450;
const DOUBLE_TAP_MS: u64 = 320;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PointerKind {
    Finger,
    Stylus,
    Mouse,
    Eraser,
}

impl PointerKind {
    pub fn from_tool(t: i32) -> PointerKind {
        match t {
            TOOL_STYLUS => PointerKind::Stylus,
            TOOL_MOUSE => PointerKind::Mouse,
            TOOL_ERASER => PointerKind::Eraser,
            _ => PointerKind::Finger,
        }
    }
    /// Pen-like pointers act on the model; fingers navigate.
    pub fn is_pen(self) -> bool {
        matches!(self, PointerKind::Stylus | PointerKind::Eraser)
    }
}

#[derive(Clone, Debug, PartialEq)]
pub enum Event {
    Down { pos: [f32; 2], kind: PointerKind, pressure: f32 },
    DragBegin { start: [f32; 2], pos: [f32; 2], kind: PointerKind, pressure: f32 },
    /// `delta` is the movement since the previous event (the first one includes the slop distance).
    Drag { start: [f32; 2], pos: [f32; 2], delta: [f32; 2], kind: PointerKind, pressure: f32 },
    DragEnd { start: [f32; 2], pos: [f32; 2], kind: PointerKind },
    /// The drag was interrupted (second finger, system cancel): undo whatever it did.
    DragCancel,
    Tap { pos: [f32; 2], kind: PointerKind },
    DoubleTap { pos: [f32; 2] },
    LongPress { pos: [f32; 2], kind: PointerKind },
    MultiBegin { center: [f32; 2] },
    /// Incremental: `scale` is the ratio of finger distances (>1 spreads), `twist` radians (screen clockwise > 0).
    Multi { center: [f32; 2], delta: [f32; 2], scale: f32, twist: f32 },
    MultiEnd,
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum State {
    Idle,
    Pending { id: i32, start: [f32; 2], t0: u64, kind: PointerKind, pressure: f32, long_fired: bool },
    Dragging { id: i32, start: [f32; 2], last: [f32; 2], kind: PointerKind },
    Multi { a: i32, b: i32, center: [f32; 2], dist: f32, angle: f32 },
    /// A multi-touch gesture ended; swallow the remaining pointers until all are up.
    Wait,
}

pub struct Gestures {
    slop: f32,
    dbl_radius: f32,
    state: State,
    last_tap: Option<([f32; 2], u64)>,
    ignored: Vec<i32>,
}

fn dist(a: [f32; 2], b: [f32; 2]) -> f32 {
    ((a[0] - b[0]).powi(2) + (a[1] - b[1]).powi(2)).sqrt()
}

fn pair(a: [f32; 2], b: [f32; 2]) -> ([f32; 2], f32, f32) {
    ([(a[0] + b[0]) * 0.5, (a[1] + b[1]) * 0.5], dist(a, b), (b[1] - a[1]).atan2(b[0] - a[0]))
}

fn wrap(a: f32) -> f32 {
    let tau = std::f32::consts::TAU;
    a - tau * ((a + std::f32::consts::PI) / tau).floor()
}

impl Gestures {
    /// `density`: pixels per dp, used to scale the touch slop.
    pub fn new(density: f32) -> Gestures {
        let d = density.max(0.5);
        Gestures { slop: 8.0 * d, dbl_radius: 36.0 * d, state: State::Idle, last_tap: None, ignored: Vec::new() }
    }

    pub fn is_idle(&self) -> bool {
        self.state == State::Idle
    }

    /// `now_ms`: any monotonic clock (only differences are used).
    pub fn feed(&mut self, b: &TouchBatch, now_ms: u64) -> Vec<Event> {
        let mut out = Vec::new();
        let idx = b.action_index.max(0) as usize;
        let acted = b.pointers.get(idx).or_else(|| b.pointers.first());
        match b.action {
            ACTION_DOWN => {
                self.cancel(&mut out);
                self.ignored.clear();
                if let Some(p) = acted {
                    self.begin(p, now_ms, &mut out);
                }
            }
            ACTION_POINTER_DOWN => {
                if let Some(p) = acted {
                    self.pointer_down(b, p, now_ms, &mut out);
                }
            }
            ACTION_MOVE => self.moved(b, &mut out),
            ACTION_UP | ACTION_POINTER_UP => {
                let all_up = b.action == ACTION_UP || b.pointers.len() <= 1;
                if let Some(p) = acted {
                    self.lifted(p, all_up, now_ms, &mut out);
                }
            }
            ACTION_CANCEL => {
                self.cancel(&mut out);
                self.state = State::Idle;
                self.ignored.clear();
            }
            _ => {}
        }
        out
    }

    /// Time based events (long press). Call regularly, e.g. from the UI poll.
    pub fn tick(&mut self, now_ms: u64) -> Vec<Event> {
        let mut out = Vec::new();
        if let State::Pending { id, start, t0, kind, pressure, long_fired: false } = self.state {
            if now_ms.saturating_sub(t0) >= LONG_PRESS_MS {
                self.state = State::Pending { id, start, t0, kind, pressure, long_fired: true };
                out.push(Event::LongPress { pos: start, kind });
            }
        }
        out
    }

    /// Abort any gesture in progress (app paused, tool changed).
    pub fn reset(&mut self) -> Vec<Event> {
        let mut out = Vec::new();
        self.cancel(&mut out);
        self.state = State::Idle;
        self.ignored.clear();
        out
    }

    fn cancel(&mut self, out: &mut Vec<Event>) {
        match self.state {
            State::Dragging { .. } => out.push(Event::DragCancel),
            State::Multi { .. } => out.push(Event::MultiEnd),
            _ => {}
        }
        self.state = State::Idle;
    }

    fn begin(&mut self, p: &TouchPointer, now: u64, out: &mut Vec<Event>) {
        let kind = PointerKind::from_tool(p.tool_type);
        let start = [p.x, p.y];
        self.state = State::Pending { id: p.id, start, t0: now, kind, pressure: p.pressure, long_fired: false };
        out.push(Event::Down { pos: start, kind, pressure: p.pressure });
    }

    fn pointer_down(&mut self, b: &TouchBatch, p: &TouchPointer, now: u64, out: &mut Vec<Event>) {
        let kind = PointerKind::from_tool(p.tool_type);
        if kind.is_pen() {
            self.cancel(out);
            self.ignored = b.pointers.iter().filter(|q| q.id != p.id).map(|q| q.id).collect();
            self.begin(p, now, out);
            return;
        }
        let primary = match self.state {
            State::Pending { id, kind, .. } | State::Dragging { id, kind, .. } => Some((id, kind)),
            _ => None,
        };
        match primary {
            Some((_, k)) if k.is_pen() => self.ignored.push(p.id),
            Some((id, _)) => match b.pointers.iter().find(|q| q.id == id) {
                Some(first) => {
                    if matches!(self.state, State::Dragging { .. }) {
                        out.push(Event::DragCancel);
                    }
                    let (center, d, angle) = pair([first.x, first.y], [p.x, p.y]);
                    self.state = State::Multi { a: id, b: p.id, center, dist: d, angle };
                    out.push(Event::MultiBegin { center });
                }
                None => self.ignored.push(p.id),
            },
            None if self.state == State::Idle => self.begin(p, now, out),
            None => self.ignored.push(p.id),
        }
    }

    fn moved(&mut self, b: &TouchBatch, out: &mut Vec<Event>) {
        let find = |id: i32| b.pointers.iter().find(|q| q.id == id);
        match self.state {
            State::Pending { id, start, kind, .. } => {
                if let Some(p) = find(id) {
                    let pos = [p.x, p.y];
                    if dist(start, pos) > self.slop {
                        out.push(Event::DragBegin { start, pos, kind, pressure: p.pressure });
                        out.push(Event::Drag { start, pos, delta: [pos[0] - start[0], pos[1] - start[1]], kind, pressure: p.pressure });
                        self.state = State::Dragging { id, start, last: pos, kind };
                    }
                }
            }
            State::Dragging { id, start, last, kind } => {
                if let Some(p) = find(id) {
                    let pos = [p.x, p.y];
                    if pos != last {
                        out.push(Event::Drag { start, pos, delta: [pos[0] - last[0], pos[1] - last[1]], kind, pressure: p.pressure });
                        self.state = State::Dragging { id, start, last: pos, kind };
                    }
                }
            }
            State::Multi { a, b: bid, center, dist: d0, angle } => {
                if let (Some(pa), Some(pb)) = (find(a), find(bid)) {
                    let (c, d, ang) = pair([pa.x, pa.y], [pb.x, pb.y]);
                    let scale = if d0 > 1e-3 && d > 1e-3 { d / d0 } else { 1.0 };
                    let twist = wrap(ang - angle);
                    let delta = [c[0] - center[0], c[1] - center[1]];
                    if delta != [0.0, 0.0] || scale != 1.0 || twist != 0.0 {
                        out.push(Event::Multi { center: c, delta, scale, twist });
                    }
                    self.state = State::Multi { a, b: bid, center: c, dist: d, angle: ang };
                }
            }
            _ => {}
        }
    }

    fn lifted(&mut self, p: &TouchPointer, all_up: bool, now: u64, out: &mut Vec<Event>) {
        self.ignored.retain(|&i| i != p.id);
        let pos = [p.x, p.y];
        match self.state {
            State::Pending { id, kind, long_fired, .. } if id == p.id => {
                if !long_fired {
                    let double = matches!(self.last_tap, Some((q, t)) if now.saturating_sub(t) <= DOUBLE_TAP_MS && dist(q, pos) <= self.dbl_radius);
                    if double {
                        out.push(Event::DoubleTap { pos });
                        self.last_tap = None;
                    } else {
                        out.push(Event::Tap { pos, kind });
                        self.last_tap = Some((pos, now));
                    }
                }
                self.state = State::Wait;
            }
            State::Dragging { id, start, kind, .. } if id == p.id => {
                out.push(Event::DragEnd { start, pos, kind });
                self.state = State::Wait;
            }
            State::Multi { a, b, .. } if a == p.id || b == p.id => {
                out.push(Event::MultiEnd);
                self.state = State::Wait;
            }
            _ => {}
        }
        if all_up {
            self.state = State::Idle;
            self.ignored.clear();
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn f(id: i32, x: f32, y: f32) -> TouchPointer {
        TouchPointer::finger(id, x, y)
    }
    fn b(action: i32, index: i32, pts: &[TouchPointer]) -> TouchBatch {
        TouchBatch::new(action, index, pts.to_vec())
    }

    #[test]
    fn tap_then_double_tap() {
        let mut g = Gestures::new(1.0);
        assert!(matches!(g.feed(&b(0, 0, &[f(0, 100.0, 100.0)]), 0)[..], [Event::Down { .. }]));
        assert!(matches!(g.feed(&b(1, 0, &[f(0, 101.0, 100.0)]), 60)[..], [Event::Tap { .. }]));
        assert!(g.is_idle());
        g.feed(&b(0, 0, &[f(0, 102.0, 101.0)]), 200);
        assert!(matches!(g.feed(&b(1, 0, &[f(0, 102.0, 101.0)]), 250)[..], [Event::DoubleTap { .. }]));
        g.feed(&b(0, 0, &[f(0, 102.0, 101.0)]), 300);
        assert!(matches!(g.feed(&b(1, 0, &[f(0, 102.0, 101.0)]), 340)[..], [Event::Tap { .. }]), "third tap starts over");
        g.feed(&b(0, 0, &[f(0, 500.0, 500.0)]), 5000);
        assert!(matches!(g.feed(&b(1, 0, &[f(0, 500.0, 500.0)]), 5040)[..], [Event::Tap { .. }]), "too slow");
    }

    #[test]
    fn drag_needs_slop_then_streams_deltas() {
        let mut g = Gestures::new(1.0);
        g.feed(&b(0, 0, &[f(0, 100.0, 100.0)]), 0);
        assert!(g.feed(&b(2, 0, &[f(0, 104.0, 100.0)]), 10).is_empty());
        let ev = g.feed(&b(2, 0, &[f(0, 120.0, 100.0)]), 20);
        assert!(matches!(ev[0], Event::DragBegin { .. }));
        assert!(matches!(ev[1], Event::Drag { delta, .. } if delta == [20.0, 0.0]));
        let ev = g.feed(&b(2, 0, &[f(0, 130.0, 105.0)]), 30);
        assert!(matches!(ev[..], [Event::Drag { delta, .. }] if delta == [10.0, 5.0]));
        assert!(matches!(g.feed(&b(1, 0, &[f(0, 130.0, 105.0)]), 40)[..], [Event::DragEnd { .. }]));
        assert!(g.is_idle());
    }

    #[test]
    fn long_press_suppresses_the_tap() {
        let mut g = Gestures::new(2.0);
        g.feed(&b(0, 0, &[f(0, 10.0, 10.0)]), 0);
        assert!(g.tick(100).is_empty());
        assert!(matches!(g.tick(500)[..], [Event::LongPress { .. }]));
        assert!(g.tick(900).is_empty());
        assert!(g.feed(&b(1, 0, &[f(0, 10.0, 10.0)]), 1000).is_empty());
    }

    #[test]
    fn two_fingers_pinch_pan_and_twist() {
        let mut g = Gestures::new(1.0);
        g.feed(&b(0, 0, &[f(0, 100.0, 100.0)]), 0);
        let ev = g.feed(&b(5, 1, &[f(0, 100.0, 100.0), f(1, 200.0, 100.0)]), 5);
        assert!(matches!(ev[..], [Event::MultiBegin { center }] if center == [150.0, 100.0]));
        let ev = g.feed(&b(2, 0, &[f(0, 100.0, 100.0), f(1, 300.0, 100.0)]), 10);
        assert!(matches!(ev[..], [Event::Multi { scale, delta, twist, .. }] if (scale - 2.0).abs() < 1e-5 && delta == [50.0, 0.0] && twist.abs() < 1e-5));
        let ev = g.feed(&b(2, 0, &[f(0, 200.0, 50.0), f(1, 200.0, 150.0)]), 20);
        assert!(matches!(ev[..], [Event::Multi { twist, .. }] if twist > 1.0), "{ev:?}");
        assert!(matches!(g.feed(&b(6, 1, &[f(0, 200.0, 50.0), f(1, 200.0, 150.0)]), 30)[..], [Event::MultiEnd]));
        assert!(g.feed(&b(2, 0, &[f(0, 220.0, 60.0)]), 40).is_empty(), "no drag after a pinch");
        assert!(g.feed(&b(1, 0, &[f(0, 220.0, 60.0)]), 50).is_empty());
        assert!(g.is_idle());
    }

    #[test]
    fn second_finger_cancels_a_drag() {
        let mut g = Gestures::new(1.0);
        g.feed(&b(0, 0, &[f(0, 0.0, 0.0)]), 0);
        g.feed(&b(2, 0, &[f(0, 50.0, 0.0)]), 5);
        let ev = g.feed(&b(5, 1, &[f(0, 50.0, 0.0), f(1, 90.0, 0.0)]), 8);
        assert!(matches!(ev[..], [Event::DragCancel, Event::MultiBegin { .. }]));
    }

    #[test]
    fn stylus_overrides_resting_palm() {
        let mut g = Gestures::new(1.0);
        g.feed(&b(0, 0, &[f(0, 300.0, 300.0)]), 0);
        let pen = TouchPointer::stylus(1, 50.0, 50.0, 0.7);
        let ev = g.feed(&b(5, 1, &[f(0, 300.0, 300.0), pen]), 5);
        assert!(matches!(ev[..], [Event::Down { kind: PointerKind::Stylus, .. }]));
        assert!(g.feed(&b(2, 0, &[f(0, 320.0, 330.0), pen]), 6).is_empty(), "palm movement is ignored");
        let pen2 = TouchPointer::stylus(1, 90.0, 50.0, 0.9);
        let ev = g.feed(&b(2, 0, &[f(0, 320.0, 330.0), pen2]), 7);
        assert!(matches!(ev[1], Event::Drag { kind: PointerKind::Stylus, pressure, .. } if pressure > 0.8));
        assert!(matches!(g.feed(&b(1, 1, &[f(0, 320.0, 330.0), pen2]), 9)[..], [Event::DragEnd { .. }]));
    }

    #[test]
    fn system_cancel_resets() {
        let mut g = Gestures::new(1.0);
        g.feed(&b(0, 0, &[f(0, 0.0, 0.0)]), 0);
        g.feed(&b(2, 0, &[f(0, 40.0, 0.0)]), 5);
        assert!(matches!(g.feed(&b(3, 0, &[f(0, 40.0, 0.0)]), 6)[..], [Event::DragCancel]));
        assert!(g.is_idle());
        assert!(g.reset().is_empty());
    }
}
