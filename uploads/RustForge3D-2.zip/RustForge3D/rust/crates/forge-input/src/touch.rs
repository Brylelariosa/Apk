//! Raw touch data as delivered by the Android `MotionEvent` bridge.

pub const TOOL_FINGER: i32 = 1;
pub const TOOL_STYLUS: i32 = 2;
pub const TOOL_MOUSE: i32 = 3;
pub const TOOL_ERASER: i32 = 4;

pub(crate) const ACTION_DOWN: i32 = 0;
pub(crate) const ACTION_UP: i32 = 1;
pub(crate) const ACTION_MOVE: i32 = 2;
pub(crate) const ACTION_CANCEL: i32 = 3;
pub(crate) const ACTION_POINTER_DOWN: i32 = 5;
pub(crate) const ACTION_POINTER_UP: i32 = 6;

/// One pointer of a touch event batch (mirrors Android `MotionEvent`).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TouchPointer {
    pub id: i32,
    pub x: f32,
    pub y: f32,
    pub pressure: f32,
    /// Android `MotionEvent.TOOL_TYPE_*`: 1 finger, 2 stylus, 3 mouse, 4 eraser.
    pub tool_type: i32,
}

/// All pointers currently down plus the action that triggered the event.
#[derive(Clone, Debug, PartialEq)]
pub struct TouchBatch {
    /// `MotionEvent.getActionMasked()`: 0 down, 1 up, 2 move, 3 cancel, 5 pointer down, 6 pointer up.
    pub action: i32,
    /// `MotionEvent.getActionIndex()` (index into `pointers` of the pointer that went down/up).
    pub action_index: i32,
    pub time_ms: u64,
    pub pointers: Vec<TouchPointer>,
}

impl TouchPointer {
    pub fn finger(id: i32, x: f32, y: f32) -> TouchPointer {
        TouchPointer { id, x, y, pressure: 1.0, tool_type: TOOL_FINGER }
    }
    pub fn stylus(id: i32, x: f32, y: f32, pressure: f32) -> TouchPointer {
        TouchPointer { id, x, y, pressure, tool_type: TOOL_STYLUS }
    }
}

impl TouchBatch {
    pub fn new(action: i32, action_index: i32, pointers: Vec<TouchPointer>) -> TouchBatch {
        TouchBatch { action, action_index, time_ms: 0, pointers }
    }
}
