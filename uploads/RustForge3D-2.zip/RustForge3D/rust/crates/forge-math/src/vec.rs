//! Vec2 / Vec3 / Vec4 (f32). API follows glam naming where practical.
use std::ops::{Add, AddAssign, Div, DivAssign, Index, IndexMut, Mul, MulAssign, Neg, Sub, SubAssign};

#[derive(Clone, Copy, PartialEq, Debug, Default)]
pub struct Vec2 {
    pub x: f32,
    pub y: f32,
}
#[derive(Clone, Copy, PartialEq, Debug, Default)]
pub struct Vec3 {
    pub x: f32,
    pub y: f32,
    pub z: f32,
}
#[derive(Clone, Copy, PartialEq, Debug, Default)]
pub struct Vec4 {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub w: f32,
}

macro_rules! vec_ops {
    ($T:ident, $($f:ident),+) => {
        impl Add for $T { type Output = $T; #[inline] fn add(self, o: $T) -> $T { $T { $($f: self.$f + o.$f),+ } } }
        impl Sub for $T { type Output = $T; #[inline] fn sub(self, o: $T) -> $T { $T { $($f: self.$f - o.$f),+ } } }
        impl Mul for $T { type Output = $T; #[inline] fn mul(self, o: $T) -> $T { $T { $($f: self.$f * o.$f),+ } } }
        impl Div for $T { type Output = $T; #[inline] fn div(self, o: $T) -> $T { $T { $($f: self.$f / o.$f),+ } } }
        impl Mul<f32> for $T { type Output = $T; #[inline] fn mul(self, s: f32) -> $T { $T { $($f: self.$f * s),+ } } }
        impl Div<f32> for $T { type Output = $T; #[inline] fn div(self, s: f32) -> $T { $T { $($f: self.$f / s),+ } } }
        impl Mul<$T> for f32 { type Output = $T; #[inline] fn mul(self, v: $T) -> $T { $T { $($f: self * v.$f),+ } } }
        impl Neg for $T { type Output = $T; #[inline] fn neg(self) -> $T { $T { $($f: -self.$f),+ } } }
        impl AddAssign for $T { #[inline] fn add_assign(&mut self, o: $T) { $(self.$f += o.$f;)+ } }
        impl SubAssign for $T { #[inline] fn sub_assign(&mut self, o: $T) { $(self.$f -= o.$f;)+ } }
        impl MulAssign<f32> for $T { #[inline] fn mul_assign(&mut self, s: f32) { $(self.$f *= s;)+ } }
        impl DivAssign<f32> for $T { #[inline] fn div_assign(&mut self, s: f32) { $(self.$f /= s;)+ } }
    };
}
vec_ops!(Vec2, x, y);
vec_ops!(Vec3, x, y, z);
vec_ops!(Vec4, x, y, z, w);

// ---------------------------------------------------------------- Vec2
impl Vec2 {
    pub const ZERO: Vec2 = Vec2 { x: 0.0, y: 0.0 };
    pub const ONE: Vec2 = Vec2 { x: 1.0, y: 1.0 };
    #[inline]
    pub const fn new(x: f32, y: f32) -> Vec2 {
        Vec2 { x, y }
    }
    #[inline]
    pub const fn splat(v: f32) -> Vec2 {
        Vec2 { x: v, y: v }
    }
    #[inline]
    pub fn dot(self, o: Vec2) -> f32 {
        self.x * o.x + self.y * o.y
    }
    /// 2D cross product (z of the 3D cross).
    #[inline]
    pub fn perp_dot(self, o: Vec2) -> f32 {
        self.x * o.y - self.y * o.x
    }
    #[inline]
    pub fn length_squared(self) -> f32 {
        self.dot(self)
    }
    #[inline]
    pub fn length(self) -> f32 {
        self.length_squared().sqrt()
    }
    #[inline]
    pub fn distance(self, o: Vec2) -> f32 {
        (self - o).length()
    }
    pub fn normalize(self) -> Vec2 {
        let l = self.length();
        if l > 1e-20 {
            self / l
        } else {
            Vec2::ZERO
        }
    }
    #[inline]
    pub fn lerp(self, o: Vec2, t: f32) -> Vec2 {
        self + (o - self) * t
    }
    #[inline]
    pub fn min(self, o: Vec2) -> Vec2 {
        Vec2::new(self.x.min(o.x), self.y.min(o.y))
    }
    #[inline]
    pub fn max(self, o: Vec2) -> Vec2 {
        Vec2::new(self.x.max(o.x), self.y.max(o.y))
    }
    #[inline]
    pub fn abs(self) -> Vec2 {
        Vec2::new(self.x.abs(), self.y.abs())
    }
    #[inline]
    pub fn perp(self) -> Vec2 {
        Vec2::new(-self.y, self.x)
    }
    #[inline]
    pub fn extend(self, z: f32) -> Vec3 {
        Vec3::new(self.x, self.y, z)
    }
    #[inline]
    pub fn to_array(self) -> [f32; 2] {
        [self.x, self.y]
    }
    #[inline]
    pub fn from_array(a: [f32; 2]) -> Vec2 {
        Vec2::new(a[0], a[1])
    }
    #[inline]
    pub fn is_finite(self) -> bool {
        self.x.is_finite() && self.y.is_finite()
    }
}
impl Index<usize> for Vec2 {
    type Output = f32;
    fn index(&self, i: usize) -> &f32 {
        match i {
            0 => &self.x,
            1 => &self.y,
            _ => panic!("Vec2 index out of range"),
        }
    }
}
impl IndexMut<usize> for Vec2 {
    fn index_mut(&mut self, i: usize) -> &mut f32 {
        match i {
            0 => &mut self.x,
            1 => &mut self.y,
            _ => panic!("Vec2 index out of range"),
        }
    }
}
impl From<[f32; 2]> for Vec2 {
    fn from(a: [f32; 2]) -> Vec2 {
        Vec2::from_array(a)
    }
}

// ---------------------------------------------------------------- Vec3
impl Vec3 {
    pub const ZERO: Vec3 = Vec3 { x: 0.0, y: 0.0, z: 0.0 };
    pub const ONE: Vec3 = Vec3 { x: 1.0, y: 1.0, z: 1.0 };
    pub const X: Vec3 = Vec3 { x: 1.0, y: 0.0, z: 0.0 };
    pub const Y: Vec3 = Vec3 { x: 0.0, y: 1.0, z: 0.0 };
    pub const Z: Vec3 = Vec3 { x: 0.0, y: 0.0, z: 1.0 };
    pub const NEG_X: Vec3 = Vec3 { x: -1.0, y: 0.0, z: 0.0 };
    pub const NEG_Y: Vec3 = Vec3 { x: 0.0, y: -1.0, z: 0.0 };
    pub const NEG_Z: Vec3 = Vec3 { x: 0.0, y: 0.0, z: -1.0 };
    pub const AXES: [Vec3; 3] = [Vec3::X, Vec3::Y, Vec3::Z];

    #[inline]
    pub const fn new(x: f32, y: f32, z: f32) -> Vec3 {
        Vec3 { x, y, z }
    }
    #[inline]
    pub const fn splat(v: f32) -> Vec3 {
        Vec3 { x: v, y: v, z: v }
    }
    #[inline]
    pub fn dot(self, o: Vec3) -> f32 {
        self.x * o.x + self.y * o.y + self.z * o.z
    }
    #[inline]
    pub fn cross(self, o: Vec3) -> Vec3 {
        Vec3::new(
            self.y * o.z - self.z * o.y,
            self.z * o.x - self.x * o.z,
            self.x * o.y - self.y * o.x,
        )
    }
    #[inline]
    pub fn length_squared(self) -> f32 {
        self.dot(self)
    }
    #[inline]
    pub fn length(self) -> f32 {
        self.length_squared().sqrt()
    }
    #[inline]
    pub fn distance(self, o: Vec3) -> f32 {
        (self - o).length()
    }
    #[inline]
    pub fn distance_squared(self, o: Vec3) -> f32 {
        (self - o).length_squared()
    }
    /// Normalised copy; the zero vector (or anything shorter than 1e-20) maps to zero. Never NaN.
    pub fn normalize(self) -> Vec3 {
        let l = self.length();
        if l > 1e-20 && l.is_finite() {
            self / l
        } else {
            Vec3::ZERO
        }
    }
    pub fn try_normalize(self) -> Option<Vec3> {
        let l = self.length();
        if l > 1e-20 && l.is_finite() {
            Some(self / l)
        } else {
            None
        }
    }
    #[inline]
    pub fn lerp(self, o: Vec3, t: f32) -> Vec3 {
        self + (o - self) * t
    }
    #[inline]
    pub fn min(self, o: Vec3) -> Vec3 {
        Vec3::new(self.x.min(o.x), self.y.min(o.y), self.z.min(o.z))
    }
    #[inline]
    pub fn max(self, o: Vec3) -> Vec3 {
        Vec3::new(self.x.max(o.x), self.y.max(o.y), self.z.max(o.z))
    }
    #[inline]
    pub fn abs(self) -> Vec3 {
        Vec3::new(self.x.abs(), self.y.abs(), self.z.abs())
    }
    #[inline]
    pub fn clamp(self, lo: Vec3, hi: Vec3) -> Vec3 {
        self.max(lo).min(hi)
    }
    #[inline]
    pub fn min_element(self) -> f32 {
        self.x.min(self.y).min(self.z)
    }
    #[inline]
    pub fn max_element(self) -> f32 {
        self.x.max(self.y).max(self.z)
    }
    /// Index (0..3) of the component with the largest absolute value.
    pub fn max_abs_axis(self) -> usize {
        let a = self.abs();
        if a.x >= a.y && a.x >= a.z {
            0
        } else if a.y >= a.z {
            1
        } else {
            2
        }
    }
    #[inline]
    pub fn floor(self) -> Vec3 {
        Vec3::new(self.x.floor(), self.y.floor(), self.z.floor())
    }
    #[inline]
    pub fn round(self) -> Vec3 {
        Vec3::new(self.x.round(), self.y.round(), self.z.round())
    }
    #[inline]
    pub fn is_finite(self) -> bool {
        self.x.is_finite() && self.y.is_finite() && self.z.is_finite()
    }
    #[inline]
    pub fn extend(self, w: f32) -> Vec4 {
        Vec4::new(self.x, self.y, self.z, w)
    }
    #[inline]
    pub fn xy(self) -> Vec2 {
        Vec2::new(self.x, self.y)
    }
    pub fn project_onto(self, o: Vec3) -> Vec3 {
        let d = o.dot(o);
        if d > 1e-30 {
            o * (self.dot(o) / d)
        } else {
            Vec3::ZERO
        }
    }
    pub fn reflect(self, n: Vec3) -> Vec3 {
        self - n * (2.0 * self.dot(n))
    }
    pub fn angle_between(self, o: Vec3) -> f32 {
        let d = self.length() * o.length();
        if d < 1e-30 {
            return 0.0;
        }
        (self.dot(o) / d).clamp(-1.0, 1.0).acos()
    }
    /// Some unit vector perpendicular to `self` (self need not be normalised).
    pub fn any_orthogonal(self) -> Vec3 {
        let a = self.abs();
        let axis = if a.x <= a.y && a.x <= a.z {
            Vec3::X
        } else if a.y <= a.z {
            Vec3::Y
        } else {
            Vec3::Z
        };
        self.cross(axis).normalize()
    }
    #[inline]
    pub fn to_array(self) -> [f32; 3] {
        [self.x, self.y, self.z]
    }
    #[inline]
    pub fn from_array(a: [f32; 3]) -> Vec3 {
        Vec3::new(a[0], a[1], a[2])
    }
    /// Component-wise approximate equality.
    pub fn abs_diff_eq(self, o: Vec3, eps: f32) -> bool {
        (self.x - o.x).abs() <= eps && (self.y - o.y).abs() <= eps && (self.z - o.z).abs() <= eps
    }
}
impl Index<usize> for Vec3 {
    type Output = f32;
    #[inline]
    fn index(&self, i: usize) -> &f32 {
        match i {
            0 => &self.x,
            1 => &self.y,
            2 => &self.z,
            _ => panic!("Vec3 index out of range"),
        }
    }
}
impl IndexMut<usize> for Vec3 {
    #[inline]
    fn index_mut(&mut self, i: usize) -> &mut f32 {
        match i {
            0 => &mut self.x,
            1 => &mut self.y,
            2 => &mut self.z,
            _ => panic!("Vec3 index out of range"),
        }
    }
}
impl From<[f32; 3]> for Vec3 {
    fn from(a: [f32; 3]) -> Vec3 {
        Vec3::from_array(a)
    }
}
impl From<Vec3> for [f32; 3] {
    fn from(v: Vec3) -> [f32; 3] {
        v.to_array()
    }
}
impl From<(f32, f32, f32)> for Vec3 {
    fn from(t: (f32, f32, f32)) -> Vec3 {
        Vec3::new(t.0, t.1, t.2)
    }
}

// ---------------------------------------------------------------- Vec4
impl Vec4 {
    pub const ZERO: Vec4 = Vec4 { x: 0.0, y: 0.0, z: 0.0, w: 0.0 };
    #[inline]
    pub const fn new(x: f32, y: f32, z: f32, w: f32) -> Vec4 {
        Vec4 { x, y, z, w }
    }
    #[inline]
    pub const fn splat(v: f32) -> Vec4 {
        Vec4 { x: v, y: v, z: v, w: v }
    }
    #[inline]
    pub fn dot(self, o: Vec4) -> f32 {
        self.x * o.x + self.y * o.y + self.z * o.z + self.w * o.w
    }
    #[inline]
    pub fn truncate(self) -> Vec3 {
        Vec3::new(self.x, self.y, self.z)
    }
    #[inline]
    pub fn to_array(self) -> [f32; 4] {
        [self.x, self.y, self.z, self.w]
    }
    #[inline]
    pub fn from_array(a: [f32; 4]) -> Vec4 {
        Vec4::new(a[0], a[1], a[2], a[3])
    }
}
impl Index<usize> for Vec4 {
    type Output = f32;
    fn index(&self, i: usize) -> &f32 {
        match i {
            0 => &self.x,
            1 => &self.y,
            2 => &self.z,
            3 => &self.w,
            _ => panic!("Vec4 index out of range"),
        }
    }
}
impl IndexMut<usize> for Vec4 {
    fn index_mut(&mut self, i: usize) -> &mut f32 {
        match i {
            0 => &mut self.x,
            1 => &mut self.y,
            2 => &mut self.z,
            3 => &mut self.w,
            _ => panic!("Vec4 index out of range"),
        }
    }
}
