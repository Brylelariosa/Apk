//! forge-math: small f32 linear-algebra kernel for RustForge (glam-style API, no dependencies).
//!
//! Conventions (shared by every crate in the workspace):
//! * Right-handed, **Z-up** world (same as Blender). Camera looks down -Z in view space.
//! * Matrices are column-major; clip-space depth is 0..1 (wgpu).
//! * Angles are radians unless a name says `_deg`.
//! * Euler rotations follow Blender: `XYZ` = rotate about X, then Y, then Z.
#![forbid(unsafe_code)]

mod mat;
mod quat;
mod shapes;
mod vec;

pub use mat::{Mat3, Mat4};
pub use quat::{euler_from_mat3, euler_to_mat3, EulerOrder, Quat};
pub use shapes::{Aabb, Plane, Ray, TriHit};
pub use vec::{Vec2, Vec3, Vec4};

pub const PI: f32 = std::f32::consts::PI;
pub const TAU: f32 = std::f32::consts::TAU;

#[inline]
pub fn radians(deg: f32) -> f32 {
    deg * (PI / 180.0)
}
#[inline]
pub fn degrees(rad: f32) -> f32 {
    rad * (180.0 / PI)
}
#[inline]
pub fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}
#[inline]
pub fn smoothstep(e0: f32, e1: f32, x: f32) -> f32 {
    let t = ((x - e0) / (e1 - e0)).clamp(0.0, 1.0);
    t * t * (3.0 - 2.0 * t)
}
/// Round `v` to the nearest multiple of `step` (no-op for non-positive steps).
#[inline]
pub fn snap(v: f32, step: f32) -> f32 {
    if step > 0.0 {
        (v / step).round() * step
    } else {
        v
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn rng(seed: &mut u64) -> f32 {
        *seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        ((*seed >> 40) as f32) / (1u64 << 24) as f32
    }

    #[test]
    fn mat4_inverse_roundtrip() {
        let m = Mat4::from_scale_rotation_translation(
            Vec3::new(2.0, 3.0, 0.5),
            Quat::from_axis_angle(Vec3::new(1.0, 2.0, 3.0), 0.7),
            Vec3::new(4.0, -5.0, 6.0),
        );
        let p = (m * m.inverse()).to_cols_array();
        let id = Mat4::IDENTITY.to_cols_array();
        for i in 0..16 {
            assert!((p[i] - id[i]).abs() < 1e-5, "elem {i}: {} vs {}", p[i], id[i]);
        }
        assert!((m.determinant() - 2.0 * 3.0 * 0.5).abs() < 1e-4);
        assert!(Mat4::ZERO.try_inverse().is_none());
    }

    #[test]
    fn decompose_roundtrip() {
        let q = Quat::from_axis_angle(Vec3::new(0.3, 0.9, -0.2), 1.1);
        let m = Mat4::from_scale_rotation_translation(Vec3::new(1.5, 2.0, 0.25), q, Vec3::new(1.0, 2.0, 3.0));
        let (s, r, t) = m.to_scale_rotation_translation();
        assert!(s.abs_diff_eq(Vec3::new(1.5, 2.0, 0.25), 1e-5));
        assert!(t.abs_diff_eq(Vec3::new(1.0, 2.0, 3.0), 1e-6));
        assert!(r.dot(q).abs() > 0.99999);
    }

    #[test]
    fn quat_rotates_like_matrix() {
        let q = Quat::from_axis_angle(Vec3::Z, PI / 2.0);
        assert!(q.mul_vec3(Vec3::X).abs_diff_eq(Vec3::Y, 1e-6));
        let m = Mat3::from_quat(q);
        assert!(m.mul_vec3(Vec3::X).abs_diff_eq(Vec3::Y, 1e-6));
        assert!((q * q.inverse()).dot(Quat::IDENTITY) > 0.99999);
        let a = Quat::from_rotation_arc(Vec3::X, Vec3::Y);
        assert!(a.mul_vec3(Vec3::X).abs_diff_eq(Vec3::Y, 1e-5));
        let b = Quat::from_rotation_arc(Vec3::X, Vec3::NEG_X);
        assert!(b.mul_vec3(Vec3::X).abs_diff_eq(Vec3::NEG_X, 1e-5));
    }

    #[test]
    fn euler_order_semantics_match_blender() {
        // XYZ: X applied first. Rotating +Y by 90deg about X gives +Z; then 90deg about Z leaves +Z.
        let m = euler_to_mat3(EulerOrder::XYZ, Vec3::new(PI / 2.0, 0.0, PI / 2.0));
        assert!(m.mul_vec3(Vec3::Y).abs_diff_eq(Vec3::Z, 1e-5));
        // and +X: X-rot leaves it, Z-rot sends it to +Y
        assert!(m.mul_vec3(Vec3::X).abs_diff_eq(Vec3::Y, 1e-5));
        // Quat path agrees with matrix path for every order
        let e = Vec3::new(0.3, -0.7, 1.1);
        for o in [EulerOrder::XYZ, EulerOrder::XZY, EulerOrder::YXZ, EulerOrder::YZX, EulerOrder::ZXY, EulerOrder::ZYX] {
            let a = euler_to_mat3(o, e);
            let b = Mat3::from_quat(Quat::from_euler(o, e));
            for c in 0..3 {
                assert!(a.cols[c].abs_diff_eq(b.cols[c], 1e-5), "order {:?}", o);
            }
        }
    }

    #[test]
    fn euler_roundtrip_all_orders() {
        let mut seed = 12345u64;
        for o in [EulerOrder::XYZ, EulerOrder::XZY, EulerOrder::YXZ, EulerOrder::YZX, EulerOrder::ZXY, EulerOrder::ZYX] {
            for _ in 0..200 {
                let e = Vec3::new((rng(&mut seed) - 0.5) * 6.0, (rng(&mut seed) - 0.5) * 2.8, (rng(&mut seed) - 0.5) * 6.0);
                let m = euler_to_mat3(o, e);
                let back = euler_from_mat3(o, &m, Some(e));
                let m2 = euler_to_mat3(o, back);
                for c in 0..3 {
                    assert!(m.cols[c].abs_diff_eq(m2.cols[c], 2e-4), "order {:?} e={:?} back={:?}", o, e, back);
                }
            }
            // gimbal lock must still reproduce the matrix
            let e = Vec3::new(0.4, PI / 2.0, 0.9);
            let m = euler_to_mat3(o, e);
            let m2 = euler_to_mat3(o, euler_from_mat3(o, &m, None));
            for c in 0..3 {
                assert!(m.cols[c].abs_diff_eq(m2.cols[c], 2e-3), "gimbal order {:?}", o);
            }
        }
    }

    #[test]
    fn perspective_maps_depth_0_to_1() {
        let p = Mat4::perspective_rh(radians(60.0), 1.5, 0.1, 100.0);
        let near = p.project_point3(Vec3::new(0.0, 0.0, -0.1)).unwrap();
        let far = p.project_point3(Vec3::new(0.0, 0.0, -100.0)).unwrap();
        assert!(near.z.abs() < 1e-5 && (far.z - 1.0).abs() < 1e-4);
        let o = Mat4::orthographic_rh(-2.0, 2.0, -1.0, 1.0, 0.1, 10.0);
        let c = o.project_point3(Vec3::new(2.0, 1.0, -10.0)).unwrap();
        assert!((c.x - 1.0).abs() < 1e-6 && (c.y - 1.0).abs() < 1e-6 && (c.z - 1.0).abs() < 1e-5);
    }

    #[test]
    fn look_at_z_up() {
        let v = Mat4::look_at_rh(Vec3::new(0.0, -5.0, 0.0), Vec3::ZERO, Vec3::Z);
        let p = v.transform_point3(Vec3::ZERO);
        assert!(p.abs_diff_eq(Vec3::new(0.0, 0.0, -5.0), 1e-5));
        // world +Z must be screen up (+Y in view space)
        assert!(v.transform_vector3(Vec3::Z).abs_diff_eq(Vec3::Y, 1e-5));
        // world +X must be screen right
        assert!(v.transform_vector3(Vec3::X).abs_diff_eq(Vec3::X, 1e-5));
    }

    #[test]
    fn ray_queries() {
        let r = Ray::new(Vec3::new(0.0, 0.0, 5.0), Vec3::new(0.0, 0.0, -1.0));
        let hit = r.intersect_triangle(Vec3::new(-1.0, -1.0, 0.0), Vec3::new(1.0, -1.0, 0.0), Vec3::new(0.0, 1.0, 0.0)).unwrap();
        assert!((hit.t - 5.0).abs() < 1e-5);
        let b = Aabb::new(Vec3::splat(-1.0), Vec3::splat(1.0));
        let (t0, t1) = b.ray_intersect(&r, 0.0, 100.0).unwrap();
        assert!((t0 - 4.0).abs() < 1e-5 && (t1 - 6.0).abs() < 1e-5);
        let miss = Ray::new(Vec3::new(3.0, 0.0, 5.0), Vec3::new(0.0, 0.0, -1.0));
        assert!(b.ray_intersect(&miss, 0.0, 100.0).is_none());
        // ray parallel to an axis, origin inside the slab
        let par = Ray::new(Vec3::new(0.0, 0.0, 5.0), Vec3::new(0.0, 0.0, -1.0));
        assert!(b.ray_intersect(&par, 0.0, 100.0).is_some());
        let (t, s, d) = Ray::new(Vec3::new(0.0, -3.0, 0.0), Vec3::Y).closest_to_line(Vec3::new(1.0, 0.0, 0.0), Vec3::Z).unwrap();
        assert!((t - 3.0).abs() < 1e-5 && s.abs() < 1e-5 && (d - 1.0).abs() < 1e-5);
        let pl = Plane::from_point_normal(Vec3::ZERO, Vec3::Z);
        assert!((r.intersect_plane(&pl).unwrap() - 5.0).abs() < 1e-5);
    }

    #[test]
    fn aabb_basics() {
        let mut b = Aabb::EMPTY;
        assert!(b.is_empty());
        b.expand_point(Vec3::new(1.0, 2.0, 3.0));
        b.expand_point(Vec3::new(-1.0, 0.0, 5.0));
        assert!(b.center().abs_diff_eq(Vec3::new(0.0, 1.0, 4.0), 1e-6));
        assert!(b.size().abs_diff_eq(Vec3::new(2.0, 2.0, 2.0), 1e-6));
        let t = b.transformed(&Mat4::from_translation(Vec3::new(10.0, 0.0, 0.0)));
        assert!((t.min.x - 9.0).abs() < 1e-6);
        assert_eq!(snap(0.37, 0.25), 0.25);
    }
}
