//! Aabb, Ray, Plane and small geometric queries used by picking, gizmos and BVHs.
use crate::mat::Mat4;
use crate::vec::Vec3;

#[derive(Clone, Copy, PartialEq, Debug)]
pub struct Aabb {
    pub min: Vec3,
    pub max: Vec3,
}

impl Default for Aabb {
    fn default() -> Self {
        Aabb::EMPTY
    }
}

impl Aabb {
    /// Inverted box that any `expand_*` call turns into a valid one.
    pub const EMPTY: Aabb = Aabb {
        min: Vec3 { x: f32::INFINITY, y: f32::INFINITY, z: f32::INFINITY },
        max: Vec3 { x: f32::NEG_INFINITY, y: f32::NEG_INFINITY, z: f32::NEG_INFINITY },
    };
    pub fn new(min: Vec3, max: Vec3) -> Aabb {
        Aabb { min, max }
    }
    pub fn from_points<I: IntoIterator<Item = Vec3>>(pts: I) -> Aabb {
        let mut b = Aabb::EMPTY;
        for p in pts {
            b.expand_point(p);
        }
        b
    }
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.min.x > self.max.x || self.min.y > self.max.y || self.min.z > self.max.z
    }
    #[inline]
    pub fn expand_point(&mut self, p: Vec3) {
        self.min = self.min.min(p);
        self.max = self.max.max(p);
    }
    pub fn expand_aabb(&mut self, o: &Aabb) {
        if !o.is_empty() {
            self.min = self.min.min(o.min);
            self.max = self.max.max(o.max);
        }
    }
    pub fn union(&self, o: &Aabb) -> Aabb {
        let mut r = *self;
        r.expand_aabb(o);
        r
    }
    pub fn center(&self) -> Vec3 {
        if self.is_empty() {
            Vec3::ZERO
        } else {
            (self.min + self.max) * 0.5
        }
    }
    pub fn size(&self) -> Vec3 {
        if self.is_empty() {
            Vec3::ZERO
        } else {
            self.max - self.min
        }
    }
    pub fn half_extents(&self) -> Vec3 {
        self.size() * 0.5
    }
    /// Radius of the bounding sphere around `center()`.
    pub fn radius(&self) -> f32 {
        self.half_extents().length()
    }
    pub fn surface_area(&self) -> f32 {
        if self.is_empty() {
            return 0.0;
        }
        let d = self.size();
        2.0 * (d.x * d.y + d.y * d.z + d.z * d.x)
    }
    pub fn contains_point(&self, p: Vec3) -> bool {
        p.x >= self.min.x && p.x <= self.max.x && p.y >= self.min.y && p.y <= self.max.y && p.z >= self.min.z && p.z <= self.max.z
    }
    pub fn intersects(&self, o: &Aabb) -> bool {
        self.min.x <= o.max.x && self.max.x >= o.min.x && self.min.y <= o.max.y && self.max.y >= o.min.y && self.min.z <= o.max.z && self.max.z >= o.min.z
    }
    pub fn inflate(&self, d: f32) -> Aabb {
        Aabb { min: self.min - Vec3::splat(d), max: self.max + Vec3::splat(d) }
    }
    pub fn distance_squared_to_point(&self, p: Vec3) -> f32 {
        let c = p.clamp(self.min, self.max);
        c.distance_squared(p)
    }
    /// Bounds of the 8 transformed corners.
    pub fn transformed(&self, m: &Mat4) -> Aabb {
        if self.is_empty() {
            return *self;
        }
        let mut b = Aabb::EMPTY;
        for i in 0..8 {
            let c = Vec3::new(
                if i & 1 == 0 { self.min.x } else { self.max.x },
                if i & 2 == 0 { self.min.y } else { self.max.y },
                if i & 4 == 0 { self.min.z } else { self.max.z },
            );
            b.expand_point(m.transform_point3(c));
        }
        b
    }
    /// Slab test. Returns (t_near, t_far) clipped to [t_min, t_max] when the ray hits.
    pub fn ray_intersect(&self, ray: &Ray, t_min: f32, t_max: f32) -> Option<(f32, f32)> {
        let (mut t0, mut t1) = (t_min, t_max);
        for a in 0..3 {
            let inv = 1.0 / ray.dir[a];
            let mut n = (self.min[a] - ray.origin[a]) * inv;
            let mut f = (self.max[a] - ray.origin[a]) * inv;
            if n > f {
                std::mem::swap(&mut n, &mut f);
            }
            // NaN (0 * inf) falls through as "no constraint" when the origin lies in the slab
            if n.is_nan() || f.is_nan() {
                if ray.origin[a] < self.min[a] || ray.origin[a] > self.max[a] {
                    return None;
                }
                continue;
            }
            t0 = t0.max(n);
            t1 = t1.min(f);
            if t0 > t1 {
                return None;
            }
        }
        Some((t0, t1))
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub struct Ray {
    pub origin: Vec3,
    /// Unit length direction.
    pub dir: Vec3,
}

#[derive(Clone, Copy, Debug)]
pub struct TriHit {
    pub t: f32,
    /// Barycentric coordinates of vertices 1 and 2 (vertex 0 weight is `1 - u - v`).
    pub u: f32,
    pub v: f32,
}

impl Ray {
    pub fn new(origin: Vec3, dir: Vec3) -> Ray {
        Ray { origin, dir: dir.normalize() }
    }
    #[inline]
    pub fn at(&self, t: f32) -> Vec3 {
        self.origin + self.dir * t
    }
    /// Moller-Trumbore, double sided.
    pub fn intersect_triangle(&self, a: Vec3, b: Vec3, c: Vec3) -> Option<TriHit> {
        let e1 = b - a;
        let e2 = c - a;
        let p = self.dir.cross(e2);
        let det = e1.dot(p);
        if det.abs() < 1e-12 {
            return None;
        }
        let inv = 1.0 / det;
        let s = self.origin - a;
        let u = s.dot(p) * inv;
        if !(0.0..=1.0).contains(&u) {
            return None;
        }
        let q = s.cross(e1);
        let v = self.dir.dot(q) * inv;
        if v < 0.0 || u + v > 1.0 {
            return None;
        }
        let t = e2.dot(q) * inv;
        if t < 0.0 {
            return None;
        }
        Some(TriHit { t, u, v })
    }
    pub fn intersect_plane(&self, plane: &Plane) -> Option<f32> {
        let d = plane.normal.dot(self.dir);
        if d.abs() < 1e-9 {
            return None;
        }
        let t = -(plane.normal.dot(self.origin) + plane.d) / d;
        if t >= 0.0 {
            Some(t)
        } else {
            None
        }
    }
    pub fn distance_to_point(&self, p: Vec3) -> f32 {
        let t = (p - self.origin).dot(self.dir).max(0.0);
        self.at(t).distance(p)
    }
    /// Closest approach between this ray and the infinite line `(p, d)`.
    /// Returns (t on the ray, s along the line, distance); None if (almost) parallel.
    pub fn closest_to_line(&self, p: Vec3, d: Vec3) -> Option<(f32, f32, f32)> {
        let w0 = self.origin - p;
        let a = self.dir.dot(self.dir);
        let b = self.dir.dot(d);
        let c = d.dot(d);
        let dd = self.dir.dot(w0);
        let e = d.dot(w0);
        let den = a * c - b * b;
        if den.abs() < 1e-9 * a * c {
            return None;
        }
        let t = (b * e - c * dd) / den;
        let s = (a * e - b * dd) / den;
        let dist = (self.at(t) - (p + d * s)).length();
        Some((t, s, dist))
    }
    /// Closest approach to the finite segment a..b: (t on the ray, param 0..1 on the segment, distance).
    pub fn closest_to_segment(&self, a: Vec3, b: Vec3) -> (f32, f32, f32) {
        let d = b - a;
        let len2 = d.dot(d);
        if len2 < 1e-20 {
            let t = (a - self.origin).dot(self.dir).max(0.0);
            return (t, 0.0, self.at(t).distance(a));
        }
        match self.closest_to_line(a, d) {
            Some((_, s, _)) => {
                let s = s.clamp(0.0, 1.0);
                let q = a + d * s;
                let t = (q - self.origin).dot(self.dir).max(0.0);
                (t, s, self.at(t).distance(q))
            }
            None => {
                let t = (a - self.origin).dot(self.dir).max(0.0);
                (t, 0.0, self.at(t).distance(a))
            }
        }
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub struct Plane {
    pub normal: Vec3,
    /// Plane equation: normal . p + d = 0
    pub d: f32,
}

impl Plane {
    pub fn from_point_normal(p: Vec3, n: Vec3) -> Plane {
        let n = n.normalize();
        Plane { normal: n, d: -n.dot(p) }
    }
    #[inline]
    pub fn signed_distance(&self, p: Vec3) -> f32 {
        self.normal.dot(p) + self.d
    }
}
