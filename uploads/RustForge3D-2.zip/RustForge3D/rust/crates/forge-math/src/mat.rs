//! Mat3 / Mat4, column-major, right-handed, depth range 0..1 (wgpu convention).
use crate::quat::Quat;
use crate::vec::{Vec3, Vec4};
use std::ops::Mul;

#[derive(Clone, Copy, PartialEq, Debug)]
pub struct Mat3 {
    pub cols: [Vec3; 3],
}
#[derive(Clone, Copy, PartialEq, Debug)]
pub struct Mat4 {
    pub cols: [Vec4; 4],
}

impl Default for Mat3 {
    fn default() -> Self {
        Mat3::IDENTITY
    }
}
impl Default for Mat4 {
    fn default() -> Self {
        Mat4::IDENTITY
    }
}

impl Mat3 {
    pub const IDENTITY: Mat3 = Mat3 { cols: [Vec3::X, Vec3::Y, Vec3::Z] };
    pub const ZERO: Mat3 = Mat3 { cols: [Vec3::ZERO, Vec3::ZERO, Vec3::ZERO] };
    #[inline]
    pub const fn from_cols(x: Vec3, y: Vec3, z: Vec3) -> Mat3 {
        Mat3 { cols: [x, y, z] }
    }
    pub fn from_diagonal(d: Vec3) -> Mat3 {
        Mat3::from_cols(Vec3::new(d.x, 0.0, 0.0), Vec3::new(0.0, d.y, 0.0), Vec3::new(0.0, 0.0, d.z))
    }
    pub fn from_quat(q: Quat) -> Mat3 {
        let (x, y, z, w) = (q.x, q.y, q.z, q.w);
        let (x2, y2, z2) = (x + x, y + y, z + z);
        let (xx, xy, xz) = (x * x2, x * y2, x * z2);
        let (yy, yz, zz) = (y * y2, y * z2, z * z2);
        let (wx, wy, wz) = (w * x2, w * y2, w * z2);
        Mat3::from_cols(
            Vec3::new(1.0 - (yy + zz), xy + wz, xz - wy),
            Vec3::new(xy - wz, 1.0 - (xx + zz), yz + wx),
            Vec3::new(xz + wy, yz - wx, 1.0 - (xx + yy)),
        )
    }
    pub fn from_rotation_x(a: f32) -> Mat3 {
        let (s, c) = a.sin_cos();
        Mat3::from_cols(Vec3::X, Vec3::new(0.0, c, s), Vec3::new(0.0, -s, c))
    }
    pub fn from_rotation_y(a: f32) -> Mat3 {
        let (s, c) = a.sin_cos();
        Mat3::from_cols(Vec3::new(c, 0.0, -s), Vec3::Y, Vec3::new(s, 0.0, c))
    }
    pub fn from_rotation_z(a: f32) -> Mat3 {
        let (s, c) = a.sin_cos();
        Mat3::from_cols(Vec3::new(c, s, 0.0), Vec3::new(-s, c, 0.0), Vec3::Z)
    }
    /// Element at (row, col).
    #[inline]
    pub fn at(&self, row: usize, col: usize) -> f32 {
        self.cols[col][row]
    }
    pub fn row(&self, r: usize) -> Vec3 {
        Vec3::new(self.cols[0][r], self.cols[1][r], self.cols[2][r])
    }
    pub fn transpose(&self) -> Mat3 {
        Mat3::from_cols(self.row(0), self.row(1), self.row(2))
    }
    pub fn determinant(&self) -> f32 {
        self.cols[0].dot(self.cols[1].cross(self.cols[2]))
    }
    pub fn try_inverse(&self) -> Option<Mat3> {
        let (a, b, c) = (self.cols[0], self.cols[1], self.cols[2]);
        let r0 = b.cross(c);
        let r1 = c.cross(a);
        let r2 = a.cross(b);
        let det = a.dot(r0);
        if det == 0.0 || !det.is_finite() {
            return None;
        }
        let inv = 1.0 / det;
        Some(Mat3::from_cols(
            Vec3::new(r0.x, r1.x, r2.x) * inv,
            Vec3::new(r0.y, r1.y, r2.y) * inv,
            Vec3::new(r0.z, r1.z, r2.z) * inv,
        ))
    }
    /// Inverse, or identity when singular (never NaN).
    pub fn inverse(&self) -> Mat3 {
        self.try_inverse().unwrap_or(Mat3::IDENTITY)
    }
    #[inline]
    pub fn mul_vec3(&self, v: Vec3) -> Vec3 {
        self.cols[0] * v.x + self.cols[1] * v.y + self.cols[2] * v.z
    }
    pub fn mul_mat3(&self, o: &Mat3) -> Mat3 {
        Mat3::from_cols(self.mul_vec3(o.cols[0]), self.mul_vec3(o.cols[1]), self.mul_vec3(o.cols[2]))
    }
    pub fn to_cols_array(&self) -> [f32; 9] {
        let c = &self.cols;
        [c[0].x, c[0].y, c[0].z, c[1].x, c[1].y, c[1].z, c[2].x, c[2].y, c[2].z]
    }
}
impl Mul for Mat3 {
    type Output = Mat3;
    fn mul(self, o: Mat3) -> Mat3 {
        self.mul_mat3(&o)
    }
}
impl Mul<Vec3> for Mat3 {
    type Output = Vec3;
    fn mul(self, v: Vec3) -> Vec3 {
        self.mul_vec3(v)
    }
}

fn invert16(m: &[f64; 16]) -> Option<[f64; 16]> {
    let mut inv = [0f64; 16];
    inv[0] = m[5] * m[10] * m[15] - m[5] * m[11] * m[14] - m[9] * m[6] * m[15] + m[9] * m[7] * m[14] + m[13] * m[6] * m[11] - m[13] * m[7] * m[10];
    inv[4] = -m[4] * m[10] * m[15] + m[4] * m[11] * m[14] + m[8] * m[6] * m[15] - m[8] * m[7] * m[14] - m[12] * m[6] * m[11] + m[12] * m[7] * m[10];
    inv[8] = m[4] * m[9] * m[15] - m[4] * m[11] * m[13] - m[8] * m[5] * m[15] + m[8] * m[7] * m[13] + m[12] * m[5] * m[11] - m[12] * m[7] * m[9];
    inv[12] = -m[4] * m[9] * m[14] + m[4] * m[10] * m[13] + m[8] * m[5] * m[14] - m[8] * m[6] * m[13] - m[12] * m[5] * m[10] + m[12] * m[6] * m[9];
    inv[1] = -m[1] * m[10] * m[15] + m[1] * m[11] * m[14] + m[9] * m[2] * m[15] - m[9] * m[3] * m[14] - m[13] * m[2] * m[11] + m[13] * m[3] * m[10];
    inv[5] = m[0] * m[10] * m[15] - m[0] * m[11] * m[14] - m[8] * m[2] * m[15] + m[8] * m[3] * m[14] + m[12] * m[2] * m[11] - m[12] * m[3] * m[10];
    inv[9] = -m[0] * m[9] * m[15] + m[0] * m[11] * m[13] + m[8] * m[1] * m[15] - m[8] * m[3] * m[13] - m[12] * m[1] * m[11] + m[12] * m[3] * m[9];
    inv[13] = m[0] * m[9] * m[14] - m[0] * m[10] * m[13] - m[8] * m[1] * m[14] + m[8] * m[2] * m[13] + m[12] * m[1] * m[10] - m[12] * m[2] * m[9];
    inv[2] = m[1] * m[6] * m[15] - m[1] * m[7] * m[14] - m[5] * m[2] * m[15] + m[5] * m[3] * m[14] + m[13] * m[2] * m[7] - m[13] * m[3] * m[6];
    inv[6] = -m[0] * m[6] * m[15] + m[0] * m[7] * m[14] + m[4] * m[2] * m[15] - m[4] * m[3] * m[14] - m[12] * m[2] * m[7] + m[12] * m[3] * m[6];
    inv[10] = m[0] * m[5] * m[15] - m[0] * m[7] * m[13] - m[4] * m[1] * m[15] + m[4] * m[3] * m[13] + m[12] * m[1] * m[7] - m[12] * m[3] * m[5];
    inv[14] = -m[0] * m[5] * m[14] + m[0] * m[6] * m[13] + m[4] * m[1] * m[14] - m[4] * m[2] * m[13] - m[12] * m[1] * m[6] + m[12] * m[2] * m[5];
    inv[3] = -m[1] * m[6] * m[11] + m[1] * m[7] * m[10] + m[5] * m[2] * m[11] - m[5] * m[3] * m[10] - m[9] * m[2] * m[7] + m[9] * m[3] * m[6];
    inv[7] = m[0] * m[6] * m[11] - m[0] * m[7] * m[10] - m[4] * m[2] * m[11] + m[4] * m[3] * m[10] + m[8] * m[2] * m[7] - m[8] * m[3] * m[6];
    inv[11] = -m[0] * m[5] * m[11] + m[0] * m[7] * m[9] + m[4] * m[1] * m[11] - m[4] * m[3] * m[9] - m[8] * m[1] * m[7] + m[8] * m[3] * m[5];
    inv[15] = m[0] * m[5] * m[10] - m[0] * m[6] * m[9] - m[4] * m[1] * m[10] + m[4] * m[2] * m[9] + m[8] * m[1] * m[6] - m[8] * m[2] * m[5];
    let det = m[0] * inv[0] + m[1] * inv[4] + m[2] * inv[8] + m[3] * inv[12];
    if det == 0.0 || !det.is_finite() {
        return None;
    }
    let id = 1.0 / det;
    for v in inv.iter_mut() {
        *v *= id;
    }
    Some(inv)
}

impl Mat4 {
    pub const IDENTITY: Mat4 = Mat4 {
        cols: [
            Vec4 { x: 1.0, y: 0.0, z: 0.0, w: 0.0 },
            Vec4 { x: 0.0, y: 1.0, z: 0.0, w: 0.0 },
            Vec4 { x: 0.0, y: 0.0, z: 1.0, w: 0.0 },
            Vec4 { x: 0.0, y: 0.0, z: 0.0, w: 1.0 },
        ],
    };
    pub const ZERO: Mat4 = Mat4 { cols: [Vec4::ZERO; 4] };

    #[inline]
    pub const fn from_cols(x: Vec4, y: Vec4, z: Vec4, w: Vec4) -> Mat4 {
        Mat4 { cols: [x, y, z, w] }
    }
    pub fn from_cols_array(a: &[f32; 16]) -> Mat4 {
        Mat4::from_cols(
            Vec4::new(a[0], a[1], a[2], a[3]),
            Vec4::new(a[4], a[5], a[6], a[7]),
            Vec4::new(a[8], a[9], a[10], a[11]),
            Vec4::new(a[12], a[13], a[14], a[15]),
        )
    }
    pub fn to_cols_array(&self) -> [f32; 16] {
        let c = &self.cols;
        [
            c[0].x, c[0].y, c[0].z, c[0].w, c[1].x, c[1].y, c[1].z, c[1].w, c[2].x, c[2].y, c[2].z, c[2].w, c[3].x, c[3].y, c[3].z,
            c[3].w,
        ]
    }
    pub fn from_translation(t: Vec3) -> Mat4 {
        let mut m = Mat4::IDENTITY;
        m.cols[3] = Vec4::new(t.x, t.y, t.z, 1.0);
        m
    }
    pub fn from_scale(s: Vec3) -> Mat4 {
        Mat4::from_cols(
            Vec4::new(s.x, 0.0, 0.0, 0.0),
            Vec4::new(0.0, s.y, 0.0, 0.0),
            Vec4::new(0.0, 0.0, s.z, 0.0),
            Vec4::new(0.0, 0.0, 0.0, 1.0),
        )
    }
    pub fn from_mat3(m: Mat3) -> Mat4 {
        Mat4::from_cols(m.cols[0].extend(0.0), m.cols[1].extend(0.0), m.cols[2].extend(0.0), Vec4::new(0.0, 0.0, 0.0, 1.0))
    }
    pub fn from_quat(q: Quat) -> Mat4 {
        Mat4::from_mat3(Mat3::from_quat(q))
    }
    /// T * R * S
    pub fn from_scale_rotation_translation(scale: Vec3, rot: Quat, trans: Vec3) -> Mat4 {
        let r = Mat3::from_quat(rot);
        Mat4::from_cols(
            (r.cols[0] * scale.x).extend(0.0),
            (r.cols[1] * scale.y).extend(0.0),
            (r.cols[2] * scale.z).extend(0.0),
            trans.extend(1.0),
        )
    }
    /// T * R3 * S where R3 is an arbitrary rotation matrix.
    pub fn from_trs_mat3(scale: Vec3, rot: &Mat3, trans: Vec3) -> Mat4 {
        Mat4::from_cols(
            (rot.cols[0] * scale.x).extend(0.0),
            (rot.cols[1] * scale.y).extend(0.0),
            (rot.cols[2] * scale.z).extend(0.0),
            trans.extend(1.0),
        )
    }
    /// Right-handed perspective, depth 0..1, vertical field of view in radians.
    pub fn perspective_rh(fov_y: f32, aspect: f32, near: f32, far: f32) -> Mat4 {
        let (s, c) = (0.5 * fov_y).sin_cos();
        let h = c / s;
        let w = h / aspect;
        let r = far / (near - far);
        Mat4::from_cols(Vec4::new(w, 0.0, 0.0, 0.0), Vec4::new(0.0, h, 0.0, 0.0), Vec4::new(0.0, 0.0, r, -1.0), Vec4::new(0.0, 0.0, r * near, 0.0))
    }
    /// Right-handed orthographic, depth 0..1.
    pub fn orthographic_rh(left: f32, right: f32, bottom: f32, top: f32, near: f32, far: f32) -> Mat4 {
        let rw = 1.0 / (right - left);
        let rh = 1.0 / (top - bottom);
        let r = 1.0 / (near - far);
        Mat4::from_cols(
            Vec4::new(rw * 2.0, 0.0, 0.0, 0.0),
            Vec4::new(0.0, rh * 2.0, 0.0, 0.0),
            Vec4::new(0.0, 0.0, r, 0.0),
            Vec4::new(-(left + right) * rw, -(top + bottom) * rh, r * near, 1.0),
        )
    }
    /// View matrix looking from `eye` towards `center` (right-handed, camera looks down -Z).
    pub fn look_at_rh(eye: Vec3, center: Vec3, up: Vec3) -> Mat4 {
        let f = (center - eye).normalize();
        let mut s = f.cross(up);
        if s.length_squared() < 1e-12 {
            s = f.any_orthogonal();
        }
        let s = s.normalize();
        let u = s.cross(f);
        Mat4::from_cols(
            Vec4::new(s.x, u.x, -f.x, 0.0),
            Vec4::new(s.y, u.y, -f.y, 0.0),
            Vec4::new(s.z, u.z, -f.z, 0.0),
            Vec4::new(-s.dot(eye), -u.dot(eye), f.dot(eye), 1.0),
        )
    }
    #[inline]
    pub fn col(&self, i: usize) -> Vec4 {
        self.cols[i]
    }
    /// Element at (row, col).
    #[inline]
    pub fn at(&self, row: usize, col: usize) -> f32 {
        self.cols[col][row]
    }
    #[inline]
    pub fn translation(&self) -> Vec3 {
        self.cols[3].truncate()
    }
    pub fn set_translation(&mut self, t: Vec3) {
        self.cols[3] = Vec4::new(t.x, t.y, t.z, self.cols[3].w);
    }
    pub fn mat3(&self) -> Mat3 {
        Mat3::from_cols(self.cols[0].truncate(), self.cols[1].truncate(), self.cols[2].truncate())
    }
    pub fn transpose(&self) -> Mat4 {
        let c = &self.cols;
        Mat4::from_cols(
            Vec4::new(c[0].x, c[1].x, c[2].x, c[3].x),
            Vec4::new(c[0].y, c[1].y, c[2].y, c[3].y),
            Vec4::new(c[0].z, c[1].z, c[2].z, c[3].z),
            Vec4::new(c[0].w, c[1].w, c[2].w, c[3].w),
        )
    }
    pub fn determinant(&self) -> f32 {
        let a = self.to_cols_array().map(|v| v as f64);
        let mut inv0 = [0f64; 4];
        // cofactors of the first row via the same expansion invert16 uses
        inv0[0] = a[5] * a[10] * a[15] - a[5] * a[11] * a[14] - a[9] * a[6] * a[15] + a[9] * a[7] * a[14] + a[13] * a[6] * a[11] - a[13] * a[7] * a[10];
        inv0[1] = -a[4] * a[10] * a[15] + a[4] * a[11] * a[14] + a[8] * a[6] * a[15] - a[8] * a[7] * a[14] - a[12] * a[6] * a[11] + a[12] * a[7] * a[10];
        inv0[2] = a[4] * a[9] * a[15] - a[4] * a[11] * a[13] - a[8] * a[5] * a[15] + a[8] * a[7] * a[13] + a[12] * a[5] * a[11] - a[12] * a[7] * a[9];
        inv0[3] = -a[4] * a[9] * a[14] + a[4] * a[10] * a[13] + a[8] * a[5] * a[14] - a[8] * a[6] * a[13] - a[12] * a[5] * a[10] + a[12] * a[6] * a[9];
        (a[0] * inv0[0] + a[1] * inv0[1] + a[2] * inv0[2] + a[3] * inv0[3]) as f32
    }
    pub fn try_inverse(&self) -> Option<Mat4> {
        let a = self.to_cols_array().map(|v| v as f64);
        let inv = invert16(&a)?;
        let mut out = [0f32; 16];
        for i in 0..16 {
            out[i] = inv[i] as f32;
        }
        Some(Mat4::from_cols_array(&out))
    }
    /// Inverse, or identity when singular (never NaN).
    pub fn inverse(&self) -> Mat4 {
        self.try_inverse().unwrap_or(Mat4::IDENTITY)
    }
    #[inline]
    pub fn mul_vec4(&self, v: Vec4) -> Vec4 {
        self.cols[0] * v.x + self.cols[1] * v.y + self.cols[2] * v.z + self.cols[3] * v.w
    }
    pub fn mul_mat4(&self, o: &Mat4) -> Mat4 {
        Mat4::from_cols(self.mul_vec4(o.cols[0]), self.mul_vec4(o.cols[1]), self.mul_vec4(o.cols[2]), self.mul_vec4(o.cols[3]))
    }
    #[inline]
    pub fn transform_point3(&self, p: Vec3) -> Vec3 {
        (self.cols[0] * p.x + self.cols[1] * p.y + self.cols[2] * p.z + self.cols[3]).truncate()
    }
    #[inline]
    pub fn transform_vector3(&self, v: Vec3) -> Vec3 {
        (self.cols[0] * v.x + self.cols[1] * v.y + self.cols[2] * v.z).truncate()
    }
    /// Full projective transform with perspective divide. Returns None when w is ~0.
    pub fn project_point3(&self, p: Vec3) -> Option<Vec3> {
        let v = self.mul_vec4(p.extend(1.0));
        if v.w.abs() < 1e-12 {
            None
        } else {
            Some(Vec3::new(v.x / v.w, v.y / v.w, v.z / v.w))
        }
    }
    /// Inverse-transpose of the upper 3x3: use for transforming normals.
    pub fn normal_matrix(&self) -> Mat3 {
        self.mat3().inverse().transpose()
    }
    /// Decompose a T*R*S matrix. A negative determinant is folded into a negative X scale.
    pub fn to_scale_rotation_translation(&self) -> (Vec3, Quat, Vec3) {
        let c0 = self.cols[0].truncate();
        let c1 = self.cols[1].truncate();
        let c2 = self.cols[2].truncate();
        let mut sx = c0.length();
        let sy = c1.length();
        let sz = c2.length();
        if self.mat3().determinant() < 0.0 {
            sx = -sx;
        }
        let inv = |s: f32| if s.abs() > 1e-20 { 1.0 / s } else { 0.0 };
        let r = Mat3::from_cols(c0 * inv(sx), c1 * inv(sy), c2 * inv(sz));
        (Vec3::new(sx, sy, sz), Quat::from_mat3(&r), self.translation())
    }
}
impl Mul for Mat4 {
    type Output = Mat4;
    fn mul(self, o: Mat4) -> Mat4 {
        self.mul_mat4(&o)
    }
}
impl Mul<Vec4> for Mat4 {
    type Output = Vec4;
    fn mul(self, v: Vec4) -> Vec4 {
        self.mul_vec4(v)
    }
}
