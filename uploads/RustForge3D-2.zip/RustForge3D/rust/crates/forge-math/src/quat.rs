//! Unit quaternion rotations and Blender-style Euler conversions.
use crate::mat::Mat3;
use crate::vec::Vec3;
use std::ops::Mul;

/// Rotation order of an Euler triple. `XYZ` means: rotate about X first, then Y, then Z
/// (matrix `Rz * Ry * Rx`), exactly like Blender's `rotation_mode = 'XYZ'`.
#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub enum EulerOrder {
    #[default]
    XYZ,
    XZY,
    YXZ,
    YZX,
    ZXY,
    ZYX,
}

impl EulerOrder {
    /// Axis indices in application order (first applied first).
    pub fn axes(self) -> [usize; 3] {
        match self {
            EulerOrder::XYZ => [0, 1, 2],
            EulerOrder::XZY => [0, 2, 1],
            EulerOrder::YXZ => [1, 0, 2],
            EulerOrder::YZX => [1, 2, 0],
            EulerOrder::ZXY => [2, 0, 1],
            EulerOrder::ZYX => [2, 1, 0],
        }
    }
    pub fn name(self) -> &'static str {
        match self {
            EulerOrder::XYZ => "XYZ",
            EulerOrder::XZY => "XZY",
            EulerOrder::YXZ => "YXZ",
            EulerOrder::YZX => "YZX",
            EulerOrder::ZXY => "ZXY",
            EulerOrder::ZYX => "ZYX",
        }
    }
    pub fn from_name(s: &str) -> Option<EulerOrder> {
        Some(match s {
            "XYZ" => EulerOrder::XYZ,
            "XZY" => EulerOrder::XZY,
            "YXZ" => EulerOrder::YXZ,
            "YZX" => EulerOrder::YZX,
            "ZXY" => EulerOrder::ZXY,
            "ZYX" => EulerOrder::ZYX,
            _ => return None,
        })
    }
    fn is_odd(self) -> bool {
        matches!(self, EulerOrder::XZY | EulerOrder::YXZ | EulerOrder::ZYX)
    }
}

#[derive(Clone, Copy, PartialEq, Debug)]
pub struct Quat {
    pub x: f32,
    pub y: f32,
    pub z: f32,
    pub w: f32,
}

impl Default for Quat {
    fn default() -> Self {
        Quat::IDENTITY
    }
}

fn axis_matrix(axis: usize, a: f32) -> Mat3 {
    match axis {
        0 => Mat3::from_rotation_x(a),
        1 => Mat3::from_rotation_y(a),
        _ => Mat3::from_rotation_z(a),
    }
}

impl Quat {
    pub const IDENTITY: Quat = Quat { x: 0.0, y: 0.0, z: 0.0, w: 1.0 };
    #[inline]
    pub const fn from_xyzw(x: f32, y: f32, z: f32, w: f32) -> Quat {
        Quat { x, y, z, w }
    }
    pub fn from_axis_angle(axis: Vec3, angle: f32) -> Quat {
        let a = axis.normalize();
        let (s, c) = (angle * 0.5).sin_cos();
        Quat { x: a.x * s, y: a.y * s, z: a.z * s, w: c }
    }
    pub fn from_rotation_x(a: f32) -> Quat {
        Quat::from_axis_angle(Vec3::X, a)
    }
    pub fn from_rotation_y(a: f32) -> Quat {
        Quat::from_axis_angle(Vec3::Y, a)
    }
    pub fn from_rotation_z(a: f32) -> Quat {
        Quat::from_axis_angle(Vec3::Z, a)
    }
    #[inline]
    pub fn dot(self, o: Quat) -> f32 {
        self.x * o.x + self.y * o.y + self.z * o.z + self.w * o.w
    }
    #[inline]
    pub fn length(self) -> f32 {
        self.dot(self).sqrt()
    }
    pub fn normalize(self) -> Quat {
        let l = self.length();
        if l > 1e-20 && l.is_finite() {
            Quat { x: self.x / l, y: self.y / l, z: self.z / l, w: self.w / l }
        } else {
            Quat::IDENTITY
        }
    }
    #[inline]
    pub fn conjugate(self) -> Quat {
        Quat { x: -self.x, y: -self.y, z: -self.z, w: self.w }
    }
    pub fn inverse(self) -> Quat {
        let d = self.dot(self);
        if d > 1e-30 {
            let c = self.conjugate();
            Quat { x: c.x / d, y: c.y / d, z: c.z / d, w: c.w / d }
        } else {
            Quat::IDENTITY
        }
    }
    pub fn mul_quat(self, o: Quat) -> Quat {
        Quat {
            x: self.w * o.x + self.x * o.w + self.y * o.z - self.z * o.y,
            y: self.w * o.y - self.x * o.z + self.y * o.w + self.z * o.x,
            z: self.w * o.z + self.x * o.y - self.y * o.x + self.z * o.w,
            w: self.w * o.w - self.x * o.x - self.y * o.y - self.z * o.z,
        }
    }
    pub fn mul_vec3(self, v: Vec3) -> Vec3 {
        let q = Vec3::new(self.x, self.y, self.z);
        let t = q.cross(v) * 2.0;
        v + t * self.w + q.cross(t)
    }
    pub fn slerp(self, mut b: Quat, t: f32) -> Quat {
        let mut d = self.dot(b);
        if d < 0.0 {
            b = Quat { x: -b.x, y: -b.y, z: -b.z, w: -b.w };
            d = -d;
        }
        if d > 0.9995 {
            return Quat {
                x: self.x + (b.x - self.x) * t,
                y: self.y + (b.y - self.y) * t,
                z: self.z + (b.z - self.z) * t,
                w: self.w + (b.w - self.w) * t,
            }
            .normalize();
        }
        let th = d.clamp(-1.0, 1.0).acos();
        let s = th.sin();
        let (wa, wb) = (((1.0 - t) * th).sin() / s, (t * th).sin() / s);
        Quat { x: self.x * wa + b.x * wb, y: self.y * wa + b.y * wb, z: self.z * wa + b.z * wb, w: self.w * wa + b.w * wb }
    }
    /// Shortest rotation taking unit vector `from` to unit vector `to`.
    pub fn from_rotation_arc(from: Vec3, to: Vec3) -> Quat {
        let (f, t) = (from.normalize(), to.normalize());
        let d = f.dot(t);
        if d > 0.999999 {
            return Quat::IDENTITY;
        }
        if d < -0.999999 {
            return Quat::from_axis_angle(f.any_orthogonal(), std::f32::consts::PI);
        }
        let c = f.cross(t);
        Quat { x: c.x, y: c.y, z: c.z, w: 1.0 + d }.normalize()
    }
    pub fn to_axis_angle(self) -> (Vec3, f32) {
        let q = if self.w < 0.0 { Quat { x: -self.x, y: -self.y, z: -self.z, w: -self.w } } else { self };
        let s = (q.x * q.x + q.y * q.y + q.z * q.z).sqrt();
        if s < 1e-8 {
            (Vec3::Z, 0.0)
        } else {
            (Vec3::new(q.x / s, q.y / s, q.z / s), 2.0 * s.atan2(q.w))
        }
    }
    pub fn from_mat3(m: &Mat3) -> Quat {
        let (m00, m11, m22) = (m.at(0, 0), m.at(1, 1), m.at(2, 2));
        let tr = m00 + m11 + m22;
        let q = if tr > 0.0 {
            let s = (tr + 1.0).sqrt() * 2.0;
            Quat { w: 0.25 * s, x: (m.at(2, 1) - m.at(1, 2)) / s, y: (m.at(0, 2) - m.at(2, 0)) / s, z: (m.at(1, 0) - m.at(0, 1)) / s }
        } else if m00 > m11 && m00 > m22 {
            let s = (1.0 + m00 - m11 - m22).sqrt() * 2.0;
            Quat { w: (m.at(2, 1) - m.at(1, 2)) / s, x: 0.25 * s, y: (m.at(0, 1) + m.at(1, 0)) / s, z: (m.at(0, 2) + m.at(2, 0)) / s }
        } else if m11 > m22 {
            let s = (1.0 + m11 - m00 - m22).sqrt() * 2.0;
            Quat { w: (m.at(0, 2) - m.at(2, 0)) / s, x: (m.at(0, 1) + m.at(1, 0)) / s, y: 0.25 * s, z: (m.at(1, 2) + m.at(2, 1)) / s }
        } else {
            let s = (1.0 + m22 - m00 - m11).sqrt() * 2.0;
            Quat { w: (m.at(1, 0) - m.at(0, 1)) / s, x: (m.at(0, 2) + m.at(2, 0)) / s, y: (m.at(1, 2) + m.at(2, 1)) / s, z: 0.25 * s }
        };
        q.normalize()
    }
    pub fn to_mat3(self) -> Mat3 {
        Mat3::from_quat(self)
    }
    /// Blender-style Euler: angles `e = (about X, about Y, about Z)` applied in `order`.
    pub fn from_euler(order: EulerOrder, e: Vec3) -> Quat {
        let ax = order.axes();
        let mut q = Quat::IDENTITY;
        for &a in ax.iter() {
            q = Quat::from_axis_angle(Vec3::AXES[a], e[a]).mul_quat(q);
        }
        q
    }
    pub fn to_euler(self, order: EulerOrder) -> Vec3 {
        euler_from_mat3(order, &Mat3::from_quat(self), None)
    }
}

impl Mul for Quat {
    type Output = Quat;
    fn mul(self, o: Quat) -> Quat {
        self.mul_quat(o)
    }
}
impl Mul<Vec3> for Quat {
    type Output = Vec3;
    fn mul(self, v: Vec3) -> Vec3 {
        self.mul_vec3(v)
    }
}

/// Rotation matrix for Euler angles `e` in `order` (first axis applied first).
pub fn euler_to_mat3(order: EulerOrder, e: Vec3) -> Mat3 {
    let ax = order.axes();
    let mut m = Mat3::IDENTITY;
    for &a in ax.iter() {
        m = axis_matrix(a, e[a]) * m;
    }
    m
}

fn xyz_angles(m: &[[f32; 3]; 3]) -> [Vec3; 2] {
    // m[row][col]; R = Rz(g) Ry(b) Rx(a)
    let cb = (m[0][0] * m[0][0] + m[1][0] * m[1][0]).sqrt();
    if cb > 1e-6 {
        let a1 = m[2][1].atan2(m[2][2]);
        let b1 = (-m[2][0]).atan2(cb);
        let g1 = m[1][0].atan2(m[0][0]);
        let a2 = a1 + std::f32::consts::PI;
        let b2 = (-m[2][0]).atan2(-cb);
        let g2 = g1 + std::f32::consts::PI;
        [Vec3::new(a1, b1, g1), Vec3::new(a2, b2, g2)]
    } else {
        let a = (-m[1][2]).atan2(m[1][1]);
        let b = (-m[2][0]).atan2(cb);
        let v = Vec3::new(a, b, 0.0);
        [v, v]
    }
}

fn wrap_pi(a: f32) -> f32 {
    let two_pi = std::f32::consts::TAU;
    let mut r = (a + std::f32::consts::PI).rem_euclid(two_pi) - std::f32::consts::PI;
    if r <= -std::f32::consts::PI {
        r += two_pi;
    }
    r
}

/// Euler angles `(about X, about Y, about Z)` reproducing rotation matrix `m` in `order`.
/// Of the two valid solutions the one closest to `compat` (default zero) is chosen, like Blender.
pub fn euler_from_mat3(order: EulerOrder, m: &Mat3, compat: Option<Vec3>) -> Vec3 {
    let ax = order.axes();
    // permuted matrix P[r][c] = M[ax[r]][ax[c]]
    let mut p = [[0f32; 3]; 3];
    for r in 0..3 {
        for c in 0..3 {
            p[r][c] = m.at(ax[r], ax[c]);
        }
    }
    let sols = xyz_angles(&p);
    let odd = order.is_odd();
    let reference = compat.unwrap_or(Vec3::ZERO);
    let mut best = Vec3::ZERO;
    let mut best_cost = f32::INFINITY;
    for s in sols.iter() {
        let (a, b, g) = if odd { (-s.x, -s.y, -s.z) } else { (s.x, s.y, s.z) };
        let mut e = Vec3::ZERO;
        e[ax[0]] = wrap_pi(a);
        e[ax[1]] = wrap_pi(b);
        e[ax[2]] = wrap_pi(g);
        let cost: f32 = (0..3).map(|i| wrap_pi(e[i] - reference[i]).abs()).sum();
        if cost < best_cost {
            best_cost = cost;
            best = e;
        }
    }
    best
}
