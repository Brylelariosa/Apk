//! Bounding volume hierarchy over the triangles of a mesh: closest ray hit (picking) and visibility tests.
#![forbid(unsafe_code)]

use forge_math::{Aabb, Ray, Vec3};
use forge_mesh::Mesh;

#[derive(Clone, Copy, Debug)]
pub struct Hit {
    pub t: f32,
    /// Face of the mesh that was hit.
    pub face: u32,
    pub point: Vec3,
}

struct Node {
    bounds: Aabb,
    /// Leaf: first slot in `order`. Inner: index of the right child (the left child is `self index + 1`).
    a: u32,
    /// Leaf: number of triangles; 0 for inner nodes.
    count: u32,
}

pub struct Bvh {
    nodes: Vec<Node>,
    order: Vec<u32>,
    tris: Vec<[Vec3; 3]>,
    tri_face: Vec<u32>,
}

const LEAF: usize = 4;

impl Bvh {
    pub fn build(mesh: &Mesh) -> Bvh {
        let mut tris = Vec::with_capacity(mesh.triangle_count());
        let mut tri_face = Vec::with_capacity(mesh.triangle_count());
        let mut scratch: Vec<[u32; 3]> = Vec::new();
        for f in 0..mesh.face_count() {
            scratch.clear();
            mesh.triangulate_face(f, &mut scratch);
            for t in &scratch {
                let p = |k: usize| mesh.positions[mesh.corners[t[k] as usize] as usize];
                tris.push([p(0), p(1), p(2)]);
                tri_face.push(f as u32);
            }
        }
        let n = tris.len();
        let mut bvh = Bvh { nodes: Vec::with_capacity(n / 2 + 1), order: (0..n as u32).collect(), tris, tri_face };
        if n > 0 {
            let boxes: Vec<Aabb> = bvh.tris.iter().map(|t| Aabb::from_points(t.iter().copied())).collect();
            let cents: Vec<Vec3> = boxes.iter().map(|b| b.center()).collect();
            bvh.split(0, n, &boxes, &cents);
        }
        bvh
    }

    fn split(&mut self, lo: usize, hi: usize, boxes: &[Aabb], cents: &[Vec3]) -> usize {
        let mut bounds = Aabb::EMPTY;
        for &i in &self.order[lo..hi] {
            bounds.expand_aabb(&boxes[i as usize]);
        }
        let idx = self.nodes.len();
        self.nodes.push(Node { bounds, a: lo as u32, count: (hi - lo) as u32 });
        if hi - lo <= LEAF {
            return idx;
        }
        let ext = bounds.size();
        let axis = ext.max_abs_axis();
        let mid = (lo + hi) / 2;
        self.order[lo..hi].select_nth_unstable_by(mid - lo, |&a, &b| cents[a as usize][axis].partial_cmp(&cents[b as usize][axis]).unwrap_or(std::cmp::Ordering::Equal));
        self.split(lo, mid, boxes, cents);
        let right = self.split(mid, hi, boxes, cents);
        self.nodes[idx].a = right as u32;
        self.nodes[idx].count = 0;
        idx
    }

    pub fn is_empty(&self) -> bool {
        self.tris.is_empty()
    }

    pub fn bounds(&self) -> Aabb {
        self.nodes.first().map(|n| n.bounds).unwrap_or(Aabb::EMPTY)
    }

    /// Closest hit along the ray within `(0, max_t]`.
    pub fn raycast(&self, ray: &Ray, max_t: f32) -> Option<Hit> {
        if self.nodes.is_empty() {
            return None;
        }
        let mut best: Option<(f32, u32)> = None;
        let mut limit = max_t;
        let mut stack: Vec<usize> = Vec::with_capacity(64);
        stack.push(0);
        while let Some(ni) = stack.pop() {
            let n = &self.nodes[ni];
            if n.bounds.ray_intersect(ray, 0.0, limit).is_none() {
                continue;
            }
            if n.count > 0 {
                for s in n.a as usize..(n.a + n.count) as usize {
                    let ti = self.order[s] as usize;
                    let t = &self.tris[ti];
                    if let Some(h) = ray.intersect_triangle(t[0], t[1], t[2]) {
                        if h.t > 0.0 && h.t <= limit {
                            limit = h.t;
                            best = Some((h.t, self.tri_face[ti]));
                        }
                    }
                }
            } else {
                stack.push(n.a as usize);
                stack.push(ni + 1);
            }
        }
        best.map(|(t, face)| Hit { t, face, point: ray.at(t) })
    }

    /// True when something blocks the segment `from -> to` (ends excluded by `eps`).
    pub fn occluded(&self, from: Vec3, to: Vec3, eps: f32) -> bool {
        let d = to - from;
        let len = d.length();
        if len <= eps {
            return false;
        }
        self.raycast(&Ray::new(from, d * (1.0 / len)), len - eps).is_some()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use forge_geom::{cube, ico_sphere, uv_sphere};
    use forge_mesh::OpCtx;

    #[test]
    fn hits_the_nearest_face_of_a_cube() {
        let c = cube(2.0, false);
        let bvh = Bvh::build(&c);
        let h = bvh.raycast(&Ray::new(Vec3::new(0.2, 0.3, 5.0), Vec3::new(0.0, 0.0, -1.0)), 100.0).unwrap();
        assert_eq!(h.face, 4);
        assert!((h.t - 4.0).abs() < 1e-5 && (h.point.z - 1.0).abs() < 1e-5);
        let side = bvh.raycast(&Ray::new(Vec3::new(-5.0, 0.0, 0.0), Vec3::X), 100.0).unwrap();
        assert_eq!(side.face, 1);
        assert!(bvh.raycast(&Ray::new(Vec3::new(5.0, 5.0, 5.0), Vec3::X), 100.0).is_none());
        assert!(bvh.raycast(&Ray::new(Vec3::new(0.0, 0.0, 5.0), Vec3::new(0.0, 0.0, -1.0)), 3.0).is_none());
    }

    #[test]
    fn agrees_with_brute_force_on_a_sphere() {
        let ctx = OpCtx::new();
        let m = uv_sphere(24, 12, 1.0, false, &ctx).unwrap();
        let bvh = Bvh::build(&m);
        let mut seed = 7u64;
        let mut rnd = || {
            seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            ((seed >> 33) as f32 / (1u64 << 31) as f32) * 2.0 - 1.0
        };
        let mut tris = Vec::new();
        for _ in 0..300 {
            let o = Vec3::new(rnd() * 3.0, rnd() * 3.0, rnd() * 3.0);
            let d = Vec3::new(rnd(), rnd(), rnd()).normalize();
            if d.length() < 0.5 {
                continue;
            }
            let ray = Ray::new(o, d);
            let mut brute: Option<f32> = None;
            for f in 0..m.face_count() {
                tris.clear();
                m.triangulate_face(f, &mut tris);
                for t in &tris {
                    let p = |k: usize| m.positions[m.corners[t[k] as usize] as usize];
                    if let Some(h) = ray.intersect_triangle(p(0), p(1), p(2)) {
                        if h.t > 0.0 && brute.map_or(true, |b| h.t < b) {
                            brute = Some(h.t);
                        }
                    }
                }
            }
            let fast = bvh.raycast(&ray, f32::MAX).map(|h| h.t);
            match (brute, fast) {
                (None, None) => {}
                (Some(a), Some(b)) => assert!((a - b).abs() < 1e-4, "{a} vs {b}"),
                other => panic!("mismatch {other:?}"),
            }
        }
        let ico = Bvh::build(&ico_sphere(3, 1.0, false, &ctx).unwrap());
        assert!(ico.occluded(Vec3::new(0.0, 0.0, 3.0), Vec3::new(0.0, 0.0, -3.0), 1e-3));
        assert!(!ico.occluded(Vec3::new(0.0, 0.0, 3.0), Vec3::new(0.0, 0.0, 1.5), 1e-3));
        assert!(Bvh::build(&Mesh::new()).is_empty());
    }
}
