//! Transforms of the current selection (objects, or vertices in edit mode) about a pivot.
use super::*;
use forge_geom::transform_selection;
use forge_math::{Mat3, Mat4, Quat};
use forge_scene::{ParamDef, Transform};

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Xform {
    Translate(Vec3),
    Rotate { axis: Vec3, angle: f32 },
    /// `factors` along the orthonormal `axes`.
    Scale { axes: [Vec3; 3], factors: Vec3 },
}

impl Xform {
    /// World-space matrix of the transform about `pivot`.
    pub fn matrix(&self, pivot: Vec3) -> Mat4 {
        let about = |m: Mat3| Mat4::from_translation(pivot) * Mat4::from_mat3(m) * Mat4::from_translation(pivot * -1.0);
        match *self {
            Xform::Translate(d) => Mat4::from_translation(d),
            Xform::Rotate { axis, angle } => about(Quat::from_axis_angle(axis.try_normalize().unwrap_or(Vec3::Z), angle).to_mat3()),
            Xform::Scale { axes, factors } => {
                let b = Mat3::from_cols(axes[0], axes[1], axes[2]);
                about(b.mul_mat3(&Mat3::from_diagonal(factors)).mul_mat3(&b.transpose()))
            }
        }
    }
}

/// World-space median of the selection: selected object origins, or the selected vertices in edit mode.
pub fn selection_pivot(scene: &Scene, edit: Option<&EditState>) -> Option<Vec3> {
    let mut sum = Vec3::ZERO;
    let mut n = 0usize;
    if let Some(e) = edit {
        let o = scene.get(e.object)?;
        let m = o.mesh()?;
        let w = o.transform.matrix();
        for v in e.sel.indices() {
            if let Some(p) = m.positions.get(v as usize) {
                sum = sum + w.transform_point3(*p);
                n += 1;
            }
        }
    } else {
        for &id in &scene.selected {
            if let Some(o) = scene.get(id) {
                sum = sum + o.transform.location;
                n += 1;
            }
        }
    }
    if n == 0 {
        None
    } else {
        Some(sum * (1.0 / n as f32))
    }
}

/// Apply `x` about `pivot` to the selection. Locked objects are skipped.
pub fn apply_xform(scene: &mut Scene, edit: Option<&EditState>, x: &Xform, pivot: Vec3) -> Result<(), String> {
    let m = x.matrix(pivot);
    if let Some(e) = edit {
        let o = scene.get(e.object).ok_or("The edited object no longer exists")?;
        let mesh = o.mesh().ok_or("The edited object is not a mesh")?.clone();
        let w = o.transform.matrix();
        let local = w.inverse() * m * w;
        let mut sel = e.sel.clone();
        sel.resize(mesh.vert_count());
        scene.set_mesh(e.object, transform_selection(&mesh, &sel, &local));
        return Ok(());
    }
    let ids: Vec<ObjId> = scene.selected.iter().copied().filter(|&i| scene.get(i).map_or(false, |o| !o.locked)).collect();
    if ids.is_empty() {
        return Err("No objects selected".into());
    }
    for id in ids {
        let world = scene.world_matrix(id);
        if let Some(o) = scene.get_mut(id) {
            o.transform = Transform::from_matrix(&(m * world), Some(o.transform.rotation));
        }
    }
    Ok(())
}

fn orient_params() -> Vec<ParamDef> {
    vec![ParamDef::choice("orient_type", "Orientation", "GLOBAL", &[("GLOBAL", "Global"), ("LOCAL", "Local")])]
}

/// Frame axes for the orientation: global, or the active object's rotation.
fn frame_axes(env: &OpEnv, p: &Params) -> [Vec3; 3] {
    if p.s("orient_type") == "LOCAL" {
        if let Some(o) = env.scene.active_object() {
            let r = forge_math::euler_to_mat3(forge_math::EulerOrder::XYZ, o.transform.rotation);
            return [r.cols[0], r.cols[1], r.cols[2]];
        }
    }
    [Vec3::X, Vec3::Y, Vec3::Z]
}

fn pivot_or_err(env: &OpEnv) -> Result<Vec3, String> {
    selection_pivot(env.scene, env.edit.as_ref()).ok_or_else(|| "Nothing is selected".to_string())
}

fn translate(env: &mut OpEnv, p: &Params) -> R {
    let a = frame_axes(env, p);
    let v = v3(p, "value");
    let d = a[0] * v.x + a[1] * v.y + a[2] * v.z;
    let pivot = pivot_or_err(env)?;
    apply_xform(env.scene, env.edit.as_ref(), &Xform::Translate(d), pivot)?;
    Ok(OpOutcome::msg("Moved"))
}

fn rotate(env: &mut OpEnv, p: &Params) -> R {
    let a = frame_axes(env, p);
    let axis = match p.s("orient_axis").as_str() {
        "X" => a[0],
        "Y" => a[1],
        _ => a[2],
    };
    let pivot = pivot_or_err(env)?;
    apply_xform(env.scene, env.edit.as_ref(), &Xform::Rotate { axis, angle: (p.f("value") as f32).to_radians() }, pivot)?;
    Ok(OpOutcome::msg("Rotated"))
}

fn resize(env: &mut OpEnv, p: &Params) -> R {
    let axes = frame_axes(env, p);
    let pivot = pivot_or_err(env)?;
    apply_xform(env.scene, env.edit.as_ref(), &Xform::Scale { axes, factors: v3(p, "value") }, pivot)?;
    Ok(OpOutcome::msg("Scaled"))
}

pub(crate) fn register(v: &mut Vec<OpDef>) {
    def!(v, "transform.translate", "Move", "transform", Context::Both, || {
        let mut d = vec![ParamDef::vec3("value", "Move", [0.0; 3]).length()];
        d.extend(orient_params());
        d
    }, translate);
    def!(v, "transform.rotate", "Rotate", "transform", Context::Both, || {
        let mut d = vec![ParamDef::float("value", "Angle", 0.0).angle(), ParamDef::choice("orient_axis", "Axis", "Z", &[("X", "X"), ("Y", "Y"), ("Z", "Z")])];
        d.extend(orient_params());
        d
    }, rotate);
    def!(v, "transform.resize", "Resize", "transform", Context::Both, || {
        let mut d = vec![ParamDef::vec3("value", "Scale", [1.0; 3])];
        d.extend(orient_params());
        d
    }, resize);
}
