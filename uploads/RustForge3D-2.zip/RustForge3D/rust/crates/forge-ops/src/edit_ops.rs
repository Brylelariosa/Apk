//! Edit-mode (mesh) operators.
use super::*;
use forge_geom as geo;
use forge_geom::{DeleteMode, InsetOpts, MergeMode, MirrorOpts};
use forge_math::Mat4;
use forge_mesh::Topology;

/// Area weighted normal of the fully selected faces.
fn region_normal(mesh: &Mesh, sel: &Selection) -> Vec3 {
    let mut n = Vec3::ZERO;
    for f in sel.faces(mesh) {
        n = n + mesh.face_area_vector(f as usize);
    }
    n.try_normalize().unwrap_or(Vec3::ZERO)
}

fn moved(mesh: Mesh, sel: &Selection, d: Vec3) -> Mesh {
    if d.length_squared() > 0.0 {
        geo::transform_selection(&mesh, sel, &Mat4::from_translation(d))
    } else {
        mesh
    }
}

fn extrude_region(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let n = region_normal(&t.mesh, &t.sel);
    let (m, out) = g(geo::extrude_region(&t.mesh, &t.sel, env.ctx))?;
    let m = moved(m, &out.selection, n * p.f("distance") as f32 + v3(p, "translate"));
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Extruded region"))
}

fn extrude_indiv(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (mut m, out) = g(geo::extrude_individual_faces(&t.mesh, &t.sel, env.ctx))?;
    let d = p.f("distance") as f32;
    if d != 0.0 {
        let mut done = vec![false; m.vert_count()];
        for f in out.selection.faces(&m) {
            let n = m.face_normal(f as usize);
            let verts: Vec<u32> = m.face_verts(f as usize).to_vec();
            for v in verts {
                if !done[v as usize] {
                    done[v as usize] = true;
                    m.positions[v as usize] = m.positions[v as usize] + n * d;
                }
            }
        }
    }
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Extruded faces individually"))
}

fn extrude_edges(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (m, out) = g(geo::extrude_edges(&t.mesh, &t.sel, env.ctx))?;
    let m = moved(m, &out.selection, v3(p, "translate"));
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Extruded edges"))
}

fn extrude_verts(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (m, out) = g(geo::extrude_verts(&t.mesh, &t.sel, env.ctx))?;
    let m = moved(m, &out.selection, v3(p, "translate"));
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Extruded vertices"))
}

fn inset(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let o = InsetOpts {
        thickness: p.f("thickness") as f32,
        depth: p.f("depth") as f32,
        individual: p.b("use_individual"),
        boundary: p.b("use_boundary"),
        even_offset: p.b("use_even_offset"),
    };
    let (m, out) = g(geo::inset(&t.mesh, &t.sel, &o, env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Inset faces"))
}

fn loopcut(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    let topo = Topology::build(&t.mesh);
    let e = p.i("edge");
    let edge = if e >= 0 && (e as usize) < topo.loose_start {
        topo.edges[e as usize]
    } else {
        topo.edges[..topo.loose_start]
            .iter()
            .copied()
            .find(|ed| t.sel.is_selected(ed[0]) && t.sel.is_selected(ed[1]))
            .ok_or("Select an edge, or tap an edge with the Loop Cut tool")?
    };
    let (m, out) = g(geo::loop_cut(&t.mesh, edge, p.i("number_cuts").max(1) as u32, p.f("factor") as f32, env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Loop cut"))
}

fn subdivide(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (m, out) = g(geo::subdivide(&t.mesh, &t.sel, p.i("number_cuts").max(1) as u32, env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Subdivided"))
}

fn delete(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let mode = match p.s("type").as_str() {
        "EDGE" => DeleteMode::Edges,
        "FACE" => DeleteMode::Faces,
        "ONLY_FACE" => DeleteMode::OnlyFaces,
        _ => DeleteMode::Vertices,
    };
    let (m, out) = g(geo::delete(&t.mesh, &t.sel, mode, env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Deleted"))
}

fn merge(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let mode = match p.s("type").as_str() {
        "FIRST" => MergeMode::First,
        "LAST" => MergeMode::Last,
        "COLLAPSE" => MergeMode::Collapse,
        "CURSOR" => MergeMode::Cursor(env.scene.world_matrix(t.id).inverse().transform_point3(Vec3::ZERO)),
        _ => MergeMode::Center,
    };
    let (m, out) = g(geo::merge(&t.mesh, &t.sel, mode, env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Merged vertices"))
}

fn remove_doubles(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    let all = p.b("use_unselected");
    if !all {
        need_sel(&t)?;
    }
    let before = t.mesh.vert_count();
    let (m, out) = g(geo::remove_doubles(&t.mesh, if all { None } else { Some(&t.sel) }, p.f("threshold") as f32, env.ctx))?;
    let removed = before.saturating_sub(m.vert_count());
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg(format!("Removed {removed} vertices")))
}

fn dissolve_verts(env: &mut OpEnv, _p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (m, out) = g(geo::dissolve_verts(&t.mesh, &t.sel, env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Dissolved vertices"))
}
fn dissolve_edges(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (m, out) = g(geo::dissolve_edges(&t.mesh, &t.sel, p.b("use_verts"), env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Dissolved edges"))
}
fn dissolve_faces(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (m, out) = g(geo::dissolve_faces(&t.mesh, &t.sel, p.b("use_verts"), env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Dissolved faces"))
}

fn flip_normals(env: &mut OpEnv, _p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let m = geo::flip_normals(&t.mesh, &t.sel);
    let sel = t.sel.clone();
    commit(env, &t, m, sel);
    Ok(OpOutcome::msg("Flipped normals"))
}

fn make_consistent(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    let m = g(geo::recalc_normals(&t.mesh, p.b("inside"), env.ctx))?;
    let sel = t.sel.clone();
    commit(env, &t, m, sel);
    Ok(OpOutcome::msg("Recalculated normals"))
}

fn shade(env: &mut OpEnv, smooth: bool) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let m = geo::set_smooth(&t.mesh, &t.sel, smooth);
    let sel = t.sel.clone();
    commit(env, &t, m, sel);
    Ok(OpOutcome::msg(if smooth { "Shaded smooth" } else { "Shaded flat" }))
}
fn faces_smooth(env: &mut OpEnv, _p: &Params) -> R {
    shade(env, true)
}
fn faces_flat(env: &mut OpEnv, _p: &Params) -> R {
    shade(env, false)
}

fn to_tris(env: &mut OpEnv, _p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (m, out) = g(geo::triangulate(&t.mesh, &t.sel, env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Triangulated"))
}

fn fill(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (m, out) = g(geo::fill(&t.mesh, &t.sel, p.b("triangulate"), env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Filled"))
}

fn duplicate(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (m, out) = g(geo::duplicate(&t.mesh, &t.sel, env.ctx))?;
    let m = moved(m, &out.selection, v3(p, "translate"));
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Duplicated"))
}

fn separate(env: &mut OpEnv, _p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let (rest, part) = g(geo::separate(&t.mesh, &t.sel))?;
    if part.is_empty() {
        return Err("The selection contains no faces to separate".into());
    }
    let src = env.scene.get(t.id).cloned().ok_or("The edited object no longer exists")?;
    let none = Selection::none(rest.vert_count());
    commit(env, &t, rest, none);
    let id = env.scene.add_mesh(&src.name, part);
    if let Some(o) = env.scene.get_mut(id) {
        o.transform = src.transform.clone();
        o.materials = src.materials.clone();
    }
    Ok(OpOutcome { message: "Separated selection".into(), created: vec![id] })
}

fn smooth_verts(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    need_sel(&t)?;
    let m = g(geo::smooth_vertices(&t.mesh, &t.sel, p.i("repeat").max(1) as u32, p.f("factor") as f32, env.ctx))?;
    let sel = t.sel.clone();
    commit(env, &t, m, sel);
    Ok(OpOutcome::msg("Smoothed vertices"))
}

fn symmetrize(env: &mut OpEnv, p: &Params) -> R {
    let t = target(env)?;
    let mut axes = [false; 3];
    axes[match p.s("axis").as_str() {
        "Y" => 1,
        "Z" => 2,
        _ => 0,
    }] = true;
    let opts = MirrorOpts { axes, merge: true, merge_distance: p.f("threshold") as f32 };
    let (m, out) = g(geo::mirror(&t.mesh, &opts, env.ctx))?;
    commit(env, &t, m, out.selection);
    Ok(OpOutcome::msg("Mirrored the mesh across the axis plane"))
}

fn distance_param() -> ParamDef {
    ParamDef::float("distance", "Distance", 0.0).length().help("Move along the face normal")
}

fn translate_param() -> ParamDef {
    ParamDef::vec3("translate", "Move", [0.0; 3]).length()
}

pub(crate) fn register(v: &mut Vec<OpDef>) {
    let e = Context::Edit;
    def!(v, "mesh.extrude_region_move", "Extrude", "mesh", e, || vec![distance_param(), translate_param()], extrude_region);
    def!(v, "mesh.extrude_faces_indiv", "Extrude Individual Faces", "mesh", e, || vec![distance_param()], extrude_indiv);
    def!(v, "mesh.extrude_edges_move", "Extrude Edges", "mesh", e, || vec![translate_param()], extrude_edges);
    def!(v, "mesh.extrude_vertices_move", "Extrude Vertices", "mesh", e, || vec![translate_param()], extrude_verts);
    def!(v, "mesh.inset", "Inset Faces", "mesh", e, || vec![
        ParamDef::float("thickness", "Thickness", 0.1).min(0.0).length(),
        ParamDef::float("depth", "Depth", 0.0).length(),
        ParamDef::boolean("use_individual", "Individual", false),
        ParamDef::boolean("use_boundary", "Boundary", true),
        ParamDef::boolean("use_even_offset", "Offset Even", true),
    ], inset);
    def!(v, "mesh.loopcut_slide", "Loop Cut", "mesh", e, || vec![
        ParamDef::int("edge", "Edge", -1).help("Edge index; -1 uses the selected edge"),
        ParamDef::int("number_cuts", "Number of Cuts", 1).range(1.0, 64.0),
        ParamDef::float("factor", "Position", 0.5).range(0.0, 1.0).step(0.01),
    ], loopcut);
    def!(v, "mesh.subdivide", "Subdivide", "mesh", e, || vec![ParamDef::int("number_cuts", "Number of Cuts", 1).range(1.0, 8.0)], subdivide);
    def!(v, "mesh.delete", "Delete", "mesh", e, || vec![ParamDef::choice("type", "Type", "VERT", &[("VERT", "Vertices"), ("EDGE", "Edges"), ("FACE", "Faces"), ("ONLY_FACE", "Only Faces")])], delete);
    def!(v, "mesh.merge", "Merge", "mesh", e, || vec![ParamDef::choice("type", "Type", "CENTER", &[("CENTER", "At Center"), ("FIRST", "At First"), ("LAST", "At Last"), ("CURSOR", "At World Origin"), ("COLLAPSE", "Collapse")])], merge);
    def!(v, "mesh.remove_doubles", "Merge by Distance", "mesh", e, || vec![
        ParamDef::float("threshold", "Merge Distance", 0.0001).min(0.0).step(0.0001).length(),
        ParamDef::boolean("use_unselected", "Whole Mesh", false),
    ], remove_doubles);
    def!(v, "mesh.dissolve_verts", "Dissolve Vertices", "mesh", e, Vec::new, dissolve_verts);
    def!(v, "mesh.dissolve_edges", "Dissolve Edges", "mesh", e, || vec![ParamDef::boolean("use_verts", "Dissolve Vertices", true)], dissolve_edges);
    def!(v, "mesh.dissolve_faces", "Dissolve Faces", "mesh", e, || vec![ParamDef::boolean("use_verts", "Dissolve Vertices", false)], dissolve_faces);
    def!(v, "mesh.flip_normals", "Flip Normals", "mesh", e, Vec::new, flip_normals);
    def!(v, "mesh.normals_make_consistent", "Recalculate Normals", "mesh", e, || vec![ParamDef::boolean("inside", "Inside", false)], make_consistent);
    def!(v, "mesh.faces_shade_smooth", "Shade Smooth", "mesh", e, Vec::new, faces_smooth);
    def!(v, "mesh.faces_shade_flat", "Shade Flat", "mesh", e, Vec::new, faces_flat);
    def!(v, "mesh.quads_convert_to_tris", "Triangulate Faces", "mesh", e, Vec::new, to_tris);
    def!(v, "mesh.fill", "Fill", "mesh", e, || vec![ParamDef::boolean("triangulate", "Triangulate", false)], fill);
    def!(v, "mesh.duplicate_move", "Duplicate", "mesh", e, || vec![translate_param()], duplicate);
    def!(v, "mesh.separate", "Separate", "mesh", e, Vec::new, separate);
    def!(v, "mesh.vertices_smooth", "Smooth Vertices", "mesh", e, || vec![
        ParamDef::float("factor", "Smoothing", 0.5).range(0.0, 1.0).step(0.05),
        ParamDef::int("repeat", "Repeat", 1).range(1.0, 100.0),
    ], smooth_verts);
    def!(v, "mesh.symmetrize", "Symmetrize", "mesh", e, || vec![
        ParamDef::choice("axis", "Axis", "X", &[("X", "X"), ("Y", "Y"), ("Z", "Z")]),
        ParamDef::float("threshold", "Merge Distance", 0.0001).min(0.0).step(0.0001).length(),
    ], symmetrize);
}
