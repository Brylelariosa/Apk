use super::*;
use forge_math::Vec3;

struct Rig {
    scene: Scene,
    edit: Option<EditState>,
    ctx: OpCtx,
}

impl Rig {
    fn new() -> Rig {
        Rig { scene: Scene::new(), edit: None, ctx: OpCtx::new() }
    }
    fn run(&mut self, id: &str, params: &str) -> Result<OpRun, String> {
        let j = Json::parse(params).unwrap();
        let mut env = OpEnv { scene: &mut self.scene, edit: &mut self.edit, ctx: &self.ctx };
        run(id, &mut env, &j)
    }
    fn enter_edit(&mut self, mode: SelectMode, all: bool) {
        let id = self.scene.active.unwrap();
        let n = self.scene.get(id).unwrap().mesh().unwrap().vert_count();
        self.edit = Some(EditState { object: id, mode, sel: if all { Selection::all(n) } else { Selection::none(n) } });
    }
    fn mesh(&self) -> Arc<Mesh> {
        self.scene.active_object().unwrap().mesh().unwrap().clone()
    }
}

#[test]
fn registry_is_consistent() {
    let mut ids: Vec<&str> = all().iter().map(|d| d.id).collect();
    let n = ids.len();
    ids.sort();
    ids.dedup();
    assert_eq!(ids.len(), n, "duplicate operator ids");
    for d in all() {
        let defs = (d.params)();
        let mut names: Vec<&str> = defs.iter().map(|p| p.name.as_str()).collect();
        names.sort();
        names.dedup();
        assert_eq!(names.len(), defs.len(), "{} has duplicate params", d.id);
    }
    assert!(list_json("edit").as_arr().unwrap().len() > 20);
    for id in ["mesh.primitive_cube_add", "mesh.extrude_region_move", "mesh.loopcut_slide", "object.join", "transform.translate"] {
        assert!(find(id).is_some(), "{id}");
    }
    assert!(run("mesh.nope", &mut OpEnv { scene: &mut Scene::new(), edit: &mut None, ctx: &OpCtx::new() }, &Json::obj()).is_err());
}

#[test]
fn primitives_have_blender_counts_and_placement() {
    let mut r = Rig::new();
    let out = r.run("mesh.primitive_cube_add", r#"{"size": 4, "location": [1,2,3], "rotation": [0,0,90]}"#).unwrap();
    assert_eq!(out.outcome.created.len(), 1);
    let o = r.scene.active_object().unwrap();
    assert_eq!(o.name, "Cube");
    assert_eq!(o.mesh().unwrap().vert_count(), 8);
    assert!((o.transform.location - Vec3::new(1.0, 2.0, 3.0)).length() < 1e-6 && (o.transform.rotation.z - std::f32::consts::FRAC_PI_2).abs() < 1e-5);
    assert!((o.mesh().unwrap().bounds().size().x - 4.0).abs() < 1e-5);
    r.run("mesh.primitive_uv_sphere_add", "{}").unwrap();
    assert_eq!(r.mesh().vert_count(), 482);
    r.run("mesh.primitive_cube_add", "{}").unwrap();
    assert_eq!(r.scene.active_object().unwrap().name, "Cube.001");
    for id in ["mesh.primitive_ico_sphere_add", "mesh.primitive_cylinder_add", "mesh.primitive_cone_add", "mesh.primitive_torus_add", "mesh.primitive_plane_add", "mesh.primitive_circle_add", "mesh.primitive_grid_add", "object.light_add", "object.empty_add"] {
        r.run(id, "{}").unwrap_or_else(|e| panic!("{id}: {e}"));
    }
    assert_eq!(r.scene.objects.len(), 12);
    // clamped parameters never fail
    r.run("mesh.primitive_cylinder_add", r#"{"vertices": 1}"#).unwrap();
    assert_eq!(r.mesh().vert_count(), 6);
}

#[test]
fn edit_operators_work_on_the_selection() {
    let mut r = Rig::new();
    r.run("mesh.primitive_cube_add", "{}").unwrap();
    assert!(r.run("mesh.subdivide", "{}").is_err(), "edit operators need edit mode");
    r.enter_edit(SelectMode::Face, false);
    assert!(r.run("mesh.subdivide", "{}").unwrap_err().contains("Nothing"));
    // top face: select the four z = +1 vertices
    let top: Vec<u32> = (0..8u32).filter(|&v| r.mesh().positions[v as usize].z > 0.0).collect();
    r.edit.as_mut().unwrap().sel = Selection::from_indices(8, top);
    r.run("mesh.extrude_region_move", r#"{"distance": 1.5}"#).unwrap();
    let m = r.mesh();
    assert_eq!((m.vert_count(), m.face_count()), (12, 10));
    assert!((m.bounds().max.z - 2.5).abs() < 1e-5);
    assert_eq!(r.edit.as_ref().unwrap().sel.count(), 4, "the new top is selected");
    r.run("mesh.inset", r#"{"thickness": 0.25}"#).unwrap();
    assert_eq!(r.mesh().face_count(), 14);
    assert!(r.run("mesh.dissolve_faces", "{}").is_err(), "a single face has nothing to dissolve into");
    r.edit.as_mut().unwrap().sel = Selection::all(r.mesh().vert_count());
    r.run("mesh.subdivide", r#"{"number_cuts": 1}"#).unwrap();
    assert!(r.mesh().face_count() > 20);
    r.run("mesh.normals_make_consistent", "{}").unwrap();
    r.run("mesh.faces_shade_smooth", "{}").unwrap();
    assert!(r.mesh().face_smooth.iter().all(|&s| s));
    r.run("mesh.quads_convert_to_tris", "{}").unwrap();
    assert!(r.mesh().face_count() > 40);
    let before = r.mesh().vert_count();
    r.run("mesh.remove_doubles", r#"{"use_unselected": true}"#).unwrap();
    assert_eq!(r.mesh().vert_count(), before);
}

#[test]
fn loop_cut_separate_and_primitives_in_edit_mode() {
    let mut r = Rig::new();
    r.run("mesh.primitive_cube_add", "{}").unwrap();
    r.enter_edit(SelectMode::Edge, false);
    let topo = forge_mesh::Topology::build(&r.mesh());
    let e = topo.edges[..topo.loose_start].iter().position(|ed| (r.mesh().positions[ed[0] as usize] - r.mesh().positions[ed[1] as usize]).z.abs() > 1.0).unwrap();
    r.run("mesh.loopcut_slide", &format!(r#"{{"edge": {e}, "number_cuts": 2}}"#)).unwrap();
    assert_eq!(r.mesh().face_count(), 6 + 4 * 2);
    r.run("mesh.primitive_plane_add", r#"{"location": [5,0,0]}"#).unwrap();
    assert_eq!(r.scene.objects.len(), 1, "added to the edited mesh, not as an object");
    let n = r.mesh().vert_count();
    assert_eq!(r.edit.as_ref().unwrap().sel.count(), 4);
    let out = r.run("mesh.separate", "{}").unwrap();
    assert_eq!(out.outcome.created.len(), 1);
    assert_eq!(r.scene.objects.len(), 2);
    assert_eq!(r.mesh().vert_count(), n - 4);
    assert_eq!(r.scene.get(out.outcome.created[0]).unwrap().mesh().unwrap().vert_count(), 4);
}

#[test]
fn object_operators() {
    let mut r = Rig::new();
    r.run("mesh.primitive_cube_add", "{}").unwrap();
    let a = r.scene.active.unwrap();
    r.run("mesh.primitive_cube_add", r#"{"location": [3,0,0]}"#).unwrap();
    let b = r.scene.active.unwrap();
    r.scene.set_selection(&[a, b], Some(a));
    r.run("object.join", "{}").unwrap();
    assert_eq!(r.scene.objects.len(), 1);
    assert_eq!(r.mesh().vert_count(), 16);
    assert!((r.mesh().bounds().max.x - 4.0).abs() < 1e-5);
    r.run("object.modifier_add", r#"{"type": "SUBSURF"}"#).unwrap();
    assert_eq!(r.scene.active_object().unwrap().modifiers.len(), 1);
    r.run("object.modifier_apply", "{}").unwrap();
    assert!(r.scene.active_object().unwrap().modifiers.is_empty() && r.mesh().face_count() > 12);
    let id = r.scene.active.unwrap();
    {
        let o = r.scene.get_mut(id).unwrap();
        o.transform.location = Vec3::new(1.0, 0.0, 0.0);
        o.transform.scale = Vec3::new(2.0, 2.0, 2.0);
    }
    let world_before = r.scene.world_matrix(id).transform_point3(r.mesh().positions[0]);
    r.run("object.transform_apply", "{}").unwrap();
    let world_after = r.scene.world_matrix(id).transform_point3(r.mesh().positions[0]);
    assert!((world_before - world_after).length() < 1e-4);
    assert_eq!(r.scene.active_object().unwrap().transform, forge_scene::Transform::default());
    r.run("object.duplicate_move", r#"{"translate": [0,5,0]}"#).unwrap();
    assert_eq!(r.scene.objects.len(), 2);
    assert_eq!(r.scene.selected.len(), 1);
    r.run("object.hide_view_set", "{}").unwrap();
    assert!(!r.scene.objects.last().unwrap().visible);
    r.run("object.hide_view_clear", "{}").unwrap();
    r.run("object.delete", "{}").unwrap_err();
    r.scene.select_all();
    r.run("object.delete", "{}").unwrap();
    assert!(r.scene.objects.is_empty());
}

#[test]
fn transforms_in_both_modes() {
    let mut r = Rig::new();
    r.run("mesh.primitive_cube_add", "{}").unwrap();
    r.run("transform.translate", r#"{"value": [1,2,3]}"#).unwrap();
    assert!((r.scene.active_object().unwrap().transform.location - Vec3::new(1.0, 2.0, 3.0)).length() < 1e-5);
    r.run("transform.rotate", r#"{"value": 90, "orient_axis": "Z"}"#).unwrap();
    assert!((r.scene.active_object().unwrap().transform.rotation.z - std::f32::consts::FRAC_PI_2).abs() < 1e-4);
    r.run("transform.resize", r#"{"value": [2,2,2]}"#).unwrap();
    assert!((r.scene.active_object().unwrap().transform.scale.x - 2.0).abs() < 1e-5);
    r.enter_edit(SelectMode::Vertex, true);
    let z0 = r.mesh().bounds().max.z;
    r.run("transform.translate", r#"{"value": [0,0,1]}"#).unwrap();
    assert!((r.mesh().bounds().max.z - z0 - 0.5).abs() < 1e-4, "world +1 is 0.5 local with scale 2");
    let pivot = selection_pivot(&r.scene, r.edit.as_ref()).unwrap();
    assert!((pivot - (r.scene.active_object().unwrap().transform.location + Vec3::new(0.0, 0.0, 1.0))).length() < 1e-4);
}
