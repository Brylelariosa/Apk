//! Object-level operators.
use super::*;
use forge_geom as geo;
use forge_math::Mat4;
use forge_scene::{next_rev, Transform};

fn selected(env: &OpEnv) -> Result<Vec<ObjId>, String> {
    let ids: Vec<ObjId> = env.scene.selected.iter().copied().filter(|&i| env.scene.get(i).is_some()).collect();
    if ids.is_empty() {
        Err("No objects selected".into())
    } else {
        Ok(ids)
    }
}

fn delete(env: &mut OpEnv, _p: &Params) -> R {
    let ids = selected(env)?;
    for &id in &ids {
        env.scene.remove(id);
    }
    Ok(OpOutcome::msg(format!("Deleted {} object(s)", ids.len())))
}

fn duplicate(env: &mut OpEnv, p: &Params) -> R {
    let ids = selected(env)?;
    let d = v3(p, "translate");
    let mut created = Vec::new();
    for id in ids {
        let Some(src) = env.scene.get(id).cloned() else { continue };
        let mut o = src;
        o.id = env.scene.next_obj;
        env.scene.next_obj += 1;
        o.name = env.scene.unique_name(&o.name);
        o.rev = next_rev();
        o.transform.location = o.transform.location + d;
        created.push(o.id);
        env.scene.objects.push(o);
    }
    let active = created.last().copied();
    env.scene.set_selection(&created, active);
    Ok(OpOutcome { message: format!("Duplicated {} object(s)", created.len()), created })
}

fn join(env: &mut OpEnv, _p: &Params) -> R {
    let active = env.scene.active.ok_or("There is no active object")?;
    let ids = selected_meshes(env.scene);
    if ids.len() < 2 || !ids.contains(&active) {
        return Err("Select two or more meshes; the active one receives the others".into());
    }
    let inv = env.scene.world_matrix(active).inverse();
    let mut slots: Vec<u32> = env.scene.get(active).map(|o| o.materials.clone()).unwrap_or_default();
    let any_material = ids.iter().any(|&i| env.scene.get(i).map_or(false, |o| !o.materials.is_empty()));
    if slots.is_empty() && any_material {
        slots.push(0);
    }
    let mut parts: Vec<Mesh> = Vec::new();
    let order = std::iter::once(active).chain(ids.iter().copied().filter(|&i| i != active));
    for id in order {
        let o = env.scene.get(id).ok_or("Object vanished")?;
        let mut m = Mesh::clone(o.mesh().ok_or("Not a mesh")?);
        m.transform(&(inv * o.transform.matrix()));
        if id != active && !o.materials.is_empty() {
            let remap: Vec<u16> = o
                .materials
                .iter()
                .map(|mid| match slots.iter().position(|s| s == mid) {
                    Some(p) => p as u16,
                    None => {
                        slots.push(*mid);
                        (slots.len() - 1) as u16
                    }
                })
                .collect();
            for fm in &mut m.face_material {
                *fm = remap.get(*fm as usize).copied().unwrap_or(0);
            }
        }
        parts.push(m);
    }
    let refs: Vec<&Mesh> = parts.iter().collect();
    let joined = geo::join(&refs);
    env.scene.set_mesh(active, joined);
    if let Some(o) = env.scene.get_mut(active) {
        o.materials = slots;
    }
    for id in ids.into_iter().filter(|&i| i != active) {
        env.scene.remove(id);
    }
    env.scene.set_selection(&[active], Some(active));
    Ok(OpOutcome::msg("Joined objects"))
}

fn shade(env: &mut OpEnv, smooth: bool) -> R {
    let ids = selected_meshes(env.scene);
    if ids.is_empty() {
        return Err("No mesh objects selected".into());
    }
    for id in ids {
        let Some(mesh) = env.scene.get(id).and_then(|o| o.mesh()).cloned() else { continue };
        let all = Selection::all(mesh.vert_count());
        env.scene.set_mesh(id, geo::set_smooth(&mesh, &all, smooth));
    }
    Ok(OpOutcome::msg(if smooth { "Shaded smooth" } else { "Shaded flat" }))
}
fn shade_smooth(env: &mut OpEnv, _p: &Params) -> R {
    shade(env, true)
}
fn shade_flat(env: &mut OpEnv, _p: &Params) -> R {
    shade(env, false)
}

fn active_mesh_id(env: &OpEnv) -> Result<ObjId, String> {
    let id = env.scene.active.ok_or("There is no active object")?;
    env.scene.get(id).and_then(|o| o.mesh()).ok_or("The active object is not a mesh")?;
    Ok(id)
}

fn modifier_add(env: &mut OpEnv, p: &Params) -> R {
    let id = active_mesh_id(env)?;
    let o = env.scene.get_mut(id).ok_or("No active object")?;
    let m = forge_mods::new_modifier(&p.s("type"), &o.modifiers).ok_or("Unknown modifier type")?;
    let name = m.name.clone();
    o.modifiers.push(m);
    o.rev = next_rev();
    Ok(OpOutcome::msg(format!("Added modifier {name}")))
}

fn modifier_index(env: &OpEnv, id: ObjId, p: &Params) -> Result<usize, String> {
    let o = env.scene.get(id).ok_or("No active object")?;
    let name = p.s("modifier");
    if !name.is_empty() {
        return o.modifiers.iter().position(|m| m.name == name).ok_or_else(|| format!("No modifier named '{name}'"));
    }
    let i = p.i("index") as usize;
    if i < o.modifiers.len() {
        Ok(i)
    } else {
        Err("The object has no such modifier".into())
    }
}

fn modifier_remove(env: &mut OpEnv, p: &Params) -> R {
    let id = active_mesh_id(env)?;
    let i = modifier_index(env, id, p)?;
    if let Some(o) = env.scene.get_mut(id) {
        o.modifiers.remove(i);
        o.rev = next_rev();
    }
    Ok(OpOutcome::msg("Removed modifier"))
}

fn modifier_apply(env: &mut OpEnv, p: &Params) -> R {
    let id = active_mesh_id(env)?;
    let i = modifier_index(env, id, p)?;
    let o = env.scene.get(id).ok_or("No active object")?;
    let kind = o.modifiers[i].kind.clone();
    let mesh = o.mesh().ok_or("Not a mesh")?.clone();
    let out = g(forge_mods::apply(&mesh, &kind, env.ctx))?;
    env.scene.set_mesh(id, out);
    if let Some(o) = env.scene.get_mut(id) {
        o.modifiers.remove(i);
    }
    Ok(OpOutcome::msg("Applied modifier"))
}

fn hide(env: &mut OpEnv, p: &Params) -> R {
    let unselected = p.b("unselected");
    let ids: Vec<ObjId> = env.scene.objects.iter().map(|o| o.id).filter(|&i| env.scene.is_selected(i) != unselected).collect();
    for &i in &ids {
        if let Some(o) = env.scene.get_mut(i) {
            o.visible = false;
        }
    }
    let keep: Vec<ObjId> = env.scene.selected.iter().copied().filter(|i| !ids.contains(i)).collect();
    env.scene.set_selection(&keep, None);
    Ok(OpOutcome::msg("Hidden"))
}

fn reveal(env: &mut OpEnv, _p: &Params) -> R {
    for o in &mut env.scene.objects {
        o.visible = true;
    }
    Ok(OpOutcome::msg("Revealed all objects"))
}

fn origin_set(env: &mut OpEnv, p: &Params) -> R {
    let ids = selected_meshes(env.scene);
    if ids.is_empty() {
        return Err("No mesh objects selected".into());
    }
    let to_cursor = p.s("type") == "ORIGIN_CURSOR";
    for id in ids {
        let o = env.scene.get(id).ok_or("Object vanished")?;
        let mesh = o.mesh().ok_or("Not a mesh")?.clone();
        let w = o.transform.matrix();
        let local = if to_cursor { w.inverse().transform_point3(Vec3::ZERO) } else { mesh.bounds().center() };
        let mut m = Mesh::clone(&mesh);
        m.translate(local * -1.0);
        env.scene.set_mesh(id, m);
        if let Some(o) = env.scene.get_mut(id) {
            o.transform.location = w.transform_point3(local);
        }
    }
    Ok(OpOutcome::msg("Origin set"))
}

fn transform_apply(env: &mut OpEnv, p: &Params) -> R {
    let ids = selected_meshes(env.scene);
    if ids.is_empty() {
        return Err("No mesh objects selected".into());
    }
    let (loc, rot, scl) = (p.b("location"), p.b("rotation"), p.b("scale"));
    for id in ids {
        let o = env.scene.get(id).ok_or("Object vanished")?;
        let mesh = o.mesh().ok_or("Not a mesh")?.clone();
        let t = o.transform.clone();
        let rem = Transform {
            location: if loc { Vec3::ZERO } else { t.location },
            rotation: if rot { Vec3::ZERO } else { t.rotation },
            scale: if scl { Vec3::ONE } else { t.scale },
        };
        let a: Mat4 = rem.matrix().inverse() * t.matrix();
        let mut m = Mesh::clone(&mesh);
        m.transform(&a);
        env.scene.set_mesh(id, m);
        if let Some(o) = env.scene.get_mut(id) {
            o.transform = rem;
        }
    }
    Ok(OpOutcome::msg("Applied transform"))
}

fn mod_types() -> Vec<(&'static str, &'static str)> {
    forge_mods::TYPES.to_vec()
}

fn mod_ref() -> Vec<ParamDef> {
    vec![ParamDef::int("index", "Index", 0).min(0.0), ParamDef::text("modifier", "Modifier Name")]
}

pub(crate) fn register(v: &mut Vec<OpDef>) {
    let o = Context::Object;
    def!(v, "object.delete", "Delete", "object", o, Vec::new, delete);
    def!(v, "object.duplicate_move", "Duplicate", "object", o, || vec![ParamDef::vec3("translate", "Move", [0.0; 3]).length()], duplicate);
    def!(v, "object.join", "Join", "object", o, Vec::new, join);
    def!(v, "object.shade_smooth", "Shade Smooth", "object", o, Vec::new, shade_smooth);
    def!(v, "object.shade_flat", "Shade Flat", "object", o, Vec::new, shade_flat);
    def!(v, "object.modifier_add", "Add Modifier", "object", o, || vec![ParamDef::choice("type", "Type", "SUBSURF", &mod_types())], modifier_add);
    def!(v, "object.modifier_remove", "Remove Modifier", "object", o, mod_ref, modifier_remove);
    def!(v, "object.modifier_apply", "Apply Modifier", "object", o, mod_ref, modifier_apply);
    def!(v, "object.hide_view_set", "Hide", "object", o, || vec![ParamDef::boolean("unselected", "Unselected", false)], hide);
    def!(v, "object.hide_view_clear", "Reveal Hidden", "object", o, Vec::new, reveal);
    def!(v, "object.origin_set", "Set Origin", "object", o, || vec![ParamDef::choice("type", "Type", "ORIGIN_GEOMETRY", &[("ORIGIN_GEOMETRY", "Origin to Geometry"), ("ORIGIN_CURSOR", "Origin to World Origin")])], origin_set);
    def!(v, "object.transform_apply", "Apply Transform", "object", o, || vec![
        ParamDef::boolean("location", "Location", true),
        ParamDef::boolean("rotation", "Rotation", true),
        ParamDef::boolean("scale", "Scale", true),
    ], transform_apply);
}
