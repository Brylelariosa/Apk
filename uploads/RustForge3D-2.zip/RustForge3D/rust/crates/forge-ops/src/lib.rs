//! forge-ops: the operator registry. The UI (`op.run`) and scripting (`bpy.ops`) run the same operators.
//!
//! An operator mutates the scene (and the edit-mode selection) through [`OpEnv`]; the caller (engine) takes the
//! undo snapshot *before* running it. Parameters are described by `ParamDef` lists (angles in degrees).
#![forbid(unsafe_code)]

mod edit_ops;
mod object_ops;
mod primitives;
mod transform;
#[cfg(test)]
mod tests;

pub use transform::{apply_xform, selection_pivot, Xform};

use forge_json::Json;
use forge_math::Vec3;
use forge_mesh::{GeomResult, Mesh, OpCtx, Selection};
use forge_scene::{defs_to_json, merge_values, ObjId, ParamDef, Params, Scene};
use std::sync::{Arc, OnceLock};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SelectMode {
    Vertex,
    Edge,
    Face,
}

impl SelectMode {
    pub fn name(self) -> &'static str {
        match self {
            SelectMode::Vertex => "vertex",
            SelectMode::Edge => "edge",
            SelectMode::Face => "face",
        }
    }
    pub fn from_name(s: &str) -> Option<SelectMode> {
        match s {
            "vertex" => Some(SelectMode::Vertex),
            "edge" => Some(SelectMode::Edge),
            "face" => Some(SelectMode::Face),
            _ => None,
        }
    }
}

/// Edit-mode state: which object, the element mode and the vertex-flag selection of its mesh.
#[derive(Clone, Debug)]
pub struct EditState {
    pub object: ObjId,
    pub mode: SelectMode,
    pub sel: Selection,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Context {
    Object,
    Edit,
    Both,
}

impl Context {
    pub fn name(self) -> &'static str {
        match self {
            Context::Object => "object",
            Context::Edit => "edit",
            Context::Both => "both",
        }
    }
}

pub struct OpEnv<'a> {
    pub scene: &'a mut Scene,
    pub edit: &'a mut Option<EditState>,
    pub ctx: &'a OpCtx,
}

#[derive(Clone, Debug, Default, PartialEq)]
pub struct OpOutcome {
    pub message: String,
    pub created: Vec<ObjId>,
}

impl OpOutcome {
    pub(crate) fn msg(s: impl Into<String>) -> OpOutcome {
        OpOutcome { message: s.into(), created: Vec::new() }
    }
}

pub(crate) type R = Result<OpOutcome, String>;
pub type OpFn = fn(&mut OpEnv, &Params) -> R;

pub struct OpDef {
    pub id: &'static str,
    pub label: &'static str,
    pub category: &'static str,
    pub context: Context,
    pub params: fn() -> Vec<ParamDef>,
    pub run: OpFn,
}

macro_rules! def {
    ($v:expr, $id:literal, $label:literal, $cat:literal, $ctx:expr, $params:expr, $run:expr) => {
        $v.push(crate::OpDef { id: $id, label: $label, category: $cat, context: $ctx, params: $params, run: $run })
    };
}
pub(crate) use def;

pub fn all() -> &'static [OpDef] {
    static REG: OnceLock<Vec<OpDef>> = OnceLock::new();
    REG.get_or_init(|| {
        let mut v = Vec::new();
        primitives::register(&mut v);
        object_ops::register(&mut v);
        edit_ops::register(&mut v);
        transform::register(&mut v);
        v
    })
}

pub fn find(id: &str) -> Option<&'static OpDef> {
    all().iter().find(|d| d.id == id)
}

/// `{"ops":[...]}` entries for `op.list`; `context` is "object", "edit" or "all".
pub fn list_json(context: &str) -> Json {
    let mut a = Json::arr();
    for d in all() {
        let keep = match context {
            "object" => d.context != Context::Edit,
            "edit" => d.context != Context::Object,
            _ => true,
        };
        if keep {
            let defs = (d.params)();
            a.push(
                Json::obj()
                    .set("id", d.id)
                    .set("label", d.label)
                    .set("category", d.category)
                    .set("context", d.context.name())
                    .set("params", defs_to_json(&defs, &Json::obj())),
            );
        }
    }
    a
}

#[derive(Debug)]
pub struct OpRun {
    pub outcome: OpOutcome,
    /// Complete parameter values that were used (defaults filled in): what a redo panel shows.
    pub values: Json,
}

/// Run an operator by id with `values` (a JSON object; missing entries take their defaults).
pub fn run(id: &str, env: &mut OpEnv, values: &Json) -> Result<OpRun, String> {
    let def = find(id).ok_or_else(|| format!("Unknown operator '{id}'"))?;
    let editing = env.edit.is_some();
    match def.context {
        Context::Edit if !editing => return Err(format!("{} needs Edit Mode", def.label)),
        Context::Object if editing => return Err(format!("{} is not available in Edit Mode", def.label)),
        _ => {}
    }
    let defs = (def.params)();
    let merged = merge_values(&defs, &Json::obj(), values);
    let params = Params::new(&defs, &merged);
    let outcome = (def.run)(env, &params)?;
    Ok(OpRun { outcome, values: merged })
}

// ---- helpers shared by the operator modules ------------------------------------------------------------------------

pub(crate) fn g<T>(r: GeomResult<T>) -> Result<T, String> {
    r.map_err(|e| e.to_string())
}

pub(crate) fn v3(p: &Params, name: &str) -> Vec3 {
    let a = p.v3(name);
    Vec3::new(a[0], a[1], a[2])
}

/// Degrees in a vec3 param -> radians.
pub(crate) fn v3_rad(p: &Params, name: &str) -> Vec3 {
    v3(p, name) * std::f32::consts::PI / 180.0
}

/// The mesh being edited together with its selection.
pub(crate) struct Target {
    pub id: ObjId,
    pub mesh: Arc<Mesh>,
    pub sel: Selection,
}

pub(crate) fn target(env: &OpEnv) -> Result<Target, String> {
    let e = env.edit.as_ref().ok_or("This operator needs Edit Mode")?;
    let obj = env.scene.get(e.object).ok_or("The edited object no longer exists")?;
    let mesh = obj.mesh().ok_or("The edited object is not a mesh")?.clone();
    let mut sel = e.sel.clone();
    sel.resize(mesh.vert_count());
    Ok(Target { id: e.object, mesh, sel })
}

pub(crate) fn need_sel(t: &Target) -> Result<(), String> {
    if t.sel.any() {
        Ok(())
    } else {
        Err("Nothing is selected".into())
    }
}

pub(crate) fn commit(env: &mut OpEnv, t: &Target, mesh: Mesh, sel: Selection) {
    env.scene.set_mesh(t.id, mesh);
    if let Some(e) = env.edit.as_mut() {
        let mut s = sel;
        if let Some(m) = env.scene.get(t.id).and_then(|o| o.mesh()) {
            s.resize(m.vert_count());
        }
        e.sel = s;
    }
}

/// Selected objects that carry mesh data.
pub(crate) fn selected_meshes(scene: &Scene) -> Vec<ObjId> {
    scene.selected.iter().copied().filter(|&i| scene.get(i).map_or(false, |o| o.mesh().is_some())).collect()
}
