//! Add-primitive operators (Blender names and defaults).
use super::*;
use forge_geom as geo;
use forge_geom::CapFill;
use forge_scene::{Data, Light, LightKind, Transform};

fn placement(mut v: Vec<ParamDef>) -> Vec<ParamDef> {
    v.push(ParamDef::vec3("location", "Location", [0.0; 3]).length());
    v.push(ParamDef::vec3("rotation", "Rotation", [0.0; 3]).angle());
    v
}

fn fills() -> [(&'static str, &'static str); 3] {
    [("NGON", "N-Gon"), ("TRIFAN", "Triangle Fan"), ("NOTHING", "Nothing")]
}

fn cap(p: &Params, name: &str) -> CapFill {
    match p.s(name).as_str() {
        "TRIFAN" => CapFill::TriFan,
        "NOTHING" => CapFill::Nothing,
        _ => CapFill::NGon,
    }
}

/// New object (object mode) or extra geometry in the edited mesh (edit mode).
fn place(env: &mut OpEnv, name: &str, mut mesh: Mesh, p: &Params) -> R {
    let t = Transform { location: v3(p, "location"), rotation: v3_rad(p, "rotation"), scale: Vec3::ONE };
    if let Some(e) = env.edit.as_ref() {
        let id = e.object;
        let obj = env.scene.get(id).ok_or("The edited object no longer exists")?;
        let old = obj.mesh().ok_or("The edited object is not a mesh")?.clone();
        mesh.transform(&(obj.transform.matrix().inverse() * t.matrix()));
        let base = old.vert_count();
        let joined = geo::join(&[&*old, &mesh]);
        let mut sel = Selection::none(joined.vert_count());
        for v in base..joined.vert_count() {
            sel.set(v as u32, true);
        }
        let tg = Target { id, mesh: old, sel: Selection::none(0) };
        commit(env, &tg, joined, sel);
        return Ok(OpOutcome::msg(format!("Added {name} to the mesh")));
    }
    let id = env.scene.add_mesh(name, mesh);
    if let Some(o) = env.scene.get_mut(id) {
        o.transform = t;
    }
    env.scene.set_selection(&[id], Some(id));
    Ok(OpOutcome { message: format!("Added {name}"), created: vec![id] })
}

fn cube(env: &mut OpEnv, p: &Params) -> R {
    place(env, "Cube", geo::cube(p.f("size") as f32, true), p)
}
fn plane(env: &mut OpEnv, p: &Params) -> R {
    place(env, "Plane", geo::plane(p.f("size") as f32, true), p)
}
fn uv_sphere(env: &mut OpEnv, p: &Params) -> R {
    let m = g(geo::uv_sphere(p.i("segments") as u32, p.i("ring_count") as u32, p.f("radius") as f32, true, env.ctx))?;
    place(env, "Sphere", m, p)
}
fn ico_sphere(env: &mut OpEnv, p: &Params) -> R {
    let m = g(geo::ico_sphere(p.i("subdivisions") as u32, p.f("radius") as f32, true, env.ctx))?;
    place(env, "Icosphere", m, p)
}
fn cylinder(env: &mut OpEnv, p: &Params) -> R {
    let m = g(geo::cylinder(p.i("vertices") as u32, p.f("radius") as f32, p.f("depth") as f32, cap(p, "end_fill_type"), true, env.ctx))?;
    place(env, "Cylinder", m, p)
}
fn cone(env: &mut OpEnv, p: &Params) -> R {
    let m = g(geo::cone(p.i("vertices") as u32, p.f("radius1") as f32, p.f("radius2") as f32, p.f("depth") as f32, cap(p, "end_fill_type"), true, env.ctx))?;
    place(env, "Cone", m, p)
}
fn torus(env: &mut OpEnv, p: &Params) -> R {
    let m = g(geo::torus(p.i("major_segments") as u32, p.i("minor_segments") as u32, p.f("major_radius") as f32, p.f("minor_radius") as f32, true, env.ctx))?;
    place(env, "Torus", m, p)
}
fn circle(env: &mut OpEnv, p: &Params) -> R {
    let m = g(geo::circle(p.i("vertices") as u32, p.f("radius") as f32, cap(p, "fill_type"), true, env.ctx))?;
    place(env, "Circle", m, p)
}
fn grid(env: &mut OpEnv, p: &Params) -> R {
    let m = g(geo::grid(p.i("x_subdivisions") as u32, p.i("y_subdivisions") as u32, p.f("size") as f32, true, env.ctx))?;
    place(env, "Grid", m, p)
}

fn light(env: &mut OpEnv, p: &Params) -> R {
    let kind = LightKind::from_name(&p.s("type")).unwrap_or(LightKind::Point);
    let name = match kind {
        LightKind::Point => "Point",
        LightKind::Sun => "Sun",
        LightKind::Spot => "Spot",
    };
    let id = env.scene.add_object(name, Data::Light(Light::new(kind)));
    if let Some(o) = env.scene.get_mut(id) {
        o.transform = Transform { location: v3(p, "location"), rotation: v3_rad(p, "rotation"), scale: Vec3::ONE };
    }
    env.scene.set_selection(&[id], Some(id));
    Ok(OpOutcome { message: format!("Added {name} light"), created: vec![id] })
}

fn empty(env: &mut OpEnv, p: &Params) -> R {
    let id = env.scene.add_object("Empty", Data::Empty);
    if let Some(o) = env.scene.get_mut(id) {
        o.transform = Transform { location: v3(p, "location"), rotation: v3_rad(p, "rotation"), scale: Vec3::ONE };
    }
    env.scene.set_selection(&[id], Some(id));
    Ok(OpOutcome { message: "Added Empty".into(), created: vec![id] })
}

fn radius(d: f64) -> ParamDef {
    ParamDef::float("radius", "Radius", d).min(0.0001).length()
}

pub(crate) fn register(v: &mut Vec<OpDef>) {
    let c = Context::Both;
    let o = Context::Object;
    def!(v, "mesh.primitive_cube_add", "Cube", "add", c, || placement(vec![ParamDef::float("size", "Size", 2.0).min(0.0001).length()]), cube);
    def!(v, "mesh.primitive_plane_add", "Plane", "add", c, || placement(vec![ParamDef::float("size", "Size", 2.0).min(0.0001).length()]), plane);
    def!(v, "mesh.primitive_uv_sphere_add", "UV Sphere", "add", c, || placement(vec![
        ParamDef::int("segments", "Segments", 32).range(3.0, 256.0),
        ParamDef::int("ring_count", "Rings", 16).range(2.0, 256.0),
        radius(1.0),
    ]), uv_sphere);
    def!(v, "mesh.primitive_ico_sphere_add", "Ico Sphere", "add", c, || placement(vec![
        ParamDef::int("subdivisions", "Subdivisions", 2).range(1.0, 6.0),
        radius(1.0),
    ]), ico_sphere);
    def!(v, "mesh.primitive_cylinder_add", "Cylinder", "add", c, || placement(vec![
        ParamDef::int("vertices", "Vertices", 32).range(3.0, 512.0),
        radius(1.0),
        ParamDef::float("depth", "Depth", 2.0).min(0.0001).length(),
        ParamDef::choice("end_fill_type", "Cap Fill", "NGON", &fills()),
    ]), cylinder);
    def!(v, "mesh.primitive_cone_add", "Cone", "add", c, || placement(vec![
        ParamDef::int("vertices", "Vertices", 32).range(3.0, 512.0),
        ParamDef::float("radius1", "Radius 1", 1.0).min(0.0).length(),
        ParamDef::float("radius2", "Radius 2", 0.0).min(0.0).length(),
        ParamDef::float("depth", "Depth", 2.0).min(0.0001).length(),
        ParamDef::choice("end_fill_type", "Base Fill", "NGON", &fills()),
    ]), cone);
    def!(v, "mesh.primitive_torus_add", "Torus", "add", c, || placement(vec![
        ParamDef::int("major_segments", "Major Segments", 48).range(3.0, 512.0),
        ParamDef::int("minor_segments", "Minor Segments", 12).range(3.0, 256.0),
        ParamDef::float("major_radius", "Major Radius", 1.0).min(0.0001).length(),
        ParamDef::float("minor_radius", "Minor Radius", 0.25).min(0.0001).length(),
    ]), torus);
    def!(v, "mesh.primitive_circle_add", "Circle", "add", c, || placement(vec![
        ParamDef::int("vertices", "Vertices", 32).range(3.0, 512.0),
        radius(1.0),
        ParamDef::choice("fill_type", "Fill", "NOTHING", &fills()),
    ]), circle);
    def!(v, "mesh.primitive_grid_add", "Grid", "add", c, || placement(vec![
        ParamDef::int("x_subdivisions", "X Subdivisions", 10).range(1.0, 500.0),
        ParamDef::int("y_subdivisions", "Y Subdivisions", 10).range(1.0, 500.0),
        ParamDef::float("size", "Size", 2.0).min(0.0001).length(),
    ]), grid);
    def!(v, "object.light_add", "Light", "add", o, || placement(vec![ParamDef::choice("type", "Type", "POINT", &[("POINT", "Point"), ("SUN", "Sun"), ("SPOT", "Spot")])]), light);
    def!(v, "object.empty_add", "Empty", "add", o, || placement(Vec::new()), empty);
}
