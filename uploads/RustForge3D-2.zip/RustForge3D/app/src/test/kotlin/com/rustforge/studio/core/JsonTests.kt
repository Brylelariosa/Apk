package com.rustforge.studio.core

import com.rustforge.studio.testing.T

object JsonTests {
    fun run() {
        T.test("json: scalars and containers") {
            T.eq(Json.Null, Json.parse("null"))
            T.eq(Json.Bool(true), Json.parse(" true "))
            T.eq(Json.Num(-12.5), Json.parse("-12.5"))
            T.eq(Json.Str("hi"), Json.parse("\"hi\""))
            val v = Json.parse("""{"a":[1,2,{"b":null}],"c":{}}""")
            T.eq(2, v["a"][1].int())
            T.ok(v["a"][2]["b"].isNull)
            T.ok(v["c"].map.isEmpty())
            T.eq(3, v["a"].list.size)
        }
        T.test("json: numbers with exponents and big values") {
            T.near(1.5e3, Json.parse("1.5e3").double())
            T.near(2.5E-4, Json.parse("2.5E-4").double())
            T.near(1e22, Json.parse("1E+22").double())
            T.eq(0, Json.parse("-0").int())
            T.eq(4_000_000_000L, Json.parse("4000000000").long())
            T.near(0.1, Json.parse("0.1").double(), 0.0)
        }
        T.test("json: escapes, unicode and surrogate pairs") {
            T.eq("a\"b\\c/d\ne\tf", Json.parse("\"a\\\"b\\\\c\\/d\\ne\\tf\"").str())
            T.eq("é€", Json.parse("\"\\u00e9\\u20AC\"").str())
            val grin = Json.parse("\"\\ud83d\\ude00\"").str()
            T.eq("\uD83D\uDE00", grin)
            T.eq(1, grin.codePointCount(0, grin.length))
            T.eq("日本語", Json.parse("\"日本語\"").str())
        }
        T.test("json: writer escapes and round-trips") {
            val tricky = "quote\" back\\ nl\n tab\t ctl\u0001 uni é \uD83D\uDE00"
            val text = jsonOf("k" to tricky, "n" to 3, "f" to 0.5, "z" to null, "b" to true).toString()
            val back = Json.parse(text)
            T.eq(tricky, back["k"].str())
            T.eq(3, back["n"].int())
            T.near(0.5, back["f"].double())
            T.ok(back["z"].isNull)
            T.ok(back["b"].bool())
            T.ok(text.contains("\\u0001"), text)
        }
        T.test("json: number formatting") {
            T.eq("3", JsonWriter.formatNumber(3.0))
            T.eq("-7", JsonWriter.formatNumber(-7.0))
            T.eq("0", JsonWriter.formatNumber(-0.0))
            T.eq("0.25", JsonWriter.formatNumber(0.25))
            T.eq("null", JsonWriter.formatNumber(Double.NaN))
            T.eq("null", JsonWriter.formatNumber(Double.POSITIVE_INFINITY))
            T.eq("0.1", toJson(0.1f).toString())
            T.eq("[1,2.5,3]", toJson(floatArrayOf(1f, 2.5f, 3f)).toString())
            T.near(1.0E-5, Json.parse(JsonWriter.formatNumber(1.0E-5)).double(), 0.0)
        }
        T.test("json: builders convert Kotlin values") {
            val j = jsonOf("ids" to listOf(1, 2), "pos" to floatArrayOf(1f, 2f, 3f), "m" to mapOf("x" to 1), "s" to "t")
            T.eq("""{"ids":[1,2],"pos":[1,2,3],"m":{"x":1},"s":"t"}""", j.toString())
            T.eq("""{"a":1,"b":2}""", jsonOf("a" to 1).merged(jsonOf("b" to 2)).toString())
            T.eq("""{"a":2}""", jsonOf("a" to 1).merged(jsonOf("a" to 2)).toString())
        }
        T.test("json: accessors never throw") {
            val v = Json.parse("""{"a":"x","n":4.7,"t":true,"arr":[1,"s",2]}""")
            T.eq("", v["n"].str())
            T.eq("d", v["missing"].str("d"))
            T.eq(4, v["n"].int())
            T.eq(7, v["a"].int(7))
            T.ok(v["t"].bool())
            T.ok(!v["a"].bool())
            T.eq(listOf(1f, 0f, 2f), v["arr"].floats())
            T.eq(listOf("s"), v["arr"].strings())
            T.ok(v[3].isNull)
            T.ok(v.path("a.b.c").isNull)
        }
        T.test("json: dotted path") {
            val v = Json.parse("""{"viewport":{"quality":"auto","msaa":4}}""")
            T.eq("auto", v.path("viewport.quality").str())
            T.eq(4, v.path("viewport.msaa").int())
        }
        T.test("json: malformed input reports position") {
            fun bad(text: String, fragment: String) {
                try {
                    Json.parse(text)
                    throw AssertionError("accepted: $text")
                } catch (e: JsonException) {
                    T.ok(e.message!!.contains(fragment), "message '${e.message}' lacks '$fragment' for $text")
                }
            }
            bad("", "end of input")
            bad("{", "Unterminated")
            bad("[1,]", "Unexpected character")
            bad("{\"a\" 1}", "Expected ':'")
            bad("{a:1}", "string key")
            bad("[1 2]", "Expected ','")
            bad("\"abc", "Unterminated string")
            bad("\"a\\qb\"", "Invalid escape")
            bad("\"\\u12\"", "\\u")
            bad("01", "Leading zeros")
            bad("1.", "Digits expected")
            bad("1e", "exponent")
            bad("-", "Incomplete")
            bad("tru", "Invalid literal")
            bad("{} x", "trailing")
            bad("\"a\nb\"", "Control character")
            bad("[\n\n  x]", "line 3, column 3")
        }
        T.test("json: nesting depth is limited, not fatal") {
            val ok = "[".repeat(200) + "]".repeat(200)
            T.ok(Json.parse(ok) is Json.Arr)
            val deep = "[".repeat(5000) + "]".repeat(5000)
            T.ok(Json.parseOrNull(deep) == null)
        }
        T.test("json: parseOrNull") {
            T.ok(Json.parseOrNull(null) == null)
            T.ok(Json.parseOrNull("{") == null)
            T.ok(Json.parseOrNull("{}") != null)
        }
        T.test("json: large documents") {
            val sb = StringBuilder("[")
            for (k in 0 until 20_000) {
                if (k > 0) sb.append(',')
                sb.append("{\"id\":").append(k).append(",\"name\":\"obj").append(k).append("\"}")
            }
            sb.append(']')
            val v = Json.parse(sb.toString())
            T.eq(20_000, v.list.size)
            T.eq("obj19999", v[19_999]["name"].str())
        }
    }
}
