package com.rustforge.studio.core

import com.rustforge.studio.testing.T

object NumericExprTests {
    private fun v(text: String, unit: ParamUnit = ParamUnit.NONE): Double = NumericExpr.eval(text, unit).value ?: throw AssertionError("'$text' failed: ${NumericExpr.eval(text, unit).error}")
    private fun bad(text: String, fragment: String, unit: ParamUnit = ParamUnit.NONE) {
        val r = NumericExpr.eval(text, unit)
        T.ok(r.value == null, "'$text' should fail")
        T.ok(r.error!!.contains(fragment, ignoreCase = true), "'$text' -> '${r.error}' lacks '$fragment'")
    }

    fun run() {
        T.test("expr: arithmetic and precedence") {
            T.near(3.25, v("2*1.5+0.25"))
            T.near(9.0, v("(1+2)*3"))
            T.near(7.0, v("1+2*3"))
            T.near(-4.0, v("-2^2"))
            T.near(512.0, v("2^3^2"))
            T.near(2.5, v("5/2"))
            T.near(-3.0, v(" - 3 "))
            T.near(4.0, v("+4"))
            T.near(1000.0, v("1e3"))
            T.near(0.015, v("1.5E-2"))
            T.near(0.5, v(".5"))
            T.near(Math.PI, v("pi"))
            T.near(2 * Math.PI, v("2*pi"), 1e-12)
        }
        T.test("expr: length units convert to metres") {
            T.near(0.5, v("50cm", ParamUnit.LENGTH))
            T.near(1.7, v("1.5m+20cm", ParamUnit.LENGTH))
            T.near(0.002, v("2mm", ParamUnit.LENGTH))
            T.near(1500.0, v("1.5km", ParamUnit.LENGTH))
            T.near(0.0254, v("1in", ParamUnit.LENGTH))
            T.near(0.3048, v("1 ft", ParamUnit.LENGTH))
            T.near(3.0, v("3", ParamUnit.LENGTH))
            T.near(0.6, v("(20+10)cm*2", ParamUnit.LENGTH), 1e-12)
        }
        T.test("expr: angle units convert to degrees") {
            T.near(90.0, v("90deg", ParamUnit.ANGLE))
            T.near(90.0, v("90°", ParamUnit.ANGLE))
            T.near(180.0, v("3.141592653589793rad", ParamUnit.ANGLE), 1e-9)
            T.near(45.0, v("45", ParamUnit.ANGLE))
            T.near(100.0, v("90deg+10", ParamUnit.ANGLE))
        }
        T.test("expr: errors are explained") {
            bad("", "Enter a number")
            bad("   ", "Enter a number")
            bad("1/0", "Division by zero")
            bad("2*", "end of expression")
            bad("(1+2", "Missing ')'")
            bad("1+*2", "Unexpected '*'")
            bad("abc", "Unknown name")
            bad("5m", "Units are not allowed")
            bad("5deg", "Unknown length unit", ParamUnit.LENGTH)
            bad("5cm", "Unknown angle unit", ParamUnit.ANGLE)
            bad("1 2", "Unexpected")
            bad("1.2.3", "Invalid number")
            bad("10^400", "not a finite")
        }
        T.test("expr: evalOrNull") {
            T.eq(4.0, NumericExpr.evalOrNull("2+2"))
            T.ok(NumericExpr.evalOrNull("2+") == null)
        }
    }
}
