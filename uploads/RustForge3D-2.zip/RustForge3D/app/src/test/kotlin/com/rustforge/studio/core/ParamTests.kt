package com.rustforge.studio.core

import com.rustforge.studio.testing.T

object ParamTests {
    private fun def(json: String) = ParamDefs.parse(Json.parse(json))

    fun run() {
        T.test("param: parses every field") {
            val d = def(
                """{"name":"offset","label":"Offset","type":"float","value":0.2,"default":0.1,"min":0,"max":100,"soft_max":10,"step":0.01,
                "unit":"length","help":"Distance","visible_if":{"name":"affect","equals":"EDGES"}}""",
            )
            T.eq("offset", d.name)
            T.eq("Offset", d.label)
            T.eq(ParamKind.FLOAT, d.kind)
            T.near(0.2, d.number)
            T.near(0.0, d.min!!)
            T.near(100.0, d.max!!)
            T.near(10.0, d.softMax!!)
            T.near(0.01, d.step!!)
            T.eq(ParamUnit.LENGTH, d.unit)
            T.eq("Distance", d.help)
            T.eq(VisibleIf("affect", Json.Str("EDGES")), d.visibleIf)
        }
        T.test("param: enum options and kinds") {
            val d = def("""{"name":"affect","type":"enum","value":"EDGES","default":"EDGES","options":[["EDGES","Edges"],["VERTICES","Vertices"]]}""")
            T.eq(ParamKind.ENUM, d.kind)
            T.eq(listOf("EDGES" to "Edges", "VERTICES" to "Vertices"), d.options)
            T.eq("affect", d.label)
            for ((name, kind) in listOf("int" to ParamKind.INT, "bool" to ParamKind.BOOL, "bvec3" to ParamKind.BVEC3, "vec2" to ParamKind.VEC2,
                "vec3" to ParamKind.VEC3, "color" to ParamKind.COLOR, "string" to ParamKind.STRING, "object" to ParamKind.OBJECT,
                "material" to ParamKind.MATERIAL, "weird" to ParamKind.UNKNOWN)) {
                T.eq(kind, ParamKind.parse(name))
            }
        }
        T.test("param: visible_if follows the other parameter's value") {
            val mirror = EngineState.parse(Fixtures.SCENE).active!!.modifiers.single().params
            val threshold = mirror.first { it.name == "merge_threshold" }
            T.ok(threshold.visibleIf != null)
            T.ok(threshold.isVisible(mirror))
            val merge = mirror.first { it.name == "use_mirror_merge" }
            val off = mirror.map { if (it.name == merge.name) it.withValue(Json.Bool(false)) else it }
            T.ok(!threshold.isVisible(off))
            T.ok(merge.isVisible(off))
            T.ok(threshold.isVisible(emptyList()), "unknown controlling parameter -> visible")
        }
        T.test("param: loose equality treats bools and 0/1 alike") {
            T.ok(ParamDefs.looseEquals(Json.Bool(true), Json.Num(1.0)))
            T.ok(!ParamDefs.looseEquals(Json.Bool(true), Json.Num(0.0)))
            T.ok(ParamDefs.looseEquals(Json.Str("A"), Json.Str("A")))
            T.ok(!ParamDefs.looseEquals(Json.Str("A"), Json.Str("B")))
        }
        T.test("param: edits produce the params JSON for op.redo and modifier.set") {
            val d = def("""{"name":"thickness","type":"float","value":0.1,"default":0.1,"min":0,"unit":"length"}""")
            T.eq("""{"params":{"thickness":0.25}}""", d.patch(Json.Num(0.25)).toString())
            val v = def("""{"name":"location","type":"vec3","value":[1,2,3],"default":[0,0,0]}""")
            T.eq("[1,5,3]", ParamDefs.withComponent(v, 1, Json.Num(5.0)).toString())
            val b = def("""{"name":"axes","type":"bvec3","value":[true],"default":[false,false,false]}""")
            T.eq("[true,false,true]", ParamDefs.withComponent(b, 2, Json.Bool(true)).toString())
        }
        T.test("param: slider ranges and clamping") {
            val ang = def("""{"name":"a","type":"float","value":30,"default":0,"unit":"angle"}""")
            T.eq(SliderRange(-360f, 360f), ang.sliderRange())
            val th = def("""{"name":"t","type":"float","value":0.1,"default":0.1,"min":0,"unit":"length"}""")
            T.eq(SliderRange(0f, 4f), th.sliderRange())
            val seg = def("""{"name":"s","type":"int","value":32,"default":32,"min":3,"max":256}""")
            T.eq(SliderRange(3f, 256f), seg.sliderRange())
            val soft = def("""{"name":"s","type":"float","value":1,"default":1,"min":0,"max":100,"soft_max":10}""")
            T.eq(SliderRange(0f, 10f), soft.sliderRange())
            T.near(256.0, seg.clamp(1000.0))
            T.near(3.0, seg.clamp(-5.0))
            T.near(7.0, seg.clamp(6.6), 0.0)
            T.near(50.0, soft.clamp(50.0))
        }
        T.test("param: number formatting and entry") {
            T.eq("0.1", ParamFormat.plain(0.1))
            T.eq("3", ParamFormat.plain(3.0))
            T.eq("-1.5", ParamFormat.plain(-1.5))
            T.eq("0", ParamFormat.plain(-0.00001))
            T.eq("0.3333", ParamFormat.plain(1.0 / 3.0))
            T.eq("12", ParamFormat.number(12.4, def("""{"name":"n","type":"int","value":12,"default":1}""")))
            val len = def("""{"name":"d","type":"float","value":1,"default":1,"min":0,"max":10,"unit":"length"}""")
            T.near(0.5, ParamFormat.parse("50cm", len)!!)
            T.near(10.0, ParamFormat.parse("1000", len)!!)
            T.ok(ParamFormat.parse("abc", len) == null)
            val ang = def("""{"name":"a","type":"float","value":0,"default":0,"unit":"angle"}""")
            T.near(90.0, ParamFormat.parse("90deg", ang)!!)
            T.eq("m", ParamFormat.unitSuffix(ParamUnit.LENGTH))
        }
    }
}
