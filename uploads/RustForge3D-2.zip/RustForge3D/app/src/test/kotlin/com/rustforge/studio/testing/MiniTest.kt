package com.rustforge.studio.testing

/** Minimal dependency-free test harness (no JUnit on the offline machine). Used by `tools/run-kotlin-tests.sh`. */
class TestFailure(message: String) : Exception(message)

object T {
    var passed = 0
        private set
    var failed = 0
        private set
    private val failures = ArrayList<String>()

    /** Runs one named test; exceptions are recorded as failures instead of aborting the run. */
    fun test(name: String, body: () -> Unit) {
        try {
            body()
            passed++
        } catch (e: Throwable) {
            failed++
            val where = e.stackTrace.firstOrNull { it.className.contains("Tests") }?.let { " (${it.fileName}:${it.lineNumber})" } ?: ""
            failures.add("FAIL $name: ${e.message ?: e.toString()}$where")
        }
    }

    fun <A> eq(expected: A, actual: A, message: String = "") {
        if (expected != actual) throw TestFailure("expected <$expected> but was <$actual> $message".trim())
    }

    fun ok(condition: Boolean, message: String = "condition is false") {
        if (!condition) throw TestFailure(message)
    }

    fun near(expected: Double, actual: Double, eps: Double = 1e-9, message: String = "") {
        if (kotlin.math.abs(expected - actual) > eps) throw TestFailure("expected <$expected> +/- $eps but was <$actual> $message".trim())
    }

    /** Asserts that [body] throws an exception of type [E]. */
    inline fun <reified E : Throwable> throws(message: String = "", body: () -> Unit) {
        try {
            body()
        } catch (e: Throwable) {
            if (e is E) return
            throw TestFailure("expected ${E::class.simpleName} but got ${e::class.simpleName}: ${e.message} $message".trim())
        }
        throw TestFailure("expected ${E::class.simpleName} but nothing was thrown $message".trim())
    }

    fun summary(): String {
        val sb = StringBuilder()
        failures.forEach { sb.appendLine(it) }
        sb.append("tests: $passed passed, $failed failed")
        return sb.toString()
    }
}
