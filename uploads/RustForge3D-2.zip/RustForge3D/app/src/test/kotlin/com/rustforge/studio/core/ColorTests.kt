package com.rustforge.studio.core

import com.rustforge.studio.testing.T

object ColorTests {
    private fun close(a: Rgb, b: Rgb, eps: Double = 1e-4) {
        T.near(a.r.toDouble(), b.r.toDouble(), eps, "r")
        T.near(a.g.toDouble(), b.g.toDouble(), eps, "g")
        T.near(a.b.toDouble(), b.b.toDouble(), eps, "b")
    }

    fun run() {
        T.test("color: sRGB <-> linear") {
            T.near(0.0, ColorMath.srgbToLinear(0f).toDouble())
            T.near(1.0, ColorMath.srgbToLinear(1f).toDouble(), 1e-6)
            T.near(0.2140, ColorMath.srgbToLinear(0.5f).toDouble(), 1e-3)
            for (i in 0..20) {
                val c = i / 20f
                T.near(c.toDouble(), ColorMath.linearToSrgb(ColorMath.srgbToLinear(c)).toDouble(), 1e-5)
            }
            close(Rgb(0.8f, 0.4f, 0.1f), ColorMath.toSrgb(ColorMath.toLinear(Rgb(0.8f, 0.4f, 0.1f))))
        }
        T.test("color: HSV round trip") {
            for (c in listOf(Rgb(1f, 0f, 0f), Rgb(0f, 1f, 0f), Rgb(0f, 0f, 1f), Rgb(0.2f, 0.6f, 0.9f), Rgb(0.5f, 0.5f, 0.5f), Rgb(0f, 0f, 0f), Rgb(1f, 1f, 1f), Rgb(0.9f, 0.1f, 0.5f))) {
                close(c, ColorMath.hsvToRgb(ColorMath.rgbToHsv(c)))
            }
            T.near(0.0, ColorMath.rgbToHsv(Rgb(1f, 0f, 0f)).h.toDouble())
            T.near(120.0, ColorMath.rgbToHsv(Rgb(0f, 1f, 0f)).h.toDouble())
            T.near(240.0, ColorMath.rgbToHsv(Rgb(0f, 0f, 1f)).h.toDouble())
            T.near(300.0, ColorMath.rgbToHsv(Rgb(1f, 0f, 1f)).h.toDouble(), 1e-4)
            close(Rgb(1f, 1f, 0f), ColorMath.hsvToRgb(Hsv(60f, 1f, 1f)))
            close(Rgb(1f, 0f, 0f), ColorMath.hsvToRgb(Hsv(360f, 1f, 1f)))
            close(Rgb(1f, 0f, 0f), ColorMath.hsvToRgb(Hsv(-360f, 1f, 1f)))
        }
        T.test("color: hex") {
            T.eq("#FF8000", ColorMath.toHex(Rgb(1f, 0.5f, 0f)))
            T.eq("#000000", ColorMath.toHex(Rgb(-1f, 0f, 0f)))
            close(Rgb(1f, 1f, 1f), ColorMath.parseHex("#ffffff")!!)
            close(Rgb(1f, 0f, 0f), ColorMath.parseHex("f00")!!)
            close(Rgb(0.2f, 0.4f, 0.6f), ColorMath.parseHex(" 336699 ")!!)
            T.ok(ColorMath.parseHex("#12345") == null)
            T.ok(ColorMath.parseHex("#GGGGGG") == null)
            T.ok(ColorMath.parseHex("") == null)
            val c = Rgb(0.123f, 0.456f, 0.789f)
            close(c, ColorMath.parseHex(ColorMath.toHex(c))!!, 1 / 255.0)
        }
    }
}
