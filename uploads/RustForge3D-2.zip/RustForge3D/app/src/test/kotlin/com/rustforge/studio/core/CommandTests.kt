package com.rustforge.studio.core

import com.rustforge.studio.testing.T

object CommandTests {
    fun run() {
        T.test("call result: success, failure and garbage") {
            val ok = CallResult.parse("""{"ok":true,"created":[3]}""")
            T.ok(ok.ok && ok.error.isEmpty())
            T.eq(3, ok.json["created"][0].int())
            val bad = CallResult.parse("""{"ok":false,"error":"Nothing to undo"}""")
            T.ok(!bad.ok)
            T.eq("Nothing to undo", bad.error)
            T.eq("The command failed", CallResult.parse("""{"ok":false}""").error)
            T.ok(!CallResult.parse("garbage").ok)
            T.ok(!CallResult.parse(null).ok)
            T.ok(!CallResult.parse("[1]").ok)
            T.ok(!CallResult.parse("{}").ok, "a reply without ok is not a success")
        }
        T.test("commands: op.run arguments") {
            T.eq("""{"id":"mesh.primitive_cube_add","params":{"size":3}}""", Cmd.op("mesh.primitive_cube_add", "size" to 3).toString())
            T.eq("""{"id":"object.delete","params":{}}""", Cmd.op("object.delete").toString())
            T.eq("VERT", Cmd.deleteType("vertex"))
            T.eq("EDGE", Cmd.deleteType("edge"))
            T.eq("FACE", Cmd.deleteType("face"))
        }
        T.test("commands: menus reference real operator ids") {
            // The authoritative list: operator ids registered in forge-ops (docs/PROTOCOL.md section 4.3).
            val registered = setOf(
                "mesh.primitive_cube_add", "mesh.primitive_plane_add", "mesh.primitive_uv_sphere_add", "mesh.primitive_ico_sphere_add",
                "mesh.primitive_cylinder_add", "mesh.primitive_cone_add", "mesh.primitive_torus_add", "mesh.primitive_circle_add", "mesh.primitive_grid_add",
                "object.light_add", "object.empty_add", "object.delete", "object.duplicate_move", "object.join", "object.shade_smooth", "object.shade_flat",
                "object.modifier_add", "object.modifier_remove", "object.modifier_apply", "object.hide_view_set", "object.hide_view_clear", "object.origin_set",
                "object.transform_apply", "mesh.extrude_region_move", "mesh.extrude_faces_indiv", "mesh.extrude_edges_move", "mesh.extrude_vertices_move",
                "mesh.inset", "mesh.loopcut_slide", "mesh.subdivide", "mesh.delete", "mesh.merge", "mesh.remove_doubles", "mesh.dissolve_verts",
                "mesh.dissolve_edges", "mesh.dissolve_faces", "mesh.flip_normals", "mesh.normals_make_consistent", "mesh.faces_shade_smooth",
                "mesh.faces_shade_flat", "mesh.quads_convert_to_tris", "mesh.fill", "mesh.duplicate_move", "mesh.separate", "mesh.vertices_smooth", "mesh.symmetrize",
            )
            for ((id, _, icon) in Cmd.primitives) {
                T.ok(id in registered, id)
                T.ok(IconSet.has(icon), icon)
            }
            for (op in OperatorMenus.object_ + OperatorMenus.meshOps("face")) {
                T.ok(op.id in registered, op.id)
                T.ok(IconSet.has(op.icon), op.icon)
            }
            T.eq(listOf("type" to "FACE"), OperatorMenus.meshOps("face").first { it.id == "mesh.delete" }.params)
        }
    }
}
