package com.rustforge.studio.core

import com.rustforge.studio.testing.T

object StateTests {
    fun run() {
        T.test("state: default scene snapshot") {
            val s = EngineState.parse(Fixtures.OBJECT)
            T.eq("object", s.mode)
            T.eq("select", s.tool)
            T.ok(!s.isEdit)
            T.eq(1, s.scene.objects.size)
            val cube = s.scene.objects[0]
            T.eq("Cube", cube.name)
            T.eq("mesh", cube.kind)
            T.ok(cube.selected && cube.active)
            T.eq(8, cube.verts)
            T.eq(6, cube.faces)
            T.eq(null, cube.material)
            val a = s.active!!
            T.eq(Vec3(2f, 2f, 2f), a.dimensions)
            T.eq(Vec3.ONE, a.scale)
            T.eq(8, a.mesh!!.verts)
            T.eq(12, a.mesh!!.edges)
            T.ok(a.mesh!!.valid)
            T.ok(a.light == null && a.camera == null)
            T.ok(s.edit == null && s.lastOp == null && s.toolState == null && s.toast == null)
            T.ok(!s.undo.canUndo && !s.undo.canRedo)
            T.eq(1, s.stats.objects)
            T.eq(8L, s.stats.verts)
            T.eq(1, s.scene.collections.size)
        }
        T.test("state: scene with light, material, modifier and undo history") {
            val s = EngineState.parse(Fixtures.SCENE)
            T.eq(3, s.scene.objects.size)
            T.eq("light", s.scene.objects[1].kind)
            T.eq("Stone", s.scene.objects[2].material)
            T.eq(3, s.scene.active)
            T.eq(1, s.scene.selectedCount)
            T.eq(listOf(3), s.selectedObjects.map { it.id })
            T.eq("Sphere", s.objectById(3)!!.name)
            T.ok(s.objectById(99) == null)
            val m = s.materials.single()
            T.eq("Stone", m.name)
            T.eq(listOf(0.5f, 0.4f, 0.3f, 1f), m.baseColor)
            T.near(0.8, m.roughness.toDouble(), 1e-6)
            T.eq(1, m.users)
            val a = s.active!!
            T.eq(SlotInfo(0, 1, "Stone"), a.slots.single())
            val mod = a.modifiers.single()
            T.eq("MIRROR", mod.type)
            T.eq("Mirror", mod.name)
            T.eq(5, mod.params.size)
            T.ok(s.undo.canUndo)
            T.eq("Assign Material", s.undo.undoLabel)
            T.eq(5, s.undo.depth)
        }
        T.test("state: edit mode snapshot with redo panel") {
            val s = EngineState.parse(Fixtures.EDIT)
            T.ok(s.isEdit)
            T.eq("face", s.selectMode)
            val e = s.edit!!
            T.eq(Counts(26, 26), e.verts)
            T.eq(Counts(32, 32), e.faces)
            val op = s.lastOp!!
            T.eq("mesh.inset", op.id)
            T.eq("Inset Faces", op.label)
            T.eq(listOf("thickness", "depth", "use_individual", "use_boundary", "use_even_offset"), op.params.map { it.name })
            val thickness = op.params[0]
            T.eq(ParamKind.FLOAT, thickness.kind)
            T.eq(ParamUnit.LENGTH, thickness.unit)
            T.near(0.1, thickness.number)
            T.near(0.0, thickness.min!!)
            T.ok(thickness.max == null)
            T.eq(ParamKind.BOOL, op.params[2].kind)
        }
        T.test("state: settings are readable by path and complete") {
            val s = EngineState.parse(Fixtures.OBJECT).settings
            T.near(1.0, s.f("touch.sensitivity"))
            T.eq("orbit", s.s("gestures.one_finger"))
            T.ok(s.b("select.xray_box"))
            T.ok(!s.b("snap.grid"))
            T.eq("auto", s.s("viewport.quality"))
            T.eq("fallback", s.s("nope.nothing", "fallback"))
            for (spec in SettingsSpecs.all) {
                T.ok(s.json.path(spec.path) !is Json.Null, "settings spec path ${spec.path} is missing from the engine's settings")
            }
        }
        T.test("state: settings spec is consistent with the engine's choices and ranges") {
            val s = EngineState.parse(Fixtures.OBJECT).settings
            for (spec in SettingsSpecs.all) {
                when (val c = spec.control) {
                    is SettingControl.Slider -> {
                        T.ok(c.min < c.max && c.step > 0f, spec.path)
                        val v = s.f(spec.path)
                        T.ok(v >= c.min - 1e-6 && v <= c.max + 1e-6, "${spec.path} default $v outside ${c.min}..${c.max}")
                    }
                    is SettingControl.Choice -> {
                        T.ok(c.options.any { it.first == s.s(spec.path) }, "${spec.path} default not among options")
                    }
                    SettingControl.Toggle -> T.ok(s.json.path(spec.path) is Json.Bool, "${spec.path} is not a boolean")
                }
            }
            T.eq(SettingsSpecs.all.size, SettingsSpecs.all.map { it.path }.toSet().size)
        }
        T.test("state: light and camera details") {
            val j = """{"active":{"id":2,"name":"Spot","kind":"light","transform":{"location":[1,2,3],"rotation":[0,90,0],"scale":[1,1,1]},
                "dimensions":[0,0,0],"mesh":null,"modifiers":[],"slots":[],
                "light":{"type":"SPOT","color":[1,0.5,0.25],"energy":800,"spot_size_deg":45,"spot_blend":0.15},
                "camera":{"lens_mm":35,"sensor_mm":36,"clip_start":0.1,"clip_end":500,"ortho":true,"ortho_scale":4}}}"""
            val a = SnapshotParser.parse(Json.parse(j)).active!!
            T.eq("SPOT", a.light!!.type)
            T.eq(Vec3(1f, 0.5f, 0.25f), a.light!!.color)
            T.near(800.0, a.light!!.energy.toDouble())
            T.eq(Vec3(1f, 2f, 3f), a.location)
            T.eq(Vec3(0f, 90f, 0f), a.rotation)
            T.ok(a.mesh == null)
            T.ok(a.camera!!.ortho)
            T.near(35.0, a.camera!!.lensMm.toDouble())
        }
        T.test("state: tool state, toast and script blocks") {
            val j = """{"tool_state":{"kind":"extrude","label":"Extrude","value":0.5,"unit":"m","hint":"Drag"},
                "toast":{"seq":7,"level":"warn","text":"Mesh has 2 non-manifold edges"},
                "script":{"status":"error","run_mode":"add","elapsed_ms":120,"console_seq":42,"created":3,
                          "error":{"line":3,"col":1,"end_col":9,"message":"NameError","traceback":"..."},"available":true}}"""
            val s = SnapshotParser.parse(Json.parse(j))
            T.eq(ToolState("extrude", "Extrude", 0.5, "m", "Drag"), s.toolState)
            T.eq(EngineToast(7, "warn", "Mesh has 2 non-manifold edges"), s.toast)
            T.eq("error", s.script.status)
            T.eq("NameError", s.script.errorMessage)
            T.ok(s.script.available)
            T.eq(42L, s.script.consoleSeq)
        }
        T.test("state: missing, partial and garbled snapshots fall back to defaults") {
            T.eq(EngineState(), SnapshotParser.parse(Json.parse("{}")))
            val weird = SnapshotParser.parse(Json.parse("""{"rev":"x","scene":5,"active":[1],"materials":{"a":1},"stats":7,"mode":3}"""))
            T.eq(0L, weird.rev)
            T.eq(SceneState(), weird.scene)
            T.ok(weird.active == null)
            T.ok(weird.materials.isEmpty())
            T.eq("object", weird.mode)
            val partial = SnapshotParser.parse(Json.parse("""{"scene":{"objects":[{"id":4}]},"future_field":{"x":1}}"""))
            T.eq(1, partial.scene.objects.size)
            T.eq(4, partial.scene.objects[0].id)
            T.ok(partial.scene.objects[0].visible)
            T.throws<JsonException> { EngineState.parse("not json") }
        }
        T.test("state: equal snapshots compare equal (StateFlow can skip them)") {
            T.eq(EngineState.parse(Fixtures.SCENE), EngineState.parse(Fixtures.SCENE))
            T.ok(EngineState.parse(Fixtures.SCENE) != EngineState.parse(Fixtures.EDIT))
        }
        T.test("state: help content is present") {
            T.ok(HelpContent.sections.size >= 5)
            T.ok(HelpContent.sections.all { it.title.isNotBlank() && it.lines.isNotEmpty() })
        }
    }
}
