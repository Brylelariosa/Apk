package com.rustforge.studio.core

import com.rustforge.studio.testing.T
import kotlin.math.abs
import kotlin.math.hypot

object IconTests {
    private fun cubicPoint(a: Seg.Cubic, x0: Float, y0: Float, t: Float): Pair<Float, Float> {
        val u = 1 - t
        val x = u * u * u * x0 + 3 * u * u * t * a.x1 + 3 * u * t * t * a.x2 + t * t * t * a.x
        val y = u * u * u * y0 + 3 * u * u * t * a.y1 + 3 * u * t * t * a.y2 + t * t * t * a.y
        return x to y
    }

    fun run() {
        T.test("path: commands, relative coordinates and implicit repeats") {
            val s = PathData.parse("M1 2L3 4 5 6h2v-1z")
            T.eq(listOf(Seg.Move(1f, 2f), Seg.Line(3f, 4f), Seg.Line(5f, 6f), Seg.Line(7f, 6f), Seg.Line(7f, 5f), Seg.Close), s)
            val rel = PathData.parse("m1 1 2 0 0 2z m1 1h1")
            T.eq(Seg.Move(1f, 1f), rel[0])
            T.eq(Seg.Line(3f, 1f), rel[1])
            T.eq(Seg.Line(3f, 3f), rel[2])
            T.eq(Seg.Move(2f, 2f), rel[4], "relative move after close starts at the subpath origin")
            T.eq(Seg.Line(3f, 2f), rel[5])
        }
        T.test("path: compact numbers and dots") {
            val s = PathData.parse("M.5.5L-1-2 1.5.25M12 8h.01")
            T.eq(Seg.Move(0.5f, 0.5f), s[0])
            T.eq(Seg.Line(-1f, -2f), s[1])
            T.eq(Seg.Line(1.5f, 0.25f), s[2])
            T.eq(Seg.Line(12.01f, 8f), s[4])
        }
        T.test("path: quadratic curves become cubics") {
            val s = PathData.parse("M0 0Q3 3 6 0")
            val c = s[1] as Seg.Cubic
            T.near(2.0, c.x1.toDouble(), 1e-5)
            T.near(2.0, c.y1.toDouble(), 1e-5)
            T.near(4.0, c.x2.toDouble(), 1e-5)
            T.near(6.0, c.x.toDouble(), 1e-5)
        }
        T.test("path: smooth curves reflect the previous control point") {
            val s = PathData.parse("M0 0C0 4 4 4 4 0S8-4 8 0")
            val second = s[2] as Seg.Cubic
            T.near(4.0, second.x1.toDouble(), 1e-5)
            T.near(-4.0, second.y1.toDouble(), 1e-5)
        }
        T.test("path: arcs approximate circles") {
            val s = PathData.parse("M1 0A1 1 0 0 1 0 1")
            val c = s[1] as Seg.Cubic
            val (mx, my) = cubicPoint(c, 1f, 0f, 0.5f)
            T.near(Math.sqrt(0.5), mx.toDouble(), 2e-3)
            T.near(Math.sqrt(0.5), my.toDouble(), 2e-3)
            val full = PathData.parse("M0 0a5 5 0 1 0 10 0a5 5 0 1 0-10 0z")
            var px = 0f
            var py = 0f
            for (seg in full) {
                when (seg) {
                    is Seg.Move -> { px = seg.x; py = seg.y }
                    is Seg.Cubic -> {
                        for (k in 1..4) {
                            val (x, y) = cubicPoint(seg, px, py, k / 4f)
                            T.near(5.0, hypot((x - 5f).toDouble(), y.toDouble()), 0.02, "point on circle of radius 5")
                        }
                        px = seg.x; py = seg.y
                    }
                    else -> {}
                }
            }
            val big = PathData.parse("M0 0a1 1 0 0 1 10 0")
            val (bx, by) = cubicPoint(big.filterIsInstance<Seg.Cubic>().let { it[it.size / 2] }, 5f, 0f, 0f)
            T.ok(abs(bx) < 20f && abs(by) < 20f, "radii too small for the chord are scaled up")
        }
        T.test("path: compact arc flags and errors") {
            val ok = PathData.parse("M0 0a2 2 0 0110 0")
            T.ok(ok.size >= 2)
            T.throws<PathParseException> { PathData.parse("M0 0 L x") }
            T.throws<PathParseException> { PathData.parse("5 5") }
            T.throws<PathParseException> { PathData.parse("M0 0 K 1 1") }
            T.throws<PathParseException> { PathData.parse("M0 0a1 1 0 2 0 1 1") }
        }
        T.test("icons: every icon parses and stays on the 24x24 canvas") {
            T.ok(IconSet.names.size >= 70, "icon count ${IconSet.names.size}")
            for (name in IconSet.names) {
                val shapes = IconSet.get(name)
                T.ok(shapes.isNotEmpty(), name)
                for (sh in shapes) {
                    T.ok(sh.segs.isNotEmpty() && sh.segs[0] is Seg.Move, "$name starts with a moveto")
                    for (seg in sh.segs) {
                        val pts = when (seg) {
                            is Seg.Move -> listOf(seg.x to seg.y)
                            is Seg.Line -> listOf(seg.x to seg.y)
                            is Seg.Cubic -> listOf(seg.x to seg.y, seg.x1 to seg.y1, seg.x2 to seg.y2)
                            Seg.Close -> emptyList()
                        }
                        for ((x, y) in pts) T.ok(x >= -0.5f && x <= 24.5f && y >= -0.5f && y <= 24.5f, "$name has a point outside the canvas: $x,$y")
                    }
                }
            }
        }
        T.test("icons: lookup, filled shapes and the placeholder") {
            T.ok(IconSet.has("undo") && !IconSet.has("nope"))
            T.ok(IconSet.get("more").all { it.fill })
            T.ok(IconSet.get("undo").none { it.fill })
            T.ok(IconSet.get("solid").any { it.fill } && IconSet.get("solid").any { !it.fill })
            T.eq(2, IconSet.get("no-such-icon").size)
        }
        T.test("icons: every icon the UI refers to exists") {
            val needed = listOf(
                "undo", "redo", "menu", "more", "settings", "add", "close", "check", "warning", "error", "info", "help", "chevron-down", "chevron-up",
                "chevron-left", "chevron-right", "code", "pencil", "duplicate", "delete", "new", "folder", "save", "import", "export", "navigate", "select",
                "box-select", "move", "rotate", "scale", "extrude", "inset", "loop-cut", "subdivide", "merge", "mirror", "join", "separate", "dissolve",
                "flip-normals", "shade-smooth", "shade-flat", "fill", "smooth", "invert", "cube", "sphere", "cylinder", "cone", "torus", "plane", "circle",
                "grid", "light", "camera", "empty", "object-mode", "edit-mode", "vertex-select", "edge-select", "face-select", "select-all", "eye",
                "eye-off", "lock", "unlock", "axes", "wire", "solid", "material", "xray", "perspective", "ortho", "home", "focus", "hierarchy", "sliders", "wrench",
            )
            for (n in needed) T.ok(IconSet.has(n), "missing icon $n")
        }
    }
}
