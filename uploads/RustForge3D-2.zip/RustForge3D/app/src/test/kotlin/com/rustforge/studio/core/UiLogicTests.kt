package com.rustforge.studio.core

import com.rustforge.studio.testing.T

object UiLogicTests {
    fun run() {
        T.test("hud: view labels") {
            T.eq("User Perspective", HudText.viewLabel(CameraState()))
            T.eq("Front Orthographic", HudText.viewLabel(CameraState(projection = "ortho", view = "front")))
            T.eq("Top Perspective", HudText.viewLabel(CameraState(view = "top")))
        }
        T.test("hud: selection summary") {
            T.eq("Cube", HudText.selectionSummary(EngineState.parse(Fixtures.OBJECT)))
            T.eq("Faces 32 / 32", HudText.selectionSummary(EngineState.parse(Fixtures.EDIT)))
            T.eq("Nothing selected", HudText.selectionSummary(EngineState()))
            val two = EngineState(scene = SceneState(selectedCount = 2))
            T.eq("2 objects selected", HudText.selectionSummary(two))
        }
        T.test("hud: tool read-out") {
            T.eq(null, HudText.toolLine(null))
            T.eq("Extrude: 0.5 m  -  Drag along the normal", HudText.toolLine(ToolState("extrude", "Extrude", 0.5, "m", "Drag along the normal")))
            T.eq("Loop Cut: 0", HudText.toolLine(ToolState("loop_cut", "Loop Cut", 0.0, "", "")))
            T.eq("Move: 1.235 m", HudText.toolLine(ToolState("move", "Move", 1.23456, "m", "")))
        }
        T.test("hud: statistics lines") {
            val lines = HudText.statsLines(StatsInfo(objects = 3, verts = 1234567, faces = 10, tris = 20, gpuMb = 12.4f, fps = 59.6f, quality = "auto", backend = "vulkan"))
            T.eq("Objects 3", lines[0])
            T.eq("Vertices 1,234,567", lines[1])
            T.ok("60 FPS" in lines, lines.toString())
            T.ok("GPU 12 MB" in lines, lines.toString())
            T.ok("Backend vulkan" in lines)
            T.ok(HudText.statsLines(StatsInfo()).none { it.startsWith("Backend") }, "no backend line while unknown")
        }
        T.test("tools: rail contents per mode") {
            val obj = Tools.forMode("object").map { it.id }
            T.eq(listOf("navigate", "select", "box_select", "move", "rotate", "scale"), obj)
            val edit = Tools.forMode("edit").map { it.id }
            T.eq(listOf("navigate", "select", "box_select", "move", "rotate", "scale", "extrude", "inset", "loop_cut"), edit)
            for (t in Tools.forMode("edit")) T.ok(IconSet.has(t.icon), "icon ${t.icon}")
        }
        T.test("numeric transform: expressions, units and defaults") {
            T.eq(listOf("1", "1", "1"), NumericTransform.defaults("scale"))
            T.eq(listOf("0", "0", "0"), NumericTransform.defaults("move"))
            val r = NumericTransform.build("move", listOf("1+1", "50cm", "0"), "global", true)
            T.ok(r.error == null, r.error ?: "")
            val a = r.args!!
            T.eq("move", a["mode"].str())
            T.near(2.0, a["values"][0].double())
            T.near(0.5, a["values"][1].double(), 1e-9)
            T.ok(a["relative"].bool())
            val rot = NumericTransform.build("rotate", listOf("90deg", "0", "0"), "local", false)
            T.near(90.0, rot.args!!["values"][0].double(), 1e-9)
            T.ok(rot.args!!["relative"].bool(), "rotate is always relative")
            val abs = NumericTransform.build("move", listOf("1", "2", "3"), "global", false)
            T.ok(!abs.args!!["relative"].bool())
        }
        T.test("numeric transform: errors name the axis") {
            val r = NumericTransform.build("move", listOf("1", "abc", "0"), "global", true)
            T.ok(r.args == null)
            T.ok(r.error!!.startsWith("Y:"), r.error ?: "")
            T.ok(NumericTransform.build("move", listOf("1"), "global", true).error != null)
        }
        T.test("settings: slider snapping stays on the step grid and in range") {
            val sl = SettingControl.Slider(0.2f, 4f, 0.1f)
            T.near(1.2, sl.snap(1.23f).toDouble(), 1e-4)
            T.near(0.2, sl.snap(-3f).toDouble(), 1e-4)
            T.near(4.0, sl.snap(99f).toDouble(), 1e-4)
            T.ok(SettingsSpecs.all.none { (it.control as? SettingControl.Slider)?.let { s -> s.step <= 0f || s.min >= s.max } == true }, "every slider has a sane range")
        }
        T.test("layout rules: phone, foldable and tablet windows") {
            val phone = LayoutRules.of(360, 800)
            T.ok(!phone.landscape && !phone.railVertical && !phone.dock && !phone.showTitle && !phone.wideWorkspaceSwitch)
            val phoneLandscape = LayoutRules.of(800, 360)
            T.ok(phoneLandscape.landscape && phoneLandscape.railVertical && !phoneLandscape.dock)
            val tabletPortrait = LayoutRules.of(800, 1280)
            T.ok(tabletPortrait.railVertical && !tabletPortrait.dock && tabletPortrait.showTitle && tabletPortrait.wideWorkspaceSwitch)
            val tabletLandscape = LayoutRules.of(1280, 800)
            T.ok(tabletLandscape.dock && tabletLandscape.railVertical)
        }
    }
}
