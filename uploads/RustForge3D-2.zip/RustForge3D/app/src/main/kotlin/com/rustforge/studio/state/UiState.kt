package com.rustforge.studio.state

enum class Workspace { MODELING, CODE }

/** Tabs of the scene / properties panel. */
enum class PanelTab(val label: String, val icon: String) {
    SCENE("Scene", "hierarchy"),
    OBJECT("Object", "cube"),
    MODIFIERS("Modifiers", "wrench"),
    MATERIAL("Material", "material"),
    INFO("Info", "info"),
}

sealed interface AppDialog {
    object Settings : AppDialog
    object Help : AppDialog
    object NumericTransform : AppDialog
    object ConfirmNew : AppDialog
    data class Rename(val id: Int, val name: String) : AppDialog
}

/** A transient message shown over the viewport. [level] is "info", "warn" or "error". */
data class UiMessage(val id: Long, val level: String, val text: String)

/** App-level UI state that is not part of the engine snapshot. Lives in the ViewModel so rotation loses nothing. */
data class UiState(
    val workspace: Workspace = Workspace.MODELING,
    val panelOpen: Boolean = false,
    val panelTab: PanelTab = PanelTab.SCENE,
    val dialog: AppDialog? = null,
    val redoPanelOpen: Boolean = true,
    val multiSelect: Boolean = false,
    val documentName: String? = null,
    val restoreSession: Boolean = true,
)
