package com.rustforge.studio.ui.icons

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.IconSet
import com.rustforge.studio.core.Seg

private class DrawablePath(val path: Path, val fill: Boolean)

private val iconStroke = Stroke(width = 2f, cap = StrokeCap.Round, join = StrokeJoin.Round)

private fun buildPaths(name: String): List<DrawablePath> = IconSet.get(name).map { shape ->
    val p = Path()
    for (seg in shape.segs) {
        when (seg) {
            is Seg.Move -> p.moveTo(seg.x, seg.y)
            is Seg.Line -> p.lineTo(seg.x, seg.y)
            is Seg.Cubic -> p.cubicTo(seg.x1, seg.y1, seg.x2, seg.y2, seg.x, seg.y)
            Seg.Close -> p.close()
        }
    }
    DrawablePath(p, shape.fill)
}

/** Draws a named icon of [IconSet] on a 24-unit grid scaled to [size]. */
@Composable
fun AppIcon(name: String, modifier: Modifier = Modifier, tint: Color = LocalContentColor.current, size: Dp = 22.dp) {
    val paths = remember(name) { buildPaths(name) }
    Canvas(modifier.size(size)) {
        val k = this.size.minDimension / 24f
        scale(k, k, pivot = Offset.Zero) {
            for (item in paths) {
                if (item.fill) drawPath(item.path, tint, style = Fill) else drawPath(item.path, tint, style = iconStroke)
            }
        }
    }
}
