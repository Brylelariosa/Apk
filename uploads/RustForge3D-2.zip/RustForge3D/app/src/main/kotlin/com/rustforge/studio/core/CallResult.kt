package com.rustforge.studio.core

/** Reply of an engine command (docs/PROTOCOL.md section 4): `ok`, an error text when it failed, and the whole reply object. */
data class CallResult(val ok: Boolean, val error: String, val json: Json) {
    companion object {
        fun parse(text: String?): CallResult {
            val j = Json.parseOrNull(text) as? Json.Obj ?: return CallResult(false, "The engine returned an unreadable reply", Json.Null)
            val ok = j["ok"].bool(false)
            return CallResult(ok, if (ok) "" else j["error"].str("The command failed"), j)
        }

        fun failure(message: String) = CallResult(false, message, Json.Null)
    }
}

/** Built-in command argument builders shared by the UI (kept in one place so ids and parameter names are not scattered). */
object Cmd {
    /** Arguments of `op.run`. */
    fun op(id: String, vararg params: Pair<String, Any?>): Json.Obj = jsonOf("id" to id, "params" to jsonOf(*params))

    /** Operator id of "add primitive" menu entries, in menu order, with their labels and icon names. */
    val primitives: List<Triple<String, String, String>> = listOf(
        Triple("mesh.primitive_cube_add", "Cube", "cube"),
        Triple("mesh.primitive_uv_sphere_add", "UV Sphere", "sphere"),
        Triple("mesh.primitive_ico_sphere_add", "Ico Sphere", "sphere"),
        Triple("mesh.primitive_cylinder_add", "Cylinder", "cylinder"),
        Triple("mesh.primitive_cone_add", "Cone", "cone"),
        Triple("mesh.primitive_torus_add", "Torus", "torus"),
        Triple("mesh.primitive_plane_add", "Plane", "plane"),
        Triple("mesh.primitive_circle_add", "Circle", "circle"),
        Triple("mesh.primitive_grid_add", "Grid", "grid"),
    )

    val lights: List<Pair<String, String>> = listOf("POINT" to "Point Light", "SUN" to "Sun Light", "SPOT" to "Spot Light")

    /** The `mesh.delete` type matching the element mode ("vertex" | "edge" | "face"). */
    fun deleteType(selectMode: String): String = when (selectMode) {
        "edge" -> "EDGE"
        "face" -> "FACE"
        else -> "VERT"
    }
}

/** One entry of the object / mesh operator menus. */
data class MenuOp(val label: String, val icon: String, val id: String, val params: List<Pair<String, Any?>> = emptyList())

/** Operators offered in the bottom bar menus (all exist in the engine's registry; see forge-ops). */
object OperatorMenus {
    val object_: List<MenuOp> = listOf(
        MenuOp("Duplicate", "duplicate", "object.duplicate_move"),
        MenuOp("Delete", "delete", "object.delete"),
        MenuOp("Join", "join", "object.join"),
        MenuOp("Shade Smooth", "shade-smooth", "object.shade_smooth"),
        MenuOp("Shade Flat", "shade-flat", "object.shade_flat"),
        MenuOp("Origin to Geometry", "focus", "object.origin_set"),
        MenuOp("Apply Transforms", "check", "object.transform_apply"),
        MenuOp("Hide", "eye-off", "object.hide_view_set"),
        MenuOp("Reveal Hidden", "eye", "object.hide_view_clear"),
    )

    /** Edit-mode operators; the delete type depends on the element mode and is filled in by [meshOps]. */
    fun meshOps(selectMode: String): List<MenuOp> = listOf(
        MenuOp("Subdivide", "subdivide", "mesh.subdivide"),
        MenuOp("Delete", "delete", "mesh.delete", listOf("type" to Cmd.deleteType(selectMode))),
        MenuOp("Merge at Center", "merge", "mesh.merge", listOf("type" to "CENTER")),
        MenuOp("Merge by Distance", "merge", "mesh.remove_doubles"),
        MenuOp("Dissolve Vertices", "dissolve", "mesh.dissolve_verts"),
        MenuOp("Dissolve Edges", "dissolve", "mesh.dissolve_edges"),
        MenuOp("Dissolve Faces", "dissolve", "mesh.dissolve_faces"),
        MenuOp("Flip Normals", "flip-normals", "mesh.flip_normals"),
        MenuOp("Recalculate Normals", "flip-normals", "mesh.normals_make_consistent"),
        MenuOp("Shade Smooth", "shade-smooth", "mesh.faces_shade_smooth"),
        MenuOp("Shade Flat", "shade-flat", "mesh.faces_shade_flat"),
        MenuOp("Triangulate", "fill", "mesh.quads_convert_to_tris"),
        MenuOp("Fill", "fill", "mesh.fill"),
        MenuOp("Smooth Vertices", "smooth", "mesh.vertices_smooth"),
        MenuOp("Symmetrize", "mirror", "mesh.symmetrize"),
        MenuOp("Duplicate", "duplicate", "mesh.duplicate_move"),
        MenuOp("Separate", "separate", "mesh.separate"),
    )
}
