package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.NumericTransform
import com.rustforge.studio.state.AppDialog
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.ui.common.DialogFrame
import com.rustforge.studio.ui.common.EntryField
import com.rustforge.studio.ui.common.LabelButton
import com.rustforge.studio.ui.common.Segmented
import com.rustforge.studio.ui.common.ToggleRow
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.theme.Palette

/** Type exact values to move, rotate or scale the selection. Fields accept expressions and units (50cm, 90deg, 2*3). */
@Composable
fun NumericTransformDialog(vm: AppViewModel) {
    var mode by remember { mutableStateOf("move") }
    var space by remember { mutableStateOf("global") }
    var relative by remember { mutableStateOf(true) }
    var texts by remember { mutableStateOf(NumericTransform.defaults("move")) }
    var error by remember { mutableStateOf<String?>(null) }
    val axes = listOf("X", "Y", "Z")

    fun setText(index: Int, value: String) {
        texts = texts.mapIndexed { i, old -> if (i == index) value else old }
    }

    DialogFrame(
        title = "Numeric transform",
        onClose = { vm.closeDialog() },
        actions = {
            LabelButton("Cancel", { vm.closeDialog() })
            LabelButton(
                "Apply",
                {
                    val result = NumericTransform.build(mode, texts, space, relative)
                    val args = result.args
                    if (args == null) {
                        error = result.error
                    } else {
                        vm.callJson("transform.numeric", args)
                        vm.closeDialog()
                    }
                },
                primary = true,
            )
        },
    ) {
        Segmented(
            NumericTransform.modes,
            mode,
            {
                mode = it
                texts = NumericTransform.defaults(it)
                error = null
            },
            Modifier.padding(vertical = 8.dp),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0 until 3) {
                EntryField(
                    text = texts[i],
                    onCommit = {
                        setText(i, it)
                        true
                    },
                    modifier = Modifier.weight(1f),
                    suffix = axes[i],
                    onEdit = { setText(i, it) },
                )
            }
        }
        Segmented(NumericTransform.spaces, space, { space = it }, Modifier.padding(top = 12.dp))
        if (NumericTransform.supportsAbsolute(mode)) {
            ToggleRow("Relative (offset from current position)", relative, { relative = it })
        }
        val message = error
        if (message != null) Txt(message, Modifier.padding(top = 8.dp), color = Palette.danger, maxLines = 3)
        Txt(
            "Examples: 2*1.5+0.25, 50cm, 90deg. Rotation is in degrees, scale values are factors.",
            Modifier.padding(top = 8.dp),
            color = Palette.muted,
            maxLines = 3,
        )
    }
}

@Composable
fun RenameDialog(dialog: AppDialog.Rename, vm: AppViewModel) {
    var name by remember(dialog.id) { mutableStateOf(dialog.name) }

    fun submit() {
        if (name.isBlank()) return
        vm.call("object.rename", "id" to dialog.id, "name" to name.trim())
        vm.closeDialog()
    }

    DialogFrame(
        title = "Rename object",
        onClose = { vm.closeDialog() },
        actions = {
            LabelButton("Cancel", { vm.closeDialog() })
            LabelButton("Rename", { submit() }, primary = true, enabled = name.isNotBlank())
        },
    ) {
        EntryField(
            text = name,
            onCommit = {
                name = it
                true
            },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            numeric = false,
            onEdit = { name = it },
        )
    }
}
