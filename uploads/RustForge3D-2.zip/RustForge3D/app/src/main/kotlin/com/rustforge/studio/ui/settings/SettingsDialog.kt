package com.rustforge.studio.ui.settings

import android.content.Context
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.ParamFormat
import com.rustforge.studio.core.SettingControl
import com.rustforge.studio.core.SettingSpec
import com.rustforge.studio.core.SettingsSpecs
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.state.UiState
import com.rustforge.studio.ui.common.DialogFrame
import com.rustforge.studio.ui.common.DropdownField
import com.rustforge.studio.ui.common.LiveSlider
import com.rustforge.studio.ui.common.SectionTitle
import com.rustforge.studio.ui.common.ToggleRow
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.theme.Palette

/** Touch, gesture, gizmo, snapping, selection and viewport settings, generated from [SettingsSpecs]. */
@Composable
fun SettingsDialog(state: EngineState, ui: UiState, vm: AppViewModel) {
    val context = LocalContext.current
    val version = remember { appVersion(context) }
    DialogFrame(title = "Settings", onClose = { vm.closeDialog() }) {
        for (group in SettingsSpecs.groups) {
            SectionTitle(group.title)
            for (item in group.items) SettingRow(item, state, vm)
        }
        SectionTitle("Session")
        ToggleRow(
            "Restore the last session on start",
            ui.restoreSession,
            { vm.setRestoreSession(it) },
            help = "The scene is saved automatically when the app goes to the background.",
        )
        SectionTitle("About")
        Txt("RustForge 3D $version".trim())
        val backend = vm.backendName()
        Txt(if (backend.isEmpty()) "Renderer: starting" else "Renderer: $backend", color = Palette.muted)
    }
}

@Composable
private fun SettingRow(spec: SettingSpec, state: EngineState, vm: AppViewModel) {
    val settings = state.settings
    when (val control = spec.control) {
        SettingControl.Toggle -> ToggleRow(spec.label, settings.b(spec.path), { vm.setSetting(spec.path, it) }, help = spec.help)
        is SettingControl.Slider -> Column(Modifier.fillMaxWidth()) {
            LiveSlider(
                label = spec.label,
                value = settings.f(spec.path).toFloat(),
                range = control.min..control.max,
                onChange = { vm.setSetting(spec.path, it.toDouble()) },
                valueText = { ParamFormat.plain(it.toDouble(), 2) },
                snap = { control.snap(it) },
            )
            if (spec.help.isNotEmpty()) Txt(spec.help, color = Palette.muted, size = 11.sp, maxLines = 2)
        }
        is SettingControl.Choice -> Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Txt(spec.label)
            if (spec.help.isNotEmpty()) Txt(spec.help, color = Palette.muted, size = 11.sp, maxLines = 3)
            DropdownField(control.options, settings.s(spec.path), { vm.setSetting(spec.path, it) }, Modifier.padding(top = 4.dp))
        }
    }
}

private fun appVersion(context: Context): String = try {
    context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
} catch (e: Exception) {
    ""
}
