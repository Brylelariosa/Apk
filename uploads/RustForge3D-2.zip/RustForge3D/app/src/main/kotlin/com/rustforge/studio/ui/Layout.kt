package com.rustforge.studio.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalConfiguration
import com.rustforge.studio.core.LayoutRules
import com.rustforge.studio.core.LayoutSpec

/** The arrangement for the current window size; recomputed on rotation and window resizes. */
@Composable
fun rememberLayoutSpec(): LayoutSpec {
    val config = LocalConfiguration.current
    return remember(config.screenWidthDp, config.screenHeightDp) { LayoutRules.of(config.screenWidthDp, config.screenHeightDp) }
}
