package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.theme.Palette

/** Grey hint text for panels that have nothing to show. */
@Composable
fun EmptyNote(text: String, modifier: Modifier = Modifier) {
    Txt(text, modifier.fillMaxWidth().padding(16.dp), color = Palette.muted, maxLines = 4)
}

/** Name on the left, value on the right (read-only information). */
@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Txt(label, Modifier.weight(1f), color = Palette.muted)
        Txt(value, size = 13.sp)
    }
}

/** Column with the standard horizontal padding of panel content. */
@Composable
fun PanelColumn(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        content()
    }
}
