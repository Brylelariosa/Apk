package com.rustforge.studio.bridge

import android.view.Surface
import com.rustforge.studio.core.CallResult
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.Json
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadFactory

/** Outcome of starting the native engine. */
sealed interface EngineStart {
    class Started(val client: EngineClient) : EngineStart
    class Failed(val message: String) : EngineStart
}

/**
 * Owns one native engine handle. Commands run in order on a single background thread (a heavy operator may take
 * 100+ ms and must never block the UI); a poll loop publishes the latest state snapshot as a [StateFlow].
 */
class EngineClient private constructor(private val handle: Long) {
    private val callExecutor = Executors.newSingleThreadExecutor(namedThread("rf-engine-calls"))
    private val pollExecutor = Executors.newSingleThreadExecutor(namedThread("rf-engine-poll"))
    private val callDispatcher = callExecutor.asCoroutineDispatcher()
    private val pollDispatcher = pollExecutor.asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val mutableState = MutableStateFlow(EngineState())

    /** Latest snapshot; equal snapshots are conflated, so collectors only see real changes. */
    val state: StateFlow<EngineState> = mutableState.asStateFlow()

    private val mutableErrors = MutableSharedFlow<String>(extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    /** Human readable failures of fire-and-forget commands ("Nothing to undo", ...). */
    val errors: SharedFlow<String> = mutableErrors.asSharedFlow()

    private val mutableSurfaceError = MutableStateFlow<String?>(null)

    /** Why rendering is unavailable (no GPU adapter, surface failure), or null. */
    val surfaceError: StateFlow<String?> = mutableSurfaceError.asStateFlow()

    private val wake = Channel<Unit>(Channel.CONFLATED)

    @Volatile
    private var resumed = true

    @Volatile
    private var destroyed = false
    private var surfaceAttached = false

    init {
        scope.launch(pollDispatcher) {
            while (isActive) {
                if (resumed) pollOnce()
                withTimeoutOrNull(POLL_INTERVAL_MS) { wake.receive() }
            }
        }
    }

    private fun pollOnce() {
        val text = try {
            NativeBridge.nativePoll(handle)
        } catch (e: Throwable) {
            null
        } ?: return
        try {
            mutableState.value = EngineState.parse(text)
        } catch (e: Exception) {
            // A garbled snapshot is skipped; the previous good state stays visible.
        }
    }

    private fun callBlocking(method: String, args: Json): CallResult = try {
        CallResult.parse(NativeBridge.nativeCall(handle, method, args.toString()))
    } catch (e: Throwable) {
        CallResult.failure("Engine call failed: ${e.message ?: e.javaClass.simpleName}")
    }

    /** Runs a command and returns its reply (suspends; never blocks the caller's thread). */
    suspend fun call(method: String, args: Json = EMPTY): CallResult {
        if (destroyed) return CallResult.failure("The engine is not running")
        val result = withContext(callDispatcher) { callBlocking(method, args) }
        wake.trySend(Unit)
        return result
    }

    /** Fire-and-forget command; commands posted from one thread run in posting order. Failures go to [errors]. */
    fun post(method: String, args: Json = EMPTY, onDone: ((CallResult) -> Unit)? = null) {
        if (destroyed) return
        try {
            callExecutor.execute {
                val r = callBlocking(method, args)
                if (!r.ok) mutableErrors.tryEmit(r.error)
                wake.trySend(Unit)
                onDone?.invoke(r)
            }
        } catch (e: RejectedExecutionException) {
            // Shutting down.
        }
    }

    // ---- surface and touch (called on the UI thread, must be synchronous) ---------------------------------------------

    fun onSurface(surface: Surface, width: Int, height: Int) {
        if (destroyed) return
        try {
            if (!surfaceAttached) {
                surfaceAttached = NativeBridge.nativeSurfaceCreated(handle, surface, width, height)
                mutableSurfaceError.value = if (surfaceAttached) null else NativeBridge.nativeLastError(handle).ifBlank { "The 3D viewport could not be started." }
            } else {
                NativeBridge.nativeSurfaceChanged(handle, width, height)
            }
        } catch (e: Throwable) {
            mutableSurfaceError.value = "The 3D viewport failed: ${e.message ?: e.javaClass.simpleName}"
        }
        wake.trySend(Unit)
    }

    fun onSurfaceDestroyed() {
        if (destroyed || !surfaceAttached) return
        surfaceAttached = false
        try {
            NativeBridge.nativeSurfaceDestroyed(handle)
        } catch (e: Throwable) {
            // Nothing sensible left to do; the surface is gone either way.
        }
    }

    fun touch(action: Int, actionIndex: Int, timeMs: Long, count: Int, ids: IntArray, xs: FloatArray, ys: FloatArray, pressures: FloatArray, toolTypes: IntArray) {
        if (destroyed) return
        NativeBridge.nativeTouch(handle, action, actionIndex, timeMs, count, ids, xs, ys, pressures, toolTypes)
    }

    fun setResumed(value: Boolean) {
        resumed = value
        if (destroyed) return
        NativeBridge.nativeSetPaused(handle, !value)
        if (value) wake.trySend(Unit)
    }

    // ---- files --------------------------------------------------------------------------------------------------------

    suspend fun saveProject(): ByteArray? {
        if (destroyed) return null
        return withContext(callDispatcher) { NativeBridge.nativeSaveProject(handle) }
    }

    suspend fun loadProject(bytes: ByteArray): CallResult {
        if (destroyed) return CallResult.failure("The engine is not running")
        val r = withContext(callDispatcher) { CallResult.parse(NativeBridge.nativeLoadProject(handle, bytes)) }
        wake.trySend(Unit)
        return r
    }

    suspend fun importFile(fileName: String, bytes: ByteArray): CallResult {
        if (destroyed) return CallResult.failure("The engine is not running")
        val r = withContext(callDispatcher) { CallResult.parse(NativeBridge.nativeImport(handle, fileName, bytes)) }
        wake.trySend(Unit)
        return r
    }

    suspend fun export(format: String, optionsJson: String): ByteArray? {
        if (destroyed) return null
        return withContext(callDispatcher) { NativeBridge.nativeExport(handle, format, optionsJson) }
    }

    fun lastError(): String = if (destroyed) "" else NativeBridge.nativeLastError(handle)

    fun backendName(): String = if (destroyed) "" else NativeBridge.nativeBackendName(handle)

    fun destroy() {
        if (destroyed) return
        destroyed = true
        scope.cancel()
        callExecutor.shutdown()
        pollExecutor.shutdown()
        NativeBridge.nativeDestroy(handle)
    }

    companion object {
        private const val POLL_INTERVAL_MS = 100L
        private val EMPTY: Json = Json.Obj(emptyMap())

        private fun namedThread(name: String) = ThreadFactory { r -> Thread(r, name).apply { isDaemon = true } }

        /** Loads the native library and creates the engine; a failure is reported as text instead of crashing the app. */
        fun start(filesDir: File, density: Float): EngineStart = try {
            val h = NativeBridge.nativeCreate(filesDir.absolutePath, density)
            if (h == 0L) EngineStart.Failed("The native engine could not be created.") else EngineStart.Started(EngineClient(h))
        } catch (e: UnsatisfiedLinkError) {
            EngineStart.Failed("The native library (librustforge.so) could not be loaded: ${e.message}")
        } catch (e: Throwable) {
            EngineStart.Failed("The native engine failed to start: ${e.message ?: e.javaClass.simpleName}")
        }
    }
}
