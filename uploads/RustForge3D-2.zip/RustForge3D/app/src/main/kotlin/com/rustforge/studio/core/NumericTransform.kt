package com.rustforge.studio.core

/** Outcome of reading the numeric transform dialog: command arguments, or an error message for the user. */
class NumericTransformResult(val args: Json.Obj?, val error: String?)

/** Parsing and command building for the numeric transform dialog (`transform.numeric`, docs/PROTOCOL.md 4.4). */
object NumericTransform {
    val modes: List<Pair<String, String>> = listOf("move" to "Move", "rotate" to "Rotate", "scale" to "Scale")
    val spaces: List<Pair<String, String>> = listOf("global" to "Global", "local" to "Local")
    private val axes = listOf("X", "Y", "Z")

    fun defaults(mode: String): List<String> = if (mode == "scale") listOf("1", "1", "1") else listOf("0", "0", "0")

    fun unit(mode: String): ParamUnit = when (mode) {
        "move" -> ParamUnit.LENGTH
        "rotate" -> ParamUnit.ANGLE
        else -> ParamUnit.NONE
    }

    /** Only a move can be absolute ("set the position of the selection"); rotate and scale are always relative. */
    fun supportsAbsolute(mode: String): Boolean = mode == "move"

    fun build(mode: String, texts: List<String>, space: String, relative: Boolean): NumericTransformResult {
        if (texts.size != 3) return NumericTransformResult(null, "Three values are needed")
        val values = ArrayList<Double>(3)
        for (i in 0 until 3) {
            val r = NumericExpr.eval(texts[i], unit(mode))
            val v = r.value ?: return NumericTransformResult(null, "${axes[i]}: ${r.error ?: "not a number"}")
            values.add(v)
        }
        val args = jsonOf(
            "mode" to mode,
            "values" to values,
            "space" to space,
            "relative" to (relative || !supportsAbsolute(mode)),
        )
        return NumericTransformResult(args, null)
    }
}
