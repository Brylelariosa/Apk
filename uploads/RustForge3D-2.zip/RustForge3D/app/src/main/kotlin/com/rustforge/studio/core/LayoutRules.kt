package com.rustforge.studio.core

/** How the modeling screen is arranged for a window size (in dp). */
data class LayoutSpec(
    val landscape: Boolean,
    /** Tool rail as a column at the left edge (otherwise a row above the bottom bar). */
    val railVertical: Boolean,
    /** Properties as a permanent dock at the right edge (otherwise an overlay panel opened from the top bar). */
    val dock: Boolean,
    /** Room for the document name in the top bar. */
    val showTitle: Boolean,
    /** Room for the Modeling | Code switch with text (otherwise one icon button). */
    val wideWorkspaceSwitch: Boolean,
)

object LayoutRules {
    const val DOCK_WIDTH_DP = 340

    fun of(widthDp: Int, heightDp: Int): LayoutSpec {
        val landscape = widthDp > heightDp
        return LayoutSpec(
            landscape = landscape,
            railVertical = landscape || widthDp >= 600,
            dock = widthDp >= 840,
            showTitle = widthDp >= 520,
            wideWorkspaceSwitch = widthDp >= 700,
        )
    }
}
