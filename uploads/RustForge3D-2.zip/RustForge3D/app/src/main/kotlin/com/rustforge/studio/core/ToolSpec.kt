package com.rustforge.studio.core

data class ToolSpec(val id: String, val label: String, val icon: String)

/** The tools of the tool rail (ids: docs/PROTOCOL.md section 6). */
object Tools {
    private val navigation = listOf(
        ToolSpec("navigate", "Navigate", "navigate"),
        ToolSpec("select", "Select", "select"),
        ToolSpec("box_select", "Box Select", "box-select"),
    )
    private val transform = listOf(
        ToolSpec("move", "Move", "move"),
        ToolSpec("rotate", "Rotate", "rotate"),
        ToolSpec("scale", "Scale", "scale"),
    )
    private val editOnly = listOf(
        ToolSpec("extrude", "Extrude", "extrude"),
        ToolSpec("inset", "Inset", "inset"),
        ToolSpec("loop_cut", "Loop Cut", "loop-cut"),
    )

    fun forMode(mode: String): List<ToolSpec> = if (mode == "edit") navigation + transform + editOnly else navigation + transform
}
