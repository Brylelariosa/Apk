package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.HudText
import com.rustforge.studio.ui.common.SectionTitle
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.theme.Palette
import java.util.Locale

/** Scene statistics, mesh health, undo history and renderer information. */
@Composable
fun InfoTab(state: EngineState, modifier: Modifier = Modifier) {
    PanelColumn(modifier) {
        SectionTitle("Scene")
        InfoRow("Objects", state.stats.objects.toString())
        InfoRow("Vertices", HudText.grouped(state.stats.verts))
        InfoRow("Faces", HudText.grouped(state.stats.faces))
        InfoRow("Triangles", HudText.grouped(state.stats.tris))
        val mesh = state.active?.mesh
        if (mesh != null) {
            SectionTitle("Active mesh")
            InfoRow("Vertices", mesh.verts.toString())
            InfoRow("Edges", mesh.edges.toString())
            InfoRow("Faces", mesh.faces.toString())
            InfoRow("Triangles", mesh.tris.toString())
            InfoRow("Valid", if (mesh.valid) "Yes" else "No")
            for (issue in mesh.issues) Txt(issue, color = Palette.warning, maxLines = 3)
        }
        SectionTitle("History")
        InfoRow("Steps", state.undo.depth.toString())
        InfoRow("Undo", state.undo.undoLabel.ifEmpty { "-" })
        InfoRow("Redo", state.undo.redoLabel.ifEmpty { "-" })
        SectionTitle("Renderer")
        InfoRow("Backend", state.stats.backend.ifEmpty { "-" })
        InfoRow("Quality", state.stats.quality)
        if (state.view.stats) {
            InfoRow("Frame rate", String.format(Locale.ROOT, "%.0f FPS", state.stats.fps))
            InfoRow("GPU memory", String.format(Locale.ROOT, "%.0f MB", state.stats.gpuMb))
        } else {
            Txt("Turn on Statistics in the View menu for frame rate and GPU memory.", Modifier.padding(top = 8.dp), color = Palette.muted, maxLines = 3)
        }
    }
}
