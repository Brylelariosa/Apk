package com.rustforge.studio.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.core.Capabilities
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.LayoutSpec
import com.rustforge.studio.state.AppDialog
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.state.UiState
import com.rustforge.studio.state.Workspace
import com.rustforge.studio.ui.common.MenuButton
import com.rustforge.studio.ui.common.MenuEntry
import com.rustforge.studio.ui.common.Rule
import com.rustforge.studio.ui.common.Segmented
import com.rustforge.studio.ui.common.ToolButton
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.theme.Palette

/** File actions that need the system file picker (launched from the activity-result launchers in [AppRoot]). */
class ProjectActions(val open: () -> Unit, val save: () -> Unit, val saveAs: () -> Unit)

@Composable
fun TopBar(state: EngineState, ui: UiState, vm: AppViewModel, layout: LayoutSpec, actions: ProjectActions, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().height(56.dp).background(Palette.panel).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ProjectMenu(vm, actions)
        if (layout.showTitle) {
            Txt(ui.documentName ?: "Untitled", Modifier.weight(1f).padding(horizontal = 8.dp), size = 15.sp, weight = FontWeight.Medium)
        } else {
            Spacer(Modifier.weight(1f))
        }
        val undoLabel = state.undo.undoLabel
        val redoLabel = state.undo.redoLabel
        ToolButton("undo", if (undoLabel.isEmpty()) "Undo" else "Undo $undoLabel", { vm.undo() }, enabled = state.undo.canUndo)
        ToolButton("redo", if (redoLabel.isEmpty()) "Redo" else "Redo $redoLabel", { vm.redo() }, enabled = state.undo.canRedo)
        if (ui.workspace == Workspace.MODELING) {
            ViewMenu(state, vm)
            if (!layout.dock) ToolButton("sliders", "Properties", { vm.togglePanel(ui.panelTab) }, selected = ui.panelOpen)
        }
        WorkspaceSwitch(ui.workspace, layout.wideWorkspaceSwitch) { vm.setWorkspace(it) }
    }
}

@Composable
private fun ProjectMenu(vm: AppViewModel, actions: ProjectActions) {
    MenuButton(
        button = { open -> ToolButton("menu", "Menu", open) },
        menu = { close ->
            MenuEntry("New project", { close(); vm.showDialog(AppDialog.ConfirmNew) }, icon = "new")
            MenuEntry("Open...", { close(); actions.open() }, icon = "folder")
            MenuEntry("Save", { close(); actions.save() }, icon = "save")
            MenuEntry("Save as...", { close(); actions.saveAs() }, icon = "save")
            Rule()
            MenuEntry("Import mesh (not in this build)", { close() }, icon = "import", enabled = Capabilities.MESH_IMPORT)
            MenuEntry("Export mesh (not in this build)", { close() }, icon = "export", enabled = Capabilities.MESH_EXPORT)
            Rule()
            MenuEntry("Settings", { close(); vm.showDialog(AppDialog.Settings) }, icon = "settings")
            MenuEntry("Help", { close(); vm.showDialog(AppDialog.Help) }, icon = "help")
        },
    )
}

private val viewPresets = listOf("front" to "Front", "back" to "Back", "left" to "Left", "right" to "Right", "top" to "Top", "bottom" to "Bottom")
private val shadingModes = listOf(Triple("solid", "Solid", "solid"), Triple("wire", "Wireframe", "wire"), Triple("material", "Material preview", "material"))

@Composable
private fun ViewMenu(state: EngineState, vm: AppViewModel) {
    val ortho = state.camera.projection == "ortho"
    MenuButton(
        button = { open -> ToolButton("eye", "View", open) },
        menu = { close ->
            for ((id, label) in viewPresets) {
                MenuEntry(label, { close(); vm.viewPreset(id) }, checked = state.camera.view == id)
            }
            MenuEntry("Reset view", { close(); vm.viewPreset("reset") }, icon = "home")
            MenuEntry(if (ortho) "Perspective" else "Orthographic", { close(); vm.toggleProjection() }, icon = if (ortho) "perspective" else "ortho")
            MenuEntry("Focus selection", { close(); vm.focus("selection") }, icon = "focus")
            MenuEntry("Frame all", { close(); vm.focus("all") }, icon = "focus")
            Rule()
            for ((id, label, icon) in shadingModes) {
                MenuEntry(label, { close(); vm.viewSet("shading", id) }, icon = icon, checked = state.view.shading == id)
            }
            Rule()
            MenuEntry("Grid", { close(); vm.viewSet("grid", !state.view.grid) }, icon = "grid", checked = state.view.grid)
            MenuEntry("Axes", { close(); vm.viewSet("axes", !state.view.axes) }, icon = "axes", checked = state.view.axes)
            MenuEntry("Wire overlay", { close(); vm.viewSet("wire_overlay", !state.view.wireOverlay) }, icon = "wire", checked = state.view.wireOverlay)
            MenuEntry("X-ray", { close(); vm.viewSet("xray", !state.view.xray) }, icon = "xray", checked = state.view.xray)
            MenuEntry("Statistics", { close(); vm.viewSet("stats", !state.view.stats) }, icon = "info", checked = state.view.stats)
        },
    )
}

@Composable
private fun WorkspaceSwitch(current: Workspace, wide: Boolean, onSelect: (Workspace) -> Unit) {
    val code = current == Workspace.CODE
    if (wide) {
        Segmented(
            options = listOf("modeling" to "Modeling", "code" to "Code"),
            selected = if (code) "code" else "modeling",
            onSelect = { onSelect(if (it == "code") Workspace.CODE else Workspace.MODELING) },
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    } else {
        ToolButton(
            if (code) "cube" else "code",
            if (code) "Modeling workspace" else "Code workspace",
            { onSelect(if (code) Workspace.MODELING else Workspace.CODE) },
        )
    }
}
