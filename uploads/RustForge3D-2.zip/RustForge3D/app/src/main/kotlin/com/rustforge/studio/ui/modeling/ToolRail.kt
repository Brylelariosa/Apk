package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.ToolSpec
import com.rustforge.studio.ui.common.ToolButton
import com.rustforge.studio.ui.theme.Palette

/** The tool buttons, as a column at the left edge or a row at the bottom depending on [vertical]. */
@Composable
fun ToolRail(tools: List<ToolSpec>, selected: String, onSelect: (String) -> Unit, vertical: Boolean, modifier: Modifier = Modifier) {
    if (vertical) {
        Column(
            modifier.fillMaxHeight().width(56.dp).background(Palette.panel).verticalScroll(rememberScrollState()).padding(vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            for (t in tools) ToolButton(t.icon, t.label, { onSelect(t.id) }, selected = t.id == selected)
        }
    } else {
        Box(modifier.fillMaxWidth().background(Palette.panel), contentAlignment = Alignment.Center) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                for (t in tools) ToolButton(t.icon, t.label, { onSelect(t.id) }, selected = t.id == selected, tipAbove = true)
            }
        }
    }
}
