package com.rustforge.studio.core

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** One drawn element of an icon: stroked outline, or a solid fill when [fill] is set. */
data class IconShape(val segs: List<Seg>, val fill: Boolean)

/**
 * The app's own icon set: 24x24 grid, round line caps and joins, a uniform 2-unit stroke (drawn by `AppIcon`).
 * Shapes are SVG path strings; a leading `*` marks a filled shape. No emoji, no external icon fonts.
 */
object IconSet {
    private val sources = LinkedHashMap<String, List<String>>()
    private val parsed = HashMap<String, List<IconShape>>()

    val names: List<String> get() = sources.keys.toList()

    /** Parsed shapes of an icon; an unknown name yields a placeholder outline so a typo is visible but not fatal. */
    @Synchronized
    fun get(name: String): List<IconShape> = parsed.getOrPut(name) {
        val shapes = sources[name] ?: listOf("M4 4h16v16H4z", "M4 4l16 16")
        shapes.map { s ->
            val fill = s.startsWith("*")
            IconShape(PathData.parse(if (fill) s.substring(1) else s), fill)
        }
    }

    fun has(name: String): Boolean = sources.containsKey(name)

    private fun n(v: Float): String = JsonWriter.formatNumber((Math.round(v * 100f) / 100f).toDouble())

    private fun circle(cx: Float, cy: Float, r: Float) = "M${n(cx - r)} ${n(cy)}a${n(r)} ${n(r)} 0 1 0 ${n(2 * r)} 0a${n(r)} ${n(r)} 0 1 0 ${n(-2 * r)} 0z"

    private fun dot(cx: Float, cy: Float, r: Float = 1.7f) = "*" + circle(cx, cy, r)

    private fun ellipse(cx: Float, cy: Float, rx: Float, ry: Float) =
        "M${n(cx - rx)} ${n(cy)}a${n(rx)} ${n(ry)} 0 1 0 ${n(2 * rx)} 0a${n(rx)} ${n(ry)} 0 1 0 ${n(-2 * rx)} 0z"

    private fun rect(x: Float, y: Float, w: Float, h: Float, r: Float = 0f): String {
        if (r <= 0f) return "M${n(x)} ${n(y)}h${n(w)}v${n(h)}h${n(-w)}z"
        val iw = w - 2 * r
        val ih = h - 2 * r
        return "M${n(x + r)} ${n(y)}h${n(iw)}a${n(r)} ${n(r)} 0 0 1 ${n(r)} ${n(r)}v${n(ih)}a${n(r)} ${n(r)} 0 0 1 ${n(-r)} ${n(r)}" +
            "h${n(-iw)}a${n(r)} ${n(r)} 0 0 1 ${n(-r)} ${n(-r)}v${n(-ih)}a${n(r)} ${n(r)} 0 0 1 ${n(r)} ${n(-r)}z"
    }

    /** Gear outline with [teeth] trapezoid teeth. */
    private fun gear(cx: Float, cy: Float, inner: Float, outer: Float, teeth: Int): String {
        val sb = StringBuilder()
        val step = 2 * PI / teeth
        var first = true
        for (k in 0 until teeth) {
            val a = k * step
            val pts = listOf(a - step * 0.30 to inner, a - step * 0.17 to outer, a + step * 0.17 to outer, a + step * 0.30 to inner)
            for ((ang, r) in pts) {
                val x = cx + (r * cos(ang)).toFloat()
                val y = cy + (r * sin(ang)).toFloat()
                sb.append(if (first) "M" else "L").append(n(x)).append(' ').append(n(y))
                first = false
            }
        }
        return sb.append('z').toString()
    }

    private fun ic(name: String, vararg shapes: String) {
        require(!sources.containsKey(name)) { "duplicate icon $name" }
        sources[name] = shapes.toList()
    }

    init {
        // history and general actions
        ic("undo", "M9 14L4 9l5-5", "M4 9h10.5a5.5 5.5 0 0 1 0 11H11")
        ic("redo", "M15 14l5-5-5-5", "M20 9H9.5a5.5 5.5 0 0 0 0 11H13")
        ic("menu", "M4 6h16", "M4 12h16", "M4 18h16")
        ic("more", dot(5f, 12f), dot(12f, 12f), dot(19f, 12f))
        ic("settings", gear(12f, 12f, 7.6f, 9.8f, 8), circle(12f, 12f, 3f))
        ic("add", "M12 5v14", "M5 12h14")
        ic("close", "M6 6l12 12", "M18 6L6 18")
        ic("check", "M5 12.5l4.5 4.5L19 7.5")
        ic("warning", "M12 3L2 20h20z", "M12 10v4", "M12 17h.01")
        ic("error", circle(12f, 12f, 9f), "M12 7v6", "M12 16.5h.01")
        ic("info", circle(12f, 12f, 9f), "M12 16v-4", "M12 8h.01")
        ic("help", circle(12f, 12f, 9f), "M9.5 9.2a2.6 2.6 0 0 1 5 1c0 1.7-2.5 2.2-2.5 3.8", "M12 17.5h.01")
        ic("chevron-down", "M6 9l6 6 6-6")
        ic("chevron-up", "M6 15l6-6 6 6")
        ic("chevron-left", "M15 6l-6 6 6 6")
        ic("chevron-right", "M9 6l6 6-6 6")
        ic("code", "M16 18l6-6-6-6", "M8 6l-6 6 6 6")
        ic("pencil", "M17 3l4 4L8 20H4v-4z", "M14 6l4 4")
        ic("duplicate", rect(9f, 9f, 12f, 12f, 2f), "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1")
        ic("delete", "M3 6h18", "M8 6V4h8v2", "M19 6l-1 14H6L5 6", "M10 11v6", "M14 11v6")

        // files
        ic("new", "M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z", "M14 3v5h5", "M12 12v6", "M9 15h6")
        ic("folder", "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z")
        ic("save", "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z", "M17 21v-8H7v8", "M7 3v5h8")
        ic("import", "M12 3v12", "M7 10l5 5 5-5", "M5 21h14")
        ic("export", "M12 15V3", "M7 8l5-5 5 5", "M5 21h14")

        // tools
        ic("navigate",
            "M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2", "M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2", "M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8",
            "M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15")
        ic("select", "M5 3l13.5 6.2-5.6 1.7-1.7 5.6z")
        ic("box-select", "M3 7V4h3", "M10 4h4", "M18 4h3v3", "M21 11v2", "M21 17v3h-3", "M14 20h-4", "M6 20H3v-3", "M3 13v-2")
        ic("move", "M5 9l-3 3 3 3", "M9 5l3-3 3 3", "M15 19l-3 3-3-3", "M19 9l3 3-3 3", "M2 12h20", "M12 2v20")
        ic("rotate", "M21 12a9 9 0 1 1-3-6.7L21 8", "M21 3v5h-5")
        ic("scale", rect(3f, 9f, 12f, 12f, 2f), "M14 10l7-7", "M16 3h5v5")
        ic("extrude", "M12 14V3", "M7.5 7.5L12 3l4.5 4.5", "M4 14h16v7H4z")
        ic("inset", rect(3f, 3f, 18f, 18f, 2f), rect(8f, 8f, 8f, 8f, 1f))
        ic("loop-cut", rect(5f, 3f, 14f, 18f, 2f), "M2 12h20")
        ic("subdivide", rect(3f, 3f, 18f, 18f, 2f), "M12 3v18", "M3 12h18")

        // mesh operators
        ic("merge", "M8 6l4-4 4 4", "M12 2v10.3a4 4 0 0 1-1.17 2.87L4 22", "M20 22l-5-5")
        ic("mirror", "M8 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3", "M16 3h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-3", "M12 20v2", "M12 14v2", "M12 8v2", "M12 2v2")
        ic("join", rect(2f, 7f, 8f, 10f, 1f), rect(14f, 7f, 8f, 10f, 1f), "M10 12h4")
        ic("separate", rect(2f, 7f, 8f, 10f, 1f), rect(14f, 7f, 8f, 10f, 1f), "M12 4v2", "M12 11v2", "M12 18v2")
        ic("dissolve", "M3 12h6", "M15 12h6", "M9.5 9l5 6", "M14.5 9l-5 6")
        ic("flip-normals", "M7 20V4", "M3 8l4-4 4 4", "M17 4v16", "M13 16l4 4 4-4")
        ic("shade-smooth", circle(12f, 12f, 9f), "M5.5 9.5c4 2 9 2 13 0", "M5.5 14.5c4 2 9 2 13 0")
        ic("shade-flat", "M12 3l7.8 4.5v9L12 21l-7.8-4.5v-9z", "M4.2 7.5L12 12l7.8-4.5", "M12 12v9")
        ic("fill", "M5 5h14v14H5z", "M5 5l14 14")
        ic("smooth", "M3 14c3-8 6-8 9 0s6 8 9 0")
        ic("invert", circle(12f, 12f, 9f), "*M12 3a9 9 0 0 1 0 18z")

        // primitives and object kinds
        ic("cube", "M12 2.5l8.5 4.75v9.5L12 21.5l-8.5-4.75v-9.5z", "M3.5 7.25L12 12l8.5-4.75", "M12 12v9.5")
        ic("sphere", circle(12f, 12f, 9f), "M3 12h18", "M12 3c3 2.5 3 15.5 0 18", "M12 3c-3 2.5-3 15.5 0 18")
        ic("cylinder", "M5 6c0-1.66 3.13-3 7-3s7 1.34 7 3-3.13 3-7 3-7-1.34-7-3z", "M5 6v12c0 1.66 3.13 3 7 3s7-1.34 7-3V6")
        ic("cone", "M12 3L5 18", "M12 3l7 15", "M5 18c0-1.66 3.13-3 7-3s7 1.34 7 3-3.13 3-7 3-7-1.34-7-3z")
        ic("torus", ellipse(12f, 12f, 9.5f, 6f), ellipse(12f, 12f, 4f, 2f))
        ic("plane", "M2 17l5-10h15l-5 10z")
        ic("circle", circle(12f, 12f, 8.5f), dot(12f, 3.5f, 1.5f), dot(20.5f, 12f, 1.5f), dot(12f, 20.5f, 1.5f), dot(3.5f, 12f, 1.5f))
        ic("grid", rect(3f, 3f, 18f, 18f, 1f), "M3 9h18", "M3 15h18", "M9 3v18", "M15 3v18")
        ic("light", "M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5", "M9 18h6", "M10 22h4")
        ic("camera", "M3 8a2 2 0 0 1 2-2h2l1.5-2h7L17 6h2a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z", circle(12f, 13f, 3.5f))
        ic("empty", "M12 3v18", "M3 12h18", circle(12f, 12f, 2.5f))

        // modes and selection
        ic("object-mode", "M12 2.5l8.5 4.75v9.5L12 21.5l-8.5-4.75v-9.5z", "M3.5 7.25L12 12l8.5-4.75", "M12 12v9.5")
        ic("edit-mode", "M12 4L4 19h16z", dot(12f, 4f, 2f), dot(4f, 19f, 2f), dot(20f, 19f, 2f))
        ic("vertex-select", "M5 5h14v14H5z", dot(5f, 5f, 2.2f), dot(19f, 5f, 2.2f), dot(19f, 19f, 2.2f), dot(5f, 19f, 2.2f))
        ic("edge-select", "M5 5h14v14H5z", "*M5 3.6h14v2.8H5z", dot(5f, 5f, 2.2f), dot(19f, 5f, 2.2f))
        ic("face-select", "M5 5h14v14H5z", "*M8.2 8.2h7.6v7.6H8.2z")
        ic("select-all", rect(4f, 4f, 16f, 16f, 2f), "M8.5 12.5l2.5 2.5 4.5-5.5")

        // viewport
        ic("eye", "M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z", circle(12f, 12f, 3f))
        ic("eye-off", "M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z", circle(12f, 12f, 3f), "M4 4l16 16")
        ic("lock", rect(5f, 11f, 14f, 10f, 2f), "M8 11V7a4 4 0 0 1 8 0v4")
        ic("unlock", rect(5f, 11f, 14f, 10f, 2f), "M8 11V7a4 4 0 0 1 7.5-2")
        ic("axes", "M12 12V3", "M12 12L4.5 16.5", "M12 12l7.5 4.5", dot(12f, 12f, 1.8f))
        ic("wire", "M12 2.5l8.5 4.75v9.5L12 21.5l-8.5-4.75v-9.5z", "M3.5 7.25L12 12l8.5-4.75", "M12 12v9.5")
        ic("solid", "*M12 2.5l8.5 4.75L12 12 3.5 7.25z", "M12 2.5l8.5 4.75v9.5L12 21.5l-8.5-4.75v-9.5z", "M3.5 7.25L12 12l8.5-4.75", "M12 12v9.5")
        ic("material", circle(12f, 12f, 9f), "M7.5 9.5a5 5 0 0 1 4-3.5", dot(15.5f, 14.5f, 1.4f))
        ic("xray", rect(3f, 3f, 12f, 12f, 1.5f), rect(9f, 9f, 12f, 12f, 1.5f))
        ic("perspective", "M3 20L9 4h6l6 16z", "M6 12h12")
        ic("ortho", "M4 8h12v12H4z", "M4 8l4-4h12l-4 4", "M20 4v12l-4 4")
        ic("home", "M3 11l9-8 9 8", "M5 10v10h5v-6h4v6h5V10")
        ic("focus", "M4 9V4h5", "M20 9V4h-5", "M4 15v5h5", "M20 15v5h-5", dot(12f, 12f, 2f))

        // panels
        ic("hierarchy", "M21 12h-8", "M21 6H8", "M21 18h-8", "M3 6v4c0 1.1.9 2 2 2h3", "M3 10v6c0 1.1.9 2 2 2h3")
        ic("sliders", "M4 21v-7", "M4 10V3", "M12 21v-9", "M12 8V3", "M20 21v-5", "M20 12V3", "M1 14h6", "M9 8h6", "M17 16h6")
        ic("wrench", "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z")
    }
}
