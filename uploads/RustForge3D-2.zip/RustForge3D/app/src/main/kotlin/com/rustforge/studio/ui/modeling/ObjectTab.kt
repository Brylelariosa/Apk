package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.core.ActiveObject
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.LightInfo
import com.rustforge.studio.core.NumericExpr
import com.rustforge.studio.core.ParamFormat
import com.rustforge.studio.core.ParamUnit
import com.rustforge.studio.core.Vec3
import com.rustforge.studio.state.AppDialog
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.ui.common.DropdownField
import com.rustforge.studio.ui.common.EntryField
import com.rustforge.studio.ui.common.LabelButton
import com.rustforge.studio.ui.common.LiveSlider
import com.rustforge.studio.ui.common.PropertyRow
import com.rustforge.studio.ui.common.SectionTitle
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.params.ColorPicker
import com.rustforge.studio.ui.theme.Palette

/** Name, transform, dimensions and light settings of the active object. */
@Composable
fun ObjectTab(state: EngineState, vm: AppViewModel, modifier: Modifier = Modifier) {
    val obj = state.active
    if (obj == null) {
        EmptyNote("Select an object to edit its properties.", modifier)
        return
    }
    PanelColumn(modifier) {
        PropertyRow("Name") {
            EntryField(
                text = obj.name,
                onCommit = { text ->
                    if (text.isBlank()) {
                        false
                    } else {
                        vm.call("object.rename", "id" to obj.id, "name" to text.trim())
                        true
                    }
                },
                modifier = Modifier.weight(1f),
                numeric = false,
            )
        }
        SectionTitle("Transform")
        VectorRow("Location", obj.location, ParamUnit.LENGTH) { vm.objectSet(obj.id, "location" to it.toJson()) }
        VectorRow("Rotation (degrees)", obj.rotation, ParamUnit.ANGLE) { vm.objectSet(obj.id, "rotation" to it.toJson()) }
        VectorRow("Scale", obj.scale, ParamUnit.NONE) { vm.objectSet(obj.id, "scale" to it.toJson()) }
        InfoRow("Dimensions", "${fmt(obj.dimensions.x)} x ${fmt(obj.dimensions.y)} x ${fmt(obj.dimensions.z)} m")
        Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            LabelButton("Numeric transform", { vm.showDialog(AppDialog.NumericTransform) }, Modifier.fillMaxWidth(), icon = "sliders")
            if (!state.isEdit) {
                LabelButton("Apply transforms", { vm.op("object.transform_apply") }, Modifier.fillMaxWidth(), icon = "check")
                LabelButton("Origin to geometry", { vm.op("object.origin_set") }, Modifier.fillMaxWidth(), icon = "focus")
            }
        }
        val light = obj.light
        if (light != null) LightSection(obj, light, vm)
    }
}

private fun fmt(v: Float): String = ParamFormat.plain(v.toDouble(), 3)

@Composable
private fun VectorRow(title: String, value: Vec3, unit: ParamUnit, onSet: (Vec3) -> Unit) {
    val axes = listOf("X", "Y", "Z")
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Txt(title, color = Palette.muted, size = 12.sp)
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0 until 3) {
                EntryField(
                    text = ParamFormat.plain(value[i].toDouble()),
                    onCommit = { text ->
                        val v = NumericExpr.evalOrNull(text, unit)
                        if (v == null) {
                            false
                        } else {
                            onSet(value.with(i, v.toFloat()))
                            true
                        }
                    },
                    modifier = Modifier.weight(1f),
                    suffix = axes[i],
                )
            }
        }
    }
}

@Composable
private fun LightSection(obj: ActiveObject, light: LightInfo, vm: AppViewModel) {
    SectionTitle("Light")
    PropertyRow("Type") {
        DropdownField(
            options = listOf("POINT" to "Point", "SUN" to "Sun", "SPOT" to "Spot"),
            selected = light.type.uppercase(),
            onSelect = { vm.call("light.set", "id" to obj.id, "type" to it) },
            modifier = Modifier.weight(1f),
        )
    }
    ColorPicker(listOf(light.color.x, light.color.y, light.color.z), { c -> vm.call("light.set", "id" to obj.id, "color" to c) })
    val sun = light.type.equals("SUN", ignoreCase = true)
    LiveSlider(
        label = if (sun) "Strength" else "Power (W)",
        value = light.energy,
        range = 0f..(if (sun) 20f else 2000f),
        onChange = { vm.call("light.set", "id" to obj.id, "energy" to it) },
        valueText = { ParamFormat.plain(it.toDouble(), 1) },
    )
    if (light.type.equals("SPOT", ignoreCase = true)) {
        LiveSlider(
            label = "Spot size (degrees)",
            value = light.spotSizeDeg,
            range = 1f..180f,
            onChange = { vm.call("light.set", "id" to obj.id, "spot_size_deg" to it) },
            valueText = { ParamFormat.plain(it.toDouble(), 0) },
        )
        LiveSlider(
            label = "Spot blend",
            value = light.spotBlend,
            range = 0f..1f,
            onChange = { vm.call("light.set", "id" to obj.id, "spot_blend" to it) },
            valueText = { ParamFormat.plain(it.toDouble(), 2) },
        )
    }
}
