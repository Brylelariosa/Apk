package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.SceneObject
import com.rustforge.studio.state.AppDialog
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.state.UiState
import com.rustforge.studio.ui.common.LabelButton
import com.rustforge.studio.ui.common.MenuButton
import com.rustforge.studio.ui.common.MenuEntry
import com.rustforge.studio.ui.common.Pressable
import com.rustforge.studio.ui.common.ToolButton
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.icons.AppIcon
import com.rustforge.studio.ui.theme.Palette

/** The object list. Tap selects, long press renames; eye and lock buttons and a menu per row. */
@Composable
fun SceneTab(state: EngineState, ui: UiState, vm: AppViewModel, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Txt("${state.scene.name}: ${state.scene.objects.size} objects", Modifier.weight(1f), color = Palette.muted)
            LabelButton("Multi-select", { vm.setMultiSelect(!ui.multiSelect) }, icon = "select-all", selected = ui.multiSelect)
        }
        if (state.scene.objects.isEmpty()) {
            EmptyNote("The scene is empty. Use Add in the bottom bar to create an object.")
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(state.scene.objects, key = { it.id }) { obj ->
                    ObjectRow(obj, ui.multiSelect, state.isEdit, vm)
                }
            }
        }
    }
}

private fun kindIcon(kind: String): String = when (kind.lowercase()) {
    "light" -> "light"
    "camera" -> "camera"
    "empty" -> "empty"
    else -> "cube"
}

@Composable
private fun ObjectRow(obj: SceneObject, multi: Boolean, editMode: Boolean, vm: AppViewModel) {
    val rowColor = if (obj.selected) Palette.accentDim else Color.Transparent
    val textColor = if (obj.active) Palette.accent else Palette.text
    Row(Modifier.fillMaxWidth().height(48.dp).background(rowColor), verticalAlignment = Alignment.CenterVertically) {
        Pressable(
            onTap = { if (multi) vm.toggleObjectSelection(obj.id) else vm.selectObject(obj.id) },
            modifier = Modifier.weight(1f).fillMaxHeight(),
            enabled = !editMode,
            label = obj.name,
            onLongPress = { vm.showDialog(AppDialog.Rename(obj.id, obj.name)) },
            shape = RectangleShape,
        ) {
            Row(
                Modifier.fillMaxWidth().padding(start = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                AppIcon(kindIcon(obj.kind), tint = if (obj.active) Palette.accent else Palette.muted, size = 20.dp)
                Txt(obj.name, Modifier.weight(1f), color = textColor)
                if (obj.modifiers > 0) AppIcon("wrench", tint = Palette.muted, size = 16.dp)
            }
        }
        ToolButton(
            if (obj.visible) "eye" else "eye-off",
            if (obj.visible) "Hide" else "Show",
            { vm.objectSet(obj.id, "visible" to !obj.visible) },
            size = 44.dp,
            iconSize = 20.dp,
        )
        ToolButton(
            if (obj.locked) "lock" else "unlock",
            if (obj.locked) "Unlock" else "Lock",
            { vm.objectSet(obj.id, "locked" to !obj.locked) },
            size = 44.dp,
            iconSize = 20.dp,
        )
        MenuButton(
            button = { open -> ToolButton("more", "More", open, size = 44.dp, iconSize = 20.dp, enabled = !editMode) },
            menu = { close ->
                MenuEntry("Rename", { close(); vm.showDialog(AppDialog.Rename(obj.id, obj.name)) }, icon = "pencil")
                MenuEntry("Duplicate", { close(); vm.selectObject(obj.id); vm.op("object.duplicate_move") }, icon = "duplicate")
                MenuEntry("Delete", { close(); vm.selectObject(obj.id); vm.op("object.delete") }, icon = "delete")
            },
        )
    }
}
