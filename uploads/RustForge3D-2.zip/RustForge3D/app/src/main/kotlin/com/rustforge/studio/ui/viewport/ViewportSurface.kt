package com.rustforge.studio.ui.viewport

import android.annotation.SuppressLint
import android.content.Context
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.rustforge.studio.bridge.EngineClient

private const val MAX_POINTERS = 16

/**
 * The 3D surface. The engine renders into it and interprets every touch itself (gestures, tools, gizmos), so each
 * MotionEvent is forwarded unchanged; nothing is decided here.
 */
@SuppressLint("ViewConstructor")
class ViewportView(context: Context, private val client: EngineClient) : SurfaceView(context), SurfaceHolder.Callback {
    private val ids = IntArray(MAX_POINTERS)
    private val xs = FloatArray(MAX_POINTERS)
    private val ys = FloatArray(MAX_POINTERS)
    private val pressures = FloatArray(MAX_POINTERS)
    private val toolTypes = IntArray(MAX_POINTERS)

    init {
        holder.addCallback(this)
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        // The surface size is only known in surfaceChanged, which always follows.
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        client.onSurface(holder.surface, width, height)
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        client.onSurfaceDestroyed()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val count = minOf(event.pointerCount, MAX_POINTERS)
        for (i in 0 until count) {
            ids[i] = event.getPointerId(i)
            xs[i] = event.getX(i)
            ys[i] = event.getY(i)
            pressures[i] = event.getPressure(i)
            toolTypes[i] = event.getToolType(i)
        }
        client.touch(event.actionMasked, event.actionIndex, event.eventTime, count, ids, xs, ys, pressures, toolTypes)
        return true
    }
}

/** Hosts the [ViewportView]. It stays at one place in the composition so layout changes only resize the surface. */
@Composable
fun ViewportSurface(client: EngineClient, modifier: Modifier = Modifier) {
    AndroidView(
        factory = { context -> ViewportView(context, client) },
        modifier = modifier.fillMaxSize(),
    )
}
