package com.rustforge.studio.core

import java.util.Locale

/** Texts shown over the viewport. Kept free of UI code so they can be tested. */
object HudText {
    fun viewLabel(c: CameraState): String {
        val view = when (c.view) {
            "front" -> "Front"
            "back" -> "Back"
            "left" -> "Left"
            "right" -> "Right"
            "top" -> "Top"
            "bottom" -> "Bottom"
            else -> "User"
        }
        val projection = if (c.projection == "ortho") "Orthographic" else "Perspective"
        return "$view $projection"
    }

    /** What is selected: element counts in Edit Mode, otherwise the active object's name or the object count. */
    fun selectionSummary(s: EngineState): String {
        val e = s.edit
        if (s.isEdit && e != null) {
            val label: String
            val counts: Counts
            when (s.selectMode) {
                "edge" -> {
                    label = "Edges"
                    counts = e.edges
                }
                "face" -> {
                    label = "Faces"
                    counts = e.faces
                }
                else -> {
                    label = "Vertices"
                    counts = e.verts
                }
            }
            return "$label ${counts.selected} / ${counts.total}"
        }
        val selected = s.scene.selectedCount
        val active = s.active
        return when {
            selected <= 0 -> "Nothing selected"
            selected == 1 && active != null -> active.name
            else -> "$selected objects selected"
        }
    }

    /** Live read-out of a modal tool (extrude distance and so on); null when no tool is being dragged. */
    fun toolLine(t: ToolState?): String? {
        if (t == null) return null
        val value = String.format(Locale.ROOT, "%.3f", t.value).trimEnd('0').trimEnd('.').ifEmpty { "0" }
        val unit = if (t.unit.isEmpty()) "" else " ${t.unit}"
        val hint = if (t.hint.isEmpty()) "" else "  -  ${t.hint}"
        return "${t.label}: $value$unit$hint"
    }

    fun grouped(n: Long): String = String.format(Locale.ROOT, "%,d", n)

    fun statsLines(s: StatsInfo): List<String> {
        val lines = ArrayList<String>()
        lines.add("Objects ${s.objects}")
        lines.add("Vertices ${grouped(s.verts)}")
        lines.add("Faces ${grouped(s.faces)}")
        lines.add("Triangles ${grouped(s.tris)}")
        lines.add(String.format(Locale.ROOT, "%.0f FPS", s.fps))
        lines.add(String.format(Locale.ROOT, "GPU %.0f MB", s.gpuMb))
        if (s.backend.isNotBlank()) lines.add("Backend ${s.backend}")
        lines.add("Quality ${s.quality}")
        return lines
    }
}
