package com.rustforge.studio.ui.help

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.HelpContent
import com.rustforge.studio.ui.common.DialogFrame
import com.rustforge.studio.ui.common.SectionTitle
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.theme.Palette

/** Gestures and tools as they behave in this build ([HelpContent]). */
@Composable
fun HelpDialog(onClose: () -> Unit) {
    DialogFrame(title = "Help", onClose = onClose) {
        for (section in HelpContent.sections) {
            SectionTitle(section.title)
            for (line in section.lines) {
                Row(Modifier.padding(vertical = 3.dp)) {
                    Txt("-", Modifier.width(14.dp), color = Palette.muted)
                    Txt(line, Modifier.weight(1f), maxLines = 8)
                }
            }
        }
    }
}
