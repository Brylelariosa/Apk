package com.rustforge.studio.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.bridge.EngineClient
import com.rustforge.studio.state.AppDialog
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.state.Workspace
import com.rustforge.studio.ui.code.CodeWorkspace
import com.rustforge.studio.ui.common.ConfirmDialog
import com.rustforge.studio.ui.common.ToastHost
import com.rustforge.studio.ui.help.HelpDialog
import com.rustforge.studio.ui.icons.AppIcon
import com.rustforge.studio.ui.modeling.ModelingWorkspace
import com.rustforge.studio.ui.modeling.NumericTransformDialog
import com.rustforge.studio.ui.modeling.RenameDialog
import com.rustforge.studio.ui.settings.SettingsDialog
import com.rustforge.studio.ui.theme.Palette

/** Entry composable: the engine start-failure screen, or the app. */
@Composable
fun AppRoot(vm: AppViewModel) {
    val client = vm.client
    val startError = vm.startError
    if (client == null) {
        StartFailureScreen(startError ?: "The native engine is not available.")
    } else {
        MainContent(vm, client)
    }
}

@Composable
private fun MainContent(vm: AppViewModel, client: EngineClient) {
    val state by vm.engine.collectAsState()
    val ui by vm.ui.collectAsState()
    val layout = rememberLayoutSpec()

    val openLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openProject(uri)
    }
    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) vm.saveProject(uri)
    }
    val suggestedName = (ui.documentName ?: "Untitled").let { if (it.endsWith(".rforge")) it else "$it.rforge" }
    val actions = ProjectActions(
        open = { openLauncher.launch(arrayOf("*/*")) },
        save = { if (!vm.saveToCurrent()) saveLauncher.launch(suggestedName) },
        saveAs = { saveLauncher.launch(suggestedName) },
    )

    BackHandler(enabled = ui.workspace == Workspace.CODE || (ui.panelOpen && !layout.dock)) {
        if (ui.workspace == Workspace.CODE) vm.setWorkspace(Workspace.MODELING) else vm.closePanel()
    }

    Box(Modifier.fillMaxSize().background(Palette.bg)) {
        Column(Modifier.fillMaxSize()) {
            TopBar(state, ui, vm, layout, actions)
            when (ui.workspace) {
                Workspace.MODELING -> ModelingWorkspace(vm, client, Modifier.weight(1f))
                Workspace.CODE -> CodeWorkspace({ vm.setWorkspace(Workspace.MODELING) }, Modifier.weight(1f))
            }
        }
        ToastHost(vm.messages, Modifier.align(Alignment.TopCenter).padding(top = 64.dp, start = 12.dp, end = 12.dp))
    }

    when (val dialog = ui.dialog) {
        null -> Unit
        AppDialog.Settings -> SettingsDialog(state, ui, vm)
        AppDialog.Help -> HelpDialog({ vm.closeDialog() })
        AppDialog.NumericTransform -> NumericTransformDialog(vm)
        AppDialog.ConfirmNew -> ConfirmDialog(
            title = "New project",
            message = "Discard the current scene and start an empty one? Anything not saved is lost.",
            confirmLabel = "Discard",
            onConfirm = {
                vm.newProject()
                vm.closeDialog()
            },
            onCancel = { vm.closeDialog() },
        )
        is AppDialog.Rename -> RenameDialog(dialog, vm)
    }
}

@Composable
private fun StartFailureScreen(message: String) {
    Box(Modifier.fillMaxSize().background(Palette.bg), contentAlignment = Alignment.Center) {
        Column(
            Modifier.padding(24.dp).widthIn(max = 480.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AppIcon("error", tint = Palette.danger, size = 40.dp)
            Text("RustForge 3D could not start its engine", color = Palette.text, fontSize = 18.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
            Text(message, color = Palette.muted, fontSize = 13.sp, textAlign = TextAlign.Center)
            Text(
                "Restart the app. If this keeps happening the device may lack the graphics support the engine needs (Vulkan or OpenGL ES 3.0).",
                color = Palette.muted,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )
        }
    }
}
