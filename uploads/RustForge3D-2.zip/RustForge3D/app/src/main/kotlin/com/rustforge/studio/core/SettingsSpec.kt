package com.rustforge.studio.core

/** How one engine setting is edited in the settings dialog. */
sealed class SettingControl {
    object Toggle : SettingControl()
    data class Slider(val min: Float, val max: Float, val step: Float) : SettingControl() {
        /** The nearest multiple of [step] (counted from [min]) inside the range. */
        fun snap(v: Float): Float {
            val n = Math.round((v - min) / step)
            return (min + n * step).coerceIn(min, max)
        }
    }
    data class Choice(val options: List<Pair<String, String>>) : SettingControl()
}

data class SettingSpec(val path: String, val label: String, val control: SettingControl, val help: String = "")
data class SettingGroup(val title: String, val items: List<SettingSpec>)

/**
 * The settings the engine honours (docs/PROTOCOL.md section 5), grouped for the settings dialog. Settings that exist in the
 * protocol but are not wired up in the engine yet are deliberately not offered here.
 */
object SettingsSpecs {
    private fun toggle(path: String, label: String, help: String = "") = SettingSpec(path, label, SettingControl.Toggle, help)
    private fun slider(path: String, label: String, min: Float, max: Float, step: Float, help: String = "") =
        SettingSpec(path, label, SettingControl.Slider(min, max, step), help)

    private fun choice(path: String, label: String, help: String, vararg options: Pair<String, String>) =
        SettingSpec(path, label, SettingControl.Choice(options.toList()), help)

    val groups: List<SettingGroup> = listOf(
        SettingGroup(
            "Touch",
            listOf(
                slider("touch.sensitivity", "Overall sensitivity", 0.2f, 4f, 0.1f),
                slider("touch.orbit_speed", "Orbit speed", 0.2f, 4f, 0.1f),
                slider("touch.pan_speed", "Pan speed", 0.2f, 4f, 0.1f),
                slider("touch.zoom_speed", "Zoom speed", 0.2f, 4f, 0.1f),
                toggle("touch.invert_y", "Invert vertical orbit"),
                slider("touch.hit_radius_dp", "Touch hit radius (dp)", 8f, 80f, 1f, "How close a tap must be to a vertex, edge or handle to pick it."),
                toggle("touch.stylus", "Stylus draws selection boxes", "A pen drag on empty space draws a selection box instead of orbiting."),
            ),
        ),
        SettingGroup(
            "Gestures",
            listOf(
                choice("gestures.one_finger", "One-finger drag (Navigate tool)", "", "orbit" to "Orbit", "pan" to "Pan", "none" to "Nothing"),
                choice("gestures.select_drag", "Drag on empty space (Select tool)", "", "orbit" to "Orbit", "box" to "Box select"),
                choice("gestures.two_finger", "Two-finger drag", "", "pan" to "Pan", "orbit" to "Orbit"),
                choice("gestures.pinch", "Pinch", "", "zoom" to "Zoom", "none" to "Nothing"),
                choice("gestures.double_tap", "Double tap", "", "focus" to "Focus selection", "none" to "Nothing"),
            ),
        ),
        SettingGroup(
            "Gizmo and snapping",
            listOf(
                slider("gizmo.size", "Gizmo size", 0.5f, 2.5f, 0.1f),
                toggle("gizmo.visible", "Show gizmo"),
                choice("gizmo.orientation", "Gizmo orientation", "", "global" to "Global", "local" to "Local"),
                toggle("snap.grid", "Snap movement to grid"),
                slider("snap.grid_size", "Grid step (m)", 0.05f, 5f, 0.05f),
                toggle("snap.angle", "Snap rotation"),
                slider("snap.angle_step_deg", "Angle step (degrees)", 1f, 90f, 1f),
                toggle("snap.scale", "Snap scale"),
                slider("snap.scale_step", "Scale step", 0.01f, 1f, 0.01f),
            ),
        ),
        SettingGroup(
            "Selection",
            listOf(
                toggle("select.additive", "Additive selection", "Taps and boxes add to the selection instead of replacing it."),
                toggle("select.xray_box", "Box select sees through surfaces"),
            ),
        ),
        SettingGroup(
            "Viewport",
            listOf(
                choice(
                    "viewport.quality", "Quality", "Auto lowers the quality when the frame rate drops and raises it again when there is headroom.",
                    "auto" to "Auto", "low" to "Low (fastest)", "medium" to "Medium", "high" to "High",
                ),
            ),
        ),
    )

    val all: List<SettingSpec> get() = groups.flatMap { it.items }
}
