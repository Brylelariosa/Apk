package com.rustforge.studio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Restrained dark palette with a single accent colour. */
object Palette {
    val bg = Color(0xFF1B1C1F)
    val panel = Color(0xFF25272B)
    val panelRaised = Color(0xFF2E3136)
    val field = Color(0xFF1F2124)
    val outline = Color(0xFF3A3D43)
    val pressed = Color(0xFF3A3E45)
    val text = Color(0xFFE6E8EC)
    val muted = Color(0xFF9AA0AA)
    val accent = Color(0xFF5B9DFF)
    val accentDim = Color(0xFF2B4A78)
    val onAccent = Color(0xFF0B1B33)
    val danger = Color(0xFFE5594F)
    val warning = Color(0xFFE2A93B)
    val ok = Color(0xFF4FB58A)
    val hud = Color(0x99101114)
}

@Composable
fun RustForgeTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Palette.accent,
        onPrimary = Palette.onAccent,
        secondary = Palette.accent,
        onSecondary = Palette.onAccent,
        background = Palette.bg,
        onBackground = Palette.text,
        surface = Palette.panel,
        onSurface = Palette.text,
        surfaceVariant = Palette.panelRaised,
        onSurfaceVariant = Palette.muted,
        error = Palette.danger,
        onError = Color.White,
        outline = Palette.outline,
    )
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
