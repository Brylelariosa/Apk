package com.rustforge.studio.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.rustforge.studio.state.UiMessage
import com.rustforge.studio.ui.icons.AppIcon
import com.rustforge.studio.ui.theme.Palette
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow

/** Shows the newest message for a few seconds. Carries no touch handling, so it never blocks the viewport. */
@Composable
fun ToastHost(messages: Flow<UiMessage>, modifier: Modifier = Modifier) {
    var current by remember { mutableStateOf<UiMessage?>(null) }
    LaunchedEffect(messages) {
        messages.collect { current = it }
    }
    val message = current
    if (message != null) {
        LaunchedEffect(message.id) {
            delay(if (message.level == "error") 6000L else 3500L)
            if (current?.id == message.id) current = null
        }
        ToastCard(message, modifier)
    }
}

@Composable
private fun ToastCard(message: UiMessage, modifier: Modifier) {
    val icon: String
    val tint = when (message.level) {
        "error" -> {
            icon = "error"
            Palette.danger
        }
        "warn" -> {
            icon = "warning"
            Palette.warning
        }
        else -> {
            icon = "info"
            Palette.accent
        }
    }
    Row(
        modifier
            .widthIn(max = 520.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Palette.panelRaised)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        AppIcon(icon, tint = tint, size = 20.dp)
        Txt(message.text, Modifier.weight(1f, fill = false), maxLines = 4)
    }
}
