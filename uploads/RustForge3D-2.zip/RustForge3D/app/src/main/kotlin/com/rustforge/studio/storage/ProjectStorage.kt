package com.rustforge.studio.storage

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/** File access through the Storage Access Framework (no storage permissions) and the app-private autosave file. */
object ProjectStorage {
    suspend fun read(resolver: ContentResolver, uri: Uri): ByteArray = withContext(Dispatchers.IO) {
        val input = resolver.openInputStream(uri) ?: throw IOException("The file could not be opened")
        input.use { it.readBytes() }
    }

    suspend fun write(resolver: ContentResolver, uri: Uri, bytes: ByteArray) = withContext(Dispatchers.IO) {
        val out = resolver.openOutputStream(uri, "wt") ?: throw IOException("The file could not be written")
        out.use { it.write(bytes) }
    }

    fun displayName(resolver: ContentResolver, uri: Uri): String? = try {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    /** Writes atomically (temp file + rename) so a crash never leaves a truncated autosave. */
    suspend fun writeAutosave(file: File, bytes: ByteArray) = withContext(Dispatchers.IO) {
        val tmp = File(file.parentFile, file.name + ".tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(file)) {
            file.delete()
            tmp.renameTo(file)
        }
    }

    suspend fun readAutosave(file: File): ByteArray? = withContext(Dispatchers.IO) {
        if (file.isFile && file.length() > 0) file.readBytes() else null
    }
}
