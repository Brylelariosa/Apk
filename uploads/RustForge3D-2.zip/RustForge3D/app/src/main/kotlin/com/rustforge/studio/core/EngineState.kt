package com.rustforge.studio.core

data class Vec3(val x: Float, val y: Float, val z: Float) {
    operator fun get(i: Int): Float = when (i) {
        0 -> x
        1 -> y
        else -> z
    }

    fun with(i: Int, v: Float): Vec3 = when (i) {
        0 -> copy(x = v)
        1 -> copy(y = v)
        else -> copy(z = v)
    }

    fun toJson(): Json = jsonArrayOf(x, y, z)

    companion object {
        val ZERO = Vec3(0f, 0f, 0f)
        val ONE = Vec3(1f, 1f, 1f)

        fun from(j: Json, default: Vec3 = ZERO): Vec3 {
            val l = j.list
            return if (l.size < 3) default else Vec3(l[0].float(), l[1].float(), l[2].float())
        }
    }
}

data class ToolState(val kind: String, val label: String, val value: Double, val unit: String, val hint: String)
data class CameraState(val projection: String = "persp", val view: String = "user", val fovDeg: Float = 50f, val yawDeg: Float = 0f, val pitchDeg: Float = 0f)
data class ViewState(
    val shading: String = "solid",
    val grid: Boolean = true,
    val axes: Boolean = true,
    val wireOverlay: Boolean = false,
    val xray: Boolean = false,
    val stats: Boolean = false,
)

data class CollectionInfo(val id: Int, val name: String, val parent: Int, val visible: Boolean, val locked: Boolean)
data class SceneObject(
    val id: Int,
    val name: String,
    val kind: String,
    val parent: Int,
    val collection: Int,
    val visible: Boolean,
    val locked: Boolean,
    val selected: Boolean,
    val active: Boolean,
    val verts: Int,
    val faces: Int,
    val modifiers: Int,
    val material: String?,
)

data class SceneState(
    val name: String = "Scene",
    val collections: List<CollectionInfo> = emptyList(),
    val objects: List<SceneObject> = emptyList(),
    val active: Int = 0,
    val selectedCount: Int = 0,
)

data class MeshInfo(val verts: Int, val edges: Int, val faces: Int, val tris: Int, val dataName: String, val valid: Boolean, val issues: List<String>)
data class ModifierInfo(val index: Int, val type: String, val name: String, val showViewport: Boolean, val showRender: Boolean, val params: List<ParamDef>)
data class SlotInfo(val slot: Int, val material: Int, val name: String)
data class LightInfo(val type: String, val color: Vec3, val energy: Float, val spotSizeDeg: Float, val spotBlend: Float)
data class CameraObjInfo(val lensMm: Float, val sensorMm: Float, val clipStart: Float, val clipEnd: Float, val ortho: Boolean, val orthoScale: Float)

/** Details of the active object. Rotations are in degrees. */
data class ActiveObject(
    val id: Int,
    val name: String,
    val kind: String,
    val parent: Int,
    val collection: Int,
    val location: Vec3,
    val rotation: Vec3,
    val scale: Vec3,
    val dimensions: Vec3,
    val mesh: MeshInfo?,
    val modifiers: List<ModifierInfo>,
    val slots: List<SlotInfo>,
    val light: LightInfo?,
    val camera: CameraObjInfo?,
)

data class MaterialInfo(
    val id: Int,
    val name: String,
    val baseColor: List<Float>,
    val metallic: Float,
    val roughness: Float,
    val alpha: Float,
    val emission: Vec3,
    val emissionStrength: Float,
    val users: Int,
)

data class Counts(val total: Int = 0, val selected: Int = 0)
data class EditInfo(val verts: Counts, val edges: Counts, val faces: Counts, val median: Vec3)
data class LastOp(val id: String, val label: String, val params: List<ParamDef>)
data class UndoInfo(val canUndo: Boolean = false, val canRedo: Boolean = false, val undoLabel: String = "", val redoLabel: String = "", val depth: Int = 0)
data class ScriptInfo(val status: String = "idle", val runMode: String = "replace", val elapsedMs: Long = 0, val consoleSeq: Long = 0, val created: Int = 0, val errorMessage: String? = null, val available: Boolean = false)
data class StatsInfo(
    val objects: Int = 0,
    val verts: Long = 0,
    val faces: Long = 0,
    val tris: Long = 0,
    val gpuMb: Float = 0f,
    val fps: Float = 0f,
    val quality: String = "auto",
    val backend: String = "",
)

data class EngineToast(val seq: Long, val level: String, val text: String)

/** Read access to the settings object of a snapshot by dotted path. */
data class SettingsView(val json: Json = Json.Null) {
    fun f(path: String, default: Double = 0.0): Double = json.path(path).double(default)
    fun b(path: String, default: Boolean = false): Boolean = json.path(path).bool(default)
    fun s(path: String, default: String = ""): String = json.path(path).str(default)
}

/** One full engine state snapshot (docs/PROTOCOL.md section 3). Defaults describe "no snapshot received yet". */
data class EngineState(
    val rev: Long = 0,
    val mode: String = "object",
    val selectMode: String = "vertex",
    val tool: String = "select",
    val toolState: ToolState? = null,
    val camera: CameraState = CameraState(),
    val view: ViewState = ViewState(),
    val scene: SceneState = SceneState(),
    val active: ActiveObject? = null,
    val materials: List<MaterialInfo> = emptyList(),
    val edit: EditInfo? = null,
    val lastOp: LastOp? = null,
    val undo: UndoInfo = UndoInfo(),
    val settings: SettingsView = SettingsView(),
    val script: ScriptInfo = ScriptInfo(),
    val stats: StatsInfo = StatsInfo(),
    val toast: EngineToast? = null,
) {
    val isEdit: Boolean get() = mode == "edit"
    fun objectById(id: Int): SceneObject? = scene.objects.firstOrNull { it.id == id }
    val selectedObjects: List<SceneObject> get() = scene.objects.filter { it.selected }

    companion object {
        fun parse(text: String): EngineState = SnapshotParser.parse(Json.parse(text))
    }
}

/** Tolerant snapshot reader: missing or mistyped members fall back to defaults, unknown members are ignored. */
object SnapshotParser {
    private fun Json.objOrNull(): Json? = if (this is Json.Obj) this else null

    fun parse(j: Json): EngineState = EngineState(
        rev = j["rev"].long(),
        mode = j["mode"].str("object"),
        selectMode = j["select_mode"].str("vertex"),
        tool = j["tool"].str("select"),
        toolState = j["tool_state"].objOrNull()?.let { toolState(it) },
        camera = camera(j["camera"]),
        view = view(j["view"]),
        scene = scene(j["scene"]),
        active = j["active"].objOrNull()?.let { active(it) },
        materials = j["materials"].list.map { material(it) },
        edit = j["edit"].objOrNull()?.let { edit(it) },
        lastOp = j["last_op"].objOrNull()?.let { LastOp(it["id"].str(), it["label"].str(), ParamDefs.parseList(it["params"])) },
        undo = undo(j["undo"]),
        settings = SettingsView(j["settings"]),
        script = script(j["script"]),
        stats = stats(j["stats"]),
        toast = j["toast"].objOrNull()?.let { EngineToast(it["seq"].long(), it["level"].str("info"), it["text"].str()) },
    )

    private fun toolState(j: Json) = ToolState(j["kind"].str(), j["label"].str(), j["value"].double(), j["unit"].str(), j["hint"].str())

    private fun camera(j: Json) = CameraState(j["projection"].str("persp"), j["view"].str("user"), j["fov_deg"].float(50f), j["yaw_deg"].float(), j["pitch_deg"].float())

    private fun view(j: Json) = ViewState(
        shading = j["shading"].str("solid"),
        grid = j["grid"].bool(true),
        axes = j["axes"].bool(true),
        wireOverlay = j["wire_overlay"].bool(),
        xray = j["xray"].bool(),
        stats = j["stats"].bool(),
    )

    private fun scene(j: Json) = SceneState(
        name = j["name"].str("Scene"),
        collections = j["collections"].list.map { CollectionInfo(it["id"].int(), it["name"].str(), it["parent"].int(), it["visible"].bool(true), it["locked"].bool()) },
        objects = j["objects"].list.map { o ->
            SceneObject(
                id = o["id"].int(),
                name = o["name"].str(),
                kind = o["kind"].str("mesh"),
                parent = o["parent"].int(),
                collection = o["collection"].int(),
                visible = o["visible"].bool(true),
                locked = o["locked"].bool(),
                selected = o["selected"].bool(),
                active = o["active"].bool(),
                verts = o["verts"].int(),
                faces = o["faces"].int(),
                modifiers = o["modifiers"].int(),
                material = (o["material"] as? Json.Str)?.value,
            )
        },
        active = j["active"].int(),
        selectedCount = j["selected_count"].int(),
    )

    private fun active(j: Json): ActiveObject {
        val t = j["transform"]
        val mesh = j["mesh"].objOrNull()?.let { m ->
            MeshInfo(m["verts"].int(), m["edges"].int(), m["faces"].int(), m["tris"].int(), m["data_name"].str(), m["valid"].bool(true), m["issues"].strings())
        }
        val light = j["light"].objOrNull()?.let { l ->
            LightInfo(l["type"].str("POINT"), Vec3.from(l["color"], Vec3.ONE), l["energy"].float(), l["spot_size_deg"].float(45f), l["spot_blend"].float())
        }
        val cam = j["camera"].objOrNull()?.let { c ->
            CameraObjInfo(c["lens_mm"].float(50f), c["sensor_mm"].float(36f), c["clip_start"].float(0.1f), c["clip_end"].float(1000f), c["ortho"].bool(), c["ortho_scale"].float(6f))
        }
        return ActiveObject(
            id = j["id"].int(),
            name = j["name"].str(),
            kind = j["kind"].str("mesh"),
            parent = j["parent"].int(),
            collection = j["collection"].int(),
            location = Vec3.from(t["location"]),
            rotation = Vec3.from(t["rotation"]),
            scale = Vec3.from(t["scale"], Vec3.ONE),
            dimensions = Vec3.from(j["dimensions"]),
            mesh = mesh,
            modifiers = j["modifiers"].list.map { m ->
                ModifierInfo(m["index"].int(), m["type"].str(), m["name"].str(), m["show_viewport"].bool(true), m["show_render"].bool(true), ParamDefs.parseList(m["params"]))
            },
            slots = j["slots"].list.map { SlotInfo(it["slot"].int(), it["material"].int(), it["name"].str()) },
            light = light,
            camera = cam,
        )
    }

    private fun material(j: Json): MaterialInfo {
        val c = j["base_color"].floats()
        return MaterialInfo(
            id = j["id"].int(),
            name = j["name"].str(),
            baseColor = if (c.size >= 4) c.take(4) else listOf(0.8f, 0.8f, 0.8f, 1f),
            metallic = j["metallic"].float(),
            roughness = j["roughness"].float(0.5f),
            alpha = j["alpha"].float(1f),
            emission = Vec3.from(j["emission"]),
            emissionStrength = j["emission_strength"].float(),
            users = j["users"].int(),
        )
    }

    private fun edit(j: Json): EditInfo {
        fun counts(c: Json) = Counts(c["total"].int(), c["selected"].int())
        return EditInfo(counts(j["verts"]), counts(j["edges"]), counts(j["faces"]), Vec3.from(j["median"]))
    }

    private fun undo(j: Json) = UndoInfo(j["can_undo"].bool(), j["can_redo"].bool(), j["undo_label"].str(), j["redo_label"].str(), j["depth"].int())

    private fun script(j: Json) = ScriptInfo(
        status = j["status"].str("idle"),
        runMode = j["run_mode"].str("replace"),
        elapsedMs = j["elapsed_ms"].long(),
        consoleSeq = j["console_seq"].long(),
        created = j["created"].int(),
        errorMessage = j["error"].objOrNull()?.get("message")?.str(),
        available = j["available"].bool(),
    )

    private fun stats(j: Json) = StatsInfo(
        objects = j["objects"].int(),
        verts = j["verts"].long(),
        faces = j["faces"].long(),
        tris = j["tris"].long(),
        gpuMb = j["gpu_mb"].float(),
        fps = j["fps"].float(),
        quality = j["quality"].str("auto"),
        backend = j["backend"].str(),
    )
}
