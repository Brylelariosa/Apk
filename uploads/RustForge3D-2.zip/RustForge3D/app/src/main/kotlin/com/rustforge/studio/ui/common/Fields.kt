package com.rustforge.studio.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.ui.theme.Palette
import kotlinx.coroutines.delay

/**
 * Text entry that commits on the keyboard's Done key or when focus leaves. [onCommit] returns false when the entry is
 * invalid: the field then shows an error outline and reverts to [text]. [onEdit] sees every keystroke (for dialogs whose
 * confirm button may be tapped while the field still has focus).
 */
@Composable
fun EntryField(
    text: String,
    onCommit: (String) -> Boolean,
    modifier: Modifier = Modifier,
    suffix: String = "",
    enabled: Boolean = true,
    numeric: Boolean = true,
    alignEnd: Boolean = numeric,
    onEdit: (String) -> Unit = {},
) {
    var edit by remember(text) { mutableStateOf(text) }
    var focused by remember { mutableStateOf(false) }
    var rejected by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    val shape = RoundedCornerShape(8.dp)

    fun commit() {
        if (edit == text) {
            rejected = false
            return
        }
        val ok = onCommit(edit)
        rejected = !ok
        if (!ok) edit = text
    }

    val border = when {
        rejected -> Palette.danger
        focused -> Palette.accent
        else -> Palette.outline
    }
    Row(
        modifier
            .height(40.dp)
            .clip(shape)
            .background(Palette.field)
            .border(1.dp, border, shape)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        BasicTextField(
            value = edit,
            onValueChange = {
                edit = it
                rejected = false
                onEdit(it)
            },
            enabled = enabled,
            singleLine = true,
            textStyle = TextStyle(color = if (enabled) Palette.text else Palette.muted, fontSize = 14.sp, textAlign = if (alignEnd) TextAlign.End else TextAlign.Start),
            cursorBrush = SolidColor(Palette.accent),
            keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = {
                commit()
                focus.clearFocus()
            }),
            modifier = Modifier
                .weight(1f)
                .onFocusChanged { st ->
                    if (focused && !st.isFocused) commit()
                    focused = st.isFocused
                },
        )
        if (suffix.isNotEmpty()) Text(suffix, color = Palette.muted, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp))
    }
}

/**
 * Slider with a value read-out. With [live] false the value is only reported when the finger lifts (for settings whose
 * every change is an undo step); with [live] true every movement is reported.
 */
@Composable
fun LiveSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    valueText: (Float) -> String,
    modifier: Modifier = Modifier,
    live: Boolean = false,
    enabled: Boolean = true,
    snap: (Float) -> Float = { it },
) {
    var dragging by remember { mutableStateOf<Float?>(null) }
    var finished by remember { mutableStateOf(false) }
    // After the finger lifts the thumb stays where it was released until the engine reports the new value (or a moment
    // has passed), so it does not jump back for the length of one poll.
    LaunchedEffect(value) {
        if (finished) {
            dragging = null
            finished = false
        }
    }
    LaunchedEffect(finished) {
        if (finished) {
            delay(600)
            dragging = null
            finished = false
        }
    }
    val shown = (dragging ?: value).coerceIn(range.start, range.endInclusive)
    Column(modifier.fillMaxWidth()) {
        if (label.isNotEmpty()) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Txt(label, Modifier.weight(1f), color = if (enabled) Palette.text else Palette.muted)
                Txt(valueText(shown), color = Palette.muted, size = 12.sp)
            }
        }
        Slider(
            value = shown,
            onValueChange = {
                val v = snap(it)
                finished = false
                dragging = v
                if (live) onChange(v)
            },
            onValueChangeFinished = {
                val v = dragging
                if (v == null) {
                    finished = false
                } else {
                    if (!live) onChange(v)
                    finished = true
                }
            },
            valueRange = range,
            enabled = enabled,
        )
    }
}

@Composable
fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier, help: String = "", enabled: Boolean = true) {
    Row(modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Txt(label, color = if (enabled) Palette.text else Palette.muted)
            if (help.isNotEmpty()) Txt(help, color = Palette.muted, size = 11.sp, maxLines = 2)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Txt(text.uppercase(), modifier.padding(top = 14.dp, bottom = 6.dp), color = Palette.muted, size = 11.sp, weight = FontWeight.Medium)
}

/** Label on the left, content on the right (used for property rows). */
@Composable
fun PropertyRow(label: String, modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Txt(label, Modifier.width(84.dp), color = Palette.muted)
        content()
    }
}
