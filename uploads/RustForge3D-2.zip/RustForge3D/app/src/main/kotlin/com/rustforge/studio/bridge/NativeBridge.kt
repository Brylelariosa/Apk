package com.rustforge.studio.bridge

import android.view.Surface

/**
 * JNI entry points of `librustforge.so` (docs/PROTOCOL.md section 1). Any thread may call any function; the engine
 * serialises access itself. Prefer [EngineClient], which adds threading, polling and error handling on top.
 */
object NativeBridge {
    init {
        System.loadLibrary("rustforge")
    }

    @JvmStatic external fun nativeCreate(filesDir: String, density: Float): Long

    @JvmStatic external fun nativeDestroy(handle: Long)

    @JvmStatic external fun nativeSurfaceCreated(handle: Long, surface: Surface, width: Int, height: Int): Boolean

    @JvmStatic external fun nativeSurfaceChanged(handle: Long, width: Int, height: Int)

    @JvmStatic external fun nativeSurfaceDestroyed(handle: Long)

    @JvmStatic external fun nativeSetPaused(handle: Long, paused: Boolean)

    @JvmStatic external fun nativeTouch(
        handle: Long,
        action: Int,
        actionIndex: Int,
        timeMs: Long,
        count: Int,
        ids: IntArray,
        xs: FloatArray,
        ys: FloatArray,
        pressures: FloatArray,
        toolTypes: IntArray,
    )

    @JvmStatic external fun nativeCall(handle: Long, method: String, argsJson: String): String

    @JvmStatic external fun nativePoll(handle: Long): String?

    @JvmStatic external fun nativeImport(handle: Long, fileName: String, data: ByteArray): String

    @JvmStatic external fun nativeExport(handle: Long, format: String, optsJson: String): ByteArray?

    @JvmStatic external fun nativeSaveProject(handle: Long): ByteArray?

    @JvmStatic external fun nativeLoadProject(handle: Long, data: ByteArray): String

    @JvmStatic external fun nativeLastError(handle: Long): String

    @JvmStatic external fun nativeBackendName(handle: Long): String
}
