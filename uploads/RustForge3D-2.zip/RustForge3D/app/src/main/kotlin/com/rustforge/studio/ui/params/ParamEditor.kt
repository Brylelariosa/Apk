package com.rustforge.studio.ui.params

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.core.Json
import com.rustforge.studio.core.ParamDef
import com.rustforge.studio.core.ParamDefs
import com.rustforge.studio.core.ParamFormat
import com.rustforge.studio.core.ParamKind
import com.rustforge.studio.ui.common.DropdownField
import com.rustforge.studio.ui.common.EntryField
import com.rustforge.studio.ui.common.LiveSlider
import com.rustforge.studio.ui.common.PropertyRow
import com.rustforge.studio.ui.common.Segmented
import com.rustforge.studio.ui.common.ToggleRow
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.theme.Palette

/**
 * Generic editor for a list of [ParamDef]s (operator redo panel, modifiers). With [live] true every slider movement is
 * reported; otherwise values are reported when the finger lifts or a field is committed.
 */
@Composable
fun ParamEditor(
    params: List<ParamDef>,
    live: Boolean,
    onChange: (ParamDef, Json) -> Unit,
    modifier: Modifier = Modifier,
    objectNames: List<Pair<String, String>> = emptyList(),
    materialNames: List<Pair<String, String>> = emptyList(),
) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        for (def in params) {
            if (!def.isVisible(params)) continue
            when (def.kind) {
                ParamKind.BOOL -> ToggleRow(def.label, def.value.bool(), { onChange(def, Json.Bool(it)) }, help = def.help)
                ParamKind.FLOAT, ParamKind.INT -> NumberParam(def, live, onChange)
                ParamKind.ENUM -> PropertyRow(def.label) {
                    DropdownField(def.options, def.value.str(), { onChange(def, Json.Str(it)) }, Modifier.weight(1f))
                }
                ParamKind.VEC2 -> VectorParam(def, 2, onChange)
                ParamKind.VEC3, ParamKind.COLOR -> VectorParam(def, if (def.kind == ParamKind.COLOR && def.value.list.size >= 4) 4 else 3, onChange)
                ParamKind.BVEC3 -> PropertyRow(def.label) { BoolVector(def, onChange) }
                ParamKind.STRING -> PropertyRow(def.label) {
                    EntryField(def.value.str(), { onChange(def, Json.Str(it)); true }, Modifier.weight(1f), numeric = false)
                }
                ParamKind.OBJECT -> PropertyRow(def.label) {
                    DropdownField(objectNames, def.value.int().toString(), { onChange(def, Json.Num(it.toDouble())) }, Modifier.weight(1f))
                }
                ParamKind.MATERIAL -> PropertyRow(def.label) {
                    DropdownField(materialNames, def.value.int().toString(), { onChange(def, Json.Num(it.toDouble())) }, Modifier.weight(1f))
                }
                ParamKind.UNKNOWN -> PropertyRow(def.label) { Txt(def.value.toString(), color = Palette.muted) }
            }
        }
    }
}

@Composable
private fun NumberParam(def: ParamDef, live: Boolean, onChange: (ParamDef, Json) -> Unit) {
    val range = remember(def.name, def.min, def.max, def.softMax, def.unit) { def.sliderRange() }
    val isInt = def.kind == ParamKind.INT
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Txt(def.label, Modifier.weight(1f))
            EntryField(
                text = ParamFormat.number(def.number, def),
                onCommit = { text ->
                    val v = ParamFormat.parse(text, def)
                    if (v == null) {
                        false
                    } else {
                        onChange(def, Json.Num(v))
                        true
                    }
                },
                modifier = Modifier.width(112.dp),
                suffix = ParamFormat.unitSuffix(def.unit),
            )
        }
        LiveSlider(
            label = "",
            value = def.number.toFloat(),
            range = range.min..range.max,
            onChange = { onChange(def, Json.Num(def.clamp(it.toDouble()))) },
            valueText = { "" },
            live = live,
            snap = { if (isInt) Math.round(it).toFloat() else it },
        )
    }
}

@Composable
private fun VectorParam(def: ParamDef, count: Int, onChange: (ParamDef, Json) -> Unit) {
    val names = listOf("X", "Y", "Z", "W")
    Column(Modifier.fillMaxWidth()) {
        Txt(def.label, color = Palette.muted, size = 12.sp)
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (i in 0 until count) {
                EntryField(
                    text = ParamFormat.plain(def.value[i].double()),
                    onCommit = { text ->
                        val v = com.rustforge.studio.core.NumericExpr.evalOrNull(text, def.unit)
                        if (v == null) {
                            false
                        } else {
                            onChange(def, ParamDefs.withComponent(def, i, Json.Num(v)))
                            true
                        }
                    },
                    modifier = Modifier.weight(1f),
                    suffix = names[i],
                )
            }
        }
    }
}

@Composable
private fun BoolVector(def: ParamDef, onChange: (ParamDef, Json) -> Unit) {
    val names = listOf("X", "Y", "Z")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (i in 0 until 3) {
            val on = def.value[i].bool()
            Segmented(
                options = listOf("on" to names[i]),
                selected = if (on) "on" else "",
                onSelect = { onChange(def, ParamDefs.withComponent(def, i, Json.Bool(!on))) },
            )
        }
    }
}
