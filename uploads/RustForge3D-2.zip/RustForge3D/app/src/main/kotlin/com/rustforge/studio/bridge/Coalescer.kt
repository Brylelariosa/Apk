package com.rustforge.studio.bridge

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Runs only the newest of many rapidly submitted values: while one run is in progress, later submissions replace the
 * pending one. Used for live parameter editing, where only the final slider position matters.
 */
class Coalescer<T : Any>(private val scope: CoroutineScope, private val run: suspend (T) -> Unit) {
    private val lock = Any()
    private var pending: T? = null
    private var running = false

    fun submit(value: T) {
        synchronized(lock) {
            pending = value
            if (running) return
            running = true
        }
        scope.launch {
            while (true) {
                val next = synchronized(lock) {
                    val p = pending
                    pending = null
                    if (p == null) running = false
                    p
                } ?: break
                run(next)
            }
        }
    }
}
