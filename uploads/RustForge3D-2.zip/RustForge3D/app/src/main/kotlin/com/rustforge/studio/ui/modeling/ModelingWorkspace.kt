package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import com.rustforge.studio.bridge.EngineClient
import com.rustforge.studio.core.Tools
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.ui.rememberLayoutSpec
import com.rustforge.studio.ui.viewport.SurfaceErrorCard
import com.rustforge.studio.ui.viewport.ViewportHud
import com.rustforge.studio.ui.viewport.ViewportSurface

/**
 * The modeling screen. The viewport sits at one fixed place in the tree (inside the Row, between two conditional
 * siblings), so rotating the device or opening a panel only resizes the surface; it is never recreated.
 */
@Composable
fun ModelingWorkspace(vm: AppViewModel, client: EngineClient, modifier: Modifier = Modifier) {
    val state by vm.engine.collectAsState()
    val ui by vm.ui.collectAsState()
    val surfaceError by vm.surfaceError.collectAsState()
    val layout = rememberLayoutSpec()
    val screenHeightDp = LocalConfiguration.current.screenHeightDp
    val tools = Tools.forMode(state.mode)

    Column(modifier.fillMaxSize()) {
        Row(Modifier.weight(1f).fillMaxWidth()) {
            if (layout.railVertical) ToolRail(tools, state.tool, { vm.setTool(it) }, vertical = true)
            Box(Modifier.weight(1f).fillMaxHeight()) {
                ViewportSurface(client)
                ViewportHud(state)
                val error = surfaceError
                if (error != null) SurfaceErrorCard(error, Modifier.align(Alignment.Center))
                val overlayOpen = !layout.dock && ui.panelOpen
                val last = state.lastOp
                if (last != null && last.params.isNotEmpty() && !overlayOpen) {
                    RedoPanel(
                        last = last,
                        open = ui.redoPanelOpen,
                        maxBodyHeight = (screenHeightDp * 0.35f).dp,
                        onToggle = { vm.toggleRedoPanel() },
                        onChange = { def, value -> vm.redoParam(def, value) },
                        modifier = Modifier.align(Alignment.BottomStart).padding(8.dp),
                    )
                }
                if (overlayOpen) {
                    OverlayPanel(
                        state = state,
                        ui = ui,
                        vm = vm,
                        landscape = layout.landscape,
                        screenHeightDp = screenHeightDp,
                        modifier = Modifier.align(if (layout.landscape) Alignment.CenterEnd else Alignment.BottomCenter),
                    )
                }
            }
            if (layout.dock) DockPanel(state, ui, vm)
        }
        if (!layout.railVertical) ToolRail(tools, state.tool, { vm.setTool(it) }, vertical = false)
        BottomBar(state, vm)
    }
}
