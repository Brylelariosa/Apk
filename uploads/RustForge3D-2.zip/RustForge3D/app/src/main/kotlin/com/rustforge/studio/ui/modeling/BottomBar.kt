package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.Cmd
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.OperatorMenus
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.ui.common.LabelButton
import com.rustforge.studio.ui.common.MenuButton
import com.rustforge.studio.ui.common.MenuEntry
import com.rustforge.studio.ui.common.Rule
import com.rustforge.studio.ui.common.Segmented
import com.rustforge.studio.ui.common.ToolButton
import com.rustforge.studio.ui.theme.Palette

/** Mode switch, element mode, selection, add and operator menus. Scrolls sideways on narrow screens. */
@Composable
fun BottomBar(state: EngineState, vm: AppViewModel, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().background(Palette.panel).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Segmented(listOf("object" to "Object", "edit" to "Edit"), state.mode, { vm.setMode(it) })
        if (state.isEdit) {
            Separator()
            ToolButton("vertex-select", "Vertex select", { vm.setSelectMode("vertex") }, selected = state.selectMode == "vertex", tipAbove = true)
            ToolButton("edge-select", "Edge select", { vm.setSelectMode("edge") }, selected = state.selectMode == "edge", tipAbove = true)
            ToolButton("face-select", "Face select", { vm.setSelectMode("face") }, selected = state.selectMode == "face", tipAbove = true)
        }
        Separator()
        SelectMenu(state, vm)
        if (!state.isEdit) AddMenu(vm)
        OperatorMenu(state, vm)
    }
}

@Composable
private fun Separator() {
    Box(Modifier.width(1.dp).height(28.dp).background(Palette.outline))
}

@Composable
private fun SelectMenu(state: EngineState, vm: AppViewModel) {
    MenuButton(
        button = { open -> ToolButton("select-all", "Selection", open, tipAbove = true) },
        menu = { close ->
            MenuEntry("Select all", { close(); vm.select("all") }, icon = "select-all")
            MenuEntry("Select none", { close(); vm.select("none") }, icon = "close")
            MenuEntry("Invert selection", { close(); vm.select("invert") }, icon = "invert")
            if (state.isEdit) {
                Rule()
                MenuEntry("Grow selection", { close(); vm.select("more") }, icon = "add")
                MenuEntry("Shrink selection", { close(); vm.select("less") }, icon = "select")
                MenuEntry("Select linked", { close(); vm.select("linked") }, icon = "join")
            }
        },
    )
}

@Composable
private fun AddMenu(vm: AppViewModel) {
    MenuButton(
        button = { open -> LabelButton("Add", open, icon = "add", chevron = true, tipAbove = true, label = "Add object") },
        menu = { close ->
            for ((id, label, icon) in Cmd.primitives) {
                MenuEntry(label, { close(); vm.op(id) }, icon = icon)
            }
            Rule()
            for ((type, label) in Cmd.lights) {
                MenuEntry(label, { close(); vm.op("object.light_add", "type" to type) }, icon = "light")
            }
            MenuEntry("Empty", { close(); vm.op("object.empty_add") }, icon = "empty")
        },
    )
}

@Composable
private fun OperatorMenu(state: EngineState, vm: AppViewModel) {
    val items = if (state.isEdit) OperatorMenus.meshOps(state.selectMode) else OperatorMenus.object_
    MenuButton(
        button = { open ->
            LabelButton(if (state.isEdit) "Mesh" else "Object", open, icon = if (state.isEdit) "edit-mode" else "object-mode", chevron = true, tipAbove = true, label = "Operators")
        },
        menu = { close ->
            for (item in items) {
                MenuEntry(item.label, { close(); vm.runMenuOp(item) }, icon = item.icon)
            }
        },
    )
}
