package com.rustforge.studio.core

data class HelpSection(val title: String, val lines: List<String>)

/** Text of the help overlay: gestures and tools as they behave in this build. */
object HelpContent {
    val sections: List<HelpSection> = listOf(
        HelpSection(
            "Navigating",
            listOf(
                "Drag with one finger on empty space to orbit (Select and Navigate tools; change this in Settings).",
                "Drag with two fingers to pan. Pinch to zoom. These work in every tool.",
                "Double tap to focus the selection (or everything when nothing is selected).",
                "The view menu snaps to front, back, left, right, top and bottom and toggles perspective / orthographic.",
            ),
        ),
        HelpSection(
            "Selecting",
            listOf(
                "Select tool: tap an object to select it; tap empty space to deselect. Tap again to toggle in additive mode.",
                "Edit Mode: tap vertices, edges or faces according to the element mode (V / E / F buttons).",
                "Box Select tool, or a stylus drag: draws a selection rectangle. Selection boxes see through surfaces unless turned off in Settings.",
                "Select all / none / invert, grow and shrink, and linked selection are in the bottom bar.",
            ),
        ),
        HelpSection(
            "Transforming",
            listOf(
                "Move, Rotate and Scale show a gizmo at the selection. Drag an axis handle to constrain, a plane handle to move in a plane, the centre for free movement.",
                "Dragging a gizmo handle never moves the camera. Each drag is one undo step.",
                "Numeric transform (Properties > Object) types exact values; fields accept expressions like 2*1.5+0.25, 50cm or 45deg.",
                "Snapping (grid, angle, scale) is configured in Settings.",
            ),
        ),
        HelpSection(
            "Editing meshes",
            listOf(
                "Enter Edit Mode with the mode switch. Extrude, Inset and Loop Cut are in the tool rail while in Edit Mode.",
                "Extrude duplicates the selection and switches to Move so you can pull the new geometry out. Loop Cut: tap an edge.",
                "After an operator runs, the Adjust panel shows its parameters; changing them re-runs the operator from the original state.",
                "The Mesh menu has subdivide, delete, merge, dissolve, flip normals, shade smooth / flat and more.",
            ),
        ),
        HelpSection(
            "Objects, modifiers and materials",
            listOf(
                "Add primitives, lights and empties from the Add menu. The Scene panel lists objects: tap to select, use the eye and lock buttons, long-press for more.",
                "Properties > Modifiers adds Mirror and Subdivision Surface and edits their parameters live.",
                "Properties > Material creates and assigns materials and edits colour, metallic, roughness and emission.",
            ),
        ),
        HelpSection(
            "Undo and projects",
            listOf(
                "Undo and Redo are always in the top bar. Selection changes are not undo steps; edits are.",
                "Projects are saved as .rforge files with the system file picker. The last session is restored when the app starts.",
                "Mesh import / export (OBJ, STL, glTF) and Python scripting are not part of this build yet.",
            ),
        ),
    )
}
