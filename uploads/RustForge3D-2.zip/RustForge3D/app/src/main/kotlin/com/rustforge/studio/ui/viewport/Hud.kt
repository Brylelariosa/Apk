package com.rustforge.studio.ui.viewport

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.HudText
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.icons.AppIcon
import com.rustforge.studio.ui.theme.Palette

/**
 * Passive overlay on the viewport: nothing in here takes touches (no clickable, no Surface), so every touch reaches the
 * 3D view underneath.
 */
@Composable
fun ViewportHud(state: EngineState, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().padding(8.dp)) {
        Column(Modifier.align(Alignment.TopStart), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            HudChip(HudText.viewLabel(state.camera))
            HudChip(HudText.selectionSummary(state), color = Palette.muted)
        }
        if (state.view.stats) {
            Column(Modifier.align(Alignment.TopEnd), verticalArrangement = Arrangement.spacedBy(2.dp), horizontalAlignment = Alignment.End) {
                for (line in HudText.statsLines(state.stats)) HudChip(line, color = Palette.muted)
            }
        }
        val tool = HudText.toolLine(state.toolState)
        if (tool != null) HudChip(tool, Modifier.align(Alignment.BottomCenter).padding(bottom = 8.dp))
    }
}

@Composable
fun HudChip(text: String, modifier: Modifier = Modifier, color: Color = Palette.text) {
    Box(modifier.clip(RoundedCornerShape(6.dp)).background(Palette.hud).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Txt(text, color = color, size = 12.sp)
    }
}

/** Shown in the middle of the viewport when the GPU surface could not be set up. */
@Composable
fun SurfaceErrorCard(message: String, modifier: Modifier = Modifier) {
    Box(modifier.padding(24.dp).widthIn(max = 420.dp).clip(RoundedCornerShape(12.dp)).background(Palette.panel).padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AppIcon("warning", tint = Palette.warning, size = 24.dp)
            Column(Modifier.weight(1f)) {
                Txt("The 3D view is not available", weight = FontWeight.Medium, size = 15.sp, maxLines = 2)
                Txt(message, color = Palette.muted, maxLines = 8)
            }
        }
    }
}
