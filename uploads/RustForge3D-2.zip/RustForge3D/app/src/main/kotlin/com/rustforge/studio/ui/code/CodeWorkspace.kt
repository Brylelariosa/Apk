package com.rustforge.studio.ui.code

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.ui.common.LabelButton
import com.rustforge.studio.ui.icons.AppIcon
import com.rustforge.studio.ui.theme.Palette

/**
 * Honest placeholder: the Python (bpy-style) scripting workspace needs a real interpreter inside the app, which this
 * build does not contain. Nothing here pretends to run code.
 */
@Composable
fun CodeWorkspace(onBack: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().background(Palette.bg), contentAlignment = Alignment.Center) {
        Column(
            Modifier.padding(24.dp).widthIn(max = 480.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AppIcon("code", tint = Palette.accent, size = 40.dp)
            Text("Python scripting is not in this build yet", color = Palette.text, fontSize = 18.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
            Text(
                "The code workspace (editor, console, Run / Stop / Preview and a Blender-style Python API) needs a real Python " +
                    "interpreter running inside the app. It is planned for a later release and is not simulated here. " +
                    "Modeling, modifiers, materials and projects work fully without it.",
                color = Palette.muted,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
            )
            LabelButton("Back to modeling", onBack, icon = "cube", primary = true)
        }
    }
}
