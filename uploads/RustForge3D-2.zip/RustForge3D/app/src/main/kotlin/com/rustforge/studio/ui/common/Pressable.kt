package com.rustforge.studio.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.disabled
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntRect
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupPositionProvider
import com.rustforge.studio.ui.theme.Palette
import kotlinx.coroutines.delay

/**
 * Touch target with press feedback, accessibility semantics and a long-press tooltip showing [label]
 * (every toolbar button uses it, so every button explains itself). A custom [onLongPress] replaces the tooltip.
 */
@Composable
fun Pressable(
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    label: String? = null,
    tipAbove: Boolean = false,
    onLongPress: (() -> Unit)? = null,
    shape: Shape = RoundedCornerShape(10.dp),
    background: Color = Color.Transparent,
    pressedBackground: Color = Palette.pressed,
    content: @Composable BoxScope.() -> Unit,
) {
    var pressed by remember { mutableStateOf(false) }
    var showTip by remember { mutableStateOf(false) }
    val currentTap by rememberUpdatedState(onTap)
    val currentLong by rememberUpdatedState(onLongPress)
    Box(
        modifier = modifier
            .clip(shape)
            .background(if (pressed && enabled) pressedBackground else background)
            .semantics(mergeDescendants = true) {
                if (label != null) contentDescription = label
                role = Role.Button
                if (enabled) {
                    onClick {
                        currentTap()
                        true
                    }
                } else {
                    disabled()
                }
            }
            .pointerInput(enabled) {
                if (enabled) {
                    detectTapGestures(
                        onPress = {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        },
                        onLongPress = {
                            val custom = currentLong
                            if (custom != null) custom() else if (label != null) showTip = true
                        },
                        onTap = { currentTap() },
                    )
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        content()
        if (showTip && label != null) Tooltip(label, tipAbove) { showTip = false }
    }
}

/** Small text bubble next to the anchor, dismissed after a moment or by tapping elsewhere. */
@Composable
fun Tooltip(text: String, above: Boolean, onDismiss: () -> Unit) {
    val provider = remember(above) {
        object : PopupPositionProvider {
            override fun calculatePosition(anchorBounds: IntRect, windowSize: IntSize, layoutDirection: LayoutDirection, popupContentSize: IntSize): IntOffset {
                val x = (anchorBounds.center.x - popupContentSize.width / 2).coerceIn(0, maxOf(0, windowSize.width - popupContentSize.width))
                val gap = 8
                val y = if (above) anchorBounds.top - popupContentSize.height - gap else anchorBounds.bottom + gap
                return IntOffset(x, y.coerceIn(0, maxOf(0, windowSize.height - popupContentSize.height)))
            }
        }
    }
    LaunchedEffect(text) {
        delay(1600)
        onDismiss()
    }
    Popup(popupPositionProvider = provider, onDismissRequest = onDismiss) {
        Box(
            Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(Palette.panelRaised)
                .padding(horizontal = 10.dp, vertical = 6.dp),
        ) {
            Text(text, color = Palette.text, fontSize = 12.sp)
        }
    }
}

/** Stops touches inside a panel from reaching the 3D viewport underneath it. */
fun Modifier.blockTouches(): Modifier = this.pointerInput(Unit) { detectTapGestures { } }
