package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.LayoutRules
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.state.PanelTab
import com.rustforge.studio.state.UiState
import com.rustforge.studio.ui.common.Pressable
import com.rustforge.studio.ui.common.Rule
import com.rustforge.studio.ui.common.ToolButton
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.common.blockTouches
import com.rustforge.studio.ui.icons.AppIcon
import com.rustforge.studio.ui.theme.Palette

/** Tab strip and the content of the selected tab. Used by the dock and the overlay panels. */
@Composable
fun PanelBody(state: EngineState, ui: UiState, vm: AppViewModel, modifier: Modifier = Modifier) {
    Column(modifier) {
        PanelTabs(ui.panelTab) { vm.selectTab(it) }
        Rule()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (ui.panelTab) {
                PanelTab.SCENE -> SceneTab(state, ui, vm)
                PanelTab.OBJECT -> Scrolling { ObjectTab(state, vm) }
                PanelTab.MODIFIERS -> Scrolling { ModifiersTab(state, vm) }
                PanelTab.MATERIAL -> Scrolling { MaterialTab(state, vm) }
                PanelTab.INFO -> Scrolling { InfoTab(state) }
            }
        }
    }
}

@Composable
private fun Scrolling(content: @Composable () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        content()
    }
}

@Composable
private fun PanelTabs(selected: PanelTab, onSelect: (PanelTab) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        for (tab in PanelTab.values()) {
            val on = tab == selected
            val color = if (on) Palette.accent else Palette.muted
            Pressable(
                onTap = { onSelect(tab) },
                modifier = Modifier.weight(1f).height(54.dp),
                label = tab.label,
                background = if (on) Palette.accentDim else Color.Transparent,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    AppIcon(tab.icon, tint = color, size = 20.dp)
                    Txt(tab.label, color = color, size = 10.sp)
                }
            }
        }
    }
}

/** Permanent properties dock at the right edge (wide windows). */
@Composable
fun DockPanel(state: EngineState, ui: UiState, vm: AppViewModel, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxHeight().width(LayoutRules.DOCK_WIDTH_DP.dp)) {
        Box(Modifier.width(1.dp).fillMaxHeight().background(Palette.outline))
        PanelBody(state, ui, vm, Modifier.weight(1f).fillMaxHeight().background(Palette.panel))
    }
}

/**
 * Properties as an overlay on the viewport: a sheet from the bottom in portrait, a card at the right edge in landscape.
 * It swallows touches so nothing reaches the 3D view underneath.
 */
@Composable
fun OverlayPanel(state: EngineState, ui: UiState, vm: AppViewModel, landscape: Boolean, screenHeightDp: Int, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(16.dp)
    val sized = if (landscape) {
        modifier.fillMaxHeight().width(340.dp).padding(8.dp)
    } else {
        modifier.fillMaxWidth().height((screenHeightDp * 0.55f).dp)
    }
    Column(sized.clip(shape).background(Palette.panel).blockTouches()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Txt("Properties", Modifier.weight(1f), size = 15.sp)
            ToolButton("close", "Close", { vm.closePanel() })
        }
        PanelBody(state, ui, vm, Modifier.weight(1f).fillMaxWidth())
    }
}
