package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.ModifierInfo
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.ui.common.LabelButton
import com.rustforge.studio.ui.common.MenuButton
import com.rustforge.studio.ui.common.MenuEntry
import com.rustforge.studio.ui.common.ToolButton
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.params.ParamEditor
import com.rustforge.studio.ui.theme.Palette

/** Add, edit, reorder, apply and remove the active mesh's modifiers. */
@Composable
fun ModifiersTab(state: EngineState, vm: AppViewModel, modifier: Modifier = Modifier) {
    val obj = state.active
    if (obj == null || !obj.kind.equals("mesh", ignoreCase = true)) {
        EmptyNote("Select a mesh object to add modifiers.", modifier)
        return
    }
    PanelColumn(modifier) {
        MenuButton(
            modifier = Modifier.padding(vertical = 4.dp),
            button = { open -> LabelButton("Add modifier", open, icon = "add", chevron = true) },
            menu = { close ->
                MenuEntry("Mirror", { close(); vm.addModifier("MIRROR") }, icon = "mirror")
                MenuEntry("Subdivision Surface", { close(); vm.addModifier("SUBSURF") }, icon = "subdivide")
            },
        )
        if (obj.modifiers.isEmpty()) EmptyNote("This object has no modifiers.", Modifier.padding(0.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (m in obj.modifiers) ModifierCard(obj.id, m, obj.modifiers.size, vm)
        }
    }
}

@Composable
private fun ModifierCard(objectId: Int, m: ModifierInfo, count: Int, vm: AppViewModel) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Palette.panelRaised).padding(start = 12.dp, end = 12.dp, bottom = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Txt(m.name, Modifier.weight(1f), weight = FontWeight.Medium)
            ToolButton(
                if (m.showViewport) "eye" else "eye-off",
                if (m.showViewport) "Hide in viewport" else "Show in viewport",
                { vm.call("modifier.set", "object" to objectId, "index" to m.index, "show_viewport" to !m.showViewport) },
                size = 44.dp,
                iconSize = 20.dp,
            )
            MenuButton(
                button = { open -> ToolButton("more", "Modifier actions", open, size = 44.dp, iconSize = 20.dp) },
                menu = { close ->
                    MenuEntry("Move up", { close(); vm.call("modifier.move", "object" to objectId, "index" to m.index, "to" to m.index - 1) }, icon = "chevron-up", enabled = m.index > 0)
                    MenuEntry("Move down", { close(); vm.call("modifier.move", "object" to objectId, "index" to m.index, "to" to m.index + 1) }, icon = "chevron-down", enabled = m.index < count - 1)
                    MenuEntry("Apply", { close(); vm.applyModifier(m.index) }, icon = "check")
                    MenuEntry("Remove", { close(); vm.removeModifier(m.index) }, icon = "delete")
                },
            )
        }
        ParamEditor(m.params, live = false, onChange = { def, value -> vm.setModifierParam(objectId, m.index, def, value) })
    }
}
