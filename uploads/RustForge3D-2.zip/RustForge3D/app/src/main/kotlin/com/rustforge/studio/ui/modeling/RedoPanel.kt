package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.Json
import com.rustforge.studio.core.LastOp
import com.rustforge.studio.core.ParamDef
import com.rustforge.studio.ui.common.Pressable
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.common.blockTouches
import com.rustforge.studio.ui.icons.AppIcon
import com.rustforge.studio.ui.params.ParamEditor
import com.rustforge.studio.ui.theme.Palette

/** "Adjust last operation": the parameters of the operator that just ran, applied live. */
@Composable
fun RedoPanel(
    last: LastOp,
    open: Boolean,
    maxBodyHeight: Dp,
    onToggle: () -> Unit,
    onChange: (ParamDef, Json) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(12.dp)).background(Palette.panel).blockTouches()) {
        Pressable(onTap = onToggle, modifier = Modifier.fillMaxWidth().height(44.dp), label = if (open) "Collapse" else "Adjust ${last.label}") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Txt("Adjust: ${last.label}", Modifier.weight(1f))
                AppIcon(if (open) "chevron-down" else "chevron-up", tint = Palette.muted, size = 18.dp)
            }
        }
        if (open) {
            Column(Modifier.heightIn(max = maxBodyHeight).verticalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, bottom = 8.dp)) {
                ParamEditor(last.params, live = true, onChange = onChange)
            }
        }
    }
}
