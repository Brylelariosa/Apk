package com.rustforge.studio.ui.modeling

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.MaterialInfo
import com.rustforge.studio.core.ParamFormat
import com.rustforge.studio.state.AppViewModel
import com.rustforge.studio.ui.common.DropdownField
import com.rustforge.studio.ui.common.EntryField
import com.rustforge.studio.ui.common.LabelButton
import com.rustforge.studio.ui.common.LiveSlider
import com.rustforge.studio.ui.common.PropertyRow
import com.rustforge.studio.ui.common.SectionTitle
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.params.ColorPicker
import com.rustforge.studio.ui.theme.Palette

/** Material slots of the active mesh, assignment and the properties of the material in the chosen slot. */
@Composable
fun MaterialTab(state: EngineState, vm: AppViewModel, modifier: Modifier = Modifier) {
    val obj = state.active
    if (obj == null || !obj.kind.equals("mesh", ignoreCase = true)) {
        EmptyNote("Select a mesh object to edit its materials.", modifier)
        return
    }
    var chosen by remember(obj.id) { mutableStateOf(0) }
    val position = if (obj.slots.isEmpty()) 0 else chosen.coerceIn(0, obj.slots.lastIndex)
    val slot = obj.slots.getOrNull(position)

    PanelColumn(modifier) {
        SectionTitle("Slots")
        if (slot == null) {
            Txt("This object has no material slots.", color = Palette.muted, maxLines = 2)
        } else {
            DropdownField(
                options = obj.slots.mapIndexed { i, s -> i.toString() to "${i + 1}. ${s.name}" },
                selected = position.toString(),
                onSelect = { chosen = it.toIntOrNull() ?: 0 },
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            LabelButton("Add slot", { vm.call("material.slot_add", "object" to obj.id) }, icon = "add")
            if (slot != null) {
                LabelButton("Remove slot", { vm.call("material.slot_remove", "object" to obj.id, "slot" to slot.slot) }, icon = "delete")
            }
        }
        if (slot != null) {
            SectionTitle("Material")
            val assignable = state.materials.map { it.id.toString() to it.name }
            if (assignable.isNotEmpty()) {
                PropertyRow("Assigned") {
                    DropdownField(assignable, slot.material.toString(), { vm.assignMaterial(obj.id, it.toIntOrNull() ?: 0, slot.slot) }, Modifier.weight(1f))
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                LabelButton("New material", { vm.createMaterialForActive(slot.slot) }, icon = "add")
                if (state.isEdit) {
                    LabelButton(
                        "Assign to selection",
                        { vm.call("material.assign", "object" to obj.id, "material" to slot.material, "slot" to slot.slot, "selection" to true) },
                        icon = "face-select",
                    )
                }
            }
            val material = state.materials.firstOrNull { it.id == slot.material }
            if (material != null) MaterialEditor(material, vm)
        }
    }
}

@Composable
private fun MaterialEditor(m: MaterialInfo, vm: AppViewModel) {
    val alpha = m.baseColor.getOrElse(3) { 1f }
    SectionTitle("Surface")
    PropertyRow("Name") {
        EntryField(
            text = m.name,
            onCommit = { text ->
                if (text.isBlank()) {
                    false
                } else {
                    vm.setMaterial(m.id, "name" to text.trim())
                    true
                }
            },
            modifier = Modifier.weight(1f),
            numeric = false,
        )
    }
    Txt("Base color", color = Palette.muted, modifier = Modifier.padding(top = 4.dp))
    ColorPicker(
        linear = m.baseColor,
        onCommit = { c -> vm.setMaterial(m.id, "base_color" to listOf(c[0], c[1], c[2], alpha)) },
    )
    LiveSlider("Metallic", m.metallic, 0f..1f, { vm.setMaterial(m.id, "metallic" to it) }, { ParamFormat.plain(it.toDouble(), 2) })
    LiveSlider("Roughness", m.roughness, 0f..1f, { vm.setMaterial(m.id, "roughness" to it) }, { ParamFormat.plain(it.toDouble(), 2) })
    LiveSlider("Alpha", alpha, 0f..1f, { vm.setMaterial(m.id, "alpha" to it) }, { ParamFormat.plain(it.toDouble(), 2) })
    SectionTitle("Emission")
    ColorPicker(
        linear = listOf(m.emission.x, m.emission.y, m.emission.z),
        onCommit = { c -> vm.setMaterial(m.id, "emission" to c) },
    )
    LiveSlider("Strength", m.emissionStrength, 0f..10f, { vm.setMaterial(m.id, "emission_strength" to it) }, { ParamFormat.plain(it.toDouble(), 2) })
    if (m.users > 1) Txt("Shared by ${m.users} users", color = Palette.muted, modifier = Modifier.padding(top = 4.dp))
}
