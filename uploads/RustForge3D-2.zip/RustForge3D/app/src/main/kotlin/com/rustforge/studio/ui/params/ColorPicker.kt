package com.rustforge.studio.ui.params

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.core.ColorMath
import com.rustforge.studio.core.Rgb
import com.rustforge.studio.ui.common.EntryField
import com.rustforge.studio.ui.common.Txt
import com.rustforge.studio.ui.theme.Palette
import java.util.Locale

/**
 * Hue / saturation / value sliders plus a hex field. Colours of the engine are linear; the picker shows sRGB.
 * Dragging only previews; [onCommit] receives the linear r, g, b once the finger lifts or a hex value is entered.
 */
@Composable
fun ColorPicker(linear: List<Float>, onCommit: (List<Float>) -> Unit, modifier: Modifier = Modifier) {
    val r = linear.getOrElse(0) { 0.8f }
    val g = linear.getOrElse(1) { 0.8f }
    val b = linear.getOrElse(2) { 0.8f }
    var hsv by remember(r, g, b) { mutableStateOf(ColorMath.rgbToHsv(ColorMath.toSrgb(Rgb(r, g, b)))) }
    val shown = ColorMath.hsvToRgb(hsv)

    fun commitHsv() {
        val lin = ColorMath.toLinear(ColorMath.hsvToRgb(hsv))
        onCommit(listOf(lin.r, lin.g, lin.b))
    }

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val shape = RoundedCornerShape(8.dp)
            Box(
                Modifier
                    .size(40.dp)
                    .clip(shape)
                    .background(Color(shown.r.coerceIn(0f, 1f), shown.g.coerceIn(0f, 1f), shown.b.coerceIn(0f, 1f)))
                    .border(1.dp, Palette.outline, shape),
            )
            EntryField(
                text = ColorMath.toHex(shown),
                onCommit = { text ->
                    val parsed = ColorMath.parseHex(text)
                    if (parsed == null) {
                        false
                    } else {
                        val lin = ColorMath.toLinear(parsed)
                        onCommit(listOf(lin.r, lin.g, lin.b))
                        true
                    }
                },
                modifier = Modifier.weight(1f),
                numeric = false,
                alignEnd = false,
            )
        }
        HsvSlider("H", hsv.h, 0f..360f, String.format(Locale.ROOT, "%.0f", hsv.h), { hsv = hsv.copy(h = it) }, { commitHsv() })
        HsvSlider("S", hsv.s, 0f..1f, String.format(Locale.ROOT, "%.2f", hsv.s), { hsv = hsv.copy(s = it) }, { commitHsv() })
        HsvSlider("V", hsv.v, 0f..1f, String.format(Locale.ROOT, "%.2f", hsv.v), { hsv = hsv.copy(v = it) }, { commitHsv() })
    }
}

@Composable
private fun HsvSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    text: String,
    onChange: (Float) -> Unit,
    onDone: () -> Unit,
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Txt(label, Modifier.width(20.dp), color = Palette.muted)
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            onValueChangeFinished = onDone,
            valueRange = range,
            modifier = Modifier.weight(1f),
        )
        Txt(text, Modifier.width(40.dp), color = Palette.muted, size = 12.sp)
    }
}
