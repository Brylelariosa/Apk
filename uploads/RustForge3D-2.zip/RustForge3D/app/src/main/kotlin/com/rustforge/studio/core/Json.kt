package com.rustforge.studio.core

/**
 * Small immutable JSON model with forgiving typed accessors: reading a missing or mistyped member yields the given
 * default instead of throwing, so the app tolerates engine versions that add or drop fields.
 */
sealed class Json {
    object Null : Json()
    data class Bool(val value: Boolean) : Json()
    data class Num(val value: Double) : Json()
    data class Str(val value: String) : Json()
    data class Arr(val items: List<Json>) : Json()
    data class Obj(val fields: Map<String, Json>) : Json()

    // ---- navigation -------------------------------------------------------------------------------------------

    /** Member of an object; [Null] when this is not an object or the key is missing. */
    operator fun get(key: String): Json = (this as? Obj)?.fields?.get(key) ?: Null

    /** Element of an array; [Null] when this is not an array or the index is out of range. */
    operator fun get(index: Int): Json = (this as? Arr)?.items?.getOrNull(index) ?: Null

    /** Follows a dotted path such as `viewport.quality`. */
    fun path(dotted: String): Json {
        var cur: Json = this
        for (part in dotted.split('.')) cur = cur[part]
        return cur
    }

    val isNull: Boolean get() = this === Null
    fun has(key: String): Boolean = (this as? Obj)?.fields?.containsKey(key) == true

    /** The elements of an array (empty for anything else). */
    val list: List<Json> get() = (this as? Arr)?.items ?: emptyList()

    /** The members of an object (empty for anything else). */
    val map: Map<String, Json> get() = (this as? Obj)?.fields ?: emptyMap()

    // ---- typed reads ------------------------------------------------------------------------------------------

    fun str(default: String = ""): String = (this as? Str)?.value ?: default
    fun double(default: Double = 0.0): Double = when (this) {
        is Num -> value
        is Bool -> if (value) 1.0 else 0.0
        else -> default
    }
    fun float(default: Float = 0f): Float = if (this is Num || this is Bool) double().toFloat() else default
    fun int(default: Int = 0): Int = if (this is Num) value.toInt() else if (this is Bool) (if (value) 1 else 0) else default
    fun long(default: Long = 0L): Long = if (this is Num) value.toLong() else default
    fun bool(default: Boolean = false): Boolean = when (this) {
        is Bool -> value
        is Num -> value != 0.0
        else -> default
    }

    /** Array of numbers as floats; non-numeric entries read as 0. */
    fun floats(): List<Float> = list.map { it.float() }
    fun strings(): List<String> = list.mapNotNull { (it as? Str)?.value }

    final override fun toString(): String = JsonWriter.write(this)

    companion object {
        /** Parses [text]; throws [JsonException] with a precise position on malformed input. */
        fun parse(text: String): Json = JsonParser(text).parseDocument()

        fun parseOrNull(text: String?): Json? {
            if (text == null) return null
            return try {
                parse(text)
            } catch (e: JsonException) {
                null
            }
        }
    }
}

class JsonException(message: String, val offset: Int) : Exception(message)

// ---- builders -----------------------------------------------------------------------------------------------------

/** Converts plain Kotlin values (numbers, strings, lists, maps, arrays, [Json]) into [Json]. */
fun toJson(value: Any?): Json = when (value) {
    null -> Json.Null
    is Json -> value
    is Boolean -> Json.Bool(value)
    is Float -> if (value.isFinite()) Json.Num(value.toString().toDouble()) else Json.Null
    is Number -> Json.Num(value.toDouble())
    is CharSequence -> Json.Str(value.toString())
    is Enum<*> -> Json.Str(value.name)
    is Map<*, *> -> Json.Obj(LinkedHashMap<String, Json>().also { m -> for ((k, v) in value) m[k.toString()] = toJson(v) })
    is Iterable<*> -> Json.Arr(value.map { toJson(it) })
    is FloatArray -> Json.Arr(value.map { toJson(it) })
    is DoubleArray -> Json.Arr(value.map { Json.Num(it) })
    is IntArray -> Json.Arr(value.map { Json.Num(it.toDouble()) })
    is BooleanArray -> Json.Arr(value.map { Json.Bool(it) })
    is Array<*> -> Json.Arr(value.map { toJson(it) })
    else -> Json.Str(value.toString())
}

fun jsonOf(vararg pairs: Pair<String, Any?>): Json.Obj {
    val m = LinkedHashMap<String, Json>()
    for ((k, v) in pairs) m[k] = toJson(v)
    return Json.Obj(m)
}

fun jsonArrayOf(vararg values: Any?): Json.Arr = Json.Arr(values.map { toJson(it) })

/** The object with [patch] members replacing or adding to this one's. */
fun Json.merged(patch: Json): Json {
    if (this !is Json.Obj || patch !is Json.Obj) return patch
    val m = LinkedHashMap(fields)
    m.putAll(patch.fields)
    return Json.Obj(m)
}

// ---- writer -------------------------------------------------------------------------------------------------------

object JsonWriter {
    fun write(v: Json): String {
        val sb = StringBuilder()
        write(v, sb)
        return sb.toString()
    }

    fun formatNumber(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "null"
        if (d == Math.floor(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        return d.toString()
    }

    private fun write(v: Json, sb: StringBuilder) {
        when (v) {
            is Json.Null -> sb.append("null")
            is Json.Bool -> sb.append(if (v.value) "true" else "false")
            is Json.Num -> sb.append(formatNumber(v.value))
            is Json.Str -> quote(v.value, sb)
            is Json.Arr -> {
                sb.append('[')
                v.items.forEachIndexed { i, e ->
                    if (i > 0) sb.append(',')
                    write(e, sb)
                }
                sb.append(']')
            }
            is Json.Obj -> {
                sb.append('{')
                var first = true
                for ((k, e) in v.fields) {
                    if (!first) sb.append(',')
                    first = false
                    quote(k, sb)
                    sb.append(':')
                    write(e, sb)
                }
                sb.append('}')
            }
        }
    }

    private fun quote(s: String, sb: StringBuilder) {
        sb.append('"')
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c == '\b' -> sb.append("\\b")
                c == '\u000C' -> sb.append("\\f")
                c < ' ' || c == '\u2028' || c == '\u2029' -> {
                    sb.append("\\u")
                    sb.append(String.format("%04x", c.code))
                }
                else -> sb.append(c)
            }
        }
        sb.append('"')
    }
}

// ---- parser -------------------------------------------------------------------------------------------------------

/** Strict RFC 8259 parser (recursive descent, nesting limited so hostile input cannot overflow the stack). */
class JsonParser(private val s: String) {
    private var i = 0

    fun parseDocument(): Json {
        skipWs()
        val v = value(0)
        skipWs()
        if (i < s.length) fail("Unexpected trailing characters")
        return v
    }

    private fun fail(what: String, at: Int = i): Nothing {
        var line = 1
        var col = 1
        val end = minOf(at, s.length)
        for (k in 0 until end) {
            if (s[k] == '\n') {
                line++
                col = 1
            } else {
                col++
            }
        }
        throw JsonException("$what at line $line, column $col", at)
    }

    private fun skipWs() {
        while (i < s.length) {
            val c = s[i]
            if (c == ' ' || c == '\n' || c == '\r' || c == '\t') i++ else break
        }
    }

    private fun value(depth: Int): Json {
        if (depth > MAX_DEPTH) fail("Nesting is too deep")
        if (i >= s.length) fail("Unexpected end of input")
        return when (val c = s[i]) {
            '{' -> obj(depth)
            '[' -> arr(depth)
            '"' -> Json.Str(string())
            't' -> literal("true", Json.Bool(true))
            'f' -> literal("false", Json.Bool(false))
            'n' -> literal("null", Json.Null)
            else -> if (c == '-' || c in '0'..'9') number() else fail("Unexpected character '$c'")
        }
    }

    private fun literal(word: String, v: Json): Json {
        if (!s.startsWith(word, i)) fail("Invalid literal")
        i += word.length
        return v
    }

    private fun obj(depth: Int): Json {
        i++ // {
        val m = LinkedHashMap<String, Json>()
        skipWs()
        if (i < s.length && s[i] == '}') {
            i++
            return Json.Obj(m)
        }
        while (true) {
            skipWs()
            if (i >= s.length) fail("Unterminated object")
            if (s[i] != '"') fail("Expected a string key")
            val k = string()
            skipWs()
            if (i >= s.length || s[i] != ':') fail("Expected ':'")
            i++
            skipWs()
            m[k] = value(depth + 1)
            skipWs()
            if (i >= s.length) fail("Unterminated object")
            when (s[i]) {
                ',' -> i++
                '}' -> {
                    i++
                    return Json.Obj(m)
                }
                else -> fail("Expected ',' or '}'")
            }
        }
    }

    private fun arr(depth: Int): Json {
        i++ // [
        val a = ArrayList<Json>()
        skipWs()
        if (i < s.length && s[i] == ']') {
            i++
            return Json.Arr(a)
        }
        while (true) {
            skipWs()
            a.add(value(depth + 1))
            skipWs()
            if (i >= s.length) fail("Unterminated array")
            when (s[i]) {
                ',' -> i++
                ']' -> {
                    i++
                    return Json.Arr(a)
                }
                else -> fail("Expected ',' or ']'")
            }
        }
    }

    private fun string(): String {
        val start = i
        i++ // opening quote
        var sb: StringBuilder? = null
        var chunk = i
        while (true) {
            if (i >= s.length) fail("Unterminated string", start)
            val c = s[i]
            if (c == '"') {
                val out = if (sb == null) s.substring(chunk, i) else sb.append(s, chunk, i).toString()
                i++
                return out
            }
            if (c < ' ') fail("Control character in string")
            if (c == '\\') {
                val b = sb ?: StringBuilder().also { sb = it }
                b.append(s, chunk, i)
                i++
                if (i >= s.length) fail("Unterminated escape")
                when (val e = s[i]) {
                    '"' -> b.append('"')
                    '\\' -> b.append('\\')
                    '/' -> b.append('/')
                    'b' -> b.append('\b')
                    'f' -> b.append('\u000C')
                    'n' -> b.append('\n')
                    'r' -> b.append('\r')
                    't' -> b.append('\t')
                    'u' -> {
                        if (i + 4 >= s.length) fail("Truncated \\u escape")
                        var code = 0
                        for (k in 1..4) {
                            val d = Character.digit(s[i + k], 16)
                            if (d < 0) fail("Invalid \\u escape", i + k)
                            code = code * 16 + d
                        }
                        b.append(code.toChar())
                        i += 4
                    }
                    else -> fail("Invalid escape '\\$e'")
                }
                i++
                chunk = i
            } else {
                i++
            }
        }
    }

    private fun number(): Json {
        val start = i
        if (s[i] == '-') i++
        if (i >= s.length) fail("Incomplete number", start)
        if (s[i] == '0') {
            i++
            if (i < s.length && s[i] in '0'..'9') fail("Leading zeros are not allowed", start)
        } else if (s[i] in '1'..'9') {
            while (i < s.length && s[i] in '0'..'9') i++
        } else {
            fail("Invalid number", start)
        }
        if (i < s.length && s[i] == '.') {
            i++
            if (i >= s.length || s[i] !in '0'..'9') fail("Digits expected after '.'")
            while (i < s.length && s[i] in '0'..'9') i++
        }
        if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
            i++
            if (i < s.length && (s[i] == '+' || s[i] == '-')) i++
            if (i >= s.length || s[i] !in '0'..'9') fail("Digits expected in exponent")
            while (i < s.length && s[i] in '0'..'9') i++
        }
        return Json.Num(s.substring(start, i).toDouble())
    }

    companion object {
        const val MAX_DEPTH = 256
    }
}
