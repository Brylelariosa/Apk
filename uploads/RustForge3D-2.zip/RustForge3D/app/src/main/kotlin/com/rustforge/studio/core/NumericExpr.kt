package com.rustforge.studio.core

import kotlin.math.PI
import kotlin.math.pow

/** Outcome of evaluating a numeric field entry: exactly one of [value] and [error] is set. */
class NumericResult(val value: Double?, val error: String?)

/**
 * Evaluates what the user types into numeric fields: `2*1.5+0.25`, `(1+2)^2`, `-3`, `1e-3`, `pi`, with unit
 * suffixes depending on the field: length `m cm mm km in ft` (result in metres) and angle `deg ° rad` (result in degrees).
 */
object NumericExpr {
    fun eval(text: String, unit: ParamUnit = ParamUnit.NONE): NumericResult {
        if (text.isBlank()) return NumericResult(null, "Enter a number")
        return try {
            val p = Parser(text, unit)
            val v = p.parseAll()
            if (v.isNaN() || v.isInfinite()) NumericResult(null, "The result is not a finite number") else NumericResult(v, null)
        } catch (e: ExprError) {
            NumericResult(null, e.message ?: "Invalid expression")
        }
    }

    fun evalOrNull(text: String, unit: ParamUnit = ParamUnit.NONE): Double? = eval(text, unit).value

    private class ExprError(message: String) : Exception(message)

    private class Parser(private val s: String, private val unit: ParamUnit) {
        private var i = 0

        fun parseAll(): Double {
            val v = expr()
            skipWs()
            if (i < s.length) throw ExprError("Unexpected '${s[i]}'")
            return v
        }

        private fun skipWs() {
            while (i < s.length && s[i].isWhitespace()) i++
        }

        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        private fun expr(): Double {
            var v = term()
            while (true) {
                skipWs()
                when (peek()) {
                    '+' -> {
                        i++
                        v += term()
                    }
                    '-' -> {
                        i++
                        v -= term()
                    }
                    else -> return v
                }
            }
        }

        private fun term(): Double {
            var v = unary()
            while (true) {
                skipWs()
                when (peek()) {
                    '*' -> {
                        i++
                        v *= unary()
                    }
                    '/' -> {
                        i++
                        val d = unary()
                        if (d == 0.0) throw ExprError("Division by zero")
                        v /= d
                    }
                    else -> return v
                }
            }
        }

        private fun unary(): Double {
            skipWs()
            return when (peek()) {
                '-' -> {
                    i++
                    -unary()
                }
                '+' -> {
                    i++
                    unary()
                }
                else -> power()
            }
        }

        private fun power(): Double {
            val base = atom()
            skipWs()
            if (peek() == '^') {
                i++
                return base.pow(unary())
            }
            return base
        }

        private fun atom(): Double {
            skipWs()
            val c = peek()
            val v: Double
            if (c == '(') {
                i++
                v = expr()
                skipWs()
                if (peek() != ')') throw ExprError("Missing ')'")
                i++
            } else if (c.isDigit() || c == '.') {
                v = number()
            } else if (c.isLetter()) {
                val word = word()
                if (word.lowercase() == "pi") return PI
                throw ExprError("Unknown name '$word'")
            } else if (c == '\u0000') {
                throw ExprError("Unexpected end of expression")
            } else {
                throw ExprError("Unexpected '$c'")
            }
            return v * unitFactor()
        }

        private fun word(): String {
            val start = i
            while (i < s.length && s[i].isLetter()) i++
            return s.substring(start, i)
        }

        private fun number(): Double {
            val start = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (i < s.length && (s[i] == 'e' || s[i] == 'E')) {
                var j = i + 1
                if (j < s.length && (s[j] == '+' || s[j] == '-')) j++
                if (j < s.length && s[j].isDigit()) {
                    while (j < s.length && s[j].isDigit()) j++
                    i = j
                }
            }
            return s.substring(start, i).toDoubleOrNull() ?: throw ExprError("Invalid number '${s.substring(start, i)}'")
        }

        /** Factor of an optional unit suffix, converting to the field's base unit (metres or degrees). */
        private fun unitFactor(): Double {
            val save = i
            skipWs()
            val c = peek()
            if (!(c.isLetter() || c == '°')) {
                i = save
                return 1.0
            }
            val name = if (c == '°') {
                i++
                "°"
            } else {
                word()
            }
            if (name.lowercase() == "e" || name.lowercase() == "pi") throw ExprError("Unexpected '$name'")
            val lower = name.lowercase()
            return when (unit) {
                ParamUnit.LENGTH -> when (lower) {
                    "m" -> 1.0
                    "cm" -> 0.01
                    "mm" -> 0.001
                    "km" -> 1000.0
                    "in" -> 0.0254
                    "ft" -> 0.3048
                    else -> throw ExprError("Unknown length unit '$name' (use m, cm, mm, km, in, ft)")
                }
                ParamUnit.ANGLE -> when (lower) {
                    "deg", "°" -> 1.0
                    "rad" -> 180.0 / PI
                    else -> throw ExprError("Unknown angle unit '$name' (use deg or rad)")
                }
                ParamUnit.NONE -> throw ExprError("Units are not allowed here ('$name')")
            }
        }
    }
}
