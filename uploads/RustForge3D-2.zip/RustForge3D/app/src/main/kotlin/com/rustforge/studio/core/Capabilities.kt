package com.rustforge.studio.core

/**
 * What this build's engine can do beyond the always-present core. Features are listed here, in one place, so the UI shows
 * honest states; flip a flag when the engine gains the feature.
 */
object Capabilities {
    /** OBJ / STL / GLB / glTF import. */
    const val MESH_IMPORT = false

    /** OBJ / STL / GLB / glTF export. */
    const val MESH_EXPORT = false

    /** Sculpt mode and brushes. */
    const val SCULPT = false

    /** File extension of project files (the only file format this build reads and writes). */
    const val PROJECT_EXTENSION = "rforge"
}
