package com.rustforge.studio.core

import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToLong

enum class ParamKind {
    FLOAT, INT, BOOL, BVEC3, ENUM, VEC2, VEC3, COLOR, STRING, OBJECT, MATERIAL, UNKNOWN;

    companion object {
        fun parse(s: String): ParamKind = when (s) {
            "float" -> FLOAT
            "int" -> INT
            "bool" -> BOOL
            "bvec3" -> BVEC3
            "enum" -> ENUM
            "vec2" -> VEC2
            "vec3" -> VEC3
            "color" -> COLOR
            "string" -> STRING
            "object" -> OBJECT
            "material" -> MATERIAL
            else -> UNKNOWN
        }
    }
}

enum class ParamUnit {
    NONE, LENGTH, ANGLE;

    companion object {
        fun parse(s: String): ParamUnit = when (s) {
            "length" -> LENGTH
            "angle" -> ANGLE
            else -> NONE
        }
    }
}

/** Show a parameter only while another parameter has the given value. */
data class VisibleIf(val name: String, val equals: Json)

/** Slider extent for a number parameter. */
data class SliderRange(val min: Float, val max: Float)

/** One adjustable operator or modifier parameter (docs/PROTOCOL.md section 3). Angle values are in degrees. */
data class ParamDef(
    val name: String,
    val label: String,
    val kind: ParamKind,
    val value: Json,
    val default: Json,
    val min: Double? = null,
    val max: Double? = null,
    val softMax: Double? = null,
    val step: Double? = null,
    val unit: ParamUnit = ParamUnit.NONE,
    val options: List<Pair<String, String>> = emptyList(),
    val help: String = "",
    val visibleIf: VisibleIf? = null,
) {
    val number: Double get() = value.double()
    val isNumeric: Boolean get() = kind == ParamKind.FLOAT || kind == ParamKind.INT

    /** Slider extent: the declared soft/hard limits, otherwise a range scaled to the parameter's magnitude. */
    fun sliderRange(): SliderRange {
        val ref = max(1.0, abs(default.double()))
        val hi = softMax ?: max ?: if (unit == ParamUnit.ANGLE) 360.0 else ref * 4.0
        var lo = min ?: if (unit == ParamUnit.ANGLE) -360.0 else -hi
        if (lo >= hi) lo = hi - 1.0
        return SliderRange(lo.toFloat(), hi.toFloat())
    }

    /** Clamps to the hard limits and rounds integers. */
    fun clamp(v: Double): Double {
        var r = v
        if (min != null && r < min) r = min
        if (max != null && r > max) r = max
        return if (kind == ParamKind.INT) r.roundToLong().toDouble() else r
    }

    fun isVisible(all: List<ParamDef>): Boolean {
        val cond = visibleIf ?: return true
        val other = all.firstOrNull { it.name == cond.name } ?: return true
        return ParamDefs.looseEquals(other.value, cond.equals)
    }

    /** The `params` JSON that changes only this parameter (argument of `op.redo` and `modifier.set`). */
    fun patch(newValue: Json): Json.Obj = ParamDefs.patch(name, newValue)

    fun withValue(v: Json): ParamDef = copy(value = v)
}

object ParamDefs {
    fun parse(j: Json): ParamDef {
        val options = j["options"].list.mapNotNull { o ->
            val id = o[0].str()
            if (id.isEmpty()) null else id to o[1].str(id)
        }
        val cond = j["visible_if"]
        return ParamDef(
            name = j["name"].str(),
            label = j["label"].str(j["name"].str()),
            kind = ParamKind.parse(j["type"].str()),
            value = j["value"],
            default = j["default"],
            min = j["min"].optDouble(),
            max = j["max"].optDouble(),
            softMax = j["soft_max"].optDouble(),
            step = j["step"].optDouble(),
            unit = ParamUnit.parse(j["unit"].str()),
            options = options,
            help = j["help"].str(),
            visibleIf = if (cond is Json.Obj) VisibleIf(cond["name"].str(), cond["equals"]) else null,
        )
    }

    fun parseList(j: Json): List<ParamDef> = j.list.map { parse(it) }.filter { it.name.isNotEmpty() }

    fun patch(name: String, value: Json): Json.Obj = jsonOf("params" to jsonOf(name to value))

    /** JSON equality that treats booleans and 0/1 numbers alike (the engine accepts both). */
    fun looseEquals(a: Json, b: Json): Boolean {
        if (a == b) return true
        if ((a is Json.Bool || a is Json.Num) && (b is Json.Bool || b is Json.Num)) return a.double() == b.double()
        return false
    }

    /** Replaces one component of a vector value (`vec2`/`vec3`/`color`/`bvec3`). */
    fun withComponent(def: ParamDef, index: Int, v: Json): Json {
        val items = def.value.list.toMutableList()
        while (items.size <= index) items.add(if (def.kind == ParamKind.BVEC3) Json.Bool(false) else Json.Num(0.0))
        items[index] = v
        return Json.Arr(items)
    }
}

private fun Json.optDouble(): Double? = if (this is Json.Num) value else null

/** Number display and entry for parameter fields. */
object ParamFormat {
    /** Decimal text without trailing zeros (always `.` as separator). */
    fun plain(d: Double, maxDecimals: Int = 4): String {
        if (!d.isFinite()) return "0"
        var s = String.format(Locale.ROOT, "%.${maxDecimals}f", d)
        if (s.contains('.')) s = s.trimEnd('0').trimEnd('.')
        return if (s == "-0" || s.isEmpty()) "0" else s
    }

    /** Text shown in a numeric field for [def]'s value (no unit suffix; the field label carries the unit). */
    fun number(d: Double, def: ParamDef?): String = if (def?.kind == ParamKind.INT) d.roundToLong().toString() else plain(d)

    fun unitSuffix(unit: ParamUnit): String = when (unit) {
        ParamUnit.LENGTH -> "m"
        ParamUnit.ANGLE -> "°"
        ParamUnit.NONE -> ""
    }

    /** Parses what the user typed for [def]; null when invalid. The result is clamped to the hard limits. */
    fun parse(text: String, def: ParamDef): Double? = NumericExpr.evalOrNull(text, def.unit)?.let { def.clamp(it) }
}
