package com.rustforge.studio.state

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import com.rustforge.studio.bridge.Coalescer
import com.rustforge.studio.bridge.EngineClient
import com.rustforge.studio.bridge.EngineStart
import com.rustforge.studio.core.Cmd
import com.rustforge.studio.core.EngineState
import com.rustforge.studio.core.Json
import com.rustforge.studio.core.MenuOp
import com.rustforge.studio.core.ParamDef
import com.rustforge.studio.core.jsonOf
import com.rustforge.studio.storage.AppPrefs
import com.rustforge.studio.storage.ProjectStorage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

/**
 * Owns the engine client and the app-level UI state. Every engine interaction of the UI goes through here, so ids and
 * argument names of commands live in one place. The ViewModel survives rotation: scene, history and panels are kept.
 */
class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = AppPrefs(application)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val autosaveFile = File(application.filesDir, "autosave.rforge")
    private val start = EngineClient.start(application.filesDir, application.resources.displayMetrics.density)

    val client: EngineClient? = (start as? EngineStart.Started)?.client

    /** Set when the native engine could not start; the UI then shows this instead of the app. */
    val startError: String? = (start as? EngineStart.Failed)?.message

    val engine: StateFlow<EngineState> = client?.state ?: MutableStateFlow(EngineState())
    val surfaceError: StateFlow<String?> = client?.surfaceError ?: MutableStateFlow(null)

    private val mutableUi = MutableStateFlow(UiState(documentName = prefs.documentName, restoreSession = prefs.restoreSession))
    val ui: StateFlow<UiState> = mutableUi.asStateFlow()

    private val mutableMessages = MutableSharedFlow<UiMessage>(extraBufferCapacity = 8, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val messages: SharedFlow<UiMessage> = mutableMessages.asSharedFlow()
    private var messageSeq = 0L
    private var currentUri: Uri? = null

    private val redoCoalescer = Coalescer<Json>(scope) { patch -> client?.call("op.redo", patch) }

    init {
        val c = client
        if (c != null) {
            scope.launch { c.errors.collect { message("error", it) } }
            scope.launch {
                var lastSeq = 0L
                c.state.collect { s ->
                    val t = s.toast
                    if (t != null && t.seq != lastSeq) {
                        lastSeq = t.seq
                        message(t.level, t.text)
                    }
                }
            }
            scope.launch { restoreSession(c) }
            scope.launch { autosaveLoop(c) }
        }
    }

    // ---- lifecycle ----------------------------------------------------------------------------------------------------

    fun onStart() {
        client?.setResumed(true)
    }

    fun onStop() {
        client?.setResumed(false)
        scope.launch { autosaveNow() }
    }

    override fun onCleared() {
        scope.cancel()
        client?.destroy()
        super.onCleared()
    }

    private suspend fun restoreSession(c: EngineClient) {
        if (!prefs.restoreSession) return
        val bytes = ProjectStorage.readAutosave(autosaveFile) ?: return
        val r = c.loadProject(bytes)
        if (!r.ok) {
            message("warn", "The previous session could not be restored: ${r.error}")
            autosaveFile.delete()
        }
    }

    private suspend fun autosaveLoop(c: EngineClient) {
        var lastKey = ""
        while (true) {
            delay(AUTOSAVE_INTERVAL_MS)
            val s = c.state.value
            val key = "${s.undo.depth}|${s.undo.undoLabel}|${s.stats.verts}|${s.scene.objects.size}"
            if (key != lastKey) {
                lastKey = key
                autosaveNow()
            }
        }
    }

    private suspend fun autosaveNow() {
        val bytes = client?.saveProject() ?: return
        try {
            ProjectStorage.writeAutosave(autosaveFile, bytes)
        } catch (e: Exception) {
            // Autosave is best effort.
        }
    }

    fun message(level: String, text: String) {
        mutableMessages.tryEmit(UiMessage(++messageSeq, level, text))
    }

    // ---- UI state -----------------------------------------------------------------------------------------------------

    fun setWorkspace(w: Workspace) = mutableUi.update { it.copy(workspace = w) }
    fun showPanel(tab: PanelTab) = mutableUi.update { it.copy(panelOpen = true, panelTab = tab) }
    fun togglePanel(tab: PanelTab) = mutableUi.update { if (it.panelOpen && it.panelTab == tab) it.copy(panelOpen = false) else it.copy(panelOpen = true, panelTab = tab) }
    fun selectTab(tab: PanelTab) = mutableUi.update { it.copy(panelTab = tab) }
    fun closePanel() = mutableUi.update { it.copy(panelOpen = false) }
    fun showDialog(d: AppDialog) = mutableUi.update { it.copy(dialog = d) }
    fun closeDialog() = mutableUi.update { it.copy(dialog = null) }
    fun toggleRedoPanel() = mutableUi.update { it.copy(redoPanelOpen = !it.redoPanelOpen) }
    fun setMultiSelect(on: Boolean) = mutableUi.update { it.copy(multiSelect = on) }

    fun setRestoreSession(on: Boolean) {
        prefs.restoreSession = on
        mutableUi.update { it.copy(restoreSession = on) }
    }

    private fun setDocument(name: String?) {
        prefs.documentName = name
        mutableUi.update { it.copy(documentName = name) }
    }

    fun backendName(): String = client?.backendName().orEmpty()

    // ---- engine commands ----------------------------------------------------------------------------------------------

    fun call(method: String, vararg args: Pair<String, Any?>) {
        client?.post(method, jsonOf(*args))
    }

    /** Posts a command whose arguments were built elsewhere (for example by a dialog). */
    fun callJson(method: String, args: Json) {
        client?.post(method, args)
    }

    fun op(id: String, vararg params: Pair<String, Any?>) {
        client?.post("op.run", Cmd.op(id, *params))
    }

    fun runMenuOp(item: MenuOp) = op(item.id, *item.params.toTypedArray())

    fun undo() = call("undo")
    fun redo() = call("redo")
    fun setTool(id: String) = call("tool.set", "tool" to id)
    fun setMode(mode: String) = call("mode.set", "mode" to mode)
    fun setSelectMode(mode: String) = call("select.mode", "mode" to mode)
    fun select(action: String) = call("select.$action")
    fun viewPreset(view: String) = call("view.preset", "view" to view)
    fun toggleProjection() = call("view.projection", "projection" to "toggle")
    fun focus(target: String) = call("view.focus", "target" to target)
    fun viewSet(key: String, value: Any?) = call("view.set", key to value)
    fun setSetting(path: String, value: Any?) = call("settings.set", "path" to path, "value" to value)

    fun selectObject(id: Int) = call("select.set", "ids" to listOf(id), "extend" to false)

    /** Multi-select mode: tapping toggles an object in or out of the selection; the tapped object becomes active. */
    fun toggleObjectSelection(id: Int) {
        val selected = engine.value.selectedObjects.map { it.id }
        val next = if (id in selected) selected - id else selected + id
        if (next.isEmpty()) call("select.none") else call("select.set", "ids" to next, "extend" to false)
    }

    /** Live editing of the last operator's parameter (the redo panel): only the newest value is applied. */
    fun redoParam(def: ParamDef, value: Json) = redoCoalescer.submit(def.patch(value))

    fun setModifierParam(objectId: Int, index: Int, def: ParamDef, value: Json) =
        call("modifier.set", "object" to objectId, "index" to index, "params" to jsonOf(def.name to value))

    fun objectSet(id: Int, vararg fields: Pair<String, Any?>) = call("object.set", "id" to id, *fields)

    fun addModifier(type: String) = op("object.modifier_add", "type" to type)
    fun removeModifier(index: Int) = op("object.modifier_remove", "index" to index)
    fun applyModifier(index: Int) = op("object.modifier_apply", "index" to index)

    /** Creates a material and assigns it to [slot] of the active object. */
    fun createMaterialForActive(slot: Int) {
        val c = client ?: return
        val active = engine.value.active ?: return
        scope.launch {
            val created = c.call("material.create", jsonOf("name" to "Material"))
            if (!created.ok) {
                message("error", created.error)
                return@launch
            }
            val assigned = c.call("material.assign", jsonOf("object" to active.id, "material" to created.json["id"].int(), "slot" to slot))
            if (!assigned.ok) message("error", assigned.error)
        }
    }

    fun assignMaterial(objectId: Int, materialId: Int, slot: Int) = call("material.assign", "object" to objectId, "material" to materialId, "slot" to slot)
    fun setMaterial(id: Int, vararg fields: Pair<String, Any?>) = call("material.set", "id" to id, *fields)

    // ---- projects -----------------------------------------------------------------------------------------------------

    fun newProject() {
        call("project.new")
        currentUri = null
        setDocument(null)
    }

    fun openProject(uri: Uri) {
        val c = client ?: return
        val resolver = getApplication<Application>().contentResolver
        scope.launch {
            try {
                val bytes = ProjectStorage.read(resolver, uri)
                val r = c.loadProject(bytes)
                if (r.ok) {
                    currentUri = uri
                    keepAccess(uri)
                    setDocument(ProjectStorage.displayName(resolver, uri))
                } else {
                    message("error", r.error)
                }
            } catch (e: Exception) {
                message("error", "Could not open the file: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Saves into [uri] (Save As target). */
    fun saveProject(uri: Uri) {
        val c = client ?: return
        val resolver = getApplication<Application>().contentResolver
        scope.launch {
            try {
                val bytes = c.saveProject() ?: throw IllegalStateException(c.lastError().ifBlank { "The project could not be serialised" })
                ProjectStorage.write(resolver, uri, bytes)
                currentUri = uri
                keepAccess(uri)
                setDocument(ProjectStorage.displayName(resolver, uri))
                message("info", "Project saved")
            } catch (e: Exception) {
                message("error", "Could not save the file: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    /** Saves to the file the project was opened from or last saved to. Returns false when there is none (use Save As). */
    fun saveToCurrent(): Boolean {
        val uri = currentUri ?: return false
        saveProject(uri)
        return true
    }

    private fun keepAccess(uri: Uri) {
        try {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
            )
        } catch (e: Exception) {
            // Not every provider offers persistable grants; saving still works for this session.
        }
    }

    private companion object {
        const val AUTOSAVE_INTERVAL_MS = 30_000L
    }
}
