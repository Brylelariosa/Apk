package com.rustforge.studio.core

import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

data class Rgb(val r: Float, val g: Float, val b: Float)
data class Hsv(val h: Float, val s: Float, val v: Float)

/** Colour conversions for the material colour picker. The engine stores linear RGB; pickers work in sRGB. */
object ColorMath {
    fun srgbToLinear(c: Float): Float = if (c <= 0.04045f) c / 12.92f else ((c + 0.055f) / 1.055f).pow(2.4f)

    fun linearToSrgb(c: Float): Float = if (c <= 0.0031308f) c * 12.92f else 1.055f * c.pow(1f / 2.4f) - 0.055f

    fun toSrgb(linear: Rgb) = Rgb(linearToSrgb(linear.r), linearToSrgb(linear.g), linearToSrgb(linear.b))
    fun toLinear(srgb: Rgb) = Rgb(srgbToLinear(srgb.r), srgbToLinear(srgb.g), srgbToLinear(srgb.b))

    fun rgbToHsv(c: Rgb): Hsv {
        val mx = max(c.r, max(c.g, c.b))
        val mn = min(c.r, min(c.g, c.b))
        val d = mx - mn
        val h = when {
            d == 0f -> 0f
            mx == c.r -> 60f * (((c.g - c.b) / d) % 6f)
            mx == c.g -> 60f * ((c.b - c.r) / d + 2f)
            else -> 60f * ((c.r - c.g) / d + 4f)
        }
        return Hsv(if (h < 0f) h + 360f else h, if (mx == 0f) 0f else d / mx, mx)
    }

    fun hsvToRgb(c: Hsv): Rgb {
        val h = ((c.h % 360f) + 360f) % 360f
        val k = c.v * c.s
        val x = k * (1f - abs((h / 60f) % 2f - 1f))
        val m = c.v - k
        val (r, g, b) = when (floor(h / 60f).toInt()) {
            0 -> Triple(k, x, 0f)
            1 -> Triple(x, k, 0f)
            2 -> Triple(0f, k, x)
            3 -> Triple(0f, x, k)
            4 -> Triple(x, 0f, k)
            else -> Triple(k, 0f, x)
        }
        return Rgb(r + m, g + m, b + m)
    }

    /** `#RRGGBB` of an sRGB colour. */
    fun toHex(c: Rgb): String {
        fun ch(v: Float) = (v.coerceIn(0f, 1f) * 255f).roundToInt()
        return String.format(Locale.ROOT, "#%02X%02X%02X", ch(c.r), ch(c.g), ch(c.b))
    }

    /** Parses `#RGB`, `#RRGGBB` (with or without `#`) into an sRGB colour; null when malformed. */
    fun parseHex(text: String): Rgb? {
        var t = text.trim().removePrefix("#")
        if (t.length == 3) t = t.map { "$it$it" }.joinToString("")
        if (t.length != 6 || !t.all { Character.digit(it, 16) >= 0 }) return null
        val v = t.toInt(16)
        return Rgb(((v shr 16) and 255) / 255f, ((v shr 8) and 255) / 255f, (v and 255) / 255f)
    }
}
