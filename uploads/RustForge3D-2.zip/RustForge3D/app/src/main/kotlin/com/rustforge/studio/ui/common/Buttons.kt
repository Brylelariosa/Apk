package com.rustforge.studio.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rustforge.studio.ui.icons.AppIcon
import com.rustforge.studio.ui.theme.Palette

/** Single-line text in the app's colours. */
@Composable
fun Txt(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Palette.text,
    size: TextUnit = 13.sp,
    weight: FontWeight? = null,
    maxLines: Int = 1,
) {
    Text(text, modifier = modifier, color = color, fontSize = size, fontWeight = weight, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

/** Thin horizontal separator. */
@Composable
fun Rule(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().height(1.dp).background(Palette.outline))
}

/** Icon-only button with a tooltip (long press) and a 48 dp touch target by default. */
@Composable
fun ToolButton(
    icon: String,
    label: String,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    enabled: Boolean = true,
    size: Dp = 48.dp,
    iconSize: Dp = 22.dp,
    tipAbove: Boolean = false,
    tint: Color? = null,
) {
    val color = when {
        !enabled -> Palette.muted.copy(alpha = 0.4f)
        selected -> Palette.accent
        else -> tint ?: Palette.text
    }
    Pressable(
        onTap = onTap,
        modifier = modifier.size(size),
        enabled = enabled,
        label = label,
        tipAbove = tipAbove,
        background = if (selected) Palette.accentDim else Color.Transparent,
    ) {
        AppIcon(icon, tint = color, size = iconSize)
    }
}

/** Text button with an optional leading icon and trailing chevron (for buttons that open menus). */
@Composable
fun LabelButton(
    text: String,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
    icon: String? = null,
    selected: Boolean = false,
    enabled: Boolean = true,
    chevron: Boolean = false,
    tipAbove: Boolean = false,
    primary: Boolean = false,
    label: String? = null,
) {
    val color = when {
        !enabled -> Palette.muted.copy(alpha = 0.5f)
        primary -> Palette.onAccent
        selected -> Palette.accent
        else -> Palette.text
    }
    Pressable(
        onTap = onTap,
        modifier = modifier.height(44.dp),
        enabled = enabled,
        label = label ?: text,
        tipAbove = tipAbove,
        background = when {
            primary && enabled -> Palette.accent
            selected -> Palette.accentDim
            else -> Color.Transparent
        },
        pressedBackground = if (primary) Palette.accentDim else Palette.pressed,
    ) {
        Row(Modifier.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (icon != null) AppIcon(icon, tint = color, size = 20.dp)
            Text(text, color = color, fontSize = 13.sp, maxLines = 1, fontWeight = if (primary) FontWeight.Medium else null)
            if (chevron) AppIcon("chevron-down", tint = color, size = 16.dp)
        }
    }
}

/** Row of mutually exclusive options. [options] are (id, label) pairs. */
@Composable
fun Segmented(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 40.dp,
) {
    val shape = RoundedCornerShape(10.dp)
    Row(
        modifier
            .height(height)
            .clip(shape)
            .background(Palette.field)
            .border(1.dp, Palette.outline, shape),
    ) {
        for ((id, text) in options) {
            val on = id == selected
            Pressable(
                onTap = { onSelect(id) },
                modifier = Modifier.height(height),
                label = text,
                shape = shape,
                background = if (on) Palette.accentDim else Color.Transparent,
            ) {
                Text(
                    text,
                    color = if (on) Palette.accent else Palette.muted,
                    fontSize = 13.sp,
                    fontWeight = if (on) FontWeight.Medium else null,
                    maxLines = 1,
                    modifier = Modifier.padding(horizontal = 14.dp),
                )
            }
        }
    }
}

/** One entry of a dropdown menu, with an optional icon and check mark. */
@Composable
fun MenuEntry(text: String, onClick: () -> Unit, icon: String? = null, enabled: Boolean = true, checked: Boolean = false) {
    val tint = if (enabled) Palette.text else Palette.muted.copy(alpha = 0.5f)
    val leading: (@Composable () -> Unit)? = if (icon != null) {
        { AppIcon(icon, tint = tint, size = 20.dp) }
    } else {
        null
    }
    val trailing: (@Composable () -> Unit)? = if (checked) {
        { AppIcon("check", tint = Palette.accent, size = 18.dp) }
    } else {
        null
    }
    DropdownMenuItem(
        text = { Text(text, fontSize = 14.sp, color = tint) },
        onClick = onClick,
        enabled = enabled,
        leadingIcon = leading,
        trailingIcon = trailing,
    )
}

/** A button that shows [menu] below it; [menu] receives a function that closes the menu. */
@Composable
fun MenuButton(
    modifier: Modifier = Modifier,
    button: @Composable (open: () -> Unit) -> Unit,
    menu: @Composable (close: () -> Unit) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        button { open = true }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            menu { open = false }
        }
    }
}

/** Compact dropdown for choosing one of [options] ((id, label) pairs). */
@Composable
fun DropdownField(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(8.dp)
    val text = options.firstOrNull { it.first == selected }?.second ?: selected
    Box(modifier) {
        Pressable(
            onTap = { open = true },
            enabled = enabled,
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .border(1.dp, Palette.outline, shape),
            shape = shape,
            background = Palette.field,
            label = text,
        ) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Txt(text, Modifier.weight(1f), color = if (enabled) Palette.text else Palette.muted)
                Spacer(Modifier.width(4.dp))
                AppIcon("chevron-down", tint = Palette.muted, size = 16.dp)
            }
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            for ((id, label) in options) {
                MenuEntry(label, onClick = {
                    open = false
                    onSelect(id)
                }, checked = id == selected)
            }
        }
    }
}
