package com.rustforge.studio.storage

import android.content.Context

/** App-level preferences that are not engine settings. */
class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("rustforge_app", Context.MODE_PRIVATE)

    /** Reopen the previous scene when the app starts. */
    var restoreSession: Boolean
        get() = prefs.getBoolean(KEY_RESTORE, true)
        set(value) {
            prefs.edit().putBoolean(KEY_RESTORE, value).apply()
        }

    /** Name of the project file last opened or saved, shown in the top bar. */
    var documentName: String?
        get() = prefs.getString(KEY_DOC, null)
        set(value) {
            prefs.edit().putString(KEY_DOC, value).apply()
        }

    private companion object {
        const val KEY_RESTORE = "restore_session"
        const val KEY_DOC = "document_name"
    }
}
