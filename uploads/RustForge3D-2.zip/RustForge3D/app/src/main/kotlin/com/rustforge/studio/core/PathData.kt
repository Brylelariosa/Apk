package com.rustforge.studio.core

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** Absolute path segments; quadratic curves and arcs are converted to cubics so renderers need only these four. */
sealed class Seg {
    data class Move(val x: Float, val y: Float) : Seg()
    data class Line(val x: Float, val y: Float) : Seg()
    data class Cubic(val x1: Float, val y1: Float, val x2: Float, val y2: Float, val x: Float, val y: Float) : Seg()
    object Close : Seg()
}

class PathParseException(message: String) : Exception(message)

/** Parser for SVG path data (`M L H V C S Q T A Z`, absolute and relative). */
object PathData {
    fun parse(d: String): List<Seg> = Reader(d).run()

    private class Reader(private val s: String) {
        private var i = 0
        private val out = ArrayList<Seg>()
        private var cx = 0.0
        private var cy = 0.0
        private var sx = 0.0
        private var sy = 0.0
        private var lastCtrlX = 0.0
        private var lastCtrlY = 0.0
        private var lastCmd = ' '

        fun run(): List<Seg> {
            var cmd = ' '
            while (true) {
                skipSep()
                if (i >= s.length) break
                val c = s[i]
                if (c.isLetter()) {
                    cmd = c
                    i++
                    if (cmd == 'z' || cmd == 'Z') {
                        out.add(Seg.Close)
                        cx = sx
                        cy = sy
                        lastCmd = 'Z'
                        continue
                    }
                } else if (cmd == ' ' || cmd == 'z' || cmd == 'Z') {
                    throw PathParseException("Number without a command at $i in '$s'")
                }
                command(cmd)
                // After a moveto, further coordinate pairs are implicit linetos.
                if (cmd == 'M') cmd = 'L' else if (cmd == 'm') cmd = 'l'
            }
            return out
        }

        private fun skipSep() {
            while (i < s.length && (s[i] == ' ' || s[i] == ',' || s[i] == '\n' || s[i] == '\t')) i++
        }

        private fun num(): Double {
            skipSep()
            val start = i
            if (i < s.length && (s[i] == '-' || s[i] == '+')) i++
            var seenDot = false
            while (i < s.length) {
                val c = s[i]
                if (c.isDigit()) {
                    i++
                } else if (c == '.' && !seenDot) {
                    seenDot = true
                    i++
                } else {
                    break
                }
            }
            if (i < s.length && (s[i] == 'e' || s[i] == 'E') && i + 1 < s.length && (s[i + 1].isDigit() || s[i + 1] == '-' || s[i + 1] == '+')) {
                i += 2
                while (i < s.length && s[i].isDigit()) i++
            }
            return s.substring(start, i).toDoubleOrNull() ?: throw PathParseException("Bad number at $start in '$s'")
        }

        private fun flag(): Boolean {
            skipSep()
            if (i >= s.length || (s[i] != '0' && s[i] != '1')) throw PathParseException("Bad arc flag at $i in '$s'")
            return s[i++] == '1'
        }

        private fun command(cmd: Char) {
            val rel = cmd.isLowerCase()
            val ox = if (rel) cx else 0.0
            val oy = if (rel) cy else 0.0
            when (cmd.uppercaseChar()) {
                'M' -> {
                    val x = num() + ox
                    val y = num() + oy
                    out.add(Seg.Move(x.toFloat(), y.toFloat()))
                    cx = x; cy = y; sx = x; sy = y
                }
                'L' -> line(num() + ox, num() + oy)
                'H' -> line(num() + ox, cy)
                'V' -> line(cx, num() + oy)
                'C' -> {
                    val x1 = num() + ox; val y1 = num() + oy
                    val x2 = num() + ox; val y2 = num() + oy
                    val x = num() + ox; val y = num() + oy
                    cubic(x1, y1, x2, y2, x, y)
                }
                'S' -> {
                    val smooth = lastCmd == 'C' || lastCmd == 'S'
                    val x1 = if (smooth) 2 * cx - lastCtrlX else cx
                    val y1 = if (smooth) 2 * cy - lastCtrlY else cy
                    val x2 = num() + ox; val y2 = num() + oy
                    val x = num() + ox; val y = num() + oy
                    cubic(x1, y1, x2, y2, x, y)
                }
                'Q' -> {
                    val qx = num() + ox; val qy = num() + oy
                    val x = num() + ox; val y = num() + oy
                    quad(qx, qy, x, y)
                }
                'T' -> {
                    val smooth = lastCmd == 'Q' || lastCmd == 'T'
                    val qx = if (smooth) 2 * cx - lastCtrlX else cx
                    val qy = if (smooth) 2 * cy - lastCtrlY else cy
                    quad(qx, qy, num() + ox, num() + oy)
                }
                'A' -> {
                    val rx = num(); val ry = num(); val rot = num()
                    val large = flag(); val sweep = flag()
                    arc(rx, ry, rot, large, sweep, num() + ox, num() + oy)
                }
                else -> throw PathParseException("Unknown command '$cmd' in '$s'")
            }
            lastCmd = cmd.uppercaseChar()
        }

        private fun line(x: Double, y: Double) {
            out.add(Seg.Line(x.toFloat(), y.toFloat()))
            cx = x; cy = y
        }

        private fun cubic(x1: Double, y1: Double, x2: Double, y2: Double, x: Double, y: Double) {
            out.add(Seg.Cubic(x1.toFloat(), y1.toFloat(), x2.toFloat(), y2.toFloat(), x.toFloat(), y.toFloat()))
            lastCtrlX = x2; lastCtrlY = y2
            cx = x; cy = y
        }

        private fun quad(qx: Double, qy: Double, x: Double, y: Double) {
            val c1x = cx + 2.0 / 3.0 * (qx - cx)
            val c1y = cy + 2.0 / 3.0 * (qy - cy)
            val c2x = x + 2.0 / 3.0 * (qx - x)
            val c2y = y + 2.0 / 3.0 * (qy - y)
            out.add(Seg.Cubic(c1x.toFloat(), c1y.toFloat(), c2x.toFloat(), c2y.toFloat(), x.toFloat(), y.toFloat()))
            lastCtrlX = qx; lastCtrlY = qy
            cx = x; cy = y
        }

        /** SVG endpoint arc -> centre parameterisation -> cubic segments of at most 90 degrees (SVG spec F.6.5). */
        private fun arc(rxIn: Double, ryIn: Double, rotDeg: Double, large: Boolean, sweep: Boolean, x: Double, y: Double) {
            val x0 = cx
            val y0 = cy
            if (x0 == x && y0 == y) return
            var rx = abs(rxIn)
            var ry = abs(ryIn)
            if (rx == 0.0 || ry == 0.0) {
                line(x, y)
                return
            }
            val phi = rotDeg * PI / 180.0
            val cosP = cos(phi)
            val sinP = sin(phi)
            val dx2 = (x0 - x) / 2.0
            val dy2 = (y0 - y) / 2.0
            val x1p = cosP * dx2 + sinP * dy2
            val y1p = -sinP * dx2 + cosP * dy2
            val lambda = x1p * x1p / (rx * rx) + y1p * y1p / (ry * ry)
            if (lambda > 1.0) {
                val k = sqrt(lambda)
                rx *= k
                ry *= k
            }
            val rx2 = rx * rx
            val ry2 = ry * ry
            val num = rx2 * ry2 - rx2 * y1p * y1p - ry2 * x1p * x1p
            val den = rx2 * y1p * y1p + ry2 * x1p * x1p
            val coef = (if (large == sweep) -1.0 else 1.0) * sqrt(maxOf(0.0, num / den))
            val cxp = coef * (rx * y1p / ry)
            val cyp = coef * -(ry * x1p / rx)
            val ccx = cosP * cxp - sinP * cyp + (x0 + x) / 2.0
            val ccy = sinP * cxp + cosP * cyp + (y0 + y) / 2.0
            val theta1 = atan2((y1p - cyp) / ry, (x1p - cxp) / rx)
            val theta2 = atan2((-y1p - cyp) / ry, (-x1p - cxp) / rx)
            var delta = theta2 - theta1
            if (!sweep && delta > 0) delta -= 2 * PI
            if (sweep && delta < 0) delta += 2 * PI
            val n = maxOf(1, ceil(abs(delta) / (PI / 2) - 1e-9).toInt())
            val step = delta / n
            val kappa = 4.0 / 3.0 * tan(step / 4.0)
            var t = theta1
            for (k in 0 until n) {
                val c1 = cos(t); val s1 = sin(t)
                val c2 = cos(t + step); val s2 = sin(t + step)
                fun mapX(px: Double, py: Double) = cosP * rx * px - sinP * ry * py + ccx
                fun mapY(px: Double, py: Double) = sinP * rx * px + cosP * ry * py + ccy
                val ex = if (k == n - 1) x else mapX(c2, s2)
                val ey = if (k == n - 1) y else mapY(c2, s2)
                cubic(
                    mapX(c1 - kappa * s1, s1 + kappa * c1), mapY(c1 - kappa * s1, s1 + kappa * c1),
                    mapX(c2 + kappa * s2, s2 - kappa * c2), mapY(c2 + kappa * s2, s2 - kappa * c2),
                    ex, ey,
                )
                t += step
            }
        }
    }

    /** Segments back to path data (absolute commands): used by the icon sheet generator and tests. */
    fun toSvg(segs: List<Seg>): String {
        val sb = StringBuilder()
        for (s in segs) {
            when (s) {
                is Seg.Move -> sb.append("M${f(s.x)} ${f(s.y)} ")
                is Seg.Line -> sb.append("L${f(s.x)} ${f(s.y)} ")
                is Seg.Cubic -> sb.append("C${f(s.x1)} ${f(s.y1)} ${f(s.x2)} ${f(s.y2)} ${f(s.x)} ${f(s.y)} ")
                Seg.Close -> sb.append("Z ")
            }
        }
        return sb.toString().trim()
    }

    private fun f(v: Float): String = JsonWriter.formatNumber((Math.round(v * 1000f) / 1000f).toDouble())
}
