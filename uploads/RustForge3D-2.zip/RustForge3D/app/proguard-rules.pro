# The native library looks these up by name through JNI.
-keep class com.rustforge.studio.bridge.NativeBridge { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}

# Size: let R8 move everything into one flat package and widen access so it can inline/merge more.
-repackageclasses ''
-allowaccessmodification
