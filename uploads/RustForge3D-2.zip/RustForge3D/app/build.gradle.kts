plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ABIs come from `rustAbis=` in gradle.properties (comma or space separated).
val rustAbis: List<String> = (providers.gradleProperty("rustAbis").orNull ?: "arm64-v8a")
    .split(',', ' ')
    .map { it.trim() }
    .filter { it.isNotEmpty() }

// The CI builds the native library itself and passes -PrustPrebuilt=true; nothing Rust-related runs then.
val rustPrebuilt: Boolean = providers.gradleProperty("rustPrebuilt").orNull == "true"

android {
    namespace = "com.rustforge.studio"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rustforge.studio"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0"
        ndk {
            abiFilters += rustAbis
        }
        // The UI is English only; drop the translated strings that AndroidX/Compose libraries bring along.
        resourceConfigurations += listOf("en")
    }

    buildTypes {
        release {
            // Signing is injected by the CI (-Pandroid.injected.signing.*); no signing config is hard-coded here.
            // Size: R8 shrinks/optimises code and removes unused resources (single APK, no ABI splits).
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    // Drop the signed dependency-metadata blob AGP adds to the APK (only Play uses it).
    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }

    sourceSets {
        getByName("main") {
            // cargo-ndk writes <abi>/librustforge.so here.
            jniLibs.srcDirs("src/main/jniLibs")
        }
    }

    packaging {
        jniLibs {
            // true = librustforge.so is stored compressed inside the APK (much smaller download/APK file; the installer
            // extracts it, so on-device install size is the uncompressed size). Also avoids 16 KB page-alignment issues.
            useLegacyPackaging = true
        }
        resources {
            excludes += listOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/*.version",
                "/DebugProbesKt.bin",
                "/kotlin-tooling-metadata.json",
            )
        }
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}

// Local builds (not CI): compile the Rust crate with cargo-ndk before packaging.
if (!rustPrebuilt) {
    val rustDir = rootProject.layout.projectDirectory.dir("rust").asFile
    val jniDir = layout.projectDirectory.dir("src/main/jniLibs").asFile
    val cargoNdkBuild = tasks.register<Exec>("cargoNdkBuild") {
        group = "rust"
        description = "Builds librustforge.so for the ABIs in rustAbis with cargo-ndk."
        workingDir = rustDir
        commandLine(listOf("cargo", "ndk") + rustAbis.flatMap { listOf("-t", it) } + listOf("-o", jniDir.absolutePath, "build", "--release"))
    }
    tasks.named("preBuild") {
        dependsOn(cargoNdkBuild)
    }
}
