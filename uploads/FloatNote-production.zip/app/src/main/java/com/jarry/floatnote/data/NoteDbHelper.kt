package com.jarry.floatnote.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteStatement
import android.os.CancellationSignal

/** Plain SQLiteOpenHelper - no Room/KSP, keeps the dependency graph (and APK) small.
 *  [dbName] defaults to the real on-disk database every production call site
 *  uses; tests pass `null` (SQLiteOpenHelper's own documented way to ask for
 *  a private, ephemeral in-memory database instead) to get a fully isolated
 *  instance per test with no shared file and nothing to clean up. */
class NoteDbHelper(context: Context, dbName: String? = DB_NAME) :
    SQLiteOpenHelper(context.applicationContext, dbName, null, DB_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE $TABLE (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TITLE TEXT NOT NULL DEFAULT '',
                $COL_CONTENT TEXT NOT NULL DEFAULT '',
                $COL_COLOR INTEGER NOT NULL DEFAULT -1,
                $COL_PINNED INTEGER NOT NULL DEFAULT 0,
                $COL_CREATED INTEGER NOT NULL,
                $COL_UPDATED INTEGER NOT NULL,
                $COL_VERSION INTEGER NOT NULL DEFAULT 1
            )
            """.trimIndent()
        )
        createIndexes(db)
    }

    // Each branch here only ever ADDS things (indexes, columns) and never
    // drops or recreates $TABLE, so existing notes always survive an
    // upgrade - this used to unconditionally DROP TABLE + recreate on any
    // version bump, which would have silently wiped every saved note the
    // moment DB_VERSION was next incremented. Add the next `if (oldVersion < N)`
    // branch here when the schema changes again.
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            createIndexes(db)
        }
        if (oldVersion < 3) {
            // Existing rows default to version=1 ("saved once already"),
            // consistent with what a brand-new row gets from insert() -
            // callers that read a note before this migration ran never saw
            // a version at all, so there's no earlier value to preserve.
            db.execSQL("ALTER TABLE $TABLE ADD COLUMN $COL_VERSION INTEGER NOT NULL DEFAULT 1")
        }
        if (oldVersion < 4) {
            // $COL_COLOR is only now becoming a real per-note style choice
            // (see Note.styleIndex's own doc comment). Every row that
            // exists already has 0 in this column purely because that was
            // the schema's original default, written faithfully but never
            // read anywhere - not because anyone ever chose style 0 for
            // that note. Resetting to -1 ("no override, follow Settings")
            // is what keeps every existing note rendering exactly as it did
            // before this feature existed, instead of every note in the app
            // suddenly reskinning to "Orange Book" the moment this update
            // runs.
            db.execSQL("UPDATE $TABLE SET $COL_COLOR = -1")
        }
    }

    private fun createIndexes(db: SQLiteDatabase) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_updated ON $TABLE($COL_UPDATED DESC)")
        // Every query in this app sorts by pinned-then-updated together (see
        // getAll below), so a composite index on both columns lets SQLite
        // satisfy that sort directly from the index instead of scanning the
        // table and sorting in memory.
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_pinned_updated ON $TABLE($COL_PINNED DESC, $COL_UPDATED DESC)")
    }

    /** Always inserts a new row (starting at version=1) - there's nothing an
     *  as-yet-nonexistent row could conflict with, so unlike update this
     *  never needs a version check. */
    fun insert(note: Note): Long {
        val values = toValues(note)
        values.put(COL_VERSION, 1)
        return writableDatabase.insert(TABLE, null, values)
    }

    /** Unconditional full-row update (title/content/color/pinned/timestamps),
     *  used only by the small number of callers that intentionally want
     *  last-write-wins with no conflict check - currently just
     *  [NoteRepository.save]'s fallback path. Still atomically bumps
     *  $COL_VERSION so any conflict-aware writer elsewhere correctly
     *  notices the row changed. Returns rows affected (0 if [note].id no
     *  longer exists). */
    fun update(note: Note): Int {
        val sql = """
            UPDATE $TABLE SET
                $COL_TITLE = ?, $COL_CONTENT = ?, $COL_COLOR = ?, $COL_PINNED = ?,
                $COL_UPDATED = ?, $COL_VERSION = $COL_VERSION + 1
            WHERE $COL_ID = ?
        """.trimIndent()
        return writableDatabase.compileStatement(sql).useStatement { stmt ->
            stmt.bindString(1, note.title)
            stmt.bindString(2, note.content)
            stmt.bindLong(3, note.styleIndex.toLong())
            stmt.bindLong(4, if (note.isPinned) 1 else 0)
            stmt.bindLong(5, note.updatedAt)
            stmt.bindLong(6, note.id)
            stmt.executeUpdateDelete()
        }
    }

    /**
     * Conditional, narrow update: writes only title/content/color/updatedAt -
     * deliberately NEVER $COL_PINNED, which nothing but [setPinned] ever
     * touches, so a floating window or the full editor autosaving stale
     * content can never clobber a pin toggled from the main list, and
     * vice versa. They simply write disjoint columns, so there is nothing
     * to reconcile between them.
     *
     * Only applies if the row's version still equals [expectedVersion], and
     * atomically increments it by 1 on success - this is the actual
     * optimistic-concurrency check backing
     * [NoteRepository.saveContentIfUnchanged]. Returns rows affected: 0
     * means either the row is gone (deleted elsewhere) or someone else's
     * write already moved the version on - the caller (via getById)
     * distinguishes those.
     */
    fun updateContentIfVersionMatches(note: Note, expectedVersion: Int): Int {
        val sql = """
            UPDATE $TABLE SET
                $COL_TITLE = ?, $COL_CONTENT = ?, $COL_COLOR = ?,
                $COL_UPDATED = ?, $COL_VERSION = $COL_VERSION + 1
            WHERE $COL_ID = ? AND $COL_VERSION = ?
        """.trimIndent()
        return writableDatabase.compileStatement(sql).useStatement { stmt ->
            stmt.bindString(1, note.title)
            stmt.bindString(2, note.content)
            stmt.bindLong(3, note.styleIndex.toLong())
            stmt.bindLong(4, note.updatedAt)
            stmt.bindLong(5, note.id)
            stmt.bindLong(6, expectedVersion.toLong())
            stmt.executeUpdateDelete()
        }
    }

    /** Narrow, unconditional update of only the pinned flag - the main list
     *  is the sole writer of this column (see updateContentIfVersionMatches),
     *  so there is nothing for it to conflict with; a version check here
     *  would only risk spuriously rejecting a legitimate pin tap because the
     *  list's cached copy of an unrelated field (title/content) was a tick
     *  stale. Still bumps $COL_VERSION so a content writer elsewhere
     *  correctly notices the row changed. */
    fun setPinned(id: Long, pinned: Boolean, updatedAt: Long): Int {
        val sql = "UPDATE $TABLE SET $COL_PINNED = ?, $COL_UPDATED = ?, $COL_VERSION = $COL_VERSION + 1 WHERE $COL_ID = ?"
        return writableDatabase.compileStatement(sql).useStatement { stmt ->
            stmt.bindLong(1, if (pinned) 1 else 0)
            stmt.bindLong(2, updatedAt)
            stmt.bindLong(3, id)
            stmt.executeUpdateDelete()
        }
    }

    fun delete(id: Long) {
        writableDatabase.delete(TABLE, "$COL_ID = ?", arrayOf(id.toString()))
    }

    fun getById(id: Long): Note? {
        readableDatabase.query(
            TABLE, null, "$COL_ID = ?", arrayOf(id.toString()), null, null, null
        ).use { c ->
            return if (c.moveToFirst()) c.toNote() else null
        }
    }

    /** [cancellationSignal], when supplied, lets a caller stop this query
     *  from the outside (a different thread) while it's still running -
     *  see NoteRepository.getAll. Without it, a query already handed off to
     *  SQLite runs to completion regardless of whether whoever asked for it
     *  (e.g. a superseded search keystroke) still wants the result, wasting
     *  CPU/IO and holding the DB's connection lock longer than necessary. */
    fun getAll(
        query: String = "",
        sortOrder: NoteSortOrder = NoteSortOrder.RECENTLY_EDITED,
        cancellationSignal: CancellationSignal? = null
    ): List<Note> {
        val selection = if (query.isNotBlank()) {
            "$COL_TITLE LIKE ? ESCAPE '\\' OR $COL_CONTENT LIKE ? ESCAPE '\\'"
        } else {
            null
        }
        val args = if (query.isNotBlank()) {
            // Escape SQLite's own LIKE wildcards (% and _) and the escape
            // character itself so a search for e.g. "50% off" or
            // "file_name" matches those literal characters instead of being
            // interpreted as a wildcard pattern.
            val likeArg = "%${escapeLike(query)}%"
            arrayOf(likeArg, likeArg)
        } else {
            null
        }
        // Pinned notes stay first regardless of which secondary sort is
        // chosen - sort order is about how the rest of the list reads, not
        // about demoting what's pinned.
        val secondarySort = when (sortOrder) {
            NoteSortOrder.RECENTLY_EDITED -> "$COL_UPDATED DESC"
            NoteSortOrder.DATE_CREATED -> "$COL_CREATED DESC"
            NoteSortOrder.TITLE_A_Z -> "$COL_TITLE COLLATE NOCASE ASC"
        }
        val order = "$COL_PINNED DESC, $secondarySort"
        val notes = mutableListOf<Note>()
        readableDatabase.query(
            false, TABLE, null, selection, args, null, null, order, null, cancellationSignal
        ).use { c ->
            while (c.moveToNext()) notes.add(c.toNote())
        }
        return notes
    }

    private fun escapeLike(raw: String): String =
        raw.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    private fun toValues(note: Note) = ContentValues().apply {
        put(COL_TITLE, note.title)
        put(COL_CONTENT, note.content)
        put(COL_COLOR, note.styleIndex)
        put(COL_PINNED, if (note.isPinned) 1 else 0)
        put(COL_CREATED, note.createdAt)
        put(COL_UPDATED, note.updatedAt)
    }

    private fun Cursor.toNote() = Note(
        id = getLong(getColumnIndexOrThrow(COL_ID)),
        title = getString(getColumnIndexOrThrow(COL_TITLE)),
        content = getString(getColumnIndexOrThrow(COL_CONTENT)),
        styleIndex = getInt(getColumnIndexOrThrow(COL_COLOR)),
        isPinned = getInt(getColumnIndexOrThrow(COL_PINNED)) == 1,
        createdAt = getLong(getColumnIndexOrThrow(COL_CREATED)),
        updatedAt = getLong(getColumnIndexOrThrow(COL_UPDATED)),
        version = getInt(getColumnIndexOrThrow(COL_VERSION))
    )

    /** SQLiteStatement.close() exists but the class doesn't reliably
     *  implement java.io.Closeable across every API level this app
     *  supports, so Kotlin's `.use {}` isn't used here - this is the same
     *  guarantee (always closed, even if [block] throws) via a plain
     *  try/finally instead. */
    private inline fun <T> SQLiteStatement.useStatement(block: (SQLiteStatement) -> T): T {
        try {
            return block(this)
        } finally {
            close()
        }
    }

    companion object {
        private const val DB_NAME = "floatnote.db"
        private const val DB_VERSION = 4
        private const val TABLE = "notes"
        private const val COL_ID = "_id"
        private const val COL_TITLE = "title"
        private const val COL_CONTENT = "content"
        private const val COL_COLOR = "color"
        private const val COL_PINNED = "pinned"
        private const val COL_CREATED = "created_at"
        private const val COL_UPDATED = "updated_at"
        private const val COL_VERSION = "version"
    }
}
