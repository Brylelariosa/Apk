package com.jarry.floatnote.util

import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Debounced undo/redo history for a single EditText. Pauses in typing (~700ms)
 * create checkpoints, so a burst of typing is one undo step rather than one
 * step per keystroke - matching how most text editors batch undo history.
 * Any new edit after an undo clears the redo stack, which is standard editor
 * behavior.
 */
class UndoRedoManager(
    private val editText: EditText,
    private val scope: CoroutineScope
) {
    private val undoStack = ArrayDeque<String>()
    private val redoStack = ArrayDeque<String>()
    private var lastCheckpoint: String = editText.text?.toString().orEmpty()
    private var isRestoring = false
    private var debounceJob: Job? = null

    /** Called after any state change so callers can refresh undo/redo button state. */
    var onStateChanged: (() -> Unit)? = null

    init {
        editText.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (isRestoring) return
                debounceJob?.cancel()
                debounceJob = scope.launch {
                    delay(700)
                    checkpoint()
                }
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    fun canUndo(): Boolean = undoStack.isNotEmpty()
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    /** Resets history to the current text, e.g. after loading a different note into the same field. */
    fun reset() {
        debounceJob?.cancel()
        undoStack.clear()
        redoStack.clear()
        lastCheckpoint = editText.text?.toString().orEmpty()
        onStateChanged?.invoke()
    }

    fun undo() {
        debounceJob?.cancel()
        checkpoint()
        if (undoStack.isEmpty()) return
        val previous = undoStack.removeLast()
        redoStack.addLast(lastCheckpoint)
        restore(previous)
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        val next = redoStack.removeLast()
        undoStack.addLast(lastCheckpoint)
        restore(next)
    }

    private fun checkpoint() {
        val current = editText.text?.toString().orEmpty()
        if (current == lastCheckpoint) return
        undoStack.addLast(lastCheckpoint)
        // Two eviction rules: a hard cap on entry count (bounds history depth
        // for typical small notes) and a total-characters budget (bounds
        // worst-case memory for a very large note, where even a handful of
        // full-text snapshots could otherwise add up to tens of MB). Oldest
        // entries go first either way, same as a normal undo stack running out
        // of room.
        var retainedChars = undoStack.sumOf { it.length }
        while (undoStack.size > MAX_HISTORY_ENTRIES || retainedChars > MAX_HISTORY_CHARS) {
            val removed = undoStack.removeFirstOrNull() ?: break
            retainedChars -= removed.length
        }
        redoStack.clear()
        lastCheckpoint = current
        onStateChanged?.invoke()
    }

    private fun restore(text: String) {
        isRestoring = true
        // Lands the cursor at roughly where the undone/redone edit actually
        // was - the first point the text being restored diverges from what's
        // currently on screen - rather than always at the very end. On a
        // long note, undoing a change made near the top used to yank the
        // cursor (and the scroll position with it) all the way down to the
        // bottom regardless of where the edit itself was.
        val cursorPos = commonPrefixLength(editText.text?.toString().orEmpty(), text)
        editText.setText(text)
        editText.setSelection(cursorPos.coerceIn(0, text.length))
        lastCheckpoint = text
        isRestoring = false
        onStateChanged?.invoke()
    }

    private fun commonPrefixLength(a: String, b: String): Int {
        val max = minOf(a.length, b.length)
        var i = 0
        while (i < max && a[i] == b[i]) i++
        return i
    }

    companion object {
        private const val MAX_HISTORY_ENTRIES = 100

        // ~4MB worst case (Kotlin/JVM strings are UTF-16, 2 bytes/char) - very
        // generous for a notes app but keeps a pathological single huge note
        // from turning undo history into an out-of-memory risk.
        private const val MAX_HISTORY_CHARS = 2_000_000
    }
}
