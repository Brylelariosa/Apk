package com.jarry.floatnote.util

import android.graphics.Rect
import android.view.TouchDelegate
import android.view.View
import android.view.ViewGroup

/**
 * Grows this view's *touch* area to at least [minSizePx] square, without
 * changing how it looks - for a view that's visually meant to stay small
 * (the note-color spine is 6dp wide) but still needs to meet Android's
 * ~48dp minimum touch target. Must be called after the view (and its
 * parent) have been laid out at least once, since it needs their actual
 * on-screen bounds - posting to the view itself is the simplest way to
 * guarantee that.
 */
fun View.expandTouchTarget(minSizePx: Int) {
    val parent = this.parent as? ViewGroup ?: return
    post {
        val rect = Rect()
        getHitRect(rect)
        val growX = ((minSizePx - rect.width()) / 2).coerceAtLeast(0)
        val growY = ((minSizePx - rect.height()) / 2).coerceAtLeast(0)
        rect.inset(-growX, -growY)
        parent.touchDelegate = TouchDelegate(rect, this)
    }
}
