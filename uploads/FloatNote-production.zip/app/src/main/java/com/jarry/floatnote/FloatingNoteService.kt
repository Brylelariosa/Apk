package com.jarry.floatnote

import android.animation.ValueAnimator
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.PopupMenu
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.data.NoteRepository
import com.jarry.floatnote.databinding.LayoutFloatingBubbleBinding
import com.jarry.floatnote.databinding.LayoutFloatingNoteBinding
import com.jarry.floatnote.util.Debouncer
import com.jarry.floatnote.util.ImeAwareOverlayResizer
import com.jarry.floatnote.util.MinimizeMode
import com.jarry.floatnote.util.OverlayEditFocusController
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.PrefsManager
import com.jarry.floatnote.util.UndoRedoManager
import com.jarry.floatnote.util.ViewLayoutThrottler
import com.jarry.floatnote.util.applyBubbleAppearance
import com.jarry.floatnote.util.applyContentTextSize
import com.jarry.floatnote.util.bubbleWindowSizePx
import com.jarry.floatnote.util.clipToRoundedCorners
import com.jarry.floatnote.util.copySelectionOrAll
import com.jarry.floatnote.util.dpToPx
import com.jarry.floatnote.util.expandNumberedListToken
import com.jarry.floatnote.util.pasteFromClipboard
import com.jarry.floatnote.util.setupWindowDrag
import com.jarry.floatnote.util.showNoteStylePicker
import com.jarry.floatnote.widget.CornerAccentBar
import com.jarry.floatnote.util.simpleWatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicInteger

/**
 * Hosts every floating note as a WindowManager overlay. Each note is either a
 * small draggable bubble (collapsed) or a draggable/resizable card (expanded).
 * Multiple notes can float at once - each gets its own FloatingNoteWindow.
 */
class FloatingNoteService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var repository: NoteRepository

    // A CoroutineExceptionHandler here is a last-resort safety net: an
    // uncaught exception from any coroutine launched on this scope (which
    // has no handler of its own) would otherwise propagate to the process's
    // default uncaught-exception handler and crash the whole app, taking
    // down every other still-open floating note along with it.
    private val serviceScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Main +
            CoroutineExceptionHandler { _, throwable ->
                Log.e(TAG, "Unhandled error in a floating note coroutine", throwable)
            }
    )
    private val windows = mutableListOf<FloatingNoteWindow>()

    // Guards showNote() against opening the same note in two windows if a
    // "show this note" intent is dispatched again before the first call has
    // finished creating its window (both would otherwise pass the
    // windows.find check below before either has added itself to `windows`).
    // Main-thread only, same as `windows` and `floatingNoteIds`.
    private val pendingShowNoteIds = mutableSetOf<Long>()

    // onDestroy tears down every window in a loop, and each one otherwise
    // calls updateForegroundNotification() on its way out - pointless work
    // right before the whole notification is removed along with the
    // foreground service itself, so updates are skipped once shutdown starts.
    private var isShuttingDown = false

    // A bare Service context doesn't reliably resolve Material3/AppCompat theme
    // attributes the way an Activity does, which previously crashed inflation
    // of the AppCompat-based views in the floating layouts. Wrapping it with
    // the app's own theme explicitly fixes that for good - reused by anything
    // else that needs the same themed resolution, like the overflow PopupMenu.
    private val themedContext: Context by lazy {
        ContextThemeWrapper(this, R.style.Theme_FloatNote)
    }
    private val themedInflater: LayoutInflater by lazy {
        LayoutInflater.from(themedContext)
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        repository = NoteRepository.getInstance(this)
        ensureNotificationChannels()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_SHOW_NOTE -> showNote(intent.getLongExtra(EXTRA_NOTE_ID, 0L))
            ACTION_CLOSE_ALL -> stopSelf()
            ACTION_EXPAND_NOTE -> {
                val key = intent.getIntExtra(EXTRA_WINDOW_KEY, -1)
                windows.find { it.notifKey == key }?.expand()
            }
            ACTION_DISMISS_NOTE -> {
                val key = intent.getIntExtra(EXTRA_WINDOW_KEY, -1)
                windows.find { it.notifKey == key }?.destroy(save = true)
            }
            ACTION_MINIMIZE_TO_BUBBLE -> {
                val key = intent.getIntExtra(EXTRA_WINDOW_KEY, -1)
                windows.find { it.notifKey == key }?.collapseToBubble()
            }
        }
        return START_NOT_STICKY
    }

    private fun showNote(noteId: Long) {
        // Safety net: WindowManager.addView(TYPE_APPLICATION_OVERLAY) throws without this
        // permission. Callers should already check OverlayPermission before starting this
        // service, but this guard means a missed check degrades to a message, not a crash.
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.overlay_permission_toast, Toast.LENGTH_LONG).show()
            if (windows.isEmpty()) stopSelf()
            return
        }
        windows.find { it.noteId == noteId && noteId != 0L }?.let {
            it.expand()
            return
        }
        if (noteId != 0L && !pendingShowNoteIds.add(noteId)) return
        serviceScope.launch {
            try {
                val note = if (noteId != 0L) repository.getById(noteId) ?: Note() else Note()
                val window = FloatingNoteWindow(note)
                windows.add(window)
                window.attach()
                syncFloatingNoteIds()
                updateForegroundNotification()
            } finally {
                pendingShowNoteIds.remove(noteId)
            }
        }
    }

    /** Keeps the companion's [floatingNoteIds] set in sync with [windows] -
     *  call after any change to which notes are floating: a window added or
     *  removed, or a window's own note id changing (assigned on first save
     *  of a brand-new note, which starts at id 0 and so isn't trackable
     *  until then). */
    private fun syncFloatingNoteIds() {
        floatingNoteIds.clear()
        windows.mapNotNullTo(floatingNoteIds) { it.noteId.takeIf { id -> id != 0L } }
    }

    /** Re-posts the always-on service notification so its "Maximize" action
     *  (see [buildNotification]) stays in sync with whether there's now a
     *  single note it can unambiguously target - call whenever [windows]
     *  gains or loses an entry. */
    private fun updateForegroundNotification() {
        if (isShuttingDown) return
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
    }

    private fun expandIntentFor(notifKey: Int): PendingIntent = PendingIntent.getService(
        this, notifKey,
        Intent(this, FloatingNoteService::class.java)
            .setAction(ACTION_EXPAND_NOTE)
            .putExtra(EXTRA_WINDOW_KEY, notifKey),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Both notification channels are created once up front instead of on
     *  every notification build/minimize - channel creation is idempotent,
     *  but there's no reason to repeat it on every single call. */
    private fun ensureNotificationChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(
                CHANNEL_ID, getString(R.string.floating_notes_channel_name), NotificationManager.IMPORTANCE_MIN
            )
        )
        manager.createNotificationChannel(
            NotificationChannel(
                MINIMIZED_CHANNEL_ID, getString(R.string.minimized_notes_channel_name), NotificationManager.IMPORTANCE_DEFAULT
            )
        )
    }

    private fun buildNotification(): android.app.Notification {
        val closeIntent = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingNoteService::class.java).setAction(ACTION_CLOSE_ALL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        // Was previously missing entirely, so the "Tap to manage floating notes"
        // text was a dead promise - tapping the notification body did nothing,
        // and "Close all" was the only way to interact with it. This opens the
        // notes list, where any note (including ones already closed) can be
        // reopened as a floating note.
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_note)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .addAction(0, getString(R.string.close_all_action), closeIntent)
            .setOngoing(true)

        // With exactly one floating note open (bubble or card - default
        // minimize mode is BUBBLE, so this is the *only* notification most
        // people ever see), "Maximize" can unambiguously target it. With zero
        // or several, there's no single note to bring forward, so this stays
        // a generic "manage floating notes" notification and the body opens
        // the notes list instead, same as before.
        val single = windows.singleOrNull()
        return if (single != null) {
            builder
                .setContentTitle(single.displayTitle())
                .setContentText(getString(R.string.foreground_notification_single_text))
                .setContentIntent(expandIntentFor(single.notifKey))
                .addAction(0, getString(R.string.notification_maximize_action), expandIntentFor(single.notifKey))
                .build()
        } else {
            builder
                .setContentTitle(getString(R.string.foreground_notification_title))
                .setContentText(getString(R.string.foreground_notification_text))
                .setContentIntent(openAppIntent)
                .build()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Rotation, entering/exiting multi-window, and similar changes can
        // leave a floating window positioned (or, for the card, sized)
        // outside the new screen bounds, where it would be impossible to see
        // or drag back into view - every live window is clamped back inside
        // the new bounds instead.
        windows.toList().forEach { it.clampToScreenBounds() }
    }

    override fun onDestroy() {
        isShuttingDown = true

        // Tear down every window's views, listeners, and notification
        // synchronously and up front, independent of any save. By the time
        // this loop returns, nothing this service added to WindowManager is
        // left outstanding - see FloatingNoteWindow.prepareForShutdown().
        val windowsToClose = windows.toList()
        windows.clear()
        windowsToClose.forEach { it.prepareForShutdown() }
        syncFloatingNoteIds()

        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)

        // Final saves are fired on NoteRepository's own durable scope
        // (Dispatchers.IO, independent of serviceScope) rather than awaited
        // here, so this callback returns immediately without blocking the
        // main thread even briefly - see
        // NoteRepository.saveOrDeleteIfEmptyDurable and
        // FloatingNoteWindow.persistFinalSnapshotAsync.
        //
        // An earlier version of this fix used
        // `runBlocking(Dispatchers.IO) { ... }` here, which no longer
        // deadlocked (see the version-control history / prior write-up) but
        // still synchronously blocked the main thread for however long the
        // writes took - a real, if small, ANR-risk/jank cost this avoids
        // entirely. Because durableScope has its own SupervisorJob rather
        // than being a child of serviceScope, cancelling serviceScope two
        // lines down can never interrupt a save already under way, and the
        // save still runs to completion in the background even after this
        // Service instance and serviceScope are gone, for as long as the
        // process itself keeps running - which Android does not tie to this
        // callback returning. This works the same way for any number of
        // simultaneously open floating notes: windowsToClose covers all of
        // them, and each one's save is independently version-checked
        // against the DB (see NoteRepository.saveContentIfUnchanged), so
        // even a note that was just deleted or edited from the main list a
        // moment earlier can't be clobbered by a stale write from here.
        windowsToClose.forEach { it.persistFinalSnapshotAsync() }

        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private inner class FloatingNoteWindow(private var note: Note) {
        val noteId: Long get() = note.id

        /** Human-readable label for this window - used by both the per-note
         *  minimized notification and the always-on service notification's
         *  "Maximize" action, so a note without a title still shows up as
         *  something a person would recognize instead of a blank line. */
        fun displayTitle(): String = note.title.ifBlank { getString(R.string.untitled_note) }

        // Stable identity for this window's notification (when minimized to one),
        // independent of note.id since a brand new note may still be 0L.
        val notifKey: Int = nextNotifKey()

        private var bubbleBinding: LayoutFloatingBubbleBinding? = null
        private var cardBinding: LayoutFloatingNoteBinding? = null

        // Kept alongside the bindings so a configuration change can clamp an
        // already-live window's position/size without needing to guess at
        // (or re-derive from the View) the WindowManager.LayoutParams it was
        // added with.
        private var cardParams: WindowManager.LayoutParams? = null
        private var bubbleParams: WindowManager.LayoutParams? = null

        private var cardEditFocusController: OverlayEditFocusController? = null
        private var imeResizer: ImeAwareOverlayResizer? = null
        private val saveDebouncer = Debouncer(serviceScope)
        private var isMinimizedAsNotification = false

        // Guards destroy()/prepareForShutdown() against running twice for the
        // same window - e.g. a note's own close button firing right as
        // "Close All" tears down every window - so removeView is never
        // called a second time on a view already removed, and this window's
        // final save/notification-cancel can't double up either.
        private var isDestroyed = false

        // Card and bubble are different-sized windows that replace each other on
        // every minimize/expand, so their shared on-screen position and the
        // card's own size are tracked as separate fields rather than reusing
        // either window's live LayoutParams object - aliasing the bubble's
        // (much smaller) LayoutParams as "the last known card size" was
        // previously the cause of the card reopening tiny after a bubble drag.
        private var lastWindowX: Int? = null
        private var lastWindowY: Int? = null
        private var cardWidth: Int? = null
        private var cardHeight: Int? = null

        // The card is fully torn down and re-inflated on every minimize/maximize,
        // so scroll position and caret selection have to be captured manually
        // before that happens or the note reopens at the top every time.
        private var savedScrollY = 0
        private var savedSelectionStart = -1
        private var savedSelectionEnd = -1

        // The bubble's release-to-snap-to-edge animation (see snapToEdge) runs
        // for up to 250ms after the finger lifts. Without tracking it, a
        // second drag starting mid-snap would fight the still-running
        // animator for params.x every frame (each ignoring the other's
        // writes, showing up as jitter), and closing the note mid-snap would
        // leave it updating a window that's already been torn down - harmless
        // (its updateViewLayout call is already wrapped in runCatching) but
        // sloppy. Cancelling any previous instance before starting a new one,
        // and on removeBubble(), avoids both.
        private var edgeSnapAnimator: ValueAnimator? = null

        private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

        fun attach() = showCard()

        fun expand() {
            cancelMinimizedNotification()
            if (cardBinding != null) return
            removeBubble()
            showCard()
        }

        private fun showCard() {
            try {
                val binding = LayoutFloatingNoteBinding.inflate(themedInflater)
                cardBinding = binding

                binding.editTitle.setText(note.title)
                binding.editContent.setText(note.content)
                if (savedSelectionStart >= 0) {
                    val len = binding.editContent.text?.length ?: 0
                    val end = savedSelectionEnd.coerceIn(0, len)
                    val start = savedSelectionStart.coerceIn(0, end)
                    binding.editContent.setSelection(start, end)
                }
                // Restore where the user was in the note instead of reopening at the
                // top - has to wait a frame since the EditText doesn't know its own
                // scroll range until it's actually been laid out at its new size.
                val scrollToRestore = savedScrollY
                binding.editContent.post { binding.editContent.scrollTo(0, scrollToRestore) }
                applyCardStyle(binding)
                applyContentTextSize(binding.editContent, this@FloatingNoteService)

                val undoRedo = UndoRedoManager(binding.editContent, serviceScope)
                undoRedo.reset()

                val params = WindowManager.LayoutParams(
                    cardWidth ?: dpToPx(300f), cardHeight ?: dpToPx(360f),
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = lastWindowX ?: dpToPx(40f)
                    y = lastWindowY ?: dpToPx(120f)
                    // Doesn't make WindowManager resize this window for us
                    // (it's not an Activity window, so that handshake doesn't
                    // apply) - but it's what tells the system this window
                    // cares about the IME at all, which is what
                    // ImeAwareOverlayResizer's own detection below depends
                    // on actually reporting anything useful.
                    softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        layoutInDisplayCutoutMode =
                            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
                cardWidth = params.width
                cardHeight = params.height
                lastWindowX = params.x
                lastWindowY = params.y
                cardParams = params

                setupCardDrag(binding, params)
                setupCardResize(binding, params)

                binding.buttonMore.setOnClickListener { showOverflowMenu(binding, undoRedo) }
                binding.buttonMinimize.setOnClickListener { minimizeToPreferredMode() }
                binding.buttonClose.setOnClickListener { destroy(save = true) }

                // The card starts non-focusable, like the bubble, so touches on it
                // (drag, resize, buttons) still work but Back/Home/etc. go straight
                // to whatever app is underneath instead of being swallowed - the note
                // just floats on top without taking over navigation. It only grabs
                // focus for as long as you're actually typing, so the keyboard can
                // show, and gives it back up the moment you're done.
                val resizer = ImeAwareOverlayResizer(windowManager, binding.root, params, dpToPx(CARD_MIN_SIZE_DP))
                imeResizer = resizer

                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                val editFocusController = OverlayEditFocusController(
                    windowManager, binding.root, params, imm,
                    listOf(binding.editTitle, binding.editContent),
                    onFocusGained = { resizer.onKeyboardMayShow() },
                    onFocusLost = { resizer.onKeyboardMayHide() }
                )
                editFocusController.install()
                cardEditFocusController = editFocusController

                // Only schedules the debounced save on each keystroke rather than
                // also eagerly copying the full title/content text out of the
                // Editable right here - `.toString()` on a large note's content
                // copies the *entire* text, and doing that on every character
                // typed was measurable lag for large notes. syncNoteFromCard()
                // (called from the debounced save and from captureEditorState/
                // destroy below) still always captures the latest text by the
                // time it's actually needed.
                val watcher = simpleWatcher { scheduleSave() }
                binding.editTitle.addTextChangedListener(watcher)
                binding.editContent.addTextChangedListener(watcher)

                windowManager.addView(binding.root, params)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to show floating note card", e)
                cardBinding = null
                cardParams = null
                Toast.makeText(this@FloatingNoteService, R.string.floating_note_error_toast, Toast.LENGTH_LONG).show()
                windows.remove(this)
                syncFloatingNoteIds()
                if (windows.isEmpty()) stopSelf() else updateForegroundNotification()
            }
        }

        private fun minimizeToPreferredMode() {
            when (PrefsManager.getMinimizeMode(this@FloatingNoteService)) {
                MinimizeMode.BUBBLE -> collapseToBubble()
                MinimizeMode.NOTIFICATION -> collapseToNotification()
            }
        }

        /** Also reachable from the "Minimize" action on the minimized-notification
         *  itself (switches representation to a bubble), not just from the card's
         *  own minimize button - safe to call directly since capturing editor
         *  state and tearing down the card/bubble are both no-ops when neither
         *  is currently showing. */
        fun collapseToBubble() {
            cancelMinimizedNotification()
            captureEditorState()
            removeCard()
            try {
                val binding = LayoutFloatingBubbleBinding.inflate(themedInflater)
                bubbleBinding = binding
                applyBubbleAppearance(binding, this@FloatingNoteService)

                val size = bubbleWindowSizePx(
                    this@FloatingNoteService,
                    PrefsManager.getBubbleSizeDp(this@FloatingNoteService)
                )
                val params = WindowManager.LayoutParams(
                    size, size,
                    overlayType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    x = lastWindowX ?: dpToPx(BUBBLE_EDGE_MARGIN_DP)
                    y = lastWindowY ?: dpToPx(120f)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                        layoutInDisplayCutoutMode =
                            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                    }
                }
                bubbleParams = params

                setupBubbleDrag(binding, params)
                windowManager.addView(binding.root, params)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to show floating bubble", e)
                bubbleBinding = null
                bubbleParams = null
                windows.remove(this)
                syncFloatingNoteIds()
                if (windows.isEmpty()) stopSelf() else updateForegroundNotification()
            }
        }

        /** Minimize by fully removing the overlay and showing a regular status-bar
         *  notification instead of a floating bubble. Tapping it re-expands the
         *  card; swiping it away closes the note (same as the bubble's close). */
        private fun collapseToNotification() {
            captureEditorState()
            removeCard()
            removeBubble()
            val expandIntent = expandIntentFor(notifKey)
            val dismissIntent = PendingIntent.getService(
                this@FloatingNoteService, notifKey + 1,
                Intent(this@FloatingNoteService, FloatingNoteService::class.java)
                    .setAction(ACTION_DISMISS_NOTE)
                    .putExtra(EXTRA_WINDOW_KEY, notifKey),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            // Lets the note switch straight to the other minimized representation
            // (bubble) from the notification itself, mirroring the card's own
            // minimize/close pair instead of only offering a way back to full size.
            val bubbleIntent = PendingIntent.getService(
                this@FloatingNoteService, notifKey + 2,
                Intent(this@FloatingNoteService, FloatingNoteService::class.java)
                    .setAction(ACTION_MINIMIZE_TO_BUBBLE)
                    .putExtra(EXTRA_WINDOW_KEY, notifKey),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notification = NotificationCompat.Builder(this@FloatingNoteService, MINIMIZED_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_note)
                .setContentTitle(displayTitle())
                .setContentText(note.content.take(80).ifBlank { getString(R.string.empty_note_placeholder) })
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setOngoing(false)
                .setAutoCancel(true)
                .setContentIntent(expandIntent)
                .setDeleteIntent(dismissIntent)
                .addAction(0, getString(R.string.notification_minimize_action), bubbleIntent)
                .addAction(0, getString(R.string.notification_maximize_action), expandIntent)
                .build()
            getSystemService(NotificationManager::class.java).notify(notifKey, notification)
            isMinimizedAsNotification = true
        }

        private fun cancelMinimizedNotification() {
            if (!isMinimizedAsNotification) return
            getSystemService(NotificationManager::class.java).cancel(notifKey)
            isMinimizedAsNotification = false
        }

        private fun setupCardDrag(binding: LayoutFloatingNoteBinding, params: WindowManager.LayoutParams) {
            setupWindowDrag(binding.dragHandle, binding.root, params, windowManager, onPositionChanged = { x, y ->
                lastWindowX = x
                lastWindowY = y
            })
        }

        private fun setupCardResize(binding: LayoutFloatingNoteBinding, params: WindowManager.LayoutParams) {
            var startWidth = 0
            var startHeight = 0
            var touchX = 0f
            var touchY = 0f
            val minSize = dpToPx(CARD_MIN_SIZE_DP)
            val maxSize = dpToPx(CARD_MAX_SIZE_DP)
            // updateViewLayout forces a full cross-process relayout of the card
            // (including PatternedEditText's ruled-line redraw), which is too
            // expensive to run on every raw ACTION_MOVE - throttled to one call
            // per rendered frame instead, see ViewLayoutThrottler.
            val layoutThrottler = ViewLayoutThrottler(windowManager, binding.root, params)
            binding.resizeHandle.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        startWidth = params.width
                        startHeight = params.height
                        touchX = event.rawX
                        touchY = event.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.width = (startWidth + (event.rawX - touchX).toInt()).coerceIn(minSize, maxSize)
                        params.height = (startHeight + (event.rawY - touchY).toInt()).coerceIn(minSize, maxSize)
                        cardWidth = params.width
                        cardHeight = params.height
                        layoutThrottler.requestUpdate()
                        true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        layoutThrottler.applyNow()
                        true
                    }
                    else -> false
                }
            }
        }

        private fun setupBubbleDrag(binding: LayoutFloatingBubbleBinding, params: WindowManager.LayoutParams) {
            setupWindowDrag(
                binding.root, binding.root, params, windowManager,
                onPositionChanged = { x, y ->
                    lastWindowX = x
                    lastWindowY = y
                }
            ) { moved ->
                if (moved) {
                    // Screen width is read fresh here at release time rather than
                    // captured once when the drag started, so a rotation that
                    // happens mid-drag doesn't snap to an edge computed from the
                    // now-stale old orientation's width.
                    snapToEdge(binding, params, resources.displayMetrics.widthPixels)
                } else {
                    expand()
                }
            }
        }

        private fun snapToEdge(binding: LayoutFloatingBubbleBinding, params: WindowManager.LayoutParams, screenWidth: Int) {
            edgeSnapAnimator?.cancel()
            val margin = dpToPx(BUBBLE_EDGE_MARGIN_DP)
            val targetX = if (params.x + params.width / 2 < screenWidth / 2) {
                margin
            } else {
                screenWidth - params.width - margin
            }
            val animator = ValueAnimator.ofInt(params.x, targetX)
            animator.interpolator = OvershootInterpolator(0.9f)
            animator.duration = 250
            animator.addUpdateListener {
                params.x = it.animatedValue as Int
                runCatching { windowManager.updateViewLayout(binding.root, params) }
                lastWindowX = params.x
            }
            edgeSnapAnimator = animator
            animator.start()
        }

        /** Repositions (and, for the card, resizes) this window back within the
         *  current screen bounds - called after a configuration change, since a
         *  window positioned/sized for the old orientation or window size could
         *  otherwise end up partly or fully off-screen where it can no longer be
         *  seen or dragged back into view. */
        fun clampToScreenBounds() {
            val metrics = resources.displayMetrics
            cardBinding?.root?.let { view -> cardParams?.let { clampWindowToScreen(view, it, metrics, resizable = true) } }
            bubbleBinding?.root?.let { view -> bubbleParams?.let { clampWindowToScreen(view, it, metrics, resizable = false) } }
        }

        private fun clampWindowToScreen(
            view: View,
            params: WindowManager.LayoutParams,
            metrics: DisplayMetrics,
            resizable: Boolean
        ) {
            var changed = false
            if (resizable) {
                val minSizePx = dpToPx(CARD_MIN_SIZE_DP)
                val maxWidthPx = minOf(dpToPx(CARD_MAX_SIZE_DP), metrics.widthPixels).coerceAtLeast(minSizePx)
                val maxHeightPx = minOf(dpToPx(CARD_MAX_SIZE_DP), metrics.heightPixels).coerceAtLeast(minSizePx)
                val newWidth = params.width.coerceIn(minSizePx, maxWidthPx)
                val newHeight = params.height.coerceIn(minSizePx, maxHeightPx)
                if (newWidth != params.width || newHeight != params.height) {
                    params.width = newWidth
                    params.height = newHeight
                    cardWidth = newWidth
                    cardHeight = newHeight
                    changed = true
                }
            }
            val maxX = (metrics.widthPixels - params.width).coerceAtLeast(0)
            val maxY = (metrics.heightPixels - params.height).coerceAtLeast(0)
            val clampedX = params.x.coerceIn(0, maxX)
            val clampedY = params.y.coerceIn(0, maxY)
            if (clampedX != params.x || clampedY != params.y) {
                params.x = clampedX
                params.y = clampedY
                changed = true
            }
            if (changed) {
                runCatching { windowManager.updateViewLayout(view, params) }
                lastWindowX = params.x
                lastWindowY = params.y
            }
        }

        /** The undo/redo/numbered-list/copy/paste actions that used to be their
         *  own toolbar buttons now live behind this single overflow button (see
         *  layout comment) - same underlying actions as the full-screen editor,
         *  just presented as a menu instead of an icon row so the drag handle
         *  fits at any card width. */
        private fun showOverflowMenu(binding: LayoutFloatingNoteBinding, undoRedo: UndoRedoManager) {
            val editText = binding.editContent
            val popup = PopupMenu(themedContext, binding.buttonMore)
            popup.menu.add(0, ID_UNDO, 0, R.string.undo).isEnabled = undoRedo.canUndo()
            popup.menu.add(0, ID_REDO, 1, R.string.redo).isEnabled = undoRedo.canRedo()
            popup.menu.add(0, ID_NUMBERED_LIST, 2, R.string.insert_numbered_list)
            popup.menu.add(0, ID_COPY, 3, R.string.copy_note)
            popup.menu.add(0, ID_PASTE, 4, R.string.paste_note)
            popup.menu.add(0, ID_SWITCH_NOTE, 5, R.string.switch_note)
            popup.menu.add(0, ID_NOTE_COLOR, 6, R.string.note_style_label)
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    ID_UNDO -> undoRedo.undo()
                    ID_REDO -> undoRedo.redo()
                    ID_NUMBERED_LIST -> if (!expandNumberedListToken(editText)) {
                        Toast.makeText(this@FloatingNoteService, R.string.numbered_list_hint, Toast.LENGTH_SHORT).show()
                    }
                    ID_COPY -> if (copySelectionOrAll(editText, this@FloatingNoteService)) {
                        Toast.makeText(this@FloatingNoteService, R.string.copied_to_clipboard, Toast.LENGTH_SHORT).show()
                    }
                    ID_PASTE -> if (!pasteFromClipboard(editText, this@FloatingNoteService)) {
                        Toast.makeText(this@FloatingNoteService, R.string.clipboard_empty_hint, Toast.LENGTH_SHORT).show()
                    }
                    ID_SWITCH_NOTE -> showSwitchNoteMenu(binding)
                    ID_NOTE_COLOR -> showNoteStylePicker(binding.buttonMore, note.styleIndex) { picked ->
                        note = note.copy(styleIndex = picked)
                        applyCardStyle(binding)
                        scheduleSave()
                    }
                }
                true
            }
            // Showing this popup hands window focus to it for as long as it's
            // up, which OverlayEditFocusController's window-focus listener
            // can't otherwise tell apart from the user tapping away and
            // leaving edit mode - see onTransientPopupOpened/Closed. Without
            // this, opening the menu itself cleared the very selection the
            // menu's own Copy item is meant to act on.
            cardEditFocusController?.onTransientPopupOpened()
            popup.setOnDismissListener { cardEditFocusController?.onTransientPopupClosed() }
            popup.show()
        }

        /** Lists every other saved note so this window can jump straight to
         *  editing one of them - see [switchToNote]. The note currently open
         *  in this window is left out since "switch to what's already here"
         *  isn't a real option; brand-new, not-yet-saved notes open
         *  elsewhere aren't listed either, the same as anywhere else in the
         *  app that lists notes from the DB rather than from memory. */
        private fun showSwitchNoteMenu(binding: LayoutFloatingNoteBinding) {
            serviceScope.launch {
                val notes = repository.getAll().filter { it.id != noteId }
                if (notes.isEmpty()) {
                    Toast.makeText(this@FloatingNoteService, R.string.no_other_notes_toast, Toast.LENGTH_SHORT).show()
                    return@launch
                }
                val popup = PopupMenu(themedContext, binding.buttonMore)
                notes.forEachIndexed { index, candidate ->
                    popup.menu.add(0, index, index, candidate.title.ifBlank { getString(R.string.untitled_note) })
                }
                popup.setOnMenuItemClickListener { item ->
                    switchToNote(notes[item.itemId].id)
                    true
                }
                // Same reasoning as showOverflowMenu's own listener - this
                // popup owning window focus for as long as it's up must not
                // register with OverlayEditFocusController as "the user
                // tapped away", or picking a note would also blur/dismiss
                // the card right under it.
                cardEditFocusController?.onTransientPopupOpened()
                popup.setOnDismissListener { cardEditFocusController?.onTransientPopupClosed() }
                popup.show()
            }
        }

        /** Swaps this window's note for [targetId] in place - same on-screen
         *  position and size, no close/reopen - after saving whatever was
         *  open here first. The card is still torn down and re-inflated
         *  (same as minimize/maximize already does) rather than pushing the
         *  new title/content into the live views by hand, so this reuses
         *  [showCard]'s one, already-correct setup path (style, undo/redo,
         *  watchers, focus controller) instead of a second copy of it that
         *  could drift out of sync.
         *
         *  If [targetId] is already open in another window, that window is
         *  brought forward instead of switching into it here - editing the
         *  same note from two uncoordinated windows at once is exactly what
         *  floatingNoteIds/isNoteFloating exists to prevent (see
         *  [showNote]), and this would otherwise be a second, unguarded way
         *  around that. */
        private fun switchToNote(targetId: Long) {
            if (targetId == noteId) return
            windows.find { it.noteId == targetId && targetId != 0L }?.let {
                Toast.makeText(this@FloatingNoteService, R.string.note_already_floating_toast, Toast.LENGTH_SHORT).show()
                it.expand()
                return
            }
            // Cancels any autosave still pending for the note being switched
            // away from - same reasoning as destroy()'s own upfront cancel:
            // once persistOrDeleteIfEmpty() below has saved it, a stale
            // debounced save firing later on the *new* note field would at
            // best be a wasted no-op write, and there's no reason to leave
            // it queued.
            saveDebouncer.cancel()
            serviceScope.launch {
                persistOrDeleteIfEmpty()
                note = repository.getById(targetId) ?: Note()
                savedScrollY = 0
                savedSelectionStart = -1
                savedSelectionEnd = -1
                removeCard()
                showCard()
                syncFloatingNoteIds()
                updateForegroundNotification()
            }
        }

        private fun applyCardStyle(binding: LayoutFloatingNoteBinding) {
            binding.cardBackground.clipToRoundedCorners(resources.getDimension(R.dimen.card_corner_radius_floating))
            val style = PaperStyles.effective(this@FloatingNoteService, note.styleIndex)
            val color = ContextCompat.getColor(this@FloatingNoteService, style.coverColor)
            binding.dragHandle.setAccent(
                color, resources.getDimension(R.dimen.card_corner_radius_floating), CornerAccentBar.RoundedCorners.TOP_EDGE
            )
            binding.colorDot.backgroundTintList = ColorStateList.valueOf(color)
            binding.editContent.pattern = style.pattern
        }

        /** Reads the card's live title/content into [note] - called right before
         *  the card is torn down (minimize/close) and at the start of the
         *  debounced save, rather than on every keystroke. `.toString()` on a
         *  large note's Editable copies the *entire* text, and doing that on
         *  every single character typed was a real, avoidable cost for large
         *  notes. Deferring it to these two points (a ~600ms typing pause, or
         *  the card actually going away) still always captures the latest text
         *  by the time it's needed. */
        private fun syncNoteFromCard() {
            cardBinding?.let { binding ->
                note = note.copy(
                    title = binding.editTitle.text.toString(),
                    content = binding.editContent.text.toString()
                )
            }
        }

        /** Refreshes [note] from the still-live card view, then saves/deletes
         *  it via the shared, conflict-aware
         *  [NoteRepository.saveOrDeleteIfEmpty] - see there for what
         *  "conflict-aware" means and why it matters for a
         *  background-autosaving window like this one (it can no longer
         *  clobber a pin toggle or resurrect a note deleted from the main
         *  list while this window held its own possibly-stale copy). Used
         *  by the debounced auto-save and by a single window's own
         *  close/dismiss ([destroy]); the whole-service shutdown path uses
         *  [persistFinalSnapshotAsync] instead, since by then the card view
         *  is already gone and the save must not depend on serviceScope. */
        private suspend fun persistOrDeleteIfEmpty() {
            syncNoteFromCard()
            note = repository.saveOrDeleteIfEmpty(note)
        }

        private fun scheduleSave() {
            saveDebouncer.schedule { persistOrDeleteIfEmpty() }
        }

        /** Tears the window down. When [save] is true, returns the
         *  [Deferred] for the final save (Deferred is a Job, so this keeps
         *  the same return type callers already use) so callers that want
         *  to know the outcome can await it - though most, like this app's
         *  own call sites, don't need to. */
        fun destroy(save: Boolean): Job? {
            if (isDestroyed) return null
            isDestroyed = true
            saveDebouncer.cancel()
            syncNoteFromCard()
            // Durable (see NoteRepository.saveOrDeleteIfEmptyDurable), not
            // serviceScope: stopSelf() below can lead to this Service's
            // onDestroy() - and therefore serviceScope.cancel() - running
            // before a serviceScope-launched save here would have finished,
            // the same race onDestroy()'s own shutdown save has to avoid.
            val job = if (save) repository.saveOrDeleteIfEmptyDurable(note) else null
            cancelMinimizedNotification()
            removeCard()
            removeBubble()
            windows.remove(this)
            syncFloatingNoteIds()
            if (windows.isEmpty()) stopSelf() else updateForegroundNotification()
            return job
        }

        /** Tears down this window's views, listeners, and notification
         *  synchronously, without touching [windows] or [serviceScope] -
         *  used only by FloatingNoteService.onDestroy(), where the *whole*
         *  service is shutting down at once rather than just this one note.
         *  Deliberately doesn't launch the final save itself - call
         *  [persistFinalSnapshotAsync] afterward instead, see onDestroy(). */
        fun prepareForShutdown() {
            if (isDestroyed) return
            isDestroyed = true
            saveDebouncer.cancel()
            syncNoteFromCard()
            cancelMinimizedNotification()
            removeCard()
            removeBubble()
        }

        /** Fires this window's final save on NoteRepository's durable scope
         *  (see [NoteRepository.saveOrDeleteIfEmptyDurable]) - called from
         *  FloatingNoteService.onDestroy() after [prepareForShutdown] has
         *  already captured [note]'s latest content and torn down this
         *  window's views. Fire-and-forget by design: nothing is left
         *  alive here to hand a result back to once the whole service is
         *  going away, so unlike NoteEditorActivity's use of the same
         *  repository method, there is nothing that needs to await() this. */
        fun persistFinalSnapshotAsync() {
            repository.saveOrDeleteIfEmptyDurable(note)
        }

        private fun captureEditorState() {
            cardBinding?.editContent?.let {
                savedScrollY = it.scrollY
                savedSelectionStart = it.selectionStart
                savedSelectionEnd = it.selectionEnd
            }
            syncNoteFromCard()
        }

        // removeViewImmediate (rather than plain removeView) matters most
        // here: the plain version only *schedules* a window's detachment on
        // the calling thread's own Looper rather than applying it before
        // returning, so anything that later blocks that Looper (see the
        // onDestroy() comment above the runBlocking deadlock this replaced)
        // could leave the removal stuck pending forever - an overlay that's
        // still fully attached and drawn, just with no live app behind it to
        // respond to touches. removeViewImmediate applies the detachment
        // synchronously instead, so by the time this call returns there's
        // nothing left in WindowManager for a later hang on this thread to
        // strand.
        private fun removeCard() {
            cardEditFocusController?.uninstall()
            cardEditFocusController = null
            imeResizer?.uninstall()
            imeResizer = null
            cardBinding?.root?.let { view ->
                runCatching { windowManager.removeViewImmediate(view) }
                    .onFailure { Log.w(TAG, "Card view already detached", it) }
            }
            cardBinding = null
            cardParams = null
        }

        private fun removeBubble() {
            edgeSnapAnimator?.cancel()
            edgeSnapAnimator = null
            bubbleBinding?.root?.let { view ->
                runCatching { windowManager.removeViewImmediate(view) }
                    .onFailure { Log.w(TAG, "Bubble view already detached", it) }
            }
            bubbleBinding = null
            bubbleParams = null
        }
    }

    companion object {
        const val ACTION_SHOW_NOTE = "com.jarry.floatnote.action.SHOW_NOTE"
        const val ACTION_CLOSE_ALL = "com.jarry.floatnote.action.CLOSE_ALL"
        const val ACTION_EXPAND_NOTE = "com.jarry.floatnote.action.EXPAND_NOTE"
        const val ACTION_DISMISS_NOTE = "com.jarry.floatnote.action.DISMISS_NOTE"
        const val ACTION_MINIMIZE_TO_BUBBLE = "com.jarry.floatnote.action.MINIMIZE_TO_BUBBLE"
        const val EXTRA_NOTE_ID = "extra_note_id"
        const val EXTRA_WINDOW_KEY = "extra_window_key"
        private const val TAG = "FloatingNoteService"
        private const val CHANNEL_ID = "floating_notes_channel"
        private const val MINIMIZED_CHANNEL_ID = "minimized_notes_channel"
        private const val NOTIF_ID = 42

        private const val CARD_MIN_SIZE_DP = 140f
        private const val CARD_MAX_SIZE_DP = 500f

        // Item ids for the overflow popup menu (see showOverflowMenu) - just
        // need to be distinct from one another and from Menu.NONE (0) as a
        // group id, not tied to any resource.
        private const val ID_UNDO = 1
        private const val ID_REDO = 2
        private const val ID_NUMBERED_LIST = 3
        private const val ID_COPY = 4
        private const val ID_PASTE = 5
        private const val ID_SWITCH_NOTE = 6
        private const val ID_NOTE_COLOR = 7

        // A back-gesture swipe starting inside the bubble's touch bounds can get
        // captured by the bubble instead of reaching the system's edge-back
        // gesture detector, so the bubble is kept clear of the true screen edge
        // instead of sitting flush against it.
        private const val BUBBLE_EDGE_MARGIN_DP = 16f

        // Which note ids currently have a live floating window (card, bubble,
        // or minimized-to-notification) - checked before opening a note in
        // the regular full-screen editor so the same note is never edited in
        // two independent, uncoordinated places at once. Each editor holds
        // and saves its own in-memory copy on its own schedule, so without
        // this check, whichever one happened to save last would silently
        // overwrite the other's changes. Plain mutableSetOf is safe here
        // without extra synchronization since every read/write - from this
        // service or from an Activity - happens on the main thread.
        private val floatingNoteIds = mutableSetOf<Long>()

        /** Whether [noteId] currently has a live floating window. In-process
         *  only, by design - there's no binder/broadcast API since only this
         *  app itself ever needs the answer. */
        fun isNoteFloating(noteId: Long): Boolean = noteId != 0L && noteId in floatingNoteIds

        // Notification/PendingIntent request codes for minimized notes, kept well
        // clear of NOTIF_ID and independent of note.id (which can be 0 for an
        // unsaved note). Each window consumes a block of 3 consecutive codes -
        // notifKey (expand), notifKey+1 (dismiss), notifKey+2 (minimize to
        // bubble) - so no two windows' PendingIntent request codes ever collide.
        private val notifKeySeq = AtomicInteger(1000)
        private fun nextNotifKey(): Int = notifKeySeq.getAndAdd(3)
    }
}
