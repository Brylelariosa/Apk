package com.jarry.floatnote.util

import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding

/** Applies the system bars' top inset as this view's top padding, keeping it
 *  clear of the status bar in edge-to-edge layouts. */
fun View.applyTopSystemBarPadding() {
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        v.updatePadding(top = insets.getInsets(WindowInsetsCompat.Type.systemBars()).top)
        insets
    }
}

/** Applies the system bars' bottom inset as this view's bottom padding,
 *  keeping it clear of the nav bar / gesture area in edge-to-edge layouts. */
fun View.applyBottomSystemBarPadding() {
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        v.updatePadding(bottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom)
        insets
    }
}

/** Applies the on-screen keyboard's height as this view's bottom padding
 *  while it's showing (zero otherwise), so whatever's above it - here,
 *  editorRoot, shrinking a weight="1" child (the note card) rather than
 *  the fixed-height toolbar/bottomBar around it - actually gets smaller
 *  instead of just sitting underneath the keyboard unnoticed.
 *
 *  This is the one piece automatic keyboard-avoidance depends on that
 *  `android:windowSoftInputMode="adjustResize"` alone (already set in the
 *  manifest) no longer provides by itself: adjustResize's automatic
 *  resize-and-pad behavior was designed for windows that fit system
 *  content instead of drawing edge-to-edge, and edge-to-edge is exactly
 *  what this app already opts into elsewhere (see the system-bar padding
 *  functions above - system bars need the exact same manual treatment, for
 *  the exact same reason). Without a view somewhere actually getting
 *  smaller in response, the EditText inside never finds out part of it is
 *  now covered, and its own built-in scroll-to-cursor behavior - the same
 *  logic that keeps the caret visible while typing in any ordinary,
 *  non-edge-to-edge screen - has nothing to react to. */
fun View.applyImeBottomPadding() {
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, insets ->
        v.updatePadding(bottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom)
        insets
    }
}
