package com.jarry.floatnote.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.widget.LinearLayout

/**
 * A solid-colored accent bar - the floating card's drag handle, or the
 * editor/list card's left-edge spine - used in one of two fundamentally
 * different ways:
 *
 * [RoundedCorners.TOP_EDGE] traces the parent card's own corner curve -
 * appropriate when this bar's own width/height comfortably exceeds the
 * corner radius (the drag handle: 36dp tall against an 18dp radius), so the
 * arc isn't being squeezed into less room than it needs.
 *
 * [RoundedCorners.PILL] gives up on matching the card's corner at all and
 * draws a fully self-rounded capsule instead, proportioned to its *own*
 * size (radius = half its shorter dimension) - for the editor/list spine,
 * which at 6dp wide is narrower than the 14dp corner radius it used to try
 * to match. That's not fixable by drawing the match more carefully: a
 * quarter-circle arc of radius R physically cannot come within R of a
 * corner using a shape narrower than R - the arc simply hasn't curved back
 * far enough yet at that height, no matter how correctly it's drawn. Rather
 * than accept the resulting sliver of the card's paper background showing
 * through at the very top/bottom, the spine is drawn as a standalone pill,
 * inset a bit from the card's corners in the XML (`layout_marginTop`/
 * `Bottom`) so it never enters the region a 6dp shape can't correctly
 * occupy in the first place.
 */
class CornerAccentBar @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    enum class RoundedCorners { TOP_EDGE, LEFT_EDGE, PILL }

    private var cornerRadiusPx = 0f
    private var roundedCorners = RoundedCorners.TOP_EDGE
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val drawRect = RectF()

    init {
        // ViewGroups skip onDraw() entirely by default as an optimization,
        // on the assumption a pure container has nothing of its own to
        // paint - needs to be turned off since this one does.
        setWillNotDraw(false)
    }

    /** Sets the fill color and how this bar's corners should be rounded -
     *  see the class doc for the difference between the two approaches.
     *  [radiusPx] is unused for [RoundedCorners.PILL], which computes its
     *  own radius from its own size instead. */
    fun setAccent(color: Int, radiusPx: Float, corners: RoundedCorners) {
        cornerRadiusPx = radiusPx
        roundedCorners = corners
        paint.color = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return

        if (roundedCorners == RoundedCorners.PILL) {
            val radius = minOf(w, h) / 2f
            drawRect.set(0f, 0f, w.toFloat(), h.toFloat())
            path.reset()
            path.addRoundRect(drawRect, radius, radius, Path.Direction.CW)
            canvas.drawPath(path, paint)
            return
        }

        if (cornerRadiusPx <= 0f) {
            canvas.drawColor(paint.color)
            return
        }
        // A small safety margin past the mathematical minimum (2x radius)
        // so the arc has clean room to fully resolve before this view's own
        // bounds crop it, rather than sitting exactly on the boundary where
        // rounding error could leave a stray unrounded pixel or two.
        val drawnSize = cornerRadiusPx * 2 + 8f
        val drawnWidth = maxOf(w.toFloat(), drawnSize)
        val drawnHeight = maxOf(h.toFloat(), drawnSize)
        val topLeft = cornerRadiusPx
        val topRight = if (roundedCorners == RoundedCorners.TOP_EDGE) cornerRadiusPx else 0f
        val bottomLeft = if (roundedCorners == RoundedCorners.LEFT_EDGE) cornerRadiusPx else 0f
        drawRect.set(0f, 0f, drawnWidth, drawnHeight)
        path.reset()
        path.addRoundRect(
            drawRect,
            floatArrayOf(
                topLeft, topLeft,
                topRight, topRight,
                0f, 0f,
                bottomLeft, bottomLeft
            ),
            Path.Direction.CW
        )
        canvas.drawPath(path, paint)
    }
}
