package com.jarry.floatnote.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.widget.LinearLayout

/**
 * A solid-colored accent bar - the floating card's drag handle, or the
 * editor/list card's left-edge spine - whose corners touching the parent
 * card's own rounded corner draw a matching curve, even where the bar
 * itself is far narrower or shorter than that curve's radius (6dp wide
 * against a 14dp card corner radius, for the spine).
 *
 * A plain background color with its own rounded corners - the obvious way
 * to do this, and what this app tried twice before - doesn't actually
 * work: a rounded-rect corner radius is relative to *its own* shape's
 * bounds, and a radius bigger than half the shape it's applied to can't
 * sweep a normal quarter-circle arc - it degenerates into something that
 * recedes far more aggressively than a properly-proportioned corner does.
 * The result doesn't match the card's own (correctly proportioned, since
 * the card itself is hundreds of dp across) corner curve at all, leaving a
 * sliver of the card's paper-colored background visible between the two
 * mismatched curves, right where the bar was supposed to reach into the
 * corner. No amount of clipping fixes this - clipping only trims excess,
 * it can't make a too-narrow shape reach further into a curve it's
 * mathematically too small to draw in the first place.
 *
 * This draws the full, correctly-proportioned rounded rect instead - as
 * large as the actual corner radius calls for, not squashed down to this
 * bar's own narrow width or height - anchored at this view's own top-left,
 * and leans on the one clipping mechanism that's actually guaranteed to
 * work regardless of what any card/outline implementation does: a normal
 * View can never draw outside its own laid-out bounds within its parent.
 * Only the slice that's actually this bar's real size ends up visible, and
 * that slice traces the *same* curve the card itself does, because it's
 * computed at the same scale instead of a squashed one.
 */
class CornerAccentBar @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {

    enum class RoundedCorners { TOP_EDGE, LEFT_EDGE }

    private var cornerRadiusPx = 0f
    private var roundedCorners = RoundedCorners.TOP_EDGE
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val drawRect = RectF()

    init {
        // ViewGroups skip onDraw() entirely by default as an optimization,
        // on the assumption a pure container has nothing of its own to
        // paint - needs to be turned off since this one does.
        setWillNotDraw(false)
    }

    /** Sets the fill color and which of this bar's own corners should match
     *  the parent card's [radiusPx] rounding - see the class doc for why
     *  this can't just be a rounded background color. */
    fun setAccent(color: Int, radiusPx: Float, corners: RoundedCorners) {
        cornerRadiusPx = radiusPx
        roundedCorners = corners
        paint.color = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        if (cornerRadiusPx <= 0f) {
            canvas.drawColor(paint.color)
            return
        }
        // A small safety margin past the mathematical minimum (2x radius)
        // so the arc has clean room to fully resolve before this view's own
        // bounds crop it, rather than sitting exactly on the boundary where
        // rounding error could leave a stray unrounded pixel or two.
        val drawnSize = cornerRadiusPx * 2 + 8f
        val drawnWidth = maxOf(w.toFloat(), drawnSize)
        val drawnHeight = maxOf(h.toFloat(), drawnSize)
        val topLeft = cornerRadiusPx
        val topRight = if (roundedCorners == RoundedCorners.TOP_EDGE) cornerRadiusPx else 0f
        val bottomLeft = if (roundedCorners == RoundedCorners.LEFT_EDGE) cornerRadiusPx else 0f
        drawRect.set(0f, 0f, drawnWidth, drawnHeight)
        path.reset()
        path.addRoundRect(
            drawRect,
            floatArrayOf(
                topLeft, topLeft,
                topRight, topRight,
                0f, 0f,
                bottomLeft, bottomLeft
            ),
            Path.Direction.CW
        )
        canvas.drawPath(path, paint)
    }
}
