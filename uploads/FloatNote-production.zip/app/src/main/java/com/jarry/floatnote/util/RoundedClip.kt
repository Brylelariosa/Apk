package com.jarry.floatnote.util

import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider

/**
 * Clips this view - background, foreground, and children alike - to a
 * rounded rect of [radiusPx].
 *
 * `android:clipToOutline="true"` in XML looks like it should be enough for
 * a MaterialCardView, but in practice doesn't reliably stick: XML
 * attributes are applied inside View's own constructor, before
 * MaterialCardView's *later* shape/elevation setup (which manages its own
 * compat shadow rather than relying on the platform's native
 * elevation-from-outline) runs and can silently reset it back off. Setting
 * this explicitly in code, after inflation, applies last and isn't at the
 * mercy of that ordering.
 *
 * A plain lambda-based ViewOutlineProvider (rather than computing the
 * outline once, up front) matters here too: it's re-invoked by the
 * platform on every size change, so this still clips correctly through a
 * card resize instead of clipping to whatever size the view happened to be
 * the moment this was called.
 */
fun View.clipToRoundedCorners(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            if (view.width > 0 && view.height > 0) {
                outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
            }
        }
    }
    clipToOutline = true
}
