package com.jarry.floatnote.util

import android.content.Context
import com.jarry.floatnote.R

/** The background pattern drawn on the writing surface by PatternedEditText. */
enum class PaperPattern { RULED, GRID, DOT, BLANK }

/** A "notebook" preset: a cover color (list card spine / editor frame / floating
 *  header) paired with a paper pattern for the writing surface. */
data class PaperStyle(
    val label: String,
    val coverColor: Int,
    val pattern: PaperPattern
)

object PaperStyles {
    val all = listOf(
        PaperStyle("Orange Book", R.color.cover_orange, PaperPattern.RULED),
        PaperStyle("Indigo Ruled", R.color.cover_indigo, PaperPattern.RULED),
        PaperStyle("Forest Grid", R.color.cover_forest, PaperPattern.GRID),
        PaperStyle("Charcoal Dot", R.color.cover_charcoal, PaperPattern.DOT),
        PaperStyle("Kraft Blank", R.color.cover_kraft, PaperPattern.BLANK),
        PaperStyle("Rose Ruled", R.color.cover_rose, PaperPattern.RULED)
    )

    fun get(index: Int): PaperStyle = all.getOrElse(index) { all[0] }

    /** The single app-wide style currently chosen in Settings. */
    fun current(context: Context): PaperStyle = get(PrefsManager.getGlobalStyleIndex(context))

    /** A specific note's own style - its per-note override in
     *  [noteStyleIndex] if it has one (>= 0), otherwise whatever's
     *  currently chosen app-wide in Settings. */
    fun effective(context: Context, noteStyleIndex: Int): PaperStyle =
        if (noteStyleIndex >= 0) get(noteStyleIndex) else current(context)
}
