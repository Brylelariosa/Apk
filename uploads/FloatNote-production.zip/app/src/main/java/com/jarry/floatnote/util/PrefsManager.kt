package com.jarry.floatnote.util

import android.content.Context
import com.jarry.floatnote.data.NoteSortOrder

/** How a floating note behaves when the user taps minimize. */
enum class MinimizeMode { BUBBLE, NOTIFICATION }

object PrefsManager {
    private const val PREFS = "floatnote_prefs"
    private const val KEY_FLOATING_MODE = "floating_mode"
    private const val KEY_GLOBAL_STYLE = "global_style_index"
    private const val KEY_MINIMIZE_MODE = "minimize_mode"
    private const val KEY_CONTENT_TEXT_SIZE = "content_text_size_sp"
    private const val KEY_BUBBLE_SIZE = "bubble_size_dp"
    private const val KEY_BUBBLE_OPACITY = "bubble_opacity_percent"
    private const val KEY_SORT_ORDER = "note_sort_order"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isFloatingModeEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_FLOATING_MODE, false)

    fun setFloatingModeEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_FLOATING_MODE, enabled).apply()
    }

    /** One app-wide paper style (cover color + pattern) used by every note,
     *  chosen once in Settings instead of per-note. */
    fun getGlobalStyleIndex(context: Context): Int =
        prefs(context).getInt(KEY_GLOBAL_STYLE, 0)

    fun setGlobalStyleIndex(context: Context, index: Int) {
        prefs(context).edit().putInt(KEY_GLOBAL_STYLE, index).apply()
    }

    fun getMinimizeMode(context: Context): MinimizeMode {
        val stored = prefs(context).getString(KEY_MINIMIZE_MODE, null)
        return runCatching { MinimizeMode.valueOf(stored ?: "") }.getOrDefault(MinimizeMode.BUBBLE)
    }

    fun setMinimizeMode(context: Context, mode: MinimizeMode) {
        prefs(context).edit().putString(KEY_MINIMIZE_MODE, mode.name).apply()
    }

    fun getSortOrder(context: Context): NoteSortOrder {
        val stored = prefs(context).getString(KEY_SORT_ORDER, null)
        return runCatching { NoteSortOrder.valueOf(stored ?: "") }.getOrDefault(NoteSortOrder.RECENTLY_EDITED)
    }

    fun setSortOrder(context: Context, order: NoteSortOrder) {
        prefs(context).edit().putString(KEY_SORT_ORDER, order.name).apply()
    }

    /** One app-wide note content text size (sp), same idea as [getGlobalStyleIndex]. */
    fun getContentTextSizeSp(context: Context): Float =
        prefs(context).getFloat(KEY_CONTENT_TEXT_SIZE, DEFAULT_CONTENT_TEXT_SIZE_SP)

    fun setContentTextSizeSp(context: Context, sizeSp: Float) {
        prefs(context).edit().putFloat(KEY_CONTENT_TEXT_SIZE, sizeSp).apply()
    }

    /** The floating bubble's visible size in dp - see util/BubbleAppearance.kt. */
    fun getBubbleSizeDp(context: Context): Float =
        prefs(context).getFloat(KEY_BUBBLE_SIZE, DEFAULT_BUBBLE_SIZE_DP)

    fun setBubbleSizeDp(context: Context, sizeDp: Float) {
        prefs(context).edit().putFloat(KEY_BUBBLE_SIZE, sizeDp).apply()
    }

    /** The floating bubble's opacity as a percent (0-100) - see util/BubbleAppearance.kt. */
    fun getBubbleOpacityPercent(context: Context): Int =
        prefs(context).getInt(KEY_BUBBLE_OPACITY, DEFAULT_BUBBLE_OPACITY_PERCENT)

    fun setBubbleOpacityPercent(context: Context, percent: Int) {
        prefs(context).edit().putInt(KEY_BUBBLE_OPACITY, percent).apply()
    }
}
