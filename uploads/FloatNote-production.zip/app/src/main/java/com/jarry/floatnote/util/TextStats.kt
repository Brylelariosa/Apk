package com.jarry.floatnote.util

import android.content.Context
import com.jarry.floatnote.R

/** Words: runs of non-whitespace, the same definition most word processors
 *  use - not e.g. split-on-single-space, which would overcount a run of
 *  multiple spaces as extra empty "words". */
fun wordCount(text: CharSequence): Int {
    if (text.isBlank()) return 0
    var count = 0
    var inWord = false
    for (c in text) {
        if (c.isWhitespace()) {
            inWord = false
        } else if (!inWord) {
            inWord = true
            count++
        }
    }
    return count
}

/** "128 words · 742 characters" (localized, correctly pluralized) for the
 *  editor's live word/character count label. */
fun formatWordAndCharCount(context: Context, text: CharSequence): String {
    val words = wordCount(text)
    val chars = text.length
    val wordsStr = context.resources.getQuantityString(R.plurals.word_count, words, words)
    val charsStr = context.resources.getQuantityString(R.plurals.character_count, chars, chars)
    return context.getString(R.string.word_char_count_format, wordsStr, charsStr)
}
