package com.jarry.floatnote.util

import android.text.Spannable
import android.text.SpannableString
import android.text.style.BackgroundColorSpan

/** [text] with every case-insensitive occurrence of [query] background-
 *  highlighted - or [text] itself, unchanged, if [query] is blank (the
 *  common case: most rows render with no active search, so this avoids
 *  allocating a SpannableString at all when there's nothing to highlight). */
fun highlightMatches(text: String, query: String, highlightColor: Int): CharSequence {
    if (query.isBlank()) return text
    val spannable = SpannableString(text)
    var start = text.indexOf(query, ignoreCase = true)
    while (start >= 0) {
        val end = start + query.length
        spannable.setSpan(BackgroundColorSpan(highlightColor), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        start = text.indexOf(query, start + 1, ignoreCase = true)
    }
    return spannable
}
