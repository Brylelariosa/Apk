package com.jarry.floatnote.util

import android.view.View
import android.widget.PopupMenu
import com.jarry.floatnote.R

/**
 * Shows a picker for one note's own style override - the same PaperStyles
 * list Settings uses for the app-wide default, plus a leading "Use default"
 * entry that clears the override (reported back to [onPicked] as -1) so the
 * note goes back to following whatever's chosen in Settings.
 *
 * A plain checkable PopupMenu rather than a richer swatch-grid picker like
 * Settings' own - reuses this app's existing PopupMenu conventions
 * (FloatingNoteService's overflow/switch-note menus) instead of a new UI
 * pattern, at the cost of showing style names instead of color previews.
 */
fun showNoteStylePicker(anchor: View, currentStyleIndex: Int, onPicked: (Int) -> Unit) {
    val popup = PopupMenu(anchor.context, anchor)
    // A real menu item id, not -1 itself - Android reserves -1
    // (View.NO_ID) as a sentinel elsewhere, so it's safer not to hand it to
    // Menu.add as an id even though PopupMenu happens to tolerate it. One
    // past the last valid style index keeps it unambiguous without needing
    // a second lookup table.
    val useDefaultId = PaperStyles.all.size
    popup.menu.add(0, useDefaultId, 0, R.string.use_default_style).isChecked = currentStyleIndex < 0
    PaperStyles.all.forEachIndexed { index, style ->
        popup.menu.add(0, index, index + 1, style.label).isChecked = index == currentStyleIndex
    }
    popup.menu.setGroupCheckable(0, true, false)
    popup.setOnMenuItemClickListener { item ->
        onPicked(if (item.itemId == useDefaultId) -1 else item.itemId)
        true
    }
    popup.show()
}
