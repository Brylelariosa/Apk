package com.jarry.floatnote.data

/** Secondary sort for the main note list - pinned notes are always first
 *  regardless of which of these is chosen (see NoteDbHelper.getAll). */
enum class NoteSortOrder {
    RECENTLY_EDITED,
    DATE_CREATED,
    TITLE_A_Z
}
