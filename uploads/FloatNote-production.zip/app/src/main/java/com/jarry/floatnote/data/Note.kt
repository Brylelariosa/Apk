package com.jarry.floatnote.data

/**
 * @param styleIndex Index into PaperStyles.all for a per-note style
 *   override, or -1 to follow the app-wide style chosen in Settings (see
 *   PaperStyles.effective). -1, not 0, is "unset": every note persisted
 *   before per-note styling existed has styleIndex=0 in the DB from the
 *   column's original schema default, and that value was never a real
 *   choice - just the placeholder the column happened to start with, back
 *   when it was written but never read anywhere. Treating 0 as a real
 *   override would silently reskin every existing note the first time this
 *   ran (see NoteDbHelper's migration for oldVersion < 4, which explicitly
 *   resets existing rows to -1 for exactly this reason).
 * @param version Optimistic-concurrency token, incremented by 1 in the DB on
 *   every successful write. 0 means "never loaded from/written to the DB" -
 *   the same sentinel role [id]==0 plays for "not yet persisted". A caller
 *   holding a stale [version] (e.g. a floating note window that hasn't
 *   re-synced since the main list pinned or deleted it) has its next
 *   conditional write rejected instead of silently overwriting whatever
 *   changed - see NoteRepository.saveContentIfUnchanged.
 */
data class Note(
    val id: Long = 0L,
    val title: String = "",
    val content: String = "",
    val styleIndex: Int = -1,
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val version: Int = 0
)
