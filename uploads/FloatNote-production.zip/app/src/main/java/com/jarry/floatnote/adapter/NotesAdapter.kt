package com.jarry.floatnote.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jarry.floatnote.R
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.databinding.ItemNoteBinding
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.clipToRoundedCorners
import com.jarry.floatnote.util.highlightMatches
import com.jarry.floatnote.widget.CornerAccentBar
import java.text.DateFormat

class NotesAdapter(
    private val onClick: (Note) -> Unit,
    private val onLongClick: (Note) -> Boolean,
    // Fires on every selection-state change (entering/leaving selection
    // mode, or an item toggled) with the current full set of selected ids -
    // MainActivity uses this to keep its ActionMode title/menu in sync
    // without needing to ask the adapter for its selection state directly.
    private val onSelectionChanged: (Set<Long>) -> Unit = {}
) : ListAdapter<Note, NotesAdapter.NoteViewHolder>(DIFF) {

    // Paper style is a single app-wide setting (see PaperStyles), not
    // per-note, so it's resolved once and cached here instead of doing a
    // SharedPreferences read + color resolution on every single row bind.
    // refreshStyle() re-resolves it and repaints already-bound rows when the
    // style changes in Settings - without this, returning to the list
    // wouldn't visibly update already-bound cards, since the underlying Note
    // data hasn't changed and DiffUtil would otherwise skip rebinding them.
    private var cachedSpineColor: Int? = null

    // The active search query, purely for highlighting matches - kept
    // separate from the list data itself (rather than, say, folding it into
    // Note) so DiffUtil's areContentsTheSame keeps comparing actual note
    // content, not "content plus whatever was last searched for".
    private var highlightQuery: String = ""

    private var selectionMode = false
    private val selectedIds = mutableSetOf<Long>()

    init {
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long = getItem(position).id

    fun refreshStyle(context: Context) {
        cachedSpineColor = resolveSpineColor(context)
        notifyItemRangeChanged(0, itemCount, PAYLOAD_STYLE)
    }

    /** Re-highlights every visible row for [query] without a full rebind -
     *  called on every search keystroke, so this needs to stay cheap. */
    fun setHighlightQuery(query: String) {
        if (highlightQuery == query) return
        highlightQuery = query
        notifyItemRangeChanged(0, itemCount, PAYLOAD_HIGHLIGHT)
    }

    val isInSelectionMode: Boolean get() = selectionMode

    fun setSelectionMode(enabled: Boolean) {
        if (selectionMode == enabled) return
        selectionMode = enabled
        if (!enabled) selectedIds.clear()
        notifyItemRangeChanged(0, itemCount, PAYLOAD_SELECTION)
        onSelectionChanged(selectedIds)
    }

    fun toggleSelected(id: Long) {
        if (!selectedIds.remove(id)) selectedIds.add(id)
        val position = currentList.indexOfFirst { it.id == id }
        if (position != RecyclerView.NO_POSITION) notifyItemChanged(position, PAYLOAD_SELECTION)
        onSelectionChanged(selectedIds)
    }

    fun selectAll() {
        selectedIds.clear()
        currentList.mapTo(selectedIds) { it.id }
        notifyItemRangeChanged(0, itemCount, PAYLOAD_SELECTION)
        onSelectionChanged(selectedIds)
    }

    fun selectedNotes(): List<Note> = currentList.filter { selectedIds.contains(it.id) }

    private fun resolveSpineColor(context: Context): Int {
        val style = PaperStyles.current(context)
        return ContextCompat.getColor(context, style.coverColor)
    }

    private fun spineColorFor(context: Context): Int =
        cachedSpineColor ?: resolveSpineColor(context).also { cachedSpineColor = it }

    /** [note]'s own style override if it has one, otherwise the app-wide
     *  [globalSpineColor] - used by both bind paths below so a note with its
     *  own color isn't clobbered back to the global one when only the
     *  global style changes (see the PAYLOAD_STYLE path). */
    private fun colorFor(context: Context, note: Note, globalSpineColor: Int): Int =
        if (note.styleIndex >= 0) {
            ContextCompat.getColor(context, PaperStyles.get(note.styleIndex).coverColor)
        } else {
            globalSpineColor
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val binding = ItemNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NoteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.bind(getItem(position), spineColorFor(holder.itemView.context), highlightQuery)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isEmpty()) {
            super.onBindViewHolder(holder, position, payloads)
            return
        }
        val note = getItem(position)
        if (payloads.contains(PAYLOAD_STYLE)) {
            holder.applySpineColor(colorFor(holder.itemView.context, note, spineColorFor(holder.itemView.context)))
        }
        if (payloads.contains(PAYLOAD_HIGHLIGHT)) {
            holder.applyHighlight(note, highlightQuery)
        }
        if (payloads.contains(PAYLOAD_SELECTION)) {
            holder.applySelectionState(note)
        }
    }

    inner class NoteViewHolder(private val binding: ItemNoteBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.cardRoot.clipToRoundedCorners(
                binding.root.resources.getDimension(R.dimen.card_corner_radius_list)
            )
        }

        fun bind(note: Note, globalSpineColor: Int, query: String) {
            binding.textTimestamp.text = DATE_FORMAT.format(note.updatedAt)
            applySpineColor(colorFor(binding.root.context, note, globalSpineColor))
            applyHighlight(note, query)
            applySelectionState(note)

            binding.root.setOnClickListener {
                if (selectionMode) toggleSelected(note.id) else onClick(note)
            }
            binding.root.setOnLongClickListener {
                if (selectionMode) {
                    toggleSelected(note.id)
                    true
                } else {
                    onLongClick(note)
                }
            }
        }

        fun applySpineColor(color: Int) {
            binding.spineAccent.setAccent(color, 0f, CornerAccentBar.RoundedCorners.PILL)
        }

        fun applyHighlight(note: Note, query: String) {
            val highlightColor = ContextCompat.getColor(binding.root.context, R.color.search_match_highlight)
            val title = note.title.ifBlank { binding.root.context.getString(R.string.untitled_note) }
            binding.textTitle.text = highlightMatches(title, query, highlightColor)
            binding.textContent.text = highlightMatches(note.content, query, highlightColor)
            binding.textContent.isVisible = note.content.isNotBlank()
        }

        fun applySelectionState(note: Note) {
            // The pinned icon and the selection checkbox share the same
            // corner of the card - showing both at once would overlap, and
            // "is this pinned" isn't very useful to know while bulk-picking
            // notes anyway, so selection mode takes over that corner
            // entirely instead of shrinking both to fit.
            binding.iconPinned.isVisible = note.isPinned && !selectionMode
            binding.checkboxSelect.isVisible = selectionMode
            binding.checkboxSelect.isChecked = selectedIds.contains(note.id)
        }
    }

    companion object {
        private const val PAYLOAD_STYLE = "payload_style"
        private const val PAYLOAD_HIGHLIGHT = "payload_highlight"
        private const val PAYLOAD_SELECTION = "payload_selection"

        private val DIFF = object : DiffUtil.ItemCallback<Note>() {
            override fun areItemsTheSame(oldItem: Note, newItem: Note) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Note, newItem: Note) = oldItem == newItem
        }

        // DateFormat.getDateInstance() does locale/pattern resource work that's
        // expensive enough to notice if it runs on every single row bind - it's
        // allocated once here and reused instead. Safe to share since binding
        // only ever happens on the main thread.
        private val DATE_FORMAT: DateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM)
    }
}
