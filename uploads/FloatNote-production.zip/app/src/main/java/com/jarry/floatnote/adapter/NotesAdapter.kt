package com.jarry.floatnote.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jarry.floatnote.R
import com.jarry.floatnote.data.Note
import com.jarry.floatnote.databinding.ItemNoteBinding
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.clipToRoundedCorners
import com.jarry.floatnote.widget.CornerAccentBar
import java.text.DateFormat

class NotesAdapter(
    private val onClick: (Note) -> Unit,
    private val onLongClick: (Note) -> Boolean
) : ListAdapter<Note, NotesAdapter.NoteViewHolder>(DIFF) {

    // Paper style is a single app-wide setting (see PaperStyles), not
    // per-note, so it's resolved once and cached here instead of doing a
    // SharedPreferences read + color resolution on every single row bind.
    // refreshStyle() re-resolves it and repaints already-bound rows when the
    // style changes in Settings - without this, returning to the list
    // wouldn't visibly update already-bound cards, since the underlying Note
    // data hasn't changed and DiffUtil would otherwise skip rebinding them.
    private var cachedSpineColor: Int? = null

    init {
        setHasStableIds(true)
    }

    override fun getItemId(position: Int): Long = getItem(position).id

    fun refreshStyle(context: Context) {
        cachedSpineColor = resolveSpineColor(context)
        notifyItemRangeChanged(0, itemCount, PAYLOAD_STYLE)
    }

    private fun resolveSpineColor(context: Context): Int {
        val style = PaperStyles.current(context)
        return ContextCompat.getColor(context, style.coverColor)
    }

    private fun spineColorFor(context: Context): Int =
        cachedSpineColor ?: resolveSpineColor(context).also { cachedSpineColor = it }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val binding = ItemNoteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NoteViewHolder(binding)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        holder.bind(getItem(position), spineColorFor(holder.itemView.context))
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.contains(PAYLOAD_STYLE)) {
            holder.applySpineColor(spineColorFor(holder.itemView.context))
        } else {
            super.onBindViewHolder(holder, position, payloads)
        }
    }

    inner class NoteViewHolder(private val binding: ItemNoteBinding) :
        RecyclerView.ViewHolder(binding.root) {

        init {
            binding.cardRoot.clipToRoundedCorners(
                binding.root.resources.getDimension(R.dimen.card_corner_radius_list)
            )
        }

        fun bind(note: Note, spineColor: Int) {
            binding.textTitle.text = note.title.ifBlank { binding.root.context.getString(R.string.untitled_note) }
            binding.textContent.text = note.content
            binding.textContent.isVisible = note.content.isNotBlank()
            binding.iconPinned.isVisible = note.isPinned
            binding.textTimestamp.text = DATE_FORMAT.format(note.updatedAt)
            applySpineColor(spineColor)

            binding.root.setOnClickListener { onClick(note) }
            binding.root.setOnLongClickListener { onLongClick(note) }
        }

        fun applySpineColor(color: Int) {
            binding.spineAccent.setAccent(
                color,
                binding.root.resources.getDimension(R.dimen.card_corner_radius_list),
                CornerAccentBar.RoundedCorners.LEFT_EDGE
            )
        }
    }

    companion object {
        private const val PAYLOAD_STYLE = "payload_style"

        private val DIFF = object : DiffUtil.ItemCallback<Note>() {
            override fun areItemsTheSame(oldItem: Note, newItem: Note) = oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Note, newItem: Note) = oldItem == newItem
        }

        // DateFormat.getDateInstance() does locale/pattern resource work that's
        // expensive enough to notice if it runs on every single row bind - it's
        // allocated once here and reused instead. Safe to share since binding
        // only ever happens on the main thread.
        private val DATE_FORMAT: DateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM)
    }
}
