package com.jarry.floatnote.util

import android.graphics.Rect
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager

/**
 * Keeps a draggable/resizable TYPE_APPLICATION_OVERLAY window clear of the
 * on-screen keyboard.
 *
 * A window added directly through WindowManager - rather than as part of an
 * Activity - gets none of the system's usual softInputMode adjustResize/
 * adjustPan handling when the IME shows: the keyboard just draws over
 * whatever part of the window happens to be underneath it. Worse, the
 * EditText inside is completely unaware anything is covering it - its own
 * built-in scroll-to-cursor behavior (the same logic that keeps the caret
 * visible while typing in any ordinary Activity) only reacts to *its own*
 * bounds shrinking, never to something a separate window drew on top of
 * those bounds. Left alone, typing near the bottom of a long note just
 * disappears behind the keyboard with nothing scrolling to reveal it.
 *
 * This restores that behavior by hand: whenever the keyboard's height
 * changes, the window is shrunk/shifted just enough to clear it - which
 * then lets the EditText's own scroll-to-cursor logic do the rest, the same
 * way it would in a normal resized window - and put back exactly where it
 * was, down to the pixel, the moment the keyboard closes. Only y/height are
 * ever touched; the keyboard doesn't affect horizontal space.
 */
class ImeAwareOverlayResizer(
    private val windowManager: WindowManager,
    private val rootView: View,
    private val params: WindowManager.LayoutParams,
    private val minHeightPx: Int
) {
    // The window's own y/height immediately before the keyboard first
    // pushed it around - null whenever the keyboard is hidden. Restoring
    // from this rather than from the window's persisted "user's real size"
    // fields (which this class knows nothing about, by design - it only
    // ever touches the live LayoutParams it was handed) means a resize/drag
    // the user manages to make *while* the keyboard is up isn't silently
    // lost the moment it closes.
    private var originalY: Int? = null
    private var originalHeight: Int? = null
    private val visibleFrame = Rect()

    // getWindowVisibleDisplayFrame, not the newer WindowInsetsCompat IME
    // type, on purpose: this app's minSdk (26) predates Android's WindowInsets
    // overhaul in API 30, and IME insets dispatch for a window that isn't
    // part of an Activity - like this one - isn't reliably available before
    // that. getWindowVisibleDisplayFrame has reported a window's actual
    // visible area, shrunk by the keyboard whenever it's showing, since long
    // before either of those APIs existed, and works the same for a
    // WindowManager overlay as for any other window.
    private val layoutListener = ViewTreeObserver.OnGlobalLayoutListener {
        rootView.getWindowVisibleDisplayFrame(visibleFrame)
        val screenHeight = rootView.resources.displayMetrics.heightPixels
        val obscured = (screenHeight - visibleFrame.bottom).coerceAtLeast(0)
        // A few dp of gesture-nav/system-bar inset is normal even with no
        // keyboard up at all - only treat this as "the keyboard is showing"
        // once it's a substantial fraction of the screen, so that noise
        // doesn't trigger a pointless resize/restore on every layout pass
        // (e.g. one fires on pretty much every keystroke, as the content
        // reflows).
        applyKeyboardHeight(if (obscured > screenHeight * KEYBOARD_HEIGHT_THRESHOLD) obscured else 0)
    }

    /** Starts listening. Safe to call before or after windowManager.addView -
     *  layout passes naturally start only once the view is attached. */
    fun install() {
        rootView.viewTreeObserver.addOnGlobalLayoutListener(layoutListener)
    }

    /** Call when the window this was installed on is being torn down (or
     *  before installing a fresh resizer for a re-inflated one). Doesn't
     *  restore first - the caller is about to discard [params] and [rootView]
     *  entirely, so there's nothing left for a restore to do anything useful
     *  to. */
    fun uninstall() {
        runCatching { rootView.viewTreeObserver.removeOnGlobalLayoutListener(layoutListener) }
    }

    private fun applyKeyboardHeight(keyboardHeightPx: Int) {
        if (keyboardHeightPx <= 0) {
            restore()
            return
        }
        val baseY = originalY ?: params.y.also { originalY = it }
        val baseHeight = originalHeight ?: params.height.also { originalHeight = it }

        val screenHeight = rootView.resources.displayMetrics.heightPixels
        val keyboardTop = screenHeight - keyboardHeightPx
        val availableAboveKeyboard = (keyboardTop - baseY).coerceAtLeast(minHeightPx)
        val newHeight = baseHeight.coerceAtMost(availableAboveKeyboard)
        // Sits the window's bottom edge right at the keyboard's top edge,
        // never lower than its original position (no need to move down if
        // it already clears the keyboard as-is) and never above the top of
        // the screen (if even the minimum height doesn't leave room, the
        // window ends up partly behind the keyboard rather than partly off
        // the top of the screen - the lesser of two imperfect options).
        val newY = (keyboardTop - newHeight).coerceIn(0, baseY.coerceAtLeast(0))

        if (params.y != newY || params.height != newHeight) {
            params.y = newY
            params.height = newHeight
            updateLayout()
        }
    }

    private fun restore() {
        val y = originalY
        val height = originalHeight
        if (y == null && height == null) return
        y?.let { params.y = it }
        height?.let { params.height = it }
        originalY = null
        originalHeight = null
        updateLayout()
    }

    private fun updateLayout() {
        runCatching { windowManager.updateViewLayout(rootView, params) }
    }

    companion object {
        private const val KEYBOARD_HEIGHT_THRESHOLD = 0.15
    }
}
