package com.jarry.floatnote.util

import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager

/**
 * Keeps a draggable/resizable TYPE_APPLICATION_OVERLAY window clear of the
 * on-screen keyboard.
 *
 * A window added directly through WindowManager - rather than as part of an
 * Activity - gets none of the system's usual softInputMode adjustResize/
 * adjustPan handling when the IME shows: the keyboard just draws over
 * whatever part of the window happens to be underneath it. Worse, the
 * EditText inside is completely unaware anything is covering it - its own
 * built-in scroll-to-cursor behavior (the same logic that keeps the caret
 * visible while typing in any ordinary Activity) only reacts to *its own*
 * bounds shrinking, never to something a separate window drew on top of
 * those bounds. Left alone, typing near the bottom of a long note just
 * disappears behind the keyboard with nothing scrolling to reveal it.
 *
 * This restores that behavior by hand: whenever the keyboard's height
 * changes, the window is shrunk/shifted just enough to clear it - which
 * then lets the EditText's own scroll-to-cursor logic do the rest, the same
 * way it would in a normal resized window - and put back exactly where it
 * was, down to the pixel, the moment the keyboard closes. Only y/height are
 * ever touched; the keyboard doesn't affect horizontal space.
 *
 * Detection is a global layout listener *plus* a light poll, not just the
 * listener alone: a global layout pass is the fast path and normally fires
 * within a frame of the keyboard's own show/hide animation starting, but
 * nothing guarantees it fires at all here. This window's own requested size
 * never changes just because its overlap with the IME did, and unlike an
 * Activity window, there's no framework-owned resize handshake forcing a
 * layout pass in response - so the poll exists as a backstop for whenever
 * that assumption doesn't hold. It's cheap enough (one
 * getWindowVisibleDisplayFrame call and a couple of int comparisons) to just
 * always run for as long as the card's open, rather than trying to predict
 * exactly when the fast path will and won't fire.
 */
class ImeAwareOverlayResizer(
    private val windowManager: WindowManager,
    private val rootView: View,
    private val params: WindowManager.LayoutParams,
    private val minHeightPx: Int
) {
    // The window's own y/height immediately before the keyboard first
    // pushed it around - null whenever the keyboard is hidden. Restoring
    // from this rather than from the window's persisted "user's real size"
    // fields (which this class knows nothing about, by design - it only
    // ever touches the live LayoutParams it was handed) means a resize/drag
    // the user manages to make *while* the keyboard is up isn't silently
    // lost the moment it closes.
    private var originalY: Int? = null
    private var originalHeight: Int? = null
    private val visibleFrame = Rect()
    private val handler = Handler(Looper.getMainLooper())

    private val layoutListener = ViewTreeObserver.OnGlobalLayoutListener { check() }

    private val pollRunnable = object : Runnable {
        override fun run() {
            check()
            handler.postDelayed(this, POLL_INTERVAL_MS)
        }
    }

    /** Starts watching. Safe to call before or after windowManager.addView. */
    fun install() {
        rootView.viewTreeObserver.addOnGlobalLayoutListener(layoutListener)
        handler.postDelayed(pollRunnable, POLL_INTERVAL_MS)
    }

    /** Call when the window this was installed on is being torn down (or
     *  before installing a fresh resizer for a re-inflated one). Doesn't
     *  restore first - the caller is about to discard [params] and [rootView]
     *  entirely, so there's nothing left for a restore to do anything useful
     *  to. */
    fun uninstall() {
        runCatching { rootView.viewTreeObserver.removeOnGlobalLayoutListener(layoutListener) }
        handler.removeCallbacks(pollRunnable)
    }

    private fun check() {
        rootView.getWindowVisibleDisplayFrame(visibleFrame)
        val screenHeight = rootView.resources.displayMetrics.heightPixels
        val obscured = (screenHeight - visibleFrame.bottom).coerceAtLeast(0)
        // A few dp of gesture-nav/system-bar inset is normal even with no
        // keyboard up at all - only treat this as "the keyboard is showing"
        // once it's a substantial fraction of the screen, so that noise
        // doesn't trigger a pointless resize/restore.
        applyKeyboardHeight(if (obscured > screenHeight * KEYBOARD_HEIGHT_THRESHOLD) obscured else 0)
    }

    private fun applyKeyboardHeight(keyboardHeightPx: Int) {
        if (keyboardHeightPx <= 0) {
            restore()
            return
        }
        val baseY = originalY ?: params.y.also { originalY = it }
        val baseHeight = originalHeight ?: params.height.also { originalHeight = it }

        val screenHeight = rootView.resources.displayMetrics.heightPixels
        val keyboardTop = screenHeight - keyboardHeightPx
        val availableAboveKeyboard = (keyboardTop - baseY).coerceAtLeast(minHeightPx)
        val newHeight = baseHeight.coerceAtMost(availableAboveKeyboard)
        // Sits the window's bottom edge right at the keyboard's top edge,
        // never lower than its original position (no need to move down if
        // it already clears the keyboard as-is) and never above the top of
        // the screen (if even the minimum height doesn't leave room, the
        // window ends up partly behind the keyboard rather than partly off
        // the top of the screen - the lesser of two imperfect options).
        val newY = (keyboardTop - newHeight).coerceIn(0, baseY.coerceAtLeast(0))

        if (params.y != newY || params.height != newHeight) {
            params.y = newY
            params.height = newHeight
            updateLayout()
        }
    }

    private fun restore() {
        val y = originalY
        val height = originalHeight
        if (y == null && height == null) return
        y?.let { params.y = it }
        height?.let { params.height = it }
        originalY = null
        originalHeight = null
        updateLayout()
    }

    private fun updateLayout() {
        runCatching { windowManager.updateViewLayout(rootView, params) }
    }

    companion object {
        private const val KEYBOARD_HEIGHT_THRESHOLD = 0.15
        private const val POLL_INTERVAL_MS = 150L
    }
}
