package com.jarry.floatnote.util

import android.view.View
import android.view.WindowManager

/**
 * Keeps a draggable/resizable TYPE_APPLICATION_OVERLAY window clear of the
 * on-screen keyboard.
 *
 * A window added directly through WindowManager - rather than as part of an
 * Activity - gets none of the system's usual softInputMode adjustResize/
 * adjustPan handling when the IME shows: the keyboard just draws over
 * whatever part of the window happens to be underneath it. Worse, the
 * EditText inside is completely unaware anything is covering it - its own
 * built-in scroll-to-cursor behavior (the same logic that keeps the caret
 * visible while typing in any ordinary Activity) only reacts to *its own*
 * bounds shrinking, never to something a separate window drew on top of
 * those bounds. Left alone, typing near the bottom of a long note just
 * disappears behind the keyboard with nothing scrolling to reveal it.
 *
 * This restores that behavior by hand: [onKeyboardMayShow] shrinks/shifts
 * the window to clear a conservative estimate of the keyboard's height -
 * which then lets the EditText's own scroll-to-cursor logic do the rest,
 * the same way it would in a normal resized window - and [onKeyboardMayHide]
 * puts it back exactly where it was, down to the pixel. Only y/height are
 * ever touched; the keyboard doesn't affect horizontal space.
 *
 * Deliberately an *estimate* triggered off the field's own focus change,
 * not a measurement of the real keyboard: measuring it - via
 * getWindowVisibleDisplayFrame or WindowInsets - depends on this window
 * actually receiving accurate IME-overlap information from the system,
 * which two earlier attempts at this found isn't dependable for a raw
 * overlay window like this one (however sound in theory, it visibly didn't
 * do anything in practice). A field's own focus state, on the other hand,
 * is already proven reliable - it's the exact same signal
 * OverlayEditFocusController uses to show/hide the keyboard at all, so if
 * *that* weren't firing correctly, the keyboard wouldn't be showing up in
 * the first place. Trading precise height for a guaranteed trigger is the
 * right trade here: a window that's a little more conservative than it
 * strictly needed to be is a far smaller problem than one that never
 * resizes at all.
 */
class ImeAwareOverlayResizer(
    private val windowManager: WindowManager,
    private val rootView: View,
    private val params: WindowManager.LayoutParams,
    private val minHeightPx: Int
) {
    // The window's own y/height immediately before the keyboard first
    // pushed it around - null whenever the keyboard is hidden. Restoring
    // from this rather than from the window's persisted "user's real size"
    // fields (which this class knows nothing about, by design - it only
    // ever touches the live LayoutParams it was handed) means a resize/drag
    // the user manages to make *while* the keyboard is up isn't silently
    // lost the moment it closes.
    private var originalY: Int? = null
    private var originalHeight: Int? = null

    /** Call the moment a field in this window gains focus, right alongside
     *  wherever the keyboard itself is being asked to show - see the class
     *  doc for why this is what drives the resize instead of trying to
     *  measure the keyboard once it's actually up. */
    fun onKeyboardMayShow() {
        val screenHeight = rootView.resources.displayMetrics.heightPixels
        applyKeyboardHeight((screenHeight * ESTIMATED_KEYBOARD_HEIGHT_FRACTION).toInt())
    }

    /** Call the moment a field in this window loses focus, right alongside
     *  wherever the keyboard itself is being asked to hide. */
    fun onKeyboardMayHide() {
        restore()
    }

    /** Call when the window this was installed on is being torn down (or
     *  before installing a fresh one for a re-inflated card) - restores any
     *  in-progress keyboard-avoidance offset first, since the card's own
     *  persisted position/size fields (cardHeight/lastWindowY) are read
     *  from these same [params] right around teardown, and shouldn't end up
     *  permanently capturing a keyboard-shrunk size. */
    fun uninstall() {
        restore()
    }

    private fun applyKeyboardHeight(keyboardHeightPx: Int) {
        if (keyboardHeightPx <= 0) {
            restore()
            return
        }
        val baseY = originalY ?: params.y.also { originalY = it }
        val baseHeight = originalHeight ?: params.height.also { originalHeight = it }

        val screenHeight = rootView.resources.displayMetrics.heightPixels
        val keyboardTop = screenHeight - keyboardHeightPx
        val availableAboveKeyboard = (keyboardTop - baseY).coerceAtLeast(minHeightPx)
        val newHeight = baseHeight.coerceAtMost(availableAboveKeyboard)
        // Sits the window's bottom edge right at the keyboard's top edge,
        // never lower than its original position (no need to move down if
        // it already clears the keyboard as-is) and never above the top of
        // the screen (if even the minimum height doesn't leave room, the
        // window ends up partly behind the keyboard rather than partly off
        // the top of the screen - the lesser of two imperfect options).
        val newY = (keyboardTop - newHeight).coerceIn(0, baseY.coerceAtLeast(0))

        if (params.y != newY || params.height != newHeight) {
            params.y = newY
            params.height = newHeight
            updateLayout()
        }
    }

    private fun restore() {
        val y = originalY
        val height = originalHeight
        if (y == null && height == null) return
        y?.let { params.y = it }
        height?.let { params.height = it }
        originalY = null
        originalHeight = null
        updateLayout()
    }

    private fun updateLayout() {
        runCatching { windowManager.updateViewLayout(rootView, params) }
    }

    companion object {
        // A bit on the generous side on purpose - Gboard/Samsung Keyboard
        // etc. with a suggestion strip typically run somewhere around
        // 30-40% of screen height in portrait, and overshooting costs a
        // window that's a little smaller than it strictly needed to be,
        // where undershooting costs the exact bug this class exists to fix.
        private const val ESTIMATED_KEYBOARD_HEIGHT_FRACTION = 0.42
    }
}
