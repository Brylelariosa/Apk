package com.jarry.floatnote.util

import android.graphics.drawable.GradientDrawable
import android.view.View

/**
 * Which of a rectangular accent view's own corners should be rounded to
 * match its parent `MaterialCardView`'s corner radius - see
 * [View.setRoundedAccentColor].
 */
enum class AccentCorners {
    /** Round the top-left and bottom-left corners - for an accent strip
     *  running down the left edge of a card (the list/editor "spine"). */
    LEFT_EDGE,

    /** Round the top-left and top-right corners - for an accent bar running
     *  along the top edge of a card (the floating note's drag handle). */
    TOP_EDGE
}

/**
 * Paints this view a solid [color], rounding only the corners named by
 * [corners] to [cornerRadiusPx] and leaving the rest square.
 *
 * Plain `View.setBackgroundColor(color)` installs a square-cornered
 * `ColorDrawable`. That's a problem for a rectangular accent view sitting
 * flush against one or more of a rounded `MaterialCardView`'s own corners
 * (the list/editor spine, the floating card's drag handle): MaterialCardView
 * clips its content to its own rounded outline, so the accent's sharp corner
 * gets cut off along that curve instead of following one of its own -
 * leaving a jagged diagonal edge with the card's flat background color
 * peeking through in a small triangle where the accent was expected to
 * reach the corner. That's what shows up as an unwanted pale notch in the
 * note's corner.
 *
 * Giving the accent the *same* corner radius as its card makes the two
 * curves coincide exactly, so there's nothing left for the clip to cut -
 * the accent's own rounding already stops exactly where the card's does.
 * This is independent of how (or how well) a given OS version/OEM skin
 * implements that clip, so it holds up across API levels and devices,
 * rather than depending on clip-to-outline behaving identically everywhere.
 *
 * [cornerRadiusPx] should always be the same radius as the enclosing card's
 * own `app:cardCornerRadius` - see the `card_corner_radius_*` dimensions in
 * `dimens.xml`, shared by both the layout XML and the call site that uses
 * this function, so the two can never drift apart.
 */
fun View.setRoundedAccentColor(color: Int, cornerRadiusPx: Float, corners: AccentCorners) {
    val topRight = if (corners == AccentCorners.TOP_EDGE) cornerRadiusPx else 0f
    val bottomLeft = if (corners == AccentCorners.LEFT_EDGE) cornerRadiusPx else 0f
    background = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(color)
        // Order is top-left, top-right, bottom-right, bottom-left, each as
        // an [x, y] pair - top-left is rounded for both corner sets since
        // every accent touches the card's top-left corner either way.
        cornerRadii = floatArrayOf(
            cornerRadiusPx, cornerRadiusPx,
            topRight, topRight,
            0f, 0f,
            bottomLeft, bottomLeft
        )
    }
}
