package com.jarry.floatnote.util

import android.content.Context
import android.view.View
import com.jarry.floatnote.databinding.LayoutFloatingBubbleBinding

/**
 * Default/min/max for the floating bubble's user-customizable visible size
 * (dp) - see [PrefsManager.getBubbleSizeDp]/[PrefsManager.setBubbleSizeDp]
 * and the "Floating bubble" section of Settings.
 */
const val DEFAULT_BUBBLE_SIZE_DP = 36f
const val MIN_BUBBLE_SIZE_DP = 24f
const val MAX_BUBBLE_SIZE_DP = 64f

/**
 * Default/min/max for the bubble's opacity, as a percent (0-100) - see
 * [PrefsManager.getBubbleOpacityPercent]/[PrefsManager.setBubbleOpacityPercent].
 *
 * The floor is well above 0: `View.alpha` doesn't affect touch dispatch, so
 * a bubble faded all the way to invisible would still sit there fully
 * tappable/draggable - just impossible to see, and therefore never
 * findable again to turn back up. Stopping short of that keeps "very
 * transparent" from becoming "gone".
 */
const val DEFAULT_BUBBLE_OPACITY_PERCENT = 100
const val MIN_BUBBLE_OPACITY_PERCENT = 20
const val MAX_BUBBLE_OPACITY_PERCENT = 100

// The bubble's *window* (the actual draggable/tappable touch target) is
// kept a bit larger than the visible icon - see layout_floating_bubble.xml's
// own top-of-file comment - so the target still meets Android's
// accessibility touch-target guidance even at the smallest visible size.
// MIN_BUBBLE_TOUCH_TARGET_DP is an absolute floor on top of that padding,
// for the same reason at the very bottom of the size range.
private const val TOUCH_TARGET_PADDING_DP = 8f
private const val MIN_BUBBLE_TOUCH_TARGET_DP = 48f

// The icon glyph is inset from the visible bubble's own edge by this
// fraction on each side - the same ratio the bubble originally shipped
// with (a fixed 9dp inset on a fixed 36dp bubble, i.e. 25%). Keeping it
// proportional rather than fixed means a resized bubble's icon grows or
// shrinks along with it, instead of looking lost in a large bubble or
// cramped in a small one. Private - shared through applyBubbleVisuals
// below rather than the raw ratio itself, so nothing outside this file
// can end up doing the inset math slightly differently.
private const val ICON_INSET_RATIO = 0.25f

/** The floating bubble window's own size in px for a chosen visible size of
 *  [visibleSizeDp] - see [TOUCH_TARGET_PADDING_DP]. */
fun bubbleWindowSizePx(context: Context, visibleSizeDp: Float): Int {
    val wantedDp = maxOf(visibleSizeDp + TOUCH_TARGET_PADDING_DP, MIN_BUBBLE_TOUCH_TARGET_DP)
    return context.dpToPx(wantedDp)
}

/**
 * Renders [sizeDp]/[opacityPercent] onto any bubble-shaped [icon] view - the
 * real floating bubble's own icon (via [applyBubbleAppearance]) and the
 * Settings screen's live preview (see SettingsActivity.updateBubblePreview)
 * both go through this one function, so the preview can never quietly draw
 * a slightly different size or inset than the real bubble actually ends up
 * with.
 *
 * Callers own clamping [sizeDp]/[opacityPercent] to their MIN_.../MAX_...
 * range - this function just renders whatever it's given.
 */
fun applyBubbleVisuals(icon: View, sizeDp: Float, opacityPercent: Int, context: Context) {
    val sizePx = context.dpToPx(sizeDp)
    val insetPx = (sizePx * ICON_INSET_RATIO).toInt()
    icon.layoutParams = icon.layoutParams.apply {
        width = sizePx
        height = sizePx
    }
    icon.setPadding(insetPx, insetPx, insetPx, insetPx)
    icon.alpha = opacityPercent / 100f
}

/**
 * Applies the user's current bubble size/opacity choices (see
 * [PrefsManager]) to a freshly-inflated [LayoutFloatingBubbleBinding] -
 * call once, right after inflating and before adding the view to the
 * WindowManager - see [FloatingNoteService.collapseToBubble].
 *
 * Like the app's other global settings (paper style, content text size),
 * this is read fresh at the point a new bubble is created rather than
 * observed live, so a change made in Settings takes effect the next time a
 * note is minimized to a bubble - an already-showing bubble keeps its
 * current appearance until then, the same way an already-open floating
 * card keeps its style until it's next reopened.
 */
fun applyBubbleAppearance(binding: LayoutFloatingBubbleBinding, context: Context) {
    val sizeDp = PrefsManager.getBubbleSizeDp(context)
        .coerceIn(MIN_BUBBLE_SIZE_DP, MAX_BUBBLE_SIZE_DP)
    val opacityPercent = PrefsManager.getBubbleOpacityPercent(context)
        .coerceIn(MIN_BUBBLE_OPACITY_PERCENT, MAX_BUBBLE_OPACITY_PERCENT)
    applyBubbleVisuals(binding.bubbleIcon, sizeDp, opacityPercent, context)
}
