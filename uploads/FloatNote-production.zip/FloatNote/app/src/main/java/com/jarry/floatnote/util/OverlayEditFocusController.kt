package com.jarry.floatnote.util

import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.EditText

/**
 * Lets a non-focusable overlay window (TYPE_APPLICATION_OVERLAY with
 * FLAG_NOT_FOCUSABLE) become focusable only while the user is actually
 * typing in one of [editFields]. A fully non-focusable overlay never
 * receives IME input, but a fully focusable one would swallow Back/Home for
 * whatever's underneath - so focusability is toggled on the fly: a tap on a
 * field arms it, and losing focus (or pressing Back) hands the window's
 * focusability back off so Back reaches the app below again.
 */
class OverlayEditFocusController(
    private val windowManager: WindowManager,
    private val rootView: View,
    private val params: WindowManager.LayoutParams,
    private val imm: InputMethodManager,
    private val editFields: List<EditText>
) {
    // updateViewLayout is a synchronous WMS call - calling it directly from
    // the ACTION_DOWN listener below would block every single tap into a
    // field on that IPC completing before the tap even finishes being
    // dispatched. Deferring it to the next frame keeps a tap feeling
    // instant; the keyboard still shows up within a frame either way, which
    // isn't perceptible as a delay the way a blocked touch is.
    private val layoutThrottler = ViewLayoutThrottler(windowManager, rootView, params)

    // Set for as long as a popup *we* opened on top of this window (currently
    // just the overflow PopupMenu) is showing. Android hands window focus to
    // a focusable PopupMenu/PopupWindow for as long as it's up, which fires
    // windowFocusListener below with hasWindowFocus=false - from that
    // callback alone, that's indistinguishable from the user tapping away
    // into a different app entirely. Left unguarded, simply opening the
    // overflow menu was enough to trip releaseEditingFocus() and silently
    // collapse whatever text was selected before the user could act on it.
    // See onTransientPopupOpened/onTransientPopupClosed.
    private var transientPopupOpen = false

    private val windowFocusListener = ViewTreeObserver.OnWindowFocusChangeListener { hasWindowFocus ->
        if (!hasWindowFocus && !transientPopupOpen) releaseEditingFocus()
    }

    /** Wires the touch/focus/key listeners onto [rootView] and [editFields]. */
    fun install() {
        editFields.forEach { field ->
            field.isFocusable = false
            field.isFocusableInTouchMode = false
            field.setOnTouchListener { view, event ->
                if (event.action == MotionEvent.ACTION_DOWN) {
                    view.isFocusable = true
                    view.isFocusableInTouchMode = true
                    setWindowFocusable(true)
                }
                false
            }
            field.onFocusChangeListener = View.OnFocusChangeListener { view, hasFocus ->
                if (hasFocus) {
                    view.post { imm.showSoftInput(view, InputMethodManager.SHOW_IMPLICIT) }
                } else {
                    imm.hideSoftInputFromWindow(view.windowToken, 0)
                    view.isFocusable = false
                    view.isFocusableInTouchMode = false
                    setWindowFocusable(false)
                }
            }
        }

        rootView.isFocusableInTouchMode = true
        rootView.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP) {
                releaseEditingFocus()
                true
            } else {
                false
            }
        }

        // A field's own OnFocusChangeListener above only fires when focus moves
        // to something else *inside this same window* - it never fires just
        // because the user tapped away into a different app entirely, since
        // nothing in our hierarchy took over local focus. Left unhandled, this
        // window would stay armed focusable indefinitely, competing for system
        // input focus with whatever the user taps next and blocking its
        // keyboard, and never re-arming cleanly on the next tap back in here.
        // Watching window focus directly (rather than per-field focus) catches
        // that case too.
        rootView.viewTreeObserver.addOnWindowFocusChangeListener(windowFocusListener)
    }

    /** Releases the window-focus listener installed by [install] - call when
     *  the overlay window this controller was wired to is being torn down
     *  (e.g. minimized to a bubble or closed), so it doesn't stay registered
     *  on the (now-detached) view's ViewTreeObserver until GC catches up. */
    fun uninstall() {
        runCatching { rootView.viewTreeObserver.removeOnWindowFocusChangeListener(windowFocusListener) }
    }

    /** Call immediately before showing a PopupMenu/PopupWindow anchored on a
     *  view inside [rootView] (e.g. the card's overflow menu) - suppresses
     *  the window-focus-lost teardown for as long as that popup is up, since
     *  the loss of focus it causes is our own popup taking it, not the user
     *  leaving the field. Always pair with [onTransientPopupClosed] once the
     *  popup dismisses (e.g. via its own OnDismissListener), or editing state
     *  will never tear down again even after the user genuinely leaves. */
    fun onTransientPopupOpened() {
        transientPopupOpen = true
    }

    /** Pairs with [onTransientPopupOpened]. Window focus is normally handed
     *  straight back to [rootView] by the system the instant the popup above
     *  it closes, so this doesn't need to do anything further by default -
     *  the fallback below only matters if focus somehow *didn't* come back
     *  (e.g. the user managed to switch to another app while the popup was
     *  still up), in which case editing is torn down same as any other
     *  genuine focus loss instead of being left stuck open. */
    fun onTransientPopupClosed() {
        transientPopupOpen = false
        if (!rootView.hasWindowFocus()) releaseEditingFocus()
    }

    private fun releaseEditingFocus() {
        editFields.forEach { it.clearFocus() }
        imm.hideSoftInputFromWindow(rootView.windowToken, 0)
        setWindowFocusable(false)
    }

    private fun setWindowFocusable(focusable: Boolean) {
        val newFlags = if (focusable) {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        if (newFlags != params.flags) {
            params.flags = newFlags
            layoutThrottler.requestUpdate()
        }
    }
}
