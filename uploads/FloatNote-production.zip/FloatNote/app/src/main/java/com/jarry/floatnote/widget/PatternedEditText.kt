package com.jarry.floatnote.widget

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ViewConfiguration
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.jarry.floatnote.R
import com.jarry.floatnote.util.PaperPattern
import kotlin.math.abs

/**
 * An EditText that draws a paper-style background pattern behind the text:
 * ruled lines (with a red margin line), a grid, a dot-grid, or nothing
 * (blank). Spacing is read from the EditText's own lineHeight/font metrics,
 * not a fixed dp value, so the pattern always lines up with the actual text
 * no matter the font size. Patterns are drawn all the way to the bottom of
 * the view, not just behind typed lines, so it reads as a full page from the
 * moment a note opens.
 */
class PatternedEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private val density = resources.displayMetrics.density

    // The system default long-press-to-select trigger (~500ms, via
    // ViewConfiguration.getLongPressTimeout()) is easy to hit by accident
    // while just tapping to place the cursor. There's no public API to tune
    // that duration per-view, so it's disabled (isLongClickable = false, which
    // stops View from ever scheduling its own timer) and reimplemented here
    // by hand with a longer delay - performLongClick() below still runs
    // TextView's normal selection-start logic (handles, magnifier, the
    // selection toolbar are all still native), just triggered later.
    init {
        isLongClickable = false
    }

    private val longPressHandler = Handler(Looper.getMainLooper())
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private val longPressRunnable = Runnable { performLongClick(lastX, lastY) }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                lastX = event.x
                lastY = event.y
                longPressHandler.removeCallbacks(longPressRunnable)
                longPressHandler.postDelayed(longPressRunnable, SELECTION_HOLD_MS)
            }
            MotionEvent.ACTION_MOVE -> {
                lastX = event.x
                lastY = event.y
                if (abs(event.x - downX) > touchSlop || abs(event.y - downY) > touchSlop) {
                    longPressHandler.removeCallbacks(longPressRunnable)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> {
                longPressHandler.removeCallbacks(longPressRunnable)
            }
        }
        return super.onTouchEvent(event)
    }

    override fun onDetachedFromWindow() {
        longPressHandler.removeCallbacks(longPressRunnable)
        super.onDetachedFromWindow()
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = density
        color = ContextCompat.getColor(context, R.color.paper_rule_line)
    }

    private val marginPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = density
        color = ContextCompat.getColor(context, R.color.paper_margin_line)
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = ContextCompat.getColor(context, R.color.paper_rule_line)
    }

    var pattern: PaperPattern = PaperPattern.RULED
        set(value) {
            field = value
            invalidate()
        }

    var showMarginLine: Boolean = true
        set(value) {
            field = value
            invalidate()
        }
    override fun onDraw(canvas: Canvas) {
        when (pattern) {
            PaperPattern.RULED -> {
                drawRules(canvas)
                drawMargin(canvas)
            }
            PaperPattern.GRID -> drawGrid(canvas)
            PaperPattern.DOT -> drawDots(canvas)
            PaperPattern.BLANK -> Unit
        }
        super.onDraw(canvas)
    }

    private fun lineStep(): Float {
        val lineH = lineHeight.toFloat()
        return if (lineH > 0f) lineH else textSize * 1.3f
    }

    private fun drawRules(canvas: Canvas) {
        val lineH = lineStep()
        if (lineH <= 0f) return
        val fm = paint.fontMetrics
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val top = scrollY.toFloat()
        val bottom = scrollY + (height - paddingBottom).toFloat()
        // Drawn a hairline below the text baseline rather than exactly on it,
        // just enough that the rule's own stroke doesn't visually fuse with
        // the bottom of non-descender glyphs - not pushed further down into
        // the descender band. On real ruled paper, letters rest directly ON
        // the line, with only true descenders (g, y, p, q, j) dipping
        // slightly below it; a bigger gap here reads as the whole line of
        // text floating above the rule instead of sitting on it. A fixed px
        // amount rather than one proportional to line height/descent also
        // means this stays a hairline at any content text size, instead of
        // widening into a visible gap again as the user picks a larger size
        // in Settings.
        val ruleGap = density * RULE_BASELINE_CLEARANCE_DP

        // Fallback anchor for when there's no Layout yet (shouldn't happen in
        // practice inside onDraw, but keeps this safe).
        var lastBaseline = paddingTop - fm.top

        val textLayout = layout
        if (textLayout != null) {
            val lineCount = textLayout.lineCount
            if (lineCount > 0) {
                // Use the real per-line baselines from the EditText's own Layout
                // instead of repeatedly adding a fixed lineHeight step, so rules
                // stay locked to the glyphs above them (lineSpacingExtra, wrapped
                // long lines like URLs, etc. each round slightly differently and
                // drift out of sync with a fixed step over a long note).
                //
                // Only walk lines within the visible (scrolled) window - onDraw
                // runs on every scroll frame, so looping every line in the whole
                // note each time is what made scrolling feel slow. getLineForVertical
                // jumps straight to the right range instead of a full scan.
                val firstLine = textLayout.getLineForVertical((top - paddingTop).toInt().coerceAtLeast(0))
                    .coerceIn(0, lineCount - 1)
                val lastLine = textLayout.getLineForVertical((bottom - paddingTop).toInt())
                    .coerceIn(0, lineCount - 1)
                for (i in firstLine..lastLine) {
                    val baseline = paddingTop + textLayout.getLineBaseline(i).toFloat()
                    val ruleY = baseline + ruleGap
                    canvas.drawLine(left, ruleY, right, ruleY, linePaint)
                }
                lastBaseline = paddingTop + textLayout.getLineBaseline(lineCount - 1).toFloat()
            }
        }

        // Continue the ruled pattern below the last typed line so the page still
        // reads as fully lined from the moment the note opens. Drift doesn't matter
        // here since there's no text to stay in sync with yet.
        var baseline = lastBaseline + lineH
        while (baseline <= bottom) {
            val ruleY = baseline + ruleGap
            canvas.drawLine(left, ruleY, right, ruleY, linePaint)
            baseline += lineH
        }
    }

    private fun drawMargin(canvas: Canvas) {
        if (!showMarginLine) return
        val x = paddingLeft - (10f * density)
        if (x > 0f) {
            val top = scrollY.toFloat()
            val bottom = (scrollY + height).toFloat()
            canvas.drawLine(x, top, x, bottom, marginPaint)
        }
    }

    /** First on-or-before-[top] grid line along an axis stepped by [step] from
     *  [axisStart] - shared by [drawGrid] and [drawDots], which only differ in
     *  what they draw at each computed position. */
    private fun firstVisibleLine(top: Float, axisStart: Float, step: Float): Float {
        val skipped = kotlin.math.floor((top - axisStart) / step).toInt().coerceAtLeast(0)
        return axisStart + skipped * step
    }

    private fun drawGrid(canvas: Canvas) {
        val step = lineStep() * 0.72f
        if (step <= 0f) return
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val top = scrollY.toFloat()
        val bottom = scrollY + (height - paddingBottom).toFloat()
        var y = firstVisibleLine(top, paddingTop.toFloat(), step)
        while (y <= bottom) {
            canvas.drawLine(left, y, right, y, linePaint)
            y += step
        }
        var x = left
        while (x <= right) {
            canvas.drawLine(x, top, x, bottom, linePaint)
            x += step
        }
    }

    private fun drawDots(canvas: Canvas) {
        val step = lineStep() * 0.72f
        if (step <= 0f) return
        val left = paddingLeft.toFloat()
        val right = (width - paddingRight).toFloat()
        val top = scrollY.toFloat()
        val bottom = scrollY + (height - paddingBottom).toFloat()
        val radius = density * 1.1f
        var y = firstVisibleLine(top, paddingTop.toFloat(), step)
        while (y <= bottom) {
            var x = left
            while (x <= right) {
                canvas.drawCircle(x, y, radius, dotPaint)
                x += step
            }
            y += step
        }
    }

    companion object {
        // A bit longer than the system default (~500ms) so a slightly-too-long
        // tap while placing the cursor doesn't accidentally start a selection.
        private const val SELECTION_HOLD_MS = 700L

        // See drawRules' own comment on ruleGap - deliberately small and
        // fixed rather than derived from font metrics.
        private const val RULE_BASELINE_CLEARANCE_DP = 1f
    }
}
