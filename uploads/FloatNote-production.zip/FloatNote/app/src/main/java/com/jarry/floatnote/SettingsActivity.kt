package com.jarry.floatnote

import android.content.res.ColorStateList
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.jarry.floatnote.databinding.ActivitySettingsBinding
import com.jarry.floatnote.util.MAX_BUBBLE_OPACITY_PERCENT
import com.jarry.floatnote.util.MAX_BUBBLE_SIZE_DP
import com.jarry.floatnote.util.MAX_CONTENT_TEXT_SIZE_SP
import com.jarry.floatnote.util.MIN_BUBBLE_OPACITY_PERCENT
import com.jarry.floatnote.util.MIN_BUBBLE_SIZE_DP
import com.jarry.floatnote.util.MIN_CONTENT_TEXT_SIZE_SP
import com.jarry.floatnote.util.MinimizeMode
import com.jarry.floatnote.util.PaperStyles
import com.jarry.floatnote.util.PrefsManager
import com.jarry.floatnote.util.applyBottomSystemBarPadding
import com.jarry.floatnote.util.applyBubbleVisuals
import com.jarry.floatnote.util.applyTopSystemBarPadding

/**
 * One place for choices that used to live inline on the note editor: the
 * single app-wide note style, and how minimizing a floating note behaves.
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        applyInsets()

        buildStyleSwatches()
        setupMinimizeModeToggle()
        setupBubbleSliders()
        setupTextSizeSlider()
    }

    private fun applyInsets() {
        binding.toolbar.applyTopSystemBarPadding()
        binding.settingsScroll.applyBottomSystemBarPadding()
    }

    private fun buildStyleSwatches() {
        binding.styleRow.removeAllViews()
        val current = PrefsManager.getGlobalStyleIndex(this)
        PaperStyles.all.forEachIndexed { index, style ->
            val swatch = layoutInflater.inflate(R.layout.item_style_swatch, binding.styleRow, false)
            val cover = swatch.findViewById<View>(R.id.styleCover)
            cover.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this, style.coverColor))
            val selected = index == current
            cover.alpha = if (selected) 1f else 0.5f
            cover.scaleX = if (selected) 1.1f else 1f
            cover.scaleY = if (selected) 1.1f else 1f
            swatch.contentDescription = style.label
            swatch.setOnClickListener {
                PrefsManager.setGlobalStyleIndex(this, index)
                buildStyleSwatches()
            }
            binding.styleRow.addView(swatch)
        }
    }

    private fun setupMinimizeModeToggle() {
        val checkedId = when (PrefsManager.getMinimizeMode(this)) {
            MinimizeMode.BUBBLE -> R.id.buttonModeBubble
            MinimizeMode.NOTIFICATION -> R.id.buttonModeNotification
        }
        binding.minimizeModeGroup.check(checkedId)
        binding.minimizeModeGroup.addOnButtonCheckedListener { _, checkedButtonId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val mode = if (checkedButtonId == R.id.buttonModeNotification) {
                MinimizeMode.NOTIFICATION
            } else {
                MinimizeMode.BUBBLE
            }
            PrefsManager.setMinimizeMode(this, mode)
        }
    }

    /** Wires the bubble size/opacity sliders to [PrefsManager] and keeps
     *  [updateBubblePreview] in sync with both - same pattern as
     *  [setupTextSizeSlider] below. A change here takes effect the next
     *  time a note is minimized to a bubble, not on an already-showing one
     *  - see [applyBubbleVisuals]'s own doc for why. */
    private fun setupBubbleSliders() {
        binding.bubbleSizeSlider.valueFrom = MIN_BUBBLE_SIZE_DP
        binding.bubbleSizeSlider.valueTo = MAX_BUBBLE_SIZE_DP
        binding.bubbleOpacitySlider.valueFrom = MIN_BUBBLE_OPACITY_PERCENT.toFloat()
        binding.bubbleOpacitySlider.valueTo = MAX_BUBBLE_OPACITY_PERCENT.toFloat()

        val sizeDp = PrefsManager.getBubbleSizeDp(this)
            .coerceIn(MIN_BUBBLE_SIZE_DP, MAX_BUBBLE_SIZE_DP)
        val opacityPercent = PrefsManager.getBubbleOpacityPercent(this)
            .coerceIn(MIN_BUBBLE_OPACITY_PERCENT, MAX_BUBBLE_OPACITY_PERCENT)
        binding.bubbleSizeSlider.value = sizeDp
        binding.bubbleOpacitySlider.value = opacityPercent.toFloat()
        updateBubblePreview(sizeDp, opacityPercent)

        binding.bubbleSizeSlider.addOnChangeListener { _, value, _ ->
            PrefsManager.setBubbleSizeDp(this, value)
            updateBubblePreview(value, binding.bubbleOpacitySlider.value.toInt())
        }
        binding.bubbleOpacitySlider.addOnChangeListener { _, value, _ ->
            PrefsManager.setBubbleOpacityPercent(this, value.toInt())
            updateBubblePreview(binding.bubbleSizeSlider.value, value.toInt())
        }
    }

    private fun updateBubblePreview(sizeDp: Float, opacityPercent: Int) {
        applyBubbleVisuals(binding.bubblePreview, sizeDp, opacityPercent, this)
    }

    private fun setupTextSizeSlider() {
        binding.textSizeSlider.valueFrom = MIN_CONTENT_TEXT_SIZE_SP
        binding.textSizeSlider.valueTo = MAX_CONTENT_TEXT_SIZE_SP
        val current = PrefsManager.getContentTextSizeSp(this)
            .coerceIn(MIN_CONTENT_TEXT_SIZE_SP, MAX_CONTENT_TEXT_SIZE_SP)
        binding.textSizeSlider.value = current
        binding.textSizePreview.textSize = current
        binding.textSizeSlider.addOnChangeListener { _, value, _ ->
            binding.textSizePreview.textSize = value
            PrefsManager.setContentTextSizeSp(this, value)
        }
    }
}
