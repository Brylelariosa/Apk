package com.jarry.floatnote.util

import android.view.Choreographer
import android.view.View
import android.view.WindowManager

/**
 * Coalesces rapid-fire `WindowManager.updateViewLayout` calls into at most
 * one per rendered frame.
 *
 * A raw touch stream during drag/resize can deliver ACTION_MOVE far faster
 * than the display refreshes, and `updateViewLayout` is a synchronous
 * cross-process call into WindowManagerService that triggers a full
 * measure/layout/draw of the window's content on the other end - calling it
 * once per touch event (rather than once per frame) redoes that work many
 * times more than the screen can even show, which is what shows up as
 * dropped frames/lag. This is most visible on content that's expensive to
 * redraw, like `PatternedEditText`'s ruled-line background being remeasured
 * on every pixel of a resize drag.
 *
 * [params] is expected to be mutated in place by the caller (as
 * `WindowManager.LayoutParams` already is elsewhere in this codebase) before
 * calling [requestUpdate] - since the callback reads the same object
 * reference, whatever is current at the moment the frame actually renders is
 * what gets applied, so bursts of moves within one frame collapse into a
 * single relayout with the latest values automatically, with no separate
 * "pending value" bookkeeping needed.
 */
class ViewLayoutThrottler(
    private val windowManager: WindowManager,
    private val view: View,
    private val params: WindowManager.LayoutParams
) {
    private var scheduled = false
    private val frameCallback = Choreographer.FrameCallback {
        scheduled = false
        runCatching { windowManager.updateViewLayout(view, params) }
    }

    /** Ensures [params] will be applied on the next frame. Cheap to call on
     *  every ACTION_MOVE - only the first call in a given frame actually
     *  schedules anything. */
    fun requestUpdate() {
        if (scheduled) return
        scheduled = true
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    /** Applies [params] immediately and drops any pending frame callback -
     *  use on ACTION_UP/ACTION_CANCEL so the gesture's final position/size
     *  lands exactly instead of waiting on a frame that may arrive late (or,
     *  since the callback is removed, not at all). */
    fun applyNow() {
        cancelPending()
        runCatching { windowManager.updateViewLayout(view, params) }
    }

    /** Drops a pending frame callback without applying [params] - use when
     *  the window is being torn down mid-gesture and any further layout call
     *  on it would be pointless (or unsafe, if the view's already detached). */
    fun cancelPending() {
        if (!scheduled) return
        scheduled = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
    }
}
