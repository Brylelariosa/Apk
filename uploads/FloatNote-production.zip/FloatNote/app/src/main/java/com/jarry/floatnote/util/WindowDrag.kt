package com.jarry.floatnote.util

import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs

private const val DRAG_THRESHOLD_PX = 8

/**
 * Wires an OnTouchListener on [dragHandle] that repositions [params] (x/y) as
 * the user drags, applying each move to [windowRoot] via [windowManager] -
 * [windowRoot] is the view actually attached via `WindowManager.addView` and
 * must be used for `updateViewLayout` even when [dragHandle] is a child view
 * used only to receive the drag gesture (as with the card's drag handle).
 * Shared by the floating card's drag handle and the collapsed bubble (where
 * [dragHandle] and [windowRoot] are the same view).
 *
 * [onPositionChanged], if given, is called with the updated (x, y) after
 * every move - lets a caller track "where is this window right now" without
 * holding onto (and risking aliasing) the [params] instance itself.
 *
 * [onRelease], if given, is called on ACTION_UP with whether the touch moved
 * past a small threshold (a tap vs. an actual drag) - e.g. the bubble uses
 * this to tell "tap to expand" apart from "drag to reposition". When
 * omitted, ACTION_UP is left unhandled, matching a plain drag handle with no
 * separate tap behavior.
 */
fun setupWindowDrag(
    dragHandle: View,
    windowRoot: View,
    params: WindowManager.LayoutParams,
    windowManager: WindowManager,
    onPositionChanged: ((x: Int, y: Int) -> Unit)? = null,
    onRelease: ((moved: Boolean) -> Unit)? = null
) {
    var startX = 0
    var startY = 0
    var touchX = 0f
    var touchY = 0f
    var moved = false
    val layoutThrottler = ViewLayoutThrottler(windowManager, windowRoot, params)
    dragHandle.setOnTouchListener { _, event ->
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = params.x
                startY = params.y
                touchX = event.rawX
                touchY = event.rawY
                moved = false
                true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - touchX
                val dy = event.rawY - touchY
                if (abs(dx) > DRAG_THRESHOLD_PX || abs(dy) > DRAG_THRESHOLD_PX) moved = true
                params.x = startX + dx.toInt()
                params.y = startY + dy.toInt()
                layoutThrottler.requestUpdate()
                onPositionChanged?.invoke(params.x, params.y)
                true
            }
            MotionEvent.ACTION_UP -> {
                layoutThrottler.applyNow()
                if (onRelease != null) {
                    onRelease(moved)
                    true
                } else {
                    false
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                layoutThrottler.applyNow()
                false
            }
            else -> false
        }
    }
}
