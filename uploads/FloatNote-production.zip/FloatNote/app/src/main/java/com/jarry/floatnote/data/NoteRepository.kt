package com.jarry.floatnote.data

import android.content.Context
import android.os.CancellationSignal
import android.os.OperationCanceledException
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.job
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

/** Outcome of a conflict-aware content write - see [NoteRepository.saveContentIfUnchanged]. */
sealed interface SaveOutcome {
    /** Write succeeded; carries the note as now persisted (fresh id/version/updatedAt). */
    data class Saved(val note: Note) : SaveOutcome

    /** The row's version no longer matched what the caller expected - someone
     *  else's write landed first. Nothing was written. */
    data object Conflict : SaveOutcome

    /** The row this note pointed at no longer exists (deleted elsewhere).
     *  Nothing was written. */
    data object DeletedElsewhere : SaveOutcome
}

/**
 * Suspend wrapper around [NoteDbHelper] that also centralizes error
 * handling, search cancellation, and multi-writer conflict resolution for
 * the whole app: every DB operation can in principle throw (disk full,
 * corrupt database file, etc.), and callers shouldn't have to guard against
 * that individually. Failures are logged and degraded to a safe fallback (an
 * empty list, a null note, an unchanged id) rather than propagating and
 * crashing whatever screen or floating window triggered them.
 */
class NoteRepository internal constructor(private val dbHelper: NoteDbHelper) {

    /**
     * Scope for saves that must survive the death of whatever Android
     * component (Activity/Service) triggered them - e.g. the final autosave
     * fired from NoteEditorActivity.onPause() or FloatingNoteService.onDestroy()
     * right as that component is torn down. Deliberately NOT a child of
     * lifecycleScope or serviceScope: both of those are cancelled as part of
     * that exact teardown, which would race - and could silently drop - the
     * very save they're meant to guarantee. Because this scope is
     * structurally independent (its own SupervisorJob, not parented to
     * either caller), cancelling lifecycleScope/serviceScope can never
     * reach in and interrupt a write already under way here, without
     * needing NonCancellable guards at every call site.
     *
     * Dispatchers.IO so callers never block their own (often main) thread
     * waiting for this - see saveOrDeleteIfEmptyDurable.
     */
    private val durableScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    suspend fun getAll(query: String = ""): List<Note> = withContext(Dispatchers.IO) {
        // Ties this native SQLite query to the coroutine's own cancellation:
        // if the caller (e.g. MainActivity.loadNotes on a newer keystroke)
        // cancels the Job that's running this, signal.cancel() interrupts
        // sqlite3_step() from wherever it currently is instead of letting a
        // large/unindexed LIKE scan grind on to completion for a result
        // nobody wants anymore - see NoteDbHelper.getAll.
        val signal = CancellationSignal()
        coroutineContext.job.invokeOnCompletion { cause ->
            if (cause is CancellationException) signal.cancel()
        }
        try {
            dbHelper.getAll(query, signal)
        } catch (e: OperationCanceledException) {
            throw CancellationException("getAll($query) cancelled", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "getAll failed", e)
            emptyList()
        }
    }

    suspend fun getById(id: Long): Note? = withContext(Dispatchers.IO) {
        try {
            dbHelper.getById(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "getById($id) failed", e)
            null
        }
    }

    /** Unconditional insert-or-update, last-write-wins - kept for simple
     *  callers that can't conflict by construction (a brand-new note being
     *  inserted, or MainActivity's undo-after-delete, which always inserts
     *  a fresh row) and as saveOrDeleteIfEmpty's last-resort fallback.
     *  Prefer [saveContentIfUnchanged] (via [saveOrDeleteIfEmpty]) for any
     *  writer whose in-memory copy of the note could have gone stale in the
     *  background. */
    suspend fun save(note: Note): Long = withContext(Dispatchers.IO) {
        val stamped = note.copy(updatedAt = System.currentTimeMillis())
        try {
            if (stamped.id == 0L) {
                dbHelper.insert(stamped)
            } else {
                dbHelper.update(stamped)
                stamped.id
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "save(${note.id}) failed", e)
            // Fall back to whatever id the note already had so the caller's
            // in-memory state stays consistent (a new note stays "unsaved"
            // rather than being mistaken for a successful insert).
            note.id
        }
    }

    suspend fun delete(id: Long) = withContext(Dispatchers.IO) {
        try {
            dbHelper.delete(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "delete($id) failed", e)
        }
    }

    /** Toggles/sets only the pinned flag - see
     *  [NoteDbHelper.setPinned] for why this is deliberately narrow rather
     *  than routed through [save] with a full-row overwrite: pinning a note
     *  from the main list must never clobber title/content a floating
     *  window or the editor autosaved moments ago that just hasn't made it
     *  into the list's own (debounced, periodically-refreshed) snapshot yet. */
    suspend fun setPinned(id: Long, pinned: Boolean) = withContext(Dispatchers.IO) {
        try {
            dbHelper.setPinned(id, pinned, System.currentTimeMillis())
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "setPinned($id) failed", e)
        }
    }

    /**
     * Version-checked content save - the conflict-aware building block
     * every writer that could go stale in the background (floating note
     * windows; the full editor, for the same reason) should use instead of
     * [save]. Only ever touches title/content/color/updatedAt/version -
     * see [NoteDbHelper.updateContentIfVersionMatches] for why pinned is
     * excluded on purpose.
     *
     * A brand-new, not-yet-persisted note ([note].id == 0) has nothing to
     * conflict with yet, so this always inserts it, same as [save] would.
     */
    suspend fun saveContentIfUnchanged(note: Note, expectedVersion: Int): SaveOutcome =
        withContext(Dispatchers.IO) {
            val stamped = note.copy(updatedAt = System.currentTimeMillis())
            try {
                if (stamped.id == 0L) {
                    val newId = dbHelper.insert(stamped)
                    SaveOutcome.Saved(stamped.copy(id = newId, version = 1))
                } else {
                    val rows = dbHelper.updateContentIfVersionMatches(stamped, expectedVersion)
                    when {
                        rows > 0 -> SaveOutcome.Saved(stamped.copy(version = expectedVersion + 1))
                        dbHelper.getById(stamped.id) == null -> SaveOutcome.DeletedElsewhere
                        else -> SaveOutcome.Conflict
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "saveContentIfUnchanged(${note.id}) failed", e)
                // Fail closed: an unexpected error here means we don't know
                // whether the write landed, so the caller should not trust
                // its in-memory version and should re-sync rather than
                // silently moving on as if nothing happened.
                SaveOutcome.Conflict
            }
        }

    /**
     * Saves [note]'s title/content, or deletes the row if the user cleared
     * both - the "autosave or clean up an emptied note" rule shared by the
     * full-screen editor, a single floating window's own close/dismiss, and
     * the whole-service shutdown path, so all three agree on it instead of
     * three independent copies risking disagreement.
     *
     * Built on [saveContentIfUnchanged], so it inherits that method's
     * conflict-safety: on a genuine version conflict (the row changed since
     * [note] was last read/saved) this re-reads the current version and
     * retries - the caller's own in-progress edit is what the user is
     * looking at right now, so it should still win over a merely-newer
     * version number, just never over an outright deletion. If the row is
     * gone entirely, [note] is treated as brand new (id/version reset to 0)
     * so its content isn't silently dropped: the very next call inserts it
     * as a fresh row instead of endlessly failing to update a row that no
     * longer exists.
     */
    suspend fun saveOrDeleteIfEmpty(note: Note): Note {
        if (note.title.isBlank() && note.content.isBlank()) {
            if (note.id != 0L) delete(note.id)
            return note.copy(id = 0L, version = 0)
        }
        var current = note
        repeat(MAX_CONFLICT_RETRIES) {
            when (val outcome = saveContentIfUnchanged(current, current.version)) {
                is SaveOutcome.Saved -> return outcome.note
                SaveOutcome.DeletedElsewhere -> current = current.copy(id = 0L, version = 0)
                SaveOutcome.Conflict -> {
                    val fresh = getById(current.id)
                    current = if (fresh != null) {
                        current.copy(version = fresh.version)
                    } else {
                        current.copy(id = 0L, version = 0)
                    }
                }
            }
        }
        // Retries exhausted - pathological, and shouldn't happen in
        // practice given this app never has two live writers actively
        // saving the same note id at once (see FloatingNoteService's
        // isNoteFloating/showNote guards). Fall back to an unconditional
        // save so a real edit is never silently dropped, at the cost of -
        // in this specific, extremely unlikely case only - the same
        // last-write-wins behavior the rest of this function exists to avoid.
        Log.w(TAG, "saveOrDeleteIfEmpty(${note.id}) exhausted conflict retries, forcing save")
        return current.copy(id = save(current))
    }

    /**
     * Fires [saveOrDeleteIfEmpty] on [durableScope] instead of the caller's
     * own scope, returning a [Deferred] the caller can [Deferred.await]
     * later (from a *different*, still-alive scope/coroutine) if it needs
     * the resulting id/version - e.g. NoteEditorActivity hands this across
     * a rotation via onRetainCustomNonConfigurationInstance so the
     * recreated instance can pick up the id a brand-new note was just
     * assigned. Callers that don't need the result (e.g.
     * FloatingNoteService tearing down a window for good) can simply not
     * await it - the write still completes independently either way.
     *
     * This never blocks the calling thread: it only launches the work and
     * returns immediately, which is what makes it safe to call from
     * onPause()/onDestroy() without freezing the UI.
     */
    fun saveOrDeleteIfEmptyDurable(note: Note): Deferred<Note> =
        durableScope.async { saveOrDeleteIfEmpty(note) }

    companion object {
        private const val TAG = "NoteRepository"
        private const val MAX_CONFLICT_RETRIES = 3

        @Volatile private var instance: NoteRepository? = null
        fun getInstance(context: Context): NoteRepository =
            instance ?: synchronized(this) {
                instance ?: NoteRepository(NoteDbHelper(context.applicationContext)).also { instance = it }
            }
    }
}
