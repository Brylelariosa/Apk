package com.jarry.floatnote.util

import android.content.Context
import android.widget.TextView

/** Default note content text size in sp - matches the fixed size the app
 *  shipped with before this became a user preference. */
const val DEFAULT_CONTENT_TEXT_SIZE_SP = 13f
const val MIN_CONTENT_TEXT_SIZE_SP = 10f
const val MAX_CONTENT_TEXT_SIZE_SP = 24f

// Line spacing is kept proportional to text size rather than a fixed value,
// so bigger text doesn't end up cramped and smaller text doesn't end up with
// oversized gaps between lines.
private const val LINE_SPACING_RATIO = 0.2f

/**
 * Applies the user's chosen note content text size (see
 * [PrefsManager.getContentTextSizeSp]) to [textView], along with a
 * proportionally-scaled line spacing so the two stay visually balanced at
 * any size. Used for the note content field on both the full-screen editor
 * and each floating card.
 */
fun applyContentTextSize(textView: TextView, context: Context) {
    val sizeSp = PrefsManager.getContentTextSizeSp(context)
    textView.textSize = sizeSp
    val lineSpacingExtraPx = context.dpToPx(sizeSp * LINE_SPACING_RATIO).toFloat()
    textView.setLineSpacing(lineSpacingExtraPx, 1f)
}
