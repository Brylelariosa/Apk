package com.jarry.floatnote.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.View
import com.google.android.material.snackbar.Snackbar
import com.jarry.floatnote.R

/**
 * Shared "display over other apps" permission check, used by every entry
 * point that can start FloatingNoteService. Centralizing this avoids the bug
 * where one entry point checks the permission and another forgets to -
 * calling WindowManager.addView(TYPE_APPLICATION_OVERLAY) without this
 * permission throws and crashes the app.
 */
object OverlayPermission {
    fun isGranted(context: Context): Boolean = Settings.canDrawOverlays(context)

    fun request(activity: Activity, anchor: View) {
        // startActivity can throw ActivityNotFoundException on a device/profile
        // with no app registered to handle this Settings screen - rare, but a
        // real crash risk that's cheap to guard against here.
        val opened = runCatching {
            activity.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${activity.packageName}"))
            )
        }.isSuccess
        val message = if (opened) R.string.overlay_permission_snackbar else R.string.overlay_permission_settings_unavailable
        Snackbar.make(anchor, message, Snackbar.LENGTH_LONG).show()
    }
}
