package com.jarry.floatnote.data

/**
 * @param version Optimistic-concurrency token, incremented by 1 in the DB on
 *   every successful write. 0 means "never loaded from/written to the DB" -
 *   the same sentinel role [id]==0 plays for "not yet persisted". A caller
 *   holding a stale [version] (e.g. a floating note window that hasn't
 *   re-synced since the main list pinned or deleted it) has its next
 *   conditional write rejected instead of silently overwriting whatever
 *   changed - see NoteRepository.saveContentIfUnchanged.
 */
data class Note(
    val id: Long = 0L,
    val title: String = "",
    val content: String = "",
    val styleIndex: Int = 0,
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val version: Int = 0
)
