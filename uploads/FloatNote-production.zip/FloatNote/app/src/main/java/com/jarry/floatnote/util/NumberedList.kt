package com.jarry.floatnote.util

import android.widget.EditText

// e.g. "1/45" or "1/45gap" (case-insensitive, optional spaces around the slash).
private val NUMBERED_LIST_PATTERN = Regex("""(-?\d+)\s*/\s*(-?\d+)(gap)?""", RegexOption.IGNORE_CASE)

/**
 * Looks for a typed range token (e.g. "1/45" or "1/45gap") on the line the
 * cursor is currently on, and replaces that token in place with the expanded
 * numbered list:
 *
 *   "1/45"    -> "1.\n2.\n3.\n...\n45."
 *   "1/45gap" -> "1.\n\n2.\n\n3.\n\n...\n\n45." (blank line between numbers)
 *
 * Ranges can also count down (e.g. "45/1"). Returns true if a token was
 * found and expanded, false if the current line had nothing to expand -
 * callers can use that to show a hint.
 */
fun expandNumberedListToken(editText: EditText): Boolean {
    val editable = editText.text ?: return false
    val text = editable.toString()
    val cursor = editText.selectionStart.coerceIn(0, editable.length)

    val lineStart = text.lastIndexOf('\n', cursor - 1) + 1
    val lineEnd = text.indexOf('\n', cursor).let { if (it == -1) text.length else it }
    val line = text.substring(lineStart, lineEnd)

    val match = NUMBERED_LIST_PATTERN.find(line) ?: return false
    // Parsed as Long and clamped well within Int range *before* any
    // arithmetic is done on them - otherwise a token like
    // "2147483647/2147483647" would overflow the from+999/from-999 below
    // (Int wraps instead of throwing), silently turning the 1000-number
    // safety cap into a multi-billion-entry range and freezing/crashing the
    // app instead of being capped.
    val from = (match.groupValues[1].toLongOrNull() ?: return false)
        .coerceIn(-1_000_000L, 1_000_000L).toInt()
    val to = (match.groupValues[2].toLongOrNull() ?: from.toLong())
        .coerceIn(-1_000_000L, 1_000_000L).toInt()
    val withGap = match.groupValues[3].isNotEmpty()

    // Cap at 1000 numbers so a typo (or a very ambitious range) can't
    // generate a multi-megabyte string and freeze the editor.
    val cappedTo = if (to >= from) minOf(to, from + 999) else maxOf(to, from - 999)
    val range = if (from <= cappedTo) from..cappedTo else from downTo cappedTo
    val separator = if (withGap) "\n\n" else "\n"
    val list = range.joinToString(separator) { "$it. " }

    val matchStart = lineStart + match.range.first
    val matchEnd = lineStart + match.range.last + 1
    editable.replace(matchStart, matchEnd, list)
    editText.setSelection((matchStart + list.length).coerceAtMost(editable.length))
    return true
}
