package com.jarry.floatnote.util

import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Debouncer backs autosave in both NoteEditorActivity and every floating
 * note window - this is the timing/cancellation contract the rest of the
 * app's autosave behavior depends on. No Robolectric needed: Debouncer
 * itself has no Android dependency, only a CoroutineScope, so a plain
 * kotlinx-coroutines-test virtual-time scope is enough.
 */
class DebouncerTest {

    @Test
    fun `only the last scheduled action runs after rapid rescheduling`() = runTest {
        val debouncer = Debouncer(this, delayMillis = 600L)
        var runs = 0
        var lastValue = -1

        // Simulates a burst of keystrokes: each one reschedules before the
        // previous 600ms window elapses.
        for (value in 0..4) {
            debouncer.schedule { runs++; lastValue = value }
            advanceTimeBy(200)
        }
        advanceTimeBy(601)

        assertEquals("only the final schedule() call should ever fire", 1, runs)
        assertEquals(4, lastValue)
    }

    @Test
    fun `cancel prevents a pending action from ever running`() = runTest {
        val debouncer = Debouncer(this, delayMillis = 600L)
        var ran = false

        debouncer.schedule { ran = true }
        advanceTimeBy(300) // still inside the debounce window
        debouncer.cancel()
        advanceTimeBy(1000)

        assertEquals(false, ran)
    }

    @Test
    fun `an action that already completes is unaffected by a later cancel`() = runTest {
        val debouncer = Debouncer(this, delayMillis = 600L)
        var runs = 0

        debouncer.schedule { runs++ }
        advanceTimeBy(601) // action has already run
        debouncer.cancel() // no pending job left to cancel

        assertEquals(1, runs)
    }

    @Test
    fun `scheduling again after a run starts a fresh independent debounce window`() = runTest {
        val debouncer = Debouncer(this, delayMillis = 600L)
        var runs = 0

        debouncer.schedule { runs++ }
        advanceTimeBy(601)
        assertEquals(1, runs)

        debouncer.schedule { runs++ }
        advanceTimeBy(601)
        assertEquals(2, runs)
    }
}
