package com.jarry.floatnote.util

import android.widget.EditText
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * Lightweight coverage for UndoRedoManager's debounced checkpointing and
 * undo/redo stack behavior. This class wasn't touched by the persistence
 * refactor, but had no test coverage at all beforehand - these lock in its
 * existing, correct behavior (debounced checkpoints, undo/redo, redo
 * invalidation on a fresh edit) so a future change can't silently break it.
 * A real EditText is used (via Robolectric) rather than a fake/interface,
 * since the class's whole job is reacting to a real TextWatcher callback
 * sequence, which is exactly what would be lost by mocking it.
 */
@RunWith(RobolectricTestRunner::class)
class UndoRedoManagerTest {

    private lateinit var editText: EditText

    @Before
    fun setUp() {
        editText = EditText(ApplicationProvider.getApplicationContext())
    }

    @Test
    fun `a burst of typing becomes a single undo step once the debounce settles`() = runTest {
        val manager = UndoRedoManager(editText, this)

        editText.setText("H")
        editText.setText("He")
        editText.setText("Hello")
        assertFalse("no checkpoint yet - still inside the 700ms debounce window", manager.canUndo())

        advanceTimeBy(701)
        assertTrue(manager.canUndo())

        manager.undo()
        assertEquals("", editText.text.toString())
    }

    @Test
    fun `redo restores what undo just took back`() = runTest {
        val manager = UndoRedoManager(editText, this)
        editText.setText("Hello")
        advanceTimeBy(701)

        manager.undo()
        assertEquals("", editText.text.toString())
        assertTrue(manager.canRedo())

        manager.redo()
        assertEquals("Hello", editText.text.toString())
    }

    @Test
    fun `a new edit after undo clears the redo stack`() = runTest {
        val manager = UndoRedoManager(editText, this)
        editText.setText("Hello")
        advanceTimeBy(701)
        manager.undo()
        assertTrue(manager.canRedo())

        editText.setText("Different branch")
        advanceTimeBy(701)
        assertFalse("a fresh edit should discard now-stale redo history", manager.canRedo())
    }

    @Test
    fun `reset clears history without touching the current text`() = runTest {
        val manager = UndoRedoManager(editText, this)
        editText.setText("Hello")
        advanceTimeBy(701)
        assertTrue(manager.canUndo())

        manager.reset()
        assertFalse(manager.canUndo())
        assertFalse(manager.canRedo())
        assertEquals("Hello", editText.text.toString())
    }

    @Test
    fun `onStateChanged fires on checkpoint, undo, and redo`() = runTest {
        var notifications = 0
        val manager = UndoRedoManager(editText, this)
        manager.onStateChanged = { notifications++ }

        editText.setText("Hello")
        advanceTimeBy(701)
        assertEquals(1, notifications)

        manager.undo()
        assertEquals(2, notifications)

        manager.redo()
        assertEquals(3, notifications)
    }
}
