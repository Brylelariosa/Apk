package com.jarry.floatnote.data

import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * FloatingNoteWindow (in FloatingNoteService) is a private inner class tied
 * to a real Service, WindowManager, and inflated Views - exercising it
 * directly would need either a heavy Robolectric Service+WindowManager
 * shadow setup or an instrumented on-device test, neither of which is
 * "lightweight" or particularly maintainable for what's actually at risk
 * here. What FloatingNoteWindow does with a note's content is entirely
 * delegated to NoteRepository (see persistOrDeleteIfEmpty,
 * persistFinalSnapshotAsync, and destroy() in FloatingNoteService.kt) -
 * these tests exercise that same persistence contract directly, framed
 * around the actual scenarios a floating window hits in practice:
 * background autosave, service shutdown, and racing the main list.
 *
 * (The WindowManager/notification/view plumbing *around* that contract -
 * i.e. whether FloatingNoteWindow correctly calls these methods at the
 * right time - is covered by manual verification and the lifecycle-safety
 * reasoning documented directly in FloatingNoteService.kt, not by an
 * automated test. This gap is called out in the refactor's final report.)
 */
@RunWith(RobolectricTestRunner::class)
class FloatingNotePersistenceTest {

    private lateinit var repository: NoteRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        repository = NoteRepository(NoteDbHelper(context, dbName = null))
    }

    @Test
    fun `a floating window's background autosave preserves a pin toggled from the main list`() = runTest {
        // The floating window loads its note when first opened...
        val opened = repository.saveOrDeleteIfEmpty(Note(title = "Groceries", content = "milk"))

        // ...the user pins it from the main list while the window is still
        // open in the background...
        repository.setPinned(opened.id, true)

        // ...then keeps typing in the floating window, whose in-memory copy
        // doesn't know about the pin yet, and its debounced autosave fires.
        repository.saveOrDeleteIfEmpty(opened.copy(content = "milk, eggs, bread"))

        val final = repository.getById(opened.id)
        assertTrue("pin must survive the floating window's autosave", final!!.isPinned)
        assertEquals("milk, eggs, bread", final.content)
    }

    @Test
    fun `deleting a note from the main list while it's floating does not get silently resurrected`() = runTest {
        val opened = repository.saveOrDeleteIfEmpty(Note(title = "Temp", content = "scratch"))

        // Swiped away from the main list while the floating window is open.
        repository.delete(opened.id)

        // The floating window's own next autosave, still holding its
        // pre-delete copy, fires anyway (it has no way to know yet).
        val result = repository.saveOrDeleteIfEmpty(opened.copy(content = "still typing"))

        // The old row must stay gone rather than being re-created at the
        // same id (which would look like the delete silently failed)...
        assertNull(repository.getById(opened.id))
        // ...but the user's still-unsaved text is not dropped either: it
        // lands as a genuinely new note.
        assertNotEquals(opened.id, result.id)
        assertEquals("still typing", repository.getById(result.id)?.content)
    }

    @Test
    fun `a durable shutdown save completes for every simultaneously open floating window`() = runTest {
        // Mirrors FloatingNoteService.onDestroy(): several windows torn down
        // in the same pass, each firing its own durable, fire-and-forget save.
        val a = repository.saveOrDeleteIfEmptyDurable(Note(title = "Window A", content = "a"))
        val b = repository.saveOrDeleteIfEmptyDurable(Note(title = "Window B", content = "b"))
        val c = repository.saveOrDeleteIfEmptyDurable(Note(title = "", content = "")) // closed while still blank

        val savedA = a.await()
        val savedB = b.await()
        val savedC = c.await()

        assertNotEquals(0L, savedA.id)
        assertNotEquals(0L, savedB.id)
        assertEquals(0L, savedC.id) // blank note: nothing to persist
        assertEquals("a", repository.getById(savedA.id)?.content)
        assertEquals("b", repository.getById(savedB.id)?.content)
        assertEquals(2, repository.getAll().size)
    }

    @Test
    fun `closing one floating window's autosave never touches a different note`() = runTest {
        val noteA = repository.saveOrDeleteIfEmpty(Note(title = "A", content = "first"))
        val noteB = repository.saveOrDeleteIfEmpty(Note(title = "B", content = "second"))

        repository.saveOrDeleteIfEmptyDurable(noteA.copy(content = "first, edited")).await()

        assertEquals("first, edited", repository.getById(noteA.id)?.content)
        assertEquals("second", repository.getById(noteB.id)?.content)
    }
}
