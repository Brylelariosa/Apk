package com.jarry.floatnote.data

import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * Lightweight regression coverage for NoteRepository, focused on the
 * behaviors this refactor introduced or changed: conflict-safe content
 * saves, pin/content column isolation, autosave's save-or-delete-if-empty
 * rule, and the "durable" save path floating windows and the editor's
 * onPause() rely on. Each test gets its own in-memory database (see
 * NoteDbHelper's dbName=null) so tests never see each other's data.
 */
@RunWith(RobolectricTestRunner::class)
class NoteRepositoryTest {

    private lateinit var repository: NoteRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        repository = NoteRepository(NoteDbHelper(context, dbName = null))
    }

    // ---- Basic CRUD -----------------------------------------------------

    @Test
    fun `save inserts a new note and getById returns it`() = runTest {
        val id = repository.save(Note(title = "Groceries", content = "Milk, eggs"))
        val loaded = repository.getById(id)
        assertEquals("Groceries", loaded?.title)
        assertEquals("Milk, eggs", loaded?.content)
    }

    @Test
    fun `delete removes the row`() = runTest {
        val id = repository.save(Note(title = "Temp"))
        repository.delete(id)
        assertNull(repository.getById(id))
    }

    @Test
    fun `getAll filters by title or content and sorts pinned first`() = runTest {
        repository.save(Note(title = "Apple pie recipe"))
        val pinnedId = repository.save(Note(title = "Unrelated", content = "mentions apple once"))
        repository.setPinned(pinnedId, true)
        repository.save(Note(title = "Banana bread"))

        val results = repository.getAll("apple")
        assertEquals(2, results.size)
        // Pinned match sorts first even though it was saved after the other match.
        assertTrue(results.first().isPinned)
    }

    // ---- Autosave / save-or-delete-if-empty ------------------------------

    @Test
    fun `saveOrDeleteIfEmpty inserts non-blank content`() = runTest {
        val saved = repository.saveOrDeleteIfEmpty(Note(title = "Idea", content = "Ship it"))
        assertNotEquals(0L, saved.id)
        assertEquals(1, saved.version)
    }

    @Test
    fun `saveOrDeleteIfEmpty deletes an existing row when cleared to blank`() = runTest {
        val saved = repository.saveOrDeleteIfEmpty(Note(title = "Draft", content = "text"))
        val cleared = repository.saveOrDeleteIfEmpty(saved.copy(title = "", content = ""))
        assertEquals(0L, cleared.id)
        assertNull(repository.getById(saved.id))
    }

    @Test
    fun `saveOrDeleteIfEmpty on a still-blank new note never inserts a row`() = runTest {
        val result = repository.saveOrDeleteIfEmpty(Note())
        assertEquals(0L, result.id)
    }

    @Test
    fun `repeated autosave calls update the same row instead of inserting duplicates`() = runTest {
        var note = repository.saveOrDeleteIfEmpty(Note(title = "v1"))
        val firstId = note.id
        note = repository.saveOrDeleteIfEmpty(note.copy(title = "v2"))
        note = repository.saveOrDeleteIfEmpty(note.copy(title = "v3"))

        assertEquals(firstId, note.id)
        assertEquals("v3", repository.getById(firstId)?.title)
        assertEquals(1, repository.getAll().size)
    }

    // ---- Conflict resolution ---------------------------------------------

    @Test
    fun `saveContentIfUnchanged succeeds and increments version when expectedVersion matches`() = runTest {
        val saved = repository.saveOrDeleteIfEmpty(Note(title = "a", content = "b"))
        val outcome = repository.saveContentIfUnchanged(saved.copy(title = "a2"), saved.version)
        val result = outcome as SaveOutcome.Saved
        assertEquals(saved.version + 1, result.note.version)
        assertEquals("a2", repository.getById(saved.id)?.title)
    }

    @Test
    fun `saveContentIfUnchanged reports Conflict when the version moved on`() = runTest {
        val saved = repository.saveOrDeleteIfEmpty(Note(title = "a", content = "b"))
        // Someone else's write lands first (e.g. a different window's autosave).
        repository.saveContentIfUnchanged(saved.copy(content = "elsewhere"), saved.version)

        // This caller is still holding the *original* version number.
        val outcome = repository.saveContentIfUnchanged(saved.copy(title = "stale writer"), saved.version)
        assertEquals(SaveOutcome.Conflict, outcome)
        // The conflicting write must not have been applied.
        assertEquals("elsewhere", repository.getById(saved.id)?.content)
    }

    @Test
    fun `saveContentIfUnchanged reports DeletedElsewhere and never resurrects the row`() = runTest {
        val saved = repository.saveOrDeleteIfEmpty(Note(title = "a", content = "b"))
        repository.delete(saved.id)

        val outcome = repository.saveContentIfUnchanged(saved.copy(title = "too late"), saved.version)
        assertEquals(SaveOutcome.DeletedElsewhere, outcome)
        assertNull(repository.getById(saved.id))
    }

    @Test
    fun `saveOrDeleteIfEmpty transparently recovers from a deleted-elsewhere conflict by inserting fresh`() = runTest {
        val saved = repository.saveOrDeleteIfEmpty(Note(title = "a", content = "b"))
        repository.delete(saved.id)

        // Simulates a floating window's next autosave firing after the main
        // list swiped the note away: the user's still-unsaved edit must not
        // be silently dropped.
        val result = repository.saveOrDeleteIfEmpty(saved.copy(content = "still typing"))
        assertNotEquals(saved.id, result.id)
        assertNotEquals(0L, result.id)
        assertEquals("still typing", repository.getById(result.id)?.content)
    }

    // ---- Pin / content column isolation -----------------------------------

    @Test
    fun `setPinned never touches title or content`() = runTest {
        val saved = repository.saveOrDeleteIfEmpty(Note(title = "keep me", content = "keep me too"))
        repository.setPinned(saved.id, true)
        val reloaded = repository.getById(saved.id)
        assertTrue(reloaded!!.isPinned)
        assertEquals("keep me", reloaded.title)
        assertEquals("keep me too", reloaded.content)
    }

    @Test
    fun `a stale content save never clobbers a pin toggled elsewhere`() = runTest {
        val saved = repository.saveOrDeleteIfEmpty(Note(title = "a", content = "b"))
        // A floating window loaded the note before it was pinned from the list.
        val staleCopy = saved
        repository.setPinned(saved.id, true)

        // The floating window's autosave fires afterward with its
        // (pin-unaware) in-memory copy.
        repository.saveOrDeleteIfEmpty(staleCopy.copy(content = "edited in floating window"))

        val reloaded = repository.getById(saved.id)
        assertTrue("pin toggled from the list must survive a concurrent content save", reloaded!!.isPinned)
        assertEquals("edited in floating window", reloaded.content)
    }

    // ---- Durable persistence (floating note / onPause style) --------------

    @Test
    fun `saveOrDeleteIfEmptyDurable completes even though nothing awaits it immediately`() = runTest {
        val deferred = repository.saveOrDeleteIfEmptyDurable(Note(title = "background save", content = "x"))
        val result = deferred.await()
        assertNotEquals(0L, result.id)
        assertEquals("background save", repository.getById(result.id)?.title)
    }

    @Test
    fun `saveOrDeleteIfEmptyDurable for a brand new note lets a later caller adopt its id`() = runTest {
        // Mirrors NoteEditorActivity's rotation hand-off: onPause() fires a
        // durable save for a still-unsaved note, and the recreated instance
        // awaits the same Deferred instead of racing it with its own insert.
        val deferred = repository.saveOrDeleteIfEmptyDurable(Note(content = "typed just before rotating"))
        val adopted = deferred.await()
        assertFalse(adopted.id == 0L)
    }
}
