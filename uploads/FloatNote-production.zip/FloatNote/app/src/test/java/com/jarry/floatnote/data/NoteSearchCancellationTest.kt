package com.jarry.floatnote.data

import android.os.CancellationSignal
import android.os.OperationCanceledException
import androidx.test.core.app.ApplicationProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * Regression coverage for the two things that made search cancellation
 * unreliable before this refactor:
 *  1. A cancelled query used to run to completion anyway (its result was
 *     merely discarded by the coroutine machinery) instead of actually
 *     being interrupted - see NoteDbHelper.getAll's CancellationSignal.
 *  2. NoteRepository's blanket `catch (e: Exception)` could in principle
 *     swallow a CancellationException and turn it into a normal-looking
 *     empty list instead of letting it propagate - see the explicit
 *     CancellationException/OperationCanceledException catches ahead of
 *     the generic one in NoteRepository.getAll.
 */
@RunWith(RobolectricTestRunner::class)
class NoteSearchCancellationTest {

    private lateinit var dbHelper: NoteDbHelper
    private lateinit var repository: NoteRepository

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        dbHelper = NoteDbHelper(context, dbName = null)
        repository = NoteRepository(dbHelper)
    }

    @Test(expected = OperationCanceledException::class)
    fun `a pre-cancelled signal interrupts the query instead of letting it run`() {
        val signal = CancellationSignal()
        signal.cancel()
        dbHelper.getAll("", signal)
    }

    @Test
    fun `an uncancelled search still returns matching notes normally`() = runTest {
        repository.save(Note(title = "Quarterly report"))
        repository.save(Note(title = "Grocery list"))

        val results = repository.getAll("report")

        assertEquals(1, results.size)
        assertEquals("Quarterly report", results[0].title)
    }

    @Test
    fun `cancelling the coroutine running getAll leaves the job cancelled, not completed`() = runTest {
        repository.save(Note(title = "Should never be seen by a cancelled caller"))

        val job = launch { repository.getAll("never") }
        job.cancel()
        job.join()

        // Locks in that a superseded search's Job ends up Cancelled rather
        // than Completed - the property MainActivity.loadNotes relies on to
        // know a stale result was never applied to the adapter. See
        // NoteDbHelper's CancellationSignal wiring and the explicit
        // CancellationException/OperationCanceledException catches ahead of
        // the generic one in NoteRepository.getAll for how this is kept
        // true even when the underlying query races the cancellation.
        assertTrue(job.isCancelled)
        assertTrue(job.isCompleted)
    }
}
