package com.jarry.floatnote.util

import android.view.ViewGroup
import android.widget.ImageView
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

/**
 * applyBubbleVisuals/bubbleWindowSizePx are the shared math behind both the
 * real floating bubble (FloatingNoteService.collapseToBubble, via
 * applyBubbleAppearance) and the Settings screen's live preview
 * (SettingsActivity.updateBubblePreview) - this is what keeps those two
 * from silently drifting apart as either is tuned. Needs Robolectric only
 * for a Context to resolve dp-to-px and a plain View to assert against;
 * unlike FloatingNoteWindow itself, nothing here touches a real
 * Service/WindowManager.
 */
@RunWith(RobolectricTestRunner::class)
class BubbleAppearanceTest {

    private val context = ApplicationProvider.getApplicationContext<android.content.Context>()

    /** A bare View has null layoutParams until something gives it some -
     *  matches an inflated icon's real starting state closely enough for
     *  applyBubbleVisuals (which mutates width/height on whatever's there)
     *  to have something to mutate. */
    private fun newIconView() = ImageView(context).apply {
        layoutParams = ViewGroup.LayoutParams(0, 0)
    }

    @Test
    fun `applyBubbleVisuals sizes the icon and scales its inset with it`() {
        val icon = newIconView()

        applyBubbleVisuals(icon, sizeDp = 40f, opacityPercent = 100, context)

        val expectedSizePx = context.dpToPx(40f)
        assertEquals(expectedSizePx, icon.layoutParams.width)
        assertEquals(expectedSizePx, icon.layoutParams.height)
        // 25% inset ratio, documented on applyBubbleVisuals/ICON_INSET_RATIO -
        // asserted here as the public, expected behavior rather than by
        // reading the private constant.
        assertEquals((expectedSizePx * 0.25f).toInt(), icon.paddingLeft)
        assertEquals((expectedSizePx * 0.25f).toInt(), icon.paddingTop)
    }

    @Test
    fun `applyBubbleVisuals converts opacity percent to a 0 point-1 alpha`() {
        val icon = newIconView()

        applyBubbleVisuals(icon, sizeDp = MIN_BUBBLE_SIZE_DP, opacityPercent = 55, context)

        assertEquals(0.55f, icon.alpha, 0.001f)
    }

    @Test
    fun `a larger icon gets a proportionally larger inset, not a fixed one`() {
        val small = newIconView()
        val large = newIconView()

        applyBubbleVisuals(small, sizeDp = MIN_BUBBLE_SIZE_DP, opacityPercent = 100, context)
        applyBubbleVisuals(large, sizeDp = MAX_BUBBLE_SIZE_DP, opacityPercent = 100, context)

        assertEquals(true, large.paddingLeft > small.paddingLeft)
    }

    @Test
    fun `bubbleWindowSizePx grows with the chosen visible size once past the touch-target floor`() {
        val atMinVisibleSize = bubbleWindowSizePx(context, MIN_BUBBLE_SIZE_DP)
        val atMaxVisibleSize = bubbleWindowSizePx(context, MAX_BUBBLE_SIZE_DP)

        assertEquals(true, atMaxVisibleSize > atMinVisibleSize)
    }

    @Test
    fun `bubbleWindowSizePx never shrinks the touch target below the accessibility floor`() {
        // Even the smallest allowed visible bubble (MIN_BUBBLE_SIZE_DP, well
        // under Android's ~48dp touch-target guidance) must still resolve to
        // a window at or above that floor.
        val windowPx = bubbleWindowSizePx(context, MIN_BUBBLE_SIZE_DP)

        assertEquals(true, windowPx >= context.dpToPx(48f))
    }
}
