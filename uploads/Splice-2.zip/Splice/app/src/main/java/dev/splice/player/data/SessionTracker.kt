package dev.splice.player.data

import android.app.ActivityManager
import android.content.Context
import android.os.Process
import dev.splice.player.core.AppLog
import dev.splice.player.core.Paths
import org.json.JSONObject
import java.io.File

/**
 * A tiny marker file records the running play session so the UI process can tell, after returning
 * from a game, whether it ended normally (play time + auto-backup) or crashed.
 */
object SessionTracker {
    class Session(val gameId: String, val engine: String, val start: Long, val end: Long, val log: String, val pid: Int)

    class Outcome(val game: dev.splice.player.model.Game?, val crashed: Boolean, val log: String?, val durationMs: Long)

    private fun file() = File(Paths.root, "session.json")

    @Synchronized
    private fun write(s: Session) {
        try {
            val o = JSONObject().put("gameId", s.gameId).put("engine", s.engine).put("start", s.start)
                .put("end", s.end).put("log", s.log).put("pid", s.pid)
            val tmp = File(Paths.root, "session.json.tmp")
            tmp.writeText(o.toString())
            if (!tmp.renameTo(file())) {
                file().delete()
                tmp.renameTo(file())
            }
        } catch (t: Throwable) {
            AppLog.w("session", "marker write failed", t)
        }
    }

    fun read(): Session? {
        return try {
            val f = file()
            if (!f.exists()) return null
            val o = JSONObject(f.readText())
            Session(o.getString("gameId"), o.optString("engine"), o.optLong("start"), o.optLong("end"), o.optString("log"), o.optInt("pid"))
        } catch (t: Throwable) {
            null
        }
    }

    fun begin(gameId: String, engine: String, log: String) {
        write(Session(gameId, engine, System.currentTimeMillis(), 0L, log, Process.myPid()))
    }

    /** Called inside the game process (RGSS) once it is really running: records its pid. */
    fun attach() {
        val s = read() ?: return
        if (s.end == 0L) write(Session(s.gameId, s.engine, s.start, 0L, s.log, Process.myPid()))
    }

    fun end() {
        val s = read() ?: return
        if (s.end == 0L) write(Session(s.gameId, s.engine, s.start, System.currentTimeMillis(), s.log, s.pid))
    }

    private fun processAlive(ctx: Context, name: String): Boolean {
        return try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.runningAppProcesses?.any { it.processName == name } ?: false
        } catch (t: Throwable) {
            false
        }
    }

    /** True while an RGSS game process exists. */
    fun rgssRunning(ctx: Context): Boolean = processAlive(ctx, ctx.packageName + ":rgss")

    /**
     * Called by the UI whenever it becomes visible. Finalises a finished or crashed session
     * (play time, auto-backup) and returns what happened, or null if nothing is pending.
     */
    fun finalizeIfNeeded(ctx: Context, webAlive: Boolean): Outcome? {
        val s = read() ?: return null
        val g = Library.get(s.gameId)
        val stillRunning = if (s.engine == "rgss") rgssRunning(ctx) else webAlive
        if (s.end == 0L && stillRunning) return null
        val ended = s.end > 0L
        val end = if (ended) s.end else System.currentTimeMillis()
        val dur = (end - s.start).coerceAtLeast(0L)
        file().delete()
        if (g != null) {
            Library.addPlayTime(g.id, dur)
            SaveVault.autoBackup(g, "after-session")
        }
        return Outcome(g, !ended, s.log, dur)
    }
}
