package dev.splice.player.ui

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import dev.splice.player.R
import dev.splice.player.core.AppLog
import dev.splice.player.core.Paths
import dev.splice.player.data.Diagnostics
import dev.splice.player.data.ImportTask
import dev.splice.player.data.Importer
import dev.splice.player.data.Library
import dev.splice.player.data.SessionTracker
import dev.splice.player.data.StorageAccess
import dev.splice.player.engine.RgssLauncher
import dev.splice.player.engine.WebGameActivity
import dev.splice.player.model.EngineKind
import dev.splice.player.model.Game
import java.io.File

/** Single activity hosting the four tabs and pushed pages (game page, editors, viewers). */
class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private lateinit var bar: LinearLayout
    private lateinit var tabs: Array<Screen>
    private val tabViews = ArrayList<LinearLayout>()
    private val stack = ArrayList<Screen>()
    private var tabIndex = 0
    private var nextCode = 100
    private val pending = HashMap<Int, (Intent?) -> Unit>()
    var currentImport: ImportTask? = null
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(C.BG)
        content = FrameLayout(this)
        root.add(content, MATCH, 0, 1f)

        tabs = arrayOf(LibraryView(this), SavesView(this), LogsView(this), SettingsView(this))
        bar = buildBar()
        root.add(bar, MATCH, WRAP)
        setContentView(root)
        showTab(0, false)
    }

    // ---------- tabs ----------

    private fun buildBar(): LinearLayout {
        val b = hbox(false)
        b.setBackgroundColor(C.SURFACE)
        b.setPadding(dp(8), dp(6), dp(8), dp(6))
        val items = listOf(
            Pair("Library", R.drawable.ic_library), Pair("Saves", R.drawable.ic_saves),
            Pair("Logs", R.drawable.ic_logs), Pair("Settings", R.drawable.ic_settings)
        )
        items.forEachIndexed { i, (label, iconRes) ->
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.setPadding(0, dp(6), 0, dp(6))
            val pill = FrameLayout(this)
            val ic = icon(iconRes, C.DIM, 22)
            pill.addView(ic, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            col.add(pill, dp(56), dp(30))
            col.add(text(label, 11.5f, C.DIM, 1), WRAP, WRAP, 0f, 0, 3, 0, 0)
            col.background = ripple(null, 14f)
            col.isClickable = true
            col.setOnClickListener { if (stack.isNotEmpty()) clearStack(); showTab(i, true) }
            b.add(col, 0, WRAP, 1f)
            tabViews.add(col)
        }
        return b
    }

    private fun paintTabs() {
        tabViews.forEachIndexed { i, col ->
            val active = i == tabIndex
            val pill = col.getChildAt(0) as FrameLayout
            pill.background = if (active) shape(0x265BE3C4, 16f) else null
            (pill.getChildAt(0) as ImageView).setColorFilter(if (active) C.MINT else C.DIM)
            (col.getChildAt(1) as TextView).setTextColor(if (active) C.MINT else C.DIM)
        }
    }

    private fun showTab(i: Int, animate: Boolean) {
        val old = tabs[tabIndex]
        if (content.childCount > 0 && i != tabIndex) old.onHide()
        tabIndex = i
        val s = tabs[i]
        if (s.parent == null) content.addView(s, FrameLayout.LayoutParams(MATCH, MATCH))
        for (t in tabs) t.visibility = if (t === s) View.VISIBLE else View.GONE
        if (animate) {
            s.alpha = 0f
            s.animate().alpha(1f).setDuration(180).start()
        }
        paintTabs()
        s.onShow()
    }

    private fun current(): Screen = if (stack.isNotEmpty()) stack[stack.size - 1] else tabs[tabIndex]

    // ---------- pushed pages ----------

    fun push(s: Screen) {
        current().onHide()
        stack.add(s)
        content.addView(s, FrameLayout.LayoutParams(MATCH, MATCH))
        s.alpha = 0f
        s.translationX = dpf(36f)
        s.animate().alpha(1f).translationX(0f).setDuration(240).setInterpolator(DecelerateInterpolator()).start()
        bar.visibility = View.GONE
        s.onShow()
    }

    fun pop() {
        if (stack.isEmpty()) return
        val s = stack.removeAt(stack.size - 1)
        s.onHide()
        s.animate().alpha(0f).translationX(dpf(28f)).setDuration(170).withEndAction {
            content.removeView(s)
            s.onDestroyScreen()
        }.start()
        if (stack.isEmpty()) bar.visibility = View.VISIBLE
        current().onShow()
    }

    private fun clearStack() {
        for (s in ArrayList(stack)) {
            content.removeView(s)
            s.onDestroyScreen()
        }
        stack.clear()
        bar.visibility = View.VISIBLE
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val c = current()
        if (c.onBack()) return
        if (stack.isNotEmpty()) {
            pop()
        } else if (tabIndex != 0) {
            showTab(0, true)
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        for (t in tabs) t.requestLayout()
    }

    // ---------- results ----------

    fun launchForResult(intent: Intent, cb: (Intent?) -> Unit) {
        val code = nextCode++
        pending[code] = cb
        try {
            startActivityForResult(intent, code)
        } catch (t: Throwable) {
            pending.remove(code)
            toast("No app can handle this action on your device")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        pending.remove(requestCode)?.invoke(if (resultCode == RESULT_OK) data else null)
    }

    override fun onResume() {
        super.onResume()
        val outcome = SessionTracker.finalizeIfNeeded(this, WebGameActivity.alive)
        if (outcome != null && outcome.crashed) {
            val s = Sheet(this, "That session ended unexpectedly", outcome.game?.title)
            s.add(text("The game stopped without closing normally. The session log may show why, and Troubleshoot can suggest compatibility fixes.", 14f, C.DIM))
            val row = hbox()
            row.add(button("Dismiss", 0, BTN_GHOST) { s.dismiss() }, 0, WRAP, 1f, 0, 0, 8, 0)
            val g = outcome.game
            val logPath = outcome.log
            row.add(button("View log", R.drawable.ic_logs, BTN_PRIMARY) {
                s.dismiss()
                if (logPath != null && File(logPath).exists()) push(LogViewerView(this, "Session log", File(logPath)))
            }, 0, WRAP, 1f, 8, 0, 0, 0)
            s.add(row, 18)
            if (g != null) s.add(button("Open Troubleshoot", R.drawable.ic_shield, BTN_TONAL) {
                s.dismiss()
                push(TroubleshootView(this, g))
            }, 10)
            s.show()
        }
        current().onShow()
    }

    // ---------- play ----------

    fun openGame(g: Game) {
        push(GameDetailView(this, g.id))
    }

    fun play(g: Game) {
        val errors = Diagnostics.run(this, g).filter { it.level == Diagnostics.ERROR }
        if (errors.isNotEmpty()) {
            val s = Sheet(this, "Can't start yet", g.title)
            for (e in errors) {
                val col = vbox()
                col.setPadding(dp(14), dp(12), dp(14), dp(12))
                col.background = shape(0x22FF6B7A, 12f)
                col.addView(text(e.title, 14.5f, C.DANGER, 1))
                col.add(text(e.detail, 13f, C.DIM), MATCH, WRAP, 0f, 0, 4, 0, 0)
                s.add(col, 10)
            }
            val row = hbox()
            if (errors.any { it.title.startsWith("Storage access") }) {
                row.add(button("Grant access", R.drawable.ic_folder, BTN_PRIMARY) {
                    s.dismiss()
                    StorageAccess.request(this)
                }, 0, WRAP, 1f, 0, 0, 8, 0)
            }
            row.add(button("Troubleshoot", R.drawable.ic_shield, BTN_TONAL) {
                s.dismiss()
                push(TroubleshootView(this, g))
            }, 0, WRAP, 1f, 0, 0, 0, 0)
            s.add(row, 16)
            s.show()
            return
        }
        val err = if (g.format.engine == EngineKind.RGSS) RgssLauncher.launch(this, g) else WebGameActivity.launch(this, g)
        if (err != null) {
            val s = Sheet(this, "Couldn't start the game", g.title)
            s.add(text(err, 14f, C.DIM))
            s.add(button("OK", 0, BTN_TONAL) { s.dismiss() }, 16)
            s.show()
        }
    }

    // ---------- importing ----------

    fun importZip() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
        launchForResult(i) { data ->
            val uri = data?.data
            if (uri != null) startImport(ImportTask("Archive")) { t -> Importer.importZip(this, uri, t) { onImportDone(it) } }
        }
    }

    fun importFolder() {
        val go = {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            launchForResult(i) { data ->
                val uri: Uri? = data?.data
                if (uri != null) startImport(ImportTask("Folder")) { t -> Importer.importTree(this, uri, t) { onImportDone(it) } }
            }
        }
        if (StorageAccess.hasAllFiles(this)) {
            go()
        } else {
            val s = Sheet(this, "Add a game folder", "Pick a game folder, or a folder that contains several games")
            s.add(text("Without \"All files access\" Splice has to copy the game into its own storage, which takes time and space. Granting access lets games stay where they are (recommended).", 13.5f, C.DIM))
            val col = vbox()
            col.add(button("Grant All files access", R.drawable.ic_folder, BTN_PRIMARY) {
                s.dismiss()
                StorageAccess.request(this)
            }, MATCH, WRAP, 0f, 0, 14, 0, 0)
            col.add(button("Continue and copy", R.drawable.ic_import, BTN_TONAL) {
                s.dismiss()
                go()
            }, MATCH, WRAP, 0f, 0, 8, 0, 0)
            s.add(col)
            s.show()
        }
    }

    private fun startImport(task: ImportTask, starter: (ImportTask) -> Unit) {
        if (currentImport?.finished == false) {
            toast("Another import is still running")
            return
        }
        currentImport = task
        (tabs[0] as LibraryView).trackImport(task)
        starter(task)
    }

    private fun onImportDone(task: ImportTask) {
        val err = task.error
        if (err != null) {
            AppLog.w("import", "import ended: $err")
            toast(err)
        } else {
            toast(if (task.added.size == 1) "Added ${task.added[0].title}" else "Added ${task.added.size} games")
        }
    }

    fun gamesDirInfo(): File = Paths.games

    fun libraryHasGames(): Boolean = Library.all().isNotEmpty()
}
