package dev.splice.player.data

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import dev.splice.player.core.AppLog
import dev.splice.player.core.Bg
import dev.splice.player.core.Files
import dev.splice.player.core.Paths
import dev.splice.player.model.Game
import dev.splice.player.model.Profile
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** Progress/result holder for one import, polled by the UI. */
class ImportTask(val label: String) {
    val cancel = AtomicBoolean(false)

    @Volatile var message: String = "Preparing"
    @Volatile var bytes: Long = 0
    @Volatile var total: Long = 0
    @Volatile var files: Int = 0
    @Volatile var finished: Boolean = false
    @Volatile var error: String? = null
    @Volatile var added: List<Game> = emptyList()

    /** 0..1, or -1 when the total is unknown */
    val fraction: Float
        get() = if (total > 0) (bytes.toFloat() / total.toFloat()).coerceIn(0f, 1f) else -1f
}

object Importer {
    // ---------- public entry points ----------

    fun importZip(ctx: Context, uri: Uri, task: ImportTask, done: (ImportTask) -> Unit) {
        Bg.io.execute {
            val work = File(Paths.games, ".tmp-" + Library.newId())
            try {
                val cr = ctx.contentResolver
                task.total = querySize(cr, uri)
                task.message = "Extracting archive"
                work.mkdirs()
                Zip.extract({ cr.openInputStream(uri) }, work, task.cancel) { bytes, name ->
                    if (bytes >= 0) {
                        task.bytes = bytes
                    } else {
                        task.files++
                        if (name.isNotEmpty()) task.message = name.substringAfterLast('/')
                    }
                }
                task.message = "Looking for games"
                task.added = adopt(work)
                if (task.added.isEmpty()) task.error = "No RPG Maker game was found in this archive."
            } catch (c: ImportCancelled) {
                task.error = "Cancelled"
            } catch (t: Throwable) {
                AppLog.e("import", "zip import failed", t)
                task.error = t.message ?: t.javaClass.simpleName
            } finally {
                Files.deleteRecursive(work)
                task.finished = true
                Bg.ui { done(task) }
            }
        }
    }

    /** Folder picked through the system file picker (content:// tree). */
    fun importTree(ctx: Context, tree: Uri, task: ImportTask, done: (ImportTask) -> Unit) {
        Bg.io.execute {
            val work = File(Paths.games, ".tmp-" + Library.newId())
            try {
                val real = StorageAccess.treeUriToPath(tree)
                if (real != null && StorageAccess.hasAllFiles(ctx)) {
                    task.message = "Scanning folder"
                    task.added = registerInPlace(real)
                } else {
                    task.message = "Copying files"
                    work.mkdirs()
                    copyTree(ctx, tree, work, task)
                    task.message = "Looking for games"
                    task.added = adopt(work)
                }
                if (task.added.isEmpty()) task.error = "No RPG Maker game was found in this folder."
            } catch (c: ImportCancelled) {
                task.error = "Cancelled"
            } catch (t: Throwable) {
                AppLog.e("import", "folder import failed", t)
                task.error = t.message ?: t.javaClass.simpleName
            } finally {
                Files.deleteRecursive(work)
                task.finished = true
                Bg.ui { done(task) }
            }
        }
    }

    /** Folder we can read directly (needs All files access): the game stays where it is. */
    fun importPath(dir: File, task: ImportTask, done: (ImportTask) -> Unit) {
        Bg.io.execute {
            try {
                task.message = "Scanning folder"
                task.added = registerInPlace(dir)
                if (task.added.isEmpty()) task.error = "No RPG Maker game was found in this folder."
            } catch (t: Throwable) {
                AppLog.e("import", "scan failed", t)
                task.error = t.message ?: t.javaClass.simpleName
            } finally {
                task.finished = true
                Bg.ui { done(task) }
            }
        }
    }

    // ---------- internals ----------

    fun newProfileFor(@Suppress("UNUSED_PARAMETER") g: Game): Profile {
        val p = Library.defaults()
        if (!p.json.has("orientation")) p.orientation = 1
        return p
    }

    private fun querySize(cr: ContentResolver, uri: Uri): Long {
        return try {
            cr.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
            } ?: -1L
        } catch (t: Throwable) {
            -1L
        }
    }

    private fun slug(title: String): String {
        val s = title.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "-").trim('-')
        return if (s.isEmpty()) "game" else s.take(32)
    }

    private fun registerInPlace(root: File): List<Game> {
        val added = ArrayList<Game>()
        for (r in Detector.scan(root, 3)) {
            val path = r.root.absolutePath
            if (Library.findByPath(path) != null) continue
            val g = Game(
                id = Library.newId(), title = r.title, path = path, format = r.format,
                webRoot = r.webRoot?.absolutePath, managed = false,
                tags = r.tags.toMutableSet(), execName = r.execName
            )
            Library.add(g, newProfileFor(g))
            added.add(g)
        }
        return added
    }

    /** Moves detected games from a temp folder into the managed games folder. */
    private fun adopt(work: File): List<Game> {
        val added = ArrayList<Game>()
        for (r in Detector.scan(work, 3)) {
            val id = Library.newId()
            val finalDir = File(Paths.games, slug(r.title) + "-" + id.take(6))
            val rel = r.webRoot?.relativeTo(r.root)?.path
            if (!r.root.renameTo(finalDir)) {
                Files.copyRecursive(r.root, finalDir)
                Files.deleteRecursive(r.root)
            }
            val web = if (rel == null) null else (if (rel.isEmpty()) finalDir else File(finalDir, rel)).absolutePath
            val g = Game(
                id = id, title = r.title, path = finalDir.absolutePath, format = r.format,
                webRoot = web, managed = true, tags = r.tags.toMutableSet(), execName = r.execName
            )
            Library.add(g, newProfileFor(g))
            added.add(g)
        }
        return added
    }

    private fun copyTree(ctx: Context, tree: Uri, dest: File, task: ImportTask) {
        val rootId = DocumentsContract.getTreeDocumentId(tree)
        copyDir(ctx, tree, rootId, dest, task)
    }

    private fun copyDir(ctx: Context, tree: Uri, docId: String, dest: File, task: ImportTask) {
        dest.mkdirs()
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val ids = ArrayList<String>()
        val names = ArrayList<String>()
        val dirs = ArrayList<Boolean>()
        ctx.contentResolver.query(childrenUri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                ids.add(c.getString(0))
                names.add(c.getString(1) ?: "unnamed")
                dirs.add(DocumentsContract.Document.MIME_TYPE_DIR == c.getString(2))
            }
        }
        val buf = ByteArray(128 * 1024)
        for (i in ids.indices) {
            if (task.cancel.get()) throw ImportCancelled()
            val name = names[i].replace('/', '_').replace('\\', '_')
            if (name == "." || name == "..") continue
            if (dirs[i]) {
                copyDir(ctx, tree, ids[i], File(dest, name), task)
            } else {
                val uri = DocumentsContract.buildDocumentUriUsingTree(tree, ids[i])
                val input = ctx.contentResolver.openInputStream(uri) ?: continue
                input.use { ins ->
                    File(dest, name).outputStream().use { out ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            task.bytes += n
                            if (task.cancel.get()) throw ImportCancelled()
                        }
                    }
                }
                task.files++
                task.message = name
            }
        }
    }
}
