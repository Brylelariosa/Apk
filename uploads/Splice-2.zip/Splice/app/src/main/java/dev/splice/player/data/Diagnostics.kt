package dev.splice.player.data

import android.content.Context
import dev.splice.player.core.Paths
import dev.splice.player.engine.EngineInfo
import dev.splice.player.model.EngineKind
import dev.splice.player.model.Game
import java.io.File
import java.util.Locale

/** Pre-launch checks and the "Troubleshoot" report. Every item is a real check of the actual files/device. */
object Diagnostics {
    const val OK = 0
    const val INFO = 1
    const val WARN = 2
    const val ERROR = 3

    class Check(val level: Int, val title: String, val detail: String)

    fun run(ctx: Context, g: Game): List<Check> {
        val out = ArrayList<Check>()
        val dir = g.dir
        if (!dir.isDirectory) {
            out.add(Check(ERROR, "Game folder is missing", "${g.path} no longer exists. Remove the game from the library or restore the folder."))
            return out
        }
        if (StorageAccess.needsPermission(ctx, dir)) {
            out.add(Check(ERROR, "Storage access needed", "The game lives outside Splice's folder. Grant \"All files access\" in Settings."))
        } else if (dir.listFiles() == null) {
            out.add(Check(ERROR, "Game folder is not readable", "Splice cannot list ${g.path}."))
        } else {
            out.add(Check(OK, "Game folder readable", g.path))
        }

        if (g.format.engine == EngineKind.RGSS) rgssChecks(ctx, g, out) else webChecks(ctx, g, out)

        val free = StorageAccess.freeBytes(Paths.root)
        if (free in 0..(200L * 1024 * 1024)) {
            out.add(Check(WARN, "Low storage", "Only ${dev.splice.player.core.Fmt.size(free)} free. Saves and backups need space."))
        }

        val sessions = Paths.sessionDir(g.id).listFiles()?.filter { it.name.endsWith(".log") }?.sortedByDescending { it.name }
        val last = sessions?.firstOrNull()
        if (last != null) {
            val text = try {
                dev.splice.player.core.Files.tail(last, 60_000)
            } catch (t: Throwable) {
                ""
            }
            if (text.contains("NATIVE CRASH")) {
                out.add(Check(ERROR, "Last session crashed natively", "See Logs for the backtrace (${last.name})."))
            } else if (Regex("(?i)(fatal|exception|error)").containsMatchIn(text)) {
                out.add(Check(WARN, "Errors in the last session", "The last log (${last.name}) contains errors. Open Logs to read them."))
            }
        }
        return out
    }

    private fun has(dir: File, vararg parts: String) = Detector.childPath(dir, *parts) != null

    private fun rgssChecks(ctx: Context, g: Game, out: ArrayList<Check>) {
        val problem = EngineInfo.rgssProblem(ctx)
        if (problem != null) out.add(Check(ERROR, "RGSS engine unavailable", problem))
        else out.add(Check(OK, "RGSS engine ready", "mkxp-z (${g.format.label}, RGSS${g.format.rgssVersion})"))

        val dir = g.dir
        val scripts = when (g.format.rgssVersion) {
            3 -> "Scripts.rvdata2"
            2 -> "Scripts.rvdata"
            else -> "Scripts.rxdata"
        }
        val hasScripts = has(dir, "Data", scripts)
        val archive = dir.listFiles()?.any { val n = it.name.lowercase(Locale.ROOT); n.endsWith(".rgssad") || n.endsWith(".rgss2a") || n.endsWith(".rgss3a") } ?: false
        if (hasScripts) out.add(Check(OK, "Game scripts found", "Data/$scripts"))
        else if (archive) out.add(Check(INFO, "Encrypted archive", "Game data is inside an .rgssad/.rgss3a archive; the engine reads it directly."))
        else out.add(Check(ERROR, "No game scripts", "Data/$scripts was not found. The folder may be incomplete."))

        val ini = Detector.child(dir, "Game.ini")
        if (ini == null) {
            out.add(Check(WARN, "Game.ini missing", "mkxp-z can usually run without it; the title and RGSS version come from the data files."))
        } else {
            try {
                val text = dev.splice.player.core.Files.readTextSmart(ini)
                val rtp = Regex("(?im)^\\s*RTP1?\\s*=\\s*(.*)$").find(text)?.groupValues?.get(1)?.trim().orEmpty()
                if (rtp.isNotEmpty() && !rtp.equals("none", true)) {
                    val extra = Library.profile(g.id).rtpExtra.isNotBlank()
                    out.add(
                        Check(
                            if (extra) INFO else WARN, "Uses the RPG Maker RTP ($rtp)",
                            if (extra) "Extra RTP folders are configured in this game's compatibility settings."
                            else "If the game shows missing graphics/audio, add the RTP folder under Compatibility > Extra RTP folders. Most fangames bundle everything."
                        )
                    )
                }
            } catch (ignored: Throwable) {
            }
        }
        if (g.isPokemon && !has(dir, "Graphics")) out.add(Check(WARN, "No Graphics folder", "This looks like a Pokémon Essentials game but Graphics/ is missing (it may be inside an archive)."))
        val legacy = SaveVault.legacyFiles(g)
        if (legacy.isNotEmpty() && Library.profile(g.id).redirectSaves) {
            out.add(Check(INFO, "Saves found in the game folder", "${legacy.size} file(s) will be copied into Splice's save vault on first launch (originals stay untouched)."))
        }
    }

    private fun webChecks(ctx: Context, g: Game, out: ArrayList<Check>) {
        val web = g.webRoot?.let { File(it) }
        if (web == null || Detector.child(web, "index.html") == null) {
            out.add(Check(ERROR, "index.html not found", "The web root of this game is missing."))
            return
        }
        out.add(Check(OK, "index.html found", web.absolutePath))
        val major = EngineInfo.webViewMajor(ctx)
        val need = if (g.format.label.endsWith("MZ")) 87 else 70
        if (major in 1 until need) {
            out.add(Check(WARN, "System WebView is old (Chromium $major)", "${g.format.label} needs Chromium $need or newer. Update \"Android System WebView\" in the Play Store."))
        } else if (major > 0) {
            out.add(Check(OK, "System WebView ready", EngineInfo.webViewVersion(ctx) ?: "Chromium $major"))
        } else {
            out.add(Check(INFO, "WebView version unknown", "Make sure Android System WebView is up to date."))
        }
        if (!has(web, "data", "System.json")) out.add(Check(WARN, "data/System.json missing", "The game data folder looks incomplete."))
        val enc = has(web, "img") && (Detector.childPath(web, "img", "system")?.listFiles()?.any { it.name.endsWith(".rpgmvp") || it.name.endsWith(".png_") } ?: false)
        if (enc) out.add(Check(INFO, "Encrypted assets", "Images and audio are decrypted by the game's own scripts."))
    }
}
