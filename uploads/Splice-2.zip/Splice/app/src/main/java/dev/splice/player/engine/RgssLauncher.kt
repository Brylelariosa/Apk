package dev.splice.player.engine

import android.app.Activity
import android.content.Intent
import dev.splice.player.core.AppLog
import dev.splice.player.core.Fmt
import dev.splice.player.core.Paths
import dev.splice.player.data.Library
import dev.splice.player.data.SaveVault
import dev.splice.player.data.SessionTracker
import dev.splice.player.data.StorageAccess
import dev.splice.player.model.Game

/** Prepares everything the mkxp-z engine needs and starts it in its own process. */
object RgssLauncher {
    const val EXTRA_GAME_ID = "splice.game_id"
    const val EXTRA_LOG = "splice.session_log"

    /** Returns an error message to show the user, or null when the engine was started. */
    fun launch(act: Activity, g: Game): String? {
        EngineInfo.rgssProblem(act)?.let { return it }
        if (!g.dir.isDirectory) return "The game folder no longer exists: ${g.path}"
        if (StorageAccess.needsPermission(act, g.dir)) return "Splice needs \"All files access\" to read games outside its own folder. Enable it in Settings."
        val p = Library.profile(g.id)
        return try {
            if (p.redirectSaves) {
                val moved = SaveVault.migrateLegacy(g)
                if (moved > 0) AppLog.i("rgss", "copied $moved legacy save file(s) into the vault for ${g.title}")
                MkxpConfig.writePreload(g)
            }
            SaveVault.autoBackup(g, "before-play")
            val cfg = MkxpConfig.build(g, p)
            val written = MkxpConfig.writeEverywhere(act, cfg)

            val log = Paths.newSessionLog(g.id)
            log.writeText(
                "== Splice session ${Fmt.date(System.currentTimeMillis())} ==\n" +
                    "game: ${g.title} (${g.format.label}, RGSS${g.format.rgssVersion})\n" +
                    "folder: ${g.path}\n" +
                    "mkxp.json written to:\n" + written.joinToString("\n") { "  $it" } + "\n" +
                    "--- engine output ---\n"
            )
            pruneLogs(g.id)

            g.lastPlayed = System.currentTimeMillis()
            Library.update(g)
            SessionTracker.begin(g.id, "rgss", log.absolutePath)

            val i = Intent()
            i.setClassName(act.packageName, EngineInfo.RGSS_ACTIVITY)
            i.putExtra(EXTRA_GAME_ID, g.id)
            i.putExtra(EXTRA_LOG, log.absolutePath)
            act.startActivity(i)
            null
        } catch (t: Throwable) {
            AppLog.e("rgss", "launch failed", t)
            "Could not start the RGSS engine: ${t.message ?: t.javaClass.simpleName}"
        }
    }

    private fun pruneLogs(gameId: String) {
        val logs = Paths.sessionDir(gameId).listFiles { f -> f.name.endsWith(".log") }?.sortedByDescending { it.name } ?: return
        logs.drop(12).forEach { it.delete() }
    }
}
