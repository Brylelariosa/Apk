package dev.splice.player

import android.app.Application
import android.os.Build
import dev.splice.player.core.AppLog
import dev.splice.player.core.Fmt
import dev.splice.player.core.Paths
import dev.splice.player.core.Prefs
import dev.splice.player.data.Library
import java.io.File

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val rgssProcess = currentProcessName().endsWith(":rgss")
        Paths.init(this)
        AppLog.init(Paths.logs, if (rgssProcess) "rgss" else "main")
        Prefs.init(this)
        installCrashLogger()
        Library.init(this)
        AppLog.i("app", "start ${BuildConfig.VERSION_NAME} process=${if (rgssProcess) "rgss" else "main"} " +
            "android=${Build.VERSION.RELEASE}(${Build.VERSION.SDK_INT}) device=${Build.MANUFACTURER} ${Build.MODEL} abi=${Build.SUPPORTED_ABIS.joinToString()}")
    }

    private fun currentProcessName(): String {
        return try {
            File("/proc/self/cmdline").readText().trim { it == '\u0000' || it.isWhitespace() }
        } catch (t: Throwable) {
            packageName
        }
    }

    private fun installCrashLogger() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, e ->
            try {
                AppLog.e("crash", "Uncaught exception in ${thread.name}", e)
                val f = File(Paths.logs, "crash-${Fmt.stamp()}.txt")
                f.writeText(
                    "Splice ${BuildConfig.VERSION_NAME}\n" +
                        "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                        "Thread: ${thread.name}\n\n" + android.util.Log.getStackTraceString(e)
                )
            } catch (ignored: Throwable) {
            }
            previous?.uncaughtException(thread, e)
        }
    }
}
