# Splice

An Android player for **RPG Maker XP, VX, VX Ace, MV and MZ** games, built for Pokémon fangames such as
Pokémon Infinite Fusion. One universal APK, no root, no background services.

## How games run

| Format | Engine | Notes |
|---|---|---|
| XP / VX / VX Ace (RGSS) | **mkxp-z** (Ruby 3.1 + SDL2 + OpenAL), the free RGSS implementation | Runs in its own process. Built from the open-source Android port at build time (see below). arm64-v8a only. |
| MV / MZ | The game's own HTML5 engine in the **system WebView** | Splice serves the game folder directly (no copy), emulates NW.js (`fs`, `path`, `nw.gui`, `process`), so saves are real files. |

Nothing is faked: every option in the settings maps to a real mkxp-z option or a real change in the
WebView runtime (see `MkxpConfig.kt` and `app/src/main/assets/web/nwshim.js`).

## Features

* Library with automatic format detection (RGSS version from `Game.ini`/data files, MV vs MZ from the JS core), Pokémon
  Essentials detection, cover art from the game (`Graphics/Titles`, `Game.ico`, `icon/icon.png`) or a generated cover.
* Import a ZIP, a game folder (played in place with "All files access", or copied), or a folder containing several games.
* Per-game profiles: orientation, scaling (fit / stretch / pixel-perfect), smoothing, game speed 0.5x to 3x, frame skip,
  frame pacing, texture limit, render cap, FPS display, MIDI soundfont, SE channels, RGSS version override, tile/blit/font
  fixes, extra RTP folders, raw `mkxp.json` overrides, Canvas renderer, custom JS.
* Touch controls with a layout editor (drag, resize, add keys), per-orientation layouts, haptics, auto-hide when a
  controller is used. Controllers work natively (SDL for RGSS, Gamepad API for MV/MZ).
* Save vault: each game's saves live in their own folder; rolling auto-backups, manual backups, restore, ZIP export/import,
  named slots (separate playthroughs).
* Troubleshoot page with real checks (files, storage access, engine, WebView version, last crash) and one-tap presets.
* Logs: every session's engine output is captured. Native crashes get a backtrace. No logcat needed.

## Building

Upload the ZIP to your repository's `uploads/` folder as usual (workflow: `Build APK`). Requirements are exactly what that
workflow provides: JDK 17, Gradle 8.6, NDK 25.2, CMake 3.22.1.

### The RGSS engine step

`./gradlew` runs `tools/engine/prepare_engine.sh` first. It builds the mkxp-z Android port
([BookerRues9/mkxp-z-android-reworked](https://github.com/BookerRues9/mkxp-z-android-reworked), pinned commit) with the same
recipe that project's CI uses (NDK r23, Ruby 3.1, `get_deps.sh`, `make`, `assembleRelease`), then harvests the native
libraries, Java and resources into the generated Gradle module `rgss-engine/` and generates `SpliceRgssActivity`.

* The step **never fails the build**. If anything goes wrong you still get an APK with MV/MZ support, and
  *Settings > Engines* shows the reason. The CI log has lines starting with `[splice-engine]`.
* The result is cached in `app/.cxx/splice-engine` (already cached by your workflow), so only the first run is slow.
* If the engine builds but its sources fail to compile inside the app, `./gradlew` retries the build once without it, so a
  failed engine never costs you the APK. The first attempt's error stays in the build log.
* Ruby 3.1 is taken from the runner's tool cache when present, otherwise downloaded; if neither works the system Ruby
  is used. Ubuntu's Ruby patches RubyGems so the cross-compiled Ruby's `make install` tries to write into
  `/var/lib/gems` (`Errno::EACCES`); the script neutralises that hook for the install (and, as a last resort, creates
  the folder it asks for and retries).
* Skip it with `SPLICE_SKIP_ENGINE=1` or by adding an empty file named `engine.disabled`.
* Override the engine with `SPLICE_ENGINE_REPO` / `SPLICE_ENGINE_REF`.

mkxp-z's Android port reads `mkxp.json`; Splice writes the generated file to every location that port is known to use
and gives every game its own save folder through a small Ruby preload script (`MkxpConfig.writePreload`).

## Size

* R8 shrinking and resource shrinking in release **and** debug (the workflow builds debug when no keystore secret exists).
* No AndroidX, no Compose, no image libraries; UI is plain framework views with vector icons.
* Compressed native libraries, no debug symbols, `fgcore` (crash backtraces + stdout capture) is a few KB per ABI.

## Layout

```
app/src/main/java/dev/splice/player/
  core/    paths, logging, JNI wrapper, prefs
  model/   Game, Profile (per-game settings), Format, touch-control layout
  data/    library, detection, import, covers, save vault, diagnostics, sessions
  engine/  RGSS launcher/session/config, WebView runtime (GameServer, NwBridge), controls editor
  ui/      design tokens + widgets, screens
app/src/main/cpp/fgcore.c         crash handler + stdio capture
tools/engine/                     engine bootstrap (shell + python)
rgss-engine/                      generated library module (git-ignored contents)
```

## License

GPL-2.0-or-later, matching mkxp-z. RPG Maker, RGSS and Pokémon are trademarks of their owners; Splice ships no game content.
