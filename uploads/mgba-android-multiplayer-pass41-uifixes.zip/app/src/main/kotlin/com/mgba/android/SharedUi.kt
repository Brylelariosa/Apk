package com.mgba.android

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

// Split out of MainActivity (Thirty-second pass) when the ROM browser
// became its own Activity (see RomBrowserActivity.kt) and needed the same
// small set of UI helpers MainActivity already had as private methods.
// Extension functions on Context/Activity rather than a shared base class —
// avoids touching MainActivity's class hierarchy at all for what's a small,
// stateless, purely-cosmetic set of helpers; every existing unqualified
// call site (dp(20), uiToast("..."), etc.) keeps compiling unchanged since
// these live in the same package.

/** SharedPreferences file name both Activities read/write. */
internal const val PREFS = "mgba_prefs"

internal val colorAccentLight = Color.parseColor("#D8D8DE")

internal fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Transparent, outlined "chip" background for corner icon buttons. */
internal fun Context.iconChipBackground(): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.RECTANGLE
    cornerRadius = dp(10).toFloat()
    setColor(Color.parseColor("#33000000"))
    setStroke(dp(1).coerceAtLeast(2), colorAccentLight)
}

/** Filled rounded-rect background every AlertDialog in the app uses via
 *  dialog.window?.setBackgroundDrawable(...). Moved here from MainActivity
 *  (this pass), alongside sliderRow()/showTypeValueDialog() below, which
 *  need it too — same "small, stateless, purely-cosmetic" rationale as
 *  every other helper in this file. Every existing MainActivity call site
 *  (unqualified roundedDialogBackground()) keeps compiling unchanged,
 *  exactly the same "same-package extension function" reasoning as the
 *  rest of this file's own top comment. */
internal fun Context.roundedDialogBackground(): GradientDrawable = GradientDrawable().apply {
    cornerRadius = dp(14).toFloat()
    setColor(Color.parseColor("#FF2E2E33"))
}

internal fun Activity.uiToast(msg: String) =
    Handler(Looper.getMainLooper()).post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

/**
 * A drag-or-type-exact-number row: a SeekBar plus a value readout that
 * doubles as a tap-to-type button (opens [showTypeValueDialog]). Built
 * once per row (Control Size, Control Opacity in MainActivity's per-item
 * editor bar) and refreshed via [SliderRow.setValue]/[SliderRow.setEnabled]
 * whenever what it's editing changes — a different control gets selected,
 * Reset is tapped, lock is toggled — without re-invoking [onChange], the
 * same "built once, refreshed on selection" shape the rest of that editor
 * bar already uses.
 *
 * FIX (this pass): replaces a pair of "-"/"+" chips whose real touch
 * target — even after a previous pass's 48dp-minimum fix — was still just
 * a few glyph-sized pixels. Direct report: "the plus and minus maybe a
 * slider with number or percent and you can type the number". A SeekBar's
 * entire width is draggable, not just one small fixed target, and the
 * value readout next to it both shows the live number and, tapped, opens
 * an exact-entry dialog.
 *
 * [min]/[max] are inclusive, in whatever unit [format] displays (a percent
 * in every current caller). SeekBar's own `progress` is always kept
 * 0-based internally regardless of [min] — `SeekBar.setMin()` needs API 26
 * and this app's minSdk is 24 — so every value this class exposes
 * ([initial], [onChange], [SliderRow.setValue], the typed dialog) is
 * already in real [min]..[max] units; only the SeekBar's own internal
 * progress carries the min-offset, invisibly to every caller.
 */
internal class SliderRow(
    val root: View,
    private val seek: SeekBar,
    private val valueText: TextView,
    private val min: Int,
    private val format: (Int) -> String
) {
    /** Updates the displayed value/position without invoking this row's
     *  own [onChange] — for reflecting a value that changed some other way
     *  (a newly-selected control's own current size/opacity, a Reset), not
     *  a fresh user edit. */
    fun setValue(v: Int) {
        seek.progress = (v - min).coerceIn(0, seek.max)
        valueText.text = format(v)
    }

    /** Disables (and visibly dims) both the slider and the tap-to-type
     *  readout — for a locked control, matching the "Unlock this control
     *  first" guard the setter functions in MainActivity already enforce.
     *  `SeekBar.isEnabled = false` already blocks drag input at the
     *  platform level (`AbsSeekBar.onTouchEvent`'s own first check); the
     *  readout's alpha is set explicitly since a plain TextView with a
     *  flat `setTextColor()`/GradientDrawable background — not a
     *  state-list-aware style — doesn't otherwise dim itself on disable. */
    fun setEnabled(enabled: Boolean) {
        seek.isEnabled = enabled
        valueText.isEnabled = enabled
        valueText.alpha = if (enabled) 1f else 0.5f
    }
}

internal fun Activity.sliderRow(
    min: Int,
    max: Int,
    initial: Int,
    dialogTitle: () -> String,
    format: (Int) -> String = { "$it%" },
    onChange: (Int) -> Unit
): SliderRow {
    val ctx = this
    // Deliberately not set inside a SeekBar.apply{} block: SeekBar has its
    // own `max` property, which would shadow this function's own `max`
    // parameter for any *unqualified* reference on the right-hand side of
    // an assignment inside such a block (Kotlin resolves an implicit-
    // receiver member before an enclosing function's parameter of the same
    // name) — exactly the kind of thing that would silently compile and
    // just be wrong. Two statements, no shared receiver scope, no
    // ambiguity either way.
    val seek = SeekBar(ctx)
    seek.max = (max - min).coerceAtLeast(1)
    val valueText = TextView(ctx).apply {
        textSize = 13f
        setTextColor(colorAccentLight)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(4), dp(10), dp(4))
        minWidth = dp(48); minimumWidth = dp(48); minHeight = dp(48); minimumHeight = dp(48)
        isClickable = true; isFocusable = true
        background = iconChipBackground()
    }
    val row = SliderRow(
        root = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(seek, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(valueText)
        },
        seek = seek, valueText = valueText, min = min, format = format
    )
    seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
            val v = progress + min
            valueText.text = format(v)
            if (fromUser) onChange(v)
        }
        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    })
    valueText.setOnClickListener {
        showTypeValueDialog(dialogTitle(), min, max, seek.progress + min) { typed ->
            row.setValue(typed)
            onChange(typed)
        }
    }
    row.setValue(initial)
    return row
}

/** A small "type an exact value" prompt, [min]..[max] inclusive — same
 *  numeric-EditText-in-an-AlertDialog shape as the app's other typed-value
 *  fields (e.g. Misc settings' fast-forward speed field). Invalid or
 *  out-of-range input toasts and leaves the value unchanged rather than
 *  silently clamping, so a typo doesn't quietly snap to some other number
 *  without the person noticing. */
internal fun Activity.showTypeValueDialog(
    title: String,
    min: Int,
    max: Int,
    current: Int,
    onConfirm: (Int) -> Unit
) {
    val ctx = this
    val input = EditText(ctx).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        setText(current.toString())
        setTextColor(Color.WHITE)
        setHintTextColor(Color.GRAY)
        hint = "$min – $max"
        setPadding(dp(24), dp(16), dp(24), dp(4))
        setSelection(text.length)
    }
    val dialog = AlertDialog.Builder(ctx)
        .setTitle(title)
        .setView(input)
        .setPositiveButton("OK") { _, _ ->
            val v = input.text.toString().toIntOrNull()
            when {
                v == null -> uiToast("Enter a number")
                v < min || v > max -> uiToast("Must be $min – $max")
                else -> onConfirm(v)
            }
        }
        .setNegativeButton("Cancel", null)
        .create()
    dialog.window?.setBackgroundDrawable(roundedDialogBackground())
    dialog.show()
}
