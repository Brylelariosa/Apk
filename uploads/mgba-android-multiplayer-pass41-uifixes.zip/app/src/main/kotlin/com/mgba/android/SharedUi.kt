package com.mgba.android

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

// Split out of MainActivity (Thirty-second pass) when the ROM browser
// became its own Activity (see RomBrowserActivity.kt) and needed the same
// small set of UI helpers MainActivity already had as private methods.
// Extension functions on Context/Activity rather than a shared base class —
// avoids touching MainActivity's class hierarchy at all for what's a small,
// stateless, purely-cosmetic set of helpers; every existing unqualified
// call site (dp(20), uiToast("..."), etc.) keeps compiling unchanged since
// these live in the same package.

/** SharedPreferences file name both Activities read/write. */
internal const val PREFS = "mgba_prefs"

internal val colorAccentLight = Color.parseColor("#D8D8DE")

internal fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Transparent, outlined "chip" background for corner icon buttons. */
internal fun Context.iconChipBackground(): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.RECTANGLE
    cornerRadius = dp(10).toFloat()
    setColor(Color.parseColor("#33000000"))
    setStroke(dp(1).coerceAtLeast(2), colorAccentLight)
}

/** Filled rounded-rect background every AlertDialog in the app uses via
 *  dialog.window?.setBackgroundDrawable(...). Moved here from MainActivity,
 *  alongside sliderRow() below, which needs it too — same "small,
 *  stateless, purely-cosmetic" rationale as every other helper in this
 *  file. Every existing MainActivity call site (unqualified
 *  roundedDialogBackground()) keeps compiling unchanged, exactly the same
 *  "same-package extension function" reasoning as the rest of this file's
 *  own top comment. */
internal fun Context.roundedDialogBackground(): GradientDrawable = GradientDrawable().apply {
    cornerRadius = dp(14).toFloat()
    setColor(Color.parseColor("#FF2E2E33"))
}

internal fun Activity.uiToast(msg: String) =
    Handler(Looper.getMainLooper()).post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

/**
 * A drag-or-type-exact-number row: a SeekBar plus a value readout that
 * doubles as a tap-to-type field. Built once per row (Control Size,
 * Control Opacity in MainActivity's per-item editor bar) and refreshed via
 * [SliderRow.setValue]/[SliderRow.setEnabled] whenever what it's editing
 * changes — a different control gets selected, Reset is tapped, lock is
 * toggled — without re-invoking [onChange], the same "built once, refreshed
 * on selection" shape the rest of that editor bar already uses.
 *
 * FIX (an earlier pass): replaces a pair of "-"/"+" chips whose real touch
 * target — even after a previous pass's 48dp-minimum fix — was still just
 * a few glyph-sized pixels. Direct report: "the plus and minus maybe a
 * slider with number or percent and you can type the number". A SeekBar's
 * entire width is draggable, not just one small fixed target, and the
 * value readout next to it both shows the live number and, tapped, opens
 * an exact-entry field.
 *
 * FIX (this pass — direct reports: "if you click the number where you
 * type it should type on the box doesn't pop up another typing area", that
 * popup's own number box being "big", and "the slider and box is not
 * aligned"): the separate typed-entry AlertDialog this used to open
 * (showTypeValueDialog) is gone entirely. Tapping the readout now turns
 * that exact same box into an editable field in place — see
 * [beginInlineEdit]/[commitInlineEdit] below and the FrameLayout in
 * [sliderRow] that overlays valueText/valueEdit in one shared slot — so
 * there is no second popup anywhere on screen, and nothing to visually
 * mis-size relative to it. The readout's own minimum height also comes
 * down from 48dp to 36dp as part of the same report: still a real touch
 * target (a SeekBar's own touch target is generously padded well past its
 * visible track/thumb, so 36dp next to it reads as comfortably tappable,
 * not cramped) but no longer tall enough to visually spill into the row
 * above/below it inside a tightly packed editor panel — see
 * editButtonBar's own row-spacing fix in MainActivity for the rest of that
 * "not aligned" report.
 *
 * [min]/[max] are inclusive, in whatever unit [format] displays (a percent
 * in every current caller). SeekBar's own `progress` is always kept
 * 0-based internally regardless of [min] — `SeekBar.setMin()` needs API 26
 * and this app's minSdk is 24 — so every value this class exposes
 * ([initial], [onChange], [SliderRow.setValue], the typed field) is
 * already in real [min]..[max] units; only the SeekBar's own internal
 * progress carries the min-offset, invisibly to every caller.
 */
internal class SliderRow(
    val root: View,
    private val seek: SeekBar,
    private val valueText: TextView,
    private val valueEdit: EditText,
    private val min: Int,
    private val max: Int,
    private val format: (Int) -> String,
    private val onChange: (Int) -> Unit
) {
    /** Updates the displayed value/position without invoking this row's
     *  own [onChange] — for reflecting a value that changed some other way
     *  (a newly-selected control's own current size/opacity, a Reset), not
     *  a fresh user edit. */
    fun setValue(v: Int) {
        seek.progress = (v - min).coerceIn(0, seek.max)
        valueText.text = format(v)
    }

    /** Disables (and visibly dims) the slider and the tap-to-type readout —
     *  for a locked control, matching the "Unlock this control first" guard
     *  the setter functions in MainActivity already enforce.
     *  `SeekBar.isEnabled = false` already blocks drag input at the
     *  platform level (`AbsSeekBar.onTouchEvent`'s own first check);
     *  `valueText.isEnabled = false` equally blocks its tap-to-edit
     *  listener from firing, the same mechanism. The readout's alpha is
     *  set explicitly since a plain TextView with a flat
     *  `setTextColor()`/GradientDrawable background — not a
     *  state-list-aware style — doesn't otherwise dim itself on disable. */
    fun setEnabled(enabled: Boolean) {
        seek.isEnabled = enabled
        valueText.isEnabled = enabled
        valueText.alpha = if (enabled) 1f else 0.5f
    }

    /** Swaps the readout for the inline EditText occupying the same slot,
     *  pre-filled with the current raw number (no "%"/unit suffix — just
     *  what someone would want to retype), selection parked at the end,
     *  keyboard requested immediately. See [sliderRow] for where this is
     *  wired to valueText's own click. */
    internal fun beginInlineEdit() {
        if (!valueText.isEnabled) return
        valueEdit.setText((seek.progress + min).toString())
        valueEdit.setSelection(valueEdit.text.length)
        valueText.visibility = View.GONE
        valueEdit.visibility = View.VISIBLE
        valueEdit.requestFocus()
        (valueEdit.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.showSoftInput(valueEdit, InputMethodManager.SHOW_IMPLICIT)
    }

    /** Reverses [beginInlineEdit]: a valid [min]..[max] number applies
     *  through the exact same [setValue] + [onChange] path a drag would
     *  use; anything else (empty, non-numeric, out of range) is silently
     *  left as it was — no toast, unlike the old dialog's rejection
     *  message, since a mis-tap-away from an inline field someone can just
     *  tap straight back into shouldn't interrupt them the way dismissing
     *  a whole popup with bad input once did. Guarded to a no-op when
     *  already showing valueText so it's safe to call from both the IME
     *  "Done" action and a plain focus-loss (e.g. tapping straight into a
     *  different row) without double-handling either path. */
    internal fun commitInlineEdit() {
        if (valueEdit.visibility != View.VISIBLE) return
        valueEdit.text.toString().toIntOrNull()?.let { typed ->
            if (typed in min..max) { setValue(typed); onChange(typed) }
        }
        valueEdit.visibility = View.GONE
        valueText.visibility = View.VISIBLE
        (valueEdit.context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(valueEdit.windowToken, 0)
    }
}

internal fun Activity.sliderRow(
    min: Int,
    max: Int,
    initial: Int,
    label: () -> String,
    format: (Int) -> String = { "$it%" },
    onChange: (Int) -> Unit
): SliderRow {
    val ctx = this
    // Deliberately not set inside a SeekBar.apply{} block: SeekBar has its
    // own `max` property, which would shadow this function's own `max`
    // parameter for any *unqualified* reference on the right-hand side of
    // an assignment inside such a block (Kotlin resolves an implicit-
    // receiver member before an enclosing function's parameter of the same
    // name) — exactly the kind of thing that would silently compile and
    // just be wrong. Two statements, no shared receiver scope, no
    // ambiguity either way.
    val seek = SeekBar(ctx)
    seek.max = (max - min).coerceAtLeast(1)
    val valueText = TextView(ctx).apply {
        textSize = 13f
        setTextColor(colorAccentLight)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(4), dp(10), dp(4))
        minWidth = dp(48); minimumWidth = dp(48); minHeight = dp(36); minimumHeight = dp(36)
        isClickable = true; isFocusable = true
        background = iconChipBackground()
    }
    // Same visible size/position as valueText (down to the identical
    // background/padding/text size) so swapping one for the other reads as
    // "this box is now editable", not as a different element appearing.
    // IME_FLAG_NO_FULLSCREEN matters specifically here: this editor lives
    // over the game screen in landscape play, where a fullscreen IME (the
    // default a lot of keyboards fall back to for a short landscape input)
    // would otherwise cover the whole thing just to type 2-3 digits.
    val valueEdit = EditText(ctx).apply {
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(10), 0, dp(10), 0)
        minWidth = dp(48); minimumWidth = dp(48); minHeight = dp(36); minimumHeight = dp(36)
        background = iconChipBackground()
        inputType = InputType.TYPE_CLASS_NUMBER
        imeOptions = EditorInfo.IME_ACTION_DONE or EditorInfo.IME_FLAG_NO_FULLSCREEN
        setSingleLine(true)
        visibility = View.GONE
        contentDescription = label()
    }
    val valueSlot = FrameLayout(ctx).apply {
        addView(valueText, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
        addView(valueEdit, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT))
    }
    val row = SliderRow(
        root = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(seek, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(valueSlot)
        },
        seek = seek, valueText = valueText, valueEdit = valueEdit,
        min = min, max = max, format = format, onChange = onChange
    )
    seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
            val v = progress + min
            valueText.text = format(v)
            if (fromUser) onChange(v)
        }
        override fun onStartTrackingTouch(sb: SeekBar) {}
        override fun onStopTrackingTouch(sb: SeekBar) {}
    })
    valueText.setOnClickListener { row.beginInlineEdit() }
    valueEdit.setOnEditorActionListener { _, actionId, event ->
        val isEnterKeyDown = event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
        if (actionId == EditorInfo.IME_ACTION_DONE || isEnterKeyDown) {
            row.commitInlineEdit()
            true
        } else false
    }
    valueEdit.setOnFocusChangeListener { _, hasFocus -> if (!hasFocus) row.commitInlineEdit() }
    row.setValue(initial)
    return row
}
