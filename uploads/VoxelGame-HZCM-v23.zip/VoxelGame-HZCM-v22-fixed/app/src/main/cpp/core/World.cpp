// ============================================================================
// HZCM v4 — World.cpp
// ============================================================================
#include "World.h"
#include <android/log.h>
#include <algorithm>
#include <cmath>
#include <climits>
#include <cstring>

#define TAG  "HZCMWorld"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// ─────────────────────────────────────────────────────────────────────────────
World::World() : m_noise(0) {}

World::~World() {
    m_jobQueue.requestStop();
    for (auto& t : m_workers)
        if (t.joinable()) t.join();
}

// ── Worker main loop ──────────────────────────────────────────────────────────
void World::workerLoop() {
    WorldJob job;
    // popWait blocks up to 20 ms then retries; returns false only when
    // the queue is stopped AND empty — our exit condition.
    while (m_jobQueue.popWait(job, 20)) {
        executeJob(job);
    }
}

// ── Job dispatcher ─────────────────────────────────────────────────────────────
void World::executeJob(const WorldJob& job) {
    switch (job.kind) {
        case JobKind::CHUNK_BUILD:
            workerChunkBuild(job.chunk);
            break;
        case JobKind::CLUSTER_REBUILD:
            workerClusterRebuild(job.chunk, job.ci);
            break;
        case JobKind::NEIGHBOUR_FLUSH:
            workerNeighbourFlush(job.flushCX, job.flushCZ);
            break;
    }
}

// ── Enqueue helpers ────────────────────────────────────────────────────────────
void World::enqueueChunkBuild(Chunk* chunk) {
    WorldJob job{};
    job.kind  = JobKind::CHUNK_BUILD;
    job.world = this;
    job.chunk = chunk;
    job.ci    = -1;
    if (!m_jobQueue.push(job)) {
        // Queue full — defer to retry queue instead of dropping.
        // drainRetryQueue() will re-attempt this job at the start of the
        // next GL-thread update() call.
        m_overflowCount.fetch_add(1, std::memory_order_relaxed);
        std::lock_guard<std::mutex> lk(m_retryMtx);
        m_retryQueue.push_back(job);
        m_retryQueueSize.store((int)m_retryQueue.size(),
                               std::memory_order_relaxed);
        LOGI("CHUNK_BUILD deferred to retry queue (%d,%d) [overflow=%d]",
             chunk->cx, chunk->cz,
             m_overflowCount.load(std::memory_order_relaxed));
    }
}

void World::enqueueClusterRebuild(Chunk* chunk, int ci) {
    WorldJob job{};
    job.kind  = JobKind::CLUSTER_REBUILD;
    job.world = this;
    job.chunk = chunk;
    job.ci    = ci;
    if (!m_jobQueue.push(job)) {
        m_overflowCount.fetch_add(1, std::memory_order_relaxed);
        std::lock_guard<std::mutex> lk(m_retryMtx);
        m_retryQueue.push_back(job);
        m_retryQueueSize.store((int)m_retryQueue.size(),
                               std::memory_order_relaxed);
    }
}

void World::enqueueNeighbourFlush(int cx, int cz) {
    WorldJob job{};
    job.kind    = JobKind::NEIGHBOUR_FLUSH;
    job.world   = this;
    job.chunk   = nullptr;
    job.ci      = -1;
    job.flushCX = cx;
    job.flushCZ = cz;
    if (!m_jobQueue.push(job)) {
        m_overflowCount.fetch_add(1, std::memory_order_relaxed);
        std::lock_guard<std::mutex> lk(m_retryMtx);
        m_retryQueue.push_back(job);
        m_retryQueueSize.store((int)m_retryQueue.size(),
                               std::memory_order_relaxed);
    }
}

// ── Worker implementations ────────────────────────────────────────────────────

void World::workerChunkBuild(Chunk* chunk) {
    // Guard: if chunk was evicted before we even started, skip entirely
    if (chunk->evicted.load(std::memory_order_acquire)) return;
    chunk->inFlight.fetch_add(1, std::memory_order_acquire);

    int cx = chunk->cx, cz = chunk->cz;

    // BUG FIXED (v10 → v11): workerNeighbourFlush can now enqueue a
    // CHUNK_BUILD for a neighbour that is generated-but-not-yet-meshed.
    // Guard against running generate() a second time — terrain is already
    // correct; we only need the mesh step.
    if (!chunk->generated.load(std::memory_order_acquire)) {
        // Generate terrain voxels
        chunk->generate(m_noise);

        // Re-check eviction: might have been evicted during generate()
        if (chunk->evicted.load(std::memory_order_acquire)) {
            chunk->inFlight.fetch_sub(1, std::memory_order_release);
            return;
        }
    }

    // Grab neighbour pointers under shared lock
    const Chunk *nx, *px, *nz, *pz;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        nx = getChunk(cx-1, cz); px = getChunk(cx+1, cz);
        nz = getChunk(cx, cz-1); pz = getChunk(cx, cz+1);
    }

    // 3. Mesh all 4 clusters
    for (int ci = 0; ci < CLUSTER_STACK; ++ci)
        chunk->buildClusterMesh(ci, nx, px, nz, pz);

    // Push in REVERSE order so that within a single chunk, ci=0 (ground)
    // is processed before ci=3 (tree-tops) within the same distance bucket.
    // FIX v13: stamp chebDist so updateGPU can route into the correct
    // priority bucket.  Workers use the atomic camera snapshot — no lock.
    {
        int ccx = m_camCXAtomic.load(std::memory_order_relaxed);
        int ccz = m_camCZAtomic.load(std::memory_order_relaxed);
        int dist = std::max(std::abs(chunk->cx - ccx),
                            std::abs(chunk->cz - ccz));
        int bkt = uploadBucket(dist);
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        for (int ci = CLUSTER_STACK - 1; ci >= 0; --ci)
            m_uploadBuckets[bkt].push_back({ chunk, ci, chunk->clusterDirtyGen[ci], dist });
    }

    chunk->inFlight.fetch_sub(1, std::memory_order_release);

    // ── Race-condition guard ────────────────────────────────────────────────
    // If any neighbour that was null when we grabbed pointers above has since
    // generated, our border clusters used BLOCK_AIR for that side and are stale.
    // Enqueue CLUSTER_REBUILD for every affected cluster so the border faces
    // are corrected.  workerNeighbourFlush only triggers on READY/MESHED
    // neighbours, so this self-check is the only way to catch the race where
    // B completes and calls workerNeighbourFlush while A's clusters are DIRTY.
    {
        const Chunk *nx2, *px2, *nz2, *pz2;
        {
            std::shared_lock<std::shared_mutex> rlk2(m_chunksMtx);
            nx2 = getChunk(cx-1, cz); px2 = getChunk(cx+1, cz);
            nz2 = getChunk(cx, cz-1); pz2 = getChunk(cx, cz+1);
        }
        bool stale =
            (nx2 && nx2->generated.load(std::memory_order_acquire) && !nx) ||
            (px2 && px2->generated.load(std::memory_order_acquire) && !px) ||
            (nz2 && nz2->generated.load(std::memory_order_acquire) && !nz) ||
            (pz2 && pz2->generated.load(std::memory_order_acquire) && !pz);
        if (stale) {
            for (int ci2 = 0; ci2 < CLUSTER_STACK; ++ci2)
                enqueueClusterRebuild(chunk, ci2);
        }
    }

    // Remesh border clusters of existing neighbours
    workerNeighbourFlush(cx, cz);
}

void World::workerClusterRebuild(Chunk* chunk, int ci) {
    if (chunk->evicted.load(std::memory_order_acquire)) return;
    chunk->inFlight.fetch_add(1, std::memory_order_acquire);

    int cx = chunk->cx, cz = chunk->cz;
    const Chunk *nx, *px, *nz, *pz;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        nx = getChunk(cx-1, cz); px = getChunk(cx+1, cz);
        nz = getChunk(cx, cz-1); pz = getChunk(cx, cz+1);
    }
    chunk->buildClusterMesh(ci, nx, px, nz, pz);

    if (!chunk->evicted.load(std::memory_order_acquire)) {
        int ccx = m_camCXAtomic.load(std::memory_order_relaxed);
        int ccz = m_camCZAtomic.load(std::memory_order_relaxed);
        int dist = std::max(std::abs(chunk->cx - ccx),
                            std::abs(chunk->cz - ccz));
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        m_uploadBuckets[uploadBucket(dist)].push_back(
            { chunk, ci, chunk->clusterDirtyGen[ci], dist });
    }

    chunk->inFlight.fetch_sub(1, std::memory_order_release);
}

void World::workerNeighbourFlush(int cx, int cz) {
    // BUG FIXED (v10 → v11): old code only re-meshed neighbours in READY or
    // MESHED state.  A neighbour whose CHUNK_BUILD job had completed generate()
    // but not yet buildClusterMesh() — cluster state = DIRTY — was silently
    // skipped.  In that narrow window, neither this flush nor the neighbour's
    // own stale-check re-queued the rebuild, producing a permanent seam on the
    // shared border.
    //
    // Fix:  Collect two sets —
    //   • remesh: clusters already READY/MESHED that need a border correction.
    //   • initMesh: generated neighbours with ALL clusters still DIRTY/EMPTY,
    //     meaning their first full mesh hasn't happened yet.  Enqueue a
    //     CHUNK_BUILD for them so they pick up the now-generated neighbour
    //     (us) during their own mesh pass.  workerChunkBuild skips generate()
    //     if `generated` is already true, so this is safe against double-gen.
    static const int dirs[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
    std::vector<std::pair<Chunk*,int>> remesh;
    std::vector<Chunk*>                initMesh;
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        for (auto& d : dirs) {
            Chunk* nb = getChunk(cx + d[0], cz + d[1]);
            if (!nb || !nb->generated.load(std::memory_order_acquire)) continue;

            bool anyMeshed = false;
            for (int c2 = 0; c2 < CLUSTER_STACK; ++c2) {
                auto st = nb->clusterState[c2].load(std::memory_order_acquire);
                if (st == ClusterState::READY || st == ClusterState::MESHED) {
                    remesh.push_back({nb, c2});
                    anyMeshed = true;
                }
            }
            // All clusters are DIRTY/EMPTY but terrain is generated — the
            // neighbour's initial mesh is in-flight or hasn't been enqueued yet.
            // Trigger a build so it meshes with correct border data.
            if (!anyMeshed && !nb->evicted.load(std::memory_order_acquire)) {
                initMesh.push_back(nb);
            }
        }
    }
    for (auto& [nb, c2] : remesh)
        enqueueClusterRebuild(nb, c2);
    for (Chunk* nb : initMesh)
        enqueueChunkBuild(nb);
}

// ── Init ───────────────────────────────────────────────────────────────────────
void World::init(int seed) {
    m_noise = Noise(seed);

    {
        std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
        m_chunks.clear();
    }
    m_submitted.clear();
    m_pendingCandidates.clear();
    m_candidateIdx = 0;
    m_lastCamCX = INT_MIN;
    m_lastCamCZ = INT_MIN;
    m_lastRdGen = 0;

    int hw       = (int)std::thread::hardware_concurrency();
    // Allow up to 4 worker threads on devices with enough cores.
    // The extra thread significantly improves drain rate at RD≥12 where
    // the queue can hold hundreds of concurrent CLUSTER_REBUILD jobs.
    int nThreads = std::max(2, std::min(4, hw - 1));
    LOGI("Starting %d worker threads (hw=%d)", nThreads, hw);
    for (int i = 0; i < nThreads; ++i)
        m_workers.emplace_back([this] { workerLoop(); });

    // Prime initial area
    update(0.f, 0.f, 64.f, 0.f, 0.f, 0.f, 1.f, 0.016f);
    LOGI("World init done (render distance=%d)", m_renderDist.getDistance());
}

// ── Effective radius ──────────────────────────────────────────────────────────
// FIX v13: Thermal scaling REMOVED from effective radius.
//
// Old behaviour: m_effectiveRadius = max(2, (int)(requested × radiusScale()))
//   • WARM  → radius shrinks to 75% of requested
//   • HOT   → radius shrinks to 50%
//   • CRITICAL → radius shrinks to 30%
//   Combined with slow rebuild/upload budgets, this caused chunks at
//   render distances ≥ 8 to never load: the thermally-reduced radius
//   shrank the candidate list while the submission loop still consumed
//   the full budget on empty iterations.
//
// New behaviour: m_effectiveRadius = requested (always).
//   Thermal throttling is applied ONLY to:
//     • maxNew      (submission budget per frame, via thermalScale factor)
//     • upload budget (maxUploadBudget() × rdScale in updateGPU)
//     • rebuild budget (maxRebuildBudget() guards workerClusterRebuild paths)
//   This preserves full world coverage at any render distance while still
//   slowing down loading speed on hot devices to avoid overheating.
void World::refreshEffectiveRadius() {
    m_effectiveRadius = m_renderDist.getDistance();
}

// ── Retry queue drain ──────────────────────────────────────────────────────────
// Called once per frame at the top of update() before new chunk submissions.
// Attempts to push previously-dropped jobs back into m_jobQueue now that
// workers may have drained some capacity.
//
// Design notes:
//   • Jobs are eviction-checked before push: if a chunk was evicted while
//     sitting in the retry queue, it is discarded (no use re-meshing it).
//   • A single-pass strategy is used — we don't loop until empty.  If the
//     queue is still too full for some retries, they stay in m_retryQueue and
//     are re-attempted next frame.  This prevents infinite spinning on a
//     sustained-full queue.
//   • m_retryQueue is a std::vector accessed under m_retryMtx.  We swap it
//     out under the lock (O(1)) then release the lock before doing any pushes
//     so workers don't contend on m_retryMtx during drain.
void World::drainRetryQueue() {
    std::vector<WorldJob> snapshot;
    {
        std::lock_guard<std::mutex> lk(m_retryMtx);
        if (m_retryQueue.empty()) return;
        snapshot.swap(m_retryQueue);
        m_retryQueueSize.store(0, std::memory_order_relaxed);
    }

    int pushed = 0, dropped = 0, requeued = 0;
    for (auto& job : snapshot) {
        // Skip evicted chunks — no point retrying a dead chunk
        if (job.chunk && job.chunk->evicted.load(std::memory_order_acquire)) {
            ++dropped;
            continue;
        }
        if (m_jobQueue.push(job)) {
            ++pushed;
        } else {
            // Queue still full — put back for next frame
            std::lock_guard<std::mutex> lk(m_retryMtx);
            m_retryQueue.push_back(job);
            ++requeued;
        }
    }

    {
        std::lock_guard<std::mutex> lk(m_retryMtx);
        m_retryQueueSize.store((int)m_retryQueue.size(),
                               std::memory_order_relaxed);
    }

    if (pushed > 0 || requeued > 0)
        LOGI("RetryQueue drain: pushed=%d dropped=%d requeued=%d", pushed, dropped, requeued);
}

// ── Per-frame update ───────────────────────────────────────────────────────────
void World::update(float camX, float camZ, float camY,
                    float velX, float velZ,
                    float fwdX, float fwdZ, float dt)
{
    ++m_frameCount;

    m_thermal.update(dt);
    m_scheduler.update(camX, camZ, camY, velX, velZ, fwdX, fwdZ);

    // ── Drain deferred retry queue first ──────────────────────────────────────
    // Any CHUNK_BUILD / CLUSTER_REBUILD / NEIGHBOUR_FLUSH jobs that failed to
    // push last frame (queue was full) are retried here before new submissions,
    // preserving priority ordering and preventing permanent border seams.
    drainRetryQueue();

    bool rdChanged = m_renderDist.pollChanged(m_lastRdGen);
    refreshEffectiveRadius();

    // FIX v13: loadR / unloadR use the full requested radii — no thermal
    // reduction.  `scale` is retained for the per-frame debug log only.
    // Thermal throttling operates exclusively on the submission/upload/rebuild
    // budgets computed later in this function and in updateGPU().
    float scale = m_thermal.radiusScale();   // informational — NOT applied to radii
    auto  radii = m_renderDist.getRadii();
    int loadR   = radii.load;    // = requestedRD + 1  (neighbours for seam meshing)
    int unloadR = radii.unload;  // = requestedRD + 4  (hysteresis avoids thrashing)

    int camCX = (int)floorf(camX / (float)CHUNK_W);
    int camCZ = (int)floorf(camZ / (float)CHUNK_D);
    bool camMoved = (camCX != m_lastCamCX || camCZ != m_lastCamCZ);

    // Keep atomic snapshot current — worker threads read these to stamp
    // chebDist on UploadTasks without acquiring any lock.
    m_camCXAtomic.store(camCX, std::memory_order_relaxed);
    m_camCZAtomic.store(camCZ, std::memory_order_relaxed);

    // ── Unload ────────────────────────────────────────────────────────────────
    if (camMoved || rdChanged) {
        std::vector<std::pair<ChunkKey, std::unique_ptr<Chunk>>> evicted;
        {
            std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
            for (auto it = m_chunks.begin(); it != m_chunks.end(); ) {
                int dx = std::abs(it->first.cx - camCX);
                int dz = std::abs(it->first.cz - camCZ);
                if (dx > unloadR || dz > unloadR) {
                    evictChunk(it->second.get());           // mark evicted + free GPU
                    m_submitted.erase({it->first.cx, it->first.cz});
                    evicted.push_back({it->first, std::move(it->second)});
                    it = m_chunks.erase(it);
                } else {
                    ++it;
                }
            }

            // BUG FIXED (v10 → v11): On render-distance change, also scrub any
            // m_submitted entries whose chunk is no longer in m_chunks.  This
            // can happen when the queue-full rollback path removes a chunk from
            // m_chunks between a rdChanged and its corresponding eviction pass
            // (the rollback does not erase from m_submitted because the entry
            // was never inserted, but a pathological multi-frame sequence could
            // leave the set pointing at a dead key).  The check is cheap and
            // makes the submitted set provably consistent after every RD event.
            if (rdChanged) {
                for (auto sit = m_submitted.begin(); sit != m_submitted.end(); ) {
                    if (m_chunks.find({sit->cx, sit->cz}) == m_chunks.end())
                        sit = m_submitted.erase(sit);
                    else
                        ++sit;
                }
                // v18: also remove m_submitted entries for chunks that exist in
                // m_chunks but have never completed generate().  These are orphaned
                // jobs — they were submitted before the RD change but their build
                // may have been lost or deferred.  Removing them from m_submitted
                // lets the next candidate rebuild re-enqueue them without waiting
                // for the stranded-chunk recovery scan later in this frame.
                // Safe: workerChunkBuild guards against double-generate().
                for (auto sit = m_submitted.begin(); sit != m_submitted.end(); ) {
                    auto it2 = m_chunks.find({sit->cx, sit->cz});
                    if (it2 != m_chunks.end()) {
                        const Chunk* ch2 = it2->second.get();
                        if (!ch2->generated.load(std::memory_order_acquire)
                         && !ch2->evicted.load(std::memory_order_acquire)) {
                            sit = m_submitted.erase(sit);
                            continue;
                        }
                    }
                    ++sit;
                }
            }
        }
        // Move evicted chunks to graveyard (deferred deletion — workers may still be reading)
        {
            std::lock_guard<std::mutex> glk(m_graveyardMtx);
            for (auto& [key, ptr] : evicted) {
                m_graveyard.push_back({ std::move(ptr), 4 }); // wait 4 frames
                enqueueNeighbourFlush(key.cx, key.cz);
            }
        }
    }

    // ── Rebuild sorted candidate list when necessary ───────────────────────────
    // Rebuild triggers:
    //   1. camMoved  — player entered a new chunk; frontier has shifted.
    //   2. rdChanged — render distance changed; candidate grid resized.
    //   3. missingNearbyChunk (stall-recovery) — candidates exhausted AND at
    //      least one position within loadR is absent from m_chunks.
    //
    // FIX v14: replaced the broken submittedDeficit check
    //   ((int)m_submitted.size() < expectedFull)
    // with a direct O(N) scan of m_chunks.
    //
    // Why the old check was wrong:
    //   m_submitted is a global accumulated set.  After the player's first
    //   camera-chunk move the set grows beyond expectedFull because the
    //   eviction hysteresis keeps (2*(RD+4)+1)^2 chunks resident while
    //   expectedFull = (2*(RD+1)+1)^2.  submittedDeficit therefore became
    //   permanently false after the very first move, disabling stall-recovery
    //   for the rest of the session.  The "one RD change helps" symptom
    //   followed directly: raising RD temporarily lifted expectedFull above
    //   m_submitted.size() for one load cycle, then the set outpaced it again.
    //
    // Why the new check is correct:
    //   m_chunks is the ground truth for what is actually loaded.  A position
    //   absent from m_chunks is genuinely missing regardless of what
    //   m_submitted says.  The scan is bounded by (2*loadR+1)^2 entries
    //   (361 at RD=8, 1225 at RD=16), runs only when candidates are exhausted
    //   AND the camera has not moved, and early-exits on the first missing
    //   entry — so a fully-loaded stationary player pays near-zero cost.
    bool candidatesExhausted = (m_candidateIdx >= (int)m_pendingCandidates.size());

    // ── Periodic full-radius missing-chunk scan ───────────────────────────────
    //
    // ROOT BUG FIX (v12 → v14):
    //
    // OLD code ran this scan ONLY when:
    //   candidatesExhausted && !camMoved && !rdChanged
    //
    // While the player is exploring, camMoved=true every frame, so the scan
    // NEVER ran.  Chunks starved by the (now-removed) forward-bias sort were
    // perpetually deferred and holes were never detected.
    //
    // NEW behaviour: scan runs every MISSING_SCAN_INTERVAL frames regardless
    // of movement, PLUS the original "exhausted + stationary" fast path.
    //   • Full-radius square (not Euclidean circle) to match buildCandidates.
    //   • Counts total positions and missing positions for debug telemetry.
    //   • Early-exit removed: scan the whole radius to get accurate missing count.
    //   • If any chunk is missing, forces a candidate rebuild to re-enqueue it.
    //
    // Performance: (2*loadR+1)^2 unordered_map lookups.
    //   RD=8  → 361 lookups,  RD=16 → 1225 lookups.
    //   Each lookup is O(1).  At 120-frame interval (~2 s), cost is negligible.
    // v18: halved from 120 → 60 frames (~1 s at 60 fps) so recovery
    // from any stranded or missing chunk is detected and re-queued sooner.
    // Also fire immediately when render distance changes so newly-in-range
    // chunks that got stranded aren't left waiting until the next interval.
    static constexpr int MISSING_SCAN_INTERVAL = 60;   // ~1 s at 60 fps
    bool doPeriodicScan = (m_frameCount % MISSING_SCAN_INTERVAL == 1)
                       || rdChanged;  // v18: instant scan on every RD event

    bool missingNearbyChunk = false;
    int  scanTotalInRadius  = 0;
    int  scanMissingCount   = 0;

    if ((candidatesExhausted && !camMoved && !rdChanged) || doPeriodicScan) {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        for (int dz = -loadR; dz <= loadR; ++dz) {
            for (int dx = -loadR; dx <= loadR; ++dx) {
                ++scanTotalInRadius;
                if (m_chunks.find({camCX + dx, camCZ + dz}) == m_chunks.end()) {
                    ++scanMissingCount;
                    missingNearbyChunk = true;
                    // Do NOT early-exit: continue scanning for accurate count.
                }
            }
        }
    }

    // Update diagnostic counters (read by getDebugStats / HUD).
    m_lastTotalInRadius = scanTotalInRadius;
    m_lastMissingCount  = scanMissingCount;

    // ── Stranded-chunk recovery ───────────────────────────────────────────────
    // Runs every MISSING_SCAN_INTERVAL frames alongside the missing-chunk scan.
    // Detects chunks that ARE in m_chunks (so the missing-chunk scan won't catch
    // them) but whose build job was lost: generated=false AND inFlight=0 means
    // no worker is processing the chunk right now.
    //
    // Safe to re-enqueue: workerChunkBuild checks generated.load() before
    // running generate(), so a duplicate CHUNK_BUILD is a no-op if the chunk
    // already completed between the scan and the worker execution.
    if (doPeriodicScan) {
        std::vector<Chunk*> stranded;
        {
            std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
            for (auto& kv : m_chunks) {
                Chunk* ch = kv.second.get();
                if (!ch->evicted  .load(std::memory_order_acquire)
                    && !ch->generated.load(std::memory_order_acquire)
                    &&   ch->inFlight .load(std::memory_order_acquire) == 0)
                {
                    stranded.push_back(ch);
                }
            }
        }
        // Enqueue outside the shared lock so workers can run concurrently.
        for (Chunk* ch : stranded)
            enqueueChunkBuild(ch);

        m_lastStrandedCount = (int)stranded.size();
        if (!stranded.empty()) {
            LOGI("Stranded-chunk recovery: re-queued=%d frame=%d RD=%d",
                 (int)stranded.size(), m_frameCount,
                 m_renderDist.getDistance());
        }
    }

    bool needRebuild = camMoved || rdChanged || missingNearbyChunk;

    if (needRebuild) {
        m_lastCamCX = camCX;
        m_lastCamCZ = camCZ;
        ++m_candidateRebuildCount;
        m_pendingCandidates.clear();
        StreamScheduler::buildCandidates(camCX, camCZ, 0, loadR, m_pendingCandidates);

        // Strip already-submitted chunks so every slot represents genuine
        // unsubmitted work.  The duplicate guard inside the submission loop
        // is kept as a safety net only.
        {
            auto newEnd = std::remove_if(
                m_pendingCandidates.begin(), m_pendingCandidates.end(),
                [this](const ChunkPriority& cp) {
                    return m_submitted.count({cp.cx, cp.cz}) != 0;
                });
            m_pendingCandidates.erase(newEnd, m_pendingCandidates.end());
        }

        m_scheduler.sortByPriority(m_pendingCandidates);
        m_candidateIdx = 0;
        m_visibility.markDirty();

        if (missingNearbyChunk) {
            LOGI("Missing-chunk recovery rebuild: "
                 "totalInRadius=%d missing=%d submitted=%u candidates=%zu "
                 "camCX=%d camCZ=%d RD=%d rebuilds=%d",
                 scanTotalInRadius, scanMissingCount,
                 (unsigned)m_submitted.size(),
                 m_pendingCandidates.size(),
                 camCX, camCZ,
                 m_renderDist.getDistance(),
                 m_candidateRebuildCount);
        }
    }

    // ── Submit unsubmitted chunks every frame (not only on camera move) ────────
    // This ensures a stationary player at any RD still loads all chunks.
    // maxNew scales with render distance so large RD loads faster.
    // Near chunks always have highest priority (sorted above).
    //
    // CRITICAL: cap maxNew to available queue space and only insert into
    // m_submitted AFTER a successful push.  The old code did:
    //
    //   m_submitted.insert(key);   <- always
    //   m_chunks[key] = ...;       <- always
    //   enqueueChunkBuild(ptr);    <- silently dropped when queue full
    //
    // A dropped push left a zombie chunk: in m_submitted (never retried) and
    // in m_chunks (DIRTY forever). With RD>=16 the 1024-slot ring filled in
    // ~16 frames causing slow loading and terrain missing after RD changes.
    {
        // ── Dynamic submission budget ─────────────────────────────────────────
        // Goal: process one entire outer-ring shell worth of new chunks in
        // roughly 4–8 frames regardless of render distance.
        //
        //   baseNew = max(8, 2*R) scaled by thermal state
        //     RD=8  → 16/frame
        //     RD=12 → 24/frame
        //     RD=16 → 32/frame
        //
        // NOTE: Do NOT add a "far-ring throttle" that skips far candidates
        // while advancing candidateIdx.  Such a throttle causes a permanent
        // stall: the skipped positions are never inserted into m_submitted,
        // so they represent genuine unsubmitted work, but candidateIdx has
        // moved past them.  The candidate list only rebuilds on camMoved or
        // rdChanged, so a stationary player stalls permanently and an
        // exploring player stalls between moves.  Upload-queue priority
        // (distance-sorted in updateGPU) already ensures nearby chunks
        // upload before far ones — no submission-side throttle is needed.
        int thermalScale = m_thermal.maxRebuildBudget(); // 8/4/2/1 per state
        int baseNew = std::max(8, 2 * m_effectiveRadius);
        baseNew = std::max(8, baseNew * thermalScale / 8);

        // BUG FIX (v15→v16): old formula:
        //   queueFreeNow = approximateFree() - 128
        //   maxNew       = min(baseNew, max(0, queueFreeNow))
        //
        // When secondary CLUSTER_REBUILD jobs flood the 4096-slot queue (at
        // RD≥8 the burst can reach 361×16 = 5776 jobs), approximateFree()
        // drops below 128, making queueFreeNow negative and maxNew = 0.
        // The submission while-loop exits immediately without advancing
        // m_candidateIdx.  This stall persisted for seconds while workers
        // drained secondary jobs, and was the primary reason new chunks
        // stopped generating above RD=7.
        //
        // New formula: scale submissions proportionally to available slots,
        // divided by 8 to preserve headroom for secondary jobs.
        // Crucially, always allow at least 1 primary submission so the queue
        // can never be permanently starved by secondary job pressure.
        uint32_t freeSlots = m_jobQueue.approximateFree();
        int maxNew = std::min(baseNew, std::max(1, (int)(freeSlots / 8u)));

        int submitted    = 0;
        int skipped      = 0;
        bool hadOverflow = false;

        // FIX v14: do NOT pre-increment m_candidateIdx before resolving the
        // slot.  Old pattern advanced the index unconditionally then skipped
        // the slot on duplicate — permanently losing that candidate position.
        // New invariant: m_candidateIdx advances ONLY after the slot is fully
        // committed (submitted to ring + inserted into m_submitted) or
        // explicitly skipped as a known duplicate.  On overflow the index stays
        // put so the same slot is retried next frame.
        while (m_candidateIdx < (int)m_pendingCandidates.size()
               && submitted < maxNew
               && !hadOverflow)
        {
            // Peek — do NOT advance yet.
            const auto& cp = m_pendingCandidates[m_candidateIdx];
            ChunkKey key{cp.cx, cp.cz};

            // Safety-net duplicate guard.  The pre-filter on rebuild strips all
            // currently-submitted entries, so this fires only in rare edge cases
            // (e.g. a key re-submitted between rebuild and loop iteration).
            // When it does fire we advance past the slot — the chunk is already
            // handled, no work is lost.
            if (m_submitted.count(key)) {
                ++m_candidateIdx;   // advance: slot is handled, not lost
                ++skipped;
                continue;
            }

            Chunk* ptr;
            {
                std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
                auto ch = std::make_unique<Chunk>(cp.cx, cp.cz);
                ptr = ch.get();
                m_chunks[key] = std::move(ch);
            }

            // Push inline so we can react to failure before touching
            // m_submitted or advancing m_candidateIdx.
            WorldJob job{};
            job.kind  = JobKind::CHUNK_BUILD;
            job.world = this;
            job.chunk = ptr;
            job.ci    = -1;
            if (!m_jobQueue.push(job)) {
                // Queue unexpectedly full despite the headroom cap.
                // Undo the allocation.  Do NOT advance m_candidateIdx —
                // this exact slot will be retried next frame.
                {
                    std::unique_lock<std::shared_mutex> wlk(m_chunksMtx);
                    m_chunks.erase(key);
                }
                m_overflowCount.fetch_add(1, std::memory_order_relaxed);
                hadOverflow = true;
                LOGI("Submission overflow at candidate %zu (queue≈%u free≈%d) RD=%d",
                     m_candidateIdx,
                     m_jobQueue.approximateSize(),
                     (int)m_jobQueue.approximateFree(),
                     m_renderDist.getDistance());
                break;
            }

            // Job is safely in the ring — now commit: mark submitted and advance.
            m_submitted.insert(key);
            ++m_candidateIdx;
            ++submitted;
        }

        // ── Periodic debug log ────────────────────────────────────────────────
        // Every 60 frames (~1 s at 60 fps): dump all streaming telemetry to
        // logcat so that RD-related stalls can be diagnosed without a debugger.
        if (m_frameCount % 60 == 0) {
            size_t uploadBacklog;
            {
                std::unique_lock<std::mutex> ulk(m_uploadMtx);
                uploadBacklog = 0;
                for (auto& bkt : m_uploadBuckets) uploadBacklog += bkt.size();
            }
            // Compute in-radius count for this log tick without a full scan
            // (m_lastTotalInRadius / m_lastMissingCount come from the periodic
            // scan at MISSING_SCAN_INTERVAL; zero between scans is expected).
            LOGI("[ HZCM Stream v14 ] "
                 "frame=%d RD=%d effectiveR=%d | "
                 "queueSize=%u/%u queueFree=%d overflowTotal=%d retryQ=%d | "
                 "submitted=%u candidates=%zu candidateIdx=%zu "
                 "rebuilds=%d skipped=%d | "
                 "totalInRadius=%d missing=%d stranded=%d "
                 "missingNow=%s | "
                 "uploadBacklog=%zu workers=%d visible=%d",
                 m_frameCount,
                 m_renderDist.getDistance(), m_effectiveRadius,
                 m_jobQueue.approximateSize(), JOB_RING_CAPACITY,
                 (int)m_jobQueue.approximateFree(),
                 m_overflowCount.load(std::memory_order_relaxed),
                 m_retryQueueSize.load(std::memory_order_relaxed),
                 (unsigned)m_submitted.size(),
                 m_pendingCandidates.size(), (size_t)m_candidateIdx,
                 m_candidateRebuildCount,
                 skipped,
                 m_lastTotalInRadius, m_lastMissingCount, m_lastStrandedCount,
                 missingNearbyChunk ? "YES" : "no",
                 uploadBacklog,
                 (int)m_workers.size(),
                 m_lastVisibleDraws);
        }
    }

    // ── Rebuild HierarchicalVisibility when camera chunk changes ───────────────
    if (m_visibility.needsRebuild()) {
        // BUG FIXED (v11 → v12): old code passed a lambda that called
        // surfaceHeightAt() for every cell in the (2*RD+1)² grid, each
        // acquiring a separate shared_lock on m_chunksMtx.  At RD=200 that
        // is ~163 k lock acquisitions — a 30–100 ms GL-thread stall per
        // camera chunk-move.  The stall also pushed frame times into the
        // ThermalManager's HOT/CRITICAL range, cutting effectiveRadius to
        // 50–60 % and reducing chunk-submission budgets, compounding the
        // loading problem.
        //
        // Fix: snapshot surface heights for ALL loaded chunks under ONE
        // shared lock, then pass a fast hash-map lookup as the callback.
        // The total cost is one lock acquire + one unordered_map fill over
        // the (small) set of actually-loaded chunks, then one lock release.
        std::unordered_map<ChunkKey, int, ChunkKeyHash> surfHeights;
        {
            std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
            surfHeights.reserve(m_chunks.size());
            for (auto& kv : m_chunks) {
                const Chunk* ch2 = kv.second.get();
                if (!ch2->generated.load(std::memory_order_acquire)) {
                    surfHeights[kv.first] = 40;
                    continue;
                }
                int h = 0;
                for (int y = CHUNK_H - 1; y >= 0; --y) {
                    if (ch2->getBlock(8, y, 8) != BLOCK_AIR) { h = y; break; }
                }
                surfHeights[kv.first] = h;
            }
        }
        m_visibility.rebuild(camCX, camCZ, camY, m_effectiveRadius,
            [&surfHeights](int cx, int cz) -> int {
                auto it = surfHeights.find({cx, cz});
                return it != surfHeights.end() ? it->second : 40;
            });
    }
}

// ── GPU upload ─────────────────────────────────────────────────────────────────
// ── GPU memory management constants ──────────────────────────────────────────
static constexpr float MAX_GPU_USAGE         = 0.85f;  // start evicting above 85%
static constexpr float GPU_EMERGENCY_USAGE   = 0.95f;  // always evict above 95%
static constexpr int   MAX_UPLOADS_PER_FRAME = 4;      // minimum upload floor when GPU full
//                                                        (raised from 2 — was causing starvation)
// OPT v17: increased from 4 to 8.  A margin of 4 meant chunks at exactly
// RD+4 oscillated in/out of the eviction zone as the player moved, causing
// constant evict→rebuild→re-upload cycles.  8 gives a stable hysteresis band.
// v20: increased 8→12.  At RD=60 the old margin (RD+8) was inside the player's
// view frustum, causing continual evict/re-upload pressure on distant-but-visible
// chunks.  12 keeps GPU residency alive well beyond the visible edge.
static constexpr int   GPU_UNLOAD_MARGIN     = 12;

// OPT v17: Rate-limit knobs for the two eviction passes.
// At RD=30 with ~4000 chunks, the 85% pass was doing an O(N log N) sort
// every single frame — ~47K comparisons at 60 Hz = 2.8M comparisons/sec.
// Limiting each pass to once every N frames, and replacing the sort with an
// O(N) threshold scan, eliminates the largest per-frame CPU spike.
static constexpr int GPU_MARGIN_EVICT_INTERVAL   = 4;   // margin pass: max once per 4 frames
static constexpr int GPU_PRESSURE_EVICT_INTERVAL = 6;   // pressure pass: max once per 6 frames
static constexpr int MAX_EVICTION_REBUILDS_PER_PASS = 24; // cap CLUSTER_REBUILD enqueues per pass

void World::updateGPU() {
    m_mega.beginFrame();

    // ── Tick graveyard — delete chunks whose workers have all finished ─────────
    {
        std::lock_guard<std::mutex> glk(m_graveyardMtx);
        auto it = m_graveyard.begin();
        while (it != m_graveyard.end()) {
            it->frames--;
            // Safe to delete when countdown expired AND no worker is inside it
            if (it->frames <= 0 && it->chunk->inFlight.load(std::memory_order_acquire) == 0) {
                it = m_graveyard.erase(it);   // unique_ptr destructor runs here
            } else {
                ++it;
            }
        }
    }

    // ── OPT v17: GPU margin eviction pass (rate-limited) ──────────────────────
    // Frees GPU pages for chunks beyond RD + GPU_UNLOAD_MARGIN so the nearby
    // chunks that actually need pages can get them.
    //
    // Rate-limited to once every GPU_MARGIN_EVICT_INTERVAL frames.
    // Rationale: at RD=30 iterating all ~4000 chunks every frame is wasteful
    // when the margin zone changes slowly.  A 4-frame interval is imperceptible
    // to the player but cuts this pass cost by 4×.
    //
    // Rebuild budget cap: we do NOT want to flood the job queue with hundreds of
    // CLUSTER_REBUILD tasks in one frame.  Uncapped, a single eviction pass at
    // RD=30 could enqueue 4000 × 4 = 16000 CLUSTER_REBUILD jobs simultaneously,
    // saturating the ring and stalling all other work for seconds.
    if ((m_frameCount - m_lastMarginEvictFrame) >= GPU_MARGIN_EVICT_INTERVAL) {
        m_lastMarginEvictFrame = m_frameCount;

        int camCX = m_camCXAtomic.load(std::memory_order_relaxed);
        int camCZ = m_camCZAtomic.load(std::memory_order_relaxed);
        int gpuUnloadRadius = m_effectiveRadius + GPU_UNLOAD_MARGIN;

        std::vector<std::pair<Chunk*, int>> toRebuild;
        toRebuild.reserve(MAX_EVICTION_REBUILDS_PER_PASS);

        {
            std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
            for (auto& kv : m_chunks) {
                Chunk* ch = kv.second.get();
                if (ch->evicted.load(std::memory_order_acquire)) continue;
                int dx = std::abs(ch->cx - camCX);
                int dz = std::abs(ch->cz - camCZ);
                if (dx > gpuUnloadRadius || dz > gpuUnloadRadius) {
                    bool anyFreed = false;
                    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
                        if (ch->clusterGPUOffset[ci] != MEGA_INVALID) {
                            m_mega.free(ch->clusterGPUOffset[ci], ch->clusterFaceCount[ci]);
                            ch->clusterGPUOffset[ci] = MEGA_INVALID;
                            ch->clusterFaceCount[ci] = 0;
                            ch->clusterState[ci].store(ClusterState::DIRTY,
                                                       std::memory_order_release);
                            anyFreed = true;
                            ++m_gpuEvictedMeshes;
                            if ((int)toRebuild.size() < MAX_EVICTION_REBUILDS_PER_PASS)
                                toRebuild.push_back({ch, ci});
                        }
                    }
                    if (anyFreed) {
                        ch->uploadedClusterCount   = 0;
                        ch->clusterFirstUploadMask = 0;
                    }
                }
            }
        }
        // Enqueue rebuilds outside the shared lock
        for (auto& [ch, ci] : toRebuild)
            enqueueClusterRebuild(ch, ci);
    }

    // ── OPT v17: Adaptive GPU pressure eviction (rate-limited, no sort) ────────
    // When GPU usage exceeds MAX_GPU_USAGE, evict the GPU memory of chunks
    // beyond a distance threshold to free pages for nearby chunks.
    //
    // KEY CHANGE from v16: replaced O(N log N) collect-and-sort with an O(N)
    // threshold scan.  The old sort ran every frame at RD=30 on ~4000 candidates
    // — at 60 Hz that was ~240 000 sort iterations per second.
    //
    // New approach:
    //   • Compute evictThresh = max(2/3 of effectiveRadius, 4).
    //     Anything beyond this radius is a candidate for eviction.
    //   • Single linear sweep — no sort, no std::vector realloc.
    //   • Rate-limited: run at most once per GPU_PRESSURE_EVICT_INTERVAL frames
    //     UNLESS usage is above GPU_EMERGENCY_USAGE (95%), in which case we
    //     run every frame as an emergency flush.
    //   • Drain target lowered from 75% → 65% so each pass frees more pages
    //     and the cooldown interval can be longer without pressure spiking back
    //     immediately.
    //   • Rebuild budget capped at MAX_EVICTION_REBUILDS_PER_PASS to avoid
    //     flooding the job ring and stalling all other work.
    {
        float gpuUsage = (m_mega.totalFaces() > 0)
            ? (float)m_mega.usedFaces() / (float)m_mega.totalFaces()
            : 0.f;

        bool emergency = (gpuUsage > GPU_EMERGENCY_USAGE);
        bool cooldownExpired = (m_frameCount - m_lastPressureEvictFrame)
                               >= GPU_PRESSURE_EVICT_INTERVAL;

        if (gpuUsage > MAX_GPU_USAGE && (emergency || cooldownExpired)) {
            m_lastPressureEvictFrame = m_frameCount;

            int camCX = m_camCXAtomic.load(std::memory_order_relaxed);
            int camCZ = m_camCZAtomic.load(std::memory_order_relaxed);

            // FIX v22: Evict chunks beyond a distance that fits within the VRAM budget.
            // OLD: evictThresh = RD*2/3 → at RD=36 = 24, keeping ~1809 chunks
            //      (7236 clusters), far more than the 6000 available slots.
            //      Result: permanent alloc failures, nothing ever reached READY.
            //
            // NEW: hard cap at GPU_MAX_RESIDENT_RADIUS (20 chunks ≈ 5024 clusters,
            //      safely within 6000 slots).  For RD ≤ 20 the old 2/3 formula applies
            //      (keeping even more headroom).  For RD > 20 only the nearest 20
            //      chunks stay GPU-resident; distant terrain is regenerated when
            //      the camera approaches.
            static constexpr int GPU_MAX_RESIDENT_RADIUS = 20;
            int evictThresh = std::min(
                std::max(4, m_effectiveRadius * 2 / 3),
                GPU_MAX_RESIDENT_RADIUS);
            float gpuUsageBefore = gpuUsage;
            LOGI("GPU pressure eviction: usage=%.1f%% evictThresh=%d (RD=%d)",
                 gpuUsageBefore * 100.f, evictThresh, m_effectiveRadius);

            int rebuildsQueued = 0;

            {
                std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
                for (auto& kv : m_chunks) {
                    // Stop once we've brought usage below 65%
                    if (gpuUsage <= 0.65f) break;

                    Chunk* ch = kv.second.get();
                    if (ch->evicted.load(std::memory_order_acquire)) continue;

                    int chebyshev = std::max(std::abs(ch->cx - camCX),
                                             std::abs(ch->cz - camCZ));
                    if (chebyshev < evictThresh) continue;  // keep near chunks

                    bool anyFreed = false;
                    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
                        if (ch->clusterGPUOffset[ci] != MEGA_INVALID) {
                            m_mega.free(ch->clusterGPUOffset[ci],
                                        ch->clusterFaceCount[ci]);
                            ch->clusterGPUOffset[ci] = MEGA_INVALID;
                            ch->clusterFaceCount[ci] = 0;
                            ch->clusterState[ci].store(ClusterState::DIRTY,
                                                       std::memory_order_release);
                            ++m_gpuEvictedMeshes;
                            anyFreed = true;
                            // Cap rebuilds to avoid flooding the job ring
                            if (rebuildsQueued < MAX_EVICTION_REBUILDS_PER_PASS) {
                                enqueueClusterRebuild(ch, ci);
                                ++rebuildsQueued;
                            }
                        }
                    }
                    if (anyFreed) {
                        ch->uploadedClusterCount   = 0;
                        ch->clusterFirstUploadMask = 0;
                        // Recalculate usage after each evicted chunk
                        gpuUsage = (m_mega.totalFaces() > 0)
                            ? (float)m_mega.usedFaces() / (float)m_mega.totalFaces()
                            : 0.f;
                    }
                }
            }

            LOGI("GPU pressure eviction: %.1f%%→%.1f%% evicted=%d rebuilds=%d thresh=%d",
                 gpuUsageBefore * 100.f, gpuUsage * 100.f,
                 m_gpuEvictedMeshes.load(std::memory_order_relaxed),
                 rebuildsQueued, evictThresh);
        }
    }

    // ── Upload budget ─────────────────────────────────────────────────────────
    // Scale with render distance; thermal state limits peak throughput on
    // devices that are running hot.
    //
    // OPT v17: near-chunk fast path (chebDist ≤ 4 = bucket 0) always uploads
    // ALL pending near tasks, bypassing the thermal budget cap.  These are the
    // most visually critical and their count is bounded (≤ 49 chunks × 4 = 196).
    // Starving them while uploading far chunks causes large holes next to the
    // player on thermal-throttled devices like the Infinix Hot 11 2022.
    float gpuUsageNow = (m_mega.totalFaces() > 0)
        ? (float)m_mega.usedFaces() / (float)m_mega.totalFaces()
        : 0.f;
    int rdScale = std::max(1, m_effectiveRadius / 3);
    int budget;
    if (gpuUsageNow >= MAX_GPU_USAGE) {
        budget = MAX_UPLOADS_PER_FRAME;
    } else {
        budget = m_thermal.maxUploadBudget() * CLUSTER_STACK * rdScale;
    }

    std::vector<UploadTask> tasks;
    {
        std::unique_lock<std::mutex> ulk(m_uploadMtx);

        // ── OPT v17: drain buckets 0→3 in priority order ─────────────────────
        // No sort needed — bucket assignment at push time guarantees near-first
        // order.  Bucket 0 (chebDist ≤ 4) always uploads in full regardless of
        // budget (near-chunk fast path).  Buckets 1–3 drain up to the budget.
        int nearCount = (int)m_uploadBuckets[0].size();
        int effectiveBudget = std::max(budget, nearCount);
        int remaining = effectiveBudget;

        // Tally total backlog for diagnostics (done here while mutex is held)
        // (stored in a local; written to stats snapshot in getDebugStats)

        tasks.reserve(effectiveBudget);
        for (int bkt = 0; bkt < UPLOAD_BUCKET_COUNT && remaining > 0; ++bkt) {
            auto& q = m_uploadBuckets[bkt];
            int take = std::min(remaining, (int)q.size());
            for (int i = 0; i < take; ++i) {
                tasks.push_back(q.front());
                q.pop_front();
            }
            remaining -= take;
        }
    }

    // ── Per-task GPU upload ───────────────────────────────────────────────────
    for (auto& task : tasks) {
        Chunk*   ch = task.chunk;
        int      ci = task.ci;

        if (ch->evicted.load(std::memory_order_acquire)) continue;

        // Stale check: cluster was re-dirtied after this task was enqueued.
        // A newer CLUSTER_REBUILD will have re-queued a fresh task.
        if (ch->clusterState[ci].load(std::memory_order_acquire) != ClusterState::MESHED)
            continue;
        if (ch->clusterDirtyGen[ci] != task.dirtyGen)
            continue;

        std::lock_guard<std::mutex> lk(ch->clusterMutex[ci]);
        auto& faces   = ch->clusterFaces[ci];
        uint32_t nFaces = (uint32_t)faces.size();

        if (nFaces > 0) {
            // ── OPT v17: alloc-before-free — prevent flicker ──────────────────
            // OLD code freed the old GPU slot FIRST, then allocated a new one.
            // If the new alloc failed (GPU full) or staging was full, the old
            // slot was gone and the cluster rendered nothing until re-meshed.
            // This was a guaranteed flicker source on every cluster rebuild.
            //
            // NEW: allocate the new slot first.  Only if alloc AND staging
            // both succeed do we free the old slot.  If either fails, the old
            // slot stays valid and the cluster keeps rendering its previous mesh.
            uint32_t newOffset = m_mega.alloc(nFaces);
            if (newOffset == MEGA_INVALID) {
                ++m_gpuAllocFails;
                LOGE("GPU alloc failed: cluster [%d,%d ci=%d] faces=%u used=%u total=%u",
                     ch->cx, ch->cz, ci, nFaces,
                     m_mega.usedFaces(), m_mega.totalFaces());
                // Re-queue so this retries after the eviction pass frees space.
                // Old GPU slot (if any) stays intact — no flicker.
                {
                    std::unique_lock<std::mutex> ulk(m_uploadMtx);
                    m_uploadBuckets[uploadBucket(task.chebDist)].push_back(task);
                }
                continue;
            }

            if (!m_mega.upload(newOffset, faces.data(), nFaces)) {
                // Ring staging full this frame — free the new alloc, keep old.
                m_mega.free(newOffset, nFaces);
                {
                    std::unique_lock<std::mutex> ulk(m_uploadMtx);
                    m_uploadBuckets[uploadBucket(task.chebDist)].push_back(task);
                }
                continue;
            }

            // Both alloc and stage succeeded — NOW safe to retire the old slot.
            if (ch->clusterGPUOffset[ci] != MEGA_INVALID) {
                m_mega.free(ch->clusterGPUOffset[ci], ch->clusterFaceCount[ci]);
            }
            ch->clusterGPUOffset[ci] = newOffset;
            ch->clusterFaceCount[ci] = nFaces;

        } else {
            // nFaces == 0 — empty cluster (all air).  Free old slot if present;
            // no new slot needed.  Empty clusters are legitimately invisible.
            if (ch->clusterGPUOffset[ci] != MEGA_INVALID) {
                m_mega.free(ch->clusterGPUOffset[ci], ch->clusterFaceCount[ci]);
                ch->clusterGPUOffset[ci] = MEGA_INVALID;
                ch->clusterFaceCount[ci] = 0;
            }
        }

        // ── OPT v17: remove shrink_to_fit() from the hot upload path ─────────
        // OLD: faces.clear(); faces.shrink_to_fit();
        // shrink_to_fit() calls free()+malloc() on every cluster upload, causing
        // high-frequency allocator churn.  At RD=16 with hundreds of cluster
        // rebuilds per second this adds up to significant GC pressure on Android.
        //
        // NEW: clear() releases the elements but retains the vector capacity.
        // The next buildClusterMesh() can reuse the same buffer without any
        // heap allocation, turning O(N) alloc into O(1) reuse.
        //
        // Capacity is only released in evictChunk() when the chunk is
        // permanently unloaded from memory.
        faces.clear();

        ch->clusterState[ci].store(ClusterState::READY, std::memory_order_release);

        // Track first-time uploads per cluster for the render visibility gate.
        if (ch->uploadedClusterCount < CLUSTER_STACK) {
            if (!(ch->clusterFirstUploadMask & (1u << ci))) {
                ch->clusterFirstUploadMask |= (1u << ci);
                ++ch->uploadedClusterCount;
            }
        }
    }

    // One glMapBufferRange + fence for all staged uploads
    m_mega.flushUploads();

    // ── v19: DIRTY-cluster watchdog ───────────────────────────────────────────
    //
    // Detects the alloc-fail → margin-eviction → stale-task race that leaves
    // clusters permanently stuck in DIRTY with no in-flight rebuild job:
    //
    //   1. updateGPU: GPU alloc fails for a MESHED cluster → task re-queued.
    //   2. GPU margin eviction fires (same or next frame): cluster state
    //      reset DIRTY.  clusterDirtyGen[ci] is NOT incremented here.
    //   3. The re-queued upload task executes: dirtyGen matches (it wasn't
    //      bumped by the eviction), but clusterState is now DIRTY (not MESHED),
    //      so the stale-gen check fires → task discarded.
    //   4. No new CLUSTER_REBUILD was enqueued because:
    //        - eviction sets state to DIRTY (not MESHED), so workerClusterRebuild
    //          path never fires
    //        - workerNeighbourFlush only runs when a NEW neighbour is processed
    //        - stranded-chunk scan only catches generated==false
    //
    // Result: cluster is DIRTY, inFlight==0, no pending job → invisible forever.
    //
    // v20: halved watchdog interval 180→90 frames (~1.5 s at 60 fps).
    // The alloc-fail race that strands clusters in DIRTY can happen on any
    // frame with GPU pressure.  Detecting it within ~1.5 s vs ~3 s meaningfully
    // reduces the window in which the player sees invisible terrain.
    if (m_frameCount % 90 == 7) {
        // Collect under shared lock — do not call enqueue while holding it.
        std::vector<std::pair<Chunk*, int>> stuckClusters;
        {
            std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
            for (auto& kv : m_chunks) {
                Chunk* ch = kv.second.get();
                if (ch->evicted.load(std::memory_order_acquire))   continue;
                if (!ch->generated.load(std::memory_order_acquire)) continue;
                for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
                    if (ch->clusterState[ci].load(std::memory_order_acquire)
                            == ClusterState::DIRTY)
                        stuckClusters.push_back({ch, ci});
                }
            }
        }
        if (!stuckClusters.empty()) {
            m_watchdogRescues.fetch_add((int)stuckClusters.size(),
                                        std::memory_order_relaxed);
            LOGI("DIRTY watchdog: rescuing %d stuck clusters (frame=%d)",
                 (int)stuckClusters.size(), m_frameCount);
            for (auto& [ch, ci] : stuckClusters)
                enqueueClusterRebuild(ch, ci);
        }
    }
}

// ── Gather visible clusters + sorted draw ─────────────────────────────────────
void World::gatherAndDraw(const Frustum& frustum, GLint originUniformLoc) {
    m_drawBatcher.beginFrame();

    int visible = 0;
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);

    for (auto& kv : m_chunks) {
        Chunk* ch = kv.second.get();

        // 1. HierarchicalVisibility chunk-level cull
        if (!m_visibility.isChunkVisible(ch->cx, ch->cz)) continue;

        // 1b. Residency gate — OPT v17.
        //
        // OLD (v12 and earlier):
        //   if (ch->uploadedClusterCount < CLUSTER_STACK) continue;
        //   → hid entire chunk until ALL 4 clusters uploaded (large holes)
        //
        // v16 (partial fix):
        //   if (ch->uploadedClusterCount == 0) continue;
        //   → allowed partial chunks, but used a historical counter that can
        //     lag during eviction/re-upload transitions.
        //
        // OPT v17:
        //   if (!ch->hasAnyResidentCluster()) continue;
        //   → queries actual GPU-slot state, not a cached counter.
        //     Semantically identical at steady state, but never lies during
        //     the brief window where the counter is reset to 0 by the eviction
        //     pass but a slot is still technically valid in the GPU timeline.
        //     More robust against future state machine changes.
        if (!ch->hasAnyResidentCluster()) continue;

        // 1c. Soft neighbour-generation guard — defers drawing only when a
        // neighbour is ACTIVELY being generated right now (inFlight > 0).
        //
        // BUG FIXED (v11 → v12):
        // The old guard blocked drawing if ANY cardinal neighbour existed in
        // m_chunks but was not yet generated — i.e. was merely QUEUED.
        // With a 1024-slot job ring that stays near-full at moderate/high RD,
        // up to ~1000 chunks are simultaneously "queued but ungenerated".
        // Every chunk adjacent to any of those was permanently invisible,
        // producing the "chunks never appear while exploring" symptom.
        //
        // New rule: only defer while inFlight > 0 on the neighbour, meaning
        // a worker thread is processing it right now.  With at most 3 workers
        // running concurrently, at most 3 chunks have inFlight > 0, so the
        // guard almost never fires.  The brief floating-island faces that may
        // appear between a chunk's first upload and its neighbour's
        // workerNeighbourFlush re-mesh are acceptable vs permanent invisibility.
        {
            static const int CDIRS[4][2] = {{-1,0},{1,0},{0,-1},{0,1}};
            bool waitingForNeighbour = false;
            for (int d = 0; d < 4; ++d) {
                const Chunk* nb = getChunk(ch->cx + CDIRS[d][0],
                                           ch->cz + CDIRS[d][1]);
                // Only block if the neighbour is mid-generation RIGHT NOW.
                // Chunks merely queued (inFlight==0, generated==false) no
                // longer prevent their neighbours from being drawn.
                if (nb && !nb->generated.load(std::memory_order_acquire)
                       &&  nb->inFlight.load(std::memory_order_acquire) > 0) {
                    waitingForNeighbour = true;
                    break;
                }
            }
            if (waitingForNeighbour) continue;
        }

        // 2. Frustum cull
        // Fix #10: Set DISABLE_FRUSTUM_CULLING=true to force all chunks
        // visible for debugging — if holes disappear, the AABB or cull logic
        // is wrong. Verify chunk bounds use world coordinates (cx*CHUNK_W etc.)
        // and chunk min/max are correctly multiplied by chunk size.
        // NOTE: Keep false in production — this is a diagnostic toggle only.
        static constexpr bool DISABLE_FRUSTUM_CULLING = false;

        float mnX, mnY, mnZ, mxX, mxY, mxZ;
        ch->getAABB(mnX, mnY, mnZ, mxX, mxY, mxZ);
        if (!DISABLE_FRUSTUM_CULLING &&
            !frustum.testAABB({mnX,mnY,mnZ}, {mxX,mxY,mxZ})) continue;

        for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
            // 3. Per-cluster visibility (sky / underground)
            if (!m_visibility.isVisible(ch->cx, ch->cz, ci)) continue;

            // Fix #11: Explicit state validation — only READY or MESHED
            // (with a prior valid GPU slot) are renderable.
            // EMPTY/DIRTY/GENERATING clusters MUST never be drawn.
            // Accept both READY and MESHED: a MESHED cluster is mid-rebuild
            // but its GPU allocation from the previous mesh is still valid —
            // keep drawing old data so the face never vanishes between the
            // "neighbour flush" rebuild and the next GPU upload.
            ClusterState cst = ch->clusterState[ci].load(std::memory_order_acquire);
            if (cst != ClusterState::READY && cst != ClusterState::MESHED)
                continue;

            uint32_t offset = ch->clusterGPUOffset[ci];
            uint32_t count  = ch->clusterFaceCount[ci];
            // Fix #7: GPU offset validity guard — never render with
            // MEGA_INVALID offset regardless of cluster state.
            // This is the last safety net if READY was ever set incorrectly.
            if (offset == MEGA_INVALID || count == 0) continue;

            m_drawBatcher.submit(
                ch->clusterWorldX(ci),
                ch->clusterWorldY(ci),
                ch->clusterWorldZ(ci),
                offset, count);
            ++visible;
        }
    }
    m_lastVisibleDraws = visible;

    // FIX v22: log draw count for the first 120 frames to make "nothing draws" obvious
    if (m_frameCount <= 120 && m_frameCount % 30 == 0) {
        LOGI("gatherAndDraw frame=%d: visible=%d loaded_chunks=%zu",
             m_frameCount,
             visible,
             m_chunks.size());
        // Log cluster state breakdown on frame 60 to catch MESHED-but-never-READY
        if (m_frameCount == 60) {
            int nReady=0, nMeshed=0, nDirty=0, nEmpty=0;
            std::shared_lock<std::shared_mutex> rlk2(m_chunksMtx);
            for (auto& kv2 : m_chunks) {
                for (int ci=0; ci<CLUSTER_STACK; ++ci) {
                    switch (kv2.second->clusterState[ci].load(std::memory_order_relaxed)) {
                        case ClusterState::READY:    ++nReady;  break;
                        case ClusterState::MESHED:   ++nMeshed; break;
                        case ClusterState::DIRTY:    ++nDirty;  break;
                        default:                     ++nEmpty;  break;
                    }
                }
            }
            LOGI("Cluster states @ frame 60: READY=%d MESHED=%d DIRTY=%d EMPTY=%d "
                 "gpuSlots used=%u/total=%u",
                 nReady, nMeshed, nDirty, nEmpty,
                 m_mega.usedFaces(), m_mega.totalFaces());
        }
    }

    // Sort by mega-offset → sequential VBO reads → driver prefetch wins
    m_drawBatcher.sort();
    m_drawBatcher.issueDraws(originUniformLoc);
}

// ── Evict ─────────────────────────────────────────────────────────────────────
// MUST be called while holding the write lock on m_chunksMtx.
// We mark `evicted` FIRST (so any in-flight worker stops writing),
// release GPU slots, then hand ownership to the graveyard for deferred deletion.
// The unique_ptr is moved out of m_chunks by the caller AFTER this call.
void World::evictChunk(Chunk* chunk) {
    // Signal workers to abandon this chunk immediately
    chunk->evicted.store(true, std::memory_order_release);

    // Release GPU slots (GL thread — safe here)
    for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
        if (chunk->clusterGPUOffset[ci] != MEGA_INVALID) {
            m_mega.free(chunk->clusterGPUOffset[ci], chunk->clusterFaceCount[ci]);
            chunk->clusterGPUOffset[ci] = MEGA_INVALID;
            chunk->clusterFaceCount[ci] = 0;
        }
        chunk->clusterState[ci].store(ClusterState::EMPTY, std::memory_order_release);

        // OPT v17: release face buffer capacity here — this is the ONLY place
        // shrink_to_fit() is called in the mesh lifecycle.
        // In the hot upload path (updateGPU) we deliberately keep capacity
        // alive so workerClusterRebuild can refill the vector without malloc.
        // On permanent eviction the chunk's memory will never be reused, so
        // release it now to avoid holding ~200 KB of face buffers in the
        // graveyard while waiting for inFlight workers to finish.
        chunk->clusterFaces[ci].clear();
        chunk->clusterFaces[ci].shrink_to_fit();
    }
}

// ── Surface height (for HierarchicalVisibility) ────────────────────────────────
int World::surfaceHeightAt(int cx, int cz) const {
    // Caller holds no lock — take shared briefly
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    const Chunk* ch = getChunk(cx, cz);
    if (!ch || !ch->generated.load(std::memory_order_acquire)) return 40;
    for (int y = CHUNK_H - 1; y >= 0; --y)
        if (ch->getBlock(8, y, 8) != BLOCK_AIR) return y;
    return 0;
}

// ── Accessors ─────────────────────────────────────────────────────────────────
Chunk* World::getChunk(int cx, int cz) const {
    auto it = m_chunks.find({cx, cz});
    return it != m_chunks.end() ? it->second.get() : nullptr;
}

uint8_t World::getBlock(int wx, int wy, int wz) const {
    if (wy < 0 || wy >= CHUNK_H) return BLOCK_AIR;
    int cx = (int)floorf((float)wx / CHUNK_W);
    int cz = (int)floorf((float)wz / CHUNK_D);
    int lx = wx - cx * CHUNK_W;
    int lz = wz - cz * CHUNK_D;
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    const Chunk* ch = getChunk(cx, cz);
    return ch ? ch->getBlock(lx, wy, lz) : BLOCK_AIR;
}

int World::getChunkCount() const {
    std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
    return (int)m_chunks.size();
}

// ── Debug stats snapshot ───────────────────────────────────────────────────────
// Fills a WorldDebugStats struct with a point-in-time telemetry snapshot.
// Called from Renderer::render() on the GL thread; result forwarded to
// DebugOverlay's thread-safe cache which Java polls at ~4 Hz.
WorldDebugStats World::getDebugStats(float fps) {
    WorldDebugStats s{};

    s.fps             = fps;
    s.requestedRD     = m_renderDist.getDistance();
    s.effectiveRadius = m_effectiveRadius;   // = requestedRD after v13 fix

    // Thermal — informational (no longer affects radius after v13 fix)
    s.thermalScale    = m_thermal.radiusScale();
    strncpy(s.thermalState, m_thermal.stateString(),
            sizeof(s.thermalState) - 1);
    s.thermalState[sizeof(s.thermalState) - 1] = '\0';
    s.thermalPressure = m_thermal.thermalPressure();
    s.thermalEmaMs    = m_thermal.frameEmaMs();

    // Job queue
    s.queueSize      = m_jobQueue.approximateSize();
    s.queueFree      = m_jobQueue.approximateFree();
    s.queueCapacity  = JOB_RING_CAPACITY;

    // Upload backlog: sum all 4 priority buckets
    {
        std::unique_lock<std::mutex> ulk(m_uploadMtx);
        int total = 0;
        for (auto& bkt : m_uploadBuckets) total += (int)bkt.size();
        s.uploadBacklog   = total;
        s.gpuRetryQueueSz = total;
    }

    // Chunk counts (brief shared lock)
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        s.loadedChunks    = (int)m_chunks.size();
        s.submittedChunks = (int)m_submitted.size();
    }

    // Remaining unsubmitted candidates (GL-thread-only state — no lock needed)
    int remaining   = (int)m_pendingCandidates.size() - (int)m_candidateIdx;
    s.pendingChunks = (remaining > 0) ? remaining : 0;

    s.workerCount    = (int)m_workers.size();
    s.retryQueueSize = m_retryQueueSize.load(std::memory_order_relaxed);
    s.overflowTotal  = m_overflowCount.load(std::memory_order_relaxed);
    s.visibleDraws   = m_lastVisibleDraws;
    s.camCX          = (m_lastCamCX == INT_MIN) ? 0 : m_lastCamCX;
    s.camCZ          = (m_lastCamCZ == INT_MIN) ? 0 : m_lastCamCZ;

    // Chunk completeness diagnostics (v14)
    s.totalInRadius         = m_lastTotalInRadius;
    s.missingChunks         = m_lastMissingCount;
    s.candidateRebuildCount = m_candidateRebuildCount;
    s.strandedChunks        = m_lastStrandedCount;
    s.candidateIdx          = (int)m_candidateIdx;

    // MegaBuffer (non-const methods — OK, getDebugStats is non-const)
    s.megaUsedFaces  = m_mega.usedFaces();
    s.megaTotalFaces = m_mega.totalFaces();

    // Fix #6: GPU memory health counters
    s.gpuAllocFails    = m_gpuAllocFails.load(std::memory_order_relaxed);
    s.gpuEvictedMeshes = m_gpuEvictedMeshes.load(std::memory_order_relaxed);
    s.gpuUsagePct      = (s.megaTotalFaces > 0)
        ? (float)s.megaUsedFaces / (float)s.megaTotalFaces * 100.f
        : 0.f;
    // gpuRetryQueueSz populated above in the uploadMtx lock scope

    // v19: per-cluster state breakdown + watchdog rescue counter.
    // Acquired under a brief shared lock; iterating all clusters is O(N × STACK)
    // but getDebugStats is called at ~4 Hz, so the cost is negligible.
    {
        std::shared_lock<std::shared_mutex> rlk(m_chunksMtx);
        for (auto& kv : m_chunks) {
            const Chunk* ch = kv.second.get();
            for (int ci = 0; ci < CLUSTER_STACK; ++ci) {
                switch (ch->clusterState[ci].load(std::memory_order_relaxed)) {
                    case ClusterState::READY:  ++s.clustersReady;  break;
                    case ClusterState::MESHED: ++s.clustersMeshed; break;
                    case ClusterState::DIRTY:  ++s.clustersDirty;  break;
                    default:                   ++s.clustersEmpty;  break;
                }
            }
        }
    }
    s.watchdogRescues = m_watchdogRescues.load(std::memory_order_relaxed);

    return s;
}
