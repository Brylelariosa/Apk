package com.browser.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.util.TypedValue
import android.widget.ProgressBar
import android.widget.Switch
import android.widget.TextView
import android.webkit.JavascriptInterface
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    // ── Views ──────────────────────────────────────────────────────────
    private lateinit var webView: ScrollAwareWebView
    private lateinit var urlBar: LinearLayout
    private lateinit var urlInput: EditText
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnSettings: ImageButton
    private lateinit var btnToggle: ImageButton
    private lateinit var pageProgress: ProgressBar
    private lateinit var debugOverlay: android.widget.TextView

    // ── Gesture detector for double-tap / tap-to-dismiss ──────────────
    private lateinit var gestureDetector: GestureDetector

    // ── State ──────────────────────────────────────────────────────────
    private var urlBarVisible = false
    private var toggleVisible = true
    private var isOnHomePage  = false
    private var isImeVisible        = false
    private var webInputFocused     = false  // true while a web text input is active
    private var debugOverlayVisible = false

    @Volatile private var currentHost: String? = null
    @Volatile private var adBlockEnabled  = true

    /**
     * Data saver level:
     *   0 = Off
     *   1 = High Quality   (~20% saved)
     *   2 = Medium Quality (~40% saved)
     *   3 = Low Quality    (~65% saved)
     *   4 = No Images      (~80% saved)
     */
    @Volatile private var dataSaverLevel = 0

    /**
     * FAB (globe button) hide behaviour:
     *   0 = Auto-hide on scroll  (default — hides when scrolling down)
     *   1 = Tap page to hide     (single tap anywhere on the page hides it)
     *   2 = Always visible       (never auto-hides)
     */
    @Volatile private var fabBehavior = 0

    companion object {
        private const val MOBILE_UA  =
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

        private val DATA_SAVER_LABELS = arrayOf(
            "Off",
            "High Quality  — blocks 3rd-party fonts & video (~20% saved)",
            "Medium Quality — blocks 3rd-party images, fonts & video (~40% saved)",
            "Low Quality    — blocks all images, fonts & video (~65% saved)",
            "No Images      — zero images loaded (~80% saved)"
        )

        private val FAB_BEHAVIOR_LABELS = arrayOf(
            "Auto-hide on scroll",
            "Tap page to hide",
            "Always visible"
        )

        // ── Speed-dial home page HTML ──────────────────────────────────
        private val HOME_HTML = """
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0">
<style>
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{
  background:#0a0a0a;color:#fff;
  font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
  min-height:100vh;display:flex;flex-direction:column;
  align-items:center;padding:52px 18px 30px;
}
.clock{font-size:68px;font-weight:200;letter-spacing:-3px;line-height:1;
  background:linear-gradient(135deg,#fff 40%,#4FC3F7);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.date{font-size:13px;color:#666;margin-top:6px;margin-bottom:48px;letter-spacing:.5px}
.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;width:100%;max-width:400px}
a{text-decoration:none;color:inherit}
.card{display:flex;flex-direction:column;align-items:center;gap:8px;
  padding:16px 8px 12px;border-radius:16px;background:#161616;
  border:1px solid #1e1e1e;transition:background .12s,transform .1s}
.card:active{background:#222;transform:scale(.95)}
.icon{width:46px;height:46px;border-radius:12px;display:flex;align-items:center;
  justify-content:center;font-size:19px;font-weight:800;color:#fff;letter-spacing:-1px}
.label{font-size:10px;color:#777;text-align:center;letter-spacing:.3px}
</style>
</head>
<body>
<div class="clock" id="clk"></div>
<div class="date" id="dt"></div>
<div class="grid">
  <a href="https://www.google.com"><div class="card">
    <div class="icon" style="background:#4285F4">G</div>
    <span class="label">Google</span></div></a>
  <a href="https://www.youtube.com"><div class="card">
    <div class="icon" style="background:#FF0000">&#9654;</div>
    <span class="label">YouTube</span></div></a>
  <a href="https://www.facebook.com"><div class="card">
    <div class="icon" style="background:#1877F2">f</div>
    <span class="label">Facebook</span></div></a>
  <a href="https://www.reddit.com"><div class="card">
    <div class="icon" style="background:#FF4500">R</div>
    <span class="label">Reddit</span></div></a>
  <a href="https://x.com"><div class="card">
    <div class="icon" style="background:#111;border:1px solid #333">&#120143;</div>
    <span class="label">X</span></div></a>
  <a href="https://www.wikipedia.org"><div class="card">
    <div class="icon" style="background:#636466">W</div>
    <span class="label">Wikipedia</span></div></a>
  <a href="https://github.com"><div class="card">
    <div class="icon" style="background:#24292e">&#9711;</div>
    <span class="label">GitHub</span></div></a>
  <a href="https://gmail.com"><div class="card">
    <div class="icon" style="background:#EA4335">M</div>
    <span class="label">Gmail</span></div></a>
</div>
<script>
function tick(){
  var n=new Date(),
      h=n.getHours().toString().padStart(2,'0'),
      m=n.getMinutes().toString().padStart(2,'0'),
      days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
      months=['January','February','March','April','May','June','July',
              'August','September','October','November','December'];
  document.getElementById('clk').textContent=h+':'+m;
  document.getElementById('dt').textContent=
    days[n.getDay()]+', '+months[n.getMonth()]+' '+n.getDate();
}
tick();setInterval(tick,5000);
</script>
</body>
</html>
        """.trimIndent()
    }

    // ══════════════════════════════════════════════════════════════════
    // Lifecycle
    // ══════════════════════════════════════════════════════════════════

    override fun onCreate(savedInstanceState: Bundle?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { view, insets ->
            val wasVisible = isImeVisible
            isImeVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            // When the keyboard closes, restore immersive mode automatically.
            // This is the only reliable place to do it — no race conditions.
            dbg("insets ime=$isImeVisible was=$wasVisible")
            if (wasVisible && !isImeVisible) {
                webInputFocused = false
                applyImmersiveMode()
            }
            ViewCompat.onApplyWindowInsets(view, insets)
        }

        bindViews()
        applyImmersiveMode()
        configureWebView()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Re-apply immersive only when focus returns and keyboard is not up.
        // The insets listener handles restoring immersive after keyboard closes,
        // so this covers only cases like returning from another app.
        dbg("winFocus hasFocus=$hasFocus isIme=$isImeVisible webInput=$webInputFocused")
        if (hasFocus && !isImeVisible && !webInputFocused) {
            applyImmersiveMode()
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Immersive mode
    // ══════════════════════════════════════════════════════════════════

    private fun applyImmersiveMode() {
        dbg("applyImmersive")
        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior =
            WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }

    // ══════════════════════════════════════════════════════════════════
    // View binding
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("ClickableViewAccessibility")
    private fun bindViews() {
        webView      = findViewById(R.id.webView)
        urlBar       = findViewById(R.id.urlBar)
        urlInput     = findViewById(R.id.urlInput)
        btnBack      = findViewById(R.id.btnBack)
        btnForward   = findViewById(R.id.btnForward)
        btnRefresh   = findViewById(R.id.btnRefresh)
        btnSettings  = findViewById(R.id.btnSettings)
        btnToggle    = findViewById(R.id.btnToggleUrlBar)
        pageProgress = findViewById(R.id.pageProgress)

        // Debug overlay — small translucent box at top-right showing live events
        debugOverlay = android.widget.TextView(this).apply {
            textSize  = 9f
            setTextColor(0xFFFFFF00.toInt())  // yellow
            setBackgroundColor(0xCC000000.toInt())
            setPadding(8, 8, 8, 8)
            elevation = 50f
            layoutParams = android.widget.FrameLayout.LayoutParams(
                android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                android.widget.FrameLayout.LayoutParams.WRAP_CONTENT,
                android.view.Gravity.BOTTOM
            )
        }
        (findViewById<android.widget.FrameLayout>(android.R.id.content)).addView(debugOverlay)
        debugOverlay.visibility = View.GONE
        debugOverlay.setOnLongClickListener {
            val clip = android.content.ClipData.newPlainText("debug_log", debugOverlay.text)
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
            android.widget.Toast.makeText(this, "Debug log copied", android.widget.Toast.LENGTH_SHORT).show()
            true
        }

        urlBar.post { urlBar.translationY = -urlBar.height.toFloat() }

        btnToggle.setOnClickListener   { toggleUrlBar() }
        btnBack.setOnClickListener     { if (webView.canGoBack())    webView.goBack()    }
        btnForward.setOnClickListener  { if (webView.canGoForward()) webView.goForward() }
        btnRefresh.setOnClickListener  {
            if (isOnHomePage) loadHomePage() else webView.reload()
        }
        btnSettings.setOnClickListener { showSettingsDialog() }

        // ── URL input: IME actions + hardware Enter ───────────────────
        urlInput.setOnEditorActionListener { _, actionId, event ->
            val isAction = actionId == EditorInfo.IME_ACTION_GO
                        || actionId == EditorInfo.IME_ACTION_SEARCH
                        || actionId == EditorInfo.IME_ACTION_DONE
                        || actionId == EditorInfo.IME_ACTION_UNSPECIFIED
            val isEnter  = event?.keyCode == KeyEvent.KEYCODE_ENTER &&
                           event.action   == KeyEvent.ACTION_DOWN
            if (isAction || isEnter) { navigateTo(urlInput.text.toString()); true } else false
        }
        urlInput.setOnKeyListener { _, keyCode, event ->
            if (keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN) {
                navigateTo(urlInput.text.toString()); true
            } else false
        }

        // ── Scroll callback — behaviour depends on fabBehavior setting ─
        webView.onScrollCallback = { dy ->
            if (!urlBarVisible && fabBehavior == 0) {
                if (dy > 8) {
                    hideToggleFab()
                } else if (dy < -8) {
                    showToggleFab(animate = true)
                }
            }
        }

        // ── WebView gesture detector ──────────────────────────────────
        //
        //   Double-tap anywhere  → dismiss URL bar (any mode)
        //   Single tap top 22 %  → show URL bar (any mode)
        //   Single tap anywhere  → hide globe if fabBehavior == 1 (Tap page)
        //
        gestureDetector = GestureDetector(this,
            object : GestureDetector.SimpleOnGestureListener() {

                // Double-tap anywhere → dismiss URL bar
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    if (urlBarVisible) {
                        hideUrlBar()
                        return true
                    }
                    return false
                }

                // Single tap → hide globe if Tap-page mode is on
                override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                    if (fabBehavior == 1 && toggleVisible && !urlBarVisible) {
                        hideToggleFab()
                        return true
                    }
                    return false
                }
            }
        )

        webView.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            false   // never consume — WebView handles all events normally
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // Settings dialog
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private fun showSettingsDialog() {
        val dp = resources.displayMetrics.density
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20*dp).toInt(), (12*dp).toInt(), (20*dp).toInt(), (8*dp).toInt())
        }

        fun divider() = View(this).apply {
            setBackgroundColor(Color.parseColor("#33FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1
            )
        }

        // ── Helper: on/off toggle row ─────────────────────────────────
        fun addToggleRow(
            label: String, desc: String, checked: Boolean,
            onToggle: (Boolean) -> Unit
        ) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, (10*dp).toInt(), 0, (10*dp).toInt())
            }
            val textBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
            }
            textBox.addView(TextView(this).apply {
                text = label; textSize = 15f; setTextColor(Color.WHITE)
            })
            textBox.addView(TextView(this).apply {
                text = desc; textSize = 12f
                setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding(0, (2*dp).toInt(), 0, 0)
            })
            val sw = Switch(this).apply {
                isChecked = checked
                setOnCheckedChangeListener { _, on -> onToggle(on) }
            }
            row.addView(textBox); row.addView(sw)
            container.addView(row)
            container.addView(divider())
        }

        // ── Helper: tappable chevron row → sub-dialog ─────────────────
        fun addChevronRow(
            label: String,
            valueName: () -> String,
            onClick: (TextView) -> Unit
        ) {
            val rippleAttr = TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackground, rippleAttr, true)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, (10*dp).toInt(), 0, (10*dp).toInt())
                isClickable = true; isFocusable = true
                if (rippleAttr.resourceId != 0) setBackgroundResource(rippleAttr.resourceId)
            }
            val textBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
                )
                isClickable = false
            }
            textBox.addView(TextView(this).apply {
                text = label; textSize = 15f; setTextColor(Color.WHITE)
            })
            val valueLabel = TextView(this).apply {
                text = valueName(); textSize = 12f
                setTextColor(Color.parseColor("#4FC3F7"))
                setPadding(0, (2*dp).toInt(), 0, 0)
            }
            textBox.addView(valueLabel)
            row.addView(textBox)
            row.addView(TextView(this).apply {
                text = "›"; textSize = 22f
                setTextColor(Color.parseColor("#99FFFFFF"))
                setPadding((8*dp).toInt(), 0, 0, 0)
            })
            row.setOnClickListener { onClick(valueLabel) }
            container.addView(row)
            container.addView(divider())
        }

        // ── Ad Blocker ────────────────────────────────────────────────
        addToggleRow("Ad Blocker", "Block ads and trackers", adBlockEnabled) { on ->
            adBlockEnabled = on; if (!isOnHomePage) webView.reload()
        }

        // ── Data Saver ────────────────────────────────────────────────
        val dataSaverShort = arrayOf("Off", "High", "Medium", "Low", "No Images")
        addChevronRow("Data Saver", { dataSaverShort[dataSaverLevel] }) { valueLabel ->
            val checkedItem = intArrayOf(dataSaverLevel)
            AlertDialog.Builder(this)
                .setTitle("Data Saver")
                .setSingleChoiceItems(DATA_SAVER_LABELS, dataSaverLevel) { _, which ->
                    checkedItem[0] = which
                }
                .setPositiveButton("Apply") { _, _ ->
                    dataSaverLevel = checkedItem[0]
                    valueLabel.text = dataSaverShort[dataSaverLevel]
                    applyDataSaverSettings()
                    if (!isOnHomePage) webView.reload()
                }
                .setNegativeButton("Cancel", null)
                .show().styleDialog()
        }

        // ── URL Button behaviour ───────────────────────────────────────
        addChevronRow(
            "URL Button",
            { FAB_BEHAVIOR_LABELS[fabBehavior] }
        ) { valueLabel ->
            val checkedItem = intArrayOf(fabBehavior)
            AlertDialog.Builder(this)
                .setTitle("URL Button Visibility")
                .setSingleChoiceItems(FAB_BEHAVIOR_LABELS, fabBehavior) { _, which ->
                    checkedItem[0] = which
                }
                .setPositiveButton("Apply") { _, _ ->
                    fabBehavior = checkedItem[0]
                    valueLabel.text = FAB_BEHAVIOR_LABELS[fabBehavior]
                    // When switching to Always Visible, make sure it's showing
                    if (fabBehavior == 2) {
                        showToggleFab(animate = true)
                    }
                }
                .setNegativeButton("Cancel", null)
                .show().styleDialog()
        }

        // ── Debug Overlay ─────────────────────────────────────────────
        addToggleRow("Debug Overlay", "Show live event log (long-press to copy)", debugOverlayVisible) { on ->
            debugOverlayVisible = on
            debugOverlay.visibility = if (on) View.VISIBLE else View.GONE
        }

        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setView(container)
            .setPositiveButton("Done", null)
            .show().styleDialog()
    }

    /** Applies consistent dark styling to an AlertDialog. */
    // ── Debug overlay ──────────────────────────────────────────────────

    private val debugLog = ArrayDeque<String>()

    private fun dbg(msg: String) {
        val ts = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US)
            .format(java.util.Date())
        val line = "$ts  $msg"
        android.util.Log.d("BrowserKeyboard", line)
        runOnUiThread {
            debugLog.addFirst(line)
            if (debugLog.size > 8) debugLog.removeLast()
            debugOverlay.text = debugLog.joinToString("\n")
        }
    }

    private fun AlertDialog.styleDialog(): AlertDialog {
        window?.setBackgroundDrawableResource(android.R.color.background_dark)
        getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.parseColor("#4FC3F7"))
        getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.parseColor("#99FFFFFF"))
        return this
    }

    // ══════════════════════════════════════════════════════════════════
    // JS → Native bridge
    // ══════════════════════════════════════════════════════════════════

    /**
     * Called from JavaScript when a page input gains focus.
     * Belt-and-suspenders backup for onCreateInputConnection in
     * ScrollAwareWebView — handles edge cases like content-editable divs
     * that don't always trigger onCreateInputConnection.
     */
    inner class WebKeyboardBridge {
        @JavascriptInterface
        fun onInputFocused() {
            runOnUiThread {
                webInputFocused = true
                webView.requestFocus()
                dbg("jsbridge: showing keyboard")
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                val r = imm.showSoftInput(webView, InputMethodManager.SHOW_FORCED)
                WindowInsetsControllerCompat(window, webView)
                    .show(WindowInsetsCompat.Type.ime())
                dbg("jsbridge: imm=$r")
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    // WebView configuration
    // ══════════════════════════════════════════════════════════════════

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled    = true
            domStorageEnabled    = true
            databaseEnabled      = true
            setSupportZoom(true)
            builtInZoomControls  = true
            displayZoomControls  = false
            userAgentString      = MOBILE_UA
            loadWithOverviewMode = true
            useWideViewPort      = true
            allowFileAccess      = false
            @Suppress("DEPRECATION")
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }
        applyDataSaverSettings()

        webView.addJavascriptInterface(WebKeyboardBridge(), "Android")

        // ScrollAwareWebView notifies us when onCreateInputConnection fires
        webView.onWebInputFocused = { webInputFocused = true; dbg("onCreateIC callback") }
        webView.onDebugEvent = { msg -> dbg(msg) }

        // Pad WebView bottom so content scrolls above the keyboard
        ViewCompat.setOnApplyWindowInsetsListener(webView) { view, insets ->
            val imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            view.setPadding(0, 0, 0, imeBottom)
            insets
        }

        webView.webViewClient = object : WebViewClient() {

            override fun onPageStarted(
                view: WebView, url: String?,
                favicon: android.graphics.Bitmap?
            ) {
                pageProgress.visibility = View.VISIBLE
                pageProgress.progress   = 0
                if (url == null || url.startsWith("data:")) {
                    isOnHomePage = true
                    urlInput.setText("Home")
                } else {
                    isOnHomePage = false
                    currentHost = try { java.net.URI(url).host?.removePrefix("www.") }
                                  catch (_: Exception) { null }
                    urlInput.setText(url)
                }
                syncNavButtons()
            }

            override fun onPageFinished(view: WebView, url: String?) {
                pageProgress.visibility = View.GONE

                // Inject JS: detect input focus → trigger native keyboard
                view.evaluateJavascript("""
                    (function() {
                        if (window.__kbListenerAttached) return;
                        window.__kbListenerAttached = true;
                        document.addEventListener('focusin', function(e) {
                            var t = e.target;
                            if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA'
                                    || t.isContentEditable)) {
                                if (typeof Android !== 'undefined') Android.onInputFocused();
                            }
                        }, true);
                    })();
                """.trimIndent(), null)

                if (url == null || url.startsWith("data:")) {
                    isOnHomePage = true
                    urlInput.setText("Home")
                } else {
                    isOnHomePage = false
                    urlInput.setText(url)
                }
                syncNavButtons()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean = false

            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                if (adBlockEnabled && AdBlocker.shouldBlock(request, currentHost))
                    return AdBlocker.emptyResponse()
                if (dataSaverLevel > 0 &&
                    AdBlocker.shouldBlockForDataSaver(request, currentHost, dataSaverLevel))
                    return AdBlocker.emptyResponse()
                return null
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress < 100) {
                    pageProgress.visibility = View.VISIBLE
                    pageProgress.progress   = newProgress
                } else {
                    pageProgress.postDelayed({ pageProgress.visibility = View.GONE }, 200)
                }
            }
        }
        loadHomePage()
    }

    private fun loadHomePage() {
        isOnHomePage = true
        urlInput.setText("Home")
        webView.loadDataWithBaseURL("https://home.local/", HOME_HTML, "text/html", "UTF-8", null)
    }

    private fun applyDataSaverSettings() {
        webView.settings.apply {
            cacheMode = if (dataSaverLevel >= 3) WebSettings.LOAD_CACHE_ELSE_NETWORK
                        else WebSettings.LOAD_DEFAULT
            loadsImagesAutomatically = dataSaverLevel < 4
        }
    }

    private fun syncNavButtons() {
        btnBack.alpha    = if (webView.canGoBack())    1f else 0.32f
        btnForward.alpha = if (webView.canGoForward()) 1f else 0.32f
    }

    // ══════════════════════════════════════════════════════════════════
    // URL bar show / hide
    // ══════════════════════════════════════════════════════════════════

    private fun toggleUrlBar() {
        if (urlBarVisible) hideUrlBar() else showUrlBar()
    }

    private fun showUrlBar() {
        if (urlBarVisible) return
        urlBarVisible = true
        showToggleFab(animate = false)
        urlBar.visibility = View.VISIBLE
        urlBar.animate().translationY(0f).setDuration(270).start()
        if (isOnHomePage) urlInput.setText("")
        urlInput.post {
            // Re-enable focus so the user can type in the URL field
            urlInput.isFocusable = true
            urlInput.isFocusableInTouchMode = true
            urlInput.requestFocus()
            urlInput.selectAll()
            // Keyboard is NOT forced open — tap the field to type,
            // or paste directly since text is already selected.
        }
    }

    private fun hideUrlBar() {
        if (!urlBarVisible) return
        urlBarVisible = false
        dismissKeyboard()
        urlInput.clearFocus()
        // Disable focus so urlInput can never steal focus from the WebView
        // while the bar is hidden — this was preventing web keyboard from appearing
        urlInput.isFocusable = false
        urlInput.isFocusableInTouchMode = false
        webView.requestFocus()
        if (isOnHomePage) urlInput.setText("Home")
        urlBar.animate()
            .translationY(-urlBar.height.toFloat())
            .setDuration(220)
            .withEndAction { urlBar.visibility = View.INVISIBLE }
            .start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Floating toggle-button
    // ══════════════════════════════════════════════════════════════════

    private fun showToggleFab(animate: Boolean) {
        if (toggleVisible) return
        toggleVisible = true
        if (animate) btnToggle.animate().alpha(1f).translationY(0f).setDuration(220).start()
        else { btnToggle.alpha = 1f; btnToggle.translationY = 0f }
    }

    private fun hideToggleFab() {
        if (!toggleVisible) return
        // Never hide in Always Visible mode
        if (fabBehavior == 2) return
        toggleVisible = false
        btnToggle.animate()
            .alpha(0f)
            .translationY(28f * resources.displayMetrics.density)
            .setDuration(200).start()
    }

    // ══════════════════════════════════════════════════════════════════
    // Navigation
    // ══════════════════════════════════════════════════════════════════

    private fun navigateTo(raw: String) {
        val s = raw.trim()
        if (s.isEmpty() || s == "Home") return
        val url = when {
            s.startsWith("http://") || s.startsWith("https://") -> s
            s.contains(".") && !s.contains(" ")                 -> "https://$s"
            else -> "https://www.google.com/search?q=${android.net.Uri.encode(s)}"
        }
        webView.loadUrl(url)
        hideUrlBar()
    }

    private fun dismissKeyboard() {
        WindowInsetsControllerCompat(window, window.decorView)
            .hide(WindowInsetsCompat.Type.ime())
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            urlBarVisible       -> hideUrlBar()
            webView.canGoBack() -> webView.goBack()
            !isOnHomePage       -> loadHomePage()
            else                -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }
}
