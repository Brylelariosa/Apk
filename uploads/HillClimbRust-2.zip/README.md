# Hill Climb Racing Rust

Independent Rust reimplementation of Hill Climb Racing, built to compare performance with the original on the same phone. It installs next to the original (`com.fingersoft.hillclimb`) as **Hill Climb Racing Rust** (`dev.hcrrust.hillclimb`).

**Status: Task 2.1 smoke test. There is no game yet.** The Rust code has never been built or run; PROJECT_STATE.md lists exactly what is and is not verified.

## What the smoke test does
- NativeActivity app (no Java or Kotlin), OpenGL ES 2.0 through EGL, sensor-landscape, arm64-v8a, Android 11+ (minSdk 30).
- Tap to cycle the overlay: **Stats** (FPS avg / min / 1% low, frame-time percentiles, jitter, CPU work per frame, process CPU, RSS, startup time, frame-interval graph), **GPU/EGL info** (vendor, renderer, limits, extension list), **Off**.

## Layout
| Path | Purpose |
|---|---|
| `settings.gradle`, `build.gradle`, `app/` | Gradle Android app (AGP 8.2.2). `app/build.gradle` runs cargo and packages `libhcr_app.so` |
| `app/src/main/` | manifest and resources (name, icon, theme); no Java sources |
| `crates/hcr-bench` | frame statistics and /proc metrics (pure Rust, unit-tested) |
| `crates/hcr-gfx` | draw list, built-in 5x7 font, GLES2 bindings and uploader (GL part Android-only) |
| `crates/hcr-overlay` | overlay pages (pure Rust, unit-tested) |
| `crates/hcr-platform` | logcat logging, panic hook, EGL (Android-only) |
| `crates/hcr-app` | NativeActivity entry point (`libhcr_app.so`) |
| `signing/` | public DEV keystore used for the release build type |
| `docs/` | APK analysis and asset manifest (metadata only) |

## Build
Upload the ZIP to the repo's `uploads/` folder as usual. The CI workflow unzips it, finds `settings.gradle`, and runs Gradle (8.6, JDK 17, NDK r25). The Gradle task graph is:

`rustInfo` (prints toolchain versions) → `rustupTarget` (adds `aarch64-linux-android`) → `rustHostTests` (cargo test on the pure crates; informational, failures are printed but do not stop the build) → `cargoBuild` (release build with the NDK linker, then copies the `.so` into `app/build/rustJniLibs/arm64-v8a`) → normal AGP packaging.

Pass `-PskipRustTests` to Gradle to skip the host tests. The rust-android-gradle plugin is not used; the cargo calls are plain `Exec` tasks.

## Signing
The `release` build type is signed with the public DEV key in `signing/` (fine for sideloading; anyone can sign with it). The `debug` build type uses the usual debug key. Switching between signing keys requires uninstalling the previous build first.

## Notes
- No Fingersoft assets are in this repository or APK.
- Frame time is measured between consecutive buffer swaps (what the display sees). "CPU work per frame" is the time before the swap call.
- 1% low = 1 / (mean interval of the slowest 1% of frames). Percentiles use nearest-rank.
