# PROJECT_STATE — Hill Climb Racing Rust

Last updated: 2026-11-11
Current stage: **2 — toolchain and smoke test. The Task 2.1 Rust code has still NOT been built or run.** Run #1953 failed before any Rust was compiled (see below). Stage 1 (APK analysis) is complete. No game logic exists.

## Goal
Independent Rust reimplementation of Hill Climb Racing, installed next to the untouched original, to measure whether Rust performs better on the same phone with identical visuals and gameplay. No speed claim without measured results.

## Stage tracker
| # | Stage | Status |
|---|-------|--------|
| 1 | Analyze uploaded APK | Done (static analysis only, see docs/ANALYSIS.md) |
| 2 | Understand architecture and functionality | Partial: static structure mapped; runtime behaviour not yet observed |
| 3 | Extract and catalog resources | Done as metadata only (docs/asset_manifest.csv); no asset content copied into the project |
| 4 | Document original graphics and gameplay | Not started (needs on-device observation of the original) |
| 5 | Rust architecture | In progress: 5-crate workspace skeleton written for Task 2.1 |
| 6 | Reimplement game systems | Not started |
| 7 | Recreate visuals | Not started |
| 8 | Performance optimization | Not started |
| 9 | Build separate APK | In progress: Gradle project written (HillClimbRust-2), never run |
| 10 | Test and compare | Not started |

## Build pipeline (learned from build log of run #1953)
- The repo's fixed workflow (Brylelariosa/Apk, `.github/workflows/build.yml`) takes the newest ZIP in `uploads/`, unzips it to `extracted/`, and **requires `settings.gradle` or `settings.gradle.kts` within 4 directory levels**. A workflow file inside the ZIP is never used.
- Toolchain on the runner: Ubuntu 26.04 image, JDK 17 (Temurin), Gradle 8.6, Android SDK with NDK r25.2.9519653 (also r25.1.8937393) and CMake 3.22.1; `CARGO_TERM_COLOR=never`. The workflow also fetches `dtolnay/rust-toolchain` and `Swatinem/rust-cache`, but their steps were skipped (the job stopped earlier), so what they do is unknown.
- Run #1953 (HillClimbRust-1.zip) failed at "Find project directory": "No settings.gradle found inside the zip". Cause: the first ZIP was a pure Cargo project. Not a Rust error.
- Fix in HillClimbRust-2.zip: a Gradle Android app (AGP 8.2.2, matches Gradle 8.6 and the NDK 25.1 default) whose `app/build.gradle` runs cargo through `Exec` tasks and packages `libhcr_app.so`.
- Not yet known: the exact Gradle command the workflow runs (debug or release), whether it expects a wrapper, and which artifact path it uploads. The project supports both build types and standard output paths.

## Task 2.1 smoke test: what exists and what is verified
| Item | State |
|---|---|
| Cargo workspace: `hcr-bench`, `hcr-gfx`, `hcr-overlay`, `hcr-platform`, `hcr-app` | Written, not built |
| Host unit tests (frame statistics, procfs parsers, font atlas, draw list, text wrap, overlay) | Written; run by the `rustHostTests` Gradle task (informational); never run |
| Android build (cargo, arm64-v8a, API 30 NDK linker) via Gradle `Exec` tasks | Written; never run |
| APK packaging and signing by AGP (release signed with the bundled DEV key) | Written; never run |
| Overlay, EGL/GLES2 context, input, lifecycle on the phone | Not run |
| Android API usage (`android-activity` 0.6: `poll_events`, `input_events_iter`, `native_window`, `MainEvent`) | Checked against the published docs, not compiled |
| Local static checks (XML well-formed, TOML parse, bracket balance for Rust and Gradle files) | Passed. They cannot catch compile or Gradle errors |

## Decisions
| Topic | Status |
|---|---|
| Asset policy | User replied "c and how or a". C (bundle) needs written permission from the rights holder, which is not confirmed. **Working default: A** (read assets at runtime from the installed original; nothing copied into repo or APK). Asset code is not part of Task 2.1 and will sit behind one provider interface, so A to C is a switch |
| Renderer | OpenGL ES 2.0 through EGL with raw bindings (same API as the original; its shaders usable as-is). Implemented in Task 2.1; not confirmed by the user |
| Package ID, name, icon | `dev.hcrrust.hillclimb`, "Hill Climb Racing Rust", independently drawn vector icon. Written; not confirmed by the user |
| Packaging | Gradle + AGP (required by the user's pipeline). Rust built by plain `Exec` tasks calling cargo; no Gradle Rust plugin |
| Physics | Proposed: Box2D port, calibrated against the original by observation. Not started |

## Key findings from the APK analysis (details in docs/ANALYSIS.md)
1. Original: Cocos2d-x 2.x C++ (`libgame.so`, arm64) on a Java GLSurfaceView shell; GLES 2.0; OpenSL ES audio; Box2D-style physics (R.U.B.E. JSON vehicle models).
2. 2,399 asset files in standard formats; one unidentified 26 KB high-entropy file (`garage/aaa.dat`), not decoded.
3. Only 7 vehicle models are data-defined. Classic terrain, most vehicle tuning, game rules, camera and UI layout are in stripped native code.
4. Scale: 42 stage folders, 30+ vehicle types, 150 audio files, 68 shaders, 18 languages. A benchmarkable vertical slice comes first.

## Risks
- Rust compile errors are likely on the first real run (code never built).
- Exact physics and terrain parity cannot be guaranteed (stripped native code); plan is black-box calibration, not decompilation.
- Out of scope (SDK/server-bound): ads, IAP, Play Games/cloud saves, Firebase, LiveOps, promos, Helpshift, consent.
- No PC: measuring the original needs an on-device shell (wireless debugging) or screen-recording analysis. Not yet verified on the phone.
- The original declares `com.android.graphics.driver.prefer_angle=true`; whether its GL path differs from this app's plain EGL on the phone must be checked.

## Environment
- Device: Infinix Hot 11 2022, Android 11, 4 GB RAM, 1080x2400, no root/Shizuku (GPU model not yet recorded; the smoke test displays it).
- Build: the user's GitHub Actions ZIP-upload workflow (above). Target arm64-v8a, Android 11+ (minSdk 30).

## Rules carried from the brief
Preserve the original exactly (no redesign, no placeholders). Reuse only authorized assets. Do not wrap the original code. Do not lower quality to gain FPS. Separate package and data directory; original stays untouched. Never mark a feature complete until it is implemented and tested.
