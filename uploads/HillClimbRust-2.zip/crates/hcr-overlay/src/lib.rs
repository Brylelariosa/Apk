//! Debug overlay: turns frame statistics and GPU/EGL facts into draw-list geometry.
//!
//! Pure Rust (no GL, no Android) so it is unit-tested on the host. Text is rebuilt
//! at a low rate by [`Overlay::update_text`]; drawing a frame only walks cached
//! strings, so the Stats page performs no heap allocation per frame.
#![forbid(unsafe_code)]

use hcr_bench::{FrameRecorder, FrameStats};
use hcr_gfx::{layout, Color, DrawList};

const WHITE: Color = [255, 255, 255, 255];
const ACCENT: Color = [255, 150, 60, 255];
const DIM: Color = [170, 180, 195, 255];
const PANEL: Color = [0, 0, 0, 170];
const FULL_PANEL: Color = [0, 0, 0, 215];
const GOOD: Color = [80, 220, 120, 255];
const WARN: Color = [240, 200, 60, 255];
const BAD: Color = [240, 80, 70, 255];
const GRID: Color = [255, 255, 255, 70];

/// Frame-interval bars shown in the graph.
const GRAPH_BARS: usize = 300;
/// Vertical range of the graph: two 60 Hz frames.
const GRAPH_MAX_MS: f32 = 33.34;

/// Overlay pages, cycled by tapping the screen.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Page {
    /// Frame statistics and the frame-interval graph.
    Stats,
    /// GPU / EGL facts and the GL extension list.
    Info,
    /// Nothing drawn (quiet mode for benchmarking).
    Off,
}

impl Page {
    pub fn next(self) -> Page {
        match self {
            Page::Stats => Page::Info,
            Page::Info => Page::Off,
            Page::Off => Page::Stats,
        }
    }
}

/// Static facts gathered once after the GL context exists.
#[derive(Clone, Debug, Default)]
pub struct DeviceInfo {
    pub lines: Vec<String>,
    /// Space-separated GL extension names.
    pub extensions: String,
}

/// Values refreshed a couple of times per second.
#[derive(Clone, Copy, Debug, Default)]
pub struct LiveStats {
    pub frame: FrameStats,
    pub cpu_pct: Option<f32>,
    pub rss_kb: Option<u64>,
    pub peak_rss_kb: Option<u64>,
    pub startup_ms: Option<f64>,
    pub total_frames: u64,
}

struct InfoCache {
    max_chars: usize,
    ext_len: usize,
    header: String,
    lines: Vec<String>,
}

pub struct Overlay {
    page: Page,
    title: String,
    lines: Vec<String>,
    info_cache: Option<InfoCache>,
}

impl Overlay {
    pub fn new() -> Self {
        Self {
            page: Page::Stats,
            title: String::new(),
            lines: Vec::new(),
            info_cache: None,
        }
    }

    pub fn page(&self) -> Page {
        self.page
    }

    pub fn next_page(&mut self) {
        self.page = self.page.next();
    }

    /// Rebuilds the cached text. Call a few times per second, not every frame.
    pub fn update_text(&mut self, s: &LiveStats, width: i32, height: i32) {
        let f = &s.frame;
        self.title = format!(
            "HCR-RUST SMOKE TEST v{}   surface {}x{}   tap: next page",
            env!("CARGO_PKG_VERSION"),
            width,
            height
        );
        self.lines.clear();
        self.lines.push(format!(
            "FPS  avg {:.1}   min {:.1}   1% low {:.1}",
            f.avg_fps, f.min_fps, f.low1_fps
        ));
        self.lines.push(format!(
            "Frame ms  avg {:.2}  p50 {:.2}  p95 {:.2}  p99 {:.2}  max {:.2}",
            f.avg_ms, f.p50_ms, f.p95_ms, f.p99_ms, f.max_ms
        ));
        self.lines.push(format!(
            "Jitter (std dev) {:.2} ms   window {} frames   total {}",
            f.stddev_ms, f.samples, s.total_frames
        ));
        self.lines.push(format!(
            "CPU work per frame  avg {:.2} ms   p99 {:.2} ms",
            f.work_avg_ms, f.work_p99_ms
        ));
        self.lines.push(format!(
            "Process CPU {}   RSS {}   peak {}",
            fmt_pct(s.cpu_pct),
            fmt_mb(s.rss_kb),
            fmt_mb(s.peak_rss_kb)
        ));
        self.lines.push(format!(
            "Startup (process start to first frame) {}",
            fmt_ms(s.startup_ms)
        ));
    }

    /// Appends the current page's geometry to `list` (screen pixels, origin top-left).
    pub fn draw(
        &mut self,
        list: &mut DrawList,
        rec: &FrameRecorder,
        info: &DeviceInfo,
        width: f32,
        height: f32,
    ) {
        // One font pixel = `scale` screen pixels: 3 on a 1080-pixel-high landscape screen.
        let scale = (height / 360.0).round().max(1.0);
        match self.page {
            Page::Off => {}
            Page::Stats => self.draw_stats(list, rec, width, height, scale),
            Page::Info => self.draw_info(list, info, width, height, scale),
        }
    }

    fn draw_stats(
        &self,
        list: &mut DrawList,
        rec: &FrameRecorder,
        width: f32,
        height: f32,
        scale: f32,
    ) {
        let pad = 4.0 * scale;
        let line_h = 9.0 * scale;
        let char_w = 6.0 * scale;

        if !self.title.is_empty() {
            let longest = self
                .lines
                .iter()
                .map(|l| l.chars().count())
                .chain(std::iter::once(self.title.chars().count()))
                .max()
                .unwrap_or(0);
            let panel_w = pad * 2.0 + longest as f32 * char_w;
            let panel_h = pad * 2.0 + (self.lines.len() + 1) as f32 * line_h;
            list.rect(0.0, 0.0, panel_w, panel_h, PANEL);
            let mut y = pad;
            list.text(pad, y, scale, ACCENT, &self.title);
            y += line_h;
            for line in &self.lines {
                list.text(pad, y, scale, WHITE, line);
                y += line_h;
            }
        }

        // Frame-interval graph along the bottom edge.
        let bar_w = (width * 0.8 / GRAPH_BARS as f32).floor().max(1.0);
        let graph_w = bar_w * GRAPH_BARS as f32;
        let graph_h = height * 0.25;
        let x0 = pad * 2.0;
        let y1 = height - pad * 2.0;
        list.rect(x0 - pad, y1 - graph_h - pad, graph_w + pad * 2.0, graph_h + pad * 2.0, PANEL);

        let line_t = scale.max(1.0);
        let y_16 = y1 - graph_h * (16.67 / GRAPH_MAX_MS);
        list.rect(x0, y_16, graph_w, line_t, GRID);
        list.rect(x0, y1 - graph_h, graph_w, line_t, GRID);
        list.text(x0 + graph_w + pad * 2.0, y_16 - 4.0 * scale, scale, DIM, "16.7 ms");
        list.text(x0 + graph_w + pad * 2.0, y1 - graph_h - 4.0 * scale, scale, DIM, "33.3 ms");

        let (a, b) = rec.intervals_ordered();
        let total = a.len() + b.len();
        let take = total.min(GRAPH_BARS);
        let skip = total - take;
        for (i, us) in a.iter().chain(b.iter()).skip(skip).enumerate() {
            let ms = *us as f32 / 1000.0;
            let h = (ms / GRAPH_MAX_MS).min(1.0) * graph_h;
            let color = if ms <= 18.0 {
                GOOD
            } else if ms <= 25.0 {
                WARN
            } else {
                BAD
            };
            list.rect(x0 + i as f32 * bar_w, y1 - h, (bar_w - 1.0).max(1.0), h, color);
        }
    }

    fn draw_info(
        &mut self,
        list: &mut DrawList,
        info: &DeviceInfo,
        width: f32,
        height: f32,
        scale: f32,
    ) {
        let pad = 4.0 * scale;
        let line_h = 9.0 * scale;
        list.rect(0.0, 0.0, width, height, FULL_PANEL);
        let mut y = pad;
        list.text(pad, y, scale, ACCENT, "GPU / EGL INFO   (tap: next page)");
        y += line_h * 1.5;
        for line in &info.lines {
            list.text(pad, y, scale, WHITE, line);
            y += line_h;
        }
        y += line_h * 0.5;

        // The extension list is long: draw it smaller and cache the wrapped lines.
        let ext_scale = (scale - 1.0).max(1.0);
        let ext_char_w = 6.0 * ext_scale;
        let ext_line_h = 9.0 * ext_scale;
        let max_chars = (((width - pad * 2.0) / ext_char_w) as usize).max(1);
        let stale = match &self.info_cache {
            Some(c) => c.max_chars != max_chars || c.ext_len != info.extensions.len(),
            None => true,
        };
        if stale {
            self.info_cache = Some(InfoCache {
                max_chars,
                ext_len: info.extensions.len(),
                header: format!(
                    "GL EXTENSIONS ({})",
                    info.extensions.split_whitespace().count()
                ),
                lines: layout::wrap_words(&info.extensions, max_chars),
            });
        }
        if let Some(cache) = &self.info_cache {
            list.text(pad, y, scale, ACCENT, &cache.header);
            y += line_h * 1.2;
            for line in &cache.lines {
                if y + ext_line_h > height {
                    break;
                }
                list.text(pad, y, ext_scale, DIM, line);
                y += ext_line_h;
            }
        }
    }
}

impl Default for Overlay {
    fn default() -> Self {
        Self::new()
    }
}

fn fmt_pct(v: Option<f32>) -> String {
    v.map_or_else(|| "n/a".to_string(), |x| format!("{x:.0}% of 1 core"))
}

fn fmt_mb(kb: Option<u64>) -> String {
    kb.map_or_else(|| "n/a".to_string(), |k| format!("{:.1} MB", k as f64 / 1024.0))
}

fn fmt_ms(ms: Option<f64>) -> String {
    ms.map_or_else(|| "n/a".to_string(), |m| format!("{m:.0} ms"))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture() -> (Overlay, FrameRecorder, DeviceInfo) {
        let mut rec = FrameRecorder::new(600);
        for i in 0..400u32 {
            rec.push(16_000 + (i % 7) * 300, 900);
        }
        let live = LiveStats {
            frame: rec.stats(),
            cpu_pct: Some(12.5),
            rss_kb: Some(48_000),
            peak_rss_kb: Some(52_000),
            startup_ms: Some(420.0),
            total_frames: rec.total_frames(),
        };
        let mut overlay = Overlay::new();
        overlay.update_text(&live, 2400, 1080);
        let info = DeviceInfo {
            lines: vec!["GL_VENDOR    ARM".to_string(), "GL_RENDERER  Mali".to_string()],
            extensions: "GL_OES_a GL_OES_b GL_EXT_c ".repeat(40),
        };
        (overlay, rec, info)
    }

    #[test]
    fn page_cycle_returns_to_start() {
        assert_eq!(Page::Stats.next().next().next(), Page::Stats);
    }

    #[test]
    fn stats_page_draws_text_and_all_bars() {
        let (mut overlay, rec, info) = fixture();
        let mut list = DrawList::with_capacity_quads(4096);
        overlay.draw(&mut list, &rec, &info, 2400.0, 1080.0);
        // 300 bars x 6 vertices, plus panel, grid lines and text.
        assert!(list.len() > 6 * 300, "{}", list.len());
    }

    #[test]
    fn stats_page_before_first_update_still_draws_graph() {
        let rec = FrameRecorder::new(10);
        let mut overlay = Overlay::new();
        let mut list = DrawList::with_capacity_quads(64);
        overlay.draw(&mut list, &rec, &DeviceInfo::default(), 1280.0, 720.0);
        assert!(!list.is_empty());
    }

    #[test]
    fn info_page_draws_and_off_page_is_empty() {
        let (mut overlay, rec, info) = fixture();
        let mut list = DrawList::with_capacity_quads(4096);
        overlay.next_page();
        assert_eq!(overlay.page(), Page::Info);
        overlay.draw(&mut list, &rec, &info, 2400.0, 1080.0);
        assert!(!list.is_empty());

        overlay.next_page();
        assert_eq!(overlay.page(), Page::Off);
        list.clear();
        overlay.draw(&mut list, &rec, &info, 2400.0, 1080.0);
        assert!(list.is_empty());
    }

    #[test]
    fn formatting_handles_missing_values() {
        assert_eq!(fmt_pct(None), "n/a");
        assert_eq!(fmt_mb(Some(2048)), "2.0 MB");
        assert_eq!(fmt_ms(Some(419.6)), "420 ms");
    }
}
