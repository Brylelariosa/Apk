//! Minimal 2D rendering primitives.
//!
//! * [`font`], [`draw_list`], [`layout`]: pure Rust, unit-tested on the host.
//! * `gl`, `renderer`: raw OpenGL ES 2.0 bindings and a draw-list uploader (Android only).
//!
//! The renderer uses the same API level as the original game (OpenGL ES 2.0).

pub mod draw_list;
pub mod font;
pub mod layout;

#[cfg(target_os = "android")]
pub mod gl;
#[cfg(target_os = "android")]
pub mod renderer;

pub use draw_list::{Color, DrawList, Vertex};
